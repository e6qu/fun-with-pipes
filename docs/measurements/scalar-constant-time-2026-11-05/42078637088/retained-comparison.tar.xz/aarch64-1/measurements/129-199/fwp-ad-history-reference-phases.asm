
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x260>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911de0a5 	add	x5, x5, #0x778
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x260>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911e0084 	add	x4, x4, #0x780
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe838>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2b34:	912d6000 	add	x0, x0, #0xb58
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1e20>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91208042 	add	x2, x2, #0x820
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9437a60 	ldr	w0, [x19, #888]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2c7c:	912da000 	add	x0, x0, #0xb68
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2c8c:	91302000 	add	x0, x0, #0xc08
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2ca4:	912f8000 	add	x0, x0, #0xbe0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2cb0:	912ec000 	add	x0, x0, #0xbb0
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__divti3+0x260>
    2cbc:	912e2000 	add	x0, x0, #0xb88
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xb40>
    2eb4:	9109c021 	add	x1, x1, #0x270
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3050:	91132000 	add	x0, x0, #0x4c8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb40>
    3118:	91094021 	add	x1, x1, #0x250
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3150:	91138000 	add	x0, x0, #0x4e0
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <__divti3+0x260>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <__divti3+0x260>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	d0000058 	adrp	x24, d000 <__divti3+0x260>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	9114a042 	add	x2, x2, #0x528
    31e0:	911602d6 	add	x22, x22, #0x580
    31e4:	913f6318 	add	x24, x24, #0xfd8
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <__divti3+0x260>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	9115e323 	add	x3, x25, #0x578
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91164000 	add	x0, x0, #0x590
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    32c4:	9117c2a1 	add	x1, x21, #0x5f0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    32d8:	912780a5 	add	x5, x5, #0x9e0
    32dc:	9117c2a1 	add	x1, x21, #0x5f0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	9117c2b7 	add	x23, x21, #0x5f0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	9117c2b5 	add	x21, x21, #0x5f0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	9117c2b5 	add	x21, x21, #0x5f0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    3468:	912760a5 	add	x5, x5, #0x9d8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3570:	91132000 	add	x0, x0, #0x4c8
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x260>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91166021 	add	x1, x1, #0x598
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x260>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91168021 	add	x1, x1, #0x5a0
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x260>
    37e0:	9116a021 	add	x1, x1, #0x5a8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__divti3+0x260>
    3838:	aa1303e3 	mov	x3, x19
    383c:	9116c042 	add	x2, x2, #0x5b0
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3950:	91132000 	add	x0, x0, #0x4c8
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3970:	91170000 	add	x0, x0, #0x5c0
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3a08:	91178000 	add	x0, x0, #0x5e0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3a18:	91180000 	add	x0, x0, #0x600
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb40>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0a020 	ldr	q0, [x1, #640]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3b18:	9118a000 	add	x0, x0, #0x628
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3b88:	91196000 	add	x0, x0, #0x658
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__divti3+0x260>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911aa084 	add	x4, x4, #0x6a8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__divti3+0x260>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911b0084 	add	x4, x4, #0x6c0
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__divti3+0x260>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911ac084 	add	x4, x4, #0x6b0
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    3fa8:	9117c042 	add	x2, x2, #0x5f0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__divti3+0x260>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__divti3+0x260>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911b2021 	add	x1, x1, #0x6c8
    4004:	911b4000 	add	x0, x0, #0x6d0
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__divti3+0x260>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911bc042 	add	x2, x2, #0x6f0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa10>
    410c:	9113c061 	add	x1, x3, #0x4f0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    411c:	9117c262 	add	x2, x19, #0x5f0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xb40>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa10>
    414c:	9114c021 	add	x1, x1, #0x530
    4150:	3dc0a443 	ldr	q3, [x2, #656]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa10>
    417c:	9113c063 	add	x3, x3, #0x4f0
    4180:	91164084 	add	x4, x4, #0x590
    4184:	9117c266 	add	x6, x19, #0x5f0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9117c275 	add	x21, x19, #0x5f0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    4268:	911e8000 	add	x0, x0, #0x7a0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9117c273 	add	x19, x19, #0x5f0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <caf61>:
    42c4:	900000e2 	adrp	x2, 20000 <__data_start>
    42c8:	9101c041 	add	x1, x2, #0x70
    42cc:	b9409820 	ldr	w0, [x1, #152]
    42d0:	34000060 	cbz	w0, 42dc <caf61+0x18>
    42d4:	f9405020 	ldr	x0, [x1, #160]
    42d8:	d65f03c0 	ret
    42dc:	b940a820 	ldr	w0, [x1, #168]
    42e0:	340000e0 	cbz	w0, 42fc <caf61+0x38>
    42e4:	f9405820 	ldr	x0, [x1, #176]
    42e8:	9101c042 	add	x2, x2, #0x70
    42ec:	52800021 	mov	w1, #0x1                   	// #1
    42f0:	b9009841 	str	w1, [x2, #152]
    42f4:	f9005040 	str	x0, [x2, #160]
    42f8:	d65f03c0 	ret
    42fc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4300:	52800024 	mov	w4, #0x1                   	// #1
    4304:	aa0303e0 	mov	x0, x3
    4308:	b900a824 	str	w4, [x1, #168]
    430c:	f9005823 	str	x3, [x1, #176]
    4310:	17fffff6 	b	42e8 <caf61+0x24>

0000000000004314 <fwp_wake_io>:
    4314:	900000e9 	adrp	x9, 20000 <__data_start>
    4318:	9101c122 	add	x2, x9, #0x70
    431c:	f9400001 	ldr	x1, [x0]
    4320:	5280000a 	mov	w10, #0x0                   	// #0
    4324:	f9403c46 	ldr	x6, [x2, #120]
    4328:	52800008 	mov	w8, #0x0                   	// #0
    432c:	4f000400 	movi	v0.4s, #0x0
    4330:	52800027 	mov	w7, #0x1                   	// #1
    4334:	aa0103e2 	mov	x2, x1
    4338:	b4000321 	cbz	x1, 439c <fwp_wake_io+0x88>
    433c:	f9408c25 	ldr	x5, [x1, #280]
    4340:	39015c27 	strb	w7, [x1, #87]
    4344:	b4000165 	cbz	x5, 4370 <fwp_wake_io+0x5c>
    4348:	a9520c24 	ldp	x4, x3, [x1, #288]
    434c:	b4000364 	cbz	x4, 43b8 <fwp_wake_io+0xa4>
    4350:	f9009483 	str	x3, [x4, #296]
    4354:	f9409423 	ldr	x3, [x1, #296]
    4358:	b4000043 	cbz	x3, 4360 <fwp_wake_io+0x4c>
    435c:	f9009064 	str	x4, [x3, #288]
    4360:	91080023 	add	x3, x1, #0x200
    4364:	f900943f 	str	xzr, [x1, #296]
    4368:	3c918060 	stur	q0, [x3, #-232]
    436c:	f9400001 	ldr	x1, [x0]
    4370:	f9402843 	ldr	x3, [x2, #80]
    4374:	f2001c7f 	tst	x3, #0xff000000ff
    4378:	54fffde1 	b.ne	4334 <fwp_wake_io+0x20>  // b.any
    437c:	39015047 	strb	w7, [x2, #84]
    4380:	f900805f 	str	xzr, [x2, #256]
    4384:	b40001e6 	cbz	x6, 43c0 <fwp_wake_io+0xac>
    4388:	f90080c2 	str	x2, [x6, #256]
    438c:	aa0203e6 	mov	x6, x2
    4390:	52800028 	mov	w8, #0x1                   	// #1
    4394:	aa0103e2 	mov	x2, x1
    4398:	b5fffd21 	cbnz	x1, 433c <fwp_wake_io+0x28>
    439c:	3400006a 	cbz	w10, 43a8 <fwp_wake_io+0x94>
    43a0:	9101c120 	add	x0, x9, #0x70
    43a4:	f900400b 	str	x11, [x0, #128]
    43a8:	34000068 	cbz	w8, 43b4 <fwp_wake_io+0xa0>
    43ac:	9101c129 	add	x9, x9, #0x70
    43b0:	f9003d26 	str	x6, [x9, #120]
    43b4:	d65f03c0 	ret
    43b8:	f90000a3 	str	x3, [x5]
    43bc:	17ffffe7 	b	4358 <fwp_wake_io+0x44>
    43c0:	aa0203eb 	mov	x11, x2
    43c4:	5280002a 	mov	w10, #0x1                   	// #1
    43c8:	17fffff1 	b	438c <fwp_wake_io+0x78>
    43cc:	d503201f 	nop

00000000000043d0 <fwp_tape_buffers_release>:
    43d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d4:	910003fd 	mov	x29, sp
    43d8:	a90153f3 	stp	x19, x20, [sp, #16]
    43dc:	aa0003f3 	mov	x19, x0
    43e0:	f9401400 	ldr	x0, [x0, #40]
    43e4:	b7f80760 	tbnz	x0, #63, 44d0 <fwp_tape_buffers_release+0x100>
    43e8:	f9401a61 	ldr	x1, [x19, #48]
    43ec:	b7f80301 	tbnz	x1, #63, 444c <fwp_tape_buffers_release+0x7c>
    43f0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43f4:	eb02001f 	cmp	x0, x2
    43f8:	540002a8 	b.hi	444c <fwp_tape_buffers_release+0x7c>  // b.pmore
    43fc:	8b000400 	add	x0, x0, x0, lsl #1
    4400:	d2a00102 	mov	x2, #0x80000               	// #524288
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	cb000042 	sub	x2, x2, x0
    440c:	eb420c3f 	cmp	x1, x2, lsr #3
    4410:	540001e8 	b.hi	444c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4414:	8b010c14 	add	x20, x0, x1, lsl #3
    4418:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    441c:	911ec000 	add	x0, x0, #0x7b0
    4420:	97fff97c 	bl	2a10 <getenv@plt>
    4424:	b4000240 	cbz	x0, 446c <fwp_tape_buffers_release+0x9c>
    4428:	39400001 	ldrb	w1, [x0]
    442c:	7100c03f 	cmp	w1, #0x30
    4430:	540001e1 	b.ne	446c <fwp_tape_buffers_release+0x9c>  // b.any
    4434:	39400400 	ldrb	w0, [x0, #1]
    4438:	350001a0 	cbnz	w0, 446c <fwp_tape_buffers_release+0x9c>
    443c:	aa1303e0 	mov	x0, x19
    4440:	a94153f3 	ldp	x19, x20, [sp, #16]
    4444:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4448:	17fffc0e 	b	3480 <fwp_tape_buffers_dispose>
    444c:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    4450:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4454:	911ec000 	add	x0, x0, #0x7b0
    4458:	97fff96e 	bl	2a10 <getenv@plt>
    445c:	b4ffff00 	cbz	x0, 443c <fwp_tape_buffers_release+0x6c>
    4460:	39400001 	ldrb	w1, [x0]
    4464:	7100c03f 	cmp	w1, #0x30
    4468:	54fffe60 	b.eq	4434 <fwp_tape_buffers_release+0x64>  // b.none
    446c:	d1000681 	sub	x1, x20, #0x1
    4470:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4474:	eb00003f 	cmp	x1, x0
    4478:	54fffe28 	b.hi	443c <fwp_tape_buffers_release+0x6c>  // b.pmore
    447c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4480:	900000f6 	adrp	x22, 20000 <__data_start>
    4484:	9101c2d6 	add	x22, x22, #0x70
    4488:	9102e2d5 	add	x21, x22, #0xb8
    448c:	aa1503e0 	mov	x0, x21
    4490:	97fffbfc 	bl	3480 <fwp_tape_buffers_dispose>
    4494:	ad400a61 	ldp	q1, q2, [x19]
    4498:	f9007ad4 	str	x20, [x22, #240]
    449c:	4f000400 	movi	v0.4s, #0x0
    44a0:	ad000aa1 	stp	q1, q2, [x21]
    44a4:	3dc00a61 	ldr	q1, [x19, #32]
    44a8:	3d800aa1 	str	q1, [x21, #32]
    44ac:	f9401a60 	ldr	x0, [x19, #48]
    44b0:	f9001aa0 	str	x0, [x21, #48]
    44b4:	f9001a7f 	str	xzr, [x19, #48]
    44b8:	ad000260 	stp	q0, q0, [x19]
    44bc:	3d800a60 	str	q0, [x19, #32]
    44c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44cc:	d65f03c0 	ret
    44d0:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    44d4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    44d8:	911ec000 	add	x0, x0, #0x7b0
    44dc:	97fff94d 	bl	2a10 <getenv@plt>
    44e0:	b5fffa40 	cbnz	x0, 4428 <fwp_tape_buffers_release+0x58>
    44e4:	17ffffd6 	b	443c <fwp_tape_buffers_release+0x6c>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_poll_events>:
    44f0:	d10103ff 	sub	sp, sp, #0x40
    44f4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44f8:	f947f400 	ldr	x0, [x0, #4072]
    44fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4500:	910083fd 	add	x29, sp, #0x20
    4504:	a90353f3 	stp	x19, x20, [sp, #48]
    4508:	900000f4 	adrp	x20, 20000 <__data_start>
    450c:	f9400001 	ldr	x1, [x0]
    4510:	f9000fe1 	str	x1, [sp, #24]
    4514:	d2800001 	mov	x1, #0x0                   	// #0
    4518:	97fffd1a 	bl	3980 <fwp_now_ns>
    451c:	9101c281 	add	x1, x20, #0x70
    4520:	f9407c33 	ldr	x19, [x1, #248]
    4524:	b4000e93 	cbz	x19, 46f4 <fwp_poll_events+0x204>
    4528:	aa1303e1 	mov	x1, x19
    452c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4530:	14000005 	b	4544 <fwp_poll_events+0x54>
    4534:	f9408821 	ldr	x1, [x1, #272]
    4538:	eb03005f 	cmp	x2, x3
    453c:	9a83d042 	csel	x2, x2, x3, le
    4540:	b40000c1 	cbz	x1, 4558 <fwp_poll_events+0x68>
    4544:	f9403423 	ldr	x3, [x1, #104]
    4548:	b6ffff62 	tbz	x2, #63, 4534 <fwp_poll_events+0x44>
    454c:	f9408821 	ldr	x1, [x1, #272]
    4550:	aa0303e2 	mov	x2, x3
    4554:	b5ffff81 	cbnz	x1, 4544 <fwp_poll_events+0x54>
    4558:	b7f80ce2 	tbnz	x2, #63, 46f4 <fwp_poll_events+0x204>
    455c:	cb000042 	sub	x2, x2, x0
    4560:	f100005f 	cmp	x2, #0x0
    4564:	540005cd 	b.le	461c <fwp_poll_events+0x12c>
    4568:	d2869b60 	mov	x0, #0x34db                	// #13531
    456c:	d2884801 	mov	x1, #0x4240                	// #16960
    4570:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4574:	f2a001e1 	movk	x1, #0xf, lsl #16
    4578:	f2dbd040 	movk	x0, #0xde82, lsl #32
    457c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4580:	f2e86360 	movk	x0, #0x431b, lsl #48
    4584:	9b407c40 	smulh	x0, x2, x0
    4588:	9352fc00 	asr	x0, x0, #18
    458c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4590:	9b018802 	msub	x2, x0, x1, x2
    4594:	f100005f 	cmp	x2, #0x0
    4598:	9a800400 	cinc	x0, x0, ne	// ne = any
    459c:	eb03001f 	cmp	x0, x3
    45a0:	54000a0c 	b.gt	46e0 <fwp_poll_events+0x1f0>
    45a4:	340003c0 	cbz	w0, 461c <fwp_poll_events+0x12c>
    45a8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45ac:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45b0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45b4:	9ba27c02 	umull	x2, w0, w2
    45b8:	d366fc43 	lsr	x3, x2, #38
    45bc:	aa0303e2 	mov	x2, x3
    45c0:	1b048063 	msub	w3, w3, w4, w0
    45c4:	9b217c63 	smull	x3, w3, w1
    45c8:	d2800001 	mov	x1, #0x0                   	// #0
    45cc:	910023e0 	add	x0, sp, #0x8
    45d0:	a9008fe2 	stp	x2, x3, [sp, #8]
    45d4:	97fff8df 	bl	2950 <nanosleep@plt>
    45d8:	9101c280 	add	x0, x20, #0x70
    45dc:	f9407c13 	ldr	x19, [x0, #248]
    45e0:	97fffce8 	bl	3980 <fwp_now_ns>
    45e4:	aa0003e6 	mov	x6, x0
    45e8:	b50001f3 	cbnz	x19, 4624 <fwp_poll_events+0x134>
    45ec:	d503201f 	nop
    45f0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45f4:	f947f400 	ldr	x0, [x0, #4072]
    45f8:	f9400fe2 	ldr	x2, [sp, #24]
    45fc:	f9400001 	ldr	x1, [x0]
    4600:	eb010042 	subs	x2, x2, x1
    4604:	d2800001 	mov	x1, #0x0                   	// #0
    4608:	540008c1 	b.ne	4720 <fwp_poll_events+0x230>  // b.any
    460c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4610:	a94353f3 	ldp	x19, x20, [sp, #48]
    4614:	910103ff 	add	sp, sp, #0x40
    4618:	d65f03c0 	ret
    461c:	97fffcd9 	bl	3980 <fwp_now_ns>
    4620:	aa0003e6 	mov	x6, x0
    4624:	4f000400 	movi	v0.4s, #0x0
    4628:	9101c288 	add	x8, x20, #0x70
    462c:	52800027 	mov	w7, #0x1                   	// #1
    4630:	f9403661 	ldr	x1, [x19, #104]
    4634:	aa1303e5 	mov	x5, x19
    4638:	f9408a73 	ldr	x19, [x19, #272]
    463c:	eb06003f 	cmp	x1, x6
    4640:	5400032c 	b.gt	46a4 <fwp_poll_events+0x1b4>
    4644:	394154a0 	ldrb	w0, [x5, #85]
    4648:	36000120 	tbz	w0, #0, 466c <fwp_poll_events+0x17c>
    464c:	f94084a0 	ldr	x0, [x5, #264]
    4650:	b40003c0 	cbz	x0, 46c8 <fwp_poll_events+0x1d8>
    4654:	f9008813 	str	x19, [x0, #272]
    4658:	b4000053 	cbz	x19, 4660 <fwp_poll_events+0x170>
    465c:	f9008660 	str	x0, [x19, #264]
    4660:	910800a0 	add	x0, x5, #0x200
    4664:	390154bf 	strb	wzr, [x5, #85]
    4668:	3c908000 	stur	q0, [x0, #-248]
    466c:	f94030a0 	ldr	x0, [x5, #96]
    4670:	390158a7 	strb	w7, [x5, #86]
    4674:	f100001f 	cmp	x0, #0x0
    4678:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    467c:	5400018d 	b.le	46ac <fwp_poll_events+0x1bc>
    4680:	f94028a0 	ldr	x0, [x5, #80]
    4684:	f2001c1f 	tst	x0, #0xff000000ff
    4688:	540000e1 	b.ne	46a4 <fwp_poll_events+0x1b4>  // b.any
    468c:	f9403d00 	ldr	x0, [x8, #120]
    4690:	390150a7 	strb	w7, [x5, #84]
    4694:	f90080bf 	str	xzr, [x5, #256]
    4698:	b40001e0 	cbz	x0, 46d4 <fwp_poll_events+0x1e4>
    469c:	f9003d05 	str	x5, [x8, #120]
    46a0:	f9008005 	str	x5, [x0, #256]
    46a4:	b5fffc73 	cbnz	x19, 4630 <fwp_poll_events+0x140>
    46a8:	17ffffd2 	b	45f0 <fwp_poll_events+0x100>
    46ac:	394144a0 	ldrb	w0, [x5, #81]
    46b0:	3707fe80 	tbnz	w0, #0, 4680 <fwp_poll_events+0x190>
    46b4:	394140a0 	ldrb	w0, [x5, #80]
    46b8:	3707fe40 	tbnz	w0, #0, 4680 <fwp_poll_events+0x190>
    46bc:	aa0503e0 	mov	x0, x5
    46c0:	97fffc0c 	bl	36f0 <fwp_cancel_tree.part.0>
    46c4:	17ffffef 	b	4680 <fwp_poll_events+0x190>
    46c8:	9101c281 	add	x1, x20, #0x70
    46cc:	f9007c33 	str	x19, [x1, #248]
    46d0:	17ffffe2 	b	4658 <fwp_poll_events+0x168>
    46d4:	f9003d05 	str	x5, [x8, #120]
    46d8:	f9004105 	str	x5, [x8, #128]
    46dc:	17fffff2 	b	46a4 <fwp_poll_events+0x1b4>
    46e0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    46e4:	d2989362 	mov	x2, #0xc49b                	// #50331
    46e8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    46ec:	f2a00402 	movk	x2, #0x20, lsl #16
    46f0:	17ffffb6 	b	45c8 <fwp_poll_events+0xd8>
    46f4:	97fffa3f 	bl	2ff0 <fwp_flush>
    46f8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46fc:	f947e863 	ldr	x3, [x3, #4048]
    4700:	d2800562 	mov	x2, #0x2b                  	// #43
    4704:	d2800021 	mov	x1, #0x1                   	// #1
    4708:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    470c:	911f2000 	add	x0, x0, #0x7c8
    4710:	f9400063 	ldr	x3, [x3]
    4714:	97fff89b 	bl	2980 <fwrite@plt>
    4718:	52800ca0 	mov	w0, #0x65                  	// #101
    471c:	97fff805 	bl	2730 <exit@plt>
    4720:	97fff858 	bl	2880 <__stack_chk_fail@plt>

0000000000004724 <fwp_rc_wide_dup>:
    4724:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4728:	910003fd 	mov	x29, sp
    472c:	a90153f3 	stp	x19, x20, [sp, #16]
    4730:	aa0003f3 	mov	x19, x0
    4734:	ca404400 	eor	x0, x0, x0, lsr #17
    4738:	f90013f5 	str	x21, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4740:	ca402400 	eor	x0, x0, x0, lsr #9
    4744:	9117c2a2 	add	x2, x21, #0x5f0
    4748:	92401c00 	and	x0, x0, #0xff
    474c:	910a2403 	add	x3, x0, #0x289
    4750:	8b000c40 	add	x0, x2, x0, lsl #3
    4754:	8b030c54 	add	x20, x2, x3, lsl #3
    4758:	f94a2401 	ldr	x1, [x0, #5192]
    475c:	b50000a1 	cbnz	x1, 4770 <fwp_rc_wide_dup+0x4c>
    4760:	1400002d 	b	4814 <fwp_rc_wide_dup+0xf0>
    4764:	91004034 	add	x20, x1, #0x10
    4768:	f9400821 	ldr	x1, [x1, #16]
    476c:	b4000241 	cbz	x1, 47b4 <fwp_rc_wide_dup+0x90>
    4770:	f9400022 	ldr	x2, [x1]
    4774:	eb02027f 	cmp	x19, x2
    4778:	54ffff61 	b.ne	4764 <fwp_rc_wide_dup+0x40>  // b.any
    477c:	f9400281 	ldr	x1, [x20]
    4780:	39400260 	ldrb	w0, [x19]
    4784:	7103f81f 	cmp	w0, #0xfe
    4788:	54000220 	b.eq	47cc <fwp_rc_wide_dup+0xa8>  // b.none
    478c:	b40001a1 	cbz	x1, 47c0 <fwp_rc_wide_dup+0x9c>
    4790:	f9400420 	ldr	x0, [x1, #8]
    4794:	b100041f 	cmn	x0, #0x1
    4798:	540004a0 	b.eq	482c <fwp_rc_wide_dup+0x108>  // b.none
    479c:	91000400 	add	x0, x0, #0x1
    47a0:	f9000420 	str	x0, [x1, #8]
    47a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47a8:	f94013f5 	ldr	x21, [sp, #32]
    47ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47b0:	d65f03c0 	ret
    47b4:	39400260 	ldrb	w0, [x19]
    47b8:	7103f81f 	cmp	w0, #0xfe
    47bc:	540000a0 	b.eq	47d0 <fwp_rc_wide_dup+0xac>  // b.none
    47c0:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    47c4:	91208000 	add	x0, x0, #0x820
    47c8:	97fffc0e 	bl	3800 <fwp_trap>
    47cc:	b5000281 	cbnz	x1, 481c <fwp_rc_wide_dup+0xf8>
    47d0:	d2800300 	mov	x0, #0x18                  	// #24
    47d4:	97fff813 	bl	2820 <malloc@plt>
    47d8:	b4000280 	cbz	x0, 4828 <fwp_rc_wide_dup+0x104>
    47dc:	d2801fe1 	mov	x1, #0xff                  	// #255
    47e0:	a9000413 	stp	x19, x1, [x0]
    47e4:	9117c2b5 	add	x21, x21, #0x5f0
    47e8:	f900081f 	str	xzr, [x0, #16]
    47ec:	12800001 	mov	w1, #0xffffffff            	// #-1
    47f0:	f9000280 	str	x0, [x20]
    47f4:	39000261 	strb	w1, [x19]
    47f8:	f94e26a0 	ldr	x0, [x21, #7240]
    47fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4800:	91000400 	add	x0, x0, #0x1
    4804:	f90e26a0 	str	x0, [x21, #7240]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4818:	17ffffda 	b	4780 <fwp_rc_wide_dup+0x5c>
    481c:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    4820:	911fe000 	add	x0, x0, #0x7f8
    4824:	97fffbf7 	bl	3800 <fwp_trap>
    4828:	97fffa02 	bl	3030 <fwp_heap_oom>
    482c:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    4830:	91212000 	add	x0, x0, #0x848
    4834:	97fffbf3 	bl	3800 <fwp_trap>
    4838:	d503201f 	nop
    483c:	d503201f 	nop

0000000000004840 <fwp_rc_forget_slot>:
    4840:	aa0003e1 	mov	x1, x0
    4844:	39400000 	ldrb	w0, [x0]
    4848:	7103fc1f 	cmp	w0, #0xff
    484c:	54000040 	b.eq	4854 <fwp_rc_forget_slot+0x14>  // b.none
    4850:	d65f03c0 	ret
    4854:	ca414420 	eor	x0, x1, x1, lsr #17
    4858:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    485c:	ca402400 	eor	x0, x0, x0, lsr #9
    4860:	910003fd 	mov	x29, sp
    4864:	92401c00 	and	x0, x0, #0xff
    4868:	f9000bf3 	str	x19, [sp, #16]
    486c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4870:	9117c262 	add	x2, x19, #0x5f0
    4874:	910a2403 	add	x3, x0, #0x289
    4878:	8b000c40 	add	x0, x2, x0, lsl #3
    487c:	8b030c43 	add	x3, x2, x3, lsl #3
    4880:	f94a2400 	ldr	x0, [x0, #5192]
    4884:	b50000a0 	cbnz	x0, 4898 <fwp_rc_forget_slot+0x58>
    4888:	14000011 	b	48cc <fwp_rc_forget_slot+0x8c>
    488c:	91004003 	add	x3, x0, #0x10
    4890:	f9400800 	ldr	x0, [x0, #16]
    4894:	b40001c0 	cbz	x0, 48cc <fwp_rc_forget_slot+0x8c>
    4898:	f9400002 	ldr	x2, [x0]
    489c:	eb02003f 	cmp	x1, x2
    48a0:	54ffff61 	b.ne	488c <fwp_rc_forget_slot+0x4c>  // b.any
    48a4:	f9400801 	ldr	x1, [x0, #16]
    48a8:	9117c273 	add	x19, x19, #0x5f0
    48ac:	f9000061 	str	x1, [x3]
    48b0:	97fff824 	bl	2940 <free@plt>
    48b4:	f94e2660 	ldr	x0, [x19, #7240]
    48b8:	d1000400 	sub	x0, x0, #0x1
    48bc:	f90e2660 	str	x0, [x19, #7240]
    48c0:	f9400bf3 	ldr	x19, [sp, #16]
    48c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48c8:	d65f03c0 	ret
    48cc:	b0000040 	adrp	x0, d000 <__divti3+0x260>
    48d0:	91208000 	add	x0, x0, #0x820
    48d4:	97fffbcb 	bl	3800 <fwp_trap>
    48d8:	d503201f 	nop
    48dc:	d503201f 	nop

00000000000048e0 <fwp_rc_prepare_chunk>:
    48e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48e4:	910003fd 	mov	x29, sp
    48e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    48ec:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    48f0:	9117c2c2 	add	x2, x22, #0x5f0
    48f4:	b9401c03 	ldr	w3, [x0, #28]
    48f8:	aa0103f5 	mov	x21, x1
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f4 	mov	x20, x0
    4904:	f94e2440 	ldr	x0, [x2, #7240]
    4908:	b4000440 	cbz	x0, 4990 <fwp_rc_prepare_chunk+0xb0>
    490c:	d2800013 	mov	x19, #0x0                   	// #0
    4910:	35000203 	cbnz	w3, 4950 <fwp_rc_prepare_chunk+0x70>
    4914:	b4000361 	cbz	x1, 4980 <fwp_rc_prepare_chunk+0xa0>
    4918:	f9401280 	ldr	x0, [x20, #32]
    491c:	97fff809 	bl	2940 <free@plt>
    4920:	aa1503e0 	mov	x0, x21
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	97fff7ce 	bl	2860 <calloc@plt>
    492c:	f9001280 	str	x0, [x20, #32]
    4930:	b5000460 	cbnz	x0, 49bc <fwp_rc_prepare_chunk+0xdc>
    4934:	97fff9bf 	bl	3030 <fwp_heap_oom>
    4938:	97ffffc2 	bl	4840 <fwp_rc_forget_slot>
    493c:	91000673 	add	x19, x19, #0x1
    4940:	b9401e83 	ldr	w3, [x20, #28]
    4944:	eb13007f 	cmp	x3, x19
    4948:	54000169 	b.ls	4974 <fwp_rc_prepare_chunk+0x94>  // b.plast
    494c:	d503201f 	nop
    4950:	f9401283 	ldr	x3, [x20, #32]
    4954:	8b130060 	add	x0, x3, x19
    4958:	38736863 	ldrb	w3, [x3, x19]
    495c:	7103fc7f 	cmp	w3, #0xff
    4960:	54fffec0 	b.eq	4938 <fwp_rc_prepare_chunk+0x58>  // b.none
    4964:	b9401e83 	ldr	w3, [x20, #28]
    4968:	91000673 	add	x19, x19, #0x1
    496c:	eb13007f 	cmp	x3, x19
    4970:	54ffff08 	b.hi	4950 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4974:	eb0302bf 	cmp	x21, x3
    4978:	54000121 	b.ne	499c <fwp_rc_prepare_chunk+0xbc>  // b.any
    497c:	b5000335 	cbnz	x21, 49e0 <fwp_rc_prepare_chunk+0x100>
    4980:	a94153f3 	ldp	x19, x20, [sp, #16]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	2a0303e3 	mov	w3, w3
    4994:	eb0302bf 	cmp	x21, x3
    4998:	54ffff20 	b.eq	497c <fwp_rc_prepare_chunk+0x9c>  // b.none
    499c:	9117c2c2 	add	x2, x22, #0x5f0
    49a0:	f9401280 	ldr	x0, [x20, #32]
    49a4:	f94e2841 	ldr	x1, [x2, #7248]
    49a8:	cb030021 	sub	x1, x1, x3
    49ac:	f90e2841 	str	x1, [x2, #7248]
    49b0:	97fff7e4 	bl	2940 <free@plt>
    49b4:	b5fffb75 	cbnz	x21, 4920 <fwp_rc_prepare_chunk+0x40>
    49b8:	f900129f 	str	xzr, [x20, #32]
    49bc:	9117c2d6 	add	x22, x22, #0x5f0
    49c0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49c4:	b9001e95 	str	w21, [x20, #28]
    49c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49cc:	8b150000 	add	x0, x0, x21
    49d0:	f90e2ac0 	str	x0, [x22, #7248]
    49d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49dc:	d65f03c0 	ret
    49e0:	f9401280 	ldr	x0, [x20, #32]
    49e4:	aa1503e2 	mov	x2, x21
    49e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49ec:	52800001 	mov	w1, #0x0                   	// #0
    49f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49f8:	17fff796 	b	2850 <memset@plt>
    49fc:	d503201f 	nop

0000000000004a00 <fwp_heap_refill>:
    4a00:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a04:	910003fd 	mov	x29, sp
    4a08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a0c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4a10:	9117c2b5 	add	x21, x21, #0x5f0
    4a14:	aa0003f6 	mov	x22, x0
    4a18:	d2800020 	mov	x0, #0x1                   	// #1
    4a1c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a20:	a90363f7 	stp	x23, x24, [sp, #48]
    4a24:	2a0103f7 	mov	w23, w1
    4a28:	2a0203f8 	mov	w24, w2
    4a2c:	97fffa21 	bl	32b0 <fwp_heap_chunks>
    4a30:	aa0003f3 	mov	x19, x0
    4a34:	f949fea2 	ldr	x2, [x21, #5112]
    4a38:	8b000800 	add	x0, x0, x0, lsl #2
    4a3c:	2a1703e1 	mov	w1, w23
    4a40:	52800025 	mov	w5, #0x1                   	// #1
    4a44:	d37df000 	lsl	x0, x0, #3
    4a48:	910f0021 	add	x1, x1, #0x3c0
    4a4c:	8b000054 	add	x20, x2, x0
    4a50:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a54:	52a00024 	mov	w4, #0x10000               	// #65536
    4a58:	38206845 	strb	w5, [x2, x0]
    4a5c:	aa1403e0 	mov	x0, x20
    4a60:	39000698 	strb	w24, [x20, #1]
    4a64:	39000a97 	strb	w23, [x20, #2]
    4a68:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a6c:	b9000681 	str	w1, [x20, #4]
    4a70:	2a0103e5 	mov	w5, w1
    4a74:	8b0300a2 	add	x2, x5, x3
    4a78:	1ac10881 	udiv	w1, w4, w1
    4a7c:	9ac50842 	udiv	x2, x2, x5
    4a80:	b9000a81 	str	w1, [x20, #8]
    4a84:	92404021 	and	x1, x1, #0x1ffff
    4a88:	b9001a82 	str	w2, [x20, #24]
    4a8c:	97ffff95 	bl	48e0 <fwp_rc_prepare_chunk>
    4a90:	f949daa0 	ldr	x0, [x21, #5040]
    4a94:	29408a81 	ldp	w1, w2, [x20, #4]
    4a98:	8b134000 	add	x0, x0, x19, lsl #16
    4a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aa0:	8b214003 	add	x3, x0, w1, uxtw
    4aa4:	9ba20021 	umaddl	x1, w1, w2, x0
    4aa8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4aac:	a90086c3 	stp	x3, x1, [x22, #8]
    4ab0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ab4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ab8:	d65f03c0 	ret
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_mem_free>:
    4ac0:	b40003c0 	cbz	x0, 4b38 <fwp_mem_free+0x78>
    4ac4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ac8:	910003fd 	mov	x29, sp
    4acc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ad0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4ad4:	9117c2a1 	add	x1, x21, #0x5f0
    4ad8:	a90153f3 	stp	x19, x20, [sp, #16]
    4adc:	aa0003f3 	mov	x19, x0
    4ae0:	f949d823 	ldr	x3, [x1, #5040]
    4ae4:	f949ec22 	ldr	x2, [x1, #5080]
    4ae8:	cb030000 	sub	x0, x0, x3
    4aec:	eb02401f 	cmp	x0, x2, lsl #16
    4af0:	540001c2 	b.cs	4b28 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4af4:	d350fc16 	lsr	x22, x0, #16
    4af8:	a90363f7 	stp	x23, x24, [sp, #48]
    4afc:	f949fc22 	ldr	x2, [x1, #5112]
    4b00:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b04:	d37df294 	lsl	x20, x20, #3
    4b08:	ab140057 	adds	x23, x2, x20
    4b0c:	540000c0 	b.eq	4b24 <fwp_mem_free+0x64>  // b.none
    4b10:	38746842 	ldrb	w2, [x2, x20]
    4b14:	7100045f 	cmp	w2, #0x1
    4b18:	54000120 	b.eq	4b3c <fwp_mem_free+0x7c>  // b.none
    4b1c:	7100085f 	cmp	w2, #0x2
    4b20:	540005e0 	b.eq	4bdc <fwp_mem_free+0x11c>  // b.none
    4b24:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b30:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b34:	d65f03c0 	ret
    4b38:	d65f03c0 	ret
    4b3c:	f94012f8 	ldr	x24, [x23, #32]
    4b40:	b94006e1 	ldr	w1, [x23, #4]
    4b44:	f90023f9 	str	x25, [sp, #64]
    4b48:	2a0103e2 	mov	w2, w1
    4b4c:	394006f9 	ldrb	w25, [x23, #1]
    4b50:	39400af4 	ldrb	w20, [x23, #2]
    4b54:	b4000158 	cbz	x24, 4b7c <fwp_mem_free+0xbc>
    4b58:	92403e76 	and	x22, x19, #0xffff
    4b5c:	9ac20ad6 	udiv	x22, x22, x2
    4b60:	38766b01 	ldrb	w1, [x24, x22]
    4b64:	8b160300 	add	x0, x24, x22
    4b68:	7103fc3f 	cmp	w1, #0xff
    4b6c:	54000980 	b.eq	4c9c <fwp_mem_free+0x1dc>  // b.none
    4b70:	38366b1f 	strb	wzr, [x24, x22]
    4b74:	b94006e1 	ldr	w1, [x23, #4]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b80:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b84:	cb390000 	sub	x0, x0, w25, uxtb
    4b88:	8b340074 	add	x20, x3, w20, uxtb
    4b8c:	9117c2b5 	add	x21, x21, #0x5f0
    4b90:	1e630021 	ucvtf	d1, w1
    4b94:	d37ae400 	lsl	x0, x0, #6
    4b98:	8b140c14 	add	x20, x0, x20, lsl #3
    4b9c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ba0:	f8746aa0 	ldr	x0, [x21, x20]
    4ba4:	f94023f9 	ldr	x25, [sp, #64]
    4ba8:	aa2003e0 	mvn	x0, x0
    4bac:	fd4a22a0 	ldr	d0, [x21, #5184]
    4bb0:	f9000260 	str	x0, [x19]
    4bb4:	f8346ab3 	str	x19, [x21, x20]
    4bb8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bbc:	1e612800 	fadd	d0, d0, d1
    4bc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bc4:	cb020000 	sub	x0, x0, x2
    4bc8:	f90a12a0 	str	x0, [x21, #5152]
    4bcc:	fd0a22a0 	str	d0, [x21, #5184]
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4bd8:	d65f03c0 	ret
    4bdc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4be0:	8b000063 	add	x3, x3, x0
    4be4:	eb03027f 	cmp	x19, x3
    4be8:	54fff9e1 	b.ne	4b24 <fwp_mem_free+0x64>  // b.any
    4bec:	fd400ae1 	ldr	d1, [x23, #16]
    4bf0:	fd4a2020 	ldr	d0, [x1, #5184]
    4bf4:	f9400ae0 	ldr	x0, [x23, #16]
    4bf8:	7e61d821 	ucvtf	d1, d1
    4bfc:	f94a1022 	ldr	x2, [x1, #5152]
    4c00:	f94012f3 	ldr	x19, [x23, #32]
    4c04:	1e612800 	fadd	d0, d0, d1
    4c08:	cb000042 	sub	x2, x2, x0
    4c0c:	f90a1022 	str	x2, [x1, #5152]
    4c10:	fd0a2020 	str	d0, [x1, #5184]
    4c14:	b40000b3 	cbz	x19, 4c28 <fwp_mem_free+0x168>
    4c18:	39400260 	ldrb	w0, [x19]
    4c1c:	7103fc1f 	cmp	w0, #0xff
    4c20:	54000380 	b.eq	4c90 <fwp_mem_free+0x1d0>  // b.none
    4c24:	3900027f 	strb	wzr, [x19]
    4c28:	b9400ee2 	ldr	w2, [x23, #12]
    4c2c:	b4000142 	cbz	x2, 4c54 <fwp_mem_free+0x194>
    4c30:	9117c2a1 	add	x1, x21, #0x5f0
    4c34:	8b160040 	add	x0, x2, x22
    4c38:	8b000800 	add	x0, x0, x0, lsl #2
    4c3c:	f949fc21 	ldr	x1, [x1, #5112]
    4c40:	8b140034 	add	x20, x1, x20
    4c44:	8b000c20 	add	x0, x1, x0, lsl #3
    4c48:	3802869f 	strb	wzr, [x20], #40
    4c4c:	eb00029f 	cmp	x20, x0
    4c50:	54ffffc1 	b.ne	4c48 <fwp_mem_free+0x188>  // b.any
    4c54:	9117c2a0 	add	x0, x21, #0x5f0
    4c58:	f94a1801 	ldr	x1, [x0, #5168]
    4c5c:	f949f803 	ldr	x3, [x0, #5104]
    4c60:	8b020021 	add	x1, x1, x2
    4c64:	f90a1801 	str	x1, [x0, #5168]
    4c68:	eb16007f 	cmp	x3, x22
    4c6c:	54000049 	b.ls	4c74 <fwp_mem_free+0x1b4>  // b.plast
    4c70:	f909f816 	str	x22, [x0, #5104]
    4c74:	9117c2b5 	add	x21, x21, #0x5f0
    4c78:	f949f6a0 	ldr	x0, [x21, #5096]
    4c7c:	eb16001f 	cmp	x0, x22
    4c80:	54fff529 	b.ls	4b24 <fwp_mem_free+0x64>  // b.plast
    4c84:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c88:	f909f6b6 	str	x22, [x21, #5096]
    4c8c:	17ffffa7 	b	4b28 <fwp_mem_free+0x68>
    4c90:	aa1303e0 	mov	x0, x19
    4c94:	97fffeeb 	bl	4840 <fwp_rc_forget_slot>
    4c98:	17ffffe3 	b	4c24 <fwp_mem_free+0x164>
    4c9c:	97fffee9 	bl	4840 <fwp_rc_forget_slot>
    4ca0:	17ffffb4 	b	4b70 <fwp_mem_free+0xb0>

0000000000004ca4 <fwp_heap_alloc_big>:
    4ca4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4ca8:	910003fd 	mov	x29, sp
    4cac:	a90153f3 	stp	x19, x20, [sp, #16]
    4cb0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4cb4:	a90363f7 	stp	x23, x24, [sp, #48]
    4cb8:	aa0003f7 	mov	x23, x0
    4cbc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cc0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cc4:	eb0002ff 	cmp	x23, x0
    4cc8:	54000888 	b.hi	4dd8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4ccc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cd0:	8b0002f4 	add	x20, x23, x0
    4cd4:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xbf0>
    4cd8:	9117c359 	add	x25, x26, #0x5f0
    4cdc:	d350fe94 	lsr	x20, x20, #16
    4ce0:	2a0103f5 	mov	w21, w1
    4ce4:	aa1403e0 	mov	x0, x20
    4ce8:	97fff972 	bl	32b0 <fwp_heap_chunks>
    4cec:	f949ff22 	ldr	x2, [x25, #5112]
    4cf0:	8b000813 	add	x19, x0, x0, lsl #2
    4cf4:	aa0003f8 	mov	x24, x0
    4cf8:	52800043 	mov	w3, #0x2                   	// #2
    4cfc:	d37df273 	lsl	x19, x19, #3
    4d00:	d2800021 	mov	x1, #0x1                   	// #1
    4d04:	8b130040 	add	x0, x2, x19
    4d08:	38336843 	strb	w3, [x2, x19]
    4d0c:	39000415 	strb	w21, [x0, #1]
    4d10:	b9000c14 	str	w20, [x0, #12]
    4d14:	f9000817 	str	x23, [x0, #16]
    4d18:	97fffef2 	bl	48e0 <fwp_rc_prepare_chunk>
    4d1c:	f100069f 	cmp	x20, #0x1
    4d20:	54000269 	b.ls	4d6c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d24:	8b180294 	add	x20, x20, x24
    4d28:	9100a273 	add	x19, x19, #0x28
    4d2c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d30:	5280007b 	mov	w27, #0x3                   	// #3
    4d34:	8b140a94 	add	x20, x20, x20, lsl #2
    4d38:	2a1803fc 	mov	w28, w24
    4d3c:	9adb2296 	lsl	x22, x20, x27
    4d40:	f949ff35 	ldr	x21, [x25, #5112]
    4d44:	d2800001 	mov	x1, #0x0                   	// #0
    4d48:	8b1302b4 	add	x20, x21, x19
    4d4c:	aa1403e0 	mov	x0, x20
    4d50:	97fffee4 	bl	48e0 <fwp_rc_prepare_chunk>
    4d54:	38336abb 	strb	w27, [x21, x19]
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	b9000e9c 	str	w28, [x20, #12]
    4d60:	eb1302df 	cmp	x22, x19
    4d64:	54fffee1 	b.ne	4d40 <fwp_heap_alloc_big+0x9c>  // b.any
    4d68:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d6c:	9117c353 	add	x19, x26, #0x5f0
    4d70:	aa1703e2 	mov	x2, x23
    4d74:	52800001 	mov	w1, #0x0                   	// #0
    4d78:	f949da60 	ldr	x0, [x19, #5040]
    4d7c:	8b184018 	add	x24, x0, x24, lsl #16
    4d80:	aa1803e0 	mov	x0, x24
    4d84:	97fff6b3 	bl	2850 <memset@plt>
    4d88:	f94a1260 	ldr	x0, [x19, #5152]
    4d8c:	ab170000 	adds	x0, x0, x23
    4d90:	54000242 	b.cs	4dd8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d94:	f94a1661 	ldr	x1, [x19, #5160]
    4d98:	f90a1260 	str	x0, [x19, #5152]
    4d9c:	eb01001f 	cmp	x0, x1
    4da0:	54000049 	b.ls	4da8 <fwp_heap_alloc_big+0x104>  // b.plast
    4da4:	f90a1660 	str	x0, [x19, #5160]
    4da8:	9117c35a 	add	x26, x26, #0x5f0
    4dac:	9e6202e0 	scvtf	d0, x23
    4db0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4db4:	aa1803e0 	mov	x0, x24
    4db8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dbc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4dc0:	1e602820 	fadd	d0, d1, d0
    4dc4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dc8:	fd0a1f40 	str	d0, [x26, #5176]
    4dcc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4dd0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4dd4:	d65f03c0 	ret
    4dd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ddc:	97fff895 	bl	3030 <fwp_heap_oom>

0000000000004de0 <fwp_heap_alloc_slow>:
    4de0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4de4:	910003fd 	mov	x29, sp
    4de8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4df0:	9117c262 	add	x2, x19, #0x5f0
    4df4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4df8:	aa0003f5 	mov	x21, x0
    4dfc:	2a0103f4 	mov	w20, w1
    4e00:	b953a440 	ldr	w0, [x2, #5028]
    4e04:	34000600 	cbz	w0, 4ec4 <fwp_heap_alloc_slow+0xe4>
    4e08:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e0c:	54000628 	b.hi	4ed0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e10:	91003ea0 	add	x0, x21, #0xf
    4e14:	9117c262 	add	x2, x19, #0x5f0
    4e18:	f9001bf7 	str	x23, [sp, #48]
    4e1c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e20:	8b401040 	add	x0, x2, x0, lsr #4
    4e24:	cb34c084 	sub	x4, x4, w20, sxtw
    4e28:	d37ae484 	lsl	x4, x4, #6
    4e2c:	397e8003 	ldrb	w3, [x0, #4000]
    4e30:	910f0060 	add	x0, x3, #0x3c0
    4e34:	aa0303e1 	mov	x1, x3
    4e38:	8b030463 	add	x3, x3, x3, lsl #1
    4e3c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e40:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e44:	2a1703f6 	mov	w22, w23
    4e48:	f8636844 	ldr	x4, [x2, x3]
    4e4c:	b40004e4 	cbz	x4, 4ee8 <fwp_heap_alloc_slow+0x108>
    4e50:	f9400080 	ldr	x0, [x4]
    4e54:	aa2003e0 	mvn	x0, x0
    4e58:	f8236840 	str	x0, [x2, x3]
    4e5c:	7100069f 	cmp	w20, #0x1
    4e60:	aa0403e0 	mov	x0, x4
    4e64:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e68:	52800001 	mov	w1, #0x0                   	// #0
    4e6c:	97fff679 	bl	2850 <memset@plt>
    4e70:	aa0003e4 	mov	x4, x0
    4e74:	9117c260 	add	x0, x19, #0x5f0
    4e78:	f94a1001 	ldr	x1, [x0, #5152]
    4e7c:	ab160021 	adds	x1, x1, x22
    4e80:	540005c2 	b.cs	4f38 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e84:	f94a1402 	ldr	x2, [x0, #5160]
    4e88:	f90a1001 	str	x1, [x0, #5152]
    4e8c:	eb02003f 	cmp	x1, x2
    4e90:	54000049 	b.ls	4e98 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e94:	f90a1401 	str	x1, [x0, #5160]
    4e98:	9117c273 	add	x19, x19, #0x5f0
    4e9c:	1e6302e1 	ucvtf	d1, w23
    4ea0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ea4:	aa0403e0 	mov	x0, x4
    4ea8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4eac:	f9401bf7 	ldr	x23, [sp, #48]
    4eb0:	1e612800 	fadd	d0, d0, d1
    4eb4:	fd0a1e60 	str	d0, [x19, #5176]
    4eb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ebc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ec0:	d65f03c0 	ret
    4ec4:	97fffc90 	bl	4104 <fwp_heap_init>
    4ec8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4ecc:	54fffa29 	b.ls	4e10 <fwp_heap_alloc_slow+0x30>  // b.plast
    4ed0:	2a1403e1 	mov	w1, w20
    4ed4:	aa1503e0 	mov	x0, x21
    4ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4edc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ee0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ee4:	17ffff70 	b	4ca4 <fwp_heap_alloc_big>
    4ee8:	8b030042 	add	x2, x2, x3
    4eec:	f9400444 	ldr	x4, [x2, #8]
    4ef0:	b4000104 	cbz	x4, 4f10 <fwp_heap_alloc_slow+0x130>
    4ef4:	f9400840 	ldr	x0, [x2, #16]
    4ef8:	cb040000 	sub	x0, x0, x4
    4efc:	eb16001f 	cmp	x0, x22
    4f00:	54000083 	b.cc	4f10 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f04:	8b160080 	add	x0, x4, x22
    4f08:	f9000440 	str	x0, [x2, #8]
    4f0c:	17ffffd4 	b	4e5c <fwp_heap_alloc_slow+0x7c>
    4f10:	52800302 	mov	w2, #0x18                  	// #24
    4f14:	52807804 	mov	w4, #0x3c0                 	// #960
    4f18:	9117c260 	add	x0, x19, #0x5f0
    4f1c:	9ba27c23 	umull	x3, w1, w2
    4f20:	2a1403e2 	mov	w2, w20
    4f24:	9b240e84 	smaddl	x4, w20, w4, x3
    4f28:	8b040000 	add	x0, x0, x4
    4f2c:	97fffeb5 	bl	4a00 <fwp_heap_refill>
    4f30:	aa0003e4 	mov	x4, x0
    4f34:	17ffffca 	b	4e5c <fwp_heap_alloc_slow+0x7c>
    4f38:	97fff83e 	bl	3030 <fwp_heap_oom>
    4f3c:	d503201f 	nop

0000000000004f40 <fwp_heap_alloc>:
    4f40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f44:	f140101f 	cmp	x0, #0x4, lsl #12
    4f48:	910003fd 	mov	x29, sp
    4f4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f50:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    4f54:	9117c293 	add	x19, x20, #0x5f0
    4f58:	b953a662 	ldr	w2, [x19, #5028]
    4f5c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f60:	54000640 	b.eq	5028 <fwp_heap_alloc+0xe8>  // b.none
    4f64:	91003c03 	add	x3, x0, #0xf
    4f68:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f6c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f70:	8b431263 	add	x3, x19, x3, lsr #4
    4f74:	cb21c042 	sub	x2, x2, w1, sxtw
    4f78:	d37ae442 	lsl	x2, x2, #6
    4f7c:	397e8063 	ldrb	w3, [x3, #4000]
    4f80:	910f0064 	add	x4, x3, #0x3c0
    4f84:	8b030463 	add	x3, x3, x3, lsl #1
    4f88:	8b030c43 	add	x3, x2, x3, lsl #3
    4f8c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f90:	2a1603f5 	mov	w21, w22
    4f94:	f8636a64 	ldr	x4, [x19, x3]
    4f98:	b4000384 	cbz	x4, 5008 <fwp_heap_alloc+0xc8>
    4f9c:	f9400085 	ldr	x5, [x4]
    4fa0:	7100043f 	cmp	w1, #0x1
    4fa4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fa8:	aa0403e0 	mov	x0, x4
    4fac:	aa2503e5 	mvn	x5, x5
    4fb0:	52800001 	mov	w1, #0x0                   	// #0
    4fb4:	f8236a65 	str	x5, [x19, x3]
    4fb8:	97fff626 	bl	2850 <memset@plt>
    4fbc:	aa0003e4 	mov	x4, x0
    4fc0:	f94a1260 	ldr	x0, [x19, #5152]
    4fc4:	ab150000 	adds	x0, x0, x21
    4fc8:	54000442 	b.cs	5050 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4fcc:	f94a1661 	ldr	x1, [x19, #5160]
    4fd0:	f90a1260 	str	x0, [x19, #5152]
    4fd4:	eb01001f 	cmp	x0, x1
    4fd8:	54000049 	b.ls	4fe0 <fwp_heap_alloc+0xa0>  // b.plast
    4fdc:	f90a1660 	str	x0, [x19, #5160]
    4fe0:	9117c294 	add	x20, x20, #0x5f0
    4fe4:	1e6302c1 	ucvtf	d1, w22
    4fe8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fec:	aa0403e0 	mov	x0, x4
    4ff0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ff4:	1e612800 	fadd	d0, d0, d1
    4ff8:	fd0a1e80 	str	d0, [x20, #5176]
    4ffc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5004:	d65f03c0 	ret
    5008:	8b030263 	add	x3, x19, x3
    500c:	f9400464 	ldr	x4, [x3, #8]
    5010:	b40000a4 	cbz	x4, 5024 <fwp_heap_alloc+0xe4>
    5014:	f9400862 	ldr	x2, [x3, #16]
    5018:	cb040042 	sub	x2, x2, x4
    501c:	eb15005f 	cmp	x2, x21
    5020:	540000a2 	b.cs	5034 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5024:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5030:	17ffff6c 	b	4de0 <fwp_heap_alloc_slow>
    5034:	7100043f 	cmp	w1, #0x1
    5038:	8b150085 	add	x5, x4, x21
    503c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5040:	52800001 	mov	w1, #0x0                   	// #0
    5044:	aa0403e0 	mov	x0, x4
    5048:	f9000465 	str	x5, [x3, #8]
    504c:	17ffffdb 	b	4fb8 <fwp_heap_alloc+0x78>
    5050:	97fff7f8 	bl	3030 <fwp_heap_oom>

0000000000005054 <fwp_apply>:
    5054:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5058:	aa0003e6 	mov	x6, x0
    505c:	910003fd 	mov	x29, sp
    5060:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5064:	f947f463 	ldr	x3, [x3, #4072]
    5068:	a90153f3 	stp	x19, x20, [sp, #16]
    506c:	aa0203f4 	mov	x20, x2
    5070:	a9025bf5 	stp	x21, x22, [sp, #32]
    5074:	2a0103f5 	mov	w21, w1
    5078:	52800033 	mov	w19, #0x1                   	// #1
    507c:	a90363f7 	stp	x23, x24, [sp, #48]
    5080:	f00000d7 	adrp	x23, 20000 <__data_start>
    5084:	9101c2f7 	add	x23, x23, #0x70
    5088:	a9046bf9 	stp	x25, x26, [sp, #64]
    508c:	d100c3ff 	sub	sp, sp, #0x30
    5090:	f9400060 	ldr	x0, [x3]
    5094:	f81f83a0 	stur	x0, [x29, #-8]
    5098:	d2800000 	mov	x0, #0x0                   	// #0
    509c:	294058c3 	ldp	w3, w22, [x6]
    50a0:	910003f8 	mov	x24, sp
    50a4:	f94046e0 	ldr	x0, [x23, #136]
    50a8:	710002df 	cmp	w22, #0x0
    50ac:	d37be863 	lsl	x3, x3, #5
    50b0:	8b030007 	add	x7, x0, x3
    50b4:	b8636819 	ldr	w25, [x0, x3]
    50b8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    50bc:	54000163 	b.cc	50e8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    50c0:	f94004e3 	ldr	x3, [x7, #8]
    50c4:	34000bd9 	cbz	w25, 523c <fwp_apply+0x1e8>
    50c8:	aa1403e0 	mov	x0, x20
    50cc:	d63f0060 	blr	x3
    50d0:	aa0003e6 	mov	x6, x0
    50d4:	6b1902bf 	cmp	w21, w25
    50d8:	54000940 	b.eq	5200 <fwp_apply+0x1ac>  // b.none
    50dc:	8b394e94 	add	x20, x20, w25, uxtw #3
    50e0:	4b1902b5 	sub	w21, w21, w25
    50e4:	17ffffee 	b	509c <fwp_apply+0x48>
    50e8:	0b1602ba 	add	w26, w21, w22
    50ec:	6b19035f 	cmp	w26, w25
    50f0:	54000543 	b.cc	5198 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50f4:	7100033f 	cmp	w25, #0x0
    50f8:	4b16033a 	sub	w26, w25, w22
    50fc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    5100:	d37df000 	lsl	x0, x0, #3
    5104:	91003c00 	add	x0, x0, #0xf
    5108:	92704c01 	and	x1, x0, #0xfffff0000
    510c:	927c7c00 	and	x0, x0, #0xffffffff0
    5110:	cb2163e1 	sub	x1, sp, x1
    5114:	eb2163ff 	cmp	sp, x1
    5118:	540000a0 	b.eq	512c <fwp_apply+0xd8>  // b.none
    511c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    5120:	f90203ff 	str	xzr, [sp, #1024]
    5124:	eb2163ff 	cmp	sp, x1
    5128:	54ffffa1 	b.ne	511c <fwp_apply+0xc8>  // b.any
    512c:	92403c00 	and	x0, x0, #0xffff
    5130:	cb2063ff 	sub	sp, sp, x0
    5134:	f90003ff 	str	xzr, [sp]
    5138:	f110001f 	cmp	x0, #0x400
    513c:	54000962 	b.cs	5268 <fwp_apply+0x214>  // b.hs, b.nlast
    5140:	910020c6 	add	x6, x6, #0x8
    5144:	910043e0 	add	x0, sp, #0x10
    5148:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    514c:	d2800003 	mov	x3, #0x0                   	// #0
    5150:	340000f6 	cbz	w22, 516c <fwp_apply+0x118>
    5154:	d503201f 	nop
    5158:	f86368c4 	ldr	x4, [x6, x3]
    515c:	f8236804 	str	x4, [x0, x3]
    5160:	91002063 	add	x3, x3, #0x8
    5164:	eb0300bf 	cmp	x5, x3
    5168:	54ffff81 	b.ne	5158 <fwp_apply+0x104>  // b.any
    516c:	3400013a 	cbz	w26, 5190 <fwp_apply+0x13c>
    5170:	2a1a03e6 	mov	w6, w26
    5174:	d2800003 	mov	x3, #0x0                   	// #0
    5178:	0b0302c4 	add	w4, w22, w3
    517c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5180:	91000463 	add	x3, x3, #0x1
    5184:	f8247805 	str	x5, [x0, x4, lsl #3]
    5188:	eb0300df 	cmp	x6, x3
    518c:	54ffff61 	b.ne	5178 <fwp_apply+0x124>  // b.any
    5190:	f94004e3 	ldr	x3, [x7, #8]
    5194:	1400002c 	b	5244 <fwp_apply+0x1f0>
    5198:	11000740 	add	w0, w26, #0x1
    519c:	52800041 	mov	w1, #0x2                   	// #2
    51a0:	f81e83a6 	stur	x6, [x29, #-24]
    51a4:	d37df000 	lsl	x0, x0, #3
    51a8:	97ffff66 	bl	4f40 <fwp_heap_alloc>
    51ac:	f85e83a6 	ldur	x6, [x29, #-24]
    51b0:	aa0003f3 	mov	x19, x0
    51b4:	b94000c1 	ldr	w1, [x6]
    51b8:	29006801 	stp	w1, w26, [x0]
    51bc:	340000b6 	cbz	w22, 51d0 <fwp_apply+0x17c>
    51c0:	910020c1 	add	x1, x6, #0x8
    51c4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    51c8:	91002000 	add	x0, x0, #0x8
    51cc:	97fff549 	bl	26f0 <memmove@plt>
    51d0:	2a1503e3 	mov	w3, w21
    51d4:	d2800000 	mov	x0, #0x0                   	// #0
    51d8:	34000135 	cbz	w21, 51fc <fwp_apply+0x1a8>
    51dc:	d503201f 	nop
    51e0:	0b0002c1 	add	w1, w22, w0
    51e4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    51e8:	8b010e61 	add	x1, x19, x1, lsl #3
    51ec:	91000400 	add	x0, x0, #0x1
    51f0:	f9000422 	str	x2, [x1, #8]
    51f4:	eb00007f 	cmp	x3, x0
    51f8:	54ffff41 	b.ne	51e0 <fwp_apply+0x18c>  // b.any
    51fc:	aa1303e6 	mov	x6, x19
    5200:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5204:	f947f400 	ldr	x0, [x0, #4072]
    5208:	f85f83a2 	ldur	x2, [x29, #-8]
    520c:	f9400001 	ldr	x1, [x0]
    5210:	eb010042 	subs	x2, x2, x1
    5214:	d2800001 	mov	x1, #0x0                   	// #0
    5218:	540002c1 	b.ne	5270 <fwp_apply+0x21c>  // b.any
    521c:	910003bf 	mov	sp, x29
    5220:	aa0603e0 	mov	x0, x6
    5224:	a94153f3 	ldp	x19, x20, [sp, #16]
    5228:	a9425bf5 	ldp	x21, x22, [sp, #32]
    522c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5230:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5234:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5238:	d65f03c0 	ret
    523c:	d10043a0 	sub	x0, x29, #0x10
    5240:	5280001a 	mov	w26, #0x0                   	// #0
    5244:	d63f0060 	blr	x3
    5248:	aa0003e6 	mov	x6, x0
    524c:	6b1a02bf 	cmp	w21, w26
    5250:	54fffd80 	b.eq	5200 <fwp_apply+0x1ac>  // b.none
    5254:	0b1602b6 	add	w22, w21, w22
    5258:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    525c:	4b1902d5 	sub	w21, w22, w25
    5260:	9100031f 	mov	sp, x24
    5264:	17ffff8e 	b	509c <fwp_apply+0x48>
    5268:	f90203ff 	str	xzr, [sp, #1024]
    526c:	17ffffb5 	b	5140 <fwp_apply+0xec>
    5270:	97fff584 	bl	2880 <__stack_chk_fail@plt>

0000000000005274 <fwp_p_ad_push>:
    5274:	f100001f 	cmp	x0, #0x0
    5278:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    527c:	54000e8b 	b.lt	544c <fwp_p_ad_push+0x1d8>  // b.tstop
    5280:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5284:	aa0003e4 	mov	x4, x0
    5288:	910003fd 	mov	x29, sp
    528c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5290:	aa0003f5 	mov	x21, x0
    5294:	aa020000 	orr	x0, x0, x2
    5298:	a90363f7 	stp	x23, x24, [sp, #48]
    529c:	aa0203f7 	mov	x23, x2
    52a0:	6d0627e8 	stp	d8, d9, [sp, #96]
    52a4:	9e670029 	fmov	d9, x1
    52a8:	9e670068 	fmov	d8, x3
    52ac:	b6f80900 	tbz	x0, #63, 53cc <fwp_p_ad_push+0x158>
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	9360fc80 	asr	x0, x4, #32
    52b8:	b6f800c4 	tbz	x4, #63, 52d0 <fwp_p_ad_push+0x5c>
    52bc:	1e604109 	fmov	d9, d8
    52c0:	2f00e408 	movi	d8, #0x0
    52c4:	9360fc40 	asr	x0, x2, #32
    52c8:	aa0203f5 	mov	x21, x2
    52cc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    52d0:	97fffa18 	bl	3b30 <fwp_tape_of>
    52d4:	aa0003f3 	mov	x19, x0
    52d8:	f9403000 	ldr	x0, [x0, #96]
    52dc:	b5001280 	cbnz	x0, 552c <fwp_p_ad_push+0x2b8>
    52e0:	f9400a76 	ldr	x22, [x19, #16]
    52e4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    52e8:	eb0002df 	cmp	x22, x0
    52ec:	54000e2c 	b.gt	54b0 <fwp_p_ad_push+0x23c>
    52f0:	eb3542df 	cmp	x22, w21, uxtw
    52f4:	54000d4d 	b.le	549c <fwp_p_ad_push+0x228>
    52f8:	b7f80077 	tbnz	x23, #63, 5304 <fwp_p_ad_push+0x90>
    52fc:	eb3742df 	cmp	x22, w23, uxtw
    5300:	54000ced 	b.le	549c <fwp_p_ad_push+0x228>
    5304:	f9400678 	ldr	x24, [x19, #8]
    5308:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    530c:	cb1802d8 	sub	x24, x22, x24
    5310:	91000701 	add	x1, x24, #0x1
    5314:	eb00003f 	cmp	x1, x0
    5318:	54000cc8 	b.hi	54b0 <fwp_p_ad_push+0x23c>  // b.pmore
    531c:	a9418274 	ldp	x20, x0, [x19, #24]
    5320:	a90573fb 	stp	x27, x28, [sp, #80]
    5324:	eb14003f 	cmp	x1, x20
    5328:	5400068d 	b.le	53f8 <fwp_p_ad_push+0x184>
    532c:	f100029f 	cmp	x20, #0x0
    5330:	d2800803 	mov	x3, #0x40                  	// #64
    5334:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5338:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    533c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5340:	eb14003f 	cmp	x1, x20
    5344:	5400008d 	b.le	5354 <fwp_p_ad_push+0xe0>
    5348:	eb02029f 	cmp	x20, x2
    534c:	5400052d 	b.le	53f0 <fwp_p_ad_push+0x17c>
    5350:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5354:	d37df299 	lsl	x25, x20, #3
    5358:	aa1903e1 	mov	x1, x25
    535c:	97fff545 	bl	2870 <realloc@plt>
    5360:	aa0003e1 	mov	x1, x0
    5364:	b4000b00 	cbz	x0, 54c4 <fwp_p_ad_push+0x250>
    5368:	f9400e62 	ldr	x2, [x19, #24]
    536c:	f9001261 	str	x1, [x19, #32]
    5370:	f9401a60 	ldr	x0, [x19, #48]
    5374:	d37cee9a 	lsl	x26, x20, #4
    5378:	8b020821 	add	x1, x1, x2, lsl #2
    537c:	f9001661 	str	x1, [x19, #40]
    5380:	aa1a03e1 	mov	x1, x26
    5384:	97fff53b 	bl	2870 <realloc@plt>
    5388:	aa0003e2 	mov	x2, x0
    538c:	b40009c0 	cbz	x0, 54c4 <fwp_p_ad_push+0x250>
    5390:	f9400e61 	ldr	x1, [x19, #24]
    5394:	d37df31b 	lsl	x27, x24, #3
    5398:	d37ef685 	lsl	x5, x20, #2
    539c:	d37ef71c 	lsl	x28, x24, #2
    53a0:	8b190004 	add	x4, x0, x25
    53a4:	8b010c01 	add	x1, x0, x1, lsl #3
    53a8:	a9030660 	stp	x0, x1, [x19, #48]
    53ac:	b5000558 	cbnz	x24, 5454 <fwp_p_ad_push+0x1e0>
    53b0:	f9001e64 	str	x4, [x19, #56]
    53b4:	f9401260 	ldr	x0, [x19, #32]
    53b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53bc:	8b050001 	add	x1, x0, x5
    53c0:	f9000e74 	str	x20, [x19, #24]
    53c4:	f9001661 	str	x1, [x19, #40]
    53c8:	14000010 	b	5408 <fwp_p_ad_push+0x194>
    53cc:	9360fc40 	asr	x0, x2, #32
    53d0:	a90153f3 	stp	x19, x20, [sp, #16]
    53d4:	eb84801f 	cmp	x0, x4, asr #32
    53d8:	54fff7c0 	b.eq	52d0 <fwp_p_ad_push+0x5c>  // b.none
    53dc:	90000040 	adrp	x0, d000 <__divti3+0x260>
    53e0:	9121a000 	add	x0, x0, #0x868
    53e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53e8:	a90573fb 	stp	x27, x28, [sp, #80]
    53ec:	97fff905 	bl	3800 <fwp_trap>
    53f0:	d37ffa94 	lsl	x20, x20, #1
    53f4:	17ffffd3 	b	5340 <fwp_p_ad_push+0xcc>
    53f8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53fc:	d37ef71c 	lsl	x28, x24, #2
    5400:	f9401e64 	ldr	x4, [x19, #56]
    5404:	d37df31b 	lsl	x27, x24, #3
    5408:	b83c6815 	str	w21, [x0, x28]
    540c:	f10002ff 	cmp	x23, #0x0
    5410:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5414:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5418:	fc3b6849 	str	d9, [x2, x27]
    541c:	aa1602a0 	orr	x0, x21, x22
    5420:	b83c6837 	str	w23, [x1, x28]
    5424:	910006d6 	add	x22, x22, #0x1
    5428:	a94363f7 	ldp	x23, x24, [sp, #48]
    542c:	fc3b6888 	str	d8, [x4, x27]
    5430:	a94573fb 	ldp	x27, x28, [sp, #80]
    5434:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5438:	f9000a76 	str	x22, [x19, #16]
    543c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5444:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5448:	d65f03c0 	ret
    544c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5450:	d65f03c0 	ret
    5454:	eb1a033f 	cmp	x25, x26
    5458:	aa0403e0 	mov	x0, x4
    545c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5460:	aa1b03e2 	mov	x2, x27
    5464:	cb190063 	sub	x3, x3, x25
    5468:	f9003fe5 	str	x5, [sp, #120]
    546c:	97fff56d 	bl	2a20 <__memmove_chk@plt>
    5470:	a9420660 	ldp	x0, x1, [x19, #32]
    5474:	aa1c03e2 	mov	x2, x28
    5478:	f9401a63 	ldr	x3, [x19, #48]
    547c:	f9403fe5 	ldr	x5, [sp, #120]
    5480:	8b190063 	add	x3, x3, x25
    5484:	f9001e63 	str	x3, [x19, #56]
    5488:	8b050000 	add	x0, x0, x5
    548c:	97fff499 	bl	26f0 <memmove@plt>
    5490:	a9431262 	ldp	x2, x4, [x19, #48]
    5494:	f9403fe5 	ldr	x5, [sp, #120]
    5498:	17ffffc7 	b	53b4 <fwp_p_ad_push+0x140>
    549c:	90000040 	adrp	x0, d000 <__divti3+0x260>
    54a0:	91240000 	add	x0, x0, #0x900
    54a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54a8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ac:	97fff8d5 	bl	3800 <fwp_trap>
    54b0:	90000040 	adrp	x0, d000 <__divti3+0x260>
    54b4:	91238000 	add	x0, x0, #0x8e0
    54b8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	97fff8d0 	bl	3800 <fwp_trap>
    54c4:	aa1303e0 	mov	x0, x19
    54c8:	97fff6b2 	bl	2f90 <fwp_tape_unlink_scope>
    54cc:	f9401260 	ldr	x0, [x19, #32]
    54d0:	97fff51c 	bl	2940 <free@plt>
    54d4:	f9401a60 	ldr	x0, [x19, #48]
    54d8:	97fff51a 	bl	2940 <free@plt>
    54dc:	f9402260 	ldr	x0, [x19, #64]
    54e0:	97fff518 	bl	2940 <free@plt>
    54e4:	f9000e7f 	str	xzr, [x19, #24]
    54e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    54ec:	f947e821 	ldr	x1, [x1, #4048]
    54f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54f4:	d2800262 	mov	x2, #0x13                  	// #19
    54f8:	4f000400 	movi	v0.4s, #0x0
    54fc:	90000040 	adrp	x0, d000 <__divti3+0x260>
    5500:	f9400023 	ldr	x3, [x1]
    5504:	b900067f 	str	wzr, [x19, #4]
    5508:	d2800021 	mov	x1, #0x1                   	// #1
    550c:	91132000 	add	x0, x0, #0x4c8
    5510:	3c808260 	stur	q0, [x19, #8]
    5514:	ad010260 	stp	q0, q0, [x19, #32]
    5518:	97fff51a 	bl	2980 <fwrite@plt>
    551c:	d2800000 	mov	x0, #0x0                   	// #0
    5520:	97fff524 	bl	29b0 <fflush@plt>
    5524:	52800cc0 	mov	w0, #0x66                  	// #102
    5528:	97fff532 	bl	29f0 <_Exit@plt>
    552c:	90000040 	adrp	x0, d000 <__divti3+0x260>
    5530:	9122c000 	add	x0, x0, #0x8b0
    5534:	a9046bf9 	stp	x25, x26, [sp, #64]
    5538:	a90573fb 	stp	x27, x28, [sp, #80]
    553c:	97fff8b1 	bl	3800 <fwp_trap>

0000000000005540 <w107>:
    5540:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5544:	9e660003 	fmov	x3, d0
    5548:	aa0003e2 	mov	x2, x0
    554c:	910003fd 	mov	x29, sp
    5550:	fd001fea 	str	d10, [sp, #56]
    5554:	1e60400a 	fmov	d10, d0
    5558:	6d0427e8 	stp	d8, d9, [sp, #64]
    555c:	1e604028 	fmov	d8, d1
    5560:	1e600809 	fmul	d9, d0, d0
    5564:	a90153f3 	stp	x19, x20, [sp, #16]
    5568:	aa0103f4 	mov	x20, x1
    556c:	aa0303e1 	mov	x1, x3
    5570:	aa0003f3 	mov	x19, x0
    5574:	a9025bf5 	stp	x21, x22, [sp, #32]
    5578:	f9001bf7 	str	x23, [sp, #48]
    557c:	97ffff3e 	bl	5274 <fwp_p_ad_push>
    5580:	aa0003e5 	mov	x5, x0
    5584:	97fffb50 	bl	42c4 <caf61>
    5588:	9e670000 	fmov	d0, x0
    558c:	97fffb4e 	bl	42c4 <caf61>
    5590:	1e693908 	fsub	d8, d8, d9
    5594:	aa1403e2 	mov	x2, x20
    5598:	1e614000 	fneg	d0, d0
    559c:	aa0003e3 	mov	x3, x0
    55a0:	aa0503e0 	mov	x0, x5
    55a4:	9e660117 	fmov	x23, d8
    55a8:	9e660001 	fmov	x1, d0
    55ac:	97ffff32 	bl	5274 <fwp_p_ad_push>
    55b0:	aa0003f5 	mov	x21, x0
    55b4:	97fffb44 	bl	42c4 <caf61>
    55b8:	9e670000 	fmov	d0, x0
    55bc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    55c0:	97fffb41 	bl	42c4 <caf61>
    55c4:	1e614000 	fneg	d0, d0
    55c8:	aa0003e3 	mov	x3, x0
    55cc:	1e6a3929 	fsub	d9, d9, d10
    55d0:	aa1303e0 	mov	x0, x19
    55d4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    55d8:	9e660001 	fmov	x1, d0
    55dc:	9e660136 	fmov	x22, d9
    55e0:	97ffff25 	bl	5274 <fwp_p_ad_push>
    55e4:	1e680908 	fmul	d8, d8, d8
    55e8:	aa0003f4 	mov	x20, x0
    55ec:	aa1703e3 	mov	x3, x23
    55f0:	aa1703e1 	mov	x1, x23
    55f4:	aa1503e2 	mov	x2, x21
    55f8:	aa1503e0 	mov	x0, x21
    55fc:	97ffff1e 	bl	5274 <fwp_p_ad_push>
    5600:	aa0003e2 	mov	x2, x0
    5604:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5608:	9e670020 	fmov	d0, x1
    560c:	9e660101 	fmov	x1, d8
    5610:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5614:	1e600908 	fmul	d8, d8, d0
    5618:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    561c:	97ffff16 	bl	5274 <fwp_p_ad_push>
    5620:	1e690929 	fmul	d9, d9, d9
    5624:	aa1603e3 	mov	x3, x22
    5628:	aa1603e1 	mov	x1, x22
    562c:	aa1403e2 	mov	x2, x20
    5630:	aa0003f3 	mov	x19, x0
    5634:	aa1403e0 	mov	x0, x20
    5638:	97ffff0f 	bl	5274 <fwp_p_ad_push>
    563c:	aa0003e5 	mov	x5, x0
    5640:	97fffb21 	bl	42c4 <caf61>
    5644:	aa0003e6 	mov	x6, x0
    5648:	97fffb1f 	bl	42c4 <caf61>
    564c:	1e692908 	fadd	d8, d8, d9
    5650:	aa1303e2 	mov	x2, x19
    5654:	aa0603e1 	mov	x1, x6
    5658:	aa0003e3 	mov	x3, x0
    565c:	aa0503e0 	mov	x0, x5
    5660:	97ffff05 	bl	5274 <fwp_p_ad_push>
    5664:	aa0003e1 	mov	x1, x0
    5668:	a94153f3 	ldp	x19, x20, [sp, #16]
    566c:	9e660100 	fmov	x0, d8
    5670:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5674:	f9401bf7 	ldr	x23, [sp, #48]
    5678:	fd401fea 	ldr	d10, [sp, #56]
    567c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5680:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5684:	d65f03c0 	ret
    5688:	d503201f 	nop
    568c:	d503201f 	nop

0000000000005690 <w164.constprop.0>:
    5690:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5694:	910003fd 	mov	x29, sp
    5698:	a9025bf5 	stp	x21, x22, [sp, #32]
    569c:	fd001be8 	str	d8, [sp, #48]
    56a0:	f9400015 	ldr	x21, [x0]
    56a4:	b40003b5 	cbz	x21, 5718 <w164.constprop.0+0x88>
    56a8:	2f00e408 	movi	d8, #0x0
    56ac:	91002016 	add	x22, x0, #0x8
    56b0:	a90153f3 	stp	x19, x20, [sp, #16]
    56b4:	91004014 	add	x20, x0, #0x10
    56b8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    56bc:	d2800013 	mov	x19, #0x0                   	// #0
    56c0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    56c4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    56c8:	97fffaff 	bl	42c4 <caf61>
    56cc:	aa0003e6 	mov	x6, x0
    56d0:	97fffafd 	bl	42c4 <caf61>
    56d4:	1e602908 	fadd	d8, d8, d0
    56d8:	aa0003e3 	mov	x3, x0
    56dc:	aa0703e2 	mov	x2, x7
    56e0:	aa0503e0 	mov	x0, x5
    56e4:	aa0603e1 	mov	x1, x6
    56e8:	91000a73 	add	x19, x19, #0x2
    56ec:	97fffee2 	bl	5274 <fwp_p_ad_push>
    56f0:	aa0003e5 	mov	x5, x0
    56f4:	eb1302bf 	cmp	x21, x19
    56f8:	54fffe48 	b.hi	56c0 <w164.constprop.0+0x30>  // b.pmore
    56fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5700:	9e660100 	fmov	x0, d8
    5704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5708:	aa0503e1 	mov	x1, x5
    570c:	fd401be8 	ldr	d8, [sp, #48]
    5710:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5714:	d65f03c0 	ret
    5718:	2f00e408 	movi	d8, #0x0
    571c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5724:	aa0503e1 	mov	x1, x5
    5728:	9e660100 	fmov	x0, d8
    572c:	fd401be8 	ldr	d8, [sp, #48]
    5730:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5734:	d65f03c0 	ret
    5738:	d503201f 	nop
    573c:	d503201f 	nop

0000000000005740 <fwp_data.part.0.constprop.0>:
    5740:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5744:	910003fd 	mov	x29, sp
    5748:	a90153f3 	stp	x19, x20, [sp, #16]
    574c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    5750:	9117c283 	add	x3, x20, #0x5f0
    5754:	a9025bf5 	stp	x21, x22, [sp, #32]
    5758:	aa0103f5 	mov	x21, x1
    575c:	b953a461 	ldr	w1, [x3, #5028]
    5760:	a90363f7 	stp	x23, x24, [sp, #48]
    5764:	2a0003f8 	mov	w24, w0
    5768:	34000701 	cbz	w1, 5848 <fwp_data.part.0.constprop.0+0x108>
    576c:	397e8862 	ldrb	w2, [x3, #4002]
    5770:	910f0040 	add	x0, x2, #0x3c0
    5774:	8b020442 	add	x2, x2, x2, lsl #1
    5778:	d37df042 	lsl	x2, x2, #3
    577c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5780:	2a1703f6 	mov	w22, w23
    5784:	f8626873 	ldr	x19, [x3, x2]
    5788:	b40004d3 	cbz	x19, 5820 <fwp_data.part.0.constprop.0+0xe0>
    578c:	f9400260 	ldr	x0, [x19]
    5790:	aa2003e0 	mvn	x0, x0
    5794:	f8226860 	str	x0, [x3, x2]
    5798:	f10062df 	cmp	x22, #0x18
    579c:	540000e9 	b.ls	57b8 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    57a0:	d10066c2 	sub	x2, x22, #0x19
    57a4:	91006260 	add	x0, x19, #0x18
    57a8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    57ac:	52800001 	mov	w1, #0x0                   	// #0
    57b0:	91002042 	add	x2, x2, #0x8
    57b4:	97fff427 	bl	2850 <memset@plt>
    57b8:	9117c282 	add	x2, x20, #0x5f0
    57bc:	f94a1041 	ldr	x1, [x2, #5152]
    57c0:	ab160021 	adds	x1, x1, x22
    57c4:	540004c2 	b.cs	585c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    57c8:	f94a1440 	ldr	x0, [x2, #5160]
    57cc:	f90a1041 	str	x1, [x2, #5152]
    57d0:	eb00003f 	cmp	x1, x0
    57d4:	54000049 	b.ls	57dc <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    57d8:	f90a1441 	str	x1, [x2, #5160]
    57dc:	9117c294 	add	x20, x20, #0x5f0
    57e0:	1e6302e1 	ucvtf	d1, w23
    57e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    57e8:	1e612800 	fadd	d0, d0, d1
    57ec:	fd0a1e80 	str	d0, [x20, #5176]
    57f0:	52800041 	mov	w1, #0x2                   	// #2
    57f4:	29000678 	stp	w24, w1, [x19]
    57f8:	aa1303e0 	mov	x0, x19
    57fc:	f94002a1 	ldr	x1, [x21]
    5800:	f9000661 	str	x1, [x19, #8]
    5804:	f94006a1 	ldr	x1, [x21, #8]
    5808:	f9000a61 	str	x1, [x19, #16]
    580c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5810:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5814:	a94363f7 	ldp	x23, x24, [sp, #48]
    5818:	a8c47bfd 	ldp	x29, x30, [sp], #64
    581c:	d65f03c0 	ret
    5820:	8b020063 	add	x3, x3, x2
    5824:	f9400473 	ldr	x19, [x3, #8]
    5828:	b4000113 	cbz	x19, 5848 <fwp_data.part.0.constprop.0+0x108>
    582c:	f9400860 	ldr	x0, [x3, #16]
    5830:	cb130000 	sub	x0, x0, x19
    5834:	eb0002df 	cmp	x22, x0
    5838:	54000088 	b.hi	5848 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    583c:	8b160260 	add	x0, x19, x22
    5840:	f9000460 	str	x0, [x3, #8]
    5844:	17ffffd5 	b	5798 <fwp_data.part.0.constprop.0+0x58>
    5848:	52800001 	mov	w1, #0x0                   	// #0
    584c:	d2800300 	mov	x0, #0x18                  	// #24
    5850:	97fffdbc 	bl	4f40 <fwp_heap_alloc>
    5854:	aa0003f3 	mov	x19, x0
    5858:	17ffffe6 	b	57f0 <fwp_data.part.0.constprop.0+0xb0>
    585c:	97fff5f5 	bl	3030 <fwp_heap_oom>

0000000000005860 <fwp_rc_share>:
    5860:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    5864:	9117c042 	add	x2, x2, #0x5f0
    5868:	f949d843 	ldr	x3, [x2, #5040]
    586c:	f949ec41 	ldr	x1, [x2, #5080]
    5870:	cb030000 	sub	x0, x0, x3
    5874:	eb01401f 	cmp	x0, x1, lsl #16
    5878:	540002c2 	b.cs	58d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    587c:	d350fc01 	lsr	x1, x0, #16
    5880:	f949fc44 	ldr	x4, [x2, #5112]
    5884:	8b010821 	add	x1, x1, x1, lsl #2
    5888:	d37df021 	lsl	x1, x1, #3
    588c:	8b010083 	add	x3, x4, x1
    5890:	f9401062 	ldr	x2, [x3, #32]
    5894:	b40001e2 	cbz	x2, 58d0 <fwp_rc_share+0x70>
    5898:	38616881 	ldrb	w1, [x4, x1]
    589c:	7100083f 	cmp	w1, #0x2
    58a0:	540001a0 	b.eq	58d4 <fwp_rc_share+0x74>  // b.none
    58a4:	7100043f 	cmp	w1, #0x1
    58a8:	54000141 	b.ne	58d0 <fwp_rc_share+0x70>  // b.any
    58ac:	29430464 	ldp	w4, w1, [x3, #24]
    58b0:	92403c00 	and	x0, x0, #0xffff
    58b4:	9b047c00 	mul	x0, x0, x4
    58b8:	d360fc00 	lsr	x0, x0, #32
    58bc:	eb01001f 	cmp	x0, x1
    58c0:	54000082 	b.cs	58d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    58c4:	8b000042 	add	x2, x2, x0
    58c8:	39400040 	ldrb	w0, [x2]
    58cc:	350000a0 	cbnz	w0, 58e0 <fwp_rc_share+0x80>
    58d0:	d65f03c0 	ret
    58d4:	72003c1f 	tst	w0, #0xffff
    58d8:	54ffff80 	b.eq	58c8 <fwp_rc_share+0x68>  // b.none
    58dc:	d65f03c0 	ret
    58e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    58e4:	90000040 	adrp	x0, d000 <__divti3+0x260>
    58e8:	91248000 	add	x0, x0, #0x920
    58ec:	910003fd 	mov	x29, sp
    58f0:	97fff7c4 	bl	3800 <fwp_trap>

00000000000058f4 <fwp_rc_fresh>:
    58f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    58f8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    58fc:	9117c063 	add	x3, x3, #0x5f0
    5900:	910003fd 	mov	x29, sp
    5904:	a90153f3 	stp	x19, x20, [sp, #16]
    5908:	aa0003f3 	mov	x19, x0
    590c:	f949d861 	ldr	x1, [x3, #5040]
    5910:	f949ec60 	ldr	x0, [x3, #5080]
    5914:	cb010261 	sub	x1, x19, x1
    5918:	eb00403f 	cmp	x1, x0, lsl #16
    591c:	54000322 	b.cs	5980 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5920:	d350fc22 	lsr	x2, x1, #16
    5924:	f949fc63 	ldr	x3, [x3, #5112]
    5928:	8b020842 	add	x2, x2, x2, lsl #2
    592c:	d37df042 	lsl	x2, x2, #3
    5930:	8b020060 	add	x0, x3, x2
    5934:	f9401014 	ldr	x20, [x0, #32]
    5938:	b4000254 	cbz	x20, 5980 <fwp_rc_fresh+0x8c>
    593c:	38626862 	ldrb	w2, [x3, x2]
    5940:	7100085f 	cmp	w2, #0x2
    5944:	54000260 	b.eq	5990 <fwp_rc_fresh+0x9c>  // b.none
    5948:	7100045f 	cmp	w2, #0x1
    594c:	540001a1 	b.ne	5980 <fwp_rc_fresh+0x8c>  // b.any
    5950:	29430002 	ldp	w2, w0, [x0, #24]
    5954:	92403c21 	and	x1, x1, #0xffff
    5958:	9b027c21 	mul	x1, x1, x2
    595c:	d360fc21 	lsr	x1, x1, #32
    5960:	eb00003f 	cmp	x1, x0
    5964:	540000e2 	b.cs	5980 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5968:	8b010294 	add	x20, x20, x1
    596c:	39400280 	ldrb	w0, [x20]
    5970:	7103fc1f 	cmp	w0, #0xff
    5974:	540001a0 	b.eq	59a8 <fwp_rc_fresh+0xb4>  // b.none
    5978:	52800020 	mov	w0, #0x1                   	// #1
    597c:	39000280 	strb	w0, [x20]
    5980:	aa1303e0 	mov	x0, x19
    5984:	a94153f3 	ldp	x19, x20, [sp, #16]
    5988:	a8c27bfd 	ldp	x29, x30, [sp], #32
    598c:	d65f03c0 	ret
    5990:	72003c3f 	tst	w1, #0xffff
    5994:	54fffec0 	b.eq	596c <fwp_rc_fresh+0x78>  // b.none
    5998:	aa1303e0 	mov	x0, x19
    599c:	a94153f3 	ldp	x19, x20, [sp, #16]
    59a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59a4:	d65f03c0 	ret
    59a8:	aa1403e0 	mov	x0, x20
    59ac:	97fffba5 	bl	4840 <fwp_rc_forget_slot>
    59b0:	17fffff2 	b	5978 <fwp_rc_fresh+0x84>

00000000000059b4 <fwp_rc_free_arr>:
    59b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    59b8:	9117c063 	add	x3, x3, #0x5f0
    59bc:	f949d861 	ldr	x1, [x3, #5040]
    59c0:	f949ec62 	ldr	x2, [x3, #5080]
    59c4:	cb010001 	sub	x1, x0, x1
    59c8:	eb02403f 	cmp	x1, x2, lsl #16
    59cc:	54000342 	b.cs	5a34 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59d0:	d350fc22 	lsr	x2, x1, #16
    59d4:	f949fc65 	ldr	x5, [x3, #5112]
    59d8:	8b020842 	add	x2, x2, x2, lsl #2
    59dc:	d37df042 	lsl	x2, x2, #3
    59e0:	8b0200a4 	add	x4, x5, x2
    59e4:	f9401083 	ldr	x3, [x4, #32]
    59e8:	b4000263 	cbz	x3, 5a34 <fwp_rc_free_arr+0x80>
    59ec:	386268a2 	ldrb	w2, [x5, x2]
    59f0:	7100085f 	cmp	w2, #0x2
    59f4:	540001c0 	b.eq	5a2c <fwp_rc_free_arr+0x78>  // b.none
    59f8:	7100045f 	cmp	w2, #0x1
    59fc:	540001c1 	b.ne	5a34 <fwp_rc_free_arr+0x80>  // b.any
    5a00:	29430885 	ldp	w5, w2, [x4, #24]
    5a04:	92403c21 	and	x1, x1, #0xffff
    5a08:	9b057c21 	mul	x1, x1, x5
    5a0c:	d360fc21 	lsr	x1, x1, #32
    5a10:	eb02003f 	cmp	x1, x2
    5a14:	54000102 	b.cs	5a34 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a18:	8b010063 	add	x3, x3, x1
    5a1c:	39400061 	ldrb	w1, [x3]
    5a20:	7100043f 	cmp	w1, #0x1
    5a24:	54000081 	b.ne	5a34 <fwp_rc_free_arr+0x80>  // b.any
    5a28:	17fffc26 	b	4ac0 <fwp_mem_free>
    5a2c:	72003c3f 	tst	w1, #0xffff
    5a30:	54ffff60 	b.eq	5a1c <fwp_rc_free_arr+0x68>  // b.none
    5a34:	d65f03c0 	ret
    5a38:	d503201f 	nop
    5a3c:	d503201f 	nop

0000000000005a40 <fwp_rc_dup>:
    5a40:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    5a44:	9117c042 	add	x2, x2, #0x5f0
    5a48:	f949d841 	ldr	x1, [x2, #5040]
    5a4c:	f949ec43 	ldr	x3, [x2, #5080]
    5a50:	cb010001 	sub	x1, x0, x1
    5a54:	eb03403f 	cmp	x1, x3, lsl #16
    5a58:	54000342 	b.cs	5ac0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a5c:	d350fc20 	lsr	x0, x1, #16
    5a60:	f949fc44 	ldr	x4, [x2, #5112]
    5a64:	8b000800 	add	x0, x0, x0, lsl #2
    5a68:	d37df002 	lsl	x2, x0, #3
    5a6c:	8b020083 	add	x3, x4, x2
    5a70:	f9401060 	ldr	x0, [x3, #32]
    5a74:	b4000260 	cbz	x0, 5ac0 <fwp_rc_dup+0x80>
    5a78:	38626882 	ldrb	w2, [x4, x2]
    5a7c:	7100085f 	cmp	w2, #0x2
    5a80:	54000220 	b.eq	5ac4 <fwp_rc_dup+0x84>  // b.none
    5a84:	7100045f 	cmp	w2, #0x1
    5a88:	540001c1 	b.ne	5ac0 <fwp_rc_dup+0x80>  // b.any
    5a8c:	29430864 	ldp	w4, w2, [x3, #24]
    5a90:	92403c21 	and	x1, x1, #0xffff
    5a94:	9b047c21 	mul	x1, x1, x4
    5a98:	d360fc21 	lsr	x1, x1, #32
    5a9c:	eb02003f 	cmp	x1, x2
    5aa0:	54000102 	b.cs	5ac0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5aa4:	8b010000 	add	x0, x0, x1
    5aa8:	39400001 	ldrb	w1, [x0]
    5aac:	340000a1 	cbz	w1, 5ac0 <fwp_rc_dup+0x80>
    5ab0:	7103f43f 	cmp	w1, #0xfd
    5ab4:	540000e8 	b.hi	5ad0 <fwp_rc_dup+0x90>  // b.pmore
    5ab8:	11000421 	add	w1, w1, #0x1
    5abc:	39000001 	strb	w1, [x0]
    5ac0:	d65f03c0 	ret
    5ac4:	72003c3f 	tst	w1, #0xffff
    5ac8:	54ffff00 	b.eq	5aa8 <fwp_rc_dup+0x68>  // b.none
    5acc:	d65f03c0 	ret
    5ad0:	17fffb15 	b	4724 <fwp_rc_wide_dup>

0000000000005ad4 <fwp_owned_entry161>:
    5ad4:	d10103ff 	sub	sp, sp, #0x40
    5ad8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5adc:	f947f442 	ldr	x2, [x2, #4072]
    5ae0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ae4:	910083fd 	add	x29, sp, #0x20
    5ae8:	a90353f3 	stp	x19, x20, [sp, #48]
    5aec:	f9400043 	ldr	x3, [x2]
    5af0:	f9000fe3 	str	x3, [sp, #24]
    5af4:	d2800003 	mov	x3, #0x0                   	// #0
    5af8:	a9400c01 	ldp	x1, x3, [x0]
    5afc:	f9400802 	ldr	x2, [x0, #16]
    5b00:	ab020022 	adds	x2, x1, x2
    5b04:	540006e6 	b.vs	5be0 <fwp_owned_entry161+0x10c>
    5b08:	910023e1 	add	x1, sp, #0x8
    5b0c:	52800000 	mov	w0, #0x0                   	// #0
    5b10:	a9008be3 	stp	x3, x2, [sp, #8]
    5b14:	97ffff0b 	bl	5740 <fwp_data.part.0.constprop.0>
    5b18:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    5b1c:	9117c063 	add	x3, x3, #0x5f0
    5b20:	aa0003f3 	mov	x19, x0
    5b24:	f949d861 	ldr	x1, [x3, #5040]
    5b28:	f949ec60 	ldr	x0, [x3, #5080]
    5b2c:	cb010261 	sub	x1, x19, x1
    5b30:	eb00403f 	cmp	x1, x0, lsl #16
    5b34:	54000322 	b.cs	5b98 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5b38:	d350fc22 	lsr	x2, x1, #16
    5b3c:	f949fc63 	ldr	x3, [x3, #5112]
    5b40:	8b020842 	add	x2, x2, x2, lsl #2
    5b44:	d37df042 	lsl	x2, x2, #3
    5b48:	8b020060 	add	x0, x3, x2
    5b4c:	f9401014 	ldr	x20, [x0, #32]
    5b50:	b4000254 	cbz	x20, 5b98 <fwp_owned_entry161+0xc4>
    5b54:	38626862 	ldrb	w2, [x3, x2]
    5b58:	7100085f 	cmp	w2, #0x2
    5b5c:	54000360 	b.eq	5bc8 <fwp_owned_entry161+0xf4>  // b.none
    5b60:	7100045f 	cmp	w2, #0x1
    5b64:	540001a1 	b.ne	5b98 <fwp_owned_entry161+0xc4>  // b.any
    5b68:	29430002 	ldp	w2, w0, [x0, #24]
    5b6c:	92403c21 	and	x1, x1, #0xffff
    5b70:	9b027c21 	mul	x1, x1, x2
    5b74:	d360fc21 	lsr	x1, x1, #32
    5b78:	eb00003f 	cmp	x1, x0
    5b7c:	540000e2 	b.cs	5b98 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5b80:	8b010294 	add	x20, x20, x1
    5b84:	39400280 	ldrb	w0, [x20]
    5b88:	7103fc1f 	cmp	w0, #0xff
    5b8c:	54000240 	b.eq	5bd4 <fwp_owned_entry161+0x100>  // b.none
    5b90:	52800020 	mov	w0, #0x1                   	// #1
    5b94:	39000280 	strb	w0, [x20]
    5b98:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5b9c:	f947f400 	ldr	x0, [x0, #4072]
    5ba0:	f9400fe2 	ldr	x2, [sp, #24]
    5ba4:	f9400001 	ldr	x1, [x0]
    5ba8:	eb010042 	subs	x2, x2, x1
    5bac:	d2800001 	mov	x1, #0x0                   	// #0
    5bb0:	540001a1 	b.ne	5be4 <fwp_owned_entry161+0x110>  // b.any
    5bb4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bb8:	aa1303e0 	mov	x0, x19
    5bbc:	a94353f3 	ldp	x19, x20, [sp, #48]
    5bc0:	910103ff 	add	sp, sp, #0x40
    5bc4:	d65f03c0 	ret
    5bc8:	72003c3f 	tst	w1, #0xffff
    5bcc:	54fffe61 	b.ne	5b98 <fwp_owned_entry161+0xc4>  // b.any
    5bd0:	17ffffed 	b	5b84 <fwp_owned_entry161+0xb0>
    5bd4:	aa1403e0 	mov	x0, x20
    5bd8:	97fffb1a 	bl	4840 <fwp_rc_forget_slot>
    5bdc:	17ffffed 	b	5b90 <fwp_owned_entry161+0xbc>
    5be0:	97fff3a8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5be4:	97fff327 	bl	2880 <__stack_chk_fail@plt>
    5be8:	d503201f 	nop
    5bec:	d503201f 	nop

0000000000005bf0 <e161>:
    5bf0:	d10103ff 	sub	sp, sp, #0x40
    5bf4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5bf8:	f947f442 	ldr	x2, [x2, #4072]
    5bfc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c00:	910083fd 	add	x29, sp, #0x20
    5c04:	a90353f3 	stp	x19, x20, [sp, #48]
    5c08:	f9400043 	ldr	x3, [x2]
    5c0c:	f9000fe3 	str	x3, [sp, #24]
    5c10:	d2800003 	mov	x3, #0x0                   	// #0
    5c14:	a9400c01 	ldp	x1, x3, [x0]
    5c18:	f9400802 	ldr	x2, [x0, #16]
    5c1c:	ab020022 	adds	x2, x1, x2
    5c20:	54000726 	b.vs	5d04 <e161+0x114>
    5c24:	910023e1 	add	x1, sp, #0x8
    5c28:	52800000 	mov	w0, #0x0                   	// #0
    5c2c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c30:	97fffec4 	bl	5740 <fwp_data.part.0.constprop.0>
    5c34:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    5c38:	9117c063 	add	x3, x3, #0x5f0
    5c3c:	aa0003f3 	mov	x19, x0
    5c40:	f949d861 	ldr	x1, [x3, #5040]
    5c44:	f949ec60 	ldr	x0, [x3, #5080]
    5c48:	cb010261 	sub	x1, x19, x1
    5c4c:	eb00403f 	cmp	x1, x0, lsl #16
    5c50:	54000322 	b.cs	5cb4 <e161+0xc4>  // b.hs, b.nlast
    5c54:	d350fc22 	lsr	x2, x1, #16
    5c58:	f949fc63 	ldr	x3, [x3, #5112]
    5c5c:	8b020842 	add	x2, x2, x2, lsl #2
    5c60:	d37df042 	lsl	x2, x2, #3
    5c64:	8b020060 	add	x0, x3, x2
    5c68:	f9401014 	ldr	x20, [x0, #32]
    5c6c:	b4000254 	cbz	x20, 5cb4 <e161+0xc4>
    5c70:	38626862 	ldrb	w2, [x3, x2]
    5c74:	7100085f 	cmp	w2, #0x2
    5c78:	540003a0 	b.eq	5cec <e161+0xfc>  // b.none
    5c7c:	7100045f 	cmp	w2, #0x1
    5c80:	540001a1 	b.ne	5cb4 <e161+0xc4>  // b.any
    5c84:	29430002 	ldp	w2, w0, [x0, #24]
    5c88:	92403c21 	and	x1, x1, #0xffff
    5c8c:	9b027c21 	mul	x1, x1, x2
    5c90:	d360fc21 	lsr	x1, x1, #32
    5c94:	eb00003f 	cmp	x1, x0
    5c98:	540000e2 	b.cs	5cb4 <e161+0xc4>  // b.hs, b.nlast
    5c9c:	8b010294 	add	x20, x20, x1
    5ca0:	39400280 	ldrb	w0, [x20]
    5ca4:	7103fc1f 	cmp	w0, #0xff
    5ca8:	54000280 	b.eq	5cf8 <e161+0x108>  // b.none
    5cac:	52800020 	mov	w0, #0x1                   	// #1
    5cb0:	39000280 	strb	w0, [x20]
    5cb4:	aa1303e0 	mov	x0, x19
    5cb8:	97fffeea 	bl	5860 <fwp_rc_share>
    5cbc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5cc0:	f947f400 	ldr	x0, [x0, #4072]
    5cc4:	f9400fe2 	ldr	x2, [sp, #24]
    5cc8:	f9400001 	ldr	x1, [x0]
    5ccc:	eb010042 	subs	x2, x2, x1
    5cd0:	d2800001 	mov	x1, #0x0                   	// #0
    5cd4:	540001a1 	b.ne	5d08 <e161+0x118>  // b.any
    5cd8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5cdc:	aa1303e0 	mov	x0, x19
    5ce0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ce4:	910103ff 	add	sp, sp, #0x40
    5ce8:	d65f03c0 	ret
    5cec:	72003c3f 	tst	w1, #0xffff
    5cf0:	54fffe21 	b.ne	5cb4 <e161+0xc4>  // b.any
    5cf4:	17ffffeb 	b	5ca0 <e161+0xb0>
    5cf8:	aa1403e0 	mov	x0, x20
    5cfc:	97fffad1 	bl	4840 <fwp_rc_forget_slot>
    5d00:	17ffffeb 	b	5cac <e161+0xbc>
    5d04:	97fff35f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d08:	97fff2de 	bl	2880 <__stack_chk_fail@plt>
    5d0c:	d503201f 	nop

0000000000005d10 <fwp_drop1>:
    5d10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d14:	910003fd 	mov	x29, sp
    5d18:	a90153f3 	stp	x19, x20, [sp, #16]
    5d1c:	f90013f5 	str	x21, [sp, #32]
    5d20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5d24:	9117c2b4 	add	x20, x21, #0x5f0
    5d28:	f949da81 	ldr	x1, [x20, #5040]
    5d2c:	f949ee82 	ldr	x2, [x20, #5080]
    5d30:	cb010001 	sub	x1, x0, x1
    5d34:	eb02403f 	cmp	x1, x2, lsl #16
    5d38:	54000382 	b.cs	5da8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d3c:	d350fc22 	lsr	x2, x1, #16
    5d40:	f949fe84 	ldr	x4, [x20, #5112]
    5d44:	8b020842 	add	x2, x2, x2, lsl #2
    5d48:	d37df042 	lsl	x2, x2, #3
    5d4c:	8b020083 	add	x3, x4, x2
    5d50:	f9401073 	ldr	x19, [x3, #32]
    5d54:	b40002b3 	cbz	x19, 5da8 <fwp_drop1+0x98>
    5d58:	38626882 	ldrb	w2, [x4, x2]
    5d5c:	7100085f 	cmp	w2, #0x2
    5d60:	540002c0 	b.eq	5db8 <fwp_drop1+0xa8>  // b.none
    5d64:	7100045f 	cmp	w2, #0x1
    5d68:	54000201 	b.ne	5da8 <fwp_drop1+0x98>  // b.any
    5d6c:	29430864 	ldp	w4, w2, [x3, #24]
    5d70:	92403c21 	and	x1, x1, #0xffff
    5d74:	9b047c21 	mul	x1, x1, x4
    5d78:	d360fc21 	lsr	x1, x1, #32
    5d7c:	eb02003f 	cmp	x1, x2
    5d80:	54000142 	b.cs	5da8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d84:	8b010273 	add	x19, x19, x1
    5d88:	39400261 	ldrb	w1, [x19]
    5d8c:	340000e1 	cbz	w1, 5da8 <fwp_drop1+0x98>
    5d90:	7100043f 	cmp	w1, #0x1
    5d94:	540001e0 	b.eq	5dd0 <fwp_drop1+0xc0>  // b.none
    5d98:	7103fc3f 	cmp	w1, #0xff
    5d9c:	540002e0 	b.eq	5df8 <fwp_drop1+0xe8>  // b.none
    5da0:	51000421 	sub	w1, w1, #0x1
    5da4:	39000261 	strb	w1, [x19]
    5da8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dac:	f94013f5 	ldr	x21, [sp, #32]
    5db0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5db4:	d65f03c0 	ret
    5db8:	72003c3f 	tst	w1, #0xffff
    5dbc:	54fffe60 	b.eq	5d88 <fwp_drop1+0x78>  // b.none
    5dc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dc4:	f94013f5 	ldr	x21, [sp, #32]
    5dc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dcc:	d65f03c0 	ret
    5dd0:	f9400813 	ldr	x19, [x0, #16]
    5dd4:	97fffef8 	bl	59b4 <fwp_rc_free_arr>
    5dd8:	9117c2a0 	add	x0, x21, #0x5f0
    5ddc:	f949d801 	ldr	x1, [x0, #5040]
    5de0:	f949ec00 	ldr	x0, [x0, #5080]
    5de4:	cb010261 	sub	x1, x19, x1
    5de8:	eb00403f 	cmp	x1, x0, lsl #16
    5dec:	54fffde2 	b.cs	5da8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5df0:	aa1303e0 	mov	x0, x19
    5df4:	17ffffd2 	b	5d3c <fwp_drop1+0x2c>
    5df8:	ca534660 	eor	x0, x19, x19, lsr #17
    5dfc:	9117c2b5 	add	x21, x21, #0x5f0
    5e00:	ca402400 	eor	x0, x0, x0, lsr #9
    5e04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e08:	f94a2400 	ldr	x0, [x0, #5192]
    5e0c:	b5000080 	cbnz	x0, 5e1c <fwp_drop1+0x10c>
    5e10:	14000010 	b	5e50 <fwp_drop1+0x140>
    5e14:	f9400800 	ldr	x0, [x0, #16]
    5e18:	b40001c0 	cbz	x0, 5e50 <fwp_drop1+0x140>
    5e1c:	f9400001 	ldr	x1, [x0]
    5e20:	eb13003f 	cmp	x1, x19
    5e24:	54ffff81 	b.ne	5e14 <fwp_drop1+0x104>  // b.any
    5e28:	f9400401 	ldr	x1, [x0, #8]
    5e2c:	d1000421 	sub	x1, x1, #0x1
    5e30:	f9000401 	str	x1, [x0, #8]
    5e34:	f103f83f 	cmp	x1, #0xfe
    5e38:	54fffb81 	b.ne	5da8 <fwp_drop1+0x98>  // b.any
    5e3c:	aa1303e0 	mov	x0, x19
    5e40:	97fffa80 	bl	4840 <fwp_rc_forget_slot>
    5e44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e48:	39000260 	strb	w0, [x19]
    5e4c:	17ffffd7 	b	5da8 <fwp_drop1+0x98>
    5e50:	90000040 	adrp	x0, d000 <__divti3+0x260>
    5e54:	91208000 	add	x0, x0, #0x820
    5e58:	97fff66a 	bl	3800 <fwp_trap>
    5e5c:	d503201f 	nop

0000000000005e60 <fwp_drop0>:
    5e60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e64:	910003fd 	mov	x29, sp
    5e68:	a90153f3 	stp	x19, x20, [sp, #16]
    5e6c:	f90013f5 	str	x21, [sp, #32]
    5e70:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5e74:	9117c2b4 	add	x20, x21, #0x5f0
    5e78:	f949da81 	ldr	x1, [x20, #5040]
    5e7c:	f949ee82 	ldr	x2, [x20, #5080]
    5e80:	cb010001 	sub	x1, x0, x1
    5e84:	eb02403f 	cmp	x1, x2, lsl #16
    5e88:	54000382 	b.cs	5ef8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e8c:	d350fc22 	lsr	x2, x1, #16
    5e90:	f949fe84 	ldr	x4, [x20, #5112]
    5e94:	8b020842 	add	x2, x2, x2, lsl #2
    5e98:	d37df042 	lsl	x2, x2, #3
    5e9c:	8b020083 	add	x3, x4, x2
    5ea0:	f9401073 	ldr	x19, [x3, #32]
    5ea4:	b40002b3 	cbz	x19, 5ef8 <fwp_drop0+0x98>
    5ea8:	38626882 	ldrb	w2, [x4, x2]
    5eac:	7100085f 	cmp	w2, #0x2
    5eb0:	540002c0 	b.eq	5f08 <fwp_drop0+0xa8>  // b.none
    5eb4:	7100045f 	cmp	w2, #0x1
    5eb8:	54000201 	b.ne	5ef8 <fwp_drop0+0x98>  // b.any
    5ebc:	29430864 	ldp	w4, w2, [x3, #24]
    5ec0:	92403c21 	and	x1, x1, #0xffff
    5ec4:	9b047c21 	mul	x1, x1, x4
    5ec8:	d360fc21 	lsr	x1, x1, #32
    5ecc:	eb02003f 	cmp	x1, x2
    5ed0:	54000142 	b.cs	5ef8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ed4:	8b010273 	add	x19, x19, x1
    5ed8:	39400261 	ldrb	w1, [x19]
    5edc:	340000e1 	cbz	w1, 5ef8 <fwp_drop0+0x98>
    5ee0:	7100043f 	cmp	w1, #0x1
    5ee4:	540001e0 	b.eq	5f20 <fwp_drop0+0xc0>  // b.none
    5ee8:	7103fc3f 	cmp	w1, #0xff
    5eec:	540002e0 	b.eq	5f48 <fwp_drop0+0xe8>  // b.none
    5ef0:	51000421 	sub	w1, w1, #0x1
    5ef4:	39000261 	strb	w1, [x19]
    5ef8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5efc:	f94013f5 	ldr	x21, [sp, #32]
    5f00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f04:	d65f03c0 	ret
    5f08:	72003c3f 	tst	w1, #0xffff
    5f0c:	54fffe60 	b.eq	5ed8 <fwp_drop0+0x78>  // b.none
    5f10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f14:	f94013f5 	ldr	x21, [sp, #32]
    5f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f1c:	d65f03c0 	ret
    5f20:	f9400813 	ldr	x19, [x0, #16]
    5f24:	97fffea4 	bl	59b4 <fwp_rc_free_arr>
    5f28:	9117c2a0 	add	x0, x21, #0x5f0
    5f2c:	f949d801 	ldr	x1, [x0, #5040]
    5f30:	f949ec00 	ldr	x0, [x0, #5080]
    5f34:	cb010261 	sub	x1, x19, x1
    5f38:	eb00403f 	cmp	x1, x0, lsl #16
    5f3c:	54fffde2 	b.cs	5ef8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f40:	aa1303e0 	mov	x0, x19
    5f44:	17ffffd2 	b	5e8c <fwp_drop0+0x2c>
    5f48:	ca534660 	eor	x0, x19, x19, lsr #17
    5f4c:	9117c2b5 	add	x21, x21, #0x5f0
    5f50:	ca402400 	eor	x0, x0, x0, lsr #9
    5f54:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f58:	f94a2400 	ldr	x0, [x0, #5192]
    5f5c:	b5000080 	cbnz	x0, 5f6c <fwp_drop0+0x10c>
    5f60:	14000010 	b	5fa0 <fwp_drop0+0x140>
    5f64:	f9400800 	ldr	x0, [x0, #16]
    5f68:	b40001c0 	cbz	x0, 5fa0 <fwp_drop0+0x140>
    5f6c:	f9400001 	ldr	x1, [x0]
    5f70:	eb13003f 	cmp	x1, x19
    5f74:	54ffff81 	b.ne	5f64 <fwp_drop0+0x104>  // b.any
    5f78:	f9400401 	ldr	x1, [x0, #8]
    5f7c:	d1000421 	sub	x1, x1, #0x1
    5f80:	f9000401 	str	x1, [x0, #8]
    5f84:	f103f83f 	cmp	x1, #0xfe
    5f88:	54fffb81 	b.ne	5ef8 <fwp_drop0+0x98>  // b.any
    5f8c:	aa1303e0 	mov	x0, x19
    5f90:	97fffa2c 	bl	4840 <fwp_rc_forget_slot>
    5f94:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f98:	39000260 	strb	w0, [x19]
    5f9c:	17ffffd7 	b	5ef8 <fwp_drop0+0x98>
    5fa0:	90000040 	adrp	x0, d000 <__divti3+0x260>
    5fa4:	91208000 	add	x0, x0, #0x820
    5fa8:	97fff616 	bl	3800 <fwp_trap>
    5fac:	d503201f 	nop

0000000000005fb0 <fwp_arg_drop12>:
    5fb0:	7100003f 	cmp	w1, #0x0
    5fb4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5fb8:	54000041 	b.ne	5fc0 <fwp_arg_drop12+0x10>  // b.any
    5fbc:	d65f03c0 	ret
    5fc0:	f9400000 	ldr	x0, [x0]
    5fc4:	17ffffa7 	b	5e60 <fwp_drop0>
    5fc8:	d503201f 	nop
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_closure_drop>:
    5fd0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xbf0>
    5fd4:	9117c0a4 	add	x4, x5, #0x5f0
    5fd8:	aa0003e1 	mov	x1, x0
    5fdc:	f949d882 	ldr	x2, [x4, #5040]
    5fe0:	f949ec80 	ldr	x0, [x4, #5080]
    5fe4:	cb020022 	sub	x2, x1, x2
    5fe8:	eb00405f 	cmp	x2, x0, lsl #16
    5fec:	54000662 	b.cs	60b8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5ff0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ff4:	d350fc43 	lsr	x3, x2, #16
    5ff8:	910003fd 	mov	x29, sp
    5ffc:	8b030863 	add	x3, x3, x3, lsl #2
    6000:	f949fc84 	ldr	x4, [x4, #5112]
    6004:	d37df063 	lsl	x3, x3, #3
    6008:	f9000bf3 	str	x19, [sp, #16]
    600c:	8b030080 	add	x0, x4, x3
    6010:	f9401013 	ldr	x19, [x0, #32]
    6014:	b40002b3 	cbz	x19, 6068 <fwp_closure_drop+0x98>
    6018:	38636883 	ldrb	w3, [x4, x3]
    601c:	7100087f 	cmp	w3, #0x2
    6020:	54000420 	b.eq	60a4 <fwp_closure_drop+0xd4>  // b.none
    6024:	7100047f 	cmp	w3, #0x1
    6028:	54000201 	b.ne	6068 <fwp_closure_drop+0x98>  // b.any
    602c:	29430003 	ldp	w3, w0, [x0, #24]
    6030:	92403c42 	and	x2, x2, #0xffff
    6034:	9b037c42 	mul	x2, x2, x3
    6038:	d360fc42 	lsr	x2, x2, #32
    603c:	eb00005f 	cmp	x2, x0
    6040:	54000142 	b.cs	6068 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6044:	8b020273 	add	x19, x19, x2
    6048:	39400260 	ldrb	w0, [x19]
    604c:	340000e0 	cbz	w0, 6068 <fwp_closure_drop+0x98>
    6050:	7100041f 	cmp	w0, #0x1
    6054:	54000100 	b.eq	6074 <fwp_closure_drop+0xa4>  // b.none
    6058:	7103fc1f 	cmp	w0, #0xff
    605c:	54000300 	b.eq	60bc <fwp_closure_drop+0xec>  // b.none
    6060:	51000400 	sub	w0, w0, #0x1
    6064:	39000260 	strb	w0, [x19]
    6068:	f9400bf3 	ldr	x19, [sp, #16]
    606c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6070:	d65f03c0 	ret
    6074:	d53bd040 	mrs	x0, tpidr_el0
    6078:	91400000 	add	x0, x0, #0x0, lsl #12
    607c:	91004000 	add	x0, x0, #0x10
    6080:	f9400000 	ldr	x0, [x0]
    6084:	b4000080 	cbz	x0, 6094 <fwp_closure_drop+0xc4>
    6088:	f9400bf3 	ldr	x19, [sp, #16]
    608c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6090:	17fff5f5 	b	3864 <fwp_closure_drop_push>
    6094:	f9400bf3 	ldr	x19, [sp, #16]
    6098:	aa0103e0 	mov	x0, x1
    609c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60a0:	17fff660 	b	3a20 <fwp_closure_drop.part.0>
    60a4:	72003c5f 	tst	w2, #0xffff
    60a8:	54fffd00 	b.eq	6048 <fwp_closure_drop+0x78>  // b.none
    60ac:	f9400bf3 	ldr	x19, [sp, #16]
    60b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60b4:	d65f03c0 	ret
    60b8:	d65f03c0 	ret
    60bc:	ca534660 	eor	x0, x19, x19, lsr #17
    60c0:	9117c0a5 	add	x5, x5, #0x5f0
    60c4:	ca402400 	eor	x0, x0, x0, lsr #9
    60c8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    60cc:	f94a2400 	ldr	x0, [x0, #5192]
    60d0:	b5000080 	cbnz	x0, 60e0 <fwp_closure_drop+0x110>
    60d4:	14000010 	b	6114 <fwp_closure_drop+0x144>
    60d8:	f9400800 	ldr	x0, [x0, #16]
    60dc:	b40001c0 	cbz	x0, 6114 <fwp_closure_drop+0x144>
    60e0:	f9400001 	ldr	x1, [x0]
    60e4:	eb13003f 	cmp	x1, x19
    60e8:	54ffff81 	b.ne	60d8 <fwp_closure_drop+0x108>  // b.any
    60ec:	f9400401 	ldr	x1, [x0, #8]
    60f0:	d1000421 	sub	x1, x1, #0x1
    60f4:	f9000401 	str	x1, [x0, #8]
    60f8:	f103f83f 	cmp	x1, #0xfe
    60fc:	54fffb61 	b.ne	6068 <fwp_closure_drop+0x98>  // b.any
    6100:	aa1303e0 	mov	x0, x19
    6104:	97fff9cf 	bl	4840 <fwp_rc_forget_slot>
    6108:	12800020 	mov	w0, #0xfffffffe            	// #-2
    610c:	39000260 	strb	w0, [x19]
    6110:	17ffffd6 	b	6068 <fwp_closure_drop+0x98>
    6114:	f0000020 	adrp	x0, d000 <__divti3+0x260>
    6118:	91208000 	add	x0, x0, #0x820
    611c:	97fff5b9 	bl	3800 <fwp_trap>

0000000000006120 <fwp_owned_tape_release>:
    6120:	b4000940 	cbz	x0, 6248 <fwp_owned_tape_release+0x128>
    6124:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6128:	910003fd 	mov	x29, sp
    612c:	a90153f3 	stp	x19, x20, [sp, #16]
    6130:	aa0003f3 	mov	x19, x0
    6134:	f9400000 	ldr	x0, [x0]
    6138:	b4000060 	cbz	x0, 6144 <fwp_owned_tape_release+0x24>
    613c:	f9400661 	ldr	x1, [x19, #8]
    6140:	f9000401 	str	x1, [x0, #8]
    6144:	f9400661 	ldr	x1, [x19, #8]
    6148:	b4000041 	cbz	x1, 6150 <fwp_owned_tape_release+0x30>
    614c:	f9000020 	str	x0, [x1]
    6150:	f9400a60 	ldr	x0, [x19, #16]
    6154:	f9403401 	ldr	x1, [x0, #104]
    6158:	b40005c1 	cbz	x1, 6210 <fwp_owned_tape_release+0xf0>
    615c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6160:	eb00005f 	cmp	x2, x0
    6164:	540002ed 	b.le	61c0 <fwp_owned_tape_release+0xa0>
    6168:	d2800014 	mov	x20, #0x0                   	// #0
    616c:	f90013f5 	str	x21, [sp, #32]
    6170:	d2800015 	mov	x21, #0x0                   	// #0
    6174:	d503201f 	nop
    6178:	f9402260 	ldr	x0, [x19, #64]
    617c:	910006b5 	add	x21, x21, #0x1
    6180:	f8746800 	ldr	x0, [x0, x20]
    6184:	d63f0020 	blr	x1
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	f9400a61 	ldr	x1, [x19, #16]
    6190:	8b140000 	add	x0, x0, x20
    6194:	91004294 	add	x20, x20, #0x10
    6198:	f9400400 	ldr	x0, [x0, #8]
    619c:	f9403421 	ldr	x1, [x1, #104]
    61a0:	d63f0020 	blr	x1
    61a4:	a9450261 	ldp	x1, x0, [x19, #80]
    61a8:	cb010000 	sub	x0, x0, x1
    61ac:	eb15001f 	cmp	x0, x21
    61b0:	f9400a60 	ldr	x0, [x19, #16]
    61b4:	f9403401 	ldr	x1, [x0, #104]
    61b8:	54fffe0c 	b.gt	6178 <fwp_owned_tape_release+0x58>
    61bc:	f94013f5 	ldr	x21, [sp, #32]
    61c0:	f9403663 	ldr	x3, [x19, #104]
    61c4:	f9401262 	ldr	x2, [x19, #32]
    61c8:	f100007f 	cmp	x3, #0x0
    61cc:	540001ed 	b.le	6208 <fwp_owned_tape_release+0xe8>
    61d0:	d2800014 	mov	x20, #0x0                   	// #0
    61d4:	d503201f 	nop
    61d8:	f9402660 	ldr	x0, [x19, #72]
    61dc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    61e0:	eb02001f 	cmp	x0, x2
    61e4:	540000c0 	b.eq	61fc <fwp_owned_tape_release+0xdc>  // b.none
    61e8:	d63f0020 	blr	x1
    61ec:	f9400a60 	ldr	x0, [x19, #16]
    61f0:	f9401262 	ldr	x2, [x19, #32]
    61f4:	f9403663 	ldr	x3, [x19, #104]
    61f8:	f9403401 	ldr	x1, [x0, #104]
    61fc:	91000694 	add	x20, x20, #0x1
    6200:	eb14007f 	cmp	x3, x20
    6204:	54fffeac 	b.gt	61d8 <fwp_owned_tape_release+0xb8>
    6208:	aa0203e0 	mov	x0, x2
    620c:	d63f0020 	blr	x1
    6210:	f9401660 	ldr	x0, [x19, #40]
    6214:	97ffff6f 	bl	5fd0 <fwp_closure_drop>
    6218:	f9401a60 	ldr	x0, [x19, #48]
    621c:	97ffff6d 	bl	5fd0 <fwp_closure_drop>
    6220:	f9401e60 	ldr	x0, [x19, #56]
    6224:	97ffff6b 	bl	5fd0 <fwp_closure_drop>
    6228:	f9402260 	ldr	x0, [x19, #64]
    622c:	97fffa25 	bl	4ac0 <fwp_mem_free>
    6230:	f9402660 	ldr	x0, [x19, #72]
    6234:	97fffa23 	bl	4ac0 <fwp_mem_free>
    6238:	aa1303e0 	mov	x0, x19
    623c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6240:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6244:	17fffa1f 	b	4ac0 <fwp_mem_free>
    6248:	d65f03c0 	ret
    624c:	d503201f 	nop

0000000000006250 <fwp_tape_finish>:
    6250:	d10203ff 	sub	sp, sp, #0x80
    6254:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6258:	f947f421 	ldr	x1, [x1, #4072]
    625c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6260:	910103fd 	add	x29, sp, #0x40
    6264:	a90553f3 	stp	x19, x20, [sp, #80]
    6268:	a9065bf5 	stp	x21, x22, [sp, #96]
    626c:	a90763f7 	stp	x23, x24, [sp, #112]
    6270:	d00000d8 	adrp	x24, 20000 <__data_start>
    6274:	9101c316 	add	x22, x24, #0x70
    6278:	f9400022 	ldr	x2, [x1]
    627c:	f9001fe2 	str	x2, [sp, #56]
    6280:	d2800002 	mov	x2, #0x0                   	// #0
    6284:	9102e2c0 	add	x0, x22, #0xb8
    6288:	97fff47e 	bl	3480 <fwp_tape_buffers_dispose>
    628c:	f9007adf 	str	xzr, [x22, #240]
    6290:	f9404ac0 	ldr	x0, [x22, #144]
    6294:	f100001f 	cmp	x0, #0x0
    6298:	5400030d 	b.le	62f8 <fwp_tape_finish+0xa8>
    629c:	910003f7 	mov	x23, sp
    62a0:	d2800015 	mov	x21, #0x0                   	// #0
    62a4:	d2800014 	mov	x20, #0x0                   	// #0
    62a8:	f94002d3 	ldr	x19, [x22]
    62ac:	91000694 	add	x20, x20, #0x1
    62b0:	8b150273 	add	x19, x19, x21
    62b4:	9101a2b5 	add	x21, x21, #0x68
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	97fff335 	bl	2f90 <fwp_tape_unlink_scope>
    62c0:	aa1703e0 	mov	x0, x23
    62c4:	f9401261 	ldr	x1, [x19, #32]
    62c8:	f90003e1 	str	x1, [sp]
    62cc:	f9401a62 	ldr	x2, [x19, #48]
    62d0:	f9000be2 	str	x2, [sp, #16]
    62d4:	f9402261 	ldr	x1, [x19, #64]
    62d8:	f90013e1 	str	x1, [sp, #32]
    62dc:	97fff469 	bl	3480 <fwp_tape_buffers_dispose>
    62e0:	f9403260 	ldr	x0, [x19, #96]
    62e4:	97ffff8f 	bl	6120 <fwp_owned_tape_release>
    62e8:	f900327f 	str	xzr, [x19, #96]
    62ec:	f9404ac0 	ldr	x0, [x22, #144]
    62f0:	eb14001f 	cmp	x0, x20
    62f4:	54fffdac 	b.gt	62a8 <fwp_tape_finish+0x58>
    62f8:	f9403b00 	ldr	x0, [x24, #112]
    62fc:	9101c313 	add	x19, x24, #0x70
    6300:	97fff190 	bl	2940 <free@plt>
    6304:	f9003b1f 	str	xzr, [x24, #112]
    6308:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    630c:	f947f400 	ldr	x0, [x0, #4072]
    6310:	f9004a7f 	str	xzr, [x19, #144]
    6314:	a9107e7f 	stp	xzr, xzr, [x19, #256]
    6318:	f9401fe2 	ldr	x2, [sp, #56]
    631c:	f9400001 	ldr	x1, [x0]
    6320:	eb010042 	subs	x2, x2, x1
    6324:	d2800001 	mov	x1, #0x0                   	// #0
    6328:	540000e1 	b.ne	6344 <fwp_tape_finish+0xf4>  // b.any
    632c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6330:	a94553f3 	ldp	x19, x20, [sp, #80]
    6334:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6338:	a94763f7 	ldp	x23, x24, [sp, #112]
    633c:	910203ff 	add	sp, sp, #0x80
    6340:	d65f03c0 	ret
    6344:	97fff14f 	bl	2880 <__stack_chk_fail@plt>
    6348:	d503201f 	nop
    634c:	d503201f 	nop

0000000000006350 <fwp_tape_scope_release>:
    6350:	d10243ff 	sub	sp, sp, #0x90
    6354:	a9047bfd 	stp	x29, x30, [sp, #64]
    6358:	910103fd 	add	x29, sp, #0x40
    635c:	a90553f3 	stp	x19, x20, [sp, #80]
    6360:	aa0003f4 	mov	x20, x0
    6364:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6368:	f947f400 	ldr	x0, [x0, #4072]
    636c:	b9400285 	ldr	w5, [x20]
    6370:	f9400001 	ldr	x1, [x0]
    6374:	f9001fe1 	str	x1, [sp, #56]
    6378:	d2800001 	mov	x1, #0x0                   	// #0
    637c:	37f806c5 	tbnz	w5, #31, 6454 <fwp_tape_scope_release+0x104>
    6380:	a90763f7 	stp	x23, x24, [sp, #112]
    6384:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6388:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    638c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6390:	d00000d3 	adrp	x19, 20000 <__data_start>
    6394:	910003f7 	mov	x23, sp
    6398:	9101c273 	add	x19, x19, #0x70
    639c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    63a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63a4:	52800d16 	mov	w22, #0x68                  	// #104
    63a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    63ac:	f90043f9 	str	x25, [sp, #128]
    63b0:	14000006 	b	63c8 <fwp_tape_scope_release+0x78>
    63b4:	97fff433 	bl	3480 <fwp_tape_buffers_dispose>
    63b8:	aa1903e0 	mov	x0, x25
    63bc:	97ffff59 	bl	6120 <fwp_owned_tape_release>
    63c0:	b9400285 	ldr	w5, [x20]
    63c4:	37f80425 	tbnz	w5, #31, 6448 <fwp_tape_scope_release+0xf8>
    63c8:	f9400266 	ldr	x6, [x19]
    63cc:	9b367ca5 	smull	x5, w5, w22
    63d0:	8b0500c0 	add	x0, x6, x5
    63d4:	97fff2ef 	bl	2f90 <fwp_tape_unlink_scope>
    63d8:	ad410001 	ldp	q1, q0, [x0, #32]
    63dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    63e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    63e4:	f9400c03 	ldr	x3, [x0, #24]
    63e8:	ad0003e1 	stp	q1, q0, [sp]
    63ec:	b86568c1 	ldr	w1, [x6, x5]
    63f0:	a9440804 	ldp	x4, x2, [x0, #64]
    63f4:	b900041f 	str	wzr, [x0, #4]
    63f8:	f9403019 	ldr	x25, [x0, #96]
    63fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6400:	f9000c1f 	str	xzr, [x0, #24]
    6404:	a9020fe4 	stp	x4, x3, [sp, #32]
    6408:	f9001be2 	str	x2, [sp, #48]
    640c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6410:	f900301f 	str	xzr, [x0, #96]
    6414:	6b15003f 	cmp	w1, w21
    6418:	540000e8 	b.hi	6434 <fwp_tape_scope_release+0xe4>  // b.pmore
    641c:	9343fca5 	asr	x5, x5, #3
    6420:	f9408660 	ldr	x0, [x19, #264]
    6424:	9b187ca5 	mul	x5, x5, x24
    6428:	eb0000bf 	cmp	x5, x0
    642c:	5400004a 	b.ge	6434 <fwp_tape_scope_release+0xe4>  // b.tcont
    6430:	f9008665 	str	x5, [x19, #264]
    6434:	aa1703e0 	mov	x0, x23
    6438:	b5fffbf9 	cbnz	x25, 63b4 <fwp_tape_scope_release+0x64>
    643c:	97fff7e5 	bl	43d0 <fwp_tape_buffers_release>
    6440:	b9400285 	ldr	w5, [x20]
    6444:	36fffc25 	tbz	w5, #31, 63c8 <fwp_tape_scope_release+0x78>
    6448:	a9465bf5 	ldp	x21, x22, [sp, #96]
    644c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6450:	f94043f9 	ldr	x25, [sp, #128]
    6454:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6458:	f947f400 	ldr	x0, [x0, #4072]
    645c:	f9401fe2 	ldr	x2, [sp, #56]
    6460:	f9400001 	ldr	x1, [x0]
    6464:	eb010042 	subs	x2, x2, x1
    6468:	d2800001 	mov	x1, #0x0                   	// #0
    646c:	540000a1 	b.ne	6480 <fwp_tape_scope_release+0x130>  // b.any
    6470:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6474:	a94553f3 	ldp	x19, x20, [sp, #80]
    6478:	910243ff 	add	sp, sp, #0x90
    647c:	d65f03c0 	ret
    6480:	a9065bf5 	stp	x21, x22, [sp, #96]
    6484:	a90763f7 	stp	x23, x24, [sp, #112]
    6488:	f90043f9 	str	x25, [sp, #128]
    648c:	97fff0fd 	bl	2880 <__stack_chk_fail@plt>

0000000000006490 <fwp_task_dispose>:
    6490:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6494:	910003fd 	mov	x29, sp
    6498:	f9000bf3 	str	x19, [sp, #16]
    649c:	aa0003f3 	mov	x19, x0
    64a0:	39414000 	ldrb	w0, [x0, #80]
    64a4:	36000720 	tbz	w0, #0, 6588 <fwp_task_dispose+0xf8>
    64a8:	f9400a60 	ldr	x0, [x19, #16]
    64ac:	b50006e0 	cbnz	x0, 6588 <fwp_task_dispose+0xf8>
    64b0:	a9478660 	ldp	x0, x1, [x19, #120]
    64b4:	39014e7f 	strb	wzr, [x19, #83]
    64b8:	f9003e7f 	str	xzr, [x19, #120]
    64bc:	f100003f 	cmp	x1, #0x0
    64c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64c4:	54000040 	b.eq	64cc <fwp_task_dispose+0x3c>  // b.none
    64c8:	d63f0020 	blr	x1
    64cc:	f9405660 	ldr	x0, [x19, #168]
    64d0:	97fff97c 	bl	4ac0 <fwp_mem_free>
    64d4:	f900567f 	str	xzr, [x19, #168]
    64d8:	b9405e60 	ldr	w0, [x19, #92]
    64dc:	7100041f 	cmp	w0, #0x1
    64e0:	54000420 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    64e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    64e8:	9117c042 	add	x2, x2, #0x5f0
    64ec:	f949d840 	ldr	x0, [x2, #5040]
    64f0:	f949ec41 	ldr	x1, [x2, #5080]
    64f4:	cb000260 	sub	x0, x19, x0
    64f8:	eb01401f 	cmp	x0, x1, lsl #16
    64fc:	540002e2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6500:	d350fc01 	lsr	x1, x0, #16
    6504:	f949fc44 	ldr	x4, [x2, #5112]
    6508:	8b010821 	add	x1, x1, x1, lsl #2
    650c:	d37df021 	lsl	x1, x1, #3
    6510:	8b010083 	add	x3, x4, x1
    6514:	f9401062 	ldr	x2, [x3, #32]
    6518:	b4000202 	cbz	x2, 6558 <fwp_task_dispose+0xc8>
    651c:	38616881 	ldrb	w1, [x4, x1]
    6520:	7100083f 	cmp	w1, #0x2
    6524:	54000280 	b.eq	6574 <fwp_task_dispose+0xe4>  // b.none
    6528:	7100043f 	cmp	w1, #0x1
    652c:	54000161 	b.ne	6558 <fwp_task_dispose+0xc8>  // b.any
    6530:	29430464 	ldp	w4, w1, [x3, #24]
    6534:	92403c00 	and	x0, x0, #0xffff
    6538:	9b047c00 	mul	x0, x0, x4
    653c:	d360fc00 	lsr	x0, x0, #32
    6540:	eb01001f 	cmp	x0, x1
    6544:	540000a2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6548:	8b000042 	add	x2, x2, x0
    654c:	39400040 	ldrb	w0, [x2]
    6550:	7100041f 	cmp	w0, #0x1
    6554:	54000080 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    6558:	f9400bf3 	ldr	x19, [sp, #16]
    655c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6560:	d65f03c0 	ret
    6564:	aa1303e0 	mov	x0, x19
    6568:	f9400bf3 	ldr	x19, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	17fff954 	b	4ac0 <fwp_mem_free>
    6574:	72003c1f 	tst	w0, #0xffff
    6578:	54fffea0 	b.eq	654c <fwp_task_dispose+0xbc>  // b.none
    657c:	f9400bf3 	ldr	x19, [sp, #16]
    6580:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6584:	d65f03c0 	ret
    6588:	97fff0d2 	bl	28d0 <abort@plt>
    658c:	d503201f 	nop

0000000000006590 <fwp_free_zombie>:
    6590:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6594:	910003fd 	mov	x29, sp
    6598:	a90153f3 	stp	x19, x20, [sp, #16]
    659c:	d00000d4 	adrp	x20, 20000 <__data_start>
    65a0:	9101c281 	add	x1, x20, #0x70
    65a4:	f9408833 	ldr	x19, [x1, #272]
    65a8:	b4000333 	cbz	x19, 660c <fwp_free_zombie+0x7c>
    65ac:	f9400820 	ldr	x0, [x1, #16]
    65b0:	eb00027f 	cmp	x19, x0
    65b4:	540002c0 	b.eq	660c <fwp_free_zombie+0x7c>  // b.none
    65b8:	b9411822 	ldr	w2, [x1, #280]
    65bc:	f9400a60 	ldr	x0, [x19, #16]
    65c0:	7100fc5f 	cmp	w2, #0x3f
    65c4:	5400078c 	b.gt	66b4 <fwp_free_zombie+0x124>
    65c8:	91048023 	add	x3, x1, #0x120
    65cc:	11000444 	add	w4, w2, #0x1
    65d0:	b9011824 	str	w4, [x1, #280]
    65d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65dc:	a9530261 	ldp	x1, x0, [x19, #304]
    65e0:	b4000741 	cbz	x1, 66c8 <fwp_free_zombie+0x138>
    65e4:	f9009c20 	str	x0, [x1, #312]
    65e8:	b4000040 	cbz	x0, 65f0 <fwp_free_zombie+0x60>
    65ec:	f9009801 	str	x1, [x0, #304]
    65f0:	9101c294 	add	x20, x20, #0x70
    65f4:	b9405e60 	ldr	w0, [x19, #92]
    65f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    65fc:	f9008a9f 	str	xzr, [x20, #272]
    6600:	34000140 	cbz	w0, 6628 <fwp_free_zombie+0x98>
    6604:	7100041f 	cmp	w0, #0x1
    6608:	54000080 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    660c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6614:	d65f03c0 	ret
    6618:	aa1303e0 	mov	x0, x19
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6624:	17ffff9b 	b	6490 <fwp_task_dispose>
    6628:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xbf0>
    662c:	9117c082 	add	x2, x4, #0x5f0
    6630:	f949d841 	ldr	x1, [x2, #5040]
    6634:	f949ec40 	ldr	x0, [x2, #5080]
    6638:	cb010261 	sub	x1, x19, x1
    663c:	eb00403f 	cmp	x1, x0, lsl #16
    6640:	54fffe62 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6644:	d350fc20 	lsr	x0, x1, #16
    6648:	f949fc43 	ldr	x3, [x2, #5112]
    664c:	8b000800 	add	x0, x0, x0, lsl #2
    6650:	d37df000 	lsl	x0, x0, #3
    6654:	8b000062 	add	x2, x3, x0
    6658:	f9401054 	ldr	x20, [x2, #32]
    665c:	b4fffd94 	cbz	x20, 660c <fwp_free_zombie+0x7c>
    6660:	38606860 	ldrb	w0, [x3, x0]
    6664:	7100081f 	cmp	w0, #0x2
    6668:	54000360 	b.eq	66d4 <fwp_free_zombie+0x144>  // b.none
    666c:	7100041f 	cmp	w0, #0x1
    6670:	54fffce1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6674:	29430043 	ldp	w3, w0, [x2, #24]
    6678:	92403c21 	and	x1, x1, #0xffff
    667c:	9b037c21 	mul	x1, x1, x3
    6680:	d360fc21 	lsr	x1, x1, #32
    6684:	eb00003f 	cmp	x1, x0
    6688:	54fffc22 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    668c:	8b010294 	add	x20, x20, x1
    6690:	39400280 	ldrb	w0, [x20]
    6694:	34fffbc0 	cbz	w0, 660c <fwp_free_zombie+0x7c>
    6698:	7100041f 	cmp	w0, #0x1
    669c:	54fffbe0 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    66a0:	7103fc1f 	cmp	w0, #0xff
    66a4:	540001e0 	b.eq	66e0 <fwp_free_zombie+0x150>  // b.none
    66a8:	51000400 	sub	w0, w0, #0x1
    66ac:	39000280 	strb	w0, [x20]
    66b0:	17ffffd7 	b	660c <fwp_free_zombie+0x7c>
    66b4:	f9400e61 	ldr	x1, [x19, #24]
    66b8:	97fff0ba 	bl	29a0 <munmap@plt>
    66bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66c0:	a9530261 	ldp	x1, x0, [x19, #304]
    66c4:	b5fff901 	cbnz	x1, 65e4 <fwp_free_zombie+0x54>
    66c8:	9101c282 	add	x2, x20, #0x70
    66cc:	f9019040 	str	x0, [x2, #800]
    66d0:	17ffffc6 	b	65e8 <fwp_free_zombie+0x58>
    66d4:	72003c3f 	tst	w1, #0xffff
    66d8:	54fff9a1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    66dc:	17ffffed 	b	6690 <fwp_free_zombie+0x100>
    66e0:	ca544680 	eor	x0, x20, x20, lsr #17
    66e4:	9117c084 	add	x4, x4, #0x5f0
    66e8:	ca402400 	eor	x0, x0, x0, lsr #9
    66ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    66f0:	f94a2400 	ldr	x0, [x0, #5192]
    66f4:	b5000080 	cbnz	x0, 6704 <fwp_free_zombie+0x174>
    66f8:	14000010 	b	6738 <fwp_free_zombie+0x1a8>
    66fc:	f9400800 	ldr	x0, [x0, #16]
    6700:	b40001c0 	cbz	x0, 6738 <fwp_free_zombie+0x1a8>
    6704:	f9400001 	ldr	x1, [x0]
    6708:	eb14003f 	cmp	x1, x20
    670c:	54ffff81 	b.ne	66fc <fwp_free_zombie+0x16c>  // b.any
    6710:	f9400401 	ldr	x1, [x0, #8]
    6714:	d1000421 	sub	x1, x1, #0x1
    6718:	f9000401 	str	x1, [x0, #8]
    671c:	f103f83f 	cmp	x1, #0xfe
    6720:	54fff761 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6724:	aa1403e0 	mov	x0, x20
    6728:	97fff846 	bl	4840 <fwp_rc_forget_slot>
    672c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6730:	39000280 	strb	w0, [x20]
    6734:	17ffffb6 	b	660c <fwp_free_zombie+0x7c>
    6738:	f0000020 	adrp	x0, d000 <__divti3+0x260>
    673c:	91208000 	add	x0, x0, #0x820
    6740:	97fff430 	bl	3800 <fwp_trap>

0000000000006744 <fwp_block>:
    6744:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6748:	910003fd 	mov	x29, sp
    674c:	a90153f3 	stp	x19, x20, [sp, #16]
    6750:	d00000d3 	adrp	x19, 20000 <__data_start>
    6754:	9101c274 	add	x20, x19, #0x70
    6758:	f9404282 	ldr	x2, [x20, #128]
    675c:	b4000622 	cbz	x2, 6820 <fwp_block+0xdc>
    6760:	9101c261 	add	x1, x19, #0x70
    6764:	f9408040 	ldr	x0, [x2, #256]
    6768:	f9004020 	str	x0, [x1, #128]
    676c:	b4000680 	cbz	x0, 683c <fwp_block+0xf8>
    6770:	9101c263 	add	x3, x19, #0x70
    6774:	3901505f 	strb	wzr, [x2, #84]
    6778:	f9400864 	ldr	x4, [x3, #16]
    677c:	eb02009f 	cmp	x4, x2
    6780:	54000440 	b.eq	6808 <fwp_block+0xc4>  // b.none
    6784:	f9419465 	ldr	x5, [x3, #808]
    6788:	f9000862 	str	x2, [x3, #16]
    678c:	f9400441 	ldr	x1, [x2, #8]
    6790:	f9004885 	str	x5, [x4, #144]
    6794:	f9419865 	ldr	x5, [x3, #816]
    6798:	f9004c85 	str	x5, [x4, #152]
    679c:	f9419c65 	ldr	x5, [x3, #824]
    67a0:	f9005085 	str	x5, [x4, #160]
    67a4:	f941a065 	ldr	x5, [x3, #832]
    67a8:	f9005485 	str	x5, [x4, #168]
    67ac:	f941a465 	ldr	x5, [x3, #840]
    67b0:	f9005885 	str	x5, [x4, #176]
    67b4:	f941a865 	ldr	x5, [x3, #848]
    67b8:	f9005c85 	str	x5, [x4, #184]
    67bc:	f941ac65 	ldr	x5, [x3, #856]
    67c0:	f9006085 	str	x5, [x4, #192]
    67c4:	f9400480 	ldr	x0, [x4, #8]
    67c8:	f9404844 	ldr	x4, [x2, #144]
    67cc:	f9019464 	str	x4, [x3, #808]
    67d0:	f9404c44 	ldr	x4, [x2, #152]
    67d4:	f9019864 	str	x4, [x3, #816]
    67d8:	f9405044 	ldr	x4, [x2, #160]
    67dc:	f9019c64 	str	x4, [x3, #824]
    67e0:	f9405444 	ldr	x4, [x2, #168]
    67e4:	f901a064 	str	x4, [x3, #832]
    67e8:	f9405844 	ldr	x4, [x2, #176]
    67ec:	f901a464 	str	x4, [x3, #840]
    67f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    67f4:	f901a864 	str	x4, [x3, #848]
    67f8:	f901ac62 	str	x2, [x3, #856]
    67fc:	97fff039 	bl	28e0 <swapcontext@plt>
    6800:	97ffff64 	bl	6590 <fwp_free_zombie>
    6804:	d503201f 	nop
    6808:	9101c260 	add	x0, x19, #0x70
    680c:	b9436000 	ldr	w0, [x0, #864]
    6810:	340001a0 	cbz	w0, 6844 <fwp_block+0x100>
    6814:	a94153f3 	ldp	x19, x20, [sp, #16]
    6818:	a8c27bfd 	ldp	x29, x30, [sp], #32
    681c:	d65f03c0 	ret
    6820:	97fff734 	bl	44f0 <fwp_poll_events>
    6824:	f9404282 	ldr	x2, [x20, #128]
    6828:	b4ffffc2 	cbz	x2, 6820 <fwp_block+0xdc>
    682c:	9101c261 	add	x1, x19, #0x70
    6830:	f9408040 	ldr	x0, [x2, #256]
    6834:	f9004020 	str	x0, [x1, #128]
    6838:	b5fff9c0 	cbnz	x0, 6770 <fwp_block+0x2c>
    683c:	f9003c3f 	str	xzr, [x1, #120]
    6840:	17ffffcc 	b	6770 <fwp_block+0x2c>
    6844:	f0000020 	adrp	x0, d000 <__divti3+0x260>
    6848:	91254000 	add	x0, x0, #0x950
    684c:	97fff071 	bl	2a10 <getenv@plt>
    6850:	5284e202 	mov	w2, #0x2710                	// #10000
    6854:	b4000060 	cbz	x0, 6860 <fwp_block+0x11c>
    6858:	39400001 	ldrb	w1, [x0]
    685c:	350000c1 	cbnz	w1, 6874 <fwp_block+0x130>
    6860:	9101c273 	add	x19, x19, #0x70
    6864:	b9036262 	str	w2, [x19, #864]
    6868:	a94153f3 	ldp	x19, x20, [sp, #16]
    686c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6870:	d65f03c0 	ret
    6874:	52800142 	mov	w2, #0xa                   	// #10
    6878:	d2800001 	mov	x1, #0x0                   	// #0
    687c:	97ffefb5 	bl	2750 <strtoll@plt>
    6880:	d1000403 	sub	x3, x0, #0x1
    6884:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6888:	eb02007f 	cmp	x3, x2
    688c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6890:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6894:	17fffff3 	b	6860 <fwp_block+0x11c>
    6898:	d503201f 	nop
    689c:	d503201f 	nop

00000000000068a0 <fwp_drop4>:
    68a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    68a4:	910003fd 	mov	x29, sp
    68a8:	a90153f3 	stp	x19, x20, [sp, #16]
    68ac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    68b0:	f90013f5 	str	x21, [sp, #32]
    68b4:	9117c275 	add	x21, x19, #0x5f0
    68b8:	f949daa1 	ldr	x1, [x21, #5040]
    68bc:	f949eea2 	ldr	x2, [x21, #5080]
    68c0:	cb010001 	sub	x1, x0, x1
    68c4:	eb02403f 	cmp	x1, x2, lsl #16
    68c8:	54000382 	b.cs	6938 <fwp_drop4+0x98>  // b.hs, b.nlast
    68cc:	d350fc22 	lsr	x2, x1, #16
    68d0:	f949fea3 	ldr	x3, [x21, #5112]
    68d4:	8b020842 	add	x2, x2, x2, lsl #2
    68d8:	d37df042 	lsl	x2, x2, #3
    68dc:	8b020064 	add	x4, x3, x2
    68e0:	f9401094 	ldr	x20, [x4, #32]
    68e4:	b40002b4 	cbz	x20, 6938 <fwp_drop4+0x98>
    68e8:	38626862 	ldrb	w2, [x3, x2]
    68ec:	7100085f 	cmp	w2, #0x2
    68f0:	540007a0 	b.eq	69e4 <fwp_drop4+0x144>  // b.none
    68f4:	7100045f 	cmp	w2, #0x1
    68f8:	54000201 	b.ne	6938 <fwp_drop4+0x98>  // b.any
    68fc:	29430885 	ldp	w5, w2, [x4, #24]
    6900:	92403c21 	and	x1, x1, #0xffff
    6904:	9b057c21 	mul	x1, x1, x5
    6908:	d360fc21 	lsr	x1, x1, #32
    690c:	eb02003f 	cmp	x1, x2
    6910:	54000142 	b.cs	6938 <fwp_drop4+0x98>  // b.hs, b.nlast
    6914:	8b010294 	add	x20, x20, x1
    6918:	39400281 	ldrb	w1, [x20]
    691c:	340000e1 	cbz	w1, 6938 <fwp_drop4+0x98>
    6920:	7100043f 	cmp	w1, #0x1
    6924:	54000120 	b.eq	6948 <fwp_drop4+0xa8>  // b.none
    6928:	7103fc3f 	cmp	w1, #0xff
    692c:	540007c0 	b.eq	6a24 <fwp_drop4+0x184>  // b.none
    6930:	51000421 	sub	w1, w1, #0x1
    6934:	39000281 	strb	w1, [x20]
    6938:	a94153f3 	ldp	x19, x20, [sp, #16]
    693c:	f94013f5 	ldr	x21, [sp, #32]
    6940:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6944:	d65f03c0 	ret
    6948:	f9400001 	ldr	x1, [x0]
    694c:	b7f80581 	tbnz	x1, #63, 69fc <fwp_drop4+0x15c>
    6950:	9117c273 	add	x19, x19, #0x5f0
    6954:	f949da61 	ldr	x1, [x19, #5040]
    6958:	f949ee62 	ldr	x2, [x19, #5080]
    695c:	cb010001 	sub	x1, x0, x1
    6960:	eb02403f 	cmp	x1, x2, lsl #16
    6964:	54fffea2 	b.cs	6938 <fwp_drop4+0x98>  // b.hs, b.nlast
    6968:	d350fc22 	lsr	x2, x1, #16
    696c:	8b020842 	add	x2, x2, x2, lsl #2
    6970:	d37df042 	lsl	x2, x2, #3
    6974:	8b020065 	add	x5, x3, x2
    6978:	f94010a4 	ldr	x4, [x5, #32]
    697c:	b4fffde4 	cbz	x4, 6938 <fwp_drop4+0x98>
    6980:	38626862 	ldrb	w2, [x3, x2]
    6984:	7100085f 	cmp	w2, #0x2
    6988:	54000220 	b.eq	69cc <fwp_drop4+0x12c>  // b.none
    698c:	7100045f 	cmp	w2, #0x1
    6990:	54fffd41 	b.ne	6938 <fwp_drop4+0x98>  // b.any
    6994:	294308a3 	ldp	w3, w2, [x5, #24]
    6998:	92403c21 	and	x1, x1, #0xffff
    699c:	9b037c21 	mul	x1, x1, x3
    69a0:	d360fc21 	lsr	x1, x1, #32
    69a4:	eb02003f 	cmp	x1, x2
    69a8:	54fffc82 	b.cs	6938 <fwp_drop4+0x98>  // b.hs, b.nlast
    69ac:	8b010084 	add	x4, x4, x1
    69b0:	39400081 	ldrb	w1, [x4]
    69b4:	7100043f 	cmp	w1, #0x1
    69b8:	54fffc01 	b.ne	6938 <fwp_drop4+0x98>  // b.any
    69bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69c0:	f94013f5 	ldr	x21, [sp, #32]
    69c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69c8:	17fff83e 	b	4ac0 <fwp_mem_free>
    69cc:	72003c3f 	tst	w1, #0xffff
    69d0:	54ffff00 	b.eq	69b0 <fwp_drop4+0x110>  // b.none
    69d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d8:	f94013f5 	ldr	x21, [sp, #32]
    69dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69e0:	d65f03c0 	ret
    69e4:	72003c3f 	tst	w1, #0xffff
    69e8:	54fff980 	b.eq	6918 <fwp_drop4+0x78>  // b.none
    69ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    69f0:	f94013f5 	ldr	x21, [sp, #32]
    69f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69f8:	d65f03c0 	ret
    69fc:	f9400414 	ldr	x20, [x0, #8]
    6a00:	97fffbed 	bl	59b4 <fwp_rc_free_arr>
    6a04:	9117c260 	add	x0, x19, #0x5f0
    6a08:	f949d801 	ldr	x1, [x0, #5040]
    6a0c:	f949ec00 	ldr	x0, [x0, #5080]
    6a10:	cb010281 	sub	x1, x20, x1
    6a14:	eb00403f 	cmp	x1, x0, lsl #16
    6a18:	54fff902 	b.cs	6938 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a1c:	aa1403e0 	mov	x0, x20
    6a20:	17ffffab 	b	68cc <fwp_drop4+0x2c>
    6a24:	ca544680 	eor	x0, x20, x20, lsr #17
    6a28:	9117c273 	add	x19, x19, #0x5f0
    6a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a30:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a34:	f94a2400 	ldr	x0, [x0, #5192]
    6a38:	b5000080 	cbnz	x0, 6a48 <fwp_drop4+0x1a8>
    6a3c:	14000010 	b	6a7c <fwp_drop4+0x1dc>
    6a40:	f9400800 	ldr	x0, [x0, #16]
    6a44:	b40001c0 	cbz	x0, 6a7c <fwp_drop4+0x1dc>
    6a48:	f9400001 	ldr	x1, [x0]
    6a4c:	eb14003f 	cmp	x1, x20
    6a50:	54ffff81 	b.ne	6a40 <fwp_drop4+0x1a0>  // b.any
    6a54:	f9400401 	ldr	x1, [x0, #8]
    6a58:	d1000421 	sub	x1, x1, #0x1
    6a5c:	f9000401 	str	x1, [x0, #8]
    6a60:	f103f83f 	cmp	x1, #0xfe
    6a64:	54fff6a1 	b.ne	6938 <fwp_drop4+0x98>  // b.any
    6a68:	aa1403e0 	mov	x0, x20
    6a6c:	97fff775 	bl	4840 <fwp_rc_forget_slot>
    6a70:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a74:	39000280 	strb	w0, [x20]
    6a78:	17ffffb0 	b	6938 <fwp_drop4+0x98>
    6a7c:	f0000020 	adrp	x0, d000 <__divti3+0x260>
    6a80:	91208000 	add	x0, x0, #0x820
    6a84:	97fff35f 	bl	3800 <fwp_trap>
    6a88:	d503201f 	nop
    6a8c:	d503201f 	nop

0000000000006a90 <fwp_caps161>:
    6a90:	34000041 	cbz	w1, 6a98 <fwp_caps161+0x8>
    6a94:	d65f03c0 	ret
    6a98:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    6a9c:	9117c063 	add	x3, x3, #0x5f0
    6aa0:	f949d861 	ldr	x1, [x3, #5040]
    6aa4:	f949ec62 	ldr	x2, [x3, #5080]
    6aa8:	cb010001 	sub	x1, x0, x1
    6aac:	eb02403f 	cmp	x1, x2, lsl #16
    6ab0:	54ffff22 	b.cs	6a94 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ab4:	d350fc22 	lsr	x2, x1, #16
    6ab8:	f949fc65 	ldr	x5, [x3, #5112]
    6abc:	8b020842 	add	x2, x2, x2, lsl #2
    6ac0:	d37df042 	lsl	x2, x2, #3
    6ac4:	8b0200a4 	add	x4, x5, x2
    6ac8:	f9401083 	ldr	x3, [x4, #32]
    6acc:	b4fffe43 	cbz	x3, 6a94 <fwp_caps161+0x4>
    6ad0:	386268a2 	ldrb	w2, [x5, x2]
    6ad4:	7100085f 	cmp	w2, #0x2
    6ad8:	540001c0 	b.eq	6b10 <fwp_caps161+0x80>  // b.none
    6adc:	7100045f 	cmp	w2, #0x1
    6ae0:	54fffda1 	b.ne	6a94 <fwp_caps161+0x4>  // b.any
    6ae4:	29430885 	ldp	w5, w2, [x4, #24]
    6ae8:	92403c21 	and	x1, x1, #0xffff
    6aec:	9b057c21 	mul	x1, x1, x5
    6af0:	d360fc21 	lsr	x1, x1, #32
    6af4:	eb02003f 	cmp	x1, x2
    6af8:	54fffce2 	b.cs	6a94 <fwp_caps161+0x4>  // b.hs, b.nlast
    6afc:	8b010063 	add	x3, x3, x1
    6b00:	39400061 	ldrb	w1, [x3]
    6b04:	7100043f 	cmp	w1, #0x1
    6b08:	54fffc61 	b.ne	6a94 <fwp_caps161+0x4>  // b.any
    6b0c:	17fff7ed 	b	4ac0 <fwp_mem_free>
    6b10:	72003c3f 	tst	w1, #0xffff
    6b14:	54ffff60 	b.eq	6b00 <fwp_caps161+0x70>  // b.none
    6b18:	d65f03c0 	ret
    6b1c:	d503201f 	nop

0000000000006b20 <fwp_args23>:
    6b20:	7100003f 	cmp	w1, #0x0
    6b24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b28:	54000041 	b.ne	6b30 <fwp_args23+0x10>  // b.any
    6b2c:	d65f03c0 	ret
    6b30:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6b34:	9117c042 	add	x2, x2, #0x5f0
    6b38:	f9400001 	ldr	x1, [x0]
    6b3c:	f949d843 	ldr	x3, [x2, #5040]
    6b40:	f949ec40 	ldr	x0, [x2, #5080]
    6b44:	cb030021 	sub	x1, x1, x3
    6b48:	eb00403f 	cmp	x1, x0, lsl #16
    6b4c:	54ffff02 	b.cs	6b2c <fwp_args23+0xc>  // b.hs, b.nlast
    6b50:	d350fc20 	lsr	x0, x1, #16
    6b54:	f949fc44 	ldr	x4, [x2, #5112]
    6b58:	8b000800 	add	x0, x0, x0, lsl #2
    6b5c:	d37df002 	lsl	x2, x0, #3
    6b60:	8b020083 	add	x3, x4, x2
    6b64:	f9401060 	ldr	x0, [x3, #32]
    6b68:	b4fffe20 	cbz	x0, 6b2c <fwp_args23+0xc>
    6b6c:	38626882 	ldrb	w2, [x4, x2]
    6b70:	7100085f 	cmp	w2, #0x2
    6b74:	54000220 	b.eq	6bb8 <fwp_args23+0x98>  // b.none
    6b78:	7100045f 	cmp	w2, #0x1
    6b7c:	54fffd81 	b.ne	6b2c <fwp_args23+0xc>  // b.any
    6b80:	29430864 	ldp	w4, w2, [x3, #24]
    6b84:	92403c21 	and	x1, x1, #0xffff
    6b88:	9b047c21 	mul	x1, x1, x4
    6b8c:	d360fc21 	lsr	x1, x1, #32
    6b90:	eb02003f 	cmp	x1, x2
    6b94:	54fffcc2 	b.cs	6b2c <fwp_args23+0xc>  // b.hs, b.nlast
    6b98:	8b010000 	add	x0, x0, x1
    6b9c:	39400001 	ldrb	w1, [x0]
    6ba0:	34fffc61 	cbz	w1, 6b2c <fwp_args23+0xc>
    6ba4:	7103f43f 	cmp	w1, #0xfd
    6ba8:	540000e8 	b.hi	6bc4 <fwp_args23+0xa4>  // b.pmore
    6bac:	11000421 	add	w1, w1, #0x1
    6bb0:	39000001 	strb	w1, [x0]
    6bb4:	d65f03c0 	ret
    6bb8:	72003c3f 	tst	w1, #0xffff
    6bbc:	54ffff00 	b.eq	6b9c <fwp_args23+0x7c>  // b.none
    6bc0:	d65f03c0 	ret
    6bc4:	17fff6d8 	b	4724 <fwp_rc_wide_dup>
    6bc8:	d503201f 	nop
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_args12>:
    6bd0:	7100003f 	cmp	w1, #0x0
    6bd4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bd8:	54000041 	b.ne	6be0 <fwp_args12+0x10>  // b.any
    6bdc:	d65f03c0 	ret
    6be0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6be4:	9117c042 	add	x2, x2, #0x5f0
    6be8:	f9400001 	ldr	x1, [x0]
    6bec:	f949d843 	ldr	x3, [x2, #5040]
    6bf0:	f949ec40 	ldr	x0, [x2, #5080]
    6bf4:	cb030021 	sub	x1, x1, x3
    6bf8:	eb00403f 	cmp	x1, x0, lsl #16
    6bfc:	54ffff02 	b.cs	6bdc <fwp_args12+0xc>  // b.hs, b.nlast
    6c00:	d350fc20 	lsr	x0, x1, #16
    6c04:	f949fc44 	ldr	x4, [x2, #5112]
    6c08:	8b000800 	add	x0, x0, x0, lsl #2
    6c0c:	d37df002 	lsl	x2, x0, #3
    6c10:	8b020083 	add	x3, x4, x2
    6c14:	f9401060 	ldr	x0, [x3, #32]
    6c18:	b4fffe20 	cbz	x0, 6bdc <fwp_args12+0xc>
    6c1c:	38626882 	ldrb	w2, [x4, x2]
    6c20:	7100085f 	cmp	w2, #0x2
    6c24:	54000220 	b.eq	6c68 <fwp_args12+0x98>  // b.none
    6c28:	7100045f 	cmp	w2, #0x1
    6c2c:	54fffd81 	b.ne	6bdc <fwp_args12+0xc>  // b.any
    6c30:	29430864 	ldp	w4, w2, [x3, #24]
    6c34:	92403c21 	and	x1, x1, #0xffff
    6c38:	9b047c21 	mul	x1, x1, x4
    6c3c:	d360fc21 	lsr	x1, x1, #32
    6c40:	eb02003f 	cmp	x1, x2
    6c44:	54fffcc2 	b.cs	6bdc <fwp_args12+0xc>  // b.hs, b.nlast
    6c48:	8b010000 	add	x0, x0, x1
    6c4c:	39400001 	ldrb	w1, [x0]
    6c50:	34fffc61 	cbz	w1, 6bdc <fwp_args12+0xc>
    6c54:	7103f43f 	cmp	w1, #0xfd
    6c58:	540000e8 	b.hi	6c74 <fwp_args12+0xa4>  // b.pmore
    6c5c:	11000421 	add	w1, w1, #0x1
    6c60:	39000001 	strb	w1, [x0]
    6c64:	d65f03c0 	ret
    6c68:	72003c3f 	tst	w1, #0xffff
    6c6c:	54ffff00 	b.eq	6c4c <fwp_args12+0x7c>  // b.none
    6c70:	d65f03c0 	ret
    6c74:	17fff6ac 	b	4724 <fwp_rc_wide_dup>
    6c78:	d503201f 	nop
    6c7c:	d503201f 	nop

0000000000006c80 <fwp_caps12>:
    6c80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c84:	910003fd 	mov	x29, sp
    6c88:	f9000bf3 	str	x19, [sp, #16]
    6c8c:	aa0003f3 	mov	x19, x0
    6c90:	b9400400 	ldr	w0, [x0, #4]
    6c94:	340004a0 	cbz	w0, 6d28 <fwp_caps12+0xa8>
    6c98:	f9400660 	ldr	x0, [x19, #8]
    6c9c:	350004e1 	cbnz	w1, 6d38 <fwp_caps12+0xb8>
    6ca0:	97fffc70 	bl	5e60 <fwp_drop0>
    6ca4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6ca8:	9117c042 	add	x2, x2, #0x5f0
    6cac:	f949d840 	ldr	x0, [x2, #5040]
    6cb0:	f949ec41 	ldr	x1, [x2, #5080]
    6cb4:	cb000260 	sub	x0, x19, x0
    6cb8:	eb01401f 	cmp	x0, x1, lsl #16
    6cbc:	54000382 	b.cs	6d2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6cc0:	d350fc01 	lsr	x1, x0, #16
    6cc4:	f949fc44 	ldr	x4, [x2, #5112]
    6cc8:	8b010821 	add	x1, x1, x1, lsl #2
    6ccc:	d37df021 	lsl	x1, x1, #3
    6cd0:	8b010083 	add	x3, x4, x1
    6cd4:	f9401062 	ldr	x2, [x3, #32]
    6cd8:	b40002a2 	cbz	x2, 6d2c <fwp_caps12+0xac>
    6cdc:	38616881 	ldrb	w1, [x4, x1]
    6ce0:	7100083f 	cmp	w1, #0x2
    6ce4:	540006c0 	b.eq	6dbc <fwp_caps12+0x13c>  // b.none
    6ce8:	7100043f 	cmp	w1, #0x1
    6cec:	54000201 	b.ne	6d2c <fwp_caps12+0xac>  // b.any
    6cf0:	29430464 	ldp	w4, w1, [x3, #24]
    6cf4:	92403c00 	and	x0, x0, #0xffff
    6cf8:	9b047c00 	mul	x0, x0, x4
    6cfc:	d360fc00 	lsr	x0, x0, #32
    6d00:	eb01001f 	cmp	x0, x1
    6d04:	54000142 	b.cs	6d2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6d08:	8b000042 	add	x2, x2, x0
    6d0c:	39400040 	ldrb	w0, [x2]
    6d10:	7100041f 	cmp	w0, #0x1
    6d14:	540000c1 	b.ne	6d2c <fwp_caps12+0xac>  // b.any
    6d18:	aa1303e0 	mov	x0, x19
    6d1c:	f9400bf3 	ldr	x19, [sp, #16]
    6d20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d24:	17fff767 	b	4ac0 <fwp_mem_free>
    6d28:	34fffbe1 	cbz	w1, 6ca4 <fwp_caps12+0x24>
    6d2c:	f9400bf3 	ldr	x19, [sp, #16]
    6d30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d34:	d65f03c0 	ret
    6d38:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6d3c:	9117c042 	add	x2, x2, #0x5f0
    6d40:	f949d843 	ldr	x3, [x2, #5040]
    6d44:	f949ec41 	ldr	x1, [x2, #5080]
    6d48:	cb030000 	sub	x0, x0, x3
    6d4c:	eb01401f 	cmp	x0, x1, lsl #16
    6d50:	54fffee2 	b.cs	6d2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6d54:	d350fc01 	lsr	x1, x0, #16
    6d58:	f949fc44 	ldr	x4, [x2, #5112]
    6d5c:	8b010821 	add	x1, x1, x1, lsl #2
    6d60:	d37df021 	lsl	x1, x1, #3
    6d64:	8b010083 	add	x3, x4, x1
    6d68:	f9401062 	ldr	x2, [x3, #32]
    6d6c:	b4fffe02 	cbz	x2, 6d2c <fwp_caps12+0xac>
    6d70:	38616881 	ldrb	w1, [x4, x1]
    6d74:	7100083f 	cmp	w1, #0x2
    6d78:	54000280 	b.eq	6dc8 <fwp_caps12+0x148>  // b.none
    6d7c:	7100043f 	cmp	w1, #0x1
    6d80:	54fffd61 	b.ne	6d2c <fwp_caps12+0xac>  // b.any
    6d84:	92403c01 	and	x1, x0, #0xffff
    6d88:	29430064 	ldp	w4, w0, [x3, #24]
    6d8c:	9b047c21 	mul	x1, x1, x4
    6d90:	d360fc21 	lsr	x1, x1, #32
    6d94:	eb00003f 	cmp	x1, x0
    6d98:	54fffca2 	b.cs	6d2c <fwp_caps12+0xac>  // b.hs, b.nlast
    6d9c:	8b010042 	add	x2, x2, x1
    6da0:	39400040 	ldrb	w0, [x2]
    6da4:	34fffc40 	cbz	w0, 6d2c <fwp_caps12+0xac>
    6da8:	7103f41f 	cmp	w0, #0xfd
    6dac:	54000148 	b.hi	6dd4 <fwp_caps12+0x154>  // b.pmore
    6db0:	11000400 	add	w0, w0, #0x1
    6db4:	39000040 	strb	w0, [x2]
    6db8:	17ffffdd 	b	6d2c <fwp_caps12+0xac>
    6dbc:	72003c1f 	tst	w0, #0xffff
    6dc0:	54fffb61 	b.ne	6d2c <fwp_caps12+0xac>  // b.any
    6dc4:	17ffffd2 	b	6d0c <fwp_caps12+0x8c>
    6dc8:	72003c1f 	tst	w0, #0xffff
    6dcc:	54fffb01 	b.ne	6d2c <fwp_caps12+0xac>  // b.any
    6dd0:	17fffff4 	b	6da0 <fwp_caps12+0x120>
    6dd4:	f9400bf3 	ldr	x19, [sp, #16]
    6dd8:	aa0203e0 	mov	x0, x2
    6ddc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6de0:	17fff651 	b	4724 <fwp_rc_wide_dup>

0000000000006de4 <fwp_drop2>:
    6de4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6de8:	910003fd 	mov	x29, sp
    6dec:	a9025bf5 	stp	x21, x22, [sp, #32]
    6df0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    6df4:	9117c2d5 	add	x21, x22, #0x5f0
    6df8:	a90153f3 	stp	x19, x20, [sp, #16]
    6dfc:	aa0003f3 	mov	x19, x0
    6e00:	f949daa1 	ldr	x1, [x21, #5040]
    6e04:	f949eea0 	ldr	x0, [x21, #5080]
    6e08:	cb010261 	sub	x1, x19, x1
    6e0c:	eb00403f 	cmp	x1, x0, lsl #16
    6e10:	54000382 	b.cs	6e80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e14:	d350fc22 	lsr	x2, x1, #16
    6e18:	f949fea3 	ldr	x3, [x21, #5112]
    6e1c:	8b020842 	add	x2, x2, x2, lsl #2
    6e20:	d37df042 	lsl	x2, x2, #3
    6e24:	8b020060 	add	x0, x3, x2
    6e28:	f9401014 	ldr	x20, [x0, #32]
    6e2c:	b40002b4 	cbz	x20, 6e80 <fwp_drop2+0x9c>
    6e30:	38626862 	ldrb	w2, [x3, x2]
    6e34:	7100085f 	cmp	w2, #0x2
    6e38:	540002c0 	b.eq	6e90 <fwp_drop2+0xac>  // b.none
    6e3c:	7100045f 	cmp	w2, #0x1
    6e40:	54000201 	b.ne	6e80 <fwp_drop2+0x9c>  // b.any
    6e44:	29430002 	ldp	w2, w0, [x0, #24]
    6e48:	92403c21 	and	x1, x1, #0xffff
    6e4c:	9b027c21 	mul	x1, x1, x2
    6e50:	d360fc21 	lsr	x1, x1, #32
    6e54:	eb00003f 	cmp	x1, x0
    6e58:	54000142 	b.cs	6e80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e5c:	8b010294 	add	x20, x20, x1
    6e60:	39400280 	ldrb	w0, [x20]
    6e64:	340000e0 	cbz	w0, 6e80 <fwp_drop2+0x9c>
    6e68:	7100041f 	cmp	w0, #0x1
    6e6c:	540001e0 	b.eq	6ea8 <fwp_drop2+0xc4>  // b.none
    6e70:	7103fc1f 	cmp	w0, #0xff
    6e74:	540007e0 	b.eq	6f70 <fwp_drop2+0x18c>  // b.none
    6e78:	51000400 	sub	w0, w0, #0x1
    6e7c:	39000280 	strb	w0, [x20]
    6e80:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e84:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6e88:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e8c:	d65f03c0 	ret
    6e90:	72003c3f 	tst	w1, #0xffff
    6e94:	54fffe60 	b.eq	6e60 <fwp_drop2+0x7c>  // b.none
    6e98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ea0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ea4:	d65f03c0 	ret
    6ea8:	9117c2c2 	add	x2, x22, #0x5f0
    6eac:	f9400660 	ldr	x0, [x19, #8]
    6eb0:	f949d841 	ldr	x1, [x2, #5040]
    6eb4:	f949ec42 	ldr	x2, [x2, #5080]
    6eb8:	cb010001 	sub	x1, x0, x1
    6ebc:	eb02403f 	cmp	x1, x2, lsl #16
    6ec0:	54000382 	b.cs	6f30 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6ec4:	d350fc22 	lsr	x2, x1, #16
    6ec8:	8b020842 	add	x2, x2, x2, lsl #2
    6ecc:	d37df042 	lsl	x2, x2, #3
    6ed0:	8b020064 	add	x4, x3, x2
    6ed4:	f9401094 	ldr	x20, [x4, #32]
    6ed8:	b40002d4 	cbz	x20, 6f30 <fwp_drop2+0x14c>
    6edc:	38626862 	ldrb	w2, [x3, x2]
    6ee0:	7100085f 	cmp	w2, #0x2
    6ee4:	54000400 	b.eq	6f64 <fwp_drop2+0x180>  // b.none
    6ee8:	7100045f 	cmp	w2, #0x1
    6eec:	54000221 	b.ne	6f30 <fwp_drop2+0x14c>  // b.any
    6ef0:	29430883 	ldp	w3, w2, [x4, #24]
    6ef4:	92403c21 	and	x1, x1, #0xffff
    6ef8:	9b037c21 	mul	x1, x1, x3
    6efc:	d360fc21 	lsr	x1, x1, #32
    6f00:	eb02003f 	cmp	x1, x2
    6f04:	54000162 	b.cs	6f30 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6f08:	8b010294 	add	x20, x20, x1
    6f0c:	39400281 	ldrb	w1, [x20]
    6f10:	34000101 	cbz	w1, 6f30 <fwp_drop2+0x14c>
    6f14:	7100043f 	cmp	w1, #0x1
    6f18:	54000220 	b.eq	6f5c <fwp_drop2+0x178>  // b.none
    6f1c:	7103fc3f 	cmp	w1, #0xff
    6f20:	540005a0 	b.eq	6fd4 <fwp_drop2+0x1f0>  // b.none
    6f24:	51000421 	sub	w1, w1, #0x1
    6f28:	39000281 	strb	w1, [x20]
    6f2c:	d503201f 	nop
    6f30:	f9400a74 	ldr	x20, [x19, #16]
    6f34:	aa1303e0 	mov	x0, x19
    6f38:	97fffa9f 	bl	59b4 <fwp_rc_free_arr>
    6f3c:	9117c2c0 	add	x0, x22, #0x5f0
    6f40:	f949d801 	ldr	x1, [x0, #5040]
    6f44:	f949ec00 	ldr	x0, [x0, #5080]
    6f48:	cb010281 	sub	x1, x20, x1
    6f4c:	eb00403f 	cmp	x1, x0, lsl #16
    6f50:	54fff982 	b.cs	6e80 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6f54:	aa1403f3 	mov	x19, x20
    6f58:	17ffffaf 	b	6e14 <fwp_drop2+0x30>
    6f5c:	97fffa96 	bl	59b4 <fwp_rc_free_arr>
    6f60:	17fffff4 	b	6f30 <fwp_drop2+0x14c>
    6f64:	72003c3f 	tst	w1, #0xffff
    6f68:	54fffe41 	b.ne	6f30 <fwp_drop2+0x14c>  // b.any
    6f6c:	17ffffe8 	b	6f0c <fwp_drop2+0x128>
    6f70:	ca544681 	eor	x1, x20, x20, lsr #17
    6f74:	9117c2c0 	add	x0, x22, #0x5f0
    6f78:	ca412421 	eor	x1, x1, x1, lsr #9
    6f7c:	8b210c01 	add	x1, x0, w1, uxtb #3
    6f80:	f94a2420 	ldr	x0, [x1, #5192]
    6f84:	b5000080 	cbnz	x0, 6f94 <fwp_drop2+0x1b0>
    6f88:	14000010 	b	6fc8 <fwp_drop2+0x1e4>
    6f8c:	f9400800 	ldr	x0, [x0, #16]
    6f90:	b40001c0 	cbz	x0, 6fc8 <fwp_drop2+0x1e4>
    6f94:	f9400001 	ldr	x1, [x0]
    6f98:	eb14003f 	cmp	x1, x20
    6f9c:	54ffff81 	b.ne	6f8c <fwp_drop2+0x1a8>  // b.any
    6fa0:	f9400401 	ldr	x1, [x0, #8]
    6fa4:	d1000421 	sub	x1, x1, #0x1
    6fa8:	f9000401 	str	x1, [x0, #8]
    6fac:	f103f83f 	cmp	x1, #0xfe
    6fb0:	54fff681 	b.ne	6e80 <fwp_drop2+0x9c>  // b.any
    6fb4:	aa1403e0 	mov	x0, x20
    6fb8:	97fff622 	bl	4840 <fwp_rc_forget_slot>
    6fbc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6fc0:	39000280 	strb	w0, [x20]
    6fc4:	17ffffaf 	b	6e80 <fwp_drop2+0x9c>
    6fc8:	f0000020 	adrp	x0, d000 <__divti3+0x260>
    6fcc:	91208000 	add	x0, x0, #0x820
    6fd0:	97fff20c 	bl	3800 <fwp_trap>
    6fd4:	ca544680 	eor	x0, x20, x20, lsr #17
    6fd8:	9117c2c1 	add	x1, x22, #0x5f0
    6fdc:	ca402400 	eor	x0, x0, x0, lsr #9
    6fe0:	8b200c20 	add	x0, x1, w0, uxtb #3
    6fe4:	f94a2400 	ldr	x0, [x0, #5192]
    6fe8:	b5000080 	cbnz	x0, 6ff8 <fwp_drop2+0x214>
    6fec:	17fffff7 	b	6fc8 <fwp_drop2+0x1e4>
    6ff0:	f9400800 	ldr	x0, [x0, #16]
    6ff4:	b4fffea0 	cbz	x0, 6fc8 <fwp_drop2+0x1e4>
    6ff8:	f9400001 	ldr	x1, [x0]
    6ffc:	eb14003f 	cmp	x1, x20
    7000:	54ffff81 	b.ne	6ff0 <fwp_drop2+0x20c>  // b.any
    7004:	f9400401 	ldr	x1, [x0, #8]
    7008:	d1000421 	sub	x1, x1, #0x1
    700c:	f9000401 	str	x1, [x0, #8]
    7010:	f103f83f 	cmp	x1, #0xfe
    7014:	54fff8e1 	b.ne	6f30 <fwp_drop2+0x14c>  // b.any
    7018:	aa1403e0 	mov	x0, x20
    701c:	97fff609 	bl	4840 <fwp_rc_forget_slot>
    7020:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7024:	39000280 	strb	w0, [x20]
    7028:	17ffffc2 	b	6f30 <fwp_drop2+0x14c>
    702c:	d503201f 	nop

0000000000007030 <fwp_arg_drop23>:
    7030:	7100003f 	cmp	w1, #0x0
    7034:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7038:	54000041 	b.ne	7040 <fwp_arg_drop23+0x10>  // b.any
    703c:	d65f03c0 	ret
    7040:	f9400000 	ldr	x0, [x0]
    7044:	17ffff68 	b	6de4 <fwp_drop2>
    7048:	d503201f 	nop
    704c:	d503201f 	nop

0000000000007050 <fwp_caps23>:
    7050:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7054:	910003fd 	mov	x29, sp
    7058:	f9000bf3 	str	x19, [sp, #16]
    705c:	aa0003f3 	mov	x19, x0
    7060:	b9400400 	ldr	w0, [x0, #4]
    7064:	340004a0 	cbz	w0, 70f8 <fwp_caps23+0xa8>
    7068:	f9400660 	ldr	x0, [x19, #8]
    706c:	350004e1 	cbnz	w1, 7108 <fwp_caps23+0xb8>
    7070:	97ffff5d 	bl	6de4 <fwp_drop2>
    7074:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    7078:	9117c042 	add	x2, x2, #0x5f0
    707c:	f949d840 	ldr	x0, [x2, #5040]
    7080:	f949ec41 	ldr	x1, [x2, #5080]
    7084:	cb000260 	sub	x0, x19, x0
    7088:	eb01401f 	cmp	x0, x1, lsl #16
    708c:	54000382 	b.cs	70fc <fwp_caps23+0xac>  // b.hs, b.nlast
    7090:	d350fc01 	lsr	x1, x0, #16
    7094:	f949fc44 	ldr	x4, [x2, #5112]
    7098:	8b010821 	add	x1, x1, x1, lsl #2
    709c:	d37df021 	lsl	x1, x1, #3
    70a0:	8b010083 	add	x3, x4, x1
    70a4:	f9401062 	ldr	x2, [x3, #32]
    70a8:	b40002a2 	cbz	x2, 70fc <fwp_caps23+0xac>
    70ac:	38616881 	ldrb	w1, [x4, x1]
    70b0:	7100083f 	cmp	w1, #0x2
    70b4:	540006c0 	b.eq	718c <fwp_caps23+0x13c>  // b.none
    70b8:	7100043f 	cmp	w1, #0x1
    70bc:	54000201 	b.ne	70fc <fwp_caps23+0xac>  // b.any
    70c0:	29430464 	ldp	w4, w1, [x3, #24]
    70c4:	92403c00 	and	x0, x0, #0xffff
    70c8:	9b047c00 	mul	x0, x0, x4
    70cc:	d360fc00 	lsr	x0, x0, #32
    70d0:	eb01001f 	cmp	x0, x1
    70d4:	54000142 	b.cs	70fc <fwp_caps23+0xac>  // b.hs, b.nlast
    70d8:	8b000042 	add	x2, x2, x0
    70dc:	39400040 	ldrb	w0, [x2]
    70e0:	7100041f 	cmp	w0, #0x1
    70e4:	540000c1 	b.ne	70fc <fwp_caps23+0xac>  // b.any
    70e8:	aa1303e0 	mov	x0, x19
    70ec:	f9400bf3 	ldr	x19, [sp, #16]
    70f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70f4:	17fff673 	b	4ac0 <fwp_mem_free>
    70f8:	34fffbe1 	cbz	w1, 7074 <fwp_caps23+0x24>
    70fc:	f9400bf3 	ldr	x19, [sp, #16]
    7100:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7104:	d65f03c0 	ret
    7108:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    710c:	9117c042 	add	x2, x2, #0x5f0
    7110:	f949d843 	ldr	x3, [x2, #5040]
    7114:	f949ec41 	ldr	x1, [x2, #5080]
    7118:	cb030000 	sub	x0, x0, x3
    711c:	eb01401f 	cmp	x0, x1, lsl #16
    7120:	54fffee2 	b.cs	70fc <fwp_caps23+0xac>  // b.hs, b.nlast
    7124:	d350fc01 	lsr	x1, x0, #16
    7128:	f949fc44 	ldr	x4, [x2, #5112]
    712c:	8b010821 	add	x1, x1, x1, lsl #2
    7130:	d37df021 	lsl	x1, x1, #3
    7134:	8b010083 	add	x3, x4, x1
    7138:	f9401062 	ldr	x2, [x3, #32]
    713c:	b4fffe02 	cbz	x2, 70fc <fwp_caps23+0xac>
    7140:	38616881 	ldrb	w1, [x4, x1]
    7144:	7100083f 	cmp	w1, #0x2
    7148:	54000280 	b.eq	7198 <fwp_caps23+0x148>  // b.none
    714c:	7100043f 	cmp	w1, #0x1
    7150:	54fffd61 	b.ne	70fc <fwp_caps23+0xac>  // b.any
    7154:	92403c01 	and	x1, x0, #0xffff
    7158:	29430064 	ldp	w4, w0, [x3, #24]
    715c:	9b047c21 	mul	x1, x1, x4
    7160:	d360fc21 	lsr	x1, x1, #32
    7164:	eb00003f 	cmp	x1, x0
    7168:	54fffca2 	b.cs	70fc <fwp_caps23+0xac>  // b.hs, b.nlast
    716c:	8b010042 	add	x2, x2, x1
    7170:	39400040 	ldrb	w0, [x2]
    7174:	34fffc40 	cbz	w0, 70fc <fwp_caps23+0xac>
    7178:	7103f41f 	cmp	w0, #0xfd
    717c:	54000148 	b.hi	71a4 <fwp_caps23+0x154>  // b.pmore
    7180:	11000400 	add	w0, w0, #0x1
    7184:	39000040 	strb	w0, [x2]
    7188:	17ffffdd 	b	70fc <fwp_caps23+0xac>
    718c:	72003c1f 	tst	w0, #0xffff
    7190:	54fffb61 	b.ne	70fc <fwp_caps23+0xac>  // b.any
    7194:	17ffffd2 	b	70dc <fwp_caps23+0x8c>
    7198:	72003c1f 	tst	w0, #0xffff
    719c:	54fffb01 	b.ne	70fc <fwp_caps23+0xac>  // b.any
    71a0:	17fffff4 	b	7170 <fwp_caps23+0x120>
    71a4:	f9400bf3 	ldr	x19, [sp, #16]
    71a8:	aa0203e0 	mov	x0, x2
    71ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71b0:	17fff55d 	b	4724 <fwp_rc_wide_dup>

00000000000071b4 <f23>:
    71b4:	d101c3ff 	sub	sp, sp, #0x70
    71b8:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    71bc:	f947f421 	ldr	x1, [x1, #4072]
    71c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    71c4:	910083fd 	add	x29, sp, #0x20
    71c8:	a90563f7 	stp	x23, x24, [sp, #80]
    71cc:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xbf0>
    71d0:	9117c2e3 	add	x3, x23, #0x5f0
    71d4:	a90353f3 	stp	x19, x20, [sp, #48]
    71d8:	a9045bf5 	stp	x21, x22, [sp, #64]
    71dc:	aa0003f6 	mov	x22, x0
    71e0:	a9066bf9 	stp	x25, x26, [sp, #96]
    71e4:	f949ec62 	ldr	x2, [x3, #5080]
    71e8:	f9400024 	ldr	x4, [x1]
    71ec:	f9000fe4 	str	x4, [sp, #24]
    71f0:	d2800004 	mov	x4, #0x0                   	// #0
    71f4:	f949d861 	ldr	x1, [x3, #5040]
    71f8:	d370bc42 	lsl	x2, x2, #16
    71fc:	b40015a0 	cbz	x0, 74b0 <f23+0x2fc>
    7200:	f9400818 	ldr	x24, [x0, #16]
    7204:	cb010301 	sub	x1, x24, x1
    7208:	eb02003f 	cmp	x1, x2
    720c:	54000362 	b.cs	7278 <f23+0xc4>  // b.hs, b.nlast
    7210:	f949fc60 	ldr	x0, [x3, #5112]
    7214:	d350fc22 	lsr	x2, x1, #16
    7218:	8b020842 	add	x2, x2, x2, lsl #2
    721c:	8b020c02 	add	x2, x0, x2, lsl #3
    7220:	f9401040 	ldr	x0, [x2, #32]
    7224:	b40002a0 	cbz	x0, 7278 <f23+0xc4>
    7228:	39400043 	ldrb	w3, [x2]
    722c:	7100087f 	cmp	w3, #0x2
    7230:	540013a0 	b.eq	74a4 <f23+0x2f0>  // b.none
    7234:	7100047f 	cmp	w3, #0x1
    7238:	540001c1 	b.ne	7270 <f23+0xbc>  // b.any
    723c:	29430843 	ldp	w3, w2, [x2, #24]
    7240:	92403c21 	and	x1, x1, #0xffff
    7244:	9b037c21 	mul	x1, x1, x3
    7248:	d360fc21 	lsr	x1, x1, #32
    724c:	eb02003f 	cmp	x1, x2
    7250:	54000102 	b.cs	7270 <f23+0xbc>  // b.hs, b.nlast
    7254:	8b010000 	add	x0, x0, x1
    7258:	39400001 	ldrb	w1, [x0]
    725c:	340000a1 	cbz	w1, 7270 <f23+0xbc>
    7260:	7103f43f 	cmp	w1, #0xfd
    7264:	54001688 	b.hi	7534 <f23+0x380>  // b.pmore
    7268:	11000421 	add	w1, w1, #0x1
    726c:	39000001 	strb	w1, [x0]
    7270:	d2800000 	mov	x0, #0x0                   	// #0
    7274:	b40000d6 	cbz	x22, 728c <f23+0xd8>
    7278:	aa1603e1 	mov	x1, x22
    727c:	d2800000 	mov	x0, #0x0                   	// #0
    7280:	f9400821 	ldr	x1, [x1, #16]
    7284:	91000400 	add	x0, x0, #0x1
    7288:	b5ffffc1 	cbnz	x1, 7280 <f23+0xcc>
    728c:	b40011b8 	cbz	x24, 74c0 <f23+0x30c>
    7290:	aa1803e1 	mov	x1, x24
    7294:	d2800002 	mov	x2, #0x0                   	// #0
    7298:	f9400821 	ldr	x1, [x1, #16]
    729c:	91000442 	add	x2, x2, #0x1
    72a0:	b5ffffc1 	cbnz	x1, 7298 <f23+0xe4>
    72a4:	eb00005f 	cmp	x2, x0
    72a8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    72ac:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    72b0:	eb01033f 	cmp	x25, x1
    72b4:	54001468 	b.hi	7540 <f23+0x38c>  // b.pmore
    72b8:	d37ffb33 	lsl	x19, x25, #1
    72bc:	52800041 	mov	w1, #0x2                   	// #2
    72c0:	91000660 	add	x0, x19, #0x1
    72c4:	d37df000 	lsl	x0, x0, #3
    72c8:	97fff71e 	bl	4f40 <fwp_heap_alloc>
    72cc:	9117c2e1 	add	x1, x23, #0x5f0
    72d0:	aa0003fa 	mov	x26, x0
    72d4:	f9000013 	str	x19, [x0]
    72d8:	aa0103e0 	mov	x0, x1
    72dc:	f949d821 	ldr	x1, [x1, #5040]
    72e0:	f949ec00 	ldr	x0, [x0, #5080]
    72e4:	cb010341 	sub	x1, x26, x1
    72e8:	eb00403f 	cmp	x1, x0, lsl #16
    72ec:	54000342 	b.cs	7354 <f23+0x1a0>  // b.hs, b.nlast
    72f0:	9117c2e2 	add	x2, x23, #0x5f0
    72f4:	d350fc20 	lsr	x0, x1, #16
    72f8:	8b000800 	add	x0, x0, x0, lsl #2
    72fc:	f949fc43 	ldr	x3, [x2, #5112]
    7300:	d37df002 	lsl	x2, x0, #3
    7304:	8b020060 	add	x0, x3, x2
    7308:	f9401013 	ldr	x19, [x0, #32]
    730c:	b4000253 	cbz	x19, 7354 <f23+0x1a0>
    7310:	38626862 	ldrb	w2, [x3, x2]
    7314:	7100085f 	cmp	w2, #0x2
    7318:	54000c00 	b.eq	7498 <f23+0x2e4>  // b.none
    731c:	7100045f 	cmp	w2, #0x1
    7320:	540001a1 	b.ne	7354 <f23+0x1a0>  // b.any
    7324:	29430002 	ldp	w2, w0, [x0, #24]
    7328:	92403c21 	and	x1, x1, #0xffff
    732c:	9b027c21 	mul	x1, x1, x2
    7330:	d360fc21 	lsr	x1, x1, #32
    7334:	eb00003f 	cmp	x1, x0
    7338:	540000e2 	b.cs	7354 <f23+0x1a0>  // b.hs, b.nlast
    733c:	8b010273 	add	x19, x19, x1
    7340:	39400260 	ldrb	w0, [x19]
    7344:	7103fc1f 	cmp	w0, #0xff
    7348:	54000da0 	b.eq	74fc <f23+0x348>  // b.none
    734c:	52800020 	mov	w0, #0x1                   	// #1
    7350:	39000260 	strb	w0, [x19]
    7354:	b4000259 	cbz	x25, 739c <f23+0x1e8>
    7358:	8b191359 	add	x25, x26, x25, lsl #4
    735c:	aa1a03f3 	mov	x19, x26
    7360:	aa1603f5 	mov	x21, x22
    7364:	aa1803f4 	mov	x20, x24
    7368:	f9400683 	ldr	x3, [x20, #8]
    736c:	f94006a2 	ldr	x2, [x21, #8]
    7370:	f9400861 	ldr	x1, [x3, #16]
    7374:	f9400840 	ldr	x0, [x2, #16]
    7378:	fd400461 	ldr	d1, [x3, #8]
    737c:	fd400440 	ldr	d0, [x2, #8]
    7380:	97fff870 	bl	5540 <w107>
    7384:	f9000660 	str	x0, [x19, #8]
    7388:	f8010e61 	str	x1, [x19, #16]!
    738c:	f9400a94 	ldr	x20, [x20, #16]
    7390:	f9400ab5 	ldr	x21, [x21, #16]
    7394:	eb13033f 	cmp	x25, x19
    7398:	54fffe81 	b.ne	7368 <f23+0x1b4>  // b.any
    739c:	aa1803e0 	mov	x0, x24
    73a0:	97fffe91 	bl	6de4 <fwp_drop2>
    73a4:	aa1603e0 	mov	x0, x22
    73a8:	97fffe8f 	bl	6de4 <fwp_drop2>
    73ac:	9117c2f7 	add	x23, x23, #0x5f0
    73b0:	aa1a03e0 	mov	x0, x26
    73b4:	97fff8b7 	bl	5690 <w164.constprop.0>
    73b8:	aa0103f3 	mov	x19, x1
    73bc:	aa0003f4 	mov	x20, x0
    73c0:	aa1a03e0 	mov	x0, x26
    73c4:	97fffd37 	bl	68a0 <fwp_drop4>
    73c8:	a900cff4 	stp	x20, x19, [sp, #8]
    73cc:	910023e1 	add	x1, sp, #0x8
    73d0:	52800000 	mov	w0, #0x0                   	// #0
    73d4:	97fff8db 	bl	5740 <fwp_data.part.0.constprop.0>
    73d8:	f949dae1 	ldr	x1, [x23, #5040]
    73dc:	aa0003f3 	mov	x19, x0
    73e0:	f949eee0 	ldr	x0, [x23, #5080]
    73e4:	cb010261 	sub	x1, x19, x1
    73e8:	eb00403f 	cmp	x1, x0, lsl #16
    73ec:	54000322 	b.cs	7450 <f23+0x29c>  // b.hs, b.nlast
    73f0:	d350fc22 	lsr	x2, x1, #16
    73f4:	f949fee3 	ldr	x3, [x23, #5112]
    73f8:	8b020842 	add	x2, x2, x2, lsl #2
    73fc:	d37df042 	lsl	x2, x2, #3
    7400:	8b020060 	add	x0, x3, x2
    7404:	f9401014 	ldr	x20, [x0, #32]
    7408:	b4000254 	cbz	x20, 7450 <f23+0x29c>
    740c:	38626862 	ldrb	w2, [x3, x2]
    7410:	7100085f 	cmp	w2, #0x2
    7414:	540003c0 	b.eq	748c <f23+0x2d8>  // b.none
    7418:	7100045f 	cmp	w2, #0x1
    741c:	540001a1 	b.ne	7450 <f23+0x29c>  // b.any
    7420:	29430002 	ldp	w2, w0, [x0, #24]
    7424:	92403c21 	and	x1, x1, #0xffff
    7428:	9b027c21 	mul	x1, x1, x2
    742c:	d360fc21 	lsr	x1, x1, #32
    7430:	eb00003f 	cmp	x1, x0
    7434:	540000e2 	b.cs	7450 <f23+0x29c>  // b.hs, b.nlast
    7438:	8b010294 	add	x20, x20, x1
    743c:	39400280 	ldrb	w0, [x20]
    7440:	7103fc1f 	cmp	w0, #0xff
    7444:	54000620 	b.eq	7508 <f23+0x354>  // b.none
    7448:	52800020 	mov	w0, #0x1                   	// #1
    744c:	39000280 	strb	w0, [x20]
    7450:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7454:	f947f400 	ldr	x0, [x0, #4072]
    7458:	f9400fe2 	ldr	x2, [sp, #24]
    745c:	f9400001 	ldr	x1, [x0]
    7460:	eb010042 	subs	x2, x2, x1
    7464:	d2800001 	mov	x1, #0x0                   	// #0
    7468:	540006a1 	b.ne	753c <f23+0x388>  // b.any
    746c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7470:	aa1303e0 	mov	x0, x19
    7474:	a94353f3 	ldp	x19, x20, [sp, #48]
    7478:	a9445bf5 	ldp	x21, x22, [sp, #64]
    747c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7480:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7484:	9101c3ff 	add	sp, sp, #0x70
    7488:	d65f03c0 	ret
    748c:	72003c3f 	tst	w1, #0xffff
    7490:	54fffe01 	b.ne	7450 <f23+0x29c>  // b.any
    7494:	17ffffea 	b	743c <f23+0x288>
    7498:	72003c3f 	tst	w1, #0xffff
    749c:	54fff5c1 	b.ne	7354 <f23+0x1a0>  // b.any
    74a0:	17ffffa8 	b	7340 <f23+0x18c>
    74a4:	72003c3f 	tst	w1, #0xffff
    74a8:	54ffee41 	b.ne	7270 <f23+0xbc>  // b.any
    74ac:	17ffff6b 	b	7258 <f23+0xa4>
    74b0:	cb0103e1 	neg	x1, x1
    74b4:	eb02003f 	cmp	x1, x2
    74b8:	540002e3 	b.cc	7514 <f23+0x360>  // b.lo, b.ul, b.last
    74bc:	d503201f 	nop
    74c0:	52800041 	mov	w1, #0x2                   	// #2
    74c4:	d2800100 	mov	x0, #0x8                   	// #8
    74c8:	97fff69e 	bl	4f40 <fwp_heap_alloc>
    74cc:	aa0003e1 	mov	x1, x0
    74d0:	9117c2e0 	add	x0, x23, #0x5f0
    74d4:	aa0103fa 	mov	x26, x1
    74d8:	d2800018 	mov	x24, #0x0                   	// #0
    74dc:	f900003f 	str	xzr, [x1]
    74e0:	f949d801 	ldr	x1, [x0, #5040]
    74e4:	f949ec00 	ldr	x0, [x0, #5080]
    74e8:	cb010341 	sub	x1, x26, x1
    74ec:	eb00403f 	cmp	x1, x0, lsl #16
    74f0:	54fff562 	b.cs	739c <f23+0x1e8>  // b.hs, b.nlast
    74f4:	d2800019 	mov	x25, #0x0                   	// #0
    74f8:	17ffff7e 	b	72f0 <f23+0x13c>
    74fc:	aa1303e0 	mov	x0, x19
    7500:	97fff4d0 	bl	4840 <fwp_rc_forget_slot>
    7504:	17ffff92 	b	734c <f23+0x198>
    7508:	aa1403e0 	mov	x0, x20
    750c:	97fff4cd 	bl	4840 <fwp_rc_forget_slot>
    7510:	17ffffce 	b	7448 <f23+0x294>
    7514:	f949fc62 	ldr	x2, [x3, #5112]
    7518:	d350fc20 	lsr	x0, x1, #16
    751c:	8b000800 	add	x0, x0, x0, lsl #2
    7520:	8b000c42 	add	x2, x2, x0, lsl #3
    7524:	f9401040 	ldr	x0, [x2, #32]
    7528:	b4fffcc0 	cbz	x0, 74c0 <f23+0x30c>
    752c:	d2800018 	mov	x24, #0x0                   	// #0
    7530:	17ffff3e 	b	7228 <f23+0x74>
    7534:	97fff47c 	bl	4724 <fwp_rc_wide_dup>
    7538:	17ffff4e 	b	7270 <f23+0xbc>
    753c:	97ffecd1 	bl	2880 <__stack_chk_fail@plt>
    7540:	d0000020 	adrp	x0, d000 <__divti3+0x260>
    7544:	91258000 	add	x0, x0, #0x960
    7548:	97fff0ae 	bl	3800 <fwp_trap>
    754c:	d503201f 	nop

0000000000007550 <fwp_owned_entry23>:
    7550:	f9400000 	ldr	x0, [x0]
    7554:	17ffff18 	b	71b4 <f23>
    7558:	d503201f 	nop
    755c:	d503201f 	nop

0000000000007560 <e23>:
    7560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7564:	910003fd 	mov	x29, sp
    7568:	f9000bf3 	str	x19, [sp, #16]
    756c:	f9400013 	ldr	x19, [x0]
    7570:	aa1303e0 	mov	x0, x19
    7574:	97fff8bb 	bl	5860 <fwp_rc_share>
    7578:	aa1303e0 	mov	x0, x19
    757c:	97ffff0e 	bl	71b4 <f23>
    7580:	aa0003f3 	mov	x19, x0
    7584:	97fff8b7 	bl	5860 <fwp_rc_share>
    7588:	aa1303e0 	mov	x0, x19
    758c:	f9400bf3 	ldr	x19, [sp, #16]
    7590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7594:	d65f03c0 	ret
    7598:	d503201f 	nop
    759c:	d503201f 	nop

00000000000075a0 <f12>:
    75a0:	d104c3ff 	sub	sp, sp, #0x130
    75a4:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    75a8:	f947f442 	ldr	x2, [x2, #4072]
    75ac:	910103e8 	add	x8, sp, #0x40
    75b0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    75b4:	910303fd 	add	x29, sp, #0xc0
    75b8:	9100e3e9 	add	x9, sp, #0x38
    75bc:	a90d53f3 	stp	x19, x20, [sp, #208]
    75c0:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    75c4:	9117c263 	add	x3, x19, #0x5f0
    75c8:	b00000d4 	adrp	x20, 20000 <__data_start>
    75cc:	9101c284 	add	x4, x20, #0x70
    75d0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    75d4:	f0fffff6 	adrp	x22, 6000 <fwp_closure_drop+0x30>
    75d8:	aa0003f5 	mov	x21, x0
    75dc:	f949d861 	ldr	x1, [x3, #5040]
    75e0:	a90f63f7 	stp	x23, x24, [sp, #240]
    75e4:	b00000d7 	adrp	x23, 20000 <__data_start>
    75e8:	f949ec65 	ldr	x5, [x3, #5080]
    75ec:	a9106bf9 	stp	x25, x26, [sp, #256]
    75f0:	910042f7 	add	x23, x23, #0x10
    75f4:	a91173fb 	stp	x27, x28, [sp, #272]
    75f8:	9100e2f7 	add	x23, x23, #0x38
    75fc:	cb0102e1 	sub	x1, x23, x1
    7600:	f9419886 	ldr	x6, [x4, #816]
    7604:	fd0093e8 	str	d8, [sp, #288]
    7608:	f9400047 	ldr	x7, [x2]
    760c:	f9005fe7 	str	x7, [sp, #184]
    7610:	d2800007 	mov	x7, #0x0                   	// #0
    7614:	910d42c2 	add	x2, x22, #0x350
    7618:	12800007 	mov	w7, #0xffffffff            	// #-1
    761c:	a901a3e9 	stp	x9, x8, [sp, #24]
    7620:	b9003be7 	str	w7, [sp, #56]
    7624:	a9040be6 	stp	x6, x2, [sp, #64]
    7628:	f9002be9 	str	x9, [sp, #80]
    762c:	f9019888 	str	x8, [x4, #816]
    7630:	eb05403f 	cmp	x1, x5, lsl #16
    7634:	54000342 	b.cs	769c <f12+0xfc>  // b.hs, b.nlast
    7638:	d350fc20 	lsr	x0, x1, #16
    763c:	f949fc64 	ldr	x4, [x3, #5112]
    7640:	8b000800 	add	x0, x0, x0, lsl #2
    7644:	d37df002 	lsl	x2, x0, #3
    7648:	8b020083 	add	x3, x4, x2
    764c:	f9401060 	ldr	x0, [x3, #32]
    7650:	b4000260 	cbz	x0, 769c <f12+0xfc>
    7654:	38626882 	ldrb	w2, [x4, x2]
    7658:	7100085f 	cmp	w2, #0x2
    765c:	54006da0 	b.eq	8410 <f12+0xe70>  // b.none
    7660:	7100045f 	cmp	w2, #0x1
    7664:	540001c1 	b.ne	769c <f12+0xfc>  // b.any
    7668:	29430864 	ldp	w4, w2, [x3, #24]
    766c:	92403c21 	and	x1, x1, #0xffff
    7670:	9b047c21 	mul	x1, x1, x4
    7674:	d360fc21 	lsr	x1, x1, #32
    7678:	eb02003f 	cmp	x1, x2
    767c:	54000102 	b.cs	769c <f12+0xfc>  // b.hs, b.nlast
    7680:	8b010000 	add	x0, x0, x1
    7684:	39400001 	ldrb	w1, [x0]
    7688:	340000a1 	cbz	w1, 769c <f12+0xfc>
    768c:	7103f43f 	cmp	w1, #0xfd
    7690:	54007548 	b.hi	8538 <f12+0xf98>  // b.pmore
    7694:	11000421 	add	w1, w1, #0x1
    7698:	39000001 	strb	w1, [x0]
    769c:	aa1703e0 	mov	x0, x23
    76a0:	97fffa4c 	bl	5fd0 <fwp_closure_drop>
    76a4:	b4006c15 	cbz	x21, 8424 <f12+0xe84>
    76a8:	aa1503e0 	mov	x0, x21
    76ac:	d2800017 	mov	x23, #0x0                   	// #0
    76b0:	f9400800 	ldr	x0, [x0, #16]
    76b4:	910006f7 	add	x23, x23, #0x1
    76b8:	b5ffffc0 	cbnz	x0, 76b0 <f12+0x110>
    76bc:	52800000 	mov	w0, #0x0                   	// #0
    76c0:	97ffefcc 	bl	35f0 <descent_phase_step>
    76c4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    76c8:	eb0002ff 	cmp	x23, x0
    76cc:	540076a8 	b.hi	85a0 <f12+0x1000>  // b.pmore
    76d0:	9101c298 	add	x24, x20, #0x70
    76d4:	b9436700 	ldr	w0, [x24, #868]
    76d8:	34006880 	cbz	w0, 83e8 <f12+0xe48>
    76dc:	9101c280 	add	x0, x20, #0x70
    76e0:	f9404819 	ldr	x25, [x0, #144]
    76e4:	f9408401 	ldr	x1, [x0, #264]
    76e8:	eb19003f 	cmp	x1, x25
    76ec:	540066aa 	b.ge	83c0 <f12+0xe20>  // b.tcont
    76f0:	f9403a82 	ldr	x2, [x20, #112]
    76f4:	8b010420 	add	x0, x1, x1, lsl #1
    76f8:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    76fc:	8b000820 	add	x0, x1, x0, lsl #2
    7700:	8b000c40 	add	x0, x2, x0, lsl #3
    7704:	d503201f 	nop
    7708:	b9400402 	ldr	w2, [x0, #4]
    770c:	35000082 	cbnz	w2, 771c <f12+0x17c>
    7710:	b9400002 	ldr	w2, [x0]
    7714:	6b03005f 	cmp	w2, w3
    7718:	54006549 	b.ls	83c0 <f12+0xe20>  // b.plast
    771c:	91000421 	add	x1, x1, #0x1
    7720:	9101a000 	add	x0, x0, #0x68
    7724:	eb19003f 	cmp	x1, x25
    7728:	54ffff01 	b.ne	7708 <f12+0x168>  // b.any
    772c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7730:	eb00033f 	cmp	x25, x0
    7734:	540073cc 	b.gt	85ac <f12+0x100c>
    7738:	9101c280 	add	x0, x20, #0x70
    773c:	f9403a9a 	ldr	x26, [x20, #112]
    7740:	f9408000 	ldr	x0, [x0, #256]
    7744:	eb19001f 	cmp	x0, x25
    7748:	54000161 	b.ne	7774 <f12+0x1d4>  // b.any
    774c:	b50069d9 	cbnz	x25, 8484 <f12+0xee4>
    7750:	d2800d01 	mov	x1, #0x68                  	// #104
    7754:	d2800038 	mov	x24, #0x1                   	// #1
    7758:	aa1a03e0 	mov	x0, x26
    775c:	97ffec45 	bl	2870 <realloc@plt>
    7760:	aa0003fa 	mov	x26, x0
    7764:	b4006160 	cbz	x0, 8390 <f12+0xdf0>
    7768:	9101c280 	add	x0, x20, #0x70
    776c:	f9003a9a 	str	x26, [x20, #112]
    7770:	f9008018 	str	x24, [x0, #256]
    7774:	d37ffb21 	lsl	x1, x25, #1
    7778:	9101c280 	add	x0, x20, #0x70
    777c:	8b190022 	add	x2, x1, x25
    7780:	9100073b 	add	x27, x25, #0x1
    7784:	4f000400 	movi	v0.4s, #0x0
    7788:	8b020b22 	add	x2, x25, x2, lsl #2
    778c:	f900481b 	str	x27, [x0, #144]
    7790:	8b020f42 	add	x2, x26, x2, lsl #3
    7794:	f900305f 	str	xzr, [x2, #96]
    7798:	ad000040 	stp	q0, q0, [x2]
    779c:	ad010040 	stp	q0, q0, [x2, #32]
    77a0:	ad020040 	stp	q0, q0, [x2, #64]
    77a4:	8b190021 	add	x1, x1, x25
    77a8:	d0000020 	adrp	x0, d000 <__divti3+0x260>
    77ac:	911ec000 	add	x0, x0, #0x7b0
    77b0:	8b010b21 	add	x1, x25, x1, lsl #2
    77b4:	8b010f58 	add	x24, x26, x1, lsl #3
    77b8:	f900331f 	str	xzr, [x24, #96]
    77bc:	97ffec95 	bl	2a10 <getenv@plt>
    77c0:	b4000080 	cbz	x0, 77d0 <f12+0x230>
    77c4:	39400001 	ldrb	w1, [x0]
    77c8:	7100c03f 	cmp	w1, #0x30
    77cc:	54003080 	b.eq	7ddc <f12+0x83c>  // b.none
    77d0:	9101c280 	add	x0, x20, #0x70
    77d4:	f9407801 	ldr	x1, [x0, #240]
    77d8:	b5006381 	cbnz	x1, 8448 <f12+0xea8>
    77dc:	9101c282 	add	x2, x20, #0x70
    77e0:	2f000400 	mvni	v0.2s, #0x0
    77e4:	b9400303 	ldr	w3, [x24]
    77e8:	52800020 	mov	w0, #0x1                   	// #1
    77ec:	a900df17 	stp	x23, x23, [x24, #8]
    77f0:	0b000063 	add	w3, w3, w0
    77f4:	f9419841 	ldr	x1, [x2, #816]
    77f8:	29000303 	stp	w3, w0, [x24]
    77fc:	f9002b1f 	str	xzr, [x24, #80]
    7800:	f900845b 	str	x27, [x2, #264]
    7804:	fd002f00 	str	d0, [x24, #88]
    7808:	b4006be1 	cbz	x1, 8584 <f12+0xfe4>
    780c:	910d42d6 	add	x22, x22, #0x350
    7810:	14000003 	b	781c <f12+0x27c>
    7814:	f9400021 	ldr	x1, [x1]
    7818:	b4006b61 	cbz	x1, 8584 <f12+0xfe4>
    781c:	f9400422 	ldr	x2, [x1, #8]
    7820:	eb16005f 	cmp	x2, x22
    7824:	54ffff81 	b.ne	7814 <f12+0x274>  // b.any
    7828:	f9400820 	ldr	x0, [x1, #16]
    782c:	2a1903e2 	mov	w2, w25
    7830:	b9400001 	ldr	w1, [x0]
    7834:	f9002b00 	str	x0, [x24, #80]
    7838:	b9005f01 	str	w1, [x24, #92]
    783c:	37f80081 	tbnz	w1, #31, 784c <f12+0x2ac>
    7840:	52800d05 	mov	w5, #0x68                  	// #104
    7844:	9b256821 	smaddl	x1, w1, w5, x26
    7848:	b9005839 	str	w25, [x1, #88]
    784c:	b9000002 	str	w2, [x0]
    7850:	d3707c77 	ubfiz	x23, x3, #16, #32
    7854:	52800020 	mov	w0, #0x1                   	// #1
    7858:	aa1b02f7 	orr	x23, x23, x27
    785c:	97ffef65 	bl	35f0 <descent_phase_step>
    7860:	aa1503e0 	mov	x0, x21
    7864:	d2800002 	mov	x2, #0x0                   	// #0
    7868:	b4005655 	cbz	x21, 8330 <f12+0xd90>
    786c:	d503201f 	nop
    7870:	f9400800 	ldr	x0, [x0, #16]
    7874:	91000442 	add	x2, x2, #0x1
    7878:	b5ffffc0 	cbnz	x0, 7870 <f12+0x2d0>
    787c:	aa1503e1 	mov	x1, x21
    7880:	f9400821 	ldr	x1, [x1, #16]
    7884:	91000400 	add	x0, x0, #0x1
    7888:	b5ffffc1 	cbnz	x1, 7880 <f12+0x2e0>
    788c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7890:	eb01001f 	cmp	x0, x1
    7894:	540066c8 	b.hi	856c <f12+0xfcc>  // b.pmore
    7898:	f100005f 	cmp	x2, #0x0
    789c:	540054ad 	b.le	8330 <f12+0xd90>
    78a0:	eb00005f 	cmp	x2, x0
    78a4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    78a8:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    78ac:	eb0102df 	cmp	x22, x1
    78b0:	540065e8 	b.hi	856c <f12+0xfcc>  // b.pmore
    78b4:	d37ffad9 	lsl	x25, x22, #1
    78b8:	52800041 	mov	w1, #0x2                   	// #2
    78bc:	91000720 	add	x0, x25, #0x1
    78c0:	d37df000 	lsl	x0, x0, #3
    78c4:	97fff59f 	bl	4f40 <fwp_heap_alloc>
    78c8:	aa0003f8 	mov	x24, x0
    78cc:	9117c261 	add	x1, x19, #0x5f0
    78d0:	aa0103e0 	mov	x0, x1
    78d4:	f9000319 	str	x25, [x24]
    78d8:	f949d821 	ldr	x1, [x1, #5040]
    78dc:	f949ec00 	ldr	x0, [x0, #5080]
    78e0:	cb010301 	sub	x1, x24, x1
    78e4:	eb00403f 	cmp	x1, x0, lsl #16
    78e8:	540057a2 	b.cs	83dc <f12+0xe3c>  // b.hs, b.nlast
    78ec:	9117c262 	add	x2, x19, #0x5f0
    78f0:	d350fc20 	lsr	x0, x1, #16
    78f4:	8b000800 	add	x0, x0, x0, lsl #2
    78f8:	f949fc43 	ldr	x3, [x2, #5112]
    78fc:	d37df002 	lsl	x2, x0, #3
    7900:	8b020060 	add	x0, x3, x2
    7904:	f9401019 	ldr	x25, [x0, #32]
    7908:	b4000259 	cbz	x25, 7950 <f12+0x3b0>
    790c:	38626862 	ldrb	w2, [x3, x2]
    7910:	7100085f 	cmp	w2, #0x2
    7914:	54005780 	b.eq	8404 <f12+0xe64>  // b.none
    7918:	7100045f 	cmp	w2, #0x1
    791c:	540001a1 	b.ne	7950 <f12+0x3b0>  // b.any
    7920:	29430002 	ldp	w2, w0, [x0, #24]
    7924:	92403c21 	and	x1, x1, #0xffff
    7928:	9b027c21 	mul	x1, x1, x2
    792c:	d360fc21 	lsr	x1, x1, #32
    7930:	eb00003f 	cmp	x1, x0
    7934:	540000e2 	b.cs	7950 <f12+0x3b0>  // b.hs, b.nlast
    7938:	8b010339 	add	x25, x25, x1
    793c:	39400320 	ldrb	w0, [x25]
    7940:	7103fc1f 	cmp	w0, #0xff
    7944:	54005e80 	b.eq	8514 <f12+0xf74>  // b.none
    7948:	52800020 	mov	w0, #0x1                   	// #1
    794c:	39000320 	strb	w0, [x25]
    7950:	b4000236 	cbz	x22, 7994 <f12+0x3f4>
    7954:	d3607ee4 	lsl	x4, x23, #32
    7958:	aa1503e2 	mov	x2, x21
    795c:	f94006a5 	ldr	x5, [x21, #8]
    7960:	aa0403e3 	mov	x3, x4
    7964:	91002300 	add	x0, x24, #0x8
    7968:	d2800001 	mov	x1, #0x0                   	// #0
    796c:	14000005 	b	7980 <f12+0x3e0>
    7970:	f9400445 	ldr	x5, [x2, #8]
    7974:	ab040023 	adds	x3, x1, x4
    7978:	91004000 	add	x0, x0, #0x10
    797c:	54006266 	b.vs	85c8 <f12+0x1028>
    7980:	a9000c05 	stp	x5, x3, [x0]
    7984:	91000421 	add	x1, x1, #0x1
    7988:	f9400842 	ldr	x2, [x2, #16]
    798c:	eb0102df 	cmp	x22, x1
    7990:	54ffff08 	b.hi	7970 <f12+0x3d0>  // b.pmore
    7994:	f9400300 	ldr	x0, [x24]
    7998:	f100041f 	cmp	x0, #0x1
    799c:	54005229 	b.ls	83e0 <f12+0xe40>  // b.plast
    79a0:	d341fc00 	lsr	x0, x0, #1
    79a4:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    79a8:	d1000401 	sub	x1, x0, #0x1
    79ac:	eb02003f 	cmp	x1, x2
    79b0:	54005de8 	b.hi	856c <f12+0xfcc>  // b.pmore
    79b4:	d37ff83a 	lsl	x26, x1, #1
    79b8:	b4005141 	cbz	x1, 83e0 <f12+0xe40>
    79bc:	d1002301 	sub	x1, x24, #0x8
    79c0:	91002316 	add	x22, x24, #0x8
    79c4:	8b001039 	add	x25, x1, x0, lsl #4
    79c8:	f94006c0 	ldr	x0, [x22, #8]
    79cc:	f9400ec1 	ldr	x1, [x22, #24]
    79d0:	fd4002c0 	ldr	d0, [x22]
    79d4:	fd400ac1 	ldr	d1, [x22, #16]
    79d8:	97fff6da 	bl	5540 <w107>
    79dc:	a90006c0 	stp	x0, x1, [x22]
    79e0:	910042d6 	add	x22, x22, #0x10
    79e4:	eb1902df 	cmp	x22, x25
    79e8:	54ffff01 	b.ne	79c8 <f12+0x428>  // b.any
    79ec:	f900031a 	str	x26, [x24]
    79f0:	aa1803e0 	mov	x0, x24
    79f4:	93407efc 	sxtw	x28, w23
    79f8:	97fff726 	bl	5690 <w164.constprop.0>
    79fc:	aa1803e0 	mov	x0, x24
    7a00:	aa0103f8 	mov	x24, x1
    7a04:	97fffba7 	bl	68a0 <fwp_drop4>
    7a08:	97fff22f 	bl	42c4 <caf61>
    7a0c:	9e670008 	fmov	d8, x0
    7a10:	52800040 	mov	w0, #0x2                   	// #2
    7a14:	97ffeef7 	bl	35f0 <descent_phase_step>
    7a18:	aa1c03e0 	mov	x0, x28
    7a1c:	97fff045 	bl	3b30 <fwp_tape_of>
    7a20:	f9403002 	ldr	x2, [x0, #96]
    7a24:	aa0003e7 	mov	x7, x0
    7a28:	b5005b62 	cbnz	x2, 8594 <f12+0xff4>
    7a2c:	97ffed59 	bl	2f90 <fwp_tape_unlink_scope>
    7a30:	b9400008 	ldr	w8, [x0]
    7a34:	a94284f7 	ldp	x23, x1, [x7, #40]
    7a38:	f90007e1 	str	x1, [sp, #8]
    7a3c:	a940801b 	ldp	x27, x0, [x0, #8]
    7a40:	b90004ff 	str	wzr, [x7, #4]
    7a44:	a941d8ea 	ldp	x10, x22, [x7, #24]
    7a48:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    7a4c:	a943e8f9 	ldp	x25, x26, [x7, #56]
    7a50:	f94024e2 	ldr	x2, [x7, #72]
    7a54:	6b03011f 	cmp	w8, w3
    7a58:	54000108 	b.hi	7a78 <f12+0x4d8>  // b.pmore
    7a5c:	9101c288 	add	x8, x20, #0x70
    7a60:	92403f83 	and	x3, x28, #0xffff
    7a64:	d1000463 	sub	x3, x3, #0x1
    7a68:	f9408509 	ldr	x9, [x8, #264]
    7a6c:	eb09007f 	cmp	x3, x9
    7a70:	5400004a 	b.ge	7a78 <f12+0x4d8>  // b.tcont
    7a74:	f9008503 	str	x3, [x8, #264]
    7a78:	4f000400 	movi	v0.4s, #0x0
    7a7c:	9101c289 	add	x9, x20, #0x70
    7a80:	9101c3e1 	add	x1, sp, #0x70
    7a84:	f9000be1 	str	x1, [sp, #16]
    7a88:	f9000cff 	str	xzr, [x7, #24]
    7a8c:	910163e3 	add	x3, sp, #0x58
    7a90:	f941992b 	ldr	x11, [x9, #816]
    7a94:	3c8080e0 	stur	q0, [x7, #8]
    7a98:	b0ffffe8 	adrp	x8, 4000 <fwp_heap_report+0x60>
    7a9c:	ad0100e0 	stp	q0, q0, [x7, #32]
    7aa0:	910f4108 	add	x8, x8, #0x3d0
    7aa4:	a906dbe1 	stp	x1, x22, [sp, #104]
    7aa8:	f94007e1 	ldr	x1, [sp, #8]
    7aac:	a9047cff 	stp	xzr, xzr, [x7, #64]
    7ab0:	a905a3eb 	stp	x11, x8, [sp, #88]
    7ab4:	f9003ff7 	str	x23, [sp, #120]
    7ab8:	f90043e1 	str	x1, [sp, #128]
    7abc:	a908ebf9 	stp	x25, x26, [sp, #136]
    7ac0:	a9098bea 	stp	x10, x2, [sp, #152]
    7ac4:	f9019923 	str	x3, [x9, #816]
    7ac8:	b7f84b78 	tbnz	x24, #63, 8434 <f12+0xe94>
    7acc:	eb98839f 	cmp	x28, x24, asr #32
    7ad0:	54005481 	b.ne	8560 <f12+0xfc0>  // b.any
    7ad4:	92407f03 	and	x3, x24, #0xffffffff
    7ad8:	eb38401f 	cmp	x0, w24, uxtw
    7adc:	540053cd 	b.le	8554 <f12+0xfb4>
    7ae0:	eb03037f 	cmp	x27, x3
    7ae4:	9a83c77c 	csinc	x28, x27, x3, gt
    7ae8:	eb1c005f 	cmp	x2, x28
    7aec:	5400442a 	b.ge	8370 <f12+0xdd0>  // b.tcont
    7af0:	f100005f 	cmp	x2, #0x0
    7af4:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7af8:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    7afc:	14000004 	b	7b0c <f12+0x56c>
    7b00:	eb01005f 	cmp	x2, x1
    7b04:	d37ff842 	lsl	x2, x2, #1
    7b08:	9a9cd042 	csel	x2, x2, x28, le
    7b0c:	eb1c005f 	cmp	x2, x28
    7b10:	54ffff8b 	b.lt	7b00 <f12+0x560>  // b.tstop
    7b14:	b4004dda 	cbz	x26, 84cc <f12+0xf2c>
    7b18:	aa1a03e0 	mov	x0, x26
    7b1c:	d37df041 	lsl	x1, x2, #3
    7b20:	f90017e2 	str	x2, [sp, #40]
    7b24:	97ffeb53 	bl	2870 <realloc@plt>
    7b28:	f94017e2 	ldr	x2, [sp, #40]
    7b2c:	aa0003fa 	mov	x26, x0
    7b30:	b400421a 	cbz	x26, 8370 <f12+0xdd0>
    7b34:	f9004bfa 	str	x26, [sp, #144]
    7b38:	f90053e2 	str	x2, [sp, #160]
    7b3c:	b500157c 	cbnz	x28, 7de8 <f12+0x848>
    7b40:	b7f800b8 	tbnz	x24, #63, 7b54 <f12+0x5b4>
    7b44:	92407f04 	and	x4, x24, #0xffffffff
    7b48:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7b4c:	1e682800 	fadd	d0, d0, d8
    7b50:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7b54:	9101c281 	add	x1, x20, #0x70
    7b58:	cb1b0384 	sub	x4, x28, x27
    7b5c:	52800060 	mov	w0, #0x3                   	// #3
    7b60:	a9428827 	ldp	x7, x2, [x1, #40]
    7b64:	8b070084 	add	x4, x4, x7
    7b68:	8b1b0042 	add	x2, x2, x27
    7b6c:	a9028824 	stp	x4, x2, [x1, #40]
    7b70:	97ffeea0 	bl	35f0 <descent_phase_step>
    7b74:	d1000783 	sub	x3, x28, #0x1
    7b78:	d1000764 	sub	x4, x27, #0x1
    7b7c:	eb03037f 	cmp	x27, x3
    7b80:	540003cc 	b.gt	7bf8 <f12+0x658>
    7b84:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7b88:	1e602008 	fcmp	d0, #0.0
    7b8c:	54000300 	b.eq	7bec <f12+0x64c>  // b.none
    7b90:	cb1b0be0 	neg	x0, x27, lsl #2
    7b94:	cb1b03e2 	neg	x2, x27
    7b98:	8b0002c1 	add	x1, x22, x0
    7b9c:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    7ba0:	37f80121 	tbnz	w1, #31, 7bc4 <f12+0x624>
    7ba4:	f94007e5 	ldr	x5, [sp, #8]
    7ba8:	93407c21 	sxtw	x1, w1
    7bac:	8b020ca7 	add	x7, x5, x2, lsl #3
    7bb0:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7bb4:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7bb8:	1e620802 	fmul	d2, d0, d2
    7bbc:	1e622821 	fadd	d1, d1, d2
    7bc0:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7bc4:	8b0002e0 	add	x0, x23, x0
    7bc8:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7bcc:	37f80100 	tbnz	w0, #31, 7bec <f12+0x64c>
    7bd0:	8b020f22 	add	x2, x25, x2, lsl #3
    7bd4:	93407c00 	sxtw	x0, w0
    7bd8:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7bdc:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    7be0:	1e620800 	fmul	d0, d0, d2
    7be4:	1e602820 	fadd	d0, d1, d0
    7be8:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7bec:	d1000463 	sub	x3, x3, #0x1
    7bf0:	eb03009f 	cmp	x4, x3
    7bf4:	54fffc81 	b.ne	7b84 <f12+0x5e4>  // b.any
    7bf8:	52800080 	mov	w0, #0x4                   	// #4
    7bfc:	97ffee7d 	bl	35f0 <descent_phase_step>
    7c00:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7c04:	eb00037f 	cmp	x27, x0
    7c08:	54004d88 	b.hi	85b8 <f12+0x1018>  // b.pmore
    7c0c:	91000760 	add	x0, x27, #0x1
    7c10:	52800041 	mov	w1, #0x2                   	// #2
    7c14:	d37df000 	lsl	x0, x0, #3
    7c18:	97fff4ca 	bl	4f40 <fwp_heap_alloc>
    7c1c:	aa0003e2 	mov	x2, x0
    7c20:	aa0003f6 	mov	x22, x0
    7c24:	d2800001 	mov	x1, #0x0                   	// #0
    7c28:	f800845b 	str	x27, [x2], #8
    7c2c:	b40000db 	cbz	x27, 7c44 <f12+0x6a4>
    7c30:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    7c34:	f8217840 	str	x0, [x2, x1, lsl #3]
    7c38:	91000421 	add	x1, x1, #0x1
    7c3c:	eb01037f 	cmp	x27, x1
    7c40:	54ffff81 	b.ne	7c30 <f12+0x690>  // b.any
    7c44:	528000a0 	mov	w0, #0x5                   	// #5
    7c48:	97ffee6a 	bl	35f0 <descent_phase_step>
    7c4c:	f9400be0 	ldr	x0, [sp, #16]
    7c50:	9101c281 	add	x1, x20, #0x70
    7c54:	f9402ff8 	ldr	x24, [sp, #88]
    7c58:	f9019838 	str	x24, [x1, #816]
    7c5c:	97fff1dd 	bl	43d0 <fwp_tape_buffers_release>
    7c60:	528000c0 	mov	w0, #0x6                   	// #6
    7c64:	97ffee63 	bl	35f0 <descent_phase_step>
    7c68:	9117c262 	add	x2, x19, #0x5f0
    7c6c:	f949d841 	ldr	x1, [x2, #5040]
    7c70:	f949ec40 	ldr	x0, [x2, #5080]
    7c74:	cb0102c1 	sub	x1, x22, x1
    7c78:	eb00403f 	cmp	x1, x0, lsl #16
    7c7c:	54000322 	b.cs	7ce0 <f12+0x740>  // b.hs, b.nlast
    7c80:	d350fc20 	lsr	x0, x1, #16
    7c84:	f949fc43 	ldr	x3, [x2, #5112]
    7c88:	8b000800 	add	x0, x0, x0, lsl #2
    7c8c:	d37df002 	lsl	x2, x0, #3
    7c90:	8b020060 	add	x0, x3, x2
    7c94:	f9401017 	ldr	x23, [x0, #32]
    7c98:	b4000257 	cbz	x23, 7ce0 <f12+0x740>
    7c9c:	38626862 	ldrb	w2, [x3, x2]
    7ca0:	7100085f 	cmp	w2, #0x2
    7ca4:	54003cc0 	b.eq	843c <f12+0xe9c>  // b.none
    7ca8:	7100045f 	cmp	w2, #0x1
    7cac:	540001a1 	b.ne	7ce0 <f12+0x740>  // b.any
    7cb0:	29430002 	ldp	w2, w0, [x0, #24]
    7cb4:	92403c21 	and	x1, x1, #0xffff
    7cb8:	9b027c21 	mul	x1, x1, x2
    7cbc:	d360fc21 	lsr	x1, x1, #32
    7cc0:	eb00003f 	cmp	x1, x0
    7cc4:	540000e2 	b.cs	7ce0 <f12+0x740>  // b.hs, b.nlast
    7cc8:	8b0102f7 	add	x23, x23, x1
    7ccc:	394002e0 	ldrb	w0, [x23]
    7cd0:	7103fc1f 	cmp	w0, #0xff
    7cd4:	54004260 	b.eq	8520 <f12+0xf80>  // b.none
    7cd8:	52800020 	mov	w0, #0x1                   	// #1
    7cdc:	390002e0 	strb	w0, [x23]
    7ce0:	f94013e0 	ldr	x0, [sp, #32]
    7ce4:	eb00031f 	cmp	x24, x0
    7ce8:	540046e1 	b.ne	85c4 <f12+0x1024>  // b.any
    7cec:	f9400fe0 	ldr	x0, [sp, #24]
    7cf0:	9101c294 	add	x20, x20, #0x70
    7cf4:	f94023e1 	ldr	x1, [sp, #64]
    7cf8:	f9019a81 	str	x1, [x20, #816]
    7cfc:	97fff995 	bl	6350 <fwp_tape_scope_release>
    7d00:	f94002c0 	ldr	x0, [x22]
    7d04:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7d08:	b7f82c00 	tbnz	x0, #63, 8288 <f12+0xce8>
    7d0c:	9117c262 	add	x2, x19, #0x5f0
    7d10:	f949d840 	ldr	x0, [x2, #5040]
    7d14:	f949ec41 	ldr	x1, [x2, #5080]
    7d18:	cb0002c0 	sub	x0, x22, x0
    7d1c:	eb01401f 	cmp	x0, x1, lsl #16
    7d20:	54002b42 	b.cs	8288 <f12+0xce8>  // b.hs, b.nlast
    7d24:	d350fc01 	lsr	x1, x0, #16
    7d28:	f949fc44 	ldr	x4, [x2, #5112]
    7d2c:	8b010821 	add	x1, x1, x1, lsl #2
    7d30:	d37df021 	lsl	x1, x1, #3
    7d34:	8b010083 	add	x3, x4, x1
    7d38:	f9401062 	ldr	x2, [x3, #32]
    7d3c:	b4002a62 	cbz	x2, 8288 <f12+0xce8>
    7d40:	38616881 	ldrb	w1, [x4, x1]
    7d44:	7100083f 	cmp	w1, #0x2
    7d48:	540029a0 	b.eq	827c <f12+0xcdc>  // b.none
    7d4c:	7100043f 	cmp	w1, #0x1
    7d50:	540029c1 	b.ne	8288 <f12+0xce8>  // b.any
    7d54:	29430464 	ldp	w4, w1, [x3, #24]
    7d58:	92403c00 	and	x0, x0, #0xffff
    7d5c:	9b047c00 	mul	x0, x0, x4
    7d60:	d360fc00 	lsr	x0, x0, #32
    7d64:	eb01001f 	cmp	x0, x1
    7d68:	54002902 	b.cs	8288 <f12+0xce8>  // b.hs, b.nlast
    7d6c:	8b000042 	add	x2, x2, x0
    7d70:	39400040 	ldrb	w0, [x2]
    7d74:	7100041f 	cmp	w0, #0x1
    7d78:	54002881 	b.ne	8288 <f12+0xce8>  // b.any
    7d7c:	aa1603fa 	mov	x26, x22
    7d80:	d2800000 	mov	x0, #0x0                   	// #0
    7d84:	f90007f6 	str	x22, [sp, #8]
    7d88:	f94007e1 	ldr	x1, [sp, #8]
    7d8c:	91002023 	add	x3, x1, #0x8
    7d90:	d2800001 	mov	x1, #0x0                   	// #0
    7d94:	b4000354 	cbz	x20, 7dfc <f12+0x85c>
    7d98:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0xb40>
    7d9c:	910022c5 	add	x5, x22, #0x8
    7da0:	fd415841 	ldr	d1, [x2, #688]
    7da4:	14000009 	b	7dc8 <f12+0x828>
    7da8:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7dac:	f9400342 	ldr	x2, [x26]
    7db0:	1e600820 	fmul	d0, d1, d0
    7db4:	b7f83e22 	tbnz	x2, #63, 8578 <f12+0xfd8>
    7db8:	91000421 	add	x1, x1, #0x1
    7dbc:	fc008460 	str	d0, [x3], #8
    7dc0:	eb01029f 	cmp	x20, x1
    7dc4:	540001c0 	b.eq	7dfc <f12+0x85c>  // b.none
    7dc8:	f94002c4 	ldr	x4, [x22]
    7dcc:	aa0503e2 	mov	x2, x5
    7dd0:	b6fffec4 	tbz	x4, #63, 7da8 <f12+0x808>
    7dd4:	f9400ac2 	ldr	x2, [x22, #16]
    7dd8:	17fffff4 	b	7da8 <f12+0x808>
    7ddc:	39400400 	ldrb	w0, [x0, #1]
    7de0:	34ffcfe0 	cbz	w0, 77dc <f12+0x23c>
    7de4:	17fffe7b 	b	77d0 <f12+0x230>
    7de8:	d37df382 	lsl	x2, x28, #3
    7dec:	aa1a03e0 	mov	x0, x26
    7df0:	52800001 	mov	w1, #0x0                   	// #0
    7df4:	97ffea97 	bl	2850 <memset@plt>
    7df8:	17ffff52 	b	7b40 <f12+0x5a0>
    7dfc:	97fffaa9 	bl	68a0 <fwp_drop4>
    7e00:	aa1503e1 	mov	x1, x21
    7e04:	d2800002 	mov	x2, #0x0                   	// #0
    7e08:	b4003715 	cbz	x21, 84e8 <f12+0xf48>
    7e0c:	d503201f 	nop
    7e10:	f9400821 	ldr	x1, [x1, #16]
    7e14:	91000442 	add	x2, x2, #0x1
    7e18:	b5ffffc1 	cbnz	x1, 7e10 <f12+0x870>
    7e1c:	f9400343 	ldr	x3, [x26]
    7e20:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7e24:	b7f81f63 	tbnz	x3, #63, 8210 <f12+0xc70>
    7e28:	9117c261 	add	x1, x19, #0x5f0
    7e2c:	f94007e4 	ldr	x4, [sp, #8]
    7e30:	f949d820 	ldr	x0, [x1, #5040]
    7e34:	f949ec21 	ldr	x1, [x1, #5080]
    7e38:	cb000080 	sub	x0, x4, x0
    7e3c:	eb01401f 	cmp	x0, x1, lsl #16
    7e40:	54001e82 	b.cs	8210 <f12+0xc70>  // b.hs, b.nlast
    7e44:	9117c264 	add	x4, x19, #0x5f0
    7e48:	d350fc01 	lsr	x1, x0, #16
    7e4c:	8b010821 	add	x1, x1, x1, lsl #2
    7e50:	f949fc86 	ldr	x6, [x4, #5112]
    7e54:	d37df021 	lsl	x1, x1, #3
    7e58:	8b0100c5 	add	x5, x6, x1
    7e5c:	f94010a4 	ldr	x4, [x5, #32]
    7e60:	b4001d64 	cbz	x4, 820c <f12+0xc6c>
    7e64:	386168c1 	ldrb	w1, [x6, x1]
    7e68:	7100083f 	cmp	w1, #0x2
    7e6c:	54001cc0 	b.eq	8204 <f12+0xc64>  // b.none
    7e70:	7100043f 	cmp	w1, #0x1
    7e74:	54001cc1 	b.ne	820c <f12+0xc6c>  // b.any
    7e78:	294304a6 	ldp	w6, w1, [x5, #24]
    7e7c:	92403c00 	and	x0, x0, #0xffff
    7e80:	9b067c00 	mul	x0, x0, x6
    7e84:	d360fc00 	lsr	x0, x0, #32
    7e88:	eb01001f 	cmp	x0, x1
    7e8c:	54001c02 	b.cs	820c <f12+0xc6c>  // b.hs, b.nlast
    7e90:	8b000084 	add	x4, x4, x0
    7e94:	39400098 	ldrb	w24, [x4]
    7e98:	7100071f 	cmp	w24, #0x1
    7e9c:	54001b81 	b.ne	820c <f12+0xc6c>  // b.any
    7ea0:	b90013f8 	str	w24, [sp, #16]
    7ea4:	eb1c005f 	cmp	x2, x28
    7ea8:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7eac:	91002359 	add	x25, x26, #0x8
    7eb0:	b40034dc 	cbz	x28, 8548 <f12+0xfa8>
    7eb4:	f94007e0 	ldr	x0, [sp, #8]
    7eb8:	d37df385 	lsl	x5, x28, #3
    7ebc:	aa1503e2 	mov	x2, x21
    7ec0:	d2800001 	mov	x1, #0x0                   	// #0
    7ec4:	91002000 	add	x0, x0, #0x8
    7ec8:	1400000a 	b	7ef0 <f12+0x950>
    7ecc:	fc616881 	ldr	d1, [x4, x1]
    7ed0:	fd400440 	ldr	d0, [x2, #8]
    7ed4:	1e613800 	fsub	d0, d0, d1
    7ed8:	fc216b20 	str	d0, [x25, x1]
    7edc:	91002021 	add	x1, x1, #0x8
    7ee0:	f9400842 	ldr	x2, [x2, #16]
    7ee4:	eb05003f 	cmp	x1, x5
    7ee8:	540001c0 	b.eq	7f20 <f12+0x980>  // b.none
    7eec:	f9400343 	ldr	x3, [x26]
    7ef0:	aa0003e4 	mov	x4, x0
    7ef4:	b6fffec3 	tbz	x3, #63, 7ecc <f12+0x92c>
    7ef8:	f94007e3 	ldr	x3, [sp, #8]
    7efc:	fd400440 	ldr	d0, [x2, #8]
    7f00:	f9400864 	ldr	x4, [x3, #16]
    7f04:	fc616881 	ldr	d1, [x4, x1]
    7f08:	1e613800 	fsub	d0, d0, d1
    7f0c:	fc216b20 	str	d0, [x25, x1]
    7f10:	91002021 	add	x1, x1, #0x8
    7f14:	f9400842 	ldr	x2, [x2, #16]
    7f18:	eb05003f 	cmp	x1, x5
    7f1c:	54fffe81 	b.ne	7eec <f12+0x94c>  // b.any
    7f20:	b4003115 	cbz	x21, 8540 <f12+0xfa0>
    7f24:	9117c260 	add	x0, x19, #0x5f0
    7f28:	aa1503e2 	mov	x2, x21
    7f2c:	d280001a 	mov	x26, #0x0                   	// #0
    7f30:	f949ec06 	ldr	x6, [x0, #5080]
    7f34:	f949d807 	ldr	x7, [x0, #5040]
    7f38:	f949fc05 	ldr	x5, [x0, #5112]
    7f3c:	d370bcc6 	lsl	x6, x6, #16
    7f40:	14000006 	b	7f58 <f12+0x9b8>
    7f44:	f9400842 	ldr	x2, [x2, #16]
    7f48:	9100075a 	add	x26, x26, #0x1
    7f4c:	f100005f 	cmp	x2, #0x0
    7f50:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7f54:	54000329 	b.ls	7fb8 <f12+0xa18>  // b.plast
    7f58:	cb070040 	sub	x0, x2, x7
    7f5c:	eb06001f 	cmp	x0, x6
    7f60:	540002c2 	b.cs	7fb8 <f12+0xa18>  // b.hs, b.nlast
    7f64:	d350fc01 	lsr	x1, x0, #16
    7f68:	8b010821 	add	x1, x1, x1, lsl #2
    7f6c:	d37df021 	lsl	x1, x1, #3
    7f70:	8b0100a4 	add	x4, x5, x1
    7f74:	f9401083 	ldr	x3, [x4, #32]
    7f78:	b4000203 	cbz	x3, 7fb8 <f12+0xa18>
    7f7c:	386168a1 	ldrb	w1, [x5, x1]
    7f80:	7100083f 	cmp	w1, #0x2
    7f84:	54000de0 	b.eq	8140 <f12+0xba0>  // b.none
    7f88:	7100043f 	cmp	w1, #0x1
    7f8c:	54000161 	b.ne	7fb8 <f12+0xa18>  // b.any
    7f90:	29430488 	ldp	w8, w1, [x4, #24]
    7f94:	92403c00 	and	x0, x0, #0xffff
    7f98:	9b087c00 	mul	x0, x0, x8
    7f9c:	d360fc00 	lsr	x0, x0, #32
    7fa0:	eb01001f 	cmp	x0, x1
    7fa4:	540000a2 	b.cs	7fb8 <f12+0xa18>  // b.hs, b.nlast
    7fa8:	8b000063 	add	x3, x3, x0
    7fac:	39400060 	ldrb	w0, [x3]
    7fb0:	7100041f 	cmp	w0, #0x1
    7fb4:	54fffc80 	b.eq	7f44 <f12+0x9a4>  // b.none
    7fb8:	eb1a039f 	cmp	x28, x26
    7fbc:	54000ca9 	b.ls	8150 <f12+0xbb0>  // b.plast
    7fc0:	d1002337 	sub	x23, x25, #0x8
    7fc4:	9102a3f6 	add	x22, sp, #0xa8
    7fc8:	9117c278 	add	x24, x19, #0x5f0
    7fcc:	d2800014 	mov	x20, #0x0                   	// #0
    7fd0:	14000012 	b	8018 <f12+0xa78>
    7fd4:	7100045f 	cmp	w2, #0x1
    7fd8:	540001a1 	b.ne	800c <f12+0xa6c>  // b.any
    7fdc:	29430002 	ldp	w2, w0, [x0, #24]
    7fe0:	92403c21 	and	x1, x1, #0xffff
    7fe4:	9b027c21 	mul	x1, x1, x2
    7fe8:	d360fc21 	lsr	x1, x1, #32
    7fec:	eb00003f 	cmp	x1, x0
    7ff0:	540000e2 	b.cs	800c <f12+0xa6c>  // b.hs, b.nlast
    7ff4:	8b01037b 	add	x27, x27, x1
    7ff8:	39400360 	ldrb	w0, [x27]
    7ffc:	7103fc1f 	cmp	w0, #0xff
    8000:	54001b20 	b.eq	8364 <f12+0xdc4>  // b.none
    8004:	52800020 	mov	w0, #0x1                   	// #1
    8008:	39000360 	strb	w0, [x27]
    800c:	d100079c 	sub	x28, x28, #0x1
    8010:	eb1c035f 	cmp	x26, x28
    8014:	54000362 	b.cs	8080 <f12+0xae0>  // b.hs, b.nlast
    8018:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    801c:	aa1603e1 	mov	x1, x22
    8020:	52800020 	mov	w0, #0x1                   	// #1
    8024:	a90ad3e2 	stp	x2, x20, [sp, #168]
    8028:	97fff5c6 	bl	5740 <fwp_data.part.0.constprop.0>
    802c:	aa0003f4 	mov	x20, x0
    8030:	f949db01 	ldr	x1, [x24, #5040]
    8034:	f949ef00 	ldr	x0, [x24, #5080]
    8038:	cb010281 	sub	x1, x20, x1
    803c:	eb00403f 	cmp	x1, x0, lsl #16
    8040:	54fffe62 	b.cs	800c <f12+0xa6c>  // b.hs, b.nlast
    8044:	d350fc22 	lsr	x2, x1, #16
    8048:	f949ff03 	ldr	x3, [x24, #5112]
    804c:	8b020842 	add	x2, x2, x2, lsl #2
    8050:	d37df042 	lsl	x2, x2, #3
    8054:	8b020060 	add	x0, x3, x2
    8058:	f940101b 	ldr	x27, [x0, #32]
    805c:	b4fffd9b 	cbz	x27, 800c <f12+0xa6c>
    8060:	38626862 	ldrb	w2, [x3, x2]
    8064:	7100085f 	cmp	w2, #0x2
    8068:	54fffb61 	b.ne	7fd4 <f12+0xa34>  // b.any
    806c:	72003c3f 	tst	w1, #0xffff
    8070:	54fffc40 	b.eq	7ff8 <f12+0xa58>  // b.none
    8074:	d100079c 	sub	x28, x28, #0x1
    8078:	eb1c035f 	cmp	x26, x28
    807c:	54fffce3 	b.cc	8018 <f12+0xa78>  // b.lo, b.ul, b.last
    8080:	b50006ba 	cbnz	x26, 8154 <f12+0xbb4>
    8084:	b94013e0 	ldr	w0, [sp, #16]
    8088:	d2800038 	mov	x24, #0x1                   	// #1
    808c:	d280001b 	mov	x27, #0x0                   	// #0
    8090:	7100001f 	cmp	w0, #0x0
    8094:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    8098:	b40007db 	cbz	x27, 8190 <f12+0xbf0>
    809c:	d100077b 	sub	x27, x27, #0x1
    80a0:	9117c273 	add	x19, x19, #0x5f0
    80a4:	d503201f 	nop
    80a8:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    80ac:	aa1603e1 	mov	x1, x22
    80b0:	52800020 	mov	w0, #0x1                   	// #1
    80b4:	a90ad3e2 	stp	x2, x20, [sp, #168]
    80b8:	97fff5a2 	bl	5740 <fwp_data.part.0.constprop.0>
    80bc:	aa0003f4 	mov	x20, x0
    80c0:	f949da61 	ldr	x1, [x19, #5040]
    80c4:	f949ee60 	ldr	x0, [x19, #5080]
    80c8:	cb010281 	sub	x1, x20, x1
    80cc:	eb00403f 	cmp	x1, x0, lsl #16
    80d0:	54000302 	b.cs	8130 <f12+0xb90>  // b.hs, b.nlast
    80d4:	d350fc22 	lsr	x2, x1, #16
    80d8:	f949fe63 	ldr	x3, [x19, #5112]
    80dc:	8b020842 	add	x2, x2, x2, lsl #2
    80e0:	d37df042 	lsl	x2, x2, #3
    80e4:	8b020060 	add	x0, x3, x2
    80e8:	f940101a 	ldr	x26, [x0, #32]
    80ec:	b400023a 	cbz	x26, 8130 <f12+0xb90>
    80f0:	38626862 	ldrb	w2, [x3, x2]
    80f4:	7100085f 	cmp	w2, #0x2
    80f8:	54000800 	b.eq	81f8 <f12+0xc58>  // b.none
    80fc:	7100045f 	cmp	w2, #0x1
    8100:	54000181 	b.ne	8130 <f12+0xb90>  // b.any
    8104:	29430002 	ldp	w2, w0, [x0, #24]
    8108:	92403c21 	and	x1, x1, #0xffff
    810c:	9b027c21 	mul	x1, x1, x2
    8110:	d360fc21 	lsr	x1, x1, #32
    8114:	eb00003f 	cmp	x1, x0
    8118:	540000c2 	b.cs	8130 <f12+0xb90>  // b.hs, b.nlast
    811c:	8b01035a 	add	x26, x26, x1
    8120:	39400340 	ldrb	w0, [x26]
    8124:	7103fc1f 	cmp	w0, #0xff
    8128:	54000620 	b.eq	81ec <f12+0xc4c>  // b.none
    812c:	39000358 	strb	w24, [x26]
    8130:	d100077b 	sub	x27, x27, #0x1
    8134:	b100077f 	cmn	x27, #0x1
    8138:	54fffb81 	b.ne	80a8 <f12+0xb08>  // b.any
    813c:	14000015 	b	8190 <f12+0xbf0>
    8140:	72003c1f 	tst	w0, #0xffff
    8144:	54fff340 	b.eq	7fac <f12+0xa0c>  // b.none
    8148:	eb1a039f 	cmp	x28, x26
    814c:	54fff3a8 	b.hi	7fc0 <f12+0xa20>  // b.pmore
    8150:	d2800014 	mov	x20, #0x0                   	// #0
    8154:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8158:	aa1903e1 	mov	x1, x25
    815c:	aa1503e0 	mov	x0, x21
    8160:	f8408422 	ldr	x2, [x1], #8
    8164:	f9000402 	str	x2, [x0, #8]
    8168:	aa0003e2 	mov	x2, x0
    816c:	f9400800 	ldr	x0, [x0, #16]
    8170:	eb1a003f 	cmp	x1, x26
    8174:	54ffff61 	b.ne	8160 <f12+0xbc0>  // b.any
    8178:	b94013e1 	ldr	w1, [sp, #16]
    817c:	f9000854 	str	x20, [x2, #16]
    8180:	aa1503f4 	mov	x20, x21
    8184:	aa0003f5 	mov	x21, x0
    8188:	34000041 	cbz	w1, 8190 <f12+0xbf0>
    818c:	d2800019 	mov	x25, #0x0                   	// #0
    8190:	aa1903e0 	mov	x0, x25
    8194:	97fff24b 	bl	4ac0 <fwp_mem_free>
    8198:	f94007e0 	ldr	x0, [sp, #8]
    819c:	97fff9c1 	bl	68a0 <fwp_drop4>
    81a0:	aa1503e0 	mov	x0, x21
    81a4:	97fff72f 	bl	5e60 <fwp_drop0>
    81a8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    81ac:	f947f400 	ldr	x0, [x0, #4072]
    81b0:	f9405fe2 	ldr	x2, [sp, #184]
    81b4:	f9400001 	ldr	x1, [x0]
    81b8:	eb010042 	subs	x2, x2, x1
    81bc:	d2800001 	mov	x1, #0x0                   	// #0
    81c0:	54001e81 	b.ne	8590 <f12+0xff0>  // b.any
    81c4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    81c8:	aa1403e0 	mov	x0, x20
    81cc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    81d0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    81d4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    81d8:	a9506bf9 	ldp	x25, x26, [sp, #256]
    81dc:	a95173fb 	ldp	x27, x28, [sp, #272]
    81e0:	fd4093e8 	ldr	d8, [sp, #288]
    81e4:	9104c3ff 	add	sp, sp, #0x130
    81e8:	d65f03c0 	ret
    81ec:	aa1a03e0 	mov	x0, x26
    81f0:	97fff194 	bl	4840 <fwp_rc_forget_slot>
    81f4:	17ffffce 	b	812c <f12+0xb8c>
    81f8:	72003c3f 	tst	w1, #0xffff
    81fc:	54fff9a1 	b.ne	8130 <f12+0xb90>  // b.any
    8200:	17ffffc8 	b	8120 <f12+0xb80>
    8204:	72003c1f 	tst	w0, #0xffff
    8208:	54ffe460 	b.eq	7e94 <f12+0x8f4>  // b.none
    820c:	b40014d5 	cbz	x21, 84a4 <f12+0xf04>
    8210:	aa1503f4 	mov	x20, x21
    8214:	d2800016 	mov	x22, #0x0                   	// #0
    8218:	f9400a94 	ldr	x20, [x20, #16]
    821c:	aa1603e0 	mov	x0, x22
    8220:	910006d6 	add	x22, x22, #0x1
    8224:	b5ffffb4 	cbnz	x20, 8218 <f12+0xc78>
    8228:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    822c:	eb0102df 	cmp	x22, x1
    8230:	540019e8 	b.hi	856c <f12+0xfcc>  // b.pmore
    8234:	91000800 	add	x0, x0, #0x2
    8238:	52800041 	mov	w1, #0x2                   	// #2
    823c:	d37df000 	lsl	x0, x0, #3
    8240:	97fff340 	bl	4f40 <fwp_heap_alloc>
    8244:	eb16039f 	cmp	x28, x22
    8248:	aa0003f9 	mov	x25, x0
    824c:	9a96939c 	csel	x28, x28, x22, ls	// ls = plast
    8250:	aa1503e1 	mov	x1, x21
    8254:	d503201f 	nop
    8258:	f9400420 	ldr	x0, [x1, #8]
    825c:	f8347b20 	str	x0, [x25, x20, lsl #3]
    8260:	91000694 	add	x20, x20, #0x1
    8264:	f9400821 	ldr	x1, [x1, #16]
    8268:	b5ffff81 	cbnz	x1, 8258 <f12+0xcb8>
    826c:	b400125c 	cbz	x28, 84b4 <f12+0xf14>
    8270:	f9400343 	ldr	x3, [x26]
    8274:	b90013ff 	str	wzr, [sp, #16]
    8278:	17ffff0f 	b	7eb4 <f12+0x914>
    827c:	72003c1f 	tst	w0, #0xffff
    8280:	54ffd780 	b.eq	7d70 <f12+0x7d0>  // b.none
    8284:	d503201f 	nop
    8288:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    828c:	eb00029f 	cmp	x20, x0
    8290:	54001948 	b.hi	85b8 <f12+0x1018>  // b.pmore
    8294:	91000680 	add	x0, x20, #0x1
    8298:	52800021 	mov	w1, #0x1                   	// #1
    829c:	d37df000 	lsl	x0, x0, #3
    82a0:	97fff328 	bl	4f40 <fwp_heap_alloc>
    82a4:	9117c262 	add	x2, x19, #0x5f0
    82a8:	f9000014 	str	x20, [x0]
    82ac:	aa0003fa 	mov	x26, x0
    82b0:	f90007fa 	str	x26, [sp, #8]
    82b4:	f949d841 	ldr	x1, [x2, #5040]
    82b8:	f949ec40 	ldr	x0, [x2, #5080]
    82bc:	cb010341 	sub	x1, x26, x1
    82c0:	eb00403f 	cmp	x1, x0, lsl #16
    82c4:	54000322 	b.cs	8328 <f12+0xd88>  // b.hs, b.nlast
    82c8:	d350fc20 	lsr	x0, x1, #16
    82cc:	f949fc43 	ldr	x3, [x2, #5112]
    82d0:	8b000800 	add	x0, x0, x0, lsl #2
    82d4:	d37df002 	lsl	x2, x0, #3
    82d8:	8b020060 	add	x0, x3, x2
    82dc:	f9401018 	ldr	x24, [x0, #32]
    82e0:	b4000258 	cbz	x24, 8328 <f12+0xd88>
    82e4:	38626862 	ldrb	w2, [x3, x2]
    82e8:	7100085f 	cmp	w2, #0x2
    82ec:	54000e80 	b.eq	84bc <f12+0xf1c>  // b.none
    82f0:	7100045f 	cmp	w2, #0x1
    82f4:	540001a1 	b.ne	8328 <f12+0xd88>  // b.any
    82f8:	29430002 	ldp	w2, w0, [x0, #24]
    82fc:	92403c21 	and	x1, x1, #0xffff
    8300:	9b027c21 	mul	x1, x1, x2
    8304:	d360fc21 	lsr	x1, x1, #32
    8308:	eb00003f 	cmp	x1, x0
    830c:	540000e2 	b.cs	8328 <f12+0xd88>  // b.hs, b.nlast
    8310:	8b010318 	add	x24, x24, x1
    8314:	39400300 	ldrb	w0, [x24]
    8318:	7103fc1f 	cmp	w0, #0xff
    831c:	54001080 	b.eq	852c <f12+0xf8c>  // b.none
    8320:	52800020 	mov	w0, #0x1                   	// #1
    8324:	39000300 	strb	w0, [x24]
    8328:	aa1603e0 	mov	x0, x22
    832c:	17fffe97 	b	7d88 <f12+0x7e8>
    8330:	52800041 	mov	w1, #0x2                   	// #2
    8334:	d2800100 	mov	x0, #0x8                   	// #8
    8338:	97fff302 	bl	4f40 <fwp_heap_alloc>
    833c:	aa0003f8 	mov	x24, x0
    8340:	9117c260 	add	x0, x19, #0x5f0
    8344:	f900031f 	str	xzr, [x24]
    8348:	f949d801 	ldr	x1, [x0, #5040]
    834c:	f949ec00 	ldr	x0, [x0, #5080]
    8350:	cb010301 	sub	x1, x24, x1
    8354:	eb00403f 	cmp	x1, x0, lsl #16
    8358:	54000442 	b.cs	83e0 <f12+0xe40>  // b.hs, b.nlast
    835c:	d2800016 	mov	x22, #0x0                   	// #0
    8360:	17fffd63 	b	78ec <f12+0x34c>
    8364:	aa1b03e0 	mov	x0, x27
    8368:	97fff136 	bl	4840 <fwp_rc_forget_slot>
    836c:	17ffff26 	b	8004 <f12+0xa64>
    8370:	f100039f 	cmp	x28, #0x0
    8374:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    8378:	54ffbe21 	b.ne	7b3c <f12+0x59c>  // b.any
    837c:	f9400be0 	ldr	x0, [sp, #16]
    8380:	9101c294 	add	x20, x20, #0x70
    8384:	f9402fe1 	ldr	x1, [sp, #88]
    8388:	f9019a81 	str	x1, [x20, #816]
    838c:	97fff011 	bl	43d0 <fwp_tape_buffers_release>
    8390:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8394:	f947e863 	ldr	x3, [x3, #4048]
    8398:	d2800262 	mov	x2, #0x13                  	// #19
    839c:	d2800021 	mov	x1, #0x1                   	// #1
    83a0:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    83a4:	91132000 	add	x0, x0, #0x4c8
    83a8:	f9400063 	ldr	x3, [x3]
    83ac:	97ffe975 	bl	2980 <fwrite@plt>
    83b0:	d2800000 	mov	x0, #0x0                   	// #0
    83b4:	97ffe97f 	bl	29b0 <fflush@plt>
    83b8:	52800cc0 	mov	w0, #0x66                  	// #102
    83bc:	97ffe98d 	bl	29f0 <_Exit@plt>
    83c0:	eb01033f 	cmp	x25, x1
    83c4:	54ff9b40 	b.eq	772c <f12+0x18c>  // b.none
    83c8:	aa0103f9 	mov	x25, x1
    83cc:	9100043b 	add	x27, x1, #0x1
    83d0:	f9403a9a 	ldr	x26, [x20, #112]
    83d4:	d37ff821 	lsl	x1, x1, #1
    83d8:	17fffcf3 	b	77a4 <f12+0x204>
    83dc:	b5ffabd6 	cbnz	x22, 7954 <f12+0x3b4>
    83e0:	d280001a 	mov	x26, #0x0                   	// #0
    83e4:	17fffd82 	b	79ec <f12+0x44c>
    83e8:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x30>
    83ec:	91094000 	add	x0, x0, #0x250
    83f0:	94001428 	bl	d490 <atexit>
    83f4:	35fffce0 	cbnz	w0, 8390 <f12+0xdf0>
    83f8:	52800020 	mov	w0, #0x1                   	// #1
    83fc:	b9036700 	str	w0, [x24, #868]
    8400:	17fffcb7 	b	76dc <f12+0x13c>
    8404:	72003c3f 	tst	w1, #0xffff
    8408:	54ffaa41 	b.ne	7950 <f12+0x3b0>  // b.any
    840c:	17fffd4c 	b	793c <f12+0x39c>
    8410:	72003c3f 	tst	w1, #0xffff
    8414:	54ff9380 	b.eq	7684 <f12+0xe4>  // b.none
    8418:	aa1703e0 	mov	x0, x23
    841c:	97fff6ed 	bl	5fd0 <fwp_closure_drop>
    8420:	b5ff9455 	cbnz	x21, 76a8 <f12+0x108>
    8424:	52800000 	mov	w0, #0x0                   	// #0
    8428:	d2800017 	mov	x23, #0x0                   	// #0
    842c:	97ffec71 	bl	35f0 <descent_phase_step>
    8430:	17fffca8 	b	76d0 <f12+0x130>
    8434:	aa1b03fc 	mov	x28, x27
    8438:	17fffdac 	b	7ae8 <f12+0x548>
    843c:	72003c3f 	tst	w1, #0xffff
    8440:	54ffc501 	b.ne	7ce0 <f12+0x740>  // b.any
    8444:	17fffe22 	b	7ccc <f12+0x72c>
    8448:	3ccb8002 	ldur	q2, [x0, #184]
    844c:	9102e001 	add	x1, x0, #0xb8
    8450:	3ccc8001 	ldur	q1, [x0, #200]
    8454:	f900781f 	str	xzr, [x0, #240]
    8458:	4f000400 	movi	v0.4s, #0x0
    845c:	ad010702 	stp	q2, q1, [x24, #32]
    8460:	a94d8002 	ldp	x2, x0, [x0, #216]
    8464:	f9000f00 	str	x0, [x24, #24]
    8468:	f9401820 	ldr	x0, [x1, #48]
    846c:	f9002302 	str	x2, [x24, #64]
    8470:	f9002700 	str	x0, [x24, #72]
    8474:	ad000020 	stp	q0, q0, [x1]
    8478:	3d800820 	str	q0, [x1, #32]
    847c:	f900183f 	str	xzr, [x1, #48]
    8480:	17fffcd7 	b	77dc <f12+0x23c>
    8484:	d37ffb38 	lsl	x24, x25, #1
    8488:	d29fffe0 	mov	x0, #0xffff                	// #65535
    848c:	eb00031f 	cmp	x24, x0
    8490:	9a80d318 	csel	x24, x24, x0, le
    8494:	8b180701 	add	x1, x24, x24, lsl #1
    8498:	8b010b01 	add	x1, x24, x1, lsl #2
    849c:	d37df021 	lsl	x1, x1, #3
    84a0:	17fffcae 	b	7758 <f12+0x1b8>
    84a4:	52800041 	mov	w1, #0x2                   	// #2
    84a8:	d2800100 	mov	x0, #0x8                   	// #8
    84ac:	97fff2a5 	bl	4f40 <fwp_heap_alloc>
    84b0:	aa0003f9 	mov	x25, x0
    84b4:	d2800014 	mov	x20, #0x0                   	// #0
    84b8:	17ffff36 	b	8190 <f12+0xbf0>
    84bc:	72003c3f 	tst	w1, #0xffff
    84c0:	54fff2a0 	b.eq	8314 <f12+0xd74>  // b.none
    84c4:	aa1603e0 	mov	x0, x22
    84c8:	17fffe30 	b	7d88 <f12+0x7e8>
    84cc:	aa0203e0 	mov	x0, x2
    84d0:	d2800101 	mov	x1, #0x8                   	// #8
    84d4:	f90017e2 	str	x2, [sp, #40]
    84d8:	97ffe8e2 	bl	2860 <calloc@plt>
    84dc:	f94017e2 	ldr	x2, [sp, #40]
    84e0:	aa0003fa 	mov	x26, x0
    84e4:	17fffd93 	b	7b30 <f12+0x590>
    84e8:	f9400343 	ldr	x3, [x26]
    84ec:	b7fffdc3 	tbnz	x3, #63, 84a4 <f12+0xf04>
    84f0:	9117c261 	add	x1, x19, #0x5f0
    84f4:	f94007e4 	ldr	x4, [sp, #8]
    84f8:	f949d820 	ldr	x0, [x1, #5040]
    84fc:	f949ec21 	ldr	x1, [x1, #5080]
    8500:	cb000080 	sub	x0, x4, x0
    8504:	eb01401f 	cmp	x0, x1, lsl #16
    8508:	54fffce2 	b.cs	84a4 <f12+0xf04>  // b.hs, b.nlast
    850c:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8510:	17fffe4d 	b	7e44 <f12+0x8a4>
    8514:	aa1903e0 	mov	x0, x25
    8518:	97fff0ca 	bl	4840 <fwp_rc_forget_slot>
    851c:	17fffd0b 	b	7948 <f12+0x3a8>
    8520:	aa1703e0 	mov	x0, x23
    8524:	97fff0c7 	bl	4840 <fwp_rc_forget_slot>
    8528:	17fffdec 	b	7cd8 <f12+0x738>
    852c:	aa1803e0 	mov	x0, x24
    8530:	97fff0c4 	bl	4840 <fwp_rc_forget_slot>
    8534:	17ffff7b 	b	8320 <f12+0xd80>
    8538:	97fff07b 	bl	4724 <fwp_rc_wide_dup>
    853c:	17fffc58 	b	769c <f12+0xfc>
    8540:	d280001a 	mov	x26, #0x0                   	// #0
    8544:	17fffe9f 	b	7fc0 <f12+0xa20>
    8548:	d2800019 	mov	x25, #0x0                   	// #0
    854c:	d2800014 	mov	x20, #0x0                   	// #0
    8550:	17ffff10 	b	8190 <f12+0xbf0>
    8554:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8558:	91240000 	add	x0, x0, #0x900
    855c:	97ffeca9 	bl	3800 <fwp_trap>
    8560:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8564:	9121a000 	add	x0, x0, #0x868
    8568:	97ffeca6 	bl	3800 <fwp_trap>
    856c:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8570:	91258000 	add	x0, x0, #0x960
    8574:	97ffeca3 	bl	3800 <fwp_trap>
    8578:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    857c:	91280000 	add	x0, x0, #0xa00
    8580:	97ffeca0 	bl	3800 <fwp_trap>
    8584:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8588:	91270000 	add	x0, x0, #0x9c0
    858c:	97ffec9d 	bl	3800 <fwp_trap>
    8590:	97ffe8bc 	bl	2880 <__stack_chk_fail@plt>
    8594:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8598:	9122c000 	add	x0, x0, #0x8b0
    859c:	97ffec99 	bl	3800 <fwp_trap>
    85a0:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    85a4:	9125c000 	add	x0, x0, #0x970
    85a8:	97ffec96 	bl	3800 <fwp_trap>
    85ac:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    85b0:	91264000 	add	x0, x0, #0x990
    85b4:	97ffec93 	bl	3800 <fwp_trap>
    85b8:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    85bc:	9127c000 	add	x0, x0, #0x9f0
    85c0:	97ffec90 	bl	3800 <fwp_trap>
    85c4:	97ffe8c3 	bl	28d0 <abort@plt>
    85c8:	97ffe92e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    85cc:	d503201f 	nop

00000000000085d0 <fwp_owned_entry12>:
    85d0:	f9400000 	ldr	x0, [x0]
    85d4:	17fffbf3 	b	75a0 <f12>
    85d8:	d503201f 	nop
    85dc:	d503201f 	nop

00000000000085e0 <e12>:
    85e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    85e4:	910003fd 	mov	x29, sp
    85e8:	f9000bf3 	str	x19, [sp, #16]
    85ec:	f9400013 	ldr	x19, [x0]
    85f0:	aa1303e0 	mov	x0, x19
    85f4:	97fff49b 	bl	5860 <fwp_rc_share>
    85f8:	aa1303e0 	mov	x0, x19
    85fc:	97fffbe9 	bl	75a0 <f12>
    8600:	aa0003f3 	mov	x19, x0
    8604:	97fff497 	bl	5860 <fwp_rc_share>
    8608:	aa1303e0 	mov	x0, x19
    860c:	f9400bf3 	ldr	x19, [sp, #16]
    8610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8614:	d65f03c0 	ret
    8618:	d503201f 	nop
    861c:	d503201f 	nop

0000000000008620 <fwp_write>:
    8620:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8624:	910003fd 	mov	x29, sp
    8628:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    862c:	f947f484 	ldr	x4, [x4, #4072]
    8630:	a90153f3 	stp	x19, x20, [sp, #16]
    8634:	d10943ff 	sub	sp, sp, #0x250
    8638:	b9400045 	ldr	w5, [x2]
    863c:	aa0003f4 	mov	x20, x0
    8640:	f9400080 	ldr	x0, [x4]
    8644:	f90127e0 	str	x0, [sp, #584]
    8648:	d2800000 	mov	x0, #0x0                   	// #0
    864c:	710064bf 	cmp	w5, #0x19
    8650:	54000408 	b.hi	86d0 <fwp_write+0xb0>  // b.pmore
    8654:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xb40>
    8658:	aa0103f3 	mov	x19, x1
    865c:	91084000 	add	x0, x0, #0x210
    8660:	f9013bf5 	str	x21, [sp, #624]
    8664:	f9013ff6 	str	x22, [sp, #632]
    8668:	f90153fb 	str	x27, [sp, #672]
    866c:	f90157fc 	str	x28, [sp, #680]
    8670:	aa0203fc 	mov	x28, x2
    8674:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8678:	10000061 	adr	x1, 8684 <fwp_write+0x64>
    867c:	8b20a820 	add	x0, x1, w0, sxth #2
    8680:	d61f0000 	br	x0
    8684:	910123e0 	add	x0, sp, #0x48
    8688:	aa1303e5 	mov	x5, x19
    868c:	b0000024 	adrp	x4, d000 <__divti3+0x260>
    8690:	aa0003f3 	mov	x19, x0
    8694:	91298084 	add	x4, x4, #0xa60
    8698:	d2804003 	mov	x3, #0x200                 	// #512
    869c:	aa0303e1 	mov	x1, x3
    86a0:	52800042 	mov	w2, #0x2                   	// #2
    86a4:	97ffe853 	bl	27f0 <__snprintf_chk@plt>
    86a8:	aa1303e0 	mov	x0, x19
    86ac:	97ffe819 	bl	2710 <strlen@plt>
    86b0:	aa1303e1 	mov	x1, x19
    86b4:	aa0003e2 	mov	x2, x0
    86b8:	aa1403e0 	mov	x0, x20
    86bc:	97ffebb5 	bl	3590 <buf_put>
    86c0:	f9413bf5 	ldr	x21, [sp, #624]
    86c4:	f9413ff6 	ldr	x22, [sp, #632]
    86c8:	f94153fb 	ldr	x27, [sp, #672]
    86cc:	f94157fc 	ldr	x28, [sp, #680]
    86d0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    86d4:	f947f400 	ldr	x0, [x0, #4072]
    86d8:	f94127e2 	ldr	x2, [sp, #584]
    86dc:	f9400001 	ldr	x1, [x0]
    86e0:	eb010042 	subs	x2, x2, x1
    86e4:	d2800001 	mov	x1, #0x0                   	// #0
    86e8:	540077c1 	b.ne	95e0 <fwp_write+0xfc0>  // b.any
    86ec:	910943ff 	add	sp, sp, #0x250
    86f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    86f4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    86f8:	d65f03c0 	ret
    86fc:	910123e0 	add	x0, sp, #0x48
    8700:	aa1303e5 	mov	x5, x19
    8704:	b0000024 	adrp	x4, d000 <__divti3+0x260>
    8708:	aa0003f3 	mov	x19, x0
    870c:	91296084 	add	x4, x4, #0xa58
    8710:	d2804003 	mov	x3, #0x200                 	// #512
    8714:	17ffffe2 	b	869c <fwp_write+0x7c>
    8718:	71004cbf 	cmp	w5, #0x13
    871c:	b0000020 	adrp	x0, d000 <__divti3+0x260>
    8720:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8724:	91292000 	add	x0, x0, #0xa48
    8728:	91294021 	add	x1, x1, #0xa50
    872c:	d2800082 	mov	x2, #0x4                   	// #4
    8730:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8734:	aa1403e0 	mov	x0, x20
    8738:	f90143f7 	str	x23, [sp, #640]
    873c:	d2800016 	mov	x22, #0x0                   	// #0
    8740:	f90147f8 	str	x24, [sp, #648]
    8744:	97ffeb93 	bl	3590 <buf_put>
    8748:	f9400260 	ldr	x0, [x19]
    874c:	b0000037 	adrp	x23, d000 <__divti3+0x260>
    8750:	d2800015 	mov	x21, #0x0                   	// #0
    8754:	912b42f7 	add	x23, x23, #0xad0
    8758:	b40047a0 	cbz	x0, 904c <fwp_write+0xa2c>
    875c:	b9400380 	ldr	w0, [x28]
    8760:	52800003 	mov	w3, #0x0                   	// #0
    8764:	f9401f82 	ldr	x2, [x28, #56]
    8768:	71004c1f 	cmp	w0, #0x13
    876c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8770:	aa1403e0 	mov	x0, x20
    8774:	8b010e61 	add	x1, x19, x1, lsl #3
    8778:	f9400421 	ldr	x1, [x1, #8]
    877c:	97ffffa9 	bl	8620 <fwp_write>
    8780:	b9400380 	ldr	w0, [x28]
    8784:	7100481f 	cmp	w0, #0x12
    8788:	54004b40 	b.eq	90f0 <fwp_write+0xad0>  // b.none
    878c:	f9400260 	ldr	x0, [x19]
    8790:	910006b5 	add	x21, x21, #0x1
    8794:	91000ad6 	add	x22, x22, #0x2
    8798:	eb15001f 	cmp	x0, x21
    879c:	54004589 	b.ls	904c <fwp_write+0xa2c>  // b.plast
    87a0:	aa1703e1 	mov	x1, x23
    87a4:	aa1403e0 	mov	x0, x20
    87a8:	d2800042 	mov	x2, #0x2                   	// #2
    87ac:	97ffeb79 	bl	3590 <buf_put>
    87b0:	17ffffeb 	b	875c <fwp_write+0x13c>
    87b4:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    87b8:	912a2021 	add	x1, x1, #0xa88
    87bc:	d28000c2 	mov	x2, #0x6                   	// #6
    87c0:	aa1403e0 	mov	x0, x20
    87c4:	91004273 	add	x19, x19, #0x10
    87c8:	97ffeb72 	bl	3590 <buf_put>
    87cc:	aa1303e0 	mov	x0, x19
    87d0:	97ffe7d0 	bl	2710 <strlen@plt>
    87d4:	aa1303e1 	mov	x1, x19
    87d8:	aa0003e2 	mov	x2, x0
    87dc:	aa1403e0 	mov	x0, x20
    87e0:	97ffeb6c 	bl	3590 <buf_put>
    87e4:	528007c3 	mov	w3, #0x3e                  	// #62
    87e8:	aa1403e0 	mov	x0, x20
    87ec:	91001fe1 	add	x1, sp, #0x7
    87f0:	d2800022 	mov	x2, #0x1                   	// #1
    87f4:	39001fe3 	strb	w3, [sp, #7]
    87f8:	17ffffb1 	b	86bc <fwp_write+0x9c>
    87fc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8800:	f947f400 	ldr	x0, [x0, #4072]
    8804:	f94127e2 	ldr	x2, [sp, #584]
    8808:	f9400001 	ldr	x1, [x0]
    880c:	eb010042 	subs	x2, x2, x1
    8810:	d2800001 	mov	x1, #0x0                   	// #0
    8814:	540034e1 	b.ne	8eb0 <fwp_write+0x890>  // b.any
    8818:	f9413bf5 	ldr	x21, [sp, #624]
    881c:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8820:	f9413ff6 	ldr	x22, [sp, #632]
    8824:	aa1403e0 	mov	x0, x20
    8828:	9129a021 	add	x1, x1, #0xa68
    882c:	d2800142 	mov	x2, #0xa                   	// #10
    8830:	f94153fb 	ldr	x27, [sp, #672]
    8834:	f94157fc 	ldr	x28, [sp, #680]
    8838:	910943ff 	add	sp, sp, #0x250
    883c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8840:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8844:	17ffeb53 	b	3590 <buf_put>
    8848:	f9400456 	ldr	x22, [x2, #8]
    884c:	f90143f7 	str	x23, [sp, #640]
    8850:	f90147f8 	str	x24, [sp, #648]
    8854:	b4005b16 	cbz	x22, 93b4 <fwp_write+0xd94>
    8858:	aa1603e0 	mov	x0, x22
    885c:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8860:	912ba021 	add	x1, x1, #0xae8
    8864:	97ffe827 	bl	2900 <strcmp@plt>
    8868:	2a0003f5 	mov	w21, w0
    886c:	34005fe0 	cbz	w0, 9468 <fwp_write+0xe48>
    8870:	aa1603e0 	mov	x0, x22
    8874:	97ffe7a7 	bl	2710 <strlen@plt>
    8878:	aa1603e1 	mov	x1, x22
    887c:	aa0003e2 	mov	x2, x0
    8880:	aa1403e0 	mov	x0, x20
    8884:	97ffeb43 	bl	3590 <buf_put>
    8888:	52800403 	mov	w3, #0x20                  	// #32
    888c:	91001ff5 	add	x21, sp, #0x7
    8890:	aa1503e1 	mov	x1, x21
    8894:	aa1403e0 	mov	x0, x20
    8898:	d2800022 	mov	x2, #0x1                   	// #1
    889c:	39001fe3 	strb	w3, [sp, #7]
    88a0:	97ffeb3c 	bl	3590 <buf_put>
    88a4:	52800f63 	mov	w3, #0x7b                  	// #123
    88a8:	aa1403e0 	mov	x0, x20
    88ac:	aa1503e1 	mov	x1, x21
    88b0:	d2800022 	mov	x2, #0x1                   	// #1
    88b4:	39001fe3 	strb	w3, [sp, #7]
    88b8:	97ffeb36 	bl	3590 <buf_put>
    88bc:	b9401380 	ldr	w0, [x28, #16]
    88c0:	52800018 	mov	w24, #0x0                   	// #0
    88c4:	7100001f 	cmp	w0, #0x0
    88c8:	54003aad 	b.le	901c <fwp_write+0x9fc>
    88cc:	f9014bf9 	str	x25, [sp, #656]
    88d0:	b0000039 	adrp	x25, d000 <__divti3+0x260>
    88d4:	912c4339 	add	x25, x25, #0xb10
    88d8:	f9014ffa 	str	x26, [sp, #664]
    88dc:	b000003a 	adrp	x26, d000 <__divti3+0x260>
    88e0:	912b435a 	add	x26, x26, #0xad0
    88e4:	91002276 	add	x22, x19, #0x8
    88e8:	d2800013 	mov	x19, #0x0                   	// #0
    88ec:	b5003e93 	cbnz	x19, 90bc <fwp_write+0xa9c>
    88f0:	d37df277 	lsl	x23, x19, #3
    88f4:	34003cb8 	cbz	w24, 9088 <fwp_write+0xa68>
    88f8:	f9401382 	ldr	x2, [x28, #32]
    88fc:	aa1403e0 	mov	x0, x20
    8900:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8904:	52800003 	mov	w3, #0x0                   	// #0
    8908:	f8776842 	ldr	x2, [x2, x23]
    890c:	91000673 	add	x19, x19, #0x1
    8910:	97ffff44 	bl	8620 <fwp_write>
    8914:	b9401380 	ldr	w0, [x28, #16]
    8918:	6b13001f 	cmp	w0, w19
    891c:	54fffe8c 	b.gt	88ec <fwp_write+0x2cc>
    8920:	f9414bf9 	ldr	x25, [sp, #656]
    8924:	f9414ffa 	ldr	x26, [sp, #664]
    8928:	340037b8 	cbz	w24, 901c <fwp_write+0x9fc>
    892c:	52800523 	mov	w3, #0x29                  	// #41
    8930:	aa1503e1 	mov	x1, x21
    8934:	aa1403e0 	mov	x0, x20
    8938:	d2800022 	mov	x2, #0x1                   	// #1
    893c:	39001fe3 	strb	w3, [sp, #7]
    8940:	97ffeb14 	bl	3590 <buf_put>
    8944:	f9413bf5 	ldr	x21, [sp, #624]
    8948:	f9413ff6 	ldr	x22, [sp, #632]
    894c:	f94143f7 	ldr	x23, [sp, #640]
    8950:	f94147f8 	ldr	x24, [sp, #648]
    8954:	f94153fb 	ldr	x27, [sp, #672]
    8958:	f94157fc 	ldr	x28, [sp, #680]
    895c:	17ffff5d 	b	86d0 <fwp_write+0xb0>
    8960:	b9404855 	ldr	w21, [x2, #72]
    8964:	aa1403e0 	mov	x0, x20
    8968:	93407eb6 	sxtw	x22, w21
    896c:	91000ac1 	add	x1, x22, #0x2
    8970:	97ffead5 	bl	34c4 <buf_grow>
    8974:	a9400281 	ldp	x1, x0, [x20]
    8978:	528e8603 	mov	w3, #0x7430                	// #29744
    897c:	78206823 	strh	w3, [x1, x0]
    8980:	8b000022 	add	x2, x1, x0
    8984:	710002bf 	cmp	w21, #0x0
    8988:	540036cd 	b.le	9060 <fwp_write+0xa40>
    898c:	110006a3 	add	w3, w21, #0x1
    8990:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8994:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8998:	91000449 	add	x9, x2, #0x1
    899c:	8b23c043 	add	x3, x2, w3, sxtw
    89a0:	f28aaac6 	movk	x6, #0x5556
    89a4:	f2955568 	movk	x8, #0xaaab
    89a8:	1400000d 	b	89dc <fwp_write+0x3bc>
    89ac:	d2800021 	mov	x1, #0x1                   	// #1
    89b0:	528005a5 	mov	w5, #0x2d                  	// #45
    89b4:	f100001f 	cmp	x0, #0x0
    89b8:	9b467e60 	smulh	x0, x19, x6
    89bc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    89c0:	381ff465 	strb	w5, [x3], #-1
    89c4:	cb040000 	sub	x0, x0, x4
    89c8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    89cc:	cb020000 	sub	x0, x0, x2
    89d0:	8b010013 	add	x19, x0, x1
    89d4:	eb03013f 	cmp	x9, x3
    89d8:	54003440 	b.eq	9060 <fwp_write+0xa40>  // b.none
    89dc:	9b467e60 	smulh	x0, x19, x6
    89e0:	937ffe64 	asr	x4, x19, #63
    89e4:	52800605 	mov	w5, #0x30                  	// #48
    89e8:	cb040000 	sub	x0, x0, x4
    89ec:	8b000400 	add	x0, x0, x0, lsl #1
    89f0:	cb000260 	sub	x0, x19, x0
    89f4:	91000c01 	add	x1, x0, #0x3
    89f8:	9bc87c22 	umulh	x2, x1, x8
    89fc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8a00:	8b4204e2 	add	x2, x7, x2, lsr #1
    8a04:	eb020021 	subs	x1, x1, x2
    8a08:	54fffd60 	b.eq	89b4 <fwp_write+0x394>  // b.none
    8a0c:	f100043f 	cmp	x1, #0x1
    8a10:	54fffce1 	b.ne	89ac <fwp_write+0x38c>  // b.any
    8a14:	d2800001 	mov	x1, #0x0                   	// #0
    8a18:	52800565 	mov	w5, #0x2b                  	// #43
    8a1c:	17ffffe6 	b	89b4 <fwp_write+0x394>
    8a20:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a24:	f947f400 	ldr	x0, [x0, #4072]
    8a28:	f94127e2 	ldr	x2, [sp, #584]
    8a2c:	f9400001 	ldr	x1, [x0]
    8a30:	eb010042 	subs	x2, x2, x1
    8a34:	d2800001 	mov	x1, #0x0                   	// #0
    8a38:	540023c1 	b.ne	8eb0 <fwp_write+0x890>  // b.any
    8a3c:	f9413bf5 	ldr	x21, [sp, #624]
    8a40:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8a44:	f9413ff6 	ldr	x22, [sp, #632]
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	9129e021 	add	x1, x1, #0xa78
    8a50:	d2800102 	mov	x2, #0x8                   	// #8
    8a54:	17ffff77 	b	8830 <fwp_write+0x210>
    8a58:	aa1403e0 	mov	x0, x20
    8a5c:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8a60:	d28000c2 	mov	x2, #0x6                   	// #6
    8a64:	912b6021 	add	x1, x1, #0xad8
    8a68:	97ffeaca 	bl	3590 <buf_put>
    8a6c:	d2800015 	mov	x21, #0x0                   	// #0
    8a70:	f9400263 	ldr	x3, [x19]
    8a74:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8a78:	54002c60 	b.eq	9004 <fwp_write+0x9e4>  // b.none
    8a7c:	f9401f82 	ldr	x2, [x28, #56]
    8a80:	f90143f7 	str	x23, [sp, #640]
    8a84:	f90147f8 	str	x24, [sp, #648]
    8a88:	d2800857 	mov	x23, #0x42                  	// #66
    8a8c:	f9014bf9 	str	x25, [sp, #656]
    8a90:	b0000036 	adrp	x22, d000 <__divti3+0x260>
    8a94:	f9014ffa 	str	x26, [sp, #664]
    8a98:	912b42d6 	add	x22, x22, #0xad0
    8a9c:	d2800038 	mov	x24, #0x1                   	// #1
    8aa0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8aa4:	d2809099 	mov	x25, #0x484                 	// #1156
    8aa8:	b40004a2 	cbz	x2, 8b3c <fwp_write+0x51c>
    8aac:	b9400040 	ldr	w0, [x2]
    8ab0:	7100701f 	cmp	w0, #0x1c
    8ab4:	540042c0 	b.eq	930c <fwp_write+0xcec>  // b.none
    8ab8:	71006c1f 	cmp	w0, #0x1b
    8abc:	54000408 	b.hi	8b3c <fwp_write+0x51c>  // b.pmore
    8ac0:	9ac02301 	lsl	x1, x24, x0
    8ac4:	ea17003f 	tst	x1, x23
    8ac8:	540036a1 	b.ne	919c <fwp_write+0xb7c>  // b.any
    8acc:	ea19003f 	tst	x1, x25
    8ad0:	54003521 	b.ne	9174 <fwp_write+0xb54>  // b.any
    8ad4:	d2800424 	mov	x4, #0x21                  	// #33
    8ad8:	ea04003f 	tst	x1, x4
    8adc:	54000300 	b.eq	8b3c <fwp_write+0x51c>  // b.none
    8ae0:	b7f849c3 	tbnz	x3, #63, 9418 <fwp_write+0xdf8>
    8ae4:	91002261 	add	x1, x19, #0x8
    8ae8:	8b150021 	add	x1, x1, x21
    8aec:	39400021 	ldrb	w1, [x1]
    8af0:	7100001f 	cmp	w0, #0x0
    8af4:	93401c23 	sxtb	x3, w1
    8af8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8afc:	d503201f 	nop
    8b00:	aa1403e0 	mov	x0, x20
    8b04:	52800003 	mov	w3, #0x0                   	// #0
    8b08:	97fffec6 	bl	8620 <fwp_write>
    8b0c:	910006b5 	add	x21, x21, #0x1
    8b10:	f9400260 	ldr	x0, [x19]
    8b14:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8b18:	eb0002bf 	cmp	x21, x0
    8b1c:	540026c2 	b.cs	8ff4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8b20:	d2800042 	mov	x2, #0x2                   	// #2
    8b24:	aa1603e1 	mov	x1, x22
    8b28:	aa1403e0 	mov	x0, x20
    8b2c:	97ffea99 	bl	3590 <buf_put>
    8b30:	f9401f82 	ldr	x2, [x28, #56]
    8b34:	f9400263 	ldr	x3, [x19]
    8b38:	b5fffba2 	cbnz	x2, 8aac <fwp_write+0x48c>
    8b3c:	d37df2a0 	lsl	x0, x21, #3
    8b40:	b7f83f03 	tbnz	x3, #63, 9320 <fwp_write+0xd00>
    8b44:	91002261 	add	x1, x19, #0x8
    8b48:	8b000020 	add	x0, x1, x0
    8b4c:	f9400001 	ldr	x1, [x0]
    8b50:	17ffffec 	b	8b00 <fwp_write+0x4e0>
    8b54:	a9400e62 	ldp	x2, x3, [x19]
    8b58:	b7f83ca3 	tbnz	x3, #63, 92ec <fwp_write+0xccc>
    8b5c:	910123f5 	add	x21, sp, #0x48
    8b60:	aa1503e0 	mov	x0, x21
    8b64:	97ffe8af 	bl	2e20 <fwp_fmt_u128>
    8b68:	aa1503e0 	mov	x0, x21
    8b6c:	97ffe6e9 	bl	2710 <strlen@plt>
    8b70:	aa1503e1 	mov	x1, x21
    8b74:	aa0003e2 	mov	x2, x0
    8b78:	17fffed0 	b	86b8 <fwp_write+0x98>
    8b7c:	fd015be8 	str	d8, [sp, #688]
    8b80:	1e270268 	fmov	s8, w19
    8b84:	fd015fe9 	str	d9, [sp, #696]
    8b88:	1e282100 	fcmp	s8, s8
    8b8c:	54004d26 	b.vs	9530 <fwp_write+0xf10>
    8b90:	1e20c101 	fabs	s1, s8
    8b94:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8b98:	1e270000 	fmov	s0, w0
    8b9c:	1e202020 	fcmp	s1, s0
    8ba0:	54002c0d 	b.le	9120 <fwp_write+0xb00>
    8ba4:	1e202118 	fcmpe	s8, #0.0
    8ba8:	b0000022 	adrp	x2, d000 <__divti3+0x260>
    8bac:	91166042 	add	x2, x2, #0x598
    8bb0:	910123f5 	add	x21, sp, #0x48
    8bb4:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8bb8:	9128a021 	add	x1, x1, #0xa28
    8bbc:	aa1503e0 	mov	x0, x21
    8bc0:	9a81c041 	csel	x1, x2, x1, gt
    8bc4:	97ffe77f 	bl	29c0 <strcpy@plt>
    8bc8:	aa1503e0 	mov	x0, x21
    8bcc:	97ffe6d1 	bl	2710 <strlen@plt>
    8bd0:	aa1503e1 	mov	x1, x21
    8bd4:	aa0003e2 	mov	x2, x0
    8bd8:	aa1403e0 	mov	x0, x20
    8bdc:	97ffea6d 	bl	3590 <buf_put>
    8be0:	f9413bf5 	ldr	x21, [sp, #624]
    8be4:	f9413ff6 	ldr	x22, [sp, #632]
    8be8:	f94153fb 	ldr	x27, [sp, #672]
    8bec:	f94157fc 	ldr	x28, [sp, #680]
    8bf0:	fd415be8 	ldr	d8, [sp, #688]
    8bf4:	fd415fe9 	ldr	d9, [sp, #696]
    8bf8:	17fffeb6 	b	86d0 <fwp_write+0xb0>
    8bfc:	f9400276 	ldr	x22, [x19]
    8c00:	34002e03 	cbz	w3, 91c0 <fwp_write+0xba0>
    8c04:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8c08:	f947f400 	ldr	x0, [x0, #4072]
    8c0c:	f94127e2 	ldr	x2, [sp, #584]
    8c10:	f9400001 	ldr	x1, [x0]
    8c14:	eb010042 	subs	x2, x2, x1
    8c18:	d2800001 	mov	x1, #0x0                   	// #0
    8c1c:	540014a1 	b.ne	8eb0 <fwp_write+0x890>  // b.any
    8c20:	aa1603e2 	mov	x2, x22
    8c24:	91002261 	add	x1, x19, #0x8
    8c28:	f9413bf5 	ldr	x21, [sp, #624]
    8c2c:	aa1403e0 	mov	x0, x20
    8c30:	f9413ff6 	ldr	x22, [sp, #632]
    8c34:	17fffeff 	b	8830 <fwp_write+0x210>
    8c38:	fd015be8 	str	d8, [sp, #688]
    8c3c:	9e670268 	fmov	d8, x19
    8c40:	fd015fe9 	str	d9, [sp, #696]
    8c44:	1e682100 	fcmp	d8, d8
    8c48:	54004746 	b.vs	9530 <fwp_write+0xf10>
    8c4c:	1e60c101 	fabs	d1, d8
    8c50:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8c54:	9e670000 	fmov	d0, x0
    8c58:	910123f5 	add	x21, sp, #0x48
    8c5c:	52800033 	mov	w19, #0x1                   	// #1
    8c60:	1e602020 	fcmp	d1, d0
    8c64:	540001ad 	b.le	8c98 <fwp_write+0x678>
    8c68:	1e602118 	fcmpe	d8, #0.0
    8c6c:	b0000022 	adrp	x2, d000 <__divti3+0x260>
    8c70:	91166042 	add	x2, x2, #0x598
    8c74:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8c78:	9128a021 	add	x1, x1, #0xa28
    8c7c:	aa1503e0 	mov	x0, x21
    8c80:	9a81c041 	csel	x1, x2, x1, gt
    8c84:	97ffe74f 	bl	29c0 <strcpy@plt>
    8c88:	17ffffd0 	b	8bc8 <fwp_write+0x5a8>
    8c8c:	11000673 	add	w19, w19, #0x1
    8c90:	71004a7f 	cmp	w19, #0x12
    8c94:	54003860 	b.eq	93a0 <fwp_write+0xd80>  // b.none
    8c98:	1e604100 	fmov	d0, d8
    8c9c:	2a1303e1 	mov	w1, w19
    8ca0:	aa1503e0 	mov	x0, x21
    8ca4:	97ffebbc 	bl	3b94 <fwp_format_g.constprop.0>
    8ca8:	aa1503e0 	mov	x0, x21
    8cac:	d2800001 	mov	x1, #0x0                   	// #0
    8cb0:	97ffe6ac 	bl	2760 <strtod@plt>
    8cb4:	1e602100 	fcmp	d8, d0
    8cb8:	54fffea1 	b.ne	8c8c <fwp_write+0x66c>  // b.any
    8cbc:	aa1503e0 	mov	x0, x21
    8cc0:	97ffeaad 	bl	3774 <fwp_finish_float>
    8cc4:	17ffffc1 	b	8bc8 <fwp_write+0x5a8>
    8cc8:	a9400e62 	ldp	x2, x3, [x19]
    8ccc:	910123f3 	add	x19, sp, #0x48
    8cd0:	aa1303e0 	mov	x0, x19
    8cd4:	97ffe853 	bl	2e20 <fwp_fmt_u128>
    8cd8:	17fffe74 	b	86a8 <fwp_write+0x88>
    8cdc:	f90143f7 	str	x23, [sp, #640]
    8ce0:	f90147f8 	str	x24, [sp, #648]
    8ce4:	2a1303f8 	mov	w24, w19
    8ce8:	f9014bf9 	str	x25, [sp, #656]
    8cec:	f9014ffa 	str	x26, [sp, #664]
    8cf0:	f13ffe7f 	cmp	x19, #0xfff
    8cf4:	54000049 	b.ls	8cfc <fwp_write+0x6dc>  // b.plast
    8cf8:	b9400278 	ldr	w24, [x19]
    8cfc:	f9400f80 	ldr	x0, [x28, #24]
    8d00:	2a1803f5 	mov	w21, w24
    8d04:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8d08:	d37ef6b9 	lsl	x25, x21, #2
    8d0c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8d10:	aa1603e0 	mov	x0, x22
    8d14:	97ffe67f 	bl	2710 <strlen@plt>
    8d18:	aa1603e1 	mov	x1, x22
    8d1c:	aa0003e2 	mov	x2, x0
    8d20:	aa1403e0 	mov	x0, x20
    8d24:	97ffea1b 	bl	3590 <buf_put>
    8d28:	f9401780 	ldr	x0, [x28, #40]
    8d2c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8d30:	7100001f 	cmp	w0, #0x0
    8d34:	5400068d 	b.le	8e04 <fwp_write+0x7e4>
    8d38:	91002276 	add	x22, x19, #0x8
    8d3c:	91001ff5 	add	x21, sp, #0x7
    8d40:	d280001b 	mov	x27, #0x0                   	// #0
    8d44:	5280041a 	mov	w26, #0x20                  	// #32
    8d48:	f9401b80 	ldr	x0, [x28, #48]
    8d4c:	aa1503e1 	mov	x1, x21
    8d50:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8d54:	d2800022 	mov	x2, #0x1                   	// #1
    8d58:	f8786803 	ldr	x3, [x0, x24]
    8d5c:	aa1403e0 	mov	x0, x20
    8d60:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8d64:	39001ffa 	strb	w26, [sp, #7]
    8d68:	97ffea0a 	bl	3590 <buf_put>
    8d6c:	f13ffeff 	cmp	x23, #0xfff
    8d70:	b9400261 	ldr	w1, [x19]
    8d74:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8d78:	7100383f 	cmp	w1, #0xe
    8d7c:	54000160 	b.eq	8da8 <fwp_write+0x788>  // b.none
    8d80:	7100403f 	cmp	w1, #0x10
    8d84:	54001a60 	b.eq	90d0 <fwp_write+0xab0>  // b.none
    8d88:	7100283f 	cmp	w1, #0xa
    8d8c:	54002aa0 	b.eq	92e0 <fwp_write+0xcc0>  // b.none
    8d90:	540014ac 	b.gt	9024 <fwp_write+0xa04>
    8d94:	71000c3f 	cmp	w1, #0x3
    8d98:	540029ac 	b.gt	92cc <fwp_write+0xcac>
    8d9c:	d37ffee0 	lsr	x0, x23, #63
    8da0:	37f814a1 	tbnz	w1, #31, 9034 <fwp_write+0xa14>
    8da4:	d503201f 	nop
    8da8:	34001460 	cbz	w0, 9034 <fwp_write+0xa14>
    8dac:	52800503 	mov	w3, #0x28                  	// #40
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa1403e0 	mov	x0, x20
    8db8:	d2800022 	mov	x2, #0x1                   	// #1
    8dbc:	39001fe3 	strb	w3, [sp, #7]
    8dc0:	97ffe9f4 	bl	3590 <buf_put>
    8dc4:	aa1303e2 	mov	x2, x19
    8dc8:	aa1703e1 	mov	x1, x23
    8dcc:	aa1403e0 	mov	x0, x20
    8dd0:	52800003 	mov	w3, #0x0                   	// #0
    8dd4:	97fffe13 	bl	8620 <fwp_write>
    8dd8:	52800523 	mov	w3, #0x29                  	// #41
    8ddc:	aa1503e1 	mov	x1, x21
    8de0:	aa1403e0 	mov	x0, x20
    8de4:	d2800022 	mov	x2, #0x1                   	// #1
    8de8:	39001fe3 	strb	w3, [sp, #7]
    8dec:	97ffe9e9 	bl	3590 <buf_put>
    8df0:	f9401780 	ldr	x0, [x28, #40]
    8df4:	9100077b 	add	x27, x27, #0x1
    8df8:	b8796800 	ldr	w0, [x0, x25]
    8dfc:	6b1b001f 	cmp	w0, w27
    8e00:	54fffa4c 	b.gt	8d48 <fwp_write+0x728>
    8e04:	f9413bf5 	ldr	x21, [sp, #624]
    8e08:	f9413ff6 	ldr	x22, [sp, #632]
    8e0c:	f94143f7 	ldr	x23, [sp, #640]
    8e10:	f94147f8 	ldr	x24, [sp, #648]
    8e14:	f9414bf9 	ldr	x25, [sp, #656]
    8e18:	f9414ffa 	ldr	x26, [sp, #664]
    8e1c:	f94153fb 	ldr	x27, [sp, #672]
    8e20:	f94157fc 	ldr	x28, [sp, #680]
    8e24:	17fffe2b 	b	86d0 <fwp_write+0xb0>
    8e28:	52800783 	mov	w3, #0x3c                  	// #60
    8e2c:	91001ff3 	add	x19, sp, #0x7
    8e30:	aa1303e1 	mov	x1, x19
    8e34:	d2800022 	mov	x2, #0x1                   	// #1
    8e38:	aa1403e0 	mov	x0, x20
    8e3c:	39001fe3 	strb	w3, [sp, #7]
    8e40:	97ffe9d4 	bl	3590 <buf_put>
    8e44:	f9400795 	ldr	x21, [x28, #8]
    8e48:	aa1503e0 	mov	x0, x21
    8e4c:	97ffe631 	bl	2710 <strlen@plt>
    8e50:	aa1503e1 	mov	x1, x21
    8e54:	aa0003e2 	mov	x2, x0
    8e58:	aa1403e0 	mov	x0, x20
    8e5c:	97ffe9cd 	bl	3590 <buf_put>
    8e60:	528007c3 	mov	w3, #0x3e                  	// #62
    8e64:	aa1303e1 	mov	x1, x19
    8e68:	aa1403e0 	mov	x0, x20
    8e6c:	d2800022 	mov	x2, #0x1                   	// #1
    8e70:	39001fe3 	strb	w3, [sp, #7]
    8e74:	17fffe12 	b	86bc <fwp_write+0x9c>
    8e78:	f100067f 	cmp	x19, #0x1
    8e7c:	540025a0 	b.eq	9330 <fwp_write+0xd10>  // b.none
    8e80:	b100067f 	cmn	x19, #0x1
    8e84:	54002bc0 	b.eq	93fc <fwp_write+0xddc>  // b.none
    8e88:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8e8c:	9128c021 	add	x1, x1, #0xa30
    8e90:	d2800022 	mov	x2, #0x1                   	// #1
    8e94:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8e98:	f947f400 	ldr	x0, [x0, #4072]
    8e9c:	f94127e4 	ldr	x4, [sp, #584]
    8ea0:	f9400003 	ldr	x3, [x0]
    8ea4:	eb030084 	subs	x4, x4, x3
    8ea8:	d2800003 	mov	x3, #0x0                   	// #0
    8eac:	54ffebe0 	b.eq	8c28 <fwp_write+0x608>  // b.none
    8eb0:	f90143f7 	str	x23, [sp, #640]
    8eb4:	f90147f8 	str	x24, [sp, #648]
    8eb8:	f9014bf9 	str	x25, [sp, #656]
    8ebc:	f9014ffa 	str	x26, [sp, #664]
    8ec0:	fd015be8 	str	d8, [sp, #688]
    8ec4:	fd015fe9 	str	d9, [sp, #696]
    8ec8:	97ffe66e 	bl	2880 <__stack_chk_fail@plt>
    8ecc:	52800b63 	mov	w3, #0x5b                  	// #91
    8ed0:	91001ff5 	add	x21, sp, #0x7
    8ed4:	aa1503e1 	mov	x1, x21
    8ed8:	aa1403e0 	mov	x0, x20
    8edc:	d2800022 	mov	x2, #0x1                   	// #1
    8ee0:	b0000036 	adrp	x22, d000 <__divti3+0x260>
    8ee4:	912b42d6 	add	x22, x22, #0xad0
    8ee8:	39001fe3 	strb	w3, [sp, #7]
    8eec:	97ffe9a9 	bl	3590 <buf_put>
    8ef0:	b4000273 	cbz	x19, 8f3c <fwp_write+0x91c>
    8ef4:	f9400661 	ldr	x1, [x19, #8]
    8ef8:	aa1403e0 	mov	x0, x20
    8efc:	f9401f82 	ldr	x2, [x28, #56]
    8f00:	52800003 	mov	w3, #0x0                   	// #0
    8f04:	97fffdc7 	bl	8620 <fwp_write>
    8f08:	f9400a73 	ldr	x19, [x19, #16]
    8f0c:	b4000193 	cbz	x19, 8f3c <fwp_write+0x91c>
    8f10:	aa1603e1 	mov	x1, x22
    8f14:	aa1403e0 	mov	x0, x20
    8f18:	d2800042 	mov	x2, #0x2                   	// #2
    8f1c:	97ffe99d 	bl	3590 <buf_put>
    8f20:	f9400661 	ldr	x1, [x19, #8]
    8f24:	aa1403e0 	mov	x0, x20
    8f28:	f9401f82 	ldr	x2, [x28, #56]
    8f2c:	52800003 	mov	w3, #0x0                   	// #0
    8f30:	97fffdbc 	bl	8620 <fwp_write>
    8f34:	f9400a73 	ldr	x19, [x19, #16]
    8f38:	b5fffed3 	cbnz	x19, 8f10 <fwp_write+0x8f0>
    8f3c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8f40:	aa1503e1 	mov	x1, x21
    8f44:	aa1403e0 	mov	x0, x20
    8f48:	d2800022 	mov	x2, #0x1                   	// #1
    8f4c:	39001fe3 	strb	w3, [sp, #7]
    8f50:	17fffddb 	b	86bc <fwp_write+0x9c>
    8f54:	aa1403e0 	mov	x0, x20
    8f58:	b0000021 	adrp	x1, d000 <__divti3+0x260>
    8f5c:	d28000c2 	mov	x2, #0x6                   	// #6
    8f60:	912b0021 	add	x1, x1, #0xac0
    8f64:	97ffe98b 	bl	3590 <buf_put>
    8f68:	f9400260 	ldr	x0, [x19]
    8f6c:	b40004c0 	cbz	x0, 9004 <fwp_write+0x9e4>
    8f70:	910123f5 	add	x21, sp, #0x48
    8f74:	91002276 	add	x22, x19, #0x8
    8f78:	f90143f7 	str	x23, [sp, #640]
    8f7c:	d2800017 	mov	x23, #0x0                   	// #0
    8f80:	f90147f8 	str	x24, [sp, #648]
    8f84:	b0000038 	adrp	x24, d000 <__divti3+0x260>
    8f88:	912b2318 	add	x24, x24, #0xac8
    8f8c:	f9014bf9 	str	x25, [sp, #656]
    8f90:	b0000039 	adrp	x25, d000 <__divti3+0x260>
    8f94:	912b4339 	add	x25, x25, #0xad0
    8f98:	f9014ffa 	str	x26, [sp, #664]
    8f9c:	14000005 	b	8fb0 <fwp_write+0x990>
    8fa0:	aa1903e1 	mov	x1, x25
    8fa4:	aa1403e0 	mov	x0, x20
    8fa8:	d2800042 	mov	x2, #0x2                   	// #2
    8fac:	97ffe979 	bl	3590 <buf_put>
    8fb0:	38776ac5 	ldrb	w5, [x22, x23]
    8fb4:	d2804003 	mov	x3, #0x200                 	// #512
    8fb8:	aa1803e4 	mov	x4, x24
    8fbc:	aa0303e1 	mov	x1, x3
    8fc0:	52800042 	mov	w2, #0x2                   	// #2
    8fc4:	aa1503e0 	mov	x0, x21
    8fc8:	910006f7 	add	x23, x23, #0x1
    8fcc:	97ffe609 	bl	27f0 <__snprintf_chk@plt>
    8fd0:	aa1503e0 	mov	x0, x21
    8fd4:	97ffe5cf 	bl	2710 <strlen@plt>
    8fd8:	aa1503e1 	mov	x1, x21
    8fdc:	aa0003e2 	mov	x2, x0
    8fe0:	aa1403e0 	mov	x0, x20
    8fe4:	97ffe96b 	bl	3590 <buf_put>
    8fe8:	f9400260 	ldr	x0, [x19]
    8fec:	eb17001f 	cmp	x0, x23
    8ff0:	54fffd88 	b.hi	8fa0 <fwp_write+0x980>  // b.pmore
    8ff4:	f94143f7 	ldr	x23, [sp, #640]
    8ff8:	f94147f8 	ldr	x24, [sp, #648]
    8ffc:	f9414bf9 	ldr	x25, [sp, #656]
    9000:	f9414ffa 	ldr	x26, [sp, #664]
    9004:	52800ba3 	mov	w3, #0x5d                  	// #93
    9008:	aa1403e0 	mov	x0, x20
    900c:	91001fe1 	add	x1, sp, #0x7
    9010:	d2800022 	mov	x2, #0x1                   	// #1
    9014:	39001fe3 	strb	w3, [sp, #7]
    9018:	17fffda9 	b	86bc <fwp_write+0x9c>
    901c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9020:	17fffe44 	b	8930 <fwp_write+0x310>
    9024:	f10002ff 	cmp	x23, #0x0
    9028:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    902c:	71002c3f 	cmp	w1, #0xb
    9030:	54ffebc0 	b.eq	8da8 <fwp_write+0x788>  // b.none
    9034:	aa1303e2 	mov	x2, x19
    9038:	aa1703e1 	mov	x1, x23
    903c:	aa1403e0 	mov	x0, x20
    9040:	52800003 	mov	w3, #0x0                   	// #0
    9044:	97fffd77 	bl	8620 <fwp_write>
    9048:	17ffff6a 	b	8df0 <fwp_write+0x7d0>
    904c:	aa1403e0 	mov	x0, x20
    9050:	91001fe1 	add	x1, sp, #0x7
    9054:	52800fa3 	mov	w3, #0x7d                  	// #125
    9058:	d2800022 	mov	x2, #0x1                   	// #1
    905c:	17fffe38 	b	893c <fwp_write+0x31c>
    9060:	a9400281 	ldp	x1, x0, [x20]
    9064:	91000800 	add	x0, x0, #0x2
    9068:	8b160000 	add	x0, x0, x22
    906c:	f9000680 	str	x0, [x20, #8]
    9070:	3820683f 	strb	wzr, [x1, x0]
    9074:	f9413bf5 	ldr	x21, [sp, #624]
    9078:	f9413ff6 	ldr	x22, [sp, #632]
    907c:	f94153fb 	ldr	x27, [sp, #672]
    9080:	f94157fc 	ldr	x28, [sp, #680]
    9084:	17fffd93 	b	86d0 <fwp_write+0xb0>
    9088:	f9400f80 	ldr	x0, [x28, #24]
    908c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9090:	aa1b03e0 	mov	x0, x27
    9094:	97ffe59f 	bl	2710 <strlen@plt>
    9098:	aa1b03e1 	mov	x1, x27
    909c:	aa0003e2 	mov	x2, x0
    90a0:	aa1403e0 	mov	x0, x20
    90a4:	97ffe93b 	bl	3590 <buf_put>
    90a8:	aa1903e1 	mov	x1, x25
    90ac:	aa1403e0 	mov	x0, x20
    90b0:	d2800062 	mov	x2, #0x3                   	// #3
    90b4:	97ffe937 	bl	3590 <buf_put>
    90b8:	17fffe10 	b	88f8 <fwp_write+0x2d8>
    90bc:	aa1a03e1 	mov	x1, x26
    90c0:	aa1403e0 	mov	x0, x20
    90c4:	d2800042 	mov	x2, #0x2                   	// #2
    90c8:	97ffe932 	bl	3590 <buf_put>
    90cc:	17fffe09 	b	88f0 <fwp_write+0x2d0>
    90d0:	f9400660 	ldr	x0, [x19, #8]
    90d4:	b4fffb00 	cbz	x0, 9034 <fwp_write+0xa14>
    90d8:	90000021 	adrp	x1, d000 <__divti3+0x260>
    90dc:	912ba021 	add	x1, x1, #0xae8
    90e0:	97ffe608 	bl	2900 <strcmp@plt>
    90e4:	7100001f 	cmp	w0, #0x0
    90e8:	1a9f07e0 	cset	w0, ne	// ne = any
    90ec:	17ffff2f 	b	8da8 <fwp_write+0x788>
    90f0:	aa1403e0 	mov	x0, x20
    90f4:	d2800042 	mov	x2, #0x2                   	// #2
    90f8:	90000021 	adrp	x1, d000 <__divti3+0x260>
    90fc:	912b8021 	add	x1, x1, #0xae0
    9100:	97ffe924 	bl	3590 <buf_put>
    9104:	91004261 	add	x1, x19, #0x10
    9108:	aa1403e0 	mov	x0, x20
    910c:	f9402382 	ldr	x2, [x28, #64]
    9110:	52800003 	mov	w3, #0x0                   	// #0
    9114:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9118:	97fffd42 	bl	8620 <fwp_write>
    911c:	17fffd9c 	b	878c <fwp_write+0x16c>
    9120:	1e22c109 	fcvt	d9, s8
    9124:	910123f5 	add	x21, sp, #0x48
    9128:	52800033 	mov	w19, #0x1                   	// #1
    912c:	d503201f 	nop
    9130:	1e604120 	fmov	d0, d9
    9134:	2a1303e1 	mov	w1, w19
    9138:	aa1503e0 	mov	x0, x21
    913c:	97ffea96 	bl	3b94 <fwp_format_g.constprop.0>
    9140:	aa1503e0 	mov	x0, x21
    9144:	d2800001 	mov	x1, #0x0                   	// #0
    9148:	97ffe5fa 	bl	2930 <strtof@plt>
    914c:	1e202100 	fcmp	s8, s0
    9150:	54ffdb60 	b.eq	8cbc <fwp_write+0x69c>  // b.none
    9154:	11000673 	add	w19, w19, #0x1
    9158:	71002a7f 	cmp	w19, #0xa
    915c:	54fffea1 	b.ne	9130 <fwp_write+0xb10>  // b.any
    9160:	1e604120 	fmov	d0, d9
    9164:	aa1503e0 	mov	x0, x21
    9168:	52800121 	mov	w1, #0x9                   	// #9
    916c:	97ffea8a 	bl	3b94 <fwp_format_g.constprop.0>
    9170:	17fffed3 	b	8cbc <fwp_write+0x69c>
    9174:	d37ef6a1 	lsl	x1, x21, #2
    9178:	b7f81563 	tbnz	x3, #63, 9424 <fwp_write+0xe04>
    917c:	91002263 	add	x3, x19, #0x8
    9180:	8b010061 	add	x1, x3, x1
    9184:	b9400023 	ldr	w3, [x1]
    9188:	7100081f 	cmp	w0, #0x2
    918c:	2a0303e1 	mov	w1, w3
    9190:	93407c63 	sxtw	x3, w3
    9194:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9198:	17fffe5a 	b	8b00 <fwp_write+0x4e0>
    919c:	d37ffaa1 	lsl	x1, x21, #1
    91a0:	b7f81363 	tbnz	x3, #63, 940c <fwp_write+0xdec>
    91a4:	91002263 	add	x3, x19, #0x8
    91a8:	8b010061 	add	x1, x3, x1
    91ac:	79400021 	ldrh	w1, [x1]
    91b0:	7100041f 	cmp	w0, #0x1
    91b4:	93403c23 	sxth	x3, w1
    91b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    91bc:	17fffe51 	b	8b00 <fwp_write+0x4e0>
    91c0:	52800443 	mov	w3, #0x22                  	// #34
    91c4:	91001ff5 	add	x21, sp, #0x7
    91c8:	91002273 	add	x19, x19, #0x8
    91cc:	aa1503e1 	mov	x1, x21
    91d0:	aa1403e0 	mov	x0, x20
    91d4:	d2800022 	mov	x2, #0x1                   	// #1
    91d8:	39001fe3 	strb	w3, [sp, #7]
    91dc:	f90143f7 	str	x23, [sp, #640]
    91e0:	8b160277 	add	x23, x19, x22
    91e4:	f90147f8 	str	x24, [sp, #648]
    91e8:	97ffe8ea 	bl	3590 <buf_put>
    91ec:	b4000696 	cbz	x22, 92bc <fwp_write+0xc9c>
    91f0:	90000038 	adrp	x24, d000 <__divti3+0x260>
    91f4:	912a4318 	add	x24, x24, #0xa90
    91f8:	f9014bf9 	str	x25, [sp, #656]
    91fc:	90000039 	adrp	x25, d000 <__divti3+0x260>
    9200:	912ac339 	add	x25, x25, #0xab0
    9204:	f9014ffa 	str	x26, [sp, #664]
    9208:	1400000d 	b	923c <fwp_write+0xc1c>
    920c:	710024bf 	cmp	w5, #0x9
    9210:	54000460 	b.eq	929c <fwp_write+0xc7c>  // b.none
    9214:	710028bf 	cmp	w5, #0xa
    9218:	54000a61 	b.ne	9364 <fwp_write+0xd44>  // b.any
    921c:	90000021 	adrp	x1, d000 <__divti3+0x260>
    9220:	aa1403e0 	mov	x0, x20
    9224:	912a8021 	add	x1, x1, #0xaa0
    9228:	d2800042 	mov	x2, #0x2                   	// #2
    922c:	97ffe8d9 	bl	3590 <buf_put>
    9230:	91000673 	add	x19, x19, #0x1
    9234:	eb17027f 	cmp	x19, x23
    9238:	540003e0 	b.eq	92b4 <fwp_write+0xc94>  // b.none
    923c:	39400265 	ldrb	w5, [x19]
    9240:	710034bf 	cmp	w5, #0xd
    9244:	54000180 	b.eq	9274 <fwp_write+0xc54>  // b.none
    9248:	54fffe29 	b.ls	920c <fwp_write+0xbec>  // b.plast
    924c:	710088bf 	cmp	w5, #0x22
    9250:	540001c0 	b.eq	9288 <fwp_write+0xc68>  // b.none
    9254:	710170bf 	cmp	w5, #0x5c
    9258:	54000741 	b.ne	9340 <fwp_write+0xd20>  // b.any
    925c:	aa1403e0 	mov	x0, x20
    9260:	90000021 	adrp	x1, d000 <__divti3+0x260>
    9264:	d2800042 	mov	x2, #0x2                   	// #2
    9268:	912a6021 	add	x1, x1, #0xa98
    926c:	97ffe8c9 	bl	3590 <buf_put>
    9270:	17fffff0 	b	9230 <fwp_write+0xc10>
    9274:	aa1903e1 	mov	x1, x25
    9278:	aa1403e0 	mov	x0, x20
    927c:	d2800042 	mov	x2, #0x2                   	// #2
    9280:	97ffe8c4 	bl	3590 <buf_put>
    9284:	17ffffeb 	b	9230 <fwp_write+0xc10>
    9288:	aa1803e1 	mov	x1, x24
    928c:	aa1403e0 	mov	x0, x20
    9290:	d2800042 	mov	x2, #0x2                   	// #2
    9294:	97ffe8bf 	bl	3590 <buf_put>
    9298:	17ffffe6 	b	9230 <fwp_write+0xc10>
    929c:	aa1403e0 	mov	x0, x20
    92a0:	90000021 	adrp	x1, d000 <__divti3+0x260>
    92a4:	d2800042 	mov	x2, #0x2                   	// #2
    92a8:	912aa021 	add	x1, x1, #0xaa8
    92ac:	97ffe8b9 	bl	3590 <buf_put>
    92b0:	17ffffe0 	b	9230 <fwp_write+0xc10>
    92b4:	f9414bf9 	ldr	x25, [sp, #656]
    92b8:	f9414ffa 	ldr	x26, [sp, #664]
    92bc:	aa1503e1 	mov	x1, x21
    92c0:	aa1403e0 	mov	x0, x20
    92c4:	52800443 	mov	w3, #0x22                  	// #34
    92c8:	17fffd9c 	b	8938 <fwp_write+0x318>
    92cc:	7100103f 	cmp	w1, #0x4
    92d0:	54ffeb21 	b.ne	9034 <fwp_write+0xa14>  // b.any
    92d4:	f94006e0 	ldr	x0, [x23, #8]
    92d8:	d37ffc00 	lsr	x0, x0, #63
    92dc:	17fffeb3 	b	8da8 <fwp_write+0x788>
    92e0:	710002ff 	cmp	w23, #0x0
    92e4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    92e8:	17fffeb0 	b	8da8 <fwp_write+0x788>
    92ec:	528005a1 	mov	w1, #0x2d                  	// #45
    92f0:	eb0203e2 	negs	x2, x2
    92f4:	da0303e3 	ngc	x3, x3
    92f8:	910127e0 	add	x0, sp, #0x49
    92fc:	910123f5 	add	x21, sp, #0x48
    9300:	390123e1 	strb	w1, [sp, #72]
    9304:	97ffe6c7 	bl	2e20 <fwp_fmt_u128>
    9308:	17fffe18 	b	8b68 <fwp_write+0x548>
    930c:	d37ceea1 	lsl	x1, x21, #4
    9310:	b7f810a3 	tbnz	x3, #63, 9524 <fwp_write+0xf04>
    9314:	91002260 	add	x0, x19, #0x8
    9318:	8b010001 	add	x1, x0, x1
    931c:	17fffdf9 	b	8b00 <fwp_write+0x4e0>
    9320:	f9400a61 	ldr	x1, [x19, #16]
    9324:	8b010000 	add	x0, x0, x1
    9328:	f9400001 	ldr	x1, [x0]
    932c:	17fffdf5 	b	8b00 <fwp_write+0x4e0>
    9330:	90000021 	adrp	x1, d000 <__divti3+0x260>
    9334:	d2800042 	mov	x2, #0x2                   	// #2
    9338:	9128e021 	add	x1, x1, #0xa38
    933c:	17fffed6 	b	8e94 <fwp_write+0x874>
    9340:	7101fcbf 	cmp	w5, #0x7f
    9344:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9348:	540000e9 	b.ls	9364 <fwp_write+0xd44>  // b.plast
    934c:	aa1503e1 	mov	x1, x21
    9350:	aa1403e0 	mov	x0, x20
    9354:	d2800022 	mov	x2, #0x1                   	// #1
    9358:	39001fe5 	strb	w5, [sp, #7]
    935c:	97ffe88d 	bl	3590 <buf_put>
    9360:	17ffffb4 	b	9230 <fwp_write+0xc10>
    9364:	d2800203 	mov	x3, #0x10                  	// #16
    9368:	90000024 	adrp	x4, d000 <__divti3+0x260>
    936c:	aa0303e1 	mov	x1, x3
    9370:	912ae084 	add	x4, x4, #0xab8
    9374:	910123f6 	add	x22, sp, #0x48
    9378:	52800042 	mov	w2, #0x2                   	// #2
    937c:	aa1603e0 	mov	x0, x22
    9380:	97ffe51c 	bl	27f0 <__snprintf_chk@plt>
    9384:	aa1603e0 	mov	x0, x22
    9388:	97ffe4e2 	bl	2710 <strlen@plt>
    938c:	aa1603e1 	mov	x1, x22
    9390:	aa0003e2 	mov	x2, x0
    9394:	aa1403e0 	mov	x0, x20
    9398:	97ffe87e 	bl	3590 <buf_put>
    939c:	17ffffa5 	b	9230 <fwp_write+0xc10>
    93a0:	1e604100 	fmov	d0, d8
    93a4:	aa1503e0 	mov	x0, x21
    93a8:	52800221 	mov	w1, #0x11                  	// #17
    93ac:	97ffe9fa 	bl	3b94 <fwp_format_g.constprop.0>
    93b0:	17fffe43 	b	8cbc <fwp_write+0x69c>
    93b4:	b9401040 	ldr	w0, [x2, #16]
    93b8:	350003c0 	cbnz	w0, 9430 <fwp_write+0xe10>
    93bc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    93c0:	f947f400 	ldr	x0, [x0, #4072]
    93c4:	f94127e2 	ldr	x2, [sp, #584]
    93c8:	f9400001 	ldr	x1, [x0]
    93cc:	eb010042 	subs	x2, x2, x1
    93d0:	d2800001 	mov	x1, #0x0                   	// #0
    93d4:	54ffd721 	b.ne	8eb8 <fwp_write+0x898>  // b.any
    93d8:	f9413bf5 	ldr	x21, [sp, #624]
    93dc:	90000021 	adrp	x1, d000 <__divti3+0x260>
    93e0:	f9413ff6 	ldr	x22, [sp, #632]
    93e4:	aa1403e0 	mov	x0, x20
    93e8:	f94143f7 	ldr	x23, [sp, #640]
    93ec:	912c2021 	add	x1, x1, #0xb08
    93f0:	f94147f8 	ldr	x24, [sp, #648]
    93f4:	d2800042 	mov	x2, #0x2                   	// #2
    93f8:	17fffd0e 	b	8830 <fwp_write+0x210>
    93fc:	90000021 	adrp	x1, d000 <__divti3+0x260>
    9400:	d2800042 	mov	x2, #0x2                   	// #2
    9404:	91290021 	add	x1, x1, #0xa40
    9408:	17fffea3 	b	8e94 <fwp_write+0x874>
    940c:	f9400a63 	ldr	x3, [x19, #16]
    9410:	8b030021 	add	x1, x1, x3
    9414:	17ffff66 	b	91ac <fwp_write+0xb8c>
    9418:	f9400a61 	ldr	x1, [x19, #16]
    941c:	8b0102a1 	add	x1, x21, x1
    9420:	17fffdb3 	b	8aec <fwp_write+0x4cc>
    9424:	f9400a63 	ldr	x3, [x19, #16]
    9428:	8b030021 	add	x1, x1, x3
    942c:	17ffff56 	b	9184 <fwp_write+0xb64>
    9430:	b9404840 	ldr	w0, [x2, #72]
    9434:	91001ff5 	add	x21, sp, #0x7
    9438:	34ffa360 	cbz	w0, 88a4 <fwp_write+0x284>
    943c:	52800503 	mov	w3, #0x28                  	// #40
    9440:	aa1403e0 	mov	x0, x20
    9444:	aa1503e1 	mov	x1, x21
    9448:	d2800022 	mov	x2, #0x1                   	// #1
    944c:	39001fe3 	strb	w3, [sp, #7]
    9450:	97ffe850 	bl	3590 <buf_put>
    9454:	b9401380 	ldr	w0, [x28, #16]
    9458:	52800038 	mov	w24, #0x1                   	// #1
    945c:	7100001f 	cmp	w0, #0x0
    9460:	54ffa36c 	b.gt	88cc <fwp_write+0x2ac>
    9464:	17fffd32 	b	892c <fwp_write+0x30c>
    9468:	f9014bf9 	str	x25, [sp, #656]
    946c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe838>
    9470:	f9014ffa 	str	x26, [sp, #664]
    9474:	f9400676 	ldr	x22, [x19, #8]
    9478:	91102333 	add	x19, x25, #0x408
    947c:	91002273 	add	x19, x19, #0x8
    9480:	937ffed8 	asr	x24, x22, #63
    9484:	aa1802c0 	orr	x0, x22, x24
    9488:	b5000320 	cbnz	x0, 94ec <fwp_write+0xecc>
    948c:	110006b5 	add	w21, w21, #0x1
    9490:	710016bf 	cmp	w21, #0x5
    9494:	54ffffc1 	b.ne	948c <fwp_write+0xe6c>  // b.any
    9498:	b7f80578 	tbnz	x24, #63, 9544 <fwp_write+0xf24>
    949c:	910023f3 	add	x19, sp, #0x8
    94a0:	aa1603e2 	mov	x2, x22
    94a4:	aa1303e0 	mov	x0, x19
    94a8:	d2800003 	mov	x3, #0x0                   	// #0
    94ac:	97ffe65d 	bl	2e20 <fwp_fmt_u128>
    94b0:	910123f5 	add	x21, sp, #0x48
    94b4:	90000023 	adrp	x3, d000 <__divti3+0x260>
    94b8:	aa1303e4 	mov	x4, x19
    94bc:	aa1503e0 	mov	x0, x21
    94c0:	912c0063 	add	x3, x3, #0xb00
    94c4:	d2804002 	mov	x2, #0x200                 	// #512
    94c8:	52800041 	mov	w1, #0x2                   	// #2
    94cc:	97ffe495 	bl	2720 <__sprintf_chk@plt>
    94d0:	aa1503e0 	mov	x0, x21
    94d4:	97ffe48f 	bl	2710 <strlen@plt>
    94d8:	aa1503e1 	mov	x1, x21
    94dc:	aa0003e2 	mov	x2, x0
    94e0:	aa1403e0 	mov	x0, x20
    94e4:	97ffe82b 	bl	3590 <buf_put>
    94e8:	17fffe47 	b	8e04 <fwp_write+0x7e4>
    94ec:	f9400277 	ldr	x23, [x19]
    94f0:	aa1603e0 	mov	x0, x22
    94f4:	aa1803e1 	mov	x1, x24
    94f8:	aa1703e2 	mov	x2, x23
    94fc:	937ffefa 	asr	x26, x23, #63
    9500:	aa1a03e3 	mov	x3, x26
    9504:	94000f07 	bl	d120 <__modti3>
    9508:	aa010000 	orr	x0, x0, x1
    950c:	b40002c0 	cbz	x0, 9564 <fwp_write+0xf44>
    9510:	110006b5 	add	w21, w21, #0x1
    9514:	91004273 	add	x19, x19, #0x10
    9518:	710016bf 	cmp	w21, #0x5
    951c:	54fffe81 	b.ne	94ec <fwp_write+0xecc>  // b.any
    9520:	17ffffde 	b	9498 <fwp_write+0xe78>
    9524:	f9400a60 	ldr	x0, [x19, #16]
    9528:	8b000021 	add	x1, x1, x0
    952c:	17fffd75 	b	8b00 <fwp_write+0x4e0>
    9530:	528c29c0 	mov	w0, #0x614e                	// #24910
    9534:	910123f5 	add	x21, sp, #0x48
    9538:	72a009c0 	movk	w0, #0x4e, lsl #16
    953c:	b9004be0 	str	w0, [sp, #72]
    9540:	17fffda2 	b	8bc8 <fwp_write+0x5a8>
    9544:	528005a1 	mov	w1, #0x2d                  	// #45
    9548:	eb1603e2 	negs	x2, x22
    954c:	da1803e3 	ngc	x3, x24
    9550:	910027e0 	add	x0, sp, #0x9
    9554:	910023f3 	add	x19, sp, #0x8
    9558:	390023e1 	strb	w1, [sp, #8]
    955c:	97ffe631 	bl	2e20 <fwp_fmt_u128>
    9560:	17ffffd4 	b	94b0 <fwp_write+0xe90>
    9564:	aa1703e2 	mov	x2, x23
    9568:	aa1a03e3 	mov	x3, x26
    956c:	aa1603e0 	mov	x0, x22
    9570:	aa1803e1 	mov	x1, x24
    9574:	94000e0b 	bl	cda0 <__divti3>
    9578:	aa0003e2 	mov	x2, x0
    957c:	aa0103e3 	mov	x3, x1
    9580:	b7f80201 	tbnz	x1, #63, 95c0 <fwp_write+0xfa0>
    9584:	910023f3 	add	x19, sp, #0x8
    9588:	aa1303e0 	mov	x0, x19
    958c:	97ffe625 	bl	2e20 <fwp_fmt_u128>
    9590:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9594:	91102339 	add	x25, x25, #0x408
    9598:	910123f5 	add	x21, sp, #0x48
    959c:	aa1303e4 	mov	x4, x19
    95a0:	aa1503e0 	mov	x0, x21
    95a4:	90000023 	adrp	x3, d000 <__divti3+0x260>
    95a8:	f8616b25 	ldr	x5, [x25, x1]
    95ac:	912be063 	add	x3, x3, #0xaf8
    95b0:	d2804002 	mov	x2, #0x200                 	// #512
    95b4:	52800041 	mov	w1, #0x2                   	// #2
    95b8:	97ffe45a 	bl	2720 <__sprintf_chk@plt>
    95bc:	17ffffc5 	b	94d0 <fwp_write+0xeb0>
    95c0:	528005a4 	mov	w4, #0x2d                  	// #45
    95c4:	eb0003e2 	negs	x2, x0
    95c8:	da0103e3 	ngc	x3, x1
    95cc:	910027e0 	add	x0, sp, #0x9
    95d0:	910023f3 	add	x19, sp, #0x8
    95d4:	390023e4 	strb	w4, [sp, #8]
    95d8:	97ffe612 	bl	2e20 <fwp_fmt_u128>
    95dc:	17ffffed 	b	9590 <fwp_write+0xf70>
    95e0:	f9013bf5 	str	x21, [sp, #624]
    95e4:	f9013ff6 	str	x22, [sp, #632]
    95e8:	f90143f7 	str	x23, [sp, #640]
    95ec:	f90147f8 	str	x24, [sp, #648]
    95f0:	f9014bf9 	str	x25, [sp, #656]
    95f4:	f9014ffa 	str	x26, [sp, #664]
    95f8:	f90153fb 	str	x27, [sp, #672]
    95fc:	f90157fc 	str	x28, [sp, #680]
    9600:	fd015be8 	str	d8, [sp, #688]
    9604:	fd015fe9 	str	d9, [sp, #696]
    9608:	97ffe49e 	bl	2880 <__stack_chk_fail@plt>
    960c:	d503201f 	nop

0000000000009610 <fwp_hof0.constprop.0>:
    9610:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9614:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9618:	f947f442 	ldr	x2, [x2, #4072]
    961c:	910003fd 	mov	x29, sp
    9620:	a90153f3 	stp	x19, x20, [sp, #16]
    9624:	a9025bf5 	stp	x21, x22, [sp, #32]
    9628:	a90363f7 	stp	x23, x24, [sp, #48]
    962c:	aa0003f7 	mov	x23, x0
    9630:	a9046bf9 	stp	x25, x26, [sp, #64]
    9634:	a90573fb 	stp	x27, x28, [sp, #80]
    9638:	d10243ff 	sub	sp, sp, #0x90
    963c:	f9400040 	ldr	x0, [x2]
    9640:	f81f83a0 	stur	x0, [x29, #-8]
    9644:	d2800000 	mov	x0, #0x0                   	// #0
    9648:	b4002da1 	cbz	x1, 9bfc <fwp_hof0.constprop.0+0x5ec>
    964c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9650:	9100401c 	add	x28, x0, #0x10
    9654:	9101039c 	add	x28, x28, #0x40
    9658:	f00000a0 	adrp	x0, 20000 <__data_start>
    965c:	aa0103fa 	mov	x26, x1
    9660:	d10083b4 	sub	x20, x29, #0x20
    9664:	9101c015 	add	x21, x0, #0x70
    9668:	aa1c03f8 	mov	x24, x28
    966c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9670:	9117c002 	add	x2, x0, #0x5f0
    9674:	f949d841 	ldr	x1, [x2, #5040]
    9678:	f949ec40 	ldr	x0, [x2, #5080]
    967c:	cb0102e1 	sub	x1, x23, x1
    9680:	eb00403f 	cmp	x1, x0, lsl #16
    9684:	54000342 	b.cs	96ec <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9688:	d350fc20 	lsr	x0, x1, #16
    968c:	f949fc44 	ldr	x4, [x2, #5112]
    9690:	8b000800 	add	x0, x0, x0, lsl #2
    9694:	d37df002 	lsl	x2, x0, #3
    9698:	8b020083 	add	x3, x4, x2
    969c:	f9401060 	ldr	x0, [x3, #32]
    96a0:	b4000260 	cbz	x0, 96ec <fwp_hof0.constprop.0+0xdc>
    96a4:	38626882 	ldrb	w2, [x4, x2]
    96a8:	7100085f 	cmp	w2, #0x2
    96ac:	54005240 	b.eq	a0f4 <fwp_hof0.constprop.0+0xae4>  // b.none
    96b0:	7100045f 	cmp	w2, #0x1
    96b4:	540001c1 	b.ne	96ec <fwp_hof0.constprop.0+0xdc>  // b.any
    96b8:	29430864 	ldp	w4, w2, [x3, #24]
    96bc:	92403c21 	and	x1, x1, #0xffff
    96c0:	9b047c21 	mul	x1, x1, x4
    96c4:	d360fc21 	lsr	x1, x1, #32
    96c8:	eb02003f 	cmp	x1, x2
    96cc:	54000102 	b.cs	96ec <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    96d0:	8b010000 	add	x0, x0, x1
    96d4:	39400001 	ldrb	w1, [x0]
    96d8:	340000a1 	cbz	w1, 96ec <fwp_hof0.constprop.0+0xdc>
    96dc:	7103f43f 	cmp	w1, #0xfd
    96e0:	54005728 	b.hi	a1c4 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    96e4:	11000421 	add	w1, w1, #0x1
    96e8:	39000001 	strb	w1, [x0]
    96ec:	aa1703f9 	mov	x25, x23
    96f0:	a938dfba 	stp	x26, x23, [x29, #-120]
    96f4:	aa1803fa 	mov	x26, x24
    96f8:	d28018f3 	mov	x19, #0xc7                  	// #199
    96fc:	f81983b3 	stur	x19, [x29, #-104]
    9700:	f00000a0 	adrp	x0, 20000 <__data_start>
    9704:	91004000 	add	x0, x0, #0x10
    9708:	f94046a3 	ldr	x3, [x21, #136]
    970c:	91010005 	add	x5, x0, #0x40
    9710:	b9404002 	ldr	w2, [x0, #64]
    9714:	d37be842 	lsl	x2, x2, #5
    9718:	8b02007b 	add	x27, x3, x2
    971c:	f9400f61 	ldr	x1, [x27, #24]
    9720:	f81e03b9 	stur	x25, [x29, #-32]
    9724:	b4004ee1 	cbz	x1, a100 <fwp_hof0.constprop.0+0xaf0>
    9728:	f9400c20 	ldr	x0, [x1, #24]
    972c:	b40042a0 	cbz	x0, 9f80 <fwp_hof0.constprop.0+0x970>
    9730:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9734:	9117c002 	add	x2, x0, #0x5f0
    9738:	f949d841 	ldr	x1, [x2, #5040]
    973c:	f949ec40 	ldr	x0, [x2, #5080]
    9740:	cb010341 	sub	x1, x26, x1
    9744:	eb00403f 	cmp	x1, x0, lsl #16
    9748:	54000342 	b.cs	97b0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    974c:	d350fc20 	lsr	x0, x1, #16
    9750:	f949fc45 	ldr	x5, [x2, #5112]
    9754:	8b000800 	add	x0, x0, x0, lsl #2
    9758:	d37df002 	lsl	x2, x0, #3
    975c:	8b0200a3 	add	x3, x5, x2
    9760:	f9401060 	ldr	x0, [x3, #32]
    9764:	b4000260 	cbz	x0, 97b0 <fwp_hof0.constprop.0+0x1a0>
    9768:	386268a2 	ldrb	w2, [x5, x2]
    976c:	7100085f 	cmp	w2, #0x2
    9770:	54004700 	b.eq	a050 <fwp_hof0.constprop.0+0xa40>  // b.none
    9774:	7100045f 	cmp	w2, #0x1
    9778:	540001c1 	b.ne	97b0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    977c:	29430865 	ldp	w5, w2, [x3, #24]
    9780:	92403c21 	and	x1, x1, #0xffff
    9784:	9b057c21 	mul	x1, x1, x5
    9788:	d360fc21 	lsr	x1, x1, #32
    978c:	eb02003f 	cmp	x1, x2
    9790:	54000102 	b.cs	97b0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9794:	8b010000 	add	x0, x0, x1
    9798:	39400001 	ldrb	w1, [x0]
    979c:	340000a1 	cbz	w1, 97b0 <fwp_hof0.constprop.0+0x1a0>
    97a0:	7103f43f 	cmp	w1, #0xfd
    97a4:	54004988 	b.hi	a0d4 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    97a8:	11000421 	add	w1, w1, #0x1
    97ac:	39000001 	strb	w1, [x0]
    97b0:	aa1a03f9 	mov	x25, x26
    97b4:	aa1a03e0 	mov	x0, x26
    97b8:	aa1b03e3 	mov	x3, x27
    97bc:	52800037 	mov	w23, #0x1                   	// #1
    97c0:	90000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    97c4:	9117c036 	add	x22, x1, #0x5f0
    97c8:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    97cc:	f81b03b6 	stur	x22, [x29, #-80]
    97d0:	b81cc3b7 	stur	w23, [x29, #-52]
    97d4:	f81d03b4 	stur	x20, [x29, #-48]
    97d8:	b9400401 	ldr	w1, [x0, #4]
    97dc:	b9400078 	ldr	w24, [x3]
    97e0:	b85cc3a0 	ldur	w0, [x29, #-52]
    97e4:	4b010318 	sub	w24, w24, w1
    97e8:	6b17031f 	cmp	w24, w23
    97ec:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    97f0:	6b0000ff 	cmp	w7, w0
    97f4:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    97f8:	b81c83a0 	stur	w0, [x29, #-56]
    97fc:	6b0000e2 	subs	w2, w7, w0
    9800:	54000120 	b.eq	9824 <fwp_hof0.constprop.0+0x214>  // b.none
    9804:	f9400c63 	ldr	x3, [x3, #24]
    9808:	0b000021 	add	w1, w1, w0
    980c:	f85d03a4 	ldur	x4, [x29, #-48]
    9810:	b81d83a7 	stur	w7, [x29, #-40]
    9814:	f9400863 	ldr	x3, [x3, #16]
    9818:	8b204c80 	add	x0, x4, w0, uxtw #3
    981c:	d63f0060 	blr	x3
    9820:	b85d83a7 	ldur	w7, [x29, #-40]
    9824:	f94046a0 	ldr	x0, [x21, #136]
    9828:	aa1903e6 	mov	x6, x25
    982c:	b9400323 	ldr	w3, [x25]
    9830:	2a0703f4 	mov	w20, w7
    9834:	f85d03bb 	ldur	x27, [x29, #-48]
    9838:	aa1903fc 	mov	x28, x25
    983c:	8b03141a 	add	x26, x0, x3, lsl #5
    9840:	f9400f40 	ldr	x0, [x26, #24]
    9844:	b40020e0 	cbz	x0, 9c60 <fwp_hof0.constprop.0+0x650>
    9848:	f85b03bc 	ldur	x28, [x29, #-80]
    984c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9850:	aa1a03f7 	mov	x23, x26
    9854:	b81c03b8 	stur	w24, [x29, #-64]
    9858:	aa1b03f8 	mov	x24, x27
    985c:	14000012 	b	98a4 <fwp_hof0.constprop.0+0x294>
    9860:	f9400001 	ldr	x1, [x0]
    9864:	aa1803e0 	mov	x0, x24
    9868:	d63f0020 	blr	x1
    986c:	aa0003fb 	mov	x27, x0
    9870:	aa1903e0 	mov	x0, x25
    9874:	97fff1d7 	bl	5fd0 <fwp_closure_drop>
    9878:	6b13029f 	cmp	w20, w19
    987c:	54000ca0 	b.eq	9a10 <fwp_hof0.constprop.0+0x400>  // b.none
    9880:	f94046a0 	ldr	x0, [x21, #136]
    9884:	8b334f18 	add	x24, x24, w19, uxtw #3
    9888:	b9400363 	ldr	w3, [x27]
    988c:	4b1a02d4 	sub	w20, w22, w26
    9890:	aa1b03e6 	mov	x6, x27
    9894:	8b031417 	add	x23, x0, x3, lsl #5
    9898:	f9400ee0 	ldr	x0, [x23, #24]
    989c:	b4001da0 	cbz	x0, 9c50 <fwp_hof0.constprop.0+0x640>
    98a0:	aa1b03f9 	mov	x25, x27
    98a4:	b94004c1 	ldr	w1, [x6, #4]
    98a8:	b94002fa 	ldr	w26, [x23]
    98ac:	0b010296 	add	w22, w20, w1
    98b0:	6b16035f 	cmp	w26, w22
    98b4:	54002488 	b.hi	9d44 <fwp_hof0.constprop.0+0x734>  // b.pmore
    98b8:	7100003f 	cmp	w1, #0x0
    98bc:	4b010353 	sub	w19, w26, w1
    98c0:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    98c4:	54fffce1 	b.ne	9860 <fwp_hof0.constprop.0+0x250>  // b.any
    98c8:	7100035f 	cmp	w26, #0x0
    98cc:	910003e2 	mov	x2, sp
    98d0:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    98d4:	f81d83a2 	stur	x2, [x29, #-40]
    98d8:	d37df084 	lsl	x4, x4, #3
    98dc:	91003c84 	add	x4, x4, #0xf
    98e0:	92704c87 	and	x7, x4, #0xfffff0000
    98e4:	927c7c84 	and	x4, x4, #0xffffffff0
    98e8:	cb2763e7 	sub	x7, sp, x7
    98ec:	eb2763ff 	cmp	sp, x7
    98f0:	540000a0 	b.eq	9904 <fwp_hof0.constprop.0+0x2f4>  // b.none
    98f4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    98f8:	f90203ff 	str	xzr, [sp, #1024]
    98fc:	eb2763ff 	cmp	sp, x7
    9900:	54ffffa1 	b.ne	98f4 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9904:	92403c84 	and	x4, x4, #0xffff
    9908:	cb2463ff 	sub	sp, sp, x4
    990c:	f90003ff 	str	xzr, [sp]
    9910:	f110009f 	cmp	x4, #0x400
    9914:	54000043 	b.cc	991c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9918:	f90203ff 	str	xzr, [sp, #1024]
    991c:	910043fb 	add	x27, sp, #0x10
    9920:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9924:	910020c9 	add	x9, x6, #0x8
    9928:	d2800004 	mov	x4, #0x0                   	// #0
    992c:	340000c1 	cbz	w1, 9944 <fwp_hof0.constprop.0+0x334>
    9930:	f8646922 	ldr	x2, [x9, x4]
    9934:	f8246b62 	str	x2, [x27, x4]
    9938:	91002084 	add	x4, x4, #0x8
    993c:	eb04015f 	cmp	x10, x4
    9940:	54ffff81 	b.ne	9930 <fwp_hof0.constprop.0+0x320>  // b.any
    9944:	2a1303ea 	mov	w10, w19
    9948:	d2800004 	mov	x4, #0x0                   	// #0
    994c:	340000f3 	cbz	w19, 9968 <fwp_hof0.constprop.0+0x358>
    9950:	0b040022 	add	w2, w1, w4
    9954:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9958:	91000484 	add	x4, x4, #0x1
    995c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9960:	eb04015f 	cmp	x10, x4
    9964:	54ffff61 	b.ne	9950 <fwp_hof0.constprop.0+0x340>  // b.any
    9968:	f949db81 	ldr	x1, [x28, #5040]
    996c:	f949ef84 	ldr	x4, [x28, #5080]
    9970:	cb010321 	sub	x1, x25, x1
    9974:	eb04403f 	cmp	x1, x4, lsl #16
    9978:	540002e2 	b.cs	99d4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    997c:	d350fc24 	lsr	x4, x1, #16
    9980:	f949ff8a 	ldr	x10, [x28, #5112]
    9984:	8b040884 	add	x4, x4, x4, lsl #2
    9988:	d37df084 	lsl	x4, x4, #3
    998c:	8b040149 	add	x9, x10, x4
    9990:	f9401128 	ldr	x8, [x9, #32]
    9994:	b4000208 	cbz	x8, 99d4 <fwp_hof0.constprop.0+0x3c4>
    9998:	38646944 	ldrb	w4, [x10, x4]
    999c:	7100089f 	cmp	w4, #0x2
    99a0:	54001520 	b.eq	9c44 <fwp_hof0.constprop.0+0x634>  // b.none
    99a4:	7100049f 	cmp	w4, #0x1
    99a8:	54000161 	b.ne	99d4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    99ac:	2943112a 	ldp	w10, w4, [x9, #24]
    99b0:	92403c21 	and	x1, x1, #0xffff
    99b4:	9b0a7c21 	mul	x1, x1, x10
    99b8:	d360fc21 	lsr	x1, x1, #32
    99bc:	eb04003f 	cmp	x1, x4
    99c0:	540000a2 	b.cs	99d4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    99c4:	8b010108 	add	x8, x8, x1
    99c8:	39400101 	ldrb	w1, [x8]
    99cc:	7100043f 	cmp	w1, #0x1
    99d0:	54001360 	b.eq	9c3c <fwp_hof0.constprop.0+0x62c>  // b.none
    99d4:	f9400404 	ldr	x4, [x0, #8]
    99d8:	52800021 	mov	w1, #0x1                   	// #1
    99dc:	aa1903e0 	mov	x0, x25
    99e0:	d63f0080 	blr	x4
    99e4:	f9400ee1 	ldr	x1, [x23, #24]
    99e8:	aa1b03e0 	mov	x0, x27
    99ec:	f9400021 	ldr	x1, [x1]
    99f0:	d63f0020 	blr	x1
    99f4:	aa0003fb 	mov	x27, x0
    99f8:	f85d83a0 	ldur	x0, [x29, #-40]
    99fc:	9100001f 	mov	sp, x0
    9a00:	aa1903e0 	mov	x0, x25
    9a04:	97fff173 	bl	5fd0 <fwp_closure_drop>
    9a08:	6b13029f 	cmp	w20, w19
    9a0c:	54fff3a1 	b.ne	9880 <fwp_hof0.constprop.0+0x270>  // b.any
    9a10:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9a14:	aa1b03f9 	mov	x25, x27
    9a18:	b85c03b8 	ldur	w24, [x29, #-64]
    9a1c:	6b17031f 	cmp	w24, w23
    9a20:	540014c3 	b.cc	9cb8 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9a24:	f85983a0 	ldur	x0, [x29, #-104]
    9a28:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9a2c:	f1000400 	subs	x0, x0, #0x1
    9a30:	f81983a0 	stur	x0, [x29, #-104]
    9a34:	54ffe661 	b.ne	9700 <fwp_hof0.constprop.0+0xf0>  // b.any
    9a38:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe838>
    9a3c:	91102042 	add	x2, x2, #0x408
    9a40:	aa1903e1 	mov	x1, x25
    9a44:	aa1403e0 	mov	x0, x20
    9a48:	aa1a03f8 	mov	x24, x26
    9a4c:	aa1903fb 	mov	x27, x25
    9a50:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9a54:	91014042 	add	x2, x2, #0x50
    9a58:	52800023 	mov	w3, #0x1                   	// #1
    9a5c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9a60:	f81f03bf 	stur	xzr, [x29, #-16]
    9a64:	97fffaef 	bl	8620 <fwp_write>
    9a68:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9a6c:	90000020 	adrp	x0, d000 <__divti3+0x260>
    9a70:	913f6000 	add	x0, x0, #0xfd8
    9a74:	f10002df 	cmp	x22, #0x0
    9a78:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9a7c:	b1002b3f 	cmn	x25, #0xa
    9a80:	540039c8 	b.hi	a1b8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9a84:	91002720 	add	x0, x25, #0x9
    9a88:	52800021 	mov	w1, #0x1                   	// #1
    9a8c:	97ffed2d 	bl	4f40 <fwp_heap_alloc>
    9a90:	aa0003f3 	mov	x19, x0
    9a94:	aa1603e1 	mov	x1, x22
    9a98:	aa0003f6 	mov	x22, x0
    9a9c:	aa1903e2 	mov	x2, x25
    9aa0:	f80086d9 	str	x25, [x22], #8
    9aa4:	8b190279 	add	x25, x19, x25
    9aa8:	aa1603e0 	mov	x0, x22
    9aac:	97ffe309 	bl	26d0 <memcpy@plt>
    9ab0:	3900233f 	strb	wzr, [x25, #8]
    9ab4:	f85e03a0 	ldur	x0, [x29, #-32]
    9ab8:	97ffe3a2 	bl	2940 <free@plt>
    9abc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9ac0:	9117c002 	add	x2, x0, #0x5f0
    9ac4:	f949d841 	ldr	x1, [x2, #5040]
    9ac8:	f949ec40 	ldr	x0, [x2, #5080]
    9acc:	cb010261 	sub	x1, x19, x1
    9ad0:	eb00403f 	cmp	x1, x0, lsl #16
    9ad4:	54000322 	b.cs	9b38 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9ad8:	d350fc20 	lsr	x0, x1, #16
    9adc:	f949fc43 	ldr	x3, [x2, #5112]
    9ae0:	8b000800 	add	x0, x0, x0, lsl #2
    9ae4:	d37df002 	lsl	x2, x0, #3
    9ae8:	8b020060 	add	x0, x3, x2
    9aec:	f9401019 	ldr	x25, [x0, #32]
    9af0:	b4000259 	cbz	x25, 9b38 <fwp_hof0.constprop.0+0x528>
    9af4:	38626862 	ldrb	w2, [x3, x2]
    9af8:	7100085f 	cmp	w2, #0x2
    9afc:	54003220 	b.eq	a140 <fwp_hof0.constprop.0+0xb30>  // b.none
    9b00:	7100045f 	cmp	w2, #0x1
    9b04:	540001a1 	b.ne	9b38 <fwp_hof0.constprop.0+0x528>  // b.any
    9b08:	29430002 	ldp	w2, w0, [x0, #24]
    9b0c:	92403c21 	and	x1, x1, #0xffff
    9b10:	9b027c21 	mul	x1, x1, x2
    9b14:	d360fc21 	lsr	x1, x1, #32
    9b18:	eb00003f 	cmp	x1, x0
    9b1c:	540000e2 	b.cs	9b38 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9b20:	8b010339 	add	x25, x25, x1
    9b24:	39400320 	ldrb	w0, [x25]
    9b28:	7103fc1f 	cmp	w0, #0xff
    9b2c:	54003520 	b.eq	a1d0 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9b30:	52800020 	mov	w0, #0x1                   	// #1
    9b34:	39000320 	strb	w0, [x25]
    9b38:	aa1b03e0 	mov	x0, x27
    9b3c:	97fff0c9 	bl	5e60 <fwp_drop0>
    9b40:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b44:	9101c003 	add	x3, x0, #0x70
    9b48:	f9400262 	ldr	x2, [x19]
    9b4c:	aa1603e0 	mov	x0, x22
    9b50:	aa0303f6 	mov	x22, x3
    9b54:	d2800021 	mov	x1, #0x1                   	// #1
    9b58:	f9400463 	ldr	x3, [x3, #8]
    9b5c:	97ffe389 	bl	2980 <fwrite@plt>
    9b60:	f94006c1 	ldr	x1, [x22, #8]
    9b64:	52800140 	mov	w0, #0xa                   	// #10
    9b68:	97ffe30e 	bl	27a0 <fputc@plt>
    9b6c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9b70:	9117c002 	add	x2, x0, #0x5f0
    9b74:	f949d841 	ldr	x1, [x2, #5040]
    9b78:	f949ec40 	ldr	x0, [x2, #5080]
    9b7c:	cb010261 	sub	x1, x19, x1
    9b80:	eb00403f 	cmp	x1, x0, lsl #16
    9b84:	54000382 	b.cs	9bf4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9b88:	d350fc20 	lsr	x0, x1, #16
    9b8c:	f949fc43 	ldr	x3, [x2, #5112]
    9b90:	8b000800 	add	x0, x0, x0, lsl #2
    9b94:	d37df000 	lsl	x0, x0, #3
    9b98:	8b000062 	add	x2, x3, x0
    9b9c:	f9401056 	ldr	x22, [x2, #32]
    9ba0:	b40002b6 	cbz	x22, 9bf4 <fwp_hof0.constprop.0+0x5e4>
    9ba4:	38606860 	ldrb	w0, [x3, x0]
    9ba8:	7100081f 	cmp	w0, #0x2
    9bac:	54002c40 	b.eq	a134 <fwp_hof0.constprop.0+0xb24>  // b.none
    9bb0:	7100041f 	cmp	w0, #0x1
    9bb4:	54000201 	b.ne	9bf4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9bb8:	29430043 	ldp	w3, w0, [x2, #24]
    9bbc:	92403c21 	and	x1, x1, #0xffff
    9bc0:	9b037c21 	mul	x1, x1, x3
    9bc4:	d360fc21 	lsr	x1, x1, #32
    9bc8:	eb00003f 	cmp	x1, x0
    9bcc:	54000142 	b.cs	9bf4 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9bd0:	8b0102d6 	add	x22, x22, x1
    9bd4:	394002c0 	ldrb	w0, [x22]
    9bd8:	340000e0 	cbz	w0, 9bf4 <fwp_hof0.constprop.0+0x5e4>
    9bdc:	7100041f 	cmp	w0, #0x1
    9be0:	54002a00 	b.eq	a120 <fwp_hof0.constprop.0+0xb10>  // b.none
    9be4:	7103fc1f 	cmp	w0, #0xff
    9be8:	54002b20 	b.eq	a14c <fwp_hof0.constprop.0+0xb3c>  // b.none
    9bec:	51000400 	sub	w0, w0, #0x1
    9bf0:	390002c0 	strb	w0, [x22]
    9bf4:	f9400b5a 	ldr	x26, [x26, #16]
    9bf8:	b5ffd3ba 	cbnz	x26, 966c <fwp_hof0.constprop.0+0x5c>
    9bfc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9c00:	f947f400 	ldr	x0, [x0, #4072]
    9c04:	f85f83a2 	ldur	x2, [x29, #-8]
    9c08:	f9400001 	ldr	x1, [x0]
    9c0c:	eb010042 	subs	x2, x2, x1
    9c10:	d2800001 	mov	x1, #0x0                   	// #0
    9c14:	54002dc1 	b.ne	a1cc <fwp_hof0.constprop.0+0xbbc>  // b.any
    9c18:	910003bf 	mov	sp, x29
    9c1c:	d2800000 	mov	x0, #0x0                   	// #0
    9c20:	a94153f3 	ldp	x19, x20, [sp, #16]
    9c24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9c28:	a94363f7 	ldp	x23, x24, [sp, #48]
    9c2c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9c30:	a94573fb 	ldp	x27, x28, [sp, #80]
    9c34:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9c38:	d65f03c0 	ret
    9c3c:	b90004df 	str	wzr, [x6, #4]
    9c40:	17ffff69 	b	99e4 <fwp_hof0.constprop.0+0x3d4>
    9c44:	72003c3f 	tst	w1, #0xffff
    9c48:	54ffec61 	b.ne	99d4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    9c4c:	17ffff5f 	b	99c8 <fwp_hof0.constprop.0+0x3b8>
    9c50:	aa1b03fc 	mov	x28, x27
    9c54:	aa1803fb 	mov	x27, x24
    9c58:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9c5c:	b85c03b8 	ldur	w24, [x29, #-64]
    9c60:	aa1c03e0 	mov	x0, x28
    9c64:	b81d83a7 	stur	w7, [x29, #-40]
    9c68:	97ffeefe 	bl	5860 <fwp_rc_share>
    9c6c:	b85d83a7 	ldur	w7, [x29, #-40]
    9c70:	34000134 	cbz	w20, 9c94 <fwp_hof0.constprop.0+0x684>
    9c74:	aa1b03f6 	mov	x22, x27
    9c78:	8b344f73 	add	x19, x27, w20, uxtw #3
    9c7c:	2a0703f9 	mov	w25, w7
    9c80:	f84086c0 	ldr	x0, [x22], #8
    9c84:	97ffeef7 	bl	5860 <fwp_rc_share>
    9c88:	eb16027f 	cmp	x19, x22
    9c8c:	54ffffa1 	b.ne	9c80 <fwp_hof0.constprop.0+0x670>  // b.any
    9c90:	2a1903e7 	mov	w7, w25
    9c94:	aa1b03e2 	mov	x2, x27
    9c98:	2a1403e1 	mov	w1, w20
    9c9c:	aa1c03e0 	mov	x0, x28
    9ca0:	b81d83a7 	stur	w7, [x29, #-40]
    9ca4:	97ffecec 	bl	5054 <fwp_apply>
    9ca8:	aa0003f9 	mov	x25, x0
    9cac:	b85d83a7 	ldur	w7, [x29, #-40]
    9cb0:	6b17031f 	cmp	w24, w23
    9cb4:	54ffeb82 	b.cs	9a24 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    9cb8:	f94046a1 	ldr	x1, [x21, #136]
    9cbc:	4b0702f7 	sub	w23, w23, w7
    9cc0:	b9400323 	ldr	w3, [x25]
    9cc4:	f85d03a0 	ldur	x0, [x29, #-48]
    9cc8:	8b031423 	add	x3, x1, x3, lsl #5
    9ccc:	b85c83a2 	ldur	w2, [x29, #-56]
    9cd0:	8b274c00 	add	x0, x0, w7, uxtw #3
    9cd4:	f81d03a0 	stur	x0, [x29, #-48]
    9cd8:	f9400c61 	ldr	x1, [x3, #24]
    9cdc:	b85cc3a0 	ldur	w0, [x29, #-52]
    9ce0:	4b020000 	sub	w0, w0, w2
    9ce4:	b81cc3a0 	stur	w0, [x29, #-52]
    9ce8:	aa1903e0 	mov	x0, x25
    9cec:	b5ffd761 	cbnz	x1, 97d8 <fwp_hof0.constprop.0+0x1c8>
    9cf0:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9cf4:	aa1903e0 	mov	x0, x25
    9cf8:	97ffeeda 	bl	5860 <fwp_rc_share>
    9cfc:	34000117 	cbz	w23, 9d1c <fwp_hof0.constprop.0+0x70c>
    9d00:	f85d03b8 	ldur	x24, [x29, #-48]
    9d04:	d2800016 	mov	x22, #0x0                   	// #0
    9d08:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    9d0c:	910006d6 	add	x22, x22, #0x1
    9d10:	97ffeed4 	bl	5860 <fwp_rc_share>
    9d14:	6b1602ff 	cmp	w23, w22
    9d18:	54ffff88 	b.hi	9d08 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    9d1c:	f85d03a2 	ldur	x2, [x29, #-48]
    9d20:	aa1903e0 	mov	x0, x25
    9d24:	2a1703e1 	mov	w1, w23
    9d28:	97ffeccb 	bl	5054 <fwp_apply>
    9d2c:	aa0003f9 	mov	x25, x0
    9d30:	f85983a0 	ldur	x0, [x29, #-104]
    9d34:	f1000400 	subs	x0, x0, #0x1
    9d38:	f81983a0 	stur	x0, [x29, #-104]
    9d3c:	54ffce21 	b.ne	9700 <fwp_hof0.constprop.0+0xf0>  // b.any
    9d40:	17ffff3e 	b	9a38 <fwp_hof0.constprop.0+0x428>
    9d44:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9d48:	9117c00a 	add	x10, x0, #0x5f0
    9d4c:	2a0103fc 	mov	w28, w1
    9d50:	110006c0 	add	w0, w22, #0x1
    9d54:	f120001f 	cmp	x0, #0x800
    9d58:	aa1703fa 	mov	x26, x23
    9d5c:	b953a541 	ldr	w1, [x10, #5028]
    9d60:	aa1803fb 	mov	x27, x24
    9d64:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9d68:	d37df000 	lsl	x0, x0, #3
    9d6c:	b85c03b8 	ldur	w24, [x29, #-64]
    9d70:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9d74:	54001860 	b.eq	a080 <fwp_hof0.constprop.0+0xa70>  // b.none
    9d78:	91003c01 	add	x1, x0, #0xf
    9d7c:	8b411141 	add	x1, x10, x1, lsr #4
    9d80:	397e8021 	ldrb	w1, [x1, #4000]
    9d84:	910f002b 	add	x11, x1, #0x3c0
    9d88:	8b010429 	add	x9, x1, x1, lsl #1
    9d8c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9d90:	8b090d4c 	add	x12, x10, x9, lsl #3
    9d94:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9d98:	2a0b03e1 	mov	w1, w11
    9d9c:	b4001613 	cbz	x19, a05c <fwp_hof0.constprop.0+0xa4c>
    9da0:	f940026c 	ldr	x12, [x19]
    9da4:	aa2c03ec 	mvn	x12, x12
    9da8:	f829794c 	str	x12, [x10, x9, lsl #3]
    9dac:	eb01001f 	cmp	x0, x1
    9db0:	540000c2 	b.cs	9dc8 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9db4:	d503201f 	nop
    9db8:	f8206a7f 	str	xzr, [x19, x0]
    9dbc:	91002000 	add	x0, x0, #0x8
    9dc0:	eb00003f 	cmp	x1, x0
    9dc4:	54ffffa8 	b.hi	9db8 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9dc8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9dcc:	9117c009 	add	x9, x0, #0x5f0
    9dd0:	f94a1120 	ldr	x0, [x9, #5152]
    9dd4:	ab010000 	adds	x0, x0, x1
    9dd8:	54001e82 	b.cs	a1a8 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9ddc:	f94a1521 	ldr	x1, [x9, #5160]
    9de0:	f90a1120 	str	x0, [x9, #5152]
    9de4:	eb01001f 	cmp	x0, x1
    9de8:	54000049 	b.ls	9df0 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9dec:	f90a1520 	str	x0, [x9, #5160]
    9df0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9df4:	9117c000 	add	x0, x0, #0x5f0
    9df8:	1e630161 	ucvtf	d1, w11
    9dfc:	fd4a1c00 	ldr	d0, [x0, #5176]
    9e00:	1e612800 	fadd	d0, d0, d1
    9e04:	fd0a1c00 	str	d0, [x0, #5176]
    9e08:	b94000c0 	ldr	w0, [x6]
    9e0c:	29005a60 	stp	w0, w22, [x19]
    9e10:	3400013c 	cbz	w28, 9e34 <fwp_hof0.constprop.0+0x824>
    9e14:	910020c1 	add	x1, x6, #0x8
    9e18:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9e1c:	91002260 	add	x0, x19, #0x8
    9e20:	b81c03a7 	stur	w7, [x29, #-64]
    9e24:	f81d83a6 	stur	x6, [x29, #-40]
    9e28:	97ffe232 	bl	26f0 <memmove@plt>
    9e2c:	f85d83a6 	ldur	x6, [x29, #-40]
    9e30:	b85c03a7 	ldur	w7, [x29, #-64]
    9e34:	2a1403e9 	mov	w9, w20
    9e38:	d2800001 	mov	x1, #0x0                   	// #0
    9e3c:	34000114 	cbz	w20, 9e5c <fwp_hof0.constprop.0+0x84c>
    9e40:	0b010380 	add	w0, w28, w1
    9e44:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9e48:	8b000e60 	add	x0, x19, x0, lsl #3
    9e4c:	91000421 	add	x1, x1, #0x1
    9e50:	f9000402 	str	x2, [x0, #8]
    9e54:	eb01013f 	cmp	x9, x1
    9e58:	54ffff41 	b.ne	9e40 <fwp_hof0.constprop.0+0x830>  // b.any
    9e5c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9e60:	9117c002 	add	x2, x0, #0x5f0
    9e64:	f949d840 	ldr	x0, [x2, #5040]
    9e68:	f949ec41 	ldr	x1, [x2, #5080]
    9e6c:	cb000320 	sub	x0, x25, x0
    9e70:	eb01401f 	cmp	x0, x1, lsl #16
    9e74:	540002e2 	b.cs	9ed0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9e78:	d350fc01 	lsr	x1, x0, #16
    9e7c:	f949fc45 	ldr	x5, [x2, #5112]
    9e80:	8b010821 	add	x1, x1, x1, lsl #2
    9e84:	d37df021 	lsl	x1, x1, #3
    9e88:	8b0100a4 	add	x4, x5, x1
    9e8c:	f9401082 	ldr	x2, [x4, #32]
    9e90:	b4000202 	cbz	x2, 9ed0 <fwp_hof0.constprop.0+0x8c0>
    9e94:	386168a1 	ldrb	w1, [x5, x1]
    9e98:	7100083f 	cmp	w1, #0x2
    9e9c:	54001020 	b.eq	a0a0 <fwp_hof0.constprop.0+0xa90>  // b.none
    9ea0:	7100043f 	cmp	w1, #0x1
    9ea4:	54000161 	b.ne	9ed0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9ea8:	29430485 	ldp	w5, w1, [x4, #24]
    9eac:	92403c00 	and	x0, x0, #0xffff
    9eb0:	9b057c00 	mul	x0, x0, x5
    9eb4:	d360fc00 	lsr	x0, x0, #32
    9eb8:	eb01001f 	cmp	x0, x1
    9ebc:	540000a2 	b.cs	9ed0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9ec0:	8b000042 	add	x2, x2, x0
    9ec4:	39400040 	ldrb	w0, [x2]
    9ec8:	7100041f 	cmp	w0, #0x1
    9ecc:	54000be0 	b.eq	a048 <fwp_hof0.constprop.0+0xa38>  // b.none
    9ed0:	f9400f42 	ldr	x2, [x26, #24]
    9ed4:	aa1903e0 	mov	x0, x25
    9ed8:	52800021 	mov	w1, #0x1                   	// #1
    9edc:	b81d83a7 	stur	w7, [x29, #-40]
    9ee0:	f9400442 	ldr	x2, [x2, #8]
    9ee4:	d63f0040 	blr	x2
    9ee8:	b85d83a7 	ldur	w7, [x29, #-40]
    9eec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    9ef0:	9117c002 	add	x2, x0, #0x5f0
    9ef4:	f949d841 	ldr	x1, [x2, #5040]
    9ef8:	f949ec40 	ldr	x0, [x2, #5080]
    9efc:	cb010261 	sub	x1, x19, x1
    9f00:	eb00403f 	cmp	x1, x0, lsl #16
    9f04:	54000322 	b.cs	9f68 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9f08:	d350fc20 	lsr	x0, x1, #16
    9f0c:	f949fc43 	ldr	x3, [x2, #5112]
    9f10:	8b000800 	add	x0, x0, x0, lsl #2
    9f14:	d37df002 	lsl	x2, x0, #3
    9f18:	8b020060 	add	x0, x3, x2
    9f1c:	f9401014 	ldr	x20, [x0, #32]
    9f20:	b4000254 	cbz	x20, 9f68 <fwp_hof0.constprop.0+0x958>
    9f24:	38626862 	ldrb	w2, [x3, x2]
    9f28:	7100085f 	cmp	w2, #0x2
    9f2c:	54000c00 	b.eq	a0ac <fwp_hof0.constprop.0+0xa9c>  // b.none
    9f30:	7100045f 	cmp	w2, #0x1
    9f34:	540001a1 	b.ne	9f68 <fwp_hof0.constprop.0+0x958>  // b.any
    9f38:	29430002 	ldp	w2, w0, [x0, #24]
    9f3c:	92403c21 	and	x1, x1, #0xffff
    9f40:	9b027c21 	mul	x1, x1, x2
    9f44:	d360fc21 	lsr	x1, x1, #32
    9f48:	eb00003f 	cmp	x1, x0
    9f4c:	540000e2 	b.cs	9f68 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9f50:	8b010294 	add	x20, x20, x1
    9f54:	39400280 	ldrb	w0, [x20]
    9f58:	7103fc1f 	cmp	w0, #0xff
    9f5c:	54000b20 	b.eq	a0c0 <fwp_hof0.constprop.0+0xab0>  // b.none
    9f60:	52800020 	mov	w0, #0x1                   	// #1
    9f64:	39000280 	strb	w0, [x20]
    9f68:	aa1903e0 	mov	x0, x25
    9f6c:	b81d83a7 	stur	w7, [x29, #-40]
    9f70:	97fff018 	bl	5fd0 <fwp_closure_drop>
    9f74:	aa1303f9 	mov	x25, x19
    9f78:	b85d83a7 	ldur	w7, [x29, #-40]
    9f7c:	17ffff4d 	b	9cb0 <fwp_hof0.constprop.0+0x6a0>
    9f80:	b8626860 	ldr	w0, [x3, x2]
    9f84:	b94004a2 	ldr	w2, [x5, #4]
    9f88:	4b020003 	sub	w3, w0, w2
    9f8c:	7100047f 	cmp	w3, #0x1
    9f90:	54ffbd01 	b.ne	9730 <fwp_hof0.constprop.0+0x120>  // b.any
    9f94:	910003f6 	mov	x22, sp
    9f98:	34000a22 	cbz	w2, a0dc <fwp_hof0.constprop.0+0xacc>
    9f9c:	7100001f 	cmp	w0, #0x0
    9fa0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9fa4:	d2800101 	mov	x1, #0x8                   	// #8
    9fa8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9fac:	91003ee0 	add	x0, x23, #0xf
    9fb0:	92704c01 	and	x1, x0, #0xfffff0000
    9fb4:	927c7c00 	and	x0, x0, #0xffffffff0
    9fb8:	cb2163e1 	sub	x1, sp, x1
    9fbc:	eb2163ff 	cmp	sp, x1
    9fc0:	540000a0 	b.eq	9fd4 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9fc4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9fc8:	f90203ff 	str	xzr, [sp, #1024]
    9fcc:	eb2163ff 	cmp	sp, x1
    9fd0:	54ffffa1 	b.ne	9fc4 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9fd4:	92403c00 	and	x0, x0, #0xffff
    9fd8:	cb2063ff 	sub	sp, sp, x0
    9fdc:	f90003ff 	str	xzr, [sp]
    9fe0:	f110001f 	cmp	x0, #0x400
    9fe4:	54000043 	b.cc	9fec <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9fe8:	f90203ff 	str	xzr, [sp, #1024]
    9fec:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9ff0:	910043f8 	add	x24, sp, #0x10
    9ff4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ff8:	91004001 	add	x1, x0, #0x10
    9ffc:	aa1c03e2 	mov	x2, x28
    a000:	91012021 	add	x1, x1, #0x48
    a004:	aa1703e3 	mov	x3, x23
    a008:	aa1803e0 	mov	x0, x24
    a00c:	97ffe1f1 	bl	27d0 <__memcpy_chk@plt>
    a010:	eb1c02ff 	cmp	x23, x28
    a014:	aa1403e1 	mov	x1, x20
    a018:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a01c:	d2800102 	mov	x2, #0x8                   	// #8
    a020:	cb1c0063 	sub	x3, x3, x28
    a024:	8b1c0300 	add	x0, x24, x28
    a028:	97ffe1ea 	bl	27d0 <__memcpy_chk@plt>
    a02c:	f9400f61 	ldr	x1, [x27, #24]
    a030:	aa1803e0 	mov	x0, x24
    a034:	f9400021 	ldr	x1, [x1]
    a038:	d63f0020 	blr	x1
    a03c:	aa0003f9 	mov	x25, x0
    a040:	910002df 	mov	sp, x22
    a044:	17ffff3b 	b	9d30 <fwp_hof0.constprop.0+0x720>
    a048:	b90004df 	str	wzr, [x6, #4]
    a04c:	17ffffa8 	b	9eec <fwp_hof0.constprop.0+0x8dc>
    a050:	72003c3f 	tst	w1, #0xffff
    a054:	54ffbae1 	b.ne	97b0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a058:	17fffdd0 	b	9798 <fwp_hof0.constprop.0+0x188>
    a05c:	f9400593 	ldr	x19, [x12, #8]
    a060:	b4000113 	cbz	x19, a080 <fwp_hof0.constprop.0+0xa70>
    a064:	f9400989 	ldr	x9, [x12, #16]
    a068:	cb130129 	sub	x9, x9, x19
    a06c:	eb09003f 	cmp	x1, x9
    a070:	54000088 	b.hi	a080 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    a074:	8b010269 	add	x9, x19, x1
    a078:	f9000589 	str	x9, [x12, #8]
    a07c:	17ffff4c 	b	9dac <fwp_hof0.constprop.0+0x79c>
    a080:	52800001 	mov	w1, #0x0                   	// #0
    a084:	f81c03a6 	stur	x6, [x29, #-64]
    a088:	b81d83a7 	stur	w7, [x29, #-40]
    a08c:	97ffebad 	bl	4f40 <fwp_heap_alloc>
    a090:	f85c03a6 	ldur	x6, [x29, #-64]
    a094:	aa0003f3 	mov	x19, x0
    a098:	b85d83a7 	ldur	w7, [x29, #-40]
    a09c:	17ffff5b 	b	9e08 <fwp_hof0.constprop.0+0x7f8>
    a0a0:	72003c1f 	tst	w0, #0xffff
    a0a4:	54fff161 	b.ne	9ed0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    a0a8:	17ffff87 	b	9ec4 <fwp_hof0.constprop.0+0x8b4>
    a0ac:	72003c3f 	tst	w1, #0xffff
    a0b0:	54fff5c1 	b.ne	9f68 <fwp_hof0.constprop.0+0x958>  // b.any
    a0b4:	39400280 	ldrb	w0, [x20]
    a0b8:	7103fc1f 	cmp	w0, #0xff
    a0bc:	54fff521 	b.ne	9f60 <fwp_hof0.constprop.0+0x950>  // b.any
    a0c0:	aa1403e0 	mov	x0, x20
    a0c4:	b81d83a7 	stur	w7, [x29, #-40]
    a0c8:	97ffe9de 	bl	4840 <fwp_rc_forget_slot>
    a0cc:	b85d83a7 	ldur	w7, [x29, #-40]
    a0d0:	17ffffa4 	b	9f60 <fwp_hof0.constprop.0+0x950>
    a0d4:	97ffe994 	bl	4724 <fwp_rc_wide_dup>
    a0d8:	17fffdb6 	b	97b0 <fwp_hof0.constprop.0+0x1a0>
    a0dc:	f9400021 	ldr	x1, [x1]
    a0e0:	aa1403e0 	mov	x0, x20
    a0e4:	d63f0020 	blr	x1
    a0e8:	aa0003f9 	mov	x25, x0
    a0ec:	910002df 	mov	sp, x22
    a0f0:	17ffff10 	b	9d30 <fwp_hof0.constprop.0+0x720>
    a0f4:	72003c3f 	tst	w1, #0xffff
    a0f8:	54ffafa1 	b.ne	96ec <fwp_hof0.constprop.0+0xdc>  // b.any
    a0fc:	17fffd76 	b	96d4 <fwp_hof0.constprop.0+0xc4>
    a100:	aa1a03e0 	mov	x0, x26
    a104:	97ffedd7 	bl	5860 <fwp_rc_share>
    a108:	aa1903e0 	mov	x0, x25
    a10c:	52800037 	mov	w23, #0x1                   	// #1
    a110:	97ffedd4 	bl	5860 <fwp_rc_share>
    a114:	aa1a03f9 	mov	x25, x26
    a118:	f81d03b4 	stur	x20, [x29, #-48]
    a11c:	17ffff00 	b	9d1c <fwp_hof0.constprop.0+0x70c>
    a120:	aa1303e0 	mov	x0, x19
    a124:	97ffee24 	bl	59b4 <fwp_rc_free_arr>
    a128:	f9400b5a 	ldr	x26, [x26, #16]
    a12c:	b5ffaa1a 	cbnz	x26, 966c <fwp_hof0.constprop.0+0x5c>
    a130:	17fffeb3 	b	9bfc <fwp_hof0.constprop.0+0x5ec>
    a134:	72003c3f 	tst	w1, #0xffff
    a138:	54ffd5e1 	b.ne	9bf4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a13c:	17fffea6 	b	9bd4 <fwp_hof0.constprop.0+0x5c4>
    a140:	72003c3f 	tst	w1, #0xffff
    a144:	54ffcfa1 	b.ne	9b38 <fwp_hof0.constprop.0+0x528>  // b.any
    a148:	17fffe77 	b	9b24 <fwp_hof0.constprop.0+0x514>
    a14c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a150:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a154:	9117c021 	add	x1, x1, #0x5f0
    a158:	ca402400 	eor	x0, x0, x0, lsr #9
    a15c:	8b200c20 	add	x0, x1, w0, uxtb #3
    a160:	f94a2400 	ldr	x0, [x0, #5192]
    a164:	b5000080 	cbnz	x0, a174 <fwp_hof0.constprop.0+0xb64>
    a168:	14000011 	b	a1ac <fwp_hof0.constprop.0+0xb9c>
    a16c:	f9400800 	ldr	x0, [x0, #16]
    a170:	b40001e0 	cbz	x0, a1ac <fwp_hof0.constprop.0+0xb9c>
    a174:	f9400001 	ldr	x1, [x0]
    a178:	eb0102df 	cmp	x22, x1
    a17c:	54ffff81 	b.ne	a16c <fwp_hof0.constprop.0+0xb5c>  // b.any
    a180:	f9400401 	ldr	x1, [x0, #8]
    a184:	d1000421 	sub	x1, x1, #0x1
    a188:	f9000401 	str	x1, [x0, #8]
    a18c:	f103f83f 	cmp	x1, #0xfe
    a190:	54ffd321 	b.ne	9bf4 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a194:	aa1603e0 	mov	x0, x22
    a198:	97ffe9aa 	bl	4840 <fwp_rc_forget_slot>
    a19c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a1a0:	390002c0 	strb	w0, [x22]
    a1a4:	17fffe94 	b	9bf4 <fwp_hof0.constprop.0+0x5e4>
    a1a8:	97ffe3a2 	bl	3030 <fwp_heap_oom>
    a1ac:	f0000000 	adrp	x0, d000 <__divti3+0x260>
    a1b0:	91208000 	add	x0, x0, #0x820
    a1b4:	97ffe593 	bl	3800 <fwp_trap>
    a1b8:	f0000000 	adrp	x0, d000 <__divti3+0x260>
    a1bc:	912c6000 	add	x0, x0, #0xb18
    a1c0:	97ffe590 	bl	3800 <fwp_trap>
    a1c4:	97ffe958 	bl	4724 <fwp_rc_wide_dup>
    a1c8:	17fffd49 	b	96ec <fwp_hof0.constprop.0+0xdc>
    a1cc:	97ffe1ad 	bl	2880 <__stack_chk_fail@plt>
    a1d0:	aa1903e0 	mov	x0, x25
    a1d4:	97ffe99b 	bl	4840 <fwp_rc_forget_slot>
    a1d8:	17fffe56 	b	9b30 <fwp_hof0.constprop.0+0x520>
    a1dc:	d503201f 	nop

000000000000a1e0 <f0>:
    a1e0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a1e4:	910003fd 	mov	x29, sp
    a1e8:	a90153f3 	stp	x19, x20, [sp, #16]
    a1ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    a1f0:	a90363f7 	stp	x23, x24, [sp, #48]
    a1f4:	a9046bf9 	stp	x25, x26, [sp, #64]
    a1f8:	a90573fb 	stp	x27, x28, [sp, #80]
    a1fc:	d12183ff 	sub	sp, sp, #0x860
    a200:	f90203ff 	str	xzr, [sp, #1024]
    a204:	d00000a0 	adrp	x0, 20000 <__data_start>
    a208:	9101c005 	add	x5, x0, #0x70
    a20c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a210:	f947f400 	ldr	x0, [x0, #4072]
    a214:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    a218:	f94198a6 	ldr	x6, [x5, #816]
    a21c:	f9400001 	ldr	x1, [x0]
    a220:	f9042fe1 	str	x1, [sp, #2136]
    a224:	d2800001 	mov	x1, #0x0                   	// #0
    a228:	9117c298 	add	x24, x20, #0x5f0
    a22c:	912123f6 	add	x22, sp, #0x848
    a230:	910023e0 	add	x0, sp, #0x8
    a234:	910083e2 	add	x2, sp, #0x20
    a238:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc+0xc0>
    a23c:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a240:	91344021 	add	x1, x1, #0xd10
    a244:	913d4084 	add	x4, x4, #0xf50
    a248:	d2800013 	mov	x19, #0x0                   	// #0
    a24c:	d2800119 	mov	x25, #0x8                   	// #8
    a250:	d2800015 	mov	x21, #0x0                   	// #0
    a254:	52800037 	mov	w23, #0x1                   	// #1
    a258:	a90093e6 	stp	x6, x4, [sp, #8]
    a25c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a260:	a90307ff 	stp	xzr, x1, [sp, #48]
    a264:	f90198a0 	str	x0, [x5, #816]
    a268:	f100073a 	subs	x26, x25, #0x1
    a26c:	aa1603e1 	mov	x1, x22
    a270:	da1f02bc 	sbc	x28, x21, xzr
    a274:	52800020 	mov	w0, #0x1                   	// #1
    a278:	f90017fa 	str	x26, [sp, #40]
    a27c:	aa1a03f9 	mov	x25, x26
    a280:	f90427fa 	str	x26, [sp, #2120]
    a284:	aa1c03f5 	mov	x21, x28
    a288:	f9042bf3 	str	x19, [sp, #2128]
    a28c:	97ffed2d 	bl	5740 <fwp_data.part.0.constprop.0>
    a290:	f949db02 	ldr	x2, [x24, #5040]
    a294:	aa0003f3 	mov	x19, x0
    a298:	f949ef00 	ldr	x0, [x24, #5080]
    a29c:	cb020262 	sub	x2, x19, x2
    a2a0:	eb00405f 	cmp	x2, x0, lsl #16
    a2a4:	54000302 	b.cs	a304 <f0+0x124>  // b.hs, b.nlast
    a2a8:	d350fc40 	lsr	x0, x2, #16
    a2ac:	f949ff04 	ldr	x4, [x24, #5112]
    a2b0:	8b000800 	add	x0, x0, x0, lsl #2
    a2b4:	d37df001 	lsl	x1, x0, #3
    a2b8:	8b010080 	add	x0, x4, x1
    a2bc:	f940101b 	ldr	x27, [x0, #32]
    a2c0:	b400023b 	cbz	x27, a304 <f0+0x124>
    a2c4:	38616881 	ldrb	w1, [x4, x1]
    a2c8:	7100083f 	cmp	w1, #0x2
    a2cc:	54010cc0 	b.eq	c464 <f0+0x2284>  // b.none
    a2d0:	7100043f 	cmp	w1, #0x1
    a2d4:	54000181 	b.ne	a304 <f0+0x124>  // b.any
    a2d8:	29430001 	ldp	w1, w0, [x0, #24]
    a2dc:	92403c42 	and	x2, x2, #0xffff
    a2e0:	9b017c42 	mul	x2, x2, x1
    a2e4:	d360fc42 	lsr	x2, x2, #32
    a2e8:	eb00005f 	cmp	x2, x0
    a2ec:	540000c2 	b.cs	a304 <f0+0x124>  // b.hs, b.nlast
    a2f0:	8b02037b 	add	x27, x27, x2
    a2f4:	39400360 	ldrb	w0, [x27]
    a2f8:	7103fc1f 	cmp	w0, #0xff
    a2fc:	54010ae0 	b.eq	c458 <f0+0x2278>  // b.none
    a300:	39000377 	strb	w23, [x27]
    a304:	f90013f3 	str	x19, [sp, #32]
    a308:	aa1c035a 	orr	x26, x26, x28
    a30c:	b5fffafa 	cbnz	x26, a268 <f0+0x88>
    a310:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xb40>
    a314:	910103e1 	add	x1, sp, #0x40
    a318:	f94007e2 	ldr	x2, [sp, #8]
    a31c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a320:	3dc0a800 	ldr	q0, [x0, #672]
    a324:	d00000a0 	adrp	x0, 20000 <__data_start>
    a328:	9101c018 	add	x24, x0, #0x70
    a32c:	52800020 	mov	w0, #0x1                   	// #1
    a330:	3d8013e0 	str	q0, [sp, #64]
    a334:	f9019b02 	str	x2, [x24, #816]
    a338:	97ffed02 	bl	5740 <fwp_data.part.0.constprop.0>
    a33c:	97ffed6e 	bl	58f4 <fwp_rc_fresh>
    a340:	aa0003e2 	mov	x2, x0
    a344:	910163e1 	add	x1, sp, #0x58
    a348:	52800020 	mov	w0, #0x1                   	// #1
    a34c:	a9058bf5 	stp	x21, x2, [sp, #88]
    a350:	97ffecfc 	bl	5740 <fwp_data.part.0.constprop.0>
    a354:	97ffed68 	bl	58f4 <fwp_rc_fresh>
    a358:	aa0003e2 	mov	x2, x0
    a35c:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xb40>
    a360:	9101a3e1 	add	x1, sp, #0x68
    a364:	52800020 	mov	w0, #0x1                   	// #1
    a368:	f9003be2 	str	x2, [sp, #112]
    a36c:	3dc0a860 	ldr	q0, [x3, #672]
    a370:	fd0037e0 	str	d0, [sp, #104]
    a374:	97ffecf3 	bl	5740 <fwp_data.part.0.constprop.0>
    a378:	97ffed5f 	bl	58f4 <fwp_rc_fresh>
    a37c:	aa0003e2 	mov	x2, x0
    a380:	9101e3e1 	add	x1, sp, #0x78
    a384:	52800020 	mov	w0, #0x1                   	// #1
    a388:	a9078bf5 	stp	x21, x2, [sp, #120]
    a38c:	97ffeced 	bl	5740 <fwp_data.part.0.constprop.0>
    a390:	9117c283 	add	x3, x20, #0x5f0
    a394:	aa0003f5 	mov	x21, x0
    a398:	f949d861 	ldr	x1, [x3, #5040]
    a39c:	f949ec60 	ldr	x0, [x3, #5080]
    a3a0:	cb0102a1 	sub	x1, x21, x1
    a3a4:	eb00403f 	cmp	x1, x0, lsl #16
    a3a8:	54000322 	b.cs	a40c <f0+0x22c>  // b.hs, b.nlast
    a3ac:	d350fc22 	lsr	x2, x1, #16
    a3b0:	f949fc63 	ldr	x3, [x3, #5112]
    a3b4:	8b020842 	add	x2, x2, x2, lsl #2
    a3b8:	d37df042 	lsl	x2, x2, #3
    a3bc:	8b020060 	add	x0, x3, x2
    a3c0:	f9401017 	ldr	x23, [x0, #32]
    a3c4:	b4000257 	cbz	x23, a40c <f0+0x22c>
    a3c8:	38626862 	ldrb	w2, [x3, x2]
    a3cc:	7100085f 	cmp	w2, #0x2
    a3d0:	540108c0 	b.eq	c4e8 <f0+0x2308>  // b.none
    a3d4:	7100045f 	cmp	w2, #0x1
    a3d8:	540001a1 	b.ne	a40c <f0+0x22c>  // b.any
    a3dc:	29430002 	ldp	w2, w0, [x0, #24]
    a3e0:	92403c21 	and	x1, x1, #0xffff
    a3e4:	9b027c21 	mul	x1, x1, x2
    a3e8:	d360fc21 	lsr	x1, x1, #32
    a3ec:	eb00003f 	cmp	x1, x0
    a3f0:	540000e2 	b.cs	a40c <f0+0x22c>  // b.hs, b.nlast
    a3f4:	8b0102f7 	add	x23, x23, x1
    a3f8:	394002e0 	ldrb	w0, [x23]
    a3fc:	7103fc1f 	cmp	w0, #0xff
    a400:	54011280 	b.eq	c650 <f0+0x2470>  // b.none
    a404:	52800020 	mov	w0, #0x1                   	// #1
    a408:	390002e0 	strb	w0, [x23]
    a40c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a410:	910223e1 	add	x1, sp, #0x88
    a414:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a418:	52800020 	mov	w0, #0x1                   	// #1
    a41c:	a908d7e2 	stp	x2, x21, [sp, #136]
    a420:	97ffecc8 	bl	5740 <fwp_data.part.0.constprop.0>
    a424:	97ffed34 	bl	58f4 <fwp_rc_fresh>
    a428:	aa0003e2 	mov	x2, x0
    a42c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a430:	910263e1 	add	x1, sp, #0x98
    a434:	52800020 	mov	w0, #0x1                   	// #1
    a438:	a9098be3 	stp	x3, x2, [sp, #152]
    a43c:	97ffecc1 	bl	5740 <fwp_data.part.0.constprop.0>
    a440:	9117c283 	add	x3, x20, #0x5f0
    a444:	aa0003f5 	mov	x21, x0
    a448:	f949d861 	ldr	x1, [x3, #5040]
    a44c:	f949ec60 	ldr	x0, [x3, #5080]
    a450:	cb0102a1 	sub	x1, x21, x1
    a454:	eb00403f 	cmp	x1, x0, lsl #16
    a458:	54000322 	b.cs	a4bc <f0+0x2dc>  // b.hs, b.nlast
    a45c:	d350fc22 	lsr	x2, x1, #16
    a460:	f949fc63 	ldr	x3, [x3, #5112]
    a464:	8b020842 	add	x2, x2, x2, lsl #2
    a468:	d37df042 	lsl	x2, x2, #3
    a46c:	8b020060 	add	x0, x3, x2
    a470:	f9401017 	ldr	x23, [x0, #32]
    a474:	b4000257 	cbz	x23, a4bc <f0+0x2dc>
    a478:	38626862 	ldrb	w2, [x3, x2]
    a47c:	7100085f 	cmp	w2, #0x2
    a480:	540102e0 	b.eq	c4dc <f0+0x22fc>  // b.none
    a484:	7100045f 	cmp	w2, #0x1
    a488:	540001a1 	b.ne	a4bc <f0+0x2dc>  // b.any
    a48c:	29430002 	ldp	w2, w0, [x0, #24]
    a490:	92403c21 	and	x1, x1, #0xffff
    a494:	9b027c21 	mul	x1, x1, x2
    a498:	d360fc21 	lsr	x1, x1, #32
    a49c:	eb00003f 	cmp	x1, x0
    a4a0:	540000e2 	b.cs	a4bc <f0+0x2dc>  // b.hs, b.nlast
    a4a4:	8b0102f7 	add	x23, x23, x1
    a4a8:	394002e0 	ldrb	w0, [x23]
    a4ac:	7103fc1f 	cmp	w0, #0xff
    a4b0:	54010d60 	b.eq	c65c <f0+0x247c>  // b.none
    a4b4:	52800020 	mov	w0, #0x1                   	// #1
    a4b8:	390002e0 	strb	w0, [x23]
    a4bc:	9102a3e1 	add	x1, sp, #0xa8
    a4c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a4c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a4c8:	52800020 	mov	w0, #0x1                   	// #1
    a4cc:	a90ad7f7 	stp	x23, x21, [sp, #168]
    a4d0:	97ffec9c 	bl	5740 <fwp_data.part.0.constprop.0>
    a4d4:	97ffed08 	bl	58f4 <fwp_rc_fresh>
    a4d8:	aa0003e2 	mov	x2, x0
    a4dc:	9102e3e1 	add	x1, sp, #0xb8
    a4e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a4e4:	52800020 	mov	w0, #0x1                   	// #1
    a4e8:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a4ec:	97ffec95 	bl	5740 <fwp_data.part.0.constprop.0>
    a4f0:	97ffed01 	bl	58f4 <fwp_rc_fresh>
    a4f4:	aa0003e2 	mov	x2, x0
    a4f8:	910323e1 	add	x1, sp, #0xc8
    a4fc:	52800020 	mov	w0, #0x1                   	// #1
    a500:	a90c8bf7 	stp	x23, x2, [sp, #200]
    a504:	97ffec8f 	bl	5740 <fwp_data.part.0.constprop.0>
    a508:	97ffecfb 	bl	58f4 <fwp_rc_fresh>
    a50c:	aa0003e2 	mov	x2, x0
    a510:	910363e1 	add	x1, sp, #0xd8
    a514:	52800020 	mov	w0, #0x1                   	// #1
    a518:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a51c:	97ffec89 	bl	5740 <fwp_data.part.0.constprop.0>
    a520:	9117c283 	add	x3, x20, #0x5f0
    a524:	aa0003f5 	mov	x21, x0
    a528:	f949d861 	ldr	x1, [x3, #5040]
    a52c:	f949ec60 	ldr	x0, [x3, #5080]
    a530:	cb0102a1 	sub	x1, x21, x1
    a534:	eb00403f 	cmp	x1, x0, lsl #16
    a538:	54000322 	b.cs	a59c <f0+0x3bc>  // b.hs, b.nlast
    a53c:	d350fc22 	lsr	x2, x1, #16
    a540:	f949fc63 	ldr	x3, [x3, #5112]
    a544:	8b020842 	add	x2, x2, x2, lsl #2
    a548:	d37df042 	lsl	x2, x2, #3
    a54c:	8b020060 	add	x0, x3, x2
    a550:	f9401017 	ldr	x23, [x0, #32]
    a554:	b4000257 	cbz	x23, a59c <f0+0x3bc>
    a558:	38626862 	ldrb	w2, [x3, x2]
    a55c:	7100085f 	cmp	w2, #0x2
    a560:	5400fb80 	b.eq	c4d0 <f0+0x22f0>  // b.none
    a564:	7100045f 	cmp	w2, #0x1
    a568:	540001a1 	b.ne	a59c <f0+0x3bc>  // b.any
    a56c:	29430002 	ldp	w2, w0, [x0, #24]
    a570:	92403c21 	and	x1, x1, #0xffff
    a574:	9b027c21 	mul	x1, x1, x2
    a578:	d360fc21 	lsr	x1, x1, #32
    a57c:	eb00003f 	cmp	x1, x0
    a580:	540000e2 	b.cs	a59c <f0+0x3bc>  // b.hs, b.nlast
    a584:	8b0102f7 	add	x23, x23, x1
    a588:	394002e0 	ldrb	w0, [x23]
    a58c:	7103fc1f 	cmp	w0, #0xff
    a590:	540106c0 	b.eq	c668 <f0+0x2488>  // b.none
    a594:	52800020 	mov	w0, #0x1                   	// #1
    a598:	390002e0 	strb	w0, [x23]
    a59c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a5a0:	9103a3e1 	add	x1, sp, #0xe8
    a5a4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a5a8:	52800020 	mov	w0, #0x1                   	// #1
    a5ac:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a5b0:	97ffec64 	bl	5740 <fwp_data.part.0.constprop.0>
    a5b4:	97ffecd0 	bl	58f4 <fwp_rc_fresh>
    a5b8:	aa0003e2 	mov	x2, x0
    a5bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a5c0:	9103e3e1 	add	x1, sp, #0xf8
    a5c4:	52800020 	mov	w0, #0x1                   	// #1
    a5c8:	a90f8be3 	stp	x3, x2, [sp, #248]
    a5cc:	97ffec5d 	bl	5740 <fwp_data.part.0.constprop.0>
    a5d0:	9117c283 	add	x3, x20, #0x5f0
    a5d4:	aa0003f5 	mov	x21, x0
    a5d8:	f949d861 	ldr	x1, [x3, #5040]
    a5dc:	f949ec60 	ldr	x0, [x3, #5080]
    a5e0:	cb0102a1 	sub	x1, x21, x1
    a5e4:	eb00403f 	cmp	x1, x0, lsl #16
    a5e8:	54000322 	b.cs	a64c <f0+0x46c>  // b.hs, b.nlast
    a5ec:	d350fc22 	lsr	x2, x1, #16
    a5f0:	f949fc63 	ldr	x3, [x3, #5112]
    a5f4:	8b020842 	add	x2, x2, x2, lsl #2
    a5f8:	d37df042 	lsl	x2, x2, #3
    a5fc:	8b020060 	add	x0, x3, x2
    a600:	f9401017 	ldr	x23, [x0, #32]
    a604:	b4000257 	cbz	x23, a64c <f0+0x46c>
    a608:	38626862 	ldrb	w2, [x3, x2]
    a60c:	7100085f 	cmp	w2, #0x2
    a610:	5400f840 	b.eq	c518 <f0+0x2338>  // b.none
    a614:	7100045f 	cmp	w2, #0x1
    a618:	540001a1 	b.ne	a64c <f0+0x46c>  // b.any
    a61c:	29430002 	ldp	w2, w0, [x0, #24]
    a620:	92403c21 	and	x1, x1, #0xffff
    a624:	9b027c21 	mul	x1, x1, x2
    a628:	d360fc21 	lsr	x1, x1, #32
    a62c:	eb00003f 	cmp	x1, x0
    a630:	540000e2 	b.cs	a64c <f0+0x46c>  // b.hs, b.nlast
    a634:	8b0102f7 	add	x23, x23, x1
    a638:	394002e0 	ldrb	w0, [x23]
    a63c:	7103fc1f 	cmp	w0, #0xff
    a640:	540101a0 	b.eq	c674 <f0+0x2494>  // b.none
    a644:	52800020 	mov	w0, #0x1                   	// #1
    a648:	390002e0 	strb	w0, [x23]
    a64c:	910423e1 	add	x1, sp, #0x108
    a650:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a654:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a658:	52800020 	mov	w0, #0x1                   	// #1
    a65c:	a910d7f7 	stp	x23, x21, [sp, #264]
    a660:	97ffec38 	bl	5740 <fwp_data.part.0.constprop.0>
    a664:	97ffeca4 	bl	58f4 <fwp_rc_fresh>
    a668:	aa0003e2 	mov	x2, x0
    a66c:	910463e1 	add	x1, sp, #0x118
    a670:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a674:	52800020 	mov	w0, #0x1                   	// #1
    a678:	a9118bf5 	stp	x21, x2, [sp, #280]
    a67c:	97ffec31 	bl	5740 <fwp_data.part.0.constprop.0>
    a680:	97ffec9d 	bl	58f4 <fwp_rc_fresh>
    a684:	aa0003e2 	mov	x2, x0
    a688:	9104a3e1 	add	x1, sp, #0x128
    a68c:	52800020 	mov	w0, #0x1                   	// #1
    a690:	a9128bf7 	stp	x23, x2, [sp, #296]
    a694:	97ffec2b 	bl	5740 <fwp_data.part.0.constprop.0>
    a698:	97ffec97 	bl	58f4 <fwp_rc_fresh>
    a69c:	aa0003e2 	mov	x2, x0
    a6a0:	9104e3e1 	add	x1, sp, #0x138
    a6a4:	52800020 	mov	w0, #0x1                   	// #1
    a6a8:	a9138bf5 	stp	x21, x2, [sp, #312]
    a6ac:	97ffec25 	bl	5740 <fwp_data.part.0.constprop.0>
    a6b0:	9117c283 	add	x3, x20, #0x5f0
    a6b4:	aa0003f5 	mov	x21, x0
    a6b8:	f949d861 	ldr	x1, [x3, #5040]
    a6bc:	f949ec60 	ldr	x0, [x3, #5080]
    a6c0:	cb0102a1 	sub	x1, x21, x1
    a6c4:	eb00403f 	cmp	x1, x0, lsl #16
    a6c8:	54000322 	b.cs	a72c <f0+0x54c>  // b.hs, b.nlast
    a6cc:	d350fc22 	lsr	x2, x1, #16
    a6d0:	f949fc63 	ldr	x3, [x3, #5112]
    a6d4:	8b020842 	add	x2, x2, x2, lsl #2
    a6d8:	d37df042 	lsl	x2, x2, #3
    a6dc:	8b020060 	add	x0, x3, x2
    a6e0:	f9401017 	ldr	x23, [x0, #32]
    a6e4:	b4000257 	cbz	x23, a72c <f0+0x54c>
    a6e8:	38626862 	ldrb	w2, [x3, x2]
    a6ec:	7100085f 	cmp	w2, #0x2
    a6f0:	5400f0e0 	b.eq	c50c <f0+0x232c>  // b.none
    a6f4:	7100045f 	cmp	w2, #0x1
    a6f8:	540001a1 	b.ne	a72c <f0+0x54c>  // b.any
    a6fc:	29430002 	ldp	w2, w0, [x0, #24]
    a700:	92403c21 	and	x1, x1, #0xffff
    a704:	9b027c21 	mul	x1, x1, x2
    a708:	d360fc21 	lsr	x1, x1, #32
    a70c:	eb00003f 	cmp	x1, x0
    a710:	540000e2 	b.cs	a72c <f0+0x54c>  // b.hs, b.nlast
    a714:	8b0102f7 	add	x23, x23, x1
    a718:	394002e0 	ldrb	w0, [x23]
    a71c:	7103fc1f 	cmp	w0, #0xff
    a720:	5400fb00 	b.eq	c680 <f0+0x24a0>  // b.none
    a724:	52800020 	mov	w0, #0x1                   	// #1
    a728:	390002e0 	strb	w0, [x23]
    a72c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a730:	910523e1 	add	x1, sp, #0x148
    a734:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a738:	52800020 	mov	w0, #0x1                   	// #1
    a73c:	a914d7e2 	stp	x2, x21, [sp, #328]
    a740:	97ffec00 	bl	5740 <fwp_data.part.0.constprop.0>
    a744:	9117c283 	add	x3, x20, #0x5f0
    a748:	aa0003f5 	mov	x21, x0
    a74c:	f949d861 	ldr	x1, [x3, #5040]
    a750:	f949ec60 	ldr	x0, [x3, #5080]
    a754:	cb0102a1 	sub	x1, x21, x1
    a758:	eb00403f 	cmp	x1, x0, lsl #16
    a75c:	54000322 	b.cs	a7c0 <f0+0x5e0>  // b.hs, b.nlast
    a760:	d350fc22 	lsr	x2, x1, #16
    a764:	f949fc63 	ldr	x3, [x3, #5112]
    a768:	8b020842 	add	x2, x2, x2, lsl #2
    a76c:	d37df042 	lsl	x2, x2, #3
    a770:	8b020060 	add	x0, x3, x2
    a774:	f9401017 	ldr	x23, [x0, #32]
    a778:	b4000257 	cbz	x23, a7c0 <f0+0x5e0>
    a77c:	38626862 	ldrb	w2, [x3, x2]
    a780:	7100085f 	cmp	w2, #0x2
    a784:	5400ebe0 	b.eq	c500 <f0+0x2320>  // b.none
    a788:	7100045f 	cmp	w2, #0x1
    a78c:	540001a1 	b.ne	a7c0 <f0+0x5e0>  // b.any
    a790:	29430002 	ldp	w2, w0, [x0, #24]
    a794:	92403c21 	and	x1, x1, #0xffff
    a798:	9b027c21 	mul	x1, x1, x2
    a79c:	d360fc21 	lsr	x1, x1, #32
    a7a0:	eb00003f 	cmp	x1, x0
    a7a4:	540000e2 	b.cs	a7c0 <f0+0x5e0>  // b.hs, b.nlast
    a7a8:	8b0102f7 	add	x23, x23, x1
    a7ac:	394002e0 	ldrb	w0, [x23]
    a7b0:	7103fc1f 	cmp	w0, #0xff
    a7b4:	5400f6c0 	b.eq	c68c <f0+0x24ac>  // b.none
    a7b8:	52800020 	mov	w0, #0x1                   	// #1
    a7bc:	390002e0 	strb	w0, [x23]
    a7c0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7c4:	910563e1 	add	x1, sp, #0x158
    a7c8:	52800020 	mov	w0, #0x1                   	// #1
    a7cc:	a915d7e2 	stp	x2, x21, [sp, #344]
    a7d0:	97ffebdc 	bl	5740 <fwp_data.part.0.constprop.0>
    a7d4:	9117c283 	add	x3, x20, #0x5f0
    a7d8:	aa0003f5 	mov	x21, x0
    a7dc:	f949d861 	ldr	x1, [x3, #5040]
    a7e0:	f949ec60 	ldr	x0, [x3, #5080]
    a7e4:	cb0102a1 	sub	x1, x21, x1
    a7e8:	eb00403f 	cmp	x1, x0, lsl #16
    a7ec:	54000322 	b.cs	a850 <f0+0x670>  // b.hs, b.nlast
    a7f0:	d350fc22 	lsr	x2, x1, #16
    a7f4:	f949fc63 	ldr	x3, [x3, #5112]
    a7f8:	8b020842 	add	x2, x2, x2, lsl #2
    a7fc:	d37df042 	lsl	x2, x2, #3
    a800:	8b020060 	add	x0, x3, x2
    a804:	f9401017 	ldr	x23, [x0, #32]
    a808:	b4000257 	cbz	x23, a850 <f0+0x670>
    a80c:	38626862 	ldrb	w2, [x3, x2]
    a810:	7100085f 	cmp	w2, #0x2
    a814:	5400e700 	b.eq	c4f4 <f0+0x2314>  // b.none
    a818:	7100045f 	cmp	w2, #0x1
    a81c:	540001a1 	b.ne	a850 <f0+0x670>  // b.any
    a820:	29430002 	ldp	w2, w0, [x0, #24]
    a824:	92403c21 	and	x1, x1, #0xffff
    a828:	9b027c21 	mul	x1, x1, x2
    a82c:	d360fc21 	lsr	x1, x1, #32
    a830:	eb00003f 	cmp	x1, x0
    a834:	540000e2 	b.cs	a850 <f0+0x670>  // b.hs, b.nlast
    a838:	8b0102f7 	add	x23, x23, x1
    a83c:	394002e0 	ldrb	w0, [x23]
    a840:	7103fc1f 	cmp	w0, #0xff
    a844:	5400f2a0 	b.eq	c698 <f0+0x24b8>  // b.none
    a848:	52800020 	mov	w0, #0x1                   	// #1
    a84c:	390002e0 	strb	w0, [x23]
    a850:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a854:	9105a3e1 	add	x1, sp, #0x168
    a858:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a85c:	52800020 	mov	w0, #0x1                   	// #1
    a860:	a916d7e2 	stp	x2, x21, [sp, #360]
    a864:	97ffebb7 	bl	5740 <fwp_data.part.0.constprop.0>
    a868:	9117c283 	add	x3, x20, #0x5f0
    a86c:	aa0003f5 	mov	x21, x0
    a870:	f949d861 	ldr	x1, [x3, #5040]
    a874:	f949ec60 	ldr	x0, [x3, #5080]
    a878:	cb0102a1 	sub	x1, x21, x1
    a87c:	eb00403f 	cmp	x1, x0, lsl #16
    a880:	54000322 	b.cs	a8e4 <f0+0x704>  // b.hs, b.nlast
    a884:	d350fc22 	lsr	x2, x1, #16
    a888:	f949fc63 	ldr	x3, [x3, #5112]
    a88c:	8b020842 	add	x2, x2, x2, lsl #2
    a890:	d37df042 	lsl	x2, x2, #3
    a894:	8b020060 	add	x0, x3, x2
    a898:	f9401017 	ldr	x23, [x0, #32]
    a89c:	b4000257 	cbz	x23, a8e4 <f0+0x704>
    a8a0:	38626862 	ldrb	w2, [x3, x2]
    a8a4:	7100085f 	cmp	w2, #0x2
    a8a8:	5400e680 	b.eq	c578 <f0+0x2398>  // b.none
    a8ac:	7100045f 	cmp	w2, #0x1
    a8b0:	540001a1 	b.ne	a8e4 <f0+0x704>  // b.any
    a8b4:	29430002 	ldp	w2, w0, [x0, #24]
    a8b8:	92403c21 	and	x1, x1, #0xffff
    a8bc:	9b027c21 	mul	x1, x1, x2
    a8c0:	d360fc21 	lsr	x1, x1, #32
    a8c4:	eb00003f 	cmp	x1, x0
    a8c8:	540000e2 	b.cs	a8e4 <f0+0x704>  // b.hs, b.nlast
    a8cc:	8b0102f7 	add	x23, x23, x1
    a8d0:	394002e0 	ldrb	w0, [x23]
    a8d4:	7103fc1f 	cmp	w0, #0xff
    a8d8:	5400ee60 	b.eq	c6a4 <f0+0x24c4>  // b.none
    a8dc:	52800020 	mov	w0, #0x1                   	// #1
    a8e0:	390002e0 	strb	w0, [x23]
    a8e4:	9105e3e1 	add	x1, sp, #0x178
    a8e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	a917d7f7 	stp	x23, x21, [sp, #376]
    a8f4:	97ffeb93 	bl	5740 <fwp_data.part.0.constprop.0>
    a8f8:	97ffebff 	bl	58f4 <fwp_rc_fresh>
    a8fc:	aa0003e2 	mov	x2, x0
    a900:	910623e1 	add	x1, sp, #0x188
    a904:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a908:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a90c:	52800020 	mov	w0, #0x1                   	// #1
    a910:	a9188bf5 	stp	x21, x2, [sp, #392]
    a914:	97ffeb8b 	bl	5740 <fwp_data.part.0.constprop.0>
    a918:	97ffebf7 	bl	58f4 <fwp_rc_fresh>
    a91c:	aa0003e2 	mov	x2, x0
    a920:	910663e1 	add	x1, sp, #0x198
    a924:	52800020 	mov	w0, #0x1                   	// #1
    a928:	a9198bf7 	stp	x23, x2, [sp, #408]
    a92c:	97ffeb85 	bl	5740 <fwp_data.part.0.constprop.0>
    a930:	97ffebf1 	bl	58f4 <fwp_rc_fresh>
    a934:	aa0003e2 	mov	x2, x0
    a938:	9106a3e1 	add	x1, sp, #0x1a8
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a944:	97ffeb7f 	bl	5740 <fwp_data.part.0.constprop.0>
    a948:	97ffebeb 	bl	58f4 <fwp_rc_fresh>
    a94c:	aa0003e2 	mov	x2, x0
    a950:	9106e3e1 	add	x1, sp, #0x1b8
    a954:	52800020 	mov	w0, #0x1                   	// #1
    a958:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a95c:	97ffeb79 	bl	5740 <fwp_data.part.0.constprop.0>
    a960:	97ffebe5 	bl	58f4 <fwp_rc_fresh>
    a964:	aa0003e2 	mov	x2, x0
    a968:	910723e1 	add	x1, sp, #0x1c8
    a96c:	52800020 	mov	w0, #0x1                   	// #1
    a970:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a974:	97ffeb73 	bl	5740 <fwp_data.part.0.constprop.0>
    a978:	97ffebdf 	bl	58f4 <fwp_rc_fresh>
    a97c:	aa0003e2 	mov	x2, x0
    a980:	910763e1 	add	x1, sp, #0x1d8
    a984:	52800020 	mov	w0, #0x1                   	// #1
    a988:	a91d8bf7 	stp	x23, x2, [sp, #472]
    a98c:	97ffeb6d 	bl	5740 <fwp_data.part.0.constprop.0>
    a990:	97ffebd9 	bl	58f4 <fwp_rc_fresh>
    a994:	aa0003e2 	mov	x2, x0
    a998:	9107a3e1 	add	x1, sp, #0x1e8
    a99c:	52800020 	mov	w0, #0x1                   	// #1
    a9a0:	a91e8bf5 	stp	x21, x2, [sp, #488]
    a9a4:	97ffeb67 	bl	5740 <fwp_data.part.0.constprop.0>
    a9a8:	97ffebd3 	bl	58f4 <fwp_rc_fresh>
    a9ac:	aa0003e2 	mov	x2, x0
    a9b0:	9107e3e1 	add	x1, sp, #0x1f8
    a9b4:	52800020 	mov	w0, #0x1                   	// #1
    a9b8:	a91f8bf7 	stp	x23, x2, [sp, #504]
    a9bc:	97ffeb61 	bl	5740 <fwp_data.part.0.constprop.0>
    a9c0:	97ffebcd 	bl	58f4 <fwp_rc_fresh>
    a9c4:	aa0003e2 	mov	x2, x0
    a9c8:	910823e1 	add	x1, sp, #0x208
    a9cc:	52800020 	mov	w0, #0x1                   	// #1
    a9d0:	f90107f5 	str	x21, [sp, #520]
    a9d4:	f9010be2 	str	x2, [sp, #528]
    a9d8:	97ffeb5a 	bl	5740 <fwp_data.part.0.constprop.0>
    a9dc:	97ffebc6 	bl	58f4 <fwp_rc_fresh>
    a9e0:	aa0003e2 	mov	x2, x0
    a9e4:	910863e1 	add	x1, sp, #0x218
    a9e8:	52800020 	mov	w0, #0x1                   	// #1
    a9ec:	f9010ff7 	str	x23, [sp, #536]
    a9f0:	f90113e2 	str	x2, [sp, #544]
    a9f4:	97ffeb53 	bl	5740 <fwp_data.part.0.constprop.0>
    a9f8:	97ffebbf 	bl	58f4 <fwp_rc_fresh>
    a9fc:	aa0003e2 	mov	x2, x0
    aa00:	9108a3e1 	add	x1, sp, #0x228
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	f90117f5 	str	x21, [sp, #552]
    aa0c:	f9011be2 	str	x2, [sp, #560]
    aa10:	97ffeb4c 	bl	5740 <fwp_data.part.0.constprop.0>
    aa14:	97ffebb8 	bl	58f4 <fwp_rc_fresh>
    aa18:	aa0003e2 	mov	x2, x0
    aa1c:	9108e3e1 	add	x1, sp, #0x238
    aa20:	52800020 	mov	w0, #0x1                   	// #1
    aa24:	f9011ff7 	str	x23, [sp, #568]
    aa28:	f90123e2 	str	x2, [sp, #576]
    aa2c:	97ffeb45 	bl	5740 <fwp_data.part.0.constprop.0>
    aa30:	97ffebb1 	bl	58f4 <fwp_rc_fresh>
    aa34:	aa0003e2 	mov	x2, x0
    aa38:	910923e1 	add	x1, sp, #0x248
    aa3c:	52800020 	mov	w0, #0x1                   	// #1
    aa40:	f90127f5 	str	x21, [sp, #584]
    aa44:	f9012be2 	str	x2, [sp, #592]
    aa48:	97ffeb3e 	bl	5740 <fwp_data.part.0.constprop.0>
    aa4c:	97ffebaa 	bl	58f4 <fwp_rc_fresh>
    aa50:	aa0003e2 	mov	x2, x0
    aa54:	910963e1 	add	x1, sp, #0x258
    aa58:	52800020 	mov	w0, #0x1                   	// #1
    aa5c:	f9012ff7 	str	x23, [sp, #600]
    aa60:	f90133e2 	str	x2, [sp, #608]
    aa64:	97ffeb37 	bl	5740 <fwp_data.part.0.constprop.0>
    aa68:	97ffeba3 	bl	58f4 <fwp_rc_fresh>
    aa6c:	aa0003e2 	mov	x2, x0
    aa70:	9109a3e1 	add	x1, sp, #0x268
    aa74:	52800020 	mov	w0, #0x1                   	// #1
    aa78:	f90137f5 	str	x21, [sp, #616]
    aa7c:	f9013be2 	str	x2, [sp, #624]
    aa80:	97ffeb30 	bl	5740 <fwp_data.part.0.constprop.0>
    aa84:	97ffeb9c 	bl	58f4 <fwp_rc_fresh>
    aa88:	aa0003e2 	mov	x2, x0
    aa8c:	9109e3e1 	add	x1, sp, #0x278
    aa90:	52800020 	mov	w0, #0x1                   	// #1
    aa94:	f9013ff7 	str	x23, [sp, #632]
    aa98:	f90143e2 	str	x2, [sp, #640]
    aa9c:	97ffeb29 	bl	5740 <fwp_data.part.0.constprop.0>
    aaa0:	97ffeb95 	bl	58f4 <fwp_rc_fresh>
    aaa4:	aa0003e2 	mov	x2, x0
    aaa8:	910a23e1 	add	x1, sp, #0x288
    aaac:	52800020 	mov	w0, #0x1                   	// #1
    aab0:	f90147f5 	str	x21, [sp, #648]
    aab4:	f9014be2 	str	x2, [sp, #656]
    aab8:	97ffeb22 	bl	5740 <fwp_data.part.0.constprop.0>
    aabc:	9117c283 	add	x3, x20, #0x5f0
    aac0:	aa0003f5 	mov	x21, x0
    aac4:	f949d861 	ldr	x1, [x3, #5040]
    aac8:	f949ec60 	ldr	x0, [x3, #5080]
    aacc:	cb0102a1 	sub	x1, x21, x1
    aad0:	eb00403f 	cmp	x1, x0, lsl #16
    aad4:	54000322 	b.cs	ab38 <f0+0x958>  // b.hs, b.nlast
    aad8:	d350fc22 	lsr	x2, x1, #16
    aadc:	f949fc63 	ldr	x3, [x3, #5112]
    aae0:	8b020842 	add	x2, x2, x2, lsl #2
    aae4:	d37df042 	lsl	x2, x2, #3
    aae8:	8b020060 	add	x0, x3, x2
    aaec:	f9401017 	ldr	x23, [x0, #32]
    aaf0:	b4000257 	cbz	x23, ab38 <f0+0x958>
    aaf4:	38626862 	ldrb	w2, [x3, x2]
    aaf8:	7100085f 	cmp	w2, #0x2
    aafc:	5400d380 	b.eq	c56c <f0+0x238c>  // b.none
    ab00:	7100045f 	cmp	w2, #0x1
    ab04:	540001a1 	b.ne	ab38 <f0+0x958>  // b.any
    ab08:	29430002 	ldp	w2, w0, [x0, #24]
    ab0c:	92403c21 	and	x1, x1, #0xffff
    ab10:	9b027c21 	mul	x1, x1, x2
    ab14:	d360fc21 	lsr	x1, x1, #32
    ab18:	eb00003f 	cmp	x1, x0
    ab1c:	540000e2 	b.cs	ab38 <f0+0x958>  // b.hs, b.nlast
    ab20:	8b0102f7 	add	x23, x23, x1
    ab24:	394002e0 	ldrb	w0, [x23]
    ab28:	7103fc1f 	cmp	w0, #0xff
    ab2c:	5400dc20 	b.eq	c6b0 <f0+0x24d0>  // b.none
    ab30:	52800020 	mov	w0, #0x1                   	// #1
    ab34:	390002e0 	strb	w0, [x23]
    ab38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab3c:	910a63e1 	add	x1, sp, #0x298
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	f9014fe2 	str	x2, [sp, #664]
    ab48:	f90153f5 	str	x21, [sp, #672]
    ab4c:	97ffeafd 	bl	5740 <fwp_data.part.0.constprop.0>
    ab50:	9117c283 	add	x3, x20, #0x5f0
    ab54:	aa0003f5 	mov	x21, x0
    ab58:	f949d861 	ldr	x1, [x3, #5040]
    ab5c:	f949ec60 	ldr	x0, [x3, #5080]
    ab60:	cb0102a1 	sub	x1, x21, x1
    ab64:	eb00403f 	cmp	x1, x0, lsl #16
    ab68:	54000322 	b.cs	abcc <f0+0x9ec>  // b.hs, b.nlast
    ab6c:	d350fc22 	lsr	x2, x1, #16
    ab70:	f949fc63 	ldr	x3, [x3, #5112]
    ab74:	8b020842 	add	x2, x2, x2, lsl #2
    ab78:	d37df042 	lsl	x2, x2, #3
    ab7c:	8b020060 	add	x0, x3, x2
    ab80:	f9401017 	ldr	x23, [x0, #32]
    ab84:	b4000257 	cbz	x23, abcc <f0+0x9ec>
    ab88:	38626862 	ldrb	w2, [x3, x2]
    ab8c:	7100085f 	cmp	w2, #0x2
    ab90:	5400ce80 	b.eq	c560 <f0+0x2380>  // b.none
    ab94:	7100045f 	cmp	w2, #0x1
    ab98:	540001a1 	b.ne	abcc <f0+0x9ec>  // b.any
    ab9c:	29430002 	ldp	w2, w0, [x0, #24]
    aba0:	92403c21 	and	x1, x1, #0xffff
    aba4:	9b027c21 	mul	x1, x1, x2
    aba8:	d360fc21 	lsr	x1, x1, #32
    abac:	eb00003f 	cmp	x1, x0
    abb0:	540000e2 	b.cs	abcc <f0+0x9ec>  // b.hs, b.nlast
    abb4:	8b0102f7 	add	x23, x23, x1
    abb8:	394002e0 	ldrb	w0, [x23]
    abbc:	7103fc1f 	cmp	w0, #0xff
    abc0:	5400d7e0 	b.eq	c6bc <f0+0x24dc>  // b.none
    abc4:	52800020 	mov	w0, #0x1                   	// #1
    abc8:	390002e0 	strb	w0, [x23]
    abcc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    abd0:	910aa3e1 	add	x1, sp, #0x2a8
    abd4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abd8:	52800020 	mov	w0, #0x1                   	// #1
    abdc:	f90157e2 	str	x2, [sp, #680]
    abe0:	f9015bf5 	str	x21, [sp, #688]
    abe4:	97ffead7 	bl	5740 <fwp_data.part.0.constprop.0>
    abe8:	9117c283 	add	x3, x20, #0x5f0
    abec:	aa0003f5 	mov	x21, x0
    abf0:	f949d861 	ldr	x1, [x3, #5040]
    abf4:	f949ec60 	ldr	x0, [x3, #5080]
    abf8:	cb0102a1 	sub	x1, x21, x1
    abfc:	eb00403f 	cmp	x1, x0, lsl #16
    ac00:	54000322 	b.cs	ac64 <f0+0xa84>  // b.hs, b.nlast
    ac04:	d350fc22 	lsr	x2, x1, #16
    ac08:	f949fc63 	ldr	x3, [x3, #5112]
    ac0c:	8b020842 	add	x2, x2, x2, lsl #2
    ac10:	d37df042 	lsl	x2, x2, #3
    ac14:	8b020060 	add	x0, x3, x2
    ac18:	f9401017 	ldr	x23, [x0, #32]
    ac1c:	b4000257 	cbz	x23, ac64 <f0+0xa84>
    ac20:	38626862 	ldrb	w2, [x3, x2]
    ac24:	7100085f 	cmp	w2, #0x2
    ac28:	5400c960 	b.eq	c554 <f0+0x2374>  // b.none
    ac2c:	7100045f 	cmp	w2, #0x1
    ac30:	540001a1 	b.ne	ac64 <f0+0xa84>  // b.any
    ac34:	29430002 	ldp	w2, w0, [x0, #24]
    ac38:	92403c21 	and	x1, x1, #0xffff
    ac3c:	9b027c21 	mul	x1, x1, x2
    ac40:	d360fc21 	lsr	x1, x1, #32
    ac44:	eb00003f 	cmp	x1, x0
    ac48:	540000e2 	b.cs	ac64 <f0+0xa84>  // b.hs, b.nlast
    ac4c:	8b0102f7 	add	x23, x23, x1
    ac50:	394002e0 	ldrb	w0, [x23]
    ac54:	7103fc1f 	cmp	w0, #0xff
    ac58:	5400d380 	b.eq	c6c8 <f0+0x24e8>  // b.none
    ac5c:	52800020 	mov	w0, #0x1                   	// #1
    ac60:	390002e0 	strb	w0, [x23]
    ac64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac68:	910ae3e1 	add	x1, sp, #0x2b8
    ac6c:	52800020 	mov	w0, #0x1                   	// #1
    ac70:	f9015fe2 	str	x2, [sp, #696]
    ac74:	f90163f5 	str	x21, [sp, #704]
    ac78:	97ffeab2 	bl	5740 <fwp_data.part.0.constprop.0>
    ac7c:	9117c283 	add	x3, x20, #0x5f0
    ac80:	aa0003f5 	mov	x21, x0
    ac84:	f949d861 	ldr	x1, [x3, #5040]
    ac88:	f949ec60 	ldr	x0, [x3, #5080]
    ac8c:	cb0102a1 	sub	x1, x21, x1
    ac90:	eb00403f 	cmp	x1, x0, lsl #16
    ac94:	54000322 	b.cs	acf8 <f0+0xb18>  // b.hs, b.nlast
    ac98:	d350fc22 	lsr	x2, x1, #16
    ac9c:	f949fc63 	ldr	x3, [x3, #5112]
    aca0:	8b020842 	add	x2, x2, x2, lsl #2
    aca4:	d37df042 	lsl	x2, x2, #3
    aca8:	8b020060 	add	x0, x3, x2
    acac:	f9401017 	ldr	x23, [x0, #32]
    acb0:	b4000257 	cbz	x23, acf8 <f0+0xb18>
    acb4:	38626862 	ldrb	w2, [x3, x2]
    acb8:	7100085f 	cmp	w2, #0x2
    acbc:	5400c460 	b.eq	c548 <f0+0x2368>  // b.none
    acc0:	7100045f 	cmp	w2, #0x1
    acc4:	540001a1 	b.ne	acf8 <f0+0xb18>  // b.any
    acc8:	29430002 	ldp	w2, w0, [x0, #24]
    accc:	92403c21 	and	x1, x1, #0xffff
    acd0:	9b027c21 	mul	x1, x1, x2
    acd4:	d360fc21 	lsr	x1, x1, #32
    acd8:	eb00003f 	cmp	x1, x0
    acdc:	540000e2 	b.cs	acf8 <f0+0xb18>  // b.hs, b.nlast
    ace0:	8b0102f7 	add	x23, x23, x1
    ace4:	394002e0 	ldrb	w0, [x23]
    ace8:	7103fc1f 	cmp	w0, #0xff
    acec:	5400cf40 	b.eq	c6d4 <f0+0x24f4>  // b.none
    acf0:	52800020 	mov	w0, #0x1                   	// #1
    acf4:	390002e0 	strb	w0, [x23]
    acf8:	910b23e1 	add	x1, sp, #0x2c8
    acfc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ad00:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ad04:	52800020 	mov	w0, #0x1                   	// #1
    ad08:	f90167f7 	str	x23, [sp, #712]
    ad0c:	f9016bf5 	str	x21, [sp, #720]
    ad10:	97ffea8c 	bl	5740 <fwp_data.part.0.constprop.0>
    ad14:	97ffeaf8 	bl	58f4 <fwp_rc_fresh>
    ad18:	aa0003e2 	mov	x2, x0
    ad1c:	910b63e1 	add	x1, sp, #0x2d8
    ad20:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ad24:	52800020 	mov	w0, #0x1                   	// #1
    ad28:	f9016ff5 	str	x21, [sp, #728]
    ad2c:	f90173e2 	str	x2, [sp, #736]
    ad30:	97ffea84 	bl	5740 <fwp_data.part.0.constprop.0>
    ad34:	97ffeaf0 	bl	58f4 <fwp_rc_fresh>
    ad38:	aa0003e2 	mov	x2, x0
    ad3c:	910ba3e1 	add	x1, sp, #0x2e8
    ad40:	52800020 	mov	w0, #0x1                   	// #1
    ad44:	f90177f7 	str	x23, [sp, #744]
    ad48:	f9017be2 	str	x2, [sp, #752]
    ad4c:	97ffea7d 	bl	5740 <fwp_data.part.0.constprop.0>
    ad50:	97ffeae9 	bl	58f4 <fwp_rc_fresh>
    ad54:	aa0003e2 	mov	x2, x0
    ad58:	910be3e1 	add	x1, sp, #0x2f8
    ad5c:	52800020 	mov	w0, #0x1                   	// #1
    ad60:	f9017ff5 	str	x21, [sp, #760]
    ad64:	f90183e2 	str	x2, [sp, #768]
    ad68:	97ffea76 	bl	5740 <fwp_data.part.0.constprop.0>
    ad6c:	97ffeae2 	bl	58f4 <fwp_rc_fresh>
    ad70:	aa0003e2 	mov	x2, x0
    ad74:	910c23e1 	add	x1, sp, #0x308
    ad78:	52800020 	mov	w0, #0x1                   	// #1
    ad7c:	f90187f7 	str	x23, [sp, #776]
    ad80:	f9018be2 	str	x2, [sp, #784]
    ad84:	97ffea6f 	bl	5740 <fwp_data.part.0.constprop.0>
    ad88:	97ffeadb 	bl	58f4 <fwp_rc_fresh>
    ad8c:	aa0003e2 	mov	x2, x0
    ad90:	910c63e1 	add	x1, sp, #0x318
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	f9018ff5 	str	x21, [sp, #792]
    ad9c:	f90193e2 	str	x2, [sp, #800]
    ada0:	97ffea68 	bl	5740 <fwp_data.part.0.constprop.0>
    ada4:	97ffead4 	bl	58f4 <fwp_rc_fresh>
    ada8:	aa0003e2 	mov	x2, x0
    adac:	910ca3e1 	add	x1, sp, #0x328
    adb0:	52800020 	mov	w0, #0x1                   	// #1
    adb4:	f90197f7 	str	x23, [sp, #808]
    adb8:	f9019be2 	str	x2, [sp, #816]
    adbc:	97ffea61 	bl	5740 <fwp_data.part.0.constprop.0>
    adc0:	97ffeacd 	bl	58f4 <fwp_rc_fresh>
    adc4:	aa0003e2 	mov	x2, x0
    adc8:	910ce3e1 	add	x1, sp, #0x338
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	f9019ff5 	str	x21, [sp, #824]
    add4:	f901a3e2 	str	x2, [sp, #832]
    add8:	97ffea5a 	bl	5740 <fwp_data.part.0.constprop.0>
    addc:	97ffeac6 	bl	58f4 <fwp_rc_fresh>
    ade0:	aa0003e2 	mov	x2, x0
    ade4:	910d23e1 	add	x1, sp, #0x348
    ade8:	52800020 	mov	w0, #0x1                   	// #1
    adec:	f901a7f7 	str	x23, [sp, #840]
    adf0:	f901abe2 	str	x2, [sp, #848]
    adf4:	97ffea53 	bl	5740 <fwp_data.part.0.constprop.0>
    adf8:	97ffeabf 	bl	58f4 <fwp_rc_fresh>
    adfc:	aa0003e2 	mov	x2, x0
    ae00:	910d63e1 	add	x1, sp, #0x358
    ae04:	52800020 	mov	w0, #0x1                   	// #1
    ae08:	f901aff5 	str	x21, [sp, #856]
    ae0c:	f901b3e2 	str	x2, [sp, #864]
    ae10:	97ffea4c 	bl	5740 <fwp_data.part.0.constprop.0>
    ae14:	97ffeab8 	bl	58f4 <fwp_rc_fresh>
    ae18:	aa0003e2 	mov	x2, x0
    ae1c:	910da3e1 	add	x1, sp, #0x368
    ae20:	52800020 	mov	w0, #0x1                   	// #1
    ae24:	f901b7f7 	str	x23, [sp, #872]
    ae28:	f901bbe2 	str	x2, [sp, #880]
    ae2c:	97ffea45 	bl	5740 <fwp_data.part.0.constprop.0>
    ae30:	97ffeab1 	bl	58f4 <fwp_rc_fresh>
    ae34:	aa0003e2 	mov	x2, x0
    ae38:	910de3e1 	add	x1, sp, #0x378
    ae3c:	52800020 	mov	w0, #0x1                   	// #1
    ae40:	f901bff5 	str	x21, [sp, #888]
    ae44:	f901c3e2 	str	x2, [sp, #896]
    ae48:	97ffea3e 	bl	5740 <fwp_data.part.0.constprop.0>
    ae4c:	97ffeaaa 	bl	58f4 <fwp_rc_fresh>
    ae50:	aa0003e2 	mov	x2, x0
    ae54:	910e23e1 	add	x1, sp, #0x388
    ae58:	52800020 	mov	w0, #0x1                   	// #1
    ae5c:	f901c7f7 	str	x23, [sp, #904]
    ae60:	f901cbe2 	str	x2, [sp, #912]
    ae64:	97ffea37 	bl	5740 <fwp_data.part.0.constprop.0>
    ae68:	97ffeaa3 	bl	58f4 <fwp_rc_fresh>
    ae6c:	aa0003e2 	mov	x2, x0
    ae70:	910e63e1 	add	x1, sp, #0x398
    ae74:	52800020 	mov	w0, #0x1                   	// #1
    ae78:	f901cff5 	str	x21, [sp, #920]
    ae7c:	f901d3e2 	str	x2, [sp, #928]
    ae80:	97ffea30 	bl	5740 <fwp_data.part.0.constprop.0>
    ae84:	97ffea9c 	bl	58f4 <fwp_rc_fresh>
    ae88:	aa0003e2 	mov	x2, x0
    ae8c:	910ea3e1 	add	x1, sp, #0x3a8
    ae90:	52800020 	mov	w0, #0x1                   	// #1
    ae94:	f901d7f7 	str	x23, [sp, #936]
    ae98:	f901dbe2 	str	x2, [sp, #944]
    ae9c:	97ffea29 	bl	5740 <fwp_data.part.0.constprop.0>
    aea0:	97ffea95 	bl	58f4 <fwp_rc_fresh>
    aea4:	aa0003e2 	mov	x2, x0
    aea8:	910ee3e1 	add	x1, sp, #0x3b8
    aeac:	52800020 	mov	w0, #0x1                   	// #1
    aeb0:	f901dff5 	str	x21, [sp, #952]
    aeb4:	f901e3e2 	str	x2, [sp, #960]
    aeb8:	97ffea22 	bl	5740 <fwp_data.part.0.constprop.0>
    aebc:	97ffea8e 	bl	58f4 <fwp_rc_fresh>
    aec0:	aa0003e2 	mov	x2, x0
    aec4:	910f23e1 	add	x1, sp, #0x3c8
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	f901e7f7 	str	x23, [sp, #968]
    aed0:	f901ebe2 	str	x2, [sp, #976]
    aed4:	97ffea1b 	bl	5740 <fwp_data.part.0.constprop.0>
    aed8:	97ffea87 	bl	58f4 <fwp_rc_fresh>
    aedc:	aa0003e2 	mov	x2, x0
    aee0:	910f63e1 	add	x1, sp, #0x3d8
    aee4:	52800020 	mov	w0, #0x1                   	// #1
    aee8:	f901eff5 	str	x21, [sp, #984]
    aeec:	f901f3e2 	str	x2, [sp, #992]
    aef0:	97ffea14 	bl	5740 <fwp_data.part.0.constprop.0>
    aef4:	97ffea80 	bl	58f4 <fwp_rc_fresh>
    aef8:	aa0003e2 	mov	x2, x0
    aefc:	910fa3e1 	add	x1, sp, #0x3e8
    af00:	52800020 	mov	w0, #0x1                   	// #1
    af04:	f901f7f7 	str	x23, [sp, #1000]
    af08:	f901fbe2 	str	x2, [sp, #1008]
    af0c:	97ffea0d 	bl	5740 <fwp_data.part.0.constprop.0>
    af10:	97ffea79 	bl	58f4 <fwp_rc_fresh>
    af14:	aa0003e2 	mov	x2, x0
    af18:	910fe3e1 	add	x1, sp, #0x3f8
    af1c:	52800020 	mov	w0, #0x1                   	// #1
    af20:	f901fff5 	str	x21, [sp, #1016]
    af24:	f90203e2 	str	x2, [sp, #1024]
    af28:	97ffea06 	bl	5740 <fwp_data.part.0.constprop.0>
    af2c:	97ffea72 	bl	58f4 <fwp_rc_fresh>
    af30:	aa0003e2 	mov	x2, x0
    af34:	911023e1 	add	x1, sp, #0x408
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f90207f7 	str	x23, [sp, #1032]
    af40:	f9020be2 	str	x2, [sp, #1040]
    af44:	97ffe9ff 	bl	5740 <fwp_data.part.0.constprop.0>
    af48:	97ffea6b 	bl	58f4 <fwp_rc_fresh>
    af4c:	aa0003e2 	mov	x2, x0
    af50:	911063e1 	add	x1, sp, #0x418
    af54:	52800020 	mov	w0, #0x1                   	// #1
    af58:	f9020ff5 	str	x21, [sp, #1048]
    af5c:	f90213e2 	str	x2, [sp, #1056]
    af60:	97ffe9f8 	bl	5740 <fwp_data.part.0.constprop.0>
    af64:	9117c283 	add	x3, x20, #0x5f0
    af68:	aa0003f5 	mov	x21, x0
    af6c:	f949d861 	ldr	x1, [x3, #5040]
    af70:	f949ec60 	ldr	x0, [x3, #5080]
    af74:	cb0102a1 	sub	x1, x21, x1
    af78:	eb00403f 	cmp	x1, x0, lsl #16
    af7c:	54000322 	b.cs	afe0 <f0+0xe00>  // b.hs, b.nlast
    af80:	d350fc22 	lsr	x2, x1, #16
    af84:	f949fc63 	ldr	x3, [x3, #5112]
    af88:	8b020842 	add	x2, x2, x2, lsl #2
    af8c:	d37df042 	lsl	x2, x2, #3
    af90:	8b020060 	add	x0, x3, x2
    af94:	f9401017 	ldr	x23, [x0, #32]
    af98:	b4000257 	cbz	x23, afe0 <f0+0xe00>
    af9c:	38626862 	ldrb	w2, [x3, x2]
    afa0:	7100085f 	cmp	w2, #0x2
    afa4:	5400acc0 	b.eq	c53c <f0+0x235c>  // b.none
    afa8:	7100045f 	cmp	w2, #0x1
    afac:	540001a1 	b.ne	afe0 <f0+0xe00>  // b.any
    afb0:	29430002 	ldp	w2, w0, [x0, #24]
    afb4:	92403c21 	and	x1, x1, #0xffff
    afb8:	9b027c21 	mul	x1, x1, x2
    afbc:	d360fc21 	lsr	x1, x1, #32
    afc0:	eb00003f 	cmp	x1, x0
    afc4:	540000e2 	b.cs	afe0 <f0+0xe00>  // b.hs, b.nlast
    afc8:	8b0102f7 	add	x23, x23, x1
    afcc:	394002e0 	ldrb	w0, [x23]
    afd0:	7103fc1f 	cmp	w0, #0xff
    afd4:	5400b860 	b.eq	c6e0 <f0+0x2500>  // b.none
    afd8:	52800020 	mov	w0, #0x1                   	// #1
    afdc:	390002e0 	strb	w0, [x23]
    afe0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    afe4:	9110a3e1 	add	x1, sp, #0x428
    afe8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f90217e2 	str	x2, [sp, #1064]
    aff4:	f9021bf5 	str	x21, [sp, #1072]
    aff8:	97ffe9d2 	bl	5740 <fwp_data.part.0.constprop.0>
    affc:	97ffea3e 	bl	58f4 <fwp_rc_fresh>
    b000:	aa0003e2 	mov	x2, x0
    b004:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b008:	9110e3e1 	add	x1, sp, #0x438
    b00c:	52800020 	mov	w0, #0x1                   	// #1
    b010:	f9021fe3 	str	x3, [sp, #1080]
    b014:	f90223e2 	str	x2, [sp, #1088]
    b018:	97ffe9ca 	bl	5740 <fwp_data.part.0.constprop.0>
    b01c:	9117c283 	add	x3, x20, #0x5f0
    b020:	aa0003f5 	mov	x21, x0
    b024:	f949d861 	ldr	x1, [x3, #5040]
    b028:	f949ec60 	ldr	x0, [x3, #5080]
    b02c:	cb0102a1 	sub	x1, x21, x1
    b030:	eb00403f 	cmp	x1, x0, lsl #16
    b034:	54000322 	b.cs	b098 <f0+0xeb8>  // b.hs, b.nlast
    b038:	d350fc22 	lsr	x2, x1, #16
    b03c:	f949fc63 	ldr	x3, [x3, #5112]
    b040:	8b020842 	add	x2, x2, x2, lsl #2
    b044:	d37df042 	lsl	x2, x2, #3
    b048:	8b020060 	add	x0, x3, x2
    b04c:	f9401017 	ldr	x23, [x0, #32]
    b050:	b4000257 	cbz	x23, b098 <f0+0xeb8>
    b054:	38626862 	ldrb	w2, [x3, x2]
    b058:	7100085f 	cmp	w2, #0x2
    b05c:	5400a6a0 	b.eq	c530 <f0+0x2350>  // b.none
    b060:	7100045f 	cmp	w2, #0x1
    b064:	540001a1 	b.ne	b098 <f0+0xeb8>  // b.any
    b068:	29430002 	ldp	w2, w0, [x0, #24]
    b06c:	92403c21 	and	x1, x1, #0xffff
    b070:	9b027c21 	mul	x1, x1, x2
    b074:	d360fc21 	lsr	x1, x1, #32
    b078:	eb00003f 	cmp	x1, x0
    b07c:	540000e2 	b.cs	b098 <f0+0xeb8>  // b.hs, b.nlast
    b080:	8b0102f7 	add	x23, x23, x1
    b084:	394002e0 	ldrb	w0, [x23]
    b088:	7103fc1f 	cmp	w0, #0xff
    b08c:	5400b300 	b.eq	c6ec <f0+0x250c>  // b.none
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	390002e0 	strb	w0, [x23]
    b098:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b09c:	911123e1 	add	x1, sp, #0x448
    b0a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f90227e2 	str	x2, [sp, #1096]
    b0ac:	f9022bf5 	str	x21, [sp, #1104]
    b0b0:	97ffe9a4 	bl	5740 <fwp_data.part.0.constprop.0>
    b0b4:	9117c283 	add	x3, x20, #0x5f0
    b0b8:	aa0003f5 	mov	x21, x0
    b0bc:	f949d861 	ldr	x1, [x3, #5040]
    b0c0:	f949ec60 	ldr	x0, [x3, #5080]
    b0c4:	cb0102a1 	sub	x1, x21, x1
    b0c8:	eb00403f 	cmp	x1, x0, lsl #16
    b0cc:	54000322 	b.cs	b130 <f0+0xf50>  // b.hs, b.nlast
    b0d0:	d350fc22 	lsr	x2, x1, #16
    b0d4:	f949fc63 	ldr	x3, [x3, #5112]
    b0d8:	8b020842 	add	x2, x2, x2, lsl #2
    b0dc:	d37df042 	lsl	x2, x2, #3
    b0e0:	8b020060 	add	x0, x3, x2
    b0e4:	f9401017 	ldr	x23, [x0, #32]
    b0e8:	b4000257 	cbz	x23, b130 <f0+0xf50>
    b0ec:	38626862 	ldrb	w2, [x3, x2]
    b0f0:	7100085f 	cmp	w2, #0x2
    b0f4:	5400a180 	b.eq	c524 <f0+0x2344>  // b.none
    b0f8:	7100045f 	cmp	w2, #0x1
    b0fc:	540001a1 	b.ne	b130 <f0+0xf50>  // b.any
    b100:	29430002 	ldp	w2, w0, [x0, #24]
    b104:	92403c21 	and	x1, x1, #0xffff
    b108:	9b027c21 	mul	x1, x1, x2
    b10c:	d360fc21 	lsr	x1, x1, #32
    b110:	eb00003f 	cmp	x1, x0
    b114:	540000e2 	b.cs	b130 <f0+0xf50>  // b.hs, b.nlast
    b118:	8b0102f7 	add	x23, x23, x1
    b11c:	394002e0 	ldrb	w0, [x23]
    b120:	7103fc1f 	cmp	w0, #0xff
    b124:	5400aea0 	b.eq	c6f8 <f0+0x2518>  // b.none
    b128:	52800020 	mov	w0, #0x1                   	// #1
    b12c:	390002e0 	strb	w0, [x23]
    b130:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b134:	911163e1 	add	x1, sp, #0x458
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	f9022fe2 	str	x2, [sp, #1112]
    b140:	f90233f5 	str	x21, [sp, #1120]
    b144:	97ffe97f 	bl	5740 <fwp_data.part.0.constprop.0>
    b148:	9117c283 	add	x3, x20, #0x5f0
    b14c:	aa0003f5 	mov	x21, x0
    b150:	f949d861 	ldr	x1, [x3, #5040]
    b154:	f949ec60 	ldr	x0, [x3, #5080]
    b158:	cb0102a1 	sub	x1, x21, x1
    b15c:	eb00403f 	cmp	x1, x0, lsl #16
    b160:	54000322 	b.cs	b1c4 <f0+0xfe4>  // b.hs, b.nlast
    b164:	d350fc22 	lsr	x2, x1, #16
    b168:	f949fc63 	ldr	x3, [x3, #5112]
    b16c:	8b020842 	add	x2, x2, x2, lsl #2
    b170:	d37df042 	lsl	x2, x2, #3
    b174:	8b020060 	add	x0, x3, x2
    b178:	f9401017 	ldr	x23, [x0, #32]
    b17c:	b4000257 	cbz	x23, b1c4 <f0+0xfe4>
    b180:	38626862 	ldrb	w2, [x3, x2]
    b184:	7100085f 	cmp	w2, #0x2
    b188:	540099e0 	b.eq	c4c4 <f0+0x22e4>  // b.none
    b18c:	7100045f 	cmp	w2, #0x1
    b190:	540001a1 	b.ne	b1c4 <f0+0xfe4>  // b.any
    b194:	29430002 	ldp	w2, w0, [x0, #24]
    b198:	92403c21 	and	x1, x1, #0xffff
    b19c:	9b027c21 	mul	x1, x1, x2
    b1a0:	d360fc21 	lsr	x1, x1, #32
    b1a4:	eb00003f 	cmp	x1, x0
    b1a8:	540000e2 	b.cs	b1c4 <f0+0xfe4>  // b.hs, b.nlast
    b1ac:	8b0102f7 	add	x23, x23, x1
    b1b0:	394002e0 	ldrb	w0, [x23]
    b1b4:	7103fc1f 	cmp	w0, #0xff
    b1b8:	5400aa60 	b.eq	c704 <f0+0x2524>  // b.none
    b1bc:	52800020 	mov	w0, #0x1                   	// #1
    b1c0:	390002e0 	strb	w0, [x23]
    b1c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b1c8:	9111a3e1 	add	x1, sp, #0x468
    b1cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b1d0:	52800020 	mov	w0, #0x1                   	// #1
    b1d4:	f90237e2 	str	x2, [sp, #1128]
    b1d8:	f9023bf5 	str	x21, [sp, #1136]
    b1dc:	97ffe959 	bl	5740 <fwp_data.part.0.constprop.0>
    b1e0:	97ffe9c5 	bl	58f4 <fwp_rc_fresh>
    b1e4:	aa0003e2 	mov	x2, x0
    b1e8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b1ec:	9111e3e1 	add	x1, sp, #0x478
    b1f0:	52800020 	mov	w0, #0x1                   	// #1
    b1f4:	f9023fe3 	str	x3, [sp, #1144]
    b1f8:	f90243e2 	str	x2, [sp, #1152]
    b1fc:	97ffe951 	bl	5740 <fwp_data.part.0.constprop.0>
    b200:	9117c283 	add	x3, x20, #0x5f0
    b204:	aa0003f5 	mov	x21, x0
    b208:	f949d861 	ldr	x1, [x3, #5040]
    b20c:	f949ec60 	ldr	x0, [x3, #5080]
    b210:	cb0102a1 	sub	x1, x21, x1
    b214:	eb00403f 	cmp	x1, x0, lsl #16
    b218:	54000322 	b.cs	b27c <f0+0x109c>  // b.hs, b.nlast
    b21c:	d350fc22 	lsr	x2, x1, #16
    b220:	f949fc63 	ldr	x3, [x3, #5112]
    b224:	8b020842 	add	x2, x2, x2, lsl #2
    b228:	d37df042 	lsl	x2, x2, #3
    b22c:	8b020060 	add	x0, x3, x2
    b230:	f9401017 	ldr	x23, [x0, #32]
    b234:	b4000257 	cbz	x23, b27c <f0+0x109c>
    b238:	38626862 	ldrb	w2, [x3, x2]
    b23c:	7100085f 	cmp	w2, #0x2
    b240:	540093c0 	b.eq	c4b8 <f0+0x22d8>  // b.none
    b244:	7100045f 	cmp	w2, #0x1
    b248:	540001a1 	b.ne	b27c <f0+0x109c>  // b.any
    b24c:	29430002 	ldp	w2, w0, [x0, #24]
    b250:	92403c21 	and	x1, x1, #0xffff
    b254:	9b027c21 	mul	x1, x1, x2
    b258:	d360fc21 	lsr	x1, x1, #32
    b25c:	eb00003f 	cmp	x1, x0
    b260:	540000e2 	b.cs	b27c <f0+0x109c>  // b.hs, b.nlast
    b264:	8b0102f7 	add	x23, x23, x1
    b268:	394002e0 	ldrb	w0, [x23]
    b26c:	7103fc1f 	cmp	w0, #0xff
    b270:	5400a500 	b.eq	c710 <f0+0x2530>  // b.none
    b274:	52800020 	mov	w0, #0x1                   	// #1
    b278:	390002e0 	strb	w0, [x23]
    b27c:	911223e1 	add	x1, sp, #0x488
    b280:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b284:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b288:	52800020 	mov	w0, #0x1                   	// #1
    b28c:	f90247f7 	str	x23, [sp, #1160]
    b290:	f9024bf5 	str	x21, [sp, #1168]
    b294:	97ffe92b 	bl	5740 <fwp_data.part.0.constprop.0>
    b298:	97ffe997 	bl	58f4 <fwp_rc_fresh>
    b29c:	aa0003e2 	mov	x2, x0
    b2a0:	911263e1 	add	x1, sp, #0x498
    b2a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b2a8:	52800020 	mov	w0, #0x1                   	// #1
    b2ac:	f9024ff5 	str	x21, [sp, #1176]
    b2b0:	f90253e2 	str	x2, [sp, #1184]
    b2b4:	97ffe923 	bl	5740 <fwp_data.part.0.constprop.0>
    b2b8:	97ffe98f 	bl	58f4 <fwp_rc_fresh>
    b2bc:	aa0003e2 	mov	x2, x0
    b2c0:	9112a3e1 	add	x1, sp, #0x4a8
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	f90257f7 	str	x23, [sp, #1192]
    b2cc:	f9025be2 	str	x2, [sp, #1200]
    b2d0:	97ffe91c 	bl	5740 <fwp_data.part.0.constprop.0>
    b2d4:	97ffe988 	bl	58f4 <fwp_rc_fresh>
    b2d8:	aa0003e2 	mov	x2, x0
    b2dc:	9112e3e1 	add	x1, sp, #0x4b8
    b2e0:	52800020 	mov	w0, #0x1                   	// #1
    b2e4:	f9025ff5 	str	x21, [sp, #1208]
    b2e8:	f90263e2 	str	x2, [sp, #1216]
    b2ec:	97ffe915 	bl	5740 <fwp_data.part.0.constprop.0>
    b2f0:	97ffe981 	bl	58f4 <fwp_rc_fresh>
    b2f4:	aa0003e2 	mov	x2, x0
    b2f8:	911323e1 	add	x1, sp, #0x4c8
    b2fc:	52800020 	mov	w0, #0x1                   	// #1
    b300:	f90267f7 	str	x23, [sp, #1224]
    b304:	f9026be2 	str	x2, [sp, #1232]
    b308:	97ffe90e 	bl	5740 <fwp_data.part.0.constprop.0>
    b30c:	9117c283 	add	x3, x20, #0x5f0
    b310:	aa0003f5 	mov	x21, x0
    b314:	f949d861 	ldr	x1, [x3, #5040]
    b318:	f949ec60 	ldr	x0, [x3, #5080]
    b31c:	cb0102a1 	sub	x1, x21, x1
    b320:	eb00403f 	cmp	x1, x0, lsl #16
    b324:	54000322 	b.cs	b388 <f0+0x11a8>  // b.hs, b.nlast
    b328:	d350fc22 	lsr	x2, x1, #16
    b32c:	f949fc63 	ldr	x3, [x3, #5112]
    b330:	8b020842 	add	x2, x2, x2, lsl #2
    b334:	d37df042 	lsl	x2, x2, #3
    b338:	8b020060 	add	x0, x3, x2
    b33c:	f9401017 	ldr	x23, [x0, #32]
    b340:	b4000257 	cbz	x23, b388 <f0+0x11a8>
    b344:	38626862 	ldrb	w2, [x3, x2]
    b348:	7100085f 	cmp	w2, #0x2
    b34c:	54008b00 	b.eq	c4ac <f0+0x22cc>  // b.none
    b350:	7100045f 	cmp	w2, #0x1
    b354:	540001a1 	b.ne	b388 <f0+0x11a8>  // b.any
    b358:	29430002 	ldp	w2, w0, [x0, #24]
    b35c:	92403c21 	and	x1, x1, #0xffff
    b360:	9b027c21 	mul	x1, x1, x2
    b364:	d360fc21 	lsr	x1, x1, #32
    b368:	eb00003f 	cmp	x1, x0
    b36c:	540000e2 	b.cs	b388 <f0+0x11a8>  // b.hs, b.nlast
    b370:	8b0102f7 	add	x23, x23, x1
    b374:	394002e0 	ldrb	w0, [x23]
    b378:	7103fc1f 	cmp	w0, #0xff
    b37c:	54009d00 	b.eq	c71c <f0+0x253c>  // b.none
    b380:	52800020 	mov	w0, #0x1                   	// #1
    b384:	390002e0 	strb	w0, [x23]
    b388:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b38c:	911363e1 	add	x1, sp, #0x4d8
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f9026fe2 	str	x2, [sp, #1240]
    b398:	f90273f5 	str	x21, [sp, #1248]
    b39c:	97ffe8e9 	bl	5740 <fwp_data.part.0.constprop.0>
    b3a0:	9117c283 	add	x3, x20, #0x5f0
    b3a4:	aa0003f5 	mov	x21, x0
    b3a8:	f949d861 	ldr	x1, [x3, #5040]
    b3ac:	f949ec60 	ldr	x0, [x3, #5080]
    b3b0:	cb0102a1 	sub	x1, x21, x1
    b3b4:	eb00403f 	cmp	x1, x0, lsl #16
    b3b8:	54000322 	b.cs	b41c <f0+0x123c>  // b.hs, b.nlast
    b3bc:	d350fc22 	lsr	x2, x1, #16
    b3c0:	f949fc63 	ldr	x3, [x3, #5112]
    b3c4:	8b020842 	add	x2, x2, x2, lsl #2
    b3c8:	d37df042 	lsl	x2, x2, #3
    b3cc:	8b020060 	add	x0, x3, x2
    b3d0:	f9401017 	ldr	x23, [x0, #32]
    b3d4:	b4000257 	cbz	x23, b41c <f0+0x123c>
    b3d8:	38626862 	ldrb	w2, [x3, x2]
    b3dc:	7100085f 	cmp	w2, #0x2
    b3e0:	54008600 	b.eq	c4a0 <f0+0x22c0>  // b.none
    b3e4:	7100045f 	cmp	w2, #0x1
    b3e8:	540001a1 	b.ne	b41c <f0+0x123c>  // b.any
    b3ec:	29430002 	ldp	w2, w0, [x0, #24]
    b3f0:	92403c21 	and	x1, x1, #0xffff
    b3f4:	9b027c21 	mul	x1, x1, x2
    b3f8:	d360fc21 	lsr	x1, x1, #32
    b3fc:	eb00003f 	cmp	x1, x0
    b400:	540000e2 	b.cs	b41c <f0+0x123c>  // b.hs, b.nlast
    b404:	8b0102f7 	add	x23, x23, x1
    b408:	394002e0 	ldrb	w0, [x23]
    b40c:	7103fc1f 	cmp	w0, #0xff
    b410:	540098c0 	b.eq	c728 <f0+0x2548>  // b.none
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	390002e0 	strb	w0, [x23]
    b41c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b420:	9113a3e1 	add	x1, sp, #0x4e8
    b424:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	f90277e2 	str	x2, [sp, #1256]
    b430:	f9027bf5 	str	x21, [sp, #1264]
    b434:	97ffe8c3 	bl	5740 <fwp_data.part.0.constprop.0>
    b438:	97ffe92f 	bl	58f4 <fwp_rc_fresh>
    b43c:	aa0003e2 	mov	x2, x0
    b440:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b444:	9113e3e1 	add	x1, sp, #0x4f8
    b448:	52800020 	mov	w0, #0x1                   	// #1
    b44c:	f9027fe3 	str	x3, [sp, #1272]
    b450:	f90283e2 	str	x2, [sp, #1280]
    b454:	97ffe8bb 	bl	5740 <fwp_data.part.0.constprop.0>
    b458:	9117c283 	add	x3, x20, #0x5f0
    b45c:	aa0003f5 	mov	x21, x0
    b460:	f949d861 	ldr	x1, [x3, #5040]
    b464:	f949ec60 	ldr	x0, [x3, #5080]
    b468:	cb0102a1 	sub	x1, x21, x1
    b46c:	eb00403f 	cmp	x1, x0, lsl #16
    b470:	54000322 	b.cs	b4d4 <f0+0x12f4>  // b.hs, b.nlast
    b474:	d350fc22 	lsr	x2, x1, #16
    b478:	f949fc63 	ldr	x3, [x3, #5112]
    b47c:	8b020842 	add	x2, x2, x2, lsl #2
    b480:	d37df042 	lsl	x2, x2, #3
    b484:	8b020060 	add	x0, x3, x2
    b488:	f9401017 	ldr	x23, [x0, #32]
    b48c:	b4000257 	cbz	x23, b4d4 <f0+0x12f4>
    b490:	38626862 	ldrb	w2, [x3, x2]
    b494:	7100085f 	cmp	w2, #0x2
    b498:	54007fe0 	b.eq	c494 <f0+0x22b4>  // b.none
    b49c:	7100045f 	cmp	w2, #0x1
    b4a0:	540001a1 	b.ne	b4d4 <f0+0x12f4>  // b.any
    b4a4:	29430002 	ldp	w2, w0, [x0, #24]
    b4a8:	92403c21 	and	x1, x1, #0xffff
    b4ac:	9b027c21 	mul	x1, x1, x2
    b4b0:	d360fc21 	lsr	x1, x1, #32
    b4b4:	eb00003f 	cmp	x1, x0
    b4b8:	540000e2 	b.cs	b4d4 <f0+0x12f4>  // b.hs, b.nlast
    b4bc:	8b0102f7 	add	x23, x23, x1
    b4c0:	394002e0 	ldrb	w0, [x23]
    b4c4:	7103fc1f 	cmp	w0, #0xff
    b4c8:	54009360 	b.eq	c734 <f0+0x2554>  // b.none
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	390002e0 	strb	w0, [x23]
    b4d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b4d8:	911423e1 	add	x1, sp, #0x508
    b4dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b4e0:	52800020 	mov	w0, #0x1                   	// #1
    b4e4:	f90287e2 	str	x2, [sp, #1288]
    b4e8:	f9028bf5 	str	x21, [sp, #1296]
    b4ec:	97ffe895 	bl	5740 <fwp_data.part.0.constprop.0>
    b4f0:	97ffe901 	bl	58f4 <fwp_rc_fresh>
    b4f4:	aa0003e2 	mov	x2, x0
    b4f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4fc:	911463e1 	add	x1, sp, #0x518
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	f9028fe3 	str	x3, [sp, #1304]
    b508:	f90293e2 	str	x2, [sp, #1312]
    b50c:	97ffe88d 	bl	5740 <fwp_data.part.0.constprop.0>
    b510:	9117c283 	add	x3, x20, #0x5f0
    b514:	aa0003f5 	mov	x21, x0
    b518:	f949d861 	ldr	x1, [x3, #5040]
    b51c:	f949ec60 	ldr	x0, [x3, #5080]
    b520:	cb0102a1 	sub	x1, x21, x1
    b524:	eb00403f 	cmp	x1, x0, lsl #16
    b528:	54000322 	b.cs	b58c <f0+0x13ac>  // b.hs, b.nlast
    b52c:	d350fc22 	lsr	x2, x1, #16
    b530:	f949fc63 	ldr	x3, [x3, #5112]
    b534:	8b020842 	add	x2, x2, x2, lsl #2
    b538:	d37df042 	lsl	x2, x2, #3
    b53c:	8b020060 	add	x0, x3, x2
    b540:	f9401017 	ldr	x23, [x0, #32]
    b544:	b4000257 	cbz	x23, b58c <f0+0x13ac>
    b548:	38626862 	ldrb	w2, [x3, x2]
    b54c:	7100085f 	cmp	w2, #0x2
    b550:	540079c0 	b.eq	c488 <f0+0x22a8>  // b.none
    b554:	7100045f 	cmp	w2, #0x1
    b558:	540001a1 	b.ne	b58c <f0+0x13ac>  // b.any
    b55c:	29430002 	ldp	w2, w0, [x0, #24]
    b560:	92403c21 	and	x1, x1, #0xffff
    b564:	9b027c21 	mul	x1, x1, x2
    b568:	d360fc21 	lsr	x1, x1, #32
    b56c:	eb00003f 	cmp	x1, x0
    b570:	540000e2 	b.cs	b58c <f0+0x13ac>  // b.hs, b.nlast
    b574:	8b0102f7 	add	x23, x23, x1
    b578:	394002e0 	ldrb	w0, [x23]
    b57c:	7103fc1f 	cmp	w0, #0xff
    b580:	54008e00 	b.eq	c740 <f0+0x2560>  // b.none
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	390002e0 	strb	w0, [x23]
    b58c:	9114a3e1 	add	x1, sp, #0x528
    b590:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b594:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b598:	52800020 	mov	w0, #0x1                   	// #1
    b59c:	f90297f7 	str	x23, [sp, #1320]
    b5a0:	f9029bf5 	str	x21, [sp, #1328]
    b5a4:	97ffe867 	bl	5740 <fwp_data.part.0.constprop.0>
    b5a8:	97ffe8d3 	bl	58f4 <fwp_rc_fresh>
    b5ac:	aa0003e2 	mov	x2, x0
    b5b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b5b4:	9114e3e1 	add	x1, sp, #0x538
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	f9029fe3 	str	x3, [sp, #1336]
    b5c0:	f902a3e2 	str	x2, [sp, #1344]
    b5c4:	97ffe85f 	bl	5740 <fwp_data.part.0.constprop.0>
    b5c8:	97ffe8cb 	bl	58f4 <fwp_rc_fresh>
    b5cc:	aa0003e2 	mov	x2, x0
    b5d0:	911523e1 	add	x1, sp, #0x548
    b5d4:	52800020 	mov	w0, #0x1                   	// #1
    b5d8:	f902a7f7 	str	x23, [sp, #1352]
    b5dc:	f902abe2 	str	x2, [sp, #1360]
    b5e0:	97ffe858 	bl	5740 <fwp_data.part.0.constprop.0>
    b5e4:	9117c283 	add	x3, x20, #0x5f0
    b5e8:	aa0003f5 	mov	x21, x0
    b5ec:	f949d861 	ldr	x1, [x3, #5040]
    b5f0:	f949ec60 	ldr	x0, [x3, #5080]
    b5f4:	cb0102a1 	sub	x1, x21, x1
    b5f8:	eb00403f 	cmp	x1, x0, lsl #16
    b5fc:	54000322 	b.cs	b660 <f0+0x1480>  // b.hs, b.nlast
    b600:	d350fc22 	lsr	x2, x1, #16
    b604:	f949fc63 	ldr	x3, [x3, #5112]
    b608:	8b020842 	add	x2, x2, x2, lsl #2
    b60c:	d37df042 	lsl	x2, x2, #3
    b610:	8b020060 	add	x0, x3, x2
    b614:	f9401017 	ldr	x23, [x0, #32]
    b618:	b4000257 	cbz	x23, b660 <f0+0x1480>
    b61c:	38626862 	ldrb	w2, [x3, x2]
    b620:	7100085f 	cmp	w2, #0x2
    b624:	540072c0 	b.eq	c47c <f0+0x229c>  // b.none
    b628:	7100045f 	cmp	w2, #0x1
    b62c:	540001a1 	b.ne	b660 <f0+0x1480>  // b.any
    b630:	29430002 	ldp	w2, w0, [x0, #24]
    b634:	92403c21 	and	x1, x1, #0xffff
    b638:	9b027c21 	mul	x1, x1, x2
    b63c:	d360fc21 	lsr	x1, x1, #32
    b640:	eb00003f 	cmp	x1, x0
    b644:	540000e2 	b.cs	b660 <f0+0x1480>  // b.hs, b.nlast
    b648:	8b0102f7 	add	x23, x23, x1
    b64c:	394002e0 	ldrb	w0, [x23]
    b650:	7103fc1f 	cmp	w0, #0xff
    b654:	540087c0 	b.eq	c74c <f0+0x256c>  // b.none
    b658:	52800020 	mov	w0, #0x1                   	// #1
    b65c:	390002e0 	strb	w0, [x23]
    b660:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b664:	911563e1 	add	x1, sp, #0x558
    b668:	52800020 	mov	w0, #0x1                   	// #1
    b66c:	f902afe2 	str	x2, [sp, #1368]
    b670:	f902b3f5 	str	x21, [sp, #1376]
    b674:	97ffe833 	bl	5740 <fwp_data.part.0.constprop.0>
    b678:	9117c283 	add	x3, x20, #0x5f0
    b67c:	aa0003f5 	mov	x21, x0
    b680:	f949d861 	ldr	x1, [x3, #5040]
    b684:	f949ec60 	ldr	x0, [x3, #5080]
    b688:	cb0102a1 	sub	x1, x21, x1
    b68c:	eb00403f 	cmp	x1, x0, lsl #16
    b690:	54000322 	b.cs	b6f4 <f0+0x1514>  // b.hs, b.nlast
    b694:	d350fc22 	lsr	x2, x1, #16
    b698:	f949fc63 	ldr	x3, [x3, #5112]
    b69c:	8b020842 	add	x2, x2, x2, lsl #2
    b6a0:	d37df042 	lsl	x2, x2, #3
    b6a4:	8b020060 	add	x0, x3, x2
    b6a8:	f9401017 	ldr	x23, [x0, #32]
    b6ac:	b4000257 	cbz	x23, b6f4 <f0+0x1514>
    b6b0:	38626862 	ldrb	w2, [x3, x2]
    b6b4:	7100085f 	cmp	w2, #0x2
    b6b8:	54006dc0 	b.eq	c470 <f0+0x2290>  // b.none
    b6bc:	7100045f 	cmp	w2, #0x1
    b6c0:	540001a1 	b.ne	b6f4 <f0+0x1514>  // b.any
    b6c4:	29430002 	ldp	w2, w0, [x0, #24]
    b6c8:	92403c21 	and	x1, x1, #0xffff
    b6cc:	9b027c21 	mul	x1, x1, x2
    b6d0:	d360fc21 	lsr	x1, x1, #32
    b6d4:	eb00003f 	cmp	x1, x0
    b6d8:	540000e2 	b.cs	b6f4 <f0+0x1514>  // b.hs, b.nlast
    b6dc:	8b0102f7 	add	x23, x23, x1
    b6e0:	394002e0 	ldrb	w0, [x23]
    b6e4:	7103fc1f 	cmp	w0, #0xff
    b6e8:	54008380 	b.eq	c758 <f0+0x2578>  // b.none
    b6ec:	52800020 	mov	w0, #0x1                   	// #1
    b6f0:	390002e0 	strb	w0, [x23]
    b6f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6f8:	9115a3e1 	add	x1, sp, #0x568
    b6fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	f902b7e2 	str	x2, [sp, #1384]
    b708:	f902bbf5 	str	x21, [sp, #1392]
    b70c:	97ffe80d 	bl	5740 <fwp_data.part.0.constprop.0>
    b710:	97ffe879 	bl	58f4 <fwp_rc_fresh>
    b714:	aa0003e2 	mov	x2, x0
    b718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b71c:	9115e3e1 	add	x1, sp, #0x578
    b720:	52800020 	mov	w0, #0x1                   	// #1
    b724:	f902bfe3 	str	x3, [sp, #1400]
    b728:	f902c3e2 	str	x2, [sp, #1408]
    b72c:	97ffe805 	bl	5740 <fwp_data.part.0.constprop.0>
    b730:	9117c283 	add	x3, x20, #0x5f0
    b734:	aa0003f5 	mov	x21, x0
    b738:	f949d861 	ldr	x1, [x3, #5040]
    b73c:	f949ec60 	ldr	x0, [x3, #5080]
    b740:	cb0102a1 	sub	x1, x21, x1
    b744:	eb00403f 	cmp	x1, x0, lsl #16
    b748:	54000322 	b.cs	b7ac <f0+0x15cc>  // b.hs, b.nlast
    b74c:	d350fc22 	lsr	x2, x1, #16
    b750:	f949fc63 	ldr	x3, [x3, #5112]
    b754:	8b020842 	add	x2, x2, x2, lsl #2
    b758:	d37df042 	lsl	x2, x2, #3
    b75c:	8b020060 	add	x0, x3, x2
    b760:	f9401017 	ldr	x23, [x0, #32]
    b764:	b4000257 	cbz	x23, b7ac <f0+0x15cc>
    b768:	38626862 	ldrb	w2, [x3, x2]
    b76c:	7100085f 	cmp	w2, #0x2
    b770:	54007640 	b.eq	c638 <f0+0x2458>  // b.none
    b774:	7100045f 	cmp	w2, #0x1
    b778:	540001a1 	b.ne	b7ac <f0+0x15cc>  // b.any
    b77c:	29430002 	ldp	w2, w0, [x0, #24]
    b780:	92403c21 	and	x1, x1, #0xffff
    b784:	9b027c21 	mul	x1, x1, x2
    b788:	d360fc21 	lsr	x1, x1, #32
    b78c:	eb00003f 	cmp	x1, x0
    b790:	540000e2 	b.cs	b7ac <f0+0x15cc>  // b.hs, b.nlast
    b794:	8b0102f7 	add	x23, x23, x1
    b798:	394002e0 	ldrb	w0, [x23]
    b79c:	7103fc1f 	cmp	w0, #0xff
    b7a0:	54007e20 	b.eq	c764 <f0+0x2584>  // b.none
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	390002e0 	strb	w0, [x23]
    b7ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b7b0:	911623e1 	add	x1, sp, #0x588
    b7b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b7b8:	52800020 	mov	w0, #0x1                   	// #1
    b7bc:	f902c7e2 	str	x2, [sp, #1416]
    b7c0:	f902cbf5 	str	x21, [sp, #1424]
    b7c4:	97ffe7df 	bl	5740 <fwp_data.part.0.constprop.0>
    b7c8:	97ffe84b 	bl	58f4 <fwp_rc_fresh>
    b7cc:	aa0003e2 	mov	x2, x0
    b7d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b7d4:	911663e1 	add	x1, sp, #0x598
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	f902cfe3 	str	x3, [sp, #1432]
    b7e0:	f902d3e2 	str	x2, [sp, #1440]
    b7e4:	97ffe7d7 	bl	5740 <fwp_data.part.0.constprop.0>
    b7e8:	9117c283 	add	x3, x20, #0x5f0
    b7ec:	aa0003f5 	mov	x21, x0
    b7f0:	f949d861 	ldr	x1, [x3, #5040]
    b7f4:	f949ec60 	ldr	x0, [x3, #5080]
    b7f8:	cb0102a1 	sub	x1, x21, x1
    b7fc:	eb00403f 	cmp	x1, x0, lsl #16
    b800:	54000322 	b.cs	b864 <f0+0x1684>  // b.hs, b.nlast
    b804:	d350fc22 	lsr	x2, x1, #16
    b808:	f949fc63 	ldr	x3, [x3, #5112]
    b80c:	8b020842 	add	x2, x2, x2, lsl #2
    b810:	d37df042 	lsl	x2, x2, #3
    b814:	8b020060 	add	x0, x3, x2
    b818:	f9401017 	ldr	x23, [x0, #32]
    b81c:	b4000257 	cbz	x23, b864 <f0+0x1684>
    b820:	38626862 	ldrb	w2, [x3, x2]
    b824:	7100085f 	cmp	w2, #0x2
    b828:	54007020 	b.eq	c62c <f0+0x244c>  // b.none
    b82c:	7100045f 	cmp	w2, #0x1
    b830:	540001a1 	b.ne	b864 <f0+0x1684>  // b.any
    b834:	29430002 	ldp	w2, w0, [x0, #24]
    b838:	92403c21 	and	x1, x1, #0xffff
    b83c:	9b027c21 	mul	x1, x1, x2
    b840:	d360fc21 	lsr	x1, x1, #32
    b844:	eb00003f 	cmp	x1, x0
    b848:	540000e2 	b.cs	b864 <f0+0x1684>  // b.hs, b.nlast
    b84c:	8b0102f7 	add	x23, x23, x1
    b850:	394002e0 	ldrb	w0, [x23]
    b854:	7103fc1f 	cmp	w0, #0xff
    b858:	540078c0 	b.eq	c770 <f0+0x2590>  // b.none
    b85c:	52800020 	mov	w0, #0x1                   	// #1
    b860:	390002e0 	strb	w0, [x23]
    b864:	9116a3e1 	add	x1, sp, #0x5a8
    b868:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b86c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b870:	52800020 	mov	w0, #0x1                   	// #1
    b874:	f902d7f7 	str	x23, [sp, #1448]
    b878:	f902dbf5 	str	x21, [sp, #1456]
    b87c:	97ffe7b1 	bl	5740 <fwp_data.part.0.constprop.0>
    b880:	97ffe81d 	bl	58f4 <fwp_rc_fresh>
    b884:	aa0003e2 	mov	x2, x0
    b888:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b88c:	9116e3e1 	add	x1, sp, #0x5b8
    b890:	52800020 	mov	w0, #0x1                   	// #1
    b894:	f902dfe3 	str	x3, [sp, #1464]
    b898:	f902e3e2 	str	x2, [sp, #1472]
    b89c:	97ffe7a9 	bl	5740 <fwp_data.part.0.constprop.0>
    b8a0:	97ffe815 	bl	58f4 <fwp_rc_fresh>
    b8a4:	aa0003e2 	mov	x2, x0
    b8a8:	911723e1 	add	x1, sp, #0x5c8
    b8ac:	52800020 	mov	w0, #0x1                   	// #1
    b8b0:	f902e7f7 	str	x23, [sp, #1480]
    b8b4:	f902ebe2 	str	x2, [sp, #1488]
    b8b8:	97ffe7a2 	bl	5740 <fwp_data.part.0.constprop.0>
    b8bc:	9117c283 	add	x3, x20, #0x5f0
    b8c0:	aa0003f5 	mov	x21, x0
    b8c4:	f949d861 	ldr	x1, [x3, #5040]
    b8c8:	f949ec60 	ldr	x0, [x3, #5080]
    b8cc:	cb0102a1 	sub	x1, x21, x1
    b8d0:	eb00403f 	cmp	x1, x0, lsl #16
    b8d4:	54000322 	b.cs	b938 <f0+0x1758>  // b.hs, b.nlast
    b8d8:	d350fc22 	lsr	x2, x1, #16
    b8dc:	f949fc63 	ldr	x3, [x3, #5112]
    b8e0:	8b020842 	add	x2, x2, x2, lsl #2
    b8e4:	d37df042 	lsl	x2, x2, #3
    b8e8:	8b020060 	add	x0, x3, x2
    b8ec:	f9401017 	ldr	x23, [x0, #32]
    b8f0:	b4000257 	cbz	x23, b938 <f0+0x1758>
    b8f4:	38626862 	ldrb	w2, [x3, x2]
    b8f8:	7100085f 	cmp	w2, #0x2
    b8fc:	54006920 	b.eq	c620 <f0+0x2440>  // b.none
    b900:	7100045f 	cmp	w2, #0x1
    b904:	540001a1 	b.ne	b938 <f0+0x1758>  // b.any
    b908:	29430002 	ldp	w2, w0, [x0, #24]
    b90c:	92403c21 	and	x1, x1, #0xffff
    b910:	9b027c21 	mul	x1, x1, x2
    b914:	d360fc21 	lsr	x1, x1, #32
    b918:	eb00003f 	cmp	x1, x0
    b91c:	540000e2 	b.cs	b938 <f0+0x1758>  // b.hs, b.nlast
    b920:	8b0102f7 	add	x23, x23, x1
    b924:	394002e0 	ldrb	w0, [x23]
    b928:	7103fc1f 	cmp	w0, #0xff
    b92c:	54007280 	b.eq	c77c <f0+0x259c>  // b.none
    b930:	52800020 	mov	w0, #0x1                   	// #1
    b934:	390002e0 	strb	w0, [x23]
    b938:	911763e1 	add	x1, sp, #0x5d8
    b93c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b940:	52800020 	mov	w0, #0x1                   	// #1
    b944:	f902eff7 	str	x23, [sp, #1496]
    b948:	f902f3f5 	str	x21, [sp, #1504]
    b94c:	97ffe77d 	bl	5740 <fwp_data.part.0.constprop.0>
    b950:	97ffe7e9 	bl	58f4 <fwp_rc_fresh>
    b954:	aa0003e2 	mov	x2, x0
    b958:	9117a3e1 	add	x1, sp, #0x5e8
    b95c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b960:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b964:	52800020 	mov	w0, #0x1                   	// #1
    b968:	f902f7f5 	str	x21, [sp, #1512]
    b96c:	f902fbe2 	str	x2, [sp, #1520]
    b970:	97ffe774 	bl	5740 <fwp_data.part.0.constprop.0>
    b974:	97ffe7e0 	bl	58f4 <fwp_rc_fresh>
    b978:	aa0003e2 	mov	x2, x0
    b97c:	9117e3e1 	add	x1, sp, #0x5f8
    b980:	52800020 	mov	w0, #0x1                   	// #1
    b984:	f902fff7 	str	x23, [sp, #1528]
    b988:	f90303e2 	str	x2, [sp, #1536]
    b98c:	97ffe76d 	bl	5740 <fwp_data.part.0.constprop.0>
    b990:	97ffe7d9 	bl	58f4 <fwp_rc_fresh>
    b994:	aa0003e2 	mov	x2, x0
    b998:	911823e1 	add	x1, sp, #0x608
    b99c:	52800020 	mov	w0, #0x1                   	// #1
    b9a0:	f90307f5 	str	x21, [sp, #1544]
    b9a4:	f9030be2 	str	x2, [sp, #1552]
    b9a8:	97ffe766 	bl	5740 <fwp_data.part.0.constprop.0>
    b9ac:	97ffe7d2 	bl	58f4 <fwp_rc_fresh>
    b9b0:	aa0003e2 	mov	x2, x0
    b9b4:	911863e1 	add	x1, sp, #0x618
    b9b8:	52800020 	mov	w0, #0x1                   	// #1
    b9bc:	f9030ff7 	str	x23, [sp, #1560]
    b9c0:	f90313e2 	str	x2, [sp, #1568]
    b9c4:	97ffe75f 	bl	5740 <fwp_data.part.0.constprop.0>
    b9c8:	9117c283 	add	x3, x20, #0x5f0
    b9cc:	aa0003f5 	mov	x21, x0
    b9d0:	f949d861 	ldr	x1, [x3, #5040]
    b9d4:	f949ec60 	ldr	x0, [x3, #5080]
    b9d8:	cb0102a1 	sub	x1, x21, x1
    b9dc:	eb00403f 	cmp	x1, x0, lsl #16
    b9e0:	54000322 	b.cs	ba44 <f0+0x1864>  // b.hs, b.nlast
    b9e4:	d350fc22 	lsr	x2, x1, #16
    b9e8:	f949fc63 	ldr	x3, [x3, #5112]
    b9ec:	8b020842 	add	x2, x2, x2, lsl #2
    b9f0:	d37df042 	lsl	x2, x2, #3
    b9f4:	8b020060 	add	x0, x3, x2
    b9f8:	f9401017 	ldr	x23, [x0, #32]
    b9fc:	b4000257 	cbz	x23, ba44 <f0+0x1864>
    ba00:	38626862 	ldrb	w2, [x3, x2]
    ba04:	7100085f 	cmp	w2, #0x2
    ba08:	54006060 	b.eq	c614 <f0+0x2434>  // b.none
    ba0c:	7100045f 	cmp	w2, #0x1
    ba10:	540001a1 	b.ne	ba44 <f0+0x1864>  // b.any
    ba14:	29430002 	ldp	w2, w0, [x0, #24]
    ba18:	92403c21 	and	x1, x1, #0xffff
    ba1c:	9b027c21 	mul	x1, x1, x2
    ba20:	d360fc21 	lsr	x1, x1, #32
    ba24:	eb00003f 	cmp	x1, x0
    ba28:	540000e2 	b.cs	ba44 <f0+0x1864>  // b.hs, b.nlast
    ba2c:	8b0102f7 	add	x23, x23, x1
    ba30:	394002e0 	ldrb	w0, [x23]
    ba34:	7103fc1f 	cmp	w0, #0xff
    ba38:	54006a80 	b.eq	c788 <f0+0x25a8>  // b.none
    ba3c:	52800020 	mov	w0, #0x1                   	// #1
    ba40:	390002e0 	strb	w0, [x23]
    ba44:	9118a3e1 	add	x1, sp, #0x628
    ba48:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba4c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba50:	52800020 	mov	w0, #0x1                   	// #1
    ba54:	f90317f7 	str	x23, [sp, #1576]
    ba58:	f9031bf5 	str	x21, [sp, #1584]
    ba5c:	97ffe739 	bl	5740 <fwp_data.part.0.constprop.0>
    ba60:	97ffe7a5 	bl	58f4 <fwp_rc_fresh>
    ba64:	aa0003e2 	mov	x2, x0
    ba68:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ba6c:	9118e3e1 	add	x1, sp, #0x638
    ba70:	52800020 	mov	w0, #0x1                   	// #1
    ba74:	f9031fe3 	str	x3, [sp, #1592]
    ba78:	f90323e2 	str	x2, [sp, #1600]
    ba7c:	97ffe731 	bl	5740 <fwp_data.part.0.constprop.0>
    ba80:	97ffe79d 	bl	58f4 <fwp_rc_fresh>
    ba84:	aa0003e2 	mov	x2, x0
    ba88:	911923e1 	add	x1, sp, #0x648
    ba8c:	52800020 	mov	w0, #0x1                   	// #1
    ba90:	f90327f7 	str	x23, [sp, #1608]
    ba94:	f9032be2 	str	x2, [sp, #1616]
    ba98:	97ffe72a 	bl	5740 <fwp_data.part.0.constprop.0>
    ba9c:	9117c283 	add	x3, x20, #0x5f0
    baa0:	aa0003f5 	mov	x21, x0
    baa4:	f949d861 	ldr	x1, [x3, #5040]
    baa8:	f949ec60 	ldr	x0, [x3, #5080]
    baac:	cb0102a1 	sub	x1, x21, x1
    bab0:	eb00403f 	cmp	x1, x0, lsl #16
    bab4:	54000322 	b.cs	bb18 <f0+0x1938>  // b.hs, b.nlast
    bab8:	d350fc22 	lsr	x2, x1, #16
    babc:	f949fc63 	ldr	x3, [x3, #5112]
    bac0:	8b020842 	add	x2, x2, x2, lsl #2
    bac4:	d37df042 	lsl	x2, x2, #3
    bac8:	8b020060 	add	x0, x3, x2
    bacc:	f9401017 	ldr	x23, [x0, #32]
    bad0:	b4000257 	cbz	x23, bb18 <f0+0x1938>
    bad4:	38626862 	ldrb	w2, [x3, x2]
    bad8:	7100085f 	cmp	w2, #0x2
    badc:	54005960 	b.eq	c608 <f0+0x2428>  // b.none
    bae0:	7100045f 	cmp	w2, #0x1
    bae4:	540001a1 	b.ne	bb18 <f0+0x1938>  // b.any
    bae8:	29430002 	ldp	w2, w0, [x0, #24]
    baec:	92403c21 	and	x1, x1, #0xffff
    baf0:	9b027c21 	mul	x1, x1, x2
    baf4:	d360fc21 	lsr	x1, x1, #32
    baf8:	eb00003f 	cmp	x1, x0
    bafc:	540000e2 	b.cs	bb18 <f0+0x1938>  // b.hs, b.nlast
    bb00:	8b0102f7 	add	x23, x23, x1
    bb04:	394002e0 	ldrb	w0, [x23]
    bb08:	7103fc1f 	cmp	w0, #0xff
    bb0c:	54006440 	b.eq	c794 <f0+0x25b4>  // b.none
    bb10:	52800020 	mov	w0, #0x1                   	// #1
    bb14:	390002e0 	strb	w0, [x23]
    bb18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb1c:	911963e1 	add	x1, sp, #0x658
    bb20:	52800020 	mov	w0, #0x1                   	// #1
    bb24:	f9032fe2 	str	x2, [sp, #1624]
    bb28:	f90333f5 	str	x21, [sp, #1632]
    bb2c:	97ffe705 	bl	5740 <fwp_data.part.0.constprop.0>
    bb30:	9117c283 	add	x3, x20, #0x5f0
    bb34:	aa0003f5 	mov	x21, x0
    bb38:	f949d861 	ldr	x1, [x3, #5040]
    bb3c:	f949ec60 	ldr	x0, [x3, #5080]
    bb40:	cb0102a1 	sub	x1, x21, x1
    bb44:	eb00403f 	cmp	x1, x0, lsl #16
    bb48:	54000322 	b.cs	bbac <f0+0x19cc>  // b.hs, b.nlast
    bb4c:	d350fc22 	lsr	x2, x1, #16
    bb50:	f949fc63 	ldr	x3, [x3, #5112]
    bb54:	8b020842 	add	x2, x2, x2, lsl #2
    bb58:	d37df042 	lsl	x2, x2, #3
    bb5c:	8b020060 	add	x0, x3, x2
    bb60:	f9401017 	ldr	x23, [x0, #32]
    bb64:	b4000257 	cbz	x23, bbac <f0+0x19cc>
    bb68:	38626862 	ldrb	w2, [x3, x2]
    bb6c:	7100085f 	cmp	w2, #0x2
    bb70:	54005460 	b.eq	c5fc <f0+0x241c>  // b.none
    bb74:	7100045f 	cmp	w2, #0x1
    bb78:	540001a1 	b.ne	bbac <f0+0x19cc>  // b.any
    bb7c:	29430002 	ldp	w2, w0, [x0, #24]
    bb80:	92403c21 	and	x1, x1, #0xffff
    bb84:	9b027c21 	mul	x1, x1, x2
    bb88:	d360fc21 	lsr	x1, x1, #32
    bb8c:	eb00003f 	cmp	x1, x0
    bb90:	540000e2 	b.cs	bbac <f0+0x19cc>  // b.hs, b.nlast
    bb94:	8b0102f7 	add	x23, x23, x1
    bb98:	394002e0 	ldrb	w0, [x23]
    bb9c:	7103fc1f 	cmp	w0, #0xff
    bba0:	54006000 	b.eq	c7a0 <f0+0x25c0>  // b.none
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	390002e0 	strb	w0, [x23]
    bbac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bbb0:	9119a3e1 	add	x1, sp, #0x668
    bbb4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bbb8:	52800020 	mov	w0, #0x1                   	// #1
    bbbc:	f90337e2 	str	x2, [sp, #1640]
    bbc0:	f9033bf5 	str	x21, [sp, #1648]
    bbc4:	97ffe6df 	bl	5740 <fwp_data.part.0.constprop.0>
    bbc8:	97ffe74b 	bl	58f4 <fwp_rc_fresh>
    bbcc:	aa0003e2 	mov	x2, x0
    bbd0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bbd4:	9119e3e1 	add	x1, sp, #0x678
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	f9033fe3 	str	x3, [sp, #1656]
    bbe0:	f90343e2 	str	x2, [sp, #1664]
    bbe4:	97ffe6d7 	bl	5740 <fwp_data.part.0.constprop.0>
    bbe8:	9117c283 	add	x3, x20, #0x5f0
    bbec:	aa0003f5 	mov	x21, x0
    bbf0:	f949d861 	ldr	x1, [x3, #5040]
    bbf4:	f949ec60 	ldr	x0, [x3, #5080]
    bbf8:	cb0102a1 	sub	x1, x21, x1
    bbfc:	eb00403f 	cmp	x1, x0, lsl #16
    bc00:	54000322 	b.cs	bc64 <f0+0x1a84>  // b.hs, b.nlast
    bc04:	d350fc22 	lsr	x2, x1, #16
    bc08:	f949fc63 	ldr	x3, [x3, #5112]
    bc0c:	8b020842 	add	x2, x2, x2, lsl #2
    bc10:	d37df042 	lsl	x2, x2, #3
    bc14:	8b020060 	add	x0, x3, x2
    bc18:	f9401017 	ldr	x23, [x0, #32]
    bc1c:	b4000257 	cbz	x23, bc64 <f0+0x1a84>
    bc20:	38626862 	ldrb	w2, [x3, x2]
    bc24:	7100085f 	cmp	w2, #0x2
    bc28:	54004e40 	b.eq	c5f0 <f0+0x2410>  // b.none
    bc2c:	7100045f 	cmp	w2, #0x1
    bc30:	540001a1 	b.ne	bc64 <f0+0x1a84>  // b.any
    bc34:	29430002 	ldp	w2, w0, [x0, #24]
    bc38:	92403c21 	and	x1, x1, #0xffff
    bc3c:	9b027c21 	mul	x1, x1, x2
    bc40:	d360fc21 	lsr	x1, x1, #32
    bc44:	eb00003f 	cmp	x1, x0
    bc48:	540000e2 	b.cs	bc64 <f0+0x1a84>  // b.hs, b.nlast
    bc4c:	8b0102f7 	add	x23, x23, x1
    bc50:	394002e0 	ldrb	w0, [x23]
    bc54:	7103fc1f 	cmp	w0, #0xff
    bc58:	54005aa0 	b.eq	c7ac <f0+0x25cc>  // b.none
    bc5c:	52800020 	mov	w0, #0x1                   	// #1
    bc60:	390002e0 	strb	w0, [x23]
    bc64:	911a23e1 	add	x1, sp, #0x688
    bc68:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bc6c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bc70:	52800020 	mov	w0, #0x1                   	// #1
    bc74:	f90347f7 	str	x23, [sp, #1672]
    bc78:	f9034bf5 	str	x21, [sp, #1680]
    bc7c:	97ffe6b1 	bl	5740 <fwp_data.part.0.constprop.0>
    bc80:	97ffe71d 	bl	58f4 <fwp_rc_fresh>
    bc84:	aa0003e2 	mov	x2, x0
    bc88:	911a63e1 	add	x1, sp, #0x698
    bc8c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bc90:	52800020 	mov	w0, #0x1                   	// #1
    bc94:	f9034ff5 	str	x21, [sp, #1688]
    bc98:	f90353e2 	str	x2, [sp, #1696]
    bc9c:	97ffe6a9 	bl	5740 <fwp_data.part.0.constprop.0>
    bca0:	97ffe715 	bl	58f4 <fwp_rc_fresh>
    bca4:	aa0003e2 	mov	x2, x0
    bca8:	911aa3e1 	add	x1, sp, #0x6a8
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f90357f7 	str	x23, [sp, #1704]
    bcb4:	f9035be2 	str	x2, [sp, #1712]
    bcb8:	97ffe6a2 	bl	5740 <fwp_data.part.0.constprop.0>
    bcbc:	97ffe70e 	bl	58f4 <fwp_rc_fresh>
    bcc0:	aa0003e2 	mov	x2, x0
    bcc4:	911ae3e1 	add	x1, sp, #0x6b8
    bcc8:	52800020 	mov	w0, #0x1                   	// #1
    bccc:	f9035ff5 	str	x21, [sp, #1720]
    bcd0:	f90363e2 	str	x2, [sp, #1728]
    bcd4:	97ffe69b 	bl	5740 <fwp_data.part.0.constprop.0>
    bcd8:	97ffe707 	bl	58f4 <fwp_rc_fresh>
    bcdc:	aa0003e2 	mov	x2, x0
    bce0:	911b23e1 	add	x1, sp, #0x6c8
    bce4:	52800020 	mov	w0, #0x1                   	// #1
    bce8:	f90367f7 	str	x23, [sp, #1736]
    bcec:	f9036be2 	str	x2, [sp, #1744]
    bcf0:	97ffe694 	bl	5740 <fwp_data.part.0.constprop.0>
    bcf4:	9117c283 	add	x3, x20, #0x5f0
    bcf8:	aa0003f5 	mov	x21, x0
    bcfc:	f949d861 	ldr	x1, [x3, #5040]
    bd00:	f949ec60 	ldr	x0, [x3, #5080]
    bd04:	cb0102a1 	sub	x1, x21, x1
    bd08:	eb00403f 	cmp	x1, x0, lsl #16
    bd0c:	54000322 	b.cs	bd70 <f0+0x1b90>  // b.hs, b.nlast
    bd10:	d350fc22 	lsr	x2, x1, #16
    bd14:	f949fc63 	ldr	x3, [x3, #5112]
    bd18:	8b020842 	add	x2, x2, x2, lsl #2
    bd1c:	d37df042 	lsl	x2, x2, #3
    bd20:	8b020060 	add	x0, x3, x2
    bd24:	f9401017 	ldr	x23, [x0, #32]
    bd28:	b4000257 	cbz	x23, bd70 <f0+0x1b90>
    bd2c:	38626862 	ldrb	w2, [x3, x2]
    bd30:	7100085f 	cmp	w2, #0x2
    bd34:	54004580 	b.eq	c5e4 <f0+0x2404>  // b.none
    bd38:	7100045f 	cmp	w2, #0x1
    bd3c:	540001a1 	b.ne	bd70 <f0+0x1b90>  // b.any
    bd40:	29430002 	ldp	w2, w0, [x0, #24]
    bd44:	92403c21 	and	x1, x1, #0xffff
    bd48:	9b027c21 	mul	x1, x1, x2
    bd4c:	d360fc21 	lsr	x1, x1, #32
    bd50:	eb00003f 	cmp	x1, x0
    bd54:	540000e2 	b.cs	bd70 <f0+0x1b90>  // b.hs, b.nlast
    bd58:	8b0102f7 	add	x23, x23, x1
    bd5c:	394002e0 	ldrb	w0, [x23]
    bd60:	7103fc1f 	cmp	w0, #0xff
    bd64:	540052a0 	b.eq	c7b8 <f0+0x25d8>  // b.none
    bd68:	52800020 	mov	w0, #0x1                   	// #1
    bd6c:	390002e0 	strb	w0, [x23]
    bd70:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd74:	911b63e1 	add	x1, sp, #0x6d8
    bd78:	52800020 	mov	w0, #0x1                   	// #1
    bd7c:	f9036fe2 	str	x2, [sp, #1752]
    bd80:	f90373f5 	str	x21, [sp, #1760]
    bd84:	97ffe66f 	bl	5740 <fwp_data.part.0.constprop.0>
    bd88:	9117c283 	add	x3, x20, #0x5f0
    bd8c:	aa0003f5 	mov	x21, x0
    bd90:	f949d861 	ldr	x1, [x3, #5040]
    bd94:	f949ec60 	ldr	x0, [x3, #5080]
    bd98:	cb0102a1 	sub	x1, x21, x1
    bd9c:	eb00403f 	cmp	x1, x0, lsl #16
    bda0:	54000322 	b.cs	be04 <f0+0x1c24>  // b.hs, b.nlast
    bda4:	d350fc22 	lsr	x2, x1, #16
    bda8:	f949fc63 	ldr	x3, [x3, #5112]
    bdac:	8b020842 	add	x2, x2, x2, lsl #2
    bdb0:	d37df042 	lsl	x2, x2, #3
    bdb4:	8b020060 	add	x0, x3, x2
    bdb8:	f9401017 	ldr	x23, [x0, #32]
    bdbc:	b4000257 	cbz	x23, be04 <f0+0x1c24>
    bdc0:	38626862 	ldrb	w2, [x3, x2]
    bdc4:	7100085f 	cmp	w2, #0x2
    bdc8:	54004080 	b.eq	c5d8 <f0+0x23f8>  // b.none
    bdcc:	7100045f 	cmp	w2, #0x1
    bdd0:	540001a1 	b.ne	be04 <f0+0x1c24>  // b.any
    bdd4:	29430002 	ldp	w2, w0, [x0, #24]
    bdd8:	92403c21 	and	x1, x1, #0xffff
    bddc:	9b027c21 	mul	x1, x1, x2
    bde0:	d360fc21 	lsr	x1, x1, #32
    bde4:	eb00003f 	cmp	x1, x0
    bde8:	540000e2 	b.cs	be04 <f0+0x1c24>  // b.hs, b.nlast
    bdec:	8b0102f7 	add	x23, x23, x1
    bdf0:	394002e0 	ldrb	w0, [x23]
    bdf4:	7103fc1f 	cmp	w0, #0xff
    bdf8:	54004e60 	b.eq	c7c4 <f0+0x25e4>  // b.none
    bdfc:	52800020 	mov	w0, #0x1                   	// #1
    be00:	390002e0 	strb	w0, [x23]
    be04:	911ba3e1 	add	x1, sp, #0x6e8
    be08:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    be0c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    be10:	52800020 	mov	w0, #0x1                   	// #1
    be14:	f90377f7 	str	x23, [sp, #1768]
    be18:	f9037bf5 	str	x21, [sp, #1776]
    be1c:	97ffe649 	bl	5740 <fwp_data.part.0.constprop.0>
    be20:	97ffe6b5 	bl	58f4 <fwp_rc_fresh>
    be24:	aa0003e2 	mov	x2, x0
    be28:	911be3e1 	add	x1, sp, #0x6f8
    be2c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    be30:	52800020 	mov	w0, #0x1                   	// #1
    be34:	f9037ff5 	str	x21, [sp, #1784]
    be38:	f90383e2 	str	x2, [sp, #1792]
    be3c:	97ffe641 	bl	5740 <fwp_data.part.0.constprop.0>
    be40:	97ffe6ad 	bl	58f4 <fwp_rc_fresh>
    be44:	aa0003e2 	mov	x2, x0
    be48:	911c23e1 	add	x1, sp, #0x708
    be4c:	52800020 	mov	w0, #0x1                   	// #1
    be50:	f90387f7 	str	x23, [sp, #1800]
    be54:	f9038be2 	str	x2, [sp, #1808]
    be58:	97ffe63a 	bl	5740 <fwp_data.part.0.constprop.0>
    be5c:	97ffe6a6 	bl	58f4 <fwp_rc_fresh>
    be60:	aa0003e2 	mov	x2, x0
    be64:	911c63e1 	add	x1, sp, #0x718
    be68:	52800020 	mov	w0, #0x1                   	// #1
    be6c:	f9038ff5 	str	x21, [sp, #1816]
    be70:	f90393e2 	str	x2, [sp, #1824]
    be74:	97ffe633 	bl	5740 <fwp_data.part.0.constprop.0>
    be78:	9117c283 	add	x3, x20, #0x5f0
    be7c:	aa0003f5 	mov	x21, x0
    be80:	f949d861 	ldr	x1, [x3, #5040]
    be84:	f949ec60 	ldr	x0, [x3, #5080]
    be88:	cb0102a1 	sub	x1, x21, x1
    be8c:	eb00403f 	cmp	x1, x0, lsl #16
    be90:	54000322 	b.cs	bef4 <f0+0x1d14>  // b.hs, b.nlast
    be94:	d350fc22 	lsr	x2, x1, #16
    be98:	f949fc63 	ldr	x3, [x3, #5112]
    be9c:	8b020842 	add	x2, x2, x2, lsl #2
    bea0:	d37df042 	lsl	x2, x2, #3
    bea4:	8b020060 	add	x0, x3, x2
    bea8:	f9401017 	ldr	x23, [x0, #32]
    beac:	b4000257 	cbz	x23, bef4 <f0+0x1d14>
    beb0:	38626862 	ldrb	w2, [x3, x2]
    beb4:	7100085f 	cmp	w2, #0x2
    beb8:	540038a0 	b.eq	c5cc <f0+0x23ec>  // b.none
    bebc:	7100045f 	cmp	w2, #0x1
    bec0:	540001a1 	b.ne	bef4 <f0+0x1d14>  // b.any
    bec4:	29430002 	ldp	w2, w0, [x0, #24]
    bec8:	92403c21 	and	x1, x1, #0xffff
    becc:	9b027c21 	mul	x1, x1, x2
    bed0:	d360fc21 	lsr	x1, x1, #32
    bed4:	eb00003f 	cmp	x1, x0
    bed8:	540000e2 	b.cs	bef4 <f0+0x1d14>  // b.hs, b.nlast
    bedc:	8b0102f7 	add	x23, x23, x1
    bee0:	394002e0 	ldrb	w0, [x23]
    bee4:	7103fc1f 	cmp	w0, #0xff
    bee8:	54004740 	b.eq	c7d0 <f0+0x25f0>  // b.none
    beec:	52800020 	mov	w0, #0x1                   	// #1
    bef0:	390002e0 	strb	w0, [x23]
    bef4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bef8:	911ca3e1 	add	x1, sp, #0x728
    befc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf00:	52800020 	mov	w0, #0x1                   	// #1
    bf04:	f90397e2 	str	x2, [sp, #1832]
    bf08:	f9039bf5 	str	x21, [sp, #1840]
    bf0c:	97ffe60d 	bl	5740 <fwp_data.part.0.constprop.0>
    bf10:	9117c283 	add	x3, x20, #0x5f0
    bf14:	aa0003f5 	mov	x21, x0
    bf18:	f949d861 	ldr	x1, [x3, #5040]
    bf1c:	f949ec60 	ldr	x0, [x3, #5080]
    bf20:	cb0102a1 	sub	x1, x21, x1
    bf24:	eb00403f 	cmp	x1, x0, lsl #16
    bf28:	54000322 	b.cs	bf8c <f0+0x1dac>  // b.hs, b.nlast
    bf2c:	d350fc22 	lsr	x2, x1, #16
    bf30:	f949fc63 	ldr	x3, [x3, #5112]
    bf34:	8b020842 	add	x2, x2, x2, lsl #2
    bf38:	d37df042 	lsl	x2, x2, #3
    bf3c:	8b020060 	add	x0, x3, x2
    bf40:	f9401017 	ldr	x23, [x0, #32]
    bf44:	b4000257 	cbz	x23, bf8c <f0+0x1dac>
    bf48:	38626862 	ldrb	w2, [x3, x2]
    bf4c:	7100085f 	cmp	w2, #0x2
    bf50:	54003380 	b.eq	c5c0 <f0+0x23e0>  // b.none
    bf54:	7100045f 	cmp	w2, #0x1
    bf58:	540001a1 	b.ne	bf8c <f0+0x1dac>  // b.any
    bf5c:	29430002 	ldp	w2, w0, [x0, #24]
    bf60:	92403c21 	and	x1, x1, #0xffff
    bf64:	9b027c21 	mul	x1, x1, x2
    bf68:	d360fc21 	lsr	x1, x1, #32
    bf6c:	eb00003f 	cmp	x1, x0
    bf70:	540000e2 	b.cs	bf8c <f0+0x1dac>  // b.hs, b.nlast
    bf74:	8b0102f7 	add	x23, x23, x1
    bf78:	394002e0 	ldrb	w0, [x23]
    bf7c:	7103fc1f 	cmp	w0, #0xff
    bf80:	540042e0 	b.eq	c7dc <f0+0x25fc>  // b.none
    bf84:	52800020 	mov	w0, #0x1                   	// #1
    bf88:	390002e0 	strb	w0, [x23]
    bf8c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf90:	911ce3e1 	add	x1, sp, #0x738
    bf94:	52800020 	mov	w0, #0x1                   	// #1
    bf98:	f9039fe2 	str	x2, [sp, #1848]
    bf9c:	f903a3f5 	str	x21, [sp, #1856]
    bfa0:	97ffe5e8 	bl	5740 <fwp_data.part.0.constprop.0>
    bfa4:	9117c283 	add	x3, x20, #0x5f0
    bfa8:	aa0003f5 	mov	x21, x0
    bfac:	f949d861 	ldr	x1, [x3, #5040]
    bfb0:	f949ec60 	ldr	x0, [x3, #5080]
    bfb4:	cb0102a1 	sub	x1, x21, x1
    bfb8:	eb00403f 	cmp	x1, x0, lsl #16
    bfbc:	54000322 	b.cs	c020 <f0+0x1e40>  // b.hs, b.nlast
    bfc0:	d350fc22 	lsr	x2, x1, #16
    bfc4:	f949fc63 	ldr	x3, [x3, #5112]
    bfc8:	8b020842 	add	x2, x2, x2, lsl #2
    bfcc:	d37df042 	lsl	x2, x2, #3
    bfd0:	8b020060 	add	x0, x3, x2
    bfd4:	f9401017 	ldr	x23, [x0, #32]
    bfd8:	b4000257 	cbz	x23, c020 <f0+0x1e40>
    bfdc:	38626862 	ldrb	w2, [x3, x2]
    bfe0:	7100085f 	cmp	w2, #0x2
    bfe4:	54002e80 	b.eq	c5b4 <f0+0x23d4>  // b.none
    bfe8:	7100045f 	cmp	w2, #0x1
    bfec:	540001a1 	b.ne	c020 <f0+0x1e40>  // b.any
    bff0:	29430002 	ldp	w2, w0, [x0, #24]
    bff4:	92403c21 	and	x1, x1, #0xffff
    bff8:	9b027c21 	mul	x1, x1, x2
    bffc:	d360fc21 	lsr	x1, x1, #32
    c000:	eb00003f 	cmp	x1, x0
    c004:	540000e2 	b.cs	c020 <f0+0x1e40>  // b.hs, b.nlast
    c008:	8b0102f7 	add	x23, x23, x1
    c00c:	394002e0 	ldrb	w0, [x23]
    c010:	7103fc1f 	cmp	w0, #0xff
    c014:	54003ea0 	b.eq	c7e8 <f0+0x2608>  // b.none
    c018:	52800020 	mov	w0, #0x1                   	// #1
    c01c:	390002e0 	strb	w0, [x23]
    c020:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c024:	911d23e1 	add	x1, sp, #0x748
    c028:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c02c:	52800020 	mov	w0, #0x1                   	// #1
    c030:	f903a7e2 	str	x2, [sp, #1864]
    c034:	f903abf5 	str	x21, [sp, #1872]
    c038:	97ffe5c2 	bl	5740 <fwp_data.part.0.constprop.0>
    c03c:	9117c283 	add	x3, x20, #0x5f0
    c040:	aa0003f5 	mov	x21, x0
    c044:	f949d861 	ldr	x1, [x3, #5040]
    c048:	f949ec60 	ldr	x0, [x3, #5080]
    c04c:	cb0102a1 	sub	x1, x21, x1
    c050:	eb00403f 	cmp	x1, x0, lsl #16
    c054:	54000322 	b.cs	c0b8 <f0+0x1ed8>  // b.hs, b.nlast
    c058:	d350fc22 	lsr	x2, x1, #16
    c05c:	f949fc63 	ldr	x3, [x3, #5112]
    c060:	8b020842 	add	x2, x2, x2, lsl #2
    c064:	d37df042 	lsl	x2, x2, #3
    c068:	8b020060 	add	x0, x3, x2
    c06c:	f9401017 	ldr	x23, [x0, #32]
    c070:	b4000257 	cbz	x23, c0b8 <f0+0x1ed8>
    c074:	38626862 	ldrb	w2, [x3, x2]
    c078:	7100085f 	cmp	w2, #0x2
    c07c:	54002960 	b.eq	c5a8 <f0+0x23c8>  // b.none
    c080:	7100045f 	cmp	w2, #0x1
    c084:	540001a1 	b.ne	c0b8 <f0+0x1ed8>  // b.any
    c088:	29430002 	ldp	w2, w0, [x0, #24]
    c08c:	92403c21 	and	x1, x1, #0xffff
    c090:	9b027c21 	mul	x1, x1, x2
    c094:	d360fc21 	lsr	x1, x1, #32
    c098:	eb00003f 	cmp	x1, x0
    c09c:	540000e2 	b.cs	c0b8 <f0+0x1ed8>  // b.hs, b.nlast
    c0a0:	8b0102f7 	add	x23, x23, x1
    c0a4:	394002e0 	ldrb	w0, [x23]
    c0a8:	7103fc1f 	cmp	w0, #0xff
    c0ac:	54003a40 	b.eq	c7f4 <f0+0x2614>  // b.none
    c0b0:	52800020 	mov	w0, #0x1                   	// #1
    c0b4:	390002e0 	strb	w0, [x23]
    c0b8:	911d63e1 	add	x1, sp, #0x758
    c0bc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c0c0:	52800020 	mov	w0, #0x1                   	// #1
    c0c4:	f903aff7 	str	x23, [sp, #1880]
    c0c8:	f903b3f5 	str	x21, [sp, #1888]
    c0cc:	97ffe59d 	bl	5740 <fwp_data.part.0.constprop.0>
    c0d0:	97ffe609 	bl	58f4 <fwp_rc_fresh>
    c0d4:	aa0003e2 	mov	x2, x0
    c0d8:	911da3e1 	add	x1, sp, #0x768
    c0dc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c0e0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c0e4:	52800020 	mov	w0, #0x1                   	// #1
    c0e8:	f903b7f5 	str	x21, [sp, #1896]
    c0ec:	f903bbe2 	str	x2, [sp, #1904]
    c0f0:	97ffe594 	bl	5740 <fwp_data.part.0.constprop.0>
    c0f4:	97ffe600 	bl	58f4 <fwp_rc_fresh>
    c0f8:	aa0003e2 	mov	x2, x0
    c0fc:	911de3e1 	add	x1, sp, #0x778
    c100:	52800020 	mov	w0, #0x1                   	// #1
    c104:	f903bff7 	str	x23, [sp, #1912]
    c108:	f903c3e2 	str	x2, [sp, #1920]
    c10c:	97ffe58d 	bl	5740 <fwp_data.part.0.constprop.0>
    c110:	97ffe5f9 	bl	58f4 <fwp_rc_fresh>
    c114:	aa0003e2 	mov	x2, x0
    c118:	911e23e1 	add	x1, sp, #0x788
    c11c:	52800020 	mov	w0, #0x1                   	// #1
    c120:	f903c7f5 	str	x21, [sp, #1928]
    c124:	f903cbe2 	str	x2, [sp, #1936]
    c128:	97ffe586 	bl	5740 <fwp_data.part.0.constprop.0>
    c12c:	97ffe5f2 	bl	58f4 <fwp_rc_fresh>
    c130:	aa0003e2 	mov	x2, x0
    c134:	911e63e1 	add	x1, sp, #0x798
    c138:	52800020 	mov	w0, #0x1                   	// #1
    c13c:	f903cff7 	str	x23, [sp, #1944]
    c140:	f903d3e2 	str	x2, [sp, #1952]
    c144:	97ffe57f 	bl	5740 <fwp_data.part.0.constprop.0>
    c148:	9117c283 	add	x3, x20, #0x5f0
    c14c:	aa0003f5 	mov	x21, x0
    c150:	f949d861 	ldr	x1, [x3, #5040]
    c154:	f949ec60 	ldr	x0, [x3, #5080]
    c158:	cb0102a1 	sub	x1, x21, x1
    c15c:	eb00403f 	cmp	x1, x0, lsl #16
    c160:	54000322 	b.cs	c1c4 <f0+0x1fe4>  // b.hs, b.nlast
    c164:	d350fc22 	lsr	x2, x1, #16
    c168:	f949fc63 	ldr	x3, [x3, #5112]
    c16c:	8b020842 	add	x2, x2, x2, lsl #2
    c170:	d37df042 	lsl	x2, x2, #3
    c174:	8b020060 	add	x0, x3, x2
    c178:	f9401017 	ldr	x23, [x0, #32]
    c17c:	b4000257 	cbz	x23, c1c4 <f0+0x1fe4>
    c180:	38626862 	ldrb	w2, [x3, x2]
    c184:	7100085f 	cmp	w2, #0x2
    c188:	540020a0 	b.eq	c59c <f0+0x23bc>  // b.none
    c18c:	7100045f 	cmp	w2, #0x1
    c190:	540001a1 	b.ne	c1c4 <f0+0x1fe4>  // b.any
    c194:	29430002 	ldp	w2, w0, [x0, #24]
    c198:	92403c21 	and	x1, x1, #0xffff
    c19c:	9b027c21 	mul	x1, x1, x2
    c1a0:	d360fc21 	lsr	x1, x1, #32
    c1a4:	eb00003f 	cmp	x1, x0
    c1a8:	540000e2 	b.cs	c1c4 <f0+0x1fe4>  // b.hs, b.nlast
    c1ac:	8b0102f7 	add	x23, x23, x1
    c1b0:	394002e0 	ldrb	w0, [x23]
    c1b4:	7103fc1f 	cmp	w0, #0xff
    c1b8:	54003240 	b.eq	c800 <f0+0x2620>  // b.none
    c1bc:	52800020 	mov	w0, #0x1                   	// #1
    c1c0:	390002e0 	strb	w0, [x23]
    c1c4:	911ea3e1 	add	x1, sp, #0x7a8
    c1c8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c1cc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c1d0:	52800020 	mov	w0, #0x1                   	// #1
    c1d4:	f903d7f7 	str	x23, [sp, #1960]
    c1d8:	f903dbf5 	str	x21, [sp, #1968]
    c1dc:	97ffe559 	bl	5740 <fwp_data.part.0.constprop.0>
    c1e0:	97ffe5c5 	bl	58f4 <fwp_rc_fresh>
    c1e4:	aa0003e2 	mov	x2, x0
    c1e8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c1ec:	911ee3e1 	add	x1, sp, #0x7b8
    c1f0:	52800020 	mov	w0, #0x1                   	// #1
    c1f4:	f903dfe3 	str	x3, [sp, #1976]
    c1f8:	f903e3e2 	str	x2, [sp, #1984]
    c1fc:	97ffe551 	bl	5740 <fwp_data.part.0.constprop.0>
    c200:	97ffe5bd 	bl	58f4 <fwp_rc_fresh>
    c204:	aa0003e2 	mov	x2, x0
    c208:	911f23e1 	add	x1, sp, #0x7c8
    c20c:	52800020 	mov	w0, #0x1                   	// #1
    c210:	f903e7f7 	str	x23, [sp, #1992]
    c214:	f903ebe2 	str	x2, [sp, #2000]
    c218:	97ffe54a 	bl	5740 <fwp_data.part.0.constprop.0>
    c21c:	9117c283 	add	x3, x20, #0x5f0
    c220:	aa0003f5 	mov	x21, x0
    c224:	f949d861 	ldr	x1, [x3, #5040]
    c228:	f949ec60 	ldr	x0, [x3, #5080]
    c22c:	cb0102a1 	sub	x1, x21, x1
    c230:	eb00403f 	cmp	x1, x0, lsl #16
    c234:	54000322 	b.cs	c298 <f0+0x20b8>  // b.hs, b.nlast
    c238:	d350fc22 	lsr	x2, x1, #16
    c23c:	f949fc63 	ldr	x3, [x3, #5112]
    c240:	8b020842 	add	x2, x2, x2, lsl #2
    c244:	d37df042 	lsl	x2, x2, #3
    c248:	8b020060 	add	x0, x3, x2
    c24c:	f9401017 	ldr	x23, [x0, #32]
    c250:	b4000257 	cbz	x23, c298 <f0+0x20b8>
    c254:	38626862 	ldrb	w2, [x3, x2]
    c258:	7100085f 	cmp	w2, #0x2
    c25c:	540019a0 	b.eq	c590 <f0+0x23b0>  // b.none
    c260:	7100045f 	cmp	w2, #0x1
    c264:	540001a1 	b.ne	c298 <f0+0x20b8>  // b.any
    c268:	29430002 	ldp	w2, w0, [x0, #24]
    c26c:	92403c21 	and	x1, x1, #0xffff
    c270:	9b027c21 	mul	x1, x1, x2
    c274:	d360fc21 	lsr	x1, x1, #32
    c278:	eb00003f 	cmp	x1, x0
    c27c:	540000e2 	b.cs	c298 <f0+0x20b8>  // b.hs, b.nlast
    c280:	8b0102f7 	add	x23, x23, x1
    c284:	394002e0 	ldrb	w0, [x23]
    c288:	7103fc1f 	cmp	w0, #0xff
    c28c:	54002c00 	b.eq	c80c <f0+0x262c>  // b.none
    c290:	52800020 	mov	w0, #0x1                   	// #1
    c294:	390002e0 	strb	w0, [x23]
    c298:	9117c294 	add	x20, x20, #0x5f0
    c29c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c2a0:	911f63e1 	add	x1, sp, #0x7d8
    c2a4:	52800020 	mov	w0, #0x1                   	// #1
    c2a8:	f903efe2 	str	x2, [sp, #2008]
    c2ac:	f903f3f5 	str	x21, [sp, #2016]
    c2b0:	97ffe524 	bl	5740 <fwp_data.part.0.constprop.0>
    c2b4:	f949da81 	ldr	x1, [x20, #5040]
    c2b8:	aa0003f5 	mov	x21, x0
    c2bc:	f949ee80 	ldr	x0, [x20, #5080]
    c2c0:	cb0102a1 	sub	x1, x21, x1
    c2c4:	eb00403f 	cmp	x1, x0, lsl #16
    c2c8:	54000322 	b.cs	c32c <f0+0x214c>  // b.hs, b.nlast
    c2cc:	d350fc22 	lsr	x2, x1, #16
    c2d0:	f949fe83 	ldr	x3, [x20, #5112]
    c2d4:	8b020842 	add	x2, x2, x2, lsl #2
    c2d8:	d37df042 	lsl	x2, x2, #3
    c2dc:	8b020060 	add	x0, x3, x2
    c2e0:	f9401014 	ldr	x20, [x0, #32]
    c2e4:	b4000254 	cbz	x20, c32c <f0+0x214c>
    c2e8:	38626862 	ldrb	w2, [x3, x2]
    c2ec:	7100085f 	cmp	w2, #0x2
    c2f0:	540014a0 	b.eq	c584 <f0+0x23a4>  // b.none
    c2f4:	7100045f 	cmp	w2, #0x1
    c2f8:	540001a1 	b.ne	c32c <f0+0x214c>  // b.any
    c2fc:	29430002 	ldp	w2, w0, [x0, #24]
    c300:	92403c21 	and	x1, x1, #0xffff
    c304:	9b027c21 	mul	x1, x1, x2
    c308:	d360fc21 	lsr	x1, x1, #32
    c30c:	eb00003f 	cmp	x1, x0
    c310:	540000e2 	b.cs	c32c <f0+0x214c>  // b.hs, b.nlast
    c314:	8b010294 	add	x20, x20, x1
    c318:	39400280 	ldrb	w0, [x20]
    c31c:	7103fc1f 	cmp	w0, #0xff
    c320:	54001920 	b.eq	c644 <f0+0x2464>  // b.none
    c324:	52800020 	mov	w0, #0x1                   	// #1
    c328:	39000280 	strb	w0, [x20]
    c32c:	911fa3e1 	add	x1, sp, #0x7e8
    c330:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c334:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c338:	52800020 	mov	w0, #0x1                   	// #1
    c33c:	f903f7f4 	str	x20, [sp, #2024]
    c340:	f903fbf5 	str	x21, [sp, #2032]
    c344:	97ffe4ff 	bl	5740 <fwp_data.part.0.constprop.0>
    c348:	97ffe56b 	bl	58f4 <fwp_rc_fresh>
    c34c:	aa0003e2 	mov	x2, x0
    c350:	911fe3e1 	add	x1, sp, #0x7f8
    c354:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c358:	52800020 	mov	w0, #0x1                   	// #1
    c35c:	f903fff5 	str	x21, [sp, #2040]
    c360:	f90403e2 	str	x2, [sp, #2048]
    c364:	97ffe4f7 	bl	5740 <fwp_data.part.0.constprop.0>
    c368:	97ffe563 	bl	58f4 <fwp_rc_fresh>
    c36c:	aa0003e2 	mov	x2, x0
    c370:	912023e1 	add	x1, sp, #0x808
    c374:	52800020 	mov	w0, #0x1                   	// #1
    c378:	f90407f4 	str	x20, [sp, #2056]
    c37c:	f9040be2 	str	x2, [sp, #2064]
    c380:	97ffe4f0 	bl	5740 <fwp_data.part.0.constprop.0>
    c384:	97ffe55c 	bl	58f4 <fwp_rc_fresh>
    c388:	aa0003e2 	mov	x2, x0
    c38c:	912063e1 	add	x1, sp, #0x818
    c390:	52800020 	mov	w0, #0x1                   	// #1
    c394:	f9040ff5 	str	x21, [sp, #2072]
    c398:	f90413e2 	str	x2, [sp, #2080]
    c39c:	97ffe4e9 	bl	5740 <fwp_data.part.0.constprop.0>
    c3a0:	97ffe555 	bl	58f4 <fwp_rc_fresh>
    c3a4:	aa0003e2 	mov	x2, x0
    c3a8:	9120a3e1 	add	x1, sp, #0x828
    c3ac:	52800020 	mov	w0, #0x1                   	// #1
    c3b0:	f90417f4 	str	x20, [sp, #2088]
    c3b4:	f9041be2 	str	x2, [sp, #2096]
    c3b8:	97ffe4e2 	bl	5740 <fwp_data.part.0.constprop.0>
    c3bc:	97ffe54e 	bl	58f4 <fwp_rc_fresh>
    c3c0:	aa0003e2 	mov	x2, x0
    c3c4:	9120e3e1 	add	x1, sp, #0x838
    c3c8:	52800020 	mov	w0, #0x1                   	// #1
    c3cc:	f9041ff5 	str	x21, [sp, #2104]
    c3d0:	f90423e2 	str	x2, [sp, #2112]
    c3d4:	97ffe4db 	bl	5740 <fwp_data.part.0.constprop.0>
    c3d8:	97ffe547 	bl	58f4 <fwp_rc_fresh>
    c3dc:	aa0003e2 	mov	x2, x0
    c3e0:	aa1603e1 	mov	x1, x22
    c3e4:	52800020 	mov	w0, #0x1                   	// #1
    c3e8:	f90427f4 	str	x20, [sp, #2120]
    c3ec:	f9042be2 	str	x2, [sp, #2128]
    c3f0:	97ffe4d4 	bl	5740 <fwp_data.part.0.constprop.0>
    c3f4:	97ffe540 	bl	58f4 <fwp_rc_fresh>
    c3f8:	aa0003f5 	mov	x21, x0
    c3fc:	aa1303e1 	mov	x1, x19
    c400:	97fff484 	bl	9610 <fwp_hof0.constprop.0>
    c404:	aa0003f4 	mov	x20, x0
    c408:	aa1503e0 	mov	x0, x21
    c40c:	97ffe695 	bl	5e60 <fwp_drop0>
    c410:	aa1303e0 	mov	x0, x19
    c414:	97ffe693 	bl	5e60 <fwp_drop0>
    c418:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c41c:	f947f400 	ldr	x0, [x0, #4072]
    c420:	f9442fe2 	ldr	x2, [sp, #2136]
    c424:	f9400001 	ldr	x1, [x0]
    c428:	eb010042 	subs	x2, x2, x1
    c42c:	d2800001 	mov	x1, #0x0                   	// #0
    c430:	54001f41 	b.ne	c818 <f0+0x2638>  // b.any
    c434:	912183ff 	add	sp, sp, #0x860
    c438:	aa1403e0 	mov	x0, x20
    c43c:	a94153f3 	ldp	x19, x20, [sp, #16]
    c440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c444:	a94363f7 	ldp	x23, x24, [sp, #48]
    c448:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c44c:	a94573fb 	ldp	x27, x28, [sp, #80]
    c450:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c454:	d65f03c0 	ret
    c458:	aa1b03e0 	mov	x0, x27
    c45c:	97ffe0f9 	bl	4840 <fwp_rc_forget_slot>
    c460:	17fff7a8 	b	a300 <f0+0x120>
    c464:	72003c5f 	tst	w2, #0xffff
    c468:	54fef4e1 	b.ne	a304 <f0+0x124>  // b.any
    c46c:	17fff7a2 	b	a2f4 <f0+0x114>
    c470:	72003c3f 	tst	w1, #0xffff
    c474:	54ff9401 	b.ne	b6f4 <f0+0x1514>  // b.any
    c478:	17fffc9a 	b	b6e0 <f0+0x1500>
    c47c:	72003c3f 	tst	w1, #0xffff
    c480:	54ff8f01 	b.ne	b660 <f0+0x1480>  // b.any
    c484:	17fffc72 	b	b64c <f0+0x146c>
    c488:	72003c3f 	tst	w1, #0xffff
    c48c:	54ff8801 	b.ne	b58c <f0+0x13ac>  // b.any
    c490:	17fffc3a 	b	b578 <f0+0x1398>
    c494:	72003c3f 	tst	w1, #0xffff
    c498:	54ff81e1 	b.ne	b4d4 <f0+0x12f4>  // b.any
    c49c:	17fffc09 	b	b4c0 <f0+0x12e0>
    c4a0:	72003c3f 	tst	w1, #0xffff
    c4a4:	54ff7bc1 	b.ne	b41c <f0+0x123c>  // b.any
    c4a8:	17fffbd8 	b	b408 <f0+0x1228>
    c4ac:	72003c3f 	tst	w1, #0xffff
    c4b0:	54ff76c1 	b.ne	b388 <f0+0x11a8>  // b.any
    c4b4:	17fffbb0 	b	b374 <f0+0x1194>
    c4b8:	72003c3f 	tst	w1, #0xffff
    c4bc:	54ff6e01 	b.ne	b27c <f0+0x109c>  // b.any
    c4c0:	17fffb6a 	b	b268 <f0+0x1088>
    c4c4:	72003c3f 	tst	w1, #0xffff
    c4c8:	54ff67e1 	b.ne	b1c4 <f0+0xfe4>  // b.any
    c4cc:	17fffb39 	b	b1b0 <f0+0xfd0>
    c4d0:	72003c3f 	tst	w1, #0xffff
    c4d4:	54ff0641 	b.ne	a59c <f0+0x3bc>  // b.any
    c4d8:	17fff82c 	b	a588 <f0+0x3a8>
    c4dc:	72003c3f 	tst	w1, #0xffff
    c4e0:	54fefee1 	b.ne	a4bc <f0+0x2dc>  // b.any
    c4e4:	17fff7f1 	b	a4a8 <f0+0x2c8>
    c4e8:	72003c3f 	tst	w1, #0xffff
    c4ec:	54fef901 	b.ne	a40c <f0+0x22c>  // b.any
    c4f0:	17fff7c2 	b	a3f8 <f0+0x218>
    c4f4:	72003c3f 	tst	w1, #0xffff
    c4f8:	54ff1ac1 	b.ne	a850 <f0+0x670>  // b.any
    c4fc:	17fff8d0 	b	a83c <f0+0x65c>
    c500:	72003c3f 	tst	w1, #0xffff
    c504:	54ff15e1 	b.ne	a7c0 <f0+0x5e0>  // b.any
    c508:	17fff8a9 	b	a7ac <f0+0x5cc>
    c50c:	72003c3f 	tst	w1, #0xffff
    c510:	54ff10e1 	b.ne	a72c <f0+0x54c>  // b.any
    c514:	17fff881 	b	a718 <f0+0x538>
    c518:	72003c3f 	tst	w1, #0xffff
    c51c:	54ff0981 	b.ne	a64c <f0+0x46c>  // b.any
    c520:	17fff846 	b	a638 <f0+0x458>
    c524:	72003c3f 	tst	w1, #0xffff
    c528:	54ff6041 	b.ne	b130 <f0+0xf50>  // b.any
    c52c:	17fffafc 	b	b11c <f0+0xf3c>
    c530:	72003c3f 	tst	w1, #0xffff
    c534:	54ff5b21 	b.ne	b098 <f0+0xeb8>  // b.any
    c538:	17fffad3 	b	b084 <f0+0xea4>
    c53c:	72003c3f 	tst	w1, #0xffff
    c540:	54ff5501 	b.ne	afe0 <f0+0xe00>  // b.any
    c544:	17fffaa2 	b	afcc <f0+0xdec>
    c548:	72003c3f 	tst	w1, #0xffff
    c54c:	54ff3d61 	b.ne	acf8 <f0+0xb18>  // b.any
    c550:	17fff9e5 	b	ace4 <f0+0xb04>
    c554:	72003c3f 	tst	w1, #0xffff
    c558:	54ff3861 	b.ne	ac64 <f0+0xa84>  // b.any
    c55c:	17fff9bd 	b	ac50 <f0+0xa70>
    c560:	72003c3f 	tst	w1, #0xffff
    c564:	54ff3341 	b.ne	abcc <f0+0x9ec>  // b.any
    c568:	17fff994 	b	abb8 <f0+0x9d8>
    c56c:	72003c3f 	tst	w1, #0xffff
    c570:	54ff2e41 	b.ne	ab38 <f0+0x958>  // b.any
    c574:	17fff96c 	b	ab24 <f0+0x944>
    c578:	72003c3f 	tst	w1, #0xffff
    c57c:	54ff1b41 	b.ne	a8e4 <f0+0x704>  // b.any
    c580:	17fff8d4 	b	a8d0 <f0+0x6f0>
    c584:	72003c3f 	tst	w1, #0xffff
    c588:	54ffed21 	b.ne	c32c <f0+0x214c>  // b.any
    c58c:	17ffff63 	b	c318 <f0+0x2138>
    c590:	72003c3f 	tst	w1, #0xffff
    c594:	54ffe821 	b.ne	c298 <f0+0x20b8>  // b.any
    c598:	17ffff3b 	b	c284 <f0+0x20a4>
    c59c:	72003c3f 	tst	w1, #0xffff
    c5a0:	54ffe121 	b.ne	c1c4 <f0+0x1fe4>  // b.any
    c5a4:	17ffff03 	b	c1b0 <f0+0x1fd0>
    c5a8:	72003c3f 	tst	w1, #0xffff
    c5ac:	54ffd861 	b.ne	c0b8 <f0+0x1ed8>  // b.any
    c5b0:	17fffebd 	b	c0a4 <f0+0x1ec4>
    c5b4:	72003c3f 	tst	w1, #0xffff
    c5b8:	54ffd341 	b.ne	c020 <f0+0x1e40>  // b.any
    c5bc:	17fffe94 	b	c00c <f0+0x1e2c>
    c5c0:	72003c3f 	tst	w1, #0xffff
    c5c4:	54ffce41 	b.ne	bf8c <f0+0x1dac>  // b.any
    c5c8:	17fffe6c 	b	bf78 <f0+0x1d98>
    c5cc:	72003c3f 	tst	w1, #0xffff
    c5d0:	54ffc921 	b.ne	bef4 <f0+0x1d14>  // b.any
    c5d4:	17fffe43 	b	bee0 <f0+0x1d00>
    c5d8:	72003c3f 	tst	w1, #0xffff
    c5dc:	54ffc141 	b.ne	be04 <f0+0x1c24>  // b.any
    c5e0:	17fffe04 	b	bdf0 <f0+0x1c10>
    c5e4:	72003c3f 	tst	w1, #0xffff
    c5e8:	54ffbc41 	b.ne	bd70 <f0+0x1b90>  // b.any
    c5ec:	17fffddc 	b	bd5c <f0+0x1b7c>
    c5f0:	72003c3f 	tst	w1, #0xffff
    c5f4:	54ffb381 	b.ne	bc64 <f0+0x1a84>  // b.any
    c5f8:	17fffd96 	b	bc50 <f0+0x1a70>
    c5fc:	72003c3f 	tst	w1, #0xffff
    c600:	54ffad61 	b.ne	bbac <f0+0x19cc>  // b.any
    c604:	17fffd65 	b	bb98 <f0+0x19b8>
    c608:	72003c3f 	tst	w1, #0xffff
    c60c:	54ffa861 	b.ne	bb18 <f0+0x1938>  // b.any
    c610:	17fffd3d 	b	bb04 <f0+0x1924>
    c614:	72003c3f 	tst	w1, #0xffff
    c618:	54ffa161 	b.ne	ba44 <f0+0x1864>  // b.any
    c61c:	17fffd05 	b	ba30 <f0+0x1850>
    c620:	72003c3f 	tst	w1, #0xffff
    c624:	54ff98a1 	b.ne	b938 <f0+0x1758>  // b.any
    c628:	17fffcbf 	b	b924 <f0+0x1744>
    c62c:	72003c3f 	tst	w1, #0xffff
    c630:	54ff91a1 	b.ne	b864 <f0+0x1684>  // b.any
    c634:	17fffc87 	b	b850 <f0+0x1670>
    c638:	72003c3f 	tst	w1, #0xffff
    c63c:	54ff8b81 	b.ne	b7ac <f0+0x15cc>  // b.any
    c640:	17fffc56 	b	b798 <f0+0x15b8>
    c644:	aa1403e0 	mov	x0, x20
    c648:	97ffe07e 	bl	4840 <fwp_rc_forget_slot>
    c64c:	17ffff36 	b	c324 <f0+0x2144>
    c650:	aa1703e0 	mov	x0, x23
    c654:	97ffe07b 	bl	4840 <fwp_rc_forget_slot>
    c658:	17fff76b 	b	a404 <f0+0x224>
    c65c:	aa1703e0 	mov	x0, x23
    c660:	97ffe078 	bl	4840 <fwp_rc_forget_slot>
    c664:	17fff794 	b	a4b4 <f0+0x2d4>
    c668:	aa1703e0 	mov	x0, x23
    c66c:	97ffe075 	bl	4840 <fwp_rc_forget_slot>
    c670:	17fff7c9 	b	a594 <f0+0x3b4>
    c674:	aa1703e0 	mov	x0, x23
    c678:	97ffe072 	bl	4840 <fwp_rc_forget_slot>
    c67c:	17fff7f2 	b	a644 <f0+0x464>
    c680:	aa1703e0 	mov	x0, x23
    c684:	97ffe06f 	bl	4840 <fwp_rc_forget_slot>
    c688:	17fff827 	b	a724 <f0+0x544>
    c68c:	aa1703e0 	mov	x0, x23
    c690:	97ffe06c 	bl	4840 <fwp_rc_forget_slot>
    c694:	17fff849 	b	a7b8 <f0+0x5d8>
    c698:	aa1703e0 	mov	x0, x23
    c69c:	97ffe069 	bl	4840 <fwp_rc_forget_slot>
    c6a0:	17fff86a 	b	a848 <f0+0x668>
    c6a4:	aa1703e0 	mov	x0, x23
    c6a8:	97ffe066 	bl	4840 <fwp_rc_forget_slot>
    c6ac:	17fff88c 	b	a8dc <f0+0x6fc>
    c6b0:	aa1703e0 	mov	x0, x23
    c6b4:	97ffe063 	bl	4840 <fwp_rc_forget_slot>
    c6b8:	17fff91e 	b	ab30 <f0+0x950>
    c6bc:	aa1703e0 	mov	x0, x23
    c6c0:	97ffe060 	bl	4840 <fwp_rc_forget_slot>
    c6c4:	17fff940 	b	abc4 <f0+0x9e4>
    c6c8:	aa1703e0 	mov	x0, x23
    c6cc:	97ffe05d 	bl	4840 <fwp_rc_forget_slot>
    c6d0:	17fff963 	b	ac5c <f0+0xa7c>
    c6d4:	aa1703e0 	mov	x0, x23
    c6d8:	97ffe05a 	bl	4840 <fwp_rc_forget_slot>
    c6dc:	17fff985 	b	acf0 <f0+0xb10>
    c6e0:	aa1703e0 	mov	x0, x23
    c6e4:	97ffe057 	bl	4840 <fwp_rc_forget_slot>
    c6e8:	17fffa3c 	b	afd8 <f0+0xdf8>
    c6ec:	aa1703e0 	mov	x0, x23
    c6f0:	97ffe054 	bl	4840 <fwp_rc_forget_slot>
    c6f4:	17fffa67 	b	b090 <f0+0xeb0>
    c6f8:	aa1703e0 	mov	x0, x23
    c6fc:	97ffe051 	bl	4840 <fwp_rc_forget_slot>
    c700:	17fffa8a 	b	b128 <f0+0xf48>
    c704:	aa1703e0 	mov	x0, x23
    c708:	97ffe04e 	bl	4840 <fwp_rc_forget_slot>
    c70c:	17fffaac 	b	b1bc <f0+0xfdc>
    c710:	aa1703e0 	mov	x0, x23
    c714:	97ffe04b 	bl	4840 <fwp_rc_forget_slot>
    c718:	17fffad7 	b	b274 <f0+0x1094>
    c71c:	aa1703e0 	mov	x0, x23
    c720:	97ffe048 	bl	4840 <fwp_rc_forget_slot>
    c724:	17fffb17 	b	b380 <f0+0x11a0>
    c728:	aa1703e0 	mov	x0, x23
    c72c:	97ffe045 	bl	4840 <fwp_rc_forget_slot>
    c730:	17fffb39 	b	b414 <f0+0x1234>
    c734:	aa1703e0 	mov	x0, x23
    c738:	97ffe042 	bl	4840 <fwp_rc_forget_slot>
    c73c:	17fffb64 	b	b4cc <f0+0x12ec>
    c740:	aa1703e0 	mov	x0, x23
    c744:	97ffe03f 	bl	4840 <fwp_rc_forget_slot>
    c748:	17fffb8f 	b	b584 <f0+0x13a4>
    c74c:	aa1703e0 	mov	x0, x23
    c750:	97ffe03c 	bl	4840 <fwp_rc_forget_slot>
    c754:	17fffbc1 	b	b658 <f0+0x1478>
    c758:	aa1703e0 	mov	x0, x23
    c75c:	97ffe039 	bl	4840 <fwp_rc_forget_slot>
    c760:	17fffbe3 	b	b6ec <f0+0x150c>
    c764:	aa1703e0 	mov	x0, x23
    c768:	97ffe036 	bl	4840 <fwp_rc_forget_slot>
    c76c:	17fffc0e 	b	b7a4 <f0+0x15c4>
    c770:	aa1703e0 	mov	x0, x23
    c774:	97ffe033 	bl	4840 <fwp_rc_forget_slot>
    c778:	17fffc39 	b	b85c <f0+0x167c>
    c77c:	aa1703e0 	mov	x0, x23
    c780:	97ffe030 	bl	4840 <fwp_rc_forget_slot>
    c784:	17fffc6b 	b	b930 <f0+0x1750>
    c788:	aa1703e0 	mov	x0, x23
    c78c:	97ffe02d 	bl	4840 <fwp_rc_forget_slot>
    c790:	17fffcab 	b	ba3c <f0+0x185c>
    c794:	aa1703e0 	mov	x0, x23
    c798:	97ffe02a 	bl	4840 <fwp_rc_forget_slot>
    c79c:	17fffcdd 	b	bb10 <f0+0x1930>
    c7a0:	aa1703e0 	mov	x0, x23
    c7a4:	97ffe027 	bl	4840 <fwp_rc_forget_slot>
    c7a8:	17fffcff 	b	bba4 <f0+0x19c4>
    c7ac:	aa1703e0 	mov	x0, x23
    c7b0:	97ffe024 	bl	4840 <fwp_rc_forget_slot>
    c7b4:	17fffd2a 	b	bc5c <f0+0x1a7c>
    c7b8:	aa1703e0 	mov	x0, x23
    c7bc:	97ffe021 	bl	4840 <fwp_rc_forget_slot>
    c7c0:	17fffd6a 	b	bd68 <f0+0x1b88>
    c7c4:	aa1703e0 	mov	x0, x23
    c7c8:	97ffe01e 	bl	4840 <fwp_rc_forget_slot>
    c7cc:	17fffd8c 	b	bdfc <f0+0x1c1c>
    c7d0:	aa1703e0 	mov	x0, x23
    c7d4:	97ffe01b 	bl	4840 <fwp_rc_forget_slot>
    c7d8:	17fffdc5 	b	beec <f0+0x1d0c>
    c7dc:	aa1703e0 	mov	x0, x23
    c7e0:	97ffe018 	bl	4840 <fwp_rc_forget_slot>
    c7e4:	17fffde8 	b	bf84 <f0+0x1da4>
    c7e8:	aa1703e0 	mov	x0, x23
    c7ec:	97ffe015 	bl	4840 <fwp_rc_forget_slot>
    c7f0:	17fffe0a 	b	c018 <f0+0x1e38>
    c7f4:	aa1703e0 	mov	x0, x23
    c7f8:	97ffe012 	bl	4840 <fwp_rc_forget_slot>
    c7fc:	17fffe2d 	b	c0b0 <f0+0x1ed0>
    c800:	aa1703e0 	mov	x0, x23
    c804:	97ffe00f 	bl	4840 <fwp_rc_forget_slot>
    c808:	17fffe6d 	b	c1bc <f0+0x1fdc>
    c80c:	aa1703e0 	mov	x0, x23
    c810:	97ffe00c 	bl	4840 <fwp_rc_forget_slot>
    c814:	17fffe9f 	b	c290 <f0+0x20b0>
    c818:	97ffd81a 	bl	2880 <__stack_chk_fail@plt>
    c81c:	d503201f 	nop

000000000000c820 <fwp_main_thread>:
    c820:	d10443ff 	sub	sp, sp, #0x110
    c824:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c828:	f947f400 	ldr	x0, [x0, #4072]
    c82c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c830:	910303fd 	add	x29, sp, #0xc0
    c834:	a90d53f3 	stp	x19, x20, [sp, #208]
    c838:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    c83c:	9117c261 	add	x1, x19, #0x5f0
    c840:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c844:	b953a421 	ldr	w1, [x1, #5028]
    c848:	f9400002 	ldr	x2, [x0]
    c84c:	f9005fe2 	str	x2, [sp, #184]
    c850:	d2800002 	mov	x2, #0x0                   	// #0
    c854:	34002821 	cbz	w1, cd58 <fwp_main_thread+0x538>
    c858:	9117c273 	add	x19, x19, #0x5f0
    c85c:	b953aa60 	ldr	w0, [x19, #5032]
    c860:	35002740 	cbnz	w0, cd48 <fwp_main_thread+0x528>
    c864:	91001fe2 	add	x2, sp, #0x7
    c868:	900000b5 	adrp	x21, 20000 <__data_start>
    c86c:	900000a3 	adrp	x3, 20000 <__data_start>
    c870:	9101c2b3 	add	x19, x21, #0x70
    c874:	91104063 	add	x3, x3, #0x410
    c878:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c87c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c880:	910023e0 	add	x0, sp, #0x8
    c884:	d2800001 	mov	x1, #0x0                   	// #0
    c888:	f90007e3 	str	x3, [sp, #8]
    c88c:	b90013ff 	str	wzr, [sp, #16]
    c890:	a9019262 	stp	x2, x4, [x19, #24]
    c894:	f9000fe5 	str	x5, [sp, #24]
    c898:	97ffd792 	bl	26e0 <sigaltstack@plt>
    c89c:	350026e0 	cbnz	w0, cd78 <fwp_main_thread+0x558>
    c8a0:	4f000400 	movi	v0.4s, #0x0
    c8a4:	9100a3e0 	add	x0, sp, #0x28
    c8a8:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c8ac:	52800082 	mov	w2, #0x4                   	// #4
    c8b0:	9101c021 	add	x1, x1, #0x70
    c8b4:	72a10002 	movk	w2, #0x800, lsl #16
    c8b8:	910083f4 	add	x20, sp, #0x20
    c8bc:	f90013e1 	str	x1, [sp, #32]
    c8c0:	3d802000 	str	q0, [x0, #128]
    c8c4:	b900abe2 	str	w2, [sp, #168]
    c8c8:	ad000000 	stp	q0, q0, [x0]
    c8cc:	ad010000 	stp	q0, q0, [x0, #32]
    c8d0:	ad020000 	stp	q0, q0, [x0, #64]
    c8d4:	ad030000 	stp	q0, q0, [x0, #96]
    c8d8:	97ffd7da 	bl	2840 <sigemptyset@plt>
    c8dc:	350024e0 	cbnz	w0, cd78 <fwp_main_thread+0x558>
    c8e0:	aa1403e1 	mov	x1, x20
    c8e4:	d2800002 	mov	x2, #0x0                   	// #0
    c8e8:	52800160 	mov	w0, #0xb                   	// #11
    c8ec:	97ffd7ed 	bl	28a0 <sigaction@plt>
    c8f0:	35002440 	cbnz	w0, cd78 <fwp_main_thread+0x558>
    c8f4:	aa1403e1 	mov	x1, x20
    c8f8:	d2800002 	mov	x2, #0x0                   	// #0
    c8fc:	528000e0 	mov	w0, #0x7                   	// #7
    c900:	97ffd7e8 	bl	28a0 <sigaction@plt>
    c904:	350023a0 	cbnz	w0, cd78 <fwp_main_thread+0x558>
    c908:	b9436a60 	ldr	w0, [x19, #872]
    c90c:	34002000 	cbz	w0, cd0c <fwp_main_thread+0x4ec>
    c910:	9101c2b3 	add	x19, x21, #0x70
    c914:	a90f63f7 	stp	x23, x24, [sp, #240]
    c918:	b9436e60 	ldr	w0, [x19, #876]
    c91c:	340020c0 	cbz	w0, cd34 <fwp_main_thread+0x514>
    c920:	9101c2b6 	add	x22, x21, #0x70
    c924:	f9400ad4 	ldr	x20, [x22, #16]
    c928:	b40010f4 	cbz	x20, cb44 <fwp_main_thread+0x324>
    c92c:	aa1403f3 	mov	x19, x20
    c930:	91010297 	add	x23, x20, #0x40
    c934:	f90083f9 	str	x25, [sp, #256]
    c938:	52800038 	mov	w24, #0x1                   	// #1
    c93c:	39414a99 	ldrb	w25, [x20, #82]
    c940:	39014a98 	strb	w24, [x20, #82]
    c944:	f9401680 	ldr	x0, [x20, #40]
    c948:	b4000620 	cbz	x0, ca0c <fwp_main_thread+0x1ec>
    c94c:	f9403281 	ldr	x1, [x20, #96]
    c950:	39414680 	ldrb	w0, [x20, #81]
    c954:	b4000b61 	cbz	x1, cac0 <fwp_main_thread+0x2a0>
    c958:	36000aa0 	tbz	w0, #0, caac <fwp_main_thread+0x28c>
    c95c:	39414a62 	ldrb	w2, [x19, #82]
    c960:	f9402280 	ldr	x0, [x20, #64]
    c964:	37000d82 	tbnz	w2, #0, cb14 <fwp_main_thread+0x2f4>
    c968:	f9403261 	ldr	x1, [x19, #96]
    c96c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c970:	f9009660 	str	x0, [x19, #296]
    c974:	b4000040 	cbz	x0, c97c <fwp_main_thread+0x15c>
    c978:	f9009013 	str	x19, [x0, #288]
    c97c:	f9002293 	str	x19, [x20, #64]
    c980:	b4000101 	cbz	x1, c9a0 <fwp_main_thread+0x180>
    c984:	f9407ec0 	ldr	x0, [x22, #248]
    c988:	39015678 	strb	w24, [x19, #85]
    c98c:	f9003661 	str	x1, [x19, #104]
    c990:	a910827f 	stp	xzr, x0, [x19, #264]
    c994:	b4000040 	cbz	x0, c99c <fwp_main_thread+0x17c>
    c998:	f9008413 	str	x19, [x0, #264]
    c99c:	f9007ed3 	str	x19, [x22, #248]
    c9a0:	39015a7f 	strb	wzr, [x19, #86]
    c9a4:	97ffe768 	bl	6744 <fwp_block>
    c9a8:	f9408e62 	ldr	x2, [x19, #280]
    c9ac:	b4000142 	cbz	x2, c9d4 <fwp_main_thread+0x1b4>
    c9b0:	a9520261 	ldp	x1, x0, [x19, #288]
    c9b4:	b4000bc1 	cbz	x1, cb2c <fwp_main_thread+0x30c>
    c9b8:	f9009420 	str	x0, [x1, #296]
    c9bc:	f9409660 	ldr	x0, [x19, #296]
    c9c0:	b4000040 	cbz	x0, c9c8 <fwp_main_thread+0x1a8>
    c9c4:	f9009001 	str	x1, [x0, #288]
    c9c8:	91080260 	add	x0, x19, #0x200
    c9cc:	f900967f 	str	xzr, [x19, #296]
    c9d0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c9d4:	39415660 	ldrb	w0, [x19, #85]
    c9d8:	f9400ac2 	ldr	x2, [x22, #16]
    c9dc:	36000980 	tbz	w0, #0, cb0c <fwp_main_thread+0x2ec>
    c9e0:	a9508261 	ldp	x1, x0, [x19, #264]
    c9e4:	b4000a81 	cbz	x1, cb34 <fwp_main_thread+0x314>
    c9e8:	f9008820 	str	x0, [x1, #272]
    c9ec:	b4000040 	cbz	x0, c9f4 <fwp_main_thread+0x1d4>
    c9f0:	f9008401 	str	x1, [x0, #264]
    c9f4:	91080260 	add	x0, x19, #0x200
    c9f8:	3901567f 	strb	wzr, [x19, #85]
    c9fc:	aa0203f3 	mov	x19, x2
    ca00:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    ca04:	f9401680 	ldr	x0, [x20, #40]
    ca08:	b5fffa20 	cbnz	x0, c94c <fwp_main_thread+0x12c>
    ca0c:	9101c2a0 	add	x0, x21, #0x70
    ca10:	39014a99 	strb	w25, [x20, #82]
    ca14:	f94083f9 	ldr	x25, [sp, #256]
    ca18:	f941a400 	ldr	x0, [x0, #840]
    ca1c:	b4001580 	cbz	x0, cccc <fwp_main_thread+0x4ac>
    ca20:	9101c2a0 	add	x0, x21, #0x70
    ca24:	f941c001 	ldr	x1, [x0, #896]
    ca28:	b903781f 	str	wzr, [x0, #888]
    ca2c:	eb13003f 	cmp	x1, x19
    ca30:	540016a1 	b.ne	cd04 <fwp_main_thread+0x4e4>  // b.any
    ca34:	b4000933 	cbz	x19, cb58 <fwp_main_thread+0x338>
    ca38:	9101c2a0 	add	x0, x21, #0x70
    ca3c:	52800021 	mov	w1, #0x1                   	// #1
    ca40:	39014a61 	strb	w1, [x19, #82]
    ca44:	f9419005 	ldr	x5, [x0, #800]
    ca48:	b4000885 	cbz	x5, cb58 <fwp_main_thread+0x338>
    ca4c:	d503201f 	nop
    ca50:	394140a0 	ldrb	w0, [x5, #80]
    ca54:	37000060 	tbnz	w0, #0, ca60 <fwp_main_thread+0x240>
    ca58:	aa0503e0 	mov	x0, x5
    ca5c:	97ffdb25 	bl	36f0 <fwp_cancel_tree.part.0>
    ca60:	f9409ca5 	ldr	x5, [x5, #312]
    ca64:	b5ffff65 	cbnz	x5, ca50 <fwp_main_thread+0x230>
    ca68:	9101c2b4 	add	x20, x21, #0x70
    ca6c:	52800036 	mov	w22, #0x1                   	// #1
    ca70:	f9402a60 	ldr	x0, [x19, #80]
    ca74:	f2001c1f 	tst	x0, #0xff000000ff
    ca78:	540000e1 	b.ne	ca94 <fwp_main_thread+0x274>  // b.any
    ca7c:	f9403e80 	ldr	x0, [x20, #120]
    ca80:	39015276 	strb	w22, [x19, #84]
    ca84:	f900827f 	str	xzr, [x19, #256]
    ca88:	b40005a0 	cbz	x0, cb3c <fwp_main_thread+0x31c>
    ca8c:	f9008013 	str	x19, [x0, #256]
    ca90:	f9003e93 	str	x19, [x20, #120]
    ca94:	97ffe72c 	bl	6744 <fwp_block>
    ca98:	97ffe6be 	bl	6590 <fwp_free_zombie>
    ca9c:	f9419280 	ldr	x0, [x20, #800]
    caa0:	b40005c0 	cbz	x0, cb58 <fwp_main_thread+0x338>
    caa4:	f941c293 	ldr	x19, [x20, #896]
    caa8:	17fffff2 	b	ca70 <fwp_main_thread+0x250>
    caac:	97ffdbb5 	bl	3980 <fwp_now_ns>
    cab0:	f9403281 	ldr	x1, [x20, #96]
    cab4:	eb01001f 	cmp	x0, x1
    cab8:	54000fca 	b.ge	ccb0 <fwp_main_thread+0x490>  // b.tcont
    cabc:	39414680 	ldrb	w0, [x20, #81]
    cac0:	39414a62 	ldrb	w2, [x19, #82]
    cac4:	3707f4e0 	tbnz	w0, #0, c960 <fwp_main_thread+0x140>
    cac8:	f9403281 	ldr	x1, [x20, #96]
    cacc:	370001c2 	tbnz	w2, #0, cb04 <fwp_main_thread+0x2e4>
    cad0:	f9403260 	ldr	x0, [x19, #96]
    cad4:	b4000180 	cbz	x0, cb04 <fwp_main_thread+0x2e4>
    cad8:	b4000061 	cbz	x1, cae4 <fwp_main_thread+0x2c4>
    cadc:	eb01001f 	cmp	x0, x1
    cae0:	9a81d000 	csel	x0, x0, x1, le
    cae4:	f9402281 	ldr	x1, [x20, #64]
    cae8:	a911fe77 	stp	x23, xzr, [x19, #280]
    caec:	f9009661 	str	x1, [x19, #296]
    caf0:	b4001381 	cbz	x1, cd60 <fwp_main_thread+0x540>
    caf4:	f9009033 	str	x19, [x1, #288]
    caf8:	aa0003e1 	mov	x1, x0
    cafc:	f9002293 	str	x19, [x20, #64]
    cb00:	17ffffa1 	b	c984 <fwp_main_thread+0x164>
    cb04:	f9402280 	ldr	x0, [x20, #64]
    cb08:	17ffff99 	b	c96c <fwp_main_thread+0x14c>
    cb0c:	aa0203f3 	mov	x19, x2
    cb10:	17ffff8d 	b	c944 <fwp_main_thread+0x124>
    cb14:	a911fe77 	stp	x23, xzr, [x19, #280]
    cb18:	f9009660 	str	x0, [x19, #296]
    cb1c:	b4000040 	cbz	x0, cb24 <fwp_main_thread+0x304>
    cb20:	f9009013 	str	x19, [x0, #288]
    cb24:	f9002293 	str	x19, [x20, #64]
    cb28:	17ffff9e 	b	c9a0 <fwp_main_thread+0x180>
    cb2c:	f9000040 	str	x0, [x2]
    cb30:	17ffffa4 	b	c9c0 <fwp_main_thread+0x1a0>
    cb34:	f9007ec0 	str	x0, [x22, #248]
    cb38:	17ffffad 	b	c9ec <fwp_main_thread+0x1cc>
    cb3c:	f9004293 	str	x19, [x20, #128]
    cb40:	17ffffd4 	b	ca90 <fwp_main_thread+0x270>
    cb44:	f941a6c0 	ldr	x0, [x22, #840]
    cb48:	b4000c00 	cbz	x0, ccc8 <fwp_main_thread+0x4a8>
    cb4c:	f941c2c0 	ldr	x0, [x22, #896]
    cb50:	b9037adf 	str	wzr, [x22, #888]
    cb54:	b5000d80 	cbnz	x0, cd04 <fwp_main_thread+0x4e4>
    cb58:	9101c2b4 	add	x20, x21, #0x70
    cb5c:	97ffe68d 	bl	6590 <fwp_free_zombie>
    cb60:	f9404280 	ldr	x0, [x20, #128]
    cb64:	b5000d00 	cbnz	x0, cd04 <fwp_main_thread+0x4e4>
    cb68:	f9407e80 	ldr	x0, [x20, #248]
    cb6c:	b5000cc0 	cbnz	x0, cd04 <fwp_main_thread+0x4e4>
    cb70:	b9411a93 	ldr	w19, [x20, #280]
    cb74:	340001d3 	cbz	w19, cbac <fwp_main_thread+0x38c>
    cb78:	93407e76 	sxtw	x22, w19
    cb7c:	51000673 	sub	w19, w19, #0x1
    cb80:	d1000ad6 	sub	x22, x22, #0x2
    cb84:	91048297 	add	x23, x20, #0x120
    cb88:	cb3342d6 	sub	x22, x22, w19, uxtw
    cb8c:	93407e73 	sxtw	x19, w19
    cb90:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cb94:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cb98:	b9011a93 	str	w19, [x20, #280]
    cb9c:	d1000673 	sub	x19, x19, #0x1
    cba0:	97ffd780 	bl	29a0 <munmap@plt>
    cba4:	eb16027f 	cmp	x19, x22
    cba8:	54ffff41 	b.ne	cb90 <fwp_main_thread+0x370>  // b.any
    cbac:	900000b3 	adrp	x19, 20000 <__data_start>
    cbb0:	91004260 	add	x0, x19, #0x10
    cbb4:	b9404800 	ldr	w0, [x0, #72]
    cbb8:	37f80040 	tbnz	w0, #31, cbc0 <fwp_main_thread+0x3a0>
    cbbc:	97ffd735 	bl	2890 <close@plt>
    cbc0:	9101c2a0 	add	x0, x21, #0x70
    cbc4:	91004261 	add	x1, x19, #0x10
    cbc8:	12800002 	mov	w2, #0xffffffff            	// #-1
    cbcc:	d2800013 	mov	x19, #0x0                   	// #0
    cbd0:	f941c416 	ldr	x22, [x0, #904]
    cbd4:	b9004822 	str	w2, [x1, #72]
    cbd8:	f941c814 	ldr	x20, [x0, #912]
    cbdc:	b4000176 	cbz	x22, cc08 <fwp_main_thread+0x3e8>
    cbe0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cbe4:	b40000c0 	cbz	x0, cbfc <fwp_main_thread+0x3dc>
    cbe8:	f9400001 	ldr	x1, [x0]
    cbec:	b50008c1 	cbnz	x1, cd04 <fwp_main_thread+0x4e4>
    cbf0:	f9400401 	ldr	x1, [x0, #8]
    cbf4:	b5000881 	cbnz	x1, cd04 <fwp_main_thread+0x4e4>
    cbf8:	97ffdfb2 	bl	4ac0 <fwp_mem_free>
    cbfc:	91000673 	add	x19, x19, #0x1
    cc00:	eb16027f 	cmp	x19, x22
    cc04:	54fffee1 	b.ne	cbe0 <fwp_main_thread+0x3c0>  // b.any
    cc08:	aa1403e0 	mov	x0, x20
    cc0c:	97ffdfad 	bl	4ac0 <fwp_mem_free>
    cc10:	9101c2a0 	add	x0, x21, #0x70
    cc14:	f941c013 	ldr	x19, [x0, #896]
    cc18:	f901c41f 	str	xzr, [x0, #904]
    cc1c:	f901c81f 	str	xzr, [x0, #912]
    cc20:	b40001f3 	cbz	x19, cc5c <fwp_main_thread+0x43c>
    cc24:	f9401661 	ldr	x1, [x19, #40]
    cc28:	b50006e1 	cbnz	x1, cd04 <fwp_main_thread+0x4e4>
    cc2c:	f9405661 	ldr	x1, [x19, #168]
    cc30:	b50006a1 	cbnz	x1, cd04 <fwp_main_thread+0x4e4>
    cc34:	f941a401 	ldr	x1, [x0, #840]
    cc38:	b5000661 	cbnz	x1, cd04 <fwp_main_thread+0x4e4>
    cc3c:	f941ac00 	ldr	x0, [x0, #856]
    cc40:	b5000620 	cbnz	x0, cd04 <fwp_main_thread+0x4e4>
    cc44:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cc48:	90000120 	adrp	x0, 30000 <alt.9+0xfbf0>
    cc4c:	91104000 	add	x0, x0, #0x410
    cc50:	97ffd700 	bl	2850 <memset@plt>
    cc54:	aa1303e0 	mov	x0, x19
    cc58:	97ffdf9a 	bl	4ac0 <fwp_mem_free>
    cc5c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cc60:	f947ec00 	ldr	x0, [x0, #4056]
    cc64:	9101c2b5 	add	x21, x21, #0x70
    cc68:	f9400000 	ldr	x0, [x0]
    cc6c:	f9000abf 	str	xzr, [x21, #16]
    cc70:	f901c2bf 	str	xzr, [x21, #896]
    cc74:	97ffd74f 	bl	29b0 <fflush@plt>
    cc78:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cc7c:	f947f400 	ldr	x0, [x0, #4072]
    cc80:	f9405fe2 	ldr	x2, [sp, #184]
    cc84:	f9400001 	ldr	x1, [x0]
    cc88:	eb010042 	subs	x2, x2, x1
    cc8c:	d2800001 	mov	x1, #0x0                   	// #0
    cc90:	54000821 	b.ne	cd94 <fwp_main_thread+0x574>  // b.any
    cc94:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cc98:	d2800000 	mov	x0, #0x0                   	// #0
    cc9c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cca0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cca4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cca8:	910443ff 	add	sp, sp, #0x110
    ccac:	d65f03c0 	ret
    ccb0:	39414280 	ldrb	w0, [x20, #80]
    ccb4:	3707f040 	tbnz	w0, #0, cabc <fwp_main_thread+0x29c>
    ccb8:	aa1403e0 	mov	x0, x20
    ccbc:	97ffda8d 	bl	36f0 <fwp_cancel_tree.part.0>
    ccc0:	39414680 	ldrb	w0, [x20, #81]
    ccc4:	17ffff7f 	b	cac0 <fwp_main_thread+0x2a0>
    ccc8:	d2800013 	mov	x19, #0x0                   	// #0
    cccc:	9101c2b4 	add	x20, x21, #0x70
    ccd0:	f941ae80 	ldr	x0, [x20, #856]
    ccd4:	b5ffea60 	cbnz	x0, ca20 <fwp_main_thread+0x200>
    ccd8:	f941a280 	ldr	x0, [x20, #832]
    ccdc:	97ffdf79 	bl	4ac0 <fwp_mem_free>
    cce0:	f901a29f 	str	xzr, [x20, #832]
    cce4:	f901aa9f 	str	xzr, [x20, #848]
    cce8:	f941c280 	ldr	x0, [x20, #896]
    ccec:	b4000413 	cbz	x19, cd6c <fwp_main_thread+0x54c>
    ccf0:	f900567f 	str	xzr, [x19, #168]
    ccf4:	f9005e7f 	str	xzr, [x19, #184]
    ccf8:	b9037a9f 	str	wzr, [x20, #888]
    ccfc:	eb00027f 	cmp	x19, x0
    cd00:	54ffe9c0 	b.eq	ca38 <fwp_main_thread+0x218>  // b.none
    cd04:	f90083f9 	str	x25, [sp, #256]
    cd08:	97ffd6f2 	bl	28d0 <abort@plt>
    cd0c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cd10:	91058000 	add	x0, x0, #0x160
    cd14:	940001df 	bl	d490 <atexit>
    cd18:	a90f63f7 	stp	x23, x24, [sp, #240]
    cd1c:	35000380 	cbnz	w0, cd8c <fwp_main_thread+0x56c>
    cd20:	52800020 	mov	w0, #0x1                   	// #1
    cd24:	b9036a60 	str	w0, [x19, #872]
    cd28:	9101c2b3 	add	x19, x21, #0x70
    cd2c:	b9436e60 	ldr	w0, [x19, #876]
    cd30:	35ffdf80 	cbnz	w0, c920 <fwp_main_thread+0x100>
    cd34:	97fff52b 	bl	a1e0 <f0>
    cd38:	f901ba60 	str	x0, [x19, #880]
    cd3c:	52800021 	mov	w1, #0x1                   	// #1
    cd40:	b9036e61 	str	w1, [x19, #876]
    cd44:	17fffef7 	b	c920 <fwp_main_thread+0x100>
    cd48:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cd4c:	913e8000 	add	x0, x0, #0xfa0
    cd50:	940001d0 	bl	d490 <atexit>
    cd54:	17fffec4 	b	c864 <fwp_main_thread+0x44>
    cd58:	97ffdceb 	bl	4104 <fwp_heap_init>
    cd5c:	17fffebf 	b	c858 <fwp_main_thread+0x38>
    cd60:	aa0003e1 	mov	x1, x0
    cd64:	f9002293 	str	x19, [x20, #64]
    cd68:	17ffff07 	b	c984 <fwp_main_thread+0x164>
    cd6c:	b9037a9f 	str	wzr, [x20, #888]
    cd70:	b4ffef40 	cbz	x0, cb58 <fwp_main_thread+0x338>
    cd74:	17ffffe4 	b	cd04 <fwp_main_thread+0x4e4>
    cd78:	b0000000 	adrp	x0, d000 <__divti3+0x260>
    cd7c:	912cc000 	add	x0, x0, #0xb30
    cd80:	a90f63f7 	stp	x23, x24, [sp, #240]
    cd84:	f90083f9 	str	x25, [sp, #256]
    cd88:	97ffda9e 	bl	3800 <fwp_trap>
    cd8c:	f90083f9 	str	x25, [sp, #256]
    cd90:	97ffd8e8 	bl	3130 <descent_phase_fail>
    cd94:	f90083f9 	str	x25, [sp, #256]
    cd98:	97ffd6ba 	bl	2880 <__stack_chk_fail@plt>
    cd9c:	d503201f 	nop

000000000000cda0 <__divti3>:
    cda0:	d503245f 	bti	c
    cda4:	d2800004 	mov	x4, #0x0                   	// #0
    cda8:	b7f80721 	tbnz	x1, #63, ce8c <__divti3+0xec>
    cdac:	b6f80083 	tbz	x3, #63, cdbc <__divti3+0x1c>
    cdb0:	eb0203e2 	negs	x2, x2
    cdb4:	aa2403e4 	mvn	x4, x4
    cdb8:	da0303e3 	ngc	x3, x3
    cdbc:	aa0203e6 	mov	x6, x2
    cdc0:	aa0003e7 	mov	x7, x0
    cdc4:	aa0103e5 	mov	x5, x1
    cdc8:	b5000583 	cbnz	x3, ce78 <__divti3+0xd8>
    cdcc:	eb01005f 	cmp	x2, x1
    cdd0:	54000e69 	b.ls	cf9c <__divti3+0x1fc>  // b.plast
    cdd4:	dac01040 	clz	x0, x2
    cdd8:	b40000e0 	cbz	x0, cdf4 <__divti3+0x54>
    cddc:	4b0003e1 	neg	w1, w0
    cde0:	9ac020a5 	lsl	x5, x5, x0
    cde4:	9ac02046 	lsl	x6, x2, x0
    cde8:	9ac124e1 	lsr	x1, x7, x1
    cdec:	aa050025 	orr	x5, x1, x5
    cdf0:	9ac020e7 	lsl	x7, x7, x0
    cdf4:	d360fcc8 	lsr	x8, x6, #32
    cdf8:	92407cc2 	and	x2, x6, #0xffffffff
    cdfc:	9ac808a3 	udiv	x3, x5, x8
    ce00:	9b089465 	msub	x5, x3, x8, x5
    ce04:	aa0303e0 	mov	x0, x3
    ce08:	9b037c41 	mul	x1, x2, x3
    ce0c:	93c780a5 	extr	x5, x5, x7, #32
    ce10:	eb05003f 	cmp	x1, x5
    ce14:	540000a9 	b.ls	ce28 <__divti3+0x88>  // b.plast
    ce18:	ab0500c5 	adds	x5, x6, x5
    ce1c:	d1000460 	sub	x0, x3, #0x1
    ce20:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ce24:	540015a8 	b.hi	d0d8 <__divti3+0x338>  // b.pmore
    ce28:	cb0100a5 	sub	x5, x5, x1
    ce2c:	9ac808a3 	udiv	x3, x5, x8
    ce30:	9b089465 	msub	x5, x3, x8, x5
    ce34:	aa0303e1 	mov	x1, x3
    ce38:	9b037c42 	mul	x2, x2, x3
    ce3c:	aa0703e3 	mov	x3, x7
    ce40:	b3607ca3 	bfi	x3, x5, #32, #32
    ce44:	eb03005f 	cmp	x2, x3
    ce48:	540000c9 	b.ls	ce60 <__divti3+0xc0>  // b.plast
    ce4c:	ab0300c3 	adds	x3, x6, x3
    ce50:	d1000425 	sub	x5, x1, #0x1
    ce54:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce58:	d1000821 	sub	x1, x1, #0x2
    ce5c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ce60:	aa008020 	orr	x0, x1, x0, lsl #32
    ce64:	d2800001 	mov	x1, #0x0                   	// #0
    ce68:	b4000064 	cbz	x4, ce74 <__divti3+0xd4>
    ce6c:	eb0003e0 	negs	x0, x0
    ce70:	da0103e1 	ngc	x1, x1
    ce74:	d65f03c0 	ret
    ce78:	eb01007f 	cmp	x3, x1
    ce7c:	54000109 	b.ls	ce9c <__divti3+0xfc>  // b.plast
    ce80:	d2800001 	mov	x1, #0x0                   	// #0
    ce84:	d2800000 	mov	x0, #0x0                   	// #0
    ce88:	17fffff8 	b	ce68 <__divti3+0xc8>
    ce8c:	eb0003e0 	negs	x0, x0
    ce90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce94:	da0103e1 	ngc	x1, x1
    ce98:	17ffffc5 	b	cdac <__divti3+0xc>
    ce9c:	dac01067 	clz	x7, x3
    cea0:	b40010e7 	cbz	x7, d0bc <__divti3+0x31c>
    cea4:	d2800805 	mov	x5, #0x40                  	// #64
    cea8:	cb0700a5 	sub	x5, x5, x7
    ceac:	9ac72063 	lsl	x3, x3, x7
    ceb0:	9ac52448 	lsr	x8, x2, x5
    ceb4:	aa030108 	orr	x8, x8, x3
    ceb8:	9ac52426 	lsr	x6, x1, x5
    cebc:	92407d0a 	and	x10, x8, #0xffffffff
    cec0:	d360fd09 	lsr	x9, x8, #32
    cec4:	9ac52403 	lsr	x3, x0, x5
    cec8:	9ac72021 	lsl	x1, x1, x7
    cecc:	aa010063 	orr	x3, x3, x1
    ced0:	9ac72042 	lsl	x2, x2, x7
    ced4:	9ac908cb 	udiv	x11, x6, x9
    ced8:	9b099965 	msub	x5, x11, x9, x6
    cedc:	aa0b03e1 	mov	x1, x11
    cee0:	9b0b7d46 	mul	x6, x10, x11
    cee4:	93c380a5 	extr	x5, x5, x3, #32
    cee8:	eb0500df 	cmp	x6, x5
    ceec:	540000a9 	b.ls	cf00 <__divti3+0x160>  // b.plast
    cef0:	ab050105 	adds	x5, x8, x5
    cef4:	d1000561 	sub	x1, x11, #0x1
    cef8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cefc:	54000f48 	b.hi	d0e4 <__divti3+0x344>  // b.pmore
    cf00:	cb0600a6 	sub	x6, x5, x6
    cf04:	9ac908cb 	udiv	x11, x6, x9
    cf08:	9b099969 	msub	x9, x11, x9, x6
    cf0c:	aa0b03e5 	mov	x5, x11
    cf10:	9b0b7d4a 	mul	x10, x10, x11
    cf14:	b3607d23 	bfi	x3, x9, #32, #32
    cf18:	eb03015f 	cmp	x10, x3
    cf1c:	540000a9 	b.ls	cf30 <__divti3+0x190>  // b.plast
    cf20:	ab030103 	adds	x3, x8, x3
    cf24:	d1000565 	sub	x5, x11, #0x1
    cf28:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cf2c:	54000e28 	b.hi	d0f0 <__divti3+0x350>  // b.pmore
    cf30:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cf34:	92407c48 	and	x8, x2, #0xffffffff
    cf38:	2a0503e5 	mov	w5, w5
    cf3c:	d360fc42 	lsr	x2, x2, #32
    cf40:	d360fc26 	lsr	x6, x1, #32
    cf44:	cb0a0063 	sub	x3, x3, x10
    cf48:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cf4c:	9b087caa 	mul	x10, x5, x8
    cf50:	9b087cc8 	mul	x8, x6, x8
    cf54:	9b0220a5 	madd	x5, x5, x2, x8
    cf58:	9b027cc6 	mul	x6, x6, x2
    cf5c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cf60:	8b0900c5 	add	x5, x6, x9
    cf64:	eb02011f 	cmp	x8, x2
    cf68:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cf6c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cf70:	eb06007f 	cmp	x3, x6
    cf74:	540000e3 	b.cc	cf90 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cf78:	92407d4a 	and	x10, x10, #0xffffffff
    cf7c:	9ac72000 	lsl	x0, x0, x7
    cf80:	8b028142 	add	x2, x10, x2, lsl #32
    cf84:	eb02001f 	cmp	x0, x2
    cf88:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cf8c:	54000a01 	b.ne	d0cc <__divti3+0x32c>  // b.any
    cf90:	d1000420 	sub	x0, x1, #0x1
    cf94:	d2800001 	mov	x1, #0x0                   	// #0
    cf98:	17ffffb4 	b	ce68 <__divti3+0xc8>
    cf9c:	b5000062 	cbnz	x2, cfa8 <__divti3+0x208>
    cfa0:	d2800022 	mov	x2, #0x1                   	// #1
    cfa4:	9ac30846 	udiv	x6, x2, x3
    cfa8:	dac010c8 	clz	x8, x6
    cfac:	b5000408 	cbnz	x8, d02c <__divti3+0x28c>
    cfb0:	d360fcc9 	lsr	x9, x6, #32
    cfb4:	92407cc5 	and	x5, x6, #0xffffffff
    cfb8:	cb060023 	sub	x3, x1, x6
    cfbc:	d2800021 	mov	x1, #0x1                   	// #1
    cfc0:	9ac90868 	udiv	x8, x3, x9
    cfc4:	9b098d03 	msub	x3, x8, x9, x3
    cfc8:	aa0803e0 	mov	x0, x8
    cfcc:	9b057d02 	mul	x2, x8, x5
    cfd0:	93c78063 	extr	x3, x3, x7, #32
    cfd4:	eb03005f 	cmp	x2, x3
    cfd8:	540000a9 	b.ls	cfec <__divti3+0x24c>  // b.plast
    cfdc:	ab0300c3 	adds	x3, x6, x3
    cfe0:	d1000500 	sub	x0, x8, #0x1
    cfe4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cfe8:	54000968 	b.hi	d114 <__divti3+0x374>  // b.pmore
    cfec:	cb020063 	sub	x3, x3, x2
    cff0:	9ac90862 	udiv	x2, x3, x9
    cff4:	aa0203e8 	mov	x8, x2
    cff8:	9b098c42 	msub	x2, x2, x9, x3
    cffc:	aa0703e3 	mov	x3, x7
    d000:	9b057d05 	mul	x5, x8, x5
    d004:	b3607c43 	bfi	x3, x2, #32, #32
    d008:	eb0300bf 	cmp	x5, x3
    d00c:	540000c9 	b.ls	d024 <__divti3+0x284>  // b.plast
    d010:	ab0300c2 	adds	x2, x6, x3
    d014:	d1000503 	sub	x3, x8, #0x1
    d018:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d01c:	d1000908 	sub	x8, x8, #0x2
    d020:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d024:	aa008100 	orr	x0, x8, x0, lsl #32
    d028:	17ffff90 	b	ce68 <__divti3+0xc8>
    d02c:	9ac820c6 	lsl	x6, x6, x8
    d030:	d2800803 	mov	x3, #0x40                  	// #64
    d034:	cb080063 	sub	x3, x3, x8
    d038:	d360fcc9 	lsr	x9, x6, #32
    d03c:	9ac82027 	lsl	x7, x1, x8
    d040:	92407cc5 	and	x5, x6, #0xffffffff
    d044:	9ac32422 	lsr	x2, x1, x3
    d048:	9ac32403 	lsr	x3, x0, x3
    d04c:	aa070063 	orr	x3, x3, x7
    d050:	9ac9084a 	udiv	x10, x2, x9
    d054:	9ac82007 	lsl	x7, x0, x8
    d058:	9b098940 	msub	x0, x10, x9, x2
    d05c:	aa0a03e1 	mov	x1, x10
    d060:	9b0a7ca2 	mul	x2, x5, x10
    d064:	93c38000 	extr	x0, x0, x3, #32
    d068:	eb00005f 	cmp	x2, x0
    d06c:	540000a9 	b.ls	d080 <__divti3+0x2e0>  // b.plast
    d070:	ab0000c0 	adds	x0, x6, x0
    d074:	d1000541 	sub	x1, x10, #0x1
    d078:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d07c:	54000468 	b.hi	d108 <__divti3+0x368>  // b.pmore
    d080:	cb020000 	sub	x0, x0, x2
    d084:	9ac9080a 	udiv	x10, x0, x9
    d088:	9b098140 	msub	x0, x10, x9, x0
    d08c:	aa0a03e2 	mov	x2, x10
    d090:	9b0a7ca8 	mul	x8, x5, x10
    d094:	b3607c03 	bfi	x3, x0, #32, #32
    d098:	eb03011f 	cmp	x8, x3
    d09c:	540000a9 	b.ls	d0b0 <__divti3+0x310>  // b.plast
    d0a0:	ab0300c3 	adds	x3, x6, x3
    d0a4:	d1000542 	sub	x2, x10, #0x1
    d0a8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d0ac:	54000288 	b.hi	d0fc <__divti3+0x35c>  // b.pmore
    d0b0:	cb080063 	sub	x3, x3, x8
    d0b4:	aa018041 	orr	x1, x2, x1, lsl #32
    d0b8:	17ffffc2 	b	cfc0 <__divti3+0x220>
    d0bc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d0c0:	d2800001 	mov	x1, #0x0                   	// #0
    d0c4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d0c8:	17ffff68 	b	ce68 <__divti3+0xc8>
    d0cc:	aa0103e0 	mov	x0, x1
    d0d0:	d2800001 	mov	x1, #0x0                   	// #0
    d0d4:	17ffff65 	b	ce68 <__divti3+0xc8>
    d0d8:	d1000860 	sub	x0, x3, #0x2
    d0dc:	8b0600a5 	add	x5, x5, x6
    d0e0:	17ffff52 	b	ce28 <__divti3+0x88>
    d0e4:	d1000961 	sub	x1, x11, #0x2
    d0e8:	8b0800a5 	add	x5, x5, x8
    d0ec:	17ffff85 	b	cf00 <__divti3+0x160>
    d0f0:	d1000965 	sub	x5, x11, #0x2
    d0f4:	8b080063 	add	x3, x3, x8
    d0f8:	17ffff8e 	b	cf30 <__divti3+0x190>
    d0fc:	d1000942 	sub	x2, x10, #0x2
    d100:	8b060063 	add	x3, x3, x6
    d104:	17ffffeb 	b	d0b0 <__divti3+0x310>
    d108:	d1000941 	sub	x1, x10, #0x2
    d10c:	8b060000 	add	x0, x0, x6
    d110:	17ffffdc 	b	d080 <__divti3+0x2e0>
    d114:	d1000900 	sub	x0, x8, #0x2
    d118:	8b060063 	add	x3, x3, x6
    d11c:	17ffffb4 	b	cfec <__divti3+0x24c>

000000000000d120 <__modti3>:
    d120:	d503245f 	bti	c
    d124:	d2800004 	mov	x4, #0x0                   	// #0
    d128:	b6f80081 	tbz	x1, #63, d138 <__modti3+0x18>
    d12c:	eb0003e0 	negs	x0, x0
    d130:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d134:	da0103e1 	ngc	x1, x1
    d138:	f100007f 	cmp	x3, #0x0
    d13c:	5400128b 	b.lt	d38c <__modti3+0x26c>  // b.tstop
    d140:	aa0003e7 	mov	x7, x0
    d144:	aa0103e6 	mov	x6, x1
    d148:	540004e1 	b.ne	d1e4 <__modti3+0xc4>  // b.any
    d14c:	eb02003f 	cmp	x1, x2
    d150:	54000dc2 	b.cs	d308 <__modti3+0x1e8>  // b.hs, b.nlast
    d154:	dac01043 	clz	x3, x2
    d158:	aa0303e5 	mov	x5, x3
    d15c:	b40000e3 	cbz	x3, d178 <__modti3+0x58>
    d160:	4b0303e6 	neg	w6, w3
    d164:	9ac32021 	lsl	x1, x1, x3
    d168:	9ac32042 	lsl	x2, x2, x3
    d16c:	9ac62406 	lsr	x6, x0, x6
    d170:	aa0100c6 	orr	x6, x6, x1
    d174:	9ac32007 	lsl	x7, x0, x3
    d178:	d360fc40 	lsr	x0, x2, #32
    d17c:	92407c43 	and	x3, x2, #0xffffffff
    d180:	9ac008c1 	udiv	x1, x6, x0
    d184:	9b009826 	msub	x6, x1, x0, x6
    d188:	9b017c61 	mul	x1, x3, x1
    d18c:	93c780c6 	extr	x6, x6, x7, #32
    d190:	eb06003f 	cmp	x1, x6
    d194:	540000a9 	b.ls	d1a8 <__modti3+0x88>  // b.plast
    d198:	ab060046 	adds	x6, x2, x6
    d19c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d1a0:	8b0200c8 	add	x8, x6, x2
    d1a4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d1a8:	cb0100c6 	sub	x6, x6, x1
    d1ac:	9ac008c8 	udiv	x8, x6, x0
    d1b0:	9b009901 	msub	x1, x8, x0, x6
    d1b4:	aa0703e0 	mov	x0, x7
    d1b8:	9b087c63 	mul	x3, x3, x8
    d1bc:	b3607c20 	bfi	x0, x1, #32, #32
    d1c0:	eb00007f 	cmp	x3, x0
    d1c4:	54001088 	b.hi	d3d4 <__modti3+0x2b4>  // b.pmore
    d1c8:	cb030000 	sub	x0, x0, x3
    d1cc:	9ac52400 	lsr	x0, x0, x5
    d1d0:	d2800001 	mov	x1, #0x0                   	// #0
    d1d4:	b4000064 	cbz	x4, d1e0 <__modti3+0xc0>
    d1d8:	eb0003e0 	negs	x0, x0
    d1dc:	da0103e1 	ngc	x1, x1
    d1e0:	d65f03c0 	ret
    d1e4:	dac01066 	clz	x6, x3
    d1e8:	eb03003f 	cmp	x1, x3
    d1ec:	54ffff43 	b.cc	d1d4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d1f0:	93407cc5 	sxtw	x5, w6
    d1f4:	d2800808 	mov	x8, #0x40                  	// #64
    d1f8:	cb050108 	sub	x8, x8, x5
    d1fc:	9ac62063 	lsl	x3, x3, x6
    d200:	9ac62025 	lsl	x5, x1, x6
    d204:	9ac82447 	lsr	x7, x2, x8
    d208:	aa0300e7 	orr	x7, x7, x3
    d20c:	9ac82423 	lsr	x3, x1, x8
    d210:	92407cec 	and	x12, x7, #0xffffffff
    d214:	d360fcea 	lsr	x10, x7, #32
    d218:	9ac82401 	lsr	x1, x0, x8
    d21c:	aa050021 	orr	x1, x1, x5
    d220:	9ac62042 	lsl	x2, x2, x6
    d224:	9ac62000 	lsl	x0, x0, x6
    d228:	9aca086b 	udiv	x11, x3, x10
    d22c:	9b0a8d63 	msub	x3, x11, x10, x3
    d230:	aa0b03e5 	mov	x5, x11
    d234:	9b0b7d89 	mul	x9, x12, x11
    d238:	93c18063 	extr	x3, x3, x1, #32
    d23c:	eb03013f 	cmp	x9, x3
    d240:	540000a9 	b.ls	d254 <__modti3+0x134>  // b.plast
    d244:	ab0300e3 	adds	x3, x7, x3
    d248:	d1000565 	sub	x5, x11, #0x1
    d24c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d250:	54001168 	b.hi	d47c <__modti3+0x35c>  // b.pmore
    d254:	cb090063 	sub	x3, x3, x9
    d258:	9aca086b 	udiv	x11, x3, x10
    d25c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d260:	aa0b03e9 	mov	x9, x11
    d264:	9b0b7d8c 	mul	x12, x12, x11
    d268:	b3607d41 	bfi	x1, x10, #32, #32
    d26c:	eb01019f 	cmp	x12, x1
    d270:	540000a9 	b.ls	d284 <__modti3+0x164>  // b.plast
    d274:	ab0100e1 	adds	x1, x7, x1
    d278:	d1000569 	sub	x9, x11, #0x1
    d27c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d280:	54000f88 	b.hi	d470 <__modti3+0x350>  // b.pmore
    d284:	aa058123 	orr	x3, x9, x5, lsl #32
    d288:	92407c4b 	and	x11, x2, #0xffffffff
    d28c:	2a0903e9 	mov	w9, w9
    d290:	d360fc4a 	lsr	x10, x2, #32
    d294:	d360fc63 	lsr	x3, x3, #32
    d298:	cb0c0021 	sub	x1, x1, x12
    d29c:	aa0a03ec 	mov	x12, x10
    d2a0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d2a4:	9b0b7d25 	mul	x5, x9, x11
    d2a8:	9b0b7c6b 	mul	x11, x3, x11
    d2ac:	9b0a2d29 	madd	x9, x9, x10, x11
    d2b0:	92407caa 	and	x10, x5, #0xffffffff
    d2b4:	9b0c7c63 	mul	x3, x3, x12
    d2b8:	8b458125 	add	x5, x9, x5, lsr #32
    d2bc:	8b0d0069 	add	x9, x3, x13
    d2c0:	eb05017f 	cmp	x11, x5
    d2c4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d2c8:	8b058149 	add	x9, x10, x5, lsl #32
    d2cc:	8b458063 	add	x3, x3, x5, lsr #32
    d2d0:	eb03003f 	cmp	x1, x3
    d2d4:	54000063 	b.cc	d2e0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d2d8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d2dc:	54000082 	b.cs	d2ec <__modti3+0x1cc>  // b.hs, b.nlast
    d2e0:	eb020129 	subs	x9, x9, x2
    d2e4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d2e8:	cb070063 	sub	x3, x3, x7
    d2ec:	eb090000 	subs	x0, x0, x9
    d2f0:	da030021 	sbc	x1, x1, x3
    d2f4:	9ac62400 	lsr	x0, x0, x6
    d2f8:	9ac82028 	lsl	x8, x1, x8
    d2fc:	aa000100 	orr	x0, x8, x0
    d300:	9ac62421 	lsr	x1, x1, x6
    d304:	17ffffb4 	b	d1d4 <__modti3+0xb4>
    d308:	b5000062 	cbnz	x2, d314 <__modti3+0x1f4>
    d30c:	d2800023 	mov	x3, #0x1                   	// #1
    d310:	9ac20862 	udiv	x2, x3, x2
    d314:	dac01048 	clz	x8, x2
    d318:	aa0803e5 	mov	x5, x8
    d31c:	b5000668 	cbnz	x8, d3e8 <__modti3+0x2c8>
    d320:	cb020020 	sub	x0, x1, x2
    d324:	d360fc49 	lsr	x9, x2, #32
    d328:	92407c4a 	and	x10, x2, #0xffffffff
    d32c:	9ac90801 	udiv	x1, x0, x9
    d330:	9b098020 	msub	x0, x1, x9, x0
    d334:	9b0a7c21 	mul	x1, x1, x10
    d338:	93c78000 	extr	x0, x0, x7, #32
    d33c:	eb00003f 	cmp	x1, x0
    d340:	540000a9 	b.ls	d354 <__modti3+0x234>  // b.plast
    d344:	ab000040 	adds	x0, x2, x0
    d348:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d34c:	8b020003 	add	x3, x0, x2
    d350:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d354:	cb010001 	sub	x1, x0, x1
    d358:	9ac90820 	udiv	x0, x1, x9
    d35c:	9b098403 	msub	x3, x0, x9, x1
    d360:	aa0703e1 	mov	x1, x7
    d364:	9b0a7c00 	mul	x0, x0, x10
    d368:	b3607c61 	bfi	x1, x3, #32, #32
    d36c:	eb01001f 	cmp	x0, x1
    d370:	540000a9 	b.ls	d384 <__modti3+0x264>  // b.plast
    d374:	ab010041 	adds	x1, x2, x1
    d378:	8b020022 	add	x2, x1, x2
    d37c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d380:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d384:	cb000020 	sub	x0, x1, x0
    d388:	17ffff91 	b	d1cc <__modti3+0xac>
    d38c:	eb0203e5 	negs	x5, x2
    d390:	aa0003e7 	mov	x7, x0
    d394:	da0303e8 	ngc	x8, x3
    d398:	aa0503e2 	mov	x2, x5
    d39c:	aa0803e3 	mov	x3, x8
    d3a0:	aa0103e6 	mov	x6, x1
    d3a4:	b4ffed48 	cbz	x8, d14c <__modti3+0x2c>
    d3a8:	eb01011f 	cmp	x8, x1
    d3ac:	54fff148 	b.hi	d1d4 <__modti3+0xb4>  // b.pmore
    d3b0:	dac01109 	clz	x9, x8
    d3b4:	2a0903e6 	mov	w6, w9
    d3b8:	b5fff1c9 	cbnz	x9, d1f0 <__modti3+0xd0>
    d3bc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d3c0:	54000068 	b.hi	d3cc <__modti3+0x2ac>  // b.pmore
    d3c4:	eb050007 	subs	x7, x0, x5
    d3c8:	da080021 	sbc	x1, x1, x8
    d3cc:	aa0703e0 	mov	x0, x7
    d3d0:	17ffff81 	b	d1d4 <__modti3+0xb4>
    d3d4:	ab000040 	adds	x0, x2, x0
    d3d8:	8b020002 	add	x2, x0, x2
    d3dc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d3e0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d3e4:	17ffff79 	b	d1c8 <__modti3+0xa8>
    d3e8:	9ac82042 	lsl	x2, x2, x8
    d3ec:	d2800803 	mov	x3, #0x40                  	// #64
    d3f0:	cb080063 	sub	x3, x3, x8
    d3f4:	d360fc49 	lsr	x9, x2, #32
    d3f8:	9ac82027 	lsl	x7, x1, x8
    d3fc:	92407c4a 	and	x10, x2, #0xffffffff
    d400:	9ac32426 	lsr	x6, x1, x3
    d404:	9ac32403 	lsr	x3, x0, x3
    d408:	aa070063 	orr	x3, x3, x7
    d40c:	9ac908c1 	udiv	x1, x6, x9
    d410:	9ac82007 	lsl	x7, x0, x8
    d414:	9b099820 	msub	x0, x1, x9, x6
    d418:	9b017d41 	mul	x1, x10, x1
    d41c:	93c38000 	extr	x0, x0, x3, #32
    d420:	eb00003f 	cmp	x1, x0
    d424:	540000a9 	b.ls	d438 <__modti3+0x318>  // b.plast
    d428:	ab000040 	adds	x0, x2, x0
    d42c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d430:	8b020006 	add	x6, x0, x2
    d434:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d438:	cb010000 	sub	x0, x0, x1
    d43c:	9ac90801 	udiv	x1, x0, x9
    d440:	9b098026 	msub	x6, x1, x9, x0
    d444:	aa0303e0 	mov	x0, x3
    d448:	9b017d41 	mul	x1, x10, x1
    d44c:	b3607cc0 	bfi	x0, x6, #32, #32
    d450:	eb00003f 	cmp	x1, x0
    d454:	540000a9 	b.ls	d468 <__modti3+0x348>  // b.plast
    d458:	ab000040 	adds	x0, x2, x0
    d45c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d460:	8b020003 	add	x3, x0, x2
    d464:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d468:	cb010000 	sub	x0, x0, x1
    d46c:	17ffffb0 	b	d32c <__modti3+0x20c>
    d470:	d1000969 	sub	x9, x11, #0x2
    d474:	8b070021 	add	x1, x1, x7
    d478:	17ffff83 	b	d284 <__modti3+0x164>
    d47c:	d1000965 	sub	x5, x11, #0x2
    d480:	8b070063 	add	x3, x3, x7
    d484:	17ffff74 	b	d254 <__modti3+0x134>
    d488:	d503201f 	nop
    d48c:	d503201f 	nop

000000000000d490 <atexit>:
    d490:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d494:	f0000082 	adrp	x2, 20000 <__data_start>
    d498:	d2800001 	mov	x1, #0x0                   	// #0
    d49c:	910003fd 	mov	x29, sp
    d4a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d4a4:	f9400442 	ldr	x2, [x2, #8]
    d4a8:	17ffd4b6 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d4ac <_fini>:
    d4ac:	d503201f 	nop
    d4b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d4b4:	910003fd 	mov	x29, sp
    d4b8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d4bc:	d65f03c0 	ret
