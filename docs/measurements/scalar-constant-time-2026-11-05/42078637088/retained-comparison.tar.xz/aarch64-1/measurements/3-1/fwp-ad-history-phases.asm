
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__divti3+0x1a0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9120e0a5 	add	x5, x5, #0x838
    2aa0:	b0000044 	adrp	x4, b000 <__divti3+0x1a0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91210084 	add	x4, x4, #0x840
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x108b0>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2b34:	91306000 	add	x0, x0, #0xc18
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x860>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911e4042 	add	x2, x2, #0x790
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2c7c:	9130a000 	add	x0, x0, #0xc28
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2c8c:	91332000 	add	x0, x0, #0xcc8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2ca4:	91328000 	add	x0, x0, #0xca0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2cb0:	9131c000 	add	x0, x0, #0xc70
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	b0000040 	adrp	x0, b000 <__divti3+0x1a0>
    2cbc:	91312000 	add	x0, x0, #0xc48
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xa80>
    2eb4:	910cc021 	add	x1, x1, #0x330
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3050:	91162000 	add	x0, x0, #0x588
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa80>
    3118:	910c4021 	add	x1, x1, #0x310
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3150:	91168000 	add	x0, x0, #0x5a0
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__divti3+0x1a0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__divti3+0x1a0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	b0000058 	adrp	x24, c000 <_IO_stdin_used+0xa80>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	9117a042 	add	x2, x2, #0x5e8
    31e0:	911902d6 	add	x22, x22, #0x640
    31e4:	91026318 	add	x24, x24, #0x98
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__divti3+0x1a0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	9118e323 	add	x3, x25, #0x638
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91194000 	add	x0, x0, #0x650
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3570:	91162000 	add	x0, x0, #0x588
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__divti3+0x1a0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91196021 	add	x1, x1, #0x658
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__divti3+0x1a0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91198021 	add	x1, x1, #0x660
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__divti3+0x1a0>
    37e0:	9119a021 	add	x1, x1, #0x668
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	90000042 	adrp	x2, b000 <__divti3+0x1a0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	9119c042 	add	x2, x2, #0x670
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3950:	91162000 	add	x0, x0, #0x588
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3970:	911a0000 	add	x0, x0, #0x680
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3a08:	911a8000 	add	x0, x0, #0x6a0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3a18:	911b0000 	add	x0, x0, #0x6c0
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa80>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0d020 	ldr	q0, [x1, #832]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3b18:	911ba000 	add	x0, x0, #0x6e8
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3b88:	911c6000 	add	x0, x0, #0x718
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	90000044 	adrp	x4, b000 <__divti3+0x1a0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911da084 	add	x4, x4, #0x768
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	90000044 	adrp	x4, b000 <__divti3+0x1a0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911e0084 	add	x4, x4, #0x780
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	90000044 	adrp	x4, b000 <__divti3+0x1a0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911dc084 	add	x4, x4, #0x770
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	90000041 	adrp	x1, b000 <__divti3+0x1a0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	90000040 	adrp	x0, b000 <__divti3+0x1a0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911e2021 	add	x1, x1, #0x788
    4004:	911e4000 	add	x0, x0, #0x790
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	f0000022 	adrp	x2, b000 <__divti3+0x1a0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911ec042 	add	x2, x2, #0x7b0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	90000042 	adrp	x2, c000 <_IO_stdin_used+0xa80>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc0d443 	ldr	q3, [x2, #848]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    4268:	91218000 	add	x0, x0, #0x860
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    43cc:	9121c000 	add	x0, x0, #0x870
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	9121c000 	add	x0, x0, #0x870
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	9121c000 	add	x0, x0, #0x870
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    46bc:	91222000 	add	x0, x0, #0x888
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    4774:	91238000 	add	x0, x0, #0x8e0
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    47d0:	9122e000 	add	x0, x0, #0x8b8
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    47e0:	91242000 	add	x0, x0, #0x908
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	f0000020 	adrp	x0, b000 <__divti3+0x1a0>
    4880:	91238000 	add	x0, x0, #0x8e0
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	54000e8b 	b.lt	53fc <fwp_p_ad_push+0x1d8>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	aa0003e4 	mov	x4, x0
    5238:	910003fd 	mov	x29, sp
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0003f5 	mov	x21, x0
    5244:	aa020000 	orr	x0, x0, x2
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f7 	mov	x23, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	b6f80900 	tbz	x0, #63, 537c <fwp_p_ad_push+0x158>
    5260:	a90153f3 	stp	x19, x20, [sp, #16]
    5264:	9360fc80 	asr	x0, x4, #32
    5268:	b6f800c4 	tbz	x4, #63, 5280 <fwp_p_ad_push+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc40 	asr	x0, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5280:	97fffa2c 	bl	3b30 <fwp_tape_of>
    5284:	aa0003f3 	mov	x19, x0
    5288:	f9403000 	ldr	x0, [x0, #96]
    528c:	b5001280 	cbnz	x0, 54dc <fwp_p_ad_push+0x2b8>
    5290:	f9400a76 	ldr	x22, [x19, #16]
    5294:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5298:	eb0002df 	cmp	x22, x0
    529c:	54000e2c 	b.gt	5460 <fwp_p_ad_push+0x23c>
    52a0:	eb3542df 	cmp	x22, w21, uxtw
    52a4:	54000d4d 	b.le	544c <fwp_p_ad_push+0x228>
    52a8:	b7f80077 	tbnz	x23, #63, 52b4 <fwp_p_ad_push+0x90>
    52ac:	eb3742df 	cmp	x22, w23, uxtw
    52b0:	54000ced 	b.le	544c <fwp_p_ad_push+0x228>
    52b4:	f9400678 	ldr	x24, [x19, #8]
    52b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52bc:	cb1802d8 	sub	x24, x22, x24
    52c0:	91000701 	add	x1, x24, #0x1
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	54000cc8 	b.hi	5460 <fwp_p_ad_push+0x23c>  // b.pmore
    52cc:	a9418274 	ldp	x20, x0, [x19, #24]
    52d0:	a90573fb 	stp	x27, x28, [sp, #80]
    52d4:	eb14003f 	cmp	x1, x20
    52d8:	5400068d 	b.le	53a8 <fwp_p_ad_push+0x184>
    52dc:	f100029f 	cmp	x20, #0x0
    52e0:	d2800803 	mov	x3, #0x40                  	// #64
    52e4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52e8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	5400008d 	b.le	5304 <fwp_p_ad_push+0xe0>
    52f8:	eb02029f 	cmp	x20, x2
    52fc:	5400052d 	b.le	53a0 <fwp_p_ad_push+0x17c>
    5300:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5304:	d37df299 	lsl	x25, x20, #3
    5308:	aa1903e1 	mov	x1, x25
    530c:	97fff559 	bl	2870 <realloc@plt>
    5310:	aa0003e1 	mov	x1, x0
    5314:	b4000b00 	cbz	x0, 5474 <fwp_p_ad_push+0x250>
    5318:	f9400e62 	ldr	x2, [x19, #24]
    531c:	f9001261 	str	x1, [x19, #32]
    5320:	f9401a60 	ldr	x0, [x19, #48]
    5324:	d37cee9a 	lsl	x26, x20, #4
    5328:	8b020821 	add	x1, x1, x2, lsl #2
    532c:	f9001661 	str	x1, [x19, #40]
    5330:	aa1a03e1 	mov	x1, x26
    5334:	97fff54f 	bl	2870 <realloc@plt>
    5338:	aa0003e2 	mov	x2, x0
    533c:	b40009c0 	cbz	x0, 5474 <fwp_p_ad_push+0x250>
    5340:	f9400e61 	ldr	x1, [x19, #24]
    5344:	d37df31b 	lsl	x27, x24, #3
    5348:	d37ef685 	lsl	x5, x20, #2
    534c:	d37ef71c 	lsl	x28, x24, #2
    5350:	8b190004 	add	x4, x0, x25
    5354:	8b010c01 	add	x1, x0, x1, lsl #3
    5358:	a9030660 	stp	x0, x1, [x19, #48]
    535c:	b5000558 	cbnz	x24, 5404 <fwp_p_ad_push+0x1e0>
    5360:	f9001e64 	str	x4, [x19, #56]
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	a9446bf9 	ldp	x25, x26, [sp, #64]
    536c:	8b050001 	add	x1, x0, x5
    5370:	f9000e74 	str	x20, [x19, #24]
    5374:	f9001661 	str	x1, [x19, #40]
    5378:	14000010 	b	53b8 <fwp_p_ad_push+0x194>
    537c:	9360fc40 	asr	x0, x2, #32
    5380:	a90153f3 	stp	x19, x20, [sp, #16]
    5384:	eb84801f 	cmp	x0, x4, asr #32
    5388:	54fff7c0 	b.eq	5280 <fwp_p_ad_push+0x5c>  // b.none
    538c:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5390:	9124a000 	add	x0, x0, #0x928
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	a90573fb 	stp	x27, x28, [sp, #80]
    539c:	97fff919 	bl	3800 <fwp_trap>
    53a0:	d37ffa94 	lsl	x20, x20, #1
    53a4:	17ffffd3 	b	52f0 <fwp_p_ad_push+0xcc>
    53a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53ac:	d37ef71c 	lsl	x28, x24, #2
    53b0:	f9401e64 	ldr	x4, [x19, #56]
    53b4:	d37df31b 	lsl	x27, x24, #3
    53b8:	b83c6815 	str	w21, [x0, x28]
    53bc:	f10002ff 	cmp	x23, #0x0
    53c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    53c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53c8:	fc3b6849 	str	d9, [x2, x27]
    53cc:	aa1602a0 	orr	x0, x21, x22
    53d0:	b83c6837 	str	w23, [x1, x28]
    53d4:	910006d6 	add	x22, x22, #0x1
    53d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53dc:	fc3b6888 	str	d8, [x4, x27]
    53e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53e8:	f9000a76 	str	x22, [x19, #16]
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53f8:	d65f03c0 	ret
    53fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5400:	d65f03c0 	ret
    5404:	eb1a033f 	cmp	x25, x26
    5408:	aa0403e0 	mov	x0, x4
    540c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5410:	aa1b03e2 	mov	x2, x27
    5414:	cb190063 	sub	x3, x3, x25
    5418:	f9003fe5 	str	x5, [sp, #120]
    541c:	97fff581 	bl	2a20 <__memmove_chk@plt>
    5420:	a9420660 	ldp	x0, x1, [x19, #32]
    5424:	aa1c03e2 	mov	x2, x28
    5428:	f9401a63 	ldr	x3, [x19, #48]
    542c:	f9403fe5 	ldr	x5, [sp, #120]
    5430:	8b190063 	add	x3, x3, x25
    5434:	f9001e63 	str	x3, [x19, #56]
    5438:	8b050000 	add	x0, x0, x5
    543c:	97fff4ad 	bl	26f0 <memmove@plt>
    5440:	a9431262 	ldp	x2, x4, [x19, #48]
    5444:	f9403fe5 	ldr	x5, [sp, #120]
    5448:	17ffffc7 	b	5364 <fwp_p_ad_push+0x140>
    544c:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5450:	91270000 	add	x0, x0, #0x9c0
    5454:	a9046bf9 	stp	x25, x26, [sp, #64]
    5458:	a90573fb 	stp	x27, x28, [sp, #80]
    545c:	97fff8e9 	bl	3800 <fwp_trap>
    5460:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5464:	91268000 	add	x0, x0, #0x9a0
    5468:	a9046bf9 	stp	x25, x26, [sp, #64]
    546c:	a90573fb 	stp	x27, x28, [sp, #80]
    5470:	97fff8e4 	bl	3800 <fwp_trap>
    5474:	aa1303e0 	mov	x0, x19
    5478:	97fff6c6 	bl	2f90 <fwp_tape_unlink_scope>
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	97fff530 	bl	2940 <free@plt>
    5484:	f9401a60 	ldr	x0, [x19, #48]
    5488:	97fff52e 	bl	2940 <free@plt>
    548c:	f9402260 	ldr	x0, [x19, #64]
    5490:	97fff52c 	bl	2940 <free@plt>
    5494:	f9000e7f 	str	xzr, [x19, #24]
    5498:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    549c:	f947e821 	ldr	x1, [x1, #4048]
    54a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54a4:	d2800262 	mov	x2, #0x13                  	// #19
    54a8:	4f000400 	movi	v0.4s, #0x0
    54ac:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    54b0:	f9400023 	ldr	x3, [x1]
    54b4:	b900067f 	str	wzr, [x19, #4]
    54b8:	d2800021 	mov	x1, #0x1                   	// #1
    54bc:	91162000 	add	x0, x0, #0x588
    54c0:	3c808260 	stur	q0, [x19, #8]
    54c4:	ad010260 	stp	q0, q0, [x19, #32]
    54c8:	97fff52e 	bl	2980 <fwrite@plt>
    54cc:	d2800000 	mov	x0, #0x0                   	// #0
    54d0:	97fff538 	bl	29b0 <fflush@plt>
    54d4:	52800cc0 	mov	w0, #0x66                  	// #102
    54d8:	97fff546 	bl	29f0 <_Exit@plt>
    54dc:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    54e0:	9125c000 	add	x0, x0, #0x970
    54e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54e8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ec:	97fff8c5 	bl	3800 <fwp_trap>

00000000000054f0 <w107>:
    54f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54f4:	9e660003 	fmov	x3, d0
    54f8:	aa0003e2 	mov	x2, x0
    54fc:	910003fd 	mov	x29, sp
    5500:	6d0327e8 	stp	d8, d9, [sp, #48]
    5504:	1e604028 	fmov	d8, d1
    5508:	1e600809 	fmul	d9, d0, d0
    550c:	fd0023ea 	str	d10, [sp, #64]
    5510:	1e60400a 	fmov	d10, d0
    5514:	a90153f3 	stp	x19, x20, [sp, #16]
    5518:	aa0003f3 	mov	x19, x0
    551c:	aa0103f4 	mov	x20, x1
    5520:	aa0303e1 	mov	x1, x3
    5524:	a9025bf5 	stp	x21, x22, [sp, #32]
    5528:	97ffff3f 	bl	5224 <fwp_p_ad_push>
    552c:	1e693908 	fsub	d8, d8, d9
    5530:	aa1403e2 	mov	x2, x20
    5534:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5538:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    553c:	9e660116 	fmov	x22, d8
    5540:	97ffff39 	bl	5224 <fwp_p_ad_push>
    5544:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5548:	aa0003e1 	mov	x1, x0
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa1303e0 	mov	x0, x19
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	aa0103f3 	mov	x19, x1
    555c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5560:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5564:	9e660135 	fmov	x21, d9
    5568:	97ffff2f 	bl	5224 <fwp_p_ad_push>
    556c:	1e680908 	fmul	d8, d8, d8
    5570:	aa0003f4 	mov	x20, x0
    5574:	aa1603e3 	mov	x3, x22
    5578:	aa1603e1 	mov	x1, x22
    557c:	aa1303e2 	mov	x2, x19
    5580:	aa1303e0 	mov	x0, x19
    5584:	97ffff28 	bl	5224 <fwp_p_ad_push>
    5588:	aa0003e2 	mov	x2, x0
    558c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5590:	9e670020 	fmov	d0, x1
    5594:	9e660101 	fmov	x1, d8
    5598:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    559c:	1e600908 	fmul	d8, d8, d0
    55a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55a4:	97ffff20 	bl	5224 <fwp_p_ad_push>
    55a8:	1e690929 	fmul	d9, d9, d9
    55ac:	aa0003f3 	mov	x19, x0
    55b0:	aa1503e3 	mov	x3, x21
    55b4:	aa1503e1 	mov	x1, x21
    55b8:	aa1403e2 	mov	x2, x20
    55bc:	aa1403e0 	mov	x0, x20
    55c0:	97ffff19 	bl	5224 <fwp_p_ad_push>
    55c4:	1e692908 	fadd	d8, d8, d9
    55c8:	aa1303e2 	mov	x2, x19
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	aa0303e1 	mov	x1, x3
    55d4:	97ffff14 	bl	5224 <fwp_p_ad_push>
    55d8:	aa0003e1 	mov	x1, x0
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	9e660100 	fmov	x0, d8
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    55ec:	fd4023ea 	ldr	d10, [sp, #64]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <fwp_data.part.0.constprop.0>:
    5600:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5604:	910003fd 	mov	x29, sp
    5608:	a90153f3 	stp	x19, x20, [sp, #16]
    560c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5610:	91174283 	add	x3, x20, #0x5d0
    5614:	a9025bf5 	stp	x21, x22, [sp, #32]
    5618:	aa0103f5 	mov	x21, x1
    561c:	b953a461 	ldr	w1, [x3, #5028]
    5620:	a90363f7 	stp	x23, x24, [sp, #48]
    5624:	2a0003f8 	mov	w24, w0
    5628:	34000701 	cbz	w1, 5708 <fwp_data.part.0.constprop.0+0x108>
    562c:	397e8862 	ldrb	w2, [x3, #4002]
    5630:	910f0040 	add	x0, x2, #0x3c0
    5634:	8b020442 	add	x2, x2, x2, lsl #1
    5638:	d37df042 	lsl	x2, x2, #3
    563c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5640:	2a1703f6 	mov	w22, w23
    5644:	f8626873 	ldr	x19, [x3, x2]
    5648:	b40004d3 	cbz	x19, 56e0 <fwp_data.part.0.constprop.0+0xe0>
    564c:	f9400260 	ldr	x0, [x19]
    5650:	aa2003e0 	mvn	x0, x0
    5654:	f8226860 	str	x0, [x3, x2]
    5658:	f10062df 	cmp	x22, #0x18
    565c:	540000e9 	b.ls	5678 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5660:	d10066c2 	sub	x2, x22, #0x19
    5664:	91006260 	add	x0, x19, #0x18
    5668:	927df042 	and	x2, x2, #0xfffffffffffffff8
    566c:	52800001 	mov	w1, #0x0                   	// #0
    5670:	91002042 	add	x2, x2, #0x8
    5674:	97fff477 	bl	2850 <memset@plt>
    5678:	91174282 	add	x2, x20, #0x5d0
    567c:	f94a1041 	ldr	x1, [x2, #5152]
    5680:	ab160021 	adds	x1, x1, x22
    5684:	540004c2 	b.cs	571c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5688:	f94a1440 	ldr	x0, [x2, #5160]
    568c:	f90a1041 	str	x1, [x2, #5152]
    5690:	eb00003f 	cmp	x1, x0
    5694:	54000049 	b.ls	569c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5698:	f90a1441 	str	x1, [x2, #5160]
    569c:	91174294 	add	x20, x20, #0x5d0
    56a0:	1e6302e1 	ucvtf	d1, w23
    56a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    56a8:	1e612800 	fadd	d0, d0, d1
    56ac:	fd0a1e80 	str	d0, [x20, #5176]
    56b0:	52800041 	mov	w1, #0x2                   	// #2
    56b4:	29000678 	stp	w24, w1, [x19]
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	f94002a1 	ldr	x1, [x21]
    56c0:	f9000661 	str	x1, [x19, #8]
    56c4:	f94006a1 	ldr	x1, [x21, #8]
    56c8:	f9000a61 	str	x1, [x19, #16]
    56cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    56d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    56d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    56dc:	d65f03c0 	ret
    56e0:	8b020063 	add	x3, x3, x2
    56e4:	f9400473 	ldr	x19, [x3, #8]
    56e8:	b4000113 	cbz	x19, 5708 <fwp_data.part.0.constprop.0+0x108>
    56ec:	f9400860 	ldr	x0, [x3, #16]
    56f0:	cb130000 	sub	x0, x0, x19
    56f4:	eb0002df 	cmp	x22, x0
    56f8:	54000088 	b.hi	5708 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    56fc:	8b160260 	add	x0, x19, x22
    5700:	f9000460 	str	x0, [x3, #8]
    5704:	17ffffd5 	b	5658 <fwp_data.part.0.constprop.0+0x58>
    5708:	52800001 	mov	w1, #0x0                   	// #0
    570c:	d2800300 	mov	x0, #0x18                  	// #24
    5710:	97fffdf8 	bl	4ef0 <fwp_heap_alloc>
    5714:	aa0003f3 	mov	x19, x0
    5718:	17ffffe6 	b	56b0 <fwp_data.part.0.constprop.0+0xb0>
    571c:	97fff645 	bl	3030 <fwp_heap_oom>

0000000000005720 <fwp_rc_share>:
    5720:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5724:	91174042 	add	x2, x2, #0x5d0
    5728:	f949d843 	ldr	x3, [x2, #5040]
    572c:	f949ec41 	ldr	x1, [x2, #5080]
    5730:	cb030000 	sub	x0, x0, x3
    5734:	eb01401f 	cmp	x0, x1, lsl #16
    5738:	540002c2 	b.cs	5790 <fwp_rc_share+0x70>  // b.hs, b.nlast
    573c:	d350fc01 	lsr	x1, x0, #16
    5740:	f949fc44 	ldr	x4, [x2, #5112]
    5744:	8b010821 	add	x1, x1, x1, lsl #2
    5748:	d37df021 	lsl	x1, x1, #3
    574c:	8b010083 	add	x3, x4, x1
    5750:	f9401062 	ldr	x2, [x3, #32]
    5754:	b40001e2 	cbz	x2, 5790 <fwp_rc_share+0x70>
    5758:	38616881 	ldrb	w1, [x4, x1]
    575c:	7100083f 	cmp	w1, #0x2
    5760:	540001a0 	b.eq	5794 <fwp_rc_share+0x74>  // b.none
    5764:	7100043f 	cmp	w1, #0x1
    5768:	54000141 	b.ne	5790 <fwp_rc_share+0x70>  // b.any
    576c:	29430464 	ldp	w4, w1, [x3, #24]
    5770:	92403c00 	and	x0, x0, #0xffff
    5774:	9b047c00 	mul	x0, x0, x4
    5778:	d360fc00 	lsr	x0, x0, #32
    577c:	eb01001f 	cmp	x0, x1
    5780:	54000082 	b.cs	5790 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5784:	8b000042 	add	x2, x2, x0
    5788:	39400040 	ldrb	w0, [x2]
    578c:	350000a0 	cbnz	w0, 57a0 <fwp_rc_share+0x80>
    5790:	d65f03c0 	ret
    5794:	72003c1f 	tst	w0, #0xffff
    5798:	54ffff80 	b.eq	5788 <fwp_rc_share+0x68>  // b.none
    579c:	d65f03c0 	ret
    57a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57a4:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    57a8:	91278000 	add	x0, x0, #0x9e0
    57ac:	910003fd 	mov	x29, sp
    57b0:	97fff814 	bl	3800 <fwp_trap>

00000000000057b4 <fwp_rc_free_arr>:
    57b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    57b8:	91174063 	add	x3, x3, #0x5d0
    57bc:	f949d861 	ldr	x1, [x3, #5040]
    57c0:	f949ec62 	ldr	x2, [x3, #5080]
    57c4:	cb010001 	sub	x1, x0, x1
    57c8:	eb02403f 	cmp	x1, x2, lsl #16
    57cc:	54000342 	b.cs	5834 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57d0:	d350fc22 	lsr	x2, x1, #16
    57d4:	f949fc65 	ldr	x5, [x3, #5112]
    57d8:	8b020842 	add	x2, x2, x2, lsl #2
    57dc:	d37df042 	lsl	x2, x2, #3
    57e0:	8b0200a4 	add	x4, x5, x2
    57e4:	f9401083 	ldr	x3, [x4, #32]
    57e8:	b4000263 	cbz	x3, 5834 <fwp_rc_free_arr+0x80>
    57ec:	386268a2 	ldrb	w2, [x5, x2]
    57f0:	7100085f 	cmp	w2, #0x2
    57f4:	540001c0 	b.eq	582c <fwp_rc_free_arr+0x78>  // b.none
    57f8:	7100045f 	cmp	w2, #0x1
    57fc:	540001c1 	b.ne	5834 <fwp_rc_free_arr+0x80>  // b.any
    5800:	29430885 	ldp	w5, w2, [x4, #24]
    5804:	92403c21 	and	x1, x1, #0xffff
    5808:	9b057c21 	mul	x1, x1, x5
    580c:	d360fc21 	lsr	x1, x1, #32
    5810:	eb02003f 	cmp	x1, x2
    5814:	54000102 	b.cs	5834 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5818:	8b010063 	add	x3, x3, x1
    581c:	39400061 	ldrb	w1, [x3]
    5820:	7100043f 	cmp	w1, #0x1
    5824:	54000081 	b.ne	5834 <fwp_rc_free_arr+0x80>  // b.any
    5828:	17fffc92 	b	4a70 <fwp_mem_free>
    582c:	72003c3f 	tst	w1, #0xffff
    5830:	54ffff60 	b.eq	581c <fwp_rc_free_arr+0x68>  // b.none
    5834:	d65f03c0 	ret
    5838:	d503201f 	nop
    583c:	d503201f 	nop

0000000000005840 <fwp_rc_dup>:
    5840:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5844:	91174042 	add	x2, x2, #0x5d0
    5848:	f949d841 	ldr	x1, [x2, #5040]
    584c:	f949ec43 	ldr	x3, [x2, #5080]
    5850:	cb010001 	sub	x1, x0, x1
    5854:	eb03403f 	cmp	x1, x3, lsl #16
    5858:	54000342 	b.cs	58c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    585c:	d350fc20 	lsr	x0, x1, #16
    5860:	f949fc44 	ldr	x4, [x2, #5112]
    5864:	8b000800 	add	x0, x0, x0, lsl #2
    5868:	d37df002 	lsl	x2, x0, #3
    586c:	8b020083 	add	x3, x4, x2
    5870:	f9401060 	ldr	x0, [x3, #32]
    5874:	b4000260 	cbz	x0, 58c0 <fwp_rc_dup+0x80>
    5878:	38626882 	ldrb	w2, [x4, x2]
    587c:	7100085f 	cmp	w2, #0x2
    5880:	54000220 	b.eq	58c4 <fwp_rc_dup+0x84>  // b.none
    5884:	7100045f 	cmp	w2, #0x1
    5888:	540001c1 	b.ne	58c0 <fwp_rc_dup+0x80>  // b.any
    588c:	29430864 	ldp	w4, w2, [x3, #24]
    5890:	92403c21 	and	x1, x1, #0xffff
    5894:	9b047c21 	mul	x1, x1, x4
    5898:	d360fc21 	lsr	x1, x1, #32
    589c:	eb02003f 	cmp	x1, x2
    58a0:	54000102 	b.cs	58c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58a4:	8b010000 	add	x0, x0, x1
    58a8:	39400001 	ldrb	w1, [x0]
    58ac:	340000a1 	cbz	w1, 58c0 <fwp_rc_dup+0x80>
    58b0:	7103f43f 	cmp	w1, #0xfd
    58b4:	540000e8 	b.hi	58d0 <fwp_rc_dup+0x90>  // b.pmore
    58b8:	11000421 	add	w1, w1, #0x1
    58bc:	39000001 	strb	w1, [x0]
    58c0:	d65f03c0 	ret
    58c4:	72003c3f 	tst	w1, #0xffff
    58c8:	54ffff00 	b.eq	58a8 <fwp_rc_dup+0x68>  // b.none
    58cc:	d65f03c0 	ret
    58d0:	17fffb81 	b	46d4 <fwp_rc_wide_dup>

00000000000058d4 <fwp_drop0>:
    58d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    58d8:	910003fd 	mov	x29, sp
    58dc:	a90153f3 	stp	x19, x20, [sp, #16]
    58e0:	f90013f5 	str	x21, [sp, #32]
    58e4:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    58e8:	911742b4 	add	x20, x21, #0x5d0
    58ec:	f949da81 	ldr	x1, [x20, #5040]
    58f0:	f949ee82 	ldr	x2, [x20, #5080]
    58f4:	cb010001 	sub	x1, x0, x1
    58f8:	eb02403f 	cmp	x1, x2, lsl #16
    58fc:	54000382 	b.cs	596c <fwp_drop0+0x98>  // b.hs, b.nlast
    5900:	d350fc22 	lsr	x2, x1, #16
    5904:	f949fe84 	ldr	x4, [x20, #5112]
    5908:	8b020842 	add	x2, x2, x2, lsl #2
    590c:	d37df042 	lsl	x2, x2, #3
    5910:	8b020083 	add	x3, x4, x2
    5914:	f9401073 	ldr	x19, [x3, #32]
    5918:	b40002b3 	cbz	x19, 596c <fwp_drop0+0x98>
    591c:	38626882 	ldrb	w2, [x4, x2]
    5920:	7100085f 	cmp	w2, #0x2
    5924:	540002c0 	b.eq	597c <fwp_drop0+0xa8>  // b.none
    5928:	7100045f 	cmp	w2, #0x1
    592c:	54000201 	b.ne	596c <fwp_drop0+0x98>  // b.any
    5930:	29430864 	ldp	w4, w2, [x3, #24]
    5934:	92403c21 	and	x1, x1, #0xffff
    5938:	9b047c21 	mul	x1, x1, x4
    593c:	d360fc21 	lsr	x1, x1, #32
    5940:	eb02003f 	cmp	x1, x2
    5944:	54000142 	b.cs	596c <fwp_drop0+0x98>  // b.hs, b.nlast
    5948:	8b010273 	add	x19, x19, x1
    594c:	39400261 	ldrb	w1, [x19]
    5950:	340000e1 	cbz	w1, 596c <fwp_drop0+0x98>
    5954:	7100043f 	cmp	w1, #0x1
    5958:	540001e0 	b.eq	5994 <fwp_drop0+0xc0>  // b.none
    595c:	7103fc3f 	cmp	w1, #0xff
    5960:	540002e0 	b.eq	59bc <fwp_drop0+0xe8>  // b.none
    5964:	51000421 	sub	w1, w1, #0x1
    5968:	39000261 	strb	w1, [x19]
    596c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5970:	f94013f5 	ldr	x21, [sp, #32]
    5974:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5978:	d65f03c0 	ret
    597c:	72003c3f 	tst	w1, #0xffff
    5980:	54fffe60 	b.eq	594c <fwp_drop0+0x78>  // b.none
    5984:	a94153f3 	ldp	x19, x20, [sp, #16]
    5988:	f94013f5 	ldr	x21, [sp, #32]
    598c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5990:	d65f03c0 	ret
    5994:	f9400813 	ldr	x19, [x0, #16]
    5998:	97ffff87 	bl	57b4 <fwp_rc_free_arr>
    599c:	911742a0 	add	x0, x21, #0x5d0
    59a0:	f949d801 	ldr	x1, [x0, #5040]
    59a4:	f949ec00 	ldr	x0, [x0, #5080]
    59a8:	cb010261 	sub	x1, x19, x1
    59ac:	eb00403f 	cmp	x1, x0, lsl #16
    59b0:	54fffde2 	b.cs	596c <fwp_drop0+0x98>  // b.hs, b.nlast
    59b4:	aa1303e0 	mov	x0, x19
    59b8:	17ffffd2 	b	5900 <fwp_drop0+0x2c>
    59bc:	ca534660 	eor	x0, x19, x19, lsr #17
    59c0:	911742b5 	add	x21, x21, #0x5d0
    59c4:	ca402400 	eor	x0, x0, x0, lsr #9
    59c8:	8b200ea0 	add	x0, x21, w0, uxtb #3
    59cc:	f94a2400 	ldr	x0, [x0, #5192]
    59d0:	b5000080 	cbnz	x0, 59e0 <fwp_drop0+0x10c>
    59d4:	14000010 	b	5a14 <fwp_drop0+0x140>
    59d8:	f9400800 	ldr	x0, [x0, #16]
    59dc:	b40001c0 	cbz	x0, 5a14 <fwp_drop0+0x140>
    59e0:	f9400001 	ldr	x1, [x0]
    59e4:	eb13003f 	cmp	x1, x19
    59e8:	54ffff81 	b.ne	59d8 <fwp_drop0+0x104>  // b.any
    59ec:	f9400401 	ldr	x1, [x0, #8]
    59f0:	d1000421 	sub	x1, x1, #0x1
    59f4:	f9000401 	str	x1, [x0, #8]
    59f8:	f103f83f 	cmp	x1, #0xfe
    59fc:	54fffb81 	b.ne	596c <fwp_drop0+0x98>  // b.any
    5a00:	aa1303e0 	mov	x0, x19
    5a04:	97fffb7b 	bl	47f0 <fwp_rc_forget_slot>
    5a08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a0c:	39000260 	strb	w0, [x19]
    5a10:	17ffffd7 	b	596c <fwp_drop0+0x98>
    5a14:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5a18:	91238000 	add	x0, x0, #0x8e0
    5a1c:	97fff779 	bl	3800 <fwp_trap>

0000000000005a20 <fwp_arg_drop12>:
    5a20:	7100003f 	cmp	w1, #0x0
    5a24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5a28:	54000041 	b.ne	5a30 <fwp_arg_drop12+0x10>  // b.any
    5a2c:	d65f03c0 	ret
    5a30:	f9400000 	ldr	x0, [x0]
    5a34:	17ffffa8 	b	58d4 <fwp_drop0>
    5a38:	d503201f 	nop
    5a3c:	d503201f 	nop

0000000000005a40 <fwp_drop1>:
    5a40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a44:	910003fd 	mov	x29, sp
    5a48:	a90153f3 	stp	x19, x20, [sp, #16]
    5a4c:	f90013f5 	str	x21, [sp, #32]
    5a50:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5a54:	911742b4 	add	x20, x21, #0x5d0
    5a58:	f949da81 	ldr	x1, [x20, #5040]
    5a5c:	f949ee82 	ldr	x2, [x20, #5080]
    5a60:	cb010001 	sub	x1, x0, x1
    5a64:	eb02403f 	cmp	x1, x2, lsl #16
    5a68:	54000382 	b.cs	5ad8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a6c:	d350fc22 	lsr	x2, x1, #16
    5a70:	f949fe84 	ldr	x4, [x20, #5112]
    5a74:	8b020842 	add	x2, x2, x2, lsl #2
    5a78:	d37df042 	lsl	x2, x2, #3
    5a7c:	8b020083 	add	x3, x4, x2
    5a80:	f9401073 	ldr	x19, [x3, #32]
    5a84:	b40002b3 	cbz	x19, 5ad8 <fwp_drop1+0x98>
    5a88:	38626882 	ldrb	w2, [x4, x2]
    5a8c:	7100085f 	cmp	w2, #0x2
    5a90:	540002c0 	b.eq	5ae8 <fwp_drop1+0xa8>  // b.none
    5a94:	7100045f 	cmp	w2, #0x1
    5a98:	54000201 	b.ne	5ad8 <fwp_drop1+0x98>  // b.any
    5a9c:	29430864 	ldp	w4, w2, [x3, #24]
    5aa0:	92403c21 	and	x1, x1, #0xffff
    5aa4:	9b047c21 	mul	x1, x1, x4
    5aa8:	d360fc21 	lsr	x1, x1, #32
    5aac:	eb02003f 	cmp	x1, x2
    5ab0:	54000142 	b.cs	5ad8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ab4:	8b010273 	add	x19, x19, x1
    5ab8:	39400261 	ldrb	w1, [x19]
    5abc:	340000e1 	cbz	w1, 5ad8 <fwp_drop1+0x98>
    5ac0:	7100043f 	cmp	w1, #0x1
    5ac4:	540001e0 	b.eq	5b00 <fwp_drop1+0xc0>  // b.none
    5ac8:	7103fc3f 	cmp	w1, #0xff
    5acc:	540002e0 	b.eq	5b28 <fwp_drop1+0xe8>  // b.none
    5ad0:	51000421 	sub	w1, w1, #0x1
    5ad4:	39000261 	strb	w1, [x19]
    5ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5adc:	f94013f5 	ldr	x21, [sp, #32]
    5ae0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ae4:	d65f03c0 	ret
    5ae8:	72003c3f 	tst	w1, #0xffff
    5aec:	54fffe60 	b.eq	5ab8 <fwp_drop1+0x78>  // b.none
    5af0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5af4:	f94013f5 	ldr	x21, [sp, #32]
    5af8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5afc:	d65f03c0 	ret
    5b00:	f9400813 	ldr	x19, [x0, #16]
    5b04:	97ffff2c 	bl	57b4 <fwp_rc_free_arr>
    5b08:	911742a0 	add	x0, x21, #0x5d0
    5b0c:	f949d801 	ldr	x1, [x0, #5040]
    5b10:	f949ec00 	ldr	x0, [x0, #5080]
    5b14:	cb010261 	sub	x1, x19, x1
    5b18:	eb00403f 	cmp	x1, x0, lsl #16
    5b1c:	54fffde2 	b.cs	5ad8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b20:	aa1303e0 	mov	x0, x19
    5b24:	17ffffd2 	b	5a6c <fwp_drop1+0x2c>
    5b28:	ca534660 	eor	x0, x19, x19, lsr #17
    5b2c:	911742b5 	add	x21, x21, #0x5d0
    5b30:	ca402400 	eor	x0, x0, x0, lsr #9
    5b34:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b38:	f94a2400 	ldr	x0, [x0, #5192]
    5b3c:	b5000080 	cbnz	x0, 5b4c <fwp_drop1+0x10c>
    5b40:	14000010 	b	5b80 <fwp_drop1+0x140>
    5b44:	f9400800 	ldr	x0, [x0, #16]
    5b48:	b40001c0 	cbz	x0, 5b80 <fwp_drop1+0x140>
    5b4c:	f9400001 	ldr	x1, [x0]
    5b50:	eb13003f 	cmp	x1, x19
    5b54:	54ffff81 	b.ne	5b44 <fwp_drop1+0x104>  // b.any
    5b58:	f9400401 	ldr	x1, [x0, #8]
    5b5c:	d1000421 	sub	x1, x1, #0x1
    5b60:	f9000401 	str	x1, [x0, #8]
    5b64:	f103f83f 	cmp	x1, #0xfe
    5b68:	54fffb81 	b.ne	5ad8 <fwp_drop1+0x98>  // b.any
    5b6c:	aa1303e0 	mov	x0, x19
    5b70:	97fffb20 	bl	47f0 <fwp_rc_forget_slot>
    5b74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b78:	39000260 	strb	w0, [x19]
    5b7c:	17ffffd7 	b	5ad8 <fwp_drop1+0x98>
    5b80:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5b84:	91238000 	add	x0, x0, #0x8e0
    5b88:	97fff71e 	bl	3800 <fwp_trap>
    5b8c:	d503201f 	nop

0000000000005b90 <fwp_closure_drop>:
    5b90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5b94:	911740a4 	add	x4, x5, #0x5d0
    5b98:	aa0003e1 	mov	x1, x0
    5b9c:	f949d882 	ldr	x2, [x4, #5040]
    5ba0:	f949ec80 	ldr	x0, [x4, #5080]
    5ba4:	cb020022 	sub	x2, x1, x2
    5ba8:	eb00405f 	cmp	x2, x0, lsl #16
    5bac:	54000662 	b.cs	5c78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5bb4:	d350fc43 	lsr	x3, x2, #16
    5bb8:	910003fd 	mov	x29, sp
    5bbc:	8b030863 	add	x3, x3, x3, lsl #2
    5bc0:	f949fc84 	ldr	x4, [x4, #5112]
    5bc4:	d37df063 	lsl	x3, x3, #3
    5bc8:	f9000bf3 	str	x19, [sp, #16]
    5bcc:	8b030080 	add	x0, x4, x3
    5bd0:	f9401013 	ldr	x19, [x0, #32]
    5bd4:	b40002b3 	cbz	x19, 5c28 <fwp_closure_drop+0x98>
    5bd8:	38636883 	ldrb	w3, [x4, x3]
    5bdc:	7100087f 	cmp	w3, #0x2
    5be0:	54000420 	b.eq	5c64 <fwp_closure_drop+0xd4>  // b.none
    5be4:	7100047f 	cmp	w3, #0x1
    5be8:	54000201 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5bec:	29430003 	ldp	w3, w0, [x0, #24]
    5bf0:	92403c42 	and	x2, x2, #0xffff
    5bf4:	9b037c42 	mul	x2, x2, x3
    5bf8:	d360fc42 	lsr	x2, x2, #32
    5bfc:	eb00005f 	cmp	x2, x0
    5c00:	54000142 	b.cs	5c28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5c04:	8b020273 	add	x19, x19, x2
    5c08:	39400260 	ldrb	w0, [x19]
    5c0c:	340000e0 	cbz	w0, 5c28 <fwp_closure_drop+0x98>
    5c10:	7100041f 	cmp	w0, #0x1
    5c14:	54000100 	b.eq	5c34 <fwp_closure_drop+0xa4>  // b.none
    5c18:	7103fc1f 	cmp	w0, #0xff
    5c1c:	54000300 	b.eq	5c7c <fwp_closure_drop+0xec>  // b.none
    5c20:	51000400 	sub	w0, w0, #0x1
    5c24:	39000260 	strb	w0, [x19]
    5c28:	f9400bf3 	ldr	x19, [sp, #16]
    5c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c30:	d65f03c0 	ret
    5c34:	d53bd040 	mrs	x0, tpidr_el0
    5c38:	91400000 	add	x0, x0, #0x0, lsl #12
    5c3c:	91004000 	add	x0, x0, #0x10
    5c40:	f9400000 	ldr	x0, [x0]
    5c44:	b4000080 	cbz	x0, 5c54 <fwp_closure_drop+0xc4>
    5c48:	f9400bf3 	ldr	x19, [sp, #16]
    5c4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c50:	17fff705 	b	3864 <fwp_closure_drop_push>
    5c54:	f9400bf3 	ldr	x19, [sp, #16]
    5c58:	aa0103e0 	mov	x0, x1
    5c5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c60:	17fff770 	b	3a20 <fwp_closure_drop.part.0>
    5c64:	72003c5f 	tst	w2, #0xffff
    5c68:	54fffd00 	b.eq	5c08 <fwp_closure_drop+0x78>  // b.none
    5c6c:	f9400bf3 	ldr	x19, [sp, #16]
    5c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c74:	d65f03c0 	ret
    5c78:	d65f03c0 	ret
    5c7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5c80:	911740a5 	add	x5, x5, #0x5d0
    5c84:	ca402400 	eor	x0, x0, x0, lsr #9
    5c88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5c8c:	f94a2400 	ldr	x0, [x0, #5192]
    5c90:	b5000080 	cbnz	x0, 5ca0 <fwp_closure_drop+0x110>
    5c94:	14000010 	b	5cd4 <fwp_closure_drop+0x144>
    5c98:	f9400800 	ldr	x0, [x0, #16]
    5c9c:	b40001c0 	cbz	x0, 5cd4 <fwp_closure_drop+0x144>
    5ca0:	f9400001 	ldr	x1, [x0]
    5ca4:	eb13003f 	cmp	x1, x19
    5ca8:	54ffff81 	b.ne	5c98 <fwp_closure_drop+0x108>  // b.any
    5cac:	f9400401 	ldr	x1, [x0, #8]
    5cb0:	d1000421 	sub	x1, x1, #0x1
    5cb4:	f9000401 	str	x1, [x0, #8]
    5cb8:	f103f83f 	cmp	x1, #0xfe
    5cbc:	54fffb61 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5cc0:	aa1303e0 	mov	x0, x19
    5cc4:	97fffacb 	bl	47f0 <fwp_rc_forget_slot>
    5cc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ccc:	39000260 	strb	w0, [x19]
    5cd0:	17ffffd6 	b	5c28 <fwp_closure_drop+0x98>
    5cd4:	d0000020 	adrp	x0, b000 <__divti3+0x1a0>
    5cd8:	91238000 	add	x0, x0, #0x8e0
    5cdc:	97fff6c9 	bl	3800 <fwp_trap>

0000000000005ce0 <fwp_owned_tape_release>:
    5ce0:	b4000940 	cbz	x0, 5e08 <fwp_owned_tape_release+0x128>
    5ce4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ce8:	910003fd 	mov	x29, sp
    5cec:	a90153f3 	stp	x19, x20, [sp, #16]
    5cf0:	aa0003f3 	mov	x19, x0
    5cf4:	f9400000 	ldr	x0, [x0]
    5cf8:	b4000060 	cbz	x0, 5d04 <fwp_owned_tape_release+0x24>
    5cfc:	f9400661 	ldr	x1, [x19, #8]
    5d00:	f9000401 	str	x1, [x0, #8]
    5d04:	f9400661 	ldr	x1, [x19, #8]
    5d08:	b4000041 	cbz	x1, 5d10 <fwp_owned_tape_release+0x30>
    5d0c:	f9000020 	str	x0, [x1]
    5d10:	f9400a60 	ldr	x0, [x19, #16]
    5d14:	f9403401 	ldr	x1, [x0, #104]
    5d18:	b40005c1 	cbz	x1, 5dd0 <fwp_owned_tape_release+0xf0>
    5d1c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5d20:	eb00005f 	cmp	x2, x0
    5d24:	540002ed 	b.le	5d80 <fwp_owned_tape_release+0xa0>
    5d28:	d2800014 	mov	x20, #0x0                   	// #0
    5d2c:	f90013f5 	str	x21, [sp, #32]
    5d30:	d2800015 	mov	x21, #0x0                   	// #0
    5d34:	d503201f 	nop
    5d38:	f9402260 	ldr	x0, [x19, #64]
    5d3c:	910006b5 	add	x21, x21, #0x1
    5d40:	f8746800 	ldr	x0, [x0, x20]
    5d44:	d63f0020 	blr	x1
    5d48:	f9402260 	ldr	x0, [x19, #64]
    5d4c:	f9400a61 	ldr	x1, [x19, #16]
    5d50:	8b140000 	add	x0, x0, x20
    5d54:	91004294 	add	x20, x20, #0x10
    5d58:	f9400400 	ldr	x0, [x0, #8]
    5d5c:	f9403421 	ldr	x1, [x1, #104]
    5d60:	d63f0020 	blr	x1
    5d64:	a9450261 	ldp	x1, x0, [x19, #80]
    5d68:	cb010000 	sub	x0, x0, x1
    5d6c:	eb15001f 	cmp	x0, x21
    5d70:	f9400a60 	ldr	x0, [x19, #16]
    5d74:	f9403401 	ldr	x1, [x0, #104]
    5d78:	54fffe0c 	b.gt	5d38 <fwp_owned_tape_release+0x58>
    5d7c:	f94013f5 	ldr	x21, [sp, #32]
    5d80:	f9403663 	ldr	x3, [x19, #104]
    5d84:	f9401262 	ldr	x2, [x19, #32]
    5d88:	f100007f 	cmp	x3, #0x0
    5d8c:	540001ed 	b.le	5dc8 <fwp_owned_tape_release+0xe8>
    5d90:	d2800014 	mov	x20, #0x0                   	// #0
    5d94:	d503201f 	nop
    5d98:	f9402660 	ldr	x0, [x19, #72]
    5d9c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5da0:	eb02001f 	cmp	x0, x2
    5da4:	540000c0 	b.eq	5dbc <fwp_owned_tape_release+0xdc>  // b.none
    5da8:	d63f0020 	blr	x1
    5dac:	f9400a60 	ldr	x0, [x19, #16]
    5db0:	f9401262 	ldr	x2, [x19, #32]
    5db4:	f9403663 	ldr	x3, [x19, #104]
    5db8:	f9403401 	ldr	x1, [x0, #104]
    5dbc:	91000694 	add	x20, x20, #0x1
    5dc0:	eb14007f 	cmp	x3, x20
    5dc4:	54fffeac 	b.gt	5d98 <fwp_owned_tape_release+0xb8>
    5dc8:	aa0203e0 	mov	x0, x2
    5dcc:	d63f0020 	blr	x1
    5dd0:	f9401660 	ldr	x0, [x19, #40]
    5dd4:	97ffff6f 	bl	5b90 <fwp_closure_drop>
    5dd8:	f9401a60 	ldr	x0, [x19, #48]
    5ddc:	97ffff6d 	bl	5b90 <fwp_closure_drop>
    5de0:	f9401e60 	ldr	x0, [x19, #56]
    5de4:	97ffff6b 	bl	5b90 <fwp_closure_drop>
    5de8:	f9402260 	ldr	x0, [x19, #64]
    5dec:	97fffb21 	bl	4a70 <fwp_mem_free>
    5df0:	f9402660 	ldr	x0, [x19, #72]
    5df4:	97fffb1f 	bl	4a70 <fwp_mem_free>
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e04:	17fffb1b 	b	4a70 <fwp_mem_free>
    5e08:	d65f03c0 	ret
    5e0c:	d503201f 	nop

0000000000005e10 <fwp_tape_finish>:
    5e10:	d10203ff 	sub	sp, sp, #0x80
    5e14:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5e18:	f947f421 	ldr	x1, [x1, #4072]
    5e1c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5e20:	910103fd 	add	x29, sp, #0x40
    5e24:	a90553f3 	stp	x19, x20, [sp, #80]
    5e28:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e2c:	a90763f7 	stp	x23, x24, [sp, #112]
    5e30:	f00000d8 	adrp	x24, 20000 <__data_start>
    5e34:	9101c316 	add	x22, x24, #0x70
    5e38:	f9400022 	ldr	x2, [x1]
    5e3c:	f9001fe2 	str	x2, [sp, #56]
    5e40:	d2800002 	mov	x2, #0x0                   	// #0
    5e44:	910262c0 	add	x0, x22, #0x98
    5e48:	97fff58e 	bl	3480 <fwp_tape_buffers_dispose>
    5e4c:	f9006adf 	str	xzr, [x22, #208]
    5e50:	f9404ac0 	ldr	x0, [x22, #144]
    5e54:	f100001f 	cmp	x0, #0x0
    5e58:	5400030d 	b.le	5eb8 <fwp_tape_finish+0xa8>
    5e5c:	910003f7 	mov	x23, sp
    5e60:	d2800015 	mov	x21, #0x0                   	// #0
    5e64:	d2800014 	mov	x20, #0x0                   	// #0
    5e68:	f94002d3 	ldr	x19, [x22]
    5e6c:	91000694 	add	x20, x20, #0x1
    5e70:	8b150273 	add	x19, x19, x21
    5e74:	9101a2b5 	add	x21, x21, #0x68
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	97fff445 	bl	2f90 <fwp_tape_unlink_scope>
    5e80:	aa1703e0 	mov	x0, x23
    5e84:	f9401261 	ldr	x1, [x19, #32]
    5e88:	f90003e1 	str	x1, [sp]
    5e8c:	f9401a62 	ldr	x2, [x19, #48]
    5e90:	f9000be2 	str	x2, [sp, #16]
    5e94:	f9402261 	ldr	x1, [x19, #64]
    5e98:	f90013e1 	str	x1, [sp, #32]
    5e9c:	97fff579 	bl	3480 <fwp_tape_buffers_dispose>
    5ea0:	f9403260 	ldr	x0, [x19, #96]
    5ea4:	97ffff8f 	bl	5ce0 <fwp_owned_tape_release>
    5ea8:	f900327f 	str	xzr, [x19, #96]
    5eac:	f9404ac0 	ldr	x0, [x22, #144]
    5eb0:	eb14001f 	cmp	x0, x20
    5eb4:	54fffdac 	b.gt	5e68 <fwp_tape_finish+0x58>
    5eb8:	f9403b00 	ldr	x0, [x24, #112]
    5ebc:	9101c313 	add	x19, x24, #0x70
    5ec0:	97fff2a0 	bl	2940 <free@plt>
    5ec4:	f9003b1f 	str	xzr, [x24, #112]
    5ec8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5ecc:	f947f400 	ldr	x0, [x0, #4072]
    5ed0:	f9004a7f 	str	xzr, [x19, #144]
    5ed4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    5ed8:	f9401fe2 	ldr	x2, [sp, #56]
    5edc:	f9400001 	ldr	x1, [x0]
    5ee0:	eb010042 	subs	x2, x2, x1
    5ee4:	d2800001 	mov	x1, #0x0                   	// #0
    5ee8:	540000e1 	b.ne	5f04 <fwp_tape_finish+0xf4>  // b.any
    5eec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5ef0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5ef4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5ef8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5efc:	910203ff 	add	sp, sp, #0x80
    5f00:	d65f03c0 	ret
    5f04:	97fff25f 	bl	2880 <__stack_chk_fail@plt>
    5f08:	d503201f 	nop
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_tape_scope_release>:
    5f10:	d10243ff 	sub	sp, sp, #0x90
    5f14:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f18:	910103fd 	add	x29, sp, #0x40
    5f1c:	a90553f3 	stp	x19, x20, [sp, #80]
    5f20:	aa0003f4 	mov	x20, x0
    5f24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f28:	f947f400 	ldr	x0, [x0, #4072]
    5f2c:	b9400285 	ldr	w5, [x20]
    5f30:	f9400001 	ldr	x1, [x0]
    5f34:	f9001fe1 	str	x1, [sp, #56]
    5f38:	d2800001 	mov	x1, #0x0                   	// #0
    5f3c:	37f806c5 	tbnz	w5, #31, 6014 <fwp_tape_scope_release+0x104>
    5f40:	a90763f7 	stp	x23, x24, [sp, #112]
    5f44:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5f48:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5f4c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5f50:	f00000d3 	adrp	x19, 20000 <__data_start>
    5f54:	910003f7 	mov	x23, sp
    5f58:	9101c273 	add	x19, x19, #0x70
    5f5c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5f60:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f64:	52800d16 	mov	w22, #0x68                  	// #104
    5f68:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5f6c:	f90043f9 	str	x25, [sp, #128]
    5f70:	14000006 	b	5f88 <fwp_tape_scope_release+0x78>
    5f74:	97fff543 	bl	3480 <fwp_tape_buffers_dispose>
    5f78:	aa1903e0 	mov	x0, x25
    5f7c:	97ffff59 	bl	5ce0 <fwp_owned_tape_release>
    5f80:	b9400285 	ldr	w5, [x20]
    5f84:	37f80425 	tbnz	w5, #31, 6008 <fwp_tape_scope_release+0xf8>
    5f88:	f9400266 	ldr	x6, [x19]
    5f8c:	9b367ca5 	smull	x5, w5, w22
    5f90:	8b0500c0 	add	x0, x6, x5
    5f94:	97fff3ff 	bl	2f90 <fwp_tape_unlink_scope>
    5f98:	ad410001 	ldp	q1, q0, [x0, #32]
    5f9c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5fa0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5fa4:	f9400c03 	ldr	x3, [x0, #24]
    5fa8:	ad0003e1 	stp	q1, q0, [sp]
    5fac:	b86568c1 	ldr	w1, [x6, x5]
    5fb0:	a9440804 	ldp	x4, x2, [x0, #64]
    5fb4:	b900041f 	str	wzr, [x0, #4]
    5fb8:	f9403019 	ldr	x25, [x0, #96]
    5fbc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5fc0:	f9000c1f 	str	xzr, [x0, #24]
    5fc4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5fc8:	f9001be2 	str	x2, [sp, #48]
    5fcc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5fd0:	f900301f 	str	xzr, [x0, #96]
    5fd4:	6b15003f 	cmp	w1, w21
    5fd8:	540000e8 	b.hi	5ff4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5fdc:	9343fca5 	asr	x5, x5, #3
    5fe0:	f9407660 	ldr	x0, [x19, #232]
    5fe4:	9b187ca5 	mul	x5, x5, x24
    5fe8:	eb0000bf 	cmp	x5, x0
    5fec:	5400004a 	b.ge	5ff4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5ff0:	f9007665 	str	x5, [x19, #232]
    5ff4:	aa1703e0 	mov	x0, x23
    5ff8:	b5fffbf9 	cbnz	x25, 5f74 <fwp_tape_scope_release+0x64>
    5ffc:	97fff8e1 	bl	4380 <fwp_tape_buffers_release>
    6000:	b9400285 	ldr	w5, [x20]
    6004:	36fffc25 	tbz	w5, #31, 5f88 <fwp_tape_scope_release+0x78>
    6008:	a9465bf5 	ldp	x21, x22, [sp, #96]
    600c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6010:	f94043f9 	ldr	x25, [sp, #128]
    6014:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6018:	f947f400 	ldr	x0, [x0, #4072]
    601c:	f9401fe2 	ldr	x2, [sp, #56]
    6020:	f9400001 	ldr	x1, [x0]
    6024:	eb010042 	subs	x2, x2, x1
    6028:	d2800001 	mov	x1, #0x0                   	// #0
    602c:	540000a1 	b.ne	6040 <fwp_tape_scope_release+0x130>  // b.any
    6030:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6034:	a94553f3 	ldp	x19, x20, [sp, #80]
    6038:	910243ff 	add	sp, sp, #0x90
    603c:	d65f03c0 	ret
    6040:	a9065bf5 	stp	x21, x22, [sp, #96]
    6044:	a90763f7 	stp	x23, x24, [sp, #112]
    6048:	f90043f9 	str	x25, [sp, #128]
    604c:	97fff20d 	bl	2880 <__stack_chk_fail@plt>

0000000000006050 <fwp_task_dispose>:
    6050:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6054:	910003fd 	mov	x29, sp
    6058:	f9000bf3 	str	x19, [sp, #16]
    605c:	aa0003f3 	mov	x19, x0
    6060:	39414000 	ldrb	w0, [x0, #80]
    6064:	36000720 	tbz	w0, #0, 6148 <fwp_task_dispose+0xf8>
    6068:	f9400a60 	ldr	x0, [x19, #16]
    606c:	b50006e0 	cbnz	x0, 6148 <fwp_task_dispose+0xf8>
    6070:	a9478660 	ldp	x0, x1, [x19, #120]
    6074:	39014e7f 	strb	wzr, [x19, #83]
    6078:	f9003e7f 	str	xzr, [x19, #120]
    607c:	f100003f 	cmp	x1, #0x0
    6080:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6084:	54000040 	b.eq	608c <fwp_task_dispose+0x3c>  // b.none
    6088:	d63f0020 	blr	x1
    608c:	f9405660 	ldr	x0, [x19, #168]
    6090:	97fffa78 	bl	4a70 <fwp_mem_free>
    6094:	f900567f 	str	xzr, [x19, #168]
    6098:	b9405e60 	ldr	w0, [x19, #92]
    609c:	7100041f 	cmp	w0, #0x1
    60a0:	54000420 	b.eq	6124 <fwp_task_dispose+0xd4>  // b.none
    60a4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    60a8:	91174042 	add	x2, x2, #0x5d0
    60ac:	f949d840 	ldr	x0, [x2, #5040]
    60b0:	f949ec41 	ldr	x1, [x2, #5080]
    60b4:	cb000260 	sub	x0, x19, x0
    60b8:	eb01401f 	cmp	x0, x1, lsl #16
    60bc:	540002e2 	b.cs	6118 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    60c0:	d350fc01 	lsr	x1, x0, #16
    60c4:	f949fc44 	ldr	x4, [x2, #5112]
    60c8:	8b010821 	add	x1, x1, x1, lsl #2
    60cc:	d37df021 	lsl	x1, x1, #3
    60d0:	8b010083 	add	x3, x4, x1
    60d4:	f9401062 	ldr	x2, [x3, #32]
    60d8:	b4000202 	cbz	x2, 6118 <fwp_task_dispose+0xc8>
    60dc:	38616881 	ldrb	w1, [x4, x1]
    60e0:	7100083f 	cmp	w1, #0x2
    60e4:	54000280 	b.eq	6134 <fwp_task_dispose+0xe4>  // b.none
    60e8:	7100043f 	cmp	w1, #0x1
    60ec:	54000161 	b.ne	6118 <fwp_task_dispose+0xc8>  // b.any
    60f0:	29430464 	ldp	w4, w1, [x3, #24]
    60f4:	92403c00 	and	x0, x0, #0xffff
    60f8:	9b047c00 	mul	x0, x0, x4
    60fc:	d360fc00 	lsr	x0, x0, #32
    6100:	eb01001f 	cmp	x0, x1
    6104:	540000a2 	b.cs	6118 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6108:	8b000042 	add	x2, x2, x0
    610c:	39400040 	ldrb	w0, [x2]
    6110:	7100041f 	cmp	w0, #0x1
    6114:	54000080 	b.eq	6124 <fwp_task_dispose+0xd4>  // b.none
    6118:	f9400bf3 	ldr	x19, [sp, #16]
    611c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6120:	d65f03c0 	ret
    6124:	aa1303e0 	mov	x0, x19
    6128:	f9400bf3 	ldr	x19, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	17fffa50 	b	4a70 <fwp_mem_free>
    6134:	72003c1f 	tst	w0, #0xffff
    6138:	54fffea0 	b.eq	610c <fwp_task_dispose+0xbc>  // b.none
    613c:	f9400bf3 	ldr	x19, [sp, #16]
    6140:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6144:	d65f03c0 	ret
    6148:	97fff1e2 	bl	28d0 <abort@plt>
    614c:	d503201f 	nop

0000000000006150 <fwp_free_zombie>:
    6150:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6154:	910003fd 	mov	x29, sp
    6158:	a90153f3 	stp	x19, x20, [sp, #16]
    615c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6160:	9101c281 	add	x1, x20, #0x70
    6164:	f9407833 	ldr	x19, [x1, #240]
    6168:	b4000333 	cbz	x19, 61cc <fwp_free_zombie+0x7c>
    616c:	f9400820 	ldr	x0, [x1, #16]
    6170:	eb00027f 	cmp	x19, x0
    6174:	540002c0 	b.eq	61cc <fwp_free_zombie+0x7c>  // b.none
    6178:	b940f822 	ldr	w2, [x1, #248]
    617c:	f9400a60 	ldr	x0, [x19, #16]
    6180:	7100fc5f 	cmp	w2, #0x3f
    6184:	5400078c 	b.gt	6274 <fwp_free_zombie+0x124>
    6188:	91040023 	add	x3, x1, #0x100
    618c:	11000444 	add	w4, w2, #0x1
    6190:	b900f824 	str	w4, [x1, #248]
    6194:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6198:	f822d860 	str	x0, [x3, w2, sxtw #3]
    619c:	a9530261 	ldp	x1, x0, [x19, #304]
    61a0:	b4000741 	cbz	x1, 6288 <fwp_free_zombie+0x138>
    61a4:	f9009c20 	str	x0, [x1, #312]
    61a8:	b4000040 	cbz	x0, 61b0 <fwp_free_zombie+0x60>
    61ac:	f9009801 	str	x1, [x0, #304]
    61b0:	9101c294 	add	x20, x20, #0x70
    61b4:	b9405e60 	ldr	w0, [x19, #92]
    61b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    61bc:	f9007a9f 	str	xzr, [x20, #240]
    61c0:	34000140 	cbz	w0, 61e8 <fwp_free_zombie+0x98>
    61c4:	7100041f 	cmp	w0, #0x1
    61c8:	54000080 	b.eq	61d8 <fwp_free_zombie+0x88>  // b.none
    61cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d4:	d65f03c0 	ret
    61d8:	aa1303e0 	mov	x0, x19
    61dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e4:	17ffff9b 	b	6050 <fwp_task_dispose>
    61e8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    61ec:	91174082 	add	x2, x4, #0x5d0
    61f0:	f949d841 	ldr	x1, [x2, #5040]
    61f4:	f949ec40 	ldr	x0, [x2, #5080]
    61f8:	cb010261 	sub	x1, x19, x1
    61fc:	eb00403f 	cmp	x1, x0, lsl #16
    6200:	54fffe62 	b.cs	61cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6204:	d350fc20 	lsr	x0, x1, #16
    6208:	f949fc43 	ldr	x3, [x2, #5112]
    620c:	8b000800 	add	x0, x0, x0, lsl #2
    6210:	d37df000 	lsl	x0, x0, #3
    6214:	8b000062 	add	x2, x3, x0
    6218:	f9401054 	ldr	x20, [x2, #32]
    621c:	b4fffd94 	cbz	x20, 61cc <fwp_free_zombie+0x7c>
    6220:	38606860 	ldrb	w0, [x3, x0]
    6224:	7100081f 	cmp	w0, #0x2
    6228:	54000360 	b.eq	6294 <fwp_free_zombie+0x144>  // b.none
    622c:	7100041f 	cmp	w0, #0x1
    6230:	54fffce1 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    6234:	29430043 	ldp	w3, w0, [x2, #24]
    6238:	92403c21 	and	x1, x1, #0xffff
    623c:	9b037c21 	mul	x1, x1, x3
    6240:	d360fc21 	lsr	x1, x1, #32
    6244:	eb00003f 	cmp	x1, x0
    6248:	54fffc22 	b.cs	61cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    624c:	8b010294 	add	x20, x20, x1
    6250:	39400280 	ldrb	w0, [x20]
    6254:	34fffbc0 	cbz	w0, 61cc <fwp_free_zombie+0x7c>
    6258:	7100041f 	cmp	w0, #0x1
    625c:	54fffbe0 	b.eq	61d8 <fwp_free_zombie+0x88>  // b.none
    6260:	7103fc1f 	cmp	w0, #0xff
    6264:	540001e0 	b.eq	62a0 <fwp_free_zombie+0x150>  // b.none
    6268:	51000400 	sub	w0, w0, #0x1
    626c:	39000280 	strb	w0, [x20]
    6270:	17ffffd7 	b	61cc <fwp_free_zombie+0x7c>
    6274:	f9400e61 	ldr	x1, [x19, #24]
    6278:	97fff1ca 	bl	29a0 <munmap@plt>
    627c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6280:	a9530261 	ldp	x1, x0, [x19, #304]
    6284:	b5fff901 	cbnz	x1, 61a4 <fwp_free_zombie+0x54>
    6288:	9101c282 	add	x2, x20, #0x70
    628c:	f9018040 	str	x0, [x2, #768]
    6290:	17ffffc6 	b	61a8 <fwp_free_zombie+0x58>
    6294:	72003c3f 	tst	w1, #0xffff
    6298:	54fff9a1 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    629c:	17ffffed 	b	6250 <fwp_free_zombie+0x100>
    62a0:	ca544680 	eor	x0, x20, x20, lsr #17
    62a4:	91174084 	add	x4, x4, #0x5d0
    62a8:	ca402400 	eor	x0, x0, x0, lsr #9
    62ac:	8b200c80 	add	x0, x4, w0, uxtb #3
    62b0:	f94a2400 	ldr	x0, [x0, #5192]
    62b4:	b5000080 	cbnz	x0, 62c4 <fwp_free_zombie+0x174>
    62b8:	14000010 	b	62f8 <fwp_free_zombie+0x1a8>
    62bc:	f9400800 	ldr	x0, [x0, #16]
    62c0:	b40001c0 	cbz	x0, 62f8 <fwp_free_zombie+0x1a8>
    62c4:	f9400001 	ldr	x1, [x0]
    62c8:	eb14003f 	cmp	x1, x20
    62cc:	54ffff81 	b.ne	62bc <fwp_free_zombie+0x16c>  // b.any
    62d0:	f9400401 	ldr	x1, [x0, #8]
    62d4:	d1000421 	sub	x1, x1, #0x1
    62d8:	f9000401 	str	x1, [x0, #8]
    62dc:	f103f83f 	cmp	x1, #0xfe
    62e0:	54fff761 	b.ne	61cc <fwp_free_zombie+0x7c>  // b.any
    62e4:	aa1403e0 	mov	x0, x20
    62e8:	97fff942 	bl	47f0 <fwp_rc_forget_slot>
    62ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62f0:	39000280 	strb	w0, [x20]
    62f4:	17ffffb6 	b	61cc <fwp_free_zombie+0x7c>
    62f8:	b0000020 	adrp	x0, b000 <__divti3+0x1a0>
    62fc:	91238000 	add	x0, x0, #0x8e0
    6300:	97fff540 	bl	3800 <fwp_trap>

0000000000006304 <fwp_block>:
    6304:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6308:	910003fd 	mov	x29, sp
    630c:	a90153f3 	stp	x19, x20, [sp, #16]
    6310:	d00000d3 	adrp	x19, 20000 <__data_start>
    6314:	9101c274 	add	x20, x19, #0x70
    6318:	f9404282 	ldr	x2, [x20, #128]
    631c:	b4000622 	cbz	x2, 63e0 <fwp_block+0xdc>
    6320:	9101c261 	add	x1, x19, #0x70
    6324:	f9408040 	ldr	x0, [x2, #256]
    6328:	f9004020 	str	x0, [x1, #128]
    632c:	b4000680 	cbz	x0, 63fc <fwp_block+0xf8>
    6330:	9101c263 	add	x3, x19, #0x70
    6334:	3901505f 	strb	wzr, [x2, #84]
    6338:	f9400864 	ldr	x4, [x3, #16]
    633c:	eb02009f 	cmp	x4, x2
    6340:	54000440 	b.eq	63c8 <fwp_block+0xc4>  // b.none
    6344:	f9418465 	ldr	x5, [x3, #776]
    6348:	f9000862 	str	x2, [x3, #16]
    634c:	f9400441 	ldr	x1, [x2, #8]
    6350:	f9004885 	str	x5, [x4, #144]
    6354:	f9418865 	ldr	x5, [x3, #784]
    6358:	f9004c85 	str	x5, [x4, #152]
    635c:	f9418c65 	ldr	x5, [x3, #792]
    6360:	f9005085 	str	x5, [x4, #160]
    6364:	f9419065 	ldr	x5, [x3, #800]
    6368:	f9005485 	str	x5, [x4, #168]
    636c:	f9419465 	ldr	x5, [x3, #808]
    6370:	f9005885 	str	x5, [x4, #176]
    6374:	f9419865 	ldr	x5, [x3, #816]
    6378:	f9005c85 	str	x5, [x4, #184]
    637c:	f9419c65 	ldr	x5, [x3, #824]
    6380:	f9006085 	str	x5, [x4, #192]
    6384:	f9400480 	ldr	x0, [x4, #8]
    6388:	f9404844 	ldr	x4, [x2, #144]
    638c:	f9018464 	str	x4, [x3, #776]
    6390:	f9404c44 	ldr	x4, [x2, #152]
    6394:	f9018864 	str	x4, [x3, #784]
    6398:	f9405044 	ldr	x4, [x2, #160]
    639c:	f9018c64 	str	x4, [x3, #792]
    63a0:	f9405444 	ldr	x4, [x2, #168]
    63a4:	f9019064 	str	x4, [x3, #800]
    63a8:	f9405844 	ldr	x4, [x2, #176]
    63ac:	f9019464 	str	x4, [x3, #808]
    63b0:	a94b8844 	ldp	x4, x2, [x2, #184]
    63b4:	f9019864 	str	x4, [x3, #816]
    63b8:	f9019c62 	str	x2, [x3, #824]
    63bc:	97fff149 	bl	28e0 <swapcontext@plt>
    63c0:	97ffff64 	bl	6150 <fwp_free_zombie>
    63c4:	d503201f 	nop
    63c8:	9101c260 	add	x0, x19, #0x70
    63cc:	b9434000 	ldr	w0, [x0, #832]
    63d0:	340001a0 	cbz	w0, 6404 <fwp_block+0x100>
    63d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63dc:	d65f03c0 	ret
    63e0:	97fff830 	bl	44a0 <fwp_poll_events>
    63e4:	f9404282 	ldr	x2, [x20, #128]
    63e8:	b4ffffc2 	cbz	x2, 63e0 <fwp_block+0xdc>
    63ec:	9101c261 	add	x1, x19, #0x70
    63f0:	f9408040 	ldr	x0, [x2, #256]
    63f4:	f9004020 	str	x0, [x1, #128]
    63f8:	b5fff9c0 	cbnz	x0, 6330 <fwp_block+0x2c>
    63fc:	f9003c3f 	str	xzr, [x1, #120]
    6400:	17ffffcc 	b	6330 <fwp_block+0x2c>
    6404:	b0000020 	adrp	x0, b000 <__divti3+0x1a0>
    6408:	91284000 	add	x0, x0, #0xa10
    640c:	97fff181 	bl	2a10 <getenv@plt>
    6410:	5284e202 	mov	w2, #0x2710                	// #10000
    6414:	b4000060 	cbz	x0, 6420 <fwp_block+0x11c>
    6418:	39400001 	ldrb	w1, [x0]
    641c:	350000c1 	cbnz	w1, 6434 <fwp_block+0x130>
    6420:	9101c273 	add	x19, x19, #0x70
    6424:	b9034262 	str	w2, [x19, #832]
    6428:	a94153f3 	ldp	x19, x20, [sp, #16]
    642c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6430:	d65f03c0 	ret
    6434:	52800142 	mov	w2, #0xa                   	// #10
    6438:	d2800001 	mov	x1, #0x0                   	// #0
    643c:	97fff0c5 	bl	2750 <strtoll@plt>
    6440:	d1000403 	sub	x3, x0, #0x1
    6444:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6448:	eb02007f 	cmp	x3, x2
    644c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6450:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6454:	17fffff3 	b	6420 <fwp_block+0x11c>
    6458:	d503201f 	nop
    645c:	d503201f 	nop

0000000000006460 <fwp_owned_entry161>:
    6460:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6464:	910003fd 	mov	x29, sp
    6468:	a90363f7 	stp	x23, x24, [sp, #48]
    646c:	a9406002 	ldp	x2, x24, [x0]
    6470:	a90153f3 	stp	x19, x20, [sp, #16]
    6474:	f9400801 	ldr	x1, [x0, #16]
    6478:	a9025bf5 	stp	x21, x22, [sp, #32]
    647c:	ab010055 	adds	x21, x2, x1
    6480:	54000d06 	b.vs	6620 <fwp_owned_entry161+0x1c0>
    6484:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6488:	91174281 	add	x1, x20, #0x5d0
    648c:	b953a420 	ldr	w0, [x1, #5028]
    6490:	34000a80 	cbz	w0, 65e0 <fwp_owned_entry161+0x180>
    6494:	397e8820 	ldrb	w0, [x1, #4002]
    6498:	910f0002 	add	x2, x0, #0x3c0
    649c:	8b000400 	add	x0, x0, x0, lsl #1
    64a0:	d37df000 	lsl	x0, x0, #3
    64a4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    64a8:	2a1703f6 	mov	w22, w23
    64ac:	f8606833 	ldr	x19, [x1, x0]
    64b0:	b4000853 	cbz	x19, 65b8 <fwp_owned_entry161+0x158>
    64b4:	f9400262 	ldr	x2, [x19]
    64b8:	aa2203e2 	mvn	x2, x2
    64bc:	f8206822 	str	x2, [x1, x0]
    64c0:	f10062df 	cmp	x22, #0x18
    64c4:	540000e9 	b.ls	64e0 <fwp_owned_entry161+0x80>  // b.plast
    64c8:	d10066c2 	sub	x2, x22, #0x19
    64cc:	91006260 	add	x0, x19, #0x18
    64d0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    64d4:	52800001 	mov	w1, #0x0                   	// #0
    64d8:	91002042 	add	x2, x2, #0x8
    64dc:	97fff0dd 	bl	2850 <memset@plt>
    64e0:	91174281 	add	x1, x20, #0x5d0
    64e4:	f94a1020 	ldr	x0, [x1, #5152]
    64e8:	ab160000 	adds	x0, x0, x22
    64ec:	540009c2 	b.cs	6624 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    64f0:	f94a1422 	ldr	x2, [x1, #5160]
    64f4:	f90a1020 	str	x0, [x1, #5152]
    64f8:	eb02001f 	cmp	x0, x2
    64fc:	54000049 	b.ls	6504 <fwp_owned_entry161+0xa4>  // b.plast
    6500:	f90a1420 	str	x0, [x1, #5160]
    6504:	91174280 	add	x0, x20, #0x5d0
    6508:	1e6302e1 	ucvtf	d1, w23
    650c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6510:	1e612800 	fadd	d0, d0, d1
    6514:	fd0a1c00 	str	d0, [x0, #5176]
    6518:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    651c:	91174294 	add	x20, x20, #0x5d0
    6520:	a900d678 	stp	x24, x21, [x19, #8]
    6524:	fd41b800 	ldr	d0, [x0, #880]
    6528:	fd000260 	str	d0, [x19]
    652c:	f949da81 	ldr	x1, [x20, #5040]
    6530:	f949ee80 	ldr	x0, [x20, #5080]
    6534:	cb010261 	sub	x1, x19, x1
    6538:	eb00403f 	cmp	x1, x0, lsl #16
    653c:	54000322 	b.cs	65a0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6540:	d350fc20 	lsr	x0, x1, #16
    6544:	f949fe83 	ldr	x3, [x20, #5112]
    6548:	8b000800 	add	x0, x0, x0, lsl #2
    654c:	d37df002 	lsl	x2, x0, #3
    6550:	8b020060 	add	x0, x3, x2
    6554:	f9401014 	ldr	x20, [x0, #32]
    6558:	b4000254 	cbz	x20, 65a0 <fwp_owned_entry161+0x140>
    655c:	38626862 	ldrb	w2, [x3, x2]
    6560:	7100085f 	cmp	w2, #0x2
    6564:	54000480 	b.eq	65f4 <fwp_owned_entry161+0x194>  // b.none
    6568:	7100045f 	cmp	w2, #0x1
    656c:	540001a1 	b.ne	65a0 <fwp_owned_entry161+0x140>  // b.any
    6570:	29430002 	ldp	w2, w0, [x0, #24]
    6574:	92403c21 	and	x1, x1, #0xffff
    6578:	9b027c21 	mul	x1, x1, x2
    657c:	d360fc21 	lsr	x1, x1, #32
    6580:	eb00003f 	cmp	x1, x0
    6584:	540000e2 	b.cs	65a0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6588:	8b010294 	add	x20, x20, x1
    658c:	39400280 	ldrb	w0, [x20]
    6590:	7103fc1f 	cmp	w0, #0xff
    6594:	54000400 	b.eq	6614 <fwp_owned_entry161+0x1b4>  // b.none
    6598:	52800020 	mov	w0, #0x1                   	// #1
    659c:	39000280 	strb	w0, [x20]
    65a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65a4:	aa1303e0 	mov	x0, x19
    65a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    65b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    65b4:	d65f03c0 	ret
    65b8:	8b000021 	add	x1, x1, x0
    65bc:	f9400433 	ldr	x19, [x1, #8]
    65c0:	b4000113 	cbz	x19, 65e0 <fwp_owned_entry161+0x180>
    65c4:	f9400820 	ldr	x0, [x1, #16]
    65c8:	cb130000 	sub	x0, x0, x19
    65cc:	eb0002df 	cmp	x22, x0
    65d0:	54000088 	b.hi	65e0 <fwp_owned_entry161+0x180>  // b.pmore
    65d4:	8b160260 	add	x0, x19, x22
    65d8:	f9000420 	str	x0, [x1, #8]
    65dc:	17ffffb9 	b	64c0 <fwp_owned_entry161+0x60>
    65e0:	52800001 	mov	w1, #0x0                   	// #0
    65e4:	d2800300 	mov	x0, #0x18                  	// #24
    65e8:	97fffa42 	bl	4ef0 <fwp_heap_alloc>
    65ec:	aa0003f3 	mov	x19, x0
    65f0:	17ffffca 	b	6518 <fwp_owned_entry161+0xb8>
    65f4:	72003c3f 	tst	w1, #0xffff
    65f8:	54fffca0 	b.eq	658c <fwp_owned_entry161+0x12c>  // b.none
    65fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6600:	aa1303e0 	mov	x0, x19
    6604:	a94153f3 	ldp	x19, x20, [sp, #16]
    6608:	a94363f7 	ldp	x23, x24, [sp, #48]
    660c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6610:	d65f03c0 	ret
    6614:	aa1403e0 	mov	x0, x20
    6618:	97fff876 	bl	47f0 <fwp_rc_forget_slot>
    661c:	17ffffdf 	b	6598 <fwp_owned_entry161+0x138>
    6620:	97fff118 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6624:	97fff283 	bl	3030 <fwp_heap_oom>
    6628:	d503201f 	nop
    662c:	d503201f 	nop

0000000000006630 <e161>:
    6630:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6634:	910003fd 	mov	x29, sp
    6638:	a90363f7 	stp	x23, x24, [sp, #48]
    663c:	a9406002 	ldp	x2, x24, [x0]
    6640:	a90153f3 	stp	x19, x20, [sp, #16]
    6644:	f9400801 	ldr	x1, [x0, #16]
    6648:	a9025bf5 	stp	x21, x22, [sp, #32]
    664c:	ab010055 	adds	x21, x2, x1
    6650:	54000d86 	b.vs	6800 <e161+0x1d0>
    6654:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6658:	91174281 	add	x1, x20, #0x5d0
    665c:	b953a420 	ldr	w0, [x1, #5028]
    6660:	34000ac0 	cbz	w0, 67b8 <e161+0x188>
    6664:	397e8820 	ldrb	w0, [x1, #4002]
    6668:	910f0002 	add	x2, x0, #0x3c0
    666c:	8b000400 	add	x0, x0, x0, lsl #1
    6670:	d37df000 	lsl	x0, x0, #3
    6674:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6678:	2a1703f6 	mov	w22, w23
    667c:	f8606833 	ldr	x19, [x1, x0]
    6680:	b4000893 	cbz	x19, 6790 <e161+0x160>
    6684:	f9400262 	ldr	x2, [x19]
    6688:	aa2203e2 	mvn	x2, x2
    668c:	f8206822 	str	x2, [x1, x0]
    6690:	f10062df 	cmp	x22, #0x18
    6694:	540000e9 	b.ls	66b0 <e161+0x80>  // b.plast
    6698:	d10066c2 	sub	x2, x22, #0x19
    669c:	91006260 	add	x0, x19, #0x18
    66a0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    66a4:	52800001 	mov	w1, #0x0                   	// #0
    66a8:	91002042 	add	x2, x2, #0x8
    66ac:	97fff069 	bl	2850 <memset@plt>
    66b0:	91174281 	add	x1, x20, #0x5d0
    66b4:	f94a1020 	ldr	x0, [x1, #5152]
    66b8:	ab160000 	adds	x0, x0, x22
    66bc:	54000a42 	b.cs	6804 <e161+0x1d4>  // b.hs, b.nlast
    66c0:	f94a1422 	ldr	x2, [x1, #5160]
    66c4:	f90a1020 	str	x0, [x1, #5152]
    66c8:	eb02001f 	cmp	x0, x2
    66cc:	54000049 	b.ls	66d4 <e161+0xa4>  // b.plast
    66d0:	f90a1420 	str	x0, [x1, #5160]
    66d4:	91174280 	add	x0, x20, #0x5d0
    66d8:	1e6302e1 	ucvtf	d1, w23
    66dc:	fd4a1c00 	ldr	d0, [x0, #5176]
    66e0:	1e612800 	fadd	d0, d0, d1
    66e4:	fd0a1c00 	str	d0, [x0, #5176]
    66e8:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    66ec:	91174294 	add	x20, x20, #0x5d0
    66f0:	a900d678 	stp	x24, x21, [x19, #8]
    66f4:	fd41b800 	ldr	d0, [x0, #880]
    66f8:	fd000260 	str	d0, [x19]
    66fc:	f949da81 	ldr	x1, [x20, #5040]
    6700:	f949ee80 	ldr	x0, [x20, #5080]
    6704:	cb010261 	sub	x1, x19, x1
    6708:	eb00403f 	cmp	x1, x0, lsl #16
    670c:	54000322 	b.cs	6770 <e161+0x140>  // b.hs, b.nlast
    6710:	d350fc20 	lsr	x0, x1, #16
    6714:	f949fe83 	ldr	x3, [x20, #5112]
    6718:	8b000800 	add	x0, x0, x0, lsl #2
    671c:	d37df002 	lsl	x2, x0, #3
    6720:	8b020060 	add	x0, x3, x2
    6724:	f9401014 	ldr	x20, [x0, #32]
    6728:	b4000254 	cbz	x20, 6770 <e161+0x140>
    672c:	38626862 	ldrb	w2, [x3, x2]
    6730:	7100085f 	cmp	w2, #0x2
    6734:	540004c0 	b.eq	67cc <e161+0x19c>  // b.none
    6738:	7100045f 	cmp	w2, #0x1
    673c:	540001a1 	b.ne	6770 <e161+0x140>  // b.any
    6740:	29430002 	ldp	w2, w0, [x0, #24]
    6744:	92403c21 	and	x1, x1, #0xffff
    6748:	9b027c21 	mul	x1, x1, x2
    674c:	d360fc21 	lsr	x1, x1, #32
    6750:	eb00003f 	cmp	x1, x0
    6754:	540000e2 	b.cs	6770 <e161+0x140>  // b.hs, b.nlast
    6758:	8b010294 	add	x20, x20, x1
    675c:	39400280 	ldrb	w0, [x20]
    6760:	7103fc1f 	cmp	w0, #0xff
    6764:	54000480 	b.eq	67f4 <e161+0x1c4>  // b.none
    6768:	52800020 	mov	w0, #0x1                   	// #1
    676c:	39000280 	strb	w0, [x20]
    6770:	aa1303e0 	mov	x0, x19
    6774:	97fffbeb 	bl	5720 <fwp_rc_share>
    6778:	a9425bf5 	ldp	x21, x22, [sp, #32]
    677c:	aa1303e0 	mov	x0, x19
    6780:	a94153f3 	ldp	x19, x20, [sp, #16]
    6784:	a94363f7 	ldp	x23, x24, [sp, #48]
    6788:	a8c47bfd 	ldp	x29, x30, [sp], #64
    678c:	d65f03c0 	ret
    6790:	8b000021 	add	x1, x1, x0
    6794:	f9400433 	ldr	x19, [x1, #8]
    6798:	b4000113 	cbz	x19, 67b8 <e161+0x188>
    679c:	f9400820 	ldr	x0, [x1, #16]
    67a0:	cb130000 	sub	x0, x0, x19
    67a4:	eb0002df 	cmp	x22, x0
    67a8:	54000088 	b.hi	67b8 <e161+0x188>  // b.pmore
    67ac:	8b160260 	add	x0, x19, x22
    67b0:	f9000420 	str	x0, [x1, #8]
    67b4:	17ffffb7 	b	6690 <e161+0x60>
    67b8:	52800001 	mov	w1, #0x0                   	// #0
    67bc:	d2800300 	mov	x0, #0x18                  	// #24
    67c0:	97fff9cc 	bl	4ef0 <fwp_heap_alloc>
    67c4:	aa0003f3 	mov	x19, x0
    67c8:	17ffffc8 	b	66e8 <e161+0xb8>
    67cc:	72003c3f 	tst	w1, #0xffff
    67d0:	54fffc60 	b.eq	675c <e161+0x12c>  // b.none
    67d4:	aa1303e0 	mov	x0, x19
    67d8:	97fffbd2 	bl	5720 <fwp_rc_share>
    67dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    67e0:	aa1303e0 	mov	x0, x19
    67e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    67ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    67f0:	d65f03c0 	ret
    67f4:	aa1403e0 	mov	x0, x20
    67f8:	97fff7fe 	bl	47f0 <fwp_rc_forget_slot>
    67fc:	17ffffdb 	b	6768 <e161+0x138>
    6800:	97fff0a0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    6804:	97fff20b 	bl	3030 <fwp_heap_oom>
    6808:	d503201f 	nop
    680c:	d503201f 	nop

0000000000006810 <fwp_drop4>:
    6810:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6814:	910003fd 	mov	x29, sp
    6818:	a90153f3 	stp	x19, x20, [sp, #16]
    681c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6820:	f90013f5 	str	x21, [sp, #32]
    6824:	91174275 	add	x21, x19, #0x5d0
    6828:	f949daa1 	ldr	x1, [x21, #5040]
    682c:	f949eea2 	ldr	x2, [x21, #5080]
    6830:	cb010001 	sub	x1, x0, x1
    6834:	eb02403f 	cmp	x1, x2, lsl #16
    6838:	54000382 	b.cs	68a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    683c:	d350fc22 	lsr	x2, x1, #16
    6840:	f949fea3 	ldr	x3, [x21, #5112]
    6844:	8b020842 	add	x2, x2, x2, lsl #2
    6848:	d37df042 	lsl	x2, x2, #3
    684c:	8b020064 	add	x4, x3, x2
    6850:	f9401094 	ldr	x20, [x4, #32]
    6854:	b40002b4 	cbz	x20, 68a8 <fwp_drop4+0x98>
    6858:	38626862 	ldrb	w2, [x3, x2]
    685c:	7100085f 	cmp	w2, #0x2
    6860:	540007a0 	b.eq	6954 <fwp_drop4+0x144>  // b.none
    6864:	7100045f 	cmp	w2, #0x1
    6868:	54000201 	b.ne	68a8 <fwp_drop4+0x98>  // b.any
    686c:	29430885 	ldp	w5, w2, [x4, #24]
    6870:	92403c21 	and	x1, x1, #0xffff
    6874:	9b057c21 	mul	x1, x1, x5
    6878:	d360fc21 	lsr	x1, x1, #32
    687c:	eb02003f 	cmp	x1, x2
    6880:	54000142 	b.cs	68a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6884:	8b010294 	add	x20, x20, x1
    6888:	39400281 	ldrb	w1, [x20]
    688c:	340000e1 	cbz	w1, 68a8 <fwp_drop4+0x98>
    6890:	7100043f 	cmp	w1, #0x1
    6894:	54000120 	b.eq	68b8 <fwp_drop4+0xa8>  // b.none
    6898:	7103fc3f 	cmp	w1, #0xff
    689c:	540007c0 	b.eq	6994 <fwp_drop4+0x184>  // b.none
    68a0:	51000421 	sub	w1, w1, #0x1
    68a4:	39000281 	strb	w1, [x20]
    68a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68ac:	f94013f5 	ldr	x21, [sp, #32]
    68b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68b4:	d65f03c0 	ret
    68b8:	f9400001 	ldr	x1, [x0]
    68bc:	b7f80581 	tbnz	x1, #63, 696c <fwp_drop4+0x15c>
    68c0:	91174273 	add	x19, x19, #0x5d0
    68c4:	f949da61 	ldr	x1, [x19, #5040]
    68c8:	f949ee62 	ldr	x2, [x19, #5080]
    68cc:	cb010001 	sub	x1, x0, x1
    68d0:	eb02403f 	cmp	x1, x2, lsl #16
    68d4:	54fffea2 	b.cs	68a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    68d8:	d350fc22 	lsr	x2, x1, #16
    68dc:	8b020842 	add	x2, x2, x2, lsl #2
    68e0:	d37df042 	lsl	x2, x2, #3
    68e4:	8b020065 	add	x5, x3, x2
    68e8:	f94010a4 	ldr	x4, [x5, #32]
    68ec:	b4fffde4 	cbz	x4, 68a8 <fwp_drop4+0x98>
    68f0:	38626862 	ldrb	w2, [x3, x2]
    68f4:	7100085f 	cmp	w2, #0x2
    68f8:	54000220 	b.eq	693c <fwp_drop4+0x12c>  // b.none
    68fc:	7100045f 	cmp	w2, #0x1
    6900:	54fffd41 	b.ne	68a8 <fwp_drop4+0x98>  // b.any
    6904:	294308a3 	ldp	w3, w2, [x5, #24]
    6908:	92403c21 	and	x1, x1, #0xffff
    690c:	9b037c21 	mul	x1, x1, x3
    6910:	d360fc21 	lsr	x1, x1, #32
    6914:	eb02003f 	cmp	x1, x2
    6918:	54fffc82 	b.cs	68a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    691c:	8b010084 	add	x4, x4, x1
    6920:	39400081 	ldrb	w1, [x4]
    6924:	7100043f 	cmp	w1, #0x1
    6928:	54fffc01 	b.ne	68a8 <fwp_drop4+0x98>  // b.any
    692c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6930:	f94013f5 	ldr	x21, [sp, #32]
    6934:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6938:	17fff84e 	b	4a70 <fwp_mem_free>
    693c:	72003c3f 	tst	w1, #0xffff
    6940:	54ffff00 	b.eq	6920 <fwp_drop4+0x110>  // b.none
    6944:	a94153f3 	ldp	x19, x20, [sp, #16]
    6948:	f94013f5 	ldr	x21, [sp, #32]
    694c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6950:	d65f03c0 	ret
    6954:	72003c3f 	tst	w1, #0xffff
    6958:	54fff980 	b.eq	6888 <fwp_drop4+0x78>  // b.none
    695c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6960:	f94013f5 	ldr	x21, [sp, #32]
    6964:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6968:	d65f03c0 	ret
    696c:	f9400414 	ldr	x20, [x0, #8]
    6970:	97fffb91 	bl	57b4 <fwp_rc_free_arr>
    6974:	91174260 	add	x0, x19, #0x5d0
    6978:	f949d801 	ldr	x1, [x0, #5040]
    697c:	f949ec00 	ldr	x0, [x0, #5080]
    6980:	cb010281 	sub	x1, x20, x1
    6984:	eb00403f 	cmp	x1, x0, lsl #16
    6988:	54fff902 	b.cs	68a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    698c:	aa1403e0 	mov	x0, x20
    6990:	17ffffab 	b	683c <fwp_drop4+0x2c>
    6994:	ca544680 	eor	x0, x20, x20, lsr #17
    6998:	91174273 	add	x19, x19, #0x5d0
    699c:	ca402400 	eor	x0, x0, x0, lsr #9
    69a0:	8b200e60 	add	x0, x19, w0, uxtb #3
    69a4:	f94a2400 	ldr	x0, [x0, #5192]
    69a8:	b5000080 	cbnz	x0, 69b8 <fwp_drop4+0x1a8>
    69ac:	14000010 	b	69ec <fwp_drop4+0x1dc>
    69b0:	f9400800 	ldr	x0, [x0, #16]
    69b4:	b40001c0 	cbz	x0, 69ec <fwp_drop4+0x1dc>
    69b8:	f9400001 	ldr	x1, [x0]
    69bc:	eb14003f 	cmp	x1, x20
    69c0:	54ffff81 	b.ne	69b0 <fwp_drop4+0x1a0>  // b.any
    69c4:	f9400401 	ldr	x1, [x0, #8]
    69c8:	d1000421 	sub	x1, x1, #0x1
    69cc:	f9000401 	str	x1, [x0, #8]
    69d0:	f103f83f 	cmp	x1, #0xfe
    69d4:	54fff6a1 	b.ne	68a8 <fwp_drop4+0x98>  // b.any
    69d8:	aa1403e0 	mov	x0, x20
    69dc:	97fff785 	bl	47f0 <fwp_rc_forget_slot>
    69e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69e4:	39000280 	strb	w0, [x20]
    69e8:	17ffffb0 	b	68a8 <fwp_drop4+0x98>
    69ec:	b0000020 	adrp	x0, b000 <__divti3+0x1a0>
    69f0:	91238000 	add	x0, x0, #0x8e0
    69f4:	97fff383 	bl	3800 <fwp_trap>
    69f8:	d503201f 	nop
    69fc:	d503201f 	nop

0000000000006a00 <fwp_caps161>:
    6a00:	34000041 	cbz	w1, 6a08 <fwp_caps161+0x8>
    6a04:	d65f03c0 	ret
    6a08:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6a0c:	91174063 	add	x3, x3, #0x5d0
    6a10:	f949d861 	ldr	x1, [x3, #5040]
    6a14:	f949ec62 	ldr	x2, [x3, #5080]
    6a18:	cb010001 	sub	x1, x0, x1
    6a1c:	eb02403f 	cmp	x1, x2, lsl #16
    6a20:	54ffff22 	b.cs	6a04 <fwp_caps161+0x4>  // b.hs, b.nlast
    6a24:	d350fc22 	lsr	x2, x1, #16
    6a28:	f949fc65 	ldr	x5, [x3, #5112]
    6a2c:	8b020842 	add	x2, x2, x2, lsl #2
    6a30:	d37df042 	lsl	x2, x2, #3
    6a34:	8b0200a4 	add	x4, x5, x2
    6a38:	f9401083 	ldr	x3, [x4, #32]
    6a3c:	b4fffe43 	cbz	x3, 6a04 <fwp_caps161+0x4>
    6a40:	386268a2 	ldrb	w2, [x5, x2]
    6a44:	7100085f 	cmp	w2, #0x2
    6a48:	540001c0 	b.eq	6a80 <fwp_caps161+0x80>  // b.none
    6a4c:	7100045f 	cmp	w2, #0x1
    6a50:	54fffda1 	b.ne	6a04 <fwp_caps161+0x4>  // b.any
    6a54:	29430885 	ldp	w5, w2, [x4, #24]
    6a58:	92403c21 	and	x1, x1, #0xffff
    6a5c:	9b057c21 	mul	x1, x1, x5
    6a60:	d360fc21 	lsr	x1, x1, #32
    6a64:	eb02003f 	cmp	x1, x2
    6a68:	54fffce2 	b.cs	6a04 <fwp_caps161+0x4>  // b.hs, b.nlast
    6a6c:	8b010063 	add	x3, x3, x1
    6a70:	39400061 	ldrb	w1, [x3]
    6a74:	7100043f 	cmp	w1, #0x1
    6a78:	54fffc61 	b.ne	6a04 <fwp_caps161+0x4>  // b.any
    6a7c:	17fff7fd 	b	4a70 <fwp_mem_free>
    6a80:	72003c3f 	tst	w1, #0xffff
    6a84:	54ffff60 	b.eq	6a70 <fwp_caps161+0x70>  // b.none
    6a88:	d65f03c0 	ret
    6a8c:	d503201f 	nop

0000000000006a90 <f12>:
    6a90:	d10483ff 	sub	sp, sp, #0x120
    6a94:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6a98:	f947f442 	ldr	x2, [x2, #4072]
    6a9c:	910103e8 	add	x8, sp, #0x40
    6aa0:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6aa4:	9102c3fd 	add	x29, sp, #0xb0
    6aa8:	9100e3e9 	add	x9, sp, #0x38
    6aac:	a90c53f3 	stp	x19, x20, [sp, #192]
    6ab0:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6ab4:	91174263 	add	x3, x19, #0x5d0
    6ab8:	d00000d4 	adrp	x20, 20000 <__data_start>
    6abc:	9101c284 	add	x4, x20, #0x70
    6ac0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6ac4:	f0fffff6 	adrp	x22, 5000 <fwp_heap_alloc+0x110>
    6ac8:	aa0003f5 	mov	x21, x0
    6acc:	f949d861 	ldr	x1, [x3, #5040]
    6ad0:	a90e63f7 	stp	x23, x24, [sp, #224]
    6ad4:	d00000d7 	adrp	x23, 20000 <__data_start>
    6ad8:	f949ec65 	ldr	x5, [x3, #5080]
    6adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6ae0:	910042f7 	add	x23, x23, #0x10
    6ae4:	a91073fb 	stp	x27, x28, [sp, #256]
    6ae8:	9100e2f7 	add	x23, x23, #0x38
    6aec:	cb0102e1 	sub	x1, x23, x1
    6af0:	f9418886 	ldr	x6, [x4, #784]
    6af4:	fd008be8 	str	d8, [sp, #272]
    6af8:	f9400047 	ldr	x7, [x2]
    6afc:	f90057e7 	str	x7, [sp, #168]
    6b00:	d2800007 	mov	x7, #0x0                   	// #0
    6b04:	913c42c2 	add	x2, x22, #0xf10
    6b08:	12800007 	mov	w7, #0xffffffff            	// #-1
    6b0c:	a900a3e9 	stp	x9, x8, [sp, #8]
    6b10:	b9003be7 	str	w7, [sp, #56]
    6b14:	a9040be6 	stp	x6, x2, [sp, #64]
    6b18:	f9002be9 	str	x9, [sp, #80]
    6b1c:	f9018888 	str	x8, [x4, #784]
    6b20:	eb05403f 	cmp	x1, x5, lsl #16
    6b24:	54000342 	b.cs	6b8c <f12+0xfc>  // b.hs, b.nlast
    6b28:	d350fc20 	lsr	x0, x1, #16
    6b2c:	f949fc64 	ldr	x4, [x3, #5112]
    6b30:	8b000800 	add	x0, x0, x0, lsl #2
    6b34:	d37df002 	lsl	x2, x0, #3
    6b38:	8b020083 	add	x3, x4, x2
    6b3c:	f9401060 	ldr	x0, [x3, #32]
    6b40:	b4000260 	cbz	x0, 6b8c <f12+0xfc>
    6b44:	38626882 	ldrb	w2, [x4, x2]
    6b48:	7100085f 	cmp	w2, #0x2
    6b4c:	540079e0 	b.eq	7a88 <f12+0xff8>  // b.none
    6b50:	7100045f 	cmp	w2, #0x1
    6b54:	540001c1 	b.ne	6b8c <f12+0xfc>  // b.any
    6b58:	29430864 	ldp	w4, w2, [x3, #24]
    6b5c:	92403c21 	and	x1, x1, #0xffff
    6b60:	9b047c21 	mul	x1, x1, x4
    6b64:	d360fc21 	lsr	x1, x1, #32
    6b68:	eb02003f 	cmp	x1, x2
    6b6c:	54000102 	b.cs	6b8c <f12+0xfc>  // b.hs, b.nlast
    6b70:	8b010000 	add	x0, x0, x1
    6b74:	39400001 	ldrb	w1, [x0]
    6b78:	340000a1 	cbz	w1, 6b8c <f12+0xfc>
    6b7c:	7103f43f 	cmp	w1, #0xfd
    6b80:	54008188 	b.hi	7bb0 <f12+0x1120>  // b.pmore
    6b84:	11000421 	add	w1, w1, #0x1
    6b88:	39000001 	strb	w1, [x0]
    6b8c:	aa1703e0 	mov	x0, x23
    6b90:	97fffc00 	bl	5b90 <fwp_closure_drop>
    6b94:	b4007855 	cbz	x21, 7a9c <f12+0x100c>
    6b98:	aa1503e0 	mov	x0, x21
    6b9c:	d2800017 	mov	x23, #0x0                   	// #0
    6ba0:	f9400800 	ldr	x0, [x0, #16]
    6ba4:	910006f7 	add	x23, x23, #0x1
    6ba8:	b5ffffc0 	cbnz	x0, 6ba0 <f12+0x110>
    6bac:	52800000 	mov	w0, #0x0                   	// #0
    6bb0:	97fff290 	bl	35f0 <descent_phase_step>
    6bb4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6bb8:	eb0002ff 	cmp	x23, x0
    6bbc:	540083a8 	b.hi	7c30 <f12+0x11a0>  // b.pmore
    6bc0:	9101c298 	add	x24, x20, #0x70
    6bc4:	b9434700 	ldr	w0, [x24, #836]
    6bc8:	340074c0 	cbz	w0, 7a60 <f12+0xfd0>
    6bcc:	9101c280 	add	x0, x20, #0x70
    6bd0:	f9404818 	ldr	x24, [x0, #144]
    6bd4:	f9407419 	ldr	x25, [x0, #232]
    6bd8:	eb18033f 	cmp	x25, x24
    6bdc:	5400732a 	b.ge	7a40 <f12+0xfb0>  // b.tcont
    6be0:	f9403a81 	ldr	x1, [x20, #112]
    6be4:	8b190720 	add	x0, x25, x25, lsl #1
    6be8:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6bec:	8b000b20 	add	x0, x25, x0, lsl #2
    6bf0:	8b000c20 	add	x0, x1, x0, lsl #3
    6bf4:	d503201f 	nop
    6bf8:	b9400401 	ldr	w1, [x0, #4]
    6bfc:	35000081 	cbnz	w1, 6c0c <f12+0x17c>
    6c00:	b9400001 	ldr	w1, [x0]
    6c04:	6b02003f 	cmp	w1, w2
    6c08:	540071c9 	b.ls	7a40 <f12+0xfb0>  // b.plast
    6c0c:	91000739 	add	x25, x25, #0x1
    6c10:	9101a000 	add	x0, x0, #0x68
    6c14:	eb18033f 	cmp	x25, x24
    6c18:	54ffff01 	b.ne	6bf8 <f12+0x168>  // b.any
    6c1c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6c20:	eb00031f 	cmp	x24, x0
    6c24:	540080cc 	b.gt	7c3c <f12+0x11ac>
    6c28:	9101c280 	add	x0, x20, #0x70
    6c2c:	f9403a9c 	ldr	x28, [x20, #112]
    6c30:	f9407000 	ldr	x0, [x0, #224]
    6c34:	eb18001f 	cmp	x0, x24
    6c38:	54000161 	b.ne	6c64 <f12+0x1d4>  // b.any
    6c3c:	b5007618 	cbnz	x24, 7afc <f12+0x106c>
    6c40:	d2800d01 	mov	x1, #0x68                  	// #104
    6c44:	d280003a 	mov	x26, #0x1                   	// #1
    6c48:	aa1c03e0 	mov	x0, x28
    6c4c:	97ffef09 	bl	2870 <realloc@plt>
    6c50:	aa0003fc 	mov	x28, x0
    6c54:	b4006de0 	cbz	x0, 7a10 <f12+0xf80>
    6c58:	9101c280 	add	x0, x20, #0x70
    6c5c:	f9003a9c 	str	x28, [x20, #112]
    6c60:	f900701a 	str	x26, [x0, #224]
    6c64:	8b180700 	add	x0, x24, x24, lsl #1
    6c68:	9101c281 	add	x1, x20, #0x70
    6c6c:	4f000400 	movi	v0.4s, #0x0
    6c70:	91000702 	add	x2, x24, #0x1
    6c74:	8b000b00 	add	x0, x24, x0, lsl #2
    6c78:	f9004822 	str	x2, [x1, #144]
    6c7c:	8b000f80 	add	x0, x28, x0, lsl #3
    6c80:	f900301f 	str	xzr, [x0, #96]
    6c84:	ad000000 	stp	q0, q0, [x0]
    6c88:	ad010000 	stp	q0, q0, [x0, #32]
    6c8c:	ad020000 	stp	q0, q0, [x0, #64]
    6c90:	8b190721 	add	x1, x25, x25, lsl #1
    6c94:	b0000020 	adrp	x0, b000 <__divti3+0x1a0>
    6c98:	9121c000 	add	x0, x0, #0x870
    6c9c:	8b010b38 	add	x24, x25, x1, lsl #2
    6ca0:	8b180f98 	add	x24, x28, x24, lsl #3
    6ca4:	f900331f 	str	xzr, [x24, #96]
    6ca8:	97ffef5a 	bl	2a10 <getenv@plt>
    6cac:	b4000080 	cbz	x0, 6cbc <f12+0x22c>
    6cb0:	39400001 	ldrb	w1, [x0]
    6cb4:	7100c03f 	cmp	w1, #0x30
    6cb8:	540031e0 	b.eq	72f4 <f12+0x864>  // b.none
    6cbc:	9101c280 	add	x0, x20, #0x70
    6cc0:	f9406801 	ldr	x1, [x0, #208]
    6cc4:	b5006fe1 	cbnz	x1, 7ac0 <f12+0x1030>
    6cc8:	9101c281 	add	x1, x20, #0x70
    6ccc:	2f000400 	mvni	v0.2s, #0x0
    6cd0:	b9400302 	ldr	w2, [x24]
    6cd4:	52800024 	mov	w4, #0x1                   	// #1
    6cd8:	91000723 	add	x3, x25, #0x1
    6cdc:	a900df17 	stp	x23, x23, [x24, #8]
    6ce0:	0b040042 	add	w2, w2, w4
    6ce4:	f9418820 	ldr	x0, [x1, #784]
    6ce8:	29001302 	stp	w2, w4, [x24]
    6cec:	f9002b1f 	str	xzr, [x24, #80]
    6cf0:	f9007423 	str	x3, [x1, #232]
    6cf4:	fd002f00 	str	d0, [x24, #88]
    6cf8:	b4007a80 	cbz	x0, 7c48 <f12+0x11b8>
    6cfc:	913c42d6 	add	x22, x22, #0xf10
    6d00:	14000003 	b	6d0c <f12+0x27c>
    6d04:	f9400000 	ldr	x0, [x0]
    6d08:	b4007a00 	cbz	x0, 7c48 <f12+0x11b8>
    6d0c:	f9400401 	ldr	x1, [x0, #8]
    6d10:	eb16003f 	cmp	x1, x22
    6d14:	54ffff81 	b.ne	6d04 <f12+0x274>  // b.any
    6d18:	f9400800 	ldr	x0, [x0, #16]
    6d1c:	2a1903e4 	mov	w4, w25
    6d20:	b9400001 	ldr	w1, [x0]
    6d24:	f9002b00 	str	x0, [x24, #80]
    6d28:	b9005f01 	str	w1, [x24, #92]
    6d2c:	37f80081 	tbnz	w1, #31, 6d3c <f12+0x2ac>
    6d30:	52800d05 	mov	w5, #0x68                  	// #104
    6d34:	9b257021 	smaddl	x1, w1, w5, x28
    6d38:	b9005839 	str	w25, [x1, #88]
    6d3c:	d3707c42 	ubfiz	x2, x2, #16, #32
    6d40:	b9000004 	str	w4, [x0]
    6d44:	aa030057 	orr	x23, x2, x3
    6d48:	52800020 	mov	w0, #0x1                   	// #1
    6d4c:	97fff229 	bl	35f0 <descent_phase_step>
    6d50:	aa1503e0 	mov	x0, x21
    6d54:	d2800002 	mov	x2, #0x0                   	// #0
    6d58:	b40062d5 	cbz	x21, 79b0 <f12+0xf20>
    6d5c:	d503201f 	nop
    6d60:	f9400800 	ldr	x0, [x0, #16]
    6d64:	91000442 	add	x2, x2, #0x1
    6d68:	b5ffffc0 	cbnz	x0, 6d60 <f12+0x2d0>
    6d6c:	aa1503e1 	mov	x1, x21
    6d70:	f9400821 	ldr	x1, [x1, #16]
    6d74:	91000400 	add	x0, x0, #0x1
    6d78:	b5ffffc1 	cbnz	x1, 6d70 <f12+0x2e0>
    6d7c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6d80:	eb01001f 	cmp	x0, x1
    6d84:	54007688 	b.hi	7c54 <f12+0x11c4>  // b.pmore
    6d88:	f100005f 	cmp	x2, #0x0
    6d8c:	5400612d 	b.le	79b0 <f12+0xf20>
    6d90:	eb00005f 	cmp	x2, x0
    6d94:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6d98:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    6d9c:	eb0102df 	cmp	x22, x1
    6da0:	540075a8 	b.hi	7c54 <f12+0x11c4>  // b.pmore
    6da4:	d37ffad9 	lsl	x25, x22, #1
    6da8:	52800041 	mov	w1, #0x2                   	// #2
    6dac:	91000720 	add	x0, x25, #0x1
    6db0:	d37df000 	lsl	x0, x0, #3
    6db4:	97fff84f 	bl	4ef0 <fwp_heap_alloc>
    6db8:	aa0003f8 	mov	x24, x0
    6dbc:	91174261 	add	x1, x19, #0x5d0
    6dc0:	aa0103e0 	mov	x0, x1
    6dc4:	f9000319 	str	x25, [x24]
    6dc8:	f949d821 	ldr	x1, [x1, #5040]
    6dcc:	f949ec00 	ldr	x0, [x0, #5080]
    6dd0:	cb010301 	sub	x1, x24, x1
    6dd4:	eb00403f 	cmp	x1, x0, lsl #16
    6dd8:	540063c2 	b.cs	7a50 <f12+0xfc0>  // b.hs, b.nlast
    6ddc:	91174262 	add	x2, x19, #0x5d0
    6de0:	d350fc20 	lsr	x0, x1, #16
    6de4:	8b000800 	add	x0, x0, x0, lsl #2
    6de8:	f949fc43 	ldr	x3, [x2, #5112]
    6dec:	d37df002 	lsl	x2, x0, #3
    6df0:	8b020060 	add	x0, x3, x2
    6df4:	f9401019 	ldr	x25, [x0, #32]
    6df8:	b4000259 	cbz	x25, 6e40 <f12+0x3b0>
    6dfc:	38626862 	ldrb	w2, [x3, x2]
    6e00:	7100085f 	cmp	w2, #0x2
    6e04:	540063c0 	b.eq	7a7c <f12+0xfec>  // b.none
    6e08:	7100045f 	cmp	w2, #0x1
    6e0c:	540001a1 	b.ne	6e40 <f12+0x3b0>  // b.any
    6e10:	29430002 	ldp	w2, w0, [x0, #24]
    6e14:	92403c21 	and	x1, x1, #0xffff
    6e18:	9b027c21 	mul	x1, x1, x2
    6e1c:	d360fc21 	lsr	x1, x1, #32
    6e20:	eb00003f 	cmp	x1, x0
    6e24:	540000e2 	b.cs	6e40 <f12+0x3b0>  // b.hs, b.nlast
    6e28:	8b010339 	add	x25, x25, x1
    6e2c:	39400320 	ldrb	w0, [x25]
    6e30:	7103fc1f 	cmp	w0, #0xff
    6e34:	54006ac0 	b.eq	7b8c <f12+0x10fc>  // b.none
    6e38:	52800020 	mov	w0, #0x1                   	// #1
    6e3c:	39000320 	strb	w0, [x25]
    6e40:	b4000236 	cbz	x22, 6e84 <f12+0x3f4>
    6e44:	d3607ee4 	lsl	x4, x23, #32
    6e48:	aa1503e0 	mov	x0, x21
    6e4c:	f94006a5 	ldr	x5, [x21, #8]
    6e50:	aa0403e3 	mov	x3, x4
    6e54:	91002302 	add	x2, x24, #0x8
    6e58:	d2800001 	mov	x1, #0x0                   	// #0
    6e5c:	14000005 	b	6e70 <f12+0x3e0>
    6e60:	f9400405 	ldr	x5, [x0, #8]
    6e64:	ab040023 	adds	x3, x1, x4
    6e68:	91004042 	add	x2, x2, #0x10
    6e6c:	540070a6 	b.vs	7c80 <f12+0x11f0>
    6e70:	a9000c45 	stp	x5, x3, [x2]
    6e74:	91000421 	add	x1, x1, #0x1
    6e78:	f9400800 	ldr	x0, [x0, #16]
    6e7c:	eb0102df 	cmp	x22, x1
    6e80:	54ffff08 	b.hi	6e60 <f12+0x3d0>  // b.pmore
    6e84:	f9400300 	ldr	x0, [x24]
    6e88:	f100041f 	cmp	x0, #0x1
    6e8c:	54005e49 	b.ls	7a54 <f12+0xfc4>  // b.plast
    6e90:	d341fc00 	lsr	x0, x0, #1
    6e94:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6e98:	d100041c 	sub	x28, x0, #0x1
    6e9c:	eb01039f 	cmp	x28, x1
    6ea0:	54006da8 	b.hi	7c54 <f12+0x11c4>  // b.pmore
    6ea4:	b4005d9c 	cbz	x28, 7a54 <f12+0xfc4>
    6ea8:	d1002301 	sub	x1, x24, #0x8
    6eac:	91002316 	add	x22, x24, #0x8
    6eb0:	8b001039 	add	x25, x1, x0, lsl #4
    6eb4:	d503201f 	nop
    6eb8:	f94006c0 	ldr	x0, [x22, #8]
    6ebc:	f9400ec1 	ldr	x1, [x22, #24]
    6ec0:	fd4002c0 	ldr	d0, [x22]
    6ec4:	fd400ac1 	ldr	d1, [x22, #16]
    6ec8:	97fff98a 	bl	54f0 <w107>
    6ecc:	a90006c0 	stp	x0, x1, [x22]
    6ed0:	910042d6 	add	x22, x22, #0x10
    6ed4:	eb1902df 	cmp	x22, x25
    6ed8:	54ffff01 	b.ne	6eb8 <f12+0x428>  // b.any
    6edc:	aa1803f9 	mov	x25, x24
    6ee0:	d37ffb96 	lsl	x22, x28, #1
    6ee4:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6ee8:	d280001c 	mov	x28, #0x0                   	// #0
    6eec:	f8010736 	str	x22, [x25], #16
    6ef0:	f87c7b22 	ldr	x2, [x25, x28, lsl #3]
    6ef4:	aa0403e0 	mov	x0, x4
    6ef8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6efc:	91000b9c 	add	x28, x28, #0x2
    6f00:	aa0303e1 	mov	x1, x3
    6f04:	97fff8c8 	bl	5224 <fwp_p_ad_push>
    6f08:	aa0003e4 	mov	x4, x0
    6f0c:	eb16039f 	cmp	x28, x22
    6f10:	54ffff03 	b.cc	6ef0 <f12+0x460>  // b.lo, b.ul, b.last
    6f14:	aa1803e0 	mov	x0, x24
    6f18:	f9000fe4 	str	x4, [sp, #24]
    6f1c:	97fffe3d 	bl	6810 <fwp_drop4>
    6f20:	93407efb 	sxtw	x27, w23
    6f24:	52800040 	mov	w0, #0x2                   	// #2
    6f28:	97fff1b2 	bl	35f0 <descent_phase_step>
    6f2c:	aa1b03e0 	mov	x0, x27
    6f30:	97fff300 	bl	3b30 <fwp_tape_of>
    6f34:	f9403002 	ldr	x2, [x0, #96]
    6f38:	aa0003e8 	mov	x8, x0
    6f3c:	f9400fe4 	ldr	x4, [sp, #24]
    6f40:	b5006722 	cbnz	x2, 7c24 <f12+0x1194>
    6f44:	f9000fe4 	str	x4, [sp, #24]
    6f48:	97fff012 	bl	2f90 <fwp_tape_unlink_scope>
    6f4c:	b9400103 	ldr	w3, [x8]
    6f50:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6f54:	b900051f 	str	wzr, [x8, #4]
    6f58:	a9409d1c 	ldp	x28, x7, [x8, #8]
    6f5c:	6b00007f 	cmp	w3, w0
    6f60:	a941d90a 	ldp	x10, x22, [x8, #24]
    6f64:	f9400fe4 	ldr	x4, [sp, #24]
    6f68:	a942e117 	ldp	x23, x24, [x8, #40]
    6f6c:	a943e919 	ldp	x25, x26, [x8, #56]
    6f70:	f9402502 	ldr	x2, [x8, #72]
    6f74:	54000108 	b.hi	6f94 <f12+0x504>  // b.pmore
    6f78:	9101c283 	add	x3, x20, #0x70
    6f7c:	92403f60 	and	x0, x27, #0xffff
    6f80:	d1000400 	sub	x0, x0, #0x1
    6f84:	f9407469 	ldr	x9, [x3, #232]
    6f88:	eb09001f 	cmp	x0, x9
    6f8c:	5400004a 	b.ge	6f94 <f12+0x504>  // b.tcont
    6f90:	f9007460 	str	x0, [x3, #232]
    6f94:	4f000400 	movi	v0.4s, #0x0
    6f98:	9101c289 	add	x9, x20, #0x70
    6f9c:	f9000d1f 	str	xzr, [x8, #24]
    6fa0:	9101c3e1 	add	x1, sp, #0x70
    6fa4:	910163e0 	add	x0, sp, #0x58
    6fa8:	d0ffffe3 	adrp	x3, 4000 <fwp_heap_report+0x60>
    6fac:	f941892b 	ldr	x11, [x9, #784]
    6fb0:	3c808100 	stur	q0, [x8, #8]
    6fb4:	910e0063 	add	x3, x3, #0x380
    6fb8:	ad010100 	stp	q0, q0, [x8, #32]
    6fbc:	f9000fe1 	str	x1, [sp, #24]
    6fc0:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    6fc4:	a9058feb 	stp	x11, x3, [sp, #88]
    6fc8:	a906dbe1 	stp	x1, x22, [sp, #104]
    6fcc:	a907e3f7 	stp	x23, x24, [sp, #120]
    6fd0:	a908ebf9 	stp	x25, x26, [sp, #136]
    6fd4:	a9098bea 	stp	x10, x2, [sp, #152]
    6fd8:	f9018920 	str	x0, [x9, #784]
    6fdc:	b7f85684 	tbnz	x4, #63, 7aac <f12+0x101c>
    6fe0:	eb84837f 	cmp	x27, x4, asr #32
    6fe4:	54006121 	b.ne	7c08 <f12+0x1178>  // b.any
    6fe8:	92407c83 	and	x3, x4, #0xffffffff
    6fec:	eb2440ff 	cmp	x7, w4, uxtw
    6ff0:	5400612d 	b.le	7c14 <f12+0x1184>
    6ff4:	eb1c007f 	cmp	x3, x28
    6ff8:	9a83b79b 	csinc	x27, x28, x3, lt	// lt = tstop
    6ffc:	eb1b005f 	cmp	x2, x27
    7000:	54004f8a 	b.ge	79f0 <f12+0xf60>  // b.tcont
    7004:	f100005f 	cmp	x2, #0x0
    7008:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    700c:	9a9b1042 	csel	x2, x2, x27, ne	// ne = any
    7010:	14000004 	b	7020 <f12+0x590>
    7014:	eb01005f 	cmp	x2, x1
    7018:	d37ff842 	lsl	x2, x2, #1
    701c:	9a9bd042 	csel	x2, x2, x27, le
    7020:	eb1b005f 	cmp	x2, x27
    7024:	54ffff8b 	b.lt	7014 <f12+0x584>  // b.tstop
    7028:	f90017e4 	str	x4, [sp, #40]
    702c:	b40058da 	cbz	x26, 7b44 <f12+0x10b4>
    7030:	aa1a03e0 	mov	x0, x26
    7034:	d37df041 	lsl	x1, x2, #3
    7038:	f90013e2 	str	x2, [sp, #32]
    703c:	97ffee0d 	bl	2870 <realloc@plt>
    7040:	a94213e2 	ldp	x2, x4, [sp, #32]
    7044:	aa0003fa 	mov	x26, x0
    7048:	b4004d5a 	cbz	x26, 79f0 <f12+0xf60>
    704c:	f9004bfa 	str	x26, [sp, #144]
    7050:	f90053e2 	str	x2, [sp, #160]
    7054:	b500157b 	cbnz	x27, 7300 <f12+0x870>
    7058:	b7f800c4 	tbnz	x4, #63, 7070 <f12+0x5e0>
    705c:	92407c84 	and	x4, x4, #0xffffffff
    7060:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7064:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7068:	1e612800 	fadd	d0, d0, d1
    706c:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7070:	9101c281 	add	x1, x20, #0x70
    7074:	cb1c0364 	sub	x4, x27, x28
    7078:	52800060 	mov	w0, #0x3                   	// #3
    707c:	a9428827 	ldp	x7, x2, [x1, #40]
    7080:	8b070084 	add	x4, x4, x7
    7084:	8b1c0042 	add	x2, x2, x28
    7088:	a9028824 	stp	x4, x2, [x1, #40]
    708c:	97fff159 	bl	35f0 <descent_phase_step>
    7090:	d1000763 	sub	x3, x27, #0x1
    7094:	d1000784 	sub	x4, x28, #0x1
    7098:	eb03039f 	cmp	x28, x3
    709c:	540003ac 	b.gt	7110 <f12+0x680>
    70a0:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    70a4:	1e602008 	fcmp	d0, #0.0
    70a8:	540002e0 	b.eq	7104 <f12+0x674>  // b.none
    70ac:	cb1c0be0 	neg	x0, x28, lsl #2
    70b0:	cb1c03e2 	neg	x2, x28
    70b4:	8b0002c1 	add	x1, x22, x0
    70b8:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    70bc:	37f80101 	tbnz	w1, #31, 70dc <f12+0x64c>
    70c0:	8b020f07 	add	x7, x24, x2, lsl #3
    70c4:	93407c21 	sxtw	x1, w1
    70c8:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    70cc:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    70d0:	1e620802 	fmul	d2, d0, d2
    70d4:	1e622821 	fadd	d1, d1, d2
    70d8:	fc217b41 	str	d1, [x26, x1, lsl #3]
    70dc:	8b0002e0 	add	x0, x23, x0
    70e0:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    70e4:	37f80100 	tbnz	w0, #31, 7104 <f12+0x674>
    70e8:	8b020f22 	add	x2, x25, x2, lsl #3
    70ec:	93407c00 	sxtw	x0, w0
    70f0:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    70f4:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    70f8:	1e620800 	fmul	d0, d0, d2
    70fc:	1e602820 	fadd	d0, d1, d0
    7100:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7104:	d1000463 	sub	x3, x3, #0x1
    7108:	eb04007f 	cmp	x3, x4
    710c:	54fffca1 	b.ne	70a0 <f12+0x610>  // b.any
    7110:	52800080 	mov	w0, #0x4                   	// #4
    7114:	97fff137 	bl	35f0 <descent_phase_step>
    7118:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    711c:	eb00039f 	cmp	x28, x0
    7120:	54005a28 	b.hi	7c64 <f12+0x11d4>  // b.pmore
    7124:	91000780 	add	x0, x28, #0x1
    7128:	52800041 	mov	w1, #0x2                   	// #2
    712c:	d37df000 	lsl	x0, x0, #3
    7130:	97fff770 	bl	4ef0 <fwp_heap_alloc>
    7134:	aa0003e2 	mov	x2, x0
    7138:	aa0003f6 	mov	x22, x0
    713c:	d2800001 	mov	x1, #0x0                   	// #0
    7140:	f800845c 	str	x28, [x2], #8
    7144:	b40000dc 	cbz	x28, 715c <f12+0x6cc>
    7148:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    714c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7150:	91000421 	add	x1, x1, #0x1
    7154:	eb01039f 	cmp	x28, x1
    7158:	54ffff81 	b.ne	7148 <f12+0x6b8>  // b.any
    715c:	528000a0 	mov	w0, #0x5                   	// #5
    7160:	97fff124 	bl	35f0 <descent_phase_step>
    7164:	f9400fe0 	ldr	x0, [sp, #24]
    7168:	9101c281 	add	x1, x20, #0x70
    716c:	f9402ff8 	ldr	x24, [sp, #88]
    7170:	f9018838 	str	x24, [x1, #784]
    7174:	97fff483 	bl	4380 <fwp_tape_buffers_release>
    7178:	528000c0 	mov	w0, #0x6                   	// #6
    717c:	97fff11d 	bl	35f0 <descent_phase_step>
    7180:	91174262 	add	x2, x19, #0x5d0
    7184:	f949d841 	ldr	x1, [x2, #5040]
    7188:	f949ec40 	ldr	x0, [x2, #5080]
    718c:	cb0102c1 	sub	x1, x22, x1
    7190:	eb00403f 	cmp	x1, x0, lsl #16
    7194:	54000322 	b.cs	71f8 <f12+0x768>  // b.hs, b.nlast
    7198:	d350fc20 	lsr	x0, x1, #16
    719c:	f949fc43 	ldr	x3, [x2, #5112]
    71a0:	8b000800 	add	x0, x0, x0, lsl #2
    71a4:	d37df002 	lsl	x2, x0, #3
    71a8:	8b020060 	add	x0, x3, x2
    71ac:	f9401017 	ldr	x23, [x0, #32]
    71b0:	b4000257 	cbz	x23, 71f8 <f12+0x768>
    71b4:	38626862 	ldrb	w2, [x3, x2]
    71b8:	7100085f 	cmp	w2, #0x2
    71bc:	540047c0 	b.eq	7ab4 <f12+0x1024>  // b.none
    71c0:	7100045f 	cmp	w2, #0x1
    71c4:	540001a1 	b.ne	71f8 <f12+0x768>  // b.any
    71c8:	29430002 	ldp	w2, w0, [x0, #24]
    71cc:	92403c21 	and	x1, x1, #0xffff
    71d0:	9b027c21 	mul	x1, x1, x2
    71d4:	d360fc21 	lsr	x1, x1, #32
    71d8:	eb00003f 	cmp	x1, x0
    71dc:	540000e2 	b.cs	71f8 <f12+0x768>  // b.hs, b.nlast
    71e0:	8b0102f7 	add	x23, x23, x1
    71e4:	394002e0 	ldrb	w0, [x23]
    71e8:	7103fc1f 	cmp	w0, #0xff
    71ec:	54004d60 	b.eq	7b98 <f12+0x1108>  // b.none
    71f0:	52800020 	mov	w0, #0x1                   	// #1
    71f4:	390002e0 	strb	w0, [x23]
    71f8:	f9400be0 	ldr	x0, [sp, #16]
    71fc:	eb00031f 	cmp	x24, x0
    7200:	540053e1 	b.ne	7c7c <f12+0x11ec>  // b.any
    7204:	f94007e0 	ldr	x0, [sp, #8]
    7208:	9101c294 	add	x20, x20, #0x70
    720c:	f94023e1 	ldr	x1, [sp, #64]
    7210:	f9018a81 	str	x1, [x20, #784]
    7214:	97fffb3f 	bl	5f10 <fwp_tape_scope_release>
    7218:	f94002c0 	ldr	x0, [x22]
    721c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7220:	b7f83740 	tbnz	x0, #63, 7908 <f12+0xe78>
    7224:	91174262 	add	x2, x19, #0x5d0
    7228:	f949d840 	ldr	x0, [x2, #5040]
    722c:	f949ec41 	ldr	x1, [x2, #5080]
    7230:	cb0002c0 	sub	x0, x22, x0
    7234:	eb01401f 	cmp	x0, x1, lsl #16
    7238:	54003682 	b.cs	7908 <f12+0xe78>  // b.hs, b.nlast
    723c:	d350fc01 	lsr	x1, x0, #16
    7240:	f949fc44 	ldr	x4, [x2, #5112]
    7244:	8b010821 	add	x1, x1, x1, lsl #2
    7248:	d37df021 	lsl	x1, x1, #3
    724c:	8b010083 	add	x3, x4, x1
    7250:	f9401062 	ldr	x2, [x3, #32]
    7254:	b40035a2 	cbz	x2, 7908 <f12+0xe78>
    7258:	38616881 	ldrb	w1, [x4, x1]
    725c:	7100083f 	cmp	w1, #0x2
    7260:	540034e0 	b.eq	78fc <f12+0xe6c>  // b.none
    7264:	7100043f 	cmp	w1, #0x1
    7268:	54003501 	b.ne	7908 <f12+0xe78>  // b.any
    726c:	29430464 	ldp	w4, w1, [x3, #24]
    7270:	92403c00 	and	x0, x0, #0xffff
    7274:	9b047c00 	mul	x0, x0, x4
    7278:	d360fc00 	lsr	x0, x0, #32
    727c:	eb01001f 	cmp	x0, x1
    7280:	54003442 	b.cs	7908 <f12+0xe78>  // b.hs, b.nlast
    7284:	8b000042 	add	x2, x2, x0
    7288:	39400040 	ldrb	w0, [x2]
    728c:	7100041f 	cmp	w0, #0x1
    7290:	540033c1 	b.ne	7908 <f12+0xe78>  // b.any
    7294:	aa1603fa 	mov	x26, x22
    7298:	d2800000 	mov	x0, #0x0                   	// #0
    729c:	f9000ff6 	str	x22, [sp, #24]
    72a0:	f9400fe1 	ldr	x1, [sp, #24]
    72a4:	91002023 	add	x3, x1, #0x8
    72a8:	d2800001 	mov	x1, #0x0                   	// #0
    72ac:	b4000397 	cbz	x23, 731c <f12+0x88c>
    72b0:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0xa80>
    72b4:	910022c5 	add	x5, x22, #0x8
    72b8:	fd41bc41 	ldr	d1, [x2, #888]
    72bc:	14000009 	b	72e0 <f12+0x850>
    72c0:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    72c4:	f9400342 	ldr	x2, [x26]
    72c8:	1e600820 	fmul	d0, d1, d0
    72cc:	b7f84d22 	tbnz	x2, #63, 7c70 <f12+0x11e0>
    72d0:	91000421 	add	x1, x1, #0x1
    72d4:	fc008460 	str	d0, [x3], #8
    72d8:	eb0102ff 	cmp	x23, x1
    72dc:	54000200 	b.eq	731c <f12+0x88c>  // b.none
    72e0:	f94002c4 	ldr	x4, [x22]
    72e4:	aa0503e2 	mov	x2, x5
    72e8:	b6fffec4 	tbz	x4, #63, 72c0 <f12+0x830>
    72ec:	f9400ac2 	ldr	x2, [x22, #16]
    72f0:	17fffff4 	b	72c0 <f12+0x830>
    72f4:	39400400 	ldrb	w0, [x0, #1]
    72f8:	34ffce80 	cbz	w0, 6cc8 <f12+0x238>
    72fc:	17fffe70 	b	6cbc <f12+0x22c>
    7300:	d37df362 	lsl	x2, x27, #3
    7304:	aa1a03e0 	mov	x0, x26
    7308:	52800001 	mov	w1, #0x0                   	// #0
    730c:	f90013e4 	str	x4, [sp, #32]
    7310:	97ffed50 	bl	2850 <memset@plt>
    7314:	f94013e4 	ldr	x4, [sp, #32]
    7318:	17ffff50 	b	7058 <f12+0x5c8>
    731c:	97fffd3d 	bl	6810 <fwp_drop4>
    7320:	aa1503e1 	mov	x1, x21
    7324:	d2800002 	mov	x2, #0x0                   	// #0
    7328:	b40041d5 	cbz	x21, 7b60 <f12+0x10d0>
    732c:	d503201f 	nop
    7330:	f9400821 	ldr	x1, [x1, #16]
    7334:	91000442 	add	x2, x2, #0x1
    7338:	b5ffffc1 	cbnz	x1, 7330 <f12+0x8a0>
    733c:	f9400343 	ldr	x3, [x26]
    7340:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7344:	b7f82a63 	tbnz	x3, #63, 7890 <f12+0xe00>
    7348:	91174261 	add	x1, x19, #0x5d0
    734c:	f9400fe4 	ldr	x4, [sp, #24]
    7350:	f949d820 	ldr	x0, [x1, #5040]
    7354:	f949ec21 	ldr	x1, [x1, #5080]
    7358:	cb000080 	sub	x0, x4, x0
    735c:	eb01401f 	cmp	x0, x1, lsl #16
    7360:	54002982 	b.cs	7890 <f12+0xe00>  // b.hs, b.nlast
    7364:	91174264 	add	x4, x19, #0x5d0
    7368:	d350fc01 	lsr	x1, x0, #16
    736c:	8b010821 	add	x1, x1, x1, lsl #2
    7370:	f949fc86 	ldr	x6, [x4, #5112]
    7374:	d37df021 	lsl	x1, x1, #3
    7378:	8b0100c5 	add	x5, x6, x1
    737c:	f94010a4 	ldr	x4, [x5, #32]
    7380:	b4002864 	cbz	x4, 788c <f12+0xdfc>
    7384:	386168c1 	ldrb	w1, [x6, x1]
    7388:	7100083f 	cmp	w1, #0x2
    738c:	540027c0 	b.eq	7884 <f12+0xdf4>  // b.none
    7390:	7100043f 	cmp	w1, #0x1
    7394:	540027c1 	b.ne	788c <f12+0xdfc>  // b.any
    7398:	294304a6 	ldp	w6, w1, [x5, #24]
    739c:	92403c00 	and	x0, x0, #0xffff
    73a0:	9b067c00 	mul	x0, x0, x6
    73a4:	d360fc00 	lsr	x0, x0, #32
    73a8:	eb01001f 	cmp	x0, x1
    73ac:	54002702 	b.cs	788c <f12+0xdfc>  // b.hs, b.nlast
    73b0:	8b000084 	add	x4, x4, x0
    73b4:	39400096 	ldrb	w22, [x4]
    73b8:	710006df 	cmp	w22, #0x1
    73bc:	54002681 	b.ne	788c <f12+0xdfc>  // b.any
    73c0:	b90023f6 	str	w22, [sp, #32]
    73c4:	eb17005f 	cmp	x2, x23
    73c8:	9a979057 	csel	x23, x2, x23, ls	// ls = plast
    73cc:	91002359 	add	x25, x26, #0x8
    73d0:	b4003f97 	cbz	x23, 7bc0 <f12+0x1130>
    73d4:	f9400fe0 	ldr	x0, [sp, #24]
    73d8:	d37df2e5 	lsl	x5, x23, #3
    73dc:	aa1503e2 	mov	x2, x21
    73e0:	d2800001 	mov	x1, #0x0                   	// #0
    73e4:	91002000 	add	x0, x0, #0x8
    73e8:	1400000a 	b	7410 <f12+0x980>
    73ec:	fc616881 	ldr	d1, [x4, x1]
    73f0:	fd400440 	ldr	d0, [x2, #8]
    73f4:	1e613800 	fsub	d0, d0, d1
    73f8:	fc216b20 	str	d0, [x25, x1]
    73fc:	91002021 	add	x1, x1, #0x8
    7400:	f9400842 	ldr	x2, [x2, #16]
    7404:	eb05003f 	cmp	x1, x5
    7408:	540001c0 	b.eq	7440 <f12+0x9b0>  // b.none
    740c:	f9400343 	ldr	x3, [x26]
    7410:	aa0003e4 	mov	x4, x0
    7414:	b6fffec3 	tbz	x3, #63, 73ec <f12+0x95c>
    7418:	f9400fe3 	ldr	x3, [sp, #24]
    741c:	fd400440 	ldr	d0, [x2, #8]
    7420:	f9400864 	ldr	x4, [x3, #16]
    7424:	fc616881 	ldr	d1, [x4, x1]
    7428:	1e613800 	fsub	d0, d0, d1
    742c:	fc216b20 	str	d0, [x25, x1]
    7430:	91002021 	add	x1, x1, #0x8
    7434:	f9400842 	ldr	x2, [x2, #16]
    7438:	eb05003f 	cmp	x1, x5
    743c:	54fffe81 	b.ne	740c <f12+0x97c>  // b.any
    7440:	b4003bd5 	cbz	x21, 7bb8 <f12+0x1128>
    7444:	91174260 	add	x0, x19, #0x5d0
    7448:	aa1503e2 	mov	x2, x21
    744c:	d280001b 	mov	x27, #0x0                   	// #0
    7450:	f949ec06 	ldr	x6, [x0, #5080]
    7454:	f949d807 	ldr	x7, [x0, #5040]
    7458:	f949fc05 	ldr	x5, [x0, #5112]
    745c:	d370bcc6 	lsl	x6, x6, #16
    7460:	14000006 	b	7478 <f12+0x9e8>
    7464:	f9400842 	ldr	x2, [x2, #16]
    7468:	9100077b 	add	x27, x27, #0x1
    746c:	f100005f 	cmp	x2, #0x0
    7470:	fa571362 	ccmp	x27, x23, #0x2, ne	// ne = any
    7474:	54000322 	b.cs	74d8 <f12+0xa48>  // b.hs, b.nlast
    7478:	cb070040 	sub	x0, x2, x7
    747c:	eb06001f 	cmp	x0, x6
    7480:	540002c2 	b.cs	74d8 <f12+0xa48>  // b.hs, b.nlast
    7484:	d350fc01 	lsr	x1, x0, #16
    7488:	8b010821 	add	x1, x1, x1, lsl #2
    748c:	d37df021 	lsl	x1, x1, #3
    7490:	8b0100a4 	add	x4, x5, x1
    7494:	f9401083 	ldr	x3, [x4, #32]
    7498:	b4000203 	cbz	x3, 74d8 <f12+0xa48>
    749c:	386168a1 	ldrb	w1, [x5, x1]
    74a0:	7100083f 	cmp	w1, #0x2
    74a4:	54000e00 	b.eq	7664 <f12+0xbd4>  // b.none
    74a8:	7100043f 	cmp	w1, #0x1
    74ac:	54000161 	b.ne	74d8 <f12+0xa48>  // b.any
    74b0:	29430488 	ldp	w8, w1, [x4, #24]
    74b4:	92403c00 	and	x0, x0, #0xffff
    74b8:	9b087c00 	mul	x0, x0, x8
    74bc:	d360fc00 	lsr	x0, x0, #32
    74c0:	eb01001f 	cmp	x0, x1
    74c4:	540000a2 	b.cs	74d8 <f12+0xa48>  // b.hs, b.nlast
    74c8:	8b000063 	add	x3, x3, x0
    74cc:	39400060 	ldrb	w0, [x3]
    74d0:	7100041f 	cmp	w0, #0x1
    74d4:	54fffc80 	b.eq	7464 <f12+0x9d4>  // b.none
    74d8:	d2800018 	mov	x24, #0x0                   	// #0
    74dc:	eb17037f 	cmp	x27, x23
    74e0:	54000cc2 	b.cs	7678 <f12+0xbe8>  // b.hs, b.nlast
    74e4:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    74e8:	d1002336 	sub	x22, x25, #0x8
    74ec:	9117427a 	add	x26, x19, #0x5d0
    74f0:	d2800018 	mov	x24, #0x0                   	// #0
    74f4:	fd41a808 	ldr	d8, [x0, #848]
    74f8:	14000042 	b	7600 <f12+0xb70>
    74fc:	f9400381 	ldr	x1, [x28]
    7500:	aa2103e1 	mvn	x1, x1
    7504:	f8207b41 	str	x1, [x26, x0, lsl #3]
    7508:	f100609f 	cmp	x4, #0x18
    750c:	54000169 	b.ls	7538 <f12+0xaa8>  // b.plast
    7510:	d1006482 	sub	x2, x4, #0x19
    7514:	91006380 	add	x0, x28, #0x18
    7518:	927df042 	and	x2, x2, #0xfffffffffffffff8
    751c:	52800001 	mov	w1, #0x0                   	// #0
    7520:	91002042 	add	x2, x2, #0x8
    7524:	f90007e4 	str	x4, [sp, #8]
    7528:	b90013e5 	str	w5, [sp, #16]
    752c:	97ffecc9 	bl	2850 <memset@plt>
    7530:	f94007e4 	ldr	x4, [sp, #8]
    7534:	b94013e5 	ldr	w5, [sp, #16]
    7538:	91174262 	add	x2, x19, #0x5d0
    753c:	f94a1041 	ldr	x1, [x2, #5152]
    7540:	ab040021 	adds	x1, x1, x4
    7544:	540036e2 	b.cs	7c20 <f12+0x1190>  // b.hs, b.nlast
    7548:	f94a1440 	ldr	x0, [x2, #5160]
    754c:	f90a1041 	str	x1, [x2, #5152]
    7550:	eb00003f 	cmp	x1, x0
    7554:	54000049 	b.ls	755c <f12+0xacc>  // b.plast
    7558:	f90a1441 	str	x1, [x2, #5160]
    755c:	91174260 	add	x0, x19, #0x5d0
    7560:	1e6300a1 	ucvtf	d1, w5
    7564:	fd4a1c00 	ldr	d0, [x0, #5176]
    7568:	1e612800 	fadd	d0, d0, d1
    756c:	fd0a1c00 	str	d0, [x0, #5176]
    7570:	a900e394 	stp	x20, x24, [x28, #8]
    7574:	aa1c03f8 	mov	x24, x28
    7578:	fd000388 	str	d8, [x28]
    757c:	f949db41 	ldr	x1, [x26, #5040]
    7580:	f949ef40 	ldr	x0, [x26, #5080]
    7584:	cb010381 	sub	x1, x28, x1
    7588:	eb00403f 	cmp	x1, x0, lsl #16
    758c:	54000322 	b.cs	75f0 <f12+0xb60>  // b.hs, b.nlast
    7590:	d350fc22 	lsr	x2, x1, #16
    7594:	f949ff44 	ldr	x4, [x26, #5112]
    7598:	8b020842 	add	x2, x2, x2, lsl #2
    759c:	d37df042 	lsl	x2, x2, #3
    75a0:	8b020080 	add	x0, x4, x2
    75a4:	f940101c 	ldr	x28, [x0, #32]
    75a8:	b400025c 	cbz	x28, 75f0 <f12+0xb60>
    75ac:	38626882 	ldrb	w2, [x4, x2]
    75b0:	7100085f 	cmp	w2, #0x2
    75b4:	54000b00 	b.eq	7714 <f12+0xc84>  // b.none
    75b8:	7100045f 	cmp	w2, #0x1
    75bc:	540001a1 	b.ne	75f0 <f12+0xb60>  // b.any
    75c0:	29430002 	ldp	w2, w0, [x0, #24]
    75c4:	92403c21 	and	x1, x1, #0xffff
    75c8:	9b027c21 	mul	x1, x1, x2
    75cc:	d360fc21 	lsr	x1, x1, #32
    75d0:	eb00003f 	cmp	x1, x0
    75d4:	540000e2 	b.cs	75f0 <f12+0xb60>  // b.hs, b.nlast
    75d8:	8b01039c 	add	x28, x28, x1
    75dc:	39400380 	ldrb	w0, [x28]
    75e0:	7103fc1f 	cmp	w0, #0xff
    75e4:	54002000 	b.eq	79e4 <f12+0xf54>  // b.none
    75e8:	52800020 	mov	w0, #0x1                   	// #1
    75ec:	39000380 	strb	w0, [x28]
    75f0:	d10006e0 	sub	x0, x23, #0x1
    75f4:	eb00037f 	cmp	x27, x0
    75f8:	54000982 	b.cs	7728 <f12+0xc98>  // b.hs, b.nlast
    75fc:	aa0003f7 	mov	x23, x0
    7600:	b953a740 	ldr	w0, [x26, #5028]
    7604:	f8777ad4 	ldr	x20, [x22, x23, lsl #3]
    7608:	34000240 	cbz	w0, 7650 <f12+0xbc0>
    760c:	397e8b40 	ldrb	w0, [x26, #4002]
    7610:	910f0001 	add	x1, x0, #0x3c0
    7614:	8b000400 	add	x0, x0, x0, lsl #1
    7618:	b8617b45 	ldr	w5, [x26, x1, lsl #2]
    761c:	8b000f41 	add	x1, x26, x0, lsl #3
    7620:	f8607b5c 	ldr	x28, [x26, x0, lsl #3]
    7624:	2a0503e4 	mov	w4, w5
    7628:	b5fff6bc 	cbnz	x28, 74fc <f12+0xa6c>
    762c:	f940043c 	ldr	x28, [x1, #8]
    7630:	b400011c 	cbz	x28, 7650 <f12+0xbc0>
    7634:	f9400820 	ldr	x0, [x1, #16]
    7638:	cb1c0000 	sub	x0, x0, x28
    763c:	eb00009f 	cmp	x4, x0
    7640:	54000088 	b.hi	7650 <f12+0xbc0>  // b.pmore
    7644:	8b040380 	add	x0, x28, x4
    7648:	f9000420 	str	x0, [x1, #8]
    764c:	17ffffaf 	b	7508 <f12+0xa78>
    7650:	52800001 	mov	w1, #0x0                   	// #0
    7654:	d2800300 	mov	x0, #0x18                  	// #24
    7658:	97fff626 	bl	4ef0 <fwp_heap_alloc>
    765c:	aa0003fc 	mov	x28, x0
    7660:	17ffffc4 	b	7570 <f12+0xae0>
    7664:	72003c1f 	tst	w0, #0xffff
    7668:	54fff320 	b.eq	74cc <f12+0xa3c>  // b.none
    766c:	d2800018 	mov	x24, #0x0                   	// #0
    7670:	eb17037f 	cmp	x27, x23
    7674:	54fff383 	b.cc	74e4 <f12+0xa54>  // b.lo, b.ul, b.last
    7678:	8b1b0f3b 	add	x27, x25, x27, lsl #3
    767c:	aa1903e1 	mov	x1, x25
    7680:	aa1503e0 	mov	x0, x21
    7684:	d503201f 	nop
    7688:	f8408422 	ldr	x2, [x1], #8
    768c:	f9000402 	str	x2, [x0, #8]
    7690:	aa0003e2 	mov	x2, x0
    7694:	f9400800 	ldr	x0, [x0, #16]
    7698:	eb1b003f 	cmp	x1, x27
    769c:	54ffff61 	b.ne	7688 <f12+0xbf8>  // b.any
    76a0:	b94023e1 	ldr	w1, [sp, #32]
    76a4:	f9000858 	str	x24, [x2, #16]
    76a8:	aa1503f8 	mov	x24, x21
    76ac:	aa0003f5 	mov	x21, x0
    76b0:	34000041 	cbz	w1, 76b8 <f12+0xc28>
    76b4:	d2800019 	mov	x25, #0x0                   	// #0
    76b8:	aa1903e0 	mov	x0, x25
    76bc:	97fff4ed 	bl	4a70 <fwp_mem_free>
    76c0:	f9400fe0 	ldr	x0, [sp, #24]
    76c4:	97fffc53 	bl	6810 <fwp_drop4>
    76c8:	aa1503e0 	mov	x0, x21
    76cc:	97fff882 	bl	58d4 <fwp_drop0>
    76d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    76d4:	f947f400 	ldr	x0, [x0, #4072]
    76d8:	f94057e2 	ldr	x2, [sp, #168]
    76dc:	f9400001 	ldr	x1, [x0]
    76e0:	eb010042 	subs	x2, x2, x1
    76e4:	d2800001 	mov	x1, #0x0                   	// #0
    76e8:	54002bc1 	b.ne	7c60 <f12+0x11d0>  // b.any
    76ec:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    76f0:	aa1803e0 	mov	x0, x24
    76f4:	a94c53f3 	ldp	x19, x20, [sp, #192]
    76f8:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    76fc:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7700:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7704:	a95073fb 	ldp	x27, x28, [sp, #256]
    7708:	fd408be8 	ldr	d8, [sp, #272]
    770c:	910483ff 	add	sp, sp, #0x120
    7710:	d65f03c0 	ret
    7714:	72003c3f 	tst	w1, #0xffff
    7718:	54fff620 	b.eq	75dc <f12+0xb4c>  // b.none
    771c:	d10006e0 	sub	x0, x23, #0x1
    7720:	eb00037f 	cmp	x27, x0
    7724:	54fff6c3 	b.cc	75fc <f12+0xb6c>  // b.lo, b.ul, b.last
    7728:	b5fffa9b 	cbnz	x27, 7678 <f12+0xbe8>
    772c:	b94023e1 	ldr	w1, [sp, #32]
    7730:	7100003f 	cmp	w1, #0x0
    7734:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7738:	b4fffc00 	cbz	x0, 76b8 <f12+0xc28>
    773c:	91174273 	add	x19, x19, #0x5d0
    7740:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    7744:	d1000afa 	sub	x26, x23, #0x2
    7748:	52800034 	mov	w20, #0x1                   	// #1
    774c:	fd41a808 	ldr	d8, [x0, #848]
    7750:	b953a660 	ldr	w0, [x19, #5028]
    7754:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    7758:	340008c0 	cbz	w0, 7870 <f12+0xde0>
    775c:	d503201f 	nop
    7760:	397e8a60 	ldrb	w0, [x19, #4002]
    7764:	910f0001 	add	x1, x0, #0x3c0
    7768:	8b000400 	add	x0, x0, x0, lsl #1
    776c:	b8617a7c 	ldr	w28, [x19, x1, lsl #2]
    7770:	8b000e61 	add	x1, x19, x0, lsl #3
    7774:	f8607a76 	ldr	x22, [x19, x0, lsl #3]
    7778:	2a1c03fb 	mov	w27, w28
    777c:	b40022f6 	cbz	x22, 7bd8 <f12+0x1148>
    7780:	f94002c1 	ldr	x1, [x22]
    7784:	aa2103e1 	mvn	x1, x1
    7788:	f8207a61 	str	x1, [x19, x0, lsl #3]
    778c:	f100637f 	cmp	x27, #0x18
    7790:	540000e9 	b.ls	77ac <f12+0xd1c>  // b.plast
    7794:	d1006762 	sub	x2, x27, #0x19
    7798:	910062c0 	add	x0, x22, #0x18
    779c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    77a0:	52800001 	mov	w1, #0x0                   	// #0
    77a4:	91002042 	add	x2, x2, #0x8
    77a8:	97ffec2a 	bl	2850 <memset@plt>
    77ac:	f94a1260 	ldr	x0, [x19, #5152]
    77b0:	ab1b0000 	adds	x0, x0, x27
    77b4:	54002362 	b.cs	7c20 <f12+0x1190>  // b.hs, b.nlast
    77b8:	f94a1661 	ldr	x1, [x19, #5160]
    77bc:	f90a1260 	str	x0, [x19, #5152]
    77c0:	eb01001f 	cmp	x0, x1
    77c4:	54000049 	b.ls	77cc <f12+0xd3c>  // b.plast
    77c8:	f90a1660 	str	x0, [x19, #5160]
    77cc:	1e630381 	ucvtf	d1, w28
    77d0:	fd4a1e60 	ldr	d0, [x19, #5176]
    77d4:	1e612800 	fadd	d0, d0, d1
    77d8:	fd0a1e60 	str	d0, [x19, #5176]
    77dc:	a900e2d7 	stp	x23, x24, [x22, #8]
    77e0:	aa1603f8 	mov	x24, x22
    77e4:	fd0002c8 	str	d8, [x22]
    77e8:	f949da61 	ldr	x1, [x19, #5040]
    77ec:	f949ee60 	ldr	x0, [x19, #5080]
    77f0:	cb0102c1 	sub	x1, x22, x1
    77f4:	eb00403f 	cmp	x1, x0, lsl #16
    77f8:	54000302 	b.cs	7858 <f12+0xdc8>  // b.hs, b.nlast
    77fc:	d350fc22 	lsr	x2, x1, #16
    7800:	f949fe63 	ldr	x3, [x19, #5112]
    7804:	8b020842 	add	x2, x2, x2, lsl #2
    7808:	d37df042 	lsl	x2, x2, #3
    780c:	8b020060 	add	x0, x3, x2
    7810:	f9401016 	ldr	x22, [x0, #32]
    7814:	b4000236 	cbz	x22, 7858 <f12+0xdc8>
    7818:	38626862 	ldrb	w2, [x3, x2]
    781c:	7100085f 	cmp	w2, #0x2
    7820:	54001ee0 	b.eq	7bfc <f12+0x116c>  // b.none
    7824:	7100045f 	cmp	w2, #0x1
    7828:	54000181 	b.ne	7858 <f12+0xdc8>  // b.any
    782c:	29430002 	ldp	w2, w0, [x0, #24]
    7830:	92403c21 	and	x1, x1, #0xffff
    7834:	9b027c21 	mul	x1, x1, x2
    7838:	d360fc21 	lsr	x1, x1, #32
    783c:	eb00003f 	cmp	x1, x0
    7840:	540000c2 	b.cs	7858 <f12+0xdc8>  // b.hs, b.nlast
    7844:	8b0102d6 	add	x22, x22, x1
    7848:	394002c0 	ldrb	w0, [x22]
    784c:	7103fc1f 	cmp	w0, #0xff
    7850:	54001be0 	b.eq	7bcc <f12+0x113c>  // b.none
    7854:	390002d4 	strb	w20, [x22]
    7858:	d100075a 	sub	x26, x26, #0x1
    785c:	b100075f 	cmn	x26, #0x1
    7860:	54fff2c0 	b.eq	76b8 <f12+0xc28>  // b.none
    7864:	b953a660 	ldr	w0, [x19, #5028]
    7868:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    786c:	35fff7a0 	cbnz	w0, 7760 <f12+0xcd0>
    7870:	52800001 	mov	w1, #0x0                   	// #0
    7874:	d2800300 	mov	x0, #0x18                  	// #24
    7878:	97fff59e 	bl	4ef0 <fwp_heap_alloc>
    787c:	aa0003f6 	mov	x22, x0
    7880:	17ffffd7 	b	77dc <f12+0xd4c>
    7884:	72003c1f 	tst	w0, #0xffff
    7888:	54ffd960 	b.eq	73b4 <f12+0x924>  // b.none
    788c:	b4001495 	cbz	x21, 7b1c <f12+0x108c>
    7890:	aa1503f6 	mov	x22, x21
    7894:	d2800018 	mov	x24, #0x0                   	// #0
    7898:	f9400ad6 	ldr	x22, [x22, #16]
    789c:	aa1803e0 	mov	x0, x24
    78a0:	91000718 	add	x24, x24, #0x1
    78a4:	b5ffffb6 	cbnz	x22, 7898 <f12+0xe08>
    78a8:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    78ac:	eb01031f 	cmp	x24, x1
    78b0:	54001d28 	b.hi	7c54 <f12+0x11c4>  // b.pmore
    78b4:	91000800 	add	x0, x0, #0x2
    78b8:	52800041 	mov	w1, #0x2                   	// #2
    78bc:	d37df000 	lsl	x0, x0, #3
    78c0:	97fff58c 	bl	4ef0 <fwp_heap_alloc>
    78c4:	eb17031f 	cmp	x24, x23
    78c8:	aa0003f9 	mov	x25, x0
    78cc:	9a979317 	csel	x23, x24, x23, ls	// ls = plast
    78d0:	aa1503e1 	mov	x1, x21
    78d4:	d503201f 	nop
    78d8:	f9400420 	ldr	x0, [x1, #8]
    78dc:	f8367b20 	str	x0, [x25, x22, lsl #3]
    78e0:	910006d6 	add	x22, x22, #0x1
    78e4:	f9400821 	ldr	x1, [x1, #16]
    78e8:	b5ffff81 	cbnz	x1, 78d8 <f12+0xe48>
    78ec:	b4001217 	cbz	x23, 7b2c <f12+0x109c>
    78f0:	f9400343 	ldr	x3, [x26]
    78f4:	b90023ff 	str	wzr, [sp, #32]
    78f8:	17fffeb7 	b	73d4 <f12+0x944>
    78fc:	72003c1f 	tst	w0, #0xffff
    7900:	54ffcc40 	b.eq	7288 <f12+0x7f8>  // b.none
    7904:	d503201f 	nop
    7908:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    790c:	eb0002ff 	cmp	x23, x0
    7910:	54001aa8 	b.hi	7c64 <f12+0x11d4>  // b.pmore
    7914:	910006e0 	add	x0, x23, #0x1
    7918:	52800021 	mov	w1, #0x1                   	// #1
    791c:	d37df000 	lsl	x0, x0, #3
    7920:	97fff574 	bl	4ef0 <fwp_heap_alloc>
    7924:	91174262 	add	x2, x19, #0x5d0
    7928:	f9000017 	str	x23, [x0]
    792c:	aa0003fa 	mov	x26, x0
    7930:	f9000ffa 	str	x26, [sp, #24]
    7934:	f949d841 	ldr	x1, [x2, #5040]
    7938:	f949ec40 	ldr	x0, [x2, #5080]
    793c:	cb010341 	sub	x1, x26, x1
    7940:	eb00403f 	cmp	x1, x0, lsl #16
    7944:	54000322 	b.cs	79a8 <f12+0xf18>  // b.hs, b.nlast
    7948:	d350fc20 	lsr	x0, x1, #16
    794c:	f949fc43 	ldr	x3, [x2, #5112]
    7950:	8b000800 	add	x0, x0, x0, lsl #2
    7954:	d37df002 	lsl	x2, x0, #3
    7958:	8b020060 	add	x0, x3, x2
    795c:	f9401018 	ldr	x24, [x0, #32]
    7960:	b4000258 	cbz	x24, 79a8 <f12+0xf18>
    7964:	38626862 	ldrb	w2, [x3, x2]
    7968:	7100085f 	cmp	w2, #0x2
    796c:	54000e40 	b.eq	7b34 <f12+0x10a4>  // b.none
    7970:	7100045f 	cmp	w2, #0x1
    7974:	540001a1 	b.ne	79a8 <f12+0xf18>  // b.any
    7978:	29430002 	ldp	w2, w0, [x0, #24]
    797c:	92403c21 	and	x1, x1, #0xffff
    7980:	9b027c21 	mul	x1, x1, x2
    7984:	d360fc21 	lsr	x1, x1, #32
    7988:	eb00003f 	cmp	x1, x0
    798c:	540000e2 	b.cs	79a8 <f12+0xf18>  // b.hs, b.nlast
    7990:	8b010318 	add	x24, x24, x1
    7994:	39400300 	ldrb	w0, [x24]
    7998:	7103fc1f 	cmp	w0, #0xff
    799c:	54001040 	b.eq	7ba4 <f12+0x1114>  // b.none
    79a0:	52800020 	mov	w0, #0x1                   	// #1
    79a4:	39000300 	strb	w0, [x24]
    79a8:	aa1603e0 	mov	x0, x22
    79ac:	17fffe3d 	b	72a0 <f12+0x810>
    79b0:	52800041 	mov	w1, #0x2                   	// #2
    79b4:	d2800100 	mov	x0, #0x8                   	// #8
    79b8:	97fff54e 	bl	4ef0 <fwp_heap_alloc>
    79bc:	aa0003f8 	mov	x24, x0
    79c0:	91174260 	add	x0, x19, #0x5d0
    79c4:	f900031f 	str	xzr, [x24]
    79c8:	f949d801 	ldr	x1, [x0, #5040]
    79cc:	f949ec00 	ldr	x0, [x0, #5080]
    79d0:	cb010301 	sub	x1, x24, x1
    79d4:	eb00403f 	cmp	x1, x0, lsl #16
    79d8:	540003e2 	b.cs	7a54 <f12+0xfc4>  // b.hs, b.nlast
    79dc:	d2800016 	mov	x22, #0x0                   	// #0
    79e0:	17fffcff 	b	6ddc <f12+0x34c>
    79e4:	aa1c03e0 	mov	x0, x28
    79e8:	97fff382 	bl	47f0 <fwp_rc_forget_slot>
    79ec:	17fffeff 	b	75e8 <f12+0xb58>
    79f0:	f100037f 	cmp	x27, #0x0
    79f4:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    79f8:	54ffb2e1 	b.ne	7054 <f12+0x5c4>  // b.any
    79fc:	f9400fe0 	ldr	x0, [sp, #24]
    7a00:	9101c294 	add	x20, x20, #0x70
    7a04:	f9402fe1 	ldr	x1, [sp, #88]
    7a08:	f9018a81 	str	x1, [x20, #784]
    7a0c:	97fff25d 	bl	4380 <fwp_tape_buffers_release>
    7a10:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7a14:	f947e863 	ldr	x3, [x3, #4048]
    7a18:	d2800262 	mov	x2, #0x13                  	// #19
    7a1c:	d2800021 	mov	x1, #0x1                   	// #1
    7a20:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7a24:	91162000 	add	x0, x0, #0x588
    7a28:	f9400063 	ldr	x3, [x3]
    7a2c:	97ffebd5 	bl	2980 <fwrite@plt>
    7a30:	d2800000 	mov	x0, #0x0                   	// #0
    7a34:	97ffebdf 	bl	29b0 <fflush@plt>
    7a38:	52800cc0 	mov	w0, #0x66                  	// #102
    7a3c:	97ffebed 	bl	29f0 <_Exit@plt>
    7a40:	eb18033f 	cmp	x25, x24
    7a44:	54ff8ec0 	b.eq	6c1c <f12+0x18c>  // b.none
    7a48:	f9403a9c 	ldr	x28, [x20, #112]
    7a4c:	17fffc91 	b	6c90 <f12+0x200>
    7a50:	b5ff9fb6 	cbnz	x22, 6e44 <f12+0x3b4>
    7a54:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7a58:	f900031f 	str	xzr, [x24]
    7a5c:	17fffd2e 	b	6f14 <f12+0x484>
    7a60:	d0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x110>
    7a64:	91384000 	add	x0, x0, #0xe10
    7a68:	94000eba 	bl	b550 <atexit>
    7a6c:	35fffd20 	cbnz	w0, 7a10 <f12+0xf80>
    7a70:	52800020 	mov	w0, #0x1                   	// #1
    7a74:	b9034700 	str	w0, [x24, #836]
    7a78:	17fffc55 	b	6bcc <f12+0x13c>
    7a7c:	72003c3f 	tst	w1, #0xffff
    7a80:	54ff9e01 	b.ne	6e40 <f12+0x3b0>  // b.any
    7a84:	17fffcea 	b	6e2c <f12+0x39c>
    7a88:	72003c3f 	tst	w1, #0xffff
    7a8c:	54ff8740 	b.eq	6b74 <f12+0xe4>  // b.none
    7a90:	aa1703e0 	mov	x0, x23
    7a94:	97fff83f 	bl	5b90 <fwp_closure_drop>
    7a98:	b5ff8815 	cbnz	x21, 6b98 <f12+0x108>
    7a9c:	52800000 	mov	w0, #0x0                   	// #0
    7aa0:	d2800017 	mov	x23, #0x0                   	// #0
    7aa4:	97ffeed3 	bl	35f0 <descent_phase_step>
    7aa8:	17fffc46 	b	6bc0 <f12+0x130>
    7aac:	aa1c03fb 	mov	x27, x28
    7ab0:	17fffd53 	b	6ffc <f12+0x56c>
    7ab4:	72003c3f 	tst	w1, #0xffff
    7ab8:	54ffba01 	b.ne	71f8 <f12+0x768>  // b.any
    7abc:	17fffdca 	b	71e4 <f12+0x754>
    7ac0:	3cc98002 	ldur	q2, [x0, #152]
    7ac4:	91026001 	add	x1, x0, #0x98
    7ac8:	3cca8001 	ldur	q1, [x0, #168]
    7acc:	f900681f 	str	xzr, [x0, #208]
    7ad0:	4f000400 	movi	v0.4s, #0x0
    7ad4:	ad010702 	stp	q2, q1, [x24, #32]
    7ad8:	a94b8002 	ldp	x2, x0, [x0, #184]
    7adc:	f9000f00 	str	x0, [x24, #24]
    7ae0:	f9401820 	ldr	x0, [x1, #48]
    7ae4:	f9002302 	str	x2, [x24, #64]
    7ae8:	f9002700 	str	x0, [x24, #72]
    7aec:	ad000020 	stp	q0, q0, [x1]
    7af0:	3d800820 	str	q0, [x1, #32]
    7af4:	f900183f 	str	xzr, [x1, #48]
    7af8:	17fffc74 	b	6cc8 <f12+0x238>
    7afc:	d37ffb1a 	lsl	x26, x24, #1
    7b00:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7b04:	eb00035f 	cmp	x26, x0
    7b08:	9a80d35a 	csel	x26, x26, x0, le
    7b0c:	8b1a0741 	add	x1, x26, x26, lsl #1
    7b10:	8b010b41 	add	x1, x26, x1, lsl #2
    7b14:	d37df021 	lsl	x1, x1, #3
    7b18:	17fffc4c 	b	6c48 <f12+0x1b8>
    7b1c:	52800041 	mov	w1, #0x2                   	// #2
    7b20:	d2800100 	mov	x0, #0x8                   	// #8
    7b24:	97fff4f3 	bl	4ef0 <fwp_heap_alloc>
    7b28:	aa0003f9 	mov	x25, x0
    7b2c:	d2800018 	mov	x24, #0x0                   	// #0
    7b30:	17fffee2 	b	76b8 <f12+0xc28>
    7b34:	72003c3f 	tst	w1, #0xffff
    7b38:	54fff2e0 	b.eq	7994 <f12+0xf04>  // b.none
    7b3c:	aa1603e0 	mov	x0, x22
    7b40:	17fffdd8 	b	72a0 <f12+0x810>
    7b44:	aa0203e0 	mov	x0, x2
    7b48:	d2800101 	mov	x1, #0x8                   	// #8
    7b4c:	f90013e2 	str	x2, [sp, #32]
    7b50:	97ffeb44 	bl	2860 <calloc@plt>
    7b54:	a94213e2 	ldp	x2, x4, [sp, #32]
    7b58:	aa0003fa 	mov	x26, x0
    7b5c:	17fffd3b 	b	7048 <f12+0x5b8>
    7b60:	f9400343 	ldr	x3, [x26]
    7b64:	b7fffdc3 	tbnz	x3, #63, 7b1c <f12+0x108c>
    7b68:	91174261 	add	x1, x19, #0x5d0
    7b6c:	f9400fe4 	ldr	x4, [sp, #24]
    7b70:	f949d820 	ldr	x0, [x1, #5040]
    7b74:	f949ec21 	ldr	x1, [x1, #5080]
    7b78:	cb000080 	sub	x0, x4, x0
    7b7c:	eb01401f 	cmp	x0, x1, lsl #16
    7b80:	54fffce2 	b.cs	7b1c <f12+0x108c>  // b.hs, b.nlast
    7b84:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7b88:	17fffdf7 	b	7364 <f12+0x8d4>
    7b8c:	aa1903e0 	mov	x0, x25
    7b90:	97fff318 	bl	47f0 <fwp_rc_forget_slot>
    7b94:	17fffca9 	b	6e38 <f12+0x3a8>
    7b98:	aa1703e0 	mov	x0, x23
    7b9c:	97fff315 	bl	47f0 <fwp_rc_forget_slot>
    7ba0:	17fffd94 	b	71f0 <f12+0x760>
    7ba4:	aa1803e0 	mov	x0, x24
    7ba8:	97fff312 	bl	47f0 <fwp_rc_forget_slot>
    7bac:	17ffff7d 	b	79a0 <f12+0xf10>
    7bb0:	97fff2c9 	bl	46d4 <fwp_rc_wide_dup>
    7bb4:	17fffbf6 	b	6b8c <f12+0xfc>
    7bb8:	d280001b 	mov	x27, #0x0                   	// #0
    7bbc:	17fffe4a 	b	74e4 <f12+0xa54>
    7bc0:	d2800019 	mov	x25, #0x0                   	// #0
    7bc4:	d2800018 	mov	x24, #0x0                   	// #0
    7bc8:	17fffebc 	b	76b8 <f12+0xc28>
    7bcc:	aa1603e0 	mov	x0, x22
    7bd0:	97fff308 	bl	47f0 <fwp_rc_forget_slot>
    7bd4:	17ffff20 	b	7854 <f12+0xdc4>
    7bd8:	f9400436 	ldr	x22, [x1, #8]
    7bdc:	b4ffe4b6 	cbz	x22, 7870 <f12+0xde0>
    7be0:	f9400820 	ldr	x0, [x1, #16]
    7be4:	cb160000 	sub	x0, x0, x22
    7be8:	eb00037f 	cmp	x27, x0
    7bec:	54ffe428 	b.hi	7870 <f12+0xde0>  // b.pmore
    7bf0:	8b1b02c0 	add	x0, x22, x27
    7bf4:	f9000420 	str	x0, [x1, #8]
    7bf8:	17fffee5 	b	778c <f12+0xcfc>
    7bfc:	72003c3f 	tst	w1, #0xffff
    7c00:	54ffe2c1 	b.ne	7858 <f12+0xdc8>  // b.any
    7c04:	17ffff11 	b	7848 <f12+0xdb8>
    7c08:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c0c:	9124a000 	add	x0, x0, #0x928
    7c10:	97ffeefc 	bl	3800 <fwp_trap>
    7c14:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c18:	91270000 	add	x0, x0, #0x9c0
    7c1c:	97ffeef9 	bl	3800 <fwp_trap>
    7c20:	97ffed04 	bl	3030 <fwp_heap_oom>
    7c24:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c28:	9125c000 	add	x0, x0, #0x970
    7c2c:	97ffeef5 	bl	3800 <fwp_trap>
    7c30:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c34:	91288000 	add	x0, x0, #0xa20
    7c38:	97ffeef2 	bl	3800 <fwp_trap>
    7c3c:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c40:	91290000 	add	x0, x0, #0xa40
    7c44:	97ffeeef 	bl	3800 <fwp_trap>
    7c48:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c4c:	9129c000 	add	x0, x0, #0xa70
    7c50:	97ffeeec 	bl	3800 <fwp_trap>
    7c54:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c58:	912a8000 	add	x0, x0, #0xaa0
    7c5c:	97ffeee9 	bl	3800 <fwp_trap>
    7c60:	97ffeb08 	bl	2880 <__stack_chk_fail@plt>
    7c64:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c68:	912ac000 	add	x0, x0, #0xab0
    7c6c:	97ffeee5 	bl	3800 <fwp_trap>
    7c70:	90000020 	adrp	x0, b000 <__divti3+0x1a0>
    7c74:	912b0000 	add	x0, x0, #0xac0
    7c78:	97ffeee2 	bl	3800 <fwp_trap>
    7c7c:	97ffeb15 	bl	28d0 <abort@plt>
    7c80:	97ffeb80 	bl	2a80 <fwp_trap_overflow.constprop.0>

0000000000007c84 <fwp_owned_entry12>:
    7c84:	f9400000 	ldr	x0, [x0]
    7c88:	17fffb82 	b	6a90 <f12>
    7c8c:	d503201f 	nop

0000000000007c90 <e12>:
    7c90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7c94:	910003fd 	mov	x29, sp
    7c98:	f9000bf3 	str	x19, [sp, #16]
    7c9c:	f9400013 	ldr	x19, [x0]
    7ca0:	aa1303e0 	mov	x0, x19
    7ca4:	97fff69f 	bl	5720 <fwp_rc_share>
    7ca8:	aa1303e0 	mov	x0, x19
    7cac:	97fffb79 	bl	6a90 <f12>
    7cb0:	aa0003f3 	mov	x19, x0
    7cb4:	97fff69b 	bl	5720 <fwp_rc_share>
    7cb8:	aa1303e0 	mov	x0, x19
    7cbc:	f9400bf3 	ldr	x19, [sp, #16]
    7cc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7cc4:	d65f03c0 	ret
    7cc8:	d503201f 	nop
    7ccc:	d503201f 	nop

0000000000007cd0 <fwp_args12>:
    7cd0:	7100003f 	cmp	w1, #0x0
    7cd4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7cd8:	54000041 	b.ne	7ce0 <fwp_args12+0x10>  // b.any
    7cdc:	d65f03c0 	ret
    7ce0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7ce4:	91174042 	add	x2, x2, #0x5d0
    7ce8:	f9400001 	ldr	x1, [x0]
    7cec:	f949d843 	ldr	x3, [x2, #5040]
    7cf0:	f949ec40 	ldr	x0, [x2, #5080]
    7cf4:	cb030021 	sub	x1, x1, x3
    7cf8:	eb00403f 	cmp	x1, x0, lsl #16
    7cfc:	54ffff02 	b.cs	7cdc <fwp_args12+0xc>  // b.hs, b.nlast
    7d00:	d350fc20 	lsr	x0, x1, #16
    7d04:	f949fc44 	ldr	x4, [x2, #5112]
    7d08:	8b000800 	add	x0, x0, x0, lsl #2
    7d0c:	d37df002 	lsl	x2, x0, #3
    7d10:	8b020083 	add	x3, x4, x2
    7d14:	f9401060 	ldr	x0, [x3, #32]
    7d18:	b4fffe20 	cbz	x0, 7cdc <fwp_args12+0xc>
    7d1c:	38626882 	ldrb	w2, [x4, x2]
    7d20:	7100085f 	cmp	w2, #0x2
    7d24:	54000220 	b.eq	7d68 <fwp_args12+0x98>  // b.none
    7d28:	7100045f 	cmp	w2, #0x1
    7d2c:	54fffd81 	b.ne	7cdc <fwp_args12+0xc>  // b.any
    7d30:	29430864 	ldp	w4, w2, [x3, #24]
    7d34:	92403c21 	and	x1, x1, #0xffff
    7d38:	9b047c21 	mul	x1, x1, x4
    7d3c:	d360fc21 	lsr	x1, x1, #32
    7d40:	eb02003f 	cmp	x1, x2
    7d44:	54fffcc2 	b.cs	7cdc <fwp_args12+0xc>  // b.hs, b.nlast
    7d48:	8b010000 	add	x0, x0, x1
    7d4c:	39400001 	ldrb	w1, [x0]
    7d50:	34fffc61 	cbz	w1, 7cdc <fwp_args12+0xc>
    7d54:	7103f43f 	cmp	w1, #0xfd
    7d58:	540000e8 	b.hi	7d74 <fwp_args12+0xa4>  // b.pmore
    7d5c:	11000421 	add	w1, w1, #0x1
    7d60:	39000001 	strb	w1, [x0]
    7d64:	d65f03c0 	ret
    7d68:	72003c3f 	tst	w1, #0xffff
    7d6c:	54ffff00 	b.eq	7d4c <fwp_args12+0x7c>  // b.none
    7d70:	d65f03c0 	ret
    7d74:	17fff258 	b	46d4 <fwp_rc_wide_dup>
    7d78:	d503201f 	nop
    7d7c:	d503201f 	nop

0000000000007d80 <fwp_args23>:
    7d80:	7100003f 	cmp	w1, #0x0
    7d84:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7d88:	54000041 	b.ne	7d90 <fwp_args23+0x10>  // b.any
    7d8c:	d65f03c0 	ret
    7d90:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7d94:	91174042 	add	x2, x2, #0x5d0
    7d98:	f9400001 	ldr	x1, [x0]
    7d9c:	f949d843 	ldr	x3, [x2, #5040]
    7da0:	f949ec40 	ldr	x0, [x2, #5080]
    7da4:	cb030021 	sub	x1, x1, x3
    7da8:	eb00403f 	cmp	x1, x0, lsl #16
    7dac:	54ffff02 	b.cs	7d8c <fwp_args23+0xc>  // b.hs, b.nlast
    7db0:	d350fc20 	lsr	x0, x1, #16
    7db4:	f949fc44 	ldr	x4, [x2, #5112]
    7db8:	8b000800 	add	x0, x0, x0, lsl #2
    7dbc:	d37df002 	lsl	x2, x0, #3
    7dc0:	8b020083 	add	x3, x4, x2
    7dc4:	f9401060 	ldr	x0, [x3, #32]
    7dc8:	b4fffe20 	cbz	x0, 7d8c <fwp_args23+0xc>
    7dcc:	38626882 	ldrb	w2, [x4, x2]
    7dd0:	7100085f 	cmp	w2, #0x2
    7dd4:	54000220 	b.eq	7e18 <fwp_args23+0x98>  // b.none
    7dd8:	7100045f 	cmp	w2, #0x1
    7ddc:	54fffd81 	b.ne	7d8c <fwp_args23+0xc>  // b.any
    7de0:	29430864 	ldp	w4, w2, [x3, #24]
    7de4:	92403c21 	and	x1, x1, #0xffff
    7de8:	9b047c21 	mul	x1, x1, x4
    7dec:	d360fc21 	lsr	x1, x1, #32
    7df0:	eb02003f 	cmp	x1, x2
    7df4:	54fffcc2 	b.cs	7d8c <fwp_args23+0xc>  // b.hs, b.nlast
    7df8:	8b010000 	add	x0, x0, x1
    7dfc:	39400001 	ldrb	w1, [x0]
    7e00:	34fffc61 	cbz	w1, 7d8c <fwp_args23+0xc>
    7e04:	7103f43f 	cmp	w1, #0xfd
    7e08:	540000e8 	b.hi	7e24 <fwp_args23+0xa4>  // b.pmore
    7e0c:	11000421 	add	w1, w1, #0x1
    7e10:	39000001 	strb	w1, [x0]
    7e14:	d65f03c0 	ret
    7e18:	72003c3f 	tst	w1, #0xffff
    7e1c:	54ffff00 	b.eq	7dfc <fwp_args23+0x7c>  // b.none
    7e20:	d65f03c0 	ret
    7e24:	17fff22c 	b	46d4 <fwp_rc_wide_dup>
    7e28:	d503201f 	nop
    7e2c:	d503201f 	nop

0000000000007e30 <fwp_caps12>:
    7e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7e34:	910003fd 	mov	x29, sp
    7e38:	f9000bf3 	str	x19, [sp, #16]
    7e3c:	aa0003f3 	mov	x19, x0
    7e40:	b9400400 	ldr	w0, [x0, #4]
    7e44:	340004a0 	cbz	w0, 7ed8 <fwp_caps12+0xa8>
    7e48:	f9400660 	ldr	x0, [x19, #8]
    7e4c:	350004e1 	cbnz	w1, 7ee8 <fwp_caps12+0xb8>
    7e50:	97fff6a1 	bl	58d4 <fwp_drop0>
    7e54:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7e58:	91174042 	add	x2, x2, #0x5d0
    7e5c:	f949d840 	ldr	x0, [x2, #5040]
    7e60:	f949ec41 	ldr	x1, [x2, #5080]
    7e64:	cb000260 	sub	x0, x19, x0
    7e68:	eb01401f 	cmp	x0, x1, lsl #16
    7e6c:	54000382 	b.cs	7edc <fwp_caps12+0xac>  // b.hs, b.nlast
    7e70:	d350fc01 	lsr	x1, x0, #16
    7e74:	f949fc44 	ldr	x4, [x2, #5112]
    7e78:	8b010821 	add	x1, x1, x1, lsl #2
    7e7c:	d37df021 	lsl	x1, x1, #3
    7e80:	8b010083 	add	x3, x4, x1
    7e84:	f9401062 	ldr	x2, [x3, #32]
    7e88:	b40002a2 	cbz	x2, 7edc <fwp_caps12+0xac>
    7e8c:	38616881 	ldrb	w1, [x4, x1]
    7e90:	7100083f 	cmp	w1, #0x2
    7e94:	540006c0 	b.eq	7f6c <fwp_caps12+0x13c>  // b.none
    7e98:	7100043f 	cmp	w1, #0x1
    7e9c:	54000201 	b.ne	7edc <fwp_caps12+0xac>  // b.any
    7ea0:	29430464 	ldp	w4, w1, [x3, #24]
    7ea4:	92403c00 	and	x0, x0, #0xffff
    7ea8:	9b047c00 	mul	x0, x0, x4
    7eac:	d360fc00 	lsr	x0, x0, #32
    7eb0:	eb01001f 	cmp	x0, x1
    7eb4:	54000142 	b.cs	7edc <fwp_caps12+0xac>  // b.hs, b.nlast
    7eb8:	8b000042 	add	x2, x2, x0
    7ebc:	39400040 	ldrb	w0, [x2]
    7ec0:	7100041f 	cmp	w0, #0x1
    7ec4:	540000c1 	b.ne	7edc <fwp_caps12+0xac>  // b.any
    7ec8:	aa1303e0 	mov	x0, x19
    7ecc:	f9400bf3 	ldr	x19, [sp, #16]
    7ed0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ed4:	17fff2e7 	b	4a70 <fwp_mem_free>
    7ed8:	34fffbe1 	cbz	w1, 7e54 <fwp_caps12+0x24>
    7edc:	f9400bf3 	ldr	x19, [sp, #16]
    7ee0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ee4:	d65f03c0 	ret
    7ee8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7eec:	91174042 	add	x2, x2, #0x5d0
    7ef0:	f949d843 	ldr	x3, [x2, #5040]
    7ef4:	f949ec41 	ldr	x1, [x2, #5080]
    7ef8:	cb030000 	sub	x0, x0, x3
    7efc:	eb01401f 	cmp	x0, x1, lsl #16
    7f00:	54fffee2 	b.cs	7edc <fwp_caps12+0xac>  // b.hs, b.nlast
    7f04:	d350fc01 	lsr	x1, x0, #16
    7f08:	f949fc44 	ldr	x4, [x2, #5112]
    7f0c:	8b010821 	add	x1, x1, x1, lsl #2
    7f10:	d37df021 	lsl	x1, x1, #3
    7f14:	8b010083 	add	x3, x4, x1
    7f18:	f9401062 	ldr	x2, [x3, #32]
    7f1c:	b4fffe02 	cbz	x2, 7edc <fwp_caps12+0xac>
    7f20:	38616881 	ldrb	w1, [x4, x1]
    7f24:	7100083f 	cmp	w1, #0x2
    7f28:	54000280 	b.eq	7f78 <fwp_caps12+0x148>  // b.none
    7f2c:	7100043f 	cmp	w1, #0x1
    7f30:	54fffd61 	b.ne	7edc <fwp_caps12+0xac>  // b.any
    7f34:	92403c01 	and	x1, x0, #0xffff
    7f38:	29430064 	ldp	w4, w0, [x3, #24]
    7f3c:	9b047c21 	mul	x1, x1, x4
    7f40:	d360fc21 	lsr	x1, x1, #32
    7f44:	eb00003f 	cmp	x1, x0
    7f48:	54fffca2 	b.cs	7edc <fwp_caps12+0xac>  // b.hs, b.nlast
    7f4c:	8b010042 	add	x2, x2, x1
    7f50:	39400040 	ldrb	w0, [x2]
    7f54:	34fffc40 	cbz	w0, 7edc <fwp_caps12+0xac>
    7f58:	7103f41f 	cmp	w0, #0xfd
    7f5c:	54000148 	b.hi	7f84 <fwp_caps12+0x154>  // b.pmore
    7f60:	11000400 	add	w0, w0, #0x1
    7f64:	39000040 	strb	w0, [x2]
    7f68:	17ffffdd 	b	7edc <fwp_caps12+0xac>
    7f6c:	72003c1f 	tst	w0, #0xffff
    7f70:	54fffb61 	b.ne	7edc <fwp_caps12+0xac>  // b.any
    7f74:	17ffffd2 	b	7ebc <fwp_caps12+0x8c>
    7f78:	72003c1f 	tst	w0, #0xffff
    7f7c:	54fffb01 	b.ne	7edc <fwp_caps12+0xac>  // b.any
    7f80:	17fffff4 	b	7f50 <fwp_caps12+0x120>
    7f84:	f9400bf3 	ldr	x19, [sp, #16]
    7f88:	aa0203e0 	mov	x0, x2
    7f8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7f90:	17fff1d1 	b	46d4 <fwp_rc_wide_dup>

0000000000007f94 <fwp_drop2>:
    7f94:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7f98:	910003fd 	mov	x29, sp
    7f9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7fa0:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    7fa4:	911742d5 	add	x21, x22, #0x5d0
    7fa8:	a90153f3 	stp	x19, x20, [sp, #16]
    7fac:	aa0003f3 	mov	x19, x0
    7fb0:	f949daa1 	ldr	x1, [x21, #5040]
    7fb4:	f949eea0 	ldr	x0, [x21, #5080]
    7fb8:	cb010261 	sub	x1, x19, x1
    7fbc:	eb00403f 	cmp	x1, x0, lsl #16
    7fc0:	54000382 	b.cs	8030 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7fc4:	d350fc22 	lsr	x2, x1, #16
    7fc8:	f949fea3 	ldr	x3, [x21, #5112]
    7fcc:	8b020842 	add	x2, x2, x2, lsl #2
    7fd0:	d37df042 	lsl	x2, x2, #3
    7fd4:	8b020060 	add	x0, x3, x2
    7fd8:	f9401014 	ldr	x20, [x0, #32]
    7fdc:	b40002b4 	cbz	x20, 8030 <fwp_drop2+0x9c>
    7fe0:	38626862 	ldrb	w2, [x3, x2]
    7fe4:	7100085f 	cmp	w2, #0x2
    7fe8:	540002c0 	b.eq	8040 <fwp_drop2+0xac>  // b.none
    7fec:	7100045f 	cmp	w2, #0x1
    7ff0:	54000201 	b.ne	8030 <fwp_drop2+0x9c>  // b.any
    7ff4:	29430002 	ldp	w2, w0, [x0, #24]
    7ff8:	92403c21 	and	x1, x1, #0xffff
    7ffc:	9b027c21 	mul	x1, x1, x2
    8000:	d360fc21 	lsr	x1, x1, #32
    8004:	eb00003f 	cmp	x1, x0
    8008:	54000142 	b.cs	8030 <fwp_drop2+0x9c>  // b.hs, b.nlast
    800c:	8b010294 	add	x20, x20, x1
    8010:	39400280 	ldrb	w0, [x20]
    8014:	340000e0 	cbz	w0, 8030 <fwp_drop2+0x9c>
    8018:	7100041f 	cmp	w0, #0x1
    801c:	540001e0 	b.eq	8058 <fwp_drop2+0xc4>  // b.none
    8020:	7103fc1f 	cmp	w0, #0xff
    8024:	540007e0 	b.eq	8120 <fwp_drop2+0x18c>  // b.none
    8028:	51000400 	sub	w0, w0, #0x1
    802c:	39000280 	strb	w0, [x20]
    8030:	a94153f3 	ldp	x19, x20, [sp, #16]
    8034:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8038:	a8c37bfd 	ldp	x29, x30, [sp], #48
    803c:	d65f03c0 	ret
    8040:	72003c3f 	tst	w1, #0xffff
    8044:	54fffe60 	b.eq	8010 <fwp_drop2+0x7c>  // b.none
    8048:	a94153f3 	ldp	x19, x20, [sp, #16]
    804c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8050:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8054:	d65f03c0 	ret
    8058:	911742c2 	add	x2, x22, #0x5d0
    805c:	f9400660 	ldr	x0, [x19, #8]
    8060:	f949d841 	ldr	x1, [x2, #5040]
    8064:	f949ec42 	ldr	x2, [x2, #5080]
    8068:	cb010001 	sub	x1, x0, x1
    806c:	eb02403f 	cmp	x1, x2, lsl #16
    8070:	54000382 	b.cs	80e0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8074:	d350fc22 	lsr	x2, x1, #16
    8078:	8b020842 	add	x2, x2, x2, lsl #2
    807c:	d37df042 	lsl	x2, x2, #3
    8080:	8b020064 	add	x4, x3, x2
    8084:	f9401094 	ldr	x20, [x4, #32]
    8088:	b40002d4 	cbz	x20, 80e0 <fwp_drop2+0x14c>
    808c:	38626862 	ldrb	w2, [x3, x2]
    8090:	7100085f 	cmp	w2, #0x2
    8094:	54000400 	b.eq	8114 <fwp_drop2+0x180>  // b.none
    8098:	7100045f 	cmp	w2, #0x1
    809c:	54000221 	b.ne	80e0 <fwp_drop2+0x14c>  // b.any
    80a0:	29430883 	ldp	w3, w2, [x4, #24]
    80a4:	92403c21 	and	x1, x1, #0xffff
    80a8:	9b037c21 	mul	x1, x1, x3
    80ac:	d360fc21 	lsr	x1, x1, #32
    80b0:	eb02003f 	cmp	x1, x2
    80b4:	54000162 	b.cs	80e0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    80b8:	8b010294 	add	x20, x20, x1
    80bc:	39400281 	ldrb	w1, [x20]
    80c0:	34000101 	cbz	w1, 80e0 <fwp_drop2+0x14c>
    80c4:	7100043f 	cmp	w1, #0x1
    80c8:	54000220 	b.eq	810c <fwp_drop2+0x178>  // b.none
    80cc:	7103fc3f 	cmp	w1, #0xff
    80d0:	540005a0 	b.eq	8184 <fwp_drop2+0x1f0>  // b.none
    80d4:	51000421 	sub	w1, w1, #0x1
    80d8:	39000281 	strb	w1, [x20]
    80dc:	d503201f 	nop
    80e0:	f9400a74 	ldr	x20, [x19, #16]
    80e4:	aa1303e0 	mov	x0, x19
    80e8:	97fff5b3 	bl	57b4 <fwp_rc_free_arr>
    80ec:	911742c0 	add	x0, x22, #0x5d0
    80f0:	f949d801 	ldr	x1, [x0, #5040]
    80f4:	f949ec00 	ldr	x0, [x0, #5080]
    80f8:	cb010281 	sub	x1, x20, x1
    80fc:	eb00403f 	cmp	x1, x0, lsl #16
    8100:	54fff982 	b.cs	8030 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8104:	aa1403f3 	mov	x19, x20
    8108:	17ffffaf 	b	7fc4 <fwp_drop2+0x30>
    810c:	97fff5aa 	bl	57b4 <fwp_rc_free_arr>
    8110:	17fffff4 	b	80e0 <fwp_drop2+0x14c>
    8114:	72003c3f 	tst	w1, #0xffff
    8118:	54fffe41 	b.ne	80e0 <fwp_drop2+0x14c>  // b.any
    811c:	17ffffe8 	b	80bc <fwp_drop2+0x128>
    8120:	ca544681 	eor	x1, x20, x20, lsr #17
    8124:	911742c0 	add	x0, x22, #0x5d0
    8128:	ca412421 	eor	x1, x1, x1, lsr #9
    812c:	8b210c01 	add	x1, x0, w1, uxtb #3
    8130:	f94a2420 	ldr	x0, [x1, #5192]
    8134:	b5000080 	cbnz	x0, 8144 <fwp_drop2+0x1b0>
    8138:	14000010 	b	8178 <fwp_drop2+0x1e4>
    813c:	f9400800 	ldr	x0, [x0, #16]
    8140:	b40001c0 	cbz	x0, 8178 <fwp_drop2+0x1e4>
    8144:	f9400001 	ldr	x1, [x0]
    8148:	eb14003f 	cmp	x1, x20
    814c:	54ffff81 	b.ne	813c <fwp_drop2+0x1a8>  // b.any
    8150:	f9400401 	ldr	x1, [x0, #8]
    8154:	d1000421 	sub	x1, x1, #0x1
    8158:	f9000401 	str	x1, [x0, #8]
    815c:	f103f83f 	cmp	x1, #0xfe
    8160:	54fff681 	b.ne	8030 <fwp_drop2+0x9c>  // b.any
    8164:	aa1403e0 	mov	x0, x20
    8168:	97fff1a2 	bl	47f0 <fwp_rc_forget_slot>
    816c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8170:	39000280 	strb	w0, [x20]
    8174:	17ffffaf 	b	8030 <fwp_drop2+0x9c>
    8178:	f0000000 	adrp	x0, b000 <__divti3+0x1a0>
    817c:	91238000 	add	x0, x0, #0x8e0
    8180:	97ffeda0 	bl	3800 <fwp_trap>
    8184:	ca544680 	eor	x0, x20, x20, lsr #17
    8188:	911742c1 	add	x1, x22, #0x5d0
    818c:	ca402400 	eor	x0, x0, x0, lsr #9
    8190:	8b200c20 	add	x0, x1, w0, uxtb #3
    8194:	f94a2400 	ldr	x0, [x0, #5192]
    8198:	b5000080 	cbnz	x0, 81a8 <fwp_drop2+0x214>
    819c:	17fffff7 	b	8178 <fwp_drop2+0x1e4>
    81a0:	f9400800 	ldr	x0, [x0, #16]
    81a4:	b4fffea0 	cbz	x0, 8178 <fwp_drop2+0x1e4>
    81a8:	f9400001 	ldr	x1, [x0]
    81ac:	eb14003f 	cmp	x1, x20
    81b0:	54ffff81 	b.ne	81a0 <fwp_drop2+0x20c>  // b.any
    81b4:	f9400401 	ldr	x1, [x0, #8]
    81b8:	d1000421 	sub	x1, x1, #0x1
    81bc:	f9000401 	str	x1, [x0, #8]
    81c0:	f103f83f 	cmp	x1, #0xfe
    81c4:	54fff8e1 	b.ne	80e0 <fwp_drop2+0x14c>  // b.any
    81c8:	aa1403e0 	mov	x0, x20
    81cc:	97fff189 	bl	47f0 <fwp_rc_forget_slot>
    81d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    81d4:	39000280 	strb	w0, [x20]
    81d8:	17ffffc2 	b	80e0 <fwp_drop2+0x14c>
    81dc:	d503201f 	nop

00000000000081e0 <fwp_arg_drop23>:
    81e0:	7100003f 	cmp	w1, #0x0
    81e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    81e8:	54000041 	b.ne	81f0 <fwp_arg_drop23+0x10>  // b.any
    81ec:	d65f03c0 	ret
    81f0:	f9400000 	ldr	x0, [x0]
    81f4:	17ffff68 	b	7f94 <fwp_drop2>
    81f8:	d503201f 	nop
    81fc:	d503201f 	nop

0000000000008200 <fwp_caps23>:
    8200:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8204:	910003fd 	mov	x29, sp
    8208:	f9000bf3 	str	x19, [sp, #16]
    820c:	aa0003f3 	mov	x19, x0
    8210:	b9400400 	ldr	w0, [x0, #4]
    8214:	340004a0 	cbz	w0, 82a8 <fwp_caps23+0xa8>
    8218:	f9400660 	ldr	x0, [x19, #8]
    821c:	350004e1 	cbnz	w1, 82b8 <fwp_caps23+0xb8>
    8220:	97ffff5d 	bl	7f94 <fwp_drop2>
    8224:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8228:	91174042 	add	x2, x2, #0x5d0
    822c:	f949d840 	ldr	x0, [x2, #5040]
    8230:	f949ec41 	ldr	x1, [x2, #5080]
    8234:	cb000260 	sub	x0, x19, x0
    8238:	eb01401f 	cmp	x0, x1, lsl #16
    823c:	54000382 	b.cs	82ac <fwp_caps23+0xac>  // b.hs, b.nlast
    8240:	d350fc01 	lsr	x1, x0, #16
    8244:	f949fc44 	ldr	x4, [x2, #5112]
    8248:	8b010821 	add	x1, x1, x1, lsl #2
    824c:	d37df021 	lsl	x1, x1, #3
    8250:	8b010083 	add	x3, x4, x1
    8254:	f9401062 	ldr	x2, [x3, #32]
    8258:	b40002a2 	cbz	x2, 82ac <fwp_caps23+0xac>
    825c:	38616881 	ldrb	w1, [x4, x1]
    8260:	7100083f 	cmp	w1, #0x2
    8264:	540006c0 	b.eq	833c <fwp_caps23+0x13c>  // b.none
    8268:	7100043f 	cmp	w1, #0x1
    826c:	54000201 	b.ne	82ac <fwp_caps23+0xac>  // b.any
    8270:	29430464 	ldp	w4, w1, [x3, #24]
    8274:	92403c00 	and	x0, x0, #0xffff
    8278:	9b047c00 	mul	x0, x0, x4
    827c:	d360fc00 	lsr	x0, x0, #32
    8280:	eb01001f 	cmp	x0, x1
    8284:	54000142 	b.cs	82ac <fwp_caps23+0xac>  // b.hs, b.nlast
    8288:	8b000042 	add	x2, x2, x0
    828c:	39400040 	ldrb	w0, [x2]
    8290:	7100041f 	cmp	w0, #0x1
    8294:	540000c1 	b.ne	82ac <fwp_caps23+0xac>  // b.any
    8298:	aa1303e0 	mov	x0, x19
    829c:	f9400bf3 	ldr	x19, [sp, #16]
    82a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    82a4:	17fff1f3 	b	4a70 <fwp_mem_free>
    82a8:	34fffbe1 	cbz	w1, 8224 <fwp_caps23+0x24>
    82ac:	f9400bf3 	ldr	x19, [sp, #16]
    82b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    82b4:	d65f03c0 	ret
    82b8:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    82bc:	91174042 	add	x2, x2, #0x5d0
    82c0:	f949d843 	ldr	x3, [x2, #5040]
    82c4:	f949ec41 	ldr	x1, [x2, #5080]
    82c8:	cb030000 	sub	x0, x0, x3
    82cc:	eb01401f 	cmp	x0, x1, lsl #16
    82d0:	54fffee2 	b.cs	82ac <fwp_caps23+0xac>  // b.hs, b.nlast
    82d4:	d350fc01 	lsr	x1, x0, #16
    82d8:	f949fc44 	ldr	x4, [x2, #5112]
    82dc:	8b010821 	add	x1, x1, x1, lsl #2
    82e0:	d37df021 	lsl	x1, x1, #3
    82e4:	8b010083 	add	x3, x4, x1
    82e8:	f9401062 	ldr	x2, [x3, #32]
    82ec:	b4fffe02 	cbz	x2, 82ac <fwp_caps23+0xac>
    82f0:	38616881 	ldrb	w1, [x4, x1]
    82f4:	7100083f 	cmp	w1, #0x2
    82f8:	54000280 	b.eq	8348 <fwp_caps23+0x148>  // b.none
    82fc:	7100043f 	cmp	w1, #0x1
    8300:	54fffd61 	b.ne	82ac <fwp_caps23+0xac>  // b.any
    8304:	92403c01 	and	x1, x0, #0xffff
    8308:	29430064 	ldp	w4, w0, [x3, #24]
    830c:	9b047c21 	mul	x1, x1, x4
    8310:	d360fc21 	lsr	x1, x1, #32
    8314:	eb00003f 	cmp	x1, x0
    8318:	54fffca2 	b.cs	82ac <fwp_caps23+0xac>  // b.hs, b.nlast
    831c:	8b010042 	add	x2, x2, x1
    8320:	39400040 	ldrb	w0, [x2]
    8324:	34fffc40 	cbz	w0, 82ac <fwp_caps23+0xac>
    8328:	7103f41f 	cmp	w0, #0xfd
    832c:	54000148 	b.hi	8354 <fwp_caps23+0x154>  // b.pmore
    8330:	11000400 	add	w0, w0, #0x1
    8334:	39000040 	strb	w0, [x2]
    8338:	17ffffdd 	b	82ac <fwp_caps23+0xac>
    833c:	72003c1f 	tst	w0, #0xffff
    8340:	54fffb61 	b.ne	82ac <fwp_caps23+0xac>  // b.any
    8344:	17ffffd2 	b	828c <fwp_caps23+0x8c>
    8348:	72003c1f 	tst	w0, #0xffff
    834c:	54fffb01 	b.ne	82ac <fwp_caps23+0xac>  // b.any
    8350:	17fffff4 	b	8320 <fwp_caps23+0x120>
    8354:	f9400bf3 	ldr	x19, [sp, #16]
    8358:	aa0203e0 	mov	x0, x2
    835c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8360:	17fff0dd 	b	46d4 <fwp_rc_wide_dup>

0000000000008364 <f23>:
    8364:	d10203ff 	sub	sp, sp, #0x80
    8368:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    836c:	f947f421 	ldr	x1, [x1, #4072]
    8370:	a9027bfd 	stp	x29, x30, [sp, #32]
    8374:	910083fd 	add	x29, sp, #0x20
    8378:	a9045bf5 	stp	x21, x22, [sp, #64]
    837c:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    8380:	911742c3 	add	x3, x22, #0x5d0
    8384:	a90353f3 	stp	x19, x20, [sp, #48]
    8388:	a90563f7 	stp	x23, x24, [sp, #80]
    838c:	aa0003f8 	mov	x24, x0
    8390:	a9066bf9 	stp	x25, x26, [sp, #96]
    8394:	f949ec62 	ldr	x2, [x3, #5080]
    8398:	f9400024 	ldr	x4, [x1]
    839c:	f9000fe4 	str	x4, [sp, #24]
    83a0:	d2800004 	mov	x4, #0x0                   	// #0
    83a4:	f949d861 	ldr	x1, [x3, #5040]
    83a8:	d370bc42 	lsl	x2, x2, #16
    83ac:	b40017c0 	cbz	x0, 86a4 <f23+0x340>
    83b0:	f9400819 	ldr	x25, [x0, #16]
    83b4:	cb010321 	sub	x1, x25, x1
    83b8:	eb02003f 	cmp	x1, x2
    83bc:	54000362 	b.cs	8428 <f23+0xc4>  // b.hs, b.nlast
    83c0:	f949fc60 	ldr	x0, [x3, #5112]
    83c4:	d350fc22 	lsr	x2, x1, #16
    83c8:	8b020842 	add	x2, x2, x2, lsl #2
    83cc:	8b020c02 	add	x2, x0, x2, lsl #3
    83d0:	f9401040 	ldr	x0, [x2, #32]
    83d4:	b40002a0 	cbz	x0, 8428 <f23+0xc4>
    83d8:	39400043 	ldrb	w3, [x2]
    83dc:	7100087f 	cmp	w3, #0x2
    83e0:	540015c0 	b.eq	8698 <f23+0x334>  // b.none
    83e4:	7100047f 	cmp	w3, #0x1
    83e8:	540001c1 	b.ne	8420 <f23+0xbc>  // b.any
    83ec:	29430843 	ldp	w3, w2, [x2, #24]
    83f0:	92403c21 	and	x1, x1, #0xffff
    83f4:	9b037c21 	mul	x1, x1, x3
    83f8:	d360fc21 	lsr	x1, x1, #32
    83fc:	eb02003f 	cmp	x1, x2
    8400:	54000102 	b.cs	8420 <f23+0xbc>  // b.hs, b.nlast
    8404:	8b010000 	add	x0, x0, x1
    8408:	39400001 	ldrb	w1, [x0]
    840c:	340000a1 	cbz	w1, 8420 <f23+0xbc>
    8410:	7103f43f 	cmp	w1, #0xfd
    8414:	54001868 	b.hi	8720 <f23+0x3bc>  // b.pmore
    8418:	11000421 	add	w1, w1, #0x1
    841c:	39000001 	strb	w1, [x0]
    8420:	d2800000 	mov	x0, #0x0                   	// #0
    8424:	b40000d8 	cbz	x24, 843c <f23+0xd8>
    8428:	aa1803e1 	mov	x1, x24
    842c:	d2800000 	mov	x0, #0x0                   	// #0
    8430:	f9400821 	ldr	x1, [x1, #16]
    8434:	91000400 	add	x0, x0, #0x1
    8438:	b5ffffc1 	cbnz	x1, 8430 <f23+0xcc>
    843c:	b40013b9 	cbz	x25, 86b0 <f23+0x34c>
    8440:	aa1903e1 	mov	x1, x25
    8444:	d2800002 	mov	x2, #0x0                   	// #0
    8448:	f9400821 	ldr	x1, [x1, #16]
    844c:	91000442 	add	x2, x2, #0x1
    8450:	b5ffffc1 	cbnz	x1, 8448 <f23+0xe4>
    8454:	eb00005f 	cmp	x2, x0
    8458:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    845c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    8460:	eb01035f 	cmp	x26, x1
    8464:	54001668 	b.hi	8730 <f23+0x3cc>  // b.pmore
    8468:	d37ffb53 	lsl	x19, x26, #1
    846c:	52800041 	mov	w1, #0x2                   	// #2
    8470:	91000660 	add	x0, x19, #0x1
    8474:	d37df000 	lsl	x0, x0, #3
    8478:	97fff29e 	bl	4ef0 <fwp_heap_alloc>
    847c:	aa0003f7 	mov	x23, x0
    8480:	911742c1 	add	x1, x22, #0x5d0
    8484:	aa0103e0 	mov	x0, x1
    8488:	f90002f3 	str	x19, [x23]
    848c:	f949d821 	ldr	x1, [x1, #5040]
    8490:	f949ec00 	ldr	x0, [x0, #5080]
    8494:	cb0102e1 	sub	x1, x23, x1
    8498:	eb00403f 	cmp	x1, x0, lsl #16
    849c:	54000342 	b.cs	8504 <f23+0x1a0>  // b.hs, b.nlast
    84a0:	911742c2 	add	x2, x22, #0x5d0
    84a4:	d350fc20 	lsr	x0, x1, #16
    84a8:	8b000800 	add	x0, x0, x0, lsl #2
    84ac:	f949fc43 	ldr	x3, [x2, #5112]
    84b0:	d37df002 	lsl	x2, x0, #3
    84b4:	8b020060 	add	x0, x3, x2
    84b8:	f9401013 	ldr	x19, [x0, #32]
    84bc:	b4000253 	cbz	x19, 8504 <f23+0x1a0>
    84c0:	38626862 	ldrb	w2, [x3, x2]
    84c4:	7100085f 	cmp	w2, #0x2
    84c8:	54000e20 	b.eq	868c <f23+0x328>  // b.none
    84cc:	7100045f 	cmp	w2, #0x1
    84d0:	540001a1 	b.ne	8504 <f23+0x1a0>  // b.any
    84d4:	29430002 	ldp	w2, w0, [x0, #24]
    84d8:	92403c21 	and	x1, x1, #0xffff
    84dc:	9b027c21 	mul	x1, x1, x2
    84e0:	d360fc21 	lsr	x1, x1, #32
    84e4:	eb00003f 	cmp	x1, x0
    84e8:	540000e2 	b.cs	8504 <f23+0x1a0>  // b.hs, b.nlast
    84ec:	8b010273 	add	x19, x19, x1
    84f0:	39400260 	ldrb	w0, [x19]
    84f4:	7103fc1f 	cmp	w0, #0xff
    84f8:	54000f80 	b.eq	86e8 <f23+0x384>  // b.none
    84fc:	52800020 	mov	w0, #0x1                   	// #1
    8500:	39000260 	strb	w0, [x19]
    8504:	b400025a 	cbz	x26, 854c <f23+0x1e8>
    8508:	8b1a12fa 	add	x26, x23, x26, lsl #4
    850c:	aa1703f3 	mov	x19, x23
    8510:	aa1803f5 	mov	x21, x24
    8514:	aa1903f4 	mov	x20, x25
    8518:	f9400683 	ldr	x3, [x20, #8]
    851c:	f94006a2 	ldr	x2, [x21, #8]
    8520:	f9400861 	ldr	x1, [x3, #16]
    8524:	f9400840 	ldr	x0, [x2, #16]
    8528:	fd400461 	ldr	d1, [x3, #8]
    852c:	fd400440 	ldr	d0, [x2, #8]
    8530:	97fff3f0 	bl	54f0 <w107>
    8534:	f9000660 	str	x0, [x19, #8]
    8538:	f8010e61 	str	x1, [x19, #16]!
    853c:	f9400a94 	ldr	x20, [x20, #16]
    8540:	f9400ab5 	ldr	x21, [x21, #16]
    8544:	eb13035f 	cmp	x26, x19
    8548:	54fffe81 	b.ne	8518 <f23+0x1b4>  // b.any
    854c:	aa1903e0 	mov	x0, x25
    8550:	97fffe91 	bl	7f94 <fwp_drop2>
    8554:	aa1803e0 	mov	x0, x24
    8558:	97fffe8f 	bl	7f94 <fwp_drop2>
    855c:	f94002f5 	ldr	x21, [x23]
    8560:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8564:	b4000275 	cbz	x21, 85b0 <f23+0x24c>
    8568:	fd003be8 	str	d8, [sp, #112]
    856c:	2f00e408 	movi	d8, #0x0
    8570:	910022f9 	add	x25, x23, #0x8
    8574:	910042f8 	add	x24, x23, #0x10
    8578:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    857c:	d2800013 	mov	x19, #0x0                   	// #0
    8580:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8584:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8588:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    858c:	aa0303e1 	mov	x1, x3
    8590:	1e602908 	fadd	d8, d8, d0
    8594:	91000a73 	add	x19, x19, #0x2
    8598:	97fff323 	bl	5224 <fwp_p_ad_push>
    859c:	aa0003f4 	mov	x20, x0
    85a0:	eb1302bf 	cmp	x21, x19
    85a4:	54fffee8 	b.hi	8580 <f23+0x21c>  // b.pmore
    85a8:	9e660115 	fmov	x21, d8
    85ac:	fd403be8 	ldr	d8, [sp, #112]
    85b0:	911742d6 	add	x22, x22, #0x5d0
    85b4:	aa1703e0 	mov	x0, x23
    85b8:	97fff896 	bl	6810 <fwp_drop4>
    85bc:	a900d3f5 	stp	x21, x20, [sp, #8]
    85c0:	910023e1 	add	x1, sp, #0x8
    85c4:	52800000 	mov	w0, #0x0                   	// #0
    85c8:	97fff40e 	bl	5600 <fwp_data.part.0.constprop.0>
    85cc:	f949dac1 	ldr	x1, [x22, #5040]
    85d0:	aa0003f3 	mov	x19, x0
    85d4:	f949eec0 	ldr	x0, [x22, #5080]
    85d8:	cb010261 	sub	x1, x19, x1
    85dc:	eb00403f 	cmp	x1, x0, lsl #16
    85e0:	54000322 	b.cs	8644 <f23+0x2e0>  // b.hs, b.nlast
    85e4:	d350fc22 	lsr	x2, x1, #16
    85e8:	f949fec3 	ldr	x3, [x22, #5112]
    85ec:	8b020842 	add	x2, x2, x2, lsl #2
    85f0:	d37df042 	lsl	x2, x2, #3
    85f4:	8b020060 	add	x0, x3, x2
    85f8:	f9401014 	ldr	x20, [x0, #32]
    85fc:	b4000254 	cbz	x20, 8644 <f23+0x2e0>
    8600:	38626862 	ldrb	w2, [x3, x2]
    8604:	7100085f 	cmp	w2, #0x2
    8608:	540003c0 	b.eq	8680 <f23+0x31c>  // b.none
    860c:	7100045f 	cmp	w2, #0x1
    8610:	540001a1 	b.ne	8644 <f23+0x2e0>  // b.any
    8614:	29430002 	ldp	w2, w0, [x0, #24]
    8618:	92403c21 	and	x1, x1, #0xffff
    861c:	9b027c21 	mul	x1, x1, x2
    8620:	d360fc21 	lsr	x1, x1, #32
    8624:	eb00003f 	cmp	x1, x0
    8628:	540000e2 	b.cs	8644 <f23+0x2e0>  // b.hs, b.nlast
    862c:	8b010294 	add	x20, x20, x1
    8630:	39400280 	ldrb	w0, [x20]
    8634:	7103fc1f 	cmp	w0, #0xff
    8638:	540005e0 	b.eq	86f4 <f23+0x390>  // b.none
    863c:	52800020 	mov	w0, #0x1                   	// #1
    8640:	39000280 	strb	w0, [x20]
    8644:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8648:	f947f400 	ldr	x0, [x0, #4072]
    864c:	f9400fe2 	ldr	x2, [sp, #24]
    8650:	f9400001 	ldr	x1, [x0]
    8654:	eb010042 	subs	x2, x2, x1
    8658:	d2800001 	mov	x1, #0x0                   	// #0
    865c:	54000721 	b.ne	8740 <f23+0x3dc>  // b.any
    8660:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8664:	aa1303e0 	mov	x0, x19
    8668:	a94353f3 	ldp	x19, x20, [sp, #48]
    866c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8670:	a94563f7 	ldp	x23, x24, [sp, #80]
    8674:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8678:	910203ff 	add	sp, sp, #0x80
    867c:	d65f03c0 	ret
    8680:	72003c3f 	tst	w1, #0xffff
    8684:	54fffe01 	b.ne	8644 <f23+0x2e0>  // b.any
    8688:	17ffffea 	b	8630 <f23+0x2cc>
    868c:	72003c3f 	tst	w1, #0xffff
    8690:	54fff3a1 	b.ne	8504 <f23+0x1a0>  // b.any
    8694:	17ffff97 	b	84f0 <f23+0x18c>
    8698:	72003c3f 	tst	w1, #0xffff
    869c:	54ffec21 	b.ne	8420 <f23+0xbc>  // b.any
    86a0:	17ffff5a 	b	8408 <f23+0xa4>
    86a4:	cb0103e1 	neg	x1, x1
    86a8:	eb02003f 	cmp	x1, x2
    86ac:	540002a3 	b.cc	8700 <f23+0x39c>  // b.lo, b.ul, b.last
    86b0:	52800041 	mov	w1, #0x2                   	// #2
    86b4:	d2800100 	mov	x0, #0x8                   	// #8
    86b8:	97fff20e 	bl	4ef0 <fwp_heap_alloc>
    86bc:	aa0003f7 	mov	x23, x0
    86c0:	911742c0 	add	x0, x22, #0x5d0
    86c4:	f90002ff 	str	xzr, [x23]
    86c8:	f949d801 	ldr	x1, [x0, #5040]
    86cc:	f949ec00 	ldr	x0, [x0, #5080]
    86d0:	cb0102e1 	sub	x1, x23, x1
    86d4:	eb00403f 	cmp	x1, x0, lsl #16
    86d8:	54000282 	b.cs	8728 <f23+0x3c4>  // b.hs, b.nlast
    86dc:	d280001a 	mov	x26, #0x0                   	// #0
    86e0:	d2800019 	mov	x25, #0x0                   	// #0
    86e4:	17ffff6f 	b	84a0 <f23+0x13c>
    86e8:	aa1303e0 	mov	x0, x19
    86ec:	97fff041 	bl	47f0 <fwp_rc_forget_slot>
    86f0:	17ffff83 	b	84fc <f23+0x198>
    86f4:	aa1403e0 	mov	x0, x20
    86f8:	97fff03e 	bl	47f0 <fwp_rc_forget_slot>
    86fc:	17ffffd0 	b	863c <f23+0x2d8>
    8700:	f949fc62 	ldr	x2, [x3, #5112]
    8704:	d350fc20 	lsr	x0, x1, #16
    8708:	8b000800 	add	x0, x0, x0, lsl #2
    870c:	8b000c42 	add	x2, x2, x0, lsl #3
    8710:	f9401040 	ldr	x0, [x2, #32]
    8714:	b4fffce0 	cbz	x0, 86b0 <f23+0x34c>
    8718:	d2800019 	mov	x25, #0x0                   	// #0
    871c:	17ffff2f 	b	83d8 <f23+0x74>
    8720:	97ffefed 	bl	46d4 <fwp_rc_wide_dup>
    8724:	17ffff3f 	b	8420 <f23+0xbc>
    8728:	d2800019 	mov	x25, #0x0                   	// #0
    872c:	17ffff88 	b	854c <f23+0x1e8>
    8730:	f0000000 	adrp	x0, b000 <__divti3+0x1a0>
    8734:	912a8000 	add	x0, x0, #0xaa0
    8738:	fd003be8 	str	d8, [sp, #112]
    873c:	97ffec31 	bl	3800 <fwp_trap>
    8740:	fd003be8 	str	d8, [sp, #112]
    8744:	97ffe84f 	bl	2880 <__stack_chk_fail@plt>
    8748:	d503201f 	nop
    874c:	d503201f 	nop

0000000000008750 <fwp_owned_entry23>:
    8750:	f9400000 	ldr	x0, [x0]
    8754:	17ffff04 	b	8364 <f23>
    8758:	d503201f 	nop
    875c:	d503201f 	nop

0000000000008760 <e23>:
    8760:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8764:	910003fd 	mov	x29, sp
    8768:	f9000bf3 	str	x19, [sp, #16]
    876c:	f9400013 	ldr	x19, [x0]
    8770:	aa1303e0 	mov	x0, x19
    8774:	97fff3eb 	bl	5720 <fwp_rc_share>
    8778:	aa1303e0 	mov	x0, x19
    877c:	97fffefa 	bl	8364 <f23>
    8780:	aa0003f3 	mov	x19, x0
    8784:	97fff3e7 	bl	5720 <fwp_rc_share>
    8788:	aa1303e0 	mov	x0, x19
    878c:	f9400bf3 	ldr	x19, [sp, #16]
    8790:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8794:	d65f03c0 	ret
    8798:	d503201f 	nop
    879c:	d503201f 	nop

00000000000087a0 <fwp_write>:
    87a0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    87a4:	910003fd 	mov	x29, sp
    87a8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    87ac:	f947f484 	ldr	x4, [x4, #4072]
    87b0:	a90153f3 	stp	x19, x20, [sp, #16]
    87b4:	d10943ff 	sub	sp, sp, #0x250
    87b8:	b9400045 	ldr	w5, [x2]
    87bc:	aa0003f4 	mov	x20, x0
    87c0:	f9400080 	ldr	x0, [x4]
    87c4:	f90127e0 	str	x0, [sp, #584]
    87c8:	d2800000 	mov	x0, #0x0                   	// #0
    87cc:	710064bf 	cmp	w5, #0x19
    87d0:	54000408 	b.hi	8850 <fwp_write+0xb0>  // b.pmore
    87d4:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    87d8:	aa0103f3 	mov	x19, x1
    87dc:	910b4000 	add	x0, x0, #0x2d0
    87e0:	f9013bf5 	str	x21, [sp, #624]
    87e4:	f9013ff6 	str	x22, [sp, #632]
    87e8:	f90153fb 	str	x27, [sp, #672]
    87ec:	f90157fc 	str	x28, [sp, #680]
    87f0:	aa0203fc 	mov	x28, x2
    87f4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    87f8:	10000061 	adr	x1, 8804 <fwp_write+0x64>
    87fc:	8b20a820 	add	x0, x1, w0, sxth #2
    8800:	d61f0000 	br	x0
    8804:	910123e0 	add	x0, sp, #0x48
    8808:	aa1303e5 	mov	x5, x19
    880c:	f0000004 	adrp	x4, b000 <__divti3+0x1a0>
    8810:	aa0003f3 	mov	x19, x0
    8814:	912c8084 	add	x4, x4, #0xb20
    8818:	d2804003 	mov	x3, #0x200                 	// #512
    881c:	aa0303e1 	mov	x1, x3
    8820:	52800042 	mov	w2, #0x2                   	// #2
    8824:	97ffe7f3 	bl	27f0 <__snprintf_chk@plt>
    8828:	aa1303e0 	mov	x0, x19
    882c:	97ffe7b9 	bl	2710 <strlen@plt>
    8830:	aa1303e1 	mov	x1, x19
    8834:	aa0003e2 	mov	x2, x0
    8838:	aa1403e0 	mov	x0, x20
    883c:	97ffeb55 	bl	3590 <buf_put>
    8840:	f9413bf5 	ldr	x21, [sp, #624]
    8844:	f9413ff6 	ldr	x22, [sp, #632]
    8848:	f94153fb 	ldr	x27, [sp, #672]
    884c:	f94157fc 	ldr	x28, [sp, #680]
    8850:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8854:	f947f400 	ldr	x0, [x0, #4072]
    8858:	f94127e2 	ldr	x2, [sp, #584]
    885c:	f9400001 	ldr	x1, [x0]
    8860:	eb010042 	subs	x2, x2, x1
    8864:	d2800001 	mov	x1, #0x0                   	// #0
    8868:	540077c1 	b.ne	9760 <fwp_write+0xfc0>  // b.any
    886c:	910943ff 	add	sp, sp, #0x250
    8870:	a94153f3 	ldp	x19, x20, [sp, #16]
    8874:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8878:	d65f03c0 	ret
    887c:	910123e0 	add	x0, sp, #0x48
    8880:	aa1303e5 	mov	x5, x19
    8884:	f0000004 	adrp	x4, b000 <__divti3+0x1a0>
    8888:	aa0003f3 	mov	x19, x0
    888c:	912c6084 	add	x4, x4, #0xb18
    8890:	d2804003 	mov	x3, #0x200                 	// #512
    8894:	17ffffe2 	b	881c <fwp_write+0x7c>
    8898:	71004cbf 	cmp	w5, #0x13
    889c:	f0000000 	adrp	x0, b000 <__divti3+0x1a0>
    88a0:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    88a4:	912c2000 	add	x0, x0, #0xb08
    88a8:	912c4021 	add	x1, x1, #0xb10
    88ac:	d2800082 	mov	x2, #0x4                   	// #4
    88b0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    88b4:	aa1403e0 	mov	x0, x20
    88b8:	f90143f7 	str	x23, [sp, #640]
    88bc:	d2800016 	mov	x22, #0x0                   	// #0
    88c0:	f90147f8 	str	x24, [sp, #648]
    88c4:	97ffeb33 	bl	3590 <buf_put>
    88c8:	f9400260 	ldr	x0, [x19]
    88cc:	f0000017 	adrp	x23, b000 <__divti3+0x1a0>
    88d0:	d2800015 	mov	x21, #0x0                   	// #0
    88d4:	912e42f7 	add	x23, x23, #0xb90
    88d8:	b40047a0 	cbz	x0, 91cc <fwp_write+0xa2c>
    88dc:	b9400380 	ldr	w0, [x28]
    88e0:	52800003 	mov	w3, #0x0                   	// #0
    88e4:	f9401f82 	ldr	x2, [x28, #56]
    88e8:	71004c1f 	cmp	w0, #0x13
    88ec:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    88f0:	aa1403e0 	mov	x0, x20
    88f4:	8b010e61 	add	x1, x19, x1, lsl #3
    88f8:	f9400421 	ldr	x1, [x1, #8]
    88fc:	97ffffa9 	bl	87a0 <fwp_write>
    8900:	b9400380 	ldr	w0, [x28]
    8904:	7100481f 	cmp	w0, #0x12
    8908:	54004b40 	b.eq	9270 <fwp_write+0xad0>  // b.none
    890c:	f9400260 	ldr	x0, [x19]
    8910:	910006b5 	add	x21, x21, #0x1
    8914:	91000ad6 	add	x22, x22, #0x2
    8918:	eb15001f 	cmp	x0, x21
    891c:	54004589 	b.ls	91cc <fwp_write+0xa2c>  // b.plast
    8920:	aa1703e1 	mov	x1, x23
    8924:	aa1403e0 	mov	x0, x20
    8928:	d2800042 	mov	x2, #0x2                   	// #2
    892c:	97ffeb19 	bl	3590 <buf_put>
    8930:	17ffffeb 	b	88dc <fwp_write+0x13c>
    8934:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    8938:	912d2021 	add	x1, x1, #0xb48
    893c:	d28000c2 	mov	x2, #0x6                   	// #6
    8940:	aa1403e0 	mov	x0, x20
    8944:	91004273 	add	x19, x19, #0x10
    8948:	97ffeb12 	bl	3590 <buf_put>
    894c:	aa1303e0 	mov	x0, x19
    8950:	97ffe770 	bl	2710 <strlen@plt>
    8954:	aa1303e1 	mov	x1, x19
    8958:	aa0003e2 	mov	x2, x0
    895c:	aa1403e0 	mov	x0, x20
    8960:	97ffeb0c 	bl	3590 <buf_put>
    8964:	528007c3 	mov	w3, #0x3e                  	// #62
    8968:	aa1403e0 	mov	x0, x20
    896c:	91001fe1 	add	x1, sp, #0x7
    8970:	d2800022 	mov	x2, #0x1                   	// #1
    8974:	39001fe3 	strb	w3, [sp, #7]
    8978:	17ffffb1 	b	883c <fwp_write+0x9c>
    897c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8980:	f947f400 	ldr	x0, [x0, #4072]
    8984:	f94127e2 	ldr	x2, [sp, #584]
    8988:	f9400001 	ldr	x1, [x0]
    898c:	eb010042 	subs	x2, x2, x1
    8990:	d2800001 	mov	x1, #0x0                   	// #0
    8994:	540034e1 	b.ne	9030 <fwp_write+0x890>  // b.any
    8998:	f9413bf5 	ldr	x21, [sp, #624]
    899c:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    89a0:	f9413ff6 	ldr	x22, [sp, #632]
    89a4:	aa1403e0 	mov	x0, x20
    89a8:	912ca021 	add	x1, x1, #0xb28
    89ac:	d2800142 	mov	x2, #0xa                   	// #10
    89b0:	f94153fb 	ldr	x27, [sp, #672]
    89b4:	f94157fc 	ldr	x28, [sp, #680]
    89b8:	910943ff 	add	sp, sp, #0x250
    89bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    89c0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89c4:	17ffeaf3 	b	3590 <buf_put>
    89c8:	f9400456 	ldr	x22, [x2, #8]
    89cc:	f90143f7 	str	x23, [sp, #640]
    89d0:	f90147f8 	str	x24, [sp, #648]
    89d4:	b4005b16 	cbz	x22, 9534 <fwp_write+0xd94>
    89d8:	aa1603e0 	mov	x0, x22
    89dc:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    89e0:	912ea021 	add	x1, x1, #0xba8
    89e4:	97ffe7c7 	bl	2900 <strcmp@plt>
    89e8:	2a0003f5 	mov	w21, w0
    89ec:	34005fe0 	cbz	w0, 95e8 <fwp_write+0xe48>
    89f0:	aa1603e0 	mov	x0, x22
    89f4:	97ffe747 	bl	2710 <strlen@plt>
    89f8:	aa1603e1 	mov	x1, x22
    89fc:	aa0003e2 	mov	x2, x0
    8a00:	aa1403e0 	mov	x0, x20
    8a04:	97ffeae3 	bl	3590 <buf_put>
    8a08:	52800403 	mov	w3, #0x20                  	// #32
    8a0c:	91001ff5 	add	x21, sp, #0x7
    8a10:	aa1503e1 	mov	x1, x21
    8a14:	aa1403e0 	mov	x0, x20
    8a18:	d2800022 	mov	x2, #0x1                   	// #1
    8a1c:	39001fe3 	strb	w3, [sp, #7]
    8a20:	97ffeadc 	bl	3590 <buf_put>
    8a24:	52800f63 	mov	w3, #0x7b                  	// #123
    8a28:	aa1403e0 	mov	x0, x20
    8a2c:	aa1503e1 	mov	x1, x21
    8a30:	d2800022 	mov	x2, #0x1                   	// #1
    8a34:	39001fe3 	strb	w3, [sp, #7]
    8a38:	97ffead6 	bl	3590 <buf_put>
    8a3c:	b9401380 	ldr	w0, [x28, #16]
    8a40:	52800018 	mov	w24, #0x0                   	// #0
    8a44:	7100001f 	cmp	w0, #0x0
    8a48:	54003aad 	b.le	919c <fwp_write+0x9fc>
    8a4c:	f9014bf9 	str	x25, [sp, #656]
    8a50:	f0000019 	adrp	x25, b000 <__divti3+0x1a0>
    8a54:	912f4339 	add	x25, x25, #0xbd0
    8a58:	f9014ffa 	str	x26, [sp, #664]
    8a5c:	f000001a 	adrp	x26, b000 <__divti3+0x1a0>
    8a60:	912e435a 	add	x26, x26, #0xb90
    8a64:	91002276 	add	x22, x19, #0x8
    8a68:	d2800013 	mov	x19, #0x0                   	// #0
    8a6c:	b5003e93 	cbnz	x19, 923c <fwp_write+0xa9c>
    8a70:	d37df277 	lsl	x23, x19, #3
    8a74:	34003cb8 	cbz	w24, 9208 <fwp_write+0xa68>
    8a78:	f9401382 	ldr	x2, [x28, #32]
    8a7c:	aa1403e0 	mov	x0, x20
    8a80:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8a84:	52800003 	mov	w3, #0x0                   	// #0
    8a88:	f8776842 	ldr	x2, [x2, x23]
    8a8c:	91000673 	add	x19, x19, #0x1
    8a90:	97ffff44 	bl	87a0 <fwp_write>
    8a94:	b9401380 	ldr	w0, [x28, #16]
    8a98:	6b13001f 	cmp	w0, w19
    8a9c:	54fffe8c 	b.gt	8a6c <fwp_write+0x2cc>
    8aa0:	f9414bf9 	ldr	x25, [sp, #656]
    8aa4:	f9414ffa 	ldr	x26, [sp, #664]
    8aa8:	340037b8 	cbz	w24, 919c <fwp_write+0x9fc>
    8aac:	52800523 	mov	w3, #0x29                  	// #41
    8ab0:	aa1503e1 	mov	x1, x21
    8ab4:	aa1403e0 	mov	x0, x20
    8ab8:	d2800022 	mov	x2, #0x1                   	// #1
    8abc:	39001fe3 	strb	w3, [sp, #7]
    8ac0:	97ffeab4 	bl	3590 <buf_put>
    8ac4:	f9413bf5 	ldr	x21, [sp, #624]
    8ac8:	f9413ff6 	ldr	x22, [sp, #632]
    8acc:	f94143f7 	ldr	x23, [sp, #640]
    8ad0:	f94147f8 	ldr	x24, [sp, #648]
    8ad4:	f94153fb 	ldr	x27, [sp, #672]
    8ad8:	f94157fc 	ldr	x28, [sp, #680]
    8adc:	17ffff5d 	b	8850 <fwp_write+0xb0>
    8ae0:	b9404855 	ldr	w21, [x2, #72]
    8ae4:	aa1403e0 	mov	x0, x20
    8ae8:	93407eb6 	sxtw	x22, w21
    8aec:	91000ac1 	add	x1, x22, #0x2
    8af0:	97ffea75 	bl	34c4 <buf_grow>
    8af4:	a9400281 	ldp	x1, x0, [x20]
    8af8:	528e8603 	mov	w3, #0x7430                	// #29744
    8afc:	78206823 	strh	w3, [x1, x0]
    8b00:	8b000022 	add	x2, x1, x0
    8b04:	710002bf 	cmp	w21, #0x0
    8b08:	540036cd 	b.le	91e0 <fwp_write+0xa40>
    8b0c:	110006a3 	add	w3, w21, #0x1
    8b10:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8b14:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8b18:	91000449 	add	x9, x2, #0x1
    8b1c:	8b23c043 	add	x3, x2, w3, sxtw
    8b20:	f28aaac6 	movk	x6, #0x5556
    8b24:	f2955568 	movk	x8, #0xaaab
    8b28:	1400000d 	b	8b5c <fwp_write+0x3bc>
    8b2c:	d2800021 	mov	x1, #0x1                   	// #1
    8b30:	528005a5 	mov	w5, #0x2d                  	// #45
    8b34:	f100001f 	cmp	x0, #0x0
    8b38:	9b467e60 	smulh	x0, x19, x6
    8b3c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8b40:	381ff465 	strb	w5, [x3], #-1
    8b44:	cb040000 	sub	x0, x0, x4
    8b48:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8b4c:	cb020000 	sub	x0, x0, x2
    8b50:	8b010013 	add	x19, x0, x1
    8b54:	eb03013f 	cmp	x9, x3
    8b58:	54003440 	b.eq	91e0 <fwp_write+0xa40>  // b.none
    8b5c:	9b467e60 	smulh	x0, x19, x6
    8b60:	937ffe64 	asr	x4, x19, #63
    8b64:	52800605 	mov	w5, #0x30                  	// #48
    8b68:	cb040000 	sub	x0, x0, x4
    8b6c:	8b000400 	add	x0, x0, x0, lsl #1
    8b70:	cb000260 	sub	x0, x19, x0
    8b74:	91000c01 	add	x1, x0, #0x3
    8b78:	9bc87c22 	umulh	x2, x1, x8
    8b7c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8b80:	8b4204e2 	add	x2, x7, x2, lsr #1
    8b84:	eb020021 	subs	x1, x1, x2
    8b88:	54fffd60 	b.eq	8b34 <fwp_write+0x394>  // b.none
    8b8c:	f100043f 	cmp	x1, #0x1
    8b90:	54fffce1 	b.ne	8b2c <fwp_write+0x38c>  // b.any
    8b94:	d2800001 	mov	x1, #0x0                   	// #0
    8b98:	52800565 	mov	w5, #0x2b                  	// #43
    8b9c:	17ffffe6 	b	8b34 <fwp_write+0x394>
    8ba0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ba4:	f947f400 	ldr	x0, [x0, #4072]
    8ba8:	f94127e2 	ldr	x2, [sp, #584]
    8bac:	f9400001 	ldr	x1, [x0]
    8bb0:	eb010042 	subs	x2, x2, x1
    8bb4:	d2800001 	mov	x1, #0x0                   	// #0
    8bb8:	540023c1 	b.ne	9030 <fwp_write+0x890>  // b.any
    8bbc:	f9413bf5 	ldr	x21, [sp, #624]
    8bc0:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    8bc4:	f9413ff6 	ldr	x22, [sp, #632]
    8bc8:	aa1403e0 	mov	x0, x20
    8bcc:	912ce021 	add	x1, x1, #0xb38
    8bd0:	d2800102 	mov	x2, #0x8                   	// #8
    8bd4:	17ffff77 	b	89b0 <fwp_write+0x210>
    8bd8:	aa1403e0 	mov	x0, x20
    8bdc:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    8be0:	d28000c2 	mov	x2, #0x6                   	// #6
    8be4:	912e6021 	add	x1, x1, #0xb98
    8be8:	97ffea6a 	bl	3590 <buf_put>
    8bec:	d2800015 	mov	x21, #0x0                   	// #0
    8bf0:	f9400263 	ldr	x3, [x19]
    8bf4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8bf8:	54002c60 	b.eq	9184 <fwp_write+0x9e4>  // b.none
    8bfc:	f9401f82 	ldr	x2, [x28, #56]
    8c00:	f90143f7 	str	x23, [sp, #640]
    8c04:	f90147f8 	str	x24, [sp, #648]
    8c08:	d2800857 	mov	x23, #0x42                  	// #66
    8c0c:	f9014bf9 	str	x25, [sp, #656]
    8c10:	f0000016 	adrp	x22, b000 <__divti3+0x1a0>
    8c14:	f9014ffa 	str	x26, [sp, #664]
    8c18:	912e42d6 	add	x22, x22, #0xb90
    8c1c:	d2800038 	mov	x24, #0x1                   	// #1
    8c20:	f2a18017 	movk	x23, #0xc00, lsl #16
    8c24:	d2809099 	mov	x25, #0x484                 	// #1156
    8c28:	b40004a2 	cbz	x2, 8cbc <fwp_write+0x51c>
    8c2c:	b9400040 	ldr	w0, [x2]
    8c30:	7100701f 	cmp	w0, #0x1c
    8c34:	540042c0 	b.eq	948c <fwp_write+0xcec>  // b.none
    8c38:	71006c1f 	cmp	w0, #0x1b
    8c3c:	54000408 	b.hi	8cbc <fwp_write+0x51c>  // b.pmore
    8c40:	9ac02301 	lsl	x1, x24, x0
    8c44:	ea17003f 	tst	x1, x23
    8c48:	540036a1 	b.ne	931c <fwp_write+0xb7c>  // b.any
    8c4c:	ea19003f 	tst	x1, x25
    8c50:	54003521 	b.ne	92f4 <fwp_write+0xb54>  // b.any
    8c54:	d2800424 	mov	x4, #0x21                  	// #33
    8c58:	ea04003f 	tst	x1, x4
    8c5c:	54000300 	b.eq	8cbc <fwp_write+0x51c>  // b.none
    8c60:	b7f849c3 	tbnz	x3, #63, 9598 <fwp_write+0xdf8>
    8c64:	91002261 	add	x1, x19, #0x8
    8c68:	8b150021 	add	x1, x1, x21
    8c6c:	39400021 	ldrb	w1, [x1]
    8c70:	7100001f 	cmp	w0, #0x0
    8c74:	93401c23 	sxtb	x3, w1
    8c78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8c7c:	d503201f 	nop
    8c80:	aa1403e0 	mov	x0, x20
    8c84:	52800003 	mov	w3, #0x0                   	// #0
    8c88:	97fffec6 	bl	87a0 <fwp_write>
    8c8c:	910006b5 	add	x21, x21, #0x1
    8c90:	f9400260 	ldr	x0, [x19]
    8c94:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8c98:	eb0002bf 	cmp	x21, x0
    8c9c:	540026c2 	b.cs	9174 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ca0:	d2800042 	mov	x2, #0x2                   	// #2
    8ca4:	aa1603e1 	mov	x1, x22
    8ca8:	aa1403e0 	mov	x0, x20
    8cac:	97ffea39 	bl	3590 <buf_put>
    8cb0:	f9401f82 	ldr	x2, [x28, #56]
    8cb4:	f9400263 	ldr	x3, [x19]
    8cb8:	b5fffba2 	cbnz	x2, 8c2c <fwp_write+0x48c>
    8cbc:	d37df2a0 	lsl	x0, x21, #3
    8cc0:	b7f83f03 	tbnz	x3, #63, 94a0 <fwp_write+0xd00>
    8cc4:	91002261 	add	x1, x19, #0x8
    8cc8:	8b000020 	add	x0, x1, x0
    8ccc:	f9400001 	ldr	x1, [x0]
    8cd0:	17ffffec 	b	8c80 <fwp_write+0x4e0>
    8cd4:	a9400e62 	ldp	x2, x3, [x19]
    8cd8:	b7f83ca3 	tbnz	x3, #63, 946c <fwp_write+0xccc>
    8cdc:	910123f5 	add	x21, sp, #0x48
    8ce0:	aa1503e0 	mov	x0, x21
    8ce4:	97ffe84f 	bl	2e20 <fwp_fmt_u128>
    8ce8:	aa1503e0 	mov	x0, x21
    8cec:	97ffe689 	bl	2710 <strlen@plt>
    8cf0:	aa1503e1 	mov	x1, x21
    8cf4:	aa0003e2 	mov	x2, x0
    8cf8:	17fffed0 	b	8838 <fwp_write+0x98>
    8cfc:	fd015be8 	str	d8, [sp, #688]
    8d00:	1e270268 	fmov	s8, w19
    8d04:	fd015fe9 	str	d9, [sp, #696]
    8d08:	1e282100 	fcmp	s8, s8
    8d0c:	54004d26 	b.vs	96b0 <fwp_write+0xf10>
    8d10:	1e20c101 	fabs	s1, s8
    8d14:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8d18:	1e270000 	fmov	s0, w0
    8d1c:	1e202020 	fcmp	s1, s0
    8d20:	54002c0d 	b.le	92a0 <fwp_write+0xb00>
    8d24:	1e202118 	fcmpe	s8, #0.0
    8d28:	f0000002 	adrp	x2, b000 <__divti3+0x1a0>
    8d2c:	91196042 	add	x2, x2, #0x658
    8d30:	910123f5 	add	x21, sp, #0x48
    8d34:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    8d38:	912ba021 	add	x1, x1, #0xae8
    8d3c:	aa1503e0 	mov	x0, x21
    8d40:	9a81c041 	csel	x1, x2, x1, gt
    8d44:	97ffe71f 	bl	29c0 <strcpy@plt>
    8d48:	aa1503e0 	mov	x0, x21
    8d4c:	97ffe671 	bl	2710 <strlen@plt>
    8d50:	aa1503e1 	mov	x1, x21
    8d54:	aa0003e2 	mov	x2, x0
    8d58:	aa1403e0 	mov	x0, x20
    8d5c:	97ffea0d 	bl	3590 <buf_put>
    8d60:	f9413bf5 	ldr	x21, [sp, #624]
    8d64:	f9413ff6 	ldr	x22, [sp, #632]
    8d68:	f94153fb 	ldr	x27, [sp, #672]
    8d6c:	f94157fc 	ldr	x28, [sp, #680]
    8d70:	fd415be8 	ldr	d8, [sp, #688]
    8d74:	fd415fe9 	ldr	d9, [sp, #696]
    8d78:	17fffeb6 	b	8850 <fwp_write+0xb0>
    8d7c:	f9400276 	ldr	x22, [x19]
    8d80:	34002e03 	cbz	w3, 9340 <fwp_write+0xba0>
    8d84:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8d88:	f947f400 	ldr	x0, [x0, #4072]
    8d8c:	f94127e2 	ldr	x2, [sp, #584]
    8d90:	f9400001 	ldr	x1, [x0]
    8d94:	eb010042 	subs	x2, x2, x1
    8d98:	d2800001 	mov	x1, #0x0                   	// #0
    8d9c:	540014a1 	b.ne	9030 <fwp_write+0x890>  // b.any
    8da0:	aa1603e2 	mov	x2, x22
    8da4:	91002261 	add	x1, x19, #0x8
    8da8:	f9413bf5 	ldr	x21, [sp, #624]
    8dac:	aa1403e0 	mov	x0, x20
    8db0:	f9413ff6 	ldr	x22, [sp, #632]
    8db4:	17fffeff 	b	89b0 <fwp_write+0x210>
    8db8:	fd015be8 	str	d8, [sp, #688]
    8dbc:	9e670268 	fmov	d8, x19
    8dc0:	fd015fe9 	str	d9, [sp, #696]
    8dc4:	1e682100 	fcmp	d8, d8
    8dc8:	54004746 	b.vs	96b0 <fwp_write+0xf10>
    8dcc:	1e60c101 	fabs	d1, d8
    8dd0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8dd4:	9e670000 	fmov	d0, x0
    8dd8:	910123f5 	add	x21, sp, #0x48
    8ddc:	52800033 	mov	w19, #0x1                   	// #1
    8de0:	1e602020 	fcmp	d1, d0
    8de4:	540001ad 	b.le	8e18 <fwp_write+0x678>
    8de8:	1e602118 	fcmpe	d8, #0.0
    8dec:	f0000002 	adrp	x2, b000 <__divti3+0x1a0>
    8df0:	91196042 	add	x2, x2, #0x658
    8df4:	f0000001 	adrp	x1, b000 <__divti3+0x1a0>
    8df8:	912ba021 	add	x1, x1, #0xae8
    8dfc:	aa1503e0 	mov	x0, x21
    8e00:	9a81c041 	csel	x1, x2, x1, gt
    8e04:	97ffe6ef 	bl	29c0 <strcpy@plt>
    8e08:	17ffffd0 	b	8d48 <fwp_write+0x5a8>
    8e0c:	11000673 	add	w19, w19, #0x1
    8e10:	71004a7f 	cmp	w19, #0x12
    8e14:	54003860 	b.eq	9520 <fwp_write+0xd80>  // b.none
    8e18:	1e604100 	fmov	d0, d8
    8e1c:	2a1303e1 	mov	w1, w19
    8e20:	aa1503e0 	mov	x0, x21
    8e24:	97ffeb5c 	bl	3b94 <fwp_format_g.constprop.0>
    8e28:	aa1503e0 	mov	x0, x21
    8e2c:	d2800001 	mov	x1, #0x0                   	// #0
    8e30:	97ffe64c 	bl	2760 <strtod@plt>
    8e34:	1e602100 	fcmp	d8, d0
    8e38:	54fffea1 	b.ne	8e0c <fwp_write+0x66c>  // b.any
    8e3c:	aa1503e0 	mov	x0, x21
    8e40:	97ffea4d 	bl	3774 <fwp_finish_float>
    8e44:	17ffffc1 	b	8d48 <fwp_write+0x5a8>
    8e48:	a9400e62 	ldp	x2, x3, [x19]
    8e4c:	910123f3 	add	x19, sp, #0x48
    8e50:	aa1303e0 	mov	x0, x19
    8e54:	97ffe7f3 	bl	2e20 <fwp_fmt_u128>
    8e58:	17fffe74 	b	8828 <fwp_write+0x88>
    8e5c:	f90143f7 	str	x23, [sp, #640]
    8e60:	f90147f8 	str	x24, [sp, #648]
    8e64:	2a1303f8 	mov	w24, w19
    8e68:	f9014bf9 	str	x25, [sp, #656]
    8e6c:	f9014ffa 	str	x26, [sp, #664]
    8e70:	f13ffe7f 	cmp	x19, #0xfff
    8e74:	54000049 	b.ls	8e7c <fwp_write+0x6dc>  // b.plast
    8e78:	b9400278 	ldr	w24, [x19]
    8e7c:	f9400f80 	ldr	x0, [x28, #24]
    8e80:	2a1803f5 	mov	w21, w24
    8e84:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8e88:	d37ef6b9 	lsl	x25, x21, #2
    8e8c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8e90:	aa1603e0 	mov	x0, x22
    8e94:	97ffe61f 	bl	2710 <strlen@plt>
    8e98:	aa1603e1 	mov	x1, x22
    8e9c:	aa0003e2 	mov	x2, x0
    8ea0:	aa1403e0 	mov	x0, x20
    8ea4:	97ffe9bb 	bl	3590 <buf_put>
    8ea8:	f9401780 	ldr	x0, [x28, #40]
    8eac:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8eb0:	7100001f 	cmp	w0, #0x0
    8eb4:	5400068d 	b.le	8f84 <fwp_write+0x7e4>
    8eb8:	91002276 	add	x22, x19, #0x8
    8ebc:	91001ff5 	add	x21, sp, #0x7
    8ec0:	d280001b 	mov	x27, #0x0                   	// #0
    8ec4:	5280041a 	mov	w26, #0x20                  	// #32
    8ec8:	f9401b80 	ldr	x0, [x28, #48]
    8ecc:	aa1503e1 	mov	x1, x21
    8ed0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8ed4:	d2800022 	mov	x2, #0x1                   	// #1
    8ed8:	f8786803 	ldr	x3, [x0, x24]
    8edc:	aa1403e0 	mov	x0, x20
    8ee0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8ee4:	39001ffa 	strb	w26, [sp, #7]
    8ee8:	97ffe9aa 	bl	3590 <buf_put>
    8eec:	f13ffeff 	cmp	x23, #0xfff
    8ef0:	b9400261 	ldr	w1, [x19]
    8ef4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8ef8:	7100383f 	cmp	w1, #0xe
    8efc:	54000160 	b.eq	8f28 <fwp_write+0x788>  // b.none
    8f00:	7100403f 	cmp	w1, #0x10
    8f04:	54001a60 	b.eq	9250 <fwp_write+0xab0>  // b.none
    8f08:	7100283f 	cmp	w1, #0xa
    8f0c:	54002aa0 	b.eq	9460 <fwp_write+0xcc0>  // b.none
    8f10:	540014ac 	b.gt	91a4 <fwp_write+0xa04>
    8f14:	71000c3f 	cmp	w1, #0x3
    8f18:	540029ac 	b.gt	944c <fwp_write+0xcac>
    8f1c:	d37ffee0 	lsr	x0, x23, #63
    8f20:	37f814a1 	tbnz	w1, #31, 91b4 <fwp_write+0xa14>
    8f24:	d503201f 	nop
    8f28:	34001460 	cbz	w0, 91b4 <fwp_write+0xa14>
    8f2c:	52800503 	mov	w3, #0x28                  	// #40
    8f30:	aa1503e1 	mov	x1, x21
    8f34:	aa1403e0 	mov	x0, x20
    8f38:	d2800022 	mov	x2, #0x1                   	// #1
    8f3c:	39001fe3 	strb	w3, [sp, #7]
    8f40:	97ffe994 	bl	3590 <buf_put>
    8f44:	aa1303e2 	mov	x2, x19
    8f48:	aa1703e1 	mov	x1, x23
    8f4c:	aa1403e0 	mov	x0, x20
    8f50:	52800003 	mov	w3, #0x0                   	// #0
    8f54:	97fffe13 	bl	87a0 <fwp_write>
    8f58:	52800523 	mov	w3, #0x29                  	// #41
    8f5c:	aa1503e1 	mov	x1, x21
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	d2800022 	mov	x2, #0x1                   	// #1
    8f68:	39001fe3 	strb	w3, [sp, #7]
    8f6c:	97ffe989 	bl	3590 <buf_put>
    8f70:	f9401780 	ldr	x0, [x28, #40]
    8f74:	9100077b 	add	x27, x27, #0x1
    8f78:	b8796800 	ldr	w0, [x0, x25]
    8f7c:	6b1b001f 	cmp	w0, w27
    8f80:	54fffa4c 	b.gt	8ec8 <fwp_write+0x728>
    8f84:	f9413bf5 	ldr	x21, [sp, #624]
    8f88:	f9413ff6 	ldr	x22, [sp, #632]
    8f8c:	f94143f7 	ldr	x23, [sp, #640]
    8f90:	f94147f8 	ldr	x24, [sp, #648]
    8f94:	f9414bf9 	ldr	x25, [sp, #656]
    8f98:	f9414ffa 	ldr	x26, [sp, #664]
    8f9c:	f94153fb 	ldr	x27, [sp, #672]
    8fa0:	f94157fc 	ldr	x28, [sp, #680]
    8fa4:	17fffe2b 	b	8850 <fwp_write+0xb0>
    8fa8:	52800783 	mov	w3, #0x3c                  	// #60
    8fac:	91001ff3 	add	x19, sp, #0x7
    8fb0:	aa1303e1 	mov	x1, x19
    8fb4:	d2800022 	mov	x2, #0x1                   	// #1
    8fb8:	aa1403e0 	mov	x0, x20
    8fbc:	39001fe3 	strb	w3, [sp, #7]
    8fc0:	97ffe974 	bl	3590 <buf_put>
    8fc4:	f9400795 	ldr	x21, [x28, #8]
    8fc8:	aa1503e0 	mov	x0, x21
    8fcc:	97ffe5d1 	bl	2710 <strlen@plt>
    8fd0:	aa1503e1 	mov	x1, x21
    8fd4:	aa0003e2 	mov	x2, x0
    8fd8:	aa1403e0 	mov	x0, x20
    8fdc:	97ffe96d 	bl	3590 <buf_put>
    8fe0:	528007c3 	mov	w3, #0x3e                  	// #62
    8fe4:	aa1303e1 	mov	x1, x19
    8fe8:	aa1403e0 	mov	x0, x20
    8fec:	d2800022 	mov	x2, #0x1                   	// #1
    8ff0:	39001fe3 	strb	w3, [sp, #7]
    8ff4:	17fffe12 	b	883c <fwp_write+0x9c>
    8ff8:	f100067f 	cmp	x19, #0x1
    8ffc:	540025a0 	b.eq	94b0 <fwp_write+0xd10>  // b.none
    9000:	b100067f 	cmn	x19, #0x1
    9004:	54002bc0 	b.eq	957c <fwp_write+0xddc>  // b.none
    9008:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    900c:	912bc021 	add	x1, x1, #0xaf0
    9010:	d2800022 	mov	x2, #0x1                   	// #1
    9014:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9018:	f947f400 	ldr	x0, [x0, #4072]
    901c:	f94127e4 	ldr	x4, [sp, #584]
    9020:	f9400003 	ldr	x3, [x0]
    9024:	eb030084 	subs	x4, x4, x3
    9028:	d2800003 	mov	x3, #0x0                   	// #0
    902c:	54ffebe0 	b.eq	8da8 <fwp_write+0x608>  // b.none
    9030:	f90143f7 	str	x23, [sp, #640]
    9034:	f90147f8 	str	x24, [sp, #648]
    9038:	f9014bf9 	str	x25, [sp, #656]
    903c:	f9014ffa 	str	x26, [sp, #664]
    9040:	fd015be8 	str	d8, [sp, #688]
    9044:	fd015fe9 	str	d9, [sp, #696]
    9048:	97ffe60e 	bl	2880 <__stack_chk_fail@plt>
    904c:	52800b63 	mov	w3, #0x5b                  	// #91
    9050:	91001ff5 	add	x21, sp, #0x7
    9054:	aa1503e1 	mov	x1, x21
    9058:	aa1403e0 	mov	x0, x20
    905c:	d2800022 	mov	x2, #0x1                   	// #1
    9060:	d0000016 	adrp	x22, b000 <__divti3+0x1a0>
    9064:	912e42d6 	add	x22, x22, #0xb90
    9068:	39001fe3 	strb	w3, [sp, #7]
    906c:	97ffe949 	bl	3590 <buf_put>
    9070:	b4000273 	cbz	x19, 90bc <fwp_write+0x91c>
    9074:	f9400661 	ldr	x1, [x19, #8]
    9078:	aa1403e0 	mov	x0, x20
    907c:	f9401f82 	ldr	x2, [x28, #56]
    9080:	52800003 	mov	w3, #0x0                   	// #0
    9084:	97fffdc7 	bl	87a0 <fwp_write>
    9088:	f9400a73 	ldr	x19, [x19, #16]
    908c:	b4000193 	cbz	x19, 90bc <fwp_write+0x91c>
    9090:	aa1603e1 	mov	x1, x22
    9094:	aa1403e0 	mov	x0, x20
    9098:	d2800042 	mov	x2, #0x2                   	// #2
    909c:	97ffe93d 	bl	3590 <buf_put>
    90a0:	f9400661 	ldr	x1, [x19, #8]
    90a4:	aa1403e0 	mov	x0, x20
    90a8:	f9401f82 	ldr	x2, [x28, #56]
    90ac:	52800003 	mov	w3, #0x0                   	// #0
    90b0:	97fffdbc 	bl	87a0 <fwp_write>
    90b4:	f9400a73 	ldr	x19, [x19, #16]
    90b8:	b5fffed3 	cbnz	x19, 9090 <fwp_write+0x8f0>
    90bc:	52800ba3 	mov	w3, #0x5d                  	// #93
    90c0:	aa1503e1 	mov	x1, x21
    90c4:	aa1403e0 	mov	x0, x20
    90c8:	d2800022 	mov	x2, #0x1                   	// #1
    90cc:	39001fe3 	strb	w3, [sp, #7]
    90d0:	17fffddb 	b	883c <fwp_write+0x9c>
    90d4:	aa1403e0 	mov	x0, x20
    90d8:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    90dc:	d28000c2 	mov	x2, #0x6                   	// #6
    90e0:	912e0021 	add	x1, x1, #0xb80
    90e4:	97ffe92b 	bl	3590 <buf_put>
    90e8:	f9400260 	ldr	x0, [x19]
    90ec:	b40004c0 	cbz	x0, 9184 <fwp_write+0x9e4>
    90f0:	910123f5 	add	x21, sp, #0x48
    90f4:	91002276 	add	x22, x19, #0x8
    90f8:	f90143f7 	str	x23, [sp, #640]
    90fc:	d2800017 	mov	x23, #0x0                   	// #0
    9100:	f90147f8 	str	x24, [sp, #648]
    9104:	d0000018 	adrp	x24, b000 <__divti3+0x1a0>
    9108:	912e2318 	add	x24, x24, #0xb88
    910c:	f9014bf9 	str	x25, [sp, #656]
    9110:	d0000019 	adrp	x25, b000 <__divti3+0x1a0>
    9114:	912e4339 	add	x25, x25, #0xb90
    9118:	f9014ffa 	str	x26, [sp, #664]
    911c:	14000005 	b	9130 <fwp_write+0x990>
    9120:	aa1903e1 	mov	x1, x25
    9124:	aa1403e0 	mov	x0, x20
    9128:	d2800042 	mov	x2, #0x2                   	// #2
    912c:	97ffe919 	bl	3590 <buf_put>
    9130:	38776ac5 	ldrb	w5, [x22, x23]
    9134:	d2804003 	mov	x3, #0x200                 	// #512
    9138:	aa1803e4 	mov	x4, x24
    913c:	aa0303e1 	mov	x1, x3
    9140:	52800042 	mov	w2, #0x2                   	// #2
    9144:	aa1503e0 	mov	x0, x21
    9148:	910006f7 	add	x23, x23, #0x1
    914c:	97ffe5a9 	bl	27f0 <__snprintf_chk@plt>
    9150:	aa1503e0 	mov	x0, x21
    9154:	97ffe56f 	bl	2710 <strlen@plt>
    9158:	aa1503e1 	mov	x1, x21
    915c:	aa0003e2 	mov	x2, x0
    9160:	aa1403e0 	mov	x0, x20
    9164:	97ffe90b 	bl	3590 <buf_put>
    9168:	f9400260 	ldr	x0, [x19]
    916c:	eb17001f 	cmp	x0, x23
    9170:	54fffd88 	b.hi	9120 <fwp_write+0x980>  // b.pmore
    9174:	f94143f7 	ldr	x23, [sp, #640]
    9178:	f94147f8 	ldr	x24, [sp, #648]
    917c:	f9414bf9 	ldr	x25, [sp, #656]
    9180:	f9414ffa 	ldr	x26, [sp, #664]
    9184:	52800ba3 	mov	w3, #0x5d                  	// #93
    9188:	aa1403e0 	mov	x0, x20
    918c:	91001fe1 	add	x1, sp, #0x7
    9190:	d2800022 	mov	x2, #0x1                   	// #1
    9194:	39001fe3 	strb	w3, [sp, #7]
    9198:	17fffda9 	b	883c <fwp_write+0x9c>
    919c:	52800fa3 	mov	w3, #0x7d                  	// #125
    91a0:	17fffe44 	b	8ab0 <fwp_write+0x310>
    91a4:	f10002ff 	cmp	x23, #0x0
    91a8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    91ac:	71002c3f 	cmp	w1, #0xb
    91b0:	54ffebc0 	b.eq	8f28 <fwp_write+0x788>  // b.none
    91b4:	aa1303e2 	mov	x2, x19
    91b8:	aa1703e1 	mov	x1, x23
    91bc:	aa1403e0 	mov	x0, x20
    91c0:	52800003 	mov	w3, #0x0                   	// #0
    91c4:	97fffd77 	bl	87a0 <fwp_write>
    91c8:	17ffff6a 	b	8f70 <fwp_write+0x7d0>
    91cc:	aa1403e0 	mov	x0, x20
    91d0:	91001fe1 	add	x1, sp, #0x7
    91d4:	52800fa3 	mov	w3, #0x7d                  	// #125
    91d8:	d2800022 	mov	x2, #0x1                   	// #1
    91dc:	17fffe38 	b	8abc <fwp_write+0x31c>
    91e0:	a9400281 	ldp	x1, x0, [x20]
    91e4:	91000800 	add	x0, x0, #0x2
    91e8:	8b160000 	add	x0, x0, x22
    91ec:	f9000680 	str	x0, [x20, #8]
    91f0:	3820683f 	strb	wzr, [x1, x0]
    91f4:	f9413bf5 	ldr	x21, [sp, #624]
    91f8:	f9413ff6 	ldr	x22, [sp, #632]
    91fc:	f94153fb 	ldr	x27, [sp, #672]
    9200:	f94157fc 	ldr	x28, [sp, #680]
    9204:	17fffd93 	b	8850 <fwp_write+0xb0>
    9208:	f9400f80 	ldr	x0, [x28, #24]
    920c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9210:	aa1b03e0 	mov	x0, x27
    9214:	97ffe53f 	bl	2710 <strlen@plt>
    9218:	aa1b03e1 	mov	x1, x27
    921c:	aa0003e2 	mov	x2, x0
    9220:	aa1403e0 	mov	x0, x20
    9224:	97ffe8db 	bl	3590 <buf_put>
    9228:	aa1903e1 	mov	x1, x25
    922c:	aa1403e0 	mov	x0, x20
    9230:	d2800062 	mov	x2, #0x3                   	// #3
    9234:	97ffe8d7 	bl	3590 <buf_put>
    9238:	17fffe10 	b	8a78 <fwp_write+0x2d8>
    923c:	aa1a03e1 	mov	x1, x26
    9240:	aa1403e0 	mov	x0, x20
    9244:	d2800042 	mov	x2, #0x2                   	// #2
    9248:	97ffe8d2 	bl	3590 <buf_put>
    924c:	17fffe09 	b	8a70 <fwp_write+0x2d0>
    9250:	f9400660 	ldr	x0, [x19, #8]
    9254:	b4fffb00 	cbz	x0, 91b4 <fwp_write+0xa14>
    9258:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    925c:	912ea021 	add	x1, x1, #0xba8
    9260:	97ffe5a8 	bl	2900 <strcmp@plt>
    9264:	7100001f 	cmp	w0, #0x0
    9268:	1a9f07e0 	cset	w0, ne	// ne = any
    926c:	17ffff2f 	b	8f28 <fwp_write+0x788>
    9270:	aa1403e0 	mov	x0, x20
    9274:	d2800042 	mov	x2, #0x2                   	// #2
    9278:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    927c:	912e8021 	add	x1, x1, #0xba0
    9280:	97ffe8c4 	bl	3590 <buf_put>
    9284:	91004261 	add	x1, x19, #0x10
    9288:	aa1403e0 	mov	x0, x20
    928c:	f9402382 	ldr	x2, [x28, #64]
    9290:	52800003 	mov	w3, #0x0                   	// #0
    9294:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9298:	97fffd42 	bl	87a0 <fwp_write>
    929c:	17fffd9c 	b	890c <fwp_write+0x16c>
    92a0:	1e22c109 	fcvt	d9, s8
    92a4:	910123f5 	add	x21, sp, #0x48
    92a8:	52800033 	mov	w19, #0x1                   	// #1
    92ac:	d503201f 	nop
    92b0:	1e604120 	fmov	d0, d9
    92b4:	2a1303e1 	mov	w1, w19
    92b8:	aa1503e0 	mov	x0, x21
    92bc:	97ffea36 	bl	3b94 <fwp_format_g.constprop.0>
    92c0:	aa1503e0 	mov	x0, x21
    92c4:	d2800001 	mov	x1, #0x0                   	// #0
    92c8:	97ffe59a 	bl	2930 <strtof@plt>
    92cc:	1e202100 	fcmp	s8, s0
    92d0:	54ffdb60 	b.eq	8e3c <fwp_write+0x69c>  // b.none
    92d4:	11000673 	add	w19, w19, #0x1
    92d8:	71002a7f 	cmp	w19, #0xa
    92dc:	54fffea1 	b.ne	92b0 <fwp_write+0xb10>  // b.any
    92e0:	1e604120 	fmov	d0, d9
    92e4:	aa1503e0 	mov	x0, x21
    92e8:	52800121 	mov	w1, #0x9                   	// #9
    92ec:	97ffea2a 	bl	3b94 <fwp_format_g.constprop.0>
    92f0:	17fffed3 	b	8e3c <fwp_write+0x69c>
    92f4:	d37ef6a1 	lsl	x1, x21, #2
    92f8:	b7f81563 	tbnz	x3, #63, 95a4 <fwp_write+0xe04>
    92fc:	91002263 	add	x3, x19, #0x8
    9300:	8b010061 	add	x1, x3, x1
    9304:	b9400023 	ldr	w3, [x1]
    9308:	7100081f 	cmp	w0, #0x2
    930c:	2a0303e1 	mov	w1, w3
    9310:	93407c63 	sxtw	x3, w3
    9314:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9318:	17fffe5a 	b	8c80 <fwp_write+0x4e0>
    931c:	d37ffaa1 	lsl	x1, x21, #1
    9320:	b7f81363 	tbnz	x3, #63, 958c <fwp_write+0xdec>
    9324:	91002263 	add	x3, x19, #0x8
    9328:	8b010061 	add	x1, x3, x1
    932c:	79400021 	ldrh	w1, [x1]
    9330:	7100041f 	cmp	w0, #0x1
    9334:	93403c23 	sxth	x3, w1
    9338:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    933c:	17fffe51 	b	8c80 <fwp_write+0x4e0>
    9340:	52800443 	mov	w3, #0x22                  	// #34
    9344:	91001ff5 	add	x21, sp, #0x7
    9348:	91002273 	add	x19, x19, #0x8
    934c:	aa1503e1 	mov	x1, x21
    9350:	aa1403e0 	mov	x0, x20
    9354:	d2800022 	mov	x2, #0x1                   	// #1
    9358:	39001fe3 	strb	w3, [sp, #7]
    935c:	f90143f7 	str	x23, [sp, #640]
    9360:	8b160277 	add	x23, x19, x22
    9364:	f90147f8 	str	x24, [sp, #648]
    9368:	97ffe88a 	bl	3590 <buf_put>
    936c:	b4000696 	cbz	x22, 943c <fwp_write+0xc9c>
    9370:	d0000018 	adrp	x24, b000 <__divti3+0x1a0>
    9374:	912d4318 	add	x24, x24, #0xb50
    9378:	f9014bf9 	str	x25, [sp, #656]
    937c:	d0000019 	adrp	x25, b000 <__divti3+0x1a0>
    9380:	912dc339 	add	x25, x25, #0xb70
    9384:	f9014ffa 	str	x26, [sp, #664]
    9388:	1400000d 	b	93bc <fwp_write+0xc1c>
    938c:	710024bf 	cmp	w5, #0x9
    9390:	54000460 	b.eq	941c <fwp_write+0xc7c>  // b.none
    9394:	710028bf 	cmp	w5, #0xa
    9398:	54000a61 	b.ne	94e4 <fwp_write+0xd44>  // b.any
    939c:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    93a0:	aa1403e0 	mov	x0, x20
    93a4:	912d8021 	add	x1, x1, #0xb60
    93a8:	d2800042 	mov	x2, #0x2                   	// #2
    93ac:	97ffe879 	bl	3590 <buf_put>
    93b0:	91000673 	add	x19, x19, #0x1
    93b4:	eb17027f 	cmp	x19, x23
    93b8:	540003e0 	b.eq	9434 <fwp_write+0xc94>  // b.none
    93bc:	39400265 	ldrb	w5, [x19]
    93c0:	710034bf 	cmp	w5, #0xd
    93c4:	54000180 	b.eq	93f4 <fwp_write+0xc54>  // b.none
    93c8:	54fffe29 	b.ls	938c <fwp_write+0xbec>  // b.plast
    93cc:	710088bf 	cmp	w5, #0x22
    93d0:	540001c0 	b.eq	9408 <fwp_write+0xc68>  // b.none
    93d4:	710170bf 	cmp	w5, #0x5c
    93d8:	54000741 	b.ne	94c0 <fwp_write+0xd20>  // b.any
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    93e4:	d2800042 	mov	x2, #0x2                   	// #2
    93e8:	912d6021 	add	x1, x1, #0xb58
    93ec:	97ffe869 	bl	3590 <buf_put>
    93f0:	17fffff0 	b	93b0 <fwp_write+0xc10>
    93f4:	aa1903e1 	mov	x1, x25
    93f8:	aa1403e0 	mov	x0, x20
    93fc:	d2800042 	mov	x2, #0x2                   	// #2
    9400:	97ffe864 	bl	3590 <buf_put>
    9404:	17ffffeb 	b	93b0 <fwp_write+0xc10>
    9408:	aa1803e1 	mov	x1, x24
    940c:	aa1403e0 	mov	x0, x20
    9410:	d2800042 	mov	x2, #0x2                   	// #2
    9414:	97ffe85f 	bl	3590 <buf_put>
    9418:	17ffffe6 	b	93b0 <fwp_write+0xc10>
    941c:	aa1403e0 	mov	x0, x20
    9420:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    9424:	d2800042 	mov	x2, #0x2                   	// #2
    9428:	912da021 	add	x1, x1, #0xb68
    942c:	97ffe859 	bl	3590 <buf_put>
    9430:	17ffffe0 	b	93b0 <fwp_write+0xc10>
    9434:	f9414bf9 	ldr	x25, [sp, #656]
    9438:	f9414ffa 	ldr	x26, [sp, #664]
    943c:	aa1503e1 	mov	x1, x21
    9440:	aa1403e0 	mov	x0, x20
    9444:	52800443 	mov	w3, #0x22                  	// #34
    9448:	17fffd9c 	b	8ab8 <fwp_write+0x318>
    944c:	7100103f 	cmp	w1, #0x4
    9450:	54ffeb21 	b.ne	91b4 <fwp_write+0xa14>  // b.any
    9454:	f94006e0 	ldr	x0, [x23, #8]
    9458:	d37ffc00 	lsr	x0, x0, #63
    945c:	17fffeb3 	b	8f28 <fwp_write+0x788>
    9460:	710002ff 	cmp	w23, #0x0
    9464:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9468:	17fffeb0 	b	8f28 <fwp_write+0x788>
    946c:	528005a1 	mov	w1, #0x2d                  	// #45
    9470:	eb0203e2 	negs	x2, x2
    9474:	da0303e3 	ngc	x3, x3
    9478:	910127e0 	add	x0, sp, #0x49
    947c:	910123f5 	add	x21, sp, #0x48
    9480:	390123e1 	strb	w1, [sp, #72]
    9484:	97ffe667 	bl	2e20 <fwp_fmt_u128>
    9488:	17fffe18 	b	8ce8 <fwp_write+0x548>
    948c:	d37ceea1 	lsl	x1, x21, #4
    9490:	b7f810a3 	tbnz	x3, #63, 96a4 <fwp_write+0xf04>
    9494:	91002260 	add	x0, x19, #0x8
    9498:	8b010001 	add	x1, x0, x1
    949c:	17fffdf9 	b	8c80 <fwp_write+0x4e0>
    94a0:	f9400a61 	ldr	x1, [x19, #16]
    94a4:	8b010000 	add	x0, x0, x1
    94a8:	f9400001 	ldr	x1, [x0]
    94ac:	17fffdf5 	b	8c80 <fwp_write+0x4e0>
    94b0:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    94b4:	d2800042 	mov	x2, #0x2                   	// #2
    94b8:	912be021 	add	x1, x1, #0xaf8
    94bc:	17fffed6 	b	9014 <fwp_write+0x874>
    94c0:	7101fcbf 	cmp	w5, #0x7f
    94c4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    94c8:	540000e9 	b.ls	94e4 <fwp_write+0xd44>  // b.plast
    94cc:	aa1503e1 	mov	x1, x21
    94d0:	aa1403e0 	mov	x0, x20
    94d4:	d2800022 	mov	x2, #0x1                   	// #1
    94d8:	39001fe5 	strb	w5, [sp, #7]
    94dc:	97ffe82d 	bl	3590 <buf_put>
    94e0:	17ffffb4 	b	93b0 <fwp_write+0xc10>
    94e4:	d2800203 	mov	x3, #0x10                  	// #16
    94e8:	d0000004 	adrp	x4, b000 <__divti3+0x1a0>
    94ec:	aa0303e1 	mov	x1, x3
    94f0:	912de084 	add	x4, x4, #0xb78
    94f4:	910123f6 	add	x22, sp, #0x48
    94f8:	52800042 	mov	w2, #0x2                   	// #2
    94fc:	aa1603e0 	mov	x0, x22
    9500:	97ffe4bc 	bl	27f0 <__snprintf_chk@plt>
    9504:	aa1603e0 	mov	x0, x22
    9508:	97ffe482 	bl	2710 <strlen@plt>
    950c:	aa1603e1 	mov	x1, x22
    9510:	aa0003e2 	mov	x2, x0
    9514:	aa1403e0 	mov	x0, x20
    9518:	97ffe81e 	bl	3590 <buf_put>
    951c:	17ffffa5 	b	93b0 <fwp_write+0xc10>
    9520:	1e604100 	fmov	d0, d8
    9524:	aa1503e0 	mov	x0, x21
    9528:	52800221 	mov	w1, #0x11                  	// #17
    952c:	97ffe99a 	bl	3b94 <fwp_format_g.constprop.0>
    9530:	17fffe43 	b	8e3c <fwp_write+0x69c>
    9534:	b9401040 	ldr	w0, [x2, #16]
    9538:	350003c0 	cbnz	w0, 95b0 <fwp_write+0xe10>
    953c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9540:	f947f400 	ldr	x0, [x0, #4072]
    9544:	f94127e2 	ldr	x2, [sp, #584]
    9548:	f9400001 	ldr	x1, [x0]
    954c:	eb010042 	subs	x2, x2, x1
    9550:	d2800001 	mov	x1, #0x0                   	// #0
    9554:	54ffd721 	b.ne	9038 <fwp_write+0x898>  // b.any
    9558:	f9413bf5 	ldr	x21, [sp, #624]
    955c:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    9560:	f9413ff6 	ldr	x22, [sp, #632]
    9564:	aa1403e0 	mov	x0, x20
    9568:	f94143f7 	ldr	x23, [sp, #640]
    956c:	912f2021 	add	x1, x1, #0xbc8
    9570:	f94147f8 	ldr	x24, [sp, #648]
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	17fffd0e 	b	89b0 <fwp_write+0x210>
    957c:	d0000001 	adrp	x1, b000 <__divti3+0x1a0>
    9580:	d2800042 	mov	x2, #0x2                   	// #2
    9584:	912c0021 	add	x1, x1, #0xb00
    9588:	17fffea3 	b	9014 <fwp_write+0x874>
    958c:	f9400a63 	ldr	x3, [x19, #16]
    9590:	8b030021 	add	x1, x1, x3
    9594:	17ffff66 	b	932c <fwp_write+0xb8c>
    9598:	f9400a61 	ldr	x1, [x19, #16]
    959c:	8b0102a1 	add	x1, x21, x1
    95a0:	17fffdb3 	b	8c6c <fwp_write+0x4cc>
    95a4:	f9400a63 	ldr	x3, [x19, #16]
    95a8:	8b030021 	add	x1, x1, x3
    95ac:	17ffff56 	b	9304 <fwp_write+0xb64>
    95b0:	b9404840 	ldr	w0, [x2, #72]
    95b4:	91001ff5 	add	x21, sp, #0x7
    95b8:	34ffa360 	cbz	w0, 8a24 <fwp_write+0x284>
    95bc:	52800503 	mov	w3, #0x28                  	// #40
    95c0:	aa1403e0 	mov	x0, x20
    95c4:	aa1503e1 	mov	x1, x21
    95c8:	d2800022 	mov	x2, #0x1                   	// #1
    95cc:	39001fe3 	strb	w3, [sp, #7]
    95d0:	97ffe7f0 	bl	3590 <buf_put>
    95d4:	b9401380 	ldr	w0, [x28, #16]
    95d8:	52800038 	mov	w24, #0x1                   	// #1
    95dc:	7100001f 	cmp	w0, #0x0
    95e0:	54ffa36c 	b.gt	8a4c <fwp_write+0x2ac>
    95e4:	17fffd32 	b	8aac <fwp_write+0x30c>
    95e8:	f9014bf9 	str	x25, [sp, #656]
    95ec:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x108b0>
    95f0:	f9014ffa 	str	x26, [sp, #664]
    95f4:	f9400676 	ldr	x22, [x19, #8]
    95f8:	91102333 	add	x19, x25, #0x408
    95fc:	91002273 	add	x19, x19, #0x8
    9600:	937ffed8 	asr	x24, x22, #63
    9604:	aa1802c0 	orr	x0, x22, x24
    9608:	b5000320 	cbnz	x0, 966c <fwp_write+0xecc>
    960c:	110006b5 	add	w21, w21, #0x1
    9610:	710016bf 	cmp	w21, #0x5
    9614:	54ffffc1 	b.ne	960c <fwp_write+0xe6c>  // b.any
    9618:	b7f80578 	tbnz	x24, #63, 96c4 <fwp_write+0xf24>
    961c:	910023f3 	add	x19, sp, #0x8
    9620:	aa1603e2 	mov	x2, x22
    9624:	aa1303e0 	mov	x0, x19
    9628:	d2800003 	mov	x3, #0x0                   	// #0
    962c:	97ffe5fd 	bl	2e20 <fwp_fmt_u128>
    9630:	910123f5 	add	x21, sp, #0x48
    9634:	d0000003 	adrp	x3, b000 <__divti3+0x1a0>
    9638:	aa1303e4 	mov	x4, x19
    963c:	aa1503e0 	mov	x0, x21
    9640:	912f0063 	add	x3, x3, #0xbc0
    9644:	d2804002 	mov	x2, #0x200                 	// #512
    9648:	52800041 	mov	w1, #0x2                   	// #2
    964c:	97ffe435 	bl	2720 <__sprintf_chk@plt>
    9650:	aa1503e0 	mov	x0, x21
    9654:	97ffe42f 	bl	2710 <strlen@plt>
    9658:	aa1503e1 	mov	x1, x21
    965c:	aa0003e2 	mov	x2, x0
    9660:	aa1403e0 	mov	x0, x20
    9664:	97ffe7cb 	bl	3590 <buf_put>
    9668:	17fffe47 	b	8f84 <fwp_write+0x7e4>
    966c:	f9400277 	ldr	x23, [x19]
    9670:	aa1603e0 	mov	x0, x22
    9674:	aa1803e1 	mov	x1, x24
    9678:	aa1703e2 	mov	x2, x23
    967c:	937ffefa 	asr	x26, x23, #63
    9680:	aa1a03e3 	mov	x3, x26
    9684:	940006d7 	bl	b1e0 <__modti3>
    9688:	aa010000 	orr	x0, x0, x1
    968c:	b40002c0 	cbz	x0, 96e4 <fwp_write+0xf44>
    9690:	110006b5 	add	w21, w21, #0x1
    9694:	91004273 	add	x19, x19, #0x10
    9698:	710016bf 	cmp	w21, #0x5
    969c:	54fffe81 	b.ne	966c <fwp_write+0xecc>  // b.any
    96a0:	17ffffde 	b	9618 <fwp_write+0xe78>
    96a4:	f9400a60 	ldr	x0, [x19, #16]
    96a8:	8b000021 	add	x1, x1, x0
    96ac:	17fffd75 	b	8c80 <fwp_write+0x4e0>
    96b0:	528c29c0 	mov	w0, #0x614e                	// #24910
    96b4:	910123f5 	add	x21, sp, #0x48
    96b8:	72a009c0 	movk	w0, #0x4e, lsl #16
    96bc:	b9004be0 	str	w0, [sp, #72]
    96c0:	17fffda2 	b	8d48 <fwp_write+0x5a8>
    96c4:	528005a1 	mov	w1, #0x2d                  	// #45
    96c8:	eb1603e2 	negs	x2, x22
    96cc:	da1803e3 	ngc	x3, x24
    96d0:	910027e0 	add	x0, sp, #0x9
    96d4:	910023f3 	add	x19, sp, #0x8
    96d8:	390023e1 	strb	w1, [sp, #8]
    96dc:	97ffe5d1 	bl	2e20 <fwp_fmt_u128>
    96e0:	17ffffd4 	b	9630 <fwp_write+0xe90>
    96e4:	aa1703e2 	mov	x2, x23
    96e8:	aa1a03e3 	mov	x3, x26
    96ec:	aa1603e0 	mov	x0, x22
    96f0:	aa1803e1 	mov	x1, x24
    96f4:	940005db 	bl	ae60 <__divti3>
    96f8:	aa0003e2 	mov	x2, x0
    96fc:	aa0103e3 	mov	x3, x1
    9700:	b7f80201 	tbnz	x1, #63, 9740 <fwp_write+0xfa0>
    9704:	910023f3 	add	x19, sp, #0x8
    9708:	aa1303e0 	mov	x0, x19
    970c:	97ffe5c5 	bl	2e20 <fwp_fmt_u128>
    9710:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9714:	91102339 	add	x25, x25, #0x408
    9718:	910123f5 	add	x21, sp, #0x48
    971c:	aa1303e4 	mov	x4, x19
    9720:	aa1503e0 	mov	x0, x21
    9724:	d0000003 	adrp	x3, b000 <__divti3+0x1a0>
    9728:	f8616b25 	ldr	x5, [x25, x1]
    972c:	912ee063 	add	x3, x3, #0xbb8
    9730:	d2804002 	mov	x2, #0x200                 	// #512
    9734:	52800041 	mov	w1, #0x2                   	// #2
    9738:	97ffe3fa 	bl	2720 <__sprintf_chk@plt>
    973c:	17ffffc5 	b	9650 <fwp_write+0xeb0>
    9740:	528005a4 	mov	w4, #0x2d                  	// #45
    9744:	eb0003e2 	negs	x2, x0
    9748:	da0103e3 	ngc	x3, x1
    974c:	910027e0 	add	x0, sp, #0x9
    9750:	910023f3 	add	x19, sp, #0x8
    9754:	390023e4 	strb	w4, [sp, #8]
    9758:	97ffe5b2 	bl	2e20 <fwp_fmt_u128>
    975c:	17ffffed 	b	9710 <fwp_write+0xf70>
    9760:	f9013bf5 	str	x21, [sp, #624]
    9764:	f9013ff6 	str	x22, [sp, #632]
    9768:	f90143f7 	str	x23, [sp, #640]
    976c:	f90147f8 	str	x24, [sp, #648]
    9770:	f9014bf9 	str	x25, [sp, #656]
    9774:	f9014ffa 	str	x26, [sp, #664]
    9778:	f90153fb 	str	x27, [sp, #672]
    977c:	f90157fc 	str	x28, [sp, #680]
    9780:	fd015be8 	str	d8, [sp, #688]
    9784:	fd015fe9 	str	d9, [sp, #696]
    9788:	97ffe43e 	bl	2880 <__stack_chk_fail@plt>
    978c:	d503201f 	nop

0000000000009790 <fwp_main_thread>:
    9790:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    9794:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9798:	91174001 	add	x1, x0, #0x5d0
    979c:	910003fd 	mov	x29, sp
    97a0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    97a4:	f947f400 	ldr	x0, [x0, #4072]
    97a8:	a90153f3 	stp	x19, x20, [sp, #16]
    97ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    97b0:	a90363f7 	stp	x23, x24, [sp, #48]
    97b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    97b8:	a90573fb 	stp	x27, x28, [sp, #80]
    97bc:	fd0033e8 	str	d8, [sp, #96]
    97c0:	d10603ff 	sub	sp, sp, #0x180
    97c4:	b953a421 	ldr	w1, [x1, #5028]
    97c8:	f9400002 	ldr	x2, [x0]
    97cc:	f81f83a2 	stur	x2, [x29, #-8]
    97d0:	d2800002 	mov	x2, #0x0                   	// #0
    97d4:	34006641 	cbz	w1, a49c <fwp_main_thread+0xd0c>
    97d8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    97dc:	91174000 	add	x0, x0, #0x5d0
    97e0:	b953a800 	ldr	w0, [x0, #5032]
    97e4:	35006540 	cbnz	w0, a48c <fwp_main_thread+0xcfc>
    97e8:	f00000a0 	adrp	x0, 20000 <__data_start>
    97ec:	f00000a2 	adrp	x2, 20000 <__data_start>
    97f0:	9101c013 	add	x19, x0, #0x70
    97f4:	910fc042 	add	x2, x2, #0x3f0
    97f8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    97fc:	d2a00024 	mov	x4, #0x10000               	// #65536
    9800:	d10383bb 	sub	x27, x29, #0xe0
    9804:	d103e3b8 	sub	x24, x29, #0xf8
    9808:	aa1b03e0 	mov	x0, x27
    980c:	d2800001 	mov	x1, #0x0                   	// #0
    9810:	f81203a2 	stur	x2, [x29, #-224]
    9814:	b81283bf 	stur	wzr, [x29, #-216]
    9818:	f81303a4 	stur	x4, [x29, #-208]
    981c:	a9018e78 	stp	x24, x3, [x19, #24]
    9820:	97ffe3b0 	bl	26e0 <sigaltstack@plt>
    9824:	3500a6c0 	cbnz	w0, acfc <fwp_main_thread+0x156c>
    9828:	4f000400 	movi	v0.4s, #0x0
    982c:	d10263a0 	sub	x0, x29, #0x98
    9830:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    9834:	9101c021 	add	x1, x1, #0x70
    9838:	f81603a1 	stur	x1, [x29, #-160]
    983c:	52800082 	mov	w2, #0x4                   	// #4
    9840:	72a10002 	movk	w2, #0x800, lsl #16
    9844:	d10283b6 	sub	x22, x29, #0xa0
    9848:	3d802000 	str	q0, [x0, #128]
    984c:	b81e83a2 	stur	w2, [x29, #-24]
    9850:	ad000000 	stp	q0, q0, [x0]
    9854:	ad010000 	stp	q0, q0, [x0, #32]
    9858:	ad020000 	stp	q0, q0, [x0, #64]
    985c:	ad030000 	stp	q0, q0, [x0, #96]
    9860:	97ffe3f8 	bl	2840 <sigemptyset@plt>
    9864:	3500a4c0 	cbnz	w0, acfc <fwp_main_thread+0x156c>
    9868:	aa1603e1 	mov	x1, x22
    986c:	d2800002 	mov	x2, #0x0                   	// #0
    9870:	52800160 	mov	w0, #0xb                   	// #11
    9874:	97ffe40b 	bl	28a0 <sigaction@plt>
    9878:	3500a420 	cbnz	w0, acfc <fwp_main_thread+0x156c>
    987c:	aa1603e1 	mov	x1, x22
    9880:	d2800002 	mov	x2, #0x0                   	// #0
    9884:	528000e0 	mov	w0, #0x7                   	// #7
    9888:	97ffe406 	bl	28a0 <sigaction@plt>
    988c:	3500a380 	cbnz	w0, acfc <fwp_main_thread+0x156c>
    9890:	b9434a60 	ldr	w0, [x19, #840]
    9894:	34001480 	cbz	w0, 9b24 <fwp_main_thread+0x394>
    9898:	f00000a0 	adrp	x0, 20000 <__data_start>
    989c:	9101c000 	add	x0, x0, #0x70
    98a0:	b9434c01 	ldr	w1, [x0, #844]
    98a4:	34001541 	cbz	w1, 9b4c <fwp_main_thread+0x3bc>
    98a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98ac:	9101c015 	add	x21, x0, #0x70
    98b0:	f9400ab4 	ldr	x20, [x21, #16]
    98b4:	b4000c54 	cbz	x20, 9a3c <fwp_main_thread+0x2ac>
    98b8:	aa1403f3 	mov	x19, x20
    98bc:	91010297 	add	x23, x20, #0x40
    98c0:	39414a98 	ldrb	w24, [x20, #82]
    98c4:	52800036 	mov	w22, #0x1                   	// #1
    98c8:	39014a96 	strb	w22, [x20, #82]
    98cc:	f9401680 	ldr	x0, [x20, #40]
    98d0:	b4000620 	cbz	x0, 9994 <fwp_main_thread+0x204>
    98d4:	f9403281 	ldr	x1, [x20, #96]
    98d8:	39414680 	ldrb	w0, [x20, #81]
    98dc:	b4000e81 	cbz	x1, 9aac <fwp_main_thread+0x31c>
    98e0:	36000d40 	tbz	w0, #0, 9a88 <fwp_main_thread+0x2f8>
    98e4:	39414a62 	ldrb	w2, [x19, #82]
    98e8:	f9402281 	ldr	x1, [x20, #64]
    98ec:	37001082 	tbnz	w2, #0, 9afc <fwp_main_thread+0x36c>
    98f0:	f9403260 	ldr	x0, [x19, #96]
    98f4:	a911fe77 	stp	x23, xzr, [x19, #280]
    98f8:	f9009661 	str	x1, [x19, #296]
    98fc:	b4000041 	cbz	x1, 9904 <fwp_main_thread+0x174>
    9900:	f9009033 	str	x19, [x1, #288]
    9904:	f9002293 	str	x19, [x20, #64]
    9908:	b4000100 	cbz	x0, 9928 <fwp_main_thread+0x198>
    990c:	f9406ea1 	ldr	x1, [x21, #216]
    9910:	39015676 	strb	w22, [x19, #85]
    9914:	f9003660 	str	x0, [x19, #104]
    9918:	a910867f 	stp	xzr, x1, [x19, #264]
    991c:	b4000041 	cbz	x1, 9924 <fwp_main_thread+0x194>
    9920:	f9008433 	str	x19, [x1, #264]
    9924:	f9006eb3 	str	x19, [x21, #216]
    9928:	39015a7f 	strb	wzr, [x19, #86]
    992c:	97fff276 	bl	6304 <fwp_block>
    9930:	f9408e62 	ldr	x2, [x19, #280]
    9934:	b4000142 	cbz	x2, 995c <fwp_main_thread+0x1cc>
    9938:	a9520261 	ldp	x1, x0, [x19, #288]
    993c:	b4000ec1 	cbz	x1, 9b14 <fwp_main_thread+0x384>
    9940:	f9009420 	str	x0, [x1, #296]
    9944:	f9409660 	ldr	x0, [x19, #296]
    9948:	b4000040 	cbz	x0, 9950 <fwp_main_thread+0x1c0>
    994c:	f9009001 	str	x1, [x0, #288]
    9950:	91080260 	add	x0, x19, #0x200
    9954:	f900967f 	str	xzr, [x19, #296]
    9958:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    995c:	39415660 	ldrb	w0, [x19, #85]
    9960:	f9400aa1 	ldr	x1, [x21, #16]
    9964:	36000c80 	tbz	w0, #0, 9af4 <fwp_main_thread+0x364>
    9968:	a9508262 	ldp	x2, x0, [x19, #264]
    996c:	b4000d82 	cbz	x2, 9b1c <fwp_main_thread+0x38c>
    9970:	f9008840 	str	x0, [x2, #272]
    9974:	b4000040 	cbz	x0, 997c <fwp_main_thread+0x1ec>
    9978:	f9008402 	str	x2, [x0, #264]
    997c:	91080260 	add	x0, x19, #0x200
    9980:	3901567f 	strb	wzr, [x19, #85]
    9984:	aa0103f3 	mov	x19, x1
    9988:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    998c:	f9401680 	ldr	x0, [x20, #40]
    9990:	b5fffa20 	cbnz	x0, 98d4 <fwp_main_thread+0x144>
    9994:	f00000a0 	adrp	x0, 20000 <__data_start>
    9998:	9101c000 	add	x0, x0, #0x70
    999c:	39014a98 	strb	w24, [x20, #82]
    99a0:	f9419400 	ldr	x0, [x0, #808]
    99a4:	b4000520 	cbz	x0, 9a48 <fwp_main_thread+0x2b8>
    99a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    99ac:	9101c000 	add	x0, x0, #0x70
    99b0:	f941b001 	ldr	x1, [x0, #864]
    99b4:	b903581f 	str	wzr, [x0, #856]
    99b8:	eb13003f 	cmp	x1, x19
    99bc:	54000641 	b.ne	9a84 <fwp_main_thread+0x2f4>  // b.any
    99c0:	b4004a53 	cbz	x19, a308 <fwp_main_thread+0xb78>
    99c4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99c8:	9101c000 	add	x0, x0, #0x70
    99cc:	52800021 	mov	w1, #0x1                   	// #1
    99d0:	39014a61 	strb	w1, [x19, #82]
    99d4:	f9418005 	ldr	x5, [x0, #768]
    99d8:	b4004985 	cbz	x5, a308 <fwp_main_thread+0xb78>
    99dc:	394140a0 	ldrb	w0, [x5, #80]
    99e0:	37000060 	tbnz	w0, #0, 99ec <fwp_main_thread+0x25c>
    99e4:	aa0503e0 	mov	x0, x5
    99e8:	97ffe742 	bl	36f0 <fwp_cancel_tree.part.0>
    99ec:	f9409ca5 	ldr	x5, [x5, #312]
    99f0:	b5ffff65 	cbnz	x5, 99dc <fwp_main_thread+0x24c>
    99f4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99f8:	9101c014 	add	x20, x0, #0x70
    99fc:	52800035 	mov	w21, #0x1                   	// #1
    9a00:	f9402a60 	ldr	x0, [x19, #80]
    9a04:	f2001c1f 	tst	x0, #0xff000000ff
    9a08:	540000e1 	b.ne	9a24 <fwp_main_thread+0x294>  // b.any
    9a0c:	f9403e80 	ldr	x0, [x20, #120]
    9a10:	39015275 	strb	w21, [x19, #84]
    9a14:	f900827f 	str	xzr, [x19, #256]
    9a18:	b40046e0 	cbz	x0, a2f4 <fwp_main_thread+0xb64>
    9a1c:	f9008013 	str	x19, [x0, #256]
    9a20:	f9003e93 	str	x19, [x20, #120]
    9a24:	97fff238 	bl	6304 <fwp_block>
    9a28:	97fff1ca 	bl	6150 <fwp_free_zombie>
    9a2c:	f9418280 	ldr	x0, [x20, #768]
    9a30:	b40046c0 	cbz	x0, a308 <fwp_main_thread+0xb78>
    9a34:	f941b293 	ldr	x19, [x20, #864]
    9a38:	17fffff2 	b	9a00 <fwp_main_thread+0x270>
    9a3c:	f94196a0 	ldr	x0, [x21, #808]
    9a40:	b50045e0 	cbnz	x0, a2fc <fwp_main_thread+0xb6c>
    9a44:	d2800013 	mov	x19, #0x0                   	// #0
    9a48:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a4c:	9101c014 	add	x20, x0, #0x70
    9a50:	f9419e80 	ldr	x0, [x20, #824]
    9a54:	b5fffaa0 	cbnz	x0, 99a8 <fwp_main_thread+0x218>
    9a58:	f9419280 	ldr	x0, [x20, #800]
    9a5c:	97ffec05 	bl	4a70 <fwp_mem_free>
    9a60:	f901929f 	str	xzr, [x20, #800]
    9a64:	f9019a9f 	str	xzr, [x20, #816]
    9a68:	f941b280 	ldr	x0, [x20, #864]
    9a6c:	b4009e13 	cbz	x19, ae2c <fwp_main_thread+0x169c>
    9a70:	f900567f 	str	xzr, [x19, #168]
    9a74:	f9005e7f 	str	xzr, [x19, #184]
    9a78:	b9035a9f 	str	wzr, [x20, #856]
    9a7c:	eb00027f 	cmp	x19, x0
    9a80:	54fffa20 	b.eq	99c4 <fwp_main_thread+0x234>  // b.none
    9a84:	97ffe393 	bl	28d0 <abort@plt>
    9a88:	97ffe7be 	bl	3980 <fwp_now_ns>
    9a8c:	f9403281 	ldr	x1, [x20, #96]
    9a90:	eb01001f 	cmp	x0, x1
    9a94:	540000ab 	b.lt	9aa8 <fwp_main_thread+0x318>  // b.tstop
    9a98:	39414280 	ldrb	w0, [x20, #80]
    9a9c:	37000060 	tbnz	w0, #0, 9aa8 <fwp_main_thread+0x318>
    9aa0:	aa1403e0 	mov	x0, x20
    9aa4:	97ffe713 	bl	36f0 <fwp_cancel_tree.part.0>
    9aa8:	39414680 	ldrb	w0, [x20, #81]
    9aac:	39414a62 	ldrb	w2, [x19, #82]
    9ab0:	3707f1c0 	tbnz	w0, #0, 98e8 <fwp_main_thread+0x158>
    9ab4:	f9403280 	ldr	x0, [x20, #96]
    9ab8:	370001a2 	tbnz	w2, #0, 9aec <fwp_main_thread+0x35c>
    9abc:	f9403261 	ldr	x1, [x19, #96]
    9ac0:	b4000161 	cbz	x1, 9aec <fwp_main_thread+0x35c>
    9ac4:	b4008de0 	cbz	x0, ac80 <fwp_main_thread+0x14f0>
    9ac8:	eb01001f 	cmp	x0, x1
    9acc:	9a81d000 	csel	x0, x0, x1, le
    9ad0:	f9402281 	ldr	x1, [x20, #64]
    9ad4:	a911fe77 	stp	x23, xzr, [x19, #280]
    9ad8:	f9009661 	str	x1, [x19, #296]
    9adc:	b4000041 	cbz	x1, 9ae4 <fwp_main_thread+0x354>
    9ae0:	f9009033 	str	x19, [x1, #288]
    9ae4:	f9002293 	str	x19, [x20, #64]
    9ae8:	17ffff89 	b	990c <fwp_main_thread+0x17c>
    9aec:	f9402281 	ldr	x1, [x20, #64]
    9af0:	17ffff81 	b	98f4 <fwp_main_thread+0x164>
    9af4:	aa0103f3 	mov	x19, x1
    9af8:	17ffff75 	b	98cc <fwp_main_thread+0x13c>
    9afc:	a911fe77 	stp	x23, xzr, [x19, #280]
    9b00:	f9009661 	str	x1, [x19, #296]
    9b04:	b4000041 	cbz	x1, 9b0c <fwp_main_thread+0x37c>
    9b08:	f9009033 	str	x19, [x1, #288]
    9b0c:	f9002293 	str	x19, [x20, #64]
    9b10:	17ffff86 	b	9928 <fwp_main_thread+0x198>
    9b14:	f9000040 	str	x0, [x2]
    9b18:	17ffff8c 	b	9948 <fwp_main_thread+0x1b8>
    9b1c:	f9006ea0 	str	x0, [x21, #216]
    9b20:	17ffff95 	b	9974 <fwp_main_thread+0x1e4>
    9b24:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9b28:	91058000 	add	x0, x0, #0x160
    9b2c:	94000689 	bl	b550 <atexit>
    9b30:	350090c0 	cbnz	w0, ad48 <fwp_main_thread+0x15b8>
    9b34:	52800020 	mov	w0, #0x1                   	// #1
    9b38:	b9034a60 	str	w0, [x19, #840]
    9b3c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b40:	9101c000 	add	x0, x0, #0x70
    9b44:	b9434c01 	ldr	w1, [x0, #844]
    9b48:	35ffeb01 	cbnz	w1, 98a8 <fwp_main_thread+0x118>
    9b4c:	f9418803 	ldr	x3, [x0, #784]
    9b50:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9b54:	f9018818 	str	x24, [x0, #784]
    9b58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b5c:	91174033 	add	x19, x1, #0x5d0
    9b60:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0xa80>
    9b64:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9b68:	d2800015 	mov	x21, #0x0                   	// #0
    9b6c:	fd41a828 	ldr	d8, [x1, #848]
    9b70:	913d4042 	add	x2, x2, #0xf50
    9b74:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    9b78:	d280401a 	mov	x26, #0x200                 	// #512
    9b7c:	91290021 	add	x1, x1, #0xa40
    9b80:	d2800014 	mov	x20, #0x0                   	// #0
    9b84:	52800037 	mov	w23, #0x1                   	// #1
    9b88:	a9308ba3 	stp	x3, x2, [x29, #-248]
    9b8c:	a931ffbb 	stp	x27, xzr, [x29, #-232]
    9b90:	a93307bf 	stp	xzr, x1, [x29, #-208]
    9b94:	f91f7816 	str	x22, [x0, #16112]
    9b98:	f91f7c1b 	str	x27, [x0, #16120]
    9b9c:	b953a660 	ldr	w0, [x19, #5028]
    9ba0:	f1000759 	subs	x25, x26, #0x1
    9ba4:	f81283b9 	stur	x25, [x29, #-216]
    9ba8:	da1f0296 	sbc	x22, x20, xzr
    9bac:	aa1903fa 	mov	x26, x25
    9bb0:	aa1603f4 	mov	x20, x22
    9bb4:	340048a0 	cbz	w0, a4c8 <fwp_main_thread+0xd38>
    9bb8:	397e8a60 	ldrb	w0, [x19, #4002]
    9bbc:	910f0001 	add	x1, x0, #0x3c0
    9bc0:	8b000400 	add	x0, x0, x0, lsl #1
    9bc4:	b8617a7b 	ldr	w27, [x19, x1, lsl #2]
    9bc8:	8b000e61 	add	x1, x19, x0, lsl #3
    9bcc:	f8607a78 	ldr	x24, [x19, x0, lsl #3]
    9bd0:	2a1b03fc 	mov	w28, w27
    9bd4:	b4004698 	cbz	x24, a4a4 <fwp_main_thread+0xd14>
    9bd8:	f9400301 	ldr	x1, [x24]
    9bdc:	aa2103e1 	mvn	x1, x1
    9be0:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9be4:	f100639f 	cmp	x28, #0x18
    9be8:	540000e9 	b.ls	9c04 <fwp_main_thread+0x474>  // b.plast
    9bec:	d1006782 	sub	x2, x28, #0x19
    9bf0:	91006300 	add	x0, x24, #0x18
    9bf4:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9bf8:	52800001 	mov	w1, #0x0                   	// #0
    9bfc:	91002042 	add	x2, x2, #0x8
    9c00:	97ffe314 	bl	2850 <memset@plt>
    9c04:	f94a1260 	ldr	x0, [x19, #5152]
    9c08:	ab1c0000 	adds	x0, x0, x28
    9c0c:	54008762 	b.cs	acf8 <fwp_main_thread+0x1568>  // b.hs, b.nlast
    9c10:	f94a1661 	ldr	x1, [x19, #5160]
    9c14:	f90a1260 	str	x0, [x19, #5152]
    9c18:	eb01001f 	cmp	x0, x1
    9c1c:	54000049 	b.ls	9c24 <fwp_main_thread+0x494>  // b.plast
    9c20:	f90a1660 	str	x0, [x19, #5160]
    9c24:	1e630361 	ucvtf	d1, w27
    9c28:	fd4a1e60 	ldr	d0, [x19, #5176]
    9c2c:	1e612800 	fadd	d0, d0, d1
    9c30:	fd0a1e60 	str	d0, [x19, #5176]
    9c34:	a900d719 	stp	x25, x21, [x24, #8]
    9c38:	aa1803f5 	mov	x21, x24
    9c3c:	fd000308 	str	d8, [x24]
    9c40:	f949da62 	ldr	x2, [x19, #5040]
    9c44:	f949ee60 	ldr	x0, [x19, #5080]
    9c48:	cb020302 	sub	x2, x24, x2
    9c4c:	eb00405f 	cmp	x2, x0, lsl #16
    9c50:	54000302 	b.cs	9cb0 <fwp_main_thread+0x520>  // b.hs, b.nlast
    9c54:	d350fc40 	lsr	x0, x2, #16
    9c58:	f949fe64 	ldr	x4, [x19, #5112]
    9c5c:	8b000800 	add	x0, x0, x0, lsl #2
    9c60:	d37df001 	lsl	x1, x0, #3
    9c64:	8b010080 	add	x0, x4, x1
    9c68:	f940101c 	ldr	x28, [x0, #32]
    9c6c:	b400023c 	cbz	x28, 9cb0 <fwp_main_thread+0x520>
    9c70:	38616881 	ldrb	w1, [x4, x1]
    9c74:	7100083f 	cmp	w1, #0x2
    9c78:	54004320 	b.eq	a4dc <fwp_main_thread+0xd4c>  // b.none
    9c7c:	7100043f 	cmp	w1, #0x1
    9c80:	54000181 	b.ne	9cb0 <fwp_main_thread+0x520>  // b.any
    9c84:	29430004 	ldp	w4, w0, [x0, #24]
    9c88:	92403c41 	and	x1, x2, #0xffff
    9c8c:	9b047c21 	mul	x1, x1, x4
    9c90:	d360fc21 	lsr	x1, x1, #32
    9c94:	eb00003f 	cmp	x1, x0
    9c98:	540000c2 	b.cs	9cb0 <fwp_main_thread+0x520>  // b.hs, b.nlast
    9c9c:	8b01039c 	add	x28, x28, x1
    9ca0:	39400380 	ldrb	w0, [x28]
    9ca4:	7103fc1f 	cmp	w0, #0xff
    9ca8:	54004240 	b.eq	a4f0 <fwp_main_thread+0xd60>  // b.none
    9cac:	39000397 	strb	w23, [x28]
    9cb0:	f81203b8 	stur	x24, [x29, #-224]
    9cb4:	aa160339 	orr	x25, x25, x22
    9cb8:	b5fff739 	cbnz	x25, 9b9c <fwp_main_thread+0x40c>
    9cbc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cc0:	d10303a1 	sub	x1, x29, #0xc0
    9cc4:	f85083a3 	ldur	x3, [x29, #-248]
    9cc8:	f95f7816 	ldr	x22, [x0, #16112]
    9ccc:	f91f7418 	str	x24, [x0, #16104]
    9cd0:	f95f7c1b 	ldr	x27, [x0, #16120]
    9cd4:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    9cd8:	3dc0d800 	ldr	q0, [x0, #864]
    9cdc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ce0:	9101c002 	add	x2, x0, #0x70
    9ce4:	52800020 	mov	w0, #0x1                   	// #1
    9ce8:	3c9403a0 	stur	q0, [x29, #-192]
    9cec:	f9018843 	str	x3, [x2, #784]
    9cf0:	97ffee44 	bl	5600 <fwp_data.part.0.constprop.0>
    9cf4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9cf8:	91174022 	add	x2, x1, #0x5d0
    9cfc:	aa0003f4 	mov	x20, x0
    9d00:	f949d841 	ldr	x1, [x2, #5040]
    9d04:	f949ec40 	ldr	x0, [x2, #5080]
    9d08:	cb010281 	sub	x1, x20, x1
    9d0c:	eb00403f 	cmp	x1, x0, lsl #16
    9d10:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d14:	f95f7406 	ldr	x6, [x0, #16104]
    9d18:	54000322 	b.cs	9d7c <fwp_main_thread+0x5ec>  // b.hs, b.nlast
    9d1c:	d350fc20 	lsr	x0, x1, #16
    9d20:	f949fc43 	ldr	x3, [x2, #5112]
    9d24:	8b000800 	add	x0, x0, x0, lsl #2
    9d28:	d37df002 	lsl	x2, x0, #3
    9d2c:	8b020060 	add	x0, x3, x2
    9d30:	f9401013 	ldr	x19, [x0, #32]
    9d34:	b4000253 	cbz	x19, 9d7c <fwp_main_thread+0x5ec>
    9d38:	38626862 	ldrb	w2, [x3, x2]
    9d3c:	7100085f 	cmp	w2, #0x2
    9d40:	54007880 	b.eq	ac50 <fwp_main_thread+0x14c0>  // b.none
    9d44:	7100045f 	cmp	w2, #0x1
    9d48:	540001a1 	b.ne	9d7c <fwp_main_thread+0x5ec>  // b.any
    9d4c:	29430002 	ldp	w2, w0, [x0, #24]
    9d50:	92403c21 	and	x1, x1, #0xffff
    9d54:	9b027c21 	mul	x1, x1, x2
    9d58:	d360fc21 	lsr	x1, x1, #32
    9d5c:	eb00003f 	cmp	x1, x0
    9d60:	540000e2 	b.cs	9d7c <fwp_main_thread+0x5ec>  // b.hs, b.nlast
    9d64:	8b010273 	add	x19, x19, x1
    9d68:	39400260 	ldrb	w0, [x19]
    9d6c:	7103fc1f 	cmp	w0, #0xff
    9d70:	540078c0 	b.eq	ac88 <fwp_main_thread+0x14f8>  // b.none
    9d74:	52800020 	mov	w0, #0x1                   	// #1
    9d78:	39000260 	strb	w0, [x19]
    9d7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d80:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9d84:	aa1603e1 	mov	x1, x22
    9d88:	a93653a2 	stp	x2, x20, [x29, #-160]
    9d8c:	f91f7c06 	str	x6, [x0, #16120]
    9d90:	52800020 	mov	w0, #0x1                   	// #1
    9d94:	97ffee1b 	bl	5600 <fwp_data.part.0.constprop.0>
    9d98:	aa0003f4 	mov	x20, x0
    9d9c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9da0:	91174022 	add	x2, x1, #0x5d0
    9da4:	f949d841 	ldr	x1, [x2, #5040]
    9da8:	f949ec40 	ldr	x0, [x2, #5080]
    9dac:	cb010281 	sub	x1, x20, x1
    9db0:	eb00403f 	cmp	x1, x0, lsl #16
    9db4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9db8:	f95f7c06 	ldr	x6, [x0, #16120]
    9dbc:	54000322 	b.cs	9e20 <fwp_main_thread+0x690>  // b.hs, b.nlast
    9dc0:	d350fc20 	lsr	x0, x1, #16
    9dc4:	f949fc43 	ldr	x3, [x2, #5112]
    9dc8:	8b000800 	add	x0, x0, x0, lsl #2
    9dcc:	d37df002 	lsl	x2, x0, #3
    9dd0:	8b020060 	add	x0, x3, x2
    9dd4:	f9401013 	ldr	x19, [x0, #32]
    9dd8:	b4000253 	cbz	x19, 9e20 <fwp_main_thread+0x690>
    9ddc:	38626862 	ldrb	w2, [x3, x2]
    9de0:	7100085f 	cmp	w2, #0x2
    9de4:	54007420 	b.eq	ac68 <fwp_main_thread+0x14d8>  // b.none
    9de8:	7100045f 	cmp	w2, #0x1
    9dec:	540001a1 	b.ne	9e20 <fwp_main_thread+0x690>  // b.any
    9df0:	29430002 	ldp	w2, w0, [x0, #24]
    9df4:	92403c21 	and	x1, x1, #0xffff
    9df8:	9b027c21 	mul	x1, x1, x2
    9dfc:	d360fc21 	lsr	x1, x1, #32
    9e00:	eb00003f 	cmp	x1, x0
    9e04:	540000e2 	b.cs	9e20 <fwp_main_thread+0x690>  // b.hs, b.nlast
    9e08:	8b010273 	add	x19, x19, x1
    9e0c:	39400260 	ldrb	w0, [x19]
    9e10:	7103fc1f 	cmp	w0, #0xff
    9e14:	54007480 	b.eq	aca4 <fwp_main_thread+0x1514>  // b.none
    9e18:	52800020 	mov	w0, #0x1                   	// #1
    9e1c:	39000260 	strb	w0, [x19]
    9e20:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9e28:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9e2c:	d102c3a1 	sub	x1, x29, #0xb0
    9e30:	a93553a2 	stp	x2, x20, [x29, #-176]
    9e34:	f91f7c06 	str	x6, [x0, #16120]
    9e38:	52800020 	mov	w0, #0x1                   	// #1
    9e3c:	97ffedf1 	bl	5600 <fwp_data.part.0.constprop.0>
    9e40:	aa0003f6 	mov	x22, x0
    9e44:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9e48:	91174023 	add	x3, x1, #0x5d0
    9e4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e50:	f949ec62 	ldr	x2, [x3, #5080]
    9e54:	f949d861 	ldr	x1, [x3, #5040]
    9e58:	d370bc42 	lsl	x2, x2, #16
    9e5c:	cb0102c1 	sub	x1, x22, x1
    9e60:	f95f7c06 	ldr	x6, [x0, #16120]
    9e64:	eb02003f 	cmp	x1, x2
    9e68:	540003e2 	b.cs	9ee4 <fwp_main_thread+0x754>  // b.hs, b.nlast
    9e6c:	d350fc20 	lsr	x0, x1, #16
    9e70:	f949fc64 	ldr	x4, [x3, #5112]
    9e74:	8b000800 	add	x0, x0, x0, lsl #2
    9e78:	d37df003 	lsl	x3, x0, #3
    9e7c:	8b030080 	add	x0, x4, x3
    9e80:	f9401013 	ldr	x19, [x0, #32]
    9e84:	b4000313 	cbz	x19, 9ee4 <fwp_main_thread+0x754>
    9e88:	38636883 	ldrb	w3, [x4, x3]
    9e8c:	7100087f 	cmp	w3, #0x2
    9e90:	54006e60 	b.eq	ac5c <fwp_main_thread+0x14cc>  // b.none
    9e94:	7100047f 	cmp	w3, #0x1
    9e98:	54000261 	b.ne	9ee4 <fwp_main_thread+0x754>  // b.any
    9e9c:	29430004 	ldp	w4, w0, [x0, #24]
    9ea0:	92403c23 	and	x3, x1, #0xffff
    9ea4:	9b047c63 	mul	x3, x3, x4
    9ea8:	d360fc63 	lsr	x3, x3, #32
    9eac:	eb00007f 	cmp	x3, x0
    9eb0:	540001a2 	b.cs	9ee4 <fwp_main_thread+0x754>  // b.hs, b.nlast
    9eb4:	8b030273 	add	x19, x19, x3
    9eb8:	39400260 	ldrb	w0, [x19]
    9ebc:	7103fc1f 	cmp	w0, #0xff
    9ec0:	54007000 	b.eq	acc0 <fwp_main_thread+0x1530>  // b.none
    9ec4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ec8:	91174000 	add	x0, x0, #0x5d0
    9ecc:	52800021 	mov	w1, #0x1                   	// #1
    9ed0:	39000261 	strb	w1, [x19]
    9ed4:	f949ec02 	ldr	x2, [x0, #5080]
    9ed8:	f949d801 	ldr	x1, [x0, #5040]
    9edc:	d370bc42 	lsl	x2, x2, #16
    9ee0:	cb0102c1 	sub	x1, x22, x1
    9ee4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ee8:	f00000a5 	adrp	x5, 20000 <__data_start>
    9eec:	910040b7 	add	x23, x5, #0x10
    9ef0:	d10403b3 	sub	x19, x29, #0x100
    9ef4:	910102f7 	add	x23, x23, #0x40
    9ef8:	f91f5406 	str	x6, [x0, #16040]
    9efc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f00:	9101c01c 	add	x28, x0, #0x70
    9f04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f08:	f91f4c06 	str	x6, [x0, #16024]
    9f0c:	aa1703e6 	mov	x6, x23
    9f10:	f91f5005 	str	x5, [x0, #16032]
    9f14:	f91f581b 	str	x27, [x0, #16048]
    9f18:	f91f5c16 	str	x22, [x0, #16056]
    9f1c:	eb02003f 	cmp	x1, x2
    9f20:	54000382 	b.cs	9f90 <fwp_main_thread+0x800>  // b.hs, b.nlast
    9f24:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9f28:	91174002 	add	x2, x0, #0x5d0
    9f2c:	d350fc20 	lsr	x0, x1, #16
    9f30:	f949fc44 	ldr	x4, [x2, #5112]
    9f34:	8b000800 	add	x0, x0, x0, lsl #2
    9f38:	d37df002 	lsl	x2, x0, #3
    9f3c:	8b020083 	add	x3, x4, x2
    9f40:	f9401060 	ldr	x0, [x3, #32]
    9f44:	b4000260 	cbz	x0, 9f90 <fwp_main_thread+0x800>
    9f48:	38626882 	ldrb	w2, [x4, x2]
    9f4c:	7100085f 	cmp	w2, #0x2
    9f50:	54006920 	b.eq	ac74 <fwp_main_thread+0x14e4>  // b.none
    9f54:	7100045f 	cmp	w2, #0x1
    9f58:	540001c1 	b.ne	9f90 <fwp_main_thread+0x800>  // b.any
    9f5c:	29430864 	ldp	w4, w2, [x3, #24]
    9f60:	92403c21 	and	x1, x1, #0xffff
    9f64:	9b047c21 	mul	x1, x1, x4
    9f68:	d360fc21 	lsr	x1, x1, #32
    9f6c:	eb02003f 	cmp	x1, x2
    9f70:	54000102 	b.cs	9f90 <fwp_main_thread+0x800>  // b.hs, b.nlast
    9f74:	8b010000 	add	x0, x0, x1
    9f78:	39400001 	ldrb	w1, [x0]
    9f7c:	340000a1 	cbz	w1, 9f90 <fwp_main_thread+0x800>
    9f80:	7103f43f 	cmp	w1, #0xfd
    9f84:	54006ac8 	b.hi	acdc <fwp_main_thread+0x154c>  // b.pmore
    9f88:	11000421 	add	w1, w1, #0x1
    9f8c:	39000001 	strb	w1, [x0]
    9f90:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f94:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9f98:	f9404783 	ldr	x3, [x28, #136]
    9f9c:	f95f5000 	ldr	x0, [x0, #16032]
    9fa0:	f95f5c21 	ldr	x1, [x1, #16056]
    9fa4:	91004000 	add	x0, x0, #0x10
    9fa8:	f81003a1 	stur	x1, [x29, #-256]
    9fac:	91010004 	add	x4, x0, #0x40
    9fb0:	b9404001 	ldr	w1, [x0, #64]
    9fb4:	d37be821 	lsl	x1, x1, #5
    9fb8:	8b010065 	add	x5, x3, x1
    9fbc:	f9400ca2 	ldr	x2, [x5, #24]
    9fc0:	b4006a42 	cbz	x2, ad08 <fwp_main_thread+0x1578>
    9fc4:	f9400c40 	ldr	x0, [x2, #24]
    9fc8:	b4005600 	cbz	x0, aa88 <fwp_main_thread+0x12f8>
    9fcc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9fd0:	91174002 	add	x2, x0, #0x5d0
    9fd4:	f949d841 	ldr	x1, [x2, #5040]
    9fd8:	f949ec40 	ldr	x0, [x2, #5080]
    9fdc:	cb0100c1 	sub	x1, x6, x1
    9fe0:	eb00403f 	cmp	x1, x0, lsl #16
    9fe4:	54000342 	b.cs	a04c <fwp_main_thread+0x8bc>  // b.hs, b.nlast
    9fe8:	d350fc20 	lsr	x0, x1, #16
    9fec:	f949fc44 	ldr	x4, [x2, #5112]
    9ff0:	8b000800 	add	x0, x0, x0, lsl #2
    9ff4:	d37df002 	lsl	x2, x0, #3
    9ff8:	8b020083 	add	x3, x4, x2
    9ffc:	f9401060 	ldr	x0, [x3, #32]
    a000:	b4000260 	cbz	x0, a04c <fwp_main_thread+0x8bc>
    a004:	38626882 	ldrb	w2, [x4, x2]
    a008:	7100085f 	cmp	w2, #0x2
    a00c:	54005b40 	b.eq	ab74 <fwp_main_thread+0x13e4>  // b.none
    a010:	7100045f 	cmp	w2, #0x1
    a014:	540001c1 	b.ne	a04c <fwp_main_thread+0x8bc>  // b.any
    a018:	29430864 	ldp	w4, w2, [x3, #24]
    a01c:	92403c21 	and	x1, x1, #0xffff
    a020:	9b047c21 	mul	x1, x1, x4
    a024:	d360fc21 	lsr	x1, x1, #32
    a028:	eb02003f 	cmp	x1, x2
    a02c:	54000102 	b.cs	a04c <fwp_main_thread+0x8bc>  // b.hs, b.nlast
    a030:	8b010000 	add	x0, x0, x1
    a034:	39400001 	ldrb	w1, [x0]
    a038:	340000a1 	cbz	w1, a04c <fwp_main_thread+0x8bc>
    a03c:	7103f43f 	cmp	w1, #0xfd
    a040:	54005e48 	b.hi	ac08 <fwp_main_thread+0x1478>  // b.pmore
    a044:	11000421 	add	w1, w1, #0x1
    a048:	39000001 	strb	w1, [x0]
    a04c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a050:	91174035 	add	x21, x1, #0x5d0
    a054:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a058:	aa0603f8 	mov	x24, x6
    a05c:	aa1303fb 	mov	x27, x19
    a060:	aa0603e0 	mov	x0, x6
    a064:	52800034 	mov	w20, #0x1                   	// #1
    a068:	f91f6033 	str	x19, [x1, #16064]
    a06c:	f91f6426 	str	x6, [x1, #16072]
    a070:	b93ee834 	str	w20, [x1, #16104]
    a074:	b93ef034 	str	w20, [x1, #16112]
    a078:	b94000a2 	ldr	w2, [x5]
    a07c:	b9400401 	ldr	w1, [x0, #4]
    a080:	4b010040 	sub	w0, w2, w1
    a084:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a088:	b93ee440 	str	w0, [x2, #16100]
    a08c:	b97ee842 	ldr	w2, [x2, #16104]
    a090:	6b02001f 	cmp	w0, w2
    a094:	1a829019 	csel	w25, w0, w2, ls	// ls = plast
    a098:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a09c:	b97ef000 	ldr	w0, [x0, #16112]
    a0a0:	6b00033f 	cmp	w25, w0
    a0a4:	1a809336 	csel	w22, w25, w0, ls	// ls = plast
    a0a8:	6b160322 	subs	w2, w25, w22
    a0ac:	540000c0 	b.eq	a0c4 <fwp_main_thread+0x934>  // b.none
    a0b0:	f9400ca4 	ldr	x4, [x5, #24]
    a0b4:	0b160021 	add	w1, w1, w22
    a0b8:	8b364f60 	add	x0, x27, w22, uxtw #3
    a0bc:	f9400884 	ldr	x4, [x4, #16]
    a0c0:	d63f0080 	blr	x4
    a0c4:	f9404780 	ldr	x0, [x28, #136]
    a0c8:	aa1803e7 	mov	x7, x24
    a0cc:	b9400304 	ldr	w4, [x24]
    a0d0:	aa1b03fa 	mov	x26, x27
    a0d4:	2a1903f7 	mov	w23, w25
    a0d8:	aa1803e9 	mov	x9, x24
    a0dc:	8b041404 	add	x4, x0, x4, lsl #5
    a0e0:	f9400c88 	ldr	x8, [x4, #24]
    a0e4:	b4002208 	cbz	x8, a524 <fwp_main_thread+0xd94>
    a0e8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0ec:	aa0403f4 	mov	x20, x4
    a0f0:	f91f681b 	str	x27, [x0, #16080]
    a0f4:	b93ed816 	str	w22, [x0, #16088]
    a0f8:	b93ee019 	str	w25, [x0, #16096]
    a0fc:	14000012 	b	a144 <fwp_main_thread+0x9b4>
    a100:	f9400101 	ldr	x1, [x8]
    a104:	aa1a03e0 	mov	x0, x26
    a108:	d63f0020 	blr	x1
    a10c:	aa0003fb 	mov	x27, x0
    a110:	aa1803e0 	mov	x0, x24
    a114:	97ffee9f 	bl	5b90 <fwp_closure_drop>
    a118:	6b1702df 	cmp	w22, w23
    a11c:	54000d00 	b.eq	a2bc <fwp_main_thread+0xb2c>  // b.none
    a120:	f9404780 	ldr	x0, [x28, #136]
    a124:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a128:	b9400364 	ldr	w4, [x27]
    a12c:	4b130337 	sub	w23, w25, w19
    a130:	aa1b03e7 	mov	x7, x27
    a134:	8b041414 	add	x20, x0, x4, lsl #5
    a138:	f9400e88 	ldr	x8, [x20, #24]
    a13c:	b4001ea8 	cbz	x8, a510 <fwp_main_thread+0xd80>
    a140:	aa1b03f8 	mov	x24, x27
    a144:	b94004e9 	ldr	w9, [x7, #4]
    a148:	b9400293 	ldr	w19, [x20]
    a14c:	0b170139 	add	w25, w9, w23
    a150:	6b19027f 	cmp	w19, w25
    a154:	540037a8 	b.hi	a848 <fwp_main_thread+0x10b8>  // b.pmore
    a158:	7100013f 	cmp	w9, #0x0
    a15c:	4b090276 	sub	w22, w19, w9
    a160:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a164:	54fffce1 	b.ne	a100 <fwp_main_thread+0x970>  // b.any
    a168:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a16c:	910003e0 	mov	x0, sp
    a170:	7100027f 	cmp	w19, #0x0
    a174:	f91f7c20 	str	x0, [x1, #16120]
    a178:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a17c:	d37df000 	lsl	x0, x0, #3
    a180:	91003c00 	add	x0, x0, #0xf
    a184:	92704c01 	and	x1, x0, #0xfffff0000
    a188:	927c7c00 	and	x0, x0, #0xffffffff0
    a18c:	cb2163e1 	sub	x1, sp, x1
    a190:	eb2163ff 	cmp	sp, x1
    a194:	540000a0 	b.eq	a1a8 <fwp_main_thread+0xa18>  // b.none
    a198:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a19c:	f90203ff 	str	xzr, [sp, #1024]
    a1a0:	eb2163ff 	cmp	sp, x1
    a1a4:	54ffffa1 	b.ne	a198 <fwp_main_thread+0xa08>  // b.any
    a1a8:	92403c00 	and	x0, x0, #0xffff
    a1ac:	cb2063ff 	sub	sp, sp, x0
    a1b0:	f90003ff 	str	xzr, [sp]
    a1b4:	f110001f 	cmp	x0, #0x400
    a1b8:	54000043 	b.cc	a1c0 <fwp_main_thread+0xa30>  // b.lo, b.ul, b.last
    a1bc:	f90203ff 	str	xzr, [sp, #1024]
    a1c0:	910043fb 	add	x27, sp, #0x10
    a1c4:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a1c8:	910020e1 	add	x1, x7, #0x8
    a1cc:	d2800000 	mov	x0, #0x0                   	// #0
    a1d0:	340000e9 	cbz	w9, a1ec <fwp_main_thread+0xa5c>
    a1d4:	d503201f 	nop
    a1d8:	f8606823 	ldr	x3, [x1, x0]
    a1dc:	f8206b63 	str	x3, [x27, x0]
    a1e0:	91002000 	add	x0, x0, #0x8
    a1e4:	eb02001f 	cmp	x0, x2
    a1e8:	54ffff81 	b.ne	a1d8 <fwp_main_thread+0xa48>  // b.any
    a1ec:	2a1603e1 	mov	w1, w22
    a1f0:	d2800000 	mov	x0, #0x0                   	// #0
    a1f4:	340000f6 	cbz	w22, a210 <fwp_main_thread+0xa80>
    a1f8:	0b000122 	add	w2, w9, w0
    a1fc:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a200:	91000400 	add	x0, x0, #0x1
    a204:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a208:	eb01001f 	cmp	x0, x1
    a20c:	54ffff61 	b.ne	a1f8 <fwp_main_thread+0xa68>  // b.any
    a210:	f949daa0 	ldr	x0, [x21, #5040]
    a214:	f949eea1 	ldr	x1, [x21, #5080]
    a218:	cb000300 	sub	x0, x24, x0
    a21c:	eb01401f 	cmp	x0, x1, lsl #16
    a220:	540002e2 	b.cs	a27c <fwp_main_thread+0xaec>  // b.hs, b.nlast
    a224:	d350fc01 	lsr	x1, x0, #16
    a228:	f949fea5 	ldr	x5, [x21, #5112]
    a22c:	8b010821 	add	x1, x1, x1, lsl #2
    a230:	d37df021 	lsl	x1, x1, #3
    a234:	8b0100a3 	add	x3, x5, x1
    a238:	f9401062 	ldr	x2, [x3, #32]
    a23c:	b4000202 	cbz	x2, a27c <fwp_main_thread+0xaec>
    a240:	386168a1 	ldrb	w1, [x5, x1]
    a244:	7100083f 	cmp	w1, #0x2
    a248:	540015e0 	b.eq	a504 <fwp_main_thread+0xd74>  // b.none
    a24c:	7100043f 	cmp	w1, #0x1
    a250:	54000161 	b.ne	a27c <fwp_main_thread+0xaec>  // b.any
    a254:	29430465 	ldp	w5, w1, [x3, #24]
    a258:	92403c00 	and	x0, x0, #0xffff
    a25c:	9b057c00 	mul	x0, x0, x5
    a260:	d360fc00 	lsr	x0, x0, #32
    a264:	eb01001f 	cmp	x0, x1
    a268:	540000a2 	b.cs	a27c <fwp_main_thread+0xaec>  // b.hs, b.nlast
    a26c:	8b000042 	add	x2, x2, x0
    a270:	39400040 	ldrb	w0, [x2]
    a274:	7100041f 	cmp	w0, #0x1
    a278:	54001420 	b.eq	a4fc <fwp_main_thread+0xd6c>  // b.none
    a27c:	f9400502 	ldr	x2, [x8, #8]
    a280:	aa1803e0 	mov	x0, x24
    a284:	52800021 	mov	w1, #0x1                   	// #1
    a288:	d63f0040 	blr	x2
    a28c:	f9400e81 	ldr	x1, [x20, #24]
    a290:	aa1b03e0 	mov	x0, x27
    a294:	f9400021 	ldr	x1, [x1]
    a298:	d63f0020 	blr	x1
    a29c:	aa0003fb 	mov	x27, x0
    a2a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2a4:	f95f7c00 	ldr	x0, [x0, #16120]
    a2a8:	9100001f 	mov	sp, x0
    a2ac:	aa1803e0 	mov	x0, x24
    a2b0:	97ffee38 	bl	5b90 <fwp_closure_drop>
    a2b4:	6b1702df 	cmp	w22, w23
    a2b8:	54fff341 	b.ne	a120 <fwp_main_thread+0x990>  // b.any
    a2bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2c0:	aa1b03f8 	mov	x24, x27
    a2c4:	f95f681b 	ldr	x27, [x0, #16080]
    a2c8:	b97ed816 	ldr	w22, [x0, #16088]
    a2cc:	b97ee019 	ldr	w25, [x0, #16096]
    a2d0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2d4:	b97ee401 	ldr	w1, [x0, #16100]
    a2d8:	b97ee800 	ldr	w0, [x0, #16104]
    a2dc:	6b00003f 	cmp	w1, w0
    a2e0:	54001563 	b.cc	a58c <fwp_main_thread+0xdfc>  // b.lo, b.ul, b.last
    a2e4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2e8:	f95f6013 	ldr	x19, [x0, #16064]
    a2ec:	f95f6406 	ldr	x6, [x0, #16072]
    a2f0:	140000cf 	b	a62c <fwp_main_thread+0xe9c>
    a2f4:	f9004293 	str	x19, [x20, #128]
    a2f8:	17fffdca 	b	9a20 <fwp_main_thread+0x290>
    a2fc:	f941b2a0 	ldr	x0, [x21, #864]
    a300:	b9035abf 	str	wzr, [x21, #856]
    a304:	b5ffbc00 	cbnz	x0, 9a84 <fwp_main_thread+0x2f4>
    a308:	97ffef92 	bl	6150 <fwp_free_zombie>
    a30c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a310:	9101c015 	add	x21, x0, #0x70
    a314:	f94042a0 	ldr	x0, [x21, #128]
    a318:	b5ffbb60 	cbnz	x0, 9a84 <fwp_main_thread+0x2f4>
    a31c:	f9406ea0 	ldr	x0, [x21, #216]
    a320:	b5ffbb20 	cbnz	x0, 9a84 <fwp_main_thread+0x2f4>
    a324:	b940faa0 	ldr	w0, [x21, #248]
    a328:	340001c0 	cbz	w0, a360 <fwp_main_thread+0xbd0>
    a32c:	93407c14 	sxtw	x20, w0
    a330:	51000400 	sub	w0, w0, #0x1
    a334:	d1000a94 	sub	x20, x20, #0x2
    a338:	910402b6 	add	x22, x21, #0x100
    a33c:	cb204294 	sub	x20, x20, w0, uxtw
    a340:	93407c13 	sxtw	x19, w0
    a344:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    a348:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a34c:	b900fab3 	str	w19, [x21, #248]
    a350:	d1000673 	sub	x19, x19, #0x1
    a354:	97ffe193 	bl	29a0 <munmap@plt>
    a358:	eb14027f 	cmp	x19, x20
    a35c:	54ffff41 	b.ne	a344 <fwp_main_thread+0xbb4>  // b.any
    a360:	d00000a5 	adrp	x5, 20000 <__data_start>
    a364:	910040a0 	add	x0, x5, #0x10
    a368:	b9404800 	ldr	w0, [x0, #72]
    a36c:	37f800c0 	tbnz	w0, #31, a384 <fwp_main_thread+0xbf4>
    a370:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a374:	f91f7c25 	str	x5, [x1, #16120]
    a378:	97ffe146 	bl	2890 <close@plt>
    a37c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a380:	f95f7c05 	ldr	x5, [x0, #16120]
    a384:	d00000a0 	adrp	x0, 20000 <__data_start>
    a388:	9101c000 	add	x0, x0, #0x70
    a38c:	910040a5 	add	x5, x5, #0x10
    a390:	12800001 	mov	w1, #0xffffffff            	// #-1
    a394:	d2800013 	mov	x19, #0x0                   	// #0
    a398:	f941b415 	ldr	x21, [x0, #872]
    a39c:	b90048a1 	str	w1, [x5, #72]
    a3a0:	f941b814 	ldr	x20, [x0, #880]
    a3a4:	b4000175 	cbz	x21, a3d0 <fwp_main_thread+0xc40>
    a3a8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    a3ac:	b40000c0 	cbz	x0, a3c4 <fwp_main_thread+0xc34>
    a3b0:	f9400001 	ldr	x1, [x0]
    a3b4:	b5ffb681 	cbnz	x1, 9a84 <fwp_main_thread+0x2f4>
    a3b8:	f9400401 	ldr	x1, [x0, #8]
    a3bc:	b5ffb641 	cbnz	x1, 9a84 <fwp_main_thread+0x2f4>
    a3c0:	97ffe9ac 	bl	4a70 <fwp_mem_free>
    a3c4:	91000673 	add	x19, x19, #0x1
    a3c8:	eb1302bf 	cmp	x21, x19
    a3cc:	54fffee1 	b.ne	a3a8 <fwp_main_thread+0xc18>  // b.any
    a3d0:	aa1403e0 	mov	x0, x20
    a3d4:	97ffe9a7 	bl	4a70 <fwp_mem_free>
    a3d8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a3dc:	9101c000 	add	x0, x0, #0x70
    a3e0:	f941b013 	ldr	x19, [x0, #864]
    a3e4:	f901b41f 	str	xzr, [x0, #872]
    a3e8:	f901b81f 	str	xzr, [x0, #880]
    a3ec:	b40001f3 	cbz	x19, a428 <fwp_main_thread+0xc98>
    a3f0:	f9401661 	ldr	x1, [x19, #40]
    a3f4:	b5ffb481 	cbnz	x1, 9a84 <fwp_main_thread+0x2f4>
    a3f8:	f9405661 	ldr	x1, [x19, #168]
    a3fc:	b5ffb441 	cbnz	x1, 9a84 <fwp_main_thread+0x2f4>
    a400:	f9419401 	ldr	x1, [x0, #808]
    a404:	b5ffb401 	cbnz	x1, 9a84 <fwp_main_thread+0x2f4>
    a408:	f9419c00 	ldr	x0, [x0, #824]
    a40c:	b5ffb3c0 	cbnz	x0, 9a84 <fwp_main_thread+0x2f4>
    a410:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a414:	d0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    a418:	910fc000 	add	x0, x0, #0x3f0
    a41c:	97ffe10d 	bl	2850 <memset@plt>
    a420:	aa1303e0 	mov	x0, x19
    a424:	97ffe993 	bl	4a70 <fwp_mem_free>
    a428:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a42c:	f947ec00 	ldr	x0, [x0, #4056]
    a430:	d00000a1 	adrp	x1, 20000 <__data_start>
    a434:	9101c021 	add	x1, x1, #0x70
    a438:	f9400000 	ldr	x0, [x0]
    a43c:	f900083f 	str	xzr, [x1, #16]
    a440:	f901b03f 	str	xzr, [x1, #864]
    a444:	97ffe15b 	bl	29b0 <fflush@plt>
    a448:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a44c:	f947f400 	ldr	x0, [x0, #4072]
    a450:	f85f83a2 	ldur	x2, [x29, #-8]
    a454:	f9400001 	ldr	x1, [x0]
    a458:	eb010042 	subs	x2, x2, x1
    a45c:	d2800001 	mov	x1, #0x0                   	// #0
    a460:	540044a1 	b.ne	acf4 <fwp_main_thread+0x1564>  // b.any
    a464:	910003bf 	mov	sp, x29
    a468:	d2800000 	mov	x0, #0x0                   	// #0
    a46c:	a94153f3 	ldp	x19, x20, [sp, #16]
    a470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a474:	a94363f7 	ldp	x23, x24, [sp, #48]
    a478:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a47c:	a94573fb 	ldp	x27, x28, [sp, #80]
    a480:	fd4033e8 	ldr	d8, [sp, #96]
    a484:	a8c77bfd 	ldp	x29, x30, [sp], #112
    a488:	d65f03c0 	ret
    a48c:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    a490:	913e8000 	add	x0, x0, #0xfa0
    a494:	9400042f 	bl	b550 <atexit>
    a498:	17fffcd4 	b	97e8 <fwp_main_thread+0x58>
    a49c:	97ffe71a 	bl	4104 <fwp_heap_init>
    a4a0:	17fffcce 	b	97d8 <fwp_main_thread+0x48>
    a4a4:	f9400438 	ldr	x24, [x1, #8]
    a4a8:	b4000118 	cbz	x24, a4c8 <fwp_main_thread+0xd38>
    a4ac:	f9400820 	ldr	x0, [x1, #16]
    a4b0:	cb180000 	sub	x0, x0, x24
    a4b4:	eb00039f 	cmp	x28, x0
    a4b8:	54000088 	b.hi	a4c8 <fwp_main_thread+0xd38>  // b.pmore
    a4bc:	8b1c0300 	add	x0, x24, x28
    a4c0:	f9000420 	str	x0, [x1, #8]
    a4c4:	17fffdc8 	b	9be4 <fwp_main_thread+0x454>
    a4c8:	52800001 	mov	w1, #0x0                   	// #0
    a4cc:	d2800300 	mov	x0, #0x18                  	// #24
    a4d0:	97ffea88 	bl	4ef0 <fwp_heap_alloc>
    a4d4:	aa0003f8 	mov	x24, x0
    a4d8:	17fffdd7 	b	9c34 <fwp_main_thread+0x4a4>
    a4dc:	72003c5f 	tst	w2, #0xffff
    a4e0:	54ffbe81 	b.ne	9cb0 <fwp_main_thread+0x520>  // b.any
    a4e4:	39400380 	ldrb	w0, [x28]
    a4e8:	7103fc1f 	cmp	w0, #0xff
    a4ec:	54ffbe01 	b.ne	9cac <fwp_main_thread+0x51c>  // b.any
    a4f0:	aa1c03e0 	mov	x0, x28
    a4f4:	97ffe8bf 	bl	47f0 <fwp_rc_forget_slot>
    a4f8:	17fffded 	b	9cac <fwp_main_thread+0x51c>
    a4fc:	b90004ff 	str	wzr, [x7, #4]
    a500:	17ffff63 	b	a28c <fwp_main_thread+0xafc>
    a504:	72003c1f 	tst	w0, #0xffff
    a508:	54ffeba1 	b.ne	a27c <fwp_main_thread+0xaec>  // b.any
    a50c:	17ffff59 	b	a270 <fwp_main_thread+0xae0>
    a510:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a514:	aa1b03e9 	mov	x9, x27
    a518:	f95f681b 	ldr	x27, [x0, #16080]
    a51c:	b97ed816 	ldr	w22, [x0, #16088]
    a520:	b97ee019 	ldr	w25, [x0, #16096]
    a524:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a528:	aa0903e0 	mov	x0, x9
    a52c:	f91f7c29 	str	x9, [x1, #16120]
    a530:	97ffec7c 	bl	5720 <fwp_rc_share>
    a534:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a538:	f95f7c09 	ldr	x9, [x0, #16120]
    a53c:	34000157 	cbz	w23, a564 <fwp_main_thread+0xdd4>
    a540:	8b374f53 	add	x19, x26, w23, uxtw #3
    a544:	aa1a03f4 	mov	x20, x26
    a548:	aa0903f8 	mov	x24, x9
    a54c:	d503201f 	nop
    a550:	f8408680 	ldr	x0, [x20], #8
    a554:	97ffec73 	bl	5720 <fwp_rc_share>
    a558:	eb13029f 	cmp	x20, x19
    a55c:	54ffffa1 	b.ne	a550 <fwp_main_thread+0xdc0>  // b.any
    a560:	aa1803e9 	mov	x9, x24
    a564:	aa1a03e2 	mov	x2, x26
    a568:	2a1703e1 	mov	w1, w23
    a56c:	aa0903e0 	mov	x0, x9
    a570:	97ffeaa5 	bl	5004 <fwp_apply>
    a574:	aa0003f8 	mov	x24, x0
    a578:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a57c:	b97ee401 	ldr	w1, [x0, #16100]
    a580:	b97ee800 	ldr	w0, [x0, #16104]
    a584:	6b00003f 	cmp	w1, w0
    a588:	54ffeae2 	b.cs	a2e4 <fwp_main_thread+0xb54>  // b.hs, b.nlast
    a58c:	f9404781 	ldr	x1, [x28, #136]
    a590:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a594:	b9400305 	ldr	w5, [x24]
    a598:	4b190000 	sub	w0, w0, w25
    a59c:	8b394f7b 	add	x27, x27, w25, uxtw #3
    a5a0:	b93ee840 	str	w0, [x2, #16104]
    a5a4:	8b051425 	add	x5, x1, x5, lsl #5
    a5a8:	b97ef040 	ldr	w0, [x2, #16112]
    a5ac:	4b160000 	sub	w0, w0, w22
    a5b0:	b93ef040 	str	w0, [x2, #16112]
    a5b4:	f9400ca1 	ldr	x1, [x5, #24]
    a5b8:	aa1803e0 	mov	x0, x24
    a5bc:	b5ffd5e1 	cbnz	x1, a078 <fwp_main_thread+0x8e8>
    a5c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5c4:	f95f6406 	ldr	x6, [x0, #16072]
    a5c8:	f91f7c06 	str	x6, [x0, #16120]
    a5cc:	f95f6013 	ldr	x19, [x0, #16064]
    a5d0:	b97ee814 	ldr	w20, [x0, #16104]
    a5d4:	aa1803e0 	mov	x0, x24
    a5d8:	97ffec52 	bl	5720 <fwp_rc_share>
    a5dc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5e0:	f95f7c06 	ldr	x6, [x0, #16120]
    a5e4:	34000134 	cbz	w20, a608 <fwp_main_thread+0xe78>
    a5e8:	aa0603fa 	mov	x26, x6
    a5ec:	d2800015 	mov	x21, #0x0                   	// #0
    a5f0:	f8757b60 	ldr	x0, [x27, x21, lsl #3]
    a5f4:	910006b5 	add	x21, x21, #0x1
    a5f8:	97ffec4a 	bl	5720 <fwp_rc_share>
    a5fc:	6b15029f 	cmp	w20, w21
    a600:	54ffff88 	b.hi	a5f0 <fwp_main_thread+0xe60>  // b.pmore
    a604:	aa1a03e6 	mov	x6, x26
    a608:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a60c:	aa1b03e2 	mov	x2, x27
    a610:	2a1403e1 	mov	w1, w20
    a614:	f91f7c06 	str	x6, [x0, #16120]
    a618:	aa1803e0 	mov	x0, x24
    a61c:	97ffea7a 	bl	5004 <fwp_apply>
    a620:	aa0003f8 	mov	x24, x0
    a624:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a628:	f95f7c06 	ldr	x6, [x0, #16120]
    a62c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a630:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x108b0>
    a634:	91102042 	add	x2, x2, #0x408
    a638:	91014042 	add	x2, x2, #0x50
    a63c:	aa1803e1 	mov	x1, x24
    a640:	f91f7c06 	str	x6, [x0, #16120]
    a644:	52800023 	mov	w3, #0x1                   	// #1
    a648:	f95f5800 	ldr	x0, [x0, #16048]
    a64c:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a650:	f81303bf 	stur	xzr, [x29, #-208]
    a654:	97fff853 	bl	87a0 <fwp_write>
    a658:	a9726bb5 	ldp	x21, x26, [x29, #-224]
    a65c:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0xa80>
    a660:	91026000 	add	x0, x0, #0x98
    a664:	f10002bf 	cmp	x21, #0x0
    a668:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a66c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a670:	b1002b5f 	cmn	x26, #0xa
    a674:	f95f7c06 	ldr	x6, [x0, #16120]
    a678:	54003628 	b.hi	ad3c <fwp_main_thread+0x15ac>  // b.pmore
    a67c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a680:	52800021 	mov	w1, #0x1                   	// #1
    a684:	f91f7c06 	str	x6, [x0, #16120]
    a688:	91002740 	add	x0, x26, #0x9
    a68c:	97ffea19 	bl	4ef0 <fwp_heap_alloc>
    a690:	aa0003f4 	mov	x20, x0
    a694:	aa1503e1 	mov	x1, x21
    a698:	aa0003f5 	mov	x21, x0
    a69c:	aa1a03e2 	mov	x2, x26
    a6a0:	f80086ba 	str	x26, [x21], #8
    a6a4:	8b1a029a 	add	x26, x20, x26
    a6a8:	aa1503e0 	mov	x0, x21
    a6ac:	97ffe009 	bl	26d0 <memcpy@plt>
    a6b0:	3900235f 	strb	wzr, [x26, #8]
    a6b4:	f85203a0 	ldur	x0, [x29, #-224]
    a6b8:	97ffe0a2 	bl	2940 <free@plt>
    a6bc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a6c0:	91174002 	add	x2, x0, #0x5d0
    a6c4:	f949d841 	ldr	x1, [x2, #5040]
    a6c8:	f949ec40 	ldr	x0, [x2, #5080]
    a6cc:	cb010281 	sub	x1, x20, x1
    a6d0:	eb00403f 	cmp	x1, x0, lsl #16
    a6d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6d8:	f95f7c06 	ldr	x6, [x0, #16120]
    a6dc:	54000322 	b.cs	a740 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    a6e0:	d350fc20 	lsr	x0, x1, #16
    a6e4:	f949fc43 	ldr	x3, [x2, #5112]
    a6e8:	8b000800 	add	x0, x0, x0, lsl #2
    a6ec:	d37df002 	lsl	x2, x0, #3
    a6f0:	8b020060 	add	x0, x3, x2
    a6f4:	f940101a 	ldr	x26, [x0, #32]
    a6f8:	b400025a 	cbz	x26, a740 <fwp_main_thread+0xfb0>
    a6fc:	38626862 	ldrb	w2, [x3, x2]
    a700:	7100085f 	cmp	w2, #0x2
    a704:	540034a0 	b.eq	ad98 <fwp_main_thread+0x1608>  // b.none
    a708:	7100045f 	cmp	w2, #0x1
    a70c:	540001a1 	b.ne	a740 <fwp_main_thread+0xfb0>  // b.any
    a710:	29430002 	ldp	w2, w0, [x0, #24]
    a714:	92403c21 	and	x1, x1, #0xffff
    a718:	9b027c21 	mul	x1, x1, x2
    a71c:	d360fc21 	lsr	x1, x1, #32
    a720:	eb00003f 	cmp	x1, x0
    a724:	540000e2 	b.cs	a740 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    a728:	8b01035a 	add	x26, x26, x1
    a72c:	39400340 	ldrb	w0, [x26]
    a730:	7103fc1f 	cmp	w0, #0xff
    a734:	54003820 	b.eq	ae38 <fwp_main_thread+0x16a8>  // b.none
    a738:	52800020 	mov	w0, #0x1                   	// #1
    a73c:	39000340 	strb	w0, [x26]
    a740:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a744:	f91f7c06 	str	x6, [x0, #16120]
    a748:	aa1803e0 	mov	x0, x24
    a74c:	97ffec62 	bl	58d4 <fwp_drop0>
    a750:	d00000a0 	adrp	x0, 20000 <__data_start>
    a754:	9101c003 	add	x3, x0, #0x70
    a758:	f9400282 	ldr	x2, [x20]
    a75c:	aa1503e0 	mov	x0, x21
    a760:	aa0303f5 	mov	x21, x3
    a764:	d2800021 	mov	x1, #0x1                   	// #1
    a768:	f9400463 	ldr	x3, [x3, #8]
    a76c:	97ffe085 	bl	2980 <fwrite@plt>
    a770:	f94006a1 	ldr	x1, [x21, #8]
    a774:	52800140 	mov	w0, #0xa                   	// #10
    a778:	97ffe00a 	bl	27a0 <fputc@plt>
    a77c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a780:	91174002 	add	x2, x0, #0x5d0
    a784:	f949d841 	ldr	x1, [x2, #5040]
    a788:	f949ec40 	ldr	x0, [x2, #5080]
    a78c:	cb010281 	sub	x1, x20, x1
    a790:	eb00403f 	cmp	x1, x0, lsl #16
    a794:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a798:	f95f7c06 	ldr	x6, [x0, #16120]
    a79c:	54000382 	b.cs	a80c <fwp_main_thread+0x107c>  // b.hs, b.nlast
    a7a0:	d350fc20 	lsr	x0, x1, #16
    a7a4:	f949fc43 	ldr	x3, [x2, #5112]
    a7a8:	8b000800 	add	x0, x0, x0, lsl #2
    a7ac:	d37df000 	lsl	x0, x0, #3
    a7b0:	8b000062 	add	x2, x3, x0
    a7b4:	f9401055 	ldr	x21, [x2, #32]
    a7b8:	b40002b5 	cbz	x21, a80c <fwp_main_thread+0x107c>
    a7bc:	38606860 	ldrb	w0, [x3, x0]
    a7c0:	7100081f 	cmp	w0, #0x2
    a7c4:	54002e40 	b.eq	ad8c <fwp_main_thread+0x15fc>  // b.none
    a7c8:	7100041f 	cmp	w0, #0x1
    a7cc:	54000201 	b.ne	a80c <fwp_main_thread+0x107c>  // b.any
    a7d0:	29430043 	ldp	w3, w0, [x2, #24]
    a7d4:	92403c21 	and	x1, x1, #0xffff
    a7d8:	9b037c21 	mul	x1, x1, x3
    a7dc:	d360fc21 	lsr	x1, x1, #32
    a7e0:	eb00003f 	cmp	x1, x0
    a7e4:	54000142 	b.cs	a80c <fwp_main_thread+0x107c>  // b.hs, b.nlast
    a7e8:	8b0102b5 	add	x21, x21, x1
    a7ec:	394002a0 	ldrb	w0, [x21]
    a7f0:	340000e0 	cbz	w0, a80c <fwp_main_thread+0x107c>
    a7f4:	7100041f 	cmp	w0, #0x1
    a7f8:	540030c0 	b.eq	ae10 <fwp_main_thread+0x1680>  // b.none
    a7fc:	7103fc1f 	cmp	w0, #0xff
    a800:	54002d20 	b.eq	ada4 <fwp_main_thread+0x1614>  // b.none
    a804:	51000400 	sub	w0, w0, #0x1
    a808:	390002a0 	strb	w0, [x21]
    a80c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a810:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a814:	f95f5400 	ldr	x0, [x0, #16040]
    a818:	f9400800 	ldr	x0, [x0, #16]
    a81c:	f91f5420 	str	x0, [x1, #16040]
    a820:	b4002960 	cbz	x0, ad4c <fwp_main_thread+0x15bc>
    a824:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a828:	91174000 	add	x0, x0, #0x5d0
    a82c:	f949d801 	ldr	x1, [x0, #5040]
    a830:	f949ec02 	ldr	x2, [x0, #5080]
    a834:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a838:	f95f5c00 	ldr	x0, [x0, #16056]
    a83c:	d370bc42 	lsl	x2, x2, #16
    a840:	cb010001 	sub	x1, x0, x1
    a844:	17fffdb6 	b	9f1c <fwp_main_thread+0x78c>
    a848:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a84c:	2a1903e2 	mov	w2, w25
    a850:	aa1403e4 	mov	x4, x20
    a854:	f95f681b 	ldr	x27, [x0, #16080]
    a858:	b97ed816 	ldr	w22, [x0, #16088]
    a85c:	b97ee019 	ldr	w25, [x0, #16096]
    a860:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a864:	9117400a 	add	x10, x0, #0x5d0
    a868:	11000440 	add	w0, w2, #0x1
    a86c:	f120001f 	cmp	x0, #0x800
    a870:	d37df000 	lsl	x0, x0, #3
    a874:	b953a541 	ldr	w1, [x10, #5028]
    a878:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a87c:	54001940 	b.eq	aba4 <fwp_main_thread+0x1414>  // b.none
    a880:	91003c01 	add	x1, x0, #0xf
    a884:	8b411141 	add	x1, x10, x1, lsr #4
    a888:	397e8021 	ldrb	w1, [x1, #4000]
    a88c:	910f002b 	add	x11, x1, #0x3c0
    a890:	8b010428 	add	x8, x1, x1, lsl #1
    a894:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a898:	8b080d4c 	add	x12, x10, x8, lsl #3
    a89c:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a8a0:	2a0b03e1 	mov	w1, w11
    a8a4:	b40016f3 	cbz	x19, ab80 <fwp_main_thread+0x13f0>
    a8a8:	f940026c 	ldr	x12, [x19]
    a8ac:	aa2c03ec 	mvn	x12, x12
    a8b0:	f828794c 	str	x12, [x10, x8, lsl #3]
    a8b4:	eb01001f 	cmp	x0, x1
    a8b8:	540000c2 	b.cs	a8d0 <fwp_main_thread+0x1140>  // b.hs, b.nlast
    a8bc:	d503201f 	nop
    a8c0:	f8206a7f 	str	xzr, [x19, x0]
    a8c4:	91002000 	add	x0, x0, #0x8
    a8c8:	eb00003f 	cmp	x1, x0
    a8cc:	54ffffa8 	b.hi	a8c0 <fwp_main_thread+0x1130>  // b.pmore
    a8d0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a8d4:	91174008 	add	x8, x0, #0x5d0
    a8d8:	f94a1100 	ldr	x0, [x8, #5152]
    a8dc:	ab010000 	adds	x0, x0, x1
    a8e0:	540020c2 	b.cs	acf8 <fwp_main_thread+0x1568>  // b.hs, b.nlast
    a8e4:	f94a1501 	ldr	x1, [x8, #5160]
    a8e8:	f90a1100 	str	x0, [x8, #5152]
    a8ec:	eb01001f 	cmp	x0, x1
    a8f0:	54000049 	b.ls	a8f8 <fwp_main_thread+0x1168>  // b.plast
    a8f4:	f90a1500 	str	x0, [x8, #5160]
    a8f8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a8fc:	91174000 	add	x0, x0, #0x5d0
    a900:	1e630161 	ucvtf	d1, w11
    a904:	fd4a1c00 	ldr	d0, [x0, #5176]
    a908:	1e612800 	fadd	d0, d0, d1
    a90c:	fd0a1c00 	str	d0, [x0, #5176]
    a910:	b94000e0 	ldr	w0, [x7]
    a914:	29000a60 	stp	w0, w2, [x19]
    a918:	340001a9 	cbz	w9, a94c <fwp_main_thread+0x11bc>
    a91c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a920:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a924:	910020e1 	add	x1, x7, #0x8
    a928:	f91f6c04 	str	x4, [x0, #16088]
    a92c:	b93ee009 	str	w9, [x0, #16096]
    a930:	f91f7c07 	str	x7, [x0, #16120]
    a934:	91002260 	add	x0, x19, #0x8
    a938:	97ffdf6e 	bl	26f0 <memmove@plt>
    a93c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a940:	f95f6c04 	ldr	x4, [x0, #16088]
    a944:	f95f7c07 	ldr	x7, [x0, #16120]
    a948:	b97ee009 	ldr	w9, [x0, #16096]
    a94c:	2a1703e8 	mov	w8, w23
    a950:	d2800001 	mov	x1, #0x0                   	// #0
    a954:	34000117 	cbz	w23, a974 <fwp_main_thread+0x11e4>
    a958:	0b010120 	add	w0, w9, w1
    a95c:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a960:	8b000e60 	add	x0, x19, x0, lsl #3
    a964:	91000421 	add	x1, x1, #0x1
    a968:	f9000402 	str	x2, [x0, #8]
    a96c:	eb08003f 	cmp	x1, x8
    a970:	54ffff41 	b.ne	a958 <fwp_main_thread+0x11c8>  // b.any
    a974:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a978:	91174002 	add	x2, x0, #0x5d0
    a97c:	f949d840 	ldr	x0, [x2, #5040]
    a980:	f949ec41 	ldr	x1, [x2, #5080]
    a984:	cb000300 	sub	x0, x24, x0
    a988:	eb01401f 	cmp	x0, x1, lsl #16
    a98c:	540002e2 	b.cs	a9e8 <fwp_main_thread+0x1258>  // b.hs, b.nlast
    a990:	d350fc01 	lsr	x1, x0, #16
    a994:	f949fc48 	ldr	x8, [x2, #5112]
    a998:	8b010821 	add	x1, x1, x1, lsl #2
    a99c:	d37df021 	lsl	x1, x1, #3
    a9a0:	8b010105 	add	x5, x8, x1
    a9a4:	f94010a2 	ldr	x2, [x5, #32]
    a9a8:	b4000202 	cbz	x2, a9e8 <fwp_main_thread+0x1258>
    a9ac:	38616901 	ldrb	w1, [x8, x1]
    a9b0:	7100083f 	cmp	w1, #0x2
    a9b4:	54001140 	b.eq	abdc <fwp_main_thread+0x144c>  // b.none
    a9b8:	7100043f 	cmp	w1, #0x1
    a9bc:	54000161 	b.ne	a9e8 <fwp_main_thread+0x1258>  // b.any
    a9c0:	294304a8 	ldp	w8, w1, [x5, #24]
    a9c4:	92403c00 	and	x0, x0, #0xffff
    a9c8:	9b087c00 	mul	x0, x0, x8
    a9cc:	d360fc00 	lsr	x0, x0, #32
    a9d0:	eb01001f 	cmp	x0, x1
    a9d4:	540000a2 	b.cs	a9e8 <fwp_main_thread+0x1258>  // b.hs, b.nlast
    a9d8:	8b000042 	add	x2, x2, x0
    a9dc:	39400040 	ldrb	w0, [x2]
    a9e0:	7100041f 	cmp	w0, #0x1
    a9e4:	54000c40 	b.eq	ab6c <fwp_main_thread+0x13dc>  // b.none
    a9e8:	f9400c82 	ldr	x2, [x4, #24]
    a9ec:	aa1803e0 	mov	x0, x24
    a9f0:	52800021 	mov	w1, #0x1                   	// #1
    a9f4:	f9400442 	ldr	x2, [x2, #8]
    a9f8:	d63f0040 	blr	x2
    a9fc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    aa00:	91174002 	add	x2, x0, #0x5d0
    aa04:	f949d841 	ldr	x1, [x2, #5040]
    aa08:	f949ec40 	ldr	x0, [x2, #5080]
    aa0c:	cb010261 	sub	x1, x19, x1
    aa10:	eb00403f 	cmp	x1, x0, lsl #16
    aa14:	54000322 	b.cs	aa78 <fwp_main_thread+0x12e8>  // b.hs, b.nlast
    aa18:	d350fc20 	lsr	x0, x1, #16
    aa1c:	f949fc44 	ldr	x4, [x2, #5112]
    aa20:	8b000800 	add	x0, x0, x0, lsl #2
    aa24:	d37df002 	lsl	x2, x0, #3
    aa28:	8b020080 	add	x0, x4, x2
    aa2c:	f9401017 	ldr	x23, [x0, #32]
    aa30:	b4000257 	cbz	x23, aa78 <fwp_main_thread+0x12e8>
    aa34:	38626882 	ldrb	w2, [x4, x2]
    aa38:	7100085f 	cmp	w2, #0x2
    aa3c:	54000d60 	b.eq	abe8 <fwp_main_thread+0x1458>  // b.none
    aa40:	7100045f 	cmp	w2, #0x1
    aa44:	540001a1 	b.ne	aa78 <fwp_main_thread+0x12e8>  // b.any
    aa48:	29430002 	ldp	w2, w0, [x0, #24]
    aa4c:	92403c21 	and	x1, x1, #0xffff
    aa50:	9b027c21 	mul	x1, x1, x2
    aa54:	d360fc21 	lsr	x1, x1, #32
    aa58:	eb00003f 	cmp	x1, x0
    aa5c:	540000e2 	b.cs	aa78 <fwp_main_thread+0x12e8>  // b.hs, b.nlast
    aa60:	8b0102f7 	add	x23, x23, x1
    aa64:	394002e0 	ldrb	w0, [x23]
    aa68:	7103fc1f 	cmp	w0, #0xff
    aa6c:	54000c80 	b.eq	abfc <fwp_main_thread+0x146c>  // b.none
    aa70:	52800020 	mov	w0, #0x1                   	// #1
    aa74:	390002e0 	strb	w0, [x23]
    aa78:	aa1803e0 	mov	x0, x24
    aa7c:	aa1303f8 	mov	x24, x19
    aa80:	97ffec44 	bl	5b90 <fwp_closure_drop>
    aa84:	17fffebd 	b	a578 <fwp_main_thread+0xde8>
    aa88:	b8616860 	ldr	w0, [x3, x1]
    aa8c:	b9400481 	ldr	w1, [x4, #4]
    aa90:	4b010003 	sub	w3, w0, w1
    aa94:	7100047f 	cmp	w3, #0x1
    aa98:	54ffa9a1 	b.ne	9fcc <fwp_main_thread+0x83c>  // b.any
    aa9c:	910003f4 	mov	x20, sp
    aaa0:	34000c41 	cbz	w1, ac28 <fwp_main_thread+0x1498>
    aaa4:	7100001f 	cmp	w0, #0x0
    aaa8:	d37d7c00 	ubfiz	x0, x0, #3, #32
    aaac:	d2800102 	mov	x2, #0x8                   	// #8
    aab0:	9a82101a 	csel	x26, x0, x2, ne	// ne = any
    aab4:	91003f40 	add	x0, x26, #0xf
    aab8:	92704c02 	and	x2, x0, #0xfffff0000
    aabc:	927c7c00 	and	x0, x0, #0xffffffff0
    aac0:	cb2263e2 	sub	x2, sp, x2
    aac4:	eb2263ff 	cmp	sp, x2
    aac8:	540000a0 	b.eq	aadc <fwp_main_thread+0x134c>  // b.none
    aacc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    aad0:	f90203ff 	str	xzr, [sp, #1024]
    aad4:	eb2263ff 	cmp	sp, x2
    aad8:	54ffffa1 	b.ne	aacc <fwp_main_thread+0x133c>  // b.any
    aadc:	92403c00 	and	x0, x0, #0xffff
    aae0:	cb2063ff 	sub	sp, sp, x0
    aae4:	f90003ff 	str	xzr, [sp]
    aae8:	f110001f 	cmp	x0, #0x400
    aaec:	54000043 	b.cc	aaf4 <fwp_main_thread+0x1364>  // b.lo, b.ul, b.last
    aaf0:	f90203ff 	str	xzr, [sp, #1024]
    aaf4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aaf8:	d37d7c3b 	ubfiz	x27, x1, #3, #32
    aafc:	910043f5 	add	x21, sp, #0x10
    ab00:	aa1b03e2 	mov	x2, x27
    ab04:	aa1a03e3 	mov	x3, x26
    ab08:	f91f7806 	str	x6, [x0, #16112]
    ab0c:	f91f7c05 	str	x5, [x0, #16120]
    ab10:	f95f5000 	ldr	x0, [x0, #16032]
    ab14:	91004001 	add	x1, x0, #0x10
    ab18:	aa1503e0 	mov	x0, x21
    ab1c:	91012021 	add	x1, x1, #0x48
    ab20:	97ffdf2c 	bl	27d0 <__memcpy_chk@plt>
    ab24:	eb1b035f 	cmp	x26, x27
    ab28:	aa1303e1 	mov	x1, x19
    ab2c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    ab30:	d2800102 	mov	x2, #0x8                   	// #8
    ab34:	cb1b0063 	sub	x3, x3, x27
    ab38:	8b1b02a0 	add	x0, x21, x27
    ab3c:	97ffdf25 	bl	27d0 <__memcpy_chk@plt>
    ab40:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ab44:	aa1503e0 	mov	x0, x21
    ab48:	f95f7c25 	ldr	x5, [x1, #16120]
    ab4c:	f9400ca1 	ldr	x1, [x5, #24]
    ab50:	f9400021 	ldr	x1, [x1]
    ab54:	d63f0020 	blr	x1
    ab58:	aa0003f8 	mov	x24, x0
    ab5c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab60:	f95f7806 	ldr	x6, [x0, #16112]
    ab64:	9100029f 	mov	sp, x20
    ab68:	17fffeb1 	b	a62c <fwp_main_thread+0xe9c>
    ab6c:	b90004ff 	str	wzr, [x7, #4]
    ab70:	17ffffa3 	b	a9fc <fwp_main_thread+0x126c>
    ab74:	72003c3f 	tst	w1, #0xffff
    ab78:	54ffa6a1 	b.ne	a04c <fwp_main_thread+0x8bc>  // b.any
    ab7c:	17fffd2e 	b	a034 <fwp_main_thread+0x8a4>
    ab80:	f9400593 	ldr	x19, [x12, #8]
    ab84:	b4000113 	cbz	x19, aba4 <fwp_main_thread+0x1414>
    ab88:	f9400988 	ldr	x8, [x12, #16]
    ab8c:	cb130108 	sub	x8, x8, x19
    ab90:	eb08003f 	cmp	x1, x8
    ab94:	54000088 	b.hi	aba4 <fwp_main_thread+0x1414>  // b.pmore
    ab98:	8b010268 	add	x8, x19, x1
    ab9c:	f9000588 	str	x8, [x12, #8]
    aba0:	17ffff45 	b	a8b4 <fwp_main_thread+0x1124>
    aba4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aba8:	f91f6824 	str	x4, [x1, #16080]
    abac:	f91f6c27 	str	x7, [x1, #16088]
    abb0:	b93ee022 	str	w2, [x1, #16096]
    abb4:	b93ef829 	str	w9, [x1, #16120]
    abb8:	52800001 	mov	w1, #0x0                   	// #0
    abbc:	97ffe8cd 	bl	4ef0 <fwp_heap_alloc>
    abc0:	aa0003f3 	mov	x19, x0
    abc4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abc8:	f95f6804 	ldr	x4, [x0, #16080]
    abcc:	f95f6c07 	ldr	x7, [x0, #16088]
    abd0:	b97ee002 	ldr	w2, [x0, #16096]
    abd4:	b97ef809 	ldr	w9, [x0, #16120]
    abd8:	17ffff4e 	b	a910 <fwp_main_thread+0x1180>
    abdc:	72003c1f 	tst	w0, #0xffff
    abe0:	54fff041 	b.ne	a9e8 <fwp_main_thread+0x1258>  // b.any
    abe4:	17ffff7e 	b	a9dc <fwp_main_thread+0x124c>
    abe8:	72003c3f 	tst	w1, #0xffff
    abec:	54fff461 	b.ne	aa78 <fwp_main_thread+0x12e8>  // b.any
    abf0:	394002e0 	ldrb	w0, [x23]
    abf4:	7103fc1f 	cmp	w0, #0xff
    abf8:	54fff3c1 	b.ne	aa70 <fwp_main_thread+0x12e0>  // b.any
    abfc:	aa1703e0 	mov	x0, x23
    ac00:	97ffe6fc 	bl	47f0 <fwp_rc_forget_slot>
    ac04:	17ffff9b 	b	aa70 <fwp_main_thread+0x12e0>
    ac08:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ac0c:	f91f7826 	str	x6, [x1, #16112]
    ac10:	f91f7c25 	str	x5, [x1, #16120]
    ac14:	97ffe6b0 	bl	46d4 <fwp_rc_wide_dup>
    ac18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac1c:	f95f7806 	ldr	x6, [x0, #16112]
    ac20:	f95f7c05 	ldr	x5, [x0, #16120]
    ac24:	17fffd0a 	b	a04c <fwp_main_thread+0x8bc>
    ac28:	f9400041 	ldr	x1, [x2]
    ac2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac30:	f91f7c06 	str	x6, [x0, #16120]
    ac34:	aa1303e0 	mov	x0, x19
    ac38:	d63f0020 	blr	x1
    ac3c:	aa0003f8 	mov	x24, x0
    ac40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac44:	f95f7c06 	ldr	x6, [x0, #16120]
    ac48:	9100029f 	mov	sp, x20
    ac4c:	17fffe78 	b	a62c <fwp_main_thread+0xe9c>
    ac50:	72003c3f 	tst	w1, #0xffff
    ac54:	54ff8941 	b.ne	9d7c <fwp_main_thread+0x5ec>  // b.any
    ac58:	17fffc44 	b	9d68 <fwp_main_thread+0x5d8>
    ac5c:	72003c3f 	tst	w1, #0xffff
    ac60:	54ff9421 	b.ne	9ee4 <fwp_main_thread+0x754>  // b.any
    ac64:	17fffc95 	b	9eb8 <fwp_main_thread+0x728>
    ac68:	72003c3f 	tst	w1, #0xffff
    ac6c:	54ff8da1 	b.ne	9e20 <fwp_main_thread+0x690>  // b.any
    ac70:	17fffc67 	b	9e0c <fwp_main_thread+0x67c>
    ac74:	72003c3f 	tst	w1, #0xffff
    ac78:	54ff98c1 	b.ne	9f90 <fwp_main_thread+0x800>  // b.any
    ac7c:	17fffcbf 	b	9f78 <fwp_main_thread+0x7e8>
    ac80:	aa0103e0 	mov	x0, x1
    ac84:	17fffb93 	b	9ad0 <fwp_main_thread+0x340>
    ac88:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac8c:	f91f7c06 	str	x6, [x0, #16120]
    ac90:	aa1303e0 	mov	x0, x19
    ac94:	97ffe6d7 	bl	47f0 <fwp_rc_forget_slot>
    ac98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac9c:	f95f7c06 	ldr	x6, [x0, #16120]
    aca0:	17fffc35 	b	9d74 <fwp_main_thread+0x5e4>
    aca4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aca8:	f91f7c06 	str	x6, [x0, #16120]
    acac:	aa1303e0 	mov	x0, x19
    acb0:	97ffe6d0 	bl	47f0 <fwp_rc_forget_slot>
    acb4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acb8:	f95f7c06 	ldr	x6, [x0, #16120]
    acbc:	17fffc57 	b	9e18 <fwp_main_thread+0x688>
    acc0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acc4:	f91f7c06 	str	x6, [x0, #16120]
    acc8:	aa1303e0 	mov	x0, x19
    accc:	97ffe6c9 	bl	47f0 <fwp_rc_forget_slot>
    acd0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acd4:	f95f7c06 	ldr	x6, [x0, #16120]
    acd8:	17fffc7b 	b	9ec4 <fwp_main_thread+0x734>
    acdc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ace0:	f91f7c26 	str	x6, [x1, #16120]
    ace4:	97ffe67c 	bl	46d4 <fwp_rc_wide_dup>
    ace8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acec:	f95f7c06 	ldr	x6, [x0, #16120]
    acf0:	17fffca8 	b	9f90 <fwp_main_thread+0x800>
    acf4:	97ffdee3 	bl	2880 <__stack_chk_fail@plt>
    acf8:	97ffe0ce 	bl	3030 <fwp_heap_oom>
    acfc:	b0000000 	adrp	x0, b000 <__divti3+0x1a0>
    ad00:	912f6000 	add	x0, x0, #0xbd8
    ad04:	97ffe2bf 	bl	3800 <fwp_trap>
    ad08:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad0c:	aa0603e0 	mov	x0, x6
    ad10:	aa1303fb 	mov	x27, x19
    ad14:	52800034 	mov	w20, #0x1                   	// #1
    ad18:	f91f7c26 	str	x6, [x1, #16120]
    ad1c:	97ffea81 	bl	5720 <fwp_rc_share>
    ad20:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad24:	f95f5c00 	ldr	x0, [x0, #16056]
    ad28:	97ffea7e 	bl	5720 <fwp_rc_share>
    ad2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad30:	f95f7c06 	ldr	x6, [x0, #16120]
    ad34:	aa0603f8 	mov	x24, x6
    ad38:	17fffe34 	b	a608 <fwp_main_thread+0xe78>
    ad3c:	b0000000 	adrp	x0, b000 <__divti3+0x1a0>
    ad40:	91300000 	add	x0, x0, #0xc00
    ad44:	97ffe2af 	bl	3800 <fwp_trap>
    ad48:	97ffe0fa 	bl	3130 <descent_phase_fail>
    ad4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad50:	f95f4c06 	ldr	x6, [x0, #16024]
    ad54:	f91f7c06 	str	x6, [x0, #16120]
    ad58:	f95f5c16 	ldr	x22, [x0, #16056]
    ad5c:	aa1603e0 	mov	x0, x22
    ad60:	97ffeadd 	bl	58d4 <fwp_drop0>
    ad64:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad68:	f95f7c06 	ldr	x6, [x0, #16120]
    ad6c:	aa0603e0 	mov	x0, x6
    ad70:	97ffead9 	bl	58d4 <fwp_drop0>
    ad74:	d00000a0 	adrp	x0, 20000 <__data_start>
    ad78:	9101c000 	add	x0, x0, #0x70
    ad7c:	52800021 	mov	w1, #0x1                   	// #1
    ad80:	b9034c01 	str	w1, [x0, #844]
    ad84:	f901a81f 	str	xzr, [x0, #848]
    ad88:	17fffac8 	b	98a8 <fwp_main_thread+0x118>
    ad8c:	72003c3f 	tst	w1, #0xffff
    ad90:	54ffd3e1 	b.ne	a80c <fwp_main_thread+0x107c>  // b.any
    ad94:	17fffe96 	b	a7ec <fwp_main_thread+0x105c>
    ad98:	72003c3f 	tst	w1, #0xffff
    ad9c:	54ffcd21 	b.ne	a740 <fwp_main_thread+0xfb0>  // b.any
    ada0:	17fffe63 	b	a72c <fwp_main_thread+0xf9c>
    ada4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    ada8:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    adac:	91174021 	add	x1, x1, #0x5d0
    adb0:	ca402400 	eor	x0, x0, x0, lsr #9
    adb4:	8b200c20 	add	x0, x1, w0, uxtb #3
    adb8:	f94a2400 	ldr	x0, [x0, #5192]
    adbc:	b5000080 	cbnz	x0, adcc <fwp_main_thread+0x163c>
    adc0:	14000025 	b	ae54 <fwp_main_thread+0x16c4>
    adc4:	f9400800 	ldr	x0, [x0, #16]
    adc8:	b4000460 	cbz	x0, ae54 <fwp_main_thread+0x16c4>
    adcc:	f9400001 	ldr	x1, [x0]
    add0:	eb0102bf 	cmp	x21, x1
    add4:	54ffff81 	b.ne	adc4 <fwp_main_thread+0x1634>  // b.any
    add8:	f9400401 	ldr	x1, [x0, #8]
    addc:	d1000421 	sub	x1, x1, #0x1
    ade0:	f9000401 	str	x1, [x0, #8]
    ade4:	f103f83f 	cmp	x1, #0xfe
    ade8:	54ffd121 	b.ne	a80c <fwp_main_thread+0x107c>  // b.any
    adec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adf0:	f91f7c06 	str	x6, [x0, #16120]
    adf4:	aa1503e0 	mov	x0, x21
    adf8:	97ffe67e 	bl	47f0 <fwp_rc_forget_slot>
    adfc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ae00:	390002a0 	strb	w0, [x21]
    ae04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae08:	f95f7c06 	ldr	x6, [x0, #16120]
    ae0c:	17fffe80 	b	a80c <fwp_main_thread+0x107c>
    ae10:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae14:	f91f7c06 	str	x6, [x0, #16120]
    ae18:	aa1403e0 	mov	x0, x20
    ae1c:	97ffea66 	bl	57b4 <fwp_rc_free_arr>
    ae20:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae24:	f95f7c06 	ldr	x6, [x0, #16120]
    ae28:	17fffe79 	b	a80c <fwp_main_thread+0x107c>
    ae2c:	b9035a9f 	str	wzr, [x20, #856]
    ae30:	b4ffa6c0 	cbz	x0, a308 <fwp_main_thread+0xb78>
    ae34:	97ffdea7 	bl	28d0 <abort@plt>
    ae38:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae3c:	f91f7c06 	str	x6, [x0, #16120]
    ae40:	aa1a03e0 	mov	x0, x26
    ae44:	97ffe66b 	bl	47f0 <fwp_rc_forget_slot>
    ae48:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae4c:	f95f7c06 	ldr	x6, [x0, #16120]
    ae50:	17fffe3a 	b	a738 <fwp_main_thread+0xfa8>
    ae54:	b0000000 	adrp	x0, b000 <__divti3+0x1a0>
    ae58:	91238000 	add	x0, x0, #0x8e0
    ae5c:	97ffe269 	bl	3800 <fwp_trap>

000000000000ae60 <__divti3>:
    ae60:	d503245f 	bti	c
    ae64:	d2800004 	mov	x4, #0x0                   	// #0
    ae68:	b7f80721 	tbnz	x1, #63, af4c <__divti3+0xec>
    ae6c:	b6f80083 	tbz	x3, #63, ae7c <__divti3+0x1c>
    ae70:	eb0203e2 	negs	x2, x2
    ae74:	aa2403e4 	mvn	x4, x4
    ae78:	da0303e3 	ngc	x3, x3
    ae7c:	aa0203e6 	mov	x6, x2
    ae80:	aa0003e7 	mov	x7, x0
    ae84:	aa0103e5 	mov	x5, x1
    ae88:	b5000583 	cbnz	x3, af38 <__divti3+0xd8>
    ae8c:	eb01005f 	cmp	x2, x1
    ae90:	54000e69 	b.ls	b05c <__divti3+0x1fc>  // b.plast
    ae94:	dac01040 	clz	x0, x2
    ae98:	b40000e0 	cbz	x0, aeb4 <__divti3+0x54>
    ae9c:	4b0003e1 	neg	w1, w0
    aea0:	9ac020a5 	lsl	x5, x5, x0
    aea4:	9ac02046 	lsl	x6, x2, x0
    aea8:	9ac124e1 	lsr	x1, x7, x1
    aeac:	aa050025 	orr	x5, x1, x5
    aeb0:	9ac020e7 	lsl	x7, x7, x0
    aeb4:	d360fcc8 	lsr	x8, x6, #32
    aeb8:	92407cc2 	and	x2, x6, #0xffffffff
    aebc:	9ac808a3 	udiv	x3, x5, x8
    aec0:	9b089465 	msub	x5, x3, x8, x5
    aec4:	aa0303e0 	mov	x0, x3
    aec8:	9b037c41 	mul	x1, x2, x3
    aecc:	93c780a5 	extr	x5, x5, x7, #32
    aed0:	eb05003f 	cmp	x1, x5
    aed4:	540000a9 	b.ls	aee8 <__divti3+0x88>  // b.plast
    aed8:	ab0500c5 	adds	x5, x6, x5
    aedc:	d1000460 	sub	x0, x3, #0x1
    aee0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    aee4:	540015a8 	b.hi	b198 <__divti3+0x338>  // b.pmore
    aee8:	cb0100a5 	sub	x5, x5, x1
    aeec:	9ac808a3 	udiv	x3, x5, x8
    aef0:	9b089465 	msub	x5, x3, x8, x5
    aef4:	aa0303e1 	mov	x1, x3
    aef8:	9b037c42 	mul	x2, x2, x3
    aefc:	aa0703e3 	mov	x3, x7
    af00:	b3607ca3 	bfi	x3, x5, #32, #32
    af04:	eb03005f 	cmp	x2, x3
    af08:	540000c9 	b.ls	af20 <__divti3+0xc0>  // b.plast
    af0c:	ab0300c3 	adds	x3, x6, x3
    af10:	d1000425 	sub	x5, x1, #0x1
    af14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    af18:	d1000821 	sub	x1, x1, #0x2
    af1c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    af20:	aa008020 	orr	x0, x1, x0, lsl #32
    af24:	d2800001 	mov	x1, #0x0                   	// #0
    af28:	b4000064 	cbz	x4, af34 <__divti3+0xd4>
    af2c:	eb0003e0 	negs	x0, x0
    af30:	da0103e1 	ngc	x1, x1
    af34:	d65f03c0 	ret
    af38:	eb01007f 	cmp	x3, x1
    af3c:	54000109 	b.ls	af5c <__divti3+0xfc>  // b.plast
    af40:	d2800001 	mov	x1, #0x0                   	// #0
    af44:	d2800000 	mov	x0, #0x0                   	// #0
    af48:	17fffff8 	b	af28 <__divti3+0xc8>
    af4c:	eb0003e0 	negs	x0, x0
    af50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af54:	da0103e1 	ngc	x1, x1
    af58:	17ffffc5 	b	ae6c <__divti3+0xc>
    af5c:	dac01067 	clz	x7, x3
    af60:	b40010e7 	cbz	x7, b17c <__divti3+0x31c>
    af64:	d2800805 	mov	x5, #0x40                  	// #64
    af68:	cb0700a5 	sub	x5, x5, x7
    af6c:	9ac72063 	lsl	x3, x3, x7
    af70:	9ac52448 	lsr	x8, x2, x5
    af74:	aa030108 	orr	x8, x8, x3
    af78:	9ac52426 	lsr	x6, x1, x5
    af7c:	92407d0a 	and	x10, x8, #0xffffffff
    af80:	d360fd09 	lsr	x9, x8, #32
    af84:	9ac52403 	lsr	x3, x0, x5
    af88:	9ac72021 	lsl	x1, x1, x7
    af8c:	aa010063 	orr	x3, x3, x1
    af90:	9ac72042 	lsl	x2, x2, x7
    af94:	9ac908cb 	udiv	x11, x6, x9
    af98:	9b099965 	msub	x5, x11, x9, x6
    af9c:	aa0b03e1 	mov	x1, x11
    afa0:	9b0b7d46 	mul	x6, x10, x11
    afa4:	93c380a5 	extr	x5, x5, x3, #32
    afa8:	eb0500df 	cmp	x6, x5
    afac:	540000a9 	b.ls	afc0 <__divti3+0x160>  // b.plast
    afb0:	ab050105 	adds	x5, x8, x5
    afb4:	d1000561 	sub	x1, x11, #0x1
    afb8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    afbc:	54000f48 	b.hi	b1a4 <__divti3+0x344>  // b.pmore
    afc0:	cb0600a6 	sub	x6, x5, x6
    afc4:	9ac908cb 	udiv	x11, x6, x9
    afc8:	9b099969 	msub	x9, x11, x9, x6
    afcc:	aa0b03e5 	mov	x5, x11
    afd0:	9b0b7d4a 	mul	x10, x10, x11
    afd4:	b3607d23 	bfi	x3, x9, #32, #32
    afd8:	eb03015f 	cmp	x10, x3
    afdc:	540000a9 	b.ls	aff0 <__divti3+0x190>  // b.plast
    afe0:	ab030103 	adds	x3, x8, x3
    afe4:	d1000565 	sub	x5, x11, #0x1
    afe8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    afec:	54000e28 	b.hi	b1b0 <__divti3+0x350>  // b.pmore
    aff0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    aff4:	92407c48 	and	x8, x2, #0xffffffff
    aff8:	2a0503e5 	mov	w5, w5
    affc:	d360fc42 	lsr	x2, x2, #32
    b000:	d360fc26 	lsr	x6, x1, #32
    b004:	cb0a0063 	sub	x3, x3, x10
    b008:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b00c:	9b087caa 	mul	x10, x5, x8
    b010:	9b087cc8 	mul	x8, x6, x8
    b014:	9b0220a5 	madd	x5, x5, x2, x8
    b018:	9b027cc6 	mul	x6, x6, x2
    b01c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b020:	8b0900c5 	add	x5, x6, x9
    b024:	eb02011f 	cmp	x8, x2
    b028:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b02c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b030:	eb06007f 	cmp	x3, x6
    b034:	540000e3 	b.cc	b050 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b038:	92407d4a 	and	x10, x10, #0xffffffff
    b03c:	9ac72000 	lsl	x0, x0, x7
    b040:	8b028142 	add	x2, x10, x2, lsl #32
    b044:	eb02001f 	cmp	x0, x2
    b048:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b04c:	54000a01 	b.ne	b18c <__divti3+0x32c>  // b.any
    b050:	d1000420 	sub	x0, x1, #0x1
    b054:	d2800001 	mov	x1, #0x0                   	// #0
    b058:	17ffffb4 	b	af28 <__divti3+0xc8>
    b05c:	b5000062 	cbnz	x2, b068 <__divti3+0x208>
    b060:	d2800022 	mov	x2, #0x1                   	// #1
    b064:	9ac30846 	udiv	x6, x2, x3
    b068:	dac010c8 	clz	x8, x6
    b06c:	b5000408 	cbnz	x8, b0ec <__divti3+0x28c>
    b070:	d360fcc9 	lsr	x9, x6, #32
    b074:	92407cc5 	and	x5, x6, #0xffffffff
    b078:	cb060023 	sub	x3, x1, x6
    b07c:	d2800021 	mov	x1, #0x1                   	// #1
    b080:	9ac90868 	udiv	x8, x3, x9
    b084:	9b098d03 	msub	x3, x8, x9, x3
    b088:	aa0803e0 	mov	x0, x8
    b08c:	9b057d02 	mul	x2, x8, x5
    b090:	93c78063 	extr	x3, x3, x7, #32
    b094:	eb03005f 	cmp	x2, x3
    b098:	540000a9 	b.ls	b0ac <__divti3+0x24c>  // b.plast
    b09c:	ab0300c3 	adds	x3, x6, x3
    b0a0:	d1000500 	sub	x0, x8, #0x1
    b0a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b0a8:	54000968 	b.hi	b1d4 <__divti3+0x374>  // b.pmore
    b0ac:	cb020063 	sub	x3, x3, x2
    b0b0:	9ac90862 	udiv	x2, x3, x9
    b0b4:	aa0203e8 	mov	x8, x2
    b0b8:	9b098c42 	msub	x2, x2, x9, x3
    b0bc:	aa0703e3 	mov	x3, x7
    b0c0:	9b057d05 	mul	x5, x8, x5
    b0c4:	b3607c43 	bfi	x3, x2, #32, #32
    b0c8:	eb0300bf 	cmp	x5, x3
    b0cc:	540000c9 	b.ls	b0e4 <__divti3+0x284>  // b.plast
    b0d0:	ab0300c2 	adds	x2, x6, x3
    b0d4:	d1000503 	sub	x3, x8, #0x1
    b0d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b0dc:	d1000908 	sub	x8, x8, #0x2
    b0e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b0e4:	aa008100 	orr	x0, x8, x0, lsl #32
    b0e8:	17ffff90 	b	af28 <__divti3+0xc8>
    b0ec:	9ac820c6 	lsl	x6, x6, x8
    b0f0:	d2800803 	mov	x3, #0x40                  	// #64
    b0f4:	cb080063 	sub	x3, x3, x8
    b0f8:	d360fcc9 	lsr	x9, x6, #32
    b0fc:	9ac82027 	lsl	x7, x1, x8
    b100:	92407cc5 	and	x5, x6, #0xffffffff
    b104:	9ac32422 	lsr	x2, x1, x3
    b108:	9ac32403 	lsr	x3, x0, x3
    b10c:	aa070063 	orr	x3, x3, x7
    b110:	9ac9084a 	udiv	x10, x2, x9
    b114:	9ac82007 	lsl	x7, x0, x8
    b118:	9b098940 	msub	x0, x10, x9, x2
    b11c:	aa0a03e1 	mov	x1, x10
    b120:	9b0a7ca2 	mul	x2, x5, x10
    b124:	93c38000 	extr	x0, x0, x3, #32
    b128:	eb00005f 	cmp	x2, x0
    b12c:	540000a9 	b.ls	b140 <__divti3+0x2e0>  // b.plast
    b130:	ab0000c0 	adds	x0, x6, x0
    b134:	d1000541 	sub	x1, x10, #0x1
    b138:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b13c:	54000468 	b.hi	b1c8 <__divti3+0x368>  // b.pmore
    b140:	cb020000 	sub	x0, x0, x2
    b144:	9ac9080a 	udiv	x10, x0, x9
    b148:	9b098140 	msub	x0, x10, x9, x0
    b14c:	aa0a03e2 	mov	x2, x10
    b150:	9b0a7ca8 	mul	x8, x5, x10
    b154:	b3607c03 	bfi	x3, x0, #32, #32
    b158:	eb03011f 	cmp	x8, x3
    b15c:	540000a9 	b.ls	b170 <__divti3+0x310>  // b.plast
    b160:	ab0300c3 	adds	x3, x6, x3
    b164:	d1000542 	sub	x2, x10, #0x1
    b168:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b16c:	54000288 	b.hi	b1bc <__divti3+0x35c>  // b.pmore
    b170:	cb080063 	sub	x3, x3, x8
    b174:	aa018041 	orr	x1, x2, x1, lsl #32
    b178:	17ffffc2 	b	b080 <__divti3+0x220>
    b17c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b180:	d2800001 	mov	x1, #0x0                   	// #0
    b184:	9a9f87e0 	cset	x0, ls	// ls = plast
    b188:	17ffff68 	b	af28 <__divti3+0xc8>
    b18c:	aa0103e0 	mov	x0, x1
    b190:	d2800001 	mov	x1, #0x0                   	// #0
    b194:	17ffff65 	b	af28 <__divti3+0xc8>
    b198:	d1000860 	sub	x0, x3, #0x2
    b19c:	8b0600a5 	add	x5, x5, x6
    b1a0:	17ffff52 	b	aee8 <__divti3+0x88>
    b1a4:	d1000961 	sub	x1, x11, #0x2
    b1a8:	8b0800a5 	add	x5, x5, x8
    b1ac:	17ffff85 	b	afc0 <__divti3+0x160>
    b1b0:	d1000965 	sub	x5, x11, #0x2
    b1b4:	8b080063 	add	x3, x3, x8
    b1b8:	17ffff8e 	b	aff0 <__divti3+0x190>
    b1bc:	d1000942 	sub	x2, x10, #0x2
    b1c0:	8b060063 	add	x3, x3, x6
    b1c4:	17ffffeb 	b	b170 <__divti3+0x310>
    b1c8:	d1000941 	sub	x1, x10, #0x2
    b1cc:	8b060000 	add	x0, x0, x6
    b1d0:	17ffffdc 	b	b140 <__divti3+0x2e0>
    b1d4:	d1000900 	sub	x0, x8, #0x2
    b1d8:	8b060063 	add	x3, x3, x6
    b1dc:	17ffffb4 	b	b0ac <__divti3+0x24c>

000000000000b1e0 <__modti3>:
    b1e0:	d503245f 	bti	c
    b1e4:	d2800004 	mov	x4, #0x0                   	// #0
    b1e8:	b6f80081 	tbz	x1, #63, b1f8 <__modti3+0x18>
    b1ec:	eb0003e0 	negs	x0, x0
    b1f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b1f4:	da0103e1 	ngc	x1, x1
    b1f8:	f100007f 	cmp	x3, #0x0
    b1fc:	5400128b 	b.lt	b44c <__modti3+0x26c>  // b.tstop
    b200:	aa0003e7 	mov	x7, x0
    b204:	aa0103e6 	mov	x6, x1
    b208:	540004e1 	b.ne	b2a4 <__modti3+0xc4>  // b.any
    b20c:	eb02003f 	cmp	x1, x2
    b210:	54000dc2 	b.cs	b3c8 <__modti3+0x1e8>  // b.hs, b.nlast
    b214:	dac01043 	clz	x3, x2
    b218:	aa0303e5 	mov	x5, x3
    b21c:	b40000e3 	cbz	x3, b238 <__modti3+0x58>
    b220:	4b0303e6 	neg	w6, w3
    b224:	9ac32021 	lsl	x1, x1, x3
    b228:	9ac32042 	lsl	x2, x2, x3
    b22c:	9ac62406 	lsr	x6, x0, x6
    b230:	aa0100c6 	orr	x6, x6, x1
    b234:	9ac32007 	lsl	x7, x0, x3
    b238:	d360fc40 	lsr	x0, x2, #32
    b23c:	92407c43 	and	x3, x2, #0xffffffff
    b240:	9ac008c1 	udiv	x1, x6, x0
    b244:	9b009826 	msub	x6, x1, x0, x6
    b248:	9b017c61 	mul	x1, x3, x1
    b24c:	93c780c6 	extr	x6, x6, x7, #32
    b250:	eb06003f 	cmp	x1, x6
    b254:	540000a9 	b.ls	b268 <__modti3+0x88>  // b.plast
    b258:	ab060046 	adds	x6, x2, x6
    b25c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b260:	8b0200c8 	add	x8, x6, x2
    b264:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b268:	cb0100c6 	sub	x6, x6, x1
    b26c:	9ac008c8 	udiv	x8, x6, x0
    b270:	9b009901 	msub	x1, x8, x0, x6
    b274:	aa0703e0 	mov	x0, x7
    b278:	9b087c63 	mul	x3, x3, x8
    b27c:	b3607c20 	bfi	x0, x1, #32, #32
    b280:	eb00007f 	cmp	x3, x0
    b284:	54001088 	b.hi	b494 <__modti3+0x2b4>  // b.pmore
    b288:	cb030000 	sub	x0, x0, x3
    b28c:	9ac52400 	lsr	x0, x0, x5
    b290:	d2800001 	mov	x1, #0x0                   	// #0
    b294:	b4000064 	cbz	x4, b2a0 <__modti3+0xc0>
    b298:	eb0003e0 	negs	x0, x0
    b29c:	da0103e1 	ngc	x1, x1
    b2a0:	d65f03c0 	ret
    b2a4:	dac01066 	clz	x6, x3
    b2a8:	eb03003f 	cmp	x1, x3
    b2ac:	54ffff43 	b.cc	b294 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b2b0:	93407cc5 	sxtw	x5, w6
    b2b4:	d2800808 	mov	x8, #0x40                  	// #64
    b2b8:	cb050108 	sub	x8, x8, x5
    b2bc:	9ac62063 	lsl	x3, x3, x6
    b2c0:	9ac62025 	lsl	x5, x1, x6
    b2c4:	9ac82447 	lsr	x7, x2, x8
    b2c8:	aa0300e7 	orr	x7, x7, x3
    b2cc:	9ac82423 	lsr	x3, x1, x8
    b2d0:	92407cec 	and	x12, x7, #0xffffffff
    b2d4:	d360fcea 	lsr	x10, x7, #32
    b2d8:	9ac82401 	lsr	x1, x0, x8
    b2dc:	aa050021 	orr	x1, x1, x5
    b2e0:	9ac62042 	lsl	x2, x2, x6
    b2e4:	9ac62000 	lsl	x0, x0, x6
    b2e8:	9aca086b 	udiv	x11, x3, x10
    b2ec:	9b0a8d63 	msub	x3, x11, x10, x3
    b2f0:	aa0b03e5 	mov	x5, x11
    b2f4:	9b0b7d89 	mul	x9, x12, x11
    b2f8:	93c18063 	extr	x3, x3, x1, #32
    b2fc:	eb03013f 	cmp	x9, x3
    b300:	540000a9 	b.ls	b314 <__modti3+0x134>  // b.plast
    b304:	ab0300e3 	adds	x3, x7, x3
    b308:	d1000565 	sub	x5, x11, #0x1
    b30c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b310:	54001168 	b.hi	b53c <__modti3+0x35c>  // b.pmore
    b314:	cb090063 	sub	x3, x3, x9
    b318:	9aca086b 	udiv	x11, x3, x10
    b31c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b320:	aa0b03e9 	mov	x9, x11
    b324:	9b0b7d8c 	mul	x12, x12, x11
    b328:	b3607d41 	bfi	x1, x10, #32, #32
    b32c:	eb01019f 	cmp	x12, x1
    b330:	540000a9 	b.ls	b344 <__modti3+0x164>  // b.plast
    b334:	ab0100e1 	adds	x1, x7, x1
    b338:	d1000569 	sub	x9, x11, #0x1
    b33c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b340:	54000f88 	b.hi	b530 <__modti3+0x350>  // b.pmore
    b344:	aa058123 	orr	x3, x9, x5, lsl #32
    b348:	92407c4b 	and	x11, x2, #0xffffffff
    b34c:	2a0903e9 	mov	w9, w9
    b350:	d360fc4a 	lsr	x10, x2, #32
    b354:	d360fc63 	lsr	x3, x3, #32
    b358:	cb0c0021 	sub	x1, x1, x12
    b35c:	aa0a03ec 	mov	x12, x10
    b360:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b364:	9b0b7d25 	mul	x5, x9, x11
    b368:	9b0b7c6b 	mul	x11, x3, x11
    b36c:	9b0a2d29 	madd	x9, x9, x10, x11
    b370:	92407caa 	and	x10, x5, #0xffffffff
    b374:	9b0c7c63 	mul	x3, x3, x12
    b378:	8b458125 	add	x5, x9, x5, lsr #32
    b37c:	8b0d0069 	add	x9, x3, x13
    b380:	eb05017f 	cmp	x11, x5
    b384:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b388:	8b058149 	add	x9, x10, x5, lsl #32
    b38c:	8b458063 	add	x3, x3, x5, lsr #32
    b390:	eb03003f 	cmp	x1, x3
    b394:	54000063 	b.cc	b3a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b398:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b39c:	54000082 	b.cs	b3ac <__modti3+0x1cc>  // b.hs, b.nlast
    b3a0:	eb020129 	subs	x9, x9, x2
    b3a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b3a8:	cb070063 	sub	x3, x3, x7
    b3ac:	eb090000 	subs	x0, x0, x9
    b3b0:	da030021 	sbc	x1, x1, x3
    b3b4:	9ac62400 	lsr	x0, x0, x6
    b3b8:	9ac82028 	lsl	x8, x1, x8
    b3bc:	aa000100 	orr	x0, x8, x0
    b3c0:	9ac62421 	lsr	x1, x1, x6
    b3c4:	17ffffb4 	b	b294 <__modti3+0xb4>
    b3c8:	b5000062 	cbnz	x2, b3d4 <__modti3+0x1f4>
    b3cc:	d2800023 	mov	x3, #0x1                   	// #1
    b3d0:	9ac20862 	udiv	x2, x3, x2
    b3d4:	dac01048 	clz	x8, x2
    b3d8:	aa0803e5 	mov	x5, x8
    b3dc:	b5000668 	cbnz	x8, b4a8 <__modti3+0x2c8>
    b3e0:	cb020020 	sub	x0, x1, x2
    b3e4:	d360fc49 	lsr	x9, x2, #32
    b3e8:	92407c4a 	and	x10, x2, #0xffffffff
    b3ec:	9ac90801 	udiv	x1, x0, x9
    b3f0:	9b098020 	msub	x0, x1, x9, x0
    b3f4:	9b0a7c21 	mul	x1, x1, x10
    b3f8:	93c78000 	extr	x0, x0, x7, #32
    b3fc:	eb00003f 	cmp	x1, x0
    b400:	540000a9 	b.ls	b414 <__modti3+0x234>  // b.plast
    b404:	ab000040 	adds	x0, x2, x0
    b408:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b40c:	8b020003 	add	x3, x0, x2
    b410:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b414:	cb010001 	sub	x1, x0, x1
    b418:	9ac90820 	udiv	x0, x1, x9
    b41c:	9b098403 	msub	x3, x0, x9, x1
    b420:	aa0703e1 	mov	x1, x7
    b424:	9b0a7c00 	mul	x0, x0, x10
    b428:	b3607c61 	bfi	x1, x3, #32, #32
    b42c:	eb01001f 	cmp	x0, x1
    b430:	540000a9 	b.ls	b444 <__modti3+0x264>  // b.plast
    b434:	ab010041 	adds	x1, x2, x1
    b438:	8b020022 	add	x2, x1, x2
    b43c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b440:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b444:	cb000020 	sub	x0, x1, x0
    b448:	17ffff91 	b	b28c <__modti3+0xac>
    b44c:	eb0203e5 	negs	x5, x2
    b450:	aa0003e7 	mov	x7, x0
    b454:	da0303e8 	ngc	x8, x3
    b458:	aa0503e2 	mov	x2, x5
    b45c:	aa0803e3 	mov	x3, x8
    b460:	aa0103e6 	mov	x6, x1
    b464:	b4ffed48 	cbz	x8, b20c <__modti3+0x2c>
    b468:	eb01011f 	cmp	x8, x1
    b46c:	54fff148 	b.hi	b294 <__modti3+0xb4>  // b.pmore
    b470:	dac01109 	clz	x9, x8
    b474:	2a0903e6 	mov	w6, w9
    b478:	b5fff1c9 	cbnz	x9, b2b0 <__modti3+0xd0>
    b47c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b480:	54000068 	b.hi	b48c <__modti3+0x2ac>  // b.pmore
    b484:	eb050007 	subs	x7, x0, x5
    b488:	da080021 	sbc	x1, x1, x8
    b48c:	aa0703e0 	mov	x0, x7
    b490:	17ffff81 	b	b294 <__modti3+0xb4>
    b494:	ab000040 	adds	x0, x2, x0
    b498:	8b020002 	add	x2, x0, x2
    b49c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b4a0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b4a4:	17ffff79 	b	b288 <__modti3+0xa8>
    b4a8:	9ac82042 	lsl	x2, x2, x8
    b4ac:	d2800803 	mov	x3, #0x40                  	// #64
    b4b0:	cb080063 	sub	x3, x3, x8
    b4b4:	d360fc49 	lsr	x9, x2, #32
    b4b8:	9ac82027 	lsl	x7, x1, x8
    b4bc:	92407c4a 	and	x10, x2, #0xffffffff
    b4c0:	9ac32426 	lsr	x6, x1, x3
    b4c4:	9ac32403 	lsr	x3, x0, x3
    b4c8:	aa070063 	orr	x3, x3, x7
    b4cc:	9ac908c1 	udiv	x1, x6, x9
    b4d0:	9ac82007 	lsl	x7, x0, x8
    b4d4:	9b099820 	msub	x0, x1, x9, x6
    b4d8:	9b017d41 	mul	x1, x10, x1
    b4dc:	93c38000 	extr	x0, x0, x3, #32
    b4e0:	eb00003f 	cmp	x1, x0
    b4e4:	540000a9 	b.ls	b4f8 <__modti3+0x318>  // b.plast
    b4e8:	ab000040 	adds	x0, x2, x0
    b4ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b4f0:	8b020006 	add	x6, x0, x2
    b4f4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b4f8:	cb010000 	sub	x0, x0, x1
    b4fc:	9ac90801 	udiv	x1, x0, x9
    b500:	9b098026 	msub	x6, x1, x9, x0
    b504:	aa0303e0 	mov	x0, x3
    b508:	9b017d41 	mul	x1, x10, x1
    b50c:	b3607cc0 	bfi	x0, x6, #32, #32
    b510:	eb00003f 	cmp	x1, x0
    b514:	540000a9 	b.ls	b528 <__modti3+0x348>  // b.plast
    b518:	ab000040 	adds	x0, x2, x0
    b51c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b520:	8b020003 	add	x3, x0, x2
    b524:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b528:	cb010000 	sub	x0, x0, x1
    b52c:	17ffffb0 	b	b3ec <__modti3+0x20c>
    b530:	d1000969 	sub	x9, x11, #0x2
    b534:	8b070021 	add	x1, x1, x7
    b538:	17ffff83 	b	b344 <__modti3+0x164>
    b53c:	d1000965 	sub	x5, x11, #0x2
    b540:	8b070063 	add	x3, x3, x7
    b544:	17ffff74 	b	b314 <__modti3+0x134>
    b548:	d503201f 	nop
    b54c:	d503201f 	nop

000000000000b550 <atexit>:
    b550:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b554:	b00000a2 	adrp	x2, 20000 <__data_start>
    b558:	d2800001 	mov	x1, #0x0                   	// #0
    b55c:	910003fd 	mov	x29, sp
    b560:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b564:	f9400442 	ldr	x2, [x2, #8]
    b568:	17ffdc86 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b56c <_fini>:
    b56c:	d503201f 	nop
    b570:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b574:	910003fd 	mov	x29, sp
    b578:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b57c:	d65f03c0 	ret
