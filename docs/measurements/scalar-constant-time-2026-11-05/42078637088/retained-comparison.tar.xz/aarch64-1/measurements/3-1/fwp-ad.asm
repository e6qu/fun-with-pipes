
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	90000045 	adrp	x5, a000 <__divti3+0xa0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912200a5 	add	x5, x5, #0x880
    2aa0:	90000044 	adrp	x4, a000 <__divti3+0xa0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91222084 	add	x4, x4, #0x888
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11a50>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2b34:	91318000 	add	x0, x0, #0xc60
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000022 	adrp	x2, 7000 <fwp_write+0x2ec>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91340042 	add	x2, x2, #0xd00
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430a60 	ldr	w0, [x19, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2c7c:	9131c000 	add	x0, x0, #0xc70
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2c8c:	91344000 	add	x0, x0, #0xd10
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2ca4:	9133a000 	add	x0, x0, #0xce8
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2cb0:	9132e000 	add	x0, x0, #0xcb8
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	90000040 	adrp	x0, a000 <__divti3+0xa0>
    2cbc:	91324000 	add	x0, x0, #0xc90
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x980>
    2eb4:	910cc021 	add	x1, x1, #0x330
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3050:	911a2000 	add	x0, x0, #0x688
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x980>
    3118:	910c4021 	add	x1, x1, #0x310
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    33f0:	911a2000 	add	x0, x0, #0x688
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	f0000021 	adrp	x1, a000 <__divti3+0xa0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	911a8021 	add	x1, x1, #0x6a0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	f0000021 	adrp	x1, a000 <__divti3+0xa0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	911aa021 	add	x1, x1, #0x6a8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	f0000021 	adrp	x1, a000 <__divti3+0xa0>
    3560:	911ac021 	add	x1, x1, #0x6b0
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	f0000022 	adrp	x2, a000 <__divti3+0xa0>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	911ae042 	add	x2, x2, #0x6b8
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    36d0:	911a2000 	add	x0, x0, #0x688
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    36f0:	911b2000 	add	x0, x0, #0x6c8
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3788:	911ba000 	add	x0, x0, #0x6e8
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3798:	911c2000 	add	x0, x0, #0x708
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x980>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc0d020 	ldr	q0, [x1, #832]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3898:	911cc000 	add	x0, x0, #0x730
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3908:	911d8000 	add	x0, x0, #0x760
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	f0000024 	adrp	x4, a000 <__divti3+0xa0>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	911ec084 	add	x4, x4, #0x7b0
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	f0000024 	adrp	x4, a000 <__divti3+0xa0>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	911f2084 	add	x4, x4, #0x7c8
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	f0000024 	adrp	x4, a000 <__divti3+0xa0>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	911ee084 	add	x4, x4, #0x7b8
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3d28:	91150042 	add	x2, x2, #0x540
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	f0000021 	adrp	x1, a000 <__divti3+0xa0>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	911f4021 	add	x1, x1, #0x7d0
    3d84:	911f6000 	add	x0, x0, #0x7d8
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	f0000022 	adrp	x2, a000 <__divti3+0xa0>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	911fe042 	add	x2, x2, #0x7f8
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e8c:	91110061 	add	x1, x3, #0x440
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e9c:	91150262 	add	x2, x19, #0x540
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x980>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3ecc:	91120021 	add	x1, x1, #0x480
    3ed0:	3dc0d443 	ldr	q3, [x2, #848]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3efc:	91110063 	add	x3, x3, #0x440
    3f00:	91138084 	add	x4, x4, #0x4e0
    3f04:	91150266 	add	x6, x19, #0x540
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91150275 	add	x21, x19, #0x540
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	f0000020 	adrp	x0, a000 <__divti3+0xa0>
    3fe8:	9122a000 	add	x0, x0, #0x8a8
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91150273 	add	x19, x19, #0x540
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    414c:	9122e000 	add	x0, x0, #0x8b8
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	9122e000 	add	x0, x0, #0x8b8
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	9122e000 	add	x0, x0, #0x8b8
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    443c:	91234000 	add	x0, x0, #0x8d0
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	911502a2 	add	x2, x21, #0x540
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    44f4:	9124a000 	add	x0, x0, #0x928
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	911502b5 	add	x21, x21, #0x540
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    4550:	91240000 	add	x0, x0, #0x900
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    4560:	91254000 	add	x0, x0, #0x950
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    45a0:	91150262 	add	x2, x19, #0x540
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	91150273 	add	x19, x19, #0x540
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	d0000020 	adrp	x0, a000 <__divti3+0xa0>
    4600:	9124a000 	add	x0, x0, #0x928
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    4620:	911502c2 	add	x2, x22, #0x540
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	911502c2 	add	x2, x22, #0x540
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	911502d6 	add	x22, x22, #0x540
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4740:	911502b5 	add	x21, x21, #0x540
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4804:	911502a1 	add	x1, x21, #0x540
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	911502b5 	add	x21, x21, #0x540
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	911502a1 	add	x1, x21, #0x540
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	911502a0 	add	x0, x21, #0x540
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	911502b5 	add	x21, x21, #0x540
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a08:	91150359 	add	x25, x26, #0x540
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	54000e8b 	b.lt	507c <fwp_p_ad_push+0x1d8>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	aa0003e4 	mov	x4, x0
    4eb8:	910003fd 	mov	x29, sp
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0003f5 	mov	x21, x0
    4ec4:	aa020000 	orr	x0, x0, x2
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f7 	mov	x23, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	b6f80900 	tbz	x0, #63, 4ffc <fwp_p_ad_push+0x158>
    4ee0:	a90153f3 	stp	x19, x20, [sp, #16]
    4ee4:	9360fc80 	asr	x0, x4, #32
    4ee8:	b6f800c4 	tbz	x4, #63, 4f00 <fwp_p_ad_push+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc40 	asr	x0, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f00:	97fffa6c 	bl	38b0 <fwp_tape_of>
    4f04:	aa0003f3 	mov	x19, x0
    4f08:	f9403000 	ldr	x0, [x0, #96]
    4f0c:	b5001280 	cbnz	x0, 515c <fwp_p_ad_push+0x2b8>
    4f10:	f9400a76 	ldr	x22, [x19, #16]
    4f14:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f18:	eb0002df 	cmp	x22, x0
    4f1c:	54000e2c 	b.gt	50e0 <fwp_p_ad_push+0x23c>
    4f20:	eb3542df 	cmp	x22, w21, uxtw
    4f24:	54000d4d 	b.le	50cc <fwp_p_ad_push+0x228>
    4f28:	b7f80077 	tbnz	x23, #63, 4f34 <fwp_p_ad_push+0x90>
    4f2c:	eb3742df 	cmp	x22, w23, uxtw
    4f30:	54000ced 	b.le	50cc <fwp_p_ad_push+0x228>
    4f34:	f9400678 	ldr	x24, [x19, #8]
    4f38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f3c:	cb1802d8 	sub	x24, x22, x24
    4f40:	91000701 	add	x1, x24, #0x1
    4f44:	eb00003f 	cmp	x1, x0
    4f48:	54000cc8 	b.hi	50e0 <fwp_p_ad_push+0x23c>  // b.pmore
    4f4c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f50:	a90573fb 	stp	x27, x28, [sp, #80]
    4f54:	eb14003f 	cmp	x1, x20
    4f58:	5400068d 	b.le	5028 <fwp_p_ad_push+0x184>
    4f5c:	f100029f 	cmp	x20, #0x0
    4f60:	d2800803 	mov	x3, #0x40                  	// #64
    4f64:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f68:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	5400008d 	b.le	4f84 <fwp_p_ad_push+0xe0>
    4f78:	eb02029f 	cmp	x20, x2
    4f7c:	5400052d 	b.le	5020 <fwp_p_ad_push+0x17c>
    4f80:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f84:	d37df299 	lsl	x25, x20, #3
    4f88:	aa1903e1 	mov	x1, x25
    4f8c:	97fff639 	bl	2870 <realloc@plt>
    4f90:	aa0003e1 	mov	x1, x0
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_p_ad_push+0x250>
    4f98:	f9400e62 	ldr	x2, [x19, #24]
    4f9c:	f9001261 	str	x1, [x19, #32]
    4fa0:	f9401a60 	ldr	x0, [x19, #48]
    4fa4:	d37cee9a 	lsl	x26, x20, #4
    4fa8:	8b020821 	add	x1, x1, x2, lsl #2
    4fac:	f9001661 	str	x1, [x19, #40]
    4fb0:	aa1a03e1 	mov	x1, x26
    4fb4:	97fff62f 	bl	2870 <realloc@plt>
    4fb8:	aa0003e2 	mov	x2, x0
    4fbc:	b40009c0 	cbz	x0, 50f4 <fwp_p_ad_push+0x250>
    4fc0:	f9400e61 	ldr	x1, [x19, #24]
    4fc4:	d37df31b 	lsl	x27, x24, #3
    4fc8:	d37ef685 	lsl	x5, x20, #2
    4fcc:	d37ef71c 	lsl	x28, x24, #2
    4fd0:	8b190004 	add	x4, x0, x25
    4fd4:	8b010c01 	add	x1, x0, x1, lsl #3
    4fd8:	a9030660 	stp	x0, x1, [x19, #48]
    4fdc:	b5000558 	cbnz	x24, 5084 <fwp_p_ad_push+0x1e0>
    4fe0:	f9001e64 	str	x4, [x19, #56]
    4fe4:	f9401260 	ldr	x0, [x19, #32]
    4fe8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fec:	8b050001 	add	x1, x0, x5
    4ff0:	f9000e74 	str	x20, [x19, #24]
    4ff4:	f9001661 	str	x1, [x19, #40]
    4ff8:	14000010 	b	5038 <fwp_p_ad_push+0x194>
    4ffc:	9360fc40 	asr	x0, x2, #32
    5000:	a90153f3 	stp	x19, x20, [sp, #16]
    5004:	eb84801f 	cmp	x0, x4, asr #32
    5008:	54fff7c0 	b.eq	4f00 <fwp_p_ad_push+0x5c>  // b.none
    500c:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5010:	9125c000 	add	x0, x0, #0x970
    5014:	a9046bf9 	stp	x25, x26, [sp, #64]
    5018:	a90573fb 	stp	x27, x28, [sp, #80]
    501c:	97fff959 	bl	3580 <fwp_trap>
    5020:	d37ffa94 	lsl	x20, x20, #1
    5024:	17ffffd3 	b	4f70 <fwp_p_ad_push+0xcc>
    5028:	a9428a61 	ldp	x1, x2, [x19, #40]
    502c:	d37ef71c 	lsl	x28, x24, #2
    5030:	f9401e64 	ldr	x4, [x19, #56]
    5034:	d37df31b 	lsl	x27, x24, #3
    5038:	b83c6815 	str	w21, [x0, x28]
    503c:	f10002ff 	cmp	x23, #0x0
    5040:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5044:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5048:	fc3b6849 	str	d9, [x2, x27]
    504c:	aa1602a0 	orr	x0, x21, x22
    5050:	b83c6837 	str	w23, [x1, x28]
    5054:	910006d6 	add	x22, x22, #0x1
    5058:	a94363f7 	ldp	x23, x24, [sp, #48]
    505c:	fc3b6888 	str	d8, [x4, x27]
    5060:	a94573fb 	ldp	x27, x28, [sp, #80]
    5064:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5068:	f9000a76 	str	x22, [x19, #16]
    506c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5078:	d65f03c0 	ret
    507c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5080:	d65f03c0 	ret
    5084:	eb1a033f 	cmp	x25, x26
    5088:	aa0403e0 	mov	x0, x4
    508c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5090:	aa1b03e2 	mov	x2, x27
    5094:	cb190063 	sub	x3, x3, x25
    5098:	f9003fe5 	str	x5, [sp, #120]
    509c:	97fff661 	bl	2a20 <__memmove_chk@plt>
    50a0:	a9420660 	ldp	x0, x1, [x19, #32]
    50a4:	aa1c03e2 	mov	x2, x28
    50a8:	f9401a63 	ldr	x3, [x19, #48]
    50ac:	f9403fe5 	ldr	x5, [sp, #120]
    50b0:	8b190063 	add	x3, x3, x25
    50b4:	f9001e63 	str	x3, [x19, #56]
    50b8:	8b050000 	add	x0, x0, x5
    50bc:	97fff58d 	bl	26f0 <memmove@plt>
    50c0:	a9431262 	ldp	x2, x4, [x19, #48]
    50c4:	f9403fe5 	ldr	x5, [sp, #120]
    50c8:	17ffffc7 	b	4fe4 <fwp_p_ad_push+0x140>
    50cc:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    50d0:	91282000 	add	x0, x0, #0xa08
    50d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50d8:	a90573fb 	stp	x27, x28, [sp, #80]
    50dc:	97fff929 	bl	3580 <fwp_trap>
    50e0:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    50e4:	9127a000 	add	x0, x0, #0x9e8
    50e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50ec:	a90573fb 	stp	x27, x28, [sp, #80]
    50f0:	97fff924 	bl	3580 <fwp_trap>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	97fff7a6 	bl	2f90 <fwp_tape_unlink_scope>
    50fc:	f9401260 	ldr	x0, [x19, #32]
    5100:	97fff610 	bl	2940 <free@plt>
    5104:	f9401a60 	ldr	x0, [x19, #48]
    5108:	97fff60e 	bl	2940 <free@plt>
    510c:	f9402260 	ldr	x0, [x19, #64]
    5110:	97fff60c 	bl	2940 <free@plt>
    5114:	f9000e7f 	str	xzr, [x19, #24]
    5118:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    511c:	f947e821 	ldr	x1, [x1, #4048]
    5120:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5124:	d2800262 	mov	x2, #0x13                  	// #19
    5128:	4f000400 	movi	v0.4s, #0x0
    512c:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5130:	f9400023 	ldr	x3, [x1]
    5134:	b900067f 	str	wzr, [x19, #4]
    5138:	d2800021 	mov	x1, #0x1                   	// #1
    513c:	911a2000 	add	x0, x0, #0x688
    5140:	3c808260 	stur	q0, [x19, #8]
    5144:	ad010260 	stp	q0, q0, [x19, #32]
    5148:	97fff60e 	bl	2980 <fwrite@plt>
    514c:	d2800000 	mov	x0, #0x0                   	// #0
    5150:	97fff618 	bl	29b0 <fflush@plt>
    5154:	52800cc0 	mov	w0, #0x66                  	// #102
    5158:	97fff626 	bl	29f0 <_Exit@plt>
    515c:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5160:	9126e000 	add	x0, x0, #0x9b8
    5164:	a9046bf9 	stp	x25, x26, [sp, #64]
    5168:	a90573fb 	stp	x27, x28, [sp, #80]
    516c:	97fff905 	bl	3580 <fwp_trap>

0000000000005170 <w120>:
    5170:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5174:	9e660003 	fmov	x3, d0
    5178:	aa0003e2 	mov	x2, x0
    517c:	910003fd 	mov	x29, sp
    5180:	6d0327e8 	stp	d8, d9, [sp, #48]
    5184:	1e604028 	fmov	d8, d1
    5188:	1e600809 	fmul	d9, d0, d0
    518c:	fd0023ea 	str	d10, [sp, #64]
    5190:	1e60400a 	fmov	d10, d0
    5194:	a90153f3 	stp	x19, x20, [sp, #16]
    5198:	aa0003f3 	mov	x19, x0
    519c:	aa0103f4 	mov	x20, x1
    51a0:	aa0303e1 	mov	x1, x3
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	97ffff3f 	bl	4ea4 <fwp_p_ad_push>
    51ac:	1e693908 	fsub	d8, d8, d9
    51b0:	aa1403e2 	mov	x2, x20
    51b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51bc:	9e660116 	fmov	x22, d8
    51c0:	97ffff39 	bl	4ea4 <fwp_p_ad_push>
    51c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    51c8:	aa0003e1 	mov	x1, x0
    51cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51d0:	aa1303e0 	mov	x0, x19
    51d4:	1e6a3929 	fsub	d9, d9, d10
    51d8:	aa0103f3 	mov	x19, x1
    51dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    51e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51e4:	9e660135 	fmov	x21, d9
    51e8:	97ffff2f 	bl	4ea4 <fwp_p_ad_push>
    51ec:	1e680908 	fmul	d8, d8, d8
    51f0:	aa0003f4 	mov	x20, x0
    51f4:	aa1603e3 	mov	x3, x22
    51f8:	aa1603e1 	mov	x1, x22
    51fc:	aa1303e2 	mov	x2, x19
    5200:	aa1303e0 	mov	x0, x19
    5204:	97ffff28 	bl	4ea4 <fwp_p_ad_push>
    5208:	aa0003e2 	mov	x2, x0
    520c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5210:	9e670020 	fmov	d0, x1
    5214:	9e660101 	fmov	x1, d8
    5218:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    521c:	1e600908 	fmul	d8, d8, d0
    5220:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5224:	97ffff20 	bl	4ea4 <fwp_p_ad_push>
    5228:	1e690929 	fmul	d9, d9, d9
    522c:	aa0003f3 	mov	x19, x0
    5230:	aa1503e3 	mov	x3, x21
    5234:	aa1503e1 	mov	x1, x21
    5238:	aa1403e2 	mov	x2, x20
    523c:	aa1403e0 	mov	x0, x20
    5240:	97ffff19 	bl	4ea4 <fwp_p_ad_push>
    5244:	1e692908 	fadd	d8, d8, d9
    5248:	aa1303e2 	mov	x2, x19
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa0303e1 	mov	x1, x3
    5254:	97ffff14 	bl	4ea4 <fwp_p_ad_push>
    5258:	aa0003e1 	mov	x1, x0
    525c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5260:	9e660100 	fmov	x0, d8
    5264:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5268:	6d4327e8 	ldp	d8, d9, [sp, #48]
    526c:	fd4023ea 	ldr	d10, [sp, #64]
    5270:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5274:	d65f03c0 	ret
    5278:	d503201f 	nop
    527c:	d503201f 	nop

0000000000005280 <fwp_rc_share>:
    5280:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5284:	91150042 	add	x2, x2, #0x540
    5288:	f949d843 	ldr	x3, [x2, #5040]
    528c:	f949ec41 	ldr	x1, [x2, #5080]
    5290:	cb030000 	sub	x0, x0, x3
    5294:	eb01401f 	cmp	x0, x1, lsl #16
    5298:	540002c2 	b.cs	52f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    529c:	d350fc01 	lsr	x1, x0, #16
    52a0:	f949fc44 	ldr	x4, [x2, #5112]
    52a4:	8b010821 	add	x1, x1, x1, lsl #2
    52a8:	d37df021 	lsl	x1, x1, #3
    52ac:	8b010083 	add	x3, x4, x1
    52b0:	f9401062 	ldr	x2, [x3, #32]
    52b4:	b40001e2 	cbz	x2, 52f0 <fwp_rc_share+0x70>
    52b8:	38616881 	ldrb	w1, [x4, x1]
    52bc:	7100083f 	cmp	w1, #0x2
    52c0:	540001a0 	b.eq	52f4 <fwp_rc_share+0x74>  // b.none
    52c4:	7100043f 	cmp	w1, #0x1
    52c8:	54000141 	b.ne	52f0 <fwp_rc_share+0x70>  // b.any
    52cc:	29430464 	ldp	w4, w1, [x3, #24]
    52d0:	92403c00 	and	x0, x0, #0xffff
    52d4:	9b047c00 	mul	x0, x0, x4
    52d8:	d360fc00 	lsr	x0, x0, #32
    52dc:	eb01001f 	cmp	x0, x1
    52e0:	54000082 	b.cs	52f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    52e4:	8b000042 	add	x2, x2, x0
    52e8:	39400040 	ldrb	w0, [x2]
    52ec:	350000a0 	cbnz	w0, 5300 <fwp_rc_share+0x80>
    52f0:	d65f03c0 	ret
    52f4:	72003c1f 	tst	w0, #0xffff
    52f8:	54ffff80 	b.eq	52e8 <fwp_rc_share+0x68>  // b.none
    52fc:	d65f03c0 	ret
    5300:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5304:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5308:	9128a000 	add	x0, x0, #0xa28
    530c:	910003fd 	mov	x29, sp
    5310:	97fff89c 	bl	3580 <fwp_trap>

0000000000005314 <fwp_rc_free_arr>:
    5314:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5318:	91150063 	add	x3, x3, #0x540
    531c:	f949d861 	ldr	x1, [x3, #5040]
    5320:	f949ec62 	ldr	x2, [x3, #5080]
    5324:	cb010001 	sub	x1, x0, x1
    5328:	eb02403f 	cmp	x1, x2, lsl #16
    532c:	54000342 	b.cs	5394 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5330:	d350fc22 	lsr	x2, x1, #16
    5334:	f949fc65 	ldr	x5, [x3, #5112]
    5338:	8b020842 	add	x2, x2, x2, lsl #2
    533c:	d37df042 	lsl	x2, x2, #3
    5340:	8b0200a4 	add	x4, x5, x2
    5344:	f9401083 	ldr	x3, [x4, #32]
    5348:	b4000263 	cbz	x3, 5394 <fwp_rc_free_arr+0x80>
    534c:	386268a2 	ldrb	w2, [x5, x2]
    5350:	7100085f 	cmp	w2, #0x2
    5354:	540001c0 	b.eq	538c <fwp_rc_free_arr+0x78>  // b.none
    5358:	7100045f 	cmp	w2, #0x1
    535c:	540001c1 	b.ne	5394 <fwp_rc_free_arr+0x80>  // b.any
    5360:	29430885 	ldp	w5, w2, [x4, #24]
    5364:	92403c21 	and	x1, x1, #0xffff
    5368:	9b057c21 	mul	x1, x1, x5
    536c:	d360fc21 	lsr	x1, x1, #32
    5370:	eb02003f 	cmp	x1, x2
    5374:	54000102 	b.cs	5394 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5378:	8b010063 	add	x3, x3, x1
    537c:	39400061 	ldrb	w1, [x3]
    5380:	7100043f 	cmp	w1, #0x1
    5384:	54000081 	b.ne	5394 <fwp_rc_free_arr+0x80>  // b.any
    5388:	17fffd1a 	b	47f0 <fwp_mem_free>
    538c:	72003c3f 	tst	w1, #0xffff
    5390:	54ffff60 	b.eq	537c <fwp_rc_free_arr+0x68>  // b.none
    5394:	d65f03c0 	ret
    5398:	d503201f 	nop
    539c:	d503201f 	nop

00000000000053a0 <fwp_rc_dup>:
    53a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    53a4:	91150042 	add	x2, x2, #0x540
    53a8:	f949d841 	ldr	x1, [x2, #5040]
    53ac:	f949ec43 	ldr	x3, [x2, #5080]
    53b0:	cb010001 	sub	x1, x0, x1
    53b4:	eb03403f 	cmp	x1, x3, lsl #16
    53b8:	54000342 	b.cs	5420 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    53bc:	d350fc20 	lsr	x0, x1, #16
    53c0:	f949fc44 	ldr	x4, [x2, #5112]
    53c4:	8b000800 	add	x0, x0, x0, lsl #2
    53c8:	d37df002 	lsl	x2, x0, #3
    53cc:	8b020083 	add	x3, x4, x2
    53d0:	f9401060 	ldr	x0, [x3, #32]
    53d4:	b4000260 	cbz	x0, 5420 <fwp_rc_dup+0x80>
    53d8:	38626882 	ldrb	w2, [x4, x2]
    53dc:	7100085f 	cmp	w2, #0x2
    53e0:	54000220 	b.eq	5424 <fwp_rc_dup+0x84>  // b.none
    53e4:	7100045f 	cmp	w2, #0x1
    53e8:	540001c1 	b.ne	5420 <fwp_rc_dup+0x80>  // b.any
    53ec:	29430864 	ldp	w4, w2, [x3, #24]
    53f0:	92403c21 	and	x1, x1, #0xffff
    53f4:	9b047c21 	mul	x1, x1, x4
    53f8:	d360fc21 	lsr	x1, x1, #32
    53fc:	eb02003f 	cmp	x1, x2
    5400:	54000102 	b.cs	5420 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5404:	8b010000 	add	x0, x0, x1
    5408:	39400001 	ldrb	w1, [x0]
    540c:	340000a1 	cbz	w1, 5420 <fwp_rc_dup+0x80>
    5410:	7103f43f 	cmp	w1, #0xfd
    5414:	540000e8 	b.hi	5430 <fwp_rc_dup+0x90>  // b.pmore
    5418:	11000421 	add	w1, w1, #0x1
    541c:	39000001 	strb	w1, [x0]
    5420:	d65f03c0 	ret
    5424:	72003c3f 	tst	w1, #0xffff
    5428:	54ffff00 	b.eq	5408 <fwp_rc_dup+0x68>  // b.none
    542c:	d65f03c0 	ret
    5430:	17fffc09 	b	4454 <fwp_rc_wide_dup>

0000000000005434 <fwp_owned_entry173>:
    5434:	d10103ff 	sub	sp, sp, #0x40
    5438:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    543c:	f947f442 	ldr	x2, [x2, #4072]
    5440:	a9027bfd 	stp	x29, x30, [sp, #32]
    5444:	910083fd 	add	x29, sp, #0x20
    5448:	a90353f3 	stp	x19, x20, [sp, #48]
    544c:	f9400043 	ldr	x3, [x2]
    5450:	f9000fe3 	str	x3, [sp, #24]
    5454:	d2800003 	mov	x3, #0x0                   	// #0
    5458:	a9400c01 	ldp	x1, x3, [x0]
    545c:	f9400802 	ldr	x2, [x0, #16]
    5460:	ab020022 	adds	x2, x1, x2
    5464:	540006e6 	b.vs	5540 <fwp_owned_entry173+0x10c>
    5468:	910023e1 	add	x1, sp, #0x8
    546c:	52800000 	mov	w0, #0x0                   	// #0
    5470:	a9008be3 	stp	x3, x2, [sp, #8]
    5474:	97fffe44 	bl	4d84 <fwp_data.part.0.constprop.0>
    5478:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    547c:	91150063 	add	x3, x3, #0x540
    5480:	aa0003f3 	mov	x19, x0
    5484:	f949d861 	ldr	x1, [x3, #5040]
    5488:	f949ec60 	ldr	x0, [x3, #5080]
    548c:	cb010261 	sub	x1, x19, x1
    5490:	eb00403f 	cmp	x1, x0, lsl #16
    5494:	54000322 	b.cs	54f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5498:	d350fc22 	lsr	x2, x1, #16
    549c:	f949fc63 	ldr	x3, [x3, #5112]
    54a0:	8b020842 	add	x2, x2, x2, lsl #2
    54a4:	d37df042 	lsl	x2, x2, #3
    54a8:	8b020060 	add	x0, x3, x2
    54ac:	f9401014 	ldr	x20, [x0, #32]
    54b0:	b4000254 	cbz	x20, 54f8 <fwp_owned_entry173+0xc4>
    54b4:	38626862 	ldrb	w2, [x3, x2]
    54b8:	7100085f 	cmp	w2, #0x2
    54bc:	54000360 	b.eq	5528 <fwp_owned_entry173+0xf4>  // b.none
    54c0:	7100045f 	cmp	w2, #0x1
    54c4:	540001a1 	b.ne	54f8 <fwp_owned_entry173+0xc4>  // b.any
    54c8:	29430002 	ldp	w2, w0, [x0, #24]
    54cc:	92403c21 	and	x1, x1, #0xffff
    54d0:	9b027c21 	mul	x1, x1, x2
    54d4:	d360fc21 	lsr	x1, x1, #32
    54d8:	eb00003f 	cmp	x1, x0
    54dc:	540000e2 	b.cs	54f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    54e0:	8b010294 	add	x20, x20, x1
    54e4:	39400280 	ldrb	w0, [x20]
    54e8:	7103fc1f 	cmp	w0, #0xff
    54ec:	54000240 	b.eq	5534 <fwp_owned_entry173+0x100>  // b.none
    54f0:	52800020 	mov	w0, #0x1                   	// #1
    54f4:	39000280 	strb	w0, [x20]
    54f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    54fc:	f947f400 	ldr	x0, [x0, #4072]
    5500:	f9400fe2 	ldr	x2, [sp, #24]
    5504:	f9400001 	ldr	x1, [x0]
    5508:	eb010042 	subs	x2, x2, x1
    550c:	d2800001 	mov	x1, #0x0                   	// #0
    5510:	540001a1 	b.ne	5544 <fwp_owned_entry173+0x110>  // b.any
    5514:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5518:	aa1303e0 	mov	x0, x19
    551c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5520:	910103ff 	add	sp, sp, #0x40
    5524:	d65f03c0 	ret
    5528:	72003c3f 	tst	w1, #0xffff
    552c:	54fffe61 	b.ne	54f8 <fwp_owned_entry173+0xc4>  // b.any
    5530:	17ffffed 	b	54e4 <fwp_owned_entry173+0xb0>
    5534:	aa1403e0 	mov	x0, x20
    5538:	97fffc0e 	bl	4570 <fwp_rc_forget_slot>
    553c:	17ffffed 	b	54f0 <fwp_owned_entry173+0xbc>
    5540:	97fff550 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5544:	97fff4cf 	bl	2880 <__stack_chk_fail@plt>
    5548:	d503201f 	nop
    554c:	d503201f 	nop

0000000000005550 <e173>:
    5550:	d10103ff 	sub	sp, sp, #0x40
    5554:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5558:	f947f442 	ldr	x2, [x2, #4072]
    555c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5560:	910083fd 	add	x29, sp, #0x20
    5564:	a90353f3 	stp	x19, x20, [sp, #48]
    5568:	f9400043 	ldr	x3, [x2]
    556c:	f9000fe3 	str	x3, [sp, #24]
    5570:	d2800003 	mov	x3, #0x0                   	// #0
    5574:	a9400c01 	ldp	x1, x3, [x0]
    5578:	f9400802 	ldr	x2, [x0, #16]
    557c:	ab020022 	adds	x2, x1, x2
    5580:	54000726 	b.vs	5664 <e173+0x114>
    5584:	910023e1 	add	x1, sp, #0x8
    5588:	52800000 	mov	w0, #0x0                   	// #0
    558c:	a9008be3 	stp	x3, x2, [sp, #8]
    5590:	97fffdfd 	bl	4d84 <fwp_data.part.0.constprop.0>
    5594:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5598:	91150063 	add	x3, x3, #0x540
    559c:	aa0003f3 	mov	x19, x0
    55a0:	f949d861 	ldr	x1, [x3, #5040]
    55a4:	f949ec60 	ldr	x0, [x3, #5080]
    55a8:	cb010261 	sub	x1, x19, x1
    55ac:	eb00403f 	cmp	x1, x0, lsl #16
    55b0:	54000322 	b.cs	5614 <e173+0xc4>  // b.hs, b.nlast
    55b4:	d350fc22 	lsr	x2, x1, #16
    55b8:	f949fc63 	ldr	x3, [x3, #5112]
    55bc:	8b020842 	add	x2, x2, x2, lsl #2
    55c0:	d37df042 	lsl	x2, x2, #3
    55c4:	8b020060 	add	x0, x3, x2
    55c8:	f9401014 	ldr	x20, [x0, #32]
    55cc:	b4000254 	cbz	x20, 5614 <e173+0xc4>
    55d0:	38626862 	ldrb	w2, [x3, x2]
    55d4:	7100085f 	cmp	w2, #0x2
    55d8:	540003a0 	b.eq	564c <e173+0xfc>  // b.none
    55dc:	7100045f 	cmp	w2, #0x1
    55e0:	540001a1 	b.ne	5614 <e173+0xc4>  // b.any
    55e4:	29430002 	ldp	w2, w0, [x0, #24]
    55e8:	92403c21 	and	x1, x1, #0xffff
    55ec:	9b027c21 	mul	x1, x1, x2
    55f0:	d360fc21 	lsr	x1, x1, #32
    55f4:	eb00003f 	cmp	x1, x0
    55f8:	540000e2 	b.cs	5614 <e173+0xc4>  // b.hs, b.nlast
    55fc:	8b010294 	add	x20, x20, x1
    5600:	39400280 	ldrb	w0, [x20]
    5604:	7103fc1f 	cmp	w0, #0xff
    5608:	54000280 	b.eq	5658 <e173+0x108>  // b.none
    560c:	52800020 	mov	w0, #0x1                   	// #1
    5610:	39000280 	strb	w0, [x20]
    5614:	aa1303e0 	mov	x0, x19
    5618:	97ffff1a 	bl	5280 <fwp_rc_share>
    561c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5620:	f947f400 	ldr	x0, [x0, #4072]
    5624:	f9400fe2 	ldr	x2, [sp, #24]
    5628:	f9400001 	ldr	x1, [x0]
    562c:	eb010042 	subs	x2, x2, x1
    5630:	d2800001 	mov	x1, #0x0                   	// #0
    5634:	540001a1 	b.ne	5668 <e173+0x118>  // b.any
    5638:	a9427bfd 	ldp	x29, x30, [sp, #32]
    563c:	aa1303e0 	mov	x0, x19
    5640:	a94353f3 	ldp	x19, x20, [sp, #48]
    5644:	910103ff 	add	sp, sp, #0x40
    5648:	d65f03c0 	ret
    564c:	72003c3f 	tst	w1, #0xffff
    5650:	54fffe21 	b.ne	5614 <e173+0xc4>  // b.any
    5654:	17ffffeb 	b	5600 <e173+0xb0>
    5658:	aa1403e0 	mov	x0, x20
    565c:	97fffbc5 	bl	4570 <fwp_rc_forget_slot>
    5660:	17ffffeb 	b	560c <e173+0xbc>
    5664:	97fff507 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5668:	97fff486 	bl	2880 <__stack_chk_fail@plt>
    566c:	d503201f 	nop

0000000000005670 <fwp_drop0>:
    5670:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5674:	910003fd 	mov	x29, sp
    5678:	a90153f3 	stp	x19, x20, [sp, #16]
    567c:	f90013f5 	str	x21, [sp, #32]
    5680:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5684:	911502b4 	add	x20, x21, #0x540
    5688:	f949da81 	ldr	x1, [x20, #5040]
    568c:	f949ee82 	ldr	x2, [x20, #5080]
    5690:	cb010001 	sub	x1, x0, x1
    5694:	eb02403f 	cmp	x1, x2, lsl #16
    5698:	54000382 	b.cs	5708 <fwp_drop0+0x98>  // b.hs, b.nlast
    569c:	d350fc22 	lsr	x2, x1, #16
    56a0:	f949fe84 	ldr	x4, [x20, #5112]
    56a4:	8b020842 	add	x2, x2, x2, lsl #2
    56a8:	d37df042 	lsl	x2, x2, #3
    56ac:	8b020083 	add	x3, x4, x2
    56b0:	f9401073 	ldr	x19, [x3, #32]
    56b4:	b40002b3 	cbz	x19, 5708 <fwp_drop0+0x98>
    56b8:	38626882 	ldrb	w2, [x4, x2]
    56bc:	7100085f 	cmp	w2, #0x2
    56c0:	540002c0 	b.eq	5718 <fwp_drop0+0xa8>  // b.none
    56c4:	7100045f 	cmp	w2, #0x1
    56c8:	54000201 	b.ne	5708 <fwp_drop0+0x98>  // b.any
    56cc:	29430864 	ldp	w4, w2, [x3, #24]
    56d0:	92403c21 	and	x1, x1, #0xffff
    56d4:	9b047c21 	mul	x1, x1, x4
    56d8:	d360fc21 	lsr	x1, x1, #32
    56dc:	eb02003f 	cmp	x1, x2
    56e0:	54000142 	b.cs	5708 <fwp_drop0+0x98>  // b.hs, b.nlast
    56e4:	8b010273 	add	x19, x19, x1
    56e8:	39400261 	ldrb	w1, [x19]
    56ec:	340000e1 	cbz	w1, 5708 <fwp_drop0+0x98>
    56f0:	7100043f 	cmp	w1, #0x1
    56f4:	540001e0 	b.eq	5730 <fwp_drop0+0xc0>  // b.none
    56f8:	7103fc3f 	cmp	w1, #0xff
    56fc:	540002e0 	b.eq	5758 <fwp_drop0+0xe8>  // b.none
    5700:	51000421 	sub	w1, w1, #0x1
    5704:	39000261 	strb	w1, [x19]
    5708:	a94153f3 	ldp	x19, x20, [sp, #16]
    570c:	f94013f5 	ldr	x21, [sp, #32]
    5710:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5714:	d65f03c0 	ret
    5718:	72003c3f 	tst	w1, #0xffff
    571c:	54fffe60 	b.eq	56e8 <fwp_drop0+0x78>  // b.none
    5720:	a94153f3 	ldp	x19, x20, [sp, #16]
    5724:	f94013f5 	ldr	x21, [sp, #32]
    5728:	a8c37bfd 	ldp	x29, x30, [sp], #48
    572c:	d65f03c0 	ret
    5730:	f9400813 	ldr	x19, [x0, #16]
    5734:	97fffef8 	bl	5314 <fwp_rc_free_arr>
    5738:	911502a0 	add	x0, x21, #0x540
    573c:	f949d801 	ldr	x1, [x0, #5040]
    5740:	f949ec00 	ldr	x0, [x0, #5080]
    5744:	cb010261 	sub	x1, x19, x1
    5748:	eb00403f 	cmp	x1, x0, lsl #16
    574c:	54fffde2 	b.cs	5708 <fwp_drop0+0x98>  // b.hs, b.nlast
    5750:	aa1303e0 	mov	x0, x19
    5754:	17ffffd2 	b	569c <fwp_drop0+0x2c>
    5758:	ca534660 	eor	x0, x19, x19, lsr #17
    575c:	911502b5 	add	x21, x21, #0x540
    5760:	ca402400 	eor	x0, x0, x0, lsr #9
    5764:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5768:	f94a2400 	ldr	x0, [x0, #5192]
    576c:	b5000080 	cbnz	x0, 577c <fwp_drop0+0x10c>
    5770:	14000010 	b	57b0 <fwp_drop0+0x140>
    5774:	f9400800 	ldr	x0, [x0, #16]
    5778:	b40001c0 	cbz	x0, 57b0 <fwp_drop0+0x140>
    577c:	f9400001 	ldr	x1, [x0]
    5780:	eb13003f 	cmp	x1, x19
    5784:	54ffff81 	b.ne	5774 <fwp_drop0+0x104>  // b.any
    5788:	f9400401 	ldr	x1, [x0, #8]
    578c:	d1000421 	sub	x1, x1, #0x1
    5790:	f9000401 	str	x1, [x0, #8]
    5794:	f103f83f 	cmp	x1, #0xfe
    5798:	54fffb81 	b.ne	5708 <fwp_drop0+0x98>  // b.any
    579c:	aa1303e0 	mov	x0, x19
    57a0:	97fffb74 	bl	4570 <fwp_rc_forget_slot>
    57a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    57a8:	39000260 	strb	w0, [x19]
    57ac:	17ffffd7 	b	5708 <fwp_drop0+0x98>
    57b0:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    57b4:	9124a000 	add	x0, x0, #0x928
    57b8:	97fff772 	bl	3580 <fwp_trap>
    57bc:	d503201f 	nop

00000000000057c0 <fwp_drop1>:
    57c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57c4:	910003fd 	mov	x29, sp
    57c8:	a90153f3 	stp	x19, x20, [sp, #16]
    57cc:	f90013f5 	str	x21, [sp, #32]
    57d0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    57d4:	911502b4 	add	x20, x21, #0x540
    57d8:	f949da81 	ldr	x1, [x20, #5040]
    57dc:	f949ee82 	ldr	x2, [x20, #5080]
    57e0:	cb010001 	sub	x1, x0, x1
    57e4:	eb02403f 	cmp	x1, x2, lsl #16
    57e8:	54000382 	b.cs	5858 <fwp_drop1+0x98>  // b.hs, b.nlast
    57ec:	d350fc22 	lsr	x2, x1, #16
    57f0:	f949fe84 	ldr	x4, [x20, #5112]
    57f4:	8b020842 	add	x2, x2, x2, lsl #2
    57f8:	d37df042 	lsl	x2, x2, #3
    57fc:	8b020083 	add	x3, x4, x2
    5800:	f9401073 	ldr	x19, [x3, #32]
    5804:	b40002b3 	cbz	x19, 5858 <fwp_drop1+0x98>
    5808:	38626882 	ldrb	w2, [x4, x2]
    580c:	7100085f 	cmp	w2, #0x2
    5810:	540002c0 	b.eq	5868 <fwp_drop1+0xa8>  // b.none
    5814:	7100045f 	cmp	w2, #0x1
    5818:	54000201 	b.ne	5858 <fwp_drop1+0x98>  // b.any
    581c:	29430864 	ldp	w4, w2, [x3, #24]
    5820:	92403c21 	and	x1, x1, #0xffff
    5824:	9b047c21 	mul	x1, x1, x4
    5828:	d360fc21 	lsr	x1, x1, #32
    582c:	eb02003f 	cmp	x1, x2
    5830:	54000142 	b.cs	5858 <fwp_drop1+0x98>  // b.hs, b.nlast
    5834:	8b010273 	add	x19, x19, x1
    5838:	39400261 	ldrb	w1, [x19]
    583c:	340000e1 	cbz	w1, 5858 <fwp_drop1+0x98>
    5840:	7100043f 	cmp	w1, #0x1
    5844:	540001e0 	b.eq	5880 <fwp_drop1+0xc0>  // b.none
    5848:	7103fc3f 	cmp	w1, #0xff
    584c:	540002e0 	b.eq	58a8 <fwp_drop1+0xe8>  // b.none
    5850:	51000421 	sub	w1, w1, #0x1
    5854:	39000261 	strb	w1, [x19]
    5858:	a94153f3 	ldp	x19, x20, [sp, #16]
    585c:	f94013f5 	ldr	x21, [sp, #32]
    5860:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5864:	d65f03c0 	ret
    5868:	72003c3f 	tst	w1, #0xffff
    586c:	54fffe60 	b.eq	5838 <fwp_drop1+0x78>  // b.none
    5870:	a94153f3 	ldp	x19, x20, [sp, #16]
    5874:	f94013f5 	ldr	x21, [sp, #32]
    5878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    587c:	d65f03c0 	ret
    5880:	f9400813 	ldr	x19, [x0, #16]
    5884:	97fffea4 	bl	5314 <fwp_rc_free_arr>
    5888:	911502a0 	add	x0, x21, #0x540
    588c:	f949d801 	ldr	x1, [x0, #5040]
    5890:	f949ec00 	ldr	x0, [x0, #5080]
    5894:	cb010261 	sub	x1, x19, x1
    5898:	eb00403f 	cmp	x1, x0, lsl #16
    589c:	54fffde2 	b.cs	5858 <fwp_drop1+0x98>  // b.hs, b.nlast
    58a0:	aa1303e0 	mov	x0, x19
    58a4:	17ffffd2 	b	57ec <fwp_drop1+0x2c>
    58a8:	ca534660 	eor	x0, x19, x19, lsr #17
    58ac:	911502b5 	add	x21, x21, #0x540
    58b0:	ca402400 	eor	x0, x0, x0, lsr #9
    58b4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    58b8:	f94a2400 	ldr	x0, [x0, #5192]
    58bc:	b5000080 	cbnz	x0, 58cc <fwp_drop1+0x10c>
    58c0:	14000010 	b	5900 <fwp_drop1+0x140>
    58c4:	f9400800 	ldr	x0, [x0, #16]
    58c8:	b40001c0 	cbz	x0, 5900 <fwp_drop1+0x140>
    58cc:	f9400001 	ldr	x1, [x0]
    58d0:	eb13003f 	cmp	x1, x19
    58d4:	54ffff81 	b.ne	58c4 <fwp_drop1+0x104>  // b.any
    58d8:	f9400401 	ldr	x1, [x0, #8]
    58dc:	d1000421 	sub	x1, x1, #0x1
    58e0:	f9000401 	str	x1, [x0, #8]
    58e4:	f103f83f 	cmp	x1, #0xfe
    58e8:	54fffb81 	b.ne	5858 <fwp_drop1+0x98>  // b.any
    58ec:	aa1303e0 	mov	x0, x19
    58f0:	97fffb20 	bl	4570 <fwp_rc_forget_slot>
    58f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    58f8:	39000260 	strb	w0, [x19]
    58fc:	17ffffd7 	b	5858 <fwp_drop1+0x98>
    5900:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5904:	9124a000 	add	x0, x0, #0x928
    5908:	97fff71e 	bl	3580 <fwp_trap>
    590c:	d503201f 	nop

0000000000005910 <fwp_closure_drop>:
    5910:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5914:	911500a4 	add	x4, x5, #0x540
    5918:	aa0003e1 	mov	x1, x0
    591c:	f949d882 	ldr	x2, [x4, #5040]
    5920:	f949ec80 	ldr	x0, [x4, #5080]
    5924:	cb020022 	sub	x2, x1, x2
    5928:	eb00405f 	cmp	x2, x0, lsl #16
    592c:	54000662 	b.cs	59f8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5930:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5934:	d350fc43 	lsr	x3, x2, #16
    5938:	910003fd 	mov	x29, sp
    593c:	8b030863 	add	x3, x3, x3, lsl #2
    5940:	f949fc84 	ldr	x4, [x4, #5112]
    5944:	d37df063 	lsl	x3, x3, #3
    5948:	f9000bf3 	str	x19, [sp, #16]
    594c:	8b030080 	add	x0, x4, x3
    5950:	f9401013 	ldr	x19, [x0, #32]
    5954:	b40002b3 	cbz	x19, 59a8 <fwp_closure_drop+0x98>
    5958:	38636883 	ldrb	w3, [x4, x3]
    595c:	7100087f 	cmp	w3, #0x2
    5960:	54000420 	b.eq	59e4 <fwp_closure_drop+0xd4>  // b.none
    5964:	7100047f 	cmp	w3, #0x1
    5968:	54000201 	b.ne	59a8 <fwp_closure_drop+0x98>  // b.any
    596c:	29430003 	ldp	w3, w0, [x0, #24]
    5970:	92403c42 	and	x2, x2, #0xffff
    5974:	9b037c42 	mul	x2, x2, x3
    5978:	d360fc42 	lsr	x2, x2, #32
    597c:	eb00005f 	cmp	x2, x0
    5980:	54000142 	b.cs	59a8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5984:	8b020273 	add	x19, x19, x2
    5988:	39400260 	ldrb	w0, [x19]
    598c:	340000e0 	cbz	w0, 59a8 <fwp_closure_drop+0x98>
    5990:	7100041f 	cmp	w0, #0x1
    5994:	54000100 	b.eq	59b4 <fwp_closure_drop+0xa4>  // b.none
    5998:	7103fc1f 	cmp	w0, #0xff
    599c:	54000300 	b.eq	59fc <fwp_closure_drop+0xec>  // b.none
    59a0:	51000400 	sub	w0, w0, #0x1
    59a4:	39000260 	strb	w0, [x19]
    59a8:	f9400bf3 	ldr	x19, [sp, #16]
    59ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59b0:	d65f03c0 	ret
    59b4:	d53bd040 	mrs	x0, tpidr_el0
    59b8:	91400000 	add	x0, x0, #0x0, lsl #12
    59bc:	91004000 	add	x0, x0, #0x10
    59c0:	f9400000 	ldr	x0, [x0]
    59c4:	b4000080 	cbz	x0, 59d4 <fwp_closure_drop+0xc4>
    59c8:	f9400bf3 	ldr	x19, [sp, #16]
    59cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59d0:	17fff705 	b	35e4 <fwp_closure_drop_push>
    59d4:	f9400bf3 	ldr	x19, [sp, #16]
    59d8:	aa0103e0 	mov	x0, x1
    59dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59e0:	17fff770 	b	37a0 <fwp_closure_drop.part.0>
    59e4:	72003c5f 	tst	w2, #0xffff
    59e8:	54fffd00 	b.eq	5988 <fwp_closure_drop+0x78>  // b.none
    59ec:	f9400bf3 	ldr	x19, [sp, #16]
    59f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59f4:	d65f03c0 	ret
    59f8:	d65f03c0 	ret
    59fc:	ca534660 	eor	x0, x19, x19, lsr #17
    5a00:	911500a5 	add	x5, x5, #0x540
    5a04:	ca402400 	eor	x0, x0, x0, lsr #9
    5a08:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5a0c:	f94a2400 	ldr	x0, [x0, #5192]
    5a10:	b5000080 	cbnz	x0, 5a20 <fwp_closure_drop+0x110>
    5a14:	14000010 	b	5a54 <fwp_closure_drop+0x144>
    5a18:	f9400800 	ldr	x0, [x0, #16]
    5a1c:	b40001c0 	cbz	x0, 5a54 <fwp_closure_drop+0x144>
    5a20:	f9400001 	ldr	x1, [x0]
    5a24:	eb13003f 	cmp	x1, x19
    5a28:	54ffff81 	b.ne	5a18 <fwp_closure_drop+0x108>  // b.any
    5a2c:	f9400401 	ldr	x1, [x0, #8]
    5a30:	d1000421 	sub	x1, x1, #0x1
    5a34:	f9000401 	str	x1, [x0, #8]
    5a38:	f103f83f 	cmp	x1, #0xfe
    5a3c:	54fffb61 	b.ne	59a8 <fwp_closure_drop+0x98>  // b.any
    5a40:	aa1303e0 	mov	x0, x19
    5a44:	97fffacb 	bl	4570 <fwp_rc_forget_slot>
    5a48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a4c:	39000260 	strb	w0, [x19]
    5a50:	17ffffd6 	b	59a8 <fwp_closure_drop+0x98>
    5a54:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5a58:	9124a000 	add	x0, x0, #0x928
    5a5c:	97fff6c9 	bl	3580 <fwp_trap>

0000000000005a60 <fwp_owned_tape_release>:
    5a60:	b4000940 	cbz	x0, 5b88 <fwp_owned_tape_release+0x128>
    5a64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a68:	910003fd 	mov	x29, sp
    5a6c:	a90153f3 	stp	x19, x20, [sp, #16]
    5a70:	aa0003f3 	mov	x19, x0
    5a74:	f9400000 	ldr	x0, [x0]
    5a78:	b4000060 	cbz	x0, 5a84 <fwp_owned_tape_release+0x24>
    5a7c:	f9400661 	ldr	x1, [x19, #8]
    5a80:	f9000401 	str	x1, [x0, #8]
    5a84:	f9400661 	ldr	x1, [x19, #8]
    5a88:	b4000041 	cbz	x1, 5a90 <fwp_owned_tape_release+0x30>
    5a8c:	f9000020 	str	x0, [x1]
    5a90:	f9400a60 	ldr	x0, [x19, #16]
    5a94:	f9403401 	ldr	x1, [x0, #104]
    5a98:	b40005c1 	cbz	x1, 5b50 <fwp_owned_tape_release+0xf0>
    5a9c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5aa0:	eb00005f 	cmp	x2, x0
    5aa4:	540002ed 	b.le	5b00 <fwp_owned_tape_release+0xa0>
    5aa8:	d2800014 	mov	x20, #0x0                   	// #0
    5aac:	f90013f5 	str	x21, [sp, #32]
    5ab0:	d2800015 	mov	x21, #0x0                   	// #0
    5ab4:	d503201f 	nop
    5ab8:	f9402260 	ldr	x0, [x19, #64]
    5abc:	910006b5 	add	x21, x21, #0x1
    5ac0:	f8746800 	ldr	x0, [x0, x20]
    5ac4:	d63f0020 	blr	x1
    5ac8:	f9402260 	ldr	x0, [x19, #64]
    5acc:	f9400a61 	ldr	x1, [x19, #16]
    5ad0:	8b140000 	add	x0, x0, x20
    5ad4:	91004294 	add	x20, x20, #0x10
    5ad8:	f9400400 	ldr	x0, [x0, #8]
    5adc:	f9403421 	ldr	x1, [x1, #104]
    5ae0:	d63f0020 	blr	x1
    5ae4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ae8:	cb010000 	sub	x0, x0, x1
    5aec:	eb15001f 	cmp	x0, x21
    5af0:	f9400a60 	ldr	x0, [x19, #16]
    5af4:	f9403401 	ldr	x1, [x0, #104]
    5af8:	54fffe0c 	b.gt	5ab8 <fwp_owned_tape_release+0x58>
    5afc:	f94013f5 	ldr	x21, [sp, #32]
    5b00:	f9403663 	ldr	x3, [x19, #104]
    5b04:	f9401262 	ldr	x2, [x19, #32]
    5b08:	f100007f 	cmp	x3, #0x0
    5b0c:	540001ed 	b.le	5b48 <fwp_owned_tape_release+0xe8>
    5b10:	d2800014 	mov	x20, #0x0                   	// #0
    5b14:	d503201f 	nop
    5b18:	f9402660 	ldr	x0, [x19, #72]
    5b1c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5b20:	eb02001f 	cmp	x0, x2
    5b24:	540000c0 	b.eq	5b3c <fwp_owned_tape_release+0xdc>  // b.none
    5b28:	d63f0020 	blr	x1
    5b2c:	f9400a60 	ldr	x0, [x19, #16]
    5b30:	f9401262 	ldr	x2, [x19, #32]
    5b34:	f9403663 	ldr	x3, [x19, #104]
    5b38:	f9403401 	ldr	x1, [x0, #104]
    5b3c:	91000694 	add	x20, x20, #0x1
    5b40:	eb14007f 	cmp	x3, x20
    5b44:	54fffeac 	b.gt	5b18 <fwp_owned_tape_release+0xb8>
    5b48:	aa0203e0 	mov	x0, x2
    5b4c:	d63f0020 	blr	x1
    5b50:	f9401660 	ldr	x0, [x19, #40]
    5b54:	97ffff6f 	bl	5910 <fwp_closure_drop>
    5b58:	f9401a60 	ldr	x0, [x19, #48]
    5b5c:	97ffff6d 	bl	5910 <fwp_closure_drop>
    5b60:	f9401e60 	ldr	x0, [x19, #56]
    5b64:	97ffff6b 	bl	5910 <fwp_closure_drop>
    5b68:	f9402260 	ldr	x0, [x19, #64]
    5b6c:	97fffb21 	bl	47f0 <fwp_mem_free>
    5b70:	f9402660 	ldr	x0, [x19, #72]
    5b74:	97fffb1f 	bl	47f0 <fwp_mem_free>
    5b78:	aa1303e0 	mov	x0, x19
    5b7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b84:	17fffb1b 	b	47f0 <fwp_mem_free>
    5b88:	d65f03c0 	ret
    5b8c:	d503201f 	nop

0000000000005b90 <fwp_tape_finish>:
    5b90:	d10203ff 	sub	sp, sp, #0x80
    5b94:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5b98:	f947f421 	ldr	x1, [x1, #4072]
    5b9c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ba0:	910103fd 	add	x29, sp, #0x40
    5ba4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ba8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5bac:	a90763f7 	stp	x23, x24, [sp, #112]
    5bb0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5bb4:	9100c316 	add	x22, x24, #0x30
    5bb8:	f9400022 	ldr	x2, [x1]
    5bbc:	f9001fe2 	str	x2, [sp, #56]
    5bc0:	d2800002 	mov	x2, #0x0                   	// #0
    5bc4:	910122c0 	add	x0, x22, #0x48
    5bc8:	97fff5ce 	bl	3300 <fwp_tape_buffers_dispose>
    5bcc:	f90042df 	str	xzr, [x22, #128]
    5bd0:	f94022c0 	ldr	x0, [x22, #64]
    5bd4:	f100001f 	cmp	x0, #0x0
    5bd8:	5400030d 	b.le	5c38 <fwp_tape_finish+0xa8>
    5bdc:	910003f7 	mov	x23, sp
    5be0:	d2800015 	mov	x21, #0x0                   	// #0
    5be4:	d2800014 	mov	x20, #0x0                   	// #0
    5be8:	f94002d3 	ldr	x19, [x22]
    5bec:	91000694 	add	x20, x20, #0x1
    5bf0:	8b150273 	add	x19, x19, x21
    5bf4:	9101a2b5 	add	x21, x21, #0x68
    5bf8:	aa1303e0 	mov	x0, x19
    5bfc:	97fff4e5 	bl	2f90 <fwp_tape_unlink_scope>
    5c00:	aa1703e0 	mov	x0, x23
    5c04:	f9401261 	ldr	x1, [x19, #32]
    5c08:	f90003e1 	str	x1, [sp]
    5c0c:	f9401a62 	ldr	x2, [x19, #48]
    5c10:	f9000be2 	str	x2, [sp, #16]
    5c14:	f9402261 	ldr	x1, [x19, #64]
    5c18:	f90013e1 	str	x1, [sp, #32]
    5c1c:	97fff5b9 	bl	3300 <fwp_tape_buffers_dispose>
    5c20:	f9403260 	ldr	x0, [x19, #96]
    5c24:	97ffff8f 	bl	5a60 <fwp_owned_tape_release>
    5c28:	f900327f 	str	xzr, [x19, #96]
    5c2c:	f94022c0 	ldr	x0, [x22, #64]
    5c30:	eb14001f 	cmp	x0, x20
    5c34:	54fffdac 	b.gt	5be8 <fwp_tape_finish+0x58>
    5c38:	f9401b00 	ldr	x0, [x24, #48]
    5c3c:	9100c313 	add	x19, x24, #0x30
    5c40:	97fff340 	bl	2940 <free@plt>
    5c44:	f9001b1f 	str	xzr, [x24, #48]
    5c48:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5c4c:	f947f400 	ldr	x0, [x0, #4072]
    5c50:	f900227f 	str	xzr, [x19, #64]
    5c54:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5c58:	f9401fe2 	ldr	x2, [sp, #56]
    5c5c:	f9400001 	ldr	x1, [x0]
    5c60:	eb010042 	subs	x2, x2, x1
    5c64:	d2800001 	mov	x1, #0x0                   	// #0
    5c68:	540000e1 	b.ne	5c84 <fwp_tape_finish+0xf4>  // b.any
    5c6c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5c70:	a94553f3 	ldp	x19, x20, [sp, #80]
    5c74:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5c78:	a94763f7 	ldp	x23, x24, [sp, #112]
    5c7c:	910203ff 	add	sp, sp, #0x80
    5c80:	d65f03c0 	ret
    5c84:	97fff2ff 	bl	2880 <__stack_chk_fail@plt>
    5c88:	d503201f 	nop
    5c8c:	d503201f 	nop

0000000000005c90 <fwp_tape_scope_release>:
    5c90:	d10243ff 	sub	sp, sp, #0x90
    5c94:	a9047bfd 	stp	x29, x30, [sp, #64]
    5c98:	910103fd 	add	x29, sp, #0x40
    5c9c:	a90553f3 	stp	x19, x20, [sp, #80]
    5ca0:	aa0003f4 	mov	x20, x0
    5ca4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ca8:	f947f400 	ldr	x0, [x0, #4072]
    5cac:	b9400285 	ldr	w5, [x20]
    5cb0:	f9400001 	ldr	x1, [x0]
    5cb4:	f9001fe1 	str	x1, [sp, #56]
    5cb8:	d2800001 	mov	x1, #0x0                   	// #0
    5cbc:	37f806c5 	tbnz	w5, #31, 5d94 <fwp_tape_scope_release+0x104>
    5cc0:	a90763f7 	stp	x23, x24, [sp, #112]
    5cc4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5cc8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5ccc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5cd0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5cd4:	910003f7 	mov	x23, sp
    5cd8:	9100c273 	add	x19, x19, #0x30
    5cdc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5ce0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ce4:	52800d16 	mov	w22, #0x68                  	// #104
    5ce8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5cec:	f90043f9 	str	x25, [sp, #128]
    5cf0:	14000006 	b	5d08 <fwp_tape_scope_release+0x78>
    5cf4:	97fff583 	bl	3300 <fwp_tape_buffers_dispose>
    5cf8:	aa1903e0 	mov	x0, x25
    5cfc:	97ffff59 	bl	5a60 <fwp_owned_tape_release>
    5d00:	b9400285 	ldr	w5, [x20]
    5d04:	37f80425 	tbnz	w5, #31, 5d88 <fwp_tape_scope_release+0xf8>
    5d08:	f9400266 	ldr	x6, [x19]
    5d0c:	9b367ca5 	smull	x5, w5, w22
    5d10:	8b0500c0 	add	x0, x6, x5
    5d14:	97fff49f 	bl	2f90 <fwp_tape_unlink_scope>
    5d18:	ad410001 	ldp	q1, q0, [x0, #32]
    5d1c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5d20:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5d24:	f9400c03 	ldr	x3, [x0, #24]
    5d28:	ad0003e1 	stp	q1, q0, [sp]
    5d2c:	b86568c1 	ldr	w1, [x6, x5]
    5d30:	a9440804 	ldp	x4, x2, [x0, #64]
    5d34:	b900041f 	str	wzr, [x0, #4]
    5d38:	f9403019 	ldr	x25, [x0, #96]
    5d3c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5d40:	f9000c1f 	str	xzr, [x0, #24]
    5d44:	a9020fe4 	stp	x4, x3, [sp, #32]
    5d48:	f9001be2 	str	x2, [sp, #48]
    5d4c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5d50:	f900301f 	str	xzr, [x0, #96]
    5d54:	6b15003f 	cmp	w1, w21
    5d58:	540000e8 	b.hi	5d74 <fwp_tape_scope_release+0xe4>  // b.pmore
    5d5c:	9343fca5 	asr	x5, x5, #3
    5d60:	f9404e60 	ldr	x0, [x19, #152]
    5d64:	9b187ca5 	mul	x5, x5, x24
    5d68:	eb0000bf 	cmp	x5, x0
    5d6c:	5400004a 	b.ge	5d74 <fwp_tape_scope_release+0xe4>  // b.tcont
    5d70:	f9004e65 	str	x5, [x19, #152]
    5d74:	aa1703e0 	mov	x0, x23
    5d78:	b5fffbf9 	cbnz	x25, 5cf4 <fwp_tape_scope_release+0x64>
    5d7c:	97fff8e1 	bl	4100 <fwp_tape_buffers_release>
    5d80:	b9400285 	ldr	w5, [x20]
    5d84:	36fffc25 	tbz	w5, #31, 5d08 <fwp_tape_scope_release+0x78>
    5d88:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5d8c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5d90:	f94043f9 	ldr	x25, [sp, #128]
    5d94:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d98:	f947f400 	ldr	x0, [x0, #4072]
    5d9c:	f9401fe2 	ldr	x2, [sp, #56]
    5da0:	f9400001 	ldr	x1, [x0]
    5da4:	eb010042 	subs	x2, x2, x1
    5da8:	d2800001 	mov	x1, #0x0                   	// #0
    5dac:	540000a1 	b.ne	5dc0 <fwp_tape_scope_release+0x130>  // b.any
    5db0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5db4:	a94553f3 	ldp	x19, x20, [sp, #80]
    5db8:	910243ff 	add	sp, sp, #0x90
    5dbc:	d65f03c0 	ret
    5dc0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5dc4:	a90763f7 	stp	x23, x24, [sp, #112]
    5dc8:	f90043f9 	str	x25, [sp, #128]
    5dcc:	97fff2ad 	bl	2880 <__stack_chk_fail@plt>

0000000000005dd0 <fwp_drop4>:
    5dd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5dd4:	910003fd 	mov	x29, sp
    5dd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    5ddc:	90000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    5de0:	911502d5 	add	x21, x22, #0x540
    5de4:	a90153f3 	stp	x19, x20, [sp, #16]
    5de8:	aa0003f3 	mov	x19, x0
    5dec:	f949daa1 	ldr	x1, [x21, #5040]
    5df0:	f949eea0 	ldr	x0, [x21, #5080]
    5df4:	cb010261 	sub	x1, x19, x1
    5df8:	eb00403f 	cmp	x1, x0, lsl #16
    5dfc:	54000382 	b.cs	5e6c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5e00:	d350fc22 	lsr	x2, x1, #16
    5e04:	f949fea3 	ldr	x3, [x21, #5112]
    5e08:	8b020842 	add	x2, x2, x2, lsl #2
    5e0c:	d37df042 	lsl	x2, x2, #3
    5e10:	8b020060 	add	x0, x3, x2
    5e14:	f9401014 	ldr	x20, [x0, #32]
    5e18:	b40002b4 	cbz	x20, 5e6c <fwp_drop4+0x9c>
    5e1c:	38626862 	ldrb	w2, [x3, x2]
    5e20:	7100085f 	cmp	w2, #0x2
    5e24:	540002c0 	b.eq	5e7c <fwp_drop4+0xac>  // b.none
    5e28:	7100045f 	cmp	w2, #0x1
    5e2c:	54000201 	b.ne	5e6c <fwp_drop4+0x9c>  // b.any
    5e30:	29430002 	ldp	w2, w0, [x0, #24]
    5e34:	92403c21 	and	x1, x1, #0xffff
    5e38:	9b027c21 	mul	x1, x1, x2
    5e3c:	d360fc21 	lsr	x1, x1, #32
    5e40:	eb00003f 	cmp	x1, x0
    5e44:	54000142 	b.cs	5e6c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5e48:	8b010294 	add	x20, x20, x1
    5e4c:	39400280 	ldrb	w0, [x20]
    5e50:	340000e0 	cbz	w0, 5e6c <fwp_drop4+0x9c>
    5e54:	7100041f 	cmp	w0, #0x1
    5e58:	540001e0 	b.eq	5e94 <fwp_drop4+0xc4>  // b.none
    5e5c:	7103fc1f 	cmp	w0, #0xff
    5e60:	540007c0 	b.eq	5f58 <fwp_drop4+0x188>  // b.none
    5e64:	51000400 	sub	w0, w0, #0x1
    5e68:	39000280 	strb	w0, [x20]
    5e6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5e74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e78:	d65f03c0 	ret
    5e7c:	72003c3f 	tst	w1, #0xffff
    5e80:	54fffe60 	b.eq	5e4c <fwp_drop4+0x7c>  // b.none
    5e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e88:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5e8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e90:	d65f03c0 	ret
    5e94:	911502c2 	add	x2, x22, #0x540
    5e98:	f9400660 	ldr	x0, [x19, #8]
    5e9c:	f949d841 	ldr	x1, [x2, #5040]
    5ea0:	f949ec42 	ldr	x2, [x2, #5080]
    5ea4:	cb010001 	sub	x1, x0, x1
    5ea8:	eb02403f 	cmp	x1, x2, lsl #16
    5eac:	54000362 	b.cs	5f18 <fwp_drop4+0x148>  // b.hs, b.nlast
    5eb0:	d350fc22 	lsr	x2, x1, #16
    5eb4:	8b020842 	add	x2, x2, x2, lsl #2
    5eb8:	d37df042 	lsl	x2, x2, #3
    5ebc:	8b020064 	add	x4, x3, x2
    5ec0:	f9401094 	ldr	x20, [x4, #32]
    5ec4:	b40002b4 	cbz	x20, 5f18 <fwp_drop4+0x148>
    5ec8:	38626862 	ldrb	w2, [x3, x2]
    5ecc:	7100085f 	cmp	w2, #0x2
    5ed0:	540003e0 	b.eq	5f4c <fwp_drop4+0x17c>  // b.none
    5ed4:	7100045f 	cmp	w2, #0x1
    5ed8:	54000201 	b.ne	5f18 <fwp_drop4+0x148>  // b.any
    5edc:	29430883 	ldp	w3, w2, [x4, #24]
    5ee0:	92403c21 	and	x1, x1, #0xffff
    5ee4:	9b037c21 	mul	x1, x1, x3
    5ee8:	d360fc21 	lsr	x1, x1, #32
    5eec:	eb02003f 	cmp	x1, x2
    5ef0:	54000142 	b.cs	5f18 <fwp_drop4+0x148>  // b.hs, b.nlast
    5ef4:	8b010294 	add	x20, x20, x1
    5ef8:	39400281 	ldrb	w1, [x20]
    5efc:	340000e1 	cbz	w1, 5f18 <fwp_drop4+0x148>
    5f00:	7100043f 	cmp	w1, #0x1
    5f04:	54000200 	b.eq	5f44 <fwp_drop4+0x174>  // b.none
    5f08:	7103fc3f 	cmp	w1, #0xff
    5f0c:	54000580 	b.eq	5fbc <fwp_drop4+0x1ec>  // b.none
    5f10:	51000421 	sub	w1, w1, #0x1
    5f14:	39000281 	strb	w1, [x20]
    5f18:	f9400a74 	ldr	x20, [x19, #16]
    5f1c:	aa1303e0 	mov	x0, x19
    5f20:	97fffcfd 	bl	5314 <fwp_rc_free_arr>
    5f24:	911502c0 	add	x0, x22, #0x540
    5f28:	f949d801 	ldr	x1, [x0, #5040]
    5f2c:	f949ec00 	ldr	x0, [x0, #5080]
    5f30:	cb010281 	sub	x1, x20, x1
    5f34:	eb00403f 	cmp	x1, x0, lsl #16
    5f38:	54fff9a2 	b.cs	5e6c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5f3c:	aa1403f3 	mov	x19, x20
    5f40:	17ffffb0 	b	5e00 <fwp_drop4+0x30>
    5f44:	97fffcf4 	bl	5314 <fwp_rc_free_arr>
    5f48:	17fffff4 	b	5f18 <fwp_drop4+0x148>
    5f4c:	72003c3f 	tst	w1, #0xffff
    5f50:	54fffe41 	b.ne	5f18 <fwp_drop4+0x148>  // b.any
    5f54:	17ffffe9 	b	5ef8 <fwp_drop4+0x128>
    5f58:	ca544681 	eor	x1, x20, x20, lsr #17
    5f5c:	911502c0 	add	x0, x22, #0x540
    5f60:	ca412421 	eor	x1, x1, x1, lsr #9
    5f64:	8b210c01 	add	x1, x0, w1, uxtb #3
    5f68:	f94a2420 	ldr	x0, [x1, #5192]
    5f6c:	b5000080 	cbnz	x0, 5f7c <fwp_drop4+0x1ac>
    5f70:	14000010 	b	5fb0 <fwp_drop4+0x1e0>
    5f74:	f9400800 	ldr	x0, [x0, #16]
    5f78:	b40001c0 	cbz	x0, 5fb0 <fwp_drop4+0x1e0>
    5f7c:	f9400001 	ldr	x1, [x0]
    5f80:	eb14003f 	cmp	x1, x20
    5f84:	54ffff81 	b.ne	5f74 <fwp_drop4+0x1a4>  // b.any
    5f88:	f9400401 	ldr	x1, [x0, #8]
    5f8c:	d1000421 	sub	x1, x1, #0x1
    5f90:	f9000401 	str	x1, [x0, #8]
    5f94:	f103f83f 	cmp	x1, #0xfe
    5f98:	54fff6a1 	b.ne	5e6c <fwp_drop4+0x9c>  // b.any
    5f9c:	aa1403e0 	mov	x0, x20
    5fa0:	97fff974 	bl	4570 <fwp_rc_forget_slot>
    5fa4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fa8:	39000280 	strb	w0, [x20]
    5fac:	17ffffb0 	b	5e6c <fwp_drop4+0x9c>
    5fb0:	b0000020 	adrp	x0, a000 <__divti3+0xa0>
    5fb4:	9124a000 	add	x0, x0, #0x928
    5fb8:	97fff572 	bl	3580 <fwp_trap>
    5fbc:	ca544680 	eor	x0, x20, x20, lsr #17
    5fc0:	911502c1 	add	x1, x22, #0x540
    5fc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5fc8:	8b200c20 	add	x0, x1, w0, uxtb #3
    5fcc:	f94a2400 	ldr	x0, [x0, #5192]
    5fd0:	b5000080 	cbnz	x0, 5fe0 <fwp_drop4+0x210>
    5fd4:	17fffff7 	b	5fb0 <fwp_drop4+0x1e0>
    5fd8:	f9400800 	ldr	x0, [x0, #16]
    5fdc:	b4fffea0 	cbz	x0, 5fb0 <fwp_drop4+0x1e0>
    5fe0:	f9400001 	ldr	x1, [x0]
    5fe4:	eb14003f 	cmp	x1, x20
    5fe8:	54ffff81 	b.ne	5fd8 <fwp_drop4+0x208>  // b.any
    5fec:	f9400401 	ldr	x1, [x0, #8]
    5ff0:	d1000421 	sub	x1, x1, #0x1
    5ff4:	f9000401 	str	x1, [x0, #8]
    5ff8:	f103f83f 	cmp	x1, #0xfe
    5ffc:	54fff8e1 	b.ne	5f18 <fwp_drop4+0x148>  // b.any
    6000:	aa1403e0 	mov	x0, x20
    6004:	97fff95b 	bl	4570 <fwp_rc_forget_slot>
    6008:	12800020 	mov	w0, #0xfffffffe            	// #-2
    600c:	39000280 	strb	w0, [x20]
    6010:	17ffffc2 	b	5f18 <fwp_drop4+0x148>

0000000000006014 <fwp_arg_drop37>:
    6014:	7100003f 	cmp	w1, #0x0
    6018:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    601c:	54000041 	b.ne	6024 <fwp_arg_drop37+0x10>  // b.any
    6020:	d65f03c0 	ret
    6024:	f9400000 	ldr	x0, [x0]
    6028:	17ffff6a 	b	5dd0 <fwp_drop4>
    602c:	d503201f 	nop

0000000000006030 <fwp_task_dispose>:
    6030:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6034:	910003fd 	mov	x29, sp
    6038:	f9000bf3 	str	x19, [sp, #16]
    603c:	aa0003f3 	mov	x19, x0
    6040:	39414000 	ldrb	w0, [x0, #80]
    6044:	36000720 	tbz	w0, #0, 6128 <fwp_task_dispose+0xf8>
    6048:	f9400a60 	ldr	x0, [x19, #16]
    604c:	b50006e0 	cbnz	x0, 6128 <fwp_task_dispose+0xf8>
    6050:	a9478660 	ldp	x0, x1, [x19, #120]
    6054:	39014e7f 	strb	wzr, [x19, #83]
    6058:	f9003e7f 	str	xzr, [x19, #120]
    605c:	f100003f 	cmp	x1, #0x0
    6060:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6064:	54000040 	b.eq	606c <fwp_task_dispose+0x3c>  // b.none
    6068:	d63f0020 	blr	x1
    606c:	f9405660 	ldr	x0, [x19, #168]
    6070:	97fff9e0 	bl	47f0 <fwp_mem_free>
    6074:	f900567f 	str	xzr, [x19, #168]
    6078:	b9405e60 	ldr	w0, [x19, #92]
    607c:	7100041f 	cmp	w0, #0x1
    6080:	54000420 	b.eq	6104 <fwp_task_dispose+0xd4>  // b.none
    6084:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6088:	91150042 	add	x2, x2, #0x540
    608c:	f949d840 	ldr	x0, [x2, #5040]
    6090:	f949ec41 	ldr	x1, [x2, #5080]
    6094:	cb000260 	sub	x0, x19, x0
    6098:	eb01401f 	cmp	x0, x1, lsl #16
    609c:	540002e2 	b.cs	60f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    60a0:	d350fc01 	lsr	x1, x0, #16
    60a4:	f949fc44 	ldr	x4, [x2, #5112]
    60a8:	8b010821 	add	x1, x1, x1, lsl #2
    60ac:	d37df021 	lsl	x1, x1, #3
    60b0:	8b010083 	add	x3, x4, x1
    60b4:	f9401062 	ldr	x2, [x3, #32]
    60b8:	b4000202 	cbz	x2, 60f8 <fwp_task_dispose+0xc8>
    60bc:	38616881 	ldrb	w1, [x4, x1]
    60c0:	7100083f 	cmp	w1, #0x2
    60c4:	54000280 	b.eq	6114 <fwp_task_dispose+0xe4>  // b.none
    60c8:	7100043f 	cmp	w1, #0x1
    60cc:	54000161 	b.ne	60f8 <fwp_task_dispose+0xc8>  // b.any
    60d0:	29430464 	ldp	w4, w1, [x3, #24]
    60d4:	92403c00 	and	x0, x0, #0xffff
    60d8:	9b047c00 	mul	x0, x0, x4
    60dc:	d360fc00 	lsr	x0, x0, #32
    60e0:	eb01001f 	cmp	x0, x1
    60e4:	540000a2 	b.cs	60f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    60e8:	8b000042 	add	x2, x2, x0
    60ec:	39400040 	ldrb	w0, [x2]
    60f0:	7100041f 	cmp	w0, #0x1
    60f4:	54000080 	b.eq	6104 <fwp_task_dispose+0xd4>  // b.none
    60f8:	f9400bf3 	ldr	x19, [sp, #16]
    60fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6100:	d65f03c0 	ret
    6104:	aa1303e0 	mov	x0, x19
    6108:	f9400bf3 	ldr	x19, [sp, #16]
    610c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6110:	17fff9b8 	b	47f0 <fwp_mem_free>
    6114:	72003c1f 	tst	w0, #0xffff
    6118:	54fffea0 	b.eq	60ec <fwp_task_dispose+0xbc>  // b.none
    611c:	f9400bf3 	ldr	x19, [sp, #16]
    6120:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6124:	d65f03c0 	ret
    6128:	97fff1ea 	bl	28d0 <abort@plt>
    612c:	d503201f 	nop

0000000000006130 <fwp_free_zombie>:
    6130:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6134:	910003fd 	mov	x29, sp
    6138:	a90153f3 	stp	x19, x20, [sp, #16]
    613c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6140:	9100c281 	add	x1, x20, #0x30
    6144:	f9405033 	ldr	x19, [x1, #160]
    6148:	b4000333 	cbz	x19, 61ac <fwp_free_zombie+0x7c>
    614c:	f9400820 	ldr	x0, [x1, #16]
    6150:	eb00027f 	cmp	x19, x0
    6154:	540002c0 	b.eq	61ac <fwp_free_zombie+0x7c>  // b.none
    6158:	b940a822 	ldr	w2, [x1, #168]
    615c:	f9400a60 	ldr	x0, [x19, #16]
    6160:	7100fc5f 	cmp	w2, #0x3f
    6164:	5400078c 	b.gt	6254 <fwp_free_zombie+0x124>
    6168:	9102c023 	add	x3, x1, #0xb0
    616c:	11000444 	add	w4, w2, #0x1
    6170:	b900a824 	str	w4, [x1, #168]
    6174:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6178:	f822d860 	str	x0, [x3, w2, sxtw #3]
    617c:	a9530261 	ldp	x1, x0, [x19, #304]
    6180:	b4000741 	cbz	x1, 6268 <fwp_free_zombie+0x138>
    6184:	f9009c20 	str	x0, [x1, #312]
    6188:	b4000040 	cbz	x0, 6190 <fwp_free_zombie+0x60>
    618c:	f9009801 	str	x1, [x0, #304]
    6190:	9100c294 	add	x20, x20, #0x30
    6194:	b9405e60 	ldr	w0, [x19, #92]
    6198:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    619c:	f900529f 	str	xzr, [x20, #160]
    61a0:	34000140 	cbz	w0, 61c8 <fwp_free_zombie+0x98>
    61a4:	7100041f 	cmp	w0, #0x1
    61a8:	54000080 	b.eq	61b8 <fwp_free_zombie+0x88>  // b.none
    61ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    61b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b4:	d65f03c0 	ret
    61b8:	aa1303e0 	mov	x0, x19
    61bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    61c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c4:	17ffff9b 	b	6030 <fwp_task_dispose>
    61c8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    61cc:	91150082 	add	x2, x4, #0x540
    61d0:	f949d841 	ldr	x1, [x2, #5040]
    61d4:	f949ec40 	ldr	x0, [x2, #5080]
    61d8:	cb010261 	sub	x1, x19, x1
    61dc:	eb00403f 	cmp	x1, x0, lsl #16
    61e0:	54fffe62 	b.cs	61ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    61e4:	d350fc20 	lsr	x0, x1, #16
    61e8:	f949fc43 	ldr	x3, [x2, #5112]
    61ec:	8b000800 	add	x0, x0, x0, lsl #2
    61f0:	d37df000 	lsl	x0, x0, #3
    61f4:	8b000062 	add	x2, x3, x0
    61f8:	f9401054 	ldr	x20, [x2, #32]
    61fc:	b4fffd94 	cbz	x20, 61ac <fwp_free_zombie+0x7c>
    6200:	38606860 	ldrb	w0, [x3, x0]
    6204:	7100081f 	cmp	w0, #0x2
    6208:	54000360 	b.eq	6274 <fwp_free_zombie+0x144>  // b.none
    620c:	7100041f 	cmp	w0, #0x1
    6210:	54fffce1 	b.ne	61ac <fwp_free_zombie+0x7c>  // b.any
    6214:	29430043 	ldp	w3, w0, [x2, #24]
    6218:	92403c21 	and	x1, x1, #0xffff
    621c:	9b037c21 	mul	x1, x1, x3
    6220:	d360fc21 	lsr	x1, x1, #32
    6224:	eb00003f 	cmp	x1, x0
    6228:	54fffc22 	b.cs	61ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    622c:	8b010294 	add	x20, x20, x1
    6230:	39400280 	ldrb	w0, [x20]
    6234:	34fffbc0 	cbz	w0, 61ac <fwp_free_zombie+0x7c>
    6238:	7100041f 	cmp	w0, #0x1
    623c:	54fffbe0 	b.eq	61b8 <fwp_free_zombie+0x88>  // b.none
    6240:	7103fc1f 	cmp	w0, #0xff
    6244:	540001e0 	b.eq	6280 <fwp_free_zombie+0x150>  // b.none
    6248:	51000400 	sub	w0, w0, #0x1
    624c:	39000280 	strb	w0, [x20]
    6250:	17ffffd7 	b	61ac <fwp_free_zombie+0x7c>
    6254:	f9400e61 	ldr	x1, [x19, #24]
    6258:	97fff1d2 	bl	29a0 <munmap@plt>
    625c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6260:	a9530261 	ldp	x1, x0, [x19, #304]
    6264:	b5fff901 	cbnz	x1, 6184 <fwp_free_zombie+0x54>
    6268:	9100c282 	add	x2, x20, #0x30
    626c:	f9015840 	str	x0, [x2, #688]
    6270:	17ffffc6 	b	6188 <fwp_free_zombie+0x58>
    6274:	72003c3f 	tst	w1, #0xffff
    6278:	54fff9a1 	b.ne	61ac <fwp_free_zombie+0x7c>  // b.any
    627c:	17ffffed 	b	6230 <fwp_free_zombie+0x100>
    6280:	ca544680 	eor	x0, x20, x20, lsr #17
    6284:	91150084 	add	x4, x4, #0x540
    6288:	ca402400 	eor	x0, x0, x0, lsr #9
    628c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6290:	f94a2400 	ldr	x0, [x0, #5192]
    6294:	b5000080 	cbnz	x0, 62a4 <fwp_free_zombie+0x174>
    6298:	14000010 	b	62d8 <fwp_free_zombie+0x1a8>
    629c:	f9400800 	ldr	x0, [x0, #16]
    62a0:	b40001c0 	cbz	x0, 62d8 <fwp_free_zombie+0x1a8>
    62a4:	f9400001 	ldr	x1, [x0]
    62a8:	eb14003f 	cmp	x1, x20
    62ac:	54ffff81 	b.ne	629c <fwp_free_zombie+0x16c>  // b.any
    62b0:	f9400401 	ldr	x1, [x0, #8]
    62b4:	d1000421 	sub	x1, x1, #0x1
    62b8:	f9000401 	str	x1, [x0, #8]
    62bc:	f103f83f 	cmp	x1, #0xfe
    62c0:	54fff761 	b.ne	61ac <fwp_free_zombie+0x7c>  // b.any
    62c4:	aa1403e0 	mov	x0, x20
    62c8:	97fff8aa 	bl	4570 <fwp_rc_forget_slot>
    62cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62d0:	39000280 	strb	w0, [x20]
    62d4:	17ffffb6 	b	61ac <fwp_free_zombie+0x7c>
    62d8:	90000020 	adrp	x0, a000 <__divti3+0xa0>
    62dc:	9124a000 	add	x0, x0, #0x928
    62e0:	97fff4a8 	bl	3580 <fwp_trap>

00000000000062e4 <fwp_block>:
    62e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62e8:	910003fd 	mov	x29, sp
    62ec:	a90153f3 	stp	x19, x20, [sp, #16]
    62f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    62f4:	9100c274 	add	x20, x19, #0x30
    62f8:	f9401a82 	ldr	x2, [x20, #48]
    62fc:	b4000622 	cbz	x2, 63c0 <fwp_block+0xdc>
    6300:	9100c261 	add	x1, x19, #0x30
    6304:	f9408040 	ldr	x0, [x2, #256]
    6308:	f9001820 	str	x0, [x1, #48]
    630c:	b4000680 	cbz	x0, 63dc <fwp_block+0xf8>
    6310:	9100c263 	add	x3, x19, #0x30
    6314:	3901505f 	strb	wzr, [x2, #84]
    6318:	f9400864 	ldr	x4, [x3, #16]
    631c:	eb02009f 	cmp	x4, x2
    6320:	54000440 	b.eq	63a8 <fwp_block+0xc4>  // b.none
    6324:	f9415c65 	ldr	x5, [x3, #696]
    6328:	f9000862 	str	x2, [x3, #16]
    632c:	f9400441 	ldr	x1, [x2, #8]
    6330:	f9004885 	str	x5, [x4, #144]
    6334:	f9416065 	ldr	x5, [x3, #704]
    6338:	f9004c85 	str	x5, [x4, #152]
    633c:	f9416465 	ldr	x5, [x3, #712]
    6340:	f9005085 	str	x5, [x4, #160]
    6344:	f9416865 	ldr	x5, [x3, #720]
    6348:	f9005485 	str	x5, [x4, #168]
    634c:	f9416c65 	ldr	x5, [x3, #728]
    6350:	f9005885 	str	x5, [x4, #176]
    6354:	f9417065 	ldr	x5, [x3, #736]
    6358:	f9005c85 	str	x5, [x4, #184]
    635c:	f9417465 	ldr	x5, [x3, #744]
    6360:	f9006085 	str	x5, [x4, #192]
    6364:	f9400480 	ldr	x0, [x4, #8]
    6368:	f9404844 	ldr	x4, [x2, #144]
    636c:	f9015c64 	str	x4, [x3, #696]
    6370:	f9404c44 	ldr	x4, [x2, #152]
    6374:	f9016064 	str	x4, [x3, #704]
    6378:	f9405044 	ldr	x4, [x2, #160]
    637c:	f9016464 	str	x4, [x3, #712]
    6380:	f9405444 	ldr	x4, [x2, #168]
    6384:	f9016864 	str	x4, [x3, #720]
    6388:	f9405844 	ldr	x4, [x2, #176]
    638c:	f9016c64 	str	x4, [x3, #728]
    6390:	a94b8844 	ldp	x4, x2, [x2, #184]
    6394:	f9017064 	str	x4, [x3, #736]
    6398:	f9017462 	str	x2, [x3, #744]
    639c:	97fff151 	bl	28e0 <swapcontext@plt>
    63a0:	97ffff64 	bl	6130 <fwp_free_zombie>
    63a4:	d503201f 	nop
    63a8:	9100c260 	add	x0, x19, #0x30
    63ac:	b942f000 	ldr	w0, [x0, #752]
    63b0:	340001a0 	cbz	w0, 63e4 <fwp_block+0x100>
    63b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63bc:	d65f03c0 	ret
    63c0:	97fff798 	bl	4220 <fwp_poll_events>
    63c4:	f9401a82 	ldr	x2, [x20, #48]
    63c8:	b4ffffc2 	cbz	x2, 63c0 <fwp_block+0xdc>
    63cc:	9100c261 	add	x1, x19, #0x30
    63d0:	f9408040 	ldr	x0, [x2, #256]
    63d4:	f9001820 	str	x0, [x1, #48]
    63d8:	b5fff9c0 	cbnz	x0, 6310 <fwp_block+0x2c>
    63dc:	f900143f 	str	xzr, [x1, #40]
    63e0:	17ffffcc 	b	6310 <fwp_block+0x2c>
    63e4:	90000020 	adrp	x0, a000 <__divti3+0xa0>
    63e8:	91296000 	add	x0, x0, #0xa58
    63ec:	97fff189 	bl	2a10 <getenv@plt>
    63f0:	5284e202 	mov	w2, #0x2710                	// #10000
    63f4:	b4000060 	cbz	x0, 6400 <fwp_block+0x11c>
    63f8:	39400001 	ldrb	w1, [x0]
    63fc:	350000c1 	cbnz	w1, 6414 <fwp_block+0x130>
    6400:	9100c273 	add	x19, x19, #0x30
    6404:	b902f262 	str	w2, [x19, #752]
    6408:	a94153f3 	ldp	x19, x20, [sp, #16]
    640c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6410:	d65f03c0 	ret
    6414:	52800142 	mov	w2, #0xa                   	// #10
    6418:	d2800001 	mov	x1, #0x0                   	// #0
    641c:	97fff0cd 	bl	2750 <strtoll@plt>
    6420:	d1000403 	sub	x3, x0, #0x1
    6424:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6428:	eb02007f 	cmp	x3, x2
    642c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6430:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6434:	17fffff3 	b	6400 <fwp_block+0x11c>
    6438:	d503201f 	nop
    643c:	d503201f 	nop

0000000000006440 <fwp_drop10>:
    6440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6444:	910003fd 	mov	x29, sp
    6448:	a90153f3 	stp	x19, x20, [sp, #16]
    644c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    6450:	f90013f5 	str	x21, [sp, #32]
    6454:	91150275 	add	x21, x19, #0x540
    6458:	f949daa1 	ldr	x1, [x21, #5040]
    645c:	f949eea2 	ldr	x2, [x21, #5080]
    6460:	cb010001 	sub	x1, x0, x1
    6464:	eb02403f 	cmp	x1, x2, lsl #16
    6468:	54000382 	b.cs	64d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    646c:	d350fc22 	lsr	x2, x1, #16
    6470:	f949fea3 	ldr	x3, [x21, #5112]
    6474:	8b020842 	add	x2, x2, x2, lsl #2
    6478:	d37df042 	lsl	x2, x2, #3
    647c:	8b020064 	add	x4, x3, x2
    6480:	f9401094 	ldr	x20, [x4, #32]
    6484:	b40002b4 	cbz	x20, 64d8 <fwp_drop10+0x98>
    6488:	38626862 	ldrb	w2, [x3, x2]
    648c:	7100085f 	cmp	w2, #0x2
    6490:	540007a0 	b.eq	6584 <fwp_drop10+0x144>  // b.none
    6494:	7100045f 	cmp	w2, #0x1
    6498:	54000201 	b.ne	64d8 <fwp_drop10+0x98>  // b.any
    649c:	29430885 	ldp	w5, w2, [x4, #24]
    64a0:	92403c21 	and	x1, x1, #0xffff
    64a4:	9b057c21 	mul	x1, x1, x5
    64a8:	d360fc21 	lsr	x1, x1, #32
    64ac:	eb02003f 	cmp	x1, x2
    64b0:	54000142 	b.cs	64d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    64b4:	8b010294 	add	x20, x20, x1
    64b8:	39400281 	ldrb	w1, [x20]
    64bc:	340000e1 	cbz	w1, 64d8 <fwp_drop10+0x98>
    64c0:	7100043f 	cmp	w1, #0x1
    64c4:	54000120 	b.eq	64e8 <fwp_drop10+0xa8>  // b.none
    64c8:	7103fc3f 	cmp	w1, #0xff
    64cc:	540007c0 	b.eq	65c4 <fwp_drop10+0x184>  // b.none
    64d0:	51000421 	sub	w1, w1, #0x1
    64d4:	39000281 	strb	w1, [x20]
    64d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64dc:	f94013f5 	ldr	x21, [sp, #32]
    64e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64e4:	d65f03c0 	ret
    64e8:	f9400001 	ldr	x1, [x0]
    64ec:	b7f80581 	tbnz	x1, #63, 659c <fwp_drop10+0x15c>
    64f0:	91150273 	add	x19, x19, #0x540
    64f4:	f949da61 	ldr	x1, [x19, #5040]
    64f8:	f949ee62 	ldr	x2, [x19, #5080]
    64fc:	cb010001 	sub	x1, x0, x1
    6500:	eb02403f 	cmp	x1, x2, lsl #16
    6504:	54fffea2 	b.cs	64d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6508:	d350fc22 	lsr	x2, x1, #16
    650c:	8b020842 	add	x2, x2, x2, lsl #2
    6510:	d37df042 	lsl	x2, x2, #3
    6514:	8b020065 	add	x5, x3, x2
    6518:	f94010a4 	ldr	x4, [x5, #32]
    651c:	b4fffde4 	cbz	x4, 64d8 <fwp_drop10+0x98>
    6520:	38626862 	ldrb	w2, [x3, x2]
    6524:	7100085f 	cmp	w2, #0x2
    6528:	54000220 	b.eq	656c <fwp_drop10+0x12c>  // b.none
    652c:	7100045f 	cmp	w2, #0x1
    6530:	54fffd41 	b.ne	64d8 <fwp_drop10+0x98>  // b.any
    6534:	294308a3 	ldp	w3, w2, [x5, #24]
    6538:	92403c21 	and	x1, x1, #0xffff
    653c:	9b037c21 	mul	x1, x1, x3
    6540:	d360fc21 	lsr	x1, x1, #32
    6544:	eb02003f 	cmp	x1, x2
    6548:	54fffc82 	b.cs	64d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    654c:	8b010084 	add	x4, x4, x1
    6550:	39400081 	ldrb	w1, [x4]
    6554:	7100043f 	cmp	w1, #0x1
    6558:	54fffc01 	b.ne	64d8 <fwp_drop10+0x98>  // b.any
    655c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6560:	f94013f5 	ldr	x21, [sp, #32]
    6564:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6568:	17fff8a2 	b	47f0 <fwp_mem_free>
    656c:	72003c3f 	tst	w1, #0xffff
    6570:	54ffff00 	b.eq	6550 <fwp_drop10+0x110>  // b.none
    6574:	a94153f3 	ldp	x19, x20, [sp, #16]
    6578:	f94013f5 	ldr	x21, [sp, #32]
    657c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6580:	d65f03c0 	ret
    6584:	72003c3f 	tst	w1, #0xffff
    6588:	54fff980 	b.eq	64b8 <fwp_drop10+0x78>  // b.none
    658c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6590:	f94013f5 	ldr	x21, [sp, #32]
    6594:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6598:	d65f03c0 	ret
    659c:	f9400414 	ldr	x20, [x0, #8]
    65a0:	97fffb5d 	bl	5314 <fwp_rc_free_arr>
    65a4:	91150260 	add	x0, x19, #0x540
    65a8:	f949d801 	ldr	x1, [x0, #5040]
    65ac:	f949ec00 	ldr	x0, [x0, #5080]
    65b0:	cb010281 	sub	x1, x20, x1
    65b4:	eb00403f 	cmp	x1, x0, lsl #16
    65b8:	54fff902 	b.cs	64d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    65bc:	aa1403e0 	mov	x0, x20
    65c0:	17ffffab 	b	646c <fwp_drop10+0x2c>
    65c4:	ca544680 	eor	x0, x20, x20, lsr #17
    65c8:	91150273 	add	x19, x19, #0x540
    65cc:	ca402400 	eor	x0, x0, x0, lsr #9
    65d0:	8b200e60 	add	x0, x19, w0, uxtb #3
    65d4:	f94a2400 	ldr	x0, [x0, #5192]
    65d8:	b5000080 	cbnz	x0, 65e8 <fwp_drop10+0x1a8>
    65dc:	14000010 	b	661c <fwp_drop10+0x1dc>
    65e0:	f9400800 	ldr	x0, [x0, #16]
    65e4:	b40001c0 	cbz	x0, 661c <fwp_drop10+0x1dc>
    65e8:	f9400001 	ldr	x1, [x0]
    65ec:	eb14003f 	cmp	x1, x20
    65f0:	54ffff81 	b.ne	65e0 <fwp_drop10+0x1a0>  // b.any
    65f4:	f9400401 	ldr	x1, [x0, #8]
    65f8:	d1000421 	sub	x1, x1, #0x1
    65fc:	f9000401 	str	x1, [x0, #8]
    6600:	f103f83f 	cmp	x1, #0xfe
    6604:	54fff6a1 	b.ne	64d8 <fwp_drop10+0x98>  // b.any
    6608:	aa1403e0 	mov	x0, x20
    660c:	97fff7d9 	bl	4570 <fwp_rc_forget_slot>
    6610:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6614:	39000280 	strb	w0, [x20]
    6618:	17ffffb0 	b	64d8 <fwp_drop10+0x98>
    661c:	90000020 	adrp	x0, a000 <__divti3+0xa0>
    6620:	9124a000 	add	x0, x0, #0x928
    6624:	97fff3d7 	bl	3580 <fwp_trap>
    6628:	d503201f 	nop
    662c:	d503201f 	nop

0000000000006630 <fwp_caps173>:
    6630:	34000041 	cbz	w1, 6638 <fwp_caps173+0x8>
    6634:	d65f03c0 	ret
    6638:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    663c:	91150063 	add	x3, x3, #0x540
    6640:	f949d861 	ldr	x1, [x3, #5040]
    6644:	f949ec62 	ldr	x2, [x3, #5080]
    6648:	cb010001 	sub	x1, x0, x1
    664c:	eb02403f 	cmp	x1, x2, lsl #16
    6650:	54ffff22 	b.cs	6634 <fwp_caps173+0x4>  // b.hs, b.nlast
    6654:	d350fc22 	lsr	x2, x1, #16
    6658:	f949fc65 	ldr	x5, [x3, #5112]
    665c:	8b020842 	add	x2, x2, x2, lsl #2
    6660:	d37df042 	lsl	x2, x2, #3
    6664:	8b0200a4 	add	x4, x5, x2
    6668:	f9401083 	ldr	x3, [x4, #32]
    666c:	b4fffe43 	cbz	x3, 6634 <fwp_caps173+0x4>
    6670:	386268a2 	ldrb	w2, [x5, x2]
    6674:	7100085f 	cmp	w2, #0x2
    6678:	540001c0 	b.eq	66b0 <fwp_caps173+0x80>  // b.none
    667c:	7100045f 	cmp	w2, #0x1
    6680:	54fffda1 	b.ne	6634 <fwp_caps173+0x4>  // b.any
    6684:	29430885 	ldp	w5, w2, [x4, #24]
    6688:	92403c21 	and	x1, x1, #0xffff
    668c:	9b057c21 	mul	x1, x1, x5
    6690:	d360fc21 	lsr	x1, x1, #32
    6694:	eb02003f 	cmp	x1, x2
    6698:	54fffce2 	b.cs	6634 <fwp_caps173+0x4>  // b.hs, b.nlast
    669c:	8b010063 	add	x3, x3, x1
    66a0:	39400061 	ldrb	w1, [x3]
    66a4:	7100043f 	cmp	w1, #0x1
    66a8:	54fffc61 	b.ne	6634 <fwp_caps173+0x4>  // b.any
    66ac:	17fff851 	b	47f0 <fwp_mem_free>
    66b0:	72003c3f 	tst	w1, #0xffff
    66b4:	54ffff60 	b.eq	66a0 <fwp_caps173+0x70>  // b.none
    66b8:	d65f03c0 	ret
    66bc:	d503201f 	nop

00000000000066c0 <f37>:
    66c0:	d10203ff 	sub	sp, sp, #0x80
    66c4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    66c8:	f947f421 	ldr	x1, [x1, #4072]
    66cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    66d0:	910083fd 	add	x29, sp, #0x20
    66d4:	a9045bf5 	stp	x21, x22, [sp, #64]
    66d8:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    66dc:	911502c3 	add	x3, x22, #0x540
    66e0:	a90353f3 	stp	x19, x20, [sp, #48]
    66e4:	a90563f7 	stp	x23, x24, [sp, #80]
    66e8:	aa0003f8 	mov	x24, x0
    66ec:	a9066bf9 	stp	x25, x26, [sp, #96]
    66f0:	f949ec62 	ldr	x2, [x3, #5080]
    66f4:	f9400024 	ldr	x4, [x1]
    66f8:	f9000fe4 	str	x4, [sp, #24]
    66fc:	d2800004 	mov	x4, #0x0                   	// #0
    6700:	f949d861 	ldr	x1, [x3, #5040]
    6704:	d370bc42 	lsl	x2, x2, #16
    6708:	b40017e0 	cbz	x0, 6a04 <f37+0x344>
    670c:	f9400819 	ldr	x25, [x0, #16]
    6710:	cb010321 	sub	x1, x25, x1
    6714:	eb02003f 	cmp	x1, x2
    6718:	54000362 	b.cs	6784 <f37+0xc4>  // b.hs, b.nlast
    671c:	f949fc60 	ldr	x0, [x3, #5112]
    6720:	d350fc22 	lsr	x2, x1, #16
    6724:	8b020842 	add	x2, x2, x2, lsl #2
    6728:	8b020c02 	add	x2, x0, x2, lsl #3
    672c:	f9401040 	ldr	x0, [x2, #32]
    6730:	b40002a0 	cbz	x0, 6784 <f37+0xc4>
    6734:	39400043 	ldrb	w3, [x2]
    6738:	7100087f 	cmp	w3, #0x2
    673c:	540015e0 	b.eq	69f8 <f37+0x338>  // b.none
    6740:	7100047f 	cmp	w3, #0x1
    6744:	540001c1 	b.ne	677c <f37+0xbc>  // b.any
    6748:	29430843 	ldp	w3, w2, [x2, #24]
    674c:	92403c21 	and	x1, x1, #0xffff
    6750:	9b037c21 	mul	x1, x1, x3
    6754:	d360fc21 	lsr	x1, x1, #32
    6758:	eb02003f 	cmp	x1, x2
    675c:	54000102 	b.cs	677c <f37+0xbc>  // b.hs, b.nlast
    6760:	8b010000 	add	x0, x0, x1
    6764:	39400001 	ldrb	w1, [x0]
    6768:	340000a1 	cbz	w1, 677c <f37+0xbc>
    676c:	7103f43f 	cmp	w1, #0xfd
    6770:	54001888 	b.hi	6a80 <f37+0x3c0>  // b.pmore
    6774:	11000421 	add	w1, w1, #0x1
    6778:	39000001 	strb	w1, [x0]
    677c:	d2800000 	mov	x0, #0x0                   	// #0
    6780:	b40000f8 	cbz	x24, 679c <f37+0xdc>
    6784:	aa1803e1 	mov	x1, x24
    6788:	d2800000 	mov	x0, #0x0                   	// #0
    678c:	d503201f 	nop
    6790:	f9400821 	ldr	x1, [x1, #16]
    6794:	91000400 	add	x0, x0, #0x1
    6798:	b5ffffc1 	cbnz	x1, 6790 <f37+0xd0>
    679c:	b40013b9 	cbz	x25, 6a10 <f37+0x350>
    67a0:	aa1903e1 	mov	x1, x25
    67a4:	d2800002 	mov	x2, #0x0                   	// #0
    67a8:	f9400821 	ldr	x1, [x1, #16]
    67ac:	91000442 	add	x2, x2, #0x1
    67b0:	b5ffffc1 	cbnz	x1, 67a8 <f37+0xe8>
    67b4:	eb00005f 	cmp	x2, x0
    67b8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    67bc:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    67c0:	eb01035f 	cmp	x26, x1
    67c4:	54001668 	b.hi	6a90 <f37+0x3d0>  // b.pmore
    67c8:	d37ffb53 	lsl	x19, x26, #1
    67cc:	52800041 	mov	w1, #0x2                   	// #2
    67d0:	91000660 	add	x0, x19, #0x1
    67d4:	d37df000 	lsl	x0, x0, #3
    67d8:	97fff926 	bl	4c70 <fwp_heap_alloc>
    67dc:	aa0003f7 	mov	x23, x0
    67e0:	911502c1 	add	x1, x22, #0x540
    67e4:	aa0103e0 	mov	x0, x1
    67e8:	f90002f3 	str	x19, [x23]
    67ec:	f949d821 	ldr	x1, [x1, #5040]
    67f0:	f949ec00 	ldr	x0, [x0, #5080]
    67f4:	cb0102e1 	sub	x1, x23, x1
    67f8:	eb00403f 	cmp	x1, x0, lsl #16
    67fc:	54000342 	b.cs	6864 <f37+0x1a4>  // b.hs, b.nlast
    6800:	911502c2 	add	x2, x22, #0x540
    6804:	d350fc20 	lsr	x0, x1, #16
    6808:	8b000800 	add	x0, x0, x0, lsl #2
    680c:	f949fc43 	ldr	x3, [x2, #5112]
    6810:	d37df002 	lsl	x2, x0, #3
    6814:	8b020060 	add	x0, x3, x2
    6818:	f9401013 	ldr	x19, [x0, #32]
    681c:	b4000253 	cbz	x19, 6864 <f37+0x1a4>
    6820:	38626862 	ldrb	w2, [x3, x2]
    6824:	7100085f 	cmp	w2, #0x2
    6828:	54000e20 	b.eq	69ec <f37+0x32c>  // b.none
    682c:	7100045f 	cmp	w2, #0x1
    6830:	540001a1 	b.ne	6864 <f37+0x1a4>  // b.any
    6834:	29430002 	ldp	w2, w0, [x0, #24]
    6838:	92403c21 	and	x1, x1, #0xffff
    683c:	9b027c21 	mul	x1, x1, x2
    6840:	d360fc21 	lsr	x1, x1, #32
    6844:	eb00003f 	cmp	x1, x0
    6848:	540000e2 	b.cs	6864 <f37+0x1a4>  // b.hs, b.nlast
    684c:	8b010273 	add	x19, x19, x1
    6850:	39400260 	ldrb	w0, [x19]
    6854:	7103fc1f 	cmp	w0, #0xff
    6858:	54000f80 	b.eq	6a48 <f37+0x388>  // b.none
    685c:	52800020 	mov	w0, #0x1                   	// #1
    6860:	39000260 	strb	w0, [x19]
    6864:	b400025a 	cbz	x26, 68ac <f37+0x1ec>
    6868:	8b1a12fa 	add	x26, x23, x26, lsl #4
    686c:	aa1703f3 	mov	x19, x23
    6870:	aa1803f5 	mov	x21, x24
    6874:	aa1903f4 	mov	x20, x25
    6878:	f9400683 	ldr	x3, [x20, #8]
    687c:	f94006a2 	ldr	x2, [x21, #8]
    6880:	f9400861 	ldr	x1, [x3, #16]
    6884:	f9400840 	ldr	x0, [x2, #16]
    6888:	fd400461 	ldr	d1, [x3, #8]
    688c:	fd400440 	ldr	d0, [x2, #8]
    6890:	97fffa38 	bl	5170 <w120>
    6894:	f9000660 	str	x0, [x19, #8]
    6898:	f8010e61 	str	x1, [x19, #16]!
    689c:	f9400a94 	ldr	x20, [x20, #16]
    68a0:	f9400ab5 	ldr	x21, [x21, #16]
    68a4:	eb13035f 	cmp	x26, x19
    68a8:	54fffe81 	b.ne	6878 <f37+0x1b8>  // b.any
    68ac:	aa1903e0 	mov	x0, x25
    68b0:	97fffd48 	bl	5dd0 <fwp_drop4>
    68b4:	aa1803e0 	mov	x0, x24
    68b8:	97fffd46 	bl	5dd0 <fwp_drop4>
    68bc:	f94002f5 	ldr	x21, [x23]
    68c0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    68c4:	b4000275 	cbz	x21, 6910 <f37+0x250>
    68c8:	fd003be8 	str	d8, [sp, #112]
    68cc:	2f00e408 	movi	d8, #0x0
    68d0:	910022f9 	add	x25, x23, #0x8
    68d4:	910042f8 	add	x24, x23, #0x10
    68d8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    68dc:	d2800013 	mov	x19, #0x0                   	// #0
    68e0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    68e4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    68e8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    68ec:	aa0303e1 	mov	x1, x3
    68f0:	1e602908 	fadd	d8, d8, d0
    68f4:	91000a73 	add	x19, x19, #0x2
    68f8:	97fff96b 	bl	4ea4 <fwp_p_ad_push>
    68fc:	aa0003f4 	mov	x20, x0
    6900:	eb1302bf 	cmp	x21, x19
    6904:	54fffee8 	b.hi	68e0 <f37+0x220>  // b.pmore
    6908:	9e660115 	fmov	x21, d8
    690c:	fd403be8 	ldr	d8, [sp, #112]
    6910:	911502d6 	add	x22, x22, #0x540
    6914:	aa1703e0 	mov	x0, x23
    6918:	97fffeca 	bl	6440 <fwp_drop10>
    691c:	a900d3f5 	stp	x21, x20, [sp, #8]
    6920:	910023e1 	add	x1, sp, #0x8
    6924:	52800000 	mov	w0, #0x0                   	// #0
    6928:	97fff917 	bl	4d84 <fwp_data.part.0.constprop.0>
    692c:	f949dac1 	ldr	x1, [x22, #5040]
    6930:	aa0003f3 	mov	x19, x0
    6934:	f949eec0 	ldr	x0, [x22, #5080]
    6938:	cb010261 	sub	x1, x19, x1
    693c:	eb00403f 	cmp	x1, x0, lsl #16
    6940:	54000322 	b.cs	69a4 <f37+0x2e4>  // b.hs, b.nlast
    6944:	d350fc22 	lsr	x2, x1, #16
    6948:	f949fec3 	ldr	x3, [x22, #5112]
    694c:	8b020842 	add	x2, x2, x2, lsl #2
    6950:	d37df042 	lsl	x2, x2, #3
    6954:	8b020060 	add	x0, x3, x2
    6958:	f9401014 	ldr	x20, [x0, #32]
    695c:	b4000254 	cbz	x20, 69a4 <f37+0x2e4>
    6960:	38626862 	ldrb	w2, [x3, x2]
    6964:	7100085f 	cmp	w2, #0x2
    6968:	540003c0 	b.eq	69e0 <f37+0x320>  // b.none
    696c:	7100045f 	cmp	w2, #0x1
    6970:	540001a1 	b.ne	69a4 <f37+0x2e4>  // b.any
    6974:	29430002 	ldp	w2, w0, [x0, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b027c21 	mul	x1, x1, x2
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb00003f 	cmp	x1, x0
    6988:	540000e2 	b.cs	69a4 <f37+0x2e4>  // b.hs, b.nlast
    698c:	8b010294 	add	x20, x20, x1
    6990:	39400280 	ldrb	w0, [x20]
    6994:	7103fc1f 	cmp	w0, #0xff
    6998:	540005e0 	b.eq	6a54 <f37+0x394>  // b.none
    699c:	52800020 	mov	w0, #0x1                   	// #1
    69a0:	39000280 	strb	w0, [x20]
    69a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    69a8:	f947f400 	ldr	x0, [x0, #4072]
    69ac:	f9400fe2 	ldr	x2, [sp, #24]
    69b0:	f9400001 	ldr	x1, [x0]
    69b4:	eb010042 	subs	x2, x2, x1
    69b8:	d2800001 	mov	x1, #0x0                   	// #0
    69bc:	54000721 	b.ne	6aa0 <f37+0x3e0>  // b.any
    69c0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    69c4:	aa1303e0 	mov	x0, x19
    69c8:	a94353f3 	ldp	x19, x20, [sp, #48]
    69cc:	a9445bf5 	ldp	x21, x22, [sp, #64]
    69d0:	a94563f7 	ldp	x23, x24, [sp, #80]
    69d4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    69d8:	910203ff 	add	sp, sp, #0x80
    69dc:	d65f03c0 	ret
    69e0:	72003c3f 	tst	w1, #0xffff
    69e4:	54fffe01 	b.ne	69a4 <f37+0x2e4>  // b.any
    69e8:	17ffffea 	b	6990 <f37+0x2d0>
    69ec:	72003c3f 	tst	w1, #0xffff
    69f0:	54fff3a1 	b.ne	6864 <f37+0x1a4>  // b.any
    69f4:	17ffff97 	b	6850 <f37+0x190>
    69f8:	72003c3f 	tst	w1, #0xffff
    69fc:	54ffec01 	b.ne	677c <f37+0xbc>  // b.any
    6a00:	17ffff59 	b	6764 <f37+0xa4>
    6a04:	cb0103e1 	neg	x1, x1
    6a08:	eb02003f 	cmp	x1, x2
    6a0c:	540002a3 	b.cc	6a60 <f37+0x3a0>  // b.lo, b.ul, b.last
    6a10:	52800041 	mov	w1, #0x2                   	// #2
    6a14:	d2800100 	mov	x0, #0x8                   	// #8
    6a18:	97fff896 	bl	4c70 <fwp_heap_alloc>
    6a1c:	aa0003f7 	mov	x23, x0
    6a20:	911502c0 	add	x0, x22, #0x540
    6a24:	f90002ff 	str	xzr, [x23]
    6a28:	f949d801 	ldr	x1, [x0, #5040]
    6a2c:	f949ec00 	ldr	x0, [x0, #5080]
    6a30:	cb0102e1 	sub	x1, x23, x1
    6a34:	eb00403f 	cmp	x1, x0, lsl #16
    6a38:	54000282 	b.cs	6a88 <f37+0x3c8>  // b.hs, b.nlast
    6a3c:	d280001a 	mov	x26, #0x0                   	// #0
    6a40:	d2800019 	mov	x25, #0x0                   	// #0
    6a44:	17ffff6f 	b	6800 <f37+0x140>
    6a48:	aa1303e0 	mov	x0, x19
    6a4c:	97fff6c9 	bl	4570 <fwp_rc_forget_slot>
    6a50:	17ffff83 	b	685c <f37+0x19c>
    6a54:	aa1403e0 	mov	x0, x20
    6a58:	97fff6c6 	bl	4570 <fwp_rc_forget_slot>
    6a5c:	17ffffd0 	b	699c <f37+0x2dc>
    6a60:	f949fc62 	ldr	x2, [x3, #5112]
    6a64:	d350fc20 	lsr	x0, x1, #16
    6a68:	8b000800 	add	x0, x0, x0, lsl #2
    6a6c:	8b000c42 	add	x2, x2, x0, lsl #3
    6a70:	f9401040 	ldr	x0, [x2, #32]
    6a74:	b4fffce0 	cbz	x0, 6a10 <f37+0x350>
    6a78:	d2800019 	mov	x25, #0x0                   	// #0
    6a7c:	17ffff2e 	b	6734 <f37+0x74>
    6a80:	97fff675 	bl	4454 <fwp_rc_wide_dup>
    6a84:	17ffff3e 	b	677c <f37+0xbc>
    6a88:	d2800019 	mov	x25, #0x0                   	// #0
    6a8c:	17ffff88 	b	68ac <f37+0x1ec>
    6a90:	90000020 	adrp	x0, a000 <__divti3+0xa0>
    6a94:	9129a000 	add	x0, x0, #0xa68
    6a98:	fd003be8 	str	d8, [sp, #112]
    6a9c:	97fff2b9 	bl	3580 <fwp_trap>
    6aa0:	fd003be8 	str	d8, [sp, #112]
    6aa4:	97ffef77 	bl	2880 <__stack_chk_fail@plt>
    6aa8:	d503201f 	nop
    6aac:	d503201f 	nop

0000000000006ab0 <fwp_owned_entry37>:
    6ab0:	f9400000 	ldr	x0, [x0]
    6ab4:	17ffff03 	b	66c0 <f37>
    6ab8:	d503201f 	nop
    6abc:	d503201f 	nop

0000000000006ac0 <e37>:
    6ac0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6ac4:	910003fd 	mov	x29, sp
    6ac8:	f9000bf3 	str	x19, [sp, #16]
    6acc:	f9400013 	ldr	x19, [x0]
    6ad0:	aa1303e0 	mov	x0, x19
    6ad4:	97fff9eb 	bl	5280 <fwp_rc_share>
    6ad8:	aa1303e0 	mov	x0, x19
    6adc:	97fffef9 	bl	66c0 <f37>
    6ae0:	aa0003f3 	mov	x19, x0
    6ae4:	97fff9e7 	bl	5280 <fwp_rc_share>
    6ae8:	aa1303e0 	mov	x0, x19
    6aec:	f9400bf3 	ldr	x19, [sp, #16]
    6af0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6af4:	d65f03c0 	ret
    6af8:	d503201f 	nop
    6afc:	d503201f 	nop

0000000000006b00 <fwp_args37>:
    6b00:	7100003f 	cmp	w1, #0x0
    6b04:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b08:	54000041 	b.ne	6b10 <fwp_args37+0x10>  // b.any
    6b0c:	d65f03c0 	ret
    6b10:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6b14:	91150042 	add	x2, x2, #0x540
    6b18:	f9400001 	ldr	x1, [x0]
    6b1c:	f949d843 	ldr	x3, [x2, #5040]
    6b20:	f949ec40 	ldr	x0, [x2, #5080]
    6b24:	cb030021 	sub	x1, x1, x3
    6b28:	eb00403f 	cmp	x1, x0, lsl #16
    6b2c:	54ffff02 	b.cs	6b0c <fwp_args37+0xc>  // b.hs, b.nlast
    6b30:	d350fc20 	lsr	x0, x1, #16
    6b34:	f949fc44 	ldr	x4, [x2, #5112]
    6b38:	8b000800 	add	x0, x0, x0, lsl #2
    6b3c:	d37df002 	lsl	x2, x0, #3
    6b40:	8b020083 	add	x3, x4, x2
    6b44:	f9401060 	ldr	x0, [x3, #32]
    6b48:	b4fffe20 	cbz	x0, 6b0c <fwp_args37+0xc>
    6b4c:	38626882 	ldrb	w2, [x4, x2]
    6b50:	7100085f 	cmp	w2, #0x2
    6b54:	54000220 	b.eq	6b98 <fwp_args37+0x98>  // b.none
    6b58:	7100045f 	cmp	w2, #0x1
    6b5c:	54fffd81 	b.ne	6b0c <fwp_args37+0xc>  // b.any
    6b60:	29430864 	ldp	w4, w2, [x3, #24]
    6b64:	92403c21 	and	x1, x1, #0xffff
    6b68:	9b047c21 	mul	x1, x1, x4
    6b6c:	d360fc21 	lsr	x1, x1, #32
    6b70:	eb02003f 	cmp	x1, x2
    6b74:	54fffcc2 	b.cs	6b0c <fwp_args37+0xc>  // b.hs, b.nlast
    6b78:	8b010000 	add	x0, x0, x1
    6b7c:	39400001 	ldrb	w1, [x0]
    6b80:	34fffc61 	cbz	w1, 6b0c <fwp_args37+0xc>
    6b84:	7103f43f 	cmp	w1, #0xfd
    6b88:	540000e8 	b.hi	6ba4 <fwp_args37+0xa4>  // b.pmore
    6b8c:	11000421 	add	w1, w1, #0x1
    6b90:	39000001 	strb	w1, [x0]
    6b94:	d65f03c0 	ret
    6b98:	72003c3f 	tst	w1, #0xffff
    6b9c:	54ffff00 	b.eq	6b7c <fwp_args37+0x7c>  // b.none
    6ba0:	d65f03c0 	ret
    6ba4:	17fff62c 	b	4454 <fwp_rc_wide_dup>
    6ba8:	d503201f 	nop
    6bac:	d503201f 	nop

0000000000006bb0 <fwp_caps37>:
    6bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6bb4:	910003fd 	mov	x29, sp
    6bb8:	f9000bf3 	str	x19, [sp, #16]
    6bbc:	aa0003f3 	mov	x19, x0
    6bc0:	b9400400 	ldr	w0, [x0, #4]
    6bc4:	340004a0 	cbz	w0, 6c58 <fwp_caps37+0xa8>
    6bc8:	f9400660 	ldr	x0, [x19, #8]
    6bcc:	350004e1 	cbnz	w1, 6c68 <fwp_caps37+0xb8>
    6bd0:	97fffc80 	bl	5dd0 <fwp_drop4>
    6bd4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6bd8:	91150042 	add	x2, x2, #0x540
    6bdc:	f949d840 	ldr	x0, [x2, #5040]
    6be0:	f949ec41 	ldr	x1, [x2, #5080]
    6be4:	cb000260 	sub	x0, x19, x0
    6be8:	eb01401f 	cmp	x0, x1, lsl #16
    6bec:	54000382 	b.cs	6c5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6bf0:	d350fc01 	lsr	x1, x0, #16
    6bf4:	f949fc44 	ldr	x4, [x2, #5112]
    6bf8:	8b010821 	add	x1, x1, x1, lsl #2
    6bfc:	d37df021 	lsl	x1, x1, #3
    6c00:	8b010083 	add	x3, x4, x1
    6c04:	f9401062 	ldr	x2, [x3, #32]
    6c08:	b40002a2 	cbz	x2, 6c5c <fwp_caps37+0xac>
    6c0c:	38616881 	ldrb	w1, [x4, x1]
    6c10:	7100083f 	cmp	w1, #0x2
    6c14:	540006c0 	b.eq	6cec <fwp_caps37+0x13c>  // b.none
    6c18:	7100043f 	cmp	w1, #0x1
    6c1c:	54000201 	b.ne	6c5c <fwp_caps37+0xac>  // b.any
    6c20:	29430464 	ldp	w4, w1, [x3, #24]
    6c24:	92403c00 	and	x0, x0, #0xffff
    6c28:	9b047c00 	mul	x0, x0, x4
    6c2c:	d360fc00 	lsr	x0, x0, #32
    6c30:	eb01001f 	cmp	x0, x1
    6c34:	54000142 	b.cs	6c5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6c38:	8b000042 	add	x2, x2, x0
    6c3c:	39400040 	ldrb	w0, [x2]
    6c40:	7100041f 	cmp	w0, #0x1
    6c44:	540000c1 	b.ne	6c5c <fwp_caps37+0xac>  // b.any
    6c48:	aa1303e0 	mov	x0, x19
    6c4c:	f9400bf3 	ldr	x19, [sp, #16]
    6c50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c54:	17fff6e7 	b	47f0 <fwp_mem_free>
    6c58:	34fffbe1 	cbz	w1, 6bd4 <fwp_caps37+0x24>
    6c5c:	f9400bf3 	ldr	x19, [sp, #16]
    6c60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c64:	d65f03c0 	ret
    6c68:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6c6c:	91150042 	add	x2, x2, #0x540
    6c70:	f949d843 	ldr	x3, [x2, #5040]
    6c74:	f949ec41 	ldr	x1, [x2, #5080]
    6c78:	cb030000 	sub	x0, x0, x3
    6c7c:	eb01401f 	cmp	x0, x1, lsl #16
    6c80:	54fffee2 	b.cs	6c5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6c84:	d350fc01 	lsr	x1, x0, #16
    6c88:	f949fc44 	ldr	x4, [x2, #5112]
    6c8c:	8b010821 	add	x1, x1, x1, lsl #2
    6c90:	d37df021 	lsl	x1, x1, #3
    6c94:	8b010083 	add	x3, x4, x1
    6c98:	f9401062 	ldr	x2, [x3, #32]
    6c9c:	b4fffe02 	cbz	x2, 6c5c <fwp_caps37+0xac>
    6ca0:	38616881 	ldrb	w1, [x4, x1]
    6ca4:	7100083f 	cmp	w1, #0x2
    6ca8:	54000280 	b.eq	6cf8 <fwp_caps37+0x148>  // b.none
    6cac:	7100043f 	cmp	w1, #0x1
    6cb0:	54fffd61 	b.ne	6c5c <fwp_caps37+0xac>  // b.any
    6cb4:	92403c01 	and	x1, x0, #0xffff
    6cb8:	29430064 	ldp	w4, w0, [x3, #24]
    6cbc:	9b047c21 	mul	x1, x1, x4
    6cc0:	d360fc21 	lsr	x1, x1, #32
    6cc4:	eb00003f 	cmp	x1, x0
    6cc8:	54fffca2 	b.cs	6c5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ccc:	8b010042 	add	x2, x2, x1
    6cd0:	39400040 	ldrb	w0, [x2]
    6cd4:	34fffc40 	cbz	w0, 6c5c <fwp_caps37+0xac>
    6cd8:	7103f41f 	cmp	w0, #0xfd
    6cdc:	54000148 	b.hi	6d04 <fwp_caps37+0x154>  // b.pmore
    6ce0:	11000400 	add	w0, w0, #0x1
    6ce4:	39000040 	strb	w0, [x2]
    6ce8:	17ffffdd 	b	6c5c <fwp_caps37+0xac>
    6cec:	72003c1f 	tst	w0, #0xffff
    6cf0:	54fffb61 	b.ne	6c5c <fwp_caps37+0xac>  // b.any
    6cf4:	17ffffd2 	b	6c3c <fwp_caps37+0x8c>
    6cf8:	72003c1f 	tst	w0, #0xffff
    6cfc:	54fffb01 	b.ne	6c5c <fwp_caps37+0xac>  // b.any
    6d00:	17fffff4 	b	6cd0 <fwp_caps37+0x120>
    6d04:	f9400bf3 	ldr	x19, [sp, #16]
    6d08:	aa0203e0 	mov	x0, x2
    6d0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d10:	17fff5d1 	b	4454 <fwp_rc_wide_dup>

0000000000006d14 <fwp_write>:
    6d14:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6d18:	910003fd 	mov	x29, sp
    6d1c:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6d20:	f947f484 	ldr	x4, [x4, #4072]
    6d24:	a90153f3 	stp	x19, x20, [sp, #16]
    6d28:	d10943ff 	sub	sp, sp, #0x250
    6d2c:	b9400045 	ldr	w5, [x2]
    6d30:	aa0003f4 	mov	x20, x0
    6d34:	f9400080 	ldr	x0, [x4]
    6d38:	f90127e0 	str	x0, [sp, #584]
    6d3c:	d2800000 	mov	x0, #0x0                   	// #0
    6d40:	710064bf 	cmp	w5, #0x19
    6d44:	54000408 	b.hi	6dc4 <fwp_write+0xb0>  // b.pmore
    6d48:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x980>
    6d4c:	aa0103f3 	mov	x19, x1
    6d50:	910b4000 	add	x0, x0, #0x2d0
    6d54:	f9013bf5 	str	x21, [sp, #624]
    6d58:	f9013ff6 	str	x22, [sp, #632]
    6d5c:	f90153fb 	str	x27, [sp, #672]
    6d60:	f90157fc 	str	x28, [sp, #680]
    6d64:	aa0203fc 	mov	x28, x2
    6d68:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6d6c:	10000061 	adr	x1, 6d78 <fwp_write+0x64>
    6d70:	8b20a820 	add	x0, x1, w0, sxth #2
    6d74:	d61f0000 	br	x0
    6d78:	910123e0 	add	x0, sp, #0x48
    6d7c:	aa1303e5 	mov	x5, x19
    6d80:	90000024 	adrp	x4, a000 <__divti3+0xa0>
    6d84:	aa0003f3 	mov	x19, x0
    6d88:	912ac084 	add	x4, x4, #0xab0
    6d8c:	d2804003 	mov	x3, #0x200                 	// #512
    6d90:	aa0303e1 	mov	x1, x3
    6d94:	52800042 	mov	w2, #0x2                   	// #2
    6d98:	97ffee96 	bl	27f0 <__snprintf_chk@plt>
    6d9c:	aa1303e0 	mov	x0, x19
    6da0:	97ffee5c 	bl	2710 <strlen@plt>
    6da4:	aa1303e1 	mov	x1, x19
    6da8:	aa0003e2 	mov	x2, x0
    6dac:	aa1403e0 	mov	x0, x20
    6db0:	97fff198 	bl	3410 <buf_put>
    6db4:	f9413bf5 	ldr	x21, [sp, #624]
    6db8:	f9413ff6 	ldr	x22, [sp, #632]
    6dbc:	f94153fb 	ldr	x27, [sp, #672]
    6dc0:	f94157fc 	ldr	x28, [sp, #680]
    6dc4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6dc8:	f947f400 	ldr	x0, [x0, #4072]
    6dcc:	f94127e2 	ldr	x2, [sp, #584]
    6dd0:	f9400001 	ldr	x1, [x0]
    6dd4:	eb010042 	subs	x2, x2, x1
    6dd8:	d2800001 	mov	x1, #0x0                   	// #0
    6ddc:	540077a1 	b.ne	7cd0 <fwp_write+0xfbc>  // b.any
    6de0:	910943ff 	add	sp, sp, #0x250
    6de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6de8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6dec:	d65f03c0 	ret
    6df0:	910123e0 	add	x0, sp, #0x48
    6df4:	aa1303e5 	mov	x5, x19
    6df8:	90000024 	adrp	x4, a000 <__divti3+0xa0>
    6dfc:	aa0003f3 	mov	x19, x0
    6e00:	912aa084 	add	x4, x4, #0xaa8
    6e04:	d2804003 	mov	x3, #0x200                 	// #512
    6e08:	17ffffe2 	b	6d90 <fwp_write+0x7c>
    6e0c:	71004cbf 	cmp	w5, #0x13
    6e10:	90000020 	adrp	x0, a000 <__divti3+0xa0>
    6e14:	90000021 	adrp	x1, a000 <__divti3+0xa0>
    6e18:	912a6000 	add	x0, x0, #0xa98
    6e1c:	912a8021 	add	x1, x1, #0xaa0
    6e20:	d2800082 	mov	x2, #0x4                   	// #4
    6e24:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6e28:	aa1403e0 	mov	x0, x20
    6e2c:	f90143f7 	str	x23, [sp, #640]
    6e30:	d2800016 	mov	x22, #0x0                   	// #0
    6e34:	f90147f8 	str	x24, [sp, #648]
    6e38:	97fff176 	bl	3410 <buf_put>
    6e3c:	f9400260 	ldr	x0, [x19]
    6e40:	90000037 	adrp	x23, a000 <__divti3+0xa0>
    6e44:	d2800015 	mov	x21, #0x0                   	// #0
    6e48:	912c82f7 	add	x23, x23, #0xb20
    6e4c:	b4004780 	cbz	x0, 773c <fwp_write+0xa28>
    6e50:	b9400380 	ldr	w0, [x28]
    6e54:	52800003 	mov	w3, #0x0                   	// #0
    6e58:	f9401f82 	ldr	x2, [x28, #56]
    6e5c:	71004c1f 	cmp	w0, #0x13
    6e60:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6e64:	aa1403e0 	mov	x0, x20
    6e68:	8b010e61 	add	x1, x19, x1, lsl #3
    6e6c:	f9400421 	ldr	x1, [x1, #8]
    6e70:	97ffffa9 	bl	6d14 <fwp_write>
    6e74:	b9400380 	ldr	w0, [x28]
    6e78:	7100481f 	cmp	w0, #0x12
    6e7c:	54004b20 	b.eq	77e0 <fwp_write+0xacc>  // b.none
    6e80:	f9400260 	ldr	x0, [x19]
    6e84:	910006b5 	add	x21, x21, #0x1
    6e88:	91000ad6 	add	x22, x22, #0x2
    6e8c:	eb15001f 	cmp	x0, x21
    6e90:	54004569 	b.ls	773c <fwp_write+0xa28>  // b.plast
    6e94:	aa1703e1 	mov	x1, x23
    6e98:	aa1403e0 	mov	x0, x20
    6e9c:	d2800042 	mov	x2, #0x2                   	// #2
    6ea0:	97fff15c 	bl	3410 <buf_put>
    6ea4:	17ffffeb 	b	6e50 <fwp_write+0x13c>
    6ea8:	90000021 	adrp	x1, a000 <__divti3+0xa0>
    6eac:	912b6021 	add	x1, x1, #0xad8
    6eb0:	d28000c2 	mov	x2, #0x6                   	// #6
    6eb4:	aa1403e0 	mov	x0, x20
    6eb8:	91004273 	add	x19, x19, #0x10
    6ebc:	97fff155 	bl	3410 <buf_put>
    6ec0:	aa1303e0 	mov	x0, x19
    6ec4:	97ffee13 	bl	2710 <strlen@plt>
    6ec8:	aa1303e1 	mov	x1, x19
    6ecc:	aa0003e2 	mov	x2, x0
    6ed0:	aa1403e0 	mov	x0, x20
    6ed4:	97fff14f 	bl	3410 <buf_put>
    6ed8:	528007c3 	mov	w3, #0x3e                  	// #62
    6edc:	aa1403e0 	mov	x0, x20
    6ee0:	91001fe1 	add	x1, sp, #0x7
    6ee4:	d2800022 	mov	x2, #0x1                   	// #1
    6ee8:	39001fe3 	strb	w3, [sp, #7]
    6eec:	17ffffb1 	b	6db0 <fwp_write+0x9c>
    6ef0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6ef4:	f947f400 	ldr	x0, [x0, #4072]
    6ef8:	f94127e2 	ldr	x2, [sp, #584]
    6efc:	f9400001 	ldr	x1, [x0]
    6f00:	eb010042 	subs	x2, x2, x1
    6f04:	d2800001 	mov	x1, #0x0                   	// #0
    6f08:	540034c1 	b.ne	75a0 <fwp_write+0x88c>  // b.any
    6f0c:	f9413bf5 	ldr	x21, [sp, #624]
    6f10:	90000021 	adrp	x1, a000 <__divti3+0xa0>
    6f14:	f9413ff6 	ldr	x22, [sp, #632]
    6f18:	aa1403e0 	mov	x0, x20
    6f1c:	912ae021 	add	x1, x1, #0xab8
    6f20:	d2800142 	mov	x2, #0xa                   	// #10
    6f24:	f94153fb 	ldr	x27, [sp, #672]
    6f28:	f94157fc 	ldr	x28, [sp, #680]
    6f2c:	910943ff 	add	sp, sp, #0x250
    6f30:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f34:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6f38:	17fff136 	b	3410 <buf_put>
    6f3c:	f9400456 	ldr	x22, [x2, #8]
    6f40:	f90143f7 	str	x23, [sp, #640]
    6f44:	f90147f8 	str	x24, [sp, #648]
    6f48:	b4005af6 	cbz	x22, 7aa4 <fwp_write+0xd90>
    6f4c:	aa1603e0 	mov	x0, x22
    6f50:	90000021 	adrp	x1, a000 <__divti3+0xa0>
    6f54:	912ce021 	add	x1, x1, #0xb38
    6f58:	97ffee6a 	bl	2900 <strcmp@plt>
    6f5c:	2a0003f5 	mov	w21, w0
    6f60:	34005fc0 	cbz	w0, 7b58 <fwp_write+0xe44>
    6f64:	aa1603e0 	mov	x0, x22
    6f68:	97ffedea 	bl	2710 <strlen@plt>
    6f6c:	aa1603e1 	mov	x1, x22
    6f70:	aa0003e2 	mov	x2, x0
    6f74:	aa1403e0 	mov	x0, x20
    6f78:	97fff126 	bl	3410 <buf_put>
    6f7c:	52800403 	mov	w3, #0x20                  	// #32
    6f80:	91001ff5 	add	x21, sp, #0x7
    6f84:	aa1503e1 	mov	x1, x21
    6f88:	aa1403e0 	mov	x0, x20
    6f8c:	d2800022 	mov	x2, #0x1                   	// #1
    6f90:	39001fe3 	strb	w3, [sp, #7]
    6f94:	97fff11f 	bl	3410 <buf_put>
    6f98:	52800f63 	mov	w3, #0x7b                  	// #123
    6f9c:	aa1403e0 	mov	x0, x20
    6fa0:	aa1503e1 	mov	x1, x21
    6fa4:	d2800022 	mov	x2, #0x1                   	// #1
    6fa8:	39001fe3 	strb	w3, [sp, #7]
    6fac:	97fff119 	bl	3410 <buf_put>
    6fb0:	b9401380 	ldr	w0, [x28, #16]
    6fb4:	52800018 	mov	w24, #0x0                   	// #0
    6fb8:	7100001f 	cmp	w0, #0x0
    6fbc:	54003a8d 	b.le	770c <fwp_write+0x9f8>
    6fc0:	f9014bf9 	str	x25, [sp, #656]
    6fc4:	90000039 	adrp	x25, a000 <__divti3+0xa0>
    6fc8:	912d8339 	add	x25, x25, #0xb60
    6fcc:	f9014ffa 	str	x26, [sp, #664]
    6fd0:	9000003a 	adrp	x26, a000 <__divti3+0xa0>
    6fd4:	912c835a 	add	x26, x26, #0xb20
    6fd8:	91002276 	add	x22, x19, #0x8
    6fdc:	d2800013 	mov	x19, #0x0                   	// #0
    6fe0:	b5003e73 	cbnz	x19, 77ac <fwp_write+0xa98>
    6fe4:	d37df277 	lsl	x23, x19, #3
    6fe8:	34003c98 	cbz	w24, 7778 <fwp_write+0xa64>
    6fec:	f9401382 	ldr	x2, [x28, #32]
    6ff0:	aa1403e0 	mov	x0, x20
    6ff4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    6ff8:	52800003 	mov	w3, #0x0                   	// #0
    6ffc:	f8776842 	ldr	x2, [x2, x23]
    7000:	91000673 	add	x19, x19, #0x1
    7004:	97ffff44 	bl	6d14 <fwp_write>
    7008:	b9401380 	ldr	w0, [x28, #16]
    700c:	6b13001f 	cmp	w0, w19
    7010:	54fffe8c 	b.gt	6fe0 <fwp_write+0x2cc>
    7014:	f9414bf9 	ldr	x25, [sp, #656]
    7018:	f9414ffa 	ldr	x26, [sp, #664]
    701c:	34003798 	cbz	w24, 770c <fwp_write+0x9f8>
    7020:	52800523 	mov	w3, #0x29                  	// #41
    7024:	aa1503e1 	mov	x1, x21
    7028:	aa1403e0 	mov	x0, x20
    702c:	d2800022 	mov	x2, #0x1                   	// #1
    7030:	39001fe3 	strb	w3, [sp, #7]
    7034:	97fff0f7 	bl	3410 <buf_put>
    7038:	f9413bf5 	ldr	x21, [sp, #624]
    703c:	f9413ff6 	ldr	x22, [sp, #632]
    7040:	f94143f7 	ldr	x23, [sp, #640]
    7044:	f94147f8 	ldr	x24, [sp, #648]
    7048:	f94153fb 	ldr	x27, [sp, #672]
    704c:	f94157fc 	ldr	x28, [sp, #680]
    7050:	17ffff5d 	b	6dc4 <fwp_write+0xb0>
    7054:	b9404855 	ldr	w21, [x2, #72]
    7058:	aa1403e0 	mov	x0, x20
    705c:	93407eb6 	sxtw	x22, w21
    7060:	91000ac1 	add	x1, x22, #0x2
    7064:	97fff0b8 	bl	3344 <buf_grow>
    7068:	a9400281 	ldp	x1, x0, [x20]
    706c:	528e8603 	mov	w3, #0x7430                	// #29744
    7070:	78206823 	strh	w3, [x1, x0]
    7074:	8b000022 	add	x2, x1, x0
    7078:	710002bf 	cmp	w21, #0x0
    707c:	540036ad 	b.le	7750 <fwp_write+0xa3c>
    7080:	110006a3 	add	w3, w21, #0x1
    7084:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7088:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    708c:	91000449 	add	x9, x2, #0x1
    7090:	8b23c043 	add	x3, x2, w3, sxtw
    7094:	f28aaac6 	movk	x6, #0x5556
    7098:	f2955568 	movk	x8, #0xaaab
    709c:	1400000d 	b	70d0 <fwp_write+0x3bc>
    70a0:	d2800021 	mov	x1, #0x1                   	// #1
    70a4:	528005a5 	mov	w5, #0x2d                  	// #45
    70a8:	f100001f 	cmp	x0, #0x0
    70ac:	9b467e60 	smulh	x0, x19, x6
    70b0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    70b4:	381ff465 	strb	w5, [x3], #-1
    70b8:	cb040000 	sub	x0, x0, x4
    70bc:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    70c0:	cb020000 	sub	x0, x0, x2
    70c4:	8b010013 	add	x19, x0, x1
    70c8:	eb03013f 	cmp	x9, x3
    70cc:	54003420 	b.eq	7750 <fwp_write+0xa3c>  // b.none
    70d0:	9b467e60 	smulh	x0, x19, x6
    70d4:	937ffe64 	asr	x4, x19, #63
    70d8:	52800605 	mov	w5, #0x30                  	// #48
    70dc:	cb040000 	sub	x0, x0, x4
    70e0:	8b000400 	add	x0, x0, x0, lsl #1
    70e4:	cb000260 	sub	x0, x19, x0
    70e8:	91000c01 	add	x1, x0, #0x3
    70ec:	9bc87c22 	umulh	x2, x1, x8
    70f0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    70f4:	8b4204e2 	add	x2, x7, x2, lsr #1
    70f8:	eb020021 	subs	x1, x1, x2
    70fc:	54fffd60 	b.eq	70a8 <fwp_write+0x394>  // b.none
    7100:	f100043f 	cmp	x1, #0x1
    7104:	54fffce1 	b.ne	70a0 <fwp_write+0x38c>  // b.any
    7108:	d2800001 	mov	x1, #0x0                   	// #0
    710c:	52800565 	mov	w5, #0x2b                  	// #43
    7110:	17ffffe6 	b	70a8 <fwp_write+0x394>
    7114:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7118:	f947f400 	ldr	x0, [x0, #4072]
    711c:	f94127e2 	ldr	x2, [sp, #584]
    7120:	f9400001 	ldr	x1, [x0]
    7124:	eb010042 	subs	x2, x2, x1
    7128:	d2800001 	mov	x1, #0x0                   	// #0
    712c:	540023a1 	b.ne	75a0 <fwp_write+0x88c>  // b.any
    7130:	f9413bf5 	ldr	x21, [sp, #624]
    7134:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7138:	f9413ff6 	ldr	x22, [sp, #632]
    713c:	aa1403e0 	mov	x0, x20
    7140:	912b2021 	add	x1, x1, #0xac8
    7144:	d2800102 	mov	x2, #0x8                   	// #8
    7148:	17ffff77 	b	6f24 <fwp_write+0x210>
    714c:	aa1403e0 	mov	x0, x20
    7150:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7154:	d28000c2 	mov	x2, #0x6                   	// #6
    7158:	912ca021 	add	x1, x1, #0xb28
    715c:	97fff0ad 	bl	3410 <buf_put>
    7160:	d2800015 	mov	x21, #0x0                   	// #0
    7164:	f9400263 	ldr	x3, [x19]
    7168:	f240f87f 	tst	x3, #0x7fffffffffffffff
    716c:	54002c40 	b.eq	76f4 <fwp_write+0x9e0>  // b.none
    7170:	f9401f82 	ldr	x2, [x28, #56]
    7174:	f90143f7 	str	x23, [sp, #640]
    7178:	f90147f8 	str	x24, [sp, #648]
    717c:	d2800857 	mov	x23, #0x42                  	// #66
    7180:	f9014bf9 	str	x25, [sp, #656]
    7184:	f0000016 	adrp	x22, a000 <__divti3+0xa0>
    7188:	f9014ffa 	str	x26, [sp, #664]
    718c:	912c82d6 	add	x22, x22, #0xb20
    7190:	d2800038 	mov	x24, #0x1                   	// #1
    7194:	f2a18017 	movk	x23, #0xc00, lsl #16
    7198:	d2809099 	mov	x25, #0x484                 	// #1156
    719c:	b4000482 	cbz	x2, 722c <fwp_write+0x518>
    71a0:	b9400040 	ldr	w0, [x2]
    71a4:	7100701f 	cmp	w0, #0x1c
    71a8:	540042a0 	b.eq	79fc <fwp_write+0xce8>  // b.none
    71ac:	71006c1f 	cmp	w0, #0x1b
    71b0:	540003e8 	b.hi	722c <fwp_write+0x518>  // b.pmore
    71b4:	9ac02301 	lsl	x1, x24, x0
    71b8:	ea17003f 	tst	x1, x23
    71bc:	54003681 	b.ne	788c <fwp_write+0xb78>  // b.any
    71c0:	ea19003f 	tst	x1, x25
    71c4:	54003501 	b.ne	7864 <fwp_write+0xb50>  // b.any
    71c8:	d2800424 	mov	x4, #0x21                  	// #33
    71cc:	ea04003f 	tst	x1, x4
    71d0:	540002e0 	b.eq	722c <fwp_write+0x518>  // b.none
    71d4:	b7f849a3 	tbnz	x3, #63, 7b08 <fwp_write+0xdf4>
    71d8:	91002261 	add	x1, x19, #0x8
    71dc:	8b150021 	add	x1, x1, x21
    71e0:	39400021 	ldrb	w1, [x1]
    71e4:	7100001f 	cmp	w0, #0x0
    71e8:	93401c23 	sxtb	x3, w1
    71ec:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    71f0:	aa1403e0 	mov	x0, x20
    71f4:	52800003 	mov	w3, #0x0                   	// #0
    71f8:	97fffec7 	bl	6d14 <fwp_write>
    71fc:	910006b5 	add	x21, x21, #0x1
    7200:	f9400260 	ldr	x0, [x19]
    7204:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7208:	eb0002bf 	cmp	x21, x0
    720c:	540026c2 	b.cs	76e4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7210:	d2800042 	mov	x2, #0x2                   	// #2
    7214:	aa1603e1 	mov	x1, x22
    7218:	aa1403e0 	mov	x0, x20
    721c:	97fff07d 	bl	3410 <buf_put>
    7220:	f9401f82 	ldr	x2, [x28, #56]
    7224:	f9400263 	ldr	x3, [x19]
    7228:	b5fffbc2 	cbnz	x2, 71a0 <fwp_write+0x48c>
    722c:	d37df2a0 	lsl	x0, x21, #3
    7230:	b7f83f03 	tbnz	x3, #63, 7a10 <fwp_write+0xcfc>
    7234:	91002261 	add	x1, x19, #0x8
    7238:	8b000020 	add	x0, x1, x0
    723c:	f9400001 	ldr	x1, [x0]
    7240:	17ffffec 	b	71f0 <fwp_write+0x4dc>
    7244:	a9400e62 	ldp	x2, x3, [x19]
    7248:	b7f83ca3 	tbnz	x3, #63, 79dc <fwp_write+0xcc8>
    724c:	910123f5 	add	x21, sp, #0x48
    7250:	aa1503e0 	mov	x0, x21
    7254:	97ffeef3 	bl	2e20 <fwp_fmt_u128>
    7258:	aa1503e0 	mov	x0, x21
    725c:	97ffed2d 	bl	2710 <strlen@plt>
    7260:	aa1503e1 	mov	x1, x21
    7264:	aa0003e2 	mov	x2, x0
    7268:	17fffed1 	b	6dac <fwp_write+0x98>
    726c:	fd015be8 	str	d8, [sp, #688]
    7270:	1e270268 	fmov	s8, w19
    7274:	fd015fe9 	str	d9, [sp, #696]
    7278:	1e282100 	fcmp	s8, s8
    727c:	54004d26 	b.vs	7c20 <fwp_write+0xf0c>
    7280:	1e20c101 	fabs	s1, s8
    7284:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7288:	1e270000 	fmov	s0, w0
    728c:	1e202020 	fcmp	s1, s0
    7290:	54002c0d 	b.le	7810 <fwp_write+0xafc>
    7294:	1e202118 	fcmpe	s8, #0.0
    7298:	f0000002 	adrp	x2, a000 <__divti3+0xa0>
    729c:	911a8042 	add	x2, x2, #0x6a0
    72a0:	910123f5 	add	x21, sp, #0x48
    72a4:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    72a8:	9129e021 	add	x1, x1, #0xa78
    72ac:	aa1503e0 	mov	x0, x21
    72b0:	9a81c041 	csel	x1, x2, x1, gt
    72b4:	97ffedc3 	bl	29c0 <strcpy@plt>
    72b8:	aa1503e0 	mov	x0, x21
    72bc:	97ffed15 	bl	2710 <strlen@plt>
    72c0:	aa1503e1 	mov	x1, x21
    72c4:	aa0003e2 	mov	x2, x0
    72c8:	aa1403e0 	mov	x0, x20
    72cc:	97fff051 	bl	3410 <buf_put>
    72d0:	f9413bf5 	ldr	x21, [sp, #624]
    72d4:	f9413ff6 	ldr	x22, [sp, #632]
    72d8:	f94153fb 	ldr	x27, [sp, #672]
    72dc:	f94157fc 	ldr	x28, [sp, #680]
    72e0:	fd415be8 	ldr	d8, [sp, #688]
    72e4:	fd415fe9 	ldr	d9, [sp, #696]
    72e8:	17fffeb7 	b	6dc4 <fwp_write+0xb0>
    72ec:	f9400276 	ldr	x22, [x19]
    72f0:	34002e03 	cbz	w3, 78b0 <fwp_write+0xb9c>
    72f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72f8:	f947f400 	ldr	x0, [x0, #4072]
    72fc:	f94127e2 	ldr	x2, [sp, #584]
    7300:	f9400001 	ldr	x1, [x0]
    7304:	eb010042 	subs	x2, x2, x1
    7308:	d2800001 	mov	x1, #0x0                   	// #0
    730c:	540014a1 	b.ne	75a0 <fwp_write+0x88c>  // b.any
    7310:	aa1603e2 	mov	x2, x22
    7314:	91002261 	add	x1, x19, #0x8
    7318:	f9413bf5 	ldr	x21, [sp, #624]
    731c:	aa1403e0 	mov	x0, x20
    7320:	f9413ff6 	ldr	x22, [sp, #632]
    7324:	17ffff00 	b	6f24 <fwp_write+0x210>
    7328:	fd015be8 	str	d8, [sp, #688]
    732c:	9e670268 	fmov	d8, x19
    7330:	fd015fe9 	str	d9, [sp, #696]
    7334:	1e682100 	fcmp	d8, d8
    7338:	54004746 	b.vs	7c20 <fwp_write+0xf0c>
    733c:	1e60c101 	fabs	d1, d8
    7340:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7344:	9e670000 	fmov	d0, x0
    7348:	910123f5 	add	x21, sp, #0x48
    734c:	52800033 	mov	w19, #0x1                   	// #1
    7350:	1e602020 	fcmp	d1, d0
    7354:	540001ad 	b.le	7388 <fwp_write+0x674>
    7358:	1e602118 	fcmpe	d8, #0.0
    735c:	f0000002 	adrp	x2, a000 <__divti3+0xa0>
    7360:	911a8042 	add	x2, x2, #0x6a0
    7364:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7368:	9129e021 	add	x1, x1, #0xa78
    736c:	aa1503e0 	mov	x0, x21
    7370:	9a81c041 	csel	x1, x2, x1, gt
    7374:	97ffed93 	bl	29c0 <strcpy@plt>
    7378:	17ffffd0 	b	72b8 <fwp_write+0x5a4>
    737c:	11000673 	add	w19, w19, #0x1
    7380:	71004a7f 	cmp	w19, #0x12
    7384:	54003860 	b.eq	7a90 <fwp_write+0xd7c>  // b.none
    7388:	1e604100 	fmov	d0, d8
    738c:	2a1303e1 	mov	w1, w19
    7390:	aa1503e0 	mov	x0, x21
    7394:	97fff160 	bl	3914 <fwp_format_g.constprop.0>
    7398:	aa1503e0 	mov	x0, x21
    739c:	d2800001 	mov	x1, #0x0                   	// #0
    73a0:	97ffecf0 	bl	2760 <strtod@plt>
    73a4:	1e602100 	fcmp	d8, d0
    73a8:	54fffea1 	b.ne	737c <fwp_write+0x668>  // b.any
    73ac:	aa1503e0 	mov	x0, x21
    73b0:	97fff051 	bl	34f4 <fwp_finish_float>
    73b4:	17ffffc1 	b	72b8 <fwp_write+0x5a4>
    73b8:	a9400e62 	ldp	x2, x3, [x19]
    73bc:	910123f3 	add	x19, sp, #0x48
    73c0:	aa1303e0 	mov	x0, x19
    73c4:	97ffee97 	bl	2e20 <fwp_fmt_u128>
    73c8:	17fffe75 	b	6d9c <fwp_write+0x88>
    73cc:	f90143f7 	str	x23, [sp, #640]
    73d0:	f90147f8 	str	x24, [sp, #648]
    73d4:	2a1303f8 	mov	w24, w19
    73d8:	f9014bf9 	str	x25, [sp, #656]
    73dc:	f9014ffa 	str	x26, [sp, #664]
    73e0:	f13ffe7f 	cmp	x19, #0xfff
    73e4:	54000049 	b.ls	73ec <fwp_write+0x6d8>  // b.plast
    73e8:	b9400278 	ldr	w24, [x19]
    73ec:	f9400f80 	ldr	x0, [x28, #24]
    73f0:	2a1803f5 	mov	w21, w24
    73f4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    73f8:	d37ef6b9 	lsl	x25, x21, #2
    73fc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7400:	aa1603e0 	mov	x0, x22
    7404:	97ffecc3 	bl	2710 <strlen@plt>
    7408:	aa1603e1 	mov	x1, x22
    740c:	aa0003e2 	mov	x2, x0
    7410:	aa1403e0 	mov	x0, x20
    7414:	97ffefff 	bl	3410 <buf_put>
    7418:	f9401780 	ldr	x0, [x28, #40]
    741c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7420:	7100001f 	cmp	w0, #0x0
    7424:	5400068d 	b.le	74f4 <fwp_write+0x7e0>
    7428:	91002276 	add	x22, x19, #0x8
    742c:	91001ff5 	add	x21, sp, #0x7
    7430:	d280001b 	mov	x27, #0x0                   	// #0
    7434:	5280041a 	mov	w26, #0x20                  	// #32
    7438:	f9401b80 	ldr	x0, [x28, #48]
    743c:	aa1503e1 	mov	x1, x21
    7440:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7444:	d2800022 	mov	x2, #0x1                   	// #1
    7448:	f8786803 	ldr	x3, [x0, x24]
    744c:	aa1403e0 	mov	x0, x20
    7450:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7454:	39001ffa 	strb	w26, [sp, #7]
    7458:	97ffefee 	bl	3410 <buf_put>
    745c:	f13ffeff 	cmp	x23, #0xfff
    7460:	b9400261 	ldr	w1, [x19]
    7464:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7468:	7100383f 	cmp	w1, #0xe
    746c:	54000160 	b.eq	7498 <fwp_write+0x784>  // b.none
    7470:	7100403f 	cmp	w1, #0x10
    7474:	54001a60 	b.eq	77c0 <fwp_write+0xaac>  // b.none
    7478:	7100283f 	cmp	w1, #0xa
    747c:	54002aa0 	b.eq	79d0 <fwp_write+0xcbc>  // b.none
    7480:	540014ac 	b.gt	7714 <fwp_write+0xa00>
    7484:	71000c3f 	cmp	w1, #0x3
    7488:	540029ac 	b.gt	79bc <fwp_write+0xca8>
    748c:	d37ffee0 	lsr	x0, x23, #63
    7490:	37f814a1 	tbnz	w1, #31, 7724 <fwp_write+0xa10>
    7494:	d503201f 	nop
    7498:	34001460 	cbz	w0, 7724 <fwp_write+0xa10>
    749c:	52800503 	mov	w3, #0x28                  	// #40
    74a0:	aa1503e1 	mov	x1, x21
    74a4:	aa1403e0 	mov	x0, x20
    74a8:	d2800022 	mov	x2, #0x1                   	// #1
    74ac:	39001fe3 	strb	w3, [sp, #7]
    74b0:	97ffefd8 	bl	3410 <buf_put>
    74b4:	aa1303e2 	mov	x2, x19
    74b8:	aa1703e1 	mov	x1, x23
    74bc:	aa1403e0 	mov	x0, x20
    74c0:	52800003 	mov	w3, #0x0                   	// #0
    74c4:	97fffe14 	bl	6d14 <fwp_write>
    74c8:	52800523 	mov	w3, #0x29                  	// #41
    74cc:	aa1503e1 	mov	x1, x21
    74d0:	aa1403e0 	mov	x0, x20
    74d4:	d2800022 	mov	x2, #0x1                   	// #1
    74d8:	39001fe3 	strb	w3, [sp, #7]
    74dc:	97ffefcd 	bl	3410 <buf_put>
    74e0:	f9401780 	ldr	x0, [x28, #40]
    74e4:	9100077b 	add	x27, x27, #0x1
    74e8:	b8796800 	ldr	w0, [x0, x25]
    74ec:	6b1b001f 	cmp	w0, w27
    74f0:	54fffa4c 	b.gt	7438 <fwp_write+0x724>
    74f4:	f9413bf5 	ldr	x21, [sp, #624]
    74f8:	f9413ff6 	ldr	x22, [sp, #632]
    74fc:	f94143f7 	ldr	x23, [sp, #640]
    7500:	f94147f8 	ldr	x24, [sp, #648]
    7504:	f9414bf9 	ldr	x25, [sp, #656]
    7508:	f9414ffa 	ldr	x26, [sp, #664]
    750c:	f94153fb 	ldr	x27, [sp, #672]
    7510:	f94157fc 	ldr	x28, [sp, #680]
    7514:	17fffe2c 	b	6dc4 <fwp_write+0xb0>
    7518:	52800783 	mov	w3, #0x3c                  	// #60
    751c:	91001ff3 	add	x19, sp, #0x7
    7520:	aa1303e1 	mov	x1, x19
    7524:	d2800022 	mov	x2, #0x1                   	// #1
    7528:	aa1403e0 	mov	x0, x20
    752c:	39001fe3 	strb	w3, [sp, #7]
    7530:	97ffefb8 	bl	3410 <buf_put>
    7534:	f9400795 	ldr	x21, [x28, #8]
    7538:	aa1503e0 	mov	x0, x21
    753c:	97ffec75 	bl	2710 <strlen@plt>
    7540:	aa1503e1 	mov	x1, x21
    7544:	aa0003e2 	mov	x2, x0
    7548:	aa1403e0 	mov	x0, x20
    754c:	97ffefb1 	bl	3410 <buf_put>
    7550:	528007c3 	mov	w3, #0x3e                  	// #62
    7554:	aa1303e1 	mov	x1, x19
    7558:	aa1403e0 	mov	x0, x20
    755c:	d2800022 	mov	x2, #0x1                   	// #1
    7560:	39001fe3 	strb	w3, [sp, #7]
    7564:	17fffe13 	b	6db0 <fwp_write+0x9c>
    7568:	f100067f 	cmp	x19, #0x1
    756c:	540025a0 	b.eq	7a20 <fwp_write+0xd0c>  // b.none
    7570:	b100067f 	cmn	x19, #0x1
    7574:	54002bc0 	b.eq	7aec <fwp_write+0xdd8>  // b.none
    7578:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    757c:	912a0021 	add	x1, x1, #0xa80
    7580:	d2800022 	mov	x2, #0x1                   	// #1
    7584:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7588:	f947f400 	ldr	x0, [x0, #4072]
    758c:	f94127e4 	ldr	x4, [sp, #584]
    7590:	f9400003 	ldr	x3, [x0]
    7594:	eb030084 	subs	x4, x4, x3
    7598:	d2800003 	mov	x3, #0x0                   	// #0
    759c:	54ffebe0 	b.eq	7318 <fwp_write+0x604>  // b.none
    75a0:	f90143f7 	str	x23, [sp, #640]
    75a4:	f90147f8 	str	x24, [sp, #648]
    75a8:	f9014bf9 	str	x25, [sp, #656]
    75ac:	f9014ffa 	str	x26, [sp, #664]
    75b0:	fd015be8 	str	d8, [sp, #688]
    75b4:	fd015fe9 	str	d9, [sp, #696]
    75b8:	97ffecb2 	bl	2880 <__stack_chk_fail@plt>
    75bc:	52800b63 	mov	w3, #0x5b                  	// #91
    75c0:	91001ff5 	add	x21, sp, #0x7
    75c4:	aa1503e1 	mov	x1, x21
    75c8:	aa1403e0 	mov	x0, x20
    75cc:	d2800022 	mov	x2, #0x1                   	// #1
    75d0:	f0000016 	adrp	x22, a000 <__divti3+0xa0>
    75d4:	912c82d6 	add	x22, x22, #0xb20
    75d8:	39001fe3 	strb	w3, [sp, #7]
    75dc:	97ffef8d 	bl	3410 <buf_put>
    75e0:	b4000273 	cbz	x19, 762c <fwp_write+0x918>
    75e4:	f9400661 	ldr	x1, [x19, #8]
    75e8:	aa1403e0 	mov	x0, x20
    75ec:	f9401f82 	ldr	x2, [x28, #56]
    75f0:	52800003 	mov	w3, #0x0                   	// #0
    75f4:	97fffdc8 	bl	6d14 <fwp_write>
    75f8:	f9400a73 	ldr	x19, [x19, #16]
    75fc:	b4000193 	cbz	x19, 762c <fwp_write+0x918>
    7600:	aa1603e1 	mov	x1, x22
    7604:	aa1403e0 	mov	x0, x20
    7608:	d2800042 	mov	x2, #0x2                   	// #2
    760c:	97ffef81 	bl	3410 <buf_put>
    7610:	f9400661 	ldr	x1, [x19, #8]
    7614:	aa1403e0 	mov	x0, x20
    7618:	f9401f82 	ldr	x2, [x28, #56]
    761c:	52800003 	mov	w3, #0x0                   	// #0
    7620:	97fffdbd 	bl	6d14 <fwp_write>
    7624:	f9400a73 	ldr	x19, [x19, #16]
    7628:	b5fffed3 	cbnz	x19, 7600 <fwp_write+0x8ec>
    762c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7630:	aa1503e1 	mov	x1, x21
    7634:	aa1403e0 	mov	x0, x20
    7638:	d2800022 	mov	x2, #0x1                   	// #1
    763c:	39001fe3 	strb	w3, [sp, #7]
    7640:	17fffddc 	b	6db0 <fwp_write+0x9c>
    7644:	aa1403e0 	mov	x0, x20
    7648:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    764c:	d28000c2 	mov	x2, #0x6                   	// #6
    7650:	912c4021 	add	x1, x1, #0xb10
    7654:	97ffef6f 	bl	3410 <buf_put>
    7658:	f9400260 	ldr	x0, [x19]
    765c:	b40004c0 	cbz	x0, 76f4 <fwp_write+0x9e0>
    7660:	910123f5 	add	x21, sp, #0x48
    7664:	91002276 	add	x22, x19, #0x8
    7668:	f90143f7 	str	x23, [sp, #640]
    766c:	d2800017 	mov	x23, #0x0                   	// #0
    7670:	f90147f8 	str	x24, [sp, #648]
    7674:	f0000018 	adrp	x24, a000 <__divti3+0xa0>
    7678:	912c6318 	add	x24, x24, #0xb18
    767c:	f9014bf9 	str	x25, [sp, #656]
    7680:	f0000019 	adrp	x25, a000 <__divti3+0xa0>
    7684:	912c8339 	add	x25, x25, #0xb20
    7688:	f9014ffa 	str	x26, [sp, #664]
    768c:	14000005 	b	76a0 <fwp_write+0x98c>
    7690:	aa1903e1 	mov	x1, x25
    7694:	aa1403e0 	mov	x0, x20
    7698:	d2800042 	mov	x2, #0x2                   	// #2
    769c:	97ffef5d 	bl	3410 <buf_put>
    76a0:	38776ac5 	ldrb	w5, [x22, x23]
    76a4:	d2804003 	mov	x3, #0x200                 	// #512
    76a8:	aa1803e4 	mov	x4, x24
    76ac:	aa0303e1 	mov	x1, x3
    76b0:	52800042 	mov	w2, #0x2                   	// #2
    76b4:	aa1503e0 	mov	x0, x21
    76b8:	910006f7 	add	x23, x23, #0x1
    76bc:	97ffec4d 	bl	27f0 <__snprintf_chk@plt>
    76c0:	aa1503e0 	mov	x0, x21
    76c4:	97ffec13 	bl	2710 <strlen@plt>
    76c8:	aa1503e1 	mov	x1, x21
    76cc:	aa0003e2 	mov	x2, x0
    76d0:	aa1403e0 	mov	x0, x20
    76d4:	97ffef4f 	bl	3410 <buf_put>
    76d8:	f9400260 	ldr	x0, [x19]
    76dc:	eb17001f 	cmp	x0, x23
    76e0:	54fffd88 	b.hi	7690 <fwp_write+0x97c>  // b.pmore
    76e4:	f94143f7 	ldr	x23, [sp, #640]
    76e8:	f94147f8 	ldr	x24, [sp, #648]
    76ec:	f9414bf9 	ldr	x25, [sp, #656]
    76f0:	f9414ffa 	ldr	x26, [sp, #664]
    76f4:	52800ba3 	mov	w3, #0x5d                  	// #93
    76f8:	aa1403e0 	mov	x0, x20
    76fc:	91001fe1 	add	x1, sp, #0x7
    7700:	d2800022 	mov	x2, #0x1                   	// #1
    7704:	39001fe3 	strb	w3, [sp, #7]
    7708:	17fffdaa 	b	6db0 <fwp_write+0x9c>
    770c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7710:	17fffe45 	b	7024 <fwp_write+0x310>
    7714:	f10002ff 	cmp	x23, #0x0
    7718:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    771c:	71002c3f 	cmp	w1, #0xb
    7720:	54ffebc0 	b.eq	7498 <fwp_write+0x784>  // b.none
    7724:	aa1303e2 	mov	x2, x19
    7728:	aa1703e1 	mov	x1, x23
    772c:	aa1403e0 	mov	x0, x20
    7730:	52800003 	mov	w3, #0x0                   	// #0
    7734:	97fffd78 	bl	6d14 <fwp_write>
    7738:	17ffff6a 	b	74e0 <fwp_write+0x7cc>
    773c:	aa1403e0 	mov	x0, x20
    7740:	91001fe1 	add	x1, sp, #0x7
    7744:	52800fa3 	mov	w3, #0x7d                  	// #125
    7748:	d2800022 	mov	x2, #0x1                   	// #1
    774c:	17fffe39 	b	7030 <fwp_write+0x31c>
    7750:	a9400281 	ldp	x1, x0, [x20]
    7754:	91000800 	add	x0, x0, #0x2
    7758:	8b160000 	add	x0, x0, x22
    775c:	f9000680 	str	x0, [x20, #8]
    7760:	3820683f 	strb	wzr, [x1, x0]
    7764:	f9413bf5 	ldr	x21, [sp, #624]
    7768:	f9413ff6 	ldr	x22, [sp, #632]
    776c:	f94153fb 	ldr	x27, [sp, #672]
    7770:	f94157fc 	ldr	x28, [sp, #680]
    7774:	17fffd94 	b	6dc4 <fwp_write+0xb0>
    7778:	f9400f80 	ldr	x0, [x28, #24]
    777c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7780:	aa1b03e0 	mov	x0, x27
    7784:	97ffebe3 	bl	2710 <strlen@plt>
    7788:	aa1b03e1 	mov	x1, x27
    778c:	aa0003e2 	mov	x2, x0
    7790:	aa1403e0 	mov	x0, x20
    7794:	97ffef1f 	bl	3410 <buf_put>
    7798:	aa1903e1 	mov	x1, x25
    779c:	aa1403e0 	mov	x0, x20
    77a0:	d2800062 	mov	x2, #0x3                   	// #3
    77a4:	97ffef1b 	bl	3410 <buf_put>
    77a8:	17fffe11 	b	6fec <fwp_write+0x2d8>
    77ac:	aa1a03e1 	mov	x1, x26
    77b0:	aa1403e0 	mov	x0, x20
    77b4:	d2800042 	mov	x2, #0x2                   	// #2
    77b8:	97ffef16 	bl	3410 <buf_put>
    77bc:	17fffe0a 	b	6fe4 <fwp_write+0x2d0>
    77c0:	f9400660 	ldr	x0, [x19, #8]
    77c4:	b4fffb00 	cbz	x0, 7724 <fwp_write+0xa10>
    77c8:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    77cc:	912ce021 	add	x1, x1, #0xb38
    77d0:	97ffec4c 	bl	2900 <strcmp@plt>
    77d4:	7100001f 	cmp	w0, #0x0
    77d8:	1a9f07e0 	cset	w0, ne	// ne = any
    77dc:	17ffff2f 	b	7498 <fwp_write+0x784>
    77e0:	aa1403e0 	mov	x0, x20
    77e4:	d2800042 	mov	x2, #0x2                   	// #2
    77e8:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    77ec:	912cc021 	add	x1, x1, #0xb30
    77f0:	97ffef08 	bl	3410 <buf_put>
    77f4:	91004261 	add	x1, x19, #0x10
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	f9402382 	ldr	x2, [x28, #64]
    7800:	52800003 	mov	w3, #0x0                   	// #0
    7804:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7808:	97fffd43 	bl	6d14 <fwp_write>
    780c:	17fffd9d 	b	6e80 <fwp_write+0x16c>
    7810:	1e22c109 	fcvt	d9, s8
    7814:	910123f5 	add	x21, sp, #0x48
    7818:	52800033 	mov	w19, #0x1                   	// #1
    781c:	d503201f 	nop
    7820:	1e604120 	fmov	d0, d9
    7824:	2a1303e1 	mov	w1, w19
    7828:	aa1503e0 	mov	x0, x21
    782c:	97fff03a 	bl	3914 <fwp_format_g.constprop.0>
    7830:	aa1503e0 	mov	x0, x21
    7834:	d2800001 	mov	x1, #0x0                   	// #0
    7838:	97ffec3e 	bl	2930 <strtof@plt>
    783c:	1e202100 	fcmp	s8, s0
    7840:	54ffdb60 	b.eq	73ac <fwp_write+0x698>  // b.none
    7844:	11000673 	add	w19, w19, #0x1
    7848:	71002a7f 	cmp	w19, #0xa
    784c:	54fffea1 	b.ne	7820 <fwp_write+0xb0c>  // b.any
    7850:	1e604120 	fmov	d0, d9
    7854:	aa1503e0 	mov	x0, x21
    7858:	52800121 	mov	w1, #0x9                   	// #9
    785c:	97fff02e 	bl	3914 <fwp_format_g.constprop.0>
    7860:	17fffed3 	b	73ac <fwp_write+0x698>
    7864:	d37ef6a1 	lsl	x1, x21, #2
    7868:	b7f81563 	tbnz	x3, #63, 7b14 <fwp_write+0xe00>
    786c:	91002263 	add	x3, x19, #0x8
    7870:	8b010061 	add	x1, x3, x1
    7874:	b9400023 	ldr	w3, [x1]
    7878:	7100081f 	cmp	w0, #0x2
    787c:	2a0303e1 	mov	w1, w3
    7880:	93407c63 	sxtw	x3, w3
    7884:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7888:	17fffe5a 	b	71f0 <fwp_write+0x4dc>
    788c:	d37ffaa1 	lsl	x1, x21, #1
    7890:	b7f81363 	tbnz	x3, #63, 7afc <fwp_write+0xde8>
    7894:	91002263 	add	x3, x19, #0x8
    7898:	8b010061 	add	x1, x3, x1
    789c:	79400021 	ldrh	w1, [x1]
    78a0:	7100041f 	cmp	w0, #0x1
    78a4:	93403c23 	sxth	x3, w1
    78a8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    78ac:	17fffe51 	b	71f0 <fwp_write+0x4dc>
    78b0:	52800443 	mov	w3, #0x22                  	// #34
    78b4:	91001ff5 	add	x21, sp, #0x7
    78b8:	91002273 	add	x19, x19, #0x8
    78bc:	aa1503e1 	mov	x1, x21
    78c0:	aa1403e0 	mov	x0, x20
    78c4:	d2800022 	mov	x2, #0x1                   	// #1
    78c8:	39001fe3 	strb	w3, [sp, #7]
    78cc:	f90143f7 	str	x23, [sp, #640]
    78d0:	8b160277 	add	x23, x19, x22
    78d4:	f90147f8 	str	x24, [sp, #648]
    78d8:	97ffeece 	bl	3410 <buf_put>
    78dc:	b4000696 	cbz	x22, 79ac <fwp_write+0xc98>
    78e0:	f0000018 	adrp	x24, a000 <__divti3+0xa0>
    78e4:	912b8318 	add	x24, x24, #0xae0
    78e8:	f9014bf9 	str	x25, [sp, #656]
    78ec:	f0000019 	adrp	x25, a000 <__divti3+0xa0>
    78f0:	912c0339 	add	x25, x25, #0xb00
    78f4:	f9014ffa 	str	x26, [sp, #664]
    78f8:	1400000d 	b	792c <fwp_write+0xc18>
    78fc:	710024bf 	cmp	w5, #0x9
    7900:	54000460 	b.eq	798c <fwp_write+0xc78>  // b.none
    7904:	710028bf 	cmp	w5, #0xa
    7908:	54000a61 	b.ne	7a54 <fwp_write+0xd40>  // b.any
    790c:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7910:	aa1403e0 	mov	x0, x20
    7914:	912bc021 	add	x1, x1, #0xaf0
    7918:	d2800042 	mov	x2, #0x2                   	// #2
    791c:	97ffeebd 	bl	3410 <buf_put>
    7920:	91000673 	add	x19, x19, #0x1
    7924:	eb17027f 	cmp	x19, x23
    7928:	540003e0 	b.eq	79a4 <fwp_write+0xc90>  // b.none
    792c:	39400265 	ldrb	w5, [x19]
    7930:	710034bf 	cmp	w5, #0xd
    7934:	54000180 	b.eq	7964 <fwp_write+0xc50>  // b.none
    7938:	54fffe29 	b.ls	78fc <fwp_write+0xbe8>  // b.plast
    793c:	710088bf 	cmp	w5, #0x22
    7940:	540001c0 	b.eq	7978 <fwp_write+0xc64>  // b.none
    7944:	710170bf 	cmp	w5, #0x5c
    7948:	54000741 	b.ne	7a30 <fwp_write+0xd1c>  // b.any
    794c:	aa1403e0 	mov	x0, x20
    7950:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7954:	d2800042 	mov	x2, #0x2                   	// #2
    7958:	912ba021 	add	x1, x1, #0xae8
    795c:	97ffeead 	bl	3410 <buf_put>
    7960:	17fffff0 	b	7920 <fwp_write+0xc0c>
    7964:	aa1903e1 	mov	x1, x25
    7968:	aa1403e0 	mov	x0, x20
    796c:	d2800042 	mov	x2, #0x2                   	// #2
    7970:	97ffeea8 	bl	3410 <buf_put>
    7974:	17ffffeb 	b	7920 <fwp_write+0xc0c>
    7978:	aa1803e1 	mov	x1, x24
    797c:	aa1403e0 	mov	x0, x20
    7980:	d2800042 	mov	x2, #0x2                   	// #2
    7984:	97ffeea3 	bl	3410 <buf_put>
    7988:	17ffffe6 	b	7920 <fwp_write+0xc0c>
    798c:	aa1403e0 	mov	x0, x20
    7990:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7994:	d2800042 	mov	x2, #0x2                   	// #2
    7998:	912be021 	add	x1, x1, #0xaf8
    799c:	97ffee9d 	bl	3410 <buf_put>
    79a0:	17ffffe0 	b	7920 <fwp_write+0xc0c>
    79a4:	f9414bf9 	ldr	x25, [sp, #656]
    79a8:	f9414ffa 	ldr	x26, [sp, #664]
    79ac:	aa1503e1 	mov	x1, x21
    79b0:	aa1403e0 	mov	x0, x20
    79b4:	52800443 	mov	w3, #0x22                  	// #34
    79b8:	17fffd9d 	b	702c <fwp_write+0x318>
    79bc:	7100103f 	cmp	w1, #0x4
    79c0:	54ffeb21 	b.ne	7724 <fwp_write+0xa10>  // b.any
    79c4:	f94006e0 	ldr	x0, [x23, #8]
    79c8:	d37ffc00 	lsr	x0, x0, #63
    79cc:	17fffeb3 	b	7498 <fwp_write+0x784>
    79d0:	710002ff 	cmp	w23, #0x0
    79d4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    79d8:	17fffeb0 	b	7498 <fwp_write+0x784>
    79dc:	528005a1 	mov	w1, #0x2d                  	// #45
    79e0:	eb0203e2 	negs	x2, x2
    79e4:	da0303e3 	ngc	x3, x3
    79e8:	910127e0 	add	x0, sp, #0x49
    79ec:	910123f5 	add	x21, sp, #0x48
    79f0:	390123e1 	strb	w1, [sp, #72]
    79f4:	97ffed0b 	bl	2e20 <fwp_fmt_u128>
    79f8:	17fffe18 	b	7258 <fwp_write+0x544>
    79fc:	d37ceea1 	lsl	x1, x21, #4
    7a00:	b7f810a3 	tbnz	x3, #63, 7c14 <fwp_write+0xf00>
    7a04:	91002260 	add	x0, x19, #0x8
    7a08:	8b010001 	add	x1, x0, x1
    7a0c:	17fffdf9 	b	71f0 <fwp_write+0x4dc>
    7a10:	f9400a61 	ldr	x1, [x19, #16]
    7a14:	8b010000 	add	x0, x0, x1
    7a18:	f9400001 	ldr	x1, [x0]
    7a1c:	17fffdf5 	b	71f0 <fwp_write+0x4dc>
    7a20:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7a24:	d2800042 	mov	x2, #0x2                   	// #2
    7a28:	912a2021 	add	x1, x1, #0xa88
    7a2c:	17fffed6 	b	7584 <fwp_write+0x870>
    7a30:	7101fcbf 	cmp	w5, #0x7f
    7a34:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7a38:	540000e9 	b.ls	7a54 <fwp_write+0xd40>  // b.plast
    7a3c:	aa1503e1 	mov	x1, x21
    7a40:	aa1403e0 	mov	x0, x20
    7a44:	d2800022 	mov	x2, #0x1                   	// #1
    7a48:	39001fe5 	strb	w5, [sp, #7]
    7a4c:	97ffee71 	bl	3410 <buf_put>
    7a50:	17ffffb4 	b	7920 <fwp_write+0xc0c>
    7a54:	d2800203 	mov	x3, #0x10                  	// #16
    7a58:	f0000004 	adrp	x4, a000 <__divti3+0xa0>
    7a5c:	aa0303e1 	mov	x1, x3
    7a60:	912c2084 	add	x4, x4, #0xb08
    7a64:	910123f6 	add	x22, sp, #0x48
    7a68:	52800042 	mov	w2, #0x2                   	// #2
    7a6c:	aa1603e0 	mov	x0, x22
    7a70:	97ffeb60 	bl	27f0 <__snprintf_chk@plt>
    7a74:	aa1603e0 	mov	x0, x22
    7a78:	97ffeb26 	bl	2710 <strlen@plt>
    7a7c:	aa1603e1 	mov	x1, x22
    7a80:	aa0003e2 	mov	x2, x0
    7a84:	aa1403e0 	mov	x0, x20
    7a88:	97ffee62 	bl	3410 <buf_put>
    7a8c:	17ffffa5 	b	7920 <fwp_write+0xc0c>
    7a90:	1e604100 	fmov	d0, d8
    7a94:	aa1503e0 	mov	x0, x21
    7a98:	52800221 	mov	w1, #0x11                  	// #17
    7a9c:	97ffef9e 	bl	3914 <fwp_format_g.constprop.0>
    7aa0:	17fffe43 	b	73ac <fwp_write+0x698>
    7aa4:	b9401040 	ldr	w0, [x2, #16]
    7aa8:	350003c0 	cbnz	w0, 7b20 <fwp_write+0xe0c>
    7aac:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ab0:	f947f400 	ldr	x0, [x0, #4072]
    7ab4:	f94127e2 	ldr	x2, [sp, #584]
    7ab8:	f9400001 	ldr	x1, [x0]
    7abc:	eb010042 	subs	x2, x2, x1
    7ac0:	d2800001 	mov	x1, #0x0                   	// #0
    7ac4:	54ffd721 	b.ne	75a8 <fwp_write+0x894>  // b.any
    7ac8:	f9413bf5 	ldr	x21, [sp, #624]
    7acc:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7ad0:	f9413ff6 	ldr	x22, [sp, #632]
    7ad4:	aa1403e0 	mov	x0, x20
    7ad8:	f94143f7 	ldr	x23, [sp, #640]
    7adc:	912d6021 	add	x1, x1, #0xb58
    7ae0:	f94147f8 	ldr	x24, [sp, #648]
    7ae4:	d2800042 	mov	x2, #0x2                   	// #2
    7ae8:	17fffd0f 	b	6f24 <fwp_write+0x210>
    7aec:	f0000001 	adrp	x1, a000 <__divti3+0xa0>
    7af0:	d2800042 	mov	x2, #0x2                   	// #2
    7af4:	912a4021 	add	x1, x1, #0xa90
    7af8:	17fffea3 	b	7584 <fwp_write+0x870>
    7afc:	f9400a63 	ldr	x3, [x19, #16]
    7b00:	8b030021 	add	x1, x1, x3
    7b04:	17ffff66 	b	789c <fwp_write+0xb88>
    7b08:	f9400a61 	ldr	x1, [x19, #16]
    7b0c:	8b0102a1 	add	x1, x21, x1
    7b10:	17fffdb4 	b	71e0 <fwp_write+0x4cc>
    7b14:	f9400a63 	ldr	x3, [x19, #16]
    7b18:	8b030021 	add	x1, x1, x3
    7b1c:	17ffff56 	b	7874 <fwp_write+0xb60>
    7b20:	b9404840 	ldr	w0, [x2, #72]
    7b24:	91001ff5 	add	x21, sp, #0x7
    7b28:	34ffa380 	cbz	w0, 6f98 <fwp_write+0x284>
    7b2c:	52800503 	mov	w3, #0x28                  	// #40
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	aa1503e1 	mov	x1, x21
    7b38:	d2800022 	mov	x2, #0x1                   	// #1
    7b3c:	39001fe3 	strb	w3, [sp, #7]
    7b40:	97ffee34 	bl	3410 <buf_put>
    7b44:	b9401380 	ldr	w0, [x28, #16]
    7b48:	52800038 	mov	w24, #0x1                   	// #1
    7b4c:	7100001f 	cmp	w0, #0x0
    7b50:	54ffa38c 	b.gt	6fc0 <fwp_write+0x2ac>
    7b54:	17fffd33 	b	7020 <fwp_write+0x30c>
    7b58:	f9014bf9 	str	x25, [sp, #656]
    7b5c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11a50>
    7b60:	f9014ffa 	str	x26, [sp, #664]
    7b64:	f9400676 	ldr	x22, [x19, #8]
    7b68:	910aa333 	add	x19, x25, #0x2a8
    7b6c:	91002273 	add	x19, x19, #0x8
    7b70:	937ffed8 	asr	x24, x22, #63
    7b74:	aa1802c0 	orr	x0, x22, x24
    7b78:	b5000320 	cbnz	x0, 7bdc <fwp_write+0xec8>
    7b7c:	110006b5 	add	w21, w21, #0x1
    7b80:	710016bf 	cmp	w21, #0x5
    7b84:	54ffffc1 	b.ne	7b7c <fwp_write+0xe68>  // b.any
    7b88:	b7f80578 	tbnz	x24, #63, 7c34 <fwp_write+0xf20>
    7b8c:	910023f3 	add	x19, sp, #0x8
    7b90:	aa1603e2 	mov	x2, x22
    7b94:	aa1303e0 	mov	x0, x19
    7b98:	d2800003 	mov	x3, #0x0                   	// #0
    7b9c:	97ffeca1 	bl	2e20 <fwp_fmt_u128>
    7ba0:	910123f5 	add	x21, sp, #0x48
    7ba4:	f0000003 	adrp	x3, a000 <__divti3+0xa0>
    7ba8:	aa1303e4 	mov	x4, x19
    7bac:	aa1503e0 	mov	x0, x21
    7bb0:	912d4063 	add	x3, x3, #0xb50
    7bb4:	d2804002 	mov	x2, #0x200                 	// #512
    7bb8:	52800041 	mov	w1, #0x2                   	// #2
    7bbc:	97ffead9 	bl	2720 <__sprintf_chk@plt>
    7bc0:	aa1503e0 	mov	x0, x21
    7bc4:	97ffead3 	bl	2710 <strlen@plt>
    7bc8:	aa1503e1 	mov	x1, x21
    7bcc:	aa0003e2 	mov	x2, x0
    7bd0:	aa1403e0 	mov	x0, x20
    7bd4:	97ffee0f 	bl	3410 <buf_put>
    7bd8:	17fffe47 	b	74f4 <fwp_write+0x7e0>
    7bdc:	f9400277 	ldr	x23, [x19]
    7be0:	aa1603e0 	mov	x0, x22
    7be4:	aa1803e1 	mov	x1, x24
    7be8:	aa1703e2 	mov	x2, x23
    7bec:	937ffefa 	asr	x26, x23, #63
    7bf0:	aa1a03e3 	mov	x3, x26
    7bf4:	940009bb 	bl	a2e0 <__modti3>
    7bf8:	aa010000 	orr	x0, x0, x1
    7bfc:	b40002c0 	cbz	x0, 7c54 <fwp_write+0xf40>
    7c00:	110006b5 	add	w21, w21, #0x1
    7c04:	91004273 	add	x19, x19, #0x10
    7c08:	710016bf 	cmp	w21, #0x5
    7c0c:	54fffe81 	b.ne	7bdc <fwp_write+0xec8>  // b.any
    7c10:	17ffffde 	b	7b88 <fwp_write+0xe74>
    7c14:	f9400a60 	ldr	x0, [x19, #16]
    7c18:	8b000021 	add	x1, x1, x0
    7c1c:	17fffd75 	b	71f0 <fwp_write+0x4dc>
    7c20:	528c29c0 	mov	w0, #0x614e                	// #24910
    7c24:	910123f5 	add	x21, sp, #0x48
    7c28:	72a009c0 	movk	w0, #0x4e, lsl #16
    7c2c:	b9004be0 	str	w0, [sp, #72]
    7c30:	17fffda2 	b	72b8 <fwp_write+0x5a4>
    7c34:	528005a1 	mov	w1, #0x2d                  	// #45
    7c38:	eb1603e2 	negs	x2, x22
    7c3c:	da1803e3 	ngc	x3, x24
    7c40:	910027e0 	add	x0, sp, #0x9
    7c44:	910023f3 	add	x19, sp, #0x8
    7c48:	390023e1 	strb	w1, [sp, #8]
    7c4c:	97ffec75 	bl	2e20 <fwp_fmt_u128>
    7c50:	17ffffd4 	b	7ba0 <fwp_write+0xe8c>
    7c54:	aa1703e2 	mov	x2, x23
    7c58:	aa1a03e3 	mov	x3, x26
    7c5c:	aa1603e0 	mov	x0, x22
    7c60:	aa1803e1 	mov	x1, x24
    7c64:	940008bf 	bl	9f60 <__divti3>
    7c68:	aa0003e2 	mov	x2, x0
    7c6c:	aa0103e3 	mov	x3, x1
    7c70:	b7f80201 	tbnz	x1, #63, 7cb0 <fwp_write+0xf9c>
    7c74:	910023f3 	add	x19, sp, #0x8
    7c78:	aa1303e0 	mov	x0, x19
    7c7c:	97ffec69 	bl	2e20 <fwp_fmt_u128>
    7c80:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7c84:	910aa339 	add	x25, x25, #0x2a8
    7c88:	910123f5 	add	x21, sp, #0x48
    7c8c:	aa1303e4 	mov	x4, x19
    7c90:	aa1503e0 	mov	x0, x21
    7c94:	f0000003 	adrp	x3, a000 <__divti3+0xa0>
    7c98:	f8616b25 	ldr	x5, [x25, x1]
    7c9c:	912d2063 	add	x3, x3, #0xb48
    7ca0:	d2804002 	mov	x2, #0x200                 	// #512
    7ca4:	52800041 	mov	w1, #0x2                   	// #2
    7ca8:	97ffea9e 	bl	2720 <__sprintf_chk@plt>
    7cac:	17ffffc5 	b	7bc0 <fwp_write+0xeac>
    7cb0:	528005a4 	mov	w4, #0x2d                  	// #45
    7cb4:	eb0003e2 	negs	x2, x0
    7cb8:	da0103e3 	ngc	x3, x1
    7cbc:	910027e0 	add	x0, sp, #0x9
    7cc0:	910023f3 	add	x19, sp, #0x8
    7cc4:	390023e4 	strb	w4, [sp, #8]
    7cc8:	97ffec56 	bl	2e20 <fwp_fmt_u128>
    7ccc:	17ffffed 	b	7c80 <fwp_write+0xf6c>
    7cd0:	f9013bf5 	str	x21, [sp, #624]
    7cd4:	f9013ff6 	str	x22, [sp, #632]
    7cd8:	f90143f7 	str	x23, [sp, #640]
    7cdc:	f90147f8 	str	x24, [sp, #648]
    7ce0:	f9014bf9 	str	x25, [sp, #656]
    7ce4:	f9014ffa 	str	x26, [sp, #664]
    7ce8:	f90153fb 	str	x27, [sp, #672]
    7cec:	f90157fc 	str	x28, [sp, #680]
    7cf0:	fd015be8 	str	d8, [sp, #688]
    7cf4:	fd015fe9 	str	d9, [sp, #696]
    7cf8:	97ffeae2 	bl	2880 <__stack_chk_fail@plt>
    7cfc:	d503201f 	nop

0000000000007d00 <fwp_main_thread>:
    7d00:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7d04:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    7d08:	91150001 	add	x1, x0, #0x540
    7d0c:	910003fd 	mov	x29, sp
    7d10:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7d14:	f947f400 	ldr	x0, [x0, #4072]
    7d18:	a9025bf5 	stp	x21, x22, [sp, #32]
    7d1c:	a90363f7 	stp	x23, x24, [sp, #48]
    7d20:	d10643ff 	sub	sp, sp, #0x190
    7d24:	b953a421 	ldr	w1, [x1, #5028]
    7d28:	f9400002 	ldr	x2, [x0]
    7d2c:	f900c7e2 	str	x2, [sp, #392]
    7d30:	d2800002 	mov	x2, #0x0                   	// #0
    7d34:	340023e1 	cbz	w1, 81b0 <fwp_main_thread+0x4b0>
    7d38:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    7d3c:	91150000 	add	x0, x0, #0x540
    7d40:	b953a800 	ldr	w0, [x0, #5032]
    7d44:	35002400 	cbnz	w0, 81c4 <fwp_main_thread+0x4c4>
    7d48:	9101c3e5 	add	x5, sp, #0x70
    7d4c:	b00000d8 	adrp	x24, 20000 <__data_start>
    7d50:	b00000c2 	adrp	x2, 20000 <__data_start>
    7d54:	9100c316 	add	x22, x24, #0x30
    7d58:	910d8042 	add	x2, x2, #0x360
    7d5c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    7d60:	d2a00024 	mov	x4, #0x10000               	// #65536
    7d64:	910223e0 	add	x0, sp, #0x88
    7d68:	d2800001 	mov	x1, #0x0                   	// #0
    7d6c:	f90003e0 	str	x0, [sp]
    7d70:	a9018ec5 	stp	x5, x3, [x22, #24]
    7d74:	f9000fe5 	str	x5, [sp, #24]
    7d78:	f90047e2 	str	x2, [sp, #136]
    7d7c:	b90093ff 	str	wzr, [sp, #144]
    7d80:	f9004fe4 	str	x4, [sp, #152]
    7d84:	97ffea57 	bl	26e0 <sigaltstack@plt>
    7d88:	a91a53f3 	stp	x19, x20, [sp, #416]
    7d8c:	35010d60 	cbnz	w0, 9f38 <fwp_main_thread+0x2238>
    7d90:	4f000400 	movi	v0.4s, #0x0
    7d94:	9103e3e0 	add	x0, sp, #0xf8
    7d98:	90ffffe1 	adrp	x1, 3000 <fwp_flush+0x10>
    7d9c:	9101c021 	add	x1, x1, #0x70
    7da0:	f9007be1 	str	x1, [sp, #240]
    7da4:	52800082 	mov	w2, #0x4                   	// #4
    7da8:	72a10002 	movk	w2, #0x800, lsl #16
    7dac:	9103c3f3 	add	x19, sp, #0xf0
    7db0:	3d802000 	str	q0, [x0, #128]
    7db4:	b9017be2 	str	w2, [sp, #376]
    7db8:	ad000000 	stp	q0, q0, [x0]
    7dbc:	ad010000 	stp	q0, q0, [x0, #32]
    7dc0:	ad020000 	stp	q0, q0, [x0, #64]
    7dc4:	ad030000 	stp	q0, q0, [x0, #96]
    7dc8:	97ffea9e 	bl	2840 <sigemptyset@plt>
    7dcc:	35010b60 	cbnz	w0, 9f38 <fwp_main_thread+0x2238>
    7dd0:	aa1303e1 	mov	x1, x19
    7dd4:	d2800002 	mov	x2, #0x0                   	// #0
    7dd8:	52800160 	mov	w0, #0xb                   	// #11
    7ddc:	97ffeab1 	bl	28a0 <sigaction@plt>
    7de0:	35010ac0 	cbnz	w0, 9f38 <fwp_main_thread+0x2238>
    7de4:	aa1303e1 	mov	x1, x19
    7de8:	d2800002 	mov	x2, #0x0                   	// #0
    7dec:	528000e0 	mov	w0, #0x7                   	// #7
    7df0:	97ffeaac 	bl	28a0 <sigaction@plt>
    7df4:	35010a20 	cbnz	w0, 9f38 <fwp_main_thread+0x2238>
    7df8:	b942f6c0 	ldr	w0, [x22, #756]
    7dfc:	34001ec0 	cbz	w0, 81d4 <fwp_main_thread+0x4d4>
    7e00:	9100c315 	add	x21, x24, #0x30
    7e04:	f9400ab3 	ldr	x19, [x21, #16]
    7e08:	b4000c73 	cbz	x19, 7f94 <fwp_main_thread+0x294>
    7e0c:	aa1303f4 	mov	x20, x19
    7e10:	91010277 	add	x23, x19, #0x40
    7e14:	a91d6bf9 	stp	x25, x26, [sp, #464]
    7e18:	52800036 	mov	w22, #0x1                   	// #1
    7e1c:	39414a79 	ldrb	w25, [x19, #82]
    7e20:	39014a76 	strb	w22, [x19, #82]
    7e24:	f9401660 	ldr	x0, [x19, #40]
    7e28:	b4000620 	cbz	x0, 7eec <fwp_main_thread+0x1ec>
    7e2c:	f9403261 	ldr	x1, [x19, #96]
    7e30:	39414660 	ldrb	w0, [x19, #81]
    7e34:	b4000ca1 	cbz	x1, 7fc8 <fwp_main_thread+0x2c8>
    7e38:	36000b60 	tbz	w0, #0, 7fa4 <fwp_main_thread+0x2a4>
    7e3c:	39414a82 	ldrb	w2, [x20, #82]
    7e40:	f9402260 	ldr	x0, [x19, #64]
    7e44:	37000ec2 	tbnz	w2, #0, 801c <fwp_main_thread+0x31c>
    7e48:	f9403281 	ldr	x1, [x20, #96]
    7e4c:	a911fe97 	stp	x23, xzr, [x20, #280]
    7e50:	f9009680 	str	x0, [x20, #296]
    7e54:	b4000040 	cbz	x0, 7e5c <fwp_main_thread+0x15c>
    7e58:	f9009014 	str	x20, [x0, #288]
    7e5c:	f9002274 	str	x20, [x19, #64]
    7e60:	b4000101 	cbz	x1, 7e80 <fwp_main_thread+0x180>
    7e64:	f94046a0 	ldr	x0, [x21, #136]
    7e68:	39015696 	strb	w22, [x20, #85]
    7e6c:	f9003681 	str	x1, [x20, #104]
    7e70:	a910829f 	stp	xzr, x0, [x20, #264]
    7e74:	b4000040 	cbz	x0, 7e7c <fwp_main_thread+0x17c>
    7e78:	f9008414 	str	x20, [x0, #264]
    7e7c:	f90046b4 	str	x20, [x21, #136]
    7e80:	39015a9f 	strb	wzr, [x20, #86]
    7e84:	97fff918 	bl	62e4 <fwp_block>
    7e88:	f9408e82 	ldr	x2, [x20, #280]
    7e8c:	b4000142 	cbz	x2, 7eb4 <fwp_main_thread+0x1b4>
    7e90:	a9520281 	ldp	x1, x0, [x20, #288]
    7e94:	b4000d01 	cbz	x1, 8034 <fwp_main_thread+0x334>
    7e98:	f9009420 	str	x0, [x1, #296]
    7e9c:	f9409680 	ldr	x0, [x20, #296]
    7ea0:	b4000040 	cbz	x0, 7ea8 <fwp_main_thread+0x1a8>
    7ea4:	f9009001 	str	x1, [x0, #288]
    7ea8:	91080280 	add	x0, x20, #0x200
    7eac:	f900969f 	str	xzr, [x20, #296]
    7eb0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    7eb4:	39415680 	ldrb	w0, [x20, #85]
    7eb8:	f9400aa2 	ldr	x2, [x21, #16]
    7ebc:	36000ac0 	tbz	w0, #0, 8014 <fwp_main_thread+0x314>
    7ec0:	a9508281 	ldp	x1, x0, [x20, #264]
    7ec4:	b4000bc1 	cbz	x1, 803c <fwp_main_thread+0x33c>
    7ec8:	f9008820 	str	x0, [x1, #272]
    7ecc:	b4000040 	cbz	x0, 7ed4 <fwp_main_thread+0x1d4>
    7ed0:	f9008401 	str	x1, [x0, #264]
    7ed4:	91080280 	add	x0, x20, #0x200
    7ed8:	3901569f 	strb	wzr, [x20, #85]
    7edc:	aa0203f4 	mov	x20, x2
    7ee0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    7ee4:	f9401660 	ldr	x0, [x19, #40]
    7ee8:	b5fffa20 	cbnz	x0, 7e2c <fwp_main_thread+0x12c>
    7eec:	9100c300 	add	x0, x24, #0x30
    7ef0:	39014a79 	strb	w25, [x19, #82]
    7ef4:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    7ef8:	f9416c00 	ldr	x0, [x0, #728]
    7efc:	b5000080 	cbnz	x0, 7f0c <fwp_main_thread+0x20c>
    7f00:	9100c313 	add	x19, x24, #0x30
    7f04:	f9417660 	ldr	x0, [x19, #744]
    7f08:	b400f440 	cbz	x0, 9d90 <fwp_main_thread+0x2090>
    7f0c:	9100c300 	add	x0, x24, #0x30
    7f10:	f9418801 	ldr	x1, [x0, #784]
    7f14:	b903081f 	str	wzr, [x0, #776]
    7f18:	eb14003f 	cmp	x1, x20
    7f1c:	5400f501 	b.ne	9dbc <fwp_main_thread+0x20bc>  // b.any
    7f20:	b40009d4 	cbz	x20, 8058 <fwp_main_thread+0x358>
    7f24:	9100c300 	add	x0, x24, #0x30
    7f28:	52800021 	mov	w1, #0x1                   	// #1
    7f2c:	39014a81 	strb	w1, [x20, #82]
    7f30:	f9415805 	ldr	x5, [x0, #688]
    7f34:	b4000925 	cbz	x5, 8058 <fwp_main_thread+0x358>
    7f38:	394140a0 	ldrb	w0, [x5, #80]
    7f3c:	37000060 	tbnz	w0, #0, 7f48 <fwp_main_thread+0x248>
    7f40:	aa0503e0 	mov	x0, x5
    7f44:	97ffed4b 	bl	3470 <fwp_cancel_tree.part.0>
    7f48:	f9409ca5 	ldr	x5, [x5, #312]
    7f4c:	b5ffff65 	cbnz	x5, 7f38 <fwp_main_thread+0x238>
    7f50:	9100c313 	add	x19, x24, #0x30
    7f54:	52800035 	mov	w21, #0x1                   	// #1
    7f58:	f9402a80 	ldr	x0, [x20, #80]
    7f5c:	f2001c1f 	tst	x0, #0xff000000ff
    7f60:	540000e1 	b.ne	7f7c <fwp_main_thread+0x27c>  // b.any
    7f64:	f9401660 	ldr	x0, [x19, #40]
    7f68:	39015295 	strb	w21, [x20, #84]
    7f6c:	f900829f 	str	xzr, [x20, #256]
    7f70:	b40006a0 	cbz	x0, 8044 <fwp_main_thread+0x344>
    7f74:	f9008014 	str	x20, [x0, #256]
    7f78:	f9001674 	str	x20, [x19, #40]
    7f7c:	97fff8da 	bl	62e4 <fwp_block>
    7f80:	97fff86c 	bl	6130 <fwp_free_zombie>
    7f84:	f9415a60 	ldr	x0, [x19, #688]
    7f88:	b4000680 	cbz	x0, 8058 <fwp_main_thread+0x358>
    7f8c:	f9418a74 	ldr	x20, [x19, #784]
    7f90:	17fffff2 	b	7f58 <fwp_main_thread+0x258>
    7f94:	f9416ea0 	ldr	x0, [x21, #728]
    7f98:	b50005a0 	cbnz	x0, 804c <fwp_main_thread+0x34c>
    7f9c:	d2800014 	mov	x20, #0x0                   	// #0
    7fa0:	17ffffd8 	b	7f00 <fwp_main_thread+0x200>
    7fa4:	97ffedd7 	bl	3700 <fwp_now_ns>
    7fa8:	f9403261 	ldr	x1, [x19, #96]
    7fac:	eb01001f 	cmp	x0, x1
    7fb0:	540000ab 	b.lt	7fc4 <fwp_main_thread+0x2c4>  // b.tstop
    7fb4:	39414260 	ldrb	w0, [x19, #80]
    7fb8:	37000060 	tbnz	w0, #0, 7fc4 <fwp_main_thread+0x2c4>
    7fbc:	aa1303e0 	mov	x0, x19
    7fc0:	97ffed2c 	bl	3470 <fwp_cancel_tree.part.0>
    7fc4:	39414660 	ldrb	w0, [x19, #81]
    7fc8:	39414a82 	ldrb	w2, [x20, #82]
    7fcc:	3707f3a0 	tbnz	w0, #0, 7e40 <fwp_main_thread+0x140>
    7fd0:	f9403261 	ldr	x1, [x19, #96]
    7fd4:	370001c2 	tbnz	w2, #0, 800c <fwp_main_thread+0x30c>
    7fd8:	f9403280 	ldr	x0, [x20, #96]
    7fdc:	b4000180 	cbz	x0, 800c <fwp_main_thread+0x30c>
    7fe0:	b4000061 	cbz	x1, 7fec <fwp_main_thread+0x2ec>
    7fe4:	eb01001f 	cmp	x0, x1
    7fe8:	9a81d000 	csel	x0, x0, x1, le
    7fec:	f9402261 	ldr	x1, [x19, #64]
    7ff0:	a911fe97 	stp	x23, xzr, [x20, #280]
    7ff4:	f9009681 	str	x1, [x20, #296]
    7ff8:	b400ec21 	cbz	x1, 9d7c <fwp_main_thread+0x207c>
    7ffc:	f9009034 	str	x20, [x1, #288]
    8000:	aa0003e1 	mov	x1, x0
    8004:	f9002274 	str	x20, [x19, #64]
    8008:	17ffff97 	b	7e64 <fwp_main_thread+0x164>
    800c:	f9402260 	ldr	x0, [x19, #64]
    8010:	17ffff8f 	b	7e4c <fwp_main_thread+0x14c>
    8014:	aa0203f4 	mov	x20, x2
    8018:	17ffff83 	b	7e24 <fwp_main_thread+0x124>
    801c:	a911fe97 	stp	x23, xzr, [x20, #280]
    8020:	f9009680 	str	x0, [x20, #296]
    8024:	b4000040 	cbz	x0, 802c <fwp_main_thread+0x32c>
    8028:	f9009014 	str	x20, [x0, #288]
    802c:	f9002274 	str	x20, [x19, #64]
    8030:	17ffff94 	b	7e80 <fwp_main_thread+0x180>
    8034:	f9000040 	str	x0, [x2]
    8038:	17ffff9a 	b	7ea0 <fwp_main_thread+0x1a0>
    803c:	f90046a0 	str	x0, [x21, #136]
    8040:	17ffffa3 	b	7ecc <fwp_main_thread+0x1cc>
    8044:	f9001a74 	str	x20, [x19, #48]
    8048:	17ffffcc 	b	7f78 <fwp_main_thread+0x278>
    804c:	f9418aa0 	ldr	x0, [x21, #784]
    8050:	b9030abf 	str	wzr, [x21, #776]
    8054:	b500eb40 	cbnz	x0, 9dbc <fwp_main_thread+0x20bc>
    8058:	9100c314 	add	x20, x24, #0x30
    805c:	97fff835 	bl	6130 <fwp_free_zombie>
    8060:	f9401a80 	ldr	x0, [x20, #48]
    8064:	b500eac0 	cbnz	x0, 9dbc <fwp_main_thread+0x20bc>
    8068:	f9404680 	ldr	x0, [x20, #136]
    806c:	b500ea80 	cbnz	x0, 9dbc <fwp_main_thread+0x20bc>
    8070:	b940aa80 	ldr	w0, [x20, #168]
    8074:	340001c0 	cbz	w0, 80ac <fwp_main_thread+0x3ac>
    8078:	93407c15 	sxtw	x21, w0
    807c:	51000400 	sub	w0, w0, #0x1
    8080:	d1000ab5 	sub	x21, x21, #0x2
    8084:	9102c296 	add	x22, x20, #0xb0
    8088:	cb2042b5 	sub	x21, x21, w0, uxtw
    808c:	93407c13 	sxtw	x19, w0
    8090:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    8094:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8098:	b900aa93 	str	w19, [x20, #168]
    809c:	d1000673 	sub	x19, x19, #0x1
    80a0:	97ffea40 	bl	29a0 <munmap@plt>
    80a4:	eb15027f 	cmp	x19, x21
    80a8:	54ffff41 	b.ne	8090 <fwp_main_thread+0x390>  // b.any
    80ac:	900000d3 	adrp	x19, 20000 <__data_start>
    80b0:	91004260 	add	x0, x19, #0x10
    80b4:	b9400800 	ldr	w0, [x0, #8]
    80b8:	37f80040 	tbnz	w0, #31, 80c0 <fwp_main_thread+0x3c0>
    80bc:	97ffe9f5 	bl	2890 <close@plt>
    80c0:	9100c300 	add	x0, x24, #0x30
    80c4:	91004261 	add	x1, x19, #0x10
    80c8:	12800002 	mov	w2, #0xffffffff            	// #-1
    80cc:	d2800013 	mov	x19, #0x0                   	// #0
    80d0:	f9418c15 	ldr	x21, [x0, #792]
    80d4:	b9000822 	str	w2, [x1, #8]
    80d8:	f9419014 	ldr	x20, [x0, #800]
    80dc:	b4000175 	cbz	x21, 8108 <fwp_main_thread+0x408>
    80e0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    80e4:	b40000c0 	cbz	x0, 80fc <fwp_main_thread+0x3fc>
    80e8:	f9400001 	ldr	x1, [x0]
    80ec:	b500e681 	cbnz	x1, 9dbc <fwp_main_thread+0x20bc>
    80f0:	f9400401 	ldr	x1, [x0, #8]
    80f4:	b500e641 	cbnz	x1, 9dbc <fwp_main_thread+0x20bc>
    80f8:	97fff1be 	bl	47f0 <fwp_mem_free>
    80fc:	91000673 	add	x19, x19, #0x1
    8100:	eb15027f 	cmp	x19, x21
    8104:	54fffee1 	b.ne	80e0 <fwp_main_thread+0x3e0>  // b.any
    8108:	aa1403e0 	mov	x0, x20
    810c:	97fff1b9 	bl	47f0 <fwp_mem_free>
    8110:	9100c300 	add	x0, x24, #0x30
    8114:	f9418813 	ldr	x19, [x0, #784]
    8118:	f9018c1f 	str	xzr, [x0, #792]
    811c:	f901901f 	str	xzr, [x0, #800]
    8120:	b40001f3 	cbz	x19, 815c <fwp_main_thread+0x45c>
    8124:	f9401661 	ldr	x1, [x19, #40]
    8128:	b500e4a1 	cbnz	x1, 9dbc <fwp_main_thread+0x20bc>
    812c:	f9405661 	ldr	x1, [x19, #168]
    8130:	b500e461 	cbnz	x1, 9dbc <fwp_main_thread+0x20bc>
    8134:	f9416c01 	ldr	x1, [x0, #728]
    8138:	b500e421 	cbnz	x1, 9dbc <fwp_main_thread+0x20bc>
    813c:	f9417400 	ldr	x0, [x0, #744]
    8140:	b500e3e0 	cbnz	x0, 9dbc <fwp_main_thread+0x20bc>
    8144:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8148:	90000140 	adrp	x0, 30000 <alt.5+0xfca0>
    814c:	910d8000 	add	x0, x0, #0x360
    8150:	97ffe9c0 	bl	2850 <memset@plt>
    8154:	aa1303e0 	mov	x0, x19
    8158:	97fff1a6 	bl	47f0 <fwp_mem_free>
    815c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8160:	f947ec00 	ldr	x0, [x0, #4056]
    8164:	9100c318 	add	x24, x24, #0x30
    8168:	f9400000 	ldr	x0, [x0]
    816c:	f9000b1f 	str	xzr, [x24, #16]
    8170:	f9018b1f 	str	xzr, [x24, #784]
    8174:	97ffea0f 	bl	29b0 <fflush@plt>
    8178:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    817c:	f947f400 	ldr	x0, [x0, #4072]
    8180:	f940c7e2 	ldr	x2, [sp, #392]
    8184:	f9400001 	ldr	x1, [x0]
    8188:	eb010042 	subs	x2, x2, x1
    818c:	d2800001 	mov	x1, #0x0                   	// #0
    8190:	5400ec01 	b.ne	9f10 <fwp_main_thread+0x2210>  // b.any
    8194:	a95a53f3 	ldp	x19, x20, [sp, #416]
    8198:	910643ff 	add	sp, sp, #0x190
    819c:	d2800000 	mov	x0, #0x0                   	// #0
    81a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    81a4:	a94363f7 	ldp	x23, x24, [sp, #48]
    81a8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    81ac:	d65f03c0 	ret
    81b0:	97ffef35 	bl	3e84 <fwp_heap_init>
    81b4:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    81b8:	91150000 	add	x0, x0, #0x540
    81bc:	b953a800 	ldr	w0, [x0, #5032]
    81c0:	34ffdc40 	cbz	w0, 7d48 <fwp_main_thread+0x48>
    81c4:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    81c8:	91348000 	add	x0, x0, #0xd20
    81cc:	94000921 	bl	a650 <atexit>
    81d0:	17fffede 	b	7d48 <fwp_main_thread+0x48>
    81d4:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    81d8:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    81dc:	f94162c2 	ldr	x2, [x22, #704]
    81e0:	913d4021 	add	x1, x1, #0xf50
    81e4:	a91e73fb 	stp	x27, x28, [sp, #480]
    81e8:	9115001b 	add	x27, x0, #0x540
    81ec:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    81f0:	911f0000 	add	x0, x0, #0x7c0
    81f4:	a90707e2 	stp	x2, x1, [sp, #112]
    81f8:	d2804017 	mov	x23, #0x200                 	// #512
    81fc:	f94003e1 	ldr	x1, [sp]
    8200:	a90983ff 	stp	xzr, x0, [sp, #152]
    8204:	d2800014 	mov	x20, #0x0                   	// #0
    8208:	f9400fe0 	ldr	x0, [sp, #24]
    820c:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8210:	52800035 	mov	w21, #0x1                   	// #1
    8214:	fd00fbe8 	str	d8, [sp, #496]
    8218:	f9000bff 	str	xzr, [sp, #16]
    821c:	f90043e1 	str	x1, [sp, #128]
    8220:	f90047ff 	str	xzr, [sp, #136]
    8224:	f90162c0 	str	x0, [x22, #704]
    8228:	f9400be2 	ldr	x2, [sp, #16]
    822c:	f10006f9 	subs	x25, x23, #0x1
    8230:	aa1303e1 	mov	x1, x19
    8234:	da1f029a 	sbc	x26, x20, xzr
    8238:	52800020 	mov	w0, #0x1                   	// #1
    823c:	f9004bf9 	str	x25, [sp, #144]
    8240:	a90f0bf9 	stp	x25, x2, [sp, #240]
    8244:	97fff2d0 	bl	4d84 <fwp_data.part.0.constprop.0>
    8248:	aa0003e2 	mov	x2, x0
    824c:	f949db61 	ldr	x1, [x27, #5040]
    8250:	f9000be2 	str	x2, [sp, #16]
    8254:	f949ef60 	ldr	x0, [x27, #5080]
    8258:	cb010041 	sub	x1, x2, x1
    825c:	aa1903f7 	mov	x23, x25
    8260:	aa1a03f4 	mov	x20, x26
    8264:	eb00403f 	cmp	x1, x0, lsl #16
    8268:	54000302 	b.cs	82c8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    826c:	d350fc20 	lsr	x0, x1, #16
    8270:	f949ff63 	ldr	x3, [x27, #5112]
    8274:	8b000800 	add	x0, x0, x0, lsl #2
    8278:	d37df002 	lsl	x2, x0, #3
    827c:	8b020060 	add	x0, x3, x2
    8280:	f9401016 	ldr	x22, [x0, #32]
    8284:	b4000236 	cbz	x22, 82c8 <fwp_main_thread+0x5c8>
    8288:	38626862 	ldrb	w2, [x3, x2]
    828c:	7100085f 	cmp	w2, #0x2
    8290:	54005c00 	b.eq	8e10 <fwp_main_thread+0x1110>  // b.none
    8294:	7100045f 	cmp	w2, #0x1
    8298:	54000181 	b.ne	82c8 <fwp_main_thread+0x5c8>  // b.any
    829c:	29430002 	ldp	w2, w0, [x0, #24]
    82a0:	92403c21 	and	x1, x1, #0xffff
    82a4:	9b027c21 	mul	x1, x1, x2
    82a8:	d360fc21 	lsr	x1, x1, #32
    82ac:	eb00003f 	cmp	x1, x0
    82b0:	540000c2 	b.cs	82c8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    82b4:	8b0102d6 	add	x22, x22, x1
    82b8:	394002c0 	ldrb	w0, [x22]
    82bc:	7103fc1f 	cmp	w0, #0xff
    82c0:	54005b20 	b.eq	8e24 <fwp_main_thread+0x1124>  // b.none
    82c4:	390002d5 	strb	w21, [x22]
    82c8:	f9400be0 	ldr	x0, [sp, #16]
    82cc:	f90047e0 	str	x0, [sp, #136]
    82d0:	aa1a0320 	orr	x0, x25, x26
    82d4:	b5fffaa0 	cbnz	x0, 8228 <fwp_main_thread+0x528>
    82d8:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x980>
    82dc:	9100c302 	add	x2, x24, #0x30
    82e0:	f9403bf5 	ldr	x21, [sp, #112]
    82e4:	910303e1 	add	x1, sp, #0xc0
    82e8:	3dc0d800 	ldr	q0, [x0, #864]
    82ec:	52800020 	mov	w0, #0x1                   	// #1
    82f0:	f9016055 	str	x21, [x2, #704]
    82f4:	3d8033e0 	str	q0, [sp, #192]
    82f8:	97fff2a3 	bl	4d84 <fwp_data.part.0.constprop.0>
    82fc:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    8300:	91150022 	add	x2, x1, #0x540
    8304:	aa0003f6 	mov	x22, x0
    8308:	f949d841 	ldr	x1, [x2, #5040]
    830c:	f949ec40 	ldr	x0, [x2, #5080]
    8310:	cb0102c1 	sub	x1, x22, x1
    8314:	eb00403f 	cmp	x1, x0, lsl #16
    8318:	54000322 	b.cs	837c <fwp_main_thread+0x67c>  // b.hs, b.nlast
    831c:	d350fc20 	lsr	x0, x1, #16
    8320:	f949fc43 	ldr	x3, [x2, #5112]
    8324:	8b000800 	add	x0, x0, x0, lsl #2
    8328:	d37df002 	lsl	x2, x0, #3
    832c:	8b020060 	add	x0, x3, x2
    8330:	f9401014 	ldr	x20, [x0, #32]
    8334:	b4000254 	cbz	x20, 837c <fwp_main_thread+0x67c>
    8338:	38626862 	ldrb	w2, [x3, x2]
    833c:	7100085f 	cmp	w2, #0x2
    8340:	5400d180 	b.eq	9d70 <fwp_main_thread+0x2070>  // b.none
    8344:	7100045f 	cmp	w2, #0x1
    8348:	540001a1 	b.ne	837c <fwp_main_thread+0x67c>  // b.any
    834c:	29430002 	ldp	w2, w0, [x0, #24]
    8350:	92403c21 	and	x1, x1, #0xffff
    8354:	9b027c21 	mul	x1, x1, x2
    8358:	d360fc21 	lsr	x1, x1, #32
    835c:	eb00003f 	cmp	x1, x0
    8360:	540000e2 	b.cs	837c <fwp_main_thread+0x67c>  // b.hs, b.nlast
    8364:	8b010294 	add	x20, x20, x1
    8368:	39400280 	ldrb	w0, [x20]
    836c:	7103fc1f 	cmp	w0, #0xff
    8370:	5400d900 	b.eq	9e90 <fwp_main_thread+0x2190>  // b.none
    8374:	52800020 	mov	w0, #0x1                   	// #1
    8378:	39000280 	strb	w0, [x20]
    837c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8380:	910383e1 	add	x1, sp, #0xe0
    8384:	52800020 	mov	w0, #0x1                   	// #1
    8388:	a90e5be2 	stp	x2, x22, [sp, #224]
    838c:	97fff27e 	bl	4d84 <fwp_data.part.0.constprop.0>
    8390:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    8394:	91150022 	add	x2, x1, #0x540
    8398:	aa0003f6 	mov	x22, x0
    839c:	f949d841 	ldr	x1, [x2, #5040]
    83a0:	f949ec40 	ldr	x0, [x2, #5080]
    83a4:	cb0102c1 	sub	x1, x22, x1
    83a8:	eb00403f 	cmp	x1, x0, lsl #16
    83ac:	54000322 	b.cs	8410 <fwp_main_thread+0x710>  // b.hs, b.nlast
    83b0:	d350fc20 	lsr	x0, x1, #16
    83b4:	f949fc43 	ldr	x3, [x2, #5112]
    83b8:	8b000800 	add	x0, x0, x0, lsl #2
    83bc:	d37df002 	lsl	x2, x0, #3
    83c0:	8b020060 	add	x0, x3, x2
    83c4:	f9401014 	ldr	x20, [x0, #32]
    83c8:	b4000254 	cbz	x20, 8410 <fwp_main_thread+0x710>
    83cc:	38626862 	ldrb	w2, [x3, x2]
    83d0:	7100085f 	cmp	w2, #0x2
    83d4:	5400cc80 	b.eq	9d64 <fwp_main_thread+0x2064>  // b.none
    83d8:	7100045f 	cmp	w2, #0x1
    83dc:	540001a1 	b.ne	8410 <fwp_main_thread+0x710>  // b.any
    83e0:	29430002 	ldp	w2, w0, [x0, #24]
    83e4:	92403c21 	and	x1, x1, #0xffff
    83e8:	9b027c21 	mul	x1, x1, x2
    83ec:	d360fc21 	lsr	x1, x1, #32
    83f0:	eb00003f 	cmp	x1, x0
    83f4:	540000e2 	b.cs	8410 <fwp_main_thread+0x710>  // b.hs, b.nlast
    83f8:	8b010294 	add	x20, x20, x1
    83fc:	39400280 	ldrb	w0, [x20]
    8400:	7103fc1f 	cmp	w0, #0xff
    8404:	5400d4c0 	b.eq	9e9c <fwp_main_thread+0x219c>  // b.none
    8408:	52800020 	mov	w0, #0x1                   	// #1
    840c:	39000280 	strb	w0, [x20]
    8410:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8414:	910343e1 	add	x1, sp, #0xd0
    8418:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    841c:	52800020 	mov	w0, #0x1                   	// #1
    8420:	a90d5be2 	stp	x2, x22, [sp, #208]
    8424:	97fff258 	bl	4d84 <fwp_data.part.0.constprop.0>
    8428:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    842c:	91150022 	add	x2, x1, #0x540
    8430:	aa0003f4 	mov	x20, x0
    8434:	f949d841 	ldr	x1, [x2, #5040]
    8438:	f949ec40 	ldr	x0, [x2, #5080]
    843c:	cb010281 	sub	x1, x20, x1
    8440:	eb00403f 	cmp	x1, x0, lsl #16
    8444:	54000322 	b.cs	84a8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    8448:	d350fc20 	lsr	x0, x1, #16
    844c:	f949fc43 	ldr	x3, [x2, #5112]
    8450:	8b000800 	add	x0, x0, x0, lsl #2
    8454:	d37df002 	lsl	x2, x0, #3
    8458:	8b020060 	add	x0, x3, x2
    845c:	f9401016 	ldr	x22, [x0, #32]
    8460:	b4000256 	cbz	x22, 84a8 <fwp_main_thread+0x7a8>
    8464:	38626862 	ldrb	w2, [x3, x2]
    8468:	7100085f 	cmp	w2, #0x2
    846c:	5400c760 	b.eq	9d58 <fwp_main_thread+0x2058>  // b.none
    8470:	7100045f 	cmp	w2, #0x1
    8474:	540001a1 	b.ne	84a8 <fwp_main_thread+0x7a8>  // b.any
    8478:	29430002 	ldp	w2, w0, [x0, #24]
    847c:	92403c21 	and	x1, x1, #0xffff
    8480:	9b027c21 	mul	x1, x1, x2
    8484:	d360fc21 	lsr	x1, x1, #32
    8488:	eb00003f 	cmp	x1, x0
    848c:	540000e2 	b.cs	84a8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    8490:	8b0102d6 	add	x22, x22, x1
    8494:	394002c0 	ldrb	w0, [x22]
    8498:	7103fc1f 	cmp	w0, #0xff
    849c:	5400d180 	b.eq	9ecc <fwp_main_thread+0x21cc>  // b.none
    84a0:	52800020 	mov	w0, #0x1                   	// #1
    84a4:	390002c0 	strb	w0, [x22]
    84a8:	f9400be0 	ldr	x0, [sp, #16]
    84ac:	b400b5a0 	cbz	x0, 9b60 <fwp_main_thread+0x1e60>
    84b0:	900000c0 	adrp	x0, 20000 <__data_start>
    84b4:	91004000 	add	x0, x0, #0x10
    84b8:	f9001fe0 	str	x0, [sp, #56]
    84bc:	910143e0 	add	x0, sp, #0x50
    84c0:	f90013e0 	str	x0, [sp, #32]
    84c4:	910163e0 	add	x0, sp, #0x58
    84c8:	f90017e0 	str	x0, [sp, #40]
    84cc:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    84d0:	9115001c 	add	x28, x0, #0x540
    84d4:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x980>
    84d8:	f9400be1 	ldr	x1, [sp, #16]
    84dc:	f90027e1 	str	x1, [sp, #72]
    84e0:	fd41b808 	ldr	d8, [x0, #880]
    84e4:	f949ef86 	ldr	x6, [x28, #5080]
    84e8:	f949db82 	ldr	x2, [x28, #5040]
    84ec:	d370bcc6 	lsl	x6, x6, #16
    84f0:	cb020285 	sub	x5, x20, x2
    84f4:	eb0600bf 	cmp	x5, x6
    84f8:	540003a2 	b.cs	856c <fwp_main_thread+0x86c>  // b.hs, b.nlast
    84fc:	d350fca0 	lsr	x0, x5, #16
    8500:	f949ff87 	ldr	x7, [x28, #5112]
    8504:	8b000800 	add	x0, x0, x0, lsl #2
    8508:	d37df001 	lsl	x1, x0, #3
    850c:	8b0100e3 	add	x3, x7, x1
    8510:	f9401060 	ldr	x0, [x3, #32]
    8514:	b40002c0 	cbz	x0, 856c <fwp_main_thread+0x86c>
    8518:	386168e1 	ldrb	w1, [x7, x1]
    851c:	7100083f 	cmp	w1, #0x2
    8520:	5400b3e0 	b.eq	9b9c <fwp_main_thread+0x1e9c>  // b.none
    8524:	7100043f 	cmp	w1, #0x1
    8528:	54000221 	b.ne	856c <fwp_main_thread+0x86c>  // b.any
    852c:	29430c67 	ldp	w7, w3, [x3, #24]
    8530:	92403ca1 	and	x1, x5, #0xffff
    8534:	9b077c21 	mul	x1, x1, x7
    8538:	d360fc21 	lsr	x1, x1, #32
    853c:	eb03003f 	cmp	x1, x3
    8540:	54000162 	b.cs	856c <fwp_main_thread+0x86c>  // b.hs, b.nlast
    8544:	8b010000 	add	x0, x0, x1
    8548:	39400001 	ldrb	w1, [x0]
    854c:	34000101 	cbz	w1, 856c <fwp_main_thread+0x86c>
    8550:	7103f43f 	cmp	w1, #0xfd
    8554:	5400c628 	b.hi	9e18 <fwp_main_thread+0x2118>  // b.pmore
    8558:	11000421 	add	w1, w1, #0x1
    855c:	39000001 	strb	w1, [x0]
    8560:	f949ef86 	ldr	x6, [x28, #5080]
    8564:	f949db82 	ldr	x2, [x28, #5040]
    8568:	d370bcc6 	lsl	x6, x6, #16
    856c:	f9401fe1 	ldr	x1, [sp, #56]
    8570:	9100c300 	add	x0, x24, #0x30
    8574:	cb020023 	sub	x3, x1, x2
    8578:	b0ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x15c>
    857c:	91324021 	add	x1, x1, #0xc90
    8580:	a90587f5 	stp	x21, x1, [sp, #88]
    8584:	12800002 	mov	w2, #0xffffffff            	// #-1
    8588:	f94013e1 	ldr	x1, [sp, #32]
    858c:	f90037e1 	str	x1, [sp, #104]
    8590:	f94017e1 	ldr	x1, [sp, #40]
    8594:	b90053e2 	str	w2, [sp, #80]
    8598:	f9016001 	str	x1, [x0, #704]
    859c:	eb0300df 	cmp	x6, x3
    85a0:	54000749 	b.ls	8688 <fwp_main_thread+0x988>  // b.plast
    85a4:	d350fc60 	lsr	x0, x3, #16
    85a8:	f949ff85 	ldr	x5, [x28, #5112]
    85ac:	8b000800 	add	x0, x0, x0, lsl #2
    85b0:	d37df002 	lsl	x2, x0, #3
    85b4:	8b0200a1 	add	x1, x5, x2
    85b8:	f9401035 	ldr	x21, [x1, #32]
    85bc:	b4000675 	cbz	x21, 8688 <fwp_main_thread+0x988>
    85c0:	386268a0 	ldrb	w0, [x5, x2]
    85c4:	7100081f 	cmp	w0, #0x2
    85c8:	5400a040 	b.eq	99d0 <fwp_main_thread+0x1cd0>  // b.none
    85cc:	7100041f 	cmp	w0, #0x1
    85d0:	540005c1 	b.ne	8688 <fwp_main_thread+0x988>  // b.any
    85d4:	29430825 	ldp	w5, w2, [x1, #24]
    85d8:	92403c60 	and	x0, x3, #0xffff
    85dc:	9b057c00 	mul	x0, x0, x5
    85e0:	d360fc00 	lsr	x0, x0, #32
    85e4:	eb02001f 	cmp	x0, x2
    85e8:	54000282 	b.cs	8638 <fwp_main_thread+0x938>  // b.hs, b.nlast
    85ec:	8b0002a0 	add	x0, x21, x0
    85f0:	39400002 	ldrb	w2, [x0]
    85f4:	34000222 	cbz	w2, 8638 <fwp_main_thread+0x938>
    85f8:	7103f45f 	cmp	w2, #0xfd
    85fc:	5400b7c8 	b.hi	9cf4 <fwp_main_thread+0x1ff4>  // b.pmore
    8600:	11000442 	add	w2, w2, #0x1
    8604:	39000002 	strb	w2, [x0]
    8608:	f9401fe1 	ldr	x1, [sp, #56]
    860c:	f949db82 	ldr	x2, [x28, #5040]
    8610:	f949ef80 	ldr	x0, [x28, #5080]
    8614:	cb020023 	sub	x3, x1, x2
    8618:	eb00407f 	cmp	x3, x0, lsl #16
    861c:	54000362 	b.cs	8688 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8620:	f949ff80 	ldr	x0, [x28, #5112]
    8624:	d350fc61 	lsr	x1, x3, #16
    8628:	8b010821 	add	x1, x1, x1, lsl #2
    862c:	8b010c01 	add	x1, x0, x1, lsl #3
    8630:	f9401035 	ldr	x21, [x1, #32]
    8634:	b40002b5 	cbz	x21, 8688 <fwp_main_thread+0x988>
    8638:	39400020 	ldrb	w0, [x1]
    863c:	7100081f 	cmp	w0, #0x2
    8640:	54009c20 	b.eq	99c4 <fwp_main_thread+0x1cc4>  // b.none
    8644:	7100041f 	cmp	w0, #0x1
    8648:	54000201 	b.ne	8688 <fwp_main_thread+0x988>  // b.any
    864c:	29430025 	ldp	w5, w0, [x1, #24]
    8650:	92403c62 	and	x2, x3, #0xffff
    8654:	9b057c41 	mul	x1, x2, x5
    8658:	d360fc21 	lsr	x1, x1, #32
    865c:	eb00003f 	cmp	x1, x0
    8660:	54000142 	b.cs	8688 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8664:	8b0102b5 	add	x21, x21, x1
    8668:	394002a1 	ldrb	w1, [x21]
    866c:	340000e1 	cbz	w1, 8688 <fwp_main_thread+0x988>
    8670:	7100043f 	cmp	w1, #0x1
    8674:	540084a0 	b.eq	9708 <fwp_main_thread+0x1a08>  // b.none
    8678:	7103fc3f 	cmp	w1, #0xff
    867c:	5400b400 	b.eq	9cfc <fwp_main_thread+0x1ffc>  // b.none
    8680:	51000421 	sub	w1, w1, #0x1
    8684:	390002a1 	strb	w1, [x21]
    8688:	b4008514 	cbz	x20, 9728 <fwp_main_thread+0x1a28>
    868c:	aa1403e0 	mov	x0, x20
    8690:	d2800001 	mov	x1, #0x0                   	// #0
    8694:	d503201f 	nop
    8698:	f9400800 	ldr	x0, [x0, #16]
    869c:	91000421 	add	x1, x1, #0x1
    86a0:	b5ffffc0 	cbnz	x0, 8698 <fwp_main_thread+0x998>
    86a4:	aa0103f7 	mov	x23, x1
    86a8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    86ac:	eb00003f 	cmp	x1, x0
    86b0:	5400c3e8 	b.hi	9f2c <fwp_main_thread+0x222c>  // b.pmore
    86b4:	9100c315 	add	x21, x24, #0x30
    86b8:	b942faa0 	ldr	w0, [x21, #760]
    86bc:	340083e0 	cbz	w0, 9738 <fwp_main_thread+0x1a38>
    86c0:	9100c300 	add	x0, x24, #0x30
    86c4:	f9402015 	ldr	x21, [x0, #64]
    86c8:	f9404c16 	ldr	x22, [x0, #152]
    86cc:	eb1502df 	cmp	x22, x21
    86d0:	54007e2a 	b.ge	9694 <fwp_main_thread+0x1994>  // b.tcont
    86d4:	f9401b01 	ldr	x1, [x24, #48]
    86d8:	8b1606c0 	add	x0, x22, x22, lsl #1
    86dc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    86e0:	8b000ac0 	add	x0, x22, x0, lsl #2
    86e4:	8b000c20 	add	x0, x1, x0, lsl #3
    86e8:	b9400401 	ldr	w1, [x0, #4]
    86ec:	35000081 	cbnz	w1, 86fc <fwp_main_thread+0x9fc>
    86f0:	b9400001 	ldr	w1, [x0]
    86f4:	6b02003f 	cmp	w1, w2
    86f8:	54007ce9 	b.ls	9694 <fwp_main_thread+0x1994>  // b.plast
    86fc:	910006d6 	add	x22, x22, #0x1
    8700:	9101a000 	add	x0, x0, #0x68
    8704:	eb1502df 	cmp	x22, x21
    8708:	54ffff01 	b.ne	86e8 <fwp_main_thread+0x9e8>  // b.any
    870c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8710:	eb0002bf 	cmp	x21, x0
    8714:	5400c06c 	b.gt	9f20 <fwp_main_thread+0x2220>
    8718:	9100c300 	add	x0, x24, #0x30
    871c:	f9401b19 	ldr	x25, [x24, #48]
    8720:	f9404800 	ldr	x0, [x0, #144]
    8724:	eb15001f 	cmp	x0, x21
    8728:	54000201 	b.ne	8768 <fwp_main_thread+0xa68>  // b.any
    872c:	b4009fd5 	cbz	x21, 9b24 <fwp_main_thread+0x1e24>
    8730:	d37ffabb 	lsl	x27, x21, #1
    8734:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8738:	eb00037f 	cmp	x27, x0
    873c:	9a80d37b 	csel	x27, x27, x0, le
    8740:	8b1b0761 	add	x1, x27, x27, lsl #1
    8744:	8b010b61 	add	x1, x27, x1, lsl #2
    8748:	d37df021 	lsl	x1, x1, #3
    874c:	aa1903e0 	mov	x0, x25
    8750:	97ffe848 	bl	2870 <realloc@plt>
    8754:	aa0003f9 	mov	x25, x0
    8758:	b4003920 	cbz	x0, 8e7c <fwp_main_thread+0x117c>
    875c:	9100c300 	add	x0, x24, #0x30
    8760:	f9001b19 	str	x25, [x24, #48]
    8764:	f900481b 	str	x27, [x0, #144]
    8768:	9100c301 	add	x1, x24, #0x30
    876c:	8b1506a0 	add	x0, x21, x21, lsl #1
    8770:	4f000400 	movi	v0.4s, #0x0
    8774:	910006a2 	add	x2, x21, #0x1
    8778:	8b000aa0 	add	x0, x21, x0, lsl #2
    877c:	f9002022 	str	x2, [x1, #64]
    8780:	8b1606c1 	add	x1, x22, x22, lsl #1
    8784:	8b000f20 	add	x0, x25, x0, lsl #3
    8788:	8b010ac1 	add	x1, x22, x1, lsl #2
    878c:	8b010f3b 	add	x27, x25, x1, lsl #3
    8790:	ad000000 	stp	q0, q0, [x0]
    8794:	ad010000 	stp	q0, q0, [x0, #32]
    8798:	ad020000 	stp	q0, q0, [x0, #64]
    879c:	f900301f 	str	xzr, [x0, #96]
    87a0:	d0000000 	adrp	x0, a000 <__divti3+0xa0>
    87a4:	f900337f 	str	xzr, [x27, #96]
    87a8:	9122e000 	add	x0, x0, #0x8b8
    87ac:	97ffe899 	bl	2a10 <getenv@plt>
    87b0:	b4007880 	cbz	x0, 96c0 <fwp_main_thread+0x19c0>
    87b4:	39400001 	ldrb	w1, [x0]
    87b8:	7100c03f 	cmp	w1, #0x30
    87bc:	54007821 	b.ne	96c0 <fwp_main_thread+0x19c0>  // b.any
    87c0:	39400400 	ldrb	w0, [x0, #1]
    87c4:	350077e0 	cbnz	w0, 96c0 <fwp_main_thread+0x19c0>
    87c8:	9100c302 	add	x2, x24, #0x30
    87cc:	2f000400 	mvni	v0.2s, #0x0
    87d0:	b9400375 	ldr	w21, [x27]
    87d4:	52800023 	mov	w3, #0x1                   	// #1
    87d8:	910006c0 	add	x0, x22, #0x1
    87dc:	a900df77 	stp	x23, x23, [x27, #8]
    87e0:	0b0302b5 	add	w21, w21, w3
    87e4:	f9416041 	ldr	x1, [x2, #704]
    87e8:	29000f75 	stp	w21, w3, [x27]
    87ec:	f9002b7f 	str	xzr, [x27, #80]
    87f0:	f9004c40 	str	x0, [x2, #152]
    87f4:	fd002f60 	str	d0, [x27, #88]
    87f8:	b400b761 	cbz	x1, 9ee4 <fwp_main_thread+0x21e4>
    87fc:	b0ffffe2 	adrp	x2, 5000 <fwp_p_ad_push+0x15c>
    8800:	91324043 	add	x3, x2, #0xc90
    8804:	14000003 	b	8810 <fwp_main_thread+0xb10>
    8808:	f9400021 	ldr	x1, [x1]
    880c:	b400b6c1 	cbz	x1, 9ee4 <fwp_main_thread+0x21e4>
    8810:	f9400422 	ldr	x2, [x1, #8]
    8814:	eb03005f 	cmp	x2, x3
    8818:	54ffff81 	b.ne	8808 <fwp_main_thread+0xb08>  // b.any
    881c:	f9400821 	ldr	x1, [x1, #16]
    8820:	2a1603e3 	mov	w3, w22
    8824:	b9400022 	ldr	w2, [x1]
    8828:	f9002b61 	str	x1, [x27, #80]
    882c:	b9005f62 	str	w2, [x27, #92]
    8830:	37f80082 	tbnz	w2, #31, 8840 <fwp_main_thread+0xb40>
    8834:	52800d05 	mov	w5, #0x68                  	// #104
    8838:	9b256442 	smaddl	x2, w2, w5, x25
    883c:	b9005856 	str	w22, [x2, #88]
    8840:	d3707eb5 	ubfiz	x21, x21, #16, #32
    8844:	b9000023 	str	w3, [x1]
    8848:	aa0002a0 	orr	x0, x21, x0
    884c:	f90007e0 	str	x0, [sp, #8]
    8850:	d2800002 	mov	x2, #0x0                   	// #0
    8854:	aa1403e0 	mov	x0, x20
    8858:	b4007e54 	cbz	x20, 9820 <fwp_main_thread+0x1b20>
    885c:	d503201f 	nop
    8860:	f9400800 	ldr	x0, [x0, #16]
    8864:	91000442 	add	x2, x2, #0x1
    8868:	b5ffffc0 	cbnz	x0, 8860 <fwp_main_thread+0xb60>
    886c:	aa1403e1 	mov	x1, x20
    8870:	f9400821 	ldr	x1, [x1, #16]
    8874:	91000400 	add	x0, x0, #0x1
    8878:	b5ffffc1 	cbnz	x1, 8870 <fwp_main_thread+0xb70>
    887c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8880:	eb01001f 	cmp	x0, x1
    8884:	5400b188 	b.hi	9eb4 <fwp_main_thread+0x21b4>  // b.pmore
    8888:	f100005f 	cmp	x2, #0x0
    888c:	54007cad 	b.le	9820 <fwp_main_thread+0x1b20>
    8890:	eb00005f 	cmp	x2, x0
    8894:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8898:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    889c:	eb0102df 	cmp	x22, x1
    88a0:	5400b0a8 	b.hi	9eb4 <fwp_main_thread+0x21b4>  // b.pmore
    88a4:	d37ffad7 	lsl	x23, x22, #1
    88a8:	52800041 	mov	w1, #0x2                   	// #2
    88ac:	910006e0 	add	x0, x23, #0x1
    88b0:	d37df000 	lsl	x0, x0, #3
    88b4:	97fff0ef 	bl	4c70 <fwp_heap_alloc>
    88b8:	f9000017 	str	x23, [x0]
    88bc:	aa0003f9 	mov	x25, x0
    88c0:	aa0003fb 	mov	x27, x0
    88c4:	f949db81 	ldr	x1, [x28, #5040]
    88c8:	f949ef80 	ldr	x0, [x28, #5080]
    88cc:	cb010321 	sub	x1, x25, x1
    88d0:	eb00403f 	cmp	x1, x0, lsl #16
    88d4:	54007c82 	b.cs	9864 <fwp_main_thread+0x1b64>  // b.hs, b.nlast
    88d8:	d350fc20 	lsr	x0, x1, #16
    88dc:	f949ff83 	ldr	x3, [x28, #5112]
    88e0:	8b000800 	add	x0, x0, x0, lsl #2
    88e4:	d37df002 	lsl	x2, x0, #3
    88e8:	8b020060 	add	x0, x3, x2
    88ec:	f9401017 	ldr	x23, [x0, #32]
    88f0:	b4000257 	cbz	x23, 8938 <fwp_main_thread+0xc38>
    88f4:	38626862 	ldrb	w2, [x3, x2]
    88f8:	7100085f 	cmp	w2, #0x2
    88fc:	54008540 	b.eq	99a4 <fwp_main_thread+0x1ca4>  // b.none
    8900:	7100045f 	cmp	w2, #0x1
    8904:	540001a1 	b.ne	8938 <fwp_main_thread+0xc38>  // b.any
    8908:	29430002 	ldp	w2, w0, [x0, #24]
    890c:	92403c21 	and	x1, x1, #0xffff
    8910:	9b027c21 	mul	x1, x1, x2
    8914:	d360fc21 	lsr	x1, x1, #32
    8918:	eb00003f 	cmp	x1, x0
    891c:	540000e2 	b.cs	8938 <fwp_main_thread+0xc38>  // b.hs, b.nlast
    8920:	8b0102f7 	add	x23, x23, x1
    8924:	394002e0 	ldrb	w0, [x23]
    8928:	7103fc1f 	cmp	w0, #0xff
    892c:	54008460 	b.eq	99b8 <fwp_main_thread+0x1cb8>  // b.none
    8930:	52800020 	mov	w0, #0x1                   	// #1
    8934:	390002e0 	strb	w0, [x23]
    8938:	b4000256 	cbz	x22, 8980 <fwp_main_thread+0xc80>
    893c:	f94007e0 	ldr	x0, [sp, #8]
    8940:	aa1403e1 	mov	x1, x20
    8944:	f9400686 	ldr	x6, [x20, #8]
    8948:	91002322 	add	x2, x25, #0x8
    894c:	d3607c05 	lsl	x5, x0, #32
    8950:	d2800000 	mov	x0, #0x0                   	// #0
    8954:	aa0503e3 	mov	x3, x5
    8958:	14000005 	b	896c <fwp_main_thread+0xc6c>
    895c:	f9400426 	ldr	x6, [x1, #8]
    8960:	ab050003 	adds	x3, x0, x5
    8964:	91004042 	add	x2, x2, #0x10
    8968:	5400af46 	b.vs	9f50 <fwp_main_thread+0x2250>
    896c:	a9000c46 	stp	x6, x3, [x2]
    8970:	91000400 	add	x0, x0, #0x1
    8974:	f9400821 	ldr	x1, [x1, #16]
    8978:	eb0002df 	cmp	x22, x0
    897c:	54ffff08 	b.hi	895c <fwp_main_thread+0xc5c>  // b.pmore
    8980:	f9400320 	ldr	x0, [x25]
    8984:	f100041f 	cmp	x0, #0x1
    8988:	54007709 	b.ls	9868 <fwp_main_thread+0x1b68>  // b.plast
    898c:	d341fc00 	lsr	x0, x0, #1
    8990:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8994:	d1000417 	sub	x23, x0, #0x1
    8998:	eb0102ff 	cmp	x23, x1
    899c:	5400a8c8 	b.hi	9eb4 <fwp_main_thread+0x21b4>  // b.pmore
    89a0:	b4007657 	cbz	x23, 9868 <fwp_main_thread+0x1b68>
    89a4:	d1002321 	sub	x1, x25, #0x8
    89a8:	91002335 	add	x21, x25, #0x8
    89ac:	8b001036 	add	x22, x1, x0, lsl #4
    89b0:	f94006a0 	ldr	x0, [x21, #8]
    89b4:	f9400ea1 	ldr	x1, [x21, #24]
    89b8:	fd4002a0 	ldr	d0, [x21]
    89bc:	fd400aa1 	ldr	d1, [x21, #16]
    89c0:	97fff1ec 	bl	5170 <w120>
    89c4:	a90006a0 	stp	x0, x1, [x21]
    89c8:	910042b5 	add	x21, x21, #0x10
    89cc:	eb1602bf 	cmp	x21, x22
    89d0:	54ffff01 	b.ne	89b0 <fwp_main_thread+0xcb0>  // b.any
    89d4:	aa1903f6 	mov	x22, x25
    89d8:	d37ffaf7 	lsl	x23, x23, #1
    89dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    89e0:	d2800015 	mov	x21, #0x0                   	// #0
    89e4:	f80106d7 	str	x23, [x22], #16
    89e8:	f8757ac2 	ldr	x2, [x22, x21, lsl #3]
    89ec:	aa1a03e0 	mov	x0, x26
    89f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    89f4:	91000ab5 	add	x21, x21, #0x2
    89f8:	aa0303e1 	mov	x1, x3
    89fc:	97fff12a 	bl	4ea4 <fwp_p_ad_push>
    8a00:	aa0003fa 	mov	x26, x0
    8a04:	eb1702bf 	cmp	x21, x23
    8a08:	54ffff03 	b.cc	89e8 <fwp_main_thread+0xce8>  // b.lo, b.ul, b.last
    8a0c:	f949db81 	ldr	x1, [x28, #5040]
    8a10:	f949ef80 	ldr	x0, [x28, #5080]
    8a14:	cb010321 	sub	x1, x25, x1
    8a18:	eb00403f 	cmp	x1, x0, lsl #16
    8a1c:	540003a2 	b.cs	8a90 <fwp_main_thread+0xd90>  // b.hs, b.nlast
    8a20:	d350fc20 	lsr	x0, x1, #16
    8a24:	f949ff86 	ldr	x6, [x28, #5112]
    8a28:	8b000800 	add	x0, x0, x0, lsl #2
    8a2c:	d37df000 	lsl	x0, x0, #3
    8a30:	8b0000c2 	add	x2, x6, x0
    8a34:	f9401056 	ldr	x22, [x2, #32]
    8a38:	b40002d6 	cbz	x22, 8a90 <fwp_main_thread+0xd90>
    8a3c:	386068c0 	ldrb	w0, [x6, x0]
    8a40:	7100081f 	cmp	w0, #0x2
    8a44:	54007180 	b.eq	9874 <fwp_main_thread+0x1b74>  // b.none
    8a48:	7100041f 	cmp	w0, #0x1
    8a4c:	54000221 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    8a50:	29430045 	ldp	w5, w0, [x2, #24]
    8a54:	92403c21 	and	x1, x1, #0xffff
    8a58:	9b057c21 	mul	x1, x1, x5
    8a5c:	d360fc21 	lsr	x1, x1, #32
    8a60:	eb00003f 	cmp	x1, x0
    8a64:	54000162 	b.cs	8a90 <fwp_main_thread+0xd90>  // b.hs, b.nlast
    8a68:	8b0102d6 	add	x22, x22, x1
    8a6c:	394002c0 	ldrb	w0, [x22]
    8a70:	34000100 	cbz	w0, 8a90 <fwp_main_thread+0xd90>
    8a74:	7100041f 	cmp	w0, #0x1
    8a78:	540021a0 	b.eq	8eac <fwp_main_thread+0x11ac>  // b.none
    8a7c:	7103fc1f 	cmp	w0, #0xff
    8a80:	54008940 	b.eq	9ba8 <fwp_main_thread+0x1ea8>  // b.none
    8a84:	51000400 	sub	w0, w0, #0x1
    8a88:	390002c0 	strb	w0, [x22]
    8a8c:	d503201f 	nop
    8a90:	b9800bf5 	ldrsw	x21, [sp, #8]
    8a94:	aa1503e0 	mov	x0, x21
    8a98:	97ffeb86 	bl	38b0 <fwp_tape_of>
    8a9c:	f9403001 	ldr	x1, [x0, #96]
    8aa0:	aa0003e7 	mov	x7, x0
    8aa4:	b500a261 	cbnz	x1, 9ef0 <fwp_main_thread+0x21f0>
    8aa8:	97ffe93a 	bl	2f90 <fwp_tape_unlink_scope>
    8aac:	b90004ff 	str	wzr, [x7, #4]
    8ab0:	b94000e1 	ldr	w1, [x7]
    8ab4:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8ab8:	a940a0f7 	ldp	x23, x8, [x7, #8]
    8abc:	a941e4e9 	ldp	x9, x25, [x7, #24]
    8ac0:	a94290fb 	ldp	x27, x4, [x7, #40]
    8ac4:	a943d8e6 	ldp	x6, x22, [x7, #56]
    8ac8:	f94024e2 	ldr	x2, [x7, #72]
    8acc:	6b00003f 	cmp	w1, w0
    8ad0:	54000108 	b.hi	8af0 <fwp_main_thread+0xdf0>  // b.pmore
    8ad4:	9100c301 	add	x1, x24, #0x30
    8ad8:	92403ea0 	and	x0, x21, #0xffff
    8adc:	d1000400 	sub	x0, x0, #0x1
    8ae0:	f9404c2a 	ldr	x10, [x1, #152]
    8ae4:	eb0a001f 	cmp	x0, x10
    8ae8:	5400004a 	b.ge	8af0 <fwp_main_thread+0xdf0>  // b.tcont
    8aec:	f9004c20 	str	x0, [x1, #152]
    8af0:	4f000400 	movi	v0.4s, #0x0
    8af4:	9100c300 	add	x0, x24, #0x30
    8af8:	90ffffe1 	adrp	x1, 4000 <fwp_heap_init+0x17c>
    8afc:	91040021 	add	x1, x1, #0x100
    8b00:	f9000cff 	str	xzr, [x7, #24]
    8b04:	f941600a 	ldr	x10, [x0, #704]
    8b08:	3c8080e0 	stur	q0, [x7, #8]
    8b0c:	ad0100e0 	stp	q0, q0, [x7, #32]
    8b10:	a9047cff 	stp	xzr, xzr, [x7, #64]
    8b14:	a90707ea 	stp	x10, x1, [sp, #112]
    8b18:	f94003e1 	ldr	x1, [sp]
    8b1c:	f90043e1 	str	x1, [sp, #128]
    8b20:	f9400fe1 	ldr	x1, [sp, #24]
    8b24:	a908eff9 	stp	x25, x27, [sp, #136]
    8b28:	a9099be4 	stp	x4, x6, [sp, #152]
    8b2c:	a90aa7f6 	stp	x22, x9, [sp, #168]
    8b30:	f9005fe2 	str	x2, [sp, #184]
    8b34:	f9016001 	str	x1, [x0, #704]
    8b38:	b7f8755a 	tbnz	x26, #63, 99e0 <fwp_main_thread+0x1ce0>
    8b3c:	eb9a82bf 	cmp	x21, x26, asr #32
    8b40:	54009661 	b.ne	9e0c <fwp_main_thread+0x210c>  // b.any
    8b44:	92407f41 	and	x1, x26, #0xffffffff
    8b48:	eb3a411f 	cmp	x8, w26, uxtw
    8b4c:	540095ad 	b.le	9e00 <fwp_main_thread+0x2100>
    8b50:	eb17003f 	cmp	x1, x23
    8b54:	9a81b6f5 	csinc	x21, x23, x1, lt	// lt = tstop
    8b58:	eb15005f 	cmp	x2, x21
    8b5c:	540017ca 	b.ge	8e54 <fwp_main_thread+0x1154>  // b.tcont
    8b60:	f100005f 	cmp	x2, #0x0
    8b64:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    8b68:	14000005 	b	8b7c <fwp_main_thread+0xe7c>
    8b6c:	d37ff841 	lsl	x1, x2, #1
    8b70:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8b74:	eb00005f 	cmp	x2, x0
    8b78:	9a95d022 	csel	x2, x1, x21, le
    8b7c:	eb15005f 	cmp	x2, x21
    8b80:	54ffff6b 	b.lt	8b6c <fwp_main_thread+0xe6c>  // b.tstop
    8b84:	f9001be4 	str	x4, [sp, #48]
    8b88:	f90023e6 	str	x6, [sp, #64]
    8b8c:	b4007a96 	cbz	x22, 9adc <fwp_main_thread+0x1ddc>
    8b90:	aa1603e0 	mov	x0, x22
    8b94:	d37df041 	lsl	x1, x2, #3
    8b98:	f90007e2 	str	x2, [sp, #8]
    8b9c:	97ffe735 	bl	2870 <realloc@plt>
    8ba0:	f94007e2 	ldr	x2, [sp, #8]
    8ba4:	aa0003f6 	mov	x22, x0
    8ba8:	f9401be4 	ldr	x4, [sp, #48]
    8bac:	f94023e6 	ldr	x6, [sp, #64]
    8bb0:	b4009a76 	cbz	x22, 9efc <fwp_main_thread+0x21fc>
    8bb4:	f90057f6 	str	x22, [sp, #168]
    8bb8:	f9005fe2 	str	x2, [sp, #184]
    8bbc:	b50013b5 	cbnz	x21, 8e30 <fwp_main_thread+0x1130>
    8bc0:	b7f800da 	tbnz	x26, #63, 8bd8 <fwp_main_thread+0xed8>
    8bc4:	92407f43 	and	x3, x26, #0xffffffff
    8bc8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8bcc:	fc637ac0 	ldr	d0, [x22, x3, lsl #3]
    8bd0:	1e612800 	fadd	d0, d0, d1
    8bd4:	fc237ac0 	str	d0, [x22, x3, lsl #3]
    8bd8:	d10006a1 	sub	x1, x21, #0x1
    8bdc:	d10006e7 	sub	x7, x23, #0x1
    8be0:	eb0102ff 	cmp	x23, x1
    8be4:	540003ac 	b.gt	8c58 <fwp_main_thread+0xf58>
    8be8:	fc617ac0 	ldr	d0, [x22, x1, lsl #3]
    8bec:	1e602008 	fcmp	d0, #0.0
    8bf0:	540002e0 	b.eq	8c4c <fwp_main_thread+0xf4c>  // b.none
    8bf4:	cb170be0 	neg	x0, x23, lsl #2
    8bf8:	cb1703e3 	neg	x3, x23
    8bfc:	8b000322 	add	x2, x25, x0
    8c00:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8c04:	37f80102 	tbnz	w2, #31, 8c24 <fwp_main_thread+0xf24>
    8c08:	8b030c88 	add	x8, x4, x3, lsl #3
    8c0c:	93407c42 	sxtw	x2, w2
    8c10:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8c14:	fc627ac1 	ldr	d1, [x22, x2, lsl #3]
    8c18:	1e620802 	fmul	d2, d0, d2
    8c1c:	1e622821 	fadd	d1, d1, d2
    8c20:	fc227ac1 	str	d1, [x22, x2, lsl #3]
    8c24:	8b000360 	add	x0, x27, x0
    8c28:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8c2c:	37f80100 	tbnz	w0, #31, 8c4c <fwp_main_thread+0xf4c>
    8c30:	8b030cc3 	add	x3, x6, x3, lsl #3
    8c34:	93407c00 	sxtw	x0, w0
    8c38:	fc617862 	ldr	d2, [x3, x1, lsl #3]
    8c3c:	fc607ac1 	ldr	d1, [x22, x0, lsl #3]
    8c40:	1e620800 	fmul	d0, d0, d2
    8c44:	1e602820 	fadd	d0, d1, d0
    8c48:	fc207ac0 	str	d0, [x22, x0, lsl #3]
    8c4c:	d1000421 	sub	x1, x1, #0x1
    8c50:	eb0100ff 	cmp	x7, x1
    8c54:	54fffca1 	b.ne	8be8 <fwp_main_thread+0xee8>  // b.any
    8c58:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8c5c:	eb0002ff 	cmp	x23, x0
    8c60:	54009528 	b.hi	9f04 <fwp_main_thread+0x2204>  // b.pmore
    8c64:	910006e0 	add	x0, x23, #0x1
    8c68:	52800041 	mov	w1, #0x2                   	// #2
    8c6c:	d37df000 	lsl	x0, x0, #3
    8c70:	97fff000 	bl	4c70 <fwp_heap_alloc>
    8c74:	aa0003e2 	mov	x2, x0
    8c78:	aa0003f9 	mov	x25, x0
    8c7c:	d2800001 	mov	x1, #0x0                   	// #0
    8c80:	f8008457 	str	x23, [x2], #8
    8c84:	b40000d7 	cbz	x23, 8c9c <fwp_main_thread+0xf9c>
    8c88:	f8617ac0 	ldr	x0, [x22, x1, lsl #3]
    8c8c:	f8217840 	str	x0, [x2, x1, lsl #3]
    8c90:	91000421 	add	x1, x1, #0x1
    8c94:	eb0102ff 	cmp	x23, x1
    8c98:	54ffff81 	b.ne	8c88 <fwp_main_thread+0xf88>  // b.any
    8c9c:	f94003e0 	ldr	x0, [sp]
    8ca0:	9100c301 	add	x1, x24, #0x30
    8ca4:	f9403bf6 	ldr	x22, [sp, #112]
    8ca8:	f9016036 	str	x22, [x1, #704]
    8cac:	97ffed15 	bl	4100 <fwp_tape_buffers_release>
    8cb0:	f949db81 	ldr	x1, [x28, #5040]
    8cb4:	f949ef80 	ldr	x0, [x28, #5080]
    8cb8:	cb010321 	sub	x1, x25, x1
    8cbc:	eb00403f 	cmp	x1, x0, lsl #16
    8cc0:	54000322 	b.cs	8d24 <fwp_main_thread+0x1024>  // b.hs, b.nlast
    8cc4:	d350fc20 	lsr	x0, x1, #16
    8cc8:	f949ff83 	ldr	x3, [x28, #5112]
    8ccc:	8b000800 	add	x0, x0, x0, lsl #2
    8cd0:	d37df002 	lsl	x2, x0, #3
    8cd4:	8b020060 	add	x0, x3, x2
    8cd8:	f9401015 	ldr	x21, [x0, #32]
    8cdc:	b4000255 	cbz	x21, 8d24 <fwp_main_thread+0x1024>
    8ce0:	38626862 	ldrb	w2, [x3, x2]
    8ce4:	7100085f 	cmp	w2, #0x2
    8ce8:	54006800 	b.eq	99e8 <fwp_main_thread+0x1ce8>  // b.none
    8cec:	7100045f 	cmp	w2, #0x1
    8cf0:	540001a1 	b.ne	8d24 <fwp_main_thread+0x1024>  // b.any
    8cf4:	29430002 	ldp	w2, w0, [x0, #24]
    8cf8:	92403c21 	and	x1, x1, #0xffff
    8cfc:	9b027c21 	mul	x1, x1, x2
    8d00:	d360fc21 	lsr	x1, x1, #32
    8d04:	eb00003f 	cmp	x1, x0
    8d08:	540000e2 	b.cs	8d24 <fwp_main_thread+0x1024>  // b.hs, b.nlast
    8d0c:	8b0102b5 	add	x21, x21, x1
    8d10:	394002a0 	ldrb	w0, [x21]
    8d14:	7103fc1f 	cmp	w0, #0xff
    8d18:	54006720 	b.eq	99fc <fwp_main_thread+0x1cfc>  // b.none
    8d1c:	52800020 	mov	w0, #0x1                   	// #1
    8d20:	390002a0 	strb	w0, [x21]
    8d24:	f94017e0 	ldr	x0, [sp, #40]
    8d28:	eb0002df 	cmp	x22, x0
    8d2c:	540084e1 	b.ne	9dc8 <fwp_main_thread+0x20c8>  // b.any
    8d30:	f94013e0 	ldr	x0, [sp, #32]
    8d34:	9100c301 	add	x1, x24, #0x30
    8d38:	f9402fe2 	ldr	x2, [sp, #88]
    8d3c:	f9016022 	str	x2, [x1, #704]
    8d40:	97fff3d4 	bl	5c90 <fwp_tape_scope_release>
    8d44:	f9400320 	ldr	x0, [x25]
    8d48:	9240f816 	and	x22, x0, #0x7fffffffffffffff
    8d4c:	b7f850a0 	tbnz	x0, #63, 9760 <fwp_main_thread+0x1a60>
    8d50:	f949db80 	ldr	x0, [x28, #5040]
    8d54:	f949ef81 	ldr	x1, [x28, #5080]
    8d58:	cb000320 	sub	x0, x25, x0
    8d5c:	eb01401f 	cmp	x0, x1, lsl #16
    8d60:	54005002 	b.cs	9760 <fwp_main_thread+0x1a60>  // b.hs, b.nlast
    8d64:	d350fc01 	lsr	x1, x0, #16
    8d68:	f949ff85 	ldr	x5, [x28, #5112]
    8d6c:	8b010821 	add	x1, x1, x1, lsl #2
    8d70:	d37df021 	lsl	x1, x1, #3
    8d74:	8b0100a3 	add	x3, x5, x1
    8d78:	f9401062 	ldr	x2, [x3, #32]
    8d7c:	b4004f22 	cbz	x2, 9760 <fwp_main_thread+0x1a60>
    8d80:	386168a1 	ldrb	w1, [x5, x1]
    8d84:	7100083f 	cmp	w1, #0x2
    8d88:	54004e60 	b.eq	9754 <fwp_main_thread+0x1a54>  // b.none
    8d8c:	7100043f 	cmp	w1, #0x1
    8d90:	54004e81 	b.ne	9760 <fwp_main_thread+0x1a60>  // b.any
    8d94:	29430465 	ldp	w5, w1, [x3, #24]
    8d98:	92403c00 	and	x0, x0, #0xffff
    8d9c:	9b057c00 	mul	x0, x0, x5
    8da0:	d360fc00 	lsr	x0, x0, #32
    8da4:	eb01001f 	cmp	x0, x1
    8da8:	54004dc2 	b.cs	9760 <fwp_main_thread+0x1a60>  // b.hs, b.nlast
    8dac:	8b000042 	add	x2, x2, x0
    8db0:	39400040 	ldrb	w0, [x2]
    8db4:	7100041f 	cmp	w0, #0x1
    8db8:	54004d41 	b.ne	9760 <fwp_main_thread+0x1a60>  // b.any
    8dbc:	aa1903e5 	mov	x5, x25
    8dc0:	aa1903f5 	mov	x21, x25
    8dc4:	d2800000 	mov	x0, #0x0                   	// #0
    8dc8:	910022a3 	add	x3, x21, #0x8
    8dcc:	91002327 	add	x7, x25, #0x8
    8dd0:	d2800001 	mov	x1, #0x0                   	// #0
    8dd4:	b5000156 	cbnz	x22, 8dfc <fwp_main_thread+0x10fc>
    8dd8:	14000056 	b	8f30 <fwp_main_thread+0x1230>
    8ddc:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8de0:	f94000a2 	ldr	x2, [x5]
    8de4:	1e600900 	fmul	d0, d8, d0
    8de8:	b7f886c2 	tbnz	x2, #63, 9ec0 <fwp_main_thread+0x21c0>
    8dec:	91000421 	add	x1, x1, #0x1
    8df0:	fc008460 	str	d0, [x3], #8
    8df4:	eb0102df 	cmp	x22, x1
    8df8:	540009c0 	b.eq	8f30 <fwp_main_thread+0x1230>  // b.none
    8dfc:	f9400326 	ldr	x6, [x25]
    8e00:	aa0703e2 	mov	x2, x7
    8e04:	b6fffec6 	tbz	x6, #63, 8ddc <fwp_main_thread+0x10dc>
    8e08:	f9400b22 	ldr	x2, [x25, #16]
    8e0c:	17fffff4 	b	8ddc <fwp_main_thread+0x10dc>
    8e10:	72003c3f 	tst	w1, #0xffff
    8e14:	54ffa5a1 	b.ne	82c8 <fwp_main_thread+0x5c8>  // b.any
    8e18:	394002c0 	ldrb	w0, [x22]
    8e1c:	7103fc1f 	cmp	w0, #0xff
    8e20:	54ffa521 	b.ne	82c4 <fwp_main_thread+0x5c4>  // b.any
    8e24:	aa1603e0 	mov	x0, x22
    8e28:	97ffedd2 	bl	4570 <fwp_rc_forget_slot>
    8e2c:	17fffd26 	b	82c4 <fwp_main_thread+0x5c4>
    8e30:	d37df2a2 	lsl	x2, x21, #3
    8e34:	aa1603e0 	mov	x0, x22
    8e38:	52800001 	mov	w1, #0x0                   	// #0
    8e3c:	f90007e4 	str	x4, [sp, #8]
    8e40:	f9001be6 	str	x6, [sp, #48]
    8e44:	97ffe683 	bl	2850 <memset@plt>
    8e48:	f94007e4 	ldr	x4, [sp, #8]
    8e4c:	f9401be6 	ldr	x6, [sp, #48]
    8e50:	17ffff5c 	b	8bc0 <fwp_main_thread+0xec0>
    8e54:	f10002df 	cmp	x22, #0x0
    8e58:	1a9f17e0 	cset	w0, eq	// eq = none
    8e5c:	f10002bf 	cmp	x21, #0x0
    8e60:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8e64:	54ffeac0 	b.eq	8bbc <fwp_main_thread+0xebc>  // b.none
    8e68:	f94003e0 	ldr	x0, [sp]
    8e6c:	9100c318 	add	x24, x24, #0x30
    8e70:	f9403be1 	ldr	x1, [sp, #112]
    8e74:	f9016301 	str	x1, [x24, #704]
    8e78:	97ffeca2 	bl	4100 <fwp_tape_buffers_release>
    8e7c:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8e80:	f947e863 	ldr	x3, [x3, #4048]
    8e84:	d2800262 	mov	x2, #0x13                  	// #19
    8e88:	d2800021 	mov	x1, #0x1                   	// #1
    8e8c:	d0000000 	adrp	x0, a000 <__divti3+0xa0>
    8e90:	911a2000 	add	x0, x0, #0x688
    8e94:	f9400063 	ldr	x3, [x3]
    8e98:	97ffe6ba 	bl	2980 <fwrite@plt>
    8e9c:	d2800000 	mov	x0, #0x0                   	// #0
    8ea0:	97ffe6c4 	bl	29b0 <fflush@plt>
    8ea4:	52800cc0 	mov	w0, #0x66                  	// #102
    8ea8:	97ffe6d2 	bl	29f0 <_Exit@plt>
    8eac:	f9400367 	ldr	x7, [x27]
    8eb0:	aa1b03e0 	mov	x0, x27
    8eb4:	f949ef85 	ldr	x5, [x28, #5080]
    8eb8:	f949db81 	ldr	x1, [x28, #5040]
    8ebc:	d370bca5 	lsl	x5, x5, #16
    8ec0:	cb010362 	sub	x2, x27, x1
    8ec4:	b7f84e47 	tbnz	x7, #63, 988c <fwp_main_thread+0x1b8c>
    8ec8:	eb05005f 	cmp	x2, x5
    8ecc:	54ffde22 	b.cs	8a90 <fwp_main_thread+0xd90>  // b.hs, b.nlast
    8ed0:	d350fc40 	lsr	x0, x2, #16
    8ed4:	8b000800 	add	x0, x0, x0, lsl #2
    8ed8:	d37df000 	lsl	x0, x0, #3
    8edc:	8b0000c5 	add	x5, x6, x0
    8ee0:	f94010a1 	ldr	x1, [x5, #32]
    8ee4:	b4ffdd61 	cbz	x1, 8a90 <fwp_main_thread+0xd90>
    8ee8:	386068c0 	ldrb	w0, [x6, x0]
    8eec:	7100081f 	cmp	w0, #0x2
    8ef0:	540058c0 	b.eq	9a08 <fwp_main_thread+0x1d08>  // b.none
    8ef4:	7100041f 	cmp	w0, #0x1
    8ef8:	54ffdcc1 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    8efc:	92403c40 	and	x0, x2, #0xffff
    8f00:	294308a6 	ldp	w6, w2, [x5, #24]
    8f04:	9b067c00 	mul	x0, x0, x6
    8f08:	d360fc00 	lsr	x0, x0, #32
    8f0c:	eb02001f 	cmp	x0, x2
    8f10:	54ffdc02 	b.cs	8a90 <fwp_main_thread+0xd90>  // b.hs, b.nlast
    8f14:	8b000021 	add	x1, x1, x0
    8f18:	39400020 	ldrb	w0, [x1]
    8f1c:	7100041f 	cmp	w0, #0x1
    8f20:	54ffdb81 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    8f24:	aa1b03e0 	mov	x0, x27
    8f28:	97ffee32 	bl	47f0 <fwp_mem_free>
    8f2c:	17fffed9 	b	8a90 <fwp_main_thread+0xd90>
    8f30:	f90007e5 	str	x5, [sp, #8]
    8f34:	97fff543 	bl	6440 <fwp_drop10>
    8f38:	f94007e5 	ldr	x5, [sp, #8]
    8f3c:	aa1403e1 	mov	x1, x20
    8f40:	d2800003 	mov	x3, #0x0                   	// #0
    8f44:	b4005df4 	cbz	x20, 9b00 <fwp_main_thread+0x1e00>
    8f48:	f9400821 	ldr	x1, [x1, #16]
    8f4c:	91000463 	add	x3, x3, #0x1
    8f50:	b5ffffc1 	cbnz	x1, 8f48 <fwp_main_thread+0x1248>
    8f54:	f94000a0 	ldr	x0, [x5]
    8f58:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    8f5c:	b7f83620 	tbnz	x0, #63, 9620 <fwp_main_thread+0x1920>
    8f60:	f949db81 	ldr	x1, [x28, #5040]
    8f64:	f949ef82 	ldr	x2, [x28, #5080]
    8f68:	cb0102a1 	sub	x1, x21, x1
    8f6c:	eb02403f 	cmp	x1, x2, lsl #16
    8f70:	54003582 	b.cs	9620 <fwp_main_thread+0x1920>  // b.hs, b.nlast
    8f74:	d350fc22 	lsr	x2, x1, #16
    8f78:	f949ff88 	ldr	x8, [x28, #5112]
    8f7c:	8b020842 	add	x2, x2, x2, lsl #2
    8f80:	d37df042 	lsl	x2, x2, #3
    8f84:	8b020107 	add	x7, x8, x2
    8f88:	f94010e6 	ldr	x6, [x7, #32]
    8f8c:	b4003486 	cbz	x6, 961c <fwp_main_thread+0x191c>
    8f90:	38626902 	ldrb	w2, [x8, x2]
    8f94:	7100085f 	cmp	w2, #0x2
    8f98:	540033e0 	b.eq	9614 <fwp_main_thread+0x1914>  // b.none
    8f9c:	7100045f 	cmp	w2, #0x1
    8fa0:	540033e1 	b.ne	961c <fwp_main_thread+0x191c>  // b.any
    8fa4:	294308e8 	ldp	w8, w2, [x7, #24]
    8fa8:	92403c21 	and	x1, x1, #0xffff
    8fac:	9b087c21 	mul	x1, x1, x8
    8fb0:	d360fc21 	lsr	x1, x1, #32
    8fb4:	eb02003f 	cmp	x1, x2
    8fb8:	54003322 	b.cs	961c <fwp_main_thread+0x191c>  // b.hs, b.nlast
    8fbc:	8b0100c6 	add	x6, x6, x1
    8fc0:	394000d6 	ldrb	w22, [x6]
    8fc4:	710006df 	cmp	w22, #0x1
    8fc8:	540032a1 	b.ne	961c <fwp_main_thread+0x191c>  // b.any
    8fcc:	b9000bf6 	str	w22, [sp, #8]
    8fd0:	eb19007f 	cmp	x3, x25
    8fd4:	9a999079 	csel	x25, x3, x25, ls	// ls = plast
    8fd8:	910020bb 	add	x27, x5, #0x8
    8fdc:	b4006859 	cbz	x25, 9ce4 <fwp_main_thread+0x1fe4>
    8fe0:	d37df327 	lsl	x7, x25, #3
    8fe4:	aa1403e2 	mov	x2, x20
    8fe8:	910022a6 	add	x6, x21, #0x8
    8fec:	d2800001 	mov	x1, #0x0                   	// #0
    8ff0:	1400000a 	b	9018 <fwp_main_thread+0x1318>
    8ff4:	fc616861 	ldr	d1, [x3, x1]
    8ff8:	fd400440 	ldr	d0, [x2, #8]
    8ffc:	1e613800 	fsub	d0, d0, d1
    9000:	fc216b60 	str	d0, [x27, x1]
    9004:	91002021 	add	x1, x1, #0x8
    9008:	f9400842 	ldr	x2, [x2, #16]
    900c:	eb07003f 	cmp	x1, x7
    9010:	540001a0 	b.eq	9044 <fwp_main_thread+0x1344>  // b.none
    9014:	f94000a0 	ldr	x0, [x5]
    9018:	aa0603e3 	mov	x3, x6
    901c:	b6fffec0 	tbz	x0, #63, 8ff4 <fwp_main_thread+0x12f4>
    9020:	f9400aa3 	ldr	x3, [x21, #16]
    9024:	fd400440 	ldr	d0, [x2, #8]
    9028:	fc616861 	ldr	d1, [x3, x1]
    902c:	1e613800 	fsub	d0, d0, d1
    9030:	fc216b60 	str	d0, [x27, x1]
    9034:	91002021 	add	x1, x1, #0x8
    9038:	f9400842 	ldr	x2, [x2, #16]
    903c:	eb07003f 	cmp	x1, x7
    9040:	54fffea1 	b.ne	9014 <fwp_main_thread+0x1314>  // b.any
    9044:	b4006a34 	cbz	x20, 9d88 <fwp_main_thread+0x2088>
    9048:	f949ef88 	ldr	x8, [x28, #5080]
    904c:	aa1403e6 	mov	x6, x20
    9050:	f949db89 	ldr	x9, [x28, #5040]
    9054:	d2800016 	mov	x22, #0x0                   	// #0
    9058:	f949ff87 	ldr	x7, [x28, #5112]
    905c:	d370bd08 	lsl	x8, x8, #16
    9060:	14000006 	b	9078 <fwp_main_thread+0x1378>
    9064:	f94008c6 	ldr	x6, [x6, #16]
    9068:	910006d6 	add	x22, x22, #0x1
    906c:	f10000df 	cmp	x6, #0x0
    9070:	fa561320 	ccmp	x25, x22, #0x0, ne	// ne = any
    9074:	54000329 	b.ls	90d8 <fwp_main_thread+0x13d8>  // b.plast
    9078:	cb0900c0 	sub	x0, x6, x9
    907c:	eb08001f 	cmp	x0, x8
    9080:	540002c2 	b.cs	90d8 <fwp_main_thread+0x13d8>  // b.hs, b.nlast
    9084:	d350fc01 	lsr	x1, x0, #16
    9088:	8b010821 	add	x1, x1, x1, lsl #2
    908c:	d37df021 	lsl	x1, x1, #3
    9090:	8b0100e5 	add	x5, x7, x1
    9094:	f94010a2 	ldr	x2, [x5, #32]
    9098:	b4000202 	cbz	x2, 90d8 <fwp_main_thread+0x13d8>
    909c:	386168e1 	ldrb	w1, [x7, x1]
    90a0:	7100083f 	cmp	w1, #0x2
    90a4:	54000d80 	b.eq	9254 <fwp_main_thread+0x1554>  // b.none
    90a8:	7100043f 	cmp	w1, #0x1
    90ac:	54000161 	b.ne	90d8 <fwp_main_thread+0x13d8>  // b.any
    90b0:	294304aa 	ldp	w10, w1, [x5, #24]
    90b4:	92403c00 	and	x0, x0, #0xffff
    90b8:	9b0a7c00 	mul	x0, x0, x10
    90bc:	d360fc00 	lsr	x0, x0, #32
    90c0:	eb01001f 	cmp	x0, x1
    90c4:	540000a2 	b.cs	90d8 <fwp_main_thread+0x13d8>  // b.hs, b.nlast
    90c8:	8b000042 	add	x2, x2, x0
    90cc:	39400040 	ldrb	w0, [x2]
    90d0:	7100041f 	cmp	w0, #0x1
    90d4:	54fffc80 	b.eq	9064 <fwp_main_thread+0x1364>  // b.none
    90d8:	eb16033f 	cmp	x25, x22
    90dc:	54000c69 	b.ls	9268 <fwp_main_thread+0x1568>  // b.plast
    90e0:	d100237a 	sub	x26, x27, #0x8
    90e4:	d2800017 	mov	x23, #0x0                   	// #0
    90e8:	14000012 	b	9130 <fwp_main_thread+0x1430>
    90ec:	7100045f 	cmp	w2, #0x1
    90f0:	540001a1 	b.ne	9124 <fwp_main_thread+0x1424>  // b.any
    90f4:	294308c7 	ldp	w7, w2, [x6, #24]
    90f8:	92403c21 	and	x1, x1, #0xffff
    90fc:	9b077c21 	mul	x1, x1, x7
    9100:	d360fc21 	lsr	x1, x1, #32
    9104:	eb02003f 	cmp	x1, x2
    9108:	540000e2 	b.cs	9124 <fwp_main_thread+0x1424>  // b.hs, b.nlast
    910c:	8b010000 	add	x0, x0, x1
    9110:	39400001 	ldrb	w1, [x0]
    9114:	7103fc3f 	cmp	w1, #0xff
    9118:	540039e0 	b.eq	9854 <fwp_main_thread+0x1b54>  // b.none
    911c:	52800021 	mov	w1, #0x1                   	// #1
    9120:	39000001 	strb	w1, [x0]
    9124:	d1000739 	sub	x25, x25, #0x1
    9128:	eb1902df 	cmp	x22, x25
    912c:	54000362 	b.cs	9198 <fwp_main_thread+0x1498>  // b.hs, b.nlast
    9130:	f8797b42 	ldr	x2, [x26, x25, lsl #3]
    9134:	aa1303e1 	mov	x1, x19
    9138:	52800020 	mov	w0, #0x1                   	// #1
    913c:	a90f5fe2 	stp	x2, x23, [sp, #240]
    9140:	97ffef11 	bl	4d84 <fwp_data.part.0.constprop.0>
    9144:	aa0003f7 	mov	x23, x0
    9148:	f949db81 	ldr	x1, [x28, #5040]
    914c:	f949ef80 	ldr	x0, [x28, #5080]
    9150:	cb0102e1 	sub	x1, x23, x1
    9154:	eb00403f 	cmp	x1, x0, lsl #16
    9158:	54fffe62 	b.cs	9124 <fwp_main_thread+0x1424>  // b.hs, b.nlast
    915c:	d350fc20 	lsr	x0, x1, #16
    9160:	f949ff87 	ldr	x7, [x28, #5112]
    9164:	8b000800 	add	x0, x0, x0, lsl #2
    9168:	d37df002 	lsl	x2, x0, #3
    916c:	8b0200e6 	add	x6, x7, x2
    9170:	f94010c0 	ldr	x0, [x6, #32]
    9174:	b4fffd80 	cbz	x0, 9124 <fwp_main_thread+0x1424>
    9178:	386268e2 	ldrb	w2, [x7, x2]
    917c:	7100085f 	cmp	w2, #0x2
    9180:	54fffb61 	b.ne	90ec <fwp_main_thread+0x13ec>  // b.any
    9184:	72003c3f 	tst	w1, #0xffff
    9188:	54fffc40 	b.eq	9110 <fwp_main_thread+0x1410>  // b.none
    918c:	d1000739 	sub	x25, x25, #0x1
    9190:	eb1902df 	cmp	x22, x25
    9194:	54fffce3 	b.cc	9130 <fwp_main_thread+0x1430>  // b.lo, b.ul, b.last
    9198:	b50006b6 	cbnz	x22, 926c <fwp_main_thread+0x156c>
    919c:	b9400be0 	ldr	w0, [sp, #8]
    91a0:	d2800036 	mov	x22, #0x1                   	// #1
    91a4:	d2800019 	mov	x25, #0x0                   	// #0
    91a8:	7100001f 	cmp	w0, #0x0
    91ac:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    91b0:	b40004f9 	cbz	x25, 924c <fwp_main_thread+0x154c>
    91b4:	d1000739 	sub	x25, x25, #0x1
    91b8:	f8797b62 	ldr	x2, [x27, x25, lsl #3]
    91bc:	aa1303e1 	mov	x1, x19
    91c0:	52800020 	mov	w0, #0x1                   	// #1
    91c4:	a90f5fe2 	stp	x2, x23, [sp, #240]
    91c8:	97ffeeef 	bl	4d84 <fwp_data.part.0.constprop.0>
    91cc:	aa0003f7 	mov	x23, x0
    91d0:	f949db81 	ldr	x1, [x28, #5040]
    91d4:	f949ef80 	ldr	x0, [x28, #5080]
    91d8:	cb0102e1 	sub	x1, x23, x1
    91dc:	eb00403f 	cmp	x1, x0, lsl #16
    91e0:	54000302 	b.cs	9240 <fwp_main_thread+0x1540>  // b.hs, b.nlast
    91e4:	d350fc22 	lsr	x2, x1, #16
    91e8:	f949ff85 	ldr	x5, [x28, #5112]
    91ec:	8b020842 	add	x2, x2, x2, lsl #2
    91f0:	d37df042 	lsl	x2, x2, #3
    91f4:	8b0200a3 	add	x3, x5, x2
    91f8:	f940107a 	ldr	x26, [x3, #32]
    91fc:	b400023a 	cbz	x26, 9240 <fwp_main_thread+0x1540>
    9200:	386268a2 	ldrb	w2, [x5, x2]
    9204:	7100085f 	cmp	w2, #0x2
    9208:	54002000 	b.eq	9608 <fwp_main_thread+0x1908>  // b.none
    920c:	7100045f 	cmp	w2, #0x1
    9210:	54000181 	b.ne	9240 <fwp_main_thread+0x1540>  // b.any
    9214:	29430865 	ldp	w5, w2, [x3, #24]
    9218:	92403c21 	and	x1, x1, #0xffff
    921c:	9b057c21 	mul	x1, x1, x5
    9220:	d360fc21 	lsr	x1, x1, #32
    9224:	eb02003f 	cmp	x1, x2
    9228:	540000c2 	b.cs	9240 <fwp_main_thread+0x1540>  // b.hs, b.nlast
    922c:	8b01035a 	add	x26, x26, x1
    9230:	39400341 	ldrb	w1, [x26]
    9234:	7103fc3f 	cmp	w1, #0xff
    9238:	54001e20 	b.eq	95fc <fwp_main_thread+0x18fc>  // b.none
    923c:	39000356 	strb	w22, [x26]
    9240:	d1000739 	sub	x25, x25, #0x1
    9244:	b100073f 	cmn	x25, #0x1
    9248:	54fffb81 	b.ne	91b8 <fwp_main_thread+0x14b8>  // b.any
    924c:	aa1403f9 	mov	x25, x20
    9250:	14000015 	b	92a4 <fwp_main_thread+0x15a4>
    9254:	72003c1f 	tst	w0, #0xffff
    9258:	54fff3a0 	b.eq	90cc <fwp_main_thread+0x13cc>  // b.none
    925c:	eb16033f 	cmp	x25, x22
    9260:	54fff408 	b.hi	90e0 <fwp_main_thread+0x13e0>  // b.pmore
    9264:	d503201f 	nop
    9268:	d2800017 	mov	x23, #0x0                   	// #0
    926c:	8b160f63 	add	x3, x27, x22, lsl #3
    9270:	aa1b03e0 	mov	x0, x27
    9274:	aa1403f9 	mov	x25, x20
    9278:	f8408401 	ldr	x1, [x0], #8
    927c:	f9000721 	str	x1, [x25, #8]
    9280:	aa1903e1 	mov	x1, x25
    9284:	f9400b39 	ldr	x25, [x25, #16]
    9288:	eb03001f 	cmp	x0, x3
    928c:	54ffff61 	b.ne	9278 <fwp_main_thread+0x1578>  // b.any
    9290:	b9400be0 	ldr	w0, [sp, #8]
    9294:	f9000837 	str	x23, [x1, #16]
    9298:	aa1403f7 	mov	x23, x20
    929c:	7100001f 	cmp	w0, #0x0
    92a0:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    92a4:	aa1b03e0 	mov	x0, x27
    92a8:	97ffed52 	bl	47f0 <fwp_mem_free>
    92ac:	f949ef83 	ldr	x3, [x28, #5080]
    92b0:	f949db81 	ldr	x1, [x28, #5040]
    92b4:	d370bc63 	lsl	x3, x3, #16
    92b8:	cb0102a2 	sub	x2, x21, x1
    92bc:	eb03005f 	cmp	x2, x3
    92c0:	54000402 	b.cs	9340 <fwp_main_thread+0x1640>  // b.hs, b.nlast
    92c4:	d350fc40 	lsr	x0, x2, #16
    92c8:	f949ff85 	ldr	x5, [x28, #5112]
    92cc:	8b000800 	add	x0, x0, x0, lsl #2
    92d0:	d37df000 	lsl	x0, x0, #3
    92d4:	8b0000a3 	add	x3, x5, x0
    92d8:	f9401076 	ldr	x22, [x3, #32]
    92dc:	b4001896 	cbz	x22, 95ec <fwp_main_thread+0x18ec>
    92e0:	386068a1 	ldrb	w1, [x5, x0]
    92e4:	7100083f 	cmp	w1, #0x2
    92e8:	54002cc0 	b.eq	9880 <fwp_main_thread+0x1b80>  // b.none
    92ec:	7100043f 	cmp	w1, #0x1
    92f0:	540017e1 	b.ne	95ec <fwp_main_thread+0x18ec>  // b.any
    92f4:	92403c41 	and	x1, x2, #0xffff
    92f8:	29430866 	ldp	w6, w2, [x3, #24]
    92fc:	9b067c21 	mul	x1, x1, x6
    9300:	d360fc21 	lsr	x1, x1, #32
    9304:	eb02003f 	cmp	x1, x2
    9308:	54001722 	b.cs	95ec <fwp_main_thread+0x18ec>  // b.hs, b.nlast
    930c:	8b0102d6 	add	x22, x22, x1
    9310:	394002c1 	ldrb	w1, [x22]
    9314:	340016c1 	cbz	w1, 95ec <fwp_main_thread+0x18ec>
    9318:	7100043f 	cmp	w1, #0x1
    931c:	54001280 	b.eq	956c <fwp_main_thread+0x186c>  // b.none
    9320:	7103fc3f 	cmp	w1, #0xff
    9324:	54004760 	b.eq	9c10 <fwp_main_thread+0x1f10>  // b.none
    9328:	51000421 	sub	w1, w1, #0x1
    932c:	390002c1 	strb	w1, [x22]
    9330:	f949ef83 	ldr	x3, [x28, #5080]
    9334:	f949db81 	ldr	x1, [x28, #5040]
    9338:	d370bc63 	lsl	x3, x3, #16
    933c:	d503201f 	nop
    9340:	cb010321 	sub	x1, x25, x1
    9344:	eb01007f 	cmp	x3, x1
    9348:	54000389 	b.ls	93b8 <fwp_main_thread+0x16b8>  // b.plast
    934c:	d350fc20 	lsr	x0, x1, #16
    9350:	f949ff83 	ldr	x3, [x28, #5112]
    9354:	8b000800 	add	x0, x0, x0, lsl #2
    9358:	d37df000 	lsl	x0, x0, #3
    935c:	8b000062 	add	x2, x3, x0
    9360:	f9401055 	ldr	x21, [x2, #32]
    9364:	b40002b5 	cbz	x21, 93b8 <fwp_main_thread+0x16b8>
    9368:	38606865 	ldrb	w5, [x3, x0]
    936c:	710008bf 	cmp	w5, #0x2
    9370:	54002ce0 	b.eq	990c <fwp_main_thread+0x1c0c>  // b.none
    9374:	710004bf 	cmp	w5, #0x1
    9378:	54000201 	b.ne	93b8 <fwp_main_thread+0x16b8>  // b.any
    937c:	29430845 	ldp	w5, w2, [x2, #24]
    9380:	92403c21 	and	x1, x1, #0xffff
    9384:	9b057c21 	mul	x1, x1, x5
    9388:	d360fc21 	lsr	x1, x1, #32
    938c:	eb02003f 	cmp	x1, x2
    9390:	54000142 	b.cs	93b8 <fwp_main_thread+0x16b8>  // b.hs, b.nlast
    9394:	8b0102b5 	add	x21, x21, x1
    9398:	394002a1 	ldrb	w1, [x21]
    939c:	340000e1 	cbz	w1, 93b8 <fwp_main_thread+0x16b8>
    93a0:	7100043f 	cmp	w1, #0x1
    93a4:	54003380 	b.eq	9a14 <fwp_main_thread+0x1d14>  // b.none
    93a8:	7103fc3f 	cmp	w1, #0xff
    93ac:	54004680 	b.eq	9c7c <fwp_main_thread+0x1f7c>  // b.none
    93b0:	51000421 	sub	w1, w1, #0x1
    93b4:	390002a1 	strb	w1, [x21]
    93b8:	f94003e0 	ldr	x0, [sp]
    93bc:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x11a50>
    93c0:	910aa042 	add	x2, x2, #0x2a8
    93c4:	aa1703e1 	mov	x1, x23
    93c8:	91014042 	add	x2, x2, #0x50
    93cc:	52800023 	mov	w3, #0x1                   	// #1
    93d0:	a908ffff 	stp	xzr, xzr, [sp, #136]
    93d4:	f9004fff 	str	xzr, [sp, #152]
    93d8:	97fff64f 	bl	6d14 <fwp_write>
    93dc:	a948e7f6 	ldp	x22, x25, [sp, #136]
    93e0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x980>
    93e4:	9102c000 	add	x0, x0, #0xb0
    93e8:	f10002df 	cmp	x22, #0x0
    93ec:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    93f0:	b1002b3f 	cmn	x25, #0xa
    93f4:	54005728 	b.hi	9ed8 <fwp_main_thread+0x21d8>  // b.pmore
    93f8:	91002720 	add	x0, x25, #0x9
    93fc:	52800021 	mov	w1, #0x1                   	// #1
    9400:	97ffee1c 	bl	4c70 <fwp_heap_alloc>
    9404:	aa0003fb 	mov	x27, x0
    9408:	aa0003f5 	mov	x21, x0
    940c:	aa1903e2 	mov	x2, x25
    9410:	aa1603e1 	mov	x1, x22
    9414:	f8008779 	str	x25, [x27], #8
    9418:	8b1902b9 	add	x25, x21, x25
    941c:	aa1b03e0 	mov	x0, x27
    9420:	97ffe4ac 	bl	26d0 <memcpy@plt>
    9424:	3900233f 	strb	wzr, [x25, #8]
    9428:	f94047e0 	ldr	x0, [sp, #136]
    942c:	97ffe545 	bl	2940 <free@plt>
    9430:	f949db82 	ldr	x2, [x28, #5040]
    9434:	f949ef80 	ldr	x0, [x28, #5080]
    9438:	cb0202a2 	sub	x2, x21, x2
    943c:	eb00405f 	cmp	x2, x0, lsl #16
    9440:	54000322 	b.cs	94a4 <fwp_main_thread+0x17a4>  // b.hs, b.nlast
    9444:	d350fc40 	lsr	x0, x2, #16
    9448:	f949ff83 	ldr	x3, [x28, #5112]
    944c:	8b000800 	add	x0, x0, x0, lsl #2
    9450:	d37df001 	lsl	x1, x0, #3
    9454:	8b010060 	add	x0, x3, x1
    9458:	f9401016 	ldr	x22, [x0, #32]
    945c:	b4000256 	cbz	x22, 94a4 <fwp_main_thread+0x17a4>
    9460:	38616861 	ldrb	w1, [x3, x1]
    9464:	7100083f 	cmp	w1, #0x2
    9468:	54004380 	b.eq	9cd8 <fwp_main_thread+0x1fd8>  // b.none
    946c:	7100043f 	cmp	w1, #0x1
    9470:	540001a1 	b.ne	94a4 <fwp_main_thread+0x17a4>  // b.any
    9474:	29430003 	ldp	w3, w0, [x0, #24]
    9478:	92403c41 	and	x1, x2, #0xffff
    947c:	9b037c21 	mul	x1, x1, x3
    9480:	d360fc21 	lsr	x1, x1, #32
    9484:	eb00003f 	cmp	x1, x0
    9488:	540000e2 	b.cs	94a4 <fwp_main_thread+0x17a4>  // b.hs, b.nlast
    948c:	8b0102d6 	add	x22, x22, x1
    9490:	394002c0 	ldrb	w0, [x22]
    9494:	7103fc1f 	cmp	w0, #0xff
    9498:	540049a0 	b.eq	9dcc <fwp_main_thread+0x20cc>  // b.none
    949c:	52800020 	mov	w0, #0x1                   	// #1
    94a0:	390002c0 	strb	w0, [x22]
    94a4:	9100c316 	add	x22, x24, #0x30
    94a8:	aa1703e0 	mov	x0, x23
    94ac:	97fff071 	bl	5670 <fwp_drop0>
    94b0:	f94002a2 	ldr	x2, [x21]
    94b4:	d2800021 	mov	x1, #0x1                   	// #1
    94b8:	f94006c3 	ldr	x3, [x22, #8]
    94bc:	aa1b03e0 	mov	x0, x27
    94c0:	97ffe530 	bl	2980 <fwrite@plt>
    94c4:	f94006c1 	ldr	x1, [x22, #8]
    94c8:	52800140 	mov	w0, #0xa                   	// #10
    94cc:	97ffe4b5 	bl	27a0 <fputc@plt>
    94d0:	f949db82 	ldr	x2, [x28, #5040]
    94d4:	f949ef80 	ldr	x0, [x28, #5080]
    94d8:	cb0202a2 	sub	x2, x21, x2
    94dc:	eb00405f 	cmp	x2, x0, lsl #16
    94e0:	54000382 	b.cs	9550 <fwp_main_thread+0x1850>  // b.hs, b.nlast
    94e4:	d350fc40 	lsr	x0, x2, #16
    94e8:	f949ff83 	ldr	x3, [x28, #5112]
    94ec:	8b000800 	add	x0, x0, x0, lsl #2
    94f0:	d37df001 	lsl	x1, x0, #3
    94f4:	8b010060 	add	x0, x3, x1
    94f8:	f9401016 	ldr	x22, [x0, #32]
    94fc:	b40002b6 	cbz	x22, 9550 <fwp_main_thread+0x1850>
    9500:	38616861 	ldrb	w1, [x3, x1]
    9504:	7100083f 	cmp	w1, #0x2
    9508:	54003b40 	b.eq	9c70 <fwp_main_thread+0x1f70>  // b.none
    950c:	7100043f 	cmp	w1, #0x1
    9510:	54000201 	b.ne	9550 <fwp_main_thread+0x1850>  // b.any
    9514:	29430003 	ldp	w3, w0, [x0, #24]
    9518:	92403c41 	and	x1, x2, #0xffff
    951c:	9b037c21 	mul	x1, x1, x3
    9520:	d360fc21 	lsr	x1, x1, #32
    9524:	eb00003f 	cmp	x1, x0
    9528:	54000142 	b.cs	9550 <fwp_main_thread+0x1850>  // b.hs, b.nlast
    952c:	8b0102d6 	add	x22, x22, x1
    9530:	394002c0 	ldrb	w0, [x22]
    9534:	340000e0 	cbz	w0, 9550 <fwp_main_thread+0x1850>
    9538:	7100041f 	cmp	w0, #0x1
    953c:	54003060 	b.eq	9b48 <fwp_main_thread+0x1e48>  // b.none
    9540:	7103fc1f 	cmp	w0, #0xff
    9544:	54004780 	b.eq	9e34 <fwp_main_thread+0x2134>  // b.none
    9548:	51000400 	sub	w0, w0, #0x1
    954c:	390002c0 	strb	w0, [x22]
    9550:	f94027e0 	ldr	x0, [sp, #72]
    9554:	f9400800 	ldr	x0, [x0, #16]
    9558:	f90027e0 	str	x0, [sp, #72]
    955c:	b4003020 	cbz	x0, 9b60 <fwp_main_thread+0x1e60>
    9560:	9100c300 	add	x0, x24, #0x30
    9564:	f9416015 	ldr	x21, [x0, #704]
    9568:	17fffbdf 	b	84e4 <fwp_main_thread+0x7e4>
    956c:	f94002a2 	ldr	x2, [x21]
    9570:	aa1503e0 	mov	x0, x21
    9574:	f949ef83 	ldr	x3, [x28, #5080]
    9578:	f949db81 	ldr	x1, [x28, #5040]
    957c:	d370bc63 	lsl	x3, x3, #16
    9580:	cb0102a8 	sub	x8, x21, x1
    9584:	b7f81ca2 	tbnz	x2, #63, 9918 <fwp_main_thread+0x1c18>
    9588:	eb03011f 	cmp	x8, x3
    958c:	54ffeda2 	b.cs	9340 <fwp_main_thread+0x1640>  // b.hs, b.nlast
    9590:	d350fd02 	lsr	x2, x8, #16
    9594:	8b020842 	add	x2, x2, x2, lsl #2
    9598:	d37df042 	lsl	x2, x2, #3
    959c:	8b0200a7 	add	x7, x5, x2
    95a0:	f94010e6 	ldr	x6, [x7, #32]
    95a4:	b4ffece6 	cbz	x6, 9340 <fwp_main_thread+0x1640>
    95a8:	386268a2 	ldrb	w2, [x5, x2]
    95ac:	7100085f 	cmp	w2, #0x2
    95b0:	540027e0 	b.eq	9aac <fwp_main_thread+0x1dac>  // b.none
    95b4:	7100045f 	cmp	w2, #0x1
    95b8:	54ffec41 	b.ne	9340 <fwp_main_thread+0x1640>  // b.any
    95bc:	294308e5 	ldp	w5, w2, [x7, #24]
    95c0:	92403d00 	and	x0, x8, #0xffff
    95c4:	9b057c00 	mul	x0, x0, x5
    95c8:	d360fc00 	lsr	x0, x0, #32
    95cc:	eb02001f 	cmp	x0, x2
    95d0:	54ffeb82 	b.cs	9340 <fwp_main_thread+0x1640>  // b.hs, b.nlast
    95d4:	8b0000c6 	add	x6, x6, x0
    95d8:	394000c0 	ldrb	w0, [x6]
    95dc:	7100041f 	cmp	w0, #0x1
    95e0:	54ffeb01 	b.ne	9340 <fwp_main_thread+0x1640>  // b.any
    95e4:	aa1503e0 	mov	x0, x21
    95e8:	97ffec82 	bl	47f0 <fwp_mem_free>
    95ec:	f949ef83 	ldr	x3, [x28, #5080]
    95f0:	f949db81 	ldr	x1, [x28, #5040]
    95f4:	d370bc63 	lsl	x3, x3, #16
    95f8:	17ffff52 	b	9340 <fwp_main_thread+0x1640>
    95fc:	aa1a03e0 	mov	x0, x26
    9600:	97ffebdc 	bl	4570 <fwp_rc_forget_slot>
    9604:	17ffff0e 	b	923c <fwp_main_thread+0x153c>
    9608:	72003c3f 	tst	w1, #0xffff
    960c:	54ffe1a1 	b.ne	9240 <fwp_main_thread+0x1540>  // b.any
    9610:	17ffff08 	b	9230 <fwp_main_thread+0x1530>
    9614:	72003c3f 	tst	w1, #0xffff
    9618:	54ffcd40 	b.eq	8fc0 <fwp_main_thread+0x12c0>  // b.none
    961c:	b4000f54 	cbz	x20, 9804 <fwp_main_thread+0x1b04>
    9620:	aa1403f6 	mov	x22, x20
    9624:	d2800017 	mov	x23, #0x0                   	// #0
    9628:	f9400ad6 	ldr	x22, [x22, #16]
    962c:	aa1703e0 	mov	x0, x23
    9630:	910006f7 	add	x23, x23, #0x1
    9634:	b5ffffb6 	cbnz	x22, 9628 <fwp_main_thread+0x1928>
    9638:	f90007e5 	str	x5, [sp, #8]
    963c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9640:	eb0102ff 	cmp	x23, x1
    9644:	54004388 	b.hi	9eb4 <fwp_main_thread+0x21b4>  // b.pmore
    9648:	91000800 	add	x0, x0, #0x2
    964c:	52800041 	mov	w1, #0x2                   	// #2
    9650:	d37df000 	lsl	x0, x0, #3
    9654:	97ffed87 	bl	4c70 <fwp_heap_alloc>
    9658:	f94007e5 	ldr	x5, [sp, #8]
    965c:	eb1902ff 	cmp	x23, x25
    9660:	9a9992f9 	csel	x25, x23, x25, ls	// ls = plast
    9664:	aa0003fb 	mov	x27, x0
    9668:	aa1403e1 	mov	x1, x20
    966c:	d503201f 	nop
    9670:	f9400420 	ldr	x0, [x1, #8]
    9674:	f8367b60 	str	x0, [x27, x22, lsl #3]
    9678:	910006d6 	add	x22, x22, #0x1
    967c:	f9400821 	ldr	x1, [x1, #16]
    9680:	b5ffff81 	cbnz	x1, 9670 <fwp_main_thread+0x1970>
    9684:	b4000c99 	cbz	x25, 9814 <fwp_main_thread+0x1b14>
    9688:	f94000a0 	ldr	x0, [x5]
    968c:	b9000bff 	str	wzr, [sp, #8]
    9690:	17fffe54 	b	8fe0 <fwp_main_thread+0x12e0>
    9694:	eb1502df 	cmp	x22, x21
    9698:	54ff83a0 	b.eq	870c <fwp_main_thread+0xa0c>  // b.none
    969c:	f9401b19 	ldr	x25, [x24, #48]
    96a0:	8b1606c1 	add	x1, x22, x22, lsl #1
    96a4:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    96a8:	9122e000 	add	x0, x0, #0x8b8
    96ac:	8b010ac1 	add	x1, x22, x1, lsl #2
    96b0:	8b010f3b 	add	x27, x25, x1, lsl #3
    96b4:	f900337f 	str	xzr, [x27, #96]
    96b8:	97ffe4d6 	bl	2a10 <getenv@plt>
    96bc:	b5ff87c0 	cbnz	x0, 87b4 <fwp_main_thread+0xab4>
    96c0:	9100c300 	add	x0, x24, #0x30
    96c4:	f9404001 	ldr	x1, [x0, #128]
    96c8:	b4ff8801 	cbz	x1, 87c8 <fwp_main_thread+0xac8>
    96cc:	3cc48002 	ldur	q2, [x0, #72]
    96d0:	91012001 	add	x1, x0, #0x48
    96d4:	3cc58001 	ldur	q1, [x0, #88]
    96d8:	f900401f 	str	xzr, [x0, #128]
    96dc:	4f000400 	movi	v0.4s, #0x0
    96e0:	ad010762 	stp	q2, q1, [x27, #32]
    96e4:	a9468002 	ldp	x2, x0, [x0, #104]
    96e8:	f9000f60 	str	x0, [x27, #24]
    96ec:	f9401820 	ldr	x0, [x1, #48]
    96f0:	f9002362 	str	x2, [x27, #64]
    96f4:	f9002760 	str	x0, [x27, #72]
    96f8:	ad000020 	stp	q0, q0, [x1]
    96fc:	3d800820 	str	q0, [x1, #32]
    9700:	f900183f 	str	xzr, [x1, #48]
    9704:	17fffc31 	b	87c8 <fwp_main_thread+0xac8>
    9708:	d53bd040 	mrs	x0, tpidr_el0
    970c:	91400000 	add	x0, x0, #0x0, lsl #12
    9710:	91004000 	add	x0, x0, #0x10
    9714:	f9400000 	ldr	x0, [x0]
    9718:	b4001400 	cbz	x0, 9998 <fwp_main_thread+0x1c98>
    971c:	f9401fe1 	ldr	x1, [sp, #56]
    9720:	97ffe7b1 	bl	35e4 <fwp_closure_drop_push>
    9724:	b5ff7b54 	cbnz	x20, 868c <fwp_main_thread+0x98c>
    9728:	9100c315 	add	x21, x24, #0x30
    972c:	d2800017 	mov	x23, #0x0                   	// #0
    9730:	b942faa0 	ldr	w0, [x21, #760]
    9734:	35ff7c60 	cbnz	w0, 86c0 <fwp_main_thread+0x9c0>
    9738:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    973c:	912e4000 	add	x0, x0, #0xb90
    9740:	940003c4 	bl	a650 <atexit>
    9744:	35ffb9c0 	cbnz	w0, 8e7c <fwp_main_thread+0x117c>
    9748:	52800020 	mov	w0, #0x1                   	// #1
    974c:	b902faa0 	str	w0, [x21, #760]
    9750:	17fffbdc 	b	86c0 <fwp_main_thread+0x9c0>
    9754:	72003c1f 	tst	w0, #0xffff
    9758:	54ffb2c0 	b.eq	8db0 <fwp_main_thread+0x10b0>  // b.none
    975c:	d503201f 	nop
    9760:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9764:	eb0002df 	cmp	x22, x0
    9768:	54003ce8 	b.hi	9f04 <fwp_main_thread+0x2204>  // b.pmore
    976c:	910006c0 	add	x0, x22, #0x1
    9770:	52800021 	mov	w1, #0x1                   	// #1
    9774:	d37df000 	lsl	x0, x0, #3
    9778:	97ffed3e 	bl	4c70 <fwp_heap_alloc>
    977c:	f9000016 	str	x22, [x0]
    9780:	aa0003e5 	mov	x5, x0
    9784:	aa0003f5 	mov	x21, x0
    9788:	f949db81 	ldr	x1, [x28, #5040]
    978c:	f949ef80 	ldr	x0, [x28, #5080]
    9790:	cb0100a1 	sub	x1, x5, x1
    9794:	eb00403f 	cmp	x1, x0, lsl #16
    9798:	54000322 	b.cs	97fc <fwp_main_thread+0x1afc>  // b.hs, b.nlast
    979c:	d350fc20 	lsr	x0, x1, #16
    97a0:	f949ff83 	ldr	x3, [x28, #5112]
    97a4:	8b000800 	add	x0, x0, x0, lsl #2
    97a8:	d37df002 	lsl	x2, x0, #3
    97ac:	8b020060 	add	x0, x3, x2
    97b0:	f9401017 	ldr	x23, [x0, #32]
    97b4:	b4000257 	cbz	x23, 97fc <fwp_main_thread+0x1afc>
    97b8:	38626862 	ldrb	w2, [x3, x2]
    97bc:	7100085f 	cmp	w2, #0x2
    97c0:	540017c0 	b.eq	9ab8 <fwp_main_thread+0x1db8>  // b.none
    97c4:	7100045f 	cmp	w2, #0x1
    97c8:	540001a1 	b.ne	97fc <fwp_main_thread+0x1afc>  // b.any
    97cc:	29430002 	ldp	w2, w0, [x0, #24]
    97d0:	92403c21 	and	x1, x1, #0xffff
    97d4:	9b027c21 	mul	x1, x1, x2
    97d8:	d360fc21 	lsr	x1, x1, #32
    97dc:	eb00003f 	cmp	x1, x0
    97e0:	540000e2 	b.cs	97fc <fwp_main_thread+0x1afc>  // b.hs, b.nlast
    97e4:	8b0102f7 	add	x23, x23, x1
    97e8:	394002e0 	ldrb	w0, [x23]
    97ec:	7103fc1f 	cmp	w0, #0xff
    97f0:	540016c0 	b.eq	9ac8 <fwp_main_thread+0x1dc8>  // b.none
    97f4:	52800020 	mov	w0, #0x1                   	// #1
    97f8:	390002e0 	strb	w0, [x23]
    97fc:	aa1903e0 	mov	x0, x25
    9800:	17fffd72 	b	8dc8 <fwp_main_thread+0x10c8>
    9804:	52800041 	mov	w1, #0x2                   	// #2
    9808:	d2800100 	mov	x0, #0x8                   	// #8
    980c:	97ffed19 	bl	4c70 <fwp_heap_alloc>
    9810:	aa0003fb 	mov	x27, x0
    9814:	aa1403f9 	mov	x25, x20
    9818:	d2800017 	mov	x23, #0x0                   	// #0
    981c:	17fffea2 	b	92a4 <fwp_main_thread+0x15a4>
    9820:	52800041 	mov	w1, #0x2                   	// #2
    9824:	d2800100 	mov	x0, #0x8                   	// #8
    9828:	97ffed12 	bl	4c70 <fwp_heap_alloc>
    982c:	f900001f 	str	xzr, [x0]
    9830:	aa0003f9 	mov	x25, x0
    9834:	aa0003fb 	mov	x27, x0
    9838:	f949db81 	ldr	x1, [x28, #5040]
    983c:	f949ef80 	ldr	x0, [x28, #5080]
    9840:	cb010321 	sub	x1, x25, x1
    9844:	eb00403f 	cmp	x1, x0, lsl #16
    9848:	54000102 	b.cs	9868 <fwp_main_thread+0x1b68>  // b.hs, b.nlast
    984c:	d2800016 	mov	x22, #0x0                   	// #0
    9850:	17fffc22 	b	88d8 <fwp_main_thread+0xbd8>
    9854:	f9001be0 	str	x0, [sp, #48]
    9858:	97ffeb46 	bl	4570 <fwp_rc_forget_slot>
    985c:	f9401be0 	ldr	x0, [sp, #48]
    9860:	17fffe2f 	b	911c <fwp_main_thread+0x141c>
    9864:	b5ff86d6 	cbnz	x22, 893c <fwp_main_thread+0xc3c>
    9868:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    986c:	f900033f 	str	xzr, [x25]
    9870:	17fffc67 	b	8a0c <fwp_main_thread+0xd0c>
    9874:	72003c3f 	tst	w1, #0xffff
    9878:	54ff90c1 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    987c:	17fffc7c 	b	8a6c <fwp_main_thread+0xd6c>
    9880:	72003c5f 	tst	w2, #0xffff
    9884:	54ffeb41 	b.ne	95ec <fwp_main_thread+0x18ec>  // b.any
    9888:	17fffea2 	b	9310 <fwp_main_thread+0x1610>
    988c:	f940077b 	ldr	x27, [x27, #8]
    9890:	eb05005f 	cmp	x2, x5
    9894:	54000342 	b.cs	98fc <fwp_main_thread+0x1bfc>  // b.hs, b.nlast
    9898:	d350fc47 	lsr	x7, x2, #16
    989c:	8b0708e7 	add	x7, x7, x7, lsl #2
    98a0:	d37df0e7 	lsl	x7, x7, #3
    98a4:	8b0700c9 	add	x9, x6, x7
    98a8:	f9401128 	ldr	x8, [x9, #32]
    98ac:	b4000288 	cbz	x8, 98fc <fwp_main_thread+0x1bfc>
    98b0:	386768c6 	ldrb	w6, [x6, x7]
    98b4:	710008df 	cmp	w6, #0x2
    98b8:	54001420 	b.eq	9b3c <fwp_main_thread+0x1e3c>  // b.none
    98bc:	710004df 	cmp	w6, #0x1
    98c0:	540001e1 	b.ne	98fc <fwp_main_thread+0x1bfc>  // b.any
    98c4:	29431927 	ldp	w7, w6, [x9, #24]
    98c8:	92403c42 	and	x2, x2, #0xffff
    98cc:	9b077c42 	mul	x2, x2, x7
    98d0:	d360fc42 	lsr	x2, x2, #32
    98d4:	eb06005f 	cmp	x2, x6
    98d8:	54000122 	b.cs	98fc <fwp_main_thread+0x1bfc>  // b.hs, b.nlast
    98dc:	8b020108 	add	x8, x8, x2
    98e0:	39400102 	ldrb	w2, [x8]
    98e4:	7100045f 	cmp	w2, #0x1
    98e8:	540000a1 	b.ne	98fc <fwp_main_thread+0x1bfc>  // b.any
    98ec:	97ffebc1 	bl	47f0 <fwp_mem_free>
    98f0:	f949ef85 	ldr	x5, [x28, #5080]
    98f4:	f949db81 	ldr	x1, [x28, #5040]
    98f8:	d370bca5 	lsl	x5, x5, #16
    98fc:	cb010361 	sub	x1, x27, x1
    9900:	eb05003f 	cmp	x1, x5
    9904:	54ff88e3 	b.cc	8a20 <fwp_main_thread+0xd20>  // b.lo, b.ul, b.last
    9908:	17fffc62 	b	8a90 <fwp_main_thread+0xd90>
    990c:	72003c3f 	tst	w1, #0xffff
    9910:	54ffd541 	b.ne	93b8 <fwp_main_thread+0x16b8>  // b.any
    9914:	17fffea1 	b	9398 <fwp_main_thread+0x1698>
    9918:	f94006b5 	ldr	x21, [x21, #8]
    991c:	eb03011f 	cmp	x8, x3
    9920:	54000342 	b.cs	9988 <fwp_main_thread+0x1c88>  // b.hs, b.nlast
    9924:	d350fd02 	lsr	x2, x8, #16
    9928:	8b020842 	add	x2, x2, x2, lsl #2
    992c:	d37df042 	lsl	x2, x2, #3
    9930:	8b0200a7 	add	x7, x5, x2
    9934:	f94010e6 	ldr	x6, [x7, #32]
    9938:	b4000286 	cbz	x6, 9988 <fwp_main_thread+0x1c88>
    993c:	386268a2 	ldrb	w2, [x5, x2]
    9940:	7100085f 	cmp	w2, #0x2
    9944:	54000f60 	b.eq	9b30 <fwp_main_thread+0x1e30>  // b.none
    9948:	7100045f 	cmp	w2, #0x1
    994c:	540001e1 	b.ne	9988 <fwp_main_thread+0x1c88>  // b.any
    9950:	294314e9 	ldp	w9, w5, [x7, #24]
    9954:	92403d02 	and	x2, x8, #0xffff
    9958:	9b097c42 	mul	x2, x2, x9
    995c:	d360fc42 	lsr	x2, x2, #32
    9960:	eb05005f 	cmp	x2, x5
    9964:	54000122 	b.cs	9988 <fwp_main_thread+0x1c88>  // b.hs, b.nlast
    9968:	8b0200c6 	add	x6, x6, x2
    996c:	394000c2 	ldrb	w2, [x6]
    9970:	7100045f 	cmp	w2, #0x1
    9974:	540000a1 	b.ne	9988 <fwp_main_thread+0x1c88>  // b.any
    9978:	97ffeb9e 	bl	47f0 <fwp_mem_free>
    997c:	f949ef83 	ldr	x3, [x28, #5080]
    9980:	f949db81 	ldr	x1, [x28, #5040]
    9984:	d370bc63 	lsl	x3, x3, #16
    9988:	cb0102a2 	sub	x2, x21, x1
    998c:	eb02007f 	cmp	x3, x2
    9990:	54ffc9a8 	b.hi	92c4 <fwp_main_thread+0x15c4>  // b.pmore
    9994:	17fffe6b 	b	9340 <fwp_main_thread+0x1640>
    9998:	f9401fe0 	ldr	x0, [sp, #56]
    999c:	97ffe781 	bl	37a0 <fwp_closure_drop.part.0>
    99a0:	17fffb3a 	b	8688 <fwp_main_thread+0x988>
    99a4:	72003c3f 	tst	w1, #0xffff
    99a8:	54ff7c81 	b.ne	8938 <fwp_main_thread+0xc38>  // b.any
    99ac:	394002e0 	ldrb	w0, [x23]
    99b0:	7103fc1f 	cmp	w0, #0xff
    99b4:	54ff7be1 	b.ne	8930 <fwp_main_thread+0xc30>  // b.any
    99b8:	aa1703e0 	mov	x0, x23
    99bc:	97ffeaed 	bl	4570 <fwp_rc_forget_slot>
    99c0:	17fffbdc 	b	8930 <fwp_main_thread+0xc30>
    99c4:	72003c7f 	tst	w3, #0xffff
    99c8:	54ff6601 	b.ne	8688 <fwp_main_thread+0x988>  // b.any
    99cc:	17fffb27 	b	8668 <fwp_main_thread+0x968>
    99d0:	72003c7f 	tst	w3, #0xffff
    99d4:	54ff6321 	b.ne	8638 <fwp_main_thread+0x938>  // b.any
    99d8:	aa1503e0 	mov	x0, x21
    99dc:	17fffb05 	b	85f0 <fwp_main_thread+0x8f0>
    99e0:	aa1703f5 	mov	x21, x23
    99e4:	17fffc5d 	b	8b58 <fwp_main_thread+0xe58>
    99e8:	72003c3f 	tst	w1, #0xffff
    99ec:	54ff99c1 	b.ne	8d24 <fwp_main_thread+0x1024>  // b.any
    99f0:	394002a0 	ldrb	w0, [x21]
    99f4:	7103fc1f 	cmp	w0, #0xff
    99f8:	54ff9921 	b.ne	8d1c <fwp_main_thread+0x101c>  // b.any
    99fc:	aa1503e0 	mov	x0, x21
    9a00:	97ffeadc 	bl	4570 <fwp_rc_forget_slot>
    9a04:	17fffcc6 	b	8d1c <fwp_main_thread+0x101c>
    9a08:	72003c5f 	tst	w2, #0xffff
    9a0c:	54ff8421 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    9a10:	17fffd42 	b	8f18 <fwp_main_thread+0x1218>
    9a14:	f949ef85 	ldr	x5, [x28, #5080]
    9a18:	f949db81 	ldr	x1, [x28, #5040]
    9a1c:	d370bca5 	lsl	x5, x5, #16
    9a20:	cb010320 	sub	x0, x25, x1
    9a24:	f9400b35 	ldr	x21, [x25, #16]
    9a28:	eb05001f 	cmp	x0, x5
    9a2c:	54000362 	b.cs	9a98 <fwp_main_thread+0x1d98>  // b.hs, b.nlast
    9a30:	d350fc02 	lsr	x2, x0, #16
    9a34:	8b020842 	add	x2, x2, x2, lsl #2
    9a38:	d37df042 	lsl	x2, x2, #3
    9a3c:	8b020067 	add	x7, x3, x2
    9a40:	f94010e6 	ldr	x6, [x7, #32]
    9a44:	b40002a6 	cbz	x6, 9a98 <fwp_main_thread+0x1d98>
    9a48:	38626862 	ldrb	w2, [x3, x2]
    9a4c:	7100085f 	cmp	w2, #0x2
    9a50:	54000a00 	b.eq	9b90 <fwp_main_thread+0x1e90>  // b.none
    9a54:	7100045f 	cmp	w2, #0x1
    9a58:	54000201 	b.ne	9a98 <fwp_main_thread+0x1d98>  // b.any
    9a5c:	294308e3 	ldp	w3, w2, [x7, #24]
    9a60:	92403c00 	and	x0, x0, #0xffff
    9a64:	9b037c00 	mul	x0, x0, x3
    9a68:	d360fc00 	lsr	x0, x0, #32
    9a6c:	eb02001f 	cmp	x0, x2
    9a70:	54000142 	b.cs	9a98 <fwp_main_thread+0x1d98>  // b.hs, b.nlast
    9a74:	8b0000c6 	add	x6, x6, x0
    9a78:	394000c0 	ldrb	w0, [x6]
    9a7c:	7100041f 	cmp	w0, #0x1
    9a80:	540000c1 	b.ne	9a98 <fwp_main_thread+0x1d98>  // b.any
    9a84:	aa1903e0 	mov	x0, x25
    9a88:	97ffeb5a 	bl	47f0 <fwp_mem_free>
    9a8c:	f949ef85 	ldr	x5, [x28, #5080]
    9a90:	f949db81 	ldr	x1, [x28, #5040]
    9a94:	d370bca5 	lsl	x5, x5, #16
    9a98:	cb0102a1 	sub	x1, x21, x1
    9a9c:	eb05003f 	cmp	x1, x5
    9aa0:	54ffc8c2 	b.cs	93b8 <fwp_main_thread+0x16b8>  // b.hs, b.nlast
    9aa4:	aa1503f9 	mov	x25, x21
    9aa8:	17fffe29 	b	934c <fwp_main_thread+0x164c>
    9aac:	72003d1f 	tst	w8, #0xffff
    9ab0:	54ffc481 	b.ne	9340 <fwp_main_thread+0x1640>  // b.any
    9ab4:	17fffec9 	b	95d8 <fwp_main_thread+0x18d8>
    9ab8:	72003c3f 	tst	w1, #0xffff
    9abc:	54ffe960 	b.eq	97e8 <fwp_main_thread+0x1ae8>  // b.none
    9ac0:	aa1903e0 	mov	x0, x25
    9ac4:	17fffcc1 	b	8dc8 <fwp_main_thread+0x10c8>
    9ac8:	aa1703e0 	mov	x0, x23
    9acc:	f90007e5 	str	x5, [sp, #8]
    9ad0:	97ffeaa8 	bl	4570 <fwp_rc_forget_slot>
    9ad4:	f94007e5 	ldr	x5, [sp, #8]
    9ad8:	17ffff47 	b	97f4 <fwp_main_thread+0x1af4>
    9adc:	aa0203e0 	mov	x0, x2
    9ae0:	d2800101 	mov	x1, #0x8                   	// #8
    9ae4:	f90007e2 	str	x2, [sp, #8]
    9ae8:	97ffe35e 	bl	2860 <calloc@plt>
    9aec:	f94007e2 	ldr	x2, [sp, #8]
    9af0:	aa0003f6 	mov	x22, x0
    9af4:	f9401be4 	ldr	x4, [sp, #48]
    9af8:	f94023e6 	ldr	x6, [sp, #64]
    9afc:	17fffc2d 	b	8bb0 <fwp_main_thread+0xeb0>
    9b00:	f94000a0 	ldr	x0, [x5]
    9b04:	b7ffe800 	tbnz	x0, #63, 9804 <fwp_main_thread+0x1b04>
    9b08:	f949db81 	ldr	x1, [x28, #5040]
    9b0c:	f949ef82 	ldr	x2, [x28, #5080]
    9b10:	cb0102a1 	sub	x1, x21, x1
    9b14:	eb02403f 	cmp	x1, x2, lsl #16
    9b18:	54ffe762 	b.cs	9804 <fwp_main_thread+0x1b04>  // b.hs, b.nlast
    9b1c:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    9b20:	17fffd15 	b	8f74 <fwp_main_thread+0x1274>
    9b24:	d2800d01 	mov	x1, #0x68                  	// #104
    9b28:	d280003b 	mov	x27, #0x1                   	// #1
    9b2c:	17fffb08 	b	874c <fwp_main_thread+0xa4c>
    9b30:	72003d1f 	tst	w8, #0xffff
    9b34:	54fff2a1 	b.ne	9988 <fwp_main_thread+0x1c88>  // b.any
    9b38:	17ffff8d 	b	996c <fwp_main_thread+0x1c6c>
    9b3c:	72003c5f 	tst	w2, #0xffff
    9b40:	54ffede1 	b.ne	98fc <fwp_main_thread+0x1bfc>  // b.any
    9b44:	17ffff67 	b	98e0 <fwp_main_thread+0x1be0>
    9b48:	aa1503e0 	mov	x0, x21
    9b4c:	97ffedf2 	bl	5314 <fwp_rc_free_arr>
    9b50:	f94027e0 	ldr	x0, [sp, #72]
    9b54:	f9400800 	ldr	x0, [x0, #16]
    9b58:	f90027e0 	str	x0, [sp, #72]
    9b5c:	b5ffd020 	cbnz	x0, 9560 <fwp_main_thread+0x1860>
    9b60:	aa1403e0 	mov	x0, x20
    9b64:	97ffeec3 	bl	5670 <fwp_drop0>
    9b68:	f9400be0 	ldr	x0, [sp, #16]
    9b6c:	97ffeec1 	bl	5670 <fwp_drop0>
    9b70:	9100c300 	add	x0, x24, #0x30
    9b74:	fd40fbe8 	ldr	d8, [sp, #496]
    9b78:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    9b7c:	52800021 	mov	w1, #0x1                   	// #1
    9b80:	a95e73fb 	ldp	x27, x28, [sp, #480]
    9b84:	b902f401 	str	w1, [x0, #756]
    9b88:	f901801f 	str	xzr, [x0, #768]
    9b8c:	17fff89d 	b	7e00 <fwp_main_thread+0x100>
    9b90:	72003c1f 	tst	w0, #0xffff
    9b94:	54fff821 	b.ne	9a98 <fwp_main_thread+0x1d98>  // b.any
    9b98:	17ffffb8 	b	9a78 <fwp_main_thread+0x1d78>
    9b9c:	72003cbf 	tst	w5, #0xffff
    9ba0:	54ff4e61 	b.ne	856c <fwp_main_thread+0x86c>  // b.any
    9ba4:	17fffa69 	b	8548 <fwp_main_thread+0x848>
    9ba8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9bac:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9bb0:	91150021 	add	x1, x1, #0x540
    9bb4:	ca402400 	eor	x0, x0, x0, lsr #9
    9bb8:	8b200c20 	add	x0, x1, w0, uxtb #3
    9bbc:	f94a2400 	ldr	x0, [x0, #5192]
    9bc0:	b5000080 	cbnz	x0, 9bd0 <fwp_main_thread+0x1ed0>
    9bc4:	14000010 	b	9c04 <fwp_main_thread+0x1f04>
    9bc8:	f9400800 	ldr	x0, [x0, #16]
    9bcc:	b40001c0 	cbz	x0, 9c04 <fwp_main_thread+0x1f04>
    9bd0:	f9400001 	ldr	x1, [x0]
    9bd4:	eb16003f 	cmp	x1, x22
    9bd8:	54ffff81 	b.ne	9bc8 <fwp_main_thread+0x1ec8>  // b.any
    9bdc:	f9400401 	ldr	x1, [x0, #8]
    9be0:	d1000421 	sub	x1, x1, #0x1
    9be4:	f9000401 	str	x1, [x0, #8]
    9be8:	f103f83f 	cmp	x1, #0xfe
    9bec:	54ff7521 	b.ne	8a90 <fwp_main_thread+0xd90>  // b.any
    9bf0:	aa1603e0 	mov	x0, x22
    9bf4:	97ffea5f 	bl	4570 <fwp_rc_forget_slot>
    9bf8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9bfc:	390002c0 	strb	w0, [x22]
    9c00:	17fffba4 	b	8a90 <fwp_main_thread+0xd90>
    9c04:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9c08:	9124a000 	add	x0, x0, #0x928
    9c0c:	97ffe65d 	bl	3580 <fwp_trap>
    9c10:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9c14:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9c18:	91150021 	add	x1, x1, #0x540
    9c1c:	ca402400 	eor	x0, x0, x0, lsr #9
    9c20:	8b200c20 	add	x0, x1, w0, uxtb #3
    9c24:	f94a2401 	ldr	x1, [x0, #5192]
    9c28:	b5000081 	cbnz	x1, 9c38 <fwp_main_thread+0x1f38>
    9c2c:	17fffff6 	b	9c04 <fwp_main_thread+0x1f04>
    9c30:	f9400821 	ldr	x1, [x1, #16]
    9c34:	b4fffe81 	cbz	x1, 9c04 <fwp_main_thread+0x1f04>
    9c38:	f9400020 	ldr	x0, [x1]
    9c3c:	eb16001f 	cmp	x0, x22
    9c40:	54ffff81 	b.ne	9c30 <fwp_main_thread+0x1f30>  // b.any
    9c44:	f9400420 	ldr	x0, [x1, #8]
    9c48:	d1000400 	sub	x0, x0, #0x1
    9c4c:	f9000420 	str	x0, [x1, #8]
    9c50:	f103f81f 	cmp	x0, #0xfe
    9c54:	54000c20 	b.eq	9dd8 <fwp_main_thread+0x20d8>  // b.none
    9c58:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9c5c:	91150000 	add	x0, x0, #0x540
    9c60:	f949ec03 	ldr	x3, [x0, #5080]
    9c64:	f949d801 	ldr	x1, [x0, #5040]
    9c68:	d370bc63 	lsl	x3, x3, #16
    9c6c:	17fffdb5 	b	9340 <fwp_main_thread+0x1640>
    9c70:	72003c5f 	tst	w2, #0xffff
    9c74:	54ffc6e1 	b.ne	9550 <fwp_main_thread+0x1850>  // b.any
    9c78:	17fffe2e 	b	9530 <fwp_main_thread+0x1830>
    9c7c:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9c80:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9c84:	91150021 	add	x1, x1, #0x540
    9c88:	ca402400 	eor	x0, x0, x0, lsr #9
    9c8c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9c90:	f94a2401 	ldr	x1, [x0, #5192]
    9c94:	b5000081 	cbnz	x1, 9ca4 <fwp_main_thread+0x1fa4>
    9c98:	17ffffdb 	b	9c04 <fwp_main_thread+0x1f04>
    9c9c:	f9400821 	ldr	x1, [x1, #16]
    9ca0:	b4fffb21 	cbz	x1, 9c04 <fwp_main_thread+0x1f04>
    9ca4:	f9400020 	ldr	x0, [x1]
    9ca8:	eb15001f 	cmp	x0, x21
    9cac:	54ffff81 	b.ne	9c9c <fwp_main_thread+0x1f9c>  // b.any
    9cb0:	f9400420 	ldr	x0, [x1, #8]
    9cb4:	d1000400 	sub	x0, x0, #0x1
    9cb8:	f9000420 	str	x0, [x1, #8]
    9cbc:	f103f81f 	cmp	x0, #0xfe
    9cc0:	54ffb7c1 	b.ne	93b8 <fwp_main_thread+0x16b8>  // b.any
    9cc4:	aa1503e0 	mov	x0, x21
    9cc8:	97ffea2a 	bl	4570 <fwp_rc_forget_slot>
    9ccc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9cd0:	390002a0 	strb	w0, [x21]
    9cd4:	17fffdb9 	b	93b8 <fwp_main_thread+0x16b8>
    9cd8:	72003c5f 	tst	w2, #0xffff
    9cdc:	54ffbe41 	b.ne	94a4 <fwp_main_thread+0x17a4>  // b.any
    9ce0:	17fffdec 	b	9490 <fwp_main_thread+0x1790>
    9ce4:	aa1403f9 	mov	x25, x20
    9ce8:	d280001b 	mov	x27, #0x0                   	// #0
    9cec:	d2800017 	mov	x23, #0x0                   	// #0
    9cf0:	17fffd6d 	b	92a4 <fwp_main_thread+0x15a4>
    9cf4:	97ffe9d8 	bl	4454 <fwp_rc_wide_dup>
    9cf8:	17fffa44 	b	8608 <fwp_main_thread+0x908>
    9cfc:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9d00:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9d04:	91150021 	add	x1, x1, #0x540
    9d08:	ca402400 	eor	x0, x0, x0, lsr #9
    9d0c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d10:	f94a2400 	ldr	x0, [x0, #5192]
    9d14:	b5000080 	cbnz	x0, 9d24 <fwp_main_thread+0x2024>
    9d18:	17ffffbb 	b	9c04 <fwp_main_thread+0x1f04>
    9d1c:	f9400800 	ldr	x0, [x0, #16]
    9d20:	b4fff720 	cbz	x0, 9c04 <fwp_main_thread+0x1f04>
    9d24:	f9400001 	ldr	x1, [x0]
    9d28:	eb15003f 	cmp	x1, x21
    9d2c:	54ffff81 	b.ne	9d1c <fwp_main_thread+0x201c>  // b.any
    9d30:	f9400401 	ldr	x1, [x0, #8]
    9d34:	d1000421 	sub	x1, x1, #0x1
    9d38:	f9000401 	str	x1, [x0, #8]
    9d3c:	f103f83f 	cmp	x1, #0xfe
    9d40:	54ff4a41 	b.ne	8688 <fwp_main_thread+0x988>  // b.any
    9d44:	aa1503e0 	mov	x0, x21
    9d48:	97ffea0a 	bl	4570 <fwp_rc_forget_slot>
    9d4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d50:	390002a0 	strb	w0, [x21]
    9d54:	17fffa4d 	b	8688 <fwp_main_thread+0x988>
    9d58:	72003c3f 	tst	w1, #0xffff
    9d5c:	54ff3a61 	b.ne	84a8 <fwp_main_thread+0x7a8>  // b.any
    9d60:	17fff9cd 	b	8494 <fwp_main_thread+0x794>
    9d64:	72003c3f 	tst	w1, #0xffff
    9d68:	54ff3541 	b.ne	8410 <fwp_main_thread+0x710>  // b.any
    9d6c:	17fff9a4 	b	83fc <fwp_main_thread+0x6fc>
    9d70:	72003c3f 	tst	w1, #0xffff
    9d74:	54ff3041 	b.ne	837c <fwp_main_thread+0x67c>  // b.any
    9d78:	17fff97c 	b	8368 <fwp_main_thread+0x668>
    9d7c:	aa0003e1 	mov	x1, x0
    9d80:	f9002274 	str	x20, [x19, #64]
    9d84:	17fff838 	b	7e64 <fwp_main_thread+0x164>
    9d88:	d2800016 	mov	x22, #0x0                   	// #0
    9d8c:	17fffcd5 	b	90e0 <fwp_main_thread+0x13e0>
    9d90:	f9416a60 	ldr	x0, [x19, #720]
    9d94:	97ffea97 	bl	47f0 <fwp_mem_free>
    9d98:	f9016a7f 	str	xzr, [x19, #720]
    9d9c:	f901727f 	str	xzr, [x19, #736]
    9da0:	f9418a60 	ldr	x0, [x19, #784]
    9da4:	b4000834 	cbz	x20, 9ea8 <fwp_main_thread+0x21a8>
    9da8:	f900569f 	str	xzr, [x20, #168]
    9dac:	f9005e9f 	str	xzr, [x20, #184]
    9db0:	b9030a7f 	str	wzr, [x19, #776]
    9db4:	eb14001f 	cmp	x0, x20
    9db8:	54ff0b60 	b.eq	7f24 <fwp_main_thread+0x224>  // b.none
    9dbc:	a91d6bf9 	stp	x25, x26, [sp, #464]
    9dc0:	a91e73fb 	stp	x27, x28, [sp, #480]
    9dc4:	fd00fbe8 	str	d8, [sp, #496]
    9dc8:	97ffe2c2 	bl	28d0 <abort@plt>
    9dcc:	aa1603e0 	mov	x0, x22
    9dd0:	97ffe9e8 	bl	4570 <fwp_rc_forget_slot>
    9dd4:	17fffdb2 	b	949c <fwp_main_thread+0x179c>
    9dd8:	aa1603e0 	mov	x0, x22
    9ddc:	97ffe9e5 	bl	4570 <fwp_rc_forget_slot>
    9de0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9de4:	91150000 	add	x0, x0, #0x540
    9de8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9dec:	390002c1 	strb	w1, [x22]
    9df0:	f949ec03 	ldr	x3, [x0, #5080]
    9df4:	f949d801 	ldr	x1, [x0, #5040]
    9df8:	d370bc63 	lsl	x3, x3, #16
    9dfc:	17fffd51 	b	9340 <fwp_main_thread+0x1640>
    9e00:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9e04:	91282000 	add	x0, x0, #0xa08
    9e08:	97ffe5de 	bl	3580 <fwp_trap>
    9e0c:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9e10:	9125c000 	add	x0, x0, #0x970
    9e14:	97ffe5db 	bl	3580 <fwp_trap>
    9e18:	97ffe98f 	bl	4454 <fwp_rc_wide_dup>
    9e1c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9e20:	91150000 	add	x0, x0, #0x540
    9e24:	f949ec06 	ldr	x6, [x0, #5080]
    9e28:	f949d802 	ldr	x2, [x0, #5040]
    9e2c:	d370bcc6 	lsl	x6, x6, #16
    9e30:	17fff9cf 	b	856c <fwp_main_thread+0x86c>
    9e34:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9e38:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9e3c:	91150021 	add	x1, x1, #0x540
    9e40:	ca402400 	eor	x0, x0, x0, lsr #9
    9e44:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e48:	f94a2400 	ldr	x0, [x0, #5192]
    9e4c:	b5000080 	cbnz	x0, 9e5c <fwp_main_thread+0x215c>
    9e50:	17ffff6d 	b	9c04 <fwp_main_thread+0x1f04>
    9e54:	f9400800 	ldr	x0, [x0, #16]
    9e58:	b4ffed60 	cbz	x0, 9c04 <fwp_main_thread+0x1f04>
    9e5c:	f9400001 	ldr	x1, [x0]
    9e60:	eb16003f 	cmp	x1, x22
    9e64:	54ffff81 	b.ne	9e54 <fwp_main_thread+0x2154>  // b.any
    9e68:	f9400401 	ldr	x1, [x0, #8]
    9e6c:	d1000421 	sub	x1, x1, #0x1
    9e70:	f9000401 	str	x1, [x0, #8]
    9e74:	f103f83f 	cmp	x1, #0xfe
    9e78:	54ffb6c1 	b.ne	9550 <fwp_main_thread+0x1850>  // b.any
    9e7c:	aa1603e0 	mov	x0, x22
    9e80:	97ffe9bc 	bl	4570 <fwp_rc_forget_slot>
    9e84:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e88:	390002c0 	strb	w0, [x22]
    9e8c:	17fffdb1 	b	9550 <fwp_main_thread+0x1850>
    9e90:	aa1403e0 	mov	x0, x20
    9e94:	97ffe9b7 	bl	4570 <fwp_rc_forget_slot>
    9e98:	17fff937 	b	8374 <fwp_main_thread+0x674>
    9e9c:	aa1403e0 	mov	x0, x20
    9ea0:	97ffe9b4 	bl	4570 <fwp_rc_forget_slot>
    9ea4:	17fff959 	b	8408 <fwp_main_thread+0x708>
    9ea8:	b9030a7f 	str	wzr, [x19, #776]
    9eac:	b4ff0d60 	cbz	x0, 8058 <fwp_main_thread+0x358>
    9eb0:	17ffffc3 	b	9dbc <fwp_main_thread+0x20bc>
    9eb4:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9eb8:	9129a000 	add	x0, x0, #0xa68
    9ebc:	97ffe5b1 	bl	3580 <fwp_trap>
    9ec0:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9ec4:	912fc000 	add	x0, x0, #0xbf0
    9ec8:	97ffe5ae 	bl	3580 <fwp_trap>
    9ecc:	aa1603e0 	mov	x0, x22
    9ed0:	97ffe9a8 	bl	4570 <fwp_rc_forget_slot>
    9ed4:	17fff973 	b	84a0 <fwp_main_thread+0x7a0>
    9ed8:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9edc:	91306000 	add	x0, x0, #0xc18
    9ee0:	97ffe5a8 	bl	3580 <fwp_trap>
    9ee4:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9ee8:	9130c000 	add	x0, x0, #0xc30
    9eec:	97ffe5a5 	bl	3580 <fwp_trap>
    9ef0:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9ef4:	9126e000 	add	x0, x0, #0x9b8
    9ef8:	97ffe5a2 	bl	3580 <fwp_trap>
    9efc:	52800020 	mov	w0, #0x1                   	// #1
    9f00:	17fffbd7 	b	8e5c <fwp_main_thread+0x115c>
    9f04:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9f08:	912f8000 	add	x0, x0, #0xbe0
    9f0c:	97ffe59d 	bl	3580 <fwp_trap>
    9f10:	a91d6bf9 	stp	x25, x26, [sp, #464]
    9f14:	a91e73fb 	stp	x27, x28, [sp, #480]
    9f18:	fd00fbe8 	str	d8, [sp, #496]
    9f1c:	97ffe259 	bl	2880 <__stack_chk_fail@plt>
    9f20:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9f24:	912ec000 	add	x0, x0, #0xbb0
    9f28:	97ffe596 	bl	3580 <fwp_trap>
    9f2c:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9f30:	912e4000 	add	x0, x0, #0xb90
    9f34:	97ffe593 	bl	3580 <fwp_trap>
    9f38:	b0000000 	adrp	x0, a000 <__divti3+0xa0>
    9f3c:	912da000 	add	x0, x0, #0xb68
    9f40:	a91d6bf9 	stp	x25, x26, [sp, #464]
    9f44:	a91e73fb 	stp	x27, x28, [sp, #480]
    9f48:	fd00fbe8 	str	d8, [sp, #496]
    9f4c:	97ffe58d 	bl	3580 <fwp_trap>
    9f50:	97ffe2cc 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9f54:	d503201f 	nop
    9f58:	d503201f 	nop
    9f5c:	d503201f 	nop

0000000000009f60 <__divti3>:
    9f60:	d503245f 	bti	c
    9f64:	d2800004 	mov	x4, #0x0                   	// #0
    9f68:	b7f80721 	tbnz	x1, #63, a04c <__divti3+0xec>
    9f6c:	b6f80083 	tbz	x3, #63, 9f7c <__divti3+0x1c>
    9f70:	eb0203e2 	negs	x2, x2
    9f74:	aa2403e4 	mvn	x4, x4
    9f78:	da0303e3 	ngc	x3, x3
    9f7c:	aa0203e6 	mov	x6, x2
    9f80:	aa0003e7 	mov	x7, x0
    9f84:	aa0103e5 	mov	x5, x1
    9f88:	b5000583 	cbnz	x3, a038 <__divti3+0xd8>
    9f8c:	eb01005f 	cmp	x2, x1
    9f90:	54000e69 	b.ls	a15c <__divti3+0x1fc>  // b.plast
    9f94:	dac01040 	clz	x0, x2
    9f98:	b40000e0 	cbz	x0, 9fb4 <__divti3+0x54>
    9f9c:	4b0003e1 	neg	w1, w0
    9fa0:	9ac020a5 	lsl	x5, x5, x0
    9fa4:	9ac02046 	lsl	x6, x2, x0
    9fa8:	9ac124e1 	lsr	x1, x7, x1
    9fac:	aa050025 	orr	x5, x1, x5
    9fb0:	9ac020e7 	lsl	x7, x7, x0
    9fb4:	d360fcc8 	lsr	x8, x6, #32
    9fb8:	92407cc2 	and	x2, x6, #0xffffffff
    9fbc:	9ac808a3 	udiv	x3, x5, x8
    9fc0:	9b089465 	msub	x5, x3, x8, x5
    9fc4:	aa0303e0 	mov	x0, x3
    9fc8:	9b037c41 	mul	x1, x2, x3
    9fcc:	93c780a5 	extr	x5, x5, x7, #32
    9fd0:	eb05003f 	cmp	x1, x5
    9fd4:	540000a9 	b.ls	9fe8 <__divti3+0x88>  // b.plast
    9fd8:	ab0500c5 	adds	x5, x6, x5
    9fdc:	d1000460 	sub	x0, x3, #0x1
    9fe0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9fe4:	540015a8 	b.hi	a298 <__divti3+0x338>  // b.pmore
    9fe8:	cb0100a5 	sub	x5, x5, x1
    9fec:	9ac808a3 	udiv	x3, x5, x8
    9ff0:	9b089465 	msub	x5, x3, x8, x5
    9ff4:	aa0303e1 	mov	x1, x3
    9ff8:	9b037c42 	mul	x2, x2, x3
    9ffc:	aa0703e3 	mov	x3, x7
    a000:	b3607ca3 	bfi	x3, x5, #32, #32
    a004:	eb03005f 	cmp	x2, x3
    a008:	540000c9 	b.ls	a020 <__divti3+0xc0>  // b.plast
    a00c:	ab0300c3 	adds	x3, x6, x3
    a010:	d1000425 	sub	x5, x1, #0x1
    a014:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a018:	d1000821 	sub	x1, x1, #0x2
    a01c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a020:	aa008020 	orr	x0, x1, x0, lsl #32
    a024:	d2800001 	mov	x1, #0x0                   	// #0
    a028:	b4000064 	cbz	x4, a034 <__divti3+0xd4>
    a02c:	eb0003e0 	negs	x0, x0
    a030:	da0103e1 	ngc	x1, x1
    a034:	d65f03c0 	ret
    a038:	eb01007f 	cmp	x3, x1
    a03c:	54000109 	b.ls	a05c <__divti3+0xfc>  // b.plast
    a040:	d2800001 	mov	x1, #0x0                   	// #0
    a044:	d2800000 	mov	x0, #0x0                   	// #0
    a048:	17fffff8 	b	a028 <__divti3+0xc8>
    a04c:	eb0003e0 	negs	x0, x0
    a050:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a054:	da0103e1 	ngc	x1, x1
    a058:	17ffffc5 	b	9f6c <__divti3+0xc>
    a05c:	dac01067 	clz	x7, x3
    a060:	b40010e7 	cbz	x7, a27c <__divti3+0x31c>
    a064:	d2800805 	mov	x5, #0x40                  	// #64
    a068:	cb0700a5 	sub	x5, x5, x7
    a06c:	9ac72063 	lsl	x3, x3, x7
    a070:	9ac52448 	lsr	x8, x2, x5
    a074:	aa030108 	orr	x8, x8, x3
    a078:	9ac52426 	lsr	x6, x1, x5
    a07c:	92407d0a 	and	x10, x8, #0xffffffff
    a080:	d360fd09 	lsr	x9, x8, #32
    a084:	9ac52403 	lsr	x3, x0, x5
    a088:	9ac72021 	lsl	x1, x1, x7
    a08c:	aa010063 	orr	x3, x3, x1
    a090:	9ac72042 	lsl	x2, x2, x7
    a094:	9ac908cb 	udiv	x11, x6, x9
    a098:	9b099965 	msub	x5, x11, x9, x6
    a09c:	aa0b03e1 	mov	x1, x11
    a0a0:	9b0b7d46 	mul	x6, x10, x11
    a0a4:	93c380a5 	extr	x5, x5, x3, #32
    a0a8:	eb0500df 	cmp	x6, x5
    a0ac:	540000a9 	b.ls	a0c0 <__divti3+0x160>  // b.plast
    a0b0:	ab050105 	adds	x5, x8, x5
    a0b4:	d1000561 	sub	x1, x11, #0x1
    a0b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a0bc:	54000f48 	b.hi	a2a4 <__divti3+0x344>  // b.pmore
    a0c0:	cb0600a6 	sub	x6, x5, x6
    a0c4:	9ac908cb 	udiv	x11, x6, x9
    a0c8:	9b099969 	msub	x9, x11, x9, x6
    a0cc:	aa0b03e5 	mov	x5, x11
    a0d0:	9b0b7d4a 	mul	x10, x10, x11
    a0d4:	b3607d23 	bfi	x3, x9, #32, #32
    a0d8:	eb03015f 	cmp	x10, x3
    a0dc:	540000a9 	b.ls	a0f0 <__divti3+0x190>  // b.plast
    a0e0:	ab030103 	adds	x3, x8, x3
    a0e4:	d1000565 	sub	x5, x11, #0x1
    a0e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a0ec:	54000e28 	b.hi	a2b0 <__divti3+0x350>  // b.pmore
    a0f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a0f4:	92407c48 	and	x8, x2, #0xffffffff
    a0f8:	2a0503e5 	mov	w5, w5
    a0fc:	d360fc42 	lsr	x2, x2, #32
    a100:	d360fc26 	lsr	x6, x1, #32
    a104:	cb0a0063 	sub	x3, x3, x10
    a108:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a10c:	9b087caa 	mul	x10, x5, x8
    a110:	9b087cc8 	mul	x8, x6, x8
    a114:	9b0220a5 	madd	x5, x5, x2, x8
    a118:	9b027cc6 	mul	x6, x6, x2
    a11c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a120:	8b0900c5 	add	x5, x6, x9
    a124:	eb02011f 	cmp	x8, x2
    a128:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a12c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a130:	eb06007f 	cmp	x3, x6
    a134:	540000e3 	b.cc	a150 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a138:	92407d4a 	and	x10, x10, #0xffffffff
    a13c:	9ac72000 	lsl	x0, x0, x7
    a140:	8b028142 	add	x2, x10, x2, lsl #32
    a144:	eb02001f 	cmp	x0, x2
    a148:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a14c:	54000a01 	b.ne	a28c <__divti3+0x32c>  // b.any
    a150:	d1000420 	sub	x0, x1, #0x1
    a154:	d2800001 	mov	x1, #0x0                   	// #0
    a158:	17ffffb4 	b	a028 <__divti3+0xc8>
    a15c:	b5000062 	cbnz	x2, a168 <__divti3+0x208>
    a160:	d2800022 	mov	x2, #0x1                   	// #1
    a164:	9ac30846 	udiv	x6, x2, x3
    a168:	dac010c8 	clz	x8, x6
    a16c:	b5000408 	cbnz	x8, a1ec <__divti3+0x28c>
    a170:	d360fcc9 	lsr	x9, x6, #32
    a174:	92407cc5 	and	x5, x6, #0xffffffff
    a178:	cb060023 	sub	x3, x1, x6
    a17c:	d2800021 	mov	x1, #0x1                   	// #1
    a180:	9ac90868 	udiv	x8, x3, x9
    a184:	9b098d03 	msub	x3, x8, x9, x3
    a188:	aa0803e0 	mov	x0, x8
    a18c:	9b057d02 	mul	x2, x8, x5
    a190:	93c78063 	extr	x3, x3, x7, #32
    a194:	eb03005f 	cmp	x2, x3
    a198:	540000a9 	b.ls	a1ac <__divti3+0x24c>  // b.plast
    a19c:	ab0300c3 	adds	x3, x6, x3
    a1a0:	d1000500 	sub	x0, x8, #0x1
    a1a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a1a8:	54000968 	b.hi	a2d4 <__divti3+0x374>  // b.pmore
    a1ac:	cb020063 	sub	x3, x3, x2
    a1b0:	9ac90862 	udiv	x2, x3, x9
    a1b4:	aa0203e8 	mov	x8, x2
    a1b8:	9b098c42 	msub	x2, x2, x9, x3
    a1bc:	aa0703e3 	mov	x3, x7
    a1c0:	9b057d05 	mul	x5, x8, x5
    a1c4:	b3607c43 	bfi	x3, x2, #32, #32
    a1c8:	eb0300bf 	cmp	x5, x3
    a1cc:	540000c9 	b.ls	a1e4 <__divti3+0x284>  // b.plast
    a1d0:	ab0300c2 	adds	x2, x6, x3
    a1d4:	d1000503 	sub	x3, x8, #0x1
    a1d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a1dc:	d1000908 	sub	x8, x8, #0x2
    a1e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a1e4:	aa008100 	orr	x0, x8, x0, lsl #32
    a1e8:	17ffff90 	b	a028 <__divti3+0xc8>
    a1ec:	9ac820c6 	lsl	x6, x6, x8
    a1f0:	d2800803 	mov	x3, #0x40                  	// #64
    a1f4:	cb080063 	sub	x3, x3, x8
    a1f8:	d360fcc9 	lsr	x9, x6, #32
    a1fc:	9ac82027 	lsl	x7, x1, x8
    a200:	92407cc5 	and	x5, x6, #0xffffffff
    a204:	9ac32422 	lsr	x2, x1, x3
    a208:	9ac32403 	lsr	x3, x0, x3
    a20c:	aa070063 	orr	x3, x3, x7
    a210:	9ac9084a 	udiv	x10, x2, x9
    a214:	9ac82007 	lsl	x7, x0, x8
    a218:	9b098940 	msub	x0, x10, x9, x2
    a21c:	aa0a03e1 	mov	x1, x10
    a220:	9b0a7ca2 	mul	x2, x5, x10
    a224:	93c38000 	extr	x0, x0, x3, #32
    a228:	eb00005f 	cmp	x2, x0
    a22c:	540000a9 	b.ls	a240 <__divti3+0x2e0>  // b.plast
    a230:	ab0000c0 	adds	x0, x6, x0
    a234:	d1000541 	sub	x1, x10, #0x1
    a238:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a23c:	54000468 	b.hi	a2c8 <__divti3+0x368>  // b.pmore
    a240:	cb020000 	sub	x0, x0, x2
    a244:	9ac9080a 	udiv	x10, x0, x9
    a248:	9b098140 	msub	x0, x10, x9, x0
    a24c:	aa0a03e2 	mov	x2, x10
    a250:	9b0a7ca8 	mul	x8, x5, x10
    a254:	b3607c03 	bfi	x3, x0, #32, #32
    a258:	eb03011f 	cmp	x8, x3
    a25c:	540000a9 	b.ls	a270 <__divti3+0x310>  // b.plast
    a260:	ab0300c3 	adds	x3, x6, x3
    a264:	d1000542 	sub	x2, x10, #0x1
    a268:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a26c:	54000288 	b.hi	a2bc <__divti3+0x35c>  // b.pmore
    a270:	cb080063 	sub	x3, x3, x8
    a274:	aa018041 	orr	x1, x2, x1, lsl #32
    a278:	17ffffc2 	b	a180 <__divti3+0x220>
    a27c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a280:	d2800001 	mov	x1, #0x0                   	// #0
    a284:	9a9f87e0 	cset	x0, ls	// ls = plast
    a288:	17ffff68 	b	a028 <__divti3+0xc8>
    a28c:	aa0103e0 	mov	x0, x1
    a290:	d2800001 	mov	x1, #0x0                   	// #0
    a294:	17ffff65 	b	a028 <__divti3+0xc8>
    a298:	d1000860 	sub	x0, x3, #0x2
    a29c:	8b0600a5 	add	x5, x5, x6
    a2a0:	17ffff52 	b	9fe8 <__divti3+0x88>
    a2a4:	d1000961 	sub	x1, x11, #0x2
    a2a8:	8b0800a5 	add	x5, x5, x8
    a2ac:	17ffff85 	b	a0c0 <__divti3+0x160>
    a2b0:	d1000965 	sub	x5, x11, #0x2
    a2b4:	8b080063 	add	x3, x3, x8
    a2b8:	17ffff8e 	b	a0f0 <__divti3+0x190>
    a2bc:	d1000942 	sub	x2, x10, #0x2
    a2c0:	8b060063 	add	x3, x3, x6
    a2c4:	17ffffeb 	b	a270 <__divti3+0x310>
    a2c8:	d1000941 	sub	x1, x10, #0x2
    a2cc:	8b060000 	add	x0, x0, x6
    a2d0:	17ffffdc 	b	a240 <__divti3+0x2e0>
    a2d4:	d1000900 	sub	x0, x8, #0x2
    a2d8:	8b060063 	add	x3, x3, x6
    a2dc:	17ffffb4 	b	a1ac <__divti3+0x24c>

000000000000a2e0 <__modti3>:
    a2e0:	d503245f 	bti	c
    a2e4:	d2800004 	mov	x4, #0x0                   	// #0
    a2e8:	b6f80081 	tbz	x1, #63, a2f8 <__modti3+0x18>
    a2ec:	eb0003e0 	negs	x0, x0
    a2f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a2f4:	da0103e1 	ngc	x1, x1
    a2f8:	f100007f 	cmp	x3, #0x0
    a2fc:	5400128b 	b.lt	a54c <__modti3+0x26c>  // b.tstop
    a300:	aa0003e7 	mov	x7, x0
    a304:	aa0103e6 	mov	x6, x1
    a308:	540004e1 	b.ne	a3a4 <__modti3+0xc4>  // b.any
    a30c:	eb02003f 	cmp	x1, x2
    a310:	54000dc2 	b.cs	a4c8 <__modti3+0x1e8>  // b.hs, b.nlast
    a314:	dac01043 	clz	x3, x2
    a318:	aa0303e5 	mov	x5, x3
    a31c:	b40000e3 	cbz	x3, a338 <__modti3+0x58>
    a320:	4b0303e6 	neg	w6, w3
    a324:	9ac32021 	lsl	x1, x1, x3
    a328:	9ac32042 	lsl	x2, x2, x3
    a32c:	9ac62406 	lsr	x6, x0, x6
    a330:	aa0100c6 	orr	x6, x6, x1
    a334:	9ac32007 	lsl	x7, x0, x3
    a338:	d360fc40 	lsr	x0, x2, #32
    a33c:	92407c43 	and	x3, x2, #0xffffffff
    a340:	9ac008c1 	udiv	x1, x6, x0
    a344:	9b009826 	msub	x6, x1, x0, x6
    a348:	9b017c61 	mul	x1, x3, x1
    a34c:	93c780c6 	extr	x6, x6, x7, #32
    a350:	eb06003f 	cmp	x1, x6
    a354:	540000a9 	b.ls	a368 <__modti3+0x88>  // b.plast
    a358:	ab060046 	adds	x6, x2, x6
    a35c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a360:	8b0200c8 	add	x8, x6, x2
    a364:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a368:	cb0100c6 	sub	x6, x6, x1
    a36c:	9ac008c8 	udiv	x8, x6, x0
    a370:	9b009901 	msub	x1, x8, x0, x6
    a374:	aa0703e0 	mov	x0, x7
    a378:	9b087c63 	mul	x3, x3, x8
    a37c:	b3607c20 	bfi	x0, x1, #32, #32
    a380:	eb00007f 	cmp	x3, x0
    a384:	54001088 	b.hi	a594 <__modti3+0x2b4>  // b.pmore
    a388:	cb030000 	sub	x0, x0, x3
    a38c:	9ac52400 	lsr	x0, x0, x5
    a390:	d2800001 	mov	x1, #0x0                   	// #0
    a394:	b4000064 	cbz	x4, a3a0 <__modti3+0xc0>
    a398:	eb0003e0 	negs	x0, x0
    a39c:	da0103e1 	ngc	x1, x1
    a3a0:	d65f03c0 	ret
    a3a4:	dac01066 	clz	x6, x3
    a3a8:	eb03003f 	cmp	x1, x3
    a3ac:	54ffff43 	b.cc	a394 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a3b0:	93407cc5 	sxtw	x5, w6
    a3b4:	d2800808 	mov	x8, #0x40                  	// #64
    a3b8:	cb050108 	sub	x8, x8, x5
    a3bc:	9ac62063 	lsl	x3, x3, x6
    a3c0:	9ac62025 	lsl	x5, x1, x6
    a3c4:	9ac82447 	lsr	x7, x2, x8
    a3c8:	aa0300e7 	orr	x7, x7, x3
    a3cc:	9ac82423 	lsr	x3, x1, x8
    a3d0:	92407cec 	and	x12, x7, #0xffffffff
    a3d4:	d360fcea 	lsr	x10, x7, #32
    a3d8:	9ac82401 	lsr	x1, x0, x8
    a3dc:	aa050021 	orr	x1, x1, x5
    a3e0:	9ac62042 	lsl	x2, x2, x6
    a3e4:	9ac62000 	lsl	x0, x0, x6
    a3e8:	9aca086b 	udiv	x11, x3, x10
    a3ec:	9b0a8d63 	msub	x3, x11, x10, x3
    a3f0:	aa0b03e5 	mov	x5, x11
    a3f4:	9b0b7d89 	mul	x9, x12, x11
    a3f8:	93c18063 	extr	x3, x3, x1, #32
    a3fc:	eb03013f 	cmp	x9, x3
    a400:	540000a9 	b.ls	a414 <__modti3+0x134>  // b.plast
    a404:	ab0300e3 	adds	x3, x7, x3
    a408:	d1000565 	sub	x5, x11, #0x1
    a40c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a410:	54001168 	b.hi	a63c <__modti3+0x35c>  // b.pmore
    a414:	cb090063 	sub	x3, x3, x9
    a418:	9aca086b 	udiv	x11, x3, x10
    a41c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a420:	aa0b03e9 	mov	x9, x11
    a424:	9b0b7d8c 	mul	x12, x12, x11
    a428:	b3607d41 	bfi	x1, x10, #32, #32
    a42c:	eb01019f 	cmp	x12, x1
    a430:	540000a9 	b.ls	a444 <__modti3+0x164>  // b.plast
    a434:	ab0100e1 	adds	x1, x7, x1
    a438:	d1000569 	sub	x9, x11, #0x1
    a43c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a440:	54000f88 	b.hi	a630 <__modti3+0x350>  // b.pmore
    a444:	aa058123 	orr	x3, x9, x5, lsl #32
    a448:	92407c4b 	and	x11, x2, #0xffffffff
    a44c:	2a0903e9 	mov	w9, w9
    a450:	d360fc4a 	lsr	x10, x2, #32
    a454:	d360fc63 	lsr	x3, x3, #32
    a458:	cb0c0021 	sub	x1, x1, x12
    a45c:	aa0a03ec 	mov	x12, x10
    a460:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a464:	9b0b7d25 	mul	x5, x9, x11
    a468:	9b0b7c6b 	mul	x11, x3, x11
    a46c:	9b0a2d29 	madd	x9, x9, x10, x11
    a470:	92407caa 	and	x10, x5, #0xffffffff
    a474:	9b0c7c63 	mul	x3, x3, x12
    a478:	8b458125 	add	x5, x9, x5, lsr #32
    a47c:	8b0d0069 	add	x9, x3, x13
    a480:	eb05017f 	cmp	x11, x5
    a484:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a488:	8b058149 	add	x9, x10, x5, lsl #32
    a48c:	8b458063 	add	x3, x3, x5, lsr #32
    a490:	eb03003f 	cmp	x1, x3
    a494:	54000063 	b.cc	a4a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a498:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a49c:	54000082 	b.cs	a4ac <__modti3+0x1cc>  // b.hs, b.nlast
    a4a0:	eb020129 	subs	x9, x9, x2
    a4a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a4a8:	cb070063 	sub	x3, x3, x7
    a4ac:	eb090000 	subs	x0, x0, x9
    a4b0:	da030021 	sbc	x1, x1, x3
    a4b4:	9ac62400 	lsr	x0, x0, x6
    a4b8:	9ac82028 	lsl	x8, x1, x8
    a4bc:	aa000100 	orr	x0, x8, x0
    a4c0:	9ac62421 	lsr	x1, x1, x6
    a4c4:	17ffffb4 	b	a394 <__modti3+0xb4>
    a4c8:	b5000062 	cbnz	x2, a4d4 <__modti3+0x1f4>
    a4cc:	d2800023 	mov	x3, #0x1                   	// #1
    a4d0:	9ac20862 	udiv	x2, x3, x2
    a4d4:	dac01048 	clz	x8, x2
    a4d8:	aa0803e5 	mov	x5, x8
    a4dc:	b5000668 	cbnz	x8, a5a8 <__modti3+0x2c8>
    a4e0:	cb020020 	sub	x0, x1, x2
    a4e4:	d360fc49 	lsr	x9, x2, #32
    a4e8:	92407c4a 	and	x10, x2, #0xffffffff
    a4ec:	9ac90801 	udiv	x1, x0, x9
    a4f0:	9b098020 	msub	x0, x1, x9, x0
    a4f4:	9b0a7c21 	mul	x1, x1, x10
    a4f8:	93c78000 	extr	x0, x0, x7, #32
    a4fc:	eb00003f 	cmp	x1, x0
    a500:	540000a9 	b.ls	a514 <__modti3+0x234>  // b.plast
    a504:	ab000040 	adds	x0, x2, x0
    a508:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a50c:	8b020003 	add	x3, x0, x2
    a510:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a514:	cb010001 	sub	x1, x0, x1
    a518:	9ac90820 	udiv	x0, x1, x9
    a51c:	9b098403 	msub	x3, x0, x9, x1
    a520:	aa0703e1 	mov	x1, x7
    a524:	9b0a7c00 	mul	x0, x0, x10
    a528:	b3607c61 	bfi	x1, x3, #32, #32
    a52c:	eb01001f 	cmp	x0, x1
    a530:	540000a9 	b.ls	a544 <__modti3+0x264>  // b.plast
    a534:	ab010041 	adds	x1, x2, x1
    a538:	8b020022 	add	x2, x1, x2
    a53c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a540:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a544:	cb000020 	sub	x0, x1, x0
    a548:	17ffff91 	b	a38c <__modti3+0xac>
    a54c:	eb0203e5 	negs	x5, x2
    a550:	aa0003e7 	mov	x7, x0
    a554:	da0303e8 	ngc	x8, x3
    a558:	aa0503e2 	mov	x2, x5
    a55c:	aa0803e3 	mov	x3, x8
    a560:	aa0103e6 	mov	x6, x1
    a564:	b4ffed48 	cbz	x8, a30c <__modti3+0x2c>
    a568:	eb01011f 	cmp	x8, x1
    a56c:	54fff148 	b.hi	a394 <__modti3+0xb4>  // b.pmore
    a570:	dac01109 	clz	x9, x8
    a574:	2a0903e6 	mov	w6, w9
    a578:	b5fff1c9 	cbnz	x9, a3b0 <__modti3+0xd0>
    a57c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a580:	54000068 	b.hi	a58c <__modti3+0x2ac>  // b.pmore
    a584:	eb050007 	subs	x7, x0, x5
    a588:	da080021 	sbc	x1, x1, x8
    a58c:	aa0703e0 	mov	x0, x7
    a590:	17ffff81 	b	a394 <__modti3+0xb4>
    a594:	ab000040 	adds	x0, x2, x0
    a598:	8b020002 	add	x2, x0, x2
    a59c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a5a0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a5a4:	17ffff79 	b	a388 <__modti3+0xa8>
    a5a8:	9ac82042 	lsl	x2, x2, x8
    a5ac:	d2800803 	mov	x3, #0x40                  	// #64
    a5b0:	cb080063 	sub	x3, x3, x8
    a5b4:	d360fc49 	lsr	x9, x2, #32
    a5b8:	9ac82027 	lsl	x7, x1, x8
    a5bc:	92407c4a 	and	x10, x2, #0xffffffff
    a5c0:	9ac32426 	lsr	x6, x1, x3
    a5c4:	9ac32403 	lsr	x3, x0, x3
    a5c8:	aa070063 	orr	x3, x3, x7
    a5cc:	9ac908c1 	udiv	x1, x6, x9
    a5d0:	9ac82007 	lsl	x7, x0, x8
    a5d4:	9b099820 	msub	x0, x1, x9, x6
    a5d8:	9b017d41 	mul	x1, x10, x1
    a5dc:	93c38000 	extr	x0, x0, x3, #32
    a5e0:	eb00003f 	cmp	x1, x0
    a5e4:	540000a9 	b.ls	a5f8 <__modti3+0x318>  // b.plast
    a5e8:	ab000040 	adds	x0, x2, x0
    a5ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a5f0:	8b020006 	add	x6, x0, x2
    a5f4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a5f8:	cb010000 	sub	x0, x0, x1
    a5fc:	9ac90801 	udiv	x1, x0, x9
    a600:	9b098026 	msub	x6, x1, x9, x0
    a604:	aa0303e0 	mov	x0, x3
    a608:	9b017d41 	mul	x1, x10, x1
    a60c:	b3607cc0 	bfi	x0, x6, #32, #32
    a610:	eb00003f 	cmp	x1, x0
    a614:	540000a9 	b.ls	a628 <__modti3+0x348>  // b.plast
    a618:	ab000040 	adds	x0, x2, x0
    a61c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a620:	8b020003 	add	x3, x0, x2
    a624:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a628:	cb010000 	sub	x0, x0, x1
    a62c:	17ffffb0 	b	a4ec <__modti3+0x20c>
    a630:	d1000969 	sub	x9, x11, #0x2
    a634:	8b070021 	add	x1, x1, x7
    a638:	17ffff83 	b	a444 <__modti3+0x164>
    a63c:	d1000965 	sub	x5, x11, #0x2
    a640:	8b070063 	add	x3, x3, x7
    a644:	17ffff74 	b	a414 <__modti3+0x134>
    a648:	d503201f 	nop
    a64c:	d503201f 	nop

000000000000a650 <atexit>:
    a650:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a654:	d00000a2 	adrp	x2, 20000 <__data_start>
    a658:	d2800001 	mov	x1, #0x0                   	// #0
    a65c:	910003fd 	mov	x29, sp
    a660:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a664:	f9400442 	ldr	x2, [x2, #8]
    a668:	17ffe046 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a66c <_fini>:
    a66c:	d503201f 	nop
    a670:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a674:	910003fd 	mov	x29, sp
    a678:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a67c:	d65f03c0 	ret
