
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	90000045 	adrp	x5, a000 <fwp_main_thread+0x1f10>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	913720a5 	add	x5, x5, #0xdc8
    2b20:	90000044 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91374084 	add	x4, x4, #0xdd0
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11338>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2bb4:	9106a000 	add	x0, x0, #0x1a8
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xefc>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	9103c042 	add	x2, x2, #0xf0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9437a60 	ldr	w0, [x19, #888]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2cfc:	9106e000 	add	x0, x0, #0x1b8
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2d0c:	91096000 	add	x0, x0, #0x258
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2d24:	9108c000 	add	x0, x0, #0x230
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2d30:	91080000 	add	x0, x0, #0x200
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    2d3c:	91076000 	add	x0, x0, #0x1d8
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    2f34:	91238021 	add	x1, x1, #0x8e0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    30d0:	912c6000 	add	x0, x0, #0xb18
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    3198:	91230021 	add	x1, x1, #0x8c0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    31d0:	912cc000 	add	x0, x0, #0xb30
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1f10>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x1f10>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x4f0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	912de042 	add	x2, x2, #0xb78
    3260:	912f42d6 	add	x22, x22, #0xbd0
    3264:	91198318 	add	x24, x24, #0x660
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x1f10>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	912f2323 	add	x3, x25, #0xbc8
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	912f8000 	add	x0, x0, #0xbe0
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    3344:	9117c2a1 	add	x1, x21, #0x5f0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    3358:	912780a5 	add	x5, x5, #0x9e0
    335c:	9117c2a1 	add	x1, x21, #0x5f0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	9117c2b7 	add	x23, x21, #0x5f0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	9117c2b5 	add	x21, x21, #0x5f0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	9117c2b5 	add	x21, x21, #0x5f0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa10>
    34e8:	912760a5 	add	x5, x5, #0x9d8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    35f0:	912c6000 	add	x0, x0, #0xb18
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    3830:	aa1303e0 	mov	x0, x19
    3834:	912fa021 	add	x1, x1, #0xbe8
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    3844:	aa1303e0 	mov	x0, x19
    3848:	912fc021 	add	x1, x1, #0xbf0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    3860:	912fe021 	add	x1, x1, #0xbf8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1f10>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	91300042 	add	x2, x2, #0xc00
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    39d0:	912c6000 	add	x0, x0, #0xb18
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    39f0:	91304000 	add	x0, x0, #0xc10
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    3a88:	9130c000 	add	x0, x0, #0xc30
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    3a98:	91314000 	add	x0, x0, #0xc50
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc23c20 	ldr	q0, [x1, #2288]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    3b98:	9131e000 	add	x0, x0, #0xc78
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    3c08:	9132a000 	add	x0, x0, #0xca8
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9133e084 	add	x4, x4, #0xcf8
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91344084 	add	x4, x4, #0xd10
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91340084 	add	x4, x4, #0xd00
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    4028:	9117c042 	add	x2, x2, #0x5f0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	d0000021 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	91346021 	add	x1, x1, #0xd18
    4084:	91348000 	add	x0, x0, #0xd20
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	d0000022 	adrp	x2, a000 <fwp_main_thread+0x1f10>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91350042 	add	x2, x2, #0xd40
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa10>
    418c:	9113c061 	add	x1, x3, #0x4f0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    419c:	9117c262 	add	x2, x19, #0x5f0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x4f0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa10>
    41cc:	9114c021 	add	x1, x1, #0x530
    41d0:	3dc24043 	ldr	q3, [x2, #2304]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa10>
    41fc:	9113c063 	add	x3, x3, #0x4f0
    4200:	91164084 	add	x4, x4, #0x590
    4204:	9117c266 	add	x6, x19, #0x5f0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	9117c275 	add	x21, x19, #0x5f0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    42e8:	9137c000 	add	x0, x0, #0xdf0
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	9117c273 	add	x19, x19, #0x5f0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <caf75>:
    4344:	900000e2 	adrp	x2, 20000 <__data_start>
    4348:	9101c041 	add	x1, x2, #0x70
    434c:	b9409820 	ldr	w0, [x1, #152]
    4350:	34000060 	cbz	w0, 435c <caf75+0x18>
    4354:	f9405020 	ldr	x0, [x1, #160]
    4358:	d65f03c0 	ret
    435c:	b940a820 	ldr	w0, [x1, #168]
    4360:	340000e0 	cbz	w0, 437c <caf75+0x38>
    4364:	f9405820 	ldr	x0, [x1, #176]
    4368:	9101c042 	add	x2, x2, #0x70
    436c:	52800021 	mov	w1, #0x1                   	// #1
    4370:	b9009841 	str	w1, [x2, #152]
    4374:	f9005040 	str	x0, [x2, #160]
    4378:	d65f03c0 	ret
    437c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4380:	52800024 	mov	w4, #0x1                   	// #1
    4384:	aa0303e0 	mov	x0, x3
    4388:	b900a824 	str	w4, [x1, #168]
    438c:	f9005823 	str	x3, [x1, #176]
    4390:	17fffff6 	b	4368 <caf75+0x24>

0000000000004394 <fwp_wake_io>:
    4394:	900000e9 	adrp	x9, 20000 <__data_start>
    4398:	9101c122 	add	x2, x9, #0x70
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	5280000a 	mov	w10, #0x0                   	// #0
    43a4:	f9403c46 	ldr	x6, [x2, #120]
    43a8:	52800008 	mov	w8, #0x0                   	// #0
    43ac:	4f000400 	movi	v0.4s, #0x0
    43b0:	52800027 	mov	w7, #0x1                   	// #1
    43b4:	aa0103e2 	mov	x2, x1
    43b8:	b4000321 	cbz	x1, 441c <fwp_wake_io+0x88>
    43bc:	f9408c25 	ldr	x5, [x1, #280]
    43c0:	39015c27 	strb	w7, [x1, #87]
    43c4:	b4000165 	cbz	x5, 43f0 <fwp_wake_io+0x5c>
    43c8:	a9520c24 	ldp	x4, x3, [x1, #288]
    43cc:	b4000364 	cbz	x4, 4438 <fwp_wake_io+0xa4>
    43d0:	f9009483 	str	x3, [x4, #296]
    43d4:	f9409423 	ldr	x3, [x1, #296]
    43d8:	b4000043 	cbz	x3, 43e0 <fwp_wake_io+0x4c>
    43dc:	f9009064 	str	x4, [x3, #288]
    43e0:	91080023 	add	x3, x1, #0x200
    43e4:	f900943f 	str	xzr, [x1, #296]
    43e8:	3c918060 	stur	q0, [x3, #-232]
    43ec:	f9400001 	ldr	x1, [x0]
    43f0:	f9402843 	ldr	x3, [x2, #80]
    43f4:	f2001c7f 	tst	x3, #0xff000000ff
    43f8:	54fffde1 	b.ne	43b4 <fwp_wake_io+0x20>  // b.any
    43fc:	39015047 	strb	w7, [x2, #84]
    4400:	f900805f 	str	xzr, [x2, #256]
    4404:	b40001e6 	cbz	x6, 4440 <fwp_wake_io+0xac>
    4408:	f90080c2 	str	x2, [x6, #256]
    440c:	aa0203e6 	mov	x6, x2
    4410:	52800028 	mov	w8, #0x1                   	// #1
    4414:	aa0103e2 	mov	x2, x1
    4418:	b5fffd21 	cbnz	x1, 43bc <fwp_wake_io+0x28>
    441c:	3400006a 	cbz	w10, 4428 <fwp_wake_io+0x94>
    4420:	9101c120 	add	x0, x9, #0x70
    4424:	f900400b 	str	x11, [x0, #128]
    4428:	34000068 	cbz	w8, 4434 <fwp_wake_io+0xa0>
    442c:	9101c129 	add	x9, x9, #0x70
    4430:	f9003d26 	str	x6, [x9, #120]
    4434:	d65f03c0 	ret
    4438:	f90000a3 	str	x3, [x5]
    443c:	17ffffe7 	b	43d8 <fwp_wake_io+0x44>
    4440:	aa0203eb 	mov	x11, x2
    4444:	5280002a 	mov	w10, #0x1                   	// #1
    4448:	17fffff1 	b	440c <fwp_wake_io+0x78>
    444c:	d503201f 	nop

0000000000004450 <fwp_tape_buffers_release>:
    4450:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4454:	910003fd 	mov	x29, sp
    4458:	a90153f3 	stp	x19, x20, [sp, #16]
    445c:	aa0003f3 	mov	x19, x0
    4460:	f9401400 	ldr	x0, [x0, #40]
    4464:	b7f80760 	tbnz	x0, #63, 4550 <fwp_tape_buffers_release+0x100>
    4468:	f9401a61 	ldr	x1, [x19, #48]
    446c:	b7f80301 	tbnz	x1, #63, 44cc <fwp_tape_buffers_release+0x7c>
    4470:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4474:	eb02001f 	cmp	x0, x2
    4478:	540002a8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    447c:	8b000400 	add	x0, x0, x0, lsl #1
    4480:	d2a00102 	mov	x2, #0x80000               	// #524288
    4484:	d37df000 	lsl	x0, x0, #3
    4488:	cb000042 	sub	x2, x2, x0
    448c:	eb420c3f 	cmp	x1, x2, lsr #3
    4490:	540001e8 	b.hi	44cc <fwp_tape_buffers_release+0x7c>  // b.pmore
    4494:	8b010c14 	add	x20, x0, x1, lsl #3
    4498:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    449c:	91380000 	add	x0, x0, #0xe00
    44a0:	97fff980 	bl	2aa0 <getenv@plt>
    44a4:	b4000240 	cbz	x0, 44ec <fwp_tape_buffers_release+0x9c>
    44a8:	39400001 	ldrb	w1, [x0]
    44ac:	7100c03f 	cmp	w1, #0x30
    44b0:	540001e1 	b.ne	44ec <fwp_tape_buffers_release+0x9c>  // b.any
    44b4:	39400400 	ldrb	w0, [x0, #1]
    44b8:	350001a0 	cbnz	w0, 44ec <fwp_tape_buffers_release+0x9c>
    44bc:	aa1303e0 	mov	x0, x19
    44c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c8:	17fffc0e 	b	3500 <fwp_tape_buffers_dispose>
    44cc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    44d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    44d4:	91380000 	add	x0, x0, #0xe00
    44d8:	97fff972 	bl	2aa0 <getenv@plt>
    44dc:	b4ffff00 	cbz	x0, 44bc <fwp_tape_buffers_release+0x6c>
    44e0:	39400001 	ldrb	w1, [x0]
    44e4:	7100c03f 	cmp	w1, #0x30
    44e8:	54fffe60 	b.eq	44b4 <fwp_tape_buffers_release+0x64>  // b.none
    44ec:	d1000681 	sub	x1, x20, #0x1
    44f0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44f4:	eb00003f 	cmp	x1, x0
    44f8:	54fffe28 	b.hi	44bc <fwp_tape_buffers_release+0x6c>  // b.pmore
    44fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4500:	900000f6 	adrp	x22, 20000 <__data_start>
    4504:	9101c2d6 	add	x22, x22, #0x70
    4508:	9102e2d5 	add	x21, x22, #0xb8
    450c:	aa1503e0 	mov	x0, x21
    4510:	97fffbfc 	bl	3500 <fwp_tape_buffers_dispose>
    4514:	ad400a61 	ldp	q1, q2, [x19]
    4518:	f9007ad4 	str	x20, [x22, #240]
    451c:	4f000400 	movi	v0.4s, #0x0
    4520:	ad000aa1 	stp	q1, q2, [x21]
    4524:	3dc00a61 	ldr	q1, [x19, #32]
    4528:	3d800aa1 	str	q1, [x21, #32]
    452c:	f9401a60 	ldr	x0, [x19, #48]
    4530:	f9001aa0 	str	x0, [x21, #48]
    4534:	f9001a7f 	str	xzr, [x19, #48]
    4538:	ad000260 	stp	q0, q0, [x19]
    453c:	3d800a60 	str	q0, [x19, #32]
    4540:	a94153f3 	ldp	x19, x20, [sp, #16]
    4544:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4548:	a8c37bfd 	ldp	x29, x30, [sp], #48
    454c:	d65f03c0 	ret
    4550:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    4554:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4558:	91380000 	add	x0, x0, #0xe00
    455c:	97fff951 	bl	2aa0 <getenv@plt>
    4560:	b5fffa40 	cbnz	x0, 44a8 <fwp_tape_buffers_release+0x58>
    4564:	17ffffd6 	b	44bc <fwp_tape_buffers_release+0x6c>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_poll_events>:
    4570:	d10103ff 	sub	sp, sp, #0x40
    4574:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4578:	f947f400 	ldr	x0, [x0, #4072]
    457c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4580:	910083fd 	add	x29, sp, #0x20
    4584:	a90353f3 	stp	x19, x20, [sp, #48]
    4588:	900000f4 	adrp	x20, 20000 <__data_start>
    458c:	f9400001 	ldr	x1, [x0]
    4590:	f9000fe1 	str	x1, [sp, #24]
    4594:	d2800001 	mov	x1, #0x0                   	// #0
    4598:	97fffd1a 	bl	3a00 <fwp_now_ns>
    459c:	9101c281 	add	x1, x20, #0x70
    45a0:	f9407c33 	ldr	x19, [x1, #248]
    45a4:	b4000e93 	cbz	x19, 4774 <fwp_poll_events+0x204>
    45a8:	aa1303e1 	mov	x1, x19
    45ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    45b0:	14000005 	b	45c4 <fwp_poll_events+0x54>
    45b4:	f9408821 	ldr	x1, [x1, #272]
    45b8:	eb03005f 	cmp	x2, x3
    45bc:	9a83d042 	csel	x2, x2, x3, le
    45c0:	b40000c1 	cbz	x1, 45d8 <fwp_poll_events+0x68>
    45c4:	f9403423 	ldr	x3, [x1, #104]
    45c8:	b6ffff62 	tbz	x2, #63, 45b4 <fwp_poll_events+0x44>
    45cc:	f9408821 	ldr	x1, [x1, #272]
    45d0:	aa0303e2 	mov	x2, x3
    45d4:	b5ffff81 	cbnz	x1, 45c4 <fwp_poll_events+0x54>
    45d8:	b7f80ce2 	tbnz	x2, #63, 4774 <fwp_poll_events+0x204>
    45dc:	cb000042 	sub	x2, x2, x0
    45e0:	f100005f 	cmp	x2, #0x0
    45e4:	540005cd 	b.le	469c <fwp_poll_events+0x12c>
    45e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    45ec:	d2884801 	mov	x1, #0x4240                	// #16960
    45f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4600:	f2e86360 	movk	x0, #0x431b, lsl #48
    4604:	9b407c40 	smulh	x0, x2, x0
    4608:	9352fc00 	asr	x0, x0, #18
    460c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4610:	9b018802 	msub	x2, x0, x1, x2
    4614:	f100005f 	cmp	x2, #0x0
    4618:	9a800400 	cinc	x0, x0, ne	// ne = any
    461c:	eb03001f 	cmp	x0, x3
    4620:	54000a0c 	b.gt	4760 <fwp_poll_events+0x1f0>
    4624:	340003c0 	cbz	w0, 469c <fwp_poll_events+0x12c>
    4628:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    462c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4630:	72a20c42 	movk	w2, #0x1062, lsl #16
    4634:	9ba27c02 	umull	x2, w0, w2
    4638:	d366fc43 	lsr	x3, x2, #38
    463c:	aa0303e2 	mov	x2, x3
    4640:	1b048063 	msub	w3, w3, w4, w0
    4644:	9b217c63 	smull	x3, w3, w1
    4648:	d2800001 	mov	x1, #0x0                   	// #0
    464c:	910023e0 	add	x0, sp, #0x8
    4650:	a9008fe2 	stp	x2, x3, [sp, #8]
    4654:	97fff8e3 	bl	29e0 <nanosleep@plt>
    4658:	9101c280 	add	x0, x20, #0x70
    465c:	f9407c13 	ldr	x19, [x0, #248]
    4660:	97fffce8 	bl	3a00 <fwp_now_ns>
    4664:	aa0003e6 	mov	x6, x0
    4668:	b50001f3 	cbnz	x19, 46a4 <fwp_poll_events+0x134>
    466c:	d503201f 	nop
    4670:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4674:	f947f400 	ldr	x0, [x0, #4072]
    4678:	f9400fe2 	ldr	x2, [sp, #24]
    467c:	f9400001 	ldr	x1, [x0]
    4680:	eb010042 	subs	x2, x2, x1
    4684:	d2800001 	mov	x1, #0x0                   	// #0
    4688:	540008c1 	b.ne	47a0 <fwp_poll_events+0x230>  // b.any
    468c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4690:	a94353f3 	ldp	x19, x20, [sp, #48]
    4694:	910103ff 	add	sp, sp, #0x40
    4698:	d65f03c0 	ret
    469c:	97fffcd9 	bl	3a00 <fwp_now_ns>
    46a0:	aa0003e6 	mov	x6, x0
    46a4:	4f000400 	movi	v0.4s, #0x0
    46a8:	9101c288 	add	x8, x20, #0x70
    46ac:	52800027 	mov	w7, #0x1                   	// #1
    46b0:	f9403661 	ldr	x1, [x19, #104]
    46b4:	aa1303e5 	mov	x5, x19
    46b8:	f9408a73 	ldr	x19, [x19, #272]
    46bc:	eb06003f 	cmp	x1, x6
    46c0:	5400032c 	b.gt	4724 <fwp_poll_events+0x1b4>
    46c4:	394154a0 	ldrb	w0, [x5, #85]
    46c8:	36000120 	tbz	w0, #0, 46ec <fwp_poll_events+0x17c>
    46cc:	f94084a0 	ldr	x0, [x5, #264]
    46d0:	b40003c0 	cbz	x0, 4748 <fwp_poll_events+0x1d8>
    46d4:	f9008813 	str	x19, [x0, #272]
    46d8:	b4000053 	cbz	x19, 46e0 <fwp_poll_events+0x170>
    46dc:	f9008660 	str	x0, [x19, #264]
    46e0:	910800a0 	add	x0, x5, #0x200
    46e4:	390154bf 	strb	wzr, [x5, #85]
    46e8:	3c908000 	stur	q0, [x0, #-248]
    46ec:	f94030a0 	ldr	x0, [x5, #96]
    46f0:	390158a7 	strb	w7, [x5, #86]
    46f4:	f100001f 	cmp	x0, #0x0
    46f8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46fc:	5400018d 	b.le	472c <fwp_poll_events+0x1bc>
    4700:	f94028a0 	ldr	x0, [x5, #80]
    4704:	f2001c1f 	tst	x0, #0xff000000ff
    4708:	540000e1 	b.ne	4724 <fwp_poll_events+0x1b4>  // b.any
    470c:	f9403d00 	ldr	x0, [x8, #120]
    4710:	390150a7 	strb	w7, [x5, #84]
    4714:	f90080bf 	str	xzr, [x5, #256]
    4718:	b40001e0 	cbz	x0, 4754 <fwp_poll_events+0x1e4>
    471c:	f9003d05 	str	x5, [x8, #120]
    4720:	f9008005 	str	x5, [x0, #256]
    4724:	b5fffc73 	cbnz	x19, 46b0 <fwp_poll_events+0x140>
    4728:	17ffffd2 	b	4670 <fwp_poll_events+0x100>
    472c:	394144a0 	ldrb	w0, [x5, #81]
    4730:	3707fe80 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    4734:	394140a0 	ldrb	w0, [x5, #80]
    4738:	3707fe40 	tbnz	w0, #0, 4700 <fwp_poll_events+0x190>
    473c:	aa0503e0 	mov	x0, x5
    4740:	97fffc0c 	bl	3770 <fwp_cancel_tree.part.0>
    4744:	17ffffef 	b	4700 <fwp_poll_events+0x190>
    4748:	9101c281 	add	x1, x20, #0x70
    474c:	f9007c33 	str	x19, [x1, #248]
    4750:	17ffffe2 	b	46d8 <fwp_poll_events+0x168>
    4754:	f9003d05 	str	x5, [x8, #120]
    4758:	f9004105 	str	x5, [x8, #128]
    475c:	17fffff2 	b	4724 <fwp_poll_events+0x1b4>
    4760:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4764:	d2989362 	mov	x2, #0xc49b                	// #50331
    4768:	f2a4d203 	movk	x3, #0x2690, lsl #16
    476c:	f2a00402 	movk	x2, #0x20, lsl #16
    4770:	17ffffb6 	b	4648 <fwp_poll_events+0xd8>
    4774:	97fffa3f 	bl	3070 <fwp_flush>
    4778:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    477c:	f947e863 	ldr	x3, [x3, #4048]
    4780:	d2800562 	mov	x2, #0x2b                  	// #43
    4784:	d2800021 	mov	x1, #0x1                   	// #1
    4788:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    478c:	91386000 	add	x0, x0, #0xe18
    4790:	f9400063 	ldr	x3, [x3]
    4794:	97fff89f 	bl	2a10 <fwrite@plt>
    4798:	52800ca0 	mov	w0, #0x65                  	// #101
    479c:	97fff809 	bl	27c0 <exit@plt>
    47a0:	97fff85c 	bl	2910 <__stack_chk_fail@plt>

00000000000047a4 <fwp_rc_wide_dup>:
    47a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    47a8:	910003fd 	mov	x29, sp
    47ac:	a90153f3 	stp	x19, x20, [sp, #16]
    47b0:	aa0003f3 	mov	x19, x0
    47b4:	ca404400 	eor	x0, x0, x0, lsr #17
    47b8:	f90013f5 	str	x21, [sp, #32]
    47bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    47c0:	ca402400 	eor	x0, x0, x0, lsr #9
    47c4:	9117c2a2 	add	x2, x21, #0x5f0
    47c8:	92401c00 	and	x0, x0, #0xff
    47cc:	910a2403 	add	x3, x0, #0x289
    47d0:	8b000c40 	add	x0, x2, x0, lsl #3
    47d4:	8b030c54 	add	x20, x2, x3, lsl #3
    47d8:	f94a2401 	ldr	x1, [x0, #5192]
    47dc:	b50000a1 	cbnz	x1, 47f0 <fwp_rc_wide_dup+0x4c>
    47e0:	1400002d 	b	4894 <fwp_rc_wide_dup+0xf0>
    47e4:	91004034 	add	x20, x1, #0x10
    47e8:	f9400821 	ldr	x1, [x1, #16]
    47ec:	b4000241 	cbz	x1, 4834 <fwp_rc_wide_dup+0x90>
    47f0:	f9400022 	ldr	x2, [x1]
    47f4:	eb02027f 	cmp	x19, x2
    47f8:	54ffff61 	b.ne	47e4 <fwp_rc_wide_dup+0x40>  // b.any
    47fc:	f9400281 	ldr	x1, [x20]
    4800:	39400260 	ldrb	w0, [x19]
    4804:	7103f81f 	cmp	w0, #0xfe
    4808:	54000220 	b.eq	484c <fwp_rc_wide_dup+0xa8>  // b.none
    480c:	b40001a1 	cbz	x1, 4840 <fwp_rc_wide_dup+0x9c>
    4810:	f9400420 	ldr	x0, [x1, #8]
    4814:	b100041f 	cmn	x0, #0x1
    4818:	540004a0 	b.eq	48ac <fwp_rc_wide_dup+0x108>  // b.none
    481c:	91000400 	add	x0, x0, #0x1
    4820:	f9000420 	str	x0, [x1, #8]
    4824:	a94153f3 	ldp	x19, x20, [sp, #16]
    4828:	f94013f5 	ldr	x21, [sp, #32]
    482c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4830:	d65f03c0 	ret
    4834:	39400260 	ldrb	w0, [x19]
    4838:	7103f81f 	cmp	w0, #0xfe
    483c:	540000a0 	b.eq	4850 <fwp_rc_wide_dup+0xac>  // b.none
    4840:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    4844:	9139c000 	add	x0, x0, #0xe70
    4848:	97fffc0e 	bl	3880 <fwp_trap>
    484c:	b5000281 	cbnz	x1, 489c <fwp_rc_wide_dup+0xf8>
    4850:	d2800300 	mov	x0, #0x18                  	// #24
    4854:	97fff817 	bl	28b0 <malloc@plt>
    4858:	b4000280 	cbz	x0, 48a8 <fwp_rc_wide_dup+0x104>
    485c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4860:	a9000413 	stp	x19, x1, [x0]
    4864:	9117c2b5 	add	x21, x21, #0x5f0
    4868:	f900081f 	str	xzr, [x0, #16]
    486c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4870:	f9000280 	str	x0, [x20]
    4874:	39000261 	strb	w1, [x19]
    4878:	f94e26a0 	ldr	x0, [x21, #7240]
    487c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4880:	91000400 	add	x0, x0, #0x1
    4884:	f90e26a0 	str	x0, [x21, #7240]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4898:	17ffffda 	b	4800 <fwp_rc_wide_dup+0x5c>
    489c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    48a0:	91392000 	add	x0, x0, #0xe48
    48a4:	97fffbf7 	bl	3880 <fwp_trap>
    48a8:	97fffa02 	bl	30b0 <fwp_heap_oom>
    48ac:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    48b0:	913a6000 	add	x0, x0, #0xe98
    48b4:	97fffbf3 	bl	3880 <fwp_trap>
    48b8:	d503201f 	nop
    48bc:	d503201f 	nop

00000000000048c0 <fwp_rc_forget_slot>:
    48c0:	aa0003e1 	mov	x1, x0
    48c4:	39400000 	ldrb	w0, [x0]
    48c8:	7103fc1f 	cmp	w0, #0xff
    48cc:	54000040 	b.eq	48d4 <fwp_rc_forget_slot+0x14>  // b.none
    48d0:	d65f03c0 	ret
    48d4:	ca414420 	eor	x0, x1, x1, lsr #17
    48d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    48dc:	ca402400 	eor	x0, x0, x0, lsr #9
    48e0:	910003fd 	mov	x29, sp
    48e4:	92401c00 	and	x0, x0, #0xff
    48e8:	f9000bf3 	str	x19, [sp, #16]
    48ec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    48f0:	9117c262 	add	x2, x19, #0x5f0
    48f4:	910a2403 	add	x3, x0, #0x289
    48f8:	8b000c40 	add	x0, x2, x0, lsl #3
    48fc:	8b030c43 	add	x3, x2, x3, lsl #3
    4900:	f94a2400 	ldr	x0, [x0, #5192]
    4904:	b50000a0 	cbnz	x0, 4918 <fwp_rc_forget_slot+0x58>
    4908:	14000011 	b	494c <fwp_rc_forget_slot+0x8c>
    490c:	91004003 	add	x3, x0, #0x10
    4910:	f9400800 	ldr	x0, [x0, #16]
    4914:	b40001c0 	cbz	x0, 494c <fwp_rc_forget_slot+0x8c>
    4918:	f9400002 	ldr	x2, [x0]
    491c:	eb02003f 	cmp	x1, x2
    4920:	54ffff61 	b.ne	490c <fwp_rc_forget_slot+0x4c>  // b.any
    4924:	f9400801 	ldr	x1, [x0, #16]
    4928:	9117c273 	add	x19, x19, #0x5f0
    492c:	f9000061 	str	x1, [x3]
    4930:	97fff828 	bl	29d0 <free@plt>
    4934:	f94e2660 	ldr	x0, [x19, #7240]
    4938:	d1000400 	sub	x0, x0, #0x1
    493c:	f90e2660 	str	x0, [x19, #7240]
    4940:	f9400bf3 	ldr	x19, [sp, #16]
    4944:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4948:	d65f03c0 	ret
    494c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    4950:	9139c000 	add	x0, x0, #0xe70
    4954:	97fffbcb 	bl	3880 <fwp_trap>
    4958:	d503201f 	nop
    495c:	d503201f 	nop

0000000000004960 <fwp_rc_prepare_chunk>:
    4960:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4964:	910003fd 	mov	x29, sp
    4968:	a9025bf5 	stp	x21, x22, [sp, #32]
    496c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    4970:	9117c2c2 	add	x2, x22, #0x5f0
    4974:	b9401c03 	ldr	w3, [x0, #28]
    4978:	aa0103f5 	mov	x21, x1
    497c:	a90153f3 	stp	x19, x20, [sp, #16]
    4980:	aa0003f4 	mov	x20, x0
    4984:	f94e2440 	ldr	x0, [x2, #7240]
    4988:	b4000440 	cbz	x0, 4a10 <fwp_rc_prepare_chunk+0xb0>
    498c:	d2800013 	mov	x19, #0x0                   	// #0
    4990:	35000203 	cbnz	w3, 49d0 <fwp_rc_prepare_chunk+0x70>
    4994:	b4000361 	cbz	x1, 4a00 <fwp_rc_prepare_chunk+0xa0>
    4998:	f9401280 	ldr	x0, [x20, #32]
    499c:	97fff80d 	bl	29d0 <free@plt>
    49a0:	aa1503e0 	mov	x0, x21
    49a4:	d2800021 	mov	x1, #0x1                   	// #1
    49a8:	97fff7d2 	bl	28f0 <calloc@plt>
    49ac:	f9001280 	str	x0, [x20, #32]
    49b0:	b5000460 	cbnz	x0, 4a3c <fwp_rc_prepare_chunk+0xdc>
    49b4:	97fff9bf 	bl	30b0 <fwp_heap_oom>
    49b8:	97ffffc2 	bl	48c0 <fwp_rc_forget_slot>
    49bc:	91000673 	add	x19, x19, #0x1
    49c0:	b9401e83 	ldr	w3, [x20, #28]
    49c4:	eb13007f 	cmp	x3, x19
    49c8:	54000169 	b.ls	49f4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    49cc:	d503201f 	nop
    49d0:	f9401283 	ldr	x3, [x20, #32]
    49d4:	8b130060 	add	x0, x3, x19
    49d8:	38736863 	ldrb	w3, [x3, x19]
    49dc:	7103fc7f 	cmp	w3, #0xff
    49e0:	54fffec0 	b.eq	49b8 <fwp_rc_prepare_chunk+0x58>  // b.none
    49e4:	b9401e83 	ldr	w3, [x20, #28]
    49e8:	91000673 	add	x19, x19, #0x1
    49ec:	eb13007f 	cmp	x3, x19
    49f0:	54ffff08 	b.hi	49d0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49f4:	eb0302bf 	cmp	x21, x3
    49f8:	54000121 	b.ne	4a1c <fwp_rc_prepare_chunk+0xbc>  // b.any
    49fc:	b5000335 	cbnz	x21, 4a60 <fwp_rc_prepare_chunk+0x100>
    4a00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	2a0303e3 	mov	w3, w3
    4a14:	eb0302bf 	cmp	x21, x3
    4a18:	54ffff20 	b.eq	49fc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4a1c:	9117c2c2 	add	x2, x22, #0x5f0
    4a20:	f9401280 	ldr	x0, [x20, #32]
    4a24:	f94e2841 	ldr	x1, [x2, #7248]
    4a28:	cb030021 	sub	x1, x1, x3
    4a2c:	f90e2841 	str	x1, [x2, #7248]
    4a30:	97fff7e8 	bl	29d0 <free@plt>
    4a34:	b5fffb75 	cbnz	x21, 49a0 <fwp_rc_prepare_chunk+0x40>
    4a38:	f900129f 	str	xzr, [x20, #32]
    4a3c:	9117c2d6 	add	x22, x22, #0x5f0
    4a40:	f94e2ac0 	ldr	x0, [x22, #7248]
    4a44:	b9001e95 	str	w21, [x20, #28]
    4a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a4c:	8b150000 	add	x0, x0, x21
    4a50:	f90e2ac0 	str	x0, [x22, #7248]
    4a54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a5c:	d65f03c0 	ret
    4a60:	f9401280 	ldr	x0, [x20, #32]
    4a64:	aa1503e2 	mov	x2, x21
    4a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a6c:	52800001 	mov	w1, #0x0                   	// #0
    4a70:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a78:	17fff79a 	b	28e0 <memset@plt>
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_heap_refill>:
    4a80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a8c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4a90:	9117c2b5 	add	x21, x21, #0x5f0
    4a94:	aa0003f6 	mov	x22, x0
    4a98:	d2800020 	mov	x0, #0x1                   	// #1
    4a9c:	a90153f3 	stp	x19, x20, [sp, #16]
    4aa0:	a90363f7 	stp	x23, x24, [sp, #48]
    4aa4:	2a0103f7 	mov	w23, w1
    4aa8:	2a0203f8 	mov	w24, w2
    4aac:	97fffa21 	bl	3330 <fwp_heap_chunks>
    4ab0:	aa0003f3 	mov	x19, x0
    4ab4:	f949fea2 	ldr	x2, [x21, #5112]
    4ab8:	8b000800 	add	x0, x0, x0, lsl #2
    4abc:	2a1703e1 	mov	w1, w23
    4ac0:	52800025 	mov	w5, #0x1                   	// #1
    4ac4:	d37df000 	lsl	x0, x0, #3
    4ac8:	910f0021 	add	x1, x1, #0x3c0
    4acc:	8b000054 	add	x20, x2, x0
    4ad0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ad4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ad8:	38206845 	strb	w5, [x2, x0]
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	39000698 	strb	w24, [x20, #1]
    4ae4:	39000a97 	strb	w23, [x20, #2]
    4ae8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4aec:	b9000681 	str	w1, [x20, #4]
    4af0:	2a0103e5 	mov	w5, w1
    4af4:	8b0300a2 	add	x2, x5, x3
    4af8:	1ac10881 	udiv	w1, w4, w1
    4afc:	9ac50842 	udiv	x2, x2, x5
    4b00:	b9000a81 	str	w1, [x20, #8]
    4b04:	92404021 	and	x1, x1, #0x1ffff
    4b08:	b9001a82 	str	w2, [x20, #24]
    4b0c:	97ffff95 	bl	4960 <fwp_rc_prepare_chunk>
    4b10:	f949daa0 	ldr	x0, [x21, #5040]
    4b14:	29408a81 	ldp	w1, w2, [x20, #4]
    4b18:	8b134000 	add	x0, x0, x19, lsl #16
    4b1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b20:	8b214003 	add	x3, x0, w1, uxtw
    4b24:	9ba20021 	umaddl	x1, w1, w2, x0
    4b28:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b2c:	a90086c3 	stp	x3, x1, [x22, #8]
    4b30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b38:	d65f03c0 	ret
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_mem_free>:
    4b40:	b40003c0 	cbz	x0, 4bb8 <fwp_mem_free+0x78>
    4b44:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4b48:	910003fd 	mov	x29, sp
    4b4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b50:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    4b54:	9117c2a1 	add	x1, x21, #0x5f0
    4b58:	a90153f3 	stp	x19, x20, [sp, #16]
    4b5c:	aa0003f3 	mov	x19, x0
    4b60:	f949d823 	ldr	x3, [x1, #5040]
    4b64:	f949ec22 	ldr	x2, [x1, #5080]
    4b68:	cb030000 	sub	x0, x0, x3
    4b6c:	eb02401f 	cmp	x0, x2, lsl #16
    4b70:	540001c2 	b.cs	4ba8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b74:	d350fc16 	lsr	x22, x0, #16
    4b78:	a90363f7 	stp	x23, x24, [sp, #48]
    4b7c:	f949fc22 	ldr	x2, [x1, #5112]
    4b80:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b84:	d37df294 	lsl	x20, x20, #3
    4b88:	ab140057 	adds	x23, x2, x20
    4b8c:	540000c0 	b.eq	4ba4 <fwp_mem_free+0x64>  // b.none
    4b90:	38746842 	ldrb	w2, [x2, x20]
    4b94:	7100045f 	cmp	w2, #0x1
    4b98:	54000120 	b.eq	4bbc <fwp_mem_free+0x7c>  // b.none
    4b9c:	7100085f 	cmp	w2, #0x2
    4ba0:	540005e0 	b.eq	4c5c <fwp_mem_free+0x11c>  // b.none
    4ba4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bb0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4bb4:	d65f03c0 	ret
    4bb8:	d65f03c0 	ret
    4bbc:	f94012f8 	ldr	x24, [x23, #32]
    4bc0:	b94006e1 	ldr	w1, [x23, #4]
    4bc4:	f90023f9 	str	x25, [sp, #64]
    4bc8:	2a0103e2 	mov	w2, w1
    4bcc:	394006f9 	ldrb	w25, [x23, #1]
    4bd0:	39400af4 	ldrb	w20, [x23, #2]
    4bd4:	b4000158 	cbz	x24, 4bfc <fwp_mem_free+0xbc>
    4bd8:	92403e76 	and	x22, x19, #0xffff
    4bdc:	9ac20ad6 	udiv	x22, x22, x2
    4be0:	38766b01 	ldrb	w1, [x24, x22]
    4be4:	8b160300 	add	x0, x24, x22
    4be8:	7103fc3f 	cmp	w1, #0xff
    4bec:	54000980 	b.eq	4d1c <fwp_mem_free+0x1dc>  // b.none
    4bf0:	38366b1f 	strb	wzr, [x24, x22]
    4bf4:	b94006e1 	ldr	w1, [x23, #4]
    4bf8:	2a0103e2 	mov	w2, w1
    4bfc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4c00:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4c04:	cb390000 	sub	x0, x0, w25, uxtb
    4c08:	8b340074 	add	x20, x3, w20, uxtb
    4c0c:	9117c2b5 	add	x21, x21, #0x5f0
    4c10:	1e630021 	ucvtf	d1, w1
    4c14:	d37ae400 	lsl	x0, x0, #6
    4c18:	8b140c14 	add	x20, x0, x20, lsl #3
    4c1c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c20:	f8746aa0 	ldr	x0, [x21, x20]
    4c24:	f94023f9 	ldr	x25, [sp, #64]
    4c28:	aa2003e0 	mvn	x0, x0
    4c2c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4c30:	f9000260 	str	x0, [x19]
    4c34:	f8346ab3 	str	x19, [x21, x20]
    4c38:	f94a12a0 	ldr	x0, [x21, #5152]
    4c3c:	1e612800 	fadd	d0, d0, d1
    4c40:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c44:	cb020000 	sub	x0, x0, x2
    4c48:	f90a12a0 	str	x0, [x21, #5152]
    4c4c:	fd0a22a0 	str	d0, [x21, #5184]
    4c50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c54:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c58:	d65f03c0 	ret
    4c5c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c60:	8b000063 	add	x3, x3, x0
    4c64:	eb03027f 	cmp	x19, x3
    4c68:	54fff9e1 	b.ne	4ba4 <fwp_mem_free+0x64>  // b.any
    4c6c:	fd400ae1 	ldr	d1, [x23, #16]
    4c70:	fd4a2020 	ldr	d0, [x1, #5184]
    4c74:	f9400ae0 	ldr	x0, [x23, #16]
    4c78:	7e61d821 	ucvtf	d1, d1
    4c7c:	f94a1022 	ldr	x2, [x1, #5152]
    4c80:	f94012f3 	ldr	x19, [x23, #32]
    4c84:	1e612800 	fadd	d0, d0, d1
    4c88:	cb000042 	sub	x2, x2, x0
    4c8c:	f90a1022 	str	x2, [x1, #5152]
    4c90:	fd0a2020 	str	d0, [x1, #5184]
    4c94:	b40000b3 	cbz	x19, 4ca8 <fwp_mem_free+0x168>
    4c98:	39400260 	ldrb	w0, [x19]
    4c9c:	7103fc1f 	cmp	w0, #0xff
    4ca0:	54000380 	b.eq	4d10 <fwp_mem_free+0x1d0>  // b.none
    4ca4:	3900027f 	strb	wzr, [x19]
    4ca8:	b9400ee2 	ldr	w2, [x23, #12]
    4cac:	b4000142 	cbz	x2, 4cd4 <fwp_mem_free+0x194>
    4cb0:	9117c2a1 	add	x1, x21, #0x5f0
    4cb4:	8b160040 	add	x0, x2, x22
    4cb8:	8b000800 	add	x0, x0, x0, lsl #2
    4cbc:	f949fc21 	ldr	x1, [x1, #5112]
    4cc0:	8b140034 	add	x20, x1, x20
    4cc4:	8b000c20 	add	x0, x1, x0, lsl #3
    4cc8:	3802869f 	strb	wzr, [x20], #40
    4ccc:	eb00029f 	cmp	x20, x0
    4cd0:	54ffffc1 	b.ne	4cc8 <fwp_mem_free+0x188>  // b.any
    4cd4:	9117c2a0 	add	x0, x21, #0x5f0
    4cd8:	f94a1801 	ldr	x1, [x0, #5168]
    4cdc:	f949f803 	ldr	x3, [x0, #5104]
    4ce0:	8b020021 	add	x1, x1, x2
    4ce4:	f90a1801 	str	x1, [x0, #5168]
    4ce8:	eb16007f 	cmp	x3, x22
    4cec:	54000049 	b.ls	4cf4 <fwp_mem_free+0x1b4>  // b.plast
    4cf0:	f909f816 	str	x22, [x0, #5104]
    4cf4:	9117c2b5 	add	x21, x21, #0x5f0
    4cf8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cfc:	eb16001f 	cmp	x0, x22
    4d00:	54fff529 	b.ls	4ba4 <fwp_mem_free+0x64>  // b.plast
    4d04:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d08:	f909f6b6 	str	x22, [x21, #5096]
    4d0c:	17ffffa7 	b	4ba8 <fwp_mem_free+0x68>
    4d10:	aa1303e0 	mov	x0, x19
    4d14:	97fffeeb 	bl	48c0 <fwp_rc_forget_slot>
    4d18:	17ffffe3 	b	4ca4 <fwp_mem_free+0x164>
    4d1c:	97fffee9 	bl	48c0 <fwp_rc_forget_slot>
    4d20:	17ffffb4 	b	4bf0 <fwp_mem_free+0xb0>

0000000000004d24 <fwp_heap_alloc_big>:
    4d24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4d28:	910003fd 	mov	x29, sp
    4d2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d30:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d34:	a90363f7 	stp	x23, x24, [sp, #48]
    4d38:	aa0003f7 	mov	x23, x0
    4d3c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4d40:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d44:	eb0002ff 	cmp	x23, x0
    4d48:	54000888 	b.hi	4e58 <fwp_heap_alloc_big+0x134>  // b.pmore
    4d4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d50:	8b0002f4 	add	x20, x23, x0
    4d54:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xbf0>
    4d58:	9117c359 	add	x25, x26, #0x5f0
    4d5c:	d350fe94 	lsr	x20, x20, #16
    4d60:	2a0103f5 	mov	w21, w1
    4d64:	aa1403e0 	mov	x0, x20
    4d68:	97fff972 	bl	3330 <fwp_heap_chunks>
    4d6c:	f949ff22 	ldr	x2, [x25, #5112]
    4d70:	8b000813 	add	x19, x0, x0, lsl #2
    4d74:	aa0003f8 	mov	x24, x0
    4d78:	52800043 	mov	w3, #0x2                   	// #2
    4d7c:	d37df273 	lsl	x19, x19, #3
    4d80:	d2800021 	mov	x1, #0x1                   	// #1
    4d84:	8b130040 	add	x0, x2, x19
    4d88:	38336843 	strb	w3, [x2, x19]
    4d8c:	39000415 	strb	w21, [x0, #1]
    4d90:	b9000c14 	str	w20, [x0, #12]
    4d94:	f9000817 	str	x23, [x0, #16]
    4d98:	97fffef2 	bl	4960 <fwp_rc_prepare_chunk>
    4d9c:	f100069f 	cmp	x20, #0x1
    4da0:	54000269 	b.ls	4dec <fwp_heap_alloc_big+0xc8>  // b.plast
    4da4:	8b180294 	add	x20, x20, x24
    4da8:	9100a273 	add	x19, x19, #0x28
    4dac:	a90573fb 	stp	x27, x28, [sp, #80]
    4db0:	5280007b 	mov	w27, #0x3                   	// #3
    4db4:	8b140a94 	add	x20, x20, x20, lsl #2
    4db8:	2a1803fc 	mov	w28, w24
    4dbc:	9adb2296 	lsl	x22, x20, x27
    4dc0:	f949ff35 	ldr	x21, [x25, #5112]
    4dc4:	d2800001 	mov	x1, #0x0                   	// #0
    4dc8:	8b1302b4 	add	x20, x21, x19
    4dcc:	aa1403e0 	mov	x0, x20
    4dd0:	97fffee4 	bl	4960 <fwp_rc_prepare_chunk>
    4dd4:	38336abb 	strb	w27, [x21, x19]
    4dd8:	9100a273 	add	x19, x19, #0x28
    4ddc:	b9000e9c 	str	w28, [x20, #12]
    4de0:	eb1302df 	cmp	x22, x19
    4de4:	54fffee1 	b.ne	4dc0 <fwp_heap_alloc_big+0x9c>  // b.any
    4de8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4dec:	9117c353 	add	x19, x26, #0x5f0
    4df0:	aa1703e2 	mov	x2, x23
    4df4:	52800001 	mov	w1, #0x0                   	// #0
    4df8:	f949da60 	ldr	x0, [x19, #5040]
    4dfc:	8b184018 	add	x24, x0, x24, lsl #16
    4e00:	aa1803e0 	mov	x0, x24
    4e04:	97fff6b7 	bl	28e0 <memset@plt>
    4e08:	f94a1260 	ldr	x0, [x19, #5152]
    4e0c:	ab170000 	adds	x0, x0, x23
    4e10:	54000242 	b.cs	4e58 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4e14:	f94a1661 	ldr	x1, [x19, #5160]
    4e18:	f90a1260 	str	x0, [x19, #5152]
    4e1c:	eb01001f 	cmp	x0, x1
    4e20:	54000049 	b.ls	4e28 <fwp_heap_alloc_big+0x104>  // b.plast
    4e24:	f90a1660 	str	x0, [x19, #5160]
    4e28:	9117c35a 	add	x26, x26, #0x5f0
    4e2c:	9e6202e0 	scvtf	d0, x23
    4e30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e34:	aa1803e0 	mov	x0, x24
    4e38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4e3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e40:	1e602820 	fadd	d0, d1, d0
    4e44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e48:	fd0a1f40 	str	d0, [x26, #5176]
    4e4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e54:	d65f03c0 	ret
    4e58:	a90573fb 	stp	x27, x28, [sp, #80]
    4e5c:	97fff895 	bl	30b0 <fwp_heap_oom>

0000000000004e60 <fwp_heap_alloc_slow>:
    4e60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e64:	910003fd 	mov	x29, sp
    4e68:	a90153f3 	stp	x19, x20, [sp, #16]
    4e6c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    4e70:	9117c262 	add	x2, x19, #0x5f0
    4e74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e78:	aa0003f5 	mov	x21, x0
    4e7c:	2a0103f4 	mov	w20, w1
    4e80:	b953a440 	ldr	w0, [x2, #5028]
    4e84:	34000600 	cbz	w0, 4f44 <fwp_heap_alloc_slow+0xe4>
    4e88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e8c:	54000628 	b.hi	4f50 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e90:	91003ea0 	add	x0, x21, #0xf
    4e94:	9117c262 	add	x2, x19, #0x5f0
    4e98:	f9001bf7 	str	x23, [sp, #48]
    4e9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ea0:	8b401040 	add	x0, x2, x0, lsr #4
    4ea4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ea8:	d37ae484 	lsl	x4, x4, #6
    4eac:	397e8003 	ldrb	w3, [x0, #4000]
    4eb0:	910f0060 	add	x0, x3, #0x3c0
    4eb4:	aa0303e1 	mov	x1, x3
    4eb8:	8b030463 	add	x3, x3, x3, lsl #1
    4ebc:	8b030c83 	add	x3, x4, x3, lsl #3
    4ec0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4ec4:	2a1703f6 	mov	w22, w23
    4ec8:	f8636844 	ldr	x4, [x2, x3]
    4ecc:	b40004e4 	cbz	x4, 4f68 <fwp_heap_alloc_slow+0x108>
    4ed0:	f9400080 	ldr	x0, [x4]
    4ed4:	aa2003e0 	mvn	x0, x0
    4ed8:	f8236840 	str	x0, [x2, x3]
    4edc:	7100069f 	cmp	w20, #0x1
    4ee0:	aa0403e0 	mov	x0, x4
    4ee4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4ee8:	52800001 	mov	w1, #0x0                   	// #0
    4eec:	97fff67d 	bl	28e0 <memset@plt>
    4ef0:	aa0003e4 	mov	x4, x0
    4ef4:	9117c260 	add	x0, x19, #0x5f0
    4ef8:	f94a1001 	ldr	x1, [x0, #5152]
    4efc:	ab160021 	adds	x1, x1, x22
    4f00:	540005c2 	b.cs	4fb8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4f04:	f94a1402 	ldr	x2, [x0, #5160]
    4f08:	f90a1001 	str	x1, [x0, #5152]
    4f0c:	eb02003f 	cmp	x1, x2
    4f10:	54000049 	b.ls	4f18 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4f14:	f90a1401 	str	x1, [x0, #5160]
    4f18:	9117c273 	add	x19, x19, #0x5f0
    4f1c:	1e6302e1 	ucvtf	d1, w23
    4f20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f24:	aa0403e0 	mov	x0, x4
    4f28:	fd4a1e60 	ldr	d0, [x19, #5176]
    4f2c:	f9401bf7 	ldr	x23, [sp, #48]
    4f30:	1e612800 	fadd	d0, d0, d1
    4f34:	fd0a1e60 	str	d0, [x19, #5176]
    4f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f3c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f40:	d65f03c0 	ret
    4f44:	97fffc90 	bl	4184 <fwp_heap_init>
    4f48:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f4c:	54fffa29 	b.ls	4e90 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f50:	2a1403e1 	mov	w1, w20
    4f54:	aa1503e0 	mov	x0, x21
    4f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f60:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f64:	17ffff70 	b	4d24 <fwp_heap_alloc_big>
    4f68:	8b030042 	add	x2, x2, x3
    4f6c:	f9400444 	ldr	x4, [x2, #8]
    4f70:	b4000104 	cbz	x4, 4f90 <fwp_heap_alloc_slow+0x130>
    4f74:	f9400840 	ldr	x0, [x2, #16]
    4f78:	cb040000 	sub	x0, x0, x4
    4f7c:	eb16001f 	cmp	x0, x22
    4f80:	54000083 	b.cc	4f90 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f84:	8b160080 	add	x0, x4, x22
    4f88:	f9000440 	str	x0, [x2, #8]
    4f8c:	17ffffd4 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4f90:	52800302 	mov	w2, #0x18                  	// #24
    4f94:	52807804 	mov	w4, #0x3c0                 	// #960
    4f98:	9117c260 	add	x0, x19, #0x5f0
    4f9c:	9ba27c23 	umull	x3, w1, w2
    4fa0:	2a1403e2 	mov	w2, w20
    4fa4:	9b240e84 	smaddl	x4, w20, w4, x3
    4fa8:	8b040000 	add	x0, x0, x4
    4fac:	97fffeb5 	bl	4a80 <fwp_heap_refill>
    4fb0:	aa0003e4 	mov	x4, x0
    4fb4:	17ffffca 	b	4edc <fwp_heap_alloc_slow+0x7c>
    4fb8:	97fff83e 	bl	30b0 <fwp_heap_oom>
    4fbc:	d503201f 	nop

0000000000004fc0 <fwp_heap_alloc>:
    4fc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4fc4:	f140101f 	cmp	x0, #0x4, lsl #12
    4fc8:	910003fd 	mov	x29, sp
    4fcc:	a90153f3 	stp	x19, x20, [sp, #16]
    4fd0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    4fd4:	9117c293 	add	x19, x20, #0x5f0
    4fd8:	b953a662 	ldr	w2, [x19, #5028]
    4fdc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4fe0:	54000640 	b.eq	50a8 <fwp_heap_alloc+0xe8>  // b.none
    4fe4:	91003c03 	add	x3, x0, #0xf
    4fe8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fec:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ff0:	8b431263 	add	x3, x19, x3, lsr #4
    4ff4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ff8:	d37ae442 	lsl	x2, x2, #6
    4ffc:	397e8063 	ldrb	w3, [x3, #4000]
    5000:	910f0064 	add	x4, x3, #0x3c0
    5004:	8b030463 	add	x3, x3, x3, lsl #1
    5008:	8b030c43 	add	x3, x2, x3, lsl #3
    500c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    5010:	2a1603f5 	mov	w21, w22
    5014:	f8636a64 	ldr	x4, [x19, x3]
    5018:	b4000384 	cbz	x4, 5088 <fwp_heap_alloc+0xc8>
    501c:	f9400085 	ldr	x5, [x4]
    5020:	7100043f 	cmp	w1, #0x1
    5024:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5028:	aa0403e0 	mov	x0, x4
    502c:	aa2503e5 	mvn	x5, x5
    5030:	52800001 	mov	w1, #0x0                   	// #0
    5034:	f8236a65 	str	x5, [x19, x3]
    5038:	97fff62a 	bl	28e0 <memset@plt>
    503c:	aa0003e4 	mov	x4, x0
    5040:	f94a1260 	ldr	x0, [x19, #5152]
    5044:	ab150000 	adds	x0, x0, x21
    5048:	54000442 	b.cs	50d0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    504c:	f94a1661 	ldr	x1, [x19, #5160]
    5050:	f90a1260 	str	x0, [x19, #5152]
    5054:	eb01001f 	cmp	x0, x1
    5058:	54000049 	b.ls	5060 <fwp_heap_alloc+0xa0>  // b.plast
    505c:	f90a1660 	str	x0, [x19, #5160]
    5060:	9117c294 	add	x20, x20, #0x5f0
    5064:	1e6302c1 	ucvtf	d1, w22
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	aa0403e0 	mov	x0, x4
    5070:	fd4a1e80 	ldr	d0, [x20, #5176]
    5074:	1e612800 	fadd	d0, d0, d1
    5078:	fd0a1e80 	str	d0, [x20, #5176]
    507c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5080:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5084:	d65f03c0 	ret
    5088:	8b030263 	add	x3, x19, x3
    508c:	f9400464 	ldr	x4, [x3, #8]
    5090:	b40000a4 	cbz	x4, 50a4 <fwp_heap_alloc+0xe4>
    5094:	f9400862 	ldr	x2, [x3, #16]
    5098:	cb040042 	sub	x2, x2, x4
    509c:	eb15005f 	cmp	x2, x21
    50a0:	540000a2 	b.cs	50b4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    50a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    50b0:	17ffff6c 	b	4e60 <fwp_heap_alloc_slow>
    50b4:	7100043f 	cmp	w1, #0x1
    50b8:	8b150085 	add	x5, x4, x21
    50bc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    50c0:	52800001 	mov	w1, #0x0                   	// #0
    50c4:	aa0403e0 	mov	x0, x4
    50c8:	f9000465 	str	x5, [x3, #8]
    50cc:	17ffffdb 	b	5038 <fwp_heap_alloc+0x78>
    50d0:	97fff7f8 	bl	30b0 <fwp_heap_oom>

00000000000050d4 <fwp_data.part.0.constprop.0>:
    50d4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50d8:	910003fd 	mov	x29, sp
    50dc:	a90153f3 	stp	x19, x20, [sp, #16]
    50e0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xbf0>
    50e4:	9117c283 	add	x3, x20, #0x5f0
    50e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50ec:	aa0103f5 	mov	x21, x1
    50f0:	b953a461 	ldr	w1, [x3, #5028]
    50f4:	a90363f7 	stp	x23, x24, [sp, #48]
    50f8:	2a0003f8 	mov	w24, w0
    50fc:	34000701 	cbz	w1, 51dc <fwp_data.part.0.constprop.0+0x108>
    5100:	397e8862 	ldrb	w2, [x3, #4002]
    5104:	910f0040 	add	x0, x2, #0x3c0
    5108:	8b020442 	add	x2, x2, x2, lsl #1
    510c:	d37df042 	lsl	x2, x2, #3
    5110:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5114:	2a1703f6 	mov	w22, w23
    5118:	f8626873 	ldr	x19, [x3, x2]
    511c:	b40004d3 	cbz	x19, 51b4 <fwp_data.part.0.constprop.0+0xe0>
    5120:	f9400260 	ldr	x0, [x19]
    5124:	aa2003e0 	mvn	x0, x0
    5128:	f8226860 	str	x0, [x3, x2]
    512c:	f10062df 	cmp	x22, #0x18
    5130:	540000e9 	b.ls	514c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5134:	d10066c2 	sub	x2, x22, #0x19
    5138:	91006260 	add	x0, x19, #0x18
    513c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5140:	52800001 	mov	w1, #0x0                   	// #0
    5144:	91002042 	add	x2, x2, #0x8
    5148:	97fff5e6 	bl	28e0 <memset@plt>
    514c:	9117c282 	add	x2, x20, #0x5f0
    5150:	f94a1041 	ldr	x1, [x2, #5152]
    5154:	ab160021 	adds	x1, x1, x22
    5158:	540004c2 	b.cs	51f0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    515c:	f94a1440 	ldr	x0, [x2, #5160]
    5160:	f90a1041 	str	x1, [x2, #5152]
    5164:	eb00003f 	cmp	x1, x0
    5168:	54000049 	b.ls	5170 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    516c:	f90a1441 	str	x1, [x2, #5160]
    5170:	9117c294 	add	x20, x20, #0x5f0
    5174:	1e6302e1 	ucvtf	d1, w23
    5178:	fd4a1e80 	ldr	d0, [x20, #5176]
    517c:	1e612800 	fadd	d0, d0, d1
    5180:	fd0a1e80 	str	d0, [x20, #5176]
    5184:	52800041 	mov	w1, #0x2                   	// #2
    5188:	29000678 	stp	w24, w1, [x19]
    518c:	aa1303e0 	mov	x0, x19
    5190:	f94002a1 	ldr	x1, [x21]
    5194:	f9000661 	str	x1, [x19, #8]
    5198:	f94006a1 	ldr	x1, [x21, #8]
    519c:	f9000a61 	str	x1, [x19, #16]
    51a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51b0:	d65f03c0 	ret
    51b4:	8b020063 	add	x3, x3, x2
    51b8:	f9400473 	ldr	x19, [x3, #8]
    51bc:	b4000113 	cbz	x19, 51dc <fwp_data.part.0.constprop.0+0x108>
    51c0:	f9400860 	ldr	x0, [x3, #16]
    51c4:	cb130000 	sub	x0, x0, x19
    51c8:	eb0002df 	cmp	x22, x0
    51cc:	54000088 	b.hi	51dc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    51d0:	8b160260 	add	x0, x19, x22
    51d4:	f9000460 	str	x0, [x3, #8]
    51d8:	17ffffd5 	b	512c <fwp_data.part.0.constprop.0+0x58>
    51dc:	52800001 	mov	w1, #0x0                   	// #0
    51e0:	d2800300 	mov	x0, #0x18                  	// #24
    51e4:	97ffff77 	bl	4fc0 <fwp_heap_alloc>
    51e8:	aa0003f3 	mov	x19, x0
    51ec:	17ffffe6 	b	5184 <fwp_data.part.0.constprop.0+0xb0>
    51f0:	97fff7b0 	bl	30b0 <fwp_heap_oom>

00000000000051f4 <fwp_p_ad_push>:
    51f4:	f100001f 	cmp	x0, #0x0
    51f8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51fc:	54000e8b 	b.lt	53cc <fwp_p_ad_push+0x1d8>  // b.tstop
    5200:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5204:	aa0003e4 	mov	x4, x0
    5208:	910003fd 	mov	x29, sp
    520c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5210:	aa0003f5 	mov	x21, x0
    5214:	aa020000 	orr	x0, x0, x2
    5218:	a90363f7 	stp	x23, x24, [sp, #48]
    521c:	aa0203f7 	mov	x23, x2
    5220:	6d0627e8 	stp	d8, d9, [sp, #96]
    5224:	9e670029 	fmov	d9, x1
    5228:	9e670068 	fmov	d8, x3
    522c:	b6f80900 	tbz	x0, #63, 534c <fwp_p_ad_push+0x158>
    5230:	a90153f3 	stp	x19, x20, [sp, #16]
    5234:	9360fc80 	asr	x0, x4, #32
    5238:	b6f800c4 	tbz	x4, #63, 5250 <fwp_p_ad_push+0x5c>
    523c:	1e604109 	fmov	d9, d8
    5240:	2f00e408 	movi	d8, #0x0
    5244:	9360fc40 	asr	x0, x2, #32
    5248:	aa0203f5 	mov	x21, x2
    524c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5250:	97fffa58 	bl	3bb0 <fwp_tape_of>
    5254:	aa0003f3 	mov	x19, x0
    5258:	f9403000 	ldr	x0, [x0, #96]
    525c:	b5001280 	cbnz	x0, 54ac <fwp_p_ad_push+0x2b8>
    5260:	f9400a76 	ldr	x22, [x19, #16]
    5264:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5268:	eb0002df 	cmp	x22, x0
    526c:	54000e2c 	b.gt	5430 <fwp_p_ad_push+0x23c>
    5270:	eb3542df 	cmp	x22, w21, uxtw
    5274:	54000d4d 	b.le	541c <fwp_p_ad_push+0x228>
    5278:	b7f80077 	tbnz	x23, #63, 5284 <fwp_p_ad_push+0x90>
    527c:	eb3742df 	cmp	x22, w23, uxtw
    5280:	54000ced 	b.le	541c <fwp_p_ad_push+0x228>
    5284:	f9400678 	ldr	x24, [x19, #8]
    5288:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    528c:	cb1802d8 	sub	x24, x22, x24
    5290:	91000701 	add	x1, x24, #0x1
    5294:	eb00003f 	cmp	x1, x0
    5298:	54000cc8 	b.hi	5430 <fwp_p_ad_push+0x23c>  // b.pmore
    529c:	a9418274 	ldp	x20, x0, [x19, #24]
    52a0:	a90573fb 	stp	x27, x28, [sp, #80]
    52a4:	eb14003f 	cmp	x1, x20
    52a8:	5400068d 	b.le	5378 <fwp_p_ad_push+0x184>
    52ac:	f100029f 	cmp	x20, #0x0
    52b0:	d2800803 	mov	x3, #0x40                  	// #64
    52b4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52b8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52bc:	a9046bf9 	stp	x25, x26, [sp, #64]
    52c0:	eb14003f 	cmp	x1, x20
    52c4:	5400008d 	b.le	52d4 <fwp_p_ad_push+0xe0>
    52c8:	eb02029f 	cmp	x20, x2
    52cc:	5400052d 	b.le	5370 <fwp_p_ad_push+0x17c>
    52d0:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    52d4:	d37df299 	lsl	x25, x20, #3
    52d8:	aa1903e1 	mov	x1, x25
    52dc:	97fff589 	bl	2900 <realloc@plt>
    52e0:	aa0003e1 	mov	x1, x0
    52e4:	b4000b00 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    52e8:	f9400e62 	ldr	x2, [x19, #24]
    52ec:	f9001261 	str	x1, [x19, #32]
    52f0:	f9401a60 	ldr	x0, [x19, #48]
    52f4:	d37cee9a 	lsl	x26, x20, #4
    52f8:	8b020821 	add	x1, x1, x2, lsl #2
    52fc:	f9001661 	str	x1, [x19, #40]
    5300:	aa1a03e1 	mov	x1, x26
    5304:	97fff57f 	bl	2900 <realloc@plt>
    5308:	aa0003e2 	mov	x2, x0
    530c:	b40009c0 	cbz	x0, 5444 <fwp_p_ad_push+0x250>
    5310:	f9400e61 	ldr	x1, [x19, #24]
    5314:	d37df31b 	lsl	x27, x24, #3
    5318:	d37ef685 	lsl	x5, x20, #2
    531c:	d37ef71c 	lsl	x28, x24, #2
    5320:	8b190004 	add	x4, x0, x25
    5324:	8b010c01 	add	x1, x0, x1, lsl #3
    5328:	a9030660 	stp	x0, x1, [x19, #48]
    532c:	b5000558 	cbnz	x24, 53d4 <fwp_p_ad_push+0x1e0>
    5330:	f9001e64 	str	x4, [x19, #56]
    5334:	f9401260 	ldr	x0, [x19, #32]
    5338:	a9446bf9 	ldp	x25, x26, [sp, #64]
    533c:	8b050001 	add	x1, x0, x5
    5340:	f9000e74 	str	x20, [x19, #24]
    5344:	f9001661 	str	x1, [x19, #40]
    5348:	14000010 	b	5388 <fwp_p_ad_push+0x194>
    534c:	9360fc40 	asr	x0, x2, #32
    5350:	a90153f3 	stp	x19, x20, [sp, #16]
    5354:	eb84801f 	cmp	x0, x4, asr #32
    5358:	54fff7c0 	b.eq	5250 <fwp_p_ad_push+0x5c>  // b.none
    535c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5360:	913ae000 	add	x0, x0, #0xeb8
    5364:	a9046bf9 	stp	x25, x26, [sp, #64]
    5368:	a90573fb 	stp	x27, x28, [sp, #80]
    536c:	97fff945 	bl	3880 <fwp_trap>
    5370:	d37ffa94 	lsl	x20, x20, #1
    5374:	17ffffd3 	b	52c0 <fwp_p_ad_push+0xcc>
    5378:	a9428a61 	ldp	x1, x2, [x19, #40]
    537c:	d37ef71c 	lsl	x28, x24, #2
    5380:	f9401e64 	ldr	x4, [x19, #56]
    5384:	d37df31b 	lsl	x27, x24, #3
    5388:	b83c6815 	str	w21, [x0, x28]
    538c:	f10002ff 	cmp	x23, #0x0
    5390:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5394:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5398:	fc3b6849 	str	d9, [x2, x27]
    539c:	aa1602a0 	orr	x0, x21, x22
    53a0:	b83c6837 	str	w23, [x1, x28]
    53a4:	910006d6 	add	x22, x22, #0x1
    53a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53ac:	fc3b6888 	str	d8, [x4, x27]
    53b0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53b4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53b8:	f9000a76 	str	x22, [x19, #16]
    53bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53c8:	d65f03c0 	ret
    53cc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53d0:	d65f03c0 	ret
    53d4:	eb1a033f 	cmp	x25, x26
    53d8:	aa0403e0 	mov	x0, x4
    53dc:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    53e0:	aa1b03e2 	mov	x2, x27
    53e4:	cb190063 	sub	x3, x3, x25
    53e8:	f9003fe5 	str	x5, [sp, #120]
    53ec:	97fff5b1 	bl	2ab0 <__memmove_chk@plt>
    53f0:	a9420660 	ldp	x0, x1, [x19, #32]
    53f4:	aa1c03e2 	mov	x2, x28
    53f8:	f9401a63 	ldr	x3, [x19, #48]
    53fc:	f9403fe5 	ldr	x5, [sp, #120]
    5400:	8b190063 	add	x3, x3, x25
    5404:	f9001e63 	str	x3, [x19, #56]
    5408:	8b050000 	add	x0, x0, x5
    540c:	97fff4dd 	bl	2780 <memmove@plt>
    5410:	a9431262 	ldp	x2, x4, [x19, #48]
    5414:	f9403fe5 	ldr	x5, [sp, #120]
    5418:	17ffffc7 	b	5334 <fwp_p_ad_push+0x140>
    541c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5420:	913d4000 	add	x0, x0, #0xf50
    5424:	a9046bf9 	stp	x25, x26, [sp, #64]
    5428:	a90573fb 	stp	x27, x28, [sp, #80]
    542c:	97fff915 	bl	3880 <fwp_trap>
    5430:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5434:	913cc000 	add	x0, x0, #0xf30
    5438:	a9046bf9 	stp	x25, x26, [sp, #64]
    543c:	a90573fb 	stp	x27, x28, [sp, #80]
    5440:	97fff910 	bl	3880 <fwp_trap>
    5444:	aa1303e0 	mov	x0, x19
    5448:	97fff6f2 	bl	3010 <fwp_tape_unlink_scope>
    544c:	f9401260 	ldr	x0, [x19, #32]
    5450:	97fff560 	bl	29d0 <free@plt>
    5454:	f9401a60 	ldr	x0, [x19, #48]
    5458:	97fff55e 	bl	29d0 <free@plt>
    545c:	f9402260 	ldr	x0, [x19, #64]
    5460:	97fff55c 	bl	29d0 <free@plt>
    5464:	f9000e7f 	str	xzr, [x19, #24]
    5468:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    546c:	f947e821 	ldr	x1, [x1, #4048]
    5470:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5474:	d2800262 	mov	x2, #0x13                  	// #19
    5478:	4f000400 	movi	v0.4s, #0x0
    547c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5480:	f9400023 	ldr	x3, [x1]
    5484:	b900067f 	str	wzr, [x19, #4]
    5488:	d2800021 	mov	x1, #0x1                   	// #1
    548c:	912c6000 	add	x0, x0, #0xb18
    5490:	3c808260 	stur	q0, [x19, #8]
    5494:	ad010260 	stp	q0, q0, [x19, #32]
    5498:	97fff55e 	bl	2a10 <fwrite@plt>
    549c:	d2800000 	mov	x0, #0x0                   	// #0
    54a0:	97fff568 	bl	2a40 <fflush@plt>
    54a4:	52800cc0 	mov	w0, #0x66                  	// #102
    54a8:	97fff576 	bl	2a80 <_Exit@plt>
    54ac:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    54b0:	913c0000 	add	x0, x0, #0xf00
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	a90573fb 	stp	x27, x28, [sp, #80]
    54bc:	97fff8f1 	bl	3880 <fwp_trap>

00000000000054c0 <w120>:
    54c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54c4:	9e660003 	fmov	x3, d0
    54c8:	aa0003e2 	mov	x2, x0
    54cc:	910003fd 	mov	x29, sp
    54d0:	fd001fea 	str	d10, [sp, #56]
    54d4:	1e60400a 	fmov	d10, d0
    54d8:	6d0427e8 	stp	d8, d9, [sp, #64]
    54dc:	1e604028 	fmov	d8, d1
    54e0:	1e600809 	fmul	d9, d0, d0
    54e4:	a90153f3 	stp	x19, x20, [sp, #16]
    54e8:	aa0103f4 	mov	x20, x1
    54ec:	aa0303e1 	mov	x1, x3
    54f0:	aa0003f3 	mov	x19, x0
    54f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54f8:	f9001bf7 	str	x23, [sp, #48]
    54fc:	97ffff3e 	bl	51f4 <fwp_p_ad_push>
    5500:	aa0003e5 	mov	x5, x0
    5504:	97fffb90 	bl	4344 <caf75>
    5508:	9e670000 	fmov	d0, x0
    550c:	97fffb8e 	bl	4344 <caf75>
    5510:	1e693908 	fsub	d8, d8, d9
    5514:	aa1403e2 	mov	x2, x20
    5518:	1e614000 	fneg	d0, d0
    551c:	aa0003e3 	mov	x3, x0
    5520:	aa0503e0 	mov	x0, x5
    5524:	9e660117 	fmov	x23, d8
    5528:	9e660001 	fmov	x1, d0
    552c:	97ffff32 	bl	51f4 <fwp_p_ad_push>
    5530:	aa0003f5 	mov	x21, x0
    5534:	97fffb84 	bl	4344 <caf75>
    5538:	9e670000 	fmov	d0, x0
    553c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5540:	97fffb81 	bl	4344 <caf75>
    5544:	1e614000 	fneg	d0, d0
    5548:	aa0003e3 	mov	x3, x0
    554c:	1e6a3929 	fsub	d9, d9, d10
    5550:	aa1303e0 	mov	x0, x19
    5554:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5558:	9e660001 	fmov	x1, d0
    555c:	9e660136 	fmov	x22, d9
    5560:	97ffff25 	bl	51f4 <fwp_p_ad_push>
    5564:	1e680908 	fmul	d8, d8, d8
    5568:	aa0003f4 	mov	x20, x0
    556c:	aa1703e3 	mov	x3, x23
    5570:	aa1703e1 	mov	x1, x23
    5574:	aa1503e2 	mov	x2, x21
    5578:	aa1503e0 	mov	x0, x21
    557c:	97ffff1e 	bl	51f4 <fwp_p_ad_push>
    5580:	aa0003e2 	mov	x2, x0
    5584:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5588:	9e670020 	fmov	d0, x1
    558c:	9e660101 	fmov	x1, d8
    5590:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5594:	1e600908 	fmul	d8, d8, d0
    5598:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    559c:	97ffff16 	bl	51f4 <fwp_p_ad_push>
    55a0:	1e690929 	fmul	d9, d9, d9
    55a4:	aa1603e3 	mov	x3, x22
    55a8:	aa1603e1 	mov	x1, x22
    55ac:	aa1403e2 	mov	x2, x20
    55b0:	aa0003f3 	mov	x19, x0
    55b4:	aa1403e0 	mov	x0, x20
    55b8:	97ffff0f 	bl	51f4 <fwp_p_ad_push>
    55bc:	aa0003e5 	mov	x5, x0
    55c0:	97fffb61 	bl	4344 <caf75>
    55c4:	aa0003e6 	mov	x6, x0
    55c8:	97fffb5f 	bl	4344 <caf75>
    55cc:	1e692908 	fadd	d8, d8, d9
    55d0:	aa1303e2 	mov	x2, x19
    55d4:	aa0603e1 	mov	x1, x6
    55d8:	aa0003e3 	mov	x3, x0
    55dc:	aa0503e0 	mov	x0, x5
    55e0:	97ffff05 	bl	51f4 <fwp_p_ad_push>
    55e4:	aa0003e1 	mov	x1, x0
    55e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55ec:	9e660100 	fmov	x0, d8
    55f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55f4:	f9401bf7 	ldr	x23, [sp, #48]
    55f8:	fd401fea 	ldr	d10, [sp, #56]
    55fc:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5600:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5604:	d65f03c0 	ret
    5608:	d503201f 	nop
    560c:	d503201f 	nop

0000000000005610 <w176.constprop.0>:
    5610:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5614:	910003fd 	mov	x29, sp
    5618:	a9025bf5 	stp	x21, x22, [sp, #32]
    561c:	fd001be8 	str	d8, [sp, #48]
    5620:	f9400015 	ldr	x21, [x0]
    5624:	b40003b5 	cbz	x21, 5698 <w176.constprop.0+0x88>
    5628:	2f00e408 	movi	d8, #0x0
    562c:	91002016 	add	x22, x0, #0x8
    5630:	a90153f3 	stp	x19, x20, [sp, #16]
    5634:	91004014 	add	x20, x0, #0x10
    5638:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    563c:	d2800013 	mov	x19, #0x0                   	// #0
    5640:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5644:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    5648:	97fffb3f 	bl	4344 <caf75>
    564c:	aa0003e6 	mov	x6, x0
    5650:	97fffb3d 	bl	4344 <caf75>
    5654:	1e602908 	fadd	d8, d8, d0
    5658:	aa0003e3 	mov	x3, x0
    565c:	aa0703e2 	mov	x2, x7
    5660:	aa0503e0 	mov	x0, x5
    5664:	aa0603e1 	mov	x1, x6
    5668:	91000a73 	add	x19, x19, #0x2
    566c:	97fffee2 	bl	51f4 <fwp_p_ad_push>
    5670:	aa0003e5 	mov	x5, x0
    5674:	eb1302bf 	cmp	x21, x19
    5678:	54fffe48 	b.hi	5640 <w176.constprop.0+0x30>  // b.pmore
    567c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5680:	9e660100 	fmov	x0, d8
    5684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5688:	aa0503e1 	mov	x1, x5
    568c:	fd401be8 	ldr	d8, [sp, #48]
    5690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5694:	d65f03c0 	ret
    5698:	2f00e408 	movi	d8, #0x0
    569c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    56a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56a4:	aa0503e1 	mov	x1, x5
    56a8:	9e660100 	fmov	x0, d8
    56ac:	fd401be8 	ldr	d8, [sp, #48]
    56b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    56b4:	d65f03c0 	ret
    56b8:	d503201f 	nop
    56bc:	d503201f 	nop

00000000000056c0 <fwp_rc_share>:
    56c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    56c4:	9117c042 	add	x2, x2, #0x5f0
    56c8:	f949d843 	ldr	x3, [x2, #5040]
    56cc:	f949ec41 	ldr	x1, [x2, #5080]
    56d0:	cb030000 	sub	x0, x0, x3
    56d4:	eb01401f 	cmp	x0, x1, lsl #16
    56d8:	540002c2 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    56dc:	d350fc01 	lsr	x1, x0, #16
    56e0:	f949fc44 	ldr	x4, [x2, #5112]
    56e4:	8b010821 	add	x1, x1, x1, lsl #2
    56e8:	d37df021 	lsl	x1, x1, #3
    56ec:	8b010083 	add	x3, x4, x1
    56f0:	f9401062 	ldr	x2, [x3, #32]
    56f4:	b40001e2 	cbz	x2, 5730 <fwp_rc_share+0x70>
    56f8:	38616881 	ldrb	w1, [x4, x1]
    56fc:	7100083f 	cmp	w1, #0x2
    5700:	540001a0 	b.eq	5734 <fwp_rc_share+0x74>  // b.none
    5704:	7100043f 	cmp	w1, #0x1
    5708:	54000141 	b.ne	5730 <fwp_rc_share+0x70>  // b.any
    570c:	29430464 	ldp	w4, w1, [x3, #24]
    5710:	92403c00 	and	x0, x0, #0xffff
    5714:	9b047c00 	mul	x0, x0, x4
    5718:	d360fc00 	lsr	x0, x0, #32
    571c:	eb01001f 	cmp	x0, x1
    5720:	54000082 	b.cs	5730 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5724:	8b000042 	add	x2, x2, x0
    5728:	39400040 	ldrb	w0, [x2]
    572c:	350000a0 	cbnz	w0, 5740 <fwp_rc_share+0x80>
    5730:	d65f03c0 	ret
    5734:	72003c1f 	tst	w0, #0xffff
    5738:	54ffff80 	b.eq	5728 <fwp_rc_share+0x68>  // b.none
    573c:	d65f03c0 	ret
    5740:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5744:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5748:	913dc000 	add	x0, x0, #0xf70
    574c:	910003fd 	mov	x29, sp
    5750:	97fff84c 	bl	3880 <fwp_trap>

0000000000005754 <fwp_rc_free_arr>:
    5754:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    5758:	9117c063 	add	x3, x3, #0x5f0
    575c:	f949d861 	ldr	x1, [x3, #5040]
    5760:	f949ec62 	ldr	x2, [x3, #5080]
    5764:	cb010001 	sub	x1, x0, x1
    5768:	eb02403f 	cmp	x1, x2, lsl #16
    576c:	54000342 	b.cs	57d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5770:	d350fc22 	lsr	x2, x1, #16
    5774:	f949fc65 	ldr	x5, [x3, #5112]
    5778:	8b020842 	add	x2, x2, x2, lsl #2
    577c:	d37df042 	lsl	x2, x2, #3
    5780:	8b0200a4 	add	x4, x5, x2
    5784:	f9401083 	ldr	x3, [x4, #32]
    5788:	b4000263 	cbz	x3, 57d4 <fwp_rc_free_arr+0x80>
    578c:	386268a2 	ldrb	w2, [x5, x2]
    5790:	7100085f 	cmp	w2, #0x2
    5794:	540001c0 	b.eq	57cc <fwp_rc_free_arr+0x78>  // b.none
    5798:	7100045f 	cmp	w2, #0x1
    579c:	540001c1 	b.ne	57d4 <fwp_rc_free_arr+0x80>  // b.any
    57a0:	29430885 	ldp	w5, w2, [x4, #24]
    57a4:	92403c21 	and	x1, x1, #0xffff
    57a8:	9b057c21 	mul	x1, x1, x5
    57ac:	d360fc21 	lsr	x1, x1, #32
    57b0:	eb02003f 	cmp	x1, x2
    57b4:	54000102 	b.cs	57d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57b8:	8b010063 	add	x3, x3, x1
    57bc:	39400061 	ldrb	w1, [x3]
    57c0:	7100043f 	cmp	w1, #0x1
    57c4:	54000081 	b.ne	57d4 <fwp_rc_free_arr+0x80>  // b.any
    57c8:	17fffcde 	b	4b40 <fwp_mem_free>
    57cc:	72003c3f 	tst	w1, #0xffff
    57d0:	54ffff60 	b.eq	57bc <fwp_rc_free_arr+0x68>  // b.none
    57d4:	d65f03c0 	ret
    57d8:	d503201f 	nop
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_dup>:
    57e0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    57e4:	9117c042 	add	x2, x2, #0x5f0
    57e8:	f949d841 	ldr	x1, [x2, #5040]
    57ec:	f949ec43 	ldr	x3, [x2, #5080]
    57f0:	cb010001 	sub	x1, x0, x1
    57f4:	eb03403f 	cmp	x1, x3, lsl #16
    57f8:	54000342 	b.cs	5860 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57fc:	d350fc20 	lsr	x0, x1, #16
    5800:	f949fc44 	ldr	x4, [x2, #5112]
    5804:	8b000800 	add	x0, x0, x0, lsl #2
    5808:	d37df002 	lsl	x2, x0, #3
    580c:	8b020083 	add	x3, x4, x2
    5810:	f9401060 	ldr	x0, [x3, #32]
    5814:	b4000260 	cbz	x0, 5860 <fwp_rc_dup+0x80>
    5818:	38626882 	ldrb	w2, [x4, x2]
    581c:	7100085f 	cmp	w2, #0x2
    5820:	54000220 	b.eq	5864 <fwp_rc_dup+0x84>  // b.none
    5824:	7100045f 	cmp	w2, #0x1
    5828:	540001c1 	b.ne	5860 <fwp_rc_dup+0x80>  // b.any
    582c:	29430864 	ldp	w4, w2, [x3, #24]
    5830:	92403c21 	and	x1, x1, #0xffff
    5834:	9b047c21 	mul	x1, x1, x4
    5838:	d360fc21 	lsr	x1, x1, #32
    583c:	eb02003f 	cmp	x1, x2
    5840:	54000102 	b.cs	5860 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5844:	8b010000 	add	x0, x0, x1
    5848:	39400001 	ldrb	w1, [x0]
    584c:	340000a1 	cbz	w1, 5860 <fwp_rc_dup+0x80>
    5850:	7103f43f 	cmp	w1, #0xfd
    5854:	540000e8 	b.hi	5870 <fwp_rc_dup+0x90>  // b.pmore
    5858:	11000421 	add	w1, w1, #0x1
    585c:	39000001 	strb	w1, [x0]
    5860:	d65f03c0 	ret
    5864:	72003c3f 	tst	w1, #0xffff
    5868:	54ffff00 	b.eq	5848 <fwp_rc_dup+0x68>  // b.none
    586c:	d65f03c0 	ret
    5870:	17fffbcd 	b	47a4 <fwp_rc_wide_dup>

0000000000005874 <fwp_owned_entry173>:
    5874:	d10103ff 	sub	sp, sp, #0x40
    5878:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    587c:	f947f442 	ldr	x2, [x2, #4072]
    5880:	a9027bfd 	stp	x29, x30, [sp, #32]
    5884:	910083fd 	add	x29, sp, #0x20
    5888:	a90353f3 	stp	x19, x20, [sp, #48]
    588c:	f9400043 	ldr	x3, [x2]
    5890:	f9000fe3 	str	x3, [sp, #24]
    5894:	d2800003 	mov	x3, #0x0                   	// #0
    5898:	a9400c01 	ldp	x1, x3, [x0]
    589c:	f9400802 	ldr	x2, [x0, #16]
    58a0:	ab020022 	adds	x2, x1, x2
    58a4:	540006e6 	b.vs	5980 <fwp_owned_entry173+0x10c>
    58a8:	910023e1 	add	x1, sp, #0x8
    58ac:	52800000 	mov	w0, #0x0                   	// #0
    58b0:	a9008be3 	stp	x3, x2, [sp, #8]
    58b4:	97fffe08 	bl	50d4 <fwp_data.part.0.constprop.0>
    58b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    58bc:	9117c063 	add	x3, x3, #0x5f0
    58c0:	aa0003f3 	mov	x19, x0
    58c4:	f949d861 	ldr	x1, [x3, #5040]
    58c8:	f949ec60 	ldr	x0, [x3, #5080]
    58cc:	cb010261 	sub	x1, x19, x1
    58d0:	eb00403f 	cmp	x1, x0, lsl #16
    58d4:	54000322 	b.cs	5938 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    58d8:	d350fc22 	lsr	x2, x1, #16
    58dc:	f949fc63 	ldr	x3, [x3, #5112]
    58e0:	8b020842 	add	x2, x2, x2, lsl #2
    58e4:	d37df042 	lsl	x2, x2, #3
    58e8:	8b020060 	add	x0, x3, x2
    58ec:	f9401014 	ldr	x20, [x0, #32]
    58f0:	b4000254 	cbz	x20, 5938 <fwp_owned_entry173+0xc4>
    58f4:	38626862 	ldrb	w2, [x3, x2]
    58f8:	7100085f 	cmp	w2, #0x2
    58fc:	54000360 	b.eq	5968 <fwp_owned_entry173+0xf4>  // b.none
    5900:	7100045f 	cmp	w2, #0x1
    5904:	540001a1 	b.ne	5938 <fwp_owned_entry173+0xc4>  // b.any
    5908:	29430002 	ldp	w2, w0, [x0, #24]
    590c:	92403c21 	and	x1, x1, #0xffff
    5910:	9b027c21 	mul	x1, x1, x2
    5914:	d360fc21 	lsr	x1, x1, #32
    5918:	eb00003f 	cmp	x1, x0
    591c:	540000e2 	b.cs	5938 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5920:	8b010294 	add	x20, x20, x1
    5924:	39400280 	ldrb	w0, [x20]
    5928:	7103fc1f 	cmp	w0, #0xff
    592c:	54000240 	b.eq	5974 <fwp_owned_entry173+0x100>  // b.none
    5930:	52800020 	mov	w0, #0x1                   	// #1
    5934:	39000280 	strb	w0, [x20]
    5938:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    593c:	f947f400 	ldr	x0, [x0, #4072]
    5940:	f9400fe2 	ldr	x2, [sp, #24]
    5944:	f9400001 	ldr	x1, [x0]
    5948:	eb010042 	subs	x2, x2, x1
    594c:	d2800001 	mov	x1, #0x0                   	// #0
    5950:	540001a1 	b.ne	5984 <fwp_owned_entry173+0x110>  // b.any
    5954:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5958:	aa1303e0 	mov	x0, x19
    595c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5960:	910103ff 	add	sp, sp, #0x40
    5964:	d65f03c0 	ret
    5968:	72003c3f 	tst	w1, #0xffff
    596c:	54fffe61 	b.ne	5938 <fwp_owned_entry173+0xc4>  // b.any
    5970:	17ffffed 	b	5924 <fwp_owned_entry173+0xb0>
    5974:	aa1403e0 	mov	x0, x20
    5978:	97fffbd2 	bl	48c0 <fwp_rc_forget_slot>
    597c:	17ffffed 	b	5930 <fwp_owned_entry173+0xbc>
    5980:	97fff460 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5984:	97fff3e3 	bl	2910 <__stack_chk_fail@plt>
    5988:	d503201f 	nop
    598c:	d503201f 	nop

0000000000005990 <e173>:
    5990:	d10103ff 	sub	sp, sp, #0x40
    5994:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5998:	f947f442 	ldr	x2, [x2, #4072]
    599c:	a9027bfd 	stp	x29, x30, [sp, #32]
    59a0:	910083fd 	add	x29, sp, #0x20
    59a4:	a90353f3 	stp	x19, x20, [sp, #48]
    59a8:	f9400043 	ldr	x3, [x2]
    59ac:	f9000fe3 	str	x3, [sp, #24]
    59b0:	d2800003 	mov	x3, #0x0                   	// #0
    59b4:	a9400c01 	ldp	x1, x3, [x0]
    59b8:	f9400802 	ldr	x2, [x0, #16]
    59bc:	ab020022 	adds	x2, x1, x2
    59c0:	54000726 	b.vs	5aa4 <e173+0x114>
    59c4:	910023e1 	add	x1, sp, #0x8
    59c8:	52800000 	mov	w0, #0x0                   	// #0
    59cc:	a9008be3 	stp	x3, x2, [sp, #8]
    59d0:	97fffdc1 	bl	50d4 <fwp_data.part.0.constprop.0>
    59d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    59d8:	9117c063 	add	x3, x3, #0x5f0
    59dc:	aa0003f3 	mov	x19, x0
    59e0:	f949d861 	ldr	x1, [x3, #5040]
    59e4:	f949ec60 	ldr	x0, [x3, #5080]
    59e8:	cb010261 	sub	x1, x19, x1
    59ec:	eb00403f 	cmp	x1, x0, lsl #16
    59f0:	54000322 	b.cs	5a54 <e173+0xc4>  // b.hs, b.nlast
    59f4:	d350fc22 	lsr	x2, x1, #16
    59f8:	f949fc63 	ldr	x3, [x3, #5112]
    59fc:	8b020842 	add	x2, x2, x2, lsl #2
    5a00:	d37df042 	lsl	x2, x2, #3
    5a04:	8b020060 	add	x0, x3, x2
    5a08:	f9401014 	ldr	x20, [x0, #32]
    5a0c:	b4000254 	cbz	x20, 5a54 <e173+0xc4>
    5a10:	38626862 	ldrb	w2, [x3, x2]
    5a14:	7100085f 	cmp	w2, #0x2
    5a18:	540003a0 	b.eq	5a8c <e173+0xfc>  // b.none
    5a1c:	7100045f 	cmp	w2, #0x1
    5a20:	540001a1 	b.ne	5a54 <e173+0xc4>  // b.any
    5a24:	29430002 	ldp	w2, w0, [x0, #24]
    5a28:	92403c21 	and	x1, x1, #0xffff
    5a2c:	9b027c21 	mul	x1, x1, x2
    5a30:	d360fc21 	lsr	x1, x1, #32
    5a34:	eb00003f 	cmp	x1, x0
    5a38:	540000e2 	b.cs	5a54 <e173+0xc4>  // b.hs, b.nlast
    5a3c:	8b010294 	add	x20, x20, x1
    5a40:	39400280 	ldrb	w0, [x20]
    5a44:	7103fc1f 	cmp	w0, #0xff
    5a48:	54000280 	b.eq	5a98 <e173+0x108>  // b.none
    5a4c:	52800020 	mov	w0, #0x1                   	// #1
    5a50:	39000280 	strb	w0, [x20]
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	97ffff1a 	bl	56c0 <fwp_rc_share>
    5a5c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a60:	f947f400 	ldr	x0, [x0, #4072]
    5a64:	f9400fe2 	ldr	x2, [sp, #24]
    5a68:	f9400001 	ldr	x1, [x0]
    5a6c:	eb010042 	subs	x2, x2, x1
    5a70:	d2800001 	mov	x1, #0x0                   	// #0
    5a74:	540001a1 	b.ne	5aa8 <e173+0x118>  // b.any
    5a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a7c:	aa1303e0 	mov	x0, x19
    5a80:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a84:	910103ff 	add	sp, sp, #0x40
    5a88:	d65f03c0 	ret
    5a8c:	72003c3f 	tst	w1, #0xffff
    5a90:	54fffe21 	b.ne	5a54 <e173+0xc4>  // b.any
    5a94:	17ffffeb 	b	5a40 <e173+0xb0>
    5a98:	aa1403e0 	mov	x0, x20
    5a9c:	97fffb89 	bl	48c0 <fwp_rc_forget_slot>
    5aa0:	17ffffeb 	b	5a4c <e173+0xbc>
    5aa4:	97fff417 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5aa8:	97fff39a 	bl	2910 <__stack_chk_fail@plt>
    5aac:	d503201f 	nop

0000000000005ab0 <fwp_drop1>:
    5ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ab4:	910003fd 	mov	x29, sp
    5ab8:	a90153f3 	stp	x19, x20, [sp, #16]
    5abc:	f90013f5 	str	x21, [sp, #32]
    5ac0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5ac4:	9117c2b4 	add	x20, x21, #0x5f0
    5ac8:	f949da81 	ldr	x1, [x20, #5040]
    5acc:	f949ee82 	ldr	x2, [x20, #5080]
    5ad0:	cb010001 	sub	x1, x0, x1
    5ad4:	eb02403f 	cmp	x1, x2, lsl #16
    5ad8:	54000382 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5adc:	d350fc22 	lsr	x2, x1, #16
    5ae0:	f949fe84 	ldr	x4, [x20, #5112]
    5ae4:	8b020842 	add	x2, x2, x2, lsl #2
    5ae8:	d37df042 	lsl	x2, x2, #3
    5aec:	8b020083 	add	x3, x4, x2
    5af0:	f9401073 	ldr	x19, [x3, #32]
    5af4:	b40002b3 	cbz	x19, 5b48 <fwp_drop1+0x98>
    5af8:	38626882 	ldrb	w2, [x4, x2]
    5afc:	7100085f 	cmp	w2, #0x2
    5b00:	540002c0 	b.eq	5b58 <fwp_drop1+0xa8>  // b.none
    5b04:	7100045f 	cmp	w2, #0x1
    5b08:	54000201 	b.ne	5b48 <fwp_drop1+0x98>  // b.any
    5b0c:	29430864 	ldp	w4, w2, [x3, #24]
    5b10:	92403c21 	and	x1, x1, #0xffff
    5b14:	9b047c21 	mul	x1, x1, x4
    5b18:	d360fc21 	lsr	x1, x1, #32
    5b1c:	eb02003f 	cmp	x1, x2
    5b20:	54000142 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b24:	8b010273 	add	x19, x19, x1
    5b28:	39400261 	ldrb	w1, [x19]
    5b2c:	340000e1 	cbz	w1, 5b48 <fwp_drop1+0x98>
    5b30:	7100043f 	cmp	w1, #0x1
    5b34:	540001e0 	b.eq	5b70 <fwp_drop1+0xc0>  // b.none
    5b38:	7103fc3f 	cmp	w1, #0xff
    5b3c:	540002e0 	b.eq	5b98 <fwp_drop1+0xe8>  // b.none
    5b40:	51000421 	sub	w1, w1, #0x1
    5b44:	39000261 	strb	w1, [x19]
    5b48:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b4c:	f94013f5 	ldr	x21, [sp, #32]
    5b50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b54:	d65f03c0 	ret
    5b58:	72003c3f 	tst	w1, #0xffff
    5b5c:	54fffe60 	b.eq	5b28 <fwp_drop1+0x78>  // b.none
    5b60:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b64:	f94013f5 	ldr	x21, [sp, #32]
    5b68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b6c:	d65f03c0 	ret
    5b70:	f9400813 	ldr	x19, [x0, #16]
    5b74:	97fffef8 	bl	5754 <fwp_rc_free_arr>
    5b78:	9117c2a0 	add	x0, x21, #0x5f0
    5b7c:	f949d801 	ldr	x1, [x0, #5040]
    5b80:	f949ec00 	ldr	x0, [x0, #5080]
    5b84:	cb010261 	sub	x1, x19, x1
    5b88:	eb00403f 	cmp	x1, x0, lsl #16
    5b8c:	54fffde2 	b.cs	5b48 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b90:	aa1303e0 	mov	x0, x19
    5b94:	17ffffd2 	b	5adc <fwp_drop1+0x2c>
    5b98:	ca534660 	eor	x0, x19, x19, lsr #17
    5b9c:	9117c2b5 	add	x21, x21, #0x5f0
    5ba0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ba4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ba8:	f94a2400 	ldr	x0, [x0, #5192]
    5bac:	b5000080 	cbnz	x0, 5bbc <fwp_drop1+0x10c>
    5bb0:	14000010 	b	5bf0 <fwp_drop1+0x140>
    5bb4:	f9400800 	ldr	x0, [x0, #16]
    5bb8:	b40001c0 	cbz	x0, 5bf0 <fwp_drop1+0x140>
    5bbc:	f9400001 	ldr	x1, [x0]
    5bc0:	eb13003f 	cmp	x1, x19
    5bc4:	54ffff81 	b.ne	5bb4 <fwp_drop1+0x104>  // b.any
    5bc8:	f9400401 	ldr	x1, [x0, #8]
    5bcc:	d1000421 	sub	x1, x1, #0x1
    5bd0:	f9000401 	str	x1, [x0, #8]
    5bd4:	f103f83f 	cmp	x1, #0xfe
    5bd8:	54fffb81 	b.ne	5b48 <fwp_drop1+0x98>  // b.any
    5bdc:	aa1303e0 	mov	x0, x19
    5be0:	97fffb38 	bl	48c0 <fwp_rc_forget_slot>
    5be4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5be8:	39000260 	strb	w0, [x19]
    5bec:	17ffffd7 	b	5b48 <fwp_drop1+0x98>
    5bf0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5bf4:	9139c000 	add	x0, x0, #0xe70
    5bf8:	97fff722 	bl	3880 <fwp_trap>
    5bfc:	d503201f 	nop

0000000000005c00 <fwp_drop0>:
    5c00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c04:	910003fd 	mov	x29, sp
    5c08:	a90153f3 	stp	x19, x20, [sp, #16]
    5c0c:	f90013f5 	str	x21, [sp, #32]
    5c10:	90000175 	adrp	x21, 31000 <fwp_root_context+0xbf0>
    5c14:	9117c2b4 	add	x20, x21, #0x5f0
    5c18:	f949da81 	ldr	x1, [x20, #5040]
    5c1c:	f949ee82 	ldr	x2, [x20, #5080]
    5c20:	cb010001 	sub	x1, x0, x1
    5c24:	eb02403f 	cmp	x1, x2, lsl #16
    5c28:	54000382 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c2c:	d350fc22 	lsr	x2, x1, #16
    5c30:	f949fe84 	ldr	x4, [x20, #5112]
    5c34:	8b020842 	add	x2, x2, x2, lsl #2
    5c38:	d37df042 	lsl	x2, x2, #3
    5c3c:	8b020083 	add	x3, x4, x2
    5c40:	f9401073 	ldr	x19, [x3, #32]
    5c44:	b40002b3 	cbz	x19, 5c98 <fwp_drop0+0x98>
    5c48:	38626882 	ldrb	w2, [x4, x2]
    5c4c:	7100085f 	cmp	w2, #0x2
    5c50:	540002c0 	b.eq	5ca8 <fwp_drop0+0xa8>  // b.none
    5c54:	7100045f 	cmp	w2, #0x1
    5c58:	54000201 	b.ne	5c98 <fwp_drop0+0x98>  // b.any
    5c5c:	29430864 	ldp	w4, w2, [x3, #24]
    5c60:	92403c21 	and	x1, x1, #0xffff
    5c64:	9b047c21 	mul	x1, x1, x4
    5c68:	d360fc21 	lsr	x1, x1, #32
    5c6c:	eb02003f 	cmp	x1, x2
    5c70:	54000142 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c74:	8b010273 	add	x19, x19, x1
    5c78:	39400261 	ldrb	w1, [x19]
    5c7c:	340000e1 	cbz	w1, 5c98 <fwp_drop0+0x98>
    5c80:	7100043f 	cmp	w1, #0x1
    5c84:	540001e0 	b.eq	5cc0 <fwp_drop0+0xc0>  // b.none
    5c88:	7103fc3f 	cmp	w1, #0xff
    5c8c:	540002e0 	b.eq	5ce8 <fwp_drop0+0xe8>  // b.none
    5c90:	51000421 	sub	w1, w1, #0x1
    5c94:	39000261 	strb	w1, [x19]
    5c98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c9c:	f94013f5 	ldr	x21, [sp, #32]
    5ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ca4:	d65f03c0 	ret
    5ca8:	72003c3f 	tst	w1, #0xffff
    5cac:	54fffe60 	b.eq	5c78 <fwp_drop0+0x78>  // b.none
    5cb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cb4:	f94013f5 	ldr	x21, [sp, #32]
    5cb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cbc:	d65f03c0 	ret
    5cc0:	f9400813 	ldr	x19, [x0, #16]
    5cc4:	97fffea4 	bl	5754 <fwp_rc_free_arr>
    5cc8:	9117c2a0 	add	x0, x21, #0x5f0
    5ccc:	f949d801 	ldr	x1, [x0, #5040]
    5cd0:	f949ec00 	ldr	x0, [x0, #5080]
    5cd4:	cb010261 	sub	x1, x19, x1
    5cd8:	eb00403f 	cmp	x1, x0, lsl #16
    5cdc:	54fffde2 	b.cs	5c98 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ce0:	aa1303e0 	mov	x0, x19
    5ce4:	17ffffd2 	b	5c2c <fwp_drop0+0x2c>
    5ce8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cec:	9117c2b5 	add	x21, x21, #0x5f0
    5cf0:	ca402400 	eor	x0, x0, x0, lsr #9
    5cf4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5cf8:	f94a2400 	ldr	x0, [x0, #5192]
    5cfc:	b5000080 	cbnz	x0, 5d0c <fwp_drop0+0x10c>
    5d00:	14000010 	b	5d40 <fwp_drop0+0x140>
    5d04:	f9400800 	ldr	x0, [x0, #16]
    5d08:	b40001c0 	cbz	x0, 5d40 <fwp_drop0+0x140>
    5d0c:	f9400001 	ldr	x1, [x0]
    5d10:	eb13003f 	cmp	x1, x19
    5d14:	54ffff81 	b.ne	5d04 <fwp_drop0+0x104>  // b.any
    5d18:	f9400401 	ldr	x1, [x0, #8]
    5d1c:	d1000421 	sub	x1, x1, #0x1
    5d20:	f9000401 	str	x1, [x0, #8]
    5d24:	f103f83f 	cmp	x1, #0xfe
    5d28:	54fffb81 	b.ne	5c98 <fwp_drop0+0x98>  // b.any
    5d2c:	aa1303e0 	mov	x0, x19
    5d30:	97fffae4 	bl	48c0 <fwp_rc_forget_slot>
    5d34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d38:	39000260 	strb	w0, [x19]
    5d3c:	17ffffd7 	b	5c98 <fwp_drop0+0x98>
    5d40:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5d44:	9139c000 	add	x0, x0, #0xe70
    5d48:	97fff6ce 	bl	3880 <fwp_trap>
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_closure_drop>:
    5d50:	90000165 	adrp	x5, 31000 <fwp_root_context+0xbf0>
    5d54:	9117c0a4 	add	x4, x5, #0x5f0
    5d58:	aa0003e1 	mov	x1, x0
    5d5c:	f949d882 	ldr	x2, [x4, #5040]
    5d60:	f949ec80 	ldr	x0, [x4, #5080]
    5d64:	cb020022 	sub	x2, x1, x2
    5d68:	eb00405f 	cmp	x2, x0, lsl #16
    5d6c:	54000662 	b.cs	5e38 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d74:	d350fc43 	lsr	x3, x2, #16
    5d78:	910003fd 	mov	x29, sp
    5d7c:	8b030863 	add	x3, x3, x3, lsl #2
    5d80:	f949fc84 	ldr	x4, [x4, #5112]
    5d84:	d37df063 	lsl	x3, x3, #3
    5d88:	f9000bf3 	str	x19, [sp, #16]
    5d8c:	8b030080 	add	x0, x4, x3
    5d90:	f9401013 	ldr	x19, [x0, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_closure_drop+0x98>
    5d98:	38636883 	ldrb	w3, [x4, x3]
    5d9c:	7100087f 	cmp	w3, #0x2
    5da0:	54000420 	b.eq	5e24 <fwp_closure_drop+0xd4>  // b.none
    5da4:	7100047f 	cmp	w3, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5dac:	29430003 	ldp	w3, w0, [x0, #24]
    5db0:	92403c42 	and	x2, x2, #0xffff
    5db4:	9b037c42 	mul	x2, x2, x3
    5db8:	d360fc42 	lsr	x2, x2, #32
    5dbc:	eb00005f 	cmp	x2, x0
    5dc0:	54000142 	b.cs	5de8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5dc4:	8b020273 	add	x19, x19, x2
    5dc8:	39400260 	ldrb	w0, [x19]
    5dcc:	340000e0 	cbz	w0, 5de8 <fwp_closure_drop+0x98>
    5dd0:	7100041f 	cmp	w0, #0x1
    5dd4:	54000100 	b.eq	5df4 <fwp_closure_drop+0xa4>  // b.none
    5dd8:	7103fc1f 	cmp	w0, #0xff
    5ddc:	54000300 	b.eq	5e3c <fwp_closure_drop+0xec>  // b.none
    5de0:	51000400 	sub	w0, w0, #0x1
    5de4:	39000260 	strb	w0, [x19]
    5de8:	f9400bf3 	ldr	x19, [sp, #16]
    5dec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5df0:	d65f03c0 	ret
    5df4:	d53bd040 	mrs	x0, tpidr_el0
    5df8:	91400000 	add	x0, x0, #0x0, lsl #12
    5dfc:	91004000 	add	x0, x0, #0x10
    5e00:	f9400000 	ldr	x0, [x0]
    5e04:	b4000080 	cbz	x0, 5e14 <fwp_closure_drop+0xc4>
    5e08:	f9400bf3 	ldr	x19, [sp, #16]
    5e0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e10:	17fff6b5 	b	38e4 <fwp_closure_drop_push>
    5e14:	f9400bf3 	ldr	x19, [sp, #16]
    5e18:	aa0103e0 	mov	x0, x1
    5e1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e20:	17fff720 	b	3aa0 <fwp_closure_drop.part.0>
    5e24:	72003c5f 	tst	w2, #0xffff
    5e28:	54fffd00 	b.eq	5dc8 <fwp_closure_drop+0x78>  // b.none
    5e2c:	f9400bf3 	ldr	x19, [sp, #16]
    5e30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e34:	d65f03c0 	ret
    5e38:	d65f03c0 	ret
    5e3c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e40:	9117c0a5 	add	x5, x5, #0x5f0
    5e44:	ca402400 	eor	x0, x0, x0, lsr #9
    5e48:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5e4c:	f94a2400 	ldr	x0, [x0, #5192]
    5e50:	b5000080 	cbnz	x0, 5e60 <fwp_closure_drop+0x110>
    5e54:	14000010 	b	5e94 <fwp_closure_drop+0x144>
    5e58:	f9400800 	ldr	x0, [x0, #16]
    5e5c:	b40001c0 	cbz	x0, 5e94 <fwp_closure_drop+0x144>
    5e60:	f9400001 	ldr	x1, [x0]
    5e64:	eb13003f 	cmp	x1, x19
    5e68:	54ffff81 	b.ne	5e58 <fwp_closure_drop+0x108>  // b.any
    5e6c:	f9400401 	ldr	x1, [x0, #8]
    5e70:	d1000421 	sub	x1, x1, #0x1
    5e74:	f9000401 	str	x1, [x0, #8]
    5e78:	f103f83f 	cmp	x1, #0xfe
    5e7c:	54fffb61 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5e80:	aa1303e0 	mov	x0, x19
    5e84:	97fffa8f 	bl	48c0 <fwp_rc_forget_slot>
    5e88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e8c:	39000260 	strb	w0, [x19]
    5e90:	17ffffd6 	b	5de8 <fwp_closure_drop+0x98>
    5e94:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    5e98:	9139c000 	add	x0, x0, #0xe70
    5e9c:	97fff679 	bl	3880 <fwp_trap>

0000000000005ea0 <fwp_owned_tape_release>:
    5ea0:	b4000940 	cbz	x0, 5fc8 <fwp_owned_tape_release+0x128>
    5ea4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ea8:	910003fd 	mov	x29, sp
    5eac:	a90153f3 	stp	x19, x20, [sp, #16]
    5eb0:	aa0003f3 	mov	x19, x0
    5eb4:	f9400000 	ldr	x0, [x0]
    5eb8:	b4000060 	cbz	x0, 5ec4 <fwp_owned_tape_release+0x24>
    5ebc:	f9400661 	ldr	x1, [x19, #8]
    5ec0:	f9000401 	str	x1, [x0, #8]
    5ec4:	f9400661 	ldr	x1, [x19, #8]
    5ec8:	b4000041 	cbz	x1, 5ed0 <fwp_owned_tape_release+0x30>
    5ecc:	f9000020 	str	x0, [x1]
    5ed0:	f9400a60 	ldr	x0, [x19, #16]
    5ed4:	f9403401 	ldr	x1, [x0, #104]
    5ed8:	b40005c1 	cbz	x1, 5f90 <fwp_owned_tape_release+0xf0>
    5edc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ee0:	eb00005f 	cmp	x2, x0
    5ee4:	540002ed 	b.le	5f40 <fwp_owned_tape_release+0xa0>
    5ee8:	d2800014 	mov	x20, #0x0                   	// #0
    5eec:	f90013f5 	str	x21, [sp, #32]
    5ef0:	d2800015 	mov	x21, #0x0                   	// #0
    5ef4:	d503201f 	nop
    5ef8:	f9402260 	ldr	x0, [x19, #64]
    5efc:	910006b5 	add	x21, x21, #0x1
    5f00:	f8746800 	ldr	x0, [x0, x20]
    5f04:	d63f0020 	blr	x1
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	f9400a61 	ldr	x1, [x19, #16]
    5f10:	8b140000 	add	x0, x0, x20
    5f14:	91004294 	add	x20, x20, #0x10
    5f18:	f9400400 	ldr	x0, [x0, #8]
    5f1c:	f9403421 	ldr	x1, [x1, #104]
    5f20:	d63f0020 	blr	x1
    5f24:	a9450261 	ldp	x1, x0, [x19, #80]
    5f28:	cb010000 	sub	x0, x0, x1
    5f2c:	eb15001f 	cmp	x0, x21
    5f30:	f9400a60 	ldr	x0, [x19, #16]
    5f34:	f9403401 	ldr	x1, [x0, #104]
    5f38:	54fffe0c 	b.gt	5ef8 <fwp_owned_tape_release+0x58>
    5f3c:	f94013f5 	ldr	x21, [sp, #32]
    5f40:	f9403663 	ldr	x3, [x19, #104]
    5f44:	f9401262 	ldr	x2, [x19, #32]
    5f48:	f100007f 	cmp	x3, #0x0
    5f4c:	540001ed 	b.le	5f88 <fwp_owned_tape_release+0xe8>
    5f50:	d2800014 	mov	x20, #0x0                   	// #0
    5f54:	d503201f 	nop
    5f58:	f9402660 	ldr	x0, [x19, #72]
    5f5c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f60:	eb02001f 	cmp	x0, x2
    5f64:	540000c0 	b.eq	5f7c <fwp_owned_tape_release+0xdc>  // b.none
    5f68:	d63f0020 	blr	x1
    5f6c:	f9400a60 	ldr	x0, [x19, #16]
    5f70:	f9401262 	ldr	x2, [x19, #32]
    5f74:	f9403663 	ldr	x3, [x19, #104]
    5f78:	f9403401 	ldr	x1, [x0, #104]
    5f7c:	91000694 	add	x20, x20, #0x1
    5f80:	eb14007f 	cmp	x3, x20
    5f84:	54fffeac 	b.gt	5f58 <fwp_owned_tape_release+0xb8>
    5f88:	aa0203e0 	mov	x0, x2
    5f8c:	d63f0020 	blr	x1
    5f90:	f9401660 	ldr	x0, [x19, #40]
    5f94:	97ffff6f 	bl	5d50 <fwp_closure_drop>
    5f98:	f9401a60 	ldr	x0, [x19, #48]
    5f9c:	97ffff6d 	bl	5d50 <fwp_closure_drop>
    5fa0:	f9401e60 	ldr	x0, [x19, #56]
    5fa4:	97ffff6b 	bl	5d50 <fwp_closure_drop>
    5fa8:	f9402260 	ldr	x0, [x19, #64]
    5fac:	97fffae5 	bl	4b40 <fwp_mem_free>
    5fb0:	f9402660 	ldr	x0, [x19, #72]
    5fb4:	97fffae3 	bl	4b40 <fwp_mem_free>
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fc4:	17fffadf 	b	4b40 <fwp_mem_free>
    5fc8:	d65f03c0 	ret
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_tape_finish>:
    5fd0:	d10203ff 	sub	sp, sp, #0x80
    5fd4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5fd8:	f947f421 	ldr	x1, [x1, #4072]
    5fdc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fe0:	910103fd 	add	x29, sp, #0x40
    5fe4:	a90553f3 	stp	x19, x20, [sp, #80]
    5fe8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fec:	a90763f7 	stp	x23, x24, [sp, #112]
    5ff0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ff4:	9101c316 	add	x22, x24, #0x70
    5ff8:	f9400022 	ldr	x2, [x1]
    5ffc:	f9001fe2 	str	x2, [sp, #56]
    6000:	d2800002 	mov	x2, #0x0                   	// #0
    6004:	9102e2c0 	add	x0, x22, #0xb8
    6008:	97fff53e 	bl	3500 <fwp_tape_buffers_dispose>
    600c:	f9007adf 	str	xzr, [x22, #240]
    6010:	f9404ac0 	ldr	x0, [x22, #144]
    6014:	f100001f 	cmp	x0, #0x0
    6018:	5400030d 	b.le	6078 <fwp_tape_finish+0xa8>
    601c:	910003f7 	mov	x23, sp
    6020:	d2800015 	mov	x21, #0x0                   	// #0
    6024:	d2800014 	mov	x20, #0x0                   	// #0
    6028:	f94002d3 	ldr	x19, [x22]
    602c:	91000694 	add	x20, x20, #0x1
    6030:	8b150273 	add	x19, x19, x21
    6034:	9101a2b5 	add	x21, x21, #0x68
    6038:	aa1303e0 	mov	x0, x19
    603c:	97fff3f5 	bl	3010 <fwp_tape_unlink_scope>
    6040:	aa1703e0 	mov	x0, x23
    6044:	f9401261 	ldr	x1, [x19, #32]
    6048:	f90003e1 	str	x1, [sp]
    604c:	f9401a62 	ldr	x2, [x19, #48]
    6050:	f9000be2 	str	x2, [sp, #16]
    6054:	f9402261 	ldr	x1, [x19, #64]
    6058:	f90013e1 	str	x1, [sp, #32]
    605c:	97fff529 	bl	3500 <fwp_tape_buffers_dispose>
    6060:	f9403260 	ldr	x0, [x19, #96]
    6064:	97ffff8f 	bl	5ea0 <fwp_owned_tape_release>
    6068:	f900327f 	str	xzr, [x19, #96]
    606c:	f9404ac0 	ldr	x0, [x22, #144]
    6070:	eb14001f 	cmp	x0, x20
    6074:	54fffdac 	b.gt	6028 <fwp_tape_finish+0x58>
    6078:	f9403b00 	ldr	x0, [x24, #112]
    607c:	9101c313 	add	x19, x24, #0x70
    6080:	97fff254 	bl	29d0 <free@plt>
    6084:	f9003b1f 	str	xzr, [x24, #112]
    6088:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    608c:	f947f400 	ldr	x0, [x0, #4072]
    6090:	f9004a7f 	str	xzr, [x19, #144]
    6094:	a9107e7f 	stp	xzr, xzr, [x19, #256]
    6098:	f9401fe2 	ldr	x2, [sp, #56]
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb010042 	subs	x2, x2, x1
    60a4:	d2800001 	mov	x1, #0x0                   	// #0
    60a8:	540000e1 	b.ne	60c4 <fwp_tape_finish+0xf4>  // b.any
    60ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60bc:	910203ff 	add	sp, sp, #0x80
    60c0:	d65f03c0 	ret
    60c4:	97fff213 	bl	2910 <__stack_chk_fail@plt>
    60c8:	d503201f 	nop
    60cc:	d503201f 	nop

00000000000060d0 <fwp_tape_scope_release>:
    60d0:	d10243ff 	sub	sp, sp, #0x90
    60d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60d8:	910103fd 	add	x29, sp, #0x40
    60dc:	a90553f3 	stp	x19, x20, [sp, #80]
    60e0:	aa0003f4 	mov	x20, x0
    60e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    60e8:	f947f400 	ldr	x0, [x0, #4072]
    60ec:	b9400285 	ldr	w5, [x20]
    60f0:	f9400001 	ldr	x1, [x0]
    60f4:	f9001fe1 	str	x1, [sp, #56]
    60f8:	d2800001 	mov	x1, #0x0                   	// #0
    60fc:	37f806c5 	tbnz	w5, #31, 61d4 <fwp_tape_scope_release+0x104>
    6100:	a90763f7 	stp	x23, x24, [sp, #112]
    6104:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6108:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    610c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6110:	d00000d3 	adrp	x19, 20000 <__data_start>
    6114:	910003f7 	mov	x23, sp
    6118:	9101c273 	add	x19, x19, #0x70
    611c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6120:	a9065bf5 	stp	x21, x22, [sp, #96]
    6124:	52800d16 	mov	w22, #0x68                  	// #104
    6128:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    612c:	f90043f9 	str	x25, [sp, #128]
    6130:	14000006 	b	6148 <fwp_tape_scope_release+0x78>
    6134:	97fff4f3 	bl	3500 <fwp_tape_buffers_dispose>
    6138:	aa1903e0 	mov	x0, x25
    613c:	97ffff59 	bl	5ea0 <fwp_owned_tape_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	37f80425 	tbnz	w5, #31, 61c8 <fwp_tape_scope_release+0xf8>
    6148:	f9400266 	ldr	x6, [x19]
    614c:	9b367ca5 	smull	x5, w5, w22
    6150:	8b0500c0 	add	x0, x6, x5
    6154:	97fff3af 	bl	3010 <fwp_tape_unlink_scope>
    6158:	ad410001 	ldp	q1, q0, [x0, #32]
    615c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6160:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6164:	f9400c03 	ldr	x3, [x0, #24]
    6168:	ad0003e1 	stp	q1, q0, [sp]
    616c:	b86568c1 	ldr	w1, [x6, x5]
    6170:	a9440804 	ldp	x4, x2, [x0, #64]
    6174:	b900041f 	str	wzr, [x0, #4]
    6178:	f9403019 	ldr	x25, [x0, #96]
    617c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6180:	f9000c1f 	str	xzr, [x0, #24]
    6184:	a9020fe4 	stp	x4, x3, [sp, #32]
    6188:	f9001be2 	str	x2, [sp, #48]
    618c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6190:	f900301f 	str	xzr, [x0, #96]
    6194:	6b15003f 	cmp	w1, w21
    6198:	540000e8 	b.hi	61b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    619c:	9343fca5 	asr	x5, x5, #3
    61a0:	f9408660 	ldr	x0, [x19, #264]
    61a4:	9b187ca5 	mul	x5, x5, x24
    61a8:	eb0000bf 	cmp	x5, x0
    61ac:	5400004a 	b.ge	61b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61b0:	f9008665 	str	x5, [x19, #264]
    61b4:	aa1703e0 	mov	x0, x23
    61b8:	b5fffbf9 	cbnz	x25, 6134 <fwp_tape_scope_release+0x64>
    61bc:	97fff8a5 	bl	4450 <fwp_tape_buffers_release>
    61c0:	b9400285 	ldr	w5, [x20]
    61c4:	36fffc25 	tbz	w5, #31, 6148 <fwp_tape_scope_release+0x78>
    61c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    61d0:	f94043f9 	ldr	x25, [sp, #128]
    61d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61d8:	f947f400 	ldr	x0, [x0, #4072]
    61dc:	f9401fe2 	ldr	x2, [sp, #56]
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	eb010042 	subs	x2, x2, x1
    61e8:	d2800001 	mov	x1, #0x0                   	// #0
    61ec:	540000a1 	b.ne	6200 <fwp_tape_scope_release+0x130>  // b.any
    61f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f8:	910243ff 	add	sp, sp, #0x90
    61fc:	d65f03c0 	ret
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	a90763f7 	stp	x23, x24, [sp, #112]
    6208:	f90043f9 	str	x25, [sp, #128]
    620c:	97fff1c1 	bl	2910 <__stack_chk_fail@plt>

0000000000006210 <fwp_drop4>:
    6210:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6214:	910003fd 	mov	x29, sp
    6218:	a9025bf5 	stp	x21, x22, [sp, #32]
    621c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xbf0>
    6220:	9117c2d5 	add	x21, x22, #0x5f0
    6224:	a90153f3 	stp	x19, x20, [sp, #16]
    6228:	aa0003f3 	mov	x19, x0
    622c:	f949daa1 	ldr	x1, [x21, #5040]
    6230:	f949eea0 	ldr	x0, [x21, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54000382 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6240:	d350fc22 	lsr	x2, x1, #16
    6244:	f949fea3 	ldr	x3, [x21, #5112]
    6248:	8b020842 	add	x2, x2, x2, lsl #2
    624c:	d37df042 	lsl	x2, x2, #3
    6250:	8b020060 	add	x0, x3, x2
    6254:	f9401014 	ldr	x20, [x0, #32]
    6258:	b40002b4 	cbz	x20, 62ac <fwp_drop4+0x9c>
    625c:	38626862 	ldrb	w2, [x3, x2]
    6260:	7100085f 	cmp	w2, #0x2
    6264:	540002c0 	b.eq	62bc <fwp_drop4+0xac>  // b.none
    6268:	7100045f 	cmp	w2, #0x1
    626c:	54000201 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    6270:	29430002 	ldp	w2, w0, [x0, #24]
    6274:	92403c21 	and	x1, x1, #0xffff
    6278:	9b027c21 	mul	x1, x1, x2
    627c:	d360fc21 	lsr	x1, x1, #32
    6280:	eb00003f 	cmp	x1, x0
    6284:	54000142 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6288:	8b010294 	add	x20, x20, x1
    628c:	39400280 	ldrb	w0, [x20]
    6290:	340000e0 	cbz	w0, 62ac <fwp_drop4+0x9c>
    6294:	7100041f 	cmp	w0, #0x1
    6298:	540001e0 	b.eq	62d4 <fwp_drop4+0xc4>  // b.none
    629c:	7103fc1f 	cmp	w0, #0xff
    62a0:	540007c0 	b.eq	6398 <fwp_drop4+0x188>  // b.none
    62a4:	51000400 	sub	w0, w0, #0x1
    62a8:	39000280 	strb	w0, [x20]
    62ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    62b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62b8:	d65f03c0 	ret
    62bc:	72003c3f 	tst	w1, #0xffff
    62c0:	54fffe60 	b.eq	628c <fwp_drop4+0x7c>  // b.none
    62c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62d0:	d65f03c0 	ret
    62d4:	9117c2c2 	add	x2, x22, #0x5f0
    62d8:	f9400660 	ldr	x0, [x19, #8]
    62dc:	f949d841 	ldr	x1, [x2, #5040]
    62e0:	f949ec42 	ldr	x2, [x2, #5080]
    62e4:	cb010001 	sub	x1, x0, x1
    62e8:	eb02403f 	cmp	x1, x2, lsl #16
    62ec:	54000362 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    62f0:	d350fc22 	lsr	x2, x1, #16
    62f4:	8b020842 	add	x2, x2, x2, lsl #2
    62f8:	d37df042 	lsl	x2, x2, #3
    62fc:	8b020064 	add	x4, x3, x2
    6300:	f9401094 	ldr	x20, [x4, #32]
    6304:	b40002b4 	cbz	x20, 6358 <fwp_drop4+0x148>
    6308:	38626862 	ldrb	w2, [x3, x2]
    630c:	7100085f 	cmp	w2, #0x2
    6310:	540003e0 	b.eq	638c <fwp_drop4+0x17c>  // b.none
    6314:	7100045f 	cmp	w2, #0x1
    6318:	54000201 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    631c:	29430883 	ldp	w3, w2, [x4, #24]
    6320:	92403c21 	and	x1, x1, #0xffff
    6324:	9b037c21 	mul	x1, x1, x3
    6328:	d360fc21 	lsr	x1, x1, #32
    632c:	eb02003f 	cmp	x1, x2
    6330:	54000142 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    6334:	8b010294 	add	x20, x20, x1
    6338:	39400281 	ldrb	w1, [x20]
    633c:	340000e1 	cbz	w1, 6358 <fwp_drop4+0x148>
    6340:	7100043f 	cmp	w1, #0x1
    6344:	54000200 	b.eq	6384 <fwp_drop4+0x174>  // b.none
    6348:	7103fc3f 	cmp	w1, #0xff
    634c:	54000580 	b.eq	63fc <fwp_drop4+0x1ec>  // b.none
    6350:	51000421 	sub	w1, w1, #0x1
    6354:	39000281 	strb	w1, [x20]
    6358:	f9400a74 	ldr	x20, [x19, #16]
    635c:	aa1303e0 	mov	x0, x19
    6360:	97fffcfd 	bl	5754 <fwp_rc_free_arr>
    6364:	9117c2c0 	add	x0, x22, #0x5f0
    6368:	f949d801 	ldr	x1, [x0, #5040]
    636c:	f949ec00 	ldr	x0, [x0, #5080]
    6370:	cb010281 	sub	x1, x20, x1
    6374:	eb00403f 	cmp	x1, x0, lsl #16
    6378:	54fff9a2 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    637c:	aa1403f3 	mov	x19, x20
    6380:	17ffffb0 	b	6240 <fwp_drop4+0x30>
    6384:	97fffcf4 	bl	5754 <fwp_rc_free_arr>
    6388:	17fffff4 	b	6358 <fwp_drop4+0x148>
    638c:	72003c3f 	tst	w1, #0xffff
    6390:	54fffe41 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    6394:	17ffffe9 	b	6338 <fwp_drop4+0x128>
    6398:	ca544681 	eor	x1, x20, x20, lsr #17
    639c:	9117c2c0 	add	x0, x22, #0x5f0
    63a0:	ca412421 	eor	x1, x1, x1, lsr #9
    63a4:	8b210c01 	add	x1, x0, w1, uxtb #3
    63a8:	f94a2420 	ldr	x0, [x1, #5192]
    63ac:	b5000080 	cbnz	x0, 63bc <fwp_drop4+0x1ac>
    63b0:	14000010 	b	63f0 <fwp_drop4+0x1e0>
    63b4:	f9400800 	ldr	x0, [x0, #16]
    63b8:	b40001c0 	cbz	x0, 63f0 <fwp_drop4+0x1e0>
    63bc:	f9400001 	ldr	x1, [x0]
    63c0:	eb14003f 	cmp	x1, x20
    63c4:	54ffff81 	b.ne	63b4 <fwp_drop4+0x1a4>  // b.any
    63c8:	f9400401 	ldr	x1, [x0, #8]
    63cc:	d1000421 	sub	x1, x1, #0x1
    63d0:	f9000401 	str	x1, [x0, #8]
    63d4:	f103f83f 	cmp	x1, #0xfe
    63d8:	54fff6a1 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    63dc:	aa1403e0 	mov	x0, x20
    63e0:	97fff938 	bl	48c0 <fwp_rc_forget_slot>
    63e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63e8:	39000280 	strb	w0, [x20]
    63ec:	17ffffb0 	b	62ac <fwp_drop4+0x9c>
    63f0:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    63f4:	9139c000 	add	x0, x0, #0xe70
    63f8:	97fff522 	bl	3880 <fwp_trap>
    63fc:	ca544680 	eor	x0, x20, x20, lsr #17
    6400:	9117c2c1 	add	x1, x22, #0x5f0
    6404:	ca402400 	eor	x0, x0, x0, lsr #9
    6408:	8b200c20 	add	x0, x1, w0, uxtb #3
    640c:	f94a2400 	ldr	x0, [x0, #5192]
    6410:	b5000080 	cbnz	x0, 6420 <fwp_drop4+0x210>
    6414:	17fffff7 	b	63f0 <fwp_drop4+0x1e0>
    6418:	f9400800 	ldr	x0, [x0, #16]
    641c:	b4fffea0 	cbz	x0, 63f0 <fwp_drop4+0x1e0>
    6420:	f9400001 	ldr	x1, [x0]
    6424:	eb14003f 	cmp	x1, x20
    6428:	54ffff81 	b.ne	6418 <fwp_drop4+0x208>  // b.any
    642c:	f9400401 	ldr	x1, [x0, #8]
    6430:	d1000421 	sub	x1, x1, #0x1
    6434:	f9000401 	str	x1, [x0, #8]
    6438:	f103f83f 	cmp	x1, #0xfe
    643c:	54fff8e1 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    6440:	aa1403e0 	mov	x0, x20
    6444:	97fff91f 	bl	48c0 <fwp_rc_forget_slot>
    6448:	12800020 	mov	w0, #0xfffffffe            	// #-2
    644c:	39000280 	strb	w0, [x20]
    6450:	17ffffc2 	b	6358 <fwp_drop4+0x148>

0000000000006454 <fwp_arg_drop37>:
    6454:	7100003f 	cmp	w1, #0x0
    6458:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    645c:	54000041 	b.ne	6464 <fwp_arg_drop37+0x10>  // b.any
    6460:	d65f03c0 	ret
    6464:	f9400000 	ldr	x0, [x0]
    6468:	17ffff6a 	b	6210 <fwp_drop4>
    646c:	d503201f 	nop

0000000000006470 <fwp_task_dispose>:
    6470:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6474:	910003fd 	mov	x29, sp
    6478:	f9000bf3 	str	x19, [sp, #16]
    647c:	aa0003f3 	mov	x19, x0
    6480:	39414000 	ldrb	w0, [x0, #80]
    6484:	36000720 	tbz	w0, #0, 6568 <fwp_task_dispose+0xf8>
    6488:	f9400a60 	ldr	x0, [x19, #16]
    648c:	b50006e0 	cbnz	x0, 6568 <fwp_task_dispose+0xf8>
    6490:	a9478660 	ldp	x0, x1, [x19, #120]
    6494:	39014e7f 	strb	wzr, [x19, #83]
    6498:	f9003e7f 	str	xzr, [x19, #120]
    649c:	f100003f 	cmp	x1, #0x0
    64a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64a4:	54000040 	b.eq	64ac <fwp_task_dispose+0x3c>  // b.none
    64a8:	d63f0020 	blr	x1
    64ac:	f9405660 	ldr	x0, [x19, #168]
    64b0:	97fff9a4 	bl	4b40 <fwp_mem_free>
    64b4:	f900567f 	str	xzr, [x19, #168]
    64b8:	b9405e60 	ldr	w0, [x19, #92]
    64bc:	7100041f 	cmp	w0, #0x1
    64c0:	54000420 	b.eq	6544 <fwp_task_dispose+0xd4>  // b.none
    64c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    64c8:	9117c042 	add	x2, x2, #0x5f0
    64cc:	f949d840 	ldr	x0, [x2, #5040]
    64d0:	f949ec41 	ldr	x1, [x2, #5080]
    64d4:	cb000260 	sub	x0, x19, x0
    64d8:	eb01401f 	cmp	x0, x1, lsl #16
    64dc:	540002e2 	b.cs	6538 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    64e0:	d350fc01 	lsr	x1, x0, #16
    64e4:	f949fc44 	ldr	x4, [x2, #5112]
    64e8:	8b010821 	add	x1, x1, x1, lsl #2
    64ec:	d37df021 	lsl	x1, x1, #3
    64f0:	8b010083 	add	x3, x4, x1
    64f4:	f9401062 	ldr	x2, [x3, #32]
    64f8:	b4000202 	cbz	x2, 6538 <fwp_task_dispose+0xc8>
    64fc:	38616881 	ldrb	w1, [x4, x1]
    6500:	7100083f 	cmp	w1, #0x2
    6504:	54000280 	b.eq	6554 <fwp_task_dispose+0xe4>  // b.none
    6508:	7100043f 	cmp	w1, #0x1
    650c:	54000161 	b.ne	6538 <fwp_task_dispose+0xc8>  // b.any
    6510:	29430464 	ldp	w4, w1, [x3, #24]
    6514:	92403c00 	and	x0, x0, #0xffff
    6518:	9b047c00 	mul	x0, x0, x4
    651c:	d360fc00 	lsr	x0, x0, #32
    6520:	eb01001f 	cmp	x0, x1
    6524:	540000a2 	b.cs	6538 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6528:	8b000042 	add	x2, x2, x0
    652c:	39400040 	ldrb	w0, [x2]
    6530:	7100041f 	cmp	w0, #0x1
    6534:	54000080 	b.eq	6544 <fwp_task_dispose+0xd4>  // b.none
    6538:	f9400bf3 	ldr	x19, [sp, #16]
    653c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6540:	d65f03c0 	ret
    6544:	aa1303e0 	mov	x0, x19
    6548:	f9400bf3 	ldr	x19, [sp, #16]
    654c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6550:	17fff97c 	b	4b40 <fwp_mem_free>
    6554:	72003c1f 	tst	w0, #0xffff
    6558:	54fffea0 	b.eq	652c <fwp_task_dispose+0xbc>  // b.none
    655c:	f9400bf3 	ldr	x19, [sp, #16]
    6560:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6564:	d65f03c0 	ret
    6568:	97fff0fe 	bl	2960 <abort@plt>
    656c:	d503201f 	nop

0000000000006570 <fwp_free_zombie>:
    6570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6574:	910003fd 	mov	x29, sp
    6578:	a90153f3 	stp	x19, x20, [sp, #16]
    657c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6580:	9101c281 	add	x1, x20, #0x70
    6584:	f9408833 	ldr	x19, [x1, #272]
    6588:	b4000333 	cbz	x19, 65ec <fwp_free_zombie+0x7c>
    658c:	f9400820 	ldr	x0, [x1, #16]
    6590:	eb00027f 	cmp	x19, x0
    6594:	540002c0 	b.eq	65ec <fwp_free_zombie+0x7c>  // b.none
    6598:	b9411822 	ldr	w2, [x1, #280]
    659c:	f9400a60 	ldr	x0, [x19, #16]
    65a0:	7100fc5f 	cmp	w2, #0x3f
    65a4:	5400078c 	b.gt	6694 <fwp_free_zombie+0x124>
    65a8:	91048023 	add	x3, x1, #0x120
    65ac:	11000444 	add	w4, w2, #0x1
    65b0:	b9011824 	str	w4, [x1, #280]
    65b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65bc:	a9530261 	ldp	x1, x0, [x19, #304]
    65c0:	b4000741 	cbz	x1, 66a8 <fwp_free_zombie+0x138>
    65c4:	f9009c20 	str	x0, [x1, #312]
    65c8:	b4000040 	cbz	x0, 65d0 <fwp_free_zombie+0x60>
    65cc:	f9009801 	str	x1, [x0, #304]
    65d0:	9101c294 	add	x20, x20, #0x70
    65d4:	b9405e60 	ldr	w0, [x19, #92]
    65d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    65dc:	f9008a9f 	str	xzr, [x20, #272]
    65e0:	34000140 	cbz	w0, 6608 <fwp_free_zombie+0x98>
    65e4:	7100041f 	cmp	w0, #0x1
    65e8:	54000080 	b.eq	65f8 <fwp_free_zombie+0x88>  // b.none
    65ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    65f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f4:	d65f03c0 	ret
    65f8:	aa1303e0 	mov	x0, x19
    65fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6600:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6604:	17ffff9b 	b	6470 <fwp_task_dispose>
    6608:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xbf0>
    660c:	9117c082 	add	x2, x4, #0x5f0
    6610:	f949d841 	ldr	x1, [x2, #5040]
    6614:	f949ec40 	ldr	x0, [x2, #5080]
    6618:	cb010261 	sub	x1, x19, x1
    661c:	eb00403f 	cmp	x1, x0, lsl #16
    6620:	54fffe62 	b.cs	65ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6624:	d350fc20 	lsr	x0, x1, #16
    6628:	f949fc43 	ldr	x3, [x2, #5112]
    662c:	8b000800 	add	x0, x0, x0, lsl #2
    6630:	d37df000 	lsl	x0, x0, #3
    6634:	8b000062 	add	x2, x3, x0
    6638:	f9401054 	ldr	x20, [x2, #32]
    663c:	b4fffd94 	cbz	x20, 65ec <fwp_free_zombie+0x7c>
    6640:	38606860 	ldrb	w0, [x3, x0]
    6644:	7100081f 	cmp	w0, #0x2
    6648:	54000360 	b.eq	66b4 <fwp_free_zombie+0x144>  // b.none
    664c:	7100041f 	cmp	w0, #0x1
    6650:	54fffce1 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    6654:	29430043 	ldp	w3, w0, [x2, #24]
    6658:	92403c21 	and	x1, x1, #0xffff
    665c:	9b037c21 	mul	x1, x1, x3
    6660:	d360fc21 	lsr	x1, x1, #32
    6664:	eb00003f 	cmp	x1, x0
    6668:	54fffc22 	b.cs	65ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    666c:	8b010294 	add	x20, x20, x1
    6670:	39400280 	ldrb	w0, [x20]
    6674:	34fffbc0 	cbz	w0, 65ec <fwp_free_zombie+0x7c>
    6678:	7100041f 	cmp	w0, #0x1
    667c:	54fffbe0 	b.eq	65f8 <fwp_free_zombie+0x88>  // b.none
    6680:	7103fc1f 	cmp	w0, #0xff
    6684:	540001e0 	b.eq	66c0 <fwp_free_zombie+0x150>  // b.none
    6688:	51000400 	sub	w0, w0, #0x1
    668c:	39000280 	strb	w0, [x20]
    6690:	17ffffd7 	b	65ec <fwp_free_zombie+0x7c>
    6694:	f9400e61 	ldr	x1, [x19, #24]
    6698:	97fff0e6 	bl	2a30 <munmap@plt>
    669c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66a0:	a9530261 	ldp	x1, x0, [x19, #304]
    66a4:	b5fff901 	cbnz	x1, 65c4 <fwp_free_zombie+0x54>
    66a8:	9101c282 	add	x2, x20, #0x70
    66ac:	f9019040 	str	x0, [x2, #800]
    66b0:	17ffffc6 	b	65c8 <fwp_free_zombie+0x58>
    66b4:	72003c3f 	tst	w1, #0xffff
    66b8:	54fff9a1 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    66bc:	17ffffed 	b	6670 <fwp_free_zombie+0x100>
    66c0:	ca544680 	eor	x0, x20, x20, lsr #17
    66c4:	9117c084 	add	x4, x4, #0x5f0
    66c8:	ca402400 	eor	x0, x0, x0, lsr #9
    66cc:	8b200c80 	add	x0, x4, w0, uxtb #3
    66d0:	f94a2400 	ldr	x0, [x0, #5192]
    66d4:	b5000080 	cbnz	x0, 66e4 <fwp_free_zombie+0x174>
    66d8:	14000010 	b	6718 <fwp_free_zombie+0x1a8>
    66dc:	f9400800 	ldr	x0, [x0, #16]
    66e0:	b40001c0 	cbz	x0, 6718 <fwp_free_zombie+0x1a8>
    66e4:	f9400001 	ldr	x1, [x0]
    66e8:	eb14003f 	cmp	x1, x20
    66ec:	54ffff81 	b.ne	66dc <fwp_free_zombie+0x16c>  // b.any
    66f0:	f9400401 	ldr	x1, [x0, #8]
    66f4:	d1000421 	sub	x1, x1, #0x1
    66f8:	f9000401 	str	x1, [x0, #8]
    66fc:	f103f83f 	cmp	x1, #0xfe
    6700:	54fff761 	b.ne	65ec <fwp_free_zombie+0x7c>  // b.any
    6704:	aa1403e0 	mov	x0, x20
    6708:	97fff86e 	bl	48c0 <fwp_rc_forget_slot>
    670c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6710:	39000280 	strb	w0, [x20]
    6714:	17ffffb6 	b	65ec <fwp_free_zombie+0x7c>
    6718:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    671c:	9139c000 	add	x0, x0, #0xe70
    6720:	97fff458 	bl	3880 <fwp_trap>

0000000000006724 <fwp_block>:
    6724:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6728:	910003fd 	mov	x29, sp
    672c:	a90153f3 	stp	x19, x20, [sp, #16]
    6730:	d00000d3 	adrp	x19, 20000 <__data_start>
    6734:	9101c274 	add	x20, x19, #0x70
    6738:	f9404282 	ldr	x2, [x20, #128]
    673c:	b4000622 	cbz	x2, 6800 <fwp_block+0xdc>
    6740:	9101c261 	add	x1, x19, #0x70
    6744:	f9408040 	ldr	x0, [x2, #256]
    6748:	f9004020 	str	x0, [x1, #128]
    674c:	b4000680 	cbz	x0, 681c <fwp_block+0xf8>
    6750:	9101c263 	add	x3, x19, #0x70
    6754:	3901505f 	strb	wzr, [x2, #84]
    6758:	f9400864 	ldr	x4, [x3, #16]
    675c:	eb02009f 	cmp	x4, x2
    6760:	54000440 	b.eq	67e8 <fwp_block+0xc4>  // b.none
    6764:	f9419465 	ldr	x5, [x3, #808]
    6768:	f9000862 	str	x2, [x3, #16]
    676c:	f9400441 	ldr	x1, [x2, #8]
    6770:	f9004885 	str	x5, [x4, #144]
    6774:	f9419865 	ldr	x5, [x3, #816]
    6778:	f9004c85 	str	x5, [x4, #152]
    677c:	f9419c65 	ldr	x5, [x3, #824]
    6780:	f9005085 	str	x5, [x4, #160]
    6784:	f941a065 	ldr	x5, [x3, #832]
    6788:	f9005485 	str	x5, [x4, #168]
    678c:	f941a465 	ldr	x5, [x3, #840]
    6790:	f9005885 	str	x5, [x4, #176]
    6794:	f941a865 	ldr	x5, [x3, #848]
    6798:	f9005c85 	str	x5, [x4, #184]
    679c:	f941ac65 	ldr	x5, [x3, #856]
    67a0:	f9006085 	str	x5, [x4, #192]
    67a4:	f9400480 	ldr	x0, [x4, #8]
    67a8:	f9404844 	ldr	x4, [x2, #144]
    67ac:	f9019464 	str	x4, [x3, #808]
    67b0:	f9404c44 	ldr	x4, [x2, #152]
    67b4:	f9019864 	str	x4, [x3, #816]
    67b8:	f9405044 	ldr	x4, [x2, #160]
    67bc:	f9019c64 	str	x4, [x3, #824]
    67c0:	f9405444 	ldr	x4, [x2, #168]
    67c4:	f901a064 	str	x4, [x3, #832]
    67c8:	f9405844 	ldr	x4, [x2, #176]
    67cc:	f901a464 	str	x4, [x3, #840]
    67d0:	a94b8844 	ldp	x4, x2, [x2, #184]
    67d4:	f901a864 	str	x4, [x3, #848]
    67d8:	f901ac62 	str	x2, [x3, #856]
    67dc:	97fff065 	bl	2970 <swapcontext@plt>
    67e0:	97ffff64 	bl	6570 <fwp_free_zombie>
    67e4:	d503201f 	nop
    67e8:	9101c260 	add	x0, x19, #0x70
    67ec:	b9436000 	ldr	w0, [x0, #864]
    67f0:	340001a0 	cbz	w0, 6824 <fwp_block+0x100>
    67f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67fc:	d65f03c0 	ret
    6800:	97fff75c 	bl	4570 <fwp_poll_events>
    6804:	f9404282 	ldr	x2, [x20, #128]
    6808:	b4ffffc2 	cbz	x2, 6800 <fwp_block+0xdc>
    680c:	9101c261 	add	x1, x19, #0x70
    6810:	f9408040 	ldr	x0, [x2, #256]
    6814:	f9004020 	str	x0, [x1, #128]
    6818:	b5fff9c0 	cbnz	x0, 6750 <fwp_block+0x2c>
    681c:	f9003c3f 	str	xzr, [x1, #120]
    6820:	17ffffcc 	b	6750 <fwp_block+0x2c>
    6824:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    6828:	913e8000 	add	x0, x0, #0xfa0
    682c:	97fff09d 	bl	2aa0 <getenv@plt>
    6830:	5284e202 	mov	w2, #0x2710                	// #10000
    6834:	b4000060 	cbz	x0, 6840 <fwp_block+0x11c>
    6838:	39400001 	ldrb	w1, [x0]
    683c:	350000c1 	cbnz	w1, 6854 <fwp_block+0x130>
    6840:	9101c273 	add	x19, x19, #0x70
    6844:	b9036262 	str	w2, [x19, #864]
    6848:	a94153f3 	ldp	x19, x20, [sp, #16]
    684c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6850:	d65f03c0 	ret
    6854:	52800142 	mov	w2, #0xa                   	// #10
    6858:	d2800001 	mov	x1, #0x0                   	// #0
    685c:	97ffefe1 	bl	27e0 <strtoll@plt>
    6860:	d1000403 	sub	x3, x0, #0x1
    6864:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6868:	eb02007f 	cmp	x3, x2
    686c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6870:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6874:	17fffff3 	b	6840 <fwp_block+0x11c>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <fwp_drop10>:
    6880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6884:	910003fd 	mov	x29, sp
    6888:	a90153f3 	stp	x19, x20, [sp, #16]
    688c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xbf0>
    6890:	f90013f5 	str	x21, [sp, #32]
    6894:	9117c275 	add	x21, x19, #0x5f0
    6898:	f949daa1 	ldr	x1, [x21, #5040]
    689c:	f949eea2 	ldr	x2, [x21, #5080]
    68a0:	cb010001 	sub	x1, x0, x1
    68a4:	eb02403f 	cmp	x1, x2, lsl #16
    68a8:	54000382 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    68ac:	d350fc22 	lsr	x2, x1, #16
    68b0:	f949fea3 	ldr	x3, [x21, #5112]
    68b4:	8b020842 	add	x2, x2, x2, lsl #2
    68b8:	d37df042 	lsl	x2, x2, #3
    68bc:	8b020064 	add	x4, x3, x2
    68c0:	f9401094 	ldr	x20, [x4, #32]
    68c4:	b40002b4 	cbz	x20, 6918 <fwp_drop10+0x98>
    68c8:	38626862 	ldrb	w2, [x3, x2]
    68cc:	7100085f 	cmp	w2, #0x2
    68d0:	540007a0 	b.eq	69c4 <fwp_drop10+0x144>  // b.none
    68d4:	7100045f 	cmp	w2, #0x1
    68d8:	54000201 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    68dc:	29430885 	ldp	w5, w2, [x4, #24]
    68e0:	92403c21 	and	x1, x1, #0xffff
    68e4:	9b057c21 	mul	x1, x1, x5
    68e8:	d360fc21 	lsr	x1, x1, #32
    68ec:	eb02003f 	cmp	x1, x2
    68f0:	54000142 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    68f4:	8b010294 	add	x20, x20, x1
    68f8:	39400281 	ldrb	w1, [x20]
    68fc:	340000e1 	cbz	w1, 6918 <fwp_drop10+0x98>
    6900:	7100043f 	cmp	w1, #0x1
    6904:	54000120 	b.eq	6928 <fwp_drop10+0xa8>  // b.none
    6908:	7103fc3f 	cmp	w1, #0xff
    690c:	540007c0 	b.eq	6a04 <fwp_drop10+0x184>  // b.none
    6910:	51000421 	sub	w1, w1, #0x1
    6914:	39000281 	strb	w1, [x20]
    6918:	a94153f3 	ldp	x19, x20, [sp, #16]
    691c:	f94013f5 	ldr	x21, [sp, #32]
    6920:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6924:	d65f03c0 	ret
    6928:	f9400001 	ldr	x1, [x0]
    692c:	b7f80581 	tbnz	x1, #63, 69dc <fwp_drop10+0x15c>
    6930:	9117c273 	add	x19, x19, #0x5f0
    6934:	f949da61 	ldr	x1, [x19, #5040]
    6938:	f949ee62 	ldr	x2, [x19, #5080]
    693c:	cb010001 	sub	x1, x0, x1
    6940:	eb02403f 	cmp	x1, x2, lsl #16
    6944:	54fffea2 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    6948:	d350fc22 	lsr	x2, x1, #16
    694c:	8b020842 	add	x2, x2, x2, lsl #2
    6950:	d37df042 	lsl	x2, x2, #3
    6954:	8b020065 	add	x5, x3, x2
    6958:	f94010a4 	ldr	x4, [x5, #32]
    695c:	b4fffde4 	cbz	x4, 6918 <fwp_drop10+0x98>
    6960:	38626862 	ldrb	w2, [x3, x2]
    6964:	7100085f 	cmp	w2, #0x2
    6968:	54000220 	b.eq	69ac <fwp_drop10+0x12c>  // b.none
    696c:	7100045f 	cmp	w2, #0x1
    6970:	54fffd41 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    6974:	294308a3 	ldp	w3, w2, [x5, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b037c21 	mul	x1, x1, x3
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb02003f 	cmp	x1, x2
    6988:	54fffc82 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    698c:	8b010084 	add	x4, x4, x1
    6990:	39400081 	ldrb	w1, [x4]
    6994:	7100043f 	cmp	w1, #0x1
    6998:	54fffc01 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    699c:	a94153f3 	ldp	x19, x20, [sp, #16]
    69a0:	f94013f5 	ldr	x21, [sp, #32]
    69a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69a8:	17fff866 	b	4b40 <fwp_mem_free>
    69ac:	72003c3f 	tst	w1, #0xffff
    69b0:	54ffff00 	b.eq	6990 <fwp_drop10+0x110>  // b.none
    69b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69b8:	f94013f5 	ldr	x21, [sp, #32]
    69bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69c0:	d65f03c0 	ret
    69c4:	72003c3f 	tst	w1, #0xffff
    69c8:	54fff980 	b.eq	68f8 <fwp_drop10+0x78>  // b.none
    69cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d0:	f94013f5 	ldr	x21, [sp, #32]
    69d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69d8:	d65f03c0 	ret
    69dc:	f9400414 	ldr	x20, [x0, #8]
    69e0:	97fffb5d 	bl	5754 <fwp_rc_free_arr>
    69e4:	9117c260 	add	x0, x19, #0x5f0
    69e8:	f949d801 	ldr	x1, [x0, #5040]
    69ec:	f949ec00 	ldr	x0, [x0, #5080]
    69f0:	cb010281 	sub	x1, x20, x1
    69f4:	eb00403f 	cmp	x1, x0, lsl #16
    69f8:	54fff902 	b.cs	6918 <fwp_drop10+0x98>  // b.hs, b.nlast
    69fc:	aa1403e0 	mov	x0, x20
    6a00:	17ffffab 	b	68ac <fwp_drop10+0x2c>
    6a04:	ca544680 	eor	x0, x20, x20, lsr #17
    6a08:	9117c273 	add	x19, x19, #0x5f0
    6a0c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a10:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a14:	f94a2400 	ldr	x0, [x0, #5192]
    6a18:	b5000080 	cbnz	x0, 6a28 <fwp_drop10+0x1a8>
    6a1c:	14000010 	b	6a5c <fwp_drop10+0x1dc>
    6a20:	f9400800 	ldr	x0, [x0, #16]
    6a24:	b40001c0 	cbz	x0, 6a5c <fwp_drop10+0x1dc>
    6a28:	f9400001 	ldr	x1, [x0]
    6a2c:	eb14003f 	cmp	x1, x20
    6a30:	54ffff81 	b.ne	6a20 <fwp_drop10+0x1a0>  // b.any
    6a34:	f9400401 	ldr	x1, [x0, #8]
    6a38:	d1000421 	sub	x1, x1, #0x1
    6a3c:	f9000401 	str	x1, [x0, #8]
    6a40:	f103f83f 	cmp	x1, #0xfe
    6a44:	54fff6a1 	b.ne	6918 <fwp_drop10+0x98>  // b.any
    6a48:	aa1403e0 	mov	x0, x20
    6a4c:	97fff79d 	bl	48c0 <fwp_rc_forget_slot>
    6a50:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a54:	39000280 	strb	w0, [x20]
    6a58:	17ffffb0 	b	6918 <fwp_drop10+0x98>
    6a5c:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    6a60:	9139c000 	add	x0, x0, #0xe70
    6a64:	97fff387 	bl	3880 <fwp_trap>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_caps173>:
    6a70:	34000041 	cbz	w1, 6a78 <fwp_caps173+0x8>
    6a74:	d65f03c0 	ret
    6a78:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xbf0>
    6a7c:	9117c063 	add	x3, x3, #0x5f0
    6a80:	f949d861 	ldr	x1, [x3, #5040]
    6a84:	f949ec62 	ldr	x2, [x3, #5080]
    6a88:	cb010001 	sub	x1, x0, x1
    6a8c:	eb02403f 	cmp	x1, x2, lsl #16
    6a90:	54ffff22 	b.cs	6a74 <fwp_caps173+0x4>  // b.hs, b.nlast
    6a94:	d350fc22 	lsr	x2, x1, #16
    6a98:	f949fc65 	ldr	x5, [x3, #5112]
    6a9c:	8b020842 	add	x2, x2, x2, lsl #2
    6aa0:	d37df042 	lsl	x2, x2, #3
    6aa4:	8b0200a4 	add	x4, x5, x2
    6aa8:	f9401083 	ldr	x3, [x4, #32]
    6aac:	b4fffe43 	cbz	x3, 6a74 <fwp_caps173+0x4>
    6ab0:	386268a2 	ldrb	w2, [x5, x2]
    6ab4:	7100085f 	cmp	w2, #0x2
    6ab8:	540001c0 	b.eq	6af0 <fwp_caps173+0x80>  // b.none
    6abc:	7100045f 	cmp	w2, #0x1
    6ac0:	54fffda1 	b.ne	6a74 <fwp_caps173+0x4>  // b.any
    6ac4:	29430885 	ldp	w5, w2, [x4, #24]
    6ac8:	92403c21 	and	x1, x1, #0xffff
    6acc:	9b057c21 	mul	x1, x1, x5
    6ad0:	d360fc21 	lsr	x1, x1, #32
    6ad4:	eb02003f 	cmp	x1, x2
    6ad8:	54fffce2 	b.cs	6a74 <fwp_caps173+0x4>  // b.hs, b.nlast
    6adc:	8b010063 	add	x3, x3, x1
    6ae0:	39400061 	ldrb	w1, [x3]
    6ae4:	7100043f 	cmp	w1, #0x1
    6ae8:	54fffc61 	b.ne	6a74 <fwp_caps173+0x4>  // b.any
    6aec:	17fff815 	b	4b40 <fwp_mem_free>
    6af0:	72003c3f 	tst	w1, #0xffff
    6af4:	54ffff60 	b.eq	6ae0 <fwp_caps173+0x70>  // b.none
    6af8:	d65f03c0 	ret
    6afc:	d503201f 	nop

0000000000006b00 <f37>:
    6b00:	d101c3ff 	sub	sp, sp, #0x70
    6b04:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6b08:	f947f421 	ldr	x1, [x1, #4072]
    6b0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6b10:	910083fd 	add	x29, sp, #0x20
    6b14:	a90563f7 	stp	x23, x24, [sp, #80]
    6b18:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xbf0>
    6b1c:	9117c2e3 	add	x3, x23, #0x5f0
    6b20:	a90353f3 	stp	x19, x20, [sp, #48]
    6b24:	a9045bf5 	stp	x21, x22, [sp, #64]
    6b28:	aa0003f6 	mov	x22, x0
    6b2c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6b30:	f949ec62 	ldr	x2, [x3, #5080]
    6b34:	f9400024 	ldr	x4, [x1]
    6b38:	f9000fe4 	str	x4, [sp, #24]
    6b3c:	d2800004 	mov	x4, #0x0                   	// #0
    6b40:	f949d861 	ldr	x1, [x3, #5040]
    6b44:	d370bc42 	lsl	x2, x2, #16
    6b48:	b40015c0 	cbz	x0, 6e00 <f37+0x300>
    6b4c:	f9400818 	ldr	x24, [x0, #16]
    6b50:	cb010301 	sub	x1, x24, x1
    6b54:	eb02003f 	cmp	x1, x2
    6b58:	54000362 	b.cs	6bc4 <f37+0xc4>  // b.hs, b.nlast
    6b5c:	f949fc60 	ldr	x0, [x3, #5112]
    6b60:	d350fc22 	lsr	x2, x1, #16
    6b64:	8b020842 	add	x2, x2, x2, lsl #2
    6b68:	8b020c02 	add	x2, x0, x2, lsl #3
    6b6c:	f9401040 	ldr	x0, [x2, #32]
    6b70:	b40002a0 	cbz	x0, 6bc4 <f37+0xc4>
    6b74:	39400043 	ldrb	w3, [x2]
    6b78:	7100087f 	cmp	w3, #0x2
    6b7c:	540013c0 	b.eq	6df4 <f37+0x2f4>  // b.none
    6b80:	7100047f 	cmp	w3, #0x1
    6b84:	540001c1 	b.ne	6bbc <f37+0xbc>  // b.any
    6b88:	29430843 	ldp	w3, w2, [x2, #24]
    6b8c:	92403c21 	and	x1, x1, #0xffff
    6b90:	9b037c21 	mul	x1, x1, x3
    6b94:	d360fc21 	lsr	x1, x1, #32
    6b98:	eb02003f 	cmp	x1, x2
    6b9c:	54000102 	b.cs	6bbc <f37+0xbc>  // b.hs, b.nlast
    6ba0:	8b010000 	add	x0, x0, x1
    6ba4:	39400001 	ldrb	w1, [x0]
    6ba8:	340000a1 	cbz	w1, 6bbc <f37+0xbc>
    6bac:	7103f43f 	cmp	w1, #0xfd
    6bb0:	540016a8 	b.hi	6e84 <f37+0x384>  // b.pmore
    6bb4:	11000421 	add	w1, w1, #0x1
    6bb8:	39000001 	strb	w1, [x0]
    6bbc:	d2800000 	mov	x0, #0x0                   	// #0
    6bc0:	b40000f6 	cbz	x22, 6bdc <f37+0xdc>
    6bc4:	aa1603e1 	mov	x1, x22
    6bc8:	d2800000 	mov	x0, #0x0                   	// #0
    6bcc:	d503201f 	nop
    6bd0:	f9400821 	ldr	x1, [x1, #16]
    6bd4:	91000400 	add	x0, x0, #0x1
    6bd8:	b5ffffc1 	cbnz	x1, 6bd0 <f37+0xd0>
    6bdc:	b40011b8 	cbz	x24, 6e10 <f37+0x310>
    6be0:	aa1803e1 	mov	x1, x24
    6be4:	d2800002 	mov	x2, #0x0                   	// #0
    6be8:	f9400821 	ldr	x1, [x1, #16]
    6bec:	91000442 	add	x2, x2, #0x1
    6bf0:	b5ffffc1 	cbnz	x1, 6be8 <f37+0xe8>
    6bf4:	eb00005f 	cmp	x2, x0
    6bf8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6bfc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6c00:	eb01033f 	cmp	x25, x1
    6c04:	54001468 	b.hi	6e90 <f37+0x390>  // b.pmore
    6c08:	d37ffb33 	lsl	x19, x25, #1
    6c0c:	52800041 	mov	w1, #0x2                   	// #2
    6c10:	91000660 	add	x0, x19, #0x1
    6c14:	d37df000 	lsl	x0, x0, #3
    6c18:	97fff8ea 	bl	4fc0 <fwp_heap_alloc>
    6c1c:	9117c2e1 	add	x1, x23, #0x5f0
    6c20:	aa0003fa 	mov	x26, x0
    6c24:	f9000013 	str	x19, [x0]
    6c28:	aa0103e0 	mov	x0, x1
    6c2c:	f949d821 	ldr	x1, [x1, #5040]
    6c30:	f949ec00 	ldr	x0, [x0, #5080]
    6c34:	cb010341 	sub	x1, x26, x1
    6c38:	eb00403f 	cmp	x1, x0, lsl #16
    6c3c:	54000342 	b.cs	6ca4 <f37+0x1a4>  // b.hs, b.nlast
    6c40:	9117c2e2 	add	x2, x23, #0x5f0
    6c44:	d350fc20 	lsr	x0, x1, #16
    6c48:	8b000800 	add	x0, x0, x0, lsl #2
    6c4c:	f949fc43 	ldr	x3, [x2, #5112]
    6c50:	d37df002 	lsl	x2, x0, #3
    6c54:	8b020060 	add	x0, x3, x2
    6c58:	f9401013 	ldr	x19, [x0, #32]
    6c5c:	b4000253 	cbz	x19, 6ca4 <f37+0x1a4>
    6c60:	38626862 	ldrb	w2, [x3, x2]
    6c64:	7100085f 	cmp	w2, #0x2
    6c68:	54000c00 	b.eq	6de8 <f37+0x2e8>  // b.none
    6c6c:	7100045f 	cmp	w2, #0x1
    6c70:	540001a1 	b.ne	6ca4 <f37+0x1a4>  // b.any
    6c74:	29430002 	ldp	w2, w0, [x0, #24]
    6c78:	92403c21 	and	x1, x1, #0xffff
    6c7c:	9b027c21 	mul	x1, x1, x2
    6c80:	d360fc21 	lsr	x1, x1, #32
    6c84:	eb00003f 	cmp	x1, x0
    6c88:	540000e2 	b.cs	6ca4 <f37+0x1a4>  // b.hs, b.nlast
    6c8c:	8b010273 	add	x19, x19, x1
    6c90:	39400260 	ldrb	w0, [x19]
    6c94:	7103fc1f 	cmp	w0, #0xff
    6c98:	54000da0 	b.eq	6e4c <f37+0x34c>  // b.none
    6c9c:	52800020 	mov	w0, #0x1                   	// #1
    6ca0:	39000260 	strb	w0, [x19]
    6ca4:	b4000259 	cbz	x25, 6cec <f37+0x1ec>
    6ca8:	8b191359 	add	x25, x26, x25, lsl #4
    6cac:	aa1a03f3 	mov	x19, x26
    6cb0:	aa1603f5 	mov	x21, x22
    6cb4:	aa1803f4 	mov	x20, x24
    6cb8:	f9400683 	ldr	x3, [x20, #8]
    6cbc:	f94006a2 	ldr	x2, [x21, #8]
    6cc0:	f9400861 	ldr	x1, [x3, #16]
    6cc4:	f9400840 	ldr	x0, [x2, #16]
    6cc8:	fd400461 	ldr	d1, [x3, #8]
    6ccc:	fd400440 	ldr	d0, [x2, #8]
    6cd0:	97fff9fc 	bl	54c0 <w120>
    6cd4:	f9000660 	str	x0, [x19, #8]
    6cd8:	f8010e61 	str	x1, [x19, #16]!
    6cdc:	f9400a94 	ldr	x20, [x20, #16]
    6ce0:	f9400ab5 	ldr	x21, [x21, #16]
    6ce4:	eb13033f 	cmp	x25, x19
    6ce8:	54fffe81 	b.ne	6cb8 <f37+0x1b8>  // b.any
    6cec:	aa1803e0 	mov	x0, x24
    6cf0:	97fffd48 	bl	6210 <fwp_drop4>
    6cf4:	aa1603e0 	mov	x0, x22
    6cf8:	97fffd46 	bl	6210 <fwp_drop4>
    6cfc:	9117c2f7 	add	x23, x23, #0x5f0
    6d00:	aa1a03e0 	mov	x0, x26
    6d04:	97fffa43 	bl	5610 <w176.constprop.0>
    6d08:	aa0103f3 	mov	x19, x1
    6d0c:	aa0003f4 	mov	x20, x0
    6d10:	aa1a03e0 	mov	x0, x26
    6d14:	97fffedb 	bl	6880 <fwp_drop10>
    6d18:	a900cff4 	stp	x20, x19, [sp, #8]
    6d1c:	910023e1 	add	x1, sp, #0x8
    6d20:	52800000 	mov	w0, #0x0                   	// #0
    6d24:	97fff8ec 	bl	50d4 <fwp_data.part.0.constprop.0>
    6d28:	f949dae1 	ldr	x1, [x23, #5040]
    6d2c:	aa0003f3 	mov	x19, x0
    6d30:	f949eee0 	ldr	x0, [x23, #5080]
    6d34:	cb010261 	sub	x1, x19, x1
    6d38:	eb00403f 	cmp	x1, x0, lsl #16
    6d3c:	54000322 	b.cs	6da0 <f37+0x2a0>  // b.hs, b.nlast
    6d40:	d350fc22 	lsr	x2, x1, #16
    6d44:	f949fee3 	ldr	x3, [x23, #5112]
    6d48:	8b020842 	add	x2, x2, x2, lsl #2
    6d4c:	d37df042 	lsl	x2, x2, #3
    6d50:	8b020060 	add	x0, x3, x2
    6d54:	f9401014 	ldr	x20, [x0, #32]
    6d58:	b4000254 	cbz	x20, 6da0 <f37+0x2a0>
    6d5c:	38626862 	ldrb	w2, [x3, x2]
    6d60:	7100085f 	cmp	w2, #0x2
    6d64:	540003c0 	b.eq	6ddc <f37+0x2dc>  // b.none
    6d68:	7100045f 	cmp	w2, #0x1
    6d6c:	540001a1 	b.ne	6da0 <f37+0x2a0>  // b.any
    6d70:	29430002 	ldp	w2, w0, [x0, #24]
    6d74:	92403c21 	and	x1, x1, #0xffff
    6d78:	9b027c21 	mul	x1, x1, x2
    6d7c:	d360fc21 	lsr	x1, x1, #32
    6d80:	eb00003f 	cmp	x1, x0
    6d84:	540000e2 	b.cs	6da0 <f37+0x2a0>  // b.hs, b.nlast
    6d88:	8b010294 	add	x20, x20, x1
    6d8c:	39400280 	ldrb	w0, [x20]
    6d90:	7103fc1f 	cmp	w0, #0xff
    6d94:	54000620 	b.eq	6e58 <f37+0x358>  // b.none
    6d98:	52800020 	mov	w0, #0x1                   	// #1
    6d9c:	39000280 	strb	w0, [x20]
    6da0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6da4:	f947f400 	ldr	x0, [x0, #4072]
    6da8:	f9400fe2 	ldr	x2, [sp, #24]
    6dac:	f9400001 	ldr	x1, [x0]
    6db0:	eb010042 	subs	x2, x2, x1
    6db4:	d2800001 	mov	x1, #0x0                   	// #0
    6db8:	540006a1 	b.ne	6e8c <f37+0x38c>  // b.any
    6dbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6dc0:	aa1303e0 	mov	x0, x19
    6dc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6dc8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6dcc:	a94563f7 	ldp	x23, x24, [sp, #80]
    6dd0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6dd4:	9101c3ff 	add	sp, sp, #0x70
    6dd8:	d65f03c0 	ret
    6ddc:	72003c3f 	tst	w1, #0xffff
    6de0:	54fffe01 	b.ne	6da0 <f37+0x2a0>  // b.any
    6de4:	17ffffea 	b	6d8c <f37+0x28c>
    6de8:	72003c3f 	tst	w1, #0xffff
    6dec:	54fff5c1 	b.ne	6ca4 <f37+0x1a4>  // b.any
    6df0:	17ffffa8 	b	6c90 <f37+0x190>
    6df4:	72003c3f 	tst	w1, #0xffff
    6df8:	54ffee21 	b.ne	6bbc <f37+0xbc>  // b.any
    6dfc:	17ffff6a 	b	6ba4 <f37+0xa4>
    6e00:	cb0103e1 	neg	x1, x1
    6e04:	eb02003f 	cmp	x1, x2
    6e08:	540002e3 	b.cc	6e64 <f37+0x364>  // b.lo, b.ul, b.last
    6e0c:	d503201f 	nop
    6e10:	52800041 	mov	w1, #0x2                   	// #2
    6e14:	d2800100 	mov	x0, #0x8                   	// #8
    6e18:	97fff86a 	bl	4fc0 <fwp_heap_alloc>
    6e1c:	aa0003e1 	mov	x1, x0
    6e20:	9117c2e0 	add	x0, x23, #0x5f0
    6e24:	aa0103fa 	mov	x26, x1
    6e28:	d2800018 	mov	x24, #0x0                   	// #0
    6e2c:	f900003f 	str	xzr, [x1]
    6e30:	f949d801 	ldr	x1, [x0, #5040]
    6e34:	f949ec00 	ldr	x0, [x0, #5080]
    6e38:	cb010341 	sub	x1, x26, x1
    6e3c:	eb00403f 	cmp	x1, x0, lsl #16
    6e40:	54fff562 	b.cs	6cec <f37+0x1ec>  // b.hs, b.nlast
    6e44:	d2800019 	mov	x25, #0x0                   	// #0
    6e48:	17ffff7e 	b	6c40 <f37+0x140>
    6e4c:	aa1303e0 	mov	x0, x19
    6e50:	97fff69c 	bl	48c0 <fwp_rc_forget_slot>
    6e54:	17ffff92 	b	6c9c <f37+0x19c>
    6e58:	aa1403e0 	mov	x0, x20
    6e5c:	97fff699 	bl	48c0 <fwp_rc_forget_slot>
    6e60:	17ffffce 	b	6d98 <f37+0x298>
    6e64:	f949fc62 	ldr	x2, [x3, #5112]
    6e68:	d350fc20 	lsr	x0, x1, #16
    6e6c:	8b000800 	add	x0, x0, x0, lsl #2
    6e70:	8b000c42 	add	x2, x2, x0, lsl #3
    6e74:	f9401040 	ldr	x0, [x2, #32]
    6e78:	b4fffcc0 	cbz	x0, 6e10 <f37+0x310>
    6e7c:	d2800018 	mov	x24, #0x0                   	// #0
    6e80:	17ffff3d 	b	6b74 <f37+0x74>
    6e84:	97fff648 	bl	47a4 <fwp_rc_wide_dup>
    6e88:	17ffff4d 	b	6bbc <f37+0xbc>
    6e8c:	97ffeea1 	bl	2910 <__stack_chk_fail@plt>
    6e90:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    6e94:	913ec000 	add	x0, x0, #0xfb0
    6e98:	97fff27a 	bl	3880 <fwp_trap>
    6e9c:	d503201f 	nop

0000000000006ea0 <fwp_owned_entry37>:
    6ea0:	f9400000 	ldr	x0, [x0]
    6ea4:	17ffff17 	b	6b00 <f37>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <e37>:
    6eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	f9000bf3 	str	x19, [sp, #16]
    6ebc:	f9400013 	ldr	x19, [x0]
    6ec0:	aa1303e0 	mov	x0, x19
    6ec4:	97fff9ff 	bl	56c0 <fwp_rc_share>
    6ec8:	aa1303e0 	mov	x0, x19
    6ecc:	97ffff0d 	bl	6b00 <f37>
    6ed0:	aa0003f3 	mov	x19, x0
    6ed4:	97fff9fb 	bl	56c0 <fwp_rc_share>
    6ed8:	aa1303e0 	mov	x0, x19
    6edc:	f9400bf3 	ldr	x19, [sp, #16]
    6ee0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ee4:	d65f03c0 	ret
    6ee8:	d503201f 	nop
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_args37>:
    6ef0:	7100003f 	cmp	w1, #0x0
    6ef4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ef8:	54000041 	b.ne	6f00 <fwp_args37+0x10>  // b.any
    6efc:	d65f03c0 	ret
    6f00:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6f04:	9117c042 	add	x2, x2, #0x5f0
    6f08:	f9400001 	ldr	x1, [x0]
    6f0c:	f949d843 	ldr	x3, [x2, #5040]
    6f10:	f949ec40 	ldr	x0, [x2, #5080]
    6f14:	cb030021 	sub	x1, x1, x3
    6f18:	eb00403f 	cmp	x1, x0, lsl #16
    6f1c:	54ffff02 	b.cs	6efc <fwp_args37+0xc>  // b.hs, b.nlast
    6f20:	d350fc20 	lsr	x0, x1, #16
    6f24:	f949fc44 	ldr	x4, [x2, #5112]
    6f28:	8b000800 	add	x0, x0, x0, lsl #2
    6f2c:	d37df002 	lsl	x2, x0, #3
    6f30:	8b020083 	add	x3, x4, x2
    6f34:	f9401060 	ldr	x0, [x3, #32]
    6f38:	b4fffe20 	cbz	x0, 6efc <fwp_args37+0xc>
    6f3c:	38626882 	ldrb	w2, [x4, x2]
    6f40:	7100085f 	cmp	w2, #0x2
    6f44:	54000220 	b.eq	6f88 <fwp_args37+0x98>  // b.none
    6f48:	7100045f 	cmp	w2, #0x1
    6f4c:	54fffd81 	b.ne	6efc <fwp_args37+0xc>  // b.any
    6f50:	29430864 	ldp	w4, w2, [x3, #24]
    6f54:	92403c21 	and	x1, x1, #0xffff
    6f58:	9b047c21 	mul	x1, x1, x4
    6f5c:	d360fc21 	lsr	x1, x1, #32
    6f60:	eb02003f 	cmp	x1, x2
    6f64:	54fffcc2 	b.cs	6efc <fwp_args37+0xc>  // b.hs, b.nlast
    6f68:	8b010000 	add	x0, x0, x1
    6f6c:	39400001 	ldrb	w1, [x0]
    6f70:	34fffc61 	cbz	w1, 6efc <fwp_args37+0xc>
    6f74:	7103f43f 	cmp	w1, #0xfd
    6f78:	540000e8 	b.hi	6f94 <fwp_args37+0xa4>  // b.pmore
    6f7c:	11000421 	add	w1, w1, #0x1
    6f80:	39000001 	strb	w1, [x0]
    6f84:	d65f03c0 	ret
    6f88:	72003c3f 	tst	w1, #0xffff
    6f8c:	54ffff00 	b.eq	6f6c <fwp_args37+0x7c>  // b.none
    6f90:	d65f03c0 	ret
    6f94:	17fff604 	b	47a4 <fwp_rc_wide_dup>
    6f98:	d503201f 	nop
    6f9c:	d503201f 	nop

0000000000006fa0 <fwp_caps37>:
    6fa0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6fa4:	910003fd 	mov	x29, sp
    6fa8:	f9000bf3 	str	x19, [sp, #16]
    6fac:	aa0003f3 	mov	x19, x0
    6fb0:	b9400400 	ldr	w0, [x0, #4]
    6fb4:	340004a0 	cbz	w0, 7048 <fwp_caps37+0xa8>
    6fb8:	f9400660 	ldr	x0, [x19, #8]
    6fbc:	350004e1 	cbnz	w1, 7058 <fwp_caps37+0xb8>
    6fc0:	97fffc94 	bl	6210 <fwp_drop4>
    6fc4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    6fc8:	9117c042 	add	x2, x2, #0x5f0
    6fcc:	f949d840 	ldr	x0, [x2, #5040]
    6fd0:	f949ec41 	ldr	x1, [x2, #5080]
    6fd4:	cb000260 	sub	x0, x19, x0
    6fd8:	eb01401f 	cmp	x0, x1, lsl #16
    6fdc:	54000382 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    6fe0:	d350fc01 	lsr	x1, x0, #16
    6fe4:	f949fc44 	ldr	x4, [x2, #5112]
    6fe8:	8b010821 	add	x1, x1, x1, lsl #2
    6fec:	d37df021 	lsl	x1, x1, #3
    6ff0:	8b010083 	add	x3, x4, x1
    6ff4:	f9401062 	ldr	x2, [x3, #32]
    6ff8:	b40002a2 	cbz	x2, 704c <fwp_caps37+0xac>
    6ffc:	38616881 	ldrb	w1, [x4, x1]
    7000:	7100083f 	cmp	w1, #0x2
    7004:	540006c0 	b.eq	70dc <fwp_caps37+0x13c>  // b.none
    7008:	7100043f 	cmp	w1, #0x1
    700c:	54000201 	b.ne	704c <fwp_caps37+0xac>  // b.any
    7010:	29430464 	ldp	w4, w1, [x3, #24]
    7014:	92403c00 	and	x0, x0, #0xffff
    7018:	9b047c00 	mul	x0, x0, x4
    701c:	d360fc00 	lsr	x0, x0, #32
    7020:	eb01001f 	cmp	x0, x1
    7024:	54000142 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    7028:	8b000042 	add	x2, x2, x0
    702c:	39400040 	ldrb	w0, [x2]
    7030:	7100041f 	cmp	w0, #0x1
    7034:	540000c1 	b.ne	704c <fwp_caps37+0xac>  // b.any
    7038:	aa1303e0 	mov	x0, x19
    703c:	f9400bf3 	ldr	x19, [sp, #16]
    7040:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7044:	17fff6bf 	b	4b40 <fwp_mem_free>
    7048:	34fffbe1 	cbz	w1, 6fc4 <fwp_caps37+0x24>
    704c:	f9400bf3 	ldr	x19, [sp, #16]
    7050:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7054:	d65f03c0 	ret
    7058:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xbf0>
    705c:	9117c042 	add	x2, x2, #0x5f0
    7060:	f949d843 	ldr	x3, [x2, #5040]
    7064:	f949ec41 	ldr	x1, [x2, #5080]
    7068:	cb030000 	sub	x0, x0, x3
    706c:	eb01401f 	cmp	x0, x1, lsl #16
    7070:	54fffee2 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    7074:	d350fc01 	lsr	x1, x0, #16
    7078:	f949fc44 	ldr	x4, [x2, #5112]
    707c:	8b010821 	add	x1, x1, x1, lsl #2
    7080:	d37df021 	lsl	x1, x1, #3
    7084:	8b010083 	add	x3, x4, x1
    7088:	f9401062 	ldr	x2, [x3, #32]
    708c:	b4fffe02 	cbz	x2, 704c <fwp_caps37+0xac>
    7090:	38616881 	ldrb	w1, [x4, x1]
    7094:	7100083f 	cmp	w1, #0x2
    7098:	54000280 	b.eq	70e8 <fwp_caps37+0x148>  // b.none
    709c:	7100043f 	cmp	w1, #0x1
    70a0:	54fffd61 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70a4:	92403c01 	and	x1, x0, #0xffff
    70a8:	29430064 	ldp	w4, w0, [x3, #24]
    70ac:	9b047c21 	mul	x1, x1, x4
    70b0:	d360fc21 	lsr	x1, x1, #32
    70b4:	eb00003f 	cmp	x1, x0
    70b8:	54fffca2 	b.cs	704c <fwp_caps37+0xac>  // b.hs, b.nlast
    70bc:	8b010042 	add	x2, x2, x1
    70c0:	39400040 	ldrb	w0, [x2]
    70c4:	34fffc40 	cbz	w0, 704c <fwp_caps37+0xac>
    70c8:	7103f41f 	cmp	w0, #0xfd
    70cc:	54000148 	b.hi	70f4 <fwp_caps37+0x154>  // b.pmore
    70d0:	11000400 	add	w0, w0, #0x1
    70d4:	39000040 	strb	w0, [x2]
    70d8:	17ffffdd 	b	704c <fwp_caps37+0xac>
    70dc:	72003c1f 	tst	w0, #0xffff
    70e0:	54fffb61 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70e4:	17ffffd2 	b	702c <fwp_caps37+0x8c>
    70e8:	72003c1f 	tst	w0, #0xffff
    70ec:	54fffb01 	b.ne	704c <fwp_caps37+0xac>  // b.any
    70f0:	17fffff4 	b	70c0 <fwp_caps37+0x120>
    70f4:	f9400bf3 	ldr	x19, [sp, #16]
    70f8:	aa0203e0 	mov	x0, x2
    70fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7100:	17fff5a9 	b	47a4 <fwp_rc_wide_dup>

0000000000007104 <fwp_write>:
    7104:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7108:	910003fd 	mov	x29, sp
    710c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7110:	f947f484 	ldr	x4, [x4, #4072]
    7114:	a90153f3 	stp	x19, x20, [sp, #16]
    7118:	d10943ff 	sub	sp, sp, #0x250
    711c:	b9400045 	ldr	w5, [x2]
    7120:	aa0003f4 	mov	x20, x0
    7124:	f9400080 	ldr	x0, [x4]
    7128:	f90127e0 	str	x0, [sp, #584]
    712c:	d2800000 	mov	x0, #0x0                   	// #0
    7130:	710064bf 	cmp	w5, #0x19
    7134:	54000408 	b.hi	71b4 <fwp_write+0xb0>  // b.pmore
    7138:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    713c:	aa0103f3 	mov	x19, x1
    7140:	91220000 	add	x0, x0, #0x880
    7144:	f9013bf5 	str	x21, [sp, #624]
    7148:	f9013ff6 	str	x22, [sp, #632]
    714c:	f90153fb 	str	x27, [sp, #672]
    7150:	f90157fc 	str	x28, [sp, #680]
    7154:	aa0203fc 	mov	x28, x2
    7158:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    715c:	10000061 	adr	x1, 7168 <fwp_write+0x64>
    7160:	8b20a820 	add	x0, x1, w0, sxth #2
    7164:	d61f0000 	br	x0
    7168:	910123e0 	add	x0, sp, #0x48
    716c:	aa1303e5 	mov	x5, x19
    7170:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    7174:	aa0003f3 	mov	x19, x0
    7178:	913fe084 	add	x4, x4, #0xff8
    717c:	d2804003 	mov	x3, #0x200                 	// #512
    7180:	aa0303e1 	mov	x1, x3
    7184:	52800042 	mov	w2, #0x2                   	// #2
    7188:	97ffedbe 	bl	2880 <__snprintf_chk@plt>
    718c:	aa1303e0 	mov	x0, x19
    7190:	97ffed84 	bl	27a0 <strlen@plt>
    7194:	aa1303e1 	mov	x1, x19
    7198:	aa0003e2 	mov	x2, x0
    719c:	aa1403e0 	mov	x0, x20
    71a0:	97fff11c 	bl	3610 <buf_put>
    71a4:	f9413bf5 	ldr	x21, [sp, #624]
    71a8:	f9413ff6 	ldr	x22, [sp, #632]
    71ac:	f94153fb 	ldr	x27, [sp, #672]
    71b0:	f94157fc 	ldr	x28, [sp, #680]
    71b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71b8:	f947f400 	ldr	x0, [x0, #4072]
    71bc:	f94127e2 	ldr	x2, [sp, #584]
    71c0:	f9400001 	ldr	x1, [x0]
    71c4:	eb010042 	subs	x2, x2, x1
    71c8:	d2800001 	mov	x1, #0x0                   	// #0
    71cc:	540077a1 	b.ne	80c0 <fwp_write+0xfbc>  // b.any
    71d0:	910943ff 	add	sp, sp, #0x250
    71d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    71d8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    71dc:	d65f03c0 	ret
    71e0:	910123e0 	add	x0, sp, #0x48
    71e4:	aa1303e5 	mov	x5, x19
    71e8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1f10>
    71ec:	aa0003f3 	mov	x19, x0
    71f0:	913fc084 	add	x4, x4, #0xff0
    71f4:	d2804003 	mov	x3, #0x200                 	// #512
    71f8:	17ffffe2 	b	7180 <fwp_write+0x7c>
    71fc:	71004cbf 	cmp	w5, #0x13
    7200:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    7204:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    7208:	913f8000 	add	x0, x0, #0xfe0
    720c:	913fa021 	add	x1, x1, #0xfe8
    7210:	d2800082 	mov	x2, #0x4                   	// #4
    7214:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7218:	aa1403e0 	mov	x0, x20
    721c:	f90143f7 	str	x23, [sp, #640]
    7220:	d2800016 	mov	x22, #0x0                   	// #0
    7224:	f90147f8 	str	x24, [sp, #648]
    7228:	97fff0fa 	bl	3610 <buf_put>
    722c:	f9400260 	ldr	x0, [x19]
    7230:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x4f0>
    7234:	d2800015 	mov	x21, #0x0                   	// #0
    7238:	9101a2f7 	add	x23, x23, #0x68
    723c:	b4004780 	cbz	x0, 7b2c <fwp_write+0xa28>
    7240:	b9400380 	ldr	w0, [x28]
    7244:	52800003 	mov	w3, #0x0                   	// #0
    7248:	f9401f82 	ldr	x2, [x28, #56]
    724c:	71004c1f 	cmp	w0, #0x13
    7250:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7254:	aa1403e0 	mov	x0, x20
    7258:	8b010e61 	add	x1, x19, x1, lsl #3
    725c:	f9400421 	ldr	x1, [x1, #8]
    7260:	97ffffa9 	bl	7104 <fwp_write>
    7264:	b9400380 	ldr	w0, [x28]
    7268:	7100481f 	cmp	w0, #0x12
    726c:	54004b20 	b.eq	7bd0 <fwp_write+0xacc>  // b.none
    7270:	f9400260 	ldr	x0, [x19]
    7274:	910006b5 	add	x21, x21, #0x1
    7278:	91000ad6 	add	x22, x22, #0x2
    727c:	eb15001f 	cmp	x0, x21
    7280:	54004569 	b.ls	7b2c <fwp_write+0xa28>  // b.plast
    7284:	aa1703e1 	mov	x1, x23
    7288:	aa1403e0 	mov	x0, x20
    728c:	d2800042 	mov	x2, #0x2                   	// #2
    7290:	97fff0e0 	bl	3610 <buf_put>
    7294:	17ffffeb 	b	7240 <fwp_write+0x13c>
    7298:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    729c:	91008021 	add	x1, x1, #0x20
    72a0:	d28000c2 	mov	x2, #0x6                   	// #6
    72a4:	aa1403e0 	mov	x0, x20
    72a8:	91004273 	add	x19, x19, #0x10
    72ac:	97fff0d9 	bl	3610 <buf_put>
    72b0:	aa1303e0 	mov	x0, x19
    72b4:	97ffed3b 	bl	27a0 <strlen@plt>
    72b8:	aa1303e1 	mov	x1, x19
    72bc:	aa0003e2 	mov	x2, x0
    72c0:	aa1403e0 	mov	x0, x20
    72c4:	97fff0d3 	bl	3610 <buf_put>
    72c8:	528007c3 	mov	w3, #0x3e                  	// #62
    72cc:	aa1403e0 	mov	x0, x20
    72d0:	91001fe1 	add	x1, sp, #0x7
    72d4:	d2800022 	mov	x2, #0x1                   	// #1
    72d8:	39001fe3 	strb	w3, [sp, #7]
    72dc:	17ffffb1 	b	71a0 <fwp_write+0x9c>
    72e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72e4:	f947f400 	ldr	x0, [x0, #4072]
    72e8:	f94127e2 	ldr	x2, [sp, #584]
    72ec:	f9400001 	ldr	x1, [x0]
    72f0:	eb010042 	subs	x2, x2, x1
    72f4:	d2800001 	mov	x1, #0x0                   	// #0
    72f8:	540034c1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    72fc:	f9413bf5 	ldr	x21, [sp, #624]
    7300:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7304:	f9413ff6 	ldr	x22, [sp, #632]
    7308:	aa1403e0 	mov	x0, x20
    730c:	91000021 	add	x1, x1, #0x0
    7310:	d2800142 	mov	x2, #0xa                   	// #10
    7314:	f94153fb 	ldr	x27, [sp, #672]
    7318:	f94157fc 	ldr	x28, [sp, #680]
    731c:	910943ff 	add	sp, sp, #0x250
    7320:	a94153f3 	ldp	x19, x20, [sp, #16]
    7324:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7328:	17fff0ba 	b	3610 <buf_put>
    732c:	f9400456 	ldr	x22, [x2, #8]
    7330:	f90143f7 	str	x23, [sp, #640]
    7334:	f90147f8 	str	x24, [sp, #648]
    7338:	b4005af6 	cbz	x22, 7e94 <fwp_write+0xd90>
    733c:	aa1603e0 	mov	x0, x22
    7340:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7344:	91020021 	add	x1, x1, #0x80
    7348:	97ffed92 	bl	2990 <strcmp@plt>
    734c:	2a0003f5 	mov	w21, w0
    7350:	34005fc0 	cbz	w0, 7f48 <fwp_write+0xe44>
    7354:	aa1603e0 	mov	x0, x22
    7358:	97ffed12 	bl	27a0 <strlen@plt>
    735c:	aa1603e1 	mov	x1, x22
    7360:	aa0003e2 	mov	x2, x0
    7364:	aa1403e0 	mov	x0, x20
    7368:	97fff0aa 	bl	3610 <buf_put>
    736c:	52800403 	mov	w3, #0x20                  	// #32
    7370:	91001ff5 	add	x21, sp, #0x7
    7374:	aa1503e1 	mov	x1, x21
    7378:	aa1403e0 	mov	x0, x20
    737c:	d2800022 	mov	x2, #0x1                   	// #1
    7380:	39001fe3 	strb	w3, [sp, #7]
    7384:	97fff0a3 	bl	3610 <buf_put>
    7388:	52800f63 	mov	w3, #0x7b                  	// #123
    738c:	aa1403e0 	mov	x0, x20
    7390:	aa1503e1 	mov	x1, x21
    7394:	d2800022 	mov	x2, #0x1                   	// #1
    7398:	39001fe3 	strb	w3, [sp, #7]
    739c:	97fff09d 	bl	3610 <buf_put>
    73a0:	b9401380 	ldr	w0, [x28, #16]
    73a4:	52800018 	mov	w24, #0x0                   	// #0
    73a8:	7100001f 	cmp	w0, #0x0
    73ac:	54003a8d 	b.le	7afc <fwp_write+0x9f8>
    73b0:	f9014bf9 	str	x25, [sp, #656]
    73b4:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x4f0>
    73b8:	9102a339 	add	x25, x25, #0xa8
    73bc:	f9014ffa 	str	x26, [sp, #664]
    73c0:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x4f0>
    73c4:	9101a35a 	add	x26, x26, #0x68
    73c8:	91002276 	add	x22, x19, #0x8
    73cc:	d2800013 	mov	x19, #0x0                   	// #0
    73d0:	b5003e73 	cbnz	x19, 7b9c <fwp_write+0xa98>
    73d4:	d37df277 	lsl	x23, x19, #3
    73d8:	34003c98 	cbz	w24, 7b68 <fwp_write+0xa64>
    73dc:	f9401382 	ldr	x2, [x28, #32]
    73e0:	aa1403e0 	mov	x0, x20
    73e4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    73e8:	52800003 	mov	w3, #0x0                   	// #0
    73ec:	f8776842 	ldr	x2, [x2, x23]
    73f0:	91000673 	add	x19, x19, #0x1
    73f4:	97ffff44 	bl	7104 <fwp_write>
    73f8:	b9401380 	ldr	w0, [x28, #16]
    73fc:	6b13001f 	cmp	w0, w19
    7400:	54fffe8c 	b.gt	73d0 <fwp_write+0x2cc>
    7404:	f9414bf9 	ldr	x25, [sp, #656]
    7408:	f9414ffa 	ldr	x26, [sp, #664]
    740c:	34003798 	cbz	w24, 7afc <fwp_write+0x9f8>
    7410:	52800523 	mov	w3, #0x29                  	// #41
    7414:	aa1503e1 	mov	x1, x21
    7418:	aa1403e0 	mov	x0, x20
    741c:	d2800022 	mov	x2, #0x1                   	// #1
    7420:	39001fe3 	strb	w3, [sp, #7]
    7424:	97fff07b 	bl	3610 <buf_put>
    7428:	f9413bf5 	ldr	x21, [sp, #624]
    742c:	f9413ff6 	ldr	x22, [sp, #632]
    7430:	f94143f7 	ldr	x23, [sp, #640]
    7434:	f94147f8 	ldr	x24, [sp, #648]
    7438:	f94153fb 	ldr	x27, [sp, #672]
    743c:	f94157fc 	ldr	x28, [sp, #680]
    7440:	17ffff5d 	b	71b4 <fwp_write+0xb0>
    7444:	b9404855 	ldr	w21, [x2, #72]
    7448:	aa1403e0 	mov	x0, x20
    744c:	93407eb6 	sxtw	x22, w21
    7450:	91000ac1 	add	x1, x22, #0x2
    7454:	97fff03c 	bl	3544 <buf_grow>
    7458:	a9400281 	ldp	x1, x0, [x20]
    745c:	528e8603 	mov	w3, #0x7430                	// #29744
    7460:	78206823 	strh	w3, [x1, x0]
    7464:	8b000022 	add	x2, x1, x0
    7468:	710002bf 	cmp	w21, #0x0
    746c:	540036ad 	b.le	7b40 <fwp_write+0xa3c>
    7470:	110006a3 	add	w3, w21, #0x1
    7474:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7478:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    747c:	91000449 	add	x9, x2, #0x1
    7480:	8b23c043 	add	x3, x2, w3, sxtw
    7484:	f28aaac6 	movk	x6, #0x5556
    7488:	f2955568 	movk	x8, #0xaaab
    748c:	1400000d 	b	74c0 <fwp_write+0x3bc>
    7490:	d2800021 	mov	x1, #0x1                   	// #1
    7494:	528005a5 	mov	w5, #0x2d                  	// #45
    7498:	f100001f 	cmp	x0, #0x0
    749c:	9b467e60 	smulh	x0, x19, x6
    74a0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    74a4:	381ff465 	strb	w5, [x3], #-1
    74a8:	cb040000 	sub	x0, x0, x4
    74ac:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    74b0:	cb020000 	sub	x0, x0, x2
    74b4:	8b010013 	add	x19, x0, x1
    74b8:	eb03013f 	cmp	x9, x3
    74bc:	54003420 	b.eq	7b40 <fwp_write+0xa3c>  // b.none
    74c0:	9b467e60 	smulh	x0, x19, x6
    74c4:	937ffe64 	asr	x4, x19, #63
    74c8:	52800605 	mov	w5, #0x30                  	// #48
    74cc:	cb040000 	sub	x0, x0, x4
    74d0:	8b000400 	add	x0, x0, x0, lsl #1
    74d4:	cb000260 	sub	x0, x19, x0
    74d8:	91000c01 	add	x1, x0, #0x3
    74dc:	9bc87c22 	umulh	x2, x1, x8
    74e0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    74e4:	8b4204e2 	add	x2, x7, x2, lsr #1
    74e8:	eb020021 	subs	x1, x1, x2
    74ec:	54fffd60 	b.eq	7498 <fwp_write+0x394>  // b.none
    74f0:	f100043f 	cmp	x1, #0x1
    74f4:	54fffce1 	b.ne	7490 <fwp_write+0x38c>  // b.any
    74f8:	d2800001 	mov	x1, #0x0                   	// #0
    74fc:	52800565 	mov	w5, #0x2b                  	// #43
    7500:	17ffffe6 	b	7498 <fwp_write+0x394>
    7504:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7508:	f947f400 	ldr	x0, [x0, #4072]
    750c:	f94127e2 	ldr	x2, [sp, #584]
    7510:	f9400001 	ldr	x1, [x0]
    7514:	eb010042 	subs	x2, x2, x1
    7518:	d2800001 	mov	x1, #0x0                   	// #0
    751c:	540023a1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    7520:	f9413bf5 	ldr	x21, [sp, #624]
    7524:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7528:	f9413ff6 	ldr	x22, [sp, #632]
    752c:	aa1403e0 	mov	x0, x20
    7530:	91004021 	add	x1, x1, #0x10
    7534:	d2800102 	mov	x2, #0x8                   	// #8
    7538:	17ffff77 	b	7314 <fwp_write+0x210>
    753c:	aa1403e0 	mov	x0, x20
    7540:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7544:	d28000c2 	mov	x2, #0x6                   	// #6
    7548:	9101c021 	add	x1, x1, #0x70
    754c:	97fff031 	bl	3610 <buf_put>
    7550:	d2800015 	mov	x21, #0x0                   	// #0
    7554:	f9400263 	ldr	x3, [x19]
    7558:	f240f87f 	tst	x3, #0x7fffffffffffffff
    755c:	54002c40 	b.eq	7ae4 <fwp_write+0x9e0>  // b.none
    7560:	f9401f82 	ldr	x2, [x28, #56]
    7564:	f90143f7 	str	x23, [sp, #640]
    7568:	f90147f8 	str	x24, [sp, #648]
    756c:	d2800857 	mov	x23, #0x42                  	// #66
    7570:	f9014bf9 	str	x25, [sp, #656]
    7574:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x4f0>
    7578:	f9014ffa 	str	x26, [sp, #664]
    757c:	9101a2d6 	add	x22, x22, #0x68
    7580:	d2800038 	mov	x24, #0x1                   	// #1
    7584:	f2a18017 	movk	x23, #0xc00, lsl #16
    7588:	d2809099 	mov	x25, #0x484                 	// #1156
    758c:	b4000482 	cbz	x2, 761c <fwp_write+0x518>
    7590:	b9400040 	ldr	w0, [x2]
    7594:	7100701f 	cmp	w0, #0x1c
    7598:	540042a0 	b.eq	7dec <fwp_write+0xce8>  // b.none
    759c:	71006c1f 	cmp	w0, #0x1b
    75a0:	540003e8 	b.hi	761c <fwp_write+0x518>  // b.pmore
    75a4:	9ac02301 	lsl	x1, x24, x0
    75a8:	ea17003f 	tst	x1, x23
    75ac:	54003681 	b.ne	7c7c <fwp_write+0xb78>  // b.any
    75b0:	ea19003f 	tst	x1, x25
    75b4:	54003501 	b.ne	7c54 <fwp_write+0xb50>  // b.any
    75b8:	d2800424 	mov	x4, #0x21                  	// #33
    75bc:	ea04003f 	tst	x1, x4
    75c0:	540002e0 	b.eq	761c <fwp_write+0x518>  // b.none
    75c4:	b7f849a3 	tbnz	x3, #63, 7ef8 <fwp_write+0xdf4>
    75c8:	91002261 	add	x1, x19, #0x8
    75cc:	8b150021 	add	x1, x1, x21
    75d0:	39400021 	ldrb	w1, [x1]
    75d4:	7100001f 	cmp	w0, #0x0
    75d8:	93401c23 	sxtb	x3, w1
    75dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    75e0:	aa1403e0 	mov	x0, x20
    75e4:	52800003 	mov	w3, #0x0                   	// #0
    75e8:	97fffec7 	bl	7104 <fwp_write>
    75ec:	910006b5 	add	x21, x21, #0x1
    75f0:	f9400260 	ldr	x0, [x19]
    75f4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    75f8:	eb0002bf 	cmp	x21, x0
    75fc:	540026c2 	b.cs	7ad4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7600:	d2800042 	mov	x2, #0x2                   	// #2
    7604:	aa1603e1 	mov	x1, x22
    7608:	aa1403e0 	mov	x0, x20
    760c:	97fff001 	bl	3610 <buf_put>
    7610:	f9401f82 	ldr	x2, [x28, #56]
    7614:	f9400263 	ldr	x3, [x19]
    7618:	b5fffbc2 	cbnz	x2, 7590 <fwp_write+0x48c>
    761c:	d37df2a0 	lsl	x0, x21, #3
    7620:	b7f83f03 	tbnz	x3, #63, 7e00 <fwp_write+0xcfc>
    7624:	91002261 	add	x1, x19, #0x8
    7628:	8b000020 	add	x0, x1, x0
    762c:	f9400001 	ldr	x1, [x0]
    7630:	17ffffec 	b	75e0 <fwp_write+0x4dc>
    7634:	a9400e62 	ldp	x2, x3, [x19]
    7638:	b7f83ca3 	tbnz	x3, #63, 7dcc <fwp_write+0xcc8>
    763c:	910123f5 	add	x21, sp, #0x48
    7640:	aa1503e0 	mov	x0, x21
    7644:	97ffee17 	bl	2ea0 <fwp_fmt_u128>
    7648:	aa1503e0 	mov	x0, x21
    764c:	97ffec55 	bl	27a0 <strlen@plt>
    7650:	aa1503e1 	mov	x1, x21
    7654:	aa0003e2 	mov	x2, x0
    7658:	17fffed1 	b	719c <fwp_write+0x98>
    765c:	fd015be8 	str	d8, [sp, #688]
    7660:	1e270268 	fmov	s8, w19
    7664:	fd015fe9 	str	d9, [sp, #696]
    7668:	1e282100 	fcmp	s8, s8
    766c:	54004d26 	b.vs	8010 <fwp_write+0xf0c>
    7670:	1e20c101 	fabs	s1, s8
    7674:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7678:	1e270000 	fmov	s0, w0
    767c:	1e202020 	fcmp	s1, s0
    7680:	54002c0d 	b.le	7c00 <fwp_write+0xafc>
    7684:	1e202118 	fcmpe	s8, #0.0
    7688:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1f10>
    768c:	912fa042 	add	x2, x2, #0xbe8
    7690:	910123f5 	add	x21, sp, #0x48
    7694:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    7698:	913f0021 	add	x1, x1, #0xfc0
    769c:	aa1503e0 	mov	x0, x21
    76a0:	9a81c041 	csel	x1, x2, x1, gt
    76a4:	97ffeceb 	bl	2a50 <strcpy@plt>
    76a8:	aa1503e0 	mov	x0, x21
    76ac:	97ffec3d 	bl	27a0 <strlen@plt>
    76b0:	aa1503e1 	mov	x1, x21
    76b4:	aa0003e2 	mov	x2, x0
    76b8:	aa1403e0 	mov	x0, x20
    76bc:	97ffefd5 	bl	3610 <buf_put>
    76c0:	f9413bf5 	ldr	x21, [sp, #624]
    76c4:	f9413ff6 	ldr	x22, [sp, #632]
    76c8:	f94153fb 	ldr	x27, [sp, #672]
    76cc:	f94157fc 	ldr	x28, [sp, #680]
    76d0:	fd415be8 	ldr	d8, [sp, #688]
    76d4:	fd415fe9 	ldr	d9, [sp, #696]
    76d8:	17fffeb7 	b	71b4 <fwp_write+0xb0>
    76dc:	f9400276 	ldr	x22, [x19]
    76e0:	34002e03 	cbz	w3, 7ca0 <fwp_write+0xb9c>
    76e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76e8:	f947f400 	ldr	x0, [x0, #4072]
    76ec:	f94127e2 	ldr	x2, [sp, #584]
    76f0:	f9400001 	ldr	x1, [x0]
    76f4:	eb010042 	subs	x2, x2, x1
    76f8:	d2800001 	mov	x1, #0x0                   	// #0
    76fc:	540014a1 	b.ne	7990 <fwp_write+0x88c>  // b.any
    7700:	aa1603e2 	mov	x2, x22
    7704:	91002261 	add	x1, x19, #0x8
    7708:	f9413bf5 	ldr	x21, [sp, #624]
    770c:	aa1403e0 	mov	x0, x20
    7710:	f9413ff6 	ldr	x22, [sp, #632]
    7714:	17ffff00 	b	7314 <fwp_write+0x210>
    7718:	fd015be8 	str	d8, [sp, #688]
    771c:	9e670268 	fmov	d8, x19
    7720:	fd015fe9 	str	d9, [sp, #696]
    7724:	1e682100 	fcmp	d8, d8
    7728:	54004746 	b.vs	8010 <fwp_write+0xf0c>
    772c:	1e60c101 	fabs	d1, d8
    7730:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7734:	9e670000 	fmov	d0, x0
    7738:	910123f5 	add	x21, sp, #0x48
    773c:	52800033 	mov	w19, #0x1                   	// #1
    7740:	1e602020 	fcmp	d1, d0
    7744:	540001ad 	b.le	7778 <fwp_write+0x674>
    7748:	1e602118 	fcmpe	d8, #0.0
    774c:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1f10>
    7750:	912fa042 	add	x2, x2, #0xbe8
    7754:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    7758:	913f0021 	add	x1, x1, #0xfc0
    775c:	aa1503e0 	mov	x0, x21
    7760:	9a81c041 	csel	x1, x2, x1, gt
    7764:	97ffecbb 	bl	2a50 <strcpy@plt>
    7768:	17ffffd0 	b	76a8 <fwp_write+0x5a4>
    776c:	11000673 	add	w19, w19, #0x1
    7770:	71004a7f 	cmp	w19, #0x12
    7774:	54003860 	b.eq	7e80 <fwp_write+0xd7c>  // b.none
    7778:	1e604100 	fmov	d0, d8
    777c:	2a1303e1 	mov	w1, w19
    7780:	aa1503e0 	mov	x0, x21
    7784:	97fff124 	bl	3c14 <fwp_format_g.constprop.0>
    7788:	aa1503e0 	mov	x0, x21
    778c:	d2800001 	mov	x1, #0x0                   	// #0
    7790:	97ffec18 	bl	27f0 <strtod@plt>
    7794:	1e602100 	fcmp	d8, d0
    7798:	54fffea1 	b.ne	776c <fwp_write+0x668>  // b.any
    779c:	aa1503e0 	mov	x0, x21
    77a0:	97fff015 	bl	37f4 <fwp_finish_float>
    77a4:	17ffffc1 	b	76a8 <fwp_write+0x5a4>
    77a8:	a9400e62 	ldp	x2, x3, [x19]
    77ac:	910123f3 	add	x19, sp, #0x48
    77b0:	aa1303e0 	mov	x0, x19
    77b4:	97ffedbb 	bl	2ea0 <fwp_fmt_u128>
    77b8:	17fffe75 	b	718c <fwp_write+0x88>
    77bc:	f90143f7 	str	x23, [sp, #640]
    77c0:	f90147f8 	str	x24, [sp, #648]
    77c4:	2a1303f8 	mov	w24, w19
    77c8:	f9014bf9 	str	x25, [sp, #656]
    77cc:	f9014ffa 	str	x26, [sp, #664]
    77d0:	f13ffe7f 	cmp	x19, #0xfff
    77d4:	54000049 	b.ls	77dc <fwp_write+0x6d8>  // b.plast
    77d8:	b9400278 	ldr	w24, [x19]
    77dc:	f9400f80 	ldr	x0, [x28, #24]
    77e0:	2a1803f5 	mov	w21, w24
    77e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    77e8:	d37ef6b9 	lsl	x25, x21, #2
    77ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    77f0:	aa1603e0 	mov	x0, x22
    77f4:	97ffebeb 	bl	27a0 <strlen@plt>
    77f8:	aa1603e1 	mov	x1, x22
    77fc:	aa0003e2 	mov	x2, x0
    7800:	aa1403e0 	mov	x0, x20
    7804:	97ffef83 	bl	3610 <buf_put>
    7808:	f9401780 	ldr	x0, [x28, #40]
    780c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7810:	7100001f 	cmp	w0, #0x0
    7814:	5400068d 	b.le	78e4 <fwp_write+0x7e0>
    7818:	91002276 	add	x22, x19, #0x8
    781c:	91001ff5 	add	x21, sp, #0x7
    7820:	d280001b 	mov	x27, #0x0                   	// #0
    7824:	5280041a 	mov	w26, #0x20                  	// #32
    7828:	f9401b80 	ldr	x0, [x28, #48]
    782c:	aa1503e1 	mov	x1, x21
    7830:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7834:	d2800022 	mov	x2, #0x1                   	// #1
    7838:	f8786803 	ldr	x3, [x0, x24]
    783c:	aa1403e0 	mov	x0, x20
    7840:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7844:	39001ffa 	strb	w26, [sp, #7]
    7848:	97ffef72 	bl	3610 <buf_put>
    784c:	f13ffeff 	cmp	x23, #0xfff
    7850:	b9400261 	ldr	w1, [x19]
    7854:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7858:	7100383f 	cmp	w1, #0xe
    785c:	54000160 	b.eq	7888 <fwp_write+0x784>  // b.none
    7860:	7100403f 	cmp	w1, #0x10
    7864:	54001a60 	b.eq	7bb0 <fwp_write+0xaac>  // b.none
    7868:	7100283f 	cmp	w1, #0xa
    786c:	54002aa0 	b.eq	7dc0 <fwp_write+0xcbc>  // b.none
    7870:	540014ac 	b.gt	7b04 <fwp_write+0xa00>
    7874:	71000c3f 	cmp	w1, #0x3
    7878:	540029ac 	b.gt	7dac <fwp_write+0xca8>
    787c:	d37ffee0 	lsr	x0, x23, #63
    7880:	37f814a1 	tbnz	w1, #31, 7b14 <fwp_write+0xa10>
    7884:	d503201f 	nop
    7888:	34001460 	cbz	w0, 7b14 <fwp_write+0xa10>
    788c:	52800503 	mov	w3, #0x28                  	// #40
    7890:	aa1503e1 	mov	x1, x21
    7894:	aa1403e0 	mov	x0, x20
    7898:	d2800022 	mov	x2, #0x1                   	// #1
    789c:	39001fe3 	strb	w3, [sp, #7]
    78a0:	97ffef5c 	bl	3610 <buf_put>
    78a4:	aa1303e2 	mov	x2, x19
    78a8:	aa1703e1 	mov	x1, x23
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	52800003 	mov	w3, #0x0                   	// #0
    78b4:	97fffe14 	bl	7104 <fwp_write>
    78b8:	52800523 	mov	w3, #0x29                  	// #41
    78bc:	aa1503e1 	mov	x1, x21
    78c0:	aa1403e0 	mov	x0, x20
    78c4:	d2800022 	mov	x2, #0x1                   	// #1
    78c8:	39001fe3 	strb	w3, [sp, #7]
    78cc:	97ffef51 	bl	3610 <buf_put>
    78d0:	f9401780 	ldr	x0, [x28, #40]
    78d4:	9100077b 	add	x27, x27, #0x1
    78d8:	b8796800 	ldr	w0, [x0, x25]
    78dc:	6b1b001f 	cmp	w0, w27
    78e0:	54fffa4c 	b.gt	7828 <fwp_write+0x724>
    78e4:	f9413bf5 	ldr	x21, [sp, #624]
    78e8:	f9413ff6 	ldr	x22, [sp, #632]
    78ec:	f94143f7 	ldr	x23, [sp, #640]
    78f0:	f94147f8 	ldr	x24, [sp, #648]
    78f4:	f9414bf9 	ldr	x25, [sp, #656]
    78f8:	f9414ffa 	ldr	x26, [sp, #664]
    78fc:	f94153fb 	ldr	x27, [sp, #672]
    7900:	f94157fc 	ldr	x28, [sp, #680]
    7904:	17fffe2c 	b	71b4 <fwp_write+0xb0>
    7908:	52800783 	mov	w3, #0x3c                  	// #60
    790c:	91001ff3 	add	x19, sp, #0x7
    7910:	aa1303e1 	mov	x1, x19
    7914:	d2800022 	mov	x2, #0x1                   	// #1
    7918:	aa1403e0 	mov	x0, x20
    791c:	39001fe3 	strb	w3, [sp, #7]
    7920:	97ffef3c 	bl	3610 <buf_put>
    7924:	f9400795 	ldr	x21, [x28, #8]
    7928:	aa1503e0 	mov	x0, x21
    792c:	97ffeb9d 	bl	27a0 <strlen@plt>
    7930:	aa1503e1 	mov	x1, x21
    7934:	aa0003e2 	mov	x2, x0
    7938:	aa1403e0 	mov	x0, x20
    793c:	97ffef35 	bl	3610 <buf_put>
    7940:	528007c3 	mov	w3, #0x3e                  	// #62
    7944:	aa1303e1 	mov	x1, x19
    7948:	aa1403e0 	mov	x0, x20
    794c:	d2800022 	mov	x2, #0x1                   	// #1
    7950:	39001fe3 	strb	w3, [sp, #7]
    7954:	17fffe13 	b	71a0 <fwp_write+0x9c>
    7958:	f100067f 	cmp	x19, #0x1
    795c:	540025a0 	b.eq	7e10 <fwp_write+0xd0c>  // b.none
    7960:	b100067f 	cmn	x19, #0x1
    7964:	54002bc0 	b.eq	7edc <fwp_write+0xdd8>  // b.none
    7968:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    796c:	913f2021 	add	x1, x1, #0xfc8
    7970:	d2800022 	mov	x2, #0x1                   	// #1
    7974:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7978:	f947f400 	ldr	x0, [x0, #4072]
    797c:	f94127e4 	ldr	x4, [sp, #584]
    7980:	f9400003 	ldr	x3, [x0]
    7984:	eb030084 	subs	x4, x4, x3
    7988:	d2800003 	mov	x3, #0x0                   	// #0
    798c:	54ffebe0 	b.eq	7708 <fwp_write+0x604>  // b.none
    7990:	f90143f7 	str	x23, [sp, #640]
    7994:	f90147f8 	str	x24, [sp, #648]
    7998:	f9014bf9 	str	x25, [sp, #656]
    799c:	f9014ffa 	str	x26, [sp, #664]
    79a0:	fd015be8 	str	d8, [sp, #688]
    79a4:	fd015fe9 	str	d9, [sp, #696]
    79a8:	97ffebda 	bl	2910 <__stack_chk_fail@plt>
    79ac:	52800b63 	mov	w3, #0x5b                  	// #91
    79b0:	91001ff5 	add	x21, sp, #0x7
    79b4:	aa1503e1 	mov	x1, x21
    79b8:	aa1403e0 	mov	x0, x20
    79bc:	d2800022 	mov	x2, #0x1                   	// #1
    79c0:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x4f0>
    79c4:	9101a2d6 	add	x22, x22, #0x68
    79c8:	39001fe3 	strb	w3, [sp, #7]
    79cc:	97ffef11 	bl	3610 <buf_put>
    79d0:	b4000273 	cbz	x19, 7a1c <fwp_write+0x918>
    79d4:	f9400661 	ldr	x1, [x19, #8]
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	f9401f82 	ldr	x2, [x28, #56]
    79e0:	52800003 	mov	w3, #0x0                   	// #0
    79e4:	97fffdc8 	bl	7104 <fwp_write>
    79e8:	f9400a73 	ldr	x19, [x19, #16]
    79ec:	b4000193 	cbz	x19, 7a1c <fwp_write+0x918>
    79f0:	aa1603e1 	mov	x1, x22
    79f4:	aa1403e0 	mov	x0, x20
    79f8:	d2800042 	mov	x2, #0x2                   	// #2
    79fc:	97ffef05 	bl	3610 <buf_put>
    7a00:	f9400661 	ldr	x1, [x19, #8]
    7a04:	aa1403e0 	mov	x0, x20
    7a08:	f9401f82 	ldr	x2, [x28, #56]
    7a0c:	52800003 	mov	w3, #0x0                   	// #0
    7a10:	97fffdbd 	bl	7104 <fwp_write>
    7a14:	f9400a73 	ldr	x19, [x19, #16]
    7a18:	b5fffed3 	cbnz	x19, 79f0 <fwp_write+0x8ec>
    7a1c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7a20:	aa1503e1 	mov	x1, x21
    7a24:	aa1403e0 	mov	x0, x20
    7a28:	d2800022 	mov	x2, #0x1                   	// #1
    7a2c:	39001fe3 	strb	w3, [sp, #7]
    7a30:	17fffddc 	b	71a0 <fwp_write+0x9c>
    7a34:	aa1403e0 	mov	x0, x20
    7a38:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7a3c:	d28000c2 	mov	x2, #0x6                   	// #6
    7a40:	91016021 	add	x1, x1, #0x58
    7a44:	97ffeef3 	bl	3610 <buf_put>
    7a48:	f9400260 	ldr	x0, [x19]
    7a4c:	b40004c0 	cbz	x0, 7ae4 <fwp_write+0x9e0>
    7a50:	910123f5 	add	x21, sp, #0x48
    7a54:	91002276 	add	x22, x19, #0x8
    7a58:	f90143f7 	str	x23, [sp, #640]
    7a5c:	d2800017 	mov	x23, #0x0                   	// #0
    7a60:	f90147f8 	str	x24, [sp, #648]
    7a64:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x4f0>
    7a68:	91018318 	add	x24, x24, #0x60
    7a6c:	f9014bf9 	str	x25, [sp, #656]
    7a70:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x4f0>
    7a74:	9101a339 	add	x25, x25, #0x68
    7a78:	f9014ffa 	str	x26, [sp, #664]
    7a7c:	14000005 	b	7a90 <fwp_write+0x98c>
    7a80:	aa1903e1 	mov	x1, x25
    7a84:	aa1403e0 	mov	x0, x20
    7a88:	d2800042 	mov	x2, #0x2                   	// #2
    7a8c:	97ffeee1 	bl	3610 <buf_put>
    7a90:	38776ac5 	ldrb	w5, [x22, x23]
    7a94:	d2804003 	mov	x3, #0x200                 	// #512
    7a98:	aa1803e4 	mov	x4, x24
    7a9c:	aa0303e1 	mov	x1, x3
    7aa0:	52800042 	mov	w2, #0x2                   	// #2
    7aa4:	aa1503e0 	mov	x0, x21
    7aa8:	910006f7 	add	x23, x23, #0x1
    7aac:	97ffeb75 	bl	2880 <__snprintf_chk@plt>
    7ab0:	aa1503e0 	mov	x0, x21
    7ab4:	97ffeb3b 	bl	27a0 <strlen@plt>
    7ab8:	aa1503e1 	mov	x1, x21
    7abc:	aa0003e2 	mov	x2, x0
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	97ffeed3 	bl	3610 <buf_put>
    7ac8:	f9400260 	ldr	x0, [x19]
    7acc:	eb17001f 	cmp	x0, x23
    7ad0:	54fffd88 	b.hi	7a80 <fwp_write+0x97c>  // b.pmore
    7ad4:	f94143f7 	ldr	x23, [sp, #640]
    7ad8:	f94147f8 	ldr	x24, [sp, #648]
    7adc:	f9414bf9 	ldr	x25, [sp, #656]
    7ae0:	f9414ffa 	ldr	x26, [sp, #664]
    7ae4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ae8:	aa1403e0 	mov	x0, x20
    7aec:	91001fe1 	add	x1, sp, #0x7
    7af0:	d2800022 	mov	x2, #0x1                   	// #1
    7af4:	39001fe3 	strb	w3, [sp, #7]
    7af8:	17fffdaa 	b	71a0 <fwp_write+0x9c>
    7afc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b00:	17fffe45 	b	7414 <fwp_write+0x310>
    7b04:	f10002ff 	cmp	x23, #0x0
    7b08:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b0c:	71002c3f 	cmp	w1, #0xb
    7b10:	54ffebc0 	b.eq	7888 <fwp_write+0x784>  // b.none
    7b14:	aa1303e2 	mov	x2, x19
    7b18:	aa1703e1 	mov	x1, x23
    7b1c:	aa1403e0 	mov	x0, x20
    7b20:	52800003 	mov	w3, #0x0                   	// #0
    7b24:	97fffd78 	bl	7104 <fwp_write>
    7b28:	17ffff6a 	b	78d0 <fwp_write+0x7cc>
    7b2c:	aa1403e0 	mov	x0, x20
    7b30:	91001fe1 	add	x1, sp, #0x7
    7b34:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b38:	d2800022 	mov	x2, #0x1                   	// #1
    7b3c:	17fffe39 	b	7420 <fwp_write+0x31c>
    7b40:	a9400281 	ldp	x1, x0, [x20]
    7b44:	91000800 	add	x0, x0, #0x2
    7b48:	8b160000 	add	x0, x0, x22
    7b4c:	f9000680 	str	x0, [x20, #8]
    7b50:	3820683f 	strb	wzr, [x1, x0]
    7b54:	f9413bf5 	ldr	x21, [sp, #624]
    7b58:	f9413ff6 	ldr	x22, [sp, #632]
    7b5c:	f94153fb 	ldr	x27, [sp, #672]
    7b60:	f94157fc 	ldr	x28, [sp, #680]
    7b64:	17fffd94 	b	71b4 <fwp_write+0xb0>
    7b68:	f9400f80 	ldr	x0, [x28, #24]
    7b6c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7b70:	aa1b03e0 	mov	x0, x27
    7b74:	97ffeb0b 	bl	27a0 <strlen@plt>
    7b78:	aa1b03e1 	mov	x1, x27
    7b7c:	aa0003e2 	mov	x2, x0
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	97ffeea3 	bl	3610 <buf_put>
    7b88:	aa1903e1 	mov	x1, x25
    7b8c:	aa1403e0 	mov	x0, x20
    7b90:	d2800062 	mov	x2, #0x3                   	// #3
    7b94:	97ffee9f 	bl	3610 <buf_put>
    7b98:	17fffe11 	b	73dc <fwp_write+0x2d8>
    7b9c:	aa1a03e1 	mov	x1, x26
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	d2800042 	mov	x2, #0x2                   	// #2
    7ba8:	97ffee9a 	bl	3610 <buf_put>
    7bac:	17fffe0a 	b	73d4 <fwp_write+0x2d0>
    7bb0:	f9400660 	ldr	x0, [x19, #8]
    7bb4:	b4fffb00 	cbz	x0, 7b14 <fwp_write+0xa10>
    7bb8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7bbc:	91020021 	add	x1, x1, #0x80
    7bc0:	97ffeb74 	bl	2990 <strcmp@plt>
    7bc4:	7100001f 	cmp	w0, #0x0
    7bc8:	1a9f07e0 	cset	w0, ne	// ne = any
    7bcc:	17ffff2f 	b	7888 <fwp_write+0x784>
    7bd0:	aa1403e0 	mov	x0, x20
    7bd4:	d2800042 	mov	x2, #0x2                   	// #2
    7bd8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7bdc:	9101e021 	add	x1, x1, #0x78
    7be0:	97ffee8c 	bl	3610 <buf_put>
    7be4:	91004261 	add	x1, x19, #0x10
    7be8:	aa1403e0 	mov	x0, x20
    7bec:	f9402382 	ldr	x2, [x28, #64]
    7bf0:	52800003 	mov	w3, #0x0                   	// #0
    7bf4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7bf8:	97fffd43 	bl	7104 <fwp_write>
    7bfc:	17fffd9d 	b	7270 <fwp_write+0x16c>
    7c00:	1e22c109 	fcvt	d9, s8
    7c04:	910123f5 	add	x21, sp, #0x48
    7c08:	52800033 	mov	w19, #0x1                   	// #1
    7c0c:	d503201f 	nop
    7c10:	1e604120 	fmov	d0, d9
    7c14:	2a1303e1 	mov	w1, w19
    7c18:	aa1503e0 	mov	x0, x21
    7c1c:	97ffeffe 	bl	3c14 <fwp_format_g.constprop.0>
    7c20:	aa1503e0 	mov	x0, x21
    7c24:	d2800001 	mov	x1, #0x0                   	// #0
    7c28:	97ffeb66 	bl	29c0 <strtof@plt>
    7c2c:	1e202100 	fcmp	s8, s0
    7c30:	54ffdb60 	b.eq	779c <fwp_write+0x698>  // b.none
    7c34:	11000673 	add	w19, w19, #0x1
    7c38:	71002a7f 	cmp	w19, #0xa
    7c3c:	54fffea1 	b.ne	7c10 <fwp_write+0xb0c>  // b.any
    7c40:	1e604120 	fmov	d0, d9
    7c44:	aa1503e0 	mov	x0, x21
    7c48:	52800121 	mov	w1, #0x9                   	// #9
    7c4c:	97ffeff2 	bl	3c14 <fwp_format_g.constprop.0>
    7c50:	17fffed3 	b	779c <fwp_write+0x698>
    7c54:	d37ef6a1 	lsl	x1, x21, #2
    7c58:	b7f81563 	tbnz	x3, #63, 7f04 <fwp_write+0xe00>
    7c5c:	91002263 	add	x3, x19, #0x8
    7c60:	8b010061 	add	x1, x3, x1
    7c64:	b9400023 	ldr	w3, [x1]
    7c68:	7100081f 	cmp	w0, #0x2
    7c6c:	2a0303e1 	mov	w1, w3
    7c70:	93407c63 	sxtw	x3, w3
    7c74:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c78:	17fffe5a 	b	75e0 <fwp_write+0x4dc>
    7c7c:	d37ffaa1 	lsl	x1, x21, #1
    7c80:	b7f81363 	tbnz	x3, #63, 7eec <fwp_write+0xde8>
    7c84:	91002263 	add	x3, x19, #0x8
    7c88:	8b010061 	add	x1, x3, x1
    7c8c:	79400021 	ldrh	w1, [x1]
    7c90:	7100041f 	cmp	w0, #0x1
    7c94:	93403c23 	sxth	x3, w1
    7c98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c9c:	17fffe51 	b	75e0 <fwp_write+0x4dc>
    7ca0:	52800443 	mov	w3, #0x22                  	// #34
    7ca4:	91001ff5 	add	x21, sp, #0x7
    7ca8:	91002273 	add	x19, x19, #0x8
    7cac:	aa1503e1 	mov	x1, x21
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	d2800022 	mov	x2, #0x1                   	// #1
    7cb8:	39001fe3 	strb	w3, [sp, #7]
    7cbc:	f90143f7 	str	x23, [sp, #640]
    7cc0:	8b160277 	add	x23, x19, x22
    7cc4:	f90147f8 	str	x24, [sp, #648]
    7cc8:	97ffee52 	bl	3610 <buf_put>
    7ccc:	b4000696 	cbz	x22, 7d9c <fwp_write+0xc98>
    7cd0:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x4f0>
    7cd4:	9100a318 	add	x24, x24, #0x28
    7cd8:	f9014bf9 	str	x25, [sp, #656]
    7cdc:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x4f0>
    7ce0:	91012339 	add	x25, x25, #0x48
    7ce4:	f9014ffa 	str	x26, [sp, #664]
    7ce8:	1400000d 	b	7d1c <fwp_write+0xc18>
    7cec:	710024bf 	cmp	w5, #0x9
    7cf0:	54000460 	b.eq	7d7c <fwp_write+0xc78>  // b.none
    7cf4:	710028bf 	cmp	w5, #0xa
    7cf8:	54000a61 	b.ne	7e44 <fwp_write+0xd40>  // b.any
    7cfc:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7d00:	aa1403e0 	mov	x0, x20
    7d04:	9100e021 	add	x1, x1, #0x38
    7d08:	d2800042 	mov	x2, #0x2                   	// #2
    7d0c:	97ffee41 	bl	3610 <buf_put>
    7d10:	91000673 	add	x19, x19, #0x1
    7d14:	eb17027f 	cmp	x19, x23
    7d18:	540003e0 	b.eq	7d94 <fwp_write+0xc90>  // b.none
    7d1c:	39400265 	ldrb	w5, [x19]
    7d20:	710034bf 	cmp	w5, #0xd
    7d24:	54000180 	b.eq	7d54 <fwp_write+0xc50>  // b.none
    7d28:	54fffe29 	b.ls	7cec <fwp_write+0xbe8>  // b.plast
    7d2c:	710088bf 	cmp	w5, #0x22
    7d30:	540001c0 	b.eq	7d68 <fwp_write+0xc64>  // b.none
    7d34:	710170bf 	cmp	w5, #0x5c
    7d38:	54000741 	b.ne	7e20 <fwp_write+0xd1c>  // b.any
    7d3c:	aa1403e0 	mov	x0, x20
    7d40:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7d44:	d2800042 	mov	x2, #0x2                   	// #2
    7d48:	9100c021 	add	x1, x1, #0x30
    7d4c:	97ffee31 	bl	3610 <buf_put>
    7d50:	17fffff0 	b	7d10 <fwp_write+0xc0c>
    7d54:	aa1903e1 	mov	x1, x25
    7d58:	aa1403e0 	mov	x0, x20
    7d5c:	d2800042 	mov	x2, #0x2                   	// #2
    7d60:	97ffee2c 	bl	3610 <buf_put>
    7d64:	17ffffeb 	b	7d10 <fwp_write+0xc0c>
    7d68:	aa1803e1 	mov	x1, x24
    7d6c:	aa1403e0 	mov	x0, x20
    7d70:	d2800042 	mov	x2, #0x2                   	// #2
    7d74:	97ffee27 	bl	3610 <buf_put>
    7d78:	17ffffe6 	b	7d10 <fwp_write+0xc0c>
    7d7c:	aa1403e0 	mov	x0, x20
    7d80:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7d84:	d2800042 	mov	x2, #0x2                   	// #2
    7d88:	91010021 	add	x1, x1, #0x40
    7d8c:	97ffee21 	bl	3610 <buf_put>
    7d90:	17ffffe0 	b	7d10 <fwp_write+0xc0c>
    7d94:	f9414bf9 	ldr	x25, [sp, #656]
    7d98:	f9414ffa 	ldr	x26, [sp, #664]
    7d9c:	aa1503e1 	mov	x1, x21
    7da0:	aa1403e0 	mov	x0, x20
    7da4:	52800443 	mov	w3, #0x22                  	// #34
    7da8:	17fffd9d 	b	741c <fwp_write+0x318>
    7dac:	7100103f 	cmp	w1, #0x4
    7db0:	54ffeb21 	b.ne	7b14 <fwp_write+0xa10>  // b.any
    7db4:	f94006e0 	ldr	x0, [x23, #8]
    7db8:	d37ffc00 	lsr	x0, x0, #63
    7dbc:	17fffeb3 	b	7888 <fwp_write+0x784>
    7dc0:	710002ff 	cmp	w23, #0x0
    7dc4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7dc8:	17fffeb0 	b	7888 <fwp_write+0x784>
    7dcc:	528005a1 	mov	w1, #0x2d                  	// #45
    7dd0:	eb0203e2 	negs	x2, x2
    7dd4:	da0303e3 	ngc	x3, x3
    7dd8:	910127e0 	add	x0, sp, #0x49
    7ddc:	910123f5 	add	x21, sp, #0x48
    7de0:	390123e1 	strb	w1, [sp, #72]
    7de4:	97ffec2f 	bl	2ea0 <fwp_fmt_u128>
    7de8:	17fffe18 	b	7648 <fwp_write+0x544>
    7dec:	d37ceea1 	lsl	x1, x21, #4
    7df0:	b7f810a3 	tbnz	x3, #63, 8004 <fwp_write+0xf00>
    7df4:	91002260 	add	x0, x19, #0x8
    7df8:	8b010001 	add	x1, x0, x1
    7dfc:	17fffdf9 	b	75e0 <fwp_write+0x4dc>
    7e00:	f9400a61 	ldr	x1, [x19, #16]
    7e04:	8b010000 	add	x0, x0, x1
    7e08:	f9400001 	ldr	x1, [x0]
    7e0c:	17fffdf5 	b	75e0 <fwp_write+0x4dc>
    7e10:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    7e14:	d2800042 	mov	x2, #0x2                   	// #2
    7e18:	913f4021 	add	x1, x1, #0xfd0
    7e1c:	17fffed6 	b	7974 <fwp_write+0x870>
    7e20:	7101fcbf 	cmp	w5, #0x7f
    7e24:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7e28:	540000e9 	b.ls	7e44 <fwp_write+0xd40>  // b.plast
    7e2c:	aa1503e1 	mov	x1, x21
    7e30:	aa1403e0 	mov	x0, x20
    7e34:	d2800022 	mov	x2, #0x1                   	// #1
    7e38:	39001fe5 	strb	w5, [sp, #7]
    7e3c:	97ffedf5 	bl	3610 <buf_put>
    7e40:	17ffffb4 	b	7d10 <fwp_write+0xc0c>
    7e44:	d2800203 	mov	x3, #0x10                  	// #16
    7e48:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x4f0>
    7e4c:	aa0303e1 	mov	x1, x3
    7e50:	91014084 	add	x4, x4, #0x50
    7e54:	910123f6 	add	x22, sp, #0x48
    7e58:	52800042 	mov	w2, #0x2                   	// #2
    7e5c:	aa1603e0 	mov	x0, x22
    7e60:	97ffea88 	bl	2880 <__snprintf_chk@plt>
    7e64:	aa1603e0 	mov	x0, x22
    7e68:	97ffea4e 	bl	27a0 <strlen@plt>
    7e6c:	aa1603e1 	mov	x1, x22
    7e70:	aa0003e2 	mov	x2, x0
    7e74:	aa1403e0 	mov	x0, x20
    7e78:	97ffede6 	bl	3610 <buf_put>
    7e7c:	17ffffa5 	b	7d10 <fwp_write+0xc0c>
    7e80:	1e604100 	fmov	d0, d8
    7e84:	aa1503e0 	mov	x0, x21
    7e88:	52800221 	mov	w1, #0x11                  	// #17
    7e8c:	97ffef62 	bl	3c14 <fwp_format_g.constprop.0>
    7e90:	17fffe43 	b	779c <fwp_write+0x698>
    7e94:	b9401040 	ldr	w0, [x2, #16]
    7e98:	350003c0 	cbnz	w0, 7f10 <fwp_write+0xe0c>
    7e9c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ea0:	f947f400 	ldr	x0, [x0, #4072]
    7ea4:	f94127e2 	ldr	x2, [sp, #584]
    7ea8:	f9400001 	ldr	x1, [x0]
    7eac:	eb010042 	subs	x2, x2, x1
    7eb0:	d2800001 	mov	x1, #0x0                   	// #0
    7eb4:	54ffd721 	b.ne	7998 <fwp_write+0x894>  // b.any
    7eb8:	f9413bf5 	ldr	x21, [sp, #624]
    7ebc:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x4f0>
    7ec0:	f9413ff6 	ldr	x22, [sp, #632]
    7ec4:	aa1403e0 	mov	x0, x20
    7ec8:	f94143f7 	ldr	x23, [sp, #640]
    7ecc:	91028021 	add	x1, x1, #0xa0
    7ed0:	f94147f8 	ldr	x24, [sp, #648]
    7ed4:	d2800042 	mov	x2, #0x2                   	// #2
    7ed8:	17fffd0f 	b	7314 <fwp_write+0x210>
    7edc:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1f10>
    7ee0:	d2800042 	mov	x2, #0x2                   	// #2
    7ee4:	913f6021 	add	x1, x1, #0xfd8
    7ee8:	17fffea3 	b	7974 <fwp_write+0x870>
    7eec:	f9400a63 	ldr	x3, [x19, #16]
    7ef0:	8b030021 	add	x1, x1, x3
    7ef4:	17ffff66 	b	7c8c <fwp_write+0xb88>
    7ef8:	f9400a61 	ldr	x1, [x19, #16]
    7efc:	8b0102a1 	add	x1, x21, x1
    7f00:	17fffdb4 	b	75d0 <fwp_write+0x4cc>
    7f04:	f9400a63 	ldr	x3, [x19, #16]
    7f08:	8b030021 	add	x1, x1, x3
    7f0c:	17ffff56 	b	7c64 <fwp_write+0xb60>
    7f10:	b9404840 	ldr	w0, [x2, #72]
    7f14:	91001ff5 	add	x21, sp, #0x7
    7f18:	34ffa380 	cbz	w0, 7388 <fwp_write+0x284>
    7f1c:	52800503 	mov	w3, #0x28                  	// #40
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	aa1503e1 	mov	x1, x21
    7f28:	d2800022 	mov	x2, #0x1                   	// #1
    7f2c:	39001fe3 	strb	w3, [sp, #7]
    7f30:	97ffedb8 	bl	3610 <buf_put>
    7f34:	b9401380 	ldr	w0, [x28, #16]
    7f38:	52800038 	mov	w24, #0x1                   	// #1
    7f3c:	7100001f 	cmp	w0, #0x0
    7f40:	54ffa38c 	b.gt	73b0 <fwp_write+0x2ac>
    7f44:	17fffd33 	b	7410 <fwp_write+0x30c>
    7f48:	f9014bf9 	str	x25, [sp, #656]
    7f4c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11338>
    7f50:	f9014ffa 	str	x26, [sp, #664]
    7f54:	f9400676 	ldr	x22, [x19, #8]
    7f58:	910aa333 	add	x19, x25, #0x2a8
    7f5c:	91002273 	add	x19, x19, #0x8
    7f60:	937ffed8 	asr	x24, x22, #63
    7f64:	aa1802c0 	orr	x0, x22, x24
    7f68:	b5000320 	cbnz	x0, 7fcc <fwp_write+0xec8>
    7f6c:	110006b5 	add	w21, w21, #0x1
    7f70:	710016bf 	cmp	w21, #0x5
    7f74:	54ffffc1 	b.ne	7f6c <fwp_write+0xe68>  // b.any
    7f78:	b7f80578 	tbnz	x24, #63, 8024 <fwp_write+0xf20>
    7f7c:	910023f3 	add	x19, sp, #0x8
    7f80:	aa1603e2 	mov	x2, x22
    7f84:	aa1303e0 	mov	x0, x19
    7f88:	d2800003 	mov	x3, #0x0                   	// #0
    7f8c:	97ffebc5 	bl	2ea0 <fwp_fmt_u128>
    7f90:	910123f5 	add	x21, sp, #0x48
    7f94:	90000023 	adrp	x3, b000 <_IO_stdin_used+0x4f0>
    7f98:	aa1303e4 	mov	x4, x19
    7f9c:	aa1503e0 	mov	x0, x21
    7fa0:	91026063 	add	x3, x3, #0x98
    7fa4:	d2804002 	mov	x2, #0x200                 	// #512
    7fa8:	52800041 	mov	w1, #0x2                   	// #2
    7fac:	97ffea01 	bl	27b0 <__sprintf_chk@plt>
    7fb0:	aa1503e0 	mov	x0, x21
    7fb4:	97ffe9fb 	bl	27a0 <strlen@plt>
    7fb8:	aa1503e1 	mov	x1, x21
    7fbc:	aa0003e2 	mov	x2, x0
    7fc0:	aa1403e0 	mov	x0, x20
    7fc4:	97ffed93 	bl	3610 <buf_put>
    7fc8:	17fffe47 	b	78e4 <fwp_write+0x7e0>
    7fcc:	f9400277 	ldr	x23, [x19]
    7fd0:	aa1603e0 	mov	x0, x22
    7fd4:	aa1803e1 	mov	x1, x24
    7fd8:	aa1703e2 	mov	x2, x23
    7fdc:	937ffefa 	asr	x26, x23, #63
    7fe0:	aa1a03e3 	mov	x3, x26
    7fe4:	940009e3 	bl	a770 <__modti3>
    7fe8:	aa010000 	orr	x0, x0, x1
    7fec:	b40002c0 	cbz	x0, 8044 <fwp_write+0xf40>
    7ff0:	110006b5 	add	w21, w21, #0x1
    7ff4:	91004273 	add	x19, x19, #0x10
    7ff8:	710016bf 	cmp	w21, #0x5
    7ffc:	54fffe81 	b.ne	7fcc <fwp_write+0xec8>  // b.any
    8000:	17ffffde 	b	7f78 <fwp_write+0xe74>
    8004:	f9400a60 	ldr	x0, [x19, #16]
    8008:	8b000021 	add	x1, x1, x0
    800c:	17fffd75 	b	75e0 <fwp_write+0x4dc>
    8010:	528c29c0 	mov	w0, #0x614e                	// #24910
    8014:	910123f5 	add	x21, sp, #0x48
    8018:	72a009c0 	movk	w0, #0x4e, lsl #16
    801c:	b9004be0 	str	w0, [sp, #72]
    8020:	17fffda2 	b	76a8 <fwp_write+0x5a4>
    8024:	528005a1 	mov	w1, #0x2d                  	// #45
    8028:	eb1603e2 	negs	x2, x22
    802c:	da1803e3 	ngc	x3, x24
    8030:	910027e0 	add	x0, sp, #0x9
    8034:	910023f3 	add	x19, sp, #0x8
    8038:	390023e1 	strb	w1, [sp, #8]
    803c:	97ffeb99 	bl	2ea0 <fwp_fmt_u128>
    8040:	17ffffd4 	b	7f90 <fwp_write+0xe8c>
    8044:	aa1703e2 	mov	x2, x23
    8048:	aa1a03e3 	mov	x3, x26
    804c:	aa1603e0 	mov	x0, x22
    8050:	aa1803e1 	mov	x1, x24
    8054:	940008e7 	bl	a3f0 <__divti3>
    8058:	aa0003e2 	mov	x2, x0
    805c:	aa0103e3 	mov	x3, x1
    8060:	b7f80201 	tbnz	x1, #63, 80a0 <fwp_write+0xf9c>
    8064:	910023f3 	add	x19, sp, #0x8
    8068:	aa1303e0 	mov	x0, x19
    806c:	97ffeb8d 	bl	2ea0 <fwp_fmt_u128>
    8070:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8074:	910aa339 	add	x25, x25, #0x2a8
    8078:	910123f5 	add	x21, sp, #0x48
    807c:	aa1303e4 	mov	x4, x19
    8080:	aa1503e0 	mov	x0, x21
    8084:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x4f0>
    8088:	f8616b25 	ldr	x5, [x25, x1]
    808c:	91024063 	add	x3, x3, #0x90
    8090:	d2804002 	mov	x2, #0x200                 	// #512
    8094:	52800041 	mov	w1, #0x2                   	// #2
    8098:	97ffe9c6 	bl	27b0 <__sprintf_chk@plt>
    809c:	17ffffc5 	b	7fb0 <fwp_write+0xeac>
    80a0:	528005a4 	mov	w4, #0x2d                  	// #45
    80a4:	eb0003e2 	negs	x2, x0
    80a8:	da0103e3 	ngc	x3, x1
    80ac:	910027e0 	add	x0, sp, #0x9
    80b0:	910023f3 	add	x19, sp, #0x8
    80b4:	390023e4 	strb	w4, [sp, #8]
    80b8:	97ffeb7a 	bl	2ea0 <fwp_fmt_u128>
    80bc:	17ffffed 	b	8070 <fwp_write+0xf6c>
    80c0:	f9013bf5 	str	x21, [sp, #624]
    80c4:	f9013ff6 	str	x22, [sp, #632]
    80c8:	f90143f7 	str	x23, [sp, #640]
    80cc:	f90147f8 	str	x24, [sp, #648]
    80d0:	f9014bf9 	str	x25, [sp, #656]
    80d4:	f9014ffa 	str	x26, [sp, #664]
    80d8:	f90153fb 	str	x27, [sp, #672]
    80dc:	f90157fc 	str	x28, [sp, #680]
    80e0:	fd015be8 	str	d8, [sp, #688]
    80e4:	fd015fe9 	str	d9, [sp, #696]
    80e8:	97ffea0a 	bl	2910 <__stack_chk_fail@plt>
    80ec:	d503201f 	nop

00000000000080f0 <fwp_main_thread>:
    80f0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    80f4:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    80f8:	9117c001 	add	x1, x0, #0x5f0
    80fc:	910003fd 	mov	x29, sp
    8100:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8104:	f947f400 	ldr	x0, [x0, #4072]
    8108:	a90153f3 	stp	x19, x20, [sp, #16]
    810c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8110:	d10643ff 	sub	sp, sp, #0x190
    8114:	b953a421 	ldr	w1, [x1, #5028]
    8118:	f9400002 	ldr	x2, [x0]
    811c:	f900c7e2 	str	x2, [sp, #392]
    8120:	d2800002 	mov	x2, #0x0                   	// #0
    8124:	34008b21 	cbz	w1, 9288 <fwp_main_thread+0x1198>
    8128:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    812c:	9117c000 	add	x0, x0, #0x5f0
    8130:	b953a800 	ldr	w0, [x0, #5032]
    8134:	35008a20 	cbnz	w0, 9278 <fwp_main_thread+0x1188>
    8138:	9101c3e5 	add	x5, sp, #0x70
    813c:	900000d3 	adrp	x19, 20000 <__data_start>
    8140:	900000c2 	adrp	x2, 20000 <__data_start>
    8144:	9101c275 	add	x21, x19, #0x70
    8148:	91104042 	add	x2, x2, #0x410
    814c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8150:	d2a00024 	mov	x4, #0x10000               	// #65536
    8154:	910223e0 	add	x0, sp, #0x88
    8158:	d2800001 	mov	x1, #0x0                   	// #0
    815c:	f9000be0 	str	x0, [sp, #16]
    8160:	a9018ea5 	stp	x5, x3, [x21, #24]
    8164:	f90013e5 	str	x5, [sp, #32]
    8168:	f90047e2 	str	x2, [sp, #136]
    816c:	b90093ff 	str	wzr, [sp, #144]
    8170:	f9004fe4 	str	x4, [sp, #152]
    8174:	97ffe97f 	bl	2770 <sigaltstack@plt>
    8178:	35010fa0 	cbnz	w0, a36c <fwp_main_thread+0x227c>
    817c:	4f000400 	movi	v0.4s, #0x0
    8180:	9103e3e0 	add	x0, sp, #0xf8
    8184:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8188:	9103c021 	add	x1, x1, #0xf0
    818c:	f9007be1 	str	x1, [sp, #240]
    8190:	52800082 	mov	w2, #0x4                   	// #4
    8194:	72a10002 	movk	w2, #0x800, lsl #16
    8198:	9103c3f4 	add	x20, sp, #0xf0
    819c:	3d802000 	str	q0, [x0, #128]
    81a0:	b9017be2 	str	w2, [sp, #376]
    81a4:	ad000000 	stp	q0, q0, [x0]
    81a8:	ad010000 	stp	q0, q0, [x0, #32]
    81ac:	ad020000 	stp	q0, q0, [x0, #64]
    81b0:	ad030000 	stp	q0, q0, [x0, #96]
    81b4:	97ffe9c7 	bl	28d0 <sigemptyset@plt>
    81b8:	35010da0 	cbnz	w0, a36c <fwp_main_thread+0x227c>
    81bc:	aa1403e1 	mov	x1, x20
    81c0:	d2800002 	mov	x2, #0x0                   	// #0
    81c4:	52800160 	mov	w0, #0xb                   	// #11
    81c8:	97ffe9da 	bl	2930 <sigaction@plt>
    81cc:	35010d00 	cbnz	w0, a36c <fwp_main_thread+0x227c>
    81d0:	aa1403e1 	mov	x1, x20
    81d4:	d2800002 	mov	x2, #0x0                   	// #0
    81d8:	528000e0 	mov	w0, #0x7                   	// #7
    81dc:	97ffe9d5 	bl	2930 <sigaction@plt>
    81e0:	35010c60 	cbnz	w0, a36c <fwp_main_thread+0x227c>
    81e4:	b94366a0 	ldr	w0, [x21, #868]
    81e8:	340012e0 	cbz	w0, 8444 <fwp_main_thread+0x354>
    81ec:	9101c260 	add	x0, x19, #0x70
    81f0:	a91c63f7 	stp	x23, x24, [sp, #448]
    81f4:	b9436801 	ldr	w1, [x0, #872]
    81f8:	340013a1 	cbz	w1, 846c <fwp_main_thread+0x37c>
    81fc:	9101c276 	add	x22, x19, #0x70
    8200:	f9400ad5 	ldr	x21, [x22, #16]
    8204:	b4000c95 	cbz	x21, 8394 <fwp_main_thread+0x2a4>
    8208:	aa1503f4 	mov	x20, x21
    820c:	910102b8 	add	x24, x21, #0x40
    8210:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8214:	52800037 	mov	w23, #0x1                   	// #1
    8218:	39414ab9 	ldrb	w25, [x21, #82]
    821c:	39014ab7 	strb	w23, [x21, #82]
    8220:	f94016a0 	ldr	x0, [x21, #40]
    8224:	b4000620 	cbz	x0, 82e8 <fwp_main_thread+0x1f8>
    8228:	f94032a1 	ldr	x1, [x21, #96]
    822c:	394146a0 	ldrb	w0, [x21, #81]
    8230:	b4000cc1 	cbz	x1, 83c8 <fwp_main_thread+0x2d8>
    8234:	36000b80 	tbz	w0, #0, 83a4 <fwp_main_thread+0x2b4>
    8238:	39414a82 	ldrb	w2, [x20, #82]
    823c:	f94022a0 	ldr	x0, [x21, #64]
    8240:	37000ee2 	tbnz	w2, #0, 841c <fwp_main_thread+0x32c>
    8244:	f9403281 	ldr	x1, [x20, #96]
    8248:	a911fe98 	stp	x24, xzr, [x20, #280]
    824c:	f9009680 	str	x0, [x20, #296]
    8250:	b4000040 	cbz	x0, 8258 <fwp_main_thread+0x168>
    8254:	f9009014 	str	x20, [x0, #288]
    8258:	f90022b4 	str	x20, [x21, #64]
    825c:	b4000101 	cbz	x1, 827c <fwp_main_thread+0x18c>
    8260:	f9407ec0 	ldr	x0, [x22, #248]
    8264:	39015697 	strb	w23, [x20, #85]
    8268:	f9003681 	str	x1, [x20, #104]
    826c:	a910829f 	stp	xzr, x0, [x20, #264]
    8270:	b4000040 	cbz	x0, 8278 <fwp_main_thread+0x188>
    8274:	f9008414 	str	x20, [x0, #264]
    8278:	f9007ed4 	str	x20, [x22, #248]
    827c:	39015a9f 	strb	wzr, [x20, #86]
    8280:	97fff929 	bl	6724 <fwp_block>
    8284:	f9408e82 	ldr	x2, [x20, #280]
    8288:	b4000142 	cbz	x2, 82b0 <fwp_main_thread+0x1c0>
    828c:	a9520281 	ldp	x1, x0, [x20, #288]
    8290:	b4000d21 	cbz	x1, 8434 <fwp_main_thread+0x344>
    8294:	f9009420 	str	x0, [x1, #296]
    8298:	f9409680 	ldr	x0, [x20, #296]
    829c:	b4000040 	cbz	x0, 82a4 <fwp_main_thread+0x1b4>
    82a0:	f9009001 	str	x1, [x0, #288]
    82a4:	91080280 	add	x0, x20, #0x200
    82a8:	f900969f 	str	xzr, [x20, #296]
    82ac:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    82b0:	39415680 	ldrb	w0, [x20, #85]
    82b4:	f9400ac2 	ldr	x2, [x22, #16]
    82b8:	36000ae0 	tbz	w0, #0, 8414 <fwp_main_thread+0x324>
    82bc:	a9508281 	ldp	x1, x0, [x20, #264]
    82c0:	b4000be1 	cbz	x1, 843c <fwp_main_thread+0x34c>
    82c4:	f9008820 	str	x0, [x1, #272]
    82c8:	b4000040 	cbz	x0, 82d0 <fwp_main_thread+0x1e0>
    82cc:	f9008401 	str	x1, [x0, #264]
    82d0:	91080280 	add	x0, x20, #0x200
    82d4:	3901569f 	strb	wzr, [x20, #85]
    82d8:	aa0203f4 	mov	x20, x2
    82dc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    82e0:	f94016a0 	ldr	x0, [x21, #40]
    82e4:	b5fffa20 	cbnz	x0, 8228 <fwp_main_thread+0x138>
    82e8:	9101c260 	add	x0, x19, #0x70
    82ec:	39014ab9 	strb	w25, [x21, #82]
    82f0:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    82f4:	f941a400 	ldr	x0, [x0, #840]
    82f8:	b5000080 	cbnz	x0, 8308 <fwp_main_thread+0x218>
    82fc:	9101c275 	add	x21, x19, #0x70
    8300:	f941aea0 	ldr	x0, [x21, #856]
    8304:	b400f8a0 	cbz	x0, a218 <fwp_main_thread+0x2128>
    8308:	9101c260 	add	x0, x19, #0x70
    830c:	f941c001 	ldr	x1, [x0, #896]
    8310:	b903781f 	str	wzr, [x0, #888]
    8314:	eb14003f 	cmp	x1, x20
    8318:	5400f961 	b.ne	a244 <fwp_main_thread+0x2154>  // b.any
    831c:	b4006f14 	cbz	x20, 90fc <fwp_main_thread+0x100c>
    8320:	9101c260 	add	x0, x19, #0x70
    8324:	52800021 	mov	w1, #0x1                   	// #1
    8328:	39014a81 	strb	w1, [x20, #82]
    832c:	f9419005 	ldr	x5, [x0, #800]
    8330:	b4006e65 	cbz	x5, 90fc <fwp_main_thread+0x100c>
    8334:	d503201f 	nop
    8338:	394140a0 	ldrb	w0, [x5, #80]
    833c:	37000060 	tbnz	w0, #0, 8348 <fwp_main_thread+0x258>
    8340:	aa0503e0 	mov	x0, x5
    8344:	97ffed0b 	bl	3770 <fwp_cancel_tree.part.0>
    8348:	f9409ca5 	ldr	x5, [x5, #312]
    834c:	b5ffff65 	cbnz	x5, 8338 <fwp_main_thread+0x248>
    8350:	9101c275 	add	x21, x19, #0x70
    8354:	52800036 	mov	w22, #0x1                   	// #1
    8358:	f9402a80 	ldr	x0, [x20, #80]
    835c:	f2001c1f 	tst	x0, #0xff000000ff
    8360:	540000e1 	b.ne	837c <fwp_main_thread+0x28c>  // b.any
    8364:	f9403ea0 	ldr	x0, [x21, #120]
    8368:	39015296 	strb	w22, [x20, #84]
    836c:	f900829f 	str	xzr, [x20, #256]
    8370:	b4006bc0 	cbz	x0, 90e8 <fwp_main_thread+0xff8>
    8374:	f9008014 	str	x20, [x0, #256]
    8378:	f9003eb4 	str	x20, [x21, #120]
    837c:	97fff8ea 	bl	6724 <fwp_block>
    8380:	97fff87c 	bl	6570 <fwp_free_zombie>
    8384:	f94192a0 	ldr	x0, [x21, #800]
    8388:	b4006ba0 	cbz	x0, 90fc <fwp_main_thread+0x100c>
    838c:	f941c2b4 	ldr	x20, [x21, #896]
    8390:	17fffff2 	b	8358 <fwp_main_thread+0x268>
    8394:	f941a6c0 	ldr	x0, [x22, #840]
    8398:	b5006ac0 	cbnz	x0, 90f0 <fwp_main_thread+0x1000>
    839c:	d2800014 	mov	x20, #0x0                   	// #0
    83a0:	17ffffd7 	b	82fc <fwp_main_thread+0x20c>
    83a4:	97ffed97 	bl	3a00 <fwp_now_ns>
    83a8:	f94032a1 	ldr	x1, [x21, #96]
    83ac:	eb01001f 	cmp	x0, x1
    83b0:	540000ab 	b.lt	83c4 <fwp_main_thread+0x2d4>  // b.tstop
    83b4:	394142a0 	ldrb	w0, [x21, #80]
    83b8:	37000060 	tbnz	w0, #0, 83c4 <fwp_main_thread+0x2d4>
    83bc:	aa1503e0 	mov	x0, x21
    83c0:	97ffecec 	bl	3770 <fwp_cancel_tree.part.0>
    83c4:	394146a0 	ldrb	w0, [x21, #81]
    83c8:	39414a82 	ldrb	w2, [x20, #82]
    83cc:	3707f380 	tbnz	w0, #0, 823c <fwp_main_thread+0x14c>
    83d0:	f94032a1 	ldr	x1, [x21, #96]
    83d4:	370001c2 	tbnz	w2, #0, 840c <fwp_main_thread+0x31c>
    83d8:	f9403280 	ldr	x0, [x20, #96]
    83dc:	b4000180 	cbz	x0, 840c <fwp_main_thread+0x31c>
    83e0:	b4000061 	cbz	x1, 83ec <fwp_main_thread+0x2fc>
    83e4:	eb01001f 	cmp	x0, x1
    83e8:	9a81d000 	csel	x0, x0, x1, le
    83ec:	f94022a1 	ldr	x1, [x21, #64]
    83f0:	a911fe98 	stp	x24, xzr, [x20, #280]
    83f4:	f9009681 	str	x1, [x20, #296]
    83f8:	b400f001 	cbz	x1, a1f8 <fwp_main_thread+0x2108>
    83fc:	f9009034 	str	x20, [x1, #288]
    8400:	aa0003e1 	mov	x1, x0
    8404:	f90022b4 	str	x20, [x21, #64]
    8408:	17ffff96 	b	8260 <fwp_main_thread+0x170>
    840c:	f94022a0 	ldr	x0, [x21, #64]
    8410:	17ffff8e 	b	8248 <fwp_main_thread+0x158>
    8414:	aa0203f4 	mov	x20, x2
    8418:	17ffff82 	b	8220 <fwp_main_thread+0x130>
    841c:	a911fe98 	stp	x24, xzr, [x20, #280]
    8420:	f9009680 	str	x0, [x20, #296]
    8424:	b4000040 	cbz	x0, 842c <fwp_main_thread+0x33c>
    8428:	f9009014 	str	x20, [x0, #288]
    842c:	f90022b4 	str	x20, [x21, #64]
    8430:	17ffff93 	b	827c <fwp_main_thread+0x18c>
    8434:	f9000040 	str	x0, [x2]
    8438:	17ffff99 	b	829c <fwp_main_thread+0x1ac>
    843c:	f9007ec0 	str	x0, [x22, #248]
    8440:	17ffffa2 	b	82c8 <fwp_main_thread+0x1d8>
    8444:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    8448:	91078000 	add	x0, x0, #0x1e0
    844c:	940009a5 	bl	aae0 <atexit>
    8450:	a91c63f7 	stp	x23, x24, [sp, #448]
    8454:	3500f9a0 	cbnz	w0, a388 <fwp_main_thread+0x2298>
    8458:	52800020 	mov	w0, #0x1                   	// #1
    845c:	b90366a0 	str	w0, [x21, #868]
    8460:	9101c260 	add	x0, x19, #0x70
    8464:	b9436801 	ldr	w1, [x0, #872]
    8468:	35ffeca1 	cbnz	w1, 81fc <fwp_main_thread+0x10c>
    846c:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    8470:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8474:	f9419803 	ldr	x3, [x0, #816]
    8478:	913f4042 	add	x2, x2, #0xfd0
    847c:	a91e73fb 	stp	x27, x28, [sp, #480]
    8480:	9117c03c 	add	x28, x1, #0x5f0
    8484:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x40>
    8488:	912ac021 	add	x1, x1, #0xab0
    848c:	a9070be3 	stp	x3, x2, [sp, #112]
    8490:	d2804018 	mov	x24, #0x200                 	// #512
    8494:	f9400be2 	ldr	x2, [sp, #16]
    8498:	a90987ff 	stp	xzr, x1, [sp, #152]
    849c:	d2800015 	mov	x21, #0x0                   	// #0
    84a0:	f94013e1 	ldr	x1, [sp, #32]
    84a4:	a91d6bf9 	stp	x25, x26, [sp, #464]
    84a8:	52800036 	mov	w22, #0x1                   	// #1
    84ac:	6d1f27e8 	stp	d8, d9, [sp, #496]
    84b0:	f9000fff 	str	xzr, [sp, #24]
    84b4:	f90043e2 	str	x2, [sp, #128]
    84b8:	f90047ff 	str	xzr, [sp, #136]
    84bc:	f9019801 	str	x1, [x0, #816]
    84c0:	f9400fe2 	ldr	x2, [sp, #24]
    84c4:	f1000719 	subs	x25, x24, #0x1
    84c8:	aa1403e1 	mov	x1, x20
    84cc:	da1f02bb 	sbc	x27, x21, xzr
    84d0:	52800020 	mov	w0, #0x1                   	// #1
    84d4:	f9004bf9 	str	x25, [sp, #144]
    84d8:	a90f0bf9 	stp	x25, x2, [sp, #240]
    84dc:	97fff2fe 	bl	50d4 <fwp_data.part.0.constprop.0>
    84e0:	aa0003e2 	mov	x2, x0
    84e4:	f949db81 	ldr	x1, [x28, #5040]
    84e8:	f9000fe2 	str	x2, [sp, #24]
    84ec:	f949ef80 	ldr	x0, [x28, #5080]
    84f0:	cb010041 	sub	x1, x2, x1
    84f4:	aa1903f8 	mov	x24, x25
    84f8:	aa1b03f5 	mov	x21, x27
    84fc:	eb00403f 	cmp	x1, x0, lsl #16
    8500:	54000302 	b.cs	8560 <fwp_main_thread+0x470>  // b.hs, b.nlast
    8504:	d350fc20 	lsr	x0, x1, #16
    8508:	f949ff83 	ldr	x3, [x28, #5112]
    850c:	8b000800 	add	x0, x0, x0, lsl #2
    8510:	d37df002 	lsl	x2, x0, #3
    8514:	8b020060 	add	x0, x3, x2
    8518:	f9401017 	ldr	x23, [x0, #32]
    851c:	b4000237 	cbz	x23, 8560 <fwp_main_thread+0x470>
    8520:	38626862 	ldrb	w2, [x3, x2]
    8524:	7100085f 	cmp	w2, #0x2
    8528:	54006980 	b.eq	9258 <fwp_main_thread+0x1168>  // b.none
    852c:	7100045f 	cmp	w2, #0x1
    8530:	54000181 	b.ne	8560 <fwp_main_thread+0x470>  // b.any
    8534:	29430002 	ldp	w2, w0, [x0, #24]
    8538:	92403c21 	and	x1, x1, #0xffff
    853c:	9b027c21 	mul	x1, x1, x2
    8540:	d360fc21 	lsr	x1, x1, #32
    8544:	eb00003f 	cmp	x1, x0
    8548:	540000c2 	b.cs	8560 <fwp_main_thread+0x470>  // b.hs, b.nlast
    854c:	8b0102f7 	add	x23, x23, x1
    8550:	394002e0 	ldrb	w0, [x23]
    8554:	7103fc1f 	cmp	w0, #0xff
    8558:	540068a0 	b.eq	926c <fwp_main_thread+0x117c>  // b.none
    855c:	390002f6 	strb	w22, [x23]
    8560:	f9400fe0 	ldr	x0, [sp, #24]
    8564:	f90047e0 	str	x0, [sp, #136]
    8568:	aa1b0320 	orr	x0, x25, x27
    856c:	b5fffaa0 	cbnz	x0, 84c0 <fwp_main_thread+0x3d0>
    8570:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    8574:	9101c262 	add	x2, x19, #0x70
    8578:	f9403bf6 	ldr	x22, [sp, #112]
    857c:	910303e1 	add	x1, sp, #0xc0
    8580:	3dc24400 	ldr	q0, [x0, #2320]
    8584:	52800020 	mov	w0, #0x1                   	// #1
    8588:	f9019856 	str	x22, [x2, #816]
    858c:	3d8033e0 	str	q0, [sp, #192]
    8590:	97fff2d1 	bl	50d4 <fwp_data.part.0.constprop.0>
    8594:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    8598:	9117c022 	add	x2, x1, #0x5f0
    859c:	aa0003f7 	mov	x23, x0
    85a0:	f949d841 	ldr	x1, [x2, #5040]
    85a4:	f949ec40 	ldr	x0, [x2, #5080]
    85a8:	cb0102e1 	sub	x1, x23, x1
    85ac:	eb00403f 	cmp	x1, x0, lsl #16
    85b0:	54000322 	b.cs	8614 <fwp_main_thread+0x524>  // b.hs, b.nlast
    85b4:	d350fc20 	lsr	x0, x1, #16
    85b8:	f949fc43 	ldr	x3, [x2, #5112]
    85bc:	8b000800 	add	x0, x0, x0, lsl #2
    85c0:	d37df002 	lsl	x2, x0, #3
    85c4:	8b020060 	add	x0, x3, x2
    85c8:	f9401015 	ldr	x21, [x0, #32]
    85cc:	b4000255 	cbz	x21, 8614 <fwp_main_thread+0x524>
    85d0:	38626862 	ldrb	w2, [x3, x2]
    85d4:	7100085f 	cmp	w2, #0x2
    85d8:	5400dfe0 	b.eq	a1d4 <fwp_main_thread+0x20e4>  // b.none
    85dc:	7100045f 	cmp	w2, #0x1
    85e0:	540001a1 	b.ne	8614 <fwp_main_thread+0x524>  // b.any
    85e4:	29430002 	ldp	w2, w0, [x0, #24]
    85e8:	92403c21 	and	x1, x1, #0xffff
    85ec:	9b027c21 	mul	x1, x1, x2
    85f0:	d360fc21 	lsr	x1, x1, #32
    85f4:	eb00003f 	cmp	x1, x0
    85f8:	540000e2 	b.cs	8614 <fwp_main_thread+0x524>  // b.hs, b.nlast
    85fc:	8b0102b5 	add	x21, x21, x1
    8600:	394002a0 	ldrb	w0, [x21]
    8604:	7103fc1f 	cmp	w0, #0xff
    8608:	5400e940 	b.eq	a330 <fwp_main_thread+0x2240>  // b.none
    860c:	52800020 	mov	w0, #0x1                   	// #1
    8610:	390002a0 	strb	w0, [x21]
    8614:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8618:	910383e1 	add	x1, sp, #0xe0
    861c:	52800020 	mov	w0, #0x1                   	// #1
    8620:	a90e5fe2 	stp	x2, x23, [sp, #224]
    8624:	97fff2ac 	bl	50d4 <fwp_data.part.0.constprop.0>
    8628:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    862c:	9117c022 	add	x2, x1, #0x5f0
    8630:	aa0003f7 	mov	x23, x0
    8634:	f949d841 	ldr	x1, [x2, #5040]
    8638:	f949ec40 	ldr	x0, [x2, #5080]
    863c:	cb0102e1 	sub	x1, x23, x1
    8640:	eb00403f 	cmp	x1, x0, lsl #16
    8644:	54000322 	b.cs	86a8 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    8648:	d350fc20 	lsr	x0, x1, #16
    864c:	f949fc43 	ldr	x3, [x2, #5112]
    8650:	8b000800 	add	x0, x0, x0, lsl #2
    8654:	d37df002 	lsl	x2, x0, #3
    8658:	8b020060 	add	x0, x3, x2
    865c:	f9401015 	ldr	x21, [x0, #32]
    8660:	b4000255 	cbz	x21, 86a8 <fwp_main_thread+0x5b8>
    8664:	38626862 	ldrb	w2, [x3, x2]
    8668:	7100085f 	cmp	w2, #0x2
    866c:	5400dc00 	b.eq	a1ec <fwp_main_thread+0x20fc>  // b.none
    8670:	7100045f 	cmp	w2, #0x1
    8674:	540001a1 	b.ne	86a8 <fwp_main_thread+0x5b8>  // b.any
    8678:	29430002 	ldp	w2, w0, [x0, #24]
    867c:	92403c21 	and	x1, x1, #0xffff
    8680:	9b027c21 	mul	x1, x1, x2
    8684:	d360fc21 	lsr	x1, x1, #32
    8688:	eb00003f 	cmp	x1, x0
    868c:	540000e2 	b.cs	86a8 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    8690:	8b0102b5 	add	x21, x21, x1
    8694:	394002a0 	ldrb	w0, [x21]
    8698:	7103fc1f 	cmp	w0, #0xff
    869c:	5400e500 	b.eq	a33c <fwp_main_thread+0x224c>  // b.none
    86a0:	52800020 	mov	w0, #0x1                   	// #1
    86a4:	390002a0 	strb	w0, [x21]
    86a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    86ac:	910343e1 	add	x1, sp, #0xd0
    86b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    86b4:	52800020 	mov	w0, #0x1                   	// #1
    86b8:	a90d5fe2 	stp	x2, x23, [sp, #208]
    86bc:	97fff286 	bl	50d4 <fwp_data.part.0.constprop.0>
    86c0:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    86c4:	9117c022 	add	x2, x1, #0x5f0
    86c8:	aa0003f5 	mov	x21, x0
    86cc:	f949d841 	ldr	x1, [x2, #5040]
    86d0:	f949ec40 	ldr	x0, [x2, #5080]
    86d4:	cb0102a1 	sub	x1, x21, x1
    86d8:	eb00403f 	cmp	x1, x0, lsl #16
    86dc:	54000322 	b.cs	8740 <fwp_main_thread+0x650>  // b.hs, b.nlast
    86e0:	d350fc20 	lsr	x0, x1, #16
    86e4:	f949fc43 	ldr	x3, [x2, #5112]
    86e8:	8b000800 	add	x0, x0, x0, lsl #2
    86ec:	d37df002 	lsl	x2, x0, #3
    86f0:	8b020060 	add	x0, x3, x2
    86f4:	f9401017 	ldr	x23, [x0, #32]
    86f8:	b4000257 	cbz	x23, 8740 <fwp_main_thread+0x650>
    86fc:	38626862 	ldrb	w2, [x3, x2]
    8700:	7100085f 	cmp	w2, #0x2
    8704:	5400d6e0 	b.eq	a1e0 <fwp_main_thread+0x20f0>  // b.none
    8708:	7100045f 	cmp	w2, #0x1
    870c:	540001a1 	b.ne	8740 <fwp_main_thread+0x650>  // b.any
    8710:	29430002 	ldp	w2, w0, [x0, #24]
    8714:	92403c21 	and	x1, x1, #0xffff
    8718:	9b027c21 	mul	x1, x1, x2
    871c:	d360fc21 	lsr	x1, x1, #32
    8720:	eb00003f 	cmp	x1, x0
    8724:	540000e2 	b.cs	8740 <fwp_main_thread+0x650>  // b.hs, b.nlast
    8728:	8b0102f7 	add	x23, x23, x1
    872c:	394002e0 	ldrb	w0, [x23]
    8730:	7103fc1f 	cmp	w0, #0xff
    8734:	5400e0a0 	b.eq	a348 <fwp_main_thread+0x2258>  // b.none
    8738:	52800020 	mov	w0, #0x1                   	// #1
    873c:	390002e0 	strb	w0, [x23]
    8740:	f9400fe0 	ldr	x0, [sp, #24]
    8744:	b400c400 	cbz	x0, 9fc4 <fwp_main_thread+0x1ed4>
    8748:	900000c0 	adrp	x0, 20000 <__data_start>
    874c:	91004000 	add	x0, x0, #0x10
    8750:	9100e000 	add	x0, x0, #0x38
    8754:	f9001fe0 	str	x0, [sp, #56]
    8758:	f9400fe0 	ldr	x0, [sp, #24]
    875c:	f90027e0 	str	x0, [sp, #72]
    8760:	910143e0 	add	x0, sp, #0x50
    8764:	f90017e0 	str	x0, [sp, #40]
    8768:	910163e0 	add	x0, sp, #0x58
    876c:	f9001be0 	str	x0, [sp, #48]
    8770:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    8774:	9117c01a 	add	x26, x0, #0x5f0
    8778:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    877c:	fd449008 	ldr	d8, [x0, #2336]
    8780:	f949ef46 	ldr	x6, [x26, #5080]
    8784:	f949db43 	ldr	x3, [x26, #5040]
    8788:	d370bcc6 	lsl	x6, x6, #16
    878c:	cb0302a2 	sub	x2, x21, x3
    8790:	eb06005f 	cmp	x2, x6
    8794:	540003a2 	b.cs	8808 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8798:	d350fc40 	lsr	x0, x2, #16
    879c:	f949ff47 	ldr	x7, [x26, #5112]
    87a0:	8b000800 	add	x0, x0, x0, lsl #2
    87a4:	d37df001 	lsl	x1, x0, #3
    87a8:	8b0100e5 	add	x5, x7, x1
    87ac:	f94010a0 	ldr	x0, [x5, #32]
    87b0:	b40002c0 	cbz	x0, 8808 <fwp_main_thread+0x718>
    87b4:	386168e1 	ldrb	w1, [x7, x1]
    87b8:	7100083f 	cmp	w1, #0x2
    87bc:	5400c2e0 	b.eq	a018 <fwp_main_thread+0x1f28>  // b.none
    87c0:	7100043f 	cmp	w1, #0x1
    87c4:	54000221 	b.ne	8808 <fwp_main_thread+0x718>  // b.any
    87c8:	92403c41 	and	x1, x2, #0xffff
    87cc:	294308a7 	ldp	w7, w2, [x5, #24]
    87d0:	9b077c21 	mul	x1, x1, x7
    87d4:	d360fc21 	lsr	x1, x1, #32
    87d8:	eb02003f 	cmp	x1, x2
    87dc:	54000162 	b.cs	8808 <fwp_main_thread+0x718>  // b.hs, b.nlast
    87e0:	8b010000 	add	x0, x0, x1
    87e4:	39400001 	ldrb	w1, [x0]
    87e8:	34000101 	cbz	w1, 8808 <fwp_main_thread+0x718>
    87ec:	7103f43f 	cmp	w1, #0xfd
    87f0:	5400d528 	b.hi	a294 <fwp_main_thread+0x21a4>  // b.pmore
    87f4:	11000421 	add	w1, w1, #0x1
    87f8:	39000001 	strb	w1, [x0]
    87fc:	f949ef46 	ldr	x6, [x26, #5080]
    8800:	f949db43 	ldr	x3, [x26, #5040]
    8804:	d370bcc6 	lsl	x6, x6, #16
    8808:	f9401fe1 	ldr	x1, [sp, #56]
    880c:	9101c260 	add	x0, x19, #0x70
    8810:	12800002 	mov	w2, #0xffffffff            	// #-1
    8814:	b90053e2 	str	w2, [sp, #80]
    8818:	cb030023 	sub	x3, x1, x3
    881c:	d0ffffe1 	adrp	x1, 6000 <fwp_tape_finish+0x30>
    8820:	91034021 	add	x1, x1, #0xd0
    8824:	a90587f6 	stp	x22, x1, [sp, #88]
    8828:	f94017e1 	ldr	x1, [sp, #40]
    882c:	f90037e1 	str	x1, [sp, #104]
    8830:	f9401be1 	ldr	x1, [sp, #48]
    8834:	f9019801 	str	x1, [x0, #816]
    8838:	eb0300df 	cmp	x6, x3
    883c:	54000769 	b.ls	8928 <fwp_main_thread+0x838>  // b.plast
    8840:	d350fc60 	lsr	x0, x3, #16
    8844:	f949ff45 	ldr	x5, [x26, #5112]
    8848:	8b000800 	add	x0, x0, x0, lsl #2
    884c:	d37df002 	lsl	x2, x0, #3
    8850:	8b0200a1 	add	x1, x5, x2
    8854:	f9401036 	ldr	x22, [x1, #32]
    8858:	b4000696 	cbz	x22, 8928 <fwp_main_thread+0x838>
    885c:	386268a0 	ldrb	w0, [x5, x2]
    8860:	7100081f 	cmp	w0, #0x2
    8864:	5400ae20 	b.eq	9e28 <fwp_main_thread+0x1d38>  // b.none
    8868:	7100041f 	cmp	w0, #0x1
    886c:	540005e1 	b.ne	8928 <fwp_main_thread+0x838>  // b.any
    8870:	29430825 	ldp	w5, w2, [x1, #24]
    8874:	92403c60 	and	x0, x3, #0xffff
    8878:	9b057c00 	mul	x0, x0, x5
    887c:	d360fc00 	lsr	x0, x0, #32
    8880:	eb02001f 	cmp	x0, x2
    8884:	54000282 	b.cs	88d4 <fwp_main_thread+0x7e4>  // b.hs, b.nlast
    8888:	8b0002c0 	add	x0, x22, x0
    888c:	39400002 	ldrb	w2, [x0]
    8890:	34000222 	cbz	w2, 88d4 <fwp_main_thread+0x7e4>
    8894:	7103f45f 	cmp	w2, #0xfd
    8898:	5400c6c8 	b.hi	a170 <fwp_main_thread+0x2080>  // b.pmore
    889c:	11000442 	add	w2, w2, #0x1
    88a0:	39000002 	strb	w2, [x0]
    88a4:	f9401fe1 	ldr	x1, [sp, #56]
    88a8:	f949db43 	ldr	x3, [x26, #5040]
    88ac:	f949ef40 	ldr	x0, [x26, #5080]
    88b0:	cb030023 	sub	x3, x1, x3
    88b4:	eb00407f 	cmp	x3, x0, lsl #16
    88b8:	54000382 	b.cs	8928 <fwp_main_thread+0x838>  // b.hs, b.nlast
    88bc:	f949ff40 	ldr	x0, [x26, #5112]
    88c0:	d350fc61 	lsr	x1, x3, #16
    88c4:	8b010821 	add	x1, x1, x1, lsl #2
    88c8:	8b010c01 	add	x1, x0, x1, lsl #3
    88cc:	f9401036 	ldr	x22, [x1, #32]
    88d0:	b40002d6 	cbz	x22, 8928 <fwp_main_thread+0x838>
    88d4:	39400020 	ldrb	w0, [x1]
    88d8:	7100081f 	cmp	w0, #0x2
    88dc:	5400aae0 	b.eq	9e38 <fwp_main_thread+0x1d48>  // b.none
    88e0:	7100041f 	cmp	w0, #0x1
    88e4:	54000221 	b.ne	8928 <fwp_main_thread+0x838>  // b.any
    88e8:	29430022 	ldp	w2, w0, [x1, #24]
    88ec:	92403c63 	and	x3, x3, #0xffff
    88f0:	9b027c61 	mul	x1, x3, x2
    88f4:	d360fc21 	lsr	x1, x1, #32
    88f8:	eb00003f 	cmp	x1, x0
    88fc:	54000162 	b.cs	8928 <fwp_main_thread+0x838>  // b.hs, b.nlast
    8900:	8b0102d6 	add	x22, x22, x1
    8904:	394002c1 	ldrb	w1, [x22]
    8908:	34000101 	cbz	w1, 8928 <fwp_main_thread+0x838>
    890c:	7100043f 	cmp	w1, #0x1
    8910:	54008ea0 	b.eq	9ae4 <fwp_main_thread+0x19f4>  // b.none
    8914:	7103fc3f 	cmp	w1, #0xff
    8918:	5400c300 	b.eq	a178 <fwp_main_thread+0x2088>  // b.none
    891c:	51000421 	sub	w1, w1, #0x1
    8920:	390002c1 	strb	w1, [x22]
    8924:	d503201f 	nop
    8928:	b4008ef5 	cbz	x21, 9b04 <fwp_main_thread+0x1a14>
    892c:	aa1503e0 	mov	x0, x21
    8930:	d2800016 	mov	x22, #0x0                   	// #0
    8934:	d503201f 	nop
    8938:	f9400800 	ldr	x0, [x0, #16]
    893c:	910006d6 	add	x22, x22, #0x1
    8940:	b5ffffc0 	cbnz	x0, 8938 <fwp_main_thread+0x848>
    8944:	52800000 	mov	w0, #0x0                   	// #0
    8948:	97ffeb4a 	bl	3670 <descent_phase_step>
    894c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8950:	eb0002df 	cmp	x22, x0
    8954:	5400d3a8 	b.hi	a3c8 <fwp_main_thread+0x22d8>  // b.pmore
    8958:	9101c277 	add	x23, x19, #0x70
    895c:	b9436ee0 	ldr	w0, [x23, #876]
    8960:	34008e00 	cbz	w0, 9b20 <fwp_main_thread+0x1a30>
    8964:	9101c260 	add	x0, x19, #0x70
    8968:	f9404817 	ldr	x23, [x0, #144]
    896c:	f9408401 	ldr	x1, [x0, #264]
    8970:	eb17003f 	cmp	x1, x23
    8974:	54008eea 	b.ge	9b50 <fwp_main_thread+0x1a60>  // b.tcont
    8978:	f9403a62 	ldr	x2, [x19, #112]
    897c:	8b010420 	add	x0, x1, x1, lsl #1
    8980:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8984:	8b000820 	add	x0, x1, x0, lsl #2
    8988:	8b000c40 	add	x0, x2, x0, lsl #3
    898c:	d503201f 	nop
    8990:	b9400402 	ldr	w2, [x0, #4]
    8994:	35000082 	cbnz	w2, 89a4 <fwp_main_thread+0x8b4>
    8998:	b9400002 	ldr	w2, [x0]
    899c:	6b03005f 	cmp	w2, w3
    89a0:	54008d89 	b.ls	9b50 <fwp_main_thread+0x1a60>  // b.plast
    89a4:	91000421 	add	x1, x1, #0x1
    89a8:	9101a000 	add	x0, x0, #0x68
    89ac:	eb17003f 	cmp	x1, x23
    89b0:	54ffff01 	b.ne	8990 <fwp_main_thread+0x8a0>  // b.any
    89b4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    89b8:	eb0002ff 	cmp	x23, x0
    89bc:	5400d0cc 	b.gt	a3d4 <fwp_main_thread+0x22e4>
    89c0:	9101c260 	add	x0, x19, #0x70
    89c4:	f9403a7b 	ldr	x27, [x19, #112]
    89c8:	f9408000 	ldr	x0, [x0, #256]
    89cc:	eb17001f 	cmp	x0, x23
    89d0:	54000201 	b.ne	8a10 <fwp_main_thread+0x920>  // b.any
    89d4:	b400ad57 	cbz	x23, 9f7c <fwp_main_thread+0x1e8c>
    89d8:	d37ffaf8 	lsl	x24, x23, #1
    89dc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    89e0:	eb00031f 	cmp	x24, x0
    89e4:	9a80d318 	csel	x24, x24, x0, le
    89e8:	8b180701 	add	x1, x24, x24, lsl #1
    89ec:	8b010b01 	add	x1, x24, x1, lsl #2
    89f0:	d37df021 	lsl	x1, x1, #3
    89f4:	aa1b03e0 	mov	x0, x27
    89f8:	97ffe7c2 	bl	2900 <realloc@plt>
    89fc:	aa0003fb 	mov	x27, x0
    8a00:	b4004660 	cbz	x0, 92cc <fwp_main_thread+0x11dc>
    8a04:	9101c260 	add	x0, x19, #0x70
    8a08:	f9003a7b 	str	x27, [x19, #112]
    8a0c:	f9008018 	str	x24, [x0, #256]
    8a10:	d37ffae1 	lsl	x1, x23, #1
    8a14:	9101c260 	add	x0, x19, #0x70
    8a18:	8b170022 	add	x2, x1, x23
    8a1c:	8b170021 	add	x1, x1, x23
    8a20:	4f000400 	movi	v0.4s, #0x0
    8a24:	910006fc 	add	x28, x23, #0x1
    8a28:	8b020ae2 	add	x2, x23, x2, lsl #2
    8a2c:	8b010ae1 	add	x1, x23, x1, lsl #2
    8a30:	f900481c 	str	x28, [x0, #144]
    8a34:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    8a38:	8b020f62 	add	x2, x27, x2, lsl #3
    8a3c:	8b010f78 	add	x24, x27, x1, lsl #3
    8a40:	91380000 	add	x0, x0, #0xe00
    8a44:	ad000040 	stp	q0, q0, [x2]
    8a48:	ad010040 	stp	q0, q0, [x2, #32]
    8a4c:	ad020040 	stp	q0, q0, [x2, #64]
    8a50:	f900305f 	str	xzr, [x2, #96]
    8a54:	f900331f 	str	xzr, [x24, #96]
    8a58:	97ffe812 	bl	2aa0 <getenv@plt>
    8a5c:	b4008960 	cbz	x0, 9b88 <fwp_main_thread+0x1a98>
    8a60:	39400001 	ldrb	w1, [x0]
    8a64:	7100c03f 	cmp	w1, #0x30
    8a68:	54008901 	b.ne	9b88 <fwp_main_thread+0x1a98>  // b.any
    8a6c:	39400400 	ldrb	w0, [x0, #1]
    8a70:	350088c0 	cbnz	w0, 9b88 <fwp_main_thread+0x1a98>
    8a74:	9101c260 	add	x0, x19, #0x70
    8a78:	b9400305 	ldr	w5, [x24]
    8a7c:	52800021 	mov	w1, #0x1                   	// #1
    8a80:	2f000400 	mvni	v0.2s, #0x0
    8a84:	110004a5 	add	w5, w5, #0x1
    8a88:	29000705 	stp	w5, w1, [x24]
    8a8c:	f9419801 	ldr	x1, [x0, #816]
    8a90:	a900db16 	stp	x22, x22, [x24, #8]
    8a94:	f9002b1f 	str	xzr, [x24, #80]
    8a98:	f900841c 	str	x28, [x0, #264]
    8a9c:	fd002f00 	str	d0, [x24, #88]
    8aa0:	b400c5a1 	cbz	x1, a354 <fwp_main_thread+0x2264>
    8aa4:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0x30>
    8aa8:	91034003 	add	x3, x0, #0xd0
    8aac:	14000003 	b	8ab8 <fwp_main_thread+0x9c8>
    8ab0:	f9400021 	ldr	x1, [x1]
    8ab4:	b400c501 	cbz	x1, a354 <fwp_main_thread+0x2264>
    8ab8:	f9400422 	ldr	x2, [x1, #8]
    8abc:	eb03005f 	cmp	x2, x3
    8ac0:	54ffff81 	b.ne	8ab0 <fwp_main_thread+0x9c0>  // b.any
    8ac4:	f9400820 	ldr	x0, [x1, #16]
    8ac8:	2a1703e2 	mov	w2, w23
    8acc:	b9400001 	ldr	w1, [x0]
    8ad0:	f9002b00 	str	x0, [x24, #80]
    8ad4:	b9005f01 	str	w1, [x24, #92]
    8ad8:	37f80081 	tbnz	w1, #31, 8ae8 <fwp_main_thread+0x9f8>
    8adc:	52800d03 	mov	w3, #0x68                  	// #104
    8ae0:	9b236c21 	smaddl	x1, w1, w3, x27
    8ae4:	b9005837 	str	w23, [x1, #88]
    8ae8:	b9000002 	str	w2, [x0]
    8aec:	d3707cb6 	ubfiz	x22, x5, #16, #32
    8af0:	52800020 	mov	w0, #0x1                   	// #1
    8af4:	aa1c02d6 	orr	x22, x22, x28
    8af8:	97ffeade 	bl	3670 <descent_phase_step>
    8afc:	aa1503e0 	mov	x0, x21
    8b00:	d2800002 	mov	x2, #0x0                   	// #0
    8b04:	b4008d15 	cbz	x21, 9ca4 <fwp_main_thread+0x1bb4>
    8b08:	f9400800 	ldr	x0, [x0, #16]
    8b0c:	91000442 	add	x2, x2, #0x1
    8b10:	b5ffffc0 	cbnz	x0, 8b08 <fwp_main_thread+0xa18>
    8b14:	aa1503e1 	mov	x1, x21
    8b18:	f9400821 	ldr	x1, [x1, #16]
    8b1c:	91000400 	add	x0, x0, #0x1
    8b20:	b5ffffc1 	cbnz	x1, 8b18 <fwp_main_thread+0xa28>
    8b24:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8b28:	eb01001f 	cmp	x0, x1
    8b2c:	5400bf68 	b.hi	a318 <fwp_main_thread+0x2228>  // b.pmore
    8b30:	f100005f 	cmp	x2, #0x0
    8b34:	54008b8d 	b.le	9ca4 <fwp_main_thread+0x1bb4>
    8b38:	eb00005f 	cmp	x2, x0
    8b3c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8b40:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8b44:	eb0102ff 	cmp	x23, x1
    8b48:	5400be88 	b.hi	a318 <fwp_main_thread+0x2228>  // b.pmore
    8b4c:	d37ffafc 	lsl	x28, x23, #1
    8b50:	52800041 	mov	w1, #0x2                   	// #2
    8b54:	91000780 	add	x0, x28, #0x1
    8b58:	d37df000 	lsl	x0, x0, #3
    8b5c:	97fff119 	bl	4fc0 <fwp_heap_alloc>
    8b60:	f900001c 	str	x28, [x0]
    8b64:	aa0003f8 	mov	x24, x0
    8b68:	aa0003fb 	mov	x27, x0
    8b6c:	f949db41 	ldr	x1, [x26, #5040]
    8b70:	f949ef40 	ldr	x0, [x26, #5080]
    8b74:	cb010301 	sub	x1, x24, x1
    8b78:	eb00403f 	cmp	x1, x0, lsl #16
    8b7c:	54008b62 	b.cs	9ce8 <fwp_main_thread+0x1bf8>  // b.hs, b.nlast
    8b80:	d350fc20 	lsr	x0, x1, #16
    8b84:	f949ff43 	ldr	x3, [x26, #5112]
    8b88:	8b000800 	add	x0, x0, x0, lsl #2
    8b8c:	d37df002 	lsl	x2, x0, #3
    8b90:	8b020060 	add	x0, x3, x2
    8b94:	f940101c 	ldr	x28, [x0, #32]
    8b98:	b400025c 	cbz	x28, 8be0 <fwp_main_thread+0xaf0>
    8b9c:	38626862 	ldrb	w2, [x3, x2]
    8ba0:	7100085f 	cmp	w2, #0x2
    8ba4:	54009500 	b.eq	9e44 <fwp_main_thread+0x1d54>  // b.none
    8ba8:	7100045f 	cmp	w2, #0x1
    8bac:	540001a1 	b.ne	8be0 <fwp_main_thread+0xaf0>  // b.any
    8bb0:	29430002 	ldp	w2, w0, [x0, #24]
    8bb4:	92403c21 	and	x1, x1, #0xffff
    8bb8:	9b027c21 	mul	x1, x1, x2
    8bbc:	d360fc21 	lsr	x1, x1, #32
    8bc0:	eb00003f 	cmp	x1, x0
    8bc4:	540000e2 	b.cs	8be0 <fwp_main_thread+0xaf0>  // b.hs, b.nlast
    8bc8:	8b01039c 	add	x28, x28, x1
    8bcc:	39400380 	ldrb	w0, [x28]
    8bd0:	7103fc1f 	cmp	w0, #0xff
    8bd4:	54009420 	b.eq	9e58 <fwp_main_thread+0x1d68>  // b.none
    8bd8:	52800020 	mov	w0, #0x1                   	// #1
    8bdc:	39000380 	strb	w0, [x28]
    8be0:	b4000237 	cbz	x23, 8c24 <fwp_main_thread+0xb34>
    8be4:	d3607ec5 	lsl	x5, x22, #32
    8be8:	aa1503e1 	mov	x1, x21
    8bec:	f94006a6 	ldr	x6, [x21, #8]
    8bf0:	aa0503e3 	mov	x3, x5
    8bf4:	91002302 	add	x2, x24, #0x8
    8bf8:	d2800000 	mov	x0, #0x0                   	// #0
    8bfc:	14000005 	b	8c10 <fwp_main_thread+0xb20>
    8c00:	f9400426 	ldr	x6, [x1, #8]
    8c04:	ab050003 	adds	x3, x0, x5
    8c08:	91004042 	add	x2, x2, #0x10
    8c0c:	5400bea6 	b.vs	a3e0 <fwp_main_thread+0x22f0>
    8c10:	a9000c46 	stp	x6, x3, [x2]
    8c14:	91000400 	add	x0, x0, #0x1
    8c18:	f9400821 	ldr	x1, [x1, #16]
    8c1c:	eb17001f 	cmp	x0, x23
    8c20:	54ffff03 	b.cc	8c00 <fwp_main_thread+0xb10>  // b.lo, b.ul, b.last
    8c24:	f9400300 	ldr	x0, [x24]
    8c28:	f100041f 	cmp	x0, #0x1
    8c2c:	54008629 	b.ls	9cf0 <fwp_main_thread+0x1c00>  // b.plast
    8c30:	d341fc00 	lsr	x0, x0, #1
    8c34:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8c38:	d1000401 	sub	x1, x0, #0x1
    8c3c:	eb02003f 	cmp	x1, x2
    8c40:	5400b6c8 	b.hi	a318 <fwp_main_thread+0x2228>  // b.pmore
    8c44:	d37ff83c 	lsl	x28, x1, #1
    8c48:	b4008541 	cbz	x1, 9cf0 <fwp_main_thread+0x1c00>
    8c4c:	d1002301 	sub	x1, x24, #0x8
    8c50:	91002319 	add	x25, x24, #0x8
    8c54:	8b001037 	add	x23, x1, x0, lsl #4
    8c58:	f9400720 	ldr	x0, [x25, #8]
    8c5c:	f9400f21 	ldr	x1, [x25, #24]
    8c60:	fd400320 	ldr	d0, [x25]
    8c64:	fd400b21 	ldr	d1, [x25, #16]
    8c68:	97fff216 	bl	54c0 <w120>
    8c6c:	a9000720 	stp	x0, x1, [x25]
    8c70:	91004339 	add	x25, x25, #0x10
    8c74:	eb17033f 	cmp	x25, x23
    8c78:	54ffff01 	b.ne	8c58 <fwp_main_thread+0xb68>  // b.any
    8c7c:	f900031c 	str	x28, [x24]
    8c80:	aa1803e0 	mov	x0, x24
    8c84:	97fff263 	bl	5610 <w176.constprop.0>
    8c88:	aa0103fc 	mov	x28, x1
    8c8c:	f949db40 	ldr	x0, [x26, #5040]
    8c90:	f949ef42 	ldr	x2, [x26, #5080]
    8c94:	cb000301 	sub	x1, x24, x0
    8c98:	eb02403f 	cmp	x1, x2, lsl #16
    8c9c:	540003a2 	b.cs	8d10 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8ca0:	d350fc20 	lsr	x0, x1, #16
    8ca4:	f949ff45 	ldr	x5, [x26, #5112]
    8ca8:	8b000800 	add	x0, x0, x0, lsl #2
    8cac:	d37df000 	lsl	x0, x0, #3
    8cb0:	8b0000a2 	add	x2, x5, x0
    8cb4:	f9401057 	ldr	x23, [x2, #32]
    8cb8:	b40002d7 	cbz	x23, 8d10 <fwp_main_thread+0xc20>
    8cbc:	386068a0 	ldrb	w0, [x5, x0]
    8cc0:	7100081f 	cmp	w0, #0x2
    8cc4:	540081a0 	b.eq	9cf8 <fwp_main_thread+0x1c08>  // b.none
    8cc8:	7100041f 	cmp	w0, #0x1
    8ccc:	54000221 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    8cd0:	29430043 	ldp	w3, w0, [x2, #24]
    8cd4:	92403c21 	and	x1, x1, #0xffff
    8cd8:	9b037c21 	mul	x1, x1, x3
    8cdc:	d360fc21 	lsr	x1, x1, #32
    8ce0:	eb00003f 	cmp	x1, x0
    8ce4:	54000162 	b.cs	8d10 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8ce8:	8b0102f7 	add	x23, x23, x1
    8cec:	394002e0 	ldrb	w0, [x23]
    8cf0:	34000100 	cbz	w0, 8d10 <fwp_main_thread+0xc20>
    8cf4:	7100041f 	cmp	w0, #0x1
    8cf8:	54003020 	b.eq	92fc <fwp_main_thread+0x120c>  // b.none
    8cfc:	7103fc1f 	cmp	w0, #0xff
    8d00:	54009c80 	b.eq	a090 <fwp_main_thread+0x1fa0>  // b.none
    8d04:	51000400 	sub	w0, w0, #0x1
    8d08:	390002e0 	strb	w0, [x23]
    8d0c:	d503201f 	nop
    8d10:	97ffed8d 	bl	4344 <caf75>
    8d14:	9e670009 	fmov	d9, x0
    8d18:	93407ed6 	sxtw	x22, w22
    8d1c:	52800040 	mov	w0, #0x2                   	// #2
    8d20:	97ffea54 	bl	3670 <descent_phase_step>
    8d24:	aa1603e0 	mov	x0, x22
    8d28:	97ffeba2 	bl	3bb0 <fwp_tape_of>
    8d2c:	f9403001 	ldr	x1, [x0, #96]
    8d30:	aa0003e6 	mov	x6, x0
    8d34:	b500b441 	cbnz	x1, a3bc <fwp_main_thread+0x22cc>
    8d38:	97ffe8b6 	bl	3010 <fwp_tape_unlink_scope>
    8d3c:	b90004df 	str	wzr, [x6, #4]
    8d40:	a94288d8 	ldp	x24, x2, [x6, #40]
    8d44:	f90003e2 	str	x2, [sp]
    8d48:	f9401cc2 	ldr	x2, [x6, #56]
    8d4c:	f90007e2 	str	x2, [sp, #8]
    8d50:	b94000c1 	ldr	w1, [x6]
    8d54:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8d58:	a940a0d9 	ldp	x25, x8, [x6, #8]
    8d5c:	a941dcc9 	ldp	x9, x23, [x6, #24]
    8d60:	f94020db 	ldr	x27, [x6, #64]
    8d64:	f94024c2 	ldr	x2, [x6, #72]
    8d68:	6b00003f 	cmp	w1, w0
    8d6c:	54000108 	b.hi	8d8c <fwp_main_thread+0xc9c>  // b.pmore
    8d70:	9101c261 	add	x1, x19, #0x70
    8d74:	92403ec0 	and	x0, x22, #0xffff
    8d78:	d1000400 	sub	x0, x0, #0x1
    8d7c:	f940842a 	ldr	x10, [x1, #264]
    8d80:	eb0a001f 	cmp	x0, x10
    8d84:	5400004a 	b.ge	8d8c <fwp_main_thread+0xc9c>  // b.tcont
    8d88:	f9008420 	str	x0, [x1, #264]
    8d8c:	4f000400 	movi	v0.4s, #0x0
    8d90:	9101c261 	add	x1, x19, #0x70
    8d94:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8d98:	91114000 	add	x0, x0, #0x450
    8d9c:	f9000cdf 	str	xzr, [x6, #24]
    8da0:	f941982a 	ldr	x10, [x1, #816]
    8da4:	3c8080c0 	stur	q0, [x6, #8]
    8da8:	ad0100c0 	stp	q0, q0, [x6, #32]
    8dac:	a9047cdf 	stp	xzr, xzr, [x6, #64]
    8db0:	a90703ea 	stp	x10, x0, [sp, #112]
    8db4:	f9400be0 	ldr	x0, [sp, #16]
    8db8:	f90043e0 	str	x0, [sp, #128]
    8dbc:	f94003e0 	ldr	x0, [sp]
    8dc0:	f9004fe0 	str	x0, [sp, #152]
    8dc4:	f94007e0 	ldr	x0, [sp, #8]
    8dc8:	f90053e0 	str	x0, [sp, #160]
    8dcc:	f94013e0 	ldr	x0, [sp, #32]
    8dd0:	a908e3f7 	stp	x23, x24, [sp, #136]
    8dd4:	a90aa7fb 	stp	x27, x9, [sp, #168]
    8dd8:	f9005fe2 	str	x2, [sp, #184]
    8ddc:	f9019820 	str	x0, [x1, #816]
    8de0:	b7f8843c 	tbnz	x28, #63, 9e64 <fwp_main_thread+0x1d74>
    8de4:	eb9c82df 	cmp	x22, x28, asr #32
    8de8:	5400a501 	b.ne	a288 <fwp_main_thread+0x2198>  // b.any
    8dec:	92407f81 	and	x1, x28, #0xffffffff
    8df0:	eb3c411f 	cmp	x8, w28, uxtw
    8df4:	5400a44d 	b.le	a27c <fwp_main_thread+0x218c>
    8df8:	eb19003f 	cmp	x1, x25
    8dfc:	9a81b736 	csinc	x22, x25, x1, lt	// lt = tstop
    8e00:	eb16005f 	cmp	x2, x22
    8e04:	5400250a 	b.ge	92a4 <fwp_main_thread+0x11b4>  // b.tcont
    8e08:	f100005f 	cmp	x2, #0x0
    8e0c:	9a961042 	csel	x2, x2, x22, ne	// ne = any
    8e10:	14000005 	b	8e24 <fwp_main_thread+0xd34>
    8e14:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8e18:	eb00005f 	cmp	x2, x0
    8e1c:	d37ff842 	lsl	x2, x2, #1
    8e20:	9a96d042 	csel	x2, x2, x22, le
    8e24:	eb16005f 	cmp	x2, x22
    8e28:	54ffff6b 	b.lt	8e14 <fwp_main_thread+0xd24>  // b.tstop
    8e2c:	b40089bb 	cbz	x27, 9f60 <fwp_main_thread+0x1e70>
    8e30:	aa1b03e0 	mov	x0, x27
    8e34:	d37df041 	lsl	x1, x2, #3
    8e38:	f90023e2 	str	x2, [sp, #64]
    8e3c:	97ffe6b1 	bl	2900 <realloc@plt>
    8e40:	f94023e2 	ldr	x2, [sp, #64]
    8e44:	aa0003fb 	mov	x27, x0
    8e48:	b400ab1b 	cbz	x27, a3a8 <fwp_main_thread+0x22b8>
    8e4c:	f90057fb 	str	x27, [sp, #168]
    8e50:	f9005fe2 	str	x2, [sp, #184]
    8e54:	b50021f6 	cbnz	x22, 9290 <fwp_main_thread+0x11a0>
    8e58:	b7f800bc 	tbnz	x28, #63, 8e6c <fwp_main_thread+0xd7c>
    8e5c:	92407f81 	and	x1, x28, #0xffffffff
    8e60:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8e64:	1e692800 	fadd	d0, d0, d9
    8e68:	fc217b60 	str	d0, [x27, x1, lsl #3]
    8e6c:	9101c261 	add	x1, x19, #0x70
    8e70:	cb1902c6 	sub	x6, x22, x25
    8e74:	52800060 	mov	w0, #0x3                   	// #3
    8e78:	a9428827 	ldp	x7, x2, [x1, #40]
    8e7c:	8b0700c6 	add	x6, x6, x7
    8e80:	8b190042 	add	x2, x2, x25
    8e84:	a9028826 	stp	x6, x2, [x1, #40]
    8e88:	97ffe9fa 	bl	3670 <descent_phase_step>
    8e8c:	d10006c1 	sub	x1, x22, #0x1
    8e90:	d1000727 	sub	x7, x25, #0x1
    8e94:	eb01033f 	cmp	x25, x1
    8e98:	540003ec 	b.gt	8f14 <fwp_main_thread+0xe24>
    8e9c:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8ea0:	1e602008 	fcmp	d0, #0.0
    8ea4:	54000320 	b.eq	8f08 <fwp_main_thread+0xe18>  // b.none
    8ea8:	cb190be0 	neg	x0, x25, lsl #2
    8eac:	cb1903e6 	neg	x6, x25
    8eb0:	8b0002e2 	add	x2, x23, x0
    8eb4:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8eb8:	37f80122 	tbnz	w2, #31, 8edc <fwp_main_thread+0xdec>
    8ebc:	f94003e3 	ldr	x3, [sp]
    8ec0:	93407c42 	sxtw	x2, w2
    8ec4:	8b060c68 	add	x8, x3, x6, lsl #3
    8ec8:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    8ecc:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8ed0:	1e620802 	fmul	d2, d0, d2
    8ed4:	1e622821 	fadd	d1, d1, d2
    8ed8:	fc227b61 	str	d1, [x27, x2, lsl #3]
    8edc:	8b000300 	add	x0, x24, x0
    8ee0:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8ee4:	37f80120 	tbnz	w0, #31, 8f08 <fwp_main_thread+0xe18>
    8ee8:	f94007e2 	ldr	x2, [sp, #8]
    8eec:	93407c00 	sxtw	x0, w0
    8ef0:	8b060c46 	add	x6, x2, x6, lsl #3
    8ef4:	fc607b61 	ldr	d1, [x27, x0, lsl #3]
    8ef8:	fc6178c2 	ldr	d2, [x6, x1, lsl #3]
    8efc:	1e620800 	fmul	d0, d0, d2
    8f00:	1e602820 	fadd	d0, d1, d0
    8f04:	fc207b60 	str	d0, [x27, x0, lsl #3]
    8f08:	d1000421 	sub	x1, x1, #0x1
    8f0c:	eb0100ff 	cmp	x7, x1
    8f10:	54fffc61 	b.ne	8e9c <fwp_main_thread+0xdac>  // b.any
    8f14:	52800080 	mov	w0, #0x4                   	// #4
    8f18:	97ffe9d6 	bl	3670 <descent_phase_step>
    8f1c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8f20:	eb00033f 	cmp	x25, x0
    8f24:	5400a468 	b.hi	a3b0 <fwp_main_thread+0x22c0>  // b.pmore
    8f28:	91000720 	add	x0, x25, #0x1
    8f2c:	52800041 	mov	w1, #0x2                   	// #2
    8f30:	d37df000 	lsl	x0, x0, #3
    8f34:	97fff023 	bl	4fc0 <fwp_heap_alloc>
    8f38:	aa0003e2 	mov	x2, x0
    8f3c:	aa0003f7 	mov	x23, x0
    8f40:	d2800001 	mov	x1, #0x0                   	// #0
    8f44:	f8008459 	str	x25, [x2], #8
    8f48:	b40000f9 	cbz	x25, 8f64 <fwp_main_thread+0xe74>
    8f4c:	d503201f 	nop
    8f50:	f8617b60 	ldr	x0, [x27, x1, lsl #3]
    8f54:	f8217840 	str	x0, [x2, x1, lsl #3]
    8f58:	91000421 	add	x1, x1, #0x1
    8f5c:	eb01033f 	cmp	x25, x1
    8f60:	54ffff81 	b.ne	8f50 <fwp_main_thread+0xe60>  // b.any
    8f64:	528000a0 	mov	w0, #0x5                   	// #5
    8f68:	97ffe9c2 	bl	3670 <descent_phase_step>
    8f6c:	f9400be0 	ldr	x0, [sp, #16]
    8f70:	9101c261 	add	x1, x19, #0x70
    8f74:	f9403bf8 	ldr	x24, [sp, #112]
    8f78:	f9019838 	str	x24, [x1, #816]
    8f7c:	97ffed35 	bl	4450 <fwp_tape_buffers_release>
    8f80:	528000c0 	mov	w0, #0x6                   	// #6
    8f84:	97ffe9bb 	bl	3670 <descent_phase_step>
    8f88:	f949db41 	ldr	x1, [x26, #5040]
    8f8c:	f949ef40 	ldr	x0, [x26, #5080]
    8f90:	cb0102e1 	sub	x1, x23, x1
    8f94:	eb00403f 	cmp	x1, x0, lsl #16
    8f98:	54000322 	b.cs	8ffc <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    8f9c:	d350fc20 	lsr	x0, x1, #16
    8fa0:	f949ff43 	ldr	x3, [x26, #5112]
    8fa4:	8b000800 	add	x0, x0, x0, lsl #2
    8fa8:	d37df002 	lsl	x2, x0, #3
    8fac:	8b020060 	add	x0, x3, x2
    8fb0:	f9401016 	ldr	x22, [x0, #32]
    8fb4:	b4000256 	cbz	x22, 8ffc <fwp_main_thread+0xf0c>
    8fb8:	38626862 	ldrb	w2, [x3, x2]
    8fbc:	7100085f 	cmp	w2, #0x2
    8fc0:	54007560 	b.eq	9e6c <fwp_main_thread+0x1d7c>  // b.none
    8fc4:	7100045f 	cmp	w2, #0x1
    8fc8:	540001a1 	b.ne	8ffc <fwp_main_thread+0xf0c>  // b.any
    8fcc:	29430002 	ldp	w2, w0, [x0, #24]
    8fd0:	92403c21 	and	x1, x1, #0xffff
    8fd4:	9b027c21 	mul	x1, x1, x2
    8fd8:	d360fc21 	lsr	x1, x1, #32
    8fdc:	eb00003f 	cmp	x1, x0
    8fe0:	540000e2 	b.cs	8ffc <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    8fe4:	8b0102d6 	add	x22, x22, x1
    8fe8:	394002c0 	ldrb	w0, [x22]
    8fec:	7103fc1f 	cmp	w0, #0xff
    8ff0:	54007480 	b.eq	9e80 <fwp_main_thread+0x1d90>  // b.none
    8ff4:	52800020 	mov	w0, #0x1                   	// #1
    8ff8:	390002c0 	strb	w0, [x22]
    8ffc:	f9401be0 	ldr	x0, [sp, #48]
    9000:	eb00031f 	cmp	x24, x0
    9004:	54009261 	b.ne	a250 <fwp_main_thread+0x2160>  // b.any
    9008:	f94017e0 	ldr	x0, [sp, #40]
    900c:	9101c261 	add	x1, x19, #0x70
    9010:	f9402fe2 	ldr	x2, [sp, #88]
    9014:	f9019822 	str	x2, [x1, #816]
    9018:	97fff42e 	bl	60d0 <fwp_tape_scope_release>
    901c:	f94002e0 	ldr	x0, [x23]
    9020:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    9024:	b7f85da0 	tbnz	x0, #63, 9bd8 <fwp_main_thread+0x1ae8>
    9028:	f949db40 	ldr	x0, [x26, #5040]
    902c:	f949ef41 	ldr	x1, [x26, #5080]
    9030:	cb0002e0 	sub	x0, x23, x0
    9034:	eb01401f 	cmp	x0, x1, lsl #16
    9038:	54005d02 	b.cs	9bd8 <fwp_main_thread+0x1ae8>  // b.hs, b.nlast
    903c:	d350fc01 	lsr	x1, x0, #16
    9040:	f949ff45 	ldr	x5, [x26, #5112]
    9044:	8b010821 	add	x1, x1, x1, lsl #2
    9048:	d37df021 	lsl	x1, x1, #3
    904c:	8b0100a3 	add	x3, x5, x1
    9050:	f9401062 	ldr	x2, [x3, #32]
    9054:	b4005c22 	cbz	x2, 9bd8 <fwp_main_thread+0x1ae8>
    9058:	386168a1 	ldrb	w1, [x5, x1]
    905c:	7100083f 	cmp	w1, #0x2
    9060:	54005b80 	b.eq	9bd0 <fwp_main_thread+0x1ae0>  // b.none
    9064:	7100043f 	cmp	w1, #0x1
    9068:	54005b81 	b.ne	9bd8 <fwp_main_thread+0x1ae8>  // b.any
    906c:	29430465 	ldp	w5, w1, [x3, #24]
    9070:	92403c00 	and	x0, x0, #0xffff
    9074:	9b057c00 	mul	x0, x0, x5
    9078:	d360fc00 	lsr	x0, x0, #32
    907c:	eb01001f 	cmp	x0, x1
    9080:	54005ac2 	b.cs	9bd8 <fwp_main_thread+0x1ae8>  // b.hs, b.nlast
    9084:	8b000042 	add	x2, x2, x0
    9088:	39400040 	ldrb	w0, [x2]
    908c:	7100041f 	cmp	w0, #0x1
    9090:	54005a41 	b.ne	9bd8 <fwp_main_thread+0x1ae8>  // b.any
    9094:	aa1703e5 	mov	x5, x23
    9098:	aa1703f6 	mov	x22, x23
    909c:	d2800000 	mov	x0, #0x0                   	// #0
    90a0:	910022c3 	add	x3, x22, #0x8
    90a4:	910022e7 	add	x7, x23, #0x8
    90a8:	d2800001 	mov	x1, #0x0                   	// #0
    90ac:	b5000158 	cbnz	x24, 90d4 <fwp_main_thread+0xfe4>
    90b0:	140000b4 	b	9380 <fwp_main_thread+0x1290>
    90b4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    90b8:	f94000a2 	ldr	x2, [x5]
    90bc:	1e600900 	fmul	d0, d8, d0
    90c0:	b7f89262 	tbnz	x2, #63, a30c <fwp_main_thread+0x221c>
    90c4:	91000421 	add	x1, x1, #0x1
    90c8:	fc008460 	str	d0, [x3], #8
    90cc:	eb01031f 	cmp	x24, x1
    90d0:	54001580 	b.eq	9380 <fwp_main_thread+0x1290>  // b.none
    90d4:	f94002e6 	ldr	x6, [x23]
    90d8:	aa0703e2 	mov	x2, x7
    90dc:	b6fffec6 	tbz	x6, #63, 90b4 <fwp_main_thread+0xfc4>
    90e0:	f9400ae2 	ldr	x2, [x23, #16]
    90e4:	17fffff4 	b	90b4 <fwp_main_thread+0xfc4>
    90e8:	f90042b4 	str	x20, [x21, #128]
    90ec:	17fffca3 	b	8378 <fwp_main_thread+0x288>
    90f0:	f941c2c0 	ldr	x0, [x22, #896]
    90f4:	b9037adf 	str	wzr, [x22, #888]
    90f8:	b5008a60 	cbnz	x0, a244 <fwp_main_thread+0x2154>
    90fc:	9101c275 	add	x21, x19, #0x70
    9100:	97fff51c 	bl	6570 <fwp_free_zombie>
    9104:	f94042a0 	ldr	x0, [x21, #128]
    9108:	b50089e0 	cbnz	x0, a244 <fwp_main_thread+0x2154>
    910c:	f9407ea0 	ldr	x0, [x21, #248]
    9110:	b50089a0 	cbnz	x0, a244 <fwp_main_thread+0x2154>
    9114:	b9411aa0 	ldr	w0, [x21, #280]
    9118:	340001e0 	cbz	w0, 9154 <fwp_main_thread+0x1064>
    911c:	93407c16 	sxtw	x22, w0
    9120:	51000400 	sub	w0, w0, #0x1
    9124:	d1000ad6 	sub	x22, x22, #0x2
    9128:	910482b7 	add	x23, x21, #0x120
    912c:	cb2042d6 	sub	x22, x22, w0, uxtw
    9130:	93407c14 	sxtw	x20, w0
    9134:	d503201f 	nop
    9138:	f8747ae0 	ldr	x0, [x23, x20, lsl #3]
    913c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9140:	b9011ab4 	str	w20, [x21, #280]
    9144:	d1000694 	sub	x20, x20, #0x1
    9148:	97ffe63a 	bl	2a30 <munmap@plt>
    914c:	eb16029f 	cmp	x20, x22
    9150:	54ffff41 	b.ne	9138 <fwp_main_thread+0x1048>  // b.any
    9154:	f00000b4 	adrp	x20, 20000 <__data_start>
    9158:	91004280 	add	x0, x20, #0x10
    915c:	b9404000 	ldr	w0, [x0, #64]
    9160:	37f80040 	tbnz	w0, #31, 9168 <fwp_main_thread+0x1078>
    9164:	97ffe5ef 	bl	2920 <close@plt>
    9168:	9101c260 	add	x0, x19, #0x70
    916c:	91004281 	add	x1, x20, #0x10
    9170:	12800002 	mov	w2, #0xffffffff            	// #-1
    9174:	d2800014 	mov	x20, #0x0                   	// #0
    9178:	f941c416 	ldr	x22, [x0, #904]
    917c:	b9004022 	str	w2, [x1, #64]
    9180:	f941c815 	ldr	x21, [x0, #912]
    9184:	b4000176 	cbz	x22, 91b0 <fwp_main_thread+0x10c0>
    9188:	f8747aa0 	ldr	x0, [x21, x20, lsl #3]
    918c:	b40000c0 	cbz	x0, 91a4 <fwp_main_thread+0x10b4>
    9190:	f9400001 	ldr	x1, [x0]
    9194:	b5008581 	cbnz	x1, a244 <fwp_main_thread+0x2154>
    9198:	f9400401 	ldr	x1, [x0, #8]
    919c:	b5008541 	cbnz	x1, a244 <fwp_main_thread+0x2154>
    91a0:	97ffee68 	bl	4b40 <fwp_mem_free>
    91a4:	91000694 	add	x20, x20, #0x1
    91a8:	eb1402df 	cmp	x22, x20
    91ac:	54fffee1 	b.ne	9188 <fwp_main_thread+0x1098>  // b.any
    91b0:	aa1503e0 	mov	x0, x21
    91b4:	97ffee63 	bl	4b40 <fwp_mem_free>
    91b8:	9101c260 	add	x0, x19, #0x70
    91bc:	f941c014 	ldr	x20, [x0, #896]
    91c0:	f901c41f 	str	xzr, [x0, #904]
    91c4:	f901c81f 	str	xzr, [x0, #912]
    91c8:	b40001f4 	cbz	x20, 9204 <fwp_main_thread+0x1114>
    91cc:	f9401681 	ldr	x1, [x20, #40]
    91d0:	b50083a1 	cbnz	x1, a244 <fwp_main_thread+0x2154>
    91d4:	f9405681 	ldr	x1, [x20, #168]
    91d8:	b5008361 	cbnz	x1, a244 <fwp_main_thread+0x2154>
    91dc:	f941a401 	ldr	x1, [x0, #840]
    91e0:	b5008321 	cbnz	x1, a244 <fwp_main_thread+0x2154>
    91e4:	f941ac00 	ldr	x0, [x0, #856]
    91e8:	b50082e0 	cbnz	x0, a244 <fwp_main_thread+0x2154>
    91ec:	d2823a02 	mov	x2, #0x11d0                	// #4560
    91f0:	f0000120 	adrp	x0, 30000 <alt.9+0xfbf0>
    91f4:	91104000 	add	x0, x0, #0x410
    91f8:	97ffe5ba 	bl	28e0 <memset@plt>
    91fc:	aa1403e0 	mov	x0, x20
    9200:	97ffee50 	bl	4b40 <fwp_mem_free>
    9204:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9208:	f947ec00 	ldr	x0, [x0, #4056]
    920c:	9101c273 	add	x19, x19, #0x70
    9210:	f9400000 	ldr	x0, [x0]
    9214:	f9000a7f 	str	xzr, [x19, #16]
    9218:	f901c27f 	str	xzr, [x19, #896]
    921c:	97ffe609 	bl	2a40 <fflush@plt>
    9220:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9224:	f947f400 	ldr	x0, [x0, #4072]
    9228:	f940c7e2 	ldr	x2, [sp, #392]
    922c:	f9400001 	ldr	x1, [x0]
    9230:	eb010042 	subs	x2, x2, x1
    9234:	d2800001 	mov	x1, #0x0                   	// #0
    9238:	54008b01 	b.ne	a398 <fwp_main_thread+0x22a8>  // b.any
    923c:	a95c63f7 	ldp	x23, x24, [sp, #448]
    9240:	910643ff 	add	sp, sp, #0x190
    9244:	d2800000 	mov	x0, #0x0                   	// #0
    9248:	a94153f3 	ldp	x19, x20, [sp, #16]
    924c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9250:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9254:	d65f03c0 	ret
    9258:	72003c3f 	tst	w1, #0xffff
    925c:	54ff9821 	b.ne	8560 <fwp_main_thread+0x470>  // b.any
    9260:	394002e0 	ldrb	w0, [x23]
    9264:	7103fc1f 	cmp	w0, #0xff
    9268:	54ff97a1 	b.ne	855c <fwp_main_thread+0x46c>  // b.any
    926c:	aa1703e0 	mov	x0, x23
    9270:	97ffed94 	bl	48c0 <fwp_rc_forget_slot>
    9274:	17fffcba 	b	855c <fwp_main_thread+0x46c>
    9278:	f0ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    927c:	91008000 	add	x0, x0, #0x20
    9280:	94000618 	bl	aae0 <atexit>
    9284:	17fffbad 	b	8138 <fwp_main_thread+0x48>
    9288:	97ffebbf 	bl	4184 <fwp_heap_init>
    928c:	17fffba7 	b	8128 <fwp_main_thread+0x38>
    9290:	d37df2c2 	lsl	x2, x22, #3
    9294:	aa1b03e0 	mov	x0, x27
    9298:	52800001 	mov	w1, #0x0                   	// #0
    929c:	97ffe591 	bl	28e0 <memset@plt>
    92a0:	17fffeee 	b	8e58 <fwp_main_thread+0xd68>
    92a4:	f100037f 	cmp	x27, #0x0
    92a8:	1a9f17e0 	cset	w0, eq	// eq = none
    92ac:	f10002df 	cmp	x22, #0x0
    92b0:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    92b4:	54ffdd00 	b.eq	8e54 <fwp_main_thread+0xd64>  // b.none
    92b8:	f9400be0 	ldr	x0, [sp, #16]
    92bc:	9101c273 	add	x19, x19, #0x70
    92c0:	f9403be1 	ldr	x1, [sp, #112]
    92c4:	f9019a61 	str	x1, [x19, #816]
    92c8:	97ffec62 	bl	4450 <fwp_tape_buffers_release>
    92cc:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    92d0:	f947e863 	ldr	x3, [x3, #4048]
    92d4:	d2800262 	mov	x2, #0x13                  	// #19
    92d8:	d2800021 	mov	x1, #0x1                   	// #1
    92dc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    92e0:	912c6000 	add	x0, x0, #0xb18
    92e4:	f9400063 	ldr	x3, [x3]
    92e8:	97ffe5ca 	bl	2a10 <fwrite@plt>
    92ec:	d2800000 	mov	x0, #0x0                   	// #0
    92f0:	97ffe5d4 	bl	2a40 <fflush@plt>
    92f4:	52800cc0 	mov	w0, #0x66                  	// #102
    92f8:	97ffe5e2 	bl	2a80 <_Exit@plt>
    92fc:	f9400366 	ldr	x6, [x27]
    9300:	aa1b03e0 	mov	x0, x27
    9304:	f949ef43 	ldr	x3, [x26, #5080]
    9308:	f949db41 	ldr	x1, [x26, #5040]
    930c:	d370bc63 	lsl	x3, x3, #16
    9310:	cb010362 	sub	x2, x27, x1
    9314:	b7f84fe6 	tbnz	x6, #63, 9d10 <fwp_main_thread+0x1c20>
    9318:	eb03005f 	cmp	x2, x3
    931c:	54ffcfa2 	b.cs	8d10 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    9320:	d350fc40 	lsr	x0, x2, #16
    9324:	8b000800 	add	x0, x0, x0, lsl #2
    9328:	d37df000 	lsl	x0, x0, #3
    932c:	8b0000a3 	add	x3, x5, x0
    9330:	f9401061 	ldr	x1, [x3, #32]
    9334:	b4ffcee1 	cbz	x1, 8d10 <fwp_main_thread+0xc20>
    9338:	386068a0 	ldrb	w0, [x5, x0]
    933c:	7100081f 	cmp	w0, #0x2
    9340:	54005a60 	b.eq	9e8c <fwp_main_thread+0x1d9c>  // b.none
    9344:	7100041f 	cmp	w0, #0x1
    9348:	54ffce41 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    934c:	92403c40 	and	x0, x2, #0xffff
    9350:	29430865 	ldp	w5, w2, [x3, #24]
    9354:	9b057c00 	mul	x0, x0, x5
    9358:	d360fc00 	lsr	x0, x0, #32
    935c:	eb02001f 	cmp	x0, x2
    9360:	54ffcd82 	b.cs	8d10 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    9364:	8b000021 	add	x1, x1, x0
    9368:	39400020 	ldrb	w0, [x1]
    936c:	7100041f 	cmp	w0, #0x1
    9370:	54ffcd01 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    9374:	aa1b03e0 	mov	x0, x27
    9378:	97ffedf2 	bl	4b40 <fwp_mem_free>
    937c:	17fffe65 	b	8d10 <fwp_main_thread+0xc20>
    9380:	f90003e5 	str	x5, [sp]
    9384:	97fff53f 	bl	6880 <fwp_drop10>
    9388:	f94003e5 	ldr	x5, [sp]
    938c:	aa1503e1 	mov	x1, x21
    9390:	d2800002 	mov	x2, #0x0                   	// #0
    9394:	b4005fb5 	cbz	x21, 9f88 <fwp_main_thread+0x1e98>
    9398:	f9400821 	ldr	x1, [x1, #16]
    939c:	91000442 	add	x2, x2, #0x1
    93a0:	b5ffffc1 	cbnz	x1, 9398 <fwp_main_thread+0x12a8>
    93a4:	f94000a0 	ldr	x0, [x5]
    93a8:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    93ac:	b7f83620 	tbnz	x0, #63, 9a70 <fwp_main_thread+0x1980>
    93b0:	f949db41 	ldr	x1, [x26, #5040]
    93b4:	f949ef43 	ldr	x3, [x26, #5080]
    93b8:	cb0102c1 	sub	x1, x22, x1
    93bc:	eb03403f 	cmp	x1, x3, lsl #16
    93c0:	54003582 	b.cs	9a70 <fwp_main_thread+0x1980>  // b.hs, b.nlast
    93c4:	d350fc23 	lsr	x3, x1, #16
    93c8:	f949ff48 	ldr	x8, [x26, #5112]
    93cc:	8b030863 	add	x3, x3, x3, lsl #2
    93d0:	d37df063 	lsl	x3, x3, #3
    93d4:	8b030107 	add	x7, x8, x3
    93d8:	f94010e6 	ldr	x6, [x7, #32]
    93dc:	b4003486 	cbz	x6, 9a6c <fwp_main_thread+0x197c>
    93e0:	38636903 	ldrb	w3, [x8, x3]
    93e4:	7100087f 	cmp	w3, #0x2
    93e8:	540033e0 	b.eq	9a64 <fwp_main_thread+0x1974>  // b.none
    93ec:	7100047f 	cmp	w3, #0x1
    93f0:	540033e1 	b.ne	9a6c <fwp_main_thread+0x197c>  // b.any
    93f4:	29430ce8 	ldp	w8, w3, [x7, #24]
    93f8:	92403c21 	and	x1, x1, #0xffff
    93fc:	9b087c21 	mul	x1, x1, x8
    9400:	d360fc21 	lsr	x1, x1, #32
    9404:	eb03003f 	cmp	x1, x3
    9408:	54003322 	b.cs	9a6c <fwp_main_thread+0x197c>  // b.hs, b.nlast
    940c:	8b0100c6 	add	x6, x6, x1
    9410:	394000d7 	ldrb	w23, [x6]
    9414:	710006ff 	cmp	w23, #0x1
    9418:	540032a1 	b.ne	9a6c <fwp_main_thread+0x197c>  // b.any
    941c:	b90003f7 	str	w23, [sp]
    9420:	eb1b005f 	cmp	x2, x27
    9424:	9a9b905b 	csel	x27, x2, x27, ls	// ls = plast
    9428:	910020bc 	add	x28, x5, #0x8
    942c:	b40069bb 	cbz	x27, a160 <fwp_main_thread+0x2070>
    9430:	d37df367 	lsl	x7, x27, #3
    9434:	aa1503e2 	mov	x2, x21
    9438:	910022c6 	add	x6, x22, #0x8
    943c:	d2800001 	mov	x1, #0x0                   	// #0
    9440:	1400000a 	b	9468 <fwp_main_thread+0x1378>
    9444:	fc616861 	ldr	d1, [x3, x1]
    9448:	fd400440 	ldr	d0, [x2, #8]
    944c:	1e613800 	fsub	d0, d0, d1
    9450:	fc216b80 	str	d0, [x28, x1]
    9454:	91002021 	add	x1, x1, #0x8
    9458:	f9400842 	ldr	x2, [x2, #16]
    945c:	eb07003f 	cmp	x1, x7
    9460:	540001a0 	b.eq	9494 <fwp_main_thread+0x13a4>  // b.none
    9464:	f94000a0 	ldr	x0, [x5]
    9468:	aa0603e3 	mov	x3, x6
    946c:	b6fffec0 	tbz	x0, #63, 9444 <fwp_main_thread+0x1354>
    9470:	f9400ac3 	ldr	x3, [x22, #16]
    9474:	fd400440 	ldr	d0, [x2, #8]
    9478:	fc616861 	ldr	d1, [x3, x1]
    947c:	1e613800 	fsub	d0, d0, d1
    9480:	fc216b80 	str	d0, [x28, x1]
    9484:	91002021 	add	x1, x1, #0x8
    9488:	f9400842 	ldr	x2, [x2, #16]
    948c:	eb07003f 	cmp	x1, x7
    9490:	54fffea1 	b.ne	9464 <fwp_main_thread+0x1374>  // b.any
    9494:	b4006b95 	cbz	x21, a204 <fwp_main_thread+0x2114>
    9498:	f949ef48 	ldr	x8, [x26, #5080]
    949c:	aa1503e6 	mov	x6, x21
    94a0:	f949db49 	ldr	x9, [x26, #5040]
    94a4:	d2800017 	mov	x23, #0x0                   	// #0
    94a8:	f949ff47 	ldr	x7, [x26, #5112]
    94ac:	d370bd08 	lsl	x8, x8, #16
    94b0:	14000006 	b	94c8 <fwp_main_thread+0x13d8>
    94b4:	f94008c6 	ldr	x6, [x6, #16]
    94b8:	910006f7 	add	x23, x23, #0x1
    94bc:	f10000df 	cmp	x6, #0x0
    94c0:	fa571360 	ccmp	x27, x23, #0x0, ne	// ne = any
    94c4:	54003dc9 	b.ls	9c7c <fwp_main_thread+0x1b8c>  // b.plast
    94c8:	cb0900c0 	sub	x0, x6, x9
    94cc:	eb08001f 	cmp	x0, x8
    94d0:	540002c2 	b.cs	9528 <fwp_main_thread+0x1438>  // b.hs, b.nlast
    94d4:	d350fc01 	lsr	x1, x0, #16
    94d8:	8b010821 	add	x1, x1, x1, lsl #2
    94dc:	d37df021 	lsl	x1, x1, #3
    94e0:	8b0100e5 	add	x5, x7, x1
    94e4:	f94010a2 	ldr	x2, [x5, #32]
    94e8:	b4000202 	cbz	x2, 9528 <fwp_main_thread+0x1438>
    94ec:	386168e1 	ldrb	w1, [x7, x1]
    94f0:	7100083f 	cmp	w1, #0x2
    94f4:	54000d80 	b.eq	96a4 <fwp_main_thread+0x15b4>  // b.none
    94f8:	7100043f 	cmp	w1, #0x1
    94fc:	54000161 	b.ne	9528 <fwp_main_thread+0x1438>  // b.any
    9500:	294304aa 	ldp	w10, w1, [x5, #24]
    9504:	92403c00 	and	x0, x0, #0xffff
    9508:	9b0a7c00 	mul	x0, x0, x10
    950c:	d360fc00 	lsr	x0, x0, #32
    9510:	eb01001f 	cmp	x0, x1
    9514:	540000a2 	b.cs	9528 <fwp_main_thread+0x1438>  // b.hs, b.nlast
    9518:	8b000042 	add	x2, x2, x0
    951c:	39400040 	ldrb	w0, [x2]
    9520:	7100041f 	cmp	w0, #0x1
    9524:	54fffc80 	b.eq	94b4 <fwp_main_thread+0x13c4>  // b.none
    9528:	eb1b02ff 	cmp	x23, x27
    952c:	54000c62 	b.cs	96b8 <fwp_main_thread+0x15c8>  // b.hs, b.nlast
    9530:	d1002399 	sub	x25, x28, #0x8
    9534:	d2800018 	mov	x24, #0x0                   	// #0
    9538:	14000012 	b	9580 <fwp_main_thread+0x1490>
    953c:	7100045f 	cmp	w2, #0x1
    9540:	540001a1 	b.ne	9574 <fwp_main_thread+0x1484>  // b.any
    9544:	294308c7 	ldp	w7, w2, [x6, #24]
    9548:	92403c21 	and	x1, x1, #0xffff
    954c:	9b077c21 	mul	x1, x1, x7
    9550:	d360fc21 	lsr	x1, x1, #32
    9554:	eb02003f 	cmp	x1, x2
    9558:	540000e2 	b.cs	9574 <fwp_main_thread+0x1484>  // b.hs, b.nlast
    955c:	8b010000 	add	x0, x0, x1
    9560:	39400001 	ldrb	w1, [x0]
    9564:	7103fc3f 	cmp	w1, #0xff
    9568:	54003b80 	b.eq	9cd8 <fwp_main_thread+0x1be8>  // b.none
    956c:	52800021 	mov	w1, #0x1                   	// #1
    9570:	39000001 	strb	w1, [x0]
    9574:	d100077b 	sub	x27, x27, #0x1
    9578:	eb1b02ff 	cmp	x23, x27
    957c:	54000362 	b.cs	95e8 <fwp_main_thread+0x14f8>  // b.hs, b.nlast
    9580:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    9584:	aa1403e1 	mov	x1, x20
    9588:	52800020 	mov	w0, #0x1                   	// #1
    958c:	a90f63e2 	stp	x2, x24, [sp, #240]
    9590:	97ffeed1 	bl	50d4 <fwp_data.part.0.constprop.0>
    9594:	aa0003f8 	mov	x24, x0
    9598:	f949db41 	ldr	x1, [x26, #5040]
    959c:	f949ef40 	ldr	x0, [x26, #5080]
    95a0:	cb010301 	sub	x1, x24, x1
    95a4:	eb00403f 	cmp	x1, x0, lsl #16
    95a8:	54fffe62 	b.cs	9574 <fwp_main_thread+0x1484>  // b.hs, b.nlast
    95ac:	d350fc20 	lsr	x0, x1, #16
    95b0:	f949ff47 	ldr	x7, [x26, #5112]
    95b4:	8b000800 	add	x0, x0, x0, lsl #2
    95b8:	d37df002 	lsl	x2, x0, #3
    95bc:	8b0200e6 	add	x6, x7, x2
    95c0:	f94010c0 	ldr	x0, [x6, #32]
    95c4:	b4fffd80 	cbz	x0, 9574 <fwp_main_thread+0x1484>
    95c8:	386268e2 	ldrb	w2, [x7, x2]
    95cc:	7100085f 	cmp	w2, #0x2
    95d0:	54fffb61 	b.ne	953c <fwp_main_thread+0x144c>  // b.any
    95d4:	72003c3f 	tst	w1, #0xffff
    95d8:	54fffc40 	b.eq	9560 <fwp_main_thread+0x1470>  // b.none
    95dc:	d100077b 	sub	x27, x27, #0x1
    95e0:	eb1b02ff 	cmp	x23, x27
    95e4:	54fffce3 	b.cc	9580 <fwp_main_thread+0x1490>  // b.lo, b.ul, b.last
    95e8:	b50006b7 	cbnz	x23, 96bc <fwp_main_thread+0x15cc>
    95ec:	b94003e0 	ldr	w0, [sp]
    95f0:	d2800037 	mov	x23, #0x1                   	// #1
    95f4:	d280001b 	mov	x27, #0x0                   	// #0
    95f8:	7100001f 	cmp	w0, #0x0
    95fc:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    9600:	b40004fb 	cbz	x27, 969c <fwp_main_thread+0x15ac>
    9604:	d100077b 	sub	x27, x27, #0x1
    9608:	f87b7b82 	ldr	x2, [x28, x27, lsl #3]
    960c:	aa1403e1 	mov	x1, x20
    9610:	52800020 	mov	w0, #0x1                   	// #1
    9614:	a90f63e2 	stp	x2, x24, [sp, #240]
    9618:	97ffeeaf 	bl	50d4 <fwp_data.part.0.constprop.0>
    961c:	aa0003f8 	mov	x24, x0
    9620:	f949db41 	ldr	x1, [x26, #5040]
    9624:	f949ef40 	ldr	x0, [x26, #5080]
    9628:	cb010301 	sub	x1, x24, x1
    962c:	eb00403f 	cmp	x1, x0, lsl #16
    9630:	54000302 	b.cs	9690 <fwp_main_thread+0x15a0>  // b.hs, b.nlast
    9634:	d350fc22 	lsr	x2, x1, #16
    9638:	f949ff45 	ldr	x5, [x26, #5112]
    963c:	8b020842 	add	x2, x2, x2, lsl #2
    9640:	d37df042 	lsl	x2, x2, #3
    9644:	8b0200a3 	add	x3, x5, x2
    9648:	f9401079 	ldr	x25, [x3, #32]
    964c:	b4000239 	cbz	x25, 9690 <fwp_main_thread+0x15a0>
    9650:	386268a2 	ldrb	w2, [x5, x2]
    9654:	7100085f 	cmp	w2, #0x2
    9658:	54002000 	b.eq	9a58 <fwp_main_thread+0x1968>  // b.none
    965c:	7100045f 	cmp	w2, #0x1
    9660:	54000181 	b.ne	9690 <fwp_main_thread+0x15a0>  // b.any
    9664:	29430865 	ldp	w5, w2, [x3, #24]
    9668:	92403c21 	and	x1, x1, #0xffff
    966c:	9b057c21 	mul	x1, x1, x5
    9670:	d360fc21 	lsr	x1, x1, #32
    9674:	eb02003f 	cmp	x1, x2
    9678:	540000c2 	b.cs	9690 <fwp_main_thread+0x15a0>  // b.hs, b.nlast
    967c:	8b010339 	add	x25, x25, x1
    9680:	39400321 	ldrb	w1, [x25]
    9684:	7103fc3f 	cmp	w1, #0xff
    9688:	54001e20 	b.eq	9a4c <fwp_main_thread+0x195c>  // b.none
    968c:	39000337 	strb	w23, [x25]
    9690:	d100077b 	sub	x27, x27, #0x1
    9694:	b100077f 	cmn	x27, #0x1
    9698:	54fffb81 	b.ne	9608 <fwp_main_thread+0x1518>  // b.any
    969c:	aa1503fb 	mov	x27, x21
    96a0:	14000015 	b	96f4 <fwp_main_thread+0x1604>
    96a4:	72003c1f 	tst	w0, #0xffff
    96a8:	54fff3a0 	b.eq	951c <fwp_main_thread+0x142c>  // b.none
    96ac:	eb1b02ff 	cmp	x23, x27
    96b0:	54fff403 	b.cc	9530 <fwp_main_thread+0x1440>  // b.lo, b.ul, b.last
    96b4:	d503201f 	nop
    96b8:	d2800018 	mov	x24, #0x0                   	// #0
    96bc:	8b170f83 	add	x3, x28, x23, lsl #3
    96c0:	aa1c03e0 	mov	x0, x28
    96c4:	aa1503fb 	mov	x27, x21
    96c8:	f8408401 	ldr	x1, [x0], #8
    96cc:	f9000761 	str	x1, [x27, #8]
    96d0:	aa1b03e1 	mov	x1, x27
    96d4:	f9400b7b 	ldr	x27, [x27, #16]
    96d8:	eb03001f 	cmp	x0, x3
    96dc:	54ffff61 	b.ne	96c8 <fwp_main_thread+0x15d8>  // b.any
    96e0:	b94003e0 	ldr	w0, [sp]
    96e4:	f9000838 	str	x24, [x1, #16]
    96e8:	aa1503f8 	mov	x24, x21
    96ec:	7100001f 	cmp	w0, #0x0
    96f0:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    96f4:	aa1c03e0 	mov	x0, x28
    96f8:	97ffed12 	bl	4b40 <fwp_mem_free>
    96fc:	f949ef42 	ldr	x2, [x26, #5080]
    9700:	f949db41 	ldr	x1, [x26, #5040]
    9704:	d370bc42 	lsl	x2, x2, #16
    9708:	cb0102c3 	sub	x3, x22, x1
    970c:	eb02007f 	cmp	x3, x2
    9710:	54000402 	b.cs	9790 <fwp_main_thread+0x16a0>  // b.hs, b.nlast
    9714:	d350fc60 	lsr	x0, x3, #16
    9718:	f949ff45 	ldr	x5, [x26, #5112]
    971c:	8b000800 	add	x0, x0, x0, lsl #2
    9720:	d37df000 	lsl	x0, x0, #3
    9724:	8b0000a2 	add	x2, x5, x0
    9728:	f9401057 	ldr	x23, [x2, #32]
    972c:	b4001897 	cbz	x23, 9a3c <fwp_main_thread+0x194c>
    9730:	386068a1 	ldrb	w1, [x5, x0]
    9734:	7100083f 	cmp	w1, #0x2
    9738:	54002e60 	b.eq	9d04 <fwp_main_thread+0x1c14>  // b.none
    973c:	7100043f 	cmp	w1, #0x1
    9740:	540017e1 	b.ne	9a3c <fwp_main_thread+0x194c>  // b.any
    9744:	29430846 	ldp	w6, w2, [x2, #24]
    9748:	92403c61 	and	x1, x3, #0xffff
    974c:	9b067c21 	mul	x1, x1, x6
    9750:	d360fc21 	lsr	x1, x1, #32
    9754:	eb02003f 	cmp	x1, x2
    9758:	54001722 	b.cs	9a3c <fwp_main_thread+0x194c>  // b.hs, b.nlast
    975c:	8b0102f7 	add	x23, x23, x1
    9760:	394002e1 	ldrb	w1, [x23]
    9764:	340016c1 	cbz	w1, 9a3c <fwp_main_thread+0x194c>
    9768:	7100043f 	cmp	w1, #0x1
    976c:	54001280 	b.eq	99bc <fwp_main_thread+0x18cc>  // b.none
    9770:	7103fc3f 	cmp	w1, #0xff
    9774:	54004580 	b.eq	a024 <fwp_main_thread+0x1f34>  // b.none
    9778:	51000421 	sub	w1, w1, #0x1
    977c:	390002e1 	strb	w1, [x23]
    9780:	f949ef42 	ldr	x2, [x26, #5080]
    9784:	f949db41 	ldr	x1, [x26, #5040]
    9788:	d370bc42 	lsl	x2, x2, #16
    978c:	d503201f 	nop
    9790:	cb010361 	sub	x1, x27, x1
    9794:	eb02003f 	cmp	x1, x2
    9798:	54000382 	b.cs	9808 <fwp_main_thread+0x1718>  // b.hs, b.nlast
    979c:	d350fc20 	lsr	x0, x1, #16
    97a0:	f949ff43 	ldr	x3, [x26, #5112]
    97a4:	8b000800 	add	x0, x0, x0, lsl #2
    97a8:	d37df000 	lsl	x0, x0, #3
    97ac:	8b000062 	add	x2, x3, x0
    97b0:	f9401056 	ldr	x22, [x2, #32]
    97b4:	b40002b6 	cbz	x22, 9808 <fwp_main_thread+0x1718>
    97b8:	38606865 	ldrb	w5, [x3, x0]
    97bc:	710008bf 	cmp	w5, #0x2
    97c0:	54002e80 	b.eq	9d90 <fwp_main_thread+0x1ca0>  // b.none
    97c4:	710004bf 	cmp	w5, #0x1
    97c8:	54000201 	b.ne	9808 <fwp_main_thread+0x1718>  // b.any
    97cc:	29430845 	ldp	w5, w2, [x2, #24]
    97d0:	92403c21 	and	x1, x1, #0xffff
    97d4:	9b057c21 	mul	x1, x1, x5
    97d8:	d360fc21 	lsr	x1, x1, #32
    97dc:	eb02003f 	cmp	x1, x2
    97e0:	54000142 	b.cs	9808 <fwp_main_thread+0x1718>  // b.hs, b.nlast
    97e4:	8b0102d6 	add	x22, x22, x1
    97e8:	394002c1 	ldrb	w1, [x22]
    97ec:	340000e1 	cbz	w1, 9808 <fwp_main_thread+0x1718>
    97f0:	7100043f 	cmp	w1, #0x1
    97f4:	54003520 	b.eq	9e98 <fwp_main_thread+0x1da8>  // b.none
    97f8:	7103fc3f 	cmp	w1, #0xff
    97fc:	540047e0 	b.eq	a0f8 <fwp_main_thread+0x2008>  // b.none
    9800:	51000421 	sub	w1, w1, #0x1
    9804:	390002c1 	strb	w1, [x22]
    9808:	f9400be0 	ldr	x0, [sp, #16]
    980c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x11338>
    9810:	910aa042 	add	x2, x2, #0x2a8
    9814:	aa1803e1 	mov	x1, x24
    9818:	91014042 	add	x2, x2, #0x50
    981c:	52800023 	mov	w3, #0x1                   	// #1
    9820:	a908ffff 	stp	xzr, xzr, [sp, #136]
    9824:	f9004fff 	str	xzr, [sp, #152]
    9828:	97fff637 	bl	7104 <fwp_write>
    982c:	a948eff7 	ldp	x23, x27, [sp, #136]
    9830:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    9834:	91198000 	add	x0, x0, #0x660
    9838:	f10002ff 	cmp	x23, #0x0
    983c:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    9840:	b1002b7f 	cmn	x27, #0xa
    9844:	540058e8 	b.hi	a360 <fwp_main_thread+0x2270>  // b.pmore
    9848:	91002760 	add	x0, x27, #0x9
    984c:	52800021 	mov	w1, #0x1                   	// #1
    9850:	97ffeddc 	bl	4fc0 <fwp_heap_alloc>
    9854:	aa0003fc 	mov	x28, x0
    9858:	aa0003f6 	mov	x22, x0
    985c:	aa1b03e2 	mov	x2, x27
    9860:	aa1703e1 	mov	x1, x23
    9864:	f800879b 	str	x27, [x28], #8
    9868:	8b1b02db 	add	x27, x22, x27
    986c:	aa1c03e0 	mov	x0, x28
    9870:	97ffe3bc 	bl	2760 <memcpy@plt>
    9874:	3900237f 	strb	wzr, [x27, #8]
    9878:	f94047e0 	ldr	x0, [sp, #136]
    987c:	97ffe455 	bl	29d0 <free@plt>
    9880:	f949db42 	ldr	x2, [x26, #5040]
    9884:	f949ef40 	ldr	x0, [x26, #5080]
    9888:	cb0202c2 	sub	x2, x22, x2
    988c:	eb00405f 	cmp	x2, x0, lsl #16
    9890:	54000322 	b.cs	98f4 <fwp_main_thread+0x1804>  // b.hs, b.nlast
    9894:	d350fc40 	lsr	x0, x2, #16
    9898:	f949ff43 	ldr	x3, [x26, #5112]
    989c:	8b000800 	add	x0, x0, x0, lsl #2
    98a0:	d37df001 	lsl	x1, x0, #3
    98a4:	8b010060 	add	x0, x3, x1
    98a8:	f9401017 	ldr	x23, [x0, #32]
    98ac:	b4000257 	cbz	x23, 98f4 <fwp_main_thread+0x1804>
    98b0:	38616861 	ldrb	w1, [x3, x1]
    98b4:	7100083f 	cmp	w1, #0x2
    98b8:	540041a0 	b.eq	a0ec <fwp_main_thread+0x1ffc>  // b.none
    98bc:	7100043f 	cmp	w1, #0x1
    98c0:	540001a1 	b.ne	98f4 <fwp_main_thread+0x1804>  // b.any
    98c4:	29430003 	ldp	w3, w0, [x0, #24]
    98c8:	92403c41 	and	x1, x2, #0xffff
    98cc:	9b037c21 	mul	x1, x1, x3
    98d0:	d360fc21 	lsr	x1, x1, #32
    98d4:	eb00003f 	cmp	x1, x0
    98d8:	540000e2 	b.cs	98f4 <fwp_main_thread+0x1804>  // b.hs, b.nlast
    98dc:	8b0102f7 	add	x23, x23, x1
    98e0:	394002e0 	ldrb	w0, [x23]
    98e4:	7103fc1f 	cmp	w0, #0xff
    98e8:	54004920 	b.eq	a20c <fwp_main_thread+0x211c>  // b.none
    98ec:	52800020 	mov	w0, #0x1                   	// #1
    98f0:	390002e0 	strb	w0, [x23]
    98f4:	9101c277 	add	x23, x19, #0x70
    98f8:	aa1803e0 	mov	x0, x24
    98fc:	97fff0c1 	bl	5c00 <fwp_drop0>
    9900:	f94002c2 	ldr	x2, [x22]
    9904:	d2800021 	mov	x1, #0x1                   	// #1
    9908:	f94006e3 	ldr	x3, [x23, #8]
    990c:	aa1c03e0 	mov	x0, x28
    9910:	97ffe440 	bl	2a10 <fwrite@plt>
    9914:	f94006e1 	ldr	x1, [x23, #8]
    9918:	52800140 	mov	w0, #0xa                   	// #10
    991c:	97ffe3c5 	bl	2830 <fputc@plt>
    9920:	f949db42 	ldr	x2, [x26, #5040]
    9924:	f949ef40 	ldr	x0, [x26, #5080]
    9928:	cb0202c2 	sub	x2, x22, x2
    992c:	eb00405f 	cmp	x2, x0, lsl #16
    9930:	54000382 	b.cs	99a0 <fwp_main_thread+0x18b0>  // b.hs, b.nlast
    9934:	d350fc40 	lsr	x0, x2, #16
    9938:	f949ff43 	ldr	x3, [x26, #5112]
    993c:	8b000800 	add	x0, x0, x0, lsl #2
    9940:	d37df001 	lsl	x1, x0, #3
    9944:	8b010060 	add	x0, x3, x1
    9948:	f9401017 	ldr	x23, [x0, #32]
    994c:	b40002b7 	cbz	x23, 99a0 <fwp_main_thread+0x18b0>
    9950:	38616861 	ldrb	w1, [x3, x1]
    9954:	7100083f 	cmp	w1, #0x2
    9958:	54003fe0 	b.eq	a154 <fwp_main_thread+0x2064>  // b.none
    995c:	7100043f 	cmp	w1, #0x1
    9960:	54000201 	b.ne	99a0 <fwp_main_thread+0x18b0>  // b.any
    9964:	29430003 	ldp	w3, w0, [x0, #24]
    9968:	92403c41 	and	x1, x2, #0xffff
    996c:	9b037c21 	mul	x1, x1, x3
    9970:	d360fc21 	lsr	x1, x1, #32
    9974:	eb00003f 	cmp	x1, x0
    9978:	54000142 	b.cs	99a0 <fwp_main_thread+0x18b0>  // b.hs, b.nlast
    997c:	8b0102f7 	add	x23, x23, x1
    9980:	394002e0 	ldrb	w0, [x23]
    9984:	340000e0 	cbz	w0, 99a0 <fwp_main_thread+0x18b0>
    9988:	7100041f 	cmp	w0, #0x1
    998c:	54003100 	b.eq	9fac <fwp_main_thread+0x1ebc>  // b.none
    9990:	7103fc1f 	cmp	w0, #0xff
    9994:	540048e0 	b.eq	a2b0 <fwp_main_thread+0x21c0>  // b.none
    9998:	51000400 	sub	w0, w0, #0x1
    999c:	390002e0 	strb	w0, [x23]
    99a0:	f94027e0 	ldr	x0, [sp, #72]
    99a4:	f9400800 	ldr	x0, [x0, #16]
    99a8:	f90027e0 	str	x0, [sp, #72]
    99ac:	b40030c0 	cbz	x0, 9fc4 <fwp_main_thread+0x1ed4>
    99b0:	9101c260 	add	x0, x19, #0x70
    99b4:	f9419816 	ldr	x22, [x0, #816]
    99b8:	17fffb72 	b	8780 <fwp_main_thread+0x690>
    99bc:	f94002c3 	ldr	x3, [x22]
    99c0:	aa1603e0 	mov	x0, x22
    99c4:	f949ef42 	ldr	x2, [x26, #5080]
    99c8:	f949db41 	ldr	x1, [x26, #5040]
    99cc:	d370bc42 	lsl	x2, x2, #16
    99d0:	cb0102c8 	sub	x8, x22, x1
    99d4:	b7f81e43 	tbnz	x3, #63, 9d9c <fwp_main_thread+0x1cac>
    99d8:	eb08005f 	cmp	x2, x8
    99dc:	54ffeda9 	b.ls	9790 <fwp_main_thread+0x16a0>  // b.plast
    99e0:	d350fd03 	lsr	x3, x8, #16
    99e4:	8b030863 	add	x3, x3, x3, lsl #2
    99e8:	d37df063 	lsl	x3, x3, #3
    99ec:	8b0300a7 	add	x7, x5, x3
    99f0:	f94010e6 	ldr	x6, [x7, #32]
    99f4:	b4ffece6 	cbz	x6, 9790 <fwp_main_thread+0x16a0>
    99f8:	386368a3 	ldrb	w3, [x5, x3]
    99fc:	7100087f 	cmp	w3, #0x2
    9a00:	54002980 	b.eq	9f30 <fwp_main_thread+0x1e40>  // b.none
    9a04:	7100047f 	cmp	w3, #0x1
    9a08:	54ffec41 	b.ne	9790 <fwp_main_thread+0x16a0>  // b.any
    9a0c:	29430ce5 	ldp	w5, w3, [x7, #24]
    9a10:	92403d00 	and	x0, x8, #0xffff
    9a14:	9b057c00 	mul	x0, x0, x5
    9a18:	d360fc00 	lsr	x0, x0, #32
    9a1c:	eb03001f 	cmp	x0, x3
    9a20:	54ffeb82 	b.cs	9790 <fwp_main_thread+0x16a0>  // b.hs, b.nlast
    9a24:	8b0000c6 	add	x6, x6, x0
    9a28:	394000c0 	ldrb	w0, [x6]
    9a2c:	7100041f 	cmp	w0, #0x1
    9a30:	54ffeb01 	b.ne	9790 <fwp_main_thread+0x16a0>  // b.any
    9a34:	aa1603e0 	mov	x0, x22
    9a38:	97ffec42 	bl	4b40 <fwp_mem_free>
    9a3c:	f949ef42 	ldr	x2, [x26, #5080]
    9a40:	f949db41 	ldr	x1, [x26, #5040]
    9a44:	d370bc42 	lsl	x2, x2, #16
    9a48:	17ffff52 	b	9790 <fwp_main_thread+0x16a0>
    9a4c:	aa1903e0 	mov	x0, x25
    9a50:	97ffeb9c 	bl	48c0 <fwp_rc_forget_slot>
    9a54:	17ffff0e 	b	968c <fwp_main_thread+0x159c>
    9a58:	72003c3f 	tst	w1, #0xffff
    9a5c:	54ffe1a1 	b.ne	9690 <fwp_main_thread+0x15a0>  // b.any
    9a60:	17ffff08 	b	9680 <fwp_main_thread+0x1590>
    9a64:	72003c3f 	tst	w1, #0xffff
    9a68:	54ffcd40 	b.eq	9410 <fwp_main_thread+0x1320>  // b.none
    9a6c:	b40010f5 	cbz	x21, 9c88 <fwp_main_thread+0x1b98>
    9a70:	aa1503f7 	mov	x23, x21
    9a74:	d2800018 	mov	x24, #0x0                   	// #0
    9a78:	f9400af7 	ldr	x23, [x23, #16]
    9a7c:	aa1803e0 	mov	x0, x24
    9a80:	91000718 	add	x24, x24, #0x1
    9a84:	b5ffffb7 	cbnz	x23, 9a78 <fwp_main_thread+0x1988>
    9a88:	f90003e5 	str	x5, [sp]
    9a8c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9a90:	eb01031f 	cmp	x24, x1
    9a94:	54004428 	b.hi	a318 <fwp_main_thread+0x2228>  // b.pmore
    9a98:	91000800 	add	x0, x0, #0x2
    9a9c:	52800041 	mov	w1, #0x2                   	// #2
    9aa0:	d37df000 	lsl	x0, x0, #3
    9aa4:	97ffed47 	bl	4fc0 <fwp_heap_alloc>
    9aa8:	f94003e5 	ldr	x5, [sp]
    9aac:	eb1b031f 	cmp	x24, x27
    9ab0:	9a9b931b 	csel	x27, x24, x27, ls	// ls = plast
    9ab4:	aa0003fc 	mov	x28, x0
    9ab8:	aa1503e1 	mov	x1, x21
    9abc:	d503201f 	nop
    9ac0:	f9400420 	ldr	x0, [x1, #8]
    9ac4:	f8377b80 	str	x0, [x28, x23, lsl #3]
    9ac8:	910006f7 	add	x23, x23, #0x1
    9acc:	f9400821 	ldr	x1, [x1, #16]
    9ad0:	b5ffff81 	cbnz	x1, 9ac0 <fwp_main_thread+0x19d0>
    9ad4:	b4000e3b 	cbz	x27, 9c98 <fwp_main_thread+0x1ba8>
    9ad8:	f94000a0 	ldr	x0, [x5]
    9adc:	b90003ff 	str	wzr, [sp]
    9ae0:	17fffe54 	b	9430 <fwp_main_thread+0x1340>
    9ae4:	d53bd040 	mrs	x0, tpidr_el0
    9ae8:	91400000 	add	x0, x0, #0x0, lsl #12
    9aec:	91004000 	add	x0, x0, #0x10
    9af0:	f9400000 	ldr	x0, [x0]
    9af4:	b4001940 	cbz	x0, 9e1c <fwp_main_thread+0x1d2c>
    9af8:	f9401fe1 	ldr	x1, [sp, #56]
    9afc:	97ffe77a 	bl	38e4 <fwp_closure_drop_push>
    9b00:	b5ff7175 	cbnz	x21, 892c <fwp_main_thread+0x83c>
    9b04:	9101c277 	add	x23, x19, #0x70
    9b08:	52800000 	mov	w0, #0x0                   	// #0
    9b0c:	97ffe6d9 	bl	3670 <descent_phase_step>
    9b10:	d2800016 	mov	x22, #0x0                   	// #0
    9b14:	b9436ee0 	ldr	w0, [x23, #876]
    9b18:	35ff7260 	cbnz	w0, 8964 <fwp_main_thread+0x874>
    9b1c:	d503201f 	nop
    9b20:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x40>
    9b24:	913f4000 	add	x0, x0, #0xfd0
    9b28:	940003ee 	bl	aae0 <atexit>
    9b2c:	35ffbd00 	cbnz	w0, 92cc <fwp_main_thread+0x11dc>
    9b30:	52800020 	mov	w0, #0x1                   	// #1
    9b34:	b9036ee0 	str	w0, [x23, #876]
    9b38:	9101c260 	add	x0, x19, #0x70
    9b3c:	f9404817 	ldr	x23, [x0, #144]
    9b40:	f9408401 	ldr	x1, [x0, #264]
    9b44:	eb17003f 	cmp	x1, x23
    9b48:	54ff718b 	b.lt	8978 <fwp_main_thread+0x888>  // b.tstop
    9b4c:	d503201f 	nop
    9b50:	eb0102ff 	cmp	x23, x1
    9b54:	54ff7300 	b.eq	89b4 <fwp_main_thread+0x8c4>  // b.none
    9b58:	aa0103f7 	mov	x23, x1
    9b5c:	9100043c 	add	x28, x1, #0x1
    9b60:	d37ff821 	lsl	x1, x1, #1
    9b64:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    9b68:	f9403a7b 	ldr	x27, [x19, #112]
    9b6c:	8b170021 	add	x1, x1, x23
    9b70:	91380000 	add	x0, x0, #0xe00
    9b74:	8b010ae1 	add	x1, x23, x1, lsl #2
    9b78:	8b010f78 	add	x24, x27, x1, lsl #3
    9b7c:	f900331f 	str	xzr, [x24, #96]
    9b80:	97ffe3c8 	bl	2aa0 <getenv@plt>
    9b84:	b5ff76e0 	cbnz	x0, 8a60 <fwp_main_thread+0x970>
    9b88:	9101c260 	add	x0, x19, #0x70
    9b8c:	f9407801 	ldr	x1, [x0, #240]
    9b90:	b4ff7721 	cbz	x1, 8a74 <fwp_main_thread+0x984>
    9b94:	3ccb8002 	ldur	q2, [x0, #184]
    9b98:	9102e001 	add	x1, x0, #0xb8
    9b9c:	3ccc8001 	ldur	q1, [x0, #200]
    9ba0:	f900781f 	str	xzr, [x0, #240]
    9ba4:	4f000400 	movi	v0.4s, #0x0
    9ba8:	ad010702 	stp	q2, q1, [x24, #32]
    9bac:	f9406c02 	ldr	x2, [x0, #216]
    9bb0:	f9407400 	ldr	x0, [x0, #232]
    9bb4:	a9040302 	stp	x2, x0, [x24, #64]
    9bb8:	f9401422 	ldr	x2, [x1, #40]
    9bbc:	f9000f02 	str	x2, [x24, #24]
    9bc0:	f900183f 	str	xzr, [x1, #48]
    9bc4:	ad000020 	stp	q0, q0, [x1]
    9bc8:	3d800820 	str	q0, [x1, #32]
    9bcc:	17fffbaa 	b	8a74 <fwp_main_thread+0x984>
    9bd0:	72003c1f 	tst	w0, #0xffff
    9bd4:	54ffa5a0 	b.eq	9088 <fwp_main_thread+0xf98>  // b.none
    9bd8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9bdc:	eb00031f 	cmp	x24, x0
    9be0:	54003e88 	b.hi	a3b0 <fwp_main_thread+0x22c0>  // b.pmore
    9be4:	91000700 	add	x0, x24, #0x1
    9be8:	52800021 	mov	w1, #0x1                   	// #1
    9bec:	d37df000 	lsl	x0, x0, #3
    9bf0:	97ffecf4 	bl	4fc0 <fwp_heap_alloc>
    9bf4:	f9000018 	str	x24, [x0]
    9bf8:	aa0003e5 	mov	x5, x0
    9bfc:	aa0003f6 	mov	x22, x0
    9c00:	f949db41 	ldr	x1, [x26, #5040]
    9c04:	f949ef40 	ldr	x0, [x26, #5080]
    9c08:	cb0100a1 	sub	x1, x5, x1
    9c0c:	eb00403f 	cmp	x1, x0, lsl #16
    9c10:	54000322 	b.cs	9c74 <fwp_main_thread+0x1b84>  // b.hs, b.nlast
    9c14:	d350fc20 	lsr	x0, x1, #16
    9c18:	f949ff43 	ldr	x3, [x26, #5112]
    9c1c:	8b000800 	add	x0, x0, x0, lsl #2
    9c20:	d37df002 	lsl	x2, x0, #3
    9c24:	8b020060 	add	x0, x3, x2
    9c28:	f940101b 	ldr	x27, [x0, #32]
    9c2c:	b400025b 	cbz	x27, 9c74 <fwp_main_thread+0x1b84>
    9c30:	38626862 	ldrb	w2, [x3, x2]
    9c34:	7100085f 	cmp	w2, #0x2
    9c38:	54001820 	b.eq	9f3c <fwp_main_thread+0x1e4c>  // b.none
    9c3c:	7100045f 	cmp	w2, #0x1
    9c40:	540001a1 	b.ne	9c74 <fwp_main_thread+0x1b84>  // b.any
    9c44:	29430002 	ldp	w2, w0, [x0, #24]
    9c48:	92403c21 	and	x1, x1, #0xffff
    9c4c:	9b027c21 	mul	x1, x1, x2
    9c50:	d360fc21 	lsr	x1, x1, #32
    9c54:	eb00003f 	cmp	x1, x0
    9c58:	540000e2 	b.cs	9c74 <fwp_main_thread+0x1b84>  // b.hs, b.nlast
    9c5c:	8b01037b 	add	x27, x27, x1
    9c60:	39400360 	ldrb	w0, [x27]
    9c64:	7103fc1f 	cmp	w0, #0xff
    9c68:	54001720 	b.eq	9f4c <fwp_main_thread+0x1e5c>  // b.none
    9c6c:	52800020 	mov	w0, #0x1                   	// #1
    9c70:	39000360 	strb	w0, [x27]
    9c74:	aa1703e0 	mov	x0, x23
    9c78:	17fffd0a 	b	90a0 <fwp_main_thread+0xfb0>
    9c7c:	eb17037f 	cmp	x27, x23
    9c80:	54ffc588 	b.hi	9530 <fwp_main_thread+0x1440>  // b.pmore
    9c84:	17fffe8d 	b	96b8 <fwp_main_thread+0x15c8>
    9c88:	52800041 	mov	w1, #0x2                   	// #2
    9c8c:	d2800100 	mov	x0, #0x8                   	// #8
    9c90:	97ffeccc 	bl	4fc0 <fwp_heap_alloc>
    9c94:	aa0003fc 	mov	x28, x0
    9c98:	aa1503fb 	mov	x27, x21
    9c9c:	d2800018 	mov	x24, #0x0                   	// #0
    9ca0:	17fffe95 	b	96f4 <fwp_main_thread+0x1604>
    9ca4:	52800041 	mov	w1, #0x2                   	// #2
    9ca8:	d2800100 	mov	x0, #0x8                   	// #8
    9cac:	97ffecc5 	bl	4fc0 <fwp_heap_alloc>
    9cb0:	f900001f 	str	xzr, [x0]
    9cb4:	aa0003f8 	mov	x24, x0
    9cb8:	aa0003fb 	mov	x27, x0
    9cbc:	f949db41 	ldr	x1, [x26, #5040]
    9cc0:	f949ef40 	ldr	x0, [x26, #5080]
    9cc4:	cb010301 	sub	x1, x24, x1
    9cc8:	eb00403f 	cmp	x1, x0, lsl #16
    9ccc:	54000122 	b.cs	9cf0 <fwp_main_thread+0x1c00>  // b.hs, b.nlast
    9cd0:	d2800017 	mov	x23, #0x0                   	// #0
    9cd4:	17fffbab 	b	8b80 <fwp_main_thread+0xa90>
    9cd8:	f90007e0 	str	x0, [sp, #8]
    9cdc:	97ffeaf9 	bl	48c0 <fwp_rc_forget_slot>
    9ce0:	f94007e0 	ldr	x0, [sp, #8]
    9ce4:	17fffe22 	b	956c <fwp_main_thread+0x147c>
    9ce8:	b5ff77f7 	cbnz	x23, 8be4 <fwp_main_thread+0xaf4>
    9cec:	d503201f 	nop
    9cf0:	d280001c 	mov	x28, #0x0                   	// #0
    9cf4:	17fffbe2 	b	8c7c <fwp_main_thread+0xb8c>
    9cf8:	72003c3f 	tst	w1, #0xffff
    9cfc:	54ff80a1 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    9d00:	17fffbfb 	b	8cec <fwp_main_thread+0xbfc>
    9d04:	72003c7f 	tst	w3, #0xffff
    9d08:	54ffe9a1 	b.ne	9a3c <fwp_main_thread+0x194c>  // b.any
    9d0c:	17fffe95 	b	9760 <fwp_main_thread+0x1670>
    9d10:	f940077b 	ldr	x27, [x27, #8]
    9d14:	eb03005f 	cmp	x2, x3
    9d18:	54000342 	b.cs	9d80 <fwp_main_thread+0x1c90>  // b.hs, b.nlast
    9d1c:	d350fc46 	lsr	x6, x2, #16
    9d20:	8b0608c6 	add	x6, x6, x6, lsl #2
    9d24:	d37df0c6 	lsl	x6, x6, #3
    9d28:	8b0600a9 	add	x9, x5, x6
    9d2c:	f9401128 	ldr	x8, [x9, #32]
    9d30:	b4000288 	cbz	x8, 9d80 <fwp_main_thread+0x1c90>
    9d34:	386668a5 	ldrb	w5, [x5, x6]
    9d38:	710008bf 	cmp	w5, #0x2
    9d3c:	54001620 	b.eq	a000 <fwp_main_thread+0x1f10>  // b.none
    9d40:	710004bf 	cmp	w5, #0x1
    9d44:	540001e1 	b.ne	9d80 <fwp_main_thread+0x1c90>  // b.any
    9d48:	29431526 	ldp	w6, w5, [x9, #24]
    9d4c:	92403c42 	and	x2, x2, #0xffff
    9d50:	9b067c42 	mul	x2, x2, x6
    9d54:	d360fc42 	lsr	x2, x2, #32
    9d58:	eb05005f 	cmp	x2, x5
    9d5c:	54000122 	b.cs	9d80 <fwp_main_thread+0x1c90>  // b.hs, b.nlast
    9d60:	8b020108 	add	x8, x8, x2
    9d64:	39400102 	ldrb	w2, [x8]
    9d68:	7100045f 	cmp	w2, #0x1
    9d6c:	540000a1 	b.ne	9d80 <fwp_main_thread+0x1c90>  // b.any
    9d70:	97ffeb74 	bl	4b40 <fwp_mem_free>
    9d74:	f949ef43 	ldr	x3, [x26, #5080]
    9d78:	f949db41 	ldr	x1, [x26, #5040]
    9d7c:	d370bc63 	lsl	x3, x3, #16
    9d80:	cb010361 	sub	x1, x27, x1
    9d84:	eb01007f 	cmp	x3, x1
    9d88:	54ff78c8 	b.hi	8ca0 <fwp_main_thread+0xbb0>  // b.pmore
    9d8c:	17fffbe1 	b	8d10 <fwp_main_thread+0xc20>
    9d90:	72003c3f 	tst	w1, #0xffff
    9d94:	54ffd3a1 	b.ne	9808 <fwp_main_thread+0x1718>  // b.any
    9d98:	17fffe94 	b	97e8 <fwp_main_thread+0x16f8>
    9d9c:	f94006d6 	ldr	x22, [x22, #8]
    9da0:	eb08005f 	cmp	x2, x8
    9da4:	54000349 	b.ls	9e0c <fwp_main_thread+0x1d1c>  // b.plast
    9da8:	d350fd03 	lsr	x3, x8, #16
    9dac:	8b030863 	add	x3, x3, x3, lsl #2
    9db0:	d37df063 	lsl	x3, x3, #3
    9db4:	8b0300a7 	add	x7, x5, x3
    9db8:	f94010e6 	ldr	x6, [x7, #32]
    9dbc:	b4000286 	cbz	x6, 9e0c <fwp_main_thread+0x1d1c>
    9dc0:	386368a3 	ldrb	w3, [x5, x3]
    9dc4:	7100087f 	cmp	w3, #0x2
    9dc8:	54001160 	b.eq	9ff4 <fwp_main_thread+0x1f04>  // b.none
    9dcc:	7100047f 	cmp	w3, #0x1
    9dd0:	540001e1 	b.ne	9e0c <fwp_main_thread+0x1d1c>  // b.any
    9dd4:	294314e9 	ldp	w9, w5, [x7, #24]
    9dd8:	92403d03 	and	x3, x8, #0xffff
    9ddc:	9b097c63 	mul	x3, x3, x9
    9de0:	d360fc63 	lsr	x3, x3, #32
    9de4:	eb05007f 	cmp	x3, x5
    9de8:	54000122 	b.cs	9e0c <fwp_main_thread+0x1d1c>  // b.hs, b.nlast
    9dec:	8b0300c6 	add	x6, x6, x3
    9df0:	394000c3 	ldrb	w3, [x6]
    9df4:	7100047f 	cmp	w3, #0x1
    9df8:	540000a1 	b.ne	9e0c <fwp_main_thread+0x1d1c>  // b.any
    9dfc:	97ffeb51 	bl	4b40 <fwp_mem_free>
    9e00:	f949ef42 	ldr	x2, [x26, #5080]
    9e04:	f949db41 	ldr	x1, [x26, #5040]
    9e08:	d370bc42 	lsl	x2, x2, #16
    9e0c:	cb0102c3 	sub	x3, x22, x1
    9e10:	eb03005f 	cmp	x2, x3
    9e14:	54ffc808 	b.hi	9714 <fwp_main_thread+0x1624>  // b.pmore
    9e18:	17fffe5e 	b	9790 <fwp_main_thread+0x16a0>
    9e1c:	f9401fe0 	ldr	x0, [sp, #56]
    9e20:	97ffe720 	bl	3aa0 <fwp_closure_drop.part.0>
    9e24:	17fffac1 	b	8928 <fwp_main_thread+0x838>
    9e28:	72003c7f 	tst	w3, #0xffff
    9e2c:	54ff5541 	b.ne	88d4 <fwp_main_thread+0x7e4>  // b.any
    9e30:	aa1603e0 	mov	x0, x22
    9e34:	17fffa96 	b	888c <fwp_main_thread+0x79c>
    9e38:	72003c7f 	tst	w3, #0xffff
    9e3c:	54ff5761 	b.ne	8928 <fwp_main_thread+0x838>  // b.any
    9e40:	17fffab1 	b	8904 <fwp_main_thread+0x814>
    9e44:	72003c3f 	tst	w1, #0xffff
    9e48:	54ff6cc1 	b.ne	8be0 <fwp_main_thread+0xaf0>  // b.any
    9e4c:	39400380 	ldrb	w0, [x28]
    9e50:	7103fc1f 	cmp	w0, #0xff
    9e54:	54ff6c21 	b.ne	8bd8 <fwp_main_thread+0xae8>  // b.any
    9e58:	aa1c03e0 	mov	x0, x28
    9e5c:	97ffea99 	bl	48c0 <fwp_rc_forget_slot>
    9e60:	17fffb5e 	b	8bd8 <fwp_main_thread+0xae8>
    9e64:	aa1903f6 	mov	x22, x25
    9e68:	17fffbe6 	b	8e00 <fwp_main_thread+0xd10>
    9e6c:	72003c3f 	tst	w1, #0xffff
    9e70:	54ff8c61 	b.ne	8ffc <fwp_main_thread+0xf0c>  // b.any
    9e74:	394002c0 	ldrb	w0, [x22]
    9e78:	7103fc1f 	cmp	w0, #0xff
    9e7c:	54ff8bc1 	b.ne	8ff4 <fwp_main_thread+0xf04>  // b.any
    9e80:	aa1603e0 	mov	x0, x22
    9e84:	97ffea8f 	bl	48c0 <fwp_rc_forget_slot>
    9e88:	17fffc5b 	b	8ff4 <fwp_main_thread+0xf04>
    9e8c:	72003c5f 	tst	w2, #0xffff
    9e90:	54ff7401 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    9e94:	17fffd35 	b	9368 <fwp_main_thread+0x1278>
    9e98:	f949ef45 	ldr	x5, [x26, #5080]
    9e9c:	f949db41 	ldr	x1, [x26, #5040]
    9ea0:	d370bca5 	lsl	x5, x5, #16
    9ea4:	cb010360 	sub	x0, x27, x1
    9ea8:	f9400b76 	ldr	x22, [x27, #16]
    9eac:	eb05001f 	cmp	x0, x5
    9eb0:	54000362 	b.cs	9f1c <fwp_main_thread+0x1e2c>  // b.hs, b.nlast
    9eb4:	d350fc02 	lsr	x2, x0, #16
    9eb8:	8b020842 	add	x2, x2, x2, lsl #2
    9ebc:	d37df042 	lsl	x2, x2, #3
    9ec0:	8b020067 	add	x7, x3, x2
    9ec4:	f94010e6 	ldr	x6, [x7, #32]
    9ec8:	b40002a6 	cbz	x6, 9f1c <fwp_main_thread+0x1e2c>
    9ecc:	38626862 	ldrb	w2, [x3, x2]
    9ed0:	7100085f 	cmp	w2, #0x2
    9ed4:	540009c0 	b.eq	a00c <fwp_main_thread+0x1f1c>  // b.none
    9ed8:	7100045f 	cmp	w2, #0x1
    9edc:	54000201 	b.ne	9f1c <fwp_main_thread+0x1e2c>  // b.any
    9ee0:	294308e3 	ldp	w3, w2, [x7, #24]
    9ee4:	92403c00 	and	x0, x0, #0xffff
    9ee8:	9b037c00 	mul	x0, x0, x3
    9eec:	d360fc00 	lsr	x0, x0, #32
    9ef0:	eb02001f 	cmp	x0, x2
    9ef4:	54000142 	b.cs	9f1c <fwp_main_thread+0x1e2c>  // b.hs, b.nlast
    9ef8:	8b0000c6 	add	x6, x6, x0
    9efc:	394000c0 	ldrb	w0, [x6]
    9f00:	7100041f 	cmp	w0, #0x1
    9f04:	540000c1 	b.ne	9f1c <fwp_main_thread+0x1e2c>  // b.any
    9f08:	aa1b03e0 	mov	x0, x27
    9f0c:	97ffeb0d 	bl	4b40 <fwp_mem_free>
    9f10:	f949ef45 	ldr	x5, [x26, #5080]
    9f14:	f949db41 	ldr	x1, [x26, #5040]
    9f18:	d370bca5 	lsl	x5, x5, #16
    9f1c:	cb0102c1 	sub	x1, x22, x1
    9f20:	eb0100bf 	cmp	x5, x1
    9f24:	54ffc729 	b.ls	9808 <fwp_main_thread+0x1718>  // b.plast
    9f28:	aa1603fb 	mov	x27, x22
    9f2c:	17fffe1c 	b	979c <fwp_main_thread+0x16ac>
    9f30:	72003d1f 	tst	w8, #0xffff
    9f34:	54ffc2e1 	b.ne	9790 <fwp_main_thread+0x16a0>  // b.any
    9f38:	17fffebc 	b	9a28 <fwp_main_thread+0x1938>
    9f3c:	72003c3f 	tst	w1, #0xffff
    9f40:	54ffe900 	b.eq	9c60 <fwp_main_thread+0x1b70>  // b.none
    9f44:	aa1703e0 	mov	x0, x23
    9f48:	17fffc56 	b	90a0 <fwp_main_thread+0xfb0>
    9f4c:	aa1b03e0 	mov	x0, x27
    9f50:	f90003e5 	str	x5, [sp]
    9f54:	97ffea5b 	bl	48c0 <fwp_rc_forget_slot>
    9f58:	f94003e5 	ldr	x5, [sp]
    9f5c:	17ffff44 	b	9c6c <fwp_main_thread+0x1b7c>
    9f60:	aa0203e0 	mov	x0, x2
    9f64:	d2800101 	mov	x1, #0x8                   	// #8
    9f68:	f90023e2 	str	x2, [sp, #64]
    9f6c:	97ffe261 	bl	28f0 <calloc@plt>
    9f70:	f94023e2 	ldr	x2, [sp, #64]
    9f74:	aa0003fb 	mov	x27, x0
    9f78:	17fffbb4 	b	8e48 <fwp_main_thread+0xd58>
    9f7c:	d2800d01 	mov	x1, #0x68                  	// #104
    9f80:	d2800038 	mov	x24, #0x1                   	// #1
    9f84:	17fffa9c 	b	89f4 <fwp_main_thread+0x904>
    9f88:	f94000a0 	ldr	x0, [x5]
    9f8c:	b7ffe7e0 	tbnz	x0, #63, 9c88 <fwp_main_thread+0x1b98>
    9f90:	f949db41 	ldr	x1, [x26, #5040]
    9f94:	f949ef43 	ldr	x3, [x26, #5080]
    9f98:	cb0102c1 	sub	x1, x22, x1
    9f9c:	eb03403f 	cmp	x1, x3, lsl #16
    9fa0:	54ffe742 	b.cs	9c88 <fwp_main_thread+0x1b98>  // b.hs, b.nlast
    9fa4:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    9fa8:	17fffd07 	b	93c4 <fwp_main_thread+0x12d4>
    9fac:	aa1603e0 	mov	x0, x22
    9fb0:	97ffede9 	bl	5754 <fwp_rc_free_arr>
    9fb4:	f94027e0 	ldr	x0, [sp, #72]
    9fb8:	f9400800 	ldr	x0, [x0, #16]
    9fbc:	f90027e0 	str	x0, [sp, #72]
    9fc0:	b5ffcf80 	cbnz	x0, 99b0 <fwp_main_thread+0x18c0>
    9fc4:	aa1503e0 	mov	x0, x21
    9fc8:	97ffef0e 	bl	5c00 <fwp_drop0>
    9fcc:	f9400fe0 	ldr	x0, [sp, #24]
    9fd0:	97ffef0c 	bl	5c00 <fwp_drop0>
    9fd4:	9101c260 	add	x0, x19, #0x70
    9fd8:	52800021 	mov	w1, #0x1                   	// #1
    9fdc:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    9fe0:	a95e73fb 	ldp	x27, x28, [sp, #480]
    9fe4:	6d5f27e8 	ldp	d8, d9, [sp, #496]
    9fe8:	b9036801 	str	w1, [x0, #872]
    9fec:	f901b81f 	str	xzr, [x0, #880]
    9ff0:	17fff883 	b	81fc <fwp_main_thread+0x10c>
    9ff4:	72003d1f 	tst	w8, #0xffff
    9ff8:	54fff0a1 	b.ne	9e0c <fwp_main_thread+0x1d1c>  // b.any
    9ffc:	17ffff7d 	b	9df0 <fwp_main_thread+0x1d00>
    a000:	72003c5f 	tst	w2, #0xffff
    a004:	54ffebe1 	b.ne	9d80 <fwp_main_thread+0x1c90>  // b.any
    a008:	17ffff57 	b	9d64 <fwp_main_thread+0x1c74>
    a00c:	72003c1f 	tst	w0, #0xffff
    a010:	54fff861 	b.ne	9f1c <fwp_main_thread+0x1e2c>  // b.any
    a014:	17ffffba 	b	9efc <fwp_main_thread+0x1e0c>
    a018:	72003c5f 	tst	w2, #0xffff
    a01c:	54ff3f61 	b.ne	8808 <fwp_main_thread+0x718>  // b.any
    a020:	17fff9f1 	b	87e4 <fwp_main_thread+0x6f4>
    a024:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a028:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a02c:	9117c021 	add	x1, x1, #0x5f0
    a030:	ca402400 	eor	x0, x0, x0, lsr #9
    a034:	8b200c20 	add	x0, x1, w0, uxtb #3
    a038:	f94a2401 	ldr	x1, [x0, #5192]
    a03c:	b5000081 	cbnz	x1, a04c <fwp_main_thread+0x1f5c>
    a040:	14000011 	b	a084 <fwp_main_thread+0x1f94>
    a044:	f9400821 	ldr	x1, [x1, #16]
    a048:	b40001e1 	cbz	x1, a084 <fwp_main_thread+0x1f94>
    a04c:	f9400020 	ldr	x0, [x1]
    a050:	eb0002ff 	cmp	x23, x0
    a054:	54ffff81 	b.ne	a044 <fwp_main_thread+0x1f54>  // b.any
    a058:	f9400420 	ldr	x0, [x1, #8]
    a05c:	d1000400 	sub	x0, x0, #0x1
    a060:	f9000420 	str	x0, [x1, #8]
    a064:	f103f81f 	cmp	x0, #0xfe
    a068:	54000f60 	b.eq	a254 <fwp_main_thread+0x2164>  // b.none
    a06c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a070:	9117c000 	add	x0, x0, #0x5f0
    a074:	f949ec02 	ldr	x2, [x0, #5080]
    a078:	f949d801 	ldr	x1, [x0, #5040]
    a07c:	d370bc42 	lsl	x2, x2, #16
    a080:	17fffdc4 	b	9790 <fwp_main_thread+0x16a0>
    a084:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    a088:	9139c000 	add	x0, x0, #0xe70
    a08c:	97ffe5fd 	bl	3880 <fwp_trap>
    a090:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a094:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a098:	9117c021 	add	x1, x1, #0x5f0
    a09c:	ca402400 	eor	x0, x0, x0, lsr #9
    a0a0:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0a4:	f94a2400 	ldr	x0, [x0, #5192]
    a0a8:	b5000080 	cbnz	x0, a0b8 <fwp_main_thread+0x1fc8>
    a0ac:	17fffff6 	b	a084 <fwp_main_thread+0x1f94>
    a0b0:	f9400800 	ldr	x0, [x0, #16]
    a0b4:	b4fffe80 	cbz	x0, a084 <fwp_main_thread+0x1f94>
    a0b8:	f9400001 	ldr	x1, [x0]
    a0bc:	eb17003f 	cmp	x1, x23
    a0c0:	54ffff81 	b.ne	a0b0 <fwp_main_thread+0x1fc0>  // b.any
    a0c4:	f9400401 	ldr	x1, [x0, #8]
    a0c8:	d1000421 	sub	x1, x1, #0x1
    a0cc:	f9000401 	str	x1, [x0, #8]
    a0d0:	f103f83f 	cmp	x1, #0xfe
    a0d4:	54ff61e1 	b.ne	8d10 <fwp_main_thread+0xc20>  // b.any
    a0d8:	aa1703e0 	mov	x0, x23
    a0dc:	97ffe9f9 	bl	48c0 <fwp_rc_forget_slot>
    a0e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0e4:	390002e0 	strb	w0, [x23]
    a0e8:	17fffb0a 	b	8d10 <fwp_main_thread+0xc20>
    a0ec:	72003c5f 	tst	w2, #0xffff
    a0f0:	54ffc021 	b.ne	98f4 <fwp_main_thread+0x1804>  // b.any
    a0f4:	17fffdfb 	b	98e0 <fwp_main_thread+0x17f0>
    a0f8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a0fc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a100:	9117c021 	add	x1, x1, #0x5f0
    a104:	ca402400 	eor	x0, x0, x0, lsr #9
    a108:	8b200c20 	add	x0, x1, w0, uxtb #3
    a10c:	f94a2401 	ldr	x1, [x0, #5192]
    a110:	b5000081 	cbnz	x1, a120 <fwp_main_thread+0x2030>
    a114:	17ffffdc 	b	a084 <fwp_main_thread+0x1f94>
    a118:	f9400821 	ldr	x1, [x1, #16]
    a11c:	b4fffb41 	cbz	x1, a084 <fwp_main_thread+0x1f94>
    a120:	f9400020 	ldr	x0, [x1]
    a124:	eb16001f 	cmp	x0, x22
    a128:	54ffff81 	b.ne	a118 <fwp_main_thread+0x2028>  // b.any
    a12c:	f9400420 	ldr	x0, [x1, #8]
    a130:	d1000400 	sub	x0, x0, #0x1
    a134:	f9000420 	str	x0, [x1, #8]
    a138:	f103f81f 	cmp	x0, #0xfe
    a13c:	54ffb661 	b.ne	9808 <fwp_main_thread+0x1718>  // b.any
    a140:	aa1603e0 	mov	x0, x22
    a144:	97ffe9df 	bl	48c0 <fwp_rc_forget_slot>
    a148:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a14c:	390002c0 	strb	w0, [x22]
    a150:	17fffdae 	b	9808 <fwp_main_thread+0x1718>
    a154:	72003c5f 	tst	w2, #0xffff
    a158:	54ffc241 	b.ne	99a0 <fwp_main_thread+0x18b0>  // b.any
    a15c:	17fffe09 	b	9980 <fwp_main_thread+0x1890>
    a160:	aa1503fb 	mov	x27, x21
    a164:	d280001c 	mov	x28, #0x0                   	// #0
    a168:	d2800018 	mov	x24, #0x0                   	// #0
    a16c:	17fffd62 	b	96f4 <fwp_main_thread+0x1604>
    a170:	97ffe98d 	bl	47a4 <fwp_rc_wide_dup>
    a174:	17fff9cc 	b	88a4 <fwp_main_thread+0x7b4>
    a178:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a17c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a180:	9117c021 	add	x1, x1, #0x5f0
    a184:	ca402400 	eor	x0, x0, x0, lsr #9
    a188:	8b200c20 	add	x0, x1, w0, uxtb #3
    a18c:	f94a2400 	ldr	x0, [x0, #5192]
    a190:	b5000080 	cbnz	x0, a1a0 <fwp_main_thread+0x20b0>
    a194:	17ffffbc 	b	a084 <fwp_main_thread+0x1f94>
    a198:	f9400800 	ldr	x0, [x0, #16]
    a19c:	b4fff740 	cbz	x0, a084 <fwp_main_thread+0x1f94>
    a1a0:	f9400001 	ldr	x1, [x0]
    a1a4:	eb16003f 	cmp	x1, x22
    a1a8:	54ffff81 	b.ne	a198 <fwp_main_thread+0x20a8>  // b.any
    a1ac:	f9400401 	ldr	x1, [x0, #8]
    a1b0:	d1000421 	sub	x1, x1, #0x1
    a1b4:	f9000401 	str	x1, [x0, #8]
    a1b8:	f103f83f 	cmp	x1, #0xfe
    a1bc:	54ff3b61 	b.ne	8928 <fwp_main_thread+0x838>  // b.any
    a1c0:	aa1603e0 	mov	x0, x22
    a1c4:	97ffe9bf 	bl	48c0 <fwp_rc_forget_slot>
    a1c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a1cc:	390002c0 	strb	w0, [x22]
    a1d0:	17fff9d6 	b	8928 <fwp_main_thread+0x838>
    a1d4:	72003c3f 	tst	w1, #0xffff
    a1d8:	54ff21e1 	b.ne	8614 <fwp_main_thread+0x524>  // b.any
    a1dc:	17fff909 	b	8600 <fwp_main_thread+0x510>
    a1e0:	72003c3f 	tst	w1, #0xffff
    a1e4:	54ff2ae1 	b.ne	8740 <fwp_main_thread+0x650>  // b.any
    a1e8:	17fff951 	b	872c <fwp_main_thread+0x63c>
    a1ec:	72003c3f 	tst	w1, #0xffff
    a1f0:	54ff25c1 	b.ne	86a8 <fwp_main_thread+0x5b8>  // b.any
    a1f4:	17fff928 	b	8694 <fwp_main_thread+0x5a4>
    a1f8:	aa0003e1 	mov	x1, x0
    a1fc:	f90022b4 	str	x20, [x21, #64]
    a200:	17fff818 	b	8260 <fwp_main_thread+0x170>
    a204:	d2800017 	mov	x23, #0x0                   	// #0
    a208:	17fffcca 	b	9530 <fwp_main_thread+0x1440>
    a20c:	aa1703e0 	mov	x0, x23
    a210:	97ffe9ac 	bl	48c0 <fwp_rc_forget_slot>
    a214:	17fffdb6 	b	98ec <fwp_main_thread+0x17fc>
    a218:	f941a2a0 	ldr	x0, [x21, #832]
    a21c:	97ffea49 	bl	4b40 <fwp_mem_free>
    a220:	f901a2bf 	str	xzr, [x21, #832]
    a224:	f901aabf 	str	xzr, [x21, #848]
    a228:	f941c2a0 	ldr	x0, [x21, #896]
    a22c:	b40007d4 	cbz	x20, a324 <fwp_main_thread+0x2234>
    a230:	f900569f 	str	xzr, [x20, #168]
    a234:	f9005e9f 	str	xzr, [x20, #184]
    a238:	b9037abf 	str	wzr, [x21, #888]
    a23c:	eb14001f 	cmp	x0, x20
    a240:	54ff0700 	b.eq	8320 <fwp_main_thread+0x230>  // b.none
    a244:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a248:	a91e73fb 	stp	x27, x28, [sp, #480]
    a24c:	6d1f27e8 	stp	d8, d9, [sp, #496]
    a250:	97ffe1c4 	bl	2960 <abort@plt>
    a254:	aa1703e0 	mov	x0, x23
    a258:	97ffe99a 	bl	48c0 <fwp_rc_forget_slot>
    a25c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a260:	9117c000 	add	x0, x0, #0x5f0
    a264:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a268:	390002e1 	strb	w1, [x23]
    a26c:	f949ec02 	ldr	x2, [x0, #5080]
    a270:	f949d801 	ldr	x1, [x0, #5040]
    a274:	d370bc42 	lsl	x2, x2, #16
    a278:	17fffd46 	b	9790 <fwp_main_thread+0x16a0>
    a27c:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    a280:	913d4000 	add	x0, x0, #0xf50
    a284:	97ffe57f 	bl	3880 <fwp_trap>
    a288:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    a28c:	913ae000 	add	x0, x0, #0xeb8
    a290:	97ffe57c 	bl	3880 <fwp_trap>
    a294:	97ffe944 	bl	47a4 <fwp_rc_wide_dup>
    a298:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xbf0>
    a29c:	9117c000 	add	x0, x0, #0x5f0
    a2a0:	f949ec06 	ldr	x6, [x0, #5080]
    a2a4:	f949d803 	ldr	x3, [x0, #5040]
    a2a8:	d370bcc6 	lsl	x6, x6, #16
    a2ac:	17fff957 	b	8808 <fwp_main_thread+0x718>
    a2b0:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a2b4:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xbf0>
    a2b8:	9117c021 	add	x1, x1, #0x5f0
    a2bc:	ca402400 	eor	x0, x0, x0, lsr #9
    a2c0:	8b200c20 	add	x0, x1, w0, uxtb #3
    a2c4:	f94a2400 	ldr	x0, [x0, #5192]
    a2c8:	b5000080 	cbnz	x0, a2d8 <fwp_main_thread+0x21e8>
    a2cc:	17ffff6e 	b	a084 <fwp_main_thread+0x1f94>
    a2d0:	f9400800 	ldr	x0, [x0, #16]
    a2d4:	b4ffed80 	cbz	x0, a084 <fwp_main_thread+0x1f94>
    a2d8:	f9400001 	ldr	x1, [x0]
    a2dc:	eb0102ff 	cmp	x23, x1
    a2e0:	54ffff81 	b.ne	a2d0 <fwp_main_thread+0x21e0>  // b.any
    a2e4:	f9400401 	ldr	x1, [x0, #8]
    a2e8:	d1000421 	sub	x1, x1, #0x1
    a2ec:	f9000401 	str	x1, [x0, #8]
    a2f0:	f103f83f 	cmp	x1, #0xfe
    a2f4:	54ffb561 	b.ne	99a0 <fwp_main_thread+0x18b0>  // b.any
    a2f8:	aa1703e0 	mov	x0, x23
    a2fc:	97ffe971 	bl	48c0 <fwp_rc_forget_slot>
    a300:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a304:	390002e0 	strb	w0, [x23]
    a308:	17fffda6 	b	99a0 <fwp_main_thread+0x18b0>
    a30c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a310:	9104e000 	add	x0, x0, #0x138
    a314:	97ffe55b 	bl	3880 <fwp_trap>
    a318:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    a31c:	913ec000 	add	x0, x0, #0xfb0
    a320:	97ffe558 	bl	3880 <fwp_trap>
    a324:	b9037abf 	str	wzr, [x21, #888]
    a328:	b4ff6ea0 	cbz	x0, 90fc <fwp_main_thread+0x100c>
    a32c:	17ffffc6 	b	a244 <fwp_main_thread+0x2154>
    a330:	aa1503e0 	mov	x0, x21
    a334:	97ffe963 	bl	48c0 <fwp_rc_forget_slot>
    a338:	17fff8b5 	b	860c <fwp_main_thread+0x51c>
    a33c:	aa1503e0 	mov	x0, x21
    a340:	97ffe960 	bl	48c0 <fwp_rc_forget_slot>
    a344:	17fff8d7 	b	86a0 <fwp_main_thread+0x5b0>
    a348:	aa1703e0 	mov	x0, x23
    a34c:	97ffe95d 	bl	48c0 <fwp_rc_forget_slot>
    a350:	17fff8fa 	b	8738 <fwp_main_thread+0x648>
    a354:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a358:	9105e000 	add	x0, x0, #0x178
    a35c:	97ffe549 	bl	3880 <fwp_trap>
    a360:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a364:	91058000 	add	x0, x0, #0x160
    a368:	97ffe546 	bl	3880 <fwp_trap>
    a36c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a370:	9102c000 	add	x0, x0, #0xb0
    a374:	a91c63f7 	stp	x23, x24, [sp, #448]
    a378:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a37c:	a91e73fb 	stp	x27, x28, [sp, #480]
    a380:	6d1f27e8 	stp	d8, d9, [sp, #496]
    a384:	97ffe53f 	bl	3880 <fwp_trap>
    a388:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a38c:	a91e73fb 	stp	x27, x28, [sp, #480]
    a390:	6d1f27e8 	stp	d8, d9, [sp, #496]
    a394:	97ffe387 	bl	31b0 <descent_phase_fail>
    a398:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a39c:	a91e73fb 	stp	x27, x28, [sp, #480]
    a3a0:	6d1f27e8 	stp	d8, d9, [sp, #496]
    a3a4:	97ffe15b 	bl	2910 <__stack_chk_fail@plt>
    a3a8:	52800020 	mov	w0, #0x1                   	// #1
    a3ac:	17fffbc0 	b	92ac <fwp_main_thread+0x11bc>
    a3b0:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a3b4:	9104a000 	add	x0, x0, #0x128
    a3b8:	97ffe532 	bl	3880 <fwp_trap>
    a3bc:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1f10>
    a3c0:	913c0000 	add	x0, x0, #0xf00
    a3c4:	97ffe52f 	bl	3880 <fwp_trap>
    a3c8:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a3cc:	91036000 	add	x0, x0, #0xd8
    a3d0:	97ffe52c 	bl	3880 <fwp_trap>
    a3d4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x4f0>
    a3d8:	9103e000 	add	x0, x0, #0xf8
    a3dc:	97ffe529 	bl	3880 <fwp_trap>
    a3e0:	97ffe1c8 	bl	2b00 <fwp_trap_overflow.constprop.0>
    a3e4:	d503201f 	nop
    a3e8:	d503201f 	nop
    a3ec:	d503201f 	nop

000000000000a3f0 <__divti3>:
    a3f0:	d503245f 	bti	c
    a3f4:	d2800004 	mov	x4, #0x0                   	// #0
    a3f8:	b7f80721 	tbnz	x1, #63, a4dc <__divti3+0xec>
    a3fc:	b6f80083 	tbz	x3, #63, a40c <__divti3+0x1c>
    a400:	eb0203e2 	negs	x2, x2
    a404:	aa2403e4 	mvn	x4, x4
    a408:	da0303e3 	ngc	x3, x3
    a40c:	aa0203e6 	mov	x6, x2
    a410:	aa0003e7 	mov	x7, x0
    a414:	aa0103e5 	mov	x5, x1
    a418:	b5000583 	cbnz	x3, a4c8 <__divti3+0xd8>
    a41c:	eb01005f 	cmp	x2, x1
    a420:	54000e69 	b.ls	a5ec <__divti3+0x1fc>  // b.plast
    a424:	dac01040 	clz	x0, x2
    a428:	b40000e0 	cbz	x0, a444 <__divti3+0x54>
    a42c:	4b0003e1 	neg	w1, w0
    a430:	9ac020a5 	lsl	x5, x5, x0
    a434:	9ac02046 	lsl	x6, x2, x0
    a438:	9ac124e1 	lsr	x1, x7, x1
    a43c:	aa050025 	orr	x5, x1, x5
    a440:	9ac020e7 	lsl	x7, x7, x0
    a444:	d360fcc8 	lsr	x8, x6, #32
    a448:	92407cc2 	and	x2, x6, #0xffffffff
    a44c:	9ac808a3 	udiv	x3, x5, x8
    a450:	9b089465 	msub	x5, x3, x8, x5
    a454:	aa0303e0 	mov	x0, x3
    a458:	9b037c41 	mul	x1, x2, x3
    a45c:	93c780a5 	extr	x5, x5, x7, #32
    a460:	eb05003f 	cmp	x1, x5
    a464:	540000a9 	b.ls	a478 <__divti3+0x88>  // b.plast
    a468:	ab0500c5 	adds	x5, x6, x5
    a46c:	d1000460 	sub	x0, x3, #0x1
    a470:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a474:	540015a8 	b.hi	a728 <__divti3+0x338>  // b.pmore
    a478:	cb0100a5 	sub	x5, x5, x1
    a47c:	9ac808a3 	udiv	x3, x5, x8
    a480:	9b089465 	msub	x5, x3, x8, x5
    a484:	aa0303e1 	mov	x1, x3
    a488:	9b037c42 	mul	x2, x2, x3
    a48c:	aa0703e3 	mov	x3, x7
    a490:	b3607ca3 	bfi	x3, x5, #32, #32
    a494:	eb03005f 	cmp	x2, x3
    a498:	540000c9 	b.ls	a4b0 <__divti3+0xc0>  // b.plast
    a49c:	ab0300c3 	adds	x3, x6, x3
    a4a0:	d1000425 	sub	x5, x1, #0x1
    a4a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a4a8:	d1000821 	sub	x1, x1, #0x2
    a4ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a4b0:	aa008020 	orr	x0, x1, x0, lsl #32
    a4b4:	d2800001 	mov	x1, #0x0                   	// #0
    a4b8:	b4000064 	cbz	x4, a4c4 <__divti3+0xd4>
    a4bc:	eb0003e0 	negs	x0, x0
    a4c0:	da0103e1 	ngc	x1, x1
    a4c4:	d65f03c0 	ret
    a4c8:	eb01007f 	cmp	x3, x1
    a4cc:	54000109 	b.ls	a4ec <__divti3+0xfc>  // b.plast
    a4d0:	d2800001 	mov	x1, #0x0                   	// #0
    a4d4:	d2800000 	mov	x0, #0x0                   	// #0
    a4d8:	17fffff8 	b	a4b8 <__divti3+0xc8>
    a4dc:	eb0003e0 	negs	x0, x0
    a4e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a4e4:	da0103e1 	ngc	x1, x1
    a4e8:	17ffffc5 	b	a3fc <__divti3+0xc>
    a4ec:	dac01067 	clz	x7, x3
    a4f0:	b40010e7 	cbz	x7, a70c <__divti3+0x31c>
    a4f4:	d2800805 	mov	x5, #0x40                  	// #64
    a4f8:	cb0700a5 	sub	x5, x5, x7
    a4fc:	9ac72063 	lsl	x3, x3, x7
    a500:	9ac52448 	lsr	x8, x2, x5
    a504:	aa030108 	orr	x8, x8, x3
    a508:	9ac52426 	lsr	x6, x1, x5
    a50c:	92407d0a 	and	x10, x8, #0xffffffff
    a510:	d360fd09 	lsr	x9, x8, #32
    a514:	9ac52403 	lsr	x3, x0, x5
    a518:	9ac72021 	lsl	x1, x1, x7
    a51c:	aa010063 	orr	x3, x3, x1
    a520:	9ac72042 	lsl	x2, x2, x7
    a524:	9ac908cb 	udiv	x11, x6, x9
    a528:	9b099965 	msub	x5, x11, x9, x6
    a52c:	aa0b03e1 	mov	x1, x11
    a530:	9b0b7d46 	mul	x6, x10, x11
    a534:	93c380a5 	extr	x5, x5, x3, #32
    a538:	eb0500df 	cmp	x6, x5
    a53c:	540000a9 	b.ls	a550 <__divti3+0x160>  // b.plast
    a540:	ab050105 	adds	x5, x8, x5
    a544:	d1000561 	sub	x1, x11, #0x1
    a548:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a54c:	54000f48 	b.hi	a734 <__divti3+0x344>  // b.pmore
    a550:	cb0600a6 	sub	x6, x5, x6
    a554:	9ac908cb 	udiv	x11, x6, x9
    a558:	9b099969 	msub	x9, x11, x9, x6
    a55c:	aa0b03e5 	mov	x5, x11
    a560:	9b0b7d4a 	mul	x10, x10, x11
    a564:	b3607d23 	bfi	x3, x9, #32, #32
    a568:	eb03015f 	cmp	x10, x3
    a56c:	540000a9 	b.ls	a580 <__divti3+0x190>  // b.plast
    a570:	ab030103 	adds	x3, x8, x3
    a574:	d1000565 	sub	x5, x11, #0x1
    a578:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a57c:	54000e28 	b.hi	a740 <__divti3+0x350>  // b.pmore
    a580:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a584:	92407c48 	and	x8, x2, #0xffffffff
    a588:	2a0503e5 	mov	w5, w5
    a58c:	d360fc42 	lsr	x2, x2, #32
    a590:	d360fc26 	lsr	x6, x1, #32
    a594:	cb0a0063 	sub	x3, x3, x10
    a598:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a59c:	9b087caa 	mul	x10, x5, x8
    a5a0:	9b087cc8 	mul	x8, x6, x8
    a5a4:	9b0220a5 	madd	x5, x5, x2, x8
    a5a8:	9b027cc6 	mul	x6, x6, x2
    a5ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a5b0:	8b0900c5 	add	x5, x6, x9
    a5b4:	eb02011f 	cmp	x8, x2
    a5b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a5bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    a5c0:	eb06007f 	cmp	x3, x6
    a5c4:	540000e3 	b.cc	a5e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a5c8:	92407d4a 	and	x10, x10, #0xffffffff
    a5cc:	9ac72000 	lsl	x0, x0, x7
    a5d0:	8b028142 	add	x2, x10, x2, lsl #32
    a5d4:	eb02001f 	cmp	x0, x2
    a5d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a5dc:	54000a01 	b.ne	a71c <__divti3+0x32c>  // b.any
    a5e0:	d1000420 	sub	x0, x1, #0x1
    a5e4:	d2800001 	mov	x1, #0x0                   	// #0
    a5e8:	17ffffb4 	b	a4b8 <__divti3+0xc8>
    a5ec:	b5000062 	cbnz	x2, a5f8 <__divti3+0x208>
    a5f0:	d2800022 	mov	x2, #0x1                   	// #1
    a5f4:	9ac30846 	udiv	x6, x2, x3
    a5f8:	dac010c8 	clz	x8, x6
    a5fc:	b5000408 	cbnz	x8, a67c <__divti3+0x28c>
    a600:	d360fcc9 	lsr	x9, x6, #32
    a604:	92407cc5 	and	x5, x6, #0xffffffff
    a608:	cb060023 	sub	x3, x1, x6
    a60c:	d2800021 	mov	x1, #0x1                   	// #1
    a610:	9ac90868 	udiv	x8, x3, x9
    a614:	9b098d03 	msub	x3, x8, x9, x3
    a618:	aa0803e0 	mov	x0, x8
    a61c:	9b057d02 	mul	x2, x8, x5
    a620:	93c78063 	extr	x3, x3, x7, #32
    a624:	eb03005f 	cmp	x2, x3
    a628:	540000a9 	b.ls	a63c <__divti3+0x24c>  // b.plast
    a62c:	ab0300c3 	adds	x3, x6, x3
    a630:	d1000500 	sub	x0, x8, #0x1
    a634:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a638:	54000968 	b.hi	a764 <__divti3+0x374>  // b.pmore
    a63c:	cb020063 	sub	x3, x3, x2
    a640:	9ac90862 	udiv	x2, x3, x9
    a644:	aa0203e8 	mov	x8, x2
    a648:	9b098c42 	msub	x2, x2, x9, x3
    a64c:	aa0703e3 	mov	x3, x7
    a650:	9b057d05 	mul	x5, x8, x5
    a654:	b3607c43 	bfi	x3, x2, #32, #32
    a658:	eb0300bf 	cmp	x5, x3
    a65c:	540000c9 	b.ls	a674 <__divti3+0x284>  // b.plast
    a660:	ab0300c2 	adds	x2, x6, x3
    a664:	d1000503 	sub	x3, x8, #0x1
    a668:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a66c:	d1000908 	sub	x8, x8, #0x2
    a670:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a674:	aa008100 	orr	x0, x8, x0, lsl #32
    a678:	17ffff90 	b	a4b8 <__divti3+0xc8>
    a67c:	9ac820c6 	lsl	x6, x6, x8
    a680:	d2800803 	mov	x3, #0x40                  	// #64
    a684:	cb080063 	sub	x3, x3, x8
    a688:	d360fcc9 	lsr	x9, x6, #32
    a68c:	9ac82027 	lsl	x7, x1, x8
    a690:	92407cc5 	and	x5, x6, #0xffffffff
    a694:	9ac32422 	lsr	x2, x1, x3
    a698:	9ac32403 	lsr	x3, x0, x3
    a69c:	aa070063 	orr	x3, x3, x7
    a6a0:	9ac9084a 	udiv	x10, x2, x9
    a6a4:	9ac82007 	lsl	x7, x0, x8
    a6a8:	9b098940 	msub	x0, x10, x9, x2
    a6ac:	aa0a03e1 	mov	x1, x10
    a6b0:	9b0a7ca2 	mul	x2, x5, x10
    a6b4:	93c38000 	extr	x0, x0, x3, #32
    a6b8:	eb00005f 	cmp	x2, x0
    a6bc:	540000a9 	b.ls	a6d0 <__divti3+0x2e0>  // b.plast
    a6c0:	ab0000c0 	adds	x0, x6, x0
    a6c4:	d1000541 	sub	x1, x10, #0x1
    a6c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a6cc:	54000468 	b.hi	a758 <__divti3+0x368>  // b.pmore
    a6d0:	cb020000 	sub	x0, x0, x2
    a6d4:	9ac9080a 	udiv	x10, x0, x9
    a6d8:	9b098140 	msub	x0, x10, x9, x0
    a6dc:	aa0a03e2 	mov	x2, x10
    a6e0:	9b0a7ca8 	mul	x8, x5, x10
    a6e4:	b3607c03 	bfi	x3, x0, #32, #32
    a6e8:	eb03011f 	cmp	x8, x3
    a6ec:	540000a9 	b.ls	a700 <__divti3+0x310>  // b.plast
    a6f0:	ab0300c3 	adds	x3, x6, x3
    a6f4:	d1000542 	sub	x2, x10, #0x1
    a6f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a6fc:	54000288 	b.hi	a74c <__divti3+0x35c>  // b.pmore
    a700:	cb080063 	sub	x3, x3, x8
    a704:	aa018041 	orr	x1, x2, x1, lsl #32
    a708:	17ffffc2 	b	a610 <__divti3+0x220>
    a70c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a710:	d2800001 	mov	x1, #0x0                   	// #0
    a714:	9a9f87e0 	cset	x0, ls	// ls = plast
    a718:	17ffff68 	b	a4b8 <__divti3+0xc8>
    a71c:	aa0103e0 	mov	x0, x1
    a720:	d2800001 	mov	x1, #0x0                   	// #0
    a724:	17ffff65 	b	a4b8 <__divti3+0xc8>
    a728:	d1000860 	sub	x0, x3, #0x2
    a72c:	8b0600a5 	add	x5, x5, x6
    a730:	17ffff52 	b	a478 <__divti3+0x88>
    a734:	d1000961 	sub	x1, x11, #0x2
    a738:	8b0800a5 	add	x5, x5, x8
    a73c:	17ffff85 	b	a550 <__divti3+0x160>
    a740:	d1000965 	sub	x5, x11, #0x2
    a744:	8b080063 	add	x3, x3, x8
    a748:	17ffff8e 	b	a580 <__divti3+0x190>
    a74c:	d1000942 	sub	x2, x10, #0x2
    a750:	8b060063 	add	x3, x3, x6
    a754:	17ffffeb 	b	a700 <__divti3+0x310>
    a758:	d1000941 	sub	x1, x10, #0x2
    a75c:	8b060000 	add	x0, x0, x6
    a760:	17ffffdc 	b	a6d0 <__divti3+0x2e0>
    a764:	d1000900 	sub	x0, x8, #0x2
    a768:	8b060063 	add	x3, x3, x6
    a76c:	17ffffb4 	b	a63c <__divti3+0x24c>

000000000000a770 <__modti3>:
    a770:	d503245f 	bti	c
    a774:	d2800004 	mov	x4, #0x0                   	// #0
    a778:	b6f80081 	tbz	x1, #63, a788 <__modti3+0x18>
    a77c:	eb0003e0 	negs	x0, x0
    a780:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a784:	da0103e1 	ngc	x1, x1
    a788:	f100007f 	cmp	x3, #0x0
    a78c:	5400128b 	b.lt	a9dc <__modti3+0x26c>  // b.tstop
    a790:	aa0003e7 	mov	x7, x0
    a794:	aa0103e6 	mov	x6, x1
    a798:	540004e1 	b.ne	a834 <__modti3+0xc4>  // b.any
    a79c:	eb02003f 	cmp	x1, x2
    a7a0:	54000dc2 	b.cs	a958 <__modti3+0x1e8>  // b.hs, b.nlast
    a7a4:	dac01043 	clz	x3, x2
    a7a8:	aa0303e5 	mov	x5, x3
    a7ac:	b40000e3 	cbz	x3, a7c8 <__modti3+0x58>
    a7b0:	4b0303e6 	neg	w6, w3
    a7b4:	9ac32021 	lsl	x1, x1, x3
    a7b8:	9ac32042 	lsl	x2, x2, x3
    a7bc:	9ac62406 	lsr	x6, x0, x6
    a7c0:	aa0100c6 	orr	x6, x6, x1
    a7c4:	9ac32007 	lsl	x7, x0, x3
    a7c8:	d360fc40 	lsr	x0, x2, #32
    a7cc:	92407c43 	and	x3, x2, #0xffffffff
    a7d0:	9ac008c1 	udiv	x1, x6, x0
    a7d4:	9b009826 	msub	x6, x1, x0, x6
    a7d8:	9b017c61 	mul	x1, x3, x1
    a7dc:	93c780c6 	extr	x6, x6, x7, #32
    a7e0:	eb06003f 	cmp	x1, x6
    a7e4:	540000a9 	b.ls	a7f8 <__modti3+0x88>  // b.plast
    a7e8:	ab060046 	adds	x6, x2, x6
    a7ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a7f0:	8b0200c8 	add	x8, x6, x2
    a7f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a7f8:	cb0100c6 	sub	x6, x6, x1
    a7fc:	9ac008c8 	udiv	x8, x6, x0
    a800:	9b009901 	msub	x1, x8, x0, x6
    a804:	aa0703e0 	mov	x0, x7
    a808:	9b087c63 	mul	x3, x3, x8
    a80c:	b3607c20 	bfi	x0, x1, #32, #32
    a810:	eb00007f 	cmp	x3, x0
    a814:	54001088 	b.hi	aa24 <__modti3+0x2b4>  // b.pmore
    a818:	cb030000 	sub	x0, x0, x3
    a81c:	9ac52400 	lsr	x0, x0, x5
    a820:	d2800001 	mov	x1, #0x0                   	// #0
    a824:	b4000064 	cbz	x4, a830 <__modti3+0xc0>
    a828:	eb0003e0 	negs	x0, x0
    a82c:	da0103e1 	ngc	x1, x1
    a830:	d65f03c0 	ret
    a834:	dac01066 	clz	x6, x3
    a838:	eb03003f 	cmp	x1, x3
    a83c:	54ffff43 	b.cc	a824 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a840:	93407cc5 	sxtw	x5, w6
    a844:	d2800808 	mov	x8, #0x40                  	// #64
    a848:	cb050108 	sub	x8, x8, x5
    a84c:	9ac62063 	lsl	x3, x3, x6
    a850:	9ac62025 	lsl	x5, x1, x6
    a854:	9ac82447 	lsr	x7, x2, x8
    a858:	aa0300e7 	orr	x7, x7, x3
    a85c:	9ac82423 	lsr	x3, x1, x8
    a860:	92407cec 	and	x12, x7, #0xffffffff
    a864:	d360fcea 	lsr	x10, x7, #32
    a868:	9ac82401 	lsr	x1, x0, x8
    a86c:	aa050021 	orr	x1, x1, x5
    a870:	9ac62042 	lsl	x2, x2, x6
    a874:	9ac62000 	lsl	x0, x0, x6
    a878:	9aca086b 	udiv	x11, x3, x10
    a87c:	9b0a8d63 	msub	x3, x11, x10, x3
    a880:	aa0b03e5 	mov	x5, x11
    a884:	9b0b7d89 	mul	x9, x12, x11
    a888:	93c18063 	extr	x3, x3, x1, #32
    a88c:	eb03013f 	cmp	x9, x3
    a890:	540000a9 	b.ls	a8a4 <__modti3+0x134>  // b.plast
    a894:	ab0300e3 	adds	x3, x7, x3
    a898:	d1000565 	sub	x5, x11, #0x1
    a89c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a8a0:	54001168 	b.hi	aacc <__modti3+0x35c>  // b.pmore
    a8a4:	cb090063 	sub	x3, x3, x9
    a8a8:	9aca086b 	udiv	x11, x3, x10
    a8ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    a8b0:	aa0b03e9 	mov	x9, x11
    a8b4:	9b0b7d8c 	mul	x12, x12, x11
    a8b8:	b3607d41 	bfi	x1, x10, #32, #32
    a8bc:	eb01019f 	cmp	x12, x1
    a8c0:	540000a9 	b.ls	a8d4 <__modti3+0x164>  // b.plast
    a8c4:	ab0100e1 	adds	x1, x7, x1
    a8c8:	d1000569 	sub	x9, x11, #0x1
    a8cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a8d0:	54000f88 	b.hi	aac0 <__modti3+0x350>  // b.pmore
    a8d4:	aa058123 	orr	x3, x9, x5, lsl #32
    a8d8:	92407c4b 	and	x11, x2, #0xffffffff
    a8dc:	2a0903e9 	mov	w9, w9
    a8e0:	d360fc4a 	lsr	x10, x2, #32
    a8e4:	d360fc63 	lsr	x3, x3, #32
    a8e8:	cb0c0021 	sub	x1, x1, x12
    a8ec:	aa0a03ec 	mov	x12, x10
    a8f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a8f4:	9b0b7d25 	mul	x5, x9, x11
    a8f8:	9b0b7c6b 	mul	x11, x3, x11
    a8fc:	9b0a2d29 	madd	x9, x9, x10, x11
    a900:	92407caa 	and	x10, x5, #0xffffffff
    a904:	9b0c7c63 	mul	x3, x3, x12
    a908:	8b458125 	add	x5, x9, x5, lsr #32
    a90c:	8b0d0069 	add	x9, x3, x13
    a910:	eb05017f 	cmp	x11, x5
    a914:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a918:	8b058149 	add	x9, x10, x5, lsl #32
    a91c:	8b458063 	add	x3, x3, x5, lsr #32
    a920:	eb03003f 	cmp	x1, x3
    a924:	54000063 	b.cc	a930 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a928:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a92c:	54000082 	b.cs	a93c <__modti3+0x1cc>  // b.hs, b.nlast
    a930:	eb020129 	subs	x9, x9, x2
    a934:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a938:	cb070063 	sub	x3, x3, x7
    a93c:	eb090000 	subs	x0, x0, x9
    a940:	da030021 	sbc	x1, x1, x3
    a944:	9ac62400 	lsr	x0, x0, x6
    a948:	9ac82028 	lsl	x8, x1, x8
    a94c:	aa000100 	orr	x0, x8, x0
    a950:	9ac62421 	lsr	x1, x1, x6
    a954:	17ffffb4 	b	a824 <__modti3+0xb4>
    a958:	b5000062 	cbnz	x2, a964 <__modti3+0x1f4>
    a95c:	d2800023 	mov	x3, #0x1                   	// #1
    a960:	9ac20862 	udiv	x2, x3, x2
    a964:	dac01048 	clz	x8, x2
    a968:	aa0803e5 	mov	x5, x8
    a96c:	b5000668 	cbnz	x8, aa38 <__modti3+0x2c8>
    a970:	cb020020 	sub	x0, x1, x2
    a974:	d360fc49 	lsr	x9, x2, #32
    a978:	92407c4a 	and	x10, x2, #0xffffffff
    a97c:	9ac90801 	udiv	x1, x0, x9
    a980:	9b098020 	msub	x0, x1, x9, x0
    a984:	9b0a7c21 	mul	x1, x1, x10
    a988:	93c78000 	extr	x0, x0, x7, #32
    a98c:	eb00003f 	cmp	x1, x0
    a990:	540000a9 	b.ls	a9a4 <__modti3+0x234>  // b.plast
    a994:	ab000040 	adds	x0, x2, x0
    a998:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a99c:	8b020003 	add	x3, x0, x2
    a9a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a9a4:	cb010001 	sub	x1, x0, x1
    a9a8:	9ac90820 	udiv	x0, x1, x9
    a9ac:	9b098403 	msub	x3, x0, x9, x1
    a9b0:	aa0703e1 	mov	x1, x7
    a9b4:	9b0a7c00 	mul	x0, x0, x10
    a9b8:	b3607c61 	bfi	x1, x3, #32, #32
    a9bc:	eb01001f 	cmp	x0, x1
    a9c0:	540000a9 	b.ls	a9d4 <__modti3+0x264>  // b.plast
    a9c4:	ab010041 	adds	x1, x2, x1
    a9c8:	8b020022 	add	x2, x1, x2
    a9cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a9d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a9d4:	cb000020 	sub	x0, x1, x0
    a9d8:	17ffff91 	b	a81c <__modti3+0xac>
    a9dc:	eb0203e5 	negs	x5, x2
    a9e0:	aa0003e7 	mov	x7, x0
    a9e4:	da0303e8 	ngc	x8, x3
    a9e8:	aa0503e2 	mov	x2, x5
    a9ec:	aa0803e3 	mov	x3, x8
    a9f0:	aa0103e6 	mov	x6, x1
    a9f4:	b4ffed48 	cbz	x8, a79c <__modti3+0x2c>
    a9f8:	eb01011f 	cmp	x8, x1
    a9fc:	54fff148 	b.hi	a824 <__modti3+0xb4>  // b.pmore
    aa00:	dac01109 	clz	x9, x8
    aa04:	2a0903e6 	mov	w6, w9
    aa08:	b5fff1c9 	cbnz	x9, a840 <__modti3+0xd0>
    aa0c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    aa10:	54000068 	b.hi	aa1c <__modti3+0x2ac>  // b.pmore
    aa14:	eb050007 	subs	x7, x0, x5
    aa18:	da080021 	sbc	x1, x1, x8
    aa1c:	aa0703e0 	mov	x0, x7
    aa20:	17ffff81 	b	a824 <__modti3+0xb4>
    aa24:	ab000040 	adds	x0, x2, x0
    aa28:	8b020002 	add	x2, x0, x2
    aa2c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    aa30:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    aa34:	17ffff79 	b	a818 <__modti3+0xa8>
    aa38:	9ac82042 	lsl	x2, x2, x8
    aa3c:	d2800803 	mov	x3, #0x40                  	// #64
    aa40:	cb080063 	sub	x3, x3, x8
    aa44:	d360fc49 	lsr	x9, x2, #32
    aa48:	9ac82027 	lsl	x7, x1, x8
    aa4c:	92407c4a 	and	x10, x2, #0xffffffff
    aa50:	9ac32426 	lsr	x6, x1, x3
    aa54:	9ac32403 	lsr	x3, x0, x3
    aa58:	aa070063 	orr	x3, x3, x7
    aa5c:	9ac908c1 	udiv	x1, x6, x9
    aa60:	9ac82007 	lsl	x7, x0, x8
    aa64:	9b099820 	msub	x0, x1, x9, x6
    aa68:	9b017d41 	mul	x1, x10, x1
    aa6c:	93c38000 	extr	x0, x0, x3, #32
    aa70:	eb00003f 	cmp	x1, x0
    aa74:	540000a9 	b.ls	aa88 <__modti3+0x318>  // b.plast
    aa78:	ab000040 	adds	x0, x2, x0
    aa7c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aa80:	8b020006 	add	x6, x0, x2
    aa84:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    aa88:	cb010000 	sub	x0, x0, x1
    aa8c:	9ac90801 	udiv	x1, x0, x9
    aa90:	9b098026 	msub	x6, x1, x9, x0
    aa94:	aa0303e0 	mov	x0, x3
    aa98:	9b017d41 	mul	x1, x10, x1
    aa9c:	b3607cc0 	bfi	x0, x6, #32, #32
    aaa0:	eb00003f 	cmp	x1, x0
    aaa4:	540000a9 	b.ls	aab8 <__modti3+0x348>  // b.plast
    aaa8:	ab000040 	adds	x0, x2, x0
    aaac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aab0:	8b020003 	add	x3, x0, x2
    aab4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aab8:	cb010000 	sub	x0, x0, x1
    aabc:	17ffffb0 	b	a97c <__modti3+0x20c>
    aac0:	d1000969 	sub	x9, x11, #0x2
    aac4:	8b070021 	add	x1, x1, x7
    aac8:	17ffff83 	b	a8d4 <__modti3+0x164>
    aacc:	d1000965 	sub	x5, x11, #0x2
    aad0:	8b070063 	add	x3, x3, x7
    aad4:	17ffff74 	b	a8a4 <__modti3+0x134>
    aad8:	d503201f 	nop
    aadc:	d503201f 	nop

000000000000aae0 <atexit>:
    aae0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aae4:	d00000a2 	adrp	x2, 20000 <__data_start>
    aae8:	d2800001 	mov	x1, #0x0                   	// #0
    aaec:	910003fd 	mov	x29, sp
    aaf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aaf4:	f9400442 	ldr	x2, [x2, #8]
    aaf8:	17ffdf46 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000aafc <_fini>:
    aafc:	d503201f 	nop
    ab00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ab04:	910003fd 	mov	x29, sp
    ab08:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ab0c:	d65f03c0 	ret
