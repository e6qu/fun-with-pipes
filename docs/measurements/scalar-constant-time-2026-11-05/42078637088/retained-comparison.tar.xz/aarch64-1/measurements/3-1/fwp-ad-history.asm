
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__modti3+0x180>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	911080a5 	add	x5, x5, #0x420
    2a20:	b0000044 	adrp	x4, b000 <__modti3+0x180>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9110a084 	add	x4, x4, #0x428
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10dc8>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2ab4:	91200000 	add	x0, x0, #0x800
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0xb90>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91118042 	add	x2, x2, #0x460
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2bfc:	91204000 	add	x0, x0, #0x810
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2c0c:	9122c000 	add	x0, x0, #0x8b0
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2c24:	91222000 	add	x0, x0, #0x888
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2c30:	91216000 	add	x0, x0, #0x858
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2c3c:	9120c000 	add	x0, x0, #0x830
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <__modti3+0x180>
    2e34:	913ac021 	add	x1, x1, #0xeb0
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	b0000040 	adrp	x0, b000 <__modti3+0x180>
    2fd0:	9108a000 	add	x0, x0, #0x228
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <__modti3+0x180>
    3098:	913a4021 	add	x1, x1, #0xe90
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3370:	9108a000 	add	x0, x0, #0x228
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	90000041 	adrp	x1, b000 <__modti3+0x180>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91090021 	add	x1, x1, #0x240
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	90000041 	adrp	x1, b000 <__modti3+0x180>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	91092021 	add	x1, x1, #0x248
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	90000041 	adrp	x1, b000 <__modti3+0x180>
    34e0:	91094021 	add	x1, x1, #0x250
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	90000042 	adrp	x2, b000 <__modti3+0x180>
    3538:	aa1303e3 	mov	x3, x19
    353c:	91096042 	add	x2, x2, #0x258
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3650:	9108a000 	add	x0, x0, #0x228
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3670:	9109a000 	add	x0, x0, #0x268
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3708:	910a2000 	add	x0, x0, #0x288
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3718:	910aa000 	add	x0, x0, #0x2a8
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	90000041 	adrp	x1, b000 <__modti3+0x180>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc3b020 	ldr	q0, [x1, #3776]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3818:	910b4000 	add	x0, x0, #0x2d0
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3888:	910c0000 	add	x0, x0, #0x300
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	90000044 	adrp	x4, b000 <__modti3+0x180>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	910d4084 	add	x4, x4, #0x350
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	90000044 	adrp	x4, b000 <__modti3+0x180>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	910da084 	add	x4, x4, #0x368
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	90000044 	adrp	x4, b000 <__modti3+0x180>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	910d6084 	add	x4, x4, #0x358
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3ca8:	91154042 	add	x2, x2, #0x550
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	90000041 	adrp	x1, b000 <__modti3+0x180>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	910dc021 	add	x1, x1, #0x370
    3d04:	910de000 	add	x0, x0, #0x378
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	90000042 	adrp	x2, b000 <__modti3+0x180>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	910e6042 	add	x2, x2, #0x398
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e0c:	91114061 	add	x1, x3, #0x450
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e1c:	91154262 	add	x2, x19, #0x550
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	90000042 	adrp	x2, b000 <__modti3+0x180>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3e4c:	91124021 	add	x1, x1, #0x490
    3e50:	3dc3b443 	ldr	q3, [x2, #3792]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3e7c:	91114063 	add	x3, x3, #0x450
    3e80:	9113c084 	add	x4, x4, #0x4f0
    3e84:	91154266 	add	x6, x19, #0x550
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91154275 	add	x21, x19, #0x550
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	90000040 	adrp	x0, b000 <__modti3+0x180>
    3f68:	91112000 	add	x0, x0, #0x448
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91154273 	add	x19, x19, #0x550
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	91010122 	add	x2, x9, #0x40
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	91010120 	add	x0, x9, #0x40
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	91010129 	add	x9, x9, #0x40
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    40cc:	91116000 	add	x0, x0, #0x458
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	91116000 	add	x0, x0, #0x458
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	910102d6 	add	x22, x22, #0x40
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	91116000 	add	x0, x0, #0x458
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	91010281 	add	x1, x20, #0x40
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	91010280 	add	x0, x20, #0x40
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	91010288 	add	x8, x20, #0x40
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	91010281 	add	x1, x20, #0x40
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    43bc:	9111c000 	add	x0, x0, #0x470
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911542a2 	add	x2, x21, #0x550
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    4474:	91132000 	add	x0, x0, #0x4c8
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911542b5 	add	x21, x21, #0x550
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    44d0:	91128000 	add	x0, x0, #0x4a0
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    44e0:	9113c000 	add	x0, x0, #0x4f0
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4520:	91154262 	add	x2, x19, #0x550
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91154273 	add	x19, x19, #0x550
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	f0000020 	adrp	x0, b000 <__modti3+0x180>
    4580:	91132000 	add	x0, x0, #0x4c8
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    45a0:	911542c2 	add	x2, x22, #0x550
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911542c2 	add	x2, x22, #0x550
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911542d6 	add	x22, x22, #0x550
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    46c0:	911542b5 	add	x21, x21, #0x550
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4784:	911542a1 	add	x1, x21, #0x550
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911542b5 	add	x21, x21, #0x550
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911542a1 	add	x1, x21, #0x550
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911542a0 	add	x0, x21, #0x550
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911542b5 	add	x21, x21, #0x550
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4988:	91154359 	add	x25, x26, #0x550
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	54000e8b 	b.lt	50fc <fwp_p_ad_push+0x1d8>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	aa0003e4 	mov	x4, x0
    4f38:	910003fd 	mov	x29, sp
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0003f5 	mov	x21, x0
    4f44:	aa020000 	orr	x0, x0, x2
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f7 	mov	x23, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	b6f80900 	tbz	x0, #63, 507c <fwp_p_ad_push+0x158>
    4f60:	a90153f3 	stp	x19, x20, [sp, #16]
    4f64:	9360fc80 	asr	x0, x4, #32
    4f68:	b6f800c4 	tbz	x4, #63, 4f80 <fwp_p_ad_push+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc40 	asr	x0, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f80:	97fffa2c 	bl	3830 <fwp_tape_of>
    4f84:	aa0003f3 	mov	x19, x0
    4f88:	f9403000 	ldr	x0, [x0, #96]
    4f8c:	b5001280 	cbnz	x0, 51dc <fwp_p_ad_push+0x2b8>
    4f90:	f9400a76 	ldr	x22, [x19, #16]
    4f94:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f98:	eb0002df 	cmp	x22, x0
    4f9c:	54000e2c 	b.gt	5160 <fwp_p_ad_push+0x23c>
    4fa0:	eb3542df 	cmp	x22, w21, uxtw
    4fa4:	54000d4d 	b.le	514c <fwp_p_ad_push+0x228>
    4fa8:	b7f80077 	tbnz	x23, #63, 4fb4 <fwp_p_ad_push+0x90>
    4fac:	eb3742df 	cmp	x22, w23, uxtw
    4fb0:	54000ced 	b.le	514c <fwp_p_ad_push+0x228>
    4fb4:	f9400678 	ldr	x24, [x19, #8]
    4fb8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fbc:	cb1802d8 	sub	x24, x22, x24
    4fc0:	91000701 	add	x1, x24, #0x1
    4fc4:	eb00003f 	cmp	x1, x0
    4fc8:	54000cc8 	b.hi	5160 <fwp_p_ad_push+0x23c>  // b.pmore
    4fcc:	a9418274 	ldp	x20, x0, [x19, #24]
    4fd0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fd4:	eb14003f 	cmp	x1, x20
    4fd8:	5400068d 	b.le	50a8 <fwp_p_ad_push+0x184>
    4fdc:	f100029f 	cmp	x20, #0x0
    4fe0:	d2800803 	mov	x3, #0x40                  	// #64
    4fe4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fe8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	5400008d 	b.le	5004 <fwp_p_ad_push+0xe0>
    4ff8:	eb02029f 	cmp	x20, x2
    4ffc:	5400052d 	b.le	50a0 <fwp_p_ad_push+0x17c>
    5000:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5004:	d37df299 	lsl	x25, x20, #3
    5008:	aa1903e1 	mov	x1, x25
    500c:	97fff5f5 	bl	27e0 <realloc@plt>
    5010:	aa0003e1 	mov	x1, x0
    5014:	b4000b00 	cbz	x0, 5174 <fwp_p_ad_push+0x250>
    5018:	f9400e62 	ldr	x2, [x19, #24]
    501c:	f9001261 	str	x1, [x19, #32]
    5020:	f9401a60 	ldr	x0, [x19, #48]
    5024:	d37cee9a 	lsl	x26, x20, #4
    5028:	8b020821 	add	x1, x1, x2, lsl #2
    502c:	f9001661 	str	x1, [x19, #40]
    5030:	aa1a03e1 	mov	x1, x26
    5034:	97fff5eb 	bl	27e0 <realloc@plt>
    5038:	aa0003e2 	mov	x2, x0
    503c:	b40009c0 	cbz	x0, 5174 <fwp_p_ad_push+0x250>
    5040:	f9400e61 	ldr	x1, [x19, #24]
    5044:	d37df31b 	lsl	x27, x24, #3
    5048:	d37ef685 	lsl	x5, x20, #2
    504c:	d37ef71c 	lsl	x28, x24, #2
    5050:	8b190004 	add	x4, x0, x25
    5054:	8b010c01 	add	x1, x0, x1, lsl #3
    5058:	a9030660 	stp	x0, x1, [x19, #48]
    505c:	b5000558 	cbnz	x24, 5104 <fwp_p_ad_push+0x1e0>
    5060:	f9001e64 	str	x4, [x19, #56]
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	a9446bf9 	ldp	x25, x26, [sp, #64]
    506c:	8b050001 	add	x1, x0, x5
    5070:	f9000e74 	str	x20, [x19, #24]
    5074:	f9001661 	str	x1, [x19, #40]
    5078:	14000010 	b	50b8 <fwp_p_ad_push+0x194>
    507c:	9360fc40 	asr	x0, x2, #32
    5080:	a90153f3 	stp	x19, x20, [sp, #16]
    5084:	eb84801f 	cmp	x0, x4, asr #32
    5088:	54fff7c0 	b.eq	4f80 <fwp_p_ad_push+0x5c>  // b.none
    508c:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5090:	91144000 	add	x0, x0, #0x510
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	a90573fb 	stp	x27, x28, [sp, #80]
    509c:	97fff919 	bl	3500 <fwp_trap>
    50a0:	d37ffa94 	lsl	x20, x20, #1
    50a4:	17ffffd3 	b	4ff0 <fwp_p_ad_push+0xcc>
    50a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50ac:	d37ef71c 	lsl	x28, x24, #2
    50b0:	f9401e64 	ldr	x4, [x19, #56]
    50b4:	d37df31b 	lsl	x27, x24, #3
    50b8:	b83c6815 	str	w21, [x0, x28]
    50bc:	f10002ff 	cmp	x23, #0x0
    50c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    50c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50c8:	fc3b6849 	str	d9, [x2, x27]
    50cc:	aa1602a0 	orr	x0, x21, x22
    50d0:	b83c6837 	str	w23, [x1, x28]
    50d4:	910006d6 	add	x22, x22, #0x1
    50d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50dc:	fc3b6888 	str	d8, [x4, x27]
    50e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50e8:	f9000a76 	str	x22, [x19, #16]
    50ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50f8:	d65f03c0 	ret
    50fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5100:	d65f03c0 	ret
    5104:	eb1a033f 	cmp	x25, x26
    5108:	aa0403e0 	mov	x0, x4
    510c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5110:	aa1b03e2 	mov	x2, x27
    5114:	cb190063 	sub	x3, x3, x25
    5118:	f9003fe5 	str	x5, [sp, #120]
    511c:	97fff61d 	bl	2990 <__memmove_chk@plt>
    5120:	a9420660 	ldp	x0, x1, [x19, #32]
    5124:	aa1c03e2 	mov	x2, x28
    5128:	f9401a63 	ldr	x3, [x19, #48]
    512c:	f9403fe5 	ldr	x5, [sp, #120]
    5130:	8b190063 	add	x3, x3, x25
    5134:	f9001e63 	str	x3, [x19, #56]
    5138:	8b050000 	add	x0, x0, x5
    513c:	97fff549 	bl	2660 <memmove@plt>
    5140:	a9431262 	ldp	x2, x4, [x19, #48]
    5144:	f9403fe5 	ldr	x5, [sp, #120]
    5148:	17ffffc7 	b	5064 <fwp_p_ad_push+0x140>
    514c:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5150:	9116a000 	add	x0, x0, #0x5a8
    5154:	a9046bf9 	stp	x25, x26, [sp, #64]
    5158:	a90573fb 	stp	x27, x28, [sp, #80]
    515c:	97fff8e9 	bl	3500 <fwp_trap>
    5160:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5164:	91162000 	add	x0, x0, #0x588
    5168:	a9046bf9 	stp	x25, x26, [sp, #64]
    516c:	a90573fb 	stp	x27, x28, [sp, #80]
    5170:	97fff8e4 	bl	3500 <fwp_trap>
    5174:	aa1303e0 	mov	x0, x19
    5178:	97fff766 	bl	2f10 <fwp_tape_unlink_scope>
    517c:	f9401260 	ldr	x0, [x19, #32]
    5180:	97fff5cc 	bl	28b0 <free@plt>
    5184:	f9401a60 	ldr	x0, [x19, #48]
    5188:	97fff5ca 	bl	28b0 <free@plt>
    518c:	f9402260 	ldr	x0, [x19, #64]
    5190:	97fff5c8 	bl	28b0 <free@plt>
    5194:	f9000e7f 	str	xzr, [x19, #24]
    5198:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    519c:	f947e821 	ldr	x1, [x1, #4048]
    51a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51a4:	d2800262 	mov	x2, #0x13                  	// #19
    51a8:	4f000400 	movi	v0.4s, #0x0
    51ac:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    51b0:	f9400023 	ldr	x3, [x1]
    51b4:	b900067f 	str	wzr, [x19, #4]
    51b8:	d2800021 	mov	x1, #0x1                   	// #1
    51bc:	9108a000 	add	x0, x0, #0x228
    51c0:	3c808260 	stur	q0, [x19, #8]
    51c4:	ad010260 	stp	q0, q0, [x19, #32]
    51c8:	97fff5ca 	bl	28f0 <fwrite@plt>
    51cc:	d2800000 	mov	x0, #0x0                   	// #0
    51d0:	97fff5d4 	bl	2920 <fflush@plt>
    51d4:	52800cc0 	mov	w0, #0x66                  	// #102
    51d8:	97fff5e2 	bl	2960 <_Exit@plt>
    51dc:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    51e0:	91156000 	add	x0, x0, #0x558
    51e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51e8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ec:	97fff8c5 	bl	3500 <fwp_trap>

00000000000051f0 <w107>:
    51f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51f4:	9e660003 	fmov	x3, d0
    51f8:	aa0003e2 	mov	x2, x0
    51fc:	910003fd 	mov	x29, sp
    5200:	6d0327e8 	stp	d8, d9, [sp, #48]
    5204:	1e604028 	fmov	d8, d1
    5208:	1e600809 	fmul	d9, d0, d0
    520c:	fd0023ea 	str	d10, [sp, #64]
    5210:	1e60400a 	fmov	d10, d0
    5214:	a90153f3 	stp	x19, x20, [sp, #16]
    5218:	aa0003f3 	mov	x19, x0
    521c:	aa0103f4 	mov	x20, x1
    5220:	aa0303e1 	mov	x1, x3
    5224:	a9025bf5 	stp	x21, x22, [sp, #32]
    5228:	97ffff3f 	bl	4f24 <fwp_p_ad_push>
    522c:	1e693908 	fsub	d8, d8, d9
    5230:	aa1403e2 	mov	x2, x20
    5234:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5238:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    523c:	9e660116 	fmov	x22, d8
    5240:	97ffff39 	bl	4f24 <fwp_p_ad_push>
    5244:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5248:	aa0003e1 	mov	x1, x0
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa1303e0 	mov	x0, x19
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	aa0103f3 	mov	x19, x1
    525c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5260:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5264:	9e660135 	fmov	x21, d9
    5268:	97ffff2f 	bl	4f24 <fwp_p_ad_push>
    526c:	1e680908 	fmul	d8, d8, d8
    5270:	aa0003f4 	mov	x20, x0
    5274:	aa1603e3 	mov	x3, x22
    5278:	aa1603e1 	mov	x1, x22
    527c:	aa1303e2 	mov	x2, x19
    5280:	aa1303e0 	mov	x0, x19
    5284:	97ffff28 	bl	4f24 <fwp_p_ad_push>
    5288:	aa0003e2 	mov	x2, x0
    528c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5290:	9e670020 	fmov	d0, x1
    5294:	9e660101 	fmov	x1, d8
    5298:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    529c:	1e600908 	fmul	d8, d8, d0
    52a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52a4:	97ffff20 	bl	4f24 <fwp_p_ad_push>
    52a8:	1e690929 	fmul	d9, d9, d9
    52ac:	aa0003f3 	mov	x19, x0
    52b0:	aa1503e3 	mov	x3, x21
    52b4:	aa1503e1 	mov	x1, x21
    52b8:	aa1403e2 	mov	x2, x20
    52bc:	aa1403e0 	mov	x0, x20
    52c0:	97ffff19 	bl	4f24 <fwp_p_ad_push>
    52c4:	1e692908 	fadd	d8, d8, d9
    52c8:	aa1303e2 	mov	x2, x19
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	aa0303e1 	mov	x1, x3
    52d4:	97ffff14 	bl	4f24 <fwp_p_ad_push>
    52d8:	aa0003e1 	mov	x1, x0
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	9e660100 	fmov	x0, d8
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    52ec:	fd4023ea 	ldr	d10, [sp, #64]
    52f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52f4:	d65f03c0 	ret
    52f8:	d503201f 	nop
    52fc:	d503201f 	nop

0000000000005300 <fwp_data.part.0.constprop.0>:
    5300:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5304:	910003fd 	mov	x29, sp
    5308:	a90153f3 	stp	x19, x20, [sp, #16]
    530c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    5310:	91154283 	add	x3, x20, #0x550
    5314:	a9025bf5 	stp	x21, x22, [sp, #32]
    5318:	aa0103f5 	mov	x21, x1
    531c:	b953a461 	ldr	w1, [x3, #5028]
    5320:	a90363f7 	stp	x23, x24, [sp, #48]
    5324:	2a0003f8 	mov	w24, w0
    5328:	34000701 	cbz	w1, 5408 <fwp_data.part.0.constprop.0+0x108>
    532c:	397e8862 	ldrb	w2, [x3, #4002]
    5330:	910f0040 	add	x0, x2, #0x3c0
    5334:	8b020442 	add	x2, x2, x2, lsl #1
    5338:	d37df042 	lsl	x2, x2, #3
    533c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5340:	2a1703f6 	mov	w22, w23
    5344:	f8626873 	ldr	x19, [x3, x2]
    5348:	b40004d3 	cbz	x19, 53e0 <fwp_data.part.0.constprop.0+0xe0>
    534c:	f9400260 	ldr	x0, [x19]
    5350:	aa2003e0 	mvn	x0, x0
    5354:	f8226860 	str	x0, [x3, x2]
    5358:	f10062df 	cmp	x22, #0x18
    535c:	540000e9 	b.ls	5378 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5360:	d10066c2 	sub	x2, x22, #0x19
    5364:	91006260 	add	x0, x19, #0x18
    5368:	927df042 	and	x2, x2, #0xfffffffffffffff8
    536c:	52800001 	mov	w1, #0x0                   	// #0
    5370:	91002042 	add	x2, x2, #0x8
    5374:	97fff513 	bl	27c0 <memset@plt>
    5378:	91154282 	add	x2, x20, #0x550
    537c:	f94a1041 	ldr	x1, [x2, #5152]
    5380:	ab160021 	adds	x1, x1, x22
    5384:	540004c2 	b.cs	541c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5388:	f94a1440 	ldr	x0, [x2, #5160]
    538c:	f90a1041 	str	x1, [x2, #5152]
    5390:	eb00003f 	cmp	x1, x0
    5394:	54000049 	b.ls	539c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5398:	f90a1441 	str	x1, [x2, #5160]
    539c:	91154294 	add	x20, x20, #0x550
    53a0:	1e6302e1 	ucvtf	d1, w23
    53a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    53a8:	1e612800 	fadd	d0, d0, d1
    53ac:	fd0a1e80 	str	d0, [x20, #5176]
    53b0:	52800041 	mov	w1, #0x2                   	// #2
    53b4:	29000678 	stp	w24, w1, [x19]
    53b8:	aa1303e0 	mov	x0, x19
    53bc:	f94002a1 	ldr	x1, [x21]
    53c0:	f9000661 	str	x1, [x19, #8]
    53c4:	f94006a1 	ldr	x1, [x21, #8]
    53c8:	f9000a61 	str	x1, [x19, #16]
    53cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    53d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    53dc:	d65f03c0 	ret
    53e0:	8b020063 	add	x3, x3, x2
    53e4:	f9400473 	ldr	x19, [x3, #8]
    53e8:	b4000113 	cbz	x19, 5408 <fwp_data.part.0.constprop.0+0x108>
    53ec:	f9400860 	ldr	x0, [x3, #16]
    53f0:	cb130000 	sub	x0, x0, x19
    53f4:	eb0002df 	cmp	x22, x0
    53f8:	54000088 	b.hi	5408 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    53fc:	8b160260 	add	x0, x19, x22
    5400:	f9000460 	str	x0, [x3, #8]
    5404:	17ffffd5 	b	5358 <fwp_data.part.0.constprop.0+0x58>
    5408:	52800001 	mov	w1, #0x0                   	// #0
    540c:	d2800300 	mov	x0, #0x18                  	// #24
    5410:	97fffdf8 	bl	4bf0 <fwp_heap_alloc>
    5414:	aa0003f3 	mov	x19, x0
    5418:	17ffffe6 	b	53b0 <fwp_data.part.0.constprop.0+0xb0>
    541c:	97fff6e5 	bl	2fb0 <fwp_heap_oom>

0000000000005420 <fwp_rc_share>:
    5420:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5424:	91154042 	add	x2, x2, #0x550
    5428:	f949d843 	ldr	x3, [x2, #5040]
    542c:	f949ec41 	ldr	x1, [x2, #5080]
    5430:	cb030000 	sub	x0, x0, x3
    5434:	eb01401f 	cmp	x0, x1, lsl #16
    5438:	540002c2 	b.cs	5490 <fwp_rc_share+0x70>  // b.hs, b.nlast
    543c:	d350fc01 	lsr	x1, x0, #16
    5440:	f949fc44 	ldr	x4, [x2, #5112]
    5444:	8b010821 	add	x1, x1, x1, lsl #2
    5448:	d37df021 	lsl	x1, x1, #3
    544c:	8b010083 	add	x3, x4, x1
    5450:	f9401062 	ldr	x2, [x3, #32]
    5454:	b40001e2 	cbz	x2, 5490 <fwp_rc_share+0x70>
    5458:	38616881 	ldrb	w1, [x4, x1]
    545c:	7100083f 	cmp	w1, #0x2
    5460:	540001a0 	b.eq	5494 <fwp_rc_share+0x74>  // b.none
    5464:	7100043f 	cmp	w1, #0x1
    5468:	54000141 	b.ne	5490 <fwp_rc_share+0x70>  // b.any
    546c:	29430464 	ldp	w4, w1, [x3, #24]
    5470:	92403c00 	and	x0, x0, #0xffff
    5474:	9b047c00 	mul	x0, x0, x4
    5478:	d360fc00 	lsr	x0, x0, #32
    547c:	eb01001f 	cmp	x0, x1
    5480:	54000082 	b.cs	5490 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5484:	8b000042 	add	x2, x2, x0
    5488:	39400040 	ldrb	w0, [x2]
    548c:	350000a0 	cbnz	w0, 54a0 <fwp_rc_share+0x80>
    5490:	d65f03c0 	ret
    5494:	72003c1f 	tst	w0, #0xffff
    5498:	54ffff80 	b.eq	5488 <fwp_rc_share+0x68>  // b.none
    549c:	d65f03c0 	ret
    54a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    54a4:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    54a8:	91172000 	add	x0, x0, #0x5c8
    54ac:	910003fd 	mov	x29, sp
    54b0:	97fff814 	bl	3500 <fwp_trap>

00000000000054b4 <fwp_rc_free_arr>:
    54b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    54b8:	91154063 	add	x3, x3, #0x550
    54bc:	f949d861 	ldr	x1, [x3, #5040]
    54c0:	f949ec62 	ldr	x2, [x3, #5080]
    54c4:	cb010001 	sub	x1, x0, x1
    54c8:	eb02403f 	cmp	x1, x2, lsl #16
    54cc:	54000342 	b.cs	5534 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    54d0:	d350fc22 	lsr	x2, x1, #16
    54d4:	f949fc65 	ldr	x5, [x3, #5112]
    54d8:	8b020842 	add	x2, x2, x2, lsl #2
    54dc:	d37df042 	lsl	x2, x2, #3
    54e0:	8b0200a4 	add	x4, x5, x2
    54e4:	f9401083 	ldr	x3, [x4, #32]
    54e8:	b4000263 	cbz	x3, 5534 <fwp_rc_free_arr+0x80>
    54ec:	386268a2 	ldrb	w2, [x5, x2]
    54f0:	7100085f 	cmp	w2, #0x2
    54f4:	540001c0 	b.eq	552c <fwp_rc_free_arr+0x78>  // b.none
    54f8:	7100045f 	cmp	w2, #0x1
    54fc:	540001c1 	b.ne	5534 <fwp_rc_free_arr+0x80>  // b.any
    5500:	29430885 	ldp	w5, w2, [x4, #24]
    5504:	92403c21 	and	x1, x1, #0xffff
    5508:	9b057c21 	mul	x1, x1, x5
    550c:	d360fc21 	lsr	x1, x1, #32
    5510:	eb02003f 	cmp	x1, x2
    5514:	54000102 	b.cs	5534 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5518:	8b010063 	add	x3, x3, x1
    551c:	39400061 	ldrb	w1, [x3]
    5520:	7100043f 	cmp	w1, #0x1
    5524:	54000081 	b.ne	5534 <fwp_rc_free_arr+0x80>  // b.any
    5528:	17fffc92 	b	4770 <fwp_mem_free>
    552c:	72003c3f 	tst	w1, #0xffff
    5530:	54ffff60 	b.eq	551c <fwp_rc_free_arr+0x68>  // b.none
    5534:	d65f03c0 	ret
    5538:	d503201f 	nop
    553c:	d503201f 	nop

0000000000005540 <fwp_rc_dup>:
    5540:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5544:	91154042 	add	x2, x2, #0x550
    5548:	f949d841 	ldr	x1, [x2, #5040]
    554c:	f949ec43 	ldr	x3, [x2, #5080]
    5550:	cb010001 	sub	x1, x0, x1
    5554:	eb03403f 	cmp	x1, x3, lsl #16
    5558:	54000342 	b.cs	55c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    555c:	d350fc20 	lsr	x0, x1, #16
    5560:	f949fc44 	ldr	x4, [x2, #5112]
    5564:	8b000800 	add	x0, x0, x0, lsl #2
    5568:	d37df002 	lsl	x2, x0, #3
    556c:	8b020083 	add	x3, x4, x2
    5570:	f9401060 	ldr	x0, [x3, #32]
    5574:	b4000260 	cbz	x0, 55c0 <fwp_rc_dup+0x80>
    5578:	38626882 	ldrb	w2, [x4, x2]
    557c:	7100085f 	cmp	w2, #0x2
    5580:	54000220 	b.eq	55c4 <fwp_rc_dup+0x84>  // b.none
    5584:	7100045f 	cmp	w2, #0x1
    5588:	540001c1 	b.ne	55c0 <fwp_rc_dup+0x80>  // b.any
    558c:	29430864 	ldp	w4, w2, [x3, #24]
    5590:	92403c21 	and	x1, x1, #0xffff
    5594:	9b047c21 	mul	x1, x1, x4
    5598:	d360fc21 	lsr	x1, x1, #32
    559c:	eb02003f 	cmp	x1, x2
    55a0:	54000102 	b.cs	55c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    55a4:	8b010000 	add	x0, x0, x1
    55a8:	39400001 	ldrb	w1, [x0]
    55ac:	340000a1 	cbz	w1, 55c0 <fwp_rc_dup+0x80>
    55b0:	7103f43f 	cmp	w1, #0xfd
    55b4:	540000e8 	b.hi	55d0 <fwp_rc_dup+0x90>  // b.pmore
    55b8:	11000421 	add	w1, w1, #0x1
    55bc:	39000001 	strb	w1, [x0]
    55c0:	d65f03c0 	ret
    55c4:	72003c3f 	tst	w1, #0xffff
    55c8:	54ffff00 	b.eq	55a8 <fwp_rc_dup+0x68>  // b.none
    55cc:	d65f03c0 	ret
    55d0:	17fffb81 	b	43d4 <fwp_rc_wide_dup>

00000000000055d4 <fwp_drop1>:
    55d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    55d8:	910003fd 	mov	x29, sp
    55dc:	a90153f3 	stp	x19, x20, [sp, #16]
    55e0:	f90013f5 	str	x21, [sp, #32]
    55e4:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    55e8:	911542b4 	add	x20, x21, #0x550
    55ec:	f949da81 	ldr	x1, [x20, #5040]
    55f0:	f949ee82 	ldr	x2, [x20, #5080]
    55f4:	cb010001 	sub	x1, x0, x1
    55f8:	eb02403f 	cmp	x1, x2, lsl #16
    55fc:	54000382 	b.cs	566c <fwp_drop1+0x98>  // b.hs, b.nlast
    5600:	d350fc22 	lsr	x2, x1, #16
    5604:	f949fe84 	ldr	x4, [x20, #5112]
    5608:	8b020842 	add	x2, x2, x2, lsl #2
    560c:	d37df042 	lsl	x2, x2, #3
    5610:	8b020083 	add	x3, x4, x2
    5614:	f9401073 	ldr	x19, [x3, #32]
    5618:	b40002b3 	cbz	x19, 566c <fwp_drop1+0x98>
    561c:	38626882 	ldrb	w2, [x4, x2]
    5620:	7100085f 	cmp	w2, #0x2
    5624:	540002c0 	b.eq	567c <fwp_drop1+0xa8>  // b.none
    5628:	7100045f 	cmp	w2, #0x1
    562c:	54000201 	b.ne	566c <fwp_drop1+0x98>  // b.any
    5630:	29430864 	ldp	w4, w2, [x3, #24]
    5634:	92403c21 	and	x1, x1, #0xffff
    5638:	9b047c21 	mul	x1, x1, x4
    563c:	d360fc21 	lsr	x1, x1, #32
    5640:	eb02003f 	cmp	x1, x2
    5644:	54000142 	b.cs	566c <fwp_drop1+0x98>  // b.hs, b.nlast
    5648:	8b010273 	add	x19, x19, x1
    564c:	39400261 	ldrb	w1, [x19]
    5650:	340000e1 	cbz	w1, 566c <fwp_drop1+0x98>
    5654:	7100043f 	cmp	w1, #0x1
    5658:	540001e0 	b.eq	5694 <fwp_drop1+0xc0>  // b.none
    565c:	7103fc3f 	cmp	w1, #0xff
    5660:	540002e0 	b.eq	56bc <fwp_drop1+0xe8>  // b.none
    5664:	51000421 	sub	w1, w1, #0x1
    5668:	39000261 	strb	w1, [x19]
    566c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5670:	f94013f5 	ldr	x21, [sp, #32]
    5674:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5678:	d65f03c0 	ret
    567c:	72003c3f 	tst	w1, #0xffff
    5680:	54fffe60 	b.eq	564c <fwp_drop1+0x78>  // b.none
    5684:	a94153f3 	ldp	x19, x20, [sp, #16]
    5688:	f94013f5 	ldr	x21, [sp, #32]
    568c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5690:	d65f03c0 	ret
    5694:	f9400813 	ldr	x19, [x0, #16]
    5698:	97ffff87 	bl	54b4 <fwp_rc_free_arr>
    569c:	911542a0 	add	x0, x21, #0x550
    56a0:	f949d801 	ldr	x1, [x0, #5040]
    56a4:	f949ec00 	ldr	x0, [x0, #5080]
    56a8:	cb010261 	sub	x1, x19, x1
    56ac:	eb00403f 	cmp	x1, x0, lsl #16
    56b0:	54fffde2 	b.cs	566c <fwp_drop1+0x98>  // b.hs, b.nlast
    56b4:	aa1303e0 	mov	x0, x19
    56b8:	17ffffd2 	b	5600 <fwp_drop1+0x2c>
    56bc:	ca534660 	eor	x0, x19, x19, lsr #17
    56c0:	911542b5 	add	x21, x21, #0x550
    56c4:	ca402400 	eor	x0, x0, x0, lsr #9
    56c8:	8b200ea0 	add	x0, x21, w0, uxtb #3
    56cc:	f94a2400 	ldr	x0, [x0, #5192]
    56d0:	b5000080 	cbnz	x0, 56e0 <fwp_drop1+0x10c>
    56d4:	14000010 	b	5714 <fwp_drop1+0x140>
    56d8:	f9400800 	ldr	x0, [x0, #16]
    56dc:	b40001c0 	cbz	x0, 5714 <fwp_drop1+0x140>
    56e0:	f9400001 	ldr	x1, [x0]
    56e4:	eb13003f 	cmp	x1, x19
    56e8:	54ffff81 	b.ne	56d8 <fwp_drop1+0x104>  // b.any
    56ec:	f9400401 	ldr	x1, [x0, #8]
    56f0:	d1000421 	sub	x1, x1, #0x1
    56f4:	f9000401 	str	x1, [x0, #8]
    56f8:	f103f83f 	cmp	x1, #0xfe
    56fc:	54fffb81 	b.ne	566c <fwp_drop1+0x98>  // b.any
    5700:	aa1303e0 	mov	x0, x19
    5704:	97fffb7b 	bl	44f0 <fwp_rc_forget_slot>
    5708:	12800020 	mov	w0, #0xfffffffe            	// #-2
    570c:	39000260 	strb	w0, [x19]
    5710:	17ffffd7 	b	566c <fwp_drop1+0x98>
    5714:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5718:	91132000 	add	x0, x0, #0x4c8
    571c:	97fff779 	bl	3500 <fwp_trap>

0000000000005720 <fwp_drop0>:
    5720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5724:	910003fd 	mov	x29, sp
    5728:	a90153f3 	stp	x19, x20, [sp, #16]
    572c:	f90013f5 	str	x21, [sp, #32]
    5730:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5734:	911542b4 	add	x20, x21, #0x550
    5738:	f949da81 	ldr	x1, [x20, #5040]
    573c:	f949ee82 	ldr	x2, [x20, #5080]
    5740:	cb010001 	sub	x1, x0, x1
    5744:	eb02403f 	cmp	x1, x2, lsl #16
    5748:	54000382 	b.cs	57b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    574c:	d350fc22 	lsr	x2, x1, #16
    5750:	f949fe84 	ldr	x4, [x20, #5112]
    5754:	8b020842 	add	x2, x2, x2, lsl #2
    5758:	d37df042 	lsl	x2, x2, #3
    575c:	8b020083 	add	x3, x4, x2
    5760:	f9401073 	ldr	x19, [x3, #32]
    5764:	b40002b3 	cbz	x19, 57b8 <fwp_drop0+0x98>
    5768:	38626882 	ldrb	w2, [x4, x2]
    576c:	7100085f 	cmp	w2, #0x2
    5770:	540002c0 	b.eq	57c8 <fwp_drop0+0xa8>  // b.none
    5774:	7100045f 	cmp	w2, #0x1
    5778:	54000201 	b.ne	57b8 <fwp_drop0+0x98>  // b.any
    577c:	29430864 	ldp	w4, w2, [x3, #24]
    5780:	92403c21 	and	x1, x1, #0xffff
    5784:	9b047c21 	mul	x1, x1, x4
    5788:	d360fc21 	lsr	x1, x1, #32
    578c:	eb02003f 	cmp	x1, x2
    5790:	54000142 	b.cs	57b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5794:	8b010273 	add	x19, x19, x1
    5798:	39400261 	ldrb	w1, [x19]
    579c:	340000e1 	cbz	w1, 57b8 <fwp_drop0+0x98>
    57a0:	7100043f 	cmp	w1, #0x1
    57a4:	540001e0 	b.eq	57e0 <fwp_drop0+0xc0>  // b.none
    57a8:	7103fc3f 	cmp	w1, #0xff
    57ac:	540002e0 	b.eq	5808 <fwp_drop0+0xe8>  // b.none
    57b0:	51000421 	sub	w1, w1, #0x1
    57b4:	39000261 	strb	w1, [x19]
    57b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    57bc:	f94013f5 	ldr	x21, [sp, #32]
    57c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57c4:	d65f03c0 	ret
    57c8:	72003c3f 	tst	w1, #0xffff
    57cc:	54fffe60 	b.eq	5798 <fwp_drop0+0x78>  // b.none
    57d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57d4:	f94013f5 	ldr	x21, [sp, #32]
    57d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57dc:	d65f03c0 	ret
    57e0:	f9400813 	ldr	x19, [x0, #16]
    57e4:	97ffff34 	bl	54b4 <fwp_rc_free_arr>
    57e8:	911542a0 	add	x0, x21, #0x550
    57ec:	f949d801 	ldr	x1, [x0, #5040]
    57f0:	f949ec00 	ldr	x0, [x0, #5080]
    57f4:	cb010261 	sub	x1, x19, x1
    57f8:	eb00403f 	cmp	x1, x0, lsl #16
    57fc:	54fffde2 	b.cs	57b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5800:	aa1303e0 	mov	x0, x19
    5804:	17ffffd2 	b	574c <fwp_drop0+0x2c>
    5808:	ca534660 	eor	x0, x19, x19, lsr #17
    580c:	911542b5 	add	x21, x21, #0x550
    5810:	ca402400 	eor	x0, x0, x0, lsr #9
    5814:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5818:	f94a2400 	ldr	x0, [x0, #5192]
    581c:	b5000080 	cbnz	x0, 582c <fwp_drop0+0x10c>
    5820:	14000010 	b	5860 <fwp_drop0+0x140>
    5824:	f9400800 	ldr	x0, [x0, #16]
    5828:	b40001c0 	cbz	x0, 5860 <fwp_drop0+0x140>
    582c:	f9400001 	ldr	x1, [x0]
    5830:	eb13003f 	cmp	x1, x19
    5834:	54ffff81 	b.ne	5824 <fwp_drop0+0x104>  // b.any
    5838:	f9400401 	ldr	x1, [x0, #8]
    583c:	d1000421 	sub	x1, x1, #0x1
    5840:	f9000401 	str	x1, [x0, #8]
    5844:	f103f83f 	cmp	x1, #0xfe
    5848:	54fffb81 	b.ne	57b8 <fwp_drop0+0x98>  // b.any
    584c:	aa1303e0 	mov	x0, x19
    5850:	97fffb28 	bl	44f0 <fwp_rc_forget_slot>
    5854:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5858:	39000260 	strb	w0, [x19]
    585c:	17ffffd7 	b	57b8 <fwp_drop0+0x98>
    5860:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5864:	91132000 	add	x0, x0, #0x4c8
    5868:	97fff726 	bl	3500 <fwp_trap>
    586c:	d503201f 	nop

0000000000005870 <fwp_arg_drop12>:
    5870:	7100003f 	cmp	w1, #0x0
    5874:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5878:	54000041 	b.ne	5880 <fwp_arg_drop12+0x10>  // b.any
    587c:	d65f03c0 	ret
    5880:	f9400000 	ldr	x0, [x0]
    5884:	17ffffa7 	b	5720 <fwp_drop0>
    5888:	d503201f 	nop
    588c:	d503201f 	nop

0000000000005890 <fwp_closure_drop>:
    5890:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5894:	911540a4 	add	x4, x5, #0x550
    5898:	aa0003e1 	mov	x1, x0
    589c:	f949d882 	ldr	x2, [x4, #5040]
    58a0:	f949ec80 	ldr	x0, [x4, #5080]
    58a4:	cb020022 	sub	x2, x1, x2
    58a8:	eb00405f 	cmp	x2, x0, lsl #16
    58ac:	54000662 	b.cs	5978 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    58b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    58b4:	d350fc43 	lsr	x3, x2, #16
    58b8:	910003fd 	mov	x29, sp
    58bc:	8b030863 	add	x3, x3, x3, lsl #2
    58c0:	f949fc84 	ldr	x4, [x4, #5112]
    58c4:	d37df063 	lsl	x3, x3, #3
    58c8:	f9000bf3 	str	x19, [sp, #16]
    58cc:	8b030080 	add	x0, x4, x3
    58d0:	f9401013 	ldr	x19, [x0, #32]
    58d4:	b40002b3 	cbz	x19, 5928 <fwp_closure_drop+0x98>
    58d8:	38636883 	ldrb	w3, [x4, x3]
    58dc:	7100087f 	cmp	w3, #0x2
    58e0:	54000420 	b.eq	5964 <fwp_closure_drop+0xd4>  // b.none
    58e4:	7100047f 	cmp	w3, #0x1
    58e8:	54000201 	b.ne	5928 <fwp_closure_drop+0x98>  // b.any
    58ec:	29430003 	ldp	w3, w0, [x0, #24]
    58f0:	92403c42 	and	x2, x2, #0xffff
    58f4:	9b037c42 	mul	x2, x2, x3
    58f8:	d360fc42 	lsr	x2, x2, #32
    58fc:	eb00005f 	cmp	x2, x0
    5900:	54000142 	b.cs	5928 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5904:	8b020273 	add	x19, x19, x2
    5908:	39400260 	ldrb	w0, [x19]
    590c:	340000e0 	cbz	w0, 5928 <fwp_closure_drop+0x98>
    5910:	7100041f 	cmp	w0, #0x1
    5914:	54000100 	b.eq	5934 <fwp_closure_drop+0xa4>  // b.none
    5918:	7103fc1f 	cmp	w0, #0xff
    591c:	54000300 	b.eq	597c <fwp_closure_drop+0xec>  // b.none
    5920:	51000400 	sub	w0, w0, #0x1
    5924:	39000260 	strb	w0, [x19]
    5928:	f9400bf3 	ldr	x19, [sp, #16]
    592c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5930:	d65f03c0 	ret
    5934:	d53bd040 	mrs	x0, tpidr_el0
    5938:	91400000 	add	x0, x0, #0x0, lsl #12
    593c:	91004000 	add	x0, x0, #0x10
    5940:	f9400000 	ldr	x0, [x0]
    5944:	b4000080 	cbz	x0, 5954 <fwp_closure_drop+0xc4>
    5948:	f9400bf3 	ldr	x19, [sp, #16]
    594c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5950:	17fff705 	b	3564 <fwp_closure_drop_push>
    5954:	f9400bf3 	ldr	x19, [sp, #16]
    5958:	aa0103e0 	mov	x0, x1
    595c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5960:	17fff770 	b	3720 <fwp_closure_drop.part.0>
    5964:	72003c5f 	tst	w2, #0xffff
    5968:	54fffd00 	b.eq	5908 <fwp_closure_drop+0x78>  // b.none
    596c:	f9400bf3 	ldr	x19, [sp, #16]
    5970:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5974:	d65f03c0 	ret
    5978:	d65f03c0 	ret
    597c:	ca534660 	eor	x0, x19, x19, lsr #17
    5980:	911540a5 	add	x5, x5, #0x550
    5984:	ca402400 	eor	x0, x0, x0, lsr #9
    5988:	8b200ca0 	add	x0, x5, w0, uxtb #3
    598c:	f94a2400 	ldr	x0, [x0, #5192]
    5990:	b5000080 	cbnz	x0, 59a0 <fwp_closure_drop+0x110>
    5994:	14000010 	b	59d4 <fwp_closure_drop+0x144>
    5998:	f9400800 	ldr	x0, [x0, #16]
    599c:	b40001c0 	cbz	x0, 59d4 <fwp_closure_drop+0x144>
    59a0:	f9400001 	ldr	x1, [x0]
    59a4:	eb13003f 	cmp	x1, x19
    59a8:	54ffff81 	b.ne	5998 <fwp_closure_drop+0x108>  // b.any
    59ac:	f9400401 	ldr	x1, [x0, #8]
    59b0:	d1000421 	sub	x1, x1, #0x1
    59b4:	f9000401 	str	x1, [x0, #8]
    59b8:	f103f83f 	cmp	x1, #0xfe
    59bc:	54fffb61 	b.ne	5928 <fwp_closure_drop+0x98>  // b.any
    59c0:	aa1303e0 	mov	x0, x19
    59c4:	97fffacb 	bl	44f0 <fwp_rc_forget_slot>
    59c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    59cc:	39000260 	strb	w0, [x19]
    59d0:	17ffffd6 	b	5928 <fwp_closure_drop+0x98>
    59d4:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    59d8:	91132000 	add	x0, x0, #0x4c8
    59dc:	97fff6c9 	bl	3500 <fwp_trap>

00000000000059e0 <fwp_owned_tape_release>:
    59e0:	b4000940 	cbz	x0, 5b08 <fwp_owned_tape_release+0x128>
    59e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    59e8:	910003fd 	mov	x29, sp
    59ec:	a90153f3 	stp	x19, x20, [sp, #16]
    59f0:	aa0003f3 	mov	x19, x0
    59f4:	f9400000 	ldr	x0, [x0]
    59f8:	b4000060 	cbz	x0, 5a04 <fwp_owned_tape_release+0x24>
    59fc:	f9400661 	ldr	x1, [x19, #8]
    5a00:	f9000401 	str	x1, [x0, #8]
    5a04:	f9400661 	ldr	x1, [x19, #8]
    5a08:	b4000041 	cbz	x1, 5a10 <fwp_owned_tape_release+0x30>
    5a0c:	f9000020 	str	x0, [x1]
    5a10:	f9400a60 	ldr	x0, [x19, #16]
    5a14:	f9403401 	ldr	x1, [x0, #104]
    5a18:	b40005c1 	cbz	x1, 5ad0 <fwp_owned_tape_release+0xf0>
    5a1c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5a20:	eb00005f 	cmp	x2, x0
    5a24:	540002ed 	b.le	5a80 <fwp_owned_tape_release+0xa0>
    5a28:	d2800014 	mov	x20, #0x0                   	// #0
    5a2c:	f90013f5 	str	x21, [sp, #32]
    5a30:	d2800015 	mov	x21, #0x0                   	// #0
    5a34:	d503201f 	nop
    5a38:	f9402260 	ldr	x0, [x19, #64]
    5a3c:	910006b5 	add	x21, x21, #0x1
    5a40:	f8746800 	ldr	x0, [x0, x20]
    5a44:	d63f0020 	blr	x1
    5a48:	f9402260 	ldr	x0, [x19, #64]
    5a4c:	f9400a61 	ldr	x1, [x19, #16]
    5a50:	8b140000 	add	x0, x0, x20
    5a54:	91004294 	add	x20, x20, #0x10
    5a58:	f9400400 	ldr	x0, [x0, #8]
    5a5c:	f9403421 	ldr	x1, [x1, #104]
    5a60:	d63f0020 	blr	x1
    5a64:	a9450261 	ldp	x1, x0, [x19, #80]
    5a68:	cb010000 	sub	x0, x0, x1
    5a6c:	eb15001f 	cmp	x0, x21
    5a70:	f9400a60 	ldr	x0, [x19, #16]
    5a74:	f9403401 	ldr	x1, [x0, #104]
    5a78:	54fffe0c 	b.gt	5a38 <fwp_owned_tape_release+0x58>
    5a7c:	f94013f5 	ldr	x21, [sp, #32]
    5a80:	f9403663 	ldr	x3, [x19, #104]
    5a84:	f9401262 	ldr	x2, [x19, #32]
    5a88:	f100007f 	cmp	x3, #0x0
    5a8c:	540001ed 	b.le	5ac8 <fwp_owned_tape_release+0xe8>
    5a90:	d2800014 	mov	x20, #0x0                   	// #0
    5a94:	d503201f 	nop
    5a98:	f9402660 	ldr	x0, [x19, #72]
    5a9c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5aa0:	eb02001f 	cmp	x0, x2
    5aa4:	540000c0 	b.eq	5abc <fwp_owned_tape_release+0xdc>  // b.none
    5aa8:	d63f0020 	blr	x1
    5aac:	f9400a60 	ldr	x0, [x19, #16]
    5ab0:	f9401262 	ldr	x2, [x19, #32]
    5ab4:	f9403663 	ldr	x3, [x19, #104]
    5ab8:	f9403401 	ldr	x1, [x0, #104]
    5abc:	91000694 	add	x20, x20, #0x1
    5ac0:	eb14007f 	cmp	x3, x20
    5ac4:	54fffeac 	b.gt	5a98 <fwp_owned_tape_release+0xb8>
    5ac8:	aa0203e0 	mov	x0, x2
    5acc:	d63f0020 	blr	x1
    5ad0:	f9401660 	ldr	x0, [x19, #40]
    5ad4:	97ffff6f 	bl	5890 <fwp_closure_drop>
    5ad8:	f9401a60 	ldr	x0, [x19, #48]
    5adc:	97ffff6d 	bl	5890 <fwp_closure_drop>
    5ae0:	f9401e60 	ldr	x0, [x19, #56]
    5ae4:	97ffff6b 	bl	5890 <fwp_closure_drop>
    5ae8:	f9402260 	ldr	x0, [x19, #64]
    5aec:	97fffb21 	bl	4770 <fwp_mem_free>
    5af0:	f9402660 	ldr	x0, [x19, #72]
    5af4:	97fffb1f 	bl	4770 <fwp_mem_free>
    5af8:	aa1303e0 	mov	x0, x19
    5afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b04:	17fffb1b 	b	4770 <fwp_mem_free>
    5b08:	d65f03c0 	ret
    5b0c:	d503201f 	nop

0000000000005b10 <fwp_tape_finish>:
    5b10:	d10203ff 	sub	sp, sp, #0x80
    5b14:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5b18:	f947f421 	ldr	x1, [x1, #4072]
    5b1c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5b20:	910103fd 	add	x29, sp, #0x40
    5b24:	a90553f3 	stp	x19, x20, [sp, #80]
    5b28:	a9065bf5 	stp	x21, x22, [sp, #96]
    5b2c:	a90763f7 	stp	x23, x24, [sp, #112]
    5b30:	f00000d8 	adrp	x24, 20000 <__data_start>
    5b34:	91010316 	add	x22, x24, #0x40
    5b38:	f9400022 	ldr	x2, [x1]
    5b3c:	f9001fe2 	str	x2, [sp, #56]
    5b40:	d2800002 	mov	x2, #0x0                   	// #0
    5b44:	910122c0 	add	x0, x22, #0x48
    5b48:	97fff5ce 	bl	3280 <fwp_tape_buffers_dispose>
    5b4c:	f90042df 	str	xzr, [x22, #128]
    5b50:	f94022c0 	ldr	x0, [x22, #64]
    5b54:	f100001f 	cmp	x0, #0x0
    5b58:	5400030d 	b.le	5bb8 <fwp_tape_finish+0xa8>
    5b5c:	910003f7 	mov	x23, sp
    5b60:	d2800015 	mov	x21, #0x0                   	// #0
    5b64:	d2800014 	mov	x20, #0x0                   	// #0
    5b68:	f94002d3 	ldr	x19, [x22]
    5b6c:	91000694 	add	x20, x20, #0x1
    5b70:	8b150273 	add	x19, x19, x21
    5b74:	9101a2b5 	add	x21, x21, #0x68
    5b78:	aa1303e0 	mov	x0, x19
    5b7c:	97fff4e5 	bl	2f10 <fwp_tape_unlink_scope>
    5b80:	aa1703e0 	mov	x0, x23
    5b84:	f9401261 	ldr	x1, [x19, #32]
    5b88:	f90003e1 	str	x1, [sp]
    5b8c:	f9401a62 	ldr	x2, [x19, #48]
    5b90:	f9000be2 	str	x2, [sp, #16]
    5b94:	f9402261 	ldr	x1, [x19, #64]
    5b98:	f90013e1 	str	x1, [sp, #32]
    5b9c:	97fff5b9 	bl	3280 <fwp_tape_buffers_dispose>
    5ba0:	f9403260 	ldr	x0, [x19, #96]
    5ba4:	97ffff8f 	bl	59e0 <fwp_owned_tape_release>
    5ba8:	f900327f 	str	xzr, [x19, #96]
    5bac:	f94022c0 	ldr	x0, [x22, #64]
    5bb0:	eb14001f 	cmp	x0, x20
    5bb4:	54fffdac 	b.gt	5b68 <fwp_tape_finish+0x58>
    5bb8:	f9402300 	ldr	x0, [x24, #64]
    5bbc:	91010313 	add	x19, x24, #0x40
    5bc0:	97fff33c 	bl	28b0 <free@plt>
    5bc4:	f900231f 	str	xzr, [x24, #64]
    5bc8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5bcc:	f947f400 	ldr	x0, [x0, #4072]
    5bd0:	f900227f 	str	xzr, [x19, #64]
    5bd4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5bd8:	f9401fe2 	ldr	x2, [sp, #56]
    5bdc:	f9400001 	ldr	x1, [x0]
    5be0:	eb010042 	subs	x2, x2, x1
    5be4:	d2800001 	mov	x1, #0x0                   	// #0
    5be8:	540000e1 	b.ne	5c04 <fwp_tape_finish+0xf4>  // b.any
    5bec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5bf0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5bf4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5bf8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5bfc:	910203ff 	add	sp, sp, #0x80
    5c00:	d65f03c0 	ret
    5c04:	97fff2fb 	bl	27f0 <__stack_chk_fail@plt>
    5c08:	d503201f 	nop
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_tape_scope_release>:
    5c10:	d10243ff 	sub	sp, sp, #0x90
    5c14:	a9047bfd 	stp	x29, x30, [sp, #64]
    5c18:	910103fd 	add	x29, sp, #0x40
    5c1c:	a90553f3 	stp	x19, x20, [sp, #80]
    5c20:	aa0003f4 	mov	x20, x0
    5c24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c28:	f947f400 	ldr	x0, [x0, #4072]
    5c2c:	b9400285 	ldr	w5, [x20]
    5c30:	f9400001 	ldr	x1, [x0]
    5c34:	f9001fe1 	str	x1, [sp, #56]
    5c38:	d2800001 	mov	x1, #0x0                   	// #0
    5c3c:	37f806c5 	tbnz	w5, #31, 5d14 <fwp_tape_scope_release+0x104>
    5c40:	a90763f7 	stp	x23, x24, [sp, #112]
    5c44:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5c48:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5c4c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5c50:	f00000d3 	adrp	x19, 20000 <__data_start>
    5c54:	910003f7 	mov	x23, sp
    5c58:	91010273 	add	x19, x19, #0x40
    5c5c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5c60:	a9065bf5 	stp	x21, x22, [sp, #96]
    5c64:	52800d16 	mov	w22, #0x68                  	// #104
    5c68:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5c6c:	f90043f9 	str	x25, [sp, #128]
    5c70:	14000006 	b	5c88 <fwp_tape_scope_release+0x78>
    5c74:	97fff583 	bl	3280 <fwp_tape_buffers_dispose>
    5c78:	aa1903e0 	mov	x0, x25
    5c7c:	97ffff59 	bl	59e0 <fwp_owned_tape_release>
    5c80:	b9400285 	ldr	w5, [x20]
    5c84:	37f80425 	tbnz	w5, #31, 5d08 <fwp_tape_scope_release+0xf8>
    5c88:	f9400266 	ldr	x6, [x19]
    5c8c:	9b367ca5 	smull	x5, w5, w22
    5c90:	8b0500c0 	add	x0, x6, x5
    5c94:	97fff49f 	bl	2f10 <fwp_tape_unlink_scope>
    5c98:	ad410001 	ldp	q1, q0, [x0, #32]
    5c9c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5ca0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5ca4:	f9400c03 	ldr	x3, [x0, #24]
    5ca8:	ad0003e1 	stp	q1, q0, [sp]
    5cac:	b86568c1 	ldr	w1, [x6, x5]
    5cb0:	a9440804 	ldp	x4, x2, [x0, #64]
    5cb4:	b900041f 	str	wzr, [x0, #4]
    5cb8:	f9403019 	ldr	x25, [x0, #96]
    5cbc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5cc0:	f9000c1f 	str	xzr, [x0, #24]
    5cc4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5cc8:	f9001be2 	str	x2, [sp, #48]
    5ccc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5cd0:	f900301f 	str	xzr, [x0, #96]
    5cd4:	6b15003f 	cmp	w1, w21
    5cd8:	540000e8 	b.hi	5cf4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5cdc:	9343fca5 	asr	x5, x5, #3
    5ce0:	f9404e60 	ldr	x0, [x19, #152]
    5ce4:	9b187ca5 	mul	x5, x5, x24
    5ce8:	eb0000bf 	cmp	x5, x0
    5cec:	5400004a 	b.ge	5cf4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5cf0:	f9004e65 	str	x5, [x19, #152]
    5cf4:	aa1703e0 	mov	x0, x23
    5cf8:	b5fffbf9 	cbnz	x25, 5c74 <fwp_tape_scope_release+0x64>
    5cfc:	97fff8e1 	bl	4080 <fwp_tape_buffers_release>
    5d00:	b9400285 	ldr	w5, [x20]
    5d04:	36fffc25 	tbz	w5, #31, 5c88 <fwp_tape_scope_release+0x78>
    5d08:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5d0c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5d10:	f94043f9 	ldr	x25, [sp, #128]
    5d14:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d18:	f947f400 	ldr	x0, [x0, #4072]
    5d1c:	f9401fe2 	ldr	x2, [sp, #56]
    5d20:	f9400001 	ldr	x1, [x0]
    5d24:	eb010042 	subs	x2, x2, x1
    5d28:	d2800001 	mov	x1, #0x0                   	// #0
    5d2c:	540000a1 	b.ne	5d40 <fwp_tape_scope_release+0x130>  // b.any
    5d30:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5d34:	a94553f3 	ldp	x19, x20, [sp, #80]
    5d38:	910243ff 	add	sp, sp, #0x90
    5d3c:	d65f03c0 	ret
    5d40:	a9065bf5 	stp	x21, x22, [sp, #96]
    5d44:	a90763f7 	stp	x23, x24, [sp, #112]
    5d48:	f90043f9 	str	x25, [sp, #128]
    5d4c:	97fff2a9 	bl	27f0 <__stack_chk_fail@plt>

0000000000005d50 <fwp_task_dispose>:
    5d50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d54:	910003fd 	mov	x29, sp
    5d58:	f9000bf3 	str	x19, [sp, #16]
    5d5c:	aa0003f3 	mov	x19, x0
    5d60:	39414000 	ldrb	w0, [x0, #80]
    5d64:	36000720 	tbz	w0, #0, 5e48 <fwp_task_dispose+0xf8>
    5d68:	f9400a60 	ldr	x0, [x19, #16]
    5d6c:	b50006e0 	cbnz	x0, 5e48 <fwp_task_dispose+0xf8>
    5d70:	a9478660 	ldp	x0, x1, [x19, #120]
    5d74:	39014e7f 	strb	wzr, [x19, #83]
    5d78:	f9003e7f 	str	xzr, [x19, #120]
    5d7c:	f100003f 	cmp	x1, #0x0
    5d80:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    5d84:	54000040 	b.eq	5d8c <fwp_task_dispose+0x3c>  // b.none
    5d88:	d63f0020 	blr	x1
    5d8c:	f9405660 	ldr	x0, [x19, #168]
    5d90:	97fffa78 	bl	4770 <fwp_mem_free>
    5d94:	f900567f 	str	xzr, [x19, #168]
    5d98:	b9405e60 	ldr	w0, [x19, #92]
    5d9c:	7100041f 	cmp	w0, #0x1
    5da0:	54000420 	b.eq	5e24 <fwp_task_dispose+0xd4>  // b.none
    5da4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5da8:	91154042 	add	x2, x2, #0x550
    5dac:	f949d840 	ldr	x0, [x2, #5040]
    5db0:	f949ec41 	ldr	x1, [x2, #5080]
    5db4:	cb000260 	sub	x0, x19, x0
    5db8:	eb01401f 	cmp	x0, x1, lsl #16
    5dbc:	540002e2 	b.cs	5e18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5dc0:	d350fc01 	lsr	x1, x0, #16
    5dc4:	f949fc44 	ldr	x4, [x2, #5112]
    5dc8:	8b010821 	add	x1, x1, x1, lsl #2
    5dcc:	d37df021 	lsl	x1, x1, #3
    5dd0:	8b010083 	add	x3, x4, x1
    5dd4:	f9401062 	ldr	x2, [x3, #32]
    5dd8:	b4000202 	cbz	x2, 5e18 <fwp_task_dispose+0xc8>
    5ddc:	38616881 	ldrb	w1, [x4, x1]
    5de0:	7100083f 	cmp	w1, #0x2
    5de4:	54000280 	b.eq	5e34 <fwp_task_dispose+0xe4>  // b.none
    5de8:	7100043f 	cmp	w1, #0x1
    5dec:	54000161 	b.ne	5e18 <fwp_task_dispose+0xc8>  // b.any
    5df0:	29430464 	ldp	w4, w1, [x3, #24]
    5df4:	92403c00 	and	x0, x0, #0xffff
    5df8:	9b047c00 	mul	x0, x0, x4
    5dfc:	d360fc00 	lsr	x0, x0, #32
    5e00:	eb01001f 	cmp	x0, x1
    5e04:	540000a2 	b.cs	5e18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5e08:	8b000042 	add	x2, x2, x0
    5e0c:	39400040 	ldrb	w0, [x2]
    5e10:	7100041f 	cmp	w0, #0x1
    5e14:	54000080 	b.eq	5e24 <fwp_task_dispose+0xd4>  // b.none
    5e18:	f9400bf3 	ldr	x19, [sp, #16]
    5e1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e20:	d65f03c0 	ret
    5e24:	aa1303e0 	mov	x0, x19
    5e28:	f9400bf3 	ldr	x19, [sp, #16]
    5e2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e30:	17fffa50 	b	4770 <fwp_mem_free>
    5e34:	72003c1f 	tst	w0, #0xffff
    5e38:	54fffea0 	b.eq	5e0c <fwp_task_dispose+0xbc>  // b.none
    5e3c:	f9400bf3 	ldr	x19, [sp, #16]
    5e40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e44:	d65f03c0 	ret
    5e48:	97fff27e 	bl	2840 <abort@plt>
    5e4c:	d503201f 	nop

0000000000005e50 <fwp_free_zombie>:
    5e50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e54:	910003fd 	mov	x29, sp
    5e58:	a90153f3 	stp	x19, x20, [sp, #16]
    5e5c:	f00000d4 	adrp	x20, 20000 <__data_start>
    5e60:	91010281 	add	x1, x20, #0x40
    5e64:	f9405033 	ldr	x19, [x1, #160]
    5e68:	b4000333 	cbz	x19, 5ecc <fwp_free_zombie+0x7c>
    5e6c:	f9400820 	ldr	x0, [x1, #16]
    5e70:	eb00027f 	cmp	x19, x0
    5e74:	540002c0 	b.eq	5ecc <fwp_free_zombie+0x7c>  // b.none
    5e78:	b940a822 	ldr	w2, [x1, #168]
    5e7c:	f9400a60 	ldr	x0, [x19, #16]
    5e80:	7100fc5f 	cmp	w2, #0x3f
    5e84:	5400078c 	b.gt	5f74 <fwp_free_zombie+0x124>
    5e88:	9102c023 	add	x3, x1, #0xb0
    5e8c:	11000444 	add	w4, w2, #0x1
    5e90:	b900a824 	str	w4, [x1, #168]
    5e94:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    5e98:	f822d860 	str	x0, [x3, w2, sxtw #3]
    5e9c:	a9530261 	ldp	x1, x0, [x19, #304]
    5ea0:	b4000741 	cbz	x1, 5f88 <fwp_free_zombie+0x138>
    5ea4:	f9009c20 	str	x0, [x1, #312]
    5ea8:	b4000040 	cbz	x0, 5eb0 <fwp_free_zombie+0x60>
    5eac:	f9009801 	str	x1, [x0, #304]
    5eb0:	91010294 	add	x20, x20, #0x40
    5eb4:	b9405e60 	ldr	w0, [x19, #92]
    5eb8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    5ebc:	f900529f 	str	xzr, [x20, #160]
    5ec0:	34000140 	cbz	w0, 5ee8 <fwp_free_zombie+0x98>
    5ec4:	7100041f 	cmp	w0, #0x1
    5ec8:	54000080 	b.eq	5ed8 <fwp_free_zombie+0x88>  // b.none
    5ecc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ed0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed4:	d65f03c0 	ret
    5ed8:	aa1303e0 	mov	x0, x19
    5edc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ee0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ee4:	17ffff9b 	b	5d50 <fwp_task_dispose>
    5ee8:	90000164 	adrp	x4, 31000 <fwp_root_context+0xc90>
    5eec:	91154082 	add	x2, x4, #0x550
    5ef0:	f949d841 	ldr	x1, [x2, #5040]
    5ef4:	f949ec40 	ldr	x0, [x2, #5080]
    5ef8:	cb010261 	sub	x1, x19, x1
    5efc:	eb00403f 	cmp	x1, x0, lsl #16
    5f00:	54fffe62 	b.cs	5ecc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    5f04:	d350fc20 	lsr	x0, x1, #16
    5f08:	f949fc43 	ldr	x3, [x2, #5112]
    5f0c:	8b000800 	add	x0, x0, x0, lsl #2
    5f10:	d37df000 	lsl	x0, x0, #3
    5f14:	8b000062 	add	x2, x3, x0
    5f18:	f9401054 	ldr	x20, [x2, #32]
    5f1c:	b4fffd94 	cbz	x20, 5ecc <fwp_free_zombie+0x7c>
    5f20:	38606860 	ldrb	w0, [x3, x0]
    5f24:	7100081f 	cmp	w0, #0x2
    5f28:	54000360 	b.eq	5f94 <fwp_free_zombie+0x144>  // b.none
    5f2c:	7100041f 	cmp	w0, #0x1
    5f30:	54fffce1 	b.ne	5ecc <fwp_free_zombie+0x7c>  // b.any
    5f34:	29430043 	ldp	w3, w0, [x2, #24]
    5f38:	92403c21 	and	x1, x1, #0xffff
    5f3c:	9b037c21 	mul	x1, x1, x3
    5f40:	d360fc21 	lsr	x1, x1, #32
    5f44:	eb00003f 	cmp	x1, x0
    5f48:	54fffc22 	b.cs	5ecc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    5f4c:	8b010294 	add	x20, x20, x1
    5f50:	39400280 	ldrb	w0, [x20]
    5f54:	34fffbc0 	cbz	w0, 5ecc <fwp_free_zombie+0x7c>
    5f58:	7100041f 	cmp	w0, #0x1
    5f5c:	54fffbe0 	b.eq	5ed8 <fwp_free_zombie+0x88>  // b.none
    5f60:	7103fc1f 	cmp	w0, #0xff
    5f64:	540001e0 	b.eq	5fa0 <fwp_free_zombie+0x150>  // b.none
    5f68:	51000400 	sub	w0, w0, #0x1
    5f6c:	39000280 	strb	w0, [x20]
    5f70:	17ffffd7 	b	5ecc <fwp_free_zombie+0x7c>
    5f74:	f9400e61 	ldr	x1, [x19, #24]
    5f78:	97fff266 	bl	2910 <munmap@plt>
    5f7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    5f80:	a9530261 	ldp	x1, x0, [x19, #304]
    5f84:	b5fff901 	cbnz	x1, 5ea4 <fwp_free_zombie+0x54>
    5f88:	91010282 	add	x2, x20, #0x40
    5f8c:	f9015840 	str	x0, [x2, #688]
    5f90:	17ffffc6 	b	5ea8 <fwp_free_zombie+0x58>
    5f94:	72003c3f 	tst	w1, #0xffff
    5f98:	54fff9a1 	b.ne	5ecc <fwp_free_zombie+0x7c>  // b.any
    5f9c:	17ffffed 	b	5f50 <fwp_free_zombie+0x100>
    5fa0:	ca544680 	eor	x0, x20, x20, lsr #17
    5fa4:	91154084 	add	x4, x4, #0x550
    5fa8:	ca402400 	eor	x0, x0, x0, lsr #9
    5fac:	8b200c80 	add	x0, x4, w0, uxtb #3
    5fb0:	f94a2400 	ldr	x0, [x0, #5192]
    5fb4:	b5000080 	cbnz	x0, 5fc4 <fwp_free_zombie+0x174>
    5fb8:	14000010 	b	5ff8 <fwp_free_zombie+0x1a8>
    5fbc:	f9400800 	ldr	x0, [x0, #16]
    5fc0:	b40001c0 	cbz	x0, 5ff8 <fwp_free_zombie+0x1a8>
    5fc4:	f9400001 	ldr	x1, [x0]
    5fc8:	eb14003f 	cmp	x1, x20
    5fcc:	54ffff81 	b.ne	5fbc <fwp_free_zombie+0x16c>  // b.any
    5fd0:	f9400401 	ldr	x1, [x0, #8]
    5fd4:	d1000421 	sub	x1, x1, #0x1
    5fd8:	f9000401 	str	x1, [x0, #8]
    5fdc:	f103f83f 	cmp	x1, #0xfe
    5fe0:	54fff761 	b.ne	5ecc <fwp_free_zombie+0x7c>  // b.any
    5fe4:	aa1403e0 	mov	x0, x20
    5fe8:	97fff942 	bl	44f0 <fwp_rc_forget_slot>
    5fec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ff0:	39000280 	strb	w0, [x20]
    5ff4:	17ffffb6 	b	5ecc <fwp_free_zombie+0x7c>
    5ff8:	d0000020 	adrp	x0, b000 <__modti3+0x180>
    5ffc:	91132000 	add	x0, x0, #0x4c8
    6000:	97fff540 	bl	3500 <fwp_trap>

0000000000006004 <fwp_block>:
    6004:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6008:	910003fd 	mov	x29, sp
    600c:	a90153f3 	stp	x19, x20, [sp, #16]
    6010:	d00000d3 	adrp	x19, 20000 <__data_start>
    6014:	91010274 	add	x20, x19, #0x40
    6018:	f9401a82 	ldr	x2, [x20, #48]
    601c:	b4000622 	cbz	x2, 60e0 <fwp_block+0xdc>
    6020:	91010261 	add	x1, x19, #0x40
    6024:	f9408040 	ldr	x0, [x2, #256]
    6028:	f9001820 	str	x0, [x1, #48]
    602c:	b4000680 	cbz	x0, 60fc <fwp_block+0xf8>
    6030:	91010263 	add	x3, x19, #0x40
    6034:	3901505f 	strb	wzr, [x2, #84]
    6038:	f9400864 	ldr	x4, [x3, #16]
    603c:	eb02009f 	cmp	x4, x2
    6040:	54000440 	b.eq	60c8 <fwp_block+0xc4>  // b.none
    6044:	f9415c65 	ldr	x5, [x3, #696]
    6048:	f9000862 	str	x2, [x3, #16]
    604c:	f9400441 	ldr	x1, [x2, #8]
    6050:	f9004885 	str	x5, [x4, #144]
    6054:	f9416065 	ldr	x5, [x3, #704]
    6058:	f9004c85 	str	x5, [x4, #152]
    605c:	f9416465 	ldr	x5, [x3, #712]
    6060:	f9005085 	str	x5, [x4, #160]
    6064:	f9416865 	ldr	x5, [x3, #720]
    6068:	f9005485 	str	x5, [x4, #168]
    606c:	f9416c65 	ldr	x5, [x3, #728]
    6070:	f9005885 	str	x5, [x4, #176]
    6074:	f9417065 	ldr	x5, [x3, #736]
    6078:	f9005c85 	str	x5, [x4, #184]
    607c:	f9417465 	ldr	x5, [x3, #744]
    6080:	f9006085 	str	x5, [x4, #192]
    6084:	f9400480 	ldr	x0, [x4, #8]
    6088:	f9404844 	ldr	x4, [x2, #144]
    608c:	f9015c64 	str	x4, [x3, #696]
    6090:	f9404c44 	ldr	x4, [x2, #152]
    6094:	f9016064 	str	x4, [x3, #704]
    6098:	f9405044 	ldr	x4, [x2, #160]
    609c:	f9016464 	str	x4, [x3, #712]
    60a0:	f9405444 	ldr	x4, [x2, #168]
    60a4:	f9016864 	str	x4, [x3, #720]
    60a8:	f9405844 	ldr	x4, [x2, #176]
    60ac:	f9016c64 	str	x4, [x3, #728]
    60b0:	a94b8844 	ldp	x4, x2, [x2, #184]
    60b4:	f9017064 	str	x4, [x3, #736]
    60b8:	f9017462 	str	x2, [x3, #744]
    60bc:	97fff1e5 	bl	2850 <swapcontext@plt>
    60c0:	97ffff64 	bl	5e50 <fwp_free_zombie>
    60c4:	d503201f 	nop
    60c8:	91010260 	add	x0, x19, #0x40
    60cc:	b942f000 	ldr	w0, [x0, #752]
    60d0:	340001a0 	cbz	w0, 6104 <fwp_block+0x100>
    60d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    60d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60dc:	d65f03c0 	ret
    60e0:	97fff830 	bl	41a0 <fwp_poll_events>
    60e4:	f9401a82 	ldr	x2, [x20, #48]
    60e8:	b4ffffc2 	cbz	x2, 60e0 <fwp_block+0xdc>
    60ec:	91010261 	add	x1, x19, #0x40
    60f0:	f9408040 	ldr	x0, [x2, #256]
    60f4:	f9001820 	str	x0, [x1, #48]
    60f8:	b5fff9c0 	cbnz	x0, 6030 <fwp_block+0x2c>
    60fc:	f900143f 	str	xzr, [x1, #40]
    6100:	17ffffcc 	b	6030 <fwp_block+0x2c>
    6104:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    6108:	9117e000 	add	x0, x0, #0x5f8
    610c:	97fff21d 	bl	2980 <getenv@plt>
    6110:	5284e202 	mov	w2, #0x2710                	// #10000
    6114:	b4000060 	cbz	x0, 6120 <fwp_block+0x11c>
    6118:	39400001 	ldrb	w1, [x0]
    611c:	350000c1 	cbnz	w1, 6134 <fwp_block+0x130>
    6120:	91010273 	add	x19, x19, #0x40
    6124:	b902f262 	str	w2, [x19, #752]
    6128:	a94153f3 	ldp	x19, x20, [sp, #16]
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	d65f03c0 	ret
    6134:	52800142 	mov	w2, #0xa                   	// #10
    6138:	d2800001 	mov	x1, #0x0                   	// #0
    613c:	97fff161 	bl	26c0 <strtoll@plt>
    6140:	d1000403 	sub	x3, x0, #0x1
    6144:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6148:	eb02007f 	cmp	x3, x2
    614c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6150:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6154:	17fffff3 	b	6120 <fwp_block+0x11c>
    6158:	d503201f 	nop
    615c:	d503201f 	nop

0000000000006160 <fwp_owned_entry161>:
    6160:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6164:	910003fd 	mov	x29, sp
    6168:	a90363f7 	stp	x23, x24, [sp, #48]
    616c:	a9406002 	ldp	x2, x24, [x0]
    6170:	a90153f3 	stp	x19, x20, [sp, #16]
    6174:	f9400801 	ldr	x1, [x0, #16]
    6178:	a9025bf5 	stp	x21, x22, [sp, #32]
    617c:	ab010055 	adds	x21, x2, x1
    6180:	54000d06 	b.vs	6320 <fwp_owned_entry161+0x1c0>
    6184:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    6188:	91154281 	add	x1, x20, #0x550
    618c:	b953a420 	ldr	w0, [x1, #5028]
    6190:	34000a80 	cbz	w0, 62e0 <fwp_owned_entry161+0x180>
    6194:	397e8820 	ldrb	w0, [x1, #4002]
    6198:	910f0002 	add	x2, x0, #0x3c0
    619c:	8b000400 	add	x0, x0, x0, lsl #1
    61a0:	d37df000 	lsl	x0, x0, #3
    61a4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    61a8:	2a1703f6 	mov	w22, w23
    61ac:	f8606833 	ldr	x19, [x1, x0]
    61b0:	b4000853 	cbz	x19, 62b8 <fwp_owned_entry161+0x158>
    61b4:	f9400262 	ldr	x2, [x19]
    61b8:	aa2203e2 	mvn	x2, x2
    61bc:	f8206822 	str	x2, [x1, x0]
    61c0:	f10062df 	cmp	x22, #0x18
    61c4:	540000e9 	b.ls	61e0 <fwp_owned_entry161+0x80>  // b.plast
    61c8:	d10066c2 	sub	x2, x22, #0x19
    61cc:	91006260 	add	x0, x19, #0x18
    61d0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    61d4:	52800001 	mov	w1, #0x0                   	// #0
    61d8:	91002042 	add	x2, x2, #0x8
    61dc:	97fff179 	bl	27c0 <memset@plt>
    61e0:	91154281 	add	x1, x20, #0x550
    61e4:	f94a1020 	ldr	x0, [x1, #5152]
    61e8:	ab160000 	adds	x0, x0, x22
    61ec:	540009c2 	b.cs	6324 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    61f0:	f94a1422 	ldr	x2, [x1, #5160]
    61f4:	f90a1020 	str	x0, [x1, #5152]
    61f8:	eb02001f 	cmp	x0, x2
    61fc:	54000049 	b.ls	6204 <fwp_owned_entry161+0xa4>  // b.plast
    6200:	f90a1420 	str	x0, [x1, #5160]
    6204:	91154280 	add	x0, x20, #0x550
    6208:	1e6302e1 	ucvtf	d1, w23
    620c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6210:	1e612800 	fadd	d0, d0, d1
    6214:	fd0a1c00 	str	d0, [x0, #5176]
    6218:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    621c:	91154294 	add	x20, x20, #0x550
    6220:	a900d678 	stp	x24, x21, [x19, #8]
    6224:	fd477800 	ldr	d0, [x0, #3824]
    6228:	fd000260 	str	d0, [x19]
    622c:	f949da81 	ldr	x1, [x20, #5040]
    6230:	f949ee80 	ldr	x0, [x20, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54000322 	b.cs	62a0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6240:	d350fc20 	lsr	x0, x1, #16
    6244:	f949fe83 	ldr	x3, [x20, #5112]
    6248:	8b000800 	add	x0, x0, x0, lsl #2
    624c:	d37df002 	lsl	x2, x0, #3
    6250:	8b020060 	add	x0, x3, x2
    6254:	f9401014 	ldr	x20, [x0, #32]
    6258:	b4000254 	cbz	x20, 62a0 <fwp_owned_entry161+0x140>
    625c:	38626862 	ldrb	w2, [x3, x2]
    6260:	7100085f 	cmp	w2, #0x2
    6264:	54000480 	b.eq	62f4 <fwp_owned_entry161+0x194>  // b.none
    6268:	7100045f 	cmp	w2, #0x1
    626c:	540001a1 	b.ne	62a0 <fwp_owned_entry161+0x140>  // b.any
    6270:	29430002 	ldp	w2, w0, [x0, #24]
    6274:	92403c21 	and	x1, x1, #0xffff
    6278:	9b027c21 	mul	x1, x1, x2
    627c:	d360fc21 	lsr	x1, x1, #32
    6280:	eb00003f 	cmp	x1, x0
    6284:	540000e2 	b.cs	62a0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6288:	8b010294 	add	x20, x20, x1
    628c:	39400280 	ldrb	w0, [x20]
    6290:	7103fc1f 	cmp	w0, #0xff
    6294:	54000400 	b.eq	6314 <fwp_owned_entry161+0x1b4>  // b.none
    6298:	52800020 	mov	w0, #0x1                   	// #1
    629c:	39000280 	strb	w0, [x20]
    62a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62a4:	aa1303e0 	mov	x0, x19
    62a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    62b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    62b4:	d65f03c0 	ret
    62b8:	8b000021 	add	x1, x1, x0
    62bc:	f9400433 	ldr	x19, [x1, #8]
    62c0:	b4000113 	cbz	x19, 62e0 <fwp_owned_entry161+0x180>
    62c4:	f9400820 	ldr	x0, [x1, #16]
    62c8:	cb130000 	sub	x0, x0, x19
    62cc:	eb0002df 	cmp	x22, x0
    62d0:	54000088 	b.hi	62e0 <fwp_owned_entry161+0x180>  // b.pmore
    62d4:	8b160260 	add	x0, x19, x22
    62d8:	f9000420 	str	x0, [x1, #8]
    62dc:	17ffffb9 	b	61c0 <fwp_owned_entry161+0x60>
    62e0:	52800001 	mov	w1, #0x0                   	// #0
    62e4:	d2800300 	mov	x0, #0x18                  	// #24
    62e8:	97fffa42 	bl	4bf0 <fwp_heap_alloc>
    62ec:	aa0003f3 	mov	x19, x0
    62f0:	17ffffca 	b	6218 <fwp_owned_entry161+0xb8>
    62f4:	72003c3f 	tst	w1, #0xffff
    62f8:	54fffca0 	b.eq	628c <fwp_owned_entry161+0x12c>  // b.none
    62fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6300:	aa1303e0 	mov	x0, x19
    6304:	a94153f3 	ldp	x19, x20, [sp, #16]
    6308:	a94363f7 	ldp	x23, x24, [sp, #48]
    630c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6310:	d65f03c0 	ret
    6314:	aa1403e0 	mov	x0, x20
    6318:	97fff876 	bl	44f0 <fwp_rc_forget_slot>
    631c:	17ffffdf 	b	6298 <fwp_owned_entry161+0x138>
    6320:	97fff1b8 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6324:	97fff323 	bl	2fb0 <fwp_heap_oom>
    6328:	d503201f 	nop
    632c:	d503201f 	nop

0000000000006330 <e161>:
    6330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6334:	910003fd 	mov	x29, sp
    6338:	a90363f7 	stp	x23, x24, [sp, #48]
    633c:	a9406002 	ldp	x2, x24, [x0]
    6340:	a90153f3 	stp	x19, x20, [sp, #16]
    6344:	f9400801 	ldr	x1, [x0, #16]
    6348:	a9025bf5 	stp	x21, x22, [sp, #32]
    634c:	ab010055 	adds	x21, x2, x1
    6350:	54000d86 	b.vs	6500 <e161+0x1d0>
    6354:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    6358:	91154281 	add	x1, x20, #0x550
    635c:	b953a420 	ldr	w0, [x1, #5028]
    6360:	34000ac0 	cbz	w0, 64b8 <e161+0x188>
    6364:	397e8820 	ldrb	w0, [x1, #4002]
    6368:	910f0002 	add	x2, x0, #0x3c0
    636c:	8b000400 	add	x0, x0, x0, lsl #1
    6370:	d37df000 	lsl	x0, x0, #3
    6374:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6378:	2a1703f6 	mov	w22, w23
    637c:	f8606833 	ldr	x19, [x1, x0]
    6380:	b4000893 	cbz	x19, 6490 <e161+0x160>
    6384:	f9400262 	ldr	x2, [x19]
    6388:	aa2203e2 	mvn	x2, x2
    638c:	f8206822 	str	x2, [x1, x0]
    6390:	f10062df 	cmp	x22, #0x18
    6394:	540000e9 	b.ls	63b0 <e161+0x80>  // b.plast
    6398:	d10066c2 	sub	x2, x22, #0x19
    639c:	91006260 	add	x0, x19, #0x18
    63a0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    63a4:	52800001 	mov	w1, #0x0                   	// #0
    63a8:	91002042 	add	x2, x2, #0x8
    63ac:	97fff105 	bl	27c0 <memset@plt>
    63b0:	91154281 	add	x1, x20, #0x550
    63b4:	f94a1020 	ldr	x0, [x1, #5152]
    63b8:	ab160000 	adds	x0, x0, x22
    63bc:	54000a42 	b.cs	6504 <e161+0x1d4>  // b.hs, b.nlast
    63c0:	f94a1422 	ldr	x2, [x1, #5160]
    63c4:	f90a1020 	str	x0, [x1, #5152]
    63c8:	eb02001f 	cmp	x0, x2
    63cc:	54000049 	b.ls	63d4 <e161+0xa4>  // b.plast
    63d0:	f90a1420 	str	x0, [x1, #5160]
    63d4:	91154280 	add	x0, x20, #0x550
    63d8:	1e6302e1 	ucvtf	d1, w23
    63dc:	fd4a1c00 	ldr	d0, [x0, #5176]
    63e0:	1e612800 	fadd	d0, d0, d1
    63e4:	fd0a1c00 	str	d0, [x0, #5176]
    63e8:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    63ec:	91154294 	add	x20, x20, #0x550
    63f0:	a900d678 	stp	x24, x21, [x19, #8]
    63f4:	fd477800 	ldr	d0, [x0, #3824]
    63f8:	fd000260 	str	d0, [x19]
    63fc:	f949da81 	ldr	x1, [x20, #5040]
    6400:	f949ee80 	ldr	x0, [x20, #5080]
    6404:	cb010261 	sub	x1, x19, x1
    6408:	eb00403f 	cmp	x1, x0, lsl #16
    640c:	54000322 	b.cs	6470 <e161+0x140>  // b.hs, b.nlast
    6410:	d350fc20 	lsr	x0, x1, #16
    6414:	f949fe83 	ldr	x3, [x20, #5112]
    6418:	8b000800 	add	x0, x0, x0, lsl #2
    641c:	d37df002 	lsl	x2, x0, #3
    6420:	8b020060 	add	x0, x3, x2
    6424:	f9401014 	ldr	x20, [x0, #32]
    6428:	b4000254 	cbz	x20, 6470 <e161+0x140>
    642c:	38626862 	ldrb	w2, [x3, x2]
    6430:	7100085f 	cmp	w2, #0x2
    6434:	540004c0 	b.eq	64cc <e161+0x19c>  // b.none
    6438:	7100045f 	cmp	w2, #0x1
    643c:	540001a1 	b.ne	6470 <e161+0x140>  // b.any
    6440:	29430002 	ldp	w2, w0, [x0, #24]
    6444:	92403c21 	and	x1, x1, #0xffff
    6448:	9b027c21 	mul	x1, x1, x2
    644c:	d360fc21 	lsr	x1, x1, #32
    6450:	eb00003f 	cmp	x1, x0
    6454:	540000e2 	b.cs	6470 <e161+0x140>  // b.hs, b.nlast
    6458:	8b010294 	add	x20, x20, x1
    645c:	39400280 	ldrb	w0, [x20]
    6460:	7103fc1f 	cmp	w0, #0xff
    6464:	54000480 	b.eq	64f4 <e161+0x1c4>  // b.none
    6468:	52800020 	mov	w0, #0x1                   	// #1
    646c:	39000280 	strb	w0, [x20]
    6470:	aa1303e0 	mov	x0, x19
    6474:	97fffbeb 	bl	5420 <fwp_rc_share>
    6478:	a9425bf5 	ldp	x21, x22, [sp, #32]
    647c:	aa1303e0 	mov	x0, x19
    6480:	a94153f3 	ldp	x19, x20, [sp, #16]
    6484:	a94363f7 	ldp	x23, x24, [sp, #48]
    6488:	a8c47bfd 	ldp	x29, x30, [sp], #64
    648c:	d65f03c0 	ret
    6490:	8b000021 	add	x1, x1, x0
    6494:	f9400433 	ldr	x19, [x1, #8]
    6498:	b4000113 	cbz	x19, 64b8 <e161+0x188>
    649c:	f9400820 	ldr	x0, [x1, #16]
    64a0:	cb130000 	sub	x0, x0, x19
    64a4:	eb0002df 	cmp	x22, x0
    64a8:	54000088 	b.hi	64b8 <e161+0x188>  // b.pmore
    64ac:	8b160260 	add	x0, x19, x22
    64b0:	f9000420 	str	x0, [x1, #8]
    64b4:	17ffffb7 	b	6390 <e161+0x60>
    64b8:	52800001 	mov	w1, #0x0                   	// #0
    64bc:	d2800300 	mov	x0, #0x18                  	// #24
    64c0:	97fff9cc 	bl	4bf0 <fwp_heap_alloc>
    64c4:	aa0003f3 	mov	x19, x0
    64c8:	17ffffc8 	b	63e8 <e161+0xb8>
    64cc:	72003c3f 	tst	w1, #0xffff
    64d0:	54fffc60 	b.eq	645c <e161+0x12c>  // b.none
    64d4:	aa1303e0 	mov	x0, x19
    64d8:	97fffbd2 	bl	5420 <fwp_rc_share>
    64dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64e0:	aa1303e0 	mov	x0, x19
    64e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    64e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    64ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    64f0:	d65f03c0 	ret
    64f4:	aa1403e0 	mov	x0, x20
    64f8:	97fff7fe 	bl	44f0 <fwp_rc_forget_slot>
    64fc:	17ffffdb 	b	6468 <e161+0x138>
    6500:	97fff140 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6504:	97fff2ab 	bl	2fb0 <fwp_heap_oom>
    6508:	d503201f 	nop
    650c:	d503201f 	nop

0000000000006510 <fwp_drop4>:
    6510:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6514:	910003fd 	mov	x29, sp
    6518:	a90153f3 	stp	x19, x20, [sp, #16]
    651c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    6520:	f90013f5 	str	x21, [sp, #32]
    6524:	91154275 	add	x21, x19, #0x550
    6528:	f949daa1 	ldr	x1, [x21, #5040]
    652c:	f949eea2 	ldr	x2, [x21, #5080]
    6530:	cb010001 	sub	x1, x0, x1
    6534:	eb02403f 	cmp	x1, x2, lsl #16
    6538:	54000382 	b.cs	65a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    653c:	d350fc22 	lsr	x2, x1, #16
    6540:	f949fea3 	ldr	x3, [x21, #5112]
    6544:	8b020842 	add	x2, x2, x2, lsl #2
    6548:	d37df042 	lsl	x2, x2, #3
    654c:	8b020064 	add	x4, x3, x2
    6550:	f9401094 	ldr	x20, [x4, #32]
    6554:	b40002b4 	cbz	x20, 65a8 <fwp_drop4+0x98>
    6558:	38626862 	ldrb	w2, [x3, x2]
    655c:	7100085f 	cmp	w2, #0x2
    6560:	540007a0 	b.eq	6654 <fwp_drop4+0x144>  // b.none
    6564:	7100045f 	cmp	w2, #0x1
    6568:	54000201 	b.ne	65a8 <fwp_drop4+0x98>  // b.any
    656c:	29430885 	ldp	w5, w2, [x4, #24]
    6570:	92403c21 	and	x1, x1, #0xffff
    6574:	9b057c21 	mul	x1, x1, x5
    6578:	d360fc21 	lsr	x1, x1, #32
    657c:	eb02003f 	cmp	x1, x2
    6580:	54000142 	b.cs	65a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6584:	8b010294 	add	x20, x20, x1
    6588:	39400281 	ldrb	w1, [x20]
    658c:	340000e1 	cbz	w1, 65a8 <fwp_drop4+0x98>
    6590:	7100043f 	cmp	w1, #0x1
    6594:	54000120 	b.eq	65b8 <fwp_drop4+0xa8>  // b.none
    6598:	7103fc3f 	cmp	w1, #0xff
    659c:	540007c0 	b.eq	6694 <fwp_drop4+0x184>  // b.none
    65a0:	51000421 	sub	w1, w1, #0x1
    65a4:	39000281 	strb	w1, [x20]
    65a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65ac:	f94013f5 	ldr	x21, [sp, #32]
    65b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65b4:	d65f03c0 	ret
    65b8:	f9400001 	ldr	x1, [x0]
    65bc:	b7f80581 	tbnz	x1, #63, 666c <fwp_drop4+0x15c>
    65c0:	91154273 	add	x19, x19, #0x550
    65c4:	f949da61 	ldr	x1, [x19, #5040]
    65c8:	f949ee62 	ldr	x2, [x19, #5080]
    65cc:	cb010001 	sub	x1, x0, x1
    65d0:	eb02403f 	cmp	x1, x2, lsl #16
    65d4:	54fffea2 	b.cs	65a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    65d8:	d350fc22 	lsr	x2, x1, #16
    65dc:	8b020842 	add	x2, x2, x2, lsl #2
    65e0:	d37df042 	lsl	x2, x2, #3
    65e4:	8b020065 	add	x5, x3, x2
    65e8:	f94010a4 	ldr	x4, [x5, #32]
    65ec:	b4fffde4 	cbz	x4, 65a8 <fwp_drop4+0x98>
    65f0:	38626862 	ldrb	w2, [x3, x2]
    65f4:	7100085f 	cmp	w2, #0x2
    65f8:	54000220 	b.eq	663c <fwp_drop4+0x12c>  // b.none
    65fc:	7100045f 	cmp	w2, #0x1
    6600:	54fffd41 	b.ne	65a8 <fwp_drop4+0x98>  // b.any
    6604:	294308a3 	ldp	w3, w2, [x5, #24]
    6608:	92403c21 	and	x1, x1, #0xffff
    660c:	9b037c21 	mul	x1, x1, x3
    6610:	d360fc21 	lsr	x1, x1, #32
    6614:	eb02003f 	cmp	x1, x2
    6618:	54fffc82 	b.cs	65a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    661c:	8b010084 	add	x4, x4, x1
    6620:	39400081 	ldrb	w1, [x4]
    6624:	7100043f 	cmp	w1, #0x1
    6628:	54fffc01 	b.ne	65a8 <fwp_drop4+0x98>  // b.any
    662c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6630:	f94013f5 	ldr	x21, [sp, #32]
    6634:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6638:	17fff84e 	b	4770 <fwp_mem_free>
    663c:	72003c3f 	tst	w1, #0xffff
    6640:	54ffff00 	b.eq	6620 <fwp_drop4+0x110>  // b.none
    6644:	a94153f3 	ldp	x19, x20, [sp, #16]
    6648:	f94013f5 	ldr	x21, [sp, #32]
    664c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6650:	d65f03c0 	ret
    6654:	72003c3f 	tst	w1, #0xffff
    6658:	54fff980 	b.eq	6588 <fwp_drop4+0x78>  // b.none
    665c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6660:	f94013f5 	ldr	x21, [sp, #32]
    6664:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6668:	d65f03c0 	ret
    666c:	f9400414 	ldr	x20, [x0, #8]
    6670:	97fffb91 	bl	54b4 <fwp_rc_free_arr>
    6674:	91154260 	add	x0, x19, #0x550
    6678:	f949d801 	ldr	x1, [x0, #5040]
    667c:	f949ec00 	ldr	x0, [x0, #5080]
    6680:	cb010281 	sub	x1, x20, x1
    6684:	eb00403f 	cmp	x1, x0, lsl #16
    6688:	54fff902 	b.cs	65a8 <fwp_drop4+0x98>  // b.hs, b.nlast
    668c:	aa1403e0 	mov	x0, x20
    6690:	17ffffab 	b	653c <fwp_drop4+0x2c>
    6694:	ca544680 	eor	x0, x20, x20, lsr #17
    6698:	91154273 	add	x19, x19, #0x550
    669c:	ca402400 	eor	x0, x0, x0, lsr #9
    66a0:	8b200e60 	add	x0, x19, w0, uxtb #3
    66a4:	f94a2400 	ldr	x0, [x0, #5192]
    66a8:	b5000080 	cbnz	x0, 66b8 <fwp_drop4+0x1a8>
    66ac:	14000010 	b	66ec <fwp_drop4+0x1dc>
    66b0:	f9400800 	ldr	x0, [x0, #16]
    66b4:	b40001c0 	cbz	x0, 66ec <fwp_drop4+0x1dc>
    66b8:	f9400001 	ldr	x1, [x0]
    66bc:	eb14003f 	cmp	x1, x20
    66c0:	54ffff81 	b.ne	66b0 <fwp_drop4+0x1a0>  // b.any
    66c4:	f9400401 	ldr	x1, [x0, #8]
    66c8:	d1000421 	sub	x1, x1, #0x1
    66cc:	f9000401 	str	x1, [x0, #8]
    66d0:	f103f83f 	cmp	x1, #0xfe
    66d4:	54fff6a1 	b.ne	65a8 <fwp_drop4+0x98>  // b.any
    66d8:	aa1403e0 	mov	x0, x20
    66dc:	97fff785 	bl	44f0 <fwp_rc_forget_slot>
    66e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66e4:	39000280 	strb	w0, [x20]
    66e8:	17ffffb0 	b	65a8 <fwp_drop4+0x98>
    66ec:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    66f0:	91132000 	add	x0, x0, #0x4c8
    66f4:	97fff383 	bl	3500 <fwp_trap>
    66f8:	d503201f 	nop
    66fc:	d503201f 	nop

0000000000006700 <fwp_caps161>:
    6700:	34000041 	cbz	w1, 6708 <fwp_caps161+0x8>
    6704:	d65f03c0 	ret
    6708:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    670c:	91154063 	add	x3, x3, #0x550
    6710:	f949d861 	ldr	x1, [x3, #5040]
    6714:	f949ec62 	ldr	x2, [x3, #5080]
    6718:	cb010001 	sub	x1, x0, x1
    671c:	eb02403f 	cmp	x1, x2, lsl #16
    6720:	54ffff22 	b.cs	6704 <fwp_caps161+0x4>  // b.hs, b.nlast
    6724:	d350fc22 	lsr	x2, x1, #16
    6728:	f949fc65 	ldr	x5, [x3, #5112]
    672c:	8b020842 	add	x2, x2, x2, lsl #2
    6730:	d37df042 	lsl	x2, x2, #3
    6734:	8b0200a4 	add	x4, x5, x2
    6738:	f9401083 	ldr	x3, [x4, #32]
    673c:	b4fffe43 	cbz	x3, 6704 <fwp_caps161+0x4>
    6740:	386268a2 	ldrb	w2, [x5, x2]
    6744:	7100085f 	cmp	w2, #0x2
    6748:	540001c0 	b.eq	6780 <fwp_caps161+0x80>  // b.none
    674c:	7100045f 	cmp	w2, #0x1
    6750:	54fffda1 	b.ne	6704 <fwp_caps161+0x4>  // b.any
    6754:	29430885 	ldp	w5, w2, [x4, #24]
    6758:	92403c21 	and	x1, x1, #0xffff
    675c:	9b057c21 	mul	x1, x1, x5
    6760:	d360fc21 	lsr	x1, x1, #32
    6764:	eb02003f 	cmp	x1, x2
    6768:	54fffce2 	b.cs	6704 <fwp_caps161+0x4>  // b.hs, b.nlast
    676c:	8b010063 	add	x3, x3, x1
    6770:	39400061 	ldrb	w1, [x3]
    6774:	7100043f 	cmp	w1, #0x1
    6778:	54fffc61 	b.ne	6704 <fwp_caps161+0x4>  // b.any
    677c:	17fff7fd 	b	4770 <fwp_mem_free>
    6780:	72003c3f 	tst	w1, #0xffff
    6784:	54ffff60 	b.eq	6770 <fwp_caps161+0x70>  // b.none
    6788:	d65f03c0 	ret
    678c:	d503201f 	nop

0000000000006790 <f12>:
    6790:	d10483ff 	sub	sp, sp, #0x120
    6794:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6798:	f947f442 	ldr	x2, [x2, #4072]
    679c:	9100e3e8 	add	x8, sp, #0x38
    67a0:	a90b7bfd 	stp	x29, x30, [sp, #176]
    67a4:	9102c3fd 	add	x29, sp, #0xb0
    67a8:	a90d5bf5 	stp	x21, x22, [sp, #208]
    67ac:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    67b0:	911542a3 	add	x3, x21, #0x550
    67b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    67b8:	d00000d7 	adrp	x23, 20000 <__data_start>
    67bc:	910102e4 	add	x4, x23, #0x40
    67c0:	f949d861 	ldr	x1, [x3, #5040]
    67c4:	a90c53f3 	stp	x19, x20, [sp, #192]
    67c8:	d00000d4 	adrp	x20, 20000 <__data_start>
    67cc:	f949ec65 	ldr	x5, [x3, #5080]
    67d0:	a90f6bf9 	stp	x25, x26, [sp, #240]
    67d4:	91004294 	add	x20, x20, #0x10
    67d8:	a91073fb 	stp	x27, x28, [sp, #256]
    67dc:	910103f9 	add	x25, sp, #0x40
    67e0:	f0fffff3 	adrp	x19, 5000 <fwp_p_ad_push+0xdc>
    67e4:	f9416086 	ldr	x6, [x4, #704]
    67e8:	fd008be8 	str	d8, [sp, #272]
    67ec:	f9400047 	ldr	x7, [x2]
    67f0:	f90057e7 	str	x7, [sp, #168]
    67f4:	d2800007 	mov	x7, #0x0                   	// #0
    67f8:	cb010281 	sub	x1, x20, x1
    67fc:	91304262 	add	x2, x19, #0xc10
    6800:	12800007 	mov	w7, #0xffffffff            	// #-1
    6804:	f90007e8 	str	x8, [sp, #8]
    6808:	aa0003f6 	mov	x22, x0
    680c:	b9003be7 	str	w7, [sp, #56]
    6810:	a9040be6 	stp	x6, x2, [sp, #64]
    6814:	f9002be8 	str	x8, [sp, #80]
    6818:	f9016099 	str	x25, [x4, #704]
    681c:	eb05403f 	cmp	x1, x5, lsl #16
    6820:	54000342 	b.cs	6888 <f12+0xf8>  // b.hs, b.nlast
    6824:	d350fc20 	lsr	x0, x1, #16
    6828:	f949fc64 	ldr	x4, [x3, #5112]
    682c:	8b000800 	add	x0, x0, x0, lsl #2
    6830:	d37df002 	lsl	x2, x0, #3
    6834:	8b020083 	add	x3, x4, x2
    6838:	f9401060 	ldr	x0, [x3, #32]
    683c:	b4000260 	cbz	x0, 6888 <f12+0xf8>
    6840:	38626882 	ldrb	w2, [x4, x2]
    6844:	7100085f 	cmp	w2, #0x2
    6848:	54007920 	b.eq	776c <f12+0xfdc>  // b.none
    684c:	7100045f 	cmp	w2, #0x1
    6850:	540001c1 	b.ne	6888 <f12+0xf8>  // b.any
    6854:	29430864 	ldp	w4, w2, [x3, #24]
    6858:	92403c21 	and	x1, x1, #0xffff
    685c:	9b047c21 	mul	x1, x1, x4
    6860:	d360fc21 	lsr	x1, x1, #32
    6864:	eb02003f 	cmp	x1, x2
    6868:	54000102 	b.cs	6888 <f12+0xf8>  // b.hs, b.nlast
    686c:	8b010000 	add	x0, x0, x1
    6870:	39400001 	ldrb	w1, [x0]
    6874:	340000a1 	cbz	w1, 6888 <f12+0xf8>
    6878:	7103f43f 	cmp	w1, #0xfd
    687c:	54007fe8 	b.hi	7878 <f12+0x10e8>  // b.pmore
    6880:	11000421 	add	w1, w1, #0x1
    6884:	39000001 	strb	w1, [x0]
    6888:	aa1403e0 	mov	x0, x20
    688c:	97fffc01 	bl	5890 <fwp_closure_drop>
    6890:	b4007796 	cbz	x22, 7780 <f12+0xff0>
    6894:	aa1603e0 	mov	x0, x22
    6898:	d2800001 	mov	x1, #0x0                   	// #0
    689c:	d503201f 	nop
    68a0:	f9400800 	ldr	x0, [x0, #16]
    68a4:	91000421 	add	x1, x1, #0x1
    68a8:	b5ffffc0 	cbnz	x0, 68a0 <f12+0x110>
    68ac:	aa0103fa 	mov	x26, x1
    68b0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    68b4:	eb00003f 	cmp	x1, x0
    68b8:	54008328 	b.hi	791c <f12+0x118c>  // b.pmore
    68bc:	910102f4 	add	x20, x23, #0x40
    68c0:	b942f680 	ldr	w0, [x20, #756]
    68c4:	34007400 	cbz	w0, 7744 <f12+0xfb4>
    68c8:	910102e0 	add	x0, x23, #0x40
    68cc:	f940201b 	ldr	x27, [x0, #64]
    68d0:	f9404c14 	ldr	x20, [x0, #152]
    68d4:	eb1b029f 	cmp	x20, x27
    68d8:	5400364a 	b.ge	6fa0 <f12+0x810>  // b.tcont
    68dc:	f94022e1 	ldr	x1, [x23, #64]
    68e0:	8b140680 	add	x0, x20, x20, lsl #1
    68e4:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    68e8:	8b000a80 	add	x0, x20, x0, lsl #2
    68ec:	8b000c20 	add	x0, x1, x0, lsl #3
    68f0:	b9400401 	ldr	w1, [x0, #4]
    68f4:	35000081 	cbnz	w1, 6904 <f12+0x174>
    68f8:	b9400001 	ldr	w1, [x0]
    68fc:	6b02003f 	cmp	w1, w2
    6900:	54003509 	b.ls	6fa0 <f12+0x810>  // b.plast
    6904:	91000694 	add	x20, x20, #0x1
    6908:	9101a000 	add	x0, x0, #0x68
    690c:	eb1b029f 	cmp	x20, x27
    6910:	54ffff01 	b.ne	68f0 <f12+0x160>  // b.any
    6914:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6918:	eb00037f 	cmp	x27, x0
    691c:	54007e8c 	b.gt	78ec <f12+0x115c>
    6920:	910102e0 	add	x0, x23, #0x40
    6924:	f94022fc 	ldr	x28, [x23, #64]
    6928:	f9404800 	ldr	x0, [x0, #144]
    692c:	eb1b001f 	cmp	x0, x27
    6930:	54000201 	b.ne	6970 <f12+0x1e0>  // b.any
    6934:	b40078bb 	cbz	x27, 7848 <f12+0x10b8>
    6938:	d37ffb78 	lsl	x24, x27, #1
    693c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6940:	eb00031f 	cmp	x24, x0
    6944:	9a80d318 	csel	x24, x24, x0, le
    6948:	8b180701 	add	x1, x24, x24, lsl #1
    694c:	8b010b01 	add	x1, x24, x1, lsl #2
    6950:	d37df021 	lsl	x1, x1, #3
    6954:	aa1c03e0 	mov	x0, x28
    6958:	97ffefa2 	bl	27e0 <realloc@plt>
    695c:	aa0003fc 	mov	x28, x0
    6960:	b4006d20 	cbz	x0, 7704 <f12+0xf74>
    6964:	910102e0 	add	x0, x23, #0x40
    6968:	f90022fc 	str	x28, [x23, #64]
    696c:	f9004818 	str	x24, [x0, #144]
    6970:	910102e1 	add	x1, x23, #0x40
    6974:	8b1b0760 	add	x0, x27, x27, lsl #1
    6978:	4f000400 	movi	v0.4s, #0x0
    697c:	91000762 	add	x2, x27, #0x1
    6980:	8b000b60 	add	x0, x27, x0, lsl #2
    6984:	f9002022 	str	x2, [x1, #64]
    6988:	8b140681 	add	x1, x20, x20, lsl #1
    698c:	8b000f80 	add	x0, x28, x0, lsl #3
    6990:	8b010a9b 	add	x27, x20, x1, lsl #2
    6994:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6998:	ad000000 	stp	q0, q0, [x0]
    699c:	ad010000 	stp	q0, q0, [x0, #32]
    69a0:	ad020000 	stp	q0, q0, [x0, #64]
    69a4:	f900301f 	str	xzr, [x0, #96]
    69a8:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    69ac:	f900337f 	str	xzr, [x27, #96]
    69b0:	91116000 	add	x0, x0, #0x458
    69b4:	97ffeff3 	bl	2980 <getenv@plt>
    69b8:	b50030a0 	cbnz	x0, 6fcc <f12+0x83c>
    69bc:	d503201f 	nop
    69c0:	910102e0 	add	x0, x23, #0x40
    69c4:	f9404001 	ldr	x1, [x0, #128]
    69c8:	b5006ea1 	cbnz	x1, 779c <f12+0x100c>
    69cc:	910102e1 	add	x1, x23, #0x40
    69d0:	2f000400 	mvni	v0.2s, #0x0
    69d4:	b9400362 	ldr	w2, [x27]
    69d8:	52800024 	mov	w4, #0x1                   	// #1
    69dc:	91000683 	add	x3, x20, #0x1
    69e0:	a900eb7a 	stp	x26, x26, [x27, #8]
    69e4:	0b040042 	add	w2, w2, w4
    69e8:	f9416020 	ldr	x0, [x1, #704]
    69ec:	29001362 	stp	w2, w4, [x27]
    69f0:	f9002b7f 	str	xzr, [x27, #80]
    69f4:	f9004c23 	str	x3, [x1, #152]
    69f8:	fd002f60 	str	d0, [x27, #88]
    69fc:	b40078a0 	cbz	x0, 7910 <f12+0x1180>
    6a00:	91304273 	add	x19, x19, #0xc10
    6a04:	14000003 	b	6a10 <f12+0x280>
    6a08:	f9400000 	ldr	x0, [x0]
    6a0c:	b4007820 	cbz	x0, 7910 <f12+0x1180>
    6a10:	f9400401 	ldr	x1, [x0, #8]
    6a14:	eb13003f 	cmp	x1, x19
    6a18:	54ffff81 	b.ne	6a08 <f12+0x278>  // b.any
    6a1c:	f9400800 	ldr	x0, [x0, #16]
    6a20:	2a1403e4 	mov	w4, w20
    6a24:	b9400001 	ldr	w1, [x0]
    6a28:	f9002b60 	str	x0, [x27, #80]
    6a2c:	b9005f61 	str	w1, [x27, #92]
    6a30:	37f80081 	tbnz	w1, #31, 6a40 <f12+0x2b0>
    6a34:	52800d05 	mov	w5, #0x68                  	// #104
    6a38:	9b257021 	smaddl	x1, w1, w5, x28
    6a3c:	b9005834 	str	w20, [x1, #88]
    6a40:	b9000004 	str	w4, [x0]
    6a44:	d3707c42 	ubfiz	x2, x2, #16, #32
    6a48:	aa03005a 	orr	x26, x2, x3
    6a4c:	aa1603e0 	mov	x0, x22
    6a50:	d2800002 	mov	x2, #0x0                   	// #0
    6a54:	b4006296 	cbz	x22, 76a4 <f12+0xf14>
    6a58:	f9400800 	ldr	x0, [x0, #16]
    6a5c:	91000442 	add	x2, x2, #0x1
    6a60:	b5ffffc0 	cbnz	x0, 6a58 <f12+0x2c8>
    6a64:	aa1603e1 	mov	x1, x22
    6a68:	f9400821 	ldr	x1, [x1, #16]
    6a6c:	91000400 	add	x0, x0, #0x1
    6a70:	b5ffffc1 	cbnz	x1, 6a68 <f12+0x2d8>
    6a74:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6a78:	eb01001f 	cmp	x0, x1
    6a7c:	54007448 	b.hi	7904 <f12+0x1174>  // b.pmore
    6a80:	f100005f 	cmp	x2, #0x0
    6a84:	5400610d 	b.le	76a4 <f12+0xf14>
    6a88:	eb00005f 	cmp	x2, x0
    6a8c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6a90:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6a94:	eb01027f 	cmp	x19, x1
    6a98:	54007368 	b.hi	7904 <f12+0x1174>  // b.pmore
    6a9c:	d37ffa74 	lsl	x20, x19, #1
    6aa0:	52800041 	mov	w1, #0x2                   	// #2
    6aa4:	91000680 	add	x0, x20, #0x1
    6aa8:	d37df000 	lsl	x0, x0, #3
    6aac:	97fff851 	bl	4bf0 <fwp_heap_alloc>
    6ab0:	aa0003fb 	mov	x27, x0
    6ab4:	911542a1 	add	x1, x21, #0x550
    6ab8:	aa0103e0 	mov	x0, x1
    6abc:	f9000374 	str	x20, [x27]
    6ac0:	f949d821 	ldr	x1, [x1, #5040]
    6ac4:	f949ec00 	ldr	x0, [x0, #5080]
    6ac8:	cb010361 	sub	x1, x27, x1
    6acc:	eb00403f 	cmp	x1, x0, lsl #16
    6ad0:	54006322 	b.cs	7734 <f12+0xfa4>  // b.hs, b.nlast
    6ad4:	911542a2 	add	x2, x21, #0x550
    6ad8:	d350fc20 	lsr	x0, x1, #16
    6adc:	8b000800 	add	x0, x0, x0, lsl #2
    6ae0:	f949fc43 	ldr	x3, [x2, #5112]
    6ae4:	d37df002 	lsl	x2, x0, #3
    6ae8:	8b020060 	add	x0, x3, x2
    6aec:	f9401014 	ldr	x20, [x0, #32]
    6af0:	b4000254 	cbz	x20, 6b38 <f12+0x3a8>
    6af4:	38626862 	ldrb	w2, [x3, x2]
    6af8:	7100085f 	cmp	w2, #0x2
    6afc:	54006320 	b.eq	7760 <f12+0xfd0>  // b.none
    6b00:	7100045f 	cmp	w2, #0x1
    6b04:	540001a1 	b.ne	6b38 <f12+0x3a8>  // b.any
    6b08:	29430002 	ldp	w2, w0, [x0, #24]
    6b0c:	92403c21 	and	x1, x1, #0xffff
    6b10:	9b027c21 	mul	x1, x1, x2
    6b14:	d360fc21 	lsr	x1, x1, #32
    6b18:	eb00003f 	cmp	x1, x0
    6b1c:	540000e2 	b.cs	6b38 <f12+0x3a8>  // b.hs, b.nlast
    6b20:	8b010294 	add	x20, x20, x1
    6b24:	39400280 	ldrb	w0, [x20]
    6b28:	7103fc1f 	cmp	w0, #0xff
    6b2c:	54006940 	b.eq	7854 <f12+0x10c4>  // b.none
    6b30:	52800020 	mov	w0, #0x1                   	// #1
    6b34:	39000280 	strb	w0, [x20]
    6b38:	b4000233 	cbz	x19, 6b7c <f12+0x3ec>
    6b3c:	d3607f44 	lsl	x4, x26, #32
    6b40:	aa1603e0 	mov	x0, x22
    6b44:	f94006c5 	ldr	x5, [x22, #8]
    6b48:	aa0403e3 	mov	x3, x4
    6b4c:	91002362 	add	x2, x27, #0x8
    6b50:	d2800001 	mov	x1, #0x0                   	// #0
    6b54:	14000005 	b	6b68 <f12+0x3d8>
    6b58:	f9400405 	ldr	x5, [x0, #8]
    6b5c:	ab040023 	adds	x3, x1, x4
    6b60:	91004042 	add	x2, x2, #0x10
    6b64:	54006f26 	b.vs	7948 <f12+0x11b8>
    6b68:	a9000c45 	stp	x5, x3, [x2]
    6b6c:	91000421 	add	x1, x1, #0x1
    6b70:	f9400800 	ldr	x0, [x0, #16]
    6b74:	eb01027f 	cmp	x19, x1
    6b78:	54ffff08 	b.hi	6b58 <f12+0x3c8>  // b.pmore
    6b7c:	f9400360 	ldr	x0, [x27]
    6b80:	f100041f 	cmp	x0, #0x1
    6b84:	54005da9 	b.ls	7738 <f12+0xfa8>  // b.plast
    6b88:	d341fc00 	lsr	x0, x0, #1
    6b8c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6b90:	d1000414 	sub	x20, x0, #0x1
    6b94:	eb01029f 	cmp	x20, x1
    6b98:	54006b68 	b.hi	7904 <f12+0x1174>  // b.pmore
    6b9c:	b4005cf4 	cbz	x20, 7738 <f12+0xfa8>
    6ba0:	d1002361 	sub	x1, x27, #0x8
    6ba4:	91002373 	add	x19, x27, #0x8
    6ba8:	8b00103c 	add	x28, x1, x0, lsl #4
    6bac:	d503201f 	nop
    6bb0:	f9400660 	ldr	x0, [x19, #8]
    6bb4:	f9400e61 	ldr	x1, [x19, #24]
    6bb8:	fd400260 	ldr	d0, [x19]
    6bbc:	fd400a61 	ldr	d1, [x19, #16]
    6bc0:	97fff98c 	bl	51f0 <w107>
    6bc4:	a9000660 	stp	x0, x1, [x19]
    6bc8:	91004273 	add	x19, x19, #0x10
    6bcc:	eb1c027f 	cmp	x19, x28
    6bd0:	54ffff01 	b.ne	6bb0 <f12+0x420>  // b.any
    6bd4:	aa1b03fc 	mov	x28, x27
    6bd8:	d37ffa93 	lsl	x19, x20, #1
    6bdc:	d2800018 	mov	x24, #0x0                   	// #0
    6be0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6be4:	f8010793 	str	x19, [x28], #16
    6be8:	f8787b82 	ldr	x2, [x28, x24, lsl #3]
    6bec:	aa1403e0 	mov	x0, x20
    6bf0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6bf4:	91000b18 	add	x24, x24, #0x2
    6bf8:	aa0303e1 	mov	x1, x3
    6bfc:	97fff8ca 	bl	4f24 <fwp_p_ad_push>
    6c00:	aa0003f4 	mov	x20, x0
    6c04:	eb13031f 	cmp	x24, x19
    6c08:	54ffff03 	b.cc	6be8 <f12+0x458>  // b.lo, b.ul, b.last
    6c0c:	aa1b03e0 	mov	x0, x27
    6c10:	93407f53 	sxtw	x19, w26
    6c14:	97fffe3f 	bl	6510 <fwp_drop4>
    6c18:	aa1303e0 	mov	x0, x19
    6c1c:	97fff305 	bl	3830 <fwp_tape_of>
    6c20:	f9403001 	ldr	x1, [x0, #96]
    6c24:	aa0003e8 	mov	x8, x0
    6c28:	b5006801 	cbnz	x1, 7928 <f12+0x1198>
    6c2c:	97fff0b9 	bl	2f10 <fwp_tape_unlink_scope>
    6c30:	b900051f 	str	wzr, [x8, #4]
    6c34:	b9400102 	ldr	w2, [x8]
    6c38:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6c3c:	a940851c 	ldp	x28, x1, [x8, #8]
    6c40:	a941910a 	ldp	x10, x4, [x8, #24]
    6c44:	a9429905 	ldp	x5, x6, [x8, #40]
    6c48:	a9438d07 	ldp	x7, x3, [x8, #56]
    6c4c:	f940251b 	ldr	x27, [x8, #72]
    6c50:	6b00005f 	cmp	w2, w0
    6c54:	54000108 	b.hi	6c74 <f12+0x4e4>  // b.pmore
    6c58:	910102e2 	add	x2, x23, #0x40
    6c5c:	92403e60 	and	x0, x19, #0xffff
    6c60:	d1000400 	sub	x0, x0, #0x1
    6c64:	f9404c49 	ldr	x9, [x2, #152]
    6c68:	eb09001f 	cmp	x0, x9
    6c6c:	5400004a 	b.ge	6c74 <f12+0x4e4>  // b.tcont
    6c70:	f9004c40 	str	x0, [x2, #152]
    6c74:	4f000400 	movi	v0.4s, #0x0
    6c78:	910102e9 	add	x9, x23, #0x40
    6c7c:	f9000d1f 	str	xzr, [x8, #24]
    6c80:	910163e0 	add	x0, sp, #0x58
    6c84:	9101c3fa 	add	x26, sp, #0x70
    6c88:	d0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    6c8c:	f941612b 	ldr	x11, [x9, #704]
    6c90:	3c808100 	stur	q0, [x8, #8]
    6c94:	91020042 	add	x2, x2, #0x80
    6c98:	ad010100 	stp	q0, q0, [x8, #32]
    6c9c:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    6ca0:	a9058beb 	stp	x11, x2, [sp, #88]
    6ca4:	a90693fa 	stp	x26, x4, [sp, #104]
    6ca8:	a9079be5 	stp	x5, x6, [sp, #120]
    6cac:	a9088fe7 	stp	x7, x3, [sp, #136]
    6cb0:	a909efea 	stp	x10, x27, [sp, #152]
    6cb4:	f9016120 	str	x0, [x9, #704]
    6cb8:	b7f856f4 	tbnz	x20, #63, 7794 <f12+0x1004>
    6cbc:	eb94827f 	cmp	x19, x20, asr #32
    6cc0:	54006101 	b.ne	78e0 <f12+0x1150>  // b.any
    6cc4:	92407e93 	and	x19, x20, #0xffffffff
    6cc8:	eb34403f 	cmp	x1, w20, uxtw
    6ccc:	54005e4d 	b.le	7894 <f12+0x1104>
    6cd0:	eb1c027f 	cmp	x19, x28
    6cd4:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    6cd8:	eb13037f 	cmp	x27, x19
    6cdc:	5400504a 	b.ge	76e4 <f12+0xf54>  // b.tcont
    6ce0:	f100037f 	cmp	x27, #0x0
    6ce4:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    6ce8:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    6cec:	14000004 	b	6cfc <f12+0x56c>
    6cf0:	eb01037f 	cmp	x27, x1
    6cf4:	d37ffb7b 	lsl	x27, x27, #1
    6cf8:	9a93d37b 	csel	x27, x27, x19, le
    6cfc:	eb13037f 	cmp	x27, x19
    6d00:	54ffff8b 	b.lt	6cf0 <f12+0x560>  // b.tstop
    6d04:	a90117e4 	stp	x4, x5, [sp, #16]
    6d08:	a9021fe6 	stp	x6, x7, [sp, #32]
    6d0c:	b40057a3 	cbz	x3, 7800 <f12+0x1070>
    6d10:	aa0303e0 	mov	x0, x3
    6d14:	d37df361 	lsl	x1, x27, #3
    6d18:	97ffeeb2 	bl	27e0 <realloc@plt>
    6d1c:	aa0003e3 	mov	x3, x0
    6d20:	a94117e4 	ldp	x4, x5, [sp, #16]
    6d24:	a9421fe6 	ldp	x6, x7, [sp, #32]
    6d28:	b4004de3 	cbz	x3, 76e4 <f12+0xf54>
    6d2c:	f9004be3 	str	x3, [sp, #144]
    6d30:	f90053fb 	str	x27, [sp, #160]
    6d34:	b5001593 	cbnz	x19, 6fe4 <f12+0x854>
    6d38:	b7f800d4 	tbnz	x20, #63, 6d50 <f12+0x5c0>
    6d3c:	92407e94 	and	x20, x20, #0xffffffff
    6d40:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    6d44:	fc747860 	ldr	d0, [x3, x20, lsl #3]
    6d48:	1e612800 	fadd	d0, d0, d1
    6d4c:	fc347860 	str	d0, [x3, x20, lsl #3]
    6d50:	d1000673 	sub	x19, x19, #0x1
    6d54:	d1000788 	sub	x8, x28, #0x1
    6d58:	eb13039f 	cmp	x28, x19
    6d5c:	540003ac 	b.gt	6dd0 <f12+0x640>
    6d60:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    6d64:	1e602008 	fcmp	d0, #0.0
    6d68:	540002e0 	b.eq	6dc4 <f12+0x634>  // b.none
    6d6c:	cb1c0be0 	neg	x0, x28, lsl #2
    6d70:	cb1c03e2 	neg	x2, x28
    6d74:	8b000081 	add	x1, x4, x0
    6d78:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    6d7c:	37f80101 	tbnz	w1, #31, 6d9c <f12+0x60c>
    6d80:	8b020cc9 	add	x9, x6, x2, lsl #3
    6d84:	93407c21 	sxtw	x1, w1
    6d88:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    6d8c:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    6d90:	1e620802 	fmul	d2, d0, d2
    6d94:	1e622821 	fadd	d1, d1, d2
    6d98:	fc217861 	str	d1, [x3, x1, lsl #3]
    6d9c:	8b0000a0 	add	x0, x5, x0
    6da0:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    6da4:	37f80100 	tbnz	w0, #31, 6dc4 <f12+0x634>
    6da8:	8b020ce2 	add	x2, x7, x2, lsl #3
    6dac:	93407c00 	sxtw	x0, w0
    6db0:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    6db4:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    6db8:	1e620800 	fmul	d0, d0, d2
    6dbc:	1e602820 	fadd	d0, d1, d0
    6dc0:	fc207860 	str	d0, [x3, x0, lsl #3]
    6dc4:	d1000673 	sub	x19, x19, #0x1
    6dc8:	eb08027f 	cmp	x19, x8
    6dcc:	54fffca1 	b.ne	6d60 <f12+0x5d0>  // b.any
    6dd0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    6dd4:	eb00039f 	cmp	x28, x0
    6dd8:	54005908 	b.hi	78f8 <f12+0x1168>  // b.pmore
    6ddc:	91000780 	add	x0, x28, #0x1
    6de0:	52800041 	mov	w1, #0x2                   	// #2
    6de4:	f9000be3 	str	x3, [sp, #16]
    6de8:	d37df000 	lsl	x0, x0, #3
    6dec:	97fff781 	bl	4bf0 <fwp_heap_alloc>
    6df0:	aa0003e2 	mov	x2, x0
    6df4:	aa0003f3 	mov	x19, x0
    6df8:	f9400be3 	ldr	x3, [sp, #16]
    6dfc:	d2800001 	mov	x1, #0x0                   	// #0
    6e00:	f800845c 	str	x28, [x2], #8
    6e04:	b40000dc 	cbz	x28, 6e1c <f12+0x68c>
    6e08:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    6e0c:	f8217840 	str	x0, [x2, x1, lsl #3]
    6e10:	91000421 	add	x1, x1, #0x1
    6e14:	eb01039f 	cmp	x28, x1
    6e18:	54ffff81 	b.ne	6e08 <f12+0x678>  // b.any
    6e1c:	910102e1 	add	x1, x23, #0x40
    6e20:	aa1a03e0 	mov	x0, x26
    6e24:	f9402ffa 	ldr	x26, [sp, #88]
    6e28:	f901603a 	str	x26, [x1, #704]
    6e2c:	97fff495 	bl	4080 <fwp_tape_buffers_release>
    6e30:	911542a2 	add	x2, x21, #0x550
    6e34:	f949d841 	ldr	x1, [x2, #5040]
    6e38:	f949ec40 	ldr	x0, [x2, #5080]
    6e3c:	cb010261 	sub	x1, x19, x1
    6e40:	eb00403f 	cmp	x1, x0, lsl #16
    6e44:	54000322 	b.cs	6ea8 <f12+0x718>  // b.hs, b.nlast
    6e48:	d350fc20 	lsr	x0, x1, #16
    6e4c:	f949fc43 	ldr	x3, [x2, #5112]
    6e50:	8b000800 	add	x0, x0, x0, lsl #2
    6e54:	d37df002 	lsl	x2, x0, #3
    6e58:	8b020060 	add	x0, x3, x2
    6e5c:	f9401014 	ldr	x20, [x0, #32]
    6e60:	b4000254 	cbz	x20, 6ea8 <f12+0x718>
    6e64:	38626862 	ldrb	w2, [x3, x2]
    6e68:	7100085f 	cmp	w2, #0x2
    6e6c:	540048e0 	b.eq	7788 <f12+0xff8>  // b.none
    6e70:	7100045f 	cmp	w2, #0x1
    6e74:	540001a1 	b.ne	6ea8 <f12+0x718>  // b.any
    6e78:	29430002 	ldp	w2, w0, [x0, #24]
    6e7c:	92403c21 	and	x1, x1, #0xffff
    6e80:	9b027c21 	mul	x1, x1, x2
    6e84:	d360fc21 	lsr	x1, x1, #32
    6e88:	eb00003f 	cmp	x1, x0
    6e8c:	540000e2 	b.cs	6ea8 <f12+0x718>  // b.hs, b.nlast
    6e90:	8b010294 	add	x20, x20, x1
    6e94:	39400280 	ldrb	w0, [x20]
    6e98:	7103fc1f 	cmp	w0, #0xff
    6e9c:	54004e20 	b.eq	7860 <f12+0x10d0>  // b.none
    6ea0:	52800020 	mov	w0, #0x1                   	// #1
    6ea4:	39000280 	strb	w0, [x20]
    6ea8:	eb19035f 	cmp	x26, x25
    6eac:	540054c1 	b.ne	7944 <f12+0x11b4>  // b.any
    6eb0:	f94007e0 	ldr	x0, [sp, #8]
    6eb4:	910102f7 	add	x23, x23, #0x40
    6eb8:	f94023e1 	ldr	x1, [sp, #64]
    6ebc:	f90162e1 	str	x1, [x23, #704]
    6ec0:	97fffb54 	bl	5c10 <fwp_tape_scope_release>
    6ec4:	f9400260 	ldr	x0, [x19]
    6ec8:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    6ecc:	b7f83920 	tbnz	x0, #63, 75f0 <f12+0xe60>
    6ed0:	911542a2 	add	x2, x21, #0x550
    6ed4:	f949d840 	ldr	x0, [x2, #5040]
    6ed8:	f949ec41 	ldr	x1, [x2, #5080]
    6edc:	cb000260 	sub	x0, x19, x0
    6ee0:	eb01401f 	cmp	x0, x1, lsl #16
    6ee4:	54003862 	b.cs	75f0 <f12+0xe60>  // b.hs, b.nlast
    6ee8:	d350fc01 	lsr	x1, x0, #16
    6eec:	f949fc44 	ldr	x4, [x2, #5112]
    6ef0:	8b010821 	add	x1, x1, x1, lsl #2
    6ef4:	d37df021 	lsl	x1, x1, #3
    6ef8:	8b010083 	add	x3, x4, x1
    6efc:	f9401062 	ldr	x2, [x3, #32]
    6f00:	b4003782 	cbz	x2, 75f0 <f12+0xe60>
    6f04:	38616881 	ldrb	w1, [x4, x1]
    6f08:	7100083f 	cmp	w1, #0x2
    6f0c:	540036c0 	b.eq	75e4 <f12+0xe54>  // b.none
    6f10:	7100043f 	cmp	w1, #0x1
    6f14:	540036e1 	b.ne	75f0 <f12+0xe60>  // b.any
    6f18:	29430464 	ldp	w4, w1, [x3, #24]
    6f1c:	92403c00 	and	x0, x0, #0xffff
    6f20:	9b047c00 	mul	x0, x0, x4
    6f24:	d360fc00 	lsr	x0, x0, #32
    6f28:	eb01001f 	cmp	x0, x1
    6f2c:	54003622 	b.cs	75f0 <f12+0xe60>  // b.hs, b.nlast
    6f30:	8b000042 	add	x2, x2, x0
    6f34:	39400040 	ldrb	w0, [x2]
    6f38:	7100041f 	cmp	w0, #0x1
    6f3c:	540035a1 	b.ne	75f0 <f12+0xe60>  // b.any
    6f40:	aa1303f9 	mov	x25, x19
    6f44:	d2800000 	mov	x0, #0x0                   	// #0
    6f48:	f9000ff3 	str	x19, [sp, #24]
    6f4c:	f9400fe1 	ldr	x1, [sp, #24]
    6f50:	91002023 	add	x3, x1, #0x8
    6f54:	d2800001 	mov	x1, #0x0                   	// #0
    6f58:	b40005b7 	cbz	x23, 700c <f12+0x87c>
    6f5c:	b0000022 	adrp	x2, b000 <__modti3+0x180>
    6f60:	91002265 	add	x5, x19, #0x8
    6f64:	fd477c41 	ldr	d1, [x2, #3832]
    6f68:	14000009 	b	6f8c <f12+0x7fc>
    6f6c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    6f70:	f9400322 	ldr	x2, [x25]
    6f74:	1e600820 	fmul	d0, d1, d0
    6f78:	b7f84de2 	tbnz	x2, #63, 7934 <f12+0x11a4>
    6f7c:	91000421 	add	x1, x1, #0x1
    6f80:	fc008460 	str	d0, [x3], #8
    6f84:	eb0102ff 	cmp	x23, x1
    6f88:	54000420 	b.eq	700c <f12+0x87c>  // b.none
    6f8c:	f9400264 	ldr	x4, [x19]
    6f90:	aa0503e2 	mov	x2, x5
    6f94:	b6fffec4 	tbz	x4, #63, 6f6c <f12+0x7dc>
    6f98:	f9400a62 	ldr	x2, [x19, #16]
    6f9c:	17fffff4 	b	6f6c <f12+0x7dc>
    6fa0:	eb1b029f 	cmp	x20, x27
    6fa4:	54ffcb80 	b.eq	6914 <f12+0x184>  // b.none
    6fa8:	f94022fc 	ldr	x28, [x23, #64]
    6fac:	8b140681 	add	x1, x20, x20, lsl #1
    6fb0:	b0000020 	adrp	x0, b000 <__modti3+0x180>
    6fb4:	91116000 	add	x0, x0, #0x458
    6fb8:	8b010a9b 	add	x27, x20, x1, lsl #2
    6fbc:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6fc0:	f900337f 	str	xzr, [x27, #96]
    6fc4:	97ffee6f 	bl	2980 <getenv@plt>
    6fc8:	b4ffcfc0 	cbz	x0, 69c0 <f12+0x230>
    6fcc:	39400001 	ldrb	w1, [x0]
    6fd0:	7100c03f 	cmp	w1, #0x30
    6fd4:	54ffcf61 	b.ne	69c0 <f12+0x230>  // b.any
    6fd8:	39400400 	ldrb	w0, [x0, #1]
    6fdc:	34ffcf80 	cbz	w0, 69cc <f12+0x23c>
    6fe0:	17fffe78 	b	69c0 <f12+0x230>
    6fe4:	aa0303e0 	mov	x0, x3
    6fe8:	d37df262 	lsl	x2, x19, #3
    6fec:	52800001 	mov	w1, #0x0                   	// #0
    6ff0:	a90117e4 	stp	x4, x5, [sp, #16]
    6ff4:	a9021fe6 	stp	x6, x7, [sp, #32]
    6ff8:	97ffedf2 	bl	27c0 <memset@plt>
    6ffc:	aa0003e3 	mov	x3, x0
    7000:	a94117e4 	ldp	x4, x5, [sp, #16]
    7004:	a9421fe6 	ldp	x6, x7, [sp, #32]
    7008:	17ffff4c 	b	6d38 <f12+0x5a8>
    700c:	97fffd41 	bl	6510 <fwp_drop4>
    7010:	aa1603e1 	mov	x1, x22
    7014:	d2800002 	mov	x2, #0x0                   	// #0
    7018:	b4004036 	cbz	x22, 781c <f12+0x108c>
    701c:	d503201f 	nop
    7020:	f9400821 	ldr	x1, [x1, #16]
    7024:	91000442 	add	x2, x2, #0x1
    7028:	b5ffffc1 	cbnz	x1, 7020 <f12+0x890>
    702c:	f9400323 	ldr	x3, [x25]
    7030:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    7034:	b7f82a23 	tbnz	x3, #63, 7578 <f12+0xde8>
    7038:	911542a1 	add	x1, x21, #0x550
    703c:	f9400fe4 	ldr	x4, [sp, #24]
    7040:	f949d820 	ldr	x0, [x1, #5040]
    7044:	f949ec21 	ldr	x1, [x1, #5080]
    7048:	cb000080 	sub	x0, x4, x0
    704c:	eb01401f 	cmp	x0, x1, lsl #16
    7050:	54002942 	b.cs	7578 <f12+0xde8>  // b.hs, b.nlast
    7054:	911542a4 	add	x4, x21, #0x550
    7058:	d350fc01 	lsr	x1, x0, #16
    705c:	8b010821 	add	x1, x1, x1, lsl #2
    7060:	f949fc86 	ldr	x6, [x4, #5112]
    7064:	d37df021 	lsl	x1, x1, #3
    7068:	8b0100c5 	add	x5, x6, x1
    706c:	f94010a4 	ldr	x4, [x5, #32]
    7070:	b4002824 	cbz	x4, 7574 <f12+0xde4>
    7074:	386168c1 	ldrb	w1, [x6, x1]
    7078:	7100083f 	cmp	w1, #0x2
    707c:	54002780 	b.eq	756c <f12+0xddc>  // b.none
    7080:	7100043f 	cmp	w1, #0x1
    7084:	54002781 	b.ne	7574 <f12+0xde4>  // b.any
    7088:	294304a6 	ldp	w6, w1, [x5, #24]
    708c:	92403c00 	and	x0, x0, #0xffff
    7090:	9b067c00 	mul	x0, x0, x6
    7094:	d360fc00 	lsr	x0, x0, #32
    7098:	eb01001f 	cmp	x0, x1
    709c:	540026c2 	b.cs	7574 <f12+0xde4>  // b.hs, b.nlast
    70a0:	8b000084 	add	x4, x4, x0
    70a4:	39400097 	ldrb	w23, [x4]
    70a8:	710006ff 	cmp	w23, #0x1
    70ac:	54002641 	b.ne	7574 <f12+0xde4>  // b.any
    70b0:	b90023f7 	str	w23, [sp, #32]
    70b4:	eb02027f 	cmp	x19, x2
    70b8:	9a829273 	csel	x19, x19, x2, ls	// ls = plast
    70bc:	9100233a 	add	x26, x25, #0x8
    70c0:	b4003e53 	cbz	x19, 7888 <f12+0x10f8>
    70c4:	f9400fe0 	ldr	x0, [sp, #24]
    70c8:	d37df265 	lsl	x5, x19, #3
    70cc:	aa1603e2 	mov	x2, x22
    70d0:	d2800001 	mov	x1, #0x0                   	// #0
    70d4:	91002000 	add	x0, x0, #0x8
    70d8:	1400000a 	b	7100 <f12+0x970>
    70dc:	fc616881 	ldr	d1, [x4, x1]
    70e0:	fd400440 	ldr	d0, [x2, #8]
    70e4:	1e613800 	fsub	d0, d0, d1
    70e8:	fc216b40 	str	d0, [x26, x1]
    70ec:	91002021 	add	x1, x1, #0x8
    70f0:	f9400842 	ldr	x2, [x2, #16]
    70f4:	eb05003f 	cmp	x1, x5
    70f8:	540001c0 	b.eq	7130 <f12+0x9a0>  // b.none
    70fc:	f9400323 	ldr	x3, [x25]
    7100:	aa0003e4 	mov	x4, x0
    7104:	b6fffec3 	tbz	x3, #63, 70dc <f12+0x94c>
    7108:	f9400fe3 	ldr	x3, [sp, #24]
    710c:	fd400440 	ldr	d0, [x2, #8]
    7110:	f9400864 	ldr	x4, [x3, #16]
    7114:	fc616881 	ldr	d1, [x4, x1]
    7118:	1e613800 	fsub	d0, d0, d1
    711c:	fc216b40 	str	d0, [x26, x1]
    7120:	91002021 	add	x1, x1, #0x8
    7124:	f9400842 	ldr	x2, [x2, #16]
    7128:	eb05003f 	cmp	x1, x5
    712c:	54fffe81 	b.ne	70fc <f12+0x96c>  // b.any
    7130:	b4003a96 	cbz	x22, 7880 <f12+0x10f0>
    7134:	911542a0 	add	x0, x21, #0x550
    7138:	aa1603e2 	mov	x2, x22
    713c:	d280001b 	mov	x27, #0x0                   	// #0
    7140:	f949ec06 	ldr	x6, [x0, #5080]
    7144:	f949d807 	ldr	x7, [x0, #5040]
    7148:	f949fc05 	ldr	x5, [x0, #5112]
    714c:	d370bcc6 	lsl	x6, x6, #16
    7150:	14000006 	b	7168 <f12+0x9d8>
    7154:	f9400842 	ldr	x2, [x2, #16]
    7158:	9100077b 	add	x27, x27, #0x1
    715c:	f100005f 	cmp	x2, #0x0
    7160:	fa5b1260 	ccmp	x19, x27, #0x0, ne	// ne = any
    7164:	540029a9 	b.ls	7698 <f12+0xf08>  // b.plast
    7168:	cb070040 	sub	x0, x2, x7
    716c:	eb06001f 	cmp	x0, x6
    7170:	540002c2 	b.cs	71c8 <f12+0xa38>  // b.hs, b.nlast
    7174:	d350fc01 	lsr	x1, x0, #16
    7178:	8b010821 	add	x1, x1, x1, lsl #2
    717c:	d37df021 	lsl	x1, x1, #3
    7180:	8b0100a4 	add	x4, x5, x1
    7184:	f9401083 	ldr	x3, [x4, #32]
    7188:	b4000203 	cbz	x3, 71c8 <f12+0xa38>
    718c:	386168a1 	ldrb	w1, [x5, x1]
    7190:	7100083f 	cmp	w1, #0x2
    7194:	54000de0 	b.eq	7350 <f12+0xbc0>  // b.none
    7198:	7100043f 	cmp	w1, #0x1
    719c:	54000161 	b.ne	71c8 <f12+0xa38>  // b.any
    71a0:	29430488 	ldp	w8, w1, [x4, #24]
    71a4:	92403c00 	and	x0, x0, #0xffff
    71a8:	9b087c00 	mul	x0, x0, x8
    71ac:	d360fc00 	lsr	x0, x0, #32
    71b0:	eb01001f 	cmp	x0, x1
    71b4:	540000a2 	b.cs	71c8 <f12+0xa38>  // b.hs, b.nlast
    71b8:	8b000063 	add	x3, x3, x0
    71bc:	39400060 	ldrb	w0, [x3]
    71c0:	7100041f 	cmp	w0, #0x1
    71c4:	54fffc80 	b.eq	7154 <f12+0x9c4>  // b.none
    71c8:	eb13037f 	cmp	x27, x19
    71cc:	54000ca2 	b.cs	7360 <f12+0xbd0>  // b.hs, b.nlast
    71d0:	90000020 	adrp	x0, b000 <__modti3+0x180>
    71d4:	d1002357 	sub	x23, x26, #0x8
    71d8:	911542b8 	add	x24, x21, #0x550
    71dc:	d2800019 	mov	x25, #0x0                   	// #0
    71e0:	fd476808 	ldr	d8, [x0, #3792]
    71e4:	14000042 	b	72ec <f12+0xb5c>
    71e8:	f9400381 	ldr	x1, [x28]
    71ec:	aa2103e1 	mvn	x1, x1
    71f0:	f8207b01 	str	x1, [x24, x0, lsl #3]
    71f4:	f100609f 	cmp	x4, #0x18
    71f8:	54000169 	b.ls	7224 <f12+0xa94>  // b.plast
    71fc:	d1006482 	sub	x2, x4, #0x19
    7200:	91006380 	add	x0, x28, #0x18
    7204:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7208:	52800001 	mov	w1, #0x0                   	// #0
    720c:	91002042 	add	x2, x2, #0x8
    7210:	f90007e4 	str	x4, [sp, #8]
    7214:	b90013e5 	str	w5, [sp, #16]
    7218:	97ffed6a 	bl	27c0 <memset@plt>
    721c:	f94007e4 	ldr	x4, [sp, #8]
    7220:	b94013e5 	ldr	w5, [sp, #16]
    7224:	911542a2 	add	x2, x21, #0x550
    7228:	f94a1041 	ldr	x1, [x2, #5152]
    722c:	ab040021 	adds	x1, x1, x4
    7230:	54003382 	b.cs	78a0 <f12+0x1110>  // b.hs, b.nlast
    7234:	f94a1440 	ldr	x0, [x2, #5160]
    7238:	f90a1041 	str	x1, [x2, #5152]
    723c:	eb00003f 	cmp	x1, x0
    7240:	54000049 	b.ls	7248 <f12+0xab8>  // b.plast
    7244:	f90a1441 	str	x1, [x2, #5160]
    7248:	911542a0 	add	x0, x21, #0x550
    724c:	1e6300a1 	ucvtf	d1, w5
    7250:	fd4a1c00 	ldr	d0, [x0, #5176]
    7254:	1e612800 	fadd	d0, d0, d1
    7258:	fd0a1c00 	str	d0, [x0, #5176]
    725c:	a900e794 	stp	x20, x25, [x28, #8]
    7260:	aa1c03f9 	mov	x25, x28
    7264:	fd000388 	str	d8, [x28]
    7268:	f949db01 	ldr	x1, [x24, #5040]
    726c:	f949ef00 	ldr	x0, [x24, #5080]
    7270:	cb010381 	sub	x1, x28, x1
    7274:	eb00403f 	cmp	x1, x0, lsl #16
    7278:	54000322 	b.cs	72dc <f12+0xb4c>  // b.hs, b.nlast
    727c:	d350fc20 	lsr	x0, x1, #16
    7280:	f949ff04 	ldr	x4, [x24, #5112]
    7284:	8b000800 	add	x0, x0, x0, lsl #2
    7288:	d37df002 	lsl	x2, x0, #3
    728c:	8b020080 	add	x0, x4, x2
    7290:	f940101c 	ldr	x28, [x0, #32]
    7294:	b400025c 	cbz	x28, 72dc <f12+0xb4c>
    7298:	38626882 	ldrb	w2, [x4, x2]
    729c:	7100085f 	cmp	w2, #0x2
    72a0:	54000ae0 	b.eq	73fc <f12+0xc6c>  // b.none
    72a4:	7100045f 	cmp	w2, #0x1
    72a8:	540001a1 	b.ne	72dc <f12+0xb4c>  // b.any
    72ac:	29430002 	ldp	w2, w0, [x0, #24]
    72b0:	92403c21 	and	x1, x1, #0xffff
    72b4:	9b027c21 	mul	x1, x1, x2
    72b8:	d360fc21 	lsr	x1, x1, #32
    72bc:	eb00003f 	cmp	x1, x0
    72c0:	540000e2 	b.cs	72dc <f12+0xb4c>  // b.hs, b.nlast
    72c4:	8b01039c 	add	x28, x28, x1
    72c8:	39400380 	ldrb	w0, [x28]
    72cc:	7103fc1f 	cmp	w0, #0xff
    72d0:	54002040 	b.eq	76d8 <f12+0xf48>  // b.none
    72d4:	52800020 	mov	w0, #0x1                   	// #1
    72d8:	39000380 	strb	w0, [x28]
    72dc:	d1000660 	sub	x0, x19, #0x1
    72e0:	eb00037f 	cmp	x27, x0
    72e4:	54000962 	b.cs	7410 <f12+0xc80>  // b.hs, b.nlast
    72e8:	aa0003f3 	mov	x19, x0
    72ec:	b953a700 	ldr	w0, [x24, #5028]
    72f0:	f8737af4 	ldr	x20, [x23, x19, lsl #3]
    72f4:	34000240 	cbz	w0, 733c <f12+0xbac>
    72f8:	397e8b00 	ldrb	w0, [x24, #4002]
    72fc:	910f0001 	add	x1, x0, #0x3c0
    7300:	8b000400 	add	x0, x0, x0, lsl #1
    7304:	b8617b05 	ldr	w5, [x24, x1, lsl #2]
    7308:	8b000f01 	add	x1, x24, x0, lsl #3
    730c:	f8607b1c 	ldr	x28, [x24, x0, lsl #3]
    7310:	2a0503e4 	mov	w4, w5
    7314:	b5fff6bc 	cbnz	x28, 71e8 <f12+0xa58>
    7318:	f940043c 	ldr	x28, [x1, #8]
    731c:	b400011c 	cbz	x28, 733c <f12+0xbac>
    7320:	f9400820 	ldr	x0, [x1, #16]
    7324:	cb1c0000 	sub	x0, x0, x28
    7328:	eb00009f 	cmp	x4, x0
    732c:	54000088 	b.hi	733c <f12+0xbac>  // b.pmore
    7330:	8b040380 	add	x0, x28, x4
    7334:	f9000420 	str	x0, [x1, #8]
    7338:	17ffffaf 	b	71f4 <f12+0xa64>
    733c:	52800001 	mov	w1, #0x0                   	// #0
    7340:	d2800300 	mov	x0, #0x18                  	// #24
    7344:	97fff62b 	bl	4bf0 <fwp_heap_alloc>
    7348:	aa0003fc 	mov	x28, x0
    734c:	17ffffc4 	b	725c <f12+0xacc>
    7350:	72003c1f 	tst	w0, #0xffff
    7354:	54fff340 	b.eq	71bc <f12+0xa2c>  // b.none
    7358:	eb13037f 	cmp	x27, x19
    735c:	54fff3a3 	b.cc	71d0 <f12+0xa40>  // b.lo, b.ul, b.last
    7360:	d2800019 	mov	x25, #0x0                   	// #0
    7364:	8b1b0f5b 	add	x27, x26, x27, lsl #3
    7368:	aa1a03e1 	mov	x1, x26
    736c:	aa1603e0 	mov	x0, x22
    7370:	f8408422 	ldr	x2, [x1], #8
    7374:	f9000402 	str	x2, [x0, #8]
    7378:	aa0003e2 	mov	x2, x0
    737c:	f9400800 	ldr	x0, [x0, #16]
    7380:	eb1b003f 	cmp	x1, x27
    7384:	54ffff61 	b.ne	7370 <f12+0xbe0>  // b.any
    7388:	b94023e1 	ldr	w1, [sp, #32]
    738c:	f9000859 	str	x25, [x2, #16]
    7390:	aa1603f9 	mov	x25, x22
    7394:	aa0003f6 	mov	x22, x0
    7398:	34000041 	cbz	w1, 73a0 <f12+0xc10>
    739c:	d280001a 	mov	x26, #0x0                   	// #0
    73a0:	aa1a03e0 	mov	x0, x26
    73a4:	97fff4f3 	bl	4770 <fwp_mem_free>
    73a8:	f9400fe0 	ldr	x0, [sp, #24]
    73ac:	97fffc59 	bl	6510 <fwp_drop4>
    73b0:	aa1603e0 	mov	x0, x22
    73b4:	97fff8db 	bl	5720 <fwp_drop0>
    73b8:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    73bc:	f947f400 	ldr	x0, [x0, #4072]
    73c0:	f94057e2 	ldr	x2, [sp, #168]
    73c4:	f9400001 	ldr	x1, [x0]
    73c8:	eb010042 	subs	x2, x2, x1
    73cc:	d2800001 	mov	x1, #0x0                   	// #0
    73d0:	54002b81 	b.ne	7940 <f12+0x11b0>  // b.any
    73d4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    73d8:	aa1903e0 	mov	x0, x25
    73dc:	a94c53f3 	ldp	x19, x20, [sp, #192]
    73e0:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    73e4:	a94e63f7 	ldp	x23, x24, [sp, #224]
    73e8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    73ec:	a95073fb 	ldp	x27, x28, [sp, #256]
    73f0:	fd408be8 	ldr	d8, [sp, #272]
    73f4:	910483ff 	add	sp, sp, #0x120
    73f8:	d65f03c0 	ret
    73fc:	72003c3f 	tst	w1, #0xffff
    7400:	54fff640 	b.eq	72c8 <f12+0xb38>  // b.none
    7404:	d1000660 	sub	x0, x19, #0x1
    7408:	eb00037f 	cmp	x27, x0
    740c:	54fff6e3 	b.cc	72e8 <f12+0xb58>  // b.lo, b.ul, b.last
    7410:	b5fffabb 	cbnz	x27, 7364 <f12+0xbd4>
    7414:	b94023e1 	ldr	w1, [sp, #32]
    7418:	7100003f 	cmp	w1, #0x0
    741c:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    7420:	b4fffc00 	cbz	x0, 73a0 <f12+0xc10>
    7424:	911542b5 	add	x21, x21, #0x550
    7428:	90000020 	adrp	x0, b000 <__modti3+0x180>
    742c:	d1000a73 	sub	x19, x19, #0x2
    7430:	52800034 	mov	w20, #0x1                   	// #1
    7434:	fd476808 	ldr	d8, [x0, #3792]
    7438:	b953a6a0 	ldr	w0, [x21, #5028]
    743c:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    7440:	340008c0 	cbz	w0, 7558 <f12+0xdc8>
    7444:	d503201f 	nop
    7448:	397e8aa0 	ldrb	w0, [x21, #4002]
    744c:	910f0001 	add	x1, x0, #0x3c0
    7450:	8b000400 	add	x0, x0, x0, lsl #1
    7454:	b8617abc 	ldr	w28, [x21, x1, lsl #2]
    7458:	8b000ea1 	add	x1, x21, x0, lsl #3
    745c:	f8607ab7 	ldr	x23, [x21, x0, lsl #3]
    7460:	2a1c03fb 	mov	w27, w28
    7464:	b4002277 	cbz	x23, 78b0 <f12+0x1120>
    7468:	f94002e1 	ldr	x1, [x23]
    746c:	aa2103e1 	mvn	x1, x1
    7470:	f8207aa1 	str	x1, [x21, x0, lsl #3]
    7474:	f100637f 	cmp	x27, #0x18
    7478:	540000e9 	b.ls	7494 <f12+0xd04>  // b.plast
    747c:	d1006762 	sub	x2, x27, #0x19
    7480:	910062e0 	add	x0, x23, #0x18
    7484:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7488:	52800001 	mov	w1, #0x0                   	// #0
    748c:	91002042 	add	x2, x2, #0x8
    7490:	97ffeccc 	bl	27c0 <memset@plt>
    7494:	f94a12a0 	ldr	x0, [x21, #5152]
    7498:	ab1b0000 	adds	x0, x0, x27
    749c:	54002022 	b.cs	78a0 <f12+0x1110>  // b.hs, b.nlast
    74a0:	f94a16a1 	ldr	x1, [x21, #5160]
    74a4:	f90a12a0 	str	x0, [x21, #5152]
    74a8:	eb01001f 	cmp	x0, x1
    74ac:	54000049 	b.ls	74b4 <f12+0xd24>  // b.plast
    74b0:	f90a16a0 	str	x0, [x21, #5160]
    74b4:	1e630381 	ucvtf	d1, w28
    74b8:	fd4a1ea0 	ldr	d0, [x21, #5176]
    74bc:	1e612800 	fadd	d0, d0, d1
    74c0:	fd0a1ea0 	str	d0, [x21, #5176]
    74c4:	a900e6f8 	stp	x24, x25, [x23, #8]
    74c8:	aa1703f9 	mov	x25, x23
    74cc:	fd0002e8 	str	d8, [x23]
    74d0:	f949daa1 	ldr	x1, [x21, #5040]
    74d4:	f949eea0 	ldr	x0, [x21, #5080]
    74d8:	cb0102e1 	sub	x1, x23, x1
    74dc:	eb00403f 	cmp	x1, x0, lsl #16
    74e0:	54000302 	b.cs	7540 <f12+0xdb0>  // b.hs, b.nlast
    74e4:	d350fc22 	lsr	x2, x1, #16
    74e8:	f949fea3 	ldr	x3, [x21, #5112]
    74ec:	8b020842 	add	x2, x2, x2, lsl #2
    74f0:	d37df042 	lsl	x2, x2, #3
    74f4:	8b020060 	add	x0, x3, x2
    74f8:	f9401017 	ldr	x23, [x0, #32]
    74fc:	b4000237 	cbz	x23, 7540 <f12+0xdb0>
    7500:	38626862 	ldrb	w2, [x3, x2]
    7504:	7100085f 	cmp	w2, #0x2
    7508:	54001e60 	b.eq	78d4 <f12+0x1144>  // b.none
    750c:	7100045f 	cmp	w2, #0x1
    7510:	54000181 	b.ne	7540 <f12+0xdb0>  // b.any
    7514:	29430002 	ldp	w2, w0, [x0, #24]
    7518:	92403c21 	and	x1, x1, #0xffff
    751c:	9b027c21 	mul	x1, x1, x2
    7520:	d360fc21 	lsr	x1, x1, #32
    7524:	eb00003f 	cmp	x1, x0
    7528:	540000c2 	b.cs	7540 <f12+0xdb0>  // b.hs, b.nlast
    752c:	8b0102f7 	add	x23, x23, x1
    7530:	394002e0 	ldrb	w0, [x23]
    7534:	7103fc1f 	cmp	w0, #0xff
    7538:	54001b60 	b.eq	78a4 <f12+0x1114>  // b.none
    753c:	390002f4 	strb	w20, [x23]
    7540:	d1000673 	sub	x19, x19, #0x1
    7544:	b100067f 	cmn	x19, #0x1
    7548:	54fff2c0 	b.eq	73a0 <f12+0xc10>  // b.none
    754c:	b953a6a0 	ldr	w0, [x21, #5028]
    7550:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    7554:	35fff7a0 	cbnz	w0, 7448 <f12+0xcb8>
    7558:	52800001 	mov	w1, #0x0                   	// #0
    755c:	d2800300 	mov	x0, #0x18                  	// #24
    7560:	97fff5a4 	bl	4bf0 <fwp_heap_alloc>
    7564:	aa0003f7 	mov	x23, x0
    7568:	17ffffd7 	b	74c4 <f12+0xd34>
    756c:	72003c1f 	tst	w0, #0xffff
    7570:	54ffd9a0 	b.eq	70a4 <f12+0x914>  // b.none
    7574:	b4001336 	cbz	x22, 77d8 <f12+0x1048>
    7578:	aa1603f7 	mov	x23, x22
    757c:	d2800018 	mov	x24, #0x0                   	// #0
    7580:	f9400af7 	ldr	x23, [x23, #16]
    7584:	aa1803e0 	mov	x0, x24
    7588:	91000718 	add	x24, x24, #0x1
    758c:	b5ffffb7 	cbnz	x23, 7580 <f12+0xdf0>
    7590:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7594:	eb01031f 	cmp	x24, x1
    7598:	54001b68 	b.hi	7904 <f12+0x1174>  // b.pmore
    759c:	91000800 	add	x0, x0, #0x2
    75a0:	52800041 	mov	w1, #0x2                   	// #2
    75a4:	d37df000 	lsl	x0, x0, #3
    75a8:	97fff592 	bl	4bf0 <fwp_heap_alloc>
    75ac:	eb13031f 	cmp	x24, x19
    75b0:	aa0003fa 	mov	x26, x0
    75b4:	9a939313 	csel	x19, x24, x19, ls	// ls = plast
    75b8:	aa1603e1 	mov	x1, x22
    75bc:	d503201f 	nop
    75c0:	f9400420 	ldr	x0, [x1, #8]
    75c4:	f8377b40 	str	x0, [x26, x23, lsl #3]
    75c8:	910006f7 	add	x23, x23, #0x1
    75cc:	f9400821 	ldr	x1, [x1, #16]
    75d0:	b5ffff81 	cbnz	x1, 75c0 <f12+0xe30>
    75d4:	b40010b3 	cbz	x19, 77e8 <f12+0x1058>
    75d8:	f9400323 	ldr	x3, [x25]
    75dc:	b90023ff 	str	wzr, [sp, #32]
    75e0:	17fffeb9 	b	70c4 <f12+0x934>
    75e4:	72003c1f 	tst	w0, #0xffff
    75e8:	54ffca60 	b.eq	6f34 <f12+0x7a4>  // b.none
    75ec:	d503201f 	nop
    75f0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    75f4:	eb0002ff 	cmp	x23, x0
    75f8:	54001808 	b.hi	78f8 <f12+0x1168>  // b.pmore
    75fc:	910006e0 	add	x0, x23, #0x1
    7600:	52800021 	mov	w1, #0x1                   	// #1
    7604:	d37df000 	lsl	x0, x0, #3
    7608:	97fff57a 	bl	4bf0 <fwp_heap_alloc>
    760c:	911542a2 	add	x2, x21, #0x550
    7610:	f9000017 	str	x23, [x0]
    7614:	aa0003f9 	mov	x25, x0
    7618:	f9000ff9 	str	x25, [sp, #24]
    761c:	f949d841 	ldr	x1, [x2, #5040]
    7620:	f949ec40 	ldr	x0, [x2, #5080]
    7624:	cb010321 	sub	x1, x25, x1
    7628:	eb00403f 	cmp	x1, x0, lsl #16
    762c:	54000322 	b.cs	7690 <f12+0xf00>  // b.hs, b.nlast
    7630:	d350fc20 	lsr	x0, x1, #16
    7634:	f949fc43 	ldr	x3, [x2, #5112]
    7638:	8b000800 	add	x0, x0, x0, lsl #2
    763c:	d37df002 	lsl	x2, x0, #3
    7640:	8b020060 	add	x0, x3, x2
    7644:	f9401018 	ldr	x24, [x0, #32]
    7648:	b4000258 	cbz	x24, 7690 <f12+0xf00>
    764c:	38626862 	ldrb	w2, [x3, x2]
    7650:	7100085f 	cmp	w2, #0x2
    7654:	54000ce0 	b.eq	77f0 <f12+0x1060>  // b.none
    7658:	7100045f 	cmp	w2, #0x1
    765c:	540001a1 	b.ne	7690 <f12+0xf00>  // b.any
    7660:	29430002 	ldp	w2, w0, [x0, #24]
    7664:	92403c21 	and	x1, x1, #0xffff
    7668:	9b027c21 	mul	x1, x1, x2
    766c:	d360fc21 	lsr	x1, x1, #32
    7670:	eb00003f 	cmp	x1, x0
    7674:	540000e2 	b.cs	7690 <f12+0xf00>  // b.hs, b.nlast
    7678:	8b010318 	add	x24, x24, x1
    767c:	39400300 	ldrb	w0, [x24]
    7680:	7103fc1f 	cmp	w0, #0xff
    7684:	54000f40 	b.eq	786c <f12+0x10dc>  // b.none
    7688:	52800020 	mov	w0, #0x1                   	// #1
    768c:	39000300 	strb	w0, [x24]
    7690:	aa1303e0 	mov	x0, x19
    7694:	17fffe2e 	b	6f4c <f12+0x7bc>
    7698:	eb1b027f 	cmp	x19, x27
    769c:	54ffd9a8 	b.hi	71d0 <f12+0xa40>  // b.pmore
    76a0:	17ffff30 	b	7360 <f12+0xbd0>
    76a4:	52800041 	mov	w1, #0x2                   	// #2
    76a8:	d2800100 	mov	x0, #0x8                   	// #8
    76ac:	97fff551 	bl	4bf0 <fwp_heap_alloc>
    76b0:	aa0003fb 	mov	x27, x0
    76b4:	911542a0 	add	x0, x21, #0x550
    76b8:	f900037f 	str	xzr, [x27]
    76bc:	f949d801 	ldr	x1, [x0, #5040]
    76c0:	f949ec00 	ldr	x0, [x0, #5080]
    76c4:	cb010361 	sub	x1, x27, x1
    76c8:	eb00403f 	cmp	x1, x0, lsl #16
    76cc:	54000362 	b.cs	7738 <f12+0xfa8>  // b.hs, b.nlast
    76d0:	d2800013 	mov	x19, #0x0                   	// #0
    76d4:	17fffd00 	b	6ad4 <f12+0x344>
    76d8:	aa1c03e0 	mov	x0, x28
    76dc:	97fff385 	bl	44f0 <fwp_rc_forget_slot>
    76e0:	17fffefd 	b	72d4 <f12+0xb44>
    76e4:	f100027f 	cmp	x19, #0x0
    76e8:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    76ec:	54ffb241 	b.ne	6d34 <f12+0x5a4>  // b.any
    76f0:	f9402fe1 	ldr	x1, [sp, #88]
    76f4:	910102f7 	add	x23, x23, #0x40
    76f8:	aa1a03e0 	mov	x0, x26
    76fc:	f90162e1 	str	x1, [x23, #704]
    7700:	97fff260 	bl	4080 <fwp_tape_buffers_release>
    7704:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7708:	f947e863 	ldr	x3, [x3, #4048]
    770c:	d2800262 	mov	x2, #0x13                  	// #19
    7710:	d2800021 	mov	x1, #0x1                   	// #1
    7714:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7718:	9108a000 	add	x0, x0, #0x228
    771c:	f9400063 	ldr	x3, [x3]
    7720:	97ffec74 	bl	28f0 <fwrite@plt>
    7724:	d2800000 	mov	x0, #0x0                   	// #0
    7728:	97ffec7e 	bl	2920 <fflush@plt>
    772c:	52800cc0 	mov	w0, #0x66                  	// #102
    7730:	97ffec8c 	bl	2960 <_Exit@plt>
    7734:	b5ffa053 	cbnz	x19, 6b3c <f12+0x3ac>
    7738:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    773c:	f900037f 	str	xzr, [x27]
    7740:	17fffd33 	b	6c0c <f12+0x47c>
    7744:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    7748:	912c4000 	add	x0, x0, #0xb10
    774c:	94000ea9 	bl	b1f0 <atexit>
    7750:	35fffda0 	cbnz	w0, 7704 <f12+0xf74>
    7754:	52800020 	mov	w0, #0x1                   	// #1
    7758:	b902f680 	str	w0, [x20, #756]
    775c:	17fffc5b 	b	68c8 <f12+0x138>
    7760:	72003c3f 	tst	w1, #0xffff
    7764:	54ff9ea1 	b.ne	6b38 <f12+0x3a8>  // b.any
    7768:	17fffcef 	b	6b24 <f12+0x394>
    776c:	72003c3f 	tst	w1, #0xffff
    7770:	54ff8800 	b.eq	6870 <f12+0xe0>  // b.none
    7774:	aa1403e0 	mov	x0, x20
    7778:	97fff846 	bl	5890 <fwp_closure_drop>
    777c:	b5ff88d6 	cbnz	x22, 6894 <f12+0x104>
    7780:	d280001a 	mov	x26, #0x0                   	// #0
    7784:	17fffc4e 	b	68bc <f12+0x12c>
    7788:	72003c3f 	tst	w1, #0xffff
    778c:	54ffb8e1 	b.ne	6ea8 <f12+0x718>  // b.any
    7790:	17fffdc1 	b	6e94 <f12+0x704>
    7794:	aa1c03f3 	mov	x19, x28
    7798:	17fffd50 	b	6cd8 <f12+0x548>
    779c:	3cc48002 	ldur	q2, [x0, #72]
    77a0:	91012001 	add	x1, x0, #0x48
    77a4:	3cc58001 	ldur	q1, [x0, #88]
    77a8:	f900401f 	str	xzr, [x0, #128]
    77ac:	4f000400 	movi	v0.4s, #0x0
    77b0:	ad010762 	stp	q2, q1, [x27, #32]
    77b4:	a9468002 	ldp	x2, x0, [x0, #104]
    77b8:	f9000f60 	str	x0, [x27, #24]
    77bc:	f9401820 	ldr	x0, [x1, #48]
    77c0:	f9002362 	str	x2, [x27, #64]
    77c4:	f9002760 	str	x0, [x27, #72]
    77c8:	ad000020 	stp	q0, q0, [x1]
    77cc:	3d800820 	str	q0, [x1, #32]
    77d0:	f900183f 	str	xzr, [x1, #48]
    77d4:	17fffc7e 	b	69cc <f12+0x23c>
    77d8:	52800041 	mov	w1, #0x2                   	// #2
    77dc:	d2800100 	mov	x0, #0x8                   	// #8
    77e0:	97fff504 	bl	4bf0 <fwp_heap_alloc>
    77e4:	aa0003fa 	mov	x26, x0
    77e8:	d2800019 	mov	x25, #0x0                   	// #0
    77ec:	17fffeed 	b	73a0 <f12+0xc10>
    77f0:	72003c3f 	tst	w1, #0xffff
    77f4:	54fff440 	b.eq	767c <f12+0xeec>  // b.none
    77f8:	aa1303e0 	mov	x0, x19
    77fc:	17fffdd4 	b	6f4c <f12+0x7bc>
    7800:	aa1b03e0 	mov	x0, x27
    7804:	d2800101 	mov	x1, #0x8                   	// #8
    7808:	97ffebf2 	bl	27d0 <calloc@plt>
    780c:	aa0003e3 	mov	x3, x0
    7810:	a94117e4 	ldp	x4, x5, [sp, #16]
    7814:	a9421fe6 	ldp	x6, x7, [sp, #32]
    7818:	17fffd44 	b	6d28 <f12+0x598>
    781c:	f9400323 	ldr	x3, [x25]
    7820:	b7fffdc3 	tbnz	x3, #63, 77d8 <f12+0x1048>
    7824:	911542a1 	add	x1, x21, #0x550
    7828:	f9400fe4 	ldr	x4, [sp, #24]
    782c:	f949d820 	ldr	x0, [x1, #5040]
    7830:	f949ec21 	ldr	x1, [x1, #5080]
    7834:	cb000080 	sub	x0, x4, x0
    7838:	eb01401f 	cmp	x0, x1, lsl #16
    783c:	54fffce2 	b.cs	77d8 <f12+0x1048>  // b.hs, b.nlast
    7840:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    7844:	17fffe04 	b	7054 <f12+0x8c4>
    7848:	d2800d01 	mov	x1, #0x68                  	// #104
    784c:	d2800038 	mov	x24, #0x1                   	// #1
    7850:	17fffc41 	b	6954 <f12+0x1c4>
    7854:	aa1403e0 	mov	x0, x20
    7858:	97fff326 	bl	44f0 <fwp_rc_forget_slot>
    785c:	17fffcb5 	b	6b30 <f12+0x3a0>
    7860:	aa1403e0 	mov	x0, x20
    7864:	97fff323 	bl	44f0 <fwp_rc_forget_slot>
    7868:	17fffd8e 	b	6ea0 <f12+0x710>
    786c:	aa1803e0 	mov	x0, x24
    7870:	97fff320 	bl	44f0 <fwp_rc_forget_slot>
    7874:	17ffff85 	b	7688 <f12+0xef8>
    7878:	97fff2d7 	bl	43d4 <fwp_rc_wide_dup>
    787c:	17fffc03 	b	6888 <f12+0xf8>
    7880:	d280001b 	mov	x27, #0x0                   	// #0
    7884:	17fffe53 	b	71d0 <f12+0xa40>
    7888:	d280001a 	mov	x26, #0x0                   	// #0
    788c:	d2800019 	mov	x25, #0x0                   	// #0
    7890:	17fffec4 	b	73a0 <f12+0xc10>
    7894:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7898:	9116a000 	add	x0, x0, #0x5a8
    789c:	97ffef19 	bl	3500 <fwp_trap>
    78a0:	97ffedc4 	bl	2fb0 <fwp_heap_oom>
    78a4:	aa1703e0 	mov	x0, x23
    78a8:	97fff312 	bl	44f0 <fwp_rc_forget_slot>
    78ac:	17ffff24 	b	753c <f12+0xdac>
    78b0:	f9400437 	ldr	x23, [x1, #8]
    78b4:	b4ffe537 	cbz	x23, 7558 <f12+0xdc8>
    78b8:	f9400820 	ldr	x0, [x1, #16]
    78bc:	cb170000 	sub	x0, x0, x23
    78c0:	eb00037f 	cmp	x27, x0
    78c4:	54ffe4a8 	b.hi	7558 <f12+0xdc8>  // b.pmore
    78c8:	8b1b02e0 	add	x0, x23, x27
    78cc:	f9000420 	str	x0, [x1, #8]
    78d0:	17fffee9 	b	7474 <f12+0xce4>
    78d4:	72003c3f 	tst	w1, #0xffff
    78d8:	54ffe341 	b.ne	7540 <f12+0xdb0>  // b.any
    78dc:	17ffff15 	b	7530 <f12+0xda0>
    78e0:	90000020 	adrp	x0, b000 <__modti3+0x180>
    78e4:	91144000 	add	x0, x0, #0x510
    78e8:	97ffef06 	bl	3500 <fwp_trap>
    78ec:	90000020 	adrp	x0, b000 <__modti3+0x180>
    78f0:	9118a000 	add	x0, x0, #0x628
    78f4:	97ffef03 	bl	3500 <fwp_trap>
    78f8:	90000020 	adrp	x0, b000 <__modti3+0x180>
    78fc:	911a6000 	add	x0, x0, #0x698
    7900:	97ffef00 	bl	3500 <fwp_trap>
    7904:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7908:	911a2000 	add	x0, x0, #0x688
    790c:	97ffeefd 	bl	3500 <fwp_trap>
    7910:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7914:	91196000 	add	x0, x0, #0x658
    7918:	97ffeefa 	bl	3500 <fwp_trap>
    791c:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7920:	91182000 	add	x0, x0, #0x608
    7924:	97ffeef7 	bl	3500 <fwp_trap>
    7928:	90000020 	adrp	x0, b000 <__modti3+0x180>
    792c:	91156000 	add	x0, x0, #0x558
    7930:	97ffeef4 	bl	3500 <fwp_trap>
    7934:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7938:	911aa000 	add	x0, x0, #0x6a8
    793c:	97ffeef1 	bl	3500 <fwp_trap>
    7940:	97ffebac 	bl	27f0 <__stack_chk_fail@plt>
    7944:	97ffebbf 	bl	2840 <abort@plt>
    7948:	97ffec2e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    794c:	d503201f 	nop

0000000000007950 <fwp_owned_entry12>:
    7950:	f9400000 	ldr	x0, [x0]
    7954:	17fffb8f 	b	6790 <f12>
    7958:	d503201f 	nop
    795c:	d503201f 	nop

0000000000007960 <e12>:
    7960:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7964:	910003fd 	mov	x29, sp
    7968:	f9000bf3 	str	x19, [sp, #16]
    796c:	f9400013 	ldr	x19, [x0]
    7970:	aa1303e0 	mov	x0, x19
    7974:	97fff6ab 	bl	5420 <fwp_rc_share>
    7978:	aa1303e0 	mov	x0, x19
    797c:	97fffb85 	bl	6790 <f12>
    7980:	aa0003f3 	mov	x19, x0
    7984:	97fff6a7 	bl	5420 <fwp_rc_share>
    7988:	aa1303e0 	mov	x0, x19
    798c:	f9400bf3 	ldr	x19, [sp, #16]
    7990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7994:	d65f03c0 	ret
    7998:	d503201f 	nop
    799c:	d503201f 	nop

00000000000079a0 <fwp_args12>:
    79a0:	7100003f 	cmp	w1, #0x0
    79a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    79a8:	54000041 	b.ne	79b0 <fwp_args12+0x10>  // b.any
    79ac:	d65f03c0 	ret
    79b0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    79b4:	91154042 	add	x2, x2, #0x550
    79b8:	f9400001 	ldr	x1, [x0]
    79bc:	f949d843 	ldr	x3, [x2, #5040]
    79c0:	f949ec40 	ldr	x0, [x2, #5080]
    79c4:	cb030021 	sub	x1, x1, x3
    79c8:	eb00403f 	cmp	x1, x0, lsl #16
    79cc:	54ffff02 	b.cs	79ac <fwp_args12+0xc>  // b.hs, b.nlast
    79d0:	d350fc20 	lsr	x0, x1, #16
    79d4:	f949fc44 	ldr	x4, [x2, #5112]
    79d8:	8b000800 	add	x0, x0, x0, lsl #2
    79dc:	d37df002 	lsl	x2, x0, #3
    79e0:	8b020083 	add	x3, x4, x2
    79e4:	f9401060 	ldr	x0, [x3, #32]
    79e8:	b4fffe20 	cbz	x0, 79ac <fwp_args12+0xc>
    79ec:	38626882 	ldrb	w2, [x4, x2]
    79f0:	7100085f 	cmp	w2, #0x2
    79f4:	54000220 	b.eq	7a38 <fwp_args12+0x98>  // b.none
    79f8:	7100045f 	cmp	w2, #0x1
    79fc:	54fffd81 	b.ne	79ac <fwp_args12+0xc>  // b.any
    7a00:	29430864 	ldp	w4, w2, [x3, #24]
    7a04:	92403c21 	and	x1, x1, #0xffff
    7a08:	9b047c21 	mul	x1, x1, x4
    7a0c:	d360fc21 	lsr	x1, x1, #32
    7a10:	eb02003f 	cmp	x1, x2
    7a14:	54fffcc2 	b.cs	79ac <fwp_args12+0xc>  // b.hs, b.nlast
    7a18:	8b010000 	add	x0, x0, x1
    7a1c:	39400001 	ldrb	w1, [x0]
    7a20:	34fffc61 	cbz	w1, 79ac <fwp_args12+0xc>
    7a24:	7103f43f 	cmp	w1, #0xfd
    7a28:	540000e8 	b.hi	7a44 <fwp_args12+0xa4>  // b.pmore
    7a2c:	11000421 	add	w1, w1, #0x1
    7a30:	39000001 	strb	w1, [x0]
    7a34:	d65f03c0 	ret
    7a38:	72003c3f 	tst	w1, #0xffff
    7a3c:	54ffff00 	b.eq	7a1c <fwp_args12+0x7c>  // b.none
    7a40:	d65f03c0 	ret
    7a44:	17fff264 	b	43d4 <fwp_rc_wide_dup>
    7a48:	d503201f 	nop
    7a4c:	d503201f 	nop

0000000000007a50 <fwp_args23>:
    7a50:	7100003f 	cmp	w1, #0x0
    7a54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7a58:	54000041 	b.ne	7a60 <fwp_args23+0x10>  // b.any
    7a5c:	d65f03c0 	ret
    7a60:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7a64:	91154042 	add	x2, x2, #0x550
    7a68:	f9400001 	ldr	x1, [x0]
    7a6c:	f949d843 	ldr	x3, [x2, #5040]
    7a70:	f949ec40 	ldr	x0, [x2, #5080]
    7a74:	cb030021 	sub	x1, x1, x3
    7a78:	eb00403f 	cmp	x1, x0, lsl #16
    7a7c:	54ffff02 	b.cs	7a5c <fwp_args23+0xc>  // b.hs, b.nlast
    7a80:	d350fc20 	lsr	x0, x1, #16
    7a84:	f949fc44 	ldr	x4, [x2, #5112]
    7a88:	8b000800 	add	x0, x0, x0, lsl #2
    7a8c:	d37df002 	lsl	x2, x0, #3
    7a90:	8b020083 	add	x3, x4, x2
    7a94:	f9401060 	ldr	x0, [x3, #32]
    7a98:	b4fffe20 	cbz	x0, 7a5c <fwp_args23+0xc>
    7a9c:	38626882 	ldrb	w2, [x4, x2]
    7aa0:	7100085f 	cmp	w2, #0x2
    7aa4:	54000220 	b.eq	7ae8 <fwp_args23+0x98>  // b.none
    7aa8:	7100045f 	cmp	w2, #0x1
    7aac:	54fffd81 	b.ne	7a5c <fwp_args23+0xc>  // b.any
    7ab0:	29430864 	ldp	w4, w2, [x3, #24]
    7ab4:	92403c21 	and	x1, x1, #0xffff
    7ab8:	9b047c21 	mul	x1, x1, x4
    7abc:	d360fc21 	lsr	x1, x1, #32
    7ac0:	eb02003f 	cmp	x1, x2
    7ac4:	54fffcc2 	b.cs	7a5c <fwp_args23+0xc>  // b.hs, b.nlast
    7ac8:	8b010000 	add	x0, x0, x1
    7acc:	39400001 	ldrb	w1, [x0]
    7ad0:	34fffc61 	cbz	w1, 7a5c <fwp_args23+0xc>
    7ad4:	7103f43f 	cmp	w1, #0xfd
    7ad8:	540000e8 	b.hi	7af4 <fwp_args23+0xa4>  // b.pmore
    7adc:	11000421 	add	w1, w1, #0x1
    7ae0:	39000001 	strb	w1, [x0]
    7ae4:	d65f03c0 	ret
    7ae8:	72003c3f 	tst	w1, #0xffff
    7aec:	54ffff00 	b.eq	7acc <fwp_args23+0x7c>  // b.none
    7af0:	d65f03c0 	ret
    7af4:	17fff238 	b	43d4 <fwp_rc_wide_dup>
    7af8:	d503201f 	nop
    7afc:	d503201f 	nop

0000000000007b00 <fwp_caps12>:
    7b00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7b04:	910003fd 	mov	x29, sp
    7b08:	f9000bf3 	str	x19, [sp, #16]
    7b0c:	aa0003f3 	mov	x19, x0
    7b10:	b9400400 	ldr	w0, [x0, #4]
    7b14:	340004a0 	cbz	w0, 7ba8 <fwp_caps12+0xa8>
    7b18:	f9400660 	ldr	x0, [x19, #8]
    7b1c:	350004e1 	cbnz	w1, 7bb8 <fwp_caps12+0xb8>
    7b20:	97fff700 	bl	5720 <fwp_drop0>
    7b24:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7b28:	91154042 	add	x2, x2, #0x550
    7b2c:	f949d840 	ldr	x0, [x2, #5040]
    7b30:	f949ec41 	ldr	x1, [x2, #5080]
    7b34:	cb000260 	sub	x0, x19, x0
    7b38:	eb01401f 	cmp	x0, x1, lsl #16
    7b3c:	54000382 	b.cs	7bac <fwp_caps12+0xac>  // b.hs, b.nlast
    7b40:	d350fc01 	lsr	x1, x0, #16
    7b44:	f949fc44 	ldr	x4, [x2, #5112]
    7b48:	8b010821 	add	x1, x1, x1, lsl #2
    7b4c:	d37df021 	lsl	x1, x1, #3
    7b50:	8b010083 	add	x3, x4, x1
    7b54:	f9401062 	ldr	x2, [x3, #32]
    7b58:	b40002a2 	cbz	x2, 7bac <fwp_caps12+0xac>
    7b5c:	38616881 	ldrb	w1, [x4, x1]
    7b60:	7100083f 	cmp	w1, #0x2
    7b64:	540006c0 	b.eq	7c3c <fwp_caps12+0x13c>  // b.none
    7b68:	7100043f 	cmp	w1, #0x1
    7b6c:	54000201 	b.ne	7bac <fwp_caps12+0xac>  // b.any
    7b70:	29430464 	ldp	w4, w1, [x3, #24]
    7b74:	92403c00 	and	x0, x0, #0xffff
    7b78:	9b047c00 	mul	x0, x0, x4
    7b7c:	d360fc00 	lsr	x0, x0, #32
    7b80:	eb01001f 	cmp	x0, x1
    7b84:	54000142 	b.cs	7bac <fwp_caps12+0xac>  // b.hs, b.nlast
    7b88:	8b000042 	add	x2, x2, x0
    7b8c:	39400040 	ldrb	w0, [x2]
    7b90:	7100041f 	cmp	w0, #0x1
    7b94:	540000c1 	b.ne	7bac <fwp_caps12+0xac>  // b.any
    7b98:	aa1303e0 	mov	x0, x19
    7b9c:	f9400bf3 	ldr	x19, [sp, #16]
    7ba0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ba4:	17fff2f3 	b	4770 <fwp_mem_free>
    7ba8:	34fffbe1 	cbz	w1, 7b24 <fwp_caps12+0x24>
    7bac:	f9400bf3 	ldr	x19, [sp, #16]
    7bb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7bb4:	d65f03c0 	ret
    7bb8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7bbc:	91154042 	add	x2, x2, #0x550
    7bc0:	f949d843 	ldr	x3, [x2, #5040]
    7bc4:	f949ec41 	ldr	x1, [x2, #5080]
    7bc8:	cb030000 	sub	x0, x0, x3
    7bcc:	eb01401f 	cmp	x0, x1, lsl #16
    7bd0:	54fffee2 	b.cs	7bac <fwp_caps12+0xac>  // b.hs, b.nlast
    7bd4:	d350fc01 	lsr	x1, x0, #16
    7bd8:	f949fc44 	ldr	x4, [x2, #5112]
    7bdc:	8b010821 	add	x1, x1, x1, lsl #2
    7be0:	d37df021 	lsl	x1, x1, #3
    7be4:	8b010083 	add	x3, x4, x1
    7be8:	f9401062 	ldr	x2, [x3, #32]
    7bec:	b4fffe02 	cbz	x2, 7bac <fwp_caps12+0xac>
    7bf0:	38616881 	ldrb	w1, [x4, x1]
    7bf4:	7100083f 	cmp	w1, #0x2
    7bf8:	54000280 	b.eq	7c48 <fwp_caps12+0x148>  // b.none
    7bfc:	7100043f 	cmp	w1, #0x1
    7c00:	54fffd61 	b.ne	7bac <fwp_caps12+0xac>  // b.any
    7c04:	92403c01 	and	x1, x0, #0xffff
    7c08:	29430064 	ldp	w4, w0, [x3, #24]
    7c0c:	9b047c21 	mul	x1, x1, x4
    7c10:	d360fc21 	lsr	x1, x1, #32
    7c14:	eb00003f 	cmp	x1, x0
    7c18:	54fffca2 	b.cs	7bac <fwp_caps12+0xac>  // b.hs, b.nlast
    7c1c:	8b010042 	add	x2, x2, x1
    7c20:	39400040 	ldrb	w0, [x2]
    7c24:	34fffc40 	cbz	w0, 7bac <fwp_caps12+0xac>
    7c28:	7103f41f 	cmp	w0, #0xfd
    7c2c:	54000148 	b.hi	7c54 <fwp_caps12+0x154>  // b.pmore
    7c30:	11000400 	add	w0, w0, #0x1
    7c34:	39000040 	strb	w0, [x2]
    7c38:	17ffffdd 	b	7bac <fwp_caps12+0xac>
    7c3c:	72003c1f 	tst	w0, #0xffff
    7c40:	54fffb61 	b.ne	7bac <fwp_caps12+0xac>  // b.any
    7c44:	17ffffd2 	b	7b8c <fwp_caps12+0x8c>
    7c48:	72003c1f 	tst	w0, #0xffff
    7c4c:	54fffb01 	b.ne	7bac <fwp_caps12+0xac>  // b.any
    7c50:	17fffff4 	b	7c20 <fwp_caps12+0x120>
    7c54:	f9400bf3 	ldr	x19, [sp, #16]
    7c58:	aa0203e0 	mov	x0, x2
    7c5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7c60:	17fff1dd 	b	43d4 <fwp_rc_wide_dup>

0000000000007c64 <fwp_drop2>:
    7c64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7c68:	910003fd 	mov	x29, sp
    7c6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7c70:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    7c74:	911542d5 	add	x21, x22, #0x550
    7c78:	a90153f3 	stp	x19, x20, [sp, #16]
    7c7c:	aa0003f3 	mov	x19, x0
    7c80:	f949daa1 	ldr	x1, [x21, #5040]
    7c84:	f949eea0 	ldr	x0, [x21, #5080]
    7c88:	cb010261 	sub	x1, x19, x1
    7c8c:	eb00403f 	cmp	x1, x0, lsl #16
    7c90:	54000382 	b.cs	7d00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7c94:	d350fc22 	lsr	x2, x1, #16
    7c98:	f949fea3 	ldr	x3, [x21, #5112]
    7c9c:	8b020842 	add	x2, x2, x2, lsl #2
    7ca0:	d37df042 	lsl	x2, x2, #3
    7ca4:	8b020060 	add	x0, x3, x2
    7ca8:	f9401014 	ldr	x20, [x0, #32]
    7cac:	b40002b4 	cbz	x20, 7d00 <fwp_drop2+0x9c>
    7cb0:	38626862 	ldrb	w2, [x3, x2]
    7cb4:	7100085f 	cmp	w2, #0x2
    7cb8:	540002c0 	b.eq	7d10 <fwp_drop2+0xac>  // b.none
    7cbc:	7100045f 	cmp	w2, #0x1
    7cc0:	54000201 	b.ne	7d00 <fwp_drop2+0x9c>  // b.any
    7cc4:	29430002 	ldp	w2, w0, [x0, #24]
    7cc8:	92403c21 	and	x1, x1, #0xffff
    7ccc:	9b027c21 	mul	x1, x1, x2
    7cd0:	d360fc21 	lsr	x1, x1, #32
    7cd4:	eb00003f 	cmp	x1, x0
    7cd8:	54000142 	b.cs	7d00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7cdc:	8b010294 	add	x20, x20, x1
    7ce0:	39400280 	ldrb	w0, [x20]
    7ce4:	340000e0 	cbz	w0, 7d00 <fwp_drop2+0x9c>
    7ce8:	7100041f 	cmp	w0, #0x1
    7cec:	540001e0 	b.eq	7d28 <fwp_drop2+0xc4>  // b.none
    7cf0:	7103fc1f 	cmp	w0, #0xff
    7cf4:	540007e0 	b.eq	7df0 <fwp_drop2+0x18c>  // b.none
    7cf8:	51000400 	sub	w0, w0, #0x1
    7cfc:	39000280 	strb	w0, [x20]
    7d00:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7d0c:	d65f03c0 	ret
    7d10:	72003c3f 	tst	w1, #0xffff
    7d14:	54fffe60 	b.eq	7ce0 <fwp_drop2+0x7c>  // b.none
    7d18:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d1c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7d24:	d65f03c0 	ret
    7d28:	911542c2 	add	x2, x22, #0x550
    7d2c:	f9400660 	ldr	x0, [x19, #8]
    7d30:	f949d841 	ldr	x1, [x2, #5040]
    7d34:	f949ec42 	ldr	x2, [x2, #5080]
    7d38:	cb010001 	sub	x1, x0, x1
    7d3c:	eb02403f 	cmp	x1, x2, lsl #16
    7d40:	54000382 	b.cs	7db0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7d44:	d350fc22 	lsr	x2, x1, #16
    7d48:	8b020842 	add	x2, x2, x2, lsl #2
    7d4c:	d37df042 	lsl	x2, x2, #3
    7d50:	8b020064 	add	x4, x3, x2
    7d54:	f9401094 	ldr	x20, [x4, #32]
    7d58:	b40002d4 	cbz	x20, 7db0 <fwp_drop2+0x14c>
    7d5c:	38626862 	ldrb	w2, [x3, x2]
    7d60:	7100085f 	cmp	w2, #0x2
    7d64:	54000400 	b.eq	7de4 <fwp_drop2+0x180>  // b.none
    7d68:	7100045f 	cmp	w2, #0x1
    7d6c:	54000221 	b.ne	7db0 <fwp_drop2+0x14c>  // b.any
    7d70:	29430883 	ldp	w3, w2, [x4, #24]
    7d74:	92403c21 	and	x1, x1, #0xffff
    7d78:	9b037c21 	mul	x1, x1, x3
    7d7c:	d360fc21 	lsr	x1, x1, #32
    7d80:	eb02003f 	cmp	x1, x2
    7d84:	54000162 	b.cs	7db0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7d88:	8b010294 	add	x20, x20, x1
    7d8c:	39400281 	ldrb	w1, [x20]
    7d90:	34000101 	cbz	w1, 7db0 <fwp_drop2+0x14c>
    7d94:	7100043f 	cmp	w1, #0x1
    7d98:	54000220 	b.eq	7ddc <fwp_drop2+0x178>  // b.none
    7d9c:	7103fc3f 	cmp	w1, #0xff
    7da0:	540005a0 	b.eq	7e54 <fwp_drop2+0x1f0>  // b.none
    7da4:	51000421 	sub	w1, w1, #0x1
    7da8:	39000281 	strb	w1, [x20]
    7dac:	d503201f 	nop
    7db0:	f9400a74 	ldr	x20, [x19, #16]
    7db4:	aa1303e0 	mov	x0, x19
    7db8:	97fff5bf 	bl	54b4 <fwp_rc_free_arr>
    7dbc:	911542c0 	add	x0, x22, #0x550
    7dc0:	f949d801 	ldr	x1, [x0, #5040]
    7dc4:	f949ec00 	ldr	x0, [x0, #5080]
    7dc8:	cb010281 	sub	x1, x20, x1
    7dcc:	eb00403f 	cmp	x1, x0, lsl #16
    7dd0:	54fff982 	b.cs	7d00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7dd4:	aa1403f3 	mov	x19, x20
    7dd8:	17ffffaf 	b	7c94 <fwp_drop2+0x30>
    7ddc:	97fff5b6 	bl	54b4 <fwp_rc_free_arr>
    7de0:	17fffff4 	b	7db0 <fwp_drop2+0x14c>
    7de4:	72003c3f 	tst	w1, #0xffff
    7de8:	54fffe41 	b.ne	7db0 <fwp_drop2+0x14c>  // b.any
    7dec:	17ffffe8 	b	7d8c <fwp_drop2+0x128>
    7df0:	ca544681 	eor	x1, x20, x20, lsr #17
    7df4:	911542c0 	add	x0, x22, #0x550
    7df8:	ca412421 	eor	x1, x1, x1, lsr #9
    7dfc:	8b210c01 	add	x1, x0, w1, uxtb #3
    7e00:	f94a2420 	ldr	x0, [x1, #5192]
    7e04:	b5000080 	cbnz	x0, 7e14 <fwp_drop2+0x1b0>
    7e08:	14000010 	b	7e48 <fwp_drop2+0x1e4>
    7e0c:	f9400800 	ldr	x0, [x0, #16]
    7e10:	b40001c0 	cbz	x0, 7e48 <fwp_drop2+0x1e4>
    7e14:	f9400001 	ldr	x1, [x0]
    7e18:	eb14003f 	cmp	x1, x20
    7e1c:	54ffff81 	b.ne	7e0c <fwp_drop2+0x1a8>  // b.any
    7e20:	f9400401 	ldr	x1, [x0, #8]
    7e24:	d1000421 	sub	x1, x1, #0x1
    7e28:	f9000401 	str	x1, [x0, #8]
    7e2c:	f103f83f 	cmp	x1, #0xfe
    7e30:	54fff681 	b.ne	7d00 <fwp_drop2+0x9c>  // b.any
    7e34:	aa1403e0 	mov	x0, x20
    7e38:	97fff1ae 	bl	44f0 <fwp_rc_forget_slot>
    7e3c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7e40:	39000280 	strb	w0, [x20]
    7e44:	17ffffaf 	b	7d00 <fwp_drop2+0x9c>
    7e48:	90000020 	adrp	x0, b000 <__modti3+0x180>
    7e4c:	91132000 	add	x0, x0, #0x4c8
    7e50:	97ffedac 	bl	3500 <fwp_trap>
    7e54:	ca544680 	eor	x0, x20, x20, lsr #17
    7e58:	911542c1 	add	x1, x22, #0x550
    7e5c:	ca402400 	eor	x0, x0, x0, lsr #9
    7e60:	8b200c20 	add	x0, x1, w0, uxtb #3
    7e64:	f94a2400 	ldr	x0, [x0, #5192]
    7e68:	b5000080 	cbnz	x0, 7e78 <fwp_drop2+0x214>
    7e6c:	17fffff7 	b	7e48 <fwp_drop2+0x1e4>
    7e70:	f9400800 	ldr	x0, [x0, #16]
    7e74:	b4fffea0 	cbz	x0, 7e48 <fwp_drop2+0x1e4>
    7e78:	f9400001 	ldr	x1, [x0]
    7e7c:	eb14003f 	cmp	x1, x20
    7e80:	54ffff81 	b.ne	7e70 <fwp_drop2+0x20c>  // b.any
    7e84:	f9400401 	ldr	x1, [x0, #8]
    7e88:	d1000421 	sub	x1, x1, #0x1
    7e8c:	f9000401 	str	x1, [x0, #8]
    7e90:	f103f83f 	cmp	x1, #0xfe
    7e94:	54fff8e1 	b.ne	7db0 <fwp_drop2+0x14c>  // b.any
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	97fff195 	bl	44f0 <fwp_rc_forget_slot>
    7ea0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7ea4:	39000280 	strb	w0, [x20]
    7ea8:	17ffffc2 	b	7db0 <fwp_drop2+0x14c>
    7eac:	d503201f 	nop

0000000000007eb0 <fwp_arg_drop23>:
    7eb0:	7100003f 	cmp	w1, #0x0
    7eb4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7eb8:	54000041 	b.ne	7ec0 <fwp_arg_drop23+0x10>  // b.any
    7ebc:	d65f03c0 	ret
    7ec0:	f9400000 	ldr	x0, [x0]
    7ec4:	17ffff68 	b	7c64 <fwp_drop2>
    7ec8:	d503201f 	nop
    7ecc:	d503201f 	nop

0000000000007ed0 <fwp_caps23>:
    7ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7ed4:	910003fd 	mov	x29, sp
    7ed8:	f9000bf3 	str	x19, [sp, #16]
    7edc:	aa0003f3 	mov	x19, x0
    7ee0:	b9400400 	ldr	w0, [x0, #4]
    7ee4:	340004a0 	cbz	w0, 7f78 <fwp_caps23+0xa8>
    7ee8:	f9400660 	ldr	x0, [x19, #8]
    7eec:	350004e1 	cbnz	w1, 7f88 <fwp_caps23+0xb8>
    7ef0:	97ffff5d 	bl	7c64 <fwp_drop2>
    7ef4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7ef8:	91154042 	add	x2, x2, #0x550
    7efc:	f949d840 	ldr	x0, [x2, #5040]
    7f00:	f949ec41 	ldr	x1, [x2, #5080]
    7f04:	cb000260 	sub	x0, x19, x0
    7f08:	eb01401f 	cmp	x0, x1, lsl #16
    7f0c:	54000382 	b.cs	7f7c <fwp_caps23+0xac>  // b.hs, b.nlast
    7f10:	d350fc01 	lsr	x1, x0, #16
    7f14:	f949fc44 	ldr	x4, [x2, #5112]
    7f18:	8b010821 	add	x1, x1, x1, lsl #2
    7f1c:	d37df021 	lsl	x1, x1, #3
    7f20:	8b010083 	add	x3, x4, x1
    7f24:	f9401062 	ldr	x2, [x3, #32]
    7f28:	b40002a2 	cbz	x2, 7f7c <fwp_caps23+0xac>
    7f2c:	38616881 	ldrb	w1, [x4, x1]
    7f30:	7100083f 	cmp	w1, #0x2
    7f34:	540006c0 	b.eq	800c <fwp_caps23+0x13c>  // b.none
    7f38:	7100043f 	cmp	w1, #0x1
    7f3c:	54000201 	b.ne	7f7c <fwp_caps23+0xac>  // b.any
    7f40:	29430464 	ldp	w4, w1, [x3, #24]
    7f44:	92403c00 	and	x0, x0, #0xffff
    7f48:	9b047c00 	mul	x0, x0, x4
    7f4c:	d360fc00 	lsr	x0, x0, #32
    7f50:	eb01001f 	cmp	x0, x1
    7f54:	54000142 	b.cs	7f7c <fwp_caps23+0xac>  // b.hs, b.nlast
    7f58:	8b000042 	add	x2, x2, x0
    7f5c:	39400040 	ldrb	w0, [x2]
    7f60:	7100041f 	cmp	w0, #0x1
    7f64:	540000c1 	b.ne	7f7c <fwp_caps23+0xac>  // b.any
    7f68:	aa1303e0 	mov	x0, x19
    7f6c:	f9400bf3 	ldr	x19, [sp, #16]
    7f70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7f74:	17fff1ff 	b	4770 <fwp_mem_free>
    7f78:	34fffbe1 	cbz	w1, 7ef4 <fwp_caps23+0x24>
    7f7c:	f9400bf3 	ldr	x19, [sp, #16]
    7f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7f84:	d65f03c0 	ret
    7f88:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7f8c:	91154042 	add	x2, x2, #0x550
    7f90:	f949d843 	ldr	x3, [x2, #5040]
    7f94:	f949ec41 	ldr	x1, [x2, #5080]
    7f98:	cb030000 	sub	x0, x0, x3
    7f9c:	eb01401f 	cmp	x0, x1, lsl #16
    7fa0:	54fffee2 	b.cs	7f7c <fwp_caps23+0xac>  // b.hs, b.nlast
    7fa4:	d350fc01 	lsr	x1, x0, #16
    7fa8:	f949fc44 	ldr	x4, [x2, #5112]
    7fac:	8b010821 	add	x1, x1, x1, lsl #2
    7fb0:	d37df021 	lsl	x1, x1, #3
    7fb4:	8b010083 	add	x3, x4, x1
    7fb8:	f9401062 	ldr	x2, [x3, #32]
    7fbc:	b4fffe02 	cbz	x2, 7f7c <fwp_caps23+0xac>
    7fc0:	38616881 	ldrb	w1, [x4, x1]
    7fc4:	7100083f 	cmp	w1, #0x2
    7fc8:	54000280 	b.eq	8018 <fwp_caps23+0x148>  // b.none
    7fcc:	7100043f 	cmp	w1, #0x1
    7fd0:	54fffd61 	b.ne	7f7c <fwp_caps23+0xac>  // b.any
    7fd4:	92403c01 	and	x1, x0, #0xffff
    7fd8:	29430064 	ldp	w4, w0, [x3, #24]
    7fdc:	9b047c21 	mul	x1, x1, x4
    7fe0:	d360fc21 	lsr	x1, x1, #32
    7fe4:	eb00003f 	cmp	x1, x0
    7fe8:	54fffca2 	b.cs	7f7c <fwp_caps23+0xac>  // b.hs, b.nlast
    7fec:	8b010042 	add	x2, x2, x1
    7ff0:	39400040 	ldrb	w0, [x2]
    7ff4:	34fffc40 	cbz	w0, 7f7c <fwp_caps23+0xac>
    7ff8:	7103f41f 	cmp	w0, #0xfd
    7ffc:	54000148 	b.hi	8024 <fwp_caps23+0x154>  // b.pmore
    8000:	11000400 	add	w0, w0, #0x1
    8004:	39000040 	strb	w0, [x2]
    8008:	17ffffdd 	b	7f7c <fwp_caps23+0xac>
    800c:	72003c1f 	tst	w0, #0xffff
    8010:	54fffb61 	b.ne	7f7c <fwp_caps23+0xac>  // b.any
    8014:	17ffffd2 	b	7f5c <fwp_caps23+0x8c>
    8018:	72003c1f 	tst	w0, #0xffff
    801c:	54fffb01 	b.ne	7f7c <fwp_caps23+0xac>  // b.any
    8020:	17fffff4 	b	7ff0 <fwp_caps23+0x120>
    8024:	f9400bf3 	ldr	x19, [sp, #16]
    8028:	aa0203e0 	mov	x0, x2
    802c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8030:	17fff0e9 	b	43d4 <fwp_rc_wide_dup>

0000000000008034 <f23>:
    8034:	d10203ff 	sub	sp, sp, #0x80
    8038:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    803c:	f947f421 	ldr	x1, [x1, #4072]
    8040:	a9027bfd 	stp	x29, x30, [sp, #32]
    8044:	910083fd 	add	x29, sp, #0x20
    8048:	a9045bf5 	stp	x21, x22, [sp, #64]
    804c:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    8050:	911542c3 	add	x3, x22, #0x550
    8054:	a90353f3 	stp	x19, x20, [sp, #48]
    8058:	a90563f7 	stp	x23, x24, [sp, #80]
    805c:	aa0003f8 	mov	x24, x0
    8060:	a9066bf9 	stp	x25, x26, [sp, #96]
    8064:	f949ec62 	ldr	x2, [x3, #5080]
    8068:	f9400024 	ldr	x4, [x1]
    806c:	f9000fe4 	str	x4, [sp, #24]
    8070:	d2800004 	mov	x4, #0x0                   	// #0
    8074:	f949d861 	ldr	x1, [x3, #5040]
    8078:	d370bc42 	lsl	x2, x2, #16
    807c:	b40017c0 	cbz	x0, 8374 <f23+0x340>
    8080:	f9400819 	ldr	x25, [x0, #16]
    8084:	cb010321 	sub	x1, x25, x1
    8088:	eb02003f 	cmp	x1, x2
    808c:	54000362 	b.cs	80f8 <f23+0xc4>  // b.hs, b.nlast
    8090:	f949fc60 	ldr	x0, [x3, #5112]
    8094:	d350fc22 	lsr	x2, x1, #16
    8098:	8b020842 	add	x2, x2, x2, lsl #2
    809c:	8b020c02 	add	x2, x0, x2, lsl #3
    80a0:	f9401040 	ldr	x0, [x2, #32]
    80a4:	b40002a0 	cbz	x0, 80f8 <f23+0xc4>
    80a8:	39400043 	ldrb	w3, [x2]
    80ac:	7100087f 	cmp	w3, #0x2
    80b0:	540015c0 	b.eq	8368 <f23+0x334>  // b.none
    80b4:	7100047f 	cmp	w3, #0x1
    80b8:	540001c1 	b.ne	80f0 <f23+0xbc>  // b.any
    80bc:	29430843 	ldp	w3, w2, [x2, #24]
    80c0:	92403c21 	and	x1, x1, #0xffff
    80c4:	9b037c21 	mul	x1, x1, x3
    80c8:	d360fc21 	lsr	x1, x1, #32
    80cc:	eb02003f 	cmp	x1, x2
    80d0:	54000102 	b.cs	80f0 <f23+0xbc>  // b.hs, b.nlast
    80d4:	8b010000 	add	x0, x0, x1
    80d8:	39400001 	ldrb	w1, [x0]
    80dc:	340000a1 	cbz	w1, 80f0 <f23+0xbc>
    80e0:	7103f43f 	cmp	w1, #0xfd
    80e4:	54001868 	b.hi	83f0 <f23+0x3bc>  // b.pmore
    80e8:	11000421 	add	w1, w1, #0x1
    80ec:	39000001 	strb	w1, [x0]
    80f0:	d2800000 	mov	x0, #0x0                   	// #0
    80f4:	b40000d8 	cbz	x24, 810c <f23+0xd8>
    80f8:	aa1803e1 	mov	x1, x24
    80fc:	d2800000 	mov	x0, #0x0                   	// #0
    8100:	f9400821 	ldr	x1, [x1, #16]
    8104:	91000400 	add	x0, x0, #0x1
    8108:	b5ffffc1 	cbnz	x1, 8100 <f23+0xcc>
    810c:	b40013b9 	cbz	x25, 8380 <f23+0x34c>
    8110:	aa1903e1 	mov	x1, x25
    8114:	d2800002 	mov	x2, #0x0                   	// #0
    8118:	f9400821 	ldr	x1, [x1, #16]
    811c:	91000442 	add	x2, x2, #0x1
    8120:	b5ffffc1 	cbnz	x1, 8118 <f23+0xe4>
    8124:	eb00005f 	cmp	x2, x0
    8128:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    812c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    8130:	eb01035f 	cmp	x26, x1
    8134:	54001668 	b.hi	8400 <f23+0x3cc>  // b.pmore
    8138:	d37ffb53 	lsl	x19, x26, #1
    813c:	52800041 	mov	w1, #0x2                   	// #2
    8140:	91000660 	add	x0, x19, #0x1
    8144:	d37df000 	lsl	x0, x0, #3
    8148:	97fff2aa 	bl	4bf0 <fwp_heap_alloc>
    814c:	aa0003f7 	mov	x23, x0
    8150:	911542c1 	add	x1, x22, #0x550
    8154:	aa0103e0 	mov	x0, x1
    8158:	f90002f3 	str	x19, [x23]
    815c:	f949d821 	ldr	x1, [x1, #5040]
    8160:	f949ec00 	ldr	x0, [x0, #5080]
    8164:	cb0102e1 	sub	x1, x23, x1
    8168:	eb00403f 	cmp	x1, x0, lsl #16
    816c:	54000342 	b.cs	81d4 <f23+0x1a0>  // b.hs, b.nlast
    8170:	911542c2 	add	x2, x22, #0x550
    8174:	d350fc20 	lsr	x0, x1, #16
    8178:	8b000800 	add	x0, x0, x0, lsl #2
    817c:	f949fc43 	ldr	x3, [x2, #5112]
    8180:	d37df002 	lsl	x2, x0, #3
    8184:	8b020060 	add	x0, x3, x2
    8188:	f9401013 	ldr	x19, [x0, #32]
    818c:	b4000253 	cbz	x19, 81d4 <f23+0x1a0>
    8190:	38626862 	ldrb	w2, [x3, x2]
    8194:	7100085f 	cmp	w2, #0x2
    8198:	54000e20 	b.eq	835c <f23+0x328>  // b.none
    819c:	7100045f 	cmp	w2, #0x1
    81a0:	540001a1 	b.ne	81d4 <f23+0x1a0>  // b.any
    81a4:	29430002 	ldp	w2, w0, [x0, #24]
    81a8:	92403c21 	and	x1, x1, #0xffff
    81ac:	9b027c21 	mul	x1, x1, x2
    81b0:	d360fc21 	lsr	x1, x1, #32
    81b4:	eb00003f 	cmp	x1, x0
    81b8:	540000e2 	b.cs	81d4 <f23+0x1a0>  // b.hs, b.nlast
    81bc:	8b010273 	add	x19, x19, x1
    81c0:	39400260 	ldrb	w0, [x19]
    81c4:	7103fc1f 	cmp	w0, #0xff
    81c8:	54000f80 	b.eq	83b8 <f23+0x384>  // b.none
    81cc:	52800020 	mov	w0, #0x1                   	// #1
    81d0:	39000260 	strb	w0, [x19]
    81d4:	b400025a 	cbz	x26, 821c <f23+0x1e8>
    81d8:	8b1a12fa 	add	x26, x23, x26, lsl #4
    81dc:	aa1703f3 	mov	x19, x23
    81e0:	aa1803f5 	mov	x21, x24
    81e4:	aa1903f4 	mov	x20, x25
    81e8:	f9400683 	ldr	x3, [x20, #8]
    81ec:	f94006a2 	ldr	x2, [x21, #8]
    81f0:	f9400861 	ldr	x1, [x3, #16]
    81f4:	f9400840 	ldr	x0, [x2, #16]
    81f8:	fd400461 	ldr	d1, [x3, #8]
    81fc:	fd400440 	ldr	d0, [x2, #8]
    8200:	97fff3fc 	bl	51f0 <w107>
    8204:	f9000660 	str	x0, [x19, #8]
    8208:	f8010e61 	str	x1, [x19, #16]!
    820c:	f9400a94 	ldr	x20, [x20, #16]
    8210:	f9400ab5 	ldr	x21, [x21, #16]
    8214:	eb13035f 	cmp	x26, x19
    8218:	54fffe81 	b.ne	81e8 <f23+0x1b4>  // b.any
    821c:	aa1903e0 	mov	x0, x25
    8220:	97fffe91 	bl	7c64 <fwp_drop2>
    8224:	aa1803e0 	mov	x0, x24
    8228:	97fffe8f 	bl	7c64 <fwp_drop2>
    822c:	f94002f5 	ldr	x21, [x23]
    8230:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8234:	b4000275 	cbz	x21, 8280 <f23+0x24c>
    8238:	fd003be8 	str	d8, [sp, #112]
    823c:	2f00e408 	movi	d8, #0x0
    8240:	910022f9 	add	x25, x23, #0x8
    8244:	910042f8 	add	x24, x23, #0x10
    8248:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    824c:	d2800013 	mov	x19, #0x0                   	// #0
    8250:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8254:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8258:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    825c:	aa0303e1 	mov	x1, x3
    8260:	1e602908 	fadd	d8, d8, d0
    8264:	91000a73 	add	x19, x19, #0x2
    8268:	97fff32f 	bl	4f24 <fwp_p_ad_push>
    826c:	aa0003f4 	mov	x20, x0
    8270:	eb1302bf 	cmp	x21, x19
    8274:	54fffee8 	b.hi	8250 <f23+0x21c>  // b.pmore
    8278:	9e660115 	fmov	x21, d8
    827c:	fd403be8 	ldr	d8, [sp, #112]
    8280:	911542d6 	add	x22, x22, #0x550
    8284:	aa1703e0 	mov	x0, x23
    8288:	97fff8a2 	bl	6510 <fwp_drop4>
    828c:	a900d3f5 	stp	x21, x20, [sp, #8]
    8290:	910023e1 	add	x1, sp, #0x8
    8294:	52800000 	mov	w0, #0x0                   	// #0
    8298:	97fff41a 	bl	5300 <fwp_data.part.0.constprop.0>
    829c:	f949dac1 	ldr	x1, [x22, #5040]
    82a0:	aa0003f3 	mov	x19, x0
    82a4:	f949eec0 	ldr	x0, [x22, #5080]
    82a8:	cb010261 	sub	x1, x19, x1
    82ac:	eb00403f 	cmp	x1, x0, lsl #16
    82b0:	54000322 	b.cs	8314 <f23+0x2e0>  // b.hs, b.nlast
    82b4:	d350fc22 	lsr	x2, x1, #16
    82b8:	f949fec3 	ldr	x3, [x22, #5112]
    82bc:	8b020842 	add	x2, x2, x2, lsl #2
    82c0:	d37df042 	lsl	x2, x2, #3
    82c4:	8b020060 	add	x0, x3, x2
    82c8:	f9401014 	ldr	x20, [x0, #32]
    82cc:	b4000254 	cbz	x20, 8314 <f23+0x2e0>
    82d0:	38626862 	ldrb	w2, [x3, x2]
    82d4:	7100085f 	cmp	w2, #0x2
    82d8:	540003c0 	b.eq	8350 <f23+0x31c>  // b.none
    82dc:	7100045f 	cmp	w2, #0x1
    82e0:	540001a1 	b.ne	8314 <f23+0x2e0>  // b.any
    82e4:	29430002 	ldp	w2, w0, [x0, #24]
    82e8:	92403c21 	and	x1, x1, #0xffff
    82ec:	9b027c21 	mul	x1, x1, x2
    82f0:	d360fc21 	lsr	x1, x1, #32
    82f4:	eb00003f 	cmp	x1, x0
    82f8:	540000e2 	b.cs	8314 <f23+0x2e0>  // b.hs, b.nlast
    82fc:	8b010294 	add	x20, x20, x1
    8300:	39400280 	ldrb	w0, [x20]
    8304:	7103fc1f 	cmp	w0, #0xff
    8308:	540005e0 	b.eq	83c4 <f23+0x390>  // b.none
    830c:	52800020 	mov	w0, #0x1                   	// #1
    8310:	39000280 	strb	w0, [x20]
    8314:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8318:	f947f400 	ldr	x0, [x0, #4072]
    831c:	f9400fe2 	ldr	x2, [sp, #24]
    8320:	f9400001 	ldr	x1, [x0]
    8324:	eb010042 	subs	x2, x2, x1
    8328:	d2800001 	mov	x1, #0x0                   	// #0
    832c:	54000721 	b.ne	8410 <f23+0x3dc>  // b.any
    8330:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8334:	aa1303e0 	mov	x0, x19
    8338:	a94353f3 	ldp	x19, x20, [sp, #48]
    833c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8340:	a94563f7 	ldp	x23, x24, [sp, #80]
    8344:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8348:	910203ff 	add	sp, sp, #0x80
    834c:	d65f03c0 	ret
    8350:	72003c3f 	tst	w1, #0xffff
    8354:	54fffe01 	b.ne	8314 <f23+0x2e0>  // b.any
    8358:	17ffffea 	b	8300 <f23+0x2cc>
    835c:	72003c3f 	tst	w1, #0xffff
    8360:	54fff3a1 	b.ne	81d4 <f23+0x1a0>  // b.any
    8364:	17ffff97 	b	81c0 <f23+0x18c>
    8368:	72003c3f 	tst	w1, #0xffff
    836c:	54ffec21 	b.ne	80f0 <f23+0xbc>  // b.any
    8370:	17ffff5a 	b	80d8 <f23+0xa4>
    8374:	cb0103e1 	neg	x1, x1
    8378:	eb02003f 	cmp	x1, x2
    837c:	540002a3 	b.cc	83d0 <f23+0x39c>  // b.lo, b.ul, b.last
    8380:	52800041 	mov	w1, #0x2                   	// #2
    8384:	d2800100 	mov	x0, #0x8                   	// #8
    8388:	97fff21a 	bl	4bf0 <fwp_heap_alloc>
    838c:	aa0003f7 	mov	x23, x0
    8390:	911542c0 	add	x0, x22, #0x550
    8394:	f90002ff 	str	xzr, [x23]
    8398:	f949d801 	ldr	x1, [x0, #5040]
    839c:	f949ec00 	ldr	x0, [x0, #5080]
    83a0:	cb0102e1 	sub	x1, x23, x1
    83a4:	eb00403f 	cmp	x1, x0, lsl #16
    83a8:	54000282 	b.cs	83f8 <f23+0x3c4>  // b.hs, b.nlast
    83ac:	d280001a 	mov	x26, #0x0                   	// #0
    83b0:	d2800019 	mov	x25, #0x0                   	// #0
    83b4:	17ffff6f 	b	8170 <f23+0x13c>
    83b8:	aa1303e0 	mov	x0, x19
    83bc:	97fff04d 	bl	44f0 <fwp_rc_forget_slot>
    83c0:	17ffff83 	b	81cc <f23+0x198>
    83c4:	aa1403e0 	mov	x0, x20
    83c8:	97fff04a 	bl	44f0 <fwp_rc_forget_slot>
    83cc:	17ffffd0 	b	830c <f23+0x2d8>
    83d0:	f949fc62 	ldr	x2, [x3, #5112]
    83d4:	d350fc20 	lsr	x0, x1, #16
    83d8:	8b000800 	add	x0, x0, x0, lsl #2
    83dc:	8b000c42 	add	x2, x2, x0, lsl #3
    83e0:	f9401040 	ldr	x0, [x2, #32]
    83e4:	b4fffce0 	cbz	x0, 8380 <f23+0x34c>
    83e8:	d2800019 	mov	x25, #0x0                   	// #0
    83ec:	17ffff2f 	b	80a8 <f23+0x74>
    83f0:	97ffeff9 	bl	43d4 <fwp_rc_wide_dup>
    83f4:	17ffff3f 	b	80f0 <f23+0xbc>
    83f8:	d2800019 	mov	x25, #0x0                   	// #0
    83fc:	17ffff88 	b	821c <f23+0x1e8>
    8400:	f0000000 	adrp	x0, b000 <__modti3+0x180>
    8404:	911a2000 	add	x0, x0, #0x688
    8408:	fd003be8 	str	d8, [sp, #112]
    840c:	97ffec3d 	bl	3500 <fwp_trap>
    8410:	fd003be8 	str	d8, [sp, #112]
    8414:	97ffe8f7 	bl	27f0 <__stack_chk_fail@plt>
    8418:	d503201f 	nop
    841c:	d503201f 	nop

0000000000008420 <fwp_owned_entry23>:
    8420:	f9400000 	ldr	x0, [x0]
    8424:	17ffff04 	b	8034 <f23>
    8428:	d503201f 	nop
    842c:	d503201f 	nop

0000000000008430 <e23>:
    8430:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8434:	910003fd 	mov	x29, sp
    8438:	f9000bf3 	str	x19, [sp, #16]
    843c:	f9400013 	ldr	x19, [x0]
    8440:	aa1303e0 	mov	x0, x19
    8444:	97fff3f7 	bl	5420 <fwp_rc_share>
    8448:	aa1303e0 	mov	x0, x19
    844c:	97fffefa 	bl	8034 <f23>
    8450:	aa0003f3 	mov	x19, x0
    8454:	97fff3f3 	bl	5420 <fwp_rc_share>
    8458:	aa1303e0 	mov	x0, x19
    845c:	f9400bf3 	ldr	x19, [sp, #16]
    8460:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8464:	d65f03c0 	ret
    8468:	d503201f 	nop
    846c:	d503201f 	nop

0000000000008470 <fwp_write>:
    8470:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8474:	910003fd 	mov	x29, sp
    8478:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    847c:	f947f484 	ldr	x4, [x4, #4072]
    8480:	a90153f3 	stp	x19, x20, [sp, #16]
    8484:	d10943ff 	sub	sp, sp, #0x250
    8488:	b9400045 	ldr	w5, [x2]
    848c:	aa0003f4 	mov	x20, x0
    8490:	f9400080 	ldr	x0, [x4]
    8494:	f90127e0 	str	x0, [sp, #584]
    8498:	d2800000 	mov	x0, #0x0                   	// #0
    849c:	710064bf 	cmp	w5, #0x19
    84a0:	54000408 	b.hi	8520 <fwp_write+0xb0>  // b.pmore
    84a4:	f0000000 	adrp	x0, b000 <__modti3+0x180>
    84a8:	aa0103f3 	mov	x19, x1
    84ac:	91394000 	add	x0, x0, #0xe50
    84b0:	f9013bf5 	str	x21, [sp, #624]
    84b4:	f9013ff6 	str	x22, [sp, #632]
    84b8:	f90153fb 	str	x27, [sp, #672]
    84bc:	f90157fc 	str	x28, [sp, #680]
    84c0:	aa0203fc 	mov	x28, x2
    84c4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    84c8:	10000061 	adr	x1, 84d4 <fwp_write+0x64>
    84cc:	8b20a820 	add	x0, x1, w0, sxth #2
    84d0:	d61f0000 	br	x0
    84d4:	910123e0 	add	x0, sp, #0x48
    84d8:	aa1303e5 	mov	x5, x19
    84dc:	f0000004 	adrp	x4, b000 <__modti3+0x180>
    84e0:	aa0003f3 	mov	x19, x0
    84e4:	911c2084 	add	x4, x4, #0x708
    84e8:	d2804003 	mov	x3, #0x200                 	// #512
    84ec:	aa0303e1 	mov	x1, x3
    84f0:	52800042 	mov	w2, #0x2                   	// #2
    84f4:	97ffe89b 	bl	2760 <__snprintf_chk@plt>
    84f8:	aa1303e0 	mov	x0, x19
    84fc:	97ffe861 	bl	2680 <strlen@plt>
    8500:	aa1303e1 	mov	x1, x19
    8504:	aa0003e2 	mov	x2, x0
    8508:	aa1403e0 	mov	x0, x20
    850c:	97ffeba1 	bl	3390 <buf_put>
    8510:	f9413bf5 	ldr	x21, [sp, #624]
    8514:	f9413ff6 	ldr	x22, [sp, #632]
    8518:	f94153fb 	ldr	x27, [sp, #672]
    851c:	f94157fc 	ldr	x28, [sp, #680]
    8520:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8524:	f947f400 	ldr	x0, [x0, #4072]
    8528:	f94127e2 	ldr	x2, [sp, #584]
    852c:	f9400001 	ldr	x1, [x0]
    8530:	eb010042 	subs	x2, x2, x1
    8534:	d2800001 	mov	x1, #0x0                   	// #0
    8538:	540077c1 	b.ne	9430 <fwp_write+0xfc0>  // b.any
    853c:	910943ff 	add	sp, sp, #0x250
    8540:	a94153f3 	ldp	x19, x20, [sp, #16]
    8544:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8548:	d65f03c0 	ret
    854c:	910123e0 	add	x0, sp, #0x48
    8550:	aa1303e5 	mov	x5, x19
    8554:	f0000004 	adrp	x4, b000 <__modti3+0x180>
    8558:	aa0003f3 	mov	x19, x0
    855c:	911c0084 	add	x4, x4, #0x700
    8560:	d2804003 	mov	x3, #0x200                 	// #512
    8564:	17ffffe2 	b	84ec <fwp_write+0x7c>
    8568:	71004cbf 	cmp	w5, #0x13
    856c:	f0000000 	adrp	x0, b000 <__modti3+0x180>
    8570:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8574:	911bc000 	add	x0, x0, #0x6f0
    8578:	911be021 	add	x1, x1, #0x6f8
    857c:	d2800082 	mov	x2, #0x4                   	// #4
    8580:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8584:	aa1403e0 	mov	x0, x20
    8588:	f90143f7 	str	x23, [sp, #640]
    858c:	d2800016 	mov	x22, #0x0                   	// #0
    8590:	f90147f8 	str	x24, [sp, #648]
    8594:	97ffeb7f 	bl	3390 <buf_put>
    8598:	f9400260 	ldr	x0, [x19]
    859c:	f0000017 	adrp	x23, b000 <__modti3+0x180>
    85a0:	d2800015 	mov	x21, #0x0                   	// #0
    85a4:	911de2f7 	add	x23, x23, #0x778
    85a8:	b40047a0 	cbz	x0, 8e9c <fwp_write+0xa2c>
    85ac:	b9400380 	ldr	w0, [x28]
    85b0:	52800003 	mov	w3, #0x0                   	// #0
    85b4:	f9401f82 	ldr	x2, [x28, #56]
    85b8:	71004c1f 	cmp	w0, #0x13
    85bc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    85c0:	aa1403e0 	mov	x0, x20
    85c4:	8b010e61 	add	x1, x19, x1, lsl #3
    85c8:	f9400421 	ldr	x1, [x1, #8]
    85cc:	97ffffa9 	bl	8470 <fwp_write>
    85d0:	b9400380 	ldr	w0, [x28]
    85d4:	7100481f 	cmp	w0, #0x12
    85d8:	54004b40 	b.eq	8f40 <fwp_write+0xad0>  // b.none
    85dc:	f9400260 	ldr	x0, [x19]
    85e0:	910006b5 	add	x21, x21, #0x1
    85e4:	91000ad6 	add	x22, x22, #0x2
    85e8:	eb15001f 	cmp	x0, x21
    85ec:	54004589 	b.ls	8e9c <fwp_write+0xa2c>  // b.plast
    85f0:	aa1703e1 	mov	x1, x23
    85f4:	aa1403e0 	mov	x0, x20
    85f8:	d2800042 	mov	x2, #0x2                   	// #2
    85fc:	97ffeb65 	bl	3390 <buf_put>
    8600:	17ffffeb 	b	85ac <fwp_write+0x13c>
    8604:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8608:	911cc021 	add	x1, x1, #0x730
    860c:	d28000c2 	mov	x2, #0x6                   	// #6
    8610:	aa1403e0 	mov	x0, x20
    8614:	91004273 	add	x19, x19, #0x10
    8618:	97ffeb5e 	bl	3390 <buf_put>
    861c:	aa1303e0 	mov	x0, x19
    8620:	97ffe818 	bl	2680 <strlen@plt>
    8624:	aa1303e1 	mov	x1, x19
    8628:	aa0003e2 	mov	x2, x0
    862c:	aa1403e0 	mov	x0, x20
    8630:	97ffeb58 	bl	3390 <buf_put>
    8634:	528007c3 	mov	w3, #0x3e                  	// #62
    8638:	aa1403e0 	mov	x0, x20
    863c:	91001fe1 	add	x1, sp, #0x7
    8640:	d2800022 	mov	x2, #0x1                   	// #1
    8644:	39001fe3 	strb	w3, [sp, #7]
    8648:	17ffffb1 	b	850c <fwp_write+0x9c>
    864c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8650:	f947f400 	ldr	x0, [x0, #4072]
    8654:	f94127e2 	ldr	x2, [sp, #584]
    8658:	f9400001 	ldr	x1, [x0]
    865c:	eb010042 	subs	x2, x2, x1
    8660:	d2800001 	mov	x1, #0x0                   	// #0
    8664:	540034e1 	b.ne	8d00 <fwp_write+0x890>  // b.any
    8668:	f9413bf5 	ldr	x21, [sp, #624]
    866c:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8670:	f9413ff6 	ldr	x22, [sp, #632]
    8674:	aa1403e0 	mov	x0, x20
    8678:	911c4021 	add	x1, x1, #0x710
    867c:	d2800142 	mov	x2, #0xa                   	// #10
    8680:	f94153fb 	ldr	x27, [sp, #672]
    8684:	f94157fc 	ldr	x28, [sp, #680]
    8688:	910943ff 	add	sp, sp, #0x250
    868c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8690:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8694:	17ffeb3f 	b	3390 <buf_put>
    8698:	f9400456 	ldr	x22, [x2, #8]
    869c:	f90143f7 	str	x23, [sp, #640]
    86a0:	f90147f8 	str	x24, [sp, #648]
    86a4:	b4005b16 	cbz	x22, 9204 <fwp_write+0xd94>
    86a8:	aa1603e0 	mov	x0, x22
    86ac:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    86b0:	911e4021 	add	x1, x1, #0x790
    86b4:	97ffe86f 	bl	2870 <strcmp@plt>
    86b8:	2a0003f5 	mov	w21, w0
    86bc:	34005fe0 	cbz	w0, 92b8 <fwp_write+0xe48>
    86c0:	aa1603e0 	mov	x0, x22
    86c4:	97ffe7ef 	bl	2680 <strlen@plt>
    86c8:	aa1603e1 	mov	x1, x22
    86cc:	aa0003e2 	mov	x2, x0
    86d0:	aa1403e0 	mov	x0, x20
    86d4:	97ffeb2f 	bl	3390 <buf_put>
    86d8:	52800403 	mov	w3, #0x20                  	// #32
    86dc:	91001ff5 	add	x21, sp, #0x7
    86e0:	aa1503e1 	mov	x1, x21
    86e4:	aa1403e0 	mov	x0, x20
    86e8:	d2800022 	mov	x2, #0x1                   	// #1
    86ec:	39001fe3 	strb	w3, [sp, #7]
    86f0:	97ffeb28 	bl	3390 <buf_put>
    86f4:	52800f63 	mov	w3, #0x7b                  	// #123
    86f8:	aa1403e0 	mov	x0, x20
    86fc:	aa1503e1 	mov	x1, x21
    8700:	d2800022 	mov	x2, #0x1                   	// #1
    8704:	39001fe3 	strb	w3, [sp, #7]
    8708:	97ffeb22 	bl	3390 <buf_put>
    870c:	b9401380 	ldr	w0, [x28, #16]
    8710:	52800018 	mov	w24, #0x0                   	// #0
    8714:	7100001f 	cmp	w0, #0x0
    8718:	54003aad 	b.le	8e6c <fwp_write+0x9fc>
    871c:	f9014bf9 	str	x25, [sp, #656]
    8720:	f0000019 	adrp	x25, b000 <__modti3+0x180>
    8724:	911ee339 	add	x25, x25, #0x7b8
    8728:	f9014ffa 	str	x26, [sp, #664]
    872c:	f000001a 	adrp	x26, b000 <__modti3+0x180>
    8730:	911de35a 	add	x26, x26, #0x778
    8734:	91002276 	add	x22, x19, #0x8
    8738:	d2800013 	mov	x19, #0x0                   	// #0
    873c:	b5003e93 	cbnz	x19, 8f0c <fwp_write+0xa9c>
    8740:	d37df277 	lsl	x23, x19, #3
    8744:	34003cb8 	cbz	w24, 8ed8 <fwp_write+0xa68>
    8748:	f9401382 	ldr	x2, [x28, #32]
    874c:	aa1403e0 	mov	x0, x20
    8750:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8754:	52800003 	mov	w3, #0x0                   	// #0
    8758:	f8776842 	ldr	x2, [x2, x23]
    875c:	91000673 	add	x19, x19, #0x1
    8760:	97ffff44 	bl	8470 <fwp_write>
    8764:	b9401380 	ldr	w0, [x28, #16]
    8768:	6b13001f 	cmp	w0, w19
    876c:	54fffe8c 	b.gt	873c <fwp_write+0x2cc>
    8770:	f9414bf9 	ldr	x25, [sp, #656]
    8774:	f9414ffa 	ldr	x26, [sp, #664]
    8778:	340037b8 	cbz	w24, 8e6c <fwp_write+0x9fc>
    877c:	52800523 	mov	w3, #0x29                  	// #41
    8780:	aa1503e1 	mov	x1, x21
    8784:	aa1403e0 	mov	x0, x20
    8788:	d2800022 	mov	x2, #0x1                   	// #1
    878c:	39001fe3 	strb	w3, [sp, #7]
    8790:	97ffeb00 	bl	3390 <buf_put>
    8794:	f9413bf5 	ldr	x21, [sp, #624]
    8798:	f9413ff6 	ldr	x22, [sp, #632]
    879c:	f94143f7 	ldr	x23, [sp, #640]
    87a0:	f94147f8 	ldr	x24, [sp, #648]
    87a4:	f94153fb 	ldr	x27, [sp, #672]
    87a8:	f94157fc 	ldr	x28, [sp, #680]
    87ac:	17ffff5d 	b	8520 <fwp_write+0xb0>
    87b0:	b9404855 	ldr	w21, [x2, #72]
    87b4:	aa1403e0 	mov	x0, x20
    87b8:	93407eb6 	sxtw	x22, w21
    87bc:	91000ac1 	add	x1, x22, #0x2
    87c0:	97ffeac1 	bl	32c4 <buf_grow>
    87c4:	a9400281 	ldp	x1, x0, [x20]
    87c8:	528e8603 	mov	w3, #0x7430                	// #29744
    87cc:	78206823 	strh	w3, [x1, x0]
    87d0:	8b000022 	add	x2, x1, x0
    87d4:	710002bf 	cmp	w21, #0x0
    87d8:	540036cd 	b.le	8eb0 <fwp_write+0xa40>
    87dc:	110006a3 	add	w3, w21, #0x1
    87e0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    87e4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    87e8:	91000449 	add	x9, x2, #0x1
    87ec:	8b23c043 	add	x3, x2, w3, sxtw
    87f0:	f28aaac6 	movk	x6, #0x5556
    87f4:	f2955568 	movk	x8, #0xaaab
    87f8:	1400000d 	b	882c <fwp_write+0x3bc>
    87fc:	d2800021 	mov	x1, #0x1                   	// #1
    8800:	528005a5 	mov	w5, #0x2d                  	// #45
    8804:	f100001f 	cmp	x0, #0x0
    8808:	9b467e60 	smulh	x0, x19, x6
    880c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8810:	381ff465 	strb	w5, [x3], #-1
    8814:	cb040000 	sub	x0, x0, x4
    8818:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    881c:	cb020000 	sub	x0, x0, x2
    8820:	8b010013 	add	x19, x0, x1
    8824:	eb03013f 	cmp	x9, x3
    8828:	54003440 	b.eq	8eb0 <fwp_write+0xa40>  // b.none
    882c:	9b467e60 	smulh	x0, x19, x6
    8830:	937ffe64 	asr	x4, x19, #63
    8834:	52800605 	mov	w5, #0x30                  	// #48
    8838:	cb040000 	sub	x0, x0, x4
    883c:	8b000400 	add	x0, x0, x0, lsl #1
    8840:	cb000260 	sub	x0, x19, x0
    8844:	91000c01 	add	x1, x0, #0x3
    8848:	9bc87c22 	umulh	x2, x1, x8
    884c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8850:	8b4204e2 	add	x2, x7, x2, lsr #1
    8854:	eb020021 	subs	x1, x1, x2
    8858:	54fffd60 	b.eq	8804 <fwp_write+0x394>  // b.none
    885c:	f100043f 	cmp	x1, #0x1
    8860:	54fffce1 	b.ne	87fc <fwp_write+0x38c>  // b.any
    8864:	d2800001 	mov	x1, #0x0                   	// #0
    8868:	52800565 	mov	w5, #0x2b                  	// #43
    886c:	17ffffe6 	b	8804 <fwp_write+0x394>
    8870:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8874:	f947f400 	ldr	x0, [x0, #4072]
    8878:	f94127e2 	ldr	x2, [sp, #584]
    887c:	f9400001 	ldr	x1, [x0]
    8880:	eb010042 	subs	x2, x2, x1
    8884:	d2800001 	mov	x1, #0x0                   	// #0
    8888:	540023c1 	b.ne	8d00 <fwp_write+0x890>  // b.any
    888c:	f9413bf5 	ldr	x21, [sp, #624]
    8890:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8894:	f9413ff6 	ldr	x22, [sp, #632]
    8898:	aa1403e0 	mov	x0, x20
    889c:	911c8021 	add	x1, x1, #0x720
    88a0:	d2800102 	mov	x2, #0x8                   	// #8
    88a4:	17ffff77 	b	8680 <fwp_write+0x210>
    88a8:	aa1403e0 	mov	x0, x20
    88ac:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    88b0:	d28000c2 	mov	x2, #0x6                   	// #6
    88b4:	911e0021 	add	x1, x1, #0x780
    88b8:	97ffeab6 	bl	3390 <buf_put>
    88bc:	d2800015 	mov	x21, #0x0                   	// #0
    88c0:	f9400263 	ldr	x3, [x19]
    88c4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    88c8:	54002c60 	b.eq	8e54 <fwp_write+0x9e4>  // b.none
    88cc:	f9401f82 	ldr	x2, [x28, #56]
    88d0:	f90143f7 	str	x23, [sp, #640]
    88d4:	f90147f8 	str	x24, [sp, #648]
    88d8:	d2800857 	mov	x23, #0x42                  	// #66
    88dc:	f9014bf9 	str	x25, [sp, #656]
    88e0:	f0000016 	adrp	x22, b000 <__modti3+0x180>
    88e4:	f9014ffa 	str	x26, [sp, #664]
    88e8:	911de2d6 	add	x22, x22, #0x778
    88ec:	d2800038 	mov	x24, #0x1                   	// #1
    88f0:	f2a18017 	movk	x23, #0xc00, lsl #16
    88f4:	d2809099 	mov	x25, #0x484                 	// #1156
    88f8:	b40004a2 	cbz	x2, 898c <fwp_write+0x51c>
    88fc:	b9400040 	ldr	w0, [x2]
    8900:	7100701f 	cmp	w0, #0x1c
    8904:	540042c0 	b.eq	915c <fwp_write+0xcec>  // b.none
    8908:	71006c1f 	cmp	w0, #0x1b
    890c:	54000408 	b.hi	898c <fwp_write+0x51c>  // b.pmore
    8910:	9ac02301 	lsl	x1, x24, x0
    8914:	ea17003f 	tst	x1, x23
    8918:	540036a1 	b.ne	8fec <fwp_write+0xb7c>  // b.any
    891c:	ea19003f 	tst	x1, x25
    8920:	54003521 	b.ne	8fc4 <fwp_write+0xb54>  // b.any
    8924:	d2800424 	mov	x4, #0x21                  	// #33
    8928:	ea04003f 	tst	x1, x4
    892c:	54000300 	b.eq	898c <fwp_write+0x51c>  // b.none
    8930:	b7f849c3 	tbnz	x3, #63, 9268 <fwp_write+0xdf8>
    8934:	91002261 	add	x1, x19, #0x8
    8938:	8b150021 	add	x1, x1, x21
    893c:	39400021 	ldrb	w1, [x1]
    8940:	7100001f 	cmp	w0, #0x0
    8944:	93401c23 	sxtb	x3, w1
    8948:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    894c:	d503201f 	nop
    8950:	aa1403e0 	mov	x0, x20
    8954:	52800003 	mov	w3, #0x0                   	// #0
    8958:	97fffec6 	bl	8470 <fwp_write>
    895c:	910006b5 	add	x21, x21, #0x1
    8960:	f9400260 	ldr	x0, [x19]
    8964:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8968:	eb0002bf 	cmp	x21, x0
    896c:	540026c2 	b.cs	8e44 <fwp_write+0x9d4>  // b.hs, b.nlast
    8970:	d2800042 	mov	x2, #0x2                   	// #2
    8974:	aa1603e1 	mov	x1, x22
    8978:	aa1403e0 	mov	x0, x20
    897c:	97ffea85 	bl	3390 <buf_put>
    8980:	f9401f82 	ldr	x2, [x28, #56]
    8984:	f9400263 	ldr	x3, [x19]
    8988:	b5fffba2 	cbnz	x2, 88fc <fwp_write+0x48c>
    898c:	d37df2a0 	lsl	x0, x21, #3
    8990:	b7f83f03 	tbnz	x3, #63, 9170 <fwp_write+0xd00>
    8994:	91002261 	add	x1, x19, #0x8
    8998:	8b000020 	add	x0, x1, x0
    899c:	f9400001 	ldr	x1, [x0]
    89a0:	17ffffec 	b	8950 <fwp_write+0x4e0>
    89a4:	a9400e62 	ldp	x2, x3, [x19]
    89a8:	b7f83ca3 	tbnz	x3, #63, 913c <fwp_write+0xccc>
    89ac:	910123f5 	add	x21, sp, #0x48
    89b0:	aa1503e0 	mov	x0, x21
    89b4:	97ffe8fb 	bl	2da0 <fwp_fmt_u128>
    89b8:	aa1503e0 	mov	x0, x21
    89bc:	97ffe731 	bl	2680 <strlen@plt>
    89c0:	aa1503e1 	mov	x1, x21
    89c4:	aa0003e2 	mov	x2, x0
    89c8:	17fffed0 	b	8508 <fwp_write+0x98>
    89cc:	fd015be8 	str	d8, [sp, #688]
    89d0:	1e270268 	fmov	s8, w19
    89d4:	fd015fe9 	str	d9, [sp, #696]
    89d8:	1e282100 	fcmp	s8, s8
    89dc:	54004d26 	b.vs	9380 <fwp_write+0xf10>
    89e0:	1e20c101 	fabs	s1, s8
    89e4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    89e8:	1e270000 	fmov	s0, w0
    89ec:	1e202020 	fcmp	s1, s0
    89f0:	54002c0d 	b.le	8f70 <fwp_write+0xb00>
    89f4:	1e202118 	fcmpe	s8, #0.0
    89f8:	f0000002 	adrp	x2, b000 <__modti3+0x180>
    89fc:	91090042 	add	x2, x2, #0x240
    8a00:	910123f5 	add	x21, sp, #0x48
    8a04:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8a08:	911b4021 	add	x1, x1, #0x6d0
    8a0c:	aa1503e0 	mov	x0, x21
    8a10:	9a81c041 	csel	x1, x2, x1, gt
    8a14:	97ffe7c7 	bl	2930 <strcpy@plt>
    8a18:	aa1503e0 	mov	x0, x21
    8a1c:	97ffe719 	bl	2680 <strlen@plt>
    8a20:	aa1503e1 	mov	x1, x21
    8a24:	aa0003e2 	mov	x2, x0
    8a28:	aa1403e0 	mov	x0, x20
    8a2c:	97ffea59 	bl	3390 <buf_put>
    8a30:	f9413bf5 	ldr	x21, [sp, #624]
    8a34:	f9413ff6 	ldr	x22, [sp, #632]
    8a38:	f94153fb 	ldr	x27, [sp, #672]
    8a3c:	f94157fc 	ldr	x28, [sp, #680]
    8a40:	fd415be8 	ldr	d8, [sp, #688]
    8a44:	fd415fe9 	ldr	d9, [sp, #696]
    8a48:	17fffeb6 	b	8520 <fwp_write+0xb0>
    8a4c:	f9400276 	ldr	x22, [x19]
    8a50:	34002e03 	cbz	w3, 9010 <fwp_write+0xba0>
    8a54:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a58:	f947f400 	ldr	x0, [x0, #4072]
    8a5c:	f94127e2 	ldr	x2, [sp, #584]
    8a60:	f9400001 	ldr	x1, [x0]
    8a64:	eb010042 	subs	x2, x2, x1
    8a68:	d2800001 	mov	x1, #0x0                   	// #0
    8a6c:	540014a1 	b.ne	8d00 <fwp_write+0x890>  // b.any
    8a70:	aa1603e2 	mov	x2, x22
    8a74:	91002261 	add	x1, x19, #0x8
    8a78:	f9413bf5 	ldr	x21, [sp, #624]
    8a7c:	aa1403e0 	mov	x0, x20
    8a80:	f9413ff6 	ldr	x22, [sp, #632]
    8a84:	17fffeff 	b	8680 <fwp_write+0x210>
    8a88:	fd015be8 	str	d8, [sp, #688]
    8a8c:	9e670268 	fmov	d8, x19
    8a90:	fd015fe9 	str	d9, [sp, #696]
    8a94:	1e682100 	fcmp	d8, d8
    8a98:	54004746 	b.vs	9380 <fwp_write+0xf10>
    8a9c:	1e60c101 	fabs	d1, d8
    8aa0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8aa4:	9e670000 	fmov	d0, x0
    8aa8:	910123f5 	add	x21, sp, #0x48
    8aac:	52800033 	mov	w19, #0x1                   	// #1
    8ab0:	1e602020 	fcmp	d1, d0
    8ab4:	540001ad 	b.le	8ae8 <fwp_write+0x678>
    8ab8:	1e602118 	fcmpe	d8, #0.0
    8abc:	f0000002 	adrp	x2, b000 <__modti3+0x180>
    8ac0:	91090042 	add	x2, x2, #0x240
    8ac4:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8ac8:	911b4021 	add	x1, x1, #0x6d0
    8acc:	aa1503e0 	mov	x0, x21
    8ad0:	9a81c041 	csel	x1, x2, x1, gt
    8ad4:	97ffe797 	bl	2930 <strcpy@plt>
    8ad8:	17ffffd0 	b	8a18 <fwp_write+0x5a8>
    8adc:	11000673 	add	w19, w19, #0x1
    8ae0:	71004a7f 	cmp	w19, #0x12
    8ae4:	54003860 	b.eq	91f0 <fwp_write+0xd80>  // b.none
    8ae8:	1e604100 	fmov	d0, d8
    8aec:	2a1303e1 	mov	w1, w19
    8af0:	aa1503e0 	mov	x0, x21
    8af4:	97ffeb68 	bl	3894 <fwp_format_g.constprop.0>
    8af8:	aa1503e0 	mov	x0, x21
    8afc:	d2800001 	mov	x1, #0x0                   	// #0
    8b00:	97ffe6f4 	bl	26d0 <strtod@plt>
    8b04:	1e602100 	fcmp	d8, d0
    8b08:	54fffea1 	b.ne	8adc <fwp_write+0x66c>  // b.any
    8b0c:	aa1503e0 	mov	x0, x21
    8b10:	97ffea59 	bl	3474 <fwp_finish_float>
    8b14:	17ffffc1 	b	8a18 <fwp_write+0x5a8>
    8b18:	a9400e62 	ldp	x2, x3, [x19]
    8b1c:	910123f3 	add	x19, sp, #0x48
    8b20:	aa1303e0 	mov	x0, x19
    8b24:	97ffe89f 	bl	2da0 <fwp_fmt_u128>
    8b28:	17fffe74 	b	84f8 <fwp_write+0x88>
    8b2c:	f90143f7 	str	x23, [sp, #640]
    8b30:	f90147f8 	str	x24, [sp, #648]
    8b34:	2a1303f8 	mov	w24, w19
    8b38:	f9014bf9 	str	x25, [sp, #656]
    8b3c:	f9014ffa 	str	x26, [sp, #664]
    8b40:	f13ffe7f 	cmp	x19, #0xfff
    8b44:	54000049 	b.ls	8b4c <fwp_write+0x6dc>  // b.plast
    8b48:	b9400278 	ldr	w24, [x19]
    8b4c:	f9400f80 	ldr	x0, [x28, #24]
    8b50:	2a1803f5 	mov	w21, w24
    8b54:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8b58:	d37ef6b9 	lsl	x25, x21, #2
    8b5c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8b60:	aa1603e0 	mov	x0, x22
    8b64:	97ffe6c7 	bl	2680 <strlen@plt>
    8b68:	aa1603e1 	mov	x1, x22
    8b6c:	aa0003e2 	mov	x2, x0
    8b70:	aa1403e0 	mov	x0, x20
    8b74:	97ffea07 	bl	3390 <buf_put>
    8b78:	f9401780 	ldr	x0, [x28, #40]
    8b7c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8b80:	7100001f 	cmp	w0, #0x0
    8b84:	5400068d 	b.le	8c54 <fwp_write+0x7e4>
    8b88:	91002276 	add	x22, x19, #0x8
    8b8c:	91001ff5 	add	x21, sp, #0x7
    8b90:	d280001b 	mov	x27, #0x0                   	// #0
    8b94:	5280041a 	mov	w26, #0x20                  	// #32
    8b98:	f9401b80 	ldr	x0, [x28, #48]
    8b9c:	aa1503e1 	mov	x1, x21
    8ba0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8ba4:	d2800022 	mov	x2, #0x1                   	// #1
    8ba8:	f8786803 	ldr	x3, [x0, x24]
    8bac:	aa1403e0 	mov	x0, x20
    8bb0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8bb4:	39001ffa 	strb	w26, [sp, #7]
    8bb8:	97ffe9f6 	bl	3390 <buf_put>
    8bbc:	f13ffeff 	cmp	x23, #0xfff
    8bc0:	b9400261 	ldr	w1, [x19]
    8bc4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8bc8:	7100383f 	cmp	w1, #0xe
    8bcc:	54000160 	b.eq	8bf8 <fwp_write+0x788>  // b.none
    8bd0:	7100403f 	cmp	w1, #0x10
    8bd4:	54001a60 	b.eq	8f20 <fwp_write+0xab0>  // b.none
    8bd8:	7100283f 	cmp	w1, #0xa
    8bdc:	54002aa0 	b.eq	9130 <fwp_write+0xcc0>  // b.none
    8be0:	540014ac 	b.gt	8e74 <fwp_write+0xa04>
    8be4:	71000c3f 	cmp	w1, #0x3
    8be8:	540029ac 	b.gt	911c <fwp_write+0xcac>
    8bec:	d37ffee0 	lsr	x0, x23, #63
    8bf0:	37f814a1 	tbnz	w1, #31, 8e84 <fwp_write+0xa14>
    8bf4:	d503201f 	nop
    8bf8:	34001460 	cbz	w0, 8e84 <fwp_write+0xa14>
    8bfc:	52800503 	mov	w3, #0x28                  	// #40
    8c00:	aa1503e1 	mov	x1, x21
    8c04:	aa1403e0 	mov	x0, x20
    8c08:	d2800022 	mov	x2, #0x1                   	// #1
    8c0c:	39001fe3 	strb	w3, [sp, #7]
    8c10:	97ffe9e0 	bl	3390 <buf_put>
    8c14:	aa1303e2 	mov	x2, x19
    8c18:	aa1703e1 	mov	x1, x23
    8c1c:	aa1403e0 	mov	x0, x20
    8c20:	52800003 	mov	w3, #0x0                   	// #0
    8c24:	97fffe13 	bl	8470 <fwp_write>
    8c28:	52800523 	mov	w3, #0x29                  	// #41
    8c2c:	aa1503e1 	mov	x1, x21
    8c30:	aa1403e0 	mov	x0, x20
    8c34:	d2800022 	mov	x2, #0x1                   	// #1
    8c38:	39001fe3 	strb	w3, [sp, #7]
    8c3c:	97ffe9d5 	bl	3390 <buf_put>
    8c40:	f9401780 	ldr	x0, [x28, #40]
    8c44:	9100077b 	add	x27, x27, #0x1
    8c48:	b8796800 	ldr	w0, [x0, x25]
    8c4c:	6b1b001f 	cmp	w0, w27
    8c50:	54fffa4c 	b.gt	8b98 <fwp_write+0x728>
    8c54:	f9413bf5 	ldr	x21, [sp, #624]
    8c58:	f9413ff6 	ldr	x22, [sp, #632]
    8c5c:	f94143f7 	ldr	x23, [sp, #640]
    8c60:	f94147f8 	ldr	x24, [sp, #648]
    8c64:	f9414bf9 	ldr	x25, [sp, #656]
    8c68:	f9414ffa 	ldr	x26, [sp, #664]
    8c6c:	f94153fb 	ldr	x27, [sp, #672]
    8c70:	f94157fc 	ldr	x28, [sp, #680]
    8c74:	17fffe2b 	b	8520 <fwp_write+0xb0>
    8c78:	52800783 	mov	w3, #0x3c                  	// #60
    8c7c:	91001ff3 	add	x19, sp, #0x7
    8c80:	aa1303e1 	mov	x1, x19
    8c84:	d2800022 	mov	x2, #0x1                   	// #1
    8c88:	aa1403e0 	mov	x0, x20
    8c8c:	39001fe3 	strb	w3, [sp, #7]
    8c90:	97ffe9c0 	bl	3390 <buf_put>
    8c94:	f9400795 	ldr	x21, [x28, #8]
    8c98:	aa1503e0 	mov	x0, x21
    8c9c:	97ffe679 	bl	2680 <strlen@plt>
    8ca0:	aa1503e1 	mov	x1, x21
    8ca4:	aa0003e2 	mov	x2, x0
    8ca8:	aa1403e0 	mov	x0, x20
    8cac:	97ffe9b9 	bl	3390 <buf_put>
    8cb0:	528007c3 	mov	w3, #0x3e                  	// #62
    8cb4:	aa1303e1 	mov	x1, x19
    8cb8:	aa1403e0 	mov	x0, x20
    8cbc:	d2800022 	mov	x2, #0x1                   	// #1
    8cc0:	39001fe3 	strb	w3, [sp, #7]
    8cc4:	17fffe12 	b	850c <fwp_write+0x9c>
    8cc8:	f100067f 	cmp	x19, #0x1
    8ccc:	540025a0 	b.eq	9180 <fwp_write+0xd10>  // b.none
    8cd0:	b100067f 	cmn	x19, #0x1
    8cd4:	54002bc0 	b.eq	924c <fwp_write+0xddc>  // b.none
    8cd8:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8cdc:	911b6021 	add	x1, x1, #0x6d8
    8ce0:	d2800022 	mov	x2, #0x1                   	// #1
    8ce4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ce8:	f947f400 	ldr	x0, [x0, #4072]
    8cec:	f94127e4 	ldr	x4, [sp, #584]
    8cf0:	f9400003 	ldr	x3, [x0]
    8cf4:	eb030084 	subs	x4, x4, x3
    8cf8:	d2800003 	mov	x3, #0x0                   	// #0
    8cfc:	54ffebe0 	b.eq	8a78 <fwp_write+0x608>  // b.none
    8d00:	f90143f7 	str	x23, [sp, #640]
    8d04:	f90147f8 	str	x24, [sp, #648]
    8d08:	f9014bf9 	str	x25, [sp, #656]
    8d0c:	f9014ffa 	str	x26, [sp, #664]
    8d10:	fd015be8 	str	d8, [sp, #688]
    8d14:	fd015fe9 	str	d9, [sp, #696]
    8d18:	97ffe6b6 	bl	27f0 <__stack_chk_fail@plt>
    8d1c:	52800b63 	mov	w3, #0x5b                  	// #91
    8d20:	91001ff5 	add	x21, sp, #0x7
    8d24:	aa1503e1 	mov	x1, x21
    8d28:	aa1403e0 	mov	x0, x20
    8d2c:	d2800022 	mov	x2, #0x1                   	// #1
    8d30:	f0000016 	adrp	x22, b000 <__modti3+0x180>
    8d34:	911de2d6 	add	x22, x22, #0x778
    8d38:	39001fe3 	strb	w3, [sp, #7]
    8d3c:	97ffe995 	bl	3390 <buf_put>
    8d40:	b4000273 	cbz	x19, 8d8c <fwp_write+0x91c>
    8d44:	f9400661 	ldr	x1, [x19, #8]
    8d48:	aa1403e0 	mov	x0, x20
    8d4c:	f9401f82 	ldr	x2, [x28, #56]
    8d50:	52800003 	mov	w3, #0x0                   	// #0
    8d54:	97fffdc7 	bl	8470 <fwp_write>
    8d58:	f9400a73 	ldr	x19, [x19, #16]
    8d5c:	b4000193 	cbz	x19, 8d8c <fwp_write+0x91c>
    8d60:	aa1603e1 	mov	x1, x22
    8d64:	aa1403e0 	mov	x0, x20
    8d68:	d2800042 	mov	x2, #0x2                   	// #2
    8d6c:	97ffe989 	bl	3390 <buf_put>
    8d70:	f9400661 	ldr	x1, [x19, #8]
    8d74:	aa1403e0 	mov	x0, x20
    8d78:	f9401f82 	ldr	x2, [x28, #56]
    8d7c:	52800003 	mov	w3, #0x0                   	// #0
    8d80:	97fffdbc 	bl	8470 <fwp_write>
    8d84:	f9400a73 	ldr	x19, [x19, #16]
    8d88:	b5fffed3 	cbnz	x19, 8d60 <fwp_write+0x8f0>
    8d8c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8d90:	aa1503e1 	mov	x1, x21
    8d94:	aa1403e0 	mov	x0, x20
    8d98:	d2800022 	mov	x2, #0x1                   	// #1
    8d9c:	39001fe3 	strb	w3, [sp, #7]
    8da0:	17fffddb 	b	850c <fwp_write+0x9c>
    8da4:	aa1403e0 	mov	x0, x20
    8da8:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8dac:	d28000c2 	mov	x2, #0x6                   	// #6
    8db0:	911da021 	add	x1, x1, #0x768
    8db4:	97ffe977 	bl	3390 <buf_put>
    8db8:	f9400260 	ldr	x0, [x19]
    8dbc:	b40004c0 	cbz	x0, 8e54 <fwp_write+0x9e4>
    8dc0:	910123f5 	add	x21, sp, #0x48
    8dc4:	91002276 	add	x22, x19, #0x8
    8dc8:	f90143f7 	str	x23, [sp, #640]
    8dcc:	d2800017 	mov	x23, #0x0                   	// #0
    8dd0:	f90147f8 	str	x24, [sp, #648]
    8dd4:	f0000018 	adrp	x24, b000 <__modti3+0x180>
    8dd8:	911dc318 	add	x24, x24, #0x770
    8ddc:	f9014bf9 	str	x25, [sp, #656]
    8de0:	f0000019 	adrp	x25, b000 <__modti3+0x180>
    8de4:	911de339 	add	x25, x25, #0x778
    8de8:	f9014ffa 	str	x26, [sp, #664]
    8dec:	14000005 	b	8e00 <fwp_write+0x990>
    8df0:	aa1903e1 	mov	x1, x25
    8df4:	aa1403e0 	mov	x0, x20
    8df8:	d2800042 	mov	x2, #0x2                   	// #2
    8dfc:	97ffe965 	bl	3390 <buf_put>
    8e00:	38776ac5 	ldrb	w5, [x22, x23]
    8e04:	d2804003 	mov	x3, #0x200                 	// #512
    8e08:	aa1803e4 	mov	x4, x24
    8e0c:	aa0303e1 	mov	x1, x3
    8e10:	52800042 	mov	w2, #0x2                   	// #2
    8e14:	aa1503e0 	mov	x0, x21
    8e18:	910006f7 	add	x23, x23, #0x1
    8e1c:	97ffe651 	bl	2760 <__snprintf_chk@plt>
    8e20:	aa1503e0 	mov	x0, x21
    8e24:	97ffe617 	bl	2680 <strlen@plt>
    8e28:	aa1503e1 	mov	x1, x21
    8e2c:	aa0003e2 	mov	x2, x0
    8e30:	aa1403e0 	mov	x0, x20
    8e34:	97ffe957 	bl	3390 <buf_put>
    8e38:	f9400260 	ldr	x0, [x19]
    8e3c:	eb17001f 	cmp	x0, x23
    8e40:	54fffd88 	b.hi	8df0 <fwp_write+0x980>  // b.pmore
    8e44:	f94143f7 	ldr	x23, [sp, #640]
    8e48:	f94147f8 	ldr	x24, [sp, #648]
    8e4c:	f9414bf9 	ldr	x25, [sp, #656]
    8e50:	f9414ffa 	ldr	x26, [sp, #664]
    8e54:	52800ba3 	mov	w3, #0x5d                  	// #93
    8e58:	aa1403e0 	mov	x0, x20
    8e5c:	91001fe1 	add	x1, sp, #0x7
    8e60:	d2800022 	mov	x2, #0x1                   	// #1
    8e64:	39001fe3 	strb	w3, [sp, #7]
    8e68:	17fffda9 	b	850c <fwp_write+0x9c>
    8e6c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8e70:	17fffe44 	b	8780 <fwp_write+0x310>
    8e74:	f10002ff 	cmp	x23, #0x0
    8e78:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8e7c:	71002c3f 	cmp	w1, #0xb
    8e80:	54ffebc0 	b.eq	8bf8 <fwp_write+0x788>  // b.none
    8e84:	aa1303e2 	mov	x2, x19
    8e88:	aa1703e1 	mov	x1, x23
    8e8c:	aa1403e0 	mov	x0, x20
    8e90:	52800003 	mov	w3, #0x0                   	// #0
    8e94:	97fffd77 	bl	8470 <fwp_write>
    8e98:	17ffff6a 	b	8c40 <fwp_write+0x7d0>
    8e9c:	aa1403e0 	mov	x0, x20
    8ea0:	91001fe1 	add	x1, sp, #0x7
    8ea4:	52800fa3 	mov	w3, #0x7d                  	// #125
    8ea8:	d2800022 	mov	x2, #0x1                   	// #1
    8eac:	17fffe38 	b	878c <fwp_write+0x31c>
    8eb0:	a9400281 	ldp	x1, x0, [x20]
    8eb4:	91000800 	add	x0, x0, #0x2
    8eb8:	8b160000 	add	x0, x0, x22
    8ebc:	f9000680 	str	x0, [x20, #8]
    8ec0:	3820683f 	strb	wzr, [x1, x0]
    8ec4:	f9413bf5 	ldr	x21, [sp, #624]
    8ec8:	f9413ff6 	ldr	x22, [sp, #632]
    8ecc:	f94153fb 	ldr	x27, [sp, #672]
    8ed0:	f94157fc 	ldr	x28, [sp, #680]
    8ed4:	17fffd93 	b	8520 <fwp_write+0xb0>
    8ed8:	f9400f80 	ldr	x0, [x28, #24]
    8edc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8ee0:	aa1b03e0 	mov	x0, x27
    8ee4:	97ffe5e7 	bl	2680 <strlen@plt>
    8ee8:	aa1b03e1 	mov	x1, x27
    8eec:	aa0003e2 	mov	x2, x0
    8ef0:	aa1403e0 	mov	x0, x20
    8ef4:	97ffe927 	bl	3390 <buf_put>
    8ef8:	aa1903e1 	mov	x1, x25
    8efc:	aa1403e0 	mov	x0, x20
    8f00:	d2800062 	mov	x2, #0x3                   	// #3
    8f04:	97ffe923 	bl	3390 <buf_put>
    8f08:	17fffe10 	b	8748 <fwp_write+0x2d8>
    8f0c:	aa1a03e1 	mov	x1, x26
    8f10:	aa1403e0 	mov	x0, x20
    8f14:	d2800042 	mov	x2, #0x2                   	// #2
    8f18:	97ffe91e 	bl	3390 <buf_put>
    8f1c:	17fffe09 	b	8740 <fwp_write+0x2d0>
    8f20:	f9400660 	ldr	x0, [x19, #8]
    8f24:	b4fffb00 	cbz	x0, 8e84 <fwp_write+0xa14>
    8f28:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8f2c:	911e4021 	add	x1, x1, #0x790
    8f30:	97ffe650 	bl	2870 <strcmp@plt>
    8f34:	7100001f 	cmp	w0, #0x0
    8f38:	1a9f07e0 	cset	w0, ne	// ne = any
    8f3c:	17ffff2f 	b	8bf8 <fwp_write+0x788>
    8f40:	aa1403e0 	mov	x0, x20
    8f44:	d2800042 	mov	x2, #0x2                   	// #2
    8f48:	f0000001 	adrp	x1, b000 <__modti3+0x180>
    8f4c:	911e2021 	add	x1, x1, #0x788
    8f50:	97ffe910 	bl	3390 <buf_put>
    8f54:	91004261 	add	x1, x19, #0x10
    8f58:	aa1403e0 	mov	x0, x20
    8f5c:	f9402382 	ldr	x2, [x28, #64]
    8f60:	52800003 	mov	w3, #0x0                   	// #0
    8f64:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8f68:	97fffd42 	bl	8470 <fwp_write>
    8f6c:	17fffd9c 	b	85dc <fwp_write+0x16c>
    8f70:	1e22c109 	fcvt	d9, s8
    8f74:	910123f5 	add	x21, sp, #0x48
    8f78:	52800033 	mov	w19, #0x1                   	// #1
    8f7c:	d503201f 	nop
    8f80:	1e604120 	fmov	d0, d9
    8f84:	2a1303e1 	mov	w1, w19
    8f88:	aa1503e0 	mov	x0, x21
    8f8c:	97ffea42 	bl	3894 <fwp_format_g.constprop.0>
    8f90:	aa1503e0 	mov	x0, x21
    8f94:	d2800001 	mov	x1, #0x0                   	// #0
    8f98:	97ffe642 	bl	28a0 <strtof@plt>
    8f9c:	1e202100 	fcmp	s8, s0
    8fa0:	54ffdb60 	b.eq	8b0c <fwp_write+0x69c>  // b.none
    8fa4:	11000673 	add	w19, w19, #0x1
    8fa8:	71002a7f 	cmp	w19, #0xa
    8fac:	54fffea1 	b.ne	8f80 <fwp_write+0xb10>  // b.any
    8fb0:	1e604120 	fmov	d0, d9
    8fb4:	aa1503e0 	mov	x0, x21
    8fb8:	52800121 	mov	w1, #0x9                   	// #9
    8fbc:	97ffea36 	bl	3894 <fwp_format_g.constprop.0>
    8fc0:	17fffed3 	b	8b0c <fwp_write+0x69c>
    8fc4:	d37ef6a1 	lsl	x1, x21, #2
    8fc8:	b7f81563 	tbnz	x3, #63, 9274 <fwp_write+0xe04>
    8fcc:	91002263 	add	x3, x19, #0x8
    8fd0:	8b010061 	add	x1, x3, x1
    8fd4:	b9400023 	ldr	w3, [x1]
    8fd8:	7100081f 	cmp	w0, #0x2
    8fdc:	2a0303e1 	mov	w1, w3
    8fe0:	93407c63 	sxtw	x3, w3
    8fe4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8fe8:	17fffe5a 	b	8950 <fwp_write+0x4e0>
    8fec:	d37ffaa1 	lsl	x1, x21, #1
    8ff0:	b7f81363 	tbnz	x3, #63, 925c <fwp_write+0xdec>
    8ff4:	91002263 	add	x3, x19, #0x8
    8ff8:	8b010061 	add	x1, x3, x1
    8ffc:	79400021 	ldrh	w1, [x1]
    9000:	7100041f 	cmp	w0, #0x1
    9004:	93403c23 	sxth	x3, w1
    9008:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    900c:	17fffe51 	b	8950 <fwp_write+0x4e0>
    9010:	52800443 	mov	w3, #0x22                  	// #34
    9014:	91001ff5 	add	x21, sp, #0x7
    9018:	91002273 	add	x19, x19, #0x8
    901c:	aa1503e1 	mov	x1, x21
    9020:	aa1403e0 	mov	x0, x20
    9024:	d2800022 	mov	x2, #0x1                   	// #1
    9028:	39001fe3 	strb	w3, [sp, #7]
    902c:	f90143f7 	str	x23, [sp, #640]
    9030:	8b160277 	add	x23, x19, x22
    9034:	f90147f8 	str	x24, [sp, #648]
    9038:	97ffe8d6 	bl	3390 <buf_put>
    903c:	b4000696 	cbz	x22, 910c <fwp_write+0xc9c>
    9040:	d0000018 	adrp	x24, b000 <__modti3+0x180>
    9044:	911ce318 	add	x24, x24, #0x738
    9048:	f9014bf9 	str	x25, [sp, #656]
    904c:	d0000019 	adrp	x25, b000 <__modti3+0x180>
    9050:	911d6339 	add	x25, x25, #0x758
    9054:	f9014ffa 	str	x26, [sp, #664]
    9058:	1400000d 	b	908c <fwp_write+0xc1c>
    905c:	710024bf 	cmp	w5, #0x9
    9060:	54000460 	b.eq	90ec <fwp_write+0xc7c>  // b.none
    9064:	710028bf 	cmp	w5, #0xa
    9068:	54000a61 	b.ne	91b4 <fwp_write+0xd44>  // b.any
    906c:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    9070:	aa1403e0 	mov	x0, x20
    9074:	911d2021 	add	x1, x1, #0x748
    9078:	d2800042 	mov	x2, #0x2                   	// #2
    907c:	97ffe8c5 	bl	3390 <buf_put>
    9080:	91000673 	add	x19, x19, #0x1
    9084:	eb17027f 	cmp	x19, x23
    9088:	540003e0 	b.eq	9104 <fwp_write+0xc94>  // b.none
    908c:	39400265 	ldrb	w5, [x19]
    9090:	710034bf 	cmp	w5, #0xd
    9094:	54000180 	b.eq	90c4 <fwp_write+0xc54>  // b.none
    9098:	54fffe29 	b.ls	905c <fwp_write+0xbec>  // b.plast
    909c:	710088bf 	cmp	w5, #0x22
    90a0:	540001c0 	b.eq	90d8 <fwp_write+0xc68>  // b.none
    90a4:	710170bf 	cmp	w5, #0x5c
    90a8:	54000741 	b.ne	9190 <fwp_write+0xd20>  // b.any
    90ac:	aa1403e0 	mov	x0, x20
    90b0:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    90b4:	d2800042 	mov	x2, #0x2                   	// #2
    90b8:	911d0021 	add	x1, x1, #0x740
    90bc:	97ffe8b5 	bl	3390 <buf_put>
    90c0:	17fffff0 	b	9080 <fwp_write+0xc10>
    90c4:	aa1903e1 	mov	x1, x25
    90c8:	aa1403e0 	mov	x0, x20
    90cc:	d2800042 	mov	x2, #0x2                   	// #2
    90d0:	97ffe8b0 	bl	3390 <buf_put>
    90d4:	17ffffeb 	b	9080 <fwp_write+0xc10>
    90d8:	aa1803e1 	mov	x1, x24
    90dc:	aa1403e0 	mov	x0, x20
    90e0:	d2800042 	mov	x2, #0x2                   	// #2
    90e4:	97ffe8ab 	bl	3390 <buf_put>
    90e8:	17ffffe6 	b	9080 <fwp_write+0xc10>
    90ec:	aa1403e0 	mov	x0, x20
    90f0:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    90f4:	d2800042 	mov	x2, #0x2                   	// #2
    90f8:	911d4021 	add	x1, x1, #0x750
    90fc:	97ffe8a5 	bl	3390 <buf_put>
    9100:	17ffffe0 	b	9080 <fwp_write+0xc10>
    9104:	f9414bf9 	ldr	x25, [sp, #656]
    9108:	f9414ffa 	ldr	x26, [sp, #664]
    910c:	aa1503e1 	mov	x1, x21
    9110:	aa1403e0 	mov	x0, x20
    9114:	52800443 	mov	w3, #0x22                  	// #34
    9118:	17fffd9c 	b	8788 <fwp_write+0x318>
    911c:	7100103f 	cmp	w1, #0x4
    9120:	54ffeb21 	b.ne	8e84 <fwp_write+0xa14>  // b.any
    9124:	f94006e0 	ldr	x0, [x23, #8]
    9128:	d37ffc00 	lsr	x0, x0, #63
    912c:	17fffeb3 	b	8bf8 <fwp_write+0x788>
    9130:	710002ff 	cmp	w23, #0x0
    9134:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9138:	17fffeb0 	b	8bf8 <fwp_write+0x788>
    913c:	528005a1 	mov	w1, #0x2d                  	// #45
    9140:	eb0203e2 	negs	x2, x2
    9144:	da0303e3 	ngc	x3, x3
    9148:	910127e0 	add	x0, sp, #0x49
    914c:	910123f5 	add	x21, sp, #0x48
    9150:	390123e1 	strb	w1, [sp, #72]
    9154:	97ffe713 	bl	2da0 <fwp_fmt_u128>
    9158:	17fffe18 	b	89b8 <fwp_write+0x548>
    915c:	d37ceea1 	lsl	x1, x21, #4
    9160:	b7f810a3 	tbnz	x3, #63, 9374 <fwp_write+0xf04>
    9164:	91002260 	add	x0, x19, #0x8
    9168:	8b010001 	add	x1, x0, x1
    916c:	17fffdf9 	b	8950 <fwp_write+0x4e0>
    9170:	f9400a61 	ldr	x1, [x19, #16]
    9174:	8b010000 	add	x0, x0, x1
    9178:	f9400001 	ldr	x1, [x0]
    917c:	17fffdf5 	b	8950 <fwp_write+0x4e0>
    9180:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    9184:	d2800042 	mov	x2, #0x2                   	// #2
    9188:	911b8021 	add	x1, x1, #0x6e0
    918c:	17fffed6 	b	8ce4 <fwp_write+0x874>
    9190:	7101fcbf 	cmp	w5, #0x7f
    9194:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9198:	540000e9 	b.ls	91b4 <fwp_write+0xd44>  // b.plast
    919c:	aa1503e1 	mov	x1, x21
    91a0:	aa1403e0 	mov	x0, x20
    91a4:	d2800022 	mov	x2, #0x1                   	// #1
    91a8:	39001fe5 	strb	w5, [sp, #7]
    91ac:	97ffe879 	bl	3390 <buf_put>
    91b0:	17ffffb4 	b	9080 <fwp_write+0xc10>
    91b4:	d2800203 	mov	x3, #0x10                  	// #16
    91b8:	d0000004 	adrp	x4, b000 <__modti3+0x180>
    91bc:	aa0303e1 	mov	x1, x3
    91c0:	911d8084 	add	x4, x4, #0x760
    91c4:	910123f6 	add	x22, sp, #0x48
    91c8:	52800042 	mov	w2, #0x2                   	// #2
    91cc:	aa1603e0 	mov	x0, x22
    91d0:	97ffe564 	bl	2760 <__snprintf_chk@plt>
    91d4:	aa1603e0 	mov	x0, x22
    91d8:	97ffe52a 	bl	2680 <strlen@plt>
    91dc:	aa1603e1 	mov	x1, x22
    91e0:	aa0003e2 	mov	x2, x0
    91e4:	aa1403e0 	mov	x0, x20
    91e8:	97ffe86a 	bl	3390 <buf_put>
    91ec:	17ffffa5 	b	9080 <fwp_write+0xc10>
    91f0:	1e604100 	fmov	d0, d8
    91f4:	aa1503e0 	mov	x0, x21
    91f8:	52800221 	mov	w1, #0x11                  	// #17
    91fc:	97ffe9a6 	bl	3894 <fwp_format_g.constprop.0>
    9200:	17fffe43 	b	8b0c <fwp_write+0x69c>
    9204:	b9401040 	ldr	w0, [x2, #16]
    9208:	350003c0 	cbnz	w0, 9280 <fwp_write+0xe10>
    920c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9210:	f947f400 	ldr	x0, [x0, #4072]
    9214:	f94127e2 	ldr	x2, [sp, #584]
    9218:	f9400001 	ldr	x1, [x0]
    921c:	eb010042 	subs	x2, x2, x1
    9220:	d2800001 	mov	x1, #0x0                   	// #0
    9224:	54ffd721 	b.ne	8d08 <fwp_write+0x898>  // b.any
    9228:	f9413bf5 	ldr	x21, [sp, #624]
    922c:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    9230:	f9413ff6 	ldr	x22, [sp, #632]
    9234:	aa1403e0 	mov	x0, x20
    9238:	f94143f7 	ldr	x23, [sp, #640]
    923c:	911ec021 	add	x1, x1, #0x7b0
    9240:	f94147f8 	ldr	x24, [sp, #648]
    9244:	d2800042 	mov	x2, #0x2                   	// #2
    9248:	17fffd0e 	b	8680 <fwp_write+0x210>
    924c:	d0000001 	adrp	x1, b000 <__modti3+0x180>
    9250:	d2800042 	mov	x2, #0x2                   	// #2
    9254:	911ba021 	add	x1, x1, #0x6e8
    9258:	17fffea3 	b	8ce4 <fwp_write+0x874>
    925c:	f9400a63 	ldr	x3, [x19, #16]
    9260:	8b030021 	add	x1, x1, x3
    9264:	17ffff66 	b	8ffc <fwp_write+0xb8c>
    9268:	f9400a61 	ldr	x1, [x19, #16]
    926c:	8b0102a1 	add	x1, x21, x1
    9270:	17fffdb3 	b	893c <fwp_write+0x4cc>
    9274:	f9400a63 	ldr	x3, [x19, #16]
    9278:	8b030021 	add	x1, x1, x3
    927c:	17ffff56 	b	8fd4 <fwp_write+0xb64>
    9280:	b9404840 	ldr	w0, [x2, #72]
    9284:	91001ff5 	add	x21, sp, #0x7
    9288:	34ffa360 	cbz	w0, 86f4 <fwp_write+0x284>
    928c:	52800503 	mov	w3, #0x28                  	// #40
    9290:	aa1403e0 	mov	x0, x20
    9294:	aa1503e1 	mov	x1, x21
    9298:	d2800022 	mov	x2, #0x1                   	// #1
    929c:	39001fe3 	strb	w3, [sp, #7]
    92a0:	97ffe83c 	bl	3390 <buf_put>
    92a4:	b9401380 	ldr	w0, [x28, #16]
    92a8:	52800038 	mov	w24, #0x1                   	// #1
    92ac:	7100001f 	cmp	w0, #0x0
    92b0:	54ffa36c 	b.gt	871c <fwp_write+0x2ac>
    92b4:	17fffd32 	b	877c <fwp_write+0x30c>
    92b8:	f9014bf9 	str	x25, [sp, #656]
    92bc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10dc8>
    92c0:	f9014ffa 	str	x26, [sp, #664]
    92c4:	f9400676 	ldr	x22, [x19, #8]
    92c8:	91102333 	add	x19, x25, #0x408
    92cc:	91002273 	add	x19, x19, #0x8
    92d0:	937ffed8 	asr	x24, x22, #63
    92d4:	aa1802c0 	orr	x0, x22, x24
    92d8:	b5000320 	cbnz	x0, 933c <fwp_write+0xecc>
    92dc:	110006b5 	add	w21, w21, #0x1
    92e0:	710016bf 	cmp	w21, #0x5
    92e4:	54ffffc1 	b.ne	92dc <fwp_write+0xe6c>  // b.any
    92e8:	b7f80578 	tbnz	x24, #63, 9394 <fwp_write+0xf24>
    92ec:	910023f3 	add	x19, sp, #0x8
    92f0:	aa1603e2 	mov	x2, x22
    92f4:	aa1303e0 	mov	x0, x19
    92f8:	d2800003 	mov	x3, #0x0                   	// #0
    92fc:	97ffe6a9 	bl	2da0 <fwp_fmt_u128>
    9300:	910123f5 	add	x21, sp, #0x48
    9304:	d0000003 	adrp	x3, b000 <__modti3+0x180>
    9308:	aa1303e4 	mov	x4, x19
    930c:	aa1503e0 	mov	x0, x21
    9310:	911ea063 	add	x3, x3, #0x7a8
    9314:	d2804002 	mov	x2, #0x200                 	// #512
    9318:	52800041 	mov	w1, #0x2                   	// #2
    931c:	97ffe4dd 	bl	2690 <__sprintf_chk@plt>
    9320:	aa1503e0 	mov	x0, x21
    9324:	97ffe4d7 	bl	2680 <strlen@plt>
    9328:	aa1503e1 	mov	x1, x21
    932c:	aa0003e2 	mov	x2, x0
    9330:	aa1403e0 	mov	x0, x20
    9334:	97ffe817 	bl	3390 <buf_put>
    9338:	17fffe47 	b	8c54 <fwp_write+0x7e4>
    933c:	f9400277 	ldr	x23, [x19]
    9340:	aa1603e0 	mov	x0, x22
    9344:	aa1803e1 	mov	x1, x24
    9348:	aa1703e2 	mov	x2, x23
    934c:	937ffefa 	asr	x26, x23, #63
    9350:	aa1a03e3 	mov	x3, x26
    9354:	940006cb 	bl	ae80 <__modti3>
    9358:	aa010000 	orr	x0, x0, x1
    935c:	b40002c0 	cbz	x0, 93b4 <fwp_write+0xf44>
    9360:	110006b5 	add	w21, w21, #0x1
    9364:	91004273 	add	x19, x19, #0x10
    9368:	710016bf 	cmp	w21, #0x5
    936c:	54fffe81 	b.ne	933c <fwp_write+0xecc>  // b.any
    9370:	17ffffde 	b	92e8 <fwp_write+0xe78>
    9374:	f9400a60 	ldr	x0, [x19, #16]
    9378:	8b000021 	add	x1, x1, x0
    937c:	17fffd75 	b	8950 <fwp_write+0x4e0>
    9380:	528c29c0 	mov	w0, #0x614e                	// #24910
    9384:	910123f5 	add	x21, sp, #0x48
    9388:	72a009c0 	movk	w0, #0x4e, lsl #16
    938c:	b9004be0 	str	w0, [sp, #72]
    9390:	17fffda2 	b	8a18 <fwp_write+0x5a8>
    9394:	528005a1 	mov	w1, #0x2d                  	// #45
    9398:	eb1603e2 	negs	x2, x22
    939c:	da1803e3 	ngc	x3, x24
    93a0:	910027e0 	add	x0, sp, #0x9
    93a4:	910023f3 	add	x19, sp, #0x8
    93a8:	390023e1 	strb	w1, [sp, #8]
    93ac:	97ffe67d 	bl	2da0 <fwp_fmt_u128>
    93b0:	17ffffd4 	b	9300 <fwp_write+0xe90>
    93b4:	aa1703e2 	mov	x2, x23
    93b8:	aa1a03e3 	mov	x3, x26
    93bc:	aa1603e0 	mov	x0, x22
    93c0:	aa1803e1 	mov	x1, x24
    93c4:	940005cf 	bl	ab00 <__divti3>
    93c8:	aa0003e2 	mov	x2, x0
    93cc:	aa0103e3 	mov	x3, x1
    93d0:	b7f80201 	tbnz	x1, #63, 9410 <fwp_write+0xfa0>
    93d4:	910023f3 	add	x19, sp, #0x8
    93d8:	aa1303e0 	mov	x0, x19
    93dc:	97ffe671 	bl	2da0 <fwp_fmt_u128>
    93e0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    93e4:	91102339 	add	x25, x25, #0x408
    93e8:	910123f5 	add	x21, sp, #0x48
    93ec:	aa1303e4 	mov	x4, x19
    93f0:	aa1503e0 	mov	x0, x21
    93f4:	d0000003 	adrp	x3, b000 <__modti3+0x180>
    93f8:	f8616b25 	ldr	x5, [x25, x1]
    93fc:	911e8063 	add	x3, x3, #0x7a0
    9400:	d2804002 	mov	x2, #0x200                 	// #512
    9404:	52800041 	mov	w1, #0x2                   	// #2
    9408:	97ffe4a2 	bl	2690 <__sprintf_chk@plt>
    940c:	17ffffc5 	b	9320 <fwp_write+0xeb0>
    9410:	528005a4 	mov	w4, #0x2d                  	// #45
    9414:	eb0003e2 	negs	x2, x0
    9418:	da0103e3 	ngc	x3, x1
    941c:	910027e0 	add	x0, sp, #0x9
    9420:	910023f3 	add	x19, sp, #0x8
    9424:	390023e4 	strb	w4, [sp, #8]
    9428:	97ffe65e 	bl	2da0 <fwp_fmt_u128>
    942c:	17ffffed 	b	93e0 <fwp_write+0xf70>
    9430:	f9013bf5 	str	x21, [sp, #624]
    9434:	f9013ff6 	str	x22, [sp, #632]
    9438:	f90143f7 	str	x23, [sp, #640]
    943c:	f90147f8 	str	x24, [sp, #648]
    9440:	f9014bf9 	str	x25, [sp, #656]
    9444:	f9014ffa 	str	x26, [sp, #664]
    9448:	f90153fb 	str	x27, [sp, #672]
    944c:	f90157fc 	str	x28, [sp, #680]
    9450:	fd015be8 	str	d8, [sp, #688]
    9454:	fd015fe9 	str	d9, [sp, #696]
    9458:	97ffe4e6 	bl	27f0 <__stack_chk_fail@plt>
    945c:	d503201f 	nop

0000000000009460 <fwp_main_thread>:
    9460:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    9464:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9468:	91154001 	add	x1, x0, #0x550
    946c:	910003fd 	mov	x29, sp
    9470:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9474:	f947f400 	ldr	x0, [x0, #4072]
    9478:	a90153f3 	stp	x19, x20, [sp, #16]
    947c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9480:	a90363f7 	stp	x23, x24, [sp, #48]
    9484:	a9046bf9 	stp	x25, x26, [sp, #64]
    9488:	a90573fb 	stp	x27, x28, [sp, #80]
    948c:	fd0033e8 	str	d8, [sp, #96]
    9490:	d10603ff 	sub	sp, sp, #0x180
    9494:	b953a421 	ldr	w1, [x1, #5028]
    9498:	f9400002 	ldr	x2, [x0]
    949c:	f81f83a2 	stur	x2, [x29, #-8]
    94a0:	d2800002 	mov	x2, #0x0                   	// #0
    94a4:	34002741 	cbz	w1, 998c <fwp_main_thread+0x52c>
    94a8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    94ac:	91154000 	add	x0, x0, #0x550
    94b0:	b953a800 	ldr	w0, [x0, #5032]
    94b4:	35002640 	cbnz	w0, 997c <fwp_main_thread+0x51c>
    94b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    94bc:	f00000a2 	adrp	x2, 20000 <__data_start>
    94c0:	91010019 	add	x25, x0, #0x40
    94c4:	910dc042 	add	x2, x2, #0x370
    94c8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    94cc:	d2a00024 	mov	x4, #0x10000               	// #65536
    94d0:	d10383bb 	sub	x27, x29, #0xe0
    94d4:	d103e3b8 	sub	x24, x29, #0xf8
    94d8:	aa1b03e0 	mov	x0, x27
    94dc:	d2800001 	mov	x1, #0x0                   	// #0
    94e0:	f81203a2 	stur	x2, [x29, #-224]
    94e4:	b81283bf 	stur	wzr, [x29, #-216]
    94e8:	f81303a4 	stur	x4, [x29, #-208]
    94ec:	a9018f38 	stp	x24, x3, [x25, #24]
    94f0:	97ffe458 	bl	2650 <sigaltstack@plt>
    94f4:	3500a4e0 	cbnz	w0, a990 <fwp_main_thread+0x1530>
    94f8:	4f000400 	movi	v0.4s, #0x0
    94fc:	d10263a0 	sub	x0, x29, #0x98
    9500:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9504:	913fc021 	add	x1, x1, #0xff0
    9508:	f81603a1 	stur	x1, [x29, #-160]
    950c:	52800082 	mov	w2, #0x4                   	// #4
    9510:	72a10002 	movk	w2, #0x800, lsl #16
    9514:	d10283b6 	sub	x22, x29, #0xa0
    9518:	3d802000 	str	q0, [x0, #128]
    951c:	b81e83a2 	stur	w2, [x29, #-24]
    9520:	ad000000 	stp	q0, q0, [x0]
    9524:	ad010000 	stp	q0, q0, [x0, #32]
    9528:	ad020000 	stp	q0, q0, [x0, #64]
    952c:	ad030000 	stp	q0, q0, [x0, #96]
    9530:	97ffe4a0 	bl	27b0 <sigemptyset@plt>
    9534:	3500a2e0 	cbnz	w0, a990 <fwp_main_thread+0x1530>
    9538:	aa1603e1 	mov	x1, x22
    953c:	d2800002 	mov	x2, #0x0                   	// #0
    9540:	52800160 	mov	w0, #0xb                   	// #11
    9544:	97ffe4b3 	bl	2810 <sigaction@plt>
    9548:	3500a240 	cbnz	w0, a990 <fwp_main_thread+0x1530>
    954c:	aa1603e1 	mov	x1, x22
    9550:	d2800002 	mov	x2, #0x0                   	// #0
    9554:	528000e0 	mov	w0, #0x7                   	// #7
    9558:	97ffe4ae 	bl	2810 <sigaction@plt>
    955c:	3500a1a0 	cbnz	w0, a990 <fwp_main_thread+0x1530>
    9560:	b942fb20 	ldr	w0, [x25, #760]
    9564:	34002180 	cbz	w0, 9994 <fwp_main_thread+0x534>
    9568:	f00000a0 	adrp	x0, 20000 <__data_start>
    956c:	91010015 	add	x21, x0, #0x40
    9570:	f9400ab4 	ldr	x20, [x21, #16]
    9574:	b4000c54 	cbz	x20, 96fc <fwp_main_thread+0x29c>
    9578:	aa1403f3 	mov	x19, x20
    957c:	91010297 	add	x23, x20, #0x40
    9580:	39414a98 	ldrb	w24, [x20, #82]
    9584:	52800036 	mov	w22, #0x1                   	// #1
    9588:	39014a96 	strb	w22, [x20, #82]
    958c:	f9401680 	ldr	x0, [x20, #40]
    9590:	b4000620 	cbz	x0, 9654 <fwp_main_thread+0x1f4>
    9594:	f9403281 	ldr	x1, [x20, #96]
    9598:	39414680 	ldrb	w0, [x20, #81]
    959c:	b4000e81 	cbz	x1, 976c <fwp_main_thread+0x30c>
    95a0:	36000d40 	tbz	w0, #0, 9748 <fwp_main_thread+0x2e8>
    95a4:	39414a62 	ldrb	w2, [x19, #82]
    95a8:	f9402281 	ldr	x1, [x20, #64]
    95ac:	37001082 	tbnz	w2, #0, 97bc <fwp_main_thread+0x35c>
    95b0:	f9403260 	ldr	x0, [x19, #96]
    95b4:	a911fe77 	stp	x23, xzr, [x19, #280]
    95b8:	f9009661 	str	x1, [x19, #296]
    95bc:	b4000041 	cbz	x1, 95c4 <fwp_main_thread+0x164>
    95c0:	f9009033 	str	x19, [x1, #288]
    95c4:	f9002293 	str	x19, [x20, #64]
    95c8:	b4000100 	cbz	x0, 95e8 <fwp_main_thread+0x188>
    95cc:	f94046a1 	ldr	x1, [x21, #136]
    95d0:	39015676 	strb	w22, [x19, #85]
    95d4:	f9003660 	str	x0, [x19, #104]
    95d8:	a910867f 	stp	xzr, x1, [x19, #264]
    95dc:	b4000041 	cbz	x1, 95e4 <fwp_main_thread+0x184>
    95e0:	f9008433 	str	x19, [x1, #264]
    95e4:	f90046b3 	str	x19, [x21, #136]
    95e8:	39015a7f 	strb	wzr, [x19, #86]
    95ec:	97fff286 	bl	6004 <fwp_block>
    95f0:	f9408e62 	ldr	x2, [x19, #280]
    95f4:	b4000142 	cbz	x2, 961c <fwp_main_thread+0x1bc>
    95f8:	a9520261 	ldp	x1, x0, [x19, #288]
    95fc:	b4000ec1 	cbz	x1, 97d4 <fwp_main_thread+0x374>
    9600:	f9009420 	str	x0, [x1, #296]
    9604:	f9409660 	ldr	x0, [x19, #296]
    9608:	b4000040 	cbz	x0, 9610 <fwp_main_thread+0x1b0>
    960c:	f9009001 	str	x1, [x0, #288]
    9610:	91080260 	add	x0, x19, #0x200
    9614:	f900967f 	str	xzr, [x19, #296]
    9618:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    961c:	39415660 	ldrb	w0, [x19, #85]
    9620:	f9400aa1 	ldr	x1, [x21, #16]
    9624:	36000c80 	tbz	w0, #0, 97b4 <fwp_main_thread+0x354>
    9628:	a9508262 	ldp	x2, x0, [x19, #264]
    962c:	b4000d82 	cbz	x2, 97dc <fwp_main_thread+0x37c>
    9630:	f9008840 	str	x0, [x2, #272]
    9634:	b4000040 	cbz	x0, 963c <fwp_main_thread+0x1dc>
    9638:	f9008402 	str	x2, [x0, #264]
    963c:	91080260 	add	x0, x19, #0x200
    9640:	3901567f 	strb	wzr, [x19, #85]
    9644:	aa0103f3 	mov	x19, x1
    9648:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    964c:	f9401680 	ldr	x0, [x20, #40]
    9650:	b5fffa20 	cbnz	x0, 9594 <fwp_main_thread+0x134>
    9654:	f00000a0 	adrp	x0, 20000 <__data_start>
    9658:	91010000 	add	x0, x0, #0x40
    965c:	39014a98 	strb	w24, [x20, #82]
    9660:	f9416c00 	ldr	x0, [x0, #728]
    9664:	b4000520 	cbz	x0, 9708 <fwp_main_thread+0x2a8>
    9668:	f00000a0 	adrp	x0, 20000 <__data_start>
    966c:	91010000 	add	x0, x0, #0x40
    9670:	f9418801 	ldr	x1, [x0, #784]
    9674:	b903081f 	str	wzr, [x0, #776]
    9678:	eb13003f 	cmp	x1, x19
    967c:	54000641 	b.ne	9744 <fwp_main_thread+0x2e4>  // b.any
    9680:	b4000bd3 	cbz	x19, 97f8 <fwp_main_thread+0x398>
    9684:	f00000a0 	adrp	x0, 20000 <__data_start>
    9688:	91010000 	add	x0, x0, #0x40
    968c:	52800021 	mov	w1, #0x1                   	// #1
    9690:	39014a61 	strb	w1, [x19, #82]
    9694:	f9415805 	ldr	x5, [x0, #688]
    9698:	b4000b05 	cbz	x5, 97f8 <fwp_main_thread+0x398>
    969c:	394140a0 	ldrb	w0, [x5, #80]
    96a0:	37000060 	tbnz	w0, #0, 96ac <fwp_main_thread+0x24c>
    96a4:	aa0503e0 	mov	x0, x5
    96a8:	97ffe752 	bl	33f0 <fwp_cancel_tree.part.0>
    96ac:	f9409ca5 	ldr	x5, [x5, #312]
    96b0:	b5ffff65 	cbnz	x5, 969c <fwp_main_thread+0x23c>
    96b4:	f00000a0 	adrp	x0, 20000 <__data_start>
    96b8:	91010014 	add	x20, x0, #0x40
    96bc:	52800035 	mov	w21, #0x1                   	// #1
    96c0:	f9402a60 	ldr	x0, [x19, #80]
    96c4:	f2001c1f 	tst	x0, #0xff000000ff
    96c8:	540000e1 	b.ne	96e4 <fwp_main_thread+0x284>  // b.any
    96cc:	f9401680 	ldr	x0, [x20, #40]
    96d0:	39015275 	strb	w21, [x19, #84]
    96d4:	f900827f 	str	xzr, [x19, #256]
    96d8:	b4000860 	cbz	x0, 97e4 <fwp_main_thread+0x384>
    96dc:	f9008013 	str	x19, [x0, #256]
    96e0:	f9001693 	str	x19, [x20, #40]
    96e4:	97fff248 	bl	6004 <fwp_block>
    96e8:	97fff1da 	bl	5e50 <fwp_free_zombie>
    96ec:	f9415a80 	ldr	x0, [x20, #688]
    96f0:	b4000840 	cbz	x0, 97f8 <fwp_main_thread+0x398>
    96f4:	f9418a93 	ldr	x19, [x20, #784]
    96f8:	17fffff2 	b	96c0 <fwp_main_thread+0x260>
    96fc:	f9416ea0 	ldr	x0, [x21, #728]
    9700:	b5000760 	cbnz	x0, 97ec <fwp_main_thread+0x38c>
    9704:	d2800013 	mov	x19, #0x0                   	// #0
    9708:	f00000a0 	adrp	x0, 20000 <__data_start>
    970c:	91010014 	add	x20, x0, #0x40
    9710:	f9417680 	ldr	x0, [x20, #744]
    9714:	b5fffaa0 	cbnz	x0, 9668 <fwp_main_thread+0x208>
    9718:	f9416a80 	ldr	x0, [x20, #720]
    971c:	97ffec15 	bl	4770 <fwp_mem_free>
    9720:	f9016a9f 	str	xzr, [x20, #720]
    9724:	f901729f 	str	xzr, [x20, #736]
    9728:	f9418a80 	ldr	x0, [x20, #784]
    972c:	b4009cb3 	cbz	x19, aac0 <fwp_main_thread+0x1660>
    9730:	f900567f 	str	xzr, [x19, #168]
    9734:	f9005e7f 	str	xzr, [x19, #184]
    9738:	b9030a9f 	str	wzr, [x20, #776]
    973c:	eb00027f 	cmp	x19, x0
    9740:	54fffa20 	b.eq	9684 <fwp_main_thread+0x224>  // b.none
    9744:	97ffe43f 	bl	2840 <abort@plt>
    9748:	97ffe7ce 	bl	3680 <fwp_now_ns>
    974c:	f9403281 	ldr	x1, [x20, #96]
    9750:	eb01001f 	cmp	x0, x1
    9754:	540000ab 	b.lt	9768 <fwp_main_thread+0x308>  // b.tstop
    9758:	39414280 	ldrb	w0, [x20, #80]
    975c:	37000060 	tbnz	w0, #0, 9768 <fwp_main_thread+0x308>
    9760:	aa1403e0 	mov	x0, x20
    9764:	97ffe723 	bl	33f0 <fwp_cancel_tree.part.0>
    9768:	39414680 	ldrb	w0, [x20, #81]
    976c:	39414a62 	ldrb	w2, [x19, #82]
    9770:	3707f1c0 	tbnz	w0, #0, 95a8 <fwp_main_thread+0x148>
    9774:	f9403280 	ldr	x0, [x20, #96]
    9778:	370001a2 	tbnz	w2, #0, 97ac <fwp_main_thread+0x34c>
    977c:	f9403261 	ldr	x1, [x19, #96]
    9780:	b4000161 	cbz	x1, 97ac <fwp_main_thread+0x34c>
    9784:	b4008ca0 	cbz	x0, a918 <fwp_main_thread+0x14b8>
    9788:	eb01001f 	cmp	x0, x1
    978c:	9a81d000 	csel	x0, x0, x1, le
    9790:	f9402281 	ldr	x1, [x20, #64]
    9794:	a911fe77 	stp	x23, xzr, [x19, #280]
    9798:	f9009661 	str	x1, [x19, #296]
    979c:	b4000041 	cbz	x1, 97a4 <fwp_main_thread+0x344>
    97a0:	f9009033 	str	x19, [x1, #288]
    97a4:	f9002293 	str	x19, [x20, #64]
    97a8:	17ffff89 	b	95cc <fwp_main_thread+0x16c>
    97ac:	f9402281 	ldr	x1, [x20, #64]
    97b0:	17ffff81 	b	95b4 <fwp_main_thread+0x154>
    97b4:	aa0103f3 	mov	x19, x1
    97b8:	17ffff75 	b	958c <fwp_main_thread+0x12c>
    97bc:	a911fe77 	stp	x23, xzr, [x19, #280]
    97c0:	f9009661 	str	x1, [x19, #296]
    97c4:	b4000041 	cbz	x1, 97cc <fwp_main_thread+0x36c>
    97c8:	f9009033 	str	x19, [x1, #288]
    97cc:	f9002293 	str	x19, [x20, #64]
    97d0:	17ffff86 	b	95e8 <fwp_main_thread+0x188>
    97d4:	f9000040 	str	x0, [x2]
    97d8:	17ffff8c 	b	9608 <fwp_main_thread+0x1a8>
    97dc:	f90046a0 	str	x0, [x21, #136]
    97e0:	17ffff95 	b	9634 <fwp_main_thread+0x1d4>
    97e4:	f9001a93 	str	x19, [x20, #48]
    97e8:	17ffffbe 	b	96e0 <fwp_main_thread+0x280>
    97ec:	f9418aa0 	ldr	x0, [x21, #784]
    97f0:	b9030abf 	str	wzr, [x21, #776]
    97f4:	b5fffa80 	cbnz	x0, 9744 <fwp_main_thread+0x2e4>
    97f8:	97fff196 	bl	5e50 <fwp_free_zombie>
    97fc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9800:	91010015 	add	x21, x0, #0x40
    9804:	f9401aa0 	ldr	x0, [x21, #48]
    9808:	b5fff9e0 	cbnz	x0, 9744 <fwp_main_thread+0x2e4>
    980c:	f94046a0 	ldr	x0, [x21, #136]
    9810:	b5fff9a0 	cbnz	x0, 9744 <fwp_main_thread+0x2e4>
    9814:	b940aaa0 	ldr	w0, [x21, #168]
    9818:	340001c0 	cbz	w0, 9850 <fwp_main_thread+0x3f0>
    981c:	93407c14 	sxtw	x20, w0
    9820:	51000400 	sub	w0, w0, #0x1
    9824:	d1000a94 	sub	x20, x20, #0x2
    9828:	9102c2b6 	add	x22, x21, #0xb0
    982c:	cb204294 	sub	x20, x20, w0, uxtw
    9830:	93407c13 	sxtw	x19, w0
    9834:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9838:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    983c:	b900aab3 	str	w19, [x21, #168]
    9840:	d1000673 	sub	x19, x19, #0x1
    9844:	97ffe433 	bl	2910 <munmap@plt>
    9848:	eb14027f 	cmp	x19, x20
    984c:	54ffff41 	b.ne	9834 <fwp_main_thread+0x3d4>  // b.any
    9850:	f00000a5 	adrp	x5, 20000 <__data_start>
    9854:	910040a0 	add	x0, x5, #0x10
    9858:	b9401000 	ldr	w0, [x0, #16]
    985c:	37f800c0 	tbnz	w0, #31, 9874 <fwp_main_thread+0x414>
    9860:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9864:	f91f7c25 	str	x5, [x1, #16120]
    9868:	97ffe3e6 	bl	2800 <close@plt>
    986c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9870:	f95f7c05 	ldr	x5, [x0, #16120]
    9874:	f00000a0 	adrp	x0, 20000 <__data_start>
    9878:	91010000 	add	x0, x0, #0x40
    987c:	910040a5 	add	x5, x5, #0x10
    9880:	12800001 	mov	w1, #0xffffffff            	// #-1
    9884:	d2800013 	mov	x19, #0x0                   	// #0
    9888:	f9418c15 	ldr	x21, [x0, #792]
    988c:	b90010a1 	str	w1, [x5, #16]
    9890:	f9419014 	ldr	x20, [x0, #800]
    9894:	b4000175 	cbz	x21, 98c0 <fwp_main_thread+0x460>
    9898:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    989c:	b40000c0 	cbz	x0, 98b4 <fwp_main_thread+0x454>
    98a0:	f9400001 	ldr	x1, [x0]
    98a4:	b5fff501 	cbnz	x1, 9744 <fwp_main_thread+0x2e4>
    98a8:	f9400401 	ldr	x1, [x0, #8]
    98ac:	b5fff4c1 	cbnz	x1, 9744 <fwp_main_thread+0x2e4>
    98b0:	97ffebb0 	bl	4770 <fwp_mem_free>
    98b4:	91000673 	add	x19, x19, #0x1
    98b8:	eb1302bf 	cmp	x21, x19
    98bc:	54fffee1 	b.ne	9898 <fwp_main_thread+0x438>  // b.any
    98c0:	aa1403e0 	mov	x0, x20
    98c4:	97ffebab 	bl	4770 <fwp_mem_free>
    98c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98cc:	91010000 	add	x0, x0, #0x40
    98d0:	f9418813 	ldr	x19, [x0, #784]
    98d4:	f9018c1f 	str	xzr, [x0, #792]
    98d8:	f901901f 	str	xzr, [x0, #800]
    98dc:	b40001f3 	cbz	x19, 9918 <fwp_main_thread+0x4b8>
    98e0:	f9401661 	ldr	x1, [x19, #40]
    98e4:	b5fff301 	cbnz	x1, 9744 <fwp_main_thread+0x2e4>
    98e8:	f9405661 	ldr	x1, [x19, #168]
    98ec:	b5fff2c1 	cbnz	x1, 9744 <fwp_main_thread+0x2e4>
    98f0:	f9416c01 	ldr	x1, [x0, #728]
    98f4:	b5fff281 	cbnz	x1, 9744 <fwp_main_thread+0x2e4>
    98f8:	f9417400 	ldr	x0, [x0, #744]
    98fc:	b5fff240 	cbnz	x0, 9744 <fwp_main_thread+0x2e4>
    9900:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9904:	f0000120 	adrp	x0, 30000 <alt.5+0xfc90>
    9908:	910dc000 	add	x0, x0, #0x370
    990c:	97ffe3ad 	bl	27c0 <memset@plt>
    9910:	aa1303e0 	mov	x0, x19
    9914:	97ffeb97 	bl	4770 <fwp_mem_free>
    9918:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    991c:	f947ec00 	ldr	x0, [x0, #4056]
    9920:	f00000a1 	adrp	x1, 20000 <__data_start>
    9924:	91010021 	add	x1, x1, #0x40
    9928:	f9400000 	ldr	x0, [x0]
    992c:	f900083f 	str	xzr, [x1, #16]
    9930:	f901883f 	str	xzr, [x1, #784]
    9934:	97ffe3fb 	bl	2920 <fflush@plt>
    9938:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    993c:	f947f400 	ldr	x0, [x0, #4072]
    9940:	f85f83a2 	ldur	x2, [x29, #-8]
    9944:	f9400001 	ldr	x1, [x0]
    9948:	eb010042 	subs	x2, x2, x1
    994c:	d2800001 	mov	x1, #0x0                   	// #0
    9950:	54008261 	b.ne	a99c <fwp_main_thread+0x153c>  // b.any
    9954:	910003bf 	mov	sp, x29
    9958:	d2800000 	mov	x0, #0x0                   	// #0
    995c:	a94153f3 	ldp	x19, x20, [sp, #16]
    9960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9964:	a94363f7 	ldp	x23, x24, [sp, #48]
    9968:	a9446bf9 	ldp	x25, x26, [sp, #64]
    996c:	a94573fb 	ldp	x27, x28, [sp, #80]
    9970:	fd4033e8 	ldr	d8, [sp, #96]
    9974:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9978:	d65f03c0 	ret
    997c:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9980:	91328000 	add	x0, x0, #0xca0
    9984:	9400061b 	bl	b1f0 <atexit>
    9988:	17fffecc 	b	94b8 <fwp_main_thread+0x58>
    998c:	97ffe91e 	bl	3e04 <fwp_heap_init>
    9990:	17fffec6 	b	94a8 <fwp_main_thread+0x48>
    9994:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9998:	91154013 	add	x19, x0, #0x550
    999c:	d0000000 	adrp	x0, b000 <__modti3+0x180>
    99a0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    99a4:	f9416322 	ldr	x2, [x25, #704]
    99a8:	913b4021 	add	x1, x1, #0xed0
    99ac:	fd476808 	ldr	d8, [x0, #3792]
    99b0:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    99b4:	91175000 	add	x0, x0, #0x5d4
    99b8:	a93303bf 	stp	xzr, x0, [x29, #-208]
    99bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    99c0:	d2800015 	mov	x21, #0x0                   	// #0
    99c4:	d280401a 	mov	x26, #0x200                 	// #512
    99c8:	d2800014 	mov	x20, #0x0                   	// #0
    99cc:	52800037 	mov	w23, #0x1                   	// #1
    99d0:	a93087a2 	stp	x2, x1, [x29, #-248]
    99d4:	a931ffbb 	stp	x27, xzr, [x29, #-232]
    99d8:	f9016338 	str	x24, [x25, #704]
    99dc:	f91f7816 	str	x22, [x0, #16112]
    99e0:	f91f7c1b 	str	x27, [x0, #16120]
    99e4:	b953a660 	ldr	w0, [x19, #5028]
    99e8:	f1000759 	subs	x25, x26, #0x1
    99ec:	f81283b9 	stur	x25, [x29, #-216]
    99f0:	da1f0296 	sbc	x22, x20, xzr
    99f4:	aa1903fa 	mov	x26, x25
    99f8:	aa1603f4 	mov	x20, x22
    99fc:	34003b20 	cbz	w0, a160 <fwp_main_thread+0xd00>
    9a00:	397e8a60 	ldrb	w0, [x19, #4002]
    9a04:	910f0001 	add	x1, x0, #0x3c0
    9a08:	8b000400 	add	x0, x0, x0, lsl #1
    9a0c:	b8617a7b 	ldr	w27, [x19, x1, lsl #2]
    9a10:	8b000e61 	add	x1, x19, x0, lsl #3
    9a14:	f8607a78 	ldr	x24, [x19, x0, lsl #3]
    9a18:	2a1b03fc 	mov	w28, w27
    9a1c:	b4003918 	cbz	x24, a13c <fwp_main_thread+0xcdc>
    9a20:	f9400301 	ldr	x1, [x24]
    9a24:	aa2103e1 	mvn	x1, x1
    9a28:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9a2c:	f100639f 	cmp	x28, #0x18
    9a30:	540000e9 	b.ls	9a4c <fwp_main_thread+0x5ec>  // b.plast
    9a34:	d1006782 	sub	x2, x28, #0x19
    9a38:	91006300 	add	x0, x24, #0x18
    9a3c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9a40:	52800001 	mov	w1, #0x0                   	// #0
    9a44:	91002042 	add	x2, x2, #0x8
    9a48:	97ffe35e 	bl	27c0 <memset@plt>
    9a4c:	f94a1260 	ldr	x0, [x19, #5152]
    9a50:	ab1c0000 	adds	x0, x0, x28
    9a54:	540079c2 	b.cs	a98c <fwp_main_thread+0x152c>  // b.hs, b.nlast
    9a58:	f94a1661 	ldr	x1, [x19, #5160]
    9a5c:	f90a1260 	str	x0, [x19, #5152]
    9a60:	eb01001f 	cmp	x0, x1
    9a64:	54000049 	b.ls	9a6c <fwp_main_thread+0x60c>  // b.plast
    9a68:	f90a1660 	str	x0, [x19, #5160]
    9a6c:	1e630361 	ucvtf	d1, w27
    9a70:	fd4a1e60 	ldr	d0, [x19, #5176]
    9a74:	1e612800 	fadd	d0, d0, d1
    9a78:	fd0a1e60 	str	d0, [x19, #5176]
    9a7c:	a900d719 	stp	x25, x21, [x24, #8]
    9a80:	aa1803f5 	mov	x21, x24
    9a84:	fd000308 	str	d8, [x24]
    9a88:	f949da62 	ldr	x2, [x19, #5040]
    9a8c:	f949ee60 	ldr	x0, [x19, #5080]
    9a90:	cb020302 	sub	x2, x24, x2
    9a94:	eb00405f 	cmp	x2, x0, lsl #16
    9a98:	54000302 	b.cs	9af8 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9a9c:	d350fc40 	lsr	x0, x2, #16
    9aa0:	f949fe64 	ldr	x4, [x19, #5112]
    9aa4:	8b000800 	add	x0, x0, x0, lsl #2
    9aa8:	d37df001 	lsl	x1, x0, #3
    9aac:	8b010080 	add	x0, x4, x1
    9ab0:	f940101c 	ldr	x28, [x0, #32]
    9ab4:	b400023c 	cbz	x28, 9af8 <fwp_main_thread+0x698>
    9ab8:	38616881 	ldrb	w1, [x4, x1]
    9abc:	7100083f 	cmp	w1, #0x2
    9ac0:	540035a0 	b.eq	a174 <fwp_main_thread+0xd14>  // b.none
    9ac4:	7100043f 	cmp	w1, #0x1
    9ac8:	54000181 	b.ne	9af8 <fwp_main_thread+0x698>  // b.any
    9acc:	29430004 	ldp	w4, w0, [x0, #24]
    9ad0:	92403c41 	and	x1, x2, #0xffff
    9ad4:	9b047c21 	mul	x1, x1, x4
    9ad8:	d360fc21 	lsr	x1, x1, #32
    9adc:	eb00003f 	cmp	x1, x0
    9ae0:	540000c2 	b.cs	9af8 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9ae4:	8b01039c 	add	x28, x28, x1
    9ae8:	39400380 	ldrb	w0, [x28]
    9aec:	7103fc1f 	cmp	w0, #0xff
    9af0:	540034c0 	b.eq	a188 <fwp_main_thread+0xd28>  // b.none
    9af4:	39000397 	strb	w23, [x28]
    9af8:	f81203b8 	stur	x24, [x29, #-224]
    9afc:	aa160339 	orr	x25, x25, x22
    9b00:	b5fff739 	cbnz	x25, 99e4 <fwp_main_thread+0x584>
    9b04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b08:	d10303a1 	sub	x1, x29, #0xc0
    9b0c:	f85083a3 	ldur	x3, [x29, #-248]
    9b10:	f95f7816 	ldr	x22, [x0, #16112]
    9b14:	f91f7418 	str	x24, [x0, #16104]
    9b18:	f95f7c1b 	ldr	x27, [x0, #16120]
    9b1c:	d0000000 	adrp	x0, b000 <__modti3+0x180>
    9b20:	3dc3b800 	ldr	q0, [x0, #3808]
    9b24:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b28:	91010002 	add	x2, x0, #0x40
    9b2c:	52800020 	mov	w0, #0x1                   	// #1
    9b30:	3c9403a0 	stur	q0, [x29, #-192]
    9b34:	f9016043 	str	x3, [x2, #704]
    9b38:	97ffedf2 	bl	5300 <fwp_data.part.0.constprop.0>
    9b3c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9b40:	91154022 	add	x2, x1, #0x550
    9b44:	aa0003f4 	mov	x20, x0
    9b48:	f949d841 	ldr	x1, [x2, #5040]
    9b4c:	f949ec40 	ldr	x0, [x2, #5080]
    9b50:	cb010281 	sub	x1, x20, x1
    9b54:	eb00403f 	cmp	x1, x0, lsl #16
    9b58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b5c:	f95f7406 	ldr	x6, [x0, #16104]
    9b60:	54000322 	b.cs	9bc4 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9b64:	d350fc20 	lsr	x0, x1, #16
    9b68:	f949fc43 	ldr	x3, [x2, #5112]
    9b6c:	8b000800 	add	x0, x0, x0, lsl #2
    9b70:	d37df002 	lsl	x2, x0, #3
    9b74:	8b020060 	add	x0, x3, x2
    9b78:	f9401013 	ldr	x19, [x0, #32]
    9b7c:	b4000253 	cbz	x19, 9bc4 <fwp_main_thread+0x764>
    9b80:	38626862 	ldrb	w2, [x3, x2]
    9b84:	7100085f 	cmp	w2, #0x2
    9b88:	54006b60 	b.eq	a8f4 <fwp_main_thread+0x1494>  // b.none
    9b8c:	7100045f 	cmp	w2, #0x1
    9b90:	540001a1 	b.ne	9bc4 <fwp_main_thread+0x764>  // b.any
    9b94:	29430002 	ldp	w2, w0, [x0, #24]
    9b98:	92403c21 	and	x1, x1, #0xffff
    9b9c:	9b027c21 	mul	x1, x1, x2
    9ba0:	d360fc21 	lsr	x1, x1, #32
    9ba4:	eb00003f 	cmp	x1, x0
    9ba8:	540000e2 	b.cs	9bc4 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9bac:	8b010273 	add	x19, x19, x1
    9bb0:	39400260 	ldrb	w0, [x19]
    9bb4:	7103fc1f 	cmp	w0, #0xff
    9bb8:	54006b40 	b.eq	a920 <fwp_main_thread+0x14c0>  // b.none
    9bbc:	52800020 	mov	w0, #0x1                   	// #1
    9bc0:	39000260 	strb	w0, [x19]
    9bc4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9bc8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9bcc:	aa1603e1 	mov	x1, x22
    9bd0:	a93653a2 	stp	x2, x20, [x29, #-160]
    9bd4:	f91f7c06 	str	x6, [x0, #16120]
    9bd8:	52800020 	mov	w0, #0x1                   	// #1
    9bdc:	97ffedc9 	bl	5300 <fwp_data.part.0.constprop.0>
    9be0:	aa0003f4 	mov	x20, x0
    9be4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9be8:	91154022 	add	x2, x1, #0x550
    9bec:	f949d841 	ldr	x1, [x2, #5040]
    9bf0:	f949ec40 	ldr	x0, [x2, #5080]
    9bf4:	cb010281 	sub	x1, x20, x1
    9bf8:	eb00403f 	cmp	x1, x0, lsl #16
    9bfc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c00:	f95f7c06 	ldr	x6, [x0, #16120]
    9c04:	54000322 	b.cs	9c68 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9c08:	d350fc20 	lsr	x0, x1, #16
    9c0c:	f949fc43 	ldr	x3, [x2, #5112]
    9c10:	8b000800 	add	x0, x0, x0, lsl #2
    9c14:	d37df002 	lsl	x2, x0, #3
    9c18:	8b020060 	add	x0, x3, x2
    9c1c:	f9401013 	ldr	x19, [x0, #32]
    9c20:	b4000253 	cbz	x19, 9c68 <fwp_main_thread+0x808>
    9c24:	38626862 	ldrb	w2, [x3, x2]
    9c28:	7100085f 	cmp	w2, #0x2
    9c2c:	540065e0 	b.eq	a8e8 <fwp_main_thread+0x1488>  // b.none
    9c30:	7100045f 	cmp	w2, #0x1
    9c34:	540001a1 	b.ne	9c68 <fwp_main_thread+0x808>  // b.any
    9c38:	29430002 	ldp	w2, w0, [x0, #24]
    9c3c:	92403c21 	and	x1, x1, #0xffff
    9c40:	9b027c21 	mul	x1, x1, x2
    9c44:	d360fc21 	lsr	x1, x1, #32
    9c48:	eb00003f 	cmp	x1, x0
    9c4c:	540000e2 	b.cs	9c68 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9c50:	8b010273 	add	x19, x19, x1
    9c54:	39400260 	ldrb	w0, [x19]
    9c58:	7103fc1f 	cmp	w0, #0xff
    9c5c:	540067c0 	b.eq	a954 <fwp_main_thread+0x14f4>  // b.none
    9c60:	52800020 	mov	w0, #0x1                   	// #1
    9c64:	39000260 	strb	w0, [x19]
    9c68:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c6c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9c70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9c74:	d102c3a1 	sub	x1, x29, #0xb0
    9c78:	a93553a2 	stp	x2, x20, [x29, #-176]
    9c7c:	f91f7c06 	str	x6, [x0, #16120]
    9c80:	52800020 	mov	w0, #0x1                   	// #1
    9c84:	97ffed9f 	bl	5300 <fwp_data.part.0.constprop.0>
    9c88:	aa0003f6 	mov	x22, x0
    9c8c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9c90:	91154023 	add	x3, x1, #0x550
    9c94:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c98:	f949ec62 	ldr	x2, [x3, #5080]
    9c9c:	f949d861 	ldr	x1, [x3, #5040]
    9ca0:	d370bc42 	lsl	x2, x2, #16
    9ca4:	cb0102c1 	sub	x1, x22, x1
    9ca8:	f95f7c06 	ldr	x6, [x0, #16120]
    9cac:	eb02003f 	cmp	x1, x2
    9cb0:	540003e2 	b.cs	9d2c <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9cb4:	d350fc20 	lsr	x0, x1, #16
    9cb8:	f949fc64 	ldr	x4, [x3, #5112]
    9cbc:	8b000800 	add	x0, x0, x0, lsl #2
    9cc0:	d37df003 	lsl	x3, x0, #3
    9cc4:	8b030080 	add	x0, x4, x3
    9cc8:	f9401013 	ldr	x19, [x0, #32]
    9ccc:	b4000313 	cbz	x19, 9d2c <fwp_main_thread+0x8cc>
    9cd0:	38636883 	ldrb	w3, [x4, x3]
    9cd4:	7100087f 	cmp	w3, #0x2
    9cd8:	540061a0 	b.eq	a90c <fwp_main_thread+0x14ac>  // b.none
    9cdc:	7100047f 	cmp	w3, #0x1
    9ce0:	54000261 	b.ne	9d2c <fwp_main_thread+0x8cc>  // b.any
    9ce4:	29430004 	ldp	w4, w0, [x0, #24]
    9ce8:	92403c23 	and	x3, x1, #0xffff
    9cec:	9b047c63 	mul	x3, x3, x4
    9cf0:	d360fc63 	lsr	x3, x3, #32
    9cf4:	eb00007f 	cmp	x3, x0
    9cf8:	540001a2 	b.cs	9d2c <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9cfc:	8b030273 	add	x19, x19, x3
    9d00:	39400260 	ldrb	w0, [x19]
    9d04:	7103fc1f 	cmp	w0, #0xff
    9d08:	54006340 	b.eq	a970 <fwp_main_thread+0x1510>  // b.none
    9d0c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9d10:	91154000 	add	x0, x0, #0x550
    9d14:	52800021 	mov	w1, #0x1                   	// #1
    9d18:	39000261 	strb	w1, [x19]
    9d1c:	f949ec02 	ldr	x2, [x0, #5080]
    9d20:	f949d801 	ldr	x1, [x0, #5040]
    9d24:	d370bc42 	lsl	x2, x2, #16
    9d28:	cb0102c1 	sub	x1, x22, x1
    9d2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d30:	f00000a5 	adrp	x5, 20000 <__data_start>
    9d34:	910040b7 	add	x23, x5, #0x10
    9d38:	d10403b3 	sub	x19, x29, #0x100
    9d3c:	910022f7 	add	x23, x23, #0x8
    9d40:	f91f5406 	str	x6, [x0, #16040]
    9d44:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d48:	9101001c 	add	x28, x0, #0x40
    9d4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d50:	f91f4c06 	str	x6, [x0, #16024]
    9d54:	aa1703e6 	mov	x6, x23
    9d58:	f91f5005 	str	x5, [x0, #16032]
    9d5c:	f91f581b 	str	x27, [x0, #16048]
    9d60:	f91f5c16 	str	x22, [x0, #16056]
    9d64:	eb02003f 	cmp	x1, x2
    9d68:	54000382 	b.cs	9dd8 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9d6c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9d70:	91154002 	add	x2, x0, #0x550
    9d74:	d350fc20 	lsr	x0, x1, #16
    9d78:	f949fc44 	ldr	x4, [x2, #5112]
    9d7c:	8b000800 	add	x0, x0, x0, lsl #2
    9d80:	d37df002 	lsl	x2, x0, #3
    9d84:	8b020083 	add	x3, x4, x2
    9d88:	f9401060 	ldr	x0, [x3, #32]
    9d8c:	b4000260 	cbz	x0, 9dd8 <fwp_main_thread+0x978>
    9d90:	38626882 	ldrb	w2, [x4, x2]
    9d94:	7100085f 	cmp	w2, #0x2
    9d98:	54005b40 	b.eq	a900 <fwp_main_thread+0x14a0>  // b.none
    9d9c:	7100045f 	cmp	w2, #0x1
    9da0:	540001c1 	b.ne	9dd8 <fwp_main_thread+0x978>  // b.any
    9da4:	29430864 	ldp	w4, w2, [x3, #24]
    9da8:	92403c21 	and	x1, x1, #0xffff
    9dac:	9b047c21 	mul	x1, x1, x4
    9db0:	d360fc21 	lsr	x1, x1, #32
    9db4:	eb02003f 	cmp	x1, x2
    9db8:	54000102 	b.cs	9dd8 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9dbc:	8b010000 	add	x0, x0, x1
    9dc0:	39400001 	ldrb	w1, [x0]
    9dc4:	340000a1 	cbz	w1, 9dd8 <fwp_main_thread+0x978>
    9dc8:	7103f43f 	cmp	w1, #0xfd
    9dcc:	54005b88 	b.hi	a93c <fwp_main_thread+0x14dc>  // b.pmore
    9dd0:	11000421 	add	w1, w1, #0x1
    9dd4:	39000001 	strb	w1, [x0]
    9dd8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ddc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9de0:	f9401f83 	ldr	x3, [x28, #56]
    9de4:	f95f5000 	ldr	x0, [x0, #16032]
    9de8:	f95f5c21 	ldr	x1, [x1, #16056]
    9dec:	91004000 	add	x0, x0, #0x10
    9df0:	f81003a1 	stur	x1, [x29, #-256]
    9df4:	91002004 	add	x4, x0, #0x8
    9df8:	b9400801 	ldr	w1, [x0, #8]
    9dfc:	d37be821 	lsl	x1, x1, #5
    9e00:	8b010065 	add	x5, x3, x1
    9e04:	f9400ca2 	ldr	x2, [x5, #24]
    9e08:	b4005cc2 	cbz	x2, a9a0 <fwp_main_thread+0x1540>
    9e0c:	f9400c40 	ldr	x0, [x2, #24]
    9e10:	b4004880 	cbz	x0, a720 <fwp_main_thread+0x12c0>
    9e14:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9e18:	91154002 	add	x2, x0, #0x550
    9e1c:	f949d841 	ldr	x1, [x2, #5040]
    9e20:	f949ec40 	ldr	x0, [x2, #5080]
    9e24:	cb0100c1 	sub	x1, x6, x1
    9e28:	eb00403f 	cmp	x1, x0, lsl #16
    9e2c:	54000342 	b.cs	9e94 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9e30:	d350fc20 	lsr	x0, x1, #16
    9e34:	f949fc44 	ldr	x4, [x2, #5112]
    9e38:	8b000800 	add	x0, x0, x0, lsl #2
    9e3c:	d37df002 	lsl	x2, x0, #3
    9e40:	8b020083 	add	x3, x4, x2
    9e44:	f9401060 	ldr	x0, [x3, #32]
    9e48:	b4000260 	cbz	x0, 9e94 <fwp_main_thread+0xa34>
    9e4c:	38626882 	ldrb	w2, [x4, x2]
    9e50:	7100085f 	cmp	w2, #0x2
    9e54:	54004dc0 	b.eq	a80c <fwp_main_thread+0x13ac>  // b.none
    9e58:	7100045f 	cmp	w2, #0x1
    9e5c:	540001c1 	b.ne	9e94 <fwp_main_thread+0xa34>  // b.any
    9e60:	29430864 	ldp	w4, w2, [x3, #24]
    9e64:	92403c21 	and	x1, x1, #0xffff
    9e68:	9b047c21 	mul	x1, x1, x4
    9e6c:	d360fc21 	lsr	x1, x1, #32
    9e70:	eb02003f 	cmp	x1, x2
    9e74:	54000102 	b.cs	9e94 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9e78:	8b010000 	add	x0, x0, x1
    9e7c:	39400001 	ldrb	w1, [x0]
    9e80:	340000a1 	cbz	w1, 9e94 <fwp_main_thread+0xa34>
    9e84:	7103f43f 	cmp	w1, #0xfd
    9e88:	540050c8 	b.hi	a8a0 <fwp_main_thread+0x1440>  // b.pmore
    9e8c:	11000421 	add	w1, w1, #0x1
    9e90:	39000001 	strb	w1, [x0]
    9e94:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9e98:	91154035 	add	x21, x1, #0x550
    9e9c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9ea0:	aa0603f8 	mov	x24, x6
    9ea4:	aa1303fb 	mov	x27, x19
    9ea8:	aa0603e0 	mov	x0, x6
    9eac:	52800034 	mov	w20, #0x1                   	// #1
    9eb0:	f91f6033 	str	x19, [x1, #16064]
    9eb4:	f91f6426 	str	x6, [x1, #16072]
    9eb8:	b93ee834 	str	w20, [x1, #16104]
    9ebc:	b93ef034 	str	w20, [x1, #16112]
    9ec0:	b94000a2 	ldr	w2, [x5]
    9ec4:	b9400401 	ldr	w1, [x0, #4]
    9ec8:	4b010040 	sub	w0, w2, w1
    9ecc:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    9ed0:	b93ee440 	str	w0, [x2, #16100]
    9ed4:	b97ee842 	ldr	w2, [x2, #16104]
    9ed8:	6b02001f 	cmp	w0, w2
    9edc:	1a829019 	csel	w25, w0, w2, ls	// ls = plast
    9ee0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ee4:	b97ef000 	ldr	w0, [x0, #16112]
    9ee8:	6b00033f 	cmp	w25, w0
    9eec:	1a809336 	csel	w22, w25, w0, ls	// ls = plast
    9ef0:	6b160322 	subs	w2, w25, w22
    9ef4:	540000c0 	b.eq	9f0c <fwp_main_thread+0xaac>  // b.none
    9ef8:	f9400ca4 	ldr	x4, [x5, #24]
    9efc:	0b160021 	add	w1, w1, w22
    9f00:	8b364f60 	add	x0, x27, w22, uxtw #3
    9f04:	f9400884 	ldr	x4, [x4, #16]
    9f08:	d63f0080 	blr	x4
    9f0c:	f9401f80 	ldr	x0, [x28, #56]
    9f10:	aa1803e7 	mov	x7, x24
    9f14:	b9400304 	ldr	w4, [x24]
    9f18:	aa1b03fa 	mov	x26, x27
    9f1c:	2a1903f7 	mov	w23, w25
    9f20:	aa1803e9 	mov	x9, x24
    9f24:	8b041404 	add	x4, x0, x4, lsl #5
    9f28:	f9400c88 	ldr	x8, [x4, #24]
    9f2c:	b4001488 	cbz	x8, a1bc <fwp_main_thread+0xd5c>
    9f30:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f34:	aa0403f4 	mov	x20, x4
    9f38:	f91f681b 	str	x27, [x0, #16080]
    9f3c:	b93ed816 	str	w22, [x0, #16088]
    9f40:	b93ee019 	str	w25, [x0, #16096]
    9f44:	14000012 	b	9f8c <fwp_main_thread+0xb2c>
    9f48:	f9400101 	ldr	x1, [x8]
    9f4c:	aa1a03e0 	mov	x0, x26
    9f50:	d63f0020 	blr	x1
    9f54:	aa0003fb 	mov	x27, x0
    9f58:	aa1803e0 	mov	x0, x24
    9f5c:	97ffee4d 	bl	5890 <fwp_closure_drop>
    9f60:	6b1702df 	cmp	w22, w23
    9f64:	54000d00 	b.eq	a104 <fwp_main_thread+0xca4>  // b.none
    9f68:	f9401f80 	ldr	x0, [x28, #56]
    9f6c:	8b364f5a 	add	x26, x26, w22, uxtw #3
    9f70:	b9400364 	ldr	w4, [x27]
    9f74:	4b130337 	sub	w23, w25, w19
    9f78:	aa1b03e7 	mov	x7, x27
    9f7c:	8b041414 	add	x20, x0, x4, lsl #5
    9f80:	f9400e88 	ldr	x8, [x20, #24]
    9f84:	b4001128 	cbz	x8, a1a8 <fwp_main_thread+0xd48>
    9f88:	aa1b03f8 	mov	x24, x27
    9f8c:	b94004e9 	ldr	w9, [x7, #4]
    9f90:	b9400293 	ldr	w19, [x20]
    9f94:	0b170139 	add	w25, w9, w23
    9f98:	6b19027f 	cmp	w19, w25
    9f9c:	54002a28 	b.hi	a4e0 <fwp_main_thread+0x1080>  // b.pmore
    9fa0:	7100013f 	cmp	w9, #0x0
    9fa4:	4b090276 	sub	w22, w19, w9
    9fa8:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    9fac:	54fffce1 	b.ne	9f48 <fwp_main_thread+0xae8>  // b.any
    9fb0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9fb4:	910003e0 	mov	x0, sp
    9fb8:	7100027f 	cmp	w19, #0x0
    9fbc:	f91f7c20 	str	x0, [x1, #16120]
    9fc0:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    9fc4:	d37df000 	lsl	x0, x0, #3
    9fc8:	91003c00 	add	x0, x0, #0xf
    9fcc:	92704c01 	and	x1, x0, #0xfffff0000
    9fd0:	927c7c00 	and	x0, x0, #0xffffffff0
    9fd4:	cb2163e1 	sub	x1, sp, x1
    9fd8:	eb2163ff 	cmp	sp, x1
    9fdc:	540000a0 	b.eq	9ff0 <fwp_main_thread+0xb90>  // b.none
    9fe0:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9fe4:	f90203ff 	str	xzr, [sp, #1024]
    9fe8:	eb2163ff 	cmp	sp, x1
    9fec:	54ffffa1 	b.ne	9fe0 <fwp_main_thread+0xb80>  // b.any
    9ff0:	92403c00 	and	x0, x0, #0xffff
    9ff4:	cb2063ff 	sub	sp, sp, x0
    9ff8:	f90003ff 	str	xzr, [sp]
    9ffc:	f110001f 	cmp	x0, #0x400
    a000:	54000043 	b.cc	a008 <fwp_main_thread+0xba8>  // b.lo, b.ul, b.last
    a004:	f90203ff 	str	xzr, [sp, #1024]
    a008:	910043fb 	add	x27, sp, #0x10
    a00c:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a010:	910020e1 	add	x1, x7, #0x8
    a014:	d2800000 	mov	x0, #0x0                   	// #0
    a018:	340000e9 	cbz	w9, a034 <fwp_main_thread+0xbd4>
    a01c:	d503201f 	nop
    a020:	f8606823 	ldr	x3, [x1, x0]
    a024:	f8206b63 	str	x3, [x27, x0]
    a028:	91002000 	add	x0, x0, #0x8
    a02c:	eb02001f 	cmp	x0, x2
    a030:	54ffff81 	b.ne	a020 <fwp_main_thread+0xbc0>  // b.any
    a034:	2a1603e1 	mov	w1, w22
    a038:	d2800000 	mov	x0, #0x0                   	// #0
    a03c:	340000f6 	cbz	w22, a058 <fwp_main_thread+0xbf8>
    a040:	0b000122 	add	w2, w9, w0
    a044:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a048:	91000400 	add	x0, x0, #0x1
    a04c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a050:	eb01001f 	cmp	x0, x1
    a054:	54ffff61 	b.ne	a040 <fwp_main_thread+0xbe0>  // b.any
    a058:	f949daa0 	ldr	x0, [x21, #5040]
    a05c:	f949eea1 	ldr	x1, [x21, #5080]
    a060:	cb000300 	sub	x0, x24, x0
    a064:	eb01401f 	cmp	x0, x1, lsl #16
    a068:	540002e2 	b.cs	a0c4 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a06c:	d350fc01 	lsr	x1, x0, #16
    a070:	f949fea5 	ldr	x5, [x21, #5112]
    a074:	8b010821 	add	x1, x1, x1, lsl #2
    a078:	d37df021 	lsl	x1, x1, #3
    a07c:	8b0100a3 	add	x3, x5, x1
    a080:	f9401062 	ldr	x2, [x3, #32]
    a084:	b4000202 	cbz	x2, a0c4 <fwp_main_thread+0xc64>
    a088:	386168a1 	ldrb	w1, [x5, x1]
    a08c:	7100083f 	cmp	w1, #0x2
    a090:	54000860 	b.eq	a19c <fwp_main_thread+0xd3c>  // b.none
    a094:	7100043f 	cmp	w1, #0x1
    a098:	54000161 	b.ne	a0c4 <fwp_main_thread+0xc64>  // b.any
    a09c:	29430465 	ldp	w5, w1, [x3, #24]
    a0a0:	92403c00 	and	x0, x0, #0xffff
    a0a4:	9b057c00 	mul	x0, x0, x5
    a0a8:	d360fc00 	lsr	x0, x0, #32
    a0ac:	eb01001f 	cmp	x0, x1
    a0b0:	540000a2 	b.cs	a0c4 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a0b4:	8b000042 	add	x2, x2, x0
    a0b8:	39400040 	ldrb	w0, [x2]
    a0bc:	7100041f 	cmp	w0, #0x1
    a0c0:	540006a0 	b.eq	a194 <fwp_main_thread+0xd34>  // b.none
    a0c4:	f9400502 	ldr	x2, [x8, #8]
    a0c8:	aa1803e0 	mov	x0, x24
    a0cc:	52800021 	mov	w1, #0x1                   	// #1
    a0d0:	d63f0040 	blr	x2
    a0d4:	f9400e81 	ldr	x1, [x20, #24]
    a0d8:	aa1b03e0 	mov	x0, x27
    a0dc:	f9400021 	ldr	x1, [x1]
    a0e0:	d63f0020 	blr	x1
    a0e4:	aa0003fb 	mov	x27, x0
    a0e8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0ec:	f95f7c00 	ldr	x0, [x0, #16120]
    a0f0:	9100001f 	mov	sp, x0
    a0f4:	aa1803e0 	mov	x0, x24
    a0f8:	97ffede6 	bl	5890 <fwp_closure_drop>
    a0fc:	6b1702df 	cmp	w22, w23
    a100:	54fff341 	b.ne	9f68 <fwp_main_thread+0xb08>  // b.any
    a104:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a108:	aa1b03f8 	mov	x24, x27
    a10c:	f95f681b 	ldr	x27, [x0, #16080]
    a110:	b97ed816 	ldr	w22, [x0, #16088]
    a114:	b97ee019 	ldr	w25, [x0, #16096]
    a118:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a11c:	b97ee401 	ldr	w1, [x0, #16100]
    a120:	b97ee800 	ldr	w0, [x0, #16104]
    a124:	6b00003f 	cmp	w1, w0
    a128:	540007e3 	b.cc	a224 <fwp_main_thread+0xdc4>  // b.lo, b.ul, b.last
    a12c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a130:	f95f6013 	ldr	x19, [x0, #16064]
    a134:	f95f6406 	ldr	x6, [x0, #16072]
    a138:	14000063 	b	a2c4 <fwp_main_thread+0xe64>
    a13c:	f9400438 	ldr	x24, [x1, #8]
    a140:	b4000118 	cbz	x24, a160 <fwp_main_thread+0xd00>
    a144:	f9400820 	ldr	x0, [x1, #16]
    a148:	cb180000 	sub	x0, x0, x24
    a14c:	eb00039f 	cmp	x28, x0
    a150:	54000088 	b.hi	a160 <fwp_main_thread+0xd00>  // b.pmore
    a154:	8b1c0300 	add	x0, x24, x28
    a158:	f9000420 	str	x0, [x1, #8]
    a15c:	17fffe34 	b	9a2c <fwp_main_thread+0x5cc>
    a160:	52800001 	mov	w1, #0x0                   	// #0
    a164:	d2800300 	mov	x0, #0x18                  	// #24
    a168:	97ffeaa2 	bl	4bf0 <fwp_heap_alloc>
    a16c:	aa0003f8 	mov	x24, x0
    a170:	17fffe43 	b	9a7c <fwp_main_thread+0x61c>
    a174:	72003c5f 	tst	w2, #0xffff
    a178:	54ffcc01 	b.ne	9af8 <fwp_main_thread+0x698>  // b.any
    a17c:	39400380 	ldrb	w0, [x28]
    a180:	7103fc1f 	cmp	w0, #0xff
    a184:	54ffcb81 	b.ne	9af4 <fwp_main_thread+0x694>  // b.any
    a188:	aa1c03e0 	mov	x0, x28
    a18c:	97ffe8d9 	bl	44f0 <fwp_rc_forget_slot>
    a190:	17fffe59 	b	9af4 <fwp_main_thread+0x694>
    a194:	b90004ff 	str	wzr, [x7, #4]
    a198:	17ffffcf 	b	a0d4 <fwp_main_thread+0xc74>
    a19c:	72003c1f 	tst	w0, #0xffff
    a1a0:	54fff921 	b.ne	a0c4 <fwp_main_thread+0xc64>  // b.any
    a1a4:	17ffffc5 	b	a0b8 <fwp_main_thread+0xc58>
    a1a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1ac:	aa1b03e9 	mov	x9, x27
    a1b0:	f95f681b 	ldr	x27, [x0, #16080]
    a1b4:	b97ed816 	ldr	w22, [x0, #16088]
    a1b8:	b97ee019 	ldr	w25, [x0, #16096]
    a1bc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a1c0:	aa0903e0 	mov	x0, x9
    a1c4:	f91f7c29 	str	x9, [x1, #16120]
    a1c8:	97ffec96 	bl	5420 <fwp_rc_share>
    a1cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1d0:	f95f7c09 	ldr	x9, [x0, #16120]
    a1d4:	34000157 	cbz	w23, a1fc <fwp_main_thread+0xd9c>
    a1d8:	8b374f53 	add	x19, x26, w23, uxtw #3
    a1dc:	aa1a03f4 	mov	x20, x26
    a1e0:	aa0903f8 	mov	x24, x9
    a1e4:	d503201f 	nop
    a1e8:	f8408680 	ldr	x0, [x20], #8
    a1ec:	97ffec8d 	bl	5420 <fwp_rc_share>
    a1f0:	eb13029f 	cmp	x20, x19
    a1f4:	54ffffa1 	b.ne	a1e8 <fwp_main_thread+0xd88>  // b.any
    a1f8:	aa1803e9 	mov	x9, x24
    a1fc:	aa1a03e2 	mov	x2, x26
    a200:	2a1703e1 	mov	w1, w23
    a204:	aa0903e0 	mov	x0, x9
    a208:	97ffeabf 	bl	4d04 <fwp_apply>
    a20c:	aa0003f8 	mov	x24, x0
    a210:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a214:	b97ee401 	ldr	w1, [x0, #16100]
    a218:	b97ee800 	ldr	w0, [x0, #16104]
    a21c:	6b00003f 	cmp	w1, w0
    a220:	54fff862 	b.cs	a12c <fwp_main_thread+0xccc>  // b.hs, b.nlast
    a224:	f9401f81 	ldr	x1, [x28, #56]
    a228:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a22c:	b9400305 	ldr	w5, [x24]
    a230:	4b190000 	sub	w0, w0, w25
    a234:	8b394f7b 	add	x27, x27, w25, uxtw #3
    a238:	b93ee840 	str	w0, [x2, #16104]
    a23c:	8b051425 	add	x5, x1, x5, lsl #5
    a240:	b97ef040 	ldr	w0, [x2, #16112]
    a244:	4b160000 	sub	w0, w0, w22
    a248:	b93ef040 	str	w0, [x2, #16112]
    a24c:	f9400ca1 	ldr	x1, [x5, #24]
    a250:	aa1803e0 	mov	x0, x24
    a254:	b5ffe361 	cbnz	x1, 9ec0 <fwp_main_thread+0xa60>
    a258:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a25c:	f95f6406 	ldr	x6, [x0, #16072]
    a260:	f91f7c06 	str	x6, [x0, #16120]
    a264:	f95f6013 	ldr	x19, [x0, #16064]
    a268:	b97ee814 	ldr	w20, [x0, #16104]
    a26c:	aa1803e0 	mov	x0, x24
    a270:	97ffec6c 	bl	5420 <fwp_rc_share>
    a274:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a278:	f95f7c06 	ldr	x6, [x0, #16120]
    a27c:	34000134 	cbz	w20, a2a0 <fwp_main_thread+0xe40>
    a280:	aa0603fa 	mov	x26, x6
    a284:	d2800015 	mov	x21, #0x0                   	// #0
    a288:	f8757b60 	ldr	x0, [x27, x21, lsl #3]
    a28c:	910006b5 	add	x21, x21, #0x1
    a290:	97ffec64 	bl	5420 <fwp_rc_share>
    a294:	6b15029f 	cmp	w20, w21
    a298:	54ffff88 	b.hi	a288 <fwp_main_thread+0xe28>  // b.pmore
    a29c:	aa1a03e6 	mov	x6, x26
    a2a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2a4:	aa1b03e2 	mov	x2, x27
    a2a8:	2a1403e1 	mov	w1, w20
    a2ac:	f91f7c06 	str	x6, [x0, #16120]
    a2b0:	aa1803e0 	mov	x0, x24
    a2b4:	97ffea94 	bl	4d04 <fwp_apply>
    a2b8:	aa0003f8 	mov	x24, x0
    a2bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2c0:	f95f7c06 	ldr	x6, [x0, #16120]
    a2c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2c8:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10dc8>
    a2cc:	91102042 	add	x2, x2, #0x408
    a2d0:	91014042 	add	x2, x2, #0x50
    a2d4:	aa1803e1 	mov	x1, x24
    a2d8:	f91f7c06 	str	x6, [x0, #16120]
    a2dc:	52800023 	mov	w3, #0x1                   	// #1
    a2e0:	f95f5800 	ldr	x0, [x0, #16048]
    a2e4:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a2e8:	f81303bf 	stur	xzr, [x29, #-208]
    a2ec:	97fff861 	bl	8470 <fwp_write>
    a2f0:	a9726bb5 	ldp	x21, x26, [x29, #-224]
    a2f4:	b0000000 	adrp	x0, b000 <__modti3+0x180>
    a2f8:	91306000 	add	x0, x0, #0xc18
    a2fc:	f10002bf 	cmp	x21, #0x0
    a300:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a304:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a308:	b1002b5f 	cmn	x26, #0xa
    a30c:	f95f7c06 	ldr	x6, [x0, #16120]
    a310:	54003628 	b.hi	a9d4 <fwp_main_thread+0x1574>  // b.pmore
    a314:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a318:	52800021 	mov	w1, #0x1                   	// #1
    a31c:	f91f7c06 	str	x6, [x0, #16120]
    a320:	91002740 	add	x0, x26, #0x9
    a324:	97ffea33 	bl	4bf0 <fwp_heap_alloc>
    a328:	aa0003f4 	mov	x20, x0
    a32c:	aa1503e1 	mov	x1, x21
    a330:	aa0003f5 	mov	x21, x0
    a334:	aa1a03e2 	mov	x2, x26
    a338:	f80086ba 	str	x26, [x21], #8
    a33c:	8b1a029a 	add	x26, x20, x26
    a340:	aa1503e0 	mov	x0, x21
    a344:	97ffe0bf 	bl	2640 <memcpy@plt>
    a348:	3900235f 	strb	wzr, [x26, #8]
    a34c:	f85203a0 	ldur	x0, [x29, #-224]
    a350:	97ffe158 	bl	28b0 <free@plt>
    a354:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a358:	91154002 	add	x2, x0, #0x550
    a35c:	f949d841 	ldr	x1, [x2, #5040]
    a360:	f949ec40 	ldr	x0, [x2, #5080]
    a364:	cb010281 	sub	x1, x20, x1
    a368:	eb00403f 	cmp	x1, x0, lsl #16
    a36c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a370:	f95f7c06 	ldr	x6, [x0, #16120]
    a374:	54000322 	b.cs	a3d8 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a378:	d350fc20 	lsr	x0, x1, #16
    a37c:	f949fc43 	ldr	x3, [x2, #5112]
    a380:	8b000800 	add	x0, x0, x0, lsl #2
    a384:	d37df002 	lsl	x2, x0, #3
    a388:	8b020060 	add	x0, x3, x2
    a38c:	f940101a 	ldr	x26, [x0, #32]
    a390:	b400025a 	cbz	x26, a3d8 <fwp_main_thread+0xf78>
    a394:	38626862 	ldrb	w2, [x3, x2]
    a398:	7100085f 	cmp	w2, #0x2
    a39c:	54003480 	b.eq	aa2c <fwp_main_thread+0x15cc>  // b.none
    a3a0:	7100045f 	cmp	w2, #0x1
    a3a4:	540001a1 	b.ne	a3d8 <fwp_main_thread+0xf78>  // b.any
    a3a8:	29430002 	ldp	w2, w0, [x0, #24]
    a3ac:	92403c21 	and	x1, x1, #0xffff
    a3b0:	9b027c21 	mul	x1, x1, x2
    a3b4:	d360fc21 	lsr	x1, x1, #32
    a3b8:	eb00003f 	cmp	x1, x0
    a3bc:	540000e2 	b.cs	a3d8 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a3c0:	8b01035a 	add	x26, x26, x1
    a3c4:	39400340 	ldrb	w0, [x26]
    a3c8:	7103fc1f 	cmp	w0, #0xff
    a3cc:	54003800 	b.eq	aacc <fwp_main_thread+0x166c>  // b.none
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	39000340 	strb	w0, [x26]
    a3d8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3dc:	f91f7c06 	str	x6, [x0, #16120]
    a3e0:	aa1803e0 	mov	x0, x24
    a3e4:	97ffeccf 	bl	5720 <fwp_drop0>
    a3e8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a3ec:	91010003 	add	x3, x0, #0x40
    a3f0:	f9400282 	ldr	x2, [x20]
    a3f4:	aa1503e0 	mov	x0, x21
    a3f8:	aa0303f5 	mov	x21, x3
    a3fc:	d2800021 	mov	x1, #0x1                   	// #1
    a400:	f9400463 	ldr	x3, [x3, #8]
    a404:	97ffe13b 	bl	28f0 <fwrite@plt>
    a408:	f94006a1 	ldr	x1, [x21, #8]
    a40c:	52800140 	mov	w0, #0xa                   	// #10
    a410:	97ffe0c0 	bl	2710 <fputc@plt>
    a414:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a418:	91154002 	add	x2, x0, #0x550
    a41c:	f949d841 	ldr	x1, [x2, #5040]
    a420:	f949ec40 	ldr	x0, [x2, #5080]
    a424:	cb010281 	sub	x1, x20, x1
    a428:	eb00403f 	cmp	x1, x0, lsl #16
    a42c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a430:	f95f7c06 	ldr	x6, [x0, #16120]
    a434:	54000382 	b.cs	a4a4 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a438:	d350fc20 	lsr	x0, x1, #16
    a43c:	f949fc43 	ldr	x3, [x2, #5112]
    a440:	8b000800 	add	x0, x0, x0, lsl #2
    a444:	d37df000 	lsl	x0, x0, #3
    a448:	8b000062 	add	x2, x3, x0
    a44c:	f9401055 	ldr	x21, [x2, #32]
    a450:	b40002b5 	cbz	x21, a4a4 <fwp_main_thread+0x1044>
    a454:	38606860 	ldrb	w0, [x3, x0]
    a458:	7100081f 	cmp	w0, #0x2
    a45c:	54002e20 	b.eq	aa20 <fwp_main_thread+0x15c0>  // b.none
    a460:	7100041f 	cmp	w0, #0x1
    a464:	54000201 	b.ne	a4a4 <fwp_main_thread+0x1044>  // b.any
    a468:	29430043 	ldp	w3, w0, [x2, #24]
    a46c:	92403c21 	and	x1, x1, #0xffff
    a470:	9b037c21 	mul	x1, x1, x3
    a474:	d360fc21 	lsr	x1, x1, #32
    a478:	eb00003f 	cmp	x1, x0
    a47c:	54000142 	b.cs	a4a4 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a480:	8b0102b5 	add	x21, x21, x1
    a484:	394002a0 	ldrb	w0, [x21]
    a488:	340000e0 	cbz	w0, a4a4 <fwp_main_thread+0x1044>
    a48c:	7100041f 	cmp	w0, #0x1
    a490:	540030a0 	b.eq	aaa4 <fwp_main_thread+0x1644>  // b.none
    a494:	7103fc1f 	cmp	w0, #0xff
    a498:	54002d00 	b.eq	aa38 <fwp_main_thread+0x15d8>  // b.none
    a49c:	51000400 	sub	w0, w0, #0x1
    a4a0:	390002a0 	strb	w0, [x21]
    a4a4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4a8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a4ac:	f95f5400 	ldr	x0, [x0, #16040]
    a4b0:	f9400800 	ldr	x0, [x0, #16]
    a4b4:	f91f5420 	str	x0, [x1, #16040]
    a4b8:	b4002940 	cbz	x0, a9e0 <fwp_main_thread+0x1580>
    a4bc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a4c0:	91154000 	add	x0, x0, #0x550
    a4c4:	f949d801 	ldr	x1, [x0, #5040]
    a4c8:	f949ec02 	ldr	x2, [x0, #5080]
    a4cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4d0:	f95f5c00 	ldr	x0, [x0, #16056]
    a4d4:	d370bc42 	lsl	x2, x2, #16
    a4d8:	cb010001 	sub	x1, x0, x1
    a4dc:	17fffe22 	b	9d64 <fwp_main_thread+0x904>
    a4e0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4e4:	2a1903e2 	mov	w2, w25
    a4e8:	aa1403e4 	mov	x4, x20
    a4ec:	f95f681b 	ldr	x27, [x0, #16080]
    a4f0:	b97ed816 	ldr	w22, [x0, #16088]
    a4f4:	b97ee019 	ldr	w25, [x0, #16096]
    a4f8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a4fc:	9115400a 	add	x10, x0, #0x550
    a500:	11000440 	add	w0, w2, #0x1
    a504:	f120001f 	cmp	x0, #0x800
    a508:	d37df000 	lsl	x0, x0, #3
    a50c:	b953a541 	ldr	w1, [x10, #5028]
    a510:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a514:	54001940 	b.eq	a83c <fwp_main_thread+0x13dc>  // b.none
    a518:	91003c01 	add	x1, x0, #0xf
    a51c:	8b411141 	add	x1, x10, x1, lsr #4
    a520:	397e8021 	ldrb	w1, [x1, #4000]
    a524:	910f002b 	add	x11, x1, #0x3c0
    a528:	8b010428 	add	x8, x1, x1, lsl #1
    a52c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a530:	8b080d4c 	add	x12, x10, x8, lsl #3
    a534:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a538:	2a0b03e1 	mov	w1, w11
    a53c:	b40016f3 	cbz	x19, a818 <fwp_main_thread+0x13b8>
    a540:	f940026c 	ldr	x12, [x19]
    a544:	aa2c03ec 	mvn	x12, x12
    a548:	f828794c 	str	x12, [x10, x8, lsl #3]
    a54c:	eb01001f 	cmp	x0, x1
    a550:	540000c2 	b.cs	a568 <fwp_main_thread+0x1108>  // b.hs, b.nlast
    a554:	d503201f 	nop
    a558:	f8206a7f 	str	xzr, [x19, x0]
    a55c:	91002000 	add	x0, x0, #0x8
    a560:	eb00003f 	cmp	x1, x0
    a564:	54ffffa8 	b.hi	a558 <fwp_main_thread+0x10f8>  // b.pmore
    a568:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a56c:	91154008 	add	x8, x0, #0x550
    a570:	f94a1100 	ldr	x0, [x8, #5152]
    a574:	ab010000 	adds	x0, x0, x1
    a578:	540020a2 	b.cs	a98c <fwp_main_thread+0x152c>  // b.hs, b.nlast
    a57c:	f94a1501 	ldr	x1, [x8, #5160]
    a580:	f90a1100 	str	x0, [x8, #5152]
    a584:	eb01001f 	cmp	x0, x1
    a588:	54000049 	b.ls	a590 <fwp_main_thread+0x1130>  // b.plast
    a58c:	f90a1500 	str	x0, [x8, #5160]
    a590:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a594:	91154000 	add	x0, x0, #0x550
    a598:	1e630161 	ucvtf	d1, w11
    a59c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a5a0:	1e612800 	fadd	d0, d0, d1
    a5a4:	fd0a1c00 	str	d0, [x0, #5176]
    a5a8:	b94000e0 	ldr	w0, [x7]
    a5ac:	29000a60 	stp	w0, w2, [x19]
    a5b0:	340001a9 	cbz	w9, a5e4 <fwp_main_thread+0x1184>
    a5b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5b8:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a5bc:	910020e1 	add	x1, x7, #0x8
    a5c0:	f91f6c04 	str	x4, [x0, #16088]
    a5c4:	b93ee009 	str	w9, [x0, #16096]
    a5c8:	f91f7c07 	str	x7, [x0, #16120]
    a5cc:	91002260 	add	x0, x19, #0x8
    a5d0:	97ffe024 	bl	2660 <memmove@plt>
    a5d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5d8:	f95f6c04 	ldr	x4, [x0, #16088]
    a5dc:	f95f7c07 	ldr	x7, [x0, #16120]
    a5e0:	b97ee009 	ldr	w9, [x0, #16096]
    a5e4:	2a1703e8 	mov	w8, w23
    a5e8:	d2800001 	mov	x1, #0x0                   	// #0
    a5ec:	34000117 	cbz	w23, a60c <fwp_main_thread+0x11ac>
    a5f0:	0b010120 	add	w0, w9, w1
    a5f4:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a5f8:	8b000e60 	add	x0, x19, x0, lsl #3
    a5fc:	91000421 	add	x1, x1, #0x1
    a600:	f9000402 	str	x2, [x0, #8]
    a604:	eb08003f 	cmp	x1, x8
    a608:	54ffff41 	b.ne	a5f0 <fwp_main_thread+0x1190>  // b.any
    a60c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a610:	91154002 	add	x2, x0, #0x550
    a614:	f949d840 	ldr	x0, [x2, #5040]
    a618:	f949ec41 	ldr	x1, [x2, #5080]
    a61c:	cb000300 	sub	x0, x24, x0
    a620:	eb01401f 	cmp	x0, x1, lsl #16
    a624:	540002e2 	b.cs	a680 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a628:	d350fc01 	lsr	x1, x0, #16
    a62c:	f949fc48 	ldr	x8, [x2, #5112]
    a630:	8b010821 	add	x1, x1, x1, lsl #2
    a634:	d37df021 	lsl	x1, x1, #3
    a638:	8b010105 	add	x5, x8, x1
    a63c:	f94010a2 	ldr	x2, [x5, #32]
    a640:	b4000202 	cbz	x2, a680 <fwp_main_thread+0x1220>
    a644:	38616901 	ldrb	w1, [x8, x1]
    a648:	7100083f 	cmp	w1, #0x2
    a64c:	54001140 	b.eq	a874 <fwp_main_thread+0x1414>  // b.none
    a650:	7100043f 	cmp	w1, #0x1
    a654:	54000161 	b.ne	a680 <fwp_main_thread+0x1220>  // b.any
    a658:	294304a8 	ldp	w8, w1, [x5, #24]
    a65c:	92403c00 	and	x0, x0, #0xffff
    a660:	9b087c00 	mul	x0, x0, x8
    a664:	d360fc00 	lsr	x0, x0, #32
    a668:	eb01001f 	cmp	x0, x1
    a66c:	540000a2 	b.cs	a680 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a670:	8b000042 	add	x2, x2, x0
    a674:	39400040 	ldrb	w0, [x2]
    a678:	7100041f 	cmp	w0, #0x1
    a67c:	54000c40 	b.eq	a804 <fwp_main_thread+0x13a4>  // b.none
    a680:	f9400c82 	ldr	x2, [x4, #24]
    a684:	aa1803e0 	mov	x0, x24
    a688:	52800021 	mov	w1, #0x1                   	// #1
    a68c:	f9400442 	ldr	x2, [x2, #8]
    a690:	d63f0040 	blr	x2
    a694:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a698:	91154002 	add	x2, x0, #0x550
    a69c:	f949d841 	ldr	x1, [x2, #5040]
    a6a0:	f949ec40 	ldr	x0, [x2, #5080]
    a6a4:	cb010261 	sub	x1, x19, x1
    a6a8:	eb00403f 	cmp	x1, x0, lsl #16
    a6ac:	54000322 	b.cs	a710 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a6b0:	d350fc20 	lsr	x0, x1, #16
    a6b4:	f949fc44 	ldr	x4, [x2, #5112]
    a6b8:	8b000800 	add	x0, x0, x0, lsl #2
    a6bc:	d37df002 	lsl	x2, x0, #3
    a6c0:	8b020080 	add	x0, x4, x2
    a6c4:	f9401017 	ldr	x23, [x0, #32]
    a6c8:	b4000257 	cbz	x23, a710 <fwp_main_thread+0x12b0>
    a6cc:	38626882 	ldrb	w2, [x4, x2]
    a6d0:	7100085f 	cmp	w2, #0x2
    a6d4:	54000d60 	b.eq	a880 <fwp_main_thread+0x1420>  // b.none
    a6d8:	7100045f 	cmp	w2, #0x1
    a6dc:	540001a1 	b.ne	a710 <fwp_main_thread+0x12b0>  // b.any
    a6e0:	29430002 	ldp	w2, w0, [x0, #24]
    a6e4:	92403c21 	and	x1, x1, #0xffff
    a6e8:	9b027c21 	mul	x1, x1, x2
    a6ec:	d360fc21 	lsr	x1, x1, #32
    a6f0:	eb00003f 	cmp	x1, x0
    a6f4:	540000e2 	b.cs	a710 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a6f8:	8b0102f7 	add	x23, x23, x1
    a6fc:	394002e0 	ldrb	w0, [x23]
    a700:	7103fc1f 	cmp	w0, #0xff
    a704:	54000c80 	b.eq	a894 <fwp_main_thread+0x1434>  // b.none
    a708:	52800020 	mov	w0, #0x1                   	// #1
    a70c:	390002e0 	strb	w0, [x23]
    a710:	aa1803e0 	mov	x0, x24
    a714:	aa1303f8 	mov	x24, x19
    a718:	97ffec5e 	bl	5890 <fwp_closure_drop>
    a71c:	17fffebd 	b	a210 <fwp_main_thread+0xdb0>
    a720:	b8616860 	ldr	w0, [x3, x1]
    a724:	b9400481 	ldr	w1, [x4, #4]
    a728:	4b010003 	sub	w3, w0, w1
    a72c:	7100047f 	cmp	w3, #0x1
    a730:	54ffb721 	b.ne	9e14 <fwp_main_thread+0x9b4>  // b.any
    a734:	910003f4 	mov	x20, sp
    a738:	34000c41 	cbz	w1, a8c0 <fwp_main_thread+0x1460>
    a73c:	7100001f 	cmp	w0, #0x0
    a740:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a744:	d2800102 	mov	x2, #0x8                   	// #8
    a748:	9a82101a 	csel	x26, x0, x2, ne	// ne = any
    a74c:	91003f40 	add	x0, x26, #0xf
    a750:	92704c02 	and	x2, x0, #0xfffff0000
    a754:	927c7c00 	and	x0, x0, #0xffffffff0
    a758:	cb2263e2 	sub	x2, sp, x2
    a75c:	eb2263ff 	cmp	sp, x2
    a760:	540000a0 	b.eq	a774 <fwp_main_thread+0x1314>  // b.none
    a764:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a768:	f90203ff 	str	xzr, [sp, #1024]
    a76c:	eb2263ff 	cmp	sp, x2
    a770:	54ffffa1 	b.ne	a764 <fwp_main_thread+0x1304>  // b.any
    a774:	92403c00 	and	x0, x0, #0xffff
    a778:	cb2063ff 	sub	sp, sp, x0
    a77c:	f90003ff 	str	xzr, [sp]
    a780:	f110001f 	cmp	x0, #0x400
    a784:	54000043 	b.cc	a78c <fwp_main_thread+0x132c>  // b.lo, b.ul, b.last
    a788:	f90203ff 	str	xzr, [sp, #1024]
    a78c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a790:	d37d7c3b 	ubfiz	x27, x1, #3, #32
    a794:	910043f5 	add	x21, sp, #0x10
    a798:	aa1b03e2 	mov	x2, x27
    a79c:	aa1a03e3 	mov	x3, x26
    a7a0:	f91f7806 	str	x6, [x0, #16112]
    a7a4:	f91f7c05 	str	x5, [x0, #16120]
    a7a8:	f95f5000 	ldr	x0, [x0, #16032]
    a7ac:	91004001 	add	x1, x0, #0x10
    a7b0:	aa1503e0 	mov	x0, x21
    a7b4:	91004021 	add	x1, x1, #0x10
    a7b8:	97ffdfe2 	bl	2740 <__memcpy_chk@plt>
    a7bc:	eb1b035f 	cmp	x26, x27
    a7c0:	aa1303e1 	mov	x1, x19
    a7c4:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    a7c8:	d2800102 	mov	x2, #0x8                   	// #8
    a7cc:	cb1b0063 	sub	x3, x3, x27
    a7d0:	8b1b02a0 	add	x0, x21, x27
    a7d4:	97ffdfdb 	bl	2740 <__memcpy_chk@plt>
    a7d8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a7dc:	aa1503e0 	mov	x0, x21
    a7e0:	f95f7c25 	ldr	x5, [x1, #16120]
    a7e4:	f9400ca1 	ldr	x1, [x5, #24]
    a7e8:	f9400021 	ldr	x1, [x1]
    a7ec:	d63f0020 	blr	x1
    a7f0:	aa0003f8 	mov	x24, x0
    a7f4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7f8:	f95f7806 	ldr	x6, [x0, #16112]
    a7fc:	9100029f 	mov	sp, x20
    a800:	17fffeb1 	b	a2c4 <fwp_main_thread+0xe64>
    a804:	b90004ff 	str	wzr, [x7, #4]
    a808:	17ffffa3 	b	a694 <fwp_main_thread+0x1234>
    a80c:	72003c3f 	tst	w1, #0xffff
    a810:	54ffb421 	b.ne	9e94 <fwp_main_thread+0xa34>  // b.any
    a814:	17fffd9a 	b	9e7c <fwp_main_thread+0xa1c>
    a818:	f9400593 	ldr	x19, [x12, #8]
    a81c:	b4000113 	cbz	x19, a83c <fwp_main_thread+0x13dc>
    a820:	f9400988 	ldr	x8, [x12, #16]
    a824:	cb130108 	sub	x8, x8, x19
    a828:	eb08003f 	cmp	x1, x8
    a82c:	54000088 	b.hi	a83c <fwp_main_thread+0x13dc>  // b.pmore
    a830:	8b010268 	add	x8, x19, x1
    a834:	f9000588 	str	x8, [x12, #8]
    a838:	17ffff45 	b	a54c <fwp_main_thread+0x10ec>
    a83c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a840:	f91f6824 	str	x4, [x1, #16080]
    a844:	f91f6c27 	str	x7, [x1, #16088]
    a848:	b93ee022 	str	w2, [x1, #16096]
    a84c:	b93ef829 	str	w9, [x1, #16120]
    a850:	52800001 	mov	w1, #0x0                   	// #0
    a854:	97ffe8e7 	bl	4bf0 <fwp_heap_alloc>
    a858:	aa0003f3 	mov	x19, x0
    a85c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a860:	f95f6804 	ldr	x4, [x0, #16080]
    a864:	f95f6c07 	ldr	x7, [x0, #16088]
    a868:	b97ee002 	ldr	w2, [x0, #16096]
    a86c:	b97ef809 	ldr	w9, [x0, #16120]
    a870:	17ffff4e 	b	a5a8 <fwp_main_thread+0x1148>
    a874:	72003c1f 	tst	w0, #0xffff
    a878:	54fff041 	b.ne	a680 <fwp_main_thread+0x1220>  // b.any
    a87c:	17ffff7e 	b	a674 <fwp_main_thread+0x1214>
    a880:	72003c3f 	tst	w1, #0xffff
    a884:	54fff461 	b.ne	a710 <fwp_main_thread+0x12b0>  // b.any
    a888:	394002e0 	ldrb	w0, [x23]
    a88c:	7103fc1f 	cmp	w0, #0xff
    a890:	54fff3c1 	b.ne	a708 <fwp_main_thread+0x12a8>  // b.any
    a894:	aa1703e0 	mov	x0, x23
    a898:	97ffe716 	bl	44f0 <fwp_rc_forget_slot>
    a89c:	17ffff9b 	b	a708 <fwp_main_thread+0x12a8>
    a8a0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a8a4:	f91f7826 	str	x6, [x1, #16112]
    a8a8:	f91f7c25 	str	x5, [x1, #16120]
    a8ac:	97ffe6ca 	bl	43d4 <fwp_rc_wide_dup>
    a8b0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8b4:	f95f7806 	ldr	x6, [x0, #16112]
    a8b8:	f95f7c05 	ldr	x5, [x0, #16120]
    a8bc:	17fffd76 	b	9e94 <fwp_main_thread+0xa34>
    a8c0:	f9400041 	ldr	x1, [x2]
    a8c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8c8:	f91f7c06 	str	x6, [x0, #16120]
    a8cc:	aa1303e0 	mov	x0, x19
    a8d0:	d63f0020 	blr	x1
    a8d4:	aa0003f8 	mov	x24, x0
    a8d8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8dc:	f95f7c06 	ldr	x6, [x0, #16120]
    a8e0:	9100029f 	mov	sp, x20
    a8e4:	17fffe78 	b	a2c4 <fwp_main_thread+0xe64>
    a8e8:	72003c3f 	tst	w1, #0xffff
    a8ec:	54ff9be1 	b.ne	9c68 <fwp_main_thread+0x808>  // b.any
    a8f0:	17fffcd9 	b	9c54 <fwp_main_thread+0x7f4>
    a8f4:	72003c3f 	tst	w1, #0xffff
    a8f8:	54ff9661 	b.ne	9bc4 <fwp_main_thread+0x764>  // b.any
    a8fc:	17fffcad 	b	9bb0 <fwp_main_thread+0x750>
    a900:	72003c3f 	tst	w1, #0xffff
    a904:	54ffa6a1 	b.ne	9dd8 <fwp_main_thread+0x978>  // b.any
    a908:	17fffd2e 	b	9dc0 <fwp_main_thread+0x960>
    a90c:	72003c3f 	tst	w1, #0xffff
    a910:	54ffa0e1 	b.ne	9d2c <fwp_main_thread+0x8cc>  // b.any
    a914:	17fffcfb 	b	9d00 <fwp_main_thread+0x8a0>
    a918:	aa0103e0 	mov	x0, x1
    a91c:	17fffb9d 	b	9790 <fwp_main_thread+0x330>
    a920:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a924:	f91f7c06 	str	x6, [x0, #16120]
    a928:	aa1303e0 	mov	x0, x19
    a92c:	97ffe6f1 	bl	44f0 <fwp_rc_forget_slot>
    a930:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a934:	f95f7c06 	ldr	x6, [x0, #16120]
    a938:	17fffca1 	b	9bbc <fwp_main_thread+0x75c>
    a93c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a940:	f91f7c26 	str	x6, [x1, #16120]
    a944:	97ffe6a4 	bl	43d4 <fwp_rc_wide_dup>
    a948:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a94c:	f95f7c06 	ldr	x6, [x0, #16120]
    a950:	17fffd22 	b	9dd8 <fwp_main_thread+0x978>
    a954:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a958:	f91f7c06 	str	x6, [x0, #16120]
    a95c:	aa1303e0 	mov	x0, x19
    a960:	97ffe6e4 	bl	44f0 <fwp_rc_forget_slot>
    a964:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a968:	f95f7c06 	ldr	x6, [x0, #16120]
    a96c:	17fffcbd 	b	9c60 <fwp_main_thread+0x800>
    a970:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a974:	f91f7c06 	str	x6, [x0, #16120]
    a978:	aa1303e0 	mov	x0, x19
    a97c:	97ffe6dd 	bl	44f0 <fwp_rc_forget_slot>
    a980:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a984:	f95f7c06 	ldr	x6, [x0, #16120]
    a988:	17fffce1 	b	9d0c <fwp_main_thread+0x8ac>
    a98c:	97ffe189 	bl	2fb0 <fwp_heap_oom>
    a990:	b0000000 	adrp	x0, b000 <__modti3+0x180>
    a994:	911f0000 	add	x0, x0, #0x7c0
    a998:	97ffe2da 	bl	3500 <fwp_trap>
    a99c:	97ffdf95 	bl	27f0 <__stack_chk_fail@plt>
    a9a0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a9a4:	aa0603e0 	mov	x0, x6
    a9a8:	aa1303fb 	mov	x27, x19
    a9ac:	52800034 	mov	w20, #0x1                   	// #1
    a9b0:	f91f7c26 	str	x6, [x1, #16120]
    a9b4:	97ffea9b 	bl	5420 <fwp_rc_share>
    a9b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9bc:	f95f5c00 	ldr	x0, [x0, #16056]
    a9c0:	97ffea98 	bl	5420 <fwp_rc_share>
    a9c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9c8:	f95f7c06 	ldr	x6, [x0, #16120]
    a9cc:	aa0603f8 	mov	x24, x6
    a9d0:	17fffe34 	b	a2a0 <fwp_main_thread+0xe40>
    a9d4:	b0000000 	adrp	x0, b000 <__modti3+0x180>
    a9d8:	911fa000 	add	x0, x0, #0x7e8
    a9dc:	97ffe2c9 	bl	3500 <fwp_trap>
    a9e0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9e4:	f95f4c06 	ldr	x6, [x0, #16024]
    a9e8:	f91f7c06 	str	x6, [x0, #16120]
    a9ec:	f95f5c16 	ldr	x22, [x0, #16056]
    a9f0:	aa1603e0 	mov	x0, x22
    a9f4:	97ffeb4b 	bl	5720 <fwp_drop0>
    a9f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9fc:	f95f7c06 	ldr	x6, [x0, #16120]
    aa00:	aa0603e0 	mov	x0, x6
    aa04:	97ffeb47 	bl	5720 <fwp_drop0>
    aa08:	d00000a0 	adrp	x0, 20000 <__data_start>
    aa0c:	91010000 	add	x0, x0, #0x40
    aa10:	52800021 	mov	w1, #0x1                   	// #1
    aa14:	b902f801 	str	w1, [x0, #760]
    aa18:	f901801f 	str	xzr, [x0, #768]
    aa1c:	17fffad3 	b	9568 <fwp_main_thread+0x108>
    aa20:	72003c3f 	tst	w1, #0xffff
    aa24:	54ffd401 	b.ne	a4a4 <fwp_main_thread+0x1044>  // b.any
    aa28:	17fffe97 	b	a484 <fwp_main_thread+0x1024>
    aa2c:	72003c3f 	tst	w1, #0xffff
    aa30:	54ffcd41 	b.ne	a3d8 <fwp_main_thread+0xf78>  // b.any
    aa34:	17fffe64 	b	a3c4 <fwp_main_thread+0xf64>
    aa38:	ca5546a0 	eor	x0, x21, x21, lsr #17
    aa3c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    aa40:	91154021 	add	x1, x1, #0x550
    aa44:	ca402400 	eor	x0, x0, x0, lsr #9
    aa48:	8b200c20 	add	x0, x1, w0, uxtb #3
    aa4c:	f94a2400 	ldr	x0, [x0, #5192]
    aa50:	b5000080 	cbnz	x0, aa60 <fwp_main_thread+0x1600>
    aa54:	14000025 	b	aae8 <fwp_main_thread+0x1688>
    aa58:	f9400800 	ldr	x0, [x0, #16]
    aa5c:	b4000460 	cbz	x0, aae8 <fwp_main_thread+0x1688>
    aa60:	f9400001 	ldr	x1, [x0]
    aa64:	eb0102bf 	cmp	x21, x1
    aa68:	54ffff81 	b.ne	aa58 <fwp_main_thread+0x15f8>  // b.any
    aa6c:	f9400401 	ldr	x1, [x0, #8]
    aa70:	d1000421 	sub	x1, x1, #0x1
    aa74:	f9000401 	str	x1, [x0, #8]
    aa78:	f103f83f 	cmp	x1, #0xfe
    aa7c:	54ffd141 	b.ne	a4a4 <fwp_main_thread+0x1044>  // b.any
    aa80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa84:	f91f7c06 	str	x6, [x0, #16120]
    aa88:	aa1503e0 	mov	x0, x21
    aa8c:	97ffe699 	bl	44f0 <fwp_rc_forget_slot>
    aa90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aa94:	390002a0 	strb	w0, [x21]
    aa98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa9c:	f95f7c06 	ldr	x6, [x0, #16120]
    aaa0:	17fffe81 	b	a4a4 <fwp_main_thread+0x1044>
    aaa4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aaa8:	f91f7c06 	str	x6, [x0, #16120]
    aaac:	aa1403e0 	mov	x0, x20
    aab0:	97ffea81 	bl	54b4 <fwp_rc_free_arr>
    aab4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aab8:	f95f7c06 	ldr	x6, [x0, #16120]
    aabc:	17fffe7a 	b	a4a4 <fwp_main_thread+0x1044>
    aac0:	b9030a9f 	str	wzr, [x20, #776]
    aac4:	b4ff69a0 	cbz	x0, 97f8 <fwp_main_thread+0x398>
    aac8:	97ffdf5e 	bl	2840 <abort@plt>
    aacc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aad0:	f91f7c06 	str	x6, [x0, #16120]
    aad4:	aa1a03e0 	mov	x0, x26
    aad8:	97ffe686 	bl	44f0 <fwp_rc_forget_slot>
    aadc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aae0:	f95f7c06 	ldr	x6, [x0, #16120]
    aae4:	17fffe3b 	b	a3d0 <fwp_main_thread+0xf70>
    aae8:	b0000000 	adrp	x0, b000 <__modti3+0x180>
    aaec:	91132000 	add	x0, x0, #0x4c8
    aaf0:	97ffe284 	bl	3500 <fwp_trap>
    aaf4:	d503201f 	nop
    aaf8:	d503201f 	nop
    aafc:	d503201f 	nop

000000000000ab00 <__divti3>:
    ab00:	d503245f 	bti	c
    ab04:	d2800004 	mov	x4, #0x0                   	// #0
    ab08:	b7f80721 	tbnz	x1, #63, abec <__divti3+0xec>
    ab0c:	b6f80083 	tbz	x3, #63, ab1c <__divti3+0x1c>
    ab10:	eb0203e2 	negs	x2, x2
    ab14:	aa2403e4 	mvn	x4, x4
    ab18:	da0303e3 	ngc	x3, x3
    ab1c:	aa0203e6 	mov	x6, x2
    ab20:	aa0003e7 	mov	x7, x0
    ab24:	aa0103e5 	mov	x5, x1
    ab28:	b5000583 	cbnz	x3, abd8 <__divti3+0xd8>
    ab2c:	eb01005f 	cmp	x2, x1
    ab30:	54000e69 	b.ls	acfc <__divti3+0x1fc>  // b.plast
    ab34:	dac01040 	clz	x0, x2
    ab38:	b40000e0 	cbz	x0, ab54 <__divti3+0x54>
    ab3c:	4b0003e1 	neg	w1, w0
    ab40:	9ac020a5 	lsl	x5, x5, x0
    ab44:	9ac02046 	lsl	x6, x2, x0
    ab48:	9ac124e1 	lsr	x1, x7, x1
    ab4c:	aa050025 	orr	x5, x1, x5
    ab50:	9ac020e7 	lsl	x7, x7, x0
    ab54:	d360fcc8 	lsr	x8, x6, #32
    ab58:	92407cc2 	and	x2, x6, #0xffffffff
    ab5c:	9ac808a3 	udiv	x3, x5, x8
    ab60:	9b089465 	msub	x5, x3, x8, x5
    ab64:	aa0303e0 	mov	x0, x3
    ab68:	9b037c41 	mul	x1, x2, x3
    ab6c:	93c780a5 	extr	x5, x5, x7, #32
    ab70:	eb05003f 	cmp	x1, x5
    ab74:	540000a9 	b.ls	ab88 <__divti3+0x88>  // b.plast
    ab78:	ab0500c5 	adds	x5, x6, x5
    ab7c:	d1000460 	sub	x0, x3, #0x1
    ab80:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ab84:	540015a8 	b.hi	ae38 <__divti3+0x338>  // b.pmore
    ab88:	cb0100a5 	sub	x5, x5, x1
    ab8c:	9ac808a3 	udiv	x3, x5, x8
    ab90:	9b089465 	msub	x5, x3, x8, x5
    ab94:	aa0303e1 	mov	x1, x3
    ab98:	9b037c42 	mul	x2, x2, x3
    ab9c:	aa0703e3 	mov	x3, x7
    aba0:	b3607ca3 	bfi	x3, x5, #32, #32
    aba4:	eb03005f 	cmp	x2, x3
    aba8:	540000c9 	b.ls	abc0 <__divti3+0xc0>  // b.plast
    abac:	ab0300c3 	adds	x3, x6, x3
    abb0:	d1000425 	sub	x5, x1, #0x1
    abb4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    abb8:	d1000821 	sub	x1, x1, #0x2
    abbc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    abc0:	aa008020 	orr	x0, x1, x0, lsl #32
    abc4:	d2800001 	mov	x1, #0x0                   	// #0
    abc8:	b4000064 	cbz	x4, abd4 <__divti3+0xd4>
    abcc:	eb0003e0 	negs	x0, x0
    abd0:	da0103e1 	ngc	x1, x1
    abd4:	d65f03c0 	ret
    abd8:	eb01007f 	cmp	x3, x1
    abdc:	54000109 	b.ls	abfc <__divti3+0xfc>  // b.plast
    abe0:	d2800001 	mov	x1, #0x0                   	// #0
    abe4:	d2800000 	mov	x0, #0x0                   	// #0
    abe8:	17fffff8 	b	abc8 <__divti3+0xc8>
    abec:	eb0003e0 	negs	x0, x0
    abf0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    abf4:	da0103e1 	ngc	x1, x1
    abf8:	17ffffc5 	b	ab0c <__divti3+0xc>
    abfc:	dac01067 	clz	x7, x3
    ac00:	b40010e7 	cbz	x7, ae1c <__divti3+0x31c>
    ac04:	d2800805 	mov	x5, #0x40                  	// #64
    ac08:	cb0700a5 	sub	x5, x5, x7
    ac0c:	9ac72063 	lsl	x3, x3, x7
    ac10:	9ac52448 	lsr	x8, x2, x5
    ac14:	aa030108 	orr	x8, x8, x3
    ac18:	9ac52426 	lsr	x6, x1, x5
    ac1c:	92407d0a 	and	x10, x8, #0xffffffff
    ac20:	d360fd09 	lsr	x9, x8, #32
    ac24:	9ac52403 	lsr	x3, x0, x5
    ac28:	9ac72021 	lsl	x1, x1, x7
    ac2c:	aa010063 	orr	x3, x3, x1
    ac30:	9ac72042 	lsl	x2, x2, x7
    ac34:	9ac908cb 	udiv	x11, x6, x9
    ac38:	9b099965 	msub	x5, x11, x9, x6
    ac3c:	aa0b03e1 	mov	x1, x11
    ac40:	9b0b7d46 	mul	x6, x10, x11
    ac44:	93c380a5 	extr	x5, x5, x3, #32
    ac48:	eb0500df 	cmp	x6, x5
    ac4c:	540000a9 	b.ls	ac60 <__divti3+0x160>  // b.plast
    ac50:	ab050105 	adds	x5, x8, x5
    ac54:	d1000561 	sub	x1, x11, #0x1
    ac58:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ac5c:	54000f48 	b.hi	ae44 <__divti3+0x344>  // b.pmore
    ac60:	cb0600a6 	sub	x6, x5, x6
    ac64:	9ac908cb 	udiv	x11, x6, x9
    ac68:	9b099969 	msub	x9, x11, x9, x6
    ac6c:	aa0b03e5 	mov	x5, x11
    ac70:	9b0b7d4a 	mul	x10, x10, x11
    ac74:	b3607d23 	bfi	x3, x9, #32, #32
    ac78:	eb03015f 	cmp	x10, x3
    ac7c:	540000a9 	b.ls	ac90 <__divti3+0x190>  // b.plast
    ac80:	ab030103 	adds	x3, x8, x3
    ac84:	d1000565 	sub	x5, x11, #0x1
    ac88:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ac8c:	54000e28 	b.hi	ae50 <__divti3+0x350>  // b.pmore
    ac90:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ac94:	92407c48 	and	x8, x2, #0xffffffff
    ac98:	2a0503e5 	mov	w5, w5
    ac9c:	d360fc42 	lsr	x2, x2, #32
    aca0:	d360fc26 	lsr	x6, x1, #32
    aca4:	cb0a0063 	sub	x3, x3, x10
    aca8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    acac:	9b087caa 	mul	x10, x5, x8
    acb0:	9b087cc8 	mul	x8, x6, x8
    acb4:	9b0220a5 	madd	x5, x5, x2, x8
    acb8:	9b027cc6 	mul	x6, x6, x2
    acbc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    acc0:	8b0900c5 	add	x5, x6, x9
    acc4:	eb02011f 	cmp	x8, x2
    acc8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    accc:	8b4280c6 	add	x6, x6, x2, lsr #32
    acd0:	eb06007f 	cmp	x3, x6
    acd4:	540000e3 	b.cc	acf0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    acd8:	92407d4a 	and	x10, x10, #0xffffffff
    acdc:	9ac72000 	lsl	x0, x0, x7
    ace0:	8b028142 	add	x2, x10, x2, lsl #32
    ace4:	eb02001f 	cmp	x0, x2
    ace8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    acec:	54000a01 	b.ne	ae2c <__divti3+0x32c>  // b.any
    acf0:	d1000420 	sub	x0, x1, #0x1
    acf4:	d2800001 	mov	x1, #0x0                   	// #0
    acf8:	17ffffb4 	b	abc8 <__divti3+0xc8>
    acfc:	b5000062 	cbnz	x2, ad08 <__divti3+0x208>
    ad00:	d2800022 	mov	x2, #0x1                   	// #1
    ad04:	9ac30846 	udiv	x6, x2, x3
    ad08:	dac010c8 	clz	x8, x6
    ad0c:	b5000408 	cbnz	x8, ad8c <__divti3+0x28c>
    ad10:	d360fcc9 	lsr	x9, x6, #32
    ad14:	92407cc5 	and	x5, x6, #0xffffffff
    ad18:	cb060023 	sub	x3, x1, x6
    ad1c:	d2800021 	mov	x1, #0x1                   	// #1
    ad20:	9ac90868 	udiv	x8, x3, x9
    ad24:	9b098d03 	msub	x3, x8, x9, x3
    ad28:	aa0803e0 	mov	x0, x8
    ad2c:	9b057d02 	mul	x2, x8, x5
    ad30:	93c78063 	extr	x3, x3, x7, #32
    ad34:	eb03005f 	cmp	x2, x3
    ad38:	540000a9 	b.ls	ad4c <__divti3+0x24c>  // b.plast
    ad3c:	ab0300c3 	adds	x3, x6, x3
    ad40:	d1000500 	sub	x0, x8, #0x1
    ad44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ad48:	54000968 	b.hi	ae74 <__divti3+0x374>  // b.pmore
    ad4c:	cb020063 	sub	x3, x3, x2
    ad50:	9ac90862 	udiv	x2, x3, x9
    ad54:	aa0203e8 	mov	x8, x2
    ad58:	9b098c42 	msub	x2, x2, x9, x3
    ad5c:	aa0703e3 	mov	x3, x7
    ad60:	9b057d05 	mul	x5, x8, x5
    ad64:	b3607c43 	bfi	x3, x2, #32, #32
    ad68:	eb0300bf 	cmp	x5, x3
    ad6c:	540000c9 	b.ls	ad84 <__divti3+0x284>  // b.plast
    ad70:	ab0300c2 	adds	x2, x6, x3
    ad74:	d1000503 	sub	x3, x8, #0x1
    ad78:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ad7c:	d1000908 	sub	x8, x8, #0x2
    ad80:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ad84:	aa008100 	orr	x0, x8, x0, lsl #32
    ad88:	17ffff90 	b	abc8 <__divti3+0xc8>
    ad8c:	9ac820c6 	lsl	x6, x6, x8
    ad90:	d2800803 	mov	x3, #0x40                  	// #64
    ad94:	cb080063 	sub	x3, x3, x8
    ad98:	d360fcc9 	lsr	x9, x6, #32
    ad9c:	9ac82027 	lsl	x7, x1, x8
    ada0:	92407cc5 	and	x5, x6, #0xffffffff
    ada4:	9ac32422 	lsr	x2, x1, x3
    ada8:	9ac32403 	lsr	x3, x0, x3
    adac:	aa070063 	orr	x3, x3, x7
    adb0:	9ac9084a 	udiv	x10, x2, x9
    adb4:	9ac82007 	lsl	x7, x0, x8
    adb8:	9b098940 	msub	x0, x10, x9, x2
    adbc:	aa0a03e1 	mov	x1, x10
    adc0:	9b0a7ca2 	mul	x2, x5, x10
    adc4:	93c38000 	extr	x0, x0, x3, #32
    adc8:	eb00005f 	cmp	x2, x0
    adcc:	540000a9 	b.ls	ade0 <__divti3+0x2e0>  // b.plast
    add0:	ab0000c0 	adds	x0, x6, x0
    add4:	d1000541 	sub	x1, x10, #0x1
    add8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    addc:	54000468 	b.hi	ae68 <__divti3+0x368>  // b.pmore
    ade0:	cb020000 	sub	x0, x0, x2
    ade4:	9ac9080a 	udiv	x10, x0, x9
    ade8:	9b098140 	msub	x0, x10, x9, x0
    adec:	aa0a03e2 	mov	x2, x10
    adf0:	9b0a7ca8 	mul	x8, x5, x10
    adf4:	b3607c03 	bfi	x3, x0, #32, #32
    adf8:	eb03011f 	cmp	x8, x3
    adfc:	540000a9 	b.ls	ae10 <__divti3+0x310>  // b.plast
    ae00:	ab0300c3 	adds	x3, x6, x3
    ae04:	d1000542 	sub	x2, x10, #0x1
    ae08:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    ae0c:	54000288 	b.hi	ae5c <__divti3+0x35c>  // b.pmore
    ae10:	cb080063 	sub	x3, x3, x8
    ae14:	aa018041 	orr	x1, x2, x1, lsl #32
    ae18:	17ffffc2 	b	ad20 <__divti3+0x220>
    ae1c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ae20:	d2800001 	mov	x1, #0x0                   	// #0
    ae24:	9a9f87e0 	cset	x0, ls	// ls = plast
    ae28:	17ffff68 	b	abc8 <__divti3+0xc8>
    ae2c:	aa0103e0 	mov	x0, x1
    ae30:	d2800001 	mov	x1, #0x0                   	// #0
    ae34:	17ffff65 	b	abc8 <__divti3+0xc8>
    ae38:	d1000860 	sub	x0, x3, #0x2
    ae3c:	8b0600a5 	add	x5, x5, x6
    ae40:	17ffff52 	b	ab88 <__divti3+0x88>
    ae44:	d1000961 	sub	x1, x11, #0x2
    ae48:	8b0800a5 	add	x5, x5, x8
    ae4c:	17ffff85 	b	ac60 <__divti3+0x160>
    ae50:	d1000965 	sub	x5, x11, #0x2
    ae54:	8b080063 	add	x3, x3, x8
    ae58:	17ffff8e 	b	ac90 <__divti3+0x190>
    ae5c:	d1000942 	sub	x2, x10, #0x2
    ae60:	8b060063 	add	x3, x3, x6
    ae64:	17ffffeb 	b	ae10 <__divti3+0x310>
    ae68:	d1000941 	sub	x1, x10, #0x2
    ae6c:	8b060000 	add	x0, x0, x6
    ae70:	17ffffdc 	b	ade0 <__divti3+0x2e0>
    ae74:	d1000900 	sub	x0, x8, #0x2
    ae78:	8b060063 	add	x3, x3, x6
    ae7c:	17ffffb4 	b	ad4c <__divti3+0x24c>

000000000000ae80 <__modti3>:
    ae80:	d503245f 	bti	c
    ae84:	d2800004 	mov	x4, #0x0                   	// #0
    ae88:	b6f80081 	tbz	x1, #63, ae98 <__modti3+0x18>
    ae8c:	eb0003e0 	negs	x0, x0
    ae90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ae94:	da0103e1 	ngc	x1, x1
    ae98:	f100007f 	cmp	x3, #0x0
    ae9c:	5400128b 	b.lt	b0ec <__modti3+0x26c>  // b.tstop
    aea0:	aa0003e7 	mov	x7, x0
    aea4:	aa0103e6 	mov	x6, x1
    aea8:	540004e1 	b.ne	af44 <__modti3+0xc4>  // b.any
    aeac:	eb02003f 	cmp	x1, x2
    aeb0:	54000dc2 	b.cs	b068 <__modti3+0x1e8>  // b.hs, b.nlast
    aeb4:	dac01043 	clz	x3, x2
    aeb8:	aa0303e5 	mov	x5, x3
    aebc:	b40000e3 	cbz	x3, aed8 <__modti3+0x58>
    aec0:	4b0303e6 	neg	w6, w3
    aec4:	9ac32021 	lsl	x1, x1, x3
    aec8:	9ac32042 	lsl	x2, x2, x3
    aecc:	9ac62406 	lsr	x6, x0, x6
    aed0:	aa0100c6 	orr	x6, x6, x1
    aed4:	9ac32007 	lsl	x7, x0, x3
    aed8:	d360fc40 	lsr	x0, x2, #32
    aedc:	92407c43 	and	x3, x2, #0xffffffff
    aee0:	9ac008c1 	udiv	x1, x6, x0
    aee4:	9b009826 	msub	x6, x1, x0, x6
    aee8:	9b017c61 	mul	x1, x3, x1
    aeec:	93c780c6 	extr	x6, x6, x7, #32
    aef0:	eb06003f 	cmp	x1, x6
    aef4:	540000a9 	b.ls	af08 <__modti3+0x88>  // b.plast
    aef8:	ab060046 	adds	x6, x2, x6
    aefc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    af00:	8b0200c8 	add	x8, x6, x2
    af04:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    af08:	cb0100c6 	sub	x6, x6, x1
    af0c:	9ac008c8 	udiv	x8, x6, x0
    af10:	9b009901 	msub	x1, x8, x0, x6
    af14:	aa0703e0 	mov	x0, x7
    af18:	9b087c63 	mul	x3, x3, x8
    af1c:	b3607c20 	bfi	x0, x1, #32, #32
    af20:	eb00007f 	cmp	x3, x0
    af24:	54001088 	b.hi	b134 <__modti3+0x2b4>  // b.pmore
    af28:	cb030000 	sub	x0, x0, x3
    af2c:	9ac52400 	lsr	x0, x0, x5
    af30:	d2800001 	mov	x1, #0x0                   	// #0
    af34:	b4000064 	cbz	x4, af40 <__modti3+0xc0>
    af38:	eb0003e0 	negs	x0, x0
    af3c:	da0103e1 	ngc	x1, x1
    af40:	d65f03c0 	ret
    af44:	dac01066 	clz	x6, x3
    af48:	eb03003f 	cmp	x1, x3
    af4c:	54ffff43 	b.cc	af34 <__modti3+0xb4>  // b.lo, b.ul, b.last
    af50:	93407cc5 	sxtw	x5, w6
    af54:	d2800808 	mov	x8, #0x40                  	// #64
    af58:	cb050108 	sub	x8, x8, x5
    af5c:	9ac62063 	lsl	x3, x3, x6
    af60:	9ac62025 	lsl	x5, x1, x6
    af64:	9ac82447 	lsr	x7, x2, x8
    af68:	aa0300e7 	orr	x7, x7, x3
    af6c:	9ac82423 	lsr	x3, x1, x8
    af70:	92407cec 	and	x12, x7, #0xffffffff
    af74:	d360fcea 	lsr	x10, x7, #32
    af78:	9ac82401 	lsr	x1, x0, x8
    af7c:	aa050021 	orr	x1, x1, x5
    af80:	9ac62042 	lsl	x2, x2, x6
    af84:	9ac62000 	lsl	x0, x0, x6
    af88:	9aca086b 	udiv	x11, x3, x10
    af8c:	9b0a8d63 	msub	x3, x11, x10, x3
    af90:	aa0b03e5 	mov	x5, x11
    af94:	9b0b7d89 	mul	x9, x12, x11
    af98:	93c18063 	extr	x3, x3, x1, #32
    af9c:	eb03013f 	cmp	x9, x3
    afa0:	540000a9 	b.ls	afb4 <__modti3+0x134>  // b.plast
    afa4:	ab0300e3 	adds	x3, x7, x3
    afa8:	d1000565 	sub	x5, x11, #0x1
    afac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    afb0:	54001168 	b.hi	b1dc <__modti3+0x35c>  // b.pmore
    afb4:	cb090063 	sub	x3, x3, x9
    afb8:	9aca086b 	udiv	x11, x3, x10
    afbc:	9b0a8d6a 	msub	x10, x11, x10, x3
    afc0:	aa0b03e9 	mov	x9, x11
    afc4:	9b0b7d8c 	mul	x12, x12, x11
    afc8:	b3607d41 	bfi	x1, x10, #32, #32
    afcc:	eb01019f 	cmp	x12, x1
    afd0:	540000a9 	b.ls	afe4 <__modti3+0x164>  // b.plast
    afd4:	ab0100e1 	adds	x1, x7, x1
    afd8:	d1000569 	sub	x9, x11, #0x1
    afdc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    afe0:	54000f88 	b.hi	b1d0 <__modti3+0x350>  // b.pmore
    afe4:	aa058123 	orr	x3, x9, x5, lsl #32
    afe8:	92407c4b 	and	x11, x2, #0xffffffff
    afec:	2a0903e9 	mov	w9, w9
    aff0:	d360fc4a 	lsr	x10, x2, #32
    aff4:	d360fc63 	lsr	x3, x3, #32
    aff8:	cb0c0021 	sub	x1, x1, x12
    affc:	aa0a03ec 	mov	x12, x10
    b000:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b004:	9b0b7d25 	mul	x5, x9, x11
    b008:	9b0b7c6b 	mul	x11, x3, x11
    b00c:	9b0a2d29 	madd	x9, x9, x10, x11
    b010:	92407caa 	and	x10, x5, #0xffffffff
    b014:	9b0c7c63 	mul	x3, x3, x12
    b018:	8b458125 	add	x5, x9, x5, lsr #32
    b01c:	8b0d0069 	add	x9, x3, x13
    b020:	eb05017f 	cmp	x11, x5
    b024:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b028:	8b058149 	add	x9, x10, x5, lsl #32
    b02c:	8b458063 	add	x3, x3, x5, lsr #32
    b030:	eb03003f 	cmp	x1, x3
    b034:	54000063 	b.cc	b040 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b038:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b03c:	54000082 	b.cs	b04c <__modti3+0x1cc>  // b.hs, b.nlast
    b040:	eb020129 	subs	x9, x9, x2
    b044:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b048:	cb070063 	sub	x3, x3, x7
    b04c:	eb090000 	subs	x0, x0, x9
    b050:	da030021 	sbc	x1, x1, x3
    b054:	9ac62400 	lsr	x0, x0, x6
    b058:	9ac82028 	lsl	x8, x1, x8
    b05c:	aa000100 	orr	x0, x8, x0
    b060:	9ac62421 	lsr	x1, x1, x6
    b064:	17ffffb4 	b	af34 <__modti3+0xb4>
    b068:	b5000062 	cbnz	x2, b074 <__modti3+0x1f4>
    b06c:	d2800023 	mov	x3, #0x1                   	// #1
    b070:	9ac20862 	udiv	x2, x3, x2
    b074:	dac01048 	clz	x8, x2
    b078:	aa0803e5 	mov	x5, x8
    b07c:	b5000668 	cbnz	x8, b148 <__modti3+0x2c8>
    b080:	cb020020 	sub	x0, x1, x2
    b084:	d360fc49 	lsr	x9, x2, #32
    b088:	92407c4a 	and	x10, x2, #0xffffffff
    b08c:	9ac90801 	udiv	x1, x0, x9
    b090:	9b098020 	msub	x0, x1, x9, x0
    b094:	9b0a7c21 	mul	x1, x1, x10
    b098:	93c78000 	extr	x0, x0, x7, #32
    b09c:	eb00003f 	cmp	x1, x0
    b0a0:	540000a9 	b.ls	b0b4 <__modti3+0x234>  // b.plast
    b0a4:	ab000040 	adds	x0, x2, x0
    b0a8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b0ac:	8b020003 	add	x3, x0, x2
    b0b0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b0b4:	cb010001 	sub	x1, x0, x1
    b0b8:	9ac90820 	udiv	x0, x1, x9
    b0bc:	9b098403 	msub	x3, x0, x9, x1
    b0c0:	aa0703e1 	mov	x1, x7
    b0c4:	9b0a7c00 	mul	x0, x0, x10
    b0c8:	b3607c61 	bfi	x1, x3, #32, #32
    b0cc:	eb01001f 	cmp	x0, x1
    b0d0:	540000a9 	b.ls	b0e4 <__modti3+0x264>  // b.plast
    b0d4:	ab010041 	adds	x1, x2, x1
    b0d8:	8b020022 	add	x2, x1, x2
    b0dc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b0e0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b0e4:	cb000020 	sub	x0, x1, x0
    b0e8:	17ffff91 	b	af2c <__modti3+0xac>
    b0ec:	eb0203e5 	negs	x5, x2
    b0f0:	aa0003e7 	mov	x7, x0
    b0f4:	da0303e8 	ngc	x8, x3
    b0f8:	aa0503e2 	mov	x2, x5
    b0fc:	aa0803e3 	mov	x3, x8
    b100:	aa0103e6 	mov	x6, x1
    b104:	b4ffed48 	cbz	x8, aeac <__modti3+0x2c>
    b108:	eb01011f 	cmp	x8, x1
    b10c:	54fff148 	b.hi	af34 <__modti3+0xb4>  // b.pmore
    b110:	dac01109 	clz	x9, x8
    b114:	2a0903e6 	mov	w6, w9
    b118:	b5fff1c9 	cbnz	x9, af50 <__modti3+0xd0>
    b11c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b120:	54000068 	b.hi	b12c <__modti3+0x2ac>  // b.pmore
    b124:	eb050007 	subs	x7, x0, x5
    b128:	da080021 	sbc	x1, x1, x8
    b12c:	aa0703e0 	mov	x0, x7
    b130:	17ffff81 	b	af34 <__modti3+0xb4>
    b134:	ab000040 	adds	x0, x2, x0
    b138:	8b020002 	add	x2, x0, x2
    b13c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b140:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b144:	17ffff79 	b	af28 <__modti3+0xa8>
    b148:	9ac82042 	lsl	x2, x2, x8
    b14c:	d2800803 	mov	x3, #0x40                  	// #64
    b150:	cb080063 	sub	x3, x3, x8
    b154:	d360fc49 	lsr	x9, x2, #32
    b158:	9ac82027 	lsl	x7, x1, x8
    b15c:	92407c4a 	and	x10, x2, #0xffffffff
    b160:	9ac32426 	lsr	x6, x1, x3
    b164:	9ac32403 	lsr	x3, x0, x3
    b168:	aa070063 	orr	x3, x3, x7
    b16c:	9ac908c1 	udiv	x1, x6, x9
    b170:	9ac82007 	lsl	x7, x0, x8
    b174:	9b099820 	msub	x0, x1, x9, x6
    b178:	9b017d41 	mul	x1, x10, x1
    b17c:	93c38000 	extr	x0, x0, x3, #32
    b180:	eb00003f 	cmp	x1, x0
    b184:	540000a9 	b.ls	b198 <__modti3+0x318>  // b.plast
    b188:	ab000040 	adds	x0, x2, x0
    b18c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b190:	8b020006 	add	x6, x0, x2
    b194:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b198:	cb010000 	sub	x0, x0, x1
    b19c:	9ac90801 	udiv	x1, x0, x9
    b1a0:	9b098026 	msub	x6, x1, x9, x0
    b1a4:	aa0303e0 	mov	x0, x3
    b1a8:	9b017d41 	mul	x1, x10, x1
    b1ac:	b3607cc0 	bfi	x0, x6, #32, #32
    b1b0:	eb00003f 	cmp	x1, x0
    b1b4:	540000a9 	b.ls	b1c8 <__modti3+0x348>  // b.plast
    b1b8:	ab000040 	adds	x0, x2, x0
    b1bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b1c0:	8b020003 	add	x3, x0, x2
    b1c4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b1c8:	cb010000 	sub	x0, x0, x1
    b1cc:	17ffffb0 	b	b08c <__modti3+0x20c>
    b1d0:	d1000969 	sub	x9, x11, #0x2
    b1d4:	8b070021 	add	x1, x1, x7
    b1d8:	17ffff83 	b	afe4 <__modti3+0x164>
    b1dc:	d1000965 	sub	x5, x11, #0x2
    b1e0:	8b070063 	add	x3, x3, x7
    b1e4:	17ffff74 	b	afb4 <__modti3+0x134>
    b1e8:	d503201f 	nop
    b1ec:	d503201f 	nop

000000000000b1f0 <atexit>:
    b1f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b1f4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b1f8:	d2800001 	mov	x1, #0x0                   	// #0
    b1fc:	910003fd 	mov	x29, sp
    b200:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b204:	f9400442 	ldr	x2, [x2, #8]
    b208:	17ffdd3a 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b20c <_fini>:
    b20c:	d503201f 	nop
    b210:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b214:	910003fd 	mov	x29, sp
    b218:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b21c:	d65f03c0 	ret
