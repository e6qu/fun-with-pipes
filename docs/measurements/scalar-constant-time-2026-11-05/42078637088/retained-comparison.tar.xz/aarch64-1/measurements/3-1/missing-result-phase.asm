
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/missing-result-phase:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	90000045 	adrp	x5, a000 <fwp_main_thread+0x2000>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	913420a5 	add	x5, x5, #0xd08
    2b20:	90000044 	adrp	x4, a000 <fwp_main_thread+0x2000>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91344084 	add	x4, x4, #0xd10
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11480>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2bb4:	9103a000 	add	x0, x0, #0xe8
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_main_thread>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91000042 	add	x2, x2, #0x0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2cfc:	9103e000 	add	x0, x0, #0xf8
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2d0c:	91066000 	add	x0, x0, #0x198
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2d24:	9105c000 	add	x0, x0, #0x170
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2d30:	91050000 	add	x0, x0, #0x140
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    2d3c:	91046000 	add	x0, x0, #0x118
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x5b0>
    2f34:	91208021 	add	x1, x1, #0x820
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    30d0:	91296000 	add	x0, x0, #0xa58
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x5b0>
    3198:	91200021 	add	x1, x1, #0x800
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    31d0:	9129c000 	add	x0, x0, #0xa70
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x2000>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x2000>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x5b0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	912ae042 	add	x2, x2, #0xab8
    3260:	912c42d6 	add	x22, x22, #0xb10
    3264:	91168318 	add	x24, x24, #0x5a0
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x2000>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	912c2323 	add	x3, x25, #0xb08
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	912c8000 	add	x0, x0, #0xb20
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    35f0:	91296000 	add	x0, x0, #0xa58
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2000>
    3830:	aa1303e0 	mov	x0, x19
    3834:	912ca021 	add	x1, x1, #0xb28
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2000>
    3844:	aa1303e0 	mov	x0, x19
    3848:	912cc021 	add	x1, x1, #0xb30
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2000>
    3860:	912ce021 	add	x1, x1, #0xb38
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x2000>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	912d0042 	add	x2, x2, #0xb40
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    39d0:	91296000 	add	x0, x0, #0xa58
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    39f0:	912d4000 	add	x0, x0, #0xb50
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    3a88:	912dc000 	add	x0, x0, #0xb70
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    3a98:	912e4000 	add	x0, x0, #0xb90
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x5b0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc20c20 	ldr	q0, [x1, #2096]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    3b98:	912ee000 	add	x0, x0, #0xbb8
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    3c08:	912fa000 	add	x0, x0, #0xbe8
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2000>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9130e084 	add	x4, x4, #0xc38
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2000>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91314084 	add	x4, x4, #0xc50
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2000>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91310084 	add	x4, x4, #0xc40
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	d0000021 	adrp	x1, a000 <fwp_main_thread+0x2000>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	91316021 	add	x1, x1, #0xc58
    4084:	91318000 	add	x0, x0, #0xc60
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	d0000022 	adrp	x2, a000 <fwp_main_thread+0x2000>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91320042 	add	x2, x2, #0xc80
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x5b0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc21043 	ldr	q3, [x2, #2112]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    42e8:	9134c000 	add	x0, x0, #0xd30
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    444c:	91350000 	add	x0, x0, #0xd40
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	91350000 	add	x0, x0, #0xd40
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	91350000 	add	x0, x0, #0xd40
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    473c:	91356000 	add	x0, x0, #0xd58
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    47f4:	9136c000 	add	x0, x0, #0xdb0
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    4850:	91362000 	add	x0, x0, #0xd88
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    4860:	91376000 	add	x0, x0, #0xdd8
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    4900:	9136c000 	add	x0, x0, #0xdb0
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	54000e8b 	b.lt	537c <fwp_p_ad_push+0x1d8>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	aa0003e4 	mov	x4, x0
    51b8:	910003fd 	mov	x29, sp
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0003f5 	mov	x21, x0
    51c4:	aa020000 	orr	x0, x0, x2
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f7 	mov	x23, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	b6f80900 	tbz	x0, #63, 52fc <fwp_p_ad_push+0x158>
    51e0:	a90153f3 	stp	x19, x20, [sp, #16]
    51e4:	9360fc80 	asr	x0, x4, #32
    51e8:	b6f800c4 	tbz	x4, #63, 5200 <fwp_p_ad_push+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc40 	asr	x0, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5200:	97fffa6c 	bl	3bb0 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5001280 	cbnz	x0, 545c <fwp_p_ad_push+0x2b8>
    5210:	f9400a76 	ldr	x22, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002df 	cmp	x22, x0
    521c:	54000e2c 	b.gt	53e0 <fwp_p_ad_push+0x23c>
    5220:	eb3542df 	cmp	x22, w21, uxtw
    5224:	54000d4d 	b.le	53cc <fwp_p_ad_push+0x228>
    5228:	b7f80077 	tbnz	x23, #63, 5234 <fwp_p_ad_push+0x90>
    522c:	eb3742df 	cmp	x22, w23, uxtw
    5230:	54000ced 	b.le	53cc <fwp_p_ad_push+0x228>
    5234:	f9400678 	ldr	x24, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1802d8 	sub	x24, x22, x24
    5240:	91000701 	add	x1, x24, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000cc8 	b.hi	53e0 <fwp_p_ad_push+0x23c>  // b.pmore
    524c:	a9418274 	ldp	x20, x0, [x19, #24]
    5250:	a90573fb 	stp	x27, x28, [sp, #80]
    5254:	eb14003f 	cmp	x1, x20
    5258:	5400068d 	b.le	5328 <fwp_p_ad_push+0x184>
    525c:	f100029f 	cmp	x20, #0x0
    5260:	d2800803 	mov	x3, #0x40                  	// #64
    5264:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5268:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    526c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5270:	eb14003f 	cmp	x1, x20
    5274:	5400008d 	b.le	5284 <fwp_p_ad_push+0xe0>
    5278:	eb02029f 	cmp	x20, x2
    527c:	5400052d 	b.le	5320 <fwp_p_ad_push+0x17c>
    5280:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5284:	d37df299 	lsl	x25, x20, #3
    5288:	aa1903e1 	mov	x1, x25
    528c:	97fff59d 	bl	2900 <realloc@plt>
    5290:	aa0003e1 	mov	x1, x0
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    5298:	f9400e62 	ldr	x2, [x19, #24]
    529c:	f9001261 	str	x1, [x19, #32]
    52a0:	f9401a60 	ldr	x0, [x19, #48]
    52a4:	d37cee9a 	lsl	x26, x20, #4
    52a8:	8b020821 	add	x1, x1, x2, lsl #2
    52ac:	f9001661 	str	x1, [x19, #40]
    52b0:	aa1a03e1 	mov	x1, x26
    52b4:	97fff593 	bl	2900 <realloc@plt>
    52b8:	aa0003e2 	mov	x2, x0
    52bc:	b40009c0 	cbz	x0, 53f4 <fwp_p_ad_push+0x250>
    52c0:	f9400e61 	ldr	x1, [x19, #24]
    52c4:	d37df31b 	lsl	x27, x24, #3
    52c8:	d37ef685 	lsl	x5, x20, #2
    52cc:	d37ef71c 	lsl	x28, x24, #2
    52d0:	8b190004 	add	x4, x0, x25
    52d4:	8b010c01 	add	x1, x0, x1, lsl #3
    52d8:	a9030660 	stp	x0, x1, [x19, #48]
    52dc:	b5000558 	cbnz	x24, 5384 <fwp_p_ad_push+0x1e0>
    52e0:	f9001e64 	str	x4, [x19, #56]
    52e4:	f9401260 	ldr	x0, [x19, #32]
    52e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    52ec:	8b050001 	add	x1, x0, x5
    52f0:	f9000e74 	str	x20, [x19, #24]
    52f4:	f9001661 	str	x1, [x19, #40]
    52f8:	14000010 	b	5338 <fwp_p_ad_push+0x194>
    52fc:	9360fc40 	asr	x0, x2, #32
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	eb84801f 	cmp	x0, x4, asr #32
    5308:	54fff7c0 	b.eq	5200 <fwp_p_ad_push+0x5c>  // b.none
    530c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5310:	9137e000 	add	x0, x0, #0xdf8
    5314:	a9046bf9 	stp	x25, x26, [sp, #64]
    5318:	a90573fb 	stp	x27, x28, [sp, #80]
    531c:	97fff959 	bl	3880 <fwp_trap>
    5320:	d37ffa94 	lsl	x20, x20, #1
    5324:	17ffffd3 	b	5270 <fwp_p_ad_push+0xcc>
    5328:	a9428a61 	ldp	x1, x2, [x19, #40]
    532c:	d37ef71c 	lsl	x28, x24, #2
    5330:	f9401e64 	ldr	x4, [x19, #56]
    5334:	d37df31b 	lsl	x27, x24, #3
    5338:	b83c6815 	str	w21, [x0, x28]
    533c:	f10002ff 	cmp	x23, #0x0
    5340:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5344:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5348:	fc3b6849 	str	d9, [x2, x27]
    534c:	aa1602a0 	orr	x0, x21, x22
    5350:	b83c6837 	str	w23, [x1, x28]
    5354:	910006d6 	add	x22, x22, #0x1
    5358:	a94363f7 	ldp	x23, x24, [sp, #48]
    535c:	fc3b6888 	str	d8, [x4, x27]
    5360:	a94573fb 	ldp	x27, x28, [sp, #80]
    5364:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5368:	f9000a76 	str	x22, [x19, #16]
    536c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5378:	d65f03c0 	ret
    537c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5380:	d65f03c0 	ret
    5384:	eb1a033f 	cmp	x25, x26
    5388:	aa0403e0 	mov	x0, x4
    538c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5390:	aa1b03e2 	mov	x2, x27
    5394:	cb190063 	sub	x3, x3, x25
    5398:	f9003fe5 	str	x5, [sp, #120]
    539c:	97fff5c5 	bl	2ab0 <__memmove_chk@plt>
    53a0:	a9420660 	ldp	x0, x1, [x19, #32]
    53a4:	aa1c03e2 	mov	x2, x28
    53a8:	f9401a63 	ldr	x3, [x19, #48]
    53ac:	f9403fe5 	ldr	x5, [sp, #120]
    53b0:	8b190063 	add	x3, x3, x25
    53b4:	f9001e63 	str	x3, [x19, #56]
    53b8:	8b050000 	add	x0, x0, x5
    53bc:	97fff4f1 	bl	2780 <memmove@plt>
    53c0:	a9431262 	ldp	x2, x4, [x19, #48]
    53c4:	f9403fe5 	ldr	x5, [sp, #120]
    53c8:	17ffffc7 	b	52e4 <fwp_p_ad_push+0x140>
    53cc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    53d0:	913a4000 	add	x0, x0, #0xe90
    53d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53d8:	a90573fb 	stp	x27, x28, [sp, #80]
    53dc:	97fff929 	bl	3880 <fwp_trap>
    53e0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    53e4:	9139c000 	add	x0, x0, #0xe70
    53e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53ec:	a90573fb 	stp	x27, x28, [sp, #80]
    53f0:	97fff924 	bl	3880 <fwp_trap>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	97fff706 	bl	3010 <fwp_tape_unlink_scope>
    53fc:	f9401260 	ldr	x0, [x19, #32]
    5400:	97fff574 	bl	29d0 <free@plt>
    5404:	f9401a60 	ldr	x0, [x19, #48]
    5408:	97fff572 	bl	29d0 <free@plt>
    540c:	f9402260 	ldr	x0, [x19, #64]
    5410:	97fff570 	bl	29d0 <free@plt>
    5414:	f9000e7f 	str	xzr, [x19, #24]
    5418:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    541c:	f947e821 	ldr	x1, [x1, #4048]
    5420:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5424:	d2800262 	mov	x2, #0x13                  	// #19
    5428:	4f000400 	movi	v0.4s, #0x0
    542c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5430:	f9400023 	ldr	x3, [x1]
    5434:	b900067f 	str	wzr, [x19, #4]
    5438:	d2800021 	mov	x1, #0x1                   	// #1
    543c:	91296000 	add	x0, x0, #0xa58
    5440:	3c808260 	stur	q0, [x19, #8]
    5444:	ad010260 	stp	q0, q0, [x19, #32]
    5448:	97fff572 	bl	2a10 <fwrite@plt>
    544c:	d2800000 	mov	x0, #0x0                   	// #0
    5450:	97fff57c 	bl	2a40 <fflush@plt>
    5454:	52800cc0 	mov	w0, #0x66                  	// #102
    5458:	97fff58a 	bl	2a80 <_Exit@plt>
    545c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5460:	91390000 	add	x0, x0, #0xe40
    5464:	a9046bf9 	stp	x25, x26, [sp, #64]
    5468:	a90573fb 	stp	x27, x28, [sp, #80]
    546c:	97fff905 	bl	3880 <fwp_trap>

0000000000005470 <w120>:
    5470:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5474:	9e660003 	fmov	x3, d0
    5478:	aa0003e2 	mov	x2, x0
    547c:	910003fd 	mov	x29, sp
    5480:	6d0327e8 	stp	d8, d9, [sp, #48]
    5484:	1e604028 	fmov	d8, d1
    5488:	1e600809 	fmul	d9, d0, d0
    548c:	fd0023ea 	str	d10, [sp, #64]
    5490:	1e60400a 	fmov	d10, d0
    5494:	a90153f3 	stp	x19, x20, [sp, #16]
    5498:	aa0003f3 	mov	x19, x0
    549c:	aa0103f4 	mov	x20, x1
    54a0:	aa0303e1 	mov	x1, x3
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	97ffff3f 	bl	51a4 <fwp_p_ad_push>
    54ac:	1e693908 	fsub	d8, d8, d9
    54b0:	aa1403e2 	mov	x2, x20
    54b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54bc:	9e660116 	fmov	x22, d8
    54c0:	97ffff39 	bl	51a4 <fwp_p_ad_push>
    54c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    54c8:	aa0003e1 	mov	x1, x0
    54cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	1e6a3929 	fsub	d9, d9, d10
    54d8:	aa0103f3 	mov	x19, x1
    54dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    54e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54e4:	9e660135 	fmov	x21, d9
    54e8:	97ffff2f 	bl	51a4 <fwp_p_ad_push>
    54ec:	1e680908 	fmul	d8, d8, d8
    54f0:	aa0003f4 	mov	x20, x0
    54f4:	aa1603e3 	mov	x3, x22
    54f8:	aa1603e1 	mov	x1, x22
    54fc:	aa1303e2 	mov	x2, x19
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffff28 	bl	51a4 <fwp_p_ad_push>
    5508:	aa0003e2 	mov	x2, x0
    550c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5510:	9e670020 	fmov	d0, x1
    5514:	9e660101 	fmov	x1, d8
    5518:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    551c:	1e600908 	fmul	d8, d8, d0
    5520:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5524:	97ffff20 	bl	51a4 <fwp_p_ad_push>
    5528:	1e690929 	fmul	d9, d9, d9
    552c:	aa0003f3 	mov	x19, x0
    5530:	aa1503e3 	mov	x3, x21
    5534:	aa1503e1 	mov	x1, x21
    5538:	aa1403e2 	mov	x2, x20
    553c:	aa1403e0 	mov	x0, x20
    5540:	97ffff19 	bl	51a4 <fwp_p_ad_push>
    5544:	1e692908 	fadd	d8, d8, d9
    5548:	aa1303e2 	mov	x2, x19
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa0303e1 	mov	x1, x3
    5554:	97ffff14 	bl	51a4 <fwp_p_ad_push>
    5558:	aa0003e1 	mov	x1, x0
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	9e660100 	fmov	x0, d8
    5564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5568:	6d4327e8 	ldp	d8, d9, [sp, #48]
    556c:	fd4023ea 	ldr	d10, [sp, #64]
    5570:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5574:	d65f03c0 	ret
    5578:	d503201f 	nop
    557c:	d503201f 	nop

0000000000005580 <fwp_rc_share>:
    5580:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5584:	91174042 	add	x2, x2, #0x5d0
    5588:	f949d843 	ldr	x3, [x2, #5040]
    558c:	f949ec41 	ldr	x1, [x2, #5080]
    5590:	cb030000 	sub	x0, x0, x3
    5594:	eb01401f 	cmp	x0, x1, lsl #16
    5598:	540002c2 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    559c:	d350fc01 	lsr	x1, x0, #16
    55a0:	f949fc44 	ldr	x4, [x2, #5112]
    55a4:	8b010821 	add	x1, x1, x1, lsl #2
    55a8:	d37df021 	lsl	x1, x1, #3
    55ac:	8b010083 	add	x3, x4, x1
    55b0:	f9401062 	ldr	x2, [x3, #32]
    55b4:	b40001e2 	cbz	x2, 55f0 <fwp_rc_share+0x70>
    55b8:	38616881 	ldrb	w1, [x4, x1]
    55bc:	7100083f 	cmp	w1, #0x2
    55c0:	540001a0 	b.eq	55f4 <fwp_rc_share+0x74>  // b.none
    55c4:	7100043f 	cmp	w1, #0x1
    55c8:	54000141 	b.ne	55f0 <fwp_rc_share+0x70>  // b.any
    55cc:	29430464 	ldp	w4, w1, [x3, #24]
    55d0:	92403c00 	and	x0, x0, #0xffff
    55d4:	9b047c00 	mul	x0, x0, x4
    55d8:	d360fc00 	lsr	x0, x0, #32
    55dc:	eb01001f 	cmp	x0, x1
    55e0:	54000082 	b.cs	55f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    55e4:	8b000042 	add	x2, x2, x0
    55e8:	39400040 	ldrb	w0, [x2]
    55ec:	350000a0 	cbnz	w0, 5600 <fwp_rc_share+0x80>
    55f0:	d65f03c0 	ret
    55f4:	72003c1f 	tst	w0, #0xffff
    55f8:	54ffff80 	b.eq	55e8 <fwp_rc_share+0x68>  // b.none
    55fc:	d65f03c0 	ret
    5600:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5604:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5608:	913ac000 	add	x0, x0, #0xeb0
    560c:	910003fd 	mov	x29, sp
    5610:	97fff89c 	bl	3880 <fwp_trap>

0000000000005614 <fwp_rc_free_arr>:
    5614:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5618:	91174063 	add	x3, x3, #0x5d0
    561c:	f949d861 	ldr	x1, [x3, #5040]
    5620:	f949ec62 	ldr	x2, [x3, #5080]
    5624:	cb010001 	sub	x1, x0, x1
    5628:	eb02403f 	cmp	x1, x2, lsl #16
    562c:	54000342 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5630:	d350fc22 	lsr	x2, x1, #16
    5634:	f949fc65 	ldr	x5, [x3, #5112]
    5638:	8b020842 	add	x2, x2, x2, lsl #2
    563c:	d37df042 	lsl	x2, x2, #3
    5640:	8b0200a4 	add	x4, x5, x2
    5644:	f9401083 	ldr	x3, [x4, #32]
    5648:	b4000263 	cbz	x3, 5694 <fwp_rc_free_arr+0x80>
    564c:	386268a2 	ldrb	w2, [x5, x2]
    5650:	7100085f 	cmp	w2, #0x2
    5654:	540001c0 	b.eq	568c <fwp_rc_free_arr+0x78>  // b.none
    5658:	7100045f 	cmp	w2, #0x1
    565c:	540001c1 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5660:	29430885 	ldp	w5, w2, [x4, #24]
    5664:	92403c21 	and	x1, x1, #0xffff
    5668:	9b057c21 	mul	x1, x1, x5
    566c:	d360fc21 	lsr	x1, x1, #32
    5670:	eb02003f 	cmp	x1, x2
    5674:	54000102 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5678:	8b010063 	add	x3, x3, x1
    567c:	39400061 	ldrb	w1, [x3]
    5680:	7100043f 	cmp	w1, #0x1
    5684:	54000081 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5688:	17fffd1a 	b	4af0 <fwp_mem_free>
    568c:	72003c3f 	tst	w1, #0xffff
    5690:	54ffff60 	b.eq	567c <fwp_rc_free_arr+0x68>  // b.none
    5694:	d65f03c0 	ret
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <fwp_rc_dup>:
    56a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    56a4:	91174042 	add	x2, x2, #0x5d0
    56a8:	f949d841 	ldr	x1, [x2, #5040]
    56ac:	f949ec43 	ldr	x3, [x2, #5080]
    56b0:	cb010001 	sub	x1, x0, x1
    56b4:	eb03403f 	cmp	x1, x3, lsl #16
    56b8:	54000342 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    56bc:	d350fc20 	lsr	x0, x1, #16
    56c0:	f949fc44 	ldr	x4, [x2, #5112]
    56c4:	8b000800 	add	x0, x0, x0, lsl #2
    56c8:	d37df002 	lsl	x2, x0, #3
    56cc:	8b020083 	add	x3, x4, x2
    56d0:	f9401060 	ldr	x0, [x3, #32]
    56d4:	b4000260 	cbz	x0, 5720 <fwp_rc_dup+0x80>
    56d8:	38626882 	ldrb	w2, [x4, x2]
    56dc:	7100085f 	cmp	w2, #0x2
    56e0:	54000220 	b.eq	5724 <fwp_rc_dup+0x84>  // b.none
    56e4:	7100045f 	cmp	w2, #0x1
    56e8:	540001c1 	b.ne	5720 <fwp_rc_dup+0x80>  // b.any
    56ec:	29430864 	ldp	w4, w2, [x3, #24]
    56f0:	92403c21 	and	x1, x1, #0xffff
    56f4:	9b047c21 	mul	x1, x1, x4
    56f8:	d360fc21 	lsr	x1, x1, #32
    56fc:	eb02003f 	cmp	x1, x2
    5700:	54000102 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5704:	8b010000 	add	x0, x0, x1
    5708:	39400001 	ldrb	w1, [x0]
    570c:	340000a1 	cbz	w1, 5720 <fwp_rc_dup+0x80>
    5710:	7103f43f 	cmp	w1, #0xfd
    5714:	540000e8 	b.hi	5730 <fwp_rc_dup+0x90>  // b.pmore
    5718:	11000421 	add	w1, w1, #0x1
    571c:	39000001 	strb	w1, [x0]
    5720:	d65f03c0 	ret
    5724:	72003c3f 	tst	w1, #0xffff
    5728:	54ffff00 	b.eq	5708 <fwp_rc_dup+0x68>  // b.none
    572c:	d65f03c0 	ret
    5730:	17fffc09 	b	4754 <fwp_rc_wide_dup>

0000000000005734 <fwp_owned_entry173>:
    5734:	d10103ff 	sub	sp, sp, #0x40
    5738:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    573c:	f947f442 	ldr	x2, [x2, #4072]
    5740:	a9027bfd 	stp	x29, x30, [sp, #32]
    5744:	910083fd 	add	x29, sp, #0x20
    5748:	a90353f3 	stp	x19, x20, [sp, #48]
    574c:	f9400043 	ldr	x3, [x2]
    5750:	f9000fe3 	str	x3, [sp, #24]
    5754:	d2800003 	mov	x3, #0x0                   	// #0
    5758:	a9400c01 	ldp	x1, x3, [x0]
    575c:	f9400802 	ldr	x2, [x0, #16]
    5760:	ab020022 	adds	x2, x1, x2
    5764:	540006e6 	b.vs	5840 <fwp_owned_entry173+0x10c>
    5768:	910023e1 	add	x1, sp, #0x8
    576c:	52800000 	mov	w0, #0x0                   	// #0
    5770:	a9008be3 	stp	x3, x2, [sp, #8]
    5774:	97fffe44 	bl	5084 <fwp_data.part.0.constprop.0>
    5778:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    577c:	91174063 	add	x3, x3, #0x5d0
    5780:	aa0003f3 	mov	x19, x0
    5784:	f949d861 	ldr	x1, [x3, #5040]
    5788:	f949ec60 	ldr	x0, [x3, #5080]
    578c:	cb010261 	sub	x1, x19, x1
    5790:	eb00403f 	cmp	x1, x0, lsl #16
    5794:	54000322 	b.cs	57f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5798:	d350fc22 	lsr	x2, x1, #16
    579c:	f949fc63 	ldr	x3, [x3, #5112]
    57a0:	8b020842 	add	x2, x2, x2, lsl #2
    57a4:	d37df042 	lsl	x2, x2, #3
    57a8:	8b020060 	add	x0, x3, x2
    57ac:	f9401014 	ldr	x20, [x0, #32]
    57b0:	b4000254 	cbz	x20, 57f8 <fwp_owned_entry173+0xc4>
    57b4:	38626862 	ldrb	w2, [x3, x2]
    57b8:	7100085f 	cmp	w2, #0x2
    57bc:	54000360 	b.eq	5828 <fwp_owned_entry173+0xf4>  // b.none
    57c0:	7100045f 	cmp	w2, #0x1
    57c4:	540001a1 	b.ne	57f8 <fwp_owned_entry173+0xc4>  // b.any
    57c8:	29430002 	ldp	w2, w0, [x0, #24]
    57cc:	92403c21 	and	x1, x1, #0xffff
    57d0:	9b027c21 	mul	x1, x1, x2
    57d4:	d360fc21 	lsr	x1, x1, #32
    57d8:	eb00003f 	cmp	x1, x0
    57dc:	540000e2 	b.cs	57f8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    57e0:	8b010294 	add	x20, x20, x1
    57e4:	39400280 	ldrb	w0, [x20]
    57e8:	7103fc1f 	cmp	w0, #0xff
    57ec:	54000240 	b.eq	5834 <fwp_owned_entry173+0x100>  // b.none
    57f0:	52800020 	mov	w0, #0x1                   	// #1
    57f4:	39000280 	strb	w0, [x20]
    57f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    57fc:	f947f400 	ldr	x0, [x0, #4072]
    5800:	f9400fe2 	ldr	x2, [sp, #24]
    5804:	f9400001 	ldr	x1, [x0]
    5808:	eb010042 	subs	x2, x2, x1
    580c:	d2800001 	mov	x1, #0x0                   	// #0
    5810:	540001a1 	b.ne	5844 <fwp_owned_entry173+0x110>  // b.any
    5814:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5818:	aa1303e0 	mov	x0, x19
    581c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5820:	910103ff 	add	sp, sp, #0x40
    5824:	d65f03c0 	ret
    5828:	72003c3f 	tst	w1, #0xffff
    582c:	54fffe61 	b.ne	57f8 <fwp_owned_entry173+0xc4>  // b.any
    5830:	17ffffed 	b	57e4 <fwp_owned_entry173+0xb0>
    5834:	aa1403e0 	mov	x0, x20
    5838:	97fffc0e 	bl	4870 <fwp_rc_forget_slot>
    583c:	17ffffed 	b	57f0 <fwp_owned_entry173+0xbc>
    5840:	97fff4b0 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5844:	97fff433 	bl	2910 <__stack_chk_fail@plt>
    5848:	d503201f 	nop
    584c:	d503201f 	nop

0000000000005850 <e173>:
    5850:	d10103ff 	sub	sp, sp, #0x40
    5854:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5858:	f947f442 	ldr	x2, [x2, #4072]
    585c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5860:	910083fd 	add	x29, sp, #0x20
    5864:	a90353f3 	stp	x19, x20, [sp, #48]
    5868:	f9400043 	ldr	x3, [x2]
    586c:	f9000fe3 	str	x3, [sp, #24]
    5870:	d2800003 	mov	x3, #0x0                   	// #0
    5874:	a9400c01 	ldp	x1, x3, [x0]
    5878:	f9400802 	ldr	x2, [x0, #16]
    587c:	ab020022 	adds	x2, x1, x2
    5880:	54000726 	b.vs	5964 <e173+0x114>
    5884:	910023e1 	add	x1, sp, #0x8
    5888:	52800000 	mov	w0, #0x0                   	// #0
    588c:	a9008be3 	stp	x3, x2, [sp, #8]
    5890:	97fffdfd 	bl	5084 <fwp_data.part.0.constprop.0>
    5894:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5898:	91174063 	add	x3, x3, #0x5d0
    589c:	aa0003f3 	mov	x19, x0
    58a0:	f949d861 	ldr	x1, [x3, #5040]
    58a4:	f949ec60 	ldr	x0, [x3, #5080]
    58a8:	cb010261 	sub	x1, x19, x1
    58ac:	eb00403f 	cmp	x1, x0, lsl #16
    58b0:	54000322 	b.cs	5914 <e173+0xc4>  // b.hs, b.nlast
    58b4:	d350fc22 	lsr	x2, x1, #16
    58b8:	f949fc63 	ldr	x3, [x3, #5112]
    58bc:	8b020842 	add	x2, x2, x2, lsl #2
    58c0:	d37df042 	lsl	x2, x2, #3
    58c4:	8b020060 	add	x0, x3, x2
    58c8:	f9401014 	ldr	x20, [x0, #32]
    58cc:	b4000254 	cbz	x20, 5914 <e173+0xc4>
    58d0:	38626862 	ldrb	w2, [x3, x2]
    58d4:	7100085f 	cmp	w2, #0x2
    58d8:	540003a0 	b.eq	594c <e173+0xfc>  // b.none
    58dc:	7100045f 	cmp	w2, #0x1
    58e0:	540001a1 	b.ne	5914 <e173+0xc4>  // b.any
    58e4:	29430002 	ldp	w2, w0, [x0, #24]
    58e8:	92403c21 	and	x1, x1, #0xffff
    58ec:	9b027c21 	mul	x1, x1, x2
    58f0:	d360fc21 	lsr	x1, x1, #32
    58f4:	eb00003f 	cmp	x1, x0
    58f8:	540000e2 	b.cs	5914 <e173+0xc4>  // b.hs, b.nlast
    58fc:	8b010294 	add	x20, x20, x1
    5900:	39400280 	ldrb	w0, [x20]
    5904:	7103fc1f 	cmp	w0, #0xff
    5908:	54000280 	b.eq	5958 <e173+0x108>  // b.none
    590c:	52800020 	mov	w0, #0x1                   	// #1
    5910:	39000280 	strb	w0, [x20]
    5914:	aa1303e0 	mov	x0, x19
    5918:	97ffff1a 	bl	5580 <fwp_rc_share>
    591c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5920:	f947f400 	ldr	x0, [x0, #4072]
    5924:	f9400fe2 	ldr	x2, [sp, #24]
    5928:	f9400001 	ldr	x1, [x0]
    592c:	eb010042 	subs	x2, x2, x1
    5930:	d2800001 	mov	x1, #0x0                   	// #0
    5934:	540001a1 	b.ne	5968 <e173+0x118>  // b.any
    5938:	a9427bfd 	ldp	x29, x30, [sp, #32]
    593c:	aa1303e0 	mov	x0, x19
    5940:	a94353f3 	ldp	x19, x20, [sp, #48]
    5944:	910103ff 	add	sp, sp, #0x40
    5948:	d65f03c0 	ret
    594c:	72003c3f 	tst	w1, #0xffff
    5950:	54fffe21 	b.ne	5914 <e173+0xc4>  // b.any
    5954:	17ffffeb 	b	5900 <e173+0xb0>
    5958:	aa1403e0 	mov	x0, x20
    595c:	97fffbc5 	bl	4870 <fwp_rc_forget_slot>
    5960:	17ffffeb 	b	590c <e173+0xbc>
    5964:	97fff467 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5968:	97fff3ea 	bl	2910 <__stack_chk_fail@plt>
    596c:	d503201f 	nop

0000000000005970 <fwp_drop0>:
    5970:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5974:	910003fd 	mov	x29, sp
    5978:	a90153f3 	stp	x19, x20, [sp, #16]
    597c:	f90013f5 	str	x21, [sp, #32]
    5980:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5984:	911742b4 	add	x20, x21, #0x5d0
    5988:	f949da81 	ldr	x1, [x20, #5040]
    598c:	f949ee82 	ldr	x2, [x20, #5080]
    5990:	cb010001 	sub	x1, x0, x1
    5994:	eb02403f 	cmp	x1, x2, lsl #16
    5998:	54000382 	b.cs	5a08 <fwp_drop0+0x98>  // b.hs, b.nlast
    599c:	d350fc22 	lsr	x2, x1, #16
    59a0:	f949fe84 	ldr	x4, [x20, #5112]
    59a4:	8b020842 	add	x2, x2, x2, lsl #2
    59a8:	d37df042 	lsl	x2, x2, #3
    59ac:	8b020083 	add	x3, x4, x2
    59b0:	f9401073 	ldr	x19, [x3, #32]
    59b4:	b40002b3 	cbz	x19, 5a08 <fwp_drop0+0x98>
    59b8:	38626882 	ldrb	w2, [x4, x2]
    59bc:	7100085f 	cmp	w2, #0x2
    59c0:	540002c0 	b.eq	5a18 <fwp_drop0+0xa8>  // b.none
    59c4:	7100045f 	cmp	w2, #0x1
    59c8:	54000201 	b.ne	5a08 <fwp_drop0+0x98>  // b.any
    59cc:	29430864 	ldp	w4, w2, [x3, #24]
    59d0:	92403c21 	and	x1, x1, #0xffff
    59d4:	9b047c21 	mul	x1, x1, x4
    59d8:	d360fc21 	lsr	x1, x1, #32
    59dc:	eb02003f 	cmp	x1, x2
    59e0:	54000142 	b.cs	5a08 <fwp_drop0+0x98>  // b.hs, b.nlast
    59e4:	8b010273 	add	x19, x19, x1
    59e8:	39400261 	ldrb	w1, [x19]
    59ec:	340000e1 	cbz	w1, 5a08 <fwp_drop0+0x98>
    59f0:	7100043f 	cmp	w1, #0x1
    59f4:	540001e0 	b.eq	5a30 <fwp_drop0+0xc0>  // b.none
    59f8:	7103fc3f 	cmp	w1, #0xff
    59fc:	540002e0 	b.eq	5a58 <fwp_drop0+0xe8>  // b.none
    5a00:	51000421 	sub	w1, w1, #0x1
    5a04:	39000261 	strb	w1, [x19]
    5a08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a0c:	f94013f5 	ldr	x21, [sp, #32]
    5a10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a14:	d65f03c0 	ret
    5a18:	72003c3f 	tst	w1, #0xffff
    5a1c:	54fffe60 	b.eq	59e8 <fwp_drop0+0x78>  // b.none
    5a20:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a24:	f94013f5 	ldr	x21, [sp, #32]
    5a28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a2c:	d65f03c0 	ret
    5a30:	f9400813 	ldr	x19, [x0, #16]
    5a34:	97fffef8 	bl	5614 <fwp_rc_free_arr>
    5a38:	911742a0 	add	x0, x21, #0x5d0
    5a3c:	f949d801 	ldr	x1, [x0, #5040]
    5a40:	f949ec00 	ldr	x0, [x0, #5080]
    5a44:	cb010261 	sub	x1, x19, x1
    5a48:	eb00403f 	cmp	x1, x0, lsl #16
    5a4c:	54fffde2 	b.cs	5a08 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a50:	aa1303e0 	mov	x0, x19
    5a54:	17ffffd2 	b	599c <fwp_drop0+0x2c>
    5a58:	ca534660 	eor	x0, x19, x19, lsr #17
    5a5c:	911742b5 	add	x21, x21, #0x5d0
    5a60:	ca402400 	eor	x0, x0, x0, lsr #9
    5a64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a68:	f94a2400 	ldr	x0, [x0, #5192]
    5a6c:	b5000080 	cbnz	x0, 5a7c <fwp_drop0+0x10c>
    5a70:	14000010 	b	5ab0 <fwp_drop0+0x140>
    5a74:	f9400800 	ldr	x0, [x0, #16]
    5a78:	b40001c0 	cbz	x0, 5ab0 <fwp_drop0+0x140>
    5a7c:	f9400001 	ldr	x1, [x0]
    5a80:	eb13003f 	cmp	x1, x19
    5a84:	54ffff81 	b.ne	5a74 <fwp_drop0+0x104>  // b.any
    5a88:	f9400401 	ldr	x1, [x0, #8]
    5a8c:	d1000421 	sub	x1, x1, #0x1
    5a90:	f9000401 	str	x1, [x0, #8]
    5a94:	f103f83f 	cmp	x1, #0xfe
    5a98:	54fffb81 	b.ne	5a08 <fwp_drop0+0x98>  // b.any
    5a9c:	aa1303e0 	mov	x0, x19
    5aa0:	97fffb74 	bl	4870 <fwp_rc_forget_slot>
    5aa4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5aa8:	39000260 	strb	w0, [x19]
    5aac:	17ffffd7 	b	5a08 <fwp_drop0+0x98>
    5ab0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5ab4:	9136c000 	add	x0, x0, #0xdb0
    5ab8:	97fff772 	bl	3880 <fwp_trap>
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_drop1>:
    5ac0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ac4:	910003fd 	mov	x29, sp
    5ac8:	a90153f3 	stp	x19, x20, [sp, #16]
    5acc:	f90013f5 	str	x21, [sp, #32]
    5ad0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5ad4:	911742b4 	add	x20, x21, #0x5d0
    5ad8:	f949da81 	ldr	x1, [x20, #5040]
    5adc:	f949ee82 	ldr	x2, [x20, #5080]
    5ae0:	cb010001 	sub	x1, x0, x1
    5ae4:	eb02403f 	cmp	x1, x2, lsl #16
    5ae8:	54000382 	b.cs	5b58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5aec:	d350fc22 	lsr	x2, x1, #16
    5af0:	f949fe84 	ldr	x4, [x20, #5112]
    5af4:	8b020842 	add	x2, x2, x2, lsl #2
    5af8:	d37df042 	lsl	x2, x2, #3
    5afc:	8b020083 	add	x3, x4, x2
    5b00:	f9401073 	ldr	x19, [x3, #32]
    5b04:	b40002b3 	cbz	x19, 5b58 <fwp_drop1+0x98>
    5b08:	38626882 	ldrb	w2, [x4, x2]
    5b0c:	7100085f 	cmp	w2, #0x2
    5b10:	540002c0 	b.eq	5b68 <fwp_drop1+0xa8>  // b.none
    5b14:	7100045f 	cmp	w2, #0x1
    5b18:	54000201 	b.ne	5b58 <fwp_drop1+0x98>  // b.any
    5b1c:	29430864 	ldp	w4, w2, [x3, #24]
    5b20:	92403c21 	and	x1, x1, #0xffff
    5b24:	9b047c21 	mul	x1, x1, x4
    5b28:	d360fc21 	lsr	x1, x1, #32
    5b2c:	eb02003f 	cmp	x1, x2
    5b30:	54000142 	b.cs	5b58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b34:	8b010273 	add	x19, x19, x1
    5b38:	39400261 	ldrb	w1, [x19]
    5b3c:	340000e1 	cbz	w1, 5b58 <fwp_drop1+0x98>
    5b40:	7100043f 	cmp	w1, #0x1
    5b44:	540001e0 	b.eq	5b80 <fwp_drop1+0xc0>  // b.none
    5b48:	7103fc3f 	cmp	w1, #0xff
    5b4c:	540002e0 	b.eq	5ba8 <fwp_drop1+0xe8>  // b.none
    5b50:	51000421 	sub	w1, w1, #0x1
    5b54:	39000261 	strb	w1, [x19]
    5b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b5c:	f94013f5 	ldr	x21, [sp, #32]
    5b60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b64:	d65f03c0 	ret
    5b68:	72003c3f 	tst	w1, #0xffff
    5b6c:	54fffe60 	b.eq	5b38 <fwp_drop1+0x78>  // b.none
    5b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b74:	f94013f5 	ldr	x21, [sp, #32]
    5b78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b7c:	d65f03c0 	ret
    5b80:	f9400813 	ldr	x19, [x0, #16]
    5b84:	97fffea4 	bl	5614 <fwp_rc_free_arr>
    5b88:	911742a0 	add	x0, x21, #0x5d0
    5b8c:	f949d801 	ldr	x1, [x0, #5040]
    5b90:	f949ec00 	ldr	x0, [x0, #5080]
    5b94:	cb010261 	sub	x1, x19, x1
    5b98:	eb00403f 	cmp	x1, x0, lsl #16
    5b9c:	54fffde2 	b.cs	5b58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ba0:	aa1303e0 	mov	x0, x19
    5ba4:	17ffffd2 	b	5aec <fwp_drop1+0x2c>
    5ba8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bac:	911742b5 	add	x21, x21, #0x5d0
    5bb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5bb4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5bb8:	f94a2400 	ldr	x0, [x0, #5192]
    5bbc:	b5000080 	cbnz	x0, 5bcc <fwp_drop1+0x10c>
    5bc0:	14000010 	b	5c00 <fwp_drop1+0x140>
    5bc4:	f9400800 	ldr	x0, [x0, #16]
    5bc8:	b40001c0 	cbz	x0, 5c00 <fwp_drop1+0x140>
    5bcc:	f9400001 	ldr	x1, [x0]
    5bd0:	eb13003f 	cmp	x1, x19
    5bd4:	54ffff81 	b.ne	5bc4 <fwp_drop1+0x104>  // b.any
    5bd8:	f9400401 	ldr	x1, [x0, #8]
    5bdc:	d1000421 	sub	x1, x1, #0x1
    5be0:	f9000401 	str	x1, [x0, #8]
    5be4:	f103f83f 	cmp	x1, #0xfe
    5be8:	54fffb81 	b.ne	5b58 <fwp_drop1+0x98>  // b.any
    5bec:	aa1303e0 	mov	x0, x19
    5bf0:	97fffb20 	bl	4870 <fwp_rc_forget_slot>
    5bf4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bf8:	39000260 	strb	w0, [x19]
    5bfc:	17ffffd7 	b	5b58 <fwp_drop1+0x98>
    5c00:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5c04:	9136c000 	add	x0, x0, #0xdb0
    5c08:	97fff71e 	bl	3880 <fwp_trap>
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_closure_drop>:
    5c10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5c14:	911740a4 	add	x4, x5, #0x5d0
    5c18:	aa0003e1 	mov	x1, x0
    5c1c:	f949d882 	ldr	x2, [x4, #5040]
    5c20:	f949ec80 	ldr	x0, [x4, #5080]
    5c24:	cb020022 	sub	x2, x1, x2
    5c28:	eb00405f 	cmp	x2, x0, lsl #16
    5c2c:	54000662 	b.cs	5cf8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5c30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c34:	d350fc43 	lsr	x3, x2, #16
    5c38:	910003fd 	mov	x29, sp
    5c3c:	8b030863 	add	x3, x3, x3, lsl #2
    5c40:	f949fc84 	ldr	x4, [x4, #5112]
    5c44:	d37df063 	lsl	x3, x3, #3
    5c48:	f9000bf3 	str	x19, [sp, #16]
    5c4c:	8b030080 	add	x0, x4, x3
    5c50:	f9401013 	ldr	x19, [x0, #32]
    5c54:	b40002b3 	cbz	x19, 5ca8 <fwp_closure_drop+0x98>
    5c58:	38636883 	ldrb	w3, [x4, x3]
    5c5c:	7100087f 	cmp	w3, #0x2
    5c60:	54000420 	b.eq	5ce4 <fwp_closure_drop+0xd4>  // b.none
    5c64:	7100047f 	cmp	w3, #0x1
    5c68:	54000201 	b.ne	5ca8 <fwp_closure_drop+0x98>  // b.any
    5c6c:	29430003 	ldp	w3, w0, [x0, #24]
    5c70:	92403c42 	and	x2, x2, #0xffff
    5c74:	9b037c42 	mul	x2, x2, x3
    5c78:	d360fc42 	lsr	x2, x2, #32
    5c7c:	eb00005f 	cmp	x2, x0
    5c80:	54000142 	b.cs	5ca8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5c84:	8b020273 	add	x19, x19, x2
    5c88:	39400260 	ldrb	w0, [x19]
    5c8c:	340000e0 	cbz	w0, 5ca8 <fwp_closure_drop+0x98>
    5c90:	7100041f 	cmp	w0, #0x1
    5c94:	54000100 	b.eq	5cb4 <fwp_closure_drop+0xa4>  // b.none
    5c98:	7103fc1f 	cmp	w0, #0xff
    5c9c:	54000300 	b.eq	5cfc <fwp_closure_drop+0xec>  // b.none
    5ca0:	51000400 	sub	w0, w0, #0x1
    5ca4:	39000260 	strb	w0, [x19]
    5ca8:	f9400bf3 	ldr	x19, [sp, #16]
    5cac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cb0:	d65f03c0 	ret
    5cb4:	d53bd040 	mrs	x0, tpidr_el0
    5cb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5cbc:	91004000 	add	x0, x0, #0x10
    5cc0:	f9400000 	ldr	x0, [x0]
    5cc4:	b4000080 	cbz	x0, 5cd4 <fwp_closure_drop+0xc4>
    5cc8:	f9400bf3 	ldr	x19, [sp, #16]
    5ccc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cd0:	17fff705 	b	38e4 <fwp_closure_drop_push>
    5cd4:	f9400bf3 	ldr	x19, [sp, #16]
    5cd8:	aa0103e0 	mov	x0, x1
    5cdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ce0:	17fff770 	b	3aa0 <fwp_closure_drop.part.0>
    5ce4:	72003c5f 	tst	w2, #0xffff
    5ce8:	54fffd00 	b.eq	5c88 <fwp_closure_drop+0x78>  // b.none
    5cec:	f9400bf3 	ldr	x19, [sp, #16]
    5cf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cf4:	d65f03c0 	ret
    5cf8:	d65f03c0 	ret
    5cfc:	ca534660 	eor	x0, x19, x19, lsr #17
    5d00:	911740a5 	add	x5, x5, #0x5d0
    5d04:	ca402400 	eor	x0, x0, x0, lsr #9
    5d08:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5d0c:	f94a2400 	ldr	x0, [x0, #5192]
    5d10:	b5000080 	cbnz	x0, 5d20 <fwp_closure_drop+0x110>
    5d14:	14000010 	b	5d54 <fwp_closure_drop+0x144>
    5d18:	f9400800 	ldr	x0, [x0, #16]
    5d1c:	b40001c0 	cbz	x0, 5d54 <fwp_closure_drop+0x144>
    5d20:	f9400001 	ldr	x1, [x0]
    5d24:	eb13003f 	cmp	x1, x19
    5d28:	54ffff81 	b.ne	5d18 <fwp_closure_drop+0x108>  // b.any
    5d2c:	f9400401 	ldr	x1, [x0, #8]
    5d30:	d1000421 	sub	x1, x1, #0x1
    5d34:	f9000401 	str	x1, [x0, #8]
    5d38:	f103f83f 	cmp	x1, #0xfe
    5d3c:	54fffb61 	b.ne	5ca8 <fwp_closure_drop+0x98>  // b.any
    5d40:	aa1303e0 	mov	x0, x19
    5d44:	97fffacb 	bl	4870 <fwp_rc_forget_slot>
    5d48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d4c:	39000260 	strb	w0, [x19]
    5d50:	17ffffd6 	b	5ca8 <fwp_closure_drop+0x98>
    5d54:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    5d58:	9136c000 	add	x0, x0, #0xdb0
    5d5c:	97fff6c9 	bl	3880 <fwp_trap>

0000000000005d60 <fwp_owned_tape_release>:
    5d60:	b4000940 	cbz	x0, 5e88 <fwp_owned_tape_release+0x128>
    5d64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d68:	910003fd 	mov	x29, sp
    5d6c:	a90153f3 	stp	x19, x20, [sp, #16]
    5d70:	aa0003f3 	mov	x19, x0
    5d74:	f9400000 	ldr	x0, [x0]
    5d78:	b4000060 	cbz	x0, 5d84 <fwp_owned_tape_release+0x24>
    5d7c:	f9400661 	ldr	x1, [x19, #8]
    5d80:	f9000401 	str	x1, [x0, #8]
    5d84:	f9400661 	ldr	x1, [x19, #8]
    5d88:	b4000041 	cbz	x1, 5d90 <fwp_owned_tape_release+0x30>
    5d8c:	f9000020 	str	x0, [x1]
    5d90:	f9400a60 	ldr	x0, [x19, #16]
    5d94:	f9403401 	ldr	x1, [x0, #104]
    5d98:	b40005c1 	cbz	x1, 5e50 <fwp_owned_tape_release+0xf0>
    5d9c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5da0:	eb00005f 	cmp	x2, x0
    5da4:	540002ed 	b.le	5e00 <fwp_owned_tape_release+0xa0>
    5da8:	d2800014 	mov	x20, #0x0                   	// #0
    5dac:	f90013f5 	str	x21, [sp, #32]
    5db0:	d2800015 	mov	x21, #0x0                   	// #0
    5db4:	d503201f 	nop
    5db8:	f9402260 	ldr	x0, [x19, #64]
    5dbc:	910006b5 	add	x21, x21, #0x1
    5dc0:	f8746800 	ldr	x0, [x0, x20]
    5dc4:	d63f0020 	blr	x1
    5dc8:	f9402260 	ldr	x0, [x19, #64]
    5dcc:	f9400a61 	ldr	x1, [x19, #16]
    5dd0:	8b140000 	add	x0, x0, x20
    5dd4:	91004294 	add	x20, x20, #0x10
    5dd8:	f9400400 	ldr	x0, [x0, #8]
    5ddc:	f9403421 	ldr	x1, [x1, #104]
    5de0:	d63f0020 	blr	x1
    5de4:	a9450261 	ldp	x1, x0, [x19, #80]
    5de8:	cb010000 	sub	x0, x0, x1
    5dec:	eb15001f 	cmp	x0, x21
    5df0:	f9400a60 	ldr	x0, [x19, #16]
    5df4:	f9403401 	ldr	x1, [x0, #104]
    5df8:	54fffe0c 	b.gt	5db8 <fwp_owned_tape_release+0x58>
    5dfc:	f94013f5 	ldr	x21, [sp, #32]
    5e00:	f9403663 	ldr	x3, [x19, #104]
    5e04:	f9401262 	ldr	x2, [x19, #32]
    5e08:	f100007f 	cmp	x3, #0x0
    5e0c:	540001ed 	b.le	5e48 <fwp_owned_tape_release+0xe8>
    5e10:	d2800014 	mov	x20, #0x0                   	// #0
    5e14:	d503201f 	nop
    5e18:	f9402660 	ldr	x0, [x19, #72]
    5e1c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5e20:	eb02001f 	cmp	x0, x2
    5e24:	540000c0 	b.eq	5e3c <fwp_owned_tape_release+0xdc>  // b.none
    5e28:	d63f0020 	blr	x1
    5e2c:	f9400a60 	ldr	x0, [x19, #16]
    5e30:	f9401262 	ldr	x2, [x19, #32]
    5e34:	f9403663 	ldr	x3, [x19, #104]
    5e38:	f9403401 	ldr	x1, [x0, #104]
    5e3c:	91000694 	add	x20, x20, #0x1
    5e40:	eb14007f 	cmp	x3, x20
    5e44:	54fffeac 	b.gt	5e18 <fwp_owned_tape_release+0xb8>
    5e48:	aa0203e0 	mov	x0, x2
    5e4c:	d63f0020 	blr	x1
    5e50:	f9401660 	ldr	x0, [x19, #40]
    5e54:	97ffff6f 	bl	5c10 <fwp_closure_drop>
    5e58:	f9401a60 	ldr	x0, [x19, #48]
    5e5c:	97ffff6d 	bl	5c10 <fwp_closure_drop>
    5e60:	f9401e60 	ldr	x0, [x19, #56]
    5e64:	97ffff6b 	bl	5c10 <fwp_closure_drop>
    5e68:	f9402260 	ldr	x0, [x19, #64]
    5e6c:	97fffb21 	bl	4af0 <fwp_mem_free>
    5e70:	f9402660 	ldr	x0, [x19, #72]
    5e74:	97fffb1f 	bl	4af0 <fwp_mem_free>
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e84:	17fffb1b 	b	4af0 <fwp_mem_free>
    5e88:	d65f03c0 	ret
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_tape_finish>:
    5e90:	d10203ff 	sub	sp, sp, #0x80
    5e94:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5e98:	f947f421 	ldr	x1, [x1, #4072]
    5e9c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ea0:	910103fd 	add	x29, sp, #0x40
    5ea4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ea8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5eac:	a90763f7 	stp	x23, x24, [sp, #112]
    5eb0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5eb4:	9101c316 	add	x22, x24, #0x70
    5eb8:	f9400022 	ldr	x2, [x1]
    5ebc:	f9001fe2 	str	x2, [sp, #56]
    5ec0:	d2800002 	mov	x2, #0x0                   	// #0
    5ec4:	910262c0 	add	x0, x22, #0x98
    5ec8:	97fff58e 	bl	3500 <fwp_tape_buffers_dispose>
    5ecc:	f9006adf 	str	xzr, [x22, #208]
    5ed0:	f9404ac0 	ldr	x0, [x22, #144]
    5ed4:	f100001f 	cmp	x0, #0x0
    5ed8:	5400030d 	b.le	5f38 <fwp_tape_finish+0xa8>
    5edc:	910003f7 	mov	x23, sp
    5ee0:	d2800015 	mov	x21, #0x0                   	// #0
    5ee4:	d2800014 	mov	x20, #0x0                   	// #0
    5ee8:	f94002d3 	ldr	x19, [x22]
    5eec:	91000694 	add	x20, x20, #0x1
    5ef0:	8b150273 	add	x19, x19, x21
    5ef4:	9101a2b5 	add	x21, x21, #0x68
    5ef8:	aa1303e0 	mov	x0, x19
    5efc:	97fff445 	bl	3010 <fwp_tape_unlink_scope>
    5f00:	aa1703e0 	mov	x0, x23
    5f04:	f9401261 	ldr	x1, [x19, #32]
    5f08:	f90003e1 	str	x1, [sp]
    5f0c:	f9401a62 	ldr	x2, [x19, #48]
    5f10:	f9000be2 	str	x2, [sp, #16]
    5f14:	f9402261 	ldr	x1, [x19, #64]
    5f18:	f90013e1 	str	x1, [sp, #32]
    5f1c:	97fff579 	bl	3500 <fwp_tape_buffers_dispose>
    5f20:	f9403260 	ldr	x0, [x19, #96]
    5f24:	97ffff8f 	bl	5d60 <fwp_owned_tape_release>
    5f28:	f900327f 	str	xzr, [x19, #96]
    5f2c:	f9404ac0 	ldr	x0, [x22, #144]
    5f30:	eb14001f 	cmp	x0, x20
    5f34:	54fffdac 	b.gt	5ee8 <fwp_tape_finish+0x58>
    5f38:	f9403b00 	ldr	x0, [x24, #112]
    5f3c:	9101c313 	add	x19, x24, #0x70
    5f40:	97fff2a4 	bl	29d0 <free@plt>
    5f44:	f9003b1f 	str	xzr, [x24, #112]
    5f48:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5f4c:	f947f400 	ldr	x0, [x0, #4072]
    5f50:	f9004a7f 	str	xzr, [x19, #144]
    5f54:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    5f58:	f9401fe2 	ldr	x2, [sp, #56]
    5f5c:	f9400001 	ldr	x1, [x0]
    5f60:	eb010042 	subs	x2, x2, x1
    5f64:	d2800001 	mov	x1, #0x0                   	// #0
    5f68:	540000e1 	b.ne	5f84 <fwp_tape_finish+0xf4>  // b.any
    5f6c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f70:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f74:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f78:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f7c:	910203ff 	add	sp, sp, #0x80
    5f80:	d65f03c0 	ret
    5f84:	97fff263 	bl	2910 <__stack_chk_fail@plt>
    5f88:	d503201f 	nop
    5f8c:	d503201f 	nop

0000000000005f90 <fwp_tape_scope_release>:
    5f90:	d10243ff 	sub	sp, sp, #0x90
    5f94:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f98:	910103fd 	add	x29, sp, #0x40
    5f9c:	a90553f3 	stp	x19, x20, [sp, #80]
    5fa0:	aa0003f4 	mov	x20, x0
    5fa4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5fa8:	f947f400 	ldr	x0, [x0, #4072]
    5fac:	b9400285 	ldr	w5, [x20]
    5fb0:	f9400001 	ldr	x1, [x0]
    5fb4:	f9001fe1 	str	x1, [sp, #56]
    5fb8:	d2800001 	mov	x1, #0x0                   	// #0
    5fbc:	37f806c5 	tbnz	w5, #31, 6094 <fwp_tape_scope_release+0x104>
    5fc0:	a90763f7 	stp	x23, x24, [sp, #112]
    5fc4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5fc8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5fcc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5fd0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5fd4:	910003f7 	mov	x23, sp
    5fd8:	9101c273 	add	x19, x19, #0x70
    5fdc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5fe0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fe4:	52800d16 	mov	w22, #0x68                  	// #104
    5fe8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5fec:	f90043f9 	str	x25, [sp, #128]
    5ff0:	14000006 	b	6008 <fwp_tape_scope_release+0x78>
    5ff4:	97fff543 	bl	3500 <fwp_tape_buffers_dispose>
    5ff8:	aa1903e0 	mov	x0, x25
    5ffc:	97ffff59 	bl	5d60 <fwp_owned_tape_release>
    6000:	b9400285 	ldr	w5, [x20]
    6004:	37f80425 	tbnz	w5, #31, 6088 <fwp_tape_scope_release+0xf8>
    6008:	f9400266 	ldr	x6, [x19]
    600c:	9b367ca5 	smull	x5, w5, w22
    6010:	8b0500c0 	add	x0, x6, x5
    6014:	97fff3ff 	bl	3010 <fwp_tape_unlink_scope>
    6018:	ad410001 	ldp	q1, q0, [x0, #32]
    601c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6020:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6024:	f9400c03 	ldr	x3, [x0, #24]
    6028:	ad0003e1 	stp	q1, q0, [sp]
    602c:	b86568c1 	ldr	w1, [x6, x5]
    6030:	a9440804 	ldp	x4, x2, [x0, #64]
    6034:	b900041f 	str	wzr, [x0, #4]
    6038:	f9403019 	ldr	x25, [x0, #96]
    603c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6040:	f9000c1f 	str	xzr, [x0, #24]
    6044:	a9020fe4 	stp	x4, x3, [sp, #32]
    6048:	f9001be2 	str	x2, [sp, #48]
    604c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6050:	f900301f 	str	xzr, [x0, #96]
    6054:	6b15003f 	cmp	w1, w21
    6058:	540000e8 	b.hi	6074 <fwp_tape_scope_release+0xe4>  // b.pmore
    605c:	9343fca5 	asr	x5, x5, #3
    6060:	f9407660 	ldr	x0, [x19, #232]
    6064:	9b187ca5 	mul	x5, x5, x24
    6068:	eb0000bf 	cmp	x5, x0
    606c:	5400004a 	b.ge	6074 <fwp_tape_scope_release+0xe4>  // b.tcont
    6070:	f9007665 	str	x5, [x19, #232]
    6074:	aa1703e0 	mov	x0, x23
    6078:	b5fffbf9 	cbnz	x25, 5ff4 <fwp_tape_scope_release+0x64>
    607c:	97fff8e1 	bl	4400 <fwp_tape_buffers_release>
    6080:	b9400285 	ldr	w5, [x20]
    6084:	36fffc25 	tbz	w5, #31, 6008 <fwp_tape_scope_release+0x78>
    6088:	a9465bf5 	ldp	x21, x22, [sp, #96]
    608c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6090:	f94043f9 	ldr	x25, [sp, #128]
    6094:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6098:	f947f400 	ldr	x0, [x0, #4072]
    609c:	f9401fe2 	ldr	x2, [sp, #56]
    60a0:	f9400001 	ldr	x1, [x0]
    60a4:	eb010042 	subs	x2, x2, x1
    60a8:	d2800001 	mov	x1, #0x0                   	// #0
    60ac:	540000a1 	b.ne	60c0 <fwp_tape_scope_release+0x130>  // b.any
    60b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b4:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b8:	910243ff 	add	sp, sp, #0x90
    60bc:	d65f03c0 	ret
    60c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60c4:	a90763f7 	stp	x23, x24, [sp, #112]
    60c8:	f90043f9 	str	x25, [sp, #128]
    60cc:	97fff211 	bl	2910 <__stack_chk_fail@plt>

00000000000060d0 <fwp_drop4>:
    60d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60d4:	910003fd 	mov	x29, sp
    60d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    60dc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    60e0:	911742d5 	add	x21, x22, #0x5d0
    60e4:	a90153f3 	stp	x19, x20, [sp, #16]
    60e8:	aa0003f3 	mov	x19, x0
    60ec:	f949daa1 	ldr	x1, [x21, #5040]
    60f0:	f949eea0 	ldr	x0, [x21, #5080]
    60f4:	cb010261 	sub	x1, x19, x1
    60f8:	eb00403f 	cmp	x1, x0, lsl #16
    60fc:	54000382 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6100:	d350fc22 	lsr	x2, x1, #16
    6104:	f949fea3 	ldr	x3, [x21, #5112]
    6108:	8b020842 	add	x2, x2, x2, lsl #2
    610c:	d37df042 	lsl	x2, x2, #3
    6110:	8b020060 	add	x0, x3, x2
    6114:	f9401014 	ldr	x20, [x0, #32]
    6118:	b40002b4 	cbz	x20, 616c <fwp_drop4+0x9c>
    611c:	38626862 	ldrb	w2, [x3, x2]
    6120:	7100085f 	cmp	w2, #0x2
    6124:	540002c0 	b.eq	617c <fwp_drop4+0xac>  // b.none
    6128:	7100045f 	cmp	w2, #0x1
    612c:	54000201 	b.ne	616c <fwp_drop4+0x9c>  // b.any
    6130:	29430002 	ldp	w2, w0, [x0, #24]
    6134:	92403c21 	and	x1, x1, #0xffff
    6138:	9b027c21 	mul	x1, x1, x2
    613c:	d360fc21 	lsr	x1, x1, #32
    6140:	eb00003f 	cmp	x1, x0
    6144:	54000142 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6148:	8b010294 	add	x20, x20, x1
    614c:	39400280 	ldrb	w0, [x20]
    6150:	340000e0 	cbz	w0, 616c <fwp_drop4+0x9c>
    6154:	7100041f 	cmp	w0, #0x1
    6158:	540001e0 	b.eq	6194 <fwp_drop4+0xc4>  // b.none
    615c:	7103fc1f 	cmp	w0, #0xff
    6160:	540007c0 	b.eq	6258 <fwp_drop4+0x188>  // b.none
    6164:	51000400 	sub	w0, w0, #0x1
    6168:	39000280 	strb	w0, [x20]
    616c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6178:	d65f03c0 	ret
    617c:	72003c3f 	tst	w1, #0xffff
    6180:	54fffe60 	b.eq	614c <fwp_drop4+0x7c>  // b.none
    6184:	a94153f3 	ldp	x19, x20, [sp, #16]
    6188:	a9425bf5 	ldp	x21, x22, [sp, #32]
    618c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6190:	d65f03c0 	ret
    6194:	911742c2 	add	x2, x22, #0x5d0
    6198:	f9400660 	ldr	x0, [x19, #8]
    619c:	f949d841 	ldr	x1, [x2, #5040]
    61a0:	f949ec42 	ldr	x2, [x2, #5080]
    61a4:	cb010001 	sub	x1, x0, x1
    61a8:	eb02403f 	cmp	x1, x2, lsl #16
    61ac:	54000362 	b.cs	6218 <fwp_drop4+0x148>  // b.hs, b.nlast
    61b0:	d350fc22 	lsr	x2, x1, #16
    61b4:	8b020842 	add	x2, x2, x2, lsl #2
    61b8:	d37df042 	lsl	x2, x2, #3
    61bc:	8b020064 	add	x4, x3, x2
    61c0:	f9401094 	ldr	x20, [x4, #32]
    61c4:	b40002b4 	cbz	x20, 6218 <fwp_drop4+0x148>
    61c8:	38626862 	ldrb	w2, [x3, x2]
    61cc:	7100085f 	cmp	w2, #0x2
    61d0:	540003e0 	b.eq	624c <fwp_drop4+0x17c>  // b.none
    61d4:	7100045f 	cmp	w2, #0x1
    61d8:	54000201 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    61dc:	29430883 	ldp	w3, w2, [x4, #24]
    61e0:	92403c21 	and	x1, x1, #0xffff
    61e4:	9b037c21 	mul	x1, x1, x3
    61e8:	d360fc21 	lsr	x1, x1, #32
    61ec:	eb02003f 	cmp	x1, x2
    61f0:	54000142 	b.cs	6218 <fwp_drop4+0x148>  // b.hs, b.nlast
    61f4:	8b010294 	add	x20, x20, x1
    61f8:	39400281 	ldrb	w1, [x20]
    61fc:	340000e1 	cbz	w1, 6218 <fwp_drop4+0x148>
    6200:	7100043f 	cmp	w1, #0x1
    6204:	54000200 	b.eq	6244 <fwp_drop4+0x174>  // b.none
    6208:	7103fc3f 	cmp	w1, #0xff
    620c:	54000580 	b.eq	62bc <fwp_drop4+0x1ec>  // b.none
    6210:	51000421 	sub	w1, w1, #0x1
    6214:	39000281 	strb	w1, [x20]
    6218:	f9400a74 	ldr	x20, [x19, #16]
    621c:	aa1303e0 	mov	x0, x19
    6220:	97fffcfd 	bl	5614 <fwp_rc_free_arr>
    6224:	911742c0 	add	x0, x22, #0x5d0
    6228:	f949d801 	ldr	x1, [x0, #5040]
    622c:	f949ec00 	ldr	x0, [x0, #5080]
    6230:	cb010281 	sub	x1, x20, x1
    6234:	eb00403f 	cmp	x1, x0, lsl #16
    6238:	54fff9a2 	b.cs	616c <fwp_drop4+0x9c>  // b.hs, b.nlast
    623c:	aa1403f3 	mov	x19, x20
    6240:	17ffffb0 	b	6100 <fwp_drop4+0x30>
    6244:	97fffcf4 	bl	5614 <fwp_rc_free_arr>
    6248:	17fffff4 	b	6218 <fwp_drop4+0x148>
    624c:	72003c3f 	tst	w1, #0xffff
    6250:	54fffe41 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    6254:	17ffffe9 	b	61f8 <fwp_drop4+0x128>
    6258:	ca544681 	eor	x1, x20, x20, lsr #17
    625c:	911742c0 	add	x0, x22, #0x5d0
    6260:	ca412421 	eor	x1, x1, x1, lsr #9
    6264:	8b210c01 	add	x1, x0, w1, uxtb #3
    6268:	f94a2420 	ldr	x0, [x1, #5192]
    626c:	b5000080 	cbnz	x0, 627c <fwp_drop4+0x1ac>
    6270:	14000010 	b	62b0 <fwp_drop4+0x1e0>
    6274:	f9400800 	ldr	x0, [x0, #16]
    6278:	b40001c0 	cbz	x0, 62b0 <fwp_drop4+0x1e0>
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb14003f 	cmp	x1, x20
    6284:	54ffff81 	b.ne	6274 <fwp_drop4+0x1a4>  // b.any
    6288:	f9400401 	ldr	x1, [x0, #8]
    628c:	d1000421 	sub	x1, x1, #0x1
    6290:	f9000401 	str	x1, [x0, #8]
    6294:	f103f83f 	cmp	x1, #0xfe
    6298:	54fff6a1 	b.ne	616c <fwp_drop4+0x9c>  // b.any
    629c:	aa1403e0 	mov	x0, x20
    62a0:	97fff974 	bl	4870 <fwp_rc_forget_slot>
    62a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62a8:	39000280 	strb	w0, [x20]
    62ac:	17ffffb0 	b	616c <fwp_drop4+0x9c>
    62b0:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    62b4:	9136c000 	add	x0, x0, #0xdb0
    62b8:	97fff572 	bl	3880 <fwp_trap>
    62bc:	ca544680 	eor	x0, x20, x20, lsr #17
    62c0:	911742c1 	add	x1, x22, #0x5d0
    62c4:	ca402400 	eor	x0, x0, x0, lsr #9
    62c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    62cc:	f94a2400 	ldr	x0, [x0, #5192]
    62d0:	b5000080 	cbnz	x0, 62e0 <fwp_drop4+0x210>
    62d4:	17fffff7 	b	62b0 <fwp_drop4+0x1e0>
    62d8:	f9400800 	ldr	x0, [x0, #16]
    62dc:	b4fffea0 	cbz	x0, 62b0 <fwp_drop4+0x1e0>
    62e0:	f9400001 	ldr	x1, [x0]
    62e4:	eb14003f 	cmp	x1, x20
    62e8:	54ffff81 	b.ne	62d8 <fwp_drop4+0x208>  // b.any
    62ec:	f9400401 	ldr	x1, [x0, #8]
    62f0:	d1000421 	sub	x1, x1, #0x1
    62f4:	f9000401 	str	x1, [x0, #8]
    62f8:	f103f83f 	cmp	x1, #0xfe
    62fc:	54fff8e1 	b.ne	6218 <fwp_drop4+0x148>  // b.any
    6300:	aa1403e0 	mov	x0, x20
    6304:	97fff95b 	bl	4870 <fwp_rc_forget_slot>
    6308:	12800020 	mov	w0, #0xfffffffe            	// #-2
    630c:	39000280 	strb	w0, [x20]
    6310:	17ffffc2 	b	6218 <fwp_drop4+0x148>

0000000000006314 <fwp_arg_drop37>:
    6314:	7100003f 	cmp	w1, #0x0
    6318:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    631c:	54000041 	b.ne	6324 <fwp_arg_drop37+0x10>  // b.any
    6320:	d65f03c0 	ret
    6324:	f9400000 	ldr	x0, [x0]
    6328:	17ffff6a 	b	60d0 <fwp_drop4>
    632c:	d503201f 	nop

0000000000006330 <fwp_task_dispose>:
    6330:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6334:	910003fd 	mov	x29, sp
    6338:	f9000bf3 	str	x19, [sp, #16]
    633c:	aa0003f3 	mov	x19, x0
    6340:	39414000 	ldrb	w0, [x0, #80]
    6344:	36000720 	tbz	w0, #0, 6428 <fwp_task_dispose+0xf8>
    6348:	f9400a60 	ldr	x0, [x19, #16]
    634c:	b50006e0 	cbnz	x0, 6428 <fwp_task_dispose+0xf8>
    6350:	a9478660 	ldp	x0, x1, [x19, #120]
    6354:	39014e7f 	strb	wzr, [x19, #83]
    6358:	f9003e7f 	str	xzr, [x19, #120]
    635c:	f100003f 	cmp	x1, #0x0
    6360:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6364:	54000040 	b.eq	636c <fwp_task_dispose+0x3c>  // b.none
    6368:	d63f0020 	blr	x1
    636c:	f9405660 	ldr	x0, [x19, #168]
    6370:	97fff9e0 	bl	4af0 <fwp_mem_free>
    6374:	f900567f 	str	xzr, [x19, #168]
    6378:	b9405e60 	ldr	w0, [x19, #92]
    637c:	7100041f 	cmp	w0, #0x1
    6380:	54000420 	b.eq	6404 <fwp_task_dispose+0xd4>  // b.none
    6384:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6388:	91174042 	add	x2, x2, #0x5d0
    638c:	f949d840 	ldr	x0, [x2, #5040]
    6390:	f949ec41 	ldr	x1, [x2, #5080]
    6394:	cb000260 	sub	x0, x19, x0
    6398:	eb01401f 	cmp	x0, x1, lsl #16
    639c:	540002e2 	b.cs	63f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    63a0:	d350fc01 	lsr	x1, x0, #16
    63a4:	f949fc44 	ldr	x4, [x2, #5112]
    63a8:	8b010821 	add	x1, x1, x1, lsl #2
    63ac:	d37df021 	lsl	x1, x1, #3
    63b0:	8b010083 	add	x3, x4, x1
    63b4:	f9401062 	ldr	x2, [x3, #32]
    63b8:	b4000202 	cbz	x2, 63f8 <fwp_task_dispose+0xc8>
    63bc:	38616881 	ldrb	w1, [x4, x1]
    63c0:	7100083f 	cmp	w1, #0x2
    63c4:	54000280 	b.eq	6414 <fwp_task_dispose+0xe4>  // b.none
    63c8:	7100043f 	cmp	w1, #0x1
    63cc:	54000161 	b.ne	63f8 <fwp_task_dispose+0xc8>  // b.any
    63d0:	29430464 	ldp	w4, w1, [x3, #24]
    63d4:	92403c00 	and	x0, x0, #0xffff
    63d8:	9b047c00 	mul	x0, x0, x4
    63dc:	d360fc00 	lsr	x0, x0, #32
    63e0:	eb01001f 	cmp	x0, x1
    63e4:	540000a2 	b.cs	63f8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    63e8:	8b000042 	add	x2, x2, x0
    63ec:	39400040 	ldrb	w0, [x2]
    63f0:	7100041f 	cmp	w0, #0x1
    63f4:	54000080 	b.eq	6404 <fwp_task_dispose+0xd4>  // b.none
    63f8:	f9400bf3 	ldr	x19, [sp, #16]
    63fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6400:	d65f03c0 	ret
    6404:	aa1303e0 	mov	x0, x19
    6408:	f9400bf3 	ldr	x19, [sp, #16]
    640c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6410:	17fff9b8 	b	4af0 <fwp_mem_free>
    6414:	72003c1f 	tst	w0, #0xffff
    6418:	54fffea0 	b.eq	63ec <fwp_task_dispose+0xbc>  // b.none
    641c:	f9400bf3 	ldr	x19, [sp, #16]
    6420:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6424:	d65f03c0 	ret
    6428:	97fff14e 	bl	2960 <abort@plt>
    642c:	d503201f 	nop

0000000000006430 <fwp_free_zombie>:
    6430:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6434:	910003fd 	mov	x29, sp
    6438:	a90153f3 	stp	x19, x20, [sp, #16]
    643c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6440:	9101c281 	add	x1, x20, #0x70
    6444:	f9407833 	ldr	x19, [x1, #240]
    6448:	b4000333 	cbz	x19, 64ac <fwp_free_zombie+0x7c>
    644c:	f9400820 	ldr	x0, [x1, #16]
    6450:	eb00027f 	cmp	x19, x0
    6454:	540002c0 	b.eq	64ac <fwp_free_zombie+0x7c>  // b.none
    6458:	b940f822 	ldr	w2, [x1, #248]
    645c:	f9400a60 	ldr	x0, [x19, #16]
    6460:	7100fc5f 	cmp	w2, #0x3f
    6464:	5400078c 	b.gt	6554 <fwp_free_zombie+0x124>
    6468:	91040023 	add	x3, x1, #0x100
    646c:	11000444 	add	w4, w2, #0x1
    6470:	b900f824 	str	w4, [x1, #248]
    6474:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6478:	f822d860 	str	x0, [x3, w2, sxtw #3]
    647c:	a9530261 	ldp	x1, x0, [x19, #304]
    6480:	b4000741 	cbz	x1, 6568 <fwp_free_zombie+0x138>
    6484:	f9009c20 	str	x0, [x1, #312]
    6488:	b4000040 	cbz	x0, 6490 <fwp_free_zombie+0x60>
    648c:	f9009801 	str	x1, [x0, #304]
    6490:	9101c294 	add	x20, x20, #0x70
    6494:	b9405e60 	ldr	w0, [x19, #92]
    6498:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    649c:	f9007a9f 	str	xzr, [x20, #240]
    64a0:	34000140 	cbz	w0, 64c8 <fwp_free_zombie+0x98>
    64a4:	7100041f 	cmp	w0, #0x1
    64a8:	54000080 	b.eq	64b8 <fwp_free_zombie+0x88>  // b.none
    64ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    64b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64b4:	d65f03c0 	ret
    64b8:	aa1303e0 	mov	x0, x19
    64bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    64c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c4:	17ffff9b 	b	6330 <fwp_task_dispose>
    64c8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    64cc:	91174082 	add	x2, x4, #0x5d0
    64d0:	f949d841 	ldr	x1, [x2, #5040]
    64d4:	f949ec40 	ldr	x0, [x2, #5080]
    64d8:	cb010261 	sub	x1, x19, x1
    64dc:	eb00403f 	cmp	x1, x0, lsl #16
    64e0:	54fffe62 	b.cs	64ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    64e4:	d350fc20 	lsr	x0, x1, #16
    64e8:	f949fc43 	ldr	x3, [x2, #5112]
    64ec:	8b000800 	add	x0, x0, x0, lsl #2
    64f0:	d37df000 	lsl	x0, x0, #3
    64f4:	8b000062 	add	x2, x3, x0
    64f8:	f9401054 	ldr	x20, [x2, #32]
    64fc:	b4fffd94 	cbz	x20, 64ac <fwp_free_zombie+0x7c>
    6500:	38606860 	ldrb	w0, [x3, x0]
    6504:	7100081f 	cmp	w0, #0x2
    6508:	54000360 	b.eq	6574 <fwp_free_zombie+0x144>  // b.none
    650c:	7100041f 	cmp	w0, #0x1
    6510:	54fffce1 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    6514:	29430043 	ldp	w3, w0, [x2, #24]
    6518:	92403c21 	and	x1, x1, #0xffff
    651c:	9b037c21 	mul	x1, x1, x3
    6520:	d360fc21 	lsr	x1, x1, #32
    6524:	eb00003f 	cmp	x1, x0
    6528:	54fffc22 	b.cs	64ac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    652c:	8b010294 	add	x20, x20, x1
    6530:	39400280 	ldrb	w0, [x20]
    6534:	34fffbc0 	cbz	w0, 64ac <fwp_free_zombie+0x7c>
    6538:	7100041f 	cmp	w0, #0x1
    653c:	54fffbe0 	b.eq	64b8 <fwp_free_zombie+0x88>  // b.none
    6540:	7103fc1f 	cmp	w0, #0xff
    6544:	540001e0 	b.eq	6580 <fwp_free_zombie+0x150>  // b.none
    6548:	51000400 	sub	w0, w0, #0x1
    654c:	39000280 	strb	w0, [x20]
    6550:	17ffffd7 	b	64ac <fwp_free_zombie+0x7c>
    6554:	f9400e61 	ldr	x1, [x19, #24]
    6558:	97fff136 	bl	2a30 <munmap@plt>
    655c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6560:	a9530261 	ldp	x1, x0, [x19, #304]
    6564:	b5fff901 	cbnz	x1, 6484 <fwp_free_zombie+0x54>
    6568:	9101c282 	add	x2, x20, #0x70
    656c:	f9018040 	str	x0, [x2, #768]
    6570:	17ffffc6 	b	6488 <fwp_free_zombie+0x58>
    6574:	72003c3f 	tst	w1, #0xffff
    6578:	54fff9a1 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    657c:	17ffffed 	b	6530 <fwp_free_zombie+0x100>
    6580:	ca544680 	eor	x0, x20, x20, lsr #17
    6584:	91174084 	add	x4, x4, #0x5d0
    6588:	ca402400 	eor	x0, x0, x0, lsr #9
    658c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6590:	f94a2400 	ldr	x0, [x0, #5192]
    6594:	b5000080 	cbnz	x0, 65a4 <fwp_free_zombie+0x174>
    6598:	14000010 	b	65d8 <fwp_free_zombie+0x1a8>
    659c:	f9400800 	ldr	x0, [x0, #16]
    65a0:	b40001c0 	cbz	x0, 65d8 <fwp_free_zombie+0x1a8>
    65a4:	f9400001 	ldr	x1, [x0]
    65a8:	eb14003f 	cmp	x1, x20
    65ac:	54ffff81 	b.ne	659c <fwp_free_zombie+0x16c>  // b.any
    65b0:	f9400401 	ldr	x1, [x0, #8]
    65b4:	d1000421 	sub	x1, x1, #0x1
    65b8:	f9000401 	str	x1, [x0, #8]
    65bc:	f103f83f 	cmp	x1, #0xfe
    65c0:	54fff761 	b.ne	64ac <fwp_free_zombie+0x7c>  // b.any
    65c4:	aa1403e0 	mov	x0, x20
    65c8:	97fff8aa 	bl	4870 <fwp_rc_forget_slot>
    65cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65d0:	39000280 	strb	w0, [x20]
    65d4:	17ffffb6 	b	64ac <fwp_free_zombie+0x7c>
    65d8:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    65dc:	9136c000 	add	x0, x0, #0xdb0
    65e0:	97fff4a8 	bl	3880 <fwp_trap>

00000000000065e4 <fwp_block>:
    65e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65e8:	910003fd 	mov	x29, sp
    65ec:	a90153f3 	stp	x19, x20, [sp, #16]
    65f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    65f4:	9101c274 	add	x20, x19, #0x70
    65f8:	f9404282 	ldr	x2, [x20, #128]
    65fc:	b4000622 	cbz	x2, 66c0 <fwp_block+0xdc>
    6600:	9101c261 	add	x1, x19, #0x70
    6604:	f9408040 	ldr	x0, [x2, #256]
    6608:	f9004020 	str	x0, [x1, #128]
    660c:	b4000680 	cbz	x0, 66dc <fwp_block+0xf8>
    6610:	9101c263 	add	x3, x19, #0x70
    6614:	3901505f 	strb	wzr, [x2, #84]
    6618:	f9400864 	ldr	x4, [x3, #16]
    661c:	eb02009f 	cmp	x4, x2
    6620:	54000440 	b.eq	66a8 <fwp_block+0xc4>  // b.none
    6624:	f9418465 	ldr	x5, [x3, #776]
    6628:	f9000862 	str	x2, [x3, #16]
    662c:	f9400441 	ldr	x1, [x2, #8]
    6630:	f9004885 	str	x5, [x4, #144]
    6634:	f9418865 	ldr	x5, [x3, #784]
    6638:	f9004c85 	str	x5, [x4, #152]
    663c:	f9418c65 	ldr	x5, [x3, #792]
    6640:	f9005085 	str	x5, [x4, #160]
    6644:	f9419065 	ldr	x5, [x3, #800]
    6648:	f9005485 	str	x5, [x4, #168]
    664c:	f9419465 	ldr	x5, [x3, #808]
    6650:	f9005885 	str	x5, [x4, #176]
    6654:	f9419865 	ldr	x5, [x3, #816]
    6658:	f9005c85 	str	x5, [x4, #184]
    665c:	f9419c65 	ldr	x5, [x3, #824]
    6660:	f9006085 	str	x5, [x4, #192]
    6664:	f9400480 	ldr	x0, [x4, #8]
    6668:	f9404844 	ldr	x4, [x2, #144]
    666c:	f9018464 	str	x4, [x3, #776]
    6670:	f9404c44 	ldr	x4, [x2, #152]
    6674:	f9018864 	str	x4, [x3, #784]
    6678:	f9405044 	ldr	x4, [x2, #160]
    667c:	f9018c64 	str	x4, [x3, #792]
    6680:	f9405444 	ldr	x4, [x2, #168]
    6684:	f9019064 	str	x4, [x3, #800]
    6688:	f9405844 	ldr	x4, [x2, #176]
    668c:	f9019464 	str	x4, [x3, #808]
    6690:	a94b8844 	ldp	x4, x2, [x2, #184]
    6694:	f9019864 	str	x4, [x3, #816]
    6698:	f9019c62 	str	x2, [x3, #824]
    669c:	97fff0b5 	bl	2970 <swapcontext@plt>
    66a0:	97ffff64 	bl	6430 <fwp_free_zombie>
    66a4:	d503201f 	nop
    66a8:	9101c260 	add	x0, x19, #0x70
    66ac:	b9434000 	ldr	w0, [x0, #832]
    66b0:	340001a0 	cbz	w0, 66e4 <fwp_block+0x100>
    66b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66bc:	d65f03c0 	ret
    66c0:	97fff798 	bl	4520 <fwp_poll_events>
    66c4:	f9404282 	ldr	x2, [x20, #128]
    66c8:	b4ffffc2 	cbz	x2, 66c0 <fwp_block+0xdc>
    66cc:	9101c261 	add	x1, x19, #0x70
    66d0:	f9408040 	ldr	x0, [x2, #256]
    66d4:	f9004020 	str	x0, [x1, #128]
    66d8:	b5fff9c0 	cbnz	x0, 6610 <fwp_block+0x2c>
    66dc:	f9003c3f 	str	xzr, [x1, #120]
    66e0:	17ffffcc 	b	6610 <fwp_block+0x2c>
    66e4:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    66e8:	913b8000 	add	x0, x0, #0xee0
    66ec:	97fff0ed 	bl	2aa0 <getenv@plt>
    66f0:	5284e202 	mov	w2, #0x2710                	// #10000
    66f4:	b4000060 	cbz	x0, 6700 <fwp_block+0x11c>
    66f8:	39400001 	ldrb	w1, [x0]
    66fc:	350000c1 	cbnz	w1, 6714 <fwp_block+0x130>
    6700:	9101c273 	add	x19, x19, #0x70
    6704:	b9034262 	str	w2, [x19, #832]
    6708:	a94153f3 	ldp	x19, x20, [sp, #16]
    670c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6710:	d65f03c0 	ret
    6714:	52800142 	mov	w2, #0xa                   	// #10
    6718:	d2800001 	mov	x1, #0x0                   	// #0
    671c:	97fff031 	bl	27e0 <strtoll@plt>
    6720:	d1000403 	sub	x3, x0, #0x1
    6724:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6728:	eb02007f 	cmp	x3, x2
    672c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6730:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6734:	17fffff3 	b	6700 <fwp_block+0x11c>
    6738:	d503201f 	nop
    673c:	d503201f 	nop

0000000000006740 <fwp_drop10>:
    6740:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6744:	910003fd 	mov	x29, sp
    6748:	a90153f3 	stp	x19, x20, [sp, #16]
    674c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6750:	f90013f5 	str	x21, [sp, #32]
    6754:	91174275 	add	x21, x19, #0x5d0
    6758:	f949daa1 	ldr	x1, [x21, #5040]
    675c:	f949eea2 	ldr	x2, [x21, #5080]
    6760:	cb010001 	sub	x1, x0, x1
    6764:	eb02403f 	cmp	x1, x2, lsl #16
    6768:	54000382 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    676c:	d350fc22 	lsr	x2, x1, #16
    6770:	f949fea3 	ldr	x3, [x21, #5112]
    6774:	8b020842 	add	x2, x2, x2, lsl #2
    6778:	d37df042 	lsl	x2, x2, #3
    677c:	8b020064 	add	x4, x3, x2
    6780:	f9401094 	ldr	x20, [x4, #32]
    6784:	b40002b4 	cbz	x20, 67d8 <fwp_drop10+0x98>
    6788:	38626862 	ldrb	w2, [x3, x2]
    678c:	7100085f 	cmp	w2, #0x2
    6790:	540007a0 	b.eq	6884 <fwp_drop10+0x144>  // b.none
    6794:	7100045f 	cmp	w2, #0x1
    6798:	54000201 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    679c:	29430885 	ldp	w5, w2, [x4, #24]
    67a0:	92403c21 	and	x1, x1, #0xffff
    67a4:	9b057c21 	mul	x1, x1, x5
    67a8:	d360fc21 	lsr	x1, x1, #32
    67ac:	eb02003f 	cmp	x1, x2
    67b0:	54000142 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    67b4:	8b010294 	add	x20, x20, x1
    67b8:	39400281 	ldrb	w1, [x20]
    67bc:	340000e1 	cbz	w1, 67d8 <fwp_drop10+0x98>
    67c0:	7100043f 	cmp	w1, #0x1
    67c4:	54000120 	b.eq	67e8 <fwp_drop10+0xa8>  // b.none
    67c8:	7103fc3f 	cmp	w1, #0xff
    67cc:	540007c0 	b.eq	68c4 <fwp_drop10+0x184>  // b.none
    67d0:	51000421 	sub	w1, w1, #0x1
    67d4:	39000281 	strb	w1, [x20]
    67d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67dc:	f94013f5 	ldr	x21, [sp, #32]
    67e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67e4:	d65f03c0 	ret
    67e8:	f9400001 	ldr	x1, [x0]
    67ec:	b7f80581 	tbnz	x1, #63, 689c <fwp_drop10+0x15c>
    67f0:	91174273 	add	x19, x19, #0x5d0
    67f4:	f949da61 	ldr	x1, [x19, #5040]
    67f8:	f949ee62 	ldr	x2, [x19, #5080]
    67fc:	cb010001 	sub	x1, x0, x1
    6800:	eb02403f 	cmp	x1, x2, lsl #16
    6804:	54fffea2 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6808:	d350fc22 	lsr	x2, x1, #16
    680c:	8b020842 	add	x2, x2, x2, lsl #2
    6810:	d37df042 	lsl	x2, x2, #3
    6814:	8b020065 	add	x5, x3, x2
    6818:	f94010a4 	ldr	x4, [x5, #32]
    681c:	b4fffde4 	cbz	x4, 67d8 <fwp_drop10+0x98>
    6820:	38626862 	ldrb	w2, [x3, x2]
    6824:	7100085f 	cmp	w2, #0x2
    6828:	54000220 	b.eq	686c <fwp_drop10+0x12c>  // b.none
    682c:	7100045f 	cmp	w2, #0x1
    6830:	54fffd41 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    6834:	294308a3 	ldp	w3, w2, [x5, #24]
    6838:	92403c21 	and	x1, x1, #0xffff
    683c:	9b037c21 	mul	x1, x1, x3
    6840:	d360fc21 	lsr	x1, x1, #32
    6844:	eb02003f 	cmp	x1, x2
    6848:	54fffc82 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    684c:	8b010084 	add	x4, x4, x1
    6850:	39400081 	ldrb	w1, [x4]
    6854:	7100043f 	cmp	w1, #0x1
    6858:	54fffc01 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    685c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6860:	f94013f5 	ldr	x21, [sp, #32]
    6864:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6868:	17fff8a2 	b	4af0 <fwp_mem_free>
    686c:	72003c3f 	tst	w1, #0xffff
    6870:	54ffff00 	b.eq	6850 <fwp_drop10+0x110>  // b.none
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	f94013f5 	ldr	x21, [sp, #32]
    687c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6880:	d65f03c0 	ret
    6884:	72003c3f 	tst	w1, #0xffff
    6888:	54fff980 	b.eq	67b8 <fwp_drop10+0x78>  // b.none
    688c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6890:	f94013f5 	ldr	x21, [sp, #32]
    6894:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6898:	d65f03c0 	ret
    689c:	f9400414 	ldr	x20, [x0, #8]
    68a0:	97fffb5d 	bl	5614 <fwp_rc_free_arr>
    68a4:	91174260 	add	x0, x19, #0x5d0
    68a8:	f949d801 	ldr	x1, [x0, #5040]
    68ac:	f949ec00 	ldr	x0, [x0, #5080]
    68b0:	cb010281 	sub	x1, x20, x1
    68b4:	eb00403f 	cmp	x1, x0, lsl #16
    68b8:	54fff902 	b.cs	67d8 <fwp_drop10+0x98>  // b.hs, b.nlast
    68bc:	aa1403e0 	mov	x0, x20
    68c0:	17ffffab 	b	676c <fwp_drop10+0x2c>
    68c4:	ca544680 	eor	x0, x20, x20, lsr #17
    68c8:	91174273 	add	x19, x19, #0x5d0
    68cc:	ca402400 	eor	x0, x0, x0, lsr #9
    68d0:	8b200e60 	add	x0, x19, w0, uxtb #3
    68d4:	f94a2400 	ldr	x0, [x0, #5192]
    68d8:	b5000080 	cbnz	x0, 68e8 <fwp_drop10+0x1a8>
    68dc:	14000010 	b	691c <fwp_drop10+0x1dc>
    68e0:	f9400800 	ldr	x0, [x0, #16]
    68e4:	b40001c0 	cbz	x0, 691c <fwp_drop10+0x1dc>
    68e8:	f9400001 	ldr	x1, [x0]
    68ec:	eb14003f 	cmp	x1, x20
    68f0:	54ffff81 	b.ne	68e0 <fwp_drop10+0x1a0>  // b.any
    68f4:	f9400401 	ldr	x1, [x0, #8]
    68f8:	d1000421 	sub	x1, x1, #0x1
    68fc:	f9000401 	str	x1, [x0, #8]
    6900:	f103f83f 	cmp	x1, #0xfe
    6904:	54fff6a1 	b.ne	67d8 <fwp_drop10+0x98>  // b.any
    6908:	aa1403e0 	mov	x0, x20
    690c:	97fff7d9 	bl	4870 <fwp_rc_forget_slot>
    6910:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6914:	39000280 	strb	w0, [x20]
    6918:	17ffffb0 	b	67d8 <fwp_drop10+0x98>
    691c:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    6920:	9136c000 	add	x0, x0, #0xdb0
    6924:	97fff3d7 	bl	3880 <fwp_trap>
    6928:	d503201f 	nop
    692c:	d503201f 	nop

0000000000006930 <fwp_caps173>:
    6930:	34000041 	cbz	w1, 6938 <fwp_caps173+0x8>
    6934:	d65f03c0 	ret
    6938:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    693c:	91174063 	add	x3, x3, #0x5d0
    6940:	f949d861 	ldr	x1, [x3, #5040]
    6944:	f949ec62 	ldr	x2, [x3, #5080]
    6948:	cb010001 	sub	x1, x0, x1
    694c:	eb02403f 	cmp	x1, x2, lsl #16
    6950:	54ffff22 	b.cs	6934 <fwp_caps173+0x4>  // b.hs, b.nlast
    6954:	d350fc22 	lsr	x2, x1, #16
    6958:	f949fc65 	ldr	x5, [x3, #5112]
    695c:	8b020842 	add	x2, x2, x2, lsl #2
    6960:	d37df042 	lsl	x2, x2, #3
    6964:	8b0200a4 	add	x4, x5, x2
    6968:	f9401083 	ldr	x3, [x4, #32]
    696c:	b4fffe43 	cbz	x3, 6934 <fwp_caps173+0x4>
    6970:	386268a2 	ldrb	w2, [x5, x2]
    6974:	7100085f 	cmp	w2, #0x2
    6978:	540001c0 	b.eq	69b0 <fwp_caps173+0x80>  // b.none
    697c:	7100045f 	cmp	w2, #0x1
    6980:	54fffda1 	b.ne	6934 <fwp_caps173+0x4>  // b.any
    6984:	29430885 	ldp	w5, w2, [x4, #24]
    6988:	92403c21 	and	x1, x1, #0xffff
    698c:	9b057c21 	mul	x1, x1, x5
    6990:	d360fc21 	lsr	x1, x1, #32
    6994:	eb02003f 	cmp	x1, x2
    6998:	54fffce2 	b.cs	6934 <fwp_caps173+0x4>  // b.hs, b.nlast
    699c:	8b010063 	add	x3, x3, x1
    69a0:	39400061 	ldrb	w1, [x3]
    69a4:	7100043f 	cmp	w1, #0x1
    69a8:	54fffc61 	b.ne	6934 <fwp_caps173+0x4>  // b.any
    69ac:	17fff851 	b	4af0 <fwp_mem_free>
    69b0:	72003c3f 	tst	w1, #0xffff
    69b4:	54ffff60 	b.eq	69a0 <fwp_caps173+0x70>  // b.none
    69b8:	d65f03c0 	ret
    69bc:	d503201f 	nop

00000000000069c0 <f37>:
    69c0:	d10203ff 	sub	sp, sp, #0x80
    69c4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    69c8:	f947f421 	ldr	x1, [x1, #4072]
    69cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    69d0:	910083fd 	add	x29, sp, #0x20
    69d4:	a9045bf5 	stp	x21, x22, [sp, #64]
    69d8:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    69dc:	911742c3 	add	x3, x22, #0x5d0
    69e0:	a90353f3 	stp	x19, x20, [sp, #48]
    69e4:	a90563f7 	stp	x23, x24, [sp, #80]
    69e8:	aa0003f8 	mov	x24, x0
    69ec:	a9066bf9 	stp	x25, x26, [sp, #96]
    69f0:	f949ec62 	ldr	x2, [x3, #5080]
    69f4:	f9400024 	ldr	x4, [x1]
    69f8:	f9000fe4 	str	x4, [sp, #24]
    69fc:	d2800004 	mov	x4, #0x0                   	// #0
    6a00:	f949d861 	ldr	x1, [x3, #5040]
    6a04:	d370bc42 	lsl	x2, x2, #16
    6a08:	b40017e0 	cbz	x0, 6d04 <f37+0x344>
    6a0c:	f9400819 	ldr	x25, [x0, #16]
    6a10:	cb010321 	sub	x1, x25, x1
    6a14:	eb02003f 	cmp	x1, x2
    6a18:	54000362 	b.cs	6a84 <f37+0xc4>  // b.hs, b.nlast
    6a1c:	f949fc60 	ldr	x0, [x3, #5112]
    6a20:	d350fc22 	lsr	x2, x1, #16
    6a24:	8b020842 	add	x2, x2, x2, lsl #2
    6a28:	8b020c02 	add	x2, x0, x2, lsl #3
    6a2c:	f9401040 	ldr	x0, [x2, #32]
    6a30:	b40002a0 	cbz	x0, 6a84 <f37+0xc4>
    6a34:	39400043 	ldrb	w3, [x2]
    6a38:	7100087f 	cmp	w3, #0x2
    6a3c:	540015e0 	b.eq	6cf8 <f37+0x338>  // b.none
    6a40:	7100047f 	cmp	w3, #0x1
    6a44:	540001c1 	b.ne	6a7c <f37+0xbc>  // b.any
    6a48:	29430843 	ldp	w3, w2, [x2, #24]
    6a4c:	92403c21 	and	x1, x1, #0xffff
    6a50:	9b037c21 	mul	x1, x1, x3
    6a54:	d360fc21 	lsr	x1, x1, #32
    6a58:	eb02003f 	cmp	x1, x2
    6a5c:	54000102 	b.cs	6a7c <f37+0xbc>  // b.hs, b.nlast
    6a60:	8b010000 	add	x0, x0, x1
    6a64:	39400001 	ldrb	w1, [x0]
    6a68:	340000a1 	cbz	w1, 6a7c <f37+0xbc>
    6a6c:	7103f43f 	cmp	w1, #0xfd
    6a70:	54001888 	b.hi	6d80 <f37+0x3c0>  // b.pmore
    6a74:	11000421 	add	w1, w1, #0x1
    6a78:	39000001 	strb	w1, [x0]
    6a7c:	d2800000 	mov	x0, #0x0                   	// #0
    6a80:	b40000f8 	cbz	x24, 6a9c <f37+0xdc>
    6a84:	aa1803e1 	mov	x1, x24
    6a88:	d2800000 	mov	x0, #0x0                   	// #0
    6a8c:	d503201f 	nop
    6a90:	f9400821 	ldr	x1, [x1, #16]
    6a94:	91000400 	add	x0, x0, #0x1
    6a98:	b5ffffc1 	cbnz	x1, 6a90 <f37+0xd0>
    6a9c:	b40013b9 	cbz	x25, 6d10 <f37+0x350>
    6aa0:	aa1903e1 	mov	x1, x25
    6aa4:	d2800002 	mov	x2, #0x0                   	// #0
    6aa8:	f9400821 	ldr	x1, [x1, #16]
    6aac:	91000442 	add	x2, x2, #0x1
    6ab0:	b5ffffc1 	cbnz	x1, 6aa8 <f37+0xe8>
    6ab4:	eb00005f 	cmp	x2, x0
    6ab8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6abc:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    6ac0:	eb01035f 	cmp	x26, x1
    6ac4:	54001668 	b.hi	6d90 <f37+0x3d0>  // b.pmore
    6ac8:	d37ffb53 	lsl	x19, x26, #1
    6acc:	52800041 	mov	w1, #0x2                   	// #2
    6ad0:	91000660 	add	x0, x19, #0x1
    6ad4:	d37df000 	lsl	x0, x0, #3
    6ad8:	97fff926 	bl	4f70 <fwp_heap_alloc>
    6adc:	aa0003f7 	mov	x23, x0
    6ae0:	911742c1 	add	x1, x22, #0x5d0
    6ae4:	aa0103e0 	mov	x0, x1
    6ae8:	f90002f3 	str	x19, [x23]
    6aec:	f949d821 	ldr	x1, [x1, #5040]
    6af0:	f949ec00 	ldr	x0, [x0, #5080]
    6af4:	cb0102e1 	sub	x1, x23, x1
    6af8:	eb00403f 	cmp	x1, x0, lsl #16
    6afc:	54000342 	b.cs	6b64 <f37+0x1a4>  // b.hs, b.nlast
    6b00:	911742c2 	add	x2, x22, #0x5d0
    6b04:	d350fc20 	lsr	x0, x1, #16
    6b08:	8b000800 	add	x0, x0, x0, lsl #2
    6b0c:	f949fc43 	ldr	x3, [x2, #5112]
    6b10:	d37df002 	lsl	x2, x0, #3
    6b14:	8b020060 	add	x0, x3, x2
    6b18:	f9401013 	ldr	x19, [x0, #32]
    6b1c:	b4000253 	cbz	x19, 6b64 <f37+0x1a4>
    6b20:	38626862 	ldrb	w2, [x3, x2]
    6b24:	7100085f 	cmp	w2, #0x2
    6b28:	54000e20 	b.eq	6cec <f37+0x32c>  // b.none
    6b2c:	7100045f 	cmp	w2, #0x1
    6b30:	540001a1 	b.ne	6b64 <f37+0x1a4>  // b.any
    6b34:	29430002 	ldp	w2, w0, [x0, #24]
    6b38:	92403c21 	and	x1, x1, #0xffff
    6b3c:	9b027c21 	mul	x1, x1, x2
    6b40:	d360fc21 	lsr	x1, x1, #32
    6b44:	eb00003f 	cmp	x1, x0
    6b48:	540000e2 	b.cs	6b64 <f37+0x1a4>  // b.hs, b.nlast
    6b4c:	8b010273 	add	x19, x19, x1
    6b50:	39400260 	ldrb	w0, [x19]
    6b54:	7103fc1f 	cmp	w0, #0xff
    6b58:	54000f80 	b.eq	6d48 <f37+0x388>  // b.none
    6b5c:	52800020 	mov	w0, #0x1                   	// #1
    6b60:	39000260 	strb	w0, [x19]
    6b64:	b400025a 	cbz	x26, 6bac <f37+0x1ec>
    6b68:	8b1a12fa 	add	x26, x23, x26, lsl #4
    6b6c:	aa1703f3 	mov	x19, x23
    6b70:	aa1803f5 	mov	x21, x24
    6b74:	aa1903f4 	mov	x20, x25
    6b78:	f9400683 	ldr	x3, [x20, #8]
    6b7c:	f94006a2 	ldr	x2, [x21, #8]
    6b80:	f9400861 	ldr	x1, [x3, #16]
    6b84:	f9400840 	ldr	x0, [x2, #16]
    6b88:	fd400461 	ldr	d1, [x3, #8]
    6b8c:	fd400440 	ldr	d0, [x2, #8]
    6b90:	97fffa38 	bl	5470 <w120>
    6b94:	f9000660 	str	x0, [x19, #8]
    6b98:	f8010e61 	str	x1, [x19, #16]!
    6b9c:	f9400a94 	ldr	x20, [x20, #16]
    6ba0:	f9400ab5 	ldr	x21, [x21, #16]
    6ba4:	eb13035f 	cmp	x26, x19
    6ba8:	54fffe81 	b.ne	6b78 <f37+0x1b8>  // b.any
    6bac:	aa1903e0 	mov	x0, x25
    6bb0:	97fffd48 	bl	60d0 <fwp_drop4>
    6bb4:	aa1803e0 	mov	x0, x24
    6bb8:	97fffd46 	bl	60d0 <fwp_drop4>
    6bbc:	f94002f5 	ldr	x21, [x23]
    6bc0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6bc4:	b4000275 	cbz	x21, 6c10 <f37+0x250>
    6bc8:	fd003be8 	str	d8, [sp, #112]
    6bcc:	2f00e408 	movi	d8, #0x0
    6bd0:	910022f9 	add	x25, x23, #0x8
    6bd4:	910042f8 	add	x24, x23, #0x10
    6bd8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6bdc:	d2800013 	mov	x19, #0x0                   	// #0
    6be0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6be4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6be8:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    6bec:	aa0303e1 	mov	x1, x3
    6bf0:	1e602908 	fadd	d8, d8, d0
    6bf4:	91000a73 	add	x19, x19, #0x2
    6bf8:	97fff96b 	bl	51a4 <fwp_p_ad_push>
    6bfc:	aa0003f4 	mov	x20, x0
    6c00:	eb1302bf 	cmp	x21, x19
    6c04:	54fffee8 	b.hi	6be0 <f37+0x220>  // b.pmore
    6c08:	9e660115 	fmov	x21, d8
    6c0c:	fd403be8 	ldr	d8, [sp, #112]
    6c10:	911742d6 	add	x22, x22, #0x5d0
    6c14:	aa1703e0 	mov	x0, x23
    6c18:	97fffeca 	bl	6740 <fwp_drop10>
    6c1c:	a900d3f5 	stp	x21, x20, [sp, #8]
    6c20:	910023e1 	add	x1, sp, #0x8
    6c24:	52800000 	mov	w0, #0x0                   	// #0
    6c28:	97fff917 	bl	5084 <fwp_data.part.0.constprop.0>
    6c2c:	f949dac1 	ldr	x1, [x22, #5040]
    6c30:	aa0003f3 	mov	x19, x0
    6c34:	f949eec0 	ldr	x0, [x22, #5080]
    6c38:	cb010261 	sub	x1, x19, x1
    6c3c:	eb00403f 	cmp	x1, x0, lsl #16
    6c40:	54000322 	b.cs	6ca4 <f37+0x2e4>  // b.hs, b.nlast
    6c44:	d350fc22 	lsr	x2, x1, #16
    6c48:	f949fec3 	ldr	x3, [x22, #5112]
    6c4c:	8b020842 	add	x2, x2, x2, lsl #2
    6c50:	d37df042 	lsl	x2, x2, #3
    6c54:	8b020060 	add	x0, x3, x2
    6c58:	f9401014 	ldr	x20, [x0, #32]
    6c5c:	b4000254 	cbz	x20, 6ca4 <f37+0x2e4>
    6c60:	38626862 	ldrb	w2, [x3, x2]
    6c64:	7100085f 	cmp	w2, #0x2
    6c68:	540003c0 	b.eq	6ce0 <f37+0x320>  // b.none
    6c6c:	7100045f 	cmp	w2, #0x1
    6c70:	540001a1 	b.ne	6ca4 <f37+0x2e4>  // b.any
    6c74:	29430002 	ldp	w2, w0, [x0, #24]
    6c78:	92403c21 	and	x1, x1, #0xffff
    6c7c:	9b027c21 	mul	x1, x1, x2
    6c80:	d360fc21 	lsr	x1, x1, #32
    6c84:	eb00003f 	cmp	x1, x0
    6c88:	540000e2 	b.cs	6ca4 <f37+0x2e4>  // b.hs, b.nlast
    6c8c:	8b010294 	add	x20, x20, x1
    6c90:	39400280 	ldrb	w0, [x20]
    6c94:	7103fc1f 	cmp	w0, #0xff
    6c98:	540005e0 	b.eq	6d54 <f37+0x394>  // b.none
    6c9c:	52800020 	mov	w0, #0x1                   	// #1
    6ca0:	39000280 	strb	w0, [x20]
    6ca4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6ca8:	f947f400 	ldr	x0, [x0, #4072]
    6cac:	f9400fe2 	ldr	x2, [sp, #24]
    6cb0:	f9400001 	ldr	x1, [x0]
    6cb4:	eb010042 	subs	x2, x2, x1
    6cb8:	d2800001 	mov	x1, #0x0                   	// #0
    6cbc:	54000721 	b.ne	6da0 <f37+0x3e0>  // b.any
    6cc0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6cc4:	aa1303e0 	mov	x0, x19
    6cc8:	a94353f3 	ldp	x19, x20, [sp, #48]
    6ccc:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6cd0:	a94563f7 	ldp	x23, x24, [sp, #80]
    6cd4:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6cd8:	910203ff 	add	sp, sp, #0x80
    6cdc:	d65f03c0 	ret
    6ce0:	72003c3f 	tst	w1, #0xffff
    6ce4:	54fffe01 	b.ne	6ca4 <f37+0x2e4>  // b.any
    6ce8:	17ffffea 	b	6c90 <f37+0x2d0>
    6cec:	72003c3f 	tst	w1, #0xffff
    6cf0:	54fff3a1 	b.ne	6b64 <f37+0x1a4>  // b.any
    6cf4:	17ffff97 	b	6b50 <f37+0x190>
    6cf8:	72003c3f 	tst	w1, #0xffff
    6cfc:	54ffec01 	b.ne	6a7c <f37+0xbc>  // b.any
    6d00:	17ffff59 	b	6a64 <f37+0xa4>
    6d04:	cb0103e1 	neg	x1, x1
    6d08:	eb02003f 	cmp	x1, x2
    6d0c:	540002a3 	b.cc	6d60 <f37+0x3a0>  // b.lo, b.ul, b.last
    6d10:	52800041 	mov	w1, #0x2                   	// #2
    6d14:	d2800100 	mov	x0, #0x8                   	// #8
    6d18:	97fff896 	bl	4f70 <fwp_heap_alloc>
    6d1c:	aa0003f7 	mov	x23, x0
    6d20:	911742c0 	add	x0, x22, #0x5d0
    6d24:	f90002ff 	str	xzr, [x23]
    6d28:	f949d801 	ldr	x1, [x0, #5040]
    6d2c:	f949ec00 	ldr	x0, [x0, #5080]
    6d30:	cb0102e1 	sub	x1, x23, x1
    6d34:	eb00403f 	cmp	x1, x0, lsl #16
    6d38:	54000282 	b.cs	6d88 <f37+0x3c8>  // b.hs, b.nlast
    6d3c:	d280001a 	mov	x26, #0x0                   	// #0
    6d40:	d2800019 	mov	x25, #0x0                   	// #0
    6d44:	17ffff6f 	b	6b00 <f37+0x140>
    6d48:	aa1303e0 	mov	x0, x19
    6d4c:	97fff6c9 	bl	4870 <fwp_rc_forget_slot>
    6d50:	17ffff83 	b	6b5c <f37+0x19c>
    6d54:	aa1403e0 	mov	x0, x20
    6d58:	97fff6c6 	bl	4870 <fwp_rc_forget_slot>
    6d5c:	17ffffd0 	b	6c9c <f37+0x2dc>
    6d60:	f949fc62 	ldr	x2, [x3, #5112]
    6d64:	d350fc20 	lsr	x0, x1, #16
    6d68:	8b000800 	add	x0, x0, x0, lsl #2
    6d6c:	8b000c42 	add	x2, x2, x0, lsl #3
    6d70:	f9401040 	ldr	x0, [x2, #32]
    6d74:	b4fffce0 	cbz	x0, 6d10 <f37+0x350>
    6d78:	d2800019 	mov	x25, #0x0                   	// #0
    6d7c:	17ffff2e 	b	6a34 <f37+0x74>
    6d80:	97fff675 	bl	4754 <fwp_rc_wide_dup>
    6d84:	17ffff3e 	b	6a7c <f37+0xbc>
    6d88:	d2800019 	mov	x25, #0x0                   	// #0
    6d8c:	17ffff88 	b	6bac <f37+0x1ec>
    6d90:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2000>
    6d94:	913bc000 	add	x0, x0, #0xef0
    6d98:	fd003be8 	str	d8, [sp, #112]
    6d9c:	97fff2b9 	bl	3880 <fwp_trap>
    6da0:	fd003be8 	str	d8, [sp, #112]
    6da4:	97ffeedb 	bl	2910 <__stack_chk_fail@plt>
    6da8:	d503201f 	nop
    6dac:	d503201f 	nop

0000000000006db0 <fwp_owned_entry37>:
    6db0:	f9400000 	ldr	x0, [x0]
    6db4:	17ffff03 	b	69c0 <f37>
    6db8:	d503201f 	nop
    6dbc:	d503201f 	nop

0000000000006dc0 <e37>:
    6dc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6dc4:	910003fd 	mov	x29, sp
    6dc8:	f9000bf3 	str	x19, [sp, #16]
    6dcc:	f9400013 	ldr	x19, [x0]
    6dd0:	aa1303e0 	mov	x0, x19
    6dd4:	97fff9eb 	bl	5580 <fwp_rc_share>
    6dd8:	aa1303e0 	mov	x0, x19
    6ddc:	97fffef9 	bl	69c0 <f37>
    6de0:	aa0003f3 	mov	x19, x0
    6de4:	97fff9e7 	bl	5580 <fwp_rc_share>
    6de8:	aa1303e0 	mov	x0, x19
    6dec:	f9400bf3 	ldr	x19, [sp, #16]
    6df0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6df4:	d65f03c0 	ret
    6df8:	d503201f 	nop
    6dfc:	d503201f 	nop

0000000000006e00 <fwp_args37>:
    6e00:	7100003f 	cmp	w1, #0x0
    6e04:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6e08:	54000041 	b.ne	6e10 <fwp_args37+0x10>  // b.any
    6e0c:	d65f03c0 	ret
    6e10:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6e14:	91174042 	add	x2, x2, #0x5d0
    6e18:	f9400001 	ldr	x1, [x0]
    6e1c:	f949d843 	ldr	x3, [x2, #5040]
    6e20:	f949ec40 	ldr	x0, [x2, #5080]
    6e24:	cb030021 	sub	x1, x1, x3
    6e28:	eb00403f 	cmp	x1, x0, lsl #16
    6e2c:	54ffff02 	b.cs	6e0c <fwp_args37+0xc>  // b.hs, b.nlast
    6e30:	d350fc20 	lsr	x0, x1, #16
    6e34:	f949fc44 	ldr	x4, [x2, #5112]
    6e38:	8b000800 	add	x0, x0, x0, lsl #2
    6e3c:	d37df002 	lsl	x2, x0, #3
    6e40:	8b020083 	add	x3, x4, x2
    6e44:	f9401060 	ldr	x0, [x3, #32]
    6e48:	b4fffe20 	cbz	x0, 6e0c <fwp_args37+0xc>
    6e4c:	38626882 	ldrb	w2, [x4, x2]
    6e50:	7100085f 	cmp	w2, #0x2
    6e54:	54000220 	b.eq	6e98 <fwp_args37+0x98>  // b.none
    6e58:	7100045f 	cmp	w2, #0x1
    6e5c:	54fffd81 	b.ne	6e0c <fwp_args37+0xc>  // b.any
    6e60:	29430864 	ldp	w4, w2, [x3, #24]
    6e64:	92403c21 	and	x1, x1, #0xffff
    6e68:	9b047c21 	mul	x1, x1, x4
    6e6c:	d360fc21 	lsr	x1, x1, #32
    6e70:	eb02003f 	cmp	x1, x2
    6e74:	54fffcc2 	b.cs	6e0c <fwp_args37+0xc>  // b.hs, b.nlast
    6e78:	8b010000 	add	x0, x0, x1
    6e7c:	39400001 	ldrb	w1, [x0]
    6e80:	34fffc61 	cbz	w1, 6e0c <fwp_args37+0xc>
    6e84:	7103f43f 	cmp	w1, #0xfd
    6e88:	540000e8 	b.hi	6ea4 <fwp_args37+0xa4>  // b.pmore
    6e8c:	11000421 	add	w1, w1, #0x1
    6e90:	39000001 	strb	w1, [x0]
    6e94:	d65f03c0 	ret
    6e98:	72003c3f 	tst	w1, #0xffff
    6e9c:	54ffff00 	b.eq	6e7c <fwp_args37+0x7c>  // b.none
    6ea0:	d65f03c0 	ret
    6ea4:	17fff62c 	b	4754 <fwp_rc_wide_dup>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <fwp_caps37>:
    6eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	f9000bf3 	str	x19, [sp, #16]
    6ebc:	aa0003f3 	mov	x19, x0
    6ec0:	b9400400 	ldr	w0, [x0, #4]
    6ec4:	340004a0 	cbz	w0, 6f58 <fwp_caps37+0xa8>
    6ec8:	f9400660 	ldr	x0, [x19, #8]
    6ecc:	350004e1 	cbnz	w1, 6f68 <fwp_caps37+0xb8>
    6ed0:	97fffc80 	bl	60d0 <fwp_drop4>
    6ed4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6ed8:	91174042 	add	x2, x2, #0x5d0
    6edc:	f949d840 	ldr	x0, [x2, #5040]
    6ee0:	f949ec41 	ldr	x1, [x2, #5080]
    6ee4:	cb000260 	sub	x0, x19, x0
    6ee8:	eb01401f 	cmp	x0, x1, lsl #16
    6eec:	54000382 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ef0:	d350fc01 	lsr	x1, x0, #16
    6ef4:	f949fc44 	ldr	x4, [x2, #5112]
    6ef8:	8b010821 	add	x1, x1, x1, lsl #2
    6efc:	d37df021 	lsl	x1, x1, #3
    6f00:	8b010083 	add	x3, x4, x1
    6f04:	f9401062 	ldr	x2, [x3, #32]
    6f08:	b40002a2 	cbz	x2, 6f5c <fwp_caps37+0xac>
    6f0c:	38616881 	ldrb	w1, [x4, x1]
    6f10:	7100083f 	cmp	w1, #0x2
    6f14:	540006c0 	b.eq	6fec <fwp_caps37+0x13c>  // b.none
    6f18:	7100043f 	cmp	w1, #0x1
    6f1c:	54000201 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6f20:	29430464 	ldp	w4, w1, [x3, #24]
    6f24:	92403c00 	and	x0, x0, #0xffff
    6f28:	9b047c00 	mul	x0, x0, x4
    6f2c:	d360fc00 	lsr	x0, x0, #32
    6f30:	eb01001f 	cmp	x0, x1
    6f34:	54000142 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f38:	8b000042 	add	x2, x2, x0
    6f3c:	39400040 	ldrb	w0, [x2]
    6f40:	7100041f 	cmp	w0, #0x1
    6f44:	540000c1 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6f48:	aa1303e0 	mov	x0, x19
    6f4c:	f9400bf3 	ldr	x19, [sp, #16]
    6f50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f54:	17fff6e7 	b	4af0 <fwp_mem_free>
    6f58:	34fffbe1 	cbz	w1, 6ed4 <fwp_caps37+0x24>
    6f5c:	f9400bf3 	ldr	x19, [sp, #16]
    6f60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f64:	d65f03c0 	ret
    6f68:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f6c:	91174042 	add	x2, x2, #0x5d0
    6f70:	f949d843 	ldr	x3, [x2, #5040]
    6f74:	f949ec41 	ldr	x1, [x2, #5080]
    6f78:	cb030000 	sub	x0, x0, x3
    6f7c:	eb01401f 	cmp	x0, x1, lsl #16
    6f80:	54fffee2 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f84:	d350fc01 	lsr	x1, x0, #16
    6f88:	f949fc44 	ldr	x4, [x2, #5112]
    6f8c:	8b010821 	add	x1, x1, x1, lsl #2
    6f90:	d37df021 	lsl	x1, x1, #3
    6f94:	8b010083 	add	x3, x4, x1
    6f98:	f9401062 	ldr	x2, [x3, #32]
    6f9c:	b4fffe02 	cbz	x2, 6f5c <fwp_caps37+0xac>
    6fa0:	38616881 	ldrb	w1, [x4, x1]
    6fa4:	7100083f 	cmp	w1, #0x2
    6fa8:	54000280 	b.eq	6ff8 <fwp_caps37+0x148>  // b.none
    6fac:	7100043f 	cmp	w1, #0x1
    6fb0:	54fffd61 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6fb4:	92403c01 	and	x1, x0, #0xffff
    6fb8:	29430064 	ldp	w4, w0, [x3, #24]
    6fbc:	9b047c21 	mul	x1, x1, x4
    6fc0:	d360fc21 	lsr	x1, x1, #32
    6fc4:	eb00003f 	cmp	x1, x0
    6fc8:	54fffca2 	b.cs	6f5c <fwp_caps37+0xac>  // b.hs, b.nlast
    6fcc:	8b010042 	add	x2, x2, x1
    6fd0:	39400040 	ldrb	w0, [x2]
    6fd4:	34fffc40 	cbz	w0, 6f5c <fwp_caps37+0xac>
    6fd8:	7103f41f 	cmp	w0, #0xfd
    6fdc:	54000148 	b.hi	7004 <fwp_caps37+0x154>  // b.pmore
    6fe0:	11000400 	add	w0, w0, #0x1
    6fe4:	39000040 	strb	w0, [x2]
    6fe8:	17ffffdd 	b	6f5c <fwp_caps37+0xac>
    6fec:	72003c1f 	tst	w0, #0xffff
    6ff0:	54fffb61 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    6ff4:	17ffffd2 	b	6f3c <fwp_caps37+0x8c>
    6ff8:	72003c1f 	tst	w0, #0xffff
    6ffc:	54fffb01 	b.ne	6f5c <fwp_caps37+0xac>  // b.any
    7000:	17fffff4 	b	6fd0 <fwp_caps37+0x120>
    7004:	f9400bf3 	ldr	x19, [sp, #16]
    7008:	aa0203e0 	mov	x0, x2
    700c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7010:	17fff5d1 	b	4754 <fwp_rc_wide_dup>

0000000000007014 <fwp_write>:
    7014:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7018:	910003fd 	mov	x29, sp
    701c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7020:	f947f484 	ldr	x4, [x4, #4072]
    7024:	a90153f3 	stp	x19, x20, [sp, #16]
    7028:	d10943ff 	sub	sp, sp, #0x250
    702c:	b9400045 	ldr	w5, [x2]
    7030:	aa0003f4 	mov	x20, x0
    7034:	f9400080 	ldr	x0, [x4]
    7038:	f90127e0 	str	x0, [sp, #584]
    703c:	d2800000 	mov	x0, #0x0                   	// #0
    7040:	710064bf 	cmp	w5, #0x19
    7044:	54000408 	b.hi	70c4 <fwp_write+0xb0>  // b.pmore
    7048:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    704c:	aa0103f3 	mov	x19, x1
    7050:	911f0000 	add	x0, x0, #0x7c0
    7054:	f9013bf5 	str	x21, [sp, #624]
    7058:	f9013ff6 	str	x22, [sp, #632]
    705c:	f90153fb 	str	x27, [sp, #672]
    7060:	f90157fc 	str	x28, [sp, #680]
    7064:	aa0203fc 	mov	x28, x2
    7068:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    706c:	10000061 	adr	x1, 7078 <fwp_write+0x64>
    7070:	8b20a820 	add	x0, x1, w0, sxth #2
    7074:	d61f0000 	br	x0
    7078:	910123e0 	add	x0, sp, #0x48
    707c:	aa1303e5 	mov	x5, x19
    7080:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x2000>
    7084:	aa0003f3 	mov	x19, x0
    7088:	913ce084 	add	x4, x4, #0xf38
    708c:	d2804003 	mov	x3, #0x200                 	// #512
    7090:	aa0303e1 	mov	x1, x3
    7094:	52800042 	mov	w2, #0x2                   	// #2
    7098:	97ffedfa 	bl	2880 <__snprintf_chk@plt>
    709c:	aa1303e0 	mov	x0, x19
    70a0:	97ffedc0 	bl	27a0 <strlen@plt>
    70a4:	aa1303e1 	mov	x1, x19
    70a8:	aa0003e2 	mov	x2, x0
    70ac:	aa1403e0 	mov	x0, x20
    70b0:	97fff158 	bl	3610 <buf_put>
    70b4:	f9413bf5 	ldr	x21, [sp, #624]
    70b8:	f9413ff6 	ldr	x22, [sp, #632]
    70bc:	f94153fb 	ldr	x27, [sp, #672]
    70c0:	f94157fc 	ldr	x28, [sp, #680]
    70c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    70c8:	f947f400 	ldr	x0, [x0, #4072]
    70cc:	f94127e2 	ldr	x2, [sp, #584]
    70d0:	f9400001 	ldr	x1, [x0]
    70d4:	eb010042 	subs	x2, x2, x1
    70d8:	d2800001 	mov	x1, #0x0                   	// #0
    70dc:	540077a1 	b.ne	7fd0 <fwp_write+0xfbc>  // b.any
    70e0:	910943ff 	add	sp, sp, #0x250
    70e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    70e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    70ec:	d65f03c0 	ret
    70f0:	910123e0 	add	x0, sp, #0x48
    70f4:	aa1303e5 	mov	x5, x19
    70f8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x2000>
    70fc:	aa0003f3 	mov	x19, x0
    7100:	913cc084 	add	x4, x4, #0xf30
    7104:	d2804003 	mov	x3, #0x200                 	// #512
    7108:	17ffffe2 	b	7090 <fwp_write+0x7c>
    710c:	71004cbf 	cmp	w5, #0x13
    7110:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    7114:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7118:	913c8000 	add	x0, x0, #0xf20
    711c:	913ca021 	add	x1, x1, #0xf28
    7120:	d2800082 	mov	x2, #0x4                   	// #4
    7124:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7128:	aa1403e0 	mov	x0, x20
    712c:	f90143f7 	str	x23, [sp, #640]
    7130:	d2800016 	mov	x22, #0x0                   	// #0
    7134:	f90147f8 	str	x24, [sp, #648]
    7138:	97fff136 	bl	3610 <buf_put>
    713c:	f9400260 	ldr	x0, [x19]
    7140:	f0000017 	adrp	x23, a000 <fwp_main_thread+0x2000>
    7144:	d2800015 	mov	x21, #0x0                   	// #0
    7148:	913ea2f7 	add	x23, x23, #0xfa8
    714c:	b4004780 	cbz	x0, 7a3c <fwp_write+0xa28>
    7150:	b9400380 	ldr	w0, [x28]
    7154:	52800003 	mov	w3, #0x0                   	// #0
    7158:	f9401f82 	ldr	x2, [x28, #56]
    715c:	71004c1f 	cmp	w0, #0x13
    7160:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7164:	aa1403e0 	mov	x0, x20
    7168:	8b010e61 	add	x1, x19, x1, lsl #3
    716c:	f9400421 	ldr	x1, [x1, #8]
    7170:	97ffffa9 	bl	7014 <fwp_write>
    7174:	b9400380 	ldr	w0, [x28]
    7178:	7100481f 	cmp	w0, #0x12
    717c:	54004b20 	b.eq	7ae0 <fwp_write+0xacc>  // b.none
    7180:	f9400260 	ldr	x0, [x19]
    7184:	910006b5 	add	x21, x21, #0x1
    7188:	91000ad6 	add	x22, x22, #0x2
    718c:	eb15001f 	cmp	x0, x21
    7190:	54004569 	b.ls	7a3c <fwp_write+0xa28>  // b.plast
    7194:	aa1703e1 	mov	x1, x23
    7198:	aa1403e0 	mov	x0, x20
    719c:	d2800042 	mov	x2, #0x2                   	// #2
    71a0:	97fff11c 	bl	3610 <buf_put>
    71a4:	17ffffeb 	b	7150 <fwp_write+0x13c>
    71a8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    71ac:	913d8021 	add	x1, x1, #0xf60
    71b0:	d28000c2 	mov	x2, #0x6                   	// #6
    71b4:	aa1403e0 	mov	x0, x20
    71b8:	91004273 	add	x19, x19, #0x10
    71bc:	97fff115 	bl	3610 <buf_put>
    71c0:	aa1303e0 	mov	x0, x19
    71c4:	97ffed77 	bl	27a0 <strlen@plt>
    71c8:	aa1303e1 	mov	x1, x19
    71cc:	aa0003e2 	mov	x2, x0
    71d0:	aa1403e0 	mov	x0, x20
    71d4:	97fff10f 	bl	3610 <buf_put>
    71d8:	528007c3 	mov	w3, #0x3e                  	// #62
    71dc:	aa1403e0 	mov	x0, x20
    71e0:	91001fe1 	add	x1, sp, #0x7
    71e4:	d2800022 	mov	x2, #0x1                   	// #1
    71e8:	39001fe3 	strb	w3, [sp, #7]
    71ec:	17ffffb1 	b	70b0 <fwp_write+0x9c>
    71f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71f4:	f947f400 	ldr	x0, [x0, #4072]
    71f8:	f94127e2 	ldr	x2, [sp, #584]
    71fc:	f9400001 	ldr	x1, [x0]
    7200:	eb010042 	subs	x2, x2, x1
    7204:	d2800001 	mov	x1, #0x0                   	// #0
    7208:	540034c1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    720c:	f9413bf5 	ldr	x21, [sp, #624]
    7210:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7214:	f9413ff6 	ldr	x22, [sp, #632]
    7218:	aa1403e0 	mov	x0, x20
    721c:	913d0021 	add	x1, x1, #0xf40
    7220:	d2800142 	mov	x2, #0xa                   	// #10
    7224:	f94153fb 	ldr	x27, [sp, #672]
    7228:	f94157fc 	ldr	x28, [sp, #680]
    722c:	910943ff 	add	sp, sp, #0x250
    7230:	a94153f3 	ldp	x19, x20, [sp, #16]
    7234:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7238:	17fff0f6 	b	3610 <buf_put>
    723c:	f9400456 	ldr	x22, [x2, #8]
    7240:	f90143f7 	str	x23, [sp, #640]
    7244:	f90147f8 	str	x24, [sp, #648]
    7248:	b4005af6 	cbz	x22, 7da4 <fwp_write+0xd90>
    724c:	aa1603e0 	mov	x0, x22
    7250:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7254:	913f0021 	add	x1, x1, #0xfc0
    7258:	97ffedce 	bl	2990 <strcmp@plt>
    725c:	2a0003f5 	mov	w21, w0
    7260:	34005fc0 	cbz	w0, 7e58 <fwp_write+0xe44>
    7264:	aa1603e0 	mov	x0, x22
    7268:	97ffed4e 	bl	27a0 <strlen@plt>
    726c:	aa1603e1 	mov	x1, x22
    7270:	aa0003e2 	mov	x2, x0
    7274:	aa1403e0 	mov	x0, x20
    7278:	97fff0e6 	bl	3610 <buf_put>
    727c:	52800403 	mov	w3, #0x20                  	// #32
    7280:	91001ff5 	add	x21, sp, #0x7
    7284:	aa1503e1 	mov	x1, x21
    7288:	aa1403e0 	mov	x0, x20
    728c:	d2800022 	mov	x2, #0x1                   	// #1
    7290:	39001fe3 	strb	w3, [sp, #7]
    7294:	97fff0df 	bl	3610 <buf_put>
    7298:	52800f63 	mov	w3, #0x7b                  	// #123
    729c:	aa1403e0 	mov	x0, x20
    72a0:	aa1503e1 	mov	x1, x21
    72a4:	d2800022 	mov	x2, #0x1                   	// #1
    72a8:	39001fe3 	strb	w3, [sp, #7]
    72ac:	97fff0d9 	bl	3610 <buf_put>
    72b0:	b9401380 	ldr	w0, [x28, #16]
    72b4:	52800018 	mov	w24, #0x0                   	// #0
    72b8:	7100001f 	cmp	w0, #0x0
    72bc:	54003a8d 	b.le	7a0c <fwp_write+0x9f8>
    72c0:	f9014bf9 	str	x25, [sp, #656]
    72c4:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2000>
    72c8:	913fa339 	add	x25, x25, #0xfe8
    72cc:	f9014ffa 	str	x26, [sp, #664]
    72d0:	f000001a 	adrp	x26, a000 <fwp_main_thread+0x2000>
    72d4:	913ea35a 	add	x26, x26, #0xfa8
    72d8:	91002276 	add	x22, x19, #0x8
    72dc:	d2800013 	mov	x19, #0x0                   	// #0
    72e0:	b5003e73 	cbnz	x19, 7aac <fwp_write+0xa98>
    72e4:	d37df277 	lsl	x23, x19, #3
    72e8:	34003c98 	cbz	w24, 7a78 <fwp_write+0xa64>
    72ec:	f9401382 	ldr	x2, [x28, #32]
    72f0:	aa1403e0 	mov	x0, x20
    72f4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    72f8:	52800003 	mov	w3, #0x0                   	// #0
    72fc:	f8776842 	ldr	x2, [x2, x23]
    7300:	91000673 	add	x19, x19, #0x1
    7304:	97ffff44 	bl	7014 <fwp_write>
    7308:	b9401380 	ldr	w0, [x28, #16]
    730c:	6b13001f 	cmp	w0, w19
    7310:	54fffe8c 	b.gt	72e0 <fwp_write+0x2cc>
    7314:	f9414bf9 	ldr	x25, [sp, #656]
    7318:	f9414ffa 	ldr	x26, [sp, #664]
    731c:	34003798 	cbz	w24, 7a0c <fwp_write+0x9f8>
    7320:	52800523 	mov	w3, #0x29                  	// #41
    7324:	aa1503e1 	mov	x1, x21
    7328:	aa1403e0 	mov	x0, x20
    732c:	d2800022 	mov	x2, #0x1                   	// #1
    7330:	39001fe3 	strb	w3, [sp, #7]
    7334:	97fff0b7 	bl	3610 <buf_put>
    7338:	f9413bf5 	ldr	x21, [sp, #624]
    733c:	f9413ff6 	ldr	x22, [sp, #632]
    7340:	f94143f7 	ldr	x23, [sp, #640]
    7344:	f94147f8 	ldr	x24, [sp, #648]
    7348:	f94153fb 	ldr	x27, [sp, #672]
    734c:	f94157fc 	ldr	x28, [sp, #680]
    7350:	17ffff5d 	b	70c4 <fwp_write+0xb0>
    7354:	b9404855 	ldr	w21, [x2, #72]
    7358:	aa1403e0 	mov	x0, x20
    735c:	93407eb6 	sxtw	x22, w21
    7360:	91000ac1 	add	x1, x22, #0x2
    7364:	97fff078 	bl	3544 <buf_grow>
    7368:	a9400281 	ldp	x1, x0, [x20]
    736c:	528e8603 	mov	w3, #0x7430                	// #29744
    7370:	78206823 	strh	w3, [x1, x0]
    7374:	8b000022 	add	x2, x1, x0
    7378:	710002bf 	cmp	w21, #0x0
    737c:	540036ad 	b.le	7a50 <fwp_write+0xa3c>
    7380:	110006a3 	add	w3, w21, #0x1
    7384:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7388:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    738c:	91000449 	add	x9, x2, #0x1
    7390:	8b23c043 	add	x3, x2, w3, sxtw
    7394:	f28aaac6 	movk	x6, #0x5556
    7398:	f2955568 	movk	x8, #0xaaab
    739c:	1400000d 	b	73d0 <fwp_write+0x3bc>
    73a0:	d2800021 	mov	x1, #0x1                   	// #1
    73a4:	528005a5 	mov	w5, #0x2d                  	// #45
    73a8:	f100001f 	cmp	x0, #0x0
    73ac:	9b467e60 	smulh	x0, x19, x6
    73b0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    73b4:	381ff465 	strb	w5, [x3], #-1
    73b8:	cb040000 	sub	x0, x0, x4
    73bc:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    73c0:	cb020000 	sub	x0, x0, x2
    73c4:	8b010013 	add	x19, x0, x1
    73c8:	eb03013f 	cmp	x9, x3
    73cc:	54003420 	b.eq	7a50 <fwp_write+0xa3c>  // b.none
    73d0:	9b467e60 	smulh	x0, x19, x6
    73d4:	937ffe64 	asr	x4, x19, #63
    73d8:	52800605 	mov	w5, #0x30                  	// #48
    73dc:	cb040000 	sub	x0, x0, x4
    73e0:	8b000400 	add	x0, x0, x0, lsl #1
    73e4:	cb000260 	sub	x0, x19, x0
    73e8:	91000c01 	add	x1, x0, #0x3
    73ec:	9bc87c22 	umulh	x2, x1, x8
    73f0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    73f4:	8b4204e2 	add	x2, x7, x2, lsr #1
    73f8:	eb020021 	subs	x1, x1, x2
    73fc:	54fffd60 	b.eq	73a8 <fwp_write+0x394>  // b.none
    7400:	f100043f 	cmp	x1, #0x1
    7404:	54fffce1 	b.ne	73a0 <fwp_write+0x38c>  // b.any
    7408:	d2800001 	mov	x1, #0x0                   	// #0
    740c:	52800565 	mov	w5, #0x2b                  	// #43
    7410:	17ffffe6 	b	73a8 <fwp_write+0x394>
    7414:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7418:	f947f400 	ldr	x0, [x0, #4072]
    741c:	f94127e2 	ldr	x2, [sp, #584]
    7420:	f9400001 	ldr	x1, [x0]
    7424:	eb010042 	subs	x2, x2, x1
    7428:	d2800001 	mov	x1, #0x0                   	// #0
    742c:	540023a1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    7430:	f9413bf5 	ldr	x21, [sp, #624]
    7434:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7438:	f9413ff6 	ldr	x22, [sp, #632]
    743c:	aa1403e0 	mov	x0, x20
    7440:	913d4021 	add	x1, x1, #0xf50
    7444:	d2800102 	mov	x2, #0x8                   	// #8
    7448:	17ffff77 	b	7224 <fwp_write+0x210>
    744c:	aa1403e0 	mov	x0, x20
    7450:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7454:	d28000c2 	mov	x2, #0x6                   	// #6
    7458:	913ec021 	add	x1, x1, #0xfb0
    745c:	97fff06d 	bl	3610 <buf_put>
    7460:	d2800015 	mov	x21, #0x0                   	// #0
    7464:	f9400263 	ldr	x3, [x19]
    7468:	f240f87f 	tst	x3, #0x7fffffffffffffff
    746c:	54002c40 	b.eq	79f4 <fwp_write+0x9e0>  // b.none
    7470:	f9401f82 	ldr	x2, [x28, #56]
    7474:	f90143f7 	str	x23, [sp, #640]
    7478:	f90147f8 	str	x24, [sp, #648]
    747c:	d2800857 	mov	x23, #0x42                  	// #66
    7480:	f9014bf9 	str	x25, [sp, #656]
    7484:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x2000>
    7488:	f9014ffa 	str	x26, [sp, #664]
    748c:	913ea2d6 	add	x22, x22, #0xfa8
    7490:	d2800038 	mov	x24, #0x1                   	// #1
    7494:	f2a18017 	movk	x23, #0xc00, lsl #16
    7498:	d2809099 	mov	x25, #0x484                 	// #1156
    749c:	b4000482 	cbz	x2, 752c <fwp_write+0x518>
    74a0:	b9400040 	ldr	w0, [x2]
    74a4:	7100701f 	cmp	w0, #0x1c
    74a8:	540042a0 	b.eq	7cfc <fwp_write+0xce8>  // b.none
    74ac:	71006c1f 	cmp	w0, #0x1b
    74b0:	540003e8 	b.hi	752c <fwp_write+0x518>  // b.pmore
    74b4:	9ac02301 	lsl	x1, x24, x0
    74b8:	ea17003f 	tst	x1, x23
    74bc:	54003681 	b.ne	7b8c <fwp_write+0xb78>  // b.any
    74c0:	ea19003f 	tst	x1, x25
    74c4:	54003501 	b.ne	7b64 <fwp_write+0xb50>  // b.any
    74c8:	d2800424 	mov	x4, #0x21                  	// #33
    74cc:	ea04003f 	tst	x1, x4
    74d0:	540002e0 	b.eq	752c <fwp_write+0x518>  // b.none
    74d4:	b7f849a3 	tbnz	x3, #63, 7e08 <fwp_write+0xdf4>
    74d8:	91002261 	add	x1, x19, #0x8
    74dc:	8b150021 	add	x1, x1, x21
    74e0:	39400021 	ldrb	w1, [x1]
    74e4:	7100001f 	cmp	w0, #0x0
    74e8:	93401c23 	sxtb	x3, w1
    74ec:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    74f0:	aa1403e0 	mov	x0, x20
    74f4:	52800003 	mov	w3, #0x0                   	// #0
    74f8:	97fffec7 	bl	7014 <fwp_write>
    74fc:	910006b5 	add	x21, x21, #0x1
    7500:	f9400260 	ldr	x0, [x19]
    7504:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7508:	eb0002bf 	cmp	x21, x0
    750c:	540026c2 	b.cs	79e4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7510:	d2800042 	mov	x2, #0x2                   	// #2
    7514:	aa1603e1 	mov	x1, x22
    7518:	aa1403e0 	mov	x0, x20
    751c:	97fff03d 	bl	3610 <buf_put>
    7520:	f9401f82 	ldr	x2, [x28, #56]
    7524:	f9400263 	ldr	x3, [x19]
    7528:	b5fffbc2 	cbnz	x2, 74a0 <fwp_write+0x48c>
    752c:	d37df2a0 	lsl	x0, x21, #3
    7530:	b7f83f03 	tbnz	x3, #63, 7d10 <fwp_write+0xcfc>
    7534:	91002261 	add	x1, x19, #0x8
    7538:	8b000020 	add	x0, x1, x0
    753c:	f9400001 	ldr	x1, [x0]
    7540:	17ffffec 	b	74f0 <fwp_write+0x4dc>
    7544:	a9400e62 	ldp	x2, x3, [x19]
    7548:	b7f83ca3 	tbnz	x3, #63, 7cdc <fwp_write+0xcc8>
    754c:	910123f5 	add	x21, sp, #0x48
    7550:	aa1503e0 	mov	x0, x21
    7554:	97ffee53 	bl	2ea0 <fwp_fmt_u128>
    7558:	aa1503e0 	mov	x0, x21
    755c:	97ffec91 	bl	27a0 <strlen@plt>
    7560:	aa1503e1 	mov	x1, x21
    7564:	aa0003e2 	mov	x2, x0
    7568:	17fffed1 	b	70ac <fwp_write+0x98>
    756c:	fd015be8 	str	d8, [sp, #688]
    7570:	1e270268 	fmov	s8, w19
    7574:	fd015fe9 	str	d9, [sp, #696]
    7578:	1e282100 	fcmp	s8, s8
    757c:	54004d26 	b.vs	7f20 <fwp_write+0xf0c>
    7580:	1e20c101 	fabs	s1, s8
    7584:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7588:	1e270000 	fmov	s0, w0
    758c:	1e202020 	fcmp	s1, s0
    7590:	54002c0d 	b.le	7b10 <fwp_write+0xafc>
    7594:	1e202118 	fcmpe	s8, #0.0
    7598:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x2000>
    759c:	912ca042 	add	x2, x2, #0xb28
    75a0:	910123f5 	add	x21, sp, #0x48
    75a4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    75a8:	913c0021 	add	x1, x1, #0xf00
    75ac:	aa1503e0 	mov	x0, x21
    75b0:	9a81c041 	csel	x1, x2, x1, gt
    75b4:	97ffed27 	bl	2a50 <strcpy@plt>
    75b8:	aa1503e0 	mov	x0, x21
    75bc:	97ffec79 	bl	27a0 <strlen@plt>
    75c0:	aa1503e1 	mov	x1, x21
    75c4:	aa0003e2 	mov	x2, x0
    75c8:	aa1403e0 	mov	x0, x20
    75cc:	97fff011 	bl	3610 <buf_put>
    75d0:	f9413bf5 	ldr	x21, [sp, #624]
    75d4:	f9413ff6 	ldr	x22, [sp, #632]
    75d8:	f94153fb 	ldr	x27, [sp, #672]
    75dc:	f94157fc 	ldr	x28, [sp, #680]
    75e0:	fd415be8 	ldr	d8, [sp, #688]
    75e4:	fd415fe9 	ldr	d9, [sp, #696]
    75e8:	17fffeb7 	b	70c4 <fwp_write+0xb0>
    75ec:	f9400276 	ldr	x22, [x19]
    75f0:	34002e03 	cbz	w3, 7bb0 <fwp_write+0xb9c>
    75f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    75f8:	f947f400 	ldr	x0, [x0, #4072]
    75fc:	f94127e2 	ldr	x2, [sp, #584]
    7600:	f9400001 	ldr	x1, [x0]
    7604:	eb010042 	subs	x2, x2, x1
    7608:	d2800001 	mov	x1, #0x0                   	// #0
    760c:	540014a1 	b.ne	78a0 <fwp_write+0x88c>  // b.any
    7610:	aa1603e2 	mov	x2, x22
    7614:	91002261 	add	x1, x19, #0x8
    7618:	f9413bf5 	ldr	x21, [sp, #624]
    761c:	aa1403e0 	mov	x0, x20
    7620:	f9413ff6 	ldr	x22, [sp, #632]
    7624:	17ffff00 	b	7224 <fwp_write+0x210>
    7628:	fd015be8 	str	d8, [sp, #688]
    762c:	9e670268 	fmov	d8, x19
    7630:	fd015fe9 	str	d9, [sp, #696]
    7634:	1e682100 	fcmp	d8, d8
    7638:	54004746 	b.vs	7f20 <fwp_write+0xf0c>
    763c:	1e60c101 	fabs	d1, d8
    7640:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7644:	9e670000 	fmov	d0, x0
    7648:	910123f5 	add	x21, sp, #0x48
    764c:	52800033 	mov	w19, #0x1                   	// #1
    7650:	1e602020 	fcmp	d1, d0
    7654:	540001ad 	b.le	7688 <fwp_write+0x674>
    7658:	1e602118 	fcmpe	d8, #0.0
    765c:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x2000>
    7660:	912ca042 	add	x2, x2, #0xb28
    7664:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7668:	913c0021 	add	x1, x1, #0xf00
    766c:	aa1503e0 	mov	x0, x21
    7670:	9a81c041 	csel	x1, x2, x1, gt
    7674:	97ffecf7 	bl	2a50 <strcpy@plt>
    7678:	17ffffd0 	b	75b8 <fwp_write+0x5a4>
    767c:	11000673 	add	w19, w19, #0x1
    7680:	71004a7f 	cmp	w19, #0x12
    7684:	54003860 	b.eq	7d90 <fwp_write+0xd7c>  // b.none
    7688:	1e604100 	fmov	d0, d8
    768c:	2a1303e1 	mov	w1, w19
    7690:	aa1503e0 	mov	x0, x21
    7694:	97fff160 	bl	3c14 <fwp_format_g.constprop.0>
    7698:	aa1503e0 	mov	x0, x21
    769c:	d2800001 	mov	x1, #0x0                   	// #0
    76a0:	97ffec54 	bl	27f0 <strtod@plt>
    76a4:	1e602100 	fcmp	d8, d0
    76a8:	54fffea1 	b.ne	767c <fwp_write+0x668>  // b.any
    76ac:	aa1503e0 	mov	x0, x21
    76b0:	97fff051 	bl	37f4 <fwp_finish_float>
    76b4:	17ffffc1 	b	75b8 <fwp_write+0x5a4>
    76b8:	a9400e62 	ldp	x2, x3, [x19]
    76bc:	910123f3 	add	x19, sp, #0x48
    76c0:	aa1303e0 	mov	x0, x19
    76c4:	97ffedf7 	bl	2ea0 <fwp_fmt_u128>
    76c8:	17fffe75 	b	709c <fwp_write+0x88>
    76cc:	f90143f7 	str	x23, [sp, #640]
    76d0:	f90147f8 	str	x24, [sp, #648]
    76d4:	2a1303f8 	mov	w24, w19
    76d8:	f9014bf9 	str	x25, [sp, #656]
    76dc:	f9014ffa 	str	x26, [sp, #664]
    76e0:	f13ffe7f 	cmp	x19, #0xfff
    76e4:	54000049 	b.ls	76ec <fwp_write+0x6d8>  // b.plast
    76e8:	b9400278 	ldr	w24, [x19]
    76ec:	f9400f80 	ldr	x0, [x28, #24]
    76f0:	2a1803f5 	mov	w21, w24
    76f4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    76f8:	d37ef6b9 	lsl	x25, x21, #2
    76fc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7700:	aa1603e0 	mov	x0, x22
    7704:	97ffec27 	bl	27a0 <strlen@plt>
    7708:	aa1603e1 	mov	x1, x22
    770c:	aa0003e2 	mov	x2, x0
    7710:	aa1403e0 	mov	x0, x20
    7714:	97ffefbf 	bl	3610 <buf_put>
    7718:	f9401780 	ldr	x0, [x28, #40]
    771c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7720:	7100001f 	cmp	w0, #0x0
    7724:	5400068d 	b.le	77f4 <fwp_write+0x7e0>
    7728:	91002276 	add	x22, x19, #0x8
    772c:	91001ff5 	add	x21, sp, #0x7
    7730:	d280001b 	mov	x27, #0x0                   	// #0
    7734:	5280041a 	mov	w26, #0x20                  	// #32
    7738:	f9401b80 	ldr	x0, [x28, #48]
    773c:	aa1503e1 	mov	x1, x21
    7740:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7744:	d2800022 	mov	x2, #0x1                   	// #1
    7748:	f8786803 	ldr	x3, [x0, x24]
    774c:	aa1403e0 	mov	x0, x20
    7750:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7754:	39001ffa 	strb	w26, [sp, #7]
    7758:	97ffefae 	bl	3610 <buf_put>
    775c:	f13ffeff 	cmp	x23, #0xfff
    7760:	b9400261 	ldr	w1, [x19]
    7764:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7768:	7100383f 	cmp	w1, #0xe
    776c:	54000160 	b.eq	7798 <fwp_write+0x784>  // b.none
    7770:	7100403f 	cmp	w1, #0x10
    7774:	54001a60 	b.eq	7ac0 <fwp_write+0xaac>  // b.none
    7778:	7100283f 	cmp	w1, #0xa
    777c:	54002aa0 	b.eq	7cd0 <fwp_write+0xcbc>  // b.none
    7780:	540014ac 	b.gt	7a14 <fwp_write+0xa00>
    7784:	71000c3f 	cmp	w1, #0x3
    7788:	540029ac 	b.gt	7cbc <fwp_write+0xca8>
    778c:	d37ffee0 	lsr	x0, x23, #63
    7790:	37f814a1 	tbnz	w1, #31, 7a24 <fwp_write+0xa10>
    7794:	d503201f 	nop
    7798:	34001460 	cbz	w0, 7a24 <fwp_write+0xa10>
    779c:	52800503 	mov	w3, #0x28                  	// #40
    77a0:	aa1503e1 	mov	x1, x21
    77a4:	aa1403e0 	mov	x0, x20
    77a8:	d2800022 	mov	x2, #0x1                   	// #1
    77ac:	39001fe3 	strb	w3, [sp, #7]
    77b0:	97ffef98 	bl	3610 <buf_put>
    77b4:	aa1303e2 	mov	x2, x19
    77b8:	aa1703e1 	mov	x1, x23
    77bc:	aa1403e0 	mov	x0, x20
    77c0:	52800003 	mov	w3, #0x0                   	// #0
    77c4:	97fffe14 	bl	7014 <fwp_write>
    77c8:	52800523 	mov	w3, #0x29                  	// #41
    77cc:	aa1503e1 	mov	x1, x21
    77d0:	aa1403e0 	mov	x0, x20
    77d4:	d2800022 	mov	x2, #0x1                   	// #1
    77d8:	39001fe3 	strb	w3, [sp, #7]
    77dc:	97ffef8d 	bl	3610 <buf_put>
    77e0:	f9401780 	ldr	x0, [x28, #40]
    77e4:	9100077b 	add	x27, x27, #0x1
    77e8:	b8796800 	ldr	w0, [x0, x25]
    77ec:	6b1b001f 	cmp	w0, w27
    77f0:	54fffa4c 	b.gt	7738 <fwp_write+0x724>
    77f4:	f9413bf5 	ldr	x21, [sp, #624]
    77f8:	f9413ff6 	ldr	x22, [sp, #632]
    77fc:	f94143f7 	ldr	x23, [sp, #640]
    7800:	f94147f8 	ldr	x24, [sp, #648]
    7804:	f9414bf9 	ldr	x25, [sp, #656]
    7808:	f9414ffa 	ldr	x26, [sp, #664]
    780c:	f94153fb 	ldr	x27, [sp, #672]
    7810:	f94157fc 	ldr	x28, [sp, #680]
    7814:	17fffe2c 	b	70c4 <fwp_write+0xb0>
    7818:	52800783 	mov	w3, #0x3c                  	// #60
    781c:	91001ff3 	add	x19, sp, #0x7
    7820:	aa1303e1 	mov	x1, x19
    7824:	d2800022 	mov	x2, #0x1                   	// #1
    7828:	aa1403e0 	mov	x0, x20
    782c:	39001fe3 	strb	w3, [sp, #7]
    7830:	97ffef78 	bl	3610 <buf_put>
    7834:	f9400795 	ldr	x21, [x28, #8]
    7838:	aa1503e0 	mov	x0, x21
    783c:	97ffebd9 	bl	27a0 <strlen@plt>
    7840:	aa1503e1 	mov	x1, x21
    7844:	aa0003e2 	mov	x2, x0
    7848:	aa1403e0 	mov	x0, x20
    784c:	97ffef71 	bl	3610 <buf_put>
    7850:	528007c3 	mov	w3, #0x3e                  	// #62
    7854:	aa1303e1 	mov	x1, x19
    7858:	aa1403e0 	mov	x0, x20
    785c:	d2800022 	mov	x2, #0x1                   	// #1
    7860:	39001fe3 	strb	w3, [sp, #7]
    7864:	17fffe13 	b	70b0 <fwp_write+0x9c>
    7868:	f100067f 	cmp	x19, #0x1
    786c:	540025a0 	b.eq	7d20 <fwp_write+0xd0c>  // b.none
    7870:	b100067f 	cmn	x19, #0x1
    7874:	54002bc0 	b.eq	7dec <fwp_write+0xdd8>  // b.none
    7878:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    787c:	913c2021 	add	x1, x1, #0xf08
    7880:	d2800022 	mov	x2, #0x1                   	// #1
    7884:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7888:	f947f400 	ldr	x0, [x0, #4072]
    788c:	f94127e4 	ldr	x4, [sp, #584]
    7890:	f9400003 	ldr	x3, [x0]
    7894:	eb030084 	subs	x4, x4, x3
    7898:	d2800003 	mov	x3, #0x0                   	// #0
    789c:	54ffebe0 	b.eq	7618 <fwp_write+0x604>  // b.none
    78a0:	f90143f7 	str	x23, [sp, #640]
    78a4:	f90147f8 	str	x24, [sp, #648]
    78a8:	f9014bf9 	str	x25, [sp, #656]
    78ac:	f9014ffa 	str	x26, [sp, #664]
    78b0:	fd015be8 	str	d8, [sp, #688]
    78b4:	fd015fe9 	str	d9, [sp, #696]
    78b8:	97ffec16 	bl	2910 <__stack_chk_fail@plt>
    78bc:	52800b63 	mov	w3, #0x5b                  	// #91
    78c0:	91001ff5 	add	x21, sp, #0x7
    78c4:	aa1503e1 	mov	x1, x21
    78c8:	aa1403e0 	mov	x0, x20
    78cc:	d2800022 	mov	x2, #0x1                   	// #1
    78d0:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x2000>
    78d4:	913ea2d6 	add	x22, x22, #0xfa8
    78d8:	39001fe3 	strb	w3, [sp, #7]
    78dc:	97ffef4d 	bl	3610 <buf_put>
    78e0:	b4000273 	cbz	x19, 792c <fwp_write+0x918>
    78e4:	f9400661 	ldr	x1, [x19, #8]
    78e8:	aa1403e0 	mov	x0, x20
    78ec:	f9401f82 	ldr	x2, [x28, #56]
    78f0:	52800003 	mov	w3, #0x0                   	// #0
    78f4:	97fffdc8 	bl	7014 <fwp_write>
    78f8:	f9400a73 	ldr	x19, [x19, #16]
    78fc:	b4000193 	cbz	x19, 792c <fwp_write+0x918>
    7900:	aa1603e1 	mov	x1, x22
    7904:	aa1403e0 	mov	x0, x20
    7908:	d2800042 	mov	x2, #0x2                   	// #2
    790c:	97ffef41 	bl	3610 <buf_put>
    7910:	f9400661 	ldr	x1, [x19, #8]
    7914:	aa1403e0 	mov	x0, x20
    7918:	f9401f82 	ldr	x2, [x28, #56]
    791c:	52800003 	mov	w3, #0x0                   	// #0
    7920:	97fffdbd 	bl	7014 <fwp_write>
    7924:	f9400a73 	ldr	x19, [x19, #16]
    7928:	b5fffed3 	cbnz	x19, 7900 <fwp_write+0x8ec>
    792c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7930:	aa1503e1 	mov	x1, x21
    7934:	aa1403e0 	mov	x0, x20
    7938:	d2800022 	mov	x2, #0x1                   	// #1
    793c:	39001fe3 	strb	w3, [sp, #7]
    7940:	17fffddc 	b	70b0 <fwp_write+0x9c>
    7944:	aa1403e0 	mov	x0, x20
    7948:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    794c:	d28000c2 	mov	x2, #0x6                   	// #6
    7950:	913e6021 	add	x1, x1, #0xf98
    7954:	97ffef2f 	bl	3610 <buf_put>
    7958:	f9400260 	ldr	x0, [x19]
    795c:	b40004c0 	cbz	x0, 79f4 <fwp_write+0x9e0>
    7960:	910123f5 	add	x21, sp, #0x48
    7964:	91002276 	add	x22, x19, #0x8
    7968:	f90143f7 	str	x23, [sp, #640]
    796c:	d2800017 	mov	x23, #0x0                   	// #0
    7970:	f90147f8 	str	x24, [sp, #648]
    7974:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x2000>
    7978:	913e8318 	add	x24, x24, #0xfa0
    797c:	f9014bf9 	str	x25, [sp, #656]
    7980:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2000>
    7984:	913ea339 	add	x25, x25, #0xfa8
    7988:	f9014ffa 	str	x26, [sp, #664]
    798c:	14000005 	b	79a0 <fwp_write+0x98c>
    7990:	aa1903e1 	mov	x1, x25
    7994:	aa1403e0 	mov	x0, x20
    7998:	d2800042 	mov	x2, #0x2                   	// #2
    799c:	97ffef1d 	bl	3610 <buf_put>
    79a0:	38776ac5 	ldrb	w5, [x22, x23]
    79a4:	d2804003 	mov	x3, #0x200                 	// #512
    79a8:	aa1803e4 	mov	x4, x24
    79ac:	aa0303e1 	mov	x1, x3
    79b0:	52800042 	mov	w2, #0x2                   	// #2
    79b4:	aa1503e0 	mov	x0, x21
    79b8:	910006f7 	add	x23, x23, #0x1
    79bc:	97ffebb1 	bl	2880 <__snprintf_chk@plt>
    79c0:	aa1503e0 	mov	x0, x21
    79c4:	97ffeb77 	bl	27a0 <strlen@plt>
    79c8:	aa1503e1 	mov	x1, x21
    79cc:	aa0003e2 	mov	x2, x0
    79d0:	aa1403e0 	mov	x0, x20
    79d4:	97ffef0f 	bl	3610 <buf_put>
    79d8:	f9400260 	ldr	x0, [x19]
    79dc:	eb17001f 	cmp	x0, x23
    79e0:	54fffd88 	b.hi	7990 <fwp_write+0x97c>  // b.pmore
    79e4:	f94143f7 	ldr	x23, [sp, #640]
    79e8:	f94147f8 	ldr	x24, [sp, #648]
    79ec:	f9414bf9 	ldr	x25, [sp, #656]
    79f0:	f9414ffa 	ldr	x26, [sp, #664]
    79f4:	52800ba3 	mov	w3, #0x5d                  	// #93
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	91001fe1 	add	x1, sp, #0x7
    7a00:	d2800022 	mov	x2, #0x1                   	// #1
    7a04:	39001fe3 	strb	w3, [sp, #7]
    7a08:	17fffdaa 	b	70b0 <fwp_write+0x9c>
    7a0c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a10:	17fffe45 	b	7324 <fwp_write+0x310>
    7a14:	f10002ff 	cmp	x23, #0x0
    7a18:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7a1c:	71002c3f 	cmp	w1, #0xb
    7a20:	54ffebc0 	b.eq	7798 <fwp_write+0x784>  // b.none
    7a24:	aa1303e2 	mov	x2, x19
    7a28:	aa1703e1 	mov	x1, x23
    7a2c:	aa1403e0 	mov	x0, x20
    7a30:	52800003 	mov	w3, #0x0                   	// #0
    7a34:	97fffd78 	bl	7014 <fwp_write>
    7a38:	17ffff6a 	b	77e0 <fwp_write+0x7cc>
    7a3c:	aa1403e0 	mov	x0, x20
    7a40:	91001fe1 	add	x1, sp, #0x7
    7a44:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a48:	d2800022 	mov	x2, #0x1                   	// #1
    7a4c:	17fffe39 	b	7330 <fwp_write+0x31c>
    7a50:	a9400281 	ldp	x1, x0, [x20]
    7a54:	91000800 	add	x0, x0, #0x2
    7a58:	8b160000 	add	x0, x0, x22
    7a5c:	f9000680 	str	x0, [x20, #8]
    7a60:	3820683f 	strb	wzr, [x1, x0]
    7a64:	f9413bf5 	ldr	x21, [sp, #624]
    7a68:	f9413ff6 	ldr	x22, [sp, #632]
    7a6c:	f94153fb 	ldr	x27, [sp, #672]
    7a70:	f94157fc 	ldr	x28, [sp, #680]
    7a74:	17fffd94 	b	70c4 <fwp_write+0xb0>
    7a78:	f9400f80 	ldr	x0, [x28, #24]
    7a7c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7a80:	aa1b03e0 	mov	x0, x27
    7a84:	97ffeb47 	bl	27a0 <strlen@plt>
    7a88:	aa1b03e1 	mov	x1, x27
    7a8c:	aa0003e2 	mov	x2, x0
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	97ffeedf 	bl	3610 <buf_put>
    7a98:	aa1903e1 	mov	x1, x25
    7a9c:	aa1403e0 	mov	x0, x20
    7aa0:	d2800062 	mov	x2, #0x3                   	// #3
    7aa4:	97ffeedb 	bl	3610 <buf_put>
    7aa8:	17fffe11 	b	72ec <fwp_write+0x2d8>
    7aac:	aa1a03e1 	mov	x1, x26
    7ab0:	aa1403e0 	mov	x0, x20
    7ab4:	d2800042 	mov	x2, #0x2                   	// #2
    7ab8:	97ffeed6 	bl	3610 <buf_put>
    7abc:	17fffe0a 	b	72e4 <fwp_write+0x2d0>
    7ac0:	f9400660 	ldr	x0, [x19, #8]
    7ac4:	b4fffb00 	cbz	x0, 7a24 <fwp_write+0xa10>
    7ac8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7acc:	913f0021 	add	x1, x1, #0xfc0
    7ad0:	97ffebb0 	bl	2990 <strcmp@plt>
    7ad4:	7100001f 	cmp	w0, #0x0
    7ad8:	1a9f07e0 	cset	w0, ne	// ne = any
    7adc:	17ffff2f 	b	7798 <fwp_write+0x784>
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	d2800042 	mov	x2, #0x2                   	// #2
    7ae8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7aec:	913ee021 	add	x1, x1, #0xfb8
    7af0:	97ffeec8 	bl	3610 <buf_put>
    7af4:	91004261 	add	x1, x19, #0x10
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	f9402382 	ldr	x2, [x28, #64]
    7b00:	52800003 	mov	w3, #0x0                   	// #0
    7b04:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7b08:	97fffd43 	bl	7014 <fwp_write>
    7b0c:	17fffd9d 	b	7180 <fwp_write+0x16c>
    7b10:	1e22c109 	fcvt	d9, s8
    7b14:	910123f5 	add	x21, sp, #0x48
    7b18:	52800033 	mov	w19, #0x1                   	// #1
    7b1c:	d503201f 	nop
    7b20:	1e604120 	fmov	d0, d9
    7b24:	2a1303e1 	mov	w1, w19
    7b28:	aa1503e0 	mov	x0, x21
    7b2c:	97fff03a 	bl	3c14 <fwp_format_g.constprop.0>
    7b30:	aa1503e0 	mov	x0, x21
    7b34:	d2800001 	mov	x1, #0x0                   	// #0
    7b38:	97ffeba2 	bl	29c0 <strtof@plt>
    7b3c:	1e202100 	fcmp	s8, s0
    7b40:	54ffdb60 	b.eq	76ac <fwp_write+0x698>  // b.none
    7b44:	11000673 	add	w19, w19, #0x1
    7b48:	71002a7f 	cmp	w19, #0xa
    7b4c:	54fffea1 	b.ne	7b20 <fwp_write+0xb0c>  // b.any
    7b50:	1e604120 	fmov	d0, d9
    7b54:	aa1503e0 	mov	x0, x21
    7b58:	52800121 	mov	w1, #0x9                   	// #9
    7b5c:	97fff02e 	bl	3c14 <fwp_format_g.constprop.0>
    7b60:	17fffed3 	b	76ac <fwp_write+0x698>
    7b64:	d37ef6a1 	lsl	x1, x21, #2
    7b68:	b7f81563 	tbnz	x3, #63, 7e14 <fwp_write+0xe00>
    7b6c:	91002263 	add	x3, x19, #0x8
    7b70:	8b010061 	add	x1, x3, x1
    7b74:	b9400023 	ldr	w3, [x1]
    7b78:	7100081f 	cmp	w0, #0x2
    7b7c:	2a0303e1 	mov	w1, w3
    7b80:	93407c63 	sxtw	x3, w3
    7b84:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7b88:	17fffe5a 	b	74f0 <fwp_write+0x4dc>
    7b8c:	d37ffaa1 	lsl	x1, x21, #1
    7b90:	b7f81363 	tbnz	x3, #63, 7dfc <fwp_write+0xde8>
    7b94:	91002263 	add	x3, x19, #0x8
    7b98:	8b010061 	add	x1, x3, x1
    7b9c:	79400021 	ldrh	w1, [x1]
    7ba0:	7100041f 	cmp	w0, #0x1
    7ba4:	93403c23 	sxth	x3, w1
    7ba8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7bac:	17fffe51 	b	74f0 <fwp_write+0x4dc>
    7bb0:	52800443 	mov	w3, #0x22                  	// #34
    7bb4:	91001ff5 	add	x21, sp, #0x7
    7bb8:	91002273 	add	x19, x19, #0x8
    7bbc:	aa1503e1 	mov	x1, x21
    7bc0:	aa1403e0 	mov	x0, x20
    7bc4:	d2800022 	mov	x2, #0x1                   	// #1
    7bc8:	39001fe3 	strb	w3, [sp, #7]
    7bcc:	f90143f7 	str	x23, [sp, #640]
    7bd0:	8b160277 	add	x23, x19, x22
    7bd4:	f90147f8 	str	x24, [sp, #648]
    7bd8:	97ffee8e 	bl	3610 <buf_put>
    7bdc:	b4000696 	cbz	x22, 7cac <fwp_write+0xc98>
    7be0:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x2000>
    7be4:	913da318 	add	x24, x24, #0xf68
    7be8:	f9014bf9 	str	x25, [sp, #656]
    7bec:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2000>
    7bf0:	913e2339 	add	x25, x25, #0xf88
    7bf4:	f9014ffa 	str	x26, [sp, #664]
    7bf8:	1400000d 	b	7c2c <fwp_write+0xc18>
    7bfc:	710024bf 	cmp	w5, #0x9
    7c00:	54000460 	b.eq	7c8c <fwp_write+0xc78>  // b.none
    7c04:	710028bf 	cmp	w5, #0xa
    7c08:	54000a61 	b.ne	7d54 <fwp_write+0xd40>  // b.any
    7c0c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7c10:	aa1403e0 	mov	x0, x20
    7c14:	913de021 	add	x1, x1, #0xf78
    7c18:	d2800042 	mov	x2, #0x2                   	// #2
    7c1c:	97ffee7d 	bl	3610 <buf_put>
    7c20:	91000673 	add	x19, x19, #0x1
    7c24:	eb17027f 	cmp	x19, x23
    7c28:	540003e0 	b.eq	7ca4 <fwp_write+0xc90>  // b.none
    7c2c:	39400265 	ldrb	w5, [x19]
    7c30:	710034bf 	cmp	w5, #0xd
    7c34:	54000180 	b.eq	7c64 <fwp_write+0xc50>  // b.none
    7c38:	54fffe29 	b.ls	7bfc <fwp_write+0xbe8>  // b.plast
    7c3c:	710088bf 	cmp	w5, #0x22
    7c40:	540001c0 	b.eq	7c78 <fwp_write+0xc64>  // b.none
    7c44:	710170bf 	cmp	w5, #0x5c
    7c48:	54000741 	b.ne	7d30 <fwp_write+0xd1c>  // b.any
    7c4c:	aa1403e0 	mov	x0, x20
    7c50:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7c54:	d2800042 	mov	x2, #0x2                   	// #2
    7c58:	913dc021 	add	x1, x1, #0xf70
    7c5c:	97ffee6d 	bl	3610 <buf_put>
    7c60:	17fffff0 	b	7c20 <fwp_write+0xc0c>
    7c64:	aa1903e1 	mov	x1, x25
    7c68:	aa1403e0 	mov	x0, x20
    7c6c:	d2800042 	mov	x2, #0x2                   	// #2
    7c70:	97ffee68 	bl	3610 <buf_put>
    7c74:	17ffffeb 	b	7c20 <fwp_write+0xc0c>
    7c78:	aa1803e1 	mov	x1, x24
    7c7c:	aa1403e0 	mov	x0, x20
    7c80:	d2800042 	mov	x2, #0x2                   	// #2
    7c84:	97ffee63 	bl	3610 <buf_put>
    7c88:	17ffffe6 	b	7c20 <fwp_write+0xc0c>
    7c8c:	aa1403e0 	mov	x0, x20
    7c90:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7c94:	d2800042 	mov	x2, #0x2                   	// #2
    7c98:	913e0021 	add	x1, x1, #0xf80
    7c9c:	97ffee5d 	bl	3610 <buf_put>
    7ca0:	17ffffe0 	b	7c20 <fwp_write+0xc0c>
    7ca4:	f9414bf9 	ldr	x25, [sp, #656]
    7ca8:	f9414ffa 	ldr	x26, [sp, #664]
    7cac:	aa1503e1 	mov	x1, x21
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	52800443 	mov	w3, #0x22                  	// #34
    7cb8:	17fffd9d 	b	732c <fwp_write+0x318>
    7cbc:	7100103f 	cmp	w1, #0x4
    7cc0:	54ffeb21 	b.ne	7a24 <fwp_write+0xa10>  // b.any
    7cc4:	f94006e0 	ldr	x0, [x23, #8]
    7cc8:	d37ffc00 	lsr	x0, x0, #63
    7ccc:	17fffeb3 	b	7798 <fwp_write+0x784>
    7cd0:	710002ff 	cmp	w23, #0x0
    7cd4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7cd8:	17fffeb0 	b	7798 <fwp_write+0x784>
    7cdc:	528005a1 	mov	w1, #0x2d                  	// #45
    7ce0:	eb0203e2 	negs	x2, x2
    7ce4:	da0303e3 	ngc	x3, x3
    7ce8:	910127e0 	add	x0, sp, #0x49
    7cec:	910123f5 	add	x21, sp, #0x48
    7cf0:	390123e1 	strb	w1, [sp, #72]
    7cf4:	97ffec6b 	bl	2ea0 <fwp_fmt_u128>
    7cf8:	17fffe18 	b	7558 <fwp_write+0x544>
    7cfc:	d37ceea1 	lsl	x1, x21, #4
    7d00:	b7f810a3 	tbnz	x3, #63, 7f14 <fwp_write+0xf00>
    7d04:	91002260 	add	x0, x19, #0x8
    7d08:	8b010001 	add	x1, x0, x1
    7d0c:	17fffdf9 	b	74f0 <fwp_write+0x4dc>
    7d10:	f9400a61 	ldr	x1, [x19, #16]
    7d14:	8b010000 	add	x0, x0, x1
    7d18:	f9400001 	ldr	x1, [x0]
    7d1c:	17fffdf5 	b	74f0 <fwp_write+0x4dc>
    7d20:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7d24:	d2800042 	mov	x2, #0x2                   	// #2
    7d28:	913c4021 	add	x1, x1, #0xf10
    7d2c:	17fffed6 	b	7884 <fwp_write+0x870>
    7d30:	7101fcbf 	cmp	w5, #0x7f
    7d34:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7d38:	540000e9 	b.ls	7d54 <fwp_write+0xd40>  // b.plast
    7d3c:	aa1503e1 	mov	x1, x21
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	d2800022 	mov	x2, #0x1                   	// #1
    7d48:	39001fe5 	strb	w5, [sp, #7]
    7d4c:	97ffee31 	bl	3610 <buf_put>
    7d50:	17ffffb4 	b	7c20 <fwp_write+0xc0c>
    7d54:	d2800203 	mov	x3, #0x10                  	// #16
    7d58:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x2000>
    7d5c:	aa0303e1 	mov	x1, x3
    7d60:	913e4084 	add	x4, x4, #0xf90
    7d64:	910123f6 	add	x22, sp, #0x48
    7d68:	52800042 	mov	w2, #0x2                   	// #2
    7d6c:	aa1603e0 	mov	x0, x22
    7d70:	97ffeac4 	bl	2880 <__snprintf_chk@plt>
    7d74:	aa1603e0 	mov	x0, x22
    7d78:	97ffea8a 	bl	27a0 <strlen@plt>
    7d7c:	aa1603e1 	mov	x1, x22
    7d80:	aa0003e2 	mov	x2, x0
    7d84:	aa1403e0 	mov	x0, x20
    7d88:	97ffee22 	bl	3610 <buf_put>
    7d8c:	17ffffa5 	b	7c20 <fwp_write+0xc0c>
    7d90:	1e604100 	fmov	d0, d8
    7d94:	aa1503e0 	mov	x0, x21
    7d98:	52800221 	mov	w1, #0x11                  	// #17
    7d9c:	97ffef9e 	bl	3c14 <fwp_format_g.constprop.0>
    7da0:	17fffe43 	b	76ac <fwp_write+0x698>
    7da4:	b9401040 	ldr	w0, [x2, #16]
    7da8:	350003c0 	cbnz	w0, 7e20 <fwp_write+0xe0c>
    7dac:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7db0:	f947f400 	ldr	x0, [x0, #4072]
    7db4:	f94127e2 	ldr	x2, [sp, #584]
    7db8:	f9400001 	ldr	x1, [x0]
    7dbc:	eb010042 	subs	x2, x2, x1
    7dc0:	d2800001 	mov	x1, #0x0                   	// #0
    7dc4:	54ffd721 	b.ne	78a8 <fwp_write+0x894>  // b.any
    7dc8:	f9413bf5 	ldr	x21, [sp, #624]
    7dcc:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7dd0:	f9413ff6 	ldr	x22, [sp, #632]
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	f94143f7 	ldr	x23, [sp, #640]
    7ddc:	913f8021 	add	x1, x1, #0xfe0
    7de0:	f94147f8 	ldr	x24, [sp, #648]
    7de4:	d2800042 	mov	x2, #0x2                   	// #2
    7de8:	17fffd0f 	b	7224 <fwp_write+0x210>
    7dec:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2000>
    7df0:	d2800042 	mov	x2, #0x2                   	// #2
    7df4:	913c6021 	add	x1, x1, #0xf18
    7df8:	17fffea3 	b	7884 <fwp_write+0x870>
    7dfc:	f9400a63 	ldr	x3, [x19, #16]
    7e00:	8b030021 	add	x1, x1, x3
    7e04:	17ffff66 	b	7b9c <fwp_write+0xb88>
    7e08:	f9400a61 	ldr	x1, [x19, #16]
    7e0c:	8b0102a1 	add	x1, x21, x1
    7e10:	17fffdb4 	b	74e0 <fwp_write+0x4cc>
    7e14:	f9400a63 	ldr	x3, [x19, #16]
    7e18:	8b030021 	add	x1, x1, x3
    7e1c:	17ffff56 	b	7b74 <fwp_write+0xb60>
    7e20:	b9404840 	ldr	w0, [x2, #72]
    7e24:	91001ff5 	add	x21, sp, #0x7
    7e28:	34ffa380 	cbz	w0, 7298 <fwp_write+0x284>
    7e2c:	52800503 	mov	w3, #0x28                  	// #40
    7e30:	aa1403e0 	mov	x0, x20
    7e34:	aa1503e1 	mov	x1, x21
    7e38:	d2800022 	mov	x2, #0x1                   	// #1
    7e3c:	39001fe3 	strb	w3, [sp, #7]
    7e40:	97ffedf4 	bl	3610 <buf_put>
    7e44:	b9401380 	ldr	w0, [x28, #16]
    7e48:	52800038 	mov	w24, #0x1                   	// #1
    7e4c:	7100001f 	cmp	w0, #0x0
    7e50:	54ffa38c 	b.gt	72c0 <fwp_write+0x2ac>
    7e54:	17fffd33 	b	7320 <fwp_write+0x30c>
    7e58:	f9014bf9 	str	x25, [sp, #656]
    7e5c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11480>
    7e60:	f9014ffa 	str	x26, [sp, #664]
    7e64:	f9400676 	ldr	x22, [x19, #8]
    7e68:	910aa333 	add	x19, x25, #0x2a8
    7e6c:	91002273 	add	x19, x19, #0x8
    7e70:	937ffed8 	asr	x24, x22, #63
    7e74:	aa1802c0 	orr	x0, x22, x24
    7e78:	b5000320 	cbnz	x0, 7edc <fwp_write+0xec8>
    7e7c:	110006b5 	add	w21, w21, #0x1
    7e80:	710016bf 	cmp	w21, #0x5
    7e84:	54ffffc1 	b.ne	7e7c <fwp_write+0xe68>  // b.any
    7e88:	b7f80578 	tbnz	x24, #63, 7f34 <fwp_write+0xf20>
    7e8c:	910023f3 	add	x19, sp, #0x8
    7e90:	aa1603e2 	mov	x2, x22
    7e94:	aa1303e0 	mov	x0, x19
    7e98:	d2800003 	mov	x3, #0x0                   	// #0
    7e9c:	97ffec01 	bl	2ea0 <fwp_fmt_u128>
    7ea0:	910123f5 	add	x21, sp, #0x48
    7ea4:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x2000>
    7ea8:	aa1303e4 	mov	x4, x19
    7eac:	aa1503e0 	mov	x0, x21
    7eb0:	913f6063 	add	x3, x3, #0xfd8
    7eb4:	d2804002 	mov	x2, #0x200                 	// #512
    7eb8:	52800041 	mov	w1, #0x2                   	// #2
    7ebc:	97ffea3d 	bl	27b0 <__sprintf_chk@plt>
    7ec0:	aa1503e0 	mov	x0, x21
    7ec4:	97ffea37 	bl	27a0 <strlen@plt>
    7ec8:	aa1503e1 	mov	x1, x21
    7ecc:	aa0003e2 	mov	x2, x0
    7ed0:	aa1403e0 	mov	x0, x20
    7ed4:	97ffedcf 	bl	3610 <buf_put>
    7ed8:	17fffe47 	b	77f4 <fwp_write+0x7e0>
    7edc:	f9400277 	ldr	x23, [x19]
    7ee0:	aa1603e0 	mov	x0, x22
    7ee4:	aa1803e1 	mov	x1, x24
    7ee8:	aa1703e2 	mov	x2, x23
    7eec:	937ffefa 	asr	x26, x23, #63
    7ef0:	aa1a03e3 	mov	x3, x26
    7ef4:	940009ef 	bl	a6b0 <__modti3>
    7ef8:	aa010000 	orr	x0, x0, x1
    7efc:	b40002c0 	cbz	x0, 7f54 <fwp_write+0xf40>
    7f00:	110006b5 	add	w21, w21, #0x1
    7f04:	91004273 	add	x19, x19, #0x10
    7f08:	710016bf 	cmp	w21, #0x5
    7f0c:	54fffe81 	b.ne	7edc <fwp_write+0xec8>  // b.any
    7f10:	17ffffde 	b	7e88 <fwp_write+0xe74>
    7f14:	f9400a60 	ldr	x0, [x19, #16]
    7f18:	8b000021 	add	x1, x1, x0
    7f1c:	17fffd75 	b	74f0 <fwp_write+0x4dc>
    7f20:	528c29c0 	mov	w0, #0x614e                	// #24910
    7f24:	910123f5 	add	x21, sp, #0x48
    7f28:	72a009c0 	movk	w0, #0x4e, lsl #16
    7f2c:	b9004be0 	str	w0, [sp, #72]
    7f30:	17fffda2 	b	75b8 <fwp_write+0x5a4>
    7f34:	528005a1 	mov	w1, #0x2d                  	// #45
    7f38:	eb1603e2 	negs	x2, x22
    7f3c:	da1803e3 	ngc	x3, x24
    7f40:	910027e0 	add	x0, sp, #0x9
    7f44:	910023f3 	add	x19, sp, #0x8
    7f48:	390023e1 	strb	w1, [sp, #8]
    7f4c:	97ffebd5 	bl	2ea0 <fwp_fmt_u128>
    7f50:	17ffffd4 	b	7ea0 <fwp_write+0xe8c>
    7f54:	aa1703e2 	mov	x2, x23
    7f58:	aa1a03e3 	mov	x3, x26
    7f5c:	aa1603e0 	mov	x0, x22
    7f60:	aa1803e1 	mov	x1, x24
    7f64:	940008f3 	bl	a330 <__divti3>
    7f68:	aa0003e2 	mov	x2, x0
    7f6c:	aa0103e3 	mov	x3, x1
    7f70:	b7f80201 	tbnz	x1, #63, 7fb0 <fwp_write+0xf9c>
    7f74:	910023f3 	add	x19, sp, #0x8
    7f78:	aa1303e0 	mov	x0, x19
    7f7c:	97ffebc9 	bl	2ea0 <fwp_fmt_u128>
    7f80:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7f84:	910aa339 	add	x25, x25, #0x2a8
    7f88:	910123f5 	add	x21, sp, #0x48
    7f8c:	aa1303e4 	mov	x4, x19
    7f90:	aa1503e0 	mov	x0, x21
    7f94:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x2000>
    7f98:	f8616b25 	ldr	x5, [x25, x1]
    7f9c:	913f4063 	add	x3, x3, #0xfd0
    7fa0:	d2804002 	mov	x2, #0x200                 	// #512
    7fa4:	52800041 	mov	w1, #0x2                   	// #2
    7fa8:	97ffea02 	bl	27b0 <__sprintf_chk@plt>
    7fac:	17ffffc5 	b	7ec0 <fwp_write+0xeac>
    7fb0:	528005a4 	mov	w4, #0x2d                  	// #45
    7fb4:	eb0003e2 	negs	x2, x0
    7fb8:	da0103e3 	ngc	x3, x1
    7fbc:	910027e0 	add	x0, sp, #0x9
    7fc0:	910023f3 	add	x19, sp, #0x8
    7fc4:	390023e4 	strb	w4, [sp, #8]
    7fc8:	97ffebb6 	bl	2ea0 <fwp_fmt_u128>
    7fcc:	17ffffed 	b	7f80 <fwp_write+0xf6c>
    7fd0:	f9013bf5 	str	x21, [sp, #624]
    7fd4:	f9013ff6 	str	x22, [sp, #632]
    7fd8:	f90143f7 	str	x23, [sp, #640]
    7fdc:	f90147f8 	str	x24, [sp, #648]
    7fe0:	f9014bf9 	str	x25, [sp, #656]
    7fe4:	f9014ffa 	str	x26, [sp, #664]
    7fe8:	f90153fb 	str	x27, [sp, #672]
    7fec:	f90157fc 	str	x28, [sp, #680]
    7ff0:	fd015be8 	str	d8, [sp, #688]
    7ff4:	fd015fe9 	str	d9, [sp, #696]
    7ff8:	97ffea46 	bl	2910 <__stack_chk_fail@plt>
    7ffc:	d503201f 	nop

0000000000008000 <fwp_main_thread>:
    8000:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8004:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    8008:	91174001 	add	x1, x0, #0x5d0
    800c:	910003fd 	mov	x29, sp
    8010:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8014:	f947f400 	ldr	x0, [x0, #4072]
    8018:	a90153f3 	stp	x19, x20, [sp, #16]
    801c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8020:	d10643ff 	sub	sp, sp, #0x190
    8024:	b953a421 	ldr	w1, [x1, #5028]
    8028:	f9400002 	ldr	x2, [x0]
    802c:	f900c7e2 	str	x2, [sp, #392]
    8030:	d2800002 	mov	x2, #0x0                   	// #0
    8034:	34008c21 	cbz	w1, 91b8 <fwp_main_thread+0x11b8>
    8038:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    803c:	91174000 	add	x0, x0, #0x5d0
    8040:	b953a800 	ldr	w0, [x0, #5032]
    8044:	35008b20 	cbnz	w0, 91a8 <fwp_main_thread+0x11a8>
    8048:	9101c3e5 	add	x5, sp, #0x70
    804c:	900000d3 	adrp	x19, 20000 <__data_start>
    8050:	900000c2 	adrp	x2, 20000 <__data_start>
    8054:	9101c275 	add	x21, x19, #0x70
    8058:	910fc042 	add	x2, x2, #0x3f0
    805c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    8060:	d2a00024 	mov	x4, #0x10000               	// #65536
    8064:	910223e0 	add	x0, sp, #0x88
    8068:	d2800001 	mov	x1, #0x0                   	// #0
    806c:	f90007e0 	str	x0, [sp, #8]
    8070:	a9018ea5 	stp	x5, x3, [x21, #24]
    8074:	f90013e5 	str	x5, [sp, #32]
    8078:	f90047e2 	str	x2, [sp, #136]
    807c:	b90093ff 	str	wzr, [sp, #144]
    8080:	f9004fe4 	str	x4, [sp, #152]
    8084:	97ffe9bb 	bl	2770 <sigaltstack@plt>
    8088:	35011120 	cbnz	w0, a2ac <fwp_main_thread+0x22ac>
    808c:	4f000400 	movi	v0.4s, #0x0
    8090:	9103e3e0 	add	x0, sp, #0xf8
    8094:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8098:	9103c021 	add	x1, x1, #0xf0
    809c:	f9007be1 	str	x1, [sp, #240]
    80a0:	52800082 	mov	w2, #0x4                   	// #4
    80a4:	72a10002 	movk	w2, #0x800, lsl #16
    80a8:	9103c3f4 	add	x20, sp, #0xf0
    80ac:	3d802000 	str	q0, [x0, #128]
    80b0:	b9017be2 	str	w2, [sp, #376]
    80b4:	ad000000 	stp	q0, q0, [x0]
    80b8:	ad010000 	stp	q0, q0, [x0, #32]
    80bc:	ad020000 	stp	q0, q0, [x0, #64]
    80c0:	ad030000 	stp	q0, q0, [x0, #96]
    80c4:	97ffea03 	bl	28d0 <sigemptyset@plt>
    80c8:	35010f20 	cbnz	w0, a2ac <fwp_main_thread+0x22ac>
    80cc:	aa1403e1 	mov	x1, x20
    80d0:	d2800002 	mov	x2, #0x0                   	// #0
    80d4:	52800160 	mov	w0, #0xb                   	// #11
    80d8:	97ffea16 	bl	2930 <sigaction@plt>
    80dc:	35010e80 	cbnz	w0, a2ac <fwp_main_thread+0x22ac>
    80e0:	aa1403e1 	mov	x1, x20
    80e4:	d2800002 	mov	x2, #0x0                   	// #0
    80e8:	528000e0 	mov	w0, #0x7                   	// #7
    80ec:	97ffea11 	bl	2930 <sigaction@plt>
    80f0:	35010de0 	cbnz	w0, a2ac <fwp_main_thread+0x22ac>
    80f4:	b94346a0 	ldr	w0, [x21, #836]
    80f8:	340012e0 	cbz	w0, 8354 <fwp_main_thread+0x354>
    80fc:	9101c260 	add	x0, x19, #0x70
    8100:	a91c63f7 	stp	x23, x24, [sp, #448]
    8104:	b9434801 	ldr	w1, [x0, #840]
    8108:	340013a1 	cbz	w1, 837c <fwp_main_thread+0x37c>
    810c:	9101c276 	add	x22, x19, #0x70
    8110:	f9400ad5 	ldr	x21, [x22, #16]
    8114:	b4000c95 	cbz	x21, 82a4 <fwp_main_thread+0x2a4>
    8118:	aa1503f4 	mov	x20, x21
    811c:	910102b8 	add	x24, x21, #0x40
    8120:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8124:	52800037 	mov	w23, #0x1                   	// #1
    8128:	39414ab9 	ldrb	w25, [x21, #82]
    812c:	39014ab7 	strb	w23, [x21, #82]
    8130:	f94016a0 	ldr	x0, [x21, #40]
    8134:	b4000620 	cbz	x0, 81f8 <fwp_main_thread+0x1f8>
    8138:	f94032a1 	ldr	x1, [x21, #96]
    813c:	394146a0 	ldrb	w0, [x21, #81]
    8140:	b4000cc1 	cbz	x1, 82d8 <fwp_main_thread+0x2d8>
    8144:	36000b80 	tbz	w0, #0, 82b4 <fwp_main_thread+0x2b4>
    8148:	39414a82 	ldrb	w2, [x20, #82]
    814c:	f94022a0 	ldr	x0, [x21, #64]
    8150:	37000ee2 	tbnz	w2, #0, 832c <fwp_main_thread+0x32c>
    8154:	f9403281 	ldr	x1, [x20, #96]
    8158:	a911fe98 	stp	x24, xzr, [x20, #280]
    815c:	f9009680 	str	x0, [x20, #296]
    8160:	b4000040 	cbz	x0, 8168 <fwp_main_thread+0x168>
    8164:	f9009014 	str	x20, [x0, #288]
    8168:	f90022b4 	str	x20, [x21, #64]
    816c:	b4000101 	cbz	x1, 818c <fwp_main_thread+0x18c>
    8170:	f9406ec0 	ldr	x0, [x22, #216]
    8174:	39015697 	strb	w23, [x20, #85]
    8178:	f9003681 	str	x1, [x20, #104]
    817c:	a910829f 	stp	xzr, x0, [x20, #264]
    8180:	b4000040 	cbz	x0, 8188 <fwp_main_thread+0x188>
    8184:	f9008414 	str	x20, [x0, #264]
    8188:	f9006ed4 	str	x20, [x22, #216]
    818c:	39015a9f 	strb	wzr, [x20, #86]
    8190:	97fff915 	bl	65e4 <fwp_block>
    8194:	f9408e82 	ldr	x2, [x20, #280]
    8198:	b4000142 	cbz	x2, 81c0 <fwp_main_thread+0x1c0>
    819c:	a9520281 	ldp	x1, x0, [x20, #288]
    81a0:	b4000d21 	cbz	x1, 8344 <fwp_main_thread+0x344>
    81a4:	f9009420 	str	x0, [x1, #296]
    81a8:	f9409680 	ldr	x0, [x20, #296]
    81ac:	b4000040 	cbz	x0, 81b4 <fwp_main_thread+0x1b4>
    81b0:	f9009001 	str	x1, [x0, #288]
    81b4:	91080280 	add	x0, x20, #0x200
    81b8:	f900969f 	str	xzr, [x20, #296]
    81bc:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    81c0:	39415680 	ldrb	w0, [x20, #85]
    81c4:	f9400ac2 	ldr	x2, [x22, #16]
    81c8:	36000ae0 	tbz	w0, #0, 8324 <fwp_main_thread+0x324>
    81cc:	a9508281 	ldp	x1, x0, [x20, #264]
    81d0:	b4000be1 	cbz	x1, 834c <fwp_main_thread+0x34c>
    81d4:	f9008820 	str	x0, [x1, #272]
    81d8:	b4000040 	cbz	x0, 81e0 <fwp_main_thread+0x1e0>
    81dc:	f9008401 	str	x1, [x0, #264]
    81e0:	91080280 	add	x0, x20, #0x200
    81e4:	3901569f 	strb	wzr, [x20, #85]
    81e8:	aa0203f4 	mov	x20, x2
    81ec:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    81f0:	f94016a0 	ldr	x0, [x21, #40]
    81f4:	b5fffa20 	cbnz	x0, 8138 <fwp_main_thread+0x138>
    81f8:	9101c260 	add	x0, x19, #0x70
    81fc:	39014ab9 	strb	w25, [x21, #82]
    8200:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    8204:	f9419400 	ldr	x0, [x0, #808]
    8208:	b5000080 	cbnz	x0, 8218 <fwp_main_thread+0x218>
    820c:	9101c275 	add	x21, x19, #0x70
    8210:	f9419ea0 	ldr	x0, [x21, #824]
    8214:	b400fa20 	cbz	x0, a158 <fwp_main_thread+0x2158>
    8218:	9101c260 	add	x0, x19, #0x70
    821c:	f941b001 	ldr	x1, [x0, #864]
    8220:	b903581f 	str	wzr, [x0, #856]
    8224:	eb14003f 	cmp	x1, x20
    8228:	5400fae1 	b.ne	a184 <fwp_main_thread+0x2184>  // b.any
    822c:	b4007014 	cbz	x20, 902c <fwp_main_thread+0x102c>
    8230:	9101c260 	add	x0, x19, #0x70
    8234:	52800021 	mov	w1, #0x1                   	// #1
    8238:	39014a81 	strb	w1, [x20, #82]
    823c:	f9418005 	ldr	x5, [x0, #768]
    8240:	b4006f65 	cbz	x5, 902c <fwp_main_thread+0x102c>
    8244:	d503201f 	nop
    8248:	394140a0 	ldrb	w0, [x5, #80]
    824c:	37000060 	tbnz	w0, #0, 8258 <fwp_main_thread+0x258>
    8250:	aa0503e0 	mov	x0, x5
    8254:	97ffed47 	bl	3770 <fwp_cancel_tree.part.0>
    8258:	f9409ca5 	ldr	x5, [x5, #312]
    825c:	b5ffff65 	cbnz	x5, 8248 <fwp_main_thread+0x248>
    8260:	9101c275 	add	x21, x19, #0x70
    8264:	52800036 	mov	w22, #0x1                   	// #1
    8268:	f9402a80 	ldr	x0, [x20, #80]
    826c:	f2001c1f 	tst	x0, #0xff000000ff
    8270:	540000e1 	b.ne	828c <fwp_main_thread+0x28c>  // b.any
    8274:	f9403ea0 	ldr	x0, [x21, #120]
    8278:	39015296 	strb	w22, [x20, #84]
    827c:	f900829f 	str	xzr, [x20, #256]
    8280:	b4006cc0 	cbz	x0, 9018 <fwp_main_thread+0x1018>
    8284:	f9008014 	str	x20, [x0, #256]
    8288:	f9003eb4 	str	x20, [x21, #120]
    828c:	97fff8d6 	bl	65e4 <fwp_block>
    8290:	97fff868 	bl	6430 <fwp_free_zombie>
    8294:	f94182a0 	ldr	x0, [x21, #768]
    8298:	b4006ca0 	cbz	x0, 902c <fwp_main_thread+0x102c>
    829c:	f941b2b4 	ldr	x20, [x21, #864]
    82a0:	17fffff2 	b	8268 <fwp_main_thread+0x268>
    82a4:	f94196c0 	ldr	x0, [x22, #808]
    82a8:	b5006bc0 	cbnz	x0, 9020 <fwp_main_thread+0x1020>
    82ac:	d2800014 	mov	x20, #0x0                   	// #0
    82b0:	17ffffd7 	b	820c <fwp_main_thread+0x20c>
    82b4:	97ffedd3 	bl	3a00 <fwp_now_ns>
    82b8:	f94032a1 	ldr	x1, [x21, #96]
    82bc:	eb01001f 	cmp	x0, x1
    82c0:	540000ab 	b.lt	82d4 <fwp_main_thread+0x2d4>  // b.tstop
    82c4:	394142a0 	ldrb	w0, [x21, #80]
    82c8:	37000060 	tbnz	w0, #0, 82d4 <fwp_main_thread+0x2d4>
    82cc:	aa1503e0 	mov	x0, x21
    82d0:	97ffed28 	bl	3770 <fwp_cancel_tree.part.0>
    82d4:	394146a0 	ldrb	w0, [x21, #81]
    82d8:	39414a82 	ldrb	w2, [x20, #82]
    82dc:	3707f380 	tbnz	w0, #0, 814c <fwp_main_thread+0x14c>
    82e0:	f94032a1 	ldr	x1, [x21, #96]
    82e4:	370001c2 	tbnz	w2, #0, 831c <fwp_main_thread+0x31c>
    82e8:	f9403280 	ldr	x0, [x20, #96]
    82ec:	b4000180 	cbz	x0, 831c <fwp_main_thread+0x31c>
    82f0:	b4000061 	cbz	x1, 82fc <fwp_main_thread+0x2fc>
    82f4:	eb01001f 	cmp	x0, x1
    82f8:	9a81d000 	csel	x0, x0, x1, le
    82fc:	f94022a1 	ldr	x1, [x21, #64]
    8300:	a911fe98 	stp	x24, xzr, [x20, #280]
    8304:	f9009681 	str	x1, [x20, #296]
    8308:	b400f181 	cbz	x1, a138 <fwp_main_thread+0x2138>
    830c:	f9009034 	str	x20, [x1, #288]
    8310:	aa0003e1 	mov	x1, x0
    8314:	f90022b4 	str	x20, [x21, #64]
    8318:	17ffff96 	b	8170 <fwp_main_thread+0x170>
    831c:	f94022a0 	ldr	x0, [x21, #64]
    8320:	17ffff8e 	b	8158 <fwp_main_thread+0x158>
    8324:	aa0203f4 	mov	x20, x2
    8328:	17ffff82 	b	8130 <fwp_main_thread+0x130>
    832c:	a911fe98 	stp	x24, xzr, [x20, #280]
    8330:	f9009680 	str	x0, [x20, #296]
    8334:	b4000040 	cbz	x0, 833c <fwp_main_thread+0x33c>
    8338:	f9009014 	str	x20, [x0, #288]
    833c:	f90022b4 	str	x20, [x21, #64]
    8340:	17ffff93 	b	818c <fwp_main_thread+0x18c>
    8344:	f9000040 	str	x0, [x2]
    8348:	17ffff99 	b	81ac <fwp_main_thread+0x1ac>
    834c:	f9006ec0 	str	x0, [x22, #216]
    8350:	17ffffa2 	b	81d8 <fwp_main_thread+0x1d8>
    8354:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    8358:	91078000 	add	x0, x0, #0x1e0
    835c:	940009b1 	bl	aa20 <atexit>
    8360:	a91c63f7 	stp	x23, x24, [sp, #448]
    8364:	3500fb20 	cbnz	w0, a2c8 <fwp_main_thread+0x22c8>
    8368:	52800020 	mov	w0, #0x1                   	// #1
    836c:	b90346a0 	str	w0, [x21, #836]
    8370:	9101c260 	add	x0, x19, #0x70
    8374:	b9434801 	ldr	w1, [x0, #840]
    8378:	35ffeca1 	cbnz	w1, 810c <fwp_main_thread+0x10c>
    837c:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    8380:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8384:	f9418803 	ldr	x3, [x0, #784]
    8388:	913f4042 	add	x2, x2, #0xfd0
    838c:	a91e73fb 	stp	x27, x28, [sp, #480]
    8390:	9117403b 	add	x27, x1, #0x5d0
    8394:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8398:	912b0021 	add	x1, x1, #0xac0
    839c:	a9070be3 	stp	x3, x2, [sp, #112]
    83a0:	d2804018 	mov	x24, #0x200                 	// #512
    83a4:	f94007e2 	ldr	x2, [sp, #8]
    83a8:	a90987ff 	stp	xzr, x1, [sp, #152]
    83ac:	d2800015 	mov	x21, #0x0                   	// #0
    83b0:	f94013e1 	ldr	x1, [sp, #32]
    83b4:	a91d6bf9 	stp	x25, x26, [sp, #464]
    83b8:	52800036 	mov	w22, #0x1                   	// #1
    83bc:	fd00fbe8 	str	d8, [sp, #496]
    83c0:	f9000fff 	str	xzr, [sp, #24]
    83c4:	f90043e2 	str	x2, [sp, #128]
    83c8:	f90047ff 	str	xzr, [sp, #136]
    83cc:	f9018801 	str	x1, [x0, #784]
    83d0:	f9400fe2 	ldr	x2, [sp, #24]
    83d4:	f1000719 	subs	x25, x24, #0x1
    83d8:	aa1403e1 	mov	x1, x20
    83dc:	da1f02ba 	sbc	x26, x21, xzr
    83e0:	52800020 	mov	w0, #0x1                   	// #1
    83e4:	f9004bf9 	str	x25, [sp, #144]
    83e8:	a90f0bf9 	stp	x25, x2, [sp, #240]
    83ec:	97fff326 	bl	5084 <fwp_data.part.0.constprop.0>
    83f0:	aa0003e2 	mov	x2, x0
    83f4:	f949db61 	ldr	x1, [x27, #5040]
    83f8:	f9000fe2 	str	x2, [sp, #24]
    83fc:	f949ef60 	ldr	x0, [x27, #5080]
    8400:	cb010041 	sub	x1, x2, x1
    8404:	aa1903f8 	mov	x24, x25
    8408:	aa1a03f5 	mov	x21, x26
    840c:	eb00403f 	cmp	x1, x0, lsl #16
    8410:	54000302 	b.cs	8470 <fwp_main_thread+0x470>  // b.hs, b.nlast
    8414:	d350fc20 	lsr	x0, x1, #16
    8418:	f949ff63 	ldr	x3, [x27, #5112]
    841c:	8b000800 	add	x0, x0, x0, lsl #2
    8420:	d37df002 	lsl	x2, x0, #3
    8424:	8b020060 	add	x0, x3, x2
    8428:	f9401017 	ldr	x23, [x0, #32]
    842c:	b4000237 	cbz	x23, 8470 <fwp_main_thread+0x470>
    8430:	38626862 	ldrb	w2, [x3, x2]
    8434:	7100085f 	cmp	w2, #0x2
    8438:	54006a80 	b.eq	9188 <fwp_main_thread+0x1188>  // b.none
    843c:	7100045f 	cmp	w2, #0x1
    8440:	54000181 	b.ne	8470 <fwp_main_thread+0x470>  // b.any
    8444:	29430002 	ldp	w2, w0, [x0, #24]
    8448:	92403c21 	and	x1, x1, #0xffff
    844c:	9b027c21 	mul	x1, x1, x2
    8450:	d360fc21 	lsr	x1, x1, #32
    8454:	eb00003f 	cmp	x1, x0
    8458:	540000c2 	b.cs	8470 <fwp_main_thread+0x470>  // b.hs, b.nlast
    845c:	8b0102f7 	add	x23, x23, x1
    8460:	394002e0 	ldrb	w0, [x23]
    8464:	7103fc1f 	cmp	w0, #0xff
    8468:	540069a0 	b.eq	919c <fwp_main_thread+0x119c>  // b.none
    846c:	390002f6 	strb	w22, [x23]
    8470:	f9400fe0 	ldr	x0, [sp, #24]
    8474:	f90047e0 	str	x0, [sp, #136]
    8478:	aa1a0320 	orr	x0, x25, x26
    847c:	b5fffaa0 	cbnz	x0, 83d0 <fwp_main_thread+0x3d0>
    8480:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    8484:	9101c262 	add	x2, x19, #0x70
    8488:	f9403bf6 	ldr	x22, [sp, #112]
    848c:	910303e1 	add	x1, sp, #0xc0
    8490:	3dc21400 	ldr	q0, [x0, #2128]
    8494:	52800020 	mov	w0, #0x1                   	// #1
    8498:	f9018856 	str	x22, [x2, #784]
    849c:	3d8033e0 	str	q0, [sp, #192]
    84a0:	97fff2f9 	bl	5084 <fwp_data.part.0.constprop.0>
    84a4:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    84a8:	91174022 	add	x2, x1, #0x5d0
    84ac:	aa0003f7 	mov	x23, x0
    84b0:	f949d841 	ldr	x1, [x2, #5040]
    84b4:	f949ec40 	ldr	x0, [x2, #5080]
    84b8:	cb0102e1 	sub	x1, x23, x1
    84bc:	eb00403f 	cmp	x1, x0, lsl #16
    84c0:	54000322 	b.cs	8524 <fwp_main_thread+0x524>  // b.hs, b.nlast
    84c4:	d350fc20 	lsr	x0, x1, #16
    84c8:	f949fc43 	ldr	x3, [x2, #5112]
    84cc:	8b000800 	add	x0, x0, x0, lsl #2
    84d0:	d37df002 	lsl	x2, x0, #3
    84d4:	8b020060 	add	x0, x3, x2
    84d8:	f9401015 	ldr	x21, [x0, #32]
    84dc:	b4000255 	cbz	x21, 8524 <fwp_main_thread+0x524>
    84e0:	38626862 	ldrb	w2, [x3, x2]
    84e4:	7100085f 	cmp	w2, #0x2
    84e8:	5400e160 	b.eq	a114 <fwp_main_thread+0x2114>  // b.none
    84ec:	7100045f 	cmp	w2, #0x1
    84f0:	540001a1 	b.ne	8524 <fwp_main_thread+0x524>  // b.any
    84f4:	29430002 	ldp	w2, w0, [x0, #24]
    84f8:	92403c21 	and	x1, x1, #0xffff
    84fc:	9b027c21 	mul	x1, x1, x2
    8500:	d360fc21 	lsr	x1, x1, #32
    8504:	eb00003f 	cmp	x1, x0
    8508:	540000e2 	b.cs	8524 <fwp_main_thread+0x524>  // b.hs, b.nlast
    850c:	8b0102b5 	add	x21, x21, x1
    8510:	394002a0 	ldrb	w0, [x21]
    8514:	7103fc1f 	cmp	w0, #0xff
    8518:	5400eac0 	b.eq	a270 <fwp_main_thread+0x2270>  // b.none
    851c:	52800020 	mov	w0, #0x1                   	// #1
    8520:	390002a0 	strb	w0, [x21]
    8524:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8528:	910383e1 	add	x1, sp, #0xe0
    852c:	52800020 	mov	w0, #0x1                   	// #1
    8530:	a90e5fe2 	stp	x2, x23, [sp, #224]
    8534:	97fff2d4 	bl	5084 <fwp_data.part.0.constprop.0>
    8538:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    853c:	91174022 	add	x2, x1, #0x5d0
    8540:	aa0003f7 	mov	x23, x0
    8544:	f949d841 	ldr	x1, [x2, #5040]
    8548:	f949ec40 	ldr	x0, [x2, #5080]
    854c:	cb0102e1 	sub	x1, x23, x1
    8550:	eb00403f 	cmp	x1, x0, lsl #16
    8554:	54000322 	b.cs	85b8 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    8558:	d350fc20 	lsr	x0, x1, #16
    855c:	f949fc43 	ldr	x3, [x2, #5112]
    8560:	8b000800 	add	x0, x0, x0, lsl #2
    8564:	d37df002 	lsl	x2, x0, #3
    8568:	8b020060 	add	x0, x3, x2
    856c:	f9401015 	ldr	x21, [x0, #32]
    8570:	b4000255 	cbz	x21, 85b8 <fwp_main_thread+0x5b8>
    8574:	38626862 	ldrb	w2, [x3, x2]
    8578:	7100085f 	cmp	w2, #0x2
    857c:	5400dd80 	b.eq	a12c <fwp_main_thread+0x212c>  // b.none
    8580:	7100045f 	cmp	w2, #0x1
    8584:	540001a1 	b.ne	85b8 <fwp_main_thread+0x5b8>  // b.any
    8588:	29430002 	ldp	w2, w0, [x0, #24]
    858c:	92403c21 	and	x1, x1, #0xffff
    8590:	9b027c21 	mul	x1, x1, x2
    8594:	d360fc21 	lsr	x1, x1, #32
    8598:	eb00003f 	cmp	x1, x0
    859c:	540000e2 	b.cs	85b8 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    85a0:	8b0102b5 	add	x21, x21, x1
    85a4:	394002a0 	ldrb	w0, [x21]
    85a8:	7103fc1f 	cmp	w0, #0xff
    85ac:	5400e680 	b.eq	a27c <fwp_main_thread+0x227c>  // b.none
    85b0:	52800020 	mov	w0, #0x1                   	// #1
    85b4:	390002a0 	strb	w0, [x21]
    85b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    85bc:	910343e1 	add	x1, sp, #0xd0
    85c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    85c4:	52800020 	mov	w0, #0x1                   	// #1
    85c8:	a90d5fe2 	stp	x2, x23, [sp, #208]
    85cc:	97fff2ae 	bl	5084 <fwp_data.part.0.constprop.0>
    85d0:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    85d4:	91174022 	add	x2, x1, #0x5d0
    85d8:	aa0003f5 	mov	x21, x0
    85dc:	f949d841 	ldr	x1, [x2, #5040]
    85e0:	f949ec40 	ldr	x0, [x2, #5080]
    85e4:	cb0102a1 	sub	x1, x21, x1
    85e8:	eb00403f 	cmp	x1, x0, lsl #16
    85ec:	54000322 	b.cs	8650 <fwp_main_thread+0x650>  // b.hs, b.nlast
    85f0:	d350fc20 	lsr	x0, x1, #16
    85f4:	f949fc43 	ldr	x3, [x2, #5112]
    85f8:	8b000800 	add	x0, x0, x0, lsl #2
    85fc:	d37df002 	lsl	x2, x0, #3
    8600:	8b020060 	add	x0, x3, x2
    8604:	f9401017 	ldr	x23, [x0, #32]
    8608:	b4000257 	cbz	x23, 8650 <fwp_main_thread+0x650>
    860c:	38626862 	ldrb	w2, [x3, x2]
    8610:	7100085f 	cmp	w2, #0x2
    8614:	5400d860 	b.eq	a120 <fwp_main_thread+0x2120>  // b.none
    8618:	7100045f 	cmp	w2, #0x1
    861c:	540001a1 	b.ne	8650 <fwp_main_thread+0x650>  // b.any
    8620:	29430002 	ldp	w2, w0, [x0, #24]
    8624:	92403c21 	and	x1, x1, #0xffff
    8628:	9b027c21 	mul	x1, x1, x2
    862c:	d360fc21 	lsr	x1, x1, #32
    8630:	eb00003f 	cmp	x1, x0
    8634:	540000e2 	b.cs	8650 <fwp_main_thread+0x650>  // b.hs, b.nlast
    8638:	8b0102f7 	add	x23, x23, x1
    863c:	394002e0 	ldrb	w0, [x23]
    8640:	7103fc1f 	cmp	w0, #0xff
    8644:	5400e220 	b.eq	a288 <fwp_main_thread+0x2288>  // b.none
    8648:	52800020 	mov	w0, #0x1                   	// #1
    864c:	390002e0 	strb	w0, [x23]
    8650:	f9400fe0 	ldr	x0, [sp, #24]
    8654:	b400c600 	cbz	x0, 9f14 <fwp_main_thread+0x1f14>
    8658:	900000c0 	adrp	x0, 20000 <__data_start>
    865c:	91004000 	add	x0, x0, #0x10
    8660:	9100e000 	add	x0, x0, #0x38
    8664:	f9001fe0 	str	x0, [sp, #56]
    8668:	f9400fe0 	ldr	x0, [sp, #24]
    866c:	f90027e0 	str	x0, [sp, #72]
    8670:	910143e0 	add	x0, sp, #0x50
    8674:	f90017e0 	str	x0, [sp, #40]
    8678:	910163e0 	add	x0, sp, #0x58
    867c:	f9001be0 	str	x0, [sp, #48]
    8680:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    8684:	9117401c 	add	x28, x0, #0x5d0
    8688:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    868c:	fd443008 	ldr	d8, [x0, #2144]
    8690:	f949ef86 	ldr	x6, [x28, #5080]
    8694:	f949db83 	ldr	x3, [x28, #5040]
    8698:	d370bcc6 	lsl	x6, x6, #16
    869c:	cb0302a2 	sub	x2, x21, x3
    86a0:	eb06005f 	cmp	x2, x6
    86a4:	540003a2 	b.cs	8718 <fwp_main_thread+0x718>  // b.hs, b.nlast
    86a8:	d350fc40 	lsr	x0, x2, #16
    86ac:	f949ff87 	ldr	x7, [x28, #5112]
    86b0:	8b000800 	add	x0, x0, x0, lsl #2
    86b4:	d37df001 	lsl	x1, x0, #3
    86b8:	8b0100e5 	add	x5, x7, x1
    86bc:	f94010a0 	ldr	x0, [x5, #32]
    86c0:	b40002c0 	cbz	x0, 8718 <fwp_main_thread+0x718>
    86c4:	386168e1 	ldrb	w1, [x7, x1]
    86c8:	7100083f 	cmp	w1, #0x2
    86cc:	5400c420 	b.eq	9f50 <fwp_main_thread+0x1f50>  // b.none
    86d0:	7100043f 	cmp	w1, #0x1
    86d4:	54000221 	b.ne	8718 <fwp_main_thread+0x718>  // b.any
    86d8:	92403c41 	and	x1, x2, #0xffff
    86dc:	294308a7 	ldp	w7, w2, [x5, #24]
    86e0:	9b077c21 	mul	x1, x1, x7
    86e4:	d360fc21 	lsr	x1, x1, #32
    86e8:	eb02003f 	cmp	x1, x2
    86ec:	54000162 	b.cs	8718 <fwp_main_thread+0x718>  // b.hs, b.nlast
    86f0:	8b010000 	add	x0, x0, x1
    86f4:	39400001 	ldrb	w1, [x0]
    86f8:	34000101 	cbz	w1, 8718 <fwp_main_thread+0x718>
    86fc:	7103f43f 	cmp	w1, #0xfd
    8700:	5400d6a8 	b.hi	a1d4 <fwp_main_thread+0x21d4>  // b.pmore
    8704:	11000421 	add	w1, w1, #0x1
    8708:	39000001 	strb	w1, [x0]
    870c:	f949ef86 	ldr	x6, [x28, #5080]
    8710:	f949db83 	ldr	x3, [x28, #5040]
    8714:	d370bcc6 	lsl	x6, x6, #16
    8718:	f9401fe1 	ldr	x1, [sp, #56]
    871c:	9101c260 	add	x0, x19, #0x70
    8720:	12800002 	mov	w2, #0xffffffff            	// #-1
    8724:	b90053e2 	str	w2, [sp, #80]
    8728:	cb030023 	sub	x3, x1, x3
    872c:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8730:	913e4021 	add	x1, x1, #0xf90
    8734:	a90587f6 	stp	x22, x1, [sp, #88]
    8738:	f94017e1 	ldr	x1, [sp, #40]
    873c:	f90037e1 	str	x1, [sp, #104]
    8740:	f9401be1 	ldr	x1, [sp, #48]
    8744:	f9018801 	str	x1, [x0, #784]
    8748:	eb06007f 	cmp	x3, x6
    874c:	54000762 	b.cs	8838 <fwp_main_thread+0x838>  // b.hs, b.nlast
    8750:	d350fc60 	lsr	x0, x3, #16
    8754:	f949ff85 	ldr	x5, [x28, #5112]
    8758:	8b000800 	add	x0, x0, x0, lsl #2
    875c:	d37df002 	lsl	x2, x0, #3
    8760:	8b0200a1 	add	x1, x5, x2
    8764:	f9401036 	ldr	x22, [x1, #32]
    8768:	b4000696 	cbz	x22, 8838 <fwp_main_thread+0x838>
    876c:	386268a0 	ldrb	w0, [x5, x2]
    8770:	7100081f 	cmp	w0, #0x2
    8774:	5400af40 	b.eq	9d5c <fwp_main_thread+0x1d5c>  // b.none
    8778:	7100041f 	cmp	w0, #0x1
    877c:	540005e1 	b.ne	8838 <fwp_main_thread+0x838>  // b.any
    8780:	29430825 	ldp	w5, w2, [x1, #24]
    8784:	92403c60 	and	x0, x3, #0xffff
    8788:	9b057c00 	mul	x0, x0, x5
    878c:	d360fc00 	lsr	x0, x0, #32
    8790:	eb02001f 	cmp	x0, x2
    8794:	54000282 	b.cs	87e4 <fwp_main_thread+0x7e4>  // b.hs, b.nlast
    8798:	8b0002c0 	add	x0, x22, x0
    879c:	39400002 	ldrb	w2, [x0]
    87a0:	34000222 	cbz	w2, 87e4 <fwp_main_thread+0x7e4>
    87a4:	7103f45f 	cmp	w2, #0xfd
    87a8:	5400c848 	b.hi	a0b0 <fwp_main_thread+0x20b0>  // b.pmore
    87ac:	11000442 	add	w2, w2, #0x1
    87b0:	39000002 	strb	w2, [x0]
    87b4:	f9401fe1 	ldr	x1, [sp, #56]
    87b8:	f949db83 	ldr	x3, [x28, #5040]
    87bc:	f949ef80 	ldr	x0, [x28, #5080]
    87c0:	cb030023 	sub	x3, x1, x3
    87c4:	eb00407f 	cmp	x3, x0, lsl #16
    87c8:	54000382 	b.cs	8838 <fwp_main_thread+0x838>  // b.hs, b.nlast
    87cc:	f949ff80 	ldr	x0, [x28, #5112]
    87d0:	d350fc61 	lsr	x1, x3, #16
    87d4:	8b010821 	add	x1, x1, x1, lsl #2
    87d8:	8b010c01 	add	x1, x0, x1, lsl #3
    87dc:	f9401036 	ldr	x22, [x1, #32]
    87e0:	b40002d6 	cbz	x22, 8838 <fwp_main_thread+0x838>
    87e4:	39400020 	ldrb	w0, [x1]
    87e8:	7100081f 	cmp	w0, #0x2
    87ec:	5400ac00 	b.eq	9d6c <fwp_main_thread+0x1d6c>  // b.none
    87f0:	7100041f 	cmp	w0, #0x1
    87f4:	54000221 	b.ne	8838 <fwp_main_thread+0x838>  // b.any
    87f8:	29430022 	ldp	w2, w0, [x1, #24]
    87fc:	92403c63 	and	x3, x3, #0xffff
    8800:	9b027c61 	mul	x1, x3, x2
    8804:	d360fc21 	lsr	x1, x1, #32
    8808:	eb00003f 	cmp	x1, x0
    880c:	54000162 	b.cs	8838 <fwp_main_thread+0x838>  // b.hs, b.nlast
    8810:	8b0102d6 	add	x22, x22, x1
    8814:	394002c1 	ldrb	w1, [x22]
    8818:	34000101 	cbz	w1, 8838 <fwp_main_thread+0x838>
    881c:	7100043f 	cmp	w1, #0x1
    8820:	54009020 	b.eq	9a24 <fwp_main_thread+0x1a24>  // b.none
    8824:	7103fc3f 	cmp	w1, #0xff
    8828:	5400c480 	b.eq	a0b8 <fwp_main_thread+0x20b8>  // b.none
    882c:	51000421 	sub	w1, w1, #0x1
    8830:	390002c1 	strb	w1, [x22]
    8834:	d503201f 	nop
    8838:	b4009075 	cbz	x21, 9a44 <fwp_main_thread+0x1a44>
    883c:	aa1503e0 	mov	x0, x21
    8840:	d2800016 	mov	x22, #0x0                   	// #0
    8844:	d503201f 	nop
    8848:	f9400800 	ldr	x0, [x0, #16]
    884c:	910006d6 	add	x22, x22, #0x1
    8850:	b5ffffc0 	cbnz	x0, 8848 <fwp_main_thread+0x848>
    8854:	52800000 	mov	w0, #0x0                   	// #0
    8858:	97ffeb86 	bl	3670 <descent_phase_step>
    885c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8860:	eb0002df 	cmp	x22, x0
    8864:	5400d528 	b.hi	a308 <fwp_main_thread+0x2308>  // b.pmore
    8868:	9101c277 	add	x23, x19, #0x70
    886c:	b9434ee0 	ldr	w0, [x23, #844]
    8870:	34008f80 	cbz	w0, 9a60 <fwp_main_thread+0x1a60>
    8874:	9101c260 	add	x0, x19, #0x70
    8878:	f9404818 	ldr	x24, [x0, #144]
    887c:	f9407417 	ldr	x23, [x0, #232]
    8880:	eb1802ff 	cmp	x23, x24
    8884:	5400906a 	b.ge	9a90 <fwp_main_thread+0x1a90>  // b.tcont
    8888:	f9403a61 	ldr	x1, [x19, #112]
    888c:	8b1706e0 	add	x0, x23, x23, lsl #1
    8890:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8894:	8b000ae0 	add	x0, x23, x0, lsl #2
    8898:	8b000c20 	add	x0, x1, x0, lsl #3
    889c:	d503201f 	nop
    88a0:	b9400401 	ldr	w1, [x0, #4]
    88a4:	35000081 	cbnz	w1, 88b4 <fwp_main_thread+0x8b4>
    88a8:	b9400001 	ldr	w1, [x0]
    88ac:	6b02003f 	cmp	w1, w2
    88b0:	54008f09 	b.ls	9a90 <fwp_main_thread+0x1a90>  // b.plast
    88b4:	910006f7 	add	x23, x23, #0x1
    88b8:	9101a000 	add	x0, x0, #0x68
    88bc:	eb1802ff 	cmp	x23, x24
    88c0:	54ffff01 	b.ne	88a0 <fwp_main_thread+0x8a0>  // b.any
    88c4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    88c8:	eb00031f 	cmp	x24, x0
    88cc:	5400d24c 	b.gt	a314 <fwp_main_thread+0x2314>
    88d0:	9101c260 	add	x0, x19, #0x70
    88d4:	f9403a79 	ldr	x25, [x19, #112]
    88d8:	f9407000 	ldr	x0, [x0, #224]
    88dc:	eb18001f 	cmp	x0, x24
    88e0:	54000201 	b.ne	8920 <fwp_main_thread+0x920>  // b.any
    88e4:	b400ae98 	cbz	x24, 9eb4 <fwp_main_thread+0x1eb4>
    88e8:	d37ffb1b 	lsl	x27, x24, #1
    88ec:	d29fffe0 	mov	x0, #0xffff                	// #65535
    88f0:	eb00037f 	cmp	x27, x0
    88f4:	9a80d37b 	csel	x27, x27, x0, le
    88f8:	8b1b0761 	add	x1, x27, x27, lsl #1
    88fc:	8b010b61 	add	x1, x27, x1, lsl #2
    8900:	d37df021 	lsl	x1, x1, #3
    8904:	aa1903e0 	mov	x0, x25
    8908:	97ffe7fe 	bl	2900 <realloc@plt>
    890c:	aa0003f9 	mov	x25, x0
    8910:	b40047a0 	cbz	x0, 9204 <fwp_main_thread+0x1204>
    8914:	9101c260 	add	x0, x19, #0x70
    8918:	f9003a79 	str	x25, [x19, #112]
    891c:	f900701b 	str	x27, [x0, #224]
    8920:	8b180701 	add	x1, x24, x24, lsl #1
    8924:	91000702 	add	x2, x24, #0x1
    8928:	4f000400 	movi	v0.4s, #0x0
    892c:	9101c260 	add	x0, x19, #0x70
    8930:	8b010b01 	add	x1, x24, x1, lsl #2
    8934:	8b1706f8 	add	x24, x23, x23, lsl #1
    8938:	8b180af8 	add	x24, x23, x24, lsl #2
    893c:	8b010f21 	add	x1, x25, x1, lsl #3
    8940:	f9004802 	str	x2, [x0, #144]
    8944:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    8948:	8b180f38 	add	x24, x25, x24, lsl #3
    894c:	91350000 	add	x0, x0, #0xd40
    8950:	ad000020 	stp	q0, q0, [x1]
    8954:	ad010020 	stp	q0, q0, [x1, #32]
    8958:	ad020020 	stp	q0, q0, [x1, #64]
    895c:	f900303f 	str	xzr, [x1, #96]
    8960:	f900331f 	str	xzr, [x24, #96]
    8964:	97ffe84f 	bl	2aa0 <getenv@plt>
    8968:	b4008aa0 	cbz	x0, 9abc <fwp_main_thread+0x1abc>
    896c:	39400001 	ldrb	w1, [x0]
    8970:	7100c03f 	cmp	w1, #0x30
    8974:	54008a41 	b.ne	9abc <fwp_main_thread+0x1abc>  // b.any
    8978:	39400400 	ldrb	w0, [x0, #1]
    897c:	35008a00 	cbnz	w0, 9abc <fwp_main_thread+0x1abc>
    8980:	9101c260 	add	x0, x19, #0x70
    8984:	2f000400 	mvni	v0.2s, #0x0
    8988:	b9400305 	ldr	w5, [x24]
    898c:	52800022 	mov	w2, #0x1                   	// #1
    8990:	910006e6 	add	x6, x23, #0x1
    8994:	a900db16 	stp	x22, x22, [x24, #8]
    8998:	0b0200a5 	add	w5, w5, w2
    899c:	f9418801 	ldr	x1, [x0, #784]
    89a0:	29000b05 	stp	w5, w2, [x24]
    89a4:	f9002b1f 	str	xzr, [x24, #80]
    89a8:	f9007406 	str	x6, [x0, #232]
    89ac:	fd002f00 	str	d0, [x24, #88]
    89b0:	b400c721 	cbz	x1, a294 <fwp_main_thread+0x2294>
    89b4:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    89b8:	913e4003 	add	x3, x0, #0xf90
    89bc:	14000003 	b	89c8 <fwp_main_thread+0x9c8>
    89c0:	f9400021 	ldr	x1, [x1]
    89c4:	b400c681 	cbz	x1, a294 <fwp_main_thread+0x2294>
    89c8:	f9400422 	ldr	x2, [x1, #8]
    89cc:	eb03005f 	cmp	x2, x3
    89d0:	54ffff81 	b.ne	89c0 <fwp_main_thread+0x9c0>  // b.any
    89d4:	f9400820 	ldr	x0, [x1, #16]
    89d8:	2a1703e2 	mov	w2, w23
    89dc:	b9400001 	ldr	w1, [x0]
    89e0:	f9002b00 	str	x0, [x24, #80]
    89e4:	b9005f01 	str	w1, [x24, #92]
    89e8:	37f80081 	tbnz	w1, #31, 89f8 <fwp_main_thread+0x9f8>
    89ec:	52800d03 	mov	w3, #0x68                  	// #104
    89f0:	9b236421 	smaddl	x1, w1, w3, x25
    89f4:	b9005837 	str	w23, [x1, #88]
    89f8:	b9000002 	str	w2, [x0]
    89fc:	d3707cb6 	ubfiz	x22, x5, #16, #32
    8a00:	52800020 	mov	w0, #0x1                   	// #1
    8a04:	aa0602d6 	orr	x22, x22, x6
    8a08:	97ffeb1a 	bl	3670 <descent_phase_step>
    8a0c:	aa1503e0 	mov	x0, x21
    8a10:	d2800002 	mov	x2, #0x0                   	// #0
    8a14:	b4008df5 	cbz	x21, 9bd0 <fwp_main_thread+0x1bd0>
    8a18:	f9400800 	ldr	x0, [x0, #16]
    8a1c:	91000442 	add	x2, x2, #0x1
    8a20:	b5ffffc0 	cbnz	x0, 8a18 <fwp_main_thread+0xa18>
    8a24:	aa1503e1 	mov	x1, x21
    8a28:	f9400821 	ldr	x1, [x1, #16]
    8a2c:	91000400 	add	x0, x0, #0x1
    8a30:	b5ffffc1 	cbnz	x1, 8a28 <fwp_main_thread+0xa28>
    8a34:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8a38:	eb01001f 	cmp	x0, x1
    8a3c:	5400c0e8 	b.hi	a258 <fwp_main_thread+0x2258>  // b.pmore
    8a40:	f100005f 	cmp	x2, #0x0
    8a44:	54008c6d 	b.le	9bd0 <fwp_main_thread+0x1bd0>
    8a48:	eb00005f 	cmp	x2, x0
    8a4c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8a50:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8a54:	eb0102ff 	cmp	x23, x1
    8a58:	5400c008 	b.hi	a258 <fwp_main_thread+0x2258>  // b.pmore
    8a5c:	d37ffaf8 	lsl	x24, x23, #1
    8a60:	52800041 	mov	w1, #0x2                   	// #2
    8a64:	91000700 	add	x0, x24, #0x1
    8a68:	d37df000 	lsl	x0, x0, #3
    8a6c:	97fff141 	bl	4f70 <fwp_heap_alloc>
    8a70:	f9000018 	str	x24, [x0]
    8a74:	aa0003f9 	mov	x25, x0
    8a78:	aa0003fb 	mov	x27, x0
    8a7c:	f949db81 	ldr	x1, [x28, #5040]
    8a80:	f949ef80 	ldr	x0, [x28, #5080]
    8a84:	cb010321 	sub	x1, x25, x1
    8a88:	eb00403f 	cmp	x1, x0, lsl #16
    8a8c:	54008c42 	b.cs	9c14 <fwp_main_thread+0x1c14>  // b.hs, b.nlast
    8a90:	d350fc20 	lsr	x0, x1, #16
    8a94:	f949ff83 	ldr	x3, [x28, #5112]
    8a98:	8b000800 	add	x0, x0, x0, lsl #2
    8a9c:	d37df002 	lsl	x2, x0, #3
    8aa0:	8b020060 	add	x0, x3, x2
    8aa4:	f9401018 	ldr	x24, [x0, #32]
    8aa8:	b4000258 	cbz	x24, 8af0 <fwp_main_thread+0xaf0>
    8aac:	38626862 	ldrb	w2, [x3, x2]
    8ab0:	7100085f 	cmp	w2, #0x2
    8ab4:	54009620 	b.eq	9d78 <fwp_main_thread+0x1d78>  // b.none
    8ab8:	7100045f 	cmp	w2, #0x1
    8abc:	540001a1 	b.ne	8af0 <fwp_main_thread+0xaf0>  // b.any
    8ac0:	29430002 	ldp	w2, w0, [x0, #24]
    8ac4:	92403c21 	and	x1, x1, #0xffff
    8ac8:	9b027c21 	mul	x1, x1, x2
    8acc:	d360fc21 	lsr	x1, x1, #32
    8ad0:	eb00003f 	cmp	x1, x0
    8ad4:	540000e2 	b.cs	8af0 <fwp_main_thread+0xaf0>  // b.hs, b.nlast
    8ad8:	8b010318 	add	x24, x24, x1
    8adc:	39400300 	ldrb	w0, [x24]
    8ae0:	7103fc1f 	cmp	w0, #0xff
    8ae4:	54009540 	b.eq	9d8c <fwp_main_thread+0x1d8c>  // b.none
    8ae8:	52800020 	mov	w0, #0x1                   	// #1
    8aec:	39000300 	strb	w0, [x24]
    8af0:	b4000237 	cbz	x23, 8b34 <fwp_main_thread+0xb34>
    8af4:	d3607ec5 	lsl	x5, x22, #32
    8af8:	aa1503e1 	mov	x1, x21
    8afc:	f94006a6 	ldr	x6, [x21, #8]
    8b00:	aa0503e3 	mov	x3, x5
    8b04:	91002322 	add	x2, x25, #0x8
    8b08:	d2800000 	mov	x0, #0x0                   	// #0
    8b0c:	14000005 	b	8b20 <fwp_main_thread+0xb20>
    8b10:	f9400426 	ldr	x6, [x1, #8]
    8b14:	ab050003 	adds	x3, x0, x5
    8b18:	91004042 	add	x2, x2, #0x10
    8b1c:	5400c026 	b.vs	a320 <fwp_main_thread+0x2320>
    8b20:	a9000c46 	stp	x6, x3, [x2]
    8b24:	91000400 	add	x0, x0, #0x1
    8b28:	f9400821 	ldr	x1, [x1, #16]
    8b2c:	eb0002ff 	cmp	x23, x0
    8b30:	54ffff08 	b.hi	8b10 <fwp_main_thread+0xb10>  // b.pmore
    8b34:	f9400320 	ldr	x0, [x25]
    8b38:	f100041f 	cmp	x0, #0x1
    8b3c:	540086e9 	b.ls	9c18 <fwp_main_thread+0x1c18>  // b.plast
    8b40:	d341fc00 	lsr	x0, x0, #1
    8b44:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8b48:	d1000418 	sub	x24, x0, #0x1
    8b4c:	eb01031f 	cmp	x24, x1
    8b50:	5400b848 	b.hi	a258 <fwp_main_thread+0x2258>  // b.pmore
    8b54:	b4008638 	cbz	x24, 9c18 <fwp_main_thread+0x1c18>
    8b58:	d1002321 	sub	x1, x25, #0x8
    8b5c:	9100233a 	add	x26, x25, #0x8
    8b60:	8b001037 	add	x23, x1, x0, lsl #4
    8b64:	d503201f 	nop
    8b68:	f9400740 	ldr	x0, [x26, #8]
    8b6c:	f9400f41 	ldr	x1, [x26, #24]
    8b70:	fd400340 	ldr	d0, [x26]
    8b74:	fd400b41 	ldr	d1, [x26, #16]
    8b78:	97fff23e 	bl	5470 <w120>
    8b7c:	a9000740 	stp	x0, x1, [x26]
    8b80:	9100435a 	add	x26, x26, #0x10
    8b84:	eb17035f 	cmp	x26, x23
    8b88:	54ffff01 	b.ne	8b68 <fwp_main_thread+0xb68>  // b.any
    8b8c:	aa1903f7 	mov	x23, x25
    8b90:	d37ffb18 	lsl	x24, x24, #1
    8b94:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    8b98:	d280001a 	mov	x26, #0x0                   	// #0
    8b9c:	f80106f8 	str	x24, [x23], #16
    8ba0:	f87a7ae2 	ldr	x2, [x23, x26, lsl #3]
    8ba4:	aa0303e0 	mov	x0, x3
    8ba8:	91000b5a 	add	x26, x26, #0x2
    8bac:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8bb0:	aa0303e1 	mov	x1, x3
    8bb4:	97fff17c 	bl	51a4 <fwp_p_ad_push>
    8bb8:	aa0003e3 	mov	x3, x0
    8bbc:	eb18035f 	cmp	x26, x24
    8bc0:	54ffff03 	b.cc	8ba0 <fwp_main_thread+0xba0>  // b.lo, b.ul, b.last
    8bc4:	f949db81 	ldr	x1, [x28, #5040]
    8bc8:	f949ef80 	ldr	x0, [x28, #5080]
    8bcc:	cb010321 	sub	x1, x25, x1
    8bd0:	eb00403f 	cmp	x1, x0, lsl #16
    8bd4:	540003a2 	b.cs	8c48 <fwp_main_thread+0xc48>  // b.hs, b.nlast
    8bd8:	d350fc20 	lsr	x0, x1, #16
    8bdc:	f949ff86 	ldr	x6, [x28, #5112]
    8be0:	8b000800 	add	x0, x0, x0, lsl #2
    8be4:	d37df000 	lsl	x0, x0, #3
    8be8:	8b0000c2 	add	x2, x6, x0
    8bec:	f9401057 	ldr	x23, [x2, #32]
    8bf0:	b40002d7 	cbz	x23, 8c48 <fwp_main_thread+0xc48>
    8bf4:	386068c0 	ldrb	w0, [x6, x0]
    8bf8:	7100081f 	cmp	w0, #0x2
    8bfc:	54008140 	b.eq	9c24 <fwp_main_thread+0x1c24>  // b.none
    8c00:	7100041f 	cmp	w0, #0x1
    8c04:	54000221 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    8c08:	29430045 	ldp	w5, w0, [x2, #24]
    8c0c:	92403c21 	and	x1, x1, #0xffff
    8c10:	9b057c21 	mul	x1, x1, x5
    8c14:	d360fc21 	lsr	x1, x1, #32
    8c18:	eb00003f 	cmp	x1, x0
    8c1c:	54000162 	b.cs	8c48 <fwp_main_thread+0xc48>  // b.hs, b.nlast
    8c20:	8b0102f7 	add	x23, x23, x1
    8c24:	394002e0 	ldrb	w0, [x23]
    8c28:	34000100 	cbz	w0, 8c48 <fwp_main_thread+0xc48>
    8c2c:	7100041f 	cmp	w0, #0x1
    8c30:	54003020 	b.eq	9234 <fwp_main_thread+0x1234>  // b.none
    8c34:	7103fc1f 	cmp	w0, #0xff
    8c38:	54009c80 	b.eq	9fc8 <fwp_main_thread+0x1fc8>  // b.none
    8c3c:	51000400 	sub	w0, w0, #0x1
    8c40:	390002e0 	strb	w0, [x23]
    8c44:	d503201f 	nop
    8c48:	52800040 	mov	w0, #0x2                   	// #2
    8c4c:	93407ed6 	sxtw	x22, w22
    8c50:	f90003e3 	str	x3, [sp]
    8c54:	97ffea87 	bl	3670 <descent_phase_step>
    8c58:	aa1603e0 	mov	x0, x22
    8c5c:	97ffebd5 	bl	3bb0 <fwp_tape_of>
    8c60:	f9403001 	ldr	x1, [x0, #96]
    8c64:	aa0003e7 	mov	x7, x0
    8c68:	f94003e3 	ldr	x3, [sp]
    8c6c:	b500b481 	cbnz	x1, a2fc <fwp_main_thread+0x22fc>
    8c70:	f9000be3 	str	x3, [sp, #16]
    8c74:	97ffe8e7 	bl	3010 <fwp_tape_unlink_scope>
    8c78:	a94288f8 	ldp	x24, x2, [x7, #40]
    8c7c:	f90003e2 	str	x2, [sp]
    8c80:	b94000e1 	ldr	w1, [x7]
    8c84:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8c88:	b90004ff 	str	wzr, [x7, #4]
    8c8c:	a940a0fa 	ldp	x26, x8, [x7, #8]
    8c90:	6b00003f 	cmp	w1, w0
    8c94:	f9400be3 	ldr	x3, [sp, #16]
    8c98:	a941dce9 	ldp	x9, x23, [x7, #24]
    8c9c:	a943e4fb 	ldp	x27, x25, [x7, #56]
    8ca0:	f94024e2 	ldr	x2, [x7, #72]
    8ca4:	54000108 	b.hi	8cc4 <fwp_main_thread+0xcc4>  // b.pmore
    8ca8:	9101c261 	add	x1, x19, #0x70
    8cac:	92403ec0 	and	x0, x22, #0xffff
    8cb0:	d1000400 	sub	x0, x0, #0x1
    8cb4:	f940742a 	ldr	x10, [x1, #232]
    8cb8:	eb0a001f 	cmp	x0, x10
    8cbc:	5400004a 	b.ge	8cc4 <fwp_main_thread+0xcc4>  // b.tcont
    8cc0:	f9007420 	str	x0, [x1, #232]
    8cc4:	4f000400 	movi	v0.4s, #0x0
    8cc8:	9101c261 	add	x1, x19, #0x70
    8ccc:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8cd0:	91100000 	add	x0, x0, #0x400
    8cd4:	f9000cff 	str	xzr, [x7, #24]
    8cd8:	f941882a 	ldr	x10, [x1, #784]
    8cdc:	3c8080e0 	stur	q0, [x7, #8]
    8ce0:	ad0100e0 	stp	q0, q0, [x7, #32]
    8ce4:	a9047cff 	stp	xzr, xzr, [x7, #64]
    8ce8:	a90703ea 	stp	x10, x0, [sp, #112]
    8cec:	f94007e0 	ldr	x0, [sp, #8]
    8cf0:	f90043e0 	str	x0, [sp, #128]
    8cf4:	f94003e0 	ldr	x0, [sp]
    8cf8:	f9004fe0 	str	x0, [sp, #152]
    8cfc:	f94013e0 	ldr	x0, [sp, #32]
    8d00:	a908e3f7 	stp	x23, x24, [sp, #136]
    8d04:	a90a67fb 	stp	x27, x25, [sp, #160]
    8d08:	a90b0be9 	stp	x9, x2, [sp, #176]
    8d0c:	f9018820 	str	x0, [x1, #784]
    8d10:	b7f88443 	tbnz	x3, #63, 9d98 <fwp_main_thread+0x1d98>
    8d14:	eb8382df 	cmp	x22, x3, asr #32
    8d18:	5400a581 	b.ne	a1c8 <fwp_main_thread+0x21c8>  // b.any
    8d1c:	92407c61 	and	x1, x3, #0xffffffff
    8d20:	eb23411f 	cmp	x8, w3, uxtw
    8d24:	5400a4cd 	b.le	a1bc <fwp_main_thread+0x21bc>
    8d28:	eb01035f 	cmp	x26, x1
    8d2c:	9a81c756 	csinc	x22, x26, x1, gt
    8d30:	eb16005f 	cmp	x2, x22
    8d34:	5400254a 	b.ge	91dc <fwp_main_thread+0x11dc>  // b.tcont
    8d38:	f100005f 	cmp	x2, #0x0
    8d3c:	9a961042 	csel	x2, x2, x22, ne	// ne = any
    8d40:	14000005 	b	8d54 <fwp_main_thread+0xd54>
    8d44:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8d48:	eb00005f 	cmp	x2, x0
    8d4c:	d37ff842 	lsl	x2, x2, #1
    8d50:	9a96d042 	csel	x2, x2, x22, le
    8d54:	eb16005f 	cmp	x2, x22
    8d58:	54ffff6b 	b.lt	8d44 <fwp_main_thread+0xd44>  // b.tstop
    8d5c:	f90023e3 	str	x3, [sp, #64]
    8d60:	b40089b9 	cbz	x25, 9e94 <fwp_main_thread+0x1e94>
    8d64:	aa1903e0 	mov	x0, x25
    8d68:	d37df041 	lsl	x1, x2, #3
    8d6c:	f9000be2 	str	x2, [sp, #16]
    8d70:	97ffe6e4 	bl	2900 <realloc@plt>
    8d74:	f9400be2 	ldr	x2, [sp, #16]
    8d78:	aa0003f9 	mov	x25, x0
    8d7c:	f94023e3 	ldr	x3, [sp, #64]
    8d80:	b400ab59 	cbz	x25, a2e8 <fwp_main_thread+0x22e8>
    8d84:	f90057f9 	str	x25, [sp, #168]
    8d88:	f9005fe2 	str	x2, [sp, #184]
    8d8c:	b50021b6 	cbnz	x22, 91c0 <fwp_main_thread+0x11c0>
    8d90:	b7f800c3 	tbnz	x3, #63, 8da8 <fwp_main_thread+0xda8>
    8d94:	92407c63 	and	x3, x3, #0xffffffff
    8d98:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8d9c:	fc637b20 	ldr	d0, [x25, x3, lsl #3]
    8da0:	1e612800 	fadd	d0, d0, d1
    8da4:	fc237b20 	str	d0, [x25, x3, lsl #3]
    8da8:	9101c261 	add	x1, x19, #0x70
    8dac:	cb1a02c3 	sub	x3, x22, x26
    8db0:	52800060 	mov	w0, #0x3                   	// #3
    8db4:	a9428827 	ldp	x7, x2, [x1, #40]
    8db8:	8b070063 	add	x3, x3, x7
    8dbc:	8b1a0042 	add	x2, x2, x26
    8dc0:	a9028823 	stp	x3, x2, [x1, #40]
    8dc4:	97ffea2b 	bl	3670 <descent_phase_step>
    8dc8:	d10006c1 	sub	x1, x22, #0x1
    8dcc:	d1000747 	sub	x7, x26, #0x1
    8dd0:	eb01035f 	cmp	x26, x1
    8dd4:	540003cc 	b.gt	8e4c <fwp_main_thread+0xe4c>
    8dd8:	fc617b20 	ldr	d0, [x25, x1, lsl #3]
    8ddc:	1e602008 	fcmp	d0, #0.0
    8de0:	54000300 	b.eq	8e40 <fwp_main_thread+0xe40>  // b.none
    8de4:	cb1a0be0 	neg	x0, x26, lsl #2
    8de8:	cb1a03e3 	neg	x3, x26
    8dec:	8b0002e2 	add	x2, x23, x0
    8df0:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8df4:	37f80122 	tbnz	w2, #31, 8e18 <fwp_main_thread+0xe18>
    8df8:	f94003e4 	ldr	x4, [sp]
    8dfc:	93407c42 	sxtw	x2, w2
    8e00:	8b030c88 	add	x8, x4, x3, lsl #3
    8e04:	fc627b21 	ldr	d1, [x25, x2, lsl #3]
    8e08:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8e0c:	1e620802 	fmul	d2, d0, d2
    8e10:	1e622821 	fadd	d1, d1, d2
    8e14:	fc227b21 	str	d1, [x25, x2, lsl #3]
    8e18:	8b000300 	add	x0, x24, x0
    8e1c:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8e20:	37f80100 	tbnz	w0, #31, 8e40 <fwp_main_thread+0xe40>
    8e24:	8b030f63 	add	x3, x27, x3, lsl #3
    8e28:	93407c00 	sxtw	x0, w0
    8e2c:	fc617862 	ldr	d2, [x3, x1, lsl #3]
    8e30:	fc607b21 	ldr	d1, [x25, x0, lsl #3]
    8e34:	1e620800 	fmul	d0, d0, d2
    8e38:	1e602820 	fadd	d0, d1, d0
    8e3c:	fc207b20 	str	d0, [x25, x0, lsl #3]
    8e40:	d1000421 	sub	x1, x1, #0x1
    8e44:	eb0100ff 	cmp	x7, x1
    8e48:	54fffc81 	b.ne	8dd8 <fwp_main_thread+0xdd8>  // b.any
    8e4c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8e50:	eb00035f 	cmp	x26, x0
    8e54:	5400a4e8 	b.hi	a2f0 <fwp_main_thread+0x22f0>  // b.pmore
    8e58:	91000740 	add	x0, x26, #0x1
    8e5c:	52800041 	mov	w1, #0x2                   	// #2
    8e60:	d37df000 	lsl	x0, x0, #3
    8e64:	97fff043 	bl	4f70 <fwp_heap_alloc>
    8e68:	aa0003e2 	mov	x2, x0
    8e6c:	aa0003f7 	mov	x23, x0
    8e70:	d2800001 	mov	x1, #0x0                   	// #0
    8e74:	f800845a 	str	x26, [x2], #8
    8e78:	b40000fa 	cbz	x26, 8e94 <fwp_main_thread+0xe94>
    8e7c:	d503201f 	nop
    8e80:	f8617b20 	ldr	x0, [x25, x1, lsl #3]
    8e84:	f8217840 	str	x0, [x2, x1, lsl #3]
    8e88:	91000421 	add	x1, x1, #0x1
    8e8c:	eb01035f 	cmp	x26, x1
    8e90:	54ffff81 	b.ne	8e80 <fwp_main_thread+0xe80>  // b.any
    8e94:	528000a0 	mov	w0, #0x5                   	// #5
    8e98:	97ffe9f6 	bl	3670 <descent_phase_step>
    8e9c:	f94007e0 	ldr	x0, [sp, #8]
    8ea0:	9101c261 	add	x1, x19, #0x70
    8ea4:	f9403bf8 	ldr	x24, [sp, #112]
    8ea8:	f9018838 	str	x24, [x1, #784]
    8eac:	97ffed55 	bl	4400 <fwp_tape_buffers_release>
    8eb0:	528000c0 	mov	w0, #0x6                   	// #6
    8eb4:	97ffe9ef 	bl	3670 <descent_phase_step>
    8eb8:	f949db81 	ldr	x1, [x28, #5040]
    8ebc:	f949ef80 	ldr	x0, [x28, #5080]
    8ec0:	cb0102e1 	sub	x1, x23, x1
    8ec4:	eb00403f 	cmp	x1, x0, lsl #16
    8ec8:	54000322 	b.cs	8f2c <fwp_main_thread+0xf2c>  // b.hs, b.nlast
    8ecc:	d350fc20 	lsr	x0, x1, #16
    8ed0:	f949ff83 	ldr	x3, [x28, #5112]
    8ed4:	8b000800 	add	x0, x0, x0, lsl #2
    8ed8:	d37df002 	lsl	x2, x0, #3
    8edc:	8b020060 	add	x0, x3, x2
    8ee0:	f9401016 	ldr	x22, [x0, #32]
    8ee4:	b4000256 	cbz	x22, 8f2c <fwp_main_thread+0xf2c>
    8ee8:	38626862 	ldrb	w2, [x3, x2]
    8eec:	7100085f 	cmp	w2, #0x2
    8ef0:	54007580 	b.eq	9da0 <fwp_main_thread+0x1da0>  // b.none
    8ef4:	7100045f 	cmp	w2, #0x1
    8ef8:	540001a1 	b.ne	8f2c <fwp_main_thread+0xf2c>  // b.any
    8efc:	29430002 	ldp	w2, w0, [x0, #24]
    8f00:	92403c21 	and	x1, x1, #0xffff
    8f04:	9b027c21 	mul	x1, x1, x2
    8f08:	d360fc21 	lsr	x1, x1, #32
    8f0c:	eb00003f 	cmp	x1, x0
    8f10:	540000e2 	b.cs	8f2c <fwp_main_thread+0xf2c>  // b.hs, b.nlast
    8f14:	8b0102d6 	add	x22, x22, x1
    8f18:	394002c0 	ldrb	w0, [x22]
    8f1c:	7103fc1f 	cmp	w0, #0xff
    8f20:	540074a0 	b.eq	9db4 <fwp_main_thread+0x1db4>  // b.none
    8f24:	52800020 	mov	w0, #0x1                   	// #1
    8f28:	390002c0 	strb	w0, [x22]
    8f2c:	f9401be0 	ldr	x0, [sp, #48]
    8f30:	eb00031f 	cmp	x24, x0
    8f34:	540092e1 	b.ne	a190 <fwp_main_thread+0x2190>  // b.any
    8f38:	f94017e0 	ldr	x0, [sp, #40]
    8f3c:	9101c261 	add	x1, x19, #0x70
    8f40:	f9402fe2 	ldr	x2, [sp, #88]
    8f44:	f9018822 	str	x2, [x1, #784]
    8f48:	97fff412 	bl	5f90 <fwp_tape_scope_release>
    8f4c:	f94002e0 	ldr	x0, [x23]
    8f50:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8f54:	b7f85de0 	tbnz	x0, #63, 9b10 <fwp_main_thread+0x1b10>
    8f58:	f949db80 	ldr	x0, [x28, #5040]
    8f5c:	f949ef81 	ldr	x1, [x28, #5080]
    8f60:	cb0002e0 	sub	x0, x23, x0
    8f64:	eb01401f 	cmp	x0, x1, lsl #16
    8f68:	54005d42 	b.cs	9b10 <fwp_main_thread+0x1b10>  // b.hs, b.nlast
    8f6c:	d350fc01 	lsr	x1, x0, #16
    8f70:	f949ff85 	ldr	x5, [x28, #5112]
    8f74:	8b010821 	add	x1, x1, x1, lsl #2
    8f78:	d37df021 	lsl	x1, x1, #3
    8f7c:	8b0100a3 	add	x3, x5, x1
    8f80:	f9401062 	ldr	x2, [x3, #32]
    8f84:	b4005c62 	cbz	x2, 9b10 <fwp_main_thread+0x1b10>
    8f88:	386168a1 	ldrb	w1, [x5, x1]
    8f8c:	7100083f 	cmp	w1, #0x2
    8f90:	54005ba0 	b.eq	9b04 <fwp_main_thread+0x1b04>  // b.none
    8f94:	7100043f 	cmp	w1, #0x1
    8f98:	54005bc1 	b.ne	9b10 <fwp_main_thread+0x1b10>  // b.any
    8f9c:	29430465 	ldp	w5, w1, [x3, #24]
    8fa0:	92403c00 	and	x0, x0, #0xffff
    8fa4:	9b057c00 	mul	x0, x0, x5
    8fa8:	d360fc00 	lsr	x0, x0, #32
    8fac:	eb01001f 	cmp	x0, x1
    8fb0:	54005b02 	b.cs	9b10 <fwp_main_thread+0x1b10>  // b.hs, b.nlast
    8fb4:	8b000042 	add	x2, x2, x0
    8fb8:	39400040 	ldrb	w0, [x2]
    8fbc:	7100041f 	cmp	w0, #0x1
    8fc0:	54005a81 	b.ne	9b10 <fwp_main_thread+0x1b10>  // b.any
    8fc4:	aa1703e5 	mov	x5, x23
    8fc8:	aa1703f6 	mov	x22, x23
    8fcc:	d2800000 	mov	x0, #0x0                   	// #0
    8fd0:	910022c3 	add	x3, x22, #0x8
    8fd4:	910022e7 	add	x7, x23, #0x8
    8fd8:	d2800001 	mov	x1, #0x0                   	// #0
    8fdc:	b5000158 	cbnz	x24, 9004 <fwp_main_thread+0x1004>
    8fe0:	140000b8 	b	92c0 <fwp_main_thread+0x12c0>
    8fe4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8fe8:	f94000a2 	ldr	x2, [x5]
    8fec:	1e600900 	fmul	d0, d8, d0
    8ff0:	b7f892e2 	tbnz	x2, #63, a24c <fwp_main_thread+0x224c>
    8ff4:	91000421 	add	x1, x1, #0x1
    8ff8:	fc008460 	str	d0, [x3], #8
    8ffc:	eb01031f 	cmp	x24, x1
    9000:	54001600 	b.eq	92c0 <fwp_main_thread+0x12c0>  // b.none
    9004:	f94002e6 	ldr	x6, [x23]
    9008:	aa0703e2 	mov	x2, x7
    900c:	b6fffec6 	tbz	x6, #63, 8fe4 <fwp_main_thread+0xfe4>
    9010:	f9400ae2 	ldr	x2, [x23, #16]
    9014:	17fffff4 	b	8fe4 <fwp_main_thread+0xfe4>
    9018:	f90042b4 	str	x20, [x21, #128]
    901c:	17fffc9b 	b	8288 <fwp_main_thread+0x288>
    9020:	f941b2c0 	ldr	x0, [x22, #864]
    9024:	b9035adf 	str	wzr, [x22, #856]
    9028:	b5008ae0 	cbnz	x0, a184 <fwp_main_thread+0x2184>
    902c:	9101c275 	add	x21, x19, #0x70
    9030:	97fff500 	bl	6430 <fwp_free_zombie>
    9034:	f94042a0 	ldr	x0, [x21, #128]
    9038:	b5008a60 	cbnz	x0, a184 <fwp_main_thread+0x2184>
    903c:	f9406ea0 	ldr	x0, [x21, #216]
    9040:	b5008a20 	cbnz	x0, a184 <fwp_main_thread+0x2184>
    9044:	b940faa0 	ldr	w0, [x21, #248]
    9048:	340001e0 	cbz	w0, 9084 <fwp_main_thread+0x1084>
    904c:	93407c16 	sxtw	x22, w0
    9050:	51000400 	sub	w0, w0, #0x1
    9054:	d1000ad6 	sub	x22, x22, #0x2
    9058:	910402b7 	add	x23, x21, #0x100
    905c:	cb2042d6 	sub	x22, x22, w0, uxtw
    9060:	93407c14 	sxtw	x20, w0
    9064:	d503201f 	nop
    9068:	f8747ae0 	ldr	x0, [x23, x20, lsl #3]
    906c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9070:	b900fab4 	str	w20, [x21, #248]
    9074:	d1000694 	sub	x20, x20, #0x1
    9078:	97ffe66e 	bl	2a30 <munmap@plt>
    907c:	eb16029f 	cmp	x20, x22
    9080:	54ffff41 	b.ne	9068 <fwp_main_thread+0x1068>  // b.any
    9084:	f00000b4 	adrp	x20, 20000 <__data_start>
    9088:	91004280 	add	x0, x20, #0x10
    908c:	b9404000 	ldr	w0, [x0, #64]
    9090:	37f80040 	tbnz	w0, #31, 9098 <fwp_main_thread+0x1098>
    9094:	97ffe623 	bl	2920 <close@plt>
    9098:	9101c260 	add	x0, x19, #0x70
    909c:	91004281 	add	x1, x20, #0x10
    90a0:	12800002 	mov	w2, #0xffffffff            	// #-1
    90a4:	d2800014 	mov	x20, #0x0                   	// #0
    90a8:	f941b416 	ldr	x22, [x0, #872]
    90ac:	b9004022 	str	w2, [x1, #64]
    90b0:	f941b815 	ldr	x21, [x0, #880]
    90b4:	b4000176 	cbz	x22, 90e0 <fwp_main_thread+0x10e0>
    90b8:	f8747aa0 	ldr	x0, [x21, x20, lsl #3]
    90bc:	b40000c0 	cbz	x0, 90d4 <fwp_main_thread+0x10d4>
    90c0:	f9400001 	ldr	x1, [x0]
    90c4:	b5008601 	cbnz	x1, a184 <fwp_main_thread+0x2184>
    90c8:	f9400401 	ldr	x1, [x0, #8]
    90cc:	b50085c1 	cbnz	x1, a184 <fwp_main_thread+0x2184>
    90d0:	97ffee88 	bl	4af0 <fwp_mem_free>
    90d4:	91000694 	add	x20, x20, #0x1
    90d8:	eb16029f 	cmp	x20, x22
    90dc:	54fffee1 	b.ne	90b8 <fwp_main_thread+0x10b8>  // b.any
    90e0:	aa1503e0 	mov	x0, x21
    90e4:	97ffee83 	bl	4af0 <fwp_mem_free>
    90e8:	9101c260 	add	x0, x19, #0x70
    90ec:	f941b014 	ldr	x20, [x0, #864]
    90f0:	f901b41f 	str	xzr, [x0, #872]
    90f4:	f901b81f 	str	xzr, [x0, #880]
    90f8:	b40001f4 	cbz	x20, 9134 <fwp_main_thread+0x1134>
    90fc:	f9401681 	ldr	x1, [x20, #40]
    9100:	b5008421 	cbnz	x1, a184 <fwp_main_thread+0x2184>
    9104:	f9405681 	ldr	x1, [x20, #168]
    9108:	b50083e1 	cbnz	x1, a184 <fwp_main_thread+0x2184>
    910c:	f9419401 	ldr	x1, [x0, #808]
    9110:	b50083a1 	cbnz	x1, a184 <fwp_main_thread+0x2184>
    9114:	f9419c00 	ldr	x0, [x0, #824]
    9118:	b5008360 	cbnz	x0, a184 <fwp_main_thread+0x2184>
    911c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9120:	f0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    9124:	910fc000 	add	x0, x0, #0x3f0
    9128:	97ffe5ee 	bl	28e0 <memset@plt>
    912c:	aa1403e0 	mov	x0, x20
    9130:	97ffee70 	bl	4af0 <fwp_mem_free>
    9134:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9138:	f947ec00 	ldr	x0, [x0, #4056]
    913c:	9101c273 	add	x19, x19, #0x70
    9140:	f9400000 	ldr	x0, [x0]
    9144:	f9000a7f 	str	xzr, [x19, #16]
    9148:	f901b27f 	str	xzr, [x19, #864]
    914c:	97ffe63d 	bl	2a40 <fflush@plt>
    9150:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9154:	f947f400 	ldr	x0, [x0, #4072]
    9158:	f940c7e2 	ldr	x2, [sp, #392]
    915c:	f9400001 	ldr	x1, [x0]
    9160:	eb010042 	subs	x2, x2, x1
    9164:	d2800001 	mov	x1, #0x0                   	// #0
    9168:	54008b81 	b.ne	a2d8 <fwp_main_thread+0x22d8>  // b.any
    916c:	a95c63f7 	ldp	x23, x24, [sp, #448]
    9170:	910643ff 	add	sp, sp, #0x190
    9174:	d2800000 	mov	x0, #0x0                   	// #0
    9178:	a94153f3 	ldp	x19, x20, [sp, #16]
    917c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9180:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9184:	d65f03c0 	ret
    9188:	72003c3f 	tst	w1, #0xffff
    918c:	54ff9721 	b.ne	8470 <fwp_main_thread+0x470>  // b.any
    9190:	394002e0 	ldrb	w0, [x23]
    9194:	7103fc1f 	cmp	w0, #0xff
    9198:	54ff96a1 	b.ne	846c <fwp_main_thread+0x46c>  // b.any
    919c:	aa1703e0 	mov	x0, x23
    91a0:	97ffedb4 	bl	4870 <fwp_rc_forget_slot>
    91a4:	17fffcb2 	b	846c <fwp_main_thread+0x46c>
    91a8:	f0ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    91ac:	91008000 	add	x0, x0, #0x20
    91b0:	9400061c 	bl	aa20 <atexit>
    91b4:	17fffba5 	b	8048 <fwp_main_thread+0x48>
    91b8:	97ffebf3 	bl	4184 <fwp_heap_init>
    91bc:	17fffb9f 	b	8038 <fwp_main_thread+0x38>
    91c0:	d37df2c2 	lsl	x2, x22, #3
    91c4:	aa1903e0 	mov	x0, x25
    91c8:	52800001 	mov	w1, #0x0                   	// #0
    91cc:	f9000be3 	str	x3, [sp, #16]
    91d0:	97ffe5c4 	bl	28e0 <memset@plt>
    91d4:	f9400be3 	ldr	x3, [sp, #16]
    91d8:	17fffeee 	b	8d90 <fwp_main_thread+0xd90>
    91dc:	f100033f 	cmp	x25, #0x0
    91e0:	1a9f17e0 	cset	w0, eq	// eq = none
    91e4:	f10002df 	cmp	x22, #0x0
    91e8:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    91ec:	54ffdd00 	b.eq	8d8c <fwp_main_thread+0xd8c>  // b.none
    91f0:	f94007e0 	ldr	x0, [sp, #8]
    91f4:	9101c273 	add	x19, x19, #0x70
    91f8:	f9403be1 	ldr	x1, [sp, #112]
    91fc:	f9018a61 	str	x1, [x19, #784]
    9200:	97ffec80 	bl	4400 <fwp_tape_buffers_release>
    9204:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9208:	f947e863 	ldr	x3, [x3, #4048]
    920c:	d2800262 	mov	x2, #0x13                  	// #19
    9210:	d2800021 	mov	x1, #0x1                   	// #1
    9214:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    9218:	91296000 	add	x0, x0, #0xa58
    921c:	f9400063 	ldr	x3, [x3]
    9220:	97ffe5fc 	bl	2a10 <fwrite@plt>
    9224:	d2800000 	mov	x0, #0x0                   	// #0
    9228:	97ffe606 	bl	2a40 <fflush@plt>
    922c:	52800cc0 	mov	w0, #0x66                  	// #102
    9230:	97ffe614 	bl	2a80 <_Exit@plt>
    9234:	f9400367 	ldr	x7, [x27]
    9238:	aa1b03e0 	mov	x0, x27
    923c:	f949ef85 	ldr	x5, [x28, #5080]
    9240:	f949db81 	ldr	x1, [x28, #5040]
    9244:	d370bca5 	lsl	x5, x5, #16
    9248:	cb010362 	sub	x2, x27, x1
    924c:	b7f84f87 	tbnz	x7, #63, 9c3c <fwp_main_thread+0x1c3c>
    9250:	eb05005f 	cmp	x2, x5
    9254:	54ffcfa2 	b.cs	8c48 <fwp_main_thread+0xc48>  // b.hs, b.nlast
    9258:	d350fc40 	lsr	x0, x2, #16
    925c:	8b000800 	add	x0, x0, x0, lsl #2
    9260:	d37df000 	lsl	x0, x0, #3
    9264:	8b0000c5 	add	x5, x6, x0
    9268:	f94010a1 	ldr	x1, [x5, #32]
    926c:	b4ffcee1 	cbz	x1, 8c48 <fwp_main_thread+0xc48>
    9270:	386068c0 	ldrb	w0, [x6, x0]
    9274:	7100081f 	cmp	w0, #0x2
    9278:	54005a40 	b.eq	9dc0 <fwp_main_thread+0x1dc0>  // b.none
    927c:	7100041f 	cmp	w0, #0x1
    9280:	54ffce41 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    9284:	92403c40 	and	x0, x2, #0xffff
    9288:	294308a6 	ldp	w6, w2, [x5, #24]
    928c:	9b067c00 	mul	x0, x0, x6
    9290:	d360fc00 	lsr	x0, x0, #32
    9294:	eb02001f 	cmp	x0, x2
    9298:	54ffcd82 	b.cs	8c48 <fwp_main_thread+0xc48>  // b.hs, b.nlast
    929c:	8b000021 	add	x1, x1, x0
    92a0:	39400020 	ldrb	w0, [x1]
    92a4:	7100041f 	cmp	w0, #0x1
    92a8:	54ffcd01 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    92ac:	aa1b03e0 	mov	x0, x27
    92b0:	f90003e3 	str	x3, [sp]
    92b4:	97ffee0f 	bl	4af0 <fwp_mem_free>
    92b8:	f94003e3 	ldr	x3, [sp]
    92bc:	17fffe63 	b	8c48 <fwp_main_thread+0xc48>
    92c0:	f90003e5 	str	x5, [sp]
    92c4:	97fff51f 	bl	6740 <fwp_drop10>
    92c8:	f94003e5 	ldr	x5, [sp]
    92cc:	aa1503e1 	mov	x1, x21
    92d0:	d2800002 	mov	x2, #0x0                   	// #0
    92d4:	b4005f75 	cbz	x21, 9ec0 <fwp_main_thread+0x1ec0>
    92d8:	f9400821 	ldr	x1, [x1, #16]
    92dc:	91000442 	add	x2, x2, #0x1
    92e0:	b5ffffc1 	cbnz	x1, 92d8 <fwp_main_thread+0x12d8>
    92e4:	f94000a0 	ldr	x0, [x5]
    92e8:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    92ec:	b7f83620 	tbnz	x0, #63, 99b0 <fwp_main_thread+0x19b0>
    92f0:	f949db81 	ldr	x1, [x28, #5040]
    92f4:	f949ef83 	ldr	x3, [x28, #5080]
    92f8:	cb0102c1 	sub	x1, x22, x1
    92fc:	eb03403f 	cmp	x1, x3, lsl #16
    9300:	54003582 	b.cs	99b0 <fwp_main_thread+0x19b0>  // b.hs, b.nlast
    9304:	d350fc23 	lsr	x3, x1, #16
    9308:	f949ff88 	ldr	x8, [x28, #5112]
    930c:	8b030863 	add	x3, x3, x3, lsl #2
    9310:	d37df063 	lsl	x3, x3, #3
    9314:	8b030107 	add	x7, x8, x3
    9318:	f94010e6 	ldr	x6, [x7, #32]
    931c:	b4003486 	cbz	x6, 99ac <fwp_main_thread+0x19ac>
    9320:	38636903 	ldrb	w3, [x8, x3]
    9324:	7100087f 	cmp	w3, #0x2
    9328:	540033e0 	b.eq	99a4 <fwp_main_thread+0x19a4>  // b.none
    932c:	7100047f 	cmp	w3, #0x1
    9330:	540033e1 	b.ne	99ac <fwp_main_thread+0x19ac>  // b.any
    9334:	29430ce8 	ldp	w8, w3, [x7, #24]
    9338:	92403c21 	and	x1, x1, #0xffff
    933c:	9b087c21 	mul	x1, x1, x8
    9340:	d360fc21 	lsr	x1, x1, #32
    9344:	eb03003f 	cmp	x1, x3
    9348:	54003322 	b.cs	99ac <fwp_main_thread+0x19ac>  // b.hs, b.nlast
    934c:	8b0100c6 	add	x6, x6, x1
    9350:	394000d7 	ldrb	w23, [x6]
    9354:	710006ff 	cmp	w23, #0x1
    9358:	540032a1 	b.ne	99ac <fwp_main_thread+0x19ac>  // b.any
    935c:	b90003f7 	str	w23, [sp]
    9360:	eb02033f 	cmp	x25, x2
    9364:	9a829339 	csel	x25, x25, x2, ls	// ls = plast
    9368:	910020bb 	add	x27, x5, #0x8
    936c:	b40069b9 	cbz	x25, a0a0 <fwp_main_thread+0x20a0>
    9370:	d37df327 	lsl	x7, x25, #3
    9374:	aa1503e2 	mov	x2, x21
    9378:	910022c6 	add	x6, x22, #0x8
    937c:	d2800001 	mov	x1, #0x0                   	// #0
    9380:	1400000a 	b	93a8 <fwp_main_thread+0x13a8>
    9384:	fc616861 	ldr	d1, [x3, x1]
    9388:	fd400440 	ldr	d0, [x2, #8]
    938c:	1e613800 	fsub	d0, d0, d1
    9390:	fc216b60 	str	d0, [x27, x1]
    9394:	91002021 	add	x1, x1, #0x8
    9398:	f9400842 	ldr	x2, [x2, #16]
    939c:	eb07003f 	cmp	x1, x7
    93a0:	540001a0 	b.eq	93d4 <fwp_main_thread+0x13d4>  // b.none
    93a4:	f94000a0 	ldr	x0, [x5]
    93a8:	aa0603e3 	mov	x3, x6
    93ac:	b6fffec0 	tbz	x0, #63, 9384 <fwp_main_thread+0x1384>
    93b0:	f9400ac3 	ldr	x3, [x22, #16]
    93b4:	fd400440 	ldr	d0, [x2, #8]
    93b8:	fc616861 	ldr	d1, [x3, x1]
    93bc:	1e613800 	fsub	d0, d0, d1
    93c0:	fc216b60 	str	d0, [x27, x1]
    93c4:	91002021 	add	x1, x1, #0x8
    93c8:	f9400842 	ldr	x2, [x2, #16]
    93cc:	eb07003f 	cmp	x1, x7
    93d0:	54fffea1 	b.ne	93a4 <fwp_main_thread+0x13a4>  // b.any
    93d4:	b4006b95 	cbz	x21, a144 <fwp_main_thread+0x2144>
    93d8:	f949ef88 	ldr	x8, [x28, #5080]
    93dc:	aa1503e6 	mov	x6, x21
    93e0:	f949db89 	ldr	x9, [x28, #5040]
    93e4:	d2800017 	mov	x23, #0x0                   	// #0
    93e8:	f949ff87 	ldr	x7, [x28, #5112]
    93ec:	d370bd08 	lsl	x8, x8, #16
    93f0:	14000006 	b	9408 <fwp_main_thread+0x1408>
    93f4:	f94008c6 	ldr	x6, [x6, #16]
    93f8:	910006f7 	add	x23, x23, #0x1
    93fc:	f10000df 	cmp	x6, #0x0
    9400:	fa571320 	ccmp	x25, x23, #0x0, ne	// ne = any
    9404:	54000329 	b.ls	9468 <fwp_main_thread+0x1468>  // b.plast
    9408:	cb0900c0 	sub	x0, x6, x9
    940c:	eb08001f 	cmp	x0, x8
    9410:	540002c2 	b.cs	9468 <fwp_main_thread+0x1468>  // b.hs, b.nlast
    9414:	d350fc01 	lsr	x1, x0, #16
    9418:	8b010821 	add	x1, x1, x1, lsl #2
    941c:	d37df021 	lsl	x1, x1, #3
    9420:	8b0100e5 	add	x5, x7, x1
    9424:	f94010a2 	ldr	x2, [x5, #32]
    9428:	b4000202 	cbz	x2, 9468 <fwp_main_thread+0x1468>
    942c:	386168e1 	ldrb	w1, [x7, x1]
    9430:	7100083f 	cmp	w1, #0x2
    9434:	54000d80 	b.eq	95e4 <fwp_main_thread+0x15e4>  // b.none
    9438:	7100043f 	cmp	w1, #0x1
    943c:	54000161 	b.ne	9468 <fwp_main_thread+0x1468>  // b.any
    9440:	294304aa 	ldp	w10, w1, [x5, #24]
    9444:	92403c00 	and	x0, x0, #0xffff
    9448:	9b0a7c00 	mul	x0, x0, x10
    944c:	d360fc00 	lsr	x0, x0, #32
    9450:	eb01001f 	cmp	x0, x1
    9454:	540000a2 	b.cs	9468 <fwp_main_thread+0x1468>  // b.hs, b.nlast
    9458:	8b000042 	add	x2, x2, x0
    945c:	39400040 	ldrb	w0, [x2]
    9460:	7100041f 	cmp	w0, #0x1
    9464:	54fffc80 	b.eq	93f4 <fwp_main_thread+0x13f4>  // b.none
    9468:	eb17033f 	cmp	x25, x23
    946c:	54000c69 	b.ls	95f8 <fwp_main_thread+0x15f8>  // b.plast
    9470:	d100237a 	sub	x26, x27, #0x8
    9474:	d2800018 	mov	x24, #0x0                   	// #0
    9478:	14000012 	b	94c0 <fwp_main_thread+0x14c0>
    947c:	7100045f 	cmp	w2, #0x1
    9480:	540001a1 	b.ne	94b4 <fwp_main_thread+0x14b4>  // b.any
    9484:	294308c7 	ldp	w7, w2, [x6, #24]
    9488:	92403c21 	and	x1, x1, #0xffff
    948c:	9b077c21 	mul	x1, x1, x7
    9490:	d360fc21 	lsr	x1, x1, #32
    9494:	eb02003f 	cmp	x1, x2
    9498:	540000e2 	b.cs	94b4 <fwp_main_thread+0x14b4>  // b.hs, b.nlast
    949c:	8b010000 	add	x0, x0, x1
    94a0:	39400001 	ldrb	w1, [x0]
    94a4:	7103fc3f 	cmp	w1, #0xff
    94a8:	54003ae0 	b.eq	9c04 <fwp_main_thread+0x1c04>  // b.none
    94ac:	52800021 	mov	w1, #0x1                   	// #1
    94b0:	39000001 	strb	w1, [x0]
    94b4:	d1000739 	sub	x25, x25, #0x1
    94b8:	eb1902ff 	cmp	x23, x25
    94bc:	54000362 	b.cs	9528 <fwp_main_thread+0x1528>  // b.hs, b.nlast
    94c0:	f8797b42 	ldr	x2, [x26, x25, lsl #3]
    94c4:	aa1403e1 	mov	x1, x20
    94c8:	52800020 	mov	w0, #0x1                   	// #1
    94cc:	a90f63e2 	stp	x2, x24, [sp, #240]
    94d0:	97ffeeed 	bl	5084 <fwp_data.part.0.constprop.0>
    94d4:	aa0003f8 	mov	x24, x0
    94d8:	f949db81 	ldr	x1, [x28, #5040]
    94dc:	f949ef80 	ldr	x0, [x28, #5080]
    94e0:	cb010301 	sub	x1, x24, x1
    94e4:	eb00403f 	cmp	x1, x0, lsl #16
    94e8:	54fffe62 	b.cs	94b4 <fwp_main_thread+0x14b4>  // b.hs, b.nlast
    94ec:	d350fc20 	lsr	x0, x1, #16
    94f0:	f949ff87 	ldr	x7, [x28, #5112]
    94f4:	8b000800 	add	x0, x0, x0, lsl #2
    94f8:	d37df002 	lsl	x2, x0, #3
    94fc:	8b0200e6 	add	x6, x7, x2
    9500:	f94010c0 	ldr	x0, [x6, #32]
    9504:	b4fffd80 	cbz	x0, 94b4 <fwp_main_thread+0x14b4>
    9508:	386268e2 	ldrb	w2, [x7, x2]
    950c:	7100085f 	cmp	w2, #0x2
    9510:	54fffb61 	b.ne	947c <fwp_main_thread+0x147c>  // b.any
    9514:	72003c3f 	tst	w1, #0xffff
    9518:	54fffc40 	b.eq	94a0 <fwp_main_thread+0x14a0>  // b.none
    951c:	d1000739 	sub	x25, x25, #0x1
    9520:	eb1902ff 	cmp	x23, x25
    9524:	54fffce3 	b.cc	94c0 <fwp_main_thread+0x14c0>  // b.lo, b.ul, b.last
    9528:	b50006b7 	cbnz	x23, 95fc <fwp_main_thread+0x15fc>
    952c:	b94003e0 	ldr	w0, [sp]
    9530:	d2800037 	mov	x23, #0x1                   	// #1
    9534:	d2800019 	mov	x25, #0x0                   	// #0
    9538:	7100001f 	cmp	w0, #0x0
    953c:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    9540:	b40004f9 	cbz	x25, 95dc <fwp_main_thread+0x15dc>
    9544:	d1000739 	sub	x25, x25, #0x1
    9548:	f8797b62 	ldr	x2, [x27, x25, lsl #3]
    954c:	aa1403e1 	mov	x1, x20
    9550:	52800020 	mov	w0, #0x1                   	// #1
    9554:	a90f63e2 	stp	x2, x24, [sp, #240]
    9558:	97ffeecb 	bl	5084 <fwp_data.part.0.constprop.0>
    955c:	aa0003f8 	mov	x24, x0
    9560:	f949db81 	ldr	x1, [x28, #5040]
    9564:	f949ef80 	ldr	x0, [x28, #5080]
    9568:	cb010301 	sub	x1, x24, x1
    956c:	eb00403f 	cmp	x1, x0, lsl #16
    9570:	54000302 	b.cs	95d0 <fwp_main_thread+0x15d0>  // b.hs, b.nlast
    9574:	d350fc22 	lsr	x2, x1, #16
    9578:	f949ff85 	ldr	x5, [x28, #5112]
    957c:	8b020842 	add	x2, x2, x2, lsl #2
    9580:	d37df042 	lsl	x2, x2, #3
    9584:	8b0200a3 	add	x3, x5, x2
    9588:	f940107a 	ldr	x26, [x3, #32]
    958c:	b400023a 	cbz	x26, 95d0 <fwp_main_thread+0x15d0>
    9590:	386268a2 	ldrb	w2, [x5, x2]
    9594:	7100085f 	cmp	w2, #0x2
    9598:	54002000 	b.eq	9998 <fwp_main_thread+0x1998>  // b.none
    959c:	7100045f 	cmp	w2, #0x1
    95a0:	54000181 	b.ne	95d0 <fwp_main_thread+0x15d0>  // b.any
    95a4:	29430865 	ldp	w5, w2, [x3, #24]
    95a8:	92403c21 	and	x1, x1, #0xffff
    95ac:	9b057c21 	mul	x1, x1, x5
    95b0:	d360fc21 	lsr	x1, x1, #32
    95b4:	eb02003f 	cmp	x1, x2
    95b8:	540000c2 	b.cs	95d0 <fwp_main_thread+0x15d0>  // b.hs, b.nlast
    95bc:	8b01035a 	add	x26, x26, x1
    95c0:	39400341 	ldrb	w1, [x26]
    95c4:	7103fc3f 	cmp	w1, #0xff
    95c8:	54001e20 	b.eq	998c <fwp_main_thread+0x198c>  // b.none
    95cc:	39000357 	strb	w23, [x26]
    95d0:	d1000739 	sub	x25, x25, #0x1
    95d4:	b100073f 	cmn	x25, #0x1
    95d8:	54fffb81 	b.ne	9548 <fwp_main_thread+0x1548>  // b.any
    95dc:	aa1503f9 	mov	x25, x21
    95e0:	14000015 	b	9634 <fwp_main_thread+0x1634>
    95e4:	72003c1f 	tst	w0, #0xffff
    95e8:	54fff3a0 	b.eq	945c <fwp_main_thread+0x145c>  // b.none
    95ec:	eb17033f 	cmp	x25, x23
    95f0:	54fff408 	b.hi	9470 <fwp_main_thread+0x1470>  // b.pmore
    95f4:	d503201f 	nop
    95f8:	d2800018 	mov	x24, #0x0                   	// #0
    95fc:	8b170f63 	add	x3, x27, x23, lsl #3
    9600:	aa1b03e0 	mov	x0, x27
    9604:	aa1503f9 	mov	x25, x21
    9608:	f8408401 	ldr	x1, [x0], #8
    960c:	f9000721 	str	x1, [x25, #8]
    9610:	aa1903e1 	mov	x1, x25
    9614:	f9400b39 	ldr	x25, [x25, #16]
    9618:	eb03001f 	cmp	x0, x3
    961c:	54ffff61 	b.ne	9608 <fwp_main_thread+0x1608>  // b.any
    9620:	b94003e0 	ldr	w0, [sp]
    9624:	f9000838 	str	x24, [x1, #16]
    9628:	aa1503f8 	mov	x24, x21
    962c:	7100001f 	cmp	w0, #0x0
    9630:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    9634:	aa1b03e0 	mov	x0, x27
    9638:	97ffed2e 	bl	4af0 <fwp_mem_free>
    963c:	f949ef82 	ldr	x2, [x28, #5080]
    9640:	f949db81 	ldr	x1, [x28, #5040]
    9644:	d370bc42 	lsl	x2, x2, #16
    9648:	cb0102c3 	sub	x3, x22, x1
    964c:	eb02007f 	cmp	x3, x2
    9650:	54000402 	b.cs	96d0 <fwp_main_thread+0x16d0>  // b.hs, b.nlast
    9654:	d350fc60 	lsr	x0, x3, #16
    9658:	f949ff85 	ldr	x5, [x28, #5112]
    965c:	8b000800 	add	x0, x0, x0, lsl #2
    9660:	d37df000 	lsl	x0, x0, #3
    9664:	8b0000a2 	add	x2, x5, x0
    9668:	f9401057 	ldr	x23, [x2, #32]
    966c:	b4001897 	cbz	x23, 997c <fwp_main_thread+0x197c>
    9670:	386068a1 	ldrb	w1, [x5, x0]
    9674:	7100083f 	cmp	w1, #0x2
    9678:	54002dc0 	b.eq	9c30 <fwp_main_thread+0x1c30>  // b.none
    967c:	7100043f 	cmp	w1, #0x1
    9680:	540017e1 	b.ne	997c <fwp_main_thread+0x197c>  // b.any
    9684:	29430846 	ldp	w6, w2, [x2, #24]
    9688:	92403c61 	and	x1, x3, #0xffff
    968c:	9b067c21 	mul	x1, x1, x6
    9690:	d360fc21 	lsr	x1, x1, #32
    9694:	eb02003f 	cmp	x1, x2
    9698:	54001722 	b.cs	997c <fwp_main_thread+0x197c>  // b.hs, b.nlast
    969c:	8b0102f7 	add	x23, x23, x1
    96a0:	394002e1 	ldrb	w1, [x23]
    96a4:	340016c1 	cbz	w1, 997c <fwp_main_thread+0x197c>
    96a8:	7100043f 	cmp	w1, #0x1
    96ac:	54001280 	b.eq	98fc <fwp_main_thread+0x18fc>  // b.none
    96b0:	7103fc3f 	cmp	w1, #0xff
    96b4:	54004540 	b.eq	9f5c <fwp_main_thread+0x1f5c>  // b.none
    96b8:	51000421 	sub	w1, w1, #0x1
    96bc:	390002e1 	strb	w1, [x23]
    96c0:	f949ef82 	ldr	x2, [x28, #5080]
    96c4:	f949db81 	ldr	x1, [x28, #5040]
    96c8:	d370bc42 	lsl	x2, x2, #16
    96cc:	d503201f 	nop
    96d0:	cb010321 	sub	x1, x25, x1
    96d4:	eb02003f 	cmp	x1, x2
    96d8:	54000382 	b.cs	9748 <fwp_main_thread+0x1748>  // b.hs, b.nlast
    96dc:	d350fc20 	lsr	x0, x1, #16
    96e0:	f949ff83 	ldr	x3, [x28, #5112]
    96e4:	8b000800 	add	x0, x0, x0, lsl #2
    96e8:	d37df000 	lsl	x0, x0, #3
    96ec:	8b000062 	add	x2, x3, x0
    96f0:	f9401056 	ldr	x22, [x2, #32]
    96f4:	b40002b6 	cbz	x22, 9748 <fwp_main_thread+0x1748>
    96f8:	38606865 	ldrb	w5, [x3, x0]
    96fc:	710008bf 	cmp	w5, #0x2
    9700:	54002e20 	b.eq	9cc4 <fwp_main_thread+0x1cc4>  // b.none
    9704:	710004bf 	cmp	w5, #0x1
    9708:	54000201 	b.ne	9748 <fwp_main_thread+0x1748>  // b.any
    970c:	29430845 	ldp	w5, w2, [x2, #24]
    9710:	92403c21 	and	x1, x1, #0xffff
    9714:	9b057c21 	mul	x1, x1, x5
    9718:	d360fc21 	lsr	x1, x1, #32
    971c:	eb02003f 	cmp	x1, x2
    9720:	54000142 	b.cs	9748 <fwp_main_thread+0x1748>  // b.hs, b.nlast
    9724:	8b0102d6 	add	x22, x22, x1
    9728:	394002c1 	ldrb	w1, [x22]
    972c:	340000e1 	cbz	w1, 9748 <fwp_main_thread+0x1748>
    9730:	7100043f 	cmp	w1, #0x1
    9734:	540034c0 	b.eq	9dcc <fwp_main_thread+0x1dcc>  // b.none
    9738:	7103fc3f 	cmp	w1, #0xff
    973c:	54004780 	b.eq	a02c <fwp_main_thread+0x202c>  // b.none
    9740:	51000421 	sub	w1, w1, #0x1
    9744:	390002c1 	strb	w1, [x22]
    9748:	f94007e0 	ldr	x0, [sp, #8]
    974c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x11480>
    9750:	910aa042 	add	x2, x2, #0x2a8
    9754:	aa1803e1 	mov	x1, x24
    9758:	91014042 	add	x2, x2, #0x50
    975c:	52800023 	mov	w3, #0x1                   	// #1
    9760:	a908ffff 	stp	xzr, xzr, [sp, #136]
    9764:	f9004fff 	str	xzr, [sp, #152]
    9768:	97fff62b 	bl	7014 <fwp_write>
    976c:	a948e7f7 	ldp	x23, x25, [sp, #136]
    9770:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    9774:	91168000 	add	x0, x0, #0x5a0
    9778:	f10002ff 	cmp	x23, #0x0
    977c:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    9780:	b1002b3f 	cmn	x25, #0xa
    9784:	540058e8 	b.hi	a2a0 <fwp_main_thread+0x22a0>  // b.pmore
    9788:	91002720 	add	x0, x25, #0x9
    978c:	52800021 	mov	w1, #0x1                   	// #1
    9790:	97ffedf8 	bl	4f70 <fwp_heap_alloc>
    9794:	aa0003fb 	mov	x27, x0
    9798:	aa0003f6 	mov	x22, x0
    979c:	aa1903e2 	mov	x2, x25
    97a0:	aa1703e1 	mov	x1, x23
    97a4:	f8008779 	str	x25, [x27], #8
    97a8:	8b1902d9 	add	x25, x22, x25
    97ac:	aa1b03e0 	mov	x0, x27
    97b0:	97ffe3ec 	bl	2760 <memcpy@plt>
    97b4:	3900233f 	strb	wzr, [x25, #8]
    97b8:	f94047e0 	ldr	x0, [sp, #136]
    97bc:	97ffe485 	bl	29d0 <free@plt>
    97c0:	f949db82 	ldr	x2, [x28, #5040]
    97c4:	f949ef80 	ldr	x0, [x28, #5080]
    97c8:	cb0202c2 	sub	x2, x22, x2
    97cc:	eb00405f 	cmp	x2, x0, lsl #16
    97d0:	54000322 	b.cs	9834 <fwp_main_thread+0x1834>  // b.hs, b.nlast
    97d4:	d350fc40 	lsr	x0, x2, #16
    97d8:	f949ff83 	ldr	x3, [x28, #5112]
    97dc:	8b000800 	add	x0, x0, x0, lsl #2
    97e0:	d37df001 	lsl	x1, x0, #3
    97e4:	8b010060 	add	x0, x3, x1
    97e8:	f9401017 	ldr	x23, [x0, #32]
    97ec:	b4000257 	cbz	x23, 9834 <fwp_main_thread+0x1834>
    97f0:	38616861 	ldrb	w1, [x3, x1]
    97f4:	7100083f 	cmp	w1, #0x2
    97f8:	54004480 	b.eq	a088 <fwp_main_thread+0x2088>  // b.none
    97fc:	7100043f 	cmp	w1, #0x1
    9800:	540001a1 	b.ne	9834 <fwp_main_thread+0x1834>  // b.any
    9804:	29430003 	ldp	w3, w0, [x0, #24]
    9808:	92403c41 	and	x1, x2, #0xffff
    980c:	9b037c21 	mul	x1, x1, x3
    9810:	d360fc21 	lsr	x1, x1, #32
    9814:	eb00003f 	cmp	x1, x0
    9818:	540000e2 	b.cs	9834 <fwp_main_thread+0x1834>  // b.hs, b.nlast
    981c:	8b0102f7 	add	x23, x23, x1
    9820:	394002e0 	ldrb	w0, [x23]
    9824:	7103fc1f 	cmp	w0, #0xff
    9828:	54004920 	b.eq	a14c <fwp_main_thread+0x214c>  // b.none
    982c:	52800020 	mov	w0, #0x1                   	// #1
    9830:	390002e0 	strb	w0, [x23]
    9834:	9101c277 	add	x23, x19, #0x70
    9838:	aa1803e0 	mov	x0, x24
    983c:	97fff04d 	bl	5970 <fwp_drop0>
    9840:	f94002c2 	ldr	x2, [x22]
    9844:	d2800021 	mov	x1, #0x1                   	// #1
    9848:	f94006e3 	ldr	x3, [x23, #8]
    984c:	aa1b03e0 	mov	x0, x27
    9850:	97ffe470 	bl	2a10 <fwrite@plt>
    9854:	f94006e1 	ldr	x1, [x23, #8]
    9858:	52800140 	mov	w0, #0xa                   	// #10
    985c:	97ffe3f5 	bl	2830 <fputc@plt>
    9860:	f949db82 	ldr	x2, [x28, #5040]
    9864:	f949ef80 	ldr	x0, [x28, #5080]
    9868:	cb0202c2 	sub	x2, x22, x2
    986c:	eb00405f 	cmp	x2, x0, lsl #16
    9870:	54000382 	b.cs	98e0 <fwp_main_thread+0x18e0>  // b.hs, b.nlast
    9874:	d350fc40 	lsr	x0, x2, #16
    9878:	f949ff83 	ldr	x3, [x28, #5112]
    987c:	8b000800 	add	x0, x0, x0, lsl #2
    9880:	d37df001 	lsl	x1, x0, #3
    9884:	8b010060 	add	x0, x3, x1
    9888:	f9401017 	ldr	x23, [x0, #32]
    988c:	b40002b7 	cbz	x23, 98e0 <fwp_main_thread+0x18e0>
    9890:	38616861 	ldrb	w1, [x3, x1]
    9894:	7100083f 	cmp	w1, #0x2
    9898:	54003fe0 	b.eq	a094 <fwp_main_thread+0x2094>  // b.none
    989c:	7100043f 	cmp	w1, #0x1
    98a0:	54000201 	b.ne	98e0 <fwp_main_thread+0x18e0>  // b.any
    98a4:	29430003 	ldp	w3, w0, [x0, #24]
    98a8:	92403c41 	and	x1, x2, #0xffff
    98ac:	9b037c21 	mul	x1, x1, x3
    98b0:	d360fc21 	lsr	x1, x1, #32
    98b4:	eb00003f 	cmp	x1, x0
    98b8:	54000142 	b.cs	98e0 <fwp_main_thread+0x18e0>  // b.hs, b.nlast
    98bc:	8b0102f7 	add	x23, x23, x1
    98c0:	394002e0 	ldrb	w0, [x23]
    98c4:	340000e0 	cbz	w0, 98e0 <fwp_main_thread+0x18e0>
    98c8:	7100041f 	cmp	w0, #0x1
    98cc:	54003180 	b.eq	9efc <fwp_main_thread+0x1efc>  // b.none
    98d0:	7103fc1f 	cmp	w0, #0xff
    98d4:	540048e0 	b.eq	a1f0 <fwp_main_thread+0x21f0>  // b.none
    98d8:	51000400 	sub	w0, w0, #0x1
    98dc:	390002e0 	strb	w0, [x23]
    98e0:	f94027e0 	ldr	x0, [sp, #72]
    98e4:	f9400800 	ldr	x0, [x0, #16]
    98e8:	f90027e0 	str	x0, [sp, #72]
    98ec:	b4003140 	cbz	x0, 9f14 <fwp_main_thread+0x1f14>
    98f0:	9101c260 	add	x0, x19, #0x70
    98f4:	f9418816 	ldr	x22, [x0, #784]
    98f8:	17fffb66 	b	8690 <fwp_main_thread+0x690>
    98fc:	f94002c3 	ldr	x3, [x22]
    9900:	aa1603e0 	mov	x0, x22
    9904:	f949ef82 	ldr	x2, [x28, #5080]
    9908:	f949db81 	ldr	x1, [x28, #5040]
    990c:	d370bc42 	lsl	x2, x2, #16
    9910:	cb0102c8 	sub	x8, x22, x1
    9914:	b7f81de3 	tbnz	x3, #63, 9cd0 <fwp_main_thread+0x1cd0>
    9918:	eb08005f 	cmp	x2, x8
    991c:	54ffeda9 	b.ls	96d0 <fwp_main_thread+0x16d0>  // b.plast
    9920:	d350fd03 	lsr	x3, x8, #16
    9924:	8b030863 	add	x3, x3, x3, lsl #2
    9928:	d37df063 	lsl	x3, x3, #3
    992c:	8b0300a7 	add	x7, x5, x3
    9930:	f94010e6 	ldr	x6, [x7, #32]
    9934:	b4ffece6 	cbz	x6, 96d0 <fwp_main_thread+0x16d0>
    9938:	386368a3 	ldrb	w3, [x5, x3]
    993c:	7100087f 	cmp	w3, #0x2
    9940:	54002920 	b.eq	9e64 <fwp_main_thread+0x1e64>  // b.none
    9944:	7100047f 	cmp	w3, #0x1
    9948:	54ffec41 	b.ne	96d0 <fwp_main_thread+0x16d0>  // b.any
    994c:	29430ce5 	ldp	w5, w3, [x7, #24]
    9950:	92403d00 	and	x0, x8, #0xffff
    9954:	9b057c00 	mul	x0, x0, x5
    9958:	d360fc00 	lsr	x0, x0, #32
    995c:	eb03001f 	cmp	x0, x3
    9960:	54ffeb82 	b.cs	96d0 <fwp_main_thread+0x16d0>  // b.hs, b.nlast
    9964:	8b0000c6 	add	x6, x6, x0
    9968:	394000c0 	ldrb	w0, [x6]
    996c:	7100041f 	cmp	w0, #0x1
    9970:	54ffeb01 	b.ne	96d0 <fwp_main_thread+0x16d0>  // b.any
    9974:	aa1603e0 	mov	x0, x22
    9978:	97ffec5e 	bl	4af0 <fwp_mem_free>
    997c:	f949ef82 	ldr	x2, [x28, #5080]
    9980:	f949db81 	ldr	x1, [x28, #5040]
    9984:	d370bc42 	lsl	x2, x2, #16
    9988:	17ffff52 	b	96d0 <fwp_main_thread+0x16d0>
    998c:	aa1a03e0 	mov	x0, x26
    9990:	97ffebb8 	bl	4870 <fwp_rc_forget_slot>
    9994:	17ffff0e 	b	95cc <fwp_main_thread+0x15cc>
    9998:	72003c3f 	tst	w1, #0xffff
    999c:	54ffe1a1 	b.ne	95d0 <fwp_main_thread+0x15d0>  // b.any
    99a0:	17ffff08 	b	95c0 <fwp_main_thread+0x15c0>
    99a4:	72003c3f 	tst	w1, #0xffff
    99a8:	54ffcd40 	b.eq	9350 <fwp_main_thread+0x1350>  // b.none
    99ac:	b4001055 	cbz	x21, 9bb4 <fwp_main_thread+0x1bb4>
    99b0:	aa1503f7 	mov	x23, x21
    99b4:	d2800018 	mov	x24, #0x0                   	// #0
    99b8:	f9400af7 	ldr	x23, [x23, #16]
    99bc:	aa1803e0 	mov	x0, x24
    99c0:	91000718 	add	x24, x24, #0x1
    99c4:	b5ffffb7 	cbnz	x23, 99b8 <fwp_main_thread+0x19b8>
    99c8:	f90003e5 	str	x5, [sp]
    99cc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    99d0:	eb01031f 	cmp	x24, x1
    99d4:	54004428 	b.hi	a258 <fwp_main_thread+0x2258>  // b.pmore
    99d8:	91000800 	add	x0, x0, #0x2
    99dc:	52800041 	mov	w1, #0x2                   	// #2
    99e0:	d37df000 	lsl	x0, x0, #3
    99e4:	97ffed63 	bl	4f70 <fwp_heap_alloc>
    99e8:	f94003e5 	ldr	x5, [sp]
    99ec:	eb19031f 	cmp	x24, x25
    99f0:	9a999319 	csel	x25, x24, x25, ls	// ls = plast
    99f4:	aa0003fb 	mov	x27, x0
    99f8:	aa1503e1 	mov	x1, x21
    99fc:	d503201f 	nop
    9a00:	f9400420 	ldr	x0, [x1, #8]
    9a04:	f8377b60 	str	x0, [x27, x23, lsl #3]
    9a08:	910006f7 	add	x23, x23, #0x1
    9a0c:	f9400821 	ldr	x1, [x1, #16]
    9a10:	b5ffff81 	cbnz	x1, 9a00 <fwp_main_thread+0x1a00>
    9a14:	b4000d99 	cbz	x25, 9bc4 <fwp_main_thread+0x1bc4>
    9a18:	f94000a0 	ldr	x0, [x5]
    9a1c:	b90003ff 	str	wzr, [sp]
    9a20:	17fffe54 	b	9370 <fwp_main_thread+0x1370>
    9a24:	d53bd040 	mrs	x0, tpidr_el0
    9a28:	91400000 	add	x0, x0, #0x0, lsl #12
    9a2c:	91004000 	add	x0, x0, #0x10
    9a30:	f9400000 	ldr	x0, [x0]
    9a34:	b40018e0 	cbz	x0, 9d50 <fwp_main_thread+0x1d50>
    9a38:	f9401fe1 	ldr	x1, [sp, #56]
    9a3c:	97ffe7aa 	bl	38e4 <fwp_closure_drop_push>
    9a40:	b5ff6ff5 	cbnz	x21, 883c <fwp_main_thread+0x83c>
    9a44:	9101c277 	add	x23, x19, #0x70
    9a48:	52800000 	mov	w0, #0x0                   	// #0
    9a4c:	97ffe709 	bl	3670 <descent_phase_step>
    9a50:	d2800016 	mov	x22, #0x0                   	// #0
    9a54:	b9434ee0 	ldr	w0, [x23, #844]
    9a58:	35ff70e0 	cbnz	w0, 8874 <fwp_main_thread+0x874>
    9a5c:	d503201f 	nop
    9a60:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    9a64:	913a4000 	add	x0, x0, #0xe90
    9a68:	940003ee 	bl	aa20 <atexit>
    9a6c:	35ffbcc0 	cbnz	w0, 9204 <fwp_main_thread+0x1204>
    9a70:	52800020 	mov	w0, #0x1                   	// #1
    9a74:	b9034ee0 	str	w0, [x23, #844]
    9a78:	9101c260 	add	x0, x19, #0x70
    9a7c:	f9404818 	ldr	x24, [x0, #144]
    9a80:	f9407417 	ldr	x23, [x0, #232]
    9a84:	eb1802ff 	cmp	x23, x24
    9a88:	54ff700b 	b.lt	8888 <fwp_main_thread+0x888>  // b.tstop
    9a8c:	d503201f 	nop
    9a90:	eb1802ff 	cmp	x23, x24
    9a94:	54ff7180 	b.eq	88c4 <fwp_main_thread+0x8c4>  // b.none
    9a98:	f9403a79 	ldr	x25, [x19, #112]
    9a9c:	8b1706f8 	add	x24, x23, x23, lsl #1
    9aa0:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    9aa4:	91350000 	add	x0, x0, #0xd40
    9aa8:	8b180af8 	add	x24, x23, x24, lsl #2
    9aac:	8b180f38 	add	x24, x25, x24, lsl #3
    9ab0:	f900331f 	str	xzr, [x24, #96]
    9ab4:	97ffe3fb 	bl	2aa0 <getenv@plt>
    9ab8:	b5ff75a0 	cbnz	x0, 896c <fwp_main_thread+0x96c>
    9abc:	9101c260 	add	x0, x19, #0x70
    9ac0:	f9406801 	ldr	x1, [x0, #208]
    9ac4:	b4ff75e1 	cbz	x1, 8980 <fwp_main_thread+0x980>
    9ac8:	3cc98002 	ldur	q2, [x0, #152]
    9acc:	91026001 	add	x1, x0, #0x98
    9ad0:	3cca8001 	ldur	q1, [x0, #168]
    9ad4:	f900681f 	str	xzr, [x0, #208]
    9ad8:	4f000400 	movi	v0.4s, #0x0
    9adc:	ad010702 	stp	q2, q1, [x24, #32]
    9ae0:	a94b8002 	ldp	x2, x0, [x0, #184]
    9ae4:	f9000f00 	str	x0, [x24, #24]
    9ae8:	f9401820 	ldr	x0, [x1, #48]
    9aec:	f9002302 	str	x2, [x24, #64]
    9af0:	f9002700 	str	x0, [x24, #72]
    9af4:	ad000020 	stp	q0, q0, [x1]
    9af8:	3d800820 	str	q0, [x1, #32]
    9afc:	f900183f 	str	xzr, [x1, #48]
    9b00:	17fffba0 	b	8980 <fwp_main_thread+0x980>
    9b04:	72003c1f 	tst	w0, #0xffff
    9b08:	54ffa580 	b.eq	8fb8 <fwp_main_thread+0xfb8>  // b.none
    9b0c:	d503201f 	nop
    9b10:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9b14:	eb00031f 	cmp	x24, x0
    9b18:	54003ec8 	b.hi	a2f0 <fwp_main_thread+0x22f0>  // b.pmore
    9b1c:	91000700 	add	x0, x24, #0x1
    9b20:	52800021 	mov	w1, #0x1                   	// #1
    9b24:	d37df000 	lsl	x0, x0, #3
    9b28:	97ffed12 	bl	4f70 <fwp_heap_alloc>
    9b2c:	f9000018 	str	x24, [x0]
    9b30:	aa0003e5 	mov	x5, x0
    9b34:	aa0003f6 	mov	x22, x0
    9b38:	f949db81 	ldr	x1, [x28, #5040]
    9b3c:	f949ef80 	ldr	x0, [x28, #5080]
    9b40:	cb0100a1 	sub	x1, x5, x1
    9b44:	eb00403f 	cmp	x1, x0, lsl #16
    9b48:	54000322 	b.cs	9bac <fwp_main_thread+0x1bac>  // b.hs, b.nlast
    9b4c:	d350fc20 	lsr	x0, x1, #16
    9b50:	f949ff83 	ldr	x3, [x28, #5112]
    9b54:	8b000800 	add	x0, x0, x0, lsl #2
    9b58:	d37df002 	lsl	x2, x0, #3
    9b5c:	8b020060 	add	x0, x3, x2
    9b60:	f9401019 	ldr	x25, [x0, #32]
    9b64:	b4000259 	cbz	x25, 9bac <fwp_main_thread+0x1bac>
    9b68:	38626862 	ldrb	w2, [x3, x2]
    9b6c:	7100085f 	cmp	w2, #0x2
    9b70:	54001800 	b.eq	9e70 <fwp_main_thread+0x1e70>  // b.none
    9b74:	7100045f 	cmp	w2, #0x1
    9b78:	540001a1 	b.ne	9bac <fwp_main_thread+0x1bac>  // b.any
    9b7c:	29430002 	ldp	w2, w0, [x0, #24]
    9b80:	92403c21 	and	x1, x1, #0xffff
    9b84:	9b027c21 	mul	x1, x1, x2
    9b88:	d360fc21 	lsr	x1, x1, #32
    9b8c:	eb00003f 	cmp	x1, x0
    9b90:	540000e2 	b.cs	9bac <fwp_main_thread+0x1bac>  // b.hs, b.nlast
    9b94:	8b010339 	add	x25, x25, x1
    9b98:	39400320 	ldrb	w0, [x25]
    9b9c:	7103fc1f 	cmp	w0, #0xff
    9ba0:	54001700 	b.eq	9e80 <fwp_main_thread+0x1e80>  // b.none
    9ba4:	52800020 	mov	w0, #0x1                   	// #1
    9ba8:	39000320 	strb	w0, [x25]
    9bac:	aa1703e0 	mov	x0, x23
    9bb0:	17fffd08 	b	8fd0 <fwp_main_thread+0xfd0>
    9bb4:	52800041 	mov	w1, #0x2                   	// #2
    9bb8:	d2800100 	mov	x0, #0x8                   	// #8
    9bbc:	97ffeced 	bl	4f70 <fwp_heap_alloc>
    9bc0:	aa0003fb 	mov	x27, x0
    9bc4:	aa1503f9 	mov	x25, x21
    9bc8:	d2800018 	mov	x24, #0x0                   	// #0
    9bcc:	17fffe9a 	b	9634 <fwp_main_thread+0x1634>
    9bd0:	52800041 	mov	w1, #0x2                   	// #2
    9bd4:	d2800100 	mov	x0, #0x8                   	// #8
    9bd8:	97ffece6 	bl	4f70 <fwp_heap_alloc>
    9bdc:	f900001f 	str	xzr, [x0]
    9be0:	aa0003f9 	mov	x25, x0
    9be4:	aa0003fb 	mov	x27, x0
    9be8:	f949db81 	ldr	x1, [x28, #5040]
    9bec:	f949ef80 	ldr	x0, [x28, #5080]
    9bf0:	cb010321 	sub	x1, x25, x1
    9bf4:	eb00403f 	cmp	x1, x0, lsl #16
    9bf8:	54000102 	b.cs	9c18 <fwp_main_thread+0x1c18>  // b.hs, b.nlast
    9bfc:	d2800017 	mov	x23, #0x0                   	// #0
    9c00:	17fffba4 	b	8a90 <fwp_main_thread+0xa90>
    9c04:	f9000be0 	str	x0, [sp, #16]
    9c08:	97ffeb1a 	bl	4870 <fwp_rc_forget_slot>
    9c0c:	f9400be0 	ldr	x0, [sp, #16]
    9c10:	17fffe27 	b	94ac <fwp_main_thread+0x14ac>
    9c14:	b5ff7717 	cbnz	x23, 8af4 <fwp_main_thread+0xaf4>
    9c18:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    9c1c:	f900033f 	str	xzr, [x25]
    9c20:	17fffbe9 	b	8bc4 <fwp_main_thread+0xbc4>
    9c24:	72003c3f 	tst	w1, #0xffff
    9c28:	54ff8101 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    9c2c:	17fffbfe 	b	8c24 <fwp_main_thread+0xc24>
    9c30:	72003c7f 	tst	w3, #0xffff
    9c34:	54ffea41 	b.ne	997c <fwp_main_thread+0x197c>  // b.any
    9c38:	17fffe9a 	b	96a0 <fwp_main_thread+0x16a0>
    9c3c:	f940077b 	ldr	x27, [x27, #8]
    9c40:	eb05005f 	cmp	x2, x5
    9c44:	54000382 	b.cs	9cb4 <fwp_main_thread+0x1cb4>  // b.hs, b.nlast
    9c48:	d350fc47 	lsr	x7, x2, #16
    9c4c:	8b0708e7 	add	x7, x7, x7, lsl #2
    9c50:	d37df0e7 	lsl	x7, x7, #3
    9c54:	8b0700c9 	add	x9, x6, x7
    9c58:	f9401128 	ldr	x8, [x9, #32]
    9c5c:	b40002c8 	cbz	x8, 9cb4 <fwp_main_thread+0x1cb4>
    9c60:	386768c6 	ldrb	w6, [x6, x7]
    9c64:	710008df 	cmp	w6, #0x2
    9c68:	54001440 	b.eq	9ef0 <fwp_main_thread+0x1ef0>  // b.none
    9c6c:	710004df 	cmp	w6, #0x1
    9c70:	54000221 	b.ne	9cb4 <fwp_main_thread+0x1cb4>  // b.any
    9c74:	29431927 	ldp	w7, w6, [x9, #24]
    9c78:	92403c42 	and	x2, x2, #0xffff
    9c7c:	9b077c42 	mul	x2, x2, x7
    9c80:	d360fc42 	lsr	x2, x2, #32
    9c84:	eb06005f 	cmp	x2, x6
    9c88:	54000162 	b.cs	9cb4 <fwp_main_thread+0x1cb4>  // b.hs, b.nlast
    9c8c:	8b020108 	add	x8, x8, x2
    9c90:	39400102 	ldrb	w2, [x8]
    9c94:	7100045f 	cmp	w2, #0x1
    9c98:	540000e1 	b.ne	9cb4 <fwp_main_thread+0x1cb4>  // b.any
    9c9c:	f90003e3 	str	x3, [sp]
    9ca0:	97ffeb94 	bl	4af0 <fwp_mem_free>
    9ca4:	f949ef85 	ldr	x5, [x28, #5080]
    9ca8:	f94003e3 	ldr	x3, [sp]
    9cac:	f949db81 	ldr	x1, [x28, #5040]
    9cb0:	d370bca5 	lsl	x5, x5, #16
    9cb4:	cb010361 	sub	x1, x27, x1
    9cb8:	eb0100bf 	cmp	x5, x1
    9cbc:	54ff78e8 	b.hi	8bd8 <fwp_main_thread+0xbd8>  // b.pmore
    9cc0:	17fffbe2 	b	8c48 <fwp_main_thread+0xc48>
    9cc4:	72003c3f 	tst	w1, #0xffff
    9cc8:	54ffd401 	b.ne	9748 <fwp_main_thread+0x1748>  // b.any
    9ccc:	17fffe97 	b	9728 <fwp_main_thread+0x1728>
    9cd0:	f94006d6 	ldr	x22, [x22, #8]
    9cd4:	eb08005f 	cmp	x2, x8
    9cd8:	54000349 	b.ls	9d40 <fwp_main_thread+0x1d40>  // b.plast
    9cdc:	d350fd03 	lsr	x3, x8, #16
    9ce0:	8b030863 	add	x3, x3, x3, lsl #2
    9ce4:	d37df063 	lsl	x3, x3, #3
    9ce8:	8b0300a7 	add	x7, x5, x3
    9cec:	f94010e6 	ldr	x6, [x7, #32]
    9cf0:	b4000286 	cbz	x6, 9d40 <fwp_main_thread+0x1d40>
    9cf4:	386368a3 	ldrb	w3, [x5, x3]
    9cf8:	7100087f 	cmp	w3, #0x2
    9cfc:	54000f40 	b.eq	9ee4 <fwp_main_thread+0x1ee4>  // b.none
    9d00:	7100047f 	cmp	w3, #0x1
    9d04:	540001e1 	b.ne	9d40 <fwp_main_thread+0x1d40>  // b.any
    9d08:	294314e9 	ldp	w9, w5, [x7, #24]
    9d0c:	92403d03 	and	x3, x8, #0xffff
    9d10:	9b097c63 	mul	x3, x3, x9
    9d14:	d360fc63 	lsr	x3, x3, #32
    9d18:	eb05007f 	cmp	x3, x5
    9d1c:	54000122 	b.cs	9d40 <fwp_main_thread+0x1d40>  // b.hs, b.nlast
    9d20:	8b0300c6 	add	x6, x6, x3
    9d24:	394000c3 	ldrb	w3, [x6]
    9d28:	7100047f 	cmp	w3, #0x1
    9d2c:	540000a1 	b.ne	9d40 <fwp_main_thread+0x1d40>  // b.any
    9d30:	97ffeb70 	bl	4af0 <fwp_mem_free>
    9d34:	f949ef82 	ldr	x2, [x28, #5080]
    9d38:	f949db81 	ldr	x1, [x28, #5040]
    9d3c:	d370bc42 	lsl	x2, x2, #16
    9d40:	cb0102c3 	sub	x3, x22, x1
    9d44:	eb02007f 	cmp	x3, x2
    9d48:	54ffc863 	b.cc	9654 <fwp_main_thread+0x1654>  // b.lo, b.ul, b.last
    9d4c:	17fffe61 	b	96d0 <fwp_main_thread+0x16d0>
    9d50:	f9401fe0 	ldr	x0, [sp, #56]
    9d54:	97ffe753 	bl	3aa0 <fwp_closure_drop.part.0>
    9d58:	17fffab8 	b	8838 <fwp_main_thread+0x838>
    9d5c:	72003c7f 	tst	w3, #0xffff
    9d60:	54ff5421 	b.ne	87e4 <fwp_main_thread+0x7e4>  // b.any
    9d64:	aa1603e0 	mov	x0, x22
    9d68:	17fffa8d 	b	879c <fwp_main_thread+0x79c>
    9d6c:	72003c7f 	tst	w3, #0xffff
    9d70:	54ff5641 	b.ne	8838 <fwp_main_thread+0x838>  // b.any
    9d74:	17fffaa8 	b	8814 <fwp_main_thread+0x814>
    9d78:	72003c3f 	tst	w1, #0xffff
    9d7c:	54ff6ba1 	b.ne	8af0 <fwp_main_thread+0xaf0>  // b.any
    9d80:	39400300 	ldrb	w0, [x24]
    9d84:	7103fc1f 	cmp	w0, #0xff
    9d88:	54ff6b01 	b.ne	8ae8 <fwp_main_thread+0xae8>  // b.any
    9d8c:	aa1803e0 	mov	x0, x24
    9d90:	97ffeab8 	bl	4870 <fwp_rc_forget_slot>
    9d94:	17fffb55 	b	8ae8 <fwp_main_thread+0xae8>
    9d98:	aa1a03f6 	mov	x22, x26
    9d9c:	17fffbe5 	b	8d30 <fwp_main_thread+0xd30>
    9da0:	72003c3f 	tst	w1, #0xffff
    9da4:	54ff8c41 	b.ne	8f2c <fwp_main_thread+0xf2c>  // b.any
    9da8:	394002c0 	ldrb	w0, [x22]
    9dac:	7103fc1f 	cmp	w0, #0xff
    9db0:	54ff8ba1 	b.ne	8f24 <fwp_main_thread+0xf24>  // b.any
    9db4:	aa1603e0 	mov	x0, x22
    9db8:	97ffeaae 	bl	4870 <fwp_rc_forget_slot>
    9dbc:	17fffc5a 	b	8f24 <fwp_main_thread+0xf24>
    9dc0:	72003c5f 	tst	w2, #0xffff
    9dc4:	54ff7421 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    9dc8:	17fffd36 	b	92a0 <fwp_main_thread+0x12a0>
    9dcc:	f949ef85 	ldr	x5, [x28, #5080]
    9dd0:	f949db81 	ldr	x1, [x28, #5040]
    9dd4:	d370bca5 	lsl	x5, x5, #16
    9dd8:	cb010320 	sub	x0, x25, x1
    9ddc:	f9400b36 	ldr	x22, [x25, #16]
    9de0:	eb05001f 	cmp	x0, x5
    9de4:	54000362 	b.cs	9e50 <fwp_main_thread+0x1e50>  // b.hs, b.nlast
    9de8:	d350fc02 	lsr	x2, x0, #16
    9dec:	8b020842 	add	x2, x2, x2, lsl #2
    9df0:	d37df042 	lsl	x2, x2, #3
    9df4:	8b020067 	add	x7, x3, x2
    9df8:	f94010e6 	ldr	x6, [x7, #32]
    9dfc:	b40002a6 	cbz	x6, 9e50 <fwp_main_thread+0x1e50>
    9e00:	38626862 	ldrb	w2, [x3, x2]
    9e04:	7100085f 	cmp	w2, #0x2
    9e08:	540009e0 	b.eq	9f44 <fwp_main_thread+0x1f44>  // b.none
    9e0c:	7100045f 	cmp	w2, #0x1
    9e10:	54000201 	b.ne	9e50 <fwp_main_thread+0x1e50>  // b.any
    9e14:	294308e3 	ldp	w3, w2, [x7, #24]
    9e18:	92403c00 	and	x0, x0, #0xffff
    9e1c:	9b037c00 	mul	x0, x0, x3
    9e20:	d360fc00 	lsr	x0, x0, #32
    9e24:	eb02001f 	cmp	x0, x2
    9e28:	54000142 	b.cs	9e50 <fwp_main_thread+0x1e50>  // b.hs, b.nlast
    9e2c:	8b0000c6 	add	x6, x6, x0
    9e30:	394000c0 	ldrb	w0, [x6]
    9e34:	7100041f 	cmp	w0, #0x1
    9e38:	540000c1 	b.ne	9e50 <fwp_main_thread+0x1e50>  // b.any
    9e3c:	aa1903e0 	mov	x0, x25
    9e40:	97ffeb2c 	bl	4af0 <fwp_mem_free>
    9e44:	f949ef85 	ldr	x5, [x28, #5080]
    9e48:	f949db81 	ldr	x1, [x28, #5040]
    9e4c:	d370bca5 	lsl	x5, x5, #16
    9e50:	cb0102c1 	sub	x1, x22, x1
    9e54:	eb0100bf 	cmp	x5, x1
    9e58:	54ffc789 	b.ls	9748 <fwp_main_thread+0x1748>  // b.plast
    9e5c:	aa1603f9 	mov	x25, x22
    9e60:	17fffe1f 	b	96dc <fwp_main_thread+0x16dc>
    9e64:	72003d1f 	tst	w8, #0xffff
    9e68:	54ffc341 	b.ne	96d0 <fwp_main_thread+0x16d0>  // b.any
    9e6c:	17fffebf 	b	9968 <fwp_main_thread+0x1968>
    9e70:	72003c3f 	tst	w1, #0xffff
    9e74:	54ffe920 	b.eq	9b98 <fwp_main_thread+0x1b98>  // b.none
    9e78:	aa1703e0 	mov	x0, x23
    9e7c:	17fffc55 	b	8fd0 <fwp_main_thread+0xfd0>
    9e80:	aa1903e0 	mov	x0, x25
    9e84:	f90003e5 	str	x5, [sp]
    9e88:	97ffea7a 	bl	4870 <fwp_rc_forget_slot>
    9e8c:	f94003e5 	ldr	x5, [sp]
    9e90:	17ffff45 	b	9ba4 <fwp_main_thread+0x1ba4>
    9e94:	aa0203e0 	mov	x0, x2
    9e98:	d2800101 	mov	x1, #0x8                   	// #8
    9e9c:	f9000be2 	str	x2, [sp, #16]
    9ea0:	97ffe294 	bl	28f0 <calloc@plt>
    9ea4:	f9400be2 	ldr	x2, [sp, #16]
    9ea8:	aa0003f9 	mov	x25, x0
    9eac:	f94023e3 	ldr	x3, [sp, #64]
    9eb0:	17fffbb4 	b	8d80 <fwp_main_thread+0xd80>
    9eb4:	d2800d01 	mov	x1, #0x68                  	// #104
    9eb8:	d280003b 	mov	x27, #0x1                   	// #1
    9ebc:	17fffa92 	b	8904 <fwp_main_thread+0x904>
    9ec0:	f94000a0 	ldr	x0, [x5]
    9ec4:	b7ffe780 	tbnz	x0, #63, 9bb4 <fwp_main_thread+0x1bb4>
    9ec8:	f949db81 	ldr	x1, [x28, #5040]
    9ecc:	f949ef83 	ldr	x3, [x28, #5080]
    9ed0:	cb0102c1 	sub	x1, x22, x1
    9ed4:	eb03403f 	cmp	x1, x3, lsl #16
    9ed8:	54ffe6e2 	b.cs	9bb4 <fwp_main_thread+0x1bb4>  // b.hs, b.nlast
    9edc:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    9ee0:	17fffd09 	b	9304 <fwp_main_thread+0x1304>
    9ee4:	72003d1f 	tst	w8, #0xffff
    9ee8:	54fff2c1 	b.ne	9d40 <fwp_main_thread+0x1d40>  // b.any
    9eec:	17ffff8e 	b	9d24 <fwp_main_thread+0x1d24>
    9ef0:	72003c5f 	tst	w2, #0xffff
    9ef4:	54ffee01 	b.ne	9cb4 <fwp_main_thread+0x1cb4>  // b.any
    9ef8:	17ffff66 	b	9c90 <fwp_main_thread+0x1c90>
    9efc:	aa1603e0 	mov	x0, x22
    9f00:	97ffedc5 	bl	5614 <fwp_rc_free_arr>
    9f04:	f94027e0 	ldr	x0, [sp, #72]
    9f08:	f9400800 	ldr	x0, [x0, #16]
    9f0c:	f90027e0 	str	x0, [sp, #72]
    9f10:	b5ffcf00 	cbnz	x0, 98f0 <fwp_main_thread+0x18f0>
    9f14:	aa1503e0 	mov	x0, x21
    9f18:	97ffee96 	bl	5970 <fwp_drop0>
    9f1c:	f9400fe0 	ldr	x0, [sp, #24]
    9f20:	97ffee94 	bl	5970 <fwp_drop0>
    9f24:	9101c260 	add	x0, x19, #0x70
    9f28:	fd40fbe8 	ldr	d8, [sp, #496]
    9f2c:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    9f30:	52800021 	mov	w1, #0x1                   	// #1
    9f34:	a95e73fb 	ldp	x27, x28, [sp, #480]
    9f38:	b9034801 	str	w1, [x0, #840]
    9f3c:	f901a81f 	str	xzr, [x0, #848]
    9f40:	17fff873 	b	810c <fwp_main_thread+0x10c>
    9f44:	72003c1f 	tst	w0, #0xffff
    9f48:	54fff841 	b.ne	9e50 <fwp_main_thread+0x1e50>  // b.any
    9f4c:	17ffffb9 	b	9e30 <fwp_main_thread+0x1e30>
    9f50:	72003c5f 	tst	w2, #0xffff
    9f54:	54ff3e21 	b.ne	8718 <fwp_main_thread+0x718>  // b.any
    9f58:	17fff9e7 	b	86f4 <fwp_main_thread+0x6f4>
    9f5c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9f60:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9f64:	91174021 	add	x1, x1, #0x5d0
    9f68:	ca402400 	eor	x0, x0, x0, lsr #9
    9f6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9f70:	f94a2401 	ldr	x1, [x0, #5192]
    9f74:	b5000081 	cbnz	x1, 9f84 <fwp_main_thread+0x1f84>
    9f78:	14000011 	b	9fbc <fwp_main_thread+0x1fbc>
    9f7c:	f9400821 	ldr	x1, [x1, #16]
    9f80:	b40001e1 	cbz	x1, 9fbc <fwp_main_thread+0x1fbc>
    9f84:	f9400020 	ldr	x0, [x1]
    9f88:	eb17001f 	cmp	x0, x23
    9f8c:	54ffff81 	b.ne	9f7c <fwp_main_thread+0x1f7c>  // b.any
    9f90:	f9400420 	ldr	x0, [x1, #8]
    9f94:	d1000400 	sub	x0, x0, #0x1
    9f98:	f9000420 	str	x0, [x1, #8]
    9f9c:	f103f81f 	cmp	x0, #0xfe
    9fa0:	54000fa0 	b.eq	a194 <fwp_main_thread+0x2194>  // b.none
    9fa4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9fa8:	91174000 	add	x0, x0, #0x5d0
    9fac:	f949ec02 	ldr	x2, [x0, #5080]
    9fb0:	f949d801 	ldr	x1, [x0, #5040]
    9fb4:	d370bc42 	lsl	x2, x2, #16
    9fb8:	17fffdc6 	b	96d0 <fwp_main_thread+0x16d0>
    9fbc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    9fc0:	9136c000 	add	x0, x0, #0xdb0
    9fc4:	97ffe62f 	bl	3880 <fwp_trap>
    9fc8:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9fcc:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9fd0:	91174021 	add	x1, x1, #0x5d0
    9fd4:	ca402400 	eor	x0, x0, x0, lsr #9
    9fd8:	8b200c20 	add	x0, x1, w0, uxtb #3
    9fdc:	f94a2400 	ldr	x0, [x0, #5192]
    9fe0:	b5000080 	cbnz	x0, 9ff0 <fwp_main_thread+0x1ff0>
    9fe4:	17fffff6 	b	9fbc <fwp_main_thread+0x1fbc>
    9fe8:	f9400800 	ldr	x0, [x0, #16]
    9fec:	b4fffe80 	cbz	x0, 9fbc <fwp_main_thread+0x1fbc>
    9ff0:	f9400001 	ldr	x1, [x0]
    9ff4:	eb17003f 	cmp	x1, x23
    9ff8:	54ffff81 	b.ne	9fe8 <fwp_main_thread+0x1fe8>  // b.any
    9ffc:	f9400401 	ldr	x1, [x0, #8]
    a000:	d1000421 	sub	x1, x1, #0x1
    a004:	f9000401 	str	x1, [x0, #8]
    a008:	f103f83f 	cmp	x1, #0xfe
    a00c:	54ff61e1 	b.ne	8c48 <fwp_main_thread+0xc48>  // b.any
    a010:	aa1703e0 	mov	x0, x23
    a014:	f90003e3 	str	x3, [sp]
    a018:	97ffea16 	bl	4870 <fwp_rc_forget_slot>
    a01c:	f94003e3 	ldr	x3, [sp]
    a020:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a024:	390002e0 	strb	w0, [x23]
    a028:	17fffb08 	b	8c48 <fwp_main_thread+0xc48>
    a02c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a030:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a034:	91174021 	add	x1, x1, #0x5d0
    a038:	ca402400 	eor	x0, x0, x0, lsr #9
    a03c:	8b200c20 	add	x0, x1, w0, uxtb #3
    a040:	f94a2401 	ldr	x1, [x0, #5192]
    a044:	b5000081 	cbnz	x1, a054 <fwp_main_thread+0x2054>
    a048:	17ffffdd 	b	9fbc <fwp_main_thread+0x1fbc>
    a04c:	f9400821 	ldr	x1, [x1, #16]
    a050:	b4fffb61 	cbz	x1, 9fbc <fwp_main_thread+0x1fbc>
    a054:	f9400020 	ldr	x0, [x1]
    a058:	eb16001f 	cmp	x0, x22
    a05c:	54ffff81 	b.ne	a04c <fwp_main_thread+0x204c>  // b.any
    a060:	f9400420 	ldr	x0, [x1, #8]
    a064:	d1000400 	sub	x0, x0, #0x1
    a068:	f9000420 	str	x0, [x1, #8]
    a06c:	f103f81f 	cmp	x0, #0xfe
    a070:	54ffb6c1 	b.ne	9748 <fwp_main_thread+0x1748>  // b.any
    a074:	aa1603e0 	mov	x0, x22
    a078:	97ffe9fe 	bl	4870 <fwp_rc_forget_slot>
    a07c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a080:	390002c0 	strb	w0, [x22]
    a084:	17fffdb1 	b	9748 <fwp_main_thread+0x1748>
    a088:	72003c5f 	tst	w2, #0xffff
    a08c:	54ffbd41 	b.ne	9834 <fwp_main_thread+0x1834>  // b.any
    a090:	17fffde4 	b	9820 <fwp_main_thread+0x1820>
    a094:	72003c5f 	tst	w2, #0xffff
    a098:	54ffc241 	b.ne	98e0 <fwp_main_thread+0x18e0>  // b.any
    a09c:	17fffe09 	b	98c0 <fwp_main_thread+0x18c0>
    a0a0:	aa1503f9 	mov	x25, x21
    a0a4:	d280001b 	mov	x27, #0x0                   	// #0
    a0a8:	d2800018 	mov	x24, #0x0                   	// #0
    a0ac:	17fffd62 	b	9634 <fwp_main_thread+0x1634>
    a0b0:	97ffe9a9 	bl	4754 <fwp_rc_wide_dup>
    a0b4:	17fff9c0 	b	87b4 <fwp_main_thread+0x7b4>
    a0b8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a0bc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a0c0:	91174021 	add	x1, x1, #0x5d0
    a0c4:	ca402400 	eor	x0, x0, x0, lsr #9
    a0c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0cc:	f94a2400 	ldr	x0, [x0, #5192]
    a0d0:	b5000080 	cbnz	x0, a0e0 <fwp_main_thread+0x20e0>
    a0d4:	17ffffba 	b	9fbc <fwp_main_thread+0x1fbc>
    a0d8:	f9400800 	ldr	x0, [x0, #16]
    a0dc:	b4fff700 	cbz	x0, 9fbc <fwp_main_thread+0x1fbc>
    a0e0:	f9400001 	ldr	x1, [x0]
    a0e4:	eb16003f 	cmp	x1, x22
    a0e8:	54ffff81 	b.ne	a0d8 <fwp_main_thread+0x20d8>  // b.any
    a0ec:	f9400401 	ldr	x1, [x0, #8]
    a0f0:	d1000421 	sub	x1, x1, #0x1
    a0f4:	f9000401 	str	x1, [x0, #8]
    a0f8:	f103f83f 	cmp	x1, #0xfe
    a0fc:	54ff39e1 	b.ne	8838 <fwp_main_thread+0x838>  // b.any
    a100:	aa1603e0 	mov	x0, x22
    a104:	97ffe9db 	bl	4870 <fwp_rc_forget_slot>
    a108:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a10c:	390002c0 	strb	w0, [x22]
    a110:	17fff9ca 	b	8838 <fwp_main_thread+0x838>
    a114:	72003c3f 	tst	w1, #0xffff
    a118:	54ff2061 	b.ne	8524 <fwp_main_thread+0x524>  // b.any
    a11c:	17fff8fd 	b	8510 <fwp_main_thread+0x510>
    a120:	72003c3f 	tst	w1, #0xffff
    a124:	54ff2961 	b.ne	8650 <fwp_main_thread+0x650>  // b.any
    a128:	17fff945 	b	863c <fwp_main_thread+0x63c>
    a12c:	72003c3f 	tst	w1, #0xffff
    a130:	54ff2441 	b.ne	85b8 <fwp_main_thread+0x5b8>  // b.any
    a134:	17fff91c 	b	85a4 <fwp_main_thread+0x5a4>
    a138:	aa0003e1 	mov	x1, x0
    a13c:	f90022b4 	str	x20, [x21, #64]
    a140:	17fff80c 	b	8170 <fwp_main_thread+0x170>
    a144:	d2800017 	mov	x23, #0x0                   	// #0
    a148:	17fffcca 	b	9470 <fwp_main_thread+0x1470>
    a14c:	aa1703e0 	mov	x0, x23
    a150:	97ffe9c8 	bl	4870 <fwp_rc_forget_slot>
    a154:	17fffdb6 	b	982c <fwp_main_thread+0x182c>
    a158:	f94192a0 	ldr	x0, [x21, #800]
    a15c:	97ffea65 	bl	4af0 <fwp_mem_free>
    a160:	f90192bf 	str	xzr, [x21, #800]
    a164:	f9019abf 	str	xzr, [x21, #816]
    a168:	f941b2a0 	ldr	x0, [x21, #864]
    a16c:	b40007d4 	cbz	x20, a264 <fwp_main_thread+0x2264>
    a170:	f900569f 	str	xzr, [x20, #168]
    a174:	f9005e9f 	str	xzr, [x20, #184]
    a178:	b9035abf 	str	wzr, [x21, #856]
    a17c:	eb14001f 	cmp	x0, x20
    a180:	54ff0580 	b.eq	8230 <fwp_main_thread+0x230>  // b.none
    a184:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a188:	a91e73fb 	stp	x27, x28, [sp, #480]
    a18c:	fd00fbe8 	str	d8, [sp, #496]
    a190:	97ffe1f4 	bl	2960 <abort@plt>
    a194:	aa1703e0 	mov	x0, x23
    a198:	97ffe9b6 	bl	4870 <fwp_rc_forget_slot>
    a19c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a1a0:	91174000 	add	x0, x0, #0x5d0
    a1a4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a1a8:	390002e1 	strb	w1, [x23]
    a1ac:	f949ec02 	ldr	x2, [x0, #5080]
    a1b0:	f949d801 	ldr	x1, [x0, #5040]
    a1b4:	d370bc42 	lsl	x2, x2, #16
    a1b8:	17fffd46 	b	96d0 <fwp_main_thread+0x16d0>
    a1bc:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    a1c0:	913a4000 	add	x0, x0, #0xe90
    a1c4:	97ffe5af 	bl	3880 <fwp_trap>
    a1c8:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    a1cc:	9137e000 	add	x0, x0, #0xdf8
    a1d0:	97ffe5ac 	bl	3880 <fwp_trap>
    a1d4:	97ffe960 	bl	4754 <fwp_rc_wide_dup>
    a1d8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a1dc:	91174000 	add	x0, x0, #0x5d0
    a1e0:	f949ec06 	ldr	x6, [x0, #5080]
    a1e4:	f949d803 	ldr	x3, [x0, #5040]
    a1e8:	d370bcc6 	lsl	x6, x6, #16
    a1ec:	17fff94b 	b	8718 <fwp_main_thread+0x718>
    a1f0:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a1f4:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a1f8:	91174021 	add	x1, x1, #0x5d0
    a1fc:	ca402400 	eor	x0, x0, x0, lsr #9
    a200:	8b200c20 	add	x0, x1, w0, uxtb #3
    a204:	f94a2400 	ldr	x0, [x0, #5192]
    a208:	b5000080 	cbnz	x0, a218 <fwp_main_thread+0x2218>
    a20c:	17ffff6c 	b	9fbc <fwp_main_thread+0x1fbc>
    a210:	f9400800 	ldr	x0, [x0, #16]
    a214:	b4ffed40 	cbz	x0, 9fbc <fwp_main_thread+0x1fbc>
    a218:	f9400001 	ldr	x1, [x0]
    a21c:	eb17003f 	cmp	x1, x23
    a220:	54ffff81 	b.ne	a210 <fwp_main_thread+0x2210>  // b.any
    a224:	f9400401 	ldr	x1, [x0, #8]
    a228:	d1000421 	sub	x1, x1, #0x1
    a22c:	f9000401 	str	x1, [x0, #8]
    a230:	f103f83f 	cmp	x1, #0xfe
    a234:	54ffb561 	b.ne	98e0 <fwp_main_thread+0x18e0>  // b.any
    a238:	aa1703e0 	mov	x0, x23
    a23c:	97ffe98d 	bl	4870 <fwp_rc_forget_slot>
    a240:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a244:	390002e0 	strb	w0, [x23]
    a248:	17fffda6 	b	98e0 <fwp_main_thread+0x18e0>
    a24c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a250:	9101e000 	add	x0, x0, #0x78
    a254:	97ffe58b 	bl	3880 <fwp_trap>
    a258:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    a25c:	913bc000 	add	x0, x0, #0xef0
    a260:	97ffe588 	bl	3880 <fwp_trap>
    a264:	b9035abf 	str	wzr, [x21, #856]
    a268:	b4ff6e20 	cbz	x0, 902c <fwp_main_thread+0x102c>
    a26c:	17ffffc6 	b	a184 <fwp_main_thread+0x2184>
    a270:	aa1503e0 	mov	x0, x21
    a274:	97ffe97f 	bl	4870 <fwp_rc_forget_slot>
    a278:	17fff8a9 	b	851c <fwp_main_thread+0x51c>
    a27c:	aa1503e0 	mov	x0, x21
    a280:	97ffe97c 	bl	4870 <fwp_rc_forget_slot>
    a284:	17fff8cb 	b	85b0 <fwp_main_thread+0x5b0>
    a288:	aa1703e0 	mov	x0, x23
    a28c:	97ffe979 	bl	4870 <fwp_rc_forget_slot>
    a290:	17fff8ee 	b	8648 <fwp_main_thread+0x648>
    a294:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a298:	9102e000 	add	x0, x0, #0xb8
    a29c:	97ffe579 	bl	3880 <fwp_trap>
    a2a0:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a2a4:	91028000 	add	x0, x0, #0xa0
    a2a8:	97ffe576 	bl	3880 <fwp_trap>
    a2ac:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    a2b0:	913fc000 	add	x0, x0, #0xff0
    a2b4:	a91c63f7 	stp	x23, x24, [sp, #448]
    a2b8:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2bc:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2c0:	fd00fbe8 	str	d8, [sp, #496]
    a2c4:	97ffe56f 	bl	3880 <fwp_trap>
    a2c8:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2cc:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2d0:	fd00fbe8 	str	d8, [sp, #496]
    a2d4:	97ffe3b7 	bl	31b0 <descent_phase_fail>
    a2d8:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2dc:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2e0:	fd00fbe8 	str	d8, [sp, #496]
    a2e4:	97ffe18b 	bl	2910 <__stack_chk_fail@plt>
    a2e8:	52800020 	mov	w0, #0x1                   	// #1
    a2ec:	17fffbbe 	b	91e4 <fwp_main_thread+0x11e4>
    a2f0:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a2f4:	9101a000 	add	x0, x0, #0x68
    a2f8:	97ffe562 	bl	3880 <fwp_trap>
    a2fc:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2000>
    a300:	91390000 	add	x0, x0, #0xe40
    a304:	97ffe55f 	bl	3880 <fwp_trap>
    a308:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a30c:	91006000 	add	x0, x0, #0x18
    a310:	97ffe55c 	bl	3880 <fwp_trap>
    a314:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5b0>
    a318:	9100e000 	add	x0, x0, #0x38
    a31c:	97ffe559 	bl	3880 <fwp_trap>
    a320:	97ffe1f8 	bl	2b00 <fwp_trap_overflow.constprop.0>
    a324:	d503201f 	nop
    a328:	d503201f 	nop
    a32c:	d503201f 	nop

000000000000a330 <__divti3>:
    a330:	d503245f 	bti	c
    a334:	d2800004 	mov	x4, #0x0                   	// #0
    a338:	b7f80721 	tbnz	x1, #63, a41c <__divti3+0xec>
    a33c:	b6f80083 	tbz	x3, #63, a34c <__divti3+0x1c>
    a340:	eb0203e2 	negs	x2, x2
    a344:	aa2403e4 	mvn	x4, x4
    a348:	da0303e3 	ngc	x3, x3
    a34c:	aa0203e6 	mov	x6, x2
    a350:	aa0003e7 	mov	x7, x0
    a354:	aa0103e5 	mov	x5, x1
    a358:	b5000583 	cbnz	x3, a408 <__divti3+0xd8>
    a35c:	eb01005f 	cmp	x2, x1
    a360:	54000e69 	b.ls	a52c <__divti3+0x1fc>  // b.plast
    a364:	dac01040 	clz	x0, x2
    a368:	b40000e0 	cbz	x0, a384 <__divti3+0x54>
    a36c:	4b0003e1 	neg	w1, w0
    a370:	9ac020a5 	lsl	x5, x5, x0
    a374:	9ac02046 	lsl	x6, x2, x0
    a378:	9ac124e1 	lsr	x1, x7, x1
    a37c:	aa050025 	orr	x5, x1, x5
    a380:	9ac020e7 	lsl	x7, x7, x0
    a384:	d360fcc8 	lsr	x8, x6, #32
    a388:	92407cc2 	and	x2, x6, #0xffffffff
    a38c:	9ac808a3 	udiv	x3, x5, x8
    a390:	9b089465 	msub	x5, x3, x8, x5
    a394:	aa0303e0 	mov	x0, x3
    a398:	9b037c41 	mul	x1, x2, x3
    a39c:	93c780a5 	extr	x5, x5, x7, #32
    a3a0:	eb05003f 	cmp	x1, x5
    a3a4:	540000a9 	b.ls	a3b8 <__divti3+0x88>  // b.plast
    a3a8:	ab0500c5 	adds	x5, x6, x5
    a3ac:	d1000460 	sub	x0, x3, #0x1
    a3b0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a3b4:	540015a8 	b.hi	a668 <__divti3+0x338>  // b.pmore
    a3b8:	cb0100a5 	sub	x5, x5, x1
    a3bc:	9ac808a3 	udiv	x3, x5, x8
    a3c0:	9b089465 	msub	x5, x3, x8, x5
    a3c4:	aa0303e1 	mov	x1, x3
    a3c8:	9b037c42 	mul	x2, x2, x3
    a3cc:	aa0703e3 	mov	x3, x7
    a3d0:	b3607ca3 	bfi	x3, x5, #32, #32
    a3d4:	eb03005f 	cmp	x2, x3
    a3d8:	540000c9 	b.ls	a3f0 <__divti3+0xc0>  // b.plast
    a3dc:	ab0300c3 	adds	x3, x6, x3
    a3e0:	d1000425 	sub	x5, x1, #0x1
    a3e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a3e8:	d1000821 	sub	x1, x1, #0x2
    a3ec:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a3f0:	aa008020 	orr	x0, x1, x0, lsl #32
    a3f4:	d2800001 	mov	x1, #0x0                   	// #0
    a3f8:	b4000064 	cbz	x4, a404 <__divti3+0xd4>
    a3fc:	eb0003e0 	negs	x0, x0
    a400:	da0103e1 	ngc	x1, x1
    a404:	d65f03c0 	ret
    a408:	eb01007f 	cmp	x3, x1
    a40c:	54000109 	b.ls	a42c <__divti3+0xfc>  // b.plast
    a410:	d2800001 	mov	x1, #0x0                   	// #0
    a414:	d2800000 	mov	x0, #0x0                   	// #0
    a418:	17fffff8 	b	a3f8 <__divti3+0xc8>
    a41c:	eb0003e0 	negs	x0, x0
    a420:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a424:	da0103e1 	ngc	x1, x1
    a428:	17ffffc5 	b	a33c <__divti3+0xc>
    a42c:	dac01067 	clz	x7, x3
    a430:	b40010e7 	cbz	x7, a64c <__divti3+0x31c>
    a434:	d2800805 	mov	x5, #0x40                  	// #64
    a438:	cb0700a5 	sub	x5, x5, x7
    a43c:	9ac72063 	lsl	x3, x3, x7
    a440:	9ac52448 	lsr	x8, x2, x5
    a444:	aa030108 	orr	x8, x8, x3
    a448:	9ac52426 	lsr	x6, x1, x5
    a44c:	92407d0a 	and	x10, x8, #0xffffffff
    a450:	d360fd09 	lsr	x9, x8, #32
    a454:	9ac52403 	lsr	x3, x0, x5
    a458:	9ac72021 	lsl	x1, x1, x7
    a45c:	aa010063 	orr	x3, x3, x1
    a460:	9ac72042 	lsl	x2, x2, x7
    a464:	9ac908cb 	udiv	x11, x6, x9
    a468:	9b099965 	msub	x5, x11, x9, x6
    a46c:	aa0b03e1 	mov	x1, x11
    a470:	9b0b7d46 	mul	x6, x10, x11
    a474:	93c380a5 	extr	x5, x5, x3, #32
    a478:	eb0500df 	cmp	x6, x5
    a47c:	540000a9 	b.ls	a490 <__divti3+0x160>  // b.plast
    a480:	ab050105 	adds	x5, x8, x5
    a484:	d1000561 	sub	x1, x11, #0x1
    a488:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a48c:	54000f48 	b.hi	a674 <__divti3+0x344>  // b.pmore
    a490:	cb0600a6 	sub	x6, x5, x6
    a494:	9ac908cb 	udiv	x11, x6, x9
    a498:	9b099969 	msub	x9, x11, x9, x6
    a49c:	aa0b03e5 	mov	x5, x11
    a4a0:	9b0b7d4a 	mul	x10, x10, x11
    a4a4:	b3607d23 	bfi	x3, x9, #32, #32
    a4a8:	eb03015f 	cmp	x10, x3
    a4ac:	540000a9 	b.ls	a4c0 <__divti3+0x190>  // b.plast
    a4b0:	ab030103 	adds	x3, x8, x3
    a4b4:	d1000565 	sub	x5, x11, #0x1
    a4b8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a4bc:	54000e28 	b.hi	a680 <__divti3+0x350>  // b.pmore
    a4c0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a4c4:	92407c48 	and	x8, x2, #0xffffffff
    a4c8:	2a0503e5 	mov	w5, w5
    a4cc:	d360fc42 	lsr	x2, x2, #32
    a4d0:	d360fc26 	lsr	x6, x1, #32
    a4d4:	cb0a0063 	sub	x3, x3, x10
    a4d8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a4dc:	9b087caa 	mul	x10, x5, x8
    a4e0:	9b087cc8 	mul	x8, x6, x8
    a4e4:	9b0220a5 	madd	x5, x5, x2, x8
    a4e8:	9b027cc6 	mul	x6, x6, x2
    a4ec:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a4f0:	8b0900c5 	add	x5, x6, x9
    a4f4:	eb02011f 	cmp	x8, x2
    a4f8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a4fc:	8b4280c6 	add	x6, x6, x2, lsr #32
    a500:	eb06007f 	cmp	x3, x6
    a504:	540000e3 	b.cc	a520 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a508:	92407d4a 	and	x10, x10, #0xffffffff
    a50c:	9ac72000 	lsl	x0, x0, x7
    a510:	8b028142 	add	x2, x10, x2, lsl #32
    a514:	eb02001f 	cmp	x0, x2
    a518:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a51c:	54000a01 	b.ne	a65c <__divti3+0x32c>  // b.any
    a520:	d1000420 	sub	x0, x1, #0x1
    a524:	d2800001 	mov	x1, #0x0                   	// #0
    a528:	17ffffb4 	b	a3f8 <__divti3+0xc8>
    a52c:	b5000062 	cbnz	x2, a538 <__divti3+0x208>
    a530:	d2800022 	mov	x2, #0x1                   	// #1
    a534:	9ac30846 	udiv	x6, x2, x3
    a538:	dac010c8 	clz	x8, x6
    a53c:	b5000408 	cbnz	x8, a5bc <__divti3+0x28c>
    a540:	d360fcc9 	lsr	x9, x6, #32
    a544:	92407cc5 	and	x5, x6, #0xffffffff
    a548:	cb060023 	sub	x3, x1, x6
    a54c:	d2800021 	mov	x1, #0x1                   	// #1
    a550:	9ac90868 	udiv	x8, x3, x9
    a554:	9b098d03 	msub	x3, x8, x9, x3
    a558:	aa0803e0 	mov	x0, x8
    a55c:	9b057d02 	mul	x2, x8, x5
    a560:	93c78063 	extr	x3, x3, x7, #32
    a564:	eb03005f 	cmp	x2, x3
    a568:	540000a9 	b.ls	a57c <__divti3+0x24c>  // b.plast
    a56c:	ab0300c3 	adds	x3, x6, x3
    a570:	d1000500 	sub	x0, x8, #0x1
    a574:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a578:	54000968 	b.hi	a6a4 <__divti3+0x374>  // b.pmore
    a57c:	cb020063 	sub	x3, x3, x2
    a580:	9ac90862 	udiv	x2, x3, x9
    a584:	aa0203e8 	mov	x8, x2
    a588:	9b098c42 	msub	x2, x2, x9, x3
    a58c:	aa0703e3 	mov	x3, x7
    a590:	9b057d05 	mul	x5, x8, x5
    a594:	b3607c43 	bfi	x3, x2, #32, #32
    a598:	eb0300bf 	cmp	x5, x3
    a59c:	540000c9 	b.ls	a5b4 <__divti3+0x284>  // b.plast
    a5a0:	ab0300c2 	adds	x2, x6, x3
    a5a4:	d1000503 	sub	x3, x8, #0x1
    a5a8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a5ac:	d1000908 	sub	x8, x8, #0x2
    a5b0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a5b4:	aa008100 	orr	x0, x8, x0, lsl #32
    a5b8:	17ffff90 	b	a3f8 <__divti3+0xc8>
    a5bc:	9ac820c6 	lsl	x6, x6, x8
    a5c0:	d2800803 	mov	x3, #0x40                  	// #64
    a5c4:	cb080063 	sub	x3, x3, x8
    a5c8:	d360fcc9 	lsr	x9, x6, #32
    a5cc:	9ac82027 	lsl	x7, x1, x8
    a5d0:	92407cc5 	and	x5, x6, #0xffffffff
    a5d4:	9ac32422 	lsr	x2, x1, x3
    a5d8:	9ac32403 	lsr	x3, x0, x3
    a5dc:	aa070063 	orr	x3, x3, x7
    a5e0:	9ac9084a 	udiv	x10, x2, x9
    a5e4:	9ac82007 	lsl	x7, x0, x8
    a5e8:	9b098940 	msub	x0, x10, x9, x2
    a5ec:	aa0a03e1 	mov	x1, x10
    a5f0:	9b0a7ca2 	mul	x2, x5, x10
    a5f4:	93c38000 	extr	x0, x0, x3, #32
    a5f8:	eb00005f 	cmp	x2, x0
    a5fc:	540000a9 	b.ls	a610 <__divti3+0x2e0>  // b.plast
    a600:	ab0000c0 	adds	x0, x6, x0
    a604:	d1000541 	sub	x1, x10, #0x1
    a608:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a60c:	54000468 	b.hi	a698 <__divti3+0x368>  // b.pmore
    a610:	cb020000 	sub	x0, x0, x2
    a614:	9ac9080a 	udiv	x10, x0, x9
    a618:	9b098140 	msub	x0, x10, x9, x0
    a61c:	aa0a03e2 	mov	x2, x10
    a620:	9b0a7ca8 	mul	x8, x5, x10
    a624:	b3607c03 	bfi	x3, x0, #32, #32
    a628:	eb03011f 	cmp	x8, x3
    a62c:	540000a9 	b.ls	a640 <__divti3+0x310>  // b.plast
    a630:	ab0300c3 	adds	x3, x6, x3
    a634:	d1000542 	sub	x2, x10, #0x1
    a638:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a63c:	54000288 	b.hi	a68c <__divti3+0x35c>  // b.pmore
    a640:	cb080063 	sub	x3, x3, x8
    a644:	aa018041 	orr	x1, x2, x1, lsl #32
    a648:	17ffffc2 	b	a550 <__divti3+0x220>
    a64c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a650:	d2800001 	mov	x1, #0x0                   	// #0
    a654:	9a9f87e0 	cset	x0, ls	// ls = plast
    a658:	17ffff68 	b	a3f8 <__divti3+0xc8>
    a65c:	aa0103e0 	mov	x0, x1
    a660:	d2800001 	mov	x1, #0x0                   	// #0
    a664:	17ffff65 	b	a3f8 <__divti3+0xc8>
    a668:	d1000860 	sub	x0, x3, #0x2
    a66c:	8b0600a5 	add	x5, x5, x6
    a670:	17ffff52 	b	a3b8 <__divti3+0x88>
    a674:	d1000961 	sub	x1, x11, #0x2
    a678:	8b0800a5 	add	x5, x5, x8
    a67c:	17ffff85 	b	a490 <__divti3+0x160>
    a680:	d1000965 	sub	x5, x11, #0x2
    a684:	8b080063 	add	x3, x3, x8
    a688:	17ffff8e 	b	a4c0 <__divti3+0x190>
    a68c:	d1000942 	sub	x2, x10, #0x2
    a690:	8b060063 	add	x3, x3, x6
    a694:	17ffffeb 	b	a640 <__divti3+0x310>
    a698:	d1000941 	sub	x1, x10, #0x2
    a69c:	8b060000 	add	x0, x0, x6
    a6a0:	17ffffdc 	b	a610 <__divti3+0x2e0>
    a6a4:	d1000900 	sub	x0, x8, #0x2
    a6a8:	8b060063 	add	x3, x3, x6
    a6ac:	17ffffb4 	b	a57c <__divti3+0x24c>

000000000000a6b0 <__modti3>:
    a6b0:	d503245f 	bti	c
    a6b4:	d2800004 	mov	x4, #0x0                   	// #0
    a6b8:	b6f80081 	tbz	x1, #63, a6c8 <__modti3+0x18>
    a6bc:	eb0003e0 	negs	x0, x0
    a6c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a6c4:	da0103e1 	ngc	x1, x1
    a6c8:	f100007f 	cmp	x3, #0x0
    a6cc:	5400128b 	b.lt	a91c <__modti3+0x26c>  // b.tstop
    a6d0:	aa0003e7 	mov	x7, x0
    a6d4:	aa0103e6 	mov	x6, x1
    a6d8:	540004e1 	b.ne	a774 <__modti3+0xc4>  // b.any
    a6dc:	eb02003f 	cmp	x1, x2
    a6e0:	54000dc2 	b.cs	a898 <__modti3+0x1e8>  // b.hs, b.nlast
    a6e4:	dac01043 	clz	x3, x2
    a6e8:	aa0303e5 	mov	x5, x3
    a6ec:	b40000e3 	cbz	x3, a708 <__modti3+0x58>
    a6f0:	4b0303e6 	neg	w6, w3
    a6f4:	9ac32021 	lsl	x1, x1, x3
    a6f8:	9ac32042 	lsl	x2, x2, x3
    a6fc:	9ac62406 	lsr	x6, x0, x6
    a700:	aa0100c6 	orr	x6, x6, x1
    a704:	9ac32007 	lsl	x7, x0, x3
    a708:	d360fc40 	lsr	x0, x2, #32
    a70c:	92407c43 	and	x3, x2, #0xffffffff
    a710:	9ac008c1 	udiv	x1, x6, x0
    a714:	9b009826 	msub	x6, x1, x0, x6
    a718:	9b017c61 	mul	x1, x3, x1
    a71c:	93c780c6 	extr	x6, x6, x7, #32
    a720:	eb06003f 	cmp	x1, x6
    a724:	540000a9 	b.ls	a738 <__modti3+0x88>  // b.plast
    a728:	ab060046 	adds	x6, x2, x6
    a72c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a730:	8b0200c8 	add	x8, x6, x2
    a734:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a738:	cb0100c6 	sub	x6, x6, x1
    a73c:	9ac008c8 	udiv	x8, x6, x0
    a740:	9b009901 	msub	x1, x8, x0, x6
    a744:	aa0703e0 	mov	x0, x7
    a748:	9b087c63 	mul	x3, x3, x8
    a74c:	b3607c20 	bfi	x0, x1, #32, #32
    a750:	eb00007f 	cmp	x3, x0
    a754:	54001088 	b.hi	a964 <__modti3+0x2b4>  // b.pmore
    a758:	cb030000 	sub	x0, x0, x3
    a75c:	9ac52400 	lsr	x0, x0, x5
    a760:	d2800001 	mov	x1, #0x0                   	// #0
    a764:	b4000064 	cbz	x4, a770 <__modti3+0xc0>
    a768:	eb0003e0 	negs	x0, x0
    a76c:	da0103e1 	ngc	x1, x1
    a770:	d65f03c0 	ret
    a774:	dac01066 	clz	x6, x3
    a778:	eb03003f 	cmp	x1, x3
    a77c:	54ffff43 	b.cc	a764 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a780:	93407cc5 	sxtw	x5, w6
    a784:	d2800808 	mov	x8, #0x40                  	// #64
    a788:	cb050108 	sub	x8, x8, x5
    a78c:	9ac62063 	lsl	x3, x3, x6
    a790:	9ac62025 	lsl	x5, x1, x6
    a794:	9ac82447 	lsr	x7, x2, x8
    a798:	aa0300e7 	orr	x7, x7, x3
    a79c:	9ac82423 	lsr	x3, x1, x8
    a7a0:	92407cec 	and	x12, x7, #0xffffffff
    a7a4:	d360fcea 	lsr	x10, x7, #32
    a7a8:	9ac82401 	lsr	x1, x0, x8
    a7ac:	aa050021 	orr	x1, x1, x5
    a7b0:	9ac62042 	lsl	x2, x2, x6
    a7b4:	9ac62000 	lsl	x0, x0, x6
    a7b8:	9aca086b 	udiv	x11, x3, x10
    a7bc:	9b0a8d63 	msub	x3, x11, x10, x3
    a7c0:	aa0b03e5 	mov	x5, x11
    a7c4:	9b0b7d89 	mul	x9, x12, x11
    a7c8:	93c18063 	extr	x3, x3, x1, #32
    a7cc:	eb03013f 	cmp	x9, x3
    a7d0:	540000a9 	b.ls	a7e4 <__modti3+0x134>  // b.plast
    a7d4:	ab0300e3 	adds	x3, x7, x3
    a7d8:	d1000565 	sub	x5, x11, #0x1
    a7dc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a7e0:	54001168 	b.hi	aa0c <__modti3+0x35c>  // b.pmore
    a7e4:	cb090063 	sub	x3, x3, x9
    a7e8:	9aca086b 	udiv	x11, x3, x10
    a7ec:	9b0a8d6a 	msub	x10, x11, x10, x3
    a7f0:	aa0b03e9 	mov	x9, x11
    a7f4:	9b0b7d8c 	mul	x12, x12, x11
    a7f8:	b3607d41 	bfi	x1, x10, #32, #32
    a7fc:	eb01019f 	cmp	x12, x1
    a800:	540000a9 	b.ls	a814 <__modti3+0x164>  // b.plast
    a804:	ab0100e1 	adds	x1, x7, x1
    a808:	d1000569 	sub	x9, x11, #0x1
    a80c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a810:	54000f88 	b.hi	aa00 <__modti3+0x350>  // b.pmore
    a814:	aa058123 	orr	x3, x9, x5, lsl #32
    a818:	92407c4b 	and	x11, x2, #0xffffffff
    a81c:	2a0903e9 	mov	w9, w9
    a820:	d360fc4a 	lsr	x10, x2, #32
    a824:	d360fc63 	lsr	x3, x3, #32
    a828:	cb0c0021 	sub	x1, x1, x12
    a82c:	aa0a03ec 	mov	x12, x10
    a830:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a834:	9b0b7d25 	mul	x5, x9, x11
    a838:	9b0b7c6b 	mul	x11, x3, x11
    a83c:	9b0a2d29 	madd	x9, x9, x10, x11
    a840:	92407caa 	and	x10, x5, #0xffffffff
    a844:	9b0c7c63 	mul	x3, x3, x12
    a848:	8b458125 	add	x5, x9, x5, lsr #32
    a84c:	8b0d0069 	add	x9, x3, x13
    a850:	eb05017f 	cmp	x11, x5
    a854:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a858:	8b058149 	add	x9, x10, x5, lsl #32
    a85c:	8b458063 	add	x3, x3, x5, lsr #32
    a860:	eb03003f 	cmp	x1, x3
    a864:	54000063 	b.cc	a870 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a868:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a86c:	54000082 	b.cs	a87c <__modti3+0x1cc>  // b.hs, b.nlast
    a870:	eb020129 	subs	x9, x9, x2
    a874:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a878:	cb070063 	sub	x3, x3, x7
    a87c:	eb090000 	subs	x0, x0, x9
    a880:	da030021 	sbc	x1, x1, x3
    a884:	9ac62400 	lsr	x0, x0, x6
    a888:	9ac82028 	lsl	x8, x1, x8
    a88c:	aa000100 	orr	x0, x8, x0
    a890:	9ac62421 	lsr	x1, x1, x6
    a894:	17ffffb4 	b	a764 <__modti3+0xb4>
    a898:	b5000062 	cbnz	x2, a8a4 <__modti3+0x1f4>
    a89c:	d2800023 	mov	x3, #0x1                   	// #1
    a8a0:	9ac20862 	udiv	x2, x3, x2
    a8a4:	dac01048 	clz	x8, x2
    a8a8:	aa0803e5 	mov	x5, x8
    a8ac:	b5000668 	cbnz	x8, a978 <__modti3+0x2c8>
    a8b0:	cb020020 	sub	x0, x1, x2
    a8b4:	d360fc49 	lsr	x9, x2, #32
    a8b8:	92407c4a 	and	x10, x2, #0xffffffff
    a8bc:	9ac90801 	udiv	x1, x0, x9
    a8c0:	9b098020 	msub	x0, x1, x9, x0
    a8c4:	9b0a7c21 	mul	x1, x1, x10
    a8c8:	93c78000 	extr	x0, x0, x7, #32
    a8cc:	eb00003f 	cmp	x1, x0
    a8d0:	540000a9 	b.ls	a8e4 <__modti3+0x234>  // b.plast
    a8d4:	ab000040 	adds	x0, x2, x0
    a8d8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a8dc:	8b020003 	add	x3, x0, x2
    a8e0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a8e4:	cb010001 	sub	x1, x0, x1
    a8e8:	9ac90820 	udiv	x0, x1, x9
    a8ec:	9b098403 	msub	x3, x0, x9, x1
    a8f0:	aa0703e1 	mov	x1, x7
    a8f4:	9b0a7c00 	mul	x0, x0, x10
    a8f8:	b3607c61 	bfi	x1, x3, #32, #32
    a8fc:	eb01001f 	cmp	x0, x1
    a900:	540000a9 	b.ls	a914 <__modti3+0x264>  // b.plast
    a904:	ab010041 	adds	x1, x2, x1
    a908:	8b020022 	add	x2, x1, x2
    a90c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a910:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a914:	cb000020 	sub	x0, x1, x0
    a918:	17ffff91 	b	a75c <__modti3+0xac>
    a91c:	eb0203e5 	negs	x5, x2
    a920:	aa0003e7 	mov	x7, x0
    a924:	da0303e8 	ngc	x8, x3
    a928:	aa0503e2 	mov	x2, x5
    a92c:	aa0803e3 	mov	x3, x8
    a930:	aa0103e6 	mov	x6, x1
    a934:	b4ffed48 	cbz	x8, a6dc <__modti3+0x2c>
    a938:	eb01011f 	cmp	x8, x1
    a93c:	54fff148 	b.hi	a764 <__modti3+0xb4>  // b.pmore
    a940:	dac01109 	clz	x9, x8
    a944:	2a0903e6 	mov	w6, w9
    a948:	b5fff1c9 	cbnz	x9, a780 <__modti3+0xd0>
    a94c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a950:	54000068 	b.hi	a95c <__modti3+0x2ac>  // b.pmore
    a954:	eb050007 	subs	x7, x0, x5
    a958:	da080021 	sbc	x1, x1, x8
    a95c:	aa0703e0 	mov	x0, x7
    a960:	17ffff81 	b	a764 <__modti3+0xb4>
    a964:	ab000040 	adds	x0, x2, x0
    a968:	8b020002 	add	x2, x0, x2
    a96c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a970:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a974:	17ffff79 	b	a758 <__modti3+0xa8>
    a978:	9ac82042 	lsl	x2, x2, x8
    a97c:	d2800803 	mov	x3, #0x40                  	// #64
    a980:	cb080063 	sub	x3, x3, x8
    a984:	d360fc49 	lsr	x9, x2, #32
    a988:	9ac82027 	lsl	x7, x1, x8
    a98c:	92407c4a 	and	x10, x2, #0xffffffff
    a990:	9ac32426 	lsr	x6, x1, x3
    a994:	9ac32403 	lsr	x3, x0, x3
    a998:	aa070063 	orr	x3, x3, x7
    a99c:	9ac908c1 	udiv	x1, x6, x9
    a9a0:	9ac82007 	lsl	x7, x0, x8
    a9a4:	9b099820 	msub	x0, x1, x9, x6
    a9a8:	9b017d41 	mul	x1, x10, x1
    a9ac:	93c38000 	extr	x0, x0, x3, #32
    a9b0:	eb00003f 	cmp	x1, x0
    a9b4:	540000a9 	b.ls	a9c8 <__modti3+0x318>  // b.plast
    a9b8:	ab000040 	adds	x0, x2, x0
    a9bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a9c0:	8b020006 	add	x6, x0, x2
    a9c4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a9c8:	cb010000 	sub	x0, x0, x1
    a9cc:	9ac90801 	udiv	x1, x0, x9
    a9d0:	9b098026 	msub	x6, x1, x9, x0
    a9d4:	aa0303e0 	mov	x0, x3
    a9d8:	9b017d41 	mul	x1, x10, x1
    a9dc:	b3607cc0 	bfi	x0, x6, #32, #32
    a9e0:	eb00003f 	cmp	x1, x0
    a9e4:	540000a9 	b.ls	a9f8 <__modti3+0x348>  // b.plast
    a9e8:	ab000040 	adds	x0, x2, x0
    a9ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a9f0:	8b020003 	add	x3, x0, x2
    a9f4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a9f8:	cb010000 	sub	x0, x0, x1
    a9fc:	17ffffb0 	b	a8bc <__modti3+0x20c>
    aa00:	d1000969 	sub	x9, x11, #0x2
    aa04:	8b070021 	add	x1, x1, x7
    aa08:	17ffff83 	b	a814 <__modti3+0x164>
    aa0c:	d1000965 	sub	x5, x11, #0x2
    aa10:	8b070063 	add	x3, x3, x7
    aa14:	17ffff74 	b	a7e4 <__modti3+0x134>
    aa18:	d503201f 	nop
    aa1c:	d503201f 	nop

000000000000aa20 <atexit>:
    aa20:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aa24:	d00000a2 	adrp	x2, 20000 <__data_start>
    aa28:	d2800001 	mov	x1, #0x0                   	// #0
    aa2c:	910003fd 	mov	x29, sp
    aa30:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aa34:	f9400442 	ldr	x2, [x2, #8]
    aa38:	17ffdf76 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000aa3c <_fini>:
    aa3c:	d503201f 	nop
    aa40:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aa44:	910003fd 	mov	x29, sp
    aa48:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aa4c:	d65f03c0 	ret
