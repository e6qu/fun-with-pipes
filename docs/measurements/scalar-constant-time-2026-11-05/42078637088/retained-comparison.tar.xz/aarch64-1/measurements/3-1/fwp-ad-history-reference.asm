
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__modti3+0xc0>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	911380a5 	add	x5, x5, #0x4e0
    2a20:	b0000044 	adrp	x4, b000 <__modti3+0xc0>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9113a084 	add	x4, x4, #0x4e8
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10ca8>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2ab4:	91230000 	add	x0, x0, #0x8c0
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0xad0>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91148042 	add	x2, x2, #0x520
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9432a60 	ldr	w0, [x19, #808]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2bfc:	91234000 	add	x0, x0, #0x8d0
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c0c:	9125c000 	add	x0, x0, #0x970
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c24:	91252000 	add	x0, x0, #0x948
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c30:	91246000 	add	x0, x0, #0x918
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c3c:	9123c000 	add	x0, x0, #0x8f0
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <__modti3+0xc0>
    2e34:	913dc021 	add	x1, x1, #0xf70
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2fd0:	910ba000 	add	x0, x0, #0x2e8
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    3098:	913d4021 	add	x1, x1, #0xf50
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    30c4:	9115c2a1 	add	x1, x21, #0x570
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa90>
    30d8:	912580a5 	add	x5, x5, #0x960
    30dc:	9115c2a1 	add	x1, x21, #0x570
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	9115c2b7 	add	x23, x21, #0x570
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	9115c2b5 	add	x21, x21, #0x570
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	9115c2b5 	add	x21, x21, #0x570
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa90>
    3268:	912560a5 	add	x5, x5, #0x958
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3370:	910ba000 	add	x0, x0, #0x2e8
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	910c0021 	add	x1, x1, #0x300
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	910c2021 	add	x1, x1, #0x308
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    34e0:	910c4021 	add	x1, x1, #0x310
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    3538:	aa1303e3 	mov	x3, x19
    353c:	910c6042 	add	x2, x2, #0x318
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3650:	910ba000 	add	x0, x0, #0x2e8
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3670:	910ca000 	add	x0, x0, #0x328
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3708:	910d2000 	add	x0, x0, #0x348
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3718:	910da000 	add	x0, x0, #0x368
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc3e020 	ldr	q0, [x1, #3968]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3818:	910e4000 	add	x0, x0, #0x390
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3888:	910f0000 	add	x0, x0, #0x3c0
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	91104084 	add	x4, x4, #0x410
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	9110a084 	add	x4, x4, #0x428
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	91106084 	add	x4, x4, #0x418
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    3ca8:	9115c042 	add	x2, x2, #0x570
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	9110c021 	add	x1, x1, #0x430
    3d04:	9110e000 	add	x0, x0, #0x438
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	91116042 	add	x2, x2, #0x458
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa90>
    3e0c:	9111c061 	add	x1, x3, #0x470
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    3e1c:	9115c262 	add	x2, x19, #0x570
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa90>
    3e4c:	9112c021 	add	x1, x1, #0x4b0
    3e50:	3dc3e443 	ldr	q3, [x2, #3984]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa90>
    3e7c:	9111c063 	add	x3, x3, #0x470
    3e80:	91144084 	add	x4, x4, #0x510
    3e84:	9115c266 	add	x6, x19, #0x570
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	9115c275 	add	x21, x19, #0x570
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3f68:	91142000 	add	x0, x0, #0x508
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	9115c273 	add	x19, x19, #0x570
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <caf61>:
    3fc4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fc8:	91010041 	add	x1, x2, #0x40
    3fcc:	b9404820 	ldr	w0, [x1, #72]
    3fd0:	34000060 	cbz	w0, 3fdc <caf61+0x18>
    3fd4:	f9402820 	ldr	x0, [x1, #80]
    3fd8:	d65f03c0 	ret
    3fdc:	b9405820 	ldr	w0, [x1, #88]
    3fe0:	340000e0 	cbz	w0, 3ffc <caf61+0x38>
    3fe4:	f9403020 	ldr	x0, [x1, #96]
    3fe8:	91010042 	add	x2, x2, #0x40
    3fec:	52800021 	mov	w1, #0x1                   	// #1
    3ff0:	b9004841 	str	w1, [x2, #72]
    3ff4:	f9002840 	str	x0, [x2, #80]
    3ff8:	d65f03c0 	ret
    3ffc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    4000:	52800024 	mov	w4, #0x1                   	// #1
    4004:	aa0303e0 	mov	x0, x3
    4008:	b9005824 	str	w4, [x1, #88]
    400c:	f9003023 	str	x3, [x1, #96]
    4010:	17fffff6 	b	3fe8 <caf61+0x24>

0000000000004014 <fwp_wake_io>:
    4014:	900000e9 	adrp	x9, 20000 <__data_start>
    4018:	91010122 	add	x2, x9, #0x40
    401c:	f9400001 	ldr	x1, [x0]
    4020:	5280000a 	mov	w10, #0x0                   	// #0
    4024:	f9401446 	ldr	x6, [x2, #40]
    4028:	52800008 	mov	w8, #0x0                   	// #0
    402c:	4f000400 	movi	v0.4s, #0x0
    4030:	52800027 	mov	w7, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b4000321 	cbz	x1, 409c <fwp_wake_io+0x88>
    403c:	f9408c25 	ldr	x5, [x1, #280]
    4040:	39015c27 	strb	w7, [x1, #87]
    4044:	b4000165 	cbz	x5, 4070 <fwp_wake_io+0x5c>
    4048:	a9520c24 	ldp	x4, x3, [x1, #288]
    404c:	b4000364 	cbz	x4, 40b8 <fwp_wake_io+0xa4>
    4050:	f9009483 	str	x3, [x4, #296]
    4054:	f9409423 	ldr	x3, [x1, #296]
    4058:	b4000043 	cbz	x3, 4060 <fwp_wake_io+0x4c>
    405c:	f9009064 	str	x4, [x3, #288]
    4060:	91080023 	add	x3, x1, #0x200
    4064:	f900943f 	str	xzr, [x1, #296]
    4068:	3c918060 	stur	q0, [x3, #-232]
    406c:	f9400001 	ldr	x1, [x0]
    4070:	f9402843 	ldr	x3, [x2, #80]
    4074:	f2001c7f 	tst	x3, #0xff000000ff
    4078:	54fffde1 	b.ne	4034 <fwp_wake_io+0x20>  // b.any
    407c:	39015047 	strb	w7, [x2, #84]
    4080:	f900805f 	str	xzr, [x2, #256]
    4084:	b40001e6 	cbz	x6, 40c0 <fwp_wake_io+0xac>
    4088:	f90080c2 	str	x2, [x6, #256]
    408c:	aa0203e6 	mov	x6, x2
    4090:	52800028 	mov	w8, #0x1                   	// #1
    4094:	aa0103e2 	mov	x2, x1
    4098:	b5fffd21 	cbnz	x1, 403c <fwp_wake_io+0x28>
    409c:	3400006a 	cbz	w10, 40a8 <fwp_wake_io+0x94>
    40a0:	91010120 	add	x0, x9, #0x40
    40a4:	f900180b 	str	x11, [x0, #48]
    40a8:	34000068 	cbz	w8, 40b4 <fwp_wake_io+0xa0>
    40ac:	91010129 	add	x9, x9, #0x40
    40b0:	f9001526 	str	x6, [x9, #40]
    40b4:	d65f03c0 	ret
    40b8:	f90000a3 	str	x3, [x5]
    40bc:	17ffffe7 	b	4058 <fwp_wake_io+0x44>
    40c0:	aa0203eb 	mov	x11, x2
    40c4:	5280002a 	mov	w10, #0x1                   	// #1
    40c8:	17fffff1 	b	408c <fwp_wake_io+0x78>
    40cc:	d503201f 	nop

00000000000040d0 <fwp_tape_buffers_release>:
    40d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40d4:	910003fd 	mov	x29, sp
    40d8:	a90153f3 	stp	x19, x20, [sp, #16]
    40dc:	aa0003f3 	mov	x19, x0
    40e0:	f9401400 	ldr	x0, [x0, #40]
    40e4:	b7f80760 	tbnz	x0, #63, 41d0 <fwp_tape_buffers_release+0x100>
    40e8:	f9401a61 	ldr	x1, [x19, #48]
    40ec:	b7f80301 	tbnz	x1, #63, 414c <fwp_tape_buffers_release+0x7c>
    40f0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40f4:	eb02001f 	cmp	x0, x2
    40f8:	540002a8 	b.hi	414c <fwp_tape_buffers_release+0x7c>  // b.pmore
    40fc:	8b000400 	add	x0, x0, x0, lsl #1
    4100:	d2a00102 	mov	x2, #0x80000               	// #524288
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	cb000042 	sub	x2, x2, x0
    410c:	eb420c3f 	cmp	x1, x2, lsr #3
    4110:	540001e8 	b.hi	414c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4114:	8b010c14 	add	x20, x0, x1, lsl #3
    4118:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    411c:	91146000 	add	x0, x0, #0x518
    4120:	97fffa18 	bl	2980 <getenv@plt>
    4124:	b4000240 	cbz	x0, 416c <fwp_tape_buffers_release+0x9c>
    4128:	39400001 	ldrb	w1, [x0]
    412c:	7100c03f 	cmp	w1, #0x30
    4130:	540001e1 	b.ne	416c <fwp_tape_buffers_release+0x9c>  // b.any
    4134:	39400400 	ldrb	w0, [x0, #1]
    4138:	350001a0 	cbnz	w0, 416c <fwp_tape_buffers_release+0x9c>
    413c:	aa1303e0 	mov	x0, x19
    4140:	a94153f3 	ldp	x19, x20, [sp, #16]
    4144:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4148:	17fffc4e 	b	3280 <fwp_tape_buffers_dispose>
    414c:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4150:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4154:	91146000 	add	x0, x0, #0x518
    4158:	97fffa0a 	bl	2980 <getenv@plt>
    415c:	b4ffff00 	cbz	x0, 413c <fwp_tape_buffers_release+0x6c>
    4160:	39400001 	ldrb	w1, [x0]
    4164:	7100c03f 	cmp	w1, #0x30
    4168:	54fffe60 	b.eq	4134 <fwp_tape_buffers_release+0x64>  // b.none
    416c:	d1000681 	sub	x1, x20, #0x1
    4170:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4174:	eb00003f 	cmp	x1, x0
    4178:	54fffe28 	b.hi	413c <fwp_tape_buffers_release+0x6c>  // b.pmore
    417c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4180:	900000f6 	adrp	x22, 20000 <__data_start>
    4184:	910102d6 	add	x22, x22, #0x40
    4188:	9101a2d5 	add	x21, x22, #0x68
    418c:	aa1503e0 	mov	x0, x21
    4190:	97fffc3c 	bl	3280 <fwp_tape_buffers_dispose>
    4194:	ad400a61 	ldp	q1, q2, [x19]
    4198:	f90052d4 	str	x20, [x22, #160]
    419c:	4f000400 	movi	v0.4s, #0x0
    41a0:	ad000aa1 	stp	q1, q2, [x21]
    41a4:	3dc00a61 	ldr	q1, [x19, #32]
    41a8:	3d800aa1 	str	q1, [x21, #32]
    41ac:	f9401a60 	ldr	x0, [x19, #48]
    41b0:	f9001aa0 	str	x0, [x21, #48]
    41b4:	f9001a7f 	str	xzr, [x19, #48]
    41b8:	ad000260 	stp	q0, q0, [x19]
    41bc:	3d800a60 	str	q0, [x19, #32]
    41c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41cc:	d65f03c0 	ret
    41d0:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    41d4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    41d8:	91146000 	add	x0, x0, #0x518
    41dc:	97fff9e9 	bl	2980 <getenv@plt>
    41e0:	b5fffa40 	cbnz	x0, 4128 <fwp_tape_buffers_release+0x58>
    41e4:	17ffffd6 	b	413c <fwp_tape_buffers_release+0x6c>
    41e8:	d503201f 	nop
    41ec:	d503201f 	nop

00000000000041f0 <fwp_poll_events>:
    41f0:	d10103ff 	sub	sp, sp, #0x40
    41f4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41f8:	f947f400 	ldr	x0, [x0, #4072]
    41fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4200:	910083fd 	add	x29, sp, #0x20
    4204:	a90353f3 	stp	x19, x20, [sp, #48]
    4208:	900000f4 	adrp	x20, 20000 <__data_start>
    420c:	f9400001 	ldr	x1, [x0]
    4210:	f9000fe1 	str	x1, [sp, #24]
    4214:	d2800001 	mov	x1, #0x0                   	// #0
    4218:	97fffd1a 	bl	3680 <fwp_now_ns>
    421c:	91010281 	add	x1, x20, #0x40
    4220:	f9405433 	ldr	x19, [x1, #168]
    4224:	b4000e93 	cbz	x19, 43f4 <fwp_poll_events+0x204>
    4228:	aa1303e1 	mov	x1, x19
    422c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4230:	14000005 	b	4244 <fwp_poll_events+0x54>
    4234:	f9408821 	ldr	x1, [x1, #272]
    4238:	eb03005f 	cmp	x2, x3
    423c:	9a83d042 	csel	x2, x2, x3, le
    4240:	b40000c1 	cbz	x1, 4258 <fwp_poll_events+0x68>
    4244:	f9403423 	ldr	x3, [x1, #104]
    4248:	b6ffff62 	tbz	x2, #63, 4234 <fwp_poll_events+0x44>
    424c:	f9408821 	ldr	x1, [x1, #272]
    4250:	aa0303e2 	mov	x2, x3
    4254:	b5ffff81 	cbnz	x1, 4244 <fwp_poll_events+0x54>
    4258:	b7f80ce2 	tbnz	x2, #63, 43f4 <fwp_poll_events+0x204>
    425c:	cb000042 	sub	x2, x2, x0
    4260:	f100005f 	cmp	x2, #0x0
    4264:	540005cd 	b.le	431c <fwp_poll_events+0x12c>
    4268:	d2869b60 	mov	x0, #0x34db                	// #13531
    426c:	d2884801 	mov	x1, #0x4240                	// #16960
    4270:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4274:	f2a001e1 	movk	x1, #0xf, lsl #16
    4278:	f2dbd040 	movk	x0, #0xde82, lsl #32
    427c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4280:	f2e86360 	movk	x0, #0x431b, lsl #48
    4284:	9b407c40 	smulh	x0, x2, x0
    4288:	9352fc00 	asr	x0, x0, #18
    428c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4290:	9b018802 	msub	x2, x0, x1, x2
    4294:	f100005f 	cmp	x2, #0x0
    4298:	9a800400 	cinc	x0, x0, ne	// ne = any
    429c:	eb03001f 	cmp	x0, x3
    42a0:	54000a0c 	b.gt	43e0 <fwp_poll_events+0x1f0>
    42a4:	340003c0 	cbz	w0, 431c <fwp_poll_events+0x12c>
    42a8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42ac:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42b0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42b4:	9ba27c02 	umull	x2, w0, w2
    42b8:	d366fc43 	lsr	x3, x2, #38
    42bc:	aa0303e2 	mov	x2, x3
    42c0:	1b048063 	msub	w3, w3, w4, w0
    42c4:	9b217c63 	smull	x3, w3, w1
    42c8:	d2800001 	mov	x1, #0x0                   	// #0
    42cc:	910023e0 	add	x0, sp, #0x8
    42d0:	a9008fe2 	stp	x2, x3, [sp, #8]
    42d4:	97fff97b 	bl	28c0 <nanosleep@plt>
    42d8:	91010280 	add	x0, x20, #0x40
    42dc:	f9405413 	ldr	x19, [x0, #168]
    42e0:	97fffce8 	bl	3680 <fwp_now_ns>
    42e4:	aa0003e6 	mov	x6, x0
    42e8:	b50001f3 	cbnz	x19, 4324 <fwp_poll_events+0x134>
    42ec:	d503201f 	nop
    42f0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42f4:	f947f400 	ldr	x0, [x0, #4072]
    42f8:	f9400fe2 	ldr	x2, [sp, #24]
    42fc:	f9400001 	ldr	x1, [x0]
    4300:	eb010042 	subs	x2, x2, x1
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	540008c1 	b.ne	4420 <fwp_poll_events+0x230>  // b.any
    430c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4310:	a94353f3 	ldp	x19, x20, [sp, #48]
    4314:	910103ff 	add	sp, sp, #0x40
    4318:	d65f03c0 	ret
    431c:	97fffcd9 	bl	3680 <fwp_now_ns>
    4320:	aa0003e6 	mov	x6, x0
    4324:	4f000400 	movi	v0.4s, #0x0
    4328:	91010288 	add	x8, x20, #0x40
    432c:	52800027 	mov	w7, #0x1                   	// #1
    4330:	f9403661 	ldr	x1, [x19, #104]
    4334:	aa1303e5 	mov	x5, x19
    4338:	f9408a73 	ldr	x19, [x19, #272]
    433c:	eb06003f 	cmp	x1, x6
    4340:	5400032c 	b.gt	43a4 <fwp_poll_events+0x1b4>
    4344:	394154a0 	ldrb	w0, [x5, #85]
    4348:	36000120 	tbz	w0, #0, 436c <fwp_poll_events+0x17c>
    434c:	f94084a0 	ldr	x0, [x5, #264]
    4350:	b40003c0 	cbz	x0, 43c8 <fwp_poll_events+0x1d8>
    4354:	f9008813 	str	x19, [x0, #272]
    4358:	b4000053 	cbz	x19, 4360 <fwp_poll_events+0x170>
    435c:	f9008660 	str	x0, [x19, #264]
    4360:	910800a0 	add	x0, x5, #0x200
    4364:	390154bf 	strb	wzr, [x5, #85]
    4368:	3c908000 	stur	q0, [x0, #-248]
    436c:	f94030a0 	ldr	x0, [x5, #96]
    4370:	390158a7 	strb	w7, [x5, #86]
    4374:	f100001f 	cmp	x0, #0x0
    4378:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    437c:	5400018d 	b.le	43ac <fwp_poll_events+0x1bc>
    4380:	f94028a0 	ldr	x0, [x5, #80]
    4384:	f2001c1f 	tst	x0, #0xff000000ff
    4388:	540000e1 	b.ne	43a4 <fwp_poll_events+0x1b4>  // b.any
    438c:	f9401500 	ldr	x0, [x8, #40]
    4390:	390150a7 	strb	w7, [x5, #84]
    4394:	f90080bf 	str	xzr, [x5, #256]
    4398:	b40001e0 	cbz	x0, 43d4 <fwp_poll_events+0x1e4>
    439c:	f9001505 	str	x5, [x8, #40]
    43a0:	f9008005 	str	x5, [x0, #256]
    43a4:	b5fffc73 	cbnz	x19, 4330 <fwp_poll_events+0x140>
    43a8:	17ffffd2 	b	42f0 <fwp_poll_events+0x100>
    43ac:	394144a0 	ldrb	w0, [x5, #81]
    43b0:	3707fe80 	tbnz	w0, #0, 4380 <fwp_poll_events+0x190>
    43b4:	394140a0 	ldrb	w0, [x5, #80]
    43b8:	3707fe40 	tbnz	w0, #0, 4380 <fwp_poll_events+0x190>
    43bc:	aa0503e0 	mov	x0, x5
    43c0:	97fffc0c 	bl	33f0 <fwp_cancel_tree.part.0>
    43c4:	17ffffef 	b	4380 <fwp_poll_events+0x190>
    43c8:	91010281 	add	x1, x20, #0x40
    43cc:	f9005433 	str	x19, [x1, #168]
    43d0:	17ffffe2 	b	4358 <fwp_poll_events+0x168>
    43d4:	f9001505 	str	x5, [x8, #40]
    43d8:	f9001905 	str	x5, [x8, #48]
    43dc:	17fffff2 	b	43a4 <fwp_poll_events+0x1b4>
    43e0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    43e4:	d2989362 	mov	x2, #0xc49b                	// #50331
    43e8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    43ec:	f2a00402 	movk	x2, #0x20, lsl #16
    43f0:	17ffffb6 	b	42c8 <fwp_poll_events+0xd8>
    43f4:	97fffadf 	bl	2f70 <fwp_flush>
    43f8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43fc:	f947e863 	ldr	x3, [x3, #4048]
    4400:	d2800562 	mov	x2, #0x2b                  	// #43
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    440c:	9114c000 	add	x0, x0, #0x530
    4410:	f9400063 	ldr	x3, [x3]
    4414:	97fff937 	bl	28f0 <fwrite@plt>
    4418:	52800ca0 	mov	w0, #0x65                  	// #101
    441c:	97fff8a1 	bl	26a0 <exit@plt>
    4420:	97fff8f4 	bl	27f0 <__stack_chk_fail@plt>

0000000000004424 <fwp_rc_wide_dup>:
    4424:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4428:	910003fd 	mov	x29, sp
    442c:	a90153f3 	stp	x19, x20, [sp, #16]
    4430:	aa0003f3 	mov	x19, x0
    4434:	ca404400 	eor	x0, x0, x0, lsr #17
    4438:	f90013f5 	str	x21, [sp, #32]
    443c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    4440:	ca402400 	eor	x0, x0, x0, lsr #9
    4444:	9115c2a2 	add	x2, x21, #0x570
    4448:	92401c00 	and	x0, x0, #0xff
    444c:	910a2403 	add	x3, x0, #0x289
    4450:	8b000c40 	add	x0, x2, x0, lsl #3
    4454:	8b030c54 	add	x20, x2, x3, lsl #3
    4458:	f94a2401 	ldr	x1, [x0, #5192]
    445c:	b50000a1 	cbnz	x1, 4470 <fwp_rc_wide_dup+0x4c>
    4460:	1400002d 	b	4514 <fwp_rc_wide_dup+0xf0>
    4464:	91004034 	add	x20, x1, #0x10
    4468:	f9400821 	ldr	x1, [x1, #16]
    446c:	b4000241 	cbz	x1, 44b4 <fwp_rc_wide_dup+0x90>
    4470:	f9400022 	ldr	x2, [x1]
    4474:	eb02027f 	cmp	x19, x2
    4478:	54ffff61 	b.ne	4464 <fwp_rc_wide_dup+0x40>  // b.any
    447c:	f9400281 	ldr	x1, [x20]
    4480:	39400260 	ldrb	w0, [x19]
    4484:	7103f81f 	cmp	w0, #0xfe
    4488:	54000220 	b.eq	44cc <fwp_rc_wide_dup+0xa8>  // b.none
    448c:	b40001a1 	cbz	x1, 44c0 <fwp_rc_wide_dup+0x9c>
    4490:	f9400420 	ldr	x0, [x1, #8]
    4494:	b100041f 	cmn	x0, #0x1
    4498:	540004a0 	b.eq	452c <fwp_rc_wide_dup+0x108>  // b.none
    449c:	91000400 	add	x0, x0, #0x1
    44a0:	f9000420 	str	x0, [x1, #8]
    44a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44a8:	f94013f5 	ldr	x21, [sp, #32]
    44ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44b0:	d65f03c0 	ret
    44b4:	39400260 	ldrb	w0, [x19]
    44b8:	7103f81f 	cmp	w0, #0xfe
    44bc:	540000a0 	b.eq	44d0 <fwp_rc_wide_dup+0xac>  // b.none
    44c0:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    44c4:	91162000 	add	x0, x0, #0x588
    44c8:	97fffc0e 	bl	3500 <fwp_trap>
    44cc:	b5000281 	cbnz	x1, 451c <fwp_rc_wide_dup+0xf8>
    44d0:	d2800300 	mov	x0, #0x18                  	// #24
    44d4:	97fff8af 	bl	2790 <malloc@plt>
    44d8:	b4000280 	cbz	x0, 4528 <fwp_rc_wide_dup+0x104>
    44dc:	d2801fe1 	mov	x1, #0xff                  	// #255
    44e0:	a9000413 	stp	x19, x1, [x0]
    44e4:	9115c2b5 	add	x21, x21, #0x570
    44e8:	f900081f 	str	xzr, [x0, #16]
    44ec:	12800001 	mov	w1, #0xffffffff            	// #-1
    44f0:	f9000280 	str	x0, [x20]
    44f4:	39000261 	strb	w1, [x19]
    44f8:	f94e26a0 	ldr	x0, [x21, #7240]
    44fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4500:	91000400 	add	x0, x0, #0x1
    4504:	f90e26a0 	str	x0, [x21, #7240]
    4508:	f94013f5 	ldr	x21, [sp, #32]
    450c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4510:	d65f03c0 	ret
    4514:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4518:	17ffffda 	b	4480 <fwp_rc_wide_dup+0x5c>
    451c:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4520:	91158000 	add	x0, x0, #0x560
    4524:	97fffbf7 	bl	3500 <fwp_trap>
    4528:	97fffaa2 	bl	2fb0 <fwp_heap_oom>
    452c:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4530:	9116c000 	add	x0, x0, #0x5b0
    4534:	97fffbf3 	bl	3500 <fwp_trap>
    4538:	d503201f 	nop
    453c:	d503201f 	nop

0000000000004540 <fwp_rc_forget_slot>:
    4540:	aa0003e1 	mov	x1, x0
    4544:	39400000 	ldrb	w0, [x0]
    4548:	7103fc1f 	cmp	w0, #0xff
    454c:	54000040 	b.eq	4554 <fwp_rc_forget_slot+0x14>  // b.none
    4550:	d65f03c0 	ret
    4554:	ca414420 	eor	x0, x1, x1, lsr #17
    4558:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    455c:	ca402400 	eor	x0, x0, x0, lsr #9
    4560:	910003fd 	mov	x29, sp
    4564:	92401c00 	and	x0, x0, #0xff
    4568:	f9000bf3 	str	x19, [sp, #16]
    456c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4570:	9115c262 	add	x2, x19, #0x570
    4574:	910a2403 	add	x3, x0, #0x289
    4578:	8b000c40 	add	x0, x2, x0, lsl #3
    457c:	8b030c43 	add	x3, x2, x3, lsl #3
    4580:	f94a2400 	ldr	x0, [x0, #5192]
    4584:	b50000a0 	cbnz	x0, 4598 <fwp_rc_forget_slot+0x58>
    4588:	14000011 	b	45cc <fwp_rc_forget_slot+0x8c>
    458c:	91004003 	add	x3, x0, #0x10
    4590:	f9400800 	ldr	x0, [x0, #16]
    4594:	b40001c0 	cbz	x0, 45cc <fwp_rc_forget_slot+0x8c>
    4598:	f9400002 	ldr	x2, [x0]
    459c:	eb02003f 	cmp	x1, x2
    45a0:	54ffff61 	b.ne	458c <fwp_rc_forget_slot+0x4c>  // b.any
    45a4:	f9400801 	ldr	x1, [x0, #16]
    45a8:	9115c273 	add	x19, x19, #0x570
    45ac:	f9000061 	str	x1, [x3]
    45b0:	97fff8c0 	bl	28b0 <free@plt>
    45b4:	f94e2660 	ldr	x0, [x19, #7240]
    45b8:	d1000400 	sub	x0, x0, #0x1
    45bc:	f90e2660 	str	x0, [x19, #7240]
    45c0:	f9400bf3 	ldr	x19, [sp, #16]
    45c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45c8:	d65f03c0 	ret
    45cc:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    45d0:	91162000 	add	x0, x0, #0x588
    45d4:	97fffbcb 	bl	3500 <fwp_trap>
    45d8:	d503201f 	nop
    45dc:	d503201f 	nop

00000000000045e0 <fwp_rc_prepare_chunk>:
    45e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e4:	910003fd 	mov	x29, sp
    45e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    45ec:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc70>
    45f0:	9115c2c2 	add	x2, x22, #0x570
    45f4:	b9401c03 	ldr	w3, [x0, #28]
    45f8:	aa0103f5 	mov	x21, x1
    45fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4600:	aa0003f4 	mov	x20, x0
    4604:	f94e2440 	ldr	x0, [x2, #7240]
    4608:	b4000440 	cbz	x0, 4690 <fwp_rc_prepare_chunk+0xb0>
    460c:	d2800013 	mov	x19, #0x0                   	// #0
    4610:	35000203 	cbnz	w3, 4650 <fwp_rc_prepare_chunk+0x70>
    4614:	b4000361 	cbz	x1, 4680 <fwp_rc_prepare_chunk+0xa0>
    4618:	f9401280 	ldr	x0, [x20, #32]
    461c:	97fff8a5 	bl	28b0 <free@plt>
    4620:	aa1503e0 	mov	x0, x21
    4624:	d2800021 	mov	x1, #0x1                   	// #1
    4628:	97fff86a 	bl	27d0 <calloc@plt>
    462c:	f9001280 	str	x0, [x20, #32]
    4630:	b5000460 	cbnz	x0, 46bc <fwp_rc_prepare_chunk+0xdc>
    4634:	97fffa5f 	bl	2fb0 <fwp_heap_oom>
    4638:	97ffffc2 	bl	4540 <fwp_rc_forget_slot>
    463c:	91000673 	add	x19, x19, #0x1
    4640:	b9401e83 	ldr	w3, [x20, #28]
    4644:	eb13007f 	cmp	x3, x19
    4648:	54000169 	b.ls	4674 <fwp_rc_prepare_chunk+0x94>  // b.plast
    464c:	d503201f 	nop
    4650:	f9401283 	ldr	x3, [x20, #32]
    4654:	8b130060 	add	x0, x3, x19
    4658:	38736863 	ldrb	w3, [x3, x19]
    465c:	7103fc7f 	cmp	w3, #0xff
    4660:	54fffec0 	b.eq	4638 <fwp_rc_prepare_chunk+0x58>  // b.none
    4664:	b9401e83 	ldr	w3, [x20, #28]
    4668:	91000673 	add	x19, x19, #0x1
    466c:	eb13007f 	cmp	x3, x19
    4670:	54ffff08 	b.hi	4650 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4674:	eb0302bf 	cmp	x21, x3
    4678:	54000121 	b.ne	469c <fwp_rc_prepare_chunk+0xbc>  // b.any
    467c:	b5000335 	cbnz	x21, 46e0 <fwp_rc_prepare_chunk+0x100>
    4680:	a94153f3 	ldp	x19, x20, [sp, #16]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	2a0303e3 	mov	w3, w3
    4694:	eb0302bf 	cmp	x21, x3
    4698:	54ffff20 	b.eq	467c <fwp_rc_prepare_chunk+0x9c>  // b.none
    469c:	9115c2c2 	add	x2, x22, #0x570
    46a0:	f9401280 	ldr	x0, [x20, #32]
    46a4:	f94e2841 	ldr	x1, [x2, #7248]
    46a8:	cb030021 	sub	x1, x1, x3
    46ac:	f90e2841 	str	x1, [x2, #7248]
    46b0:	97fff880 	bl	28b0 <free@plt>
    46b4:	b5fffb75 	cbnz	x21, 4620 <fwp_rc_prepare_chunk+0x40>
    46b8:	f900129f 	str	xzr, [x20, #32]
    46bc:	9115c2d6 	add	x22, x22, #0x570
    46c0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46c4:	b9001e95 	str	w21, [x20, #28]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	8b150000 	add	x0, x0, x21
    46d0:	f90e2ac0 	str	x0, [x22, #7248]
    46d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	f9401280 	ldr	x0, [x20, #32]
    46e4:	aa1503e2 	mov	x2, x21
    46e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46ec:	52800001 	mov	w1, #0x0                   	// #0
    46f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f8:	17fff832 	b	27c0 <memset@plt>
    46fc:	d503201f 	nop

0000000000004700 <fwp_heap_refill>:
    4700:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4704:	910003fd 	mov	x29, sp
    4708:	a9025bf5 	stp	x21, x22, [sp, #32]
    470c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    4710:	9115c2b5 	add	x21, x21, #0x570
    4714:	aa0003f6 	mov	x22, x0
    4718:	d2800020 	mov	x0, #0x1                   	// #1
    471c:	a90153f3 	stp	x19, x20, [sp, #16]
    4720:	a90363f7 	stp	x23, x24, [sp, #48]
    4724:	2a0103f7 	mov	w23, w1
    4728:	2a0203f8 	mov	w24, w2
    472c:	97fffa61 	bl	30b0 <fwp_heap_chunks>
    4730:	aa0003f3 	mov	x19, x0
    4734:	f949fea2 	ldr	x2, [x21, #5112]
    4738:	8b000800 	add	x0, x0, x0, lsl #2
    473c:	2a1703e1 	mov	w1, w23
    4740:	52800025 	mov	w5, #0x1                   	// #1
    4744:	d37df000 	lsl	x0, x0, #3
    4748:	910f0021 	add	x1, x1, #0x3c0
    474c:	8b000054 	add	x20, x2, x0
    4750:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4754:	52a00024 	mov	w4, #0x10000               	// #65536
    4758:	38206845 	strb	w5, [x2, x0]
    475c:	aa1403e0 	mov	x0, x20
    4760:	39000698 	strb	w24, [x20, #1]
    4764:	39000a97 	strb	w23, [x20, #2]
    4768:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    476c:	b9000681 	str	w1, [x20, #4]
    4770:	2a0103e5 	mov	w5, w1
    4774:	8b0300a2 	add	x2, x5, x3
    4778:	1ac10881 	udiv	w1, w4, w1
    477c:	9ac50842 	udiv	x2, x2, x5
    4780:	b9000a81 	str	w1, [x20, #8]
    4784:	92404021 	and	x1, x1, #0x1ffff
    4788:	b9001a82 	str	w2, [x20, #24]
    478c:	97ffff95 	bl	45e0 <fwp_rc_prepare_chunk>
    4790:	f949daa0 	ldr	x0, [x21, #5040]
    4794:	29408a81 	ldp	w1, w2, [x20, #4]
    4798:	8b134000 	add	x0, x0, x19, lsl #16
    479c:	a94153f3 	ldp	x19, x20, [sp, #16]
    47a0:	8b214003 	add	x3, x0, w1, uxtw
    47a4:	9ba20021 	umaddl	x1, w1, w2, x0
    47a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47ac:	a90086c3 	stp	x3, x1, [x22, #8]
    47b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47b4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47b8:	d65f03c0 	ret
    47bc:	d503201f 	nop

00000000000047c0 <fwp_mem_free>:
    47c0:	b40003c0 	cbz	x0, 4838 <fwp_mem_free+0x78>
    47c4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47c8:	910003fd 	mov	x29, sp
    47cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    47d0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    47d4:	9115c2a1 	add	x1, x21, #0x570
    47d8:	a90153f3 	stp	x19, x20, [sp, #16]
    47dc:	aa0003f3 	mov	x19, x0
    47e0:	f949d823 	ldr	x3, [x1, #5040]
    47e4:	f949ec22 	ldr	x2, [x1, #5080]
    47e8:	cb030000 	sub	x0, x0, x3
    47ec:	eb02401f 	cmp	x0, x2, lsl #16
    47f0:	540001c2 	b.cs	4828 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47f4:	d350fc16 	lsr	x22, x0, #16
    47f8:	a90363f7 	stp	x23, x24, [sp, #48]
    47fc:	f949fc22 	ldr	x2, [x1, #5112]
    4800:	8b160ad4 	add	x20, x22, x22, lsl #2
    4804:	d37df294 	lsl	x20, x20, #3
    4808:	ab140057 	adds	x23, x2, x20
    480c:	540000c0 	b.eq	4824 <fwp_mem_free+0x64>  // b.none
    4810:	38746842 	ldrb	w2, [x2, x20]
    4814:	7100045f 	cmp	w2, #0x1
    4818:	54000120 	b.eq	483c <fwp_mem_free+0x7c>  // b.none
    481c:	7100085f 	cmp	w2, #0x2
    4820:	540005e0 	b.eq	48dc <fwp_mem_free+0x11c>  // b.none
    4824:	a94363f7 	ldp	x23, x24, [sp, #48]
    4828:	a94153f3 	ldp	x19, x20, [sp, #16]
    482c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4830:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4834:	d65f03c0 	ret
    4838:	d65f03c0 	ret
    483c:	f94012f8 	ldr	x24, [x23, #32]
    4840:	b94006e1 	ldr	w1, [x23, #4]
    4844:	f90023f9 	str	x25, [sp, #64]
    4848:	2a0103e2 	mov	w2, w1
    484c:	394006f9 	ldrb	w25, [x23, #1]
    4850:	39400af4 	ldrb	w20, [x23, #2]
    4854:	b4000158 	cbz	x24, 487c <fwp_mem_free+0xbc>
    4858:	92403e76 	and	x22, x19, #0xffff
    485c:	9ac20ad6 	udiv	x22, x22, x2
    4860:	38766b01 	ldrb	w1, [x24, x22]
    4864:	8b160300 	add	x0, x24, x22
    4868:	7103fc3f 	cmp	w1, #0xff
    486c:	54000980 	b.eq	499c <fwp_mem_free+0x1dc>  // b.none
    4870:	38366b1f 	strb	wzr, [x24, x22]
    4874:	b94006e1 	ldr	w1, [x23, #4]
    4878:	2a0103e2 	mov	w2, w1
    487c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4880:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4884:	cb390000 	sub	x0, x0, w25, uxtb
    4888:	8b340074 	add	x20, x3, w20, uxtb
    488c:	9115c2b5 	add	x21, x21, #0x570
    4890:	1e630021 	ucvtf	d1, w1
    4894:	d37ae400 	lsl	x0, x0, #6
    4898:	8b140c14 	add	x20, x0, x20, lsl #3
    489c:	a94363f7 	ldp	x23, x24, [sp, #48]
    48a0:	f8746aa0 	ldr	x0, [x21, x20]
    48a4:	f94023f9 	ldr	x25, [sp, #64]
    48a8:	aa2003e0 	mvn	x0, x0
    48ac:	fd4a22a0 	ldr	d0, [x21, #5184]
    48b0:	f9000260 	str	x0, [x19]
    48b4:	f8346ab3 	str	x19, [x21, x20]
    48b8:	f94a12a0 	ldr	x0, [x21, #5152]
    48bc:	1e612800 	fadd	d0, d0, d1
    48c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48c4:	cb020000 	sub	x0, x0, x2
    48c8:	f90a12a0 	str	x0, [x21, #5152]
    48cc:	fd0a22a0 	str	d0, [x21, #5184]
    48d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48d8:	d65f03c0 	ret
    48dc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    48e0:	8b000063 	add	x3, x3, x0
    48e4:	eb03027f 	cmp	x19, x3
    48e8:	54fff9e1 	b.ne	4824 <fwp_mem_free+0x64>  // b.any
    48ec:	fd400ae1 	ldr	d1, [x23, #16]
    48f0:	fd4a2020 	ldr	d0, [x1, #5184]
    48f4:	f9400ae0 	ldr	x0, [x23, #16]
    48f8:	7e61d821 	ucvtf	d1, d1
    48fc:	f94a1022 	ldr	x2, [x1, #5152]
    4900:	f94012f3 	ldr	x19, [x23, #32]
    4904:	1e612800 	fadd	d0, d0, d1
    4908:	cb000042 	sub	x2, x2, x0
    490c:	f90a1022 	str	x2, [x1, #5152]
    4910:	fd0a2020 	str	d0, [x1, #5184]
    4914:	b40000b3 	cbz	x19, 4928 <fwp_mem_free+0x168>
    4918:	39400260 	ldrb	w0, [x19]
    491c:	7103fc1f 	cmp	w0, #0xff
    4920:	54000380 	b.eq	4990 <fwp_mem_free+0x1d0>  // b.none
    4924:	3900027f 	strb	wzr, [x19]
    4928:	b9400ee2 	ldr	w2, [x23, #12]
    492c:	b4000142 	cbz	x2, 4954 <fwp_mem_free+0x194>
    4930:	9115c2a1 	add	x1, x21, #0x570
    4934:	8b160040 	add	x0, x2, x22
    4938:	8b000800 	add	x0, x0, x0, lsl #2
    493c:	f949fc21 	ldr	x1, [x1, #5112]
    4940:	8b140034 	add	x20, x1, x20
    4944:	8b000c20 	add	x0, x1, x0, lsl #3
    4948:	3802869f 	strb	wzr, [x20], #40
    494c:	eb00029f 	cmp	x20, x0
    4950:	54ffffc1 	b.ne	4948 <fwp_mem_free+0x188>  // b.any
    4954:	9115c2a0 	add	x0, x21, #0x570
    4958:	f94a1801 	ldr	x1, [x0, #5168]
    495c:	f949f803 	ldr	x3, [x0, #5104]
    4960:	8b020021 	add	x1, x1, x2
    4964:	f90a1801 	str	x1, [x0, #5168]
    4968:	eb16007f 	cmp	x3, x22
    496c:	54000049 	b.ls	4974 <fwp_mem_free+0x1b4>  // b.plast
    4970:	f909f816 	str	x22, [x0, #5104]
    4974:	9115c2b5 	add	x21, x21, #0x570
    4978:	f949f6a0 	ldr	x0, [x21, #5096]
    497c:	eb16001f 	cmp	x0, x22
    4980:	54fff529 	b.ls	4824 <fwp_mem_free+0x64>  // b.plast
    4984:	a94363f7 	ldp	x23, x24, [sp, #48]
    4988:	f909f6b6 	str	x22, [x21, #5096]
    498c:	17ffffa7 	b	4828 <fwp_mem_free+0x68>
    4990:	aa1303e0 	mov	x0, x19
    4994:	97fffeeb 	bl	4540 <fwp_rc_forget_slot>
    4998:	17ffffe3 	b	4924 <fwp_mem_free+0x164>
    499c:	97fffee9 	bl	4540 <fwp_rc_forget_slot>
    49a0:	17ffffb4 	b	4870 <fwp_mem_free+0xb0>

00000000000049a4 <fwp_heap_alloc_big>:
    49a4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49a8:	910003fd 	mov	x29, sp
    49ac:	a90153f3 	stp	x19, x20, [sp, #16]
    49b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49b4:	a90363f7 	stp	x23, x24, [sp, #48]
    49b8:	aa0003f7 	mov	x23, x0
    49bc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49c4:	eb0002ff 	cmp	x23, x0
    49c8:	54000888 	b.hi	4ad8 <fwp_heap_alloc_big+0x134>  // b.pmore
    49cc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49d0:	8b0002f4 	add	x20, x23, x0
    49d4:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc70>
    49d8:	9115c359 	add	x25, x26, #0x570
    49dc:	d350fe94 	lsr	x20, x20, #16
    49e0:	2a0103f5 	mov	w21, w1
    49e4:	aa1403e0 	mov	x0, x20
    49e8:	97fff9b2 	bl	30b0 <fwp_heap_chunks>
    49ec:	f949ff22 	ldr	x2, [x25, #5112]
    49f0:	8b000813 	add	x19, x0, x0, lsl #2
    49f4:	aa0003f8 	mov	x24, x0
    49f8:	52800043 	mov	w3, #0x2                   	// #2
    49fc:	d37df273 	lsl	x19, x19, #3
    4a00:	d2800021 	mov	x1, #0x1                   	// #1
    4a04:	8b130040 	add	x0, x2, x19
    4a08:	38336843 	strb	w3, [x2, x19]
    4a0c:	39000415 	strb	w21, [x0, #1]
    4a10:	b9000c14 	str	w20, [x0, #12]
    4a14:	f9000817 	str	x23, [x0, #16]
    4a18:	97fffef2 	bl	45e0 <fwp_rc_prepare_chunk>
    4a1c:	f100069f 	cmp	x20, #0x1
    4a20:	54000269 	b.ls	4a6c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a24:	8b180294 	add	x20, x20, x24
    4a28:	9100a273 	add	x19, x19, #0x28
    4a2c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a30:	5280007b 	mov	w27, #0x3                   	// #3
    4a34:	8b140a94 	add	x20, x20, x20, lsl #2
    4a38:	2a1803fc 	mov	w28, w24
    4a3c:	9adb2296 	lsl	x22, x20, x27
    4a40:	f949ff35 	ldr	x21, [x25, #5112]
    4a44:	d2800001 	mov	x1, #0x0                   	// #0
    4a48:	8b1302b4 	add	x20, x21, x19
    4a4c:	aa1403e0 	mov	x0, x20
    4a50:	97fffee4 	bl	45e0 <fwp_rc_prepare_chunk>
    4a54:	38336abb 	strb	w27, [x21, x19]
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	b9000e9c 	str	w28, [x20, #12]
    4a60:	eb1302df 	cmp	x22, x19
    4a64:	54fffee1 	b.ne	4a40 <fwp_heap_alloc_big+0x9c>  // b.any
    4a68:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a6c:	9115c353 	add	x19, x26, #0x570
    4a70:	aa1703e2 	mov	x2, x23
    4a74:	52800001 	mov	w1, #0x0                   	// #0
    4a78:	f949da60 	ldr	x0, [x19, #5040]
    4a7c:	8b184018 	add	x24, x0, x24, lsl #16
    4a80:	aa1803e0 	mov	x0, x24
    4a84:	97fff74f 	bl	27c0 <memset@plt>
    4a88:	f94a1260 	ldr	x0, [x19, #5152]
    4a8c:	ab170000 	adds	x0, x0, x23
    4a90:	54000242 	b.cs	4ad8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a94:	f94a1661 	ldr	x1, [x19, #5160]
    4a98:	f90a1260 	str	x0, [x19, #5152]
    4a9c:	eb01001f 	cmp	x0, x1
    4aa0:	54000049 	b.ls	4aa8 <fwp_heap_alloc_big+0x104>  // b.plast
    4aa4:	f90a1660 	str	x0, [x19, #5160]
    4aa8:	9115c35a 	add	x26, x26, #0x570
    4aac:	9e6202e0 	scvtf	d0, x23
    4ab0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ab4:	aa1803e0 	mov	x0, x24
    4ab8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4abc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ac0:	1e602820 	fadd	d0, d1, d0
    4ac4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ac8:	fd0a1f40 	str	d0, [x26, #5176]
    4acc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ad0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4ad4:	d65f03c0 	ret
    4ad8:	a90573fb 	stp	x27, x28, [sp, #80]
    4adc:	97fff935 	bl	2fb0 <fwp_heap_oom>

0000000000004ae0 <fwp_heap_alloc_slow>:
    4ae0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ae4:	910003fd 	mov	x29, sp
    4ae8:	a90153f3 	stp	x19, x20, [sp, #16]
    4aec:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    4af0:	9115c262 	add	x2, x19, #0x570
    4af4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4af8:	aa0003f5 	mov	x21, x0
    4afc:	2a0103f4 	mov	w20, w1
    4b00:	b953a440 	ldr	w0, [x2, #5028]
    4b04:	34000600 	cbz	w0, 4bc4 <fwp_heap_alloc_slow+0xe4>
    4b08:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b0c:	54000628 	b.hi	4bd0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b10:	91003ea0 	add	x0, x21, #0xf
    4b14:	9115c262 	add	x2, x19, #0x570
    4b18:	f9001bf7 	str	x23, [sp, #48]
    4b1c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b20:	8b401040 	add	x0, x2, x0, lsr #4
    4b24:	cb34c084 	sub	x4, x4, w20, sxtw
    4b28:	d37ae484 	lsl	x4, x4, #6
    4b2c:	397e8003 	ldrb	w3, [x0, #4000]
    4b30:	910f0060 	add	x0, x3, #0x3c0
    4b34:	aa0303e1 	mov	x1, x3
    4b38:	8b030463 	add	x3, x3, x3, lsl #1
    4b3c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b40:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b44:	2a1703f6 	mov	w22, w23
    4b48:	f8636844 	ldr	x4, [x2, x3]
    4b4c:	b40004e4 	cbz	x4, 4be8 <fwp_heap_alloc_slow+0x108>
    4b50:	f9400080 	ldr	x0, [x4]
    4b54:	aa2003e0 	mvn	x0, x0
    4b58:	f8236840 	str	x0, [x2, x3]
    4b5c:	7100069f 	cmp	w20, #0x1
    4b60:	aa0403e0 	mov	x0, x4
    4b64:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b68:	52800001 	mov	w1, #0x0                   	// #0
    4b6c:	97fff715 	bl	27c0 <memset@plt>
    4b70:	aa0003e4 	mov	x4, x0
    4b74:	9115c260 	add	x0, x19, #0x570
    4b78:	f94a1001 	ldr	x1, [x0, #5152]
    4b7c:	ab160021 	adds	x1, x1, x22
    4b80:	540005c2 	b.cs	4c38 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b84:	f94a1402 	ldr	x2, [x0, #5160]
    4b88:	f90a1001 	str	x1, [x0, #5152]
    4b8c:	eb02003f 	cmp	x1, x2
    4b90:	54000049 	b.ls	4b98 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b94:	f90a1401 	str	x1, [x0, #5160]
    4b98:	9115c273 	add	x19, x19, #0x570
    4b9c:	1e6302e1 	ucvtf	d1, w23
    4ba0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba4:	aa0403e0 	mov	x0, x4
    4ba8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bac:	f9401bf7 	ldr	x23, [sp, #48]
    4bb0:	1e612800 	fadd	d0, d0, d1
    4bb4:	fd0a1e60 	str	d0, [x19, #5176]
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bc0:	d65f03c0 	ret
    4bc4:	97fffc90 	bl	3e04 <fwp_heap_init>
    4bc8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bcc:	54fffa29 	b.ls	4b10 <fwp_heap_alloc_slow+0x30>  // b.plast
    4bd0:	2a1403e1 	mov	w1, w20
    4bd4:	aa1503e0 	mov	x0, x21
    4bd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bdc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4be0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4be4:	17ffff70 	b	49a4 <fwp_heap_alloc_big>
    4be8:	8b030042 	add	x2, x2, x3
    4bec:	f9400444 	ldr	x4, [x2, #8]
    4bf0:	b4000104 	cbz	x4, 4c10 <fwp_heap_alloc_slow+0x130>
    4bf4:	f9400840 	ldr	x0, [x2, #16]
    4bf8:	cb040000 	sub	x0, x0, x4
    4bfc:	eb16001f 	cmp	x0, x22
    4c00:	54000083 	b.cc	4c10 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c04:	8b160080 	add	x0, x4, x22
    4c08:	f9000440 	str	x0, [x2, #8]
    4c0c:	17ffffd4 	b	4b5c <fwp_heap_alloc_slow+0x7c>
    4c10:	52800302 	mov	w2, #0x18                  	// #24
    4c14:	52807804 	mov	w4, #0x3c0                 	// #960
    4c18:	9115c260 	add	x0, x19, #0x570
    4c1c:	9ba27c23 	umull	x3, w1, w2
    4c20:	2a1403e2 	mov	w2, w20
    4c24:	9b240e84 	smaddl	x4, w20, w4, x3
    4c28:	8b040000 	add	x0, x0, x4
    4c2c:	97fffeb5 	bl	4700 <fwp_heap_refill>
    4c30:	aa0003e4 	mov	x4, x0
    4c34:	17ffffca 	b	4b5c <fwp_heap_alloc_slow+0x7c>
    4c38:	97fff8de 	bl	2fb0 <fwp_heap_oom>
    4c3c:	d503201f 	nop

0000000000004c40 <fwp_heap_alloc>:
    4c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c44:	f140101f 	cmp	x0, #0x4, lsl #12
    4c48:	910003fd 	mov	x29, sp
    4c4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c50:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    4c54:	9115c293 	add	x19, x20, #0x570
    4c58:	b953a662 	ldr	w2, [x19, #5028]
    4c5c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c60:	54000640 	b.eq	4d28 <fwp_heap_alloc+0xe8>  // b.none
    4c64:	91003c03 	add	x3, x0, #0xf
    4c68:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c6c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c70:	8b431263 	add	x3, x19, x3, lsr #4
    4c74:	cb21c042 	sub	x2, x2, w1, sxtw
    4c78:	d37ae442 	lsl	x2, x2, #6
    4c7c:	397e8063 	ldrb	w3, [x3, #4000]
    4c80:	910f0064 	add	x4, x3, #0x3c0
    4c84:	8b030463 	add	x3, x3, x3, lsl #1
    4c88:	8b030c43 	add	x3, x2, x3, lsl #3
    4c8c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c90:	2a1603f5 	mov	w21, w22
    4c94:	f8636a64 	ldr	x4, [x19, x3]
    4c98:	b4000384 	cbz	x4, 4d08 <fwp_heap_alloc+0xc8>
    4c9c:	f9400085 	ldr	x5, [x4]
    4ca0:	7100043f 	cmp	w1, #0x1
    4ca4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ca8:	aa0403e0 	mov	x0, x4
    4cac:	aa2503e5 	mvn	x5, x5
    4cb0:	52800001 	mov	w1, #0x0                   	// #0
    4cb4:	f8236a65 	str	x5, [x19, x3]
    4cb8:	97fff6c2 	bl	27c0 <memset@plt>
    4cbc:	aa0003e4 	mov	x4, x0
    4cc0:	f94a1260 	ldr	x0, [x19, #5152]
    4cc4:	ab150000 	adds	x0, x0, x21
    4cc8:	54000442 	b.cs	4d50 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ccc:	f94a1661 	ldr	x1, [x19, #5160]
    4cd0:	f90a1260 	str	x0, [x19, #5152]
    4cd4:	eb01001f 	cmp	x0, x1
    4cd8:	54000049 	b.ls	4ce0 <fwp_heap_alloc+0xa0>  // b.plast
    4cdc:	f90a1660 	str	x0, [x19, #5160]
    4ce0:	9115c294 	add	x20, x20, #0x570
    4ce4:	1e6302c1 	ucvtf	d1, w22
    4ce8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cec:	aa0403e0 	mov	x0, x4
    4cf0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4cf4:	1e612800 	fadd	d0, d0, d1
    4cf8:	fd0a1e80 	str	d0, [x20, #5176]
    4cfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d04:	d65f03c0 	ret
    4d08:	8b030263 	add	x3, x19, x3
    4d0c:	f9400464 	ldr	x4, [x3, #8]
    4d10:	b40000a4 	cbz	x4, 4d24 <fwp_heap_alloc+0xe4>
    4d14:	f9400862 	ldr	x2, [x3, #16]
    4d18:	cb040042 	sub	x2, x2, x4
    4d1c:	eb15005f 	cmp	x2, x21
    4d20:	540000a2 	b.cs	4d34 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d30:	17ffff6c 	b	4ae0 <fwp_heap_alloc_slow>
    4d34:	7100043f 	cmp	w1, #0x1
    4d38:	8b150085 	add	x5, x4, x21
    4d3c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d40:	52800001 	mov	w1, #0x0                   	// #0
    4d44:	aa0403e0 	mov	x0, x4
    4d48:	f9000465 	str	x5, [x3, #8]
    4d4c:	17ffffdb 	b	4cb8 <fwp_heap_alloc+0x78>
    4d50:	97fff898 	bl	2fb0 <fwp_heap_oom>

0000000000004d54 <fwp_apply>:
    4d54:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d58:	aa0003e6 	mov	x6, x0
    4d5c:	910003fd 	mov	x29, sp
    4d60:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d64:	f947f463 	ldr	x3, [x3, #4072]
    4d68:	a90153f3 	stp	x19, x20, [sp, #16]
    4d6c:	aa0203f4 	mov	x20, x2
    4d70:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d74:	2a0103f5 	mov	w21, w1
    4d78:	52800033 	mov	w19, #0x1                   	// #1
    4d7c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d80:	900000f7 	adrp	x23, 20000 <__data_start>
    4d84:	910102f7 	add	x23, x23, #0x40
    4d88:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d8c:	d100c3ff 	sub	sp, sp, #0x30
    4d90:	f9400060 	ldr	x0, [x3]
    4d94:	f81f83a0 	stur	x0, [x29, #-8]
    4d98:	d2800000 	mov	x0, #0x0                   	// #0
    4d9c:	294058c3 	ldp	w3, w22, [x6]
    4da0:	910003f8 	mov	x24, sp
    4da4:	f9401ee0 	ldr	x0, [x23, #56]
    4da8:	710002df 	cmp	w22, #0x0
    4dac:	d37be863 	lsl	x3, x3, #5
    4db0:	8b030007 	add	x7, x0, x3
    4db4:	b8636819 	ldr	w25, [x0, x3]
    4db8:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4dbc:	54000163 	b.cc	4de8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4dc0:	f94004e3 	ldr	x3, [x7, #8]
    4dc4:	34000bd9 	cbz	w25, 4f3c <fwp_apply+0x1e8>
    4dc8:	aa1403e0 	mov	x0, x20
    4dcc:	d63f0060 	blr	x3
    4dd0:	aa0003e6 	mov	x6, x0
    4dd4:	6b1902bf 	cmp	w21, w25
    4dd8:	54000940 	b.eq	4f00 <fwp_apply+0x1ac>  // b.none
    4ddc:	8b394e94 	add	x20, x20, w25, uxtw #3
    4de0:	4b1902b5 	sub	w21, w21, w25
    4de4:	17ffffee 	b	4d9c <fwp_apply+0x48>
    4de8:	0b1602ba 	add	w26, w21, w22
    4dec:	6b19035f 	cmp	w26, w25
    4df0:	54000543 	b.cc	4e98 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4df4:	7100033f 	cmp	w25, #0x0
    4df8:	4b16033a 	sub	w26, w25, w22
    4dfc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4e00:	d37df000 	lsl	x0, x0, #3
    4e04:	91003c00 	add	x0, x0, #0xf
    4e08:	92704c01 	and	x1, x0, #0xfffff0000
    4e0c:	927c7c00 	and	x0, x0, #0xffffffff0
    4e10:	cb2163e1 	sub	x1, sp, x1
    4e14:	eb2163ff 	cmp	sp, x1
    4e18:	540000a0 	b.eq	4e2c <fwp_apply+0xd8>  // b.none
    4e1c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4e20:	f90203ff 	str	xzr, [sp, #1024]
    4e24:	eb2163ff 	cmp	sp, x1
    4e28:	54ffffa1 	b.ne	4e1c <fwp_apply+0xc8>  // b.any
    4e2c:	92403c00 	and	x0, x0, #0xffff
    4e30:	cb2063ff 	sub	sp, sp, x0
    4e34:	f90003ff 	str	xzr, [sp]
    4e38:	f110001f 	cmp	x0, #0x400
    4e3c:	54000962 	b.cs	4f68 <fwp_apply+0x214>  // b.hs, b.nlast
    4e40:	910020c6 	add	x6, x6, #0x8
    4e44:	910043e0 	add	x0, sp, #0x10
    4e48:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4e4c:	d2800003 	mov	x3, #0x0                   	// #0
    4e50:	340000f6 	cbz	w22, 4e6c <fwp_apply+0x118>
    4e54:	d503201f 	nop
    4e58:	f86368c4 	ldr	x4, [x6, x3]
    4e5c:	f8236804 	str	x4, [x0, x3]
    4e60:	91002063 	add	x3, x3, #0x8
    4e64:	eb0300bf 	cmp	x5, x3
    4e68:	54ffff81 	b.ne	4e58 <fwp_apply+0x104>  // b.any
    4e6c:	3400013a 	cbz	w26, 4e90 <fwp_apply+0x13c>
    4e70:	2a1a03e6 	mov	w6, w26
    4e74:	d2800003 	mov	x3, #0x0                   	// #0
    4e78:	0b0302c4 	add	w4, w22, w3
    4e7c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e80:	91000463 	add	x3, x3, #0x1
    4e84:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e88:	eb0300df 	cmp	x6, x3
    4e8c:	54ffff61 	b.ne	4e78 <fwp_apply+0x124>  // b.any
    4e90:	f94004e3 	ldr	x3, [x7, #8]
    4e94:	1400002c 	b	4f44 <fwp_apply+0x1f0>
    4e98:	11000740 	add	w0, w26, #0x1
    4e9c:	52800041 	mov	w1, #0x2                   	// #2
    4ea0:	f81e83a6 	stur	x6, [x29, #-24]
    4ea4:	d37df000 	lsl	x0, x0, #3
    4ea8:	97ffff66 	bl	4c40 <fwp_heap_alloc>
    4eac:	f85e83a6 	ldur	x6, [x29, #-24]
    4eb0:	aa0003f3 	mov	x19, x0
    4eb4:	b94000c1 	ldr	w1, [x6]
    4eb8:	29006801 	stp	w1, w26, [x0]
    4ebc:	340000b6 	cbz	w22, 4ed0 <fwp_apply+0x17c>
    4ec0:	910020c1 	add	x1, x6, #0x8
    4ec4:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4ec8:	91002000 	add	x0, x0, #0x8
    4ecc:	97fff5e5 	bl	2660 <memmove@plt>
    4ed0:	2a1503e3 	mov	w3, w21
    4ed4:	d2800000 	mov	x0, #0x0                   	// #0
    4ed8:	34000135 	cbz	w21, 4efc <fwp_apply+0x1a8>
    4edc:	d503201f 	nop
    4ee0:	0b0002c1 	add	w1, w22, w0
    4ee4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4ee8:	8b010e61 	add	x1, x19, x1, lsl #3
    4eec:	91000400 	add	x0, x0, #0x1
    4ef0:	f9000422 	str	x2, [x1, #8]
    4ef4:	eb00007f 	cmp	x3, x0
    4ef8:	54ffff41 	b.ne	4ee0 <fwp_apply+0x18c>  // b.any
    4efc:	aa1303e6 	mov	x6, x19
    4f00:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4f04:	f947f400 	ldr	x0, [x0, #4072]
    4f08:	f85f83a2 	ldur	x2, [x29, #-8]
    4f0c:	f9400001 	ldr	x1, [x0]
    4f10:	eb010042 	subs	x2, x2, x1
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	540002c1 	b.ne	4f70 <fwp_apply+0x21c>  // b.any
    4f1c:	910003bf 	mov	sp, x29
    4f20:	aa0603e0 	mov	x0, x6
    4f24:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f2c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f30:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f38:	d65f03c0 	ret
    4f3c:	d10043a0 	sub	x0, x29, #0x10
    4f40:	5280001a 	mov	w26, #0x0                   	// #0
    4f44:	d63f0060 	blr	x3
    4f48:	aa0003e6 	mov	x6, x0
    4f4c:	6b1a02bf 	cmp	w21, w26
    4f50:	54fffd80 	b.eq	4f00 <fwp_apply+0x1ac>  // b.none
    4f54:	0b1602b6 	add	w22, w21, w22
    4f58:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f5c:	4b1902d5 	sub	w21, w22, w25
    4f60:	9100031f 	mov	sp, x24
    4f64:	17ffff8e 	b	4d9c <fwp_apply+0x48>
    4f68:	f90203ff 	str	xzr, [sp, #1024]
    4f6c:	17ffffb5 	b	4e40 <fwp_apply+0xec>
    4f70:	97fff620 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f74 <fwp_p_ad_push>:
    4f74:	f100001f 	cmp	x0, #0x0
    4f78:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f7c:	54000e8b 	b.lt	514c <fwp_p_ad_push+0x1d8>  // b.tstop
    4f80:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f84:	aa0003e4 	mov	x4, x0
    4f88:	910003fd 	mov	x29, sp
    4f8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f90:	aa0003f5 	mov	x21, x0
    4f94:	aa020000 	orr	x0, x0, x2
    4f98:	a90363f7 	stp	x23, x24, [sp, #48]
    4f9c:	aa0203f7 	mov	x23, x2
    4fa0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4fa4:	9e670029 	fmov	d9, x1
    4fa8:	9e670068 	fmov	d8, x3
    4fac:	b6f80900 	tbz	x0, #63, 50cc <fwp_p_ad_push+0x158>
    4fb0:	a90153f3 	stp	x19, x20, [sp, #16]
    4fb4:	9360fc80 	asr	x0, x4, #32
    4fb8:	b6f800c4 	tbz	x4, #63, 4fd0 <fwp_p_ad_push+0x5c>
    4fbc:	1e604109 	fmov	d9, d8
    4fc0:	2f00e408 	movi	d8, #0x0
    4fc4:	9360fc40 	asr	x0, x2, #32
    4fc8:	aa0203f5 	mov	x21, x2
    4fcc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4fd0:	97fffa18 	bl	3830 <fwp_tape_of>
    4fd4:	aa0003f3 	mov	x19, x0
    4fd8:	f9403000 	ldr	x0, [x0, #96]
    4fdc:	b5001280 	cbnz	x0, 522c <fwp_p_ad_push+0x2b8>
    4fe0:	f9400a76 	ldr	x22, [x19, #16]
    4fe4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4fe8:	eb0002df 	cmp	x22, x0
    4fec:	54000e2c 	b.gt	51b0 <fwp_p_ad_push+0x23c>
    4ff0:	eb3542df 	cmp	x22, w21, uxtw
    4ff4:	54000d4d 	b.le	519c <fwp_p_ad_push+0x228>
    4ff8:	b7f80077 	tbnz	x23, #63, 5004 <fwp_p_ad_push+0x90>
    4ffc:	eb3742df 	cmp	x22, w23, uxtw
    5000:	54000ced 	b.le	519c <fwp_p_ad_push+0x228>
    5004:	f9400678 	ldr	x24, [x19, #8]
    5008:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    500c:	cb1802d8 	sub	x24, x22, x24
    5010:	91000701 	add	x1, x24, #0x1
    5014:	eb00003f 	cmp	x1, x0
    5018:	54000cc8 	b.hi	51b0 <fwp_p_ad_push+0x23c>  // b.pmore
    501c:	a9418274 	ldp	x20, x0, [x19, #24]
    5020:	a90573fb 	stp	x27, x28, [sp, #80]
    5024:	eb14003f 	cmp	x1, x20
    5028:	5400068d 	b.le	50f8 <fwp_p_ad_push+0x184>
    502c:	f100029f 	cmp	x20, #0x0
    5030:	d2800803 	mov	x3, #0x40                  	// #64
    5034:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5038:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    503c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5040:	eb14003f 	cmp	x1, x20
    5044:	5400008d 	b.le	5054 <fwp_p_ad_push+0xe0>
    5048:	eb02029f 	cmp	x20, x2
    504c:	5400052d 	b.le	50f0 <fwp_p_ad_push+0x17c>
    5050:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5054:	d37df299 	lsl	x25, x20, #3
    5058:	aa1903e1 	mov	x1, x25
    505c:	97fff5e1 	bl	27e0 <realloc@plt>
    5060:	aa0003e1 	mov	x1, x0
    5064:	b4000b00 	cbz	x0, 51c4 <fwp_p_ad_push+0x250>
    5068:	f9400e62 	ldr	x2, [x19, #24]
    506c:	f9001261 	str	x1, [x19, #32]
    5070:	f9401a60 	ldr	x0, [x19, #48]
    5074:	d37cee9a 	lsl	x26, x20, #4
    5078:	8b020821 	add	x1, x1, x2, lsl #2
    507c:	f9001661 	str	x1, [x19, #40]
    5080:	aa1a03e1 	mov	x1, x26
    5084:	97fff5d7 	bl	27e0 <realloc@plt>
    5088:	aa0003e2 	mov	x2, x0
    508c:	b40009c0 	cbz	x0, 51c4 <fwp_p_ad_push+0x250>
    5090:	f9400e61 	ldr	x1, [x19, #24]
    5094:	d37df31b 	lsl	x27, x24, #3
    5098:	d37ef685 	lsl	x5, x20, #2
    509c:	d37ef71c 	lsl	x28, x24, #2
    50a0:	8b190004 	add	x4, x0, x25
    50a4:	8b010c01 	add	x1, x0, x1, lsl #3
    50a8:	a9030660 	stp	x0, x1, [x19, #48]
    50ac:	b5000558 	cbnz	x24, 5154 <fwp_p_ad_push+0x1e0>
    50b0:	f9001e64 	str	x4, [x19, #56]
    50b4:	f9401260 	ldr	x0, [x19, #32]
    50b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    50bc:	8b050001 	add	x1, x0, x5
    50c0:	f9000e74 	str	x20, [x19, #24]
    50c4:	f9001661 	str	x1, [x19, #40]
    50c8:	14000010 	b	5108 <fwp_p_ad_push+0x194>
    50cc:	9360fc40 	asr	x0, x2, #32
    50d0:	a90153f3 	stp	x19, x20, [sp, #16]
    50d4:	eb84801f 	cmp	x0, x4, asr #32
    50d8:	54fff7c0 	b.eq	4fd0 <fwp_p_ad_push+0x5c>  // b.none
    50dc:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    50e0:	91174000 	add	x0, x0, #0x5d0
    50e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50e8:	a90573fb 	stp	x27, x28, [sp, #80]
    50ec:	97fff905 	bl	3500 <fwp_trap>
    50f0:	d37ffa94 	lsl	x20, x20, #1
    50f4:	17ffffd3 	b	5040 <fwp_p_ad_push+0xcc>
    50f8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50fc:	d37ef71c 	lsl	x28, x24, #2
    5100:	f9401e64 	ldr	x4, [x19, #56]
    5104:	d37df31b 	lsl	x27, x24, #3
    5108:	b83c6815 	str	w21, [x0, x28]
    510c:	f10002ff 	cmp	x23, #0x0
    5110:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5114:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5118:	fc3b6849 	str	d9, [x2, x27]
    511c:	aa1602a0 	orr	x0, x21, x22
    5120:	b83c6837 	str	w23, [x1, x28]
    5124:	910006d6 	add	x22, x22, #0x1
    5128:	a94363f7 	ldp	x23, x24, [sp, #48]
    512c:	fc3b6888 	str	d8, [x4, x27]
    5130:	a94573fb 	ldp	x27, x28, [sp, #80]
    5134:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5138:	f9000a76 	str	x22, [x19, #16]
    513c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5140:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5144:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5148:	d65f03c0 	ret
    514c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5150:	d65f03c0 	ret
    5154:	eb1a033f 	cmp	x25, x26
    5158:	aa0403e0 	mov	x0, x4
    515c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5160:	aa1b03e2 	mov	x2, x27
    5164:	cb190063 	sub	x3, x3, x25
    5168:	f9003fe5 	str	x5, [sp, #120]
    516c:	97fff609 	bl	2990 <__memmove_chk@plt>
    5170:	a9420660 	ldp	x0, x1, [x19, #32]
    5174:	aa1c03e2 	mov	x2, x28
    5178:	f9401a63 	ldr	x3, [x19, #48]
    517c:	f9403fe5 	ldr	x5, [sp, #120]
    5180:	8b190063 	add	x3, x3, x25
    5184:	f9001e63 	str	x3, [x19, #56]
    5188:	8b050000 	add	x0, x0, x5
    518c:	97fff535 	bl	2660 <memmove@plt>
    5190:	a9431262 	ldp	x2, x4, [x19, #48]
    5194:	f9403fe5 	ldr	x5, [sp, #120]
    5198:	17ffffc7 	b	50b4 <fwp_p_ad_push+0x140>
    519c:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    51a0:	9119a000 	add	x0, x0, #0x668
    51a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51a8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ac:	97fff8d5 	bl	3500 <fwp_trap>
    51b0:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    51b4:	91192000 	add	x0, x0, #0x648
    51b8:	a9046bf9 	stp	x25, x26, [sp, #64]
    51bc:	a90573fb 	stp	x27, x28, [sp, #80]
    51c0:	97fff8d0 	bl	3500 <fwp_trap>
    51c4:	aa1303e0 	mov	x0, x19
    51c8:	97fff752 	bl	2f10 <fwp_tape_unlink_scope>
    51cc:	f9401260 	ldr	x0, [x19, #32]
    51d0:	97fff5b8 	bl	28b0 <free@plt>
    51d4:	f9401a60 	ldr	x0, [x19, #48]
    51d8:	97fff5b6 	bl	28b0 <free@plt>
    51dc:	f9402260 	ldr	x0, [x19, #64]
    51e0:	97fff5b4 	bl	28b0 <free@plt>
    51e4:	f9000e7f 	str	xzr, [x19, #24]
    51e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    51ec:	f947e821 	ldr	x1, [x1, #4048]
    51f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51f4:	d2800262 	mov	x2, #0x13                  	// #19
    51f8:	4f000400 	movi	v0.4s, #0x0
    51fc:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5200:	f9400023 	ldr	x3, [x1]
    5204:	b900067f 	str	wzr, [x19, #4]
    5208:	d2800021 	mov	x1, #0x1                   	// #1
    520c:	910ba000 	add	x0, x0, #0x2e8
    5210:	3c808260 	stur	q0, [x19, #8]
    5214:	ad010260 	stp	q0, q0, [x19, #32]
    5218:	97fff5b6 	bl	28f0 <fwrite@plt>
    521c:	d2800000 	mov	x0, #0x0                   	// #0
    5220:	97fff5c0 	bl	2920 <fflush@plt>
    5224:	52800cc0 	mov	w0, #0x66                  	// #102
    5228:	97fff5ce 	bl	2960 <_Exit@plt>
    522c:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5230:	91186000 	add	x0, x0, #0x618
    5234:	a9046bf9 	stp	x25, x26, [sp, #64]
    5238:	a90573fb 	stp	x27, x28, [sp, #80]
    523c:	97fff8b1 	bl	3500 <fwp_trap>

0000000000005240 <w107>:
    5240:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5244:	9e660003 	fmov	x3, d0
    5248:	aa0003e2 	mov	x2, x0
    524c:	910003fd 	mov	x29, sp
    5250:	fd001fea 	str	d10, [sp, #56]
    5254:	1e60400a 	fmov	d10, d0
    5258:	6d0427e8 	stp	d8, d9, [sp, #64]
    525c:	1e604028 	fmov	d8, d1
    5260:	1e600809 	fmul	d9, d0, d0
    5264:	a90153f3 	stp	x19, x20, [sp, #16]
    5268:	aa0103f4 	mov	x20, x1
    526c:	aa0303e1 	mov	x1, x3
    5270:	aa0003f3 	mov	x19, x0
    5274:	a9025bf5 	stp	x21, x22, [sp, #32]
    5278:	f9001bf7 	str	x23, [sp, #48]
    527c:	97ffff3e 	bl	4f74 <fwp_p_ad_push>
    5280:	aa0003e5 	mov	x5, x0
    5284:	97fffb50 	bl	3fc4 <caf61>
    5288:	9e670000 	fmov	d0, x0
    528c:	97fffb4e 	bl	3fc4 <caf61>
    5290:	1e693908 	fsub	d8, d8, d9
    5294:	aa1403e2 	mov	x2, x20
    5298:	1e614000 	fneg	d0, d0
    529c:	aa0003e3 	mov	x3, x0
    52a0:	aa0503e0 	mov	x0, x5
    52a4:	9e660117 	fmov	x23, d8
    52a8:	9e660001 	fmov	x1, d0
    52ac:	97ffff32 	bl	4f74 <fwp_p_ad_push>
    52b0:	aa0003f5 	mov	x21, x0
    52b4:	97fffb44 	bl	3fc4 <caf61>
    52b8:	9e670000 	fmov	d0, x0
    52bc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    52c0:	97fffb41 	bl	3fc4 <caf61>
    52c4:	1e614000 	fneg	d0, d0
    52c8:	aa0003e3 	mov	x3, x0
    52cc:	1e6a3929 	fsub	d9, d9, d10
    52d0:	aa1303e0 	mov	x0, x19
    52d4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    52d8:	9e660001 	fmov	x1, d0
    52dc:	9e660136 	fmov	x22, d9
    52e0:	97ffff25 	bl	4f74 <fwp_p_ad_push>
    52e4:	1e680908 	fmul	d8, d8, d8
    52e8:	aa0003f4 	mov	x20, x0
    52ec:	aa1703e3 	mov	x3, x23
    52f0:	aa1703e1 	mov	x1, x23
    52f4:	aa1503e2 	mov	x2, x21
    52f8:	aa1503e0 	mov	x0, x21
    52fc:	97ffff1e 	bl	4f74 <fwp_p_ad_push>
    5300:	aa0003e2 	mov	x2, x0
    5304:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5308:	9e670020 	fmov	d0, x1
    530c:	9e660101 	fmov	x1, d8
    5310:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5314:	1e600908 	fmul	d8, d8, d0
    5318:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    531c:	97ffff16 	bl	4f74 <fwp_p_ad_push>
    5320:	1e690929 	fmul	d9, d9, d9
    5324:	aa1603e3 	mov	x3, x22
    5328:	aa1603e1 	mov	x1, x22
    532c:	aa1403e2 	mov	x2, x20
    5330:	aa0003f3 	mov	x19, x0
    5334:	aa1403e0 	mov	x0, x20
    5338:	97ffff0f 	bl	4f74 <fwp_p_ad_push>
    533c:	aa0003e5 	mov	x5, x0
    5340:	97fffb21 	bl	3fc4 <caf61>
    5344:	aa0003e6 	mov	x6, x0
    5348:	97fffb1f 	bl	3fc4 <caf61>
    534c:	1e692908 	fadd	d8, d8, d9
    5350:	aa1303e2 	mov	x2, x19
    5354:	aa0603e1 	mov	x1, x6
    5358:	aa0003e3 	mov	x3, x0
    535c:	aa0503e0 	mov	x0, x5
    5360:	97ffff05 	bl	4f74 <fwp_p_ad_push>
    5364:	aa0003e1 	mov	x1, x0
    5368:	a94153f3 	ldp	x19, x20, [sp, #16]
    536c:	9e660100 	fmov	x0, d8
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	f9401bf7 	ldr	x23, [sp, #48]
    5378:	fd401fea 	ldr	d10, [sp, #56]
    537c:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5380:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5384:	d65f03c0 	ret
    5388:	d503201f 	nop
    538c:	d503201f 	nop

0000000000005390 <w164.constprop.0>:
    5390:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5394:	910003fd 	mov	x29, sp
    5398:	a9025bf5 	stp	x21, x22, [sp, #32]
    539c:	fd001be8 	str	d8, [sp, #48]
    53a0:	f9400015 	ldr	x21, [x0]
    53a4:	b40003b5 	cbz	x21, 5418 <w164.constprop.0+0x88>
    53a8:	2f00e408 	movi	d8, #0x0
    53ac:	91002016 	add	x22, x0, #0x8
    53b0:	a90153f3 	stp	x19, x20, [sp, #16]
    53b4:	91004014 	add	x20, x0, #0x10
    53b8:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    53bc:	d2800013 	mov	x19, #0x0                   	// #0
    53c0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    53c4:	f8737a87 	ldr	x7, [x20, x19, lsl #3]
    53c8:	97fffaff 	bl	3fc4 <caf61>
    53cc:	aa0003e6 	mov	x6, x0
    53d0:	97fffafd 	bl	3fc4 <caf61>
    53d4:	1e602908 	fadd	d8, d8, d0
    53d8:	aa0003e3 	mov	x3, x0
    53dc:	aa0703e2 	mov	x2, x7
    53e0:	aa0503e0 	mov	x0, x5
    53e4:	aa0603e1 	mov	x1, x6
    53e8:	91000a73 	add	x19, x19, #0x2
    53ec:	97fffee2 	bl	4f74 <fwp_p_ad_push>
    53f0:	aa0003e5 	mov	x5, x0
    53f4:	eb1302bf 	cmp	x21, x19
    53f8:	54fffe48 	b.hi	53c0 <w164.constprop.0+0x30>  // b.pmore
    53fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5400:	9e660100 	fmov	x0, d8
    5404:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5408:	aa0503e1 	mov	x1, x5
    540c:	fd401be8 	ldr	d8, [sp, #48]
    5410:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5414:	d65f03c0 	ret
    5418:	2f00e408 	movi	d8, #0x0
    541c:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    5420:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5424:	aa0503e1 	mov	x1, x5
    5428:	9e660100 	fmov	x0, d8
    542c:	fd401be8 	ldr	d8, [sp, #48]
    5430:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5434:	d65f03c0 	ret
    5438:	d503201f 	nop
    543c:	d503201f 	nop

0000000000005440 <fwp_data.part.0.constprop.0>:
    5440:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    5450:	9115c283 	add	x3, x20, #0x570
    5454:	a9025bf5 	stp	x21, x22, [sp, #32]
    5458:	aa0103f5 	mov	x21, x1
    545c:	b953a461 	ldr	w1, [x3, #5028]
    5460:	a90363f7 	stp	x23, x24, [sp, #48]
    5464:	2a0003f8 	mov	w24, w0
    5468:	34000701 	cbz	w1, 5548 <fwp_data.part.0.constprop.0+0x108>
    546c:	397e8862 	ldrb	w2, [x3, #4002]
    5470:	910f0040 	add	x0, x2, #0x3c0
    5474:	8b020442 	add	x2, x2, x2, lsl #1
    5478:	d37df042 	lsl	x2, x2, #3
    547c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5480:	2a1703f6 	mov	w22, w23
    5484:	f8626873 	ldr	x19, [x3, x2]
    5488:	b40004d3 	cbz	x19, 5520 <fwp_data.part.0.constprop.0+0xe0>
    548c:	f9400260 	ldr	x0, [x19]
    5490:	aa2003e0 	mvn	x0, x0
    5494:	f8226860 	str	x0, [x3, x2]
    5498:	f10062df 	cmp	x22, #0x18
    549c:	540000e9 	b.ls	54b8 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    54a0:	d10066c2 	sub	x2, x22, #0x19
    54a4:	91006260 	add	x0, x19, #0x18
    54a8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    54ac:	52800001 	mov	w1, #0x0                   	// #0
    54b0:	91002042 	add	x2, x2, #0x8
    54b4:	97fff4c3 	bl	27c0 <memset@plt>
    54b8:	9115c282 	add	x2, x20, #0x570
    54bc:	f94a1041 	ldr	x1, [x2, #5152]
    54c0:	ab160021 	adds	x1, x1, x22
    54c4:	540004c2 	b.cs	555c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    54c8:	f94a1440 	ldr	x0, [x2, #5160]
    54cc:	f90a1041 	str	x1, [x2, #5152]
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	54000049 	b.ls	54dc <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    54d8:	f90a1441 	str	x1, [x2, #5160]
    54dc:	9115c294 	add	x20, x20, #0x570
    54e0:	1e6302e1 	ucvtf	d1, w23
    54e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    54e8:	1e612800 	fadd	d0, d0, d1
    54ec:	fd0a1e80 	str	d0, [x20, #5176]
    54f0:	52800041 	mov	w1, #0x2                   	// #2
    54f4:	29000678 	stp	w24, w1, [x19]
    54f8:	aa1303e0 	mov	x0, x19
    54fc:	f94002a1 	ldr	x1, [x21]
    5500:	f9000661 	str	x1, [x19, #8]
    5504:	f94006a1 	ldr	x1, [x21, #8]
    5508:	f9000a61 	str	x1, [x19, #16]
    550c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5514:	a94363f7 	ldp	x23, x24, [sp, #48]
    5518:	a8c47bfd 	ldp	x29, x30, [sp], #64
    551c:	d65f03c0 	ret
    5520:	8b020063 	add	x3, x3, x2
    5524:	f9400473 	ldr	x19, [x3, #8]
    5528:	b4000113 	cbz	x19, 5548 <fwp_data.part.0.constprop.0+0x108>
    552c:	f9400860 	ldr	x0, [x3, #16]
    5530:	cb130000 	sub	x0, x0, x19
    5534:	eb0002df 	cmp	x22, x0
    5538:	54000088 	b.hi	5548 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    553c:	8b160260 	add	x0, x19, x22
    5540:	f9000460 	str	x0, [x3, #8]
    5544:	17ffffd5 	b	5498 <fwp_data.part.0.constprop.0+0x58>
    5548:	52800001 	mov	w1, #0x0                   	// #0
    554c:	d2800300 	mov	x0, #0x18                  	// #24
    5550:	97fffdbc 	bl	4c40 <fwp_heap_alloc>
    5554:	aa0003f3 	mov	x19, x0
    5558:	17ffffe6 	b	54f0 <fwp_data.part.0.constprop.0+0xb0>
    555c:	97fff695 	bl	2fb0 <fwp_heap_oom>

0000000000005560 <fwp_rc_share>:
    5560:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    5564:	9115c042 	add	x2, x2, #0x570
    5568:	f949d843 	ldr	x3, [x2, #5040]
    556c:	f949ec41 	ldr	x1, [x2, #5080]
    5570:	cb030000 	sub	x0, x0, x3
    5574:	eb01401f 	cmp	x0, x1, lsl #16
    5578:	540002c2 	b.cs	55d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    557c:	d350fc01 	lsr	x1, x0, #16
    5580:	f949fc44 	ldr	x4, [x2, #5112]
    5584:	8b010821 	add	x1, x1, x1, lsl #2
    5588:	d37df021 	lsl	x1, x1, #3
    558c:	8b010083 	add	x3, x4, x1
    5590:	f9401062 	ldr	x2, [x3, #32]
    5594:	b40001e2 	cbz	x2, 55d0 <fwp_rc_share+0x70>
    5598:	38616881 	ldrb	w1, [x4, x1]
    559c:	7100083f 	cmp	w1, #0x2
    55a0:	540001a0 	b.eq	55d4 <fwp_rc_share+0x74>  // b.none
    55a4:	7100043f 	cmp	w1, #0x1
    55a8:	54000141 	b.ne	55d0 <fwp_rc_share+0x70>  // b.any
    55ac:	29430464 	ldp	w4, w1, [x3, #24]
    55b0:	92403c00 	and	x0, x0, #0xffff
    55b4:	9b047c00 	mul	x0, x0, x4
    55b8:	d360fc00 	lsr	x0, x0, #32
    55bc:	eb01001f 	cmp	x0, x1
    55c0:	54000082 	b.cs	55d0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    55c4:	8b000042 	add	x2, x2, x0
    55c8:	39400040 	ldrb	w0, [x2]
    55cc:	350000a0 	cbnz	w0, 55e0 <fwp_rc_share+0x80>
    55d0:	d65f03c0 	ret
    55d4:	72003c1f 	tst	w0, #0xffff
    55d8:	54ffff80 	b.eq	55c8 <fwp_rc_share+0x68>  // b.none
    55dc:	d65f03c0 	ret
    55e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    55e4:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    55e8:	911a2000 	add	x0, x0, #0x688
    55ec:	910003fd 	mov	x29, sp
    55f0:	97fff7c4 	bl	3500 <fwp_trap>

00000000000055f4 <fwp_rc_free_arr>:
    55f4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    55f8:	9115c063 	add	x3, x3, #0x570
    55fc:	f949d861 	ldr	x1, [x3, #5040]
    5600:	f949ec62 	ldr	x2, [x3, #5080]
    5604:	cb010001 	sub	x1, x0, x1
    5608:	eb02403f 	cmp	x1, x2, lsl #16
    560c:	54000342 	b.cs	5674 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5610:	d350fc22 	lsr	x2, x1, #16
    5614:	f949fc65 	ldr	x5, [x3, #5112]
    5618:	8b020842 	add	x2, x2, x2, lsl #2
    561c:	d37df042 	lsl	x2, x2, #3
    5620:	8b0200a4 	add	x4, x5, x2
    5624:	f9401083 	ldr	x3, [x4, #32]
    5628:	b4000263 	cbz	x3, 5674 <fwp_rc_free_arr+0x80>
    562c:	386268a2 	ldrb	w2, [x5, x2]
    5630:	7100085f 	cmp	w2, #0x2
    5634:	540001c0 	b.eq	566c <fwp_rc_free_arr+0x78>  // b.none
    5638:	7100045f 	cmp	w2, #0x1
    563c:	540001c1 	b.ne	5674 <fwp_rc_free_arr+0x80>  // b.any
    5640:	29430885 	ldp	w5, w2, [x4, #24]
    5644:	92403c21 	and	x1, x1, #0xffff
    5648:	9b057c21 	mul	x1, x1, x5
    564c:	d360fc21 	lsr	x1, x1, #32
    5650:	eb02003f 	cmp	x1, x2
    5654:	54000102 	b.cs	5674 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5658:	8b010063 	add	x3, x3, x1
    565c:	39400061 	ldrb	w1, [x3]
    5660:	7100043f 	cmp	w1, #0x1
    5664:	54000081 	b.ne	5674 <fwp_rc_free_arr+0x80>  // b.any
    5668:	17fffc56 	b	47c0 <fwp_mem_free>
    566c:	72003c3f 	tst	w1, #0xffff
    5670:	54ffff60 	b.eq	565c <fwp_rc_free_arr+0x68>  // b.none
    5674:	d65f03c0 	ret
    5678:	d503201f 	nop
    567c:	d503201f 	nop

0000000000005680 <fwp_rc_dup>:
    5680:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    5684:	9115c042 	add	x2, x2, #0x570
    5688:	f949d841 	ldr	x1, [x2, #5040]
    568c:	f949ec43 	ldr	x3, [x2, #5080]
    5690:	cb010001 	sub	x1, x0, x1
    5694:	eb03403f 	cmp	x1, x3, lsl #16
    5698:	54000342 	b.cs	5700 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    569c:	d350fc20 	lsr	x0, x1, #16
    56a0:	f949fc44 	ldr	x4, [x2, #5112]
    56a4:	8b000800 	add	x0, x0, x0, lsl #2
    56a8:	d37df002 	lsl	x2, x0, #3
    56ac:	8b020083 	add	x3, x4, x2
    56b0:	f9401060 	ldr	x0, [x3, #32]
    56b4:	b4000260 	cbz	x0, 5700 <fwp_rc_dup+0x80>
    56b8:	38626882 	ldrb	w2, [x4, x2]
    56bc:	7100085f 	cmp	w2, #0x2
    56c0:	54000220 	b.eq	5704 <fwp_rc_dup+0x84>  // b.none
    56c4:	7100045f 	cmp	w2, #0x1
    56c8:	540001c1 	b.ne	5700 <fwp_rc_dup+0x80>  // b.any
    56cc:	29430864 	ldp	w4, w2, [x3, #24]
    56d0:	92403c21 	and	x1, x1, #0xffff
    56d4:	9b047c21 	mul	x1, x1, x4
    56d8:	d360fc21 	lsr	x1, x1, #32
    56dc:	eb02003f 	cmp	x1, x2
    56e0:	54000102 	b.cs	5700 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    56e4:	8b010000 	add	x0, x0, x1
    56e8:	39400001 	ldrb	w1, [x0]
    56ec:	340000a1 	cbz	w1, 5700 <fwp_rc_dup+0x80>
    56f0:	7103f43f 	cmp	w1, #0xfd
    56f4:	540000e8 	b.hi	5710 <fwp_rc_dup+0x90>  // b.pmore
    56f8:	11000421 	add	w1, w1, #0x1
    56fc:	39000001 	strb	w1, [x0]
    5700:	d65f03c0 	ret
    5704:	72003c3f 	tst	w1, #0xffff
    5708:	54ffff00 	b.eq	56e8 <fwp_rc_dup+0x68>  // b.none
    570c:	d65f03c0 	ret
    5710:	17fffb45 	b	4424 <fwp_rc_wide_dup>

0000000000005714 <fwp_drop0>:
    5714:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5718:	910003fd 	mov	x29, sp
    571c:	a90153f3 	stp	x19, x20, [sp, #16]
    5720:	f90013f5 	str	x21, [sp, #32]
    5724:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    5728:	9115c2b4 	add	x20, x21, #0x570
    572c:	f949da81 	ldr	x1, [x20, #5040]
    5730:	f949ee82 	ldr	x2, [x20, #5080]
    5734:	cb010001 	sub	x1, x0, x1
    5738:	eb02403f 	cmp	x1, x2, lsl #16
    573c:	54000382 	b.cs	57ac <fwp_drop0+0x98>  // b.hs, b.nlast
    5740:	d350fc22 	lsr	x2, x1, #16
    5744:	f949fe84 	ldr	x4, [x20, #5112]
    5748:	8b020842 	add	x2, x2, x2, lsl #2
    574c:	d37df042 	lsl	x2, x2, #3
    5750:	8b020083 	add	x3, x4, x2
    5754:	f9401073 	ldr	x19, [x3, #32]
    5758:	b40002b3 	cbz	x19, 57ac <fwp_drop0+0x98>
    575c:	38626882 	ldrb	w2, [x4, x2]
    5760:	7100085f 	cmp	w2, #0x2
    5764:	540002c0 	b.eq	57bc <fwp_drop0+0xa8>  // b.none
    5768:	7100045f 	cmp	w2, #0x1
    576c:	54000201 	b.ne	57ac <fwp_drop0+0x98>  // b.any
    5770:	29430864 	ldp	w4, w2, [x3, #24]
    5774:	92403c21 	and	x1, x1, #0xffff
    5778:	9b047c21 	mul	x1, x1, x4
    577c:	d360fc21 	lsr	x1, x1, #32
    5780:	eb02003f 	cmp	x1, x2
    5784:	54000142 	b.cs	57ac <fwp_drop0+0x98>  // b.hs, b.nlast
    5788:	8b010273 	add	x19, x19, x1
    578c:	39400261 	ldrb	w1, [x19]
    5790:	340000e1 	cbz	w1, 57ac <fwp_drop0+0x98>
    5794:	7100043f 	cmp	w1, #0x1
    5798:	540001e0 	b.eq	57d4 <fwp_drop0+0xc0>  // b.none
    579c:	7103fc3f 	cmp	w1, #0xff
    57a0:	540002e0 	b.eq	57fc <fwp_drop0+0xe8>  // b.none
    57a4:	51000421 	sub	w1, w1, #0x1
    57a8:	39000261 	strb	w1, [x19]
    57ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    57b0:	f94013f5 	ldr	x21, [sp, #32]
    57b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57b8:	d65f03c0 	ret
    57bc:	72003c3f 	tst	w1, #0xffff
    57c0:	54fffe60 	b.eq	578c <fwp_drop0+0x78>  // b.none
    57c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c8:	f94013f5 	ldr	x21, [sp, #32]
    57cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57d0:	d65f03c0 	ret
    57d4:	f9400813 	ldr	x19, [x0, #16]
    57d8:	97ffff87 	bl	55f4 <fwp_rc_free_arr>
    57dc:	9115c2a0 	add	x0, x21, #0x570
    57e0:	f949d801 	ldr	x1, [x0, #5040]
    57e4:	f949ec00 	ldr	x0, [x0, #5080]
    57e8:	cb010261 	sub	x1, x19, x1
    57ec:	eb00403f 	cmp	x1, x0, lsl #16
    57f0:	54fffde2 	b.cs	57ac <fwp_drop0+0x98>  // b.hs, b.nlast
    57f4:	aa1303e0 	mov	x0, x19
    57f8:	17ffffd2 	b	5740 <fwp_drop0+0x2c>
    57fc:	ca534660 	eor	x0, x19, x19, lsr #17
    5800:	9115c2b5 	add	x21, x21, #0x570
    5804:	ca402400 	eor	x0, x0, x0, lsr #9
    5808:	8b200ea0 	add	x0, x21, w0, uxtb #3
    580c:	f94a2400 	ldr	x0, [x0, #5192]
    5810:	b5000080 	cbnz	x0, 5820 <fwp_drop0+0x10c>
    5814:	14000010 	b	5854 <fwp_drop0+0x140>
    5818:	f9400800 	ldr	x0, [x0, #16]
    581c:	b40001c0 	cbz	x0, 5854 <fwp_drop0+0x140>
    5820:	f9400001 	ldr	x1, [x0]
    5824:	eb13003f 	cmp	x1, x19
    5828:	54ffff81 	b.ne	5818 <fwp_drop0+0x104>  // b.any
    582c:	f9400401 	ldr	x1, [x0, #8]
    5830:	d1000421 	sub	x1, x1, #0x1
    5834:	f9000401 	str	x1, [x0, #8]
    5838:	f103f83f 	cmp	x1, #0xfe
    583c:	54fffb81 	b.ne	57ac <fwp_drop0+0x98>  // b.any
    5840:	aa1303e0 	mov	x0, x19
    5844:	97fffb3f 	bl	4540 <fwp_rc_forget_slot>
    5848:	12800020 	mov	w0, #0xfffffffe            	// #-2
    584c:	39000260 	strb	w0, [x19]
    5850:	17ffffd7 	b	57ac <fwp_drop0+0x98>
    5854:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5858:	91162000 	add	x0, x0, #0x588
    585c:	97fff729 	bl	3500 <fwp_trap>

0000000000005860 <fwp_arg_drop12>:
    5860:	7100003f 	cmp	w1, #0x0
    5864:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5868:	54000041 	b.ne	5870 <fwp_arg_drop12+0x10>  // b.any
    586c:	d65f03c0 	ret
    5870:	f9400000 	ldr	x0, [x0]
    5874:	17ffffa8 	b	5714 <fwp_drop0>
    5878:	d503201f 	nop
    587c:	d503201f 	nop

0000000000005880 <fwp_drop1>:
    5880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5884:	910003fd 	mov	x29, sp
    5888:	a90153f3 	stp	x19, x20, [sp, #16]
    588c:	f90013f5 	str	x21, [sp, #32]
    5890:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    5894:	9115c2b4 	add	x20, x21, #0x570
    5898:	f949da81 	ldr	x1, [x20, #5040]
    589c:	f949ee82 	ldr	x2, [x20, #5080]
    58a0:	cb010001 	sub	x1, x0, x1
    58a4:	eb02403f 	cmp	x1, x2, lsl #16
    58a8:	54000382 	b.cs	5918 <fwp_drop1+0x98>  // b.hs, b.nlast
    58ac:	d350fc22 	lsr	x2, x1, #16
    58b0:	f949fe84 	ldr	x4, [x20, #5112]
    58b4:	8b020842 	add	x2, x2, x2, lsl #2
    58b8:	d37df042 	lsl	x2, x2, #3
    58bc:	8b020083 	add	x3, x4, x2
    58c0:	f9401073 	ldr	x19, [x3, #32]
    58c4:	b40002b3 	cbz	x19, 5918 <fwp_drop1+0x98>
    58c8:	38626882 	ldrb	w2, [x4, x2]
    58cc:	7100085f 	cmp	w2, #0x2
    58d0:	540002c0 	b.eq	5928 <fwp_drop1+0xa8>  // b.none
    58d4:	7100045f 	cmp	w2, #0x1
    58d8:	54000201 	b.ne	5918 <fwp_drop1+0x98>  // b.any
    58dc:	29430864 	ldp	w4, w2, [x3, #24]
    58e0:	92403c21 	and	x1, x1, #0xffff
    58e4:	9b047c21 	mul	x1, x1, x4
    58e8:	d360fc21 	lsr	x1, x1, #32
    58ec:	eb02003f 	cmp	x1, x2
    58f0:	54000142 	b.cs	5918 <fwp_drop1+0x98>  // b.hs, b.nlast
    58f4:	8b010273 	add	x19, x19, x1
    58f8:	39400261 	ldrb	w1, [x19]
    58fc:	340000e1 	cbz	w1, 5918 <fwp_drop1+0x98>
    5900:	7100043f 	cmp	w1, #0x1
    5904:	540001e0 	b.eq	5940 <fwp_drop1+0xc0>  // b.none
    5908:	7103fc3f 	cmp	w1, #0xff
    590c:	540002e0 	b.eq	5968 <fwp_drop1+0xe8>  // b.none
    5910:	51000421 	sub	w1, w1, #0x1
    5914:	39000261 	strb	w1, [x19]
    5918:	a94153f3 	ldp	x19, x20, [sp, #16]
    591c:	f94013f5 	ldr	x21, [sp, #32]
    5920:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5924:	d65f03c0 	ret
    5928:	72003c3f 	tst	w1, #0xffff
    592c:	54fffe60 	b.eq	58f8 <fwp_drop1+0x78>  // b.none
    5930:	a94153f3 	ldp	x19, x20, [sp, #16]
    5934:	f94013f5 	ldr	x21, [sp, #32]
    5938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    593c:	d65f03c0 	ret
    5940:	f9400813 	ldr	x19, [x0, #16]
    5944:	97ffff2c 	bl	55f4 <fwp_rc_free_arr>
    5948:	9115c2a0 	add	x0, x21, #0x570
    594c:	f949d801 	ldr	x1, [x0, #5040]
    5950:	f949ec00 	ldr	x0, [x0, #5080]
    5954:	cb010261 	sub	x1, x19, x1
    5958:	eb00403f 	cmp	x1, x0, lsl #16
    595c:	54fffde2 	b.cs	5918 <fwp_drop1+0x98>  // b.hs, b.nlast
    5960:	aa1303e0 	mov	x0, x19
    5964:	17ffffd2 	b	58ac <fwp_drop1+0x2c>
    5968:	ca534660 	eor	x0, x19, x19, lsr #17
    596c:	9115c2b5 	add	x21, x21, #0x570
    5970:	ca402400 	eor	x0, x0, x0, lsr #9
    5974:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5978:	f94a2400 	ldr	x0, [x0, #5192]
    597c:	b5000080 	cbnz	x0, 598c <fwp_drop1+0x10c>
    5980:	14000010 	b	59c0 <fwp_drop1+0x140>
    5984:	f9400800 	ldr	x0, [x0, #16]
    5988:	b40001c0 	cbz	x0, 59c0 <fwp_drop1+0x140>
    598c:	f9400001 	ldr	x1, [x0]
    5990:	eb13003f 	cmp	x1, x19
    5994:	54ffff81 	b.ne	5984 <fwp_drop1+0x104>  // b.any
    5998:	f9400401 	ldr	x1, [x0, #8]
    599c:	d1000421 	sub	x1, x1, #0x1
    59a0:	f9000401 	str	x1, [x0, #8]
    59a4:	f103f83f 	cmp	x1, #0xfe
    59a8:	54fffb81 	b.ne	5918 <fwp_drop1+0x98>  // b.any
    59ac:	aa1303e0 	mov	x0, x19
    59b0:	97fffae4 	bl	4540 <fwp_rc_forget_slot>
    59b4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    59b8:	39000260 	strb	w0, [x19]
    59bc:	17ffffd7 	b	5918 <fwp_drop1+0x98>
    59c0:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    59c4:	91162000 	add	x0, x0, #0x588
    59c8:	97fff6ce 	bl	3500 <fwp_trap>
    59cc:	d503201f 	nop

00000000000059d0 <fwp_closure_drop>:
    59d0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc70>
    59d4:	9115c0a4 	add	x4, x5, #0x570
    59d8:	aa0003e1 	mov	x1, x0
    59dc:	f949d882 	ldr	x2, [x4, #5040]
    59e0:	f949ec80 	ldr	x0, [x4, #5080]
    59e4:	cb020022 	sub	x2, x1, x2
    59e8:	eb00405f 	cmp	x2, x0, lsl #16
    59ec:	54000662 	b.cs	5ab8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    59f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    59f4:	d350fc43 	lsr	x3, x2, #16
    59f8:	910003fd 	mov	x29, sp
    59fc:	8b030863 	add	x3, x3, x3, lsl #2
    5a00:	f949fc84 	ldr	x4, [x4, #5112]
    5a04:	d37df063 	lsl	x3, x3, #3
    5a08:	f9000bf3 	str	x19, [sp, #16]
    5a0c:	8b030080 	add	x0, x4, x3
    5a10:	f9401013 	ldr	x19, [x0, #32]
    5a14:	b40002b3 	cbz	x19, 5a68 <fwp_closure_drop+0x98>
    5a18:	38636883 	ldrb	w3, [x4, x3]
    5a1c:	7100087f 	cmp	w3, #0x2
    5a20:	54000420 	b.eq	5aa4 <fwp_closure_drop+0xd4>  // b.none
    5a24:	7100047f 	cmp	w3, #0x1
    5a28:	54000201 	b.ne	5a68 <fwp_closure_drop+0x98>  // b.any
    5a2c:	29430003 	ldp	w3, w0, [x0, #24]
    5a30:	92403c42 	and	x2, x2, #0xffff
    5a34:	9b037c42 	mul	x2, x2, x3
    5a38:	d360fc42 	lsr	x2, x2, #32
    5a3c:	eb00005f 	cmp	x2, x0
    5a40:	54000142 	b.cs	5a68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5a44:	8b020273 	add	x19, x19, x2
    5a48:	39400260 	ldrb	w0, [x19]
    5a4c:	340000e0 	cbz	w0, 5a68 <fwp_closure_drop+0x98>
    5a50:	7100041f 	cmp	w0, #0x1
    5a54:	54000100 	b.eq	5a74 <fwp_closure_drop+0xa4>  // b.none
    5a58:	7103fc1f 	cmp	w0, #0xff
    5a5c:	54000300 	b.eq	5abc <fwp_closure_drop+0xec>  // b.none
    5a60:	51000400 	sub	w0, w0, #0x1
    5a64:	39000260 	strb	w0, [x19]
    5a68:	f9400bf3 	ldr	x19, [sp, #16]
    5a6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a70:	d65f03c0 	ret
    5a74:	d53bd040 	mrs	x0, tpidr_el0
    5a78:	91400000 	add	x0, x0, #0x0, lsl #12
    5a7c:	91004000 	add	x0, x0, #0x10
    5a80:	f9400000 	ldr	x0, [x0]
    5a84:	b4000080 	cbz	x0, 5a94 <fwp_closure_drop+0xc4>
    5a88:	f9400bf3 	ldr	x19, [sp, #16]
    5a8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a90:	17fff6b5 	b	3564 <fwp_closure_drop_push>
    5a94:	f9400bf3 	ldr	x19, [sp, #16]
    5a98:	aa0103e0 	mov	x0, x1
    5a9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5aa0:	17fff720 	b	3720 <fwp_closure_drop.part.0>
    5aa4:	72003c5f 	tst	w2, #0xffff
    5aa8:	54fffd00 	b.eq	5a48 <fwp_closure_drop+0x78>  // b.none
    5aac:	f9400bf3 	ldr	x19, [sp, #16]
    5ab0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ab4:	d65f03c0 	ret
    5ab8:	d65f03c0 	ret
    5abc:	ca534660 	eor	x0, x19, x19, lsr #17
    5ac0:	9115c0a5 	add	x5, x5, #0x570
    5ac4:	ca402400 	eor	x0, x0, x0, lsr #9
    5ac8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5acc:	f94a2400 	ldr	x0, [x0, #5192]
    5ad0:	b5000080 	cbnz	x0, 5ae0 <fwp_closure_drop+0x110>
    5ad4:	14000010 	b	5b14 <fwp_closure_drop+0x144>
    5ad8:	f9400800 	ldr	x0, [x0, #16]
    5adc:	b40001c0 	cbz	x0, 5b14 <fwp_closure_drop+0x144>
    5ae0:	f9400001 	ldr	x1, [x0]
    5ae4:	eb13003f 	cmp	x1, x19
    5ae8:	54ffff81 	b.ne	5ad8 <fwp_closure_drop+0x108>  // b.any
    5aec:	f9400401 	ldr	x1, [x0, #8]
    5af0:	d1000421 	sub	x1, x1, #0x1
    5af4:	f9000401 	str	x1, [x0, #8]
    5af8:	f103f83f 	cmp	x1, #0xfe
    5afc:	54fffb61 	b.ne	5a68 <fwp_closure_drop+0x98>  // b.any
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	97fffa8f 	bl	4540 <fwp_rc_forget_slot>
    5b08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b0c:	39000260 	strb	w0, [x19]
    5b10:	17ffffd6 	b	5a68 <fwp_closure_drop+0x98>
    5b14:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5b18:	91162000 	add	x0, x0, #0x588
    5b1c:	97fff679 	bl	3500 <fwp_trap>

0000000000005b20 <fwp_owned_tape_release>:
    5b20:	b4000940 	cbz	x0, 5c48 <fwp_owned_tape_release+0x128>
    5b24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b28:	910003fd 	mov	x29, sp
    5b2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5b30:	aa0003f3 	mov	x19, x0
    5b34:	f9400000 	ldr	x0, [x0]
    5b38:	b4000060 	cbz	x0, 5b44 <fwp_owned_tape_release+0x24>
    5b3c:	f9400661 	ldr	x1, [x19, #8]
    5b40:	f9000401 	str	x1, [x0, #8]
    5b44:	f9400661 	ldr	x1, [x19, #8]
    5b48:	b4000041 	cbz	x1, 5b50 <fwp_owned_tape_release+0x30>
    5b4c:	f9000020 	str	x0, [x1]
    5b50:	f9400a60 	ldr	x0, [x19, #16]
    5b54:	f9403401 	ldr	x1, [x0, #104]
    5b58:	b40005c1 	cbz	x1, 5c10 <fwp_owned_tape_release+0xf0>
    5b5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5b60:	eb00005f 	cmp	x2, x0
    5b64:	540002ed 	b.le	5bc0 <fwp_owned_tape_release+0xa0>
    5b68:	d2800014 	mov	x20, #0x0                   	// #0
    5b6c:	f90013f5 	str	x21, [sp, #32]
    5b70:	d2800015 	mov	x21, #0x0                   	// #0
    5b74:	d503201f 	nop
    5b78:	f9402260 	ldr	x0, [x19, #64]
    5b7c:	910006b5 	add	x21, x21, #0x1
    5b80:	f8746800 	ldr	x0, [x0, x20]
    5b84:	d63f0020 	blr	x1
    5b88:	f9402260 	ldr	x0, [x19, #64]
    5b8c:	f9400a61 	ldr	x1, [x19, #16]
    5b90:	8b140000 	add	x0, x0, x20
    5b94:	91004294 	add	x20, x20, #0x10
    5b98:	f9400400 	ldr	x0, [x0, #8]
    5b9c:	f9403421 	ldr	x1, [x1, #104]
    5ba0:	d63f0020 	blr	x1
    5ba4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ba8:	cb010000 	sub	x0, x0, x1
    5bac:	eb15001f 	cmp	x0, x21
    5bb0:	f9400a60 	ldr	x0, [x19, #16]
    5bb4:	f9403401 	ldr	x1, [x0, #104]
    5bb8:	54fffe0c 	b.gt	5b78 <fwp_owned_tape_release+0x58>
    5bbc:	f94013f5 	ldr	x21, [sp, #32]
    5bc0:	f9403663 	ldr	x3, [x19, #104]
    5bc4:	f9401262 	ldr	x2, [x19, #32]
    5bc8:	f100007f 	cmp	x3, #0x0
    5bcc:	540001ed 	b.le	5c08 <fwp_owned_tape_release+0xe8>
    5bd0:	d2800014 	mov	x20, #0x0                   	// #0
    5bd4:	d503201f 	nop
    5bd8:	f9402660 	ldr	x0, [x19, #72]
    5bdc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5be0:	eb02001f 	cmp	x0, x2
    5be4:	540000c0 	b.eq	5bfc <fwp_owned_tape_release+0xdc>  // b.none
    5be8:	d63f0020 	blr	x1
    5bec:	f9400a60 	ldr	x0, [x19, #16]
    5bf0:	f9401262 	ldr	x2, [x19, #32]
    5bf4:	f9403663 	ldr	x3, [x19, #104]
    5bf8:	f9403401 	ldr	x1, [x0, #104]
    5bfc:	91000694 	add	x20, x20, #0x1
    5c00:	eb14007f 	cmp	x3, x20
    5c04:	54fffeac 	b.gt	5bd8 <fwp_owned_tape_release+0xb8>
    5c08:	aa0203e0 	mov	x0, x2
    5c0c:	d63f0020 	blr	x1
    5c10:	f9401660 	ldr	x0, [x19, #40]
    5c14:	97ffff6f 	bl	59d0 <fwp_closure_drop>
    5c18:	f9401a60 	ldr	x0, [x19, #48]
    5c1c:	97ffff6d 	bl	59d0 <fwp_closure_drop>
    5c20:	f9401e60 	ldr	x0, [x19, #56]
    5c24:	97ffff6b 	bl	59d0 <fwp_closure_drop>
    5c28:	f9402260 	ldr	x0, [x19, #64]
    5c2c:	97fffae5 	bl	47c0 <fwp_mem_free>
    5c30:	f9402660 	ldr	x0, [x19, #72]
    5c34:	97fffae3 	bl	47c0 <fwp_mem_free>
    5c38:	aa1303e0 	mov	x0, x19
    5c3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c44:	17fffadf 	b	47c0 <fwp_mem_free>
    5c48:	d65f03c0 	ret
    5c4c:	d503201f 	nop

0000000000005c50 <fwp_tape_finish>:
    5c50:	d10203ff 	sub	sp, sp, #0x80
    5c54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5c58:	f947f421 	ldr	x1, [x1, #4072]
    5c5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5c60:	910103fd 	add	x29, sp, #0x40
    5c64:	a90553f3 	stp	x19, x20, [sp, #80]
    5c68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5c6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5c70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5c74:	91010316 	add	x22, x24, #0x40
    5c78:	f9400022 	ldr	x2, [x1]
    5c7c:	f9001fe2 	str	x2, [sp, #56]
    5c80:	d2800002 	mov	x2, #0x0                   	// #0
    5c84:	9101a2c0 	add	x0, x22, #0x68
    5c88:	97fff57e 	bl	3280 <fwp_tape_buffers_dispose>
    5c8c:	f90052df 	str	xzr, [x22, #160]
    5c90:	f94022c0 	ldr	x0, [x22, #64]
    5c94:	f100001f 	cmp	x0, #0x0
    5c98:	5400030d 	b.le	5cf8 <fwp_tape_finish+0xa8>
    5c9c:	910003f7 	mov	x23, sp
    5ca0:	d2800015 	mov	x21, #0x0                   	// #0
    5ca4:	d2800014 	mov	x20, #0x0                   	// #0
    5ca8:	f94002d3 	ldr	x19, [x22]
    5cac:	91000694 	add	x20, x20, #0x1
    5cb0:	8b150273 	add	x19, x19, x21
    5cb4:	9101a2b5 	add	x21, x21, #0x68
    5cb8:	aa1303e0 	mov	x0, x19
    5cbc:	97fff495 	bl	2f10 <fwp_tape_unlink_scope>
    5cc0:	aa1703e0 	mov	x0, x23
    5cc4:	f9401261 	ldr	x1, [x19, #32]
    5cc8:	f90003e1 	str	x1, [sp]
    5ccc:	f9401a62 	ldr	x2, [x19, #48]
    5cd0:	f9000be2 	str	x2, [sp, #16]
    5cd4:	f9402261 	ldr	x1, [x19, #64]
    5cd8:	f90013e1 	str	x1, [sp, #32]
    5cdc:	97fff569 	bl	3280 <fwp_tape_buffers_dispose>
    5ce0:	f9403260 	ldr	x0, [x19, #96]
    5ce4:	97ffff8f 	bl	5b20 <fwp_owned_tape_release>
    5ce8:	f900327f 	str	xzr, [x19, #96]
    5cec:	f94022c0 	ldr	x0, [x22, #64]
    5cf0:	eb14001f 	cmp	x0, x20
    5cf4:	54fffdac 	b.gt	5ca8 <fwp_tape_finish+0x58>
    5cf8:	f9402300 	ldr	x0, [x24, #64]
    5cfc:	91010313 	add	x19, x24, #0x40
    5d00:	97fff2ec 	bl	28b0 <free@plt>
    5d04:	f900231f 	str	xzr, [x24, #64]
    5d08:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d0c:	f947f400 	ldr	x0, [x0, #4072]
    5d10:	f900227f 	str	xzr, [x19, #64]
    5d14:	a90b7e7f 	stp	xzr, xzr, [x19, #176]
    5d18:	f9401fe2 	ldr	x2, [sp, #56]
    5d1c:	f9400001 	ldr	x1, [x0]
    5d20:	eb010042 	subs	x2, x2, x1
    5d24:	d2800001 	mov	x1, #0x0                   	// #0
    5d28:	540000e1 	b.ne	5d44 <fwp_tape_finish+0xf4>  // b.any
    5d2c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5d30:	a94553f3 	ldp	x19, x20, [sp, #80]
    5d34:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5d38:	a94763f7 	ldp	x23, x24, [sp, #112]
    5d3c:	910203ff 	add	sp, sp, #0x80
    5d40:	d65f03c0 	ret
    5d44:	97fff2ab 	bl	27f0 <__stack_chk_fail@plt>
    5d48:	d503201f 	nop
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_tape_scope_release>:
    5d50:	d10243ff 	sub	sp, sp, #0x90
    5d54:	a9047bfd 	stp	x29, x30, [sp, #64]
    5d58:	910103fd 	add	x29, sp, #0x40
    5d5c:	a90553f3 	stp	x19, x20, [sp, #80]
    5d60:	aa0003f4 	mov	x20, x0
    5d64:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d68:	f947f400 	ldr	x0, [x0, #4072]
    5d6c:	b9400285 	ldr	w5, [x20]
    5d70:	f9400001 	ldr	x1, [x0]
    5d74:	f9001fe1 	str	x1, [sp, #56]
    5d78:	d2800001 	mov	x1, #0x0                   	// #0
    5d7c:	37f806c5 	tbnz	w5, #31, 5e54 <fwp_tape_scope_release+0x104>
    5d80:	a90763f7 	stp	x23, x24, [sp, #112]
    5d84:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5d88:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5d8c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5d90:	f00000d3 	adrp	x19, 20000 <__data_start>
    5d94:	910003f7 	mov	x23, sp
    5d98:	91010273 	add	x19, x19, #0x40
    5d9c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5da0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5da4:	52800d16 	mov	w22, #0x68                  	// #104
    5da8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5dac:	f90043f9 	str	x25, [sp, #128]
    5db0:	14000006 	b	5dc8 <fwp_tape_scope_release+0x78>
    5db4:	97fff533 	bl	3280 <fwp_tape_buffers_dispose>
    5db8:	aa1903e0 	mov	x0, x25
    5dbc:	97ffff59 	bl	5b20 <fwp_owned_tape_release>
    5dc0:	b9400285 	ldr	w5, [x20]
    5dc4:	37f80425 	tbnz	w5, #31, 5e48 <fwp_tape_scope_release+0xf8>
    5dc8:	f9400266 	ldr	x6, [x19]
    5dcc:	9b367ca5 	smull	x5, w5, w22
    5dd0:	8b0500c0 	add	x0, x6, x5
    5dd4:	97fff44f 	bl	2f10 <fwp_tape_unlink_scope>
    5dd8:	ad410001 	ldp	q1, q0, [x0, #32]
    5ddc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5de0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5de4:	f9400c03 	ldr	x3, [x0, #24]
    5de8:	ad0003e1 	stp	q1, q0, [sp]
    5dec:	b86568c1 	ldr	w1, [x6, x5]
    5df0:	a9440804 	ldp	x4, x2, [x0, #64]
    5df4:	b900041f 	str	wzr, [x0, #4]
    5df8:	f9403019 	ldr	x25, [x0, #96]
    5dfc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5e00:	f9000c1f 	str	xzr, [x0, #24]
    5e04:	a9020fe4 	stp	x4, x3, [sp, #32]
    5e08:	f9001be2 	str	x2, [sp, #48]
    5e0c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5e10:	f900301f 	str	xzr, [x0, #96]
    5e14:	6b15003f 	cmp	w1, w21
    5e18:	540000e8 	b.hi	5e34 <fwp_tape_scope_release+0xe4>  // b.pmore
    5e1c:	9343fca5 	asr	x5, x5, #3
    5e20:	f9405e60 	ldr	x0, [x19, #184]
    5e24:	9b187ca5 	mul	x5, x5, x24
    5e28:	eb0000bf 	cmp	x5, x0
    5e2c:	5400004a 	b.ge	5e34 <fwp_tape_scope_release+0xe4>  // b.tcont
    5e30:	f9005e65 	str	x5, [x19, #184]
    5e34:	aa1703e0 	mov	x0, x23
    5e38:	b5fffbf9 	cbnz	x25, 5db4 <fwp_tape_scope_release+0x64>
    5e3c:	97fff8a5 	bl	40d0 <fwp_tape_buffers_release>
    5e40:	b9400285 	ldr	w5, [x20]
    5e44:	36fffc25 	tbz	w5, #31, 5dc8 <fwp_tape_scope_release+0x78>
    5e48:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5e4c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5e50:	f94043f9 	ldr	x25, [sp, #128]
    5e54:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5e58:	f947f400 	ldr	x0, [x0, #4072]
    5e5c:	f9401fe2 	ldr	x2, [sp, #56]
    5e60:	f9400001 	ldr	x1, [x0]
    5e64:	eb010042 	subs	x2, x2, x1
    5e68:	d2800001 	mov	x1, #0x0                   	// #0
    5e6c:	540000a1 	b.ne	5e80 <fwp_tape_scope_release+0x130>  // b.any
    5e70:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5e74:	a94553f3 	ldp	x19, x20, [sp, #80]
    5e78:	910243ff 	add	sp, sp, #0x90
    5e7c:	d65f03c0 	ret
    5e80:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e84:	a90763f7 	stp	x23, x24, [sp, #112]
    5e88:	f90043f9 	str	x25, [sp, #128]
    5e8c:	97fff259 	bl	27f0 <__stack_chk_fail@plt>

0000000000005e90 <fwp_task_dispose>:
    5e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e94:	910003fd 	mov	x29, sp
    5e98:	f9000bf3 	str	x19, [sp, #16]
    5e9c:	aa0003f3 	mov	x19, x0
    5ea0:	39414000 	ldrb	w0, [x0, #80]
    5ea4:	36000720 	tbz	w0, #0, 5f88 <fwp_task_dispose+0xf8>
    5ea8:	f9400a60 	ldr	x0, [x19, #16]
    5eac:	b50006e0 	cbnz	x0, 5f88 <fwp_task_dispose+0xf8>
    5eb0:	a9478660 	ldp	x0, x1, [x19, #120]
    5eb4:	39014e7f 	strb	wzr, [x19, #83]
    5eb8:	f9003e7f 	str	xzr, [x19, #120]
    5ebc:	f100003f 	cmp	x1, #0x0
    5ec0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    5ec4:	54000040 	b.eq	5ecc <fwp_task_dispose+0x3c>  // b.none
    5ec8:	d63f0020 	blr	x1
    5ecc:	f9405660 	ldr	x0, [x19, #168]
    5ed0:	97fffa3c 	bl	47c0 <fwp_mem_free>
    5ed4:	f900567f 	str	xzr, [x19, #168]
    5ed8:	b9405e60 	ldr	w0, [x19, #92]
    5edc:	7100041f 	cmp	w0, #0x1
    5ee0:	54000420 	b.eq	5f64 <fwp_task_dispose+0xd4>  // b.none
    5ee4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    5ee8:	9115c042 	add	x2, x2, #0x570
    5eec:	f949d840 	ldr	x0, [x2, #5040]
    5ef0:	f949ec41 	ldr	x1, [x2, #5080]
    5ef4:	cb000260 	sub	x0, x19, x0
    5ef8:	eb01401f 	cmp	x0, x1, lsl #16
    5efc:	540002e2 	b.cs	5f58 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5f00:	d350fc01 	lsr	x1, x0, #16
    5f04:	f949fc44 	ldr	x4, [x2, #5112]
    5f08:	8b010821 	add	x1, x1, x1, lsl #2
    5f0c:	d37df021 	lsl	x1, x1, #3
    5f10:	8b010083 	add	x3, x4, x1
    5f14:	f9401062 	ldr	x2, [x3, #32]
    5f18:	b4000202 	cbz	x2, 5f58 <fwp_task_dispose+0xc8>
    5f1c:	38616881 	ldrb	w1, [x4, x1]
    5f20:	7100083f 	cmp	w1, #0x2
    5f24:	54000280 	b.eq	5f74 <fwp_task_dispose+0xe4>  // b.none
    5f28:	7100043f 	cmp	w1, #0x1
    5f2c:	54000161 	b.ne	5f58 <fwp_task_dispose+0xc8>  // b.any
    5f30:	29430464 	ldp	w4, w1, [x3, #24]
    5f34:	92403c00 	and	x0, x0, #0xffff
    5f38:	9b047c00 	mul	x0, x0, x4
    5f3c:	d360fc00 	lsr	x0, x0, #32
    5f40:	eb01001f 	cmp	x0, x1
    5f44:	540000a2 	b.cs	5f58 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5f48:	8b000042 	add	x2, x2, x0
    5f4c:	39400040 	ldrb	w0, [x2]
    5f50:	7100041f 	cmp	w0, #0x1
    5f54:	54000080 	b.eq	5f64 <fwp_task_dispose+0xd4>  // b.none
    5f58:	f9400bf3 	ldr	x19, [sp, #16]
    5f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f60:	d65f03c0 	ret
    5f64:	aa1303e0 	mov	x0, x19
    5f68:	f9400bf3 	ldr	x19, [sp, #16]
    5f6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f70:	17fffa14 	b	47c0 <fwp_mem_free>
    5f74:	72003c1f 	tst	w0, #0xffff
    5f78:	54fffea0 	b.eq	5f4c <fwp_task_dispose+0xbc>  // b.none
    5f7c:	f9400bf3 	ldr	x19, [sp, #16]
    5f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f84:	d65f03c0 	ret
    5f88:	97fff22e 	bl	2840 <abort@plt>
    5f8c:	d503201f 	nop

0000000000005f90 <fwp_free_zombie>:
    5f90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f94:	910003fd 	mov	x29, sp
    5f98:	a90153f3 	stp	x19, x20, [sp, #16]
    5f9c:	f00000d4 	adrp	x20, 20000 <__data_start>
    5fa0:	91010281 	add	x1, x20, #0x40
    5fa4:	f9406033 	ldr	x19, [x1, #192]
    5fa8:	b4000333 	cbz	x19, 600c <fwp_free_zombie+0x7c>
    5fac:	f9400820 	ldr	x0, [x1, #16]
    5fb0:	eb00027f 	cmp	x19, x0
    5fb4:	540002c0 	b.eq	600c <fwp_free_zombie+0x7c>  // b.none
    5fb8:	b940c822 	ldr	w2, [x1, #200]
    5fbc:	f9400a60 	ldr	x0, [x19, #16]
    5fc0:	7100fc5f 	cmp	w2, #0x3f
    5fc4:	5400078c 	b.gt	60b4 <fwp_free_zombie+0x124>
    5fc8:	91034023 	add	x3, x1, #0xd0
    5fcc:	11000444 	add	w4, w2, #0x1
    5fd0:	b900c824 	str	w4, [x1, #200]
    5fd4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    5fd8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    5fdc:	a9530261 	ldp	x1, x0, [x19, #304]
    5fe0:	b4000741 	cbz	x1, 60c8 <fwp_free_zombie+0x138>
    5fe4:	f9009c20 	str	x0, [x1, #312]
    5fe8:	b4000040 	cbz	x0, 5ff0 <fwp_free_zombie+0x60>
    5fec:	f9009801 	str	x1, [x0, #304]
    5ff0:	91010294 	add	x20, x20, #0x40
    5ff4:	b9405e60 	ldr	w0, [x19, #92]
    5ff8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    5ffc:	f900629f 	str	xzr, [x20, #192]
    6000:	34000140 	cbz	w0, 6028 <fwp_free_zombie+0x98>
    6004:	7100041f 	cmp	w0, #0x1
    6008:	54000080 	b.eq	6018 <fwp_free_zombie+0x88>  // b.none
    600c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6010:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6014:	d65f03c0 	ret
    6018:	aa1303e0 	mov	x0, x19
    601c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6020:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6024:	17ffff9b 	b	5e90 <fwp_task_dispose>
    6028:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc70>
    602c:	9115c082 	add	x2, x4, #0x570
    6030:	f949d841 	ldr	x1, [x2, #5040]
    6034:	f949ec40 	ldr	x0, [x2, #5080]
    6038:	cb010261 	sub	x1, x19, x1
    603c:	eb00403f 	cmp	x1, x0, lsl #16
    6040:	54fffe62 	b.cs	600c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6044:	d350fc20 	lsr	x0, x1, #16
    6048:	f949fc43 	ldr	x3, [x2, #5112]
    604c:	8b000800 	add	x0, x0, x0, lsl #2
    6050:	d37df000 	lsl	x0, x0, #3
    6054:	8b000062 	add	x2, x3, x0
    6058:	f9401054 	ldr	x20, [x2, #32]
    605c:	b4fffd94 	cbz	x20, 600c <fwp_free_zombie+0x7c>
    6060:	38606860 	ldrb	w0, [x3, x0]
    6064:	7100081f 	cmp	w0, #0x2
    6068:	54000360 	b.eq	60d4 <fwp_free_zombie+0x144>  // b.none
    606c:	7100041f 	cmp	w0, #0x1
    6070:	54fffce1 	b.ne	600c <fwp_free_zombie+0x7c>  // b.any
    6074:	29430043 	ldp	w3, w0, [x2, #24]
    6078:	92403c21 	and	x1, x1, #0xffff
    607c:	9b037c21 	mul	x1, x1, x3
    6080:	d360fc21 	lsr	x1, x1, #32
    6084:	eb00003f 	cmp	x1, x0
    6088:	54fffc22 	b.cs	600c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    608c:	8b010294 	add	x20, x20, x1
    6090:	39400280 	ldrb	w0, [x20]
    6094:	34fffbc0 	cbz	w0, 600c <fwp_free_zombie+0x7c>
    6098:	7100041f 	cmp	w0, #0x1
    609c:	54fffbe0 	b.eq	6018 <fwp_free_zombie+0x88>  // b.none
    60a0:	7103fc1f 	cmp	w0, #0xff
    60a4:	540001e0 	b.eq	60e0 <fwp_free_zombie+0x150>  // b.none
    60a8:	51000400 	sub	w0, w0, #0x1
    60ac:	39000280 	strb	w0, [x20]
    60b0:	17ffffd7 	b	600c <fwp_free_zombie+0x7c>
    60b4:	f9400e61 	ldr	x1, [x19, #24]
    60b8:	97fff216 	bl	2910 <munmap@plt>
    60bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    60c0:	a9530261 	ldp	x1, x0, [x19, #304]
    60c4:	b5fff901 	cbnz	x1, 5fe4 <fwp_free_zombie+0x54>
    60c8:	91010282 	add	x2, x20, #0x40
    60cc:	f9016840 	str	x0, [x2, #720]
    60d0:	17ffffc6 	b	5fe8 <fwp_free_zombie+0x58>
    60d4:	72003c3f 	tst	w1, #0xffff
    60d8:	54fff9a1 	b.ne	600c <fwp_free_zombie+0x7c>  // b.any
    60dc:	17ffffed 	b	6090 <fwp_free_zombie+0x100>
    60e0:	ca544680 	eor	x0, x20, x20, lsr #17
    60e4:	9115c084 	add	x4, x4, #0x570
    60e8:	ca402400 	eor	x0, x0, x0, lsr #9
    60ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    60f0:	f94a2400 	ldr	x0, [x0, #5192]
    60f4:	b5000080 	cbnz	x0, 6104 <fwp_free_zombie+0x174>
    60f8:	14000010 	b	6138 <fwp_free_zombie+0x1a8>
    60fc:	f9400800 	ldr	x0, [x0, #16]
    6100:	b40001c0 	cbz	x0, 6138 <fwp_free_zombie+0x1a8>
    6104:	f9400001 	ldr	x1, [x0]
    6108:	eb14003f 	cmp	x1, x20
    610c:	54ffff81 	b.ne	60fc <fwp_free_zombie+0x16c>  // b.any
    6110:	f9400401 	ldr	x1, [x0, #8]
    6114:	d1000421 	sub	x1, x1, #0x1
    6118:	f9000401 	str	x1, [x0, #8]
    611c:	f103f83f 	cmp	x1, #0xfe
    6120:	54fff761 	b.ne	600c <fwp_free_zombie+0x7c>  // b.any
    6124:	aa1403e0 	mov	x0, x20
    6128:	97fff906 	bl	4540 <fwp_rc_forget_slot>
    612c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6130:	39000280 	strb	w0, [x20]
    6134:	17ffffb6 	b	600c <fwp_free_zombie+0x7c>
    6138:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    613c:	91162000 	add	x0, x0, #0x588
    6140:	97fff4f0 	bl	3500 <fwp_trap>

0000000000006144 <fwp_block>:
    6144:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6148:	910003fd 	mov	x29, sp
    614c:	a90153f3 	stp	x19, x20, [sp, #16]
    6150:	d00000d3 	adrp	x19, 20000 <__data_start>
    6154:	91010274 	add	x20, x19, #0x40
    6158:	f9401a82 	ldr	x2, [x20, #48]
    615c:	b4000622 	cbz	x2, 6220 <fwp_block+0xdc>
    6160:	91010261 	add	x1, x19, #0x40
    6164:	f9408040 	ldr	x0, [x2, #256]
    6168:	f9001820 	str	x0, [x1, #48]
    616c:	b4000680 	cbz	x0, 623c <fwp_block+0xf8>
    6170:	91010263 	add	x3, x19, #0x40
    6174:	3901505f 	strb	wzr, [x2, #84]
    6178:	f9400864 	ldr	x4, [x3, #16]
    617c:	eb02009f 	cmp	x4, x2
    6180:	54000440 	b.eq	6208 <fwp_block+0xc4>  // b.none
    6184:	f9416c65 	ldr	x5, [x3, #728]
    6188:	f9000862 	str	x2, [x3, #16]
    618c:	f9400441 	ldr	x1, [x2, #8]
    6190:	f9004885 	str	x5, [x4, #144]
    6194:	f9417065 	ldr	x5, [x3, #736]
    6198:	f9004c85 	str	x5, [x4, #152]
    619c:	f9417465 	ldr	x5, [x3, #744]
    61a0:	f9005085 	str	x5, [x4, #160]
    61a4:	f9417865 	ldr	x5, [x3, #752]
    61a8:	f9005485 	str	x5, [x4, #168]
    61ac:	f9417c65 	ldr	x5, [x3, #760]
    61b0:	f9005885 	str	x5, [x4, #176]
    61b4:	f9418065 	ldr	x5, [x3, #768]
    61b8:	f9005c85 	str	x5, [x4, #184]
    61bc:	f9418465 	ldr	x5, [x3, #776]
    61c0:	f9006085 	str	x5, [x4, #192]
    61c4:	f9400480 	ldr	x0, [x4, #8]
    61c8:	f9404844 	ldr	x4, [x2, #144]
    61cc:	f9016c64 	str	x4, [x3, #728]
    61d0:	f9404c44 	ldr	x4, [x2, #152]
    61d4:	f9017064 	str	x4, [x3, #736]
    61d8:	f9405044 	ldr	x4, [x2, #160]
    61dc:	f9017464 	str	x4, [x3, #744]
    61e0:	f9405444 	ldr	x4, [x2, #168]
    61e4:	f9017864 	str	x4, [x3, #752]
    61e8:	f9405844 	ldr	x4, [x2, #176]
    61ec:	f9017c64 	str	x4, [x3, #760]
    61f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    61f4:	f9018064 	str	x4, [x3, #768]
    61f8:	f9018462 	str	x2, [x3, #776]
    61fc:	97fff195 	bl	2850 <swapcontext@plt>
    6200:	97ffff64 	bl	5f90 <fwp_free_zombie>
    6204:	d503201f 	nop
    6208:	91010260 	add	x0, x19, #0x40
    620c:	b9431000 	ldr	w0, [x0, #784]
    6210:	340001a0 	cbz	w0, 6244 <fwp_block+0x100>
    6214:	a94153f3 	ldp	x19, x20, [sp, #16]
    6218:	a8c27bfd 	ldp	x29, x30, [sp], #32
    621c:	d65f03c0 	ret
    6220:	97fff7f4 	bl	41f0 <fwp_poll_events>
    6224:	f9401a82 	ldr	x2, [x20, #48]
    6228:	b4ffffc2 	cbz	x2, 6220 <fwp_block+0xdc>
    622c:	91010261 	add	x1, x19, #0x40
    6230:	f9408040 	ldr	x0, [x2, #256]
    6234:	f9001820 	str	x0, [x1, #48]
    6238:	b5fff9c0 	cbnz	x0, 6170 <fwp_block+0x2c>
    623c:	f900143f 	str	xzr, [x1, #40]
    6240:	17ffffcc 	b	6170 <fwp_block+0x2c>
    6244:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6248:	911ae000 	add	x0, x0, #0x6b8
    624c:	97fff1cd 	bl	2980 <getenv@plt>
    6250:	5284e202 	mov	w2, #0x2710                	// #10000
    6254:	b4000060 	cbz	x0, 6260 <fwp_block+0x11c>
    6258:	39400001 	ldrb	w1, [x0]
    625c:	350000c1 	cbnz	w1, 6274 <fwp_block+0x130>
    6260:	91010273 	add	x19, x19, #0x40
    6264:	b9031262 	str	w2, [x19, #784]
    6268:	a94153f3 	ldp	x19, x20, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	d65f03c0 	ret
    6274:	52800142 	mov	w2, #0xa                   	// #10
    6278:	d2800001 	mov	x1, #0x0                   	// #0
    627c:	97fff111 	bl	26c0 <strtoll@plt>
    6280:	d1000403 	sub	x3, x0, #0x1
    6284:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6288:	eb02007f 	cmp	x3, x2
    628c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6290:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6294:	17fffff3 	b	6260 <fwp_block+0x11c>
    6298:	d503201f 	nop
    629c:	d503201f 	nop

00000000000062a0 <fwp_owned_entry161>:
    62a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    62a4:	910003fd 	mov	x29, sp
    62a8:	a90363f7 	stp	x23, x24, [sp, #48]
    62ac:	a9406002 	ldp	x2, x24, [x0]
    62b0:	a90153f3 	stp	x19, x20, [sp, #16]
    62b4:	f9400801 	ldr	x1, [x0, #16]
    62b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    62bc:	ab010055 	adds	x21, x2, x1
    62c0:	54000d06 	b.vs	6460 <fwp_owned_entry161+0x1c0>
    62c4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc70>
    62c8:	9115c281 	add	x1, x20, #0x570
    62cc:	b953a420 	ldr	w0, [x1, #5028]
    62d0:	34000a80 	cbz	w0, 6420 <fwp_owned_entry161+0x180>
    62d4:	397e8820 	ldrb	w0, [x1, #4002]
    62d8:	910f0002 	add	x2, x0, #0x3c0
    62dc:	8b000400 	add	x0, x0, x0, lsl #1
    62e0:	d37df000 	lsl	x0, x0, #3
    62e4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    62e8:	2a1703f6 	mov	w22, w23
    62ec:	f8606833 	ldr	x19, [x1, x0]
    62f0:	b4000853 	cbz	x19, 63f8 <fwp_owned_entry161+0x158>
    62f4:	f9400262 	ldr	x2, [x19]
    62f8:	aa2203e2 	mvn	x2, x2
    62fc:	f8206822 	str	x2, [x1, x0]
    6300:	f10062df 	cmp	x22, #0x18
    6304:	540000e9 	b.ls	6320 <fwp_owned_entry161+0x80>  // b.plast
    6308:	d10066c2 	sub	x2, x22, #0x19
    630c:	91006260 	add	x0, x19, #0x18
    6310:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6314:	52800001 	mov	w1, #0x0                   	// #0
    6318:	91002042 	add	x2, x2, #0x8
    631c:	97fff129 	bl	27c0 <memset@plt>
    6320:	9115c281 	add	x1, x20, #0x570
    6324:	f94a1020 	ldr	x0, [x1, #5152]
    6328:	ab160000 	adds	x0, x0, x22
    632c:	540009c2 	b.cs	6464 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6330:	f94a1422 	ldr	x2, [x1, #5160]
    6334:	f90a1020 	str	x0, [x1, #5152]
    6338:	eb02001f 	cmp	x0, x2
    633c:	54000049 	b.ls	6344 <fwp_owned_entry161+0xa4>  // b.plast
    6340:	f90a1420 	str	x0, [x1, #5160]
    6344:	9115c280 	add	x0, x20, #0x570
    6348:	1e6302e1 	ucvtf	d1, w23
    634c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6350:	1e612800 	fadd	d0, d0, d1
    6354:	fd0a1c00 	str	d0, [x0, #5176]
    6358:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    635c:	9115c294 	add	x20, x20, #0x570
    6360:	a900d678 	stp	x24, x21, [x19, #8]
    6364:	fd47d800 	ldr	d0, [x0, #4016]
    6368:	fd000260 	str	d0, [x19]
    636c:	f949da81 	ldr	x1, [x20, #5040]
    6370:	f949ee80 	ldr	x0, [x20, #5080]
    6374:	cb010261 	sub	x1, x19, x1
    6378:	eb00403f 	cmp	x1, x0, lsl #16
    637c:	54000322 	b.cs	63e0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6380:	d350fc20 	lsr	x0, x1, #16
    6384:	f949fe83 	ldr	x3, [x20, #5112]
    6388:	8b000800 	add	x0, x0, x0, lsl #2
    638c:	d37df002 	lsl	x2, x0, #3
    6390:	8b020060 	add	x0, x3, x2
    6394:	f9401014 	ldr	x20, [x0, #32]
    6398:	b4000254 	cbz	x20, 63e0 <fwp_owned_entry161+0x140>
    639c:	38626862 	ldrb	w2, [x3, x2]
    63a0:	7100085f 	cmp	w2, #0x2
    63a4:	54000480 	b.eq	6434 <fwp_owned_entry161+0x194>  // b.none
    63a8:	7100045f 	cmp	w2, #0x1
    63ac:	540001a1 	b.ne	63e0 <fwp_owned_entry161+0x140>  // b.any
    63b0:	29430002 	ldp	w2, w0, [x0, #24]
    63b4:	92403c21 	and	x1, x1, #0xffff
    63b8:	9b027c21 	mul	x1, x1, x2
    63bc:	d360fc21 	lsr	x1, x1, #32
    63c0:	eb00003f 	cmp	x1, x0
    63c4:	540000e2 	b.cs	63e0 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    63c8:	8b010294 	add	x20, x20, x1
    63cc:	39400280 	ldrb	w0, [x20]
    63d0:	7103fc1f 	cmp	w0, #0xff
    63d4:	54000400 	b.eq	6454 <fwp_owned_entry161+0x1b4>  // b.none
    63d8:	52800020 	mov	w0, #0x1                   	// #1
    63dc:	39000280 	strb	w0, [x20]
    63e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63e4:	aa1303e0 	mov	x0, x19
    63e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    63ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    63f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    63f4:	d65f03c0 	ret
    63f8:	8b000021 	add	x1, x1, x0
    63fc:	f9400433 	ldr	x19, [x1, #8]
    6400:	b4000113 	cbz	x19, 6420 <fwp_owned_entry161+0x180>
    6404:	f9400820 	ldr	x0, [x1, #16]
    6408:	cb130000 	sub	x0, x0, x19
    640c:	eb0002df 	cmp	x22, x0
    6410:	54000088 	b.hi	6420 <fwp_owned_entry161+0x180>  // b.pmore
    6414:	8b160260 	add	x0, x19, x22
    6418:	f9000420 	str	x0, [x1, #8]
    641c:	17ffffb9 	b	6300 <fwp_owned_entry161+0x60>
    6420:	52800001 	mov	w1, #0x0                   	// #0
    6424:	d2800300 	mov	x0, #0x18                  	// #24
    6428:	97fffa06 	bl	4c40 <fwp_heap_alloc>
    642c:	aa0003f3 	mov	x19, x0
    6430:	17ffffca 	b	6358 <fwp_owned_entry161+0xb8>
    6434:	72003c3f 	tst	w1, #0xffff
    6438:	54fffca0 	b.eq	63cc <fwp_owned_entry161+0x12c>  // b.none
    643c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6440:	aa1303e0 	mov	x0, x19
    6444:	a94153f3 	ldp	x19, x20, [sp, #16]
    6448:	a94363f7 	ldp	x23, x24, [sp, #48]
    644c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6450:	d65f03c0 	ret
    6454:	aa1403e0 	mov	x0, x20
    6458:	97fff83a 	bl	4540 <fwp_rc_forget_slot>
    645c:	17ffffdf 	b	63d8 <fwp_owned_entry161+0x138>
    6460:	97fff168 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6464:	97fff2d3 	bl	2fb0 <fwp_heap_oom>
    6468:	d503201f 	nop
    646c:	d503201f 	nop

0000000000006470 <e161>:
    6470:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6474:	910003fd 	mov	x29, sp
    6478:	a90363f7 	stp	x23, x24, [sp, #48]
    647c:	a9406002 	ldp	x2, x24, [x0]
    6480:	a90153f3 	stp	x19, x20, [sp, #16]
    6484:	f9400801 	ldr	x1, [x0, #16]
    6488:	a9025bf5 	stp	x21, x22, [sp, #32]
    648c:	ab010055 	adds	x21, x2, x1
    6490:	54000d86 	b.vs	6640 <e161+0x1d0>
    6494:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc70>
    6498:	9115c281 	add	x1, x20, #0x570
    649c:	b953a420 	ldr	w0, [x1, #5028]
    64a0:	34000ac0 	cbz	w0, 65f8 <e161+0x188>
    64a4:	397e8820 	ldrb	w0, [x1, #4002]
    64a8:	910f0002 	add	x2, x0, #0x3c0
    64ac:	8b000400 	add	x0, x0, x0, lsl #1
    64b0:	d37df000 	lsl	x0, x0, #3
    64b4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    64b8:	2a1703f6 	mov	w22, w23
    64bc:	f8606833 	ldr	x19, [x1, x0]
    64c0:	b4000893 	cbz	x19, 65d0 <e161+0x160>
    64c4:	f9400262 	ldr	x2, [x19]
    64c8:	aa2203e2 	mvn	x2, x2
    64cc:	f8206822 	str	x2, [x1, x0]
    64d0:	f10062df 	cmp	x22, #0x18
    64d4:	540000e9 	b.ls	64f0 <e161+0x80>  // b.plast
    64d8:	d10066c2 	sub	x2, x22, #0x19
    64dc:	91006260 	add	x0, x19, #0x18
    64e0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    64e4:	52800001 	mov	w1, #0x0                   	// #0
    64e8:	91002042 	add	x2, x2, #0x8
    64ec:	97fff0b5 	bl	27c0 <memset@plt>
    64f0:	9115c281 	add	x1, x20, #0x570
    64f4:	f94a1020 	ldr	x0, [x1, #5152]
    64f8:	ab160000 	adds	x0, x0, x22
    64fc:	54000a42 	b.cs	6644 <e161+0x1d4>  // b.hs, b.nlast
    6500:	f94a1422 	ldr	x2, [x1, #5160]
    6504:	f90a1020 	str	x0, [x1, #5152]
    6508:	eb02001f 	cmp	x0, x2
    650c:	54000049 	b.ls	6514 <e161+0xa4>  // b.plast
    6510:	f90a1420 	str	x0, [x1, #5160]
    6514:	9115c280 	add	x0, x20, #0x570
    6518:	1e6302e1 	ucvtf	d1, w23
    651c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6520:	1e612800 	fadd	d0, d0, d1
    6524:	fd0a1c00 	str	d0, [x0, #5176]
    6528:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    652c:	9115c294 	add	x20, x20, #0x570
    6530:	a900d678 	stp	x24, x21, [x19, #8]
    6534:	fd47d800 	ldr	d0, [x0, #4016]
    6538:	fd000260 	str	d0, [x19]
    653c:	f949da81 	ldr	x1, [x20, #5040]
    6540:	f949ee80 	ldr	x0, [x20, #5080]
    6544:	cb010261 	sub	x1, x19, x1
    6548:	eb00403f 	cmp	x1, x0, lsl #16
    654c:	54000322 	b.cs	65b0 <e161+0x140>  // b.hs, b.nlast
    6550:	d350fc20 	lsr	x0, x1, #16
    6554:	f949fe83 	ldr	x3, [x20, #5112]
    6558:	8b000800 	add	x0, x0, x0, lsl #2
    655c:	d37df002 	lsl	x2, x0, #3
    6560:	8b020060 	add	x0, x3, x2
    6564:	f9401014 	ldr	x20, [x0, #32]
    6568:	b4000254 	cbz	x20, 65b0 <e161+0x140>
    656c:	38626862 	ldrb	w2, [x3, x2]
    6570:	7100085f 	cmp	w2, #0x2
    6574:	540004c0 	b.eq	660c <e161+0x19c>  // b.none
    6578:	7100045f 	cmp	w2, #0x1
    657c:	540001a1 	b.ne	65b0 <e161+0x140>  // b.any
    6580:	29430002 	ldp	w2, w0, [x0, #24]
    6584:	92403c21 	and	x1, x1, #0xffff
    6588:	9b027c21 	mul	x1, x1, x2
    658c:	d360fc21 	lsr	x1, x1, #32
    6590:	eb00003f 	cmp	x1, x0
    6594:	540000e2 	b.cs	65b0 <e161+0x140>  // b.hs, b.nlast
    6598:	8b010294 	add	x20, x20, x1
    659c:	39400280 	ldrb	w0, [x20]
    65a0:	7103fc1f 	cmp	w0, #0xff
    65a4:	54000480 	b.eq	6634 <e161+0x1c4>  // b.none
    65a8:	52800020 	mov	w0, #0x1                   	// #1
    65ac:	39000280 	strb	w0, [x20]
    65b0:	aa1303e0 	mov	x0, x19
    65b4:	97fffbeb 	bl	5560 <fwp_rc_share>
    65b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65bc:	aa1303e0 	mov	x0, x19
    65c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    65c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    65c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    65cc:	d65f03c0 	ret
    65d0:	8b000021 	add	x1, x1, x0
    65d4:	f9400433 	ldr	x19, [x1, #8]
    65d8:	b4000113 	cbz	x19, 65f8 <e161+0x188>
    65dc:	f9400820 	ldr	x0, [x1, #16]
    65e0:	cb130000 	sub	x0, x0, x19
    65e4:	eb0002df 	cmp	x22, x0
    65e8:	54000088 	b.hi	65f8 <e161+0x188>  // b.pmore
    65ec:	8b160260 	add	x0, x19, x22
    65f0:	f9000420 	str	x0, [x1, #8]
    65f4:	17ffffb7 	b	64d0 <e161+0x60>
    65f8:	52800001 	mov	w1, #0x0                   	// #0
    65fc:	d2800300 	mov	x0, #0x18                  	// #24
    6600:	97fff990 	bl	4c40 <fwp_heap_alloc>
    6604:	aa0003f3 	mov	x19, x0
    6608:	17ffffc8 	b	6528 <e161+0xb8>
    660c:	72003c3f 	tst	w1, #0xffff
    6610:	54fffc60 	b.eq	659c <e161+0x12c>  // b.none
    6614:	aa1303e0 	mov	x0, x19
    6618:	97fffbd2 	bl	5560 <fwp_rc_share>
    661c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6620:	aa1303e0 	mov	x0, x19
    6624:	a94153f3 	ldp	x19, x20, [sp, #16]
    6628:	a94363f7 	ldp	x23, x24, [sp, #48]
    662c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6630:	d65f03c0 	ret
    6634:	aa1403e0 	mov	x0, x20
    6638:	97fff7c2 	bl	4540 <fwp_rc_forget_slot>
    663c:	17ffffdb 	b	65a8 <e161+0x138>
    6640:	97fff0f0 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6644:	97fff25b 	bl	2fb0 <fwp_heap_oom>
    6648:	d503201f 	nop
    664c:	d503201f 	nop

0000000000006650 <fwp_drop4>:
    6650:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6654:	910003fd 	mov	x29, sp
    6658:	a90153f3 	stp	x19, x20, [sp, #16]
    665c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc70>
    6660:	f90013f5 	str	x21, [sp, #32]
    6664:	9115c275 	add	x21, x19, #0x570
    6668:	f949daa1 	ldr	x1, [x21, #5040]
    666c:	f949eea2 	ldr	x2, [x21, #5080]
    6670:	cb010001 	sub	x1, x0, x1
    6674:	eb02403f 	cmp	x1, x2, lsl #16
    6678:	54000382 	b.cs	66e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    667c:	d350fc22 	lsr	x2, x1, #16
    6680:	f949fea3 	ldr	x3, [x21, #5112]
    6684:	8b020842 	add	x2, x2, x2, lsl #2
    6688:	d37df042 	lsl	x2, x2, #3
    668c:	8b020064 	add	x4, x3, x2
    6690:	f9401094 	ldr	x20, [x4, #32]
    6694:	b40002b4 	cbz	x20, 66e8 <fwp_drop4+0x98>
    6698:	38626862 	ldrb	w2, [x3, x2]
    669c:	7100085f 	cmp	w2, #0x2
    66a0:	540007a0 	b.eq	6794 <fwp_drop4+0x144>  // b.none
    66a4:	7100045f 	cmp	w2, #0x1
    66a8:	54000201 	b.ne	66e8 <fwp_drop4+0x98>  // b.any
    66ac:	29430885 	ldp	w5, w2, [x4, #24]
    66b0:	92403c21 	and	x1, x1, #0xffff
    66b4:	9b057c21 	mul	x1, x1, x5
    66b8:	d360fc21 	lsr	x1, x1, #32
    66bc:	eb02003f 	cmp	x1, x2
    66c0:	54000142 	b.cs	66e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    66c4:	8b010294 	add	x20, x20, x1
    66c8:	39400281 	ldrb	w1, [x20]
    66cc:	340000e1 	cbz	w1, 66e8 <fwp_drop4+0x98>
    66d0:	7100043f 	cmp	w1, #0x1
    66d4:	54000120 	b.eq	66f8 <fwp_drop4+0xa8>  // b.none
    66d8:	7103fc3f 	cmp	w1, #0xff
    66dc:	540007c0 	b.eq	67d4 <fwp_drop4+0x184>  // b.none
    66e0:	51000421 	sub	w1, w1, #0x1
    66e4:	39000281 	strb	w1, [x20]
    66e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    66ec:	f94013f5 	ldr	x21, [sp, #32]
    66f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66f4:	d65f03c0 	ret
    66f8:	f9400001 	ldr	x1, [x0]
    66fc:	b7f80581 	tbnz	x1, #63, 67ac <fwp_drop4+0x15c>
    6700:	9115c273 	add	x19, x19, #0x570
    6704:	f949da61 	ldr	x1, [x19, #5040]
    6708:	f949ee62 	ldr	x2, [x19, #5080]
    670c:	cb010001 	sub	x1, x0, x1
    6710:	eb02403f 	cmp	x1, x2, lsl #16
    6714:	54fffea2 	b.cs	66e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6718:	d350fc22 	lsr	x2, x1, #16
    671c:	8b020842 	add	x2, x2, x2, lsl #2
    6720:	d37df042 	lsl	x2, x2, #3
    6724:	8b020065 	add	x5, x3, x2
    6728:	f94010a4 	ldr	x4, [x5, #32]
    672c:	b4fffde4 	cbz	x4, 66e8 <fwp_drop4+0x98>
    6730:	38626862 	ldrb	w2, [x3, x2]
    6734:	7100085f 	cmp	w2, #0x2
    6738:	54000220 	b.eq	677c <fwp_drop4+0x12c>  // b.none
    673c:	7100045f 	cmp	w2, #0x1
    6740:	54fffd41 	b.ne	66e8 <fwp_drop4+0x98>  // b.any
    6744:	294308a3 	ldp	w3, w2, [x5, #24]
    6748:	92403c21 	and	x1, x1, #0xffff
    674c:	9b037c21 	mul	x1, x1, x3
    6750:	d360fc21 	lsr	x1, x1, #32
    6754:	eb02003f 	cmp	x1, x2
    6758:	54fffc82 	b.cs	66e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    675c:	8b010084 	add	x4, x4, x1
    6760:	39400081 	ldrb	w1, [x4]
    6764:	7100043f 	cmp	w1, #0x1
    6768:	54fffc01 	b.ne	66e8 <fwp_drop4+0x98>  // b.any
    676c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6770:	f94013f5 	ldr	x21, [sp, #32]
    6774:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6778:	17fff812 	b	47c0 <fwp_mem_free>
    677c:	72003c3f 	tst	w1, #0xffff
    6780:	54ffff00 	b.eq	6760 <fwp_drop4+0x110>  // b.none
    6784:	a94153f3 	ldp	x19, x20, [sp, #16]
    6788:	f94013f5 	ldr	x21, [sp, #32]
    678c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6790:	d65f03c0 	ret
    6794:	72003c3f 	tst	w1, #0xffff
    6798:	54fff980 	b.eq	66c8 <fwp_drop4+0x78>  // b.none
    679c:	a94153f3 	ldp	x19, x20, [sp, #16]
    67a0:	f94013f5 	ldr	x21, [sp, #32]
    67a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67a8:	d65f03c0 	ret
    67ac:	f9400414 	ldr	x20, [x0, #8]
    67b0:	97fffb91 	bl	55f4 <fwp_rc_free_arr>
    67b4:	9115c260 	add	x0, x19, #0x570
    67b8:	f949d801 	ldr	x1, [x0, #5040]
    67bc:	f949ec00 	ldr	x0, [x0, #5080]
    67c0:	cb010281 	sub	x1, x20, x1
    67c4:	eb00403f 	cmp	x1, x0, lsl #16
    67c8:	54fff902 	b.cs	66e8 <fwp_drop4+0x98>  // b.hs, b.nlast
    67cc:	aa1403e0 	mov	x0, x20
    67d0:	17ffffab 	b	667c <fwp_drop4+0x2c>
    67d4:	ca544680 	eor	x0, x20, x20, lsr #17
    67d8:	9115c273 	add	x19, x19, #0x570
    67dc:	ca402400 	eor	x0, x0, x0, lsr #9
    67e0:	8b200e60 	add	x0, x19, w0, uxtb #3
    67e4:	f94a2400 	ldr	x0, [x0, #5192]
    67e8:	b5000080 	cbnz	x0, 67f8 <fwp_drop4+0x1a8>
    67ec:	14000010 	b	682c <fwp_drop4+0x1dc>
    67f0:	f9400800 	ldr	x0, [x0, #16]
    67f4:	b40001c0 	cbz	x0, 682c <fwp_drop4+0x1dc>
    67f8:	f9400001 	ldr	x1, [x0]
    67fc:	eb14003f 	cmp	x1, x20
    6800:	54ffff81 	b.ne	67f0 <fwp_drop4+0x1a0>  // b.any
    6804:	f9400401 	ldr	x1, [x0, #8]
    6808:	d1000421 	sub	x1, x1, #0x1
    680c:	f9000401 	str	x1, [x0, #8]
    6810:	f103f83f 	cmp	x1, #0xfe
    6814:	54fff6a1 	b.ne	66e8 <fwp_drop4+0x98>  // b.any
    6818:	aa1403e0 	mov	x0, x20
    681c:	97fff749 	bl	4540 <fwp_rc_forget_slot>
    6820:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6824:	39000280 	strb	w0, [x20]
    6828:	17ffffb0 	b	66e8 <fwp_drop4+0x98>
    682c:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6830:	91162000 	add	x0, x0, #0x588
    6834:	97fff333 	bl	3500 <fwp_trap>
    6838:	d503201f 	nop
    683c:	d503201f 	nop

0000000000006840 <fwp_caps161>:
    6840:	34000041 	cbz	w1, 6848 <fwp_caps161+0x8>
    6844:	d65f03c0 	ret
    6848:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc70>
    684c:	9115c063 	add	x3, x3, #0x570
    6850:	f949d861 	ldr	x1, [x3, #5040]
    6854:	f949ec62 	ldr	x2, [x3, #5080]
    6858:	cb010001 	sub	x1, x0, x1
    685c:	eb02403f 	cmp	x1, x2, lsl #16
    6860:	54ffff22 	b.cs	6844 <fwp_caps161+0x4>  // b.hs, b.nlast
    6864:	d350fc22 	lsr	x2, x1, #16
    6868:	f949fc65 	ldr	x5, [x3, #5112]
    686c:	8b020842 	add	x2, x2, x2, lsl #2
    6870:	d37df042 	lsl	x2, x2, #3
    6874:	8b0200a4 	add	x4, x5, x2
    6878:	f9401083 	ldr	x3, [x4, #32]
    687c:	b4fffe43 	cbz	x3, 6844 <fwp_caps161+0x4>
    6880:	386268a2 	ldrb	w2, [x5, x2]
    6884:	7100085f 	cmp	w2, #0x2
    6888:	540001c0 	b.eq	68c0 <fwp_caps161+0x80>  // b.none
    688c:	7100045f 	cmp	w2, #0x1
    6890:	54fffda1 	b.ne	6844 <fwp_caps161+0x4>  // b.any
    6894:	29430885 	ldp	w5, w2, [x4, #24]
    6898:	92403c21 	and	x1, x1, #0xffff
    689c:	9b057c21 	mul	x1, x1, x5
    68a0:	d360fc21 	lsr	x1, x1, #32
    68a4:	eb02003f 	cmp	x1, x2
    68a8:	54fffce2 	b.cs	6844 <fwp_caps161+0x4>  // b.hs, b.nlast
    68ac:	8b010063 	add	x3, x3, x1
    68b0:	39400061 	ldrb	w1, [x3]
    68b4:	7100043f 	cmp	w1, #0x1
    68b8:	54fffc61 	b.ne	6844 <fwp_caps161+0x4>  // b.any
    68bc:	17fff7c1 	b	47c0 <fwp_mem_free>
    68c0:	72003c3f 	tst	w1, #0xffff
    68c4:	54ffff60 	b.eq	68b0 <fwp_caps161+0x70>  // b.none
    68c8:	d65f03c0 	ret
    68cc:	d503201f 	nop

00000000000068d0 <f12>:
    68d0:	d10443ff 	sub	sp, sp, #0x110
    68d4:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    68d8:	f947f442 	ldr	x2, [x2, #4072]
    68dc:	a90a7bfd 	stp	x29, x30, [sp, #160]
    68e0:	910283fd 	add	x29, sp, #0xa0
    68e4:	a90b53f3 	stp	x19, x20, [sp, #176]
    68e8:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc70>
    68ec:	9115c283 	add	x3, x20, #0x570
    68f0:	a90d63f7 	stp	x23, x24, [sp, #208]
    68f4:	d00000d7 	adrp	x23, 20000 <__data_start>
    68f8:	910102e4 	add	x4, x23, #0x40
    68fc:	f949d861 	ldr	x1, [x3, #5040]
    6900:	a90c5bf5 	stp	x21, x22, [sp, #192]
    6904:	d00000d5 	adrp	x21, 20000 <__data_start>
    6908:	f949ec65 	ldr	x5, [x3, #5080]
    690c:	a90e6bf9 	stp	x25, x26, [sp, #224]
    6910:	910042b5 	add	x21, x21, #0x10
    6914:	a90f73fb 	stp	x27, x28, [sp, #240]
    6918:	9100c3f9 	add	x25, sp, #0x30
    691c:	9100a3f8 	add	x24, sp, #0x28
    6920:	f9417086 	ldr	x6, [x4, #736]
    6924:	fd0083e8 	str	d8, [sp, #256]
    6928:	f9400047 	ldr	x7, [x2]
    692c:	f9004fe7 	str	x7, [sp, #152]
    6930:	d2800007 	mov	x7, #0x0                   	// #0
    6934:	f0fffff3 	adrp	x19, 5000 <fwp_p_ad_push+0x8c>
    6938:	12800007 	mov	w7, #0xffffffff            	// #-1
    693c:	91354262 	add	x2, x19, #0xd50
    6940:	cb0102a1 	sub	x1, x21, x1
    6944:	b9002be7 	str	w7, [sp, #40]
    6948:	a9030be6 	stp	x6, x2, [sp, #48]
    694c:	aa0003f6 	mov	x22, x0
    6950:	f90023f8 	str	x24, [sp, #64]
    6954:	f9017099 	str	x25, [x4, #736]
    6958:	eb05403f 	cmp	x1, x5, lsl #16
    695c:	54000342 	b.cs	69c4 <f12+0xf4>  // b.hs, b.nlast
    6960:	d350fc20 	lsr	x0, x1, #16
    6964:	f949fc64 	ldr	x4, [x3, #5112]
    6968:	8b000800 	add	x0, x0, x0, lsl #2
    696c:	d37df002 	lsl	x2, x0, #3
    6970:	8b020083 	add	x3, x4, x2
    6974:	f9401060 	ldr	x0, [x3, #32]
    6978:	b4000260 	cbz	x0, 69c4 <f12+0xf4>
    697c:	38626882 	ldrb	w2, [x4, x2]
    6980:	7100085f 	cmp	w2, #0x2
    6984:	54007800 	b.eq	7884 <f12+0xfb4>  // b.none
    6988:	7100045f 	cmp	w2, #0x1
    698c:	540001c1 	b.ne	69c4 <f12+0xf4>  // b.any
    6990:	29430864 	ldp	w4, w2, [x3, #24]
    6994:	92403c21 	and	x1, x1, #0xffff
    6998:	9b047c21 	mul	x1, x1, x4
    699c:	d360fc21 	lsr	x1, x1, #32
    69a0:	eb02003f 	cmp	x1, x2
    69a4:	54000102 	b.cs	69c4 <f12+0xf4>  // b.hs, b.nlast
    69a8:	8b010000 	add	x0, x0, x1
    69ac:	39400001 	ldrb	w1, [x0]
    69b0:	340000a1 	cbz	w1, 69c4 <f12+0xf4>
    69b4:	7103f43f 	cmp	w1, #0xfd
    69b8:	54007ec8 	b.hi	7990 <f12+0x10c0>  // b.pmore
    69bc:	11000421 	add	w1, w1, #0x1
    69c0:	39000001 	strb	w1, [x0]
    69c4:	aa1503e0 	mov	x0, x21
    69c8:	97fffc02 	bl	59d0 <fwp_closure_drop>
    69cc:	b4007676 	cbz	x22, 7898 <f12+0xfc8>
    69d0:	aa1603e0 	mov	x0, x22
    69d4:	d2800001 	mov	x1, #0x0                   	// #0
    69d8:	f9400800 	ldr	x0, [x0, #16]
    69dc:	91000421 	add	x1, x1, #0x1
    69e0:	b5ffffc0 	cbnz	x0, 69d8 <f12+0x108>
    69e4:	aa0103fa 	mov	x26, x1
    69e8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    69ec:	eb00003f 	cmp	x1, x0
    69f0:	540081e8 	b.hi	7a2c <f12+0x115c>  // b.pmore
    69f4:	910102f5 	add	x21, x23, #0x40
    69f8:	b94316a0 	ldr	w0, [x21, #788]
    69fc:	34007300 	cbz	w0, 785c <f12+0xf8c>
    6a00:	910102e0 	add	x0, x23, #0x40
    6a04:	f940201b 	ldr	x27, [x0, #64]
    6a08:	f9405c15 	ldr	x21, [x0, #184]
    6a0c:	eb1b02bf 	cmp	x21, x27
    6a10:	5400358a 	b.ge	70c0 <f12+0x7f0>  // b.tcont
    6a14:	f94022e1 	ldr	x1, [x23, #64]
    6a18:	8b1506a0 	add	x0, x21, x21, lsl #1
    6a1c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6a20:	8b000aa0 	add	x0, x21, x0, lsl #2
    6a24:	8b000c20 	add	x0, x1, x0, lsl #3
    6a28:	b9400401 	ldr	w1, [x0, #4]
    6a2c:	35000081 	cbnz	w1, 6a3c <f12+0x16c>
    6a30:	b9400001 	ldr	w1, [x0]
    6a34:	6b02003f 	cmp	w1, w2
    6a38:	54003449 	b.ls	70c0 <f12+0x7f0>  // b.plast
    6a3c:	910006b5 	add	x21, x21, #0x1
    6a40:	9101a000 	add	x0, x0, #0x68
    6a44:	eb1b02bf 	cmp	x21, x27
    6a48:	54ffff01 	b.ne	6a28 <f12+0x158>  // b.any
    6a4c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6a50:	eb00037f 	cmp	x27, x0
    6a54:	54007f2c 	b.gt	7a38 <f12+0x1168>
    6a58:	910102e0 	add	x0, x23, #0x40
    6a5c:	f94022fc 	ldr	x28, [x23, #64]
    6a60:	f9405800 	ldr	x0, [x0, #176]
    6a64:	eb1b001f 	cmp	x0, x27
    6a68:	54000241 	b.ne	6ab0 <f12+0x1e0>  // b.any
    6a6c:	b40077bb 	cbz	x27, 7960 <f12+0x1090>
    6a70:	d37ffb62 	lsl	x2, x27, #1
    6a74:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6a78:	eb00005f 	cmp	x2, x0
    6a7c:	9a80d042 	csel	x2, x2, x0, le
    6a80:	8b020441 	add	x1, x2, x2, lsl #1
    6a84:	8b010841 	add	x1, x2, x1, lsl #2
    6a88:	d37df021 	lsl	x1, x1, #3
    6a8c:	aa1c03e0 	mov	x0, x28
    6a90:	f90003e2 	str	x2, [sp]
    6a94:	97ffef53 	bl	27e0 <realloc@plt>
    6a98:	aa0003fc 	mov	x28, x0
    6a9c:	f94003e2 	ldr	x2, [sp]
    6aa0:	b4006c00 	cbz	x0, 7820 <f12+0xf50>
    6aa4:	910102e0 	add	x0, x23, #0x40
    6aa8:	f90022fc 	str	x28, [x23, #64]
    6aac:	f9005802 	str	x2, [x0, #176]
    6ab0:	910102e1 	add	x1, x23, #0x40
    6ab4:	8b1b0760 	add	x0, x27, x27, lsl #1
    6ab8:	4f000400 	movi	v0.4s, #0x0
    6abc:	91000762 	add	x2, x27, #0x1
    6ac0:	8b000b60 	add	x0, x27, x0, lsl #2
    6ac4:	f9002022 	str	x2, [x1, #64]
    6ac8:	8b1506a1 	add	x1, x21, x21, lsl #1
    6acc:	8b000f80 	add	x0, x28, x0, lsl #3
    6ad0:	8b010abb 	add	x27, x21, x1, lsl #2
    6ad4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6ad8:	ad000000 	stp	q0, q0, [x0]
    6adc:	ad010000 	stp	q0, q0, [x0, #32]
    6ae0:	ad020000 	stp	q0, q0, [x0, #64]
    6ae4:	f900301f 	str	xzr, [x0, #96]
    6ae8:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6aec:	f900337f 	str	xzr, [x27, #96]
    6af0:	91146000 	add	x0, x0, #0x518
    6af4:	97ffefa3 	bl	2980 <getenv@plt>
    6af8:	b5002fa0 	cbnz	x0, 70ec <f12+0x81c>
    6afc:	d503201f 	nop
    6b00:	910102e0 	add	x0, x23, #0x40
    6b04:	f9405001 	ldr	x1, [x0, #160]
    6b08:	b5006d61 	cbnz	x1, 78b4 <f12+0xfe4>
    6b0c:	910102e1 	add	x1, x23, #0x40
    6b10:	2f000400 	mvni	v0.2s, #0x0
    6b14:	b9400362 	ldr	w2, [x27]
    6b18:	52800024 	mov	w4, #0x1                   	// #1
    6b1c:	910006a3 	add	x3, x21, #0x1
    6b20:	a900eb7a 	stp	x26, x26, [x27, #8]
    6b24:	0b040042 	add	w2, w2, w4
    6b28:	f9417020 	ldr	x0, [x1, #736]
    6b2c:	29001362 	stp	w2, w4, [x27]
    6b30:	f9002b7f 	str	xzr, [x27, #80]
    6b34:	f9005c23 	str	x3, [x1, #184]
    6b38:	fd002f60 	str	d0, [x27, #88]
    6b3c:	b4007720 	cbz	x0, 7a20 <f12+0x1150>
    6b40:	91354273 	add	x19, x19, #0xd50
    6b44:	14000003 	b	6b50 <f12+0x280>
    6b48:	f9400000 	ldr	x0, [x0]
    6b4c:	b40076a0 	cbz	x0, 7a20 <f12+0x1150>
    6b50:	f9400401 	ldr	x1, [x0, #8]
    6b54:	eb13003f 	cmp	x1, x19
    6b58:	54ffff81 	b.ne	6b48 <f12+0x278>  // b.any
    6b5c:	f9400800 	ldr	x0, [x0, #16]
    6b60:	2a1503e4 	mov	w4, w21
    6b64:	b9400001 	ldr	w1, [x0]
    6b68:	f9002b60 	str	x0, [x27, #80]
    6b6c:	b9005f61 	str	w1, [x27, #92]
    6b70:	37f80081 	tbnz	w1, #31, 6b80 <f12+0x2b0>
    6b74:	52800d05 	mov	w5, #0x68                  	// #104
    6b78:	9b257021 	smaddl	x1, w1, w5, x28
    6b7c:	b9005835 	str	w21, [x1, #88]
    6b80:	b9000004 	str	w4, [x0]
    6b84:	d3707c42 	ubfiz	x2, x2, #16, #32
    6b88:	aa03005a 	orr	x26, x2, x3
    6b8c:	aa1603e0 	mov	x0, x22
    6b90:	d2800002 	mov	x2, #0x0                   	// #0
    6b94:	b4006176 	cbz	x22, 77c0 <f12+0xef0>
    6b98:	f9400800 	ldr	x0, [x0, #16]
    6b9c:	91000442 	add	x2, x2, #0x1
    6ba0:	b5ffffc0 	cbnz	x0, 6b98 <f12+0x2c8>
    6ba4:	aa1603e1 	mov	x1, x22
    6ba8:	f9400821 	ldr	x1, [x1, #16]
    6bac:	91000400 	add	x0, x0, #0x1
    6bb0:	b5ffffc1 	cbnz	x1, 6ba8 <f12+0x2d8>
    6bb4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6bb8:	eb01001f 	cmp	x0, x1
    6bbc:	540074a8 	b.hi	7a50 <f12+0x1180>  // b.pmore
    6bc0:	f100005f 	cmp	x2, #0x0
    6bc4:	54005fed 	b.le	77c0 <f12+0xef0>
    6bc8:	eb00005f 	cmp	x2, x0
    6bcc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6bd0:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6bd4:	eb01027f 	cmp	x19, x1
    6bd8:	540073c8 	b.hi	7a50 <f12+0x1180>  // b.pmore
    6bdc:	d37ffa75 	lsl	x21, x19, #1
    6be0:	52800041 	mov	w1, #0x2                   	// #2
    6be4:	910006a0 	add	x0, x21, #0x1
    6be8:	d37df000 	lsl	x0, x0, #3
    6bec:	97fff815 	bl	4c40 <fwp_heap_alloc>
    6bf0:	aa0003fb 	mov	x27, x0
    6bf4:	9115c281 	add	x1, x20, #0x570
    6bf8:	aa0103e0 	mov	x0, x1
    6bfc:	f9000375 	str	x21, [x27]
    6c00:	f949d821 	ldr	x1, [x1, #5040]
    6c04:	f949ec00 	ldr	x0, [x0, #5080]
    6c08:	cb010361 	sub	x1, x27, x1
    6c0c:	eb00403f 	cmp	x1, x0, lsl #16
    6c10:	54006202 	b.cs	7850 <f12+0xf80>  // b.hs, b.nlast
    6c14:	9115c282 	add	x2, x20, #0x570
    6c18:	d350fc20 	lsr	x0, x1, #16
    6c1c:	8b000800 	add	x0, x0, x0, lsl #2
    6c20:	f949fc43 	ldr	x3, [x2, #5112]
    6c24:	d37df002 	lsl	x2, x0, #3
    6c28:	8b020060 	add	x0, x3, x2
    6c2c:	f9401015 	ldr	x21, [x0, #32]
    6c30:	b4000255 	cbz	x21, 6c78 <f12+0x3a8>
    6c34:	38626862 	ldrb	w2, [x3, x2]
    6c38:	7100085f 	cmp	w2, #0x2
    6c3c:	540061e0 	b.eq	7878 <f12+0xfa8>  // b.none
    6c40:	7100045f 	cmp	w2, #0x1
    6c44:	540001a1 	b.ne	6c78 <f12+0x3a8>  // b.any
    6c48:	29430002 	ldp	w2, w0, [x0, #24]
    6c4c:	92403c21 	and	x1, x1, #0xffff
    6c50:	9b027c21 	mul	x1, x1, x2
    6c54:	d360fc21 	lsr	x1, x1, #32
    6c58:	eb00003f 	cmp	x1, x0
    6c5c:	540000e2 	b.cs	6c78 <f12+0x3a8>  // b.hs, b.nlast
    6c60:	8b0102b5 	add	x21, x21, x1
    6c64:	394002a0 	ldrb	w0, [x21]
    6c68:	7103fc1f 	cmp	w0, #0xff
    6c6c:	54006800 	b.eq	796c <f12+0x109c>  // b.none
    6c70:	52800020 	mov	w0, #0x1                   	// #1
    6c74:	390002a0 	strb	w0, [x21]
    6c78:	b4000233 	cbz	x19, 6cbc <f12+0x3ec>
    6c7c:	d3607f44 	lsl	x4, x26, #32
    6c80:	aa1603e2 	mov	x2, x22
    6c84:	f94006c5 	ldr	x5, [x22, #8]
    6c88:	aa0403e3 	mov	x3, x4
    6c8c:	91002360 	add	x0, x27, #0x8
    6c90:	d2800001 	mov	x1, #0x0                   	// #0
    6c94:	14000005 	b	6ca8 <f12+0x3d8>
    6c98:	f9400445 	ldr	x5, [x2, #8]
    6c9c:	ab040023 	adds	x3, x1, x4
    6ca0:	91004000 	add	x0, x0, #0x10
    6ca4:	54006de6 	b.vs	7a60 <f12+0x1190>
    6ca8:	a9000c05 	stp	x5, x3, [x0]
    6cac:	91000421 	add	x1, x1, #0x1
    6cb0:	f9400842 	ldr	x2, [x2, #16]
    6cb4:	eb01027f 	cmp	x19, x1
    6cb8:	54ffff08 	b.hi	6c98 <f12+0x3c8>  // b.pmore
    6cbc:	f9400360 	ldr	x0, [x27]
    6cc0:	f100041f 	cmp	x0, #0x1
    6cc4:	54005c89 	b.ls	7854 <f12+0xf84>  // b.plast
    6cc8:	d341fc00 	lsr	x0, x0, #1
    6ccc:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    6cd0:	d1000401 	sub	x1, x0, #0x1
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54006bc8 	b.hi	7a50 <f12+0x1180>  // b.pmore
    6cdc:	d37ff83c 	lsl	x28, x1, #1
    6ce0:	b4005ba1 	cbz	x1, 7854 <f12+0xf84>
    6ce4:	d1002361 	sub	x1, x27, #0x8
    6ce8:	91002373 	add	x19, x27, #0x8
    6cec:	8b001035 	add	x21, x1, x0, lsl #4
    6cf0:	f9400660 	ldr	x0, [x19, #8]
    6cf4:	f9400e61 	ldr	x1, [x19, #24]
    6cf8:	fd400260 	ldr	d0, [x19]
    6cfc:	fd400a61 	ldr	d1, [x19, #16]
    6d00:	97fff950 	bl	5240 <w107>
    6d04:	a9000660 	stp	x0, x1, [x19]
    6d08:	91004273 	add	x19, x19, #0x10
    6d0c:	eb15027f 	cmp	x19, x21
    6d10:	54ffff01 	b.ne	6cf0 <f12+0x420>  // b.any
    6d14:	f900037c 	str	x28, [x27]
    6d18:	aa1b03e0 	mov	x0, x27
    6d1c:	93407f53 	sxtw	x19, w26
    6d20:	97fff99c 	bl	5390 <w164.constprop.0>
    6d24:	aa0103f5 	mov	x21, x1
    6d28:	aa1b03e0 	mov	x0, x27
    6d2c:	97fffe49 	bl	6650 <fwp_drop4>
    6d30:	97fff4a5 	bl	3fc4 <caf61>
    6d34:	9e670008 	fmov	d8, x0
    6d38:	aa1303e0 	mov	x0, x19
    6d3c:	97fff2bd 	bl	3830 <fwp_tape_of>
    6d40:	aa0003e8 	mov	x8, x0
    6d44:	f9403001 	ldr	x1, [x0, #96]
    6d48:	b50067e1 	cbnz	x1, 7a44 <f12+0x1174>
    6d4c:	97fff071 	bl	2f10 <fwp_tape_unlink_scope>
    6d50:	b900051f 	str	wzr, [x8, #4]
    6d54:	b9400102 	ldr	w2, [x8]
    6d58:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6d5c:	a940851c 	ldp	x28, x1, [x8, #8]
    6d60:	a941910a 	ldp	x10, x4, [x8, #24]
    6d64:	a9429905 	ldp	x5, x6, [x8, #40]
    6d68:	a9438d07 	ldp	x7, x3, [x8, #56]
    6d6c:	f940251b 	ldr	x27, [x8, #72]
    6d70:	6b00005f 	cmp	w2, w0
    6d74:	54000108 	b.hi	6d94 <f12+0x4c4>  // b.pmore
    6d78:	910102e2 	add	x2, x23, #0x40
    6d7c:	92403e60 	and	x0, x19, #0xffff
    6d80:	d1000400 	sub	x0, x0, #0x1
    6d84:	f9405c49 	ldr	x9, [x2, #184]
    6d88:	eb09001f 	cmp	x0, x9
    6d8c:	5400004a 	b.ge	6d94 <f12+0x4c4>  // b.tcont
    6d90:	f9005c40 	str	x0, [x2, #184]
    6d94:	4f000400 	movi	v0.4s, #0x0
    6d98:	910102e9 	add	x9, x23, #0x40
    6d9c:	f9000d1f 	str	xzr, [x8, #24]
    6da0:	910123e0 	add	x0, sp, #0x48
    6da4:	910183fa 	add	x26, sp, #0x60
    6da8:	d0ffffe2 	adrp	x2, 4000 <caf61+0x3c>
    6dac:	f941712b 	ldr	x11, [x9, #736]
    6db0:	3c808100 	stur	q0, [x8, #8]
    6db4:	91034042 	add	x2, x2, #0xd0
    6db8:	ad010100 	stp	q0, q0, [x8, #32]
    6dbc:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    6dc0:	a9048beb 	stp	x11, x2, [sp, #72]
    6dc4:	a90593fa 	stp	x26, x4, [sp, #88]
    6dc8:	a9069be5 	stp	x5, x6, [sp, #104]
    6dcc:	a9078fe7 	stp	x7, x3, [sp, #120]
    6dd0:	a908efea 	stp	x10, x27, [sp, #136]
    6dd4:	f9017120 	str	x0, [x9, #736]
    6dd8:	b7f856b5 	tbnz	x21, #63, 78ac <f12+0xfdc>
    6ddc:	eb95827f 	cmp	x19, x21, asr #32
    6de0:	540060a1 	b.ne	79f4 <f12+0x1124>  // b.any
    6de4:	92407eb3 	and	x19, x21, #0xffffffff
    6de8:	eb35403f 	cmp	x1, w21, uxtw
    6dec:	54005fed 	b.le	79e8 <f12+0x1118>
    6df0:	eb13039f 	cmp	x28, x19
    6df4:	9a93c793 	csinc	x19, x28, x19, gt
    6df8:	eb13037f 	cmp	x27, x19
    6dfc:	5400502a 	b.ge	7800 <f12+0xf30>  // b.tcont
    6e00:	f100037f 	cmp	x27, #0x0
    6e04:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    6e08:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    6e0c:	14000004 	b	6e1c <f12+0x54c>
    6e10:	eb01037f 	cmp	x27, x1
    6e14:	d37ffb7b 	lsl	x27, x27, #1
    6e18:	9a93d37b 	csel	x27, x27, x19, le
    6e1c:	eb13037f 	cmp	x27, x19
    6e20:	54ffff8b 	b.lt	6e10 <f12+0x540>  // b.tstop
    6e24:	a90017e4 	stp	x4, x5, [sp]
    6e28:	a9011fe6 	stp	x6, x7, [sp, #16]
    6e2c:	b4005763 	cbz	x3, 7918 <f12+0x1048>
    6e30:	aa0303e0 	mov	x0, x3
    6e34:	d37df361 	lsl	x1, x27, #3
    6e38:	97ffee6a 	bl	27e0 <realloc@plt>
    6e3c:	aa0003e3 	mov	x3, x0
    6e40:	a94017e4 	ldp	x4, x5, [sp]
    6e44:	a9411fe6 	ldp	x6, x7, [sp, #16]
    6e48:	b4004dc3 	cbz	x3, 7800 <f12+0xf30>
    6e4c:	f90043e3 	str	x3, [sp, #128]
    6e50:	f9004bfb 	str	x27, [sp, #144]
    6e54:	b5001593 	cbnz	x19, 7104 <f12+0x834>
    6e58:	b7f800b5 	tbnz	x21, #63, 6e6c <f12+0x59c>
    6e5c:	92407eb5 	and	x21, x21, #0xffffffff
    6e60:	fc757860 	ldr	d0, [x3, x21, lsl #3]
    6e64:	1e682800 	fadd	d0, d0, d8
    6e68:	fc357860 	str	d0, [x3, x21, lsl #3]
    6e6c:	d1000673 	sub	x19, x19, #0x1
    6e70:	d1000788 	sub	x8, x28, #0x1
    6e74:	eb13039f 	cmp	x28, x19
    6e78:	540003ac 	b.gt	6eec <f12+0x61c>
    6e7c:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    6e80:	1e602008 	fcmp	d0, #0.0
    6e84:	540002e0 	b.eq	6ee0 <f12+0x610>  // b.none
    6e88:	cb1c0be0 	neg	x0, x28, lsl #2
    6e8c:	cb1c03e2 	neg	x2, x28
    6e90:	8b000081 	add	x1, x4, x0
    6e94:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    6e98:	37f80101 	tbnz	w1, #31, 6eb8 <f12+0x5e8>
    6e9c:	8b020cc9 	add	x9, x6, x2, lsl #3
    6ea0:	93407c21 	sxtw	x1, w1
    6ea4:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    6ea8:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    6eac:	1e620802 	fmul	d2, d0, d2
    6eb0:	1e622821 	fadd	d1, d1, d2
    6eb4:	fc217861 	str	d1, [x3, x1, lsl #3]
    6eb8:	8b0000a0 	add	x0, x5, x0
    6ebc:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    6ec0:	37f80100 	tbnz	w0, #31, 6ee0 <f12+0x610>
    6ec4:	8b020ce2 	add	x2, x7, x2, lsl #3
    6ec8:	93407c00 	sxtw	x0, w0
    6ecc:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    6ed0:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    6ed4:	1e620800 	fmul	d0, d0, d2
    6ed8:	1e602820 	fadd	d0, d1, d0
    6edc:	fc207860 	str	d0, [x3, x0, lsl #3]
    6ee0:	d1000673 	sub	x19, x19, #0x1
    6ee4:	eb08027f 	cmp	x19, x8
    6ee8:	54fffca1 	b.ne	6e7c <f12+0x5ac>  // b.any
    6eec:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    6ef0:	eb00039f 	cmp	x28, x0
    6ef4:	540058e8 	b.hi	7a10 <f12+0x1140>  // b.pmore
    6ef8:	91000780 	add	x0, x28, #0x1
    6efc:	52800041 	mov	w1, #0x2                   	// #2
    6f00:	f90003e3 	str	x3, [sp]
    6f04:	d37df000 	lsl	x0, x0, #3
    6f08:	97fff74e 	bl	4c40 <fwp_heap_alloc>
    6f0c:	aa0003e2 	mov	x2, x0
    6f10:	aa0003f3 	mov	x19, x0
    6f14:	f94003e3 	ldr	x3, [sp]
    6f18:	d2800001 	mov	x1, #0x0                   	// #0
    6f1c:	f800845c 	str	x28, [x2], #8
    6f20:	b40000fc 	cbz	x28, 6f3c <f12+0x66c>
    6f24:	d503201f 	nop
    6f28:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    6f2c:	f8217840 	str	x0, [x2, x1, lsl #3]
    6f30:	91000421 	add	x1, x1, #0x1
    6f34:	eb01039f 	cmp	x28, x1
    6f38:	54ffff81 	b.ne	6f28 <f12+0x658>  // b.any
    6f3c:	910102e1 	add	x1, x23, #0x40
    6f40:	aa1a03e0 	mov	x0, x26
    6f44:	f94027fa 	ldr	x26, [sp, #72]
    6f48:	f901703a 	str	x26, [x1, #736]
    6f4c:	97fff461 	bl	40d0 <fwp_tape_buffers_release>
    6f50:	9115c282 	add	x2, x20, #0x570
    6f54:	f949d841 	ldr	x1, [x2, #5040]
    6f58:	f949ec40 	ldr	x0, [x2, #5080]
    6f5c:	cb010261 	sub	x1, x19, x1
    6f60:	eb00403f 	cmp	x1, x0, lsl #16
    6f64:	54000322 	b.cs	6fc8 <f12+0x6f8>  // b.hs, b.nlast
    6f68:	d350fc20 	lsr	x0, x1, #16
    6f6c:	f949fc43 	ldr	x3, [x2, #5112]
    6f70:	8b000800 	add	x0, x0, x0, lsl #2
    6f74:	d37df002 	lsl	x2, x0, #3
    6f78:	8b020060 	add	x0, x3, x2
    6f7c:	f9401015 	ldr	x21, [x0, #32]
    6f80:	b4000255 	cbz	x21, 6fc8 <f12+0x6f8>
    6f84:	38626862 	ldrb	w2, [x3, x2]
    6f88:	7100085f 	cmp	w2, #0x2
    6f8c:	540048a0 	b.eq	78a0 <f12+0xfd0>  // b.none
    6f90:	7100045f 	cmp	w2, #0x1
    6f94:	540001a1 	b.ne	6fc8 <f12+0x6f8>  // b.any
    6f98:	29430002 	ldp	w2, w0, [x0, #24]
    6f9c:	92403c21 	and	x1, x1, #0xffff
    6fa0:	9b027c21 	mul	x1, x1, x2
    6fa4:	d360fc21 	lsr	x1, x1, #32
    6fa8:	eb00003f 	cmp	x1, x0
    6fac:	540000e2 	b.cs	6fc8 <f12+0x6f8>  // b.hs, b.nlast
    6fb0:	8b0102b5 	add	x21, x21, x1
    6fb4:	394002a0 	ldrb	w0, [x21]
    6fb8:	7103fc1f 	cmp	w0, #0xff
    6fbc:	54004de0 	b.eq	7978 <f12+0x10a8>  // b.none
    6fc0:	52800020 	mov	w0, #0x1                   	// #1
    6fc4:	390002a0 	strb	w0, [x21]
    6fc8:	eb19035f 	cmp	x26, x25
    6fcc:	54005481 	b.ne	7a5c <f12+0x118c>  // b.any
    6fd0:	f9401be1 	ldr	x1, [sp, #48]
    6fd4:	910102f7 	add	x23, x23, #0x40
    6fd8:	aa1803e0 	mov	x0, x24
    6fdc:	f90172e1 	str	x1, [x23, #736]
    6fe0:	97fffb5c 	bl	5d50 <fwp_tape_scope_release>
    6fe4:	f9400260 	ldr	x0, [x19]
    6fe8:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    6fec:	b7f83960 	tbnz	x0, #63, 7718 <f12+0xe48>
    6ff0:	9115c282 	add	x2, x20, #0x570
    6ff4:	f949d840 	ldr	x0, [x2, #5040]
    6ff8:	f949ec41 	ldr	x1, [x2, #5080]
    6ffc:	cb000260 	sub	x0, x19, x0
    7000:	eb01401f 	cmp	x0, x1, lsl #16
    7004:	540038a2 	b.cs	7718 <f12+0xe48>  // b.hs, b.nlast
    7008:	d350fc01 	lsr	x1, x0, #16
    700c:	f949fc44 	ldr	x4, [x2, #5112]
    7010:	8b010821 	add	x1, x1, x1, lsl #2
    7014:	d37df021 	lsl	x1, x1, #3
    7018:	8b010083 	add	x3, x4, x1
    701c:	f9401062 	ldr	x2, [x3, #32]
    7020:	b40037c2 	cbz	x2, 7718 <f12+0xe48>
    7024:	38616881 	ldrb	w1, [x4, x1]
    7028:	7100083f 	cmp	w1, #0x2
    702c:	54003700 	b.eq	770c <f12+0xe3c>  // b.none
    7030:	7100043f 	cmp	w1, #0x1
    7034:	54003721 	b.ne	7718 <f12+0xe48>  // b.any
    7038:	29430464 	ldp	w4, w1, [x3, #24]
    703c:	92403c00 	and	x0, x0, #0xffff
    7040:	9b047c00 	mul	x0, x0, x4
    7044:	d360fc00 	lsr	x0, x0, #32
    7048:	eb01001f 	cmp	x0, x1
    704c:	54003662 	b.cs	7718 <f12+0xe48>  // b.hs, b.nlast
    7050:	8b000042 	add	x2, x2, x0
    7054:	39400040 	ldrb	w0, [x2]
    7058:	7100041f 	cmp	w0, #0x1
    705c:	540035e1 	b.ne	7718 <f12+0xe48>  // b.any
    7060:	aa1303f9 	mov	x25, x19
    7064:	d2800000 	mov	x0, #0x0                   	// #0
    7068:	f9000bf3 	str	x19, [sp, #16]
    706c:	f9400be1 	ldr	x1, [sp, #16]
    7070:	91002023 	add	x3, x1, #0x8
    7074:	d2800001 	mov	x1, #0x0                   	// #0
    7078:	b40005b7 	cbz	x23, 712c <f12+0x85c>
    707c:	90000022 	adrp	x2, b000 <__modti3+0xc0>
    7080:	91002265 	add	x5, x19, #0x8
    7084:	fd47dc41 	ldr	d1, [x2, #4024]
    7088:	14000009 	b	70ac <f12+0x7dc>
    708c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7090:	f9400322 	ldr	x2, [x25]
    7094:	1e600820 	fmul	d0, d1, d0
    7098:	b7f84b62 	tbnz	x2, #63, 7a04 <f12+0x1134>
    709c:	91000421 	add	x1, x1, #0x1
    70a0:	fc008460 	str	d0, [x3], #8
    70a4:	eb0102ff 	cmp	x23, x1
    70a8:	54000420 	b.eq	712c <f12+0x85c>  // b.none
    70ac:	f9400264 	ldr	x4, [x19]
    70b0:	aa0503e2 	mov	x2, x5
    70b4:	b6fffec4 	tbz	x4, #63, 708c <f12+0x7bc>
    70b8:	f9400a62 	ldr	x2, [x19, #16]
    70bc:	17fffff4 	b	708c <f12+0x7bc>
    70c0:	eb1b02bf 	cmp	x21, x27
    70c4:	54ffcc40 	b.eq	6a4c <f12+0x17c>  // b.none
    70c8:	f94022fc 	ldr	x28, [x23, #64]
    70cc:	8b1506a1 	add	x1, x21, x21, lsl #1
    70d0:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    70d4:	91146000 	add	x0, x0, #0x518
    70d8:	8b010abb 	add	x27, x21, x1, lsl #2
    70dc:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    70e0:	f900337f 	str	xzr, [x27, #96]
    70e4:	97ffee27 	bl	2980 <getenv@plt>
    70e8:	b4ffd0c0 	cbz	x0, 6b00 <f12+0x230>
    70ec:	39400001 	ldrb	w1, [x0]
    70f0:	7100c03f 	cmp	w1, #0x30
    70f4:	54ffd061 	b.ne	6b00 <f12+0x230>  // b.any
    70f8:	39400400 	ldrb	w0, [x0, #1]
    70fc:	34ffd080 	cbz	w0, 6b0c <f12+0x23c>
    7100:	17fffe80 	b	6b00 <f12+0x230>
    7104:	aa0303e0 	mov	x0, x3
    7108:	d37df262 	lsl	x2, x19, #3
    710c:	52800001 	mov	w1, #0x0                   	// #0
    7110:	a90017e4 	stp	x4, x5, [sp]
    7114:	a9011fe6 	stp	x6, x7, [sp, #16]
    7118:	97ffedaa 	bl	27c0 <memset@plt>
    711c:	aa0003e3 	mov	x3, x0
    7120:	a94017e4 	ldp	x4, x5, [sp]
    7124:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7128:	17ffff4c 	b	6e58 <f12+0x588>
    712c:	97fffd49 	bl	6650 <fwp_drop4>
    7130:	aa1603e1 	mov	x1, x22
    7134:	d2800002 	mov	x2, #0x0                   	// #0
    7138:	b4003ff6 	cbz	x22, 7934 <f12+0x1064>
    713c:	d503201f 	nop
    7140:	f9400821 	ldr	x1, [x1, #16]
    7144:	91000442 	add	x2, x2, #0x1
    7148:	b5ffffc1 	cbnz	x1, 7140 <f12+0x870>
    714c:	f9400323 	ldr	x3, [x25]
    7150:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    7154:	b7f82a63 	tbnz	x3, #63, 76a0 <f12+0xdd0>
    7158:	9115c281 	add	x1, x20, #0x570
    715c:	f9400be4 	ldr	x4, [sp, #16]
    7160:	f949d820 	ldr	x0, [x1, #5040]
    7164:	f949ec21 	ldr	x1, [x1, #5080]
    7168:	cb000080 	sub	x0, x4, x0
    716c:	eb01401f 	cmp	x0, x1, lsl #16
    7170:	54002982 	b.cs	76a0 <f12+0xdd0>  // b.hs, b.nlast
    7174:	9115c284 	add	x4, x20, #0x570
    7178:	d350fc01 	lsr	x1, x0, #16
    717c:	8b010821 	add	x1, x1, x1, lsl #2
    7180:	f949fc86 	ldr	x6, [x4, #5112]
    7184:	d37df021 	lsl	x1, x1, #3
    7188:	8b0100c5 	add	x5, x6, x1
    718c:	f94010a4 	ldr	x4, [x5, #32]
    7190:	b4002864 	cbz	x4, 769c <f12+0xdcc>
    7194:	386168c1 	ldrb	w1, [x6, x1]
    7198:	7100083f 	cmp	w1, #0x2
    719c:	540027c0 	b.eq	7694 <f12+0xdc4>  // b.none
    71a0:	7100043f 	cmp	w1, #0x1
    71a4:	540027c1 	b.ne	769c <f12+0xdcc>  // b.any
    71a8:	294304a6 	ldp	w6, w1, [x5, #24]
    71ac:	92403c00 	and	x0, x0, #0xffff
    71b0:	9b067c00 	mul	x0, x0, x6
    71b4:	d360fc00 	lsr	x0, x0, #32
    71b8:	eb01001f 	cmp	x0, x1
    71bc:	54002702 	b.cs	769c <f12+0xdcc>  // b.hs, b.nlast
    71c0:	8b000084 	add	x4, x4, x0
    71c4:	39400097 	ldrb	w23, [x4]
    71c8:	710006ff 	cmp	w23, #0x1
    71cc:	54002681 	b.ne	769c <f12+0xdcc>  // b.any
    71d0:	b9001bf7 	str	w23, [sp, #24]
    71d4:	eb13005f 	cmp	x2, x19
    71d8:	9a939053 	csel	x19, x2, x19, ls	// ls = plast
    71dc:	9100233a 	add	x26, x25, #0x8
    71e0:	b4003e13 	cbz	x19, 79a0 <f12+0x10d0>
    71e4:	f9400be0 	ldr	x0, [sp, #16]
    71e8:	d37df265 	lsl	x5, x19, #3
    71ec:	aa1603e2 	mov	x2, x22
    71f0:	d2800001 	mov	x1, #0x0                   	// #0
    71f4:	91002000 	add	x0, x0, #0x8
    71f8:	1400000a 	b	7220 <f12+0x950>
    71fc:	fc616881 	ldr	d1, [x4, x1]
    7200:	fd400440 	ldr	d0, [x2, #8]
    7204:	1e613800 	fsub	d0, d0, d1
    7208:	fc216b40 	str	d0, [x26, x1]
    720c:	91002021 	add	x1, x1, #0x8
    7210:	f9400842 	ldr	x2, [x2, #16]
    7214:	eb05003f 	cmp	x1, x5
    7218:	540001c0 	b.eq	7250 <f12+0x980>  // b.none
    721c:	f9400323 	ldr	x3, [x25]
    7220:	aa0003e4 	mov	x4, x0
    7224:	b6fffec3 	tbz	x3, #63, 71fc <f12+0x92c>
    7228:	f9400be3 	ldr	x3, [sp, #16]
    722c:	fd400440 	ldr	d0, [x2, #8]
    7230:	f9400864 	ldr	x4, [x3, #16]
    7234:	fc616881 	ldr	d1, [x4, x1]
    7238:	1e613800 	fsub	d0, d0, d1
    723c:	fc216b40 	str	d0, [x26, x1]
    7240:	91002021 	add	x1, x1, #0x8
    7244:	f9400842 	ldr	x2, [x2, #16]
    7248:	eb05003f 	cmp	x1, x5
    724c:	54fffe81 	b.ne	721c <f12+0x94c>  // b.any
    7250:	b4003a56 	cbz	x22, 7998 <f12+0x10c8>
    7254:	9115c280 	add	x0, x20, #0x570
    7258:	aa1603e2 	mov	x2, x22
    725c:	d280001b 	mov	x27, #0x0                   	// #0
    7260:	f949ec06 	ldr	x6, [x0, #5080]
    7264:	f949d807 	ldr	x7, [x0, #5040]
    7268:	f949fc05 	ldr	x5, [x0, #5112]
    726c:	d370bcc6 	lsl	x6, x6, #16
    7270:	14000006 	b	7288 <f12+0x9b8>
    7274:	f9400842 	ldr	x2, [x2, #16]
    7278:	9100077b 	add	x27, x27, #0x1
    727c:	f100005f 	cmp	x2, #0x0
    7280:	fa531362 	ccmp	x27, x19, #0x2, ne	// ne = any
    7284:	54000322 	b.cs	72e8 <f12+0xa18>  // b.hs, b.nlast
    7288:	cb070040 	sub	x0, x2, x7
    728c:	eb06001f 	cmp	x0, x6
    7290:	540002c2 	b.cs	72e8 <f12+0xa18>  // b.hs, b.nlast
    7294:	d350fc01 	lsr	x1, x0, #16
    7298:	8b010821 	add	x1, x1, x1, lsl #2
    729c:	d37df021 	lsl	x1, x1, #3
    72a0:	8b0100a4 	add	x4, x5, x1
    72a4:	f9401083 	ldr	x3, [x4, #32]
    72a8:	b4000203 	cbz	x3, 72e8 <f12+0xa18>
    72ac:	386168a1 	ldrb	w1, [x5, x1]
    72b0:	7100083f 	cmp	w1, #0x2
    72b4:	54000e00 	b.eq	7474 <f12+0xba4>  // b.none
    72b8:	7100043f 	cmp	w1, #0x1
    72bc:	54000161 	b.ne	72e8 <f12+0xa18>  // b.any
    72c0:	29430488 	ldp	w8, w1, [x4, #24]
    72c4:	92403c00 	and	x0, x0, #0xffff
    72c8:	9b087c00 	mul	x0, x0, x8
    72cc:	d360fc00 	lsr	x0, x0, #32
    72d0:	eb01001f 	cmp	x0, x1
    72d4:	540000a2 	b.cs	72e8 <f12+0xa18>  // b.hs, b.nlast
    72d8:	8b000063 	add	x3, x3, x0
    72dc:	39400060 	ldrb	w0, [x3]
    72e0:	7100041f 	cmp	w0, #0x1
    72e4:	54fffc80 	b.eq	7274 <f12+0x9a4>  // b.none
    72e8:	d2800019 	mov	x25, #0x0                   	// #0
    72ec:	eb13037f 	cmp	x27, x19
    72f0:	54000cc2 	b.cs	7488 <f12+0xbb8>  // b.hs, b.nlast
    72f4:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    72f8:	d1002357 	sub	x23, x26, #0x8
    72fc:	9115c298 	add	x24, x20, #0x570
    7300:	d2800019 	mov	x25, #0x0                   	// #0
    7304:	fd47c808 	ldr	d8, [x0, #3984]
    7308:	14000042 	b	7410 <f12+0xb40>
    730c:	f9400381 	ldr	x1, [x28]
    7310:	aa2103e1 	mvn	x1, x1
    7314:	f8207b01 	str	x1, [x24, x0, lsl #3]
    7318:	f100609f 	cmp	x4, #0x18
    731c:	54000169 	b.ls	7348 <f12+0xa78>  // b.plast
    7320:	d1006482 	sub	x2, x4, #0x19
    7324:	91006380 	add	x0, x28, #0x18
    7328:	927df042 	and	x2, x2, #0xfffffffffffffff8
    732c:	52800001 	mov	w1, #0x0                   	// #0
    7330:	91002042 	add	x2, x2, #0x8
    7334:	f90003e4 	str	x4, [sp]
    7338:	b9000be5 	str	w5, [sp, #8]
    733c:	97ffed21 	bl	27c0 <memset@plt>
    7340:	f94003e4 	ldr	x4, [sp]
    7344:	b9400be5 	ldr	w5, [sp, #8]
    7348:	9115c282 	add	x2, x20, #0x570
    734c:	f94a1041 	ldr	x1, [x2, #5152]
    7350:	ab040021 	adds	x1, x1, x4
    7354:	54003562 	b.cs	7a00 <f12+0x1130>  // b.hs, b.nlast
    7358:	f94a1440 	ldr	x0, [x2, #5160]
    735c:	f90a1041 	str	x1, [x2, #5152]
    7360:	eb00003f 	cmp	x1, x0
    7364:	54000049 	b.ls	736c <f12+0xa9c>  // b.plast
    7368:	f90a1441 	str	x1, [x2, #5160]
    736c:	9115c280 	add	x0, x20, #0x570
    7370:	1e6300a1 	ucvtf	d1, w5
    7374:	fd4a1c00 	ldr	d0, [x0, #5176]
    7378:	1e612800 	fadd	d0, d0, d1
    737c:	fd0a1c00 	str	d0, [x0, #5176]
    7380:	a900e795 	stp	x21, x25, [x28, #8]
    7384:	aa1c03f9 	mov	x25, x28
    7388:	fd000388 	str	d8, [x28]
    738c:	f949db01 	ldr	x1, [x24, #5040]
    7390:	f949ef00 	ldr	x0, [x24, #5080]
    7394:	cb010381 	sub	x1, x28, x1
    7398:	eb00403f 	cmp	x1, x0, lsl #16
    739c:	54000322 	b.cs	7400 <f12+0xb30>  // b.hs, b.nlast
    73a0:	d350fc20 	lsr	x0, x1, #16
    73a4:	f949ff04 	ldr	x4, [x24, #5112]
    73a8:	8b000800 	add	x0, x0, x0, lsl #2
    73ac:	d37df002 	lsl	x2, x0, #3
    73b0:	8b020080 	add	x0, x4, x2
    73b4:	f940101c 	ldr	x28, [x0, #32]
    73b8:	b400025c 	cbz	x28, 7400 <f12+0xb30>
    73bc:	38626882 	ldrb	w2, [x4, x2]
    73c0:	7100085f 	cmp	w2, #0x2
    73c4:	54000b00 	b.eq	7524 <f12+0xc54>  // b.none
    73c8:	7100045f 	cmp	w2, #0x1
    73cc:	540001a1 	b.ne	7400 <f12+0xb30>  // b.any
    73d0:	29430002 	ldp	w2, w0, [x0, #24]
    73d4:	92403c21 	and	x1, x1, #0xffff
    73d8:	9b027c21 	mul	x1, x1, x2
    73dc:	d360fc21 	lsr	x1, x1, #32
    73e0:	eb00003f 	cmp	x1, x0
    73e4:	540000e2 	b.cs	7400 <f12+0xb30>  // b.hs, b.nlast
    73e8:	8b01039c 	add	x28, x28, x1
    73ec:	39400380 	ldrb	w0, [x28]
    73f0:	7103fc1f 	cmp	w0, #0xff
    73f4:	54002000 	b.eq	77f4 <f12+0xf24>  // b.none
    73f8:	52800020 	mov	w0, #0x1                   	// #1
    73fc:	39000380 	strb	w0, [x28]
    7400:	d1000660 	sub	x0, x19, #0x1
    7404:	eb1b001f 	cmp	x0, x27
    7408:	54000989 	b.ls	7538 <f12+0xc68>  // b.plast
    740c:	aa0003f3 	mov	x19, x0
    7410:	b953a700 	ldr	w0, [x24, #5028]
    7414:	f8737af5 	ldr	x21, [x23, x19, lsl #3]
    7418:	34000240 	cbz	w0, 7460 <f12+0xb90>
    741c:	397e8b00 	ldrb	w0, [x24, #4002]
    7420:	910f0001 	add	x1, x0, #0x3c0
    7424:	8b000400 	add	x0, x0, x0, lsl #1
    7428:	b8617b05 	ldr	w5, [x24, x1, lsl #2]
    742c:	8b000f01 	add	x1, x24, x0, lsl #3
    7430:	f8607b1c 	ldr	x28, [x24, x0, lsl #3]
    7434:	2a0503e4 	mov	w4, w5
    7438:	b5fff6bc 	cbnz	x28, 730c <f12+0xa3c>
    743c:	f940043c 	ldr	x28, [x1, #8]
    7440:	b400011c 	cbz	x28, 7460 <f12+0xb90>
    7444:	f9400820 	ldr	x0, [x1, #16]
    7448:	cb1c0000 	sub	x0, x0, x28
    744c:	eb00009f 	cmp	x4, x0
    7450:	54000088 	b.hi	7460 <f12+0xb90>  // b.pmore
    7454:	8b040380 	add	x0, x28, x4
    7458:	f9000420 	str	x0, [x1, #8]
    745c:	17ffffaf 	b	7318 <f12+0xa48>
    7460:	52800001 	mov	w1, #0x0                   	// #0
    7464:	d2800300 	mov	x0, #0x18                  	// #24
    7468:	97fff5f6 	bl	4c40 <fwp_heap_alloc>
    746c:	aa0003fc 	mov	x28, x0
    7470:	17ffffc4 	b	7380 <f12+0xab0>
    7474:	72003c1f 	tst	w0, #0xffff
    7478:	54fff320 	b.eq	72dc <f12+0xa0c>  // b.none
    747c:	d2800019 	mov	x25, #0x0                   	// #0
    7480:	eb13037f 	cmp	x27, x19
    7484:	54fff383 	b.cc	72f4 <f12+0xa24>  // b.lo, b.ul, b.last
    7488:	8b1b0f5b 	add	x27, x26, x27, lsl #3
    748c:	aa1a03e1 	mov	x1, x26
    7490:	aa1603e0 	mov	x0, x22
    7494:	d503201f 	nop
    7498:	f8408422 	ldr	x2, [x1], #8
    749c:	f9000402 	str	x2, [x0, #8]
    74a0:	aa0003e2 	mov	x2, x0
    74a4:	f9400800 	ldr	x0, [x0, #16]
    74a8:	eb1b003f 	cmp	x1, x27
    74ac:	54ffff61 	b.ne	7498 <f12+0xbc8>  // b.any
    74b0:	b9401be1 	ldr	w1, [sp, #24]
    74b4:	f9000859 	str	x25, [x2, #16]
    74b8:	aa1603f9 	mov	x25, x22
    74bc:	aa0003f6 	mov	x22, x0
    74c0:	34000041 	cbz	w1, 74c8 <f12+0xbf8>
    74c4:	d280001a 	mov	x26, #0x0                   	// #0
    74c8:	aa1a03e0 	mov	x0, x26
    74cc:	97fff4bd 	bl	47c0 <fwp_mem_free>
    74d0:	f9400be0 	ldr	x0, [sp, #16]
    74d4:	97fffc5f 	bl	6650 <fwp_drop4>
    74d8:	aa1603e0 	mov	x0, x22
    74dc:	97fff88e 	bl	5714 <fwp_drop0>
    74e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    74e4:	f947f400 	ldr	x0, [x0, #4072]
    74e8:	f9404fe2 	ldr	x2, [sp, #152]
    74ec:	f9400001 	ldr	x1, [x0]
    74f0:	eb010042 	subs	x2, x2, x1
    74f4:	d2800001 	mov	x1, #0x0                   	// #0
    74f8:	54002921 	b.ne	7a1c <f12+0x114c>  // b.any
    74fc:	a94a7bfd 	ldp	x29, x30, [sp, #160]
    7500:	aa1903e0 	mov	x0, x25
    7504:	a94b53f3 	ldp	x19, x20, [sp, #176]
    7508:	a94c5bf5 	ldp	x21, x22, [sp, #192]
    750c:	a94d63f7 	ldp	x23, x24, [sp, #208]
    7510:	a94e6bf9 	ldp	x25, x26, [sp, #224]
    7514:	a94f73fb 	ldp	x27, x28, [sp, #240]
    7518:	fd4083e8 	ldr	d8, [sp, #256]
    751c:	910443ff 	add	sp, sp, #0x110
    7520:	d65f03c0 	ret
    7524:	72003c3f 	tst	w1, #0xffff
    7528:	54fff620 	b.eq	73ec <f12+0xb1c>  // b.none
    752c:	d1000660 	sub	x0, x19, #0x1
    7530:	eb1b001f 	cmp	x0, x27
    7534:	54fff6c8 	b.hi	740c <f12+0xb3c>  // b.pmore
    7538:	b5fffa9b 	cbnz	x27, 7488 <f12+0xbb8>
    753c:	b9401be1 	ldr	w1, [sp, #24]
    7540:	7100003f 	cmp	w1, #0x0
    7544:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    7548:	b4fffc00 	cbz	x0, 74c8 <f12+0xbf8>
    754c:	9115c294 	add	x20, x20, #0x570
    7550:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7554:	d1000a73 	sub	x19, x19, #0x2
    7558:	52800035 	mov	w21, #0x1                   	// #1
    755c:	fd47c808 	ldr	d8, [x0, #3984]
    7560:	b953a680 	ldr	w0, [x20, #5028]
    7564:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    7568:	340008c0 	cbz	w0, 7680 <f12+0xdb0>
    756c:	d503201f 	nop
    7570:	397e8a80 	ldrb	w0, [x20, #4002]
    7574:	910f0001 	add	x1, x0, #0x3c0
    7578:	8b000400 	add	x0, x0, x0, lsl #1
    757c:	b8617a9c 	ldr	w28, [x20, x1, lsl #2]
    7580:	8b000e81 	add	x1, x20, x0, lsl #3
    7584:	f8607a97 	ldr	x23, [x20, x0, lsl #3]
    7588:	2a1c03fb 	mov	w27, w28
    758c:	b4002177 	cbz	x23, 79b8 <f12+0x10e8>
    7590:	f94002e1 	ldr	x1, [x23]
    7594:	aa2103e1 	mvn	x1, x1
    7598:	f8207a81 	str	x1, [x20, x0, lsl #3]
    759c:	f100637f 	cmp	x27, #0x18
    75a0:	540000e9 	b.ls	75bc <f12+0xcec>  // b.plast
    75a4:	d1006762 	sub	x2, x27, #0x19
    75a8:	910062e0 	add	x0, x23, #0x18
    75ac:	927df042 	and	x2, x2, #0xfffffffffffffff8
    75b0:	52800001 	mov	w1, #0x0                   	// #0
    75b4:	91002042 	add	x2, x2, #0x8
    75b8:	97ffec82 	bl	27c0 <memset@plt>
    75bc:	f94a1280 	ldr	x0, [x20, #5152]
    75c0:	ab1b0000 	adds	x0, x0, x27
    75c4:	540021e2 	b.cs	7a00 <f12+0x1130>  // b.hs, b.nlast
    75c8:	f94a1681 	ldr	x1, [x20, #5160]
    75cc:	f90a1280 	str	x0, [x20, #5152]
    75d0:	eb01001f 	cmp	x0, x1
    75d4:	54000049 	b.ls	75dc <f12+0xd0c>  // b.plast
    75d8:	f90a1680 	str	x0, [x20, #5160]
    75dc:	1e630381 	ucvtf	d1, w28
    75e0:	fd4a1e80 	ldr	d0, [x20, #5176]
    75e4:	1e612800 	fadd	d0, d0, d1
    75e8:	fd0a1e80 	str	d0, [x20, #5176]
    75ec:	a900e6f8 	stp	x24, x25, [x23, #8]
    75f0:	aa1703f9 	mov	x25, x23
    75f4:	fd0002e8 	str	d8, [x23]
    75f8:	f949da81 	ldr	x1, [x20, #5040]
    75fc:	f949ee80 	ldr	x0, [x20, #5080]
    7600:	cb0102e1 	sub	x1, x23, x1
    7604:	eb00403f 	cmp	x1, x0, lsl #16
    7608:	54000302 	b.cs	7668 <f12+0xd98>  // b.hs, b.nlast
    760c:	d350fc22 	lsr	x2, x1, #16
    7610:	f949fe83 	ldr	x3, [x20, #5112]
    7614:	8b020842 	add	x2, x2, x2, lsl #2
    7618:	d37df042 	lsl	x2, x2, #3
    761c:	8b020060 	add	x0, x3, x2
    7620:	f9401017 	ldr	x23, [x0, #32]
    7624:	b4000237 	cbz	x23, 7668 <f12+0xd98>
    7628:	38626862 	ldrb	w2, [x3, x2]
    762c:	7100085f 	cmp	w2, #0x2
    7630:	54001d60 	b.eq	79dc <f12+0x110c>  // b.none
    7634:	7100045f 	cmp	w2, #0x1
    7638:	54000181 	b.ne	7668 <f12+0xd98>  // b.any
    763c:	29430002 	ldp	w2, w0, [x0, #24]
    7640:	92403c21 	and	x1, x1, #0xffff
    7644:	9b027c21 	mul	x1, x1, x2
    7648:	d360fc21 	lsr	x1, x1, #32
    764c:	eb00003f 	cmp	x1, x0
    7650:	540000c2 	b.cs	7668 <f12+0xd98>  // b.hs, b.nlast
    7654:	8b0102f7 	add	x23, x23, x1
    7658:	394002e0 	ldrb	w0, [x23]
    765c:	7103fc1f 	cmp	w0, #0xff
    7660:	54001a60 	b.eq	79ac <f12+0x10dc>  // b.none
    7664:	390002f5 	strb	w21, [x23]
    7668:	d1000673 	sub	x19, x19, #0x1
    766c:	b100067f 	cmn	x19, #0x1
    7670:	54fff2c0 	b.eq	74c8 <f12+0xbf8>  // b.none
    7674:	b953a680 	ldr	w0, [x20, #5028]
    7678:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    767c:	35fff7a0 	cbnz	w0, 7570 <f12+0xca0>
    7680:	52800001 	mov	w1, #0x0                   	// #0
    7684:	d2800300 	mov	x0, #0x18                  	// #24
    7688:	97fff56e 	bl	4c40 <fwp_heap_alloc>
    768c:	aa0003f7 	mov	x23, x0
    7690:	17ffffd7 	b	75ec <f12+0xd1c>
    7694:	72003c1f 	tst	w0, #0xffff
    7698:	54ffd960 	b.eq	71c4 <f12+0x8f4>  // b.none
    769c:	b40012b6 	cbz	x22, 78f0 <f12+0x1020>
    76a0:	aa1603f7 	mov	x23, x22
    76a4:	d2800018 	mov	x24, #0x0                   	// #0
    76a8:	f9400af7 	ldr	x23, [x23, #16]
    76ac:	aa1803e0 	mov	x0, x24
    76b0:	91000718 	add	x24, x24, #0x1
    76b4:	b5ffffb7 	cbnz	x23, 76a8 <f12+0xdd8>
    76b8:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    76bc:	eb01031f 	cmp	x24, x1
    76c0:	54001c88 	b.hi	7a50 <f12+0x1180>  // b.pmore
    76c4:	91000800 	add	x0, x0, #0x2
    76c8:	52800041 	mov	w1, #0x2                   	// #2
    76cc:	d37df000 	lsl	x0, x0, #3
    76d0:	97fff55c 	bl	4c40 <fwp_heap_alloc>
    76d4:	eb13031f 	cmp	x24, x19
    76d8:	aa0003fa 	mov	x26, x0
    76dc:	9a939313 	csel	x19, x24, x19, ls	// ls = plast
    76e0:	aa1603e1 	mov	x1, x22
    76e4:	d503201f 	nop
    76e8:	f9400420 	ldr	x0, [x1, #8]
    76ec:	f8377b40 	str	x0, [x26, x23, lsl #3]
    76f0:	910006f7 	add	x23, x23, #0x1
    76f4:	f9400821 	ldr	x1, [x1, #16]
    76f8:	b5ffff81 	cbnz	x1, 76e8 <f12+0xe18>
    76fc:	b4001033 	cbz	x19, 7900 <f12+0x1030>
    7700:	f9400323 	ldr	x3, [x25]
    7704:	b9001bff 	str	wzr, [sp, #24]
    7708:	17fffeb7 	b	71e4 <f12+0x914>
    770c:	72003c1f 	tst	w0, #0xffff
    7710:	54ffca20 	b.eq	7054 <f12+0x784>  // b.none
    7714:	d503201f 	nop
    7718:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    771c:	eb0002ff 	cmp	x23, x0
    7720:	54001788 	b.hi	7a10 <f12+0x1140>  // b.pmore
    7724:	910006e0 	add	x0, x23, #0x1
    7728:	52800021 	mov	w1, #0x1                   	// #1
    772c:	d37df000 	lsl	x0, x0, #3
    7730:	97fff544 	bl	4c40 <fwp_heap_alloc>
    7734:	9115c282 	add	x2, x20, #0x570
    7738:	f9000017 	str	x23, [x0]
    773c:	aa0003f9 	mov	x25, x0
    7740:	f9000bf9 	str	x25, [sp, #16]
    7744:	f949d841 	ldr	x1, [x2, #5040]
    7748:	f949ec40 	ldr	x0, [x2, #5080]
    774c:	cb010321 	sub	x1, x25, x1
    7750:	eb00403f 	cmp	x1, x0, lsl #16
    7754:	54000322 	b.cs	77b8 <f12+0xee8>  // b.hs, b.nlast
    7758:	d350fc20 	lsr	x0, x1, #16
    775c:	f949fc43 	ldr	x3, [x2, #5112]
    7760:	8b000800 	add	x0, x0, x0, lsl #2
    7764:	d37df002 	lsl	x2, x0, #3
    7768:	8b020060 	add	x0, x3, x2
    776c:	f9401018 	ldr	x24, [x0, #32]
    7770:	b4000258 	cbz	x24, 77b8 <f12+0xee8>
    7774:	38626862 	ldrb	w2, [x3, x2]
    7778:	7100085f 	cmp	w2, #0x2
    777c:	54000c60 	b.eq	7908 <f12+0x1038>  // b.none
    7780:	7100045f 	cmp	w2, #0x1
    7784:	540001a1 	b.ne	77b8 <f12+0xee8>  // b.any
    7788:	29430002 	ldp	w2, w0, [x0, #24]
    778c:	92403c21 	and	x1, x1, #0xffff
    7790:	9b027c21 	mul	x1, x1, x2
    7794:	d360fc21 	lsr	x1, x1, #32
    7798:	eb00003f 	cmp	x1, x0
    779c:	540000e2 	b.cs	77b8 <f12+0xee8>  // b.hs, b.nlast
    77a0:	8b010318 	add	x24, x24, x1
    77a4:	39400300 	ldrb	w0, [x24]
    77a8:	7103fc1f 	cmp	w0, #0xff
    77ac:	54000ec0 	b.eq	7984 <f12+0x10b4>  // b.none
    77b0:	52800020 	mov	w0, #0x1                   	// #1
    77b4:	39000300 	strb	w0, [x24]
    77b8:	aa1303e0 	mov	x0, x19
    77bc:	17fffe2c 	b	706c <f12+0x79c>
    77c0:	52800041 	mov	w1, #0x2                   	// #2
    77c4:	d2800100 	mov	x0, #0x8                   	// #8
    77c8:	97fff51e 	bl	4c40 <fwp_heap_alloc>
    77cc:	aa0003fb 	mov	x27, x0
    77d0:	9115c280 	add	x0, x20, #0x570
    77d4:	f900037f 	str	xzr, [x27]
    77d8:	f949d801 	ldr	x1, [x0, #5040]
    77dc:	f949ec00 	ldr	x0, [x0, #5080]
    77e0:	cb010361 	sub	x1, x27, x1
    77e4:	eb00403f 	cmp	x1, x0, lsl #16
    77e8:	54000362 	b.cs	7854 <f12+0xf84>  // b.hs, b.nlast
    77ec:	d2800013 	mov	x19, #0x0                   	// #0
    77f0:	17fffd09 	b	6c14 <f12+0x344>
    77f4:	aa1c03e0 	mov	x0, x28
    77f8:	97fff352 	bl	4540 <fwp_rc_forget_slot>
    77fc:	17fffeff 	b	73f8 <f12+0xb28>
    7800:	f100027f 	cmp	x19, #0x0
    7804:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    7808:	54ffb261 	b.ne	6e54 <f12+0x584>  // b.any
    780c:	f94027e1 	ldr	x1, [sp, #72]
    7810:	910102f7 	add	x23, x23, #0x40
    7814:	aa1a03e0 	mov	x0, x26
    7818:	f90172e1 	str	x1, [x23, #736]
    781c:	97fff22d 	bl	40d0 <fwp_tape_buffers_release>
    7820:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7824:	f947e863 	ldr	x3, [x3, #4048]
    7828:	d2800262 	mov	x2, #0x13                  	// #19
    782c:	d2800021 	mov	x1, #0x1                   	// #1
    7830:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7834:	910ba000 	add	x0, x0, #0x2e8
    7838:	f9400063 	ldr	x3, [x3]
    783c:	97ffec2d 	bl	28f0 <fwrite@plt>
    7840:	d2800000 	mov	x0, #0x0                   	// #0
    7844:	97ffec37 	bl	2920 <fflush@plt>
    7848:	52800cc0 	mov	w0, #0x66                  	// #102
    784c:	97ffec45 	bl	2960 <_Exit@plt>
    7850:	b5ffa173 	cbnz	x19, 6c7c <f12+0x3ac>
    7854:	d280001c 	mov	x28, #0x0                   	// #0
    7858:	17fffd2f 	b	6d14 <f12+0x444>
    785c:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x8c>
    7860:	91314000 	add	x0, x0, #0xc50
    7864:	94000e93 	bl	b2b0 <atexit>
    7868:	35fffdc0 	cbnz	w0, 7820 <f12+0xf50>
    786c:	52800020 	mov	w0, #0x1                   	// #1
    7870:	b90316a0 	str	w0, [x21, #788]
    7874:	17fffc63 	b	6a00 <f12+0x130>
    7878:	72003c3f 	tst	w1, #0xffff
    787c:	54ff9fe1 	b.ne	6c78 <f12+0x3a8>  // b.any
    7880:	17fffcf9 	b	6c64 <f12+0x394>
    7884:	72003c3f 	tst	w1, #0xffff
    7888:	54ff8920 	b.eq	69ac <f12+0xdc>  // b.none
    788c:	aa1503e0 	mov	x0, x21
    7890:	97fff850 	bl	59d0 <fwp_closure_drop>
    7894:	b5ff89f6 	cbnz	x22, 69d0 <f12+0x100>
    7898:	d280001a 	mov	x26, #0x0                   	// #0
    789c:	17fffc56 	b	69f4 <f12+0x124>
    78a0:	72003c3f 	tst	w1, #0xffff
    78a4:	54ffb921 	b.ne	6fc8 <f12+0x6f8>  // b.any
    78a8:	17fffdc3 	b	6fb4 <f12+0x6e4>
    78ac:	aa1c03f3 	mov	x19, x28
    78b0:	17fffd52 	b	6df8 <f12+0x528>
    78b4:	3cc68002 	ldur	q2, [x0, #104]
    78b8:	9101a001 	add	x1, x0, #0x68
    78bc:	3cc78001 	ldur	q1, [x0, #120]
    78c0:	f900501f 	str	xzr, [x0, #160]
    78c4:	4f000400 	movi	v0.4s, #0x0
    78c8:	ad010762 	stp	q2, q1, [x27, #32]
    78cc:	a9488002 	ldp	x2, x0, [x0, #136]
    78d0:	f9000f60 	str	x0, [x27, #24]
    78d4:	f9401820 	ldr	x0, [x1, #48]
    78d8:	f9002362 	str	x2, [x27, #64]
    78dc:	f9002760 	str	x0, [x27, #72]
    78e0:	ad000020 	stp	q0, q0, [x1]
    78e4:	3d800820 	str	q0, [x1, #32]
    78e8:	f900183f 	str	xzr, [x1, #48]
    78ec:	17fffc88 	b	6b0c <f12+0x23c>
    78f0:	52800041 	mov	w1, #0x2                   	// #2
    78f4:	d2800100 	mov	x0, #0x8                   	// #8
    78f8:	97fff4d2 	bl	4c40 <fwp_heap_alloc>
    78fc:	aa0003fa 	mov	x26, x0
    7900:	d2800019 	mov	x25, #0x0                   	// #0
    7904:	17fffef1 	b	74c8 <f12+0xbf8>
    7908:	72003c3f 	tst	w1, #0xffff
    790c:	54fff4c0 	b.eq	77a4 <f12+0xed4>  // b.none
    7910:	aa1303e0 	mov	x0, x19
    7914:	17fffdd6 	b	706c <f12+0x79c>
    7918:	aa1b03e0 	mov	x0, x27
    791c:	d2800101 	mov	x1, #0x8                   	// #8
    7920:	97ffebac 	bl	27d0 <calloc@plt>
    7924:	aa0003e3 	mov	x3, x0
    7928:	a94017e4 	ldp	x4, x5, [sp]
    792c:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7930:	17fffd46 	b	6e48 <f12+0x578>
    7934:	f9400323 	ldr	x3, [x25]
    7938:	b7fffdc3 	tbnz	x3, #63, 78f0 <f12+0x1020>
    793c:	9115c281 	add	x1, x20, #0x570
    7940:	f9400be4 	ldr	x4, [sp, #16]
    7944:	f949d820 	ldr	x0, [x1, #5040]
    7948:	f949ec21 	ldr	x1, [x1, #5080]
    794c:	cb000080 	sub	x0, x4, x0
    7950:	eb01401f 	cmp	x0, x1, lsl #16
    7954:	54fffce2 	b.cs	78f0 <f12+0x1020>  // b.hs, b.nlast
    7958:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    795c:	17fffe06 	b	7174 <f12+0x8a4>
    7960:	d2800d01 	mov	x1, #0x68                  	// #104
    7964:	d2800022 	mov	x2, #0x1                   	// #1
    7968:	17fffc49 	b	6a8c <f12+0x1bc>
    796c:	aa1503e0 	mov	x0, x21
    7970:	97fff2f4 	bl	4540 <fwp_rc_forget_slot>
    7974:	17fffcbf 	b	6c70 <f12+0x3a0>
    7978:	aa1503e0 	mov	x0, x21
    797c:	97fff2f1 	bl	4540 <fwp_rc_forget_slot>
    7980:	17fffd90 	b	6fc0 <f12+0x6f0>
    7984:	aa1803e0 	mov	x0, x24
    7988:	97fff2ee 	bl	4540 <fwp_rc_forget_slot>
    798c:	17ffff89 	b	77b0 <f12+0xee0>
    7990:	97fff2a5 	bl	4424 <fwp_rc_wide_dup>
    7994:	17fffc0c 	b	69c4 <f12+0xf4>
    7998:	d280001b 	mov	x27, #0x0                   	// #0
    799c:	17fffe56 	b	72f4 <f12+0xa24>
    79a0:	d280001a 	mov	x26, #0x0                   	// #0
    79a4:	d2800019 	mov	x25, #0x0                   	// #0
    79a8:	17fffec8 	b	74c8 <f12+0xbf8>
    79ac:	aa1703e0 	mov	x0, x23
    79b0:	97fff2e4 	bl	4540 <fwp_rc_forget_slot>
    79b4:	17ffff2c 	b	7664 <f12+0xd94>
    79b8:	f9400437 	ldr	x23, [x1, #8]
    79bc:	b4ffe637 	cbz	x23, 7680 <f12+0xdb0>
    79c0:	f9400820 	ldr	x0, [x1, #16]
    79c4:	cb170000 	sub	x0, x0, x23
    79c8:	eb00037f 	cmp	x27, x0
    79cc:	54ffe5a8 	b.hi	7680 <f12+0xdb0>  // b.pmore
    79d0:	8b1b02e0 	add	x0, x23, x27
    79d4:	f9000420 	str	x0, [x1, #8]
    79d8:	17fffef1 	b	759c <f12+0xccc>
    79dc:	72003c3f 	tst	w1, #0xffff
    79e0:	54ffe441 	b.ne	7668 <f12+0xd98>  // b.any
    79e4:	17ffff1d 	b	7658 <f12+0xd88>
    79e8:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    79ec:	9119a000 	add	x0, x0, #0x668
    79f0:	97ffeec4 	bl	3500 <fwp_trap>
    79f4:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    79f8:	91174000 	add	x0, x0, #0x5d0
    79fc:	97ffeec1 	bl	3500 <fwp_trap>
    7a00:	97ffed6c 	bl	2fb0 <fwp_heap_oom>
    7a04:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a08:	911da000 	add	x0, x0, #0x768
    7a0c:	97ffeebd 	bl	3500 <fwp_trap>
    7a10:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a14:	911d6000 	add	x0, x0, #0x758
    7a18:	97ffeeba 	bl	3500 <fwp_trap>
    7a1c:	97ffeb75 	bl	27f0 <__stack_chk_fail@plt>
    7a20:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a24:	911c6000 	add	x0, x0, #0x718
    7a28:	97ffeeb6 	bl	3500 <fwp_trap>
    7a2c:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a30:	911b2000 	add	x0, x0, #0x6c8
    7a34:	97ffeeb3 	bl	3500 <fwp_trap>
    7a38:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a3c:	911ba000 	add	x0, x0, #0x6e8
    7a40:	97ffeeb0 	bl	3500 <fwp_trap>
    7a44:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a48:	91186000 	add	x0, x0, #0x618
    7a4c:	97ffeead 	bl	3500 <fwp_trap>
    7a50:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7a54:	911d2000 	add	x0, x0, #0x748
    7a58:	97ffeeaa 	bl	3500 <fwp_trap>
    7a5c:	97ffeb79 	bl	2840 <abort@plt>
    7a60:	97ffebe8 	bl	2a00 <fwp_trap_overflow.constprop.0>

0000000000007a64 <fwp_owned_entry12>:
    7a64:	f9400000 	ldr	x0, [x0]
    7a68:	17fffb9a 	b	68d0 <f12>
    7a6c:	d503201f 	nop

0000000000007a70 <e12>:
    7a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7a74:	910003fd 	mov	x29, sp
    7a78:	f9000bf3 	str	x19, [sp, #16]
    7a7c:	f9400013 	ldr	x19, [x0]
    7a80:	aa1303e0 	mov	x0, x19
    7a84:	97fff6b7 	bl	5560 <fwp_rc_share>
    7a88:	aa1303e0 	mov	x0, x19
    7a8c:	97fffb91 	bl	68d0 <f12>
    7a90:	aa0003f3 	mov	x19, x0
    7a94:	97fff6b3 	bl	5560 <fwp_rc_share>
    7a98:	aa1303e0 	mov	x0, x19
    7a9c:	f9400bf3 	ldr	x19, [sp, #16]
    7aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7aa4:	d65f03c0 	ret
    7aa8:	d503201f 	nop
    7aac:	d503201f 	nop

0000000000007ab0 <fwp_args23>:
    7ab0:	7100003f 	cmp	w1, #0x0
    7ab4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7ab8:	54000041 	b.ne	7ac0 <fwp_args23+0x10>  // b.any
    7abc:	d65f03c0 	ret
    7ac0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    7ac4:	9115c042 	add	x2, x2, #0x570
    7ac8:	f9400001 	ldr	x1, [x0]
    7acc:	f949d843 	ldr	x3, [x2, #5040]
    7ad0:	f949ec40 	ldr	x0, [x2, #5080]
    7ad4:	cb030021 	sub	x1, x1, x3
    7ad8:	eb00403f 	cmp	x1, x0, lsl #16
    7adc:	54ffff02 	b.cs	7abc <fwp_args23+0xc>  // b.hs, b.nlast
    7ae0:	d350fc20 	lsr	x0, x1, #16
    7ae4:	f949fc44 	ldr	x4, [x2, #5112]
    7ae8:	8b000800 	add	x0, x0, x0, lsl #2
    7aec:	d37df002 	lsl	x2, x0, #3
    7af0:	8b020083 	add	x3, x4, x2
    7af4:	f9401060 	ldr	x0, [x3, #32]
    7af8:	b4fffe20 	cbz	x0, 7abc <fwp_args23+0xc>
    7afc:	38626882 	ldrb	w2, [x4, x2]
    7b00:	7100085f 	cmp	w2, #0x2
    7b04:	54000220 	b.eq	7b48 <fwp_args23+0x98>  // b.none
    7b08:	7100045f 	cmp	w2, #0x1
    7b0c:	54fffd81 	b.ne	7abc <fwp_args23+0xc>  // b.any
    7b10:	29430864 	ldp	w4, w2, [x3, #24]
    7b14:	92403c21 	and	x1, x1, #0xffff
    7b18:	9b047c21 	mul	x1, x1, x4
    7b1c:	d360fc21 	lsr	x1, x1, #32
    7b20:	eb02003f 	cmp	x1, x2
    7b24:	54fffcc2 	b.cs	7abc <fwp_args23+0xc>  // b.hs, b.nlast
    7b28:	8b010000 	add	x0, x0, x1
    7b2c:	39400001 	ldrb	w1, [x0]
    7b30:	34fffc61 	cbz	w1, 7abc <fwp_args23+0xc>
    7b34:	7103f43f 	cmp	w1, #0xfd
    7b38:	540000e8 	b.hi	7b54 <fwp_args23+0xa4>  // b.pmore
    7b3c:	11000421 	add	w1, w1, #0x1
    7b40:	39000001 	strb	w1, [x0]
    7b44:	d65f03c0 	ret
    7b48:	72003c3f 	tst	w1, #0xffff
    7b4c:	54ffff00 	b.eq	7b2c <fwp_args23+0x7c>  // b.none
    7b50:	d65f03c0 	ret
    7b54:	17fff234 	b	4424 <fwp_rc_wide_dup>
    7b58:	d503201f 	nop
    7b5c:	d503201f 	nop

0000000000007b60 <fwp_args12>:
    7b60:	7100003f 	cmp	w1, #0x0
    7b64:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7b68:	54000041 	b.ne	7b70 <fwp_args12+0x10>  // b.any
    7b6c:	d65f03c0 	ret
    7b70:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    7b74:	9115c042 	add	x2, x2, #0x570
    7b78:	f9400001 	ldr	x1, [x0]
    7b7c:	f949d843 	ldr	x3, [x2, #5040]
    7b80:	f949ec40 	ldr	x0, [x2, #5080]
    7b84:	cb030021 	sub	x1, x1, x3
    7b88:	eb00403f 	cmp	x1, x0, lsl #16
    7b8c:	54ffff02 	b.cs	7b6c <fwp_args12+0xc>  // b.hs, b.nlast
    7b90:	d350fc20 	lsr	x0, x1, #16
    7b94:	f949fc44 	ldr	x4, [x2, #5112]
    7b98:	8b000800 	add	x0, x0, x0, lsl #2
    7b9c:	d37df002 	lsl	x2, x0, #3
    7ba0:	8b020083 	add	x3, x4, x2
    7ba4:	f9401060 	ldr	x0, [x3, #32]
    7ba8:	b4fffe20 	cbz	x0, 7b6c <fwp_args12+0xc>
    7bac:	38626882 	ldrb	w2, [x4, x2]
    7bb0:	7100085f 	cmp	w2, #0x2
    7bb4:	54000220 	b.eq	7bf8 <fwp_args12+0x98>  // b.none
    7bb8:	7100045f 	cmp	w2, #0x1
    7bbc:	54fffd81 	b.ne	7b6c <fwp_args12+0xc>  // b.any
    7bc0:	29430864 	ldp	w4, w2, [x3, #24]
    7bc4:	92403c21 	and	x1, x1, #0xffff
    7bc8:	9b047c21 	mul	x1, x1, x4
    7bcc:	d360fc21 	lsr	x1, x1, #32
    7bd0:	eb02003f 	cmp	x1, x2
    7bd4:	54fffcc2 	b.cs	7b6c <fwp_args12+0xc>  // b.hs, b.nlast
    7bd8:	8b010000 	add	x0, x0, x1
    7bdc:	39400001 	ldrb	w1, [x0]
    7be0:	34fffc61 	cbz	w1, 7b6c <fwp_args12+0xc>
    7be4:	7103f43f 	cmp	w1, #0xfd
    7be8:	540000e8 	b.hi	7c04 <fwp_args12+0xa4>  // b.pmore
    7bec:	11000421 	add	w1, w1, #0x1
    7bf0:	39000001 	strb	w1, [x0]
    7bf4:	d65f03c0 	ret
    7bf8:	72003c3f 	tst	w1, #0xffff
    7bfc:	54ffff00 	b.eq	7bdc <fwp_args12+0x7c>  // b.none
    7c00:	d65f03c0 	ret
    7c04:	17fff208 	b	4424 <fwp_rc_wide_dup>
    7c08:	d503201f 	nop
    7c0c:	d503201f 	nop

0000000000007c10 <fwp_caps12>:
    7c10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7c14:	910003fd 	mov	x29, sp
    7c18:	f9000bf3 	str	x19, [sp, #16]
    7c1c:	aa0003f3 	mov	x19, x0
    7c20:	b9400400 	ldr	w0, [x0, #4]
    7c24:	340004a0 	cbz	w0, 7cb8 <fwp_caps12+0xa8>
    7c28:	f9400660 	ldr	x0, [x19, #8]
    7c2c:	350004e1 	cbnz	w1, 7cc8 <fwp_caps12+0xb8>
    7c30:	97fff6b9 	bl	5714 <fwp_drop0>
    7c34:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    7c38:	9115c042 	add	x2, x2, #0x570
    7c3c:	f949d840 	ldr	x0, [x2, #5040]
    7c40:	f949ec41 	ldr	x1, [x2, #5080]
    7c44:	cb000260 	sub	x0, x19, x0
    7c48:	eb01401f 	cmp	x0, x1, lsl #16
    7c4c:	54000382 	b.cs	7cbc <fwp_caps12+0xac>  // b.hs, b.nlast
    7c50:	d350fc01 	lsr	x1, x0, #16
    7c54:	f949fc44 	ldr	x4, [x2, #5112]
    7c58:	8b010821 	add	x1, x1, x1, lsl #2
    7c5c:	d37df021 	lsl	x1, x1, #3
    7c60:	8b010083 	add	x3, x4, x1
    7c64:	f9401062 	ldr	x2, [x3, #32]
    7c68:	b40002a2 	cbz	x2, 7cbc <fwp_caps12+0xac>
    7c6c:	38616881 	ldrb	w1, [x4, x1]
    7c70:	7100083f 	cmp	w1, #0x2
    7c74:	540006c0 	b.eq	7d4c <fwp_caps12+0x13c>  // b.none
    7c78:	7100043f 	cmp	w1, #0x1
    7c7c:	54000201 	b.ne	7cbc <fwp_caps12+0xac>  // b.any
    7c80:	29430464 	ldp	w4, w1, [x3, #24]
    7c84:	92403c00 	and	x0, x0, #0xffff
    7c88:	9b047c00 	mul	x0, x0, x4
    7c8c:	d360fc00 	lsr	x0, x0, #32
    7c90:	eb01001f 	cmp	x0, x1
    7c94:	54000142 	b.cs	7cbc <fwp_caps12+0xac>  // b.hs, b.nlast
    7c98:	8b000042 	add	x2, x2, x0
    7c9c:	39400040 	ldrb	w0, [x2]
    7ca0:	7100041f 	cmp	w0, #0x1
    7ca4:	540000c1 	b.ne	7cbc <fwp_caps12+0xac>  // b.any
    7ca8:	aa1303e0 	mov	x0, x19
    7cac:	f9400bf3 	ldr	x19, [sp, #16]
    7cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7cb4:	17fff2c3 	b	47c0 <fwp_mem_free>
    7cb8:	34fffbe1 	cbz	w1, 7c34 <fwp_caps12+0x24>
    7cbc:	f9400bf3 	ldr	x19, [sp, #16]
    7cc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7cc4:	d65f03c0 	ret
    7cc8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    7ccc:	9115c042 	add	x2, x2, #0x570
    7cd0:	f949d843 	ldr	x3, [x2, #5040]
    7cd4:	f949ec41 	ldr	x1, [x2, #5080]
    7cd8:	cb030000 	sub	x0, x0, x3
    7cdc:	eb01401f 	cmp	x0, x1, lsl #16
    7ce0:	54fffee2 	b.cs	7cbc <fwp_caps12+0xac>  // b.hs, b.nlast
    7ce4:	d350fc01 	lsr	x1, x0, #16
    7ce8:	f949fc44 	ldr	x4, [x2, #5112]
    7cec:	8b010821 	add	x1, x1, x1, lsl #2
    7cf0:	d37df021 	lsl	x1, x1, #3
    7cf4:	8b010083 	add	x3, x4, x1
    7cf8:	f9401062 	ldr	x2, [x3, #32]
    7cfc:	b4fffe02 	cbz	x2, 7cbc <fwp_caps12+0xac>
    7d00:	38616881 	ldrb	w1, [x4, x1]
    7d04:	7100083f 	cmp	w1, #0x2
    7d08:	54000280 	b.eq	7d58 <fwp_caps12+0x148>  // b.none
    7d0c:	7100043f 	cmp	w1, #0x1
    7d10:	54fffd61 	b.ne	7cbc <fwp_caps12+0xac>  // b.any
    7d14:	92403c01 	and	x1, x0, #0xffff
    7d18:	29430064 	ldp	w4, w0, [x3, #24]
    7d1c:	9b047c21 	mul	x1, x1, x4
    7d20:	d360fc21 	lsr	x1, x1, #32
    7d24:	eb00003f 	cmp	x1, x0
    7d28:	54fffca2 	b.cs	7cbc <fwp_caps12+0xac>  // b.hs, b.nlast
    7d2c:	8b010042 	add	x2, x2, x1
    7d30:	39400040 	ldrb	w0, [x2]
    7d34:	34fffc40 	cbz	w0, 7cbc <fwp_caps12+0xac>
    7d38:	7103f41f 	cmp	w0, #0xfd
    7d3c:	54000148 	b.hi	7d64 <fwp_caps12+0x154>  // b.pmore
    7d40:	11000400 	add	w0, w0, #0x1
    7d44:	39000040 	strb	w0, [x2]
    7d48:	17ffffdd 	b	7cbc <fwp_caps12+0xac>
    7d4c:	72003c1f 	tst	w0, #0xffff
    7d50:	54fffb61 	b.ne	7cbc <fwp_caps12+0xac>  // b.any
    7d54:	17ffffd2 	b	7c9c <fwp_caps12+0x8c>
    7d58:	72003c1f 	tst	w0, #0xffff
    7d5c:	54fffb01 	b.ne	7cbc <fwp_caps12+0xac>  // b.any
    7d60:	17fffff4 	b	7d30 <fwp_caps12+0x120>
    7d64:	f9400bf3 	ldr	x19, [sp, #16]
    7d68:	aa0203e0 	mov	x0, x2
    7d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d70:	17fff1ad 	b	4424 <fwp_rc_wide_dup>

0000000000007d74 <fwp_drop2>:
    7d74:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7d78:	910003fd 	mov	x29, sp
    7d7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7d80:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc70>
    7d84:	9115c2d5 	add	x21, x22, #0x570
    7d88:	a90153f3 	stp	x19, x20, [sp, #16]
    7d8c:	aa0003f3 	mov	x19, x0
    7d90:	f949daa1 	ldr	x1, [x21, #5040]
    7d94:	f949eea0 	ldr	x0, [x21, #5080]
    7d98:	cb010261 	sub	x1, x19, x1
    7d9c:	eb00403f 	cmp	x1, x0, lsl #16
    7da0:	54000382 	b.cs	7e10 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7da4:	d350fc22 	lsr	x2, x1, #16
    7da8:	f949fea3 	ldr	x3, [x21, #5112]
    7dac:	8b020842 	add	x2, x2, x2, lsl #2
    7db0:	d37df042 	lsl	x2, x2, #3
    7db4:	8b020060 	add	x0, x3, x2
    7db8:	f9401014 	ldr	x20, [x0, #32]
    7dbc:	b40002b4 	cbz	x20, 7e10 <fwp_drop2+0x9c>
    7dc0:	38626862 	ldrb	w2, [x3, x2]
    7dc4:	7100085f 	cmp	w2, #0x2
    7dc8:	540002c0 	b.eq	7e20 <fwp_drop2+0xac>  // b.none
    7dcc:	7100045f 	cmp	w2, #0x1
    7dd0:	54000201 	b.ne	7e10 <fwp_drop2+0x9c>  // b.any
    7dd4:	29430002 	ldp	w2, w0, [x0, #24]
    7dd8:	92403c21 	and	x1, x1, #0xffff
    7ddc:	9b027c21 	mul	x1, x1, x2
    7de0:	d360fc21 	lsr	x1, x1, #32
    7de4:	eb00003f 	cmp	x1, x0
    7de8:	54000142 	b.cs	7e10 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7dec:	8b010294 	add	x20, x20, x1
    7df0:	39400280 	ldrb	w0, [x20]
    7df4:	340000e0 	cbz	w0, 7e10 <fwp_drop2+0x9c>
    7df8:	7100041f 	cmp	w0, #0x1
    7dfc:	540001e0 	b.eq	7e38 <fwp_drop2+0xc4>  // b.none
    7e00:	7103fc1f 	cmp	w0, #0xff
    7e04:	540007e0 	b.eq	7f00 <fwp_drop2+0x18c>  // b.none
    7e08:	51000400 	sub	w0, w0, #0x1
    7e0c:	39000280 	strb	w0, [x20]
    7e10:	a94153f3 	ldp	x19, x20, [sp, #16]
    7e14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7e18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7e1c:	d65f03c0 	ret
    7e20:	72003c3f 	tst	w1, #0xffff
    7e24:	54fffe60 	b.eq	7df0 <fwp_drop2+0x7c>  // b.none
    7e28:	a94153f3 	ldp	x19, x20, [sp, #16]
    7e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7e30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7e34:	d65f03c0 	ret
    7e38:	9115c2c2 	add	x2, x22, #0x570
    7e3c:	f9400660 	ldr	x0, [x19, #8]
    7e40:	f949d841 	ldr	x1, [x2, #5040]
    7e44:	f949ec42 	ldr	x2, [x2, #5080]
    7e48:	cb010001 	sub	x1, x0, x1
    7e4c:	eb02403f 	cmp	x1, x2, lsl #16
    7e50:	54000382 	b.cs	7ec0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7e54:	d350fc22 	lsr	x2, x1, #16
    7e58:	8b020842 	add	x2, x2, x2, lsl #2
    7e5c:	d37df042 	lsl	x2, x2, #3
    7e60:	8b020064 	add	x4, x3, x2
    7e64:	f9401094 	ldr	x20, [x4, #32]
    7e68:	b40002d4 	cbz	x20, 7ec0 <fwp_drop2+0x14c>
    7e6c:	38626862 	ldrb	w2, [x3, x2]
    7e70:	7100085f 	cmp	w2, #0x2
    7e74:	54000400 	b.eq	7ef4 <fwp_drop2+0x180>  // b.none
    7e78:	7100045f 	cmp	w2, #0x1
    7e7c:	54000221 	b.ne	7ec0 <fwp_drop2+0x14c>  // b.any
    7e80:	29430883 	ldp	w3, w2, [x4, #24]
    7e84:	92403c21 	and	x1, x1, #0xffff
    7e88:	9b037c21 	mul	x1, x1, x3
    7e8c:	d360fc21 	lsr	x1, x1, #32
    7e90:	eb02003f 	cmp	x1, x2
    7e94:	54000162 	b.cs	7ec0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7e98:	8b010294 	add	x20, x20, x1
    7e9c:	39400281 	ldrb	w1, [x20]
    7ea0:	34000101 	cbz	w1, 7ec0 <fwp_drop2+0x14c>
    7ea4:	7100043f 	cmp	w1, #0x1
    7ea8:	54000220 	b.eq	7eec <fwp_drop2+0x178>  // b.none
    7eac:	7103fc3f 	cmp	w1, #0xff
    7eb0:	540005a0 	b.eq	7f64 <fwp_drop2+0x1f0>  // b.none
    7eb4:	51000421 	sub	w1, w1, #0x1
    7eb8:	39000281 	strb	w1, [x20]
    7ebc:	d503201f 	nop
    7ec0:	f9400a74 	ldr	x20, [x19, #16]
    7ec4:	aa1303e0 	mov	x0, x19
    7ec8:	97fff5cb 	bl	55f4 <fwp_rc_free_arr>
    7ecc:	9115c2c0 	add	x0, x22, #0x570
    7ed0:	f949d801 	ldr	x1, [x0, #5040]
    7ed4:	f949ec00 	ldr	x0, [x0, #5080]
    7ed8:	cb010281 	sub	x1, x20, x1
    7edc:	eb00403f 	cmp	x1, x0, lsl #16
    7ee0:	54fff982 	b.cs	7e10 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7ee4:	aa1403f3 	mov	x19, x20
    7ee8:	17ffffaf 	b	7da4 <fwp_drop2+0x30>
    7eec:	97fff5c2 	bl	55f4 <fwp_rc_free_arr>
    7ef0:	17fffff4 	b	7ec0 <fwp_drop2+0x14c>
    7ef4:	72003c3f 	tst	w1, #0xffff
    7ef8:	54fffe41 	b.ne	7ec0 <fwp_drop2+0x14c>  // b.any
    7efc:	17ffffe8 	b	7e9c <fwp_drop2+0x128>
    7f00:	ca544681 	eor	x1, x20, x20, lsr #17
    7f04:	9115c2c0 	add	x0, x22, #0x570
    7f08:	ca412421 	eor	x1, x1, x1, lsr #9
    7f0c:	8b210c01 	add	x1, x0, w1, uxtb #3
    7f10:	f94a2420 	ldr	x0, [x1, #5192]
    7f14:	b5000080 	cbnz	x0, 7f24 <fwp_drop2+0x1b0>
    7f18:	14000010 	b	7f58 <fwp_drop2+0x1e4>
    7f1c:	f9400800 	ldr	x0, [x0, #16]
    7f20:	b40001c0 	cbz	x0, 7f58 <fwp_drop2+0x1e4>
    7f24:	f9400001 	ldr	x1, [x0]
    7f28:	eb14003f 	cmp	x1, x20
    7f2c:	54ffff81 	b.ne	7f1c <fwp_drop2+0x1a8>  // b.any
    7f30:	f9400401 	ldr	x1, [x0, #8]
    7f34:	d1000421 	sub	x1, x1, #0x1
    7f38:	f9000401 	str	x1, [x0, #8]
    7f3c:	f103f83f 	cmp	x1, #0xfe
    7f40:	54fff681 	b.ne	7e10 <fwp_drop2+0x9c>  // b.any
    7f44:	aa1403e0 	mov	x0, x20
    7f48:	97fff17e 	bl	4540 <fwp_rc_forget_slot>
    7f4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7f50:	39000280 	strb	w0, [x20]
    7f54:	17ffffaf 	b	7e10 <fwp_drop2+0x9c>
    7f58:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    7f5c:	91162000 	add	x0, x0, #0x588
    7f60:	97ffed68 	bl	3500 <fwp_trap>
    7f64:	ca544680 	eor	x0, x20, x20, lsr #17
    7f68:	9115c2c1 	add	x1, x22, #0x570
    7f6c:	ca402400 	eor	x0, x0, x0, lsr #9
    7f70:	8b200c20 	add	x0, x1, w0, uxtb #3
    7f74:	f94a2400 	ldr	x0, [x0, #5192]
    7f78:	b5000080 	cbnz	x0, 7f88 <fwp_drop2+0x214>
    7f7c:	17fffff7 	b	7f58 <fwp_drop2+0x1e4>
    7f80:	f9400800 	ldr	x0, [x0, #16]
    7f84:	b4fffea0 	cbz	x0, 7f58 <fwp_drop2+0x1e4>
    7f88:	f9400001 	ldr	x1, [x0]
    7f8c:	eb14003f 	cmp	x1, x20
    7f90:	54ffff81 	b.ne	7f80 <fwp_drop2+0x20c>  // b.any
    7f94:	f9400401 	ldr	x1, [x0, #8]
    7f98:	d1000421 	sub	x1, x1, #0x1
    7f9c:	f9000401 	str	x1, [x0, #8]
    7fa0:	f103f83f 	cmp	x1, #0xfe
    7fa4:	54fff8e1 	b.ne	7ec0 <fwp_drop2+0x14c>  // b.any
    7fa8:	aa1403e0 	mov	x0, x20
    7fac:	97fff165 	bl	4540 <fwp_rc_forget_slot>
    7fb0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7fb4:	39000280 	strb	w0, [x20]
    7fb8:	17ffffc2 	b	7ec0 <fwp_drop2+0x14c>
    7fbc:	d503201f 	nop

0000000000007fc0 <fwp_arg_drop23>:
    7fc0:	7100003f 	cmp	w1, #0x0
    7fc4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7fc8:	54000041 	b.ne	7fd0 <fwp_arg_drop23+0x10>  // b.any
    7fcc:	d65f03c0 	ret
    7fd0:	f9400000 	ldr	x0, [x0]
    7fd4:	17ffff68 	b	7d74 <fwp_drop2>
    7fd8:	d503201f 	nop
    7fdc:	d503201f 	nop

0000000000007fe0 <fwp_caps23>:
    7fe0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7fe4:	910003fd 	mov	x29, sp
    7fe8:	f9000bf3 	str	x19, [sp, #16]
    7fec:	aa0003f3 	mov	x19, x0
    7ff0:	b9400400 	ldr	w0, [x0, #4]
    7ff4:	340004a0 	cbz	w0, 8088 <fwp_caps23+0xa8>
    7ff8:	f9400660 	ldr	x0, [x19, #8]
    7ffc:	350004e1 	cbnz	w1, 8098 <fwp_caps23+0xb8>
    8000:	97ffff5d 	bl	7d74 <fwp_drop2>
    8004:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    8008:	9115c042 	add	x2, x2, #0x570
    800c:	f949d840 	ldr	x0, [x2, #5040]
    8010:	f949ec41 	ldr	x1, [x2, #5080]
    8014:	cb000260 	sub	x0, x19, x0
    8018:	eb01401f 	cmp	x0, x1, lsl #16
    801c:	54000382 	b.cs	808c <fwp_caps23+0xac>  // b.hs, b.nlast
    8020:	d350fc01 	lsr	x1, x0, #16
    8024:	f949fc44 	ldr	x4, [x2, #5112]
    8028:	8b010821 	add	x1, x1, x1, lsl #2
    802c:	d37df021 	lsl	x1, x1, #3
    8030:	8b010083 	add	x3, x4, x1
    8034:	f9401062 	ldr	x2, [x3, #32]
    8038:	b40002a2 	cbz	x2, 808c <fwp_caps23+0xac>
    803c:	38616881 	ldrb	w1, [x4, x1]
    8040:	7100083f 	cmp	w1, #0x2
    8044:	540006c0 	b.eq	811c <fwp_caps23+0x13c>  // b.none
    8048:	7100043f 	cmp	w1, #0x1
    804c:	54000201 	b.ne	808c <fwp_caps23+0xac>  // b.any
    8050:	29430464 	ldp	w4, w1, [x3, #24]
    8054:	92403c00 	and	x0, x0, #0xffff
    8058:	9b047c00 	mul	x0, x0, x4
    805c:	d360fc00 	lsr	x0, x0, #32
    8060:	eb01001f 	cmp	x0, x1
    8064:	54000142 	b.cs	808c <fwp_caps23+0xac>  // b.hs, b.nlast
    8068:	8b000042 	add	x2, x2, x0
    806c:	39400040 	ldrb	w0, [x2]
    8070:	7100041f 	cmp	w0, #0x1
    8074:	540000c1 	b.ne	808c <fwp_caps23+0xac>  // b.any
    8078:	aa1303e0 	mov	x0, x19
    807c:	f9400bf3 	ldr	x19, [sp, #16]
    8080:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8084:	17fff1cf 	b	47c0 <fwp_mem_free>
    8088:	34fffbe1 	cbz	w1, 8004 <fwp_caps23+0x24>
    808c:	f9400bf3 	ldr	x19, [sp, #16]
    8090:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8094:	d65f03c0 	ret
    8098:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc70>
    809c:	9115c042 	add	x2, x2, #0x570
    80a0:	f949d843 	ldr	x3, [x2, #5040]
    80a4:	f949ec41 	ldr	x1, [x2, #5080]
    80a8:	cb030000 	sub	x0, x0, x3
    80ac:	eb01401f 	cmp	x0, x1, lsl #16
    80b0:	54fffee2 	b.cs	808c <fwp_caps23+0xac>  // b.hs, b.nlast
    80b4:	d350fc01 	lsr	x1, x0, #16
    80b8:	f949fc44 	ldr	x4, [x2, #5112]
    80bc:	8b010821 	add	x1, x1, x1, lsl #2
    80c0:	d37df021 	lsl	x1, x1, #3
    80c4:	8b010083 	add	x3, x4, x1
    80c8:	f9401062 	ldr	x2, [x3, #32]
    80cc:	b4fffe02 	cbz	x2, 808c <fwp_caps23+0xac>
    80d0:	38616881 	ldrb	w1, [x4, x1]
    80d4:	7100083f 	cmp	w1, #0x2
    80d8:	54000280 	b.eq	8128 <fwp_caps23+0x148>  // b.none
    80dc:	7100043f 	cmp	w1, #0x1
    80e0:	54fffd61 	b.ne	808c <fwp_caps23+0xac>  // b.any
    80e4:	92403c01 	and	x1, x0, #0xffff
    80e8:	29430064 	ldp	w4, w0, [x3, #24]
    80ec:	9b047c21 	mul	x1, x1, x4
    80f0:	d360fc21 	lsr	x1, x1, #32
    80f4:	eb00003f 	cmp	x1, x0
    80f8:	54fffca2 	b.cs	808c <fwp_caps23+0xac>  // b.hs, b.nlast
    80fc:	8b010042 	add	x2, x2, x1
    8100:	39400040 	ldrb	w0, [x2]
    8104:	34fffc40 	cbz	w0, 808c <fwp_caps23+0xac>
    8108:	7103f41f 	cmp	w0, #0xfd
    810c:	54000148 	b.hi	8134 <fwp_caps23+0x154>  // b.pmore
    8110:	11000400 	add	w0, w0, #0x1
    8114:	39000040 	strb	w0, [x2]
    8118:	17ffffdd 	b	808c <fwp_caps23+0xac>
    811c:	72003c1f 	tst	w0, #0xffff
    8120:	54fffb61 	b.ne	808c <fwp_caps23+0xac>  // b.any
    8124:	17ffffd2 	b	806c <fwp_caps23+0x8c>
    8128:	72003c1f 	tst	w0, #0xffff
    812c:	54fffb01 	b.ne	808c <fwp_caps23+0xac>  // b.any
    8130:	17fffff4 	b	8100 <fwp_caps23+0x120>
    8134:	f9400bf3 	ldr	x19, [sp, #16]
    8138:	aa0203e0 	mov	x0, x2
    813c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8140:	17fff0b9 	b	4424 <fwp_rc_wide_dup>

0000000000008144 <f23>:
    8144:	d101c3ff 	sub	sp, sp, #0x70
    8148:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    814c:	f947f421 	ldr	x1, [x1, #4072]
    8150:	a9027bfd 	stp	x29, x30, [sp, #32]
    8154:	910083fd 	add	x29, sp, #0x20
    8158:	a90563f7 	stp	x23, x24, [sp, #80]
    815c:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc70>
    8160:	9115c2e3 	add	x3, x23, #0x570
    8164:	a90353f3 	stp	x19, x20, [sp, #48]
    8168:	a9045bf5 	stp	x21, x22, [sp, #64]
    816c:	aa0003f6 	mov	x22, x0
    8170:	a9066bf9 	stp	x25, x26, [sp, #96]
    8174:	f949ec62 	ldr	x2, [x3, #5080]
    8178:	f9400024 	ldr	x4, [x1]
    817c:	f9000fe4 	str	x4, [sp, #24]
    8180:	d2800004 	mov	x4, #0x0                   	// #0
    8184:	f949d861 	ldr	x1, [x3, #5040]
    8188:	d370bc42 	lsl	x2, x2, #16
    818c:	b40015a0 	cbz	x0, 8440 <f23+0x2fc>
    8190:	f9400818 	ldr	x24, [x0, #16]
    8194:	cb010301 	sub	x1, x24, x1
    8198:	eb02003f 	cmp	x1, x2
    819c:	54000362 	b.cs	8208 <f23+0xc4>  // b.hs, b.nlast
    81a0:	f949fc60 	ldr	x0, [x3, #5112]
    81a4:	d350fc22 	lsr	x2, x1, #16
    81a8:	8b020842 	add	x2, x2, x2, lsl #2
    81ac:	8b020c02 	add	x2, x0, x2, lsl #3
    81b0:	f9401040 	ldr	x0, [x2, #32]
    81b4:	b40002a0 	cbz	x0, 8208 <f23+0xc4>
    81b8:	39400043 	ldrb	w3, [x2]
    81bc:	7100087f 	cmp	w3, #0x2
    81c0:	540013a0 	b.eq	8434 <f23+0x2f0>  // b.none
    81c4:	7100047f 	cmp	w3, #0x1
    81c8:	540001c1 	b.ne	8200 <f23+0xbc>  // b.any
    81cc:	29430843 	ldp	w3, w2, [x2, #24]
    81d0:	92403c21 	and	x1, x1, #0xffff
    81d4:	9b037c21 	mul	x1, x1, x3
    81d8:	d360fc21 	lsr	x1, x1, #32
    81dc:	eb02003f 	cmp	x1, x2
    81e0:	54000102 	b.cs	8200 <f23+0xbc>  // b.hs, b.nlast
    81e4:	8b010000 	add	x0, x0, x1
    81e8:	39400001 	ldrb	w1, [x0]
    81ec:	340000a1 	cbz	w1, 8200 <f23+0xbc>
    81f0:	7103f43f 	cmp	w1, #0xfd
    81f4:	54001688 	b.hi	84c4 <f23+0x380>  // b.pmore
    81f8:	11000421 	add	w1, w1, #0x1
    81fc:	39000001 	strb	w1, [x0]
    8200:	d2800000 	mov	x0, #0x0                   	// #0
    8204:	b40000d6 	cbz	x22, 821c <f23+0xd8>
    8208:	aa1603e1 	mov	x1, x22
    820c:	d2800000 	mov	x0, #0x0                   	// #0
    8210:	f9400821 	ldr	x1, [x1, #16]
    8214:	91000400 	add	x0, x0, #0x1
    8218:	b5ffffc1 	cbnz	x1, 8210 <f23+0xcc>
    821c:	b40011b8 	cbz	x24, 8450 <f23+0x30c>
    8220:	aa1803e1 	mov	x1, x24
    8224:	d2800002 	mov	x2, #0x0                   	// #0
    8228:	f9400821 	ldr	x1, [x1, #16]
    822c:	91000442 	add	x2, x2, #0x1
    8230:	b5ffffc1 	cbnz	x1, 8228 <f23+0xe4>
    8234:	eb00005f 	cmp	x2, x0
    8238:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    823c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    8240:	eb01033f 	cmp	x25, x1
    8244:	54001468 	b.hi	84d0 <f23+0x38c>  // b.pmore
    8248:	d37ffb33 	lsl	x19, x25, #1
    824c:	52800041 	mov	w1, #0x2                   	// #2
    8250:	91000660 	add	x0, x19, #0x1
    8254:	d37df000 	lsl	x0, x0, #3
    8258:	97fff27a 	bl	4c40 <fwp_heap_alloc>
    825c:	9115c2e1 	add	x1, x23, #0x570
    8260:	aa0003fa 	mov	x26, x0
    8264:	f9000013 	str	x19, [x0]
    8268:	aa0103e0 	mov	x0, x1
    826c:	f949d821 	ldr	x1, [x1, #5040]
    8270:	f949ec00 	ldr	x0, [x0, #5080]
    8274:	cb010341 	sub	x1, x26, x1
    8278:	eb00403f 	cmp	x1, x0, lsl #16
    827c:	54000342 	b.cs	82e4 <f23+0x1a0>  // b.hs, b.nlast
    8280:	9115c2e2 	add	x2, x23, #0x570
    8284:	d350fc20 	lsr	x0, x1, #16
    8288:	8b000800 	add	x0, x0, x0, lsl #2
    828c:	f949fc43 	ldr	x3, [x2, #5112]
    8290:	d37df002 	lsl	x2, x0, #3
    8294:	8b020060 	add	x0, x3, x2
    8298:	f9401013 	ldr	x19, [x0, #32]
    829c:	b4000253 	cbz	x19, 82e4 <f23+0x1a0>
    82a0:	38626862 	ldrb	w2, [x3, x2]
    82a4:	7100085f 	cmp	w2, #0x2
    82a8:	54000c00 	b.eq	8428 <f23+0x2e4>  // b.none
    82ac:	7100045f 	cmp	w2, #0x1
    82b0:	540001a1 	b.ne	82e4 <f23+0x1a0>  // b.any
    82b4:	29430002 	ldp	w2, w0, [x0, #24]
    82b8:	92403c21 	and	x1, x1, #0xffff
    82bc:	9b027c21 	mul	x1, x1, x2
    82c0:	d360fc21 	lsr	x1, x1, #32
    82c4:	eb00003f 	cmp	x1, x0
    82c8:	540000e2 	b.cs	82e4 <f23+0x1a0>  // b.hs, b.nlast
    82cc:	8b010273 	add	x19, x19, x1
    82d0:	39400260 	ldrb	w0, [x19]
    82d4:	7103fc1f 	cmp	w0, #0xff
    82d8:	54000da0 	b.eq	848c <f23+0x348>  // b.none
    82dc:	52800020 	mov	w0, #0x1                   	// #1
    82e0:	39000260 	strb	w0, [x19]
    82e4:	b4000259 	cbz	x25, 832c <f23+0x1e8>
    82e8:	8b191359 	add	x25, x26, x25, lsl #4
    82ec:	aa1a03f3 	mov	x19, x26
    82f0:	aa1603f5 	mov	x21, x22
    82f4:	aa1803f4 	mov	x20, x24
    82f8:	f9400683 	ldr	x3, [x20, #8]
    82fc:	f94006a2 	ldr	x2, [x21, #8]
    8300:	f9400861 	ldr	x1, [x3, #16]
    8304:	f9400840 	ldr	x0, [x2, #16]
    8308:	fd400461 	ldr	d1, [x3, #8]
    830c:	fd400440 	ldr	d0, [x2, #8]
    8310:	97fff3cc 	bl	5240 <w107>
    8314:	f9000660 	str	x0, [x19, #8]
    8318:	f8010e61 	str	x1, [x19, #16]!
    831c:	f9400a94 	ldr	x20, [x20, #16]
    8320:	f9400ab5 	ldr	x21, [x21, #16]
    8324:	eb13033f 	cmp	x25, x19
    8328:	54fffe81 	b.ne	82f8 <f23+0x1b4>  // b.any
    832c:	aa1803e0 	mov	x0, x24
    8330:	97fffe91 	bl	7d74 <fwp_drop2>
    8334:	aa1603e0 	mov	x0, x22
    8338:	97fffe8f 	bl	7d74 <fwp_drop2>
    833c:	9115c2f7 	add	x23, x23, #0x570
    8340:	aa1a03e0 	mov	x0, x26
    8344:	97fff413 	bl	5390 <w164.constprop.0>
    8348:	aa0103f3 	mov	x19, x1
    834c:	aa0003f4 	mov	x20, x0
    8350:	aa1a03e0 	mov	x0, x26
    8354:	97fff8bf 	bl	6650 <fwp_drop4>
    8358:	a900cff4 	stp	x20, x19, [sp, #8]
    835c:	910023e1 	add	x1, sp, #0x8
    8360:	52800000 	mov	w0, #0x0                   	// #0
    8364:	97fff437 	bl	5440 <fwp_data.part.0.constprop.0>
    8368:	f949dae1 	ldr	x1, [x23, #5040]
    836c:	aa0003f3 	mov	x19, x0
    8370:	f949eee0 	ldr	x0, [x23, #5080]
    8374:	cb010261 	sub	x1, x19, x1
    8378:	eb00403f 	cmp	x1, x0, lsl #16
    837c:	54000322 	b.cs	83e0 <f23+0x29c>  // b.hs, b.nlast
    8380:	d350fc22 	lsr	x2, x1, #16
    8384:	f949fee3 	ldr	x3, [x23, #5112]
    8388:	8b020842 	add	x2, x2, x2, lsl #2
    838c:	d37df042 	lsl	x2, x2, #3
    8390:	8b020060 	add	x0, x3, x2
    8394:	f9401014 	ldr	x20, [x0, #32]
    8398:	b4000254 	cbz	x20, 83e0 <f23+0x29c>
    839c:	38626862 	ldrb	w2, [x3, x2]
    83a0:	7100085f 	cmp	w2, #0x2
    83a4:	540003c0 	b.eq	841c <f23+0x2d8>  // b.none
    83a8:	7100045f 	cmp	w2, #0x1
    83ac:	540001a1 	b.ne	83e0 <f23+0x29c>  // b.any
    83b0:	29430002 	ldp	w2, w0, [x0, #24]
    83b4:	92403c21 	and	x1, x1, #0xffff
    83b8:	9b027c21 	mul	x1, x1, x2
    83bc:	d360fc21 	lsr	x1, x1, #32
    83c0:	eb00003f 	cmp	x1, x0
    83c4:	540000e2 	b.cs	83e0 <f23+0x29c>  // b.hs, b.nlast
    83c8:	8b010294 	add	x20, x20, x1
    83cc:	39400280 	ldrb	w0, [x20]
    83d0:	7103fc1f 	cmp	w0, #0xff
    83d4:	54000620 	b.eq	8498 <f23+0x354>  // b.none
    83d8:	52800020 	mov	w0, #0x1                   	// #1
    83dc:	39000280 	strb	w0, [x20]
    83e0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    83e4:	f947f400 	ldr	x0, [x0, #4072]
    83e8:	f9400fe2 	ldr	x2, [sp, #24]
    83ec:	f9400001 	ldr	x1, [x0]
    83f0:	eb010042 	subs	x2, x2, x1
    83f4:	d2800001 	mov	x1, #0x0                   	// #0
    83f8:	540006a1 	b.ne	84cc <f23+0x388>  // b.any
    83fc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8400:	aa1303e0 	mov	x0, x19
    8404:	a94353f3 	ldp	x19, x20, [sp, #48]
    8408:	a9445bf5 	ldp	x21, x22, [sp, #64]
    840c:	a94563f7 	ldp	x23, x24, [sp, #80]
    8410:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8414:	9101c3ff 	add	sp, sp, #0x70
    8418:	d65f03c0 	ret
    841c:	72003c3f 	tst	w1, #0xffff
    8420:	54fffe01 	b.ne	83e0 <f23+0x29c>  // b.any
    8424:	17ffffea 	b	83cc <f23+0x288>
    8428:	72003c3f 	tst	w1, #0xffff
    842c:	54fff5c1 	b.ne	82e4 <f23+0x1a0>  // b.any
    8430:	17ffffa8 	b	82d0 <f23+0x18c>
    8434:	72003c3f 	tst	w1, #0xffff
    8438:	54ffee41 	b.ne	8200 <f23+0xbc>  // b.any
    843c:	17ffff6b 	b	81e8 <f23+0xa4>
    8440:	cb0103e1 	neg	x1, x1
    8444:	eb02003f 	cmp	x1, x2
    8448:	540002e3 	b.cc	84a4 <f23+0x360>  // b.lo, b.ul, b.last
    844c:	d503201f 	nop
    8450:	52800041 	mov	w1, #0x2                   	// #2
    8454:	d2800100 	mov	x0, #0x8                   	// #8
    8458:	97fff1fa 	bl	4c40 <fwp_heap_alloc>
    845c:	aa0003e1 	mov	x1, x0
    8460:	9115c2e0 	add	x0, x23, #0x570
    8464:	aa0103fa 	mov	x26, x1
    8468:	d2800018 	mov	x24, #0x0                   	// #0
    846c:	f900003f 	str	xzr, [x1]
    8470:	f949d801 	ldr	x1, [x0, #5040]
    8474:	f949ec00 	ldr	x0, [x0, #5080]
    8478:	cb010341 	sub	x1, x26, x1
    847c:	eb00403f 	cmp	x1, x0, lsl #16
    8480:	54fff562 	b.cs	832c <f23+0x1e8>  // b.hs, b.nlast
    8484:	d2800019 	mov	x25, #0x0                   	// #0
    8488:	17ffff7e 	b	8280 <f23+0x13c>
    848c:	aa1303e0 	mov	x0, x19
    8490:	97fff02c 	bl	4540 <fwp_rc_forget_slot>
    8494:	17ffff92 	b	82dc <f23+0x198>
    8498:	aa1403e0 	mov	x0, x20
    849c:	97fff029 	bl	4540 <fwp_rc_forget_slot>
    84a0:	17ffffce 	b	83d8 <f23+0x294>
    84a4:	f949fc62 	ldr	x2, [x3, #5112]
    84a8:	d350fc20 	lsr	x0, x1, #16
    84ac:	8b000800 	add	x0, x0, x0, lsl #2
    84b0:	8b000c42 	add	x2, x2, x0, lsl #3
    84b4:	f9401040 	ldr	x0, [x2, #32]
    84b8:	b4fffcc0 	cbz	x0, 8450 <f23+0x30c>
    84bc:	d2800018 	mov	x24, #0x0                   	// #0
    84c0:	17ffff3e 	b	81b8 <f23+0x74>
    84c4:	97ffefd8 	bl	4424 <fwp_rc_wide_dup>
    84c8:	17ffff4e 	b	8200 <f23+0xbc>
    84cc:	97ffe8c9 	bl	27f0 <__stack_chk_fail@plt>
    84d0:	f0000000 	adrp	x0, b000 <__modti3+0xc0>
    84d4:	911d2000 	add	x0, x0, #0x748
    84d8:	97ffec0a 	bl	3500 <fwp_trap>
    84dc:	d503201f 	nop

00000000000084e0 <fwp_owned_entry23>:
    84e0:	f9400000 	ldr	x0, [x0]
    84e4:	17ffff18 	b	8144 <f23>
    84e8:	d503201f 	nop
    84ec:	d503201f 	nop

00000000000084f0 <e23>:
    84f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    84f4:	910003fd 	mov	x29, sp
    84f8:	f9000bf3 	str	x19, [sp, #16]
    84fc:	f9400013 	ldr	x19, [x0]
    8500:	aa1303e0 	mov	x0, x19
    8504:	97fff417 	bl	5560 <fwp_rc_share>
    8508:	aa1303e0 	mov	x0, x19
    850c:	97ffff0e 	bl	8144 <f23>
    8510:	aa0003f3 	mov	x19, x0
    8514:	97fff413 	bl	5560 <fwp_rc_share>
    8518:	aa1303e0 	mov	x0, x19
    851c:	f9400bf3 	ldr	x19, [sp, #16]
    8520:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8524:	d65f03c0 	ret
    8528:	d503201f 	nop
    852c:	d503201f 	nop

0000000000008530 <fwp_write>:
    8530:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8534:	910003fd 	mov	x29, sp
    8538:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    853c:	f947f484 	ldr	x4, [x4, #4072]
    8540:	a90153f3 	stp	x19, x20, [sp, #16]
    8544:	d10943ff 	sub	sp, sp, #0x250
    8548:	b9400045 	ldr	w5, [x2]
    854c:	aa0003f4 	mov	x20, x0
    8550:	f9400080 	ldr	x0, [x4]
    8554:	f90127e0 	str	x0, [sp, #584]
    8558:	d2800000 	mov	x0, #0x0                   	// #0
    855c:	710064bf 	cmp	w5, #0x19
    8560:	54000408 	b.hi	85e0 <fwp_write+0xb0>  // b.pmore
    8564:	f0000000 	adrp	x0, b000 <__modti3+0xc0>
    8568:	aa0103f3 	mov	x19, x1
    856c:	913c4000 	add	x0, x0, #0xf10
    8570:	f9013bf5 	str	x21, [sp, #624]
    8574:	f9013ff6 	str	x22, [sp, #632]
    8578:	f90153fb 	str	x27, [sp, #672]
    857c:	f90157fc 	str	x28, [sp, #680]
    8580:	aa0203fc 	mov	x28, x2
    8584:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8588:	10000061 	adr	x1, 8594 <fwp_write+0x64>
    858c:	8b20a820 	add	x0, x1, w0, sxth #2
    8590:	d61f0000 	br	x0
    8594:	910123e0 	add	x0, sp, #0x48
    8598:	aa1303e5 	mov	x5, x19
    859c:	f0000004 	adrp	x4, b000 <__modti3+0xc0>
    85a0:	aa0003f3 	mov	x19, x0
    85a4:	911f2084 	add	x4, x4, #0x7c8
    85a8:	d2804003 	mov	x3, #0x200                 	// #512
    85ac:	aa0303e1 	mov	x1, x3
    85b0:	52800042 	mov	w2, #0x2                   	// #2
    85b4:	97ffe86b 	bl	2760 <__snprintf_chk@plt>
    85b8:	aa1303e0 	mov	x0, x19
    85bc:	97ffe831 	bl	2680 <strlen@plt>
    85c0:	aa1303e1 	mov	x1, x19
    85c4:	aa0003e2 	mov	x2, x0
    85c8:	aa1403e0 	mov	x0, x20
    85cc:	97ffeb71 	bl	3390 <buf_put>
    85d0:	f9413bf5 	ldr	x21, [sp, #624]
    85d4:	f9413ff6 	ldr	x22, [sp, #632]
    85d8:	f94153fb 	ldr	x27, [sp, #672]
    85dc:	f94157fc 	ldr	x28, [sp, #680]
    85e0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    85e4:	f947f400 	ldr	x0, [x0, #4072]
    85e8:	f94127e2 	ldr	x2, [sp, #584]
    85ec:	f9400001 	ldr	x1, [x0]
    85f0:	eb010042 	subs	x2, x2, x1
    85f4:	d2800001 	mov	x1, #0x0                   	// #0
    85f8:	540077c1 	b.ne	94f0 <fwp_write+0xfc0>  // b.any
    85fc:	910943ff 	add	sp, sp, #0x250
    8600:	a94153f3 	ldp	x19, x20, [sp, #16]
    8604:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8608:	d65f03c0 	ret
    860c:	910123e0 	add	x0, sp, #0x48
    8610:	aa1303e5 	mov	x5, x19
    8614:	f0000004 	adrp	x4, b000 <__modti3+0xc0>
    8618:	aa0003f3 	mov	x19, x0
    861c:	911f0084 	add	x4, x4, #0x7c0
    8620:	d2804003 	mov	x3, #0x200                 	// #512
    8624:	17ffffe2 	b	85ac <fwp_write+0x7c>
    8628:	71004cbf 	cmp	w5, #0x13
    862c:	f0000000 	adrp	x0, b000 <__modti3+0xc0>
    8630:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8634:	911ec000 	add	x0, x0, #0x7b0
    8638:	911ee021 	add	x1, x1, #0x7b8
    863c:	d2800082 	mov	x2, #0x4                   	// #4
    8640:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8644:	aa1403e0 	mov	x0, x20
    8648:	f90143f7 	str	x23, [sp, #640]
    864c:	d2800016 	mov	x22, #0x0                   	// #0
    8650:	f90147f8 	str	x24, [sp, #648]
    8654:	97ffeb4f 	bl	3390 <buf_put>
    8658:	f9400260 	ldr	x0, [x19]
    865c:	f0000017 	adrp	x23, b000 <__modti3+0xc0>
    8660:	d2800015 	mov	x21, #0x0                   	// #0
    8664:	9120e2f7 	add	x23, x23, #0x838
    8668:	b40047a0 	cbz	x0, 8f5c <fwp_write+0xa2c>
    866c:	b9400380 	ldr	w0, [x28]
    8670:	52800003 	mov	w3, #0x0                   	// #0
    8674:	f9401f82 	ldr	x2, [x28, #56]
    8678:	71004c1f 	cmp	w0, #0x13
    867c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8680:	aa1403e0 	mov	x0, x20
    8684:	8b010e61 	add	x1, x19, x1, lsl #3
    8688:	f9400421 	ldr	x1, [x1, #8]
    868c:	97ffffa9 	bl	8530 <fwp_write>
    8690:	b9400380 	ldr	w0, [x28]
    8694:	7100481f 	cmp	w0, #0x12
    8698:	54004b40 	b.eq	9000 <fwp_write+0xad0>  // b.none
    869c:	f9400260 	ldr	x0, [x19]
    86a0:	910006b5 	add	x21, x21, #0x1
    86a4:	91000ad6 	add	x22, x22, #0x2
    86a8:	eb15001f 	cmp	x0, x21
    86ac:	54004589 	b.ls	8f5c <fwp_write+0xa2c>  // b.plast
    86b0:	aa1703e1 	mov	x1, x23
    86b4:	aa1403e0 	mov	x0, x20
    86b8:	d2800042 	mov	x2, #0x2                   	// #2
    86bc:	97ffeb35 	bl	3390 <buf_put>
    86c0:	17ffffeb 	b	866c <fwp_write+0x13c>
    86c4:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    86c8:	911fc021 	add	x1, x1, #0x7f0
    86cc:	d28000c2 	mov	x2, #0x6                   	// #6
    86d0:	aa1403e0 	mov	x0, x20
    86d4:	91004273 	add	x19, x19, #0x10
    86d8:	97ffeb2e 	bl	3390 <buf_put>
    86dc:	aa1303e0 	mov	x0, x19
    86e0:	97ffe7e8 	bl	2680 <strlen@plt>
    86e4:	aa1303e1 	mov	x1, x19
    86e8:	aa0003e2 	mov	x2, x0
    86ec:	aa1403e0 	mov	x0, x20
    86f0:	97ffeb28 	bl	3390 <buf_put>
    86f4:	528007c3 	mov	w3, #0x3e                  	// #62
    86f8:	aa1403e0 	mov	x0, x20
    86fc:	91001fe1 	add	x1, sp, #0x7
    8700:	d2800022 	mov	x2, #0x1                   	// #1
    8704:	39001fe3 	strb	w3, [sp, #7]
    8708:	17ffffb1 	b	85cc <fwp_write+0x9c>
    870c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8710:	f947f400 	ldr	x0, [x0, #4072]
    8714:	f94127e2 	ldr	x2, [sp, #584]
    8718:	f9400001 	ldr	x1, [x0]
    871c:	eb010042 	subs	x2, x2, x1
    8720:	d2800001 	mov	x1, #0x0                   	// #0
    8724:	540034e1 	b.ne	8dc0 <fwp_write+0x890>  // b.any
    8728:	f9413bf5 	ldr	x21, [sp, #624]
    872c:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8730:	f9413ff6 	ldr	x22, [sp, #632]
    8734:	aa1403e0 	mov	x0, x20
    8738:	911f4021 	add	x1, x1, #0x7d0
    873c:	d2800142 	mov	x2, #0xa                   	// #10
    8740:	f94153fb 	ldr	x27, [sp, #672]
    8744:	f94157fc 	ldr	x28, [sp, #680]
    8748:	910943ff 	add	sp, sp, #0x250
    874c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8750:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8754:	17ffeb0f 	b	3390 <buf_put>
    8758:	f9400456 	ldr	x22, [x2, #8]
    875c:	f90143f7 	str	x23, [sp, #640]
    8760:	f90147f8 	str	x24, [sp, #648]
    8764:	b4005b16 	cbz	x22, 92c4 <fwp_write+0xd94>
    8768:	aa1603e0 	mov	x0, x22
    876c:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8770:	91214021 	add	x1, x1, #0x850
    8774:	97ffe83f 	bl	2870 <strcmp@plt>
    8778:	2a0003f5 	mov	w21, w0
    877c:	34005fe0 	cbz	w0, 9378 <fwp_write+0xe48>
    8780:	aa1603e0 	mov	x0, x22
    8784:	97ffe7bf 	bl	2680 <strlen@plt>
    8788:	aa1603e1 	mov	x1, x22
    878c:	aa0003e2 	mov	x2, x0
    8790:	aa1403e0 	mov	x0, x20
    8794:	97ffeaff 	bl	3390 <buf_put>
    8798:	52800403 	mov	w3, #0x20                  	// #32
    879c:	91001ff5 	add	x21, sp, #0x7
    87a0:	aa1503e1 	mov	x1, x21
    87a4:	aa1403e0 	mov	x0, x20
    87a8:	d2800022 	mov	x2, #0x1                   	// #1
    87ac:	39001fe3 	strb	w3, [sp, #7]
    87b0:	97ffeaf8 	bl	3390 <buf_put>
    87b4:	52800f63 	mov	w3, #0x7b                  	// #123
    87b8:	aa1403e0 	mov	x0, x20
    87bc:	aa1503e1 	mov	x1, x21
    87c0:	d2800022 	mov	x2, #0x1                   	// #1
    87c4:	39001fe3 	strb	w3, [sp, #7]
    87c8:	97ffeaf2 	bl	3390 <buf_put>
    87cc:	b9401380 	ldr	w0, [x28, #16]
    87d0:	52800018 	mov	w24, #0x0                   	// #0
    87d4:	7100001f 	cmp	w0, #0x0
    87d8:	54003aad 	b.le	8f2c <fwp_write+0x9fc>
    87dc:	f9014bf9 	str	x25, [sp, #656]
    87e0:	f0000019 	adrp	x25, b000 <__modti3+0xc0>
    87e4:	9121e339 	add	x25, x25, #0x878
    87e8:	f9014ffa 	str	x26, [sp, #664]
    87ec:	f000001a 	adrp	x26, b000 <__modti3+0xc0>
    87f0:	9120e35a 	add	x26, x26, #0x838
    87f4:	91002276 	add	x22, x19, #0x8
    87f8:	d2800013 	mov	x19, #0x0                   	// #0
    87fc:	b5003e93 	cbnz	x19, 8fcc <fwp_write+0xa9c>
    8800:	d37df277 	lsl	x23, x19, #3
    8804:	34003cb8 	cbz	w24, 8f98 <fwp_write+0xa68>
    8808:	f9401382 	ldr	x2, [x28, #32]
    880c:	aa1403e0 	mov	x0, x20
    8810:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8814:	52800003 	mov	w3, #0x0                   	// #0
    8818:	f8776842 	ldr	x2, [x2, x23]
    881c:	91000673 	add	x19, x19, #0x1
    8820:	97ffff44 	bl	8530 <fwp_write>
    8824:	b9401380 	ldr	w0, [x28, #16]
    8828:	6b13001f 	cmp	w0, w19
    882c:	54fffe8c 	b.gt	87fc <fwp_write+0x2cc>
    8830:	f9414bf9 	ldr	x25, [sp, #656]
    8834:	f9414ffa 	ldr	x26, [sp, #664]
    8838:	340037b8 	cbz	w24, 8f2c <fwp_write+0x9fc>
    883c:	52800523 	mov	w3, #0x29                  	// #41
    8840:	aa1503e1 	mov	x1, x21
    8844:	aa1403e0 	mov	x0, x20
    8848:	d2800022 	mov	x2, #0x1                   	// #1
    884c:	39001fe3 	strb	w3, [sp, #7]
    8850:	97ffead0 	bl	3390 <buf_put>
    8854:	f9413bf5 	ldr	x21, [sp, #624]
    8858:	f9413ff6 	ldr	x22, [sp, #632]
    885c:	f94143f7 	ldr	x23, [sp, #640]
    8860:	f94147f8 	ldr	x24, [sp, #648]
    8864:	f94153fb 	ldr	x27, [sp, #672]
    8868:	f94157fc 	ldr	x28, [sp, #680]
    886c:	17ffff5d 	b	85e0 <fwp_write+0xb0>
    8870:	b9404855 	ldr	w21, [x2, #72]
    8874:	aa1403e0 	mov	x0, x20
    8878:	93407eb6 	sxtw	x22, w21
    887c:	91000ac1 	add	x1, x22, #0x2
    8880:	97ffea91 	bl	32c4 <buf_grow>
    8884:	a9400281 	ldp	x1, x0, [x20]
    8888:	528e8603 	mov	w3, #0x7430                	// #29744
    888c:	78206823 	strh	w3, [x1, x0]
    8890:	8b000022 	add	x2, x1, x0
    8894:	710002bf 	cmp	w21, #0x0
    8898:	540036cd 	b.le	8f70 <fwp_write+0xa40>
    889c:	110006a3 	add	w3, w21, #0x1
    88a0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    88a4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    88a8:	91000449 	add	x9, x2, #0x1
    88ac:	8b23c043 	add	x3, x2, w3, sxtw
    88b0:	f28aaac6 	movk	x6, #0x5556
    88b4:	f2955568 	movk	x8, #0xaaab
    88b8:	1400000d 	b	88ec <fwp_write+0x3bc>
    88bc:	d2800021 	mov	x1, #0x1                   	// #1
    88c0:	528005a5 	mov	w5, #0x2d                  	// #45
    88c4:	f100001f 	cmp	x0, #0x0
    88c8:	9b467e60 	smulh	x0, x19, x6
    88cc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    88d0:	381ff465 	strb	w5, [x3], #-1
    88d4:	cb040000 	sub	x0, x0, x4
    88d8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    88dc:	cb020000 	sub	x0, x0, x2
    88e0:	8b010013 	add	x19, x0, x1
    88e4:	eb03013f 	cmp	x9, x3
    88e8:	54003440 	b.eq	8f70 <fwp_write+0xa40>  // b.none
    88ec:	9b467e60 	smulh	x0, x19, x6
    88f0:	937ffe64 	asr	x4, x19, #63
    88f4:	52800605 	mov	w5, #0x30                  	// #48
    88f8:	cb040000 	sub	x0, x0, x4
    88fc:	8b000400 	add	x0, x0, x0, lsl #1
    8900:	cb000260 	sub	x0, x19, x0
    8904:	91000c01 	add	x1, x0, #0x3
    8908:	9bc87c22 	umulh	x2, x1, x8
    890c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8910:	8b4204e2 	add	x2, x7, x2, lsr #1
    8914:	eb020021 	subs	x1, x1, x2
    8918:	54fffd60 	b.eq	88c4 <fwp_write+0x394>  // b.none
    891c:	f100043f 	cmp	x1, #0x1
    8920:	54fffce1 	b.ne	88bc <fwp_write+0x38c>  // b.any
    8924:	d2800001 	mov	x1, #0x0                   	// #0
    8928:	52800565 	mov	w5, #0x2b                  	// #43
    892c:	17ffffe6 	b	88c4 <fwp_write+0x394>
    8930:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8934:	f947f400 	ldr	x0, [x0, #4072]
    8938:	f94127e2 	ldr	x2, [sp, #584]
    893c:	f9400001 	ldr	x1, [x0]
    8940:	eb010042 	subs	x2, x2, x1
    8944:	d2800001 	mov	x1, #0x0                   	// #0
    8948:	540023c1 	b.ne	8dc0 <fwp_write+0x890>  // b.any
    894c:	f9413bf5 	ldr	x21, [sp, #624]
    8950:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8954:	f9413ff6 	ldr	x22, [sp, #632]
    8958:	aa1403e0 	mov	x0, x20
    895c:	911f8021 	add	x1, x1, #0x7e0
    8960:	d2800102 	mov	x2, #0x8                   	// #8
    8964:	17ffff77 	b	8740 <fwp_write+0x210>
    8968:	aa1403e0 	mov	x0, x20
    896c:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8970:	d28000c2 	mov	x2, #0x6                   	// #6
    8974:	91210021 	add	x1, x1, #0x840
    8978:	97ffea86 	bl	3390 <buf_put>
    897c:	d2800015 	mov	x21, #0x0                   	// #0
    8980:	f9400263 	ldr	x3, [x19]
    8984:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8988:	54002c60 	b.eq	8f14 <fwp_write+0x9e4>  // b.none
    898c:	f9401f82 	ldr	x2, [x28, #56]
    8990:	f90143f7 	str	x23, [sp, #640]
    8994:	f90147f8 	str	x24, [sp, #648]
    8998:	d2800857 	mov	x23, #0x42                  	// #66
    899c:	f9014bf9 	str	x25, [sp, #656]
    89a0:	f0000016 	adrp	x22, b000 <__modti3+0xc0>
    89a4:	f9014ffa 	str	x26, [sp, #664]
    89a8:	9120e2d6 	add	x22, x22, #0x838
    89ac:	d2800038 	mov	x24, #0x1                   	// #1
    89b0:	f2a18017 	movk	x23, #0xc00, lsl #16
    89b4:	d2809099 	mov	x25, #0x484                 	// #1156
    89b8:	b40004a2 	cbz	x2, 8a4c <fwp_write+0x51c>
    89bc:	b9400040 	ldr	w0, [x2]
    89c0:	7100701f 	cmp	w0, #0x1c
    89c4:	540042c0 	b.eq	921c <fwp_write+0xcec>  // b.none
    89c8:	71006c1f 	cmp	w0, #0x1b
    89cc:	54000408 	b.hi	8a4c <fwp_write+0x51c>  // b.pmore
    89d0:	9ac02301 	lsl	x1, x24, x0
    89d4:	ea17003f 	tst	x1, x23
    89d8:	540036a1 	b.ne	90ac <fwp_write+0xb7c>  // b.any
    89dc:	ea19003f 	tst	x1, x25
    89e0:	54003521 	b.ne	9084 <fwp_write+0xb54>  // b.any
    89e4:	d2800424 	mov	x4, #0x21                  	// #33
    89e8:	ea04003f 	tst	x1, x4
    89ec:	54000300 	b.eq	8a4c <fwp_write+0x51c>  // b.none
    89f0:	b7f849c3 	tbnz	x3, #63, 9328 <fwp_write+0xdf8>
    89f4:	91002261 	add	x1, x19, #0x8
    89f8:	8b150021 	add	x1, x1, x21
    89fc:	39400021 	ldrb	w1, [x1]
    8a00:	7100001f 	cmp	w0, #0x0
    8a04:	93401c23 	sxtb	x3, w1
    8a08:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8a0c:	d503201f 	nop
    8a10:	aa1403e0 	mov	x0, x20
    8a14:	52800003 	mov	w3, #0x0                   	// #0
    8a18:	97fffec6 	bl	8530 <fwp_write>
    8a1c:	910006b5 	add	x21, x21, #0x1
    8a20:	f9400260 	ldr	x0, [x19]
    8a24:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8a28:	eb0002bf 	cmp	x21, x0
    8a2c:	540026c2 	b.cs	8f04 <fwp_write+0x9d4>  // b.hs, b.nlast
    8a30:	d2800042 	mov	x2, #0x2                   	// #2
    8a34:	aa1603e1 	mov	x1, x22
    8a38:	aa1403e0 	mov	x0, x20
    8a3c:	97ffea55 	bl	3390 <buf_put>
    8a40:	f9401f82 	ldr	x2, [x28, #56]
    8a44:	f9400263 	ldr	x3, [x19]
    8a48:	b5fffba2 	cbnz	x2, 89bc <fwp_write+0x48c>
    8a4c:	d37df2a0 	lsl	x0, x21, #3
    8a50:	b7f83f03 	tbnz	x3, #63, 9230 <fwp_write+0xd00>
    8a54:	91002261 	add	x1, x19, #0x8
    8a58:	8b000020 	add	x0, x1, x0
    8a5c:	f9400001 	ldr	x1, [x0]
    8a60:	17ffffec 	b	8a10 <fwp_write+0x4e0>
    8a64:	a9400e62 	ldp	x2, x3, [x19]
    8a68:	b7f83ca3 	tbnz	x3, #63, 91fc <fwp_write+0xccc>
    8a6c:	910123f5 	add	x21, sp, #0x48
    8a70:	aa1503e0 	mov	x0, x21
    8a74:	97ffe8cb 	bl	2da0 <fwp_fmt_u128>
    8a78:	aa1503e0 	mov	x0, x21
    8a7c:	97ffe701 	bl	2680 <strlen@plt>
    8a80:	aa1503e1 	mov	x1, x21
    8a84:	aa0003e2 	mov	x2, x0
    8a88:	17fffed0 	b	85c8 <fwp_write+0x98>
    8a8c:	fd015be8 	str	d8, [sp, #688]
    8a90:	1e270268 	fmov	s8, w19
    8a94:	fd015fe9 	str	d9, [sp, #696]
    8a98:	1e282100 	fcmp	s8, s8
    8a9c:	54004d26 	b.vs	9440 <fwp_write+0xf10>
    8aa0:	1e20c101 	fabs	s1, s8
    8aa4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8aa8:	1e270000 	fmov	s0, w0
    8aac:	1e202020 	fcmp	s1, s0
    8ab0:	54002c0d 	b.le	9030 <fwp_write+0xb00>
    8ab4:	1e202118 	fcmpe	s8, #0.0
    8ab8:	f0000002 	adrp	x2, b000 <__modti3+0xc0>
    8abc:	910c0042 	add	x2, x2, #0x300
    8ac0:	910123f5 	add	x21, sp, #0x48
    8ac4:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8ac8:	911e4021 	add	x1, x1, #0x790
    8acc:	aa1503e0 	mov	x0, x21
    8ad0:	9a81c041 	csel	x1, x2, x1, gt
    8ad4:	97ffe797 	bl	2930 <strcpy@plt>
    8ad8:	aa1503e0 	mov	x0, x21
    8adc:	97ffe6e9 	bl	2680 <strlen@plt>
    8ae0:	aa1503e1 	mov	x1, x21
    8ae4:	aa0003e2 	mov	x2, x0
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	97ffea29 	bl	3390 <buf_put>
    8af0:	f9413bf5 	ldr	x21, [sp, #624]
    8af4:	f9413ff6 	ldr	x22, [sp, #632]
    8af8:	f94153fb 	ldr	x27, [sp, #672]
    8afc:	f94157fc 	ldr	x28, [sp, #680]
    8b00:	fd415be8 	ldr	d8, [sp, #688]
    8b04:	fd415fe9 	ldr	d9, [sp, #696]
    8b08:	17fffeb6 	b	85e0 <fwp_write+0xb0>
    8b0c:	f9400276 	ldr	x22, [x19]
    8b10:	34002e03 	cbz	w3, 90d0 <fwp_write+0xba0>
    8b14:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b18:	f947f400 	ldr	x0, [x0, #4072]
    8b1c:	f94127e2 	ldr	x2, [sp, #584]
    8b20:	f9400001 	ldr	x1, [x0]
    8b24:	eb010042 	subs	x2, x2, x1
    8b28:	d2800001 	mov	x1, #0x0                   	// #0
    8b2c:	540014a1 	b.ne	8dc0 <fwp_write+0x890>  // b.any
    8b30:	aa1603e2 	mov	x2, x22
    8b34:	91002261 	add	x1, x19, #0x8
    8b38:	f9413bf5 	ldr	x21, [sp, #624]
    8b3c:	aa1403e0 	mov	x0, x20
    8b40:	f9413ff6 	ldr	x22, [sp, #632]
    8b44:	17fffeff 	b	8740 <fwp_write+0x210>
    8b48:	fd015be8 	str	d8, [sp, #688]
    8b4c:	9e670268 	fmov	d8, x19
    8b50:	fd015fe9 	str	d9, [sp, #696]
    8b54:	1e682100 	fcmp	d8, d8
    8b58:	54004746 	b.vs	9440 <fwp_write+0xf10>
    8b5c:	1e60c101 	fabs	d1, d8
    8b60:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8b64:	9e670000 	fmov	d0, x0
    8b68:	910123f5 	add	x21, sp, #0x48
    8b6c:	52800033 	mov	w19, #0x1                   	// #1
    8b70:	1e602020 	fcmp	d1, d0
    8b74:	540001ad 	b.le	8ba8 <fwp_write+0x678>
    8b78:	1e602118 	fcmpe	d8, #0.0
    8b7c:	f0000002 	adrp	x2, b000 <__modti3+0xc0>
    8b80:	910c0042 	add	x2, x2, #0x300
    8b84:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8b88:	911e4021 	add	x1, x1, #0x790
    8b8c:	aa1503e0 	mov	x0, x21
    8b90:	9a81c041 	csel	x1, x2, x1, gt
    8b94:	97ffe767 	bl	2930 <strcpy@plt>
    8b98:	17ffffd0 	b	8ad8 <fwp_write+0x5a8>
    8b9c:	11000673 	add	w19, w19, #0x1
    8ba0:	71004a7f 	cmp	w19, #0x12
    8ba4:	54003860 	b.eq	92b0 <fwp_write+0xd80>  // b.none
    8ba8:	1e604100 	fmov	d0, d8
    8bac:	2a1303e1 	mov	w1, w19
    8bb0:	aa1503e0 	mov	x0, x21
    8bb4:	97ffeb38 	bl	3894 <fwp_format_g.constprop.0>
    8bb8:	aa1503e0 	mov	x0, x21
    8bbc:	d2800001 	mov	x1, #0x0                   	// #0
    8bc0:	97ffe6c4 	bl	26d0 <strtod@plt>
    8bc4:	1e602100 	fcmp	d8, d0
    8bc8:	54fffea1 	b.ne	8b9c <fwp_write+0x66c>  // b.any
    8bcc:	aa1503e0 	mov	x0, x21
    8bd0:	97ffea29 	bl	3474 <fwp_finish_float>
    8bd4:	17ffffc1 	b	8ad8 <fwp_write+0x5a8>
    8bd8:	a9400e62 	ldp	x2, x3, [x19]
    8bdc:	910123f3 	add	x19, sp, #0x48
    8be0:	aa1303e0 	mov	x0, x19
    8be4:	97ffe86f 	bl	2da0 <fwp_fmt_u128>
    8be8:	17fffe74 	b	85b8 <fwp_write+0x88>
    8bec:	f90143f7 	str	x23, [sp, #640]
    8bf0:	f90147f8 	str	x24, [sp, #648]
    8bf4:	2a1303f8 	mov	w24, w19
    8bf8:	f9014bf9 	str	x25, [sp, #656]
    8bfc:	f9014ffa 	str	x26, [sp, #664]
    8c00:	f13ffe7f 	cmp	x19, #0xfff
    8c04:	54000049 	b.ls	8c0c <fwp_write+0x6dc>  // b.plast
    8c08:	b9400278 	ldr	w24, [x19]
    8c0c:	f9400f80 	ldr	x0, [x28, #24]
    8c10:	2a1803f5 	mov	w21, w24
    8c14:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8c18:	d37ef6b9 	lsl	x25, x21, #2
    8c1c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8c20:	aa1603e0 	mov	x0, x22
    8c24:	97ffe697 	bl	2680 <strlen@plt>
    8c28:	aa1603e1 	mov	x1, x22
    8c2c:	aa0003e2 	mov	x2, x0
    8c30:	aa1403e0 	mov	x0, x20
    8c34:	97ffe9d7 	bl	3390 <buf_put>
    8c38:	f9401780 	ldr	x0, [x28, #40]
    8c3c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8c40:	7100001f 	cmp	w0, #0x0
    8c44:	5400068d 	b.le	8d14 <fwp_write+0x7e4>
    8c48:	91002276 	add	x22, x19, #0x8
    8c4c:	91001ff5 	add	x21, sp, #0x7
    8c50:	d280001b 	mov	x27, #0x0                   	// #0
    8c54:	5280041a 	mov	w26, #0x20                  	// #32
    8c58:	f9401b80 	ldr	x0, [x28, #48]
    8c5c:	aa1503e1 	mov	x1, x21
    8c60:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8c64:	d2800022 	mov	x2, #0x1                   	// #1
    8c68:	f8786803 	ldr	x3, [x0, x24]
    8c6c:	aa1403e0 	mov	x0, x20
    8c70:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8c74:	39001ffa 	strb	w26, [sp, #7]
    8c78:	97ffe9c6 	bl	3390 <buf_put>
    8c7c:	f13ffeff 	cmp	x23, #0xfff
    8c80:	b9400261 	ldr	w1, [x19]
    8c84:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8c88:	7100383f 	cmp	w1, #0xe
    8c8c:	54000160 	b.eq	8cb8 <fwp_write+0x788>  // b.none
    8c90:	7100403f 	cmp	w1, #0x10
    8c94:	54001a60 	b.eq	8fe0 <fwp_write+0xab0>  // b.none
    8c98:	7100283f 	cmp	w1, #0xa
    8c9c:	54002aa0 	b.eq	91f0 <fwp_write+0xcc0>  // b.none
    8ca0:	540014ac 	b.gt	8f34 <fwp_write+0xa04>
    8ca4:	71000c3f 	cmp	w1, #0x3
    8ca8:	540029ac 	b.gt	91dc <fwp_write+0xcac>
    8cac:	d37ffee0 	lsr	x0, x23, #63
    8cb0:	37f814a1 	tbnz	w1, #31, 8f44 <fwp_write+0xa14>
    8cb4:	d503201f 	nop
    8cb8:	34001460 	cbz	w0, 8f44 <fwp_write+0xa14>
    8cbc:	52800503 	mov	w3, #0x28                  	// #40
    8cc0:	aa1503e1 	mov	x1, x21
    8cc4:	aa1403e0 	mov	x0, x20
    8cc8:	d2800022 	mov	x2, #0x1                   	// #1
    8ccc:	39001fe3 	strb	w3, [sp, #7]
    8cd0:	97ffe9b0 	bl	3390 <buf_put>
    8cd4:	aa1303e2 	mov	x2, x19
    8cd8:	aa1703e1 	mov	x1, x23
    8cdc:	aa1403e0 	mov	x0, x20
    8ce0:	52800003 	mov	w3, #0x0                   	// #0
    8ce4:	97fffe13 	bl	8530 <fwp_write>
    8ce8:	52800523 	mov	w3, #0x29                  	// #41
    8cec:	aa1503e1 	mov	x1, x21
    8cf0:	aa1403e0 	mov	x0, x20
    8cf4:	d2800022 	mov	x2, #0x1                   	// #1
    8cf8:	39001fe3 	strb	w3, [sp, #7]
    8cfc:	97ffe9a5 	bl	3390 <buf_put>
    8d00:	f9401780 	ldr	x0, [x28, #40]
    8d04:	9100077b 	add	x27, x27, #0x1
    8d08:	b8796800 	ldr	w0, [x0, x25]
    8d0c:	6b1b001f 	cmp	w0, w27
    8d10:	54fffa4c 	b.gt	8c58 <fwp_write+0x728>
    8d14:	f9413bf5 	ldr	x21, [sp, #624]
    8d18:	f9413ff6 	ldr	x22, [sp, #632]
    8d1c:	f94143f7 	ldr	x23, [sp, #640]
    8d20:	f94147f8 	ldr	x24, [sp, #648]
    8d24:	f9414bf9 	ldr	x25, [sp, #656]
    8d28:	f9414ffa 	ldr	x26, [sp, #664]
    8d2c:	f94153fb 	ldr	x27, [sp, #672]
    8d30:	f94157fc 	ldr	x28, [sp, #680]
    8d34:	17fffe2b 	b	85e0 <fwp_write+0xb0>
    8d38:	52800783 	mov	w3, #0x3c                  	// #60
    8d3c:	91001ff3 	add	x19, sp, #0x7
    8d40:	aa1303e1 	mov	x1, x19
    8d44:	d2800022 	mov	x2, #0x1                   	// #1
    8d48:	aa1403e0 	mov	x0, x20
    8d4c:	39001fe3 	strb	w3, [sp, #7]
    8d50:	97ffe990 	bl	3390 <buf_put>
    8d54:	f9400795 	ldr	x21, [x28, #8]
    8d58:	aa1503e0 	mov	x0, x21
    8d5c:	97ffe649 	bl	2680 <strlen@plt>
    8d60:	aa1503e1 	mov	x1, x21
    8d64:	aa0003e2 	mov	x2, x0
    8d68:	aa1403e0 	mov	x0, x20
    8d6c:	97ffe989 	bl	3390 <buf_put>
    8d70:	528007c3 	mov	w3, #0x3e                  	// #62
    8d74:	aa1303e1 	mov	x1, x19
    8d78:	aa1403e0 	mov	x0, x20
    8d7c:	d2800022 	mov	x2, #0x1                   	// #1
    8d80:	39001fe3 	strb	w3, [sp, #7]
    8d84:	17fffe12 	b	85cc <fwp_write+0x9c>
    8d88:	f100067f 	cmp	x19, #0x1
    8d8c:	540025a0 	b.eq	9240 <fwp_write+0xd10>  // b.none
    8d90:	b100067f 	cmn	x19, #0x1
    8d94:	54002bc0 	b.eq	930c <fwp_write+0xddc>  // b.none
    8d98:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8d9c:	911e6021 	add	x1, x1, #0x798
    8da0:	d2800022 	mov	x2, #0x1                   	// #1
    8da4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8da8:	f947f400 	ldr	x0, [x0, #4072]
    8dac:	f94127e4 	ldr	x4, [sp, #584]
    8db0:	f9400003 	ldr	x3, [x0]
    8db4:	eb030084 	subs	x4, x4, x3
    8db8:	d2800003 	mov	x3, #0x0                   	// #0
    8dbc:	54ffebe0 	b.eq	8b38 <fwp_write+0x608>  // b.none
    8dc0:	f90143f7 	str	x23, [sp, #640]
    8dc4:	f90147f8 	str	x24, [sp, #648]
    8dc8:	f9014bf9 	str	x25, [sp, #656]
    8dcc:	f9014ffa 	str	x26, [sp, #664]
    8dd0:	fd015be8 	str	d8, [sp, #688]
    8dd4:	fd015fe9 	str	d9, [sp, #696]
    8dd8:	97ffe686 	bl	27f0 <__stack_chk_fail@plt>
    8ddc:	52800b63 	mov	w3, #0x5b                  	// #91
    8de0:	91001ff5 	add	x21, sp, #0x7
    8de4:	aa1503e1 	mov	x1, x21
    8de8:	aa1403e0 	mov	x0, x20
    8dec:	d2800022 	mov	x2, #0x1                   	// #1
    8df0:	f0000016 	adrp	x22, b000 <__modti3+0xc0>
    8df4:	9120e2d6 	add	x22, x22, #0x838
    8df8:	39001fe3 	strb	w3, [sp, #7]
    8dfc:	97ffe965 	bl	3390 <buf_put>
    8e00:	b4000273 	cbz	x19, 8e4c <fwp_write+0x91c>
    8e04:	f9400661 	ldr	x1, [x19, #8]
    8e08:	aa1403e0 	mov	x0, x20
    8e0c:	f9401f82 	ldr	x2, [x28, #56]
    8e10:	52800003 	mov	w3, #0x0                   	// #0
    8e14:	97fffdc7 	bl	8530 <fwp_write>
    8e18:	f9400a73 	ldr	x19, [x19, #16]
    8e1c:	b4000193 	cbz	x19, 8e4c <fwp_write+0x91c>
    8e20:	aa1603e1 	mov	x1, x22
    8e24:	aa1403e0 	mov	x0, x20
    8e28:	d2800042 	mov	x2, #0x2                   	// #2
    8e2c:	97ffe959 	bl	3390 <buf_put>
    8e30:	f9400661 	ldr	x1, [x19, #8]
    8e34:	aa1403e0 	mov	x0, x20
    8e38:	f9401f82 	ldr	x2, [x28, #56]
    8e3c:	52800003 	mov	w3, #0x0                   	// #0
    8e40:	97fffdbc 	bl	8530 <fwp_write>
    8e44:	f9400a73 	ldr	x19, [x19, #16]
    8e48:	b5fffed3 	cbnz	x19, 8e20 <fwp_write+0x8f0>
    8e4c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8e50:	aa1503e1 	mov	x1, x21
    8e54:	aa1403e0 	mov	x0, x20
    8e58:	d2800022 	mov	x2, #0x1                   	// #1
    8e5c:	39001fe3 	strb	w3, [sp, #7]
    8e60:	17fffddb 	b	85cc <fwp_write+0x9c>
    8e64:	aa1403e0 	mov	x0, x20
    8e68:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8e6c:	d28000c2 	mov	x2, #0x6                   	// #6
    8e70:	9120a021 	add	x1, x1, #0x828
    8e74:	97ffe947 	bl	3390 <buf_put>
    8e78:	f9400260 	ldr	x0, [x19]
    8e7c:	b40004c0 	cbz	x0, 8f14 <fwp_write+0x9e4>
    8e80:	910123f5 	add	x21, sp, #0x48
    8e84:	91002276 	add	x22, x19, #0x8
    8e88:	f90143f7 	str	x23, [sp, #640]
    8e8c:	d2800017 	mov	x23, #0x0                   	// #0
    8e90:	f90147f8 	str	x24, [sp, #648]
    8e94:	f0000018 	adrp	x24, b000 <__modti3+0xc0>
    8e98:	9120c318 	add	x24, x24, #0x830
    8e9c:	f9014bf9 	str	x25, [sp, #656]
    8ea0:	f0000019 	adrp	x25, b000 <__modti3+0xc0>
    8ea4:	9120e339 	add	x25, x25, #0x838
    8ea8:	f9014ffa 	str	x26, [sp, #664]
    8eac:	14000005 	b	8ec0 <fwp_write+0x990>
    8eb0:	aa1903e1 	mov	x1, x25
    8eb4:	aa1403e0 	mov	x0, x20
    8eb8:	d2800042 	mov	x2, #0x2                   	// #2
    8ebc:	97ffe935 	bl	3390 <buf_put>
    8ec0:	38776ac5 	ldrb	w5, [x22, x23]
    8ec4:	d2804003 	mov	x3, #0x200                 	// #512
    8ec8:	aa1803e4 	mov	x4, x24
    8ecc:	aa0303e1 	mov	x1, x3
    8ed0:	52800042 	mov	w2, #0x2                   	// #2
    8ed4:	aa1503e0 	mov	x0, x21
    8ed8:	910006f7 	add	x23, x23, #0x1
    8edc:	97ffe621 	bl	2760 <__snprintf_chk@plt>
    8ee0:	aa1503e0 	mov	x0, x21
    8ee4:	97ffe5e7 	bl	2680 <strlen@plt>
    8ee8:	aa1503e1 	mov	x1, x21
    8eec:	aa0003e2 	mov	x2, x0
    8ef0:	aa1403e0 	mov	x0, x20
    8ef4:	97ffe927 	bl	3390 <buf_put>
    8ef8:	f9400260 	ldr	x0, [x19]
    8efc:	eb17001f 	cmp	x0, x23
    8f00:	54fffd88 	b.hi	8eb0 <fwp_write+0x980>  // b.pmore
    8f04:	f94143f7 	ldr	x23, [sp, #640]
    8f08:	f94147f8 	ldr	x24, [sp, #648]
    8f0c:	f9414bf9 	ldr	x25, [sp, #656]
    8f10:	f9414ffa 	ldr	x26, [sp, #664]
    8f14:	52800ba3 	mov	w3, #0x5d                  	// #93
    8f18:	aa1403e0 	mov	x0, x20
    8f1c:	91001fe1 	add	x1, sp, #0x7
    8f20:	d2800022 	mov	x2, #0x1                   	// #1
    8f24:	39001fe3 	strb	w3, [sp, #7]
    8f28:	17fffda9 	b	85cc <fwp_write+0x9c>
    8f2c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8f30:	17fffe44 	b	8840 <fwp_write+0x310>
    8f34:	f10002ff 	cmp	x23, #0x0
    8f38:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8f3c:	71002c3f 	cmp	w1, #0xb
    8f40:	54ffebc0 	b.eq	8cb8 <fwp_write+0x788>  // b.none
    8f44:	aa1303e2 	mov	x2, x19
    8f48:	aa1703e1 	mov	x1, x23
    8f4c:	aa1403e0 	mov	x0, x20
    8f50:	52800003 	mov	w3, #0x0                   	// #0
    8f54:	97fffd77 	bl	8530 <fwp_write>
    8f58:	17ffff6a 	b	8d00 <fwp_write+0x7d0>
    8f5c:	aa1403e0 	mov	x0, x20
    8f60:	91001fe1 	add	x1, sp, #0x7
    8f64:	52800fa3 	mov	w3, #0x7d                  	// #125
    8f68:	d2800022 	mov	x2, #0x1                   	// #1
    8f6c:	17fffe38 	b	884c <fwp_write+0x31c>
    8f70:	a9400281 	ldp	x1, x0, [x20]
    8f74:	91000800 	add	x0, x0, #0x2
    8f78:	8b160000 	add	x0, x0, x22
    8f7c:	f9000680 	str	x0, [x20, #8]
    8f80:	3820683f 	strb	wzr, [x1, x0]
    8f84:	f9413bf5 	ldr	x21, [sp, #624]
    8f88:	f9413ff6 	ldr	x22, [sp, #632]
    8f8c:	f94153fb 	ldr	x27, [sp, #672]
    8f90:	f94157fc 	ldr	x28, [sp, #680]
    8f94:	17fffd93 	b	85e0 <fwp_write+0xb0>
    8f98:	f9400f80 	ldr	x0, [x28, #24]
    8f9c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8fa0:	aa1b03e0 	mov	x0, x27
    8fa4:	97ffe5b7 	bl	2680 <strlen@plt>
    8fa8:	aa1b03e1 	mov	x1, x27
    8fac:	aa0003e2 	mov	x2, x0
    8fb0:	aa1403e0 	mov	x0, x20
    8fb4:	97ffe8f7 	bl	3390 <buf_put>
    8fb8:	aa1903e1 	mov	x1, x25
    8fbc:	aa1403e0 	mov	x0, x20
    8fc0:	d2800062 	mov	x2, #0x3                   	// #3
    8fc4:	97ffe8f3 	bl	3390 <buf_put>
    8fc8:	17fffe10 	b	8808 <fwp_write+0x2d8>
    8fcc:	aa1a03e1 	mov	x1, x26
    8fd0:	aa1403e0 	mov	x0, x20
    8fd4:	d2800042 	mov	x2, #0x2                   	// #2
    8fd8:	97ffe8ee 	bl	3390 <buf_put>
    8fdc:	17fffe09 	b	8800 <fwp_write+0x2d0>
    8fe0:	f9400660 	ldr	x0, [x19, #8]
    8fe4:	b4fffb00 	cbz	x0, 8f44 <fwp_write+0xa14>
    8fe8:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8fec:	91214021 	add	x1, x1, #0x850
    8ff0:	97ffe620 	bl	2870 <strcmp@plt>
    8ff4:	7100001f 	cmp	w0, #0x0
    8ff8:	1a9f07e0 	cset	w0, ne	// ne = any
    8ffc:	17ffff2f 	b	8cb8 <fwp_write+0x788>
    9000:	aa1403e0 	mov	x0, x20
    9004:	d2800042 	mov	x2, #0x2                   	// #2
    9008:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    900c:	91212021 	add	x1, x1, #0x848
    9010:	97ffe8e0 	bl	3390 <buf_put>
    9014:	91004261 	add	x1, x19, #0x10
    9018:	aa1403e0 	mov	x0, x20
    901c:	f9402382 	ldr	x2, [x28, #64]
    9020:	52800003 	mov	w3, #0x0                   	// #0
    9024:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9028:	97fffd42 	bl	8530 <fwp_write>
    902c:	17fffd9c 	b	869c <fwp_write+0x16c>
    9030:	1e22c109 	fcvt	d9, s8
    9034:	910123f5 	add	x21, sp, #0x48
    9038:	52800033 	mov	w19, #0x1                   	// #1
    903c:	d503201f 	nop
    9040:	1e604120 	fmov	d0, d9
    9044:	2a1303e1 	mov	w1, w19
    9048:	aa1503e0 	mov	x0, x21
    904c:	97ffea12 	bl	3894 <fwp_format_g.constprop.0>
    9050:	aa1503e0 	mov	x0, x21
    9054:	d2800001 	mov	x1, #0x0                   	// #0
    9058:	97ffe612 	bl	28a0 <strtof@plt>
    905c:	1e202100 	fcmp	s8, s0
    9060:	54ffdb60 	b.eq	8bcc <fwp_write+0x69c>  // b.none
    9064:	11000673 	add	w19, w19, #0x1
    9068:	71002a7f 	cmp	w19, #0xa
    906c:	54fffea1 	b.ne	9040 <fwp_write+0xb10>  // b.any
    9070:	1e604120 	fmov	d0, d9
    9074:	aa1503e0 	mov	x0, x21
    9078:	52800121 	mov	w1, #0x9                   	// #9
    907c:	97ffea06 	bl	3894 <fwp_format_g.constprop.0>
    9080:	17fffed3 	b	8bcc <fwp_write+0x69c>
    9084:	d37ef6a1 	lsl	x1, x21, #2
    9088:	b7f81563 	tbnz	x3, #63, 9334 <fwp_write+0xe04>
    908c:	91002263 	add	x3, x19, #0x8
    9090:	8b010061 	add	x1, x3, x1
    9094:	b9400023 	ldr	w3, [x1]
    9098:	7100081f 	cmp	w0, #0x2
    909c:	2a0303e1 	mov	w1, w3
    90a0:	93407c63 	sxtw	x3, w3
    90a4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    90a8:	17fffe5a 	b	8a10 <fwp_write+0x4e0>
    90ac:	d37ffaa1 	lsl	x1, x21, #1
    90b0:	b7f81363 	tbnz	x3, #63, 931c <fwp_write+0xdec>
    90b4:	91002263 	add	x3, x19, #0x8
    90b8:	8b010061 	add	x1, x3, x1
    90bc:	79400021 	ldrh	w1, [x1]
    90c0:	7100041f 	cmp	w0, #0x1
    90c4:	93403c23 	sxth	x3, w1
    90c8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    90cc:	17fffe51 	b	8a10 <fwp_write+0x4e0>
    90d0:	52800443 	mov	w3, #0x22                  	// #34
    90d4:	91001ff5 	add	x21, sp, #0x7
    90d8:	91002273 	add	x19, x19, #0x8
    90dc:	aa1503e1 	mov	x1, x21
    90e0:	aa1403e0 	mov	x0, x20
    90e4:	d2800022 	mov	x2, #0x1                   	// #1
    90e8:	39001fe3 	strb	w3, [sp, #7]
    90ec:	f90143f7 	str	x23, [sp, #640]
    90f0:	8b160277 	add	x23, x19, x22
    90f4:	f90147f8 	str	x24, [sp, #648]
    90f8:	97ffe8a6 	bl	3390 <buf_put>
    90fc:	b4000696 	cbz	x22, 91cc <fwp_write+0xc9c>
    9100:	d0000018 	adrp	x24, b000 <__modti3+0xc0>
    9104:	911fe318 	add	x24, x24, #0x7f8
    9108:	f9014bf9 	str	x25, [sp, #656]
    910c:	d0000019 	adrp	x25, b000 <__modti3+0xc0>
    9110:	91206339 	add	x25, x25, #0x818
    9114:	f9014ffa 	str	x26, [sp, #664]
    9118:	1400000d 	b	914c <fwp_write+0xc1c>
    911c:	710024bf 	cmp	w5, #0x9
    9120:	54000460 	b.eq	91ac <fwp_write+0xc7c>  // b.none
    9124:	710028bf 	cmp	w5, #0xa
    9128:	54000a61 	b.ne	9274 <fwp_write+0xd44>  // b.any
    912c:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    9130:	aa1403e0 	mov	x0, x20
    9134:	91202021 	add	x1, x1, #0x808
    9138:	d2800042 	mov	x2, #0x2                   	// #2
    913c:	97ffe895 	bl	3390 <buf_put>
    9140:	91000673 	add	x19, x19, #0x1
    9144:	eb17027f 	cmp	x19, x23
    9148:	540003e0 	b.eq	91c4 <fwp_write+0xc94>  // b.none
    914c:	39400265 	ldrb	w5, [x19]
    9150:	710034bf 	cmp	w5, #0xd
    9154:	54000180 	b.eq	9184 <fwp_write+0xc54>  // b.none
    9158:	54fffe29 	b.ls	911c <fwp_write+0xbec>  // b.plast
    915c:	710088bf 	cmp	w5, #0x22
    9160:	540001c0 	b.eq	9198 <fwp_write+0xc68>  // b.none
    9164:	710170bf 	cmp	w5, #0x5c
    9168:	54000741 	b.ne	9250 <fwp_write+0xd20>  // b.any
    916c:	aa1403e0 	mov	x0, x20
    9170:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    9174:	d2800042 	mov	x2, #0x2                   	// #2
    9178:	91200021 	add	x1, x1, #0x800
    917c:	97ffe885 	bl	3390 <buf_put>
    9180:	17fffff0 	b	9140 <fwp_write+0xc10>
    9184:	aa1903e1 	mov	x1, x25
    9188:	aa1403e0 	mov	x0, x20
    918c:	d2800042 	mov	x2, #0x2                   	// #2
    9190:	97ffe880 	bl	3390 <buf_put>
    9194:	17ffffeb 	b	9140 <fwp_write+0xc10>
    9198:	aa1803e1 	mov	x1, x24
    919c:	aa1403e0 	mov	x0, x20
    91a0:	d2800042 	mov	x2, #0x2                   	// #2
    91a4:	97ffe87b 	bl	3390 <buf_put>
    91a8:	17ffffe6 	b	9140 <fwp_write+0xc10>
    91ac:	aa1403e0 	mov	x0, x20
    91b0:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    91b4:	d2800042 	mov	x2, #0x2                   	// #2
    91b8:	91204021 	add	x1, x1, #0x810
    91bc:	97ffe875 	bl	3390 <buf_put>
    91c0:	17ffffe0 	b	9140 <fwp_write+0xc10>
    91c4:	f9414bf9 	ldr	x25, [sp, #656]
    91c8:	f9414ffa 	ldr	x26, [sp, #664]
    91cc:	aa1503e1 	mov	x1, x21
    91d0:	aa1403e0 	mov	x0, x20
    91d4:	52800443 	mov	w3, #0x22                  	// #34
    91d8:	17fffd9c 	b	8848 <fwp_write+0x318>
    91dc:	7100103f 	cmp	w1, #0x4
    91e0:	54ffeb21 	b.ne	8f44 <fwp_write+0xa14>  // b.any
    91e4:	f94006e0 	ldr	x0, [x23, #8]
    91e8:	d37ffc00 	lsr	x0, x0, #63
    91ec:	17fffeb3 	b	8cb8 <fwp_write+0x788>
    91f0:	710002ff 	cmp	w23, #0x0
    91f4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    91f8:	17fffeb0 	b	8cb8 <fwp_write+0x788>
    91fc:	528005a1 	mov	w1, #0x2d                  	// #45
    9200:	eb0203e2 	negs	x2, x2
    9204:	da0303e3 	ngc	x3, x3
    9208:	910127e0 	add	x0, sp, #0x49
    920c:	910123f5 	add	x21, sp, #0x48
    9210:	390123e1 	strb	w1, [sp, #72]
    9214:	97ffe6e3 	bl	2da0 <fwp_fmt_u128>
    9218:	17fffe18 	b	8a78 <fwp_write+0x548>
    921c:	d37ceea1 	lsl	x1, x21, #4
    9220:	b7f810a3 	tbnz	x3, #63, 9434 <fwp_write+0xf04>
    9224:	91002260 	add	x0, x19, #0x8
    9228:	8b010001 	add	x1, x0, x1
    922c:	17fffdf9 	b	8a10 <fwp_write+0x4e0>
    9230:	f9400a61 	ldr	x1, [x19, #16]
    9234:	8b010000 	add	x0, x0, x1
    9238:	f9400001 	ldr	x1, [x0]
    923c:	17fffdf5 	b	8a10 <fwp_write+0x4e0>
    9240:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    9244:	d2800042 	mov	x2, #0x2                   	// #2
    9248:	911e8021 	add	x1, x1, #0x7a0
    924c:	17fffed6 	b	8da4 <fwp_write+0x874>
    9250:	7101fcbf 	cmp	w5, #0x7f
    9254:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9258:	540000e9 	b.ls	9274 <fwp_write+0xd44>  // b.plast
    925c:	aa1503e1 	mov	x1, x21
    9260:	aa1403e0 	mov	x0, x20
    9264:	d2800022 	mov	x2, #0x1                   	// #1
    9268:	39001fe5 	strb	w5, [sp, #7]
    926c:	97ffe849 	bl	3390 <buf_put>
    9270:	17ffffb4 	b	9140 <fwp_write+0xc10>
    9274:	d2800203 	mov	x3, #0x10                  	// #16
    9278:	d0000004 	adrp	x4, b000 <__modti3+0xc0>
    927c:	aa0303e1 	mov	x1, x3
    9280:	91208084 	add	x4, x4, #0x820
    9284:	910123f6 	add	x22, sp, #0x48
    9288:	52800042 	mov	w2, #0x2                   	// #2
    928c:	aa1603e0 	mov	x0, x22
    9290:	97ffe534 	bl	2760 <__snprintf_chk@plt>
    9294:	aa1603e0 	mov	x0, x22
    9298:	97ffe4fa 	bl	2680 <strlen@plt>
    929c:	aa1603e1 	mov	x1, x22
    92a0:	aa0003e2 	mov	x2, x0
    92a4:	aa1403e0 	mov	x0, x20
    92a8:	97ffe83a 	bl	3390 <buf_put>
    92ac:	17ffffa5 	b	9140 <fwp_write+0xc10>
    92b0:	1e604100 	fmov	d0, d8
    92b4:	aa1503e0 	mov	x0, x21
    92b8:	52800221 	mov	w1, #0x11                  	// #17
    92bc:	97ffe976 	bl	3894 <fwp_format_g.constprop.0>
    92c0:	17fffe43 	b	8bcc <fwp_write+0x69c>
    92c4:	b9401040 	ldr	w0, [x2, #16]
    92c8:	350003c0 	cbnz	w0, 9340 <fwp_write+0xe10>
    92cc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    92d0:	f947f400 	ldr	x0, [x0, #4072]
    92d4:	f94127e2 	ldr	x2, [sp, #584]
    92d8:	f9400001 	ldr	x1, [x0]
    92dc:	eb010042 	subs	x2, x2, x1
    92e0:	d2800001 	mov	x1, #0x0                   	// #0
    92e4:	54ffd721 	b.ne	8dc8 <fwp_write+0x898>  // b.any
    92e8:	f9413bf5 	ldr	x21, [sp, #624]
    92ec:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    92f0:	f9413ff6 	ldr	x22, [sp, #632]
    92f4:	aa1403e0 	mov	x0, x20
    92f8:	f94143f7 	ldr	x23, [sp, #640]
    92fc:	9121c021 	add	x1, x1, #0x870
    9300:	f94147f8 	ldr	x24, [sp, #648]
    9304:	d2800042 	mov	x2, #0x2                   	// #2
    9308:	17fffd0e 	b	8740 <fwp_write+0x210>
    930c:	d0000001 	adrp	x1, b000 <__modti3+0xc0>
    9310:	d2800042 	mov	x2, #0x2                   	// #2
    9314:	911ea021 	add	x1, x1, #0x7a8
    9318:	17fffea3 	b	8da4 <fwp_write+0x874>
    931c:	f9400a63 	ldr	x3, [x19, #16]
    9320:	8b030021 	add	x1, x1, x3
    9324:	17ffff66 	b	90bc <fwp_write+0xb8c>
    9328:	f9400a61 	ldr	x1, [x19, #16]
    932c:	8b0102a1 	add	x1, x21, x1
    9330:	17fffdb3 	b	89fc <fwp_write+0x4cc>
    9334:	f9400a63 	ldr	x3, [x19, #16]
    9338:	8b030021 	add	x1, x1, x3
    933c:	17ffff56 	b	9094 <fwp_write+0xb64>
    9340:	b9404840 	ldr	w0, [x2, #72]
    9344:	91001ff5 	add	x21, sp, #0x7
    9348:	34ffa360 	cbz	w0, 87b4 <fwp_write+0x284>
    934c:	52800503 	mov	w3, #0x28                  	// #40
    9350:	aa1403e0 	mov	x0, x20
    9354:	aa1503e1 	mov	x1, x21
    9358:	d2800022 	mov	x2, #0x1                   	// #1
    935c:	39001fe3 	strb	w3, [sp, #7]
    9360:	97ffe80c 	bl	3390 <buf_put>
    9364:	b9401380 	ldr	w0, [x28, #16]
    9368:	52800038 	mov	w24, #0x1                   	// #1
    936c:	7100001f 	cmp	w0, #0x0
    9370:	54ffa36c 	b.gt	87dc <fwp_write+0x2ac>
    9374:	17fffd32 	b	883c <fwp_write+0x30c>
    9378:	f9014bf9 	str	x25, [sp, #656]
    937c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10ca8>
    9380:	f9014ffa 	str	x26, [sp, #664]
    9384:	f9400676 	ldr	x22, [x19, #8]
    9388:	91102333 	add	x19, x25, #0x408
    938c:	91002273 	add	x19, x19, #0x8
    9390:	937ffed8 	asr	x24, x22, #63
    9394:	aa1802c0 	orr	x0, x22, x24
    9398:	b5000320 	cbnz	x0, 93fc <fwp_write+0xecc>
    939c:	110006b5 	add	w21, w21, #0x1
    93a0:	710016bf 	cmp	w21, #0x5
    93a4:	54ffffc1 	b.ne	939c <fwp_write+0xe6c>  // b.any
    93a8:	b7f80578 	tbnz	x24, #63, 9454 <fwp_write+0xf24>
    93ac:	910023f3 	add	x19, sp, #0x8
    93b0:	aa1603e2 	mov	x2, x22
    93b4:	aa1303e0 	mov	x0, x19
    93b8:	d2800003 	mov	x3, #0x0                   	// #0
    93bc:	97ffe679 	bl	2da0 <fwp_fmt_u128>
    93c0:	910123f5 	add	x21, sp, #0x48
    93c4:	d0000003 	adrp	x3, b000 <__modti3+0xc0>
    93c8:	aa1303e4 	mov	x4, x19
    93cc:	aa1503e0 	mov	x0, x21
    93d0:	9121a063 	add	x3, x3, #0x868
    93d4:	d2804002 	mov	x2, #0x200                 	// #512
    93d8:	52800041 	mov	w1, #0x2                   	// #2
    93dc:	97ffe4ad 	bl	2690 <__sprintf_chk@plt>
    93e0:	aa1503e0 	mov	x0, x21
    93e4:	97ffe4a7 	bl	2680 <strlen@plt>
    93e8:	aa1503e1 	mov	x1, x21
    93ec:	aa0003e2 	mov	x2, x0
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	97ffe7e7 	bl	3390 <buf_put>
    93f8:	17fffe47 	b	8d14 <fwp_write+0x7e4>
    93fc:	f9400277 	ldr	x23, [x19]
    9400:	aa1603e0 	mov	x0, x22
    9404:	aa1803e1 	mov	x1, x24
    9408:	aa1703e2 	mov	x2, x23
    940c:	937ffefa 	asr	x26, x23, #63
    9410:	aa1a03e3 	mov	x3, x26
    9414:	940006cb 	bl	af40 <__modti3>
    9418:	aa010000 	orr	x0, x0, x1
    941c:	b40002c0 	cbz	x0, 9474 <fwp_write+0xf44>
    9420:	110006b5 	add	w21, w21, #0x1
    9424:	91004273 	add	x19, x19, #0x10
    9428:	710016bf 	cmp	w21, #0x5
    942c:	54fffe81 	b.ne	93fc <fwp_write+0xecc>  // b.any
    9430:	17ffffde 	b	93a8 <fwp_write+0xe78>
    9434:	f9400a60 	ldr	x0, [x19, #16]
    9438:	8b000021 	add	x1, x1, x0
    943c:	17fffd75 	b	8a10 <fwp_write+0x4e0>
    9440:	528c29c0 	mov	w0, #0x614e                	// #24910
    9444:	910123f5 	add	x21, sp, #0x48
    9448:	72a009c0 	movk	w0, #0x4e, lsl #16
    944c:	b9004be0 	str	w0, [sp, #72]
    9450:	17fffda2 	b	8ad8 <fwp_write+0x5a8>
    9454:	528005a1 	mov	w1, #0x2d                  	// #45
    9458:	eb1603e2 	negs	x2, x22
    945c:	da1803e3 	ngc	x3, x24
    9460:	910027e0 	add	x0, sp, #0x9
    9464:	910023f3 	add	x19, sp, #0x8
    9468:	390023e1 	strb	w1, [sp, #8]
    946c:	97ffe64d 	bl	2da0 <fwp_fmt_u128>
    9470:	17ffffd4 	b	93c0 <fwp_write+0xe90>
    9474:	aa1703e2 	mov	x2, x23
    9478:	aa1a03e3 	mov	x3, x26
    947c:	aa1603e0 	mov	x0, x22
    9480:	aa1803e1 	mov	x1, x24
    9484:	940005cf 	bl	abc0 <__divti3>
    9488:	aa0003e2 	mov	x2, x0
    948c:	aa0103e3 	mov	x3, x1
    9490:	b7f80201 	tbnz	x1, #63, 94d0 <fwp_write+0xfa0>
    9494:	910023f3 	add	x19, sp, #0x8
    9498:	aa1303e0 	mov	x0, x19
    949c:	97ffe641 	bl	2da0 <fwp_fmt_u128>
    94a0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    94a4:	91102339 	add	x25, x25, #0x408
    94a8:	910123f5 	add	x21, sp, #0x48
    94ac:	aa1303e4 	mov	x4, x19
    94b0:	aa1503e0 	mov	x0, x21
    94b4:	d0000003 	adrp	x3, b000 <__modti3+0xc0>
    94b8:	f8616b25 	ldr	x5, [x25, x1]
    94bc:	91218063 	add	x3, x3, #0x860
    94c0:	d2804002 	mov	x2, #0x200                 	// #512
    94c4:	52800041 	mov	w1, #0x2                   	// #2
    94c8:	97ffe472 	bl	2690 <__sprintf_chk@plt>
    94cc:	17ffffc5 	b	93e0 <fwp_write+0xeb0>
    94d0:	528005a4 	mov	w4, #0x2d                  	// #45
    94d4:	eb0003e2 	negs	x2, x0
    94d8:	da0103e3 	ngc	x3, x1
    94dc:	910027e0 	add	x0, sp, #0x9
    94e0:	910023f3 	add	x19, sp, #0x8
    94e4:	390023e4 	strb	w4, [sp, #8]
    94e8:	97ffe62e 	bl	2da0 <fwp_fmt_u128>
    94ec:	17ffffed 	b	94a0 <fwp_write+0xf70>
    94f0:	f9013bf5 	str	x21, [sp, #624]
    94f4:	f9013ff6 	str	x22, [sp, #632]
    94f8:	f90143f7 	str	x23, [sp, #640]
    94fc:	f90147f8 	str	x24, [sp, #648]
    9500:	f9014bf9 	str	x25, [sp, #656]
    9504:	f9014ffa 	str	x26, [sp, #664]
    9508:	f90153fb 	str	x27, [sp, #672]
    950c:	f90157fc 	str	x28, [sp, #680]
    9510:	fd015be8 	str	d8, [sp, #688]
    9514:	fd015fe9 	str	d9, [sp, #696]
    9518:	97ffe4b6 	bl	27f0 <__stack_chk_fail@plt>
    951c:	d503201f 	nop

0000000000009520 <fwp_main_thread>:
    9520:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    9524:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9528:	9115c001 	add	x1, x0, #0x570
    952c:	910003fd 	mov	x29, sp
    9530:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9534:	f947f400 	ldr	x0, [x0, #4072]
    9538:	a90153f3 	stp	x19, x20, [sp, #16]
    953c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9540:	a90363f7 	stp	x23, x24, [sp, #48]
    9544:	a9046bf9 	stp	x25, x26, [sp, #64]
    9548:	a90573fb 	stp	x27, x28, [sp, #80]
    954c:	fd0033e8 	str	d8, [sp, #96]
    9550:	d10603ff 	sub	sp, sp, #0x180
    9554:	b953a421 	ldr	w1, [x1, #5028]
    9558:	f9400002 	ldr	x2, [x0]
    955c:	f81f83a2 	stur	x2, [x29, #-8]
    9560:	d2800002 	mov	x2, #0x0                   	// #0
    9564:	34002741 	cbz	w1, 9a4c <fwp_main_thread+0x52c>
    9568:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    956c:	9115c000 	add	x0, x0, #0x570
    9570:	b953a800 	ldr	w0, [x0, #5032]
    9574:	35002640 	cbnz	w0, 9a3c <fwp_main_thread+0x51c>
    9578:	f00000a0 	adrp	x0, 20000 <__data_start>
    957c:	f00000a2 	adrp	x2, 20000 <__data_start>
    9580:	91010019 	add	x25, x0, #0x40
    9584:	910e4042 	add	x2, x2, #0x390
    9588:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    958c:	d2a00024 	mov	x4, #0x10000               	// #65536
    9590:	d10383bb 	sub	x27, x29, #0xe0
    9594:	d103e3b8 	sub	x24, x29, #0xf8
    9598:	aa1b03e0 	mov	x0, x27
    959c:	d2800001 	mov	x1, #0x0                   	// #0
    95a0:	f81203a2 	stur	x2, [x29, #-224]
    95a4:	b81283bf 	stur	wzr, [x29, #-216]
    95a8:	f81303a4 	stur	x4, [x29, #-208]
    95ac:	a9018f38 	stp	x24, x3, [x25, #24]
    95b0:	97ffe428 	bl	2650 <sigaltstack@plt>
    95b4:	3500a4e0 	cbnz	w0, aa50 <fwp_main_thread+0x1530>
    95b8:	4f000400 	movi	v0.4s, #0x0
    95bc:	d10263a0 	sub	x0, x29, #0x98
    95c0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    95c4:	913fc021 	add	x1, x1, #0xff0
    95c8:	f81603a1 	stur	x1, [x29, #-160]
    95cc:	52800082 	mov	w2, #0x4                   	// #4
    95d0:	72a10002 	movk	w2, #0x800, lsl #16
    95d4:	d10283b6 	sub	x22, x29, #0xa0
    95d8:	3d802000 	str	q0, [x0, #128]
    95dc:	b81e83a2 	stur	w2, [x29, #-24]
    95e0:	ad000000 	stp	q0, q0, [x0]
    95e4:	ad010000 	stp	q0, q0, [x0, #32]
    95e8:	ad020000 	stp	q0, q0, [x0, #64]
    95ec:	ad030000 	stp	q0, q0, [x0, #96]
    95f0:	97ffe470 	bl	27b0 <sigemptyset@plt>
    95f4:	3500a2e0 	cbnz	w0, aa50 <fwp_main_thread+0x1530>
    95f8:	aa1603e1 	mov	x1, x22
    95fc:	d2800002 	mov	x2, #0x0                   	// #0
    9600:	52800160 	mov	w0, #0xb                   	// #11
    9604:	97ffe483 	bl	2810 <sigaction@plt>
    9608:	3500a240 	cbnz	w0, aa50 <fwp_main_thread+0x1530>
    960c:	aa1603e1 	mov	x1, x22
    9610:	d2800002 	mov	x2, #0x0                   	// #0
    9614:	528000e0 	mov	w0, #0x7                   	// #7
    9618:	97ffe47e 	bl	2810 <sigaction@plt>
    961c:	3500a1a0 	cbnz	w0, aa50 <fwp_main_thread+0x1530>
    9620:	b9431b20 	ldr	w0, [x25, #792]
    9624:	34002180 	cbz	w0, 9a54 <fwp_main_thread+0x534>
    9628:	f00000a0 	adrp	x0, 20000 <__data_start>
    962c:	91010015 	add	x21, x0, #0x40
    9630:	f9400ab4 	ldr	x20, [x21, #16]
    9634:	b4000c54 	cbz	x20, 97bc <fwp_main_thread+0x29c>
    9638:	aa1403f3 	mov	x19, x20
    963c:	91010297 	add	x23, x20, #0x40
    9640:	39414a98 	ldrb	w24, [x20, #82]
    9644:	52800036 	mov	w22, #0x1                   	// #1
    9648:	39014a96 	strb	w22, [x20, #82]
    964c:	f9401680 	ldr	x0, [x20, #40]
    9650:	b4000620 	cbz	x0, 9714 <fwp_main_thread+0x1f4>
    9654:	f9403281 	ldr	x1, [x20, #96]
    9658:	39414680 	ldrb	w0, [x20, #81]
    965c:	b4000e81 	cbz	x1, 982c <fwp_main_thread+0x30c>
    9660:	36000d40 	tbz	w0, #0, 9808 <fwp_main_thread+0x2e8>
    9664:	39414a62 	ldrb	w2, [x19, #82]
    9668:	f9402281 	ldr	x1, [x20, #64]
    966c:	37001082 	tbnz	w2, #0, 987c <fwp_main_thread+0x35c>
    9670:	f9403260 	ldr	x0, [x19, #96]
    9674:	a911fe77 	stp	x23, xzr, [x19, #280]
    9678:	f9009661 	str	x1, [x19, #296]
    967c:	b4000041 	cbz	x1, 9684 <fwp_main_thread+0x164>
    9680:	f9009033 	str	x19, [x1, #288]
    9684:	f9002293 	str	x19, [x20, #64]
    9688:	b4000100 	cbz	x0, 96a8 <fwp_main_thread+0x188>
    968c:	f94056a1 	ldr	x1, [x21, #168]
    9690:	39015676 	strb	w22, [x19, #85]
    9694:	f9003660 	str	x0, [x19, #104]
    9698:	a910867f 	stp	xzr, x1, [x19, #264]
    969c:	b4000041 	cbz	x1, 96a4 <fwp_main_thread+0x184>
    96a0:	f9008433 	str	x19, [x1, #264]
    96a4:	f90056b3 	str	x19, [x21, #168]
    96a8:	39015a7f 	strb	wzr, [x19, #86]
    96ac:	97fff2a6 	bl	6144 <fwp_block>
    96b0:	f9408e62 	ldr	x2, [x19, #280]
    96b4:	b4000142 	cbz	x2, 96dc <fwp_main_thread+0x1bc>
    96b8:	a9520261 	ldp	x1, x0, [x19, #288]
    96bc:	b4000ec1 	cbz	x1, 9894 <fwp_main_thread+0x374>
    96c0:	f9009420 	str	x0, [x1, #296]
    96c4:	f9409660 	ldr	x0, [x19, #296]
    96c8:	b4000040 	cbz	x0, 96d0 <fwp_main_thread+0x1b0>
    96cc:	f9009001 	str	x1, [x0, #288]
    96d0:	91080260 	add	x0, x19, #0x200
    96d4:	f900967f 	str	xzr, [x19, #296]
    96d8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    96dc:	39415660 	ldrb	w0, [x19, #85]
    96e0:	f9400aa1 	ldr	x1, [x21, #16]
    96e4:	36000c80 	tbz	w0, #0, 9874 <fwp_main_thread+0x354>
    96e8:	a9508262 	ldp	x2, x0, [x19, #264]
    96ec:	b4000d82 	cbz	x2, 989c <fwp_main_thread+0x37c>
    96f0:	f9008840 	str	x0, [x2, #272]
    96f4:	b4000040 	cbz	x0, 96fc <fwp_main_thread+0x1dc>
    96f8:	f9008402 	str	x2, [x0, #264]
    96fc:	91080260 	add	x0, x19, #0x200
    9700:	3901567f 	strb	wzr, [x19, #85]
    9704:	aa0103f3 	mov	x19, x1
    9708:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    970c:	f9401680 	ldr	x0, [x20, #40]
    9710:	b5fffa20 	cbnz	x0, 9654 <fwp_main_thread+0x134>
    9714:	f00000a0 	adrp	x0, 20000 <__data_start>
    9718:	91010000 	add	x0, x0, #0x40
    971c:	39014a98 	strb	w24, [x20, #82]
    9720:	f9417c00 	ldr	x0, [x0, #760]
    9724:	b4000520 	cbz	x0, 97c8 <fwp_main_thread+0x2a8>
    9728:	f00000a0 	adrp	x0, 20000 <__data_start>
    972c:	91010000 	add	x0, x0, #0x40
    9730:	f9419801 	ldr	x1, [x0, #816]
    9734:	b903281f 	str	wzr, [x0, #808]
    9738:	eb13003f 	cmp	x1, x19
    973c:	54000641 	b.ne	9804 <fwp_main_thread+0x2e4>  // b.any
    9740:	b4000bd3 	cbz	x19, 98b8 <fwp_main_thread+0x398>
    9744:	f00000a0 	adrp	x0, 20000 <__data_start>
    9748:	91010000 	add	x0, x0, #0x40
    974c:	52800021 	mov	w1, #0x1                   	// #1
    9750:	39014a61 	strb	w1, [x19, #82]
    9754:	f9416805 	ldr	x5, [x0, #720]
    9758:	b4000b05 	cbz	x5, 98b8 <fwp_main_thread+0x398>
    975c:	394140a0 	ldrb	w0, [x5, #80]
    9760:	37000060 	tbnz	w0, #0, 976c <fwp_main_thread+0x24c>
    9764:	aa0503e0 	mov	x0, x5
    9768:	97ffe722 	bl	33f0 <fwp_cancel_tree.part.0>
    976c:	f9409ca5 	ldr	x5, [x5, #312]
    9770:	b5ffff65 	cbnz	x5, 975c <fwp_main_thread+0x23c>
    9774:	f00000a0 	adrp	x0, 20000 <__data_start>
    9778:	91010014 	add	x20, x0, #0x40
    977c:	52800035 	mov	w21, #0x1                   	// #1
    9780:	f9402a60 	ldr	x0, [x19, #80]
    9784:	f2001c1f 	tst	x0, #0xff000000ff
    9788:	540000e1 	b.ne	97a4 <fwp_main_thread+0x284>  // b.any
    978c:	f9401680 	ldr	x0, [x20, #40]
    9790:	39015275 	strb	w21, [x19, #84]
    9794:	f900827f 	str	xzr, [x19, #256]
    9798:	b4000860 	cbz	x0, 98a4 <fwp_main_thread+0x384>
    979c:	f9008013 	str	x19, [x0, #256]
    97a0:	f9001693 	str	x19, [x20, #40]
    97a4:	97fff268 	bl	6144 <fwp_block>
    97a8:	97fff1fa 	bl	5f90 <fwp_free_zombie>
    97ac:	f9416a80 	ldr	x0, [x20, #720]
    97b0:	b4000840 	cbz	x0, 98b8 <fwp_main_thread+0x398>
    97b4:	f9419a93 	ldr	x19, [x20, #816]
    97b8:	17fffff2 	b	9780 <fwp_main_thread+0x260>
    97bc:	f9417ea0 	ldr	x0, [x21, #760]
    97c0:	b5000760 	cbnz	x0, 98ac <fwp_main_thread+0x38c>
    97c4:	d2800013 	mov	x19, #0x0                   	// #0
    97c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    97cc:	91010014 	add	x20, x0, #0x40
    97d0:	f9418680 	ldr	x0, [x20, #776]
    97d4:	b5fffaa0 	cbnz	x0, 9728 <fwp_main_thread+0x208>
    97d8:	f9417a80 	ldr	x0, [x20, #752]
    97dc:	97ffebf9 	bl	47c0 <fwp_mem_free>
    97e0:	f9017a9f 	str	xzr, [x20, #752]
    97e4:	f901829f 	str	xzr, [x20, #768]
    97e8:	f9419a80 	ldr	x0, [x20, #816]
    97ec:	b4009cb3 	cbz	x19, ab80 <fwp_main_thread+0x1660>
    97f0:	f900567f 	str	xzr, [x19, #168]
    97f4:	f9005e7f 	str	xzr, [x19, #184]
    97f8:	b9032a9f 	str	wzr, [x20, #808]
    97fc:	eb00027f 	cmp	x19, x0
    9800:	54fffa20 	b.eq	9744 <fwp_main_thread+0x224>  // b.none
    9804:	97ffe40f 	bl	2840 <abort@plt>
    9808:	97ffe79e 	bl	3680 <fwp_now_ns>
    980c:	f9403281 	ldr	x1, [x20, #96]
    9810:	eb01001f 	cmp	x0, x1
    9814:	540000ab 	b.lt	9828 <fwp_main_thread+0x308>  // b.tstop
    9818:	39414280 	ldrb	w0, [x20, #80]
    981c:	37000060 	tbnz	w0, #0, 9828 <fwp_main_thread+0x308>
    9820:	aa1403e0 	mov	x0, x20
    9824:	97ffe6f3 	bl	33f0 <fwp_cancel_tree.part.0>
    9828:	39414680 	ldrb	w0, [x20, #81]
    982c:	39414a62 	ldrb	w2, [x19, #82]
    9830:	3707f1c0 	tbnz	w0, #0, 9668 <fwp_main_thread+0x148>
    9834:	f9403280 	ldr	x0, [x20, #96]
    9838:	370001a2 	tbnz	w2, #0, 986c <fwp_main_thread+0x34c>
    983c:	f9403261 	ldr	x1, [x19, #96]
    9840:	b4000161 	cbz	x1, 986c <fwp_main_thread+0x34c>
    9844:	b4008ca0 	cbz	x0, a9d8 <fwp_main_thread+0x14b8>
    9848:	eb01001f 	cmp	x0, x1
    984c:	9a81d000 	csel	x0, x0, x1, le
    9850:	f9402281 	ldr	x1, [x20, #64]
    9854:	a911fe77 	stp	x23, xzr, [x19, #280]
    9858:	f9009661 	str	x1, [x19, #296]
    985c:	b4000041 	cbz	x1, 9864 <fwp_main_thread+0x344>
    9860:	f9009033 	str	x19, [x1, #288]
    9864:	f9002293 	str	x19, [x20, #64]
    9868:	17ffff89 	b	968c <fwp_main_thread+0x16c>
    986c:	f9402281 	ldr	x1, [x20, #64]
    9870:	17ffff81 	b	9674 <fwp_main_thread+0x154>
    9874:	aa0103f3 	mov	x19, x1
    9878:	17ffff75 	b	964c <fwp_main_thread+0x12c>
    987c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9880:	f9009661 	str	x1, [x19, #296]
    9884:	b4000041 	cbz	x1, 988c <fwp_main_thread+0x36c>
    9888:	f9009033 	str	x19, [x1, #288]
    988c:	f9002293 	str	x19, [x20, #64]
    9890:	17ffff86 	b	96a8 <fwp_main_thread+0x188>
    9894:	f9000040 	str	x0, [x2]
    9898:	17ffff8c 	b	96c8 <fwp_main_thread+0x1a8>
    989c:	f90056a0 	str	x0, [x21, #168]
    98a0:	17ffff95 	b	96f4 <fwp_main_thread+0x1d4>
    98a4:	f9001a93 	str	x19, [x20, #48]
    98a8:	17ffffbe 	b	97a0 <fwp_main_thread+0x280>
    98ac:	f9419aa0 	ldr	x0, [x21, #816]
    98b0:	b9032abf 	str	wzr, [x21, #808]
    98b4:	b5fffa80 	cbnz	x0, 9804 <fwp_main_thread+0x2e4>
    98b8:	97fff1b6 	bl	5f90 <fwp_free_zombie>
    98bc:	f00000a0 	adrp	x0, 20000 <__data_start>
    98c0:	91010015 	add	x21, x0, #0x40
    98c4:	f9401aa0 	ldr	x0, [x21, #48]
    98c8:	b5fff9e0 	cbnz	x0, 9804 <fwp_main_thread+0x2e4>
    98cc:	f94056a0 	ldr	x0, [x21, #168]
    98d0:	b5fff9a0 	cbnz	x0, 9804 <fwp_main_thread+0x2e4>
    98d4:	b940caa0 	ldr	w0, [x21, #200]
    98d8:	340001c0 	cbz	w0, 9910 <fwp_main_thread+0x3f0>
    98dc:	93407c14 	sxtw	x20, w0
    98e0:	51000400 	sub	w0, w0, #0x1
    98e4:	d1000a94 	sub	x20, x20, #0x2
    98e8:	910342b6 	add	x22, x21, #0xd0
    98ec:	cb204294 	sub	x20, x20, w0, uxtw
    98f0:	93407c13 	sxtw	x19, w0
    98f4:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    98f8:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    98fc:	b900cab3 	str	w19, [x21, #200]
    9900:	d1000673 	sub	x19, x19, #0x1
    9904:	97ffe403 	bl	2910 <munmap@plt>
    9908:	eb14027f 	cmp	x19, x20
    990c:	54ffff41 	b.ne	98f4 <fwp_main_thread+0x3d4>  // b.any
    9910:	f00000a5 	adrp	x5, 20000 <__data_start>
    9914:	910040a0 	add	x0, x5, #0x10
    9918:	b9401000 	ldr	w0, [x0, #16]
    991c:	37f800c0 	tbnz	w0, #31, 9934 <fwp_main_thread+0x414>
    9920:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9924:	f91f7c25 	str	x5, [x1, #16120]
    9928:	97ffe3b6 	bl	2800 <close@plt>
    992c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9930:	f95f7c05 	ldr	x5, [x0, #16120]
    9934:	f00000a0 	adrp	x0, 20000 <__data_start>
    9938:	91010000 	add	x0, x0, #0x40
    993c:	910040a5 	add	x5, x5, #0x10
    9940:	12800001 	mov	w1, #0xffffffff            	// #-1
    9944:	d2800013 	mov	x19, #0x0                   	// #0
    9948:	f9419c15 	ldr	x21, [x0, #824]
    994c:	b90010a1 	str	w1, [x5, #16]
    9950:	f941a014 	ldr	x20, [x0, #832]
    9954:	b4000175 	cbz	x21, 9980 <fwp_main_thread+0x460>
    9958:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    995c:	b40000c0 	cbz	x0, 9974 <fwp_main_thread+0x454>
    9960:	f9400001 	ldr	x1, [x0]
    9964:	b5fff501 	cbnz	x1, 9804 <fwp_main_thread+0x2e4>
    9968:	f9400401 	ldr	x1, [x0, #8]
    996c:	b5fff4c1 	cbnz	x1, 9804 <fwp_main_thread+0x2e4>
    9970:	97ffeb94 	bl	47c0 <fwp_mem_free>
    9974:	91000673 	add	x19, x19, #0x1
    9978:	eb1302bf 	cmp	x21, x19
    997c:	54fffee1 	b.ne	9958 <fwp_main_thread+0x438>  // b.any
    9980:	aa1403e0 	mov	x0, x20
    9984:	97ffeb8f 	bl	47c0 <fwp_mem_free>
    9988:	f00000a0 	adrp	x0, 20000 <__data_start>
    998c:	91010000 	add	x0, x0, #0x40
    9990:	f9419813 	ldr	x19, [x0, #816]
    9994:	f9019c1f 	str	xzr, [x0, #824]
    9998:	f901a01f 	str	xzr, [x0, #832]
    999c:	b40001f3 	cbz	x19, 99d8 <fwp_main_thread+0x4b8>
    99a0:	f9401661 	ldr	x1, [x19, #40]
    99a4:	b5fff301 	cbnz	x1, 9804 <fwp_main_thread+0x2e4>
    99a8:	f9405661 	ldr	x1, [x19, #168]
    99ac:	b5fff2c1 	cbnz	x1, 9804 <fwp_main_thread+0x2e4>
    99b0:	f9417c01 	ldr	x1, [x0, #760]
    99b4:	b5fff281 	cbnz	x1, 9804 <fwp_main_thread+0x2e4>
    99b8:	f9418400 	ldr	x0, [x0, #776]
    99bc:	b5fff240 	cbnz	x0, 9804 <fwp_main_thread+0x2e4>
    99c0:	d2823a02 	mov	x2, #0x11d0                	// #4560
    99c4:	f0000120 	adrp	x0, 30000 <alt.9+0xfc70>
    99c8:	910e4000 	add	x0, x0, #0x390
    99cc:	97ffe37d 	bl	27c0 <memset@plt>
    99d0:	aa1303e0 	mov	x0, x19
    99d4:	97ffeb7b 	bl	47c0 <fwp_mem_free>
    99d8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    99dc:	f947ec00 	ldr	x0, [x0, #4056]
    99e0:	f00000a1 	adrp	x1, 20000 <__data_start>
    99e4:	91010021 	add	x1, x1, #0x40
    99e8:	f9400000 	ldr	x0, [x0]
    99ec:	f900083f 	str	xzr, [x1, #16]
    99f0:	f901983f 	str	xzr, [x1, #816]
    99f4:	97ffe3cb 	bl	2920 <fflush@plt>
    99f8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    99fc:	f947f400 	ldr	x0, [x0, #4072]
    9a00:	f85f83a2 	ldur	x2, [x29, #-8]
    9a04:	f9400001 	ldr	x1, [x0]
    9a08:	eb010042 	subs	x2, x2, x1
    9a0c:	d2800001 	mov	x1, #0x0                   	// #0
    9a10:	54008261 	b.ne	aa5c <fwp_main_thread+0x153c>  // b.any
    9a14:	910003bf 	mov	sp, x29
    9a18:	d2800000 	mov	x0, #0x0                   	// #0
    9a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    9a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9a24:	a94363f7 	ldp	x23, x24, [sp, #48]
    9a28:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9a2c:	a94573fb 	ldp	x27, x28, [sp, #80]
    9a30:	fd4033e8 	ldr	d8, [sp, #96]
    9a34:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9a38:	d65f03c0 	ret
    9a3c:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9a40:	91328000 	add	x0, x0, #0xca0
    9a44:	9400061b 	bl	b2b0 <atexit>
    9a48:	17fffecc 	b	9578 <fwp_main_thread+0x58>
    9a4c:	97ffe8ee 	bl	3e04 <fwp_heap_init>
    9a50:	17fffec6 	b	9568 <fwp_main_thread+0x48>
    9a54:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9a58:	9115c013 	add	x19, x0, #0x570
    9a5c:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9a60:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9a64:	f9417322 	ldr	x2, [x25, #736]
    9a68:	913b4021 	add	x1, x1, #0xed0
    9a6c:	fd47c808 	ldr	d8, [x0, #3984]
    9a70:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x8c>
    9a74:	91220000 	add	x0, x0, #0x880
    9a78:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9a7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9a80:	d2800015 	mov	x21, #0x0                   	// #0
    9a84:	d280401a 	mov	x26, #0x200                 	// #512
    9a88:	d2800014 	mov	x20, #0x0                   	// #0
    9a8c:	52800037 	mov	w23, #0x1                   	// #1
    9a90:	a93087a2 	stp	x2, x1, [x29, #-248]
    9a94:	a931ffbb 	stp	x27, xzr, [x29, #-232]
    9a98:	f9017338 	str	x24, [x25, #736]
    9a9c:	f91f7816 	str	x22, [x0, #16112]
    9aa0:	f91f7c1b 	str	x27, [x0, #16120]
    9aa4:	b953a660 	ldr	w0, [x19, #5028]
    9aa8:	f1000759 	subs	x25, x26, #0x1
    9aac:	f81283b9 	stur	x25, [x29, #-216]
    9ab0:	da1f0296 	sbc	x22, x20, xzr
    9ab4:	aa1903fa 	mov	x26, x25
    9ab8:	aa1603f4 	mov	x20, x22
    9abc:	34003b20 	cbz	w0, a220 <fwp_main_thread+0xd00>
    9ac0:	397e8a60 	ldrb	w0, [x19, #4002]
    9ac4:	910f0001 	add	x1, x0, #0x3c0
    9ac8:	8b000400 	add	x0, x0, x0, lsl #1
    9acc:	b8617a7b 	ldr	w27, [x19, x1, lsl #2]
    9ad0:	8b000e61 	add	x1, x19, x0, lsl #3
    9ad4:	f8607a78 	ldr	x24, [x19, x0, lsl #3]
    9ad8:	2a1b03fc 	mov	w28, w27
    9adc:	b4003918 	cbz	x24, a1fc <fwp_main_thread+0xcdc>
    9ae0:	f9400301 	ldr	x1, [x24]
    9ae4:	aa2103e1 	mvn	x1, x1
    9ae8:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9aec:	f100639f 	cmp	x28, #0x18
    9af0:	540000e9 	b.ls	9b0c <fwp_main_thread+0x5ec>  // b.plast
    9af4:	d1006782 	sub	x2, x28, #0x19
    9af8:	91006300 	add	x0, x24, #0x18
    9afc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9b00:	52800001 	mov	w1, #0x0                   	// #0
    9b04:	91002042 	add	x2, x2, #0x8
    9b08:	97ffe32e 	bl	27c0 <memset@plt>
    9b0c:	f94a1260 	ldr	x0, [x19, #5152]
    9b10:	ab1c0000 	adds	x0, x0, x28
    9b14:	540079c2 	b.cs	aa4c <fwp_main_thread+0x152c>  // b.hs, b.nlast
    9b18:	f94a1661 	ldr	x1, [x19, #5160]
    9b1c:	f90a1260 	str	x0, [x19, #5152]
    9b20:	eb01001f 	cmp	x0, x1
    9b24:	54000049 	b.ls	9b2c <fwp_main_thread+0x60c>  // b.plast
    9b28:	f90a1660 	str	x0, [x19, #5160]
    9b2c:	1e630361 	ucvtf	d1, w27
    9b30:	fd4a1e60 	ldr	d0, [x19, #5176]
    9b34:	1e612800 	fadd	d0, d0, d1
    9b38:	fd0a1e60 	str	d0, [x19, #5176]
    9b3c:	a900d719 	stp	x25, x21, [x24, #8]
    9b40:	aa1803f5 	mov	x21, x24
    9b44:	fd000308 	str	d8, [x24]
    9b48:	f949da62 	ldr	x2, [x19, #5040]
    9b4c:	f949ee60 	ldr	x0, [x19, #5080]
    9b50:	cb020302 	sub	x2, x24, x2
    9b54:	eb00405f 	cmp	x2, x0, lsl #16
    9b58:	54000302 	b.cs	9bb8 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9b5c:	d350fc40 	lsr	x0, x2, #16
    9b60:	f949fe64 	ldr	x4, [x19, #5112]
    9b64:	8b000800 	add	x0, x0, x0, lsl #2
    9b68:	d37df001 	lsl	x1, x0, #3
    9b6c:	8b010080 	add	x0, x4, x1
    9b70:	f940101c 	ldr	x28, [x0, #32]
    9b74:	b400023c 	cbz	x28, 9bb8 <fwp_main_thread+0x698>
    9b78:	38616881 	ldrb	w1, [x4, x1]
    9b7c:	7100083f 	cmp	w1, #0x2
    9b80:	540035a0 	b.eq	a234 <fwp_main_thread+0xd14>  // b.none
    9b84:	7100043f 	cmp	w1, #0x1
    9b88:	54000181 	b.ne	9bb8 <fwp_main_thread+0x698>  // b.any
    9b8c:	29430004 	ldp	w4, w0, [x0, #24]
    9b90:	92403c41 	and	x1, x2, #0xffff
    9b94:	9b047c21 	mul	x1, x1, x4
    9b98:	d360fc21 	lsr	x1, x1, #32
    9b9c:	eb00003f 	cmp	x1, x0
    9ba0:	540000c2 	b.cs	9bb8 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9ba4:	8b01039c 	add	x28, x28, x1
    9ba8:	39400380 	ldrb	w0, [x28]
    9bac:	7103fc1f 	cmp	w0, #0xff
    9bb0:	540034c0 	b.eq	a248 <fwp_main_thread+0xd28>  // b.none
    9bb4:	39000397 	strb	w23, [x28]
    9bb8:	f81203b8 	stur	x24, [x29, #-224]
    9bbc:	aa160339 	orr	x25, x25, x22
    9bc0:	b5fff739 	cbnz	x25, 9aa4 <fwp_main_thread+0x584>
    9bc4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9bc8:	d10303a1 	sub	x1, x29, #0xc0
    9bcc:	f85083a3 	ldur	x3, [x29, #-248]
    9bd0:	f95f7816 	ldr	x22, [x0, #16112]
    9bd4:	f91f7418 	str	x24, [x0, #16104]
    9bd8:	f95f7c1b 	ldr	x27, [x0, #16120]
    9bdc:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9be0:	3dc3e800 	ldr	q0, [x0, #4000]
    9be4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9be8:	91010002 	add	x2, x0, #0x40
    9bec:	52800020 	mov	w0, #0x1                   	// #1
    9bf0:	3c9403a0 	stur	q0, [x29, #-192]
    9bf4:	f9017043 	str	x3, [x2, #736]
    9bf8:	97ffee12 	bl	5440 <fwp_data.part.0.constprop.0>
    9bfc:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9c00:	9115c022 	add	x2, x1, #0x570
    9c04:	aa0003f4 	mov	x20, x0
    9c08:	f949d841 	ldr	x1, [x2, #5040]
    9c0c:	f949ec40 	ldr	x0, [x2, #5080]
    9c10:	cb010281 	sub	x1, x20, x1
    9c14:	eb00403f 	cmp	x1, x0, lsl #16
    9c18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c1c:	f95f7406 	ldr	x6, [x0, #16104]
    9c20:	54000322 	b.cs	9c84 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9c24:	d350fc20 	lsr	x0, x1, #16
    9c28:	f949fc43 	ldr	x3, [x2, #5112]
    9c2c:	8b000800 	add	x0, x0, x0, lsl #2
    9c30:	d37df002 	lsl	x2, x0, #3
    9c34:	8b020060 	add	x0, x3, x2
    9c38:	f9401013 	ldr	x19, [x0, #32]
    9c3c:	b4000253 	cbz	x19, 9c84 <fwp_main_thread+0x764>
    9c40:	38626862 	ldrb	w2, [x3, x2]
    9c44:	7100085f 	cmp	w2, #0x2
    9c48:	54006b60 	b.eq	a9b4 <fwp_main_thread+0x1494>  // b.none
    9c4c:	7100045f 	cmp	w2, #0x1
    9c50:	540001a1 	b.ne	9c84 <fwp_main_thread+0x764>  // b.any
    9c54:	29430002 	ldp	w2, w0, [x0, #24]
    9c58:	92403c21 	and	x1, x1, #0xffff
    9c5c:	9b027c21 	mul	x1, x1, x2
    9c60:	d360fc21 	lsr	x1, x1, #32
    9c64:	eb00003f 	cmp	x1, x0
    9c68:	540000e2 	b.cs	9c84 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9c6c:	8b010273 	add	x19, x19, x1
    9c70:	39400260 	ldrb	w0, [x19]
    9c74:	7103fc1f 	cmp	w0, #0xff
    9c78:	54006b40 	b.eq	a9e0 <fwp_main_thread+0x14c0>  // b.none
    9c7c:	52800020 	mov	w0, #0x1                   	// #1
    9c80:	39000260 	strb	w0, [x19]
    9c84:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9c8c:	aa1603e1 	mov	x1, x22
    9c90:	a93653a2 	stp	x2, x20, [x29, #-160]
    9c94:	f91f7c06 	str	x6, [x0, #16120]
    9c98:	52800020 	mov	w0, #0x1                   	// #1
    9c9c:	97ffede9 	bl	5440 <fwp_data.part.0.constprop.0>
    9ca0:	aa0003f4 	mov	x20, x0
    9ca4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9ca8:	9115c022 	add	x2, x1, #0x570
    9cac:	f949d841 	ldr	x1, [x2, #5040]
    9cb0:	f949ec40 	ldr	x0, [x2, #5080]
    9cb4:	cb010281 	sub	x1, x20, x1
    9cb8:	eb00403f 	cmp	x1, x0, lsl #16
    9cbc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cc0:	f95f7c06 	ldr	x6, [x0, #16120]
    9cc4:	54000322 	b.cs	9d28 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9cc8:	d350fc20 	lsr	x0, x1, #16
    9ccc:	f949fc43 	ldr	x3, [x2, #5112]
    9cd0:	8b000800 	add	x0, x0, x0, lsl #2
    9cd4:	d37df002 	lsl	x2, x0, #3
    9cd8:	8b020060 	add	x0, x3, x2
    9cdc:	f9401013 	ldr	x19, [x0, #32]
    9ce0:	b4000253 	cbz	x19, 9d28 <fwp_main_thread+0x808>
    9ce4:	38626862 	ldrb	w2, [x3, x2]
    9ce8:	7100085f 	cmp	w2, #0x2
    9cec:	540065e0 	b.eq	a9a8 <fwp_main_thread+0x1488>  // b.none
    9cf0:	7100045f 	cmp	w2, #0x1
    9cf4:	540001a1 	b.ne	9d28 <fwp_main_thread+0x808>  // b.any
    9cf8:	29430002 	ldp	w2, w0, [x0, #24]
    9cfc:	92403c21 	and	x1, x1, #0xffff
    9d00:	9b027c21 	mul	x1, x1, x2
    9d04:	d360fc21 	lsr	x1, x1, #32
    9d08:	eb00003f 	cmp	x1, x0
    9d0c:	540000e2 	b.cs	9d28 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9d10:	8b010273 	add	x19, x19, x1
    9d14:	39400260 	ldrb	w0, [x19]
    9d18:	7103fc1f 	cmp	w0, #0xff
    9d1c:	540067c0 	b.eq	aa14 <fwp_main_thread+0x14f4>  // b.none
    9d20:	52800020 	mov	w0, #0x1                   	// #1
    9d24:	39000260 	strb	w0, [x19]
    9d28:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d2c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9d30:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9d34:	d102c3a1 	sub	x1, x29, #0xb0
    9d38:	a93553a2 	stp	x2, x20, [x29, #-176]
    9d3c:	f91f7c06 	str	x6, [x0, #16120]
    9d40:	52800020 	mov	w0, #0x1                   	// #1
    9d44:	97ffedbf 	bl	5440 <fwp_data.part.0.constprop.0>
    9d48:	aa0003f6 	mov	x22, x0
    9d4c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9d50:	9115c023 	add	x3, x1, #0x570
    9d54:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d58:	f949ec62 	ldr	x2, [x3, #5080]
    9d5c:	f949d861 	ldr	x1, [x3, #5040]
    9d60:	d370bc42 	lsl	x2, x2, #16
    9d64:	cb0102c1 	sub	x1, x22, x1
    9d68:	f95f7c06 	ldr	x6, [x0, #16120]
    9d6c:	eb02003f 	cmp	x1, x2
    9d70:	540003e2 	b.cs	9dec <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9d74:	d350fc20 	lsr	x0, x1, #16
    9d78:	f949fc64 	ldr	x4, [x3, #5112]
    9d7c:	8b000800 	add	x0, x0, x0, lsl #2
    9d80:	d37df003 	lsl	x3, x0, #3
    9d84:	8b030080 	add	x0, x4, x3
    9d88:	f9401013 	ldr	x19, [x0, #32]
    9d8c:	b4000313 	cbz	x19, 9dec <fwp_main_thread+0x8cc>
    9d90:	38636883 	ldrb	w3, [x4, x3]
    9d94:	7100087f 	cmp	w3, #0x2
    9d98:	540061a0 	b.eq	a9cc <fwp_main_thread+0x14ac>  // b.none
    9d9c:	7100047f 	cmp	w3, #0x1
    9da0:	54000261 	b.ne	9dec <fwp_main_thread+0x8cc>  // b.any
    9da4:	29430004 	ldp	w4, w0, [x0, #24]
    9da8:	92403c23 	and	x3, x1, #0xffff
    9dac:	9b047c63 	mul	x3, x3, x4
    9db0:	d360fc63 	lsr	x3, x3, #32
    9db4:	eb00007f 	cmp	x3, x0
    9db8:	540001a2 	b.cs	9dec <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9dbc:	8b030273 	add	x19, x19, x3
    9dc0:	39400260 	ldrb	w0, [x19]
    9dc4:	7103fc1f 	cmp	w0, #0xff
    9dc8:	54006340 	b.eq	aa30 <fwp_main_thread+0x1510>  // b.none
    9dcc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9dd0:	9115c000 	add	x0, x0, #0x570
    9dd4:	52800021 	mov	w1, #0x1                   	// #1
    9dd8:	39000261 	strb	w1, [x19]
    9ddc:	f949ec02 	ldr	x2, [x0, #5080]
    9de0:	f949d801 	ldr	x1, [x0, #5040]
    9de4:	d370bc42 	lsl	x2, x2, #16
    9de8:	cb0102c1 	sub	x1, x22, x1
    9dec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9df0:	f00000a5 	adrp	x5, 20000 <__data_start>
    9df4:	910040b7 	add	x23, x5, #0x10
    9df8:	d10403b3 	sub	x19, x29, #0x100
    9dfc:	910022f7 	add	x23, x23, #0x8
    9e00:	f91f5406 	str	x6, [x0, #16040]
    9e04:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e08:	9101001c 	add	x28, x0, #0x40
    9e0c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e10:	f91f4c06 	str	x6, [x0, #16024]
    9e14:	aa1703e6 	mov	x6, x23
    9e18:	f91f5005 	str	x5, [x0, #16032]
    9e1c:	f91f581b 	str	x27, [x0, #16048]
    9e20:	f91f5c16 	str	x22, [x0, #16056]
    9e24:	eb02003f 	cmp	x1, x2
    9e28:	54000382 	b.cs	9e98 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9e2c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9e30:	9115c002 	add	x2, x0, #0x570
    9e34:	d350fc20 	lsr	x0, x1, #16
    9e38:	f949fc44 	ldr	x4, [x2, #5112]
    9e3c:	8b000800 	add	x0, x0, x0, lsl #2
    9e40:	d37df002 	lsl	x2, x0, #3
    9e44:	8b020083 	add	x3, x4, x2
    9e48:	f9401060 	ldr	x0, [x3, #32]
    9e4c:	b4000260 	cbz	x0, 9e98 <fwp_main_thread+0x978>
    9e50:	38626882 	ldrb	w2, [x4, x2]
    9e54:	7100085f 	cmp	w2, #0x2
    9e58:	54005b40 	b.eq	a9c0 <fwp_main_thread+0x14a0>  // b.none
    9e5c:	7100045f 	cmp	w2, #0x1
    9e60:	540001c1 	b.ne	9e98 <fwp_main_thread+0x978>  // b.any
    9e64:	29430864 	ldp	w4, w2, [x3, #24]
    9e68:	92403c21 	and	x1, x1, #0xffff
    9e6c:	9b047c21 	mul	x1, x1, x4
    9e70:	d360fc21 	lsr	x1, x1, #32
    9e74:	eb02003f 	cmp	x1, x2
    9e78:	54000102 	b.cs	9e98 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9e7c:	8b010000 	add	x0, x0, x1
    9e80:	39400001 	ldrb	w1, [x0]
    9e84:	340000a1 	cbz	w1, 9e98 <fwp_main_thread+0x978>
    9e88:	7103f43f 	cmp	w1, #0xfd
    9e8c:	54005b88 	b.hi	a9fc <fwp_main_thread+0x14dc>  // b.pmore
    9e90:	11000421 	add	w1, w1, #0x1
    9e94:	39000001 	strb	w1, [x0]
    9e98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e9c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9ea0:	f9401f83 	ldr	x3, [x28, #56]
    9ea4:	f95f5000 	ldr	x0, [x0, #16032]
    9ea8:	f95f5c21 	ldr	x1, [x1, #16056]
    9eac:	91004000 	add	x0, x0, #0x10
    9eb0:	f81003a1 	stur	x1, [x29, #-256]
    9eb4:	91002004 	add	x4, x0, #0x8
    9eb8:	b9400801 	ldr	w1, [x0, #8]
    9ebc:	d37be821 	lsl	x1, x1, #5
    9ec0:	8b010065 	add	x5, x3, x1
    9ec4:	f9400ca2 	ldr	x2, [x5, #24]
    9ec8:	b4005cc2 	cbz	x2, aa60 <fwp_main_thread+0x1540>
    9ecc:	f9400c40 	ldr	x0, [x2, #24]
    9ed0:	b4004880 	cbz	x0, a7e0 <fwp_main_thread+0x12c0>
    9ed4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc70>
    9ed8:	9115c002 	add	x2, x0, #0x570
    9edc:	f949d841 	ldr	x1, [x2, #5040]
    9ee0:	f949ec40 	ldr	x0, [x2, #5080]
    9ee4:	cb0100c1 	sub	x1, x6, x1
    9ee8:	eb00403f 	cmp	x1, x0, lsl #16
    9eec:	54000342 	b.cs	9f54 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9ef0:	d350fc20 	lsr	x0, x1, #16
    9ef4:	f949fc44 	ldr	x4, [x2, #5112]
    9ef8:	8b000800 	add	x0, x0, x0, lsl #2
    9efc:	d37df002 	lsl	x2, x0, #3
    9f00:	8b020083 	add	x3, x4, x2
    9f04:	f9401060 	ldr	x0, [x3, #32]
    9f08:	b4000260 	cbz	x0, 9f54 <fwp_main_thread+0xa34>
    9f0c:	38626882 	ldrb	w2, [x4, x2]
    9f10:	7100085f 	cmp	w2, #0x2
    9f14:	54004dc0 	b.eq	a8cc <fwp_main_thread+0x13ac>  // b.none
    9f18:	7100045f 	cmp	w2, #0x1
    9f1c:	540001c1 	b.ne	9f54 <fwp_main_thread+0xa34>  // b.any
    9f20:	29430864 	ldp	w4, w2, [x3, #24]
    9f24:	92403c21 	and	x1, x1, #0xffff
    9f28:	9b047c21 	mul	x1, x1, x4
    9f2c:	d360fc21 	lsr	x1, x1, #32
    9f30:	eb02003f 	cmp	x1, x2
    9f34:	54000102 	b.cs	9f54 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9f38:	8b010000 	add	x0, x0, x1
    9f3c:	39400001 	ldrb	w1, [x0]
    9f40:	340000a1 	cbz	w1, 9f54 <fwp_main_thread+0xa34>
    9f44:	7103f43f 	cmp	w1, #0xfd
    9f48:	540050c8 	b.hi	a960 <fwp_main_thread+0x1440>  // b.pmore
    9f4c:	11000421 	add	w1, w1, #0x1
    9f50:	39000001 	strb	w1, [x0]
    9f54:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc70>
    9f58:	9115c035 	add	x21, x1, #0x570
    9f5c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9f60:	aa0603f8 	mov	x24, x6
    9f64:	aa1303fb 	mov	x27, x19
    9f68:	aa0603e0 	mov	x0, x6
    9f6c:	52800034 	mov	w20, #0x1                   	// #1
    9f70:	f91f6033 	str	x19, [x1, #16064]
    9f74:	f91f6426 	str	x6, [x1, #16072]
    9f78:	b93ee834 	str	w20, [x1, #16104]
    9f7c:	b93ef034 	str	w20, [x1, #16112]
    9f80:	b94000a2 	ldr	w2, [x5]
    9f84:	b9400401 	ldr	w1, [x0, #4]
    9f88:	4b010040 	sub	w0, w2, w1
    9f8c:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    9f90:	b93ee440 	str	w0, [x2, #16100]
    9f94:	b97ee842 	ldr	w2, [x2, #16104]
    9f98:	6b02001f 	cmp	w0, w2
    9f9c:	1a829019 	csel	w25, w0, w2, ls	// ls = plast
    9fa0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9fa4:	b97ef000 	ldr	w0, [x0, #16112]
    9fa8:	6b00033f 	cmp	w25, w0
    9fac:	1a809336 	csel	w22, w25, w0, ls	// ls = plast
    9fb0:	6b160322 	subs	w2, w25, w22
    9fb4:	540000c0 	b.eq	9fcc <fwp_main_thread+0xaac>  // b.none
    9fb8:	f9400ca4 	ldr	x4, [x5, #24]
    9fbc:	0b160021 	add	w1, w1, w22
    9fc0:	8b364f60 	add	x0, x27, w22, uxtw #3
    9fc4:	f9400884 	ldr	x4, [x4, #16]
    9fc8:	d63f0080 	blr	x4
    9fcc:	f9401f80 	ldr	x0, [x28, #56]
    9fd0:	aa1803e7 	mov	x7, x24
    9fd4:	b9400304 	ldr	w4, [x24]
    9fd8:	aa1b03fa 	mov	x26, x27
    9fdc:	2a1903f7 	mov	w23, w25
    9fe0:	aa1803e9 	mov	x9, x24
    9fe4:	8b041404 	add	x4, x0, x4, lsl #5
    9fe8:	f9400c88 	ldr	x8, [x4, #24]
    9fec:	b4001488 	cbz	x8, a27c <fwp_main_thread+0xd5c>
    9ff0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ff4:	aa0403f4 	mov	x20, x4
    9ff8:	f91f681b 	str	x27, [x0, #16080]
    9ffc:	b93ed816 	str	w22, [x0, #16088]
    a000:	b93ee019 	str	w25, [x0, #16096]
    a004:	14000012 	b	a04c <fwp_main_thread+0xb2c>
    a008:	f9400101 	ldr	x1, [x8]
    a00c:	aa1a03e0 	mov	x0, x26
    a010:	d63f0020 	blr	x1
    a014:	aa0003fb 	mov	x27, x0
    a018:	aa1803e0 	mov	x0, x24
    a01c:	97ffee6d 	bl	59d0 <fwp_closure_drop>
    a020:	6b1702df 	cmp	w22, w23
    a024:	54000d00 	b.eq	a1c4 <fwp_main_thread+0xca4>  // b.none
    a028:	f9401f80 	ldr	x0, [x28, #56]
    a02c:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a030:	b9400364 	ldr	w4, [x27]
    a034:	4b130337 	sub	w23, w25, w19
    a038:	aa1b03e7 	mov	x7, x27
    a03c:	8b041414 	add	x20, x0, x4, lsl #5
    a040:	f9400e88 	ldr	x8, [x20, #24]
    a044:	b4001128 	cbz	x8, a268 <fwp_main_thread+0xd48>
    a048:	aa1b03f8 	mov	x24, x27
    a04c:	b94004e9 	ldr	w9, [x7, #4]
    a050:	b9400293 	ldr	w19, [x20]
    a054:	0b170139 	add	w25, w9, w23
    a058:	6b19027f 	cmp	w19, w25
    a05c:	54002a28 	b.hi	a5a0 <fwp_main_thread+0x1080>  // b.pmore
    a060:	7100013f 	cmp	w9, #0x0
    a064:	4b090276 	sub	w22, w19, w9
    a068:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a06c:	54fffce1 	b.ne	a008 <fwp_main_thread+0xae8>  // b.any
    a070:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a074:	910003e0 	mov	x0, sp
    a078:	7100027f 	cmp	w19, #0x0
    a07c:	f91f7c20 	str	x0, [x1, #16120]
    a080:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a084:	d37df000 	lsl	x0, x0, #3
    a088:	91003c00 	add	x0, x0, #0xf
    a08c:	92704c01 	and	x1, x0, #0xfffff0000
    a090:	927c7c00 	and	x0, x0, #0xffffffff0
    a094:	cb2163e1 	sub	x1, sp, x1
    a098:	eb2163ff 	cmp	sp, x1
    a09c:	540000a0 	b.eq	a0b0 <fwp_main_thread+0xb90>  // b.none
    a0a0:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a0a4:	f90203ff 	str	xzr, [sp, #1024]
    a0a8:	eb2163ff 	cmp	sp, x1
    a0ac:	54ffffa1 	b.ne	a0a0 <fwp_main_thread+0xb80>  // b.any
    a0b0:	92403c00 	and	x0, x0, #0xffff
    a0b4:	cb2063ff 	sub	sp, sp, x0
    a0b8:	f90003ff 	str	xzr, [sp]
    a0bc:	f110001f 	cmp	x0, #0x400
    a0c0:	54000043 	b.cc	a0c8 <fwp_main_thread+0xba8>  // b.lo, b.ul, b.last
    a0c4:	f90203ff 	str	xzr, [sp, #1024]
    a0c8:	910043fb 	add	x27, sp, #0x10
    a0cc:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a0d0:	910020e1 	add	x1, x7, #0x8
    a0d4:	d2800000 	mov	x0, #0x0                   	// #0
    a0d8:	340000e9 	cbz	w9, a0f4 <fwp_main_thread+0xbd4>
    a0dc:	d503201f 	nop
    a0e0:	f8606823 	ldr	x3, [x1, x0]
    a0e4:	f8206b63 	str	x3, [x27, x0]
    a0e8:	91002000 	add	x0, x0, #0x8
    a0ec:	eb02001f 	cmp	x0, x2
    a0f0:	54ffff81 	b.ne	a0e0 <fwp_main_thread+0xbc0>  // b.any
    a0f4:	2a1603e1 	mov	w1, w22
    a0f8:	d2800000 	mov	x0, #0x0                   	// #0
    a0fc:	340000f6 	cbz	w22, a118 <fwp_main_thread+0xbf8>
    a100:	0b000122 	add	w2, w9, w0
    a104:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a108:	91000400 	add	x0, x0, #0x1
    a10c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a110:	eb01001f 	cmp	x0, x1
    a114:	54ffff61 	b.ne	a100 <fwp_main_thread+0xbe0>  // b.any
    a118:	f949daa0 	ldr	x0, [x21, #5040]
    a11c:	f949eea1 	ldr	x1, [x21, #5080]
    a120:	cb000300 	sub	x0, x24, x0
    a124:	eb01401f 	cmp	x0, x1, lsl #16
    a128:	540002e2 	b.cs	a184 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a12c:	d350fc01 	lsr	x1, x0, #16
    a130:	f949fea5 	ldr	x5, [x21, #5112]
    a134:	8b010821 	add	x1, x1, x1, lsl #2
    a138:	d37df021 	lsl	x1, x1, #3
    a13c:	8b0100a3 	add	x3, x5, x1
    a140:	f9401062 	ldr	x2, [x3, #32]
    a144:	b4000202 	cbz	x2, a184 <fwp_main_thread+0xc64>
    a148:	386168a1 	ldrb	w1, [x5, x1]
    a14c:	7100083f 	cmp	w1, #0x2
    a150:	54000860 	b.eq	a25c <fwp_main_thread+0xd3c>  // b.none
    a154:	7100043f 	cmp	w1, #0x1
    a158:	54000161 	b.ne	a184 <fwp_main_thread+0xc64>  // b.any
    a15c:	29430465 	ldp	w5, w1, [x3, #24]
    a160:	92403c00 	and	x0, x0, #0xffff
    a164:	9b057c00 	mul	x0, x0, x5
    a168:	d360fc00 	lsr	x0, x0, #32
    a16c:	eb01001f 	cmp	x0, x1
    a170:	540000a2 	b.cs	a184 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a174:	8b000042 	add	x2, x2, x0
    a178:	39400040 	ldrb	w0, [x2]
    a17c:	7100041f 	cmp	w0, #0x1
    a180:	540006a0 	b.eq	a254 <fwp_main_thread+0xd34>  // b.none
    a184:	f9400502 	ldr	x2, [x8, #8]
    a188:	aa1803e0 	mov	x0, x24
    a18c:	52800021 	mov	w1, #0x1                   	// #1
    a190:	d63f0040 	blr	x2
    a194:	f9400e81 	ldr	x1, [x20, #24]
    a198:	aa1b03e0 	mov	x0, x27
    a19c:	f9400021 	ldr	x1, [x1]
    a1a0:	d63f0020 	blr	x1
    a1a4:	aa0003fb 	mov	x27, x0
    a1a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1ac:	f95f7c00 	ldr	x0, [x0, #16120]
    a1b0:	9100001f 	mov	sp, x0
    a1b4:	aa1803e0 	mov	x0, x24
    a1b8:	97ffee06 	bl	59d0 <fwp_closure_drop>
    a1bc:	6b1702df 	cmp	w22, w23
    a1c0:	54fff341 	b.ne	a028 <fwp_main_thread+0xb08>  // b.any
    a1c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1c8:	aa1b03f8 	mov	x24, x27
    a1cc:	f95f681b 	ldr	x27, [x0, #16080]
    a1d0:	b97ed816 	ldr	w22, [x0, #16088]
    a1d4:	b97ee019 	ldr	w25, [x0, #16096]
    a1d8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1dc:	b97ee401 	ldr	w1, [x0, #16100]
    a1e0:	b97ee800 	ldr	w0, [x0, #16104]
    a1e4:	6b00003f 	cmp	w1, w0
    a1e8:	540007e3 	b.cc	a2e4 <fwp_main_thread+0xdc4>  // b.lo, b.ul, b.last
    a1ec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1f0:	f95f6013 	ldr	x19, [x0, #16064]
    a1f4:	f95f6406 	ldr	x6, [x0, #16072]
    a1f8:	14000063 	b	a384 <fwp_main_thread+0xe64>
    a1fc:	f9400438 	ldr	x24, [x1, #8]
    a200:	b4000118 	cbz	x24, a220 <fwp_main_thread+0xd00>
    a204:	f9400820 	ldr	x0, [x1, #16]
    a208:	cb180000 	sub	x0, x0, x24
    a20c:	eb00039f 	cmp	x28, x0
    a210:	54000088 	b.hi	a220 <fwp_main_thread+0xd00>  // b.pmore
    a214:	8b1c0300 	add	x0, x24, x28
    a218:	f9000420 	str	x0, [x1, #8]
    a21c:	17fffe34 	b	9aec <fwp_main_thread+0x5cc>
    a220:	52800001 	mov	w1, #0x0                   	// #0
    a224:	d2800300 	mov	x0, #0x18                  	// #24
    a228:	97ffea86 	bl	4c40 <fwp_heap_alloc>
    a22c:	aa0003f8 	mov	x24, x0
    a230:	17fffe43 	b	9b3c <fwp_main_thread+0x61c>
    a234:	72003c5f 	tst	w2, #0xffff
    a238:	54ffcc01 	b.ne	9bb8 <fwp_main_thread+0x698>  // b.any
    a23c:	39400380 	ldrb	w0, [x28]
    a240:	7103fc1f 	cmp	w0, #0xff
    a244:	54ffcb81 	b.ne	9bb4 <fwp_main_thread+0x694>  // b.any
    a248:	aa1c03e0 	mov	x0, x28
    a24c:	97ffe8bd 	bl	4540 <fwp_rc_forget_slot>
    a250:	17fffe59 	b	9bb4 <fwp_main_thread+0x694>
    a254:	b90004ff 	str	wzr, [x7, #4]
    a258:	17ffffcf 	b	a194 <fwp_main_thread+0xc74>
    a25c:	72003c1f 	tst	w0, #0xffff
    a260:	54fff921 	b.ne	a184 <fwp_main_thread+0xc64>  // b.any
    a264:	17ffffc5 	b	a178 <fwp_main_thread+0xc58>
    a268:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a26c:	aa1b03e9 	mov	x9, x27
    a270:	f95f681b 	ldr	x27, [x0, #16080]
    a274:	b97ed816 	ldr	w22, [x0, #16088]
    a278:	b97ee019 	ldr	w25, [x0, #16096]
    a27c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a280:	aa0903e0 	mov	x0, x9
    a284:	f91f7c29 	str	x9, [x1, #16120]
    a288:	97ffecb6 	bl	5560 <fwp_rc_share>
    a28c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a290:	f95f7c09 	ldr	x9, [x0, #16120]
    a294:	34000157 	cbz	w23, a2bc <fwp_main_thread+0xd9c>
    a298:	8b374f53 	add	x19, x26, w23, uxtw #3
    a29c:	aa1a03f4 	mov	x20, x26
    a2a0:	aa0903f8 	mov	x24, x9
    a2a4:	d503201f 	nop
    a2a8:	f8408680 	ldr	x0, [x20], #8
    a2ac:	97ffecad 	bl	5560 <fwp_rc_share>
    a2b0:	eb13029f 	cmp	x20, x19
    a2b4:	54ffffa1 	b.ne	a2a8 <fwp_main_thread+0xd88>  // b.any
    a2b8:	aa1803e9 	mov	x9, x24
    a2bc:	aa1a03e2 	mov	x2, x26
    a2c0:	2a1703e1 	mov	w1, w23
    a2c4:	aa0903e0 	mov	x0, x9
    a2c8:	97ffeaa3 	bl	4d54 <fwp_apply>
    a2cc:	aa0003f8 	mov	x24, x0
    a2d0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2d4:	b97ee401 	ldr	w1, [x0, #16100]
    a2d8:	b97ee800 	ldr	w0, [x0, #16104]
    a2dc:	6b00003f 	cmp	w1, w0
    a2e0:	54fff862 	b.cs	a1ec <fwp_main_thread+0xccc>  // b.hs, b.nlast
    a2e4:	f9401f81 	ldr	x1, [x28, #56]
    a2e8:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a2ec:	b9400305 	ldr	w5, [x24]
    a2f0:	4b190000 	sub	w0, w0, w25
    a2f4:	8b394f7b 	add	x27, x27, w25, uxtw #3
    a2f8:	b93ee840 	str	w0, [x2, #16104]
    a2fc:	8b051425 	add	x5, x1, x5, lsl #5
    a300:	b97ef040 	ldr	w0, [x2, #16112]
    a304:	4b160000 	sub	w0, w0, w22
    a308:	b93ef040 	str	w0, [x2, #16112]
    a30c:	f9400ca1 	ldr	x1, [x5, #24]
    a310:	aa1803e0 	mov	x0, x24
    a314:	b5ffe361 	cbnz	x1, 9f80 <fwp_main_thread+0xa60>
    a318:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a31c:	f95f6406 	ldr	x6, [x0, #16072]
    a320:	f91f7c06 	str	x6, [x0, #16120]
    a324:	f95f6013 	ldr	x19, [x0, #16064]
    a328:	b97ee814 	ldr	w20, [x0, #16104]
    a32c:	aa1803e0 	mov	x0, x24
    a330:	97ffec8c 	bl	5560 <fwp_rc_share>
    a334:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a338:	f95f7c06 	ldr	x6, [x0, #16120]
    a33c:	34000134 	cbz	w20, a360 <fwp_main_thread+0xe40>
    a340:	aa0603fa 	mov	x26, x6
    a344:	d2800015 	mov	x21, #0x0                   	// #0
    a348:	f8757b60 	ldr	x0, [x27, x21, lsl #3]
    a34c:	910006b5 	add	x21, x21, #0x1
    a350:	97ffec84 	bl	5560 <fwp_rc_share>
    a354:	6b15029f 	cmp	w20, w21
    a358:	54ffff88 	b.hi	a348 <fwp_main_thread+0xe28>  // b.pmore
    a35c:	aa1a03e6 	mov	x6, x26
    a360:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a364:	aa1b03e2 	mov	x2, x27
    a368:	2a1403e1 	mov	w1, w20
    a36c:	f91f7c06 	str	x6, [x0, #16120]
    a370:	aa1803e0 	mov	x0, x24
    a374:	97ffea78 	bl	4d54 <fwp_apply>
    a378:	aa0003f8 	mov	x24, x0
    a37c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a380:	f95f7c06 	ldr	x6, [x0, #16120]
    a384:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a388:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10ca8>
    a38c:	91102042 	add	x2, x2, #0x408
    a390:	91014042 	add	x2, x2, #0x50
    a394:	aa1803e1 	mov	x1, x24
    a398:	f91f7c06 	str	x6, [x0, #16120]
    a39c:	52800023 	mov	w3, #0x1                   	// #1
    a3a0:	f95f5800 	ldr	x0, [x0, #16048]
    a3a4:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a3a8:	f81303bf 	stur	xzr, [x29, #-208]
    a3ac:	97fff861 	bl	8530 <fwp_write>
    a3b0:	a9726bb5 	ldp	x21, x26, [x29, #-224]
    a3b4:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a3b8:	91336000 	add	x0, x0, #0xcd8
    a3bc:	f10002bf 	cmp	x21, #0x0
    a3c0:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a3c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3c8:	b1002b5f 	cmn	x26, #0xa
    a3cc:	f95f7c06 	ldr	x6, [x0, #16120]
    a3d0:	54003628 	b.hi	aa94 <fwp_main_thread+0x1574>  // b.pmore
    a3d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3d8:	52800021 	mov	w1, #0x1                   	// #1
    a3dc:	f91f7c06 	str	x6, [x0, #16120]
    a3e0:	91002740 	add	x0, x26, #0x9
    a3e4:	97ffea17 	bl	4c40 <fwp_heap_alloc>
    a3e8:	aa0003f4 	mov	x20, x0
    a3ec:	aa1503e1 	mov	x1, x21
    a3f0:	aa0003f5 	mov	x21, x0
    a3f4:	aa1a03e2 	mov	x2, x26
    a3f8:	f80086ba 	str	x26, [x21], #8
    a3fc:	8b1a029a 	add	x26, x20, x26
    a400:	aa1503e0 	mov	x0, x21
    a404:	97ffe08f 	bl	2640 <memcpy@plt>
    a408:	3900235f 	strb	wzr, [x26, #8]
    a40c:	f85203a0 	ldur	x0, [x29, #-224]
    a410:	97ffe128 	bl	28b0 <free@plt>
    a414:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a418:	9115c002 	add	x2, x0, #0x570
    a41c:	f949d841 	ldr	x1, [x2, #5040]
    a420:	f949ec40 	ldr	x0, [x2, #5080]
    a424:	cb010281 	sub	x1, x20, x1
    a428:	eb00403f 	cmp	x1, x0, lsl #16
    a42c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a430:	f95f7c06 	ldr	x6, [x0, #16120]
    a434:	54000322 	b.cs	a498 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a438:	d350fc20 	lsr	x0, x1, #16
    a43c:	f949fc43 	ldr	x3, [x2, #5112]
    a440:	8b000800 	add	x0, x0, x0, lsl #2
    a444:	d37df002 	lsl	x2, x0, #3
    a448:	8b020060 	add	x0, x3, x2
    a44c:	f940101a 	ldr	x26, [x0, #32]
    a450:	b400025a 	cbz	x26, a498 <fwp_main_thread+0xf78>
    a454:	38626862 	ldrb	w2, [x3, x2]
    a458:	7100085f 	cmp	w2, #0x2
    a45c:	54003480 	b.eq	aaec <fwp_main_thread+0x15cc>  // b.none
    a460:	7100045f 	cmp	w2, #0x1
    a464:	540001a1 	b.ne	a498 <fwp_main_thread+0xf78>  // b.any
    a468:	29430002 	ldp	w2, w0, [x0, #24]
    a46c:	92403c21 	and	x1, x1, #0xffff
    a470:	9b027c21 	mul	x1, x1, x2
    a474:	d360fc21 	lsr	x1, x1, #32
    a478:	eb00003f 	cmp	x1, x0
    a47c:	540000e2 	b.cs	a498 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a480:	8b01035a 	add	x26, x26, x1
    a484:	39400340 	ldrb	w0, [x26]
    a488:	7103fc1f 	cmp	w0, #0xff
    a48c:	54003800 	b.eq	ab8c <fwp_main_thread+0x166c>  // b.none
    a490:	52800020 	mov	w0, #0x1                   	// #1
    a494:	39000340 	strb	w0, [x26]
    a498:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a49c:	f91f7c06 	str	x6, [x0, #16120]
    a4a0:	aa1803e0 	mov	x0, x24
    a4a4:	97ffec9c 	bl	5714 <fwp_drop0>
    a4a8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a4ac:	91010003 	add	x3, x0, #0x40
    a4b0:	f9400282 	ldr	x2, [x20]
    a4b4:	aa1503e0 	mov	x0, x21
    a4b8:	aa0303f5 	mov	x21, x3
    a4bc:	d2800021 	mov	x1, #0x1                   	// #1
    a4c0:	f9400463 	ldr	x3, [x3, #8]
    a4c4:	97ffe10b 	bl	28f0 <fwrite@plt>
    a4c8:	f94006a1 	ldr	x1, [x21, #8]
    a4cc:	52800140 	mov	w0, #0xa                   	// #10
    a4d0:	97ffe090 	bl	2710 <fputc@plt>
    a4d4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a4d8:	9115c002 	add	x2, x0, #0x570
    a4dc:	f949d841 	ldr	x1, [x2, #5040]
    a4e0:	f949ec40 	ldr	x0, [x2, #5080]
    a4e4:	cb010281 	sub	x1, x20, x1
    a4e8:	eb00403f 	cmp	x1, x0, lsl #16
    a4ec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4f0:	f95f7c06 	ldr	x6, [x0, #16120]
    a4f4:	54000382 	b.cs	a564 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a4f8:	d350fc20 	lsr	x0, x1, #16
    a4fc:	f949fc43 	ldr	x3, [x2, #5112]
    a500:	8b000800 	add	x0, x0, x0, lsl #2
    a504:	d37df000 	lsl	x0, x0, #3
    a508:	8b000062 	add	x2, x3, x0
    a50c:	f9401055 	ldr	x21, [x2, #32]
    a510:	b40002b5 	cbz	x21, a564 <fwp_main_thread+0x1044>
    a514:	38606860 	ldrb	w0, [x3, x0]
    a518:	7100081f 	cmp	w0, #0x2
    a51c:	54002e20 	b.eq	aae0 <fwp_main_thread+0x15c0>  // b.none
    a520:	7100041f 	cmp	w0, #0x1
    a524:	54000201 	b.ne	a564 <fwp_main_thread+0x1044>  // b.any
    a528:	29430043 	ldp	w3, w0, [x2, #24]
    a52c:	92403c21 	and	x1, x1, #0xffff
    a530:	9b037c21 	mul	x1, x1, x3
    a534:	d360fc21 	lsr	x1, x1, #32
    a538:	eb00003f 	cmp	x1, x0
    a53c:	54000142 	b.cs	a564 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a540:	8b0102b5 	add	x21, x21, x1
    a544:	394002a0 	ldrb	w0, [x21]
    a548:	340000e0 	cbz	w0, a564 <fwp_main_thread+0x1044>
    a54c:	7100041f 	cmp	w0, #0x1
    a550:	540030a0 	b.eq	ab64 <fwp_main_thread+0x1644>  // b.none
    a554:	7103fc1f 	cmp	w0, #0xff
    a558:	54002d00 	b.eq	aaf8 <fwp_main_thread+0x15d8>  // b.none
    a55c:	51000400 	sub	w0, w0, #0x1
    a560:	390002a0 	strb	w0, [x21]
    a564:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a568:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a56c:	f95f5400 	ldr	x0, [x0, #16040]
    a570:	f9400800 	ldr	x0, [x0, #16]
    a574:	f91f5420 	str	x0, [x1, #16040]
    a578:	b4002940 	cbz	x0, aaa0 <fwp_main_thread+0x1580>
    a57c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a580:	9115c000 	add	x0, x0, #0x570
    a584:	f949d801 	ldr	x1, [x0, #5040]
    a588:	f949ec02 	ldr	x2, [x0, #5080]
    a58c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a590:	f95f5c00 	ldr	x0, [x0, #16056]
    a594:	d370bc42 	lsl	x2, x2, #16
    a598:	cb010001 	sub	x1, x0, x1
    a59c:	17fffe22 	b	9e24 <fwp_main_thread+0x904>
    a5a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5a4:	2a1903e2 	mov	w2, w25
    a5a8:	aa1403e4 	mov	x4, x20
    a5ac:	f95f681b 	ldr	x27, [x0, #16080]
    a5b0:	b97ed816 	ldr	w22, [x0, #16088]
    a5b4:	b97ee019 	ldr	w25, [x0, #16096]
    a5b8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a5bc:	9115c00a 	add	x10, x0, #0x570
    a5c0:	11000440 	add	w0, w2, #0x1
    a5c4:	f120001f 	cmp	x0, #0x800
    a5c8:	d37df000 	lsl	x0, x0, #3
    a5cc:	b953a541 	ldr	w1, [x10, #5028]
    a5d0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a5d4:	54001940 	b.eq	a8fc <fwp_main_thread+0x13dc>  // b.none
    a5d8:	91003c01 	add	x1, x0, #0xf
    a5dc:	8b411141 	add	x1, x10, x1, lsr #4
    a5e0:	397e8021 	ldrb	w1, [x1, #4000]
    a5e4:	910f002b 	add	x11, x1, #0x3c0
    a5e8:	8b010428 	add	x8, x1, x1, lsl #1
    a5ec:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a5f0:	8b080d4c 	add	x12, x10, x8, lsl #3
    a5f4:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a5f8:	2a0b03e1 	mov	w1, w11
    a5fc:	b40016f3 	cbz	x19, a8d8 <fwp_main_thread+0x13b8>
    a600:	f940026c 	ldr	x12, [x19]
    a604:	aa2c03ec 	mvn	x12, x12
    a608:	f828794c 	str	x12, [x10, x8, lsl #3]
    a60c:	eb01001f 	cmp	x0, x1
    a610:	540000c2 	b.cs	a628 <fwp_main_thread+0x1108>  // b.hs, b.nlast
    a614:	d503201f 	nop
    a618:	f8206a7f 	str	xzr, [x19, x0]
    a61c:	91002000 	add	x0, x0, #0x8
    a620:	eb00003f 	cmp	x1, x0
    a624:	54ffffa8 	b.hi	a618 <fwp_main_thread+0x10f8>  // b.pmore
    a628:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a62c:	9115c008 	add	x8, x0, #0x570
    a630:	f94a1100 	ldr	x0, [x8, #5152]
    a634:	ab010000 	adds	x0, x0, x1
    a638:	540020a2 	b.cs	aa4c <fwp_main_thread+0x152c>  // b.hs, b.nlast
    a63c:	f94a1501 	ldr	x1, [x8, #5160]
    a640:	f90a1100 	str	x0, [x8, #5152]
    a644:	eb01001f 	cmp	x0, x1
    a648:	54000049 	b.ls	a650 <fwp_main_thread+0x1130>  // b.plast
    a64c:	f90a1500 	str	x0, [x8, #5160]
    a650:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a654:	9115c000 	add	x0, x0, #0x570
    a658:	1e630161 	ucvtf	d1, w11
    a65c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a660:	1e612800 	fadd	d0, d0, d1
    a664:	fd0a1c00 	str	d0, [x0, #5176]
    a668:	b94000e0 	ldr	w0, [x7]
    a66c:	29000a60 	stp	w0, w2, [x19]
    a670:	340001a9 	cbz	w9, a6a4 <fwp_main_thread+0x1184>
    a674:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a678:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a67c:	910020e1 	add	x1, x7, #0x8
    a680:	f91f6c04 	str	x4, [x0, #16088]
    a684:	b93ee009 	str	w9, [x0, #16096]
    a688:	f91f7c07 	str	x7, [x0, #16120]
    a68c:	91002260 	add	x0, x19, #0x8
    a690:	97ffdff4 	bl	2660 <memmove@plt>
    a694:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a698:	f95f6c04 	ldr	x4, [x0, #16088]
    a69c:	f95f7c07 	ldr	x7, [x0, #16120]
    a6a0:	b97ee009 	ldr	w9, [x0, #16096]
    a6a4:	2a1703e8 	mov	w8, w23
    a6a8:	d2800001 	mov	x1, #0x0                   	// #0
    a6ac:	34000117 	cbz	w23, a6cc <fwp_main_thread+0x11ac>
    a6b0:	0b010120 	add	w0, w9, w1
    a6b4:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a6b8:	8b000e60 	add	x0, x19, x0, lsl #3
    a6bc:	91000421 	add	x1, x1, #0x1
    a6c0:	f9000402 	str	x2, [x0, #8]
    a6c4:	eb08003f 	cmp	x1, x8
    a6c8:	54ffff41 	b.ne	a6b0 <fwp_main_thread+0x1190>  // b.any
    a6cc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a6d0:	9115c002 	add	x2, x0, #0x570
    a6d4:	f949d840 	ldr	x0, [x2, #5040]
    a6d8:	f949ec41 	ldr	x1, [x2, #5080]
    a6dc:	cb000300 	sub	x0, x24, x0
    a6e0:	eb01401f 	cmp	x0, x1, lsl #16
    a6e4:	540002e2 	b.cs	a740 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a6e8:	d350fc01 	lsr	x1, x0, #16
    a6ec:	f949fc48 	ldr	x8, [x2, #5112]
    a6f0:	8b010821 	add	x1, x1, x1, lsl #2
    a6f4:	d37df021 	lsl	x1, x1, #3
    a6f8:	8b010105 	add	x5, x8, x1
    a6fc:	f94010a2 	ldr	x2, [x5, #32]
    a700:	b4000202 	cbz	x2, a740 <fwp_main_thread+0x1220>
    a704:	38616901 	ldrb	w1, [x8, x1]
    a708:	7100083f 	cmp	w1, #0x2
    a70c:	54001140 	b.eq	a934 <fwp_main_thread+0x1414>  // b.none
    a710:	7100043f 	cmp	w1, #0x1
    a714:	54000161 	b.ne	a740 <fwp_main_thread+0x1220>  // b.any
    a718:	294304a8 	ldp	w8, w1, [x5, #24]
    a71c:	92403c00 	and	x0, x0, #0xffff
    a720:	9b087c00 	mul	x0, x0, x8
    a724:	d360fc00 	lsr	x0, x0, #32
    a728:	eb01001f 	cmp	x0, x1
    a72c:	540000a2 	b.cs	a740 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a730:	8b000042 	add	x2, x2, x0
    a734:	39400040 	ldrb	w0, [x2]
    a738:	7100041f 	cmp	w0, #0x1
    a73c:	54000c40 	b.eq	a8c4 <fwp_main_thread+0x13a4>  // b.none
    a740:	f9400c82 	ldr	x2, [x4, #24]
    a744:	aa1803e0 	mov	x0, x24
    a748:	52800021 	mov	w1, #0x1                   	// #1
    a74c:	f9400442 	ldr	x2, [x2, #8]
    a750:	d63f0040 	blr	x2
    a754:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc70>
    a758:	9115c002 	add	x2, x0, #0x570
    a75c:	f949d841 	ldr	x1, [x2, #5040]
    a760:	f949ec40 	ldr	x0, [x2, #5080]
    a764:	cb010261 	sub	x1, x19, x1
    a768:	eb00403f 	cmp	x1, x0, lsl #16
    a76c:	54000322 	b.cs	a7d0 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a770:	d350fc20 	lsr	x0, x1, #16
    a774:	f949fc44 	ldr	x4, [x2, #5112]
    a778:	8b000800 	add	x0, x0, x0, lsl #2
    a77c:	d37df002 	lsl	x2, x0, #3
    a780:	8b020080 	add	x0, x4, x2
    a784:	f9401017 	ldr	x23, [x0, #32]
    a788:	b4000257 	cbz	x23, a7d0 <fwp_main_thread+0x12b0>
    a78c:	38626882 	ldrb	w2, [x4, x2]
    a790:	7100085f 	cmp	w2, #0x2
    a794:	54000d60 	b.eq	a940 <fwp_main_thread+0x1420>  // b.none
    a798:	7100045f 	cmp	w2, #0x1
    a79c:	540001a1 	b.ne	a7d0 <fwp_main_thread+0x12b0>  // b.any
    a7a0:	29430002 	ldp	w2, w0, [x0, #24]
    a7a4:	92403c21 	and	x1, x1, #0xffff
    a7a8:	9b027c21 	mul	x1, x1, x2
    a7ac:	d360fc21 	lsr	x1, x1, #32
    a7b0:	eb00003f 	cmp	x1, x0
    a7b4:	540000e2 	b.cs	a7d0 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a7b8:	8b0102f7 	add	x23, x23, x1
    a7bc:	394002e0 	ldrb	w0, [x23]
    a7c0:	7103fc1f 	cmp	w0, #0xff
    a7c4:	54000c80 	b.eq	a954 <fwp_main_thread+0x1434>  // b.none
    a7c8:	52800020 	mov	w0, #0x1                   	// #1
    a7cc:	390002e0 	strb	w0, [x23]
    a7d0:	aa1803e0 	mov	x0, x24
    a7d4:	aa1303f8 	mov	x24, x19
    a7d8:	97ffec7e 	bl	59d0 <fwp_closure_drop>
    a7dc:	17fffebd 	b	a2d0 <fwp_main_thread+0xdb0>
    a7e0:	b8616860 	ldr	w0, [x3, x1]
    a7e4:	b9400481 	ldr	w1, [x4, #4]
    a7e8:	4b010003 	sub	w3, w0, w1
    a7ec:	7100047f 	cmp	w3, #0x1
    a7f0:	54ffb721 	b.ne	9ed4 <fwp_main_thread+0x9b4>  // b.any
    a7f4:	910003f4 	mov	x20, sp
    a7f8:	34000c41 	cbz	w1, a980 <fwp_main_thread+0x1460>
    a7fc:	7100001f 	cmp	w0, #0x0
    a800:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a804:	d2800102 	mov	x2, #0x8                   	// #8
    a808:	9a82101a 	csel	x26, x0, x2, ne	// ne = any
    a80c:	91003f40 	add	x0, x26, #0xf
    a810:	92704c02 	and	x2, x0, #0xfffff0000
    a814:	927c7c00 	and	x0, x0, #0xffffffff0
    a818:	cb2263e2 	sub	x2, sp, x2
    a81c:	eb2263ff 	cmp	sp, x2
    a820:	540000a0 	b.eq	a834 <fwp_main_thread+0x1314>  // b.none
    a824:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a828:	f90203ff 	str	xzr, [sp, #1024]
    a82c:	eb2263ff 	cmp	sp, x2
    a830:	54ffffa1 	b.ne	a824 <fwp_main_thread+0x1304>  // b.any
    a834:	92403c00 	and	x0, x0, #0xffff
    a838:	cb2063ff 	sub	sp, sp, x0
    a83c:	f90003ff 	str	xzr, [sp]
    a840:	f110001f 	cmp	x0, #0x400
    a844:	54000043 	b.cc	a84c <fwp_main_thread+0x132c>  // b.lo, b.ul, b.last
    a848:	f90203ff 	str	xzr, [sp, #1024]
    a84c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a850:	d37d7c3b 	ubfiz	x27, x1, #3, #32
    a854:	910043f5 	add	x21, sp, #0x10
    a858:	aa1b03e2 	mov	x2, x27
    a85c:	aa1a03e3 	mov	x3, x26
    a860:	f91f7806 	str	x6, [x0, #16112]
    a864:	f91f7c05 	str	x5, [x0, #16120]
    a868:	f95f5000 	ldr	x0, [x0, #16032]
    a86c:	91004001 	add	x1, x0, #0x10
    a870:	aa1503e0 	mov	x0, x21
    a874:	91004021 	add	x1, x1, #0x10
    a878:	97ffdfb2 	bl	2740 <__memcpy_chk@plt>
    a87c:	eb1b035f 	cmp	x26, x27
    a880:	aa1303e1 	mov	x1, x19
    a884:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    a888:	d2800102 	mov	x2, #0x8                   	// #8
    a88c:	cb1b0063 	sub	x3, x3, x27
    a890:	8b1b02a0 	add	x0, x21, x27
    a894:	97ffdfab 	bl	2740 <__memcpy_chk@plt>
    a898:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a89c:	aa1503e0 	mov	x0, x21
    a8a0:	f95f7c25 	ldr	x5, [x1, #16120]
    a8a4:	f9400ca1 	ldr	x1, [x5, #24]
    a8a8:	f9400021 	ldr	x1, [x1]
    a8ac:	d63f0020 	blr	x1
    a8b0:	aa0003f8 	mov	x24, x0
    a8b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8b8:	f95f7806 	ldr	x6, [x0, #16112]
    a8bc:	9100029f 	mov	sp, x20
    a8c0:	17fffeb1 	b	a384 <fwp_main_thread+0xe64>
    a8c4:	b90004ff 	str	wzr, [x7, #4]
    a8c8:	17ffffa3 	b	a754 <fwp_main_thread+0x1234>
    a8cc:	72003c3f 	tst	w1, #0xffff
    a8d0:	54ffb421 	b.ne	9f54 <fwp_main_thread+0xa34>  // b.any
    a8d4:	17fffd9a 	b	9f3c <fwp_main_thread+0xa1c>
    a8d8:	f9400593 	ldr	x19, [x12, #8]
    a8dc:	b4000113 	cbz	x19, a8fc <fwp_main_thread+0x13dc>
    a8e0:	f9400988 	ldr	x8, [x12, #16]
    a8e4:	cb130108 	sub	x8, x8, x19
    a8e8:	eb08003f 	cmp	x1, x8
    a8ec:	54000088 	b.hi	a8fc <fwp_main_thread+0x13dc>  // b.pmore
    a8f0:	8b010268 	add	x8, x19, x1
    a8f4:	f9000588 	str	x8, [x12, #8]
    a8f8:	17ffff45 	b	a60c <fwp_main_thread+0x10ec>
    a8fc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a900:	f91f6824 	str	x4, [x1, #16080]
    a904:	f91f6c27 	str	x7, [x1, #16088]
    a908:	b93ee022 	str	w2, [x1, #16096]
    a90c:	b93ef829 	str	w9, [x1, #16120]
    a910:	52800001 	mov	w1, #0x0                   	// #0
    a914:	97ffe8cb 	bl	4c40 <fwp_heap_alloc>
    a918:	aa0003f3 	mov	x19, x0
    a91c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a920:	f95f6804 	ldr	x4, [x0, #16080]
    a924:	f95f6c07 	ldr	x7, [x0, #16088]
    a928:	b97ee002 	ldr	w2, [x0, #16096]
    a92c:	b97ef809 	ldr	w9, [x0, #16120]
    a930:	17ffff4e 	b	a668 <fwp_main_thread+0x1148>
    a934:	72003c1f 	tst	w0, #0xffff
    a938:	54fff041 	b.ne	a740 <fwp_main_thread+0x1220>  // b.any
    a93c:	17ffff7e 	b	a734 <fwp_main_thread+0x1214>
    a940:	72003c3f 	tst	w1, #0xffff
    a944:	54fff461 	b.ne	a7d0 <fwp_main_thread+0x12b0>  // b.any
    a948:	394002e0 	ldrb	w0, [x23]
    a94c:	7103fc1f 	cmp	w0, #0xff
    a950:	54fff3c1 	b.ne	a7c8 <fwp_main_thread+0x12a8>  // b.any
    a954:	aa1703e0 	mov	x0, x23
    a958:	97ffe6fa 	bl	4540 <fwp_rc_forget_slot>
    a95c:	17ffff9b 	b	a7c8 <fwp_main_thread+0x12a8>
    a960:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a964:	f91f7826 	str	x6, [x1, #16112]
    a968:	f91f7c25 	str	x5, [x1, #16120]
    a96c:	97ffe6ae 	bl	4424 <fwp_rc_wide_dup>
    a970:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a974:	f95f7806 	ldr	x6, [x0, #16112]
    a978:	f95f7c05 	ldr	x5, [x0, #16120]
    a97c:	17fffd76 	b	9f54 <fwp_main_thread+0xa34>
    a980:	f9400041 	ldr	x1, [x2]
    a984:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a988:	f91f7c06 	str	x6, [x0, #16120]
    a98c:	aa1303e0 	mov	x0, x19
    a990:	d63f0020 	blr	x1
    a994:	aa0003f8 	mov	x24, x0
    a998:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a99c:	f95f7c06 	ldr	x6, [x0, #16120]
    a9a0:	9100029f 	mov	sp, x20
    a9a4:	17fffe78 	b	a384 <fwp_main_thread+0xe64>
    a9a8:	72003c3f 	tst	w1, #0xffff
    a9ac:	54ff9be1 	b.ne	9d28 <fwp_main_thread+0x808>  // b.any
    a9b0:	17fffcd9 	b	9d14 <fwp_main_thread+0x7f4>
    a9b4:	72003c3f 	tst	w1, #0xffff
    a9b8:	54ff9661 	b.ne	9c84 <fwp_main_thread+0x764>  // b.any
    a9bc:	17fffcad 	b	9c70 <fwp_main_thread+0x750>
    a9c0:	72003c3f 	tst	w1, #0xffff
    a9c4:	54ffa6a1 	b.ne	9e98 <fwp_main_thread+0x978>  // b.any
    a9c8:	17fffd2e 	b	9e80 <fwp_main_thread+0x960>
    a9cc:	72003c3f 	tst	w1, #0xffff
    a9d0:	54ffa0e1 	b.ne	9dec <fwp_main_thread+0x8cc>  // b.any
    a9d4:	17fffcfb 	b	9dc0 <fwp_main_thread+0x8a0>
    a9d8:	aa0103e0 	mov	x0, x1
    a9dc:	17fffb9d 	b	9850 <fwp_main_thread+0x330>
    a9e0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9e4:	f91f7c06 	str	x6, [x0, #16120]
    a9e8:	aa1303e0 	mov	x0, x19
    a9ec:	97ffe6d5 	bl	4540 <fwp_rc_forget_slot>
    a9f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9f4:	f95f7c06 	ldr	x6, [x0, #16120]
    a9f8:	17fffca1 	b	9c7c <fwp_main_thread+0x75c>
    a9fc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aa00:	f91f7c26 	str	x6, [x1, #16120]
    aa04:	97ffe688 	bl	4424 <fwp_rc_wide_dup>
    aa08:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa0c:	f95f7c06 	ldr	x6, [x0, #16120]
    aa10:	17fffd22 	b	9e98 <fwp_main_thread+0x978>
    aa14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa18:	f91f7c06 	str	x6, [x0, #16120]
    aa1c:	aa1303e0 	mov	x0, x19
    aa20:	97ffe6c8 	bl	4540 <fwp_rc_forget_slot>
    aa24:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa28:	f95f7c06 	ldr	x6, [x0, #16120]
    aa2c:	17fffcbd 	b	9d20 <fwp_main_thread+0x800>
    aa30:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa34:	f91f7c06 	str	x6, [x0, #16120]
    aa38:	aa1303e0 	mov	x0, x19
    aa3c:	97ffe6c1 	bl	4540 <fwp_rc_forget_slot>
    aa40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa44:	f95f7c06 	ldr	x6, [x0, #16120]
    aa48:	17fffce1 	b	9dcc <fwp_main_thread+0x8ac>
    aa4c:	97ffe159 	bl	2fb0 <fwp_heap_oom>
    aa50:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    aa54:	91220000 	add	x0, x0, #0x880
    aa58:	97ffe2aa 	bl	3500 <fwp_trap>
    aa5c:	97ffdf65 	bl	27f0 <__stack_chk_fail@plt>
    aa60:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aa64:	aa0603e0 	mov	x0, x6
    aa68:	aa1303fb 	mov	x27, x19
    aa6c:	52800034 	mov	w20, #0x1                   	// #1
    aa70:	f91f7c26 	str	x6, [x1, #16120]
    aa74:	97ffeabb 	bl	5560 <fwp_rc_share>
    aa78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa7c:	f95f5c00 	ldr	x0, [x0, #16056]
    aa80:	97ffeab8 	bl	5560 <fwp_rc_share>
    aa84:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa88:	f95f7c06 	ldr	x6, [x0, #16120]
    aa8c:	aa0603f8 	mov	x24, x6
    aa90:	17fffe34 	b	a360 <fwp_main_thread+0xe40>
    aa94:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    aa98:	9122a000 	add	x0, x0, #0x8a8
    aa9c:	97ffe299 	bl	3500 <fwp_trap>
    aaa0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aaa4:	f95f4c06 	ldr	x6, [x0, #16024]
    aaa8:	f91f7c06 	str	x6, [x0, #16120]
    aaac:	f95f5c16 	ldr	x22, [x0, #16056]
    aab0:	aa1603e0 	mov	x0, x22
    aab4:	97ffeb18 	bl	5714 <fwp_drop0>
    aab8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aabc:	f95f7c06 	ldr	x6, [x0, #16120]
    aac0:	aa0603e0 	mov	x0, x6
    aac4:	97ffeb14 	bl	5714 <fwp_drop0>
    aac8:	d00000a0 	adrp	x0, 20000 <__data_start>
    aacc:	91010000 	add	x0, x0, #0x40
    aad0:	52800021 	mov	w1, #0x1                   	// #1
    aad4:	b9031801 	str	w1, [x0, #792]
    aad8:	f901901f 	str	xzr, [x0, #800]
    aadc:	17fffad3 	b	9628 <fwp_main_thread+0x108>
    aae0:	72003c3f 	tst	w1, #0xffff
    aae4:	54ffd401 	b.ne	a564 <fwp_main_thread+0x1044>  // b.any
    aae8:	17fffe97 	b	a544 <fwp_main_thread+0x1024>
    aaec:	72003c3f 	tst	w1, #0xffff
    aaf0:	54ffcd41 	b.ne	a498 <fwp_main_thread+0xf78>  // b.any
    aaf4:	17fffe64 	b	a484 <fwp_main_thread+0xf64>
    aaf8:	ca5546a0 	eor	x0, x21, x21, lsr #17
    aafc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc70>
    ab00:	9115c021 	add	x1, x1, #0x570
    ab04:	ca402400 	eor	x0, x0, x0, lsr #9
    ab08:	8b200c20 	add	x0, x1, w0, uxtb #3
    ab0c:	f94a2400 	ldr	x0, [x0, #5192]
    ab10:	b5000080 	cbnz	x0, ab20 <fwp_main_thread+0x1600>
    ab14:	14000025 	b	aba8 <fwp_main_thread+0x1688>
    ab18:	f9400800 	ldr	x0, [x0, #16]
    ab1c:	b4000460 	cbz	x0, aba8 <fwp_main_thread+0x1688>
    ab20:	f9400001 	ldr	x1, [x0]
    ab24:	eb0102bf 	cmp	x21, x1
    ab28:	54ffff81 	b.ne	ab18 <fwp_main_thread+0x15f8>  // b.any
    ab2c:	f9400401 	ldr	x1, [x0, #8]
    ab30:	d1000421 	sub	x1, x1, #0x1
    ab34:	f9000401 	str	x1, [x0, #8]
    ab38:	f103f83f 	cmp	x1, #0xfe
    ab3c:	54ffd141 	b.ne	a564 <fwp_main_thread+0x1044>  // b.any
    ab40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab44:	f91f7c06 	str	x6, [x0, #16120]
    ab48:	aa1503e0 	mov	x0, x21
    ab4c:	97ffe67d 	bl	4540 <fwp_rc_forget_slot>
    ab50:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ab54:	390002a0 	strb	w0, [x21]
    ab58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab5c:	f95f7c06 	ldr	x6, [x0, #16120]
    ab60:	17fffe81 	b	a564 <fwp_main_thread+0x1044>
    ab64:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab68:	f91f7c06 	str	x6, [x0, #16120]
    ab6c:	aa1403e0 	mov	x0, x20
    ab70:	97ffeaa1 	bl	55f4 <fwp_rc_free_arr>
    ab74:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab78:	f95f7c06 	ldr	x6, [x0, #16120]
    ab7c:	17fffe7a 	b	a564 <fwp_main_thread+0x1044>
    ab80:	b9032a9f 	str	wzr, [x20, #808]
    ab84:	b4ff69a0 	cbz	x0, 98b8 <fwp_main_thread+0x398>
    ab88:	97ffdf2e 	bl	2840 <abort@plt>
    ab8c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab90:	f91f7c06 	str	x6, [x0, #16120]
    ab94:	aa1a03e0 	mov	x0, x26
    ab98:	97ffe66a 	bl	4540 <fwp_rc_forget_slot>
    ab9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aba0:	f95f7c06 	ldr	x6, [x0, #16120]
    aba4:	17fffe3b 	b	a490 <fwp_main_thread+0xf70>
    aba8:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    abac:	91162000 	add	x0, x0, #0x588
    abb0:	97ffe254 	bl	3500 <fwp_trap>
    abb4:	d503201f 	nop
    abb8:	d503201f 	nop
    abbc:	d503201f 	nop

000000000000abc0 <__divti3>:
    abc0:	d503245f 	bti	c
    abc4:	d2800004 	mov	x4, #0x0                   	// #0
    abc8:	b7f80721 	tbnz	x1, #63, acac <__divti3+0xec>
    abcc:	b6f80083 	tbz	x3, #63, abdc <__divti3+0x1c>
    abd0:	eb0203e2 	negs	x2, x2
    abd4:	aa2403e4 	mvn	x4, x4
    abd8:	da0303e3 	ngc	x3, x3
    abdc:	aa0203e6 	mov	x6, x2
    abe0:	aa0003e7 	mov	x7, x0
    abe4:	aa0103e5 	mov	x5, x1
    abe8:	b5000583 	cbnz	x3, ac98 <__divti3+0xd8>
    abec:	eb01005f 	cmp	x2, x1
    abf0:	54000e69 	b.ls	adbc <__divti3+0x1fc>  // b.plast
    abf4:	dac01040 	clz	x0, x2
    abf8:	b40000e0 	cbz	x0, ac14 <__divti3+0x54>
    abfc:	4b0003e1 	neg	w1, w0
    ac00:	9ac020a5 	lsl	x5, x5, x0
    ac04:	9ac02046 	lsl	x6, x2, x0
    ac08:	9ac124e1 	lsr	x1, x7, x1
    ac0c:	aa050025 	orr	x5, x1, x5
    ac10:	9ac020e7 	lsl	x7, x7, x0
    ac14:	d360fcc8 	lsr	x8, x6, #32
    ac18:	92407cc2 	and	x2, x6, #0xffffffff
    ac1c:	9ac808a3 	udiv	x3, x5, x8
    ac20:	9b089465 	msub	x5, x3, x8, x5
    ac24:	aa0303e0 	mov	x0, x3
    ac28:	9b037c41 	mul	x1, x2, x3
    ac2c:	93c780a5 	extr	x5, x5, x7, #32
    ac30:	eb05003f 	cmp	x1, x5
    ac34:	540000a9 	b.ls	ac48 <__divti3+0x88>  // b.plast
    ac38:	ab0500c5 	adds	x5, x6, x5
    ac3c:	d1000460 	sub	x0, x3, #0x1
    ac40:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ac44:	540015a8 	b.hi	aef8 <__divti3+0x338>  // b.pmore
    ac48:	cb0100a5 	sub	x5, x5, x1
    ac4c:	9ac808a3 	udiv	x3, x5, x8
    ac50:	9b089465 	msub	x5, x3, x8, x5
    ac54:	aa0303e1 	mov	x1, x3
    ac58:	9b037c42 	mul	x2, x2, x3
    ac5c:	aa0703e3 	mov	x3, x7
    ac60:	b3607ca3 	bfi	x3, x5, #32, #32
    ac64:	eb03005f 	cmp	x2, x3
    ac68:	540000c9 	b.ls	ac80 <__divti3+0xc0>  // b.plast
    ac6c:	ab0300c3 	adds	x3, x6, x3
    ac70:	d1000425 	sub	x5, x1, #0x1
    ac74:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ac78:	d1000821 	sub	x1, x1, #0x2
    ac7c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ac80:	aa008020 	orr	x0, x1, x0, lsl #32
    ac84:	d2800001 	mov	x1, #0x0                   	// #0
    ac88:	b4000064 	cbz	x4, ac94 <__divti3+0xd4>
    ac8c:	eb0003e0 	negs	x0, x0
    ac90:	da0103e1 	ngc	x1, x1
    ac94:	d65f03c0 	ret
    ac98:	eb01007f 	cmp	x3, x1
    ac9c:	54000109 	b.ls	acbc <__divti3+0xfc>  // b.plast
    aca0:	d2800001 	mov	x1, #0x0                   	// #0
    aca4:	d2800000 	mov	x0, #0x0                   	// #0
    aca8:	17fffff8 	b	ac88 <__divti3+0xc8>
    acac:	eb0003e0 	negs	x0, x0
    acb0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    acb4:	da0103e1 	ngc	x1, x1
    acb8:	17ffffc5 	b	abcc <__divti3+0xc>
    acbc:	dac01067 	clz	x7, x3
    acc0:	b40010e7 	cbz	x7, aedc <__divti3+0x31c>
    acc4:	d2800805 	mov	x5, #0x40                  	// #64
    acc8:	cb0700a5 	sub	x5, x5, x7
    accc:	9ac72063 	lsl	x3, x3, x7
    acd0:	9ac52448 	lsr	x8, x2, x5
    acd4:	aa030108 	orr	x8, x8, x3
    acd8:	9ac52426 	lsr	x6, x1, x5
    acdc:	92407d0a 	and	x10, x8, #0xffffffff
    ace0:	d360fd09 	lsr	x9, x8, #32
    ace4:	9ac52403 	lsr	x3, x0, x5
    ace8:	9ac72021 	lsl	x1, x1, x7
    acec:	aa010063 	orr	x3, x3, x1
    acf0:	9ac72042 	lsl	x2, x2, x7
    acf4:	9ac908cb 	udiv	x11, x6, x9
    acf8:	9b099965 	msub	x5, x11, x9, x6
    acfc:	aa0b03e1 	mov	x1, x11
    ad00:	9b0b7d46 	mul	x6, x10, x11
    ad04:	93c380a5 	extr	x5, x5, x3, #32
    ad08:	eb0500df 	cmp	x6, x5
    ad0c:	540000a9 	b.ls	ad20 <__divti3+0x160>  // b.plast
    ad10:	ab050105 	adds	x5, x8, x5
    ad14:	d1000561 	sub	x1, x11, #0x1
    ad18:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ad1c:	54000f48 	b.hi	af04 <__divti3+0x344>  // b.pmore
    ad20:	cb0600a6 	sub	x6, x5, x6
    ad24:	9ac908cb 	udiv	x11, x6, x9
    ad28:	9b099969 	msub	x9, x11, x9, x6
    ad2c:	aa0b03e5 	mov	x5, x11
    ad30:	9b0b7d4a 	mul	x10, x10, x11
    ad34:	b3607d23 	bfi	x3, x9, #32, #32
    ad38:	eb03015f 	cmp	x10, x3
    ad3c:	540000a9 	b.ls	ad50 <__divti3+0x190>  // b.plast
    ad40:	ab030103 	adds	x3, x8, x3
    ad44:	d1000565 	sub	x5, x11, #0x1
    ad48:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ad4c:	54000e28 	b.hi	af10 <__divti3+0x350>  // b.pmore
    ad50:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ad54:	92407c48 	and	x8, x2, #0xffffffff
    ad58:	2a0503e5 	mov	w5, w5
    ad5c:	d360fc42 	lsr	x2, x2, #32
    ad60:	d360fc26 	lsr	x6, x1, #32
    ad64:	cb0a0063 	sub	x3, x3, x10
    ad68:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ad6c:	9b087caa 	mul	x10, x5, x8
    ad70:	9b087cc8 	mul	x8, x6, x8
    ad74:	9b0220a5 	madd	x5, x5, x2, x8
    ad78:	9b027cc6 	mul	x6, x6, x2
    ad7c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ad80:	8b0900c5 	add	x5, x6, x9
    ad84:	eb02011f 	cmp	x8, x2
    ad88:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ad8c:	8b4280c6 	add	x6, x6, x2, lsr #32
    ad90:	eb06007f 	cmp	x3, x6
    ad94:	540000e3 	b.cc	adb0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ad98:	92407d4a 	and	x10, x10, #0xffffffff
    ad9c:	9ac72000 	lsl	x0, x0, x7
    ada0:	8b028142 	add	x2, x10, x2, lsl #32
    ada4:	eb02001f 	cmp	x0, x2
    ada8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    adac:	54000a01 	b.ne	aeec <__divti3+0x32c>  // b.any
    adb0:	d1000420 	sub	x0, x1, #0x1
    adb4:	d2800001 	mov	x1, #0x0                   	// #0
    adb8:	17ffffb4 	b	ac88 <__divti3+0xc8>
    adbc:	b5000062 	cbnz	x2, adc8 <__divti3+0x208>
    adc0:	d2800022 	mov	x2, #0x1                   	// #1
    adc4:	9ac30846 	udiv	x6, x2, x3
    adc8:	dac010c8 	clz	x8, x6
    adcc:	b5000408 	cbnz	x8, ae4c <__divti3+0x28c>
    add0:	d360fcc9 	lsr	x9, x6, #32
    add4:	92407cc5 	and	x5, x6, #0xffffffff
    add8:	cb060023 	sub	x3, x1, x6
    addc:	d2800021 	mov	x1, #0x1                   	// #1
    ade0:	9ac90868 	udiv	x8, x3, x9
    ade4:	9b098d03 	msub	x3, x8, x9, x3
    ade8:	aa0803e0 	mov	x0, x8
    adec:	9b057d02 	mul	x2, x8, x5
    adf0:	93c78063 	extr	x3, x3, x7, #32
    adf4:	eb03005f 	cmp	x2, x3
    adf8:	540000a9 	b.ls	ae0c <__divti3+0x24c>  // b.plast
    adfc:	ab0300c3 	adds	x3, x6, x3
    ae00:	d1000500 	sub	x0, x8, #0x1
    ae04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ae08:	54000968 	b.hi	af34 <__divti3+0x374>  // b.pmore
    ae0c:	cb020063 	sub	x3, x3, x2
    ae10:	9ac90862 	udiv	x2, x3, x9
    ae14:	aa0203e8 	mov	x8, x2
    ae18:	9b098c42 	msub	x2, x2, x9, x3
    ae1c:	aa0703e3 	mov	x3, x7
    ae20:	9b057d05 	mul	x5, x8, x5
    ae24:	b3607c43 	bfi	x3, x2, #32, #32
    ae28:	eb0300bf 	cmp	x5, x3
    ae2c:	540000c9 	b.ls	ae44 <__divti3+0x284>  // b.plast
    ae30:	ab0300c2 	adds	x2, x6, x3
    ae34:	d1000503 	sub	x3, x8, #0x1
    ae38:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ae3c:	d1000908 	sub	x8, x8, #0x2
    ae40:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ae44:	aa008100 	orr	x0, x8, x0, lsl #32
    ae48:	17ffff90 	b	ac88 <__divti3+0xc8>
    ae4c:	9ac820c6 	lsl	x6, x6, x8
    ae50:	d2800803 	mov	x3, #0x40                  	// #64
    ae54:	cb080063 	sub	x3, x3, x8
    ae58:	d360fcc9 	lsr	x9, x6, #32
    ae5c:	9ac82027 	lsl	x7, x1, x8
    ae60:	92407cc5 	and	x5, x6, #0xffffffff
    ae64:	9ac32422 	lsr	x2, x1, x3
    ae68:	9ac32403 	lsr	x3, x0, x3
    ae6c:	aa070063 	orr	x3, x3, x7
    ae70:	9ac9084a 	udiv	x10, x2, x9
    ae74:	9ac82007 	lsl	x7, x0, x8
    ae78:	9b098940 	msub	x0, x10, x9, x2
    ae7c:	aa0a03e1 	mov	x1, x10
    ae80:	9b0a7ca2 	mul	x2, x5, x10
    ae84:	93c38000 	extr	x0, x0, x3, #32
    ae88:	eb00005f 	cmp	x2, x0
    ae8c:	540000a9 	b.ls	aea0 <__divti3+0x2e0>  // b.plast
    ae90:	ab0000c0 	adds	x0, x6, x0
    ae94:	d1000541 	sub	x1, x10, #0x1
    ae98:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    ae9c:	54000468 	b.hi	af28 <__divti3+0x368>  // b.pmore
    aea0:	cb020000 	sub	x0, x0, x2
    aea4:	9ac9080a 	udiv	x10, x0, x9
    aea8:	9b098140 	msub	x0, x10, x9, x0
    aeac:	aa0a03e2 	mov	x2, x10
    aeb0:	9b0a7ca8 	mul	x8, x5, x10
    aeb4:	b3607c03 	bfi	x3, x0, #32, #32
    aeb8:	eb03011f 	cmp	x8, x3
    aebc:	540000a9 	b.ls	aed0 <__divti3+0x310>  // b.plast
    aec0:	ab0300c3 	adds	x3, x6, x3
    aec4:	d1000542 	sub	x2, x10, #0x1
    aec8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    aecc:	54000288 	b.hi	af1c <__divti3+0x35c>  // b.pmore
    aed0:	cb080063 	sub	x3, x3, x8
    aed4:	aa018041 	orr	x1, x2, x1, lsl #32
    aed8:	17ffffc2 	b	ade0 <__divti3+0x220>
    aedc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    aee0:	d2800001 	mov	x1, #0x0                   	// #0
    aee4:	9a9f87e0 	cset	x0, ls	// ls = plast
    aee8:	17ffff68 	b	ac88 <__divti3+0xc8>
    aeec:	aa0103e0 	mov	x0, x1
    aef0:	d2800001 	mov	x1, #0x0                   	// #0
    aef4:	17ffff65 	b	ac88 <__divti3+0xc8>
    aef8:	d1000860 	sub	x0, x3, #0x2
    aefc:	8b0600a5 	add	x5, x5, x6
    af00:	17ffff52 	b	ac48 <__divti3+0x88>
    af04:	d1000961 	sub	x1, x11, #0x2
    af08:	8b0800a5 	add	x5, x5, x8
    af0c:	17ffff85 	b	ad20 <__divti3+0x160>
    af10:	d1000965 	sub	x5, x11, #0x2
    af14:	8b080063 	add	x3, x3, x8
    af18:	17ffff8e 	b	ad50 <__divti3+0x190>
    af1c:	d1000942 	sub	x2, x10, #0x2
    af20:	8b060063 	add	x3, x3, x6
    af24:	17ffffeb 	b	aed0 <__divti3+0x310>
    af28:	d1000941 	sub	x1, x10, #0x2
    af2c:	8b060000 	add	x0, x0, x6
    af30:	17ffffdc 	b	aea0 <__divti3+0x2e0>
    af34:	d1000900 	sub	x0, x8, #0x2
    af38:	8b060063 	add	x3, x3, x6
    af3c:	17ffffb4 	b	ae0c <__divti3+0x24c>

000000000000af40 <__modti3>:
    af40:	d503245f 	bti	c
    af44:	d2800004 	mov	x4, #0x0                   	// #0
    af48:	b6f80081 	tbz	x1, #63, af58 <__modti3+0x18>
    af4c:	eb0003e0 	negs	x0, x0
    af50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af54:	da0103e1 	ngc	x1, x1
    af58:	f100007f 	cmp	x3, #0x0
    af5c:	5400128b 	b.lt	b1ac <__modti3+0x26c>  // b.tstop
    af60:	aa0003e7 	mov	x7, x0
    af64:	aa0103e6 	mov	x6, x1
    af68:	540004e1 	b.ne	b004 <__modti3+0xc4>  // b.any
    af6c:	eb02003f 	cmp	x1, x2
    af70:	54000dc2 	b.cs	b128 <__modti3+0x1e8>  // b.hs, b.nlast
    af74:	dac01043 	clz	x3, x2
    af78:	aa0303e5 	mov	x5, x3
    af7c:	b40000e3 	cbz	x3, af98 <__modti3+0x58>
    af80:	4b0303e6 	neg	w6, w3
    af84:	9ac32021 	lsl	x1, x1, x3
    af88:	9ac32042 	lsl	x2, x2, x3
    af8c:	9ac62406 	lsr	x6, x0, x6
    af90:	aa0100c6 	orr	x6, x6, x1
    af94:	9ac32007 	lsl	x7, x0, x3
    af98:	d360fc40 	lsr	x0, x2, #32
    af9c:	92407c43 	and	x3, x2, #0xffffffff
    afa0:	9ac008c1 	udiv	x1, x6, x0
    afa4:	9b009826 	msub	x6, x1, x0, x6
    afa8:	9b017c61 	mul	x1, x3, x1
    afac:	93c780c6 	extr	x6, x6, x7, #32
    afb0:	eb06003f 	cmp	x1, x6
    afb4:	540000a9 	b.ls	afc8 <__modti3+0x88>  // b.plast
    afb8:	ab060046 	adds	x6, x2, x6
    afbc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    afc0:	8b0200c8 	add	x8, x6, x2
    afc4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    afc8:	cb0100c6 	sub	x6, x6, x1
    afcc:	9ac008c8 	udiv	x8, x6, x0
    afd0:	9b009901 	msub	x1, x8, x0, x6
    afd4:	aa0703e0 	mov	x0, x7
    afd8:	9b087c63 	mul	x3, x3, x8
    afdc:	b3607c20 	bfi	x0, x1, #32, #32
    afe0:	eb00007f 	cmp	x3, x0
    afe4:	54001088 	b.hi	b1f4 <__modti3+0x2b4>  // b.pmore
    afe8:	cb030000 	sub	x0, x0, x3
    afec:	9ac52400 	lsr	x0, x0, x5
    aff0:	d2800001 	mov	x1, #0x0                   	// #0
    aff4:	b4000064 	cbz	x4, b000 <__modti3+0xc0>
    aff8:	eb0003e0 	negs	x0, x0
    affc:	da0103e1 	ngc	x1, x1
    b000:	d65f03c0 	ret
    b004:	dac01066 	clz	x6, x3
    b008:	eb03003f 	cmp	x1, x3
    b00c:	54ffff43 	b.cc	aff4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b010:	93407cc5 	sxtw	x5, w6
    b014:	d2800808 	mov	x8, #0x40                  	// #64
    b018:	cb050108 	sub	x8, x8, x5
    b01c:	9ac62063 	lsl	x3, x3, x6
    b020:	9ac62025 	lsl	x5, x1, x6
    b024:	9ac82447 	lsr	x7, x2, x8
    b028:	aa0300e7 	orr	x7, x7, x3
    b02c:	9ac82423 	lsr	x3, x1, x8
    b030:	92407cec 	and	x12, x7, #0xffffffff
    b034:	d360fcea 	lsr	x10, x7, #32
    b038:	9ac82401 	lsr	x1, x0, x8
    b03c:	aa050021 	orr	x1, x1, x5
    b040:	9ac62042 	lsl	x2, x2, x6
    b044:	9ac62000 	lsl	x0, x0, x6
    b048:	9aca086b 	udiv	x11, x3, x10
    b04c:	9b0a8d63 	msub	x3, x11, x10, x3
    b050:	aa0b03e5 	mov	x5, x11
    b054:	9b0b7d89 	mul	x9, x12, x11
    b058:	93c18063 	extr	x3, x3, x1, #32
    b05c:	eb03013f 	cmp	x9, x3
    b060:	540000a9 	b.ls	b074 <__modti3+0x134>  // b.plast
    b064:	ab0300e3 	adds	x3, x7, x3
    b068:	d1000565 	sub	x5, x11, #0x1
    b06c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b070:	54001168 	b.hi	b29c <__modti3+0x35c>  // b.pmore
    b074:	cb090063 	sub	x3, x3, x9
    b078:	9aca086b 	udiv	x11, x3, x10
    b07c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b080:	aa0b03e9 	mov	x9, x11
    b084:	9b0b7d8c 	mul	x12, x12, x11
    b088:	b3607d41 	bfi	x1, x10, #32, #32
    b08c:	eb01019f 	cmp	x12, x1
    b090:	540000a9 	b.ls	b0a4 <__modti3+0x164>  // b.plast
    b094:	ab0100e1 	adds	x1, x7, x1
    b098:	d1000569 	sub	x9, x11, #0x1
    b09c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b0a0:	54000f88 	b.hi	b290 <__modti3+0x350>  // b.pmore
    b0a4:	aa058123 	orr	x3, x9, x5, lsl #32
    b0a8:	92407c4b 	and	x11, x2, #0xffffffff
    b0ac:	2a0903e9 	mov	w9, w9
    b0b0:	d360fc4a 	lsr	x10, x2, #32
    b0b4:	d360fc63 	lsr	x3, x3, #32
    b0b8:	cb0c0021 	sub	x1, x1, x12
    b0bc:	aa0a03ec 	mov	x12, x10
    b0c0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b0c4:	9b0b7d25 	mul	x5, x9, x11
    b0c8:	9b0b7c6b 	mul	x11, x3, x11
    b0cc:	9b0a2d29 	madd	x9, x9, x10, x11
    b0d0:	92407caa 	and	x10, x5, #0xffffffff
    b0d4:	9b0c7c63 	mul	x3, x3, x12
    b0d8:	8b458125 	add	x5, x9, x5, lsr #32
    b0dc:	8b0d0069 	add	x9, x3, x13
    b0e0:	eb05017f 	cmp	x11, x5
    b0e4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b0e8:	8b058149 	add	x9, x10, x5, lsl #32
    b0ec:	8b458063 	add	x3, x3, x5, lsr #32
    b0f0:	eb03003f 	cmp	x1, x3
    b0f4:	54000063 	b.cc	b100 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b0f8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b0fc:	54000082 	b.cs	b10c <__modti3+0x1cc>  // b.hs, b.nlast
    b100:	eb020129 	subs	x9, x9, x2
    b104:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b108:	cb070063 	sub	x3, x3, x7
    b10c:	eb090000 	subs	x0, x0, x9
    b110:	da030021 	sbc	x1, x1, x3
    b114:	9ac62400 	lsr	x0, x0, x6
    b118:	9ac82028 	lsl	x8, x1, x8
    b11c:	aa000100 	orr	x0, x8, x0
    b120:	9ac62421 	lsr	x1, x1, x6
    b124:	17ffffb4 	b	aff4 <__modti3+0xb4>
    b128:	b5000062 	cbnz	x2, b134 <__modti3+0x1f4>
    b12c:	d2800023 	mov	x3, #0x1                   	// #1
    b130:	9ac20862 	udiv	x2, x3, x2
    b134:	dac01048 	clz	x8, x2
    b138:	aa0803e5 	mov	x5, x8
    b13c:	b5000668 	cbnz	x8, b208 <__modti3+0x2c8>
    b140:	cb020020 	sub	x0, x1, x2
    b144:	d360fc49 	lsr	x9, x2, #32
    b148:	92407c4a 	and	x10, x2, #0xffffffff
    b14c:	9ac90801 	udiv	x1, x0, x9
    b150:	9b098020 	msub	x0, x1, x9, x0
    b154:	9b0a7c21 	mul	x1, x1, x10
    b158:	93c78000 	extr	x0, x0, x7, #32
    b15c:	eb00003f 	cmp	x1, x0
    b160:	540000a9 	b.ls	b174 <__modti3+0x234>  // b.plast
    b164:	ab000040 	adds	x0, x2, x0
    b168:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b16c:	8b020003 	add	x3, x0, x2
    b170:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b174:	cb010001 	sub	x1, x0, x1
    b178:	9ac90820 	udiv	x0, x1, x9
    b17c:	9b098403 	msub	x3, x0, x9, x1
    b180:	aa0703e1 	mov	x1, x7
    b184:	9b0a7c00 	mul	x0, x0, x10
    b188:	b3607c61 	bfi	x1, x3, #32, #32
    b18c:	eb01001f 	cmp	x0, x1
    b190:	540000a9 	b.ls	b1a4 <__modti3+0x264>  // b.plast
    b194:	ab010041 	adds	x1, x2, x1
    b198:	8b020022 	add	x2, x1, x2
    b19c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b1a0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b1a4:	cb000020 	sub	x0, x1, x0
    b1a8:	17ffff91 	b	afec <__modti3+0xac>
    b1ac:	eb0203e5 	negs	x5, x2
    b1b0:	aa0003e7 	mov	x7, x0
    b1b4:	da0303e8 	ngc	x8, x3
    b1b8:	aa0503e2 	mov	x2, x5
    b1bc:	aa0803e3 	mov	x3, x8
    b1c0:	aa0103e6 	mov	x6, x1
    b1c4:	b4ffed48 	cbz	x8, af6c <__modti3+0x2c>
    b1c8:	eb01011f 	cmp	x8, x1
    b1cc:	54fff148 	b.hi	aff4 <__modti3+0xb4>  // b.pmore
    b1d0:	dac01109 	clz	x9, x8
    b1d4:	2a0903e6 	mov	w6, w9
    b1d8:	b5fff1c9 	cbnz	x9, b010 <__modti3+0xd0>
    b1dc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b1e0:	54000068 	b.hi	b1ec <__modti3+0x2ac>  // b.pmore
    b1e4:	eb050007 	subs	x7, x0, x5
    b1e8:	da080021 	sbc	x1, x1, x8
    b1ec:	aa0703e0 	mov	x0, x7
    b1f0:	17ffff81 	b	aff4 <__modti3+0xb4>
    b1f4:	ab000040 	adds	x0, x2, x0
    b1f8:	8b020002 	add	x2, x0, x2
    b1fc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b200:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b204:	17ffff79 	b	afe8 <__modti3+0xa8>
    b208:	9ac82042 	lsl	x2, x2, x8
    b20c:	d2800803 	mov	x3, #0x40                  	// #64
    b210:	cb080063 	sub	x3, x3, x8
    b214:	d360fc49 	lsr	x9, x2, #32
    b218:	9ac82027 	lsl	x7, x1, x8
    b21c:	92407c4a 	and	x10, x2, #0xffffffff
    b220:	9ac32426 	lsr	x6, x1, x3
    b224:	9ac32403 	lsr	x3, x0, x3
    b228:	aa070063 	orr	x3, x3, x7
    b22c:	9ac908c1 	udiv	x1, x6, x9
    b230:	9ac82007 	lsl	x7, x0, x8
    b234:	9b099820 	msub	x0, x1, x9, x6
    b238:	9b017d41 	mul	x1, x10, x1
    b23c:	93c38000 	extr	x0, x0, x3, #32
    b240:	eb00003f 	cmp	x1, x0
    b244:	540000a9 	b.ls	b258 <__modti3+0x318>  // b.plast
    b248:	ab000040 	adds	x0, x2, x0
    b24c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b250:	8b020006 	add	x6, x0, x2
    b254:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b258:	cb010000 	sub	x0, x0, x1
    b25c:	9ac90801 	udiv	x1, x0, x9
    b260:	9b098026 	msub	x6, x1, x9, x0
    b264:	aa0303e0 	mov	x0, x3
    b268:	9b017d41 	mul	x1, x10, x1
    b26c:	b3607cc0 	bfi	x0, x6, #32, #32
    b270:	eb00003f 	cmp	x1, x0
    b274:	540000a9 	b.ls	b288 <__modti3+0x348>  // b.plast
    b278:	ab000040 	adds	x0, x2, x0
    b27c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b280:	8b020003 	add	x3, x0, x2
    b284:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b288:	cb010000 	sub	x0, x0, x1
    b28c:	17ffffb0 	b	b14c <__modti3+0x20c>
    b290:	d1000969 	sub	x9, x11, #0x2
    b294:	8b070021 	add	x1, x1, x7
    b298:	17ffff83 	b	b0a4 <__modti3+0x164>
    b29c:	d1000965 	sub	x5, x11, #0x2
    b2a0:	8b070063 	add	x3, x3, x7
    b2a4:	17ffff74 	b	b074 <__modti3+0x134>
    b2a8:	d503201f 	nop
    b2ac:	d503201f 	nop

000000000000b2b0 <atexit>:
    b2b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b2b4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b2b8:	d2800001 	mov	x1, #0x0                   	// #0
    b2bc:	910003fd 	mov	x29, sp
    b2c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b2c4:	f9400442 	ldr	x2, [x2, #8]
    b2c8:	17ffdd0a 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b2cc <_fini>:
    b2cc:	d503201f 	nop
    b2d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b2d4:	910003fd 	mov	x29, sp
    b2d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b2dc:	d65f03c0 	ret
