
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__divti3+0x160>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912460a5 	add	x5, x5, #0x918
    2a20:	b0000044 	adrp	x4, b000 <__divti3+0x160>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91248084 	add	x4, x4, #0x920
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10690>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2ab4:	9139a000 	add	x0, x0, #0xe68
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x7a0>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91214042 	add	x2, x2, #0x850
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2bfc:	9139e000 	add	x0, x0, #0xe78
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2c0c:	913c6000 	add	x0, x0, #0xf18
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2c24:	913bc000 	add	x0, x0, #0xef0
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2c30:	913b0000 	add	x0, x0, #0xec0
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__divti3+0x160>
    2c3c:	913a6000 	add	x0, x0, #0xe98
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xa40>
    2e34:	91154021 	add	x1, x1, #0x550
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa40>
    30d8:	9114c021 	add	x1, x1, #0x530
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3110:	91172000 	add	x0, x0, #0x5c8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	90000042 	adrp	x2, b000 <__divti3+0x160>
    331c:	91178042 	add	x2, x2, #0x5e0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	90000042 	adrp	x2, b000 <__divti3+0x160>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	9118e042 	add	x2, x2, #0x638
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	90000059 	adrp	x25, b000 <__divti3+0x160>
    33a8:	9000005a 	adrp	x26, b000 <__divti3+0x160>
    33ac:	911a6339 	add	x25, x25, #0x698
    33b0:	9118035a 	add	x26, x26, #0x600
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	9000005b 	adrp	x27, b000 <__divti3+0x160>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	91182377 	add	x23, x27, #0x608
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	911b6000 	add	x0, x0, #0x6d8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	90000043 	adrp	x3, b000 <__divti3+0x160>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	90000055 	adrp	x21, b000 <__divti3+0x160>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	91180063 	add	x3, x3, #0x600
    34a0:	911bc2b5 	add	x21, x21, #0x6f0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	90000040 	adrp	x0, b000 <__divti3+0x160>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	911cc000 	add	x0, x0, #0x730
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	90000040 	adrp	x0, b000 <__divti3+0x160>
    352c:	91184000 	add	x0, x0, #0x610
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	90000040 	adrp	x0, b000 <__divti3+0x160>
    35ec:	91172000 	add	x0, x0, #0x5c8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	90000041 	adrp	x1, b000 <__divti3+0x160>
    3730:	aa1303e0 	mov	x0, x19
    3734:	911ce021 	add	x1, x1, #0x738
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	90000041 	adrp	x1, b000 <__divti3+0x160>
    3744:	aa1303e0 	mov	x0, x19
    3748:	911d0021 	add	x1, x1, #0x740
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	90000041 	adrp	x1, b000 <__divti3+0x160>
    3760:	911d2021 	add	x1, x1, #0x748
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	90000042 	adrp	x2, b000 <__divti3+0x160>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	911d4042 	add	x2, x2, #0x750
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	90000040 	adrp	x0, b000 <__divti3+0x160>
    38d0:	91172000 	add	x0, x0, #0x5c8
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	90000040 	adrp	x0, b000 <__divti3+0x160>
    38f0:	911d8000 	add	x0, x0, #0x760
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3988:	911e0000 	add	x0, x0, #0x780
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3998:	911e8000 	add	x0, x0, #0x7a0
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa40>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc15820 	ldr	q0, [x1, #1376]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3a98:	911f2000 	add	x0, x0, #0x7c8
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3b08:	911fe000 	add	x0, x0, #0x7f8
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	90000044 	adrp	x4, b000 <__divti3+0x160>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	91212084 	add	x4, x4, #0x848
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	90000044 	adrp	x4, b000 <__divti3+0x160>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	91218084 	add	x4, x4, #0x860
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	90000044 	adrp	x4, b000 <__divti3+0x160>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	91214084 	add	x4, x4, #0x850
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3f28:	91190042 	add	x2, x2, #0x640
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	90000041 	adrp	x1, b000 <__divti3+0x160>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	90000040 	adrp	x0, b000 <__divti3+0x160>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	9121a021 	add	x1, x1, #0x868
    3f84:	9121c000 	add	x0, x0, #0x870
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	f0000022 	adrp	x2, b000 <__divti3+0x160>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	91224042 	add	x2, x2, #0x890
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    408c:	91150061 	add	x1, x3, #0x540
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    409c:	91190262 	add	x2, x19, #0x640
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	90000042 	adrp	x2, c000 <_IO_stdin_used+0xa40>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    40cc:	91160021 	add	x1, x1, #0x580
    40d0:	3dc15c43 	ldr	q3, [x2, #1392]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    40fc:	91150063 	add	x3, x3, #0x540
    4100:	91178084 	add	x4, x4, #0x5e0
    4104:	91190266 	add	x6, x19, #0x640
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91190275 	add	x21, x19, #0x640
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    41e8:	91250000 	add	x0, x0, #0x940
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91190273 	add	x19, x19, #0x640
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91018122 	add	x2, x9, #0x60
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91018120 	add	x0, x9, #0x60
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91018129 	add	x9, x9, #0x60
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91118082 	add	x2, x4, #0x460
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91118084 	add	x4, x4, #0x460
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91018042 	add	x2, x2, #0x60
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	f0000021 	adrp	x1, b000 <__divti3+0x160>
    4368:	9125a021 	add	x1, x1, #0x968
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4374:	91254000 	add	x0, x0, #0x950
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91118025 	add	x5, x1, #0x460
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91118021 	add	x1, x1, #0x460
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	f0000021 	adrp	x1, b000 <__divti3+0x160>
    4478:	9125a021 	add	x1, x1, #0x968
    447c:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4480:	91254000 	add	x0, x0, #0x950
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4490:	9126a000 	add	x0, x0, #0x9a8
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    449c:	91262000 	add	x0, x0, #0x988
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    44f4:	91270000 	add	x0, x0, #0x9c0
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910182b7 	add	x23, x21, #0x60
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	91270000 	add	x0, x0, #0x9c0
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910182a0 	add	x0, x21, #0x60
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910182a2 	add	x2, x21, #0x60
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    45e4:	911180a5 	add	x5, x5, #0x460
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4628:	91276000 	add	x0, x0, #0x9d8
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4638:	91282000 	add	x0, x0, #0xa08
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91018281 	add	x1, x20, #0x60
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91018280 	add	x0, x20, #0x60
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91018288 	add	x8, x20, #0x60
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91018281 	add	x1, x20, #0x60
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    485c:	9128a000 	add	x0, x0, #0xa28
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	911902a2 	add	x2, x21, #0x640
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4914:	912a0000 	add	x0, x0, #0xa80
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	911902b5 	add	x21, x21, #0x640
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4970:	91296000 	add	x0, x0, #0xa58
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4980:	912aa000 	add	x0, x0, #0xaa8
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    49c0:	91190262 	add	x2, x19, #0x640
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	91190273 	add	x19, x19, #0x640
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	f0000020 	adrp	x0, b000 <__divti3+0x160>
    4a20:	912a0000 	add	x0, x0, #0xa80
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4a40:	911902c2 	add	x2, x22, #0x640
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	911902c2 	add	x2, x22, #0x640
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	911902d6 	add	x22, x22, #0x640
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4b60:	911902b5 	add	x21, x21, #0x640
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c24:	911902a1 	add	x1, x21, #0x640
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	911902b5 	add	x21, x21, #0x640
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	911902a1 	add	x1, x21, #0x640
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	911902a0 	add	x0, x21, #0x640
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	911902b5 	add	x21, x21, #0x640
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e28:	91190359 	add	x25, x26, #0x640
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910182f7 	add	x23, x23, #0x60
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	54000eab 	b.lt	5610 <fwp_p_ad_push+0x1dc>  // b.tstop
    5440:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5444:	aa0003e4 	mov	x4, x0
    5448:	910003fd 	mov	x29, sp
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0003f5 	mov	x21, x0
    5454:	aa020000 	orr	x0, x0, x2
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f7 	mov	x23, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	b6f80920 	tbz	x0, #63, 5590 <fwp_p_ad_push+0x15c>
    5470:	a90153f3 	stp	x19, x20, [sp, #16]
    5474:	9360fc80 	asr	x0, x4, #32
    5478:	b6f800c4 	tbz	x4, #63, 5490 <fwp_p_ad_push+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc40 	asr	x0, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5490:	97fff988 	bl	3ab0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5001240 	cbnz	x0, 56e4 <fwp_p_ad_push+0x2b0>
    54a0:	f9400a76 	ldr	x22, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002df 	cmp	x22, x0
    54ac:	54000d8c 	b.gt	565c <fwp_p_ad_push+0x228>
    54b0:	eb3542df 	cmp	x22, w21, uxtw
    54b4:	54000cad 	b.le	5648 <fwp_p_ad_push+0x214>
    54b8:	b7f80077 	tbnz	x23, #63, 54c4 <fwp_p_ad_push+0x90>
    54bc:	eb3742df 	cmp	x22, w23, uxtw
    54c0:	54000c4d 	b.le	5648 <fwp_p_ad_push+0x214>
    54c4:	f9400678 	ldr	x24, [x19, #8]
    54c8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54cc:	cb1802d8 	sub	x24, x22, x24
    54d0:	91000701 	add	x1, x24, #0x1
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000c28 	b.hi	565c <fwp_p_ad_push+0x228>  // b.pmore
    54dc:	a9418274 	ldp	x20, x0, [x19, #24]
    54e0:	a90573fb 	stp	x27, x28, [sp, #80]
    54e4:	eb14003f 	cmp	x1, x20
    54e8:	540006ad 	b.le	55bc <fwp_p_ad_push+0x188>
    54ec:	f100029f 	cmp	x20, #0x0
    54f0:	d2800803 	mov	x3, #0x40                  	// #64
    54f4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54fc:	a9046bf9 	stp	x25, x26, [sp, #64]
    5500:	eb14003f 	cmp	x1, x20
    5504:	5400008d 	b.le	5514 <fwp_p_ad_push+0xe0>
    5508:	eb02029f 	cmp	x20, x2
    550c:	5400054d 	b.le	55b4 <fwp_p_ad_push+0x180>
    5510:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5514:	d37df299 	lsl	x25, x20, #3
    5518:	52800022 	mov	w2, #0x1                   	// #1
    551c:	aa1903e1 	mov	x1, x25
    5520:	97fffbad 	bl	43d4 <ad_raw_realloc>
    5524:	aa0003e1 	mov	x1, x0
    5528:	b4000a40 	cbz	x0, 5670 <fwp_p_ad_push+0x23c>
    552c:	f9400e63 	ldr	x3, [x19, #24]
    5530:	f9001261 	str	x1, [x19, #32]
    5534:	f9401a60 	ldr	x0, [x19, #48]
    5538:	52800042 	mov	w2, #0x2                   	// #2
    553c:	8b030821 	add	x1, x1, x3, lsl #2
    5540:	f9001661 	str	x1, [x19, #40]
    5544:	d37cee81 	lsl	x1, x20, #4
    5548:	97fffba3 	bl	43d4 <ad_raw_realloc>
    554c:	aa0003e2 	mov	x2, x0
    5550:	b4000900 	cbz	x0, 5670 <fwp_p_ad_push+0x23c>
    5554:	f9400e61 	ldr	x1, [x19, #24]
    5558:	d37df31b 	lsl	x27, x24, #3
    555c:	d37ef69a 	lsl	x26, x20, #2
    5560:	d37ef71c 	lsl	x28, x24, #2
    5564:	8b190003 	add	x3, x0, x25
    5568:	8b010c01 	add	x1, x0, x1, lsl #3
    556c:	a9030660 	stp	x0, x1, [x19, #48]
    5570:	b5000558 	cbnz	x24, 5618 <fwp_p_ad_push+0x1e4>
    5574:	f9001e63 	str	x3, [x19, #56]
    5578:	f9401260 	ldr	x0, [x19, #32]
    557c:	8b1a0001 	add	x1, x0, x26
    5580:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5584:	f9000e74 	str	x20, [x19, #24]
    5588:	f9001661 	str	x1, [x19, #40]
    558c:	14000010 	b	55cc <fwp_p_ad_push+0x198>
    5590:	9360fc40 	asr	x0, x2, #32
    5594:	a90153f3 	stp	x19, x20, [sp, #16]
    5598:	eb84801f 	cmp	x0, x4, asr #32
    559c:	54fff7a0 	b.eq	5490 <fwp_p_ad_push+0x5c>  // b.none
    55a0:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    55a4:	912b2000 	add	x0, x0, #0xac8
    55a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55ac:	a90573fb 	stp	x27, x28, [sp, #80]
    55b0:	97fff874 	bl	3780 <fwp_trap>
    55b4:	d37ffa94 	lsl	x20, x20, #1
    55b8:	17ffffd2 	b	5500 <fwp_p_ad_push+0xcc>
    55bc:	a9428a61 	ldp	x1, x2, [x19, #40]
    55c0:	d37ef71c 	lsl	x28, x24, #2
    55c4:	f9401e63 	ldr	x3, [x19, #56]
    55c8:	d37df31b 	lsl	x27, x24, #3
    55cc:	b83c6815 	str	w21, [x0, x28]
    55d0:	f10002ff 	cmp	x23, #0x0
    55d4:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55d8:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55dc:	fc3b6849 	str	d9, [x2, x27]
    55e0:	aa1602a0 	orr	x0, x21, x22
    55e4:	b83c6837 	str	w23, [x1, x28]
    55e8:	910006d6 	add	x22, x22, #0x1
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	fc3b6868 	str	d8, [x3, x27]
    55f4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55f8:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55fc:	f9000a76 	str	x22, [x19, #16]
    5600:	a94153f3 	ldp	x19, x20, [sp, #16]
    5604:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5608:	a8c77bfd 	ldp	x29, x30, [sp], #112
    560c:	d65f03c0 	ret
    5610:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5614:	d65f03c0 	ret
    5618:	aa0303e0 	mov	x0, x3
    561c:	aa1b03e2 	mov	x2, x27
    5620:	97fff418 	bl	2680 <memmove@plt>
    5624:	a9420660 	ldp	x0, x1, [x19, #32]
    5628:	aa1c03e2 	mov	x2, x28
    562c:	f9401a63 	ldr	x3, [x19, #48]
    5630:	8b190063 	add	x3, x3, x25
    5634:	f9001e63 	str	x3, [x19, #56]
    5638:	8b1a0000 	add	x0, x0, x26
    563c:	97fff411 	bl	2680 <memmove@plt>
    5640:	a9430e62 	ldp	x2, x3, [x19, #48]
    5644:	17ffffcd 	b	5578 <fwp_p_ad_push+0x144>
    5648:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    564c:	912d8000 	add	x0, x0, #0xb60
    5650:	a9046bf9 	stp	x25, x26, [sp, #64]
    5654:	a90573fb 	stp	x27, x28, [sp, #80]
    5658:	97fff84a 	bl	3780 <fwp_trap>
    565c:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    5660:	912d0000 	add	x0, x0, #0xb40
    5664:	a9046bf9 	stp	x25, x26, [sp, #64]
    5668:	a90573fb 	stp	x27, x28, [sp, #80]
    566c:	97fff845 	bl	3780 <fwp_trap>
    5670:	aa1303e0 	mov	x0, x19
    5674:	97fff648 	bl	2f94 <fwp_tape_unlink_scope>
    5678:	f9401260 	ldr	x0, [x19, #32]
    567c:	b4000040 	cbz	x0, 5684 <fwp_p_ad_push+0x250>
    5680:	97fffb20 	bl	4300 <ad_raw_free.part.0>
    5684:	f9401a60 	ldr	x0, [x19, #48]
    5688:	b4000040 	cbz	x0, 5690 <fwp_p_ad_push+0x25c>
    568c:	97fffb1d 	bl	4300 <ad_raw_free.part.0>
    5690:	f9402260 	ldr	x0, [x19, #64]
    5694:	b4000040 	cbz	x0, 569c <fwp_p_ad_push+0x268>
    5698:	97fffb1a 	bl	4300 <ad_raw_free.part.0>
    569c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56a0:	f947e821 	ldr	x1, [x1, #4048]
    56a4:	f9000e7f 	str	xzr, [x19, #24]
    56a8:	4f000400 	movi	v0.4s, #0x0
    56ac:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56b0:	d2800262 	mov	x2, #0x13                  	// #19
    56b4:	f9400023 	ldr	x3, [x1]
    56b8:	b900067f 	str	wzr, [x19, #4]
    56bc:	d2800021 	mov	x1, #0x1                   	// #1
    56c0:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    56c4:	91172000 	add	x0, x0, #0x5c8
    56c8:	3c808260 	stur	q0, [x19, #8]
    56cc:	ad010260 	stp	q0, q0, [x19, #32]
    56d0:	97fff490 	bl	2910 <fwrite@plt>
    56d4:	d2800000 	mov	x0, #0x0                   	// #0
    56d8:	97fff49a 	bl	2940 <fflush@plt>
    56dc:	52800cc0 	mov	w0, #0x66                  	// #102
    56e0:	97fff4a8 	bl	2980 <_Exit@plt>
    56e4:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    56e8:	912c4000 	add	x0, x0, #0xb10
    56ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    56f0:	a90573fb 	stp	x27, x28, [sp, #80]
    56f4:	97fff823 	bl	3780 <fwp_trap>
    56f8:	d503201f 	nop
    56fc:	d503201f 	nop

0000000000005700 <w107>:
    5700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5704:	9e660003 	fmov	x3, d0
    5708:	aa0003e2 	mov	x2, x0
    570c:	910003fd 	mov	x29, sp
    5710:	6d0327e8 	stp	d8, d9, [sp, #48]
    5714:	1e604028 	fmov	d8, d1
    5718:	1e600809 	fmul	d9, d0, d0
    571c:	fd0023ea 	str	d10, [sp, #64]
    5720:	1e60400a 	fmov	d10, d0
    5724:	a90153f3 	stp	x19, x20, [sp, #16]
    5728:	aa0003f3 	mov	x19, x0
    572c:	aa0103f4 	mov	x20, x1
    5730:	aa0303e1 	mov	x1, x3
    5734:	a9025bf5 	stp	x21, x22, [sp, #32]
    5738:	97ffff3f 	bl	5434 <fwp_p_ad_push>
    573c:	1e693908 	fsub	d8, d8, d9
    5740:	aa1403e2 	mov	x2, x20
    5744:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5748:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    574c:	9e660116 	fmov	x22, d8
    5750:	97ffff39 	bl	5434 <fwp_p_ad_push>
    5754:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5758:	aa0003e1 	mov	x1, x0
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	aa1303e0 	mov	x0, x19
    5764:	1e6a3929 	fsub	d9, d9, d10
    5768:	aa0103f3 	mov	x19, x1
    576c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5770:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5774:	9e660135 	fmov	x21, d9
    5778:	97ffff2f 	bl	5434 <fwp_p_ad_push>
    577c:	1e680908 	fmul	d8, d8, d8
    5780:	aa0003f4 	mov	x20, x0
    5784:	aa1603e3 	mov	x3, x22
    5788:	aa1603e1 	mov	x1, x22
    578c:	aa1303e2 	mov	x2, x19
    5790:	aa1303e0 	mov	x0, x19
    5794:	97ffff28 	bl	5434 <fwp_p_ad_push>
    5798:	aa0003e2 	mov	x2, x0
    579c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57a0:	9e670020 	fmov	d0, x1
    57a4:	9e660101 	fmov	x1, d8
    57a8:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57ac:	1e600908 	fmul	d8, d8, d0
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	97ffff20 	bl	5434 <fwp_p_ad_push>
    57b8:	1e690929 	fmul	d9, d9, d9
    57bc:	aa0003f3 	mov	x19, x0
    57c0:	aa1503e3 	mov	x3, x21
    57c4:	aa1503e1 	mov	x1, x21
    57c8:	aa1403e2 	mov	x2, x20
    57cc:	aa1403e0 	mov	x0, x20
    57d0:	97ffff19 	bl	5434 <fwp_p_ad_push>
    57d4:	1e692908 	fadd	d8, d8, d9
    57d8:	aa1303e2 	mov	x2, x19
    57dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57e0:	aa0303e1 	mov	x1, x3
    57e4:	97ffff14 	bl	5434 <fwp_p_ad_push>
    57e8:	aa0003e1 	mov	x1, x0
    57ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    57f0:	9e660100 	fmov	x0, d8
    57f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57f8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57fc:	fd4023ea 	ldr	d10, [sp, #64]
    5800:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5804:	d65f03c0 	ret
    5808:	d503201f 	nop
    580c:	d503201f 	nop

0000000000005810 <fwp_data.part.0.constprop.0>:
    5810:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5814:	910003fd 	mov	x29, sp
    5818:	a9025bf5 	stp	x21, x22, [sp, #32]
    581c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5820:	910182c2 	add	x2, x22, #0x60
    5824:	a9046bf9 	stp	x25, x26, [sp, #64]
    5828:	b9413059 	ldr	w25, [x2, #304]
    582c:	a90153f3 	stp	x19, x20, [sp, #16]
    5830:	aa0103f4 	mov	x20, x1
    5834:	a90363f7 	stp	x23, x24, [sp, #48]
    5838:	2a0003f7 	mov	w23, w0
    583c:	340000b9 	cbz	w25, 5850 <fwp_data.part.0.constprop.0+0x40>
    5840:	a9538041 	ldp	x1, x0, [x2, #312]
    5844:	91000421 	add	x1, x1, #0x1
    5848:	91006000 	add	x0, x0, #0x18
    584c:	a9138041 	stp	x1, x0, [x2, #312]
    5850:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5854:	911902a3 	add	x3, x21, #0x640
    5858:	b953a460 	ldr	w0, [x3, #5028]
    585c:	34000840 	cbz	w0, 5964 <fwp_data.part.0.constprop.0+0x154>
    5860:	397e8862 	ldrb	w2, [x3, #4002]
    5864:	910f0040 	add	x0, x2, #0x3c0
    5868:	8b020442 	add	x2, x2, x2, lsl #1
    586c:	d37df042 	lsl	x2, x2, #3
    5870:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5874:	2a1a03f8 	mov	w24, w26
    5878:	f8626873 	ldr	x19, [x3, x2]
    587c:	b4000613 	cbz	x19, 593c <fwp_data.part.0.constprop.0+0x12c>
    5880:	f9400260 	ldr	x0, [x19]
    5884:	aa2003e0 	mvn	x0, x0
    5888:	f8226860 	str	x0, [x3, x2]
    588c:	f100631f 	cmp	x24, #0x18
    5890:	540000e9 	b.ls	58ac <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5894:	d1006702 	sub	x2, x24, #0x19
    5898:	91006260 	add	x0, x19, #0x18
    589c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    58a0:	52800001 	mov	w1, #0x0                   	// #0
    58a4:	91002042 	add	x2, x2, #0x8
    58a8:	97fff3ce 	bl	27e0 <memset@plt>
    58ac:	911902a0 	add	x0, x21, #0x640
    58b0:	f94a1001 	ldr	x1, [x0, #5152]
    58b4:	ab180021 	adds	x1, x1, x24
    58b8:	54000642 	b.cs	5980 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    58bc:	f94a1402 	ldr	x2, [x0, #5160]
    58c0:	f90a1001 	str	x1, [x0, #5152]
    58c4:	eb02003f 	cmp	x1, x2
    58c8:	54000049 	b.ls	58d0 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    58cc:	f90a1401 	str	x1, [x0, #5160]
    58d0:	911902a0 	add	x0, x21, #0x640
    58d4:	1e630341 	ucvtf	d1, w26
    58d8:	fd4a1c00 	ldr	d0, [x0, #5176]
    58dc:	1e612800 	fadd	d0, d0, d1
    58e0:	fd0a1c00 	str	d0, [x0, #5176]
    58e4:	34000139 	cbz	w25, 5908 <fwp_data.part.0.constprop.0+0xf8>
    58e8:	911902b5 	add	x21, x21, #0x640
    58ec:	910182d6 	add	x22, x22, #0x60
    58f0:	fd4a12a0 	ldr	d0, [x21, #5152]
    58f4:	6d5486c2 	ldp	d2, d1, [x22, #328]
    58f8:	7e61d800 	ucvtf	d0, d0
    58fc:	1e623800 	fsub	d0, d0, d2
    5900:	1e612010 	fcmpe	d0, d1
    5904:	540003ac 	b.gt	5978 <fwp_data.part.0.constprop.0+0x168>
    5908:	52800040 	mov	w0, #0x2                   	// #2
    590c:	29000277 	stp	w23, w0, [x19]
    5910:	aa1303e0 	mov	x0, x19
    5914:	f9400281 	ldr	x1, [x20]
    5918:	f9000661 	str	x1, [x19, #8]
    591c:	f9400681 	ldr	x1, [x20, #8]
    5920:	f9000a61 	str	x1, [x19, #16]
    5924:	a94153f3 	ldp	x19, x20, [sp, #16]
    5928:	a9425bf5 	ldp	x21, x22, [sp, #32]
    592c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5930:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5938:	d65f03c0 	ret
    593c:	8b020063 	add	x3, x3, x2
    5940:	f9400473 	ldr	x19, [x3, #8]
    5944:	b4000113 	cbz	x19, 5964 <fwp_data.part.0.constprop.0+0x154>
    5948:	f9400860 	ldr	x0, [x3, #16]
    594c:	cb130000 	sub	x0, x0, x19
    5950:	eb00031f 	cmp	x24, x0
    5954:	54000088 	b.hi	5964 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5958:	8b180260 	add	x0, x19, x24
    595c:	f9000460 	str	x0, [x3, #8]
    5960:	17ffffcb 	b	588c <fwp_data.part.0.constprop.0+0x7c>
    5964:	52800001 	mov	w1, #0x0                   	// #0
    5968:	d2800300 	mov	x0, #0x18                  	// #24
    596c:	97fffdc9 	bl	5090 <fwp_heap_alloc>
    5970:	aa0003f3 	mov	x19, x0
    5974:	17ffffdc 	b	58e4 <fwp_data.part.0.constprop.0+0xd4>
    5978:	fd00aac0 	str	d0, [x22, #336]
    597c:	17ffffe3 	b	5908 <fwp_data.part.0.constprop.0+0xf8>
    5980:	97fff5dc 	bl	30f0 <fwp_heap_oom>

0000000000005984 <fwp_rc_share>:
    5984:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5988:	91190042 	add	x2, x2, #0x640
    598c:	f949d843 	ldr	x3, [x2, #5040]
    5990:	f949ec41 	ldr	x1, [x2, #5080]
    5994:	cb030000 	sub	x0, x0, x3
    5998:	eb01401f 	cmp	x0, x1, lsl #16
    599c:	540002c2 	b.cs	59f4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59a0:	d350fc01 	lsr	x1, x0, #16
    59a4:	f949fc44 	ldr	x4, [x2, #5112]
    59a8:	8b010821 	add	x1, x1, x1, lsl #2
    59ac:	d37df021 	lsl	x1, x1, #3
    59b0:	8b010083 	add	x3, x4, x1
    59b4:	f9401062 	ldr	x2, [x3, #32]
    59b8:	b40001e2 	cbz	x2, 59f4 <fwp_rc_share+0x70>
    59bc:	38616881 	ldrb	w1, [x4, x1]
    59c0:	7100083f 	cmp	w1, #0x2
    59c4:	540001a0 	b.eq	59f8 <fwp_rc_share+0x74>  // b.none
    59c8:	7100043f 	cmp	w1, #0x1
    59cc:	54000141 	b.ne	59f4 <fwp_rc_share+0x70>  // b.any
    59d0:	29430464 	ldp	w4, w1, [x3, #24]
    59d4:	92403c00 	and	x0, x0, #0xffff
    59d8:	9b047c00 	mul	x0, x0, x4
    59dc:	d360fc00 	lsr	x0, x0, #32
    59e0:	eb01001f 	cmp	x0, x1
    59e4:	54000082 	b.cs	59f4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59e8:	8b000042 	add	x2, x2, x0
    59ec:	39400040 	ldrb	w0, [x2]
    59f0:	350000a0 	cbnz	w0, 5a04 <fwp_rc_share+0x80>
    59f4:	d65f03c0 	ret
    59f8:	72003c1f 	tst	w0, #0xffff
    59fc:	54ffff80 	b.eq	59ec <fwp_rc_share+0x68>  // b.none
    5a00:	d65f03c0 	ret
    5a04:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5a08:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    5a0c:	912e0000 	add	x0, x0, #0xb80
    5a10:	910003fd 	mov	x29, sp
    5a14:	97fff75b 	bl	3780 <fwp_trap>
    5a18:	d503201f 	nop
    5a1c:	d503201f 	nop

0000000000005a20 <fwp_rc_free_arr>:
    5a20:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5a24:	91190063 	add	x3, x3, #0x640
    5a28:	f949d861 	ldr	x1, [x3, #5040]
    5a2c:	f949ec62 	ldr	x2, [x3, #5080]
    5a30:	cb010001 	sub	x1, x0, x1
    5a34:	eb02403f 	cmp	x1, x2, lsl #16
    5a38:	54000342 	b.cs	5aa0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a3c:	d350fc22 	lsr	x2, x1, #16
    5a40:	f949fc65 	ldr	x5, [x3, #5112]
    5a44:	8b020842 	add	x2, x2, x2, lsl #2
    5a48:	d37df042 	lsl	x2, x2, #3
    5a4c:	8b0200a4 	add	x4, x5, x2
    5a50:	f9401083 	ldr	x3, [x4, #32]
    5a54:	b4000263 	cbz	x3, 5aa0 <fwp_rc_free_arr+0x80>
    5a58:	386268a2 	ldrb	w2, [x5, x2]
    5a5c:	7100085f 	cmp	w2, #0x2
    5a60:	540001c0 	b.eq	5a98 <fwp_rc_free_arr+0x78>  // b.none
    5a64:	7100045f 	cmp	w2, #0x1
    5a68:	540001c1 	b.ne	5aa0 <fwp_rc_free_arr+0x80>  // b.any
    5a6c:	29430885 	ldp	w5, w2, [x4, #24]
    5a70:	92403c21 	and	x1, x1, #0xffff
    5a74:	9b057c21 	mul	x1, x1, x5
    5a78:	d360fc21 	lsr	x1, x1, #32
    5a7c:	eb02003f 	cmp	x1, x2
    5a80:	54000102 	b.cs	5aa0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a84:	8b010063 	add	x3, x3, x1
    5a88:	39400061 	ldrb	w1, [x3]
    5a8c:	7100043f 	cmp	w1, #0x1
    5a90:	54000081 	b.ne	5aa0 <fwp_rc_free_arr+0x80>  // b.any
    5a94:	17fffc5f 	b	4c10 <fwp_mem_free>
    5a98:	72003c3f 	tst	w1, #0xffff
    5a9c:	54ffff60 	b.eq	5a88 <fwp_rc_free_arr+0x68>  // b.none
    5aa0:	d65f03c0 	ret

0000000000005aa4 <fwp_rc_dup>:
    5aa4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5aa8:	91190042 	add	x2, x2, #0x640
    5aac:	f949d841 	ldr	x1, [x2, #5040]
    5ab0:	f949ec43 	ldr	x3, [x2, #5080]
    5ab4:	cb010001 	sub	x1, x0, x1
    5ab8:	eb03403f 	cmp	x1, x3, lsl #16
    5abc:	540003c2 	b.cs	5b34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5ac0:	d350fc20 	lsr	x0, x1, #16
    5ac4:	f949fc44 	ldr	x4, [x2, #5112]
    5ac8:	8b000800 	add	x0, x0, x0, lsl #2
    5acc:	d37df002 	lsl	x2, x0, #3
    5ad0:	8b020083 	add	x3, x4, x2
    5ad4:	f9401060 	ldr	x0, [x3, #32]
    5ad8:	b40002e0 	cbz	x0, 5b34 <fwp_rc_dup+0x90>
    5adc:	38626882 	ldrb	w2, [x4, x2]
    5ae0:	7100085f 	cmp	w2, #0x2
    5ae4:	540002a0 	b.eq	5b38 <fwp_rc_dup+0x94>  // b.none
    5ae8:	7100045f 	cmp	w2, #0x1
    5aec:	54000241 	b.ne	5b34 <fwp_rc_dup+0x90>  // b.any
    5af0:	29430864 	ldp	w4, w2, [x3, #24]
    5af4:	92403c21 	and	x1, x1, #0xffff
    5af8:	9b047c21 	mul	x1, x1, x4
    5afc:	d360fc21 	lsr	x1, x1, #32
    5b00:	eb02003f 	cmp	x1, x2
    5b04:	54000182 	b.cs	5b34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b08:	8b010000 	add	x0, x0, x1
    5b0c:	39400001 	ldrb	w1, [x0]
    5b10:	34000121 	cbz	w1, 5b34 <fwp_rc_dup+0x90>
    5b14:	f00000c2 	adrp	x2, 20000 <__data_start>
    5b18:	91018042 	add	x2, x2, #0x60
    5b1c:	b9413043 	ldr	w3, [x2, #304]
    5b20:	35000123 	cbnz	w3, 5b44 <fwp_rc_dup+0xa0>
    5b24:	7103f43f 	cmp	w1, #0xfd
    5b28:	54000168 	b.hi	5b54 <fwp_rc_dup+0xb0>  // b.pmore
    5b2c:	11000421 	add	w1, w1, #0x1
    5b30:	39000001 	strb	w1, [x0]
    5b34:	d65f03c0 	ret
    5b38:	72003c3f 	tst	w1, #0xffff
    5b3c:	54fffe80 	b.eq	5b0c <fwp_rc_dup+0x68>  // b.none
    5b40:	d65f03c0 	ret
    5b44:	f940ac43 	ldr	x3, [x2, #344]
    5b48:	91000463 	add	x3, x3, #0x1
    5b4c:	f900ac43 	str	x3, [x2, #344]
    5b50:	17fffff5 	b	5b24 <fwp_rc_dup+0x80>
    5b54:	17fffb48 	b	4874 <fwp_rc_wide_dup>
    5b58:	d503201f 	nop
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_owned_entry161>:
    5b60:	d10103ff 	sub	sp, sp, #0x40
    5b64:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5b68:	f947f442 	ldr	x2, [x2, #4072]
    5b6c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b70:	910083fd 	add	x29, sp, #0x20
    5b74:	a90353f3 	stp	x19, x20, [sp, #48]
    5b78:	f9400043 	ldr	x3, [x2]
    5b7c:	f9000fe3 	str	x3, [sp, #24]
    5b80:	d2800003 	mov	x3, #0x0                   	// #0
    5b84:	a9400c01 	ldp	x1, x3, [x0]
    5b88:	f9400802 	ldr	x2, [x0, #16]
    5b8c:	ab020022 	adds	x2, x1, x2
    5b90:	540006e6 	b.vs	5c6c <fwp_owned_entry161+0x10c>
    5b94:	910023e1 	add	x1, sp, #0x8
    5b98:	52800000 	mov	w0, #0x0                   	// #0
    5b9c:	a9008be3 	stp	x3, x2, [sp, #8]
    5ba0:	97ffff1c 	bl	5810 <fwp_data.part.0.constprop.0>
    5ba4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ba8:	91190063 	add	x3, x3, #0x640
    5bac:	aa0003f3 	mov	x19, x0
    5bb0:	f949d861 	ldr	x1, [x3, #5040]
    5bb4:	f949ec60 	ldr	x0, [x3, #5080]
    5bb8:	cb010261 	sub	x1, x19, x1
    5bbc:	eb00403f 	cmp	x1, x0, lsl #16
    5bc0:	54000322 	b.cs	5c24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5bc4:	d350fc22 	lsr	x2, x1, #16
    5bc8:	f949fc63 	ldr	x3, [x3, #5112]
    5bcc:	8b020842 	add	x2, x2, x2, lsl #2
    5bd0:	d37df042 	lsl	x2, x2, #3
    5bd4:	8b020060 	add	x0, x3, x2
    5bd8:	f9401014 	ldr	x20, [x0, #32]
    5bdc:	b4000254 	cbz	x20, 5c24 <fwp_owned_entry161+0xc4>
    5be0:	38626862 	ldrb	w2, [x3, x2]
    5be4:	7100085f 	cmp	w2, #0x2
    5be8:	54000360 	b.eq	5c54 <fwp_owned_entry161+0xf4>  // b.none
    5bec:	7100045f 	cmp	w2, #0x1
    5bf0:	540001a1 	b.ne	5c24 <fwp_owned_entry161+0xc4>  // b.any
    5bf4:	29430002 	ldp	w2, w0, [x0, #24]
    5bf8:	92403c21 	and	x1, x1, #0xffff
    5bfc:	9b027c21 	mul	x1, x1, x2
    5c00:	d360fc21 	lsr	x1, x1, #32
    5c04:	eb00003f 	cmp	x1, x0
    5c08:	540000e2 	b.cs	5c24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5c0c:	8b010294 	add	x20, x20, x1
    5c10:	39400280 	ldrb	w0, [x20]
    5c14:	7103fc1f 	cmp	w0, #0xff
    5c18:	54000240 	b.eq	5c60 <fwp_owned_entry161+0x100>  // b.none
    5c1c:	52800020 	mov	w0, #0x1                   	// #1
    5c20:	39000280 	strb	w0, [x20]
    5c24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5c28:	f947f400 	ldr	x0, [x0, #4072]
    5c2c:	f9400fe2 	ldr	x2, [sp, #24]
    5c30:	f9400001 	ldr	x1, [x0]
    5c34:	eb010042 	subs	x2, x2, x1
    5c38:	d2800001 	mov	x1, #0x0                   	// #0
    5c3c:	540001a1 	b.ne	5c70 <fwp_owned_entry161+0x110>  // b.any
    5c40:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c44:	aa1303e0 	mov	x0, x19
    5c48:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c4c:	910103ff 	add	sp, sp, #0x40
    5c50:	d65f03c0 	ret
    5c54:	72003c3f 	tst	w1, #0xffff
    5c58:	54fffe61 	b.ne	5c24 <fwp_owned_entry161+0xc4>  // b.any
    5c5c:	17ffffed 	b	5c10 <fwp_owned_entry161+0xb0>
    5c60:	aa1403e0 	mov	x0, x20
    5c64:	97fffb4b 	bl	4990 <fwp_rc_forget_slot>
    5c68:	17ffffed 	b	5c1c <fwp_owned_entry161+0xbc>
    5c6c:	97fff365 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5c70:	97fff2e8 	bl	2810 <__stack_chk_fail@plt>

0000000000005c74 <e161>:
    5c74:	d10103ff 	sub	sp, sp, #0x40
    5c78:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5c7c:	f947f442 	ldr	x2, [x2, #4072]
    5c80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c84:	910083fd 	add	x29, sp, #0x20
    5c88:	a90353f3 	stp	x19, x20, [sp, #48]
    5c8c:	f9400043 	ldr	x3, [x2]
    5c90:	f9000fe3 	str	x3, [sp, #24]
    5c94:	d2800003 	mov	x3, #0x0                   	// #0
    5c98:	a9400c01 	ldp	x1, x3, [x0]
    5c9c:	f9400802 	ldr	x2, [x0, #16]
    5ca0:	ab020022 	adds	x2, x1, x2
    5ca4:	54000726 	b.vs	5d88 <e161+0x114>
    5ca8:	910023e1 	add	x1, sp, #0x8
    5cac:	52800000 	mov	w0, #0x0                   	// #0
    5cb0:	a9008be3 	stp	x3, x2, [sp, #8]
    5cb4:	97fffed7 	bl	5810 <fwp_data.part.0.constprop.0>
    5cb8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5cbc:	91190063 	add	x3, x3, #0x640
    5cc0:	aa0003f3 	mov	x19, x0
    5cc4:	f949d861 	ldr	x1, [x3, #5040]
    5cc8:	f949ec60 	ldr	x0, [x3, #5080]
    5ccc:	cb010261 	sub	x1, x19, x1
    5cd0:	eb00403f 	cmp	x1, x0, lsl #16
    5cd4:	54000322 	b.cs	5d38 <e161+0xc4>  // b.hs, b.nlast
    5cd8:	d350fc22 	lsr	x2, x1, #16
    5cdc:	f949fc63 	ldr	x3, [x3, #5112]
    5ce0:	8b020842 	add	x2, x2, x2, lsl #2
    5ce4:	d37df042 	lsl	x2, x2, #3
    5ce8:	8b020060 	add	x0, x3, x2
    5cec:	f9401014 	ldr	x20, [x0, #32]
    5cf0:	b4000254 	cbz	x20, 5d38 <e161+0xc4>
    5cf4:	38626862 	ldrb	w2, [x3, x2]
    5cf8:	7100085f 	cmp	w2, #0x2
    5cfc:	540003a0 	b.eq	5d70 <e161+0xfc>  // b.none
    5d00:	7100045f 	cmp	w2, #0x1
    5d04:	540001a1 	b.ne	5d38 <e161+0xc4>  // b.any
    5d08:	29430002 	ldp	w2, w0, [x0, #24]
    5d0c:	92403c21 	and	x1, x1, #0xffff
    5d10:	9b027c21 	mul	x1, x1, x2
    5d14:	d360fc21 	lsr	x1, x1, #32
    5d18:	eb00003f 	cmp	x1, x0
    5d1c:	540000e2 	b.cs	5d38 <e161+0xc4>  // b.hs, b.nlast
    5d20:	8b010294 	add	x20, x20, x1
    5d24:	39400280 	ldrb	w0, [x20]
    5d28:	7103fc1f 	cmp	w0, #0xff
    5d2c:	54000280 	b.eq	5d7c <e161+0x108>  // b.none
    5d30:	52800020 	mov	w0, #0x1                   	// #1
    5d34:	39000280 	strb	w0, [x20]
    5d38:	aa1303e0 	mov	x0, x19
    5d3c:	97ffff12 	bl	5984 <fwp_rc_share>
    5d40:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5d44:	f947f400 	ldr	x0, [x0, #4072]
    5d48:	f9400fe2 	ldr	x2, [sp, #24]
    5d4c:	f9400001 	ldr	x1, [x0]
    5d50:	eb010042 	subs	x2, x2, x1
    5d54:	d2800001 	mov	x1, #0x0                   	// #0
    5d58:	540001a1 	b.ne	5d8c <e161+0x118>  // b.any
    5d5c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d68:	910103ff 	add	sp, sp, #0x40
    5d6c:	d65f03c0 	ret
    5d70:	72003c3f 	tst	w1, #0xffff
    5d74:	54fffe21 	b.ne	5d38 <e161+0xc4>  // b.any
    5d78:	17ffffeb 	b	5d24 <e161+0xb0>
    5d7c:	aa1403e0 	mov	x0, x20
    5d80:	97fffb04 	bl	4990 <fwp_rc_forget_slot>
    5d84:	17ffffeb 	b	5d30 <e161+0xbc>
    5d88:	97fff31e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5d8c:	97fff2a1 	bl	2810 <__stack_chk_fail@plt>

0000000000005d90 <fwp_drop0>:
    5d90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d94:	910003fd 	mov	x29, sp
    5d98:	a90153f3 	stp	x19, x20, [sp, #16]
    5d9c:	f90013f5 	str	x21, [sp, #32]
    5da0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5da4:	911902b4 	add	x20, x21, #0x640
    5da8:	f949da81 	ldr	x1, [x20, #5040]
    5dac:	f949ee82 	ldr	x2, [x20, #5080]
    5db0:	cb010001 	sub	x1, x0, x1
    5db4:	eb02403f 	cmp	x1, x2, lsl #16
    5db8:	54000382 	b.cs	5e28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5dbc:	d350fc22 	lsr	x2, x1, #16
    5dc0:	f949fe84 	ldr	x4, [x20, #5112]
    5dc4:	8b020842 	add	x2, x2, x2, lsl #2
    5dc8:	d37df042 	lsl	x2, x2, #3
    5dcc:	8b020083 	add	x3, x4, x2
    5dd0:	f9401073 	ldr	x19, [x3, #32]
    5dd4:	b40002b3 	cbz	x19, 5e28 <fwp_drop0+0x98>
    5dd8:	38626882 	ldrb	w2, [x4, x2]
    5ddc:	7100085f 	cmp	w2, #0x2
    5de0:	540002c0 	b.eq	5e38 <fwp_drop0+0xa8>  // b.none
    5de4:	7100045f 	cmp	w2, #0x1
    5de8:	54000201 	b.ne	5e28 <fwp_drop0+0x98>  // b.any
    5dec:	29430864 	ldp	w4, w2, [x3, #24]
    5df0:	92403c21 	and	x1, x1, #0xffff
    5df4:	9b047c21 	mul	x1, x1, x4
    5df8:	d360fc21 	lsr	x1, x1, #32
    5dfc:	eb02003f 	cmp	x1, x2
    5e00:	54000142 	b.cs	5e28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e04:	8b010273 	add	x19, x19, x1
    5e08:	39400261 	ldrb	w1, [x19]
    5e0c:	340000e1 	cbz	w1, 5e28 <fwp_drop0+0x98>
    5e10:	7100043f 	cmp	w1, #0x1
    5e14:	540001e0 	b.eq	5e50 <fwp_drop0+0xc0>  // b.none
    5e18:	7103fc3f 	cmp	w1, #0xff
    5e1c:	540002e0 	b.eq	5e78 <fwp_drop0+0xe8>  // b.none
    5e20:	51000421 	sub	w1, w1, #0x1
    5e24:	39000261 	strb	w1, [x19]
    5e28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e2c:	f94013f5 	ldr	x21, [sp, #32]
    5e30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e34:	d65f03c0 	ret
    5e38:	72003c3f 	tst	w1, #0xffff
    5e3c:	54fffe60 	b.eq	5e08 <fwp_drop0+0x78>  // b.none
    5e40:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e44:	f94013f5 	ldr	x21, [sp, #32]
    5e48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e4c:	d65f03c0 	ret
    5e50:	f9400813 	ldr	x19, [x0, #16]
    5e54:	97fffef3 	bl	5a20 <fwp_rc_free_arr>
    5e58:	911902a0 	add	x0, x21, #0x640
    5e5c:	f949d801 	ldr	x1, [x0, #5040]
    5e60:	f949ec00 	ldr	x0, [x0, #5080]
    5e64:	cb010261 	sub	x1, x19, x1
    5e68:	eb00403f 	cmp	x1, x0, lsl #16
    5e6c:	54fffde2 	b.cs	5e28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e70:	aa1303e0 	mov	x0, x19
    5e74:	17ffffd2 	b	5dbc <fwp_drop0+0x2c>
    5e78:	ca534660 	eor	x0, x19, x19, lsr #17
    5e7c:	911902b5 	add	x21, x21, #0x640
    5e80:	ca402400 	eor	x0, x0, x0, lsr #9
    5e84:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e88:	f94a2400 	ldr	x0, [x0, #5192]
    5e8c:	b5000080 	cbnz	x0, 5e9c <fwp_drop0+0x10c>
    5e90:	14000010 	b	5ed0 <fwp_drop0+0x140>
    5e94:	f9400800 	ldr	x0, [x0, #16]
    5e98:	b40001c0 	cbz	x0, 5ed0 <fwp_drop0+0x140>
    5e9c:	f9400001 	ldr	x1, [x0]
    5ea0:	eb13003f 	cmp	x1, x19
    5ea4:	54ffff81 	b.ne	5e94 <fwp_drop0+0x104>  // b.any
    5ea8:	f9400401 	ldr	x1, [x0, #8]
    5eac:	d1000421 	sub	x1, x1, #0x1
    5eb0:	f9000401 	str	x1, [x0, #8]
    5eb4:	f103f83f 	cmp	x1, #0xfe
    5eb8:	54fffb81 	b.ne	5e28 <fwp_drop0+0x98>  // b.any
    5ebc:	aa1303e0 	mov	x0, x19
    5ec0:	97fffab4 	bl	4990 <fwp_rc_forget_slot>
    5ec4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ec8:	39000260 	strb	w0, [x19]
    5ecc:	17ffffd7 	b	5e28 <fwp_drop0+0x98>
    5ed0:	d0000020 	adrp	x0, b000 <__divti3+0x160>
    5ed4:	912a0000 	add	x0, x0, #0xa80
    5ed8:	97fff62a 	bl	3780 <fwp_trap>
    5edc:	d503201f 	nop

0000000000005ee0 <fwp_arg_drop12>:
    5ee0:	7100003f 	cmp	w1, #0x0
    5ee4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5ee8:	54000041 	b.ne	5ef0 <fwp_arg_drop12+0x10>  // b.any
    5eec:	d65f03c0 	ret
    5ef0:	f9400000 	ldr	x0, [x0]
    5ef4:	17ffffa7 	b	5d90 <fwp_drop0>
    5ef8:	d503201f 	nop
    5efc:	d503201f 	nop

0000000000005f00 <fwp_drop1>:
    5f00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f04:	910003fd 	mov	x29, sp
    5f08:	a90153f3 	stp	x19, x20, [sp, #16]
    5f0c:	f90013f5 	str	x21, [sp, #32]
    5f10:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5f14:	911902b4 	add	x20, x21, #0x640
    5f18:	f949da81 	ldr	x1, [x20, #5040]
    5f1c:	f949ee82 	ldr	x2, [x20, #5080]
    5f20:	cb010001 	sub	x1, x0, x1
    5f24:	eb02403f 	cmp	x1, x2, lsl #16
    5f28:	54000382 	b.cs	5f98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f2c:	d350fc22 	lsr	x2, x1, #16
    5f30:	f949fe84 	ldr	x4, [x20, #5112]
    5f34:	8b020842 	add	x2, x2, x2, lsl #2
    5f38:	d37df042 	lsl	x2, x2, #3
    5f3c:	8b020083 	add	x3, x4, x2
    5f40:	f9401073 	ldr	x19, [x3, #32]
    5f44:	b40002b3 	cbz	x19, 5f98 <fwp_drop1+0x98>
    5f48:	38626882 	ldrb	w2, [x4, x2]
    5f4c:	7100085f 	cmp	w2, #0x2
    5f50:	540002c0 	b.eq	5fa8 <fwp_drop1+0xa8>  // b.none
    5f54:	7100045f 	cmp	w2, #0x1
    5f58:	54000201 	b.ne	5f98 <fwp_drop1+0x98>  // b.any
    5f5c:	29430864 	ldp	w4, w2, [x3, #24]
    5f60:	92403c21 	and	x1, x1, #0xffff
    5f64:	9b047c21 	mul	x1, x1, x4
    5f68:	d360fc21 	lsr	x1, x1, #32
    5f6c:	eb02003f 	cmp	x1, x2
    5f70:	54000142 	b.cs	5f98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f74:	8b010273 	add	x19, x19, x1
    5f78:	39400261 	ldrb	w1, [x19]
    5f7c:	340000e1 	cbz	w1, 5f98 <fwp_drop1+0x98>
    5f80:	7100043f 	cmp	w1, #0x1
    5f84:	540001e0 	b.eq	5fc0 <fwp_drop1+0xc0>  // b.none
    5f88:	7103fc3f 	cmp	w1, #0xff
    5f8c:	540002e0 	b.eq	5fe8 <fwp_drop1+0xe8>  // b.none
    5f90:	51000421 	sub	w1, w1, #0x1
    5f94:	39000261 	strb	w1, [x19]
    5f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f9c:	f94013f5 	ldr	x21, [sp, #32]
    5fa0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fa4:	d65f03c0 	ret
    5fa8:	72003c3f 	tst	w1, #0xffff
    5fac:	54fffe60 	b.eq	5f78 <fwp_drop1+0x78>  // b.none
    5fb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fb4:	f94013f5 	ldr	x21, [sp, #32]
    5fb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fbc:	d65f03c0 	ret
    5fc0:	f9400813 	ldr	x19, [x0, #16]
    5fc4:	97fffe97 	bl	5a20 <fwp_rc_free_arr>
    5fc8:	911902a0 	add	x0, x21, #0x640
    5fcc:	f949d801 	ldr	x1, [x0, #5040]
    5fd0:	f949ec00 	ldr	x0, [x0, #5080]
    5fd4:	cb010261 	sub	x1, x19, x1
    5fd8:	eb00403f 	cmp	x1, x0, lsl #16
    5fdc:	54fffde2 	b.cs	5f98 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fe0:	aa1303e0 	mov	x0, x19
    5fe4:	17ffffd2 	b	5f2c <fwp_drop1+0x2c>
    5fe8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fec:	911902b5 	add	x21, x21, #0x640
    5ff0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ff4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ff8:	f94a2400 	ldr	x0, [x0, #5192]
    5ffc:	b5000080 	cbnz	x0, 600c <fwp_drop1+0x10c>
    6000:	14000010 	b	6040 <fwp_drop1+0x140>
    6004:	f9400800 	ldr	x0, [x0, #16]
    6008:	b40001c0 	cbz	x0, 6040 <fwp_drop1+0x140>
    600c:	f9400001 	ldr	x1, [x0]
    6010:	eb13003f 	cmp	x1, x19
    6014:	54ffff81 	b.ne	6004 <fwp_drop1+0x104>  // b.any
    6018:	f9400401 	ldr	x1, [x0, #8]
    601c:	d1000421 	sub	x1, x1, #0x1
    6020:	f9000401 	str	x1, [x0, #8]
    6024:	f103f83f 	cmp	x1, #0xfe
    6028:	54fffb81 	b.ne	5f98 <fwp_drop1+0x98>  // b.any
    602c:	aa1303e0 	mov	x0, x19
    6030:	97fffa58 	bl	4990 <fwp_rc_forget_slot>
    6034:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6038:	39000260 	strb	w0, [x19]
    603c:	17ffffd7 	b	5f98 <fwp_drop1+0x98>
    6040:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    6044:	912a0000 	add	x0, x0, #0xa80
    6048:	97fff5ce 	bl	3780 <fwp_trap>
    604c:	d503201f 	nop

0000000000006050 <fwp_closure_drop>:
    6050:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    6054:	911900a4 	add	x4, x5, #0x640
    6058:	aa0003e1 	mov	x1, x0
    605c:	f949d882 	ldr	x2, [x4, #5040]
    6060:	f949ec80 	ldr	x0, [x4, #5080]
    6064:	cb020022 	sub	x2, x1, x2
    6068:	eb00405f 	cmp	x2, x0, lsl #16
    606c:	54000662 	b.cs	6138 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6074:	d350fc43 	lsr	x3, x2, #16
    6078:	910003fd 	mov	x29, sp
    607c:	8b030863 	add	x3, x3, x3, lsl #2
    6080:	f949fc84 	ldr	x4, [x4, #5112]
    6084:	d37df063 	lsl	x3, x3, #3
    6088:	f9000bf3 	str	x19, [sp, #16]
    608c:	8b030080 	add	x0, x4, x3
    6090:	f9401013 	ldr	x19, [x0, #32]
    6094:	b40002b3 	cbz	x19, 60e8 <fwp_closure_drop+0x98>
    6098:	38636883 	ldrb	w3, [x4, x3]
    609c:	7100087f 	cmp	w3, #0x2
    60a0:	54000420 	b.eq	6124 <fwp_closure_drop+0xd4>  // b.none
    60a4:	7100047f 	cmp	w3, #0x1
    60a8:	54000201 	b.ne	60e8 <fwp_closure_drop+0x98>  // b.any
    60ac:	29430003 	ldp	w3, w0, [x0, #24]
    60b0:	92403c42 	and	x2, x2, #0xffff
    60b4:	9b037c42 	mul	x2, x2, x3
    60b8:	d360fc42 	lsr	x2, x2, #32
    60bc:	eb00005f 	cmp	x2, x0
    60c0:	54000142 	b.cs	60e8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    60c4:	8b020273 	add	x19, x19, x2
    60c8:	39400260 	ldrb	w0, [x19]
    60cc:	340000e0 	cbz	w0, 60e8 <fwp_closure_drop+0x98>
    60d0:	7100041f 	cmp	w0, #0x1
    60d4:	54000100 	b.eq	60f4 <fwp_closure_drop+0xa4>  // b.none
    60d8:	7103fc1f 	cmp	w0, #0xff
    60dc:	54000300 	b.eq	613c <fwp_closure_drop+0xec>  // b.none
    60e0:	51000400 	sub	w0, w0, #0x1
    60e4:	39000260 	strb	w0, [x19]
    60e8:	f9400bf3 	ldr	x19, [sp, #16]
    60ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60f0:	d65f03c0 	ret
    60f4:	d53bd040 	mrs	x0, tpidr_el0
    60f8:	91400000 	add	x0, x0, #0x0, lsl #12
    60fc:	91004000 	add	x0, x0, #0x10
    6100:	f9400000 	ldr	x0, [x0]
    6104:	b4000080 	cbz	x0, 6114 <fwp_closure_drop+0xc4>
    6108:	f9400bf3 	ldr	x19, [sp, #16]
    610c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6110:	17fff5b5 	b	37e4 <fwp_closure_drop_push>
    6114:	f9400bf3 	ldr	x19, [sp, #16]
    6118:	aa0103e0 	mov	x0, x1
    611c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6120:	17fff620 	b	39a0 <fwp_closure_drop.part.0>
    6124:	72003c5f 	tst	w2, #0xffff
    6128:	54fffd00 	b.eq	60c8 <fwp_closure_drop+0x78>  // b.none
    612c:	f9400bf3 	ldr	x19, [sp, #16]
    6130:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6134:	d65f03c0 	ret
    6138:	d65f03c0 	ret
    613c:	ca534660 	eor	x0, x19, x19, lsr #17
    6140:	911900a5 	add	x5, x5, #0x640
    6144:	ca402400 	eor	x0, x0, x0, lsr #9
    6148:	8b200ca0 	add	x0, x5, w0, uxtb #3
    614c:	f94a2400 	ldr	x0, [x0, #5192]
    6150:	b5000080 	cbnz	x0, 6160 <fwp_closure_drop+0x110>
    6154:	14000010 	b	6194 <fwp_closure_drop+0x144>
    6158:	f9400800 	ldr	x0, [x0, #16]
    615c:	b40001c0 	cbz	x0, 6194 <fwp_closure_drop+0x144>
    6160:	f9400001 	ldr	x1, [x0]
    6164:	eb13003f 	cmp	x1, x19
    6168:	54ffff81 	b.ne	6158 <fwp_closure_drop+0x108>  // b.any
    616c:	f9400401 	ldr	x1, [x0, #8]
    6170:	d1000421 	sub	x1, x1, #0x1
    6174:	f9000401 	str	x1, [x0, #8]
    6178:	f103f83f 	cmp	x1, #0xfe
    617c:	54fffb61 	b.ne	60e8 <fwp_closure_drop+0x98>  // b.any
    6180:	aa1303e0 	mov	x0, x19
    6184:	97fffa03 	bl	4990 <fwp_rc_forget_slot>
    6188:	12800020 	mov	w0, #0xfffffffe            	// #-2
    618c:	39000260 	strb	w0, [x19]
    6190:	17ffffd6 	b	60e8 <fwp_closure_drop+0x98>
    6194:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    6198:	912a0000 	add	x0, x0, #0xa80
    619c:	97fff579 	bl	3780 <fwp_trap>

00000000000061a0 <fwp_owned_tape_release>:
    61a0:	b4000940 	cbz	x0, 62c8 <fwp_owned_tape_release+0x128>
    61a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61a8:	910003fd 	mov	x29, sp
    61ac:	a90153f3 	stp	x19, x20, [sp, #16]
    61b0:	aa0003f3 	mov	x19, x0
    61b4:	f9400000 	ldr	x0, [x0]
    61b8:	b4000060 	cbz	x0, 61c4 <fwp_owned_tape_release+0x24>
    61bc:	f9400661 	ldr	x1, [x19, #8]
    61c0:	f9000401 	str	x1, [x0, #8]
    61c4:	f9400661 	ldr	x1, [x19, #8]
    61c8:	b4000041 	cbz	x1, 61d0 <fwp_owned_tape_release+0x30>
    61cc:	f9000020 	str	x0, [x1]
    61d0:	f9400a60 	ldr	x0, [x19, #16]
    61d4:	f9403401 	ldr	x1, [x0, #104]
    61d8:	b40005c1 	cbz	x1, 6290 <fwp_owned_tape_release+0xf0>
    61dc:	a9450a60 	ldp	x0, x2, [x19, #80]
    61e0:	eb00005f 	cmp	x2, x0
    61e4:	540002ed 	b.le	6240 <fwp_owned_tape_release+0xa0>
    61e8:	d2800014 	mov	x20, #0x0                   	// #0
    61ec:	f90013f5 	str	x21, [sp, #32]
    61f0:	d2800015 	mov	x21, #0x0                   	// #0
    61f4:	d503201f 	nop
    61f8:	f9402260 	ldr	x0, [x19, #64]
    61fc:	910006b5 	add	x21, x21, #0x1
    6200:	f8746800 	ldr	x0, [x0, x20]
    6204:	d63f0020 	blr	x1
    6208:	f9402260 	ldr	x0, [x19, #64]
    620c:	f9400a61 	ldr	x1, [x19, #16]
    6210:	8b140000 	add	x0, x0, x20
    6214:	91004294 	add	x20, x20, #0x10
    6218:	f9400400 	ldr	x0, [x0, #8]
    621c:	f9403421 	ldr	x1, [x1, #104]
    6220:	d63f0020 	blr	x1
    6224:	a9450261 	ldp	x1, x0, [x19, #80]
    6228:	cb010000 	sub	x0, x0, x1
    622c:	eb15001f 	cmp	x0, x21
    6230:	f9400a60 	ldr	x0, [x19, #16]
    6234:	f9403401 	ldr	x1, [x0, #104]
    6238:	54fffe0c 	b.gt	61f8 <fwp_owned_tape_release+0x58>
    623c:	f94013f5 	ldr	x21, [sp, #32]
    6240:	f9403663 	ldr	x3, [x19, #104]
    6244:	f9401262 	ldr	x2, [x19, #32]
    6248:	f100007f 	cmp	x3, #0x0
    624c:	540001ed 	b.le	6288 <fwp_owned_tape_release+0xe8>
    6250:	d2800014 	mov	x20, #0x0                   	// #0
    6254:	d503201f 	nop
    6258:	f9402660 	ldr	x0, [x19, #72]
    625c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6260:	eb02001f 	cmp	x0, x2
    6264:	540000c0 	b.eq	627c <fwp_owned_tape_release+0xdc>  // b.none
    6268:	d63f0020 	blr	x1
    626c:	f9400a60 	ldr	x0, [x19, #16]
    6270:	f9401262 	ldr	x2, [x19, #32]
    6274:	f9403663 	ldr	x3, [x19, #104]
    6278:	f9403401 	ldr	x1, [x0, #104]
    627c:	91000694 	add	x20, x20, #0x1
    6280:	eb14007f 	cmp	x3, x20
    6284:	54fffeac 	b.gt	6258 <fwp_owned_tape_release+0xb8>
    6288:	aa0203e0 	mov	x0, x2
    628c:	d63f0020 	blr	x1
    6290:	f9401660 	ldr	x0, [x19, #40]
    6294:	97ffff6f 	bl	6050 <fwp_closure_drop>
    6298:	f9401a60 	ldr	x0, [x19, #48]
    629c:	97ffff6d 	bl	6050 <fwp_closure_drop>
    62a0:	f9401e60 	ldr	x0, [x19, #56]
    62a4:	97ffff6b 	bl	6050 <fwp_closure_drop>
    62a8:	f9402260 	ldr	x0, [x19, #64]
    62ac:	97fffa59 	bl	4c10 <fwp_mem_free>
    62b0:	f9402660 	ldr	x0, [x19, #72]
    62b4:	97fffa57 	bl	4c10 <fwp_mem_free>
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	17fffa53 	b	4c10 <fwp_mem_free>
    62c8:	d65f03c0 	ret
    62cc:	d503201f 	nop

00000000000062d0 <fwp_tape_finish>:
    62d0:	d10203ff 	sub	sp, sp, #0x80
    62d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    62d8:	f947f421 	ldr	x1, [x1, #4072]
    62dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    62e0:	910103fd 	add	x29, sp, #0x40
    62e4:	a9065bf5 	stp	x21, x22, [sp, #96]
    62e8:	a90763f7 	stp	x23, x24, [sp, #112]
    62ec:	d00000d7 	adrp	x23, 20000 <__data_start>
    62f0:	910182f6 	add	x22, x23, #0x60
    62f4:	f9400022 	ldr	x2, [x1]
    62f8:	f9001fe2 	str	x2, [sp, #56]
    62fc:	d2800002 	mov	x2, #0x0                   	// #0
    6300:	910382c0 	add	x0, x22, #0xe0
    6304:	97fff820 	bl	4384 <fwp_tape_buffers_dispose>
    6308:	f9008edf 	str	xzr, [x22, #280]
    630c:	f9406ec0 	ldr	x0, [x22, #216]
    6310:	f100001f 	cmp	x0, #0x0
    6314:	5400034d 	b.le	637c <fwp_tape_finish+0xac>
    6318:	910003f8 	mov	x24, sp
    631c:	d2800015 	mov	x21, #0x0                   	// #0
    6320:	a90553f3 	stp	x19, x20, [sp, #80]
    6324:	d2800014 	mov	x20, #0x0                   	// #0
    6328:	91000694 	add	x20, x20, #0x1
    632c:	f94046d3 	ldr	x19, [x22, #136]
    6330:	8b150273 	add	x19, x19, x21
    6334:	9101a2b5 	add	x21, x21, #0x68
    6338:	aa1303e0 	mov	x0, x19
    633c:	97fff316 	bl	2f94 <fwp_tape_unlink_scope>
    6340:	aa1803e0 	mov	x0, x24
    6344:	a9440663 	ldp	x3, x1, [x19, #64]
    6348:	f9001be1 	str	x1, [sp, #48]
    634c:	f9400e62 	ldr	x2, [x19, #24]
    6350:	a9020be3 	stp	x3, x2, [sp, #32]
    6354:	ad410261 	ldp	q1, q0, [x19, #32]
    6358:	ad0003e1 	stp	q1, q0, [sp]
    635c:	97fff80a 	bl	4384 <fwp_tape_buffers_dispose>
    6360:	f9403260 	ldr	x0, [x19, #96]
    6364:	97ffff8f 	bl	61a0 <fwp_owned_tape_release>
    6368:	f900327f 	str	xzr, [x19, #96]
    636c:	f9406ec0 	ldr	x0, [x22, #216]
    6370:	eb14001f 	cmp	x0, x20
    6374:	54fffdac 	b.gt	6328 <fwp_tape_finish+0x58>
    6378:	a94553f3 	ldp	x19, x20, [sp, #80]
    637c:	910182e0 	add	x0, x23, #0x60
    6380:	f9404400 	ldr	x0, [x0, #136]
    6384:	b4000040 	cbz	x0, 638c <fwp_tape_finish+0xbc>
    6388:	97fff7de 	bl	4300 <ad_raw_free.part.0>
    638c:	910182f7 	add	x23, x23, #0x60
    6390:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6394:	f947f400 	ldr	x0, [x0, #4072]
    6398:	f90046ff 	str	xzr, [x23, #136]
    639c:	f9006eff 	str	xzr, [x23, #216]
    63a0:	f90092ff 	str	xzr, [x23, #288]
    63a4:	f900b2ff 	str	xzr, [x23, #352]
    63a8:	f9401fe2 	ldr	x2, [sp, #56]
    63ac:	f9400001 	ldr	x1, [x0]
    63b0:	eb010042 	subs	x2, x2, x1
    63b4:	d2800001 	mov	x1, #0x0                   	// #0
    63b8:	540000c1 	b.ne	63d0 <fwp_tape_finish+0x100>  // b.any
    63bc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63c0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63c4:	a94763f7 	ldp	x23, x24, [sp, #112]
    63c8:	910203ff 	add	sp, sp, #0x80
    63cc:	d65f03c0 	ret
    63d0:	a90553f3 	stp	x19, x20, [sp, #80]
    63d4:	97fff10f 	bl	2810 <__stack_chk_fail@plt>
    63d8:	d503201f 	nop
    63dc:	d503201f 	nop

00000000000063e0 <fwp_tape_scope_release>:
    63e0:	d10243ff 	sub	sp, sp, #0x90
    63e4:	a9047bfd 	stp	x29, x30, [sp, #64]
    63e8:	910103fd 	add	x29, sp, #0x40
    63ec:	a90553f3 	stp	x19, x20, [sp, #80]
    63f0:	aa0003f4 	mov	x20, x0
    63f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    63f8:	f947f400 	ldr	x0, [x0, #4072]
    63fc:	b9400285 	ldr	w5, [x20]
    6400:	f9400001 	ldr	x1, [x0]
    6404:	f9001fe1 	str	x1, [sp, #56]
    6408:	d2800001 	mov	x1, #0x0                   	// #0
    640c:	37f806c5 	tbnz	w5, #31, 64e4 <fwp_tape_scope_release+0x104>
    6410:	a90763f7 	stp	x23, x24, [sp, #112]
    6414:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6418:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    641c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6420:	d00000d3 	adrp	x19, 20000 <__data_start>
    6424:	910003f7 	mov	x23, sp
    6428:	91018273 	add	x19, x19, #0x60
    642c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6430:	a9065bf5 	stp	x21, x22, [sp, #96]
    6434:	52800d16 	mov	w22, #0x68                  	// #104
    6438:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    643c:	f90043f9 	str	x25, [sp, #128]
    6440:	14000006 	b	6458 <fwp_tape_scope_release+0x78>
    6444:	97fff7d0 	bl	4384 <fwp_tape_buffers_dispose>
    6448:	aa1903e0 	mov	x0, x25
    644c:	97ffff55 	bl	61a0 <fwp_owned_tape_release>
    6450:	b9400285 	ldr	w5, [x20]
    6454:	37f80425 	tbnz	w5, #31, 64d8 <fwp_tape_scope_release+0xf8>
    6458:	f9404666 	ldr	x6, [x19, #136]
    645c:	9b367ca5 	smull	x5, w5, w22
    6460:	8b0500c0 	add	x0, x6, x5
    6464:	97fff2cc 	bl	2f94 <fwp_tape_unlink_scope>
    6468:	ad410001 	ldp	q1, q0, [x0, #32]
    646c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6470:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6474:	f9400c03 	ldr	x3, [x0, #24]
    6478:	ad0003e1 	stp	q1, q0, [sp]
    647c:	b86568c1 	ldr	w1, [x6, x5]
    6480:	a9440804 	ldp	x4, x2, [x0, #64]
    6484:	b900041f 	str	wzr, [x0, #4]
    6488:	f9403019 	ldr	x25, [x0, #96]
    648c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6490:	f9000c1f 	str	xzr, [x0, #24]
    6494:	a9020fe4 	stp	x4, x3, [sp, #32]
    6498:	f9001be2 	str	x2, [sp, #48]
    649c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    64a0:	f900301f 	str	xzr, [x0, #96]
    64a4:	6b15003f 	cmp	w1, w21
    64a8:	540000e8 	b.hi	64c4 <fwp_tape_scope_release+0xe4>  // b.pmore
    64ac:	9343fca5 	asr	x5, x5, #3
    64b0:	f940b260 	ldr	x0, [x19, #352]
    64b4:	9b187ca5 	mul	x5, x5, x24
    64b8:	eb0000bf 	cmp	x5, x0
    64bc:	5400004a 	b.ge	64c4 <fwp_tape_scope_release+0xe4>  // b.tcont
    64c0:	f900b265 	str	x5, [x19, #352]
    64c4:	aa1703e0 	mov	x0, x23
    64c8:	b5fffbf9 	cbnz	x25, 6444 <fwp_tape_scope_release+0x64>
    64cc:	97fff7f6 	bl	44a4 <fwp_tape_buffers_release>
    64d0:	b9400285 	ldr	w5, [x20]
    64d4:	36fffc25 	tbz	w5, #31, 6458 <fwp_tape_scope_release+0x78>
    64d8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    64dc:	a94763f7 	ldp	x23, x24, [sp, #112]
    64e0:	f94043f9 	ldr	x25, [sp, #128]
    64e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    64e8:	f947f400 	ldr	x0, [x0, #4072]
    64ec:	f9401fe2 	ldr	x2, [sp, #56]
    64f0:	f9400001 	ldr	x1, [x0]
    64f4:	eb010042 	subs	x2, x2, x1
    64f8:	d2800001 	mov	x1, #0x0                   	// #0
    64fc:	540000a1 	b.ne	6510 <fwp_tape_scope_release+0x130>  // b.any
    6500:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6504:	a94553f3 	ldp	x19, x20, [sp, #80]
    6508:	910243ff 	add	sp, sp, #0x90
    650c:	d65f03c0 	ret
    6510:	a9065bf5 	stp	x21, x22, [sp, #96]
    6514:	a90763f7 	stp	x23, x24, [sp, #112]
    6518:	f90043f9 	str	x25, [sp, #128]
    651c:	97fff0bd 	bl	2810 <__stack_chk_fail@plt>

0000000000006520 <fwp_task_dispose>:
    6520:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6524:	910003fd 	mov	x29, sp
    6528:	f9000bf3 	str	x19, [sp, #16]
    652c:	aa0003f3 	mov	x19, x0
    6530:	39414000 	ldrb	w0, [x0, #80]
    6534:	36000720 	tbz	w0, #0, 6618 <fwp_task_dispose+0xf8>
    6538:	f9400a60 	ldr	x0, [x19, #16]
    653c:	b50006e0 	cbnz	x0, 6618 <fwp_task_dispose+0xf8>
    6540:	a9478660 	ldp	x0, x1, [x19, #120]
    6544:	39014e7f 	strb	wzr, [x19, #83]
    6548:	f9003e7f 	str	xzr, [x19, #120]
    654c:	f100003f 	cmp	x1, #0x0
    6550:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6554:	54000040 	b.eq	655c <fwp_task_dispose+0x3c>  // b.none
    6558:	d63f0020 	blr	x1
    655c:	f9405660 	ldr	x0, [x19, #168]
    6560:	97fff9ac 	bl	4c10 <fwp_mem_free>
    6564:	f900567f 	str	xzr, [x19, #168]
    6568:	b9405e60 	ldr	w0, [x19, #92]
    656c:	7100041f 	cmp	w0, #0x1
    6570:	54000420 	b.eq	65f4 <fwp_task_dispose+0xd4>  // b.none
    6574:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6578:	91190042 	add	x2, x2, #0x640
    657c:	f949d840 	ldr	x0, [x2, #5040]
    6580:	f949ec41 	ldr	x1, [x2, #5080]
    6584:	cb000260 	sub	x0, x19, x0
    6588:	eb01401f 	cmp	x0, x1, lsl #16
    658c:	540002e2 	b.cs	65e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6590:	d350fc01 	lsr	x1, x0, #16
    6594:	f949fc44 	ldr	x4, [x2, #5112]
    6598:	8b010821 	add	x1, x1, x1, lsl #2
    659c:	d37df021 	lsl	x1, x1, #3
    65a0:	8b010083 	add	x3, x4, x1
    65a4:	f9401062 	ldr	x2, [x3, #32]
    65a8:	b4000202 	cbz	x2, 65e8 <fwp_task_dispose+0xc8>
    65ac:	38616881 	ldrb	w1, [x4, x1]
    65b0:	7100083f 	cmp	w1, #0x2
    65b4:	54000280 	b.eq	6604 <fwp_task_dispose+0xe4>  // b.none
    65b8:	7100043f 	cmp	w1, #0x1
    65bc:	54000161 	b.ne	65e8 <fwp_task_dispose+0xc8>  // b.any
    65c0:	29430464 	ldp	w4, w1, [x3, #24]
    65c4:	92403c00 	and	x0, x0, #0xffff
    65c8:	9b047c00 	mul	x0, x0, x4
    65cc:	d360fc00 	lsr	x0, x0, #32
    65d0:	eb01001f 	cmp	x0, x1
    65d4:	540000a2 	b.cs	65e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65d8:	8b000042 	add	x2, x2, x0
    65dc:	39400040 	ldrb	w0, [x2]
    65e0:	7100041f 	cmp	w0, #0x1
    65e4:	54000080 	b.eq	65f4 <fwp_task_dispose+0xd4>  // b.none
    65e8:	f9400bf3 	ldr	x19, [sp, #16]
    65ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f0:	d65f03c0 	ret
    65f4:	aa1303e0 	mov	x0, x19
    65f8:	f9400bf3 	ldr	x19, [sp, #16]
    65fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6600:	17fff984 	b	4c10 <fwp_mem_free>
    6604:	72003c1f 	tst	w0, #0xffff
    6608:	54fffea0 	b.eq	65dc <fwp_task_dispose+0xbc>  // b.none
    660c:	f9400bf3 	ldr	x19, [sp, #16]
    6610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6614:	d65f03c0 	ret
    6618:	97fff092 	bl	2860 <abort@plt>
    661c:	d503201f 	nop

0000000000006620 <fwp_free_zombie>:
    6620:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6624:	910003fd 	mov	x29, sp
    6628:	a90153f3 	stp	x19, x20, [sp, #16]
    662c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6630:	91018281 	add	x1, x20, #0x60
    6634:	f940b433 	ldr	x19, [x1, #360]
    6638:	b4000333 	cbz	x19, 669c <fwp_free_zombie+0x7c>
    663c:	f9404c20 	ldr	x0, [x1, #152]
    6640:	eb00027f 	cmp	x19, x0
    6644:	540002c0 	b.eq	669c <fwp_free_zombie+0x7c>  // b.none
    6648:	b9417022 	ldr	w2, [x1, #368]
    664c:	f9400a60 	ldr	x0, [x19, #16]
    6650:	7100fc5f 	cmp	w2, #0x3f
    6654:	5400078c 	b.gt	6744 <fwp_free_zombie+0x124>
    6658:	91060023 	add	x3, x1, #0x180
    665c:	11000444 	add	w4, w2, #0x1
    6660:	b9017024 	str	w4, [x1, #368]
    6664:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6668:	f822d860 	str	x0, [x3, w2, sxtw #3]
    666c:	a9530261 	ldp	x1, x0, [x19, #304]
    6670:	b4000741 	cbz	x1, 6758 <fwp_free_zombie+0x138>
    6674:	f9009c20 	str	x0, [x1, #312]
    6678:	b4000040 	cbz	x0, 6680 <fwp_free_zombie+0x60>
    667c:	f9009801 	str	x1, [x0, #304]
    6680:	91018294 	add	x20, x20, #0x60
    6684:	b9405e60 	ldr	w0, [x19, #92]
    6688:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    668c:	f900b69f 	str	xzr, [x20, #360]
    6690:	34000140 	cbz	w0, 66b8 <fwp_free_zombie+0x98>
    6694:	7100041f 	cmp	w0, #0x1
    6698:	54000080 	b.eq	66a8 <fwp_free_zombie+0x88>  // b.none
    669c:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a4:	d65f03c0 	ret
    66a8:	aa1303e0 	mov	x0, x19
    66ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66b4:	17ffff9b 	b	6520 <fwp_task_dispose>
    66b8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    66bc:	91190082 	add	x2, x4, #0x640
    66c0:	f949d841 	ldr	x1, [x2, #5040]
    66c4:	f949ec40 	ldr	x0, [x2, #5080]
    66c8:	cb010261 	sub	x1, x19, x1
    66cc:	eb00403f 	cmp	x1, x0, lsl #16
    66d0:	54fffe62 	b.cs	669c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66d4:	d350fc20 	lsr	x0, x1, #16
    66d8:	f949fc43 	ldr	x3, [x2, #5112]
    66dc:	8b000800 	add	x0, x0, x0, lsl #2
    66e0:	d37df000 	lsl	x0, x0, #3
    66e4:	8b000062 	add	x2, x3, x0
    66e8:	f9401054 	ldr	x20, [x2, #32]
    66ec:	b4fffd94 	cbz	x20, 669c <fwp_free_zombie+0x7c>
    66f0:	38606860 	ldrb	w0, [x3, x0]
    66f4:	7100081f 	cmp	w0, #0x2
    66f8:	54000360 	b.eq	6764 <fwp_free_zombie+0x144>  // b.none
    66fc:	7100041f 	cmp	w0, #0x1
    6700:	54fffce1 	b.ne	669c <fwp_free_zombie+0x7c>  // b.any
    6704:	29430043 	ldp	w3, w0, [x2, #24]
    6708:	92403c21 	and	x1, x1, #0xffff
    670c:	9b037c21 	mul	x1, x1, x3
    6710:	d360fc21 	lsr	x1, x1, #32
    6714:	eb00003f 	cmp	x1, x0
    6718:	54fffc22 	b.cs	669c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    671c:	8b010294 	add	x20, x20, x1
    6720:	39400280 	ldrb	w0, [x20]
    6724:	34fffbc0 	cbz	w0, 669c <fwp_free_zombie+0x7c>
    6728:	7100041f 	cmp	w0, #0x1
    672c:	54fffbe0 	b.eq	66a8 <fwp_free_zombie+0x88>  // b.none
    6730:	7103fc1f 	cmp	w0, #0xff
    6734:	540001e0 	b.eq	6770 <fwp_free_zombie+0x150>  // b.none
    6738:	51000400 	sub	w0, w0, #0x1
    673c:	39000280 	strb	w0, [x20]
    6740:	17ffffd7 	b	669c <fwp_free_zombie+0x7c>
    6744:	f9400e61 	ldr	x1, [x19, #24]
    6748:	97fff07a 	bl	2930 <munmap@plt>
    674c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6750:	a9530261 	ldp	x1, x0, [x19, #304]
    6754:	b5fff901 	cbnz	x1, 6674 <fwp_free_zombie+0x54>
    6758:	91018282 	add	x2, x20, #0x60
    675c:	f901c040 	str	x0, [x2, #896]
    6760:	17ffffc6 	b	6678 <fwp_free_zombie+0x58>
    6764:	72003c3f 	tst	w1, #0xffff
    6768:	54fff9a1 	b.ne	669c <fwp_free_zombie+0x7c>  // b.any
    676c:	17ffffed 	b	6720 <fwp_free_zombie+0x100>
    6770:	ca544680 	eor	x0, x20, x20, lsr #17
    6774:	91190084 	add	x4, x4, #0x640
    6778:	ca402400 	eor	x0, x0, x0, lsr #9
    677c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6780:	f94a2400 	ldr	x0, [x0, #5192]
    6784:	b5000080 	cbnz	x0, 6794 <fwp_free_zombie+0x174>
    6788:	14000010 	b	67c8 <fwp_free_zombie+0x1a8>
    678c:	f9400800 	ldr	x0, [x0, #16]
    6790:	b40001c0 	cbz	x0, 67c8 <fwp_free_zombie+0x1a8>
    6794:	f9400001 	ldr	x1, [x0]
    6798:	eb14003f 	cmp	x1, x20
    679c:	54ffff81 	b.ne	678c <fwp_free_zombie+0x16c>  // b.any
    67a0:	f9400401 	ldr	x1, [x0, #8]
    67a4:	d1000421 	sub	x1, x1, #0x1
    67a8:	f9000401 	str	x1, [x0, #8]
    67ac:	f103f83f 	cmp	x1, #0xfe
    67b0:	54fff761 	b.ne	669c <fwp_free_zombie+0x7c>  // b.any
    67b4:	aa1403e0 	mov	x0, x20
    67b8:	97fff876 	bl	4990 <fwp_rc_forget_slot>
    67bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67c0:	39000280 	strb	w0, [x20]
    67c4:	17ffffb6 	b	669c <fwp_free_zombie+0x7c>
    67c8:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    67cc:	912a0000 	add	x0, x0, #0xa80
    67d0:	97fff3ec 	bl	3780 <fwp_trap>

00000000000067d4 <fwp_block>:
    67d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67d8:	910003fd 	mov	x29, sp
    67dc:	a90153f3 	stp	x19, x20, [sp, #16]
    67e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    67e4:	91018274 	add	x20, x19, #0x60
    67e8:	f9406682 	ldr	x2, [x20, #200]
    67ec:	b4000622 	cbz	x2, 68b0 <fwp_block+0xdc>
    67f0:	91018261 	add	x1, x19, #0x60
    67f4:	f9408040 	ldr	x0, [x2, #256]
    67f8:	f9006420 	str	x0, [x1, #200]
    67fc:	b4000680 	cbz	x0, 68cc <fwp_block+0xf8>
    6800:	91018263 	add	x3, x19, #0x60
    6804:	3901505f 	strb	wzr, [x2, #84]
    6808:	f9404c64 	ldr	x4, [x3, #152]
    680c:	eb02009f 	cmp	x4, x2
    6810:	54000440 	b.eq	6898 <fwp_block+0xc4>  // b.none
    6814:	f941c465 	ldr	x5, [x3, #904]
    6818:	f9004c62 	str	x2, [x3, #152]
    681c:	f9400441 	ldr	x1, [x2, #8]
    6820:	f9004885 	str	x5, [x4, #144]
    6824:	f941c865 	ldr	x5, [x3, #912]
    6828:	f9004c85 	str	x5, [x4, #152]
    682c:	f941cc65 	ldr	x5, [x3, #920]
    6830:	f9005085 	str	x5, [x4, #160]
    6834:	f941d065 	ldr	x5, [x3, #928]
    6838:	f9005485 	str	x5, [x4, #168]
    683c:	f941d465 	ldr	x5, [x3, #936]
    6840:	f9005885 	str	x5, [x4, #176]
    6844:	f941d865 	ldr	x5, [x3, #944]
    6848:	f9005c85 	str	x5, [x4, #184]
    684c:	f941dc65 	ldr	x5, [x3, #952]
    6850:	f9006085 	str	x5, [x4, #192]
    6854:	f9400480 	ldr	x0, [x4, #8]
    6858:	f9404844 	ldr	x4, [x2, #144]
    685c:	f901c464 	str	x4, [x3, #904]
    6860:	f9404c44 	ldr	x4, [x2, #152]
    6864:	f901c864 	str	x4, [x3, #912]
    6868:	f9405044 	ldr	x4, [x2, #160]
    686c:	f901cc64 	str	x4, [x3, #920]
    6870:	f9405444 	ldr	x4, [x2, #168]
    6874:	f901d064 	str	x4, [x3, #928]
    6878:	f9405844 	ldr	x4, [x2, #176]
    687c:	f901d464 	str	x4, [x3, #936]
    6880:	a94b8844 	ldp	x4, x2, [x2, #184]
    6884:	f901d864 	str	x4, [x3, #944]
    6888:	f901dc62 	str	x2, [x3, #952]
    688c:	97ffeff9 	bl	2870 <swapcontext@plt>
    6890:	97ffff64 	bl	6620 <fwp_free_zombie>
    6894:	d503201f 	nop
    6898:	91018260 	add	x0, x19, #0x60
    689c:	b943c000 	ldr	w0, [x0, #960]
    68a0:	340001a0 	cbz	w0, 68d4 <fwp_block+0x100>
    68a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    68a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68ac:	d65f03c0 	ret
    68b0:	97fff765 	bl	4644 <fwp_poll_events>
    68b4:	f9406682 	ldr	x2, [x20, #200]
    68b8:	b4ffffc2 	cbz	x2, 68b0 <fwp_block+0xdc>
    68bc:	91018261 	add	x1, x19, #0x60
    68c0:	f9408040 	ldr	x0, [x2, #256]
    68c4:	f9006420 	str	x0, [x1, #200]
    68c8:	b5fff9c0 	cbnz	x0, 6800 <fwp_block+0x2c>
    68cc:	f900603f 	str	xzr, [x1, #192]
    68d0:	17ffffcc 	b	6800 <fwp_block+0x2c>
    68d4:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    68d8:	912ec000 	add	x0, x0, #0xbb0
    68dc:	97fff031 	bl	29a0 <getenv@plt>
    68e0:	5284e202 	mov	w2, #0x2710                	// #10000
    68e4:	b4000060 	cbz	x0, 68f0 <fwp_block+0x11c>
    68e8:	39400001 	ldrb	w1, [x0]
    68ec:	350000c1 	cbnz	w1, 6904 <fwp_block+0x130>
    68f0:	91018273 	add	x19, x19, #0x60
    68f4:	b903c262 	str	w2, [x19, #960]
    68f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6900:	d65f03c0 	ret
    6904:	52800142 	mov	w2, #0xa                   	// #10
    6908:	d2800001 	mov	x1, #0x0                   	// #0
    690c:	97ffef75 	bl	26e0 <strtoll@plt>
    6910:	d1000403 	sub	x3, x0, #0x1
    6914:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6918:	eb02007f 	cmp	x3, x2
    691c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6920:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6924:	17fffff3 	b	68f0 <fwp_block+0x11c>
    6928:	d503201f 	nop
    692c:	d503201f 	nop

0000000000006930 <fwp_drop4>:
    6930:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6934:	910003fd 	mov	x29, sp
    6938:	a90153f3 	stp	x19, x20, [sp, #16]
    693c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6940:	f90013f5 	str	x21, [sp, #32]
    6944:	91190275 	add	x21, x19, #0x640
    6948:	f949daa1 	ldr	x1, [x21, #5040]
    694c:	f949eea2 	ldr	x2, [x21, #5080]
    6950:	cb010001 	sub	x1, x0, x1
    6954:	eb02403f 	cmp	x1, x2, lsl #16
    6958:	54000382 	b.cs	69c8 <fwp_drop4+0x98>  // b.hs, b.nlast
    695c:	d350fc22 	lsr	x2, x1, #16
    6960:	f949fea3 	ldr	x3, [x21, #5112]
    6964:	8b020842 	add	x2, x2, x2, lsl #2
    6968:	d37df042 	lsl	x2, x2, #3
    696c:	8b020064 	add	x4, x3, x2
    6970:	f9401094 	ldr	x20, [x4, #32]
    6974:	b40002b4 	cbz	x20, 69c8 <fwp_drop4+0x98>
    6978:	38626862 	ldrb	w2, [x3, x2]
    697c:	7100085f 	cmp	w2, #0x2
    6980:	540007a0 	b.eq	6a74 <fwp_drop4+0x144>  // b.none
    6984:	7100045f 	cmp	w2, #0x1
    6988:	54000201 	b.ne	69c8 <fwp_drop4+0x98>  // b.any
    698c:	29430885 	ldp	w5, w2, [x4, #24]
    6990:	92403c21 	and	x1, x1, #0xffff
    6994:	9b057c21 	mul	x1, x1, x5
    6998:	d360fc21 	lsr	x1, x1, #32
    699c:	eb02003f 	cmp	x1, x2
    69a0:	54000142 	b.cs	69c8 <fwp_drop4+0x98>  // b.hs, b.nlast
    69a4:	8b010294 	add	x20, x20, x1
    69a8:	39400281 	ldrb	w1, [x20]
    69ac:	340000e1 	cbz	w1, 69c8 <fwp_drop4+0x98>
    69b0:	7100043f 	cmp	w1, #0x1
    69b4:	54000120 	b.eq	69d8 <fwp_drop4+0xa8>  // b.none
    69b8:	7103fc3f 	cmp	w1, #0xff
    69bc:	540007c0 	b.eq	6ab4 <fwp_drop4+0x184>  // b.none
    69c0:	51000421 	sub	w1, w1, #0x1
    69c4:	39000281 	strb	w1, [x20]
    69c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69cc:	f94013f5 	ldr	x21, [sp, #32]
    69d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69d4:	d65f03c0 	ret
    69d8:	f9400001 	ldr	x1, [x0]
    69dc:	b7f80581 	tbnz	x1, #63, 6a8c <fwp_drop4+0x15c>
    69e0:	91190273 	add	x19, x19, #0x640
    69e4:	f949da61 	ldr	x1, [x19, #5040]
    69e8:	f949ee62 	ldr	x2, [x19, #5080]
    69ec:	cb010001 	sub	x1, x0, x1
    69f0:	eb02403f 	cmp	x1, x2, lsl #16
    69f4:	54fffea2 	b.cs	69c8 <fwp_drop4+0x98>  // b.hs, b.nlast
    69f8:	d350fc22 	lsr	x2, x1, #16
    69fc:	8b020842 	add	x2, x2, x2, lsl #2
    6a00:	d37df042 	lsl	x2, x2, #3
    6a04:	8b020065 	add	x5, x3, x2
    6a08:	f94010a4 	ldr	x4, [x5, #32]
    6a0c:	b4fffde4 	cbz	x4, 69c8 <fwp_drop4+0x98>
    6a10:	38626862 	ldrb	w2, [x3, x2]
    6a14:	7100085f 	cmp	w2, #0x2
    6a18:	54000220 	b.eq	6a5c <fwp_drop4+0x12c>  // b.none
    6a1c:	7100045f 	cmp	w2, #0x1
    6a20:	54fffd41 	b.ne	69c8 <fwp_drop4+0x98>  // b.any
    6a24:	294308a3 	ldp	w3, w2, [x5, #24]
    6a28:	92403c21 	and	x1, x1, #0xffff
    6a2c:	9b037c21 	mul	x1, x1, x3
    6a30:	d360fc21 	lsr	x1, x1, #32
    6a34:	eb02003f 	cmp	x1, x2
    6a38:	54fffc82 	b.cs	69c8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a3c:	8b010084 	add	x4, x4, x1
    6a40:	39400081 	ldrb	w1, [x4]
    6a44:	7100043f 	cmp	w1, #0x1
    6a48:	54fffc01 	b.ne	69c8 <fwp_drop4+0x98>  // b.any
    6a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a50:	f94013f5 	ldr	x21, [sp, #32]
    6a54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a58:	17fff86e 	b	4c10 <fwp_mem_free>
    6a5c:	72003c3f 	tst	w1, #0xffff
    6a60:	54ffff00 	b.eq	6a40 <fwp_drop4+0x110>  // b.none
    6a64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a68:	f94013f5 	ldr	x21, [sp, #32]
    6a6c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a70:	d65f03c0 	ret
    6a74:	72003c3f 	tst	w1, #0xffff
    6a78:	54fff980 	b.eq	69a8 <fwp_drop4+0x78>  // b.none
    6a7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a80:	f94013f5 	ldr	x21, [sp, #32]
    6a84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a88:	d65f03c0 	ret
    6a8c:	f9400414 	ldr	x20, [x0, #8]
    6a90:	97fffbe4 	bl	5a20 <fwp_rc_free_arr>
    6a94:	91190260 	add	x0, x19, #0x640
    6a98:	f949d801 	ldr	x1, [x0, #5040]
    6a9c:	f949ec00 	ldr	x0, [x0, #5080]
    6aa0:	cb010281 	sub	x1, x20, x1
    6aa4:	eb00403f 	cmp	x1, x0, lsl #16
    6aa8:	54fff902 	b.cs	69c8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6aac:	aa1403e0 	mov	x0, x20
    6ab0:	17ffffab 	b	695c <fwp_drop4+0x2c>
    6ab4:	ca544680 	eor	x0, x20, x20, lsr #17
    6ab8:	91190273 	add	x19, x19, #0x640
    6abc:	ca402400 	eor	x0, x0, x0, lsr #9
    6ac0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6ac4:	f94a2400 	ldr	x0, [x0, #5192]
    6ac8:	b5000080 	cbnz	x0, 6ad8 <fwp_drop4+0x1a8>
    6acc:	14000010 	b	6b0c <fwp_drop4+0x1dc>
    6ad0:	f9400800 	ldr	x0, [x0, #16]
    6ad4:	b40001c0 	cbz	x0, 6b0c <fwp_drop4+0x1dc>
    6ad8:	f9400001 	ldr	x1, [x0]
    6adc:	eb14003f 	cmp	x1, x20
    6ae0:	54ffff81 	b.ne	6ad0 <fwp_drop4+0x1a0>  // b.any
    6ae4:	f9400401 	ldr	x1, [x0, #8]
    6ae8:	d1000421 	sub	x1, x1, #0x1
    6aec:	f9000401 	str	x1, [x0, #8]
    6af0:	f103f83f 	cmp	x1, #0xfe
    6af4:	54fff6a1 	b.ne	69c8 <fwp_drop4+0x98>  // b.any
    6af8:	aa1403e0 	mov	x0, x20
    6afc:	97fff7a5 	bl	4990 <fwp_rc_forget_slot>
    6b00:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b04:	39000280 	strb	w0, [x20]
    6b08:	17ffffb0 	b	69c8 <fwp_drop4+0x98>
    6b0c:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    6b10:	912a0000 	add	x0, x0, #0xa80
    6b14:	97fff31b 	bl	3780 <fwp_trap>
    6b18:	d503201f 	nop
    6b1c:	d503201f 	nop

0000000000006b20 <fwp_caps161>:
    6b20:	34000041 	cbz	w1, 6b28 <fwp_caps161+0x8>
    6b24:	d65f03c0 	ret
    6b28:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6b2c:	91190063 	add	x3, x3, #0x640
    6b30:	f949d861 	ldr	x1, [x3, #5040]
    6b34:	f949ec62 	ldr	x2, [x3, #5080]
    6b38:	cb010001 	sub	x1, x0, x1
    6b3c:	eb02403f 	cmp	x1, x2, lsl #16
    6b40:	54ffff22 	b.cs	6b24 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b44:	d350fc22 	lsr	x2, x1, #16
    6b48:	f949fc65 	ldr	x5, [x3, #5112]
    6b4c:	8b020842 	add	x2, x2, x2, lsl #2
    6b50:	d37df042 	lsl	x2, x2, #3
    6b54:	8b0200a4 	add	x4, x5, x2
    6b58:	f9401083 	ldr	x3, [x4, #32]
    6b5c:	b4fffe43 	cbz	x3, 6b24 <fwp_caps161+0x4>
    6b60:	386268a2 	ldrb	w2, [x5, x2]
    6b64:	7100085f 	cmp	w2, #0x2
    6b68:	540001c0 	b.eq	6ba0 <fwp_caps161+0x80>  // b.none
    6b6c:	7100045f 	cmp	w2, #0x1
    6b70:	54fffda1 	b.ne	6b24 <fwp_caps161+0x4>  // b.any
    6b74:	29430885 	ldp	w5, w2, [x4, #24]
    6b78:	92403c21 	and	x1, x1, #0xffff
    6b7c:	9b057c21 	mul	x1, x1, x5
    6b80:	d360fc21 	lsr	x1, x1, #32
    6b84:	eb02003f 	cmp	x1, x2
    6b88:	54fffce2 	b.cs	6b24 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b8c:	8b010063 	add	x3, x3, x1
    6b90:	39400061 	ldrb	w1, [x3]
    6b94:	7100043f 	cmp	w1, #0x1
    6b98:	54fffc61 	b.ne	6b24 <fwp_caps161+0x4>  // b.any
    6b9c:	17fff81d 	b	4c10 <fwp_mem_free>
    6ba0:	72003c3f 	tst	w1, #0xffff
    6ba4:	54ffff60 	b.eq	6b90 <fwp_caps161+0x70>  // b.none
    6ba8:	d65f03c0 	ret
    6bac:	d503201f 	nop

0000000000006bb0 <f12>:
    6bb0:	d10483ff 	sub	sp, sp, #0x120
    6bb4:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    6bb8:	f947f442 	ldr	x2, [x2, #4072]
    6bbc:	9100e3e8 	add	x8, sp, #0x38
    6bc0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    6bc4:	910303fd 	add	x29, sp, #0xc0
    6bc8:	a90f63f7 	stp	x23, x24, [sp, #240]
    6bcc:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    6bd0:	911902e3 	add	x3, x23, #0x640
    6bd4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    6bd8:	d00000d5 	adrp	x21, 20000 <__data_start>
    6bdc:	910182a4 	add	x4, x21, #0x60
    6be0:	f949d861 	ldr	x1, [x3, #5040]
    6be4:	a90d53f3 	stp	x19, x20, [sp, #208]
    6be8:	910103f8 	add	x24, sp, #0x40
    6bec:	f949ec65 	ldr	x5, [x3, #5080]
    6bf0:	a9106bf9 	stp	x25, x26, [sp, #256]
    6bf4:	d00000d9 	adrp	x25, 20000 <__data_start>
    6bf8:	a91173fb 	stp	x27, x28, [sp, #272]
    6bfc:	91004339 	add	x25, x25, #0x10
    6c00:	91008339 	add	x25, x25, #0x20
    6c04:	f941c886 	ldr	x6, [x4, #912]
    6c08:	f9400047 	ldr	x7, [x2]
    6c0c:	f9005fe7 	str	x7, [sp, #184]
    6c10:	d2800007 	mov	x7, #0x0                   	// #0
    6c14:	90000013 	adrp	x19, 6000 <fwp_drop1+0x100>
    6c18:	12800007 	mov	w7, #0xffffffff            	// #-1
    6c1c:	910f8262 	add	x2, x19, #0x3e0
    6c20:	cb010321 	sub	x1, x25, x1
    6c24:	f90003e8 	str	x8, [sp]
    6c28:	aa0003f4 	mov	x20, x0
    6c2c:	b9003be7 	str	w7, [sp, #56]
    6c30:	a9040be6 	stp	x6, x2, [sp, #64]
    6c34:	f9002be8 	str	x8, [sp, #80]
    6c38:	f901c898 	str	x24, [x4, #912]
    6c3c:	eb05403f 	cmp	x1, x5, lsl #16
    6c40:	540003a2 	b.cs	6cb4 <f12+0x104>  // b.hs, b.nlast
    6c44:	d350fc20 	lsr	x0, x1, #16
    6c48:	f949fc64 	ldr	x4, [x3, #5112]
    6c4c:	8b000800 	add	x0, x0, x0, lsl #2
    6c50:	d37df002 	lsl	x2, x0, #3
    6c54:	8b020083 	add	x3, x4, x2
    6c58:	f9401060 	ldr	x0, [x3, #32]
    6c5c:	b40002c0 	cbz	x0, 6cb4 <f12+0x104>
    6c60:	38626882 	ldrb	w2, [x4, x2]
    6c64:	7100085f 	cmp	w2, #0x2
    6c68:	54006ee0 	b.eq	7a44 <f12+0xe94>  // b.none
    6c6c:	7100045f 	cmp	w2, #0x1
    6c70:	54000221 	b.ne	6cb4 <f12+0x104>  // b.any
    6c74:	29430864 	ldp	w4, w2, [x3, #24]
    6c78:	92403c21 	and	x1, x1, #0xffff
    6c7c:	9b047c21 	mul	x1, x1, x4
    6c80:	d360fc21 	lsr	x1, x1, #32
    6c84:	eb02003f 	cmp	x1, x2
    6c88:	54000162 	b.cs	6cb4 <f12+0x104>  // b.hs, b.nlast
    6c8c:	8b010000 	add	x0, x0, x1
    6c90:	39400001 	ldrb	w1, [x0]
    6c94:	34000101 	cbz	w1, 6cb4 <f12+0x104>
    6c98:	910182a2 	add	x2, x21, #0x60
    6c9c:	b9413043 	ldr	w3, [x2, #304]
    6ca0:	35007063 	cbnz	w3, 7aac <f12+0xefc>
    6ca4:	7103f43f 	cmp	w1, #0xfd
    6ca8:	54007a28 	b.hi	7bec <f12+0x103c>  // b.pmore
    6cac:	11000421 	add	w1, w1, #0x1
    6cb0:	39000001 	strb	w1, [x0]
    6cb4:	aa1903e0 	mov	x0, x25
    6cb8:	97fffce6 	bl	6050 <fwp_closure_drop>
    6cbc:	b4006cf4 	cbz	x20, 7a58 <f12+0xea8>
    6cc0:	aa1403e0 	mov	x0, x20
    6cc4:	d2800001 	mov	x1, #0x0                   	// #0
    6cc8:	f9400800 	ldr	x0, [x0, #16]
    6ccc:	91000421 	add	x1, x1, #0x1
    6cd0:	b5ffffc0 	cbnz	x0, 6cc8 <f12+0x118>
    6cd4:	aa0103fa 	mov	x26, x1
    6cd8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6cdc:	eb00003f 	cmp	x1, x0
    6ce0:	54007c48 	b.hi	7c68 <f12+0x10b8>  // b.pmore
    6ce4:	910182b9 	add	x25, x21, #0x60
    6ce8:	b943c720 	ldr	w0, [x25, #964]
    6cec:	34006980 	cbz	w0, 7a1c <f12+0xe6c>
    6cf0:	910182a0 	add	x0, x21, #0x60
    6cf4:	f9406c1b 	ldr	x27, [x0, #216]
    6cf8:	f940b019 	ldr	x25, [x0, #352]
    6cfc:	eb1b033f 	cmp	x25, x27
    6d00:	5400368a 	b.ge	73d0 <f12+0x820>  // b.tcont
    6d04:	f9404401 	ldr	x1, [x0, #136]
    6d08:	8b190720 	add	x0, x25, x25, lsl #1
    6d0c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6d10:	8b000b20 	add	x0, x25, x0, lsl #2
    6d14:	8b000c20 	add	x0, x1, x0, lsl #3
    6d18:	b9400401 	ldr	w1, [x0, #4]
    6d1c:	35000081 	cbnz	w1, 6d2c <f12+0x17c>
    6d20:	b9400001 	ldr	w1, [x0]
    6d24:	6b02003f 	cmp	w1, w2
    6d28:	54003549 	b.ls	73d0 <f12+0x820>  // b.plast
    6d2c:	91000739 	add	x25, x25, #0x1
    6d30:	9101a000 	add	x0, x0, #0x68
    6d34:	eb1b033f 	cmp	x25, x27
    6d38:	54ffff01 	b.ne	6d18 <f12+0x168>  // b.any
    6d3c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6d40:	eb00037f 	cmp	x27, x0
    6d44:	540079ec 	b.gt	7c80 <f12+0x10d0>
    6d48:	910182a0 	add	x0, x21, #0x60
    6d4c:	f9409001 	ldr	x1, [x0, #288]
    6d50:	f940441c 	ldr	x28, [x0, #136]
    6d54:	eb1b003f 	cmp	x1, x27
    6d58:	54000221 	b.ne	6d9c <f12+0x1ec>  // b.any
    6d5c:	b400731b 	cbz	x27, 7bbc <f12+0x100c>
    6d60:	d37ffb76 	lsl	x22, x27, #1
    6d64:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6d68:	eb0002df 	cmp	x22, x0
    6d6c:	9a80d2d6 	csel	x22, x22, x0, le
    6d70:	8b1606c1 	add	x1, x22, x22, lsl #1
    6d74:	8b010ac1 	add	x1, x22, x1, lsl #2
    6d78:	d37df021 	lsl	x1, x1, #3
    6d7c:	aa1c03e0 	mov	x0, x28
    6d80:	52800002 	mov	w2, #0x0                   	// #0
    6d84:	97fff594 	bl	43d4 <ad_raw_realloc>
    6d88:	aa0003fc 	mov	x28, x0
    6d8c:	b40036e0 	cbz	x0, 7468 <f12+0x8b8>
    6d90:	910182a0 	add	x0, x21, #0x60
    6d94:	f900441c 	str	x28, [x0, #136]
    6d98:	f9009016 	str	x22, [x0, #288]
    6d9c:	8b1b0761 	add	x1, x27, x27, lsl #1
    6da0:	91000762 	add	x2, x27, #0x1
    6da4:	4f000400 	movi	v0.4s, #0x0
    6da8:	910182a0 	add	x0, x21, #0x60
    6dac:	8b010b61 	add	x1, x27, x1, lsl #2
    6db0:	8b19073b 	add	x27, x25, x25, lsl #1
    6db4:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    6db8:	8b010f81 	add	x1, x28, x1, lsl #3
    6dbc:	f9006c02 	str	x2, [x0, #216]
    6dc0:	b0000020 	adrp	x0, b000 <__divti3+0x160>
    6dc4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6dc8:	91270000 	add	x0, x0, #0x9c0
    6dcc:	ad000020 	stp	q0, q0, [x1]
    6dd0:	ad010020 	stp	q0, q0, [x1, #32]
    6dd4:	ad020020 	stp	q0, q0, [x1, #64]
    6dd8:	f900303f 	str	xzr, [x1, #96]
    6ddc:	f900337f 	str	xzr, [x27, #96]
    6de0:	97ffeef0 	bl	29a0 <getenv@plt>
    6de4:	b50030e0 	cbnz	x0, 7400 <f12+0x850>
    6de8:	910182a0 	add	x0, x21, #0x60
    6dec:	f9408c01 	ldr	x1, [x0, #280]
    6df0:	b5006421 	cbnz	x1, 7a74 <f12+0xec4>
    6df4:	910182a2 	add	x2, x21, #0x60
    6df8:	2f000400 	mvni	v0.2s, #0x0
    6dfc:	b9400363 	ldr	w3, [x27]
    6e00:	52800024 	mov	w4, #0x1                   	// #1
    6e04:	91000720 	add	x0, x25, #0x1
    6e08:	a900eb7a 	stp	x26, x26, [x27, #8]
    6e0c:	0b040063 	add	w3, w3, w4
    6e10:	f941c841 	ldr	x1, [x2, #912]
    6e14:	29001363 	stp	w3, w4, [x27]
    6e18:	f9002b7f 	str	xzr, [x27, #80]
    6e1c:	f900b040 	str	x0, [x2, #352]
    6e20:	fd002f60 	str	d0, [x27, #88]
    6e24:	b40071c1 	cbz	x1, 7c5c <f12+0x10ac>
    6e28:	910f8273 	add	x19, x19, #0x3e0
    6e2c:	14000003 	b	6e38 <f12+0x288>
    6e30:	f9400021 	ldr	x1, [x1]
    6e34:	b4007141 	cbz	x1, 7c5c <f12+0x10ac>
    6e38:	f9400422 	ldr	x2, [x1, #8]
    6e3c:	eb13005f 	cmp	x2, x19
    6e40:	54ffff81 	b.ne	6e30 <f12+0x280>  // b.any
    6e44:	f9400821 	ldr	x1, [x1, #16]
    6e48:	2a1903e4 	mov	w4, w25
    6e4c:	b9400022 	ldr	w2, [x1]
    6e50:	f9002b61 	str	x1, [x27, #80]
    6e54:	b9005f62 	str	w2, [x27, #92]
    6e58:	37f80082 	tbnz	w2, #31, 6e68 <f12+0x2b8>
    6e5c:	52800d05 	mov	w5, #0x68                  	// #104
    6e60:	9b257042 	smaddl	x2, w2, w5, x28
    6e64:	b9005859 	str	w25, [x2, #88]
    6e68:	b9000024 	str	w4, [x1]
    6e6c:	d3707c79 	ubfiz	x25, x3, #16, #32
    6e70:	aa000339 	orr	x25, x25, x0
    6e74:	d2800002 	mov	x2, #0x0                   	// #0
    6e78:	aa1403e0 	mov	x0, x20
    6e7c:	b4005a74 	cbz	x20, 79c8 <f12+0xe18>
    6e80:	f9400800 	ldr	x0, [x0, #16]
    6e84:	91000442 	add	x2, x2, #0x1
    6e88:	b5ffffc0 	cbnz	x0, 6e80 <f12+0x2d0>
    6e8c:	aa1403e1 	mov	x1, x20
    6e90:	f9400821 	ldr	x1, [x1, #16]
    6e94:	91000400 	add	x0, x0, #0x1
    6e98:	b5ffffc1 	cbnz	x1, 6e90 <f12+0x2e0>
    6e9c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6ea0:	eb01001f 	cmp	x0, x1
    6ea4:	54006ca8 	b.hi	7c38 <f12+0x1088>  // b.pmore
    6ea8:	f100005f 	cmp	x2, #0x0
    6eac:	540058ed 	b.le	79c8 <f12+0xe18>
    6eb0:	eb00005f 	cmp	x2, x0
    6eb4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6eb8:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6ebc:	eb01027f 	cmp	x19, x1
    6ec0:	54006bc8 	b.hi	7c38 <f12+0x1088>  // b.pmore
    6ec4:	d37ffa7a 	lsl	x26, x19, #1
    6ec8:	52800041 	mov	w1, #0x2                   	// #2
    6ecc:	91000740 	add	x0, x26, #0x1
    6ed0:	d37df000 	lsl	x0, x0, #3
    6ed4:	97fff86f 	bl	5090 <fwp_heap_alloc>
    6ed8:	aa0003fb 	mov	x27, x0
    6edc:	911902e1 	add	x1, x23, #0x640
    6ee0:	aa0103e0 	mov	x0, x1
    6ee4:	f900037a 	str	x26, [x27]
    6ee8:	f949d821 	ldr	x1, [x1, #5040]
    6eec:	f949ec00 	ldr	x0, [x0, #5080]
    6ef0:	cb010361 	sub	x1, x27, x1
    6ef4:	eb00403f 	cmp	x1, x0, lsl #16
    6ef8:	54005882 	b.cs	7a08 <f12+0xe58>  // b.hs, b.nlast
    6efc:	911902e2 	add	x2, x23, #0x640
    6f00:	d350fc20 	lsr	x0, x1, #16
    6f04:	8b000800 	add	x0, x0, x0, lsl #2
    6f08:	f949fc43 	ldr	x3, [x2, #5112]
    6f0c:	d37df002 	lsl	x2, x0, #3
    6f10:	8b020060 	add	x0, x3, x2
    6f14:	f940101a 	ldr	x26, [x0, #32]
    6f18:	b400025a 	cbz	x26, 6f60 <f12+0x3b0>
    6f1c:	38626862 	ldrb	w2, [x3, x2]
    6f20:	7100085f 	cmp	w2, #0x2
    6f24:	540058a0 	b.eq	7a38 <f12+0xe88>  // b.none
    6f28:	7100045f 	cmp	w2, #0x1
    6f2c:	540001a1 	b.ne	6f60 <f12+0x3b0>  // b.any
    6f30:	29430002 	ldp	w2, w0, [x0, #24]
    6f34:	92403c21 	and	x1, x1, #0xffff
    6f38:	9b027c21 	mul	x1, x1, x2
    6f3c:	d360fc21 	lsr	x1, x1, #32
    6f40:	eb00003f 	cmp	x1, x0
    6f44:	540000e2 	b.cs	6f60 <f12+0x3b0>  // b.hs, b.nlast
    6f48:	8b01035a 	add	x26, x26, x1
    6f4c:	39400340 	ldrb	w0, [x26]
    6f50:	7103fc1f 	cmp	w0, #0xff
    6f54:	540063a0 	b.eq	7bc8 <f12+0x1018>  // b.none
    6f58:	52800020 	mov	w0, #0x1                   	// #1
    6f5c:	39000340 	strb	w0, [x26]
    6f60:	b4000233 	cbz	x19, 6fa4 <f12+0x3f4>
    6f64:	d3607f24 	lsl	x4, x25, #32
    6f68:	aa1403e0 	mov	x0, x20
    6f6c:	f9400685 	ldr	x5, [x20, #8]
    6f70:	aa0403e3 	mov	x3, x4
    6f74:	91002362 	add	x2, x27, #0x8
    6f78:	d2800001 	mov	x1, #0x0                   	// #0
    6f7c:	14000005 	b	6f90 <f12+0x3e0>
    6f80:	f9400405 	ldr	x5, [x0, #8]
    6f84:	ab040023 	adds	x3, x1, x4
    6f88:	91004042 	add	x2, x2, #0x10
    6f8c:	54006846 	b.vs	7c94 <f12+0x10e4>
    6f90:	a9000c45 	stp	x5, x3, [x2]
    6f94:	91000421 	add	x1, x1, #0x1
    6f98:	f9400800 	ldr	x0, [x0, #16]
    6f9c:	eb01027f 	cmp	x19, x1
    6fa0:	54ffff08 	b.hi	6f80 <f12+0x3d0>  // b.pmore
    6fa4:	f9400360 	ldr	x0, [x27]
    6fa8:	f100041f 	cmp	x0, #0x1
    6fac:	54005329 	b.ls	7a10 <f12+0xe60>  // b.plast
    6fb0:	d341fc00 	lsr	x0, x0, #1
    6fb4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6fb8:	d100041a 	sub	x26, x0, #0x1
    6fbc:	eb01035f 	cmp	x26, x1
    6fc0:	540063c8 	b.hi	7c38 <f12+0x1088>  // b.pmore
    6fc4:	b400527a 	cbz	x26, 7a10 <f12+0xe60>
    6fc8:	d1002361 	sub	x1, x27, #0x8
    6fcc:	91002373 	add	x19, x27, #0x8
    6fd0:	8b00103c 	add	x28, x1, x0, lsl #4
    6fd4:	d503201f 	nop
    6fd8:	f9400660 	ldr	x0, [x19, #8]
    6fdc:	f9400e61 	ldr	x1, [x19, #24]
    6fe0:	fd400260 	ldr	d0, [x19]
    6fe4:	fd400a61 	ldr	d1, [x19, #16]
    6fe8:	97fff9c6 	bl	5700 <w107>
    6fec:	a9000660 	stp	x0, x1, [x19]
    6ff0:	91004273 	add	x19, x19, #0x10
    6ff4:	eb1c027f 	cmp	x19, x28
    6ff8:	54ffff01 	b.ne	6fd8 <f12+0x428>  // b.any
    6ffc:	aa1b03fc 	mov	x28, x27
    7000:	d37ffb53 	lsl	x19, x26, #1
    7004:	d2800016 	mov	x22, #0x0                   	// #0
    7008:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    700c:	f8010793 	str	x19, [x28], #16
    7010:	f8767b82 	ldr	x2, [x28, x22, lsl #3]
    7014:	aa1a03e0 	mov	x0, x26
    7018:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    701c:	91000ad6 	add	x22, x22, #0x2
    7020:	aa0303e1 	mov	x1, x3
    7024:	97fff904 	bl	5434 <fwp_p_ad_push>
    7028:	aa0003fa 	mov	x26, x0
    702c:	eb1302df 	cmp	x22, x19
    7030:	54ffff03 	b.cc	7010 <f12+0x460>  // b.lo, b.ul, b.last
    7034:	aa1b03e0 	mov	x0, x27
    7038:	93407f33 	sxtw	x19, w25
    703c:	97fffe3d 	bl	6930 <fwp_drop4>
    7040:	aa1303e0 	mov	x0, x19
    7044:	97fff29b 	bl	3ab0 <fwp_tape_of>
    7048:	f9403001 	ldr	x1, [x0, #96]
    704c:	aa0003ea 	mov	x10, x0
    7050:	b5006121 	cbnz	x1, 7c74 <f12+0x10c4>
    7054:	97ffefd0 	bl	2f94 <fwp_tape_unlink_scope>
    7058:	b9400002 	ldr	w2, [x0]
    705c:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7060:	a940801c 	ldp	x28, x0, [x0, #8]
    7064:	b900055f 	str	wzr, [x10, #4]
    7068:	a941994b 	ldp	x11, x6, [x10, #24]
    706c:	a942a147 	ldp	x7, x8, [x10, #40]
    7070:	a9439549 	ldp	x9, x5, [x10, #56]
    7074:	f940255b 	ldr	x27, [x10, #72]
    7078:	6b01005f 	cmp	w2, w1
    707c:	54000108 	b.hi	709c <f12+0x4ec>  // b.pmore
    7080:	910182a2 	add	x2, x21, #0x60
    7084:	92403e61 	and	x1, x19, #0xffff
    7088:	d1000421 	sub	x1, x1, #0x1
    708c:	f940b043 	ldr	x3, [x2, #352]
    7090:	eb03003f 	cmp	x1, x3
    7094:	5400004a 	b.ge	709c <f12+0x4ec>  // b.tcont
    7098:	f900b041 	str	x1, [x2, #352]
    709c:	4f000400 	movi	v0.4s, #0x0
    70a0:	910182a3 	add	x3, x21, #0x60
    70a4:	f9000d5f 	str	xzr, [x10, #24]
    70a8:	910163e1 	add	x1, sp, #0x58
    70ac:	9101c3f9 	add	x25, sp, #0x70
    70b0:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    70b4:	f941c86c 	ldr	x12, [x3, #912]
    70b8:	3c808140 	stur	q0, [x10, #8]
    70bc:	91129042 	add	x2, x2, #0x4a4
    70c0:	ad010140 	stp	q0, q0, [x10, #32]
    70c4:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    70c8:	a9058bec 	stp	x12, x2, [sp, #88]
    70cc:	a9069bf9 	stp	x25, x6, [sp, #104]
    70d0:	a907a3e7 	stp	x7, x8, [sp, #120]
    70d4:	a90897e9 	stp	x9, x5, [sp, #136]
    70d8:	a909efeb 	stp	x11, x27, [sp, #152]
    70dc:	f901c861 	str	x1, [x3, #912]
    70e0:	b7f84c1a 	tbnz	x26, #63, 7a60 <f12+0xeb0>
    70e4:	eb9a827f 	cmp	x19, x26, asr #32
    70e8:	54005961 	b.ne	7c14 <f12+0x1064>  // b.any
    70ec:	92407f53 	and	x19, x26, #0xffffffff
    70f0:	eb3a401f 	cmp	x0, w26, uxtw
    70f4:	5400596d 	b.le	7c20 <f12+0x1070>
    70f8:	eb1c027f 	cmp	x19, x28
    70fc:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    7100:	eb13037f 	cmp	x27, x19
    7104:	540019ea 	b.ge	7440 <f12+0x890>  // b.tcont
    7108:	f100037f 	cmp	x27, #0x0
    710c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7110:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7114:	14000004 	b	7124 <f12+0x574>
    7118:	eb01037f 	cmp	x27, x1
    711c:	d37ffb7b 	lsl	x27, x27, #1
    7120:	9a93d37b 	csel	x27, x27, x19, le
    7124:	eb13037f 	cmp	x27, x19
    7128:	54ffff8b 	b.lt	7118 <f12+0x568>  // b.tstop
    712c:	b4004e25 	cbz	x5, 7af0 <f12+0xf40>
    7130:	aa0503e0 	mov	x0, x5
    7134:	d37df361 	lsl	x1, x27, #3
    7138:	52800062 	mov	w2, #0x3                   	// #3
    713c:	a9009fe6 	stp	x6, x7, [sp, #8]
    7140:	a901a7e8 	stp	x8, x9, [sp, #24]
    7144:	97fff4a4 	bl	43d4 <ad_raw_realloc>
    7148:	aa0003e5 	mov	x5, x0
    714c:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7150:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7154:	b4004b40 	cbz	x0, 7abc <f12+0xf0c>
    7158:	f9004be5 	str	x5, [sp, #144]
    715c:	f90053fb 	str	x27, [sp, #160]
    7160:	b50015d3 	cbnz	x19, 7418 <f12+0x868>
    7164:	b7f800da 	tbnz	x26, #63, 717c <f12+0x5cc>
    7168:	92407f40 	and	x0, x26, #0xffffffff
    716c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7170:	fc6078a0 	ldr	d0, [x5, x0, lsl #3]
    7174:	1e612800 	fadd	d0, d0, d1
    7178:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    717c:	d1000673 	sub	x19, x19, #0x1
    7180:	d1000783 	sub	x3, x28, #0x1
    7184:	eb13039f 	cmp	x28, x19
    7188:	540003ac 	b.gt	71fc <f12+0x64c>
    718c:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7190:	1e602008 	fcmp	d0, #0.0
    7194:	540002e0 	b.eq	71f0 <f12+0x640>  // b.none
    7198:	cb1c0be0 	neg	x0, x28, lsl #2
    719c:	cb1c03e2 	neg	x2, x28
    71a0:	8b0000c1 	add	x1, x6, x0
    71a4:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    71a8:	37f80101 	tbnz	w1, #31, 71c8 <f12+0x618>
    71ac:	8b020d0a 	add	x10, x8, x2, lsl #3
    71b0:	93407c21 	sxtw	x1, w1
    71b4:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    71b8:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    71bc:	1e620802 	fmul	d2, d0, d2
    71c0:	1e622821 	fadd	d1, d1, d2
    71c4:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    71c8:	8b0000e0 	add	x0, x7, x0
    71cc:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    71d0:	37f80100 	tbnz	w0, #31, 71f0 <f12+0x640>
    71d4:	8b020d22 	add	x2, x9, x2, lsl #3
    71d8:	93407c00 	sxtw	x0, w0
    71dc:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    71e0:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    71e4:	1e620800 	fmul	d0, d0, d2
    71e8:	1e602820 	fadd	d0, d1, d0
    71ec:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    71f0:	d1000673 	sub	x19, x19, #0x1
    71f4:	eb13007f 	cmp	x3, x19
    71f8:	54fffca1 	b.ne	718c <f12+0x5dc>  // b.any
    71fc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7200:	eb00039f 	cmp	x28, x0
    7204:	54005208 	b.hi	7c44 <f12+0x1094>  // b.pmore
    7208:	91000780 	add	x0, x28, #0x1
    720c:	52800041 	mov	w1, #0x2                   	// #2
    7210:	f90007e5 	str	x5, [sp, #8]
    7214:	d37df000 	lsl	x0, x0, #3
    7218:	97fff79e 	bl	5090 <fwp_heap_alloc>
    721c:	aa0003e2 	mov	x2, x0
    7220:	aa0003f3 	mov	x19, x0
    7224:	f94007e5 	ldr	x5, [sp, #8]
    7228:	d2800001 	mov	x1, #0x0                   	// #0
    722c:	f800845c 	str	x28, [x2], #8
    7230:	b40000fc 	cbz	x28, 724c <f12+0x69c>
    7234:	d503201f 	nop
    7238:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    723c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7240:	91000421 	add	x1, x1, #0x1
    7244:	eb01039f 	cmp	x28, x1
    7248:	54ffff81 	b.ne	7238 <f12+0x688>  // b.any
    724c:	910182a1 	add	x1, x21, #0x60
    7250:	aa1903e0 	mov	x0, x25
    7254:	f9402ffa 	ldr	x26, [sp, #88]
    7258:	f901c83a 	str	x26, [x1, #912]
    725c:	97fff492 	bl	44a4 <fwp_tape_buffers_release>
    7260:	911902e2 	add	x2, x23, #0x640
    7264:	f949d841 	ldr	x1, [x2, #5040]
    7268:	f949ec40 	ldr	x0, [x2, #5080]
    726c:	cb010261 	sub	x1, x19, x1
    7270:	eb00403f 	cmp	x1, x0, lsl #16
    7274:	54000322 	b.cs	72d8 <f12+0x728>  // b.hs, b.nlast
    7278:	d350fc20 	lsr	x0, x1, #16
    727c:	f949fc43 	ldr	x3, [x2, #5112]
    7280:	8b000800 	add	x0, x0, x0, lsl #2
    7284:	d37df002 	lsl	x2, x0, #3
    7288:	8b020060 	add	x0, x3, x2
    728c:	f9401019 	ldr	x25, [x0, #32]
    7290:	b4000259 	cbz	x25, 72d8 <f12+0x728>
    7294:	38626862 	ldrb	w2, [x3, x2]
    7298:	7100085f 	cmp	w2, #0x2
    729c:	54003e60 	b.eq	7a68 <f12+0xeb8>  // b.none
    72a0:	7100045f 	cmp	w2, #0x1
    72a4:	540001a1 	b.ne	72d8 <f12+0x728>  // b.any
    72a8:	29430002 	ldp	w2, w0, [x0, #24]
    72ac:	92403c21 	and	x1, x1, #0xffff
    72b0:	9b027c21 	mul	x1, x1, x2
    72b4:	d360fc21 	lsr	x1, x1, #32
    72b8:	eb00003f 	cmp	x1, x0
    72bc:	540000e2 	b.cs	72d8 <f12+0x728>  // b.hs, b.nlast
    72c0:	8b010339 	add	x25, x25, x1
    72c4:	39400320 	ldrb	w0, [x25]
    72c8:	7103fc1f 	cmp	w0, #0xff
    72cc:	54004840 	b.eq	7bd4 <f12+0x1024>  // b.none
    72d0:	52800020 	mov	w0, #0x1                   	// #1
    72d4:	39000320 	strb	w0, [x25]
    72d8:	eb18035f 	cmp	x26, x24
    72dc:	54004da1 	b.ne	7c90 <f12+0x10e0>  // b.any
    72e0:	f94003e0 	ldr	x0, [sp]
    72e4:	910182b5 	add	x21, x21, #0x60
    72e8:	f94023e1 	ldr	x1, [sp, #64]
    72ec:	f901caa1 	str	x1, [x21, #912]
    72f0:	97fffc3c 	bl	63e0 <fwp_tape_scope_release>
    72f4:	f9400260 	ldr	x0, [x19]
    72f8:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    72fc:	b7f83120 	tbnz	x0, #63, 7920 <f12+0xd70>
    7300:	911902e2 	add	x2, x23, #0x640
    7304:	f949d840 	ldr	x0, [x2, #5040]
    7308:	f949ec41 	ldr	x1, [x2, #5080]
    730c:	cb000260 	sub	x0, x19, x0
    7310:	eb01401f 	cmp	x0, x1, lsl #16
    7314:	54003062 	b.cs	7920 <f12+0xd70>  // b.hs, b.nlast
    7318:	d350fc01 	lsr	x1, x0, #16
    731c:	f949fc44 	ldr	x4, [x2, #5112]
    7320:	8b010821 	add	x1, x1, x1, lsl #2
    7324:	d37df021 	lsl	x1, x1, #3
    7328:	8b010083 	add	x3, x4, x1
    732c:	f9401062 	ldr	x2, [x3, #32]
    7330:	b4002f82 	cbz	x2, 7920 <f12+0xd70>
    7334:	38616881 	ldrb	w1, [x4, x1]
    7338:	7100083f 	cmp	w1, #0x2
    733c:	54002ec0 	b.eq	7914 <f12+0xd64>  // b.none
    7340:	7100043f 	cmp	w1, #0x1
    7344:	54002ee1 	b.ne	7920 <f12+0xd70>  // b.any
    7348:	29430464 	ldp	w4, w1, [x3, #24]
    734c:	92403c00 	and	x0, x0, #0xffff
    7350:	9b047c00 	mul	x0, x0, x4
    7354:	d360fc00 	lsr	x0, x0, #32
    7358:	eb01001f 	cmp	x0, x1
    735c:	54002e22 	b.cs	7920 <f12+0xd70>  // b.hs, b.nlast
    7360:	8b000042 	add	x2, x2, x0
    7364:	39400040 	ldrb	w0, [x2]
    7368:	7100041f 	cmp	w0, #0x1
    736c:	54002da1 	b.ne	7920 <f12+0xd70>  // b.any
    7370:	aa1303f5 	mov	x21, x19
    7374:	d2800000 	mov	x0, #0x0                   	// #0
    7378:	f90003f3 	str	x19, [sp]
    737c:	f94003e1 	ldr	x1, [sp]
    7380:	91002023 	add	x3, x1, #0x8
    7384:	d2800001 	mov	x1, #0x0                   	// #0
    7388:	b4000898 	cbz	x24, 7498 <f12+0x8e8>
    738c:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0xa40>
    7390:	91002265 	add	x5, x19, #0x8
    7394:	fd42c841 	ldr	d1, [x2, #1424]
    7398:	14000009 	b	73bc <f12+0x80c>
    739c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    73a0:	f94002a2 	ldr	x2, [x21]
    73a4:	1e600820 	fmul	d0, d1, d0
    73a8:	b7f84422 	tbnz	x2, #63, 7c2c <f12+0x107c>
    73ac:	91000421 	add	x1, x1, #0x1
    73b0:	fc008460 	str	d0, [x3], #8
    73b4:	eb01031f 	cmp	x24, x1
    73b8:	54000700 	b.eq	7498 <f12+0x8e8>  // b.none
    73bc:	f9400264 	ldr	x4, [x19]
    73c0:	aa0503e2 	mov	x2, x5
    73c4:	b6fffec4 	tbz	x4, #63, 739c <f12+0x7ec>
    73c8:	f9400a62 	ldr	x2, [x19, #16]
    73cc:	17fffff4 	b	739c <f12+0x7ec>
    73d0:	eb1b033f 	cmp	x25, x27
    73d4:	54ffcb40 	b.eq	6d3c <f12+0x18c>  // b.none
    73d8:	910182a0 	add	x0, x21, #0x60
    73dc:	8b19073b 	add	x27, x25, x25, lsl #1
    73e0:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    73e4:	f940441c 	ldr	x28, [x0, #136]
    73e8:	90000020 	adrp	x0, b000 <__divti3+0x160>
    73ec:	91270000 	add	x0, x0, #0x9c0
    73f0:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    73f4:	f900337f 	str	xzr, [x27, #96]
    73f8:	97ffed6a 	bl	29a0 <getenv@plt>
    73fc:	b4ffcf60 	cbz	x0, 6de8 <f12+0x238>
    7400:	39400001 	ldrb	w1, [x0]
    7404:	7100c03f 	cmp	w1, #0x30
    7408:	54ffcf01 	b.ne	6de8 <f12+0x238>  // b.any
    740c:	39400400 	ldrb	w0, [x0, #1]
    7410:	34ffcf20 	cbz	w0, 6df4 <f12+0x244>
    7414:	17fffe75 	b	6de8 <f12+0x238>
    7418:	aa0503e0 	mov	x0, x5
    741c:	d37df262 	lsl	x2, x19, #3
    7420:	52800001 	mov	w1, #0x0                   	// #0
    7424:	a9009fe6 	stp	x6, x7, [sp, #8]
    7428:	a901a7e8 	stp	x8, x9, [sp, #24]
    742c:	97ffeced 	bl	27e0 <memset@plt>
    7430:	aa0003e5 	mov	x5, x0
    7434:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7438:	a941a7e8 	ldp	x8, x9, [sp, #24]
    743c:	17ffff4a 	b	7164 <f12+0x5b4>
    7440:	f10000bf 	cmp	x5, #0x0
    7444:	1a9f17e0 	cset	w0, eq	// eq = none
    7448:	f100027f 	cmp	x19, #0x0
    744c:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    7450:	54ffe880 	b.eq	7160 <f12+0x5b0>  // b.none
    7454:	f9402fe1 	ldr	x1, [sp, #88]
    7458:	910182b5 	add	x21, x21, #0x60
    745c:	aa1903e0 	mov	x0, x25
    7460:	f901caa1 	str	x1, [x21, #912]
    7464:	97fff410 	bl	44a4 <fwp_tape_buffers_release>
    7468:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    746c:	f947e863 	ldr	x3, [x3, #4048]
    7470:	d2800262 	mov	x2, #0x13                  	// #19
    7474:	d2800021 	mov	x1, #0x1                   	// #1
    7478:	90000020 	adrp	x0, b000 <__divti3+0x160>
    747c:	91172000 	add	x0, x0, #0x5c8
    7480:	f9400063 	ldr	x3, [x3]
    7484:	97ffed23 	bl	2910 <fwrite@plt>
    7488:	d2800000 	mov	x0, #0x0                   	// #0
    748c:	97ffed2d 	bl	2940 <fflush@plt>
    7490:	52800cc0 	mov	w0, #0x66                  	// #102
    7494:	97ffed3b 	bl	2980 <_Exit@plt>
    7498:	97fffd26 	bl	6930 <fwp_drop4>
    749c:	aa1403e1 	mov	x1, x20
    74a0:	d2800002 	mov	x2, #0x0                   	// #0
    74a4:	b4003774 	cbz	x20, 7b90 <f12+0xfe0>
    74a8:	f9400821 	ldr	x1, [x1, #16]
    74ac:	91000442 	add	x2, x2, #0x1
    74b0:	b5ffffc1 	cbnz	x1, 74a8 <f12+0x8f8>
    74b4:	f94002a3 	ldr	x3, [x21]
    74b8:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    74bc:	b7f81f43 	tbnz	x3, #63, 78a4 <f12+0xcf4>
    74c0:	911902e1 	add	x1, x23, #0x640
    74c4:	f94003e4 	ldr	x4, [sp]
    74c8:	f949d820 	ldr	x0, [x1, #5040]
    74cc:	f949ec21 	ldr	x1, [x1, #5080]
    74d0:	cb000080 	sub	x0, x4, x0
    74d4:	eb01401f 	cmp	x0, x1, lsl #16
    74d8:	54001e62 	b.cs	78a4 <f12+0xcf4>  // b.hs, b.nlast
    74dc:	911902e4 	add	x4, x23, #0x640
    74e0:	d350fc01 	lsr	x1, x0, #16
    74e4:	8b010821 	add	x1, x1, x1, lsl #2
    74e8:	f949fc86 	ldr	x6, [x4, #5112]
    74ec:	d37df021 	lsl	x1, x1, #3
    74f0:	8b0100c5 	add	x5, x6, x1
    74f4:	f94010a4 	ldr	x4, [x5, #32]
    74f8:	b4001d44 	cbz	x4, 78a0 <f12+0xcf0>
    74fc:	386168c1 	ldrb	w1, [x6, x1]
    7500:	7100083f 	cmp	w1, #0x2
    7504:	54001ca0 	b.eq	7898 <f12+0xce8>  // b.none
    7508:	7100043f 	cmp	w1, #0x1
    750c:	54001ca1 	b.ne	78a0 <f12+0xcf0>  // b.any
    7510:	294304a6 	ldp	w6, w1, [x5, #24]
    7514:	92403c00 	and	x0, x0, #0xffff
    7518:	9b067c00 	mul	x0, x0, x6
    751c:	d360fc00 	lsr	x0, x0, #32
    7520:	eb01001f 	cmp	x0, x1
    7524:	54001be2 	b.cs	78a0 <f12+0xcf0>  // b.hs, b.nlast
    7528:	8b000084 	add	x4, x4, x0
    752c:	39400098 	ldrb	w24, [x4]
    7530:	7100071f 	cmp	w24, #0x1
    7534:	54001b61 	b.ne	78a0 <f12+0xcf0>  // b.any
    7538:	b9000bf8 	str	w24, [sp, #8]
    753c:	eb02039f 	cmp	x28, x2
    7540:	9a82939c 	csel	x28, x28, x2, ls	// ls = plast
    7544:	910022b9 	add	x25, x21, #0x8
    7548:	b400361c 	cbz	x28, 7c08 <f12+0x1058>
    754c:	f94003e0 	ldr	x0, [sp]
    7550:	d37df385 	lsl	x5, x28, #3
    7554:	aa1403e2 	mov	x2, x20
    7558:	d2800001 	mov	x1, #0x0                   	// #0
    755c:	91002000 	add	x0, x0, #0x8
    7560:	1400000a 	b	7588 <f12+0x9d8>
    7564:	fc616881 	ldr	d1, [x4, x1]
    7568:	fd400440 	ldr	d0, [x2, #8]
    756c:	1e613800 	fsub	d0, d0, d1
    7570:	fc216b20 	str	d0, [x25, x1]
    7574:	91002021 	add	x1, x1, #0x8
    7578:	f9400842 	ldr	x2, [x2, #16]
    757c:	eb05003f 	cmp	x1, x5
    7580:	540001c0 	b.eq	75b8 <f12+0xa08>  // b.none
    7584:	f94002a3 	ldr	x3, [x21]
    7588:	aa0003e4 	mov	x4, x0
    758c:	b6fffec3 	tbz	x3, #63, 7564 <f12+0x9b4>
    7590:	f94003e3 	ldr	x3, [sp]
    7594:	fd400440 	ldr	d0, [x2, #8]
    7598:	f9400864 	ldr	x4, [x3, #16]
    759c:	fc616881 	ldr	d1, [x4, x1]
    75a0:	1e613800 	fsub	d0, d0, d1
    75a4:	fc216b20 	str	d0, [x25, x1]
    75a8:	91002021 	add	x1, x1, #0x8
    75ac:	f9400842 	ldr	x2, [x2, #16]
    75b0:	eb05003f 	cmp	x1, x5
    75b4:	54fffe81 	b.ne	7584 <f12+0x9d4>  // b.any
    75b8:	b4003254 	cbz	x20, 7c00 <f12+0x1050>
    75bc:	911902e0 	add	x0, x23, #0x640
    75c0:	aa1403e2 	mov	x2, x20
    75c4:	d280001a 	mov	x26, #0x0                   	// #0
    75c8:	f949ec06 	ldr	x6, [x0, #5080]
    75cc:	f949d807 	ldr	x7, [x0, #5040]
    75d0:	f949fc05 	ldr	x5, [x0, #5112]
    75d4:	d370bcc6 	lsl	x6, x6, #16
    75d8:	14000006 	b	75f0 <f12+0xa40>
    75dc:	f9400842 	ldr	x2, [x2, #16]
    75e0:	9100075a 	add	x26, x26, #0x1
    75e4:	f100005f 	cmp	x2, #0x0
    75e8:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    75ec:	54000329 	b.ls	7650 <f12+0xaa0>  // b.plast
    75f0:	cb070040 	sub	x0, x2, x7
    75f4:	eb06001f 	cmp	x0, x6
    75f8:	540002c2 	b.cs	7650 <f12+0xaa0>  // b.hs, b.nlast
    75fc:	d350fc01 	lsr	x1, x0, #16
    7600:	8b010821 	add	x1, x1, x1, lsl #2
    7604:	d37df021 	lsl	x1, x1, #3
    7608:	8b0100a4 	add	x4, x5, x1
    760c:	f9401083 	ldr	x3, [x4, #32]
    7610:	b4000203 	cbz	x3, 7650 <f12+0xaa0>
    7614:	386168a1 	ldrb	w1, [x5, x1]
    7618:	7100083f 	cmp	w1, #0x2
    761c:	54000de0 	b.eq	77d8 <f12+0xc28>  // b.none
    7620:	7100043f 	cmp	w1, #0x1
    7624:	54000161 	b.ne	7650 <f12+0xaa0>  // b.any
    7628:	29430488 	ldp	w8, w1, [x4, #24]
    762c:	92403c00 	and	x0, x0, #0xffff
    7630:	9b087c00 	mul	x0, x0, x8
    7634:	d360fc00 	lsr	x0, x0, #32
    7638:	eb01001f 	cmp	x0, x1
    763c:	540000a2 	b.cs	7650 <f12+0xaa0>  // b.hs, b.nlast
    7640:	8b000063 	add	x3, x3, x0
    7644:	39400060 	ldrb	w0, [x3]
    7648:	7100041f 	cmp	w0, #0x1
    764c:	54fffc80 	b.eq	75dc <f12+0xa2c>  // b.none
    7650:	eb1a039f 	cmp	x28, x26
    7654:	54000ca9 	b.ls	77e8 <f12+0xc38>  // b.plast
    7658:	d1002336 	sub	x22, x25, #0x8
    765c:	9102a3f5 	add	x21, sp, #0xa8
    7660:	911902f8 	add	x24, x23, #0x640
    7664:	d2800013 	mov	x19, #0x0                   	// #0
    7668:	14000012 	b	76b0 <f12+0xb00>
    766c:	7100045f 	cmp	w2, #0x1
    7670:	540001a1 	b.ne	76a4 <f12+0xaf4>  // b.any
    7674:	29430002 	ldp	w2, w0, [x0, #24]
    7678:	92403c21 	and	x1, x1, #0xffff
    767c:	9b027c21 	mul	x1, x1, x2
    7680:	d360fc21 	lsr	x1, x1, #32
    7684:	eb00003f 	cmp	x1, x0
    7688:	540000e2 	b.cs	76a4 <f12+0xaf4>  // b.hs, b.nlast
    768c:	8b01037b 	add	x27, x27, x1
    7690:	39400360 	ldrb	w0, [x27]
    7694:	7103fc1f 	cmp	w0, #0xff
    7698:	54001b20 	b.eq	79fc <f12+0xe4c>  // b.none
    769c:	52800020 	mov	w0, #0x1                   	// #1
    76a0:	39000360 	strb	w0, [x27]
    76a4:	d100079c 	sub	x28, x28, #0x1
    76a8:	eb1c035f 	cmp	x26, x28
    76ac:	54000362 	b.cs	7718 <f12+0xb68>  // b.hs, b.nlast
    76b0:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    76b4:	aa1503e1 	mov	x1, x21
    76b8:	52800020 	mov	w0, #0x1                   	// #1
    76bc:	a90acfe2 	stp	x2, x19, [sp, #168]
    76c0:	97fff854 	bl	5810 <fwp_data.part.0.constprop.0>
    76c4:	aa0003f3 	mov	x19, x0
    76c8:	f949db01 	ldr	x1, [x24, #5040]
    76cc:	f949ef00 	ldr	x0, [x24, #5080]
    76d0:	cb010261 	sub	x1, x19, x1
    76d4:	eb00403f 	cmp	x1, x0, lsl #16
    76d8:	54fffe62 	b.cs	76a4 <f12+0xaf4>  // b.hs, b.nlast
    76dc:	d350fc22 	lsr	x2, x1, #16
    76e0:	f949ff03 	ldr	x3, [x24, #5112]
    76e4:	8b020842 	add	x2, x2, x2, lsl #2
    76e8:	d37df042 	lsl	x2, x2, #3
    76ec:	8b020060 	add	x0, x3, x2
    76f0:	f940101b 	ldr	x27, [x0, #32]
    76f4:	b4fffd9b 	cbz	x27, 76a4 <f12+0xaf4>
    76f8:	38626862 	ldrb	w2, [x3, x2]
    76fc:	7100085f 	cmp	w2, #0x2
    7700:	54fffb61 	b.ne	766c <f12+0xabc>  // b.any
    7704:	72003c3f 	tst	w1, #0xffff
    7708:	54fffc40 	b.eq	7690 <f12+0xae0>  // b.none
    770c:	d100079c 	sub	x28, x28, #0x1
    7710:	eb1c035f 	cmp	x26, x28
    7714:	54fffce3 	b.cc	76b0 <f12+0xb00>  // b.lo, b.ul, b.last
    7718:	b50006ba 	cbnz	x26, 77ec <f12+0xc3c>
    771c:	b9400be0 	ldr	w0, [sp, #8]
    7720:	d2800038 	mov	x24, #0x1                   	// #1
    7724:	d280001b 	mov	x27, #0x0                   	// #0
    7728:	7100001f 	cmp	w0, #0x0
    772c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7730:	b40007db 	cbz	x27, 7828 <f12+0xc78>
    7734:	d100077b 	sub	x27, x27, #0x1
    7738:	911902f7 	add	x23, x23, #0x640
    773c:	d503201f 	nop
    7740:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7744:	aa1503e1 	mov	x1, x21
    7748:	52800020 	mov	w0, #0x1                   	// #1
    774c:	a90acfe2 	stp	x2, x19, [sp, #168]
    7750:	97fff830 	bl	5810 <fwp_data.part.0.constprop.0>
    7754:	aa0003f3 	mov	x19, x0
    7758:	f949dae1 	ldr	x1, [x23, #5040]
    775c:	f949eee0 	ldr	x0, [x23, #5080]
    7760:	cb010261 	sub	x1, x19, x1
    7764:	eb00403f 	cmp	x1, x0, lsl #16
    7768:	54000302 	b.cs	77c8 <f12+0xc18>  // b.hs, b.nlast
    776c:	d350fc22 	lsr	x2, x1, #16
    7770:	f949fee3 	ldr	x3, [x23, #5112]
    7774:	8b020842 	add	x2, x2, x2, lsl #2
    7778:	d37df042 	lsl	x2, x2, #3
    777c:	8b020060 	add	x0, x3, x2
    7780:	f940101a 	ldr	x26, [x0, #32]
    7784:	b400023a 	cbz	x26, 77c8 <f12+0xc18>
    7788:	38626862 	ldrb	w2, [x3, x2]
    778c:	7100085f 	cmp	w2, #0x2
    7790:	540007e0 	b.eq	788c <f12+0xcdc>  // b.none
    7794:	7100045f 	cmp	w2, #0x1
    7798:	54000181 	b.ne	77c8 <f12+0xc18>  // b.any
    779c:	29430002 	ldp	w2, w0, [x0, #24]
    77a0:	92403c21 	and	x1, x1, #0xffff
    77a4:	9b027c21 	mul	x1, x1, x2
    77a8:	d360fc21 	lsr	x1, x1, #32
    77ac:	eb00003f 	cmp	x1, x0
    77b0:	540000c2 	b.cs	77c8 <f12+0xc18>  // b.hs, b.nlast
    77b4:	8b01035a 	add	x26, x26, x1
    77b8:	39400340 	ldrb	w0, [x26]
    77bc:	7103fc1f 	cmp	w0, #0xff
    77c0:	54000600 	b.eq	7880 <f12+0xcd0>  // b.none
    77c4:	39000358 	strb	w24, [x26]
    77c8:	d100077b 	sub	x27, x27, #0x1
    77cc:	b100077f 	cmn	x27, #0x1
    77d0:	54fffb81 	b.ne	7740 <f12+0xb90>  // b.any
    77d4:	14000015 	b	7828 <f12+0xc78>
    77d8:	72003c1f 	tst	w0, #0xffff
    77dc:	54fff340 	b.eq	7644 <f12+0xa94>  // b.none
    77e0:	eb1a039f 	cmp	x28, x26
    77e4:	54fff3a8 	b.hi	7658 <f12+0xaa8>  // b.pmore
    77e8:	d2800013 	mov	x19, #0x0                   	// #0
    77ec:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    77f0:	aa1903e1 	mov	x1, x25
    77f4:	aa1403e0 	mov	x0, x20
    77f8:	f8408422 	ldr	x2, [x1], #8
    77fc:	f9000402 	str	x2, [x0, #8]
    7800:	aa0003e2 	mov	x2, x0
    7804:	f9400800 	ldr	x0, [x0, #16]
    7808:	eb1a003f 	cmp	x1, x26
    780c:	54ffff61 	b.ne	77f8 <f12+0xc48>  // b.any
    7810:	b9400be1 	ldr	w1, [sp, #8]
    7814:	f9000853 	str	x19, [x2, #16]
    7818:	aa1403f3 	mov	x19, x20
    781c:	aa0003f4 	mov	x20, x0
    7820:	34000041 	cbz	w1, 7828 <f12+0xc78>
    7824:	d2800019 	mov	x25, #0x0                   	// #0
    7828:	aa1903e0 	mov	x0, x25
    782c:	97fff4f9 	bl	4c10 <fwp_mem_free>
    7830:	f94003e0 	ldr	x0, [sp]
    7834:	97fffc3f 	bl	6930 <fwp_drop4>
    7838:	aa1403e0 	mov	x0, x20
    783c:	97fff955 	bl	5d90 <fwp_drop0>
    7840:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7844:	f947f400 	ldr	x0, [x0, #4072]
    7848:	f9405fe2 	ldr	x2, [sp, #184]
    784c:	f9400001 	ldr	x1, [x0]
    7850:	eb010042 	subs	x2, x2, x1
    7854:	d2800001 	mov	x1, #0x0                   	// #0
    7858:	540021a1 	b.ne	7c8c <f12+0x10dc>  // b.any
    785c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    7860:	aa1303e0 	mov	x0, x19
    7864:	a94d53f3 	ldp	x19, x20, [sp, #208]
    7868:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    786c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    7870:	a9506bf9 	ldp	x25, x26, [sp, #256]
    7874:	a95173fb 	ldp	x27, x28, [sp, #272]
    7878:	910483ff 	add	sp, sp, #0x120
    787c:	d65f03c0 	ret
    7880:	aa1a03e0 	mov	x0, x26
    7884:	97fff443 	bl	4990 <fwp_rc_forget_slot>
    7888:	17ffffcf 	b	77c4 <f12+0xc14>
    788c:	72003c3f 	tst	w1, #0xffff
    7890:	54fff9c1 	b.ne	77c8 <f12+0xc18>  // b.any
    7894:	17ffffc9 	b	77b8 <f12+0xc08>
    7898:	72003c1f 	tst	w0, #0xffff
    789c:	54ffe480 	b.eq	752c <f12+0x97c>  // b.none
    78a0:	b4001154 	cbz	x20, 7ac8 <f12+0xf18>
    78a4:	aa1403f3 	mov	x19, x20
    78a8:	d2800018 	mov	x24, #0x0                   	// #0
    78ac:	d503201f 	nop
    78b0:	f9400a73 	ldr	x19, [x19, #16]
    78b4:	aa1803e0 	mov	x0, x24
    78b8:	91000718 	add	x24, x24, #0x1
    78bc:	b5ffffb3 	cbnz	x19, 78b0 <f12+0xd00>
    78c0:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    78c4:	eb01031f 	cmp	x24, x1
    78c8:	54001b88 	b.hi	7c38 <f12+0x1088>  // b.pmore
    78cc:	91000800 	add	x0, x0, #0x2
    78d0:	52800041 	mov	w1, #0x2                   	// #2
    78d4:	d37df000 	lsl	x0, x0, #3
    78d8:	97fff5ee 	bl	5090 <fwp_heap_alloc>
    78dc:	eb18039f 	cmp	x28, x24
    78e0:	aa0003f9 	mov	x25, x0
    78e4:	9a98939c 	csel	x28, x28, x24, ls	// ls = plast
    78e8:	aa1403e1 	mov	x1, x20
    78ec:	d503201f 	nop
    78f0:	f9400420 	ldr	x0, [x1, #8]
    78f4:	f8337b20 	str	x0, [x25, x19, lsl #3]
    78f8:	91000673 	add	x19, x19, #0x1
    78fc:	f9400821 	ldr	x1, [x1, #16]
    7900:	b5ffff81 	cbnz	x1, 78f0 <f12+0xd40>
    7904:	b4000ebc 	cbz	x28, 7ad8 <f12+0xf28>
    7908:	f94002a3 	ldr	x3, [x21]
    790c:	b9000bff 	str	wzr, [sp, #8]
    7910:	17ffff0f 	b	754c <f12+0x99c>
    7914:	72003c1f 	tst	w0, #0xffff
    7918:	54ffd260 	b.eq	7364 <f12+0x7b4>  // b.none
    791c:	d503201f 	nop
    7920:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7924:	eb00031f 	cmp	x24, x0
    7928:	540018e8 	b.hi	7c44 <f12+0x1094>  // b.pmore
    792c:	91000700 	add	x0, x24, #0x1
    7930:	52800021 	mov	w1, #0x1                   	// #1
    7934:	d37df000 	lsl	x0, x0, #3
    7938:	97fff5d6 	bl	5090 <fwp_heap_alloc>
    793c:	911902e2 	add	x2, x23, #0x640
    7940:	f9000018 	str	x24, [x0]
    7944:	aa0003f5 	mov	x21, x0
    7948:	f90003f5 	str	x21, [sp]
    794c:	f949d841 	ldr	x1, [x2, #5040]
    7950:	f949ec40 	ldr	x0, [x2, #5080]
    7954:	cb0102a1 	sub	x1, x21, x1
    7958:	eb00403f 	cmp	x1, x0, lsl #16
    795c:	54000322 	b.cs	79c0 <f12+0xe10>  // b.hs, b.nlast
    7960:	d350fc20 	lsr	x0, x1, #16
    7964:	f949fc43 	ldr	x3, [x2, #5112]
    7968:	8b000800 	add	x0, x0, x0, lsl #2
    796c:	d37df002 	lsl	x2, x0, #3
    7970:	8b020060 	add	x0, x3, x2
    7974:	f9401019 	ldr	x25, [x0, #32]
    7978:	b4000259 	cbz	x25, 79c0 <f12+0xe10>
    797c:	38626862 	ldrb	w2, [x3, x2]
    7980:	7100085f 	cmp	w2, #0x2
    7984:	54000ae0 	b.eq	7ae0 <f12+0xf30>  // b.none
    7988:	7100045f 	cmp	w2, #0x1
    798c:	540001a1 	b.ne	79c0 <f12+0xe10>  // b.any
    7990:	29430002 	ldp	w2, w0, [x0, #24]
    7994:	92403c21 	and	x1, x1, #0xffff
    7998:	9b027c21 	mul	x1, x1, x2
    799c:	d360fc21 	lsr	x1, x1, #32
    79a0:	eb00003f 	cmp	x1, x0
    79a4:	540000e2 	b.cs	79c0 <f12+0xe10>  // b.hs, b.nlast
    79a8:	8b010339 	add	x25, x25, x1
    79ac:	39400320 	ldrb	w0, [x25]
    79b0:	7103fc1f 	cmp	w0, #0xff
    79b4:	54001160 	b.eq	7be0 <f12+0x1030>  // b.none
    79b8:	52800020 	mov	w0, #0x1                   	// #1
    79bc:	39000320 	strb	w0, [x25]
    79c0:	aa1303e0 	mov	x0, x19
    79c4:	17fffe6e 	b	737c <f12+0x7cc>
    79c8:	52800041 	mov	w1, #0x2                   	// #2
    79cc:	d2800100 	mov	x0, #0x8                   	// #8
    79d0:	97fff5b0 	bl	5090 <fwp_heap_alloc>
    79d4:	aa0003fb 	mov	x27, x0
    79d8:	911902e0 	add	x0, x23, #0x640
    79dc:	f900037f 	str	xzr, [x27]
    79e0:	f949d801 	ldr	x1, [x0, #5040]
    79e4:	f949ec00 	ldr	x0, [x0, #5080]
    79e8:	cb010361 	sub	x1, x27, x1
    79ec:	eb00403f 	cmp	x1, x0, lsl #16
    79f0:	54000102 	b.cs	7a10 <f12+0xe60>  // b.hs, b.nlast
    79f4:	d2800013 	mov	x19, #0x0                   	// #0
    79f8:	17fffd41 	b	6efc <f12+0x34c>
    79fc:	aa1b03e0 	mov	x0, x27
    7a00:	97fff3e4 	bl	4990 <fwp_rc_forget_slot>
    7a04:	17ffff26 	b	769c <f12+0xaec>
    7a08:	b5ffaaf3 	cbnz	x19, 6f64 <f12+0x3b4>
    7a0c:	d503201f 	nop
    7a10:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7a14:	f900037f 	str	xzr, [x27]
    7a18:	17fffd87 	b	7034 <f12+0x484>
    7a1c:	f0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x100>
    7a20:	910b4000 	add	x0, x0, #0x2d0
    7a24:	94000edb 	bl	b590 <atexit>
    7a28:	35ffd200 	cbnz	w0, 7468 <f12+0x8b8>
    7a2c:	52800020 	mov	w0, #0x1                   	// #1
    7a30:	b903c720 	str	w0, [x25, #964]
    7a34:	17fffcaf 	b	6cf0 <f12+0x140>
    7a38:	72003c3f 	tst	w1, #0xffff
    7a3c:	54ffa921 	b.ne	6f60 <f12+0x3b0>  // b.any
    7a40:	17fffd43 	b	6f4c <f12+0x39c>
    7a44:	72003c3f 	tst	w1, #0xffff
    7a48:	54ff9240 	b.eq	6c90 <f12+0xe0>  // b.none
    7a4c:	aa1903e0 	mov	x0, x25
    7a50:	97fff980 	bl	6050 <fwp_closure_drop>
    7a54:	b5ff9374 	cbnz	x20, 6cc0 <f12+0x110>
    7a58:	d280001a 	mov	x26, #0x0                   	// #0
    7a5c:	17fffca2 	b	6ce4 <f12+0x134>
    7a60:	aa1c03f3 	mov	x19, x28
    7a64:	17fffda7 	b	7100 <f12+0x550>
    7a68:	72003c3f 	tst	w1, #0xffff
    7a6c:	54ffc361 	b.ne	72d8 <f12+0x728>  // b.any
    7a70:	17fffe15 	b	72c4 <f12+0x714>
    7a74:	ad470402 	ldp	q2, q1, [x0, #224]
    7a78:	91038001 	add	x1, x0, #0xe0
    7a7c:	4f000400 	movi	v0.4s, #0x0
    7a80:	f9008c1f 	str	xzr, [x0, #280]
    7a84:	ad010762 	stp	q2, q1, [x27, #32]
    7a88:	a9500002 	ldp	x2, x0, [x0, #256]
    7a8c:	f9000f60 	str	x0, [x27, #24]
    7a90:	f9401820 	ldr	x0, [x1, #48]
    7a94:	f9002362 	str	x2, [x27, #64]
    7a98:	f9002760 	str	x0, [x27, #72]
    7a9c:	ad000020 	stp	q0, q0, [x1]
    7aa0:	3d800820 	str	q0, [x1, #32]
    7aa4:	f900183f 	str	xzr, [x1, #48]
    7aa8:	17fffcd3 	b	6df4 <f12+0x244>
    7aac:	f940ac43 	ldr	x3, [x2, #344]
    7ab0:	91000463 	add	x3, x3, #0x1
    7ab4:	f900ac43 	str	x3, [x2, #344]
    7ab8:	17fffc7b 	b	6ca4 <f12+0xf4>
    7abc:	d2800005 	mov	x5, #0x0                   	// #0
    7ac0:	52800020 	mov	w0, #0x1                   	// #1
    7ac4:	17fffe61 	b	7448 <f12+0x898>
    7ac8:	52800041 	mov	w1, #0x2                   	// #2
    7acc:	d2800100 	mov	x0, #0x8                   	// #8
    7ad0:	97fff570 	bl	5090 <fwp_heap_alloc>
    7ad4:	aa0003f9 	mov	x25, x0
    7ad8:	d2800013 	mov	x19, #0x0                   	// #0
    7adc:	17ffff53 	b	7828 <f12+0xc78>
    7ae0:	72003c3f 	tst	w1, #0xffff
    7ae4:	54fff640 	b.eq	79ac <f12+0xdfc>  // b.none
    7ae8:	aa1303e0 	mov	x0, x19
    7aec:	17fffe24 	b	737c <f12+0x7cc>
    7af0:	d1000761 	sub	x1, x27, #0x1
    7af4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7af8:	eb00003f 	cmp	x1, x0
    7afc:	54000aa8 	b.hi	7c50 <f12+0x10a0>  // b.pmore
    7b00:	b00002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fba0>
    7b04:	d2800000 	mov	x0, #0x0                   	// #0
    7b08:	91118061 	add	x1, x3, #0x460
    7b0c:	14000005 	b	7b20 <f12+0xf70>
    7b10:	91000400 	add	x0, x0, #0x1
    7b14:	91006021 	add	x1, x1, #0x18
    7b18:	f140041f 	cmp	x0, #0x1, lsl #12
    7b1c:	540006c0 	b.eq	7bf4 <f12+0x1044>  // b.none
    7b20:	f9400022 	ldr	x2, [x1]
    7b24:	b5ffff62 	cbnz	x2, 7b10 <f12+0xf60>
    7b28:	8b000402 	add	x2, x0, x0, lsl #1
    7b2c:	91118063 	add	x3, x3, #0x460
    7b30:	aa1b03e0 	mov	x0, x27
    7b34:	d2800101 	mov	x1, #0x8                   	// #8
    7b38:	8b020c76 	add	x22, x3, x2, lsl #3
    7b3c:	a9009fe6 	stp	x6, x7, [sp, #8]
    7b40:	a901a7e8 	stp	x8, x9, [sp, #24]
    7b44:	97ffeb2b 	bl	27f0 <calloc@plt>
    7b48:	aa0003e5 	mov	x5, x0
    7b4c:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7b50:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7b54:	b4fffb40 	cbz	x0, 7abc <f12+0xf0c>
    7b58:	aa0503e1 	mov	x1, x5
    7b5c:	aa1603e0 	mov	x0, x22
    7b60:	d37df362 	lsl	x2, x27, #3
    7b64:	52800063 	mov	w3, #0x3                   	// #3
    7b68:	a9009be5 	stp	x5, x6, [sp, #8]
    7b6c:	a901a3e7 	stp	x7, x8, [sp, #24]
    7b70:	f90017e9 	str	x9, [sp, #40]
    7b74:	97ffece7 	bl	2f10 <ad_raw_record>
    7b78:	a9409be5 	ldp	x5, x6, [sp, #8]
    7b7c:	f9004be5 	str	x5, [sp, #144]
    7b80:	a941a3e7 	ldp	x7, x8, [sp, #24]
    7b84:	f90053fb 	str	x27, [sp, #160]
    7b88:	f94017e9 	ldr	x9, [sp, #40]
    7b8c:	17fffd75 	b	7160 <f12+0x5b0>
    7b90:	f94002a3 	ldr	x3, [x21]
    7b94:	b7fff9a3 	tbnz	x3, #63, 7ac8 <f12+0xf18>
    7b98:	911902e1 	add	x1, x23, #0x640
    7b9c:	f94003e4 	ldr	x4, [sp]
    7ba0:	f949d820 	ldr	x0, [x1, #5040]
    7ba4:	f949ec21 	ldr	x1, [x1, #5080]
    7ba8:	cb000080 	sub	x0, x4, x0
    7bac:	eb01401f 	cmp	x0, x1, lsl #16
    7bb0:	54fff8c2 	b.cs	7ac8 <f12+0xf18>  // b.hs, b.nlast
    7bb4:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7bb8:	17fffe49 	b	74dc <f12+0x92c>
    7bbc:	d2800d01 	mov	x1, #0x68                  	// #104
    7bc0:	d2800036 	mov	x22, #0x1                   	// #1
    7bc4:	17fffc6e 	b	6d7c <f12+0x1cc>
    7bc8:	aa1a03e0 	mov	x0, x26
    7bcc:	97fff371 	bl	4990 <fwp_rc_forget_slot>
    7bd0:	17fffce2 	b	6f58 <f12+0x3a8>
    7bd4:	aa1903e0 	mov	x0, x25
    7bd8:	97fff36e 	bl	4990 <fwp_rc_forget_slot>
    7bdc:	17fffdbd 	b	72d0 <f12+0x720>
    7be0:	aa1903e0 	mov	x0, x25
    7be4:	97fff36b 	bl	4990 <fwp_rc_forget_slot>
    7be8:	17ffff74 	b	79b8 <f12+0xe08>
    7bec:	97fff322 	bl	4874 <fwp_rc_wide_dup>
    7bf0:	17fffc31 	b	6cb4 <f12+0x104>
    7bf4:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7bf8:	9125a000 	add	x0, x0, #0x968
    7bfc:	97ffedc1 	bl	3300 <ad_raw_fail>
    7c00:	d280001a 	mov	x26, #0x0                   	// #0
    7c04:	17fffe95 	b	7658 <f12+0xaa8>
    7c08:	d2800019 	mov	x25, #0x0                   	// #0
    7c0c:	d2800013 	mov	x19, #0x0                   	// #0
    7c10:	17ffff06 	b	7828 <f12+0xc78>
    7c14:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c18:	912b2000 	add	x0, x0, #0xac8
    7c1c:	97ffeed9 	bl	3780 <fwp_trap>
    7c20:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c24:	912d8000 	add	x0, x0, #0xb60
    7c28:	97ffeed6 	bl	3780 <fwp_trap>
    7c2c:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c30:	91320000 	add	x0, x0, #0xc80
    7c34:	97ffeed3 	bl	3780 <fwp_trap>
    7c38:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c3c:	91310000 	add	x0, x0, #0xc40
    7c40:	97ffeed0 	bl	3780 <fwp_trap>
    7c44:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c48:	9131c000 	add	x0, x0, #0xc70
    7c4c:	97ffeecd 	bl	3780 <fwp_trap>
    7c50:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c54:	91314000 	add	x0, x0, #0xc50
    7c58:	97ffedaa 	bl	3300 <ad_raw_fail>
    7c5c:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c60:	91304000 	add	x0, x0, #0xc10
    7c64:	97ffeec7 	bl	3780 <fwp_trap>
    7c68:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c6c:	912f0000 	add	x0, x0, #0xbc0
    7c70:	97ffeec4 	bl	3780 <fwp_trap>
    7c74:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c78:	912c4000 	add	x0, x0, #0xb10
    7c7c:	97ffeec1 	bl	3780 <fwp_trap>
    7c80:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7c84:	912f8000 	add	x0, x0, #0xbe0
    7c88:	97ffeebe 	bl	3780 <fwp_trap>
    7c8c:	97ffeae1 	bl	2810 <__stack_chk_fail@plt>
    7c90:	97ffeaf4 	bl	2860 <abort@plt>
    7c94:	97ffeb5b 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7c98:	d503201f 	nop
    7c9c:	d503201f 	nop

0000000000007ca0 <fwp_owned_entry12>:
    7ca0:	f9400000 	ldr	x0, [x0]
    7ca4:	17fffbc3 	b	6bb0 <f12>
    7ca8:	d503201f 	nop
    7cac:	d503201f 	nop

0000000000007cb0 <e12>:
    7cb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7cb4:	910003fd 	mov	x29, sp
    7cb8:	f9000bf3 	str	x19, [sp, #16]
    7cbc:	f9400013 	ldr	x19, [x0]
    7cc0:	aa1303e0 	mov	x0, x19
    7cc4:	97fff730 	bl	5984 <fwp_rc_share>
    7cc8:	aa1303e0 	mov	x0, x19
    7ccc:	97fffbb9 	bl	6bb0 <f12>
    7cd0:	aa0003f3 	mov	x19, x0
    7cd4:	97fff72c 	bl	5984 <fwp_rc_share>
    7cd8:	aa1303e0 	mov	x0, x19
    7cdc:	f9400bf3 	ldr	x19, [sp, #16]
    7ce0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ce4:	d65f03c0 	ret
    7ce8:	d503201f 	nop
    7cec:	d503201f 	nop

0000000000007cf0 <fwp_drop2>:
    7cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7cf4:	910003fd 	mov	x29, sp
    7cf8:	a9025bf5 	stp	x21, x22, [sp, #32]
    7cfc:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    7d00:	911902d5 	add	x21, x22, #0x640
    7d04:	a90153f3 	stp	x19, x20, [sp, #16]
    7d08:	aa0003f3 	mov	x19, x0
    7d0c:	f949daa1 	ldr	x1, [x21, #5040]
    7d10:	f949eea0 	ldr	x0, [x21, #5080]
    7d14:	cb010261 	sub	x1, x19, x1
    7d18:	eb00403f 	cmp	x1, x0, lsl #16
    7d1c:	54000382 	b.cs	7d8c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7d20:	d350fc22 	lsr	x2, x1, #16
    7d24:	f949fea3 	ldr	x3, [x21, #5112]
    7d28:	8b020842 	add	x2, x2, x2, lsl #2
    7d2c:	d37df042 	lsl	x2, x2, #3
    7d30:	8b020060 	add	x0, x3, x2
    7d34:	f9401014 	ldr	x20, [x0, #32]
    7d38:	b40002b4 	cbz	x20, 7d8c <fwp_drop2+0x9c>
    7d3c:	38626862 	ldrb	w2, [x3, x2]
    7d40:	7100085f 	cmp	w2, #0x2
    7d44:	540002c0 	b.eq	7d9c <fwp_drop2+0xac>  // b.none
    7d48:	7100045f 	cmp	w2, #0x1
    7d4c:	54000201 	b.ne	7d8c <fwp_drop2+0x9c>  // b.any
    7d50:	29430002 	ldp	w2, w0, [x0, #24]
    7d54:	92403c21 	and	x1, x1, #0xffff
    7d58:	9b027c21 	mul	x1, x1, x2
    7d5c:	d360fc21 	lsr	x1, x1, #32
    7d60:	eb00003f 	cmp	x1, x0
    7d64:	54000142 	b.cs	7d8c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7d68:	8b010294 	add	x20, x20, x1
    7d6c:	39400280 	ldrb	w0, [x20]
    7d70:	340000e0 	cbz	w0, 7d8c <fwp_drop2+0x9c>
    7d74:	7100041f 	cmp	w0, #0x1
    7d78:	540001e0 	b.eq	7db4 <fwp_drop2+0xc4>  // b.none
    7d7c:	7103fc1f 	cmp	w0, #0xff
    7d80:	540007c0 	b.eq	7e78 <fwp_drop2+0x188>  // b.none
    7d84:	51000400 	sub	w0, w0, #0x1
    7d88:	39000280 	strb	w0, [x20]
    7d8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d90:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7d98:	d65f03c0 	ret
    7d9c:	72003c3f 	tst	w1, #0xffff
    7da0:	54fffe60 	b.eq	7d6c <fwp_drop2+0x7c>  // b.none
    7da4:	a94153f3 	ldp	x19, x20, [sp, #16]
    7da8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7dac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7db0:	d65f03c0 	ret
    7db4:	911902c2 	add	x2, x22, #0x640
    7db8:	f9400660 	ldr	x0, [x19, #8]
    7dbc:	f949d841 	ldr	x1, [x2, #5040]
    7dc0:	f949ec42 	ldr	x2, [x2, #5080]
    7dc4:	cb010001 	sub	x1, x0, x1
    7dc8:	eb02403f 	cmp	x1, x2, lsl #16
    7dcc:	54000362 	b.cs	7e38 <fwp_drop2+0x148>  // b.hs, b.nlast
    7dd0:	d350fc22 	lsr	x2, x1, #16
    7dd4:	8b020842 	add	x2, x2, x2, lsl #2
    7dd8:	d37df042 	lsl	x2, x2, #3
    7ddc:	8b020064 	add	x4, x3, x2
    7de0:	f9401094 	ldr	x20, [x4, #32]
    7de4:	b40002b4 	cbz	x20, 7e38 <fwp_drop2+0x148>
    7de8:	38626862 	ldrb	w2, [x3, x2]
    7dec:	7100085f 	cmp	w2, #0x2
    7df0:	540003e0 	b.eq	7e6c <fwp_drop2+0x17c>  // b.none
    7df4:	7100045f 	cmp	w2, #0x1
    7df8:	54000201 	b.ne	7e38 <fwp_drop2+0x148>  // b.any
    7dfc:	29430883 	ldp	w3, w2, [x4, #24]
    7e00:	92403c21 	and	x1, x1, #0xffff
    7e04:	9b037c21 	mul	x1, x1, x3
    7e08:	d360fc21 	lsr	x1, x1, #32
    7e0c:	eb02003f 	cmp	x1, x2
    7e10:	54000142 	b.cs	7e38 <fwp_drop2+0x148>  // b.hs, b.nlast
    7e14:	8b010294 	add	x20, x20, x1
    7e18:	39400281 	ldrb	w1, [x20]
    7e1c:	340000e1 	cbz	w1, 7e38 <fwp_drop2+0x148>
    7e20:	7100043f 	cmp	w1, #0x1
    7e24:	54000200 	b.eq	7e64 <fwp_drop2+0x174>  // b.none
    7e28:	7103fc3f 	cmp	w1, #0xff
    7e2c:	54000580 	b.eq	7edc <fwp_drop2+0x1ec>  // b.none
    7e30:	51000421 	sub	w1, w1, #0x1
    7e34:	39000281 	strb	w1, [x20]
    7e38:	f9400a74 	ldr	x20, [x19, #16]
    7e3c:	aa1303e0 	mov	x0, x19
    7e40:	97fff6f8 	bl	5a20 <fwp_rc_free_arr>
    7e44:	911902c0 	add	x0, x22, #0x640
    7e48:	f949d801 	ldr	x1, [x0, #5040]
    7e4c:	f949ec00 	ldr	x0, [x0, #5080]
    7e50:	cb010281 	sub	x1, x20, x1
    7e54:	eb00403f 	cmp	x1, x0, lsl #16
    7e58:	54fff9a2 	b.cs	7d8c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e5c:	aa1403f3 	mov	x19, x20
    7e60:	17ffffb0 	b	7d20 <fwp_drop2+0x30>
    7e64:	97fff6ef 	bl	5a20 <fwp_rc_free_arr>
    7e68:	17fffff4 	b	7e38 <fwp_drop2+0x148>
    7e6c:	72003c3f 	tst	w1, #0xffff
    7e70:	54fffe41 	b.ne	7e38 <fwp_drop2+0x148>  // b.any
    7e74:	17ffffe9 	b	7e18 <fwp_drop2+0x128>
    7e78:	ca544681 	eor	x1, x20, x20, lsr #17
    7e7c:	911902c0 	add	x0, x22, #0x640
    7e80:	ca412421 	eor	x1, x1, x1, lsr #9
    7e84:	8b210c01 	add	x1, x0, w1, uxtb #3
    7e88:	f94a2420 	ldr	x0, [x1, #5192]
    7e8c:	b5000080 	cbnz	x0, 7e9c <fwp_drop2+0x1ac>
    7e90:	14000010 	b	7ed0 <fwp_drop2+0x1e0>
    7e94:	f9400800 	ldr	x0, [x0, #16]
    7e98:	b40001c0 	cbz	x0, 7ed0 <fwp_drop2+0x1e0>
    7e9c:	f9400001 	ldr	x1, [x0]
    7ea0:	eb14003f 	cmp	x1, x20
    7ea4:	54ffff81 	b.ne	7e94 <fwp_drop2+0x1a4>  // b.any
    7ea8:	f9400401 	ldr	x1, [x0, #8]
    7eac:	d1000421 	sub	x1, x1, #0x1
    7eb0:	f9000401 	str	x1, [x0, #8]
    7eb4:	f103f83f 	cmp	x1, #0xfe
    7eb8:	54fff6a1 	b.ne	7d8c <fwp_drop2+0x9c>  // b.any
    7ebc:	aa1403e0 	mov	x0, x20
    7ec0:	97fff2b4 	bl	4990 <fwp_rc_forget_slot>
    7ec4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7ec8:	39000280 	strb	w0, [x20]
    7ecc:	17ffffb0 	b	7d8c <fwp_drop2+0x9c>
    7ed0:	90000020 	adrp	x0, b000 <__divti3+0x160>
    7ed4:	912a0000 	add	x0, x0, #0xa80
    7ed8:	97ffee2a 	bl	3780 <fwp_trap>
    7edc:	ca544680 	eor	x0, x20, x20, lsr #17
    7ee0:	911902c1 	add	x1, x22, #0x640
    7ee4:	ca402400 	eor	x0, x0, x0, lsr #9
    7ee8:	8b200c20 	add	x0, x1, w0, uxtb #3
    7eec:	f94a2400 	ldr	x0, [x0, #5192]
    7ef0:	b5000080 	cbnz	x0, 7f00 <fwp_drop2+0x210>
    7ef4:	17fffff7 	b	7ed0 <fwp_drop2+0x1e0>
    7ef8:	f9400800 	ldr	x0, [x0, #16]
    7efc:	b4fffea0 	cbz	x0, 7ed0 <fwp_drop2+0x1e0>
    7f00:	f9400001 	ldr	x1, [x0]
    7f04:	eb14003f 	cmp	x1, x20
    7f08:	54ffff81 	b.ne	7ef8 <fwp_drop2+0x208>  // b.any
    7f0c:	f9400401 	ldr	x1, [x0, #8]
    7f10:	d1000421 	sub	x1, x1, #0x1
    7f14:	f9000401 	str	x1, [x0, #8]
    7f18:	f103f83f 	cmp	x1, #0xfe
    7f1c:	54fff8e1 	b.ne	7e38 <fwp_drop2+0x148>  // b.any
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	97fff29b 	bl	4990 <fwp_rc_forget_slot>
    7f28:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7f2c:	39000280 	strb	w0, [x20]
    7f30:	17ffffc2 	b	7e38 <fwp_drop2+0x148>

0000000000007f34 <fwp_arg_drop23>:
    7f34:	7100003f 	cmp	w1, #0x0
    7f38:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7f3c:	54000041 	b.ne	7f44 <fwp_arg_drop23+0x10>  // b.any
    7f40:	d65f03c0 	ret
    7f44:	f9400000 	ldr	x0, [x0]
    7f48:	17ffff6a 	b	7cf0 <fwp_drop2>
    7f4c:	d503201f 	nop

0000000000007f50 <f23>:
    7f50:	d10203ff 	sub	sp, sp, #0x80
    7f54:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    7f58:	f947f421 	ldr	x1, [x1, #4072]
    7f5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7f60:	910083fd 	add	x29, sp, #0x20
    7f64:	a9045bf5 	stp	x21, x22, [sp, #64]
    7f68:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    7f6c:	911902c3 	add	x3, x22, #0x640
    7f70:	a90353f3 	stp	x19, x20, [sp, #48]
    7f74:	a90563f7 	stp	x23, x24, [sp, #80]
    7f78:	aa0003f8 	mov	x24, x0
    7f7c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7f80:	f949ec62 	ldr	x2, [x3, #5080]
    7f84:	f9400024 	ldr	x4, [x1]
    7f88:	f9000fe4 	str	x4, [sp, #24]
    7f8c:	d2800004 	mov	x4, #0x0                   	// #0
    7f90:	f949d861 	ldr	x1, [x3, #5040]
    7f94:	d370bc42 	lsl	x2, x2, #16
    7f98:	b40018e0 	cbz	x0, 82b4 <f23+0x364>
    7f9c:	f9400819 	ldr	x25, [x0, #16]
    7fa0:	cb010321 	sub	x1, x25, x1
    7fa4:	eb02003f 	cmp	x1, x2
    7fa8:	540003e2 	b.cs	8024 <f23+0xd4>  // b.hs, b.nlast
    7fac:	f949fc60 	ldr	x0, [x3, #5112]
    7fb0:	d350fc22 	lsr	x2, x1, #16
    7fb4:	8b020842 	add	x2, x2, x2, lsl #2
    7fb8:	8b020c02 	add	x2, x0, x2, lsl #3
    7fbc:	f9401040 	ldr	x0, [x2, #32]
    7fc0:	b4000320 	cbz	x0, 8024 <f23+0xd4>
    7fc4:	39400043 	ldrb	w3, [x2]
    7fc8:	7100087f 	cmp	w3, #0x2
    7fcc:	54001660 	b.eq	8298 <f23+0x348>  // b.none
    7fd0:	7100047f 	cmp	w3, #0x1
    7fd4:	54000241 	b.ne	801c <f23+0xcc>  // b.any
    7fd8:	29430843 	ldp	w3, w2, [x2, #24]
    7fdc:	92403c21 	and	x1, x1, #0xffff
    7fe0:	9b037c21 	mul	x1, x1, x3
    7fe4:	d360fc21 	lsr	x1, x1, #32
    7fe8:	eb02003f 	cmp	x1, x2
    7fec:	54000182 	b.cs	801c <f23+0xcc>  // b.hs, b.nlast
    7ff0:	8b010000 	add	x0, x0, x1
    7ff4:	39400001 	ldrb	w1, [x0]
    7ff8:	34000121 	cbz	w1, 801c <f23+0xcc>
    7ffc:	b00000c2 	adrp	x2, 20000 <__data_start>
    8000:	91018042 	add	x2, x2, #0x60
    8004:	b9413043 	ldr	w3, [x2, #304]
    8008:	350014e3 	cbnz	w3, 82a4 <f23+0x354>
    800c:	7103f43f 	cmp	w1, #0xfd
    8010:	54001908 	b.hi	8330 <f23+0x3e0>  // b.pmore
    8014:	11000421 	add	w1, w1, #0x1
    8018:	39000001 	strb	w1, [x0]
    801c:	d2800000 	mov	x0, #0x0                   	// #0
    8020:	b40000f8 	cbz	x24, 803c <f23+0xec>
    8024:	aa1803e1 	mov	x1, x24
    8028:	d2800000 	mov	x0, #0x0                   	// #0
    802c:	d503201f 	nop
    8030:	f9400821 	ldr	x1, [x1, #16]
    8034:	91000400 	add	x0, x0, #0x1
    8038:	b5ffffc1 	cbnz	x1, 8030 <f23+0xe0>
    803c:	b4001439 	cbz	x25, 82c0 <f23+0x370>
    8040:	aa1903e1 	mov	x1, x25
    8044:	d2800002 	mov	x2, #0x0                   	// #0
    8048:	f9400821 	ldr	x1, [x1, #16]
    804c:	91000442 	add	x2, x2, #0x1
    8050:	b5ffffc1 	cbnz	x1, 8048 <f23+0xf8>
    8054:	eb00005f 	cmp	x2, x0
    8058:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    805c:	9a80905a 	csel	x26, x2, x0, ls	// ls = plast
    8060:	eb01035f 	cmp	x26, x1
    8064:	540016e8 	b.hi	8340 <f23+0x3f0>  // b.pmore
    8068:	d37ffb53 	lsl	x19, x26, #1
    806c:	52800041 	mov	w1, #0x2                   	// #2
    8070:	91000660 	add	x0, x19, #0x1
    8074:	d37df000 	lsl	x0, x0, #3
    8078:	97fff406 	bl	5090 <fwp_heap_alloc>
    807c:	aa0003f7 	mov	x23, x0
    8080:	911902c1 	add	x1, x22, #0x640
    8084:	aa0103e0 	mov	x0, x1
    8088:	f90002f3 	str	x19, [x23]
    808c:	f949d821 	ldr	x1, [x1, #5040]
    8090:	f949ec00 	ldr	x0, [x0, #5080]
    8094:	cb0102e1 	sub	x1, x23, x1
    8098:	eb00403f 	cmp	x1, x0, lsl #16
    809c:	54000342 	b.cs	8104 <f23+0x1b4>  // b.hs, b.nlast
    80a0:	911902c2 	add	x2, x22, #0x640
    80a4:	d350fc20 	lsr	x0, x1, #16
    80a8:	8b000800 	add	x0, x0, x0, lsl #2
    80ac:	f949fc43 	ldr	x3, [x2, #5112]
    80b0:	d37df002 	lsl	x2, x0, #3
    80b4:	8b020060 	add	x0, x3, x2
    80b8:	f9401013 	ldr	x19, [x0, #32]
    80bc:	b4000253 	cbz	x19, 8104 <f23+0x1b4>
    80c0:	38626862 	ldrb	w2, [x3, x2]
    80c4:	7100085f 	cmp	w2, #0x2
    80c8:	54000e20 	b.eq	828c <f23+0x33c>  // b.none
    80cc:	7100045f 	cmp	w2, #0x1
    80d0:	540001a1 	b.ne	8104 <f23+0x1b4>  // b.any
    80d4:	29430002 	ldp	w2, w0, [x0, #24]
    80d8:	92403c21 	and	x1, x1, #0xffff
    80dc:	9b027c21 	mul	x1, x1, x2
    80e0:	d360fc21 	lsr	x1, x1, #32
    80e4:	eb00003f 	cmp	x1, x0
    80e8:	540000e2 	b.cs	8104 <f23+0x1b4>  // b.hs, b.nlast
    80ec:	8b010273 	add	x19, x19, x1
    80f0:	39400260 	ldrb	w0, [x19]
    80f4:	7103fc1f 	cmp	w0, #0xff
    80f8:	54001060 	b.eq	8304 <f23+0x3b4>  // b.none
    80fc:	52800020 	mov	w0, #0x1                   	// #1
    8100:	39000260 	strb	w0, [x19]
    8104:	b400025a 	cbz	x26, 814c <f23+0x1fc>
    8108:	8b1a12fa 	add	x26, x23, x26, lsl #4
    810c:	aa1703f3 	mov	x19, x23
    8110:	aa1803f5 	mov	x21, x24
    8114:	aa1903f4 	mov	x20, x25
    8118:	f9400683 	ldr	x3, [x20, #8]
    811c:	f94006a2 	ldr	x2, [x21, #8]
    8120:	f9400861 	ldr	x1, [x3, #16]
    8124:	f9400840 	ldr	x0, [x2, #16]
    8128:	fd400461 	ldr	d1, [x3, #8]
    812c:	fd400440 	ldr	d0, [x2, #8]
    8130:	97fff574 	bl	5700 <w107>
    8134:	f9000660 	str	x0, [x19, #8]
    8138:	f8010e61 	str	x1, [x19, #16]!
    813c:	f9400a94 	ldr	x20, [x20, #16]
    8140:	f9400ab5 	ldr	x21, [x21, #16]
    8144:	eb13035f 	cmp	x26, x19
    8148:	54fffe81 	b.ne	8118 <f23+0x1c8>  // b.any
    814c:	aa1903e0 	mov	x0, x25
    8150:	97fffee8 	bl	7cf0 <fwp_drop2>
    8154:	aa1803e0 	mov	x0, x24
    8158:	97fffee6 	bl	7cf0 <fwp_drop2>
    815c:	f94002f5 	ldr	x21, [x23]
    8160:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8164:	b4000275 	cbz	x21, 81b0 <f23+0x260>
    8168:	fd003be8 	str	d8, [sp, #112]
    816c:	2f00e408 	movi	d8, #0x0
    8170:	910022f9 	add	x25, x23, #0x8
    8174:	910042f8 	add	x24, x23, #0x10
    8178:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    817c:	d2800013 	mov	x19, #0x0                   	// #0
    8180:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8184:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8188:	f8737b02 	ldr	x2, [x24, x19, lsl #3]
    818c:	aa0303e1 	mov	x1, x3
    8190:	1e602908 	fadd	d8, d8, d0
    8194:	91000a73 	add	x19, x19, #0x2
    8198:	97fff4a7 	bl	5434 <fwp_p_ad_push>
    819c:	aa0003f4 	mov	x20, x0
    81a0:	eb1302bf 	cmp	x21, x19
    81a4:	54fffee8 	b.hi	8180 <f23+0x230>  // b.pmore
    81a8:	9e660115 	fmov	x21, d8
    81ac:	fd403be8 	ldr	d8, [sp, #112]
    81b0:	911902d6 	add	x22, x22, #0x640
    81b4:	aa1703e0 	mov	x0, x23
    81b8:	97fff9de 	bl	6930 <fwp_drop4>
    81bc:	a900d3f5 	stp	x21, x20, [sp, #8]
    81c0:	910023e1 	add	x1, sp, #0x8
    81c4:	52800000 	mov	w0, #0x0                   	// #0
    81c8:	97fff592 	bl	5810 <fwp_data.part.0.constprop.0>
    81cc:	f949dac1 	ldr	x1, [x22, #5040]
    81d0:	aa0003f3 	mov	x19, x0
    81d4:	f949eec0 	ldr	x0, [x22, #5080]
    81d8:	cb010261 	sub	x1, x19, x1
    81dc:	eb00403f 	cmp	x1, x0, lsl #16
    81e0:	54000322 	b.cs	8244 <f23+0x2f4>  // b.hs, b.nlast
    81e4:	d350fc22 	lsr	x2, x1, #16
    81e8:	f949fec3 	ldr	x3, [x22, #5112]
    81ec:	8b020842 	add	x2, x2, x2, lsl #2
    81f0:	d37df042 	lsl	x2, x2, #3
    81f4:	8b020060 	add	x0, x3, x2
    81f8:	f9401014 	ldr	x20, [x0, #32]
    81fc:	b4000254 	cbz	x20, 8244 <f23+0x2f4>
    8200:	38626862 	ldrb	w2, [x3, x2]
    8204:	7100085f 	cmp	w2, #0x2
    8208:	540003c0 	b.eq	8280 <f23+0x330>  // b.none
    820c:	7100045f 	cmp	w2, #0x1
    8210:	540001a1 	b.ne	8244 <f23+0x2f4>  // b.any
    8214:	29430002 	ldp	w2, w0, [x0, #24]
    8218:	92403c21 	and	x1, x1, #0xffff
    821c:	9b027c21 	mul	x1, x1, x2
    8220:	d360fc21 	lsr	x1, x1, #32
    8224:	eb00003f 	cmp	x1, x0
    8228:	540000e2 	b.cs	8244 <f23+0x2f4>  // b.hs, b.nlast
    822c:	8b010294 	add	x20, x20, x1
    8230:	39400280 	ldrb	w0, [x20]
    8234:	7103fc1f 	cmp	w0, #0xff
    8238:	54000600 	b.eq	82f8 <f23+0x3a8>  // b.none
    823c:	52800020 	mov	w0, #0x1                   	// #1
    8240:	39000280 	strb	w0, [x20]
    8244:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8248:	f947f400 	ldr	x0, [x0, #4072]
    824c:	f9400fe2 	ldr	x2, [sp, #24]
    8250:	f9400001 	ldr	x1, [x0]
    8254:	eb010042 	subs	x2, x2, x1
    8258:	d2800001 	mov	x1, #0x0                   	// #0
    825c:	540007a1 	b.ne	8350 <f23+0x400>  // b.any
    8260:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8264:	aa1303e0 	mov	x0, x19
    8268:	a94353f3 	ldp	x19, x20, [sp, #48]
    826c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8270:	a94563f7 	ldp	x23, x24, [sp, #80]
    8274:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8278:	910203ff 	add	sp, sp, #0x80
    827c:	d65f03c0 	ret
    8280:	72003c3f 	tst	w1, #0xffff
    8284:	54fffe01 	b.ne	8244 <f23+0x2f4>  // b.any
    8288:	17ffffea 	b	8230 <f23+0x2e0>
    828c:	72003c3f 	tst	w1, #0xffff
    8290:	54fff3a1 	b.ne	8104 <f23+0x1b4>  // b.any
    8294:	17ffff97 	b	80f0 <f23+0x1a0>
    8298:	72003c3f 	tst	w1, #0xffff
    829c:	54ffec01 	b.ne	801c <f23+0xcc>  // b.any
    82a0:	17ffff55 	b	7ff4 <f23+0xa4>
    82a4:	f940ac43 	ldr	x3, [x2, #344]
    82a8:	91000463 	add	x3, x3, #0x1
    82ac:	f900ac43 	str	x3, [x2, #344]
    82b0:	17ffff57 	b	800c <f23+0xbc>
    82b4:	cb0103e1 	neg	x1, x1
    82b8:	eb02003f 	cmp	x1, x2
    82bc:	540002a3 	b.cc	8310 <f23+0x3c0>  // b.lo, b.ul, b.last
    82c0:	52800041 	mov	w1, #0x2                   	// #2
    82c4:	d2800100 	mov	x0, #0x8                   	// #8
    82c8:	97fff372 	bl	5090 <fwp_heap_alloc>
    82cc:	aa0003f7 	mov	x23, x0
    82d0:	911902c0 	add	x0, x22, #0x640
    82d4:	f90002ff 	str	xzr, [x23]
    82d8:	f949d801 	ldr	x1, [x0, #5040]
    82dc:	f949ec00 	ldr	x0, [x0, #5080]
    82e0:	cb0102e1 	sub	x1, x23, x1
    82e4:	eb00403f 	cmp	x1, x0, lsl #16
    82e8:	54000282 	b.cs	8338 <f23+0x3e8>  // b.hs, b.nlast
    82ec:	d280001a 	mov	x26, #0x0                   	// #0
    82f0:	d2800019 	mov	x25, #0x0                   	// #0
    82f4:	17ffff6b 	b	80a0 <f23+0x150>
    82f8:	aa1403e0 	mov	x0, x20
    82fc:	97fff1a5 	bl	4990 <fwp_rc_forget_slot>
    8300:	17ffffcf 	b	823c <f23+0x2ec>
    8304:	aa1303e0 	mov	x0, x19
    8308:	97fff1a2 	bl	4990 <fwp_rc_forget_slot>
    830c:	17ffff7c 	b	80fc <f23+0x1ac>
    8310:	f949fc62 	ldr	x2, [x3, #5112]
    8314:	d350fc20 	lsr	x0, x1, #16
    8318:	8b000800 	add	x0, x0, x0, lsl #2
    831c:	8b000c42 	add	x2, x2, x0, lsl #3
    8320:	f9401040 	ldr	x0, [x2, #32]
    8324:	b4fffce0 	cbz	x0, 82c0 <f23+0x370>
    8328:	d2800019 	mov	x25, #0x0                   	// #0
    832c:	17ffff26 	b	7fc4 <f23+0x74>
    8330:	97fff151 	bl	4874 <fwp_rc_wide_dup>
    8334:	17ffff3a 	b	801c <f23+0xcc>
    8338:	d2800019 	mov	x25, #0x0                   	// #0
    833c:	17ffff84 	b	814c <f23+0x1fc>
    8340:	f0000000 	adrp	x0, b000 <__divti3+0x160>
    8344:	91310000 	add	x0, x0, #0xc40
    8348:	fd003be8 	str	d8, [sp, #112]
    834c:	97ffed0d 	bl	3780 <fwp_trap>
    8350:	fd003be8 	str	d8, [sp, #112]
    8354:	97ffe92f 	bl	2810 <__stack_chk_fail@plt>
    8358:	d503201f 	nop
    835c:	d503201f 	nop

0000000000008360 <fwp_owned_entry23>:
    8360:	f9400000 	ldr	x0, [x0]
    8364:	17fffefb 	b	7f50 <f23>
    8368:	d503201f 	nop
    836c:	d503201f 	nop

0000000000008370 <e23>:
    8370:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8374:	910003fd 	mov	x29, sp
    8378:	f9000bf3 	str	x19, [sp, #16]
    837c:	f9400013 	ldr	x19, [x0]
    8380:	aa1303e0 	mov	x0, x19
    8384:	97fff580 	bl	5984 <fwp_rc_share>
    8388:	aa1303e0 	mov	x0, x19
    838c:	97fffef1 	bl	7f50 <f23>
    8390:	aa0003f3 	mov	x19, x0
    8394:	97fff57c 	bl	5984 <fwp_rc_share>
    8398:	aa1303e0 	mov	x0, x19
    839c:	f9400bf3 	ldr	x19, [sp, #16]
    83a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83a4:	d65f03c0 	ret
    83a8:	d503201f 	nop
    83ac:	d503201f 	nop

00000000000083b0 <fwp_args12>:
    83b0:	7100003f 	cmp	w1, #0x0
    83b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    83b8:	54000041 	b.ne	83c0 <fwp_args12+0x10>  // b.any
    83bc:	d65f03c0 	ret
    83c0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    83c4:	91190042 	add	x2, x2, #0x640
    83c8:	f9400001 	ldr	x1, [x0]
    83cc:	f949d843 	ldr	x3, [x2, #5040]
    83d0:	f949ec40 	ldr	x0, [x2, #5080]
    83d4:	cb030021 	sub	x1, x1, x3
    83d8:	eb00403f 	cmp	x1, x0, lsl #16
    83dc:	54ffff02 	b.cs	83bc <fwp_args12+0xc>  // b.hs, b.nlast
    83e0:	d350fc20 	lsr	x0, x1, #16
    83e4:	f949fc44 	ldr	x4, [x2, #5112]
    83e8:	8b000800 	add	x0, x0, x0, lsl #2
    83ec:	d37df002 	lsl	x2, x0, #3
    83f0:	8b020083 	add	x3, x4, x2
    83f4:	f9401060 	ldr	x0, [x3, #32]
    83f8:	b4fffe20 	cbz	x0, 83bc <fwp_args12+0xc>
    83fc:	38626882 	ldrb	w2, [x4, x2]
    8400:	7100085f 	cmp	w2, #0x2
    8404:	54000320 	b.eq	8468 <fwp_args12+0xb8>  // b.none
    8408:	7100045f 	cmp	w2, #0x1
    840c:	54fffd81 	b.ne	83bc <fwp_args12+0xc>  // b.any
    8410:	29430864 	ldp	w4, w2, [x3, #24]
    8414:	92403c21 	and	x1, x1, #0xffff
    8418:	9b047c21 	mul	x1, x1, x4
    841c:	d360fc21 	lsr	x1, x1, #32
    8420:	eb02003f 	cmp	x1, x2
    8424:	54fffcc2 	b.cs	83bc <fwp_args12+0xc>  // b.hs, b.nlast
    8428:	8b010000 	add	x0, x0, x1
    842c:	39400001 	ldrb	w1, [x0]
    8430:	34fffc61 	cbz	w1, 83bc <fwp_args12+0xc>
    8434:	900000c2 	adrp	x2, 20000 <__data_start>
    8438:	91018042 	add	x2, x2, #0x60
    843c:	b9413043 	ldr	w3, [x2, #304]
    8440:	350000c3 	cbnz	w3, 8458 <fwp_args12+0xa8>
    8444:	7103f43f 	cmp	w1, #0xfd
    8448:	54000168 	b.hi	8474 <fwp_args12+0xc4>  // b.pmore
    844c:	11000421 	add	w1, w1, #0x1
    8450:	39000001 	strb	w1, [x0]
    8454:	d65f03c0 	ret
    8458:	f940ac43 	ldr	x3, [x2, #344]
    845c:	91000463 	add	x3, x3, #0x1
    8460:	f900ac43 	str	x3, [x2, #344]
    8464:	17fffff8 	b	8444 <fwp_args12+0x94>
    8468:	72003c3f 	tst	w1, #0xffff
    846c:	54fffe00 	b.eq	842c <fwp_args12+0x7c>  // b.none
    8470:	d65f03c0 	ret
    8474:	17fff100 	b	4874 <fwp_rc_wide_dup>
    8478:	d503201f 	nop
    847c:	d503201f 	nop

0000000000008480 <fwp_args23>:
    8480:	7100003f 	cmp	w1, #0x0
    8484:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8488:	54000041 	b.ne	8490 <fwp_args23+0x10>  // b.any
    848c:	d65f03c0 	ret
    8490:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8494:	91190042 	add	x2, x2, #0x640
    8498:	f9400001 	ldr	x1, [x0]
    849c:	f949d843 	ldr	x3, [x2, #5040]
    84a0:	f949ec40 	ldr	x0, [x2, #5080]
    84a4:	cb030021 	sub	x1, x1, x3
    84a8:	eb00403f 	cmp	x1, x0, lsl #16
    84ac:	54ffff02 	b.cs	848c <fwp_args23+0xc>  // b.hs, b.nlast
    84b0:	d350fc20 	lsr	x0, x1, #16
    84b4:	f949fc44 	ldr	x4, [x2, #5112]
    84b8:	8b000800 	add	x0, x0, x0, lsl #2
    84bc:	d37df002 	lsl	x2, x0, #3
    84c0:	8b020083 	add	x3, x4, x2
    84c4:	f9401060 	ldr	x0, [x3, #32]
    84c8:	b4fffe20 	cbz	x0, 848c <fwp_args23+0xc>
    84cc:	38626882 	ldrb	w2, [x4, x2]
    84d0:	7100085f 	cmp	w2, #0x2
    84d4:	54000320 	b.eq	8538 <fwp_args23+0xb8>  // b.none
    84d8:	7100045f 	cmp	w2, #0x1
    84dc:	54fffd81 	b.ne	848c <fwp_args23+0xc>  // b.any
    84e0:	29430864 	ldp	w4, w2, [x3, #24]
    84e4:	92403c21 	and	x1, x1, #0xffff
    84e8:	9b047c21 	mul	x1, x1, x4
    84ec:	d360fc21 	lsr	x1, x1, #32
    84f0:	eb02003f 	cmp	x1, x2
    84f4:	54fffcc2 	b.cs	848c <fwp_args23+0xc>  // b.hs, b.nlast
    84f8:	8b010000 	add	x0, x0, x1
    84fc:	39400001 	ldrb	w1, [x0]
    8500:	34fffc61 	cbz	w1, 848c <fwp_args23+0xc>
    8504:	900000c2 	adrp	x2, 20000 <__data_start>
    8508:	91018042 	add	x2, x2, #0x60
    850c:	b9413043 	ldr	w3, [x2, #304]
    8510:	350000c3 	cbnz	w3, 8528 <fwp_args23+0xa8>
    8514:	7103f43f 	cmp	w1, #0xfd
    8518:	54000168 	b.hi	8544 <fwp_args23+0xc4>  // b.pmore
    851c:	11000421 	add	w1, w1, #0x1
    8520:	39000001 	strb	w1, [x0]
    8524:	d65f03c0 	ret
    8528:	f940ac43 	ldr	x3, [x2, #344]
    852c:	91000463 	add	x3, x3, #0x1
    8530:	f900ac43 	str	x3, [x2, #344]
    8534:	17fffff8 	b	8514 <fwp_args23+0x94>
    8538:	72003c3f 	tst	w1, #0xffff
    853c:	54fffe00 	b.eq	84fc <fwp_args23+0x7c>  // b.none
    8540:	d65f03c0 	ret
    8544:	17fff0cc 	b	4874 <fwp_rc_wide_dup>
    8548:	d503201f 	nop
    854c:	d503201f 	nop

0000000000008550 <fwp_caps23>:
    8550:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8554:	910003fd 	mov	x29, sp
    8558:	f9000bf3 	str	x19, [sp, #16]
    855c:	aa0003f3 	mov	x19, x0
    8560:	b9400400 	ldr	w0, [x0, #4]
    8564:	340004a0 	cbz	w0, 85f8 <fwp_caps23+0xa8>
    8568:	f9400660 	ldr	x0, [x19, #8]
    856c:	350004e1 	cbnz	w1, 8608 <fwp_caps23+0xb8>
    8570:	97fffde0 	bl	7cf0 <fwp_drop2>
    8574:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8578:	91190042 	add	x2, x2, #0x640
    857c:	f949d840 	ldr	x0, [x2, #5040]
    8580:	f949ec41 	ldr	x1, [x2, #5080]
    8584:	cb000260 	sub	x0, x19, x0
    8588:	eb01401f 	cmp	x0, x1, lsl #16
    858c:	54000382 	b.cs	85fc <fwp_caps23+0xac>  // b.hs, b.nlast
    8590:	d350fc01 	lsr	x1, x0, #16
    8594:	f949fc44 	ldr	x4, [x2, #5112]
    8598:	8b010821 	add	x1, x1, x1, lsl #2
    859c:	d37df021 	lsl	x1, x1, #3
    85a0:	8b010083 	add	x3, x4, x1
    85a4:	f9401062 	ldr	x2, [x3, #32]
    85a8:	b40002a2 	cbz	x2, 85fc <fwp_caps23+0xac>
    85ac:	38616881 	ldrb	w1, [x4, x1]
    85b0:	7100083f 	cmp	w1, #0x2
    85b4:	54000740 	b.eq	869c <fwp_caps23+0x14c>  // b.none
    85b8:	7100043f 	cmp	w1, #0x1
    85bc:	54000201 	b.ne	85fc <fwp_caps23+0xac>  // b.any
    85c0:	29430464 	ldp	w4, w1, [x3, #24]
    85c4:	92403c00 	and	x0, x0, #0xffff
    85c8:	9b047c00 	mul	x0, x0, x4
    85cc:	d360fc00 	lsr	x0, x0, #32
    85d0:	eb01001f 	cmp	x0, x1
    85d4:	54000142 	b.cs	85fc <fwp_caps23+0xac>  // b.hs, b.nlast
    85d8:	8b000042 	add	x2, x2, x0
    85dc:	39400040 	ldrb	w0, [x2]
    85e0:	7100041f 	cmp	w0, #0x1
    85e4:	540000c1 	b.ne	85fc <fwp_caps23+0xac>  // b.any
    85e8:	aa1303e0 	mov	x0, x19
    85ec:	f9400bf3 	ldr	x19, [sp, #16]
    85f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    85f4:	17fff187 	b	4c10 <fwp_mem_free>
    85f8:	34fffbe1 	cbz	w1, 8574 <fwp_caps23+0x24>
    85fc:	f9400bf3 	ldr	x19, [sp, #16]
    8600:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8604:	d65f03c0 	ret
    8608:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    860c:	91190042 	add	x2, x2, #0x640
    8610:	f949d843 	ldr	x3, [x2, #5040]
    8614:	f949ec41 	ldr	x1, [x2, #5080]
    8618:	cb030000 	sub	x0, x0, x3
    861c:	eb01401f 	cmp	x0, x1, lsl #16
    8620:	54fffee2 	b.cs	85fc <fwp_caps23+0xac>  // b.hs, b.nlast
    8624:	d350fc01 	lsr	x1, x0, #16
    8628:	f949fc44 	ldr	x4, [x2, #5112]
    862c:	8b010821 	add	x1, x1, x1, lsl #2
    8630:	d37df021 	lsl	x1, x1, #3
    8634:	8b010083 	add	x3, x4, x1
    8638:	f9401062 	ldr	x2, [x3, #32]
    863c:	b4fffe02 	cbz	x2, 85fc <fwp_caps23+0xac>
    8640:	38616881 	ldrb	w1, [x4, x1]
    8644:	7100083f 	cmp	w1, #0x2
    8648:	54000300 	b.eq	86a8 <fwp_caps23+0x158>  // b.none
    864c:	7100043f 	cmp	w1, #0x1
    8650:	54fffd61 	b.ne	85fc <fwp_caps23+0xac>  // b.any
    8654:	92403c01 	and	x1, x0, #0xffff
    8658:	29430064 	ldp	w4, w0, [x3, #24]
    865c:	9b047c21 	mul	x1, x1, x4
    8660:	d360fc21 	lsr	x1, x1, #32
    8664:	eb00003f 	cmp	x1, x0
    8668:	54fffca2 	b.cs	85fc <fwp_caps23+0xac>  // b.hs, b.nlast
    866c:	8b010042 	add	x2, x2, x1
    8670:	39400040 	ldrb	w0, [x2]
    8674:	34fffc40 	cbz	w0, 85fc <fwp_caps23+0xac>
    8678:	900000c1 	adrp	x1, 20000 <__data_start>
    867c:	91018021 	add	x1, x1, #0x60
    8680:	b9413023 	ldr	w3, [x1, #304]
    8684:	35000183 	cbnz	w3, 86b4 <fwp_caps23+0x164>
    8688:	7103f41f 	cmp	w0, #0xfd
    868c:	540001c8 	b.hi	86c4 <fwp_caps23+0x174>  // b.pmore
    8690:	11000400 	add	w0, w0, #0x1
    8694:	39000040 	strb	w0, [x2]
    8698:	17ffffd9 	b	85fc <fwp_caps23+0xac>
    869c:	72003c1f 	tst	w0, #0xffff
    86a0:	54fffae1 	b.ne	85fc <fwp_caps23+0xac>  // b.any
    86a4:	17ffffce 	b	85dc <fwp_caps23+0x8c>
    86a8:	72003c1f 	tst	w0, #0xffff
    86ac:	54fffa81 	b.ne	85fc <fwp_caps23+0xac>  // b.any
    86b0:	17fffff0 	b	8670 <fwp_caps23+0x120>
    86b4:	f940ac23 	ldr	x3, [x1, #344]
    86b8:	91000463 	add	x3, x3, #0x1
    86bc:	f900ac23 	str	x3, [x1, #344]
    86c0:	17fffff2 	b	8688 <fwp_caps23+0x138>
    86c4:	f9400bf3 	ldr	x19, [sp, #16]
    86c8:	aa0203e0 	mov	x0, x2
    86cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    86d0:	17fff069 	b	4874 <fwp_rc_wide_dup>

00000000000086d4 <fwp_caps12>:
    86d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    86d8:	910003fd 	mov	x29, sp
    86dc:	f9000bf3 	str	x19, [sp, #16]
    86e0:	aa0003f3 	mov	x19, x0
    86e4:	b9400400 	ldr	w0, [x0, #4]
    86e8:	340004a0 	cbz	w0, 877c <fwp_caps12+0xa8>
    86ec:	f9400660 	ldr	x0, [x19, #8]
    86f0:	350004e1 	cbnz	w1, 878c <fwp_caps12+0xb8>
    86f4:	97fff5a7 	bl	5d90 <fwp_drop0>
    86f8:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    86fc:	91190042 	add	x2, x2, #0x640
    8700:	f949d840 	ldr	x0, [x2, #5040]
    8704:	f949ec41 	ldr	x1, [x2, #5080]
    8708:	cb000260 	sub	x0, x19, x0
    870c:	eb01401f 	cmp	x0, x1, lsl #16
    8710:	54000382 	b.cs	8780 <fwp_caps12+0xac>  // b.hs, b.nlast
    8714:	d350fc01 	lsr	x1, x0, #16
    8718:	f949fc44 	ldr	x4, [x2, #5112]
    871c:	8b010821 	add	x1, x1, x1, lsl #2
    8720:	d37df021 	lsl	x1, x1, #3
    8724:	8b010083 	add	x3, x4, x1
    8728:	f9401062 	ldr	x2, [x3, #32]
    872c:	b40002a2 	cbz	x2, 8780 <fwp_caps12+0xac>
    8730:	38616881 	ldrb	w1, [x4, x1]
    8734:	7100083f 	cmp	w1, #0x2
    8738:	54000740 	b.eq	8820 <fwp_caps12+0x14c>  // b.none
    873c:	7100043f 	cmp	w1, #0x1
    8740:	54000201 	b.ne	8780 <fwp_caps12+0xac>  // b.any
    8744:	29430464 	ldp	w4, w1, [x3, #24]
    8748:	92403c00 	and	x0, x0, #0xffff
    874c:	9b047c00 	mul	x0, x0, x4
    8750:	d360fc00 	lsr	x0, x0, #32
    8754:	eb01001f 	cmp	x0, x1
    8758:	54000142 	b.cs	8780 <fwp_caps12+0xac>  // b.hs, b.nlast
    875c:	8b000042 	add	x2, x2, x0
    8760:	39400040 	ldrb	w0, [x2]
    8764:	7100041f 	cmp	w0, #0x1
    8768:	540000c1 	b.ne	8780 <fwp_caps12+0xac>  // b.any
    876c:	aa1303e0 	mov	x0, x19
    8770:	f9400bf3 	ldr	x19, [sp, #16]
    8774:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8778:	17fff126 	b	4c10 <fwp_mem_free>
    877c:	34fffbe1 	cbz	w1, 86f8 <fwp_caps12+0x24>
    8780:	f9400bf3 	ldr	x19, [sp, #16]
    8784:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8788:	d65f03c0 	ret
    878c:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8790:	91190042 	add	x2, x2, #0x640
    8794:	f949d843 	ldr	x3, [x2, #5040]
    8798:	f949ec41 	ldr	x1, [x2, #5080]
    879c:	cb030000 	sub	x0, x0, x3
    87a0:	eb01401f 	cmp	x0, x1, lsl #16
    87a4:	54fffee2 	b.cs	8780 <fwp_caps12+0xac>  // b.hs, b.nlast
    87a8:	d350fc01 	lsr	x1, x0, #16
    87ac:	f949fc44 	ldr	x4, [x2, #5112]
    87b0:	8b010821 	add	x1, x1, x1, lsl #2
    87b4:	d37df021 	lsl	x1, x1, #3
    87b8:	8b010083 	add	x3, x4, x1
    87bc:	f9401062 	ldr	x2, [x3, #32]
    87c0:	b4fffe02 	cbz	x2, 8780 <fwp_caps12+0xac>
    87c4:	38616881 	ldrb	w1, [x4, x1]
    87c8:	7100083f 	cmp	w1, #0x2
    87cc:	54000300 	b.eq	882c <fwp_caps12+0x158>  // b.none
    87d0:	7100043f 	cmp	w1, #0x1
    87d4:	54fffd61 	b.ne	8780 <fwp_caps12+0xac>  // b.any
    87d8:	92403c01 	and	x1, x0, #0xffff
    87dc:	29430064 	ldp	w4, w0, [x3, #24]
    87e0:	9b047c21 	mul	x1, x1, x4
    87e4:	d360fc21 	lsr	x1, x1, #32
    87e8:	eb00003f 	cmp	x1, x0
    87ec:	54fffca2 	b.cs	8780 <fwp_caps12+0xac>  // b.hs, b.nlast
    87f0:	8b010042 	add	x2, x2, x1
    87f4:	39400040 	ldrb	w0, [x2]
    87f8:	34fffc40 	cbz	w0, 8780 <fwp_caps12+0xac>
    87fc:	900000c1 	adrp	x1, 20000 <__data_start>
    8800:	91018021 	add	x1, x1, #0x60
    8804:	b9413023 	ldr	w3, [x1, #304]
    8808:	35000183 	cbnz	w3, 8838 <fwp_caps12+0x164>
    880c:	7103f41f 	cmp	w0, #0xfd
    8810:	540001c8 	b.hi	8848 <fwp_caps12+0x174>  // b.pmore
    8814:	11000400 	add	w0, w0, #0x1
    8818:	39000040 	strb	w0, [x2]
    881c:	17ffffd9 	b	8780 <fwp_caps12+0xac>
    8820:	72003c1f 	tst	w0, #0xffff
    8824:	54fffae1 	b.ne	8780 <fwp_caps12+0xac>  // b.any
    8828:	17ffffce 	b	8760 <fwp_caps12+0x8c>
    882c:	72003c1f 	tst	w0, #0xffff
    8830:	54fffa81 	b.ne	8780 <fwp_caps12+0xac>  // b.any
    8834:	17fffff0 	b	87f4 <fwp_caps12+0x120>
    8838:	f940ac23 	ldr	x3, [x1, #344]
    883c:	91000463 	add	x3, x3, #0x1
    8840:	f900ac23 	str	x3, [x1, #344]
    8844:	17fffff2 	b	880c <fwp_caps12+0x138>
    8848:	f9400bf3 	ldr	x19, [sp, #16]
    884c:	aa0203e0 	mov	x0, x2
    8850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8854:	17fff008 	b	4874 <fwp_rc_wide_dup>
    8858:	d503201f 	nop
    885c:	d503201f 	nop

0000000000008860 <fwp_write>:
    8860:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8864:	910003fd 	mov	x29, sp
    8868:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    886c:	f947f484 	ldr	x4, [x4, #4072]
    8870:	a90153f3 	stp	x19, x20, [sp, #16]
    8874:	d10943ff 	sub	sp, sp, #0x250
    8878:	b9400045 	ldr	w5, [x2]
    887c:	aa0003f4 	mov	x20, x0
    8880:	f9400080 	ldr	x0, [x4]
    8884:	f90127e0 	str	x0, [sp, #584]
    8888:	d2800000 	mov	x0, #0x0                   	// #0
    888c:	710064bf 	cmp	w5, #0x19
    8890:	54000408 	b.hi	8910 <fwp_write+0xb0>  // b.pmore
    8894:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xa40>
    8898:	aa0103f3 	mov	x19, x1
    889c:	9113c000 	add	x0, x0, #0x4f0
    88a0:	f9013bf5 	str	x21, [sp, #624]
    88a4:	f9013ff6 	str	x22, [sp, #632]
    88a8:	f90153fb 	str	x27, [sp, #672]
    88ac:	f90157fc 	str	x28, [sp, #680]
    88b0:	aa0203fc 	mov	x28, x2
    88b4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    88b8:	10000061 	adr	x1, 88c4 <fwp_write+0x64>
    88bc:	8b20a820 	add	x0, x1, w0, sxth #2
    88c0:	d61f0000 	br	x0
    88c4:	910123e0 	add	x0, sp, #0x48
    88c8:	aa1303e5 	mov	x5, x19
    88cc:	f0000004 	adrp	x4, b000 <__divti3+0x160>
    88d0:	aa0003f3 	mov	x19, x0
    88d4:	91338084 	add	x4, x4, #0xce0
    88d8:	d2804003 	mov	x3, #0x200                 	// #512
    88dc:	aa0303e1 	mov	x1, x3
    88e0:	52800042 	mov	w2, #0x2                   	// #2
    88e4:	97ffe7a7 	bl	2780 <__snprintf_chk@plt>
    88e8:	aa1303e0 	mov	x0, x19
    88ec:	97ffe76d 	bl	26a0 <strlen@plt>
    88f0:	aa1303e1 	mov	x1, x19
    88f4:	aa0003e2 	mov	x2, x0
    88f8:	aa1403e0 	mov	x0, x20
    88fc:	97ffeb45 	bl	3610 <buf_put>
    8900:	f9413bf5 	ldr	x21, [sp, #624]
    8904:	f9413ff6 	ldr	x22, [sp, #632]
    8908:	f94153fb 	ldr	x27, [sp, #672]
    890c:	f94157fc 	ldr	x28, [sp, #680]
    8910:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8914:	f947f400 	ldr	x0, [x0, #4072]
    8918:	f94127e2 	ldr	x2, [sp, #584]
    891c:	f9400001 	ldr	x1, [x0]
    8920:	eb010042 	subs	x2, x2, x1
    8924:	d2800001 	mov	x1, #0x0                   	// #0
    8928:	540077c1 	b.ne	9820 <fwp_write+0xfc0>  // b.any
    892c:	910943ff 	add	sp, sp, #0x250
    8930:	a94153f3 	ldp	x19, x20, [sp, #16]
    8934:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8938:	d65f03c0 	ret
    893c:	910123e0 	add	x0, sp, #0x48
    8940:	aa1303e5 	mov	x5, x19
    8944:	f0000004 	adrp	x4, b000 <__divti3+0x160>
    8948:	aa0003f3 	mov	x19, x0
    894c:	91336084 	add	x4, x4, #0xcd8
    8950:	d2804003 	mov	x3, #0x200                 	// #512
    8954:	17ffffe2 	b	88dc <fwp_write+0x7c>
    8958:	71004cbf 	cmp	w5, #0x13
    895c:	f0000000 	adrp	x0, b000 <__divti3+0x160>
    8960:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8964:	91332000 	add	x0, x0, #0xcc8
    8968:	91334021 	add	x1, x1, #0xcd0
    896c:	d2800082 	mov	x2, #0x4                   	// #4
    8970:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8974:	aa1403e0 	mov	x0, x20
    8978:	f90143f7 	str	x23, [sp, #640]
    897c:	d2800016 	mov	x22, #0x0                   	// #0
    8980:	f90147f8 	str	x24, [sp, #648]
    8984:	97ffeb23 	bl	3610 <buf_put>
    8988:	f9400260 	ldr	x0, [x19]
    898c:	f0000017 	adrp	x23, b000 <__divti3+0x160>
    8990:	d2800015 	mov	x21, #0x0                   	// #0
    8994:	913542f7 	add	x23, x23, #0xd50
    8998:	b40047a0 	cbz	x0, 928c <fwp_write+0xa2c>
    899c:	b9400380 	ldr	w0, [x28]
    89a0:	52800003 	mov	w3, #0x0                   	// #0
    89a4:	f9401f82 	ldr	x2, [x28, #56]
    89a8:	71004c1f 	cmp	w0, #0x13
    89ac:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    89b0:	aa1403e0 	mov	x0, x20
    89b4:	8b010e61 	add	x1, x19, x1, lsl #3
    89b8:	f9400421 	ldr	x1, [x1, #8]
    89bc:	97ffffa9 	bl	8860 <fwp_write>
    89c0:	b9400380 	ldr	w0, [x28]
    89c4:	7100481f 	cmp	w0, #0x12
    89c8:	54004b40 	b.eq	9330 <fwp_write+0xad0>  // b.none
    89cc:	f9400260 	ldr	x0, [x19]
    89d0:	910006b5 	add	x21, x21, #0x1
    89d4:	91000ad6 	add	x22, x22, #0x2
    89d8:	eb15001f 	cmp	x0, x21
    89dc:	54004589 	b.ls	928c <fwp_write+0xa2c>  // b.plast
    89e0:	aa1703e1 	mov	x1, x23
    89e4:	aa1403e0 	mov	x0, x20
    89e8:	d2800042 	mov	x2, #0x2                   	// #2
    89ec:	97ffeb09 	bl	3610 <buf_put>
    89f0:	17ffffeb 	b	899c <fwp_write+0x13c>
    89f4:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    89f8:	91342021 	add	x1, x1, #0xd08
    89fc:	d28000c2 	mov	x2, #0x6                   	// #6
    8a00:	aa1403e0 	mov	x0, x20
    8a04:	91004273 	add	x19, x19, #0x10
    8a08:	97ffeb02 	bl	3610 <buf_put>
    8a0c:	aa1303e0 	mov	x0, x19
    8a10:	97ffe724 	bl	26a0 <strlen@plt>
    8a14:	aa1303e1 	mov	x1, x19
    8a18:	aa0003e2 	mov	x2, x0
    8a1c:	aa1403e0 	mov	x0, x20
    8a20:	97ffeafc 	bl	3610 <buf_put>
    8a24:	528007c3 	mov	w3, #0x3e                  	// #62
    8a28:	aa1403e0 	mov	x0, x20
    8a2c:	91001fe1 	add	x1, sp, #0x7
    8a30:	d2800022 	mov	x2, #0x1                   	// #1
    8a34:	39001fe3 	strb	w3, [sp, #7]
    8a38:	17ffffb1 	b	88fc <fwp_write+0x9c>
    8a3c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8a40:	f947f400 	ldr	x0, [x0, #4072]
    8a44:	f94127e2 	ldr	x2, [sp, #584]
    8a48:	f9400001 	ldr	x1, [x0]
    8a4c:	eb010042 	subs	x2, x2, x1
    8a50:	d2800001 	mov	x1, #0x0                   	// #0
    8a54:	540034e1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8a58:	f9413bf5 	ldr	x21, [sp, #624]
    8a5c:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8a60:	f9413ff6 	ldr	x22, [sp, #632]
    8a64:	aa1403e0 	mov	x0, x20
    8a68:	9133a021 	add	x1, x1, #0xce8
    8a6c:	d2800142 	mov	x2, #0xa                   	// #10
    8a70:	f94153fb 	ldr	x27, [sp, #672]
    8a74:	f94157fc 	ldr	x28, [sp, #680]
    8a78:	910943ff 	add	sp, sp, #0x250
    8a7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a80:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a84:	17ffeae3 	b	3610 <buf_put>
    8a88:	f9400456 	ldr	x22, [x2, #8]
    8a8c:	f90143f7 	str	x23, [sp, #640]
    8a90:	f90147f8 	str	x24, [sp, #648]
    8a94:	b4005b16 	cbz	x22, 95f4 <fwp_write+0xd94>
    8a98:	aa1603e0 	mov	x0, x22
    8a9c:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8aa0:	9135a021 	add	x1, x1, #0xd68
    8aa4:	97ffe77b 	bl	2890 <strcmp@plt>
    8aa8:	2a0003f5 	mov	w21, w0
    8aac:	34005fe0 	cbz	w0, 96a8 <fwp_write+0xe48>
    8ab0:	aa1603e0 	mov	x0, x22
    8ab4:	97ffe6fb 	bl	26a0 <strlen@plt>
    8ab8:	aa1603e1 	mov	x1, x22
    8abc:	aa0003e2 	mov	x2, x0
    8ac0:	aa1403e0 	mov	x0, x20
    8ac4:	97ffead3 	bl	3610 <buf_put>
    8ac8:	52800403 	mov	w3, #0x20                  	// #32
    8acc:	91001ff5 	add	x21, sp, #0x7
    8ad0:	aa1503e1 	mov	x1, x21
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	d2800022 	mov	x2, #0x1                   	// #1
    8adc:	39001fe3 	strb	w3, [sp, #7]
    8ae0:	97ffeacc 	bl	3610 <buf_put>
    8ae4:	52800f63 	mov	w3, #0x7b                  	// #123
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	aa1503e1 	mov	x1, x21
    8af0:	d2800022 	mov	x2, #0x1                   	// #1
    8af4:	39001fe3 	strb	w3, [sp, #7]
    8af8:	97ffeac6 	bl	3610 <buf_put>
    8afc:	b9401380 	ldr	w0, [x28, #16]
    8b00:	52800018 	mov	w24, #0x0                   	// #0
    8b04:	7100001f 	cmp	w0, #0x0
    8b08:	54003aad 	b.le	925c <fwp_write+0x9fc>
    8b0c:	f9014bf9 	str	x25, [sp, #656]
    8b10:	f0000019 	adrp	x25, b000 <__divti3+0x160>
    8b14:	91364339 	add	x25, x25, #0xd90
    8b18:	f9014ffa 	str	x26, [sp, #664]
    8b1c:	f000001a 	adrp	x26, b000 <__divti3+0x160>
    8b20:	9135435a 	add	x26, x26, #0xd50
    8b24:	91002276 	add	x22, x19, #0x8
    8b28:	d2800013 	mov	x19, #0x0                   	// #0
    8b2c:	b5003e93 	cbnz	x19, 92fc <fwp_write+0xa9c>
    8b30:	d37df277 	lsl	x23, x19, #3
    8b34:	34003cb8 	cbz	w24, 92c8 <fwp_write+0xa68>
    8b38:	f9401382 	ldr	x2, [x28, #32]
    8b3c:	aa1403e0 	mov	x0, x20
    8b40:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8b44:	52800003 	mov	w3, #0x0                   	// #0
    8b48:	f8776842 	ldr	x2, [x2, x23]
    8b4c:	91000673 	add	x19, x19, #0x1
    8b50:	97ffff44 	bl	8860 <fwp_write>
    8b54:	b9401380 	ldr	w0, [x28, #16]
    8b58:	6b13001f 	cmp	w0, w19
    8b5c:	54fffe8c 	b.gt	8b2c <fwp_write+0x2cc>
    8b60:	f9414bf9 	ldr	x25, [sp, #656]
    8b64:	f9414ffa 	ldr	x26, [sp, #664]
    8b68:	340037b8 	cbz	w24, 925c <fwp_write+0x9fc>
    8b6c:	52800523 	mov	w3, #0x29                  	// #41
    8b70:	aa1503e1 	mov	x1, x21
    8b74:	aa1403e0 	mov	x0, x20
    8b78:	d2800022 	mov	x2, #0x1                   	// #1
    8b7c:	39001fe3 	strb	w3, [sp, #7]
    8b80:	97ffeaa4 	bl	3610 <buf_put>
    8b84:	f9413bf5 	ldr	x21, [sp, #624]
    8b88:	f9413ff6 	ldr	x22, [sp, #632]
    8b8c:	f94143f7 	ldr	x23, [sp, #640]
    8b90:	f94147f8 	ldr	x24, [sp, #648]
    8b94:	f94153fb 	ldr	x27, [sp, #672]
    8b98:	f94157fc 	ldr	x28, [sp, #680]
    8b9c:	17ffff5d 	b	8910 <fwp_write+0xb0>
    8ba0:	b9404855 	ldr	w21, [x2, #72]
    8ba4:	aa1403e0 	mov	x0, x20
    8ba8:	93407eb6 	sxtw	x22, w21
    8bac:	91000ac1 	add	x1, x22, #0x2
    8bb0:	97ffea64 	bl	3540 <buf_grow>
    8bb4:	a9400281 	ldp	x1, x0, [x20]
    8bb8:	528e8603 	mov	w3, #0x7430                	// #29744
    8bbc:	78206823 	strh	w3, [x1, x0]
    8bc0:	8b000022 	add	x2, x1, x0
    8bc4:	710002bf 	cmp	w21, #0x0
    8bc8:	540036cd 	b.le	92a0 <fwp_write+0xa40>
    8bcc:	110006a3 	add	w3, w21, #0x1
    8bd0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8bd4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8bd8:	91000449 	add	x9, x2, #0x1
    8bdc:	8b23c043 	add	x3, x2, w3, sxtw
    8be0:	f28aaac6 	movk	x6, #0x5556
    8be4:	f2955568 	movk	x8, #0xaaab
    8be8:	1400000d 	b	8c1c <fwp_write+0x3bc>
    8bec:	d2800021 	mov	x1, #0x1                   	// #1
    8bf0:	528005a5 	mov	w5, #0x2d                  	// #45
    8bf4:	f100001f 	cmp	x0, #0x0
    8bf8:	9b467e60 	smulh	x0, x19, x6
    8bfc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8c00:	381ff465 	strb	w5, [x3], #-1
    8c04:	cb040000 	sub	x0, x0, x4
    8c08:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8c0c:	cb020000 	sub	x0, x0, x2
    8c10:	8b010013 	add	x19, x0, x1
    8c14:	eb03013f 	cmp	x9, x3
    8c18:	54003440 	b.eq	92a0 <fwp_write+0xa40>  // b.none
    8c1c:	9b467e60 	smulh	x0, x19, x6
    8c20:	937ffe64 	asr	x4, x19, #63
    8c24:	52800605 	mov	w5, #0x30                  	// #48
    8c28:	cb040000 	sub	x0, x0, x4
    8c2c:	8b000400 	add	x0, x0, x0, lsl #1
    8c30:	cb000260 	sub	x0, x19, x0
    8c34:	91000c01 	add	x1, x0, #0x3
    8c38:	9bc87c22 	umulh	x2, x1, x8
    8c3c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8c40:	8b4204e2 	add	x2, x7, x2, lsr #1
    8c44:	eb020021 	subs	x1, x1, x2
    8c48:	54fffd60 	b.eq	8bf4 <fwp_write+0x394>  // b.none
    8c4c:	f100043f 	cmp	x1, #0x1
    8c50:	54fffce1 	b.ne	8bec <fwp_write+0x38c>  // b.any
    8c54:	d2800001 	mov	x1, #0x0                   	// #0
    8c58:	52800565 	mov	w5, #0x2b                  	// #43
    8c5c:	17ffffe6 	b	8bf4 <fwp_write+0x394>
    8c60:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8c64:	f947f400 	ldr	x0, [x0, #4072]
    8c68:	f94127e2 	ldr	x2, [sp, #584]
    8c6c:	f9400001 	ldr	x1, [x0]
    8c70:	eb010042 	subs	x2, x2, x1
    8c74:	d2800001 	mov	x1, #0x0                   	// #0
    8c78:	540023c1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8c7c:	f9413bf5 	ldr	x21, [sp, #624]
    8c80:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8c84:	f9413ff6 	ldr	x22, [sp, #632]
    8c88:	aa1403e0 	mov	x0, x20
    8c8c:	9133e021 	add	x1, x1, #0xcf8
    8c90:	d2800102 	mov	x2, #0x8                   	// #8
    8c94:	17ffff77 	b	8a70 <fwp_write+0x210>
    8c98:	aa1403e0 	mov	x0, x20
    8c9c:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8ca0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ca4:	91356021 	add	x1, x1, #0xd58
    8ca8:	97ffea5a 	bl	3610 <buf_put>
    8cac:	d2800015 	mov	x21, #0x0                   	// #0
    8cb0:	f9400263 	ldr	x3, [x19]
    8cb4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8cb8:	54002c60 	b.eq	9244 <fwp_write+0x9e4>  // b.none
    8cbc:	f9401f82 	ldr	x2, [x28, #56]
    8cc0:	f90143f7 	str	x23, [sp, #640]
    8cc4:	f90147f8 	str	x24, [sp, #648]
    8cc8:	d2800857 	mov	x23, #0x42                  	// #66
    8ccc:	f9014bf9 	str	x25, [sp, #656]
    8cd0:	f0000016 	adrp	x22, b000 <__divti3+0x160>
    8cd4:	f9014ffa 	str	x26, [sp, #664]
    8cd8:	913542d6 	add	x22, x22, #0xd50
    8cdc:	d2800038 	mov	x24, #0x1                   	// #1
    8ce0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8ce4:	d2809099 	mov	x25, #0x484                 	// #1156
    8ce8:	b40004a2 	cbz	x2, 8d7c <fwp_write+0x51c>
    8cec:	b9400040 	ldr	w0, [x2]
    8cf0:	7100701f 	cmp	w0, #0x1c
    8cf4:	540042c0 	b.eq	954c <fwp_write+0xcec>  // b.none
    8cf8:	71006c1f 	cmp	w0, #0x1b
    8cfc:	54000408 	b.hi	8d7c <fwp_write+0x51c>  // b.pmore
    8d00:	9ac02301 	lsl	x1, x24, x0
    8d04:	ea17003f 	tst	x1, x23
    8d08:	540036a1 	b.ne	93dc <fwp_write+0xb7c>  // b.any
    8d0c:	ea19003f 	tst	x1, x25
    8d10:	54003521 	b.ne	93b4 <fwp_write+0xb54>  // b.any
    8d14:	d2800424 	mov	x4, #0x21                  	// #33
    8d18:	ea04003f 	tst	x1, x4
    8d1c:	54000300 	b.eq	8d7c <fwp_write+0x51c>  // b.none
    8d20:	b7f849c3 	tbnz	x3, #63, 9658 <fwp_write+0xdf8>
    8d24:	91002261 	add	x1, x19, #0x8
    8d28:	8b150021 	add	x1, x1, x21
    8d2c:	39400021 	ldrb	w1, [x1]
    8d30:	7100001f 	cmp	w0, #0x0
    8d34:	93401c23 	sxtb	x3, w1
    8d38:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8d3c:	d503201f 	nop
    8d40:	aa1403e0 	mov	x0, x20
    8d44:	52800003 	mov	w3, #0x0                   	// #0
    8d48:	97fffec6 	bl	8860 <fwp_write>
    8d4c:	910006b5 	add	x21, x21, #0x1
    8d50:	f9400260 	ldr	x0, [x19]
    8d54:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8d58:	eb0002bf 	cmp	x21, x0
    8d5c:	540026c2 	b.cs	9234 <fwp_write+0x9d4>  // b.hs, b.nlast
    8d60:	d2800042 	mov	x2, #0x2                   	// #2
    8d64:	aa1603e1 	mov	x1, x22
    8d68:	aa1403e0 	mov	x0, x20
    8d6c:	97ffea29 	bl	3610 <buf_put>
    8d70:	f9401f82 	ldr	x2, [x28, #56]
    8d74:	f9400263 	ldr	x3, [x19]
    8d78:	b5fffba2 	cbnz	x2, 8cec <fwp_write+0x48c>
    8d7c:	d37df2a0 	lsl	x0, x21, #3
    8d80:	b7f83f03 	tbnz	x3, #63, 9560 <fwp_write+0xd00>
    8d84:	91002261 	add	x1, x19, #0x8
    8d88:	8b000020 	add	x0, x1, x0
    8d8c:	f9400001 	ldr	x1, [x0]
    8d90:	17ffffec 	b	8d40 <fwp_write+0x4e0>
    8d94:	a9400e62 	ldp	x2, x3, [x19]
    8d98:	b7f83ca3 	tbnz	x3, #63, 952c <fwp_write+0xccc>
    8d9c:	910123f5 	add	x21, sp, #0x48
    8da0:	aa1503e0 	mov	x0, x21
    8da4:	97ffe7ff 	bl	2da0 <fwp_fmt_u128>
    8da8:	aa1503e0 	mov	x0, x21
    8dac:	97ffe63d 	bl	26a0 <strlen@plt>
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa0003e2 	mov	x2, x0
    8db8:	17fffed0 	b	88f8 <fwp_write+0x98>
    8dbc:	fd015be8 	str	d8, [sp, #688]
    8dc0:	1e270268 	fmov	s8, w19
    8dc4:	fd015fe9 	str	d9, [sp, #696]
    8dc8:	1e282100 	fcmp	s8, s8
    8dcc:	54004d26 	b.vs	9770 <fwp_write+0xf10>
    8dd0:	1e20c101 	fabs	s1, s8
    8dd4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8dd8:	1e270000 	fmov	s0, w0
    8ddc:	1e202020 	fcmp	s1, s0
    8de0:	54002c0d 	b.le	9360 <fwp_write+0xb00>
    8de4:	1e202118 	fcmpe	s8, #0.0
    8de8:	f0000002 	adrp	x2, b000 <__divti3+0x160>
    8dec:	911ce042 	add	x2, x2, #0x738
    8df0:	910123f5 	add	x21, sp, #0x48
    8df4:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8df8:	9132a021 	add	x1, x1, #0xca8
    8dfc:	aa1503e0 	mov	x0, x21
    8e00:	9a81c041 	csel	x1, x2, x1, gt
    8e04:	97ffe6d3 	bl	2950 <strcpy@plt>
    8e08:	aa1503e0 	mov	x0, x21
    8e0c:	97ffe625 	bl	26a0 <strlen@plt>
    8e10:	aa1503e1 	mov	x1, x21
    8e14:	aa0003e2 	mov	x2, x0
    8e18:	aa1403e0 	mov	x0, x20
    8e1c:	97ffe9fd 	bl	3610 <buf_put>
    8e20:	f9413bf5 	ldr	x21, [sp, #624]
    8e24:	f9413ff6 	ldr	x22, [sp, #632]
    8e28:	f94153fb 	ldr	x27, [sp, #672]
    8e2c:	f94157fc 	ldr	x28, [sp, #680]
    8e30:	fd415be8 	ldr	d8, [sp, #688]
    8e34:	fd415fe9 	ldr	d9, [sp, #696]
    8e38:	17fffeb6 	b	8910 <fwp_write+0xb0>
    8e3c:	f9400276 	ldr	x22, [x19]
    8e40:	34002e03 	cbz	w3, 9400 <fwp_write+0xba0>
    8e44:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8e48:	f947f400 	ldr	x0, [x0, #4072]
    8e4c:	f94127e2 	ldr	x2, [sp, #584]
    8e50:	f9400001 	ldr	x1, [x0]
    8e54:	eb010042 	subs	x2, x2, x1
    8e58:	d2800001 	mov	x1, #0x0                   	// #0
    8e5c:	540014a1 	b.ne	90f0 <fwp_write+0x890>  // b.any
    8e60:	aa1603e2 	mov	x2, x22
    8e64:	91002261 	add	x1, x19, #0x8
    8e68:	f9413bf5 	ldr	x21, [sp, #624]
    8e6c:	aa1403e0 	mov	x0, x20
    8e70:	f9413ff6 	ldr	x22, [sp, #632]
    8e74:	17fffeff 	b	8a70 <fwp_write+0x210>
    8e78:	fd015be8 	str	d8, [sp, #688]
    8e7c:	9e670268 	fmov	d8, x19
    8e80:	fd015fe9 	str	d9, [sp, #696]
    8e84:	1e682100 	fcmp	d8, d8
    8e88:	54004746 	b.vs	9770 <fwp_write+0xf10>
    8e8c:	1e60c101 	fabs	d1, d8
    8e90:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8e94:	9e670000 	fmov	d0, x0
    8e98:	910123f5 	add	x21, sp, #0x48
    8e9c:	52800033 	mov	w19, #0x1                   	// #1
    8ea0:	1e602020 	fcmp	d1, d0
    8ea4:	540001ad 	b.le	8ed8 <fwp_write+0x678>
    8ea8:	1e602118 	fcmpe	d8, #0.0
    8eac:	f0000002 	adrp	x2, b000 <__divti3+0x160>
    8eb0:	911ce042 	add	x2, x2, #0x738
    8eb4:	f0000001 	adrp	x1, b000 <__divti3+0x160>
    8eb8:	9132a021 	add	x1, x1, #0xca8
    8ebc:	aa1503e0 	mov	x0, x21
    8ec0:	9a81c041 	csel	x1, x2, x1, gt
    8ec4:	97ffe6a3 	bl	2950 <strcpy@plt>
    8ec8:	17ffffd0 	b	8e08 <fwp_write+0x5a8>
    8ecc:	11000673 	add	w19, w19, #0x1
    8ed0:	71004a7f 	cmp	w19, #0x12
    8ed4:	54003860 	b.eq	95e0 <fwp_write+0xd80>  // b.none
    8ed8:	1e604100 	fmov	d0, d8
    8edc:	2a1303e1 	mov	w1, w19
    8ee0:	aa1503e0 	mov	x0, x21
    8ee4:	97ffeb0c 	bl	3b14 <fwp_format_g.constprop.0>
    8ee8:	aa1503e0 	mov	x0, x21
    8eec:	d2800001 	mov	x1, #0x0                   	// #0
    8ef0:	97ffe600 	bl	26f0 <strtod@plt>
    8ef4:	1e602100 	fcmp	d8, d0
    8ef8:	54fffea1 	b.ne	8ecc <fwp_write+0x66c>  // b.any
    8efc:	aa1503e0 	mov	x0, x21
    8f00:	97ffe9fd 	bl	36f4 <fwp_finish_float>
    8f04:	17ffffc1 	b	8e08 <fwp_write+0x5a8>
    8f08:	a9400e62 	ldp	x2, x3, [x19]
    8f0c:	910123f3 	add	x19, sp, #0x48
    8f10:	aa1303e0 	mov	x0, x19
    8f14:	97ffe7a3 	bl	2da0 <fwp_fmt_u128>
    8f18:	17fffe74 	b	88e8 <fwp_write+0x88>
    8f1c:	f90143f7 	str	x23, [sp, #640]
    8f20:	f90147f8 	str	x24, [sp, #648]
    8f24:	2a1303f8 	mov	w24, w19
    8f28:	f9014bf9 	str	x25, [sp, #656]
    8f2c:	f9014ffa 	str	x26, [sp, #664]
    8f30:	f13ffe7f 	cmp	x19, #0xfff
    8f34:	54000049 	b.ls	8f3c <fwp_write+0x6dc>  // b.plast
    8f38:	b9400278 	ldr	w24, [x19]
    8f3c:	f9400f80 	ldr	x0, [x28, #24]
    8f40:	2a1803f5 	mov	w21, w24
    8f44:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8f48:	d37ef6b9 	lsl	x25, x21, #2
    8f4c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8f50:	aa1603e0 	mov	x0, x22
    8f54:	97ffe5d3 	bl	26a0 <strlen@plt>
    8f58:	aa1603e1 	mov	x1, x22
    8f5c:	aa0003e2 	mov	x2, x0
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	97ffe9ab 	bl	3610 <buf_put>
    8f68:	f9401780 	ldr	x0, [x28, #40]
    8f6c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8f70:	7100001f 	cmp	w0, #0x0
    8f74:	5400068d 	b.le	9044 <fwp_write+0x7e4>
    8f78:	91002276 	add	x22, x19, #0x8
    8f7c:	91001ff5 	add	x21, sp, #0x7
    8f80:	d280001b 	mov	x27, #0x0                   	// #0
    8f84:	5280041a 	mov	w26, #0x20                  	// #32
    8f88:	f9401b80 	ldr	x0, [x28, #48]
    8f8c:	aa1503e1 	mov	x1, x21
    8f90:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8f94:	d2800022 	mov	x2, #0x1                   	// #1
    8f98:	f8786803 	ldr	x3, [x0, x24]
    8f9c:	aa1403e0 	mov	x0, x20
    8fa0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8fa4:	39001ffa 	strb	w26, [sp, #7]
    8fa8:	97ffe99a 	bl	3610 <buf_put>
    8fac:	f13ffeff 	cmp	x23, #0xfff
    8fb0:	b9400261 	ldr	w1, [x19]
    8fb4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8fb8:	7100383f 	cmp	w1, #0xe
    8fbc:	54000160 	b.eq	8fe8 <fwp_write+0x788>  // b.none
    8fc0:	7100403f 	cmp	w1, #0x10
    8fc4:	54001a60 	b.eq	9310 <fwp_write+0xab0>  // b.none
    8fc8:	7100283f 	cmp	w1, #0xa
    8fcc:	54002aa0 	b.eq	9520 <fwp_write+0xcc0>  // b.none
    8fd0:	540014ac 	b.gt	9264 <fwp_write+0xa04>
    8fd4:	71000c3f 	cmp	w1, #0x3
    8fd8:	540029ac 	b.gt	950c <fwp_write+0xcac>
    8fdc:	d37ffee0 	lsr	x0, x23, #63
    8fe0:	37f814a1 	tbnz	w1, #31, 9274 <fwp_write+0xa14>
    8fe4:	d503201f 	nop
    8fe8:	34001460 	cbz	w0, 9274 <fwp_write+0xa14>
    8fec:	52800503 	mov	w3, #0x28                  	// #40
    8ff0:	aa1503e1 	mov	x1, x21
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	d2800022 	mov	x2, #0x1                   	// #1
    8ffc:	39001fe3 	strb	w3, [sp, #7]
    9000:	97ffe984 	bl	3610 <buf_put>
    9004:	aa1303e2 	mov	x2, x19
    9008:	aa1703e1 	mov	x1, x23
    900c:	aa1403e0 	mov	x0, x20
    9010:	52800003 	mov	w3, #0x0                   	// #0
    9014:	97fffe13 	bl	8860 <fwp_write>
    9018:	52800523 	mov	w3, #0x29                  	// #41
    901c:	aa1503e1 	mov	x1, x21
    9020:	aa1403e0 	mov	x0, x20
    9024:	d2800022 	mov	x2, #0x1                   	// #1
    9028:	39001fe3 	strb	w3, [sp, #7]
    902c:	97ffe979 	bl	3610 <buf_put>
    9030:	f9401780 	ldr	x0, [x28, #40]
    9034:	9100077b 	add	x27, x27, #0x1
    9038:	b8796800 	ldr	w0, [x0, x25]
    903c:	6b1b001f 	cmp	w0, w27
    9040:	54fffa4c 	b.gt	8f88 <fwp_write+0x728>
    9044:	f9413bf5 	ldr	x21, [sp, #624]
    9048:	f9413ff6 	ldr	x22, [sp, #632]
    904c:	f94143f7 	ldr	x23, [sp, #640]
    9050:	f94147f8 	ldr	x24, [sp, #648]
    9054:	f9414bf9 	ldr	x25, [sp, #656]
    9058:	f9414ffa 	ldr	x26, [sp, #664]
    905c:	f94153fb 	ldr	x27, [sp, #672]
    9060:	f94157fc 	ldr	x28, [sp, #680]
    9064:	17fffe2b 	b	8910 <fwp_write+0xb0>
    9068:	52800783 	mov	w3, #0x3c                  	// #60
    906c:	91001ff3 	add	x19, sp, #0x7
    9070:	aa1303e1 	mov	x1, x19
    9074:	d2800022 	mov	x2, #0x1                   	// #1
    9078:	aa1403e0 	mov	x0, x20
    907c:	39001fe3 	strb	w3, [sp, #7]
    9080:	97ffe964 	bl	3610 <buf_put>
    9084:	f9400795 	ldr	x21, [x28, #8]
    9088:	aa1503e0 	mov	x0, x21
    908c:	97ffe585 	bl	26a0 <strlen@plt>
    9090:	aa1503e1 	mov	x1, x21
    9094:	aa0003e2 	mov	x2, x0
    9098:	aa1403e0 	mov	x0, x20
    909c:	97ffe95d 	bl	3610 <buf_put>
    90a0:	528007c3 	mov	w3, #0x3e                  	// #62
    90a4:	aa1303e1 	mov	x1, x19
    90a8:	aa1403e0 	mov	x0, x20
    90ac:	d2800022 	mov	x2, #0x1                   	// #1
    90b0:	39001fe3 	strb	w3, [sp, #7]
    90b4:	17fffe12 	b	88fc <fwp_write+0x9c>
    90b8:	f100067f 	cmp	x19, #0x1
    90bc:	540025a0 	b.eq	9570 <fwp_write+0xd10>  // b.none
    90c0:	b100067f 	cmn	x19, #0x1
    90c4:	54002bc0 	b.eq	963c <fwp_write+0xddc>  // b.none
    90c8:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    90cc:	9132c021 	add	x1, x1, #0xcb0
    90d0:	d2800022 	mov	x2, #0x1                   	// #1
    90d4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    90d8:	f947f400 	ldr	x0, [x0, #4072]
    90dc:	f94127e4 	ldr	x4, [sp, #584]
    90e0:	f9400003 	ldr	x3, [x0]
    90e4:	eb030084 	subs	x4, x4, x3
    90e8:	d2800003 	mov	x3, #0x0                   	// #0
    90ec:	54ffebe0 	b.eq	8e68 <fwp_write+0x608>  // b.none
    90f0:	f90143f7 	str	x23, [sp, #640]
    90f4:	f90147f8 	str	x24, [sp, #648]
    90f8:	f9014bf9 	str	x25, [sp, #656]
    90fc:	f9014ffa 	str	x26, [sp, #664]
    9100:	fd015be8 	str	d8, [sp, #688]
    9104:	fd015fe9 	str	d9, [sp, #696]
    9108:	97ffe5c2 	bl	2810 <__stack_chk_fail@plt>
    910c:	52800b63 	mov	w3, #0x5b                  	// #91
    9110:	91001ff5 	add	x21, sp, #0x7
    9114:	aa1503e1 	mov	x1, x21
    9118:	aa1403e0 	mov	x0, x20
    911c:	d2800022 	mov	x2, #0x1                   	// #1
    9120:	d0000016 	adrp	x22, b000 <__divti3+0x160>
    9124:	913542d6 	add	x22, x22, #0xd50
    9128:	39001fe3 	strb	w3, [sp, #7]
    912c:	97ffe939 	bl	3610 <buf_put>
    9130:	b4000273 	cbz	x19, 917c <fwp_write+0x91c>
    9134:	f9400661 	ldr	x1, [x19, #8]
    9138:	aa1403e0 	mov	x0, x20
    913c:	f9401f82 	ldr	x2, [x28, #56]
    9140:	52800003 	mov	w3, #0x0                   	// #0
    9144:	97fffdc7 	bl	8860 <fwp_write>
    9148:	f9400a73 	ldr	x19, [x19, #16]
    914c:	b4000193 	cbz	x19, 917c <fwp_write+0x91c>
    9150:	aa1603e1 	mov	x1, x22
    9154:	aa1403e0 	mov	x0, x20
    9158:	d2800042 	mov	x2, #0x2                   	// #2
    915c:	97ffe92d 	bl	3610 <buf_put>
    9160:	f9400661 	ldr	x1, [x19, #8]
    9164:	aa1403e0 	mov	x0, x20
    9168:	f9401f82 	ldr	x2, [x28, #56]
    916c:	52800003 	mov	w3, #0x0                   	// #0
    9170:	97fffdbc 	bl	8860 <fwp_write>
    9174:	f9400a73 	ldr	x19, [x19, #16]
    9178:	b5fffed3 	cbnz	x19, 9150 <fwp_write+0x8f0>
    917c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9180:	aa1503e1 	mov	x1, x21
    9184:	aa1403e0 	mov	x0, x20
    9188:	d2800022 	mov	x2, #0x1                   	// #1
    918c:	39001fe3 	strb	w3, [sp, #7]
    9190:	17fffddb 	b	88fc <fwp_write+0x9c>
    9194:	aa1403e0 	mov	x0, x20
    9198:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    919c:	d28000c2 	mov	x2, #0x6                   	// #6
    91a0:	91350021 	add	x1, x1, #0xd40
    91a4:	97ffe91b 	bl	3610 <buf_put>
    91a8:	f9400260 	ldr	x0, [x19]
    91ac:	b40004c0 	cbz	x0, 9244 <fwp_write+0x9e4>
    91b0:	910123f5 	add	x21, sp, #0x48
    91b4:	91002276 	add	x22, x19, #0x8
    91b8:	f90143f7 	str	x23, [sp, #640]
    91bc:	d2800017 	mov	x23, #0x0                   	// #0
    91c0:	f90147f8 	str	x24, [sp, #648]
    91c4:	d0000018 	adrp	x24, b000 <__divti3+0x160>
    91c8:	91352318 	add	x24, x24, #0xd48
    91cc:	f9014bf9 	str	x25, [sp, #656]
    91d0:	d0000019 	adrp	x25, b000 <__divti3+0x160>
    91d4:	91354339 	add	x25, x25, #0xd50
    91d8:	f9014ffa 	str	x26, [sp, #664]
    91dc:	14000005 	b	91f0 <fwp_write+0x990>
    91e0:	aa1903e1 	mov	x1, x25
    91e4:	aa1403e0 	mov	x0, x20
    91e8:	d2800042 	mov	x2, #0x2                   	// #2
    91ec:	97ffe909 	bl	3610 <buf_put>
    91f0:	38776ac5 	ldrb	w5, [x22, x23]
    91f4:	d2804003 	mov	x3, #0x200                 	// #512
    91f8:	aa1803e4 	mov	x4, x24
    91fc:	aa0303e1 	mov	x1, x3
    9200:	52800042 	mov	w2, #0x2                   	// #2
    9204:	aa1503e0 	mov	x0, x21
    9208:	910006f7 	add	x23, x23, #0x1
    920c:	97ffe55d 	bl	2780 <__snprintf_chk@plt>
    9210:	aa1503e0 	mov	x0, x21
    9214:	97ffe523 	bl	26a0 <strlen@plt>
    9218:	aa1503e1 	mov	x1, x21
    921c:	aa0003e2 	mov	x2, x0
    9220:	aa1403e0 	mov	x0, x20
    9224:	97ffe8fb 	bl	3610 <buf_put>
    9228:	f9400260 	ldr	x0, [x19]
    922c:	eb17001f 	cmp	x0, x23
    9230:	54fffd88 	b.hi	91e0 <fwp_write+0x980>  // b.pmore
    9234:	f94143f7 	ldr	x23, [sp, #640]
    9238:	f94147f8 	ldr	x24, [sp, #648]
    923c:	f9414bf9 	ldr	x25, [sp, #656]
    9240:	f9414ffa 	ldr	x26, [sp, #664]
    9244:	52800ba3 	mov	w3, #0x5d                  	// #93
    9248:	aa1403e0 	mov	x0, x20
    924c:	91001fe1 	add	x1, sp, #0x7
    9250:	d2800022 	mov	x2, #0x1                   	// #1
    9254:	39001fe3 	strb	w3, [sp, #7]
    9258:	17fffda9 	b	88fc <fwp_write+0x9c>
    925c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9260:	17fffe44 	b	8b70 <fwp_write+0x310>
    9264:	f10002ff 	cmp	x23, #0x0
    9268:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    926c:	71002c3f 	cmp	w1, #0xb
    9270:	54ffebc0 	b.eq	8fe8 <fwp_write+0x788>  // b.none
    9274:	aa1303e2 	mov	x2, x19
    9278:	aa1703e1 	mov	x1, x23
    927c:	aa1403e0 	mov	x0, x20
    9280:	52800003 	mov	w3, #0x0                   	// #0
    9284:	97fffd77 	bl	8860 <fwp_write>
    9288:	17ffff6a 	b	9030 <fwp_write+0x7d0>
    928c:	aa1403e0 	mov	x0, x20
    9290:	91001fe1 	add	x1, sp, #0x7
    9294:	52800fa3 	mov	w3, #0x7d                  	// #125
    9298:	d2800022 	mov	x2, #0x1                   	// #1
    929c:	17fffe38 	b	8b7c <fwp_write+0x31c>
    92a0:	a9400281 	ldp	x1, x0, [x20]
    92a4:	91000800 	add	x0, x0, #0x2
    92a8:	8b160000 	add	x0, x0, x22
    92ac:	f9000680 	str	x0, [x20, #8]
    92b0:	3820683f 	strb	wzr, [x1, x0]
    92b4:	f9413bf5 	ldr	x21, [sp, #624]
    92b8:	f9413ff6 	ldr	x22, [sp, #632]
    92bc:	f94153fb 	ldr	x27, [sp, #672]
    92c0:	f94157fc 	ldr	x28, [sp, #680]
    92c4:	17fffd93 	b	8910 <fwp_write+0xb0>
    92c8:	f9400f80 	ldr	x0, [x28, #24]
    92cc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    92d0:	aa1b03e0 	mov	x0, x27
    92d4:	97ffe4f3 	bl	26a0 <strlen@plt>
    92d8:	aa1b03e1 	mov	x1, x27
    92dc:	aa0003e2 	mov	x2, x0
    92e0:	aa1403e0 	mov	x0, x20
    92e4:	97ffe8cb 	bl	3610 <buf_put>
    92e8:	aa1903e1 	mov	x1, x25
    92ec:	aa1403e0 	mov	x0, x20
    92f0:	d2800062 	mov	x2, #0x3                   	// #3
    92f4:	97ffe8c7 	bl	3610 <buf_put>
    92f8:	17fffe10 	b	8b38 <fwp_write+0x2d8>
    92fc:	aa1a03e1 	mov	x1, x26
    9300:	aa1403e0 	mov	x0, x20
    9304:	d2800042 	mov	x2, #0x2                   	// #2
    9308:	97ffe8c2 	bl	3610 <buf_put>
    930c:	17fffe09 	b	8b30 <fwp_write+0x2d0>
    9310:	f9400660 	ldr	x0, [x19, #8]
    9314:	b4fffb00 	cbz	x0, 9274 <fwp_write+0xa14>
    9318:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    931c:	9135a021 	add	x1, x1, #0xd68
    9320:	97ffe55c 	bl	2890 <strcmp@plt>
    9324:	7100001f 	cmp	w0, #0x0
    9328:	1a9f07e0 	cset	w0, ne	// ne = any
    932c:	17ffff2f 	b	8fe8 <fwp_write+0x788>
    9330:	aa1403e0 	mov	x0, x20
    9334:	d2800042 	mov	x2, #0x2                   	// #2
    9338:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    933c:	91358021 	add	x1, x1, #0xd60
    9340:	97ffe8b4 	bl	3610 <buf_put>
    9344:	91004261 	add	x1, x19, #0x10
    9348:	aa1403e0 	mov	x0, x20
    934c:	f9402382 	ldr	x2, [x28, #64]
    9350:	52800003 	mov	w3, #0x0                   	// #0
    9354:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9358:	97fffd42 	bl	8860 <fwp_write>
    935c:	17fffd9c 	b	89cc <fwp_write+0x16c>
    9360:	1e22c109 	fcvt	d9, s8
    9364:	910123f5 	add	x21, sp, #0x48
    9368:	52800033 	mov	w19, #0x1                   	// #1
    936c:	d503201f 	nop
    9370:	1e604120 	fmov	d0, d9
    9374:	2a1303e1 	mov	w1, w19
    9378:	aa1503e0 	mov	x0, x21
    937c:	97ffe9e6 	bl	3b14 <fwp_format_g.constprop.0>
    9380:	aa1503e0 	mov	x0, x21
    9384:	d2800001 	mov	x1, #0x0                   	// #0
    9388:	97ffe54e 	bl	28c0 <strtof@plt>
    938c:	1e202100 	fcmp	s8, s0
    9390:	54ffdb60 	b.eq	8efc <fwp_write+0x69c>  // b.none
    9394:	11000673 	add	w19, w19, #0x1
    9398:	71002a7f 	cmp	w19, #0xa
    939c:	54fffea1 	b.ne	9370 <fwp_write+0xb10>  // b.any
    93a0:	1e604120 	fmov	d0, d9
    93a4:	aa1503e0 	mov	x0, x21
    93a8:	52800121 	mov	w1, #0x9                   	// #9
    93ac:	97ffe9da 	bl	3b14 <fwp_format_g.constprop.0>
    93b0:	17fffed3 	b	8efc <fwp_write+0x69c>
    93b4:	d37ef6a1 	lsl	x1, x21, #2
    93b8:	b7f81563 	tbnz	x3, #63, 9664 <fwp_write+0xe04>
    93bc:	91002263 	add	x3, x19, #0x8
    93c0:	8b010061 	add	x1, x3, x1
    93c4:	b9400023 	ldr	w3, [x1]
    93c8:	7100081f 	cmp	w0, #0x2
    93cc:	2a0303e1 	mov	w1, w3
    93d0:	93407c63 	sxtw	x3, w3
    93d4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    93d8:	17fffe5a 	b	8d40 <fwp_write+0x4e0>
    93dc:	d37ffaa1 	lsl	x1, x21, #1
    93e0:	b7f81363 	tbnz	x3, #63, 964c <fwp_write+0xdec>
    93e4:	91002263 	add	x3, x19, #0x8
    93e8:	8b010061 	add	x1, x3, x1
    93ec:	79400021 	ldrh	w1, [x1]
    93f0:	7100041f 	cmp	w0, #0x1
    93f4:	93403c23 	sxth	x3, w1
    93f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    93fc:	17fffe51 	b	8d40 <fwp_write+0x4e0>
    9400:	52800443 	mov	w3, #0x22                  	// #34
    9404:	91001ff5 	add	x21, sp, #0x7
    9408:	91002273 	add	x19, x19, #0x8
    940c:	aa1503e1 	mov	x1, x21
    9410:	aa1403e0 	mov	x0, x20
    9414:	d2800022 	mov	x2, #0x1                   	// #1
    9418:	39001fe3 	strb	w3, [sp, #7]
    941c:	f90143f7 	str	x23, [sp, #640]
    9420:	8b160277 	add	x23, x19, x22
    9424:	f90147f8 	str	x24, [sp, #648]
    9428:	97ffe87a 	bl	3610 <buf_put>
    942c:	b4000696 	cbz	x22, 94fc <fwp_write+0xc9c>
    9430:	d0000018 	adrp	x24, b000 <__divti3+0x160>
    9434:	91344318 	add	x24, x24, #0xd10
    9438:	f9014bf9 	str	x25, [sp, #656]
    943c:	d0000019 	adrp	x25, b000 <__divti3+0x160>
    9440:	9134c339 	add	x25, x25, #0xd30
    9444:	f9014ffa 	str	x26, [sp, #664]
    9448:	1400000d 	b	947c <fwp_write+0xc1c>
    944c:	710024bf 	cmp	w5, #0x9
    9450:	54000460 	b.eq	94dc <fwp_write+0xc7c>  // b.none
    9454:	710028bf 	cmp	w5, #0xa
    9458:	54000a61 	b.ne	95a4 <fwp_write+0xd44>  // b.any
    945c:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    9460:	aa1403e0 	mov	x0, x20
    9464:	91348021 	add	x1, x1, #0xd20
    9468:	d2800042 	mov	x2, #0x2                   	// #2
    946c:	97ffe869 	bl	3610 <buf_put>
    9470:	91000673 	add	x19, x19, #0x1
    9474:	eb17027f 	cmp	x19, x23
    9478:	540003e0 	b.eq	94f4 <fwp_write+0xc94>  // b.none
    947c:	39400265 	ldrb	w5, [x19]
    9480:	710034bf 	cmp	w5, #0xd
    9484:	54000180 	b.eq	94b4 <fwp_write+0xc54>  // b.none
    9488:	54fffe29 	b.ls	944c <fwp_write+0xbec>  // b.plast
    948c:	710088bf 	cmp	w5, #0x22
    9490:	540001c0 	b.eq	94c8 <fwp_write+0xc68>  // b.none
    9494:	710170bf 	cmp	w5, #0x5c
    9498:	54000741 	b.ne	9580 <fwp_write+0xd20>  // b.any
    949c:	aa1403e0 	mov	x0, x20
    94a0:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    94a4:	d2800042 	mov	x2, #0x2                   	// #2
    94a8:	91346021 	add	x1, x1, #0xd18
    94ac:	97ffe859 	bl	3610 <buf_put>
    94b0:	17fffff0 	b	9470 <fwp_write+0xc10>
    94b4:	aa1903e1 	mov	x1, x25
    94b8:	aa1403e0 	mov	x0, x20
    94bc:	d2800042 	mov	x2, #0x2                   	// #2
    94c0:	97ffe854 	bl	3610 <buf_put>
    94c4:	17ffffeb 	b	9470 <fwp_write+0xc10>
    94c8:	aa1803e1 	mov	x1, x24
    94cc:	aa1403e0 	mov	x0, x20
    94d0:	d2800042 	mov	x2, #0x2                   	// #2
    94d4:	97ffe84f 	bl	3610 <buf_put>
    94d8:	17ffffe6 	b	9470 <fwp_write+0xc10>
    94dc:	aa1403e0 	mov	x0, x20
    94e0:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    94e4:	d2800042 	mov	x2, #0x2                   	// #2
    94e8:	9134a021 	add	x1, x1, #0xd28
    94ec:	97ffe849 	bl	3610 <buf_put>
    94f0:	17ffffe0 	b	9470 <fwp_write+0xc10>
    94f4:	f9414bf9 	ldr	x25, [sp, #656]
    94f8:	f9414ffa 	ldr	x26, [sp, #664]
    94fc:	aa1503e1 	mov	x1, x21
    9500:	aa1403e0 	mov	x0, x20
    9504:	52800443 	mov	w3, #0x22                  	// #34
    9508:	17fffd9c 	b	8b78 <fwp_write+0x318>
    950c:	7100103f 	cmp	w1, #0x4
    9510:	54ffeb21 	b.ne	9274 <fwp_write+0xa14>  // b.any
    9514:	f94006e0 	ldr	x0, [x23, #8]
    9518:	d37ffc00 	lsr	x0, x0, #63
    951c:	17fffeb3 	b	8fe8 <fwp_write+0x788>
    9520:	710002ff 	cmp	w23, #0x0
    9524:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9528:	17fffeb0 	b	8fe8 <fwp_write+0x788>
    952c:	528005a1 	mov	w1, #0x2d                  	// #45
    9530:	eb0203e2 	negs	x2, x2
    9534:	da0303e3 	ngc	x3, x3
    9538:	910127e0 	add	x0, sp, #0x49
    953c:	910123f5 	add	x21, sp, #0x48
    9540:	390123e1 	strb	w1, [sp, #72]
    9544:	97ffe617 	bl	2da0 <fwp_fmt_u128>
    9548:	17fffe18 	b	8da8 <fwp_write+0x548>
    954c:	d37ceea1 	lsl	x1, x21, #4
    9550:	b7f810a3 	tbnz	x3, #63, 9764 <fwp_write+0xf04>
    9554:	91002260 	add	x0, x19, #0x8
    9558:	8b010001 	add	x1, x0, x1
    955c:	17fffdf9 	b	8d40 <fwp_write+0x4e0>
    9560:	f9400a61 	ldr	x1, [x19, #16]
    9564:	8b010000 	add	x0, x0, x1
    9568:	f9400001 	ldr	x1, [x0]
    956c:	17fffdf5 	b	8d40 <fwp_write+0x4e0>
    9570:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	9132e021 	add	x1, x1, #0xcb8
    957c:	17fffed6 	b	90d4 <fwp_write+0x874>
    9580:	7101fcbf 	cmp	w5, #0x7f
    9584:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9588:	540000e9 	b.ls	95a4 <fwp_write+0xd44>  // b.plast
    958c:	aa1503e1 	mov	x1, x21
    9590:	aa1403e0 	mov	x0, x20
    9594:	d2800022 	mov	x2, #0x1                   	// #1
    9598:	39001fe5 	strb	w5, [sp, #7]
    959c:	97ffe81d 	bl	3610 <buf_put>
    95a0:	17ffffb4 	b	9470 <fwp_write+0xc10>
    95a4:	d2800203 	mov	x3, #0x10                  	// #16
    95a8:	d0000004 	adrp	x4, b000 <__divti3+0x160>
    95ac:	aa0303e1 	mov	x1, x3
    95b0:	9134e084 	add	x4, x4, #0xd38
    95b4:	910123f6 	add	x22, sp, #0x48
    95b8:	52800042 	mov	w2, #0x2                   	// #2
    95bc:	aa1603e0 	mov	x0, x22
    95c0:	97ffe470 	bl	2780 <__snprintf_chk@plt>
    95c4:	aa1603e0 	mov	x0, x22
    95c8:	97ffe436 	bl	26a0 <strlen@plt>
    95cc:	aa1603e1 	mov	x1, x22
    95d0:	aa0003e2 	mov	x2, x0
    95d4:	aa1403e0 	mov	x0, x20
    95d8:	97ffe80e 	bl	3610 <buf_put>
    95dc:	17ffffa5 	b	9470 <fwp_write+0xc10>
    95e0:	1e604100 	fmov	d0, d8
    95e4:	aa1503e0 	mov	x0, x21
    95e8:	52800221 	mov	w1, #0x11                  	// #17
    95ec:	97ffe94a 	bl	3b14 <fwp_format_g.constprop.0>
    95f0:	17fffe43 	b	8efc <fwp_write+0x69c>
    95f4:	b9401040 	ldr	w0, [x2, #16]
    95f8:	350003c0 	cbnz	w0, 9670 <fwp_write+0xe10>
    95fc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9600:	f947f400 	ldr	x0, [x0, #4072]
    9604:	f94127e2 	ldr	x2, [sp, #584]
    9608:	f9400001 	ldr	x1, [x0]
    960c:	eb010042 	subs	x2, x2, x1
    9610:	d2800001 	mov	x1, #0x0                   	// #0
    9614:	54ffd721 	b.ne	90f8 <fwp_write+0x898>  // b.any
    9618:	f9413bf5 	ldr	x21, [sp, #624]
    961c:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    9620:	f9413ff6 	ldr	x22, [sp, #632]
    9624:	aa1403e0 	mov	x0, x20
    9628:	f94143f7 	ldr	x23, [sp, #640]
    962c:	91362021 	add	x1, x1, #0xd88
    9630:	f94147f8 	ldr	x24, [sp, #648]
    9634:	d2800042 	mov	x2, #0x2                   	// #2
    9638:	17fffd0e 	b	8a70 <fwp_write+0x210>
    963c:	d0000001 	adrp	x1, b000 <__divti3+0x160>
    9640:	d2800042 	mov	x2, #0x2                   	// #2
    9644:	91330021 	add	x1, x1, #0xcc0
    9648:	17fffea3 	b	90d4 <fwp_write+0x874>
    964c:	f9400a63 	ldr	x3, [x19, #16]
    9650:	8b030021 	add	x1, x1, x3
    9654:	17ffff66 	b	93ec <fwp_write+0xb8c>
    9658:	f9400a61 	ldr	x1, [x19, #16]
    965c:	8b0102a1 	add	x1, x21, x1
    9660:	17fffdb3 	b	8d2c <fwp_write+0x4cc>
    9664:	f9400a63 	ldr	x3, [x19, #16]
    9668:	8b030021 	add	x1, x1, x3
    966c:	17ffff56 	b	93c4 <fwp_write+0xb64>
    9670:	b9404840 	ldr	w0, [x2, #72]
    9674:	91001ff5 	add	x21, sp, #0x7
    9678:	34ffa360 	cbz	w0, 8ae4 <fwp_write+0x284>
    967c:	52800503 	mov	w3, #0x28                  	// #40
    9680:	aa1403e0 	mov	x0, x20
    9684:	aa1503e1 	mov	x1, x21
    9688:	d2800022 	mov	x2, #0x1                   	// #1
    968c:	39001fe3 	strb	w3, [sp, #7]
    9690:	97ffe7e0 	bl	3610 <buf_put>
    9694:	b9401380 	ldr	w0, [x28, #16]
    9698:	52800038 	mov	w24, #0x1                   	// #1
    969c:	7100001f 	cmp	w0, #0x0
    96a0:	54ffa36c 	b.gt	8b0c <fwp_write+0x2ac>
    96a4:	17fffd32 	b	8b6c <fwp_write+0x30c>
    96a8:	f9014bf9 	str	x25, [sp, #656]
    96ac:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10690>
    96b0:	f9014ffa 	str	x26, [sp, #664]
    96b4:	f9400676 	ldr	x22, [x19, #8]
    96b8:	91104333 	add	x19, x25, #0x410
    96bc:	91002273 	add	x19, x19, #0x8
    96c0:	937ffed8 	asr	x24, x22, #63
    96c4:	aa1802c0 	orr	x0, x22, x24
    96c8:	b5000320 	cbnz	x0, 972c <fwp_write+0xecc>
    96cc:	110006b5 	add	w21, w21, #0x1
    96d0:	710016bf 	cmp	w21, #0x5
    96d4:	54ffffc1 	b.ne	96cc <fwp_write+0xe6c>  // b.any
    96d8:	b7f80578 	tbnz	x24, #63, 9784 <fwp_write+0xf24>
    96dc:	910023f3 	add	x19, sp, #0x8
    96e0:	aa1603e2 	mov	x2, x22
    96e4:	aa1303e0 	mov	x0, x19
    96e8:	d2800003 	mov	x3, #0x0                   	// #0
    96ec:	97ffe5ad 	bl	2da0 <fwp_fmt_u128>
    96f0:	910123f5 	add	x21, sp, #0x48
    96f4:	d0000003 	adrp	x3, b000 <__divti3+0x160>
    96f8:	aa1303e4 	mov	x4, x19
    96fc:	aa1503e0 	mov	x0, x21
    9700:	91360063 	add	x3, x3, #0xd80
    9704:	d2804002 	mov	x2, #0x200                 	// #512
    9708:	52800041 	mov	w1, #0x2                   	// #2
    970c:	97ffe3e9 	bl	26b0 <__sprintf_chk@plt>
    9710:	aa1503e0 	mov	x0, x21
    9714:	97ffe3e3 	bl	26a0 <strlen@plt>
    9718:	aa1503e1 	mov	x1, x21
    971c:	aa0003e2 	mov	x2, x0
    9720:	aa1403e0 	mov	x0, x20
    9724:	97ffe7bb 	bl	3610 <buf_put>
    9728:	17fffe47 	b	9044 <fwp_write+0x7e4>
    972c:	f9400277 	ldr	x23, [x19]
    9730:	aa1603e0 	mov	x0, x22
    9734:	aa1803e1 	mov	x1, x24
    9738:	aa1703e2 	mov	x2, x23
    973c:	937ffefa 	asr	x26, x23, #63
    9740:	aa1a03e3 	mov	x3, x26
    9744:	940006b7 	bl	b220 <__modti3>
    9748:	aa010000 	orr	x0, x0, x1
    974c:	b40002c0 	cbz	x0, 97a4 <fwp_write+0xf44>
    9750:	110006b5 	add	w21, w21, #0x1
    9754:	91004273 	add	x19, x19, #0x10
    9758:	710016bf 	cmp	w21, #0x5
    975c:	54fffe81 	b.ne	972c <fwp_write+0xecc>  // b.any
    9760:	17ffffde 	b	96d8 <fwp_write+0xe78>
    9764:	f9400a60 	ldr	x0, [x19, #16]
    9768:	8b000021 	add	x1, x1, x0
    976c:	17fffd75 	b	8d40 <fwp_write+0x4e0>
    9770:	528c29c0 	mov	w0, #0x614e                	// #24910
    9774:	910123f5 	add	x21, sp, #0x48
    9778:	72a009c0 	movk	w0, #0x4e, lsl #16
    977c:	b9004be0 	str	w0, [sp, #72]
    9780:	17fffda2 	b	8e08 <fwp_write+0x5a8>
    9784:	528005a1 	mov	w1, #0x2d                  	// #45
    9788:	eb1603e2 	negs	x2, x22
    978c:	da1803e3 	ngc	x3, x24
    9790:	910027e0 	add	x0, sp, #0x9
    9794:	910023f3 	add	x19, sp, #0x8
    9798:	390023e1 	strb	w1, [sp, #8]
    979c:	97ffe581 	bl	2da0 <fwp_fmt_u128>
    97a0:	17ffffd4 	b	96f0 <fwp_write+0xe90>
    97a4:	aa1703e2 	mov	x2, x23
    97a8:	aa1a03e3 	mov	x3, x26
    97ac:	aa1603e0 	mov	x0, x22
    97b0:	aa1803e1 	mov	x1, x24
    97b4:	940005bb 	bl	aea0 <__divti3>
    97b8:	aa0003e2 	mov	x2, x0
    97bc:	aa0103e3 	mov	x3, x1
    97c0:	b7f80201 	tbnz	x1, #63, 9800 <fwp_write+0xfa0>
    97c4:	910023f3 	add	x19, sp, #0x8
    97c8:	aa1303e0 	mov	x0, x19
    97cc:	97ffe575 	bl	2da0 <fwp_fmt_u128>
    97d0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    97d4:	91104339 	add	x25, x25, #0x410
    97d8:	910123f5 	add	x21, sp, #0x48
    97dc:	aa1303e4 	mov	x4, x19
    97e0:	aa1503e0 	mov	x0, x21
    97e4:	d0000003 	adrp	x3, b000 <__divti3+0x160>
    97e8:	f8616b25 	ldr	x5, [x25, x1]
    97ec:	9135e063 	add	x3, x3, #0xd78
    97f0:	d2804002 	mov	x2, #0x200                 	// #512
    97f4:	52800041 	mov	w1, #0x2                   	// #2
    97f8:	97ffe3ae 	bl	26b0 <__sprintf_chk@plt>
    97fc:	17ffffc5 	b	9710 <fwp_write+0xeb0>
    9800:	528005a4 	mov	w4, #0x2d                  	// #45
    9804:	eb0003e2 	negs	x2, x0
    9808:	da0103e3 	ngc	x3, x1
    980c:	910027e0 	add	x0, sp, #0x9
    9810:	910023f3 	add	x19, sp, #0x8
    9814:	390023e4 	strb	w4, [sp, #8]
    9818:	97ffe562 	bl	2da0 <fwp_fmt_u128>
    981c:	17ffffed 	b	97d0 <fwp_write+0xf70>
    9820:	f9013bf5 	str	x21, [sp, #624]
    9824:	f9013ff6 	str	x22, [sp, #632]
    9828:	f90143f7 	str	x23, [sp, #640]
    982c:	f90147f8 	str	x24, [sp, #648]
    9830:	f9014bf9 	str	x25, [sp, #656]
    9834:	f9014ffa 	str	x26, [sp, #664]
    9838:	f90153fb 	str	x27, [sp, #672]
    983c:	f90157fc 	str	x28, [sp, #680]
    9840:	fd015be8 	str	d8, [sp, #688]
    9844:	fd015fe9 	str	d9, [sp, #696]
    9848:	97ffe3f2 	bl	2810 <__stack_chk_fail@plt>
    984c:	d503201f 	nop

0000000000009850 <fwp_main_thread>:
    9850:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9854:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9858:	91190001 	add	x1, x0, #0x640
    985c:	910003fd 	mov	x29, sp
    9860:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9864:	f947f400 	ldr	x0, [x0, #4072]
    9868:	a90153f3 	stp	x19, x20, [sp, #16]
    986c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9870:	a90363f7 	stp	x23, x24, [sp, #48]
    9874:	a9046bf9 	stp	x25, x26, [sp, #64]
    9878:	a90573fb 	stp	x27, x28, [sp, #80]
    987c:	d105c3ff 	sub	sp, sp, #0x170
    9880:	b953a421 	ldr	w1, [x1, #5028]
    9884:	f9400002 	ldr	x2, [x0]
    9888:	f81f83a2 	stur	x2, [x29, #-8]
    988c:	d2800002 	mov	x2, #0x0                   	// #0
    9890:	34006421 	cbz	w1, a514 <fwp_main_thread+0xcc4>
    9894:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9898:	91190000 	add	x0, x0, #0x640
    989c:	b953a800 	ldr	w0, [x0, #5032]
    98a0:	35006320 	cbnz	w0, a504 <fwp_main_thread+0xcb4>
    98a4:	f00000a0 	adrp	x0, 20000 <__data_start>
    98a8:	f00000a2 	adrp	x2, 20000 <__data_start>
    98ac:	9101801a 	add	x26, x0, #0x60
    98b0:	91118042 	add	x2, x2, #0x460
    98b4:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    98b8:	d2a00024 	mov	x4, #0x10000               	// #65536
    98bc:	d10383b3 	sub	x19, x29, #0xe0
    98c0:	d103e3b9 	sub	x25, x29, #0xf8
    98c4:	aa1303e0 	mov	x0, x19
    98c8:	d2800001 	mov	x1, #0x0                   	// #0
    98cc:	f81203a2 	stur	x2, [x29, #-224]
    98d0:	b81283bf 	stur	wzr, [x29, #-216]
    98d4:	f81303a4 	stur	x4, [x29, #-208]
    98d8:	a90a0f59 	stp	x25, x3, [x26, #160]
    98dc:	97ffe365 	bl	2670 <sigaltstack@plt>
    98e0:	3500a4c0 	cbnz	w0, ad78 <fwp_main_thread+0x1528>
    98e4:	4f000400 	movi	v0.4s, #0x0
    98e8:	d10263a0 	sub	x0, x29, #0x98
    98ec:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    98f0:	9100c021 	add	x1, x1, #0x30
    98f4:	f81603a1 	stur	x1, [x29, #-160]
    98f8:	52800082 	mov	w2, #0x4                   	// #4
    98fc:	72a10002 	movk	w2, #0x800, lsl #16
    9900:	d10283b5 	sub	x21, x29, #0xa0
    9904:	3d802000 	str	q0, [x0, #128]
    9908:	b81e83a2 	stur	w2, [x29, #-24]
    990c:	ad000000 	stp	q0, q0, [x0]
    9910:	ad010000 	stp	q0, q0, [x0, #32]
    9914:	ad020000 	stp	q0, q0, [x0, #64]
    9918:	ad030000 	stp	q0, q0, [x0, #96]
    991c:	97ffe3ad 	bl	27d0 <sigemptyset@plt>
    9920:	3500a2c0 	cbnz	w0, ad78 <fwp_main_thread+0x1528>
    9924:	aa1503e1 	mov	x1, x21
    9928:	d2800002 	mov	x2, #0x0                   	// #0
    992c:	52800160 	mov	w0, #0xb                   	// #11
    9930:	97ffe3c0 	bl	2830 <sigaction@plt>
    9934:	3500a220 	cbnz	w0, ad78 <fwp_main_thread+0x1528>
    9938:	aa1503e1 	mov	x1, x21
    993c:	d2800002 	mov	x2, #0x0                   	// #0
    9940:	528000e0 	mov	w0, #0x7                   	// #7
    9944:	97ffe3bb 	bl	2830 <sigaction@plt>
    9948:	3500a180 	cbnz	w0, ad78 <fwp_main_thread+0x1528>
    994c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9950:	9119001b 	add	x27, x0, #0x640
    9954:	52800037 	mov	w23, #0x1                   	// #1
    9958:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    995c:	910cc000 	add	x0, x0, #0x330
    9960:	b9013357 	str	w23, [x26, #304]
    9964:	fd4a1360 	ldr	d0, [x27, #5152]
    9968:	7e61d800 	ucvtf	d0, d0
    996c:	fd00a740 	str	d0, [x26, #328]
    9970:	94000708 	bl	b590 <atexit>
    9974:	35009fc0 	cbnz	w0, ad6c <fwp_main_thread+0x151c>
    9978:	b943cb40 	ldr	w0, [x26, #968]
    997c:	34002360 	cbz	w0, 9de8 <fwp_main_thread+0x598>
    9980:	f00000a0 	adrp	x0, 20000 <__data_start>
    9984:	91018015 	add	x21, x0, #0x60
    9988:	f9404eb4 	ldr	x20, [x21, #152]
    998c:	b4000c54 	cbz	x20, 9b14 <fwp_main_thread+0x2c4>
    9990:	aa1403f3 	mov	x19, x20
    9994:	91010297 	add	x23, x20, #0x40
    9998:	39414a98 	ldrb	w24, [x20, #82]
    999c:	52800036 	mov	w22, #0x1                   	// #1
    99a0:	39014a96 	strb	w22, [x20, #82]
    99a4:	f9401680 	ldr	x0, [x20, #40]
    99a8:	b4000620 	cbz	x0, 9a6c <fwp_main_thread+0x21c>
    99ac:	f9403281 	ldr	x1, [x20, #96]
    99b0:	39414680 	ldrb	w0, [x20, #81]
    99b4:	b4000e81 	cbz	x1, 9b84 <fwp_main_thread+0x334>
    99b8:	36000d40 	tbz	w0, #0, 9b60 <fwp_main_thread+0x310>
    99bc:	39414a62 	ldrb	w2, [x19, #82]
    99c0:	f9402281 	ldr	x1, [x20, #64]
    99c4:	370010c2 	tbnz	w2, #0, 9bdc <fwp_main_thread+0x38c>
    99c8:	f9403260 	ldr	x0, [x19, #96]
    99cc:	a911fe77 	stp	x23, xzr, [x19, #280]
    99d0:	f9009661 	str	x1, [x19, #296]
    99d4:	b4000041 	cbz	x1, 99dc <fwp_main_thread+0x18c>
    99d8:	f9009033 	str	x19, [x1, #288]
    99dc:	f9002293 	str	x19, [x20, #64]
    99e0:	b4000100 	cbz	x0, 9a00 <fwp_main_thread+0x1b0>
    99e4:	f94096a1 	ldr	x1, [x21, #296]
    99e8:	39015676 	strb	w22, [x19, #85]
    99ec:	f9003660 	str	x0, [x19, #104]
    99f0:	a910867f 	stp	xzr, x1, [x19, #264]
    99f4:	b4000041 	cbz	x1, 99fc <fwp_main_thread+0x1ac>
    99f8:	f9008433 	str	x19, [x1, #264]
    99fc:	f90096b3 	str	x19, [x21, #296]
    9a00:	39015a7f 	strb	wzr, [x19, #86]
    9a04:	97fff374 	bl	67d4 <fwp_block>
    9a08:	f9408e62 	ldr	x2, [x19, #280]
    9a0c:	b4000142 	cbz	x2, 9a34 <fwp_main_thread+0x1e4>
    9a10:	a9520261 	ldp	x1, x0, [x19, #288]
    9a14:	b4000e01 	cbz	x1, 9bd4 <fwp_main_thread+0x384>
    9a18:	f9009420 	str	x0, [x1, #296]
    9a1c:	f9409660 	ldr	x0, [x19, #296]
    9a20:	b4000040 	cbz	x0, 9a28 <fwp_main_thread+0x1d8>
    9a24:	f9009001 	str	x1, [x0, #288]
    9a28:	91080260 	add	x0, x19, #0x200
    9a2c:	f900967f 	str	xzr, [x19, #296]
    9a30:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9a34:	39415660 	ldrb	w0, [x19, #85]
    9a38:	f9404ea1 	ldr	x1, [x21, #152]
    9a3c:	36000c80 	tbz	w0, #0, 9bcc <fwp_main_thread+0x37c>
    9a40:	a9508262 	ldp	x2, x0, [x19, #264]
    9a44:	b4000d82 	cbz	x2, 9bf4 <fwp_main_thread+0x3a4>
    9a48:	f9008840 	str	x0, [x2, #272]
    9a4c:	b4000040 	cbz	x0, 9a54 <fwp_main_thread+0x204>
    9a50:	f9008402 	str	x2, [x0, #264]
    9a54:	91080260 	add	x0, x19, #0x200
    9a58:	3901567f 	strb	wzr, [x19, #85]
    9a5c:	aa0103f3 	mov	x19, x1
    9a60:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9a64:	f9401680 	ldr	x0, [x20, #40]
    9a68:	b5fffa20 	cbnz	x0, 99ac <fwp_main_thread+0x15c>
    9a6c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a70:	91018000 	add	x0, x0, #0x60
    9a74:	39014a98 	strb	w24, [x20, #82]
    9a78:	f941d400 	ldr	x0, [x0, #936]
    9a7c:	b4000520 	cbz	x0, 9b20 <fwp_main_thread+0x2d0>
    9a80:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a84:	91018000 	add	x0, x0, #0x60
    9a88:	f941f001 	ldr	x1, [x0, #992]
    9a8c:	b903d81f 	str	wzr, [x0, #984]
    9a90:	eb13003f 	cmp	x1, x19
    9a94:	54000641 	b.ne	9b5c <fwp_main_thread+0x30c>  // b.any
    9a98:	b4000bd3 	cbz	x19, 9c10 <fwp_main_thread+0x3c0>
    9a9c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9aa0:	91018000 	add	x0, x0, #0x60
    9aa4:	52800021 	mov	w1, #0x1                   	// #1
    9aa8:	39014a61 	strb	w1, [x19, #82]
    9aac:	f941c005 	ldr	x5, [x0, #896]
    9ab0:	b4000b05 	cbz	x5, 9c10 <fwp_main_thread+0x3c0>
    9ab4:	394140a0 	ldrb	w0, [x5, #80]
    9ab8:	37000060 	tbnz	w0, #0, 9ac4 <fwp_main_thread+0x274>
    9abc:	aa0503e0 	mov	x0, x5
    9ac0:	97ffe6ec 	bl	3670 <fwp_cancel_tree.part.0>
    9ac4:	f9409ca5 	ldr	x5, [x5, #312]
    9ac8:	b5ffff65 	cbnz	x5, 9ab4 <fwp_main_thread+0x264>
    9acc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ad0:	91018014 	add	x20, x0, #0x60
    9ad4:	52800035 	mov	w21, #0x1                   	// #1
    9ad8:	f9402a60 	ldr	x0, [x19, #80]
    9adc:	f2001c1f 	tst	x0, #0xff000000ff
    9ae0:	540000e1 	b.ne	9afc <fwp_main_thread+0x2ac>  // b.any
    9ae4:	f9406280 	ldr	x0, [x20, #192]
    9ae8:	39015275 	strb	w21, [x19, #84]
    9aec:	f900827f 	str	xzr, [x19, #256]
    9af0:	b4000860 	cbz	x0, 9bfc <fwp_main_thread+0x3ac>
    9af4:	f9008013 	str	x19, [x0, #256]
    9af8:	f9006293 	str	x19, [x20, #192]
    9afc:	97fff336 	bl	67d4 <fwp_block>
    9b00:	97fff2c8 	bl	6620 <fwp_free_zombie>
    9b04:	f941c280 	ldr	x0, [x20, #896]
    9b08:	b4000840 	cbz	x0, 9c10 <fwp_main_thread+0x3c0>
    9b0c:	f941f293 	ldr	x19, [x20, #992]
    9b10:	17fffff2 	b	9ad8 <fwp_main_thread+0x288>
    9b14:	f941d6a0 	ldr	x0, [x21, #936]
    9b18:	b5000760 	cbnz	x0, 9c04 <fwp_main_thread+0x3b4>
    9b1c:	d2800013 	mov	x19, #0x0                   	// #0
    9b20:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b24:	91018014 	add	x20, x0, #0x60
    9b28:	f941de80 	ldr	x0, [x20, #952]
    9b2c:	b5fffaa0 	cbnz	x0, 9a80 <fwp_main_thread+0x230>
    9b30:	f941d280 	ldr	x0, [x20, #928]
    9b34:	97ffec37 	bl	4c10 <fwp_mem_free>
    9b38:	f901d29f 	str	xzr, [x20, #928]
    9b3c:	f901da9f 	str	xzr, [x20, #944]
    9b40:	f941f280 	ldr	x0, [x20, #992]
    9b44:	b4009953 	cbz	x19, ae6c <fwp_main_thread+0x161c>
    9b48:	f900567f 	str	xzr, [x19, #168]
    9b4c:	f9005e7f 	str	xzr, [x19, #184]
    9b50:	b903da9f 	str	wzr, [x20, #984]
    9b54:	eb00027f 	cmp	x19, x0
    9b58:	54fffa20 	b.eq	9a9c <fwp_main_thread+0x24c>  // b.none
    9b5c:	97ffe341 	bl	2860 <abort@plt>
    9b60:	97ffe768 	bl	3900 <fwp_now_ns>
    9b64:	f9403281 	ldr	x1, [x20, #96]
    9b68:	eb01001f 	cmp	x0, x1
    9b6c:	540000ab 	b.lt	9b80 <fwp_main_thread+0x330>  // b.tstop
    9b70:	39414280 	ldrb	w0, [x20, #80]
    9b74:	37000060 	tbnz	w0, #0, 9b80 <fwp_main_thread+0x330>
    9b78:	aa1403e0 	mov	x0, x20
    9b7c:	97ffe6bd 	bl	3670 <fwp_cancel_tree.part.0>
    9b80:	39414680 	ldrb	w0, [x20, #81]
    9b84:	39414a62 	ldrb	w2, [x19, #82]
    9b88:	3707f1c0 	tbnz	w0, #0, 99c0 <fwp_main_thread+0x170>
    9b8c:	f9403280 	ldr	x0, [x20, #96]
    9b90:	370001a2 	tbnz	w2, #0, 9bc4 <fwp_main_thread+0x374>
    9b94:	f9403261 	ldr	x1, [x19, #96]
    9b98:	b4000161 	cbz	x1, 9bc4 <fwp_main_thread+0x374>
    9b9c:	b4008c60 	cbz	x0, ad28 <fwp_main_thread+0x14d8>
    9ba0:	eb01001f 	cmp	x0, x1
    9ba4:	9a81d000 	csel	x0, x0, x1, le
    9ba8:	f9402281 	ldr	x1, [x20, #64]
    9bac:	a911fe77 	stp	x23, xzr, [x19, #280]
    9bb0:	f9009661 	str	x1, [x19, #296]
    9bb4:	b4000041 	cbz	x1, 9bbc <fwp_main_thread+0x36c>
    9bb8:	f9009033 	str	x19, [x1, #288]
    9bbc:	f9002293 	str	x19, [x20, #64]
    9bc0:	17ffff89 	b	99e4 <fwp_main_thread+0x194>
    9bc4:	f9402281 	ldr	x1, [x20, #64]
    9bc8:	17ffff81 	b	99cc <fwp_main_thread+0x17c>
    9bcc:	aa0103f3 	mov	x19, x1
    9bd0:	17ffff75 	b	99a4 <fwp_main_thread+0x154>
    9bd4:	f9000040 	str	x0, [x2]
    9bd8:	17ffff92 	b	9a20 <fwp_main_thread+0x1d0>
    9bdc:	a911fe77 	stp	x23, xzr, [x19, #280]
    9be0:	f9009661 	str	x1, [x19, #296]
    9be4:	b4000041 	cbz	x1, 9bec <fwp_main_thread+0x39c>
    9be8:	f9009033 	str	x19, [x1, #288]
    9bec:	f9002293 	str	x19, [x20, #64]
    9bf0:	17ffff84 	b	9a00 <fwp_main_thread+0x1b0>
    9bf4:	f90096a0 	str	x0, [x21, #296]
    9bf8:	17ffff95 	b	9a4c <fwp_main_thread+0x1fc>
    9bfc:	f9006693 	str	x19, [x20, #200]
    9c00:	17ffffbe 	b	9af8 <fwp_main_thread+0x2a8>
    9c04:	f941f2a0 	ldr	x0, [x21, #992]
    9c08:	b903dabf 	str	wzr, [x21, #984]
    9c0c:	b5fffa80 	cbnz	x0, 9b5c <fwp_main_thread+0x30c>
    9c10:	97fff284 	bl	6620 <fwp_free_zombie>
    9c14:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c18:	91018015 	add	x21, x0, #0x60
    9c1c:	f94066a0 	ldr	x0, [x21, #200]
    9c20:	b5fff9e0 	cbnz	x0, 9b5c <fwp_main_thread+0x30c>
    9c24:	f94096a0 	ldr	x0, [x21, #296]
    9c28:	b5fff9a0 	cbnz	x0, 9b5c <fwp_main_thread+0x30c>
    9c2c:	b94172a0 	ldr	w0, [x21, #368]
    9c30:	340001c0 	cbz	w0, 9c68 <fwp_main_thread+0x418>
    9c34:	93407c14 	sxtw	x20, w0
    9c38:	51000400 	sub	w0, w0, #0x1
    9c3c:	d1000a94 	sub	x20, x20, #0x2
    9c40:	910602b6 	add	x22, x21, #0x180
    9c44:	cb204294 	sub	x20, x20, w0, uxtw
    9c48:	93407c13 	sxtw	x19, w0
    9c4c:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9c50:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9c54:	b90172b3 	str	w19, [x21, #368]
    9c58:	d1000673 	sub	x19, x19, #0x1
    9c5c:	97ffe335 	bl	2930 <munmap@plt>
    9c60:	eb14027f 	cmp	x19, x20
    9c64:	54ffff41 	b.ne	9c4c <fwp_main_thread+0x3fc>  // b.any
    9c68:	f00000a4 	adrp	x4, 20000 <__data_start>
    9c6c:	91004080 	add	x0, x4, #0x10
    9c70:	b9403000 	ldr	w0, [x0, #48]
    9c74:	37f800c0 	tbnz	w0, #31, 9c8c <fwp_main_thread+0x43c>
    9c78:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9c7c:	f91f7c24 	str	x4, [x1, #16120]
    9c80:	97ffe2e8 	bl	2820 <close@plt>
    9c84:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c88:	f95f7c04 	ldr	x4, [x0, #16120]
    9c8c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c90:	91018000 	add	x0, x0, #0x60
    9c94:	91004084 	add	x4, x4, #0x10
    9c98:	12800001 	mov	w1, #0xffffffff            	// #-1
    9c9c:	d2800013 	mov	x19, #0x0                   	// #0
    9ca0:	f941f415 	ldr	x21, [x0, #1000]
    9ca4:	b9003081 	str	w1, [x4, #48]
    9ca8:	f941f814 	ldr	x20, [x0, #1008]
    9cac:	b4000175 	cbz	x21, 9cd8 <fwp_main_thread+0x488>
    9cb0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    9cb4:	b40000c0 	cbz	x0, 9ccc <fwp_main_thread+0x47c>
    9cb8:	f9400001 	ldr	x1, [x0]
    9cbc:	b5fff501 	cbnz	x1, 9b5c <fwp_main_thread+0x30c>
    9cc0:	f9400401 	ldr	x1, [x0, #8]
    9cc4:	b5fff4c1 	cbnz	x1, 9b5c <fwp_main_thread+0x30c>
    9cc8:	97ffebd2 	bl	4c10 <fwp_mem_free>
    9ccc:	91000673 	add	x19, x19, #0x1
    9cd0:	eb1302bf 	cmp	x21, x19
    9cd4:	54fffee1 	b.ne	9cb0 <fwp_main_thread+0x460>  // b.any
    9cd8:	aa1403e0 	mov	x0, x20
    9cdc:	97ffebcd 	bl	4c10 <fwp_mem_free>
    9ce0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ce4:	91018000 	add	x0, x0, #0x60
    9ce8:	f941f013 	ldr	x19, [x0, #992]
    9cec:	f901f41f 	str	xzr, [x0, #1000]
    9cf0:	f901f81f 	str	xzr, [x0, #1008]
    9cf4:	b40001f3 	cbz	x19, 9d30 <fwp_main_thread+0x4e0>
    9cf8:	f9401661 	ldr	x1, [x19, #40]
    9cfc:	b5fff301 	cbnz	x1, 9b5c <fwp_main_thread+0x30c>
    9d00:	f9405661 	ldr	x1, [x19, #168]
    9d04:	b5fff2c1 	cbnz	x1, 9b5c <fwp_main_thread+0x30c>
    9d08:	f941d401 	ldr	x1, [x0, #936]
    9d0c:	b5fff281 	cbnz	x1, 9b5c <fwp_main_thread+0x30c>
    9d10:	f941dc00 	ldr	x0, [x0, #952]
    9d14:	b5fff240 	cbnz	x0, 9b5c <fwp_main_thread+0x30c>
    9d18:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9d1c:	f0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    9d20:	91118000 	add	x0, x0, #0x460
    9d24:	97ffe2af 	bl	27e0 <memset@plt>
    9d28:	aa1303e0 	mov	x0, x19
    9d2c:	97ffebb9 	bl	4c10 <fwp_mem_free>
    9d30:	f00000a1 	adrp	x1, 20000 <__data_start>
    9d34:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9d38:	91018026 	add	x6, x1, #0x60
    9d3c:	91190000 	add	x0, x0, #0x640
    9d40:	3dc01821 	ldr	q1, [x1, #96]
    9d44:	d0000002 	adrp	x2, b000 <__divti3+0x160>
    9d48:	3dc004c2 	ldr	q2, [x6, #16]
    9d4c:	9137e042 	add	x2, x2, #0xdf8
    9d50:	fd4a1000 	ldr	d0, [x0, #5152]
    9d54:	52800041 	mov	w1, #0x2                   	// #2
    9d58:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    9d5c:	fd40a4c1 	ldr	d1, [x6, #328]
    9d60:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9d64:	f947e800 	ldr	x0, [x0, #4048]
    9d68:	7e61d800 	ucvtf	d0, d0
    9d6c:	a95390c3 	ldp	x3, x4, [x6, #312]
    9d70:	f9004cdf 	str	xzr, [x6, #152]
    9d74:	f9400000 	ldr	x0, [x0]
    9d78:	1e613801 	fsub	d1, d0, d1
    9d7c:	f940acc5 	ldr	x5, [x6, #344]
    9d80:	b90130df 	str	wzr, [x6, #304]
    9d84:	5ef1b842 	addp	d2, v2.2d
    9d88:	fd40a8c0 	ldr	d0, [x6, #336]
    9d8c:	f901f0df 	str	xzr, [x6, #992]
    9d90:	fd0058c2 	str	d2, [x6, #176]
    9d94:	97ffe2bb 	bl	2880 <__fprintf_chk@plt>
    9d98:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9d9c:	f947ec00 	ldr	x0, [x0, #4056]
    9da0:	f9400000 	ldr	x0, [x0]
    9da4:	97ffe2e7 	bl	2940 <fflush@plt>
    9da8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9dac:	f947f400 	ldr	x0, [x0, #4072]
    9db0:	f85f83a2 	ldur	x2, [x29, #-8]
    9db4:	f9400001 	ldr	x1, [x0]
    9db8:	eb010042 	subs	x2, x2, x1
    9dbc:	d2800001 	mov	x1, #0x0                   	// #0
    9dc0:	54007fe1 	b.ne	adbc <fwp_main_thread+0x156c>  // b.any
    9dc4:	910003bf 	mov	sp, x29
    9dc8:	d2800000 	mov	x0, #0x0                   	// #0
    9dcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    9dd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    9dd8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9ddc:	a94573fb 	ldp	x27, x28, [sp, #80]
    9de0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9de4:	d65f03c0 	ret
    9de8:	f941cb42 	ldr	x2, [x26, #912]
    9dec:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0xd0>
    9df0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9df4:	913c0000 	add	x0, x0, #0xf00
    9df8:	913b4021 	add	x1, x1, #0xed0
    9dfc:	d2800014 	mov	x20, #0x0                   	// #0
    9e00:	d2804018 	mov	x24, #0x200                 	// #512
    9e04:	d2800016 	mov	x22, #0x0                   	// #0
    9e08:	a93087a2 	stp	x2, x1, [x29, #-248]
    9e0c:	a931ffb3 	stp	x19, xzr, [x29, #-232]
    9e10:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9e14:	f901cb59 	str	x25, [x26, #912]
    9e18:	f100071a 	subs	x26, x24, #0x1
    9e1c:	aa1503e1 	mov	x1, x21
    9e20:	da1f02dc 	sbc	x28, x22, xzr
    9e24:	52800020 	mov	w0, #0x1                   	// #1
    9e28:	f81283ba 	stur	x26, [x29, #-216]
    9e2c:	aa1a03f8 	mov	x24, x26
    9e30:	a93653ba 	stp	x26, x20, [x29, #-160]
    9e34:	97ffee77 	bl	5810 <fwp_data.part.0.constprop.0>
    9e38:	aa0003f4 	mov	x20, x0
    9e3c:	f949db62 	ldr	x2, [x27, #5040]
    9e40:	aa1c03f6 	mov	x22, x28
    9e44:	f949ef60 	ldr	x0, [x27, #5080]
    9e48:	cb020282 	sub	x2, x20, x2
    9e4c:	eb00405f 	cmp	x2, x0, lsl #16
    9e50:	54000302 	b.cs	9eb0 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9e54:	d350fc40 	lsr	x0, x2, #16
    9e58:	f949ff63 	ldr	x3, [x27, #5112]
    9e5c:	8b000800 	add	x0, x0, x0, lsl #2
    9e60:	d37df001 	lsl	x1, x0, #3
    9e64:	8b010060 	add	x0, x3, x1
    9e68:	f9401019 	ldr	x25, [x0, #32]
    9e6c:	b4000239 	cbz	x25, 9eb0 <fwp_main_thread+0x660>
    9e70:	38616861 	ldrb	w1, [x3, x1]
    9e74:	7100083f 	cmp	w1, #0x2
    9e78:	54003360 	b.eq	a4e4 <fwp_main_thread+0xc94>  // b.none
    9e7c:	7100043f 	cmp	w1, #0x1
    9e80:	54000181 	b.ne	9eb0 <fwp_main_thread+0x660>  // b.any
    9e84:	29430003 	ldp	w3, w0, [x0, #24]
    9e88:	92403c41 	and	x1, x2, #0xffff
    9e8c:	9b037c21 	mul	x1, x1, x3
    9e90:	d360fc21 	lsr	x1, x1, #32
    9e94:	eb00003f 	cmp	x1, x0
    9e98:	540000c2 	b.cs	9eb0 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9e9c:	8b010339 	add	x25, x25, x1
    9ea0:	39400320 	ldrb	w0, [x25]
    9ea4:	7103fc1f 	cmp	w0, #0xff
    9ea8:	54003280 	b.eq	a4f8 <fwp_main_thread+0xca8>  // b.none
    9eac:	39000337 	strb	w23, [x25]
    9eb0:	f81203b4 	stur	x20, [x29, #-224]
    9eb4:	aa1c0340 	orr	x0, x26, x28
    9eb8:	b5fffb00 	cbnz	x0, 9e18 <fwp_main_thread+0x5c8>
    9ebc:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0xa40>
    9ec0:	d10303a1 	sub	x1, x29, #0xc0
    9ec4:	f85083a3 	ldur	x3, [x29, #-248]
    9ec8:	3dc16000 	ldr	q0, [x0, #1408]
    9ecc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ed0:	91018002 	add	x2, x0, #0x60
    9ed4:	52800020 	mov	w0, #0x1                   	// #1
    9ed8:	3c9403a0 	stur	q0, [x29, #-192]
    9edc:	f901c843 	str	x3, [x2, #912]
    9ee0:	97ffee4c 	bl	5810 <fwp_data.part.0.constprop.0>
    9ee4:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9ee8:	91190022 	add	x2, x1, #0x640
    9eec:	aa0003f7 	mov	x23, x0
    9ef0:	f949d841 	ldr	x1, [x2, #5040]
    9ef4:	f949ec40 	ldr	x0, [x2, #5080]
    9ef8:	cb0102e1 	sub	x1, x23, x1
    9efc:	eb00403f 	cmp	x1, x0, lsl #16
    9f00:	54000322 	b.cs	9f64 <fwp_main_thread+0x714>  // b.hs, b.nlast
    9f04:	d350fc20 	lsr	x0, x1, #16
    9f08:	f949fc43 	ldr	x3, [x2, #5112]
    9f0c:	8b000800 	add	x0, x0, x0, lsl #2
    9f10:	d37df002 	lsl	x2, x0, #3
    9f14:	8b020060 	add	x0, x3, x2
    9f18:	f9401016 	ldr	x22, [x0, #32]
    9f1c:	b4000256 	cbz	x22, 9f64 <fwp_main_thread+0x714>
    9f20:	38626862 	ldrb	w2, [x3, x2]
    9f24:	7100085f 	cmp	w2, #0x2
    9f28:	54006ee0 	b.eq	ad04 <fwp_main_thread+0x14b4>  // b.none
    9f2c:	7100045f 	cmp	w2, #0x1
    9f30:	540001a1 	b.ne	9f64 <fwp_main_thread+0x714>  // b.any
    9f34:	29430002 	ldp	w2, w0, [x0, #24]
    9f38:	92403c21 	and	x1, x1, #0xffff
    9f3c:	9b027c21 	mul	x1, x1, x2
    9f40:	d360fc21 	lsr	x1, x1, #32
    9f44:	eb00003f 	cmp	x1, x0
    9f48:	540000e2 	b.cs	9f64 <fwp_main_thread+0x714>  // b.hs, b.nlast
    9f4c:	8b0102d6 	add	x22, x22, x1
    9f50:	394002c0 	ldrb	w0, [x22]
    9f54:	7103fc1f 	cmp	w0, #0xff
    9f58:	54006ec0 	b.eq	ad30 <fwp_main_thread+0x14e0>  // b.none
    9f5c:	52800020 	mov	w0, #0x1                   	// #1
    9f60:	390002c0 	strb	w0, [x22]
    9f64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9f68:	aa1503e1 	mov	x1, x21
    9f6c:	52800020 	mov	w0, #0x1                   	// #1
    9f70:	a9365fa2 	stp	x2, x23, [x29, #-160]
    9f74:	97ffee27 	bl	5810 <fwp_data.part.0.constprop.0>
    9f78:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9f7c:	91190022 	add	x2, x1, #0x640
    9f80:	aa0003f6 	mov	x22, x0
    9f84:	f949d841 	ldr	x1, [x2, #5040]
    9f88:	f949ec40 	ldr	x0, [x2, #5080]
    9f8c:	cb0102c1 	sub	x1, x22, x1
    9f90:	eb00403f 	cmp	x1, x0, lsl #16
    9f94:	54000322 	b.cs	9ff8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    9f98:	d350fc20 	lsr	x0, x1, #16
    9f9c:	f949fc43 	ldr	x3, [x2, #5112]
    9fa0:	8b000800 	add	x0, x0, x0, lsl #2
    9fa4:	d37df002 	lsl	x2, x0, #3
    9fa8:	8b020060 	add	x0, x3, x2
    9fac:	f9401015 	ldr	x21, [x0, #32]
    9fb0:	b4000255 	cbz	x21, 9ff8 <fwp_main_thread+0x7a8>
    9fb4:	38626862 	ldrb	w2, [x3, x2]
    9fb8:	7100085f 	cmp	w2, #0x2
    9fbc:	540069e0 	b.eq	acf8 <fwp_main_thread+0x14a8>  // b.none
    9fc0:	7100045f 	cmp	w2, #0x1
    9fc4:	540001a1 	b.ne	9ff8 <fwp_main_thread+0x7a8>  // b.any
    9fc8:	29430002 	ldp	w2, w0, [x0, #24]
    9fcc:	92403c21 	and	x1, x1, #0xffff
    9fd0:	9b027c21 	mul	x1, x1, x2
    9fd4:	d360fc21 	lsr	x1, x1, #32
    9fd8:	eb00003f 	cmp	x1, x0
    9fdc:	540000e2 	b.cs	9ff8 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    9fe0:	8b0102b5 	add	x21, x21, x1
    9fe4:	394002a0 	ldrb	w0, [x21]
    9fe8:	7103fc1f 	cmp	w0, #0xff
    9fec:	54006a80 	b.eq	ad3c <fwp_main_thread+0x14ec>  // b.none
    9ff0:	52800020 	mov	w0, #0x1                   	// #1
    9ff4:	390002a0 	strb	w0, [x21]
    9ff8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9ffc:	d102c3a1 	sub	x1, x29, #0xb0
    a000:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a004:	52800020 	mov	w0, #0x1                   	// #1
    a008:	a9355ba2 	stp	x2, x22, [x29, #-176]
    a00c:	97ffee01 	bl	5810 <fwp_data.part.0.constprop.0>
    a010:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a014:	91190022 	add	x2, x1, #0x640
    a018:	aa0003fb 	mov	x27, x0
    a01c:	f949d841 	ldr	x1, [x2, #5040]
    a020:	f949ec40 	ldr	x0, [x2, #5080]
    a024:	cb010361 	sub	x1, x27, x1
    a028:	eb00403f 	cmp	x1, x0, lsl #16
    a02c:	54000322 	b.cs	a090 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a030:	d350fc20 	lsr	x0, x1, #16
    a034:	f949fc43 	ldr	x3, [x2, #5112]
    a038:	8b000800 	add	x0, x0, x0, lsl #2
    a03c:	d37df002 	lsl	x2, x0, #3
    a040:	8b020060 	add	x0, x3, x2
    a044:	f9401015 	ldr	x21, [x0, #32]
    a048:	b4000255 	cbz	x21, a090 <fwp_main_thread+0x840>
    a04c:	38626862 	ldrb	w2, [x3, x2]
    a050:	7100085f 	cmp	w2, #0x2
    a054:	540065e0 	b.eq	ad10 <fwp_main_thread+0x14c0>  // b.none
    a058:	7100045f 	cmp	w2, #0x1
    a05c:	540001a1 	b.ne	a090 <fwp_main_thread+0x840>  // b.any
    a060:	29430002 	ldp	w2, w0, [x0, #24]
    a064:	92403c21 	and	x1, x1, #0xffff
    a068:	9b027c21 	mul	x1, x1, x2
    a06c:	d360fc21 	lsr	x1, x1, #32
    a070:	eb00003f 	cmp	x1, x0
    a074:	540000e2 	b.cs	a090 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a078:	8b0102b5 	add	x21, x21, x1
    a07c:	394002a0 	ldrb	w0, [x21]
    a080:	7103fc1f 	cmp	w0, #0xff
    a084:	54006620 	b.eq	ad48 <fwp_main_thread+0x14f8>  // b.none
    a088:	52800020 	mov	w0, #0x1                   	// #1
    a08c:	390002a0 	strb	w0, [x21]
    a090:	b4003eb4 	cbz	x20, a864 <fwp_main_thread+0x1014>
    a094:	d00000a0 	adrp	x0, 20000 <__data_start>
    a098:	9101801c 	add	x28, x0, #0x60
    a09c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0a0:	d00000a4 	adrp	x4, 20000 <__data_start>
    a0a4:	91004098 	add	x24, x4, #0x10
    a0a8:	9100a306 	add	x6, x24, #0x28
    a0ac:	f91f5414 	str	x20, [x0, #16040]
    a0b0:	f91f5804 	str	x4, [x0, #16048]
    a0b4:	f91f5c14 	str	x20, [x0, #16056]
    a0b8:	f91f601b 	str	x27, [x0, #16064]
    a0bc:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a0c0:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a0c4:	91190002 	add	x2, x0, #0x640
    a0c8:	f95f6063 	ldr	x3, [x3, #16064]
    a0cc:	f949d841 	ldr	x1, [x2, #5040]
    a0d0:	f949ec40 	ldr	x0, [x2, #5080]
    a0d4:	cb010061 	sub	x1, x3, x1
    a0d8:	eb00403f 	cmp	x1, x0, lsl #16
    a0dc:	54000422 	b.cs	a160 <fwp_main_thread+0x910>  // b.hs, b.nlast
    a0e0:	d350fc20 	lsr	x0, x1, #16
    a0e4:	f949fc44 	ldr	x4, [x2, #5112]
    a0e8:	8b000800 	add	x0, x0, x0, lsl #2
    a0ec:	d37df002 	lsl	x2, x0, #3
    a0f0:	8b020083 	add	x3, x4, x2
    a0f4:	f9401060 	ldr	x0, [x3, #32]
    a0f8:	b4000340 	cbz	x0, a160 <fwp_main_thread+0x910>
    a0fc:	38626882 	ldrb	w2, [x4, x2]
    a100:	7100085f 	cmp	w2, #0x2
    a104:	540060c0 	b.eq	ad1c <fwp_main_thread+0x14cc>  // b.none
    a108:	7100045f 	cmp	w2, #0x1
    a10c:	540002a1 	b.ne	a160 <fwp_main_thread+0x910>  // b.any
    a110:	29430864 	ldp	w4, w2, [x3, #24]
    a114:	92403c21 	and	x1, x1, #0xffff
    a118:	9b047c21 	mul	x1, x1, x4
    a11c:	d360fc21 	lsr	x1, x1, #32
    a120:	eb02003f 	cmp	x1, x2
    a124:	540001e2 	b.cs	a160 <fwp_main_thread+0x910>  // b.hs, b.nlast
    a128:	8b010000 	add	x0, x0, x1
    a12c:	39400001 	ldrb	w1, [x0]
    a130:	34000181 	cbz	w1, a160 <fwp_main_thread+0x910>
    a134:	d00000a2 	adrp	x2, 20000 <__data_start>
    a138:	91018042 	add	x2, x2, #0x60
    a13c:	b9413043 	ldr	w3, [x2, #304]
    a140:	34000083 	cbz	w3, a150 <fwp_main_thread+0x900>
    a144:	f940ac43 	ldr	x3, [x2, #344]
    a148:	91000463 	add	x3, x3, #0x1
    a14c:	f900ac43 	str	x3, [x2, #344]
    a150:	7103f43f 	cmp	w1, #0xfd
    a154:	54006008 	b.hi	ad54 <fwp_main_thread+0x1504>  // b.pmore
    a158:	11000421 	add	w1, w1, #0x1
    a15c:	39000001 	strb	w1, [x0]
    a160:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a164:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a168:	f9406b83 	ldr	x3, [x28, #208]
    a16c:	f95f5800 	ldr	x0, [x0, #16048]
    a170:	f95f6021 	ldr	x1, [x1, #16064]
    a174:	91004000 	add	x0, x0, #0x10
    a178:	f81203a1 	stur	x1, [x29, #-224]
    a17c:	9100a005 	add	x5, x0, #0x28
    a180:	b9402801 	ldr	w1, [x0, #40]
    a184:	d37be821 	lsl	x1, x1, #5
    a188:	8b010064 	add	x4, x3, x1
    a18c:	f9400c82 	ldr	x2, [x4, #24]
    a190:	b4005fc2 	cbz	x2, ad88 <fwp_main_thread+0x1538>
    a194:	f9400c40 	ldr	x0, [x2, #24]
    a198:	b4004c40 	cbz	x0, ab20 <fwp_main_thread+0x12d0>
    a19c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a1a0:	91190002 	add	x2, x0, #0x640
    a1a4:	f949d841 	ldr	x1, [x2, #5040]
    a1a8:	f949ec40 	ldr	x0, [x2, #5080]
    a1ac:	cb0100c1 	sub	x1, x6, x1
    a1b0:	eb00403f 	cmp	x1, x0, lsl #16
    a1b4:	540003e2 	b.cs	a230 <fwp_main_thread+0x9e0>  // b.hs, b.nlast
    a1b8:	d350fc20 	lsr	x0, x1, #16
    a1bc:	f949fc45 	ldr	x5, [x2, #5112]
    a1c0:	8b000800 	add	x0, x0, x0, lsl #2
    a1c4:	d37df002 	lsl	x2, x0, #3
    a1c8:	8b0200a3 	add	x3, x5, x2
    a1cc:	f9401060 	ldr	x0, [x3, #32]
    a1d0:	b4000300 	cbz	x0, a230 <fwp_main_thread+0x9e0>
    a1d4:	386268a2 	ldrb	w2, [x5, x2]
    a1d8:	7100085f 	cmp	w2, #0x2
    a1dc:	54005180 	b.eq	ac0c <fwp_main_thread+0x13bc>  // b.none
    a1e0:	7100045f 	cmp	w2, #0x1
    a1e4:	54000261 	b.ne	a230 <fwp_main_thread+0x9e0>  // b.any
    a1e8:	29430865 	ldp	w5, w2, [x3, #24]
    a1ec:	92403c21 	and	x1, x1, #0xffff
    a1f0:	9b057c21 	mul	x1, x1, x5
    a1f4:	d360fc21 	lsr	x1, x1, #32
    a1f8:	eb02003f 	cmp	x1, x2
    a1fc:	540001a2 	b.cs	a230 <fwp_main_thread+0x9e0>  // b.hs, b.nlast
    a200:	8b010000 	add	x0, x0, x1
    a204:	39400001 	ldrb	w1, [x0]
    a208:	34000141 	cbz	w1, a230 <fwp_main_thread+0x9e0>
    a20c:	b9413382 	ldr	w2, [x28, #304]
    a210:	34000082 	cbz	w2, a220 <fwp_main_thread+0x9d0>
    a214:	f940af82 	ldr	x2, [x28, #344]
    a218:	91000442 	add	x2, x2, #0x1
    a21c:	f900af82 	str	x2, [x28, #344]
    a220:	7103f43f 	cmp	w1, #0xfd
    a224:	54005468 	b.hi	acb0 <fwp_main_thread+0x1460>  // b.pmore
    a228:	11000421 	add	w1, w1, #0x1
    a22c:	39000001 	strb	w1, [x0]
    a230:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a234:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a238:	52800036 	mov	w22, #0x1                   	// #1
    a23c:	aa0603f7 	mov	x23, x6
    a240:	f91f7833 	str	x19, [x1, #16112]
    a244:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a248:	91190035 	add	x21, x1, #0x640
    a24c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a250:	b93eec16 	str	w22, [x0, #16108]
    a254:	aa0603e0 	mov	x0, x6
    a258:	f91f6433 	str	x19, [x1, #16072]
    a25c:	f91f6826 	str	x6, [x1, #16080]
    a260:	b9400401 	ldr	w1, [x0, #4]
    a264:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a268:	b9400098 	ldr	w24, [x4]
    a26c:	4b010300 	sub	w0, w24, w1
    a270:	b93ee440 	str	w0, [x2, #16100]
    a274:	6b16001f 	cmp	w0, w22
    a278:	1a969007 	csel	w7, w0, w22, ls	// ls = plast
    a27c:	b97eec40 	ldr	w0, [x2, #16108]
    a280:	6b0000ff 	cmp	w7, w0
    a284:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    a288:	b93ee840 	str	w0, [x2, #16104]
    a28c:	6b0000e2 	subs	w2, w7, w0
    a290:	54000180 	b.eq	a2c0 <fwp_main_thread+0xa70>  // b.none
    a294:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a298:	0b000021 	add	w1, w1, w0
    a29c:	b93ef867 	str	w7, [x3, #16120]
    a2a0:	f9400c83 	ldr	x3, [x4, #24]
    a2a4:	d14013a4 	sub	x4, x29, #0x4, lsl #12
    a2a8:	f9400863 	ldr	x3, [x3, #16]
    a2ac:	f95f7884 	ldr	x4, [x4, #16112]
    a2b0:	8b204c80 	add	x0, x4, w0, uxtw #3
    a2b4:	d63f0060 	blr	x3
    a2b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2bc:	b97ef807 	ldr	w7, [x0, #16120]
    a2c0:	f9406b80 	ldr	x0, [x28, #208]
    a2c4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a2c8:	b94002e3 	ldr	w3, [x23]
    a2cc:	aa1703e5 	mov	x5, x23
    a2d0:	2a0703f4 	mov	w20, w7
    a2d4:	aa1703f8 	mov	x24, x23
    a2d8:	f95f783a 	ldr	x26, [x1, #16112]
    a2dc:	8b031419 	add	x25, x0, x3, lsl #5
    a2e0:	f9400f20 	ldr	x0, [x25, #24]
    a2e4:	b40012e0 	cbz	x0, a540 <fwp_main_thread+0xcf0>
    a2e8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a2ec:	b93ed827 	str	w7, [x1, #16088]
    a2f0:	b93ee036 	str	w22, [x1, #16096]
    a2f4:	aa1903f6 	mov	x22, x25
    a2f8:	14000012 	b	a340 <fwp_main_thread+0xaf0>
    a2fc:	f9400001 	ldr	x1, [x0]
    a300:	aa1a03e0 	mov	x0, x26
    a304:	d63f0020 	blr	x1
    a308:	aa0003f9 	mov	x25, x0
    a30c:	aa1703e0 	mov	x0, x23
    a310:	97ffef50 	bl	6050 <fwp_closure_drop>
    a314:	6b14027f 	cmp	w19, w20
    a318:	54000ce0 	b.eq	a4b4 <fwp_main_thread+0xc64>  // b.none
    a31c:	f9406b80 	ldr	x0, [x28, #208]
    a320:	8b334f5a 	add	x26, x26, w19, uxtw #3
    a324:	b9400323 	ldr	w3, [x25]
    a328:	4b180374 	sub	w20, w27, w24
    a32c:	aa1903e5 	mov	x5, x25
    a330:	8b031416 	add	x22, x0, x3, lsl #5
    a334:	f9400ec0 	ldr	x0, [x22, #24]
    a338:	b4000fc0 	cbz	x0, a530 <fwp_main_thread+0xce0>
    a33c:	aa1903f7 	mov	x23, x25
    a340:	b94004a1 	ldr	w1, [x5, #4]
    a344:	b94002d8 	ldr	w24, [x22]
    a348:	0b14003b 	add	w27, w1, w20
    a34c:	6b1b031f 	cmp	w24, w27
    a350:	540029e8 	b.hi	a88c <fwp_main_thread+0x103c>  // b.pmore
    a354:	7100003f 	cmp	w1, #0x0
    a358:	4b010313 	sub	w19, w24, w1
    a35c:	7a400b04 	ccmp	w24, #0x0, #0x4, eq	// eq = none
    a360:	54fffce1 	b.ne	a2fc <fwp_main_thread+0xaac>  // b.any
    a364:	7100031f 	cmp	w24, #0x0
    a368:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a36c:	1a9f1704 	csinc	w4, w24, wzr, ne	// ne = any
    a370:	910003e2 	mov	x2, sp
    a374:	d37df084 	lsl	x4, x4, #3
    a378:	f91f7c62 	str	x2, [x3, #16120]
    a37c:	91003c84 	add	x4, x4, #0xf
    a380:	92704c86 	and	x6, x4, #0xfffff0000
    a384:	927c7c84 	and	x4, x4, #0xffffffff0
    a388:	cb2663e6 	sub	x6, sp, x6
    a38c:	eb2663ff 	cmp	sp, x6
    a390:	540000a0 	b.eq	a3a4 <fwp_main_thread+0xb54>  // b.none
    a394:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a398:	f90203ff 	str	xzr, [sp, #1024]
    a39c:	eb2663ff 	cmp	sp, x6
    a3a0:	54ffffa1 	b.ne	a394 <fwp_main_thread+0xb44>  // b.any
    a3a4:	92403c84 	and	x4, x4, #0xffff
    a3a8:	cb2463ff 	sub	sp, sp, x4
    a3ac:	f90003ff 	str	xzr, [sp]
    a3b0:	f110009f 	cmp	x4, #0x400
    a3b4:	54000043 	b.cc	a3bc <fwp_main_thread+0xb6c>  // b.lo, b.ul, b.last
    a3b8:	f90203ff 	str	xzr, [sp, #1024]
    a3bc:	910043f9 	add	x25, sp, #0x10
    a3c0:	d37d7c27 	ubfiz	x7, x1, #3, #32
    a3c4:	910020a6 	add	x6, x5, #0x8
    a3c8:	d2800004 	mov	x4, #0x0                   	// #0
    a3cc:	340000c1 	cbz	w1, a3e4 <fwp_main_thread+0xb94>
    a3d0:	f86468c2 	ldr	x2, [x6, x4]
    a3d4:	f8246b22 	str	x2, [x25, x4]
    a3d8:	91002084 	add	x4, x4, #0x8
    a3dc:	eb07009f 	cmp	x4, x7
    a3e0:	54ffff81 	b.ne	a3d0 <fwp_main_thread+0xb80>  // b.any
    a3e4:	2a1303e6 	mov	w6, w19
    a3e8:	d2800004 	mov	x4, #0x0                   	// #0
    a3ec:	340000f3 	cbz	w19, a408 <fwp_main_thread+0xbb8>
    a3f0:	0b040022 	add	w2, w1, w4
    a3f4:	f8647b43 	ldr	x3, [x26, x4, lsl #3]
    a3f8:	91000484 	add	x4, x4, #0x1
    a3fc:	f8227b23 	str	x3, [x25, x2, lsl #3]
    a400:	eb06009f 	cmp	x4, x6
    a404:	54ffff61 	b.ne	a3f0 <fwp_main_thread+0xba0>  // b.any
    a408:	f949daa1 	ldr	x1, [x21, #5040]
    a40c:	f949eea4 	ldr	x4, [x21, #5080]
    a410:	cb0102e1 	sub	x1, x23, x1
    a414:	eb04403f 	cmp	x1, x4, lsl #16
    a418:	540002e2 	b.cs	a474 <fwp_main_thread+0xc24>  // b.hs, b.nlast
    a41c:	d350fc24 	lsr	x4, x1, #16
    a420:	f949fea8 	ldr	x8, [x21, #5112]
    a424:	8b040884 	add	x4, x4, x4, lsl #2
    a428:	d37df084 	lsl	x4, x4, #3
    a42c:	8b040107 	add	x7, x8, x4
    a430:	f94010e6 	ldr	x6, [x7, #32]
    a434:	b4000206 	cbz	x6, a474 <fwp_main_thread+0xc24>
    a438:	38646904 	ldrb	w4, [x8, x4]
    a43c:	7100089f 	cmp	w4, #0x2
    a440:	54000720 	b.eq	a524 <fwp_main_thread+0xcd4>  // b.none
    a444:	7100049f 	cmp	w4, #0x1
    a448:	54000161 	b.ne	a474 <fwp_main_thread+0xc24>  // b.any
    a44c:	294310e8 	ldp	w8, w4, [x7, #24]
    a450:	92403c21 	and	x1, x1, #0xffff
    a454:	9b087c21 	mul	x1, x1, x8
    a458:	d360fc21 	lsr	x1, x1, #32
    a45c:	eb04003f 	cmp	x1, x4
    a460:	540000a2 	b.cs	a474 <fwp_main_thread+0xc24>  // b.hs, b.nlast
    a464:	8b0100c6 	add	x6, x6, x1
    a468:	394000c1 	ldrb	w1, [x6]
    a46c:	7100043f 	cmp	w1, #0x1
    a470:	54000560 	b.eq	a51c <fwp_main_thread+0xccc>  // b.none
    a474:	f9400404 	ldr	x4, [x0, #8]
    a478:	52800021 	mov	w1, #0x1                   	// #1
    a47c:	aa1703e0 	mov	x0, x23
    a480:	d63f0080 	blr	x4
    a484:	f9400ec1 	ldr	x1, [x22, #24]
    a488:	aa1903e0 	mov	x0, x25
    a48c:	f9400021 	ldr	x1, [x1]
    a490:	d63f0020 	blr	x1
    a494:	aa0003f9 	mov	x25, x0
    a498:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a49c:	f95f7c00 	ldr	x0, [x0, #16120]
    a4a0:	9100001f 	mov	sp, x0
    a4a4:	aa1703e0 	mov	x0, x23
    a4a8:	97ffeeea 	bl	6050 <fwp_closure_drop>
    a4ac:	6b14027f 	cmp	w19, w20
    a4b0:	54fff361 	b.ne	a31c <fwp_main_thread+0xacc>  // b.any
    a4b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4b8:	aa1903f7 	mov	x23, x25
    a4bc:	b97ed807 	ldr	w7, [x0, #16088]
    a4c0:	b97ee016 	ldr	w22, [x0, #16096]
    a4c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4c8:	b97ee400 	ldr	w0, [x0, #16100]
    a4cc:	6b16001f 	cmp	w0, w22
    a4d0:	54000703 	b.cc	a5b0 <fwp_main_thread+0xd60>  // b.lo, b.ul, b.last
    a4d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4d8:	f95f6413 	ldr	x19, [x0, #16072]
    a4dc:	f95f6806 	ldr	x6, [x0, #16080]
    a4e0:	14000061 	b	a664 <fwp_main_thread+0xe14>
    a4e4:	72003c5f 	tst	w2, #0xffff
    a4e8:	54ffce41 	b.ne	9eb0 <fwp_main_thread+0x660>  // b.any
    a4ec:	39400320 	ldrb	w0, [x25]
    a4f0:	7103fc1f 	cmp	w0, #0xff
    a4f4:	54ffcdc1 	b.ne	9eac <fwp_main_thread+0x65c>  // b.any
    a4f8:	aa1903e0 	mov	x0, x25
    a4fc:	97ffe925 	bl	4990 <fwp_rc_forget_slot>
    a500:	17fffe6b 	b	9eac <fwp_main_thread+0x65c>
    a504:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    a508:	913c8000 	add	x0, x0, #0xf20
    a50c:	94000421 	bl	b590 <atexit>
    a510:	17fffce5 	b	98a4 <fwp_main_thread+0x54>
    a514:	97ffe6dc 	bl	4084 <fwp_heap_init>
    a518:	17fffcdf 	b	9894 <fwp_main_thread+0x44>
    a51c:	b90004bf 	str	wzr, [x5, #4]
    a520:	17ffffd9 	b	a484 <fwp_main_thread+0xc34>
    a524:	72003c3f 	tst	w1, #0xffff
    a528:	54fffa61 	b.ne	a474 <fwp_main_thread+0xc24>  // b.any
    a52c:	17ffffcf 	b	a468 <fwp_main_thread+0xc18>
    a530:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a534:	aa1903f8 	mov	x24, x25
    a538:	b97ed807 	ldr	w7, [x0, #16088]
    a53c:	b97ee016 	ldr	w22, [x0, #16096]
    a540:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a544:	b93ef807 	str	w7, [x0, #16120]
    a548:	aa1803e0 	mov	x0, x24
    a54c:	97ffed0e 	bl	5984 <fwp_rc_share>
    a550:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a554:	b97ef807 	ldr	w7, [x0, #16120]
    a558:	34000134 	cbz	w20, a57c <fwp_main_thread+0xd2c>
    a55c:	aa1a03f7 	mov	x23, x26
    a560:	8b344f53 	add	x19, x26, w20, uxtw #3
    a564:	2a0703f9 	mov	w25, w7
    a568:	f84086e0 	ldr	x0, [x23], #8
    a56c:	97ffed06 	bl	5984 <fwp_rc_share>
    a570:	eb1302ff 	cmp	x23, x19
    a574:	54ffffa1 	b.ne	a568 <fwp_main_thread+0xd18>  // b.any
    a578:	2a1903e7 	mov	w7, w25
    a57c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a580:	aa1a03e2 	mov	x2, x26
    a584:	2a1403e1 	mov	w1, w20
    a588:	b93ef807 	str	w7, [x0, #16120]
    a58c:	aa1803e0 	mov	x0, x24
    a590:	97ffeb21 	bl	5214 <fwp_apply>
    a594:	aa0003f7 	mov	x23, x0
    a598:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a59c:	b97ef807 	ldr	w7, [x0, #16120]
    a5a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5a4:	b97ee400 	ldr	w0, [x0, #16100]
    a5a8:	6b16001f 	cmp	w0, w22
    a5ac:	54fff942 	b.cs	a4d4 <fwp_main_thread+0xc84>  // b.hs, b.nlast
    a5b0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5b4:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a5b8:	f9406b81 	ldr	x1, [x28, #208]
    a5bc:	4b0702d6 	sub	w22, w22, w7
    a5c0:	f95f7800 	ldr	x0, [x0, #16112]
    a5c4:	b94002e4 	ldr	w4, [x23]
    a5c8:	8b274c00 	add	x0, x0, w7, uxtw #3
    a5cc:	f91f7840 	str	x0, [x2, #16112]
    a5d0:	8b041424 	add	x4, x1, x4, lsl #5
    a5d4:	b97eec40 	ldr	w0, [x2, #16108]
    a5d8:	b97ee842 	ldr	w2, [x2, #16104]
    a5dc:	4b020000 	sub	w0, w0, w2
    a5e0:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a5e4:	f9400c81 	ldr	x1, [x4, #24]
    a5e8:	b93eec40 	str	w0, [x2, #16108]
    a5ec:	aa1703e0 	mov	x0, x23
    a5f0:	b5ffe381 	cbnz	x1, a260 <fwp_main_thread+0xa10>
    a5f4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5f8:	f95f6806 	ldr	x6, [x0, #16080]
    a5fc:	f91f7c06 	str	x6, [x0, #16120]
    a600:	f95f6413 	ldr	x19, [x0, #16072]
    a604:	aa1703e0 	mov	x0, x23
    a608:	97ffecdf 	bl	5984 <fwp_rc_share>
    a60c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a610:	f95f7c06 	ldr	x6, [x0, #16120]
    a614:	34000176 	cbz	w22, a640 <fwp_main_thread+0xdf0>
    a618:	f95f7819 	ldr	x25, [x0, #16112]
    a61c:	aa0603fa 	mov	x26, x6
    a620:	d2800015 	mov	x21, #0x0                   	// #0
    a624:	d503201f 	nop
    a628:	f8757b20 	ldr	x0, [x25, x21, lsl #3]
    a62c:	910006b5 	add	x21, x21, #0x1
    a630:	97ffecd5 	bl	5984 <fwp_rc_share>
    a634:	6b1502df 	cmp	w22, w21
    a638:	54ffff88 	b.hi	a628 <fwp_main_thread+0xdd8>  // b.pmore
    a63c:	aa1a03e6 	mov	x6, x26
    a640:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a644:	2a1603e1 	mov	w1, w22
    a648:	f95f7802 	ldr	x2, [x0, #16112]
    a64c:	f91f7c06 	str	x6, [x0, #16120]
    a650:	aa1703e0 	mov	x0, x23
    a654:	97ffeaf0 	bl	5214 <fwp_apply>
    a658:	aa0003f7 	mov	x23, x0
    a65c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a660:	f95f7c06 	ldr	x6, [x0, #16120]
    a664:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a668:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10690>
    a66c:	91104042 	add	x2, x2, #0x410
    a670:	91014042 	add	x2, x2, #0x50
    a674:	aa1703e1 	mov	x1, x23
    a678:	52800023 	mov	w3, #0x1                   	// #1
    a67c:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a680:	f81303bf 	stur	xzr, [x29, #-208]
    a684:	f91f7c06 	str	x6, [x0, #16120]
    a688:	aa1303e0 	mov	x0, x19
    a68c:	97fff875 	bl	8860 <fwp_write>
    a690:	a97267b6 	ldp	x22, x25, [x29, #-224]
    a694:	b0000000 	adrp	x0, b000 <__divti3+0x160>
    a698:	91180000 	add	x0, x0, #0x600
    a69c:	f10002df 	cmp	x22, #0x0
    a6a0:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    a6a4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6a8:	b1002b3f 	cmn	x25, #0xa
    a6ac:	f95f7c06 	ldr	x6, [x0, #16120]
    a6b0:	54003888 	b.hi	adc0 <fwp_main_thread+0x1570>  // b.pmore
    a6b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6b8:	52800021 	mov	w1, #0x1                   	// #1
    a6bc:	f91f7c06 	str	x6, [x0, #16120]
    a6c0:	91002720 	add	x0, x25, #0x9
    a6c4:	97ffea73 	bl	5090 <fwp_heap_alloc>
    a6c8:	aa0003f5 	mov	x21, x0
    a6cc:	aa1603e1 	mov	x1, x22
    a6d0:	aa0003f6 	mov	x22, x0
    a6d4:	aa1903e2 	mov	x2, x25
    a6d8:	f80086d9 	str	x25, [x22], #8
    a6dc:	8b1902b9 	add	x25, x21, x25
    a6e0:	aa1603e0 	mov	x0, x22
    a6e4:	97ffdfdf 	bl	2660 <memcpy@plt>
    a6e8:	3900233f 	strb	wzr, [x25, #8]
    a6ec:	f85203a0 	ldur	x0, [x29, #-224]
    a6f0:	97ffe078 	bl	28d0 <free@plt>
    a6f4:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a6f8:	91190002 	add	x2, x0, #0x640
    a6fc:	f949d841 	ldr	x1, [x2, #5040]
    a700:	f949ec40 	ldr	x0, [x2, #5080]
    a704:	cb0102a1 	sub	x1, x21, x1
    a708:	eb00403f 	cmp	x1, x0, lsl #16
    a70c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a710:	f95f7c06 	ldr	x6, [x0, #16120]
    a714:	54000322 	b.cs	a778 <fwp_main_thread+0xf28>  // b.hs, b.nlast
    a718:	d350fc20 	lsr	x0, x1, #16
    a71c:	f949fc43 	ldr	x3, [x2, #5112]
    a720:	8b000800 	add	x0, x0, x0, lsl #2
    a724:	d37df002 	lsl	x2, x0, #3
    a728:	8b020060 	add	x0, x3, x2
    a72c:	f9401019 	ldr	x25, [x0, #32]
    a730:	b4000259 	cbz	x25, a778 <fwp_main_thread+0xf28>
    a734:	38626862 	ldrb	w2, [x3, x2]
    a738:	7100085f 	cmp	w2, #0x2
    a73c:	540034e0 	b.eq	add8 <fwp_main_thread+0x1588>  // b.none
    a740:	7100045f 	cmp	w2, #0x1
    a744:	540001a1 	b.ne	a778 <fwp_main_thread+0xf28>  // b.any
    a748:	29430002 	ldp	w2, w0, [x0, #24]
    a74c:	92403c21 	and	x1, x1, #0xffff
    a750:	9b027c21 	mul	x1, x1, x2
    a754:	d360fc21 	lsr	x1, x1, #32
    a758:	eb00003f 	cmp	x1, x0
    a75c:	540000e2 	b.cs	a778 <fwp_main_thread+0xf28>  // b.hs, b.nlast
    a760:	8b010339 	add	x25, x25, x1
    a764:	39400320 	ldrb	w0, [x25]
    a768:	7103fc1f 	cmp	w0, #0xff
    a76c:	54003860 	b.eq	ae78 <fwp_main_thread+0x1628>  // b.none
    a770:	52800020 	mov	w0, #0x1                   	// #1
    a774:	39000320 	strb	w0, [x25]
    a778:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a77c:	f91f7c06 	str	x6, [x0, #16120]
    a780:	aa1703e0 	mov	x0, x23
    a784:	97ffed83 	bl	5d90 <fwp_drop0>
    a788:	d00000a0 	adrp	x0, 20000 <__data_start>
    a78c:	91018003 	add	x3, x0, #0x60
    a790:	f94002a2 	ldr	x2, [x21]
    a794:	aa1603e0 	mov	x0, x22
    a798:	aa0303f6 	mov	x22, x3
    a79c:	d2800021 	mov	x1, #0x1                   	// #1
    a7a0:	f9404863 	ldr	x3, [x3, #144]
    a7a4:	97ffe05b 	bl	2910 <fwrite@plt>
    a7a8:	f9404ac1 	ldr	x1, [x22, #144]
    a7ac:	52800140 	mov	w0, #0xa                   	// #10
    a7b0:	97ffdfe0 	bl	2730 <fputc@plt>
    a7b4:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a7b8:	91190002 	add	x2, x0, #0x640
    a7bc:	f949d841 	ldr	x1, [x2, #5040]
    a7c0:	f949ec40 	ldr	x0, [x2, #5080]
    a7c4:	cb0102a1 	sub	x1, x21, x1
    a7c8:	eb00403f 	cmp	x1, x0, lsl #16
    a7cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7d0:	f95f7c06 	ldr	x6, [x0, #16120]
    a7d4:	54000382 	b.cs	a844 <fwp_main_thread+0xff4>  // b.hs, b.nlast
    a7d8:	d350fc20 	lsr	x0, x1, #16
    a7dc:	f949fc43 	ldr	x3, [x2, #5112]
    a7e0:	8b000800 	add	x0, x0, x0, lsl #2
    a7e4:	d37df000 	lsl	x0, x0, #3
    a7e8:	8b000062 	add	x2, x3, x0
    a7ec:	f9401056 	ldr	x22, [x2, #32]
    a7f0:	b40002b6 	cbz	x22, a844 <fwp_main_thread+0xff4>
    a7f4:	38606860 	ldrb	w0, [x3, x0]
    a7f8:	7100081f 	cmp	w0, #0x2
    a7fc:	54002e80 	b.eq	adcc <fwp_main_thread+0x157c>  // b.none
    a800:	7100041f 	cmp	w0, #0x1
    a804:	54000201 	b.ne	a844 <fwp_main_thread+0xff4>  // b.any
    a808:	29430043 	ldp	w3, w0, [x2, #24]
    a80c:	92403c21 	and	x1, x1, #0xffff
    a810:	9b037c21 	mul	x1, x1, x3
    a814:	d360fc21 	lsr	x1, x1, #32
    a818:	eb00003f 	cmp	x1, x0
    a81c:	54000142 	b.cs	a844 <fwp_main_thread+0xff4>  // b.hs, b.nlast
    a820:	8b0102d6 	add	x22, x22, x1
    a824:	394002c0 	ldrb	w0, [x22]
    a828:	340000e0 	cbz	w0, a844 <fwp_main_thread+0xff4>
    a82c:	7100041f 	cmp	w0, #0x1
    a830:	54003100 	b.eq	ae50 <fwp_main_thread+0x1600>  // b.none
    a834:	7103fc1f 	cmp	w0, #0xff
    a838:	54002d60 	b.eq	ade4 <fwp_main_thread+0x1594>  // b.none
    a83c:	51000400 	sub	w0, w0, #0x1
    a840:	390002c0 	strb	w0, [x22]
    a844:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a848:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a84c:	f95f5c00 	ldr	x0, [x0, #16056]
    a850:	f9400800 	ldr	x0, [x0, #16]
    a854:	f91f5c20 	str	x0, [x1, #16056]
    a858:	b5ffc320 	cbnz	x0, a0bc <fwp_main_thread+0x86c>
    a85c:	f95f5434 	ldr	x20, [x1, #16040]
    a860:	f95f603b 	ldr	x27, [x1, #16064]
    a864:	aa1b03e0 	mov	x0, x27
    a868:	97ffed4a 	bl	5d90 <fwp_drop0>
    a86c:	aa1403e0 	mov	x0, x20
    a870:	97ffed48 	bl	5d90 <fwp_drop0>
    a874:	d00000a0 	adrp	x0, 20000 <__data_start>
    a878:	91018000 	add	x0, x0, #0x60
    a87c:	52800021 	mov	w1, #0x1                   	// #1
    a880:	b903c801 	str	w1, [x0, #968]
    a884:	f901e81f 	str	xzr, [x0, #976]
    a888:	17fffc3e 	b	9980 <fwp_main_thread+0x130>
    a88c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a890:	b941338b 	ldr	w11, [x28, #304]
    a894:	aa1603f9 	mov	x25, x22
    a898:	2a0103f8 	mov	w24, w1
    a89c:	b97ed807 	ldr	w7, [x0, #16088]
    a8a0:	b97ee016 	ldr	w22, [x0, #16096]
    a8a4:	11000760 	add	w0, w27, #0x1
    a8a8:	d37df000 	lsl	x0, x0, #3
    a8ac:	340000ab 	cbz	w11, a8c0 <fwp_main_thread+0x1070>
    a8b0:	a9538789 	ldp	x9, x1, [x28, #312]
    a8b4:	91000529 	add	x9, x9, #0x1
    a8b8:	8b000021 	add	x1, x1, x0
    a8bc:	a9138789 	stp	x9, x1, [x28, #312]
    a8c0:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a8c4:	9119002a 	add	x10, x1, #0x640
    a8c8:	f140101f 	cmp	x0, #0x4, lsl #12
    a8cc:	b953a541 	ldr	w1, [x10, #5028]
    a8d0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a8d4:	54001b40 	b.eq	ac3c <fwp_main_thread+0x13ec>  // b.none
    a8d8:	91003c01 	add	x1, x0, #0xf
    a8dc:	8b411141 	add	x1, x10, x1, lsr #4
    a8e0:	397e8021 	ldrb	w1, [x1, #4000]
    a8e4:	910f002c 	add	x12, x1, #0x3c0
    a8e8:	8b010429 	add	x9, x1, x1, lsl #1
    a8ec:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a8f0:	8b090d4d 	add	x13, x10, x9, lsl #3
    a8f4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a8f8:	2a0c03e1 	mov	w1, w12
    a8fc:	b40018f3 	cbz	x19, ac18 <fwp_main_thread+0x13c8>
    a900:	f940026d 	ldr	x13, [x19]
    a904:	aa2d03ed 	mvn	x13, x13
    a908:	f829794d 	str	x13, [x10, x9, lsl #3]
    a90c:	eb01001f 	cmp	x0, x1
    a910:	540000c2 	b.cs	a928 <fwp_main_thread+0x10d8>  // b.hs, b.nlast
    a914:	d503201f 	nop
    a918:	f8206a7f 	str	xzr, [x19, x0]
    a91c:	91002000 	add	x0, x0, #0x8
    a920:	eb00003f 	cmp	x1, x0
    a924:	54ffffa8 	b.hi	a918 <fwp_main_thread+0x10c8>  // b.pmore
    a928:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a92c:	91190009 	add	x9, x0, #0x640
    a930:	f94a1120 	ldr	x0, [x9, #5152]
    a934:	ab010000 	adds	x0, x0, x1
    a938:	54002262 	b.cs	ad84 <fwp_main_thread+0x1534>  // b.hs, b.nlast
    a93c:	f94a1521 	ldr	x1, [x9, #5160]
    a940:	f90a1120 	str	x0, [x9, #5152]
    a944:	eb01001f 	cmp	x0, x1
    a948:	54000049 	b.ls	a950 <fwp_main_thread+0x1100>  // b.plast
    a94c:	f90a1520 	str	x0, [x9, #5160]
    a950:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a954:	91190000 	add	x0, x0, #0x640
    a958:	1e630181 	ucvtf	d1, w12
    a95c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a960:	1e612800 	fadd	d0, d0, d1
    a964:	fd0a1c00 	str	d0, [x0, #5176]
    a968:	3400012b 	cbz	w11, a98c <fwp_main_thread+0x113c>
    a96c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a970:	91190000 	add	x0, x0, #0x640
    a974:	6d548782 	ldp	d2, d1, [x28, #328]
    a978:	fd4a1000 	ldr	d0, [x0, #5152]
    a97c:	7e61d800 	ucvtf	d0, d0
    a980:	1e623800 	fsub	d0, d0, d2
    a984:	1e612010 	fcmpe	d0, d1
    a988:	5400190c 	b.gt	aca8 <fwp_main_thread+0x1458>
    a98c:	b94000a0 	ldr	w0, [x5]
    a990:	29006e60 	stp	w0, w27, [x19]
    a994:	34000178 	cbz	w24, a9c0 <fwp_main_thread+0x1170>
    a998:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a99c:	910020a1 	add	x1, x5, #0x8
    a9a0:	d37d7f02 	ubfiz	x2, x24, #3, #32
    a9a4:	b93ed807 	str	w7, [x0, #16088]
    a9a8:	f91f7c05 	str	x5, [x0, #16120]
    a9ac:	91002260 	add	x0, x19, #0x8
    a9b0:	97ffdf34 	bl	2680 <memmove@plt>
    a9b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9b8:	f95f7c05 	ldr	x5, [x0, #16120]
    a9bc:	b97ed807 	ldr	w7, [x0, #16088]
    a9c0:	2a1403e9 	mov	w9, w20
    a9c4:	d2800001 	mov	x1, #0x0                   	// #0
    a9c8:	34000134 	cbz	w20, a9ec <fwp_main_thread+0x119c>
    a9cc:	d503201f 	nop
    a9d0:	0b010300 	add	w0, w24, w1
    a9d4:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a9d8:	8b000e60 	add	x0, x19, x0, lsl #3
    a9dc:	91000421 	add	x1, x1, #0x1
    a9e0:	f9000402 	str	x2, [x0, #8]
    a9e4:	eb09003f 	cmp	x1, x9
    a9e8:	54ffff41 	b.ne	a9d0 <fwp_main_thread+0x1180>  // b.any
    a9ec:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a9f0:	91190002 	add	x2, x0, #0x640
    a9f4:	f949d840 	ldr	x0, [x2, #5040]
    a9f8:	f949ec41 	ldr	x1, [x2, #5080]
    a9fc:	cb0002e0 	sub	x0, x23, x0
    aa00:	eb01401f 	cmp	x0, x1, lsl #16
    aa04:	540002e2 	b.cs	aa60 <fwp_main_thread+0x1210>  // b.hs, b.nlast
    aa08:	d350fc01 	lsr	x1, x0, #16
    aa0c:	f949fc46 	ldr	x6, [x2, #5112]
    aa10:	8b010821 	add	x1, x1, x1, lsl #2
    aa14:	d37df021 	lsl	x1, x1, #3
    aa18:	8b0100c4 	add	x4, x6, x1
    aa1c:	f9401082 	ldr	x2, [x4, #32]
    aa20:	b4000202 	cbz	x2, aa60 <fwp_main_thread+0x1210>
    aa24:	386168c1 	ldrb	w1, [x6, x1]
    aa28:	7100083f 	cmp	w1, #0x2
    aa2c:	54001200 	b.eq	ac6c <fwp_main_thread+0x141c>  // b.none
    aa30:	7100043f 	cmp	w1, #0x1
    aa34:	54000161 	b.ne	aa60 <fwp_main_thread+0x1210>  // b.any
    aa38:	29430486 	ldp	w6, w1, [x4, #24]
    aa3c:	92403c00 	and	x0, x0, #0xffff
    aa40:	9b067c00 	mul	x0, x0, x6
    aa44:	d360fc00 	lsr	x0, x0, #32
    aa48:	eb01001f 	cmp	x0, x1
    aa4c:	540000a2 	b.cs	aa60 <fwp_main_thread+0x1210>  // b.hs, b.nlast
    aa50:	8b000042 	add	x2, x2, x0
    aa54:	39400040 	ldrb	w0, [x2]
    aa58:	7100041f 	cmp	w0, #0x1
    aa5c:	54000d40 	b.eq	ac04 <fwp_main_thread+0x13b4>  // b.none
    aa60:	f9400f22 	ldr	x2, [x25, #24]
    aa64:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa68:	52800021 	mov	w1, #0x1                   	// #1
    aa6c:	f9400442 	ldr	x2, [x2, #8]
    aa70:	b93ef807 	str	w7, [x0, #16120]
    aa74:	aa1703e0 	mov	x0, x23
    aa78:	d63f0040 	blr	x2
    aa7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa80:	b97ef807 	ldr	w7, [x0, #16120]
    aa84:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    aa88:	91190002 	add	x2, x0, #0x640
    aa8c:	f949d841 	ldr	x1, [x2, #5040]
    aa90:	f949ec40 	ldr	x0, [x2, #5080]
    aa94:	cb010261 	sub	x1, x19, x1
    aa98:	eb00403f 	cmp	x1, x0, lsl #16
    aa9c:	54000322 	b.cs	ab00 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    aaa0:	d350fc20 	lsr	x0, x1, #16
    aaa4:	f949fc43 	ldr	x3, [x2, #5112]
    aaa8:	8b000800 	add	x0, x0, x0, lsl #2
    aaac:	d37df002 	lsl	x2, x0, #3
    aab0:	8b020060 	add	x0, x3, x2
    aab4:	f9401014 	ldr	x20, [x0, #32]
    aab8:	b4000254 	cbz	x20, ab00 <fwp_main_thread+0x12b0>
    aabc:	38626862 	ldrb	w2, [x3, x2]
    aac0:	7100085f 	cmp	w2, #0x2
    aac4:	54000da0 	b.eq	ac78 <fwp_main_thread+0x1428>  // b.none
    aac8:	7100045f 	cmp	w2, #0x1
    aacc:	540001a1 	b.ne	ab00 <fwp_main_thread+0x12b0>  // b.any
    aad0:	29430002 	ldp	w2, w0, [x0, #24]
    aad4:	92403c21 	and	x1, x1, #0xffff
    aad8:	9b027c21 	mul	x1, x1, x2
    aadc:	d360fc21 	lsr	x1, x1, #32
    aae0:	eb00003f 	cmp	x1, x0
    aae4:	540000e2 	b.cs	ab00 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    aae8:	8b010294 	add	x20, x20, x1
    aaec:	39400280 	ldrb	w0, [x20]
    aaf0:	7103fc1f 	cmp	w0, #0xff
    aaf4:	54000cc0 	b.eq	ac8c <fwp_main_thread+0x143c>  // b.none
    aaf8:	52800020 	mov	w0, #0x1                   	// #1
    aafc:	39000280 	strb	w0, [x20]
    ab00:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab04:	b93ef807 	str	w7, [x0, #16120]
    ab08:	aa1703e0 	mov	x0, x23
    ab0c:	97ffed51 	bl	6050 <fwp_closure_drop>
    ab10:	aa1303f7 	mov	x23, x19
    ab14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab18:	b97ef807 	ldr	w7, [x0, #16120]
    ab1c:	17fffea1 	b	a5a0 <fwp_main_thread+0xd50>
    ab20:	b8616860 	ldr	w0, [x3, x1]
    ab24:	b94004a1 	ldr	w1, [x5, #4]
    ab28:	4b010003 	sub	w3, w0, w1
    ab2c:	7100047f 	cmp	w3, #0x1
    ab30:	54ffb361 	b.ne	a19c <fwp_main_thread+0x94c>  // b.any
    ab34:	910003f5 	mov	x21, sp
    ab38:	34000cc1 	cbz	w1, acd0 <fwp_main_thread+0x1480>
    ab3c:	7100001f 	cmp	w0, #0x0
    ab40:	d37d7c00 	ubfiz	x0, x0, #3, #32
    ab44:	d2800102 	mov	x2, #0x8                   	// #8
    ab48:	9a821019 	csel	x25, x0, x2, ne	// ne = any
    ab4c:	91003f20 	add	x0, x25, #0xf
    ab50:	92704c02 	and	x2, x0, #0xfffff0000
    ab54:	927c7c00 	and	x0, x0, #0xffffffff0
    ab58:	cb2263e2 	sub	x2, sp, x2
    ab5c:	eb2263ff 	cmp	sp, x2
    ab60:	540000a0 	b.eq	ab74 <fwp_main_thread+0x1324>  // b.none
    ab64:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    ab68:	f90203ff 	str	xzr, [sp, #1024]
    ab6c:	eb2263ff 	cmp	sp, x2
    ab70:	54ffffa1 	b.ne	ab64 <fwp_main_thread+0x1314>  // b.any
    ab74:	92403c00 	and	x0, x0, #0xffff
    ab78:	cb2063ff 	sub	sp, sp, x0
    ab7c:	f90003ff 	str	xzr, [sp]
    ab80:	f110001f 	cmp	x0, #0x400
    ab84:	54000043 	b.cc	ab8c <fwp_main_thread+0x133c>  // b.lo, b.ul, b.last
    ab88:	f90203ff 	str	xzr, [sp, #1024]
    ab8c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab90:	d37d7c3a 	ubfiz	x26, x1, #3, #32
    ab94:	910043f6 	add	x22, sp, #0x10
    ab98:	aa1a03e2 	mov	x2, x26
    ab9c:	aa1903e3 	mov	x3, x25
    aba0:	f91f7806 	str	x6, [x0, #16112]
    aba4:	f91f7c04 	str	x4, [x0, #16120]
    aba8:	f95f5800 	ldr	x0, [x0, #16048]
    abac:	91004001 	add	x1, x0, #0x10
    abb0:	aa1603e0 	mov	x0, x22
    abb4:	9100c021 	add	x1, x1, #0x30
    abb8:	97ffdeea 	bl	2760 <__memcpy_chk@plt>
    abbc:	eb1a033f 	cmp	x25, x26
    abc0:	aa1303e1 	mov	x1, x19
    abc4:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    abc8:	d2800102 	mov	x2, #0x8                   	// #8
    abcc:	cb1a0063 	sub	x3, x3, x26
    abd0:	8b1a02c0 	add	x0, x22, x26
    abd4:	97ffdee3 	bl	2760 <__memcpy_chk@plt>
    abd8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    abdc:	aa1603e0 	mov	x0, x22
    abe0:	f95f7c24 	ldr	x4, [x1, #16120]
    abe4:	f9400c81 	ldr	x1, [x4, #24]
    abe8:	f9400021 	ldr	x1, [x1]
    abec:	d63f0020 	blr	x1
    abf0:	aa0003f7 	mov	x23, x0
    abf4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abf8:	f95f7806 	ldr	x6, [x0, #16112]
    abfc:	910002bf 	mov	sp, x21
    ac00:	17fffe99 	b	a664 <fwp_main_thread+0xe14>
    ac04:	b90004bf 	str	wzr, [x5, #4]
    ac08:	17ffff9f 	b	aa84 <fwp_main_thread+0x1234>
    ac0c:	72003c3f 	tst	w1, #0xffff
    ac10:	54ffb101 	b.ne	a230 <fwp_main_thread+0x9e0>  // b.any
    ac14:	17fffd7c 	b	a204 <fwp_main_thread+0x9b4>
    ac18:	f94005b3 	ldr	x19, [x13, #8]
    ac1c:	b4000113 	cbz	x19, ac3c <fwp_main_thread+0x13ec>
    ac20:	f94009a9 	ldr	x9, [x13, #16]
    ac24:	cb130129 	sub	x9, x9, x19
    ac28:	eb09003f 	cmp	x1, x9
    ac2c:	54000088 	b.hi	ac3c <fwp_main_thread+0x13ec>  // b.pmore
    ac30:	8b010269 	add	x9, x19, x1
    ac34:	f90005a9 	str	x9, [x13, #8]
    ac38:	17ffff35 	b	a90c <fwp_main_thread+0x10bc>
    ac3c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ac40:	f91f6c25 	str	x5, [x1, #16088]
    ac44:	b93ee02b 	str	w11, [x1, #16096]
    ac48:	b93ef827 	str	w7, [x1, #16120]
    ac4c:	52800001 	mov	w1, #0x0                   	// #0
    ac50:	97ffe910 	bl	5090 <fwp_heap_alloc>
    ac54:	aa0003f3 	mov	x19, x0
    ac58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac5c:	f95f6c05 	ldr	x5, [x0, #16088]
    ac60:	b97ee00b 	ldr	w11, [x0, #16096]
    ac64:	b97ef807 	ldr	w7, [x0, #16120]
    ac68:	17ffff40 	b	a968 <fwp_main_thread+0x1118>
    ac6c:	72003c1f 	tst	w0, #0xffff
    ac70:	54ffef81 	b.ne	aa60 <fwp_main_thread+0x1210>  // b.any
    ac74:	17ffff78 	b	aa54 <fwp_main_thread+0x1204>
    ac78:	72003c3f 	tst	w1, #0xffff
    ac7c:	54fff421 	b.ne	ab00 <fwp_main_thread+0x12b0>  // b.any
    ac80:	39400280 	ldrb	w0, [x20]
    ac84:	7103fc1f 	cmp	w0, #0xff
    ac88:	54fff381 	b.ne	aaf8 <fwp_main_thread+0x12a8>  // b.any
    ac8c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac90:	b93ef807 	str	w7, [x0, #16120]
    ac94:	aa1403e0 	mov	x0, x20
    ac98:	97ffe73e 	bl	4990 <fwp_rc_forget_slot>
    ac9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aca0:	b97ef807 	ldr	w7, [x0, #16120]
    aca4:	17ffff95 	b	aaf8 <fwp_main_thread+0x12a8>
    aca8:	fd00ab80 	str	d0, [x28, #336]
    acac:	17ffff38 	b	a98c <fwp_main_thread+0x113c>
    acb0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    acb4:	f91f7826 	str	x6, [x1, #16112]
    acb8:	f91f7c24 	str	x4, [x1, #16120]
    acbc:	97ffe6ee 	bl	4874 <fwp_rc_wide_dup>
    acc0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acc4:	f95f7806 	ldr	x6, [x0, #16112]
    acc8:	f95f7c04 	ldr	x4, [x0, #16120]
    accc:	17fffd59 	b	a230 <fwp_main_thread+0x9e0>
    acd0:	f9400041 	ldr	x1, [x2]
    acd4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acd8:	f91f7c06 	str	x6, [x0, #16120]
    acdc:	aa1303e0 	mov	x0, x19
    ace0:	d63f0020 	blr	x1
    ace4:	aa0003f7 	mov	x23, x0
    ace8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acec:	f95f7c06 	ldr	x6, [x0, #16120]
    acf0:	910002bf 	mov	sp, x21
    acf4:	17fffe5c 	b	a664 <fwp_main_thread+0xe14>
    acf8:	72003c3f 	tst	w1, #0xffff
    acfc:	54ff97e1 	b.ne	9ff8 <fwp_main_thread+0x7a8>  // b.any
    ad00:	17fffcb9 	b	9fe4 <fwp_main_thread+0x794>
    ad04:	72003c3f 	tst	w1, #0xffff
    ad08:	54ff92e1 	b.ne	9f64 <fwp_main_thread+0x714>  // b.any
    ad0c:	17fffc91 	b	9f50 <fwp_main_thread+0x700>
    ad10:	72003c3f 	tst	w1, #0xffff
    ad14:	54ff9be1 	b.ne	a090 <fwp_main_thread+0x840>  // b.any
    ad18:	17fffcd9 	b	a07c <fwp_main_thread+0x82c>
    ad1c:	72003c3f 	tst	w1, #0xffff
    ad20:	54ffa201 	b.ne	a160 <fwp_main_thread+0x910>  // b.any
    ad24:	17fffd02 	b	a12c <fwp_main_thread+0x8dc>
    ad28:	aa0103e0 	mov	x0, x1
    ad2c:	17fffb9f 	b	9ba8 <fwp_main_thread+0x358>
    ad30:	aa1603e0 	mov	x0, x22
    ad34:	97ffe717 	bl	4990 <fwp_rc_forget_slot>
    ad38:	17fffc89 	b	9f5c <fwp_main_thread+0x70c>
    ad3c:	aa1503e0 	mov	x0, x21
    ad40:	97ffe714 	bl	4990 <fwp_rc_forget_slot>
    ad44:	17fffcab 	b	9ff0 <fwp_main_thread+0x7a0>
    ad48:	aa1503e0 	mov	x0, x21
    ad4c:	97ffe711 	bl	4990 <fwp_rc_forget_slot>
    ad50:	17fffcce 	b	a088 <fwp_main_thread+0x838>
    ad54:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad58:	f91f7c26 	str	x6, [x1, #16120]
    ad5c:	97ffe6c6 	bl	4874 <fwp_rc_wide_dup>
    ad60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad64:	f95f7c06 	ldr	x6, [x0, #16120]
    ad68:	17fffcfe 	b	a160 <fwp_main_thread+0x910>
    ad6c:	b0000000 	adrp	x0, b000 <__divti3+0x160>
    ad70:	91370000 	add	x0, x0, #0xdc0
    ad74:	97ffe163 	bl	3300 <ad_raw_fail>
    ad78:	b0000000 	adrp	x0, b000 <__divti3+0x160>
    ad7c:	91366000 	add	x0, x0, #0xd98
    ad80:	97ffe280 	bl	3780 <fwp_trap>
    ad84:	97ffe0db 	bl	30f0 <fwp_heap_oom>
    ad88:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad8c:	aa0603e0 	mov	x0, x6
    ad90:	52800036 	mov	w22, #0x1                   	// #1
    ad94:	f91f7c26 	str	x6, [x1, #16120]
    ad98:	97ffeafb 	bl	5984 <fwp_rc_share>
    ad9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ada0:	f95f6000 	ldr	x0, [x0, #16064]
    ada4:	97ffeaf8 	bl	5984 <fwp_rc_share>
    ada8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adac:	f95f7c06 	ldr	x6, [x0, #16120]
    adb0:	f91f7813 	str	x19, [x0, #16112]
    adb4:	aa0603f7 	mov	x23, x6
    adb8:	17fffe22 	b	a640 <fwp_main_thread+0xdf0>
    adbc:	97ffde95 	bl	2810 <__stack_chk_fail@plt>
    adc0:	b0000000 	adrp	x0, b000 <__divti3+0x160>
    adc4:	91378000 	add	x0, x0, #0xde0
    adc8:	97ffe26e 	bl	3780 <fwp_trap>
    adcc:	72003c3f 	tst	w1, #0xffff
    add0:	54ffd3a1 	b.ne	a844 <fwp_main_thread+0xff4>  // b.any
    add4:	17fffe94 	b	a824 <fwp_main_thread+0xfd4>
    add8:	72003c3f 	tst	w1, #0xffff
    addc:	54ffcce1 	b.ne	a778 <fwp_main_thread+0xf28>  // b.any
    ade0:	17fffe61 	b	a764 <fwp_main_thread+0xf14>
    ade4:	ca5646c0 	eor	x0, x22, x22, lsr #17
    ade8:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    adec:	91190021 	add	x1, x1, #0x640
    adf0:	ca402400 	eor	x0, x0, x0, lsr #9
    adf4:	8b200c20 	add	x0, x1, w0, uxtb #3
    adf8:	f94a2400 	ldr	x0, [x0, #5192]
    adfc:	b5000080 	cbnz	x0, ae0c <fwp_main_thread+0x15bc>
    ae00:	14000025 	b	ae94 <fwp_main_thread+0x1644>
    ae04:	f9400800 	ldr	x0, [x0, #16]
    ae08:	b4000460 	cbz	x0, ae94 <fwp_main_thread+0x1644>
    ae0c:	f9400001 	ldr	x1, [x0]
    ae10:	eb0102df 	cmp	x22, x1
    ae14:	54ffff81 	b.ne	ae04 <fwp_main_thread+0x15b4>  // b.any
    ae18:	f9400401 	ldr	x1, [x0, #8]
    ae1c:	d1000421 	sub	x1, x1, #0x1
    ae20:	f9000401 	str	x1, [x0, #8]
    ae24:	f103f83f 	cmp	x1, #0xfe
    ae28:	54ffd0e1 	b.ne	a844 <fwp_main_thread+0xff4>  // b.any
    ae2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae30:	f91f7c06 	str	x6, [x0, #16120]
    ae34:	aa1603e0 	mov	x0, x22
    ae38:	97ffe6d6 	bl	4990 <fwp_rc_forget_slot>
    ae3c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ae40:	390002c0 	strb	w0, [x22]
    ae44:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae48:	f95f7c06 	ldr	x6, [x0, #16120]
    ae4c:	17fffe7e 	b	a844 <fwp_main_thread+0xff4>
    ae50:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae54:	f91f7c06 	str	x6, [x0, #16120]
    ae58:	aa1503e0 	mov	x0, x21
    ae5c:	97ffeaf1 	bl	5a20 <fwp_rc_free_arr>
    ae60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae64:	f95f7c06 	ldr	x6, [x0, #16120]
    ae68:	17fffe77 	b	a844 <fwp_main_thread+0xff4>
    ae6c:	b903da9f 	str	wzr, [x20, #984]
    ae70:	b4ff6d00 	cbz	x0, 9c10 <fwp_main_thread+0x3c0>
    ae74:	97ffde7b 	bl	2860 <abort@plt>
    ae78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae7c:	f91f7c06 	str	x6, [x0, #16120]
    ae80:	aa1903e0 	mov	x0, x25
    ae84:	97ffe6c3 	bl	4990 <fwp_rc_forget_slot>
    ae88:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae8c:	f95f7c06 	ldr	x6, [x0, #16120]
    ae90:	17fffe38 	b	a770 <fwp_main_thread+0xf20>
    ae94:	b0000000 	adrp	x0, b000 <__divti3+0x160>
    ae98:	912a0000 	add	x0, x0, #0xa80
    ae9c:	97ffe239 	bl	3780 <fwp_trap>

000000000000aea0 <__divti3>:
    aea0:	d503245f 	bti	c
    aea4:	d2800004 	mov	x4, #0x0                   	// #0
    aea8:	b7f80721 	tbnz	x1, #63, af8c <__divti3+0xec>
    aeac:	b6f80083 	tbz	x3, #63, aebc <__divti3+0x1c>
    aeb0:	eb0203e2 	negs	x2, x2
    aeb4:	aa2403e4 	mvn	x4, x4
    aeb8:	da0303e3 	ngc	x3, x3
    aebc:	aa0203e6 	mov	x6, x2
    aec0:	aa0003e7 	mov	x7, x0
    aec4:	aa0103e5 	mov	x5, x1
    aec8:	b5000583 	cbnz	x3, af78 <__divti3+0xd8>
    aecc:	eb01005f 	cmp	x2, x1
    aed0:	54000e69 	b.ls	b09c <__divti3+0x1fc>  // b.plast
    aed4:	dac01040 	clz	x0, x2
    aed8:	b40000e0 	cbz	x0, aef4 <__divti3+0x54>
    aedc:	4b0003e1 	neg	w1, w0
    aee0:	9ac020a5 	lsl	x5, x5, x0
    aee4:	9ac02046 	lsl	x6, x2, x0
    aee8:	9ac124e1 	lsr	x1, x7, x1
    aeec:	aa050025 	orr	x5, x1, x5
    aef0:	9ac020e7 	lsl	x7, x7, x0
    aef4:	d360fcc8 	lsr	x8, x6, #32
    aef8:	92407cc2 	and	x2, x6, #0xffffffff
    aefc:	9ac808a3 	udiv	x3, x5, x8
    af00:	9b089465 	msub	x5, x3, x8, x5
    af04:	aa0303e0 	mov	x0, x3
    af08:	9b037c41 	mul	x1, x2, x3
    af0c:	93c780a5 	extr	x5, x5, x7, #32
    af10:	eb05003f 	cmp	x1, x5
    af14:	540000a9 	b.ls	af28 <__divti3+0x88>  // b.plast
    af18:	ab0500c5 	adds	x5, x6, x5
    af1c:	d1000460 	sub	x0, x3, #0x1
    af20:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    af24:	540015a8 	b.hi	b1d8 <__divti3+0x338>  // b.pmore
    af28:	cb0100a5 	sub	x5, x5, x1
    af2c:	9ac808a3 	udiv	x3, x5, x8
    af30:	9b089465 	msub	x5, x3, x8, x5
    af34:	aa0303e1 	mov	x1, x3
    af38:	9b037c42 	mul	x2, x2, x3
    af3c:	aa0703e3 	mov	x3, x7
    af40:	b3607ca3 	bfi	x3, x5, #32, #32
    af44:	eb03005f 	cmp	x2, x3
    af48:	540000c9 	b.ls	af60 <__divti3+0xc0>  // b.plast
    af4c:	ab0300c3 	adds	x3, x6, x3
    af50:	d1000425 	sub	x5, x1, #0x1
    af54:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    af58:	d1000821 	sub	x1, x1, #0x2
    af5c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    af60:	aa008020 	orr	x0, x1, x0, lsl #32
    af64:	d2800001 	mov	x1, #0x0                   	// #0
    af68:	b4000064 	cbz	x4, af74 <__divti3+0xd4>
    af6c:	eb0003e0 	negs	x0, x0
    af70:	da0103e1 	ngc	x1, x1
    af74:	d65f03c0 	ret
    af78:	eb01007f 	cmp	x3, x1
    af7c:	54000109 	b.ls	af9c <__divti3+0xfc>  // b.plast
    af80:	d2800001 	mov	x1, #0x0                   	// #0
    af84:	d2800000 	mov	x0, #0x0                   	// #0
    af88:	17fffff8 	b	af68 <__divti3+0xc8>
    af8c:	eb0003e0 	negs	x0, x0
    af90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af94:	da0103e1 	ngc	x1, x1
    af98:	17ffffc5 	b	aeac <__divti3+0xc>
    af9c:	dac01067 	clz	x7, x3
    afa0:	b40010e7 	cbz	x7, b1bc <__divti3+0x31c>
    afa4:	d2800805 	mov	x5, #0x40                  	// #64
    afa8:	cb0700a5 	sub	x5, x5, x7
    afac:	9ac72063 	lsl	x3, x3, x7
    afb0:	9ac52448 	lsr	x8, x2, x5
    afb4:	aa030108 	orr	x8, x8, x3
    afb8:	9ac52426 	lsr	x6, x1, x5
    afbc:	92407d0a 	and	x10, x8, #0xffffffff
    afc0:	d360fd09 	lsr	x9, x8, #32
    afc4:	9ac52403 	lsr	x3, x0, x5
    afc8:	9ac72021 	lsl	x1, x1, x7
    afcc:	aa010063 	orr	x3, x3, x1
    afd0:	9ac72042 	lsl	x2, x2, x7
    afd4:	9ac908cb 	udiv	x11, x6, x9
    afd8:	9b099965 	msub	x5, x11, x9, x6
    afdc:	aa0b03e1 	mov	x1, x11
    afe0:	9b0b7d46 	mul	x6, x10, x11
    afe4:	93c380a5 	extr	x5, x5, x3, #32
    afe8:	eb0500df 	cmp	x6, x5
    afec:	540000a9 	b.ls	b000 <__divti3+0x160>  // b.plast
    aff0:	ab050105 	adds	x5, x8, x5
    aff4:	d1000561 	sub	x1, x11, #0x1
    aff8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    affc:	54000f48 	b.hi	b1e4 <__divti3+0x344>  // b.pmore
    b000:	cb0600a6 	sub	x6, x5, x6
    b004:	9ac908cb 	udiv	x11, x6, x9
    b008:	9b099969 	msub	x9, x11, x9, x6
    b00c:	aa0b03e5 	mov	x5, x11
    b010:	9b0b7d4a 	mul	x10, x10, x11
    b014:	b3607d23 	bfi	x3, x9, #32, #32
    b018:	eb03015f 	cmp	x10, x3
    b01c:	540000a9 	b.ls	b030 <__divti3+0x190>  // b.plast
    b020:	ab030103 	adds	x3, x8, x3
    b024:	d1000565 	sub	x5, x11, #0x1
    b028:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b02c:	54000e28 	b.hi	b1f0 <__divti3+0x350>  // b.pmore
    b030:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b034:	92407c48 	and	x8, x2, #0xffffffff
    b038:	2a0503e5 	mov	w5, w5
    b03c:	d360fc42 	lsr	x2, x2, #32
    b040:	d360fc26 	lsr	x6, x1, #32
    b044:	cb0a0063 	sub	x3, x3, x10
    b048:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b04c:	9b087caa 	mul	x10, x5, x8
    b050:	9b087cc8 	mul	x8, x6, x8
    b054:	9b0220a5 	madd	x5, x5, x2, x8
    b058:	9b027cc6 	mul	x6, x6, x2
    b05c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b060:	8b0900c5 	add	x5, x6, x9
    b064:	eb02011f 	cmp	x8, x2
    b068:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b06c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b070:	eb06007f 	cmp	x3, x6
    b074:	540000e3 	b.cc	b090 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b078:	92407d4a 	and	x10, x10, #0xffffffff
    b07c:	9ac72000 	lsl	x0, x0, x7
    b080:	8b028142 	add	x2, x10, x2, lsl #32
    b084:	eb02001f 	cmp	x0, x2
    b088:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b08c:	54000a01 	b.ne	b1cc <__divti3+0x32c>  // b.any
    b090:	d1000420 	sub	x0, x1, #0x1
    b094:	d2800001 	mov	x1, #0x0                   	// #0
    b098:	17ffffb4 	b	af68 <__divti3+0xc8>
    b09c:	b5000062 	cbnz	x2, b0a8 <__divti3+0x208>
    b0a0:	d2800022 	mov	x2, #0x1                   	// #1
    b0a4:	9ac30846 	udiv	x6, x2, x3
    b0a8:	dac010c8 	clz	x8, x6
    b0ac:	b5000408 	cbnz	x8, b12c <__divti3+0x28c>
    b0b0:	d360fcc9 	lsr	x9, x6, #32
    b0b4:	92407cc5 	and	x5, x6, #0xffffffff
    b0b8:	cb060023 	sub	x3, x1, x6
    b0bc:	d2800021 	mov	x1, #0x1                   	// #1
    b0c0:	9ac90868 	udiv	x8, x3, x9
    b0c4:	9b098d03 	msub	x3, x8, x9, x3
    b0c8:	aa0803e0 	mov	x0, x8
    b0cc:	9b057d02 	mul	x2, x8, x5
    b0d0:	93c78063 	extr	x3, x3, x7, #32
    b0d4:	eb03005f 	cmp	x2, x3
    b0d8:	540000a9 	b.ls	b0ec <__divti3+0x24c>  // b.plast
    b0dc:	ab0300c3 	adds	x3, x6, x3
    b0e0:	d1000500 	sub	x0, x8, #0x1
    b0e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b0e8:	54000968 	b.hi	b214 <__divti3+0x374>  // b.pmore
    b0ec:	cb020063 	sub	x3, x3, x2
    b0f0:	9ac90862 	udiv	x2, x3, x9
    b0f4:	aa0203e8 	mov	x8, x2
    b0f8:	9b098c42 	msub	x2, x2, x9, x3
    b0fc:	aa0703e3 	mov	x3, x7
    b100:	9b057d05 	mul	x5, x8, x5
    b104:	b3607c43 	bfi	x3, x2, #32, #32
    b108:	eb0300bf 	cmp	x5, x3
    b10c:	540000c9 	b.ls	b124 <__divti3+0x284>  // b.plast
    b110:	ab0300c2 	adds	x2, x6, x3
    b114:	d1000503 	sub	x3, x8, #0x1
    b118:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b11c:	d1000908 	sub	x8, x8, #0x2
    b120:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b124:	aa008100 	orr	x0, x8, x0, lsl #32
    b128:	17ffff90 	b	af68 <__divti3+0xc8>
    b12c:	9ac820c6 	lsl	x6, x6, x8
    b130:	d2800803 	mov	x3, #0x40                  	// #64
    b134:	cb080063 	sub	x3, x3, x8
    b138:	d360fcc9 	lsr	x9, x6, #32
    b13c:	9ac82027 	lsl	x7, x1, x8
    b140:	92407cc5 	and	x5, x6, #0xffffffff
    b144:	9ac32422 	lsr	x2, x1, x3
    b148:	9ac32403 	lsr	x3, x0, x3
    b14c:	aa070063 	orr	x3, x3, x7
    b150:	9ac9084a 	udiv	x10, x2, x9
    b154:	9ac82007 	lsl	x7, x0, x8
    b158:	9b098940 	msub	x0, x10, x9, x2
    b15c:	aa0a03e1 	mov	x1, x10
    b160:	9b0a7ca2 	mul	x2, x5, x10
    b164:	93c38000 	extr	x0, x0, x3, #32
    b168:	eb00005f 	cmp	x2, x0
    b16c:	540000a9 	b.ls	b180 <__divti3+0x2e0>  // b.plast
    b170:	ab0000c0 	adds	x0, x6, x0
    b174:	d1000541 	sub	x1, x10, #0x1
    b178:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b17c:	54000468 	b.hi	b208 <__divti3+0x368>  // b.pmore
    b180:	cb020000 	sub	x0, x0, x2
    b184:	9ac9080a 	udiv	x10, x0, x9
    b188:	9b098140 	msub	x0, x10, x9, x0
    b18c:	aa0a03e2 	mov	x2, x10
    b190:	9b0a7ca8 	mul	x8, x5, x10
    b194:	b3607c03 	bfi	x3, x0, #32, #32
    b198:	eb03011f 	cmp	x8, x3
    b19c:	540000a9 	b.ls	b1b0 <__divti3+0x310>  // b.plast
    b1a0:	ab0300c3 	adds	x3, x6, x3
    b1a4:	d1000542 	sub	x2, x10, #0x1
    b1a8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b1ac:	54000288 	b.hi	b1fc <__divti3+0x35c>  // b.pmore
    b1b0:	cb080063 	sub	x3, x3, x8
    b1b4:	aa018041 	orr	x1, x2, x1, lsl #32
    b1b8:	17ffffc2 	b	b0c0 <__divti3+0x220>
    b1bc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b1c0:	d2800001 	mov	x1, #0x0                   	// #0
    b1c4:	9a9f87e0 	cset	x0, ls	// ls = plast
    b1c8:	17ffff68 	b	af68 <__divti3+0xc8>
    b1cc:	aa0103e0 	mov	x0, x1
    b1d0:	d2800001 	mov	x1, #0x0                   	// #0
    b1d4:	17ffff65 	b	af68 <__divti3+0xc8>
    b1d8:	d1000860 	sub	x0, x3, #0x2
    b1dc:	8b0600a5 	add	x5, x5, x6
    b1e0:	17ffff52 	b	af28 <__divti3+0x88>
    b1e4:	d1000961 	sub	x1, x11, #0x2
    b1e8:	8b0800a5 	add	x5, x5, x8
    b1ec:	17ffff85 	b	b000 <__divti3+0x160>
    b1f0:	d1000965 	sub	x5, x11, #0x2
    b1f4:	8b080063 	add	x3, x3, x8
    b1f8:	17ffff8e 	b	b030 <__divti3+0x190>
    b1fc:	d1000942 	sub	x2, x10, #0x2
    b200:	8b060063 	add	x3, x3, x6
    b204:	17ffffeb 	b	b1b0 <__divti3+0x310>
    b208:	d1000941 	sub	x1, x10, #0x2
    b20c:	8b060000 	add	x0, x0, x6
    b210:	17ffffdc 	b	b180 <__divti3+0x2e0>
    b214:	d1000900 	sub	x0, x8, #0x2
    b218:	8b060063 	add	x3, x3, x6
    b21c:	17ffffb4 	b	b0ec <__divti3+0x24c>

000000000000b220 <__modti3>:
    b220:	d503245f 	bti	c
    b224:	d2800004 	mov	x4, #0x0                   	// #0
    b228:	b6f80081 	tbz	x1, #63, b238 <__modti3+0x18>
    b22c:	eb0003e0 	negs	x0, x0
    b230:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b234:	da0103e1 	ngc	x1, x1
    b238:	f100007f 	cmp	x3, #0x0
    b23c:	5400128b 	b.lt	b48c <__modti3+0x26c>  // b.tstop
    b240:	aa0003e7 	mov	x7, x0
    b244:	aa0103e6 	mov	x6, x1
    b248:	540004e1 	b.ne	b2e4 <__modti3+0xc4>  // b.any
    b24c:	eb02003f 	cmp	x1, x2
    b250:	54000dc2 	b.cs	b408 <__modti3+0x1e8>  // b.hs, b.nlast
    b254:	dac01043 	clz	x3, x2
    b258:	aa0303e5 	mov	x5, x3
    b25c:	b40000e3 	cbz	x3, b278 <__modti3+0x58>
    b260:	4b0303e6 	neg	w6, w3
    b264:	9ac32021 	lsl	x1, x1, x3
    b268:	9ac32042 	lsl	x2, x2, x3
    b26c:	9ac62406 	lsr	x6, x0, x6
    b270:	aa0100c6 	orr	x6, x6, x1
    b274:	9ac32007 	lsl	x7, x0, x3
    b278:	d360fc40 	lsr	x0, x2, #32
    b27c:	92407c43 	and	x3, x2, #0xffffffff
    b280:	9ac008c1 	udiv	x1, x6, x0
    b284:	9b009826 	msub	x6, x1, x0, x6
    b288:	9b017c61 	mul	x1, x3, x1
    b28c:	93c780c6 	extr	x6, x6, x7, #32
    b290:	eb06003f 	cmp	x1, x6
    b294:	540000a9 	b.ls	b2a8 <__modti3+0x88>  // b.plast
    b298:	ab060046 	adds	x6, x2, x6
    b29c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b2a0:	8b0200c8 	add	x8, x6, x2
    b2a4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b2a8:	cb0100c6 	sub	x6, x6, x1
    b2ac:	9ac008c8 	udiv	x8, x6, x0
    b2b0:	9b009901 	msub	x1, x8, x0, x6
    b2b4:	aa0703e0 	mov	x0, x7
    b2b8:	9b087c63 	mul	x3, x3, x8
    b2bc:	b3607c20 	bfi	x0, x1, #32, #32
    b2c0:	eb00007f 	cmp	x3, x0
    b2c4:	54001088 	b.hi	b4d4 <__modti3+0x2b4>  // b.pmore
    b2c8:	cb030000 	sub	x0, x0, x3
    b2cc:	9ac52400 	lsr	x0, x0, x5
    b2d0:	d2800001 	mov	x1, #0x0                   	// #0
    b2d4:	b4000064 	cbz	x4, b2e0 <__modti3+0xc0>
    b2d8:	eb0003e0 	negs	x0, x0
    b2dc:	da0103e1 	ngc	x1, x1
    b2e0:	d65f03c0 	ret
    b2e4:	dac01066 	clz	x6, x3
    b2e8:	eb03003f 	cmp	x1, x3
    b2ec:	54ffff43 	b.cc	b2d4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b2f0:	93407cc5 	sxtw	x5, w6
    b2f4:	d2800808 	mov	x8, #0x40                  	// #64
    b2f8:	cb050108 	sub	x8, x8, x5
    b2fc:	9ac62063 	lsl	x3, x3, x6
    b300:	9ac62025 	lsl	x5, x1, x6
    b304:	9ac82447 	lsr	x7, x2, x8
    b308:	aa0300e7 	orr	x7, x7, x3
    b30c:	9ac82423 	lsr	x3, x1, x8
    b310:	92407cec 	and	x12, x7, #0xffffffff
    b314:	d360fcea 	lsr	x10, x7, #32
    b318:	9ac82401 	lsr	x1, x0, x8
    b31c:	aa050021 	orr	x1, x1, x5
    b320:	9ac62042 	lsl	x2, x2, x6
    b324:	9ac62000 	lsl	x0, x0, x6
    b328:	9aca086b 	udiv	x11, x3, x10
    b32c:	9b0a8d63 	msub	x3, x11, x10, x3
    b330:	aa0b03e5 	mov	x5, x11
    b334:	9b0b7d89 	mul	x9, x12, x11
    b338:	93c18063 	extr	x3, x3, x1, #32
    b33c:	eb03013f 	cmp	x9, x3
    b340:	540000a9 	b.ls	b354 <__modti3+0x134>  // b.plast
    b344:	ab0300e3 	adds	x3, x7, x3
    b348:	d1000565 	sub	x5, x11, #0x1
    b34c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b350:	54001168 	b.hi	b57c <__modti3+0x35c>  // b.pmore
    b354:	cb090063 	sub	x3, x3, x9
    b358:	9aca086b 	udiv	x11, x3, x10
    b35c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b360:	aa0b03e9 	mov	x9, x11
    b364:	9b0b7d8c 	mul	x12, x12, x11
    b368:	b3607d41 	bfi	x1, x10, #32, #32
    b36c:	eb01019f 	cmp	x12, x1
    b370:	540000a9 	b.ls	b384 <__modti3+0x164>  // b.plast
    b374:	ab0100e1 	adds	x1, x7, x1
    b378:	d1000569 	sub	x9, x11, #0x1
    b37c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b380:	54000f88 	b.hi	b570 <__modti3+0x350>  // b.pmore
    b384:	aa058123 	orr	x3, x9, x5, lsl #32
    b388:	92407c4b 	and	x11, x2, #0xffffffff
    b38c:	2a0903e9 	mov	w9, w9
    b390:	d360fc4a 	lsr	x10, x2, #32
    b394:	d360fc63 	lsr	x3, x3, #32
    b398:	cb0c0021 	sub	x1, x1, x12
    b39c:	aa0a03ec 	mov	x12, x10
    b3a0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b3a4:	9b0b7d25 	mul	x5, x9, x11
    b3a8:	9b0b7c6b 	mul	x11, x3, x11
    b3ac:	9b0a2d29 	madd	x9, x9, x10, x11
    b3b0:	92407caa 	and	x10, x5, #0xffffffff
    b3b4:	9b0c7c63 	mul	x3, x3, x12
    b3b8:	8b458125 	add	x5, x9, x5, lsr #32
    b3bc:	8b0d0069 	add	x9, x3, x13
    b3c0:	eb05017f 	cmp	x11, x5
    b3c4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b3c8:	8b058149 	add	x9, x10, x5, lsl #32
    b3cc:	8b458063 	add	x3, x3, x5, lsr #32
    b3d0:	eb03003f 	cmp	x1, x3
    b3d4:	54000063 	b.cc	b3e0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b3d8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b3dc:	54000082 	b.cs	b3ec <__modti3+0x1cc>  // b.hs, b.nlast
    b3e0:	eb020129 	subs	x9, x9, x2
    b3e4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b3e8:	cb070063 	sub	x3, x3, x7
    b3ec:	eb090000 	subs	x0, x0, x9
    b3f0:	da030021 	sbc	x1, x1, x3
    b3f4:	9ac62400 	lsr	x0, x0, x6
    b3f8:	9ac82028 	lsl	x8, x1, x8
    b3fc:	aa000100 	orr	x0, x8, x0
    b400:	9ac62421 	lsr	x1, x1, x6
    b404:	17ffffb4 	b	b2d4 <__modti3+0xb4>
    b408:	b5000062 	cbnz	x2, b414 <__modti3+0x1f4>
    b40c:	d2800023 	mov	x3, #0x1                   	// #1
    b410:	9ac20862 	udiv	x2, x3, x2
    b414:	dac01048 	clz	x8, x2
    b418:	aa0803e5 	mov	x5, x8
    b41c:	b5000668 	cbnz	x8, b4e8 <__modti3+0x2c8>
    b420:	cb020020 	sub	x0, x1, x2
    b424:	d360fc49 	lsr	x9, x2, #32
    b428:	92407c4a 	and	x10, x2, #0xffffffff
    b42c:	9ac90801 	udiv	x1, x0, x9
    b430:	9b098020 	msub	x0, x1, x9, x0
    b434:	9b0a7c21 	mul	x1, x1, x10
    b438:	93c78000 	extr	x0, x0, x7, #32
    b43c:	eb00003f 	cmp	x1, x0
    b440:	540000a9 	b.ls	b454 <__modti3+0x234>  // b.plast
    b444:	ab000040 	adds	x0, x2, x0
    b448:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b44c:	8b020003 	add	x3, x0, x2
    b450:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b454:	cb010001 	sub	x1, x0, x1
    b458:	9ac90820 	udiv	x0, x1, x9
    b45c:	9b098403 	msub	x3, x0, x9, x1
    b460:	aa0703e1 	mov	x1, x7
    b464:	9b0a7c00 	mul	x0, x0, x10
    b468:	b3607c61 	bfi	x1, x3, #32, #32
    b46c:	eb01001f 	cmp	x0, x1
    b470:	540000a9 	b.ls	b484 <__modti3+0x264>  // b.plast
    b474:	ab010041 	adds	x1, x2, x1
    b478:	8b020022 	add	x2, x1, x2
    b47c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b480:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b484:	cb000020 	sub	x0, x1, x0
    b488:	17ffff91 	b	b2cc <__modti3+0xac>
    b48c:	eb0203e5 	negs	x5, x2
    b490:	aa0003e7 	mov	x7, x0
    b494:	da0303e8 	ngc	x8, x3
    b498:	aa0503e2 	mov	x2, x5
    b49c:	aa0803e3 	mov	x3, x8
    b4a0:	aa0103e6 	mov	x6, x1
    b4a4:	b4ffed48 	cbz	x8, b24c <__modti3+0x2c>
    b4a8:	eb01011f 	cmp	x8, x1
    b4ac:	54fff148 	b.hi	b2d4 <__modti3+0xb4>  // b.pmore
    b4b0:	dac01109 	clz	x9, x8
    b4b4:	2a0903e6 	mov	w6, w9
    b4b8:	b5fff1c9 	cbnz	x9, b2f0 <__modti3+0xd0>
    b4bc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b4c0:	54000068 	b.hi	b4cc <__modti3+0x2ac>  // b.pmore
    b4c4:	eb050007 	subs	x7, x0, x5
    b4c8:	da080021 	sbc	x1, x1, x8
    b4cc:	aa0703e0 	mov	x0, x7
    b4d0:	17ffff81 	b	b2d4 <__modti3+0xb4>
    b4d4:	ab000040 	adds	x0, x2, x0
    b4d8:	8b020002 	add	x2, x0, x2
    b4dc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b4e0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b4e4:	17ffff79 	b	b2c8 <__modti3+0xa8>
    b4e8:	9ac82042 	lsl	x2, x2, x8
    b4ec:	d2800803 	mov	x3, #0x40                  	// #64
    b4f0:	cb080063 	sub	x3, x3, x8
    b4f4:	d360fc49 	lsr	x9, x2, #32
    b4f8:	9ac82027 	lsl	x7, x1, x8
    b4fc:	92407c4a 	and	x10, x2, #0xffffffff
    b500:	9ac32426 	lsr	x6, x1, x3
    b504:	9ac32403 	lsr	x3, x0, x3
    b508:	aa070063 	orr	x3, x3, x7
    b50c:	9ac908c1 	udiv	x1, x6, x9
    b510:	9ac82007 	lsl	x7, x0, x8
    b514:	9b099820 	msub	x0, x1, x9, x6
    b518:	9b017d41 	mul	x1, x10, x1
    b51c:	93c38000 	extr	x0, x0, x3, #32
    b520:	eb00003f 	cmp	x1, x0
    b524:	540000a9 	b.ls	b538 <__modti3+0x318>  // b.plast
    b528:	ab000040 	adds	x0, x2, x0
    b52c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b530:	8b020006 	add	x6, x0, x2
    b534:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b538:	cb010000 	sub	x0, x0, x1
    b53c:	9ac90801 	udiv	x1, x0, x9
    b540:	9b098026 	msub	x6, x1, x9, x0
    b544:	aa0303e0 	mov	x0, x3
    b548:	9b017d41 	mul	x1, x10, x1
    b54c:	b3607cc0 	bfi	x0, x6, #32, #32
    b550:	eb00003f 	cmp	x1, x0
    b554:	540000a9 	b.ls	b568 <__modti3+0x348>  // b.plast
    b558:	ab000040 	adds	x0, x2, x0
    b55c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b560:	8b020003 	add	x3, x0, x2
    b564:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b568:	cb010000 	sub	x0, x0, x1
    b56c:	17ffffb0 	b	b42c <__modti3+0x20c>
    b570:	d1000969 	sub	x9, x11, #0x2
    b574:	8b070021 	add	x1, x1, x7
    b578:	17ffff83 	b	b384 <__modti3+0x164>
    b57c:	d1000965 	sub	x5, x11, #0x2
    b580:	8b070063 	add	x3, x3, x7
    b584:	17ffff74 	b	b354 <__modti3+0x134>
    b588:	d503201f 	nop
    b58c:	d503201f 	nop

000000000000b590 <atexit>:
    b590:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b594:	b00000a2 	adrp	x2, 20000 <__data_start>
    b598:	d2800001 	mov	x1, #0x0                   	// #0
    b59c:	910003fd 	mov	x29, sp
    b5a0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b5a4:	f9400442 	ldr	x2, [x2, #8]
    b5a8:	17ffdc5a 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b5ac <_fini>:
    b5ac:	d503201f 	nop
    b5b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b5b4:	910003fd 	mov	x29, sp
    b5b8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b5bc:	d65f03c0 	ret
