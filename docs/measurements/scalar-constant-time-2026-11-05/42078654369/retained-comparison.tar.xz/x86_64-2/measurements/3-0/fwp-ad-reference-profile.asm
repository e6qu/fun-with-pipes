
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 bf 00 00 	mov    0xbfd1(%rip),%rax        # efe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 bc 00 00    	jmp    *0xbc66(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036e0 <fwp_trap_overflow.constprop.0>:
    36e0:	53                   	push   %rbx
    36e1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36e6:	ba 02 00 00 00       	mov    $0x2,%edx
    36eb:	be 60 00 00 00       	mov    $0x60,%esi
    36f0:	4c 8d 0d d8 79 00 00 	lea    0x79d8(%rip),%r9        # b0cf <_IO_stdin_used+0xcf>
    36f7:	4c 8d 05 d5 79 00 00 	lea    0x79d5(%rip),%r8        # b0d3 <_IO_stdin_used+0xd3>
    36fe:	48 83 ec 70          	sub    $0x70,%rsp
    3702:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3709:	00 00 
    370b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3710:	31 c0                	xor    %eax,%eax
    3712:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3717:	e8 84 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    371c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3721:	e8 0a 0d 00 00       	call   4430 <fwp_trap>

0000000000003726 <fwp_task_dispose.cold>:
    3726:	e8 95 fc ff ff       	call   33c0 <abort@plt>

000000000000372b <fwp_main_thread.cold>:
    372b:	e8 90 fc ff ff       	call   33c0 <abort@plt>

0000000000003730 <main.cold>:
    3730:	e8 8b fc ff ff       	call   33c0 <abort@plt>
    3735:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    373c:	00 00 00 
    373f:	90                   	nop

0000000000003740 <main>:
    3740:	f3 0f 1e fa          	endbr64
    3744:	55                   	push   %rbp
    3745:	53                   	push   %rbx
    3746:	48 83 ec 68          	sub    $0x68,%rsp
    374a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3751:	00 00 
    3753:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3758:	48 8d 05 c1 9b 00 00 	lea    0x9bc1(%rip),%rax        # d320 <fwp_fn_table>
    375f:	48 89 05 32 5d 06 00 	mov    %rax,0x65d32(%rip)        # 69498 <fwp_fns>
    3766:	48 8b 05 b3 b8 00 00 	mov    0xb8b3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    376d:	48 89 05 2c 5d 06 00 	mov    %rax,0x65d2c(%rip)        # 694a0 <fwp_prog_out>
    3774:	e8 27 0e 00 00       	call   45a0 <fwp_now_ns>
    3779:	48 8d 3d 28 7b 00 00 	lea    0x7b28(%rip),%rdi        # b2a8 <_IO_stdin_used+0x2a8>
    3780:	e8 0b fc ff ff       	call   3390 <getenv@plt>
    3785:	48 85 c0             	test   %rax,%rax
    3788:	74 0c                	je     3796 <main+0x56>
    378a:	48 89 c3             	mov    %rax,%rbx
    378d:	80 38 00             	cmpb   $0x0,(%rax)
    3790:	0f 85 09 01 00 00    	jne    389f <main+0x15f>
    3796:	31 ff                	xor    %edi,%edi
    3798:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    379d:	e8 6e fc ff ff       	call   3410 <clock_gettime@plt>
    37a2:	85 c0                	test   %eax,%eax
    37a4:	0f 85 28 01 00 00    	jne    38d2 <main+0x192>
    37aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37af:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37b4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37b9:	48 89 cb             	mov    %rcx,%rbx
    37bc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37c0:	48 01 c8             	add    %rcx,%rax
    37c3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ca:	00 00 80 
    37cd:	48 11 da             	adc    %rbx,%rdx
    37d0:	31 db                	xor    %ebx,%ebx
    37d2:	48 01 c8             	add    %rcx,%rax
    37d5:	48 11 da             	adc    %rbx,%rdx
    37d8:	48 85 d2             	test   %rdx,%rdx
    37db:	0f 85 38 01 00 00    	jne    3919 <main+0x1d9>
    37e1:	48 8b 3d 38 b8 00 00 	mov    0xb838(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37e8:	31 d2                	xor    %edx,%edx
    37ea:	31 f6                	xor    %esi,%esi
    37ec:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37f1:	e8 da fd ff ff       	call   35d0 <setvbuf@plt>
    37f6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37fb:	be 01 00 00 00       	mov    $0x1,%esi
    3800:	e8 2b fd ff ff       	call   3530 <signal@plt>
    3805:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    380a:	e8 d1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    380f:	85 c0                	test   %eax,%eax
    3811:	0f 85 f6 00 00 00    	jne    390d <main+0x1cd>
    3817:	be 00 00 00 40       	mov    $0x40000000,%esi
    381c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3821:	e8 aa fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3826:	85 c0                	test   %eax,%eax
    3828:	0f 85 c1 00 00 00    	jne    38ef <main+0x1af>
    382e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3833:	31 c9                	xor    %ecx,%ecx
    3835:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    383a:	48 8d 15 7f 5e 00 00 	lea    0x5e7f(%rip),%rdx        # 96c0 <fwp_main_thread>
    3841:	e8 9a fd ff ff       	call   35e0 <pthread_create@plt>
    3846:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    384b:	89 c5                	mov    %eax,%ebp
    384d:	e8 de fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3852:	85 c0                	test   %eax,%eax
    3854:	0f 85 d6 fe ff ff    	jne    3730 <main.cold>
    385a:	85 ed                	test   %ebp,%ebp
    385c:	0f 85 81 00 00 00    	jne    38e3 <main+0x1a3>
    3862:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3867:	31 f6                	xor    %esi,%esi
    3869:	e8 22 fe ff ff       	call   3690 <pthread_join@plt>
    386e:	85 c0                	test   %eax,%eax
    3870:	0f 85 ba fe ff ff    	jne    3730 <main.cold>
    3876:	48 8b 3d a3 b7 00 00 	mov    0xb7a3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    387d:	e8 1e fd ff ff       	call   35a0 <fflush@plt>
    3882:	8b 05 18 b8 01 00    	mov    0x1b818(%rip),%eax        # 1f0a0 <fwp_exit_code>
    3888:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    388d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3894:	00 00 
    3896:	75 46                	jne    38de <main+0x19e>
    3898:	48 83 c4 68          	add    $0x68,%rsp
    389c:	5b                   	pop    %rbx
    389d:	5d                   	pop    %rbp
    389e:	c3                   	ret
    389f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38a4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a9:	48 89 c7             	mov    %rax,%rdi
    38ac:	e8 4f fc ff ff       	call   3500 <strtoull@plt>
    38b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38b6:	80 38 00             	cmpb   $0x0,(%rax)
    38b9:	0f 85 d7 fe ff ff    	jne    3796 <main+0x56>
    38bf:	0f b6 03             	movzbl (%rbx),%eax
    38c2:	83 e8 2b             	sub    $0x2b,%eax
    38c5:	a8 fd                	test   $0xfd,%al
    38c7:	0f 84 c9 fe ff ff    	je     3796 <main+0x56>
    38cd:	e9 0f ff ff ff       	jmp    37e1 <main+0xa1>
    38d2:	48 8d 3d d8 79 00 00 	lea    0x79d8(%rip),%rdi        # b2b1 <_IO_stdin_used+0x2b1>
    38d9:	e8 52 0b 00 00       	call   4430 <fwp_trap>
    38de:	e8 6d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    38e3:	48 8d 3d a6 82 00 00 	lea    0x82a6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ea:	e8 41 0b 00 00       	call   4430 <fwp_trap>
    38ef:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38f4:	e8 37 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    38f9:	85 c0                	test   %eax,%eax
    38fb:	0f 85 2f fe ff ff    	jne    3730 <main.cold>
    3901:	48 8d 3d 60 82 00 00 	lea    0x8260(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    3908:	e8 23 0b 00 00       	call   4430 <fwp_trap>
    390d:	48 8d 3d 24 82 00 00 	lea    0x8224(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    3914:	e8 17 0b 00 00       	call   4430 <fwp_trap>
    3919:	48 8d 3d f0 81 00 00 	lea    0x81f0(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3920:	e8 0b 0b 00 00       	call   4430 <fwp_trap>
    3925:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    392c:	00 00 00 
    392f:	90                   	nop

0000000000003930 <_start>:
    3930:	f3 0f 1e fa          	endbr64
    3934:	31 ed                	xor    %ebp,%ebp
    3936:	49 89 d1             	mov    %rdx,%r9
    3939:	5e                   	pop    %rsi
    393a:	48 89 e2             	mov    %rsp,%rdx
    393d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3941:	50                   	push   %rax
    3942:	54                   	push   %rsp
    3943:	45 31 c0             	xor    %r8d,%r8d
    3946:	31 c9                	xor    %ecx,%ecx
    3948:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3740 <main>
    394f:	ff 15 7b b6 00 00    	call   *0xb67b(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    3955:	f4                   	hlt
    3956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    395d:	00 00 00 

0000000000003960 <deregister_tm_clones>:
    3960:	48 8d 3d b1 b6 00 00 	lea    0xb6b1(%rip),%rdi        # f018 <__TMC_END__>
    3967:	48 8d 05 aa b6 00 00 	lea    0xb6aa(%rip),%rax        # f018 <__TMC_END__>
    396e:	48 39 f8             	cmp    %rdi,%rax
    3971:	74 15                	je     3988 <deregister_tm_clones+0x28>
    3973:	48 8b 05 5e b6 00 00 	mov    0xb65e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    397a:	48 85 c0             	test   %rax,%rax
    397d:	74 09                	je     3988 <deregister_tm_clones+0x28>
    397f:	ff e0                	jmp    *%rax
    3981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3988:	c3                   	ret
    3989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003990 <register_tm_clones>:
    3990:	48 8d 3d 81 b6 00 00 	lea    0xb681(%rip),%rdi        # f018 <__TMC_END__>
    3997:	48 8d 35 7a b6 00 00 	lea    0xb67a(%rip),%rsi        # f018 <__TMC_END__>
    399e:	48 29 fe             	sub    %rdi,%rsi
    39a1:	48 89 f0             	mov    %rsi,%rax
    39a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39a8:	48 c1 f8 03          	sar    $0x3,%rax
    39ac:	48 01 c6             	add    %rax,%rsi
    39af:	48 d1 fe             	sar    $1,%rsi
    39b2:	74 14                	je     39c8 <register_tm_clones+0x38>
    39b4:	48 8b 05 2d b6 00 00 	mov    0xb62d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    39bb:	48 85 c0             	test   %rax,%rax
    39be:	74 08                	je     39c8 <register_tm_clones+0x38>
    39c0:	ff e0                	jmp    *%rax
    39c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39c8:	c3                   	ret
    39c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039d0 <__do_global_dtors_aux>:
    39d0:	f3 0f 1e fa          	endbr64
    39d4:	80 3d 6d b6 00 00 00 	cmpb   $0x0,0xb66d(%rip)        # f048 <completed.0>
    39db:	75 2b                	jne    3a08 <__do_global_dtors_aux+0x38>
    39dd:	55                   	push   %rbp
    39de:	48 83 3d 0a b6 00 00 	cmpq   $0x0,0xb60a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    39e5:	00 
    39e6:	48 89 e5             	mov    %rsp,%rbp
    39e9:	74 0c                	je     39f7 <__do_global_dtors_aux+0x27>
    39eb:	48 8b 3d 16 b6 00 00 	mov    0xb616(%rip),%rdi        # f008 <__dso_handle>
    39f2:	e8 89 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    39f7:	e8 64 ff ff ff       	call   3960 <deregister_tm_clones>
    39fc:	c6 05 45 b6 00 00 01 	movb   $0x1,0xb645(%rip)        # f048 <completed.0>
    3a03:	5d                   	pop    %rbp
    3a04:	c3                   	ret
    3a05:	0f 1f 00             	nopl   (%rax)
    3a08:	c3                   	ret
    3a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a10 <frame_dummy>:
    3a10:	f3 0f 1e fa          	endbr64
    3a14:	e9 77 ff ff ff       	jmp    3990 <register_tm_clones>
    3a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a20 <fwp_fmt_u128>:
    3a20:	41 57                	push   %r15
    3a22:	41 56                	push   %r14
    3a24:	41 55                	push   %r13
    3a26:	41 54                	push   %r12
    3a28:	55                   	push   %rbp
    3a29:	53                   	push   %rbx
    3a2a:	48 83 ec 68          	sub    $0x68,%rsp
    3a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a35:	00 00 
    3a37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a3c:	48 89 f0             	mov    %rsi,%rax
    3a3f:	48 09 d0             	or     %rdx,%rax
    3a42:	75 7c                	jne    3ac0 <fwp_fmt_u128+0xa0>
    3a44:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a49:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a4e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a53:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a56:	48 89 f8             	mov    %rdi,%rax
    3a59:	49 01 d4             	add    %rdx,%r12
    3a5c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a61:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a68:	00 00 
    3a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a71:	00 00 00 00 
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 
    3a80:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a85:	48 83 c0 01          	add    $0x1,%rax
    3a89:	49 83 ec 01          	sub    $0x1,%r12
    3a8d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a90:	48 39 c8             	cmp    %rcx,%rax
    3a93:	75 eb                	jne    3a80 <fwp_fmt_u128+0x60>
    3a95:	48 63 ed             	movslq %ebp,%rbp
    3a98:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a9c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3aa1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3aa8:	00 00 
    3aaa:	0f 85 ef 00 00 00    	jne    3b9f <fwp_fmt_u128+0x17f>
    3ab0:	48 83 c4 68          	add    $0x68,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5d                   	pop    %rbp
    3ab6:	41 5c                	pop    %r12
    3ab8:	41 5d                	pop    %r13
    3aba:	41 5e                	pop    %r14
    3abc:	41 5f                	pop    %r15
    3abe:	c3                   	ret
    3abf:	90                   	nop
    3ac0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ac5:	49 89 f2             	mov    %rsi,%r10
    3ac8:	49 89 d3             	mov    %rdx,%r11
    3acb:	31 ed                	xor    %ebp,%ebp
    3acd:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ad2:	4c 89 e3             	mov    %r12,%rbx
    3ad5:	45 31 f6             	xor    %r14d,%r14d
    3ad8:	49 89 f9             	mov    %rdi,%r9
    3adb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ae2:	cc cc cc 
    3ae5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3aeb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3af2:	cc cc cc 
    3af5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b00:	4c 89 d6             	mov    %r10,%rsi
    3b03:	4c 89 df             	mov    %r11,%rdi
    3b06:	4c 01 de             	add    %r11,%rsi
    3b09:	48 83 d6 00          	adc    $0x0,%rsi
    3b0d:	45 31 ed             	xor    %r13d,%r13d
    3b10:	48 89 f0             	mov    %rsi,%rax
    3b13:	48 f7 e1             	mul    %rcx
    3b16:	48 89 d0             	mov    %rdx,%rax
    3b19:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b1d:	48 c1 e8 02          	shr    $0x2,%rax
    3b21:	48 01 c2             	add    %rax,%rdx
    3b24:	48 8b 04 24          	mov    (%rsp),%rax
    3b28:	48 29 d6             	sub    %rdx,%rsi
    3b2b:	49 89 f4             	mov    %rsi,%r12
    3b2e:	4c 89 d6             	mov    %r10,%rsi
    3b31:	4c 29 e6             	sub    %r12,%rsi
    3b34:	4c 19 ef             	sbb    %r13,%rdi
    3b37:	48 0f af c6          	imul   %rsi,%rax
    3b3b:	49 89 f8             	mov    %rdi,%r8
    3b3e:	4c 0f af c1          	imul   %rcx,%r8
    3b42:	49 01 c0             	add    %rax,%r8
    3b45:	48 89 f0             	mov    %rsi,%rax
    3b48:	48 f7 e1             	mul    %rcx
    3b4b:	48 89 c6             	mov    %rax,%rsi
    3b4e:	83 e0 01             	and    $0x1,%eax
    3b51:	49 01 d0             	add    %rdx,%r8
    3b54:	49 f7 e7             	mul    %r15
    3b57:	4c 89 c7             	mov    %r8,%rdi
    3b5a:	4c 89 d2             	mov    %r10,%rdx
    3b5d:	4c 01 e0             	add    %r12,%rax
    3b60:	48 d1 ef             	shr    $1,%rdi
    3b63:	83 c5 01             	add    $0x1,%ebp
    3b66:	48 83 c3 01          	add    $0x1,%rbx
    3b6a:	83 c0 30             	add    $0x30,%eax
    3b6d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b72:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b75:	4c 89 d8             	mov    %r11,%rax
    3b78:	49 89 fb             	mov    %rdi,%r11
    3b7b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b80:	48 39 d7             	cmp    %rdx,%rdi
    3b83:	4c 89 f7             	mov    %r14,%rdi
    3b86:	49 89 f2             	mov    %rsi,%r10
    3b89:	48 19 c7             	sbb    %rax,%rdi
    3b8c:	0f 82 6e ff ff ff    	jb     3b00 <fwp_fmt_u128+0xe0>
    3b92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b97:	4c 89 cf             	mov    %r9,%rdi
    3b9a:	e9 b4 fe ff ff       	jmp    3a53 <fwp_fmt_u128+0x33>
    3b9f:	e8 ac f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3ba4:	90                   	nop
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_range_release>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	53                   	push   %rbx
    3bb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bb9:	48 89 fb             	mov    %rdi,%rbx
    3bbc:	48 85 c0             	test   %rax,%rax
    3bbf:	74 06                	je     3bc7 <fwp_range_release+0x17>
    3bc1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3bc5:	ff d0                	call   *%rax
    3bc7:	48 8b 3b             	mov    (%rbx),%rdi
    3bca:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bce:	5b                   	pop    %rbx
    3bcf:	ff e0                	jmp    *%rax
    3bd1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 

0000000000003be0 <ad_raw_record>:
    3be0:	89 c8                	mov    %ecx,%eax
    3be2:	4c 8d 05 d7 b5 04 00 	lea    0x4b5d7(%rip),%r8        # 4f1c0 <ad_raw_live>
    3be9:	49 89 f1             	mov    %rsi,%r9
    3bec:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bf3:	00 
    3bf4:	48 89 d6             	mov    %rdx,%rsi
    3bf7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bfa:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bfe:	48 8d 0d 7b b5 04 00 	lea    0x4b57b(%rip),%rcx        # 4f180 <ad_raw_requests>
    3c05:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c0a:	48 8d 0d 4f b5 04 00 	lea    0x4b54f(%rip),%rcx        # 4f160 <ad_raw_bytes>
    3c11:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c15:	48 01 f2             	add    %rsi,%rdx
    3c18:	48 8d 0d 81 b5 04 00 	lea    0x4b581(%rip),%rcx        # 4f1a0 <ad_raw_peak>
    3c1f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c23:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c27:	4c 89 0f             	mov    %r9,(%rdi)
    3c2a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c2e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c32:	73 04                	jae    3c38 <ad_raw_record+0x58>
    3c34:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c38:	66 0f 6f 05 90 b5 04 	movdqa 0x4b590(%rip),%xmm0        # 4f1d0 <ad_raw_live+0x10>
    3c3f:	00 
    3c40:	66 0f d4 05 78 b5 04 	paddq  0x4b578(%rip),%xmm0        # 4f1c0 <ad_raw_live>
    3c47:	00 
    3c48:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c4c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c51:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c55:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c5a:	48 39 05 df b4 04 00 	cmp    %rax,0x4b4df(%rip)        # 4f140 <ad_raw_total_peak>
    3c61:	73 08                	jae    3c6b <ad_raw_record+0x8b>
    3c63:	66 0f d6 05 d5 b4 04 	movq   %xmm0,0x4b4d5(%rip)        # 4f140 <ad_raw_total_peak>
    3c6a:	00 
    3c6b:	c3                   	ret
    3c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c70 <fwp_tape_unlink_scope>:
    3c70:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c74:	48 85 d2             	test   %rdx,%rdx
    3c77:	74 3e                	je     3cb7 <fwp_tape_unlink_scope+0x47>
    3c79:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c7c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c80:	85 c9                	test   %ecx,%ecx
    3c82:	78 3c                	js     3cc0 <fwp_tape_unlink_scope+0x50>
    3c84:	48 63 d1             	movslq %ecx,%rdx
    3c87:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c8b:	48 03 15 7e b4 01 00 	add    0x1b47e(%rip),%rdx        # 1f110 <fwp_tapes>
    3c92:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c95:	85 c0                	test   %eax,%eax
    3c97:	78 0e                	js     3ca7 <fwp_tape_unlink_scope+0x37>
    3c99:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c9d:	48 03 05 6c b4 01 00 	add    0x1b46c(%rip),%rax        # 1f110 <fwp_tapes>
    3ca4:	89 48 58             	mov    %ecx,0x58(%rax)
    3ca7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cae:	00 
    3caf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cb6:	ff 
    3cb7:	c3                   	ret
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	89 02                	mov    %eax,(%rdx)
    3cc2:	eb d1                	jmp    3c95 <fwp_tape_unlink_scope+0x25>
    3cc4:	90                   	nop
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_args173>:
    3cd0:	f3 0f 1e fa          	endbr64
    3cd4:	c3                   	ret
    3cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cdc:	00 00 00 00 

0000000000003ce0 <fwp_flush>:
    3ce0:	48 8b 3d b9 57 06 00 	mov    0x657b9(%rip),%rdi        # 694a0 <fwp_prog_out>
    3ce7:	48 85 ff             	test   %rdi,%rdi
    3cea:	74 1c                	je     3d08 <fwp_flush+0x28>
    3cec:	48 83 ec 08          	sub    $0x8,%rsp
    3cf0:	e8 ab f8 ff ff       	call   35a0 <fflush@plt>
    3cf5:	48 8b 3d 24 b3 00 00 	mov    0xb324(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cfc:	48 83 c4 08          	add    $0x8,%rsp
    3d00:	e9 9b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d05:	0f 1f 00             	nopl   (%rax)
    3d08:	48 8b 3d 11 b3 00 00 	mov    0xb311(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3d0f:	e9 8c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d14:	90                   	nop
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 

0000000000003d20 <fwp_segv>:
    3d20:	f3 0f 1e fa          	endbr64
    3d24:	48 83 ec 28          	sub    $0x28,%rsp
    3d28:	48 8b 05 f1 3a 06 00 	mov    0x63af1(%rip),%rax        # 67820 <fwp_cur>
    3d2f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d33:	41 89 f8             	mov    %edi,%r8d
    3d36:	48 85 c0             	test   %rax,%rax
    3d39:	74 6d                	je     3da8 <fwp_segv+0x88>
    3d3b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d3f:	48 85 d2             	test   %rdx,%rdx
    3d42:	74 64                	je     3da8 <fwp_segv+0x88>
    3d44:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d48:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d52:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d57:	e8 c4 f8 ff ff       	call   3620 <sysconf@plt>
    3d5c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d61:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d66:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d6b:	48 01 d0             	add    %rdx,%rax
    3d6e:	48 39 c1             	cmp    %rax,%rcx
    3d71:	b8 00 00 00 00       	mov    $0x0,%eax
    3d76:	40 0f 92 c6          	setb   %sil
    3d7a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d81:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d85:	31 c0                	xor    %eax,%eax
    3d87:	48 39 d1             	cmp    %rdx,%rcx
    3d8a:	0f 93 c0             	setae  %al
    3d8d:	21 f0                	and    %esi,%eax
    3d8f:	85 c0                	test   %eax,%eax
    3d91:	75 4a                	jne    3ddd <fwp_segv+0xbd>
    3d93:	31 f6                	xor    %esi,%esi
    3d95:	44 89 c7             	mov    %r8d,%edi
    3d98:	48 83 c4 28          	add    $0x28,%rsp
    3d9c:	e9 8f f7 ff ff       	jmp    3530 <signal@plt>
    3da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3da8:	48 8b 05 39 34 06 00 	mov    0x63439(%rip),%rax        # 671e8 <fwp_main_stack_top>
    3daf:	48 85 c0             	test   %rax,%rax
    3db2:	74 df                	je     3d93 <fwp_segv+0x73>
    3db4:	48 2b 05 25 34 06 00 	sub    0x63425(%rip),%rax        # 671e0 <fwp_main_stack_size>
    3dbb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3dc2:	48 39 d1             	cmp    %rdx,%rcx
    3dc5:	0f 93 c2             	setae  %dl
    3dc8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dce:	48 39 c1             	cmp    %rax,%rcx
    3dd1:	0f 92 c0             	setb   %al
    3dd4:	0f b6 c0             	movzbl %al,%eax
    3dd7:	21 d0                	and    %edx,%eax
    3dd9:	85 c0                	test   %eax,%eax
    3ddb:	74 b6                	je     3d93 <fwp_segv+0x73>
    3ddd:	e8 fe fe ff ff       	call   3ce0 <fwp_flush>
    3de2:	bf 02 00 00 00       	mov    $0x2,%edi
    3de7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dec:	48 8d 35 7d 7e 00 00 	lea    0x7e7d(%rip),%rsi        # bc70 <msg.8>
    3df3:	e8 28 f6 ff ff       	call   3420 <write@plt>
    3df8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dfd:	e8 ce f5 ff ff       	call   33d0 <_exit@plt>
    3e02:	0f 1f 00             	nopl   (%rax)
    3e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e0c:	00 00 00 00 

0000000000003e10 <fwp_heap_oom>:
    3e10:	50                   	push   %rax
    3e11:	58                   	pop    %rax
    3e12:	ba 13 00 00 00       	mov    $0x13,%edx
    3e17:	be 01 00 00 00       	mov    $0x1,%esi
    3e1c:	48 8d 3d e5 71 00 00 	lea    0x71e5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e23:	48 83 ec 08          	sub    $0x8,%rsp
    3e27:	48 8b 0d 12 b2 00 00 	mov    0xb212(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e2e:	e8 2d f8 ff ff       	call   3660 <fwrite@plt>
    3e33:	31 ff                	xor    %edi,%edi
    3e35:	e8 66 f7 ff ff       	call   35a0 <fflush@plt>
    3e3a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e3f:	e8 3c f8 ff ff       	call   3680 <_Exit@plt>
    3e44:	90                   	nop
    3e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e4c:	00 00 00 00 

0000000000003e50 <fwp_heap_chunks>:
    3e50:	41 54                	push   %r12
    3e52:	55                   	push   %rbp
    3e53:	53                   	push   %rbx
    3e54:	48 83 ff 01          	cmp    $0x1,%rdi
    3e58:	0f 84 62 01 00 00    	je     3fc0 <fwp_heap_chunks+0x170>
    3e5e:	48 8b 05 cb 4d 06 00 	mov    0x64dcb(%rip),%rax        # 68c30 <fwp_heap+0x13f0>
    3e65:	4c 8d 05 c4 4d 06 00 	lea    0x64dc4(%rip),%r8        # 68c30 <fwp_heap+0x13f0>
    3e6c:	48 8b 1d a5 4d 06 00 	mov    0x64da5(%rip),%rbx        # 68c18 <fwp_heap+0x13d8>
    3e73:	48 39 d8             	cmp    %rbx,%rax
    3e76:	0f 83 57 01 00 00    	jae    3fd3 <fwp_heap_chunks+0x183>
    3e7c:	48 8b 0d b5 4d 06 00 	mov    0x64db5(%rip),%rcx        # 68c38 <fwp_heap+0x13f8>
    3e83:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e87:	31 f6                	xor    %esi,%esi
    3e89:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e8d:	eb 1e                	jmp    3ead <fwp_heap_chunks+0x5d>
    3e8f:	90                   	nop
    3e90:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e94:	48 39 cf             	cmp    %rcx,%rdi
    3e97:	0f 84 03 01 00 00    	je     3fa0 <fwp_heap_chunks+0x150>
    3e9d:	48 83 c0 01          	add    $0x1,%rax
    3ea1:	48 89 ce             	mov    %rcx,%rsi
    3ea4:	48 83 c2 28          	add    $0x28,%rdx
    3ea8:	48 39 c3             	cmp    %rax,%rbx
    3eab:	74 14                	je     3ec1 <fwp_heap_chunks+0x71>
    3ead:	80 3a 00             	cmpb   $0x0,(%rdx)
    3eb0:	74 de                	je     3e90 <fwp_heap_chunks+0x40>
    3eb2:	48 83 c0 01          	add    $0x1,%rax
    3eb6:	31 f6                	xor    %esi,%esi
    3eb8:	48 83 c2 28          	add    $0x28,%rdx
    3ebc:	48 39 c3             	cmp    %rax,%rbx
    3ebf:	75 ec                	jne    3ead <fwp_heap_chunks+0x5d>
    3ec1:	48 29 f3             	sub    %rsi,%rbx
    3ec4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ec8:	48 8b 3d 51 4d 06 00 	mov    0x64d51(%rip),%rdi        # 68c20 <fwp_heap+0x13e0>
    3ecf:	48 29 35 9a 4d 06 00 	sub    %rsi,0x64d9a(%rip)        # 68c70 <fwp_heap+0x1430>
    3ed6:	48 39 ef             	cmp    %rbp,%rdi
    3ed9:	0f 83 96 00 00 00    	jae    3f75 <fwp_heap_chunks+0x125>
    3edf:	48 8b 05 2a 4d 06 00 	mov    0x64d2a(%rip),%rax        # 68c10 <fwp_heap+0x13d0>
    3ee6:	48 39 e8             	cmp    %rbp,%rax
    3ee9:	0f 82 eb 00 00 00    	jb     3fda <fwp_heap_chunks+0x18a>
    3eef:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ef3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef8:	49 39 c4             	cmp    %rax,%r12
    3efb:	4c 0f 47 e0          	cmova  %rax,%r12
    3eff:	4c 89 e6             	mov    %r12,%rsi
    3f02:	48 29 fe             	sub    %rdi,%rsi
    3f05:	48 c1 e7 10          	shl    $0x10,%rdi
    3f09:	48 03 3d e0 4c 06 00 	add    0x64ce0(%rip),%rdi        # 68bf0 <fwp_heap+0x13b0>
    3f10:	48 c1 e6 10          	shl    $0x10,%rsi
    3f14:	e8 e7 f6 ff ff       	call   3600 <mprotect@plt>
    3f19:	85 c0                	test   %eax,%eax
    3f1b:	0f 85 b9 00 00 00    	jne    3fda <fwp_heap_chunks+0x18a>
    3f21:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f26:	e8 f5 f6 ff ff       	call   3620 <sysconf@plt>
    3f2b:	48 8b 35 ee 4c 06 00 	mov    0x64cee(%rip),%rsi        # 68c20 <fwp_heap+0x13e0>
    3f32:	48 89 c1             	mov    %rax,%rcx
    3f35:	48 8b 05 fc 4c 06 00 	mov    0x64cfc(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    3f3c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f40:	48 89 ca             	mov    %rcx,%rdx
    3f43:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f47:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f4b:	48 f7 da             	neg    %rdx
    3f4e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f53:	48 21 d7             	and    %rdx,%rdi
    3f56:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f5a:	48 21 d6             	and    %rdx,%rsi
    3f5d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f62:	48 29 fe             	sub    %rdi,%rsi
    3f65:	e8 96 f6 ff ff       	call   3600 <mprotect@plt>
    3f6a:	85 c0                	test   %eax,%eax
    3f6c:	75 6c                	jne    3fda <fwp_heap_chunks+0x18a>
    3f6e:	4c 89 25 ab 4c 06 00 	mov    %r12,0x64cab(%rip)        # 68c20 <fwp_heap+0x13e0>
    3f75:	48 89 ef             	mov    %rbp,%rdi
    3f78:	48 89 2d 99 4c 06 00 	mov    %rbp,0x64c99(%rip)        # 68c18 <fwp_heap+0x13d8>
    3f7f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f83:	48 39 3d 7e 4c 06 00 	cmp    %rdi,0x64c7e(%rip)        # 68c08 <fwp_heap+0x13c8>
    3f8a:	73 07                	jae    3f93 <fwp_heap_chunks+0x143>
    3f8c:	48 89 3d 75 4c 06 00 	mov    %rdi,0x64c75(%rip)        # 68c08 <fwp_heap+0x13c8>
    3f93:	48 89 d8             	mov    %rbx,%rax
    3f96:	5b                   	pop    %rbx
    3f97:	5d                   	pop    %rbp
    3f98:	41 5c                	pop    %r12
    3f9a:	c3                   	ret
    3f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fa0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fa4:	48 29 f0             	sub    %rsi,%rax
    3fa7:	48 89 c3             	mov    %rax,%rbx
    3faa:	49 89 10             	mov    %rdx,(%r8)
    3fad:	48 89 d8             	mov    %rbx,%rax
    3fb0:	48 29 3d b9 4c 06 00 	sub    %rdi,0x64cb9(%rip)        # 68c70 <fwp_heap+0x1430>
    3fb7:	5b                   	pop    %rbx
    3fb8:	5d                   	pop    %rbp
    3fb9:	41 5c                	pop    %r12
    3fbb:	c3                   	ret
    3fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fc0:	48 8b 05 61 4c 06 00 	mov    0x64c61(%rip),%rax        # 68c28 <fwp_heap+0x13e8>
    3fc7:	4c 8d 05 5a 4c 06 00 	lea    0x64c5a(%rip),%r8        # 68c28 <fwp_heap+0x13e8>
    3fce:	e9 99 fe ff ff       	jmp    3e6c <fwp_heap_chunks+0x1c>
    3fd3:	31 f6                	xor    %esi,%esi
    3fd5:	e9 ea fe ff ff       	jmp    3ec4 <fwp_heap_chunks+0x74>
    3fda:	e8 31 fe ff ff       	call   3e10 <fwp_heap_oom>
    3fdf:	90                   	nop

0000000000003fe0 <ad_raw_fail>:
    3fe0:	50                   	push   %rax
    3fe1:	58                   	pop    %rax
    3fe2:	48 8d 15 d7 76 00 00 	lea    0x76d7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fe9:	be 02 00 00 00       	mov    $0x2,%esi
    3fee:	31 c0                	xor    %eax,%eax
    3ff0:	48 83 ec 08          	sub    $0x8,%rsp
    3ff4:	48 89 f9             	mov    %rdi,%rcx
    3ff7:	48 8b 3d 42 b0 00 00 	mov    0xb042(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ffe:	e8 6d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4003:	bf e8 00 00 00       	mov    $0xe8,%edi
    4008:	e8 43 f6 ff ff       	call   3650 <exit@plt>
    400d:	0f 1f 00             	nopl   (%rax)

0000000000004010 <buf_grow>:
    4010:	48 83 ec 18          	sub    $0x18,%rsp
    4014:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4018:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    401c:	74 7e                	je     409c <buf_grow+0x8c>
    401e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4025:	48 29 c2             	sub    %rax,%rdx
    4028:	48 39 f2             	cmp    %rsi,%rdx
    402b:	72 6f                	jb     409c <buf_grow+0x8c>
    402d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4032:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4036:	48 89 f9             	mov    %rdi,%rcx
    4039:	48 39 d0             	cmp    %rdx,%rax
    403c:	73 48                	jae    4086 <buf_grow+0x76>
    403e:	48 85 c0             	test   %rax,%rax
    4041:	75 15                	jne    4058 <buf_grow+0x48>
    4043:	48 83 fa 40          	cmp    $0x40,%rdx
    4047:	76 4c                	jbe    4095 <buf_grow+0x85>
    4049:	b8 40 00 00 00       	mov    $0x40,%eax
    404e:	eb 08                	jmp    4058 <buf_grow+0x48>
    4050:	48 01 c0             	add    %rax,%rax
    4053:	48 39 d0             	cmp    %rdx,%rax
    4056:	73 38                	jae    4090 <buf_grow+0x80>
    4058:	48 85 c0             	test   %rax,%rax
    405b:	79 f3                	jns    4050 <buf_grow+0x40>
    405d:	48 8b 39             	mov    (%rcx),%rdi
    4060:	48 89 d6             	mov    %rdx,%rsi
    4063:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4068:	48 89 14 24          	mov    %rdx,(%rsp)
    406c:	e8 3f f5 ff ff       	call   35b0 <realloc@plt>
    4071:	48 8b 14 24          	mov    (%rsp),%rdx
    4075:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    407a:	48 85 c0             	test   %rax,%rax
    407d:	74 1d                	je     409c <buf_grow+0x8c>
    407f:	48 89 01             	mov    %rax,(%rcx)
    4082:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4086:	48 83 c4 18          	add    $0x18,%rsp
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 89 c2             	mov    %rax,%rdx
    4093:	eb c8                	jmp    405d <buf_grow+0x4d>
    4095:	ba 40 00 00 00       	mov    $0x40,%edx
    409a:	eb c1                	jmp    405d <buf_grow+0x4d>
    409c:	48 8b 0d 9d af 00 00 	mov    0xaf9d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    40a3:	ba 13 00 00 00       	mov    $0x13,%edx
    40a8:	be 01 00 00 00       	mov    $0x1,%esi
    40ad:	48 8d 3d 54 6f 00 00 	lea    0x6f54(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    40b4:	e8 a7 f5 ff ff       	call   3660 <fwrite@plt>
    40b9:	31 ff                	xor    %edi,%edi
    40bb:	e8 e0 f4 ff ff       	call   35a0 <fflush@plt>
    40c0:	bf 66 00 00 00       	mov    $0x66,%edi
    40c5:	e8 b6 f5 ff ff       	call   3680 <_Exit@plt>
    40ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040d0 <buf_put>:
    40d0:	41 54                	push   %r12
    40d2:	49 89 f4             	mov    %rsi,%r12
    40d5:	48 89 d6             	mov    %rdx,%rsi
    40d8:	55                   	push   %rbp
    40d9:	48 89 fd             	mov    %rdi,%rbp
    40dc:	53                   	push   %rbx
    40dd:	48 89 d3             	mov    %rdx,%rbx
    40e0:	e8 2b ff ff ff       	call   4010 <buf_grow>
    40e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40e9:	48 89 da             	mov    %rbx,%rdx
    40ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40f0:	4c 89 e6             	mov    %r12,%rsi
    40f3:	e8 88 f4 ff ff       	call   3580 <memcpy@plt>
    40f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4100:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4104:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4108:	5b                   	pop    %rbx
    4109:	5d                   	pop    %rbp
    410a:	41 5c                	pop    %r12
    410c:	c3                   	ret
    410d:	0f 1f 00             	nopl   (%rax)

0000000000004110 <fwp_cancel_tree.part.0>:
    4110:	48 3b 3d 09 37 06 00 	cmp    0x63709(%rip),%rdi        # 67820 <fwp_cur>
    4117:	53                   	push   %rbx
    4118:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    411c:	74 35                	je     4153 <fwp_cancel_tree.part.0+0x43>
    411e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4122:	75 2f                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    4124:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4128:	75 29                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    412a:	48 8b 05 cf 36 06 00 	mov    0x636cf(%rip),%rax        # 67800 <fwp_ready_tail>
    4131:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4135:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    413c:	00 00 00 00 
    4140:	48 85 c0             	test   %rax,%rax
    4143:	74 33                	je     4178 <fwp_cancel_tree.part.0+0x68>
    4145:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    414c:	48 89 3d ad 36 06 00 	mov    %rdi,0x636ad(%rip)        # 67800 <fwp_ready_tail>
    4153:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4157:	48 85 db             	test   %rbx,%rbx
    415a:	74 17                	je     4173 <fwp_cancel_tree.part.0+0x63>
    415c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4160:	75 08                	jne    416a <fwp_cancel_tree.part.0+0x5a>
    4162:	48 89 df             	mov    %rbx,%rdi
    4165:	e8 a6 ff ff ff       	call   4110 <fwp_cancel_tree.part.0>
    416a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    416e:	48 85 db             	test   %rbx,%rbx
    4171:	75 e9                	jne    415c <fwp_cancel_tree.part.0+0x4c>
    4173:	5b                   	pop    %rbx
    4174:	c3                   	ret
    4175:	0f 1f 00             	nopl   (%rax)
    4178:	48 89 3d 89 36 06 00 	mov    %rdi,0x63689(%rip)        # 67808 <fwp_ready_head>
    417f:	eb cb                	jmp    414c <fwp_cancel_tree.part.0+0x3c>
    4181:	0f 1f 40 00          	nopl   0x0(%rax)
    4185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    418c:	00 00 00 00 

0000000000004190 <fwp_finish_float>:
    4190:	53                   	push   %rbx
    4191:	be 2e 00 00 00       	mov    $0x2e,%esi
    4196:	48 89 fb             	mov    %rdi,%rbx
    4199:	e8 d2 f2 ff ff       	call   3470 <strchr@plt>
    419e:	48 85 c0             	test   %rax,%rax
    41a1:	74 05                	je     41a8 <fwp_finish_float+0x18>
    41a3:	5b                   	pop    %rbx
    41a4:	c3                   	ret
    41a5:	0f 1f 00             	nopl   (%rax)
    41a8:	be 65 00 00 00       	mov    $0x65,%esi
    41ad:	48 89 df             	mov    %rbx,%rdi
    41b0:	e8 bb f2 ff ff       	call   3470 <strchr@plt>
    41b5:	48 85 c0             	test   %rax,%rax
    41b8:	75 e9                	jne    41a3 <fwp_finish_float+0x13>
    41ba:	48 8d 35 39 70 00 00 	lea    0x7039(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    41c1:	48 89 df             	mov    %rbx,%rdi
    41c4:	e8 e7 f4 ff ff       	call   36b0 <strstr@plt>
    41c9:	48 85 c0             	test   %rax,%rax
    41cc:	75 d5                	jne    41a3 <fwp_finish_float+0x13>
    41ce:	48 8d 35 47 6e 00 00 	lea    0x6e47(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41d5:	48 89 df             	mov    %rbx,%rdi
    41d8:	e8 d3 f4 ff ff       	call   36b0 <strstr@plt>
    41dd:	48 85 c0             	test   %rax,%rax
    41e0:	75 c1                	jne    41a3 <fwp_finish_float+0x13>
    41e2:	48 89 df             	mov    %rbx,%rdi
    41e5:	e8 56 f2 ff ff       	call   3440 <strlen@plt>
    41ea:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41ef:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41f3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41f8:	5b                   	pop    %rbx
    41f9:	c3                   	ret
    41fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004200 <ad_raw_report>:
    4200:	f3 0f 1e fa          	endbr64
    4204:	41 57                	push   %r15
    4206:	41 56                	push   %r14
    4208:	41 55                	push   %r13
    420a:	41 54                	push   %r12
    420c:	55                   	push   %rbp
    420d:	53                   	push   %rbx
    420e:	48 83 ec 38          	sub    $0x38,%rsp
    4212:	66 0f 6f 05 b6 af 04 	movdqa 0x4afb6(%rip),%xmm0        # 4f1d0 <ad_raw_live+0x10>
    4219:	00 
    421a:	66 0f d4 05 9e af 04 	paddq  0x4af9e(%rip),%xmm0        # 4f1c0 <ad_raw_live>
    4221:	00 
    4222:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4229:	00 00 
    422b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4230:	31 c0                	xor    %eax,%eax
    4232:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4236:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    423b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    423f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4244:	48 85 ed             	test   %rbp,%rbp
    4247:	0f 85 d2 01 00 00    	jne    441f <ad_raw_report+0x21f>
    424d:	4c 8b 05 c4 ae 01 00 	mov    0x1aec4(%rip),%r8        # 1f118 <ad_raw_before_shutdown>
    4254:	45 31 c9             	xor    %r9d,%r9d
    4257:	31 c0                	xor    %eax,%eax
    4259:	31 db                	xor    %ebx,%ebx
    425b:	48 8b 0d de ae 04 00 	mov    0x4aede(%rip),%rcx        # 4f140 <ad_raw_total_peak>
    4262:	48 8b 3d d7 ad 00 00 	mov    0xadd7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4269:	49 89 e4             	mov    %rsp,%r12
    426c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4273:	be 02 00 00 00       	mov    $0x2,%esi
    4278:	4c 8d 3d 21 af 04 00 	lea    0x4af21(%rip),%r15        # 4f1a0 <ad_raw_peak>
    427f:	4c 8d 35 da ae 04 00 	lea    0x4aeda(%rip),%r14        # 4f160 <ad_raw_bytes>
    4286:	e8 e5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    428b:	48 8d 05 99 6d 00 00 	lea    0x6d99(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4292:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec10 <d0+0x70>
    4299:	00 
    429a:	4c 8d 2d df ae 04 00 	lea    0x4aedf(%rip),%r13        # 4f180 <ad_raw_requests>
    42a1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42a6:	48 8d 05 8f 6d 00 00 	lea    0x6d8f(%rip),%rax        # b03c <_IO_stdin_used+0x3c>
    42ad:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42b1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42ba:	f3 0f 7e 05 56 a9 00 	movq   0xa956(%rip),%xmm0        # ec18 <d0+0x78>
    42c1:	00 
    42c2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42c6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42cb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42cf:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42d3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42d8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42dc:	48 85 db             	test   %rbx,%rbx
    42df:	0f 84 0b 01 00 00    	je     43f0 <ad_raw_report+0x1f0>
    42e5:	52                   	push   %rdx
    42e6:	48 8b 3d 53 ad 00 00 	mov    0xad53(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42ed:	48 8d 0d 2c 6d 00 00 	lea    0x6d2c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42f4:	48 8d 15 75 74 00 00 	lea    0x7475(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42fb:	50                   	push   %rax
    42fc:	be 02 00 00 00       	mov    $0x2,%esi
    4301:	31 c0                	xor    %eax,%eax
    4303:	48 83 c3 01          	add    $0x1,%rbx
    4307:	e8 64 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    430c:	5f                   	pop    %rdi
    430d:	41 58                	pop    %r8
    430f:	48 83 fb 04          	cmp    $0x4,%rbx
    4313:	75 b6                	jne    42cb <ad_raw_report+0xcb>
    4315:	48 8b 0d 24 ad 00 00 	mov    0xad24(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    431c:	ba 13 00 00 00       	mov    $0x13,%edx
    4321:	be 01 00 00 00       	mov    $0x1,%esi
    4326:	48 8d 3d 18 6d 00 00 	lea    0x6d18(%rip),%rdi        # b045 <_IO_stdin_used+0x45>
    432d:	e8 2e f3 ff ff       	call   3660 <fwrite@plt>
    4332:	48 83 3d e6 ad 01 00 	cmpq   $0x0,0x1ade6(%rip)        # 1f120 <ad_raw_checkpoint_count>
    4339:	00 
    433a:	74 75                	je     43b1 <ad_raw_report+0x1b1>
    433c:	4c 8b 05 fd ad 01 00 	mov    0x1adfd(%rip),%r8        # 1f140 <ad_raw_checkpoints>
    4343:	4c 8b 0d fe ad 01 00 	mov    0x1adfe(%rip),%r9        # 1f148 <ad_raw_checkpoints+0x8>
    434a:	48 8d 1d ef ad 01 00 	lea    0x1adef(%rip),%rbx        # 1f140 <ad_raw_checkpoints>
    4351:	48 8d 0d 14 6d 00 00 	lea    0x6d14(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    4358:	48 8b 05 f1 ad 01 00 	mov    0x1adf1(%rip),%rax        # 1f150 <ad_raw_checkpoints+0x10>
    435f:	4c 8d 25 ba 6c 00 00 	lea    0x6cba(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4366:	eb 1b                	jmp    4383 <ad_raw_report+0x183>
    4368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    436f:	00 
    4370:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4374:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4378:	48 83 c3 18          	add    $0x18,%rbx
    437c:	4c 89 e1             	mov    %r12,%rcx
    437f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4383:	48 83 ec 08          	sub    $0x8,%rsp
    4387:	be 02 00 00 00       	mov    $0x2,%esi
    438c:	48 83 c5 01          	add    $0x1,%rbp
    4390:	48 8b 3d a9 ac 00 00 	mov    0xaca9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4397:	50                   	push   %rax
    4398:	48 8d 15 11 74 00 00 	lea    0x7411(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    439f:	31 c0                	xor    %eax,%eax
    43a1:	e8 ca f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43a6:	48 3b 2d 73 ad 01 00 	cmp    0x1ad73(%rip),%rbp        # 1f120 <ad_raw_checkpoint_count>
    43ad:	59                   	pop    %rcx
    43ae:	5e                   	pop    %rsi
    43af:	72 bf                	jb     4370 <ad_raw_report+0x170>
    43b1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43bd:	00 00 
    43bf:	75 6a                	jne    442b <ad_raw_report+0x22b>
    43c1:	48 8b 0d 78 ac 00 00 	mov    0xac78(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43c8:	48 83 c4 38          	add    $0x38,%rsp
    43cc:	ba 04 00 00 00       	mov    $0x4,%edx
    43d1:	be 01 00 00 00       	mov    $0x1,%esi
    43d6:	5b                   	pop    %rbx
    43d7:	48 8d 3d 7b 6c 00 00 	lea    0x6c7b(%rip),%rdi        # b059 <_IO_stdin_used+0x59>
    43de:	5d                   	pop    %rbp
    43df:	41 5c                	pop    %r12
    43e1:	41 5d                	pop    %r13
    43e3:	41 5e                	pop    %r14
    43e5:	41 5f                	pop    %r15
    43e7:	e9 74 f2 ff ff       	jmp    3660 <fwrite@plt>
    43ec:	0f 1f 40 00          	nopl   0x0(%rax)
    43f0:	52                   	push   %rdx
    43f1:	be 02 00 00 00       	mov    $0x2,%esi
    43f6:	48 8b 3d 43 ac 00 00 	mov    0xac43(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43fd:	48 8d 15 6c 73 00 00 	lea    0x736c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    4404:	50                   	push   %rax
    4405:	48 8d 0d 60 6c 00 00 	lea    0x6c60(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    440c:	31 c0                	xor    %eax,%eax
    440e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4413:	e8 58 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4418:	58                   	pop    %rax
    4419:	5a                   	pop    %rdx
    441a:	e9 ac fe ff ff       	jmp    42cb <ad_raw_report+0xcb>
    441f:	48 8d 3d c2 72 00 00 	lea    0x72c2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4426:	e8 b5 fb ff ff       	call   3fe0 <ad_raw_fail>
    442b:	e8 20 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004430 <fwp_trap>:
    4430:	55                   	push   %rbp
    4431:	48 89 fd             	mov    %rdi,%rbp
    4434:	53                   	push   %rbx
    4435:	48 83 ec 08          	sub    $0x8,%rsp
    4439:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4440:	ff ff 
    4442:	e8 99 f8 ff ff       	call   3ce0 <fwp_flush>
    4447:	31 c0                	xor    %eax,%eax
    4449:	48 89 e9             	mov    %rbp,%rcx
    444c:	be 02 00 00 00       	mov    $0x2,%esi
    4451:	48 8b 3d e8 ab 00 00 	mov    0xabe8(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4458:	48 8d 15 ff 6b 00 00 	lea    0x6bff(%rip),%rdx        # b05e <_IO_stdin_used+0x5e>
    445f:	e8 0c f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4464:	48 85 db             	test   %rbx,%rbx
    4467:	74 16                	je     447f <fwp_trap+0x4f>
    4469:	48 8b 3d d0 ab 00 00 	mov    0xabd0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4470:	e8 2b f1 ff ff       	call   35a0 <fflush@plt>
    4475:	bf 65 00 00 00       	mov    $0x65,%edi
    447a:	e8 01 f2 ff ff       	call   3680 <_Exit@plt>
    447f:	bf 65 00 00 00       	mov    $0x65,%edi
    4484:	e8 c7 f1 ff ff       	call   3650 <exit@plt>
    4489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004490 <fwp_closure_drop_push>:
    4490:	41 56                	push   %r14
    4492:	41 54                	push   %r12
    4494:	49 89 f4             	mov    %rsi,%r12
    4497:	55                   	push   %rbp
    4498:	48 89 fd             	mov    %rdi,%rbp
    449b:	53                   	push   %rbx
    449c:	48 83 ec 18          	sub    $0x18,%rsp
    44a0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44a4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44a8:	74 26                	je     44d0 <fwp_closure_drop_push+0x40>
    44aa:	4c 8b 07             	mov    (%rdi),%r8
    44ad:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44b4:	00 
    44b5:	48 83 c3 01          	add    $0x1,%rbx
    44b9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44bd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44c1:	48 83 c4 18          	add    $0x18,%rsp
    44c5:	5b                   	pop    %rbx
    44c6:	5d                   	pop    %rbp
    44c7:	41 5c                	pop    %r12
    44c9:	41 5e                	pop    %r14
    44cb:	c3                   	ret
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)
    44d0:	48 89 d8             	mov    %rbx,%rax
    44d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44d7:	0f 85 a9 00 00 00    	jne    4586 <fwp_closure_drop_push+0xf6>
    44dd:	48 89 d9             	mov    %rbx,%rcx
    44e0:	48 c1 e1 04          	shl    $0x4,%rcx
    44e4:	48 89 cf             	mov    %rcx,%rdi
    44e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44eb:	e8 a0 f0 ff ff       	call   3590 <malloc@plt>
    44f0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44f4:	48 85 c0             	test   %rax,%rax
    44f7:	74 5f                	je     4558 <fwp_closure_drop_push+0xc8>
    44f9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44fd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4504:	00 
    4505:	48 89 c7             	mov    %rax,%rdi
    4508:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    450c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4511:	48 89 34 24          	mov    %rsi,(%rsp)
    4515:	e8 36 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    451a:	48 8b 34 24          	mov    (%rsp),%rsi
    451e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4523:	49 89 c0             	mov    %rax,%r8
    4526:	48 8d 45 18          	lea    0x18(%rbp),%rax
    452a:	48 39 c6             	cmp    %rax,%rsi
    452d:	74 1c                	je     454b <fwp_closure_drop_push+0xbb>
    452f:	48 89 f7             	mov    %rsi,%rdi
    4532:	4c 89 04 24          	mov    %r8,(%rsp)
    4536:	e8 75 ee ff ff       	call   33b0 <free@plt>
    453b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    453f:	4c 8b 04 24          	mov    (%rsp),%r8
    4543:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    454a:	00 
    454b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    454f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4553:	e9 5d ff ff ff       	jmp    44b5 <fwp_closure_drop_push+0x25>
    4558:	48 8b 0d e1 aa 00 00 	mov    0xaae1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    455f:	ba 13 00 00 00       	mov    $0x13,%edx
    4564:	be 01 00 00 00       	mov    $0x1,%esi
    4569:	48 8d 3d 98 6a 00 00 	lea    0x6a98(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4570:	e8 eb f0 ff ff       	call   3660 <fwrite@plt>
    4575:	31 ff                	xor    %edi,%edi
    4577:	e8 24 f0 ff ff       	call   35a0 <fflush@plt>
    457c:	bf 66 00 00 00       	mov    $0x66,%edi
    4581:	e8 fa f0 ff ff       	call   3680 <_Exit@plt>
    4586:	48 8d 3d e0 6a 00 00 	lea    0x6ae0(%rip),%rdi        # b06d <_IO_stdin_used+0x6d>
    458d:	e8 9e fe ff ff       	call   4430 <fwp_trap>
    4592:	0f 1f 00             	nopl   (%rax)
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    459c:	00 00 00 00 

00000000000045a0 <fwp_now_ns>:
    45a0:	53                   	push   %rbx
    45a1:	bf 01 00 00 00       	mov    $0x1,%edi
    45a6:	48 83 ec 20          	sub    $0x20,%rsp
    45aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45b1:	00 00 
    45b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45b8:	31 db                	xor    %ebx,%ebx
    45ba:	48 89 e6             	mov    %rsp,%rsi
    45bd:	e8 4e ee ff ff       	call   3410 <clock_gettime@plt>
    45c2:	85 c0                	test   %eax,%eax
    45c4:	75 52                	jne    4618 <fwp_now_ns+0x78>
    45c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45d0:	48 f7 2c 24          	imulq  (%rsp)
    45d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45db:	48 89 f7             	mov    %rsi,%rdi
    45de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45e2:	48 01 f0             	add    %rsi,%rax
    45e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ec:	00 00 80 
    45ef:	48 11 fa             	adc    %rdi,%rdx
    45f2:	31 ff                	xor    %edi,%edi
    45f4:	48 01 c6             	add    %rax,%rsi
    45f7:	48 11 d7             	adc    %rdx,%rdi
    45fa:	48 39 f1             	cmp    %rsi,%rcx
    45fd:	48 19 fb             	sbb    %rdi,%rbx
    4600:	72 27                	jb     4629 <fwp_now_ns+0x89>
    4602:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4607:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    460e:	00 00 
    4610:	75 12                	jne    4624 <fwp_now_ns+0x84>
    4612:	48 83 c4 20          	add    $0x20,%rsp
    4616:	5b                   	pop    %rbx
    4617:	c3                   	ret
    4618:	48 8d 3d 68 6a 00 00 	lea    0x6a68(%rip),%rdi        # b087 <_IO_stdin_used+0x87>
    461f:	e8 0c fe ff ff       	call   4430 <fwp_trap>
    4624:	e8 27 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4629:	48 8d 3d c0 71 00 00 	lea    0x71c0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4630:	e8 fb fd ff ff       	call   4430 <fwp_trap>
    4635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    463c:	00 00 00 00 

0000000000004640 <fwp_closure_drop.part.0>:
    4640:	53                   	push   %rbx
    4641:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4648:	66 0f 6f 05 40 76 00 	movdqa 0x7640(%rip),%xmm0        # bc90 <msg.8+0x20>
    464f:	00 
    4650:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4657:	00 00 
    4659:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4660:	00 
    4661:	48 89 fe             	mov    %rdi,%rsi
    4664:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4669:	48 89 e7             	mov    %rsp,%rdi
    466c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4670:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4675:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    467c:	ff ff 
    467e:	e8 0d fe ff ff       	call   4490 <fwp_closure_drop_push>
    4683:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4688:	48 85 c0             	test   %rax,%rax
    468b:	74 39                	je     46c6 <fwp_closure_drop.part.0+0x86>
    468d:	0f 1f 00             	nopl   (%rax)
    4690:	48 8b 14 24          	mov    (%rsp),%rdx
    4694:	48 83 e8 01          	sub    $0x1,%rax
    4698:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    469d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46a1:	8b 07                	mov    (%rdi),%eax
    46a3:	48 c1 e0 05          	shl    $0x5,%rax
    46a7:	48 03 05 ea 4d 06 00 	add    0x64dea(%rip),%rax        # 69498 <fwp_fns>
    46ae:	48 8b 40 18          	mov    0x18(%rax),%rax
    46b2:	48 85 c0             	test   %rax,%rax
    46b5:	74 46                	je     46fd <fwp_closure_drop.part.0+0xbd>
    46b7:	31 f6                	xor    %esi,%esi
    46b9:	ff 50 08             	call   *0x8(%rax)
    46bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46c1:	48 85 c0             	test   %rax,%rax
    46c4:	75 ca                	jne    4690 <fwp_closure_drop.part.0+0x50>
    46c6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46cd:	ff ff 00 00 00 00 
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	48 39 df             	cmp    %rbx,%rdi
    46da:	74 05                	je     46e1 <fwp_closure_drop.part.0+0xa1>
    46dc:	e8 cf ec ff ff       	call   33b0 <free@plt>
    46e1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46e8:	00 
    46e9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46f0:	00 00 
    46f2:	75 15                	jne    4709 <fwp_closure_drop.part.0+0xc9>
    46f4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46fb:	5b                   	pop    %rbx
    46fc:	c3                   	ret
    46fd:	48 8d 3d 14 71 00 00 	lea    0x7114(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    4704:	e8 27 fd ff ff       	call   4430 <fwp_trap>
    4709:	e8 42 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    470e:	66 90                	xchg   %ax,%ax

0000000000004710 <fwp_tape_of>:
    4710:	0f b7 d7             	movzwl %di,%edx
    4713:	48 85 d2             	test   %rdx,%rdx
    4716:	74 28                	je     4740 <fwp_tape_of+0x30>
    4718:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    471c:	48 39 05 e5 a9 01 00 	cmp    %rax,0x1a9e5(%rip)        # 1f108 <fwp_ntapes>
    4723:	7e 1b                	jle    4740 <fwp_tape_of+0x30>
    4725:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4729:	48 03 05 e0 a9 01 00 	add    0x1a9e0(%rip),%rax        # 1f110 <fwp_tapes>
    4730:	8b 50 04             	mov    0x4(%rax),%edx
    4733:	85 d2                	test   %edx,%edx
    4735:	74 09                	je     4740 <fwp_tape_of+0x30>
    4737:	48 c1 ff 10          	sar    $0x10,%rdi
    473b:	39 38                	cmp    %edi,(%rax)
    473d:	75 01                	jne    4740 <fwp_tape_of+0x30>
    473f:	c3                   	ret
    4740:	48 83 ec 08          	sub    $0x8,%rsp
    4744:	48 8d 3d fd 70 00 00 	lea    0x70fd(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    474b:	e8 e0 fc ff ff       	call   4430 <fwp_trap>

0000000000004750 <fwp_format_g.constprop.0>:
    4750:	41 57                	push   %r15
    4752:	b9 40 00 00 00       	mov    $0x40,%ecx
    4757:	ba 02 00 00 00       	mov    $0x2,%edx
    475c:	4c 8d 05 40 69 00 00 	lea    0x6940(%rip),%r8        # b0a3 <_IO_stdin_used+0xa3>
    4763:	41 56                	push   %r14
    4765:	b8 01 00 00 00       	mov    $0x1,%eax
    476a:	41 55                	push   %r13
    476c:	41 54                	push   %r12
    476e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4772:	55                   	push   %rbp
    4773:	45 89 e1             	mov    %r12d,%r9d
    4776:	53                   	push   %rbx
    4777:	48 89 fb             	mov    %rdi,%rbx
    477a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4781:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4788:	00 00 
    478a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4791:	00 
    4792:	41 89 f7             	mov    %esi,%r15d
    4795:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    479a:	be 40 00 00 00       	mov    $0x40,%esi
    479f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47a4:	4c 89 f7             	mov    %r14,%rdi
    47a7:	e8 f4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47ac:	be 65 00 00 00       	mov    $0x65,%esi
    47b1:	4c 89 f7             	mov    %r14,%rdi
    47b4:	e8 b7 ec ff ff       	call   3470 <strchr@plt>
    47b9:	31 f6                	xor    %esi,%esi
    47bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    47c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47c4:	48 89 c5             	mov    %rax,%rbp
    47c7:	e8 a4 ed ff ff       	call   3570 <strtol@plt>
    47cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47d1:	49 89 c0             	mov    %rax,%r8
    47d4:	83 c0 05             	add    $0x5,%eax
    47d7:	83 f8 15             	cmp    $0x15,%eax
    47da:	0f 87 e0 01 00 00    	ja     49c0 <fwp_format_g.constprop.0+0x270>
    47e0:	45 89 e5             	mov    %r12d,%r13d
    47e3:	45 29 c5             	sub    %r8d,%r13d
    47e6:	45 85 ed             	test   %r13d,%r13d
    47e9:	0f 8e 21 01 00 00    	jle    4910 <fwp_format_g.constprop.0+0x1c0>
    47ef:	41 83 ff 01          	cmp    $0x1,%r15d
    47f3:	0f 84 17 01 00 00    	je     4910 <fwp_format_g.constprop.0+0x1c0>
    47f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47fe:	31 d2                	xor    %edx,%edx
    4800:	4d 63 df             	movslq %r15d,%r11
    4803:	3c 2d                	cmp    $0x2d,%al
    4805:	0f 94 c2             	sete   %dl
    4808:	4c 29 dd             	sub    %r11,%rbp
    480b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    480f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4813:	4d 89 f1             	mov    %r14,%r9
    4816:	4d 29 d1             	sub    %r10,%r9
    4819:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    481d:	3c 2d                	cmp    $0x2d,%al
    481f:	0f 84 fb 03 00 00    	je     4c20 <fwp_format_g.constprop.0+0x4d0>
    4825:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    482a:	b9 48 00 00 00       	mov    $0x48,%ecx
    482f:	48 89 e8             	mov    %rbp,%rax
    4832:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4836:	49 8d 72 01          	lea    0x1(%r10),%rsi
    483a:	49 83 c1 47          	add    $0x47,%r9
    483e:	45 85 c0             	test   %r8d,%r8d
    4841:	0f 88 f1 02 00 00    	js     4b38 <fwp_format_g.constprop.0+0x3e8>
    4847:	45 0f b6 12          	movzbl (%r10),%r10d
    484b:	4d 63 e0             	movslq %r8d,%r12
    484e:	44 88 10             	mov    %r10b,(%rax)
    4851:	41 83 f8 07          	cmp    $0x7,%r8d
    4855:	0f 87 2d 02 00 00    	ja     4a88 <fwp_format_g.constprop.0+0x338>
    485b:	41 f6 c4 04          	test   $0x4,%r12b
    485f:	0f 85 f2 03 00 00    	jne    4c57 <fwp_format_g.constprop.0+0x507>
    4865:	45 85 e4             	test   %r12d,%r12d
    4868:	74 12                	je     487c <fwp_format_g.constprop.0+0x12c>
    486a:	45 0f b6 06          	movzbl (%r14),%r8d
    486e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4872:	41 f6 c4 02          	test   $0x2,%r12b
    4876:	0f 85 03 04 00 00    	jne    4c7f <fwp_format_g.constprop.0+0x52f>
    487c:	4c 29 e1             	sub    %r12,%rcx
    487f:	4c 01 e7             	add    %r12,%rdi
    4882:	4c 89 fa             	mov    %r15,%rdx
    4885:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488a:	48 83 e9 01          	sub    $0x1,%rcx
    488e:	4d 63 ed             	movslq %r13d,%r13
    4891:	48 89 0c 24          	mov    %rcx,(%rsp)
    4895:	e8 b6 ec ff ff       	call   3550 <__memcpy_chk@plt>
    489a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    489f:	48 8b 0c 24          	mov    (%rsp),%rcx
    48a3:	ba 48 00 00 00       	mov    $0x48,%edx
    48a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48b0:	4c 89 c8             	mov    %r9,%rax
    48b3:	48 29 c8             	sub    %rcx,%rax
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48bd:	4c 29 c9             	sub    %r9,%rcx
    48c0:	4c 89 ea             	mov    %r13,%rdx
    48c3:	48 01 c1             	add    %rax,%rcx
    48c6:	e8 85 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	48 29 e8             	sub    %rbp,%rax
    48d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 47 c2          	cmova  %rdx,%rax
    48dd:	89 c1                	mov    %eax,%ecx
    48df:	83 f8 08             	cmp    $0x8,%eax
    48e2:	0f 83 18 02 00 00    	jae    4b00 <fwp_format_g.constprop.0+0x3b0>
    48e8:	a8 04                	test   $0x4,%al
    48ea:	0f 85 54 03 00 00    	jne    4c44 <fwp_format_g.constprop.0+0x4f4>
    48f0:	85 c0                	test   %eax,%eax
    48f2:	74 0f                	je     4903 <fwp_format_g.constprop.0+0x1b3>
    48f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48f9:	88 13                	mov    %dl,(%rbx)
    48fb:	a8 02                	test   $0x2,%al
    48fd:	0f 85 6b 03 00 00    	jne    4c6e <fwp_format_g.constprop.0+0x51e>
    4903:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4907:	eb 36                	jmp    493f <fwp_format_g.constprop.0+0x1ef>
    4909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4910:	45 31 c9             	xor    %r9d,%r9d
    4913:	45 85 ed             	test   %r13d,%r13d
    4916:	4c 8d 05 95 67 00 00 	lea    0x6795(%rip),%r8        # b0b2 <_IO_stdin_used+0xb2>
    491d:	48 89 df             	mov    %rbx,%rdi
    4920:	45 0f 49 cd          	cmovns %r13d,%r9d
    4924:	ba 02 00 00 00       	mov    $0x2,%edx
    4929:	be 90 01 00 00       	mov    $0x190,%esi
    492e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4935:	b8 01 00 00 00       	mov    $0x1,%eax
    493a:	e8 61 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    493f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4944:	48 89 df             	mov    %rbx,%rdi
    4947:	e8 24 eb ff ff       	call   3470 <strchr@plt>
    494c:	48 85 c0             	test   %rax,%rax
    494f:	74 3f                	je     4990 <fwp_format_g.constprop.0+0x240>
    4951:	48 89 df             	mov    %rbx,%rdi
    4954:	e8 e7 ea ff ff       	call   3440 <strlen@plt>
    4959:	48 85 c0             	test   %rax,%rax
    495c:	75 0b                	jne    4969 <fwp_format_g.constprop.0+0x219>
    495e:	eb 30                	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4960:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4964:	48 85 c0             	test   %rax,%rax
    4967:	74 27                	je     4990 <fwp_format_g.constprop.0+0x240>
    4969:	48 89 c2             	mov    %rax,%rdx
    496c:	48 83 e8 01          	sub    $0x1,%rax
    4970:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4974:	74 ea                	je     4960 <fwp_format_g.constprop.0+0x210>
    4976:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    497b:	0f 84 6f 01 00 00    	je     4af0 <fwp_format_g.constprop.0+0x3a0>
    4981:	0f 1f 40 00          	nopl   0x0(%rax)
    4985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    498c:	00 00 00 00 
    4990:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4997:	00 
    4998:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    499f:	00 00 
    49a1:	0f 85 ec 02 00 00    	jne    4c93 <fwp_format_g.constprop.0+0x543>
    49a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ae:	5b                   	pop    %rbx
    49af:	5d                   	pop    %rbp
    49b0:	41 5c                	pop    %r12
    49b2:	41 5d                	pop    %r13
    49b4:	41 5e                	pop    %r14
    49b6:	41 5f                	pop    %r15
    49b8:	c3                   	ret
    49b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49c0:	4c 29 f5             	sub    %r14,%rbp
    49c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49c8:	4c 89 f6             	mov    %r14,%rsi
    49cb:	4c 89 04 24          	mov    %r8,(%rsp)
    49cf:	49 89 ec             	mov    %rbp,%r12
    49d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49d7:	4c 89 e2             	mov    %r12,%rdx
    49da:	48 89 ef             	mov    %rbp,%rdi
    49dd:	e8 6e eb ff ff       	call   3550 <__memcpy_chk@plt>
    49e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ed:	48 89 ef             	mov    %rbp,%rdi
    49f0:	e8 7b ea ff ff       	call   3470 <strchr@plt>
    49f5:	4c 8b 04 24          	mov    (%rsp),%r8
    49f9:	48 85 c0             	test   %rax,%rax
    49fc:	74 40                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    49fe:	4d 85 e4             	test   %r12,%r12
    4a01:	74 3b                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a03:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a08:	eb 23                	jmp    4a2d <fwp_format_g.constprop.0+0x2dd>
    4a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a11:	00 00 00 00 
    4a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a1c:	00 00 00 00 
    4a20:	c6 00 00             	movb   $0x0,(%rax)
    4a23:	48 83 e8 01          	sub    $0x1,%rax
    4a27:	49 83 ec 01          	sub    $0x1,%r12
    4a2b:	74 11                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a2d:	80 38 30             	cmpb   $0x30,(%rax)
    4a30:	74 ee                	je     4a20 <fwp_format_g.constprop.0+0x2d0>
    4a32:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a38:	0f 84 fb 01 00 00    	je     4c39 <fwp_format_g.constprop.0+0x4e9>
    4a3e:	44 89 c0             	mov    %r8d,%eax
    4a41:	ba 02 00 00 00       	mov    $0x2,%edx
    4a46:	49 89 e9             	mov    %rbp,%r9
    4a49:	be 90 01 00 00       	mov    $0x190,%esi
    4a4e:	f7 d8                	neg    %eax
    4a50:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a57:	48 89 df             	mov    %rbx,%rdi
    4a5a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a5e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a62:	41 83 e0 02          	and    $0x2,%r8d
    4a66:	41 83 c0 2b          	add    $0x2b,%r8d
    4a6a:	50                   	push   %rax
    4a6b:	31 c0                	xor    %eax,%eax
    4a6d:	41 50                	push   %r8
    4a6f:	4c 8d 05 32 66 00 00 	lea    0x6632(%rip),%r8        # b0a8 <_IO_stdin_used+0xa8>
    4a76:	e8 25 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a7b:	58                   	pop    %rax
    4a7c:	5a                   	pop    %rdx
    4a7d:	e9 0e ff ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a88:	4d 8b 06             	mov    (%r14),%r8
    4a8b:	48 83 c0 09          	add    $0x9,%rax
    4a8f:	4c 89 f2             	mov    %r14,%rdx
    4a92:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a96:	4c 89 07             	mov    %r8,(%rdi)
    4a99:	45 89 e0             	mov    %r12d,%r8d
    4a9c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4aa1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4aa6:	49 89 f8             	mov    %rdi,%r8
    4aa9:	49 29 c0             	sub    %rax,%r8
    4aac:	4c 29 c2             	sub    %r8,%rdx
    4aaf:	45 01 e0             	add    %r12d,%r8d
    4ab2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ab6:	41 83 f8 08          	cmp    $0x8,%r8d
    4aba:	0f 82 bc fd ff ff    	jb     487c <fwp_format_g.constprop.0+0x12c>
    4ac0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ac4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ac8:	45 31 d2             	xor    %r10d,%r10d
    4acb:	45 89 d3             	mov    %r10d,%r11d
    4ace:	41 83 c2 08          	add    $0x8,%r10d
    4ad2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ad6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4ada:	45 39 c2             	cmp    %r8d,%r10d
    4add:	72 ec                	jb     4acb <fwp_format_g.constprop.0+0x37b>
    4adf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ae3:	e9 94 fd ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aef:	00 
    4af0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4af5:	e9 96 fe ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b00:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b05:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b09:	48 89 ee             	mov    %rbp,%rsi
    4b0c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b10:	48 89 13             	mov    %rdx,(%rbx)
    4b13:	89 c2                	mov    %eax,%edx
    4b15:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b1a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b1f:	48 89 d9             	mov    %rbx,%rcx
    4b22:	48 29 f9             	sub    %rdi,%rcx
    4b25:	48 29 ce             	sub    %rcx,%rsi
    4b28:	01 c1                	add    %eax,%ecx
    4b2a:	c1 e9 03             	shr    $0x3,%ecx
    4b2d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b30:	e9 ce fd ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4b35:	0f 1f 00             	nopl   (%rax)
    4b38:	c6 00 30             	movb   $0x30,(%rax)
    4b3b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b3f:	4c 89 fa             	mov    %r15,%rdx
    4b42:	4c 89 e9             	mov    %r13,%rcx
    4b45:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b4a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b4f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b53:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b58:	e8 f3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b5d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b62:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b6c:	48 89 c7             	mov    %rax,%rdi
    4b6f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b73:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b78:	4c 89 c8             	mov    %r9,%rax
    4b7b:	4c 29 e8             	sub    %r13,%rax
    4b7e:	48 39 c8             	cmp    %rcx,%rax
    4b81:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b85:	4d 29 cd             	sub    %r9,%r13
    4b88:	49 01 ff             	add    %rdi,%r15
    4b8b:	4c 01 e8             	add    %r13,%rax
    4b8e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b92:	74 3d                	je     4bd1 <fwp_format_g.constprop.0+0x481>
    4b94:	41 f7 d0             	not    %r8d
    4b97:	31 f6                	xor    %esi,%esi
    4b99:	ba 48 00 00 00       	mov    $0x48,%edx
    4b9e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4ba3:	48 39 d0             	cmp    %rdx,%rax
    4ba6:	48 0f 43 d0          	cmovae %rax,%rdx
    4baa:	48 89 d1             	mov    %rdx,%rcx
    4bad:	48 29 c1             	sub    %rax,%rcx
    4bb0:	48 83 c1 01          	add    $0x1,%rcx
    4bb4:	48 39 d1             	cmp    %rdx,%rcx
    4bb7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bbb:	48 83 e8 01          	sub    $0x1,%rax
    4bbf:	48 83 c6 01          	add    $0x1,%rsi
    4bc3:	48 29 d0             	sub    %rdx,%rax
    4bc6:	48 01 c8             	add    %rcx,%rax
    4bc9:	41 39 f0             	cmp    %esi,%r8d
    4bcc:	7f cb                	jg     4b99 <fwp_format_g.constprop.0+0x449>
    4bce:	4d 01 c7             	add    %r8,%r15
    4bd1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bd6:	41 0f b6 12          	movzbl (%r10),%edx
    4bda:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bde:	4c 89 f6             	mov    %r14,%rsi
    4be1:	48 39 c8             	cmp    %rcx,%rax
    4be4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4be8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bec:	41 88 17             	mov    %dl,(%r15)
    4bef:	48 89 ca             	mov    %rcx,%rdx
    4bf2:	48 29 c2             	sub    %rax,%rdx
    4bf5:	48 83 c2 01          	add    $0x1,%rdx
    4bf9:	48 39 ca             	cmp    %rcx,%rdx
    4bfc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c00:	48 83 e8 01          	sub    $0x1,%rax
    4c04:	48 29 c8             	sub    %rcx,%rax
    4c07:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c0b:	49 63 d4             	movslq %r12d,%rdx
    4c0e:	e8 3d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c13:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c17:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c1b:	e9 ae fc ff ff       	jmp    48ce <fwp_format_g.constprop.0+0x17e>
    4c20:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c25:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c2a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c2f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c34:	e9 f9 fb ff ff       	jmp    4832 <fwp_format_g.constprop.0+0xe2>
    4c39:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c3f:	e9 fa fd ff ff       	jmp    4a3e <fwp_format_g.constprop.0+0x2ee>
    4c44:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c48:	89 13                	mov    %edx,(%rbx)
    4c4a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c4e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c52:	e9 ac fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c57:	41 8b 06             	mov    (%r14),%eax
    4c5a:	89 07                	mov    %eax,(%rdi)
    4c5c:	44 89 e0             	mov    %r12d,%eax
    4c5f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c64:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c69:	e9 0e fc ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c6e:	89 c2                	mov    %eax,%edx
    4c70:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c75:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c7a:	e9 84 fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c7f:	44 89 e0             	mov    %r12d,%eax
    4c82:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c88:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c8e:	e9 e9 fb ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c93:	e8 b8 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c9f:	00 

0000000000004ca0 <fwp_heap_report>:
    4ca0:	f3 0f 1e fa          	endbr64
    4ca4:	41 54                	push   %r12
    4ca6:	48 8d 3d 0a 64 00 00 	lea    0x640a(%rip),%rdi        # b0b7 <_IO_stdin_used+0xb7>
    4cad:	55                   	push   %rbp
    4cae:	53                   	push   %rbx
    4caf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cb6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cbd:	00 00 
    4cbf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4cc6:	00 
    4cc7:	48 8d 35 74 65 00 00 	lea    0x6574(%rip),%rsi        # b242 <_IO_stdin_used+0x242>
    4cce:	e8 3d e9 ff ff       	call   3610 <fopen@plt>
    4cd3:	48 85 c0             	test   %rax,%rax
    4cd6:	0f 84 c5 00 00 00    	je     4da1 <fwp_heap_report+0x101>
    4cdc:	48 89 c5             	mov    %rax,%rbp
    4cdf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ce6:	48 89 e3             	mov    %rsp,%rbx
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 89 ea             	mov    %rbp,%rdx
    4cf3:	be 00 01 00 00       	mov    $0x100,%esi
    4cf8:	48 89 df             	mov    %rbx,%rdi
    4cfb:	e8 f0 e7 ff ff       	call   34f0 <fgets@plt>
    4d00:	48 85 c0             	test   %rax,%rax
    4d03:	74 2b                	je     4d30 <fwp_heap_report+0x90>
    4d05:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d0b:	75 e3                	jne    4cf0 <fwp_heap_report+0x50>
    4d0d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d11:	75 dd                	jne    4cf0 <fwp_heap_report+0x50>
    4d13:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d18:	75 d6                	jne    4cf0 <fwp_heap_report+0x50>
    4d1a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d1f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d24:	31 f6                	xor    %esi,%esi
    4d26:	e8 45 e8 ff ff       	call   3570 <strtol@plt>
    4d2b:	49 89 c4             	mov    %rax,%r12
    4d2e:	eb c0                	jmp    4cf0 <fwp_heap_report+0x50>
    4d30:	48 89 ef             	mov    %rbp,%rdi
    4d33:	e8 f8 e6 ff ff       	call   3430 <fclose@plt>
    4d38:	48 83 ec 08          	sub    $0x8,%rsp
    4d3c:	4c 8b 0d c5 3e 06 00 	mov    0x63ec5(%rip),%r9        # 68c08 <fwp_heap+0x13c8>
    4d43:	4c 8b 05 1e 3f 06 00 	mov    0x63f1e(%rip),%r8        # 68c68 <fwp_heap+0x1428>
    4d4a:	48 8d 15 47 6b 00 00 	lea    0x6b47(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d51:	41 54                	push   %r12
    4d53:	48 8b 0d 06 3f 06 00 	mov    0x63f06(%rip),%rcx        # 68c60 <fwp_heap+0x1420>
    4d5a:	be 02 00 00 00       	mov    $0x2,%esi
    4d5f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d64:	f2 0f 10 0d 14 3f 06 	movsd  0x63f14(%rip),%xmm1        # 68c80 <fwp_heap+0x1440>
    4d6b:	00 
    4d6c:	f2 0f 10 05 04 3f 06 	movsd  0x63f04(%rip),%xmm0        # 68c78 <fwp_heap+0x1438>
    4d73:	00 
    4d74:	48 8b 3d c5 a2 00 00 	mov    0xa2c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d7b:	e8 f0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4d80:	58                   	pop    %rax
    4d81:	5a                   	pop    %rdx
    4d82:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d89:	00 
    4d8a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d91:	00 00 
    4d93:	75 15                	jne    4daa <fwp_heap_report+0x10a>
    4d95:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d9c:	5b                   	pop    %rbx
    4d9d:	5d                   	pop    %rbp
    4d9e:	41 5c                	pop    %r12
    4da0:	c3                   	ret
    4da1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4da8:	eb 8e                	jmp    4d38 <fwp_heap_report+0x98>
    4daa:	e8 a1 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4daf:	90                   	nop

0000000000004db0 <fwp_heap_init>:
    4db0:	66 0f 6f 05 e8 6e 00 	movdqa 0x6ee8(%rip),%xmm0        # bca0 <msg.8+0x30>
    4db7:	00 
    4db8:	41 54                	push   %r12
    4dba:	48 8d 05 bf 39 06 00 	lea    0x639bf(%rip),%rax        # 68780 <fwp_heap+0xf40>
    4dc1:	ba 00 01 00 00       	mov    $0x100,%edx
    4dc6:	55                   	push   %rbp
    4dc7:	66 0f 6f 15 11 6f 00 	movdqa 0x6f11(%rip),%xmm2        # bce0 <msg.8+0x70>
    4dce:	00 
    4dcf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4dd3:	53                   	push   %rbx
    4dd4:	0f 29 05 65 39 06 00 	movaps %xmm0,0x63965(%rip)        # 68740 <fwp_heap+0xf00>
    4ddb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # bcb0 <msg.8+0x40>
    4de2:	00 
    4de3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4de7:	c7 05 f3 3d 06 00 01 	movl   $0x1,0x63df3(%rip)        # 68be4 <fwp_heap+0x13a4>
    4dee:	00 00 00 
    4df1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4df6:	0f 29 05 53 39 06 00 	movaps %xmm0,0x63953(%rip)        # 68750 <fwp_heap+0xf10>
    4dfd:	66 0f 6f 05 bb 6e 00 	movdqa 0x6ebb(%rip),%xmm0        # bcc0 <msg.8+0x50>
    4e04:	00 
    4e05:	0f 29 05 54 39 06 00 	movaps %xmm0,0x63954(%rip)        # 68760 <fwp_heap+0xf20>
    4e0c:	66 0f 6f 05 bc 6e 00 	movdqa 0x6ebc(%rip),%xmm0        # bcd0 <msg.8+0x60>
    4e13:	00 
    4e14:	0f 29 05 55 39 06 00 	movaps %xmm0,0x63955(%rip)        # 68770 <fwp_heap+0xf30>
    4e1b:	89 d3                	mov    %edx,%ebx
    4e1d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e21:	48 83 c0 10          	add    $0x10,%rax
    4e25:	01 d2                	add    %edx,%edx
    4e27:	c1 eb 02             	shr    $0x2,%ebx
    4e2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e5f:	48 39 c7             	cmp    %rax,%rdi
    4e62:	75 b7                	jne    4e1b <fwp_heap_init+0x6b>
    4e64:	4c 8d 05 d5 29 06 00 	lea    0x629d5(%rip),%r8        # 67840 <fwp_heap>
    4e6b:	31 c9                	xor    %ecx,%ecx
    4e6d:	31 c0                	xor    %eax,%eax
    4e6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e7d:	00 00 00 
    4e80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e87:	00 
    4e88:	48 39 ca             	cmp    %rcx,%rdx
    4e8b:	73 0f                	jae    4e9c <fwp_heap_init+0xec>
    4e8d:	0f 1f 00             	nopl   (%rax)
    4e90:	48 83 c0 01          	add    $0x1,%rax
    4e94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e97:	48 39 ca             	cmp    %rcx,%rdx
    4e9a:	72 f4                	jb     4e90 <fwp_heap_init+0xe0>
    4e9c:	48 83 c1 10          	add    $0x10,%rcx
    4ea0:	88 07                	mov    %al,(%rdi)
    4ea2:	48 83 c7 01          	add    $0x1,%rdi
    4ea6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ead:	75 d1                	jne    4e80 <fwp_heap_init+0xd0>
    4eaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4eb6:	00 00 00 
    4eb9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ebe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ec5:	45 31 c9             	xor    %r9d,%r9d
    4ec8:	31 d2                	xor    %edx,%edx
    4eca:	31 ff                	xor    %edi,%edi
    4ecc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ed2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ed7:	4c 89 e6             	mov    %r12,%rsi
    4eda:	e8 81 e5 ff ff       	call   3460 <mmap@plt>
    4edf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ee3:	75 13                	jne    4ef8 <fwp_heap_init+0x148>
    4ee5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ee9:	83 ed 01             	sub    $0x1,%ebp
    4eec:	75 d0                	jne    4ebe <fwp_heap_init+0x10e>
    4eee:	e8 1d ef ff ff       	call   3e10 <fwp_heap_oom>
    4ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ef8:	48 85 c0             	test   %rax,%rax
    4efb:	74 f1                	je     4eee <fwp_heap_init+0x13e>
    4efd:	48 c1 eb 10          	shr    $0x10,%rbx
    4f01:	48 89 05 f0 3c 06 00 	mov    %rax,0x63cf0(%rip)        # 68bf8 <fwp_heap+0x13b8>
    4f08:	45 31 c9             	xor    %r9d,%r9d
    4f0b:	31 d2                	xor    %edx,%edx
    4f0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f17:	31 ff                	xor    %edi,%edi
    4f19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f1f:	66 31 c0             	xor    %ax,%ax
    4f22:	48 c1 e6 03          	shl    $0x3,%rsi
    4f26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f2b:	4c 89 25 ce 3c 06 00 	mov    %r12,0x63cce(%rip)        # 68c00 <fwp_heap+0x13c0>
    4f32:	48 89 05 b7 3c 06 00 	mov    %rax,0x63cb7(%rip)        # 68bf0 <fwp_heap+0x13b0>
    4f39:	48 89 1d d0 3c 06 00 	mov    %rbx,0x63cd0(%rip)        # 68c10 <fwp_heap+0x13d0>
    4f40:	48 89 35 f9 3c 06 00 	mov    %rsi,0x63cf9(%rip)        # 68c40 <fwp_heap+0x1400>
    4f47:	e8 14 e5 ff ff       	call   3460 <mmap@plt>
    4f4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f50:	74 9c                	je     4eee <fwp_heap_init+0x13e>
    4f52:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # b0ed <_IO_stdin_used+0xed>
    4f59:	48 89 05 d8 3c 06 00 	mov    %rax,0x63cd8(%rip)        # 68c38 <fwp_heap+0x13f8>
    4f60:	e8 2b e4 ff ff       	call   3390 <getenv@plt>
    4f65:	48 89 c2             	mov    %rax,%rdx
    4f68:	31 c0                	xor    %eax,%eax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 15                	je     4f84 <fwp_heap_init+0x1d4>
    4f6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f72:	74 10                	je     4f84 <fwp_heap_init+0x1d4>
    4f74:	0f b6 02             	movzbl (%rdx),%eax
    4f77:	83 e8 30             	sub    $0x30,%eax
    4f7a:	74 13                	je     4f8f <fwp_heap_init+0x1df>
    4f7c:	85 c0                	test   %eax,%eax
    4f7e:	0f 95 c0             	setne  %al
    4f81:	0f b6 c0             	movzbl %al,%eax
    4f84:	5b                   	pop    %rbx
    4f85:	5d                   	pop    %rbp
    4f86:	89 05 5c 3c 06 00    	mov    %eax,0x63c5c(%rip)        # 68be8 <fwp_heap+0x13a8>
    4f8c:	41 5c                	pop    %r12
    4f8e:	c3                   	ret
    4f8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f93:	85 c0                	test   %eax,%eax
    4f95:	0f 95 c0             	setne  %al
    4f98:	0f b6 c0             	movzbl %al,%eax
    4f9b:	eb e7                	jmp    4f84 <fwp_heap_init+0x1d4>
    4f9d:	0f 1f 00             	nopl   (%rax)

0000000000004fa0 <caf75>:
    4fa0:	8b 15 d2 a0 00 00    	mov    0xa0d2(%rip),%edx        # f078 <st.4>
    4fa6:	85 d2                	test   %edx,%edx
    4fa8:	74 0e                	je     4fb8 <caf75+0x18>
    4faa:	48 8b 05 bf a0 00 00 	mov    0xa0bf(%rip),%rax        # f070 <v.3>
    4fb1:	c3                   	ret
    4fb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fb8:	8b 05 aa a0 00 00    	mov    0xa0aa(%rip),%eax        # f068 <st.2>
    4fbe:	85 c0                	test   %eax,%eax
    4fc0:	74 1e                	je     4fe0 <caf75+0x40>
    4fc2:	48 8b 05 97 a0 00 00 	mov    0xa097(%rip),%rax        # f060 <v.1>
    4fc9:	48 89 05 a0 a0 00 00 	mov    %rax,0xa0a0(%rip)        # f070 <v.3>
    4fd0:	c7 05 9e a0 00 00 01 	movl   $0x1,0xa09e(%rip)        # f078 <st.4>
    4fd7:	00 00 00 
    4fda:	c3                   	ret
    4fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fe0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fe7:	00 f0 3f 
    4fea:	c7 05 74 a0 00 00 01 	movl   $0x1,0xa074(%rip)        # f068 <st.2>
    4ff1:	00 00 00 
    4ff4:	48 89 05 65 a0 00 00 	mov    %rax,0xa065(%rip)        # f060 <v.1>
    4ffb:	eb cc                	jmp    4fc9 <caf75+0x29>
    4ffd:	0f 1f 00             	nopl   (%rax)

0000000000005000 <fwp_wake_io>:
    5000:	48 8b 07             	mov    (%rdi),%rax
    5003:	48 85 c0             	test   %rax,%rax
    5006:	0f 84 f4 00 00 00    	je     5100 <fwp_wake_io+0x100>
    500c:	53                   	push   %rbx
    500d:	4c 8b 05 ec 27 06 00 	mov    0x627ec(%rip),%r8        # 67800 <fwp_ready_tail>
    5014:	49 89 f9             	mov    %rdi,%r9
    5017:	48 89 c2             	mov    %rax,%rdx
    501a:	45 31 db             	xor    %r11d,%r11d
    501d:	45 31 d2             	xor    %r10d,%r10d
    5020:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5024:	eb 71                	jmp    5097 <fwp_wake_io+0x97>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    5037:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    503e:	48 85 c9             	test   %rcx,%rcx
    5041:	74 07                	je     504a <fwp_wake_io+0x4a>
    5043:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    504a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5051:	00 00 00 00 
    5055:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    505c:	49 8b 01             	mov    (%r9),%rax
    505f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5063:	75 2a                	jne    508f <fwp_wake_io+0x8f>
    5065:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5069:	75 24                	jne    508f <fwp_wake_io+0x8f>
    506b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    506f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5076:	00 00 00 00 
    507a:	4d 85 c0             	test   %r8,%r8
    507d:	74 51                	je     50d0 <fwp_wake_io+0xd0>
    507f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5086:	49 89 d0             	mov    %rdx,%r8
    5089:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    508f:	48 89 c2             	mov    %rax,%rdx
    5092:	48 85 c0             	test   %rax,%rax
    5095:	74 49                	je     50e0 <fwp_wake_io+0xe0>
    5097:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    509e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    50a2:	48 85 ff             	test   %rdi,%rdi
    50a5:	74 b8                	je     505f <fwp_wake_io+0x5f>
    50a7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    50ae:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    50b5:	48 85 f6             	test   %rsi,%rsi
    50b8:	0f 85 72 ff ff ff    	jne    5030 <fwp_wake_io+0x30>
    50be:	48 89 0f             	mov    %rcx,(%rdi)
    50c1:	e9 78 ff ff ff       	jmp    503e <fwp_wake_io+0x3e>
    50c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50cd:	00 00 00 
    50d0:	48 89 d3             	mov    %rdx,%rbx
    50d3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    50d9:	eb ab                	jmp    5086 <fwp_wake_io+0x86>
    50db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50e0:	45 84 db             	test   %r11b,%r11b
    50e3:	74 07                	je     50ec <fwp_wake_io+0xec>
    50e5:	48 89 1d 1c 27 06 00 	mov    %rbx,0x6271c(%rip)        # 67808 <fwp_ready_head>
    50ec:	45 84 d2             	test   %r10b,%r10b
    50ef:	74 07                	je     50f8 <fwp_wake_io+0xf8>
    50f1:	4c 89 05 08 27 06 00 	mov    %r8,0x62708(%rip)        # 67800 <fwp_ready_tail>
    50f8:	5b                   	pop    %rbx
    50f9:	c3                   	ret
    50fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5100:	c3                   	ret
    5101:	0f 1f 40 00          	nopl   0x0(%rax)
    5105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    510c:	00 00 00 00 

0000000000005110 <ad_raw_free.part.0>:
    5110:	48 8d 0d c9 a0 04 00 	lea    0x4a0c9(%rip),%rcx        # 4f1e0 <ad_raw_blocks>
    5117:	31 c0                	xor    %eax,%eax
    5119:	48 89 ca             	mov    %rcx,%rdx
    511c:	eb 12                	jmp    5130 <ad_raw_free.part.0+0x20>
    511e:	66 90                	xchg   %ax,%ax
    5120:	48 83 c0 01          	add    $0x1,%rax
    5124:	48 83 c2 18          	add    $0x18,%rdx
    5128:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    512e:	74 40                	je     5170 <ad_raw_free.part.0+0x60>
    5130:	48 3b 3a             	cmp    (%rdx),%rdi
    5133:	75 eb                	jne    5120 <ad_raw_free.part.0+0x10>
    5135:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5139:	66 0f ef c0          	pxor   %xmm0,%xmm0
    513d:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5141:	48 8d 0d 78 a0 04 00 	lea    0x4a078(%rip),%rcx        # 4f1c0 <ad_raw_live>
    5148:	8b 70 10             	mov    0x10(%rax),%esi
    514b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5152:	00 
    5153:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5157:	48 2b 50 08          	sub    0x8(%rax),%rdx
    515b:	0f 11 00             	movups %xmm0,(%rax)
    515e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5162:	e9 49 e2 ff ff       	jmp    33b0 <free@plt>
    5167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    516e:	00 00 
    5170:	48 83 ec 08          	sub    $0x8,%rsp
    5174:	48 8d 3d 82 5f 00 00 	lea    0x5f82(%rip),%rdi        # b0fd <_IO_stdin_used+0xfd>
    517b:	e8 60 ee ff ff       	call   3fe0 <ad_raw_fail>

0000000000005180 <fwp_tape_buffers_dispose>:
    5180:	53                   	push   %rbx
    5181:	48 89 fb             	mov    %rdi,%rbx
    5184:	48 8b 3f             	mov    (%rdi),%rdi
    5187:	48 85 ff             	test   %rdi,%rdi
    518a:	74 05                	je     5191 <fwp_tape_buffers_dispose+0x11>
    518c:	e8 7f ff ff ff       	call   5110 <ad_raw_free.part.0>
    5191:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5195:	48 85 ff             	test   %rdi,%rdi
    5198:	74 05                	je     519f <fwp_tape_buffers_dispose+0x1f>
    519a:	e8 71 ff ff ff       	call   5110 <ad_raw_free.part.0>
    519f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    51a3:	48 85 ff             	test   %rdi,%rdi
    51a6:	74 05                	je     51ad <fwp_tape_buffers_dispose+0x2d>
    51a8:	e8 63 ff ff ff       	call   5110 <ad_raw_free.part.0>
    51ad:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51b1:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b8:	00 
    51b9:	0f 11 03             	movups %xmm0,(%rbx)
    51bc:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51c0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51c4:	5b                   	pop    %rbx
    51c5:	c3                   	ret
    51c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51cd:	00 00 00 

00000000000051d0 <ad_raw_realloc>:
    51d0:	41 55                	push   %r13
    51d2:	41 54                	push   %r12
    51d4:	55                   	push   %rbp
    51d5:	53                   	push   %rbx
    51d6:	48 83 ec 08          	sub    $0x8,%rsp
    51da:	48 85 f6             	test   %rsi,%rsi
    51dd:	0f 84 a6 00 00 00    	je     5289 <ad_raw_realloc+0xb9>
    51e3:	4c 8d 25 f6 9f 04 00 	lea    0x49ff6(%rip),%r12        # 4f1e0 <ad_raw_blocks>
    51ea:	48 89 f5             	mov    %rsi,%rbp
    51ed:	41 89 d5             	mov    %edx,%r13d
    51f0:	31 db                	xor    %ebx,%ebx
    51f2:	4c 89 e0             	mov    %r12,%rax
    51f5:	eb 1a                	jmp    5211 <ad_raw_realloc+0x41>
    51f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51fe:	00 00 
    5200:	48 83 c3 01          	add    $0x1,%rbx
    5204:	48 83 c0 18          	add    $0x18,%rax
    5208:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    520f:	74 4f                	je     5260 <ad_raw_realloc+0x90>
    5211:	48 3b 38             	cmp    (%rax),%rdi
    5214:	75 ea                	jne    5200 <ad_raw_realloc+0x30>
    5216:	48 85 ff             	test   %rdi,%rdi
    5219:	74 0b                	je     5226 <ad_raw_realloc+0x56>
    521b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    521f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    5224:	75 57                	jne    527d <ad_raw_realloc+0xad>
    5226:	48 89 ee             	mov    %rbp,%rsi
    5229:	e8 82 e3 ff ff       	call   35b0 <realloc@plt>
    522e:	49 89 c2             	mov    %rax,%r10
    5231:	48 85 c0             	test   %rax,%rax
    5234:	74 16                	je     524c <ad_raw_realloc+0x7c>
    5236:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    523a:	44 89 e9             	mov    %r13d,%ecx
    523d:	48 89 ea             	mov    %rbp,%rdx
    5240:	4c 89 d6             	mov    %r10,%rsi
    5243:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5247:	e8 94 e9 ff ff       	call   3be0 <ad_raw_record>
    524c:	48 83 c4 08          	add    $0x8,%rsp
    5250:	4c 89 d0             	mov    %r10,%rax
    5253:	5b                   	pop    %rbx
    5254:	5d                   	pop    %rbp
    5255:	41 5c                	pop    %r12
    5257:	41 5d                	pop    %r13
    5259:	c3                   	ret
    525a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5260:	48 85 ff             	test   %rdi,%rdi
    5263:	48 8d 05 a8 5e 00 00 	lea    0x5ea8(%rip),%rax        # b112 <_IO_stdin_used+0x112>
    526a:	48 8d 15 8c 5e 00 00 	lea    0x5e8c(%rip),%rdx        # b0fd <_IO_stdin_used+0xfd>
    5271:	48 0f 45 c2          	cmovne %rdx,%rax
    5275:	48 89 c7             	mov    %rax,%rdi
    5278:	e8 63 ed ff ff       	call   3fe0 <ad_raw_fail>
    527d:	48 8d 3d c4 5e 00 00 	lea    0x5ec4(%rip),%rdi        # b148 <_IO_stdin_used+0x148>
    5284:	e8 57 ed ff ff       	call   3fe0 <ad_raw_fail>
    5289:	48 8d 3d 9d 5e 00 00 	lea    0x5e9d(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    5290:	e8 4b ed ff ff       	call   3fe0 <ad_raw_fail>
    5295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    529c:	00 00 00 00 

00000000000052a0 <fwp_tape_buffers_release>:
    52a0:	f3 0f 1e fa          	endbr64
    52a4:	53                   	push   %rbx
    52a5:	48 89 fb             	mov    %rdi,%rbx
    52a8:	48 83 ec 10          	sub    $0x10,%rsp
    52ac:	48 8b 47 28          	mov    0x28(%rdi),%rax
    52b0:	48 85 c0             	test   %rax,%rax
    52b3:	0f 88 d7 00 00 00    	js     5390 <fwp_tape_buffers_release+0xf0>
    52b9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    52bd:	48 85 d2             	test   %rdx,%rdx
    52c0:	0f 88 ca 00 00 00    	js     5390 <fwp_tape_buffers_release+0xf0>
    52c6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    52cc:	0f 87 be 00 00 00    	ja     5390 <fwp_tape_buffers_release+0xf0>
    52d2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    52d6:	b8 00 00 08 00       	mov    $0x80000,%eax
    52db:	48 c1 e1 03          	shl    $0x3,%rcx
    52df:	48 29 c8             	sub    %rcx,%rax
    52e2:	48 c1 e8 03          	shr    $0x3,%rax
    52e6:	48 39 d0             	cmp    %rdx,%rax
    52e9:	0f 82 a1 00 00 00    	jb     5390 <fwp_tape_buffers_release+0xf0>
    52ef:	48 8d 3d 6a 5e 00 00 	lea    0x5e6a(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    52f6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52fb:	48 89 14 24          	mov    %rdx,(%rsp)
    52ff:	e8 8c e0 ff ff       	call   3390 <getenv@plt>
    5304:	48 8b 14 24          	mov    (%rsp),%rdx
    5308:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    530d:	48 85 c0             	test   %rax,%rax
    5310:	74 09                	je     531b <fwp_tape_buffers_release+0x7b>
    5312:	80 38 30             	cmpb   $0x30,(%rax)
    5315:	0f 84 05 01 00 00    	je     5420 <fwp_tape_buffers_release+0x180>
    531b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    531f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    5323:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    5329:	77 71                	ja     539c <fwp_tape_buffers_release+0xfc>
    532b:	48 8d 3d 8e 9d 01 00 	lea    0x19d8e(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    5332:	48 89 34 24          	mov    %rsi,(%rsp)
    5336:	e8 45 fe ff ff       	call   5180 <fwp_tape_buffers_dispose>
    533b:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    533f:	48 8b 34 24          	mov    (%rsp),%rsi
    5343:	0f 29 05 76 9d 01 00 	movaps %xmm0,0x19d76(%rip)        # 1f0c0 <fwp_tape_workspace>
    534a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    534f:	48 89 35 52 9d 01 00 	mov    %rsi,0x19d52(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    5356:	0f 29 05 73 9d 01 00 	movaps %xmm0,0x19d73(%rip)        # 1f0d0 <fwp_tape_workspace+0x10>
    535d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5362:	0f 29 05 77 9d 01 00 	movaps %xmm0,0x19d77(%rip)        # 1f0e0 <fwp_tape_workspace+0x20>
    5369:	48 8b 43 30          	mov    0x30(%rbx),%rax
    536d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5371:	48 89 05 78 9d 01 00 	mov    %rax,0x19d78(%rip)        # 1f0f0 <fwp_tape_workspace+0x30>
    5378:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    537f:	00 
    5380:	0f 11 03             	movups %xmm0,(%rbx)
    5383:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5387:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    538b:	eb 1e                	jmp    53ab <fwp_tape_buffers_release+0x10b>
    538d:	0f 1f 00             	nopl   (%rax)
    5390:	48 8d 3d c9 5d 00 00 	lea    0x5dc9(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5397:	e8 f4 df ff ff       	call   3390 <getenv@plt>
    539c:	48 89 df             	mov    %rbx,%rdi
    539f:	e8 dc fd ff ff       	call   5180 <fwp_tape_buffers_dispose>
    53a4:	48 8b 35 fd 9c 01 00 	mov    0x19cfd(%rip),%rsi        # 1f0a8 <fwp_tape_cached_bytes>
    53ab:	48 6b 15 4d 9d 01 00 	imul   $0x68,0x19d4d(%rip),%rdx        # 1f100 <fwp_tapes_cap>
    53b2:	68 
    53b3:	48 3b 15 06 9e 04 00 	cmp    0x49e06(%rip),%rdx        # 4f1c0 <ad_raw_live>
    53ba:	75 73                	jne    542f <fwp_tape_buffers_release+0x18f>
    53bc:	48 8b 05 05 9e 04 00 	mov    0x49e05(%rip),%rax        # 4f1c8 <ad_raw_live+0x8>
    53c3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    53c7:	48 01 d0             	add    %rdx,%rax
    53ca:	48 03 05 ff 9d 04 00 	add    0x49dff(%rip),%rax        # 4f1d0 <ad_raw_live+0x10>
    53d1:	48 03 05 00 9e 04 00 	add    0x49e00(%rip),%rax        # 4f1d8 <ad_raw_live+0x18>
    53d8:	48 39 c8             	cmp    %rcx,%rax
    53db:	72 52                	jb     542f <fwp_tape_buffers_release+0x18f>
    53dd:	48 8b 0d 3c 9d 01 00 	mov    0x19d3c(%rip),%rcx        # 1f120 <ad_raw_checkpoint_count>
    53e4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53eb:	74 4e                	je     543b <fwp_tape_buffers_release+0x19b>
    53ed:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53f1:	48 29 d0             	sub    %rdx,%rax
    53f4:	48 89 3d 25 9d 01 00 	mov    %rdi,0x19d25(%rip)        # 1f120 <ad_raw_checkpoint_count>
    53fb:	48 29 f0             	sub    %rsi,%rax
    53fe:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5402:	48 8d 0d 37 9d 01 00 	lea    0x19d37(%rip),%rcx        # 1f140 <ad_raw_checkpoints>
    5409:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    540d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5412:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5417:	48 83 c4 10          	add    $0x10,%rsp
    541b:	5b                   	pop    %rbx
    541c:	c3                   	ret
    541d:	0f 1f 00             	nopl   (%rax)
    5420:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5424:	0f 84 72 ff ff ff    	je     539c <fwp_tape_buffers_release+0xfc>
    542a:	e9 ec fe ff ff       	jmp    531b <fwp_tape_buffers_release+0x7b>
    542f:	48 8d 3d ea 64 00 00 	lea    0x64ea(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    5436:	e8 a5 eb ff ff       	call   3fe0 <ad_raw_fail>
    543b:	48 8d 3d 2f 5d 00 00 	lea    0x5d2f(%rip),%rdi        # b171 <_IO_stdin_used+0x171>
    5442:	e8 99 eb ff ff       	call   3fe0 <ad_raw_fail>
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 

0000000000005450 <fwp_poll_events>:
    5450:	53                   	push   %rbx
    5451:	48 83 ec 20          	sub    $0x20,%rsp
    5455:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    545c:	00 00 
    545e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5463:	31 c0                	xor    %eax,%eax
    5465:	e8 36 f1 ff ff       	call   45a0 <fwp_now_ns>
    546a:	48 8b 1d 87 23 06 00 	mov    0x62387(%rip),%rbx        # 677f8 <fwp_timers>
    5471:	48 85 db             	test   %rbx,%rbx
    5474:	0f 84 e6 00 00 00    	je     5560 <fwp_poll_events+0x110>
    547a:	48 89 c6             	mov    %rax,%rsi
    547d:	48 89 da             	mov    %rbx,%rdx
    5480:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5487:	eb 26                	jmp    54af <fwp_poll_events+0x5f>
    5489:	90                   	nop
    548a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5491:	00 00 00 00 
    5495:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    549c:	00 00 00 00 
    54a0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54a7:	48 89 c8             	mov    %rcx,%rax
    54aa:	48 85 d2             	test   %rdx,%rdx
    54ad:	74 31                	je     54e0 <fwp_poll_events+0x90>
    54af:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54b3:	48 85 c0             	test   %rax,%rax
    54b6:	78 e8                	js     54a0 <fwp_poll_events+0x50>
    54b8:	48 39 c1             	cmp    %rax,%rcx
    54bb:	7c e3                	jl     54a0 <fwp_poll_events+0x50>
    54bd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54c4:	48 85 d2             	test   %rdx,%rdx
    54c7:	74 1c                	je     54e5 <fwp_poll_events+0x95>
    54c9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54cd:	48 39 c1             	cmp    %rax,%rcx
    54d0:	7c ce                	jl     54a0 <fwp_poll_events+0x50>
    54d2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54d9:	48 85 d2             	test   %rdx,%rdx
    54dc:	75 d1                	jne    54af <fwp_poll_events+0x5f>
    54de:	66 90                	xchg   %ax,%ax
    54e0:	48 85 c0             	test   %rax,%rax
    54e3:	78 7b                	js     5560 <fwp_poll_events+0x110>
    54e5:	48 29 f0             	sub    %rsi,%rax
    54e8:	48 89 c1             	mov    %rax,%rcx
    54eb:	48 85 c0             	test   %rax,%rax
    54ee:	0f 8e 9c 00 00 00    	jle    5590 <fwp_poll_events+0x140>
    54f4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54fb:	de 1b 43 
    54fe:	48 f7 ea             	imul   %rdx
    5501:	48 89 c8             	mov    %rcx,%rax
    5504:	48 c1 f8 3f          	sar    $0x3f,%rax
    5508:	48 c1 fa 12          	sar    $0x12,%rdx
    550c:	48 29 c2             	sub    %rax,%rdx
    550f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5516:	48 39 c1             	cmp    %rax,%rcx
    5519:	0f 95 c0             	setne  %al
    551c:	0f b6 c0             	movzbl %al,%eax
    551f:	48 01 d0             	add    %rdx,%rax
    5522:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5528:	0f 8f 32 01 00 00    	jg     5660 <fwp_poll_events+0x210>
    552e:	48 85 c0             	test   %rax,%rax
    5531:	74 5d                	je     5590 <fwp_poll_events+0x140>
    5533:	89 c1                	mov    %eax,%ecx
    5535:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    553c:	48 c1 e9 26          	shr    $0x26,%rcx
    5540:	48 63 d1             	movslq %ecx,%rdx
    5543:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5549:	29 c8                	sub    %ecx,%eax
    554b:	48 98                	cltq
    554d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5554:	e9 11 01 00 00       	jmp    566a <fwp_poll_events+0x21a>
    5559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5560:	e8 7b e7 ff ff       	call   3ce0 <fwp_flush>
    5565:	ba 2b 00 00 00       	mov    $0x2b,%edx
    556a:	be 01 00 00 00       	mov    $0x1,%esi
    556f:	48 8b 0d ca 9a 00 00 	mov    0x9aca(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5576:	48 8d 3d d3 63 00 00 	lea    0x63d3(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    557d:	e8 de e0 ff ff       	call   3660 <fwrite@plt>
    5582:	bf 65 00 00 00       	mov    $0x65,%edi
    5587:	e8 c4 e0 ff ff       	call   3650 <exit@plt>
    558c:	0f 1f 40 00          	nopl   0x0(%rax)
    5590:	e8 0b f0 ff ff       	call   45a0 <fwp_now_ns>
    5595:	48 89 c1             	mov    %rax,%rcx
    5598:	66 0f ef c0          	pxor   %xmm0,%xmm0
    559c:	eb 44                	jmp    55e2 <fwp_poll_events+0x192>
    559e:	66 90                	xchg   %ax,%ax
    55a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    55a4:	75 33                	jne    55d9 <fwp_poll_events+0x189>
    55a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55aa:	75 2d                	jne    55d9 <fwp_poll_events+0x189>
    55ac:	48 8b 05 4d 22 06 00 	mov    0x6224d(%rip),%rax        # 67800 <fwp_ready_tail>
    55b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    55b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    55be:	00 00 00 00 
    55c2:	48 85 c0             	test   %rax,%rax
    55c5:	0f 84 05 01 00 00    	je     56d0 <fwp_poll_events+0x280>
    55cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    55d2:	48 89 15 27 22 06 00 	mov    %rdx,0x62227(%rip)        # 67800 <fwp_ready_tail>
    55d9:	48 85 db             	test   %rbx,%rbx
    55dc:	0f 84 be 00 00 00    	je     56a0 <fwp_poll_events+0x250>
    55e2:	48 89 da             	mov    %rbx,%rdx
    55e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55f0:	7f e7                	jg     55d9 <fwp_poll_events+0x189>
    55f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55f6:	74 2e                	je     5626 <fwp_poll_events+0x1d6>
    55f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55ff:	48 85 c0             	test   %rax,%rax
    5602:	0f 84 b8 00 00 00    	je     56c0 <fwp_poll_events+0x270>
    5608:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    560f:	48 85 db             	test   %rbx,%rbx
    5612:	74 07                	je     561b <fwp_poll_events+0x1cb>
    5614:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    561b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    561f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5626:	48 8b 42 60          	mov    0x60(%rdx),%rax
    562a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    562e:	48 85 c0             	test   %rax,%rax
    5631:	0f 84 69 ff ff ff    	je     55a0 <fwp_poll_events+0x150>
    5637:	48 39 c8             	cmp    %rcx,%rax
    563a:	0f 8f 60 ff ff ff    	jg     55a0 <fwp_poll_events+0x150>
    5640:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5644:	0f 85 56 ff ff ff    	jne    55a0 <fwp_poll_events+0x150>
    564a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    564e:	75 89                	jne    55d9 <fwp_poll_events+0x189>
    5650:	48 89 d7             	mov    %rdx,%rdi
    5653:	e8 b8 ea ff ff       	call   4110 <fwp_cancel_tree.part.0>
    5658:	e9 43 ff ff ff       	jmp    55a0 <fwp_poll_events+0x150>
    565d:	0f 1f 00             	nopl   (%rax)
    5660:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5665:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    566a:	48 89 e7             	mov    %rsp,%rdi
    566d:	31 f6                	xor    %esi,%esi
    566f:	48 89 14 24          	mov    %rdx,(%rsp)
    5673:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5678:	e8 13 de ff ff       	call   3490 <nanosleep@plt>
    567d:	48 8b 1d 74 21 06 00 	mov    0x62174(%rip),%rbx        # 677f8 <fwp_timers>
    5684:	e8 17 ef ff ff       	call   45a0 <fwp_now_ns>
    5689:	48 89 c1             	mov    %rax,%rcx
    568c:	48 85 db             	test   %rbx,%rbx
    568f:	0f 85 03 ff ff ff    	jne    5598 <fwp_poll_events+0x148>
    5695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    569c:	00 00 00 00 
    56a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    56a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    56ac:	00 00 
    56ae:	75 2c                	jne    56dc <fwp_poll_events+0x28c>
    56b0:	48 83 c4 20          	add    $0x20,%rsp
    56b4:	5b                   	pop    %rbx
    56b5:	c3                   	ret
    56b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56bd:	00 00 00 
    56c0:	48 89 1d 31 21 06 00 	mov    %rbx,0x62131(%rip)        # 677f8 <fwp_timers>
    56c7:	e9 43 ff ff ff       	jmp    560f <fwp_poll_events+0x1bf>
    56cc:	0f 1f 40 00          	nopl   0x0(%rax)
    56d0:	48 89 15 31 21 06 00 	mov    %rdx,0x62131(%rip)        # 67808 <fwp_ready_head>
    56d7:	e9 f6 fe ff ff       	jmp    55d2 <fwp_poll_events+0x182>
    56dc:	e8 6f dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56e1:	0f 1f 40 00          	nopl   0x0(%rax)
    56e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ec:	00 00 00 00 

00000000000056f0 <fwp_rc_wide_dup>:
    56f0:	48 89 fa             	mov    %rdi,%rdx
    56f3:	48 8d 35 46 21 06 00 	lea    0x62146(%rip),%rsi        # 67840 <fwp_heap>
    56fa:	48 83 ec 18          	sub    $0x18,%rsp
    56fe:	48 89 f9             	mov    %rdi,%rcx
    5701:	48 c1 ea 11          	shr    $0x11,%rdx
    5705:	48 31 fa             	xor    %rdi,%rdx
    5708:	48 89 d0             	mov    %rdx,%rax
    570b:	48 c1 e8 09          	shr    $0x9,%rax
    570f:	48 31 c2             	xor    %rax,%rdx
    5712:	0f b6 d2             	movzbl %dl,%edx
    5715:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    571c:	00 
    571d:	49 8b 00             	mov    (%r8),%rax
    5720:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5727:	00 00 
    5729:	75 21                	jne    574c <fwp_rc_wide_dup+0x5c>
    572b:	e9 98 00 00 00       	jmp    57c8 <fwp_rc_wide_dup+0xd8>
    5730:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    573c:	00 00 00 00 
    5740:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5744:	48 85 d2             	test   %rdx,%rdx
    5747:	74 2f                	je     5778 <fwp_rc_wide_dup+0x88>
    5749:	48 89 d0             	mov    %rdx,%rax
    574c:	48 3b 08             	cmp    (%rax),%rcx
    574f:	75 ef                	jne    5740 <fwp_rc_wide_dup+0x50>
    5751:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5754:	74 7c                	je     57d2 <fwp_rc_wide_dup+0xe2>
    5756:	48 8b 50 08          	mov    0x8(%rax),%rdx
    575a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    575e:	0f 84 91 00 00 00    	je     57f5 <fwp_rc_wide_dup+0x105>
    5764:	48 83 c2 01          	add    $0x1,%rdx
    5768:	48 89 50 08          	mov    %rdx,0x8(%rax)
    576c:	48 83 c4 18          	add    $0x18,%rsp
    5770:	c3                   	ret
    5771:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5778:	4c 8d 40 10          	lea    0x10(%rax),%r8
    577c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    577f:	75 68                	jne    57e9 <fwp_rc_wide_dup+0xf9>
    5781:	bf 18 00 00 00       	mov    $0x18,%edi
    5786:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    578b:	4c 89 04 24          	mov    %r8,(%rsp)
    578f:	e8 fc dd ff ff       	call   3590 <malloc@plt>
    5794:	4c 8b 04 24          	mov    (%rsp),%r8
    5798:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    579d:	48 85 c0             	test   %rax,%rax
    57a0:	74 5f                	je     5801 <fwp_rc_wide_dup+0x111>
    57a2:	48 89 08             	mov    %rcx,(%rax)
    57a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    57ac:	00 
    57ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    57b4:	00 
    57b5:	49 89 00             	mov    %rax,(%r8)
    57b8:	c6 01 ff             	movb   $0xff,(%rcx)
    57bb:	48 83 05 c5 3c 06 00 	addq   $0x1,0x63cc5(%rip)        # 69488 <fwp_heap+0x1c48>
    57c2:	01 
    57c3:	48 83 c4 18          	add    $0x18,%rsp
    57c7:	c3                   	ret
    57c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    57cb:	75 13                	jne    57e0 <fwp_rc_wide_dup+0xf0>
    57cd:	48 85 c0             	test   %rax,%rax
    57d0:	74 af                	je     5781 <fwp_rc_wide_dup+0x91>
    57d2:	48 8d 3d a7 61 00 00 	lea    0x61a7(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    57d9:	e8 52 ec ff ff       	call   4430 <fwp_trap>
    57de:	66 90                	xchg   %ax,%ax
    57e0:	48 85 c0             	test   %rax,%rax
    57e3:	0f 85 6d ff ff ff    	jne    5756 <fwp_rc_wide_dup+0x66>
    57e9:	48 8d 3d b8 61 00 00 	lea    0x61b8(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    57f0:	e8 3b ec ff ff       	call   4430 <fwp_trap>
    57f5:	48 8d 3d 92 59 00 00 	lea    0x5992(%rip),%rdi        # b18e <_IO_stdin_used+0x18e>
    57fc:	e8 2f ec ff ff       	call   4430 <fwp_trap>
    5801:	e8 0a e6 ff ff       	call   3e10 <fwp_heap_oom>
    5806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    580d:	00 00 00 

0000000000005810 <fwp_rc_forget_slot>:
    5810:	80 3f ff             	cmpb   $0xff,(%rdi)
    5813:	74 0b                	je     5820 <fwp_rc_forget_slot+0x10>
    5815:	c3                   	ret
    5816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    581d:	00 00 00 
    5820:	48 89 f8             	mov    %rdi,%rax
    5823:	48 83 ec 08          	sub    $0x8,%rsp
    5827:	48 89 fa             	mov    %rdi,%rdx
    582a:	48 c1 e8 11          	shr    $0x11,%rax
    582e:	48 31 f8             	xor    %rdi,%rax
    5831:	48 89 c1             	mov    %rax,%rcx
    5834:	48 c1 e9 09          	shr    $0x9,%rcx
    5838:	48 31 c8             	xor    %rcx,%rax
    583b:	48 8d 0d fe 1f 06 00 	lea    0x61ffe(%rip),%rcx        # 67840 <fwp_heap>
    5842:	0f b6 c0             	movzbl %al,%eax
    5845:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    584c:	00 
    584d:	48 85 ff             	test   %rdi,%rdi
    5850:	74 3c                	je     588e <fwp_rc_forget_slot+0x7e>
    5852:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5859:	00 
    585a:	48 8b 01             	mov    (%rcx),%rax
    585d:	eb 11                	jmp    5870 <fwp_rc_forget_slot+0x60>
    585f:	90                   	nop
    5860:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5864:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5868:	48 85 ff             	test   %rdi,%rdi
    586b:	74 21                	je     588e <fwp_rc_forget_slot+0x7e>
    586d:	48 89 f8             	mov    %rdi,%rax
    5870:	48 3b 10             	cmp    (%rax),%rdx
    5873:	75 eb                	jne    5860 <fwp_rc_forget_slot+0x50>
    5875:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5879:	48 89 01             	mov    %rax,(%rcx)
    587c:	e8 2f db ff ff       	call   33b0 <free@plt>
    5881:	48 83 2d ff 3b 06 00 	subq   $0x1,0x63bff(%rip)        # 69488 <fwp_heap+0x1c48>
    5888:	01 
    5889:	48 83 c4 08          	add    $0x8,%rsp
    588d:	c3                   	ret
    588e:	48 8d 3d 13 61 00 00 	lea    0x6113(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5895:	e8 96 eb ff ff       	call   4430 <fwp_trap>
    589a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000058a0 <fwp_rc_prepare_chunk>:
    58a0:	48 83 3d e0 3b 06 00 	cmpq   $0x0,0x63be0(%rip)        # 69488 <fwp_heap+0x1c48>
    58a7:	00 
    58a8:	41 54                	push   %r12
    58aa:	49 89 f4             	mov    %rsi,%r12
    58ad:	55                   	push   %rbp
    58ae:	48 89 fd             	mov    %rdi,%rbp
    58b1:	53                   	push   %rbx
    58b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    58b5:	0f 84 7d 00 00 00    	je     5938 <fwp_rc_prepare_chunk+0x98>
    58bb:	31 db                	xor    %ebx,%ebx
    58bd:	85 c0                	test   %eax,%eax
    58bf:	75 5f                	jne    5920 <fwp_rc_prepare_chunk+0x80>
    58c1:	48 85 f6             	test   %rsi,%rsi
    58c4:	74 7c                	je     5942 <fwp_rc_prepare_chunk+0xa2>
    58c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    58ca:	e8 e1 da ff ff       	call   33b0 <free@plt>
    58cf:	90                   	nop
    58d0:	be 01 00 00 00       	mov    $0x1,%esi
    58d5:	4c 89 e7             	mov    %r12,%rdi
    58d8:	e8 33 dc ff ff       	call   3510 <calloc@plt>
    58dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58e1:	48 85 c0             	test   %rax,%rax
    58e4:	0f 85 87 00 00 00    	jne    5971 <fwp_rc_prepare_chunk+0xd1>
    58ea:	e8 21 e5 ff ff       	call   3e10 <fwp_heap_oom>
    58ef:	90                   	nop
    58f0:	e8 1b ff ff ff       	call   5810 <fwp_rc_forget_slot>
    58f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58f8:	48 83 c3 01          	add    $0x1,%rbx
    58fc:	48 39 c3             	cmp    %rax,%rbx
    58ff:	73 37                	jae    5938 <fwp_rc_prepare_chunk+0x98>
    5901:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5908:	00 00 
    590a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5911:	00 00 00 00 
    5915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    591c:	00 00 00 00 
    5920:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5924:	48 01 df             	add    %rbx,%rdi
    5927:	80 3f ff             	cmpb   $0xff,(%rdi)
    592a:	74 c4                	je     58f0 <fwp_rc_prepare_chunk+0x50>
    592c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    592f:	48 83 c3 01          	add    $0x1,%rbx
    5933:	48 39 c3             	cmp    %rax,%rbx
    5936:	72 e8                	jb     5920 <fwp_rc_prepare_chunk+0x80>
    5938:	49 39 c4             	cmp    %rax,%r12
    593b:	75 13                	jne    5950 <fwp_rc_prepare_chunk+0xb0>
    593d:	4d 85 e4             	test   %r12,%r12
    5940:	75 46                	jne    5988 <fwp_rc_prepare_chunk+0xe8>
    5942:	5b                   	pop    %rbx
    5943:	5d                   	pop    %rbp
    5944:	41 5c                	pop    %r12
    5946:	c3                   	ret
    5947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    594e:	00 00 
    5950:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5954:	48 29 05 35 3b 06 00 	sub    %rax,0x63b35(%rip)        # 69490 <fwp_heap+0x1c50>
    595b:	e8 50 da ff ff       	call   33b0 <free@plt>
    5960:	4d 85 e4             	test   %r12,%r12
    5963:	0f 85 67 ff ff ff    	jne    58d0 <fwp_rc_prepare_chunk+0x30>
    5969:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5970:	00 
    5971:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5975:	5b                   	pop    %rbx
    5976:	4c 01 25 13 3b 06 00 	add    %r12,0x63b13(%rip)        # 69490 <fwp_heap+0x1c50>
    597d:	5d                   	pop    %rbp
    597e:	41 5c                	pop    %r12
    5980:	c3                   	ret
    5981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5988:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    598c:	5b                   	pop    %rbx
    598d:	4c 89 e2             	mov    %r12,%rdx
    5990:	31 f6                	xor    %esi,%esi
    5992:	5d                   	pop    %rbp
    5993:	41 5c                	pop    %r12
    5995:	e9 16 db ff ff       	jmp    34b0 <memset@plt>
    599a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000059a0 <fwp_heap_refill>:
    59a0:	41 56                	push   %r14
    59a2:	41 89 d6             	mov    %edx,%r14d
    59a5:	41 55                	push   %r13
    59a7:	41 89 f5             	mov    %esi,%r13d
    59aa:	41 54                	push   %r12
    59ac:	49 89 fc             	mov    %rdi,%r12
    59af:	bf 01 00 00 00       	mov    $0x1,%edi
    59b4:	55                   	push   %rbp
    59b5:	53                   	push   %rbx
    59b6:	e8 95 e4 ff ff       	call   3e50 <fwp_heap_chunks>
    59bb:	48 89 c3             	mov    %rax,%rbx
    59be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    59c2:	48 8b 05 6f 32 06 00 	mov    0x6326f(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    59c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    59cd:	48 8d 05 6c 1e 06 00 	lea    0x61e6c(%rip),%rax        # 67840 <fwp_heap>
    59d4:	31 d2                	xor    %edx,%edx
    59d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    59da:	48 89 ef             	mov    %rbp,%rdi
    59dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ec:	00 
    59ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    59f2:	f7 f1                	div    %ecx
    59f4:	31 d2                	xor    %edx,%edx
    59f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59fa:	66 0f 6e c8          	movd   %eax,%xmm1
    59fe:	89 c6                	mov    %eax,%esi
    5a00:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5a05:	48 01 c8             	add    %rcx,%rax
    5a08:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5a0c:	48 f7 f1             	div    %rcx
    5a0f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5a14:	89 45 18             	mov    %eax,0x18(%rbp)
    5a17:	e8 84 fe ff ff       	call   58a0 <fwp_rc_prepare_chunk>
    5a1c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    5a1f:	48 89 d8             	mov    %rbx,%rax
    5a22:	48 c1 e0 10          	shl    $0x10,%rax
    5a26:	48 03 05 c3 31 06 00 	add    0x631c3(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    5a2d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5a31:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5a36:	8b 55 08             	mov    0x8(%rbp),%edx
    5a39:	48 0f af d1          	imul   %rcx,%rdx
    5a3d:	48 01 c2             	add    %rax,%rdx
    5a40:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a45:	5b                   	pop    %rbx
    5a46:	5d                   	pop    %rbp
    5a47:	41 5c                	pop    %r12
    5a49:	41 5d                	pop    %r13
    5a4b:	41 5e                	pop    %r14
    5a4d:	c3                   	ret
    5a4e:	66 90                	xchg   %ax,%ax

0000000000005a50 <fwp_mem_free>:
    5a50:	48 85 ff             	test   %rdi,%rdi
    5a53:	0f 84 17 02 00 00    	je     5c70 <fwp_mem_free+0x220>
    5a59:	48 8b 35 90 31 06 00 	mov    0x63190(%rip),%rsi        # 68bf0 <fwp_heap+0x13b0>
    5a60:	48 8b 05 b1 31 06 00 	mov    0x631b1(%rip),%rax        # 68c18 <fwp_heap+0x13d8>
    5a67:	48 89 fa             	mov    %rdi,%rdx
    5a6a:	48 29 f2             	sub    %rsi,%rdx
    5a6d:	48 c1 e0 10          	shl    $0x10,%rax
    5a71:	48 39 c2             	cmp    %rax,%rdx
    5a74:	0f 83 f6 01 00 00    	jae    5c70 <fwp_mem_free+0x220>
    5a7a:	49 89 d1             	mov    %rdx,%r9
    5a7d:	49 c1 e9 10          	shr    $0x10,%r9
    5a81:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a85:	48 c1 e0 03          	shl    $0x3,%rax
    5a89:	49 89 c0             	mov    %rax,%r8
    5a8c:	4c 03 05 a5 31 06 00 	add    0x631a5(%rip),%r8        # 68c38 <fwp_heap+0x13f8>
    5a93:	0f 84 d7 01 00 00    	je     5c70 <fwp_mem_free+0x220>
    5a99:	48 83 ec 38          	sub    $0x38,%rsp
    5a9d:	48 89 f9             	mov    %rdi,%rcx
    5aa0:	41 0f b6 38          	movzbl (%r8),%edi
    5aa4:	40 80 ff 01          	cmp    $0x1,%dil
    5aa8:	74 16                	je     5ac0 <fwp_mem_free+0x70>
    5aaa:	40 80 ff 02          	cmp    $0x2,%dil
    5aae:	0f 84 94 00 00 00    	je     5b48 <fwp_mem_free+0xf8>
    5ab4:	48 83 c4 38          	add    $0x38,%rsp
    5ab8:	c3                   	ret
    5ab9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ac0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5ac4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5ac9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5ace:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ad2:	4d 85 d2             	test   %r10,%r10
    5ad5:	74 1d                	je     5af4 <fwp_mem_free+0xa4>
    5ad7:	0f b7 c1             	movzwl %cx,%eax
    5ada:	31 d2                	xor    %edx,%edx
    5adc:	48 f7 f7             	div    %rdi
    5adf:	49 01 c2             	add    %rax,%r10
    5ae2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5ae6:	0f 84 44 01 00 00    	je     5c30 <fwp_mem_free+0x1e0>
    5aec:	41 c6 02 00          	movb   $0x0,(%r10)
    5af0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5af4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5afb:	49 63 c1             	movslq %r9d,%rax
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b06:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5b0b:	f2 0f 58 05 6d 31 06 	addsd  0x6316d(%rip),%xmm0        # 68c80 <fwp_heap+0x1440>
    5b12:	00 
    5b13:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5b17:	48 8d 05 22 1d 06 00 	lea    0x61d22(%rip),%rax        # 67840 <fwp_heap>
    5b1e:	48 01 d0             	add    %rdx,%rax
    5b21:	48 8b 10             	mov    (%rax),%rdx
    5b24:	48 f7 d2             	not    %rdx
    5b27:	48 89 11             	mov    %rdx,(%rcx)
    5b2a:	48 89 08             	mov    %rcx,(%rax)
    5b2d:	48 29 3d 2c 31 06 00 	sub    %rdi,0x6312c(%rip)        # 68c60 <fwp_heap+0x1420>
    5b34:	f2 0f 11 05 44 31 06 	movsd  %xmm0,0x63144(%rip)        # 68c80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	48 83 c4 38          	add    $0x38,%rsp
    5b40:	c3                   	ret
    5b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b48:	66 31 d2             	xor    %dx,%dx
    5b4b:	48 01 d6             	add    %rdx,%rsi
    5b4e:	48 39 f1             	cmp    %rsi,%rcx
    5b51:	0f 85 5d ff ff ff    	jne    5ab4 <fwp_mem_free+0x64>
    5b57:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b5b:	48 29 15 fe 30 06 00 	sub    %rdx,0x630fe(%rip)        # 68c60 <fwp_heap+0x1420>
    5b62:	48 85 d2             	test   %rdx,%rdx
    5b65:	0f 88 a5 00 00 00    	js     5c10 <fwp_mem_free+0x1c0>
    5b6b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b6f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b74:	f2 0f 58 05 04 31 06 	addsd  0x63104(%rip),%xmm0        # 68c80 <fwp_heap+0x1440>
    5b7b:	00 
    5b7c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b80:	f2 0f 11 05 f8 30 06 	movsd  %xmm0,0x630f8(%rip)        # 68c80 <fwp_heap+0x1440>
    5b87:	00 
    5b88:	48 85 d2             	test   %rdx,%rdx
    5b8b:	74 0c                	je     5b99 <fwp_mem_free+0x149>
    5b8d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b90:	0f 84 db 00 00 00    	je     5c71 <fwp_mem_free+0x221>
    5b96:	c6 02 00             	movb   $0x0,(%rdx)
    5b99:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b9d:	48 85 c9             	test   %rcx,%rcx
    5ba0:	74 3e                	je     5be0 <fwp_mem_free+0x190>
    5ba2:	48 8b 15 8f 30 06 00 	mov    0x6308f(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    5ba9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5bb1:	48 01 d0             	add    %rdx,%rax
    5bb4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5bb8:	48 89 d6             	mov    %rdx,%rsi
    5bbb:	48 29 c6             	sub    %rax,%rsi
    5bbe:	83 e6 08             	and    $0x8,%esi
    5bc1:	74 0d                	je     5bd0 <fwp_mem_free+0x180>
    5bc3:	c6 00 00             	movb   $0x0,(%rax)
    5bc6:	48 83 c0 28          	add    $0x28,%rax
    5bca:	48 39 c2             	cmp    %rax,%rdx
    5bcd:	74 11                	je     5be0 <fwp_mem_free+0x190>
    5bcf:	90                   	nop
    5bd0:	c6 00 00             	movb   $0x0,(%rax)
    5bd3:	48 83 c0 50          	add    $0x50,%rax
    5bd7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5bdb:	48 39 c2             	cmp    %rax,%rdx
    5bde:	75 f0                	jne    5bd0 <fwp_mem_free+0x180>
    5be0:	48 01 0d 89 30 06 00 	add    %rcx,0x63089(%rip)        # 68c70 <fwp_heap+0x1430>
    5be7:	4c 3b 0d 42 30 06 00 	cmp    0x63042(%rip),%r9        # 68c30 <fwp_heap+0x13f0>
    5bee:	73 07                	jae    5bf7 <fwp_mem_free+0x1a7>
    5bf0:	4c 89 0d 39 30 06 00 	mov    %r9,0x63039(%rip)        # 68c30 <fwp_heap+0x13f0>
    5bf7:	4c 3b 0d 2a 30 06 00 	cmp    0x6302a(%rip),%r9        # 68c28 <fwp_heap+0x13e8>
    5bfe:	0f 83 b0 fe ff ff    	jae    5ab4 <fwp_mem_free+0x64>
    5c04:	4c 89 0d 1d 30 06 00 	mov    %r9,0x6301d(%rip)        # 68c28 <fwp_heap+0x13e8>
    5c0b:	e9 a4 fe ff ff       	jmp    5ab4 <fwp_mem_free+0x64>
    5c10:	48 89 d1             	mov    %rdx,%rcx
    5c13:	83 e2 01             	and    $0x1,%edx
    5c16:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c1a:	48 d1 e9             	shr    $1,%rcx
    5c1d:	48 09 d1             	or     %rdx,%rcx
    5c20:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5c25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5c29:	e9 46 ff ff ff       	jmp    5b74 <fwp_mem_free+0x124>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	4c 89 d7             	mov    %r10,%rdi
    5c33:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5c38:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5c3d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c42:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c46:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c4b:	e8 c0 fb ff ff       	call   5810 <fwp_rc_forget_slot>
    5c50:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c55:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c5a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c5f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c64:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c69:	e9 7e fe ff ff       	jmp    5aec <fwp_mem_free+0x9c>
    5c6e:	66 90                	xchg   %ax,%ax
    5c70:	c3                   	ret
    5c71:	48 89 d7             	mov    %rdx,%rdi
    5c74:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c79:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c7e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c83:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c88:	e8 83 fb ff ff       	call   5810 <fwp_rc_forget_slot>
    5c8d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c92:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c97:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c9c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5ca1:	e9 f0 fe ff ff       	jmp    5b96 <fwp_mem_free+0x146>
    5ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cad:	00 00 00 

0000000000005cb0 <fwp_heap_alloc_big>:
    5cb0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5cb7:	00 00 40 
    5cba:	41 57                	push   %r15
    5cbc:	41 56                	push   %r14
    5cbe:	41 55                	push   %r13
    5cc0:	41 54                	push   %r12
    5cc2:	55                   	push   %rbp
    5cc3:	53                   	push   %rbx
    5cc4:	48 83 ec 08          	sub    $0x8,%rsp
    5cc8:	48 39 f8             	cmp    %rdi,%rax
    5ccb:	0f 82 fa 00 00 00    	jb     5dcb <fwp_heap_alloc_big+0x11b>
    5cd1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5cd8:	49 89 fd             	mov    %rdi,%r13
    5cdb:	41 89 f6             	mov    %esi,%r14d
    5cde:	48 c1 ed 10          	shr    $0x10,%rbp
    5ce2:	48 89 ef             	mov    %rbp,%rdi
    5ce5:	e8 66 e1 ff ff       	call   3e50 <fwp_heap_chunks>
    5cea:	be 01 00 00 00       	mov    $0x1,%esi
    5cef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cf3:	49 89 c4             	mov    %rax,%r12
    5cf6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cfd:	00 
    5cfe:	48 03 3d 33 2f 06 00 	add    0x62f33(%rip),%rdi        # 68c38 <fwp_heap+0x13f8>
    5d05:	c6 07 02             	movb   $0x2,(%rdi)
    5d08:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5d0c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5d0f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5d13:	e8 88 fb ff ff       	call   58a0 <fwp_rc_prepare_chunk>
    5d18:	48 83 fd 01          	cmp    $0x1,%rbp
    5d1c:	76 47                	jbe    5d65 <fwp_heap_alloc_big+0xb5>
    5d1e:	4c 01 e5             	add    %r12,%rbp
    5d21:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5d28:	00 
    5d29:	4c 8d 3d 10 1b 06 00 	lea    0x61b10(%rip),%r15        # 67840 <fwp_heap>
    5d30:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5d35:	49 c1 e6 03          	shl    $0x3,%r14
    5d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d40:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d47:	31 f6                	xor    %esi,%esi
    5d49:	48 01 dd             	add    %rbx,%rbp
    5d4c:	48 83 c3 28          	add    $0x28,%rbx
    5d50:	48 89 ef             	mov    %rbp,%rdi
    5d53:	e8 48 fb ff ff       	call   58a0 <fwp_rc_prepare_chunk>
    5d58:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d5c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d60:	49 39 de             	cmp    %rbx,%r14
    5d63:	75 db                	jne    5d40 <fwp_heap_alloc_big+0x90>
    5d65:	49 c1 e4 10          	shl    $0x10,%r12
    5d69:	4c 03 25 80 2e 06 00 	add    0x62e80(%rip),%r12        # 68bf0 <fwp_heap+0x13b0>
    5d70:	4c 89 ea             	mov    %r13,%rdx
    5d73:	31 f6                	xor    %esi,%esi
    5d75:	4c 89 e7             	mov    %r12,%rdi
    5d78:	e8 33 d7 ff ff       	call   34b0 <memset@plt>
    5d7d:	4c 89 e8             	mov    %r13,%rax
    5d80:	48 03 05 d9 2e 06 00 	add    0x62ed9(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    5d87:	72 42                	jb     5dcb <fwp_heap_alloc_big+0x11b>
    5d89:	48 39 05 d8 2e 06 00 	cmp    %rax,0x62ed8(%rip)        # 68c68 <fwp_heap+0x1428>
    5d90:	48 89 05 c9 2e 06 00 	mov    %rax,0x62ec9(%rip)        # 68c60 <fwp_heap+0x1420>
    5d97:	73 07                	jae    5da0 <fwp_heap_alloc_big+0xf0>
    5d99:	48 89 05 c8 2e 06 00 	mov    %rax,0x62ec8(%rip)        # 68c68 <fwp_heap+0x1428>
    5da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da4:	4c 89 e0             	mov    %r12,%rax
    5da7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5dac:	f2 0f 58 05 c4 2e 06 	addsd  0x62ec4(%rip),%xmm0        # 68c78 <fwp_heap+0x1438>
    5db3:	00 
    5db4:	f2 0f 11 05 bc 2e 06 	movsd  %xmm0,0x62ebc(%rip)        # 68c78 <fwp_heap+0x1438>
    5dbb:	00 
    5dbc:	48 83 c4 08          	add    $0x8,%rsp
    5dc0:	5b                   	pop    %rbx
    5dc1:	5d                   	pop    %rbp
    5dc2:	41 5c                	pop    %r12
    5dc4:	41 5d                	pop    %r13
    5dc6:	41 5e                	pop    %r14
    5dc8:	41 5f                	pop    %r15
    5dca:	c3                   	ret
    5dcb:	e8 40 e0 ff ff       	call   3e10 <fwp_heap_oom>

0000000000005dd0 <fwp_heap_alloc_slow>:
    5dd0:	53                   	push   %rbx
    5dd1:	48 89 f9             	mov    %rdi,%rcx
    5dd4:	41 89 f1             	mov    %esi,%r9d
    5dd7:	48 83 ec 10          	sub    $0x10,%rsp
    5ddb:	8b 05 03 2e 06 00    	mov    0x62e03(%rip),%eax        # 68be4 <fwp_heap+0x13a4>
    5de1:	85 c0                	test   %eax,%eax
    5de3:	0f 84 c7 00 00 00    	je     5eb0 <fwp_heap_alloc_slow+0xe0>
    5de9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5df0:	0f 87 dd 00 00 00    	ja     5ed3 <fwp_heap_alloc_slow+0x103>
    5df6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dfa:	48 8d 3d 3f 1a 06 00 	lea    0x61a3f(%rip),%rdi        # 67840 <fwp_heap>
    5e01:	49 63 f1             	movslq %r9d,%rsi
    5e04:	48 c1 e8 04          	shr    $0x4,%rax
    5e08:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5e0f:	00 00 
    5e11:	41 0f b6 c2          	movzbl %r10b,%eax
    5e15:	4c 89 d2             	mov    %r10,%rdx
    5e18:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5e1c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5e23:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5e2a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5e2e:	48 01 f8             	add    %rdi,%rax
    5e31:	4c 8b 00             	mov    (%rax),%r8
    5e34:	4d 85 c0             	test   %r8,%r8
    5e37:	0f 84 ab 00 00 00    	je     5ee8 <fwp_heap_alloc_slow+0x118>
    5e3d:	49 8b 10             	mov    (%r8),%rdx
    5e40:	48 f7 d2             	not    %rdx
    5e43:	48 89 10             	mov    %rdx,(%rax)
    5e46:	41 83 f9 01          	cmp    $0x1,%r9d
    5e4a:	4c 89 c7             	mov    %r8,%rdi
    5e4d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e51:	31 f6                	xor    %esi,%esi
    5e53:	48 89 ca             	mov    %rcx,%rdx
    5e56:	e8 55 d6 ff ff       	call   34b0 <memset@plt>
    5e5b:	49 89 c0             	mov    %rax,%r8
    5e5e:	48 89 d8             	mov    %rbx,%rax
    5e61:	48 03 05 f8 2d 06 00 	add    0x62df8(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    5e68:	0f 82 d9 00 00 00    	jb     5f47 <fwp_heap_alloc_slow+0x177>
    5e6e:	48 39 05 f3 2d 06 00 	cmp    %rax,0x62df3(%rip)        # 68c68 <fwp_heap+0x1428>
    5e75:	48 89 05 e4 2d 06 00 	mov    %rax,0x62de4(%rip)        # 68c60 <fwp_heap+0x1420>
    5e7c:	73 07                	jae    5e85 <fwp_heap_alloc_slow+0xb5>
    5e7e:	48 89 05 e3 2d 06 00 	mov    %rax,0x62de3(%rip)        # 68c68 <fwp_heap+0x1428>
    5e85:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e89:	4c 89 c0             	mov    %r8,%rax
    5e8c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e91:	f2 0f 58 05 df 2d 06 	addsd  0x62ddf(%rip),%xmm0        # 68c78 <fwp_heap+0x1438>
    5e98:	00 
    5e99:	f2 0f 11 05 d7 2d 06 	movsd  %xmm0,0x62dd7(%rip)        # 68c78 <fwp_heap+0x1438>
    5ea0:	00 
    5ea1:	48 83 c4 10          	add    $0x10,%rsp
    5ea5:	5b                   	pop    %rbx
    5ea6:	c3                   	ret
    5ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5eae:	00 00 
    5eb0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5eb4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5eb8:	e8 f3 ee ff ff       	call   4db0 <fwp_heap_init>
    5ebd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5ec1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5ec6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5ecd:	0f 86 23 ff ff ff    	jbe    5df6 <fwp_heap_alloc_slow+0x26>
    5ed3:	48 83 c4 10          	add    $0x10,%rsp
    5ed7:	44 89 ce             	mov    %r9d,%esi
    5eda:	48 89 cf             	mov    %rcx,%rdi
    5edd:	5b                   	pop    %rbx
    5ede:	e9 cd fd ff ff       	jmp    5cb0 <fwp_heap_alloc_big>
    5ee3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ee8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eec:	4d 85 c0             	test   %r8,%r8
    5eef:	74 1f                	je     5f10 <fwp_heap_alloc_slow+0x140>
    5ef1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5ef5:	4d 29 c3             	sub    %r8,%r11
    5ef8:	49 39 db             	cmp    %rbx,%r11
    5efb:	72 13                	jb     5f10 <fwp_heap_alloc_slow+0x140>
    5efd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5f01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f05:	e9 3c ff ff ff       	jmp    5e46 <fwp_heap_alloc_slow+0x76>
    5f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5f17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5f1b:	44 89 ca             	mov    %r9d,%edx
    5f1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5f23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5f2b:	44 89 d6             	mov    %r10d,%esi
    5f2e:	48 01 c7             	add    %rax,%rdi
    5f31:	e8 6a fa ff ff       	call   59a0 <fwp_heap_refill>
    5f36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5f3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f3f:	49 89 c0             	mov    %rax,%r8
    5f42:	e9 ff fe ff ff       	jmp    5e46 <fwp_heap_alloc_slow+0x76>
    5f47:	e8 c4 de ff ff       	call   3e10 <fwp_heap_oom>
    5f4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f50 <fwp_heap_alloc>:
    5f50:	53                   	push   %rbx
    5f51:	48 89 fa             	mov    %rdi,%rdx
    5f54:	48 83 ec 10          	sub    $0x10,%rsp
    5f58:	8b 1d aa 35 06 00    	mov    0x635aa(%rip),%ebx        # 69508 <iteration_active>
    5f5e:	8b 05 80 2c 06 00    	mov    0x62c80(%rip),%eax        # 68be4 <fwp_heap+0x13a4>
    5f64:	85 db                	test   %ebx,%ebx
    5f66:	0f 85 04 01 00 00    	jne    6070 <fwp_heap_alloc+0x120>
    5f6c:	85 c0                	test   %eax,%eax
    5f6e:	0f 84 ac 01 00 00    	je     6120 <fwp_heap_alloc+0x1d0>
    5f74:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f7b:	0f 87 9f 01 00 00    	ja     6120 <fwp_heap_alloc+0x1d0>
    5f81:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f85:	48 8d 05 b4 18 06 00 	lea    0x618b4(%rip),%rax        # 67840 <fwp_heap>
    5f8c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f90:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f97:	00 
    5f98:	48 63 ce             	movslq %esi,%rcx
    5f9b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5fa2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5fa9:	00 
    5faa:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5fae:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5fb2:	48 01 c8             	add    %rcx,%rax
    5fb5:	48 8b 08             	mov    (%rax),%rcx
    5fb8:	48 85 c9             	test   %rcx,%rcx
    5fbb:	0f 84 ff 00 00 00    	je     60c0 <fwp_heap_alloc+0x170>
    5fc1:	48 8b 39             	mov    (%rcx),%rdi
    5fc4:	48 f7 d7             	not    %rdi
    5fc7:	48 89 38             	mov    %rdi,(%rax)
    5fca:	83 fe 01             	cmp    $0x1,%esi
    5fcd:	48 89 cf             	mov    %rcx,%rdi
    5fd0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5fd5:	49 0f 45 d0          	cmovne %r8,%rdx
    5fd9:	31 f6                	xor    %esi,%esi
    5fdb:	e8 d0 d4 ff ff       	call   34b0 <memset@plt>
    5fe0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fe5:	48 89 c1             	mov    %rax,%rcx
    5fe8:	4c 89 c0             	mov    %r8,%rax
    5feb:	48 03 05 6e 2c 06 00 	add    0x62c6e(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    5ff2:	0f 82 35 01 00 00    	jb     612d <fwp_heap_alloc+0x1dd>
    5ff8:	48 39 05 69 2c 06 00 	cmp    %rax,0x62c69(%rip)        # 68c68 <fwp_heap+0x1428>
    5fff:	48 89 05 5a 2c 06 00 	mov    %rax,0x62c5a(%rip)        # 68c60 <fwp_heap+0x1420>
    6006:	73 07                	jae    600f <fwp_heap_alloc+0xbf>
    6008:	48 89 05 59 2c 06 00 	mov    %rax,0x62c59(%rip)        # 68c68 <fwp_heap+0x1428>
    600f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6013:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    6018:	f2 0f 58 05 58 2c 06 	addsd  0x62c58(%rip),%xmm0        # 68c78 <fwp_heap+0x1438>
    601f:	00 
    6020:	f2 0f 11 05 50 2c 06 	movsd  %xmm0,0x62c50(%rip)        # 68c78 <fwp_heap+0x1438>
    6027:	00 
    6028:	85 db                	test   %ebx,%ebx
    602a:	74 33                	je     605f <fwp_heap_alloc+0x10f>
    602c:	48 8b 05 2d 2c 06 00 	mov    0x62c2d(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    6033:	48 85 c0             	test   %rax,%rax
    6036:	0f 88 ac 00 00 00    	js     60e8 <fwp_heap_alloc+0x198>
    603c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6040:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6045:	f2 0f 5c 05 9b 34 06 	subsd  0x6349b(%rip),%xmm0        # 694e8 <iteration_start_charge>
    604c:	00 
    604d:	66 0f 2f 05 8b 34 06 	comisd 0x6348b(%rip),%xmm0        # 694e0 <iteration_peak>
    6054:	00 
    6055:	76 08                	jbe    605f <fwp_heap_alloc+0x10f>
    6057:	f2 0f 11 05 81 34 06 	movsd  %xmm0,0x63481(%rip)        # 694e0 <iteration_peak>
    605e:	00 
    605f:	48 83 c4 10          	add    $0x10,%rsp
    6063:	48 89 c8             	mov    %rcx,%rax
    6066:	5b                   	pop    %rbx
    6067:	c3                   	ret
    6068:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    606f:	00 
    6070:	85 f6                	test   %esi,%esi
    6072:	74 34                	je     60a8 <fwp_heap_alloc+0x158>
    6074:	48 83 05 84 34 06 00 	addq   $0x1,0x63484(%rip)        # 69500 <iteration_requests>
    607b:	01 
    607c:	48 01 3d 75 34 06 00 	add    %rdi,0x63475(%rip)        # 694f8 <iteration_bytes>
    6083:	85 c0                	test   %eax,%eax
    6085:	74 0d                	je     6094 <fwp_heap_alloc+0x144>
    6087:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    608e:	0f 86 ed fe ff ff    	jbe    5f81 <fwp_heap_alloc+0x31>
    6094:	48 89 d7             	mov    %rdx,%rdi
    6097:	e8 34 fd ff ff       	call   5dd0 <fwp_heap_alloc_slow>
    609c:	48 89 c1             	mov    %rax,%rcx
    609f:	eb 8b                	jmp    602c <fwp_heap_alloc+0xdc>
    60a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60a8:	85 c0                	test   %eax,%eax
    60aa:	74 0d                	je     60b9 <fwp_heap_alloc+0x169>
    60ac:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60b3:	0f 86 c8 fe ff ff    	jbe    5f81 <fwp_heap_alloc+0x31>
    60b9:	31 f6                	xor    %esi,%esi
    60bb:	eb d7                	jmp    6094 <fwp_heap_alloc+0x144>
    60bd:	0f 1f 00             	nopl   (%rax)
    60c0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    60c4:	48 85 c9             	test   %rcx,%rcx
    60c7:	74 0c                	je     60d5 <fwp_heap_alloc+0x185>
    60c9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    60cd:	48 29 cf             	sub    %rcx,%rdi
    60d0:	4c 39 c7             	cmp    %r8,%rdi
    60d3:	73 3b                	jae    6110 <fwp_heap_alloc+0x1c0>
    60d5:	48 89 d7             	mov    %rdx,%rdi
    60d8:	e8 f3 fc ff ff       	call   5dd0 <fwp_heap_alloc_slow>
    60dd:	48 89 c1             	mov    %rax,%rcx
    60e0:	e9 43 ff ff ff       	jmp    6028 <fwp_heap_alloc+0xd8>
    60e5:	0f 1f 00             	nopl   (%rax)
    60e8:	48 89 c2             	mov    %rax,%rdx
    60eb:	83 e0 01             	and    $0x1,%eax
    60ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60f2:	48 d1 ea             	shr    $1,%rdx
    60f5:	48 09 c2             	or     %rax,%rdx
    60f8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60fd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6101:	e9 3f ff ff ff       	jmp    6045 <fwp_heap_alloc+0xf5>
    6106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    610d:	00 00 00 
    6110:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6114:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6118:	e9 ad fe ff ff       	jmp    5fca <fwp_heap_alloc+0x7a>
    611d:	0f 1f 00             	nopl   (%rax)
    6120:	48 83 c4 10          	add    $0x10,%rsp
    6124:	48 89 d7             	mov    %rdx,%rdi
    6127:	5b                   	pop    %rbx
    6128:	e9 a3 fc ff ff       	jmp    5dd0 <fwp_heap_alloc_slow>
    612d:	e8 de dc ff ff       	call   3e10 <fwp_heap_oom>
    6132:	0f 1f 00             	nopl   (%rax)
    6135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    613c:	00 00 00 00 

0000000000006140 <fwp_data.part.0.constprop.0>:
    6140:	41 56                	push   %r14
    6142:	8b 05 9c 2a 06 00    	mov    0x62a9c(%rip),%eax        # 68be4 <fwp_heap+0x13a4>
    6148:	41 89 fe             	mov    %edi,%r14d
    614b:	41 55                	push   %r13
    614d:	44 8b 2d b4 33 06 00 	mov    0x633b4(%rip),%r13d        # 69508 <iteration_active>
    6154:	41 54                	push   %r12
    6156:	49 89 f4             	mov    %rsi,%r12
    6159:	55                   	push   %rbp
    615a:	53                   	push   %rbx
    615b:	45 85 ed             	test   %r13d,%r13d
    615e:	0f 84 1c 01 00 00    	je     6280 <fwp_data.part.0.constprop.0+0x140>
    6164:	48 83 05 94 33 06 00 	addq   $0x1,0x63394(%rip)        # 69500 <iteration_requests>
    616b:	01 
    616c:	48 83 05 84 33 06 00 	addq   $0x18,0x63384(%rip)        # 694f8 <iteration_bytes>
    6173:	18 
    6174:	85 c0                	test   %eax,%eax
    6176:	0f 84 8c 01 00 00    	je     6308 <fwp_data.part.0.constprop.0+0x1c8>
    617c:	0f b6 05 5f 26 06 00 	movzbl 0x6265f(%rip),%eax        # 687e2 <fwp_heap+0xfa2>
    6183:	48 8d 15 b6 16 06 00 	lea    0x616b6(%rip),%rdx        # 67840 <fwp_heap>
    618a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6191:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6195:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6199:	48 8b 18             	mov    (%rax),%rbx
    619c:	48 85 db             	test   %rbx,%rbx
    619f:	0f 84 fb 00 00 00    	je     62a0 <fwp_data.part.0.constprop.0+0x160>
    61a5:	48 8b 13             	mov    (%rbx),%rdx
    61a8:	48 f7 d2             	not    %rdx
    61ab:	48 89 10             	mov    %rdx,(%rax)
    61ae:	48 83 fd 18          	cmp    $0x18,%rbp
    61b2:	76 1b                	jbe    61cf <fwp_data.part.0.constprop.0+0x8f>
    61b4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    61b8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    61bc:	31 f6                	xor    %esi,%esi
    61be:	48 c1 e8 03          	shr    $0x3,%rax
    61c2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    61c9:	00 
    61ca:	e8 e1 d2 ff ff       	call   34b0 <memset@plt>
    61cf:	48 89 e8             	mov    %rbp,%rax
    61d2:	48 03 05 87 2a 06 00 	add    0x62a87(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    61d9:	0f 82 3d 01 00 00    	jb     631c <fwp_data.part.0.constprop.0+0x1dc>
    61df:	48 39 05 82 2a 06 00 	cmp    %rax,0x62a82(%rip)        # 68c68 <fwp_heap+0x1428>
    61e6:	48 89 05 73 2a 06 00 	mov    %rax,0x62a73(%rip)        # 68c60 <fwp_heap+0x1420>
    61ed:	73 07                	jae    61f6 <fwp_data.part.0.constprop.0+0xb6>
    61ef:	48 89 05 72 2a 06 00 	mov    %rax,0x62a72(%rip)        # 68c68 <fwp_heap+0x1428>
    61f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61fa:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61ff:	f2 0f 58 05 71 2a 06 	addsd  0x62a71(%rip),%xmm0        # 68c78 <fwp_heap+0x1438>
    6206:	00 
    6207:	f2 0f 11 05 69 2a 06 	movsd  %xmm0,0x62a69(%rip)        # 68c78 <fwp_heap+0x1438>
    620e:	00 
    620f:	45 85 ed             	test   %r13d,%r13d
    6212:	74 33                	je     6247 <fwp_data.part.0.constprop.0+0x107>
    6214:	48 8b 05 45 2a 06 00 	mov    0x62a45(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    621b:	48 85 c0             	test   %rax,%rax
    621e:	0f 88 a4 00 00 00    	js     62c8 <fwp_data.part.0.constprop.0+0x188>
    6224:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6228:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    622d:	f2 0f 5c 05 b3 32 06 	subsd  0x632b3(%rip),%xmm0        # 694e8 <iteration_start_charge>
    6234:	00 
    6235:	66 0f 2f 05 a3 32 06 	comisd 0x632a3(%rip),%xmm0        # 694e0 <iteration_peak>
    623c:	00 
    623d:	76 08                	jbe    6247 <fwp_data.part.0.constprop.0+0x107>
    623f:	f2 0f 11 05 99 32 06 	movsd  %xmm0,0x63299(%rip)        # 694e0 <iteration_peak>
    6246:	00 
    6247:	b8 02 00 00 00       	mov    $0x2,%eax
    624c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6251:	66 0f 6e c8          	movd   %eax,%xmm1
    6255:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6259:	66 0f d6 03          	movq   %xmm0,(%rbx)
    625d:	49 8b 04 24          	mov    (%r12),%rax
    6261:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6265:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    626a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    626e:	48 89 d8             	mov    %rbx,%rax
    6271:	5b                   	pop    %rbx
    6272:	5d                   	pop    %rbp
    6273:	41 5c                	pop    %r12
    6275:	41 5d                	pop    %r13
    6277:	41 5e                	pop    %r14
    6279:	c3                   	ret
    627a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6280:	85 c0                	test   %eax,%eax
    6282:	0f 85 f4 fe ff ff    	jne    617c <fwp_data.part.0.constprop.0+0x3c>
    6288:	31 f6                	xor    %esi,%esi
    628a:	bf 18 00 00 00       	mov    $0x18,%edi
    628f:	e8 bc fc ff ff       	call   5f50 <fwp_heap_alloc>
    6294:	48 89 c3             	mov    %rax,%rbx
    6297:	eb ae                	jmp    6247 <fwp_data.part.0.constprop.0+0x107>
    6299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    62a4:	48 85 db             	test   %rbx,%rbx
    62a7:	74 47                	je     62f0 <fwp_data.part.0.constprop.0+0x1b0>
    62a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    62ad:	48 29 da             	sub    %rbx,%rdx
    62b0:	48 39 ea             	cmp    %rbp,%rdx
    62b3:	72 3b                	jb     62f0 <fwp_data.part.0.constprop.0+0x1b0>
    62b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    62b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    62bd:	e9 ec fe ff ff       	jmp    61ae <fwp_data.part.0.constprop.0+0x6e>
    62c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62c8:	48 89 c2             	mov    %rax,%rdx
    62cb:	83 e0 01             	and    $0x1,%eax
    62ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
    62d2:	48 d1 ea             	shr    $1,%rdx
    62d5:	48 09 c2             	or     %rax,%rdx
    62d8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    62dd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62e1:	e9 47 ff ff ff       	jmp    622d <fwp_data.part.0.constprop.0+0xed>
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	31 f6                	xor    %esi,%esi
    62f2:	bf 18 00 00 00       	mov    $0x18,%edi
    62f7:	e8 54 fc ff ff       	call   5f50 <fwp_heap_alloc>
    62fc:	48 89 c3             	mov    %rax,%rbx
    62ff:	e9 0b ff ff ff       	jmp    620f <fwp_data.part.0.constprop.0+0xcf>
    6304:	0f 1f 40 00          	nopl   0x0(%rax)
    6308:	31 f6                	xor    %esi,%esi
    630a:	bf 18 00 00 00       	mov    $0x18,%edi
    630f:	e8 3c fc ff ff       	call   5f50 <fwp_heap_alloc>
    6314:	48 89 c3             	mov    %rax,%rbx
    6317:	e9 f8 fe ff ff       	jmp    6214 <fwp_data.part.0.constprop.0+0xd4>
    631c:	e8 ef da ff ff       	call   3e10 <fwp_heap_oom>
    6321:	0f 1f 40 00          	nopl   0x0(%rax)
    6325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    632c:	00 00 00 00 

0000000000006330 <fwp_p_ad_push>:
    6330:	41 57                	push   %r15
    6332:	41 56                	push   %r14
    6334:	41 55                	push   %r13
    6336:	49 89 d5             	mov    %rdx,%r13
    6339:	41 54                	push   %r12
    633b:	49 89 fc             	mov    %rdi,%r12
    633e:	55                   	push   %rbp
    633f:	53                   	push   %rbx
    6340:	48 83 ec 38          	sub    $0x38,%rsp
    6344:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6349:	48 85 ff             	test   %rdi,%rdi
    634c:	79 09                	jns    6357 <fwp_p_ad_push+0x27>
    634e:	48 85 d2             	test   %rdx,%rdx
    6351:	0f 88 a9 01 00 00    	js     6500 <fwp_p_ad_push+0x1d0>
    6357:	48 89 f8             	mov    %rdi,%rax
    635a:	48 89 0c 24          	mov    %rcx,(%rsp)
    635e:	48 09 d0             	or     %rdx,%rax
    6361:	0f 89 71 01 00 00    	jns    64d8 <fwp_p_ad_push+0x1a8>
    6367:	48 89 f8             	mov    %rdi,%rax
    636a:	48 c1 f8 20          	sar    $0x20,%rax
    636e:	48 85 ff             	test   %rdi,%rdi
    6371:	79 24                	jns    6397 <fwp_p_ad_push+0x67>
    6373:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6378:	48 89 d0             	mov    %rdx,%rax
    637b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6382:	00 
    6383:	49 89 d4             	mov    %rdx,%r12
    6386:	48 c1 f8 20          	sar    $0x20,%rax
    638a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6391:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6397:	48 89 c7             	mov    %rax,%rdi
    639a:	e8 71 e3 ff ff       	call   4710 <fwp_tape_of>
    639f:	48 89 c3             	mov    %rax,%rbx
    63a2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63a7:	0f 85 6e 02 00 00    	jne    661b <fwp_p_ad_push+0x2eb>
    63ad:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63b1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63b8:	0f 8f 51 02 00 00    	jg     660f <fwp_p_ad_push+0x2df>
    63be:	44 89 e0             	mov    %r12d,%eax
    63c1:	4c 39 f8             	cmp    %r15,%rax
    63c4:	0f 8d 39 02 00 00    	jge    6603 <fwp_p_ad_push+0x2d3>
    63ca:	4d 85 ed             	test   %r13,%r13
    63cd:	78 0c                	js     63db <fwp_p_ad_push+0xab>
    63cf:	44 89 e8             	mov    %r13d,%eax
    63d2:	4c 39 f8             	cmp    %r15,%rax
    63d5:	0f 8d 28 02 00 00    	jge    6603 <fwp_p_ad_push+0x2d3>
    63db:	4d 89 fe             	mov    %r15,%r14
    63de:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63e2:	49 8d 46 01          	lea    0x1(%r14),%rax
    63e6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ec:	0f 87 1d 02 00 00    	ja     660f <fwp_p_ad_push+0x2df>
    63f2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63f6:	48 39 e8             	cmp    %rbp,%rax
    63f9:	0f 8e 31 01 00 00    	jle    6530 <fwp_p_ad_push+0x200>
    63ff:	48 85 ed             	test   %rbp,%rbp
    6402:	ba 40 00 00 00       	mov    $0x40,%edx
    6407:	48 0f 44 ea          	cmove  %rdx,%rbp
    640b:	48 39 e8             	cmp    %rbp,%rax
    640e:	7e 20                	jle    6430 <fwp_p_ad_push+0x100>
    6410:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6417:	0f 8f 03 01 00 00    	jg     6520 <fwp_p_ad_push+0x1f0>
    641d:	48 01 ed             	add    %rbp,%rbp
    6420:	48 39 e8             	cmp    %rbp,%rax
    6423:	7f eb                	jg     6410 <fwp_p_ad_push+0xe0>
    6425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    642c:	00 00 00 00 
    6430:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6437:	00 
    6438:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    643c:	ba 01 00 00 00       	mov    $0x1,%edx
    6441:	48 89 c6             	mov    %rax,%rsi
    6444:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6449:	e8 82 ed ff ff       	call   51d0 <ad_raw_realloc>
    644e:	48 85 c0             	test   %rax,%rax
    6451:	0f 84 d0 01 00 00    	je     6627 <fwp_p_ad_push+0x2f7>
    6457:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    645b:	48 89 ee             	mov    %rbp,%rsi
    645e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6462:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6466:	48 c1 e6 04          	shl    $0x4,%rsi
    646a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    646e:	ba 02 00 00 00       	mov    $0x2,%edx
    6473:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6477:	e8 54 ed ff ff       	call   51d0 <ad_raw_realloc>
    647c:	48 85 c0             	test   %rax,%rax
    647f:	0f 84 a2 01 00 00    	je     6627 <fwp_p_ad_push+0x2f7>
    6485:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6489:	48 89 43 30          	mov    %rax,0x30(%rbx)
    648d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6494:	00 
    6495:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    649c:	00 
    649d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64a4:	00 
    64a5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64a9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ae:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64b2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64b6:	4d 85 f6             	test   %r14,%r14
    64b9:	0f 85 e5 00 00 00    	jne    65a4 <fwp_p_ad_push+0x274>
    64bf:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64c3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64c7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64cb:	48 01 d1             	add    %rdx,%rcx
    64ce:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64d2:	eb 7c                	jmp    6550 <fwp_p_ad_push+0x220>
    64d4:	0f 1f 40 00          	nopl   0x0(%rax)
    64d8:	48 89 d0             	mov    %rdx,%rax
    64db:	48 c1 ff 20          	sar    $0x20,%rdi
    64df:	48 c1 f8 20          	sar    $0x20,%rax
    64e3:	48 39 c7             	cmp    %rax,%rdi
    64e6:	0f 84 ab fe ff ff    	je     6397 <fwp_p_ad_push+0x67>
    64ec:	48 8d 3d dd 54 00 00 	lea    0x54dd(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    64f3:	e8 38 df ff ff       	call   4430 <fwp_trap>
    64f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64ff:	00 
    6500:	48 83 c4 38          	add    $0x38,%rsp
    6504:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    650b:	5b                   	pop    %rbx
    650c:	5d                   	pop    %rbp
    650d:	41 5c                	pop    %r12
    650f:	41 5d                	pop    %r13
    6511:	41 5e                	pop    %r14
    6513:	41 5f                	pop    %r15
    6515:	c3                   	ret
    6516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    651d:	00 00 00 
    6520:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6525:	e9 06 ff ff ff       	jmp    6430 <fwp_p_ad_push+0x100>
    652a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6530:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6534:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6538:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    653f:	00 
    6540:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6547:	00 
    6548:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    654c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6550:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6556:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    655a:	4d 85 ed             	test   %r13,%r13
    655d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6562:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6568:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    656f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6573:	49 8d 47 01          	lea    0x1(%r15),%rax
    6577:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    657b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6581:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6585:	48 83 c4 38          	add    $0x38,%rsp
    6589:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6590:	ff ff ff 
    6593:	4c 21 e0             	and    %r12,%rax
    6596:	5b                   	pop    %rbx
    6597:	5d                   	pop    %rbp
    6598:	4c 09 f8             	or     %r15,%rax
    659b:	41 5c                	pop    %r12
    659d:	41 5d                	pop    %r13
    659f:	41 5e                	pop    %r14
    65a1:	41 5f                	pop    %r15
    65a3:	c3                   	ret
    65a4:	4c 89 ca             	mov    %r9,%rdx
    65a7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65ac:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65b1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65b6:	e8 35 d0 ff ff       	call   35f0 <memmove@plt>
    65bb:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65c0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65c4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65c9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65cd:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65d1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65d6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65da:	4c 89 d2             	mov    %r10,%rdx
    65dd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    65e2:	e8 09 d0 ff ff       	call   35f0 <memmove@plt>
    65e7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65eb:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65ef:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    65f4:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    65f9:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65fe:	e9 c0 fe ff ff       	jmp    64c3 <fwp_p_ad_push+0x193>
    6603:	48 8d 3d b8 4b 00 00 	lea    0x4bb8(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    660a:	e8 21 de ff ff       	call   4430 <fwp_trap>
    660f:	48 8d 3d 91 4b 00 00 	lea    0x4b91(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    6616:	e8 15 de ff ff       	call   4430 <fwp_trap>
    661b:	48 8d 3d f6 53 00 00 	lea    0x53f6(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    6622:	e8 09 de ff ff       	call   4430 <fwp_trap>
    6627:	48 89 df             	mov    %rbx,%rdi
    662a:	e8 41 d6 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    662f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6633:	48 85 ff             	test   %rdi,%rdi
    6636:	74 05                	je     663d <fwp_p_ad_push+0x30d>
    6638:	e8 d3 ea ff ff       	call   5110 <ad_raw_free.part.0>
    663d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6641:	48 85 ff             	test   %rdi,%rdi
    6644:	74 05                	je     664b <fwp_p_ad_push+0x31b>
    6646:	e8 c5 ea ff ff       	call   5110 <ad_raw_free.part.0>
    664b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    664f:	48 85 ff             	test   %rdi,%rdi
    6652:	74 05                	je     6659 <fwp_p_ad_push+0x329>
    6654:	e8 b7 ea ff ff       	call   5110 <ad_raw_free.part.0>
    6659:	31 c9                	xor    %ecx,%ecx
    665b:	31 c0                	xor    %eax,%eax
    665d:	31 d2                	xor    %edx,%edx
    665f:	be 01 00 00 00       	mov    $0x1,%esi
    6664:	89 53 04             	mov    %edx,0x4(%rbx)
    6667:	66 0f ef c0          	pxor   %xmm0,%xmm0
    666b:	ba 13 00 00 00       	mov    $0x13,%edx
    6670:	48 8d 3d 91 49 00 00 	lea    0x4991(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6677:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    667b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    667f:	48 8b 0d ba 89 00 00 	mov    0x89ba(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    6686:	48 89 43 40          	mov    %rax,0x40(%rbx)
    668a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    668e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6692:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6696:	e8 c5 cf ff ff       	call   3660 <fwrite@plt>
    669b:	31 ff                	xor    %edi,%edi
    669d:	e8 fe ce ff ff       	call   35a0 <fflush@plt>
    66a2:	bf 66 00 00 00       	mov    $0x66,%edi
    66a7:	e8 d4 cf ff ff       	call   3680 <_Exit@plt>
    66ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066b0 <w120>:
    66b0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66b4:	41 55                	push   %r13
    66b6:	48 89 fa             	mov    %rdi,%rdx
    66b9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66bd:	41 54                	push   %r12
    66bf:	49 89 fc             	mov    %rdi,%r12
    66c2:	55                   	push   %rbp
    66c3:	53                   	push   %rbx
    66c4:	48 89 f3             	mov    %rsi,%rbx
    66c7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66cc:	48 89 f1             	mov    %rsi,%rcx
    66cf:	48 83 ec 28          	sub    $0x28,%rsp
    66d3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66d9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66df:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66e5:	e8 46 fc ff ff       	call   6330 <fwp_p_ad_push>
    66ea:	48 89 c7             	mov    %rax,%rdi
    66ed:	e8 ae e8 ff ff       	call   4fa0 <caf75>
    66f2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    66f7:	e8 a4 e8 ff ff       	call   4fa0 <caf75>
    66fc:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6702:	66 0f 57 05 e6 55 00 	xorpd  0x55e6(%rip),%xmm0        # bcf0 <msg.8+0x80>
    6709:	00 
    670a:	48 89 da             	mov    %rbx,%rdx
    670d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6713:	48 89 c1             	mov    %rax,%rcx
    6716:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    671b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6720:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6726:	e8 05 fc ff ff       	call   6330 <fwp_p_ad_push>
    672b:	4c 89 e7             	mov    %r12,%rdi
    672e:	49 89 c5             	mov    %rax,%r13
    6731:	e8 6a e8 ff ff       	call   4fa0 <caf75>
    6736:	48 89 c6             	mov    %rax,%rsi
    6739:	e8 62 e8 ff ff       	call   4fa0 <caf75>
    673e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6743:	f2 0f 10 05 e5 55 00 	movsd  0x55e5(%rip),%xmm0        # bd30 <msg.8+0xc0>
    674a:	00 
    674b:	66 0f 57 15 9d 55 00 	xorpd  0x559d(%rip),%xmm2        # bcf0 <msg.8+0x80>
    6752:	00 
    6753:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6759:	48 89 c1             	mov    %rax,%rcx
    675c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6763:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6768:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    676d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6773:	e8 b8 fb ff ff       	call   6330 <fwp_p_ad_push>
    6778:	48 89 e9             	mov    %rbp,%rcx
    677b:	4c 89 ea             	mov    %r13,%rdx
    677e:	48 89 ee             	mov    %rbp,%rsi
    6781:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6787:	4c 89 ef             	mov    %r13,%rdi
    678a:	49 89 c4             	mov    %rax,%r12
    678d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6791:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6797:	e8 94 fb ff ff       	call   6330 <fwp_p_ad_push>
    679c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a2:	f2 0f 59 1d 8e 55 00 	mulsd  0x558e(%rip),%xmm3        # bd38 <msg.8+0xc8>
    67a9:	00 
    67aa:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b1:	00 59 40 
    67b4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67b9:	48 89 c2             	mov    %rax,%rdx
    67bc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67c3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67c9:	e8 62 fb ff ff       	call   6330 <fwp_p_ad_push>
    67ce:	4c 89 e2             	mov    %r12,%rdx
    67d1:	48 89 d9             	mov    %rbx,%rcx
    67d4:	48 89 de             	mov    %rbx,%rsi
    67d7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67dd:	4c 89 e7             	mov    %r12,%rdi
    67e0:	48 89 c5             	mov    %rax,%rbp
    67e3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67e7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67ed:	e8 3e fb ff ff       	call   6330 <fwp_p_ad_push>
    67f2:	48 89 c7             	mov    %rax,%rdi
    67f5:	e8 a6 e7 ff ff       	call   4fa0 <caf75>
    67fa:	48 89 c6             	mov    %rax,%rsi
    67fd:	e8 9e e7 ff ff       	call   4fa0 <caf75>
    6802:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6808:	48 89 ea             	mov    %rbp,%rdx
    680b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6811:	48 89 c1             	mov    %rax,%rcx
    6814:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6819:	e8 12 fb ff ff       	call   6330 <fwp_p_ad_push>
    681e:	48 83 c4 28          	add    $0x28,%rsp
    6822:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6827:	5b                   	pop    %rbx
    6828:	5d                   	pop    %rbp
    6829:	41 5c                	pop    %r12
    682b:	41 5d                	pop    %r13
    682d:	c3                   	ret
    682e:	66 90                	xchg   %ax,%ax

0000000000006830 <w176.constprop.0>:
    6830:	41 54                	push   %r12
    6832:	55                   	push   %rbp
    6833:	53                   	push   %rbx
    6834:	48 83 ec 10          	sub    $0x10,%rsp
    6838:	4c 8b 27             	mov    (%rdi),%r12
    683b:	4d 85 e4             	test   %r12,%r12
    683e:	74 78                	je     68b8 <w176.constprop.0+0x88>
    6840:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6847:	00 00 
    6849:	48 89 fd             	mov    %rdi,%rbp
    684c:	31 db                	xor    %ebx,%ebx
    684e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    685c:	00 00 00 00 
    6860:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6865:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    686b:	48 83 c3 02          	add    $0x2,%rbx
    686f:	e8 2c e7 ff ff       	call   4fa0 <caf75>
    6874:	48 89 c6             	mov    %rax,%rsi
    6877:	e8 24 e7 ff ff       	call   4fa0 <caf75>
    687c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6882:	4c 89 c2             	mov    %r8,%rdx
    6885:	48 89 c1             	mov    %rax,%rcx
    6888:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    688e:	e8 9d fa ff ff       	call   6330 <fwp_p_ad_push>
    6893:	48 89 c7             	mov    %rax,%rdi
    6896:	4c 39 e3             	cmp    %r12,%rbx
    6899:	72 c5                	jb     6860 <w176.constprop.0+0x30>
    689b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68a0:	48 83 c4 10          	add    $0x10,%rsp
    68a4:	5b                   	pop    %rbx
    68a5:	5d                   	pop    %rbp
    68a6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    68ab:	41 5c                	pop    %r12
    68ad:	48 89 f8             	mov    %rdi,%rax
    68b0:	c3                   	ret
    68b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    68bf:	00 00 
    68c1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68c8:	eb d1                	jmp    689b <w176.constprop.0+0x6b>
    68ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000068d0 <fwp_rc_share>:
    68d0:	48 8b 05 41 23 06 00 	mov    0x62341(%rip),%rax        # 68c18 <fwp_heap+0x13d8>
    68d7:	48 2b 3d 12 23 06 00 	sub    0x62312(%rip),%rdi        # 68bf0 <fwp_heap+0x13b0>
    68de:	48 c1 e0 10          	shl    $0x10,%rax
    68e2:	48 39 c7             	cmp    %rax,%rdi
    68e5:	73 4a                	jae    6931 <fwp_rc_share+0x61>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 c1 e8 10          	shr    $0x10,%rax
    68ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f2:	48 8b 05 3f 23 06 00 	mov    0x6233f(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    68f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    68fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6901:	48 85 d2             	test   %rdx,%rdx
    6904:	74 2b                	je     6931 <fwp_rc_share+0x61>
    6906:	0f b6 08             	movzbl (%rax),%ecx
    6909:	80 f9 02             	cmp    $0x2,%cl
    690c:	74 2a                	je     6938 <fwp_rc_share+0x68>
    690e:	80 f9 01             	cmp    $0x1,%cl
    6911:	75 1e                	jne    6931 <fwp_rc_share+0x61>
    6913:	8b 48 18             	mov    0x18(%rax),%ecx
    6916:	0f b7 ff             	movzwl %di,%edi
    6919:	8b 40 1c             	mov    0x1c(%rax),%eax
    691c:	48 0f af f9          	imul   %rcx,%rdi
    6920:	48 c1 ef 20          	shr    $0x20,%rdi
    6924:	48 39 c7             	cmp    %rax,%rdi
    6927:	73 08                	jae    6931 <fwp_rc_share+0x61>
    6929:	48 01 fa             	add    %rdi,%rdx
    692c:	80 3a 00             	cmpb   $0x0,(%rdx)
    692f:	75 0d                	jne    693e <fwp_rc_share+0x6e>
    6931:	c3                   	ret
    6932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6938:	66 85 ff             	test   %di,%di
    693b:	74 ef                	je     692c <fwp_rc_share+0x5c>
    693d:	c3                   	ret
    693e:	50                   	push   %rax
    693f:	48 8d 3d 02 51 00 00 	lea    0x5102(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    6946:	e8 e5 da ff ff       	call   4430 <fwp_trap>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006950 <fwp_rc_free_obj>:
    6950:	48 8b 15 c1 22 06 00 	mov    0x622c1(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 2b 05 8f 22 06 00 	sub    0x6228f(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    6961:	48 c1 e2 10          	shl    $0x10,%rdx
    6965:	48 39 d0             	cmp    %rdx,%rax
    6968:	73 5b                	jae    69c5 <fwp_rc_free_obj+0x75>
    696a:	48 89 c2             	mov    %rax,%rdx
    696d:	48 c1 ea 10          	shr    $0x10,%rdx
    6971:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6975:	48 8b 15 bc 22 06 00 	mov    0x622bc(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    697c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6980:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6984:	48 85 c9             	test   %rcx,%rcx
    6987:	74 3c                	je     69c5 <fwp_rc_free_obj+0x75>
    6989:	0f b6 32             	movzbl (%rdx),%esi
    698c:	40 80 fe 02          	cmp    $0x2,%sil
    6990:	74 2e                	je     69c0 <fwp_rc_free_obj+0x70>
    6992:	40 80 fe 01          	cmp    $0x1,%sil
    6996:	75 2d                	jne    69c5 <fwp_rc_free_obj+0x75>
    6998:	8b 72 18             	mov    0x18(%rdx),%esi
    699b:	0f b7 c0             	movzwl %ax,%eax
    699e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69a1:	48 0f af c6          	imul   %rsi,%rax
    69a5:	48 c1 e8 20          	shr    $0x20,%rax
    69a9:	48 39 d0             	cmp    %rdx,%rax
    69ac:	73 17                	jae    69c5 <fwp_rc_free_obj+0x75>
    69ae:	48 01 c1             	add    %rax,%rcx
    69b1:	80 39 01             	cmpb   $0x1,(%rcx)
    69b4:	75 0f                	jne    69c5 <fwp_rc_free_obj+0x75>
    69b6:	e9 95 f0 ff ff       	jmp    5a50 <fwp_mem_free>
    69bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 ec                	je     69b1 <fwp_rc_free_obj+0x61>
    69c5:	c3                   	ret
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 

00000000000069d0 <fwp_rc_dup>:
    69d0:	f3 0f 1e fa          	endbr64
    69d4:	48 8b 05 3d 22 06 00 	mov    0x6223d(%rip),%rax        # 68c18 <fwp_heap+0x13d8>
    69db:	48 2b 3d 0e 22 06 00 	sub    0x6220e(%rip),%rdi        # 68bf0 <fwp_heap+0x13b0>
    69e2:	48 c1 e0 10          	shl    $0x10,%rax
    69e6:	48 39 c7             	cmp    %rax,%rdi
    69e9:	73 60                	jae    6a4b <fwp_rc_dup+0x7b>
    69eb:	48 89 f8             	mov    %rdi,%rax
    69ee:	48 c1 e8 10          	shr    $0x10,%rax
    69f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    69f6:	48 8b 05 3b 22 06 00 	mov    0x6223b(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    69fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a01:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a05:	48 85 c0             	test   %rax,%rax
    6a08:	74 41                	je     6a4b <fwp_rc_dup+0x7b>
    6a0a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a0d:	80 f9 02             	cmp    $0x2,%cl
    6a10:	74 3e                	je     6a50 <fwp_rc_dup+0x80>
    6a12:	80 f9 01             	cmp    $0x1,%cl
    6a15:	75 34                	jne    6a4b <fwp_rc_dup+0x7b>
    6a17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a1a:	0f b7 ff             	movzwl %di,%edi
    6a1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a20:	48 0f af f9          	imul   %rcx,%rdi
    6a24:	48 c1 ef 20          	shr    $0x20,%rdi
    6a28:	48 39 d7             	cmp    %rdx,%rdi
    6a2b:	73 1e                	jae    6a4b <fwp_rc_dup+0x7b>
    6a2d:	48 01 f8             	add    %rdi,%rax
    6a30:	0f b6 10             	movzbl (%rax),%edx
    6a33:	84 d2                	test   %dl,%dl
    6a35:	74 14                	je     6a4b <fwp_rc_dup+0x7b>
    6a37:	8b 0d cb 2a 06 00    	mov    0x62acb(%rip),%ecx        # 69508 <iteration_active>
    6a3d:	85 c9                	test   %ecx,%ecx
    6a3f:	75 1f                	jne    6a60 <fwp_rc_dup+0x90>
    6a41:	80 fa fd             	cmp    $0xfd,%dl
    6a44:	77 2a                	ja     6a70 <fwp_rc_dup+0xa0>
    6a46:	83 c2 01             	add    $0x1,%edx
    6a49:	88 10                	mov    %dl,(%rax)
    6a4b:	c3                   	ret
    6a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a50:	66 85 ff             	test   %di,%di
    6a53:	74 db                	je     6a30 <fwp_rc_dup+0x60>
    6a55:	c3                   	ret
    6a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a5d:	00 00 00 
    6a60:	48 83 05 88 2a 06 00 	addq   $0x1,0x62a88(%rip)        # 694f0 <iteration_retains>
    6a67:	01 
    6a68:	eb d7                	jmp    6a41 <fwp_rc_dup+0x71>
    6a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a70:	48 89 c7             	mov    %rax,%rdi
    6a73:	e9 78 ec ff ff       	jmp    56f0 <fwp_rc_wide_dup>
    6a78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a7f:	00 

0000000000006a80 <fwp_owned_entry173>:
    6a80:	f3 0f 1e fa          	endbr64
    6a84:	48 83 ec 38          	sub    $0x38,%rsp
    6a88:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a8d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a94:	00 00 
    6a96:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a9b:	31 c0                	xor    %eax,%eax
    6a9d:	48 8b 07             	mov    (%rdi),%rax
    6aa0:	48 03 47 10          	add    0x10(%rdi),%rax
    6aa4:	0f 80 c2 00 00 00    	jo     6b6c <fwp_owned_entry173+0xec>
    6aaa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6aaf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ab4:	31 ff                	xor    %edi,%edi
    6ab6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6aba:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6abf:	e8 7c f6 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    6ac4:	48 8b 15 4d 21 06 00 	mov    0x6214d(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    6acb:	48 89 c6             	mov    %rax,%rsi
    6ace:	48 2b 05 1b 21 06 00 	sub    0x6211b(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    6ad5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ad9:	48 39 d0             	cmp    %rdx,%rax
    6adc:	73 4f                	jae    6b2d <fwp_owned_entry173+0xad>
    6ade:	48 89 c2             	mov    %rax,%rdx
    6ae1:	48 c1 ea 10          	shr    $0x10,%rdx
    6ae5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ae9:	48 8b 15 48 21 06 00 	mov    0x62148(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    6af0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6af4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6af8:	48 85 d2             	test   %rdx,%rdx
    6afb:	74 30                	je     6b2d <fwp_owned_entry173+0xad>
    6afd:	0f b6 39             	movzbl (%rcx),%edi
    6b00:	40 80 ff 02          	cmp    $0x2,%dil
    6b04:	74 42                	je     6b48 <fwp_owned_entry173+0xc8>
    6b06:	40 80 ff 01          	cmp    $0x1,%dil
    6b0a:	75 21                	jne    6b2d <fwp_owned_entry173+0xad>
    6b0c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b0f:	0f b7 c0             	movzwl %ax,%eax
    6b12:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b15:	48 0f af c7          	imul   %rdi,%rax
    6b19:	48 c1 e8 20          	shr    $0x20,%rax
    6b1d:	48 39 c8             	cmp    %rcx,%rax
    6b20:	73 0b                	jae    6b2d <fwp_owned_entry173+0xad>
    6b22:	48 01 c2             	add    %rax,%rdx
    6b25:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b28:	74 26                	je     6b50 <fwp_owned_entry173+0xd0>
    6b2a:	c6 02 01             	movb   $0x1,(%rdx)
    6b2d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b39:	00 00 
    6b3b:	75 34                	jne    6b71 <fwp_owned_entry173+0xf1>
    6b3d:	48 89 f0             	mov    %rsi,%rax
    6b40:	48 83 c4 38          	add    $0x38,%rsp
    6b44:	c3                   	ret
    6b45:	0f 1f 00             	nopl   (%rax)
    6b48:	66 85 c0             	test   %ax,%ax
    6b4b:	75 e0                	jne    6b2d <fwp_owned_entry173+0xad>
    6b4d:	eb d6                	jmp    6b25 <fwp_owned_entry173+0xa5>
    6b4f:	90                   	nop
    6b50:	48 89 d7             	mov    %rdx,%rdi
    6b53:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b58:	48 89 14 24          	mov    %rdx,(%rsp)
    6b5c:	e8 af ec ff ff       	call   5810 <fwp_rc_forget_slot>
    6b61:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b66:	48 8b 14 24          	mov    (%rsp),%rdx
    6b6a:	eb be                	jmp    6b2a <fwp_owned_entry173+0xaa>
    6b6c:	e8 6f cb ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6b71:	e8 da c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b7d:	00 00 00 

0000000000006b80 <e173>:
    6b80:	f3 0f 1e fa          	endbr64
    6b84:	53                   	push   %rbx
    6b85:	48 83 ec 30          	sub    $0x30,%rsp
    6b89:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b95:	00 00 
    6b97:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b9c:	31 c0                	xor    %eax,%eax
    6b9e:	48 8b 07             	mov    (%rdi),%rax
    6ba1:	48 03 47 10          	add    0x10(%rdi),%rax
    6ba5:	0f 80 c9 00 00 00    	jo     6c74 <e173+0xf4>
    6bab:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6bb0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6bb5:	31 ff                	xor    %edi,%edi
    6bb7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bbb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6bc0:	e8 7b f5 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    6bc5:	48 8b 15 4c 20 06 00 	mov    0x6204c(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    6bcc:	48 89 c3             	mov    %rax,%rbx
    6bcf:	48 2b 05 1a 20 06 00 	sub    0x6201a(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    6bd6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bda:	48 39 d0             	cmp    %rdx,%rax
    6bdd:	73 4f                	jae    6c2e <e173+0xae>
    6bdf:	48 89 c2             	mov    %rax,%rdx
    6be2:	48 c1 ea 10          	shr    $0x10,%rdx
    6be6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bea:	48 8b 15 47 20 06 00 	mov    0x62047(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    6bf1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bf5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bf9:	48 85 d2             	test   %rdx,%rdx
    6bfc:	74 30                	je     6c2e <e173+0xae>
    6bfe:	0f b6 31             	movzbl (%rcx),%esi
    6c01:	40 80 fe 02          	cmp    $0x2,%sil
    6c05:	74 49                	je     6c50 <e173+0xd0>
    6c07:	40 80 fe 01          	cmp    $0x1,%sil
    6c0b:	75 21                	jne    6c2e <e173+0xae>
    6c0d:	8b 71 18             	mov    0x18(%rcx),%esi
    6c10:	0f b7 c0             	movzwl %ax,%eax
    6c13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c16:	48 0f af c6          	imul   %rsi,%rax
    6c1a:	48 c1 e8 20          	shr    $0x20,%rax
    6c1e:	48 39 c8             	cmp    %rcx,%rax
    6c21:	73 0b                	jae    6c2e <e173+0xae>
    6c23:	48 01 c2             	add    %rax,%rdx
    6c26:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c29:	74 35                	je     6c60 <e173+0xe0>
    6c2b:	c6 02 01             	movb   $0x1,(%rdx)
    6c2e:	48 89 df             	mov    %rbx,%rdi
    6c31:	e8 9a fc ff ff       	call   68d0 <fwp_rc_share>
    6c36:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c3b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c42:	00 00 
    6c44:	75 33                	jne    6c79 <e173+0xf9>
    6c46:	48 83 c4 30          	add    $0x30,%rsp
    6c4a:	48 89 d8             	mov    %rbx,%rax
    6c4d:	5b                   	pop    %rbx
    6c4e:	c3                   	ret
    6c4f:	90                   	nop
    6c50:	66 85 c0             	test   %ax,%ax
    6c53:	75 d9                	jne    6c2e <e173+0xae>
    6c55:	eb cf                	jmp    6c26 <e173+0xa6>
    6c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c5e:	00 00 
    6c60:	48 89 d7             	mov    %rdx,%rdi
    6c63:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c68:	e8 a3 eb ff ff       	call   5810 <fwp_rc_forget_slot>
    6c6d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c72:	eb b7                	jmp    6c2b <e173+0xab>
    6c74:	e8 67 ca ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6c79:	e8 d2 c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6c7e:	66 90                	xchg   %ax,%ax

0000000000006c80 <fwp_closure_drop>:
    6c80:	48 8b 15 91 1f 06 00 	mov    0x61f91(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    6c87:	48 89 f8             	mov    %rdi,%rax
    6c8a:	48 2b 05 5f 1f 06 00 	sub    0x61f5f(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    6c91:	48 c1 e2 10          	shl    $0x10,%rdx
    6c95:	48 39 d0             	cmp    %rdx,%rax
    6c98:	73 6b                	jae    6d05 <fwp_closure_drop+0x85>
    6c9a:	48 89 c2             	mov    %rax,%rdx
    6c9d:	48 c1 ea 10          	shr    $0x10,%rdx
    6ca1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ca5:	48 8b 15 8c 1f 06 00 	mov    0x61f8c(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    6cac:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6cb0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6cb4:	48 85 d2             	test   %rdx,%rdx
    6cb7:	74 4c                	je     6d05 <fwp_closure_drop+0x85>
    6cb9:	0f b6 31             	movzbl (%rcx),%esi
    6cbc:	40 80 fe 02          	cmp    $0x2,%sil
    6cc0:	74 3e                	je     6d00 <fwp_closure_drop+0x80>
    6cc2:	40 80 fe 01          	cmp    $0x1,%sil
    6cc6:	75 3d                	jne    6d05 <fwp_closure_drop+0x85>
    6cc8:	8b 71 18             	mov    0x18(%rcx),%esi
    6ccb:	0f b7 c0             	movzwl %ax,%eax
    6cce:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cd1:	48 0f af c6          	imul   %rsi,%rax
    6cd5:	48 c1 e8 20          	shr    $0x20,%rax
    6cd9:	48 39 c8             	cmp    %rcx,%rax
    6cdc:	73 27                	jae    6d05 <fwp_closure_drop+0x85>
    6cde:	48 01 c2             	add    %rax,%rdx
    6ce1:	0f b6 02             	movzbl (%rdx),%eax
    6ce4:	84 c0                	test   %al,%al
    6ce6:	74 1d                	je     6d05 <fwp_closure_drop+0x85>
    6ce8:	3c 01                	cmp    $0x1,%al
    6cea:	74 24                	je     6d10 <fwp_closure_drop+0x90>
    6cec:	3c ff                	cmp    $0xff,%al
    6cee:	74 48                	je     6d38 <fwp_closure_drop+0xb8>
    6cf0:	83 e8 01             	sub    $0x1,%eax
    6cf3:	88 02                	mov    %al,(%rdx)
    6cf5:	c3                   	ret
    6cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cfd:	00 00 00 
    6d00:	66 85 c0             	test   %ax,%ax
    6d03:	74 dc                	je     6ce1 <fwp_closure_drop+0x61>
    6d05:	c3                   	ret
    6d06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d0d:	00 00 00 
    6d10:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6d17:	ff ff 
    6d19:	48 85 c0             	test   %rax,%rax
    6d1c:	74 12                	je     6d30 <fwp_closure_drop+0xb0>
    6d1e:	48 89 fe             	mov    %rdi,%rsi
    6d21:	48 89 c7             	mov    %rax,%rdi
    6d24:	e9 67 d7 ff ff       	jmp    4490 <fwp_closure_drop_push>
    6d29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d30:	e9 0b d9 ff ff       	jmp    4640 <fwp_closure_drop.part.0>
    6d35:	0f 1f 00             	nopl   (%rax)
    6d38:	48 89 d0             	mov    %rdx,%rax
    6d3b:	48 8d 35 fe 0a 06 00 	lea    0x60afe(%rip),%rsi        # 67840 <fwp_heap>
    6d42:	48 83 ec 18          	sub    $0x18,%rsp
    6d46:	48 c1 e8 11          	shr    $0x11,%rax
    6d4a:	48 31 d0             	xor    %rdx,%rax
    6d4d:	48 89 c1             	mov    %rax,%rcx
    6d50:	48 c1 e9 09          	shr    $0x9,%rcx
    6d54:	48 31 c8             	xor    %rcx,%rax
    6d57:	0f b6 c8             	movzbl %al,%ecx
    6d5a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6d61:	00 
    6d62:	48 85 c0             	test   %rax,%rax
    6d65:	75 22                	jne    6d89 <fwp_closure_drop+0x109>
    6d67:	eb 59                	jmp    6dc2 <fwp_closure_drop+0x142>
    6d69:	90                   	nop
    6d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d71:	00 00 00 00 
    6d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d7c:	00 00 00 00 
    6d80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d84:	48 85 c0             	test   %rax,%rax
    6d87:	74 39                	je     6dc2 <fwp_closure_drop+0x142>
    6d89:	48 89 c1             	mov    %rax,%rcx
    6d8c:	48 39 10             	cmp    %rdx,(%rax)
    6d8f:	75 ef                	jne    6d80 <fwp_closure_drop+0x100>
    6d91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6da4:	74 05                	je     6dab <fwp_closure_drop+0x12b>
    6da6:	48 83 c4 18          	add    $0x18,%rsp
    6daa:	c3                   	ret
    6dab:	48 89 d7             	mov    %rdx,%rdi
    6dae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6db3:	e8 58 ea ff ff       	call   5810 <fwp_rc_forget_slot>
    6db8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6dc0:	eb e4                	jmp    6da6 <fwp_closure_drop+0x126>
    6dc2:	48 8d 3d df 4b 00 00 	lea    0x4bdf(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    6dc9:	e8 62 d6 ff ff       	call   4430 <fwp_trap>
    6dce:	66 90                	xchg   %ax,%ax

0000000000006dd0 <fwp_owned_tape_release>:
    6dd0:	48 85 ff             	test   %rdi,%rdi
    6dd3:	0f 84 f7 00 00 00    	je     6ed0 <fwp_owned_tape_release+0x100>
    6dd9:	41 54                	push   %r12
    6ddb:	55                   	push   %rbp
    6ddc:	53                   	push   %rbx
    6ddd:	48 8b 07             	mov    (%rdi),%rax
    6de0:	48 85 c0             	test   %rax,%rax
    6de3:	74 08                	je     6ded <fwp_owned_tape_release+0x1d>
    6de5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6de9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ded:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6df1:	48 85 d2             	test   %rdx,%rdx
    6df4:	74 03                	je     6df9 <fwp_owned_tape_release+0x29>
    6df6:	48 89 02             	mov    %rax,(%rdx)
    6df9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6dfd:	48 89 fb             	mov    %rdi,%rbx
    6e00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6e04:	48 85 c0             	test   %rax,%rax
    6e07:	0f 84 89 00 00 00    	je     6e96 <fwp_owned_tape_release+0xc6>
    6e0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6e11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6e15:	7e 47                	jle    6e5e <fwp_owned_tape_release+0x8e>
    6e17:	31 ed                	xor    %ebp,%ebp
    6e19:	eb 0d                	jmp    6e28 <fwp_owned_tape_release+0x58>
    6e1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e2c:	49 89 ec             	mov    %rbp,%r12
    6e2f:	48 83 c5 01          	add    $0x1,%rbp
    6e33:	49 c1 e4 04          	shl    $0x4,%r12
    6e37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e3b:	ff d0                	call   *%rax
    6e3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e4a:	ff 50 68             	call   *0x68(%rax)
    6e4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e55:	48 39 e8             	cmp    %rbp,%rax
    6e58:	7f c6                	jg     6e20 <fwp_owned_tape_release+0x50>
    6e5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e5e:	31 ed                	xor    %ebp,%ebp
    6e60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6e65:	7e 28                	jle    6e8f <fwp_owned_tape_release+0xbf>
    6e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e6e:	00 00 
    6e70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6e74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6e78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6e7c:	74 07                	je     6e85 <fwp_owned_tape_release+0xb5>
    6e7e:	ff 52 68             	call   *0x68(%rdx)
    6e81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e85:	48 83 c5 01          	add    $0x1,%rbp
    6e89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e8d:	7f e1                	jg     6e70 <fwp_owned_tape_release+0xa0>
    6e8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e93:	ff 52 68             	call   *0x68(%rdx)
    6e96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e9a:	e8 e1 fd ff ff       	call   6c80 <fwp_closure_drop>
    6e9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ea3:	e8 d8 fd ff ff       	call   6c80 <fwp_closure_drop>
    6ea8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6eac:	e8 cf fd ff ff       	call   6c80 <fwp_closure_drop>
    6eb1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6eb5:	e8 96 eb ff ff       	call   5a50 <fwp_mem_free>
    6eba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6ebe:	e8 8d eb ff ff       	call   5a50 <fwp_mem_free>
    6ec3:	48 89 df             	mov    %rbx,%rdi
    6ec6:	5b                   	pop    %rbx
    6ec7:	5d                   	pop    %rbp
    6ec8:	41 5c                	pop    %r12
    6eca:	e9 81 eb ff ff       	jmp    5a50 <fwp_mem_free>
    6ecf:	90                   	nop
    6ed0:	c3                   	ret
    6ed1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6edc:	00 00 00 00 

0000000000006ee0 <fwp_tape_finish>:
    6ee0:	f3 0f 1e fa          	endbr64
    6ee4:	41 55                	push   %r13
    6ee6:	41 54                	push   %r12
    6ee8:	55                   	push   %rbp
    6ee9:	53                   	push   %rbx
    6eea:	48 83 ec 48          	sub    $0x48,%rsp
    6eee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6ef5:	00 00 
    6ef7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6efc:	48 8d 3d bd 81 01 00 	lea    0x181bd(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    6f03:	e8 78 e2 ff ff       	call   5180 <fwp_tape_buffers_dispose>
    6f08:	48 83 3d f8 81 01 00 	cmpq   $0x0,0x181f8(%rip)        # 1f108 <fwp_ntapes>
    6f0f:	00 
    6f10:	48 c7 05 8d 81 01 00 	movq   $0x0,0x1818d(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    6f17:	00 00 00 00 
    6f1b:	7e 79                	jle    6f96 <fwp_tape_finish+0xb6>
    6f1d:	45 31 e4             	xor    %r12d,%r12d
    6f20:	31 ed                	xor    %ebp,%ebp
    6f22:	0f 1f 00             	nopl   (%rax)
    6f25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f2c:	00 00 00 00 
    6f30:	48 8b 1d d9 81 01 00 	mov    0x181d9(%rip),%rbx        # 1f110 <fwp_tapes>
    6f37:	48 83 c5 01          	add    $0x1,%rbp
    6f3b:	4c 01 e3             	add    %r12,%rbx
    6f3e:	49 83 c4 68          	add    $0x68,%r12
    6f42:	48 89 df             	mov    %rbx,%rdi
    6f45:	e8 26 cd ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6f4a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6f4f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6f54:	48 89 e7             	mov    %rsp,%rdi
    6f57:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f5b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6f5f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6f64:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f69:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6f6e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6f72:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6f77:	e8 04 e2 ff ff       	call   5180 <fwp_tape_buffers_dispose>
    6f7c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6f80:	e8 4b fe ff ff       	call   6dd0 <fwp_owned_tape_release>
    6f85:	48 39 2d 7c 81 01 00 	cmp    %rbp,0x1817c(%rip)        # 1f108 <fwp_ntapes>
    6f8c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6f93:	00 
    6f94:	7f 9a                	jg     6f30 <fwp_tape_finish+0x50>
    6f96:	48 8b 3d 73 81 01 00 	mov    0x18173(%rip),%rdi        # 1f110 <fwp_tapes>
    6f9d:	48 85 ff             	test   %rdi,%rdi
    6fa0:	74 05                	je     6fa7 <fwp_tape_finish+0xc7>
    6fa2:	e8 69 e1 ff ff       	call   5110 <ad_raw_free.part.0>
    6fa7:	48 c7 05 5e 81 01 00 	movq   $0x0,0x1815e(%rip)        # 1f110 <fwp_tapes>
    6fae:	00 00 00 00 
    6fb2:	48 c7 05 43 81 01 00 	movq   $0x0,0x18143(%rip)        # 1f100 <fwp_tapes_cap>
    6fb9:	00 00 00 00 
    6fbd:	48 c7 05 40 81 01 00 	movq   $0x0,0x18140(%rip)        # 1f108 <fwp_ntapes>
    6fc4:	00 00 00 00 
    6fc8:	48 c7 05 25 81 01 00 	movq   $0x0,0x18125(%rip)        # 1f0f8 <fwp_tape_next_slot>
    6fcf:	00 00 00 00 
    6fd3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6fd8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6fdf:	00 00 
    6fe1:	75 0b                	jne    6fee <fwp_tape_finish+0x10e>
    6fe3:	48 83 c4 48          	add    $0x48,%rsp
    6fe7:	5b                   	pop    %rbx
    6fe8:	5d                   	pop    %rbp
    6fe9:	41 5c                	pop    %r12
    6feb:	41 5d                	pop    %r13
    6fed:	c3                   	ret
    6fee:	e8 5d c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6ff3:	66 90                	xchg   %ax,%ax
    6ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ffc:	00 00 00 00 

0000000000007000 <fwp_tape_scope_release>:
    7000:	f3 0f 1e fa          	endbr64
    7004:	41 55                	push   %r13
    7006:	41 54                	push   %r12
    7008:	55                   	push   %rbp
    7009:	53                   	push   %rbx
    700a:	48 83 ec 48          	sub    $0x48,%rsp
    700e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7015:	00 00 
    7017:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    701c:	48 63 07             	movslq (%rdi),%rax
    701f:	85 c0                	test   %eax,%eax
    7021:	0f 88 e8 00 00 00    	js     710f <fwp_tape_scope_release+0x10f>
    7027:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    702e:	ec c4 4e 
    7031:	48 89 fb             	mov    %rdi,%rbx
    7034:	48 89 e5             	mov    %rsp,%rbp
    7037:	eb 1f                	jmp    7058 <fwp_tape_scope_release+0x58>
    7039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7040:	e8 3b e1 ff ff       	call   5180 <fwp_tape_buffers_dispose>
    7045:	4c 89 ef             	mov    %r13,%rdi
    7048:	e8 83 fd ff ff       	call   6dd0 <fwp_owned_tape_release>
    704d:	48 63 03             	movslq (%rbx),%rax
    7050:	85 c0                	test   %eax,%eax
    7052:	0f 88 b7 00 00 00    	js     710f <fwp_tape_scope_release+0x10f>
    7058:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    705c:	48 8b 35 ad 80 01 00 	mov    0x180ad(%rip),%rsi        # 1f110 <fwp_tapes>
    7063:	4c 01 c6             	add    %r8,%rsi
    7066:	48 89 f7             	mov    %rsi,%rdi
    7069:	e8 02 cc ff ff       	call   3c70 <fwp_tape_unlink_scope>
    706e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7073:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7078:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    707f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7083:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7087:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    708e:	00 
    708f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7094:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7099:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    709d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    70a2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70a6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    70ab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    70b2:	00 
    70b3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    70ba:	00 
    70bb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    70c2:	00 
    70c3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    70c7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    70cb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    70cf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    70d3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    70d9:	77 18                	ja     70f3 <fwp_tape_scope_release+0xf3>
    70db:	49 c1 f8 03          	sar    $0x3,%r8
    70df:	4d 0f af c4          	imul   %r12,%r8
    70e3:	4c 3b 05 0e 80 01 00 	cmp    0x1800e(%rip),%r8        # 1f0f8 <fwp_tape_next_slot>
    70ea:	7d 07                	jge    70f3 <fwp_tape_scope_release+0xf3>
    70ec:	4c 89 05 05 80 01 00 	mov    %r8,0x18005(%rip)        # 1f0f8 <fwp_tape_next_slot>
    70f3:	48 89 ef             	mov    %rbp,%rdi
    70f6:	4d 85 ed             	test   %r13,%r13
    70f9:	0f 85 41 ff ff ff    	jne    7040 <fwp_tape_scope_release+0x40>
    70ff:	e8 9c e1 ff ff       	call   52a0 <fwp_tape_buffers_release>
    7104:	48 63 03             	movslq (%rbx),%rax
    7107:	85 c0                	test   %eax,%eax
    7109:	0f 89 49 ff ff ff    	jns    7058 <fwp_tape_scope_release+0x58>
    710f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7114:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    711b:	00 00 
    711d:	75 0b                	jne    712a <fwp_tape_scope_release+0x12a>
    711f:	48 83 c4 48          	add    $0x48,%rsp
    7123:	5b                   	pop    %rbx
    7124:	5d                   	pop    %rbp
    7125:	41 5c                	pop    %r12
    7127:	41 5d                	pop    %r13
    7129:	c3                   	ret
    712a:	e8 21 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    712f:	90                   	nop

0000000000007130 <fwp_drop4>:
    7130:	48 8b 0d e1 1a 06 00 	mov    0x61ae1(%rip),%rcx        # 68c18 <fwp_heap+0x13d8>
    7137:	48 89 f8             	mov    %rdi,%rax
    713a:	48 2b 05 af 1a 06 00 	sub    0x61aaf(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    7141:	48 c1 e1 10          	shl    $0x10,%rcx
    7145:	48 39 c8             	cmp    %rcx,%rax
    7148:	0f 83 42 01 00 00    	jae    7290 <fwp_drop4+0x160>
    714e:	48 83 ec 18          	sub    $0x18,%rsp
    7152:	48 89 fa             	mov    %rdi,%rdx
    7155:	4c 8d 05 e4 06 06 00 	lea    0x606e4(%rip),%r8        # 67840 <fwp_heap>
    715c:	48 89 c1             	mov    %rax,%rcx
    715f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7166:	48 c1 e9 10          	shr    $0x10,%rcx
    716a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    716e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7172:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7176:	48 85 c9             	test   %rcx,%rcx
    7179:	74 40                	je     71bb <fwp_drop4+0x8b>
    717b:	0f b6 3e             	movzbl (%rsi),%edi
    717e:	40 80 ff 02          	cmp    $0x2,%dil
    7182:	74 3c                	je     71c0 <fwp_drop4+0x90>
    7184:	40 80 ff 01          	cmp    $0x1,%dil
    7188:	75 31                	jne    71bb <fwp_drop4+0x8b>
    718a:	8b 7e 18             	mov    0x18(%rsi),%edi
    718d:	0f b7 c0             	movzwl %ax,%eax
    7190:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7193:	48 0f af c7          	imul   %rdi,%rax
    7197:	48 c1 e8 20          	shr    $0x20,%rax
    719b:	48 39 f0             	cmp    %rsi,%rax
    719e:	73 1b                	jae    71bb <fwp_drop4+0x8b>
    71a0:	48 01 c1             	add    %rax,%rcx
    71a3:	0f b6 01             	movzbl (%rcx),%eax
    71a6:	84 c0                	test   %al,%al
    71a8:	74 11                	je     71bb <fwp_drop4+0x8b>
    71aa:	3c 01                	cmp    $0x1,%al
    71ac:	74 22                	je     71d0 <fwp_drop4+0xa0>
    71ae:	3c ff                	cmp    $0xff,%al
    71b0:	0f 84 0a 01 00 00    	je     72c0 <fwp_drop4+0x190>
    71b6:	83 e8 01             	sub    $0x1,%eax
    71b9:	88 01                	mov    %al,(%rcx)
    71bb:	48 83 c4 18          	add    $0x18,%rsp
    71bf:	c3                   	ret
    71c0:	66 85 c0             	test   %ax,%ax
    71c3:	74 de                	je     71a3 <fwp_drop4+0x73>
    71c5:	48 83 c4 18          	add    $0x18,%rsp
    71c9:	c3                   	ret
    71ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71d0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    71d4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    71db:	48 89 f8             	mov    %rdi,%rax
    71de:	48 c1 e1 10          	shl    $0x10,%rcx
    71e2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71e9:	48 39 c8             	cmp    %rcx,%rax
    71ec:	73 62                	jae    7250 <fwp_drop4+0x120>
    71ee:	48 89 c1             	mov    %rax,%rcx
    71f1:	48 c1 e9 10          	shr    $0x10,%rcx
    71f5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71f9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71fd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7201:	48 85 c9             	test   %rcx,%rcx
    7204:	74 4a                	je     7250 <fwp_drop4+0x120>
    7206:	44 0f b6 0e          	movzbl (%rsi),%r9d
    720a:	41 80 f9 02          	cmp    $0x2,%r9b
    720e:	0f 84 9c 00 00 00    	je     72b0 <fwp_drop4+0x180>
    7214:	41 80 f9 01          	cmp    $0x1,%r9b
    7218:	75 36                	jne    7250 <fwp_drop4+0x120>
    721a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    721e:	0f b7 c0             	movzwl %ax,%eax
    7221:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7224:	49 0f af c1          	imul   %r9,%rax
    7228:	48 c1 e8 20          	shr    $0x20,%rax
    722c:	48 39 f0             	cmp    %rsi,%rax
    722f:	73 1f                	jae    7250 <fwp_drop4+0x120>
    7231:	48 01 c1             	add    %rax,%rcx
    7234:	0f b6 01             	movzbl (%rcx),%eax
    7237:	84 c0                	test   %al,%al
    7239:	74 15                	je     7250 <fwp_drop4+0x120>
    723b:	3c 01                	cmp    $0x1,%al
    723d:	74 59                	je     7298 <fwp_drop4+0x168>
    723f:	3c ff                	cmp    $0xff,%al
    7241:	0f 84 ff 00 00 00    	je     7346 <fwp_drop4+0x216>
    7247:	83 e8 01             	sub    $0x1,%eax
    724a:	88 01                	mov    %al,(%rcx)
    724c:	0f 1f 40 00          	nopl   0x0(%rax)
    7250:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7254:	48 89 d7             	mov    %rdx,%rdi
    7257:	48 89 0c 24          	mov    %rcx,(%rsp)
    725b:	e8 f0 f6 ff ff       	call   6950 <fwp_rc_free_obj>
    7260:	4c 8d 05 d9 05 06 00 	lea    0x605d9(%rip),%r8        # 67840 <fwp_heap>
    7267:	48 8b 04 24          	mov    (%rsp),%rax
    726b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7272:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7279:	48 c1 e2 10          	shl    $0x10,%rdx
    727d:	48 39 d0             	cmp    %rdx,%rax
    7280:	0f 83 35 ff ff ff    	jae    71bb <fwp_drop4+0x8b>
    7286:	48 8b 14 24          	mov    (%rsp),%rdx
    728a:	e9 cd fe ff ff       	jmp    715c <fwp_drop4+0x2c>
    728f:	90                   	nop
    7290:	c3                   	ret
    7291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7298:	48 89 14 24          	mov    %rdx,(%rsp)
    729c:	e8 af f6 ff ff       	call   6950 <fwp_rc_free_obj>
    72a1:	48 8b 14 24          	mov    (%rsp),%rdx
    72a5:	eb a9                	jmp    7250 <fwp_drop4+0x120>
    72a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ae:	00 00 
    72b0:	66 85 c0             	test   %ax,%ax
    72b3:	75 9b                	jne    7250 <fwp_drop4+0x120>
    72b5:	e9 7a ff ff ff       	jmp    7234 <fwp_drop4+0x104>
    72ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72c0:	48 89 c8             	mov    %rcx,%rax
    72c3:	48 c1 e8 11          	shr    $0x11,%rax
    72c7:	48 31 c8             	xor    %rcx,%rax
    72ca:	48 89 c2             	mov    %rax,%rdx
    72cd:	48 c1 ea 09          	shr    $0x9,%rdx
    72d1:	48 31 d0             	xor    %rdx,%rax
    72d4:	0f b6 d0             	movzbl %al,%edx
    72d7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    72de:	00 
    72df:	48 85 c0             	test   %rax,%rax
    72e2:	75 29                	jne    730d <fwp_drop4+0x1dd>
    72e4:	e9 e3 00 00 00       	jmp    73cc <fwp_drop4+0x29c>
    72e9:	90                   	nop
    72ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72f1:	00 00 00 00 
    72f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72fc:	00 00 00 00 
    7300:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7304:	48 85 c0             	test   %rax,%rax
    7307:	0f 84 bf 00 00 00    	je     73cc <fwp_drop4+0x29c>
    730d:	48 89 c2             	mov    %rax,%rdx
    7310:	48 39 08             	cmp    %rcx,(%rax)
    7313:	75 eb                	jne    7300 <fwp_drop4+0x1d0>
    7315:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7319:	48 83 ea 01          	sub    $0x1,%rdx
    731d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7321:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7328:	0f 85 8d fe ff ff    	jne    71bb <fwp_drop4+0x8b>
    732e:	48 89 cf             	mov    %rcx,%rdi
    7331:	48 89 0c 24          	mov    %rcx,(%rsp)
    7335:	e8 d6 e4 ff ff       	call   5810 <fwp_rc_forget_slot>
    733a:	48 8b 0c 24          	mov    (%rsp),%rcx
    733e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7341:	e9 75 fe ff ff       	jmp    71bb <fwp_drop4+0x8b>
    7346:	48 89 ce             	mov    %rcx,%rsi
    7349:	48 c1 ee 11          	shr    $0x11,%rsi
    734d:	48 31 ce             	xor    %rcx,%rsi
    7350:	48 89 f0             	mov    %rsi,%rax
    7353:	48 c1 e8 09          	shr    $0x9,%rax
    7357:	48 31 c6             	xor    %rax,%rsi
    735a:	40 0f b6 f6          	movzbl %sil,%esi
    735e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7365:	00 
    7366:	48 85 c0             	test   %rax,%rax
    7369:	75 1e                	jne    7389 <fwp_drop4+0x259>
    736b:	eb 5f                	jmp    73cc <fwp_drop4+0x29c>
    736d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7374:	00 
    7375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    737c:	00 00 00 00 
    7380:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7384:	48 85 c0             	test   %rax,%rax
    7387:	74 43                	je     73cc <fwp_drop4+0x29c>
    7389:	48 89 c6             	mov    %rax,%rsi
    738c:	48 39 08             	cmp    %rcx,(%rax)
    738f:	75 ef                	jne    7380 <fwp_drop4+0x250>
    7391:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7395:	48 83 ee 01          	sub    $0x1,%rsi
    7399:	48 89 70 08          	mov    %rsi,0x8(%rax)
    739d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    73a4:	0f 85 a6 fe ff ff    	jne    7250 <fwp_drop4+0x120>
    73aa:	48 89 cf             	mov    %rcx,%rdi
    73ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    73b6:	e8 55 e4 ff ff       	call   5810 <fwp_rc_forget_slot>
    73bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    73bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    73c7:	e9 84 fe ff ff       	jmp    7250 <fwp_drop4+0x120>
    73cc:	48 8d 3d d5 45 00 00 	lea    0x45d5(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    73d3:	e8 58 d0 ff ff       	call   4430 <fwp_trap>
    73d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73df:	00 

00000000000073e0 <fwp_arg_drop37>:
    73e0:	f3 0f 1e fa          	endbr64
    73e4:	85 f6                	test   %esi,%esi
    73e6:	75 04                	jne    73ec <fwp_arg_drop37+0xc>
    73e8:	85 d2                	test   %edx,%edx
    73ea:	75 04                	jne    73f0 <fwp_arg_drop37+0x10>
    73ec:	c3                   	ret
    73ed:	0f 1f 00             	nopl   (%rax)
    73f0:	48 8b 3f             	mov    (%rdi),%rdi
    73f3:	e9 38 fd ff ff       	jmp    7130 <fwp_drop4>
    73f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73ff:	00 

0000000000007400 <fwp_task_dispose>:
    7400:	53                   	push   %rbx
    7401:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7405:	0f 84 1b c3 ff ff    	je     3726 <fwp_task_dispose.cold>
    740b:	48 89 fb             	mov    %rdi,%rbx
    740e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7413:	0f 85 0d c3 ff ff    	jne    3726 <fwp_task_dispose.cold>
    7419:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    741d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7424:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    742b:	00 
    742c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7430:	48 85 ff             	test   %rdi,%rdi
    7433:	74 07                	je     743c <fwp_task_dispose+0x3c>
    7435:	48 85 c0             	test   %rax,%rax
    7438:	74 02                	je     743c <fwp_task_dispose+0x3c>
    743a:	ff d0                	call   *%rax
    743c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7443:	e8 08 e6 ff ff       	call   5a50 <fwp_mem_free>
    7448:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    744f:	00 00 00 00 
    7453:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7457:	74 6f                	je     74c8 <fwp_task_dispose+0xc8>
    7459:	48 8b 15 b8 17 06 00 	mov    0x617b8(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    7460:	48 89 d8             	mov    %rbx,%rax
    7463:	48 2b 05 86 17 06 00 	sub    0x61786(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    746a:	48 c1 e2 10          	shl    $0x10,%rdx
    746e:	48 39 d0             	cmp    %rdx,%rax
    7471:	73 4c                	jae    74bf <fwp_task_dispose+0xbf>
    7473:	48 89 c2             	mov    %rax,%rdx
    7476:	48 c1 ea 10          	shr    $0x10,%rdx
    747a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    747e:	48 8b 15 b3 17 06 00 	mov    0x617b3(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    7485:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7489:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    748d:	48 85 c9             	test   %rcx,%rcx
    7490:	74 2d                	je     74bf <fwp_task_dispose+0xbf>
    7492:	0f b6 32             	movzbl (%rdx),%esi
    7495:	40 80 fe 02          	cmp    $0x2,%sil
    7499:	74 3d                	je     74d8 <fwp_task_dispose+0xd8>
    749b:	40 80 fe 01          	cmp    $0x1,%sil
    749f:	75 1e                	jne    74bf <fwp_task_dispose+0xbf>
    74a1:	8b 72 18             	mov    0x18(%rdx),%esi
    74a4:	0f b7 c0             	movzwl %ax,%eax
    74a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74aa:	48 0f af c6          	imul   %rsi,%rax
    74ae:	48 c1 e8 20          	shr    $0x20,%rax
    74b2:	48 39 d0             	cmp    %rdx,%rax
    74b5:	73 08                	jae    74bf <fwp_task_dispose+0xbf>
    74b7:	48 01 c1             	add    %rax,%rcx
    74ba:	80 39 01             	cmpb   $0x1,(%rcx)
    74bd:	74 09                	je     74c8 <fwp_task_dispose+0xc8>
    74bf:	5b                   	pop    %rbx
    74c0:	c3                   	ret
    74c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74c8:	48 89 df             	mov    %rbx,%rdi
    74cb:	5b                   	pop    %rbx
    74cc:	e9 7f e5 ff ff       	jmp    5a50 <fwp_mem_free>
    74d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74d8:	66 85 c0             	test   %ax,%ax
    74db:	74 dd                	je     74ba <fwp_task_dispose+0xba>
    74dd:	5b                   	pop    %rbx
    74de:	c3                   	ret
    74df:	90                   	nop

00000000000074e0 <fwp_free_zombie>:
    74e0:	48 8b 15 29 03 06 00 	mov    0x60329(%rip),%rdx        # 67810 <fwp_zombie>
    74e7:	48 85 d2             	test   %rdx,%rdx
    74ea:	0f 84 98 00 00 00    	je     7588 <fwp_free_zombie+0xa8>
    74f0:	48 3b 15 29 03 06 00 	cmp    0x60329(%rip),%rdx        # 67820 <fwp_cur>
    74f7:	0f 84 8b 00 00 00    	je     7588 <fwp_free_zombie+0xa8>
    74fd:	48 83 ec 18          	sub    $0x18,%rsp
    7501:	48 63 05 ec fc 05 00 	movslq 0x5fcec(%rip),%rax        # 671f4 <fwp_stack_pool_n>
    7508:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    750c:	83 f8 3f             	cmp    $0x3f,%eax
    750f:	7f 7f                	jg     7590 <fwp_free_zombie+0xb0>
    7511:	8d 48 01             	lea    0x1(%rax),%ecx
    7514:	89 0d da fc 05 00    	mov    %ecx,0x5fcda(%rip)        # 671f4 <fwp_stack_pool_n>
    751a:	48 8d 0d df fc 05 00 	lea    0x5fcdf(%rip),%rcx        # 67200 <fwp_stack_pool>
    7521:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7525:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    752c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7530:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7537:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    753b:	48 85 c9             	test   %rcx,%rcx
    753e:	0f 84 fc 00 00 00    	je     7640 <fwp_free_zombie+0x160>
    7544:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    754b:	48 85 c0             	test   %rax,%rax
    754e:	74 07                	je     7557 <fwp_free_zombie+0x77>
    7550:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7557:	8b 42 5c             	mov    0x5c(%rdx),%eax
    755a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    755e:	48 c7 05 a7 02 06 00 	movq   $0x0,0x602a7(%rip)        # 67810 <fwp_zombie>
    7565:	00 00 00 00 
    7569:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7570:	85 c0                	test   %eax,%eax
    7572:	74 34                	je     75a8 <fwp_free_zombie+0xc8>
    7574:	83 f8 01             	cmp    $0x1,%eax
    7577:	0f 84 b3 00 00 00    	je     7630 <fwp_free_zombie+0x150>
    757d:	48 83 c4 18          	add    $0x18,%rsp
    7581:	c3                   	ret
    7582:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7588:	c3                   	ret
    7589:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7590:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7594:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7599:	e8 22 c0 ff ff       	call   35c0 <munmap@plt>
    759e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75a3:	eb 80                	jmp    7525 <fwp_free_zombie+0x45>
    75a5:	0f 1f 00             	nopl   (%rax)
    75a8:	48 8b 0d 69 16 06 00 	mov    0x61669(%rip),%rcx        # 68c18 <fwp_heap+0x13d8>
    75af:	48 89 d0             	mov    %rdx,%rax
    75b2:	48 2b 05 37 16 06 00 	sub    0x61637(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    75b9:	48 c1 e1 10          	shl    $0x10,%rcx
    75bd:	48 39 c8             	cmp    %rcx,%rax
    75c0:	73 bb                	jae    757d <fwp_free_zombie+0x9d>
    75c2:	48 89 c1             	mov    %rax,%rcx
    75c5:	48 c1 e9 10          	shr    $0x10,%rcx
    75c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75cd:	48 8b 0d 64 16 06 00 	mov    0x61664(%rip),%rcx        # 68c38 <fwp_heap+0x13f8>
    75d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    75d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    75dc:	48 85 c9             	test   %rcx,%rcx
    75df:	74 9c                	je     757d <fwp_free_zombie+0x9d>
    75e1:	0f b6 3e             	movzbl (%rsi),%edi
    75e4:	40 80 ff 02          	cmp    $0x2,%dil
    75e8:	74 66                	je     7650 <fwp_free_zombie+0x170>
    75ea:	40 80 ff 01          	cmp    $0x1,%dil
    75ee:	75 8d                	jne    757d <fwp_free_zombie+0x9d>
    75f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    75f3:	0f b7 c0             	movzwl %ax,%eax
    75f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    75f9:	48 0f af c7          	imul   %rdi,%rax
    75fd:	48 c1 e8 20          	shr    $0x20,%rax
    7601:	48 39 f0             	cmp    %rsi,%rax
    7604:	0f 83 73 ff ff ff    	jae    757d <fwp_free_zombie+0x9d>
    760a:	48 01 c1             	add    %rax,%rcx
    760d:	0f b6 01             	movzbl (%rcx),%eax
    7610:	84 c0                	test   %al,%al
    7612:	0f 84 65 ff ff ff    	je     757d <fwp_free_zombie+0x9d>
    7618:	3c 01                	cmp    $0x1,%al
    761a:	74 14                	je     7630 <fwp_free_zombie+0x150>
    761c:	3c ff                	cmp    $0xff,%al
    761e:	74 3b                	je     765b <fwp_free_zombie+0x17b>
    7620:	83 e8 01             	sub    $0x1,%eax
    7623:	88 01                	mov    %al,(%rcx)
    7625:	e9 53 ff ff ff       	jmp    757d <fwp_free_zombie+0x9d>
    762a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7630:	48 89 d7             	mov    %rdx,%rdi
    7633:	48 83 c4 18          	add    $0x18,%rsp
    7637:	e9 c4 fd ff ff       	jmp    7400 <fwp_task_dispose>
    763c:	0f 1f 40 00          	nopl   0x0(%rax)
    7640:	48 89 05 a1 01 06 00 	mov    %rax,0x601a1(%rip)        # 677e8 <fwp_tasks_active>
    7647:	e9 ff fe ff ff       	jmp    754b <fwp_free_zombie+0x6b>
    764c:	0f 1f 40 00          	nopl   0x0(%rax)
    7650:	66 85 c0             	test   %ax,%ax
    7653:	0f 85 24 ff ff ff    	jne    757d <fwp_free_zombie+0x9d>
    7659:	eb b2                	jmp    760d <fwp_free_zombie+0x12d>
    765b:	48 89 ca             	mov    %rcx,%rdx
    765e:	48 8d 35 db 01 06 00 	lea    0x601db(%rip),%rsi        # 67840 <fwp_heap>
    7665:	48 c1 ea 11          	shr    $0x11,%rdx
    7669:	48 31 ca             	xor    %rcx,%rdx
    766c:	48 89 d0             	mov    %rdx,%rax
    766f:	48 c1 e8 09          	shr    $0x9,%rax
    7673:	48 31 c2             	xor    %rax,%rdx
    7676:	0f b6 d2             	movzbl %dl,%edx
    7679:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7680:	00 
    7681:	48 85 c0             	test   %rax,%rax
    7684:	75 23                	jne    76a9 <fwp_free_zombie+0x1c9>
    7686:	eb 5c                	jmp    76e4 <fwp_free_zombie+0x204>
    7688:	66 90                	xchg   %ax,%ax
    768a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7691:	00 00 00 00 
    7695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    769c:	00 00 00 00 
    76a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76a4:	48 85 c0             	test   %rax,%rax
    76a7:	74 3b                	je     76e4 <fwp_free_zombie+0x204>
    76a9:	48 89 c2             	mov    %rax,%rdx
    76ac:	48 39 08             	cmp    %rcx,(%rax)
    76af:	75 ef                	jne    76a0 <fwp_free_zombie+0x1c0>
    76b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76c4:	0f 85 b3 fe ff ff    	jne    757d <fwp_free_zombie+0x9d>
    76ca:	48 89 cf             	mov    %rcx,%rdi
    76cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76d2:	e8 39 e1 ff ff       	call   5810 <fwp_rc_forget_slot>
    76d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    76dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    76df:	e9 99 fe ff ff       	jmp    757d <fwp_free_zombie+0x9d>
    76e4:	48 8d 3d bd 42 00 00 	lea    0x42bd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    76eb:	e8 40 cd ff ff       	call   4430 <fwp_trap>

00000000000076f0 <fwp_block>:
    76f0:	48 83 ec 08          	sub    $0x8,%rsp
    76f4:	48 8b 05 0d 01 06 00 	mov    0x6010d(%rip),%rax        # 67808 <fwp_ready_head>
    76fb:	48 85 c0             	test   %rax,%rax
    76fe:	0f 84 1c 01 00 00    	je     7820 <fwp_block+0x130>
    7704:	90                   	nop
    7705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    770c:	00 00 00 00 
    7710:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7717:	48 89 15 ea 00 06 00 	mov    %rdx,0x600ea(%rip)        # 67808 <fwp_ready_head>
    771e:	48 85 d2             	test   %rdx,%rdx
    7721:	0f 84 19 01 00 00    	je     7840 <fwp_block+0x150>
    7727:	48 8b 15 f2 00 06 00 	mov    0x600f2(%rip),%rdx        # 67820 <fwp_cur>
    772e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7732:	48 39 c2             	cmp    %rax,%rdx
    7735:	0f 84 d5 00 00 00    	je     7810 <fwp_block+0x120>
    773b:	48 8b 0d 66 1d 06 00 	mov    0x61d66(%rip),%rcx        # 694a8 <fwp_state_owners>
    7742:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7746:	48 89 05 d3 00 06 00 	mov    %rax,0x600d3(%rip)        # 67820 <fwp_cur>
    774d:	f3 0f 7e 05 7b 1d 06 	movq   0x61d7b(%rip),%xmm0        # 694d0 <fwp_foreign_callbacks>
    7754:	00 
    7755:	0f 16 05 64 1d 06 00 	movhps 0x61d64(%rip),%xmm0        # 694c0 <fwp_state>
    775c:	f3 0f 7e 0d 64 1d 06 	movq   0x61d64(%rip),%xmm1        # 694c8 <fwp_handlers>
    7763:	00 
    7764:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    776b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7772:	0f 16 0d 5f 1d 06 00 	movhps 0x61d5f(%rip),%xmm1        # 694d8 <fwp_cleanups>
    7779:	f3 0f 7e 05 37 1d 06 	movq   0x61d37(%rip),%xmm0        # 694b8 <fwp_state_len>
    7780:	00 
    7781:	0f 16 05 28 1d 06 00 	movhps 0x61d28(%rip),%xmm0        # 694b0 <fwp_state_cap>
    7788:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    778f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7796:	48 8b 70 08          	mov    0x8(%rax),%rsi
    779a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    77a1:	48 89 0d 20 1d 06 00 	mov    %rcx,0x61d20(%rip)        # 694c8 <fwp_handlers>
    77a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    77af:	48 89 0d 22 1d 06 00 	mov    %rcx,0x61d22(%rip)        # 694d8 <fwp_cleanups>
    77b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    77bd:	48 89 0d 0c 1d 06 00 	mov    %rcx,0x61d0c(%rip)        # 694d0 <fwp_foreign_callbacks>
    77c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    77cb:	48 89 0d ee 1c 06 00 	mov    %rcx,0x61cee(%rip)        # 694c0 <fwp_state>
    77d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    77d9:	48 89 0d d8 1c 06 00 	mov    %rcx,0x61cd8(%rip)        # 694b8 <fwp_state_len>
    77e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    77e7:	48 89 0d c2 1c 06 00 	mov    %rcx,0x61cc2(%rip)        # 694b0 <fwp_state_cap>
    77ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    77f5:	48 89 0d ac 1c 06 00 	mov    %rcx,0x61cac(%rip)        # 694a8 <fwp_state_owners>
    77fc:	e8 7f bc ff ff       	call   3480 <swapcontext@plt>
    7801:	f3 0f 1e fa          	endbr64
    7805:	e8 d6 fc ff ff       	call   74e0 <fwp_free_zombie>
    780a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7810:	8b 05 da f9 05 00    	mov    0x5f9da(%rip),%eax        # 671f0 <fwp_slice>
    7816:	85 c0                	test   %eax,%eax
    7818:	74 36                	je     7850 <fwp_block+0x160>
    781a:	48 83 c4 08          	add    $0x8,%rsp
    781e:	c3                   	ret
    781f:	90                   	nop
    7820:	e8 2b dc ff ff       	call   5450 <fwp_poll_events>
    7825:	48 8b 05 dc ff 05 00 	mov    0x5ffdc(%rip),%rax        # 67808 <fwp_ready_head>
    782c:	48 85 c0             	test   %rax,%rax
    782f:	0f 85 db fe ff ff    	jne    7710 <fwp_block+0x20>
    7835:	eb e9                	jmp    7820 <fwp_block+0x130>
    7837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    783e:	00 00 
    7840:	48 c7 05 b5 ff 05 00 	movq   $0x0,0x5ffb5(%rip)        # 67800 <fwp_ready_tail>
    7847:	00 00 00 00 
    784b:	e9 d7 fe ff ff       	jmp    7727 <fwp_block+0x37>
    7850:	48 8d 3d 88 39 00 00 	lea    0x3988(%rip),%rdi        # b1df <_IO_stdin_used+0x1df>
    7857:	e8 34 bb ff ff       	call   3390 <getenv@plt>
    785c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7861:	48 85 c0             	test   %rax,%rax
    7864:	74 05                	je     786b <fwp_block+0x17b>
    7866:	80 38 00             	cmpb   $0x0,(%rax)
    7869:	75 0b                	jne    7876 <fwp_block+0x186>
    786b:	89 15 7f f9 05 00    	mov    %edx,0x5f97f(%rip)        # 671f0 <fwp_slice>
    7871:	48 83 c4 08          	add    $0x8,%rsp
    7875:	c3                   	ret
    7876:	ba 0a 00 00 00       	mov    $0xa,%edx
    787b:	31 f6                	xor    %esi,%esi
    787d:	48 89 c7             	mov    %rax,%rdi
    7880:	e8 bb bc ff ff       	call   3540 <strtoll@plt>
    7885:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7889:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7890:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7895:	0f 46 d0             	cmovbe %eax,%edx
    7898:	eb d1                	jmp    786b <fwp_block+0x17b>
    789a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000078a0 <fwp_caps173>:
    78a0:	f3 0f 1e fa          	endbr64
    78a4:	85 f6                	test   %esi,%esi
    78a6:	74 08                	je     78b0 <fwp_caps173+0x10>
    78a8:	c3                   	ret
    78a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78b0:	48 8b 15 61 13 06 00 	mov    0x61361(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    78b7:	48 89 f8             	mov    %rdi,%rax
    78ba:	48 2b 05 2f 13 06 00 	sub    0x6132f(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    78c1:	48 c1 e2 10          	shl    $0x10,%rdx
    78c5:	48 39 d0             	cmp    %rdx,%rax
    78c8:	73 de                	jae    78a8 <fwp_caps173+0x8>
    78ca:	48 89 c2             	mov    %rax,%rdx
    78cd:	48 c1 ea 10          	shr    $0x10,%rdx
    78d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78d5:	48 8b 15 5c 13 06 00 	mov    0x6135c(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    78dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78e4:	48 85 c9             	test   %rcx,%rcx
    78e7:	74 bf                	je     78a8 <fwp_caps173+0x8>
    78e9:	0f b6 32             	movzbl (%rdx),%esi
    78ec:	40 80 fe 02          	cmp    $0x2,%sil
    78f0:	74 2e                	je     7920 <fwp_caps173+0x80>
    78f2:	40 80 fe 01          	cmp    $0x1,%sil
    78f6:	75 b0                	jne    78a8 <fwp_caps173+0x8>
    78f8:	8b 72 18             	mov    0x18(%rdx),%esi
    78fb:	0f b7 c0             	movzwl %ax,%eax
    78fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7901:	48 0f af c6          	imul   %rsi,%rax
    7905:	48 c1 e8 20          	shr    $0x20,%rax
    7909:	48 39 d0             	cmp    %rdx,%rax
    790c:	73 9a                	jae    78a8 <fwp_caps173+0x8>
    790e:	48 01 c1             	add    %rax,%rcx
    7911:	80 39 01             	cmpb   $0x1,(%rcx)
    7914:	75 92                	jne    78a8 <fwp_caps173+0x8>
    7916:	e9 35 e1 ff ff       	jmp    5a50 <fwp_mem_free>
    791b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7920:	66 85 c0             	test   %ax,%ax
    7923:	74 ec                	je     7911 <fwp_caps173+0x71>
    7925:	c3                   	ret
    7926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    792d:	00 00 00 

0000000000007930 <fwp_args37>:
    7930:	f3 0f 1e fa          	endbr64
    7934:	85 d2                	test   %edx,%edx
    7936:	74 04                	je     793c <fwp_args37+0xc>
    7938:	85 f6                	test   %esi,%esi
    793a:	74 04                	je     7940 <fwp_args37+0x10>
    793c:	c3                   	ret
    793d:	0f 1f 00             	nopl   (%rax)
    7940:	48 8b 15 d1 12 06 00 	mov    0x612d1(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    7947:	48 8b 07             	mov    (%rdi),%rax
    794a:	48 2b 05 9f 12 06 00 	sub    0x6129f(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    7951:	48 c1 e2 10          	shl    $0x10,%rdx
    7955:	48 39 d0             	cmp    %rdx,%rax
    7958:	73 e2                	jae    793c <fwp_args37+0xc>
    795a:	48 89 c2             	mov    %rax,%rdx
    795d:	48 c1 ea 10          	shr    $0x10,%rdx
    7961:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7965:	48 8b 15 cc 12 06 00 	mov    0x612cc(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    796c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7970:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7974:	48 85 ff             	test   %rdi,%rdi
    7977:	74 c3                	je     793c <fwp_args37+0xc>
    7979:	0f b6 0a             	movzbl (%rdx),%ecx
    797c:	80 f9 02             	cmp    $0x2,%cl
    797f:	74 4f                	je     79d0 <fwp_args37+0xa0>
    7981:	80 f9 01             	cmp    $0x1,%cl
    7984:	75 b6                	jne    793c <fwp_args37+0xc>
    7986:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7989:	0f b7 c0             	movzwl %ax,%eax
    798c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    798f:	48 0f af c1          	imul   %rcx,%rax
    7993:	48 c1 e8 20          	shr    $0x20,%rax
    7997:	48 39 d0             	cmp    %rdx,%rax
    799a:	73 a0                	jae    793c <fwp_args37+0xc>
    799c:	48 01 c7             	add    %rax,%rdi
    799f:	0f b6 07             	movzbl (%rdi),%eax
    79a2:	84 c0                	test   %al,%al
    79a4:	74 96                	je     793c <fwp_args37+0xc>
    79a6:	8b 15 5c 1b 06 00    	mov    0x61b5c(%rip),%edx        # 69508 <iteration_active>
    79ac:	85 d2                	test   %edx,%edx
    79ae:	75 10                	jne    79c0 <fwp_args37+0x90>
    79b0:	3c fd                	cmp    $0xfd,%al
    79b2:	77 22                	ja     79d6 <fwp_args37+0xa6>
    79b4:	83 c0 01             	add    $0x1,%eax
    79b7:	88 07                	mov    %al,(%rdi)
    79b9:	c3                   	ret
    79ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79c0:	48 83 05 28 1b 06 00 	addq   $0x1,0x61b28(%rip)        # 694f0 <iteration_retains>
    79c7:	01 
    79c8:	eb e6                	jmp    79b0 <fwp_args37+0x80>
    79ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	74 ca                	je     799f <fwp_args37+0x6f>
    79d5:	c3                   	ret
    79d6:	e9 15 dd ff ff       	jmp    56f0 <fwp_rc_wide_dup>
    79db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000079e0 <fwp_caps37>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	48 83 ec 18          	sub    $0x18,%rsp
    79e8:	48 89 f8             	mov    %rdi,%rax
    79eb:	8b 7f 04             	mov    0x4(%rdi),%edi
    79ee:	85 ff                	test   %edi,%edi
    79f0:	0f 84 9a 00 00 00    	je     7a90 <fwp_caps37+0xb0>
    79f6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    79fa:	85 f6                	test   %esi,%esi
    79fc:	0f 85 9e 00 00 00    	jne    7aa0 <fwp_caps37+0xc0>
    7a02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a07:	e8 24 f7 ff ff       	call   7130 <fwp_drop4>
    7a0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a11:	48 8b 0d 00 12 06 00 	mov    0x61200(%rip),%rcx        # 68c18 <fwp_heap+0x13d8>
    7a18:	48 89 c2             	mov    %rax,%rdx
    7a1b:	48 2b 15 ce 11 06 00 	sub    0x611ce(%rip),%rdx        # 68bf0 <fwp_heap+0x13b0>
    7a22:	48 c1 e1 10          	shl    $0x10,%rcx
    7a26:	48 39 ca             	cmp    %rcx,%rdx
    7a29:	73 6d                	jae    7a98 <fwp_caps37+0xb8>
    7a2b:	48 89 d1             	mov    %rdx,%rcx
    7a2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a36:	48 8b 0d fb 11 06 00 	mov    0x611fb(%rip),%rcx        # 68c38 <fwp_heap+0x13f8>
    7a3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a45:	48 85 f6             	test   %rsi,%rsi
    7a48:	74 4e                	je     7a98 <fwp_caps37+0xb8>
    7a4a:	0f b6 39             	movzbl (%rcx),%edi
    7a4d:	40 80 ff 02          	cmp    $0x2,%dil
    7a51:	0f 84 c9 00 00 00    	je     7b20 <fwp_caps37+0x140>
    7a57:	40 80 ff 01          	cmp    $0x1,%dil
    7a5b:	75 3b                	jne    7a98 <fwp_caps37+0xb8>
    7a5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a60:	0f b7 d2             	movzwl %dx,%edx
    7a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a66:	48 0f af d7          	imul   %rdi,%rdx
    7a6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a6e:	48 39 ca             	cmp    %rcx,%rdx
    7a71:	73 25                	jae    7a98 <fwp_caps37+0xb8>
    7a73:	48 01 d6             	add    %rdx,%rsi
    7a76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a79:	75 1d                	jne    7a98 <fwp_caps37+0xb8>
    7a7b:	48 89 c7             	mov    %rax,%rdi
    7a7e:	48 83 c4 18          	add    $0x18,%rsp
    7a82:	e9 c9 df ff ff       	jmp    5a50 <fwp_mem_free>
    7a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a8e:	00 00 
    7a90:	85 f6                	test   %esi,%esi
    7a92:	0f 84 79 ff ff ff    	je     7a11 <fwp_caps37+0x31>
    7a98:	48 83 c4 18          	add    $0x18,%rsp
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 05 71 11 06 00 	mov    0x61171(%rip),%rax        # 68c18 <fwp_heap+0x13d8>
    7aa7:	48 2b 3d 42 11 06 00 	sub    0x61142(%rip),%rdi        # 68bf0 <fwp_heap+0x13b0>
    7aae:	48 c1 e0 10          	shl    $0x10,%rax
    7ab2:	48 39 c7             	cmp    %rax,%rdi
    7ab5:	73 e1                	jae    7a98 <fwp_caps37+0xb8>
    7ab7:	48 89 f8             	mov    %rdi,%rax
    7aba:	48 c1 e8 10          	shr    $0x10,%rax
    7abe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ac2:	48 8b 05 6f 11 06 00 	mov    0x6116f(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    7ac9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7acd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ad1:	48 85 c0             	test   %rax,%rax
    7ad4:	74 c2                	je     7a98 <fwp_caps37+0xb8>
    7ad6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ad9:	80 f9 02             	cmp    $0x2,%cl
    7adc:	74 52                	je     7b30 <fwp_caps37+0x150>
    7ade:	80 f9 01             	cmp    $0x1,%cl
    7ae1:	75 b5                	jne    7a98 <fwp_caps37+0xb8>
    7ae3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae6:	0f b7 ff             	movzwl %di,%edi
    7ae9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aec:	48 0f af f9          	imul   %rcx,%rdi
    7af0:	48 c1 ef 20          	shr    $0x20,%rdi
    7af4:	48 39 d7             	cmp    %rdx,%rdi
    7af7:	73 9f                	jae    7a98 <fwp_caps37+0xb8>
    7af9:	48 01 f8             	add    %rdi,%rax
    7afc:	0f b6 10             	movzbl (%rax),%edx
    7aff:	84 d2                	test   %dl,%dl
    7b01:	74 95                	je     7a98 <fwp_caps37+0xb8>
    7b03:	8b 0d ff 19 06 00    	mov    0x619ff(%rip),%ecx        # 69508 <iteration_active>
    7b09:	85 c9                	test   %ecx,%ecx
    7b0b:	75 33                	jne    7b40 <fwp_caps37+0x160>
    7b0d:	80 fa fd             	cmp    $0xfd,%dl
    7b10:	77 38                	ja     7b4a <fwp_caps37+0x16a>
    7b12:	83 c2 01             	add    $0x1,%edx
    7b15:	88 10                	mov    %dl,(%rax)
    7b17:	e9 7c ff ff ff       	jmp    7a98 <fwp_caps37+0xb8>
    7b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b20:	66 85 d2             	test   %dx,%dx
    7b23:	0f 85 6f ff ff ff    	jne    7a98 <fwp_caps37+0xb8>
    7b29:	e9 48 ff ff ff       	jmp    7a76 <fwp_caps37+0x96>
    7b2e:	66 90                	xchg   %ax,%ax
    7b30:	66 85 ff             	test   %di,%di
    7b33:	0f 85 5f ff ff ff    	jne    7a98 <fwp_caps37+0xb8>
    7b39:	eb c1                	jmp    7afc <fwp_caps37+0x11c>
    7b3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b40:	48 83 05 a8 19 06 00 	addq   $0x1,0x619a8(%rip)        # 694f0 <iteration_retains>
    7b47:	01 
    7b48:	eb c3                	jmp    7b0d <fwp_caps37+0x12d>
    7b4a:	48 89 c7             	mov    %rax,%rdi
    7b4d:	48 83 c4 18          	add    $0x18,%rsp
    7b51:	e9 9a db ff ff       	jmp    56f0 <fwp_rc_wide_dup>
    7b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b5d:	00 00 00 

0000000000007b60 <fwp_drop0>:
    7b60:	f3 0f 1e fa          	endbr64
    7b64:	48 8b 15 ad 10 06 00 	mov    0x610ad(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    7b6b:	48 89 f8             	mov    %rdi,%rax
    7b6e:	48 2b 05 7b 10 06 00 	sub    0x6107b(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    7b75:	48 c1 e2 10          	shl    $0x10,%rdx
    7b79:	48 39 d0             	cmp    %rdx,%rax
    7b7c:	0f 83 36 01 00 00    	jae    7cb8 <fwp_drop0+0x158>
    7b82:	48 83 ec 18          	sub    $0x18,%rsp
    7b86:	48 8d 35 b3 fc 05 00 	lea    0x5fcb3(%rip),%rsi        # 67840 <fwp_heap>
    7b8d:	48 89 c2             	mov    %rax,%rdx
    7b90:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b97:	48 c1 ea 10          	shr    $0x10,%rdx
    7b9b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b9f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ba3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ba7:	48 85 d2             	test   %rdx,%rdx
    7baa:	74 42                	je     7bee <fwp_drop0+0x8e>
    7bac:	44 0f b6 01          	movzbl (%rcx),%r8d
    7bb0:	41 80 f8 02          	cmp    $0x2,%r8b
    7bb4:	74 42                	je     7bf8 <fwp_drop0+0x98>
    7bb6:	41 80 f8 01          	cmp    $0x1,%r8b
    7bba:	75 32                	jne    7bee <fwp_drop0+0x8e>
    7bbc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7bc0:	0f b7 c0             	movzwl %ax,%eax
    7bc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7bc6:	49 0f af c0          	imul   %r8,%rax
    7bca:	48 c1 e8 20          	shr    $0x20,%rax
    7bce:	48 39 c8             	cmp    %rcx,%rax
    7bd1:	73 1b                	jae    7bee <fwp_drop0+0x8e>
    7bd3:	48 01 c2             	add    %rax,%rdx
    7bd6:	0f b6 02             	movzbl (%rdx),%eax
    7bd9:	84 c0                	test   %al,%al
    7bdb:	74 11                	je     7bee <fwp_drop0+0x8e>
    7bdd:	3c 01                	cmp    $0x1,%al
    7bdf:	74 27                	je     7c08 <fwp_drop0+0xa8>
    7be1:	3c ff                	cmp    $0xff,%al
    7be3:	0f 84 e7 00 00 00    	je     7cd0 <fwp_drop0+0x170>
    7be9:	83 e8 01             	sub    $0x1,%eax
    7bec:	88 02                	mov    %al,(%rdx)
    7bee:	48 83 c4 18          	add    $0x18,%rsp
    7bf2:	c3                   	ret
    7bf3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7bf8:	66 85 c0             	test   %ax,%ax
    7bfb:	74 d9                	je     7bd6 <fwp_drop0+0x76>
    7bfd:	48 83 c4 18          	add    $0x18,%rsp
    7c01:	c3                   	ret
    7c02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c08:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c0f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c16:	48 89 f8             	mov    %rdi,%rax
    7c19:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7c1d:	48 29 c8             	sub    %rcx,%rax
    7c20:	48 c1 e2 10          	shl    $0x10,%rdx
    7c24:	48 39 d0             	cmp    %rdx,%rax
    7c27:	73 71                	jae    7c9a <fwp_drop0+0x13a>
    7c29:	49 89 c2             	mov    %rax,%r10
    7c2c:	49 c1 ea 10          	shr    $0x10,%r10
    7c30:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c34:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7c38:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7c3c:	4d 85 d2             	test   %r10,%r10
    7c3f:	74 59                	je     7c9a <fwp_drop0+0x13a>
    7c41:	45 0f b6 19          	movzbl (%r9),%r11d
    7c45:	41 80 fb 02          	cmp    $0x2,%r11b
    7c49:	74 75                	je     7cc0 <fwp_drop0+0x160>
    7c4b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c4f:	75 49                	jne    7c9a <fwp_drop0+0x13a>
    7c51:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c55:	0f b7 c0             	movzwl %ax,%eax
    7c58:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c5c:	49 0f af c3          	imul   %r11,%rax
    7c60:	48 c1 e8 20          	shr    $0x20,%rax
    7c64:	4c 39 c8             	cmp    %r9,%rax
    7c67:	73 31                	jae    7c9a <fwp_drop0+0x13a>
    7c69:	49 01 c2             	add    %rax,%r10
    7c6c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c70:	75 28                	jne    7c9a <fwp_drop0+0x13a>
    7c72:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7c77:	e8 d4 dd ff ff       	call   5a50 <fwp_mem_free>
    7c7c:	48 8d 35 bd fb 05 00 	lea    0x5fbbd(%rip),%rsi        # 67840 <fwp_heap>
    7c83:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7c88:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c8f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c96:	48 c1 e2 10          	shl    $0x10,%rdx
    7c9a:	4c 89 c0             	mov    %r8,%rax
    7c9d:	48 29 c8             	sub    %rcx,%rax
    7ca0:	48 39 d0             	cmp    %rdx,%rax
    7ca3:	0f 83 45 ff ff ff    	jae    7bee <fwp_drop0+0x8e>
    7ca9:	4c 89 c7             	mov    %r8,%rdi
    7cac:	e9 dc fe ff ff       	jmp    7b8d <fwp_drop0+0x2d>
    7cb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cb8:	c3                   	ret
    7cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cc0:	66 85 c0             	test   %ax,%ax
    7cc3:	75 d5                	jne    7c9a <fwp_drop0+0x13a>
    7cc5:	eb a5                	jmp    7c6c <fwp_drop0+0x10c>
    7cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cce:	00 00 
    7cd0:	48 89 d0             	mov    %rdx,%rax
    7cd3:	48 c1 e8 11          	shr    $0x11,%rax
    7cd7:	48 31 d0             	xor    %rdx,%rax
    7cda:	48 89 c1             	mov    %rax,%rcx
    7cdd:	48 c1 e9 09          	shr    $0x9,%rcx
    7ce1:	48 31 c8             	xor    %rcx,%rax
    7ce4:	0f b6 c8             	movzbl %al,%ecx
    7ce7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7cee:	00 
    7cef:	48 85 c0             	test   %rax,%rax
    7cf2:	75 15                	jne    7d09 <fwp_drop0+0x1a9>
    7cf4:	eb 4e                	jmp    7d44 <fwp_drop0+0x1e4>
    7cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cfd:	00 00 00 
    7d00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7d04:	48 85 c0             	test   %rax,%rax
    7d07:	74 3b                	je     7d44 <fwp_drop0+0x1e4>
    7d09:	48 89 c1             	mov    %rax,%rcx
    7d0c:	48 39 10             	cmp    %rdx,(%rax)
    7d0f:	75 ef                	jne    7d00 <fwp_drop0+0x1a0>
    7d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7d19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7d1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d24:	0f 85 c4 fe ff ff    	jne    7bee <fwp_drop0+0x8e>
    7d2a:	48 89 d7             	mov    %rdx,%rdi
    7d2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d32:	e8 d9 da ff ff       	call   5810 <fwp_rc_forget_slot>
    7d37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d3f:	e9 aa fe ff ff       	jmp    7bee <fwp_drop0+0x8e>
    7d44:	48 8d 3d 5d 3c 00 00 	lea    0x3c5d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7d4b:	e8 e0 c6 ff ff       	call   4430 <fwp_trap>

0000000000007d50 <fwp_drop1>:
    7d50:	f3 0f 1e fa          	endbr64
    7d54:	48 8b 15 bd 0e 06 00 	mov    0x60ebd(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    7d5b:	48 89 f8             	mov    %rdi,%rax
    7d5e:	48 2b 05 8b 0e 06 00 	sub    0x60e8b(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    7d65:	48 c1 e2 10          	shl    $0x10,%rdx
    7d69:	48 39 d0             	cmp    %rdx,%rax
    7d6c:	0f 83 36 01 00 00    	jae    7ea8 <fwp_drop1+0x158>
    7d72:	48 83 ec 18          	sub    $0x18,%rsp
    7d76:	48 8d 35 c3 fa 05 00 	lea    0x5fac3(%rip),%rsi        # 67840 <fwp_heap>
    7d7d:	48 89 c2             	mov    %rax,%rdx
    7d80:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d87:	48 c1 ea 10          	shr    $0x10,%rdx
    7d8b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d8f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d97:	48 85 d2             	test   %rdx,%rdx
    7d9a:	74 42                	je     7dde <fwp_drop1+0x8e>
    7d9c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7da0:	41 80 f8 02          	cmp    $0x2,%r8b
    7da4:	74 42                	je     7de8 <fwp_drop1+0x98>
    7da6:	41 80 f8 01          	cmp    $0x1,%r8b
    7daa:	75 32                	jne    7dde <fwp_drop1+0x8e>
    7dac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7db0:	0f b7 c0             	movzwl %ax,%eax
    7db3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7db6:	49 0f af c0          	imul   %r8,%rax
    7dba:	48 c1 e8 20          	shr    $0x20,%rax
    7dbe:	48 39 c8             	cmp    %rcx,%rax
    7dc1:	73 1b                	jae    7dde <fwp_drop1+0x8e>
    7dc3:	48 01 c2             	add    %rax,%rdx
    7dc6:	0f b6 02             	movzbl (%rdx),%eax
    7dc9:	84 c0                	test   %al,%al
    7dcb:	74 11                	je     7dde <fwp_drop1+0x8e>
    7dcd:	3c 01                	cmp    $0x1,%al
    7dcf:	74 27                	je     7df8 <fwp_drop1+0xa8>
    7dd1:	3c ff                	cmp    $0xff,%al
    7dd3:	0f 84 e7 00 00 00    	je     7ec0 <fwp_drop1+0x170>
    7dd9:	83 e8 01             	sub    $0x1,%eax
    7ddc:	88 02                	mov    %al,(%rdx)
    7dde:	48 83 c4 18          	add    $0x18,%rsp
    7de2:	c3                   	ret
    7de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7de8:	66 85 c0             	test   %ax,%ax
    7deb:	74 d9                	je     7dc6 <fwp_drop1+0x76>
    7ded:	48 83 c4 18          	add    $0x18,%rsp
    7df1:	c3                   	ret
    7df2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7df8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7dff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e06:	48 89 f8             	mov    %rdi,%rax
    7e09:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7e0d:	48 29 c8             	sub    %rcx,%rax
    7e10:	48 c1 e2 10          	shl    $0x10,%rdx
    7e14:	48 39 d0             	cmp    %rdx,%rax
    7e17:	73 71                	jae    7e8a <fwp_drop1+0x13a>
    7e19:	49 89 c2             	mov    %rax,%r10
    7e1c:	49 c1 ea 10          	shr    $0x10,%r10
    7e20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e24:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7e28:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7e2c:	4d 85 d2             	test   %r10,%r10
    7e2f:	74 59                	je     7e8a <fwp_drop1+0x13a>
    7e31:	45 0f b6 19          	movzbl (%r9),%r11d
    7e35:	41 80 fb 02          	cmp    $0x2,%r11b
    7e39:	74 75                	je     7eb0 <fwp_drop1+0x160>
    7e3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e3f:	75 49                	jne    7e8a <fwp_drop1+0x13a>
    7e41:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e45:	0f b7 c0             	movzwl %ax,%eax
    7e48:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e4c:	49 0f af c3          	imul   %r11,%rax
    7e50:	48 c1 e8 20          	shr    $0x20,%rax
    7e54:	4c 39 c8             	cmp    %r9,%rax
    7e57:	73 31                	jae    7e8a <fwp_drop1+0x13a>
    7e59:	49 01 c2             	add    %rax,%r10
    7e5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e60:	75 28                	jne    7e8a <fwp_drop1+0x13a>
    7e62:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e67:	e8 e4 db ff ff       	call   5a50 <fwp_mem_free>
    7e6c:	48 8d 35 cd f9 05 00 	lea    0x5f9cd(%rip),%rsi        # 67840 <fwp_heap>
    7e73:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e78:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e7f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e86:	48 c1 e2 10          	shl    $0x10,%rdx
    7e8a:	4c 89 c0             	mov    %r8,%rax
    7e8d:	48 29 c8             	sub    %rcx,%rax
    7e90:	48 39 d0             	cmp    %rdx,%rax
    7e93:	0f 83 45 ff ff ff    	jae    7dde <fwp_drop1+0x8e>
    7e99:	4c 89 c7             	mov    %r8,%rdi
    7e9c:	e9 dc fe ff ff       	jmp    7d7d <fwp_drop1+0x2d>
    7ea1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ea8:	c3                   	ret
    7ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7eb0:	66 85 c0             	test   %ax,%ax
    7eb3:	75 d5                	jne    7e8a <fwp_drop1+0x13a>
    7eb5:	eb a5                	jmp    7e5c <fwp_drop1+0x10c>
    7eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ebe:	00 00 
    7ec0:	48 89 d0             	mov    %rdx,%rax
    7ec3:	48 c1 e8 11          	shr    $0x11,%rax
    7ec7:	48 31 d0             	xor    %rdx,%rax
    7eca:	48 89 c1             	mov    %rax,%rcx
    7ecd:	48 c1 e9 09          	shr    $0x9,%rcx
    7ed1:	48 31 c8             	xor    %rcx,%rax
    7ed4:	0f b6 c8             	movzbl %al,%ecx
    7ed7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7ede:	00 
    7edf:	48 85 c0             	test   %rax,%rax
    7ee2:	75 25                	jne    7f09 <fwp_drop1+0x1b9>
    7ee4:	eb 5e                	jmp    7f44 <fwp_drop1+0x1f4>
    7ee6:	0f 1f 40 00          	nopl   0x0(%rax)
    7eea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ef1:	00 00 00 00 
    7ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7efc:	00 00 00 00 
    7f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7f04:	48 85 c0             	test   %rax,%rax
    7f07:	74 3b                	je     7f44 <fwp_drop1+0x1f4>
    7f09:	48 89 c1             	mov    %rax,%rcx
    7f0c:	48 39 10             	cmp    %rdx,(%rax)
    7f0f:	75 ef                	jne    7f00 <fwp_drop1+0x1b0>
    7f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7f24:	0f 85 b4 fe ff ff    	jne    7dde <fwp_drop1+0x8e>
    7f2a:	48 89 d7             	mov    %rdx,%rdi
    7f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f32:	e8 d9 d8 ff ff       	call   5810 <fwp_rc_forget_slot>
    7f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7f3f:	e9 9a fe ff ff       	jmp    7dde <fwp_drop1+0x8e>
    7f44:	48 8d 3d 5d 3a 00 00 	lea    0x3a5d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7f4b:	e8 e0 c4 ff ff       	call   4430 <fwp_trap>

0000000000007f50 <fwp_drop10>:
    7f50:	48 8b 0d c1 0c 06 00 	mov    0x60cc1(%rip),%rcx        # 68c18 <fwp_heap+0x13d8>
    7f57:	48 89 f8             	mov    %rdi,%rax
    7f5a:	48 2b 05 8f 0c 06 00 	sub    0x60c8f(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    7f61:	48 c1 e1 10          	shl    $0x10,%rcx
    7f65:	48 39 c8             	cmp    %rcx,%rax
    7f68:	0f 83 c2 01 00 00    	jae    8130 <fwp_drop10+0x1e0>
    7f6e:	48 83 ec 18          	sub    $0x18,%rsp
    7f72:	48 89 fa             	mov    %rdi,%rdx
    7f75:	48 8d 35 c4 f8 05 00 	lea    0x5f8c4(%rip),%rsi        # 67840 <fwp_heap>
    7f7c:	48 89 c1             	mov    %rax,%rcx
    7f7f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7f86:	48 c1 e9 10          	shr    $0x10,%rcx
    7f8a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f8e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7f92:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7f96:	48 85 c9             	test   %rcx,%rcx
    7f99:	74 46                	je     7fe1 <fwp_drop10+0x91>
    7f9b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7f9f:	41 80 f9 02          	cmp    $0x2,%r9b
    7fa3:	0f 84 d7 00 00 00    	je     8080 <fwp_drop10+0x130>
    7fa9:	41 80 f9 01          	cmp    $0x1,%r9b
    7fad:	75 32                	jne    7fe1 <fwp_drop10+0x91>
    7faf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7fb3:	0f b7 c0             	movzwl %ax,%eax
    7fb6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7fb9:	49 0f af c1          	imul   %r9,%rax
    7fbd:	48 c1 e8 20          	shr    $0x20,%rax
    7fc1:	48 39 f8             	cmp    %rdi,%rax
    7fc4:	73 1b                	jae    7fe1 <fwp_drop10+0x91>
    7fc6:	48 01 c1             	add    %rax,%rcx
    7fc9:	0f b6 01             	movzbl (%rcx),%eax
    7fcc:	84 c0                	test   %al,%al
    7fce:	74 11                	je     7fe1 <fwp_drop10+0x91>
    7fd0:	3c 01                	cmp    $0x1,%al
    7fd2:	74 1c                	je     7ff0 <fwp_drop10+0xa0>
    7fd4:	3c ff                	cmp    $0xff,%al
    7fd6:	0f 84 5c 01 00 00    	je     8138 <fwp_drop10+0x1e8>
    7fdc:	83 e8 01             	sub    $0x1,%eax
    7fdf:	88 01                	mov    %al,(%rcx)
    7fe1:	48 83 c4 18          	add    $0x18,%rsp
    7fe5:	c3                   	ret
    7fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7fed:	00 00 00 
    7ff0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7ff7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7ffe:	48 89 d0             	mov    %rdx,%rax
    8001:	49 89 d1             	mov    %rdx,%r9
    8004:	48 c1 e1 10          	shl    $0x10,%rcx
    8008:	48 29 f8             	sub    %rdi,%rax
    800b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    800f:	78 7f                	js     8090 <fwp_drop10+0x140>
    8011:	48 39 c8             	cmp    %rcx,%rax
    8014:	73 cb                	jae    7fe1 <fwp_drop10+0x91>
    8016:	48 89 c1             	mov    %rax,%rcx
    8019:	48 c1 e9 10          	shr    $0x10,%rcx
    801d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8021:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8025:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8029:	48 85 f6             	test   %rsi,%rsi
    802c:	74 b3                	je     7fe1 <fwp_drop10+0x91>
    802e:	0f b6 39             	movzbl (%rcx),%edi
    8031:	40 80 ff 02          	cmp    $0x2,%dil
    8035:	74 39                	je     8070 <fwp_drop10+0x120>
    8037:	40 80 ff 01          	cmp    $0x1,%dil
    803b:	75 a4                	jne    7fe1 <fwp_drop10+0x91>
    803d:	8b 79 18             	mov    0x18(%rcx),%edi
    8040:	0f b7 c0             	movzwl %ax,%eax
    8043:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8046:	48 0f af c7          	imul   %rdi,%rax
    804a:	48 c1 e8 20          	shr    $0x20,%rax
    804e:	48 39 c8             	cmp    %rcx,%rax
    8051:	73 8e                	jae    7fe1 <fwp_drop10+0x91>
    8053:	48 01 c6             	add    %rax,%rsi
    8056:	80 3e 01             	cmpb   $0x1,(%rsi)
    8059:	75 86                	jne    7fe1 <fwp_drop10+0x91>
    805b:	48 89 d7             	mov    %rdx,%rdi
    805e:	48 83 c4 18          	add    $0x18,%rsp
    8062:	e9 e9 d9 ff ff       	jmp    5a50 <fwp_mem_free>
    8067:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    806e:	00 00 
    8070:	66 85 c0             	test   %ax,%ax
    8073:	74 e1                	je     8056 <fwp_drop10+0x106>
    8075:	48 83 c4 18          	add    $0x18,%rsp
    8079:	c3                   	ret
    807a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8080:	66 85 c0             	test   %ax,%ax
    8083:	0f 84 40 ff ff ff    	je     7fc9 <fwp_drop10+0x79>
    8089:	48 83 c4 18          	add    $0x18,%rsp
    808d:	c3                   	ret
    808e:	66 90                	xchg   %ax,%ax
    8090:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8094:	48 39 c8             	cmp    %rcx,%rax
    8097:	73 74                	jae    810d <fwp_drop10+0x1bd>
    8099:	49 89 c2             	mov    %rax,%r10
    809c:	49 c1 ea 10          	shr    $0x10,%r10
    80a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    80a4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    80a8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    80ac:	4d 85 d2             	test   %r10,%r10
    80af:	74 5c                	je     810d <fwp_drop10+0x1bd>
    80b1:	45 0f b6 18          	movzbl (%r8),%r11d
    80b5:	41 80 fb 02          	cmp    $0x2,%r11b
    80b9:	74 6d                	je     8128 <fwp_drop10+0x1d8>
    80bb:	41 80 fb 01          	cmp    $0x1,%r11b
    80bf:	75 4c                	jne    810d <fwp_drop10+0x1bd>
    80c1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    80c5:	0f b7 c0             	movzwl %ax,%eax
    80c8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    80cc:	49 0f af c3          	imul   %r11,%rax
    80d0:	48 c1 e8 20          	shr    $0x20,%rax
    80d4:	4c 39 c0             	cmp    %r8,%rax
    80d7:	73 34                	jae    810d <fwp_drop10+0x1bd>
    80d9:	49 01 c2             	add    %rax,%r10
    80dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    80e0:	75 2b                	jne    810d <fwp_drop10+0x1bd>
    80e2:	4c 89 cf             	mov    %r9,%rdi
    80e5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    80ea:	e8 61 d9 ff ff       	call   5a50 <fwp_mem_free>
    80ef:	48 8d 35 4a f7 05 00 	lea    0x5f74a(%rip),%rsi        # 67840 <fwp_heap>
    80f6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80fb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8102:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8109:	48 c1 e1 10          	shl    $0x10,%rcx
    810d:	48 89 d0             	mov    %rdx,%rax
    8110:	48 29 f8             	sub    %rdi,%rax
    8113:	48 39 c8             	cmp    %rcx,%rax
    8116:	0f 82 60 fe ff ff    	jb     7f7c <fwp_drop10+0x2c>
    811c:	e9 c0 fe ff ff       	jmp    7fe1 <fwp_drop10+0x91>
    8121:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8128:	66 85 c0             	test   %ax,%ax
    812b:	75 e0                	jne    810d <fwp_drop10+0x1bd>
    812d:	eb ad                	jmp    80dc <fwp_drop10+0x18c>
    812f:	90                   	nop
    8130:	c3                   	ret
    8131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8138:	48 89 c8             	mov    %rcx,%rax
    813b:	48 c1 e8 11          	shr    $0x11,%rax
    813f:	48 31 c8             	xor    %rcx,%rax
    8142:	48 89 c2             	mov    %rax,%rdx
    8145:	48 c1 ea 09          	shr    $0x9,%rdx
    8149:	48 31 d0             	xor    %rdx,%rax
    814c:	0f b6 d0             	movzbl %al,%edx
    814f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8156:	00 
    8157:	48 85 c0             	test   %rax,%rax
    815a:	75 0d                	jne    8169 <fwp_drop10+0x219>
    815c:	eb 46                	jmp    81a4 <fwp_drop10+0x254>
    815e:	66 90                	xchg   %ax,%ax
    8160:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8164:	48 85 c0             	test   %rax,%rax
    8167:	74 3b                	je     81a4 <fwp_drop10+0x254>
    8169:	48 89 c2             	mov    %rax,%rdx
    816c:	48 39 08             	cmp    %rcx,(%rax)
    816f:	75 ef                	jne    8160 <fwp_drop10+0x210>
    8171:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8175:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8179:	48 89 50 08          	mov    %rdx,0x8(%rax)
    817d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8184:	0f 85 57 fe ff ff    	jne    7fe1 <fwp_drop10+0x91>
    818a:	48 89 cf             	mov    %rcx,%rdi
    818d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8192:	e8 79 d6 ff ff       	call   5810 <fwp_rc_forget_slot>
    8197:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    819c:	c6 01 fe             	movb   $0xfe,(%rcx)
    819f:	e9 3d fe ff ff       	jmp    7fe1 <fwp_drop10+0x91>
    81a4:	48 8d 3d fd 37 00 00 	lea    0x37fd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    81ab:	e8 80 c2 ff ff       	call   4430 <fwp_trap>

00000000000081b0 <f37>:
    81b0:	41 57                	push   %r15
    81b2:	41 56                	push   %r14
    81b4:	41 55                	push   %r13
    81b6:	41 54                	push   %r12
    81b8:	55                   	push   %rbp
    81b9:	53                   	push   %rbx
    81ba:	48 83 ec 38          	sub    $0x38,%rsp
    81be:	48 8b 15 53 0a 06 00 	mov    0x60a53(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    81c5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    81ca:	48 c1 e2 10          	shl    $0x10,%rdx
    81ce:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    81d5:	00 00 
    81d7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    81dc:	48 8b 0d 0d 0a 06 00 	mov    0x60a0d(%rip),%rcx        # 68bf0 <fwp_heap+0x13b0>
    81e3:	48 85 ff             	test   %rdi,%rdi
    81e6:	0f 84 1e 03 00 00    	je     850a <f37+0x35a>
    81ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81f1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    81f5:	4c 89 e8             	mov    %r13,%rax
    81f8:	48 29 c8             	sub    %rcx,%rax
    81fb:	48 39 d0             	cmp    %rdx,%rax
    81fe:	0f 83 ec 02 00 00    	jae    84f0 <f37+0x340>
    8204:	48 89 c2             	mov    %rax,%rdx
    8207:	48 c1 ea 10          	shr    $0x10,%rdx
    820b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    820f:	48 8b 15 22 0a 06 00 	mov    0x60a22(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    8216:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    821a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    821e:	48 85 ff             	test   %rdi,%rdi
    8221:	0f 84 c9 02 00 00    	je     84f0 <f37+0x340>
    8227:	0f b6 0a             	movzbl (%rdx),%ecx
    822a:	80 f9 02             	cmp    $0x2,%cl
    822d:	0f 84 4d 02 00 00    	je     8480 <f37+0x2d0>
    8233:	80 f9 01             	cmp    $0x1,%cl
    8236:	75 24                	jne    825c <f37+0xac>
    8238:	8b 4a 18             	mov    0x18(%rdx),%ecx
    823b:	0f b7 c0             	movzwl %ax,%eax
    823e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8241:	48 0f af c1          	imul   %rcx,%rax
    8245:	48 c1 e8 20          	shr    $0x20,%rax
    8249:	48 39 d0             	cmp    %rdx,%rax
    824c:	73 0e                	jae    825c <f37+0xac>
    824e:	48 01 c7             	add    %rax,%rdi
    8251:	0f b6 07             	movzbl (%rdi),%eax
    8254:	84 c0                	test   %al,%al
    8256:	0f 85 44 02 00 00    	jne    84a0 <f37+0x2f0>
    825c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8261:	48 8b 40 10          	mov    0x10(%rax),%rax
    8265:	ba 01 00 00 00       	mov    $0x1,%edx
    826a:	48 85 c0             	test   %rax,%rax
    826d:	74 0e                	je     827d <f37+0xcd>
    826f:	90                   	nop
    8270:	48 8b 40 10          	mov    0x10(%rax),%rax
    8274:	48 83 c2 01          	add    $0x1,%rdx
    8278:	48 85 c0             	test   %rax,%rax
    827b:	75 f3                	jne    8270 <f37+0xc0>
    827d:	4d 85 ed             	test   %r13,%r13
    8280:	0f 84 9a 02 00 00    	je     8520 <f37+0x370>
    8286:	4c 89 e8             	mov    %r13,%rax
    8289:	31 db                	xor    %ebx,%ebx
    828b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8290:	48 8b 40 10          	mov    0x10(%rax),%rax
    8294:	48 83 c3 01          	add    $0x1,%rbx
    8298:	48 85 c0             	test   %rax,%rax
    829b:	75 f3                	jne    8290 <f37+0xe0>
    829d:	48 39 d3             	cmp    %rdx,%rbx
    82a0:	48 0f 47 da          	cmova  %rdx,%rbx
    82a4:	48 89 d8             	mov    %rbx,%rax
    82a7:	48 c1 e8 3c          	shr    $0x3c,%rax
    82ab:	0f 85 7d 03 00 00    	jne    862e <f37+0x47e>
    82b1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    82b5:	be 02 00 00 00       	mov    $0x2,%esi
    82ba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    82c1:	00 
    82c2:	e8 89 dc ff ff       	call   5f50 <fwp_heap_alloc>
    82c7:	48 89 28             	mov    %rbp,(%rax)
    82ca:	48 8b 15 47 09 06 00 	mov    0x60947(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    82d1:	49 89 c4             	mov    %rax,%r12
    82d4:	48 2b 05 15 09 06 00 	sub    0x60915(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    82db:	48 c1 e2 10          	shl    $0x10,%rdx
    82df:	48 39 d0             	cmp    %rdx,%rax
    82e2:	73 57                	jae    833b <f37+0x18b>
    82e4:	48 89 c2             	mov    %rax,%rdx
    82e7:	48 c1 ea 10          	shr    $0x10,%rdx
    82eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82ef:	48 8b 15 42 09 06 00 	mov    0x60942(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    82f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82fa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    82fe:	48 85 ed             	test   %rbp,%rbp
    8301:	74 38                	je     833b <f37+0x18b>
    8303:	0f b6 0a             	movzbl (%rdx),%ecx
    8306:	80 f9 02             	cmp    $0x2,%cl
    8309:	0f 84 d1 01 00 00    	je     84e0 <f37+0x330>
    830f:	80 f9 01             	cmp    $0x1,%cl
    8312:	75 27                	jne    833b <f37+0x18b>
    8314:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8317:	0f b7 c0             	movzwl %ax,%eax
    831a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    831d:	48 0f af c1          	imul   %rcx,%rax
    8321:	48 c1 e8 20          	shr    $0x20,%rax
    8325:	48 39 d0             	cmp    %rdx,%rax
    8328:	73 11                	jae    833b <f37+0x18b>
    832a:	48 01 c5             	add    %rax,%rbp
    832d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8331:	0f 84 57 02 00 00    	je     858e <f37+0x3de>
    8337:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    833b:	48 85 db             	test   %rbx,%rbx
    833e:	74 5d                	je     839d <f37+0x1ed>
    8340:	48 c1 e3 04          	shl    $0x4,%rbx
    8344:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8349:	4c 89 e5             	mov    %r12,%rbp
    834c:	4d 89 ef             	mov    %r13,%r15
    834f:	4c 01 e3             	add    %r12,%rbx
    8352:	0f 1f 00             	nopl   (%rax)
    8355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    835c:	00 00 00 00 
    8360:	49 8b 46 08          	mov    0x8(%r14),%rax
    8364:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8368:	48 83 c5 10          	add    $0x10,%rbp
    836c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8371:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8375:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8379:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    837e:	e8 2d e3 ff ff       	call   66b0 <w120>
    8383:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8388:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    838c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8390:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8394:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8398:	48 39 dd             	cmp    %rbx,%rbp
    839b:	75 c3                	jne    8360 <f37+0x1b0>
    839d:	4c 89 ef             	mov    %r13,%rdi
    83a0:	e8 8b ed ff ff       	call   7130 <fwp_drop4>
    83a5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    83aa:	e8 81 ed ff ff       	call   7130 <fwp_drop4>
    83af:	4c 89 e7             	mov    %r12,%rdi
    83b2:	e8 79 e4 ff ff       	call   6830 <w176.constprop.0>
    83b7:	4c 89 e7             	mov    %r12,%rdi
    83ba:	48 89 c3             	mov    %rax,%rbx
    83bd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    83c3:	e8 88 fb ff ff       	call   7f50 <fwp_drop10>
    83c8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    83ce:	66 48 0f 6e db       	movq   %rbx,%xmm3
    83d3:	31 ff                	xor    %edi,%edi
    83d5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    83da:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    83de:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    83e3:	e8 58 dd ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    83e8:	48 8b 15 29 08 06 00 	mov    0x60829(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    83ef:	48 89 c5             	mov    %rax,%rbp
    83f2:	48 2b 05 f7 07 06 00 	sub    0x607f7(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    83f9:	48 c1 e2 10          	shl    $0x10,%rdx
    83fd:	48 39 d0             	cmp    %rdx,%rax
    8400:	73 55                	jae    8457 <f37+0x2a7>
    8402:	48 89 c2             	mov    %rax,%rdx
    8405:	48 c1 ea 10          	shr    $0x10,%rdx
    8409:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    840d:	48 8b 15 24 08 06 00 	mov    0x60824(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    8414:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8418:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    841c:	48 85 db             	test   %rbx,%rbx
    841f:	74 36                	je     8457 <f37+0x2a7>
    8421:	0f b6 0a             	movzbl (%rdx),%ecx
    8424:	80 f9 02             	cmp    $0x2,%cl
    8427:	0f 84 a3 00 00 00    	je     84d0 <f37+0x320>
    842d:	80 f9 01             	cmp    $0x1,%cl
    8430:	75 25                	jne    8457 <f37+0x2a7>
    8432:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8435:	0f b7 c0             	movzwl %ax,%eax
    8438:	8b 52 1c             	mov    0x1c(%rdx),%edx
    843b:	48 0f af c1          	imul   %rcx,%rax
    843f:	48 c1 e8 20          	shr    $0x20,%rax
    8443:	48 39 d0             	cmp    %rdx,%rax
    8446:	73 0f                	jae    8457 <f37+0x2a7>
    8448:	48 01 c3             	add    %rax,%rbx
    844b:	80 3b ff             	cmpb   $0xff,(%rbx)
    844e:	0f 84 2d 01 00 00    	je     8581 <f37+0x3d1>
    8454:	c6 03 01             	movb   $0x1,(%rbx)
    8457:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    845c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8463:	00 00 
    8465:	0f 85 cf 01 00 00    	jne    863a <f37+0x48a>
    846b:	48 83 c4 38          	add    $0x38,%rsp
    846f:	48 89 e8             	mov    %rbp,%rax
    8472:	5b                   	pop    %rbx
    8473:	5d                   	pop    %rbp
    8474:	41 5c                	pop    %r12
    8476:	41 5d                	pop    %r13
    8478:	41 5e                	pop    %r14
    847a:	41 5f                	pop    %r15
    847c:	c3                   	ret
    847d:	0f 1f 00             	nopl   (%rax)
    8480:	66 85 c0             	test   %ax,%ax
    8483:	0f 85 d3 fd ff ff    	jne    825c <f37+0xac>
    8489:	0f b6 07             	movzbl (%rdi),%eax
    848c:	84 c0                	test   %al,%al
    848e:	0f 84 c8 fd ff ff    	je     825c <f37+0xac>
    8494:	90                   	nop
    8495:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    849c:	00 00 00 00 
    84a0:	8b 15 62 10 06 00    	mov    0x61062(%rip),%edx        # 69508 <iteration_active>
    84a6:	85 d2                	test   %edx,%edx
    84a8:	75 56                	jne    8500 <f37+0x350>
    84aa:	3c fd                	cmp    $0xfd,%al
    84ac:	0f 87 4b 01 00 00    	ja     85fd <f37+0x44d>
    84b2:	83 c0 01             	add    $0x1,%eax
    84b5:	88 07                	mov    %al,(%rdi)
    84b7:	31 d2                	xor    %edx,%edx
    84b9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    84bf:	0f 85 97 fd ff ff    	jne    825c <f37+0xac>
    84c5:	e9 b3 fd ff ff       	jmp    827d <f37+0xcd>
    84ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84d0:	66 85 c0             	test   %ax,%ax
    84d3:	0f 85 7e ff ff ff    	jne    8457 <f37+0x2a7>
    84d9:	e9 6d ff ff ff       	jmp    844b <f37+0x29b>
    84de:	66 90                	xchg   %ax,%ax
    84e0:	66 85 c0             	test   %ax,%ax
    84e3:	0f 85 52 fe ff ff    	jne    833b <f37+0x18b>
    84e9:	e9 3f fe ff ff       	jmp    832d <f37+0x17d>
    84ee:	66 90                	xchg   %ax,%ax
    84f0:	4c 89 e8             	mov    %r13,%rax
    84f3:	e9 6d fd ff ff       	jmp    8265 <f37+0xb5>
    84f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84ff:	00 
    8500:	48 83 05 e8 0f 06 00 	addq   $0x1,0x60fe8(%rip)        # 694f0 <iteration_retains>
    8507:	01 
    8508:	eb a0                	jmp    84aa <f37+0x2fa>
    850a:	48 f7 d9             	neg    %rcx
    850d:	48 39 d1             	cmp    %rdx,%rcx
    8510:	0f 82 85 00 00 00    	jb     859b <f37+0x3eb>
    8516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    851d:	00 00 00 
    8520:	be 02 00 00 00       	mov    $0x2,%esi
    8525:	bf 08 00 00 00       	mov    $0x8,%edi
    852a:	e8 21 da ff ff       	call   5f50 <fwp_heap_alloc>
    852f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8536:	48 8b 15 db 06 06 00 	mov    0x606db(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    853d:	49 89 c4             	mov    %rax,%r12
    8540:	48 2b 05 a9 06 06 00 	sub    0x606a9(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    8547:	48 c1 e2 10          	shl    $0x10,%rdx
    854b:	48 39 d0             	cmp    %rdx,%rax
    854e:	0f 83 b3 00 00 00    	jae    8607 <f37+0x457>
    8554:	48 89 c2             	mov    %rax,%rdx
    8557:	48 c1 ea 10          	shr    $0x10,%rdx
    855b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    855f:	48 8b 15 d2 06 06 00 	mov    0x606d2(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    8566:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    856a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    856e:	48 85 ed             	test   %rbp,%rbp
    8571:	0f 84 90 00 00 00    	je     8607 <f37+0x457>
    8577:	31 db                	xor    %ebx,%ebx
    8579:	45 31 ed             	xor    %r13d,%r13d
    857c:	e9 82 fd ff ff       	jmp    8303 <f37+0x153>
    8581:	48 89 df             	mov    %rbx,%rdi
    8584:	e8 87 d2 ff ff       	call   5810 <fwp_rc_forget_slot>
    8589:	e9 c6 fe ff ff       	jmp    8454 <f37+0x2a4>
    858e:	48 89 ef             	mov    %rbp,%rdi
    8591:	e8 7a d2 ff ff       	call   5810 <fwp_rc_forget_slot>
    8596:	e9 9c fd ff ff       	jmp    8337 <f37+0x187>
    859b:	48 89 c8             	mov    %rcx,%rax
    859e:	48 c1 e8 10          	shr    $0x10,%rax
    85a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    85a6:	48 8b 05 8b 06 06 00 	mov    0x6068b(%rip),%rax        # 68c38 <fwp_heap+0x13f8>
    85ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    85b1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85b5:	48 85 ff             	test   %rdi,%rdi
    85b8:	0f 84 62 ff ff ff    	je     8520 <f37+0x370>
    85be:	0f b6 02             	movzbl (%rdx),%eax
    85c1:	3c 02                	cmp    $0x2,%al
    85c3:	74 4a                	je     860f <f37+0x45f>
    85c5:	3c 01                	cmp    $0x1,%al
    85c7:	0f 85 53 ff ff ff    	jne    8520 <f37+0x370>
    85cd:	0f b7 c1             	movzwl %cx,%eax
    85d0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85d6:	48 0f af c1          	imul   %rcx,%rax
    85da:	48 c1 e8 20          	shr    $0x20,%rax
    85de:	48 39 d0             	cmp    %rdx,%rax
    85e1:	0f 83 39 ff ff ff    	jae    8520 <f37+0x370>
    85e7:	48 01 c7             	add    %rax,%rdi
    85ea:	0f b6 07             	movzbl (%rdi),%eax
    85ed:	84 c0                	test   %al,%al
    85ef:	0f 84 2b ff ff ff    	je     8520 <f37+0x370>
    85f5:	45 31 ed             	xor    %r13d,%r13d
    85f8:	e9 a3 fe ff ff       	jmp    84a0 <f37+0x2f0>
    85fd:	e8 ee d0 ff ff       	call   56f0 <fwp_rc_wide_dup>
    8602:	e9 b0 fe ff ff       	jmp    84b7 <f37+0x307>
    8607:	45 31 ed             	xor    %r13d,%r13d
    860a:	e9 8e fd ff ff       	jmp    839d <f37+0x1ed>
    860f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8615:	49 89 cd             	mov    %rcx,%r13
    8618:	0f 85 02 ff ff ff    	jne    8520 <f37+0x370>
    861e:	0f b6 07             	movzbl (%rdi),%eax
    8621:	84 c0                	test   %al,%al
    8623:	0f 85 77 fe ff ff    	jne    84a0 <f37+0x2f0>
    8629:	e9 f2 fe ff ff       	jmp    8520 <f37+0x370>
    862e:	48 8d 3d b6 2b 00 00 	lea    0x2bb6(%rip),%rdi        # b1eb <_IO_stdin_used+0x1eb>
    8635:	e8 f6 bd ff ff       	call   4430 <fwp_trap>
    863a:	e8 11 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    863f:	90                   	nop

0000000000008640 <fwp_owned_entry37>:
    8640:	f3 0f 1e fa          	endbr64
    8644:	48 8b 3f             	mov    (%rdi),%rdi
    8647:	e9 64 fb ff ff       	jmp    81b0 <f37>
    864c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008650 <e37>:
    8650:	f3 0f 1e fa          	endbr64
    8654:	53                   	push   %rbx
    8655:	48 8b 1f             	mov    (%rdi),%rbx
    8658:	48 89 df             	mov    %rbx,%rdi
    865b:	e8 70 e2 ff ff       	call   68d0 <fwp_rc_share>
    8660:	48 89 df             	mov    %rbx,%rdi
    8663:	e8 48 fb ff ff       	call   81b0 <f37>
    8668:	48 89 c3             	mov    %rax,%rbx
    866b:	48 89 c7             	mov    %rax,%rdi
    866e:	e8 5d e2 ff ff       	call   68d0 <fwp_rc_share>
    8673:	48 89 d8             	mov    %rbx,%rax
    8676:	5b                   	pop    %rbx
    8677:	c3                   	ret
    8678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    867f:	00 

0000000000008680 <fwp_write>:
    8680:	41 57                	push   %r15
    8682:	41 56                	push   %r14
    8684:	41 55                	push   %r13
    8686:	41 54                	push   %r12
    8688:	55                   	push   %rbp
    8689:	53                   	push   %rbx
    868a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8691:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8698:	00 00 
    869a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    86a1:	00 
    86a2:	49 89 d4             	mov    %rdx,%r12
    86a5:	8b 12                	mov    (%rdx),%edx
    86a7:	83 fa 19             	cmp    $0x19,%edx
    86aa:	77 6a                	ja     8716 <fwp_write+0x96>
    86ac:	48 89 f5             	mov    %rsi,%rbp
    86af:	89 d0                	mov    %edx,%eax
    86b1:	89 ce                	mov    %ecx,%esi
    86b3:	48 89 fb             	mov    %rdi,%rbx
    86b6:	48 8d 0d 43 35 00 00 	lea    0x3543(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    86bd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    86c1:	48 01 c8             	add    %rcx,%rax
    86c4:	3e ff e0             	notrack jmp *%rax
    86c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86ce:	00 00 
    86d0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    86d4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    86d8:	48 89 ca             	mov    %rcx,%rdx
    86db:	48 85 c9             	test   %rcx,%rcx
    86de:	0f 88 9c 0c 00 00    	js     9380 <fwp_write+0xd00>
    86e4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    86eb:	00 
    86ec:	48 89 c6             	mov    %rax,%rsi
    86ef:	4c 89 e7             	mov    %r12,%rdi
    86f2:	e8 29 b3 ff ff       	call   3a20 <fwp_fmt_u128>
    86f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86fe:	00 00 
    8700:	4c 89 e7             	mov    %r12,%rdi
    8703:	e8 38 ad ff ff       	call   3440 <strlen@plt>
    8708:	4c 89 e6             	mov    %r12,%rsi
    870b:	48 89 df             	mov    %rbx,%rdi
    870e:	48 89 c2             	mov    %rax,%rdx
    8711:	e8 ba b9 ff ff       	call   40d0 <buf_put>
    8716:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    871d:	00 
    871e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8725:	00 00 
    8727:	0f 85 28 04 00 00    	jne    8b55 <fwp_write+0x4d5>
    872d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8734:	5b                   	pop    %rbx
    8735:	5d                   	pop    %rbp
    8736:	41 5c                	pop    %r12
    8738:	41 5d                	pop    %r13
    873a:	41 5e                	pop    %r14
    873c:	41 5f                	pop    %r15
    873e:	c3                   	ret
    873f:	90                   	nop
    8740:	49 89 e9             	mov    %rbp,%r9
    8743:	4c 8d 05 cb 2a 00 00 	lea    0x2acb(%rip),%r8        # b215 <_IO_stdin_used+0x215>
    874a:	b9 00 02 00 00       	mov    $0x200,%ecx
    874f:	ba 02 00 00 00       	mov    $0x2,%edx
    8754:	be 00 02 00 00       	mov    $0x200,%esi
    8759:	31 c0                	xor    %eax,%eax
    875b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8762:	00 
    8763:	e8 38 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    8768:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    876f:	00 
    8770:	e8 cb ac ff ff       	call   3440 <strlen@plt>
    8775:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    877c:	00 
    877d:	48 89 df             	mov    %rbx,%rdi
    8780:	48 89 c2             	mov    %rax,%rdx
    8783:	e8 48 b9 ff ff       	call   40d0 <buf_put>
    8788:	eb 8c                	jmp    8716 <fwp_write+0x96>
    878a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8790:	49 89 e9             	mov    %rbp,%r9
    8793:	4c 8d 05 76 2a 00 00 	lea    0x2a76(%rip),%r8        # b210 <_IO_stdin_used+0x210>
    879a:	eb ae                	jmp    874a <fwp_write+0xca>
    879c:	0f 1f 40 00          	nopl   0x0(%rax)
    87a0:	83 fa 13             	cmp    $0x13,%edx
    87a3:	48 8d 05 5c 2a 00 00 	lea    0x2a5c(%rip),%rax        # b206 <_IO_stdin_used+0x206>
    87aa:	48 8d 35 5a 2a 00 00 	lea    0x2a5a(%rip),%rsi        # b20b <_IO_stdin_used+0x20b>
    87b1:	ba 04 00 00 00       	mov    $0x4,%edx
    87b6:	48 0f 44 f0          	cmove  %rax,%rsi
    87ba:	45 31 ed             	xor    %r13d,%r13d
    87bd:	e8 0e b9 ff ff       	call   40d0 <buf_put>
    87c2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    87c7:	0f 84 a3 08 00 00    	je     9070 <fwp_write+0x9f0>
    87cd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    87d2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    87d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    87dc:	48 89 df             	mov    %rbx,%rdi
    87df:	49 0f 44 c5          	cmove  %r13,%rax
    87e3:	31 c9                	xor    %ecx,%ecx
    87e5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    87ea:	e8 91 fe ff ff       	call   8680 <fwp_write>
    87ef:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    87f4:	0f 84 6e 09 00 00    	je     9168 <fwp_write+0xae8>
    87fa:	49 83 c5 01          	add    $0x1,%r13
    87fe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8802:	0f 83 68 08 00 00    	jae    9070 <fwp_write+0x9f0>
    8808:	ba 02 00 00 00       	mov    $0x2,%edx
    880d:	48 8d 35 41 2a 00 00 	lea    0x2a41(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8814:	48 89 df             	mov    %rbx,%rdi
    8817:	e8 b4 b8 ff ff       	call   40d0 <buf_put>
    881c:	eb af                	jmp    87cd <fwp_write+0x14d>
    881e:	66 90                	xchg   %ax,%ax
    8820:	ba 06 00 00 00       	mov    $0x6,%edx
    8825:	48 8d 35 02 2a 00 00 	lea    0x2a02(%rip),%rsi        # b22e <_IO_stdin_used+0x22e>
    882c:	48 83 c5 10          	add    $0x10,%rbp
    8830:	e8 9b b8 ff ff       	call   40d0 <buf_put>
    8835:	48 89 ef             	mov    %rbp,%rdi
    8838:	e8 03 ac ff ff       	call   3440 <strlen@plt>
    883d:	48 89 ee             	mov    %rbp,%rsi
    8840:	48 89 df             	mov    %rbx,%rdi
    8843:	48 89 c2             	mov    %rax,%rdx
    8846:	e8 85 b8 ff ff       	call   40d0 <buf_put>
    884b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8850:	ba 01 00 00 00       	mov    $0x1,%edx
    8855:	48 89 df             	mov    %rbx,%rdi
    8858:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    885d:	e8 6e b8 ff ff       	call   40d0 <buf_put>
    8862:	e9 af fe ff ff       	jmp    8716 <fwp_write+0x96>
    8867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    886e:	00 00 
    8870:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8877:	00 
    8878:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    887f:	00 00 
    8881:	0f 85 ce 02 00 00    	jne    8b55 <fwp_write+0x4d5>
    8887:	ba 0a 00 00 00       	mov    $0xa,%edx
    888c:	48 8d 35 87 29 00 00 	lea    0x2987(%rip),%rsi        # b21a <_IO_stdin_used+0x21a>
    8893:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    889a:	48 89 df             	mov    %rbx,%rdi
    889d:	5b                   	pop    %rbx
    889e:	5d                   	pop    %rbp
    889f:	41 5c                	pop    %r12
    88a1:	41 5d                	pop    %r13
    88a3:	41 5e                	pop    %r14
    88a5:	41 5f                	pop    %r15
    88a7:	e9 24 b8 ff ff       	jmp    40d0 <buf_put>
    88ac:	0f 1f 40 00          	nopl   0x0(%rax)
    88b0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    88b5:	4d 85 ed             	test   %r13,%r13
    88b8:	0f 84 02 0c 00 00    	je     94c0 <fwp_write+0xe40>
    88be:	48 8d 35 9d 29 00 00 	lea    0x299d(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    88c5:	4c 89 ef             	mov    %r13,%rdi
    88c8:	e8 53 ac ff ff       	call   3520 <strcmp@plt>
    88cd:	41 89 c1             	mov    %eax,%r9d
    88d0:	85 c0                	test   %eax,%eax
    88d2:	0f 84 6c 0c 00 00    	je     9544 <fwp_write+0xec4>
    88d8:	4c 89 ef             	mov    %r13,%rdi
    88db:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    88e0:	e8 5b ab ff ff       	call   3440 <strlen@plt>
    88e5:	4c 89 ee             	mov    %r13,%rsi
    88e8:	48 89 df             	mov    %rbx,%rdi
    88eb:	48 89 c2             	mov    %rax,%rdx
    88ee:	e8 dd b7 ff ff       	call   40d0 <buf_put>
    88f3:	ba 01 00 00 00       	mov    $0x1,%edx
    88f8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88fd:	48 89 df             	mov    %rbx,%rdi
    8900:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8905:	e8 c6 b7 ff ff       	call   40d0 <buf_put>
    890a:	ba 01 00 00 00       	mov    $0x1,%edx
    890f:	4c 89 fe             	mov    %r15,%rsi
    8912:	48 89 df             	mov    %rbx,%rdi
    8915:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    891a:	e8 b1 b7 ff ff       	call   40d0 <buf_put>
    891f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8924:	45 31 f6             	xor    %r14d,%r14d
    8927:	85 d2                	test   %edx,%edx
    8929:	0f 8e 81 0a 00 00    	jle    93b0 <fwp_write+0xd30>
    892f:	45 31 ed             	xor    %r13d,%r13d
    8932:	4d 85 ed             	test   %r13,%r13
    8935:	0f 85 75 07 00 00    	jne    90b0 <fwp_write+0xa30>
    893b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8942:	00 
    8943:	45 85 f6             	test   %r14d,%r14d
    8946:	0f 84 84 07 00 00    	je     90d0 <fwp_write+0xa50>
    894c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8951:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8956:	48 89 df             	mov    %rbx,%rdi
    8959:	49 83 c5 01          	add    $0x1,%r13
    895d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8961:	31 c9                	xor    %ecx,%ecx
    8963:	e8 18 fd ff ff       	call   8680 <fwp_write>
    8968:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    896d:	7f c3                	jg     8932 <fwp_write+0x2b2>
    896f:	45 85 f6             	test   %r14d,%r14d
    8972:	0f 84 38 0a 00 00    	je     93b0 <fwp_write+0xd30>
    8978:	b8 29 00 00 00       	mov    $0x29,%eax
    897d:	ba 01 00 00 00       	mov    $0x1,%edx
    8982:	4c 89 fe             	mov    %r15,%rsi
    8985:	48 89 df             	mov    %rbx,%rdi
    8988:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    898c:	e8 3f b7 ff ff       	call   40d0 <buf_put>
    8991:	e9 80 fd ff ff       	jmp    8716 <fwp_write+0x96>
    8996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    899d:	00 00 00 
    89a0:	ba 01 00 00 00       	mov    $0x1,%edx
    89a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89aa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    89af:	e8 1c b7 ff ff       	call   40d0 <buf_put>
    89b4:	48 85 ed             	test   %rbp,%rbp
    89b7:	0f 84 93 06 00 00    	je     9050 <fwp_write+0x9d0>
    89bd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    89c1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89c6:	31 c9                	xor    %ecx,%ecx
    89c8:	48 89 df             	mov    %rbx,%rdi
    89cb:	e8 b0 fc ff ff       	call   8680 <fwp_write>
    89d0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    89d4:	48 85 ed             	test   %rbp,%rbp
    89d7:	0f 84 73 06 00 00    	je     9050 <fwp_write+0x9d0>
    89dd:	ba 02 00 00 00       	mov    $0x2,%edx
    89e2:	48 8d 35 6c 28 00 00 	lea    0x286c(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    89e9:	48 89 df             	mov    %rbx,%rdi
    89ec:	e8 df b6 ff ff       	call   40d0 <buf_put>
    89f1:	eb ca                	jmp    89bd <fwp_write+0x33d>
    89f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    89f8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    89fc:	85 f6                	test   %esi,%esi
    89fe:	0f 84 fc 07 00 00    	je     9200 <fwp_write+0xb80>
    8a04:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a0b:	00 
    8a0c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a13:	00 00 
    8a15:	0f 85 3a 01 00 00    	jne    8b55 <fwp_write+0x4d5>
    8a1b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8a1f:	4c 89 ea             	mov    %r13,%rdx
    8a22:	e9 6c fe ff ff       	jmp    8893 <fwp_write+0x213>
    8a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a2e:	00 00 
    8a30:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8a35:	ba 01 00 00 00       	mov    $0x1,%edx
    8a3a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8a3f:	48 89 ee             	mov    %rbp,%rsi
    8a42:	e8 89 b6 ff ff       	call   40d0 <buf_put>
    8a47:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8a4c:	4c 89 e7             	mov    %r12,%rdi
    8a4f:	e8 ec a9 ff ff       	call   3440 <strlen@plt>
    8a54:	4c 89 e6             	mov    %r12,%rsi
    8a57:	48 89 df             	mov    %rbx,%rdi
    8a5a:	48 89 c2             	mov    %rax,%rdx
    8a5d:	e8 6e b6 ff ff       	call   40d0 <buf_put>
    8a62:	ba 01 00 00 00       	mov    $0x1,%edx
    8a67:	48 89 ee             	mov    %rbp,%rsi
    8a6a:	48 89 df             	mov    %rbx,%rdi
    8a6d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a72:	e8 59 b6 ff ff       	call   40d0 <buf_put>
    8a77:	e9 9a fc ff ff       	jmp    8716 <fwp_write+0x96>
    8a7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a80:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8a85:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8a89:	0f 8a 8e 0b 00 00    	jp     961d <fwp_write+0xf9d>
    8a8f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a93:	66 0f 54 05 75 32 00 	andpd  0x3275(%rip),%xmm0        # bd10 <msg.8+0xa0>
    8a9a:	00 
    8a9b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8aa0:	66 0f 2e 05 98 32 00 	ucomisd 0x3298(%rip),%xmm0        # bd40 <msg.8+0xd0>
    8aa7:	00 
    8aa8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8aaf:	00 
    8ab0:	0f 87 b2 09 00 00    	ja     9468 <fwp_write+0xde8>
    8ab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8abd:	00 00 00 
    8ac0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ac4:	89 ee                	mov    %ebp,%esi
    8ac6:	4c 89 e7             	mov    %r12,%rdi
    8ac9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8ace:	e8 7d bc ff ff       	call   4750 <fwp_format_g.constprop.0>
    8ad3:	31 f6                	xor    %esi,%esi
    8ad5:	4c 89 e7             	mov    %r12,%rdi
    8ad8:	e8 23 a9 ff ff       	call   3400 <strtod@plt>
    8add:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8ae2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8ae6:	7a 06                	jp     8aee <fwp_write+0x46e>
    8ae8:	0f 84 e9 01 00 00    	je     8cd7 <fwp_write+0x657>
    8aee:	83 c5 01             	add    $0x1,%ebp
    8af1:	83 fd 12             	cmp    $0x12,%ebp
    8af4:	75 ca                	jne    8ac0 <fwp_write+0x440>
    8af6:	be 11 00 00 00       	mov    $0x11,%esi
    8afb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8aff:	4c 89 e7             	mov    %r12,%rdi
    8b02:	e8 49 bc ff ff       	call   4750 <fwp_format_g.constprop.0>
    8b07:	e9 cb 01 00 00       	jmp    8cd7 <fwp_write+0x657>
    8b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b10:	48 83 fd 01          	cmp    $0x1,%rbp
    8b14:	0f 84 e6 08 00 00    	je     9400 <fwp_write+0xd80>
    8b1a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8b1e:	b8 02 00 00 00       	mov    $0x2,%eax
    8b23:	ba 01 00 00 00       	mov    $0x1,%edx
    8b28:	48 0f 44 d0          	cmove  %rax,%rdx
    8b2c:	48 8d 35 cb 26 00 00 	lea    0x26cb(%rip),%rsi        # b1fe <_IO_stdin_used+0x1fe>
    8b33:	48 8d 05 c9 26 00 00 	lea    0x26c9(%rip),%rax        # b203 <_IO_stdin_used+0x203>
    8b3a:	48 0f 44 f0          	cmove  %rax,%rsi
    8b3e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b45:	00 
    8b46:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b4d:	00 00 
    8b4f:	0f 84 3e fd ff ff    	je     8893 <fwp_write+0x213>
    8b55:	e8 f6 a8 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b60:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8b65:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8b6a:	e8 a1 b4 ff ff       	call   4010 <buf_grow>
    8b6f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8b73:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8b79:	4c 03 0b             	add    (%rbx),%r9
    8b7c:	66 45 89 11          	mov    %r10w,(%r9)
    8b80:	45 85 e4             	test   %r12d,%r12d
    8b83:	0f 8e 07 05 00 00    	jle    9090 <fwp_write+0xa10>
    8b89:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8b90:	55 55 55 
    8b93:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8b98:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8b9f:	aa aa aa 
    8ba2:	49 83 c1 01          	add    $0x1,%r9
    8ba6:	eb 45                	jmp    8bed <fwp_write+0x56d>
    8ba8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8baf:	00 
    8bb0:	be 01 00 00 00       	mov    $0x1,%esi
    8bb5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8bba:	88 07                	mov    %al,(%rdi)
    8bbc:	48 89 e8             	mov    %rbp,%rax
    8bbf:	49 f7 e8             	imul   %r8
    8bc2:	48 89 e8             	mov    %rbp,%rax
    8bc5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8bc9:	48 29 c2             	sub    %rax,%rdx
    8bcc:	48 85 c9             	test   %rcx,%rcx
    8bcf:	0f 95 c0             	setne  %al
    8bd2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8bd6:	48 83 ef 01          	sub    $0x1,%rdi
    8bda:	48 21 c5             	and    %rax,%rbp
    8bdd:	48 29 ea             	sub    %rbp,%rdx
    8be0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8be4:	49 39 f9             	cmp    %rdi,%r9
    8be7:	0f 84 a3 04 00 00    	je     9090 <fwp_write+0xa10>
    8bed:	48 89 e8             	mov    %rbp,%rax
    8bf0:	49 f7 e8             	imul   %r8
    8bf3:	48 89 e8             	mov    %rbp,%rax
    8bf6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8bfa:	48 89 d1             	mov    %rdx,%rcx
    8bfd:	48 29 c1             	sub    %rax,%rcx
    8c00:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8c04:	48 89 e9             	mov    %rbp,%rcx
    8c07:	48 29 c1             	sub    %rax,%rcx
    8c0a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8c0e:	49 f7 e2             	mul    %r10
    8c11:	b8 30 00 00 00       	mov    $0x30,%eax
    8c16:	48 89 d6             	mov    %rdx,%rsi
    8c19:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8c1d:	48 d1 ee             	shr    $1,%rsi
    8c20:	48 01 f2             	add    %rsi,%rdx
    8c23:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8c27:	48 29 d6             	sub    %rdx,%rsi
    8c2a:	74 8e                	je     8bba <fwp_write+0x53a>
    8c2c:	48 83 fe 01          	cmp    $0x1,%rsi
    8c30:	0f 85 7a ff ff ff    	jne    8bb0 <fwp_write+0x530>
    8c36:	31 f6                	xor    %esi,%esi
    8c38:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8c3d:	e9 78 ff ff ff       	jmp    8bba <fwp_write+0x53a>
    8c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c48:	66 0f 6e cd          	movd   %ebp,%xmm1
    8c4c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8c4f:	0f 8a c8 09 00 00    	jp     961d <fwp_write+0xf9d>
    8c55:	0f 28 c1             	movaps %xmm1,%xmm0
    8c58:	0f 54 05 a1 30 00 00 	andps  0x30a1(%rip),%xmm0        # bd00 <msg.8+0x90>
    8c5f:	0f 2e 05 9e 23 00 00 	ucomiss 0x239e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8c66:	0f 87 24 08 00 00    	ja     9490 <fwp_write+0xe10>
    8c6c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8c70:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8c76:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c7d:	00 
    8c7e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8c82:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c8e:	00 00 
    8c90:	44 89 ee             	mov    %r13d,%esi
    8c93:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c98:	4c 89 e7             	mov    %r12,%rdi
    8c9b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8ca0:	e8 ab ba ff ff       	call   4750 <fwp_format_g.constprop.0>
    8ca5:	31 f6                	xor    %esi,%esi
    8ca7:	4c 89 e7             	mov    %r12,%rdi
    8caa:	e8 f1 a7 ff ff       	call   34a0 <strtof@plt>
    8caf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8cb4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8cb7:	7a 02                	jp     8cbb <fwp_write+0x63b>
    8cb9:	74 1c                	je     8cd7 <fwp_write+0x657>
    8cbb:	41 83 c5 01          	add    $0x1,%r13d
    8cbf:	41 83 fd 0a          	cmp    $0xa,%r13d
    8cc3:	75 cb                	jne    8c90 <fwp_write+0x610>
    8cc5:	be 09 00 00 00       	mov    $0x9,%esi
    8cca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8ccf:	4c 89 e7             	mov    %r12,%rdi
    8cd2:	e8 79 ba ff ff       	call   4750 <fwp_format_g.constprop.0>
    8cd7:	4c 89 e7             	mov    %r12,%rdi
    8cda:	e8 b1 b4 ff ff       	call   4190 <fwp_finish_float>
    8cdf:	e9 1c fa ff ff       	jmp    8700 <fwp_write+0x80>
    8ce4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ce8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8cec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8cf0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8cf7:	00 
    8cf8:	48 89 ef             	mov    %rbp,%rdi
    8cfb:	e8 20 ad ff ff       	call   3a20 <fwp_fmt_u128>
    8d00:	48 89 ef             	mov    %rbp,%rdi
    8d03:	e8 38 a7 ff ff       	call   3440 <strlen@plt>
    8d08:	48 89 ee             	mov    %rbp,%rsi
    8d0b:	48 89 df             	mov    %rbx,%rdi
    8d0e:	48 89 c2             	mov    %rax,%rdx
    8d11:	e8 ba b3 ff ff       	call   40d0 <buf_put>
    8d16:	e9 fb f9 ff ff       	jmp    8716 <fwp_write+0x96>
    8d1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d20:	ba 06 00 00 00       	mov    $0x6,%edx
    8d25:	48 8d 35 2c 25 00 00 	lea    0x252c(%rip),%rsi        # b258 <_IO_stdin_used+0x258>
    8d2c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8d32:	e8 99 b3 ff ff       	call   40d0 <buf_put>
    8d37:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d3e:	ff ff 7f 
    8d41:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d45:	0f 84 86 02 00 00    	je     8fd1 <fwp_write+0x951>
    8d4b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d50:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d54:	48 85 d2             	test   %rdx,%rdx
    8d57:	0f 84 ae 00 00 00    	je     8e0b <fwp_write+0x78b>
    8d5d:	8b 0a                	mov    (%rdx),%ecx
    8d5f:	83 f9 1c             	cmp    $0x1c,%ecx
    8d62:	0f 84 58 06 00 00    	je     93c0 <fwp_write+0xd40>
    8d68:	83 f9 1b             	cmp    $0x1b,%ecx
    8d6b:	0f 87 9a 00 00 00    	ja     8e0b <fwp_write+0x78b>
    8d71:	be 01 00 00 00       	mov    $0x1,%esi
    8d76:	48 d3 e6             	shl    %cl,%rsi
    8d79:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8d7f:	0f 85 4b 04 00 00    	jne    91d0 <fwp_write+0xb50>
    8d85:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8d8b:	0f 85 0f 04 00 00    	jne    91a0 <fwp_write+0xb20>
    8d91:	83 e6 21             	and    $0x21,%esi
    8d94:	74 75                	je     8e0b <fwp_write+0x78b>
    8d96:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8d9b:	48 85 ff             	test   %rdi,%rdi
    8d9e:	79 07                	jns    8da7 <fwp_write+0x727>
    8da0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8da4:	4c 01 ee             	add    %r13,%rsi
    8da7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8dab:	85 c9                	test   %ecx,%ecx
    8dad:	40 0f b6 f7          	movzbl %dil,%esi
    8db1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	31 c9                	xor    %ecx,%ecx
    8dc2:	48 89 df             	mov    %rbx,%rdi
    8dc5:	49 83 c5 01          	add    $0x1,%r13
    8dc9:	e8 b2 f8 ff ff       	call   8680 <fwp_write>
    8dce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8dd5:	ff ff 7f 
    8dd8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ddc:	49 39 d5             	cmp    %rdx,%r13
    8ddf:	0f 83 ec 01 00 00    	jae    8fd1 <fwp_write+0x951>
    8de5:	ba 02 00 00 00       	mov    $0x2,%edx
    8dea:	48 89 df             	mov    %rbx,%rdi
    8ded:	48 8d 35 61 24 00 00 	lea    0x2461(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8df4:	e8 d7 b2 ff ff       	call   40d0 <buf_put>
    8df9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8dfe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e02:	48 85 d2             	test   %rdx,%rdx
    8e05:	0f 85 52 ff ff ff    	jne    8d5d <fwp_write+0x6dd>
    8e0b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8e10:	48 85 ff             	test   %rdi,%rdi
    8e13:	0f 88 cf 05 00 00    	js     93e8 <fwp_write+0xd68>
    8e19:	48 8b 31             	mov    (%rcx),%rsi
    8e1c:	eb a2                	jmp    8dc0 <fwp_write+0x740>
    8e1e:	66 90                	xchg   %ax,%ax
    8e20:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e27:	00 
    8e28:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e2f:	00 00 
    8e31:	0f 85 1e fd ff ff    	jne    8b55 <fwp_write+0x4d5>
    8e37:	ba 08 00 00 00       	mov    $0x8,%edx
    8e3c:	48 8d 35 e2 23 00 00 	lea    0x23e2(%rip),%rsi        # b225 <_IO_stdin_used+0x225>
    8e43:	e9 4b fa ff ff       	jmp    8893 <fwp_write+0x213>
    8e48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e4f:	00 
    8e50:	89 e8                	mov    %ebp,%eax
    8e52:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8e59:	76 03                	jbe    8e5e <fwp_write+0x7de>
    8e5b:	8b 45 00             	mov    0x0(%rbp),%eax
    8e5e:	41 89 c6             	mov    %eax,%r14d
    8e61:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e66:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8e6b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8e6f:	4c 89 ef             	mov    %r13,%rdi
    8e72:	e8 c9 a5 ff ff       	call   3440 <strlen@plt>
    8e77:	4c 89 ee             	mov    %r13,%rsi
    8e7a:	48 89 df             	mov    %rbx,%rdi
    8e7d:	48 89 c2             	mov    %rax,%rdx
    8e80:	e8 4b b2 ff ff       	call   40d0 <buf_put>
    8e85:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e8a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8e8e:	85 f6                	test   %esi,%esi
    8e90:	0f 8e 80 f8 ff ff    	jle    8716 <fwp_write+0x96>
    8e96:	45 31 ed             	xor    %r13d,%r13d
    8e99:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e9e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8ea3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ea8:	ba 01 00 00 00       	mov    $0x1,%edx
    8ead:	4c 89 fe             	mov    %r15,%rsi
    8eb0:	48 89 04 24          	mov    %rax,(%rsp)
    8eb4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8eb9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8ebd:	48 89 df             	mov    %rbx,%rdi
    8ec0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8ec4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ec9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8ece:	e8 fd b1 ff ff       	call   40d0 <buf_put>
    8ed3:	41 8b 06             	mov    (%r14),%eax
    8ed6:	83 f8 0e             	cmp    $0xe,%eax
    8ed9:	0f 84 71 02 00 00    	je     9150 <fwp_write+0xad0>
    8edf:	83 f8 10             	cmp    $0x10,%eax
    8ee2:	0f 84 38 02 00 00    	je     9120 <fwp_write+0xaa0>
    8ee8:	83 f8 0a             	cmp    $0xa,%eax
    8eeb:	0f 84 7f 04 00 00    	je     9370 <fwp_write+0xcf0>
    8ef1:	0f 8f f9 00 00 00    	jg     8ff0 <fwp_write+0x970>
    8ef7:	83 f8 03             	cmp    $0x3,%eax
    8efa:	0f 8f 50 04 00 00    	jg     9350 <fwp_write+0xcd0>
    8f00:	85 c0                	test   %eax,%eax
    8f02:	78 10                	js     8f14 <fwp_write+0x894>
    8f04:	48 8b 04 24          	mov    (%rsp),%rax
    8f08:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f0c:	85 c0                	test   %eax,%eax
    8f0e:	0f 85 f9 00 00 00    	jne    900d <fwp_write+0x98d>
    8f14:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f19:	48 8b 34 24          	mov    (%rsp),%rsi
    8f1d:	31 c9                	xor    %ecx,%ecx
    8f1f:	48 89 df             	mov    %rbx,%rdi
    8f22:	e8 59 f7 ff ff       	call   8680 <fwp_write>
    8f27:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f2c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f31:	49 83 c5 01          	add    $0x1,%r13
    8f35:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8f39:	0f 8f 5f ff ff ff    	jg     8e9e <fwp_write+0x81e>
    8f3f:	e9 d2 f7 ff ff       	jmp    8716 <fwp_write+0x96>
    8f44:	0f 1f 40 00          	nopl   0x0(%rax)
    8f48:	ba 06 00 00 00       	mov    $0x6,%edx
    8f4d:	48 8d 35 f7 22 00 00 	lea    0x22f7(%rip),%rsi        # b24b <_IO_stdin_used+0x24b>
    8f54:	45 31 ed             	xor    %r13d,%r13d
    8f57:	e8 74 b1 ff ff       	call   40d0 <buf_put>
    8f5c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8f61:	75 19                	jne    8f7c <fwp_write+0x8fc>
    8f63:	eb 6c                	jmp    8fd1 <fwp_write+0x951>
    8f65:	0f 1f 00             	nopl   (%rax)
    8f68:	ba 02 00 00 00       	mov    $0x2,%edx
    8f6d:	48 8d 35 e1 22 00 00 	lea    0x22e1(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8f74:	48 89 df             	mov    %rbx,%rdi
    8f77:	e8 54 b1 ff ff       	call   40d0 <buf_put>
    8f7c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8f82:	b9 00 02 00 00       	mov    $0x200,%ecx
    8f87:	31 c0                	xor    %eax,%eax
    8f89:	49 83 c5 01          	add    $0x1,%r13
    8f8d:	4c 8d 05 be 22 00 00 	lea    0x22be(%rip),%r8        # b252 <_IO_stdin_used+0x252>
    8f94:	ba 02 00 00 00       	mov    $0x2,%edx
    8f99:	be 00 02 00 00       	mov    $0x200,%esi
    8f9e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fa5:	00 
    8fa6:	e8 f5 a3 ff ff       	call   33a0 <__snprintf_chk@plt>
    8fab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fb2:	00 
    8fb3:	e8 88 a4 ff ff       	call   3440 <strlen@plt>
    8fb8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fbf:	00 
    8fc0:	48 89 df             	mov    %rbx,%rdi
    8fc3:	48 89 c2             	mov    %rax,%rdx
    8fc6:	e8 05 b1 ff ff       	call   40d0 <buf_put>
    8fcb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8fcf:	72 97                	jb     8f68 <fwp_write+0x8e8>
    8fd1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fd6:	ba 01 00 00 00       	mov    $0x1,%edx
    8fdb:	48 89 df             	mov    %rbx,%rdi
    8fde:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8fe3:	e8 e8 b0 ff ff       	call   40d0 <buf_put>
    8fe8:	e9 29 f7 ff ff       	jmp    8716 <fwp_write+0x96>
    8fed:	0f 1f 00             	nopl   (%rax)
    8ff0:	83 f8 0b             	cmp    $0xb,%eax
    8ff3:	0f 85 1b ff ff ff    	jne    8f14 <fwp_write+0x894>
    8ff9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8ffe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9002:	83 e0 01             	and    $0x1,%eax
    9005:	85 c0                	test   %eax,%eax
    9007:	0f 84 07 ff ff ff    	je     8f14 <fwp_write+0x894>
    900d:	4c 89 fe             	mov    %r15,%rsi
    9010:	48 89 df             	mov    %rbx,%rdi
    9013:	ba 01 00 00 00       	mov    $0x1,%edx
    9018:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    901d:	e8 ae b0 ff ff       	call   40d0 <buf_put>
    9022:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9027:	48 8b 34 24          	mov    (%rsp),%rsi
    902b:	31 c9                	xor    %ecx,%ecx
    902d:	48 89 df             	mov    %rbx,%rdi
    9030:	e8 4b f6 ff ff       	call   8680 <fwp_write>
    9035:	ba 01 00 00 00       	mov    $0x1,%edx
    903a:	4c 89 fe             	mov    %r15,%rsi
    903d:	48 89 df             	mov    %rbx,%rdi
    9040:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9045:	e8 86 b0 ff ff       	call   40d0 <buf_put>
    904a:	e9 d8 fe ff ff       	jmp    8f27 <fwp_write+0x8a7>
    904f:	90                   	nop
    9050:	ba 01 00 00 00       	mov    $0x1,%edx
    9055:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    905a:	48 89 df             	mov    %rbx,%rdi
    905d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9062:	e8 69 b0 ff ff       	call   40d0 <buf_put>
    9067:	e9 aa f6 ff ff       	jmp    8716 <fwp_write+0x96>
    906c:	0f 1f 40 00          	nopl   0x0(%rax)
    9070:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9075:	ba 01 00 00 00       	mov    $0x1,%edx
    907a:	48 89 df             	mov    %rbx,%rdi
    907d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9082:	e8 49 b0 ff ff       	call   40d0 <buf_put>
    9087:	e9 8a f6 ff ff       	jmp    8716 <fwp_write+0x96>
    908c:	0f 1f 40 00          	nopl   0x0(%rax)
    9090:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9094:	48 8b 13             	mov    (%rbx),%rdx
    9097:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    909c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    90a0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    90a4:	e9 6d f6 ff ff       	jmp    8716 <fwp_write+0x96>
    90a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90b0:	ba 02 00 00 00       	mov    $0x2,%edx
    90b5:	48 8d 35 99 21 00 00 	lea    0x2199(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    90bc:	48 89 df             	mov    %rbx,%rdi
    90bf:	e8 0c b0 ff ff       	call   40d0 <buf_put>
    90c4:	e9 72 f8 ff ff       	jmp    893b <fwp_write+0x2bb>
    90c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90d0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    90d5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    90da:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    90de:	48 89 f7             	mov    %rsi,%rdi
    90e1:	48 89 34 24          	mov    %rsi,(%rsp)
    90e5:	e8 56 a3 ff ff       	call   3440 <strlen@plt>
    90ea:	48 8b 34 24          	mov    (%rsp),%rsi
    90ee:	48 89 df             	mov    %rbx,%rdi
    90f1:	48 89 c2             	mov    %rax,%rdx
    90f4:	e8 d7 af ff ff       	call   40d0 <buf_put>
    90f9:	ba 03 00 00 00       	mov    $0x3,%edx
    90fe:	48 8d 35 73 21 00 00 	lea    0x2173(%rip),%rsi        # b278 <_IO_stdin_used+0x278>
    9105:	48 89 df             	mov    %rbx,%rdi
    9108:	e8 c3 af ff ff       	call   40d0 <buf_put>
    910d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9112:	e9 35 f8 ff ff       	jmp    894c <fwp_write+0x2cc>
    9117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    911e:	00 00 
    9120:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9125:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9129:	48 85 ff             	test   %rdi,%rdi
    912c:	0f 84 e2 fd ff ff    	je     8f14 <fwp_write+0x894>
    9132:	48 8d 35 29 21 00 00 	lea    0x2129(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    9139:	e8 e2 a3 ff ff       	call   3520 <strcmp@plt>
    913e:	85 c0                	test   %eax,%eax
    9140:	0f 95 c0             	setne  %al
    9143:	0f b6 c0             	movzbl %al,%eax
    9146:	e9 c1 fd ff ff       	jmp    8f0c <fwp_write+0x88c>
    914b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9150:	31 c0                	xor    %eax,%eax
    9152:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9159:	00 
    915a:	0f 97 c0             	seta   %al
    915d:	e9 aa fd ff ff       	jmp    8f0c <fwp_write+0x88c>
    9162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9168:	48 89 df             	mov    %rbx,%rdi
    916b:	ba 02 00 00 00       	mov    $0x2,%edx
    9170:	48 8d 35 e8 20 00 00 	lea    0x20e8(%rip),%rsi        # b25f <_IO_stdin_used+0x25f>
    9177:	e8 54 af ff ff       	call   40d0 <buf_put>
    917c:	4c 89 e8             	mov    %r13,%rax
    917f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9184:	31 c9                	xor    %ecx,%ecx
    9186:	48 c1 e0 04          	shl    $0x4,%rax
    918a:	48 89 df             	mov    %rbx,%rdi
    918d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9192:	e8 e9 f4 ff ff       	call   8680 <fwp_write>
    9197:	e9 5e f6 ff ff       	jmp    87fa <fwp_write+0x17a>
    919c:	0f 1f 40 00          	nopl   0x0(%rax)
    91a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    91a5:	48 85 ff             	test   %rdi,%rdi
    91a8:	79 0c                	jns    91b6 <fwp_write+0xb36>
    91aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    91b1:	00 
    91b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    91b6:	48 63 3e             	movslq (%rsi),%rdi
    91b9:	83 f9 02             	cmp    $0x2,%ecx
    91bc:	89 fe                	mov    %edi,%esi
    91be:	48 0f 44 f7          	cmove  %rdi,%rsi
    91c2:	e9 f9 fb ff ff       	jmp    8dc0 <fwp_write+0x740>
    91c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91ce:	00 00 
    91d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    91d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    91da:	48 85 ff             	test   %rdi,%rdi
    91dd:	0f 88 0f 03 00 00    	js     94f2 <fwp_write+0xe72>
    91e3:	49 0f bf 38          	movswq (%r8),%rdi
    91e7:	83 f9 01             	cmp    $0x1,%ecx
    91ea:	0f b7 f7             	movzwl %di,%esi
    91ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    91f1:	e9 ca fb ff ff       	jmp    8dc0 <fwp_write+0x740>
    91f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91fd:	00 00 00 
    9200:	ba 01 00 00 00       	mov    $0x1,%edx
    9205:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    920a:	48 83 c5 08          	add    $0x8,%rbp
    920e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9213:	e8 b8 ae ff ff       	call   40d0 <buf_put>
    9218:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    921d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9222:	4d 85 ed             	test   %r13,%r13
    9225:	75 46                	jne    926d <fwp_write+0xbed>
    9227:	e9 04 01 00 00       	jmp    9330 <fwp_write+0xcb0>
    922c:	0f 1f 40 00          	nopl   0x0(%rax)
    9230:	41 80 f9 09          	cmp    $0x9,%r9b
    9234:	0f 84 d6 00 00 00    	je     9310 <fwp_write+0xc90>
    923a:	41 80 f9 0a          	cmp    $0xa,%r9b
    923e:	0f 85 9c 00 00 00    	jne    92e0 <fwp_write+0xc60>
    9244:	ba 02 00 00 00       	mov    $0x2,%edx
    9249:	48 8d 35 eb 1f 00 00 	lea    0x1feb(%rip),%rsi        # b23b <_IO_stdin_used+0x23b>
    9250:	48 89 df             	mov    %rbx,%rdi
    9253:	e8 78 ae ff ff       	call   40d0 <buf_put>
    9258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    925f:	00 
    9260:	48 83 c5 01          	add    $0x1,%rbp
    9264:	49 39 ec             	cmp    %rbp,%r12
    9267:	0f 84 c3 00 00 00    	je     9330 <fwp_write+0xcb0>
    926d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9272:	41 80 f9 0d          	cmp    $0xd,%r9b
    9276:	74 28                	je     92a0 <fwp_write+0xc20>
    9278:	7e b6                	jle    9230 <fwp_write+0xbb0>
    927a:	41 80 f9 22          	cmp    $0x22,%r9b
    927e:	74 40                	je     92c0 <fwp_write+0xc40>
    9280:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9284:	75 5a                	jne    92e0 <fwp_write+0xc60>
    9286:	ba 02 00 00 00       	mov    $0x2,%edx
    928b:	48 8d 35 a6 1f 00 00 	lea    0x1fa6(%rip),%rsi        # b238 <_IO_stdin_used+0x238>
    9292:	48 89 df             	mov    %rbx,%rdi
    9295:	e8 36 ae ff ff       	call   40d0 <buf_put>
    929a:	eb c4                	jmp    9260 <fwp_write+0xbe0>
    929c:	0f 1f 40 00          	nopl   0x0(%rax)
    92a0:	ba 02 00 00 00       	mov    $0x2,%edx
    92a5:	48 8d 35 95 1f 00 00 	lea    0x1f95(%rip),%rsi        # b241 <_IO_stdin_used+0x241>
    92ac:	48 89 df             	mov    %rbx,%rdi
    92af:	e8 1c ae ff ff       	call   40d0 <buf_put>
    92b4:	eb aa                	jmp    9260 <fwp_write+0xbe0>
    92b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92bd:	00 00 00 
    92c0:	ba 02 00 00 00       	mov    $0x2,%edx
    92c5:	48 8d 35 69 1f 00 00 	lea    0x1f69(%rip),%rsi        # b235 <_IO_stdin_used+0x235>
    92cc:	48 89 df             	mov    %rbx,%rdi
    92cf:	e8 fc ad ff ff       	call   40d0 <buf_put>
    92d4:	eb 8a                	jmp    9260 <fwp_write+0xbe0>
    92d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92dd:	00 00 00 
    92e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    92e4:	0f 86 2e 01 00 00    	jbe    9418 <fwp_write+0xd98>
    92ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    92ee:	0f 84 24 01 00 00    	je     9418 <fwp_write+0xd98>
    92f4:	ba 01 00 00 00       	mov    $0x1,%edx
    92f9:	4c 89 fe             	mov    %r15,%rsi
    92fc:	48 89 df             	mov    %rbx,%rdi
    92ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9304:	e8 c7 ad ff ff       	call   40d0 <buf_put>
    9309:	e9 52 ff ff ff       	jmp    9260 <fwp_write+0xbe0>
    930e:	66 90                	xchg   %ax,%ax
    9310:	ba 02 00 00 00       	mov    $0x2,%edx
    9315:	48 8d 35 22 1f 00 00 	lea    0x1f22(%rip),%rsi        # b23e <_IO_stdin_used+0x23e>
    931c:	48 89 df             	mov    %rbx,%rdi
    931f:	e8 ac ad ff ff       	call   40d0 <buf_put>
    9324:	e9 37 ff ff ff       	jmp    9260 <fwp_write+0xbe0>
    9329:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9330:	ba 01 00 00 00       	mov    $0x1,%edx
    9335:	4c 89 fe             	mov    %r15,%rsi
    9338:	48 89 df             	mov    %rbx,%rdi
    933b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9340:	e8 8b ad ff ff       	call   40d0 <buf_put>
    9345:	e9 cc f3 ff ff       	jmp    8716 <fwp_write+0x96>
    934a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9350:	83 f8 04             	cmp    $0x4,%eax
    9353:	0f 85 bb fb ff ff    	jne    8f14 <fwp_write+0x894>
    9359:	48 8b 04 24          	mov    (%rsp),%rax
    935d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9361:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9366:	48 c1 e8 3f          	shr    $0x3f,%rax
    936a:	e9 96 fc ff ff       	jmp    9005 <fwp_write+0x985>
    936f:	90                   	nop
    9370:	8b 0c 24             	mov    (%rsp),%ecx
    9373:	31 c0                	xor    %eax,%eax
    9375:	85 c9                	test   %ecx,%ecx
    9377:	0f 98 c0             	sets   %al
    937a:	e9 86 fc ff ff       	jmp    9005 <fwp_write+0x985>
    937f:	90                   	nop
    9380:	48 f7 d8             	neg    %rax
    9383:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    938a:	00 
    938b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9392:	2d 
    9393:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    939a:	00 
    939b:	48 83 d2 00          	adc    $0x0,%rdx
    939f:	48 89 c6             	mov    %rax,%rsi
    93a2:	48 f7 da             	neg    %rdx
    93a5:	e8 76 a6 ff ff       	call   3a20 <fwp_fmt_u128>
    93aa:	e9 51 f3 ff ff       	jmp    8700 <fwp_write+0x80>
    93af:	90                   	nop
    93b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    93b5:	e9 c3 f5 ff ff       	jmp    897d <fwp_write+0x2fd>
    93ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93c0:	4c 89 e9             	mov    %r13,%rcx
    93c3:	48 c1 e1 04          	shl    $0x4,%rcx
    93c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    93cc:	48 85 ff             	test   %rdi,%rdi
    93cf:	0f 89 eb f9 ff ff    	jns    8dc0 <fwp_write+0x740>
    93d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93d9:	48 89 ce             	mov    %rcx,%rsi
    93dc:	e9 df f9 ff ff       	jmp    8dc0 <fwp_write+0x740>
    93e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    93ef:	00 
    93f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93f4:	e9 20 fa ff ff       	jmp    8e19 <fwp_write+0x799>
    93f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9400:	ba 02 00 00 00       	mov    $0x2,%edx
    9405:	48 8d 35 f4 1d 00 00 	lea    0x1df4(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    940c:	e9 2d f7 ff ff       	jmp    8b3e <fwp_write+0x4be>
    9411:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9418:	4c 8d 05 25 1e 00 00 	lea    0x1e25(%rip),%r8        # b244 <_IO_stdin_used+0x244>
    941f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9424:	31 c0                	xor    %eax,%eax
    9426:	ba 02 00 00 00       	mov    $0x2,%edx
    942b:	be 10 00 00 00       	mov    $0x10,%esi
    9430:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9437:	00 
    9438:	e8 63 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    943d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9444:	00 
    9445:	e8 f6 9f ff ff       	call   3440 <strlen@plt>
    944a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9451:	00 
    9452:	48 89 df             	mov    %rbx,%rdi
    9455:	48 89 c2             	mov    %rax,%rdx
    9458:	e8 73 ac ff ff       	call   40d0 <buf_put>
    945d:	e9 fe fd ff ff       	jmp    9260 <fwp_write+0xbe0>
    9462:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9468:	66 0f ef c0          	pxor   %xmm0,%xmm0
    946c:	48 8d 35 87 1d 00 00 	lea    0x1d87(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    9473:	48 8d 05 7f 1d 00 00 	lea    0x1d7f(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    947a:	4c 89 e7             	mov    %r12,%rdi
    947d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9481:	48 0f 46 f0          	cmovbe %rax,%rsi
    9485:	e8 56 9f ff ff       	call   33e0 <strcpy@plt>
    948a:	e9 71 f2 ff ff       	jmp    8700 <fwp_write+0x80>
    948f:	90                   	nop
    9490:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9494:	48 8d 35 5f 1d 00 00 	lea    0x1d5f(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    949b:	48 8d 05 57 1d 00 00 	lea    0x1d57(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    94a2:	0f 2f c8             	comiss %xmm0,%xmm1
    94a5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94ac:	00 
    94ad:	4c 89 e7             	mov    %r12,%rdi
    94b0:	48 0f 46 f0          	cmovbe %rax,%rsi
    94b4:	e8 27 9f ff ff       	call   33e0 <strcpy@plt>
    94b9:	e9 42 f2 ff ff       	jmp    8700 <fwp_write+0x80>
    94be:	66 90                	xchg   %ax,%ax
    94c0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    94c5:	45 85 c0             	test   %r8d,%r8d
    94c8:	75 34                	jne    94fe <fwp_write+0xe7e>
    94ca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    94d1:	00 
    94d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    94d9:	00 00 
    94db:	0f 85 74 f6 ff ff    	jne    8b55 <fwp_write+0x4d5>
    94e1:	ba 02 00 00 00       	mov    $0x2,%edx
    94e6:	48 8d 35 88 1d 00 00 	lea    0x1d88(%rip),%rsi        # b275 <_IO_stdin_used+0x275>
    94ed:	e9 a1 f3 ff ff       	jmp    8893 <fwp_write+0x213>
    94f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    94f6:	49 89 f0             	mov    %rsi,%r8
    94f9:	e9 e5 fc ff ff       	jmp    91e3 <fwp_write+0xb63>
    94fe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9503:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9508:	85 ff                	test   %edi,%edi
    950a:	0f 84 fa f3 ff ff    	je     890a <fwp_write+0x28a>
    9510:	ba 01 00 00 00       	mov    $0x1,%edx
    9515:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    951a:	48 89 df             	mov    %rbx,%rdi
    951d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9522:	e8 a9 ab ff ff       	call   40d0 <buf_put>
    9527:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    952c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9531:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9537:	85 c0                	test   %eax,%eax
    9539:	0f 8f f0 f3 ff ff    	jg     892f <fwp_write+0x2af>
    953f:	e9 34 f4 ff ff       	jmp    8978 <fwp_write+0x2f8>
    9544:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9548:	49 89 c5             	mov    %rax,%r13
    954b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9550:	49 89 c4             	mov    %rax,%r12
    9553:	49 c1 fd 3f          	sar    $0x3f,%r13
    9557:	4c 09 e8             	or     %r13,%rax
    955a:	0f 84 a7 00 00 00    	je     9607 <fwp_write+0xf87>
    9560:	48 8d 2d 59 3d 00 00 	lea    0x3d59(%rip),%rbp        # d2c0 <units.0>
    9567:	4d 89 e7             	mov    %r12,%r15
    956a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    956e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9573:	4c 89 ff             	mov    %r15,%rdi
    9576:	4c 89 ee             	mov    %r13,%rsi
    9579:	44 89 0c 24          	mov    %r9d,(%rsp)
    957d:	48 99                	cqto
    957f:	48 89 d1             	mov    %rdx,%rcx
    9582:	48 89 c2             	mov    %rax,%rdx
    9585:	e8 56 10 00 00       	call   a5e0 <__divmodti4>
    958a:	44 8b 0c 24          	mov    (%rsp),%r9d
    958e:	48 89 c1             	mov    %rax,%rcx
    9591:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9596:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    959b:	0f 84 94 00 00 00    	je     9635 <fwp_write+0xfb5>
    95a1:	41 83 c1 01          	add    $0x1,%r9d
    95a5:	48 83 c5 10          	add    $0x10,%rbp
    95a9:	41 83 f9 05          	cmp    $0x5,%r9d
    95ad:	75 bb                	jne    956a <fwp_write+0xeea>
    95af:	4d 85 ed             	test   %r13,%r13
    95b2:	79 53                	jns    9607 <fwp_write+0xf87>
    95b4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95b9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95be:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95c3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95c8:	48 99                	cqto
    95ca:	48 f7 d8             	neg    %rax
    95cd:	48 83 d2 00          	adc    $0x0,%rdx
    95d1:	48 89 c6             	mov    %rax,%rsi
    95d4:	48 f7 da             	neg    %rdx
    95d7:	e8 44 a4 ff ff       	call   3a20 <fwp_fmt_u128>
    95dc:	49 89 e8             	mov    %rbp,%r8
    95df:	ba 00 02 00 00       	mov    $0x200,%edx
    95e4:	be 02 00 00 00       	mov    $0x2,%esi
    95e9:	31 c0                	xor    %eax,%eax
    95eb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95f2:	00 
    95f3:	48 8d 0d 76 1c 00 00 	lea    0x1c76(%rip),%rcx        # b270 <_IO_stdin_used+0x270>
    95fa:	4c 89 e7             	mov    %r12,%rdi
    95fd:	e8 be a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    9602:	e9 f9 f0 ff ff       	jmp    8700 <fwp_write+0x80>
    9607:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    960c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9611:	31 d2                	xor    %edx,%edx
    9613:	48 89 ef             	mov    %rbp,%rdi
    9616:	e8 05 a4 ff ff       	call   3a20 <fwp_fmt_u128>
    961b:	eb bf                	jmp    95dc <fwp_write+0xf5c>
    961d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9624:	4e 61 4e 00 
    9628:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    962f:	00 
    9630:	e9 cb f0 ff ff       	jmp    8700 <fwp_write+0x80>
    9635:	44 89 0c 24          	mov    %r9d,(%rsp)
    9639:	48 89 c8             	mov    %rcx,%rax
    963c:	48 85 d2             	test   %rdx,%rdx
    963f:	78 51                	js     9692 <fwp_write+0x1012>
    9641:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9646:	48 89 c6             	mov    %rax,%rsi
    9649:	48 89 ef             	mov    %rbp,%rdi
    964c:	e8 cf a3 ff ff       	call   3a20 <fwp_fmt_u128>
    9651:	44 8b 0c 24          	mov    (%rsp),%r9d
    9655:	49 63 c1             	movslq %r9d,%rax
    9658:	49 89 e8             	mov    %rbp,%r8
    965b:	ba 00 02 00 00       	mov    $0x200,%edx
    9660:	be 02 00 00 00       	mov    $0x2,%esi
    9665:	48 c1 e0 04          	shl    $0x4,%rax
    9669:	48 8d 3d 50 3c 00 00 	lea    0x3c50(%rip),%rdi        # d2c0 <units.0>
    9670:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9677:	00 
    9678:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    967c:	48 8d 0d e8 1b 00 00 	lea    0x1be8(%rip),%rcx        # b26b <_IO_stdin_used+0x26b>
    9683:	4c 89 e7             	mov    %r12,%rdi
    9686:	31 c0                	xor    %eax,%eax
    9688:	e8 33 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    968d:	e9 6e f0 ff ff       	jmp    8700 <fwp_write+0x80>
    9692:	48 f7 d8             	neg    %rax
    9695:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    969a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    969f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96a4:	48 83 d2 00          	adc    $0x0,%rdx
    96a8:	48 89 c6             	mov    %rax,%rsi
    96ab:	48 f7 da             	neg    %rdx
    96ae:	e8 6d a3 ff ff       	call   3a20 <fwp_fmt_u128>
    96b3:	44 8b 0c 24          	mov    (%rsp),%r9d
    96b7:	eb 9c                	jmp    9655 <fwp_write+0xfd5>
    96b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000096c0 <fwp_main_thread>:
    96c0:	f3 0f 1e fa          	endbr64
    96c4:	41 57                	push   %r15
    96c6:	41 56                	push   %r14
    96c8:	41 55                	push   %r13
    96ca:	41 54                	push   %r12
    96cc:	55                   	push   %rbp
    96cd:	53                   	push   %rbx
    96ce:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    96d5:	8b 3d 09 f5 05 00    	mov    0x5f509(%rip),%edi        # 68be4 <fwp_heap+0x13a4>
    96db:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    96e2:	00 00 
    96e4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    96eb:	00 
    96ec:	31 c0                	xor    %eax,%eax
    96ee:	85 ff                	test   %edi,%edi
    96f0:	0f 84 72 07 00 00    	je     9e68 <fwp_main_thread+0x7a8>
    96f6:	8b 35 ec f4 05 00    	mov    0x5f4ec(%rip),%esi        # 68be8 <fwp_heap+0x13a8>
    96fc:	85 f6                	test   %esi,%esi
    96fe:	0f 85 4c 07 00 00    	jne    9e50 <fwp_main_thread+0x790>
    9704:	48 8d 05 95 59 00 00 	lea    0x5995(%rip),%rax        # f0a0 <alt.9>
    970b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9710:	31 f6                	xor    %esi,%esi
    9712:	48 c7 05 c3 da 05 00 	movq   $0x40000000,0x5dac3(%rip)        # 671e0 <fwp_main_stack_size>
    9719:	00 00 00 40 
    971d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9722:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9727:	48 89 c7             	mov    %rax,%rdi
    972a:	48 89 2d b7 da 05 00 	mov    %rbp,0x5dab7(%rip)        # 671e8 <fwp_main_stack_top>
    9731:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9738:	01 00 
    973a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9741:	00 
    9742:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9747:	e8 54 9f ff ff       	call   36a0 <sigaltstack@plt>
    974c:	85 c0                	test   %eax,%eax
    974e:	0f 85 43 0e 00 00    	jne    a597 <fwp_main_thread+0xed7>
    9754:	31 c0                	xor    %eax,%eax
    9756:	b9 12 00 00 00       	mov    $0x12,%ecx
    975b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9762:	00 
    9763:	f3 48 ab             	rep stos %rax,(%rdi)
    9766:	48 8d 05 b3 a5 ff ff 	lea    -0x5a4d(%rip),%rax        # 3d20 <fwp_segv>
    976d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9774:	00 
    9775:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    977c:	04 00 00 08 
    9780:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9787:	00 
    9788:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    978f:	00 
    9790:	e8 cb 9d ff ff       	call   3560 <sigemptyset@plt>
    9795:	85 c0                	test   %eax,%eax
    9797:	0f 85 fa 0d 00 00    	jne    a597 <fwp_main_thread+0xed7>
    979d:	31 d2                	xor    %edx,%edx
    979f:	48 89 de             	mov    %rbx,%rsi
    97a2:	bf 0b 00 00 00       	mov    $0xb,%edi
    97a7:	e8 44 9c ff ff       	call   33f0 <sigaction@plt>
    97ac:	85 c0                	test   %eax,%eax
    97ae:	0f 85 e3 0d 00 00    	jne    a597 <fwp_main_thread+0xed7>
    97b4:	31 d2                	xor    %edx,%edx
    97b6:	48 89 de             	mov    %rbx,%rsi
    97b9:	bf 07 00 00 00       	mov    $0x7,%edi
    97be:	e8 2d 9c ff ff       	call   33f0 <sigaction@plt>
    97c3:	85 c0                	test   %eax,%eax
    97c5:	0f 85 cc 0d 00 00    	jne    a597 <fwp_main_thread+0xed7>
    97cb:	48 8b 05 8e f4 05 00 	mov    0x5f48e(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    97d2:	48 85 c0             	test   %rax,%rax
    97d5:	0f 88 35 06 00 00    	js     9e10 <fwp_main_thread+0x750>
    97db:	66 0f ef c0          	pxor   %xmm0,%xmm0
    97df:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    97e4:	48 8d 3d 15 aa ff ff 	lea    -0x55eb(%rip),%rdi        # 4200 <ad_raw_report>
    97eb:	f2 0f 11 05 f5 fc 05 	movsd  %xmm0,0x5fcf5(%rip)        # 694e8 <iteration_start_charge>
    97f2:	00 
    97f3:	c7 05 0b fd 05 00 01 	movl   $0x1,0x5fd0b(%rip)        # 69508 <iteration_active>
    97fa:	00 00 00 
    97fd:	e8 ee 0f 00 00       	call   a7f0 <atexit>
    9802:	85 c0                	test   %eax,%eax
    9804:	0f 85 aa 0d 00 00    	jne    a5b4 <fwp_main_thread+0xef4>
    980a:	8b 0d 78 58 00 00    	mov    0x5878(%rip),%ecx        # f088 <st.7>
    9810:	85 c9                	test   %ecx,%ecx
    9812:	0f 84 60 06 00 00    	je     9e78 <fwp_main_thread+0x7b8>
    9818:	48 8b 2d 01 e0 05 00 	mov    0x5e001(%rip),%rbp        # 67820 <fwp_cur>
    981f:	48 85 ed             	test   %rbp,%rbp
    9822:	0f 84 08 03 00 00    	je     9b30 <fwp_main_thread+0x470>
    9828:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    982d:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9831:	48 89 eb             	mov    %rbp,%rbx
    9834:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9839:	0f 84 41 01 00 00    	je     9980 <fwp_main_thread+0x2c0>
    983f:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9844:	0f 84 16 02 00 00    	je     9a60 <fwp_main_thread+0x3a0>
    984a:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    984e:	0f 84 fc 01 00 00    	je     9a50 <fwp_main_thread+0x390>
    9854:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9858:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    985c:	0f 85 7e 02 00 00    	jne    9ae0 <fwp_main_thread+0x420>
    9862:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9866:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    986d:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9871:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9878:	00 00 00 00 
    987c:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9883:	48 85 d2             	test   %rdx,%rdx
    9886:	74 07                	je     988f <fwp_main_thread+0x1cf>
    9888:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    988f:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9893:	48 85 c0             	test   %rax,%rax
    9896:	74 34                	je     98cc <fwp_main_thread+0x20c>
    9898:	48 89 43 68          	mov    %rax,0x68(%rbx)
    989c:	48 8b 05 55 df 05 00 	mov    0x5df55(%rip),%rax        # 677f8 <fwp_timers>
    98a3:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    98a7:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    98ae:	00 00 00 00 
    98b2:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    98b9:	48 85 c0             	test   %rax,%rax
    98bc:	74 07                	je     98c5 <fwp_main_thread+0x205>
    98be:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    98c5:	48 89 1d 2c df 05 00 	mov    %rbx,0x5df2c(%rip)        # 677f8 <fwp_timers>
    98cc:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    98d0:	e8 1b de ff ff       	call   76f0 <fwp_block>
    98d5:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    98dc:	48 85 c9             	test   %rcx,%rcx
    98df:	74 47                	je     9928 <fwp_main_thread+0x268>
    98e1:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    98e8:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    98ef:	48 85 d2             	test   %rdx,%rdx
    98f2:	0f 84 28 02 00 00    	je     9b20 <fwp_main_thread+0x460>
    98f8:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    98ff:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9906:	48 85 c0             	test   %rax,%rax
    9909:	74 07                	je     9912 <fwp_main_thread+0x252>
    990b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9912:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9919:	00 00 00 00 
    991d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9921:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9928:	48 8b 0d f1 de 05 00 	mov    0x5def1(%rip),%rcx        # 67820 <fwp_cur>
    992f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9933:	0f 84 97 01 00 00    	je     9ad0 <fwp_main_thread+0x410>
    9939:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9940:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9947:	48 85 d2             	test   %rdx,%rdx
    994a:	0f 84 20 04 00 00    	je     9d70 <fwp_main_thread+0x6b0>
    9950:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9957:	48 85 c0             	test   %rax,%rax
    995a:	74 07                	je     9963 <fwp_main_thread+0x2a3>
    995c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9963:	66 0f ef db          	pxor   %xmm3,%xmm3
    9967:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    996b:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9972:	48 89 cb             	mov    %rcx,%rbx
    9975:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    997a:	0f 85 bf fe ff ff    	jne    983f <fwp_main_thread+0x17f>
    9980:	48 83 3d 30 fb 05 00 	cmpq   $0x0,0x5fb30(%rip)        # 694b8 <fwp_state_len>
    9987:	00 
    9988:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    998c:	0f 84 10 04 00 00    	je     9da2 <fwp_main_thread+0x6e2>
    9992:	48 39 1d 7f de 05 00 	cmp    %rbx,0x5de7f(%rip)        # 67818 <fwp_root>
    9999:	c7 05 fd 56 01 00 00 	movl   $0x0,0x156fd(%rip)        # 1f0a0 <fwp_exit_code>
    99a0:	00 00 00 
    99a3:	0f 85 28 0c 00 00    	jne    a5d1 <fwp_main_thread+0xf11>
    99a9:	48 85 db             	test   %rbx,%rbx
    99ac:	0f 84 a4 01 00 00    	je     9b56 <fwp_main_thread+0x496>
    99b2:	48 8b 15 2f de 05 00 	mov    0x5de2f(%rip),%rdx        # 677e8 <fwp_tasks_active>
    99b9:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    99bd:	48 85 d2             	test   %rdx,%rdx
    99c0:	0f 84 90 01 00 00    	je     9b56 <fwp_main_thread+0x496>
    99c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99cd:	00 00 00 
    99d0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    99d4:	75 08                	jne    99de <fwp_main_thread+0x31e>
    99d6:	48 89 d7             	mov    %rdx,%rdi
    99d9:	e8 32 a7 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    99de:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    99e5:	48 85 d2             	test   %rdx,%rdx
    99e8:	75 e6                	jne    99d0 <fwp_main_thread+0x310>
    99ea:	eb 31                	jmp    9a1d <fwp_main_thread+0x35d>
    99ec:	0f 1f 40 00          	nopl   0x0(%rax)
    99f0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    99f7:	48 89 1d 02 de 05 00 	mov    %rbx,0x5de02(%rip)        # 67800 <fwp_ready_tail>
    99fe:	e8 ed dc ff ff       	call   76f0 <fwp_block>
    9a03:	e8 d8 da ff ff       	call   74e0 <fwp_free_zombie>
    9a08:	48 83 3d d8 dd 05 00 	cmpq   $0x0,0x5ddd8(%rip)        # 677e8 <fwp_tasks_active>
    9a0f:	00 
    9a10:	0f 84 40 01 00 00    	je     9b56 <fwp_main_thread+0x496>
    9a16:	48 8b 1d fb dd 05 00 	mov    0x5ddfb(%rip),%rbx        # 67818 <fwp_root>
    9a1d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9a21:	75 db                	jne    99fe <fwp_main_thread+0x33e>
    9a23:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9a27:	75 d5                	jne    99fe <fwp_main_thread+0x33e>
    9a29:	48 8b 05 d0 dd 05 00 	mov    0x5ddd0(%rip),%rax        # 67800 <fwp_ready_tail>
    9a30:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9a34:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9a3b:	00 00 00 00 
    9a3f:	48 85 c0             	test   %rax,%rax
    9a42:	75 ac                	jne    99f0 <fwp_main_thread+0x330>
    9a44:	48 89 1d bd dd 05 00 	mov    %rbx,0x5ddbd(%rip)        # 67808 <fwp_ready_head>
    9a4b:	eb aa                	jmp    99f7 <fwp_main_thread+0x337>
    9a4d:	0f 1f 00             	nopl   (%rax)
    9a50:	e8 4b ab ff ff       	call   45a0 <fwp_now_ns>
    9a55:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9a59:	0f 8d 21 03 00 00    	jge    9d80 <fwp_main_thread+0x6c0>
    9a5f:	90                   	nop
    9a60:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9a64:	0f 85 ea fd ff ff    	jne    9854 <fwp_main_thread+0x194>
    9a6a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9a6e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9a72:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9a76:	0f 85 ea fd ff ff    	jne    9866 <fwp_main_thread+0x1a6>
    9a7c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9a80:	48 85 c9             	test   %rcx,%rcx
    9a83:	0f 84 dd fd ff ff    	je     9866 <fwp_main_thread+0x1a6>
    9a89:	48 39 c8             	cmp    %rcx,%rax
    9a8c:	48 89 ce             	mov    %rcx,%rsi
    9a8f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9a96:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9a9a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9aa1:	00 00 00 00 
    9aa5:	48 0f 4e f0          	cmovle %rax,%rsi
    9aa9:	48 85 c0             	test   %rax,%rax
    9aac:	48 89 c8             	mov    %rcx,%rax
    9aaf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9ab6:	48 0f 45 c6          	cmovne %rsi,%rax
    9aba:	48 85 d2             	test   %rdx,%rdx
    9abd:	74 07                	je     9ac6 <fwp_main_thread+0x406>
    9abf:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9ac6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9aca:	e9 c9 fd ff ff       	jmp    9898 <fwp_main_thread+0x1d8>
    9acf:	90                   	nop
    9ad0:	48 89 cb             	mov    %rcx,%rbx
    9ad3:	e9 5c fd ff ff       	jmp    9834 <fwp_main_thread+0x174>
    9ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9adf:	00 
    9ae0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9ae4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9aeb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9af2:	00 00 00 00 
    9af6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9afd:	48 85 c0             	test   %rax,%rax
    9b00:	0f 84 6a 09 00 00    	je     a470 <fwp_main_thread+0xdb0>
    9b06:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9b0d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9b11:	e9 b6 fd ff ff       	jmp    98cc <fwp_main_thread+0x20c>
    9b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b1d:	00 00 00 
    9b20:	48 89 01             	mov    %rax,(%rcx)
    9b23:	e9 de fd ff ff       	jmp    9906 <fwp_main_thread+0x246>
    9b28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b2f:	00 
    9b30:	48 83 3d 80 f9 05 00 	cmpq   $0x0,0x5f980(%rip)        # 694b8 <fwp_state_len>
    9b37:	00 
    9b38:	0f 84 62 02 00 00    	je     9da0 <fwp_main_thread+0x6e0>
    9b3e:	48 83 3d d2 dc 05 00 	cmpq   $0x0,0x5dcd2(%rip)        # 67818 <fwp_root>
    9b45:	00 
    9b46:	c7 05 50 55 01 00 00 	movl   $0x0,0x15550(%rip)        # 1f0a0 <fwp_exit_code>
    9b4d:	00 00 00 
    9b50:	0f 85 76 0a 00 00    	jne    a5cc <fwp_main_thread+0xf0c>
    9b56:	e8 85 d9 ff ff       	call   74e0 <fwp_free_zombie>
    9b5b:	48 83 3d a5 dc 05 00 	cmpq   $0x0,0x5dca5(%rip)        # 67808 <fwp_ready_head>
    9b62:	00 
    9b63:	0f 85 c2 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b69:	48 83 3d 87 dc 05 00 	cmpq   $0x0,0x5dc87(%rip)        # 677f8 <fwp_timers>
    9b70:	00 
    9b71:	0f 85 b4 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b77:	8b 05 77 d6 05 00    	mov    0x5d677(%rip),%eax        # 671f4 <fwp_stack_pool_n>
    9b7d:	85 c0                	test   %eax,%eax
    9b7f:	74 3c                	je     9bbd <fwp_main_thread+0x4fd>
    9b81:	83 e8 01             	sub    $0x1,%eax
    9b84:	4c 8d 25 75 d6 05 00 	lea    0x5d675(%rip),%r12        # 67200 <fwp_stack_pool>
    9b8b:	48 63 d8             	movslq %eax,%rbx
    9b8e:	89 c0                	mov    %eax,%eax
    9b90:	48 89 da             	mov    %rbx,%rdx
    9b93:	48 29 c2             	sub    %rax,%rdx
    9b96:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ba0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9ba4:	89 1d 4a d6 05 00    	mov    %ebx,0x5d64a(%rip)        # 671f4 <fwp_stack_pool_n>
    9baa:	be 00 00 00 10       	mov    $0x10000000,%esi
    9baf:	48 83 eb 01          	sub    $0x1,%rbx
    9bb3:	e8 08 9a ff ff       	call   35c0 <munmap@plt>
    9bb8:	48 39 dd             	cmp    %rbx,%rbp
    9bbb:	75 e3                	jne    9ba0 <fwp_main_thread+0x4e0>
    9bbd:	8b 3d 4d 54 00 00    	mov    0x544d(%rip),%edi        # f010 <fwp_epfd>
    9bc3:	85 ff                	test   %edi,%edi
    9bc5:	78 05                	js     9bcc <fwp_main_thread+0x50c>
    9bc7:	e8 f4 98 ff ff       	call   34c0 <close@plt>
    9bcc:	4c 8b 25 2d d8 05 00 	mov    0x5d82d(%rip),%r12        # 67400 <fwp_nfdws>
    9bd3:	48 8b 2d 2e d8 05 00 	mov    0x5d82e(%rip),%rbp        # 67408 <fwp_fdws>
    9bda:	31 db                	xor    %ebx,%ebx
    9bdc:	c7 05 2a 54 00 00 ff 	movl   $0xffffffff,0x542a(%rip)        # f010 <fwp_epfd>
    9be3:	ff ff ff 
    9be6:	4d 85 e4             	test   %r12,%r12
    9be9:	74 32                	je     9c1d <fwp_main_thread+0x55d>
    9beb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9bf0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9bf5:	48 85 ff             	test   %rdi,%rdi
    9bf8:	74 1a                	je     9c14 <fwp_main_thread+0x554>
    9bfa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9bfe:	0f 85 27 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9c04:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9c09:	0f 85 1c 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9c0f:	e8 3c be ff ff       	call   5a50 <fwp_mem_free>
    9c14:	48 83 c3 01          	add    $0x1,%rbx
    9c18:	49 39 dc             	cmp    %rbx,%r12
    9c1b:	75 d3                	jne    9bf0 <fwp_main_thread+0x530>
    9c1d:	48 89 ef             	mov    %rbp,%rdi
    9c20:	e8 2b be ff ff       	call   5a50 <fwp_mem_free>
    9c25:	48 8b 15 ec db 05 00 	mov    0x5dbec(%rip),%rdx        # 67818 <fwp_root>
    9c2c:	48 c7 05 d1 d7 05 00 	movq   $0x0,0x5d7d1(%rip)        # 67408 <fwp_fdws>
    9c33:	00 00 00 00 
    9c37:	48 c7 05 be d7 05 00 	movq   $0x0,0x5d7be(%rip)        # 67400 <fwp_nfdws>
    9c3e:	00 00 00 00 
    9c42:	48 85 d2             	test   %rdx,%rdx
    9c45:	74 4e                	je     9c95 <fwp_main_thread+0x5d5>
    9c47:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9c4c:	0f 85 d9 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9c52:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9c59:	00 
    9c5a:	0f 85 cb 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9c60:	48 83 3d 50 f8 05 00 	cmpq   $0x0,0x5f850(%rip)        # 694b8 <fwp_state_len>
    9c67:	00 
    9c68:	0f 85 bd 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9c6e:	48 83 3d 32 f8 05 00 	cmpq   $0x0,0x5f832(%rip)        # 694a8 <fwp_state_owners>
    9c75:	00 
    9c76:	0f 85 af 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9c7c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9c81:	31 c0                	xor    %eax,%eax
    9c83:	48 8d 3d 96 d7 05 00 	lea    0x5d796(%rip),%rdi        # 67420 <fwp_root_context>
    9c8a:	f3 48 ab             	rep stos %rax,(%rdi)
    9c8d:	48 89 d7             	mov    %rdx,%rdi
    9c90:	e8 bb bd ff ff       	call   5a50 <fwp_mem_free>
    9c95:	66 0f 6f 05 33 55 04 	movdqa 0x45533(%rip),%xmm0        # 4f1d0 <ad_raw_live+0x10>
    9c9c:	00 
    9c9d:	66 0f d4 05 1b 55 04 	paddq  0x4551b(%rip),%xmm0        # 4f1c0 <ad_raw_live>
    9ca4:	00 
    9ca5:	48 c7 05 70 db 05 00 	movq   $0x0,0x5db70(%rip)        # 67820 <fwp_cur>
    9cac:	00 00 00 00 
    9cb0:	48 8b 05 a9 ef 05 00 	mov    0x5efa9(%rip),%rax        # 68c60 <fwp_heap+0x1420>
    9cb7:	48 c7 05 56 db 05 00 	movq   $0x0,0x5db56(%rip)        # 67818 <fwp_root>
    9cbe:	00 00 00 00 
    9cc2:	c7 05 3c f8 05 00 00 	movl   $0x0,0x5f83c(%rip)        # 69508 <iteration_active>
    9cc9:	00 00 00 
    9ccc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9cd0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9cd5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9cd9:	66 0f d6 05 37 54 01 	movq   %xmm0,0x15437(%rip)        # 1f118 <ad_raw_before_shutdown>
    9ce0:	00 
    9ce1:	48 85 c0             	test   %rax,%rax
    9ce4:	0f 88 46 01 00 00    	js     9e30 <fwp_main_thread+0x770>
    9cea:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9cee:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9cf3:	f2 0f 5c 0d ed f7 05 	subsd  0x5f7ed(%rip),%xmm1        # 694e8 <iteration_start_charge>
    9cfa:	00 
    9cfb:	48 8b 3d 3e 53 00 00 	mov    0x533e(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    9d02:	48 8d 15 97 1d 00 00 	lea    0x1d97(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    9d09:	be 02 00 00 00       	mov    $0x2,%esi
    9d0e:	f2 0f 10 05 ca f7 05 	movsd  0x5f7ca(%rip),%xmm0        # 694e0 <iteration_peak>
    9d15:	00 
    9d16:	4c 8b 0d d3 f7 05 00 	mov    0x5f7d3(%rip),%r9        # 694f0 <iteration_retains>
    9d1d:	b8 02 00 00 00       	mov    $0x2,%eax
    9d22:	4c 8b 05 cf f7 05 00 	mov    0x5f7cf(%rip),%r8        # 694f8 <iteration_bytes>
    9d29:	48 8b 0d d0 f7 05 00 	mov    0x5f7d0(%rip),%rcx        # 69500 <iteration_requests>
    9d30:	e8 3b 99 ff ff       	call   3670 <__fprintf_chk@plt>
    9d35:	48 8b 3d e4 52 00 00 	mov    0x52e4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    9d3c:	e8 5f 98 ff ff       	call   35a0 <fflush@plt>
    9d41:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9d48:	00 
    9d49:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d50:	00 00 
    9d52:	0f 85 57 08 00 00    	jne    a5af <fwp_main_thread+0xeef>
    9d58:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9d5f:	31 c0                	xor    %eax,%eax
    9d61:	5b                   	pop    %rbx
    9d62:	5d                   	pop    %rbp
    9d63:	41 5c                	pop    %r12
    9d65:	41 5d                	pop    %r13
    9d67:	41 5e                	pop    %r14
    9d69:	41 5f                	pop    %r15
    9d6b:	c3                   	ret
    9d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d70:	48 89 05 81 da 05 00 	mov    %rax,0x5da81(%rip)        # 677f8 <fwp_timers>
    9d77:	e9 db fb ff ff       	jmp    9957 <fwp_main_thread+0x297>
    9d7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d80:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9d84:	0f 85 d6 fc ff ff    	jne    9a60 <fwp_main_thread+0x3a0>
    9d8a:	48 89 ef             	mov    %rbp,%rdi
    9d8d:	e8 7e a3 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9d92:	e9 c9 fc ff ff       	jmp    9a60 <fwp_main_thread+0x3a0>
    9d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d9e:	00 00 
    9da0:	31 db                	xor    %ebx,%ebx
    9da2:	48 83 3d fe f6 05 00 	cmpq   $0x0,0x5f6fe(%rip)        # 694a8 <fwp_state_owners>
    9da9:	00 
    9daa:	0f 85 e2 fb ff ff    	jne    9992 <fwp_main_thread+0x2d2>
    9db0:	48 8b 3d 09 f7 05 00 	mov    0x5f709(%rip),%rdi        # 694c0 <fwp_state>
    9db7:	e8 94 bc ff ff       	call   5a50 <fwp_mem_free>
    9dbc:	48 c7 05 f9 f6 05 00 	movq   $0x0,0x5f6f9(%rip)        # 694c0 <fwp_state>
    9dc3:	00 00 00 00 
    9dc7:	48 c7 05 de f6 05 00 	movq   $0x0,0x5f6de(%rip)        # 694b0 <fwp_state_cap>
    9dce:	00 00 00 00 
    9dd2:	48 85 db             	test   %rbx,%rbx
    9dd5:	0f 84 6f 07 00 00    	je     a54a <fwp_main_thread+0xe8a>
    9ddb:	48 3b 1d 36 da 05 00 	cmp    0x5da36(%rip),%rbx        # 67818 <fwp_root>
    9de2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9de9:	00 00 00 00 
    9ded:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9df4:	00 00 00 00 
    9df8:	c7 05 9e 52 01 00 00 	movl   $0x0,0x1529e(%rip)        # 1f0a0 <fwp_exit_code>
    9dff:	00 00 00 
    9e02:	0f 84 aa fb ff ff    	je     99b2 <fwp_main_thread+0x2f2>
    9e08:	e9 1e 99 ff ff       	jmp    372b <fwp_main_thread.cold>
    9e0d:	0f 1f 00             	nopl   (%rax)
    9e10:	48 89 c2             	mov    %rax,%rdx
    9e13:	83 e0 01             	and    $0x1,%eax
    9e16:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e1a:	48 d1 ea             	shr    $1,%rdx
    9e1d:	48 09 c2             	or     %rax,%rdx
    9e20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9e25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9e29:	e9 b6 f9 ff ff       	jmp    97e4 <fwp_main_thread+0x124>
    9e2e:	66 90                	xchg   %ax,%ax
    9e30:	48 89 c2             	mov    %rax,%rdx
    9e33:	83 e0 01             	and    $0x1,%eax
    9e36:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9e3a:	48 d1 ea             	shr    $1,%rdx
    9e3d:	48 09 c2             	or     %rax,%rdx
    9e40:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9e45:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9e49:	e9 a5 fe ff ff       	jmp    9cf3 <fwp_main_thread+0x633>
    9e4e:	66 90                	xchg   %ax,%ax
    9e50:	48 8d 3d 49 ae ff ff 	lea    -0x51b7(%rip),%rdi        # 4ca0 <fwp_heap_report>
    9e57:	e8 94 09 00 00       	call   a7f0 <atexit>
    9e5c:	e9 a3 f8 ff ff       	jmp    9704 <fwp_main_thread+0x44>
    9e61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9e68:	e8 43 af ff ff       	call   4db0 <fwp_heap_init>
    9e6d:	e9 84 f8 ff ff       	jmp    96f6 <fwp_main_thread+0x36>
    9e72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e78:	48 8d 05 d1 de ff ff 	lea    -0x212f(%rip),%rax        # 7d50 <fwp_drop1>
    9e7f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e83:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9e8a:	00 00 
    9e8c:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9e92:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9e97:	48 8b 05 3a f6 05 00 	mov    0x5f63a(%rip),%rax        # 694d8 <fwp_cleanups>
    9e9e:	4c 8d 3d 9b d9 05 00 	lea    0x5d99b(%rip),%r15        # 67840 <fwp_heap>
    9ea5:	48 89 2d 2c f6 05 00 	mov    %rbp,0x5f62c(%rip)        # 694d8 <fwp_cleanups>
    9eac:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9eb0:	31 ed                	xor    %ebp,%ebp
    9eb2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9eb7:	48 8d 05 f2 9c ff ff 	lea    -0x630e(%rip),%rax        # 3bb0 <fwp_range_release>
    9ebe:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9ec3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9ec8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9ecd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9ed2:	eb 3d                	jmp    9f11 <fwp_main_thread+0x851>
    9ed4:	0f 1f 40 00          	nopl   0x0(%rax)
    9ed8:	80 f9 01             	cmp    $0x1,%cl
    9edb:	75 29                	jne    9f06 <fwp_main_thread+0x846>
    9edd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ee0:	0f b7 c0             	movzwl %ax,%eax
    9ee3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ee6:	48 0f af c1          	imul   %rcx,%rax
    9eea:	48 c1 e8 20          	shr    $0x20,%rax
    9eee:	48 39 d0             	cmp    %rdx,%rax
    9ef1:	73 13                	jae    9f06 <fwp_main_thread+0x846>
    9ef3:	49 01 c5             	add    %rax,%r13
    9ef6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9efb:	0f 84 af 05 00 00    	je     a4b0 <fwp_main_thread+0xdf0>
    9f01:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9f06:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9f0b:	49 83 ec 01          	sub    $0x1,%r12
    9f0f:	72 7f                	jb     9f90 <fwp_main_thread+0x8d0>
    9f11:	48 89 de             	mov    %rbx,%rsi
    9f14:	bf 01 00 00 00       	mov    $0x1,%edi
    9f19:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9f20:	00 
    9f21:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9f26:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9f2d:	00 
    9f2e:	e8 0d c2 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    9f33:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9f3a:	48 89 c5             	mov    %rax,%rbp
    9f3d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9f44:	48 c1 e2 10          	shl    $0x10,%rdx
    9f48:	48 39 d0             	cmp    %rdx,%rax
    9f4b:	73 b9                	jae    9f06 <fwp_main_thread+0x846>
    9f4d:	48 89 c2             	mov    %rax,%rdx
    9f50:	48 c1 ea 10          	shr    $0x10,%rdx
    9f54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f58:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9f5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f63:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9f67:	4d 85 ed             	test   %r13,%r13
    9f6a:	74 9a                	je     9f06 <fwp_main_thread+0x846>
    9f6c:	0f b6 0a             	movzbl (%rdx),%ecx
    9f6f:	80 f9 02             	cmp    $0x2,%cl
    9f72:	0f 85 60 ff ff ff    	jne    9ed8 <fwp_main_thread+0x818>
    9f78:	66 85 c0             	test   %ax,%ax
    9f7b:	0f 84 75 ff ff ff    	je     9ef6 <fwp_main_thread+0x836>
    9f81:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9f86:	49 83 ec 01          	sub    $0x1,%r12
    9f8a:	73 85                	jae    9f11 <fwp_main_thread+0x851>
    9f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f90:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9f95:	66 0f 6f 05 83 1d 00 	movdqa 0x1d83(%rip),%xmm0        # bd20 <msg.8+0xb0>
    9f9c:	00 
    9f9d:	48 89 de             	mov    %rbx,%rsi
    9fa0:	bf 01 00 00 00       	mov    $0x1,%edi
    9fa5:	48 89 05 2c f5 05 00 	mov    %rax,0x5f52c(%rip)        # 694d8 <fwp_cleanups>
    9fac:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9fb3:	00 
    9fb4:	e8 87 c1 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    9fb9:	48 8b 15 58 ec 05 00 	mov    0x5ec58(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    9fc0:	49 89 c4             	mov    %rax,%r12
    9fc3:	48 2b 05 26 ec 05 00 	sub    0x5ec26(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    9fca:	48 c1 e2 10          	shl    $0x10,%rdx
    9fce:	48 39 d0             	cmp    %rdx,%rax
    9fd1:	73 55                	jae    a028 <fwp_main_thread+0x968>
    9fd3:	48 89 c2             	mov    %rax,%rdx
    9fd6:	48 c1 ea 10          	shr    $0x10,%rdx
    9fda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fde:	48 8b 15 53 ec 05 00 	mov    0x5ec53(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    9fe5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fe9:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9fed:	48 85 db             	test   %rbx,%rbx
    9ff0:	74 36                	je     a028 <fwp_main_thread+0x968>
    9ff2:	0f b6 0a             	movzbl (%rdx),%ecx
    9ff5:	80 f9 02             	cmp    $0x2,%cl
    9ff8:	0f 84 a2 04 00 00    	je     a4a0 <fwp_main_thread+0xde0>
    9ffe:	80 f9 01             	cmp    $0x1,%cl
    a001:	75 25                	jne    a028 <fwp_main_thread+0x968>
    a003:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a006:	0f b7 c0             	movzwl %ax,%eax
    a009:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a00c:	48 0f af c1          	imul   %rcx,%rax
    a010:	48 c1 e8 20          	shr    $0x20,%rax
    a014:	48 39 d0             	cmp    %rdx,%rax
    a017:	73 0f                	jae    a028 <fwp_main_thread+0x968>
    a019:	48 01 c3             	add    %rax,%rbx
    a01c:	80 3b ff             	cmpb   $0xff,(%rbx)
    a01f:	0f 84 4b 05 00 00    	je     a570 <fwp_main_thread+0xeb0>
    a025:	c6 03 01             	movb   $0x1,(%rbx)
    a028:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    a02d:	bf 01 00 00 00       	mov    $0x1,%edi
    a032:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    a037:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a03e:	00 f0 3f 
    a041:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    a046:	e8 f5 c0 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    a04b:	48 8b 15 c6 eb 05 00 	mov    0x5ebc6(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    a052:	49 89 c4             	mov    %rax,%r12
    a055:	48 2b 05 94 eb 05 00 	sub    0x5eb94(%rip),%rax        # 68bf0 <fwp_heap+0x13b0>
    a05c:	48 c1 e2 10          	shl    $0x10,%rdx
    a060:	48 39 d0             	cmp    %rdx,%rax
    a063:	73 55                	jae    a0ba <fwp_main_thread+0x9fa>
    a065:	48 89 c2             	mov    %rax,%rdx
    a068:	48 c1 ea 10          	shr    $0x10,%rdx
    a06c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a070:	48 8b 15 c1 eb 05 00 	mov    0x5ebc1(%rip),%rdx        # 68c38 <fwp_heap+0x13f8>
    a077:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a07b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a07f:	48 85 db             	test   %rbx,%rbx
    a082:	74 36                	je     a0ba <fwp_main_thread+0x9fa>
    a084:	0f b6 0a             	movzbl (%rdx),%ecx
    a087:	80 f9 02             	cmp    $0x2,%cl
    a08a:	0f 84 00 04 00 00    	je     a490 <fwp_main_thread+0xdd0>
    a090:	80 f9 01             	cmp    $0x1,%cl
    a093:	75 25                	jne    a0ba <fwp_main_thread+0x9fa>
    a095:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a098:	0f b7 c0             	movzwl %ax,%eax
    a09b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a09e:	48 0f af c1          	imul   %rcx,%rax
    a0a2:	48 c1 e8 20          	shr    $0x20,%rax
    a0a6:	48 39 d0             	cmp    %rdx,%rax
    a0a9:	73 0f                	jae    a0ba <fwp_main_thread+0x9fa>
    a0ab:	48 01 c3             	add    %rax,%rbx
    a0ae:	80 3b ff             	cmpb   $0xff,(%rbx)
    a0b1:	0f 84 c6 04 00 00    	je     a57d <fwp_main_thread+0xebd>
    a0b7:	c6 03 01             	movb   $0x1,(%rbx)
    a0ba:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    a0bf:	bf 01 00 00 00       	mov    $0x1,%edi
    a0c4:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    a0c9:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a0d0:	33 f3 bf 
    a0d3:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a0d8:	e8 63 c0 ff ff       	call   6140 <fwp_data.part.0.constprop.0>
    a0dd:	48 8b 15 34 eb 05 00 	mov    0x5eb34(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    a0e4:	48 8b 0d 05 eb 05 00 	mov    0x5eb05(%rip),%rcx        # 68bf0 <fwp_heap+0x13b0>
    a0eb:	49 89 c4             	mov    %rax,%r12
    a0ee:	48 89 d6             	mov    %rdx,%rsi
    a0f1:	48 29 c8             	sub    %rcx,%rax
    a0f4:	48 c1 e6 10          	shl    $0x10,%rsi
    a0f8:	48 39 f0             	cmp    %rsi,%rax
    a0fb:	73 65                	jae    a162 <fwp_main_thread+0xaa2>
    a0fd:	48 89 c6             	mov    %rax,%rsi
    a100:	48 c1 ee 10          	shr    $0x10,%rsi
    a104:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a108:	48 8b 35 29 eb 05 00 	mov    0x5eb29(%rip),%rsi        # 68c38 <fwp_heap+0x13f8>
    a10f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a113:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a117:	48 85 db             	test   %rbx,%rbx
    a11a:	74 46                	je     a162 <fwp_main_thread+0xaa2>
    a11c:	0f b6 3e             	movzbl (%rsi),%edi
    a11f:	40 80 ff 02          	cmp    $0x2,%dil
    a123:	0f 84 57 03 00 00    	je     a480 <fwp_main_thread+0xdc0>
    a129:	40 80 ff 01          	cmp    $0x1,%dil
    a12d:	75 33                	jne    a162 <fwp_main_thread+0xaa2>
    a12f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a132:	0f b7 c0             	movzwl %ax,%eax
    a135:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a138:	48 0f af c7          	imul   %rdi,%rax
    a13c:	48 c1 e8 20          	shr    $0x20,%rax
    a140:	48 39 f0             	cmp    %rsi,%rax
    a143:	73 1d                	jae    a162 <fwp_main_thread+0xaa2>
    a145:	48 01 c3             	add    %rax,%rbx
    a148:	80 3b ff             	cmpb   $0xff,(%rbx)
    a14b:	0f 84 39 04 00 00    	je     a58a <fwp_main_thread+0xeca>
    a151:	c6 03 01             	movb   $0x1,(%rbx)
    a154:	48 8b 0d 95 ea 05 00 	mov    0x5ea95(%rip),%rcx        # 68bf0 <fwp_heap+0x13b0>
    a15b:	48 8b 15 b6 ea 05 00 	mov    0x5eab6(%rip),%rdx        # 68c18 <fwp_heap+0x13d8>
    a162:	49 89 ed             	mov    %rbp,%r13
    a165:	e9 13 02 00 00       	jmp    a37d <fwp_main_thread+0xcbd>
    a16a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a170:	80 f9 01             	cmp    $0x1,%cl
    a173:	75 3f                	jne    a1b4 <fwp_main_thread+0xaf4>
    a175:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a178:	0f b7 c0             	movzwl %ax,%eax
    a17b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a17e:	48 0f af c1          	imul   %rcx,%rax
    a182:	48 c1 e8 20          	shr    $0x20,%rax
    a186:	48 39 d0             	cmp    %rdx,%rax
    a189:	73 29                	jae    a1b4 <fwp_main_thread+0xaf4>
    a18b:	48 01 c7             	add    %rax,%rdi
    a18e:	0f b6 07             	movzbl (%rdi),%eax
    a191:	84 c0                	test   %al,%al
    a193:	74 1f                	je     a1b4 <fwp_main_thread+0xaf4>
    a195:	8b 15 6d f3 05 00    	mov    0x5f36d(%rip),%edx        # 69508 <iteration_active>
    a19b:	85 d2                	test   %edx,%edx
    a19d:	74 08                	je     a1a7 <fwp_main_thread+0xae7>
    a19f:	48 83 05 49 f3 05 00 	addq   $0x1,0x5f349(%rip)        # 694f0 <iteration_retains>
    a1a6:	01 
    a1a7:	3c fd                	cmp    $0xfd,%al
    a1a9:	0f 87 91 03 00 00    	ja     a540 <fwp_main_thread+0xe80>
    a1af:	83 c0 01             	add    $0x1,%eax
    a1b2:	88 07                	mov    %al,(%rdi)
    a1b4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a1b9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a1bd:	b9 01 00 00 00       	mov    $0x1,%ecx
    a1c2:	4c 89 e6             	mov    %r12,%rsi
    a1c5:	48 8d 15 d4 49 00 00 	lea    0x49d4(%rip),%rdx        # eba0 <d0>
    a1cc:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a1d1:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a1d8:	00 00 
    a1da:	e8 a1 e4 ff ff       	call   8680 <fwp_write>
    a1df:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a1e4:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a1e9:	48 8d 05 7c 0e 00 00 	lea    0xe7c(%rip),%rax        # b06c <_IO_stdin_used+0x6c>
    a1f0:	48 85 c9             	test   %rcx,%rcx
    a1f3:	48 0f 44 c8          	cmove  %rax,%rcx
    a1f7:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a1fb:	0f 87 a2 03 00 00    	ja     a5a3 <fwp_main_thread+0xee3>
    a201:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a205:	be 01 00 00 00       	mov    $0x1,%esi
    a20a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a20f:	e8 3c bd ff ff       	call   5f50 <fwp_heap_alloc>
    a214:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a219:	4c 89 f2             	mov    %r14,%rdx
    a21c:	4c 89 30             	mov    %r14,(%rax)
    a21f:	48 89 c3             	mov    %rax,%rbx
    a222:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a226:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a22b:	e8 50 93 ff ff       	call   3580 <memcpy@plt>
    a230:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a236:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a23b:	e8 70 91 ff ff       	call   33b0 <free@plt>
    a240:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a247:	48 89 d8             	mov    %rbx,%rax
    a24a:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a251:	48 c1 e2 10          	shl    $0x10,%rdx
    a255:	48 39 d0             	cmp    %rdx,%rax
    a258:	73 55                	jae    a2af <fwp_main_thread+0xbef>
    a25a:	48 89 c2             	mov    %rax,%rdx
    a25d:	48 c1 ea 10          	shr    $0x10,%rdx
    a261:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a265:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a26c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a270:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a274:	48 85 f6             	test   %rsi,%rsi
    a277:	74 36                	je     a2af <fwp_main_thread+0xbef>
    a279:	0f b6 0a             	movzbl (%rdx),%ecx
    a27c:	80 f9 02             	cmp    $0x2,%cl
    a27f:	0f 84 4b 01 00 00    	je     a3d0 <fwp_main_thread+0xd10>
    a285:	80 f9 01             	cmp    $0x1,%cl
    a288:	75 25                	jne    a2af <fwp_main_thread+0xbef>
    a28a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a28d:	0f b7 c0             	movzwl %ax,%eax
    a290:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a293:	48 0f af c1          	imul   %rcx,%rax
    a297:	48 c1 e8 20          	shr    $0x20,%rax
    a29b:	48 39 d0             	cmp    %rdx,%rax
    a29e:	73 0f                	jae    a2af <fwp_main_thread+0xbef>
    a2a0:	48 01 c6             	add    %rax,%rsi
    a2a3:	80 3e ff             	cmpb   $0xff,(%rsi)
    a2a6:	0f 84 44 01 00 00    	je     a3f0 <fwp_main_thread+0xd30>
    a2ac:	c6 06 01             	movb   $0x1,(%rsi)
    a2af:	4c 89 e7             	mov    %r12,%rdi
    a2b2:	e8 a9 d8 ff ff       	call   7b60 <fwp_drop0>
    a2b7:	48 8b 13             	mov    (%rbx),%rdx
    a2ba:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a2bf:	be 01 00 00 00       	mov    $0x1,%esi
    a2c4:	48 8b 0d d5 f1 05 00 	mov    0x5f1d5(%rip),%rcx        # 694a0 <fwp_prog_out>
    a2cb:	e8 90 93 ff ff       	call   3660 <fwrite@plt>
    a2d0:	48 8b 35 c9 f1 05 00 	mov    0x5f1c9(%rip),%rsi        # 694a0 <fwp_prog_out>
    a2d7:	bf 0a 00 00 00       	mov    $0xa,%edi
    a2dc:	e8 ef 91 ff ff       	call   34d0 <fputc@plt>
    a2e1:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a2e8:	48 89 d8             	mov    %rbx,%rax
    a2eb:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a2f2:	48 c1 e2 10          	shl    $0x10,%rdx
    a2f6:	48 39 d0             	cmp    %rdx,%rax
    a2f9:	73 67                	jae    a362 <fwp_main_thread+0xca2>
    a2fb:	48 89 c2             	mov    %rax,%rdx
    a2fe:	48 c1 ea 10          	shr    $0x10,%rdx
    a302:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a306:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a30d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a311:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a315:	4d 85 f6             	test   %r14,%r14
    a318:	74 48                	je     a362 <fwp_main_thread+0xca2>
    a31a:	0f b6 0a             	movzbl (%rdx),%ecx
    a31d:	80 f9 02             	cmp    $0x2,%cl
    a320:	0f 84 ea 00 00 00    	je     a410 <fwp_main_thread+0xd50>
    a326:	80 f9 01             	cmp    $0x1,%cl
    a329:	75 37                	jne    a362 <fwp_main_thread+0xca2>
    a32b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a32e:	0f b7 c0             	movzwl %ax,%eax
    a331:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a334:	48 0f af c1          	imul   %rcx,%rax
    a338:	48 c1 e8 20          	shr    $0x20,%rax
    a33c:	48 39 d0             	cmp    %rdx,%rax
    a33f:	73 21                	jae    a362 <fwp_main_thread+0xca2>
    a341:	49 01 c6             	add    %rax,%r14
    a344:	41 0f b6 06          	movzbl (%r14),%eax
    a348:	84 c0                	test   %al,%al
    a34a:	74 16                	je     a362 <fwp_main_thread+0xca2>
    a34c:	3c 01                	cmp    $0x1,%al
    a34e:	0f 84 0c 01 00 00    	je     a460 <fwp_main_thread+0xda0>
    a354:	3c ff                	cmp    $0xff,%al
    a356:	0f 84 64 01 00 00    	je     a4c0 <fwp_main_thread+0xe00>
    a35c:	83 e8 01             	sub    $0x1,%eax
    a35f:	41 88 06             	mov    %al,(%r14)
    a362:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a366:	4d 85 ed             	test   %r13,%r13
    a369:	0f 84 c1 00 00 00    	je     a430 <fwp_main_thread+0xd70>
    a36f:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a376:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a37d:	4c 89 e0             	mov    %r12,%rax
    a380:	48 c1 e2 10          	shl    $0x10,%rdx
    a384:	48 29 c8             	sub    %rcx,%rax
    a387:	48 39 d0             	cmp    %rdx,%rax
    a38a:	0f 83 24 fe ff ff    	jae    a1b4 <fwp_main_thread+0xaf4>
    a390:	48 89 c2             	mov    %rax,%rdx
    a393:	48 c1 ea 10          	shr    $0x10,%rdx
    a397:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a39b:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a3a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3a6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a3aa:	48 85 ff             	test   %rdi,%rdi
    a3ad:	0f 84 01 fe ff ff    	je     a1b4 <fwp_main_thread+0xaf4>
    a3b3:	0f b6 0a             	movzbl (%rdx),%ecx
    a3b6:	80 f9 02             	cmp    $0x2,%cl
    a3b9:	0f 85 b1 fd ff ff    	jne    a170 <fwp_main_thread+0xab0>
    a3bf:	66 85 c0             	test   %ax,%ax
    a3c2:	0f 85 ec fd ff ff    	jne    a1b4 <fwp_main_thread+0xaf4>
    a3c8:	e9 c1 fd ff ff       	jmp    a18e <fwp_main_thread+0xace>
    a3cd:	0f 1f 00             	nopl   (%rax)
    a3d0:	66 85 c0             	test   %ax,%ax
    a3d3:	0f 85 d6 fe ff ff    	jne    a2af <fwp_main_thread+0xbef>
    a3d9:	80 3e ff             	cmpb   $0xff,(%rsi)
    a3dc:	0f 85 ca fe ff ff    	jne    a2ac <fwp_main_thread+0xbec>
    a3e2:	0f 1f 00             	nopl   (%rax)
    a3e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3ec:	00 00 00 00 
    a3f0:	48 89 f7             	mov    %rsi,%rdi
    a3f3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a3f8:	e8 13 b4 ff ff       	call   5810 <fwp_rc_forget_slot>
    a3fd:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a402:	e9 a5 fe ff ff       	jmp    a2ac <fwp_main_thread+0xbec>
    a407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a40e:	00 00 
    a410:	66 85 c0             	test   %ax,%ax
    a413:	0f 84 2b ff ff ff    	je     a344 <fwp_main_thread+0xc84>
    a419:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a41d:	4d 85 ed             	test   %r13,%r13
    a420:	0f 85 49 ff ff ff    	jne    a36f <fwp_main_thread+0xcaf>
    a426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a42d:	00 00 00 
    a430:	4c 89 e7             	mov    %r12,%rdi
    a433:	e8 28 d7 ff ff       	call   7b60 <fwp_drop0>
    a438:	48 89 ef             	mov    %rbp,%rdi
    a43b:	e8 20 d7 ff ff       	call   7b60 <fwp_drop0>
    a440:	48 c7 05 35 4c 00 00 	movq   $0x0,0x4c35(%rip)        # f080 <v.6>
    a447:	00 00 00 00 
    a44b:	c7 05 33 4c 00 00 01 	movl   $0x1,0x4c33(%rip)        # f088 <st.7>
    a452:	00 00 00 
    a455:	e9 be f3 ff ff       	jmp    9818 <fwp_main_thread+0x158>
    a45a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a460:	48 89 df             	mov    %rbx,%rdi
    a463:	e8 e8 b5 ff ff       	call   5a50 <fwp_mem_free>
    a468:	e9 f5 fe ff ff       	jmp    a362 <fwp_main_thread+0xca2>
    a46d:	0f 1f 00             	nopl   (%rax)
    a470:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a474:	e9 53 f4 ff ff       	jmp    98cc <fwp_main_thread+0x20c>
    a479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a480:	66 85 c0             	test   %ax,%ax
    a483:	0f 85 d9 fc ff ff    	jne    a162 <fwp_main_thread+0xaa2>
    a489:	e9 ba fc ff ff       	jmp    a148 <fwp_main_thread+0xa88>
    a48e:	66 90                	xchg   %ax,%ax
    a490:	66 85 c0             	test   %ax,%ax
    a493:	0f 85 21 fc ff ff    	jne    a0ba <fwp_main_thread+0x9fa>
    a499:	e9 10 fc ff ff       	jmp    a0ae <fwp_main_thread+0x9ee>
    a49e:	66 90                	xchg   %ax,%ax
    a4a0:	66 85 c0             	test   %ax,%ax
    a4a3:	0f 85 7f fb ff ff    	jne    a028 <fwp_main_thread+0x968>
    a4a9:	e9 6e fb ff ff       	jmp    a01c <fwp_main_thread+0x95c>
    a4ae:	66 90                	xchg   %ax,%ax
    a4b0:	4c 89 ef             	mov    %r13,%rdi
    a4b3:	e8 58 b3 ff ff       	call   5810 <fwp_rc_forget_slot>
    a4b8:	e9 44 fa ff ff       	jmp    9f01 <fwp_main_thread+0x841>
    a4bd:	0f 1f 00             	nopl   (%rax)
    a4c0:	4c 89 f0             	mov    %r14,%rax
    a4c3:	48 c1 e8 11          	shr    $0x11,%rax
    a4c7:	4c 31 f0             	xor    %r14,%rax
    a4ca:	48 89 c2             	mov    %rax,%rdx
    a4cd:	48 c1 ea 09          	shr    $0x9,%rdx
    a4d1:	48 31 d0             	xor    %rdx,%rax
    a4d4:	0f b6 d0             	movzbl %al,%edx
    a4d7:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a4de:	00 
    a4df:	48 85 c0             	test   %rax,%rax
    a4e2:	75 29                	jne    a50d <fwp_main_thread+0xe4d>
    a4e4:	e9 d7 00 00 00       	jmp    a5c0 <fwp_main_thread+0xf00>
    a4e9:	90                   	nop
    a4ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a4f1:	00 00 00 00 
    a4f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a4fc:	00 00 00 00 
    a500:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a504:	48 85 c0             	test   %rax,%rax
    a507:	0f 84 b3 00 00 00    	je     a5c0 <fwp_main_thread+0xf00>
    a50d:	48 89 c2             	mov    %rax,%rdx
    a510:	4c 3b 30             	cmp    (%rax),%r14
    a513:	75 eb                	jne    a500 <fwp_main_thread+0xe40>
    a515:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a519:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a51d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a521:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a528:	0f 85 34 fe ff ff    	jne    a362 <fwp_main_thread+0xca2>
    a52e:	4c 89 f7             	mov    %r14,%rdi
    a531:	e8 da b2 ff ff       	call   5810 <fwp_rc_forget_slot>
    a536:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a53a:	e9 23 fe ff ff       	jmp    a362 <fwp_main_thread+0xca2>
    a53f:	90                   	nop
    a540:	e8 ab b1 ff ff       	call   56f0 <fwp_rc_wide_dup>
    a545:	e9 6a fc ff ff       	jmp    a1b4 <fwp_main_thread+0xaf4>
    a54a:	48 83 3d c6 d2 05 00 	cmpq   $0x0,0x5d2c6(%rip)        # 67818 <fwp_root>
    a551:	00 
    a552:	c7 05 44 4b 01 00 00 	movl   $0x0,0x14b44(%rip)        # 1f0a0 <fwp_exit_code>
    a559:	00 00 00 
    a55c:	0f 84 f4 f5 ff ff    	je     9b56 <fwp_main_thread+0x496>
    a562:	e9 c4 91 ff ff       	jmp    372b <fwp_main_thread.cold>
    a567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a56e:	00 00 
    a570:	48 89 df             	mov    %rbx,%rdi
    a573:	e8 98 b2 ff ff       	call   5810 <fwp_rc_forget_slot>
    a578:	e9 a8 fa ff ff       	jmp    a025 <fwp_main_thread+0x965>
    a57d:	48 89 df             	mov    %rbx,%rdi
    a580:	e8 8b b2 ff ff       	call   5810 <fwp_rc_forget_slot>
    a585:	e9 2d fb ff ff       	jmp    a0b7 <fwp_main_thread+0x9f7>
    a58a:	48 89 df             	mov    %rbx,%rdi
    a58d:	e8 7e b2 ff ff       	call   5810 <fwp_rc_forget_slot>
    a592:	e9 ba fb ff ff       	jmp    a151 <fwp_main_thread+0xa91>
    a597:	48 8d 3d da 14 00 00 	lea    0x14da(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    a59e:	e8 8d 9e ff ff       	call   4430 <fwp_trap>
    a5a3:	48 8d 3d ed 0c 00 00 	lea    0xced(%rip),%rdi        # b297 <_IO_stdin_used+0x297>
    a5aa:	e8 81 9e ff ff       	call   4430 <fwp_trap>
    a5af:	e8 9c 8e ff ff       	call   3450 <__stack_chk_fail@plt>
    a5b4:	48 8d 3d c1 0c 00 00 	lea    0xcc1(%rip),%rdi        # b27c <_IO_stdin_used+0x27c>
    a5bb:	e8 20 9a ff ff       	call   3fe0 <ad_raw_fail>
    a5c0:	48 8d 3d e1 13 00 00 	lea    0x13e1(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    a5c7:	e8 64 9e ff ff       	call   4430 <fwp_trap>
    a5cc:	e9 5a 91 ff ff       	jmp    372b <fwp_main_thread.cold>
    a5d1:	e9 55 91 ff ff       	jmp    372b <fwp_main_thread.cold>
    a5d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5dd:	00 00 00 

000000000000a5e0 <__divmodti4>:
    a5e0:	f3 0f 1e fa          	endbr64
    a5e4:	55                   	push   %rbp
    a5e5:	49 89 f1             	mov    %rsi,%r9
    a5e8:	49 89 d2             	mov    %rdx,%r10
    a5eb:	48 89 fe             	mov    %rdi,%rsi
    a5ee:	49 89 cb             	mov    %rcx,%r11
    a5f1:	48 89 e5             	mov    %rsp,%rbp
    a5f4:	41 57                	push   %r15
    a5f6:	41 56                	push   %r14
    a5f8:	41 55                	push   %r13
    a5fa:	41 54                	push   %r12
    a5fc:	53                   	push   %rbx
    a5fd:	4c 89 c3             	mov    %r8,%rbx
    a600:	45 31 c0             	xor    %r8d,%r8d
    a603:	4d 85 c9             	test   %r9,%r9
    a606:	79 12                	jns    a61a <__divmodti4+0x3a>
    a608:	31 ff                	xor    %edi,%edi
    a60a:	48 f7 de             	neg    %rsi
    a60d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a614:	4c 19 cf             	sbb    %r9,%rdi
    a617:	49 89 f9             	mov    %rdi,%r9
    a61a:	4c 89 d8             	mov    %r11,%rax
    a61d:	4d 85 db             	test   %r11,%r11
    a620:	0f 88 1a 01 00 00    	js     a740 <__divmodti4+0x160>
    a626:	4c 89 d9             	mov    %r11,%rcx
    a629:	49 89 f3             	mov    %rsi,%r11
    a62c:	75 62                	jne    a690 <__divmodti4+0xb0>
    a62e:	4d 89 c4             	mov    %r8,%r12
    a631:	4d 39 d1             	cmp    %r10,%r9
    a634:	0f 83 46 01 00 00    	jae    a780 <__divmodti4+0x1a0>
    a63a:	4c 89 d8             	mov    %r11,%rax
    a63d:	4c 89 ca             	mov    %r9,%rdx
    a640:	49 f7 f2             	div    %r10
    a643:	49 89 c3             	mov    %rax,%r11
    a646:	31 c0                	xor    %eax,%eax
    a648:	48 89 d6             	mov    %rdx,%rsi
    a64b:	31 ff                	xor    %edi,%edi
    a64d:	4c 89 d9             	mov    %r11,%rcx
    a650:	48 89 c2             	mov    %rax,%rdx
    a653:	48 89 c8             	mov    %rcx,%rax
    a656:	4d 85 e4             	test   %r12,%r12
    a659:	74 0a                	je     a665 <__divmodti4+0x85>
    a65b:	48 f7 d8             	neg    %rax
    a65e:	48 83 d2 00          	adc    $0x0,%rdx
    a662:	48 f7 da             	neg    %rdx
    a665:	4d 85 c0             	test   %r8,%r8
    a668:	74 0a                	je     a674 <__divmodti4+0x94>
    a66a:	48 f7 de             	neg    %rsi
    a66d:	48 83 d7 00          	adc    $0x0,%rdi
    a671:	48 f7 df             	neg    %rdi
    a674:	48 89 33             	mov    %rsi,(%rbx)
    a677:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a67b:	5b                   	pop    %rbx
    a67c:	41 5c                	pop    %r12
    a67e:	41 5d                	pop    %r13
    a680:	41 5e                	pop    %r14
    a682:	41 5f                	pop    %r15
    a684:	5d                   	pop    %rbp
    a685:	c3                   	ret
    a686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a68d:	00 00 00 
    a690:	4d 89 c4             	mov    %r8,%r12
    a693:	49 39 c1             	cmp    %rax,%r9
    a696:	0f 82 ce 00 00 00    	jb     a76a <__divmodti4+0x18a>
    a69c:	31 ff                	xor    %edi,%edi
    a69e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a6a3:	48 63 c7             	movslq %edi,%rax
    a6a6:	be 40 00 00 00       	mov    $0x40,%esi
    a6ab:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a6b0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a6b5:	48 29 c6             	sub    %rax,%rsi
    a6b8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a6bd:	48 09 c8             	or     %rcx,%rax
    a6c0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a6c5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a6ca:	49 89 c6             	mov    %rax,%r14
    a6cd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a6d1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a6d6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a6db:	49 09 c1             	or     %rax,%r9
    a6de:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a6e2:	4c 89 c8             	mov    %r9,%rax
    a6e5:	49 f7 f6             	div    %r14
    a6e8:	48 89 d1             	mov    %rdx,%rcx
    a6eb:	49 89 c3             	mov    %rax,%r11
    a6ee:	49 89 c1             	mov    %rax,%r9
    a6f1:	49 f7 e2             	mul    %r10
    a6f4:	49 89 c6             	mov    %rax,%r14
    a6f7:	49 89 d2             	mov    %rdx,%r10
    a6fa:	48 39 d1             	cmp    %rdx,%rcx
    a6fd:	72 07                	jb     a706 <__divmodti4+0x126>
    a6ff:	75 17                	jne    a718 <__divmodti4+0x138>
    a701:	49 39 c7             	cmp    %rax,%r15
    a704:	73 12                	jae    a718 <__divmodti4+0x138>
    a706:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a70a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a70e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a712:	49 89 d2             	mov    %rdx,%r10
    a715:	49 89 c6             	mov    %rax,%r14
    a718:	4c 89 f8             	mov    %r15,%rax
    a71b:	4c 29 f0             	sub    %r14,%rax
    a71e:	4c 19 d1             	sbb    %r10,%rcx
    a721:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a726:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a72b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a730:	48 09 c6             	or     %rax,%rsi
    a733:	48 89 cf             	mov    %rcx,%rdi
    a736:	31 c0                	xor    %eax,%eax
    a738:	4c 89 c9             	mov    %r9,%rcx
    a73b:	e9 10 ff ff ff       	jmp    a650 <__divmodti4+0x70>
    a740:	4c 89 d0             	mov    %r10,%rax
    a743:	4c 89 da             	mov    %r11,%rdx
    a746:	4d 89 c4             	mov    %r8,%r12
    a749:	49 89 f3             	mov    %rsi,%r11
    a74c:	48 f7 d8             	neg    %rax
    a74f:	49 f7 d4             	not    %r12
    a752:	48 83 d2 00          	adc    $0x0,%rdx
    a756:	49 89 c2             	mov    %rax,%r10
    a759:	48 f7 da             	neg    %rdx
    a75c:	48 89 d1             	mov    %rdx,%rcx
    a75f:	0f 84 cc fe ff ff    	je     a631 <__divmodti4+0x51>
    a765:	49 39 d1             	cmp    %rdx,%r9
    a768:	73 46                	jae    a7b0 <__divmodti4+0x1d0>
    a76a:	4c 89 cf             	mov    %r9,%rdi
    a76d:	31 c0                	xor    %eax,%eax
    a76f:	31 c9                	xor    %ecx,%ecx
    a771:	e9 da fe ff ff       	jmp    a650 <__divmodti4+0x70>
    a776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a77d:	00 00 00 
    a780:	4d 85 d2             	test   %r10,%r10
    a783:	75 0d                	jne    a792 <__divmodti4+0x1b2>
    a785:	b8 01 00 00 00       	mov    $0x1,%eax
    a78a:	31 d2                	xor    %edx,%edx
    a78c:	49 f7 f2             	div    %r10
    a78f:	49 89 c2             	mov    %rax,%r10
    a792:	4c 89 c8             	mov    %r9,%rax
    a795:	31 d2                	xor    %edx,%edx
    a797:	49 f7 f2             	div    %r10
    a79a:	49 89 c1             	mov    %rax,%r9
    a79d:	4c 89 d8             	mov    %r11,%rax
    a7a0:	49 f7 f2             	div    %r10
    a7a3:	49 89 c3             	mov    %rax,%r11
    a7a6:	4c 89 c8             	mov    %r9,%rax
    a7a9:	e9 9a fe ff ff       	jmp    a648 <__divmodti4+0x68>
    a7ae:	66 90                	xchg   %ax,%ax
    a7b0:	45 31 f6             	xor    %r14d,%r14d
    a7b3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a7b8:	44 89 f7             	mov    %r14d,%edi
    a7bb:	45 85 f6             	test   %r14d,%r14d
    a7be:	0f 85 df fe ff ff    	jne    a6a3 <__divmodti4+0xc3>
    a7c4:	4c 39 ca             	cmp    %r9,%rdx
    a7c7:	72 17                	jb     a7e0 <__divmodti4+0x200>
    a7c9:	31 c9                	xor    %ecx,%ecx
    a7cb:	48 39 c6             	cmp    %rax,%rsi
    a7ce:	73 10                	jae    a7e0 <__divmodti4+0x200>
    a7d0:	4c 89 cf             	mov    %r9,%rdi
    a7d3:	31 c0                	xor    %eax,%eax
    a7d5:	e9 76 fe ff ff       	jmp    a650 <__divmodti4+0x70>
    a7da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7e0:	4c 89 de             	mov    %r11,%rsi
    a7e3:	b9 01 00 00 00       	mov    $0x1,%ecx
    a7e8:	48 29 c6             	sub    %rax,%rsi
    a7eb:	49 19 d1             	sbb    %rdx,%r9
    a7ee:	eb e0                	jmp    a7d0 <__divmodti4+0x1f0>

000000000000a7f0 <atexit>:
    a7f0:	f3 0f 1e fa          	endbr64
    a7f4:	48 8b 15 0d 48 00 00 	mov    0x480d(%rip),%rdx        # f008 <__dso_handle>
    a7fb:	31 f6                	xor    %esi,%esi
    a7fd:	e9 3e 8e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a804 <_fini>:
    a804:	f3 0f 1e fa          	endbr64
    a808:	48 83 ec 08          	sub    $0x8,%rsp
    a80c:	48 83 c4 08          	add    $0x8,%rsp
    a810:	c3                   	ret
