
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 af 00 00 	mov    0xafc9(%rip),%rax        # dfd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 ad 00 00    	push   0xade2(%rip)        # de08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 ad 00 00    	jmp    *0xade4(%rip)        # de10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e ac 00 00    	jmp    *0xac4e(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e aa 00 00    	jmp    *0xaa6e(%rip)        # de18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 aa 00 00    	jmp    *0xaa66(%rip)        # de20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e aa 00 00    	jmp    *0xaa5e(%rip)        # de28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 aa 00 00    	jmp    *0xaa56(%rip)        # de30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e aa 00 00    	jmp    *0xaa4e(%rip)        # de38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 aa 00 00    	jmp    *0xaa46(%rip)        # de40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e aa 00 00    	jmp    *0xaa3e(%rip)        # de48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 aa 00 00    	jmp    *0xaa36(%rip)        # de50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e aa 00 00    	jmp    *0xaa2e(%rip)        # de58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 aa 00 00    	jmp    *0xaa26(%rip)        # de60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e aa 00 00    	jmp    *0xaa1e(%rip)        # de68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 aa 00 00    	jmp    *0xaa16(%rip)        # de70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e aa 00 00    	jmp    *0xaa0e(%rip)        # de78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 aa 00 00    	jmp    *0xaa06(%rip)        # de80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe a9 00 00    	jmp    *0xa9fe(%rip)        # de88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 a9 00 00    	jmp    *0xa9f6(%rip)        # de90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee a9 00 00    	jmp    *0xa9ee(%rip)        # de98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 a9 00 00    	jmp    *0xa9e6(%rip)        # dea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de a9 00 00    	jmp    *0xa9de(%rip)        # dea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 a9 00 00    	jmp    *0xa9d6(%rip)        # deb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce a9 00 00    	jmp    *0xa9ce(%rip)        # deb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 a9 00 00    	jmp    *0xa9c6(%rip)        # dec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be a9 00 00    	jmp    *0xa9be(%rip)        # dec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 a9 00 00    	jmp    *0xa9b6(%rip)        # ded0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae a9 00 00    	jmp    *0xa9ae(%rip)        # ded8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 a9 00 00    	jmp    *0xa9a6(%rip)        # dee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e a9 00 00    	jmp    *0xa99e(%rip)        # dee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 a9 00 00    	jmp    *0xa996(%rip)        # def0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e a9 00 00    	jmp    *0xa98e(%rip)        # def8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 a9 00 00    	jmp    *0xa986(%rip)        # df00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e a9 00 00    	jmp    *0xa97e(%rip)        # df08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 a9 00 00    	jmp    *0xa976(%rip)        # df10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e a9 00 00    	jmp    *0xa96e(%rip)        # df18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 a9 00 00    	jmp    *0xa966(%rip)        # df20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e a9 00 00    	jmp    *0xa95e(%rip)        # df28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 a9 00 00    	jmp    *0xa956(%rip)        # df30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e a9 00 00    	jmp    *0xa94e(%rip)        # df38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 a9 00 00    	jmp    *0xa946(%rip)        # df40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e a9 00 00    	jmp    *0xa93e(%rip)        # df48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 a9 00 00    	jmp    *0xa936(%rip)        # df50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e a9 00 00    	jmp    *0xa92e(%rip)        # df58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 a9 00 00    	jmp    *0xa926(%rip)        # df60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e a9 00 00    	jmp    *0xa91e(%rip)        # df68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 a9 00 00    	jmp    *0xa916(%rip)        # df70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e a9 00 00    	jmp    *0xa90e(%rip)        # df78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 a9 00 00    	jmp    *0xa906(%rip)        # df80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe a8 00 00    	jmp    *0xa8fe(%rip)        # df88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 a8 00 00    	jmp    *0xa8f6(%rip)        # df90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee a8 00 00    	jmp    *0xa8ee(%rip)        # df98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 a8 00 00    	jmp    *0xa8e6(%rip)        # dfa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de a8 00 00    	jmp    *0xa8de(%rip)        # dfa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 a8 00 00    	jmp    *0xa8d6(%rip)        # dfb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce a8 00 00    	jmp    *0xa8ce(%rip)        # dfb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 a8 00 00    	jmp    *0xa8c6(%rip)        # dfc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 69 00 00 	lea    0x697a(%rip),%r9        # a091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 69 00 00 	lea    0x6977(%rip),%r8        # a095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 8b 00 00 	lea    0x8ba1(%rip),%rax        # c320 <fwp_fn_table>
    377f:	48 89 05 32 cc 01 00 	mov    %rax,0x1cc32(%rip)        # 203b8 <fwp_fns>
    3786:	48 8b 05 93 a8 00 00 	mov    0xa893(%rip),%rax        # e020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c cc 01 00 	mov    %rax,0x1cc2c(%rip)        # 203c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 2f 6a 00 00 	lea    0x6a2f(%rip),%rdi        # a1cf <_IO_stdin_used+0x1cf>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 a8 00 00 	mov    0xa818(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 0f 57 00 00 	lea    0x570f(%rip),%rdx        # 8f70 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 a7 00 00 	mov    0xa783(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 a7 01 00    	mov    0x1a7d8(%rip),%eax        # 1e080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d df 68 00 00 	lea    0x68df(%rip),%rdi        # a1d8 <_IO_stdin_used+0x1d8>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d e6 6f 00 00 	lea    0x6fe6(%rip),%rdi        # a8f0 <_IO_stdin_used+0x8f0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d a0 6f 00 00 	lea    0x6fa0(%rip),%rdi        # a8c8 <_IO_stdin_used+0x8c8>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 64 6f 00 00 	lea    0x6f64(%rip),%rdi        # a898 <_IO_stdin_used+0x898>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d 30 6f 00 00 	lea    0x6f30(%rip),%rdi        # a870 <_IO_stdin_used+0x870>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 a6 00 00    	call   *0xa653(%rip)        # dfc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 a6 00 00 	lea    0xa691(%rip),%rdi        # e018 <__TMC_END__>
    3987:	48 8d 05 8a a6 00 00 	lea    0xa68a(%rip),%rax        # e018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 a6 00 00 	mov    0xa636(%rip),%rax        # dfd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 a6 00 00 	lea    0xa661(%rip),%rdi        # e018 <__TMC_END__>
    39b7:	48 8d 35 5a a6 00 00 	lea    0xa65a(%rip),%rsi        # e018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 a6 00 00 	mov    0xa605(%rip),%rax        # dfe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d a6 00 00 00 	cmpb   $0x0,0xa64d(%rip)        # e048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 a5 00 00 	cmpq   $0x0,0xa5e2(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 a5 00 00 	mov    0xa5f6(%rip),%rdi        # e008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 a6 00 00 01 	movb   $0x1,0xa625(%rip)        # e048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce a4 01 00 	add    0x1a4ce(%rip),%rdx        # 1e0f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc a4 01 00 	add    0x1a4bc(%rip),%rax        # 1e0f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 c7 01 00 	mov    0x1c749(%rip),%rdi        # 203c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 a3 00 00 	mov    0xa394(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 a3 00 00 	mov    0xa381(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 63 00 00 	lea    0x6345(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 a3 00 00 	mov    0xa372(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 aa 01 00 	mov    0x1aa41(%rip),%rax        # 1e740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 a3 01 00 	mov    0x1a381(%rip),%rax        # 1e100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d a3 01 00 	sub    0x1a36d(%rip),%rax        # 1e0f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 0d 6c 00 00 	lea    0x6c0d(%rip),%rsi        # a9d0 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b bd 01 00 	mov    0x1bd5b(%rip),%rax        # 1fb50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 bd 01 00 	lea    0x1bd54(%rip),%r8        # 1fb50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 bd 01 00 	mov    0x1bd35(%rip),%rbx        # 1fb38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 bd 01 00 	mov    0x1bd45(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 bc 01 00 	mov    0x1bce1(%rip),%rdi        # 1fb40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a bd 01 00 	sub    %rsi,0x1bd2a(%rip)        # 1fb90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba bc 01 00 	mov    0x1bcba(%rip),%rax        # 1fb30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 bc 01 00 	add    0x1bc70(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e bc 01 00 	mov    0x1bc7e(%rip),%rsi        # 1fb40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c bc 01 00 	mov    0x1bc8c(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b bc 01 00 	mov    %r12,0x1bc3b(%rip)        # 1fb40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 bc 01 00 	mov    %rbp,0x1bc29(%rip)        # 1fb38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e bc 01 00 	cmp    %rdi,0x1bc0e(%rip)        # 1fb28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 bc 01 00 	mov    %rdi,0x1bc05(%rip)        # 1fb28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 bc 01 00 	sub    %rdi,0x1bc49(%rip)        # 1fb90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 bb 01 00 	mov    0x1bbf1(%rip),%rax        # 1fb48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea bb 01 00 	lea    0x1bbea(%rip),%r8        # 1fb48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd 9f 00 00 	mov    0x9ffd(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 5f 00 00 	lea    0x5fb4(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 a6 01 00 	cmp    0x1a689(%rip),%rdi        # 1e740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f a6 01 00 	mov    0x1a64f(%rip),%rax        # 1e720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d a6 01 00 	mov    %rdi,0x1a62d(%rip)        # 1e720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 a6 01 00 	mov    %rdi,0x1a609(%rip)        # 1e728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 5f 00 00 	lea    0x5fdb(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 5e 00 00 	lea    0x5ea7(%rip),%rsi        # a01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 9e 00 00 	mov    0x9e78(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 5e 00 00 	lea    0x5e51(%rip),%rdx        # a020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 9e 00 00 	mov    0x9e60(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 9d 00 00 	mov    0x9d71(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 5d 00 00 	lea    0x5d28(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 5d 00 00 	lea    0x5d32(%rip),%rdi        # a02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 5c 00 00 	lea    0x5cba(%rip),%rdi        # a049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 48 62 00 00 	lea    0x6248(%rip),%rdi        # a5e8 <_IO_stdin_used+0x5e8>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 30 66 00 	movdqa 0x6630(%rip),%xmm0        # a9f0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a bf 01 00 	add    0x1bf9a(%rip),%rax        # 203b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d a4 61 00 00 	lea    0x61a4(%rip),%rdi        # a618 <_IO_stdin_used+0x618>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 9c 01 00 	cmp    %rax,0x19c55(%rip)        # 1e0e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 9c 01 00 	add    0x19c50(%rip),%rax        # 1e0f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d 8d 61 00 00 	lea    0x618d(%rip),%rdi        # a648 <_IO_stdin_used+0x648>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 5b 00 00 	lea    0x5b92(%rip),%r8        # a065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 59 00 00 	lea    0x59e7(%rip),%r8        # a074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 58 00 00 	lea    0x5874(%rip),%r8        # a06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 56 00 00 	lea    0x564c(%rip),%rdi        # a079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 57 00 00 	lea    0x5736(%rip),%rsi        # a184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 b0 01 00 	mov    0x1b065(%rip),%r9        # 1fb28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be b0 01 00 	mov    0x1b0be(%rip),%r8        # 1fb88 <fwp_heap+0x1428>
    4aca:	48 8d 15 c7 5b 00 00 	lea    0x5bc7(%rip),%rdx        # a698 <_IO_stdin_used+0x698>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 b0 01 00 	mov    0x1b0a6(%rip),%rcx        # 1fb80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 b0 01 	movsd  0x1b0b4(%rip),%xmm1        # 1fba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 b0 01 	movsd  0x1b0a4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 95 00 00 	mov    0x9545(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 c8 5e 00 	movdqa 0x5ec8(%rip),%xmm0        # aa00 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f ab 01 00 	lea    0x1ab5f(%rip),%rax        # 1f6a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 f1 5e 00 	movdqa 0x5ef1(%rip),%xmm2        # aa40 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 ab 01 00 	movaps %xmm0,0x1ab05(%rip)        # 1f660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 ad 5e 00 	movdqa 0x5ead(%rip),%xmm0        # aa10 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 af 01 00 01 	movl   $0x1,0x1af93(%rip)        # 1fb04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 aa 01 00 	movaps %xmm0,0x1aaf3(%rip)        # 1f670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 9b 5e 00 	movdqa 0x5e9b(%rip),%xmm0        # aa20 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 aa 01 00 	movaps %xmm0,0x1aaf4(%rip)        # 1f680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 9c 5e 00 	movdqa 0x5e9c(%rip),%xmm0        # aa30 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 aa 01 00 	movaps %xmm0,0x1aaf5(%rip)        # 1f690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 9b 01 00 	lea    0x19b75(%rip),%r8        # 1e760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ae 01 00 	mov    %rax,0x1ae90(%rip)        # 1fb18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ae 01 00 	mov    %r12,0x1ae6e(%rip)        # 1fb20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ae 01 00 	mov    %rax,0x1ae57(%rip)        # 1fb10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ae 01 00 	mov    %rbx,0x1ae70(%rip)        # 1fb30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ae 01 00 	mov    %rsi,0x1ae99(%rip)        # 1fb60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 53 00 00 	lea    0x53d6(%rip),%rdi        # a0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ae 01 00 	mov    %rax,0x1ae78(%rip)        # 1fb58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc ad 01 00    	mov    %eax,0x1adfc(%rip)        # 1fb08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec 99 01 00 	mov    0x199ec(%rip),%r8        # 1e720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c 99 01 00 	mov    %rbx,0x1991c(%rip)        # 1e728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 99 01 00 	mov    %r8,0x19908(%rip)        # 1e720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 52 00 00 	lea    0x5239(%rip),%rdi        # a0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd 91 01 00 	lea    0x191dd(%rip),%rdi        # 1e0a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 91 01 00 	movaps %xmm0,0x191c5(%rip)        # 1e0a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 91 01 00 	mov    %rax,0x191a1(%rip)        # 1e088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 91 01 00 	movaps %xmm0,0x191c2(%rip)        # 1e0b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 91 01 00 	movaps %xmm0,0x191c6(%rip)        # 1e0c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 91 01 00 	mov    %rdx,0x191c7(%rip)        # 1e0d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 51 00 00 	lea    0x5190(%rip),%rdi        # a0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 97 01 00 	mov    0x19797(%rip),%rbx        # 1e718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca 8f 00 00 	mov    0x8fca(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d a3 56 00 00 	lea    0x56a3(%rip),%rdi        # a720 <_IO_stdin_used+0x720>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d 96 01 00 	mov    0x1966d(%rip),%rax        # 1e720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 96 01 00 	mov    %rdx,0x19647(%rip)        # 1e720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 95 01 00 	mov    0x19594(%rip),%rbx        # 1e718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 95 01 00 	mov    %rbx,0x19551(%rip)        # 1e718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 95 01 00 	mov    %rdx,0x19551(%rip)        # 1e728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 95 01 00 	lea    0x19566(%rip),%rsi        # 1e760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 b0 01 00 	addq   $0x1,0x1b0e5(%rip)        # 203a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 77 54 00 00 	lea    0x5477(%rip),%rdi        # a750 <_IO_stdin_used+0x750>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d 88 54 00 00 	lea    0x5488(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 4d 00 00 	lea    0x4dd4(%rip),%rdi        # a0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e 94 01 00 	lea    0x1941e(%rip),%rcx        # 1e760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f b0 01 00 	subq   $0x1,0x1b01f(%rip)        # 203a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d e3 53 00 00 	lea    0x53e3(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 b0 01 00 	cmpq   $0x0,0x1b000(%rip)        # 203a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 af 01 00 	sub    %rax,0x1af55(%rip)        # 203b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 af 01 00 	add    %r12,0x1af33(%rip)        # 203b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f a6 01 00 	mov    0x1a68f(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c 92 01 00 	lea    0x1928c(%rip),%rax        # 1e760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 a5 01 00 	add    0x1a5e3(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 a5 01 00 	mov    0x1a5b0(%rip),%rsi        # 1fb10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 a5 01 00 	mov    0x1a5d1(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 a5 01 00 	add    0x1a5c5(%rip),%r8        # 1fb58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d a5 01 	addsd  0x1a58d(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 91 01 00 	lea    0x19142(%rip),%rax        # 1e760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c a5 01 00 	sub    %rdi,0x1a54c(%rip)        # 1fb80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 a5 01 	movsd  %xmm0,0x1a564(%rip)        # 1fba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e a5 01 00 	sub    %rdx,0x1a51e(%rip)        # 1fb80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 a5 01 	addsd  0x1a524(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 a5 01 	movsd  %xmm0,0x1a518(%rip)        # 1fba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af a4 01 00 	mov    0x1a4af(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 a4 01 00 	add    %rcx,0x1a4a9(%rip)        # 1fb90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 a4 01 00 	cmp    0x1a462(%rip),%r9        # 1fb50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 a4 01 00 	mov    %r9,0x1a459(%rip)        # 1fb50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a a4 01 00 	cmp    0x1a44a(%rip),%r9        # 1fb48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d a4 01 00 	mov    %r9,0x1a43d(%rip)        # 1fb48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 a3 01 00 	add    0x1a353(%rip),%rdi        # 1fb58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 8f 01 00 	lea    0x18f30(%rip),%r15        # 1e760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 a2 01 00 	add    0x1a2a0(%rip),%r12        # 1fb10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 a2 01 00 	add    0x1a2f9(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 a2 01 00 	cmp    %rax,0x1a2f8(%rip)        # 1fb88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 a2 01 00 	mov    %rax,0x1a2e9(%rip)        # 1fb80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 a2 01 00 	mov    %rax,0x1a2e8(%rip)        # 1fb88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 a2 01 	addsd  0x1a2e4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc a2 01 	movsd  %xmm0,0x1a2dc(%rip)        # 1fb98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 a2 01 00    	mov    0x1a223(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f 8e 01 00 	lea    0x18e5f(%rip),%rdi        # 1e760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 a2 01 00 	add    0x1a218(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 a2 01 00 	cmp    %rax,0x1a213(%rip)        # 1fb88 <fwp_heap+0x1428>
    5975:	48 89 05 04 a2 01 00 	mov    %rax,0x1a204(%rip)        # 1fb80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 a2 01 00 	mov    %rax,0x1a203(%rip)        # 1fb88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff a1 01 	addsd  0x1a1ff(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 a1 01 	movsd  %xmm0,0x1a1f7(%rip)        # 1fb98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae a0 01 00    	mov    0x1a0ae(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 8c 01 00 	lea    0x18ce5(%rip),%rax        # 1e760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b a0 01 00 	add    0x1a09b(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a a0 01 00 	cmp    %rax,0x1a09a(%rip)        # 1fb88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b a0 01 00 	mov    %rax,0x1a08b(%rip)        # 1fb80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a a0 01 00 	mov    %rax,0x1a08a(%rip)        # 1fb88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 a0 01 	addsd  0x1a086(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e a0 01 	movsd  %xmm0,0x1a07e(%rip)        # 1fb98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e 9f 01 00    	mov    0x19f7e(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d 9b 01 00 	movzbl 0x19b6d(%rip),%eax        # 1f702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 8b 01 00 	lea    0x18bc4(%rip),%rdx        # 1e760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 9f 01 00 	add    0x19f95(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 9f 01 00 	cmp    %rax,0x19f90(%rip)        # 1fb88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 9f 01 00 	mov    %rax,0x19f81(%rip)        # 1fb80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 9f 01 00 	mov    %rax,0x19f80(%rip)        # 1fb88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f 9f 01 	addsd  0x19f7f(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 9f 01 	movsd  %xmm0,0x19f77(%rip)        # 1fb98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 38          	sub    $0x38,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 a9 01 00 00    	js     5e70 <fwp_p_ad_push+0x1d0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	48 09 d0             	or     %rdx,%rax
    5cd1:	0f 89 79 01 00 00    	jns    5e50 <fwp_p_ad_push+0x1b0>
    5cd7:	48 89 f8             	mov    %rdi,%rax
    5cda:	48 c1 f8 20          	sar    $0x20,%rax
    5cde:	48 85 ff             	test   %rdi,%rdi
    5ce1:	79 24                	jns    5d07 <fwp_p_ad_push+0x67>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	48 89 d0             	mov    %rdx,%rax
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	48 c1 f8 20          	sar    $0x20,%rax
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 89 c7             	mov    %rax,%rdi
    5d0a:	e8 71 e7 ff ff       	call   4480 <fwp_tape_of>
    5d0f:	48 89 c3             	mov    %rax,%rbx
    5d12:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d17:	0f 85 76 02 00 00    	jne    5f93 <fwp_p_ad_push+0x2f3>
    5d1d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d21:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d28:	0f 8f 59 02 00 00    	jg     5f87 <fwp_p_ad_push+0x2e7>
    5d2e:	44 89 e0             	mov    %r12d,%eax
    5d31:	4c 39 f8             	cmp    %r15,%rax
    5d34:	0f 8d 41 02 00 00    	jge    5f7b <fwp_p_ad_push+0x2db>
    5d3a:	4d 85 ed             	test   %r13,%r13
    5d3d:	78 0c                	js     5d4b <fwp_p_ad_push+0xab>
    5d3f:	44 89 e8             	mov    %r13d,%eax
    5d42:	4c 39 f8             	cmp    %r15,%rax
    5d45:	0f 8d 30 02 00 00    	jge    5f7b <fwp_p_ad_push+0x2db>
    5d4b:	4d 89 fe             	mov    %r15,%r14
    5d4e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5d52:	49 8d 46 01          	lea    0x1(%r14),%rax
    5d56:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d5c:	0f 87 25 02 00 00    	ja     5f87 <fwp_p_ad_push+0x2e7>
    5d62:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d66:	48 39 e8             	cmp    %rbp,%rax
    5d69:	0f 8e 31 01 00 00    	jle    5ea0 <fwp_p_ad_push+0x200>
    5d6f:	48 85 ed             	test   %rbp,%rbp
    5d72:	b9 40 00 00 00       	mov    $0x40,%ecx
    5d77:	48 0f 44 e9          	cmove  %rcx,%rbp
    5d7b:	48 39 e8             	cmp    %rbp,%rax
    5d7e:	7e 20                	jle    5da0 <fwp_p_ad_push+0x100>
    5d80:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5d87:	0f 8f 03 01 00 00    	jg     5e90 <fwp_p_ad_push+0x1f0>
    5d8d:	48 01 ed             	add    %rbp,%rbp
    5d90:	48 39 e8             	cmp    %rbp,%rax
    5d93:	7f eb                	jg     5d80 <fwp_p_ad_push+0xe0>
    5d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d9c:	00 00 00 00 
    5da0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5da7:	00 
    5da8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dac:	48 89 c6             	mov    %rax,%rsi
    5daf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5db4:	e8 17 d8 ff ff       	call   35d0 <realloc@plt>
    5db9:	48 85 c0             	test   %rax,%rax
    5dbc:	0f 84 dd 01 00 00    	je     5f9f <fwp_p_ad_push+0x2ff>
    5dc2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5dc6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5dca:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5dce:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5dd2:	48 89 e9             	mov    %rbp,%rcx
    5dd5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5dd9:	48 c1 e1 04          	shl    $0x4,%rcx
    5ddd:	48 89 ce             	mov    %rcx,%rsi
    5de0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5de5:	e8 e6 d7 ff ff       	call   35d0 <realloc@plt>
    5dea:	48 85 c0             	test   %rax,%rax
    5ded:	0f 84 ac 01 00 00    	je     5f9f <fwp_p_ad_push+0x2ff>
    5df3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5df7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5dfc:	4d 85 f6             	test   %r14,%r14
    5dff:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e03:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e08:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e0f:	00 
    5e10:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e17:	00 
    5e18:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e1c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e23:	00 
    5e24:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e28:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e2c:	0f 85 e2 00 00 00    	jne    5f14 <fwp_p_ad_push+0x274>
    5e32:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e36:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e3a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e3e:	49 01 c8             	add    %rcx,%r8
    5e41:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5e45:	eb 79                	jmp    5ec0 <fwp_p_ad_push+0x220>
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	48 89 d0             	mov    %rdx,%rax
    5e53:	48 c1 ff 20          	sar    $0x20,%rdi
    5e57:	48 c1 f8 20          	sar    $0x20,%rax
    5e5b:	48 39 c7             	cmp    %rax,%rdi
    5e5e:	0f 84 a3 fe ff ff    	je     5d07 <fwp_p_ad_push+0x67>
    5e64:	48 8d 3d 35 49 00 00 	lea    0x4935(%rip),%rdi        # a7a0 <_IO_stdin_used+0x7a0>
    5e6b:	e8 30 e3 ff ff       	call   41a0 <fwp_trap>
    5e70:	48 83 c4 38          	add    $0x38,%rsp
    5e74:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5e7b:	5b                   	pop    %rbx
    5e7c:	5d                   	pop    %rbp
    5e7d:	41 5c                	pop    %r12
    5e7f:	41 5d                	pop    %r13
    5e81:	41 5e                	pop    %r14
    5e83:	41 5f                	pop    %r15
    5e85:	c3                   	ret
    5e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e8d:	00 00 00 
    5e90:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5e95:	e9 06 ff ff ff       	jmp    5da0 <fwp_p_ad_push+0x100>
    5e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5ea4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5ea8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5eaf:	00 
    5eb0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5eb7:	00 
    5eb8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5ebc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ec0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5ec6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5eca:	4d 85 ed             	test   %r13,%r13
    5ecd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5ed2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5ed8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edf:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ee3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ee7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5eeb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5ef1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ef5:	48 83 c4 38          	add    $0x38,%rsp
    5ef9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f00:	ff ff ff 
    5f03:	4c 21 e0             	and    %r12,%rax
    5f06:	5b                   	pop    %rbx
    5f07:	5d                   	pop    %rbp
    5f08:	4c 09 f8             	or     %r15,%rax
    5f0b:	41 5c                	pop    %r12
    5f0d:	41 5d                	pop    %r13
    5f0f:	41 5e                	pop    %r14
    5f11:	41 5f                	pop    %r15
    5f13:	c3                   	ret
    5f14:	48 39 ca             	cmp    %rcx,%rdx
    5f17:	49 89 d6             	mov    %rdx,%r14
    5f1a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f1f:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f23:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f28:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f2d:	48 29 d1             	sub    %rdx,%rcx
    5f30:	4c 89 ca             	mov    %r9,%rdx
    5f33:	e8 28 d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f38:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f3c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5f41:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5f45:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5f4a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5f4e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5f52:	4c 89 d2             	mov    %r10,%rdx
    5f55:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5f5a:	e8 b1 d6 ff ff       	call   3610 <memmove@plt>
    5f5f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f63:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f67:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5f6c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5f71:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5f76:	e9 bb fe ff ff       	jmp    5e36 <fwp_p_ad_push+0x196>
    5f7b:	48 8d 3d 82 41 00 00 	lea    0x4182(%rip),%rdi        # a104 <_IO_stdin_used+0x104>
    5f82:	e8 19 e2 ff ff       	call   41a0 <fwp_trap>
    5f87:	48 8d 3d 5b 41 00 00 	lea    0x415b(%rip),%rdi        # a0e9 <_IO_stdin_used+0xe9>
    5f8e:	e8 0d e2 ff ff       	call   41a0 <fwp_trap>
    5f93:	48 8d 3d 4e 48 00 00 	lea    0x484e(%rip),%rdi        # a7e8 <_IO_stdin_used+0x7e8>
    5f9a:	e8 01 e2 ff ff       	call   41a0 <fwp_trap>
    5f9f:	48 89 df             	mov    %rbx,%rdi
    5fa2:	e8 59 dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5fa7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fab:	e8 10 d4 ff ff       	call   33c0 <free@plt>
    5fb0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fb4:	e8 07 d4 ff ff       	call   33c0 <free@plt>
    5fb9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    5fbd:	e8 fe d3 ff ff       	call   33c0 <free@plt>
    5fc2:	31 c9                	xor    %ecx,%ecx
    5fc4:	31 c0                	xor    %eax,%eax
    5fc6:	31 d2                	xor    %edx,%edx
    5fc8:	89 53 04             	mov    %edx,0x4(%rbx)
    5fcb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fcf:	ba 13 00 00 00       	mov    $0x13,%edx
    5fd4:	be 01 00 00 00       	mov    $0x1,%esi
    5fd9:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    5fdd:	48 8d 3d 24 40 00 00 	lea    0x4024(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    5fe4:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    5fe8:	48 8b 0d 51 80 00 00 	mov    0x8051(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    5fef:	48 89 43 40          	mov    %rax,0x40(%rbx)
    5ff3:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5ff7:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    5ffb:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    5fff:	e8 7c d6 ff ff       	call   3680 <fwrite@plt>
    6004:	31 ff                	xor    %edi,%edi
    6006:	e8 b5 d5 ff ff       	call   35c0 <fflush@plt>
    600b:	bf 66 00 00 00       	mov    $0x66,%edi
    6010:	e8 8b d6 ff ff       	call   36a0 <_Exit@plt>
    6015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    601c:	00 00 00 00 

0000000000006020 <w120>:
    6020:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6024:	41 55                	push   %r13
    6026:	48 89 fa             	mov    %rdi,%rdx
    6029:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    602d:	41 54                	push   %r12
    602f:	49 89 fc             	mov    %rdi,%r12
    6032:	55                   	push   %rbp
    6033:	53                   	push   %rbx
    6034:	48 89 f3             	mov    %rsi,%rbx
    6037:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    603c:	48 89 f1             	mov    %rsi,%rcx
    603f:	48 83 ec 28          	sub    $0x28,%rsp
    6043:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6049:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    604f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6055:	e8 46 fc ff ff       	call   5ca0 <fwp_p_ad_push>
    605a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6060:	48 89 da             	mov    %rbx,%rdx
    6063:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6069:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6070:	00 f0 3f 
    6073:	48 89 c7             	mov    %rax,%rdi
    6076:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    607d:	00 f0 bf 
    6080:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6085:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    608b:	e8 10 fc ff ff       	call   5ca0 <fwp_p_ad_push>
    6090:	f2 0f 10 05 e8 49 00 	movsd  0x49e8(%rip),%xmm0        # aa80 <msg.4+0xb0>
    6097:	00 
    6098:	4c 89 e7             	mov    %r12,%rdi
    609b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    60a1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    60a8:	00 f0 3f 
    60ab:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60b2:	49 89 c5             	mov    %rax,%r13
    60b5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    60bc:	00 f0 bf 
    60bf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    60c4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60ca:	e8 d1 fb ff ff       	call   5ca0 <fwp_p_ad_push>
    60cf:	48 89 e9             	mov    %rbp,%rcx
    60d2:	4c 89 ea             	mov    %r13,%rdx
    60d5:	48 89 ee             	mov    %rbp,%rsi
    60d8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    60de:	4c 89 ef             	mov    %r13,%rdi
    60e1:	49 89 c4             	mov    %rax,%r12
    60e4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    60e8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60ee:	e8 ad fb ff ff       	call   5ca0 <fwp_p_ad_push>
    60f3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    60f9:	f2 0f 59 1d 87 49 00 	mulsd  0x4987(%rip),%xmm3        # aa88 <msg.4+0xb8>
    6100:	00 
    6101:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6108:	00 59 40 
    610b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6110:	48 89 c2             	mov    %rax,%rdx
    6113:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    611a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6120:	e8 7b fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6125:	48 89 d9             	mov    %rbx,%rcx
    6128:	4c 89 e2             	mov    %r12,%rdx
    612b:	48 89 de             	mov    %rbx,%rsi
    612e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6134:	4c 89 e7             	mov    %r12,%rdi
    6137:	48 89 c5             	mov    %rax,%rbp
    613a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    613e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6144:	e8 57 fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6149:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    614f:	48 89 ea             	mov    %rbp,%rdx
    6152:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6158:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    615f:	00 f0 3f 
    6162:	48 89 c7             	mov    %rax,%rdi
    6165:	48 89 ce             	mov    %rcx,%rsi
    6168:	66 48 0f 7e db       	movq   %xmm3,%rbx
    616d:	e8 2e fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6172:	48 83 c4 28          	add    $0x28,%rsp
    6176:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    617b:	5b                   	pop    %rbx
    617c:	5d                   	pop    %rbp
    617d:	41 5c                	pop    %r12
    617f:	41 5d                	pop    %r13
    6181:	c3                   	ret
    6182:	0f 1f 00             	nopl   (%rax)
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <fwp_rc_share>:
    6190:	48 8b 05 a1 99 01 00 	mov    0x199a1(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    6197:	48 2b 3d 72 99 01 00 	sub    0x19972(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    619e:	48 c1 e0 10          	shl    $0x10,%rax
    61a2:	48 39 c7             	cmp    %rax,%rdi
    61a5:	73 4a                	jae    61f1 <fwp_rc_share+0x61>
    61a7:	48 89 f8             	mov    %rdi,%rax
    61aa:	48 c1 e8 10          	shr    $0x10,%rax
    61ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    61b2:	48 8b 05 9f 99 01 00 	mov    0x1999f(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    61b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    61bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    61c1:	48 85 d2             	test   %rdx,%rdx
    61c4:	74 2b                	je     61f1 <fwp_rc_share+0x61>
    61c6:	0f b6 08             	movzbl (%rax),%ecx
    61c9:	80 f9 02             	cmp    $0x2,%cl
    61cc:	74 2a                	je     61f8 <fwp_rc_share+0x68>
    61ce:	80 f9 01             	cmp    $0x1,%cl
    61d1:	75 1e                	jne    61f1 <fwp_rc_share+0x61>
    61d3:	8b 48 18             	mov    0x18(%rax),%ecx
    61d6:	0f b7 ff             	movzwl %di,%edi
    61d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    61dc:	48 0f af f9          	imul   %rcx,%rdi
    61e0:	48 c1 ef 20          	shr    $0x20,%rdi
    61e4:	48 39 c7             	cmp    %rax,%rdi
    61e7:	73 08                	jae    61f1 <fwp_rc_share+0x61>
    61e9:	48 01 fa             	add    %rdi,%rdx
    61ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    61ef:	75 0d                	jne    61fe <fwp_rc_share+0x6e>
    61f1:	c3                   	ret
    61f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f8:	66 85 ff             	test   %di,%di
    61fb:	74 ef                	je     61ec <fwp_rc_share+0x5c>
    61fd:	c3                   	ret
    61fe:	50                   	push   %rax
    61ff:	48 8d 3d 12 46 00 00 	lea    0x4612(%rip),%rdi        # a818 <_IO_stdin_used+0x818>
    6206:	e8 95 df ff ff       	call   41a0 <fwp_trap>
    620b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006210 <fwp_rc_free_obj>:
    6210:	48 8b 15 21 99 01 00 	mov    0x19921(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    6217:	48 89 f8             	mov    %rdi,%rax
    621a:	48 2b 05 ef 98 01 00 	sub    0x198ef(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6221:	48 c1 e2 10          	shl    $0x10,%rdx
    6225:	48 39 d0             	cmp    %rdx,%rax
    6228:	73 5b                	jae    6285 <fwp_rc_free_obj+0x75>
    622a:	48 89 c2             	mov    %rax,%rdx
    622d:	48 c1 ea 10          	shr    $0x10,%rdx
    6231:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6235:	48 8b 15 1c 99 01 00 	mov    0x1991c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    623c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6240:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6244:	48 85 c9             	test   %rcx,%rcx
    6247:	74 3c                	je     6285 <fwp_rc_free_obj+0x75>
    6249:	0f b6 32             	movzbl (%rdx),%esi
    624c:	40 80 fe 02          	cmp    $0x2,%sil
    6250:	74 2e                	je     6280 <fwp_rc_free_obj+0x70>
    6252:	40 80 fe 01          	cmp    $0x1,%sil
    6256:	75 2d                	jne    6285 <fwp_rc_free_obj+0x75>
    6258:	8b 72 18             	mov    0x18(%rdx),%esi
    625b:	0f b7 c0             	movzwl %ax,%eax
    625e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6261:	48 0f af c6          	imul   %rsi,%rax
    6265:	48 c1 e8 20          	shr    $0x20,%rax
    6269:	48 39 d0             	cmp    %rdx,%rax
    626c:	73 17                	jae    6285 <fwp_rc_free_obj+0x75>
    626e:	48 01 c1             	add    %rax,%rcx
    6271:	80 39 01             	cmpb   $0x1,(%rcx)
    6274:	75 0f                	jne    6285 <fwp_rc_free_obj+0x75>
    6276:	e9 d5 f2 ff ff       	jmp    5550 <fwp_mem_free>
    627b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6280:	66 85 c0             	test   %ax,%ax
    6283:	74 ec                	je     6271 <fwp_rc_free_obj+0x61>
    6285:	c3                   	ret
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 

0000000000006290 <fwp_rc_dup>:
    6290:	f3 0f 1e fa          	endbr64
    6294:	48 8b 05 9d 98 01 00 	mov    0x1989d(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    629b:	48 2b 3d 6e 98 01 00 	sub    0x1986e(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    62a2:	48 c1 e0 10          	shl    $0x10,%rax
    62a6:	48 39 c7             	cmp    %rax,%rdi
    62a9:	73 56                	jae    6301 <fwp_rc_dup+0x71>
    62ab:	48 89 f8             	mov    %rdi,%rax
    62ae:	48 c1 e8 10          	shr    $0x10,%rax
    62b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    62b6:	48 8b 05 9b 98 01 00 	mov    0x1989b(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    62bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    62c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    62c5:	48 85 c0             	test   %rax,%rax
    62c8:	74 37                	je     6301 <fwp_rc_dup+0x71>
    62ca:	0f b6 0a             	movzbl (%rdx),%ecx
    62cd:	80 f9 02             	cmp    $0x2,%cl
    62d0:	74 36                	je     6308 <fwp_rc_dup+0x78>
    62d2:	80 f9 01             	cmp    $0x1,%cl
    62d5:	75 2a                	jne    6301 <fwp_rc_dup+0x71>
    62d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    62da:	0f b7 ff             	movzwl %di,%edi
    62dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    62e0:	48 0f af f9          	imul   %rcx,%rdi
    62e4:	48 c1 ef 20          	shr    $0x20,%rdi
    62e8:	48 39 d7             	cmp    %rdx,%rdi
    62eb:	73 14                	jae    6301 <fwp_rc_dup+0x71>
    62ed:	48 01 f8             	add    %rdi,%rax
    62f0:	0f b6 10             	movzbl (%rax),%edx
    62f3:	84 d2                	test   %dl,%dl
    62f5:	74 0a                	je     6301 <fwp_rc_dup+0x71>
    62f7:	80 fa fd             	cmp    $0xfd,%dl
    62fa:	77 14                	ja     6310 <fwp_rc_dup+0x80>
    62fc:	83 c2 01             	add    $0x1,%edx
    62ff:	88 10                	mov    %dl,(%rax)
    6301:	c3                   	ret
    6302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6308:	66 85 ff             	test   %di,%di
    630b:	74 e3                	je     62f0 <fwp_rc_dup+0x60>
    630d:	c3                   	ret
    630e:	66 90                	xchg   %ax,%ax
    6310:	48 89 c7             	mov    %rax,%rdi
    6313:	e9 d8 ee ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    631f:	00 

0000000000006320 <fwp_owned_entry173>:
    6320:	f3 0f 1e fa          	endbr64
    6324:	48 83 ec 38          	sub    $0x38,%rsp
    6328:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    632d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6334:	00 00 
    6336:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    633b:	31 c0                	xor    %eax,%eax
    633d:	48 8b 07             	mov    (%rdi),%rax
    6340:	48 03 47 10          	add    0x10(%rdi),%rax
    6344:	0f 80 c2 00 00 00    	jo     640c <fwp_owned_entry173+0xec>
    634a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    634f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6354:	31 ff                	xor    %edi,%edi
    6356:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    635a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    635f:	e8 0c f8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6364:	48 8b 15 cd 97 01 00 	mov    0x197cd(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    636b:	48 89 c6             	mov    %rax,%rsi
    636e:	48 2b 05 9b 97 01 00 	sub    0x1979b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6375:	48 c1 e2 10          	shl    $0x10,%rdx
    6379:	48 39 d0             	cmp    %rdx,%rax
    637c:	73 4f                	jae    63cd <fwp_owned_entry173+0xad>
    637e:	48 89 c2             	mov    %rax,%rdx
    6381:	48 c1 ea 10          	shr    $0x10,%rdx
    6385:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6389:	48 8b 15 c8 97 01 00 	mov    0x197c8(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6390:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6394:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6398:	48 85 d2             	test   %rdx,%rdx
    639b:	74 30                	je     63cd <fwp_owned_entry173+0xad>
    639d:	0f b6 39             	movzbl (%rcx),%edi
    63a0:	40 80 ff 02          	cmp    $0x2,%dil
    63a4:	74 42                	je     63e8 <fwp_owned_entry173+0xc8>
    63a6:	40 80 ff 01          	cmp    $0x1,%dil
    63aa:	75 21                	jne    63cd <fwp_owned_entry173+0xad>
    63ac:	8b 79 18             	mov    0x18(%rcx),%edi
    63af:	0f b7 c0             	movzwl %ax,%eax
    63b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    63b5:	48 0f af c7          	imul   %rdi,%rax
    63b9:	48 c1 e8 20          	shr    $0x20,%rax
    63bd:	48 39 c8             	cmp    %rcx,%rax
    63c0:	73 0b                	jae    63cd <fwp_owned_entry173+0xad>
    63c2:	48 01 c2             	add    %rax,%rdx
    63c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    63c8:	74 26                	je     63f0 <fwp_owned_entry173+0xd0>
    63ca:	c6 02 01             	movb   $0x1,(%rdx)
    63cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    63d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    63d9:	00 00 
    63db:	75 34                	jne    6411 <fwp_owned_entry173+0xf1>
    63dd:	48 89 f0             	mov    %rsi,%rax
    63e0:	48 83 c4 38          	add    $0x38,%rsp
    63e4:	c3                   	ret
    63e5:	0f 1f 00             	nopl   (%rax)
    63e8:	66 85 c0             	test   %ax,%ax
    63eb:	75 e0                	jne    63cd <fwp_owned_entry173+0xad>
    63ed:	eb d6                	jmp    63c5 <fwp_owned_entry173+0xa5>
    63ef:	90                   	nop
    63f0:	48 89 d7             	mov    %rdx,%rdi
    63f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    63f8:	48 89 14 24          	mov    %rdx,(%rsp)
    63fc:	e8 0f ef ff ff       	call   5310 <fwp_rc_forget_slot>
    6401:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6406:	48 8b 14 24          	mov    (%rsp),%rdx
    640a:	eb be                	jmp    63ca <fwp_owned_entry173+0xaa>
    640c:	e8 ef d2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6411:	e8 4a d0 ff ff       	call   3460 <__stack_chk_fail@plt>
    6416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    641d:	00 00 00 

0000000000006420 <e173>:
    6420:	f3 0f 1e fa          	endbr64
    6424:	53                   	push   %rbx
    6425:	48 83 ec 30          	sub    $0x30,%rsp
    6429:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    642e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6435:	00 00 
    6437:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    643c:	31 c0                	xor    %eax,%eax
    643e:	48 8b 07             	mov    (%rdi),%rax
    6441:	48 03 47 10          	add    0x10(%rdi),%rax
    6445:	0f 80 c9 00 00 00    	jo     6514 <e173+0xf4>
    644b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6450:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6455:	31 ff                	xor    %edi,%edi
    6457:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    645b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6460:	e8 0b f7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6465:	48 8b 15 cc 96 01 00 	mov    0x196cc(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    646c:	48 89 c3             	mov    %rax,%rbx
    646f:	48 2b 05 9a 96 01 00 	sub    0x1969a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6476:	48 c1 e2 10          	shl    $0x10,%rdx
    647a:	48 39 d0             	cmp    %rdx,%rax
    647d:	73 4f                	jae    64ce <e173+0xae>
    647f:	48 89 c2             	mov    %rax,%rdx
    6482:	48 c1 ea 10          	shr    $0x10,%rdx
    6486:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    648a:	48 8b 15 c7 96 01 00 	mov    0x196c7(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6491:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6495:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6499:	48 85 d2             	test   %rdx,%rdx
    649c:	74 30                	je     64ce <e173+0xae>
    649e:	0f b6 31             	movzbl (%rcx),%esi
    64a1:	40 80 fe 02          	cmp    $0x2,%sil
    64a5:	74 49                	je     64f0 <e173+0xd0>
    64a7:	40 80 fe 01          	cmp    $0x1,%sil
    64ab:	75 21                	jne    64ce <e173+0xae>
    64ad:	8b 71 18             	mov    0x18(%rcx),%esi
    64b0:	0f b7 c0             	movzwl %ax,%eax
    64b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64b6:	48 0f af c6          	imul   %rsi,%rax
    64ba:	48 c1 e8 20          	shr    $0x20,%rax
    64be:	48 39 c8             	cmp    %rcx,%rax
    64c1:	73 0b                	jae    64ce <e173+0xae>
    64c3:	48 01 c2             	add    %rax,%rdx
    64c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    64c9:	74 35                	je     6500 <e173+0xe0>
    64cb:	c6 02 01             	movb   $0x1,(%rdx)
    64ce:	48 89 df             	mov    %rbx,%rdi
    64d1:	e8 ba fc ff ff       	call   6190 <fwp_rc_share>
    64d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    64db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    64e2:	00 00 
    64e4:	75 33                	jne    6519 <e173+0xf9>
    64e6:	48 83 c4 30          	add    $0x30,%rsp
    64ea:	48 89 d8             	mov    %rbx,%rax
    64ed:	5b                   	pop    %rbx
    64ee:	c3                   	ret
    64ef:	90                   	nop
    64f0:	66 85 c0             	test   %ax,%ax
    64f3:	75 d9                	jne    64ce <e173+0xae>
    64f5:	eb cf                	jmp    64c6 <e173+0xa6>
    64f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    64fe:	00 00 
    6500:	48 89 d7             	mov    %rdx,%rdi
    6503:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6508:	e8 03 ee ff ff       	call   5310 <fwp_rc_forget_slot>
    650d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6512:	eb b7                	jmp    64cb <e173+0xab>
    6514:	e8 e7 d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6519:	e8 42 cf ff ff       	call   3460 <__stack_chk_fail@plt>
    651e:	66 90                	xchg   %ax,%ax

0000000000006520 <fwp_closure_drop>:
    6520:	48 8b 15 11 96 01 00 	mov    0x19611(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    6527:	48 89 f8             	mov    %rdi,%rax
    652a:	48 2b 05 df 95 01 00 	sub    0x195df(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6531:	48 c1 e2 10          	shl    $0x10,%rdx
    6535:	48 39 d0             	cmp    %rdx,%rax
    6538:	73 6b                	jae    65a5 <fwp_closure_drop+0x85>
    653a:	48 89 c2             	mov    %rax,%rdx
    653d:	48 c1 ea 10          	shr    $0x10,%rdx
    6541:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6545:	48 8b 15 0c 96 01 00 	mov    0x1960c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    654c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6550:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6554:	48 85 d2             	test   %rdx,%rdx
    6557:	74 4c                	je     65a5 <fwp_closure_drop+0x85>
    6559:	0f b6 31             	movzbl (%rcx),%esi
    655c:	40 80 fe 02          	cmp    $0x2,%sil
    6560:	74 3e                	je     65a0 <fwp_closure_drop+0x80>
    6562:	40 80 fe 01          	cmp    $0x1,%sil
    6566:	75 3d                	jne    65a5 <fwp_closure_drop+0x85>
    6568:	8b 71 18             	mov    0x18(%rcx),%esi
    656b:	0f b7 c0             	movzwl %ax,%eax
    656e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6571:	48 0f af c6          	imul   %rsi,%rax
    6575:	48 c1 e8 20          	shr    $0x20,%rax
    6579:	48 39 c8             	cmp    %rcx,%rax
    657c:	73 27                	jae    65a5 <fwp_closure_drop+0x85>
    657e:	48 01 c2             	add    %rax,%rdx
    6581:	0f b6 02             	movzbl (%rdx),%eax
    6584:	84 c0                	test   %al,%al
    6586:	74 1d                	je     65a5 <fwp_closure_drop+0x85>
    6588:	3c 01                	cmp    $0x1,%al
    658a:	74 24                	je     65b0 <fwp_closure_drop+0x90>
    658c:	3c ff                	cmp    $0xff,%al
    658e:	74 48                	je     65d8 <fwp_closure_drop+0xb8>
    6590:	83 e8 01             	sub    $0x1,%eax
    6593:	88 02                	mov    %al,(%rdx)
    6595:	c3                   	ret
    6596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    659d:	00 00 00 
    65a0:	66 85 c0             	test   %ax,%ax
    65a3:	74 dc                	je     6581 <fwp_closure_drop+0x61>
    65a5:	c3                   	ret
    65a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65ad:	00 00 00 
    65b0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    65b7:	ff ff 
    65b9:	48 85 c0             	test   %rax,%rax
    65bc:	74 12                	je     65d0 <fwp_closure_drop+0xb0>
    65be:	48 89 fe             	mov    %rdi,%rsi
    65c1:	48 89 c7             	mov    %rax,%rdi
    65c4:	e9 37 dc ff ff       	jmp    4200 <fwp_closure_drop_push>
    65c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65d0:	e9 db dd ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    65d5:	0f 1f 00             	nopl   (%rax)
    65d8:	48 89 d0             	mov    %rdx,%rax
    65db:	48 8d 35 7e 81 01 00 	lea    0x1817e(%rip),%rsi        # 1e760 <fwp_heap>
    65e2:	48 83 ec 18          	sub    $0x18,%rsp
    65e6:	48 c1 e8 11          	shr    $0x11,%rax
    65ea:	48 31 d0             	xor    %rdx,%rax
    65ed:	48 89 c1             	mov    %rax,%rcx
    65f0:	48 c1 e9 09          	shr    $0x9,%rcx
    65f4:	48 31 c8             	xor    %rcx,%rax
    65f7:	0f b6 c8             	movzbl %al,%ecx
    65fa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6601:	00 
    6602:	48 85 c0             	test   %rax,%rax
    6605:	75 22                	jne    6629 <fwp_closure_drop+0x109>
    6607:	eb 59                	jmp    6662 <fwp_closure_drop+0x142>
    6609:	90                   	nop
    660a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6611:	00 00 00 00 
    6615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    661c:	00 00 00 00 
    6620:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6624:	48 85 c0             	test   %rax,%rax
    6627:	74 39                	je     6662 <fwp_closure_drop+0x142>
    6629:	48 89 c1             	mov    %rax,%rcx
    662c:	48 39 10             	cmp    %rdx,(%rax)
    662f:	75 ef                	jne    6620 <fwp_closure_drop+0x100>
    6631:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6635:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6639:	48 89 48 08          	mov    %rcx,0x8(%rax)
    663d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6644:	74 05                	je     664b <fwp_closure_drop+0x12b>
    6646:	48 83 c4 18          	add    $0x18,%rsp
    664a:	c3                   	ret
    664b:	48 89 d7             	mov    %rdx,%rdi
    664e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6653:	e8 b8 ec ff ff       	call   5310 <fwp_rc_forget_slot>
    6658:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    665d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6660:	eb e4                	jmp    6646 <fwp_closure_drop+0x126>
    6662:	48 8d 3d 0f 41 00 00 	lea    0x410f(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    6669:	e8 32 db ff ff       	call   41a0 <fwp_trap>
    666e:	66 90                	xchg   %ax,%ax

0000000000006670 <fwp_owned_tape_release>:
    6670:	48 85 ff             	test   %rdi,%rdi
    6673:	0f 84 f7 00 00 00    	je     6770 <fwp_owned_tape_release+0x100>
    6679:	41 54                	push   %r12
    667b:	55                   	push   %rbp
    667c:	53                   	push   %rbx
    667d:	48 8b 07             	mov    (%rdi),%rax
    6680:	48 85 c0             	test   %rax,%rax
    6683:	74 08                	je     668d <fwp_owned_tape_release+0x1d>
    6685:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6689:	48 89 50 08          	mov    %rdx,0x8(%rax)
    668d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6691:	48 85 d2             	test   %rdx,%rdx
    6694:	74 03                	je     6699 <fwp_owned_tape_release+0x29>
    6696:	48 89 02             	mov    %rax,(%rdx)
    6699:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    669d:	48 89 fb             	mov    %rdi,%rbx
    66a0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    66a4:	48 85 c0             	test   %rax,%rax
    66a7:	0f 84 89 00 00 00    	je     6736 <fwp_owned_tape_release+0xc6>
    66ad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    66b1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    66b5:	7e 47                	jle    66fe <fwp_owned_tape_release+0x8e>
    66b7:	31 ed                	xor    %ebp,%ebp
    66b9:	eb 0d                	jmp    66c8 <fwp_owned_tape_release+0x58>
    66bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    66c0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    66c4:	48 8b 40 68          	mov    0x68(%rax),%rax
    66c8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    66cc:	49 89 ec             	mov    %rbp,%r12
    66cf:	48 83 c5 01          	add    $0x1,%rbp
    66d3:	49 c1 e4 04          	shl    $0x4,%r12
    66d7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    66db:	ff d0                	call   *%rax
    66dd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    66e1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    66e6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    66ea:	ff 50 68             	call   *0x68(%rax)
    66ed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    66f1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    66f5:	48 39 e8             	cmp    %rbp,%rax
    66f8:	7f c6                	jg     66c0 <fwp_owned_tape_release+0x50>
    66fa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    66fe:	31 ed                	xor    %ebp,%ebp
    6700:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6705:	7e 28                	jle    672f <fwp_owned_tape_release+0xbf>
    6707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    670e:	00 00 
    6710:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6714:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6718:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    671c:	74 07                	je     6725 <fwp_owned_tape_release+0xb5>
    671e:	ff 52 68             	call   *0x68(%rdx)
    6721:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6725:	48 83 c5 01          	add    $0x1,%rbp
    6729:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    672d:	7f e1                	jg     6710 <fwp_owned_tape_release+0xa0>
    672f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6733:	ff 52 68             	call   *0x68(%rdx)
    6736:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    673a:	e8 e1 fd ff ff       	call   6520 <fwp_closure_drop>
    673f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6743:	e8 d8 fd ff ff       	call   6520 <fwp_closure_drop>
    6748:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    674c:	e8 cf fd ff ff       	call   6520 <fwp_closure_drop>
    6751:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6755:	e8 f6 ed ff ff       	call   5550 <fwp_mem_free>
    675a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    675e:	e8 ed ed ff ff       	call   5550 <fwp_mem_free>
    6763:	48 89 df             	mov    %rbx,%rdi
    6766:	5b                   	pop    %rbx
    6767:	5d                   	pop    %rbp
    6768:	41 5c                	pop    %r12
    676a:	e9 e1 ed ff ff       	jmp    5550 <fwp_mem_free>
    676f:	90                   	nop
    6770:	c3                   	ret
    6771:	0f 1f 40 00          	nopl   0x0(%rax)
    6775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    677c:	00 00 00 00 

0000000000006780 <fwp_tape_finish>:
    6780:	f3 0f 1e fa          	endbr64
    6784:	41 56                	push   %r14
    6786:	48 8d 3d 13 79 01 00 	lea    0x17913(%rip),%rdi        # 1e0a0 <fwp_tape_workspace>
    678d:	41 55                	push   %r13
    678f:	41 54                	push   %r12
    6791:	55                   	push   %rbp
    6792:	53                   	push   %rbx
    6793:	e8 d8 d7 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6798:	48 83 3d 48 79 01 00 	cmpq   $0x0,0x17948(%rip)        # 1e0e8 <fwp_ntapes>
    679f:	00 
    67a0:	48 c7 05 dd 78 01 00 	movq   $0x0,0x178dd(%rip)        # 1e088 <fwp_tape_cached_bytes>
    67a7:	00 00 00 00 
    67ab:	7e 68                	jle    6815 <fwp_tape_finish+0x95>
    67ad:	45 31 e4             	xor    %r12d,%r12d
    67b0:	31 ed                	xor    %ebp,%ebp
    67b2:	0f 1f 00             	nopl   (%rax)
    67b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67bc:	00 00 00 00 
    67c0:	48 8b 1d 29 79 01 00 	mov    0x17929(%rip),%rbx        # 1e0f0 <fwp_tapes>
    67c7:	48 83 c5 01          	add    $0x1,%rbp
    67cb:	4c 01 e3             	add    %r12,%rbx
    67ce:	49 83 c4 68          	add    $0x68,%r12
    67d2:	48 89 df             	mov    %rbx,%rdi
    67d5:	e8 26 d4 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    67da:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    67de:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    67e2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    67e6:	e8 d5 cb ff ff       	call   33c0 <free@plt>
    67eb:	4c 89 f7             	mov    %r14,%rdi
    67ee:	e8 cd cb ff ff       	call   33c0 <free@plt>
    67f3:	4c 89 ef             	mov    %r13,%rdi
    67f6:	e8 c5 cb ff ff       	call   33c0 <free@plt>
    67fb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    67ff:	e8 6c fe ff ff       	call   6670 <fwp_owned_tape_release>
    6804:	48 39 2d dd 78 01 00 	cmp    %rbp,0x178dd(%rip)        # 1e0e8 <fwp_ntapes>
    680b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6812:	00 
    6813:	7f ab                	jg     67c0 <fwp_tape_finish+0x40>
    6815:	48 8b 3d d4 78 01 00 	mov    0x178d4(%rip),%rdi        # 1e0f0 <fwp_tapes>
    681c:	e8 9f cb ff ff       	call   33c0 <free@plt>
    6821:	5b                   	pop    %rbx
    6822:	5d                   	pop    %rbp
    6823:	48 c7 05 c2 78 01 00 	movq   $0x0,0x178c2(%rip)        # 1e0f0 <fwp_tapes>
    682a:	00 00 00 00 
    682e:	48 c7 05 a7 78 01 00 	movq   $0x0,0x178a7(%rip)        # 1e0e0 <fwp_tapes_cap>
    6835:	00 00 00 00 
    6839:	41 5c                	pop    %r12
    683b:	48 c7 05 a2 78 01 00 	movq   $0x0,0x178a2(%rip)        # 1e0e8 <fwp_ntapes>
    6842:	00 00 00 00 
    6846:	41 5d                	pop    %r13
    6848:	48 c7 05 85 78 01 00 	movq   $0x0,0x17885(%rip)        # 1e0d8 <fwp_tape_next_slot>
    684f:	00 00 00 00 
    6853:	41 5e                	pop    %r14
    6855:	c3                   	ret
    6856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    685d:	00 00 00 

0000000000006860 <fwp_tape_scope_release>:
    6860:	f3 0f 1e fa          	endbr64
    6864:	41 55                	push   %r13
    6866:	41 54                	push   %r12
    6868:	55                   	push   %rbp
    6869:	53                   	push   %rbx
    686a:	48 83 ec 58          	sub    $0x58,%rsp
    686e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6875:	00 00 
    6877:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    687c:	48 63 07             	movslq (%rdi),%rax
    687f:	85 c0                	test   %eax,%eax
    6881:	0f 88 05 01 00 00    	js     698c <fwp_tape_scope_release+0x12c>
    6887:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    688e:	ec c4 4e 
    6891:	48 89 fb             	mov    %rdi,%rbx
    6894:	eb 3c                	jmp    68d2 <fwp_tape_scope_release+0x72>
    6896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    689d:	00 00 00 
    68a0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    68a5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    68a9:	e8 12 cb ff ff       	call   33c0 <free@plt>
    68ae:	48 8b 3c 24          	mov    (%rsp),%rdi
    68b2:	e8 09 cb ff ff       	call   33c0 <free@plt>
    68b7:	4c 89 ef             	mov    %r13,%rdi
    68ba:	e8 01 cb ff ff       	call   33c0 <free@plt>
    68bf:	4c 89 e7             	mov    %r12,%rdi
    68c2:	e8 a9 fd ff ff       	call   6670 <fwp_owned_tape_release>
    68c7:	48 63 03             	movslq (%rbx),%rax
    68ca:	85 c0                	test   %eax,%eax
    68cc:	0f 88 ba 00 00 00    	js     698c <fwp_tape_scope_release+0x12c>
    68d2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    68d6:	48 8b 35 13 78 01 00 	mov    0x17813(%rip),%rsi        # 1e0f0 <fwp_tapes>
    68dd:	4c 01 c6             	add    %r8,%rsi
    68e0:	48 89 f7             	mov    %rsi,%rdi
    68e3:	e8 18 d3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    68e8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    68ed:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    68f2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    68f9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    68fd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6901:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6908:	00 
    6909:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    690e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6912:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6917:	66 0f ef d2          	pxor   %xmm2,%xmm2
    691b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6920:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6927:	00 
    6928:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    692f:	00 
    6930:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6937:	00 
    6938:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    693d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6942:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6946:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    694a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    694e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6954:	77 18                	ja     696e <fwp_tape_scope_release+0x10e>
    6956:	49 c1 f8 03          	sar    $0x3,%r8
    695a:	4c 0f af c5          	imul   %rbp,%r8
    695e:	4c 3b 05 73 77 01 00 	cmp    0x17773(%rip),%r8        # 1e0d8 <fwp_tape_next_slot>
    6965:	7d 07                	jge    696e <fwp_tape_scope_release+0x10e>
    6967:	4c 89 05 6a 77 01 00 	mov    %r8,0x1776a(%rip)        # 1e0d8 <fwp_tape_next_slot>
    696e:	4d 85 e4             	test   %r12,%r12
    6971:	0f 85 29 ff ff ff    	jne    68a0 <fwp_tape_scope_release+0x40>
    6977:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    697c:	e8 af e4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6981:	48 63 03             	movslq (%rbx),%rax
    6984:	85 c0                	test   %eax,%eax
    6986:	0f 89 46 ff ff ff    	jns    68d2 <fwp_tape_scope_release+0x72>
    698c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6991:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6998:	00 00 
    699a:	75 0b                	jne    69a7 <fwp_tape_scope_release+0x147>
    699c:	48 83 c4 58          	add    $0x58,%rsp
    69a0:	5b                   	pop    %rbx
    69a1:	5d                   	pop    %rbp
    69a2:	41 5c                	pop    %r12
    69a4:	41 5d                	pop    %r13
    69a6:	c3                   	ret
    69a7:	e8 b4 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    69ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000069b0 <fwp_drop4>:
    69b0:	48 8b 0d 81 91 01 00 	mov    0x19181(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    69b7:	48 89 f8             	mov    %rdi,%rax
    69ba:	48 2b 05 4f 91 01 00 	sub    0x1914f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    69c1:	48 c1 e1 10          	shl    $0x10,%rcx
    69c5:	48 39 c8             	cmp    %rcx,%rax
    69c8:	0f 83 42 01 00 00    	jae    6b10 <fwp_drop4+0x160>
    69ce:	48 83 ec 18          	sub    $0x18,%rsp
    69d2:	48 89 fa             	mov    %rdi,%rdx
    69d5:	4c 8d 05 84 7d 01 00 	lea    0x17d84(%rip),%r8        # 1e760 <fwp_heap>
    69dc:	48 89 c1             	mov    %rax,%rcx
    69df:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    69e6:	48 c1 e9 10          	shr    $0x10,%rcx
    69ea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    69ee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    69f2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    69f6:	48 85 c9             	test   %rcx,%rcx
    69f9:	74 40                	je     6a3b <fwp_drop4+0x8b>
    69fb:	0f b6 3e             	movzbl (%rsi),%edi
    69fe:	40 80 ff 02          	cmp    $0x2,%dil
    6a02:	74 3c                	je     6a40 <fwp_drop4+0x90>
    6a04:	40 80 ff 01          	cmp    $0x1,%dil
    6a08:	75 31                	jne    6a3b <fwp_drop4+0x8b>
    6a0a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6a0d:	0f b7 c0             	movzwl %ax,%eax
    6a10:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6a13:	48 0f af c7          	imul   %rdi,%rax
    6a17:	48 c1 e8 20          	shr    $0x20,%rax
    6a1b:	48 39 f0             	cmp    %rsi,%rax
    6a1e:	73 1b                	jae    6a3b <fwp_drop4+0x8b>
    6a20:	48 01 c1             	add    %rax,%rcx
    6a23:	0f b6 01             	movzbl (%rcx),%eax
    6a26:	84 c0                	test   %al,%al
    6a28:	74 11                	je     6a3b <fwp_drop4+0x8b>
    6a2a:	3c 01                	cmp    $0x1,%al
    6a2c:	74 22                	je     6a50 <fwp_drop4+0xa0>
    6a2e:	3c ff                	cmp    $0xff,%al
    6a30:	0f 84 0a 01 00 00    	je     6b40 <fwp_drop4+0x190>
    6a36:	83 e8 01             	sub    $0x1,%eax
    6a39:	88 01                	mov    %al,(%rcx)
    6a3b:	48 83 c4 18          	add    $0x18,%rsp
    6a3f:	c3                   	ret
    6a40:	66 85 c0             	test   %ax,%ax
    6a43:	74 de                	je     6a23 <fwp_drop4+0x73>
    6a45:	48 83 c4 18          	add    $0x18,%rsp
    6a49:	c3                   	ret
    6a4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a50:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6a54:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6a5b:	48 89 f8             	mov    %rdi,%rax
    6a5e:	48 c1 e1 10          	shl    $0x10,%rcx
    6a62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6a69:	48 39 c8             	cmp    %rcx,%rax
    6a6c:	73 62                	jae    6ad0 <fwp_drop4+0x120>
    6a6e:	48 89 c1             	mov    %rax,%rcx
    6a71:	48 c1 e9 10          	shr    $0x10,%rcx
    6a75:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6a79:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6a7d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6a81:	48 85 c9             	test   %rcx,%rcx
    6a84:	74 4a                	je     6ad0 <fwp_drop4+0x120>
    6a86:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6a8a:	41 80 f9 02          	cmp    $0x2,%r9b
    6a8e:	0f 84 9c 00 00 00    	je     6b30 <fwp_drop4+0x180>
    6a94:	41 80 f9 01          	cmp    $0x1,%r9b
    6a98:	75 36                	jne    6ad0 <fwp_drop4+0x120>
    6a9a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6a9e:	0f b7 c0             	movzwl %ax,%eax
    6aa1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6aa4:	49 0f af c1          	imul   %r9,%rax
    6aa8:	48 c1 e8 20          	shr    $0x20,%rax
    6aac:	48 39 f0             	cmp    %rsi,%rax
    6aaf:	73 1f                	jae    6ad0 <fwp_drop4+0x120>
    6ab1:	48 01 c1             	add    %rax,%rcx
    6ab4:	0f b6 01             	movzbl (%rcx),%eax
    6ab7:	84 c0                	test   %al,%al
    6ab9:	74 15                	je     6ad0 <fwp_drop4+0x120>
    6abb:	3c 01                	cmp    $0x1,%al
    6abd:	74 59                	je     6b18 <fwp_drop4+0x168>
    6abf:	3c ff                	cmp    $0xff,%al
    6ac1:	0f 84 ff 00 00 00    	je     6bc6 <fwp_drop4+0x216>
    6ac7:	83 e8 01             	sub    $0x1,%eax
    6aca:	88 01                	mov    %al,(%rcx)
    6acc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ad0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6ad4:	48 89 d7             	mov    %rdx,%rdi
    6ad7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6adb:	e8 30 f7 ff ff       	call   6210 <fwp_rc_free_obj>
    6ae0:	4c 8d 05 79 7c 01 00 	lea    0x17c79(%rip),%r8        # 1e760 <fwp_heap>
    6ae7:	48 8b 04 24          	mov    (%rsp),%rax
    6aeb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6af2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6af9:	48 c1 e2 10          	shl    $0x10,%rdx
    6afd:	48 39 d0             	cmp    %rdx,%rax
    6b00:	0f 83 35 ff ff ff    	jae    6a3b <fwp_drop4+0x8b>
    6b06:	48 8b 14 24          	mov    (%rsp),%rdx
    6b0a:	e9 cd fe ff ff       	jmp    69dc <fwp_drop4+0x2c>
    6b0f:	90                   	nop
    6b10:	c3                   	ret
    6b11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b18:	48 89 14 24          	mov    %rdx,(%rsp)
    6b1c:	e8 ef f6 ff ff       	call   6210 <fwp_rc_free_obj>
    6b21:	48 8b 14 24          	mov    (%rsp),%rdx
    6b25:	eb a9                	jmp    6ad0 <fwp_drop4+0x120>
    6b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b2e:	00 00 
    6b30:	66 85 c0             	test   %ax,%ax
    6b33:	75 9b                	jne    6ad0 <fwp_drop4+0x120>
    6b35:	e9 7a ff ff ff       	jmp    6ab4 <fwp_drop4+0x104>
    6b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b40:	48 89 c8             	mov    %rcx,%rax
    6b43:	48 c1 e8 11          	shr    $0x11,%rax
    6b47:	48 31 c8             	xor    %rcx,%rax
    6b4a:	48 89 c2             	mov    %rax,%rdx
    6b4d:	48 c1 ea 09          	shr    $0x9,%rdx
    6b51:	48 31 d0             	xor    %rdx,%rax
    6b54:	0f b6 d0             	movzbl %al,%edx
    6b57:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6b5e:	00 
    6b5f:	48 85 c0             	test   %rax,%rax
    6b62:	75 29                	jne    6b8d <fwp_drop4+0x1dd>
    6b64:	e9 e3 00 00 00       	jmp    6c4c <fwp_drop4+0x29c>
    6b69:	90                   	nop
    6b6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b71:	00 00 00 00 
    6b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b7c:	00 00 00 00 
    6b80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6b84:	48 85 c0             	test   %rax,%rax
    6b87:	0f 84 bf 00 00 00    	je     6c4c <fwp_drop4+0x29c>
    6b8d:	48 89 c2             	mov    %rax,%rdx
    6b90:	48 39 08             	cmp    %rcx,(%rax)
    6b93:	75 eb                	jne    6b80 <fwp_drop4+0x1d0>
    6b95:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6b99:	48 83 ea 01          	sub    $0x1,%rdx
    6b9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ba1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ba8:	0f 85 8d fe ff ff    	jne    6a3b <fwp_drop4+0x8b>
    6bae:	48 89 cf             	mov    %rcx,%rdi
    6bb1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6bb5:	e8 56 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bba:	48 8b 0c 24          	mov    (%rsp),%rcx
    6bbe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6bc1:	e9 75 fe ff ff       	jmp    6a3b <fwp_drop4+0x8b>
    6bc6:	48 89 ce             	mov    %rcx,%rsi
    6bc9:	48 c1 ee 11          	shr    $0x11,%rsi
    6bcd:	48 31 ce             	xor    %rcx,%rsi
    6bd0:	48 89 f0             	mov    %rsi,%rax
    6bd3:	48 c1 e8 09          	shr    $0x9,%rax
    6bd7:	48 31 c6             	xor    %rax,%rsi
    6bda:	40 0f b6 f6          	movzbl %sil,%esi
    6bde:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6be5:	00 
    6be6:	48 85 c0             	test   %rax,%rax
    6be9:	75 1e                	jne    6c09 <fwp_drop4+0x259>
    6beb:	eb 5f                	jmp    6c4c <fwp_drop4+0x29c>
    6bed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bf4:	00 
    6bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bfc:	00 00 00 00 
    6c00:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6c04:	48 85 c0             	test   %rax,%rax
    6c07:	74 43                	je     6c4c <fwp_drop4+0x29c>
    6c09:	48 89 c6             	mov    %rax,%rsi
    6c0c:	48 39 08             	cmp    %rcx,(%rax)
    6c0f:	75 ef                	jne    6c00 <fwp_drop4+0x250>
    6c11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c15:	48 83 ee 01          	sub    $0x1,%rsi
    6c19:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6c1d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6c24:	0f 85 a6 fe ff ff    	jne    6ad0 <fwp_drop4+0x120>
    6c2a:	48 89 cf             	mov    %rcx,%rdi
    6c2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c32:	48 89 0c 24          	mov    %rcx,(%rsp)
    6c36:	e8 d5 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6c3b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6c3f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c44:	c6 01 fe             	movb   $0xfe,(%rcx)
    6c47:	e9 84 fe ff ff       	jmp    6ad0 <fwp_drop4+0x120>
    6c4c:	48 8d 3d 25 3b 00 00 	lea    0x3b25(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    6c53:	e8 48 d5 ff ff       	call   41a0 <fwp_trap>
    6c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c5f:	00 

0000000000006c60 <fwp_arg_drop37>:
    6c60:	f3 0f 1e fa          	endbr64
    6c64:	85 f6                	test   %esi,%esi
    6c66:	75 04                	jne    6c6c <fwp_arg_drop37+0xc>
    6c68:	85 d2                	test   %edx,%edx
    6c6a:	75 04                	jne    6c70 <fwp_arg_drop37+0x10>
    6c6c:	c3                   	ret
    6c6d:	0f 1f 00             	nopl   (%rax)
    6c70:	48 8b 3f             	mov    (%rdi),%rdi
    6c73:	e9 38 fd ff ff       	jmp    69b0 <fwp_drop4>
    6c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c7f:	00 

0000000000006c80 <fwp_task_dispose>:
    6c80:	53                   	push   %rbx
    6c81:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6c85:	0f 84 bb ca ff ff    	je     3746 <fwp_task_dispose.cold>
    6c8b:	48 89 fb             	mov    %rdi,%rbx
    6c8e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6c93:	0f 85 ad ca ff ff    	jne    3746 <fwp_task_dispose.cold>
    6c99:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6c9d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6ca4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6cab:	00 
    6cac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6cb0:	48 85 ff             	test   %rdi,%rdi
    6cb3:	74 07                	je     6cbc <fwp_task_dispose+0x3c>
    6cb5:	48 85 c0             	test   %rax,%rax
    6cb8:	74 02                	je     6cbc <fwp_task_dispose+0x3c>
    6cba:	ff d0                	call   *%rax
    6cbc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6cc3:	e8 88 e8 ff ff       	call   5550 <fwp_mem_free>
    6cc8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6ccf:	00 00 00 00 
    6cd3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6cd7:	74 6f                	je     6d48 <fwp_task_dispose+0xc8>
    6cd9:	48 8b 15 58 8e 01 00 	mov    0x18e58(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    6ce0:	48 89 d8             	mov    %rbx,%rax
    6ce3:	48 2b 05 26 8e 01 00 	sub    0x18e26(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6cea:	48 c1 e2 10          	shl    $0x10,%rdx
    6cee:	48 39 d0             	cmp    %rdx,%rax
    6cf1:	73 4c                	jae    6d3f <fwp_task_dispose+0xbf>
    6cf3:	48 89 c2             	mov    %rax,%rdx
    6cf6:	48 c1 ea 10          	shr    $0x10,%rdx
    6cfa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cfe:	48 8b 15 53 8e 01 00 	mov    0x18e53(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6d05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d09:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d0d:	48 85 c9             	test   %rcx,%rcx
    6d10:	74 2d                	je     6d3f <fwp_task_dispose+0xbf>
    6d12:	0f b6 32             	movzbl (%rdx),%esi
    6d15:	40 80 fe 02          	cmp    $0x2,%sil
    6d19:	74 3d                	je     6d58 <fwp_task_dispose+0xd8>
    6d1b:	40 80 fe 01          	cmp    $0x1,%sil
    6d1f:	75 1e                	jne    6d3f <fwp_task_dispose+0xbf>
    6d21:	8b 72 18             	mov    0x18(%rdx),%esi
    6d24:	0f b7 c0             	movzwl %ax,%eax
    6d27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d2a:	48 0f af c6          	imul   %rsi,%rax
    6d2e:	48 c1 e8 20          	shr    $0x20,%rax
    6d32:	48 39 d0             	cmp    %rdx,%rax
    6d35:	73 08                	jae    6d3f <fwp_task_dispose+0xbf>
    6d37:	48 01 c1             	add    %rax,%rcx
    6d3a:	80 39 01             	cmpb   $0x1,(%rcx)
    6d3d:	74 09                	je     6d48 <fwp_task_dispose+0xc8>
    6d3f:	5b                   	pop    %rbx
    6d40:	c3                   	ret
    6d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d48:	48 89 df             	mov    %rbx,%rdi
    6d4b:	5b                   	pop    %rbx
    6d4c:	e9 ff e7 ff ff       	jmp    5550 <fwp_mem_free>
    6d51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d58:	66 85 c0             	test   %ax,%ax
    6d5b:	74 dd                	je     6d3a <fwp_task_dispose+0xba>
    6d5d:	5b                   	pop    %rbx
    6d5e:	c3                   	ret
    6d5f:	90                   	nop

0000000000006d60 <fwp_free_zombie>:
    6d60:	48 8b 15 c9 79 01 00 	mov    0x179c9(%rip),%rdx        # 1e730 <fwp_zombie>
    6d67:	48 85 d2             	test   %rdx,%rdx
    6d6a:	0f 84 98 00 00 00    	je     6e08 <fwp_free_zombie+0xa8>
    6d70:	48 3b 15 c9 79 01 00 	cmp    0x179c9(%rip),%rdx        # 1e740 <fwp_cur>
    6d77:	0f 84 8b 00 00 00    	je     6e08 <fwp_free_zombie+0xa8>
    6d7d:	48 83 ec 18          	sub    $0x18,%rsp
    6d81:	48 63 05 84 73 01 00 	movslq 0x17384(%rip),%rax        # 1e10c <fwp_stack_pool_n>
    6d88:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6d8c:	83 f8 3f             	cmp    $0x3f,%eax
    6d8f:	7f 7f                	jg     6e10 <fwp_free_zombie+0xb0>
    6d91:	8d 48 01             	lea    0x1(%rax),%ecx
    6d94:	89 0d 72 73 01 00    	mov    %ecx,0x17372(%rip)        # 1e10c <fwp_stack_pool_n>
    6d9a:	48 8d 0d 7f 73 01 00 	lea    0x1737f(%rip),%rcx        # 1e120 <fwp_stack_pool>
    6da1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6da5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6dac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6db0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6db7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6dbb:	48 85 c9             	test   %rcx,%rcx
    6dbe:	0f 84 fc 00 00 00    	je     6ec0 <fwp_free_zombie+0x160>
    6dc4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6dcb:	48 85 c0             	test   %rax,%rax
    6dce:	74 07                	je     6dd7 <fwp_free_zombie+0x77>
    6dd0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6dd7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6dda:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6dde:	48 c7 05 47 79 01 00 	movq   $0x0,0x17947(%rip)        # 1e730 <fwp_zombie>
    6de5:	00 00 00 00 
    6de9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6df0:	85 c0                	test   %eax,%eax
    6df2:	74 34                	je     6e28 <fwp_free_zombie+0xc8>
    6df4:	83 f8 01             	cmp    $0x1,%eax
    6df7:	0f 84 b3 00 00 00    	je     6eb0 <fwp_free_zombie+0x150>
    6dfd:	48 83 c4 18          	add    $0x18,%rsp
    6e01:	c3                   	ret
    6e02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e08:	c3                   	ret
    6e09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e10:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6e14:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e19:	e8 c2 c7 ff ff       	call   35e0 <munmap@plt>
    6e1e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e23:	eb 80                	jmp    6da5 <fwp_free_zombie+0x45>
    6e25:	0f 1f 00             	nopl   (%rax)
    6e28:	48 8b 0d 09 8d 01 00 	mov    0x18d09(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    6e2f:	48 89 d0             	mov    %rdx,%rax
    6e32:	48 2b 05 d7 8c 01 00 	sub    0x18cd7(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6e39:	48 c1 e1 10          	shl    $0x10,%rcx
    6e3d:	48 39 c8             	cmp    %rcx,%rax
    6e40:	73 bb                	jae    6dfd <fwp_free_zombie+0x9d>
    6e42:	48 89 c1             	mov    %rax,%rcx
    6e45:	48 c1 e9 10          	shr    $0x10,%rcx
    6e49:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6e4d:	48 8b 0d 04 8d 01 00 	mov    0x18d04(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    6e54:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6e58:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6e5c:	48 85 c9             	test   %rcx,%rcx
    6e5f:	74 9c                	je     6dfd <fwp_free_zombie+0x9d>
    6e61:	0f b6 3e             	movzbl (%rsi),%edi
    6e64:	40 80 ff 02          	cmp    $0x2,%dil
    6e68:	74 66                	je     6ed0 <fwp_free_zombie+0x170>
    6e6a:	40 80 ff 01          	cmp    $0x1,%dil
    6e6e:	75 8d                	jne    6dfd <fwp_free_zombie+0x9d>
    6e70:	8b 7e 18             	mov    0x18(%rsi),%edi
    6e73:	0f b7 c0             	movzwl %ax,%eax
    6e76:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6e79:	48 0f af c7          	imul   %rdi,%rax
    6e7d:	48 c1 e8 20          	shr    $0x20,%rax
    6e81:	48 39 f0             	cmp    %rsi,%rax
    6e84:	0f 83 73 ff ff ff    	jae    6dfd <fwp_free_zombie+0x9d>
    6e8a:	48 01 c1             	add    %rax,%rcx
    6e8d:	0f b6 01             	movzbl (%rcx),%eax
    6e90:	84 c0                	test   %al,%al
    6e92:	0f 84 65 ff ff ff    	je     6dfd <fwp_free_zombie+0x9d>
    6e98:	3c 01                	cmp    $0x1,%al
    6e9a:	74 14                	je     6eb0 <fwp_free_zombie+0x150>
    6e9c:	3c ff                	cmp    $0xff,%al
    6e9e:	74 3b                	je     6edb <fwp_free_zombie+0x17b>
    6ea0:	83 e8 01             	sub    $0x1,%eax
    6ea3:	88 01                	mov    %al,(%rcx)
    6ea5:	e9 53 ff ff ff       	jmp    6dfd <fwp_free_zombie+0x9d>
    6eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6eb0:	48 89 d7             	mov    %rdx,%rdi
    6eb3:	48 83 c4 18          	add    $0x18,%rsp
    6eb7:	e9 c4 fd ff ff       	jmp    6c80 <fwp_task_dispose>
    6ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ec0:	48 89 05 41 78 01 00 	mov    %rax,0x17841(%rip)        # 1e708 <fwp_tasks_active>
    6ec7:	e9 ff fe ff ff       	jmp    6dcb <fwp_free_zombie+0x6b>
    6ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ed0:	66 85 c0             	test   %ax,%ax
    6ed3:	0f 85 24 ff ff ff    	jne    6dfd <fwp_free_zombie+0x9d>
    6ed9:	eb b2                	jmp    6e8d <fwp_free_zombie+0x12d>
    6edb:	48 89 ca             	mov    %rcx,%rdx
    6ede:	48 8d 35 7b 78 01 00 	lea    0x1787b(%rip),%rsi        # 1e760 <fwp_heap>
    6ee5:	48 c1 ea 11          	shr    $0x11,%rdx
    6ee9:	48 31 ca             	xor    %rcx,%rdx
    6eec:	48 89 d0             	mov    %rdx,%rax
    6eef:	48 c1 e8 09          	shr    $0x9,%rax
    6ef3:	48 31 c2             	xor    %rax,%rdx
    6ef6:	0f b6 d2             	movzbl %dl,%edx
    6ef9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    6f00:	00 
    6f01:	48 85 c0             	test   %rax,%rax
    6f04:	75 23                	jne    6f29 <fwp_free_zombie+0x1c9>
    6f06:	eb 5c                	jmp    6f64 <fwp_free_zombie+0x204>
    6f08:	66 90                	xchg   %ax,%ax
    6f0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f11:	00 00 00 00 
    6f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f1c:	00 00 00 00 
    6f20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6f24:	48 85 c0             	test   %rax,%rax
    6f27:	74 3b                	je     6f64 <fwp_free_zombie+0x204>
    6f29:	48 89 c2             	mov    %rax,%rdx
    6f2c:	48 39 08             	cmp    %rcx,(%rax)
    6f2f:	75 ef                	jne    6f20 <fwp_free_zombie+0x1c0>
    6f31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f35:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    6f39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6f44:	0f 85 b3 fe ff ff    	jne    6dfd <fwp_free_zombie+0x9d>
    6f4a:	48 89 cf             	mov    %rcx,%rdi
    6f4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f52:	e8 b9 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6f57:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6f5c:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f5f:	e9 99 fe ff ff       	jmp    6dfd <fwp_free_zombie+0x9d>
    6f64:	48 8d 3d 0d 38 00 00 	lea    0x380d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    6f6b:	e8 30 d2 ff ff       	call   41a0 <fwp_trap>

0000000000006f70 <fwp_block>:
    6f70:	48 83 ec 08          	sub    $0x8,%rsp
    6f74:	48 8b 05 ad 77 01 00 	mov    0x177ad(%rip),%rax        # 1e728 <fwp_ready_head>
    6f7b:	48 85 c0             	test   %rax,%rax
    6f7e:	0f 84 1c 01 00 00    	je     70a0 <fwp_block+0x130>
    6f84:	90                   	nop
    6f85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f8c:	00 00 00 00 
    6f90:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    6f97:	48 89 15 8a 77 01 00 	mov    %rdx,0x1778a(%rip)        # 1e728 <fwp_ready_head>
    6f9e:	48 85 d2             	test   %rdx,%rdx
    6fa1:	0f 84 19 01 00 00    	je     70c0 <fwp_block+0x150>
    6fa7:	48 8b 15 92 77 01 00 	mov    0x17792(%rip),%rdx        # 1e740 <fwp_cur>
    6fae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    6fb2:	48 39 c2             	cmp    %rax,%rdx
    6fb5:	0f 84 d5 00 00 00    	je     7090 <fwp_block+0x120>
    6fbb:	48 8b 0d 06 94 01 00 	mov    0x19406(%rip),%rcx        # 203c8 <fwp_state_owners>
    6fc2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6fc6:	48 89 05 73 77 01 00 	mov    %rax,0x17773(%rip)        # 1e740 <fwp_cur>
    6fcd:	f3 0f 7e 05 1b 94 01 	movq   0x1941b(%rip),%xmm0        # 203f0 <fwp_foreign_callbacks>
    6fd4:	00 
    6fd5:	0f 16 05 04 94 01 00 	movhps 0x19404(%rip),%xmm0        # 203e0 <fwp_state>
    6fdc:	f3 0f 7e 0d 04 94 01 	movq   0x19404(%rip),%xmm1        # 203e8 <fwp_handlers>
    6fe3:	00 
    6fe4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    6feb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    6ff2:	0f 16 0d ff 93 01 00 	movhps 0x193ff(%rip),%xmm1        # 203f8 <fwp_cleanups>
    6ff9:	f3 0f 7e 05 d7 93 01 	movq   0x193d7(%rip),%xmm0        # 203d8 <fwp_state_len>
    7000:	00 
    7001:	0f 16 05 c8 93 01 00 	movhps 0x193c8(%rip),%xmm0        # 203d0 <fwp_state_cap>
    7008:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    700f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7016:	48 8b 70 08          	mov    0x8(%rax),%rsi
    701a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7021:	48 89 0d c0 93 01 00 	mov    %rcx,0x193c0(%rip)        # 203e8 <fwp_handlers>
    7028:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    702f:	48 89 0d c2 93 01 00 	mov    %rcx,0x193c2(%rip)        # 203f8 <fwp_cleanups>
    7036:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    703d:	48 89 0d ac 93 01 00 	mov    %rcx,0x193ac(%rip)        # 203f0 <fwp_foreign_callbacks>
    7044:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    704b:	48 89 0d 8e 93 01 00 	mov    %rcx,0x1938e(%rip)        # 203e0 <fwp_state>
    7052:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7059:	48 89 0d 78 93 01 00 	mov    %rcx,0x19378(%rip)        # 203d8 <fwp_state_len>
    7060:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7067:	48 89 0d 62 93 01 00 	mov    %rcx,0x19362(%rip)        # 203d0 <fwp_state_cap>
    706e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7075:	48 89 0d 4c 93 01 00 	mov    %rcx,0x1934c(%rip)        # 203c8 <fwp_state_owners>
    707c:	e8 0f c4 ff ff       	call   3490 <swapcontext@plt>
    7081:	f3 0f 1e fa          	endbr64
    7085:	e8 d6 fc ff ff       	call   6d60 <fwp_free_zombie>
    708a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7090:	8b 05 72 70 01 00    	mov    0x17072(%rip),%eax        # 1e108 <fwp_slice>
    7096:	85 c0                	test   %eax,%eax
    7098:	74 36                	je     70d0 <fwp_block+0x160>
    709a:	48 83 c4 08          	add    $0x8,%rsp
    709e:	c3                   	ret
    709f:	90                   	nop
    70a0:	e8 bb de ff ff       	call   4f60 <fwp_poll_events>
    70a5:	48 8b 05 7c 76 01 00 	mov    0x1767c(%rip),%rax        # 1e728 <fwp_ready_head>
    70ac:	48 85 c0             	test   %rax,%rax
    70af:	0f 85 db fe ff ff    	jne    6f90 <fwp_block+0x20>
    70b5:	eb e9                	jmp    70a0 <fwp_block+0x130>
    70b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70be:	00 00 
    70c0:	48 c7 05 55 76 01 00 	movq   $0x0,0x17655(%rip)        # 1e720 <fwp_ready_tail>
    70c7:	00 00 00 00 
    70cb:	e9 d7 fe ff ff       	jmp    6fa7 <fwp_block+0x37>
    70d0:	48 8d 3d 4a 30 00 00 	lea    0x304a(%rip),%rdi        # a121 <_IO_stdin_used+0x121>
    70d7:	e8 c4 c2 ff ff       	call   33a0 <getenv@plt>
    70dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    70e1:	48 85 c0             	test   %rax,%rax
    70e4:	74 05                	je     70eb <fwp_block+0x17b>
    70e6:	80 38 00             	cmpb   $0x0,(%rax)
    70e9:	75 0b                	jne    70f6 <fwp_block+0x186>
    70eb:	89 15 17 70 01 00    	mov    %edx,0x17017(%rip)        # 1e108 <fwp_slice>
    70f1:	48 83 c4 08          	add    $0x8,%rsp
    70f5:	c3                   	ret
    70f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    70fb:	31 f6                	xor    %esi,%esi
    70fd:	48 89 c7             	mov    %rax,%rdi
    7100:	e8 4b c4 ff ff       	call   3550 <strtoll@plt>
    7105:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7109:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7110:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7115:	0f 46 d0             	cmovbe %eax,%edx
    7118:	eb d1                	jmp    70eb <fwp_block+0x17b>
    711a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007120 <fwp_caps173>:
    7120:	f3 0f 1e fa          	endbr64
    7124:	85 f6                	test   %esi,%esi
    7126:	74 08                	je     7130 <fwp_caps173+0x10>
    7128:	c3                   	ret
    7129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7130:	48 8b 15 01 8a 01 00 	mov    0x18a01(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7137:	48 89 f8             	mov    %rdi,%rax
    713a:	48 2b 05 cf 89 01 00 	sub    0x189cf(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7141:	48 c1 e2 10          	shl    $0x10,%rdx
    7145:	48 39 d0             	cmp    %rdx,%rax
    7148:	73 de                	jae    7128 <fwp_caps173+0x8>
    714a:	48 89 c2             	mov    %rax,%rdx
    714d:	48 c1 ea 10          	shr    $0x10,%rdx
    7151:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7155:	48 8b 15 fc 89 01 00 	mov    0x189fc(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    715c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7160:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7164:	48 85 c9             	test   %rcx,%rcx
    7167:	74 bf                	je     7128 <fwp_caps173+0x8>
    7169:	0f b6 32             	movzbl (%rdx),%esi
    716c:	40 80 fe 02          	cmp    $0x2,%sil
    7170:	74 2e                	je     71a0 <fwp_caps173+0x80>
    7172:	40 80 fe 01          	cmp    $0x1,%sil
    7176:	75 b0                	jne    7128 <fwp_caps173+0x8>
    7178:	8b 72 18             	mov    0x18(%rdx),%esi
    717b:	0f b7 c0             	movzwl %ax,%eax
    717e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7181:	48 0f af c6          	imul   %rsi,%rax
    7185:	48 c1 e8 20          	shr    $0x20,%rax
    7189:	48 39 d0             	cmp    %rdx,%rax
    718c:	73 9a                	jae    7128 <fwp_caps173+0x8>
    718e:	48 01 c1             	add    %rax,%rcx
    7191:	80 39 01             	cmpb   $0x1,(%rcx)
    7194:	75 92                	jne    7128 <fwp_caps173+0x8>
    7196:	e9 b5 e3 ff ff       	jmp    5550 <fwp_mem_free>
    719b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    71a0:	66 85 c0             	test   %ax,%ax
    71a3:	74 ec                	je     7191 <fwp_caps173+0x71>
    71a5:	c3                   	ret
    71a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71ad:	00 00 00 

00000000000071b0 <fwp_args37>:
    71b0:	f3 0f 1e fa          	endbr64
    71b4:	85 d2                	test   %edx,%edx
    71b6:	74 04                	je     71bc <fwp_args37+0xc>
    71b8:	85 f6                	test   %esi,%esi
    71ba:	74 04                	je     71c0 <fwp_args37+0x10>
    71bc:	c3                   	ret
    71bd:	0f 1f 00             	nopl   (%rax)
    71c0:	48 8b 15 71 89 01 00 	mov    0x18971(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    71c7:	48 8b 07             	mov    (%rdi),%rax
    71ca:	48 2b 05 3f 89 01 00 	sub    0x1893f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    71d1:	48 c1 e2 10          	shl    $0x10,%rdx
    71d5:	48 39 d0             	cmp    %rdx,%rax
    71d8:	73 e2                	jae    71bc <fwp_args37+0xc>
    71da:	48 89 c2             	mov    %rax,%rdx
    71dd:	48 c1 ea 10          	shr    $0x10,%rdx
    71e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71e5:	48 8b 15 6c 89 01 00 	mov    0x1896c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    71ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    71f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    71f4:	48 85 ff             	test   %rdi,%rdi
    71f7:	74 c3                	je     71bc <fwp_args37+0xc>
    71f9:	0f b6 0a             	movzbl (%rdx),%ecx
    71fc:	80 f9 02             	cmp    $0x2,%cl
    71ff:	74 2f                	je     7230 <fwp_args37+0x80>
    7201:	80 f9 01             	cmp    $0x1,%cl
    7204:	75 b6                	jne    71bc <fwp_args37+0xc>
    7206:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7209:	0f b7 c0             	movzwl %ax,%eax
    720c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    720f:	48 0f af c1          	imul   %rcx,%rax
    7213:	48 c1 e8 20          	shr    $0x20,%rax
    7217:	48 39 d0             	cmp    %rdx,%rax
    721a:	73 a0                	jae    71bc <fwp_args37+0xc>
    721c:	48 01 c7             	add    %rax,%rdi
    721f:	0f b6 07             	movzbl (%rdi),%eax
    7222:	84 c0                	test   %al,%al
    7224:	74 96                	je     71bc <fwp_args37+0xc>
    7226:	3c fd                	cmp    $0xfd,%al
    7228:	77 0c                	ja     7236 <fwp_args37+0x86>
    722a:	83 c0 01             	add    $0x1,%eax
    722d:	88 07                	mov    %al,(%rdi)
    722f:	c3                   	ret
    7230:	66 85 c0             	test   %ax,%ax
    7233:	74 ea                	je     721f <fwp_args37+0x6f>
    7235:	c3                   	ret
    7236:	e9 b5 df ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    723b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007240 <fwp_caps37>:
    7240:	f3 0f 1e fa          	endbr64
    7244:	48 83 ec 18          	sub    $0x18,%rsp
    7248:	8b 57 04             	mov    0x4(%rdi),%edx
    724b:	48 89 f8             	mov    %rdi,%rax
    724e:	85 d2                	test   %edx,%edx
    7250:	0f 84 9a 00 00 00    	je     72f0 <fwp_caps37+0xb0>
    7256:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    725a:	85 f6                	test   %esi,%esi
    725c:	0f 85 9e 00 00 00    	jne    7300 <fwp_caps37+0xc0>
    7262:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7267:	e8 44 f7 ff ff       	call   69b0 <fwp_drop4>
    726c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7271:	48 8b 0d c0 88 01 00 	mov    0x188c0(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    7278:	48 89 c2             	mov    %rax,%rdx
    727b:	48 2b 15 8e 88 01 00 	sub    0x1888e(%rip),%rdx        # 1fb10 <fwp_heap+0x13b0>
    7282:	48 c1 e1 10          	shl    $0x10,%rcx
    7286:	48 39 ca             	cmp    %rcx,%rdx
    7289:	73 6d                	jae    72f8 <fwp_caps37+0xb8>
    728b:	48 89 d1             	mov    %rdx,%rcx
    728e:	48 c1 e9 10          	shr    $0x10,%rcx
    7292:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7296:	48 8b 0d bb 88 01 00 	mov    0x188bb(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    729d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    72a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    72a5:	48 85 f6             	test   %rsi,%rsi
    72a8:	74 4e                	je     72f8 <fwp_caps37+0xb8>
    72aa:	0f b6 39             	movzbl (%rcx),%edi
    72ad:	40 80 ff 02          	cmp    $0x2,%dil
    72b1:	0f 84 b9 00 00 00    	je     7370 <fwp_caps37+0x130>
    72b7:	40 80 ff 01          	cmp    $0x1,%dil
    72bb:	75 3b                	jne    72f8 <fwp_caps37+0xb8>
    72bd:	8b 79 18             	mov    0x18(%rcx),%edi
    72c0:	0f b7 d2             	movzwl %dx,%edx
    72c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    72c6:	48 0f af d7          	imul   %rdi,%rdx
    72ca:	48 c1 ea 20          	shr    $0x20,%rdx
    72ce:	48 39 ca             	cmp    %rcx,%rdx
    72d1:	73 25                	jae    72f8 <fwp_caps37+0xb8>
    72d3:	48 01 d6             	add    %rdx,%rsi
    72d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    72d9:	75 1d                	jne    72f8 <fwp_caps37+0xb8>
    72db:	48 89 c7             	mov    %rax,%rdi
    72de:	48 83 c4 18          	add    $0x18,%rsp
    72e2:	e9 69 e2 ff ff       	jmp    5550 <fwp_mem_free>
    72e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ee:	00 00 
    72f0:	85 f6                	test   %esi,%esi
    72f2:	0f 84 79 ff ff ff    	je     7271 <fwp_caps37+0x31>
    72f8:	48 83 c4 18          	add    $0x18,%rsp
    72fc:	c3                   	ret
    72fd:	0f 1f 00             	nopl   (%rax)
    7300:	48 8b 05 31 88 01 00 	mov    0x18831(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    7307:	48 2b 3d 02 88 01 00 	sub    0x18802(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    730e:	48 c1 e0 10          	shl    $0x10,%rax
    7312:	48 39 c7             	cmp    %rax,%rdi
    7315:	73 e1                	jae    72f8 <fwp_caps37+0xb8>
    7317:	48 89 f8             	mov    %rdi,%rax
    731a:	48 c1 e8 10          	shr    $0x10,%rax
    731e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7322:	48 8b 05 2f 88 01 00 	mov    0x1882f(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    7329:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    732d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7331:	48 85 c0             	test   %rax,%rax
    7334:	74 c2                	je     72f8 <fwp_caps37+0xb8>
    7336:	0f b6 0a             	movzbl (%rdx),%ecx
    7339:	80 f9 02             	cmp    $0x2,%cl
    733c:	74 42                	je     7380 <fwp_caps37+0x140>
    733e:	80 f9 01             	cmp    $0x1,%cl
    7341:	75 b5                	jne    72f8 <fwp_caps37+0xb8>
    7343:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7346:	0f b7 ff             	movzwl %di,%edi
    7349:	8b 52 1c             	mov    0x1c(%rdx),%edx
    734c:	48 0f af f9          	imul   %rcx,%rdi
    7350:	48 c1 ef 20          	shr    $0x20,%rdi
    7354:	48 39 d7             	cmp    %rdx,%rdi
    7357:	73 9f                	jae    72f8 <fwp_caps37+0xb8>
    7359:	48 01 f8             	add    %rdi,%rax
    735c:	0f b6 10             	movzbl (%rax),%edx
    735f:	84 d2                	test   %dl,%dl
    7361:	74 95                	je     72f8 <fwp_caps37+0xb8>
    7363:	80 fa fd             	cmp    $0xfd,%dl
    7366:	77 23                	ja     738b <fwp_caps37+0x14b>
    7368:	83 c2 01             	add    $0x1,%edx
    736b:	88 10                	mov    %dl,(%rax)
    736d:	eb 89                	jmp    72f8 <fwp_caps37+0xb8>
    736f:	90                   	nop
    7370:	66 85 d2             	test   %dx,%dx
    7373:	0f 85 7f ff ff ff    	jne    72f8 <fwp_caps37+0xb8>
    7379:	e9 58 ff ff ff       	jmp    72d6 <fwp_caps37+0x96>
    737e:	66 90                	xchg   %ax,%ax
    7380:	66 85 ff             	test   %di,%di
    7383:	0f 85 6f ff ff ff    	jne    72f8 <fwp_caps37+0xb8>
    7389:	eb d1                	jmp    735c <fwp_caps37+0x11c>
    738b:	48 89 c7             	mov    %rax,%rdi
    738e:	48 83 c4 18          	add    $0x18,%rsp
    7392:	e9 59 de ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    739e:	00 00 

00000000000073a0 <fwp_drop0>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	48 8b 15 8d 87 01 00 	mov    0x1878d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    73ab:	48 89 f8             	mov    %rdi,%rax
    73ae:	48 2b 05 5b 87 01 00 	sub    0x1875b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    73b5:	48 c1 e2 10          	shl    $0x10,%rdx
    73b9:	48 39 d0             	cmp    %rdx,%rax
    73bc:	0f 83 36 01 00 00    	jae    74f8 <fwp_drop0+0x158>
    73c2:	48 83 ec 18          	sub    $0x18,%rsp
    73c6:	48 8d 35 93 73 01 00 	lea    0x17393(%rip),%rsi        # 1e760 <fwp_heap>
    73cd:	48 89 c2             	mov    %rax,%rdx
    73d0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    73d7:	48 c1 ea 10          	shr    $0x10,%rdx
    73db:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    73df:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    73e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    73e7:	48 85 d2             	test   %rdx,%rdx
    73ea:	74 42                	je     742e <fwp_drop0+0x8e>
    73ec:	44 0f b6 01          	movzbl (%rcx),%r8d
    73f0:	41 80 f8 02          	cmp    $0x2,%r8b
    73f4:	74 42                	je     7438 <fwp_drop0+0x98>
    73f6:	41 80 f8 01          	cmp    $0x1,%r8b
    73fa:	75 32                	jne    742e <fwp_drop0+0x8e>
    73fc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7400:	0f b7 c0             	movzwl %ax,%eax
    7403:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7406:	49 0f af c0          	imul   %r8,%rax
    740a:	48 c1 e8 20          	shr    $0x20,%rax
    740e:	48 39 c8             	cmp    %rcx,%rax
    7411:	73 1b                	jae    742e <fwp_drop0+0x8e>
    7413:	48 01 c2             	add    %rax,%rdx
    7416:	0f b6 02             	movzbl (%rdx),%eax
    7419:	84 c0                	test   %al,%al
    741b:	74 11                	je     742e <fwp_drop0+0x8e>
    741d:	3c 01                	cmp    $0x1,%al
    741f:	74 27                	je     7448 <fwp_drop0+0xa8>
    7421:	3c ff                	cmp    $0xff,%al
    7423:	0f 84 e7 00 00 00    	je     7510 <fwp_drop0+0x170>
    7429:	83 e8 01             	sub    $0x1,%eax
    742c:	88 02                	mov    %al,(%rdx)
    742e:	48 83 c4 18          	add    $0x18,%rsp
    7432:	c3                   	ret
    7433:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7438:	66 85 c0             	test   %ax,%ax
    743b:	74 d9                	je     7416 <fwp_drop0+0x76>
    743d:	48 83 c4 18          	add    $0x18,%rsp
    7441:	c3                   	ret
    7442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7448:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    744f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7456:	48 89 f8             	mov    %rdi,%rax
    7459:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    745d:	48 29 c8             	sub    %rcx,%rax
    7460:	48 c1 e2 10          	shl    $0x10,%rdx
    7464:	48 39 d0             	cmp    %rdx,%rax
    7467:	73 71                	jae    74da <fwp_drop0+0x13a>
    7469:	49 89 c2             	mov    %rax,%r10
    746c:	49 c1 ea 10          	shr    $0x10,%r10
    7470:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7474:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7478:	4d 8b 51 20          	mov    0x20(%r9),%r10
    747c:	4d 85 d2             	test   %r10,%r10
    747f:	74 59                	je     74da <fwp_drop0+0x13a>
    7481:	45 0f b6 19          	movzbl (%r9),%r11d
    7485:	41 80 fb 02          	cmp    $0x2,%r11b
    7489:	74 75                	je     7500 <fwp_drop0+0x160>
    748b:	41 80 fb 01          	cmp    $0x1,%r11b
    748f:	75 49                	jne    74da <fwp_drop0+0x13a>
    7491:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7495:	0f b7 c0             	movzwl %ax,%eax
    7498:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    749c:	49 0f af c3          	imul   %r11,%rax
    74a0:	48 c1 e8 20          	shr    $0x20,%rax
    74a4:	4c 39 c8             	cmp    %r9,%rax
    74a7:	73 31                	jae    74da <fwp_drop0+0x13a>
    74a9:	49 01 c2             	add    %rax,%r10
    74ac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    74b0:	75 28                	jne    74da <fwp_drop0+0x13a>
    74b2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    74b7:	e8 94 e0 ff ff       	call   5550 <fwp_mem_free>
    74bc:	48 8d 35 9d 72 01 00 	lea    0x1729d(%rip),%rsi        # 1e760 <fwp_heap>
    74c3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    74c8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    74cf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    74d6:	48 c1 e2 10          	shl    $0x10,%rdx
    74da:	4c 89 c0             	mov    %r8,%rax
    74dd:	48 29 c8             	sub    %rcx,%rax
    74e0:	48 39 d0             	cmp    %rdx,%rax
    74e3:	0f 83 45 ff ff ff    	jae    742e <fwp_drop0+0x8e>
    74e9:	4c 89 c7             	mov    %r8,%rdi
    74ec:	e9 dc fe ff ff       	jmp    73cd <fwp_drop0+0x2d>
    74f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74f8:	c3                   	ret
    74f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7500:	66 85 c0             	test   %ax,%ax
    7503:	75 d5                	jne    74da <fwp_drop0+0x13a>
    7505:	eb a5                	jmp    74ac <fwp_drop0+0x10c>
    7507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    750e:	00 00 
    7510:	48 89 d0             	mov    %rdx,%rax
    7513:	48 c1 e8 11          	shr    $0x11,%rax
    7517:	48 31 d0             	xor    %rdx,%rax
    751a:	48 89 c1             	mov    %rax,%rcx
    751d:	48 c1 e9 09          	shr    $0x9,%rcx
    7521:	48 31 c8             	xor    %rcx,%rax
    7524:	0f b6 c8             	movzbl %al,%ecx
    7527:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    752e:	00 
    752f:	48 85 c0             	test   %rax,%rax
    7532:	75 15                	jne    7549 <fwp_drop0+0x1a9>
    7534:	eb 4e                	jmp    7584 <fwp_drop0+0x1e4>
    7536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    753d:	00 00 00 
    7540:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7544:	48 85 c0             	test   %rax,%rax
    7547:	74 3b                	je     7584 <fwp_drop0+0x1e4>
    7549:	48 89 c1             	mov    %rax,%rcx
    754c:	48 39 10             	cmp    %rdx,(%rax)
    754f:	75 ef                	jne    7540 <fwp_drop0+0x1a0>
    7551:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7555:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7559:	48 89 48 08          	mov    %rcx,0x8(%rax)
    755d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7564:	0f 85 c4 fe ff ff    	jne    742e <fwp_drop0+0x8e>
    756a:	48 89 d7             	mov    %rdx,%rdi
    756d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7572:	e8 99 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    7577:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    757c:	c6 02 fe             	movb   $0xfe,(%rdx)
    757f:	e9 aa fe ff ff       	jmp    742e <fwp_drop0+0x8e>
    7584:	48 8d 3d ed 31 00 00 	lea    0x31ed(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    758b:	e8 10 cc ff ff       	call   41a0 <fwp_trap>

0000000000007590 <fwp_drop1>:
    7590:	f3 0f 1e fa          	endbr64
    7594:	48 8b 15 9d 85 01 00 	mov    0x1859d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    759b:	48 89 f8             	mov    %rdi,%rax
    759e:	48 2b 05 6b 85 01 00 	sub    0x1856b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    75a5:	48 c1 e2 10          	shl    $0x10,%rdx
    75a9:	48 39 d0             	cmp    %rdx,%rax
    75ac:	0f 83 36 01 00 00    	jae    76e8 <fwp_drop1+0x158>
    75b2:	48 83 ec 18          	sub    $0x18,%rsp
    75b6:	48 8d 35 a3 71 01 00 	lea    0x171a3(%rip),%rsi        # 1e760 <fwp_heap>
    75bd:	48 89 c2             	mov    %rax,%rdx
    75c0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    75c7:	48 c1 ea 10          	shr    $0x10,%rdx
    75cb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    75cf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    75d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    75d7:	48 85 d2             	test   %rdx,%rdx
    75da:	74 42                	je     761e <fwp_drop1+0x8e>
    75dc:	44 0f b6 01          	movzbl (%rcx),%r8d
    75e0:	41 80 f8 02          	cmp    $0x2,%r8b
    75e4:	74 42                	je     7628 <fwp_drop1+0x98>
    75e6:	41 80 f8 01          	cmp    $0x1,%r8b
    75ea:	75 32                	jne    761e <fwp_drop1+0x8e>
    75ec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    75f0:	0f b7 c0             	movzwl %ax,%eax
    75f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    75f6:	49 0f af c0          	imul   %r8,%rax
    75fa:	48 c1 e8 20          	shr    $0x20,%rax
    75fe:	48 39 c8             	cmp    %rcx,%rax
    7601:	73 1b                	jae    761e <fwp_drop1+0x8e>
    7603:	48 01 c2             	add    %rax,%rdx
    7606:	0f b6 02             	movzbl (%rdx),%eax
    7609:	84 c0                	test   %al,%al
    760b:	74 11                	je     761e <fwp_drop1+0x8e>
    760d:	3c 01                	cmp    $0x1,%al
    760f:	74 27                	je     7638 <fwp_drop1+0xa8>
    7611:	3c ff                	cmp    $0xff,%al
    7613:	0f 84 e7 00 00 00    	je     7700 <fwp_drop1+0x170>
    7619:	83 e8 01             	sub    $0x1,%eax
    761c:	88 02                	mov    %al,(%rdx)
    761e:	48 83 c4 18          	add    $0x18,%rsp
    7622:	c3                   	ret
    7623:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7628:	66 85 c0             	test   %ax,%ax
    762b:	74 d9                	je     7606 <fwp_drop1+0x76>
    762d:	48 83 c4 18          	add    $0x18,%rsp
    7631:	c3                   	ret
    7632:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7638:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    763f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7646:	48 89 f8             	mov    %rdi,%rax
    7649:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    764d:	48 29 c8             	sub    %rcx,%rax
    7650:	48 c1 e2 10          	shl    $0x10,%rdx
    7654:	48 39 d0             	cmp    %rdx,%rax
    7657:	73 71                	jae    76ca <fwp_drop1+0x13a>
    7659:	49 89 c2             	mov    %rax,%r10
    765c:	49 c1 ea 10          	shr    $0x10,%r10
    7660:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7664:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7668:	4d 8b 51 20          	mov    0x20(%r9),%r10
    766c:	4d 85 d2             	test   %r10,%r10
    766f:	74 59                	je     76ca <fwp_drop1+0x13a>
    7671:	45 0f b6 19          	movzbl (%r9),%r11d
    7675:	41 80 fb 02          	cmp    $0x2,%r11b
    7679:	74 75                	je     76f0 <fwp_drop1+0x160>
    767b:	41 80 fb 01          	cmp    $0x1,%r11b
    767f:	75 49                	jne    76ca <fwp_drop1+0x13a>
    7681:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7685:	0f b7 c0             	movzwl %ax,%eax
    7688:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    768c:	49 0f af c3          	imul   %r11,%rax
    7690:	48 c1 e8 20          	shr    $0x20,%rax
    7694:	4c 39 c8             	cmp    %r9,%rax
    7697:	73 31                	jae    76ca <fwp_drop1+0x13a>
    7699:	49 01 c2             	add    %rax,%r10
    769c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    76a0:	75 28                	jne    76ca <fwp_drop1+0x13a>
    76a2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    76a7:	e8 a4 de ff ff       	call   5550 <fwp_mem_free>
    76ac:	48 8d 35 ad 70 01 00 	lea    0x170ad(%rip),%rsi        # 1e760 <fwp_heap>
    76b3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    76b8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    76bf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    76c6:	48 c1 e2 10          	shl    $0x10,%rdx
    76ca:	4c 89 c0             	mov    %r8,%rax
    76cd:	48 29 c8             	sub    %rcx,%rax
    76d0:	48 39 d0             	cmp    %rdx,%rax
    76d3:	0f 83 45 ff ff ff    	jae    761e <fwp_drop1+0x8e>
    76d9:	4c 89 c7             	mov    %r8,%rdi
    76dc:	e9 dc fe ff ff       	jmp    75bd <fwp_drop1+0x2d>
    76e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76e8:	c3                   	ret
    76e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76f0:	66 85 c0             	test   %ax,%ax
    76f3:	75 d5                	jne    76ca <fwp_drop1+0x13a>
    76f5:	eb a5                	jmp    769c <fwp_drop1+0x10c>
    76f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76fe:	00 00 
    7700:	48 89 d0             	mov    %rdx,%rax
    7703:	48 c1 e8 11          	shr    $0x11,%rax
    7707:	48 31 d0             	xor    %rdx,%rax
    770a:	48 89 c1             	mov    %rax,%rcx
    770d:	48 c1 e9 09          	shr    $0x9,%rcx
    7711:	48 31 c8             	xor    %rcx,%rax
    7714:	0f b6 c8             	movzbl %al,%ecx
    7717:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    771e:	00 
    771f:	48 85 c0             	test   %rax,%rax
    7722:	75 25                	jne    7749 <fwp_drop1+0x1b9>
    7724:	eb 5e                	jmp    7784 <fwp_drop1+0x1f4>
    7726:	0f 1f 40 00          	nopl   0x0(%rax)
    772a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7731:	00 00 00 00 
    7735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    773c:	00 00 00 00 
    7740:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7744:	48 85 c0             	test   %rax,%rax
    7747:	74 3b                	je     7784 <fwp_drop1+0x1f4>
    7749:	48 89 c1             	mov    %rax,%rcx
    774c:	48 39 10             	cmp    %rdx,(%rax)
    774f:	75 ef                	jne    7740 <fwp_drop1+0x1b0>
    7751:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7755:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7759:	48 89 48 08          	mov    %rcx,0x8(%rax)
    775d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7764:	0f 85 b4 fe ff ff    	jne    761e <fwp_drop1+0x8e>
    776a:	48 89 d7             	mov    %rdx,%rdi
    776d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7772:	e8 99 db ff ff       	call   5310 <fwp_rc_forget_slot>
    7777:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    777c:	c6 02 fe             	movb   $0xfe,(%rdx)
    777f:	e9 9a fe ff ff       	jmp    761e <fwp_drop1+0x8e>
    7784:	48 8d 3d ed 2f 00 00 	lea    0x2fed(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    778b:	e8 10 ca ff ff       	call   41a0 <fwp_trap>

0000000000007790 <fwp_drop10>:
    7790:	48 8b 0d a1 83 01 00 	mov    0x183a1(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    7797:	48 89 f8             	mov    %rdi,%rax
    779a:	48 2b 05 6f 83 01 00 	sub    0x1836f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    77a1:	48 c1 e1 10          	shl    $0x10,%rcx
    77a5:	48 39 c8             	cmp    %rcx,%rax
    77a8:	0f 83 c2 01 00 00    	jae    7970 <fwp_drop10+0x1e0>
    77ae:	48 83 ec 18          	sub    $0x18,%rsp
    77b2:	48 89 fa             	mov    %rdi,%rdx
    77b5:	48 8d 35 a4 6f 01 00 	lea    0x16fa4(%rip),%rsi        # 1e760 <fwp_heap>
    77bc:	48 89 c1             	mov    %rax,%rcx
    77bf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    77c6:	48 c1 e9 10          	shr    $0x10,%rcx
    77ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    77ce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    77d2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    77d6:	48 85 c9             	test   %rcx,%rcx
    77d9:	74 46                	je     7821 <fwp_drop10+0x91>
    77db:	44 0f b6 0f          	movzbl (%rdi),%r9d
    77df:	41 80 f9 02          	cmp    $0x2,%r9b
    77e3:	0f 84 d7 00 00 00    	je     78c0 <fwp_drop10+0x130>
    77e9:	41 80 f9 01          	cmp    $0x1,%r9b
    77ed:	75 32                	jne    7821 <fwp_drop10+0x91>
    77ef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    77f3:	0f b7 c0             	movzwl %ax,%eax
    77f6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    77f9:	49 0f af c1          	imul   %r9,%rax
    77fd:	48 c1 e8 20          	shr    $0x20,%rax
    7801:	48 39 f8             	cmp    %rdi,%rax
    7804:	73 1b                	jae    7821 <fwp_drop10+0x91>
    7806:	48 01 c1             	add    %rax,%rcx
    7809:	0f b6 01             	movzbl (%rcx),%eax
    780c:	84 c0                	test   %al,%al
    780e:	74 11                	je     7821 <fwp_drop10+0x91>
    7810:	3c 01                	cmp    $0x1,%al
    7812:	74 1c                	je     7830 <fwp_drop10+0xa0>
    7814:	3c ff                	cmp    $0xff,%al
    7816:	0f 84 5c 01 00 00    	je     7978 <fwp_drop10+0x1e8>
    781c:	83 e8 01             	sub    $0x1,%eax
    781f:	88 01                	mov    %al,(%rcx)
    7821:	48 83 c4 18          	add    $0x18,%rsp
    7825:	c3                   	ret
    7826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    782d:	00 00 00 
    7830:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7837:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    783e:	48 89 d0             	mov    %rdx,%rax
    7841:	49 89 d1             	mov    %rdx,%r9
    7844:	48 c1 e1 10          	shl    $0x10,%rcx
    7848:	48 29 f8             	sub    %rdi,%rax
    784b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    784f:	78 7f                	js     78d0 <fwp_drop10+0x140>
    7851:	48 39 c8             	cmp    %rcx,%rax
    7854:	73 cb                	jae    7821 <fwp_drop10+0x91>
    7856:	48 89 c1             	mov    %rax,%rcx
    7859:	48 c1 e9 10          	shr    $0x10,%rcx
    785d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7861:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7865:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7869:	48 85 f6             	test   %rsi,%rsi
    786c:	74 b3                	je     7821 <fwp_drop10+0x91>
    786e:	0f b6 39             	movzbl (%rcx),%edi
    7871:	40 80 ff 02          	cmp    $0x2,%dil
    7875:	74 39                	je     78b0 <fwp_drop10+0x120>
    7877:	40 80 ff 01          	cmp    $0x1,%dil
    787b:	75 a4                	jne    7821 <fwp_drop10+0x91>
    787d:	8b 79 18             	mov    0x18(%rcx),%edi
    7880:	0f b7 c0             	movzwl %ax,%eax
    7883:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7886:	48 0f af c7          	imul   %rdi,%rax
    788a:	48 c1 e8 20          	shr    $0x20,%rax
    788e:	48 39 c8             	cmp    %rcx,%rax
    7891:	73 8e                	jae    7821 <fwp_drop10+0x91>
    7893:	48 01 c6             	add    %rax,%rsi
    7896:	80 3e 01             	cmpb   $0x1,(%rsi)
    7899:	75 86                	jne    7821 <fwp_drop10+0x91>
    789b:	48 89 d7             	mov    %rdx,%rdi
    789e:	48 83 c4 18          	add    $0x18,%rsp
    78a2:	e9 a9 dc ff ff       	jmp    5550 <fwp_mem_free>
    78a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78ae:	00 00 
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 e1                	je     7896 <fwp_drop10+0x106>
    78b5:	48 83 c4 18          	add    $0x18,%rsp
    78b9:	c3                   	ret
    78ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78c0:	66 85 c0             	test   %ax,%ax
    78c3:	0f 84 40 ff ff ff    	je     7809 <fwp_drop10+0x79>
    78c9:	48 83 c4 18          	add    $0x18,%rsp
    78cd:	c3                   	ret
    78ce:	66 90                	xchg   %ax,%ax
    78d0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    78d4:	48 39 c8             	cmp    %rcx,%rax
    78d7:	73 74                	jae    794d <fwp_drop10+0x1bd>
    78d9:	49 89 c2             	mov    %rax,%r10
    78dc:	49 c1 ea 10          	shr    $0x10,%r10
    78e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    78e4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    78e8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    78ec:	4d 85 d2             	test   %r10,%r10
    78ef:	74 5c                	je     794d <fwp_drop10+0x1bd>
    78f1:	45 0f b6 18          	movzbl (%r8),%r11d
    78f5:	41 80 fb 02          	cmp    $0x2,%r11b
    78f9:	74 6d                	je     7968 <fwp_drop10+0x1d8>
    78fb:	41 80 fb 01          	cmp    $0x1,%r11b
    78ff:	75 4c                	jne    794d <fwp_drop10+0x1bd>
    7901:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7905:	0f b7 c0             	movzwl %ax,%eax
    7908:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    790c:	49 0f af c3          	imul   %r11,%rax
    7910:	48 c1 e8 20          	shr    $0x20,%rax
    7914:	4c 39 c0             	cmp    %r8,%rax
    7917:	73 34                	jae    794d <fwp_drop10+0x1bd>
    7919:	49 01 c2             	add    %rax,%r10
    791c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7920:	75 2b                	jne    794d <fwp_drop10+0x1bd>
    7922:	4c 89 cf             	mov    %r9,%rdi
    7925:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    792a:	e8 21 dc ff ff       	call   5550 <fwp_mem_free>
    792f:	48 8d 35 2a 6e 01 00 	lea    0x16e2a(%rip),%rsi        # 1e760 <fwp_heap>
    7936:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    793b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7942:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7949:	48 c1 e1 10          	shl    $0x10,%rcx
    794d:	48 89 d0             	mov    %rdx,%rax
    7950:	48 29 f8             	sub    %rdi,%rax
    7953:	48 39 c8             	cmp    %rcx,%rax
    7956:	0f 82 60 fe ff ff    	jb     77bc <fwp_drop10+0x2c>
    795c:	e9 c0 fe ff ff       	jmp    7821 <fwp_drop10+0x91>
    7961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7968:	66 85 c0             	test   %ax,%ax
    796b:	75 e0                	jne    794d <fwp_drop10+0x1bd>
    796d:	eb ad                	jmp    791c <fwp_drop10+0x18c>
    796f:	90                   	nop
    7970:	c3                   	ret
    7971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7978:	48 89 c8             	mov    %rcx,%rax
    797b:	48 c1 e8 11          	shr    $0x11,%rax
    797f:	48 31 c8             	xor    %rcx,%rax
    7982:	48 89 c2             	mov    %rax,%rdx
    7985:	48 c1 ea 09          	shr    $0x9,%rdx
    7989:	48 31 d0             	xor    %rdx,%rax
    798c:	0f b6 d0             	movzbl %al,%edx
    798f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7996:	00 
    7997:	48 85 c0             	test   %rax,%rax
    799a:	75 0d                	jne    79a9 <fwp_drop10+0x219>
    799c:	eb 46                	jmp    79e4 <fwp_drop10+0x254>
    799e:	66 90                	xchg   %ax,%ax
    79a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    79a4:	48 85 c0             	test   %rax,%rax
    79a7:	74 3b                	je     79e4 <fwp_drop10+0x254>
    79a9:	48 89 c2             	mov    %rax,%rdx
    79ac:	48 39 08             	cmp    %rcx,(%rax)
    79af:	75 ef                	jne    79a0 <fwp_drop10+0x210>
    79b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    79b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    79bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    79c4:	0f 85 57 fe ff ff    	jne    7821 <fwp_drop10+0x91>
    79ca:	48 89 cf             	mov    %rcx,%rdi
    79cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    79d2:	e8 39 d9 ff ff       	call   5310 <fwp_rc_forget_slot>
    79d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    79dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    79df:	e9 3d fe ff ff       	jmp    7821 <fwp_drop10+0x91>
    79e4:	48 8d 3d 8d 2d 00 00 	lea    0x2d8d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    79eb:	e8 b0 c7 ff ff       	call   41a0 <fwp_trap>

00000000000079f0 <f37>:
    79f0:	41 57                	push   %r15
    79f2:	41 56                	push   %r14
    79f4:	41 55                	push   %r13
    79f6:	41 54                	push   %r12
    79f8:	55                   	push   %rbp
    79f9:	53                   	push   %rbx
    79fa:	48 83 ec 38          	sub    $0x38,%rsp
    79fe:	48 8b 15 33 81 01 00 	mov    0x18133(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7a05:	48 8b 0d 04 81 01 00 	mov    0x18104(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    7a0c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7a13:	00 00 
    7a15:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7a1a:	49 89 fd             	mov    %rdi,%r13
    7a1d:	48 c1 e2 10          	shl    $0x10,%rdx
    7a21:	48 85 ff             	test   %rdi,%rdi
    7a24:	0f 84 0c 03 00 00    	je     7d36 <f37+0x346>
    7a2a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7a2e:	48 89 d8             	mov    %rbx,%rax
    7a31:	48 29 c8             	sub    %rcx,%rax
    7a34:	48 39 d0             	cmp    %rdx,%rax
    7a37:	0f 83 c3 03 00 00    	jae    7e00 <f37+0x410>
    7a3d:	48 89 c2             	mov    %rax,%rdx
    7a40:	48 c1 ea 10          	shr    $0x10,%rdx
    7a44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a48:	48 8b 15 09 81 01 00 	mov    0x18109(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7a4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a53:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a57:	48 85 ff             	test   %rdi,%rdi
    7a5a:	0f 84 a0 03 00 00    	je     7e00 <f37+0x410>
    7a60:	0f b6 0a             	movzbl (%rdx),%ecx
    7a63:	80 f9 02             	cmp    $0x2,%cl
    7a66:	0f 84 a4 02 00 00    	je     7d10 <f37+0x320>
    7a6c:	80 f9 01             	cmp    $0x1,%cl
    7a6f:	75 24                	jne    7a95 <f37+0xa5>
    7a71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a74:	0f b7 c0             	movzwl %ax,%eax
    7a77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a7a:	48 0f af c1          	imul   %rcx,%rax
    7a7e:	48 c1 e8 20          	shr    $0x20,%rax
    7a82:	48 39 d0             	cmp    %rdx,%rax
    7a85:	73 0e                	jae    7a95 <f37+0xa5>
    7a87:	48 01 c7             	add    %rax,%rdi
    7a8a:	0f b6 07             	movzbl (%rdi),%eax
    7a8d:	84 c0                	test   %al,%al
    7a8f:	0f 85 1b 03 00 00    	jne    7db0 <f37+0x3c0>
    7a95:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7a9a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7a9e:	ba 01 00 00 00       	mov    $0x1,%edx
    7aa3:	48 85 db             	test   %rbx,%rbx
    7aa6:	74 15                	je     7abd <f37+0xcd>
    7aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7aaf:	00 
    7ab0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7ab4:	48 83 c2 01          	add    $0x1,%rdx
    7ab8:	48 85 db             	test   %rbx,%rbx
    7abb:	75 f3                	jne    7ab0 <f37+0xc0>
    7abd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7ac2:	48 85 c0             	test   %rax,%rax
    7ac5:	0f 84 65 03 00 00    	je     7e30 <f37+0x440>
    7acb:	31 db                	xor    %ebx,%ebx
    7acd:	0f 1f 00             	nopl   (%rax)
    7ad0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7ad4:	48 83 c3 01          	add    $0x1,%rbx
    7ad8:	48 85 c0             	test   %rax,%rax
    7adb:	75 f3                	jne    7ad0 <f37+0xe0>
    7add:	48 39 d3             	cmp    %rdx,%rbx
    7ae0:	48 0f 47 da          	cmova  %rdx,%rbx
    7ae4:	48 89 d8             	mov    %rbx,%rax
    7ae7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7aeb:	0f 85 e3 03 00 00    	jne    7ed4 <f37+0x4e4>
    7af1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7af5:	be 02 00 00 00       	mov    $0x2,%esi
    7afa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7b01:	00 
    7b02:	e8 49 df ff ff       	call   5a50 <fwp_heap_alloc>
    7b07:	48 89 28             	mov    %rbp,(%rax)
    7b0a:	48 8b 15 27 80 01 00 	mov    0x18027(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7b11:	49 89 c4             	mov    %rax,%r12
    7b14:	48 2b 05 f5 7f 01 00 	sub    0x17ff5(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7b1b:	48 c1 e2 10          	shl    $0x10,%rdx
    7b1f:	48 39 d0             	cmp    %rdx,%rax
    7b22:	73 57                	jae    7b7b <f37+0x18b>
    7b24:	48 89 c2             	mov    %rax,%rdx
    7b27:	48 c1 ea 10          	shr    $0x10,%rdx
    7b2b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b2f:	48 8b 15 22 80 01 00 	mov    0x18022(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7b36:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b3a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7b3e:	48 85 ed             	test   %rbp,%rbp
    7b41:	74 38                	je     7b7b <f37+0x18b>
    7b43:	0f b6 0a             	movzbl (%rdx),%ecx
    7b46:	80 f9 02             	cmp    $0x2,%cl
    7b49:	0f 84 a1 02 00 00    	je     7df0 <f37+0x400>
    7b4f:	80 f9 01             	cmp    $0x1,%cl
    7b52:	75 27                	jne    7b7b <f37+0x18b>
    7b54:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b57:	0f b7 c0             	movzwl %ax,%eax
    7b5a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b5d:	48 0f af c1          	imul   %rcx,%rax
    7b61:	48 c1 e8 20          	shr    $0x20,%rax
    7b65:	48 39 d0             	cmp    %rdx,%rax
    7b68:	73 11                	jae    7b7b <f37+0x18b>
    7b6a:	48 01 c5             	add    %rax,%rbp
    7b6d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7b71:	0f 84 29 03 00 00    	je     7ea0 <f37+0x4b0>
    7b77:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7b7b:	48 85 db             	test   %rbx,%rbx
    7b7e:	74 5d                	je     7bdd <f37+0x1ed>
    7b80:	48 c1 e3 04          	shl    $0x4,%rbx
    7b84:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7b89:	4c 89 e5             	mov    %r12,%rbp
    7b8c:	4d 89 ee             	mov    %r13,%r14
    7b8f:	4c 01 e3             	add    %r12,%rbx
    7b92:	0f 1f 00             	nopl   (%rax)
    7b95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b9c:	00 00 00 00 
    7ba0:	49 8b 46 08          	mov    0x8(%r14),%rax
    7ba4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ba8:	48 83 c5 10          	add    $0x10,%rbp
    7bac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7bb1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7bb5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7bb9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7bbe:	e8 5d e4 ff ff       	call   6020 <w120>
    7bc3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7bc8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7bcc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7bd0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7bd4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    7bd8:	48 39 eb             	cmp    %rbp,%rbx
    7bdb:	75 c3                	jne    7ba0 <f37+0x1b0>
    7bdd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7be2:	31 db                	xor    %ebx,%ebx
    7be4:	e8 c7 ed ff ff       	call   69b0 <fwp_drop4>
    7be9:	4c 89 ef             	mov    %r13,%rdi
    7bec:	e8 bf ed ff ff       	call   69b0 <fwp_drop4>
    7bf1:	4d 8b 2c 24          	mov    (%r12),%r13
    7bf5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7bf9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    7c00:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    7c07:	4d 85 ed             	test   %r13,%r13
    7c0a:	74 3f                	je     7c4b <f37+0x25b>
    7c0c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c10:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    7c17:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    7c1c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    7c23:	00 f0 3f 
    7c26:	48 83 c3 02          	add    $0x2,%rbx
    7c2a:	48 89 ce             	mov    %rcx,%rsi
    7c2d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7c33:	e8 68 e0 ff ff       	call   5ca0 <fwp_p_ad_push>
    7c38:	4c 39 eb             	cmp    %r13,%rbx
    7c3b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7c41:	48 89 c7             	mov    %rax,%rdi
    7c44:	72 ca                	jb     7c10 <f37+0x220>
    7c46:	66 49 0f 7e c5       	movq   %xmm0,%r13
    7c4b:	4c 89 e7             	mov    %r12,%rdi
    7c4e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7c53:	e8 38 fb ff ff       	call   7790 <fwp_drop10>
    7c58:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c5d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7c62:	31 ff                	xor    %edi,%edi
    7c64:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    7c69:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7c6e:	e8 fd de ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7c73:	48 8b 15 be 7e 01 00 	mov    0x17ebe(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7c7a:	48 89 c5             	mov    %rax,%rbp
    7c7d:	48 2b 05 8c 7e 01 00 	sub    0x17e8c(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7c84:	48 c1 e2 10          	shl    $0x10,%rdx
    7c88:	48 39 d0             	cmp    %rdx,%rax
    7c8b:	73 55                	jae    7ce2 <f37+0x2f2>
    7c8d:	48 89 c2             	mov    %rax,%rdx
    7c90:	48 c1 ea 10          	shr    $0x10,%rdx
    7c94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c98:	48 8b 15 b9 7e 01 00 	mov    0x17eb9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7c9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ca3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7ca7:	48 85 db             	test   %rbx,%rbx
    7caa:	74 36                	je     7ce2 <f37+0x2f2>
    7cac:	0f b6 0a             	movzbl (%rdx),%ecx
    7caf:	80 f9 02             	cmp    $0x2,%cl
    7cb2:	0f 84 20 01 00 00    	je     7dd8 <f37+0x3e8>
    7cb8:	80 f9 01             	cmp    $0x1,%cl
    7cbb:	75 25                	jne    7ce2 <f37+0x2f2>
    7cbd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7cc0:	0f b7 c0             	movzwl %ax,%eax
    7cc3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cc6:	48 0f af c1          	imul   %rcx,%rax
    7cca:	48 c1 e8 20          	shr    $0x20,%rax
    7cce:	48 39 d0             	cmp    %rdx,%rax
    7cd1:	73 0f                	jae    7ce2 <f37+0x2f2>
    7cd3:	48 01 c3             	add    %rax,%rbx
    7cd6:	80 3b ff             	cmpb   $0xff,(%rbx)
    7cd9:	0f 84 b4 01 00 00    	je     7e93 <f37+0x4a3>
    7cdf:	c6 03 01             	movb   $0x1,(%rbx)
    7ce2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7ce7:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7cee:	00 00 
    7cf0:	0f 85 d9 01 00 00    	jne    7ecf <f37+0x4df>
    7cf6:	48 83 c4 38          	add    $0x38,%rsp
    7cfa:	48 89 e8             	mov    %rbp,%rax
    7cfd:	5b                   	pop    %rbx
    7cfe:	5d                   	pop    %rbp
    7cff:	41 5c                	pop    %r12
    7d01:	41 5d                	pop    %r13
    7d03:	41 5e                	pop    %r14
    7d05:	41 5f                	pop    %r15
    7d07:	c3                   	ret
    7d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7d0f:	00 
    7d10:	66 85 c0             	test   %ax,%ax
    7d13:	0f 85 7c fd ff ff    	jne    7a95 <f37+0xa5>
    7d19:	0f b6 07             	movzbl (%rdi),%eax
    7d1c:	84 c0                	test   %al,%al
    7d1e:	0f 84 71 fd ff ff    	je     7a95 <f37+0xa5>
    7d24:	3c fd                	cmp    $0xfd,%al
    7d26:	0f 87 99 01 00 00    	ja     7ec5 <f37+0x4d5>
    7d2c:	83 c0 01             	add    $0x1,%eax
    7d2f:	88 07                	mov    %al,(%rdi)
    7d31:	e9 5f fd ff ff       	jmp    7a95 <f37+0xa5>
    7d36:	48 f7 d9             	neg    %rcx
    7d39:	48 39 d1             	cmp    %rdx,%rcx
    7d3c:	0f 83 ee 00 00 00    	jae    7e30 <f37+0x440>
    7d42:	48 89 c8             	mov    %rcx,%rax
    7d45:	48 c1 e8 10          	shr    $0x10,%rax
    7d49:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d4d:	48 8b 05 04 7e 01 00 	mov    0x17e04(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    7d54:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d58:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d5c:	48 85 ff             	test   %rdi,%rdi
    7d5f:	0f 84 cb 00 00 00    	je     7e30 <f37+0x440>
    7d65:	0f b6 02             	movzbl (%rdx),%eax
    7d68:	3c 02                	cmp    $0x2,%al
    7d6a:	0f 84 9a 00 00 00    	je     7e0a <f37+0x41a>
    7d70:	3c 01                	cmp    $0x1,%al
    7d72:	0f 85 b8 00 00 00    	jne    7e30 <f37+0x440>
    7d78:	0f b7 c1             	movzwl %cx,%eax
    7d7b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d81:	48 0f af c1          	imul   %rcx,%rax
    7d85:	48 c1 e8 20          	shr    $0x20,%rax
    7d89:	48 39 d0             	cmp    %rdx,%rax
    7d8c:	0f 83 9e 00 00 00    	jae    7e30 <f37+0x440>
    7d92:	48 01 c7             	add    %rax,%rdi
    7d95:	0f b6 07             	movzbl (%rdi),%eax
    7d98:	84 c0                	test   %al,%al
    7d9a:	0f 84 90 00 00 00    	je     7e30 <f37+0x440>
    7da0:	31 db                	xor    %ebx,%ebx
    7da2:	0f 1f 00             	nopl   (%rax)
    7da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dac:	00 00 00 00 
    7db0:	3c fd                	cmp    $0xfd,%al
    7db2:	0f 87 f5 00 00 00    	ja     7ead <f37+0x4bd>
    7db8:	83 c0 01             	add    $0x1,%eax
    7dbb:	88 07                	mov    %al,(%rdi)
    7dbd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7dc2:	31 d2                	xor    %edx,%edx
    7dc4:	4d 85 ed             	test   %r13,%r13
    7dc7:	0f 85 cd fc ff ff    	jne    7a9a <f37+0xaa>
    7dcd:	e9 eb fc ff ff       	jmp    7abd <f37+0xcd>
    7dd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7dd8:	66 85 c0             	test   %ax,%ax
    7ddb:	0f 85 01 ff ff ff    	jne    7ce2 <f37+0x2f2>
    7de1:	e9 f0 fe ff ff       	jmp    7cd6 <f37+0x2e6>
    7de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ded:	00 00 00 
    7df0:	66 85 c0             	test   %ax,%ax
    7df3:	0f 85 82 fd ff ff    	jne    7b7b <f37+0x18b>
    7df9:	e9 6f fd ff ff       	jmp    7b6d <f37+0x17d>
    7dfe:	66 90                	xchg   %ax,%ax
    7e00:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e05:	e9 94 fc ff ff       	jmp    7a9e <f37+0xae>
    7e0a:	66 85 c9             	test   %cx,%cx
    7e0d:	75 21                	jne    7e30 <f37+0x440>
    7e0f:	0f b6 07             	movzbl (%rdi),%eax
    7e12:	84 c0                	test   %al,%al
    7e14:	74 1a                	je     7e30 <f37+0x440>
    7e16:	3c fd                	cmp    $0xfd,%al
    7e18:	0f 87 c2 00 00 00    	ja     7ee0 <f37+0x4f0>
    7e1e:	83 c0 01             	add    $0x1,%eax
    7e21:	88 07                	mov    %al,(%rdi)
    7e23:	66 90                	xchg   %ax,%ax
    7e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e2c:	00 00 00 00 
    7e30:	be 02 00 00 00       	mov    $0x2,%esi
    7e35:	bf 08 00 00 00       	mov    $0x8,%edi
    7e3a:	e8 11 dc ff ff       	call   5a50 <fwp_heap_alloc>
    7e3f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e46:	48 8b 15 eb 7c 01 00 	mov    0x17ceb(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7e4d:	49 89 c4             	mov    %rax,%r12
    7e50:	48 2b 05 b9 7c 01 00 	sub    0x17cb9(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7e57:	48 c1 e2 10          	shl    $0x10,%rdx
    7e5b:	48 39 d0             	cmp    %rdx,%rax
    7e5e:	73 57                	jae    7eb7 <f37+0x4c7>
    7e60:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7e67:	00 00 
    7e69:	48 89 c2             	mov    %rax,%rdx
    7e6c:	48 c1 ea 10          	shr    $0x10,%rdx
    7e70:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e74:	48 8b 15 dd 7c 01 00 	mov    0x17cdd(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7e7b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e7f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e83:	48 85 ed             	test   %rbp,%rbp
    7e86:	0f 84 51 fd ff ff    	je     7bdd <f37+0x1ed>
    7e8c:	31 db                	xor    %ebx,%ebx
    7e8e:	e9 b0 fc ff ff       	jmp    7b43 <f37+0x153>
    7e93:	48 89 df             	mov    %rbx,%rdi
    7e96:	e8 75 d4 ff ff       	call   5310 <fwp_rc_forget_slot>
    7e9b:	e9 3f fe ff ff       	jmp    7cdf <f37+0x2ef>
    7ea0:	48 89 ef             	mov    %rbp,%rdi
    7ea3:	e8 68 d4 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ea8:	e9 ca fc ff ff       	jmp    7b77 <f37+0x187>
    7ead:	e8 3e d3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7eb2:	e9 06 ff ff ff       	jmp    7dbd <f37+0x3cd>
    7eb7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7ebe:	00 00 
    7ec0:	e9 18 fd ff ff       	jmp    7bdd <f37+0x1ed>
    7ec5:	e8 26 d3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7eca:	e9 c6 fb ff ff       	jmp    7a95 <f37+0xa5>
    7ecf:	e8 8c b5 ff ff       	call   3460 <__stack_chk_fail@plt>
    7ed4:	48 8d 3d 52 22 00 00 	lea    0x2252(%rip),%rdi        # a12d <_IO_stdin_used+0x12d>
    7edb:	e8 c0 c2 ff ff       	call   41a0 <fwp_trap>
    7ee0:	e8 0b d3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7ee5:	e9 46 ff ff ff       	jmp    7e30 <f37+0x440>
    7eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007ef0 <fwp_owned_entry37>:
    7ef0:	f3 0f 1e fa          	endbr64
    7ef4:	48 8b 3f             	mov    (%rdi),%rdi
    7ef7:	e9 f4 fa ff ff       	jmp    79f0 <f37>
    7efc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007f00 <e37>:
    7f00:	f3 0f 1e fa          	endbr64
    7f04:	53                   	push   %rbx
    7f05:	48 8b 1f             	mov    (%rdi),%rbx
    7f08:	48 89 df             	mov    %rbx,%rdi
    7f0b:	e8 80 e2 ff ff       	call   6190 <fwp_rc_share>
    7f10:	48 89 df             	mov    %rbx,%rdi
    7f13:	e8 d8 fa ff ff       	call   79f0 <f37>
    7f18:	48 89 c3             	mov    %rax,%rbx
    7f1b:	48 89 c7             	mov    %rax,%rdi
    7f1e:	e8 6d e2 ff ff       	call   6190 <fwp_rc_share>
    7f23:	48 89 d8             	mov    %rbx,%rax
    7f26:	5b                   	pop    %rbx
    7f27:	c3                   	ret
    7f28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f2f:	00 

0000000000007f30 <fwp_write>:
    7f30:	41 57                	push   %r15
    7f32:	41 56                	push   %r14
    7f34:	41 55                	push   %r13
    7f36:	41 54                	push   %r12
    7f38:	55                   	push   %rbp
    7f39:	53                   	push   %rbx
    7f3a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    7f41:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7f48:	00 00 
    7f4a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    7f51:	00 
    7f52:	49 89 d4             	mov    %rdx,%r12
    7f55:	8b 12                	mov    (%rdx),%edx
    7f57:	83 fa 19             	cmp    $0x19,%edx
    7f5a:	77 6a                	ja     7fc6 <fwp_write+0x96>
    7f5c:	48 89 f5             	mov    %rsi,%rbp
    7f5f:	89 d0                	mov    %edx,%eax
    7f61:	89 ce                	mov    %ecx,%esi
    7f63:	48 89 fb             	mov    %rdi,%rbx
    7f66:	48 8d 0d f3 29 00 00 	lea    0x29f3(%rip),%rcx        # a960 <_IO_stdin_used+0x960>
    7f6d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    7f71:	48 01 c8             	add    %rcx,%rax
    7f74:	3e ff e0             	notrack jmp *%rax
    7f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f7e:	00 00 
    7f80:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    7f84:	48 8b 45 00          	mov    0x0(%rbp),%rax
    7f88:	48 89 ca             	mov    %rcx,%rdx
    7f8b:	48 85 c9             	test   %rcx,%rcx
    7f8e:	0f 88 9c 0c 00 00    	js     8c30 <fwp_write+0xd00>
    7f94:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7f9b:	00 
    7f9c:	48 89 c6             	mov    %rax,%rsi
    7f9f:	4c 89 e7             	mov    %r12,%rdi
    7fa2:	e8 99 ba ff ff       	call   3a40 <fwp_fmt_u128>
    7fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fae:	00 00 
    7fb0:	4c 89 e7             	mov    %r12,%rdi
    7fb3:	e8 98 b4 ff ff       	call   3450 <strlen@plt>
    7fb8:	4c 89 e6             	mov    %r12,%rsi
    7fbb:	48 89 df             	mov    %rbx,%rdi
    7fbe:	48 89 c2             	mov    %rax,%rdx
    7fc1:	e8 aa c0 ff ff       	call   4070 <buf_put>
    7fc6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7fcd:	00 
    7fce:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7fd5:	00 00 
    7fd7:	0f 85 28 04 00 00    	jne    8405 <fwp_write+0x4d5>
    7fdd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    7fe4:	5b                   	pop    %rbx
    7fe5:	5d                   	pop    %rbp
    7fe6:	41 5c                	pop    %r12
    7fe8:	41 5d                	pop    %r13
    7fea:	41 5e                	pop    %r14
    7fec:	41 5f                	pop    %r15
    7fee:	c3                   	ret
    7fef:	90                   	nop
    7ff0:	49 89 e9             	mov    %rbp,%r9
    7ff3:	4c 8d 05 5d 21 00 00 	lea    0x215d(%rip),%r8        # a157 <_IO_stdin_used+0x157>
    7ffa:	b9 00 02 00 00       	mov    $0x200,%ecx
    7fff:	ba 02 00 00 00       	mov    $0x2,%edx
    8004:	be 00 02 00 00       	mov    $0x200,%esi
    8009:	31 c0                	xor    %eax,%eax
    800b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8012:	00 
    8013:	e8 98 b3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8018:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    801f:	00 
    8020:	e8 2b b4 ff ff       	call   3450 <strlen@plt>
    8025:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    802c:	00 
    802d:	48 89 df             	mov    %rbx,%rdi
    8030:	48 89 c2             	mov    %rax,%rdx
    8033:	e8 38 c0 ff ff       	call   4070 <buf_put>
    8038:	eb 8c                	jmp    7fc6 <fwp_write+0x96>
    803a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8040:	49 89 e9             	mov    %rbp,%r9
    8043:	4c 8d 05 08 21 00 00 	lea    0x2108(%rip),%r8        # a152 <_IO_stdin_used+0x152>
    804a:	eb ae                	jmp    7ffa <fwp_write+0xca>
    804c:	0f 1f 40 00          	nopl   0x0(%rax)
    8050:	83 fa 13             	cmp    $0x13,%edx
    8053:	48 8d 05 ee 20 00 00 	lea    0x20ee(%rip),%rax        # a148 <_IO_stdin_used+0x148>
    805a:	48 8d 35 ec 20 00 00 	lea    0x20ec(%rip),%rsi        # a14d <_IO_stdin_used+0x14d>
    8061:	ba 04 00 00 00       	mov    $0x4,%edx
    8066:	48 0f 44 f0          	cmove  %rax,%rsi
    806a:	45 31 ed             	xor    %r13d,%r13d
    806d:	e8 fe bf ff ff       	call   4070 <buf_put>
    8072:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8077:	0f 84 a3 08 00 00    	je     8920 <fwp_write+0x9f0>
    807d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8082:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8087:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    808c:	48 89 df             	mov    %rbx,%rdi
    808f:	49 0f 44 c5          	cmove  %r13,%rax
    8093:	31 c9                	xor    %ecx,%ecx
    8095:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    809a:	e8 91 fe ff ff       	call   7f30 <fwp_write>
    809f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    80a4:	0f 84 6e 09 00 00    	je     8a18 <fwp_write+0xae8>
    80aa:	49 83 c5 01          	add    $0x1,%r13
    80ae:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    80b2:	0f 83 68 08 00 00    	jae    8920 <fwp_write+0x9f0>
    80b8:	ba 02 00 00 00       	mov    $0x2,%edx
    80bd:	48 8d 35 d3 20 00 00 	lea    0x20d3(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    80c4:	48 89 df             	mov    %rbx,%rdi
    80c7:	e8 a4 bf ff ff       	call   4070 <buf_put>
    80cc:	eb af                	jmp    807d <fwp_write+0x14d>
    80ce:	66 90                	xchg   %ax,%ax
    80d0:	ba 06 00 00 00       	mov    $0x6,%edx
    80d5:	48 8d 35 94 20 00 00 	lea    0x2094(%rip),%rsi        # a170 <_IO_stdin_used+0x170>
    80dc:	48 83 c5 10          	add    $0x10,%rbp
    80e0:	e8 8b bf ff ff       	call   4070 <buf_put>
    80e5:	48 89 ef             	mov    %rbp,%rdi
    80e8:	e8 63 b3 ff ff       	call   3450 <strlen@plt>
    80ed:	48 89 ee             	mov    %rbp,%rsi
    80f0:	48 89 df             	mov    %rbx,%rdi
    80f3:	48 89 c2             	mov    %rax,%rdx
    80f6:	e8 75 bf ff ff       	call   4070 <buf_put>
    80fb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8100:	ba 01 00 00 00       	mov    $0x1,%edx
    8105:	48 89 df             	mov    %rbx,%rdi
    8108:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    810d:	e8 5e bf ff ff       	call   4070 <buf_put>
    8112:	e9 af fe ff ff       	jmp    7fc6 <fwp_write+0x96>
    8117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    811e:	00 00 
    8120:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8127:	00 
    8128:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    812f:	00 00 
    8131:	0f 85 ce 02 00 00    	jne    8405 <fwp_write+0x4d5>
    8137:	ba 0a 00 00 00       	mov    $0xa,%edx
    813c:	48 8d 35 19 20 00 00 	lea    0x2019(%rip),%rsi        # a15c <_IO_stdin_used+0x15c>
    8143:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    814a:	48 89 df             	mov    %rbx,%rdi
    814d:	5b                   	pop    %rbx
    814e:	5d                   	pop    %rbp
    814f:	41 5c                	pop    %r12
    8151:	41 5d                	pop    %r13
    8153:	41 5e                	pop    %r14
    8155:	41 5f                	pop    %r15
    8157:	e9 14 bf ff ff       	jmp    4070 <buf_put>
    815c:	0f 1f 40 00          	nopl   0x0(%rax)
    8160:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8165:	4d 85 ed             	test   %r13,%r13
    8168:	0f 84 02 0c 00 00    	je     8d70 <fwp_write+0xe40>
    816e:	48 8d 35 2f 20 00 00 	lea    0x202f(%rip),%rsi        # a1a4 <_IO_stdin_used+0x1a4>
    8175:	4c 89 ef             	mov    %r13,%rdi
    8178:	e8 b3 b3 ff ff       	call   3530 <strcmp@plt>
    817d:	41 89 c1             	mov    %eax,%r9d
    8180:	85 c0                	test   %eax,%eax
    8182:	0f 84 6c 0c 00 00    	je     8df4 <fwp_write+0xec4>
    8188:	4c 89 ef             	mov    %r13,%rdi
    818b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8190:	e8 bb b2 ff ff       	call   3450 <strlen@plt>
    8195:	4c 89 ee             	mov    %r13,%rsi
    8198:	48 89 df             	mov    %rbx,%rdi
    819b:	48 89 c2             	mov    %rax,%rdx
    819e:	e8 cd be ff ff       	call   4070 <buf_put>
    81a3:	ba 01 00 00 00       	mov    $0x1,%edx
    81a8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    81ad:	48 89 df             	mov    %rbx,%rdi
    81b0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    81b5:	e8 b6 be ff ff       	call   4070 <buf_put>
    81ba:	ba 01 00 00 00       	mov    $0x1,%edx
    81bf:	4c 89 fe             	mov    %r15,%rsi
    81c2:	48 89 df             	mov    %rbx,%rdi
    81c5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    81ca:	e8 a1 be ff ff       	call   4070 <buf_put>
    81cf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    81d4:	45 31 f6             	xor    %r14d,%r14d
    81d7:	85 d2                	test   %edx,%edx
    81d9:	0f 8e 81 0a 00 00    	jle    8c60 <fwp_write+0xd30>
    81df:	45 31 ed             	xor    %r13d,%r13d
    81e2:	4d 85 ed             	test   %r13,%r13
    81e5:	0f 85 75 07 00 00    	jne    8960 <fwp_write+0xa30>
    81eb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    81f2:	00 
    81f3:	45 85 f6             	test   %r14d,%r14d
    81f6:	0f 84 84 07 00 00    	je     8980 <fwp_write+0xa50>
    81fc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8201:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8206:	48 89 df             	mov    %rbx,%rdi
    8209:	49 83 c5 01          	add    $0x1,%r13
    820d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8211:	31 c9                	xor    %ecx,%ecx
    8213:	e8 18 fd ff ff       	call   7f30 <fwp_write>
    8218:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    821d:	7f c3                	jg     81e2 <fwp_write+0x2b2>
    821f:	45 85 f6             	test   %r14d,%r14d
    8222:	0f 84 38 0a 00 00    	je     8c60 <fwp_write+0xd30>
    8228:	b8 29 00 00 00       	mov    $0x29,%eax
    822d:	ba 01 00 00 00       	mov    $0x1,%edx
    8232:	4c 89 fe             	mov    %r15,%rsi
    8235:	48 89 df             	mov    %rbx,%rdi
    8238:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    823c:	e8 2f be ff ff       	call   4070 <buf_put>
    8241:	e9 80 fd ff ff       	jmp    7fc6 <fwp_write+0x96>
    8246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    824d:	00 00 00 
    8250:	ba 01 00 00 00       	mov    $0x1,%edx
    8255:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    825a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    825f:	e8 0c be ff ff       	call   4070 <buf_put>
    8264:	48 85 ed             	test   %rbp,%rbp
    8267:	0f 84 93 06 00 00    	je     8900 <fwp_write+0x9d0>
    826d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8271:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8276:	31 c9                	xor    %ecx,%ecx
    8278:	48 89 df             	mov    %rbx,%rdi
    827b:	e8 b0 fc ff ff       	call   7f30 <fwp_write>
    8280:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8284:	48 85 ed             	test   %rbp,%rbp
    8287:	0f 84 73 06 00 00    	je     8900 <fwp_write+0x9d0>
    828d:	ba 02 00 00 00       	mov    $0x2,%edx
    8292:	48 8d 35 fe 1e 00 00 	lea    0x1efe(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    8299:	48 89 df             	mov    %rbx,%rdi
    829c:	e8 cf bd ff ff       	call   4070 <buf_put>
    82a1:	eb ca                	jmp    826d <fwp_write+0x33d>
    82a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82a8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    82ac:	85 f6                	test   %esi,%esi
    82ae:	0f 84 fc 07 00 00    	je     8ab0 <fwp_write+0xb80>
    82b4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82bb:	00 
    82bc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82c3:	00 00 
    82c5:	0f 85 3a 01 00 00    	jne    8405 <fwp_write+0x4d5>
    82cb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    82cf:	4c 89 ea             	mov    %r13,%rdx
    82d2:	e9 6c fe ff ff       	jmp    8143 <fwp_write+0x213>
    82d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82de:	00 00 
    82e0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    82e5:	ba 01 00 00 00       	mov    $0x1,%edx
    82ea:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    82ef:	48 89 ee             	mov    %rbp,%rsi
    82f2:	e8 79 bd ff ff       	call   4070 <buf_put>
    82f7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    82fc:	4c 89 e7             	mov    %r12,%rdi
    82ff:	e8 4c b1 ff ff       	call   3450 <strlen@plt>
    8304:	4c 89 e6             	mov    %r12,%rsi
    8307:	48 89 df             	mov    %rbx,%rdi
    830a:	48 89 c2             	mov    %rax,%rdx
    830d:	e8 5e bd ff ff       	call   4070 <buf_put>
    8312:	ba 01 00 00 00       	mov    $0x1,%edx
    8317:	48 89 ee             	mov    %rbp,%rsi
    831a:	48 89 df             	mov    %rbx,%rdi
    831d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8322:	e8 49 bd ff ff       	call   4070 <buf_put>
    8327:	e9 9a fc ff ff       	jmp    7fc6 <fwp_write+0x96>
    832c:	0f 1f 40 00          	nopl   0x0(%rax)
    8330:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8335:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8339:	0f 8a 8e 0b 00 00    	jp     8ecd <fwp_write+0xf9d>
    833f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8343:	66 0f 54 05 15 27 00 	andpd  0x2715(%rip),%xmm0        # aa60 <msg.4+0x90>
    834a:	00 
    834b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8350:	66 0f 2e 05 38 27 00 	ucomisd 0x2738(%rip),%xmm0        # aa90 <msg.4+0xc0>
    8357:	00 
    8358:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    835f:	00 
    8360:	0f 87 b2 09 00 00    	ja     8d18 <fwp_write+0xde8>
    8366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    836d:	00 00 00 
    8370:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8374:	89 ee                	mov    %ebp,%esi
    8376:	4c 89 e7             	mov    %r12,%rdi
    8379:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    837e:	e8 3d c1 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8383:	31 f6                	xor    %esi,%esi
    8385:	4c 89 e7             	mov    %r12,%rdi
    8388:	e8 83 b0 ff ff       	call   3410 <strtod@plt>
    838d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8392:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8396:	7a 06                	jp     839e <fwp_write+0x46e>
    8398:	0f 84 e9 01 00 00    	je     8587 <fwp_write+0x657>
    839e:	83 c5 01             	add    $0x1,%ebp
    83a1:	83 fd 12             	cmp    $0x12,%ebp
    83a4:	75 ca                	jne    8370 <fwp_write+0x440>
    83a6:	be 11 00 00 00       	mov    $0x11,%esi
    83ab:	66 0f 28 c1          	movapd %xmm1,%xmm0
    83af:	4c 89 e7             	mov    %r12,%rdi
    83b2:	e8 09 c1 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    83b7:	e9 cb 01 00 00       	jmp    8587 <fwp_write+0x657>
    83bc:	0f 1f 40 00          	nopl   0x0(%rax)
    83c0:	48 83 fd 01          	cmp    $0x1,%rbp
    83c4:	0f 84 e6 08 00 00    	je     8cb0 <fwp_write+0xd80>
    83ca:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    83ce:	b8 02 00 00 00       	mov    $0x2,%eax
    83d3:	ba 01 00 00 00       	mov    $0x1,%edx
    83d8:	48 0f 44 d0          	cmove  %rax,%rdx
    83dc:	48 8d 35 5d 1d 00 00 	lea    0x1d5d(%rip),%rsi        # a140 <_IO_stdin_used+0x140>
    83e3:	48 8d 05 5b 1d 00 00 	lea    0x1d5b(%rip),%rax        # a145 <_IO_stdin_used+0x145>
    83ea:	48 0f 44 f0          	cmove  %rax,%rsi
    83ee:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    83f5:	00 
    83f6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83fd:	00 00 
    83ff:	0f 84 3e fd ff ff    	je     8143 <fwp_write+0x213>
    8405:	e8 56 b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    840a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8410:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8415:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    841a:	e8 91 bb ff ff       	call   3fb0 <buf_grow>
    841f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8423:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8429:	4c 03 0b             	add    (%rbx),%r9
    842c:	66 45 89 11          	mov    %r10w,(%r9)
    8430:	45 85 e4             	test   %r12d,%r12d
    8433:	0f 8e 07 05 00 00    	jle    8940 <fwp_write+0xa10>
    8439:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8440:	55 55 55 
    8443:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8448:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    844f:	aa aa aa 
    8452:	49 83 c1 01          	add    $0x1,%r9
    8456:	eb 45                	jmp    849d <fwp_write+0x56d>
    8458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    845f:	00 
    8460:	be 01 00 00 00       	mov    $0x1,%esi
    8465:	b8 2d 00 00 00       	mov    $0x2d,%eax
    846a:	88 07                	mov    %al,(%rdi)
    846c:	48 89 e8             	mov    %rbp,%rax
    846f:	49 f7 e8             	imul   %r8
    8472:	48 89 e8             	mov    %rbp,%rax
    8475:	48 c1 f8 3f          	sar    $0x3f,%rax
    8479:	48 29 c2             	sub    %rax,%rdx
    847c:	48 85 c9             	test   %rcx,%rcx
    847f:	0f 95 c0             	setne  %al
    8482:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8486:	48 83 ef 01          	sub    $0x1,%rdi
    848a:	48 21 c5             	and    %rax,%rbp
    848d:	48 29 ea             	sub    %rbp,%rdx
    8490:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8494:	49 39 f9             	cmp    %rdi,%r9
    8497:	0f 84 a3 04 00 00    	je     8940 <fwp_write+0xa10>
    849d:	48 89 e8             	mov    %rbp,%rax
    84a0:	49 f7 e8             	imul   %r8
    84a3:	48 89 e8             	mov    %rbp,%rax
    84a6:	48 c1 f8 3f          	sar    $0x3f,%rax
    84aa:	48 89 d1             	mov    %rdx,%rcx
    84ad:	48 29 c1             	sub    %rax,%rcx
    84b0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    84b4:	48 89 e9             	mov    %rbp,%rcx
    84b7:	48 29 c1             	sub    %rax,%rcx
    84ba:	48 8d 41 03          	lea    0x3(%rcx),%rax
    84be:	49 f7 e2             	mul    %r10
    84c1:	b8 30 00 00 00       	mov    $0x30,%eax
    84c6:	48 89 d6             	mov    %rdx,%rsi
    84c9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    84cd:	48 d1 ee             	shr    $1,%rsi
    84d0:	48 01 f2             	add    %rsi,%rdx
    84d3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    84d7:	48 29 d6             	sub    %rdx,%rsi
    84da:	74 8e                	je     846a <fwp_write+0x53a>
    84dc:	48 83 fe 01          	cmp    $0x1,%rsi
    84e0:	0f 85 7a ff ff ff    	jne    8460 <fwp_write+0x530>
    84e6:	31 f6                	xor    %esi,%esi
    84e8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    84ed:	e9 78 ff ff ff       	jmp    846a <fwp_write+0x53a>
    84f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84f8:	66 0f 6e cd          	movd   %ebp,%xmm1
    84fc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    84ff:	0f 8a c8 09 00 00    	jp     8ecd <fwp_write+0xf9d>
    8505:	0f 28 c1             	movaps %xmm1,%xmm0
    8508:	0f 54 05 41 25 00 00 	andps  0x2541(%rip),%xmm0        # aa50 <msg.4+0x80>
    850f:	0f 2e 05 ee 1a 00 00 	ucomiss 0x1aee(%rip),%xmm0        # a004 <_IO_stdin_used+0x4>
    8516:	0f 87 24 08 00 00    	ja     8d40 <fwp_write+0xe10>
    851c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8520:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8526:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    852d:	00 
    852e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8532:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    853e:	00 00 
    8540:	44 89 ee             	mov    %r13d,%esi
    8543:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8548:	4c 89 e7             	mov    %r12,%rdi
    854b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8550:	e8 6b bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8555:	31 f6                	xor    %esi,%esi
    8557:	4c 89 e7             	mov    %r12,%rdi
    855a:	e8 51 af ff ff       	call   34b0 <strtof@plt>
    855f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8564:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8567:	7a 02                	jp     856b <fwp_write+0x63b>
    8569:	74 1c                	je     8587 <fwp_write+0x657>
    856b:	41 83 c5 01          	add    $0x1,%r13d
    856f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8573:	75 cb                	jne    8540 <fwp_write+0x610>
    8575:	be 09 00 00 00       	mov    $0x9,%esi
    857a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    857f:	4c 89 e7             	mov    %r12,%rdi
    8582:	e8 39 bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8587:	4c 89 e7             	mov    %r12,%rdi
    858a:	e8 a1 bb ff ff       	call   4130 <fwp_finish_float>
    858f:	e9 1c fa ff ff       	jmp    7fb0 <fwp_write+0x80>
    8594:	0f 1f 40 00          	nopl   0x0(%rax)
    8598:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    859c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    85a0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    85a7:	00 
    85a8:	48 89 ef             	mov    %rbp,%rdi
    85ab:	e8 90 b4 ff ff       	call   3a40 <fwp_fmt_u128>
    85b0:	48 89 ef             	mov    %rbp,%rdi
    85b3:	e8 98 ae ff ff       	call   3450 <strlen@plt>
    85b8:	48 89 ee             	mov    %rbp,%rsi
    85bb:	48 89 df             	mov    %rbx,%rdi
    85be:	48 89 c2             	mov    %rax,%rdx
    85c1:	e8 aa ba ff ff       	call   4070 <buf_put>
    85c6:	e9 fb f9 ff ff       	jmp    7fc6 <fwp_write+0x96>
    85cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    85d0:	ba 06 00 00 00       	mov    $0x6,%edx
    85d5:	48 8d 35 be 1b 00 00 	lea    0x1bbe(%rip),%rsi        # a19a <_IO_stdin_used+0x19a>
    85dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    85e2:	e8 89 ba ff ff       	call   4070 <buf_put>
    85e7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    85ee:	ff ff 7f 
    85f1:	48 23 55 00          	and    0x0(%rbp),%rdx
    85f5:	0f 84 86 02 00 00    	je     8881 <fwp_write+0x951>
    85fb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8600:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8604:	48 85 d2             	test   %rdx,%rdx
    8607:	0f 84 ae 00 00 00    	je     86bb <fwp_write+0x78b>
    860d:	8b 0a                	mov    (%rdx),%ecx
    860f:	83 f9 1c             	cmp    $0x1c,%ecx
    8612:	0f 84 58 06 00 00    	je     8c70 <fwp_write+0xd40>
    8618:	83 f9 1b             	cmp    $0x1b,%ecx
    861b:	0f 87 9a 00 00 00    	ja     86bb <fwp_write+0x78b>
    8621:	be 01 00 00 00       	mov    $0x1,%esi
    8626:	48 d3 e6             	shl    %cl,%rsi
    8629:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    862f:	0f 85 4b 04 00 00    	jne    8a80 <fwp_write+0xb50>
    8635:	f7 c6 84 04 00 00    	test   $0x484,%esi
    863b:	0f 85 0f 04 00 00    	jne    8a50 <fwp_write+0xb20>
    8641:	83 e6 21             	and    $0x21,%esi
    8644:	74 75                	je     86bb <fwp_write+0x78b>
    8646:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    864b:	48 85 ff             	test   %rdi,%rdi
    864e:	79 07                	jns    8657 <fwp_write+0x727>
    8650:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8654:	4c 01 ee             	add    %r13,%rsi
    8657:	48 0f be 3e          	movsbq (%rsi),%rdi
    865b:	85 c9                	test   %ecx,%ecx
    865d:	40 0f b6 f7          	movzbl %dil,%esi
    8661:	48 0f 44 f7          	cmove  %rdi,%rsi
    8665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    866c:	00 00 00 00 
    8670:	31 c9                	xor    %ecx,%ecx
    8672:	48 89 df             	mov    %rbx,%rdi
    8675:	49 83 c5 01          	add    $0x1,%r13
    8679:	e8 b2 f8 ff ff       	call   7f30 <fwp_write>
    867e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8685:	ff ff 7f 
    8688:	48 23 55 00          	and    0x0(%rbp),%rdx
    868c:	49 39 d5             	cmp    %rdx,%r13
    868f:	0f 83 ec 01 00 00    	jae    8881 <fwp_write+0x951>
    8695:	ba 02 00 00 00       	mov    $0x2,%edx
    869a:	48 89 df             	mov    %rbx,%rdi
    869d:	48 8d 35 f3 1a 00 00 	lea    0x1af3(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    86a4:	e8 c7 b9 ff ff       	call   4070 <buf_put>
    86a9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86ae:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    86b2:	48 85 d2             	test   %rdx,%rdx
    86b5:	0f 85 52 ff ff ff    	jne    860d <fwp_write+0x6dd>
    86bb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    86c0:	48 85 ff             	test   %rdi,%rdi
    86c3:	0f 88 cf 05 00 00    	js     8c98 <fwp_write+0xd68>
    86c9:	48 8b 31             	mov    (%rcx),%rsi
    86cc:	eb a2                	jmp    8670 <fwp_write+0x740>
    86ce:	66 90                	xchg   %ax,%ax
    86d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86d7:	00 
    86d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86df:	00 00 
    86e1:	0f 85 1e fd ff ff    	jne    8405 <fwp_write+0x4d5>
    86e7:	ba 08 00 00 00       	mov    $0x8,%edx
    86ec:	48 8d 35 74 1a 00 00 	lea    0x1a74(%rip),%rsi        # a167 <_IO_stdin_used+0x167>
    86f3:	e9 4b fa ff ff       	jmp    8143 <fwp_write+0x213>
    86f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86ff:	00 
    8700:	89 e8                	mov    %ebp,%eax
    8702:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8709:	76 03                	jbe    870e <fwp_write+0x7de>
    870b:	8b 45 00             	mov    0x0(%rbp),%eax
    870e:	41 89 c6             	mov    %eax,%r14d
    8711:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8716:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    871b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    871f:	4c 89 ef             	mov    %r13,%rdi
    8722:	e8 29 ad ff ff       	call   3450 <strlen@plt>
    8727:	4c 89 ee             	mov    %r13,%rsi
    872a:	48 89 df             	mov    %rbx,%rdi
    872d:	48 89 c2             	mov    %rax,%rdx
    8730:	e8 3b b9 ff ff       	call   4070 <buf_put>
    8735:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    873a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    873e:	85 f6                	test   %esi,%esi
    8740:	0f 8e 80 f8 ff ff    	jle    7fc6 <fwp_write+0x96>
    8746:	45 31 ed             	xor    %r13d,%r13d
    8749:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    874e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8753:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8758:	ba 01 00 00 00       	mov    $0x1,%edx
    875d:	4c 89 fe             	mov    %r15,%rsi
    8760:	48 89 04 24          	mov    %rax,(%rsp)
    8764:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8769:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    876d:	48 89 df             	mov    %rbx,%rdi
    8770:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8774:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8779:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    877e:	e8 ed b8 ff ff       	call   4070 <buf_put>
    8783:	41 8b 06             	mov    (%r14),%eax
    8786:	83 f8 0e             	cmp    $0xe,%eax
    8789:	0f 84 71 02 00 00    	je     8a00 <fwp_write+0xad0>
    878f:	83 f8 10             	cmp    $0x10,%eax
    8792:	0f 84 38 02 00 00    	je     89d0 <fwp_write+0xaa0>
    8798:	83 f8 0a             	cmp    $0xa,%eax
    879b:	0f 84 7f 04 00 00    	je     8c20 <fwp_write+0xcf0>
    87a1:	0f 8f f9 00 00 00    	jg     88a0 <fwp_write+0x970>
    87a7:	83 f8 03             	cmp    $0x3,%eax
    87aa:	0f 8f 50 04 00 00    	jg     8c00 <fwp_write+0xcd0>
    87b0:	85 c0                	test   %eax,%eax
    87b2:	78 10                	js     87c4 <fwp_write+0x894>
    87b4:	48 8b 04 24          	mov    (%rsp),%rax
    87b8:	48 c1 e8 3f          	shr    $0x3f,%rax
    87bc:	85 c0                	test   %eax,%eax
    87be:	0f 85 f9 00 00 00    	jne    88bd <fwp_write+0x98d>
    87c4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    87c9:	48 8b 34 24          	mov    (%rsp),%rsi
    87cd:	31 c9                	xor    %ecx,%ecx
    87cf:	48 89 df             	mov    %rbx,%rdi
    87d2:	e8 59 f7 ff ff       	call   7f30 <fwp_write>
    87d7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    87dc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    87e1:	49 83 c5 01          	add    $0x1,%r13
    87e5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    87e9:	0f 8f 5f ff ff ff    	jg     874e <fwp_write+0x81e>
    87ef:	e9 d2 f7 ff ff       	jmp    7fc6 <fwp_write+0x96>
    87f4:	0f 1f 40 00          	nopl   0x0(%rax)
    87f8:	ba 06 00 00 00       	mov    $0x6,%edx
    87fd:	48 8d 35 89 19 00 00 	lea    0x1989(%rip),%rsi        # a18d <_IO_stdin_used+0x18d>
    8804:	45 31 ed             	xor    %r13d,%r13d
    8807:	e8 64 b8 ff ff       	call   4070 <buf_put>
    880c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8811:	75 19                	jne    882c <fwp_write+0x8fc>
    8813:	eb 6c                	jmp    8881 <fwp_write+0x951>
    8815:	0f 1f 00             	nopl   (%rax)
    8818:	ba 02 00 00 00       	mov    $0x2,%edx
    881d:	48 8d 35 73 19 00 00 	lea    0x1973(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    8824:	48 89 df             	mov    %rbx,%rdi
    8827:	e8 44 b8 ff ff       	call   4070 <buf_put>
    882c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8832:	b9 00 02 00 00       	mov    $0x200,%ecx
    8837:	31 c0                	xor    %eax,%eax
    8839:	49 83 c5 01          	add    $0x1,%r13
    883d:	4c 8d 05 50 19 00 00 	lea    0x1950(%rip),%r8        # a194 <_IO_stdin_used+0x194>
    8844:	ba 02 00 00 00       	mov    $0x2,%edx
    8849:	be 00 02 00 00       	mov    $0x200,%esi
    884e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8855:	00 
    8856:	e8 55 ab ff ff       	call   33b0 <__snprintf_chk@plt>
    885b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8862:	00 
    8863:	e8 e8 ab ff ff       	call   3450 <strlen@plt>
    8868:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    886f:	00 
    8870:	48 89 df             	mov    %rbx,%rdi
    8873:	48 89 c2             	mov    %rax,%rdx
    8876:	e8 f5 b7 ff ff       	call   4070 <buf_put>
    887b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    887f:	72 97                	jb     8818 <fwp_write+0x8e8>
    8881:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8886:	ba 01 00 00 00       	mov    $0x1,%edx
    888b:	48 89 df             	mov    %rbx,%rdi
    888e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8893:	e8 d8 b7 ff ff       	call   4070 <buf_put>
    8898:	e9 29 f7 ff ff       	jmp    7fc6 <fwp_write+0x96>
    889d:	0f 1f 00             	nopl   (%rax)
    88a0:	83 f8 0b             	cmp    $0xb,%eax
    88a3:	0f 85 1b ff ff ff    	jne    87c4 <fwp_write+0x894>
    88a9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    88ae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    88b2:	83 e0 01             	and    $0x1,%eax
    88b5:	85 c0                	test   %eax,%eax
    88b7:	0f 84 07 ff ff ff    	je     87c4 <fwp_write+0x894>
    88bd:	4c 89 fe             	mov    %r15,%rsi
    88c0:	48 89 df             	mov    %rbx,%rdi
    88c3:	ba 01 00 00 00       	mov    $0x1,%edx
    88c8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    88cd:	e8 9e b7 ff ff       	call   4070 <buf_put>
    88d2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    88d7:	48 8b 34 24          	mov    (%rsp),%rsi
    88db:	31 c9                	xor    %ecx,%ecx
    88dd:	48 89 df             	mov    %rbx,%rdi
    88e0:	e8 4b f6 ff ff       	call   7f30 <fwp_write>
    88e5:	ba 01 00 00 00       	mov    $0x1,%edx
    88ea:	4c 89 fe             	mov    %r15,%rsi
    88ed:	48 89 df             	mov    %rbx,%rdi
    88f0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    88f5:	e8 76 b7 ff ff       	call   4070 <buf_put>
    88fa:	e9 d8 fe ff ff       	jmp    87d7 <fwp_write+0x8a7>
    88ff:	90                   	nop
    8900:	ba 01 00 00 00       	mov    $0x1,%edx
    8905:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    890a:	48 89 df             	mov    %rbx,%rdi
    890d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8912:	e8 59 b7 ff ff       	call   4070 <buf_put>
    8917:	e9 aa f6 ff ff       	jmp    7fc6 <fwp_write+0x96>
    891c:	0f 1f 40 00          	nopl   0x0(%rax)
    8920:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8925:	ba 01 00 00 00       	mov    $0x1,%edx
    892a:	48 89 df             	mov    %rbx,%rdi
    892d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8932:	e8 39 b7 ff ff       	call   4070 <buf_put>
    8937:	e9 8a f6 ff ff       	jmp    7fc6 <fwp_write+0x96>
    893c:	0f 1f 40 00          	nopl   0x0(%rax)
    8940:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8944:	48 8b 13             	mov    (%rbx),%rdx
    8947:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    894c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8950:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8954:	e9 6d f6 ff ff       	jmp    7fc6 <fwp_write+0x96>
    8959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8960:	ba 02 00 00 00       	mov    $0x2,%edx
    8965:	48 8d 35 2b 18 00 00 	lea    0x182b(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    896c:	48 89 df             	mov    %rbx,%rdi
    896f:	e8 fc b6 ff ff       	call   4070 <buf_put>
    8974:	e9 72 f8 ff ff       	jmp    81eb <fwp_write+0x2bb>
    8979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8980:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8985:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    898a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    898e:	48 89 f7             	mov    %rsi,%rdi
    8991:	48 89 34 24          	mov    %rsi,(%rsp)
    8995:	e8 b6 aa ff ff       	call   3450 <strlen@plt>
    899a:	48 8b 34 24          	mov    (%rsp),%rsi
    899e:	48 89 df             	mov    %rbx,%rdi
    89a1:	48 89 c2             	mov    %rax,%rdx
    89a4:	e8 c7 b6 ff ff       	call   4070 <buf_put>
    89a9:	ba 03 00 00 00       	mov    $0x3,%edx
    89ae:	48 8d 35 05 18 00 00 	lea    0x1805(%rip),%rsi        # a1ba <_IO_stdin_used+0x1ba>
    89b5:	48 89 df             	mov    %rbx,%rdi
    89b8:	e8 b3 b6 ff ff       	call   4070 <buf_put>
    89bd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    89c2:	e9 35 f8 ff ff       	jmp    81fc <fwp_write+0x2cc>
    89c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ce:	00 00 
    89d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    89d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    89d9:	48 85 ff             	test   %rdi,%rdi
    89dc:	0f 84 e2 fd ff ff    	je     87c4 <fwp_write+0x894>
    89e2:	48 8d 35 bb 17 00 00 	lea    0x17bb(%rip),%rsi        # a1a4 <_IO_stdin_used+0x1a4>
    89e9:	e8 42 ab ff ff       	call   3530 <strcmp@plt>
    89ee:	85 c0                	test   %eax,%eax
    89f0:	0f 95 c0             	setne  %al
    89f3:	0f b6 c0             	movzbl %al,%eax
    89f6:	e9 c1 fd ff ff       	jmp    87bc <fwp_write+0x88c>
    89fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a00:	31 c0                	xor    %eax,%eax
    8a02:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8a09:	00 
    8a0a:	0f 97 c0             	seta   %al
    8a0d:	e9 aa fd ff ff       	jmp    87bc <fwp_write+0x88c>
    8a12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a18:	48 89 df             	mov    %rbx,%rdi
    8a1b:	ba 02 00 00 00       	mov    $0x2,%edx
    8a20:	48 8d 35 7a 17 00 00 	lea    0x177a(%rip),%rsi        # a1a1 <_IO_stdin_used+0x1a1>
    8a27:	e8 44 b6 ff ff       	call   4070 <buf_put>
    8a2c:	4c 89 e8             	mov    %r13,%rax
    8a2f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8a34:	31 c9                	xor    %ecx,%ecx
    8a36:	48 c1 e0 04          	shl    $0x4,%rax
    8a3a:	48 89 df             	mov    %rbx,%rdi
    8a3d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8a42:	e8 e9 f4 ff ff       	call   7f30 <fwp_write>
    8a47:	e9 5e f6 ff ff       	jmp    80aa <fwp_write+0x17a>
    8a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a50:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8a55:	48 85 ff             	test   %rdi,%rdi
    8a58:	79 0c                	jns    8a66 <fwp_write+0xb36>
    8a5a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8a61:	00 
    8a62:	48 03 75 10          	add    0x10(%rbp),%rsi
    8a66:	48 63 3e             	movslq (%rsi),%rdi
    8a69:	83 f9 02             	cmp    $0x2,%ecx
    8a6c:	89 fe                	mov    %edi,%esi
    8a6e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8a72:	e9 f9 fb ff ff       	jmp    8670 <fwp_write+0x740>
    8a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a7e:	00 00 
    8a80:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8a85:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8a8a:	48 85 ff             	test   %rdi,%rdi
    8a8d:	0f 88 0f 03 00 00    	js     8da2 <fwp_write+0xe72>
    8a93:	49 0f bf 38          	movswq (%r8),%rdi
    8a97:	83 f9 01             	cmp    $0x1,%ecx
    8a9a:	0f b7 f7             	movzwl %di,%esi
    8a9d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8aa1:	e9 ca fb ff ff       	jmp    8670 <fwp_write+0x740>
    8aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8aad:	00 00 00 
    8ab0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ab5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8aba:	48 83 c5 08          	add    $0x8,%rbp
    8abe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ac3:	e8 a8 b5 ff ff       	call   4070 <buf_put>
    8ac8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8acd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8ad2:	4d 85 ed             	test   %r13,%r13
    8ad5:	75 46                	jne    8b1d <fwp_write+0xbed>
    8ad7:	e9 04 01 00 00       	jmp    8be0 <fwp_write+0xcb0>
    8adc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ae0:	41 80 f9 09          	cmp    $0x9,%r9b
    8ae4:	0f 84 d6 00 00 00    	je     8bc0 <fwp_write+0xc90>
    8aea:	41 80 f9 0a          	cmp    $0xa,%r9b
    8aee:	0f 85 9c 00 00 00    	jne    8b90 <fwp_write+0xc60>
    8af4:	ba 02 00 00 00       	mov    $0x2,%edx
    8af9:	48 8d 35 7d 16 00 00 	lea    0x167d(%rip),%rsi        # a17d <_IO_stdin_used+0x17d>
    8b00:	48 89 df             	mov    %rbx,%rdi
    8b03:	e8 68 b5 ff ff       	call   4070 <buf_put>
    8b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b0f:	00 
    8b10:	48 83 c5 01          	add    $0x1,%rbp
    8b14:	49 39 ec             	cmp    %rbp,%r12
    8b17:	0f 84 c3 00 00 00    	je     8be0 <fwp_write+0xcb0>
    8b1d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8b22:	41 80 f9 0d          	cmp    $0xd,%r9b
    8b26:	74 28                	je     8b50 <fwp_write+0xc20>
    8b28:	7e b6                	jle    8ae0 <fwp_write+0xbb0>
    8b2a:	41 80 f9 22          	cmp    $0x22,%r9b
    8b2e:	74 40                	je     8b70 <fwp_write+0xc40>
    8b30:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8b34:	75 5a                	jne    8b90 <fwp_write+0xc60>
    8b36:	ba 02 00 00 00       	mov    $0x2,%edx
    8b3b:	48 8d 35 38 16 00 00 	lea    0x1638(%rip),%rsi        # a17a <_IO_stdin_used+0x17a>
    8b42:	48 89 df             	mov    %rbx,%rdi
    8b45:	e8 26 b5 ff ff       	call   4070 <buf_put>
    8b4a:	eb c4                	jmp    8b10 <fwp_write+0xbe0>
    8b4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b50:	ba 02 00 00 00       	mov    $0x2,%edx
    8b55:	48 8d 35 27 16 00 00 	lea    0x1627(%rip),%rsi        # a183 <_IO_stdin_used+0x183>
    8b5c:	48 89 df             	mov    %rbx,%rdi
    8b5f:	e8 0c b5 ff ff       	call   4070 <buf_put>
    8b64:	eb aa                	jmp    8b10 <fwp_write+0xbe0>
    8b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b6d:	00 00 00 
    8b70:	ba 02 00 00 00       	mov    $0x2,%edx
    8b75:	48 8d 35 fb 15 00 00 	lea    0x15fb(%rip),%rsi        # a177 <_IO_stdin_used+0x177>
    8b7c:	48 89 df             	mov    %rbx,%rdi
    8b7f:	e8 ec b4 ff ff       	call   4070 <buf_put>
    8b84:	eb 8a                	jmp    8b10 <fwp_write+0xbe0>
    8b86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b8d:	00 00 00 
    8b90:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8b94:	0f 86 2e 01 00 00    	jbe    8cc8 <fwp_write+0xd98>
    8b9a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8b9e:	0f 84 24 01 00 00    	je     8cc8 <fwp_write+0xd98>
    8ba4:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba9:	4c 89 fe             	mov    %r15,%rsi
    8bac:	48 89 df             	mov    %rbx,%rdi
    8baf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8bb4:	e8 b7 b4 ff ff       	call   4070 <buf_put>
    8bb9:	e9 52 ff ff ff       	jmp    8b10 <fwp_write+0xbe0>
    8bbe:	66 90                	xchg   %ax,%ax
    8bc0:	ba 02 00 00 00       	mov    $0x2,%edx
    8bc5:	48 8d 35 b4 15 00 00 	lea    0x15b4(%rip),%rsi        # a180 <_IO_stdin_used+0x180>
    8bcc:	48 89 df             	mov    %rbx,%rdi
    8bcf:	e8 9c b4 ff ff       	call   4070 <buf_put>
    8bd4:	e9 37 ff ff ff       	jmp    8b10 <fwp_write+0xbe0>
    8bd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8be0:	ba 01 00 00 00       	mov    $0x1,%edx
    8be5:	4c 89 fe             	mov    %r15,%rsi
    8be8:	48 89 df             	mov    %rbx,%rdi
    8beb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8bf0:	e8 7b b4 ff ff       	call   4070 <buf_put>
    8bf5:	e9 cc f3 ff ff       	jmp    7fc6 <fwp_write+0x96>
    8bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c00:	83 f8 04             	cmp    $0x4,%eax
    8c03:	0f 85 bb fb ff ff    	jne    87c4 <fwp_write+0x894>
    8c09:	48 8b 04 24          	mov    (%rsp),%rax
    8c0d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8c11:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8c16:	48 c1 e8 3f          	shr    $0x3f,%rax
    8c1a:	e9 96 fc ff ff       	jmp    88b5 <fwp_write+0x985>
    8c1f:	90                   	nop
    8c20:	8b 0c 24             	mov    (%rsp),%ecx
    8c23:	31 c0                	xor    %eax,%eax
    8c25:	85 c9                	test   %ecx,%ecx
    8c27:	0f 98 c0             	sets   %al
    8c2a:	e9 86 fc ff ff       	jmp    88b5 <fwp_write+0x985>
    8c2f:	90                   	nop
    8c30:	48 f7 d8             	neg    %rax
    8c33:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8c3a:	00 
    8c3b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8c42:	2d 
    8c43:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c4a:	00 
    8c4b:	48 83 d2 00          	adc    $0x0,%rdx
    8c4f:	48 89 c6             	mov    %rax,%rsi
    8c52:	48 f7 da             	neg    %rdx
    8c55:	e8 e6 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8c5a:	e9 51 f3 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8c5f:	90                   	nop
    8c60:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8c65:	e9 c3 f5 ff ff       	jmp    822d <fwp_write+0x2fd>
    8c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c70:	4c 89 e9             	mov    %r13,%rcx
    8c73:	48 c1 e1 04          	shl    $0x4,%rcx
    8c77:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8c7c:	48 85 ff             	test   %rdi,%rdi
    8c7f:	0f 89 eb f9 ff ff    	jns    8670 <fwp_write+0x740>
    8c85:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8c89:	48 89 ce             	mov    %rcx,%rsi
    8c8c:	e9 df f9 ff ff       	jmp    8670 <fwp_write+0x740>
    8c91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c98:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8c9f:	00 
    8ca0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8ca4:	e9 20 fa ff ff       	jmp    86c9 <fwp_write+0x799>
    8ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cb0:	ba 02 00 00 00       	mov    $0x2,%edx
    8cb5:	48 8d 35 86 14 00 00 	lea    0x1486(%rip),%rsi        # a142 <_IO_stdin_used+0x142>
    8cbc:	e9 2d f7 ff ff       	jmp    83ee <fwp_write+0x4be>
    8cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cc8:	4c 8d 05 b7 14 00 00 	lea    0x14b7(%rip),%r8        # a186 <_IO_stdin_used+0x186>
    8ccf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8cd4:	31 c0                	xor    %eax,%eax
    8cd6:	ba 02 00 00 00       	mov    $0x2,%edx
    8cdb:	be 10 00 00 00       	mov    $0x10,%esi
    8ce0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ce7:	00 
    8ce8:	e8 c3 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8ced:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8cf4:	00 
    8cf5:	e8 56 a7 ff ff       	call   3450 <strlen@plt>
    8cfa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8d01:	00 
    8d02:	48 89 df             	mov    %rbx,%rdi
    8d05:	48 89 c2             	mov    %rax,%rdx
    8d08:	e8 63 b3 ff ff       	call   4070 <buf_put>
    8d0d:	e9 fe fd ff ff       	jmp    8b10 <fwp_write+0xbe0>
    8d12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d18:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8d1c:	48 8d 35 19 14 00 00 	lea    0x1419(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    8d23:	48 8d 05 11 14 00 00 	lea    0x1411(%rip),%rax        # a13b <_IO_stdin_used+0x13b>
    8d2a:	4c 89 e7             	mov    %r12,%rdi
    8d2d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8d31:	48 0f 46 f0          	cmovbe %rax,%rsi
    8d35:	e8 b6 a6 ff ff       	call   33f0 <strcpy@plt>
    8d3a:	e9 71 f2 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8d3f:	90                   	nop
    8d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8d44:	48 8d 35 f1 13 00 00 	lea    0x13f1(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    8d4b:	48 8d 05 e9 13 00 00 	lea    0x13e9(%rip),%rax        # a13b <_IO_stdin_used+0x13b>
    8d52:	0f 2f c8             	comiss %xmm0,%xmm1
    8d55:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8d5c:	00 
    8d5d:	4c 89 e7             	mov    %r12,%rdi
    8d60:	48 0f 46 f0          	cmovbe %rax,%rsi
    8d64:	e8 87 a6 ff ff       	call   33f0 <strcpy@plt>
    8d69:	e9 42 f2 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8d6e:	66 90                	xchg   %ax,%ax
    8d70:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8d75:	45 85 c0             	test   %r8d,%r8d
    8d78:	75 34                	jne    8dae <fwp_write+0xe7e>
    8d7a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d81:	00 
    8d82:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d89:	00 00 
    8d8b:	0f 85 74 f6 ff ff    	jne    8405 <fwp_write+0x4d5>
    8d91:	ba 02 00 00 00       	mov    $0x2,%edx
    8d96:	48 8d 35 1a 14 00 00 	lea    0x141a(%rip),%rsi        # a1b7 <_IO_stdin_used+0x1b7>
    8d9d:	e9 a1 f3 ff ff       	jmp    8143 <fwp_write+0x213>
    8da2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8da6:	49 89 f0             	mov    %rsi,%r8
    8da9:	e9 e5 fc ff ff       	jmp    8a93 <fwp_write+0xb63>
    8dae:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8db3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8db8:	85 ff                	test   %edi,%edi
    8dba:	0f 84 fa f3 ff ff    	je     81ba <fwp_write+0x28a>
    8dc0:	ba 01 00 00 00       	mov    $0x1,%edx
    8dc5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dca:	48 89 df             	mov    %rbx,%rdi
    8dcd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8dd2:	e8 99 b2 ff ff       	call   4070 <buf_put>
    8dd7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8ddc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8de1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8de7:	85 c0                	test   %eax,%eax
    8de9:	0f 8f f0 f3 ff ff    	jg     81df <fwp_write+0x2af>
    8def:	e9 34 f4 ff ff       	jmp    8228 <fwp_write+0x2f8>
    8df4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8df8:	49 89 c5             	mov    %rax,%r13
    8dfb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8e00:	49 89 c4             	mov    %rax,%r12
    8e03:	49 c1 fd 3f          	sar    $0x3f,%r13
    8e07:	4c 09 e8             	or     %r13,%rax
    8e0a:	0f 84 a7 00 00 00    	je     8eb7 <fwp_write+0xf87>
    8e10:	48 8d 2d a9 34 00 00 	lea    0x34a9(%rip),%rbp        # c2c0 <units.0>
    8e17:	4d 89 e7             	mov    %r12,%r15
    8e1a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8e1e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8e23:	4c 89 ff             	mov    %r15,%rdi
    8e26:	4c 89 ee             	mov    %r13,%rsi
    8e29:	44 89 0c 24          	mov    %r9d,(%rsp)
    8e2d:	48 99                	cqto
    8e2f:	48 89 d1             	mov    %rdx,%rcx
    8e32:	48 89 c2             	mov    %rax,%rdx
    8e35:	e8 16 0f 00 00       	call   9d50 <__divmodti4>
    8e3a:	44 8b 0c 24          	mov    (%rsp),%r9d
    8e3e:	48 89 c1             	mov    %rax,%rcx
    8e41:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8e46:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8e4b:	0f 84 94 00 00 00    	je     8ee5 <fwp_write+0xfb5>
    8e51:	41 83 c1 01          	add    $0x1,%r9d
    8e55:	48 83 c5 10          	add    $0x10,%rbp
    8e59:	41 83 f9 05          	cmp    $0x5,%r9d
    8e5d:	75 bb                	jne    8e1a <fwp_write+0xeea>
    8e5f:	4d 85 ed             	test   %r13,%r13
    8e62:	79 53                	jns    8eb7 <fwp_write+0xf87>
    8e64:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8e69:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8e6e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8e73:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8e78:	48 99                	cqto
    8e7a:	48 f7 d8             	neg    %rax
    8e7d:	48 83 d2 00          	adc    $0x0,%rdx
    8e81:	48 89 c6             	mov    %rax,%rsi
    8e84:	48 f7 da             	neg    %rdx
    8e87:	e8 b4 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8e8c:	49 89 e8             	mov    %rbp,%r8
    8e8f:	ba 00 02 00 00       	mov    $0x200,%edx
    8e94:	be 02 00 00 00       	mov    $0x2,%esi
    8e99:	31 c0                	xor    %eax,%eax
    8e9b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ea2:	00 
    8ea3:	48 8d 0d 08 13 00 00 	lea    0x1308(%rip),%rcx        # a1b2 <_IO_stdin_used+0x1b2>
    8eaa:	4c 89 e7             	mov    %r12,%rdi
    8ead:	e8 2e a8 ff ff       	call   36e0 <__sprintf_chk@plt>
    8eb2:	e9 f9 f0 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8eb7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8ebc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    8ec1:	31 d2                	xor    %edx,%edx
    8ec3:	48 89 ef             	mov    %rbp,%rdi
    8ec6:	e8 75 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8ecb:	eb bf                	jmp    8e8c <fwp_write+0xf5c>
    8ecd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    8ed4:	4e 61 4e 00 
    8ed8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8edf:	00 
    8ee0:	e9 cb f0 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8ee5:	44 89 0c 24          	mov    %r9d,(%rsp)
    8ee9:	48 89 c8             	mov    %rcx,%rax
    8eec:	48 85 d2             	test   %rdx,%rdx
    8eef:	78 51                	js     8f42 <fwp_write+0x1012>
    8ef1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8ef6:	48 89 c6             	mov    %rax,%rsi
    8ef9:	48 89 ef             	mov    %rbp,%rdi
    8efc:	e8 3f ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f01:	44 8b 0c 24          	mov    (%rsp),%r9d
    8f05:	49 63 c1             	movslq %r9d,%rax
    8f08:	49 89 e8             	mov    %rbp,%r8
    8f0b:	ba 00 02 00 00       	mov    $0x200,%edx
    8f10:	be 02 00 00 00       	mov    $0x2,%esi
    8f15:	48 c1 e0 04          	shl    $0x4,%rax
    8f19:	48 8d 3d a0 33 00 00 	lea    0x33a0(%rip),%rdi        # c2c0 <units.0>
    8f20:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f27:	00 
    8f28:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    8f2c:	48 8d 0d 7a 12 00 00 	lea    0x127a(%rip),%rcx        # a1ad <_IO_stdin_used+0x1ad>
    8f33:	4c 89 e7             	mov    %r12,%rdi
    8f36:	31 c0                	xor    %eax,%eax
    8f38:	e8 a3 a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8f3d:	e9 6e f0 ff ff       	jmp    7fb0 <fwp_write+0x80>
    8f42:	48 f7 d8             	neg    %rax
    8f45:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8f4a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8f4f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f54:	48 83 d2 00          	adc    $0x0,%rdx
    8f58:	48 89 c6             	mov    %rax,%rsi
    8f5b:	48 f7 da             	neg    %rdx
    8f5e:	e8 dd aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f63:	44 8b 0c 24          	mov    (%rsp),%r9d
    8f67:	eb 9c                	jmp    8f05 <fwp_write+0xfd5>
    8f69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000008f70 <fwp_main_thread>:
    8f70:	f3 0f 1e fa          	endbr64
    8f74:	41 57                	push   %r15
    8f76:	41 56                	push   %r14
    8f78:	41 55                	push   %r13
    8f7a:	41 54                	push   %r12
    8f7c:	55                   	push   %rbp
    8f7d:	53                   	push   %rbx
    8f7e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    8f85:	8b 0d 79 6b 01 00    	mov    0x16b79(%rip),%ecx        # 1fb04 <fwp_heap+0x13a4>
    8f8b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    8f92:	00 00 
    8f94:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    8f9b:	00 
    8f9c:	31 c0                	xor    %eax,%eax
    8f9e:	85 c9                	test   %ecx,%ecx
    8fa0:	0f 84 62 06 00 00    	je     9608 <fwp_main_thread+0x698>
    8fa6:	8b 15 5c 6b 01 00    	mov    0x16b5c(%rip),%edx        # 1fb08 <fwp_heap+0x13a8>
    8fac:	85 d2                	test   %edx,%edx
    8fae:	0f 85 3c 06 00 00    	jne    95f0 <fwp_main_thread+0x680>
    8fb4:	48 8d 05 c5 50 00 00 	lea    0x50c5(%rip),%rax        # e080 <alt.5>
    8fbb:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    8fc0:	31 f6                	xor    %esi,%esi
    8fc2:	48 c7 05 2b 51 01 00 	movq   $0x40000000,0x1512b(%rip)        # 1e0f8 <fwp_main_stack_size>
    8fc9:	00 00 00 40 
    8fcd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8fd2:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    8fd7:	48 89 c7             	mov    %rax,%rdi
    8fda:	4c 89 25 1f 51 01 00 	mov    %r12,0x1511f(%rip)        # 1e100 <fwp_main_stack_top>
    8fe1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    8fe8:	01 00 
    8fea:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    8ff1:	00 
    8ff2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ff7:	e8 c4 a6 ff ff       	call   36c0 <sigaltstack@plt>
    8ffc:	85 c0                	test   %eax,%eax
    8ffe:	0f 85 13 0d 00 00    	jne    9d17 <fwp_main_thread+0xda7>
    9004:	31 ed                	xor    %ebp,%ebp
    9006:	b9 12 00 00 00       	mov    $0x12,%ecx
    900b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9012:	00 
    9013:	48 89 e8             	mov    %rbp,%rax
    9016:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    901d:	00 
    901e:	f3 48 ab             	rep stos %rax,(%rdi)
    9021:	48 8d 05 c8 ac ff ff 	lea    -0x5338(%rip),%rax        # 3cf0 <fwp_segv>
    9028:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    902f:	00 
    9030:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    9037:	04 00 00 08 
    903b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9042:	00 
    9043:	e8 38 a5 ff ff       	call   3580 <sigemptyset@plt>
    9048:	85 c0                	test   %eax,%eax
    904a:	0f 85 c7 0c 00 00    	jne    9d17 <fwp_main_thread+0xda7>
    9050:	31 d2                	xor    %edx,%edx
    9052:	48 89 de             	mov    %rbx,%rsi
    9055:	bf 0b 00 00 00       	mov    $0xb,%edi
    905a:	e8 a1 a3 ff ff       	call   3400 <sigaction@plt>
    905f:	85 c0                	test   %eax,%eax
    9061:	0f 85 b0 0c 00 00    	jne    9d17 <fwp_main_thread+0xda7>
    9067:	31 d2                	xor    %edx,%edx
    9069:	48 89 de             	mov    %rbx,%rsi
    906c:	bf 07 00 00 00       	mov    $0x7,%edi
    9071:	e8 8a a3 ff ff       	call   3400 <sigaction@plt>
    9076:	85 c0                	test   %eax,%eax
    9078:	0f 85 99 0c 00 00    	jne    9d17 <fwp_main_thread+0xda7>
    907e:	8b 05 e4 4f 00 00    	mov    0x4fe4(%rip),%eax        # e068 <st.3>
    9084:	85 c0                	test   %eax,%eax
    9086:	0f 84 8c 05 00 00    	je     9618 <fwp_main_thread+0x6a8>
    908c:	48 8b 2d ad 56 01 00 	mov    0x156ad(%rip),%rbp        # 1e740 <fwp_cur>
    9093:	48 85 ed             	test   %rbp,%rbp
    9096:	0f 84 04 03 00 00    	je     93a0 <fwp_main_thread+0x430>
    909c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    90a1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    90a5:	48 89 eb             	mov    %rbp,%rbx
    90a8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    90ad:	0f 84 41 01 00 00    	je     91f4 <fwp_main_thread+0x284>
    90b3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    90b8:	0f 84 12 02 00 00    	je     92d0 <fwp_main_thread+0x360>
    90be:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    90c2:	0f 84 f8 01 00 00    	je     92c0 <fwp_main_thread+0x350>
    90c8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    90cc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    90d0:	0f 85 7a 02 00 00    	jne    9350 <fwp_main_thread+0x3e0>
    90d6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    90da:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    90e1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    90e5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    90ec:	00 00 00 00 
    90f0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    90f7:	48 85 d2             	test   %rdx,%rdx
    90fa:	74 07                	je     9103 <fwp_main_thread+0x193>
    90fc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9103:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9107:	48 85 c0             	test   %rax,%rax
    910a:	74 34                	je     9140 <fwp_main_thread+0x1d0>
    910c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9110:	48 8b 05 01 56 01 00 	mov    0x15601(%rip),%rax        # 1e718 <fwp_timers>
    9117:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    911b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9122:	00 00 00 00 
    9126:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    912d:	48 85 c0             	test   %rax,%rax
    9130:	74 07                	je     9139 <fwp_main_thread+0x1c9>
    9132:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9139:	48 89 1d d8 55 01 00 	mov    %rbx,0x155d8(%rip)        # 1e718 <fwp_timers>
    9140:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9144:	e8 27 de ff ff       	call   6f70 <fwp_block>
    9149:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9150:	48 85 c9             	test   %rcx,%rcx
    9153:	74 47                	je     919c <fwp_main_thread+0x22c>
    9155:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    915c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9163:	48 85 d2             	test   %rdx,%rdx
    9166:	0f 84 24 02 00 00    	je     9390 <fwp_main_thread+0x420>
    916c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9173:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    917a:	48 85 c0             	test   %rax,%rax
    917d:	74 07                	je     9186 <fwp_main_thread+0x216>
    917f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9186:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    918d:	00 00 00 00 
    9191:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9195:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    919c:	48 8b 0d 9d 55 01 00 	mov    0x1559d(%rip),%rcx        # 1e740 <fwp_cur>
    91a3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    91a7:	0f 84 93 01 00 00    	je     9340 <fwp_main_thread+0x3d0>
    91ad:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    91b4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    91bb:	48 85 d2             	test   %rdx,%rdx
    91be:	0f 84 94 03 00 00    	je     9558 <fwp_main_thread+0x5e8>
    91c4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    91cb:	48 85 c0             	test   %rax,%rax
    91ce:	74 07                	je     91d7 <fwp_main_thread+0x267>
    91d0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    91d7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    91db:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    91df:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    91e6:	48 89 cb             	mov    %rcx,%rbx
    91e9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    91ee:	0f 85 bf fe ff ff    	jne    90b3 <fwp_main_thread+0x143>
    91f4:	48 83 3d dc 71 01 00 	cmpq   $0x0,0x171dc(%rip)        # 203d8 <fwp_state_len>
    91fb:	00 
    91fc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9200:	0f 84 7c 03 00 00    	je     9582 <fwp_main_thread+0x612>
    9206:	48 39 1d 2b 55 01 00 	cmp    %rbx,0x1552b(%rip)        # 1e738 <fwp_root>
    920d:	c7 05 69 4e 01 00 00 	movl   $0x0,0x14e69(%rip)        # 1e080 <fwp_exit_code>
    9214:	00 00 00 
    9217:	0f 85 28 0b 00 00    	jne    9d45 <fwp_main_thread+0xdd5>
    921d:	48 85 db             	test   %rbx,%rbx
    9220:	0f 84 a0 01 00 00    	je     93c6 <fwp_main_thread+0x456>
    9226:	48 8b 15 db 54 01 00 	mov    0x154db(%rip),%rdx        # 1e708 <fwp_tasks_active>
    922d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9231:	48 85 d2             	test   %rdx,%rdx
    9234:	0f 84 8c 01 00 00    	je     93c6 <fwp_main_thread+0x456>
    923a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9240:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9244:	75 08                	jne    924e <fwp_main_thread+0x2de>
    9246:	48 89 d7             	mov    %rdx,%rdi
    9249:	e8 62 ae ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    924e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9255:	48 85 d2             	test   %rdx,%rdx
    9258:	75 e6                	jne    9240 <fwp_main_thread+0x2d0>
    925a:	eb 31                	jmp    928d <fwp_main_thread+0x31d>
    925c:	0f 1f 40 00          	nopl   0x0(%rax)
    9260:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9267:	48 89 1d b2 54 01 00 	mov    %rbx,0x154b2(%rip)        # 1e720 <fwp_ready_tail>
    926e:	e8 fd dc ff ff       	call   6f70 <fwp_block>
    9273:	e8 e8 da ff ff       	call   6d60 <fwp_free_zombie>
    9278:	48 83 3d 88 54 01 00 	cmpq   $0x0,0x15488(%rip)        # 1e708 <fwp_tasks_active>
    927f:	00 
    9280:	0f 84 40 01 00 00    	je     93c6 <fwp_main_thread+0x456>
    9286:	48 8b 1d ab 54 01 00 	mov    0x154ab(%rip),%rbx        # 1e738 <fwp_root>
    928d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9291:	75 db                	jne    926e <fwp_main_thread+0x2fe>
    9293:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9297:	75 d5                	jne    926e <fwp_main_thread+0x2fe>
    9299:	48 8b 05 80 54 01 00 	mov    0x15480(%rip),%rax        # 1e720 <fwp_ready_tail>
    92a0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    92a4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    92ab:	00 00 00 00 
    92af:	48 85 c0             	test   %rax,%rax
    92b2:	75 ac                	jne    9260 <fwp_main_thread+0x2f0>
    92b4:	48 89 1d 6d 54 01 00 	mov    %rbx,0x1546d(%rip)        # 1e728 <fwp_ready_head>
    92bb:	eb aa                	jmp    9267 <fwp_main_thread+0x2f7>
    92bd:	0f 1f 00             	nopl   (%rax)
    92c0:	e8 4b b0 ff ff       	call   4310 <fwp_now_ns>
    92c5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    92c9:	0f 8d 99 02 00 00    	jge    9568 <fwp_main_thread+0x5f8>
    92cf:	90                   	nop
    92d0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    92d4:	0f 85 ee fd ff ff    	jne    90c8 <fwp_main_thread+0x158>
    92da:	48 8b 45 60          	mov    0x60(%rbp),%rax
    92de:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    92e2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    92e6:	0f 85 ee fd ff ff    	jne    90da <fwp_main_thread+0x16a>
    92ec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    92f0:	48 85 c9             	test   %rcx,%rcx
    92f3:	0f 84 e1 fd ff ff    	je     90da <fwp_main_thread+0x16a>
    92f9:	48 39 c8             	cmp    %rcx,%rax
    92fc:	48 89 ce             	mov    %rcx,%rsi
    92ff:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9306:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    930a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9311:	00 00 00 00 
    9315:	48 0f 4e f0          	cmovle %rax,%rsi
    9319:	48 85 c0             	test   %rax,%rax
    931c:	48 89 c8             	mov    %rcx,%rax
    931f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9326:	48 0f 45 c6          	cmovne %rsi,%rax
    932a:	48 85 d2             	test   %rdx,%rdx
    932d:	74 07                	je     9336 <fwp_main_thread+0x3c6>
    932f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9336:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    933a:	e9 cd fd ff ff       	jmp    910c <fwp_main_thread+0x19c>
    933f:	90                   	nop
    9340:	48 89 cb             	mov    %rcx,%rbx
    9343:	e9 60 fd ff ff       	jmp    90a8 <fwp_main_thread+0x138>
    9348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    934f:	00 
    9350:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9354:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    935b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9362:	00 00 00 00 
    9366:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    936d:	48 85 c0             	test   %rax,%rax
    9370:	0f 84 8a 08 00 00    	je     9c00 <fwp_main_thread+0xc90>
    9376:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    937d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9381:	e9 ba fd ff ff       	jmp    9140 <fwp_main_thread+0x1d0>
    9386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    938d:	00 00 00 
    9390:	48 89 01             	mov    %rax,(%rcx)
    9393:	e9 e2 fd ff ff       	jmp    917a <fwp_main_thread+0x20a>
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 
    93a0:	48 83 3d 30 70 01 00 	cmpq   $0x0,0x17030(%rip)        # 203d8 <fwp_state_len>
    93a7:	00 
    93a8:	0f 84 d2 01 00 00    	je     9580 <fwp_main_thread+0x610>
    93ae:	48 83 3d 82 53 01 00 	cmpq   $0x0,0x15382(%rip)        # 1e738 <fwp_root>
    93b5:	00 
    93b6:	c7 05 c0 4c 01 00 00 	movl   $0x0,0x14cc0(%rip)        # 1e080 <fwp_exit_code>
    93bd:	00 00 00 
    93c0:	0f 85 7a 09 00 00    	jne    9d40 <fwp_main_thread+0xdd0>
    93c6:	e8 95 d9 ff ff       	call   6d60 <fwp_free_zombie>
    93cb:	48 83 3d 55 53 01 00 	cmpq   $0x0,0x15355(%rip)        # 1e728 <fwp_ready_head>
    93d2:	00 
    93d3:	0f 85 72 a3 ff ff    	jne    374b <fwp_main_thread.cold>
    93d9:	48 83 3d 37 53 01 00 	cmpq   $0x0,0x15337(%rip)        # 1e718 <fwp_timers>
    93e0:	00 
    93e1:	0f 85 64 a3 ff ff    	jne    374b <fwp_main_thread.cold>
    93e7:	8b 05 1f 4d 01 00    	mov    0x14d1f(%rip),%eax        # 1e10c <fwp_stack_pool_n>
    93ed:	85 c0                	test   %eax,%eax
    93ef:	74 3c                	je     942d <fwp_main_thread+0x4bd>
    93f1:	83 e8 01             	sub    $0x1,%eax
    93f4:	4c 8d 25 25 4d 01 00 	lea    0x14d25(%rip),%r12        # 1e120 <fwp_stack_pool>
    93fb:	48 63 d8             	movslq %eax,%rbx
    93fe:	89 c0                	mov    %eax,%eax
    9400:	48 89 da             	mov    %rbx,%rdx
    9403:	48 29 c2             	sub    %rax,%rdx
    9406:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    940a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9410:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9414:	89 1d f2 4c 01 00    	mov    %ebx,0x14cf2(%rip)        # 1e10c <fwp_stack_pool_n>
    941a:	be 00 00 00 10       	mov    $0x10000000,%esi
    941f:	48 83 eb 01          	sub    $0x1,%rbx
    9423:	e8 b8 a1 ff ff       	call   35e0 <munmap@plt>
    9428:	48 39 dd             	cmp    %rbx,%rbp
    942b:	75 e3                	jne    9410 <fwp_main_thread+0x4a0>
    942d:	8b 3d dd 4b 00 00    	mov    0x4bdd(%rip),%edi        # e010 <fwp_epfd>
    9433:	85 ff                	test   %edi,%edi
    9435:	78 05                	js     943c <fwp_main_thread+0x4cc>
    9437:	e8 94 a0 ff ff       	call   34d0 <close@plt>
    943c:	4c 8b 25 dd 4e 01 00 	mov    0x14edd(%rip),%r12        # 1e320 <fwp_nfdws>
    9443:	48 8b 2d de 4e 01 00 	mov    0x14ede(%rip),%rbp        # 1e328 <fwp_fdws>
    944a:	31 db                	xor    %ebx,%ebx
    944c:	c7 05 ba 4b 00 00 ff 	movl   $0xffffffff,0x4bba(%rip)        # e010 <fwp_epfd>
    9453:	ff ff ff 
    9456:	4d 85 e4             	test   %r12,%r12
    9459:	74 32                	je     948d <fwp_main_thread+0x51d>
    945b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9460:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9465:	48 85 ff             	test   %rdi,%rdi
    9468:	74 1a                	je     9484 <fwp_main_thread+0x514>
    946a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    946e:	0f 85 d7 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9474:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9479:	0f 85 cc a2 ff ff    	jne    374b <fwp_main_thread.cold>
    947f:	e8 cc c0 ff ff       	call   5550 <fwp_mem_free>
    9484:	48 83 c3 01          	add    $0x1,%rbx
    9488:	49 39 dc             	cmp    %rbx,%r12
    948b:	75 d3                	jne    9460 <fwp_main_thread+0x4f0>
    948d:	48 89 ef             	mov    %rbp,%rdi
    9490:	e8 bb c0 ff ff       	call   5550 <fwp_mem_free>
    9495:	48 8b 15 9c 52 01 00 	mov    0x1529c(%rip),%rdx        # 1e738 <fwp_root>
    949c:	48 c7 05 81 4e 01 00 	movq   $0x0,0x14e81(%rip)        # 1e328 <fwp_fdws>
    94a3:	00 00 00 00 
    94a7:	48 c7 05 6e 4e 01 00 	movq   $0x0,0x14e6e(%rip)        # 1e320 <fwp_nfdws>
    94ae:	00 00 00 00 
    94b2:	48 85 d2             	test   %rdx,%rdx
    94b5:	74 4e                	je     9505 <fwp_main_thread+0x595>
    94b7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    94bc:	0f 85 89 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94c2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    94c9:	00 
    94ca:	0f 85 7b a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94d0:	48 83 3d 00 6f 01 00 	cmpq   $0x0,0x16f00(%rip)        # 203d8 <fwp_state_len>
    94d7:	00 
    94d8:	0f 85 6d a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94de:	48 83 3d e2 6e 01 00 	cmpq   $0x0,0x16ee2(%rip)        # 203c8 <fwp_state_owners>
    94e5:	00 
    94e6:	0f 85 5f a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94ec:	b9 79 00 00 00       	mov    $0x79,%ecx
    94f1:	31 c0                	xor    %eax,%eax
    94f3:	48 8d 3d 46 4e 01 00 	lea    0x14e46(%rip),%rdi        # 1e340 <fwp_root_context>
    94fa:	f3 48 ab             	rep stos %rax,(%rdi)
    94fd:	48 89 d7             	mov    %rdx,%rdi
    9500:	e8 4b c0 ff ff       	call   5550 <fwp_mem_free>
    9505:	48 8b 3d 14 4b 00 00 	mov    0x4b14(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    950c:	48 c7 05 29 52 01 00 	movq   $0x0,0x15229(%rip)        # 1e740 <fwp_cur>
    9513:	00 00 00 00 
    9517:	48 c7 05 16 52 01 00 	movq   $0x0,0x15216(%rip)        # 1e738 <fwp_root>
    951e:	00 00 00 00 
    9522:	e8 99 a0 ff ff       	call   35c0 <fflush@plt>
    9527:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    952e:	00 
    952f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9536:	00 00 
    9538:	0f 85 f1 07 00 00    	jne    9d2f <fwp_main_thread+0xdbf>
    953e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9545:	31 c0                	xor    %eax,%eax
    9547:	5b                   	pop    %rbx
    9548:	5d                   	pop    %rbp
    9549:	41 5c                	pop    %r12
    954b:	41 5d                	pop    %r13
    954d:	41 5e                	pop    %r14
    954f:	41 5f                	pop    %r15
    9551:	c3                   	ret
    9552:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9558:	48 89 05 b9 51 01 00 	mov    %rax,0x151b9(%rip)        # 1e718 <fwp_timers>
    955f:	e9 67 fc ff ff       	jmp    91cb <fwp_main_thread+0x25b>
    9564:	0f 1f 40 00          	nopl   0x0(%rax)
    9568:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    956c:	0f 85 5e fd ff ff    	jne    92d0 <fwp_main_thread+0x360>
    9572:	48 89 ef             	mov    %rbp,%rdi
    9575:	e8 36 ab ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    957a:	e9 51 fd ff ff       	jmp    92d0 <fwp_main_thread+0x360>
    957f:	90                   	nop
    9580:	31 db                	xor    %ebx,%ebx
    9582:	48 83 3d 3e 6e 01 00 	cmpq   $0x0,0x16e3e(%rip)        # 203c8 <fwp_state_owners>
    9589:	00 
    958a:	0f 85 76 fc ff ff    	jne    9206 <fwp_main_thread+0x296>
    9590:	48 8b 3d 49 6e 01 00 	mov    0x16e49(%rip),%rdi        # 203e0 <fwp_state>
    9597:	e8 b4 bf ff ff       	call   5550 <fwp_mem_free>
    959c:	48 c7 05 39 6e 01 00 	movq   $0x0,0x16e39(%rip)        # 203e0 <fwp_state>
    95a3:	00 00 00 00 
    95a7:	48 c7 05 1e 6e 01 00 	movq   $0x0,0x16e1e(%rip)        # 203d0 <fwp_state_cap>
    95ae:	00 00 00 00 
    95b2:	48 85 db             	test   %rbx,%rbx
    95b5:	0f 84 0f 07 00 00    	je     9cca <fwp_main_thread+0xd5a>
    95bb:	48 39 1d 76 51 01 00 	cmp    %rbx,0x15176(%rip)        # 1e738 <fwp_root>
    95c2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    95c9:	00 00 00 00 
    95cd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    95d4:	00 00 00 00 
    95d8:	c7 05 9e 4a 01 00 00 	movl   $0x0,0x14a9e(%rip)        # 1e080 <fwp_exit_code>
    95df:	00 00 00 
    95e2:	0f 84 3e fc ff ff    	je     9226 <fwp_main_thread+0x2b6>
    95e8:	e9 5e a1 ff ff       	jmp    374b <fwp_main_thread.cold>
    95ed:	0f 1f 00             	nopl   (%rax)
    95f0:	48 8d 3d 29 b4 ff ff 	lea    -0x4bd7(%rip),%rdi        # 4a20 <fwp_heap_report>
    95f7:	e8 64 09 00 00       	call   9f60 <atexit>
    95fc:	e9 b3 f9 ff ff       	jmp    8fb4 <fwp_main_thread+0x44>
    9601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9608:	e8 23 b5 ff ff       	call   4b30 <fwp_heap_init>
    960d:	e9 94 f9 ff ff       	jmp    8fa6 <fwp_main_thread+0x36>
    9612:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9618:	48 8d 05 71 df ff ff 	lea    -0x208f(%rip),%rax        # 7590 <fwp_drop1>
    961f:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9624:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    962b:	00 00 
    962d:	4c 8d 3d 2c 51 01 00 	lea    0x1512c(%rip),%r15        # 1e760 <fwp_heap>
    9634:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9639:	48 8b 05 b8 6d 01 00 	mov    0x16db8(%rip),%rax        # 203f8 <fwp_cleanups>
    9640:	4c 89 25 b1 6d 01 00 	mov    %r12,0x16db1(%rip)        # 203f8 <fwp_cleanups>
    9647:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    964d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9651:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9656:	48 8d 05 73 a5 ff ff 	lea    -0x5a8d(%rip),%rax        # 3bd0 <fwp_range_release>
    965d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9662:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9667:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    966c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9671:	eb 3e                	jmp    96b1 <fwp_main_thread+0x741>
    9673:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9678:	80 f9 01             	cmp    $0x1,%cl
    967b:	75 29                	jne    96a6 <fwp_main_thread+0x736>
    967d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9680:	0f b7 c0             	movzwl %ax,%eax
    9683:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9686:	48 0f af c1          	imul   %rcx,%rax
    968a:	48 c1 e8 20          	shr    $0x20,%rax
    968e:	48 39 d0             	cmp    %rdx,%rax
    9691:	73 13                	jae    96a6 <fwp_main_thread+0x736>
    9693:	49 01 c5             	add    %rax,%r13
    9696:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    969b:	0f 84 9f 05 00 00    	je     9c40 <fwp_main_thread+0xcd0>
    96a1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    96a6:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    96ab:	49 83 ec 01          	sub    $0x1,%r12
    96af:	72 7f                	jb     9730 <fwp_main_thread+0x7c0>
    96b1:	48 89 de             	mov    %rbx,%rsi
    96b4:	bf 01 00 00 00       	mov    $0x1,%edi
    96b9:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    96c0:	00 
    96c1:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    96c6:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    96cd:	00 
    96ce:	e8 9d c4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    96d3:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    96da:	48 89 c5             	mov    %rax,%rbp
    96dd:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    96e4:	48 c1 e2 10          	shl    $0x10,%rdx
    96e8:	48 39 d0             	cmp    %rdx,%rax
    96eb:	73 b9                	jae    96a6 <fwp_main_thread+0x736>
    96ed:	48 89 c2             	mov    %rax,%rdx
    96f0:	48 c1 ea 10          	shr    $0x10,%rdx
    96f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96f8:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    96ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9703:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9707:	4d 85 ed             	test   %r13,%r13
    970a:	74 9a                	je     96a6 <fwp_main_thread+0x736>
    970c:	0f b6 0a             	movzbl (%rdx),%ecx
    970f:	80 f9 02             	cmp    $0x2,%cl
    9712:	0f 85 60 ff ff ff    	jne    9678 <fwp_main_thread+0x708>
    9718:	66 85 c0             	test   %ax,%ax
    971b:	0f 84 75 ff ff ff    	je     9696 <fwp_main_thread+0x726>
    9721:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9726:	49 83 ec 01          	sub    $0x1,%r12
    972a:	73 85                	jae    96b1 <fwp_main_thread+0x741>
    972c:	0f 1f 40 00          	nopl   0x0(%rax)
    9730:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9735:	66 0f 6f 05 33 13 00 	movdqa 0x1333(%rip),%xmm0        # aa70 <msg.4+0xa0>
    973c:	00 
    973d:	48 89 de             	mov    %rbx,%rsi
    9740:	bf 01 00 00 00       	mov    $0x1,%edi
    9745:	48 89 05 ac 6c 01 00 	mov    %rax,0x16cac(%rip)        # 203f8 <fwp_cleanups>
    974c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9753:	00 
    9754:	e8 17 c4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9759:	48 8b 15 d8 63 01 00 	mov    0x163d8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9760:	49 89 c4             	mov    %rax,%r12
    9763:	48 2b 05 a6 63 01 00 	sub    0x163a6(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    976a:	48 c1 e2 10          	shl    $0x10,%rdx
    976e:	48 39 d0             	cmp    %rdx,%rax
    9771:	73 55                	jae    97c8 <fwp_main_thread+0x858>
    9773:	48 89 c2             	mov    %rax,%rdx
    9776:	48 c1 ea 10          	shr    $0x10,%rdx
    977a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    977e:	48 8b 15 d3 63 01 00 	mov    0x163d3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9785:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9789:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    978d:	48 85 db             	test   %rbx,%rbx
    9790:	74 36                	je     97c8 <fwp_main_thread+0x858>
    9792:	0f b6 0a             	movzbl (%rdx),%ecx
    9795:	80 f9 02             	cmp    $0x2,%cl
    9798:	0f 84 92 04 00 00    	je     9c30 <fwp_main_thread+0xcc0>
    979e:	80 f9 01             	cmp    $0x1,%cl
    97a1:	75 25                	jne    97c8 <fwp_main_thread+0x858>
    97a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97a6:	0f b7 c0             	movzwl %ax,%eax
    97a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97ac:	48 0f af c1          	imul   %rcx,%rax
    97b0:	48 c1 e8 20          	shr    $0x20,%rax
    97b4:	48 39 d0             	cmp    %rdx,%rax
    97b7:	73 0f                	jae    97c8 <fwp_main_thread+0x858>
    97b9:	48 01 c3             	add    %rax,%rbx
    97bc:	80 3b ff             	cmpb   $0xff,(%rbx)
    97bf:	0f 84 2b 05 00 00    	je     9cf0 <fwp_main_thread+0xd80>
    97c5:	c6 03 01             	movb   $0x1,(%rbx)
    97c8:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    97cd:	bf 01 00 00 00       	mov    $0x1,%edi
    97d2:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    97d7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    97de:	00 f0 3f 
    97e1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    97e6:	e8 85 c3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    97eb:	48 8b 15 46 63 01 00 	mov    0x16346(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    97f2:	49 89 c4             	mov    %rax,%r12
    97f5:	48 2b 05 14 63 01 00 	sub    0x16314(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    97fc:	48 c1 e2 10          	shl    $0x10,%rdx
    9800:	48 39 d0             	cmp    %rdx,%rax
    9803:	73 55                	jae    985a <fwp_main_thread+0x8ea>
    9805:	48 89 c2             	mov    %rax,%rdx
    9808:	48 c1 ea 10          	shr    $0x10,%rdx
    980c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9810:	48 8b 15 41 63 01 00 	mov    0x16341(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9817:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    981b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    981f:	48 85 db             	test   %rbx,%rbx
    9822:	74 36                	je     985a <fwp_main_thread+0x8ea>
    9824:	0f b6 0a             	movzbl (%rdx),%ecx
    9827:	80 f9 02             	cmp    $0x2,%cl
    982a:	0f 84 f0 03 00 00    	je     9c20 <fwp_main_thread+0xcb0>
    9830:	80 f9 01             	cmp    $0x1,%cl
    9833:	75 25                	jne    985a <fwp_main_thread+0x8ea>
    9835:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9838:	0f b7 c0             	movzwl %ax,%eax
    983b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    983e:	48 0f af c1          	imul   %rcx,%rax
    9842:	48 c1 e8 20          	shr    $0x20,%rax
    9846:	48 39 d0             	cmp    %rdx,%rax
    9849:	73 0f                	jae    985a <fwp_main_thread+0x8ea>
    984b:	48 01 c3             	add    %rax,%rbx
    984e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9851:	0f 84 a6 04 00 00    	je     9cfd <fwp_main_thread+0xd8d>
    9857:	c6 03 01             	movb   $0x1,(%rbx)
    985a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    985f:	bf 01 00 00 00       	mov    $0x1,%edi
    9864:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9869:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9870:	33 f3 bf 
    9873:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9878:	e8 f3 c2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    987d:	48 8b 15 b4 62 01 00 	mov    0x162b4(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9884:	48 8b 0d 85 62 01 00 	mov    0x16285(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    988b:	49 89 c4             	mov    %rax,%r12
    988e:	48 89 d6             	mov    %rdx,%rsi
    9891:	48 29 c8             	sub    %rcx,%rax
    9894:	48 c1 e6 10          	shl    $0x10,%rsi
    9898:	48 39 f0             	cmp    %rsi,%rax
    989b:	73 65                	jae    9902 <fwp_main_thread+0x992>
    989d:	48 89 c6             	mov    %rax,%rsi
    98a0:	48 c1 ee 10          	shr    $0x10,%rsi
    98a4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    98a8:	48 8b 35 a9 62 01 00 	mov    0x162a9(%rip),%rsi        # 1fb58 <fwp_heap+0x13f8>
    98af:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    98b3:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    98b7:	48 85 db             	test   %rbx,%rbx
    98ba:	74 46                	je     9902 <fwp_main_thread+0x992>
    98bc:	0f b6 3e             	movzbl (%rsi),%edi
    98bf:	40 80 ff 02          	cmp    $0x2,%dil
    98c3:	0f 84 47 03 00 00    	je     9c10 <fwp_main_thread+0xca0>
    98c9:	40 80 ff 01          	cmp    $0x1,%dil
    98cd:	75 33                	jne    9902 <fwp_main_thread+0x992>
    98cf:	8b 7e 18             	mov    0x18(%rsi),%edi
    98d2:	0f b7 c0             	movzwl %ax,%eax
    98d5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    98d8:	48 0f af c7          	imul   %rdi,%rax
    98dc:	48 c1 e8 20          	shr    $0x20,%rax
    98e0:	48 39 f0             	cmp    %rsi,%rax
    98e3:	73 1d                	jae    9902 <fwp_main_thread+0x992>
    98e5:	48 01 c3             	add    %rax,%rbx
    98e8:	80 3b ff             	cmpb   $0xff,(%rbx)
    98eb:	0f 84 19 04 00 00    	je     9d0a <fwp_main_thread+0xd9a>
    98f1:	c6 03 01             	movb   $0x1,(%rbx)
    98f4:	48 8b 0d 15 62 01 00 	mov    0x16215(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    98fb:	48 8b 15 36 62 01 00 	mov    0x16236(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9902:	49 89 ed             	mov    %rbp,%r13
    9905:	e9 01 02 00 00       	jmp    9b0b <fwp_main_thread+0xb9b>
    990a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9910:	80 f9 01             	cmp    $0x1,%cl
    9913:	75 2d                	jne    9942 <fwp_main_thread+0x9d2>
    9915:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9918:	0f b7 c0             	movzwl %ax,%eax
    991b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    991e:	48 0f af c1          	imul   %rcx,%rax
    9922:	48 c1 e8 20          	shr    $0x20,%rax
    9926:	48 39 d0             	cmp    %rdx,%rax
    9929:	73 17                	jae    9942 <fwp_main_thread+0x9d2>
    992b:	48 01 c7             	add    %rax,%rdi
    992e:	0f b6 07             	movzbl (%rdi),%eax
    9931:	84 c0                	test   %al,%al
    9933:	74 0d                	je     9942 <fwp_main_thread+0x9d2>
    9935:	3c fd                	cmp    $0xfd,%al
    9937:	0f 87 83 03 00 00    	ja     9cc0 <fwp_main_thread+0xd50>
    993d:	83 c0 01             	add    $0x1,%eax
    9940:	88 07                	mov    %al,(%rdi)
    9942:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9947:	66 0f ef c0          	pxor   %xmm0,%xmm0
    994b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9950:	4c 89 e6             	mov    %r12,%rsi
    9953:	48 8d 15 46 42 00 00 	lea    0x4246(%rip),%rdx        # dba0 <d0>
    995a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    995f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9966:	00 00 
    9968:	e8 c3 e5 ff ff       	call   7f30 <fwp_write>
    996d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9972:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    9977:	48 8d 05 b0 06 00 00 	lea    0x6b0(%rip),%rax        # a02e <_IO_stdin_used+0x2e>
    997e:	48 85 c9             	test   %rcx,%rcx
    9981:	48 0f 44 c8          	cmove  %rax,%rcx
    9985:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    9989:	0f 87 94 03 00 00    	ja     9d23 <fwp_main_thread+0xdb3>
    998f:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    9993:	be 01 00 00 00       	mov    $0x1,%esi
    9998:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    999d:	e8 ae c0 ff ff       	call   5a50 <fwp_heap_alloc>
    99a2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    99a7:	4c 89 f2             	mov    %r14,%rdx
    99aa:	4c 89 30             	mov    %r14,(%rax)
    99ad:	48 89 c3             	mov    %rax,%rbx
    99b0:	48 8d 78 08          	lea    0x8(%rax),%rdi
    99b4:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    99b9:	e8 e2 9b ff ff       	call   35a0 <memcpy@plt>
    99be:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    99c4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    99c9:	e8 f2 99 ff ff       	call   33c0 <free@plt>
    99ce:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    99d5:	48 89 d8             	mov    %rbx,%rax
    99d8:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    99df:	48 c1 e2 10          	shl    $0x10,%rdx
    99e3:	48 39 d0             	cmp    %rdx,%rax
    99e6:	73 55                	jae    9a3d <fwp_main_thread+0xacd>
    99e8:	48 89 c2             	mov    %rax,%rdx
    99eb:	48 c1 ea 10          	shr    $0x10,%rdx
    99ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99f3:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    99fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99fe:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9a02:	48 85 f6             	test   %rsi,%rsi
    9a05:	74 36                	je     9a3d <fwp_main_thread+0xacd>
    9a07:	0f b6 0a             	movzbl (%rdx),%ecx
    9a0a:	80 f9 02             	cmp    $0x2,%cl
    9a0d:	0f 84 9d 01 00 00    	je     9bb0 <fwp_main_thread+0xc40>
    9a13:	80 f9 01             	cmp    $0x1,%cl
    9a16:	75 25                	jne    9a3d <fwp_main_thread+0xacd>
    9a18:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a1b:	0f b7 c0             	movzwl %ax,%eax
    9a1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a21:	48 0f af c1          	imul   %rcx,%rax
    9a25:	48 c1 e8 20          	shr    $0x20,%rax
    9a29:	48 39 d0             	cmp    %rdx,%rax
    9a2c:	73 0f                	jae    9a3d <fwp_main_thread+0xacd>
    9a2e:	48 01 c6             	add    %rax,%rsi
    9a31:	80 3e ff             	cmpb   $0xff,(%rsi)
    9a34:	0f 84 96 01 00 00    	je     9bd0 <fwp_main_thread+0xc60>
    9a3a:	c6 06 01             	movb   $0x1,(%rsi)
    9a3d:	4c 89 e7             	mov    %r12,%rdi
    9a40:	e8 5b d9 ff ff       	call   73a0 <fwp_drop0>
    9a45:	48 8b 13             	mov    (%rbx),%rdx
    9a48:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9a4d:	be 01 00 00 00       	mov    $0x1,%esi
    9a52:	48 8b 0d 67 69 01 00 	mov    0x16967(%rip),%rcx        # 203c0 <fwp_prog_out>
    9a59:	e8 22 9c ff ff       	call   3680 <fwrite@plt>
    9a5e:	48 8b 35 5b 69 01 00 	mov    0x1695b(%rip),%rsi        # 203c0 <fwp_prog_out>
    9a65:	bf 0a 00 00 00       	mov    $0xa,%edi
    9a6a:	e8 71 9a ff ff       	call   34e0 <fputc@plt>
    9a6f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9a76:	48 89 d8             	mov    %rbx,%rax
    9a79:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9a80:	48 c1 e2 10          	shl    $0x10,%rdx
    9a84:	48 39 d0             	cmp    %rdx,%rax
    9a87:	73 67                	jae    9af0 <fwp_main_thread+0xb80>
    9a89:	48 89 c2             	mov    %rax,%rdx
    9a8c:	48 c1 ea 10          	shr    $0x10,%rdx
    9a90:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a94:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9a9b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a9f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9aa3:	4d 85 f6             	test   %r14,%r14
    9aa6:	74 48                	je     9af0 <fwp_main_thread+0xb80>
    9aa8:	0f b6 0a             	movzbl (%rdx),%ecx
    9aab:	80 f9 02             	cmp    $0x2,%cl
    9aae:	0f 84 ac 00 00 00    	je     9b60 <fwp_main_thread+0xbf0>
    9ab4:	80 f9 01             	cmp    $0x1,%cl
    9ab7:	75 37                	jne    9af0 <fwp_main_thread+0xb80>
    9ab9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9abc:	0f b7 c0             	movzwl %ax,%eax
    9abf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ac2:	48 0f af c1          	imul   %rcx,%rax
    9ac6:	48 c1 e8 20          	shr    $0x20,%rax
    9aca:	48 39 d0             	cmp    %rdx,%rax
    9acd:	73 21                	jae    9af0 <fwp_main_thread+0xb80>
    9acf:	49 01 c6             	add    %rax,%r14
    9ad2:	41 0f b6 06          	movzbl (%r14),%eax
    9ad6:	84 c0                	test   %al,%al
    9ad8:	74 16                	je     9af0 <fwp_main_thread+0xb80>
    9ada:	3c 01                	cmp    $0x1,%al
    9adc:	0f 84 0e 01 00 00    	je     9bf0 <fwp_main_thread+0xc80>
    9ae2:	3c ff                	cmp    $0xff,%al
    9ae4:	0f 84 66 01 00 00    	je     9c50 <fwp_main_thread+0xce0>
    9aea:	83 e8 01             	sub    $0x1,%eax
    9aed:	41 88 06             	mov    %al,(%r14)
    9af0:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9af4:	4d 85 ed             	test   %r13,%r13
    9af7:	0f 84 83 00 00 00    	je     9b80 <fwp_main_thread+0xc10>
    9afd:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9b04:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9b0b:	4c 89 e0             	mov    %r12,%rax
    9b0e:	48 c1 e2 10          	shl    $0x10,%rdx
    9b12:	48 29 c8             	sub    %rcx,%rax
    9b15:	48 39 d0             	cmp    %rdx,%rax
    9b18:	0f 83 24 fe ff ff    	jae    9942 <fwp_main_thread+0x9d2>
    9b1e:	48 89 c2             	mov    %rax,%rdx
    9b21:	48 c1 ea 10          	shr    $0x10,%rdx
    9b25:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b29:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9b30:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b34:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9b38:	48 85 ff             	test   %rdi,%rdi
    9b3b:	0f 84 01 fe ff ff    	je     9942 <fwp_main_thread+0x9d2>
    9b41:	0f b6 0a             	movzbl (%rdx),%ecx
    9b44:	80 f9 02             	cmp    $0x2,%cl
    9b47:	0f 85 c3 fd ff ff    	jne    9910 <fwp_main_thread+0x9a0>
    9b4d:	66 85 c0             	test   %ax,%ax
    9b50:	0f 85 ec fd ff ff    	jne    9942 <fwp_main_thread+0x9d2>
    9b56:	e9 d3 fd ff ff       	jmp    992e <fwp_main_thread+0x9be>
    9b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b60:	66 85 c0             	test   %ax,%ax
    9b63:	0f 84 69 ff ff ff    	je     9ad2 <fwp_main_thread+0xb62>
    9b69:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9b6d:	4d 85 ed             	test   %r13,%r13
    9b70:	75 8b                	jne    9afd <fwp_main_thread+0xb8d>
    9b72:	0f 1f 00             	nopl   (%rax)
    9b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b7c:	00 00 00 00 
    9b80:	4c 89 e7             	mov    %r12,%rdi
    9b83:	e8 18 d8 ff ff       	call   73a0 <fwp_drop0>
    9b88:	48 89 ef             	mov    %rbp,%rdi
    9b8b:	e8 10 d8 ff ff       	call   73a0 <fwp_drop0>
    9b90:	48 c7 05 c5 44 00 00 	movq   $0x0,0x44c5(%rip)        # e060 <v.2>
    9b97:	00 00 00 00 
    9b9b:	c7 05 c3 44 00 00 01 	movl   $0x1,0x44c3(%rip)        # e068 <st.3>
    9ba2:	00 00 00 
    9ba5:	e9 e2 f4 ff ff       	jmp    908c <fwp_main_thread+0x11c>
    9baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9bb0:	66 85 c0             	test   %ax,%ax
    9bb3:	0f 85 84 fe ff ff    	jne    9a3d <fwp_main_thread+0xacd>
    9bb9:	80 3e ff             	cmpb   $0xff,(%rsi)
    9bbc:	0f 85 78 fe ff ff    	jne    9a3a <fwp_main_thread+0xaca>
    9bc2:	0f 1f 00             	nopl   (%rax)
    9bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bcc:	00 00 00 00 
    9bd0:	48 89 f7             	mov    %rsi,%rdi
    9bd3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    9bd8:	e8 33 b7 ff ff       	call   5310 <fwp_rc_forget_slot>
    9bdd:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9be2:	e9 53 fe ff ff       	jmp    9a3a <fwp_main_thread+0xaca>
    9be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bee:	00 00 
    9bf0:	48 89 df             	mov    %rbx,%rdi
    9bf3:	e8 58 b9 ff ff       	call   5550 <fwp_mem_free>
    9bf8:	e9 f3 fe ff ff       	jmp    9af0 <fwp_main_thread+0xb80>
    9bfd:	0f 1f 00             	nopl   (%rax)
    9c00:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9c04:	e9 37 f5 ff ff       	jmp    9140 <fwp_main_thread+0x1d0>
    9c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9c10:	66 85 c0             	test   %ax,%ax
    9c13:	0f 85 e9 fc ff ff    	jne    9902 <fwp_main_thread+0x992>
    9c19:	e9 ca fc ff ff       	jmp    98e8 <fwp_main_thread+0x978>
    9c1e:	66 90                	xchg   %ax,%ax
    9c20:	66 85 c0             	test   %ax,%ax
    9c23:	0f 85 31 fc ff ff    	jne    985a <fwp_main_thread+0x8ea>
    9c29:	e9 20 fc ff ff       	jmp    984e <fwp_main_thread+0x8de>
    9c2e:	66 90                	xchg   %ax,%ax
    9c30:	66 85 c0             	test   %ax,%ax
    9c33:	0f 85 8f fb ff ff    	jne    97c8 <fwp_main_thread+0x858>
    9c39:	e9 7e fb ff ff       	jmp    97bc <fwp_main_thread+0x84c>
    9c3e:	66 90                	xchg   %ax,%ax
    9c40:	4c 89 ef             	mov    %r13,%rdi
    9c43:	e8 c8 b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9c48:	e9 54 fa ff ff       	jmp    96a1 <fwp_main_thread+0x731>
    9c4d:	0f 1f 00             	nopl   (%rax)
    9c50:	4c 89 f0             	mov    %r14,%rax
    9c53:	48 c1 e8 11          	shr    $0x11,%rax
    9c57:	4c 31 f0             	xor    %r14,%rax
    9c5a:	48 89 c2             	mov    %rax,%rdx
    9c5d:	48 c1 ea 09          	shr    $0x9,%rdx
    9c61:	48 31 d0             	xor    %rdx,%rax
    9c64:	0f b6 d0             	movzbl %al,%edx
    9c67:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    9c6e:	00 
    9c6f:	48 85 c0             	test   %rax,%rax
    9c72:	75 19                	jne    9c8d <fwp_main_thread+0xd1d>
    9c74:	e9 bb 00 00 00       	jmp    9d34 <fwp_main_thread+0xdc4>
    9c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9c80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9c84:	48 85 c0             	test   %rax,%rax
    9c87:	0f 84 a7 00 00 00    	je     9d34 <fwp_main_thread+0xdc4>
    9c8d:	48 89 c2             	mov    %rax,%rdx
    9c90:	4c 3b 30             	cmp    (%rax),%r14
    9c93:	75 eb                	jne    9c80 <fwp_main_thread+0xd10>
    9c95:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9c99:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    9c9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9ca1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9ca8:	0f 85 42 fe ff ff    	jne    9af0 <fwp_main_thread+0xb80>
    9cae:	4c 89 f7             	mov    %r14,%rdi
    9cb1:	e8 5a b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9cb6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    9cba:	e9 31 fe ff ff       	jmp    9af0 <fwp_main_thread+0xb80>
    9cbf:	90                   	nop
    9cc0:	e8 2b b5 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9cc5:	e9 78 fc ff ff       	jmp    9942 <fwp_main_thread+0x9d2>
    9cca:	48 83 3d 66 4a 01 00 	cmpq   $0x0,0x14a66(%rip)        # 1e738 <fwp_root>
    9cd1:	00 
    9cd2:	c7 05 a4 43 01 00 00 	movl   $0x0,0x143a4(%rip)        # 1e080 <fwp_exit_code>
    9cd9:	00 00 00 
    9cdc:	0f 84 e4 f6 ff ff    	je     93c6 <fwp_main_thread+0x456>
    9ce2:	e9 64 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cee:	00 00 
    9cf0:	48 89 df             	mov    %rbx,%rdi
    9cf3:	e8 18 b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9cf8:	e9 c8 fa ff ff       	jmp    97c5 <fwp_main_thread+0x855>
    9cfd:	48 89 df             	mov    %rbx,%rdi
    9d00:	e8 0b b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9d05:	e9 4d fb ff ff       	jmp    9857 <fwp_main_thread+0x8e7>
    9d0a:	48 89 df             	mov    %rbx,%rdi
    9d0d:	e8 fe b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9d12:	e9 da fb ff ff       	jmp    98f1 <fwp_main_thread+0x981>
    9d17:	48 8d 3d 2a 0b 00 00 	lea    0xb2a(%rip),%rdi        # a848 <_IO_stdin_used+0x848>
    9d1e:	e8 7d a4 ff ff       	call   41a0 <fwp_trap>
    9d23:	48 8d 3d 94 04 00 00 	lea    0x494(%rip),%rdi        # a1be <_IO_stdin_used+0x1be>
    9d2a:	e8 71 a4 ff ff       	call   41a0 <fwp_trap>
    9d2f:	e8 2c 97 ff ff       	call   3460 <__stack_chk_fail@plt>
    9d34:	48 8d 3d 3d 0a 00 00 	lea    0xa3d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    9d3b:	e8 60 a4 ff ff       	call   41a0 <fwp_trap>
    9d40:	e9 06 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9d45:	e9 01 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009d50 <__divmodti4>:
    9d50:	f3 0f 1e fa          	endbr64
    9d54:	55                   	push   %rbp
    9d55:	49 89 f1             	mov    %rsi,%r9
    9d58:	49 89 d2             	mov    %rdx,%r10
    9d5b:	48 89 fe             	mov    %rdi,%rsi
    9d5e:	49 89 cb             	mov    %rcx,%r11
    9d61:	48 89 e5             	mov    %rsp,%rbp
    9d64:	41 57                	push   %r15
    9d66:	41 56                	push   %r14
    9d68:	41 55                	push   %r13
    9d6a:	41 54                	push   %r12
    9d6c:	53                   	push   %rbx
    9d6d:	4c 89 c3             	mov    %r8,%rbx
    9d70:	45 31 c0             	xor    %r8d,%r8d
    9d73:	4d 85 c9             	test   %r9,%r9
    9d76:	79 12                	jns    9d8a <__divmodti4+0x3a>
    9d78:	31 ff                	xor    %edi,%edi
    9d7a:	48 f7 de             	neg    %rsi
    9d7d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    9d84:	4c 19 cf             	sbb    %r9,%rdi
    9d87:	49 89 f9             	mov    %rdi,%r9
    9d8a:	4c 89 d8             	mov    %r11,%rax
    9d8d:	4d 85 db             	test   %r11,%r11
    9d90:	0f 88 1a 01 00 00    	js     9eb0 <__divmodti4+0x160>
    9d96:	4c 89 d9             	mov    %r11,%rcx
    9d99:	49 89 f3             	mov    %rsi,%r11
    9d9c:	75 62                	jne    9e00 <__divmodti4+0xb0>
    9d9e:	4d 89 c4             	mov    %r8,%r12
    9da1:	4d 39 d1             	cmp    %r10,%r9
    9da4:	0f 83 46 01 00 00    	jae    9ef0 <__divmodti4+0x1a0>
    9daa:	4c 89 d8             	mov    %r11,%rax
    9dad:	4c 89 ca             	mov    %r9,%rdx
    9db0:	49 f7 f2             	div    %r10
    9db3:	49 89 c3             	mov    %rax,%r11
    9db6:	31 c0                	xor    %eax,%eax
    9db8:	48 89 d6             	mov    %rdx,%rsi
    9dbb:	31 ff                	xor    %edi,%edi
    9dbd:	4c 89 d9             	mov    %r11,%rcx
    9dc0:	48 89 c2             	mov    %rax,%rdx
    9dc3:	48 89 c8             	mov    %rcx,%rax
    9dc6:	4d 85 e4             	test   %r12,%r12
    9dc9:	74 0a                	je     9dd5 <__divmodti4+0x85>
    9dcb:	48 f7 d8             	neg    %rax
    9dce:	48 83 d2 00          	adc    $0x0,%rdx
    9dd2:	48 f7 da             	neg    %rdx
    9dd5:	4d 85 c0             	test   %r8,%r8
    9dd8:	74 0a                	je     9de4 <__divmodti4+0x94>
    9dda:	48 f7 de             	neg    %rsi
    9ddd:	48 83 d7 00          	adc    $0x0,%rdi
    9de1:	48 f7 df             	neg    %rdi
    9de4:	48 89 33             	mov    %rsi,(%rbx)
    9de7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    9deb:	5b                   	pop    %rbx
    9dec:	41 5c                	pop    %r12
    9dee:	41 5d                	pop    %r13
    9df0:	41 5e                	pop    %r14
    9df2:	41 5f                	pop    %r15
    9df4:	5d                   	pop    %rbp
    9df5:	c3                   	ret
    9df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dfd:	00 00 00 
    9e00:	4d 89 c4             	mov    %r8,%r12
    9e03:	49 39 c1             	cmp    %rax,%r9
    9e06:	0f 82 ce 00 00 00    	jb     9eda <__divmodti4+0x18a>
    9e0c:	31 ff                	xor    %edi,%edi
    9e0e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    9e13:	48 63 c7             	movslq %edi,%rax
    9e16:	be 40 00 00 00       	mov    $0x40,%esi
    9e1b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    9e20:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    9e25:	48 29 c6             	sub    %rax,%rsi
    9e28:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    9e2d:	48 09 c8             	or     %rcx,%rax
    9e30:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    9e35:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    9e3a:	49 89 c6             	mov    %rax,%r14
    9e3d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    9e41:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    9e46:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    9e4b:	49 09 c1             	or     %rax,%r9
    9e4e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    9e52:	4c 89 c8             	mov    %r9,%rax
    9e55:	49 f7 f6             	div    %r14
    9e58:	48 89 d1             	mov    %rdx,%rcx
    9e5b:	49 89 c3             	mov    %rax,%r11
    9e5e:	49 89 c1             	mov    %rax,%r9
    9e61:	49 f7 e2             	mul    %r10
    9e64:	49 89 c6             	mov    %rax,%r14
    9e67:	49 89 d2             	mov    %rdx,%r10
    9e6a:	48 39 d1             	cmp    %rdx,%rcx
    9e6d:	72 07                	jb     9e76 <__divmodti4+0x126>
    9e6f:	75 17                	jne    9e88 <__divmodti4+0x138>
    9e71:	49 39 c7             	cmp    %rax,%r15
    9e74:	73 12                	jae    9e88 <__divmodti4+0x138>
    9e76:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    9e7a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    9e7e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    9e82:	49 89 d2             	mov    %rdx,%r10
    9e85:	49 89 c6             	mov    %rax,%r14
    9e88:	4c 89 f8             	mov    %r15,%rax
    9e8b:	4c 29 f0             	sub    %r14,%rax
    9e8e:	4c 19 d1             	sbb    %r10,%rcx
    9e91:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    9e96:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    9e9b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    9ea0:	48 09 c6             	or     %rax,%rsi
    9ea3:	48 89 cf             	mov    %rcx,%rdi
    9ea6:	31 c0                	xor    %eax,%eax
    9ea8:	4c 89 c9             	mov    %r9,%rcx
    9eab:	e9 10 ff ff ff       	jmp    9dc0 <__divmodti4+0x70>
    9eb0:	4c 89 d0             	mov    %r10,%rax
    9eb3:	4c 89 da             	mov    %r11,%rdx
    9eb6:	4d 89 c4             	mov    %r8,%r12
    9eb9:	49 89 f3             	mov    %rsi,%r11
    9ebc:	48 f7 d8             	neg    %rax
    9ebf:	49 f7 d4             	not    %r12
    9ec2:	48 83 d2 00          	adc    $0x0,%rdx
    9ec6:	49 89 c2             	mov    %rax,%r10
    9ec9:	48 f7 da             	neg    %rdx
    9ecc:	48 89 d1             	mov    %rdx,%rcx
    9ecf:	0f 84 cc fe ff ff    	je     9da1 <__divmodti4+0x51>
    9ed5:	49 39 d1             	cmp    %rdx,%r9
    9ed8:	73 46                	jae    9f20 <__divmodti4+0x1d0>
    9eda:	4c 89 cf             	mov    %r9,%rdi
    9edd:	31 c0                	xor    %eax,%eax
    9edf:	31 c9                	xor    %ecx,%ecx
    9ee1:	e9 da fe ff ff       	jmp    9dc0 <__divmodti4+0x70>
    9ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9eed:	00 00 00 
    9ef0:	4d 85 d2             	test   %r10,%r10
    9ef3:	75 0d                	jne    9f02 <__divmodti4+0x1b2>
    9ef5:	b8 01 00 00 00       	mov    $0x1,%eax
    9efa:	31 d2                	xor    %edx,%edx
    9efc:	49 f7 f2             	div    %r10
    9eff:	49 89 c2             	mov    %rax,%r10
    9f02:	4c 89 c8             	mov    %r9,%rax
    9f05:	31 d2                	xor    %edx,%edx
    9f07:	49 f7 f2             	div    %r10
    9f0a:	49 89 c1             	mov    %rax,%r9
    9f0d:	4c 89 d8             	mov    %r11,%rax
    9f10:	49 f7 f2             	div    %r10
    9f13:	49 89 c3             	mov    %rax,%r11
    9f16:	4c 89 c8             	mov    %r9,%rax
    9f19:	e9 9a fe ff ff       	jmp    9db8 <__divmodti4+0x68>
    9f1e:	66 90                	xchg   %ax,%ax
    9f20:	45 31 f6             	xor    %r14d,%r14d
    9f23:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    9f28:	44 89 f7             	mov    %r14d,%edi
    9f2b:	45 85 f6             	test   %r14d,%r14d
    9f2e:	0f 85 df fe ff ff    	jne    9e13 <__divmodti4+0xc3>
    9f34:	4c 39 ca             	cmp    %r9,%rdx
    9f37:	72 17                	jb     9f50 <__divmodti4+0x200>
    9f39:	31 c9                	xor    %ecx,%ecx
    9f3b:	48 39 c6             	cmp    %rax,%rsi
    9f3e:	73 10                	jae    9f50 <__divmodti4+0x200>
    9f40:	4c 89 cf             	mov    %r9,%rdi
    9f43:	31 c0                	xor    %eax,%eax
    9f45:	e9 76 fe ff ff       	jmp    9dc0 <__divmodti4+0x70>
    9f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f50:	4c 89 de             	mov    %r11,%rsi
    9f53:	b9 01 00 00 00       	mov    $0x1,%ecx
    9f58:	48 29 c6             	sub    %rax,%rsi
    9f5b:	49 19 d1             	sbb    %rdx,%r9
    9f5e:	eb e0                	jmp    9f40 <__divmodti4+0x1f0>

0000000000009f60 <atexit>:
    9f60:	f3 0f 1e fa          	endbr64
    9f64:	48 8b 15 9d 40 00 00 	mov    0x409d(%rip),%rdx        # e008 <__dso_handle>
    9f6b:	31 f6                	xor    %esi,%esi
    9f6d:	e9 ee 96 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009f74 <_fini>:
    9f74:	f3 0f 1e fa          	endbr64
    9f78:	48 83 ec 08          	sub    $0x8,%rsp
    9f7c:	48 83 c4 08          	add    $0x8,%rsp
    9f80:	c3                   	ret
