
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 bf 00 00 	mov    0xbfd1(%rip),%rax        # efe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 bc 00 00    	jmp    *0xbc66(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036e0 <fwp_trap_overflow.constprop.0>:
    36e0:	53                   	push   %rbx
    36e1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36e6:	ba 02 00 00 00       	mov    $0x2,%edx
    36eb:	be 60 00 00 00       	mov    $0x60,%esi
    36f0:	4c 8d 0d d8 79 00 00 	lea    0x79d8(%rip),%r9        # b0cf <_IO_stdin_used+0xcf>
    36f7:	4c 8d 05 d5 79 00 00 	lea    0x79d5(%rip),%r8        # b0d3 <_IO_stdin_used+0xd3>
    36fe:	48 83 ec 70          	sub    $0x70,%rsp
    3702:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3709:	00 00 
    370b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3710:	31 c0                	xor    %eax,%eax
    3712:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3717:	e8 84 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    371c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3721:	e8 0a 0d 00 00       	call   4430 <fwp_trap>

0000000000003726 <fwp_task_dispose.cold>:
    3726:	e8 95 fc ff ff       	call   33c0 <abort@plt>

000000000000372b <fwp_main_thread.cold>:
    372b:	e8 90 fc ff ff       	call   33c0 <abort@plt>

0000000000003730 <main.cold>:
    3730:	e8 8b fc ff ff       	call   33c0 <abort@plt>
    3735:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    373c:	00 00 00 
    373f:	90                   	nop

0000000000003740 <main>:
    3740:	f3 0f 1e fa          	endbr64
    3744:	55                   	push   %rbp
    3745:	53                   	push   %rbx
    3746:	48 83 ec 68          	sub    $0x68,%rsp
    374a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3751:	00 00 
    3753:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3758:	48 8d 05 c1 9b 00 00 	lea    0x9bc1(%rip),%rax        # d320 <fwp_fn_table>
    375f:	48 89 05 12 5d 06 00 	mov    %rax,0x65d12(%rip)        # 69478 <fwp_fns>
    3766:	48 8b 05 b3 b8 00 00 	mov    0xb8b3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    376d:	48 89 05 0c 5d 06 00 	mov    %rax,0x65d0c(%rip)        # 69480 <fwp_prog_out>
    3774:	e8 27 0e 00 00       	call   45a0 <fwp_now_ns>
    3779:	48 8d 3d 28 7b 00 00 	lea    0x7b28(%rip),%rdi        # b2a8 <_IO_stdin_used+0x2a8>
    3780:	e8 0b fc ff ff       	call   3390 <getenv@plt>
    3785:	48 85 c0             	test   %rax,%rax
    3788:	74 0c                	je     3796 <main+0x56>
    378a:	48 89 c3             	mov    %rax,%rbx
    378d:	80 38 00             	cmpb   $0x0,(%rax)
    3790:	0f 85 09 01 00 00    	jne    389f <main+0x15f>
    3796:	31 ff                	xor    %edi,%edi
    3798:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    379d:	e8 6e fc ff ff       	call   3410 <clock_gettime@plt>
    37a2:	85 c0                	test   %eax,%eax
    37a4:	0f 85 28 01 00 00    	jne    38d2 <main+0x192>
    37aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37af:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37b4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37b9:	48 89 cb             	mov    %rcx,%rbx
    37bc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37c0:	48 01 c8             	add    %rcx,%rax
    37c3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ca:	00 00 80 
    37cd:	48 11 da             	adc    %rbx,%rdx
    37d0:	31 db                	xor    %ebx,%ebx
    37d2:	48 01 c8             	add    %rcx,%rax
    37d5:	48 11 da             	adc    %rbx,%rdx
    37d8:	48 85 d2             	test   %rdx,%rdx
    37db:	0f 85 38 01 00 00    	jne    3919 <main+0x1d9>
    37e1:	48 8b 3d 38 b8 00 00 	mov    0xb838(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37e8:	31 d2                	xor    %edx,%edx
    37ea:	31 f6                	xor    %esi,%esi
    37ec:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37f1:	e8 da fd ff ff       	call   35d0 <setvbuf@plt>
    37f6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37fb:	be 01 00 00 00       	mov    $0x1,%esi
    3800:	e8 2b fd ff ff       	call   3530 <signal@plt>
    3805:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    380a:	e8 d1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    380f:	85 c0                	test   %eax,%eax
    3811:	0f 85 f6 00 00 00    	jne    390d <main+0x1cd>
    3817:	be 00 00 00 40       	mov    $0x40000000,%esi
    381c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3821:	e8 aa fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3826:	85 c0                	test   %eax,%eax
    3828:	0f 85 c1 00 00 00    	jne    38ef <main+0x1af>
    382e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3833:	31 c9                	xor    %ecx,%ecx
    3835:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    383a:	48 8d 15 af 5d 00 00 	lea    0x5daf(%rip),%rdx        # 95f0 <fwp_main_thread>
    3841:	e8 9a fd ff ff       	call   35e0 <pthread_create@plt>
    3846:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    384b:	89 c5                	mov    %eax,%ebp
    384d:	e8 de fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3852:	85 c0                	test   %eax,%eax
    3854:	0f 85 d6 fe ff ff    	jne    3730 <main.cold>
    385a:	85 ed                	test   %ebp,%ebp
    385c:	0f 85 81 00 00 00    	jne    38e3 <main+0x1a3>
    3862:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3867:	31 f6                	xor    %esi,%esi
    3869:	e8 22 fe ff ff       	call   3690 <pthread_join@plt>
    386e:	85 c0                	test   %eax,%eax
    3870:	0f 85 ba fe ff ff    	jne    3730 <main.cold>
    3876:	48 8b 3d a3 b7 00 00 	mov    0xb7a3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    387d:	e8 1e fd ff ff       	call   35a0 <fflush@plt>
    3882:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f080 <fwp_exit_code>
    3888:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    388d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3894:	00 00 
    3896:	75 46                	jne    38de <main+0x19e>
    3898:	48 83 c4 68          	add    $0x68,%rsp
    389c:	5b                   	pop    %rbx
    389d:	5d                   	pop    %rbp
    389e:	c3                   	ret
    389f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38a4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a9:	48 89 c7             	mov    %rax,%rdi
    38ac:	e8 4f fc ff ff       	call   3500 <strtoull@plt>
    38b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38b6:	80 38 00             	cmpb   $0x0,(%rax)
    38b9:	0f 85 d7 fe ff ff    	jne    3796 <main+0x56>
    38bf:	0f b6 03             	movzbl (%rbx),%eax
    38c2:	83 e8 2b             	sub    $0x2b,%eax
    38c5:	a8 fd                	test   $0xfd,%al
    38c7:	0f 84 c9 fe ff ff    	je     3796 <main+0x56>
    38cd:	e9 0f ff ff ff       	jmp    37e1 <main+0xa1>
    38d2:	48 8d 3d d8 79 00 00 	lea    0x79d8(%rip),%rdi        # b2b1 <_IO_stdin_used+0x2b1>
    38d9:	e8 52 0b 00 00       	call   4430 <fwp_trap>
    38de:	e8 6d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    38e3:	48 8d 3d a6 82 00 00 	lea    0x82a6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ea:	e8 41 0b 00 00       	call   4430 <fwp_trap>
    38ef:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38f4:	e8 37 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    38f9:	85 c0                	test   %eax,%eax
    38fb:	0f 85 2f fe ff ff    	jne    3730 <main.cold>
    3901:	48 8d 3d 60 82 00 00 	lea    0x8260(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    3908:	e8 23 0b 00 00       	call   4430 <fwp_trap>
    390d:	48 8d 3d 24 82 00 00 	lea    0x8224(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    3914:	e8 17 0b 00 00       	call   4430 <fwp_trap>
    3919:	48 8d 3d f0 81 00 00 	lea    0x81f0(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3920:	e8 0b 0b 00 00       	call   4430 <fwp_trap>
    3925:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    392c:	00 00 00 
    392f:	90                   	nop

0000000000003930 <_start>:
    3930:	f3 0f 1e fa          	endbr64
    3934:	31 ed                	xor    %ebp,%ebp
    3936:	49 89 d1             	mov    %rdx,%r9
    3939:	5e                   	pop    %rsi
    393a:	48 89 e2             	mov    %rsp,%rdx
    393d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3941:	50                   	push   %rax
    3942:	54                   	push   %rsp
    3943:	45 31 c0             	xor    %r8d,%r8d
    3946:	31 c9                	xor    %ecx,%ecx
    3948:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3740 <main>
    394f:	ff 15 7b b6 00 00    	call   *0xb67b(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    3955:	f4                   	hlt
    3956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    395d:	00 00 00 

0000000000003960 <deregister_tm_clones>:
    3960:	48 8d 3d b1 b6 00 00 	lea    0xb6b1(%rip),%rdi        # f018 <__TMC_END__>
    3967:	48 8d 05 aa b6 00 00 	lea    0xb6aa(%rip),%rax        # f018 <__TMC_END__>
    396e:	48 39 f8             	cmp    %rdi,%rax
    3971:	74 15                	je     3988 <deregister_tm_clones+0x28>
    3973:	48 8b 05 5e b6 00 00 	mov    0xb65e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    397a:	48 85 c0             	test   %rax,%rax
    397d:	74 09                	je     3988 <deregister_tm_clones+0x28>
    397f:	ff e0                	jmp    *%rax
    3981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3988:	c3                   	ret
    3989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003990 <register_tm_clones>:
    3990:	48 8d 3d 81 b6 00 00 	lea    0xb681(%rip),%rdi        # f018 <__TMC_END__>
    3997:	48 8d 35 7a b6 00 00 	lea    0xb67a(%rip),%rsi        # f018 <__TMC_END__>
    399e:	48 29 fe             	sub    %rdi,%rsi
    39a1:	48 89 f0             	mov    %rsi,%rax
    39a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39a8:	48 c1 f8 03          	sar    $0x3,%rax
    39ac:	48 01 c6             	add    %rax,%rsi
    39af:	48 d1 fe             	sar    $1,%rsi
    39b2:	74 14                	je     39c8 <register_tm_clones+0x38>
    39b4:	48 8b 05 2d b6 00 00 	mov    0xb62d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    39bb:	48 85 c0             	test   %rax,%rax
    39be:	74 08                	je     39c8 <register_tm_clones+0x38>
    39c0:	ff e0                	jmp    *%rax
    39c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39c8:	c3                   	ret
    39c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039d0 <__do_global_dtors_aux>:
    39d0:	f3 0f 1e fa          	endbr64
    39d4:	80 3d 6d b6 00 00 00 	cmpb   $0x0,0xb66d(%rip)        # f048 <completed.0>
    39db:	75 2b                	jne    3a08 <__do_global_dtors_aux+0x38>
    39dd:	55                   	push   %rbp
    39de:	48 83 3d 0a b6 00 00 	cmpq   $0x0,0xb60a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    39e5:	00 
    39e6:	48 89 e5             	mov    %rsp,%rbp
    39e9:	74 0c                	je     39f7 <__do_global_dtors_aux+0x27>
    39eb:	48 8b 3d 16 b6 00 00 	mov    0xb616(%rip),%rdi        # f008 <__dso_handle>
    39f2:	e8 89 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    39f7:	e8 64 ff ff ff       	call   3960 <deregister_tm_clones>
    39fc:	c6 05 45 b6 00 00 01 	movb   $0x1,0xb645(%rip)        # f048 <completed.0>
    3a03:	5d                   	pop    %rbp
    3a04:	c3                   	ret
    3a05:	0f 1f 00             	nopl   (%rax)
    3a08:	c3                   	ret
    3a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a10 <frame_dummy>:
    3a10:	f3 0f 1e fa          	endbr64
    3a14:	e9 77 ff ff ff       	jmp    3990 <register_tm_clones>
    3a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a20 <fwp_fmt_u128>:
    3a20:	41 57                	push   %r15
    3a22:	41 56                	push   %r14
    3a24:	41 55                	push   %r13
    3a26:	41 54                	push   %r12
    3a28:	55                   	push   %rbp
    3a29:	53                   	push   %rbx
    3a2a:	48 83 ec 68          	sub    $0x68,%rsp
    3a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a35:	00 00 
    3a37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a3c:	48 89 f0             	mov    %rsi,%rax
    3a3f:	48 09 d0             	or     %rdx,%rax
    3a42:	75 7c                	jne    3ac0 <fwp_fmt_u128+0xa0>
    3a44:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a49:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a4e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a53:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a56:	48 89 f8             	mov    %rdi,%rax
    3a59:	49 01 d4             	add    %rdx,%r12
    3a5c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a61:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a68:	00 00 
    3a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a71:	00 00 00 00 
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 
    3a80:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a85:	48 83 c0 01          	add    $0x1,%rax
    3a89:	49 83 ec 01          	sub    $0x1,%r12
    3a8d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a90:	48 39 c8             	cmp    %rcx,%rax
    3a93:	75 eb                	jne    3a80 <fwp_fmt_u128+0x60>
    3a95:	48 63 ed             	movslq %ebp,%rbp
    3a98:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a9c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3aa1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3aa8:	00 00 
    3aaa:	0f 85 ef 00 00 00    	jne    3b9f <fwp_fmt_u128+0x17f>
    3ab0:	48 83 c4 68          	add    $0x68,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5d                   	pop    %rbp
    3ab6:	41 5c                	pop    %r12
    3ab8:	41 5d                	pop    %r13
    3aba:	41 5e                	pop    %r14
    3abc:	41 5f                	pop    %r15
    3abe:	c3                   	ret
    3abf:	90                   	nop
    3ac0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ac5:	49 89 f2             	mov    %rsi,%r10
    3ac8:	49 89 d3             	mov    %rdx,%r11
    3acb:	31 ed                	xor    %ebp,%ebp
    3acd:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ad2:	4c 89 e3             	mov    %r12,%rbx
    3ad5:	45 31 f6             	xor    %r14d,%r14d
    3ad8:	49 89 f9             	mov    %rdi,%r9
    3adb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ae2:	cc cc cc 
    3ae5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3aeb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3af2:	cc cc cc 
    3af5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b00:	4c 89 d6             	mov    %r10,%rsi
    3b03:	4c 89 df             	mov    %r11,%rdi
    3b06:	4c 01 de             	add    %r11,%rsi
    3b09:	48 83 d6 00          	adc    $0x0,%rsi
    3b0d:	45 31 ed             	xor    %r13d,%r13d
    3b10:	48 89 f0             	mov    %rsi,%rax
    3b13:	48 f7 e1             	mul    %rcx
    3b16:	48 89 d0             	mov    %rdx,%rax
    3b19:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b1d:	48 c1 e8 02          	shr    $0x2,%rax
    3b21:	48 01 c2             	add    %rax,%rdx
    3b24:	48 8b 04 24          	mov    (%rsp),%rax
    3b28:	48 29 d6             	sub    %rdx,%rsi
    3b2b:	49 89 f4             	mov    %rsi,%r12
    3b2e:	4c 89 d6             	mov    %r10,%rsi
    3b31:	4c 29 e6             	sub    %r12,%rsi
    3b34:	4c 19 ef             	sbb    %r13,%rdi
    3b37:	48 0f af c6          	imul   %rsi,%rax
    3b3b:	49 89 f8             	mov    %rdi,%r8
    3b3e:	4c 0f af c1          	imul   %rcx,%r8
    3b42:	49 01 c0             	add    %rax,%r8
    3b45:	48 89 f0             	mov    %rsi,%rax
    3b48:	48 f7 e1             	mul    %rcx
    3b4b:	48 89 c6             	mov    %rax,%rsi
    3b4e:	83 e0 01             	and    $0x1,%eax
    3b51:	49 01 d0             	add    %rdx,%r8
    3b54:	49 f7 e7             	mul    %r15
    3b57:	4c 89 c7             	mov    %r8,%rdi
    3b5a:	4c 89 d2             	mov    %r10,%rdx
    3b5d:	4c 01 e0             	add    %r12,%rax
    3b60:	48 d1 ef             	shr    $1,%rdi
    3b63:	83 c5 01             	add    $0x1,%ebp
    3b66:	48 83 c3 01          	add    $0x1,%rbx
    3b6a:	83 c0 30             	add    $0x30,%eax
    3b6d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b72:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b75:	4c 89 d8             	mov    %r11,%rax
    3b78:	49 89 fb             	mov    %rdi,%r11
    3b7b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b80:	48 39 d7             	cmp    %rdx,%rdi
    3b83:	4c 89 f7             	mov    %r14,%rdi
    3b86:	49 89 f2             	mov    %rsi,%r10
    3b89:	48 19 c7             	sbb    %rax,%rdi
    3b8c:	0f 82 6e ff ff ff    	jb     3b00 <fwp_fmt_u128+0xe0>
    3b92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b97:	4c 89 cf             	mov    %r9,%rdi
    3b9a:	e9 b4 fe ff ff       	jmp    3a53 <fwp_fmt_u128+0x33>
    3b9f:	e8 ac f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3ba4:	90                   	nop
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_range_release>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	53                   	push   %rbx
    3bb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bb9:	48 89 fb             	mov    %rdi,%rbx
    3bbc:	48 85 c0             	test   %rax,%rax
    3bbf:	74 06                	je     3bc7 <fwp_range_release+0x17>
    3bc1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3bc5:	ff d0                	call   *%rax
    3bc7:	48 8b 3b             	mov    (%rbx),%rdi
    3bca:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bce:	5b                   	pop    %rbx
    3bcf:	ff e0                	jmp    *%rax
    3bd1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 

0000000000003be0 <ad_raw_record>:
    3be0:	89 c8                	mov    %ecx,%eax
    3be2:	4c 8d 05 b7 b5 04 00 	lea    0x4b5b7(%rip),%r8        # 4f1a0 <ad_raw_live>
    3be9:	49 89 f1             	mov    %rsi,%r9
    3bec:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bf3:	00 
    3bf4:	48 89 d6             	mov    %rdx,%rsi
    3bf7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bfa:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bfe:	48 8d 0d 5b b5 04 00 	lea    0x4b55b(%rip),%rcx        # 4f160 <ad_raw_requests>
    3c05:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c0a:	48 8d 0d 2f b5 04 00 	lea    0x4b52f(%rip),%rcx        # 4f140 <ad_raw_bytes>
    3c11:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c15:	48 01 f2             	add    %rsi,%rdx
    3c18:	48 8d 0d 61 b5 04 00 	lea    0x4b561(%rip),%rcx        # 4f180 <ad_raw_peak>
    3c1f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c23:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c27:	4c 89 0f             	mov    %r9,(%rdi)
    3c2a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c2e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c32:	73 04                	jae    3c38 <ad_raw_record+0x58>
    3c34:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c38:	66 0f 6f 05 70 b5 04 	movdqa 0x4b570(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    3c3f:	00 
    3c40:	66 0f d4 05 58 b5 04 	paddq  0x4b558(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    3c47:	00 
    3c48:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c4c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c51:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c55:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c5a:	48 39 05 bf b4 04 00 	cmp    %rax,0x4b4bf(%rip)        # 4f120 <ad_raw_total_peak>
    3c61:	73 08                	jae    3c6b <ad_raw_record+0x8b>
    3c63:	66 0f d6 05 b5 b4 04 	movq   %xmm0,0x4b4b5(%rip)        # 4f120 <ad_raw_total_peak>
    3c6a:	00 
    3c6b:	c3                   	ret
    3c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c70 <fwp_tape_unlink_scope>:
    3c70:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c74:	48 85 d2             	test   %rdx,%rdx
    3c77:	74 3e                	je     3cb7 <fwp_tape_unlink_scope+0x47>
    3c79:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c7c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c80:	85 c9                	test   %ecx,%ecx
    3c82:	78 3c                	js     3cc0 <fwp_tape_unlink_scope+0x50>
    3c84:	48 63 d1             	movslq %ecx,%rdx
    3c87:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c8b:	48 03 15 5e b4 01 00 	add    0x1b45e(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c92:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c95:	85 c0                	test   %eax,%eax
    3c97:	78 0e                	js     3ca7 <fwp_tape_unlink_scope+0x37>
    3c99:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c9d:	48 03 05 4c b4 01 00 	add    0x1b44c(%rip),%rax        # 1f0f0 <fwp_tapes>
    3ca4:	89 48 58             	mov    %ecx,0x58(%rax)
    3ca7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cae:	00 
    3caf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cb6:	ff 
    3cb7:	c3                   	ret
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	89 02                	mov    %eax,(%rdx)
    3cc2:	eb d1                	jmp    3c95 <fwp_tape_unlink_scope+0x25>
    3cc4:	90                   	nop
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_args173>:
    3cd0:	f3 0f 1e fa          	endbr64
    3cd4:	c3                   	ret
    3cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cdc:	00 00 00 00 

0000000000003ce0 <fwp_flush>:
    3ce0:	48 8b 3d 99 57 06 00 	mov    0x65799(%rip),%rdi        # 69480 <fwp_prog_out>
    3ce7:	48 85 ff             	test   %rdi,%rdi
    3cea:	74 1c                	je     3d08 <fwp_flush+0x28>
    3cec:	48 83 ec 08          	sub    $0x8,%rsp
    3cf0:	e8 ab f8 ff ff       	call   35a0 <fflush@plt>
    3cf5:	48 8b 3d 24 b3 00 00 	mov    0xb324(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cfc:	48 83 c4 08          	add    $0x8,%rsp
    3d00:	e9 9b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d05:	0f 1f 00             	nopl   (%rax)
    3d08:	48 8b 3d 11 b3 00 00 	mov    0xb311(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3d0f:	e9 8c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d14:	90                   	nop
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 

0000000000003d20 <fwp_segv>:
    3d20:	f3 0f 1e fa          	endbr64
    3d24:	48 83 ec 28          	sub    $0x28,%rsp
    3d28:	48 8b 05 d1 3a 06 00 	mov    0x63ad1(%rip),%rax        # 67800 <fwp_cur>
    3d2f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d33:	41 89 f8             	mov    %edi,%r8d
    3d36:	48 85 c0             	test   %rax,%rax
    3d39:	74 6d                	je     3da8 <fwp_segv+0x88>
    3d3b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d3f:	48 85 d2             	test   %rdx,%rdx
    3d42:	74 64                	je     3da8 <fwp_segv+0x88>
    3d44:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d48:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d52:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d57:	e8 c4 f8 ff ff       	call   3620 <sysconf@plt>
    3d5c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d61:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d66:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d6b:	48 01 d0             	add    %rdx,%rax
    3d6e:	48 39 c1             	cmp    %rax,%rcx
    3d71:	b8 00 00 00 00       	mov    $0x0,%eax
    3d76:	40 0f 92 c6          	setb   %sil
    3d7a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d81:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d85:	31 c0                	xor    %eax,%eax
    3d87:	48 39 d1             	cmp    %rdx,%rcx
    3d8a:	0f 93 c0             	setae  %al
    3d8d:	21 f0                	and    %esi,%eax
    3d8f:	85 c0                	test   %eax,%eax
    3d91:	75 4a                	jne    3ddd <fwp_segv+0xbd>
    3d93:	31 f6                	xor    %esi,%esi
    3d95:	44 89 c7             	mov    %r8d,%edi
    3d98:	48 83 c4 28          	add    $0x28,%rsp
    3d9c:	e9 8f f7 ff ff       	jmp    3530 <signal@plt>
    3da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3da8:	48 8b 05 19 34 06 00 	mov    0x63419(%rip),%rax        # 671c8 <fwp_main_stack_top>
    3daf:	48 85 c0             	test   %rax,%rax
    3db2:	74 df                	je     3d93 <fwp_segv+0x73>
    3db4:	48 2b 05 05 34 06 00 	sub    0x63405(%rip),%rax        # 671c0 <fwp_main_stack_size>
    3dbb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3dc2:	48 39 d1             	cmp    %rdx,%rcx
    3dc5:	0f 93 c2             	setae  %dl
    3dc8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dce:	48 39 c1             	cmp    %rax,%rcx
    3dd1:	0f 92 c0             	setb   %al
    3dd4:	0f b6 c0             	movzbl %al,%eax
    3dd7:	21 d0                	and    %edx,%eax
    3dd9:	85 c0                	test   %eax,%eax
    3ddb:	74 b6                	je     3d93 <fwp_segv+0x73>
    3ddd:	e8 fe fe ff ff       	call   3ce0 <fwp_flush>
    3de2:	bf 02 00 00 00       	mov    $0x2,%edi
    3de7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dec:	48 8d 35 7d 7e 00 00 	lea    0x7e7d(%rip),%rsi        # bc70 <msg.4>
    3df3:	e8 28 f6 ff ff       	call   3420 <write@plt>
    3df8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dfd:	e8 ce f5 ff ff       	call   33d0 <_exit@plt>
    3e02:	0f 1f 00             	nopl   (%rax)
    3e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e0c:	00 00 00 00 

0000000000003e10 <fwp_heap_oom>:
    3e10:	50                   	push   %rax
    3e11:	58                   	pop    %rax
    3e12:	ba 13 00 00 00       	mov    $0x13,%edx
    3e17:	be 01 00 00 00       	mov    $0x1,%esi
    3e1c:	48 8d 3d e5 71 00 00 	lea    0x71e5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e23:	48 83 ec 08          	sub    $0x8,%rsp
    3e27:	48 8b 0d 12 b2 00 00 	mov    0xb212(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e2e:	e8 2d f8 ff ff       	call   3660 <fwrite@plt>
    3e33:	31 ff                	xor    %edi,%edi
    3e35:	e8 66 f7 ff ff       	call   35a0 <fflush@plt>
    3e3a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e3f:	e8 3c f8 ff ff       	call   3680 <_Exit@plt>
    3e44:	90                   	nop
    3e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e4c:	00 00 00 00 

0000000000003e50 <fwp_heap_chunks>:
    3e50:	41 54                	push   %r12
    3e52:	55                   	push   %rbp
    3e53:	53                   	push   %rbx
    3e54:	48 83 ff 01          	cmp    $0x1,%rdi
    3e58:	0f 84 62 01 00 00    	je     3fc0 <fwp_heap_chunks+0x170>
    3e5e:	48 8b 05 ab 4d 06 00 	mov    0x64dab(%rip),%rax        # 68c10 <fwp_heap+0x13f0>
    3e65:	4c 8d 05 a4 4d 06 00 	lea    0x64da4(%rip),%r8        # 68c10 <fwp_heap+0x13f0>
    3e6c:	48 8b 1d 85 4d 06 00 	mov    0x64d85(%rip),%rbx        # 68bf8 <fwp_heap+0x13d8>
    3e73:	48 39 d8             	cmp    %rbx,%rax
    3e76:	0f 83 57 01 00 00    	jae    3fd3 <fwp_heap_chunks+0x183>
    3e7c:	48 8b 0d 95 4d 06 00 	mov    0x64d95(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    3e83:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e87:	31 f6                	xor    %esi,%esi
    3e89:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e8d:	eb 1e                	jmp    3ead <fwp_heap_chunks+0x5d>
    3e8f:	90                   	nop
    3e90:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e94:	48 39 cf             	cmp    %rcx,%rdi
    3e97:	0f 84 03 01 00 00    	je     3fa0 <fwp_heap_chunks+0x150>
    3e9d:	48 83 c0 01          	add    $0x1,%rax
    3ea1:	48 89 ce             	mov    %rcx,%rsi
    3ea4:	48 83 c2 28          	add    $0x28,%rdx
    3ea8:	48 39 c3             	cmp    %rax,%rbx
    3eab:	74 14                	je     3ec1 <fwp_heap_chunks+0x71>
    3ead:	80 3a 00             	cmpb   $0x0,(%rdx)
    3eb0:	74 de                	je     3e90 <fwp_heap_chunks+0x40>
    3eb2:	48 83 c0 01          	add    $0x1,%rax
    3eb6:	31 f6                	xor    %esi,%esi
    3eb8:	48 83 c2 28          	add    $0x28,%rdx
    3ebc:	48 39 c3             	cmp    %rax,%rbx
    3ebf:	75 ec                	jne    3ead <fwp_heap_chunks+0x5d>
    3ec1:	48 29 f3             	sub    %rsi,%rbx
    3ec4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ec8:	48 8b 3d 31 4d 06 00 	mov    0x64d31(%rip),%rdi        # 68c00 <fwp_heap+0x13e0>
    3ecf:	48 29 35 7a 4d 06 00 	sub    %rsi,0x64d7a(%rip)        # 68c50 <fwp_heap+0x1430>
    3ed6:	48 39 ef             	cmp    %rbp,%rdi
    3ed9:	0f 83 96 00 00 00    	jae    3f75 <fwp_heap_chunks+0x125>
    3edf:	48 8b 05 0a 4d 06 00 	mov    0x64d0a(%rip),%rax        # 68bf0 <fwp_heap+0x13d0>
    3ee6:	48 39 e8             	cmp    %rbp,%rax
    3ee9:	0f 82 eb 00 00 00    	jb     3fda <fwp_heap_chunks+0x18a>
    3eef:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ef3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef8:	49 39 c4             	cmp    %rax,%r12
    3efb:	4c 0f 47 e0          	cmova  %rax,%r12
    3eff:	4c 89 e6             	mov    %r12,%rsi
    3f02:	48 29 fe             	sub    %rdi,%rsi
    3f05:	48 c1 e7 10          	shl    $0x10,%rdi
    3f09:	48 03 3d c0 4c 06 00 	add    0x64cc0(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    3f10:	48 c1 e6 10          	shl    $0x10,%rsi
    3f14:	e8 e7 f6 ff ff       	call   3600 <mprotect@plt>
    3f19:	85 c0                	test   %eax,%eax
    3f1b:	0f 85 b9 00 00 00    	jne    3fda <fwp_heap_chunks+0x18a>
    3f21:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f26:	e8 f5 f6 ff ff       	call   3620 <sysconf@plt>
    3f2b:	48 8b 35 ce 4c 06 00 	mov    0x64cce(%rip),%rsi        # 68c00 <fwp_heap+0x13e0>
    3f32:	48 89 c1             	mov    %rax,%rcx
    3f35:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    3f3c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f40:	48 89 ca             	mov    %rcx,%rdx
    3f43:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f47:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f4b:	48 f7 da             	neg    %rdx
    3f4e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f53:	48 21 d7             	and    %rdx,%rdi
    3f56:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f5a:	48 21 d6             	and    %rdx,%rsi
    3f5d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f62:	48 29 fe             	sub    %rdi,%rsi
    3f65:	e8 96 f6 ff ff       	call   3600 <mprotect@plt>
    3f6a:	85 c0                	test   %eax,%eax
    3f6c:	75 6c                	jne    3fda <fwp_heap_chunks+0x18a>
    3f6e:	4c 89 25 8b 4c 06 00 	mov    %r12,0x64c8b(%rip)        # 68c00 <fwp_heap+0x13e0>
    3f75:	48 89 ef             	mov    %rbp,%rdi
    3f78:	48 89 2d 79 4c 06 00 	mov    %rbp,0x64c79(%rip)        # 68bf8 <fwp_heap+0x13d8>
    3f7f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f83:	48 39 3d 5e 4c 06 00 	cmp    %rdi,0x64c5e(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f8a:	73 07                	jae    3f93 <fwp_heap_chunks+0x143>
    3f8c:	48 89 3d 55 4c 06 00 	mov    %rdi,0x64c55(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f93:	48 89 d8             	mov    %rbx,%rax
    3f96:	5b                   	pop    %rbx
    3f97:	5d                   	pop    %rbp
    3f98:	41 5c                	pop    %r12
    3f9a:	c3                   	ret
    3f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fa0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fa4:	48 29 f0             	sub    %rsi,%rax
    3fa7:	48 89 c3             	mov    %rax,%rbx
    3faa:	49 89 10             	mov    %rdx,(%r8)
    3fad:	48 89 d8             	mov    %rbx,%rax
    3fb0:	48 29 3d 99 4c 06 00 	sub    %rdi,0x64c99(%rip)        # 68c50 <fwp_heap+0x1430>
    3fb7:	5b                   	pop    %rbx
    3fb8:	5d                   	pop    %rbp
    3fb9:	41 5c                	pop    %r12
    3fbb:	c3                   	ret
    3fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fc0:	48 8b 05 41 4c 06 00 	mov    0x64c41(%rip),%rax        # 68c08 <fwp_heap+0x13e8>
    3fc7:	4c 8d 05 3a 4c 06 00 	lea    0x64c3a(%rip),%r8        # 68c08 <fwp_heap+0x13e8>
    3fce:	e9 99 fe ff ff       	jmp    3e6c <fwp_heap_chunks+0x1c>
    3fd3:	31 f6                	xor    %esi,%esi
    3fd5:	e9 ea fe ff ff       	jmp    3ec4 <fwp_heap_chunks+0x74>
    3fda:	e8 31 fe ff ff       	call   3e10 <fwp_heap_oom>
    3fdf:	90                   	nop

0000000000003fe0 <ad_raw_fail>:
    3fe0:	50                   	push   %rax
    3fe1:	58                   	pop    %rax
    3fe2:	48 8d 15 d7 76 00 00 	lea    0x76d7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fe9:	be 02 00 00 00       	mov    $0x2,%esi
    3fee:	31 c0                	xor    %eax,%eax
    3ff0:	48 83 ec 08          	sub    $0x8,%rsp
    3ff4:	48 89 f9             	mov    %rdi,%rcx
    3ff7:	48 8b 3d 42 b0 00 00 	mov    0xb042(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ffe:	e8 6d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4003:	bf e8 00 00 00       	mov    $0xe8,%edi
    4008:	e8 43 f6 ff ff       	call   3650 <exit@plt>
    400d:	0f 1f 00             	nopl   (%rax)

0000000000004010 <buf_grow>:
    4010:	48 83 ec 18          	sub    $0x18,%rsp
    4014:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4018:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    401c:	74 7e                	je     409c <buf_grow+0x8c>
    401e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4025:	48 29 c2             	sub    %rax,%rdx
    4028:	48 39 f2             	cmp    %rsi,%rdx
    402b:	72 6f                	jb     409c <buf_grow+0x8c>
    402d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4032:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4036:	48 89 f9             	mov    %rdi,%rcx
    4039:	48 39 d0             	cmp    %rdx,%rax
    403c:	73 48                	jae    4086 <buf_grow+0x76>
    403e:	48 85 c0             	test   %rax,%rax
    4041:	75 15                	jne    4058 <buf_grow+0x48>
    4043:	48 83 fa 40          	cmp    $0x40,%rdx
    4047:	76 4c                	jbe    4095 <buf_grow+0x85>
    4049:	b8 40 00 00 00       	mov    $0x40,%eax
    404e:	eb 08                	jmp    4058 <buf_grow+0x48>
    4050:	48 01 c0             	add    %rax,%rax
    4053:	48 39 d0             	cmp    %rdx,%rax
    4056:	73 38                	jae    4090 <buf_grow+0x80>
    4058:	48 85 c0             	test   %rax,%rax
    405b:	79 f3                	jns    4050 <buf_grow+0x40>
    405d:	48 8b 39             	mov    (%rcx),%rdi
    4060:	48 89 d6             	mov    %rdx,%rsi
    4063:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4068:	48 89 14 24          	mov    %rdx,(%rsp)
    406c:	e8 3f f5 ff ff       	call   35b0 <realloc@plt>
    4071:	48 8b 14 24          	mov    (%rsp),%rdx
    4075:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    407a:	48 85 c0             	test   %rax,%rax
    407d:	74 1d                	je     409c <buf_grow+0x8c>
    407f:	48 89 01             	mov    %rax,(%rcx)
    4082:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4086:	48 83 c4 18          	add    $0x18,%rsp
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 89 c2             	mov    %rax,%rdx
    4093:	eb c8                	jmp    405d <buf_grow+0x4d>
    4095:	ba 40 00 00 00       	mov    $0x40,%edx
    409a:	eb c1                	jmp    405d <buf_grow+0x4d>
    409c:	48 8b 0d 9d af 00 00 	mov    0xaf9d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    40a3:	ba 13 00 00 00       	mov    $0x13,%edx
    40a8:	be 01 00 00 00       	mov    $0x1,%esi
    40ad:	48 8d 3d 54 6f 00 00 	lea    0x6f54(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    40b4:	e8 a7 f5 ff ff       	call   3660 <fwrite@plt>
    40b9:	31 ff                	xor    %edi,%edi
    40bb:	e8 e0 f4 ff ff       	call   35a0 <fflush@plt>
    40c0:	bf 66 00 00 00       	mov    $0x66,%edi
    40c5:	e8 b6 f5 ff ff       	call   3680 <_Exit@plt>
    40ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040d0 <buf_put>:
    40d0:	41 54                	push   %r12
    40d2:	49 89 f4             	mov    %rsi,%r12
    40d5:	48 89 d6             	mov    %rdx,%rsi
    40d8:	55                   	push   %rbp
    40d9:	48 89 fd             	mov    %rdi,%rbp
    40dc:	53                   	push   %rbx
    40dd:	48 89 d3             	mov    %rdx,%rbx
    40e0:	e8 2b ff ff ff       	call   4010 <buf_grow>
    40e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40e9:	48 89 da             	mov    %rbx,%rdx
    40ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40f0:	4c 89 e6             	mov    %r12,%rsi
    40f3:	e8 88 f4 ff ff       	call   3580 <memcpy@plt>
    40f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4100:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4104:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4108:	5b                   	pop    %rbx
    4109:	5d                   	pop    %rbp
    410a:	41 5c                	pop    %r12
    410c:	c3                   	ret
    410d:	0f 1f 00             	nopl   (%rax)

0000000000004110 <fwp_cancel_tree.part.0>:
    4110:	48 3b 3d e9 36 06 00 	cmp    0x636e9(%rip),%rdi        # 67800 <fwp_cur>
    4117:	53                   	push   %rbx
    4118:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    411c:	74 35                	je     4153 <fwp_cancel_tree.part.0+0x43>
    411e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4122:	75 2f                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    4124:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4128:	75 29                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    412a:	48 8b 05 af 36 06 00 	mov    0x636af(%rip),%rax        # 677e0 <fwp_ready_tail>
    4131:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4135:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    413c:	00 00 00 00 
    4140:	48 85 c0             	test   %rax,%rax
    4143:	74 33                	je     4178 <fwp_cancel_tree.part.0+0x68>
    4145:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    414c:	48 89 3d 8d 36 06 00 	mov    %rdi,0x6368d(%rip)        # 677e0 <fwp_ready_tail>
    4153:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4157:	48 85 db             	test   %rbx,%rbx
    415a:	74 17                	je     4173 <fwp_cancel_tree.part.0+0x63>
    415c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4160:	75 08                	jne    416a <fwp_cancel_tree.part.0+0x5a>
    4162:	48 89 df             	mov    %rbx,%rdi
    4165:	e8 a6 ff ff ff       	call   4110 <fwp_cancel_tree.part.0>
    416a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    416e:	48 85 db             	test   %rbx,%rbx
    4171:	75 e9                	jne    415c <fwp_cancel_tree.part.0+0x4c>
    4173:	5b                   	pop    %rbx
    4174:	c3                   	ret
    4175:	0f 1f 00             	nopl   (%rax)
    4178:	48 89 3d 69 36 06 00 	mov    %rdi,0x63669(%rip)        # 677e8 <fwp_ready_head>
    417f:	eb cb                	jmp    414c <fwp_cancel_tree.part.0+0x3c>
    4181:	0f 1f 40 00          	nopl   0x0(%rax)
    4185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    418c:	00 00 00 00 

0000000000004190 <fwp_finish_float>:
    4190:	53                   	push   %rbx
    4191:	be 2e 00 00 00       	mov    $0x2e,%esi
    4196:	48 89 fb             	mov    %rdi,%rbx
    4199:	e8 d2 f2 ff ff       	call   3470 <strchr@plt>
    419e:	48 85 c0             	test   %rax,%rax
    41a1:	74 05                	je     41a8 <fwp_finish_float+0x18>
    41a3:	5b                   	pop    %rbx
    41a4:	c3                   	ret
    41a5:	0f 1f 00             	nopl   (%rax)
    41a8:	be 65 00 00 00       	mov    $0x65,%esi
    41ad:	48 89 df             	mov    %rbx,%rdi
    41b0:	e8 bb f2 ff ff       	call   3470 <strchr@plt>
    41b5:	48 85 c0             	test   %rax,%rax
    41b8:	75 e9                	jne    41a3 <fwp_finish_float+0x13>
    41ba:	48 8d 35 39 70 00 00 	lea    0x7039(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    41c1:	48 89 df             	mov    %rbx,%rdi
    41c4:	e8 e7 f4 ff ff       	call   36b0 <strstr@plt>
    41c9:	48 85 c0             	test   %rax,%rax
    41cc:	75 d5                	jne    41a3 <fwp_finish_float+0x13>
    41ce:	48 8d 35 47 6e 00 00 	lea    0x6e47(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41d5:	48 89 df             	mov    %rbx,%rdi
    41d8:	e8 d3 f4 ff ff       	call   36b0 <strstr@plt>
    41dd:	48 85 c0             	test   %rax,%rax
    41e0:	75 c1                	jne    41a3 <fwp_finish_float+0x13>
    41e2:	48 89 df             	mov    %rbx,%rdi
    41e5:	e8 56 f2 ff ff       	call   3440 <strlen@plt>
    41ea:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41ef:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41f3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41f8:	5b                   	pop    %rbx
    41f9:	c3                   	ret
    41fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004200 <ad_raw_report>:
    4200:	f3 0f 1e fa          	endbr64
    4204:	41 57                	push   %r15
    4206:	41 56                	push   %r14
    4208:	41 55                	push   %r13
    420a:	41 54                	push   %r12
    420c:	55                   	push   %rbp
    420d:	53                   	push   %rbx
    420e:	48 83 ec 38          	sub    $0x38,%rsp
    4212:	66 0f 6f 05 96 af 04 	movdqa 0x4af96(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    4219:	00 
    421a:	66 0f d4 05 7e af 04 	paddq  0x4af7e(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    4221:	00 
    4222:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4229:	00 00 
    422b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4230:	31 c0                	xor    %eax,%eax
    4232:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4236:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    423b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    423f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4244:	48 85 ed             	test   %rbp,%rbp
    4247:	0f 85 d2 01 00 00    	jne    441f <ad_raw_report+0x21f>
    424d:	4c 8b 05 a4 ae 01 00 	mov    0x1aea4(%rip),%r8        # 1f0f8 <ad_raw_before_shutdown>
    4254:	45 31 c9             	xor    %r9d,%r9d
    4257:	31 c0                	xor    %eax,%eax
    4259:	31 db                	xor    %ebx,%ebx
    425b:	48 8b 0d be ae 04 00 	mov    0x4aebe(%rip),%rcx        # 4f120 <ad_raw_total_peak>
    4262:	48 8b 3d d7 ad 00 00 	mov    0xadd7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4269:	49 89 e4             	mov    %rsp,%r12
    426c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4273:	be 02 00 00 00       	mov    $0x2,%esi
    4278:	4c 8d 3d 01 af 04 00 	lea    0x4af01(%rip),%r15        # 4f180 <ad_raw_peak>
    427f:	4c 8d 35 ba ae 04 00 	lea    0x4aeba(%rip),%r14        # 4f140 <ad_raw_bytes>
    4286:	e8 e5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    428b:	48 8d 05 99 6d 00 00 	lea    0x6d99(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4292:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec10 <d0+0x70>
    4299:	00 
    429a:	4c 8d 2d bf ae 04 00 	lea    0x4aebf(%rip),%r13        # 4f160 <ad_raw_requests>
    42a1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42a6:	48 8d 05 8f 6d 00 00 	lea    0x6d8f(%rip),%rax        # b03c <_IO_stdin_used+0x3c>
    42ad:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42b1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42ba:	f3 0f 7e 05 56 a9 00 	movq   0xa956(%rip),%xmm0        # ec18 <d0+0x78>
    42c1:	00 
    42c2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42c6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42cb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42cf:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42d3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42d8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42dc:	48 85 db             	test   %rbx,%rbx
    42df:	0f 84 0b 01 00 00    	je     43f0 <ad_raw_report+0x1f0>
    42e5:	52                   	push   %rdx
    42e6:	48 8b 3d 53 ad 00 00 	mov    0xad53(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42ed:	48 8d 0d 2c 6d 00 00 	lea    0x6d2c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42f4:	48 8d 15 75 74 00 00 	lea    0x7475(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42fb:	50                   	push   %rax
    42fc:	be 02 00 00 00       	mov    $0x2,%esi
    4301:	31 c0                	xor    %eax,%eax
    4303:	48 83 c3 01          	add    $0x1,%rbx
    4307:	e8 64 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    430c:	5f                   	pop    %rdi
    430d:	41 58                	pop    %r8
    430f:	48 83 fb 04          	cmp    $0x4,%rbx
    4313:	75 b6                	jne    42cb <ad_raw_report+0xcb>
    4315:	48 8b 0d 24 ad 00 00 	mov    0xad24(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    431c:	ba 13 00 00 00       	mov    $0x13,%edx
    4321:	be 01 00 00 00       	mov    $0x1,%esi
    4326:	48 8d 3d 18 6d 00 00 	lea    0x6d18(%rip),%rdi        # b045 <_IO_stdin_used+0x45>
    432d:	e8 2e f3 ff ff       	call   3660 <fwrite@plt>
    4332:	48 83 3d c6 ad 01 00 	cmpq   $0x0,0x1adc6(%rip)        # 1f100 <ad_raw_checkpoint_count>
    4339:	00 
    433a:	74 75                	je     43b1 <ad_raw_report+0x1b1>
    433c:	4c 8b 05 dd ad 01 00 	mov    0x1addd(%rip),%r8        # 1f120 <ad_raw_checkpoints>
    4343:	4c 8b 0d de ad 01 00 	mov    0x1adde(%rip),%r9        # 1f128 <ad_raw_checkpoints+0x8>
    434a:	48 8d 1d cf ad 01 00 	lea    0x1adcf(%rip),%rbx        # 1f120 <ad_raw_checkpoints>
    4351:	48 8d 0d 14 6d 00 00 	lea    0x6d14(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    4358:	48 8b 05 d1 ad 01 00 	mov    0x1add1(%rip),%rax        # 1f130 <ad_raw_checkpoints+0x10>
    435f:	4c 8d 25 ba 6c 00 00 	lea    0x6cba(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4366:	eb 1b                	jmp    4383 <ad_raw_report+0x183>
    4368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    436f:	00 
    4370:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4374:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4378:	48 83 c3 18          	add    $0x18,%rbx
    437c:	4c 89 e1             	mov    %r12,%rcx
    437f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4383:	48 83 ec 08          	sub    $0x8,%rsp
    4387:	be 02 00 00 00       	mov    $0x2,%esi
    438c:	48 83 c5 01          	add    $0x1,%rbp
    4390:	48 8b 3d a9 ac 00 00 	mov    0xaca9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4397:	50                   	push   %rax
    4398:	48 8d 15 11 74 00 00 	lea    0x7411(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    439f:	31 c0                	xor    %eax,%eax
    43a1:	e8 ca f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43a6:	48 3b 2d 53 ad 01 00 	cmp    0x1ad53(%rip),%rbp        # 1f100 <ad_raw_checkpoint_count>
    43ad:	59                   	pop    %rcx
    43ae:	5e                   	pop    %rsi
    43af:	72 bf                	jb     4370 <ad_raw_report+0x170>
    43b1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43bd:	00 00 
    43bf:	75 6a                	jne    442b <ad_raw_report+0x22b>
    43c1:	48 8b 0d 78 ac 00 00 	mov    0xac78(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43c8:	48 83 c4 38          	add    $0x38,%rsp
    43cc:	ba 04 00 00 00       	mov    $0x4,%edx
    43d1:	be 01 00 00 00       	mov    $0x1,%esi
    43d6:	5b                   	pop    %rbx
    43d7:	48 8d 3d 7b 6c 00 00 	lea    0x6c7b(%rip),%rdi        # b059 <_IO_stdin_used+0x59>
    43de:	5d                   	pop    %rbp
    43df:	41 5c                	pop    %r12
    43e1:	41 5d                	pop    %r13
    43e3:	41 5e                	pop    %r14
    43e5:	41 5f                	pop    %r15
    43e7:	e9 74 f2 ff ff       	jmp    3660 <fwrite@plt>
    43ec:	0f 1f 40 00          	nopl   0x0(%rax)
    43f0:	52                   	push   %rdx
    43f1:	be 02 00 00 00       	mov    $0x2,%esi
    43f6:	48 8b 3d 43 ac 00 00 	mov    0xac43(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43fd:	48 8d 15 6c 73 00 00 	lea    0x736c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    4404:	50                   	push   %rax
    4405:	48 8d 0d 60 6c 00 00 	lea    0x6c60(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    440c:	31 c0                	xor    %eax,%eax
    440e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4413:	e8 58 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4418:	58                   	pop    %rax
    4419:	5a                   	pop    %rdx
    441a:	e9 ac fe ff ff       	jmp    42cb <ad_raw_report+0xcb>
    441f:	48 8d 3d c2 72 00 00 	lea    0x72c2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4426:	e8 b5 fb ff ff       	call   3fe0 <ad_raw_fail>
    442b:	e8 20 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004430 <fwp_trap>:
    4430:	55                   	push   %rbp
    4431:	48 89 fd             	mov    %rdi,%rbp
    4434:	53                   	push   %rbx
    4435:	48 83 ec 08          	sub    $0x8,%rsp
    4439:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4440:	ff ff 
    4442:	e8 99 f8 ff ff       	call   3ce0 <fwp_flush>
    4447:	31 c0                	xor    %eax,%eax
    4449:	48 89 e9             	mov    %rbp,%rcx
    444c:	be 02 00 00 00       	mov    $0x2,%esi
    4451:	48 8b 3d e8 ab 00 00 	mov    0xabe8(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4458:	48 8d 15 ff 6b 00 00 	lea    0x6bff(%rip),%rdx        # b05e <_IO_stdin_used+0x5e>
    445f:	e8 0c f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4464:	48 85 db             	test   %rbx,%rbx
    4467:	74 16                	je     447f <fwp_trap+0x4f>
    4469:	48 8b 3d d0 ab 00 00 	mov    0xabd0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4470:	e8 2b f1 ff ff       	call   35a0 <fflush@plt>
    4475:	bf 65 00 00 00       	mov    $0x65,%edi
    447a:	e8 01 f2 ff ff       	call   3680 <_Exit@plt>
    447f:	bf 65 00 00 00       	mov    $0x65,%edi
    4484:	e8 c7 f1 ff ff       	call   3650 <exit@plt>
    4489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004490 <fwp_closure_drop_push>:
    4490:	41 56                	push   %r14
    4492:	41 54                	push   %r12
    4494:	49 89 f4             	mov    %rsi,%r12
    4497:	55                   	push   %rbp
    4498:	48 89 fd             	mov    %rdi,%rbp
    449b:	53                   	push   %rbx
    449c:	48 83 ec 18          	sub    $0x18,%rsp
    44a0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44a4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44a8:	74 26                	je     44d0 <fwp_closure_drop_push+0x40>
    44aa:	4c 8b 07             	mov    (%rdi),%r8
    44ad:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44b4:	00 
    44b5:	48 83 c3 01          	add    $0x1,%rbx
    44b9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44bd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44c1:	48 83 c4 18          	add    $0x18,%rsp
    44c5:	5b                   	pop    %rbx
    44c6:	5d                   	pop    %rbp
    44c7:	41 5c                	pop    %r12
    44c9:	41 5e                	pop    %r14
    44cb:	c3                   	ret
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)
    44d0:	48 89 d8             	mov    %rbx,%rax
    44d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44d7:	0f 85 a9 00 00 00    	jne    4586 <fwp_closure_drop_push+0xf6>
    44dd:	48 89 d9             	mov    %rbx,%rcx
    44e0:	48 c1 e1 04          	shl    $0x4,%rcx
    44e4:	48 89 cf             	mov    %rcx,%rdi
    44e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44eb:	e8 a0 f0 ff ff       	call   3590 <malloc@plt>
    44f0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44f4:	48 85 c0             	test   %rax,%rax
    44f7:	74 5f                	je     4558 <fwp_closure_drop_push+0xc8>
    44f9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44fd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4504:	00 
    4505:	48 89 c7             	mov    %rax,%rdi
    4508:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    450c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4511:	48 89 34 24          	mov    %rsi,(%rsp)
    4515:	e8 36 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    451a:	48 8b 34 24          	mov    (%rsp),%rsi
    451e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4523:	49 89 c0             	mov    %rax,%r8
    4526:	48 8d 45 18          	lea    0x18(%rbp),%rax
    452a:	48 39 c6             	cmp    %rax,%rsi
    452d:	74 1c                	je     454b <fwp_closure_drop_push+0xbb>
    452f:	48 89 f7             	mov    %rsi,%rdi
    4532:	4c 89 04 24          	mov    %r8,(%rsp)
    4536:	e8 75 ee ff ff       	call   33b0 <free@plt>
    453b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    453f:	4c 8b 04 24          	mov    (%rsp),%r8
    4543:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    454a:	00 
    454b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    454f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4553:	e9 5d ff ff ff       	jmp    44b5 <fwp_closure_drop_push+0x25>
    4558:	48 8b 0d e1 aa 00 00 	mov    0xaae1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    455f:	ba 13 00 00 00       	mov    $0x13,%edx
    4564:	be 01 00 00 00       	mov    $0x1,%esi
    4569:	48 8d 3d 98 6a 00 00 	lea    0x6a98(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4570:	e8 eb f0 ff ff       	call   3660 <fwrite@plt>
    4575:	31 ff                	xor    %edi,%edi
    4577:	e8 24 f0 ff ff       	call   35a0 <fflush@plt>
    457c:	bf 66 00 00 00       	mov    $0x66,%edi
    4581:	e8 fa f0 ff ff       	call   3680 <_Exit@plt>
    4586:	48 8d 3d e0 6a 00 00 	lea    0x6ae0(%rip),%rdi        # b06d <_IO_stdin_used+0x6d>
    458d:	e8 9e fe ff ff       	call   4430 <fwp_trap>
    4592:	0f 1f 00             	nopl   (%rax)
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    459c:	00 00 00 00 

00000000000045a0 <fwp_now_ns>:
    45a0:	53                   	push   %rbx
    45a1:	bf 01 00 00 00       	mov    $0x1,%edi
    45a6:	48 83 ec 20          	sub    $0x20,%rsp
    45aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45b1:	00 00 
    45b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45b8:	31 db                	xor    %ebx,%ebx
    45ba:	48 89 e6             	mov    %rsp,%rsi
    45bd:	e8 4e ee ff ff       	call   3410 <clock_gettime@plt>
    45c2:	85 c0                	test   %eax,%eax
    45c4:	75 52                	jne    4618 <fwp_now_ns+0x78>
    45c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45d0:	48 f7 2c 24          	imulq  (%rsp)
    45d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45db:	48 89 f7             	mov    %rsi,%rdi
    45de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45e2:	48 01 f0             	add    %rsi,%rax
    45e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ec:	00 00 80 
    45ef:	48 11 fa             	adc    %rdi,%rdx
    45f2:	31 ff                	xor    %edi,%edi
    45f4:	48 01 c6             	add    %rax,%rsi
    45f7:	48 11 d7             	adc    %rdx,%rdi
    45fa:	48 39 f1             	cmp    %rsi,%rcx
    45fd:	48 19 fb             	sbb    %rdi,%rbx
    4600:	72 27                	jb     4629 <fwp_now_ns+0x89>
    4602:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4607:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    460e:	00 00 
    4610:	75 12                	jne    4624 <fwp_now_ns+0x84>
    4612:	48 83 c4 20          	add    $0x20,%rsp
    4616:	5b                   	pop    %rbx
    4617:	c3                   	ret
    4618:	48 8d 3d 68 6a 00 00 	lea    0x6a68(%rip),%rdi        # b087 <_IO_stdin_used+0x87>
    461f:	e8 0c fe ff ff       	call   4430 <fwp_trap>
    4624:	e8 27 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4629:	48 8d 3d c0 71 00 00 	lea    0x71c0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4630:	e8 fb fd ff ff       	call   4430 <fwp_trap>
    4635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    463c:	00 00 00 00 

0000000000004640 <fwp_closure_drop.part.0>:
    4640:	53                   	push   %rbx
    4641:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4648:	66 0f 6f 05 40 76 00 	movdqa 0x7640(%rip),%xmm0        # bc90 <msg.4+0x20>
    464f:	00 
    4650:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4657:	00 00 
    4659:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4660:	00 
    4661:	48 89 fe             	mov    %rdi,%rsi
    4664:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4669:	48 89 e7             	mov    %rsp,%rdi
    466c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4670:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4675:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    467c:	ff ff 
    467e:	e8 0d fe ff ff       	call   4490 <fwp_closure_drop_push>
    4683:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4688:	48 85 c0             	test   %rax,%rax
    468b:	74 39                	je     46c6 <fwp_closure_drop.part.0+0x86>
    468d:	0f 1f 00             	nopl   (%rax)
    4690:	48 8b 14 24          	mov    (%rsp),%rdx
    4694:	48 83 e8 01          	sub    $0x1,%rax
    4698:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    469d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46a1:	8b 07                	mov    (%rdi),%eax
    46a3:	48 c1 e0 05          	shl    $0x5,%rax
    46a7:	48 03 05 ca 4d 06 00 	add    0x64dca(%rip),%rax        # 69478 <fwp_fns>
    46ae:	48 8b 40 18          	mov    0x18(%rax),%rax
    46b2:	48 85 c0             	test   %rax,%rax
    46b5:	74 46                	je     46fd <fwp_closure_drop.part.0+0xbd>
    46b7:	31 f6                	xor    %esi,%esi
    46b9:	ff 50 08             	call   *0x8(%rax)
    46bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46c1:	48 85 c0             	test   %rax,%rax
    46c4:	75 ca                	jne    4690 <fwp_closure_drop.part.0+0x50>
    46c6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46cd:	ff ff 00 00 00 00 
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	48 39 df             	cmp    %rbx,%rdi
    46da:	74 05                	je     46e1 <fwp_closure_drop.part.0+0xa1>
    46dc:	e8 cf ec ff ff       	call   33b0 <free@plt>
    46e1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46e8:	00 
    46e9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46f0:	00 00 
    46f2:	75 15                	jne    4709 <fwp_closure_drop.part.0+0xc9>
    46f4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46fb:	5b                   	pop    %rbx
    46fc:	c3                   	ret
    46fd:	48 8d 3d 14 71 00 00 	lea    0x7114(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    4704:	e8 27 fd ff ff       	call   4430 <fwp_trap>
    4709:	e8 42 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    470e:	66 90                	xchg   %ax,%ax

0000000000004710 <fwp_tape_of>:
    4710:	0f b7 d7             	movzwl %di,%edx
    4713:	48 85 d2             	test   %rdx,%rdx
    4716:	74 28                	je     4740 <fwp_tape_of+0x30>
    4718:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    471c:	48 39 05 c5 a9 01 00 	cmp    %rax,0x1a9c5(%rip)        # 1f0e8 <fwp_ntapes>
    4723:	7e 1b                	jle    4740 <fwp_tape_of+0x30>
    4725:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4729:	48 03 05 c0 a9 01 00 	add    0x1a9c0(%rip),%rax        # 1f0f0 <fwp_tapes>
    4730:	8b 50 04             	mov    0x4(%rax),%edx
    4733:	85 d2                	test   %edx,%edx
    4735:	74 09                	je     4740 <fwp_tape_of+0x30>
    4737:	48 c1 ff 10          	sar    $0x10,%rdi
    473b:	39 38                	cmp    %edi,(%rax)
    473d:	75 01                	jne    4740 <fwp_tape_of+0x30>
    473f:	c3                   	ret
    4740:	48 83 ec 08          	sub    $0x8,%rsp
    4744:	48 8d 3d fd 70 00 00 	lea    0x70fd(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    474b:	e8 e0 fc ff ff       	call   4430 <fwp_trap>

0000000000004750 <fwp_format_g.constprop.0>:
    4750:	41 57                	push   %r15
    4752:	b9 40 00 00 00       	mov    $0x40,%ecx
    4757:	ba 02 00 00 00       	mov    $0x2,%edx
    475c:	4c 8d 05 40 69 00 00 	lea    0x6940(%rip),%r8        # b0a3 <_IO_stdin_used+0xa3>
    4763:	41 56                	push   %r14
    4765:	b8 01 00 00 00       	mov    $0x1,%eax
    476a:	41 55                	push   %r13
    476c:	41 54                	push   %r12
    476e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4772:	55                   	push   %rbp
    4773:	45 89 e1             	mov    %r12d,%r9d
    4776:	53                   	push   %rbx
    4777:	48 89 fb             	mov    %rdi,%rbx
    477a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4781:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4788:	00 00 
    478a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4791:	00 
    4792:	41 89 f7             	mov    %esi,%r15d
    4795:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    479a:	be 40 00 00 00       	mov    $0x40,%esi
    479f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47a4:	4c 89 f7             	mov    %r14,%rdi
    47a7:	e8 f4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47ac:	be 65 00 00 00       	mov    $0x65,%esi
    47b1:	4c 89 f7             	mov    %r14,%rdi
    47b4:	e8 b7 ec ff ff       	call   3470 <strchr@plt>
    47b9:	31 f6                	xor    %esi,%esi
    47bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    47c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47c4:	48 89 c5             	mov    %rax,%rbp
    47c7:	e8 a4 ed ff ff       	call   3570 <strtol@plt>
    47cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47d1:	49 89 c0             	mov    %rax,%r8
    47d4:	83 c0 05             	add    $0x5,%eax
    47d7:	83 f8 15             	cmp    $0x15,%eax
    47da:	0f 87 e0 01 00 00    	ja     49c0 <fwp_format_g.constprop.0+0x270>
    47e0:	45 89 e5             	mov    %r12d,%r13d
    47e3:	45 29 c5             	sub    %r8d,%r13d
    47e6:	45 85 ed             	test   %r13d,%r13d
    47e9:	0f 8e 21 01 00 00    	jle    4910 <fwp_format_g.constprop.0+0x1c0>
    47ef:	41 83 ff 01          	cmp    $0x1,%r15d
    47f3:	0f 84 17 01 00 00    	je     4910 <fwp_format_g.constprop.0+0x1c0>
    47f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47fe:	31 d2                	xor    %edx,%edx
    4800:	4d 63 df             	movslq %r15d,%r11
    4803:	3c 2d                	cmp    $0x2d,%al
    4805:	0f 94 c2             	sete   %dl
    4808:	4c 29 dd             	sub    %r11,%rbp
    480b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    480f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4813:	4d 89 f1             	mov    %r14,%r9
    4816:	4d 29 d1             	sub    %r10,%r9
    4819:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    481d:	3c 2d                	cmp    $0x2d,%al
    481f:	0f 84 fb 03 00 00    	je     4c20 <fwp_format_g.constprop.0+0x4d0>
    4825:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    482a:	b9 48 00 00 00       	mov    $0x48,%ecx
    482f:	48 89 e8             	mov    %rbp,%rax
    4832:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4836:	49 8d 72 01          	lea    0x1(%r10),%rsi
    483a:	49 83 c1 47          	add    $0x47,%r9
    483e:	45 85 c0             	test   %r8d,%r8d
    4841:	0f 88 f1 02 00 00    	js     4b38 <fwp_format_g.constprop.0+0x3e8>
    4847:	45 0f b6 12          	movzbl (%r10),%r10d
    484b:	4d 63 e0             	movslq %r8d,%r12
    484e:	44 88 10             	mov    %r10b,(%rax)
    4851:	41 83 f8 07          	cmp    $0x7,%r8d
    4855:	0f 87 2d 02 00 00    	ja     4a88 <fwp_format_g.constprop.0+0x338>
    485b:	41 f6 c4 04          	test   $0x4,%r12b
    485f:	0f 85 f2 03 00 00    	jne    4c57 <fwp_format_g.constprop.0+0x507>
    4865:	45 85 e4             	test   %r12d,%r12d
    4868:	74 12                	je     487c <fwp_format_g.constprop.0+0x12c>
    486a:	45 0f b6 06          	movzbl (%r14),%r8d
    486e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4872:	41 f6 c4 02          	test   $0x2,%r12b
    4876:	0f 85 03 04 00 00    	jne    4c7f <fwp_format_g.constprop.0+0x52f>
    487c:	4c 29 e1             	sub    %r12,%rcx
    487f:	4c 01 e7             	add    %r12,%rdi
    4882:	4c 89 fa             	mov    %r15,%rdx
    4885:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488a:	48 83 e9 01          	sub    $0x1,%rcx
    488e:	4d 63 ed             	movslq %r13d,%r13
    4891:	48 89 0c 24          	mov    %rcx,(%rsp)
    4895:	e8 b6 ec ff ff       	call   3550 <__memcpy_chk@plt>
    489a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    489f:	48 8b 0c 24          	mov    (%rsp),%rcx
    48a3:	ba 48 00 00 00       	mov    $0x48,%edx
    48a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48b0:	4c 89 c8             	mov    %r9,%rax
    48b3:	48 29 c8             	sub    %rcx,%rax
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48bd:	4c 29 c9             	sub    %r9,%rcx
    48c0:	4c 89 ea             	mov    %r13,%rdx
    48c3:	48 01 c1             	add    %rax,%rcx
    48c6:	e8 85 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	48 29 e8             	sub    %rbp,%rax
    48d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 47 c2          	cmova  %rdx,%rax
    48dd:	89 c1                	mov    %eax,%ecx
    48df:	83 f8 08             	cmp    $0x8,%eax
    48e2:	0f 83 18 02 00 00    	jae    4b00 <fwp_format_g.constprop.0+0x3b0>
    48e8:	a8 04                	test   $0x4,%al
    48ea:	0f 85 54 03 00 00    	jne    4c44 <fwp_format_g.constprop.0+0x4f4>
    48f0:	85 c0                	test   %eax,%eax
    48f2:	74 0f                	je     4903 <fwp_format_g.constprop.0+0x1b3>
    48f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48f9:	88 13                	mov    %dl,(%rbx)
    48fb:	a8 02                	test   $0x2,%al
    48fd:	0f 85 6b 03 00 00    	jne    4c6e <fwp_format_g.constprop.0+0x51e>
    4903:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4907:	eb 36                	jmp    493f <fwp_format_g.constprop.0+0x1ef>
    4909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4910:	45 31 c9             	xor    %r9d,%r9d
    4913:	45 85 ed             	test   %r13d,%r13d
    4916:	4c 8d 05 95 67 00 00 	lea    0x6795(%rip),%r8        # b0b2 <_IO_stdin_used+0xb2>
    491d:	48 89 df             	mov    %rbx,%rdi
    4920:	45 0f 49 cd          	cmovns %r13d,%r9d
    4924:	ba 02 00 00 00       	mov    $0x2,%edx
    4929:	be 90 01 00 00       	mov    $0x190,%esi
    492e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4935:	b8 01 00 00 00       	mov    $0x1,%eax
    493a:	e8 61 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    493f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4944:	48 89 df             	mov    %rbx,%rdi
    4947:	e8 24 eb ff ff       	call   3470 <strchr@plt>
    494c:	48 85 c0             	test   %rax,%rax
    494f:	74 3f                	je     4990 <fwp_format_g.constprop.0+0x240>
    4951:	48 89 df             	mov    %rbx,%rdi
    4954:	e8 e7 ea ff ff       	call   3440 <strlen@plt>
    4959:	48 85 c0             	test   %rax,%rax
    495c:	75 0b                	jne    4969 <fwp_format_g.constprop.0+0x219>
    495e:	eb 30                	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4960:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4964:	48 85 c0             	test   %rax,%rax
    4967:	74 27                	je     4990 <fwp_format_g.constprop.0+0x240>
    4969:	48 89 c2             	mov    %rax,%rdx
    496c:	48 83 e8 01          	sub    $0x1,%rax
    4970:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4974:	74 ea                	je     4960 <fwp_format_g.constprop.0+0x210>
    4976:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    497b:	0f 84 6f 01 00 00    	je     4af0 <fwp_format_g.constprop.0+0x3a0>
    4981:	0f 1f 40 00          	nopl   0x0(%rax)
    4985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    498c:	00 00 00 00 
    4990:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4997:	00 
    4998:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    499f:	00 00 
    49a1:	0f 85 ec 02 00 00    	jne    4c93 <fwp_format_g.constprop.0+0x543>
    49a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ae:	5b                   	pop    %rbx
    49af:	5d                   	pop    %rbp
    49b0:	41 5c                	pop    %r12
    49b2:	41 5d                	pop    %r13
    49b4:	41 5e                	pop    %r14
    49b6:	41 5f                	pop    %r15
    49b8:	c3                   	ret
    49b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49c0:	4c 29 f5             	sub    %r14,%rbp
    49c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49c8:	4c 89 f6             	mov    %r14,%rsi
    49cb:	4c 89 04 24          	mov    %r8,(%rsp)
    49cf:	49 89 ec             	mov    %rbp,%r12
    49d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49d7:	4c 89 e2             	mov    %r12,%rdx
    49da:	48 89 ef             	mov    %rbp,%rdi
    49dd:	e8 6e eb ff ff       	call   3550 <__memcpy_chk@plt>
    49e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ed:	48 89 ef             	mov    %rbp,%rdi
    49f0:	e8 7b ea ff ff       	call   3470 <strchr@plt>
    49f5:	4c 8b 04 24          	mov    (%rsp),%r8
    49f9:	48 85 c0             	test   %rax,%rax
    49fc:	74 40                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    49fe:	4d 85 e4             	test   %r12,%r12
    4a01:	74 3b                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a03:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a08:	eb 23                	jmp    4a2d <fwp_format_g.constprop.0+0x2dd>
    4a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a11:	00 00 00 00 
    4a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a1c:	00 00 00 00 
    4a20:	c6 00 00             	movb   $0x0,(%rax)
    4a23:	48 83 e8 01          	sub    $0x1,%rax
    4a27:	49 83 ec 01          	sub    $0x1,%r12
    4a2b:	74 11                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a2d:	80 38 30             	cmpb   $0x30,(%rax)
    4a30:	74 ee                	je     4a20 <fwp_format_g.constprop.0+0x2d0>
    4a32:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a38:	0f 84 fb 01 00 00    	je     4c39 <fwp_format_g.constprop.0+0x4e9>
    4a3e:	44 89 c0             	mov    %r8d,%eax
    4a41:	ba 02 00 00 00       	mov    $0x2,%edx
    4a46:	49 89 e9             	mov    %rbp,%r9
    4a49:	be 90 01 00 00       	mov    $0x190,%esi
    4a4e:	f7 d8                	neg    %eax
    4a50:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a57:	48 89 df             	mov    %rbx,%rdi
    4a5a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a5e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a62:	41 83 e0 02          	and    $0x2,%r8d
    4a66:	41 83 c0 2b          	add    $0x2b,%r8d
    4a6a:	50                   	push   %rax
    4a6b:	31 c0                	xor    %eax,%eax
    4a6d:	41 50                	push   %r8
    4a6f:	4c 8d 05 32 66 00 00 	lea    0x6632(%rip),%r8        # b0a8 <_IO_stdin_used+0xa8>
    4a76:	e8 25 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a7b:	58                   	pop    %rax
    4a7c:	5a                   	pop    %rdx
    4a7d:	e9 0e ff ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a88:	4d 8b 06             	mov    (%r14),%r8
    4a8b:	48 83 c0 09          	add    $0x9,%rax
    4a8f:	4c 89 f2             	mov    %r14,%rdx
    4a92:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a96:	4c 89 07             	mov    %r8,(%rdi)
    4a99:	45 89 e0             	mov    %r12d,%r8d
    4a9c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4aa1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4aa6:	49 89 f8             	mov    %rdi,%r8
    4aa9:	49 29 c0             	sub    %rax,%r8
    4aac:	4c 29 c2             	sub    %r8,%rdx
    4aaf:	45 01 e0             	add    %r12d,%r8d
    4ab2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ab6:	41 83 f8 08          	cmp    $0x8,%r8d
    4aba:	0f 82 bc fd ff ff    	jb     487c <fwp_format_g.constprop.0+0x12c>
    4ac0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ac4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ac8:	45 31 d2             	xor    %r10d,%r10d
    4acb:	45 89 d3             	mov    %r10d,%r11d
    4ace:	41 83 c2 08          	add    $0x8,%r10d
    4ad2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ad6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4ada:	45 39 c2             	cmp    %r8d,%r10d
    4add:	72 ec                	jb     4acb <fwp_format_g.constprop.0+0x37b>
    4adf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ae3:	e9 94 fd ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aef:	00 
    4af0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4af5:	e9 96 fe ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b00:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b05:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b09:	48 89 ee             	mov    %rbp,%rsi
    4b0c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b10:	48 89 13             	mov    %rdx,(%rbx)
    4b13:	89 c2                	mov    %eax,%edx
    4b15:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b1a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b1f:	48 89 d9             	mov    %rbx,%rcx
    4b22:	48 29 f9             	sub    %rdi,%rcx
    4b25:	48 29 ce             	sub    %rcx,%rsi
    4b28:	01 c1                	add    %eax,%ecx
    4b2a:	c1 e9 03             	shr    $0x3,%ecx
    4b2d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b30:	e9 ce fd ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4b35:	0f 1f 00             	nopl   (%rax)
    4b38:	c6 00 30             	movb   $0x30,(%rax)
    4b3b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b3f:	4c 89 fa             	mov    %r15,%rdx
    4b42:	4c 89 e9             	mov    %r13,%rcx
    4b45:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b4a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b4f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b53:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b58:	e8 f3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b5d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b62:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b6c:	48 89 c7             	mov    %rax,%rdi
    4b6f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b73:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b78:	4c 89 c8             	mov    %r9,%rax
    4b7b:	4c 29 e8             	sub    %r13,%rax
    4b7e:	48 39 c8             	cmp    %rcx,%rax
    4b81:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b85:	4d 29 cd             	sub    %r9,%r13
    4b88:	49 01 ff             	add    %rdi,%r15
    4b8b:	4c 01 e8             	add    %r13,%rax
    4b8e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b92:	74 3d                	je     4bd1 <fwp_format_g.constprop.0+0x481>
    4b94:	41 f7 d0             	not    %r8d
    4b97:	31 f6                	xor    %esi,%esi
    4b99:	ba 48 00 00 00       	mov    $0x48,%edx
    4b9e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4ba3:	48 39 d0             	cmp    %rdx,%rax
    4ba6:	48 0f 43 d0          	cmovae %rax,%rdx
    4baa:	48 89 d1             	mov    %rdx,%rcx
    4bad:	48 29 c1             	sub    %rax,%rcx
    4bb0:	48 83 c1 01          	add    $0x1,%rcx
    4bb4:	48 39 d1             	cmp    %rdx,%rcx
    4bb7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bbb:	48 83 e8 01          	sub    $0x1,%rax
    4bbf:	48 83 c6 01          	add    $0x1,%rsi
    4bc3:	48 29 d0             	sub    %rdx,%rax
    4bc6:	48 01 c8             	add    %rcx,%rax
    4bc9:	41 39 f0             	cmp    %esi,%r8d
    4bcc:	7f cb                	jg     4b99 <fwp_format_g.constprop.0+0x449>
    4bce:	4d 01 c7             	add    %r8,%r15
    4bd1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bd6:	41 0f b6 12          	movzbl (%r10),%edx
    4bda:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bde:	4c 89 f6             	mov    %r14,%rsi
    4be1:	48 39 c8             	cmp    %rcx,%rax
    4be4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4be8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bec:	41 88 17             	mov    %dl,(%r15)
    4bef:	48 89 ca             	mov    %rcx,%rdx
    4bf2:	48 29 c2             	sub    %rax,%rdx
    4bf5:	48 83 c2 01          	add    $0x1,%rdx
    4bf9:	48 39 ca             	cmp    %rcx,%rdx
    4bfc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c00:	48 83 e8 01          	sub    $0x1,%rax
    4c04:	48 29 c8             	sub    %rcx,%rax
    4c07:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c0b:	49 63 d4             	movslq %r12d,%rdx
    4c0e:	e8 3d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c13:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c17:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c1b:	e9 ae fc ff ff       	jmp    48ce <fwp_format_g.constprop.0+0x17e>
    4c20:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c25:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c2a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c2f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c34:	e9 f9 fb ff ff       	jmp    4832 <fwp_format_g.constprop.0+0xe2>
    4c39:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c3f:	e9 fa fd ff ff       	jmp    4a3e <fwp_format_g.constprop.0+0x2ee>
    4c44:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c48:	89 13                	mov    %edx,(%rbx)
    4c4a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c4e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c52:	e9 ac fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c57:	41 8b 06             	mov    (%r14),%eax
    4c5a:	89 07                	mov    %eax,(%rdi)
    4c5c:	44 89 e0             	mov    %r12d,%eax
    4c5f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c64:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c69:	e9 0e fc ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c6e:	89 c2                	mov    %eax,%edx
    4c70:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c75:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c7a:	e9 84 fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c7f:	44 89 e0             	mov    %r12d,%eax
    4c82:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c88:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c8e:	e9 e9 fb ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c93:	e8 b8 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c9f:	00 

0000000000004ca0 <fwp_heap_report>:
    4ca0:	f3 0f 1e fa          	endbr64
    4ca4:	41 54                	push   %r12
    4ca6:	48 8d 3d 0a 64 00 00 	lea    0x640a(%rip),%rdi        # b0b7 <_IO_stdin_used+0xb7>
    4cad:	55                   	push   %rbp
    4cae:	53                   	push   %rbx
    4caf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cb6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cbd:	00 00 
    4cbf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4cc6:	00 
    4cc7:	48 8d 35 74 65 00 00 	lea    0x6574(%rip),%rsi        # b242 <_IO_stdin_used+0x242>
    4cce:	e8 3d e9 ff ff       	call   3610 <fopen@plt>
    4cd3:	48 85 c0             	test   %rax,%rax
    4cd6:	0f 84 c5 00 00 00    	je     4da1 <fwp_heap_report+0x101>
    4cdc:	48 89 c5             	mov    %rax,%rbp
    4cdf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ce6:	48 89 e3             	mov    %rsp,%rbx
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 89 ea             	mov    %rbp,%rdx
    4cf3:	be 00 01 00 00       	mov    $0x100,%esi
    4cf8:	48 89 df             	mov    %rbx,%rdi
    4cfb:	e8 f0 e7 ff ff       	call   34f0 <fgets@plt>
    4d00:	48 85 c0             	test   %rax,%rax
    4d03:	74 2b                	je     4d30 <fwp_heap_report+0x90>
    4d05:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d0b:	75 e3                	jne    4cf0 <fwp_heap_report+0x50>
    4d0d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d11:	75 dd                	jne    4cf0 <fwp_heap_report+0x50>
    4d13:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d18:	75 d6                	jne    4cf0 <fwp_heap_report+0x50>
    4d1a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d1f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d24:	31 f6                	xor    %esi,%esi
    4d26:	e8 45 e8 ff ff       	call   3570 <strtol@plt>
    4d2b:	49 89 c4             	mov    %rax,%r12
    4d2e:	eb c0                	jmp    4cf0 <fwp_heap_report+0x50>
    4d30:	48 89 ef             	mov    %rbp,%rdi
    4d33:	e8 f8 e6 ff ff       	call   3430 <fclose@plt>
    4d38:	48 83 ec 08          	sub    $0x8,%rsp
    4d3c:	4c 8b 0d a5 3e 06 00 	mov    0x63ea5(%rip),%r9        # 68be8 <fwp_heap+0x13c8>
    4d43:	4c 8b 05 fe 3e 06 00 	mov    0x63efe(%rip),%r8        # 68c48 <fwp_heap+0x1428>
    4d4a:	48 8d 15 47 6b 00 00 	lea    0x6b47(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d51:	41 54                	push   %r12
    4d53:	48 8b 0d e6 3e 06 00 	mov    0x63ee6(%rip),%rcx        # 68c40 <fwp_heap+0x1420>
    4d5a:	be 02 00 00 00       	mov    $0x2,%esi
    4d5f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d64:	f2 0f 10 0d f4 3e 06 	movsd  0x63ef4(%rip),%xmm1        # 68c60 <fwp_heap+0x1440>
    4d6b:	00 
    4d6c:	f2 0f 10 05 e4 3e 06 	movsd  0x63ee4(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    4d73:	00 
    4d74:	48 8b 3d c5 a2 00 00 	mov    0xa2c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d7b:	e8 f0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4d80:	58                   	pop    %rax
    4d81:	5a                   	pop    %rdx
    4d82:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d89:	00 
    4d8a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d91:	00 00 
    4d93:	75 15                	jne    4daa <fwp_heap_report+0x10a>
    4d95:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d9c:	5b                   	pop    %rbx
    4d9d:	5d                   	pop    %rbp
    4d9e:	41 5c                	pop    %r12
    4da0:	c3                   	ret
    4da1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4da8:	eb 8e                	jmp    4d38 <fwp_heap_report+0x98>
    4daa:	e8 a1 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4daf:	90                   	nop

0000000000004db0 <fwp_heap_init>:
    4db0:	66 0f 6f 05 e8 6e 00 	movdqa 0x6ee8(%rip),%xmm0        # bca0 <msg.4+0x30>
    4db7:	00 
    4db8:	41 54                	push   %r12
    4dba:	48 8d 05 9f 39 06 00 	lea    0x6399f(%rip),%rax        # 68760 <fwp_heap+0xf40>
    4dc1:	ba 00 01 00 00       	mov    $0x100,%edx
    4dc6:	55                   	push   %rbp
    4dc7:	66 0f 6f 15 11 6f 00 	movdqa 0x6f11(%rip),%xmm2        # bce0 <msg.4+0x70>
    4dce:	00 
    4dcf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4dd3:	53                   	push   %rbx
    4dd4:	0f 29 05 45 39 06 00 	movaps %xmm0,0x63945(%rip)        # 68720 <fwp_heap+0xf00>
    4ddb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # bcb0 <msg.4+0x40>
    4de2:	00 
    4de3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4de7:	c7 05 d3 3d 06 00 01 	movl   $0x1,0x63dd3(%rip)        # 68bc4 <fwp_heap+0x13a4>
    4dee:	00 00 00 
    4df1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4df6:	0f 29 05 33 39 06 00 	movaps %xmm0,0x63933(%rip)        # 68730 <fwp_heap+0xf10>
    4dfd:	66 0f 6f 05 bb 6e 00 	movdqa 0x6ebb(%rip),%xmm0        # bcc0 <msg.4+0x50>
    4e04:	00 
    4e05:	0f 29 05 34 39 06 00 	movaps %xmm0,0x63934(%rip)        # 68740 <fwp_heap+0xf20>
    4e0c:	66 0f 6f 05 bc 6e 00 	movdqa 0x6ebc(%rip),%xmm0        # bcd0 <msg.4+0x60>
    4e13:	00 
    4e14:	0f 29 05 35 39 06 00 	movaps %xmm0,0x63935(%rip)        # 68750 <fwp_heap+0xf30>
    4e1b:	89 d3                	mov    %edx,%ebx
    4e1d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e21:	48 83 c0 10          	add    $0x10,%rax
    4e25:	01 d2                	add    %edx,%edx
    4e27:	c1 eb 02             	shr    $0x2,%ebx
    4e2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e5f:	48 39 c7             	cmp    %rax,%rdi
    4e62:	75 b7                	jne    4e1b <fwp_heap_init+0x6b>
    4e64:	4c 8d 05 b5 29 06 00 	lea    0x629b5(%rip),%r8        # 67820 <fwp_heap>
    4e6b:	31 c9                	xor    %ecx,%ecx
    4e6d:	31 c0                	xor    %eax,%eax
    4e6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e7d:	00 00 00 
    4e80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e87:	00 
    4e88:	48 39 ca             	cmp    %rcx,%rdx
    4e8b:	73 0f                	jae    4e9c <fwp_heap_init+0xec>
    4e8d:	0f 1f 00             	nopl   (%rax)
    4e90:	48 83 c0 01          	add    $0x1,%rax
    4e94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e97:	48 39 ca             	cmp    %rcx,%rdx
    4e9a:	72 f4                	jb     4e90 <fwp_heap_init+0xe0>
    4e9c:	48 83 c1 10          	add    $0x10,%rcx
    4ea0:	88 07                	mov    %al,(%rdi)
    4ea2:	48 83 c7 01          	add    $0x1,%rdi
    4ea6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ead:	75 d1                	jne    4e80 <fwp_heap_init+0xd0>
    4eaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4eb6:	00 00 00 
    4eb9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ebe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ec5:	45 31 c9             	xor    %r9d,%r9d
    4ec8:	31 d2                	xor    %edx,%edx
    4eca:	31 ff                	xor    %edi,%edi
    4ecc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ed2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ed7:	4c 89 e6             	mov    %r12,%rsi
    4eda:	e8 81 e5 ff ff       	call   3460 <mmap@plt>
    4edf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ee3:	75 13                	jne    4ef8 <fwp_heap_init+0x148>
    4ee5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ee9:	83 ed 01             	sub    $0x1,%ebp
    4eec:	75 d0                	jne    4ebe <fwp_heap_init+0x10e>
    4eee:	e8 1d ef ff ff       	call   3e10 <fwp_heap_oom>
    4ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ef8:	48 85 c0             	test   %rax,%rax
    4efb:	74 f1                	je     4eee <fwp_heap_init+0x13e>
    4efd:	48 c1 eb 10          	shr    $0x10,%rbx
    4f01:	48 89 05 d0 3c 06 00 	mov    %rax,0x63cd0(%rip)        # 68bd8 <fwp_heap+0x13b8>
    4f08:	45 31 c9             	xor    %r9d,%r9d
    4f0b:	31 d2                	xor    %edx,%edx
    4f0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f17:	31 ff                	xor    %edi,%edi
    4f19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f1f:	66 31 c0             	xor    %ax,%ax
    4f22:	48 c1 e6 03          	shl    $0x3,%rsi
    4f26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f2b:	4c 89 25 ae 3c 06 00 	mov    %r12,0x63cae(%rip)        # 68be0 <fwp_heap+0x13c0>
    4f32:	48 89 05 97 3c 06 00 	mov    %rax,0x63c97(%rip)        # 68bd0 <fwp_heap+0x13b0>
    4f39:	48 89 1d b0 3c 06 00 	mov    %rbx,0x63cb0(%rip)        # 68bf0 <fwp_heap+0x13d0>
    4f40:	48 89 35 d9 3c 06 00 	mov    %rsi,0x63cd9(%rip)        # 68c20 <fwp_heap+0x1400>
    4f47:	e8 14 e5 ff ff       	call   3460 <mmap@plt>
    4f4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f50:	74 9c                	je     4eee <fwp_heap_init+0x13e>
    4f52:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # b0ed <_IO_stdin_used+0xed>
    4f59:	48 89 05 b8 3c 06 00 	mov    %rax,0x63cb8(%rip)        # 68c18 <fwp_heap+0x13f8>
    4f60:	e8 2b e4 ff ff       	call   3390 <getenv@plt>
    4f65:	48 89 c2             	mov    %rax,%rdx
    4f68:	31 c0                	xor    %eax,%eax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 15                	je     4f84 <fwp_heap_init+0x1d4>
    4f6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f72:	74 10                	je     4f84 <fwp_heap_init+0x1d4>
    4f74:	0f b6 02             	movzbl (%rdx),%eax
    4f77:	83 e8 30             	sub    $0x30,%eax
    4f7a:	74 13                	je     4f8f <fwp_heap_init+0x1df>
    4f7c:	85 c0                	test   %eax,%eax
    4f7e:	0f 95 c0             	setne  %al
    4f81:	0f b6 c0             	movzbl %al,%eax
    4f84:	5b                   	pop    %rbx
    4f85:	5d                   	pop    %rbp
    4f86:	89 05 3c 3c 06 00    	mov    %eax,0x63c3c(%rip)        # 68bc8 <fwp_heap+0x13a8>
    4f8c:	41 5c                	pop    %r12
    4f8e:	c3                   	ret
    4f8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f93:	85 c0                	test   %eax,%eax
    4f95:	0f 95 c0             	setne  %al
    4f98:	0f b6 c0             	movzbl %al,%eax
    4f9b:	eb e7                	jmp    4f84 <fwp_heap_init+0x1d4>
    4f9d:	0f 1f 00             	nopl   (%rax)

0000000000004fa0 <fwp_wake_io>:
    4fa0:	48 8b 07             	mov    (%rdi),%rax
    4fa3:	48 85 c0             	test   %rax,%rax
    4fa6:	0f 84 f4 00 00 00    	je     50a0 <fwp_wake_io+0x100>
    4fac:	53                   	push   %rbx
    4fad:	4c 8b 05 2c 28 06 00 	mov    0x6282c(%rip),%r8        # 677e0 <fwp_ready_tail>
    4fb4:	49 89 f9             	mov    %rdi,%r9
    4fb7:	48 89 c2             	mov    %rax,%rdx
    4fba:	45 31 db             	xor    %r11d,%r11d
    4fbd:	45 31 d2             	xor    %r10d,%r10d
    4fc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fc4:	eb 71                	jmp    5037 <fwp_wake_io+0x97>
    4fc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fcd:	00 00 00 
    4fd0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fd7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fde:	48 85 c9             	test   %rcx,%rcx
    4fe1:	74 07                	je     4fea <fwp_wake_io+0x4a>
    4fe3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fea:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4ff1:	00 00 00 00 
    4ff5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ffc:	49 8b 01             	mov    (%r9),%rax
    4fff:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5003:	75 2a                	jne    502f <fwp_wake_io+0x8f>
    5005:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5009:	75 24                	jne    502f <fwp_wake_io+0x8f>
    500b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    500f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5016:	00 00 00 00 
    501a:	4d 85 c0             	test   %r8,%r8
    501d:	74 51                	je     5070 <fwp_wake_io+0xd0>
    501f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5026:	49 89 d0             	mov    %rdx,%r8
    5029:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    502f:	48 89 c2             	mov    %rax,%rdx
    5032:	48 85 c0             	test   %rax,%rax
    5035:	74 49                	je     5080 <fwp_wake_io+0xe0>
    5037:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    503e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5042:	48 85 ff             	test   %rdi,%rdi
    5045:	74 b8                	je     4fff <fwp_wake_io+0x5f>
    5047:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    504e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5055:	48 85 f6             	test   %rsi,%rsi
    5058:	0f 85 72 ff ff ff    	jne    4fd0 <fwp_wake_io+0x30>
    505e:	48 89 0f             	mov    %rcx,(%rdi)
    5061:	e9 78 ff ff ff       	jmp    4fde <fwp_wake_io+0x3e>
    5066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    506d:	00 00 00 
    5070:	48 89 d3             	mov    %rdx,%rbx
    5073:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5079:	eb ab                	jmp    5026 <fwp_wake_io+0x86>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	45 84 db             	test   %r11b,%r11b
    5083:	74 07                	je     508c <fwp_wake_io+0xec>
    5085:	48 89 1d 5c 27 06 00 	mov    %rbx,0x6275c(%rip)        # 677e8 <fwp_ready_head>
    508c:	45 84 d2             	test   %r10b,%r10b
    508f:	74 07                	je     5098 <fwp_wake_io+0xf8>
    5091:	4c 89 05 48 27 06 00 	mov    %r8,0x62748(%rip)        # 677e0 <fwp_ready_tail>
    5098:	5b                   	pop    %rbx
    5099:	c3                   	ret
    509a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50a0:	c3                   	ret
    50a1:	0f 1f 40 00          	nopl   0x0(%rax)
    50a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50ac:	00 00 00 00 

00000000000050b0 <ad_raw_free.part.0>:
    50b0:	48 8d 0d 09 a1 04 00 	lea    0x4a109(%rip),%rcx        # 4f1c0 <ad_raw_blocks>
    50b7:	31 c0                	xor    %eax,%eax
    50b9:	48 89 ca             	mov    %rcx,%rdx
    50bc:	eb 12                	jmp    50d0 <ad_raw_free.part.0+0x20>
    50be:	66 90                	xchg   %ax,%ax
    50c0:	48 83 c0 01          	add    $0x1,%rax
    50c4:	48 83 c2 18          	add    $0x18,%rdx
    50c8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ce:	74 40                	je     5110 <ad_raw_free.part.0+0x60>
    50d0:	48 3b 3a             	cmp    (%rdx),%rdi
    50d3:	75 eb                	jne    50c0 <ad_raw_free.part.0+0x10>
    50d5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50d9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50dd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50e1:	48 8d 0d b8 a0 04 00 	lea    0x4a0b8(%rip),%rcx        # 4f1a0 <ad_raw_live>
    50e8:	8b 70 10             	mov    0x10(%rax),%esi
    50eb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50f2:	00 
    50f3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50f7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50fb:	0f 11 00             	movups %xmm0,(%rax)
    50fe:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5102:	e9 a9 e2 ff ff       	jmp    33b0 <free@plt>
    5107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    510e:	00 00 
    5110:	48 83 ec 08          	sub    $0x8,%rsp
    5114:	48 8d 3d e2 5f 00 00 	lea    0x5fe2(%rip),%rdi        # b0fd <_IO_stdin_used+0xfd>
    511b:	e8 c0 ee ff ff       	call   3fe0 <ad_raw_fail>

0000000000005120 <fwp_tape_buffers_dispose>:
    5120:	53                   	push   %rbx
    5121:	48 89 fb             	mov    %rdi,%rbx
    5124:	48 8b 3f             	mov    (%rdi),%rdi
    5127:	48 85 ff             	test   %rdi,%rdi
    512a:	74 05                	je     5131 <fwp_tape_buffers_dispose+0x11>
    512c:	e8 7f ff ff ff       	call   50b0 <ad_raw_free.part.0>
    5131:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5135:	48 85 ff             	test   %rdi,%rdi
    5138:	74 05                	je     513f <fwp_tape_buffers_dispose+0x1f>
    513a:	e8 71 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    513f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5143:	48 85 ff             	test   %rdi,%rdi
    5146:	74 05                	je     514d <fwp_tape_buffers_dispose+0x2d>
    5148:	e8 63 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    514d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5151:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5158:	00 
    5159:	0f 11 03             	movups %xmm0,(%rbx)
    515c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5160:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5164:	5b                   	pop    %rbx
    5165:	c3                   	ret
    5166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    516d:	00 00 00 

0000000000005170 <ad_raw_realloc>:
    5170:	41 55                	push   %r13
    5172:	41 54                	push   %r12
    5174:	55                   	push   %rbp
    5175:	53                   	push   %rbx
    5176:	48 83 ec 08          	sub    $0x8,%rsp
    517a:	48 85 f6             	test   %rsi,%rsi
    517d:	0f 84 a6 00 00 00    	je     5229 <ad_raw_realloc+0xb9>
    5183:	4c 8d 25 36 a0 04 00 	lea    0x4a036(%rip),%r12        # 4f1c0 <ad_raw_blocks>
    518a:	48 89 f5             	mov    %rsi,%rbp
    518d:	41 89 d5             	mov    %edx,%r13d
    5190:	31 db                	xor    %ebx,%ebx
    5192:	4c 89 e0             	mov    %r12,%rax
    5195:	eb 1a                	jmp    51b1 <ad_raw_realloc+0x41>
    5197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    519e:	00 00 
    51a0:	48 83 c3 01          	add    $0x1,%rbx
    51a4:	48 83 c0 18          	add    $0x18,%rax
    51a8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51af:	74 4f                	je     5200 <ad_raw_realloc+0x90>
    51b1:	48 3b 38             	cmp    (%rax),%rdi
    51b4:	75 ea                	jne    51a0 <ad_raw_realloc+0x30>
    51b6:	48 85 ff             	test   %rdi,%rdi
    51b9:	74 0b                	je     51c6 <ad_raw_realloc+0x56>
    51bb:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51bf:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51c4:	75 57                	jne    521d <ad_raw_realloc+0xad>
    51c6:	48 89 ee             	mov    %rbp,%rsi
    51c9:	e8 e2 e3 ff ff       	call   35b0 <realloc@plt>
    51ce:	49 89 c2             	mov    %rax,%r10
    51d1:	48 85 c0             	test   %rax,%rax
    51d4:	74 16                	je     51ec <ad_raw_realloc+0x7c>
    51d6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51da:	44 89 e9             	mov    %r13d,%ecx
    51dd:	48 89 ea             	mov    %rbp,%rdx
    51e0:	4c 89 d6             	mov    %r10,%rsi
    51e3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51e7:	e8 f4 e9 ff ff       	call   3be0 <ad_raw_record>
    51ec:	48 83 c4 08          	add    $0x8,%rsp
    51f0:	4c 89 d0             	mov    %r10,%rax
    51f3:	5b                   	pop    %rbx
    51f4:	5d                   	pop    %rbp
    51f5:	41 5c                	pop    %r12
    51f7:	41 5d                	pop    %r13
    51f9:	c3                   	ret
    51fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5200:	48 85 ff             	test   %rdi,%rdi
    5203:	48 8d 05 08 5f 00 00 	lea    0x5f08(%rip),%rax        # b112 <_IO_stdin_used+0x112>
    520a:	48 8d 15 ec 5e 00 00 	lea    0x5eec(%rip),%rdx        # b0fd <_IO_stdin_used+0xfd>
    5211:	48 0f 45 c2          	cmovne %rdx,%rax
    5215:	48 89 c7             	mov    %rax,%rdi
    5218:	e8 c3 ed ff ff       	call   3fe0 <ad_raw_fail>
    521d:	48 8d 3d 24 5f 00 00 	lea    0x5f24(%rip),%rdi        # b148 <_IO_stdin_used+0x148>
    5224:	e8 b7 ed ff ff       	call   3fe0 <ad_raw_fail>
    5229:	48 8d 3d fd 5e 00 00 	lea    0x5efd(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    5230:	e8 ab ed ff ff       	call   3fe0 <ad_raw_fail>
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 

0000000000005240 <fwp_tape_buffers_release>:
    5240:	f3 0f 1e fa          	endbr64
    5244:	53                   	push   %rbx
    5245:	48 89 fb             	mov    %rdi,%rbx
    5248:	48 83 ec 10          	sub    $0x10,%rsp
    524c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5250:	48 85 c0             	test   %rax,%rax
    5253:	0f 88 d7 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5259:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    525d:	48 85 d2             	test   %rdx,%rdx
    5260:	0f 88 ca 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5266:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    526c:	0f 87 be 00 00 00    	ja     5330 <fwp_tape_buffers_release+0xf0>
    5272:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5276:	b8 00 00 08 00       	mov    $0x80000,%eax
    527b:	48 c1 e1 03          	shl    $0x3,%rcx
    527f:	48 29 c8             	sub    %rcx,%rax
    5282:	48 c1 e8 03          	shr    $0x3,%rax
    5286:	48 39 d0             	cmp    %rdx,%rax
    5289:	0f 82 a1 00 00 00    	jb     5330 <fwp_tape_buffers_release+0xf0>
    528f:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5296:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    529b:	48 89 14 24          	mov    %rdx,(%rsp)
    529f:	e8 ec e0 ff ff       	call   3390 <getenv@plt>
    52a4:	48 8b 14 24          	mov    (%rsp),%rdx
    52a8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52ad:	48 85 c0             	test   %rax,%rax
    52b0:	74 09                	je     52bb <fwp_tape_buffers_release+0x7b>
    52b2:	80 38 30             	cmpb   $0x30,(%rax)
    52b5:	0f 84 05 01 00 00    	je     53c0 <fwp_tape_buffers_release+0x180>
    52bb:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52bf:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52c3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52c9:	77 71                	ja     533c <fwp_tape_buffers_release+0xfc>
    52cb:	48 8d 3d ce 9d 01 00 	lea    0x19dce(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    52d2:	48 89 34 24          	mov    %rsi,(%rsp)
    52d6:	e8 45 fe ff ff       	call   5120 <fwp_tape_buffers_dispose>
    52db:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52df:	48 8b 34 24          	mov    (%rsp),%rsi
    52e3:	0f 29 05 b6 9d 01 00 	movaps %xmm0,0x19db6(%rip)        # 1f0a0 <fwp_tape_workspace>
    52ea:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52ef:	48 89 35 92 9d 01 00 	mov    %rsi,0x19d92(%rip)        # 1f088 <fwp_tape_cached_bytes>
    52f6:	0f 29 05 b3 9d 01 00 	movaps %xmm0,0x19db3(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    52fd:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5302:	0f 29 05 b7 9d 01 00 	movaps %xmm0,0x19db7(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    5309:	48 8b 43 30          	mov    0x30(%rbx),%rax
    530d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5311:	48 89 05 b8 9d 01 00 	mov    %rax,0x19db8(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5318:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    531f:	00 
    5320:	0f 11 03             	movups %xmm0,(%rbx)
    5323:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5327:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    532b:	eb 1e                	jmp    534b <fwp_tape_buffers_release+0x10b>
    532d:	0f 1f 00             	nopl   (%rax)
    5330:	48 8d 3d 29 5e 00 00 	lea    0x5e29(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5337:	e8 54 e0 ff ff       	call   3390 <getenv@plt>
    533c:	48 89 df             	mov    %rbx,%rdi
    533f:	e8 dc fd ff ff       	call   5120 <fwp_tape_buffers_dispose>
    5344:	48 8b 35 3d 9d 01 00 	mov    0x19d3d(%rip),%rsi        # 1f088 <fwp_tape_cached_bytes>
    534b:	48 6b 15 8d 9d 01 00 	imul   $0x68,0x19d8d(%rip),%rdx        # 1f0e0 <fwp_tapes_cap>
    5352:	68 
    5353:	48 3b 15 46 9e 04 00 	cmp    0x49e46(%rip),%rdx        # 4f1a0 <ad_raw_live>
    535a:	75 73                	jne    53cf <fwp_tape_buffers_release+0x18f>
    535c:	48 8b 05 45 9e 04 00 	mov    0x49e45(%rip),%rax        # 4f1a8 <ad_raw_live+0x8>
    5363:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5367:	48 01 d0             	add    %rdx,%rax
    536a:	48 03 05 3f 9e 04 00 	add    0x49e3f(%rip),%rax        # 4f1b0 <ad_raw_live+0x10>
    5371:	48 03 05 40 9e 04 00 	add    0x49e40(%rip),%rax        # 4f1b8 <ad_raw_live+0x18>
    5378:	48 39 c8             	cmp    %rcx,%rax
    537b:	72 52                	jb     53cf <fwp_tape_buffers_release+0x18f>
    537d:	48 8b 0d 7c 9d 01 00 	mov    0x19d7c(%rip),%rcx        # 1f100 <ad_raw_checkpoint_count>
    5384:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    538b:	74 4e                	je     53db <fwp_tape_buffers_release+0x19b>
    538d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5391:	48 29 d0             	sub    %rdx,%rax
    5394:	48 89 3d 65 9d 01 00 	mov    %rdi,0x19d65(%rip)        # 1f100 <ad_raw_checkpoint_count>
    539b:	48 29 f0             	sub    %rsi,%rax
    539e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53a2:	48 8d 0d 77 9d 01 00 	lea    0x19d77(%rip),%rcx        # 1f120 <ad_raw_checkpoints>
    53a9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53ad:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53b2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53b7:	48 83 c4 10          	add    $0x10,%rsp
    53bb:	5b                   	pop    %rbx
    53bc:	c3                   	ret
    53bd:	0f 1f 00             	nopl   (%rax)
    53c0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53c4:	0f 84 72 ff ff ff    	je     533c <fwp_tape_buffers_release+0xfc>
    53ca:	e9 ec fe ff ff       	jmp    52bb <fwp_tape_buffers_release+0x7b>
    53cf:	48 8d 3d 4a 65 00 00 	lea    0x654a(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    53d6:	e8 05 ec ff ff       	call   3fe0 <ad_raw_fail>
    53db:	48 8d 3d 8f 5d 00 00 	lea    0x5d8f(%rip),%rdi        # b171 <_IO_stdin_used+0x171>
    53e2:	e8 f9 eb ff ff       	call   3fe0 <ad_raw_fail>
    53e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53ee:	00 00 

00000000000053f0 <fwp_poll_events>:
    53f0:	53                   	push   %rbx
    53f1:	48 83 ec 20          	sub    $0x20,%rsp
    53f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53fc:	00 00 
    53fe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5403:	31 c0                	xor    %eax,%eax
    5405:	e8 96 f1 ff ff       	call   45a0 <fwp_now_ns>
    540a:	48 8b 1d c7 23 06 00 	mov    0x623c7(%rip),%rbx        # 677d8 <fwp_timers>
    5411:	48 85 db             	test   %rbx,%rbx
    5414:	0f 84 e6 00 00 00    	je     5500 <fwp_poll_events+0x110>
    541a:	48 89 c6             	mov    %rax,%rsi
    541d:	48 89 da             	mov    %rbx,%rdx
    5420:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5427:	eb 26                	jmp    544f <fwp_poll_events+0x5f>
    5429:	90                   	nop
    542a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5431:	00 00 00 00 
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5447:	48 89 c8             	mov    %rcx,%rax
    544a:	48 85 d2             	test   %rdx,%rdx
    544d:	74 31                	je     5480 <fwp_poll_events+0x90>
    544f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5453:	48 85 c0             	test   %rax,%rax
    5456:	78 e8                	js     5440 <fwp_poll_events+0x50>
    5458:	48 39 c1             	cmp    %rax,%rcx
    545b:	7c e3                	jl     5440 <fwp_poll_events+0x50>
    545d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5464:	48 85 d2             	test   %rdx,%rdx
    5467:	74 1c                	je     5485 <fwp_poll_events+0x95>
    5469:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    546d:	48 39 c1             	cmp    %rax,%rcx
    5470:	7c ce                	jl     5440 <fwp_poll_events+0x50>
    5472:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5479:	48 85 d2             	test   %rdx,%rdx
    547c:	75 d1                	jne    544f <fwp_poll_events+0x5f>
    547e:	66 90                	xchg   %ax,%ax
    5480:	48 85 c0             	test   %rax,%rax
    5483:	78 7b                	js     5500 <fwp_poll_events+0x110>
    5485:	48 29 f0             	sub    %rsi,%rax
    5488:	48 89 c1             	mov    %rax,%rcx
    548b:	48 85 c0             	test   %rax,%rax
    548e:	0f 8e 9c 00 00 00    	jle    5530 <fwp_poll_events+0x140>
    5494:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    549b:	de 1b 43 
    549e:	48 f7 ea             	imul   %rdx
    54a1:	48 89 c8             	mov    %rcx,%rax
    54a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54a8:	48 c1 fa 12          	sar    $0x12,%rdx
    54ac:	48 29 c2             	sub    %rax,%rdx
    54af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54b6:	48 39 c1             	cmp    %rax,%rcx
    54b9:	0f 95 c0             	setne  %al
    54bc:	0f b6 c0             	movzbl %al,%eax
    54bf:	48 01 d0             	add    %rdx,%rax
    54c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54c8:	0f 8f 32 01 00 00    	jg     5600 <fwp_poll_events+0x210>
    54ce:	48 85 c0             	test   %rax,%rax
    54d1:	74 5d                	je     5530 <fwp_poll_events+0x140>
    54d3:	89 c1                	mov    %eax,%ecx
    54d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54dc:	48 c1 e9 26          	shr    $0x26,%rcx
    54e0:	48 63 d1             	movslq %ecx,%rdx
    54e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54e9:	29 c8                	sub    %ecx,%eax
    54eb:	48 98                	cltq
    54ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54f4:	e9 11 01 00 00       	jmp    560a <fwp_poll_events+0x21a>
    54f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5500:	e8 db e7 ff ff       	call   3ce0 <fwp_flush>
    5505:	ba 2b 00 00 00       	mov    $0x2b,%edx
    550a:	be 01 00 00 00       	mov    $0x1,%esi
    550f:	48 8b 0d 2a 9b 00 00 	mov    0x9b2a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5516:	48 8d 3d 33 64 00 00 	lea    0x6433(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    551d:	e8 3e e1 ff ff       	call   3660 <fwrite@plt>
    5522:	bf 65 00 00 00       	mov    $0x65,%edi
    5527:	e8 24 e1 ff ff       	call   3650 <exit@plt>
    552c:	0f 1f 40 00          	nopl   0x0(%rax)
    5530:	e8 6b f0 ff ff       	call   45a0 <fwp_now_ns>
    5535:	48 89 c1             	mov    %rax,%rcx
    5538:	66 0f ef c0          	pxor   %xmm0,%xmm0
    553c:	eb 44                	jmp    5582 <fwp_poll_events+0x192>
    553e:	66 90                	xchg   %ax,%ax
    5540:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5544:	75 33                	jne    5579 <fwp_poll_events+0x189>
    5546:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    554a:	75 2d                	jne    5579 <fwp_poll_events+0x189>
    554c:	48 8b 05 8d 22 06 00 	mov    0x6228d(%rip),%rax        # 677e0 <fwp_ready_tail>
    5553:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5557:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    555e:	00 00 00 00 
    5562:	48 85 c0             	test   %rax,%rax
    5565:	0f 84 05 01 00 00    	je     5670 <fwp_poll_events+0x280>
    556b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5572:	48 89 15 67 22 06 00 	mov    %rdx,0x62267(%rip)        # 677e0 <fwp_ready_tail>
    5579:	48 85 db             	test   %rbx,%rbx
    557c:	0f 84 be 00 00 00    	je     5640 <fwp_poll_events+0x250>
    5582:	48 89 da             	mov    %rbx,%rdx
    5585:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    558c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5590:	7f e7                	jg     5579 <fwp_poll_events+0x189>
    5592:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5596:	74 2e                	je     55c6 <fwp_poll_events+0x1d6>
    5598:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    559f:	48 85 c0             	test   %rax,%rax
    55a2:	0f 84 b8 00 00 00    	je     5660 <fwp_poll_events+0x270>
    55a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55af:	48 85 db             	test   %rbx,%rbx
    55b2:	74 07                	je     55bb <fwp_poll_events+0x1cb>
    55b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ce:	48 85 c0             	test   %rax,%rax
    55d1:	0f 84 69 ff ff ff    	je     5540 <fwp_poll_events+0x150>
    55d7:	48 39 c8             	cmp    %rcx,%rax
    55da:	0f 8f 60 ff ff ff    	jg     5540 <fwp_poll_events+0x150>
    55e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55e4:	0f 85 56 ff ff ff    	jne    5540 <fwp_poll_events+0x150>
    55ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ee:	75 89                	jne    5579 <fwp_poll_events+0x189>
    55f0:	48 89 d7             	mov    %rdx,%rdi
    55f3:	e8 18 eb ff ff       	call   4110 <fwp_cancel_tree.part.0>
    55f8:	e9 43 ff ff ff       	jmp    5540 <fwp_poll_events+0x150>
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5605:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    560a:	48 89 e7             	mov    %rsp,%rdi
    560d:	31 f6                	xor    %esi,%esi
    560f:	48 89 14 24          	mov    %rdx,(%rsp)
    5613:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5618:	e8 73 de ff ff       	call   3490 <nanosleep@plt>
    561d:	48 8b 1d b4 21 06 00 	mov    0x621b4(%rip),%rbx        # 677d8 <fwp_timers>
    5624:	e8 77 ef ff ff       	call   45a0 <fwp_now_ns>
    5629:	48 89 c1             	mov    %rax,%rcx
    562c:	48 85 db             	test   %rbx,%rbx
    562f:	0f 85 03 ff ff ff    	jne    5538 <fwp_poll_events+0x148>
    5635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    563c:	00 00 00 00 
    5640:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5645:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    564c:	00 00 
    564e:	75 2c                	jne    567c <fwp_poll_events+0x28c>
    5650:	48 83 c4 20          	add    $0x20,%rsp
    5654:	5b                   	pop    %rbx
    5655:	c3                   	ret
    5656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    565d:	00 00 00 
    5660:	48 89 1d 71 21 06 00 	mov    %rbx,0x62171(%rip)        # 677d8 <fwp_timers>
    5667:	e9 43 ff ff ff       	jmp    55af <fwp_poll_events+0x1bf>
    566c:	0f 1f 40 00          	nopl   0x0(%rax)
    5670:	48 89 15 71 21 06 00 	mov    %rdx,0x62171(%rip)        # 677e8 <fwp_ready_head>
    5677:	e9 f6 fe ff ff       	jmp    5572 <fwp_poll_events+0x182>
    567c:	e8 cf dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5681:	0f 1f 40 00          	nopl   0x0(%rax)
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_rc_wide_dup>:
    5690:	48 89 fa             	mov    %rdi,%rdx
    5693:	48 8d 35 86 21 06 00 	lea    0x62186(%rip),%rsi        # 67820 <fwp_heap>
    569a:	48 83 ec 18          	sub    $0x18,%rsp
    569e:	48 89 f9             	mov    %rdi,%rcx
    56a1:	48 c1 ea 11          	shr    $0x11,%rdx
    56a5:	48 31 fa             	xor    %rdi,%rdx
    56a8:	48 89 d0             	mov    %rdx,%rax
    56ab:	48 c1 e8 09          	shr    $0x9,%rax
    56af:	48 31 c2             	xor    %rax,%rdx
    56b2:	0f b6 d2             	movzbl %dl,%edx
    56b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56bc:	00 
    56bd:	49 8b 00             	mov    (%r8),%rax
    56c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56c7:	00 00 
    56c9:	75 21                	jne    56ec <fwp_rc_wide_dup+0x5c>
    56cb:	e9 98 00 00 00       	jmp    5768 <fwp_rc_wide_dup+0xd8>
    56d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56dc:	00 00 00 00 
    56e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56e4:	48 85 d2             	test   %rdx,%rdx
    56e7:	74 2f                	je     5718 <fwp_rc_wide_dup+0x88>
    56e9:	48 89 d0             	mov    %rdx,%rax
    56ec:	48 3b 08             	cmp    (%rax),%rcx
    56ef:	75 ef                	jne    56e0 <fwp_rc_wide_dup+0x50>
    56f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56f4:	74 7c                	je     5772 <fwp_rc_wide_dup+0xe2>
    56f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56fe:	0f 84 91 00 00 00    	je     5795 <fwp_rc_wide_dup+0x105>
    5704:	48 83 c2 01          	add    $0x1,%rdx
    5708:	48 89 50 08          	mov    %rdx,0x8(%rax)
    570c:	48 83 c4 18          	add    $0x18,%rsp
    5710:	c3                   	ret
    5711:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5718:	4c 8d 40 10          	lea    0x10(%rax),%r8
    571c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    571f:	75 68                	jne    5789 <fwp_rc_wide_dup+0xf9>
    5721:	bf 18 00 00 00       	mov    $0x18,%edi
    5726:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    572b:	4c 89 04 24          	mov    %r8,(%rsp)
    572f:	e8 5c de ff ff       	call   3590 <malloc@plt>
    5734:	4c 8b 04 24          	mov    (%rsp),%r8
    5738:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    573d:	48 85 c0             	test   %rax,%rax
    5740:	74 5f                	je     57a1 <fwp_rc_wide_dup+0x111>
    5742:	48 89 08             	mov    %rcx,(%rax)
    5745:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    574c:	00 
    574d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5754:	00 
    5755:	49 89 00             	mov    %rax,(%r8)
    5758:	c6 01 ff             	movb   $0xff,(%rcx)
    575b:	48 83 05 05 3d 06 00 	addq   $0x1,0x63d05(%rip)        # 69468 <fwp_heap+0x1c48>
    5762:	01 
    5763:	48 83 c4 18          	add    $0x18,%rsp
    5767:	c3                   	ret
    5768:	80 3f fe             	cmpb   $0xfe,(%rdi)
    576b:	75 13                	jne    5780 <fwp_rc_wide_dup+0xf0>
    576d:	48 85 c0             	test   %rax,%rax
    5770:	74 af                	je     5721 <fwp_rc_wide_dup+0x91>
    5772:	48 8d 3d 07 62 00 00 	lea    0x6207(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    5779:	e8 b2 ec ff ff       	call   4430 <fwp_trap>
    577e:	66 90                	xchg   %ax,%ax
    5780:	48 85 c0             	test   %rax,%rax
    5783:	0f 85 6d ff ff ff    	jne    56f6 <fwp_rc_wide_dup+0x66>
    5789:	48 8d 3d 18 62 00 00 	lea    0x6218(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5790:	e8 9b ec ff ff       	call   4430 <fwp_trap>
    5795:	48 8d 3d f2 59 00 00 	lea    0x59f2(%rip),%rdi        # b18e <_IO_stdin_used+0x18e>
    579c:	e8 8f ec ff ff       	call   4430 <fwp_trap>
    57a1:	e8 6a e6 ff ff       	call   3e10 <fwp_heap_oom>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_rc_forget_slot>:
    57b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57b3:	74 0b                	je     57c0 <fwp_rc_forget_slot+0x10>
    57b5:	c3                   	ret
    57b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57bd:	00 00 00 
    57c0:	48 89 f8             	mov    %rdi,%rax
    57c3:	48 83 ec 08          	sub    $0x8,%rsp
    57c7:	48 89 fa             	mov    %rdi,%rdx
    57ca:	48 c1 e8 11          	shr    $0x11,%rax
    57ce:	48 31 f8             	xor    %rdi,%rax
    57d1:	48 89 c1             	mov    %rax,%rcx
    57d4:	48 c1 e9 09          	shr    $0x9,%rcx
    57d8:	48 31 c8             	xor    %rcx,%rax
    57db:	48 8d 0d 3e 20 06 00 	lea    0x6203e(%rip),%rcx        # 67820 <fwp_heap>
    57e2:	0f b6 c0             	movzbl %al,%eax
    57e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ec:	00 
    57ed:	48 85 ff             	test   %rdi,%rdi
    57f0:	74 3c                	je     582e <fwp_rc_forget_slot+0x7e>
    57f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57f9:	00 
    57fa:	48 8b 01             	mov    (%rcx),%rax
    57fd:	eb 11                	jmp    5810 <fwp_rc_forget_slot+0x60>
    57ff:	90                   	nop
    5800:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5804:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5808:	48 85 ff             	test   %rdi,%rdi
    580b:	74 21                	je     582e <fwp_rc_forget_slot+0x7e>
    580d:	48 89 f8             	mov    %rdi,%rax
    5810:	48 3b 10             	cmp    (%rax),%rdx
    5813:	75 eb                	jne    5800 <fwp_rc_forget_slot+0x50>
    5815:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5819:	48 89 01             	mov    %rax,(%rcx)
    581c:	e8 8f db ff ff       	call   33b0 <free@plt>
    5821:	48 83 2d 3f 3c 06 00 	subq   $0x1,0x63c3f(%rip)        # 69468 <fwp_heap+0x1c48>
    5828:	01 
    5829:	48 83 c4 08          	add    $0x8,%rsp
    582d:	c3                   	ret
    582e:	48 8d 3d 73 61 00 00 	lea    0x6173(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5835:	e8 f6 eb ff ff       	call   4430 <fwp_trap>
    583a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005840 <fwp_rc_prepare_chunk>:
    5840:	48 83 3d 20 3c 06 00 	cmpq   $0x0,0x63c20(%rip)        # 69468 <fwp_heap+0x1c48>
    5847:	00 
    5848:	41 54                	push   %r12
    584a:	49 89 f4             	mov    %rsi,%r12
    584d:	55                   	push   %rbp
    584e:	48 89 fd             	mov    %rdi,%rbp
    5851:	53                   	push   %rbx
    5852:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5855:	0f 84 7d 00 00 00    	je     58d8 <fwp_rc_prepare_chunk+0x98>
    585b:	31 db                	xor    %ebx,%ebx
    585d:	85 c0                	test   %eax,%eax
    585f:	75 5f                	jne    58c0 <fwp_rc_prepare_chunk+0x80>
    5861:	48 85 f6             	test   %rsi,%rsi
    5864:	74 7c                	je     58e2 <fwp_rc_prepare_chunk+0xa2>
    5866:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    586a:	e8 41 db ff ff       	call   33b0 <free@plt>
    586f:	90                   	nop
    5870:	be 01 00 00 00       	mov    $0x1,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 93 dc ff ff       	call   3510 <calloc@plt>
    587d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5881:	48 85 c0             	test   %rax,%rax
    5884:	0f 85 87 00 00 00    	jne    5911 <fwp_rc_prepare_chunk+0xd1>
    588a:	e8 81 e5 ff ff       	call   3e10 <fwp_heap_oom>
    588f:	90                   	nop
    5890:	e8 1b ff ff ff       	call   57b0 <fwp_rc_forget_slot>
    5895:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5898:	48 83 c3 01          	add    $0x1,%rbx
    589c:	48 39 c3             	cmp    %rax,%rbx
    589f:	73 37                	jae    58d8 <fwp_rc_prepare_chunk+0x98>
    58a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58a8:	00 00 
    58aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58b1:	00 00 00 00 
    58b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58bc:	00 00 00 00 
    58c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58c4:	48 01 df             	add    %rbx,%rdi
    58c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ca:	74 c4                	je     5890 <fwp_rc_prepare_chunk+0x50>
    58cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58cf:	48 83 c3 01          	add    $0x1,%rbx
    58d3:	48 39 c3             	cmp    %rax,%rbx
    58d6:	72 e8                	jb     58c0 <fwp_rc_prepare_chunk+0x80>
    58d8:	49 39 c4             	cmp    %rax,%r12
    58db:	75 13                	jne    58f0 <fwp_rc_prepare_chunk+0xb0>
    58dd:	4d 85 e4             	test   %r12,%r12
    58e0:	75 46                	jne    5928 <fwp_rc_prepare_chunk+0xe8>
    58e2:	5b                   	pop    %rbx
    58e3:	5d                   	pop    %rbp
    58e4:	41 5c                	pop    %r12
    58e6:	c3                   	ret
    58e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ee:	00 00 
    58f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58f4:	48 29 05 75 3b 06 00 	sub    %rax,0x63b75(%rip)        # 69470 <fwp_heap+0x1c50>
    58fb:	e8 b0 da ff ff       	call   33b0 <free@plt>
    5900:	4d 85 e4             	test   %r12,%r12
    5903:	0f 85 67 ff ff ff    	jne    5870 <fwp_rc_prepare_chunk+0x30>
    5909:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5910:	00 
    5911:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5915:	5b                   	pop    %rbx
    5916:	4c 01 25 53 3b 06 00 	add    %r12,0x63b53(%rip)        # 69470 <fwp_heap+0x1c50>
    591d:	5d                   	pop    %rbp
    591e:	41 5c                	pop    %r12
    5920:	c3                   	ret
    5921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5928:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    592c:	5b                   	pop    %rbx
    592d:	4c 89 e2             	mov    %r12,%rdx
    5930:	31 f6                	xor    %esi,%esi
    5932:	5d                   	pop    %rbp
    5933:	41 5c                	pop    %r12
    5935:	e9 76 db ff ff       	jmp    34b0 <memset@plt>
    593a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005940 <fwp_heap_refill>:
    5940:	41 56                	push   %r14
    5942:	41 89 d6             	mov    %edx,%r14d
    5945:	41 55                	push   %r13
    5947:	41 89 f5             	mov    %esi,%r13d
    594a:	41 54                	push   %r12
    594c:	49 89 fc             	mov    %rdi,%r12
    594f:	bf 01 00 00 00       	mov    $0x1,%edi
    5954:	55                   	push   %rbp
    5955:	53                   	push   %rbx
    5956:	e8 f5 e4 ff ff       	call   3e50 <fwp_heap_chunks>
    595b:	48 89 c3             	mov    %rax,%rbx
    595e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5962:	48 8b 05 af 32 06 00 	mov    0x632af(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    5969:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    596d:	48 8d 05 ac 1e 06 00 	lea    0x61eac(%rip),%rax        # 67820 <fwp_heap>
    5974:	31 d2                	xor    %edx,%edx
    5976:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    597a:	48 89 ef             	mov    %rbp,%rdi
    597d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5981:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5985:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    598c:	00 
    598d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5992:	f7 f1                	div    %ecx
    5994:	31 d2                	xor    %edx,%edx
    5996:	66 0f 6e c1          	movd   %ecx,%xmm0
    599a:	66 0f 6e c8          	movd   %eax,%xmm1
    599e:	89 c6                	mov    %eax,%esi
    59a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59a5:	48 01 c8             	add    %rcx,%rax
    59a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59ac:	48 f7 f1             	div    %rcx
    59af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59b4:	89 45 18             	mov    %eax,0x18(%rbp)
    59b7:	e8 84 fe ff ff       	call   5840 <fwp_rc_prepare_chunk>
    59bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59bf:	48 89 d8             	mov    %rbx,%rax
    59c2:	48 c1 e0 10          	shl    $0x10,%rax
    59c6:	48 03 05 03 32 06 00 	add    0x63203(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    59cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59d6:	8b 55 08             	mov    0x8(%rbp),%edx
    59d9:	48 0f af d1          	imul   %rcx,%rdx
    59dd:	48 01 c2             	add    %rax,%rdx
    59e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59e5:	5b                   	pop    %rbx
    59e6:	5d                   	pop    %rbp
    59e7:	41 5c                	pop    %r12
    59e9:	41 5d                	pop    %r13
    59eb:	41 5e                	pop    %r14
    59ed:	c3                   	ret
    59ee:	66 90                	xchg   %ax,%ax

00000000000059f0 <fwp_mem_free>:
    59f0:	48 85 ff             	test   %rdi,%rdi
    59f3:	0f 84 17 02 00 00    	je     5c10 <fwp_mem_free+0x220>
    59f9:	48 8b 35 d0 31 06 00 	mov    0x631d0(%rip),%rsi        # 68bd0 <fwp_heap+0x13b0>
    5a00:	48 8b 05 f1 31 06 00 	mov    0x631f1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    5a07:	48 89 fa             	mov    %rdi,%rdx
    5a0a:	48 29 f2             	sub    %rsi,%rdx
    5a0d:	48 c1 e0 10          	shl    $0x10,%rax
    5a11:	48 39 c2             	cmp    %rax,%rdx
    5a14:	0f 83 f6 01 00 00    	jae    5c10 <fwp_mem_free+0x220>
    5a1a:	49 89 d1             	mov    %rdx,%r9
    5a1d:	49 c1 e9 10          	shr    $0x10,%r9
    5a21:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a25:	48 c1 e0 03          	shl    $0x3,%rax
    5a29:	49 89 c0             	mov    %rax,%r8
    5a2c:	4c 03 05 e5 31 06 00 	add    0x631e5(%rip),%r8        # 68c18 <fwp_heap+0x13f8>
    5a33:	0f 84 d7 01 00 00    	je     5c10 <fwp_mem_free+0x220>
    5a39:	48 83 ec 38          	sub    $0x38,%rsp
    5a3d:	48 89 f9             	mov    %rdi,%rcx
    5a40:	41 0f b6 38          	movzbl (%r8),%edi
    5a44:	40 80 ff 01          	cmp    $0x1,%dil
    5a48:	74 16                	je     5a60 <fwp_mem_free+0x70>
    5a4a:	40 80 ff 02          	cmp    $0x2,%dil
    5a4e:	0f 84 94 00 00 00    	je     5ae8 <fwp_mem_free+0xf8>
    5a54:	48 83 c4 38          	add    $0x38,%rsp
    5a58:	c3                   	ret
    5a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a60:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a64:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a69:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a6e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a72:	4d 85 d2             	test   %r10,%r10
    5a75:	74 1d                	je     5a94 <fwp_mem_free+0xa4>
    5a77:	0f b7 c1             	movzwl %cx,%eax
    5a7a:	31 d2                	xor    %edx,%edx
    5a7c:	48 f7 f7             	div    %rdi
    5a7f:	49 01 c2             	add    %rax,%r10
    5a82:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a86:	0f 84 44 01 00 00    	je     5bd0 <fwp_mem_free+0x1e0>
    5a8c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a90:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a94:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a9b:	49 63 c1             	movslq %r9d,%rax
    5a9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5aa6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5aab:	f2 0f 58 05 ad 31 06 	addsd  0x631ad(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5ab2:	00 
    5ab3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ab7:	48 8d 05 62 1d 06 00 	lea    0x61d62(%rip),%rax        # 67820 <fwp_heap>
    5abe:	48 01 d0             	add    %rdx,%rax
    5ac1:	48 8b 10             	mov    (%rax),%rdx
    5ac4:	48 f7 d2             	not    %rdx
    5ac7:	48 89 11             	mov    %rdx,(%rcx)
    5aca:	48 89 08             	mov    %rcx,(%rax)
    5acd:	48 29 3d 6c 31 06 00 	sub    %rdi,0x6316c(%rip)        # 68c40 <fwp_heap+0x1420>
    5ad4:	f2 0f 11 05 84 31 06 	movsd  %xmm0,0x63184(%rip)        # 68c60 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	48 83 c4 38          	add    $0x38,%rsp
    5ae0:	c3                   	ret
    5ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae8:	66 31 d2             	xor    %dx,%dx
    5aeb:	48 01 d6             	add    %rdx,%rsi
    5aee:	48 39 f1             	cmp    %rsi,%rcx
    5af1:	0f 85 5d ff ff ff    	jne    5a54 <fwp_mem_free+0x64>
    5af7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5afb:	48 29 15 3e 31 06 00 	sub    %rdx,0x6313e(%rip)        # 68c40 <fwp_heap+0x1420>
    5b02:	48 85 d2             	test   %rdx,%rdx
    5b05:	0f 88 a5 00 00 00    	js     5bb0 <fwp_mem_free+0x1c0>
    5b0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b0f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b14:	f2 0f 58 05 44 31 06 	addsd  0x63144(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5b1b:	00 
    5b1c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b20:	f2 0f 11 05 38 31 06 	movsd  %xmm0,0x63138(%rip)        # 68c60 <fwp_heap+0x1440>
    5b27:	00 
    5b28:	48 85 d2             	test   %rdx,%rdx
    5b2b:	74 0c                	je     5b39 <fwp_mem_free+0x149>
    5b2d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b30:	0f 84 db 00 00 00    	je     5c11 <fwp_mem_free+0x221>
    5b36:	c6 02 00             	movb   $0x0,(%rdx)
    5b39:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b3d:	48 85 c9             	test   %rcx,%rcx
    5b40:	74 3e                	je     5b80 <fwp_mem_free+0x190>
    5b42:	48 8b 15 cf 30 06 00 	mov    0x630cf(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    5b49:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b51:	48 01 d0             	add    %rdx,%rax
    5b54:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b58:	48 89 d6             	mov    %rdx,%rsi
    5b5b:	48 29 c6             	sub    %rax,%rsi
    5b5e:	83 e6 08             	and    $0x8,%esi
    5b61:	74 0d                	je     5b70 <fwp_mem_free+0x180>
    5b63:	c6 00 00             	movb   $0x0,(%rax)
    5b66:	48 83 c0 28          	add    $0x28,%rax
    5b6a:	48 39 c2             	cmp    %rax,%rdx
    5b6d:	74 11                	je     5b80 <fwp_mem_free+0x190>
    5b6f:	90                   	nop
    5b70:	c6 00 00             	movb   $0x0,(%rax)
    5b73:	48 83 c0 50          	add    $0x50,%rax
    5b77:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b7b:	48 39 c2             	cmp    %rax,%rdx
    5b7e:	75 f0                	jne    5b70 <fwp_mem_free+0x180>
    5b80:	48 01 0d c9 30 06 00 	add    %rcx,0x630c9(%rip)        # 68c50 <fwp_heap+0x1430>
    5b87:	4c 3b 0d 82 30 06 00 	cmp    0x63082(%rip),%r9        # 68c10 <fwp_heap+0x13f0>
    5b8e:	73 07                	jae    5b97 <fwp_mem_free+0x1a7>
    5b90:	4c 89 0d 79 30 06 00 	mov    %r9,0x63079(%rip)        # 68c10 <fwp_heap+0x13f0>
    5b97:	4c 3b 0d 6a 30 06 00 	cmp    0x6306a(%rip),%r9        # 68c08 <fwp_heap+0x13e8>
    5b9e:	0f 83 b0 fe ff ff    	jae    5a54 <fwp_mem_free+0x64>
    5ba4:	4c 89 0d 5d 30 06 00 	mov    %r9,0x6305d(%rip)        # 68c08 <fwp_heap+0x13e8>
    5bab:	e9 a4 fe ff ff       	jmp    5a54 <fwp_mem_free+0x64>
    5bb0:	48 89 d1             	mov    %rdx,%rcx
    5bb3:	83 e2 01             	and    $0x1,%edx
    5bb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bba:	48 d1 e9             	shr    $1,%rcx
    5bbd:	48 09 d1             	or     %rdx,%rcx
    5bc0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5bc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5bc9:	e9 46 ff ff ff       	jmp    5b14 <fwp_mem_free+0x124>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	4c 89 d7             	mov    %r10,%rdi
    5bd3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bd8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bdd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5be2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5be6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5beb:	e8 c0 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5bf0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bf5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bfa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c09:	e9 7e fe ff ff       	jmp    5a8c <fwp_mem_free+0x9c>
    5c0e:	66 90                	xchg   %ax,%ax
    5c10:	c3                   	ret
    5c11:	48 89 d7             	mov    %rdx,%rdi
    5c14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c28:	e8 83 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5c2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c41:	e9 f0 fe ff ff       	jmp    5b36 <fwp_mem_free+0x146>
    5c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c4d:	00 00 00 

0000000000005c50 <fwp_heap_alloc_big>:
    5c50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c57:	00 00 40 
    5c5a:	41 57                	push   %r15
    5c5c:	41 56                	push   %r14
    5c5e:	41 55                	push   %r13
    5c60:	41 54                	push   %r12
    5c62:	55                   	push   %rbp
    5c63:	53                   	push   %rbx
    5c64:	48 83 ec 08          	sub    $0x8,%rsp
    5c68:	48 39 f8             	cmp    %rdi,%rax
    5c6b:	0f 82 fa 00 00 00    	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5c71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c78:	49 89 fd             	mov    %rdi,%r13
    5c7b:	41 89 f6             	mov    %esi,%r14d
    5c7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c82:	48 89 ef             	mov    %rbp,%rdi
    5c85:	e8 c6 e1 ff ff       	call   3e50 <fwp_heap_chunks>
    5c8a:	be 01 00 00 00       	mov    $0x1,%esi
    5c8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c93:	49 89 c4             	mov    %rax,%r12
    5c96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c9d:	00 
    5c9e:	48 03 3d 73 2f 06 00 	add    0x62f73(%rip),%rdi        # 68c18 <fwp_heap+0x13f8>
    5ca5:	c6 07 02             	movb   $0x2,(%rdi)
    5ca8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5cac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5caf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cb3:	e8 88 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cb8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cbc:	76 47                	jbe    5d05 <fwp_heap_alloc_big+0xb5>
    5cbe:	4c 01 e5             	add    %r12,%rbp
    5cc1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5cc8:	00 
    5cc9:	4c 8d 3d 50 1b 06 00 	lea    0x61b50(%rip),%r15        # 67820 <fwp_heap>
    5cd0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cd5:	49 c1 e6 03          	shl    $0x3,%r14
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ce7:	31 f6                	xor    %esi,%esi
    5ce9:	48 01 dd             	add    %rbx,%rbp
    5cec:	48 83 c3 28          	add    $0x28,%rbx
    5cf0:	48 89 ef             	mov    %rbp,%rdi
    5cf3:	e8 48 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cf8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cfc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d00:	49 39 de             	cmp    %rbx,%r14
    5d03:	75 db                	jne    5ce0 <fwp_heap_alloc_big+0x90>
    5d05:	49 c1 e4 10          	shl    $0x10,%r12
    5d09:	4c 03 25 c0 2e 06 00 	add    0x62ec0(%rip),%r12        # 68bd0 <fwp_heap+0x13b0>
    5d10:	4c 89 ea             	mov    %r13,%rdx
    5d13:	31 f6                	xor    %esi,%esi
    5d15:	4c 89 e7             	mov    %r12,%rdi
    5d18:	e8 93 d7 ff ff       	call   34b0 <memset@plt>
    5d1d:	4c 89 e8             	mov    %r13,%rax
    5d20:	48 03 05 19 2f 06 00 	add    0x62f19(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5d27:	72 42                	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5d29:	48 39 05 18 2f 06 00 	cmp    %rax,0x62f18(%rip)        # 68c48 <fwp_heap+0x1428>
    5d30:	48 89 05 09 2f 06 00 	mov    %rax,0x62f09(%rip)        # 68c40 <fwp_heap+0x1420>
    5d37:	73 07                	jae    5d40 <fwp_heap_alloc_big+0xf0>
    5d39:	48 89 05 08 2f 06 00 	mov    %rax,0x62f08(%rip)        # 68c48 <fwp_heap+0x1428>
    5d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d44:	4c 89 e0             	mov    %r12,%rax
    5d47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d4c:	f2 0f 58 05 04 2f 06 	addsd  0x62f04(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5d53:	00 
    5d54:	f2 0f 11 05 fc 2e 06 	movsd  %xmm0,0x62efc(%rip)        # 68c58 <fwp_heap+0x1438>
    5d5b:	00 
    5d5c:	48 83 c4 08          	add    $0x8,%rsp
    5d60:	5b                   	pop    %rbx
    5d61:	5d                   	pop    %rbp
    5d62:	41 5c                	pop    %r12
    5d64:	41 5d                	pop    %r13
    5d66:	41 5e                	pop    %r14
    5d68:	41 5f                	pop    %r15
    5d6a:	c3                   	ret
    5d6b:	e8 a0 e0 ff ff       	call   3e10 <fwp_heap_oom>

0000000000005d70 <fwp_heap_alloc_slow>:
    5d70:	53                   	push   %rbx
    5d71:	48 89 f9             	mov    %rdi,%rcx
    5d74:	41 89 f1             	mov    %esi,%r9d
    5d77:	48 83 ec 10          	sub    $0x10,%rsp
    5d7b:	8b 05 43 2e 06 00    	mov    0x62e43(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5d81:	85 c0                	test   %eax,%eax
    5d83:	0f 84 c7 00 00 00    	je     5e50 <fwp_heap_alloc_slow+0xe0>
    5d89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d90:	0f 87 dd 00 00 00    	ja     5e73 <fwp_heap_alloc_slow+0x103>
    5d96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d9a:	48 8d 3d 7f 1a 06 00 	lea    0x61a7f(%rip),%rdi        # 67820 <fwp_heap>
    5da1:	49 63 f1             	movslq %r9d,%rsi
    5da4:	48 c1 e8 04          	shr    $0x4,%rax
    5da8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5daf:	00 00 
    5db1:	41 0f b6 c2          	movzbl %r10b,%eax
    5db5:	4c 89 d2             	mov    %r10,%rdx
    5db8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5dbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5dc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dce:	48 01 f8             	add    %rdi,%rax
    5dd1:	4c 8b 00             	mov    (%rax),%r8
    5dd4:	4d 85 c0             	test   %r8,%r8
    5dd7:	0f 84 ab 00 00 00    	je     5e88 <fwp_heap_alloc_slow+0x118>
    5ddd:	49 8b 10             	mov    (%r8),%rdx
    5de0:	48 f7 d2             	not    %rdx
    5de3:	48 89 10             	mov    %rdx,(%rax)
    5de6:	41 83 f9 01          	cmp    $0x1,%r9d
    5dea:	4c 89 c7             	mov    %r8,%rdi
    5ded:	48 0f 45 cb          	cmovne %rbx,%rcx
    5df1:	31 f6                	xor    %esi,%esi
    5df3:	48 89 ca             	mov    %rcx,%rdx
    5df6:	e8 b5 d6 ff ff       	call   34b0 <memset@plt>
    5dfb:	49 89 c0             	mov    %rax,%r8
    5dfe:	48 89 d8             	mov    %rbx,%rax
    5e01:	48 03 05 38 2e 06 00 	add    0x62e38(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5e08:	0f 82 d9 00 00 00    	jb     5ee7 <fwp_heap_alloc_slow+0x177>
    5e0e:	48 39 05 33 2e 06 00 	cmp    %rax,0x62e33(%rip)        # 68c48 <fwp_heap+0x1428>
    5e15:	48 89 05 24 2e 06 00 	mov    %rax,0x62e24(%rip)        # 68c40 <fwp_heap+0x1420>
    5e1c:	73 07                	jae    5e25 <fwp_heap_alloc_slow+0xb5>
    5e1e:	48 89 05 23 2e 06 00 	mov    %rax,0x62e23(%rip)        # 68c48 <fwp_heap+0x1428>
    5e25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e29:	4c 89 c0             	mov    %r8,%rax
    5e2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e31:	f2 0f 58 05 1f 2e 06 	addsd  0x62e1f(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5e38:	00 
    5e39:	f2 0f 11 05 17 2e 06 	movsd  %xmm0,0x62e17(%rip)        # 68c58 <fwp_heap+0x1438>
    5e40:	00 
    5e41:	48 83 c4 10          	add    $0x10,%rsp
    5e45:	5b                   	pop    %rbx
    5e46:	c3                   	ret
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e58:	e8 53 ef ff ff       	call   4db0 <fwp_heap_init>
    5e5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e6d:	0f 86 23 ff ff ff    	jbe    5d96 <fwp_heap_alloc_slow+0x26>
    5e73:	48 83 c4 10          	add    $0x10,%rsp
    5e77:	44 89 ce             	mov    %r9d,%esi
    5e7a:	48 89 cf             	mov    %rcx,%rdi
    5e7d:	5b                   	pop    %rbx
    5e7e:	e9 cd fd ff ff       	jmp    5c50 <fwp_heap_alloc_big>
    5e83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e8c:	4d 85 c0             	test   %r8,%r8
    5e8f:	74 1f                	je     5eb0 <fwp_heap_alloc_slow+0x140>
    5e91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e95:	4d 29 c3             	sub    %r8,%r11
    5e98:	49 39 db             	cmp    %rbx,%r11
    5e9b:	72 13                	jb     5eb0 <fwp_heap_alloc_slow+0x140>
    5e9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ea1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ea5:	e9 3c ff ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5eb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5eb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5ebb:	44 89 ca             	mov    %r9d,%edx
    5ebe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ec3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ecb:	44 89 d6             	mov    %r10d,%esi
    5ece:	48 01 c7             	add    %rax,%rdi
    5ed1:	e8 6a fa ff ff       	call   5940 <fwp_heap_refill>
    5ed6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5edb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5edf:	49 89 c0             	mov    %rax,%r8
    5ee2:	e9 ff fe ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5ee7:	e8 24 df ff ff       	call   3e10 <fwp_heap_oom>
    5eec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ef0 <fwp_heap_alloc>:
    5ef0:	53                   	push   %rbx
    5ef1:	48 89 fa             	mov    %rdi,%rdx
    5ef4:	48 83 ec 10          	sub    $0x10,%rsp
    5ef8:	8b 1d ea 35 06 00    	mov    0x635ea(%rip),%ebx        # 694e8 <iteration_active>
    5efe:	8b 05 c0 2c 06 00    	mov    0x62cc0(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5f04:	85 db                	test   %ebx,%ebx
    5f06:	0f 85 04 01 00 00    	jne    6010 <fwp_heap_alloc+0x120>
    5f0c:	85 c0                	test   %eax,%eax
    5f0e:	0f 84 ac 01 00 00    	je     60c0 <fwp_heap_alloc+0x1d0>
    5f14:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f1b:	0f 87 9f 01 00 00    	ja     60c0 <fwp_heap_alloc+0x1d0>
    5f21:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f25:	48 8d 05 f4 18 06 00 	lea    0x618f4(%rip),%rax        # 67820 <fwp_heap>
    5f2c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f30:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f37:	00 
    5f38:	48 63 ce             	movslq %esi,%rcx
    5f3b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f42:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f49:	00 
    5f4a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f4e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f52:	48 01 c8             	add    %rcx,%rax
    5f55:	48 8b 08             	mov    (%rax),%rcx
    5f58:	48 85 c9             	test   %rcx,%rcx
    5f5b:	0f 84 ff 00 00 00    	je     6060 <fwp_heap_alloc+0x170>
    5f61:	48 8b 39             	mov    (%rcx),%rdi
    5f64:	48 f7 d7             	not    %rdi
    5f67:	48 89 38             	mov    %rdi,(%rax)
    5f6a:	83 fe 01             	cmp    $0x1,%esi
    5f6d:	48 89 cf             	mov    %rcx,%rdi
    5f70:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f75:	49 0f 45 d0          	cmovne %r8,%rdx
    5f79:	31 f6                	xor    %esi,%esi
    5f7b:	e8 30 d5 ff ff       	call   34b0 <memset@plt>
    5f80:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f85:	48 89 c1             	mov    %rax,%rcx
    5f88:	4c 89 c0             	mov    %r8,%rax
    5f8b:	48 03 05 ae 2c 06 00 	add    0x62cae(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5f92:	0f 82 35 01 00 00    	jb     60cd <fwp_heap_alloc+0x1dd>
    5f98:	48 39 05 a9 2c 06 00 	cmp    %rax,0x62ca9(%rip)        # 68c48 <fwp_heap+0x1428>
    5f9f:	48 89 05 9a 2c 06 00 	mov    %rax,0x62c9a(%rip)        # 68c40 <fwp_heap+0x1420>
    5fa6:	73 07                	jae    5faf <fwp_heap_alloc+0xbf>
    5fa8:	48 89 05 99 2c 06 00 	mov    %rax,0x62c99(%rip)        # 68c48 <fwp_heap+0x1428>
    5faf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fb3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fb8:	f2 0f 58 05 98 2c 06 	addsd  0x62c98(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5fbf:	00 
    5fc0:	f2 0f 11 05 90 2c 06 	movsd  %xmm0,0x62c90(%rip)        # 68c58 <fwp_heap+0x1438>
    5fc7:	00 
    5fc8:	85 db                	test   %ebx,%ebx
    5fca:	74 33                	je     5fff <fwp_heap_alloc+0x10f>
    5fcc:	48 8b 05 6d 2c 06 00 	mov    0x62c6d(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5fd3:	48 85 c0             	test   %rax,%rax
    5fd6:	0f 88 ac 00 00 00    	js     6088 <fwp_heap_alloc+0x198>
    5fdc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fe0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fe5:	f2 0f 5c 05 db 34 06 	subsd  0x634db(%rip),%xmm0        # 694c8 <iteration_start_charge>
    5fec:	00 
    5fed:	66 0f 2f 05 cb 34 06 	comisd 0x634cb(%rip),%xmm0        # 694c0 <iteration_peak>
    5ff4:	00 
    5ff5:	76 08                	jbe    5fff <fwp_heap_alloc+0x10f>
    5ff7:	f2 0f 11 05 c1 34 06 	movsd  %xmm0,0x634c1(%rip)        # 694c0 <iteration_peak>
    5ffe:	00 
    5fff:	48 83 c4 10          	add    $0x10,%rsp
    6003:	48 89 c8             	mov    %rcx,%rax
    6006:	5b                   	pop    %rbx
    6007:	c3                   	ret
    6008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    600f:	00 
    6010:	85 f6                	test   %esi,%esi
    6012:	74 34                	je     6048 <fwp_heap_alloc+0x158>
    6014:	48 83 05 c4 34 06 00 	addq   $0x1,0x634c4(%rip)        # 694e0 <iteration_requests>
    601b:	01 
    601c:	48 01 3d b5 34 06 00 	add    %rdi,0x634b5(%rip)        # 694d8 <iteration_bytes>
    6023:	85 c0                	test   %eax,%eax
    6025:	74 0d                	je     6034 <fwp_heap_alloc+0x144>
    6027:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    602e:	0f 86 ed fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6034:	48 89 d7             	mov    %rdx,%rdi
    6037:	e8 34 fd ff ff       	call   5d70 <fwp_heap_alloc_slow>
    603c:	48 89 c1             	mov    %rax,%rcx
    603f:	eb 8b                	jmp    5fcc <fwp_heap_alloc+0xdc>
    6041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6048:	85 c0                	test   %eax,%eax
    604a:	74 0d                	je     6059 <fwp_heap_alloc+0x169>
    604c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6053:	0f 86 c8 fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6059:	31 f6                	xor    %esi,%esi
    605b:	eb d7                	jmp    6034 <fwp_heap_alloc+0x144>
    605d:	0f 1f 00             	nopl   (%rax)
    6060:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6064:	48 85 c9             	test   %rcx,%rcx
    6067:	74 0c                	je     6075 <fwp_heap_alloc+0x185>
    6069:	48 8b 78 10          	mov    0x10(%rax),%rdi
    606d:	48 29 cf             	sub    %rcx,%rdi
    6070:	4c 39 c7             	cmp    %r8,%rdi
    6073:	73 3b                	jae    60b0 <fwp_heap_alloc+0x1c0>
    6075:	48 89 d7             	mov    %rdx,%rdi
    6078:	e8 f3 fc ff ff       	call   5d70 <fwp_heap_alloc_slow>
    607d:	48 89 c1             	mov    %rax,%rcx
    6080:	e9 43 ff ff ff       	jmp    5fc8 <fwp_heap_alloc+0xd8>
    6085:	0f 1f 00             	nopl   (%rax)
    6088:	48 89 c2             	mov    %rax,%rdx
    608b:	83 e0 01             	and    $0x1,%eax
    608e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6092:	48 d1 ea             	shr    $1,%rdx
    6095:	48 09 c2             	or     %rax,%rdx
    6098:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    609d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60a1:	e9 3f ff ff ff       	jmp    5fe5 <fwp_heap_alloc+0xf5>
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60b4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60b8:	e9 ad fe ff ff       	jmp    5f6a <fwp_heap_alloc+0x7a>
    60bd:	0f 1f 00             	nopl   (%rax)
    60c0:	48 83 c4 10          	add    $0x10,%rsp
    60c4:	48 89 d7             	mov    %rdx,%rdi
    60c7:	5b                   	pop    %rbx
    60c8:	e9 a3 fc ff ff       	jmp    5d70 <fwp_heap_alloc_slow>
    60cd:	e8 3e dd ff ff       	call   3e10 <fwp_heap_oom>
    60d2:	0f 1f 00             	nopl   (%rax)
    60d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60dc:	00 00 00 00 

00000000000060e0 <fwp_data.part.0.constprop.0>:
    60e0:	41 56                	push   %r14
    60e2:	8b 05 dc 2a 06 00    	mov    0x62adc(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    60e8:	41 89 fe             	mov    %edi,%r14d
    60eb:	41 55                	push   %r13
    60ed:	44 8b 2d f4 33 06 00 	mov    0x633f4(%rip),%r13d        # 694e8 <iteration_active>
    60f4:	41 54                	push   %r12
    60f6:	49 89 f4             	mov    %rsi,%r12
    60f9:	55                   	push   %rbp
    60fa:	53                   	push   %rbx
    60fb:	45 85 ed             	test   %r13d,%r13d
    60fe:	0f 84 1c 01 00 00    	je     6220 <fwp_data.part.0.constprop.0+0x140>
    6104:	48 83 05 d4 33 06 00 	addq   $0x1,0x633d4(%rip)        # 694e0 <iteration_requests>
    610b:	01 
    610c:	48 83 05 c4 33 06 00 	addq   $0x18,0x633c4(%rip)        # 694d8 <iteration_bytes>
    6113:	18 
    6114:	85 c0                	test   %eax,%eax
    6116:	0f 84 8c 01 00 00    	je     62a8 <fwp_data.part.0.constprop.0+0x1c8>
    611c:	0f b6 05 9f 26 06 00 	movzbl 0x6269f(%rip),%eax        # 687c2 <fwp_heap+0xfa2>
    6123:	48 8d 15 f6 16 06 00 	lea    0x616f6(%rip),%rdx        # 67820 <fwp_heap>
    612a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6131:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6135:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6139:	48 8b 18             	mov    (%rax),%rbx
    613c:	48 85 db             	test   %rbx,%rbx
    613f:	0f 84 fb 00 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x160>
    6145:	48 8b 13             	mov    (%rbx),%rdx
    6148:	48 f7 d2             	not    %rdx
    614b:	48 89 10             	mov    %rdx,(%rax)
    614e:	48 83 fd 18          	cmp    $0x18,%rbp
    6152:	76 1b                	jbe    616f <fwp_data.part.0.constprop.0+0x8f>
    6154:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6158:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    615c:	31 f6                	xor    %esi,%esi
    615e:	48 c1 e8 03          	shr    $0x3,%rax
    6162:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6169:	00 
    616a:	e8 41 d3 ff ff       	call   34b0 <memset@plt>
    616f:	48 89 e8             	mov    %rbp,%rax
    6172:	48 03 05 c7 2a 06 00 	add    0x62ac7(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    6179:	0f 82 3d 01 00 00    	jb     62bc <fwp_data.part.0.constprop.0+0x1dc>
    617f:	48 39 05 c2 2a 06 00 	cmp    %rax,0x62ac2(%rip)        # 68c48 <fwp_heap+0x1428>
    6186:	48 89 05 b3 2a 06 00 	mov    %rax,0x62ab3(%rip)        # 68c40 <fwp_heap+0x1420>
    618d:	73 07                	jae    6196 <fwp_data.part.0.constprop.0+0xb6>
    618f:	48 89 05 b2 2a 06 00 	mov    %rax,0x62ab2(%rip)        # 68c48 <fwp_heap+0x1428>
    6196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    619a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    619f:	f2 0f 58 05 b1 2a 06 	addsd  0x62ab1(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    61a6:	00 
    61a7:	f2 0f 11 05 a9 2a 06 	movsd  %xmm0,0x62aa9(%rip)        # 68c58 <fwp_heap+0x1438>
    61ae:	00 
    61af:	45 85 ed             	test   %r13d,%r13d
    61b2:	74 33                	je     61e7 <fwp_data.part.0.constprop.0+0x107>
    61b4:	48 8b 05 85 2a 06 00 	mov    0x62a85(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    61bb:	48 85 c0             	test   %rax,%rax
    61be:	0f 88 a4 00 00 00    	js     6268 <fwp_data.part.0.constprop.0+0x188>
    61c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61c8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61cd:	f2 0f 5c 05 f3 32 06 	subsd  0x632f3(%rip),%xmm0        # 694c8 <iteration_start_charge>
    61d4:	00 
    61d5:	66 0f 2f 05 e3 32 06 	comisd 0x632e3(%rip),%xmm0        # 694c0 <iteration_peak>
    61dc:	00 
    61dd:	76 08                	jbe    61e7 <fwp_data.part.0.constprop.0+0x107>
    61df:	f2 0f 11 05 d9 32 06 	movsd  %xmm0,0x632d9(%rip)        # 694c0 <iteration_peak>
    61e6:	00 
    61e7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ec:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61f1:	66 0f 6e c8          	movd   %eax,%xmm1
    61f5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61f9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61fd:	49 8b 04 24          	mov    (%r12),%rax
    6201:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6205:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    620a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    620e:	48 89 d8             	mov    %rbx,%rax
    6211:	5b                   	pop    %rbx
    6212:	5d                   	pop    %rbp
    6213:	41 5c                	pop    %r12
    6215:	41 5d                	pop    %r13
    6217:	41 5e                	pop    %r14
    6219:	c3                   	ret
    621a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6220:	85 c0                	test   %eax,%eax
    6222:	0f 85 f4 fe ff ff    	jne    611c <fwp_data.part.0.constprop.0+0x3c>
    6228:	31 f6                	xor    %esi,%esi
    622a:	bf 18 00 00 00       	mov    $0x18,%edi
    622f:	e8 bc fc ff ff       	call   5ef0 <fwp_heap_alloc>
    6234:	48 89 c3             	mov    %rax,%rbx
    6237:	eb ae                	jmp    61e7 <fwp_data.part.0.constprop.0+0x107>
    6239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6240:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6244:	48 85 db             	test   %rbx,%rbx
    6247:	74 47                	je     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6249:	48 8b 50 10          	mov    0x10(%rax),%rdx
    624d:	48 29 da             	sub    %rbx,%rdx
    6250:	48 39 ea             	cmp    %rbp,%rdx
    6253:	72 3b                	jb     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6255:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6259:	48 89 50 08          	mov    %rdx,0x8(%rax)
    625d:	e9 ec fe ff ff       	jmp    614e <fwp_data.part.0.constprop.0+0x6e>
    6262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6268:	48 89 c2             	mov    %rax,%rdx
    626b:	83 e0 01             	and    $0x1,%eax
    626e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6272:	48 d1 ea             	shr    $1,%rdx
    6275:	48 09 c2             	or     %rax,%rdx
    6278:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    627d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6281:	e9 47 ff ff ff       	jmp    61cd <fwp_data.part.0.constprop.0+0xed>
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	31 f6                	xor    %esi,%esi
    6292:	bf 18 00 00 00       	mov    $0x18,%edi
    6297:	e8 54 fc ff ff       	call   5ef0 <fwp_heap_alloc>
    629c:	48 89 c3             	mov    %rax,%rbx
    629f:	e9 0b ff ff ff       	jmp    61af <fwp_data.part.0.constprop.0+0xcf>
    62a4:	0f 1f 40 00          	nopl   0x0(%rax)
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 3c fc ff ff       	call   5ef0 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	e9 f8 fe ff ff       	jmp    61b4 <fwp_data.part.0.constprop.0+0xd4>
    62bc:	e8 4f db ff ff       	call   3e10 <fwp_heap_oom>
    62c1:	0f 1f 40 00          	nopl   0x0(%rax)
    62c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62cc:	00 00 00 00 

00000000000062d0 <fwp_p_ad_push>:
    62d0:	41 57                	push   %r15
    62d2:	41 56                	push   %r14
    62d4:	41 55                	push   %r13
    62d6:	49 89 d5             	mov    %rdx,%r13
    62d9:	41 54                	push   %r12
    62db:	49 89 fc             	mov    %rdi,%r12
    62de:	55                   	push   %rbp
    62df:	53                   	push   %rbx
    62e0:	48 83 ec 38          	sub    $0x38,%rsp
    62e4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    62e9:	48 85 ff             	test   %rdi,%rdi
    62ec:	79 09                	jns    62f7 <fwp_p_ad_push+0x27>
    62ee:	48 85 d2             	test   %rdx,%rdx
    62f1:	0f 88 a9 01 00 00    	js     64a0 <fwp_p_ad_push+0x1d0>
    62f7:	48 89 f8             	mov    %rdi,%rax
    62fa:	48 89 0c 24          	mov    %rcx,(%rsp)
    62fe:	48 09 d0             	or     %rdx,%rax
    6301:	0f 89 71 01 00 00    	jns    6478 <fwp_p_ad_push+0x1a8>
    6307:	48 89 f8             	mov    %rdi,%rax
    630a:	48 c1 f8 20          	sar    $0x20,%rax
    630e:	48 85 ff             	test   %rdi,%rdi
    6311:	79 24                	jns    6337 <fwp_p_ad_push+0x67>
    6313:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6318:	48 89 d0             	mov    %rdx,%rax
    631b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6322:	00 
    6323:	49 89 d4             	mov    %rdx,%r12
    6326:	48 c1 f8 20          	sar    $0x20,%rax
    632a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6331:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6337:	48 89 c7             	mov    %rax,%rdi
    633a:	e8 d1 e3 ff ff       	call   4710 <fwp_tape_of>
    633f:	48 89 c3             	mov    %rax,%rbx
    6342:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6347:	0f 85 6e 02 00 00    	jne    65bb <fwp_p_ad_push+0x2eb>
    634d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6351:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6358:	0f 8f 51 02 00 00    	jg     65af <fwp_p_ad_push+0x2df>
    635e:	44 89 e0             	mov    %r12d,%eax
    6361:	4c 39 f8             	cmp    %r15,%rax
    6364:	0f 8d 39 02 00 00    	jge    65a3 <fwp_p_ad_push+0x2d3>
    636a:	4d 85 ed             	test   %r13,%r13
    636d:	78 0c                	js     637b <fwp_p_ad_push+0xab>
    636f:	44 89 e8             	mov    %r13d,%eax
    6372:	4c 39 f8             	cmp    %r15,%rax
    6375:	0f 8d 28 02 00 00    	jge    65a3 <fwp_p_ad_push+0x2d3>
    637b:	4d 89 fe             	mov    %r15,%r14
    637e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6382:	49 8d 46 01          	lea    0x1(%r14),%rax
    6386:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    638c:	0f 87 1d 02 00 00    	ja     65af <fwp_p_ad_push+0x2df>
    6392:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6396:	48 39 e8             	cmp    %rbp,%rax
    6399:	0f 8e 31 01 00 00    	jle    64d0 <fwp_p_ad_push+0x200>
    639f:	48 85 ed             	test   %rbp,%rbp
    63a2:	ba 40 00 00 00       	mov    $0x40,%edx
    63a7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63ab:	48 39 e8             	cmp    %rbp,%rax
    63ae:	7e 20                	jle    63d0 <fwp_p_ad_push+0x100>
    63b0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63b7:	0f 8f 03 01 00 00    	jg     64c0 <fwp_p_ad_push+0x1f0>
    63bd:	48 01 ed             	add    %rbp,%rbp
    63c0:	48 39 e8             	cmp    %rbp,%rax
    63c3:	7f eb                	jg     63b0 <fwp_p_ad_push+0xe0>
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 
    63d0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63d7:	00 
    63d8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63dc:	ba 01 00 00 00       	mov    $0x1,%edx
    63e1:	48 89 c6             	mov    %rax,%rsi
    63e4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    63e9:	e8 82 ed ff ff       	call   5170 <ad_raw_realloc>
    63ee:	48 85 c0             	test   %rax,%rax
    63f1:	0f 84 d0 01 00 00    	je     65c7 <fwp_p_ad_push+0x2f7>
    63f7:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    63fb:	48 89 ee             	mov    %rbp,%rsi
    63fe:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6402:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6406:	48 c1 e6 04          	shl    $0x4,%rsi
    640a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    640e:	ba 02 00 00 00       	mov    $0x2,%edx
    6413:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6417:	e8 54 ed ff ff       	call   5170 <ad_raw_realloc>
    641c:	48 85 c0             	test   %rax,%rax
    641f:	0f 84 a2 01 00 00    	je     65c7 <fwp_p_ad_push+0x2f7>
    6425:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6429:	48 89 43 30          	mov    %rax,0x30(%rbx)
    642d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6434:	00 
    6435:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    643c:	00 
    643d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6444:	00 
    6445:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    6449:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    644e:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6452:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6456:	4d 85 f6             	test   %r14,%r14
    6459:	0f 85 e5 00 00 00    	jne    6544 <fwp_p_ad_push+0x274>
    645f:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6463:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6467:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    646b:	48 01 d1             	add    %rdx,%rcx
    646e:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6472:	eb 7c                	jmp    64f0 <fwp_p_ad_push+0x220>
    6474:	0f 1f 40 00          	nopl   0x0(%rax)
    6478:	48 89 d0             	mov    %rdx,%rax
    647b:	48 c1 ff 20          	sar    $0x20,%rdi
    647f:	48 c1 f8 20          	sar    $0x20,%rax
    6483:	48 39 c7             	cmp    %rax,%rdi
    6486:	0f 84 ab fe ff ff    	je     6337 <fwp_p_ad_push+0x67>
    648c:	48 8d 3d 3d 55 00 00 	lea    0x553d(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    6493:	e8 98 df ff ff       	call   4430 <fwp_trap>
    6498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    649f:	00 
    64a0:	48 83 c4 38          	add    $0x38,%rsp
    64a4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64ab:	5b                   	pop    %rbx
    64ac:	5d                   	pop    %rbp
    64ad:	41 5c                	pop    %r12
    64af:	41 5d                	pop    %r13
    64b1:	41 5e                	pop    %r14
    64b3:	41 5f                	pop    %r15
    64b5:	c3                   	ret
    64b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64bd:	00 00 00 
    64c0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64c5:	e9 06 ff ff ff       	jmp    63d0 <fwp_p_ad_push+0x100>
    64ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64d0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64d4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64d8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64df:	00 
    64e0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64e7:	00 
    64e8:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    64ec:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    64f0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64f6:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    64fa:	4d 85 ed             	test   %r13,%r13
    64fd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6502:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6508:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    650f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6513:	49 8d 47 01          	lea    0x1(%r15),%rax
    6517:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    651b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6521:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6525:	48 83 c4 38          	add    $0x38,%rsp
    6529:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6530:	ff ff ff 
    6533:	4c 21 e0             	and    %r12,%rax
    6536:	5b                   	pop    %rbx
    6537:	5d                   	pop    %rbp
    6538:	4c 09 f8             	or     %r15,%rax
    653b:	41 5c                	pop    %r12
    653d:	41 5d                	pop    %r13
    653f:	41 5e                	pop    %r14
    6541:	41 5f                	pop    %r15
    6543:	c3                   	ret
    6544:	4c 89 ca             	mov    %r9,%rdx
    6547:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    654c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6551:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6556:	e8 95 d0 ff ff       	call   35f0 <memmove@plt>
    655b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6560:	4c 03 73 30          	add    0x30(%rbx),%r14
    6564:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6569:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    656d:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6571:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    6576:	48 03 7b 20          	add    0x20(%rbx),%rdi
    657a:	4c 89 d2             	mov    %r10,%rdx
    657d:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6582:	e8 69 d0 ff ff       	call   35f0 <memmove@plt>
    6587:	48 8b 43 30          	mov    0x30(%rbx),%rax
    658b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    658f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6594:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6599:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    659e:	e9 c0 fe ff ff       	jmp    6463 <fwp_p_ad_push+0x193>
    65a3:	48 8d 3d 18 4c 00 00 	lea    0x4c18(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    65aa:	e8 81 de ff ff       	call   4430 <fwp_trap>
    65af:	48 8d 3d f1 4b 00 00 	lea    0x4bf1(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    65b6:	e8 75 de ff ff       	call   4430 <fwp_trap>
    65bb:	48 8d 3d 56 54 00 00 	lea    0x5456(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    65c2:	e8 69 de ff ff       	call   4430 <fwp_trap>
    65c7:	48 89 df             	mov    %rbx,%rdi
    65ca:	e8 a1 d6 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    65cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65d3:	48 85 ff             	test   %rdi,%rdi
    65d6:	74 05                	je     65dd <fwp_p_ad_push+0x30d>
    65d8:	e8 d3 ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65dd:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    65e1:	48 85 ff             	test   %rdi,%rdi
    65e4:	74 05                	je     65eb <fwp_p_ad_push+0x31b>
    65e6:	e8 c5 ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65eb:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    65ef:	48 85 ff             	test   %rdi,%rdi
    65f2:	74 05                	je     65f9 <fwp_p_ad_push+0x329>
    65f4:	e8 b7 ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65f9:	31 c9                	xor    %ecx,%ecx
    65fb:	31 c0                	xor    %eax,%eax
    65fd:	31 d2                	xor    %edx,%edx
    65ff:	be 01 00 00 00       	mov    $0x1,%esi
    6604:	89 53 04             	mov    %edx,0x4(%rbx)
    6607:	66 0f ef c0          	pxor   %xmm0,%xmm0
    660b:	ba 13 00 00 00       	mov    $0x13,%edx
    6610:	48 8d 3d f1 49 00 00 	lea    0x49f1(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6617:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    661b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    661f:	48 8b 0d 1a 8a 00 00 	mov    0x8a1a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    6626:	48 89 43 40          	mov    %rax,0x40(%rbx)
    662a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    662e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6632:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6636:	e8 25 d0 ff ff       	call   3660 <fwrite@plt>
    663b:	31 ff                	xor    %edi,%edi
    663d:	e8 5e cf ff ff       	call   35a0 <fflush@plt>
    6642:	bf 66 00 00 00       	mov    $0x66,%edi
    6647:	e8 34 d0 ff ff       	call   3680 <_Exit@plt>
    664c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006650 <w120>:
    6650:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6654:	41 55                	push   %r13
    6656:	48 89 fa             	mov    %rdi,%rdx
    6659:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    665d:	41 54                	push   %r12
    665f:	49 89 fc             	mov    %rdi,%r12
    6662:	55                   	push   %rbp
    6663:	53                   	push   %rbx
    6664:	48 89 f3             	mov    %rsi,%rbx
    6667:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    666c:	48 89 f1             	mov    %rsi,%rcx
    666f:	48 83 ec 28          	sub    $0x28,%rsp
    6673:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6679:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    667f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6685:	e8 46 fc ff ff       	call   62d0 <fwp_p_ad_push>
    668a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6690:	48 89 da             	mov    %rbx,%rdx
    6693:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6699:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66a0:	00 f0 3f 
    66a3:	48 89 c7             	mov    %rax,%rdi
    66a6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66ad:	00 f0 bf 
    66b0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66b5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66bb:	e8 10 fc ff ff       	call   62d0 <fwp_p_ad_push>
    66c0:	f2 0f 10 05 58 56 00 	movsd  0x5658(%rip),%xmm0        # bd20 <msg.4+0xb0>
    66c7:	00 
    66c8:	4c 89 e7             	mov    %r12,%rdi
    66cb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66d1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66d8:	00 f0 3f 
    66db:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    66e2:	49 89 c5             	mov    %rax,%r13
    66e5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66ec:	00 f0 bf 
    66ef:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    66f4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66fa:	e8 d1 fb ff ff       	call   62d0 <fwp_p_ad_push>
    66ff:	48 89 e9             	mov    %rbp,%rcx
    6702:	4c 89 ea             	mov    %r13,%rdx
    6705:	48 89 ee             	mov    %rbp,%rsi
    6708:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    670e:	4c 89 ef             	mov    %r13,%rdi
    6711:	49 89 c4             	mov    %rax,%r12
    6714:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6718:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    671e:	e8 ad fb ff ff       	call   62d0 <fwp_p_ad_push>
    6723:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6729:	f2 0f 59 1d f7 55 00 	mulsd  0x55f7(%rip),%xmm3        # bd28 <msg.4+0xb8>
    6730:	00 
    6731:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6738:	00 59 40 
    673b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6740:	48 89 c2             	mov    %rax,%rdx
    6743:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    674a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6750:	e8 7b fb ff ff       	call   62d0 <fwp_p_ad_push>
    6755:	48 89 d9             	mov    %rbx,%rcx
    6758:	4c 89 e2             	mov    %r12,%rdx
    675b:	48 89 de             	mov    %rbx,%rsi
    675e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6764:	4c 89 e7             	mov    %r12,%rdi
    6767:	48 89 c5             	mov    %rax,%rbp
    676a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    676e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6774:	e8 57 fb ff ff       	call   62d0 <fwp_p_ad_push>
    6779:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    677f:	48 89 ea             	mov    %rbp,%rdx
    6782:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6788:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    678f:	00 f0 3f 
    6792:	48 89 c7             	mov    %rax,%rdi
    6795:	48 89 ce             	mov    %rcx,%rsi
    6798:	66 48 0f 7e db       	movq   %xmm3,%rbx
    679d:	e8 2e fb ff ff       	call   62d0 <fwp_p_ad_push>
    67a2:	48 83 c4 28          	add    $0x28,%rsp
    67a6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67ab:	5b                   	pop    %rbx
    67ac:	5d                   	pop    %rbp
    67ad:	41 5c                	pop    %r12
    67af:	41 5d                	pop    %r13
    67b1:	c3                   	ret
    67b2:	0f 1f 00             	nopl   (%rax)
    67b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67bc:	00 00 00 00 

00000000000067c0 <fwp_rc_share>:
    67c0:	48 8b 05 31 24 06 00 	mov    0x62431(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    67c7:	48 2b 3d 02 24 06 00 	sub    0x62402(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    67ce:	48 c1 e0 10          	shl    $0x10,%rax
    67d2:	48 39 c7             	cmp    %rax,%rdi
    67d5:	73 4a                	jae    6821 <fwp_rc_share+0x61>
    67d7:	48 89 f8             	mov    %rdi,%rax
    67da:	48 c1 e8 10          	shr    $0x10,%rax
    67de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67e2:	48 8b 05 2f 24 06 00 	mov    0x6242f(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    67e9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    67ed:	48 8b 50 20          	mov    0x20(%rax),%rdx
    67f1:	48 85 d2             	test   %rdx,%rdx
    67f4:	74 2b                	je     6821 <fwp_rc_share+0x61>
    67f6:	0f b6 08             	movzbl (%rax),%ecx
    67f9:	80 f9 02             	cmp    $0x2,%cl
    67fc:	74 2a                	je     6828 <fwp_rc_share+0x68>
    67fe:	80 f9 01             	cmp    $0x1,%cl
    6801:	75 1e                	jne    6821 <fwp_rc_share+0x61>
    6803:	8b 48 18             	mov    0x18(%rax),%ecx
    6806:	0f b7 ff             	movzwl %di,%edi
    6809:	8b 40 1c             	mov    0x1c(%rax),%eax
    680c:	48 0f af f9          	imul   %rcx,%rdi
    6810:	48 c1 ef 20          	shr    $0x20,%rdi
    6814:	48 39 c7             	cmp    %rax,%rdi
    6817:	73 08                	jae    6821 <fwp_rc_share+0x61>
    6819:	48 01 fa             	add    %rdi,%rdx
    681c:	80 3a 00             	cmpb   $0x0,(%rdx)
    681f:	75 0d                	jne    682e <fwp_rc_share+0x6e>
    6821:	c3                   	ret
    6822:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6828:	66 85 ff             	test   %di,%di
    682b:	74 ef                	je     681c <fwp_rc_share+0x5c>
    682d:	c3                   	ret
    682e:	50                   	push   %rax
    682f:	48 8d 3d 12 52 00 00 	lea    0x5212(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    6836:	e8 f5 db ff ff       	call   4430 <fwp_trap>
    683b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006840 <fwp_rc_free_obj>:
    6840:	48 8b 15 b1 23 06 00 	mov    0x623b1(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6847:	48 89 f8             	mov    %rdi,%rax
    684a:	48 2b 05 7f 23 06 00 	sub    0x6237f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6851:	48 c1 e2 10          	shl    $0x10,%rdx
    6855:	48 39 d0             	cmp    %rdx,%rax
    6858:	73 5b                	jae    68b5 <fwp_rc_free_obj+0x75>
    685a:	48 89 c2             	mov    %rax,%rdx
    685d:	48 c1 ea 10          	shr    $0x10,%rdx
    6861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6865:	48 8b 15 ac 23 06 00 	mov    0x623ac(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    686c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6870:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6874:	48 85 c9             	test   %rcx,%rcx
    6877:	74 3c                	je     68b5 <fwp_rc_free_obj+0x75>
    6879:	0f b6 32             	movzbl (%rdx),%esi
    687c:	40 80 fe 02          	cmp    $0x2,%sil
    6880:	74 2e                	je     68b0 <fwp_rc_free_obj+0x70>
    6882:	40 80 fe 01          	cmp    $0x1,%sil
    6886:	75 2d                	jne    68b5 <fwp_rc_free_obj+0x75>
    6888:	8b 72 18             	mov    0x18(%rdx),%esi
    688b:	0f b7 c0             	movzwl %ax,%eax
    688e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6891:	48 0f af c6          	imul   %rsi,%rax
    6895:	48 c1 e8 20          	shr    $0x20,%rax
    6899:	48 39 d0             	cmp    %rdx,%rax
    689c:	73 17                	jae    68b5 <fwp_rc_free_obj+0x75>
    689e:	48 01 c1             	add    %rax,%rcx
    68a1:	80 39 01             	cmpb   $0x1,(%rcx)
    68a4:	75 0f                	jne    68b5 <fwp_rc_free_obj+0x75>
    68a6:	e9 45 f1 ff ff       	jmp    59f0 <fwp_mem_free>
    68ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68b0:	66 85 c0             	test   %ax,%ax
    68b3:	74 ec                	je     68a1 <fwp_rc_free_obj+0x61>
    68b5:	c3                   	ret
    68b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68bd:	00 00 00 

00000000000068c0 <fwp_rc_dup>:
    68c0:	f3 0f 1e fa          	endbr64
    68c4:	48 8b 05 2d 23 06 00 	mov    0x6232d(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    68cb:	48 2b 3d fe 22 06 00 	sub    0x622fe(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    68d2:	48 c1 e0 10          	shl    $0x10,%rax
    68d6:	48 39 c7             	cmp    %rax,%rdi
    68d9:	73 60                	jae    693b <fwp_rc_dup+0x7b>
    68db:	48 89 f8             	mov    %rdi,%rax
    68de:	48 c1 e8 10          	shr    $0x10,%rax
    68e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68e6:	48 8b 05 2b 23 06 00 	mov    0x6232b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    68ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    68f1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    68f5:	48 85 c0             	test   %rax,%rax
    68f8:	74 41                	je     693b <fwp_rc_dup+0x7b>
    68fa:	0f b6 0a             	movzbl (%rdx),%ecx
    68fd:	80 f9 02             	cmp    $0x2,%cl
    6900:	74 3e                	je     6940 <fwp_rc_dup+0x80>
    6902:	80 f9 01             	cmp    $0x1,%cl
    6905:	75 34                	jne    693b <fwp_rc_dup+0x7b>
    6907:	8b 4a 18             	mov    0x18(%rdx),%ecx
    690a:	0f b7 ff             	movzwl %di,%edi
    690d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6910:	48 0f af f9          	imul   %rcx,%rdi
    6914:	48 c1 ef 20          	shr    $0x20,%rdi
    6918:	48 39 d7             	cmp    %rdx,%rdi
    691b:	73 1e                	jae    693b <fwp_rc_dup+0x7b>
    691d:	48 01 f8             	add    %rdi,%rax
    6920:	0f b6 10             	movzbl (%rax),%edx
    6923:	84 d2                	test   %dl,%dl
    6925:	74 14                	je     693b <fwp_rc_dup+0x7b>
    6927:	8b 0d bb 2b 06 00    	mov    0x62bbb(%rip),%ecx        # 694e8 <iteration_active>
    692d:	85 c9                	test   %ecx,%ecx
    692f:	75 1f                	jne    6950 <fwp_rc_dup+0x90>
    6931:	80 fa fd             	cmp    $0xfd,%dl
    6934:	77 2a                	ja     6960 <fwp_rc_dup+0xa0>
    6936:	83 c2 01             	add    $0x1,%edx
    6939:	88 10                	mov    %dl,(%rax)
    693b:	c3                   	ret
    693c:	0f 1f 40 00          	nopl   0x0(%rax)
    6940:	66 85 ff             	test   %di,%di
    6943:	74 db                	je     6920 <fwp_rc_dup+0x60>
    6945:	c3                   	ret
    6946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    694d:	00 00 00 
    6950:	48 83 05 78 2b 06 00 	addq   $0x1,0x62b78(%rip)        # 694d0 <iteration_retains>
    6957:	01 
    6958:	eb d7                	jmp    6931 <fwp_rc_dup+0x71>
    695a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6960:	48 89 c7             	mov    %rax,%rdi
    6963:	e9 28 ed ff ff       	jmp    5690 <fwp_rc_wide_dup>
    6968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    696f:	00 

0000000000006970 <fwp_owned_entry173>:
    6970:	f3 0f 1e fa          	endbr64
    6974:	48 83 ec 38          	sub    $0x38,%rsp
    6978:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    697d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6984:	00 00 
    6986:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    698b:	31 c0                	xor    %eax,%eax
    698d:	48 8b 07             	mov    (%rdi),%rax
    6990:	48 03 47 10          	add    0x10(%rdi),%rax
    6994:	0f 80 c2 00 00 00    	jo     6a5c <fwp_owned_entry173+0xec>
    699a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    699f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    69a4:	31 ff                	xor    %edi,%edi
    69a6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    69aa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    69af:	e8 2c f7 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    69b4:	48 8b 15 3d 22 06 00 	mov    0x6223d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    69bb:	48 89 c6             	mov    %rax,%rsi
    69be:	48 2b 05 0b 22 06 00 	sub    0x6220b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    69c5:	48 c1 e2 10          	shl    $0x10,%rdx
    69c9:	48 39 d0             	cmp    %rdx,%rax
    69cc:	73 4f                	jae    6a1d <fwp_owned_entry173+0xad>
    69ce:	48 89 c2             	mov    %rax,%rdx
    69d1:	48 c1 ea 10          	shr    $0x10,%rdx
    69d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69d9:	48 8b 15 38 22 06 00 	mov    0x62238(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    69e0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69e4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69e8:	48 85 d2             	test   %rdx,%rdx
    69eb:	74 30                	je     6a1d <fwp_owned_entry173+0xad>
    69ed:	0f b6 39             	movzbl (%rcx),%edi
    69f0:	40 80 ff 02          	cmp    $0x2,%dil
    69f4:	74 42                	je     6a38 <fwp_owned_entry173+0xc8>
    69f6:	40 80 ff 01          	cmp    $0x1,%dil
    69fa:	75 21                	jne    6a1d <fwp_owned_entry173+0xad>
    69fc:	8b 79 18             	mov    0x18(%rcx),%edi
    69ff:	0f b7 c0             	movzwl %ax,%eax
    6a02:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a05:	48 0f af c7          	imul   %rdi,%rax
    6a09:	48 c1 e8 20          	shr    $0x20,%rax
    6a0d:	48 39 c8             	cmp    %rcx,%rax
    6a10:	73 0b                	jae    6a1d <fwp_owned_entry173+0xad>
    6a12:	48 01 c2             	add    %rax,%rdx
    6a15:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a18:	74 26                	je     6a40 <fwp_owned_entry173+0xd0>
    6a1a:	c6 02 01             	movb   $0x1,(%rdx)
    6a1d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a29:	00 00 
    6a2b:	75 34                	jne    6a61 <fwp_owned_entry173+0xf1>
    6a2d:	48 89 f0             	mov    %rsi,%rax
    6a30:	48 83 c4 38          	add    $0x38,%rsp
    6a34:	c3                   	ret
    6a35:	0f 1f 00             	nopl   (%rax)
    6a38:	66 85 c0             	test   %ax,%ax
    6a3b:	75 e0                	jne    6a1d <fwp_owned_entry173+0xad>
    6a3d:	eb d6                	jmp    6a15 <fwp_owned_entry173+0xa5>
    6a3f:	90                   	nop
    6a40:	48 89 d7             	mov    %rdx,%rdi
    6a43:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6a48:	48 89 14 24          	mov    %rdx,(%rsp)
    6a4c:	e8 5f ed ff ff       	call   57b0 <fwp_rc_forget_slot>
    6a51:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6a56:	48 8b 14 24          	mov    (%rsp),%rdx
    6a5a:	eb be                	jmp    6a1a <fwp_owned_entry173+0xaa>
    6a5c:	e8 7f cc ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6a61:	e8 ea c9 ff ff       	call   3450 <__stack_chk_fail@plt>
    6a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a6d:	00 00 00 

0000000000006a70 <e173>:
    6a70:	f3 0f 1e fa          	endbr64
    6a74:	53                   	push   %rbx
    6a75:	48 83 ec 30          	sub    $0x30,%rsp
    6a79:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a7e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a85:	00 00 
    6a87:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a8c:	31 c0                	xor    %eax,%eax
    6a8e:	48 8b 07             	mov    (%rdi),%rax
    6a91:	48 03 47 10          	add    0x10(%rdi),%rax
    6a95:	0f 80 c9 00 00 00    	jo     6b64 <e173+0xf4>
    6a9b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6aa0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6aa5:	31 ff                	xor    %edi,%edi
    6aa7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6aab:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ab0:	e8 2b f6 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6ab5:	48 8b 15 3c 21 06 00 	mov    0x6213c(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6abc:	48 89 c3             	mov    %rax,%rbx
    6abf:	48 2b 05 0a 21 06 00 	sub    0x6210a(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6ac6:	48 c1 e2 10          	shl    $0x10,%rdx
    6aca:	48 39 d0             	cmp    %rdx,%rax
    6acd:	73 4f                	jae    6b1e <e173+0xae>
    6acf:	48 89 c2             	mov    %rax,%rdx
    6ad2:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ada:	48 8b 15 37 21 06 00 	mov    0x62137(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6ae1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ae5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ae9:	48 85 d2             	test   %rdx,%rdx
    6aec:	74 30                	je     6b1e <e173+0xae>
    6aee:	0f b6 31             	movzbl (%rcx),%esi
    6af1:	40 80 fe 02          	cmp    $0x2,%sil
    6af5:	74 49                	je     6b40 <e173+0xd0>
    6af7:	40 80 fe 01          	cmp    $0x1,%sil
    6afb:	75 21                	jne    6b1e <e173+0xae>
    6afd:	8b 71 18             	mov    0x18(%rcx),%esi
    6b00:	0f b7 c0             	movzwl %ax,%eax
    6b03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b06:	48 0f af c6          	imul   %rsi,%rax
    6b0a:	48 c1 e8 20          	shr    $0x20,%rax
    6b0e:	48 39 c8             	cmp    %rcx,%rax
    6b11:	73 0b                	jae    6b1e <e173+0xae>
    6b13:	48 01 c2             	add    %rax,%rdx
    6b16:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b19:	74 35                	je     6b50 <e173+0xe0>
    6b1b:	c6 02 01             	movb   $0x1,(%rdx)
    6b1e:	48 89 df             	mov    %rbx,%rdi
    6b21:	e8 9a fc ff ff       	call   67c0 <fwp_rc_share>
    6b26:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b2b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b32:	00 00 
    6b34:	75 33                	jne    6b69 <e173+0xf9>
    6b36:	48 83 c4 30          	add    $0x30,%rsp
    6b3a:	48 89 d8             	mov    %rbx,%rax
    6b3d:	5b                   	pop    %rbx
    6b3e:	c3                   	ret
    6b3f:	90                   	nop
    6b40:	66 85 c0             	test   %ax,%ax
    6b43:	75 d9                	jne    6b1e <e173+0xae>
    6b45:	eb cf                	jmp    6b16 <e173+0xa6>
    6b47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b4e:	00 00 
    6b50:	48 89 d7             	mov    %rdx,%rdi
    6b53:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b58:	e8 53 ec ff ff       	call   57b0 <fwp_rc_forget_slot>
    6b5d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b62:	eb b7                	jmp    6b1b <e173+0xab>
    6b64:	e8 77 cb ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6b69:	e8 e2 c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b6e:	66 90                	xchg   %ax,%ax

0000000000006b70 <fwp_closure_drop>:
    6b70:	48 8b 15 81 20 06 00 	mov    0x62081(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6b77:	48 89 f8             	mov    %rdi,%rax
    6b7a:	48 2b 05 4f 20 06 00 	sub    0x6204f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6b81:	48 c1 e2 10          	shl    $0x10,%rdx
    6b85:	48 39 d0             	cmp    %rdx,%rax
    6b88:	73 6b                	jae    6bf5 <fwp_closure_drop+0x85>
    6b8a:	48 89 c2             	mov    %rax,%rdx
    6b8d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b95:	48 8b 15 7c 20 06 00 	mov    0x6207c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6b9c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ba0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ba4:	48 85 d2             	test   %rdx,%rdx
    6ba7:	74 4c                	je     6bf5 <fwp_closure_drop+0x85>
    6ba9:	0f b6 31             	movzbl (%rcx),%esi
    6bac:	40 80 fe 02          	cmp    $0x2,%sil
    6bb0:	74 3e                	je     6bf0 <fwp_closure_drop+0x80>
    6bb2:	40 80 fe 01          	cmp    $0x1,%sil
    6bb6:	75 3d                	jne    6bf5 <fwp_closure_drop+0x85>
    6bb8:	8b 71 18             	mov    0x18(%rcx),%esi
    6bbb:	0f b7 c0             	movzwl %ax,%eax
    6bbe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bc1:	48 0f af c6          	imul   %rsi,%rax
    6bc5:	48 c1 e8 20          	shr    $0x20,%rax
    6bc9:	48 39 c8             	cmp    %rcx,%rax
    6bcc:	73 27                	jae    6bf5 <fwp_closure_drop+0x85>
    6bce:	48 01 c2             	add    %rax,%rdx
    6bd1:	0f b6 02             	movzbl (%rdx),%eax
    6bd4:	84 c0                	test   %al,%al
    6bd6:	74 1d                	je     6bf5 <fwp_closure_drop+0x85>
    6bd8:	3c 01                	cmp    $0x1,%al
    6bda:	74 24                	je     6c00 <fwp_closure_drop+0x90>
    6bdc:	3c ff                	cmp    $0xff,%al
    6bde:	74 48                	je     6c28 <fwp_closure_drop+0xb8>
    6be0:	83 e8 01             	sub    $0x1,%eax
    6be3:	88 02                	mov    %al,(%rdx)
    6be5:	c3                   	ret
    6be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bed:	00 00 00 
    6bf0:	66 85 c0             	test   %ax,%ax
    6bf3:	74 dc                	je     6bd1 <fwp_closure_drop+0x61>
    6bf5:	c3                   	ret
    6bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bfd:	00 00 00 
    6c00:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c07:	ff ff 
    6c09:	48 85 c0             	test   %rax,%rax
    6c0c:	74 12                	je     6c20 <fwp_closure_drop+0xb0>
    6c0e:	48 89 fe             	mov    %rdi,%rsi
    6c11:	48 89 c7             	mov    %rax,%rdi
    6c14:	e9 77 d8 ff ff       	jmp    4490 <fwp_closure_drop_push>
    6c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c20:	e9 1b da ff ff       	jmp    4640 <fwp_closure_drop.part.0>
    6c25:	0f 1f 00             	nopl   (%rax)
    6c28:	48 89 d0             	mov    %rdx,%rax
    6c2b:	48 8d 35 ee 0b 06 00 	lea    0x60bee(%rip),%rsi        # 67820 <fwp_heap>
    6c32:	48 83 ec 18          	sub    $0x18,%rsp
    6c36:	48 c1 e8 11          	shr    $0x11,%rax
    6c3a:	48 31 d0             	xor    %rdx,%rax
    6c3d:	48 89 c1             	mov    %rax,%rcx
    6c40:	48 c1 e9 09          	shr    $0x9,%rcx
    6c44:	48 31 c8             	xor    %rcx,%rax
    6c47:	0f b6 c8             	movzbl %al,%ecx
    6c4a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6c51:	00 
    6c52:	48 85 c0             	test   %rax,%rax
    6c55:	75 12                	jne    6c69 <fwp_closure_drop+0xf9>
    6c57:	eb 49                	jmp    6ca2 <fwp_closure_drop+0x132>
    6c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c64:	48 85 c0             	test   %rax,%rax
    6c67:	74 39                	je     6ca2 <fwp_closure_drop+0x132>
    6c69:	48 89 c1             	mov    %rax,%rcx
    6c6c:	48 39 10             	cmp    %rdx,(%rax)
    6c6f:	75 ef                	jne    6c60 <fwp_closure_drop+0xf0>
    6c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6c84:	74 05                	je     6c8b <fwp_closure_drop+0x11b>
    6c86:	48 83 c4 18          	add    $0x18,%rsp
    6c8a:	c3                   	ret
    6c8b:	48 89 d7             	mov    %rdx,%rdi
    6c8e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c93:	e8 18 eb ff ff       	call   57b0 <fwp_rc_forget_slot>
    6c98:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c9d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6ca0:	eb e4                	jmp    6c86 <fwp_closure_drop+0x116>
    6ca2:	48 8d 3d ff 4c 00 00 	lea    0x4cff(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    6ca9:	e8 82 d7 ff ff       	call   4430 <fwp_trap>
    6cae:	66 90                	xchg   %ax,%ax

0000000000006cb0 <fwp_owned_tape_release>:
    6cb0:	48 85 ff             	test   %rdi,%rdi
    6cb3:	0f 84 f7 00 00 00    	je     6db0 <fwp_owned_tape_release+0x100>
    6cb9:	41 54                	push   %r12
    6cbb:	55                   	push   %rbp
    6cbc:	53                   	push   %rbx
    6cbd:	48 8b 07             	mov    (%rdi),%rax
    6cc0:	48 85 c0             	test   %rax,%rax
    6cc3:	74 08                	je     6ccd <fwp_owned_tape_release+0x1d>
    6cc5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cc9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ccd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cd1:	48 85 d2             	test   %rdx,%rdx
    6cd4:	74 03                	je     6cd9 <fwp_owned_tape_release+0x29>
    6cd6:	48 89 02             	mov    %rax,(%rdx)
    6cd9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6cdd:	48 89 fb             	mov    %rdi,%rbx
    6ce0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ce4:	48 85 c0             	test   %rax,%rax
    6ce7:	0f 84 89 00 00 00    	je     6d76 <fwp_owned_tape_release+0xc6>
    6ced:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6cf1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6cf5:	7e 47                	jle    6d3e <fwp_owned_tape_release+0x8e>
    6cf7:	31 ed                	xor    %ebp,%ebp
    6cf9:	eb 0d                	jmp    6d08 <fwp_owned_tape_release+0x58>
    6cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d0c:	49 89 ec             	mov    %rbp,%r12
    6d0f:	48 83 c5 01          	add    $0x1,%rbp
    6d13:	49 c1 e4 04          	shl    $0x4,%r12
    6d17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d1b:	ff d0                	call   *%rax
    6d1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6d21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6d26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d2a:	ff 50 68             	call   *0x68(%rax)
    6d2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6d31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6d35:	48 39 e8             	cmp    %rbp,%rax
    6d38:	7f c6                	jg     6d00 <fwp_owned_tape_release+0x50>
    6d3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d3e:	31 ed                	xor    %ebp,%ebp
    6d40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6d45:	7e 28                	jle    6d6f <fwp_owned_tape_release+0xbf>
    6d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d4e:	00 00 
    6d50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6d54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6d58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6d5c:	74 07                	je     6d65 <fwp_owned_tape_release+0xb5>
    6d5e:	ff 52 68             	call   *0x68(%rdx)
    6d61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d65:	48 83 c5 01          	add    $0x1,%rbp
    6d69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6d6d:	7f e1                	jg     6d50 <fwp_owned_tape_release+0xa0>
    6d6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d73:	ff 52 68             	call   *0x68(%rdx)
    6d76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6d7a:	e8 f1 fd ff ff       	call   6b70 <fwp_closure_drop>
    6d7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6d83:	e8 e8 fd ff ff       	call   6b70 <fwp_closure_drop>
    6d88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6d8c:	e8 df fd ff ff       	call   6b70 <fwp_closure_drop>
    6d91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6d95:	e8 56 ec ff ff       	call   59f0 <fwp_mem_free>
    6d9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6d9e:	e8 4d ec ff ff       	call   59f0 <fwp_mem_free>
    6da3:	48 89 df             	mov    %rbx,%rdi
    6da6:	5b                   	pop    %rbx
    6da7:	5d                   	pop    %rbp
    6da8:	41 5c                	pop    %r12
    6daa:	e9 41 ec ff ff       	jmp    59f0 <fwp_mem_free>
    6daf:	90                   	nop
    6db0:	c3                   	ret
    6db1:	0f 1f 40 00          	nopl   0x0(%rax)
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 

0000000000006dc0 <fwp_tape_finish>:
    6dc0:	f3 0f 1e fa          	endbr64
    6dc4:	41 55                	push   %r13
    6dc6:	41 54                	push   %r12
    6dc8:	55                   	push   %rbp
    6dc9:	53                   	push   %rbx
    6dca:	48 83 ec 48          	sub    $0x48,%rsp
    6dce:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6dd5:	00 00 
    6dd7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6ddc:	48 8d 3d bd 82 01 00 	lea    0x182bd(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    6de3:	e8 38 e3 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6de8:	48 83 3d f8 82 01 00 	cmpq   $0x0,0x182f8(%rip)        # 1f0e8 <fwp_ntapes>
    6def:	00 
    6df0:	48 c7 05 8d 82 01 00 	movq   $0x0,0x1828d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    6df7:	00 00 00 00 
    6dfb:	7e 79                	jle    6e76 <fwp_tape_finish+0xb6>
    6dfd:	45 31 e4             	xor    %r12d,%r12d
    6e00:	31 ed                	xor    %ebp,%ebp
    6e02:	0f 1f 00             	nopl   (%rax)
    6e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e0c:	00 00 00 00 
    6e10:	48 8b 1d d9 82 01 00 	mov    0x182d9(%rip),%rbx        # 1f0f0 <fwp_tapes>
    6e17:	48 83 c5 01          	add    $0x1,%rbp
    6e1b:	4c 01 e3             	add    %r12,%rbx
    6e1e:	49 83 c4 68          	add    $0x68,%r12
    6e22:	48 89 df             	mov    %rbx,%rdi
    6e25:	e8 46 ce ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6e2a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6e2f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6e34:	48 89 e7             	mov    %rsp,%rdi
    6e37:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e3b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6e3f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6e44:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e49:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6e4e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6e52:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6e57:	e8 c4 e2 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6e5c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6e60:	e8 4b fe ff ff       	call   6cb0 <fwp_owned_tape_release>
    6e65:	48 39 2d 7c 82 01 00 	cmp    %rbp,0x1827c(%rip)        # 1f0e8 <fwp_ntapes>
    6e6c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6e73:	00 
    6e74:	7f 9a                	jg     6e10 <fwp_tape_finish+0x50>
    6e76:	48 8b 3d 73 82 01 00 	mov    0x18273(%rip),%rdi        # 1f0f0 <fwp_tapes>
    6e7d:	48 85 ff             	test   %rdi,%rdi
    6e80:	74 05                	je     6e87 <fwp_tape_finish+0xc7>
    6e82:	e8 29 e2 ff ff       	call   50b0 <ad_raw_free.part.0>
    6e87:	48 c7 05 5e 82 01 00 	movq   $0x0,0x1825e(%rip)        # 1f0f0 <fwp_tapes>
    6e8e:	00 00 00 00 
    6e92:	48 c7 05 43 82 01 00 	movq   $0x0,0x18243(%rip)        # 1f0e0 <fwp_tapes_cap>
    6e99:	00 00 00 00 
    6e9d:	48 c7 05 40 82 01 00 	movq   $0x0,0x18240(%rip)        # 1f0e8 <fwp_ntapes>
    6ea4:	00 00 00 00 
    6ea8:	48 c7 05 25 82 01 00 	movq   $0x0,0x18225(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6eaf:	00 00 00 00 
    6eb3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6eb8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ebf:	00 00 
    6ec1:	75 0b                	jne    6ece <fwp_tape_finish+0x10e>
    6ec3:	48 83 c4 48          	add    $0x48,%rsp
    6ec7:	5b                   	pop    %rbx
    6ec8:	5d                   	pop    %rbp
    6ec9:	41 5c                	pop    %r12
    6ecb:	41 5d                	pop    %r13
    6ecd:	c3                   	ret
    6ece:	e8 7d c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6ed3:	66 90                	xchg   %ax,%ax
    6ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6edc:	00 00 00 00 

0000000000006ee0 <fwp_tape_scope_release>:
    6ee0:	f3 0f 1e fa          	endbr64
    6ee4:	41 55                	push   %r13
    6ee6:	41 54                	push   %r12
    6ee8:	55                   	push   %rbp
    6ee9:	53                   	push   %rbx
    6eea:	48 83 ec 48          	sub    $0x48,%rsp
    6eee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ef5:	00 00 
    6ef7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6efc:	48 63 07             	movslq (%rdi),%rax
    6eff:	85 c0                	test   %eax,%eax
    6f01:	0f 88 e8 00 00 00    	js     6fef <fwp_tape_scope_release+0x10f>
    6f07:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    6f0e:	ec c4 4e 
    6f11:	48 89 fb             	mov    %rdi,%rbx
    6f14:	48 89 e5             	mov    %rsp,%rbp
    6f17:	eb 1f                	jmp    6f38 <fwp_tape_scope_release+0x58>
    6f19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f20:	e8 fb e1 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6f25:	4c 89 ef             	mov    %r13,%rdi
    6f28:	e8 83 fd ff ff       	call   6cb0 <fwp_owned_tape_release>
    6f2d:	48 63 03             	movslq (%rbx),%rax
    6f30:	85 c0                	test   %eax,%eax
    6f32:	0f 88 b7 00 00 00    	js     6fef <fwp_tape_scope_release+0x10f>
    6f38:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6f3c:	48 8b 35 ad 81 01 00 	mov    0x181ad(%rip),%rsi        # 1f0f0 <fwp_tapes>
    6f43:	4c 01 c6             	add    %r8,%rsi
    6f46:	48 89 f7             	mov    %rsi,%rdi
    6f49:	e8 22 cd ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6f4e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6f53:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6f58:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6f5f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    6f63:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    6f67:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6f6e:	00 
    6f6f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f74:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    6f79:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    6f7d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6f82:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f86:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6f8b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6f92:	00 
    6f93:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6f9a:	00 
    6f9b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6fa2:	00 
    6fa3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6fa7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    6fab:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    6faf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    6fb3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6fb9:	77 18                	ja     6fd3 <fwp_tape_scope_release+0xf3>
    6fbb:	49 c1 f8 03          	sar    $0x3,%r8
    6fbf:	4d 0f af c4          	imul   %r12,%r8
    6fc3:	4c 3b 05 0e 81 01 00 	cmp    0x1810e(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    6fca:	7d 07                	jge    6fd3 <fwp_tape_scope_release+0xf3>
    6fcc:	4c 89 05 05 81 01 00 	mov    %r8,0x18105(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6fd3:	48 89 ef             	mov    %rbp,%rdi
    6fd6:	4d 85 ed             	test   %r13,%r13
    6fd9:	0f 85 41 ff ff ff    	jne    6f20 <fwp_tape_scope_release+0x40>
    6fdf:	e8 5c e2 ff ff       	call   5240 <fwp_tape_buffers_release>
    6fe4:	48 63 03             	movslq (%rbx),%rax
    6fe7:	85 c0                	test   %eax,%eax
    6fe9:	0f 89 49 ff ff ff    	jns    6f38 <fwp_tape_scope_release+0x58>
    6fef:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6ff4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ffb:	00 00 
    6ffd:	75 0b                	jne    700a <fwp_tape_scope_release+0x12a>
    6fff:	48 83 c4 48          	add    $0x48,%rsp
    7003:	5b                   	pop    %rbx
    7004:	5d                   	pop    %rbp
    7005:	41 5c                	pop    %r12
    7007:	41 5d                	pop    %r13
    7009:	c3                   	ret
    700a:	e8 41 c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    700f:	90                   	nop

0000000000007010 <fwp_drop4>:
    7010:	48 8b 0d e1 1b 06 00 	mov    0x61be1(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7017:	48 89 f8             	mov    %rdi,%rax
    701a:	48 2b 05 af 1b 06 00 	sub    0x61baf(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7021:	48 c1 e1 10          	shl    $0x10,%rcx
    7025:	48 39 c8             	cmp    %rcx,%rax
    7028:	0f 83 42 01 00 00    	jae    7170 <fwp_drop4+0x160>
    702e:	48 83 ec 18          	sub    $0x18,%rsp
    7032:	48 89 fa             	mov    %rdi,%rdx
    7035:	4c 8d 05 e4 07 06 00 	lea    0x607e4(%rip),%r8        # 67820 <fwp_heap>
    703c:	48 89 c1             	mov    %rax,%rcx
    703f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7046:	48 c1 e9 10          	shr    $0x10,%rcx
    704a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    704e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7052:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7056:	48 85 c9             	test   %rcx,%rcx
    7059:	74 40                	je     709b <fwp_drop4+0x8b>
    705b:	0f b6 3e             	movzbl (%rsi),%edi
    705e:	40 80 ff 02          	cmp    $0x2,%dil
    7062:	74 3c                	je     70a0 <fwp_drop4+0x90>
    7064:	40 80 ff 01          	cmp    $0x1,%dil
    7068:	75 31                	jne    709b <fwp_drop4+0x8b>
    706a:	8b 7e 18             	mov    0x18(%rsi),%edi
    706d:	0f b7 c0             	movzwl %ax,%eax
    7070:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7073:	48 0f af c7          	imul   %rdi,%rax
    7077:	48 c1 e8 20          	shr    $0x20,%rax
    707b:	48 39 f0             	cmp    %rsi,%rax
    707e:	73 1b                	jae    709b <fwp_drop4+0x8b>
    7080:	48 01 c1             	add    %rax,%rcx
    7083:	0f b6 01             	movzbl (%rcx),%eax
    7086:	84 c0                	test   %al,%al
    7088:	74 11                	je     709b <fwp_drop4+0x8b>
    708a:	3c 01                	cmp    $0x1,%al
    708c:	74 22                	je     70b0 <fwp_drop4+0xa0>
    708e:	3c ff                	cmp    $0xff,%al
    7090:	0f 84 0a 01 00 00    	je     71a0 <fwp_drop4+0x190>
    7096:	83 e8 01             	sub    $0x1,%eax
    7099:	88 01                	mov    %al,(%rcx)
    709b:	48 83 c4 18          	add    $0x18,%rsp
    709f:	c3                   	ret
    70a0:	66 85 c0             	test   %ax,%ax
    70a3:	74 de                	je     7083 <fwp_drop4+0x73>
    70a5:	48 83 c4 18          	add    $0x18,%rsp
    70a9:	c3                   	ret
    70aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70b0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    70b4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    70bb:	48 89 f8             	mov    %rdi,%rax
    70be:	48 c1 e1 10          	shl    $0x10,%rcx
    70c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70c9:	48 39 c8             	cmp    %rcx,%rax
    70cc:	73 62                	jae    7130 <fwp_drop4+0x120>
    70ce:	48 89 c1             	mov    %rax,%rcx
    70d1:	48 c1 e9 10          	shr    $0x10,%rcx
    70d5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    70d9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    70dd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    70e1:	48 85 c9             	test   %rcx,%rcx
    70e4:	74 4a                	je     7130 <fwp_drop4+0x120>
    70e6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    70ea:	41 80 f9 02          	cmp    $0x2,%r9b
    70ee:	0f 84 9c 00 00 00    	je     7190 <fwp_drop4+0x180>
    70f4:	41 80 f9 01          	cmp    $0x1,%r9b
    70f8:	75 36                	jne    7130 <fwp_drop4+0x120>
    70fa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    70fe:	0f b7 c0             	movzwl %ax,%eax
    7101:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7104:	49 0f af c1          	imul   %r9,%rax
    7108:	48 c1 e8 20          	shr    $0x20,%rax
    710c:	48 39 f0             	cmp    %rsi,%rax
    710f:	73 1f                	jae    7130 <fwp_drop4+0x120>
    7111:	48 01 c1             	add    %rax,%rcx
    7114:	0f b6 01             	movzbl (%rcx),%eax
    7117:	84 c0                	test   %al,%al
    7119:	74 15                	je     7130 <fwp_drop4+0x120>
    711b:	3c 01                	cmp    $0x1,%al
    711d:	74 59                	je     7178 <fwp_drop4+0x168>
    711f:	3c ff                	cmp    $0xff,%al
    7121:	0f 84 ff 00 00 00    	je     7226 <fwp_drop4+0x216>
    7127:	83 e8 01             	sub    $0x1,%eax
    712a:	88 01                	mov    %al,(%rcx)
    712c:	0f 1f 40 00          	nopl   0x0(%rax)
    7130:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7134:	48 89 d7             	mov    %rdx,%rdi
    7137:	48 89 0c 24          	mov    %rcx,(%rsp)
    713b:	e8 00 f7 ff ff       	call   6840 <fwp_rc_free_obj>
    7140:	4c 8d 05 d9 06 06 00 	lea    0x606d9(%rip),%r8        # 67820 <fwp_heap>
    7147:	48 8b 04 24          	mov    (%rsp),%rax
    714b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7152:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7159:	48 c1 e2 10          	shl    $0x10,%rdx
    715d:	48 39 d0             	cmp    %rdx,%rax
    7160:	0f 83 35 ff ff ff    	jae    709b <fwp_drop4+0x8b>
    7166:	48 8b 14 24          	mov    (%rsp),%rdx
    716a:	e9 cd fe ff ff       	jmp    703c <fwp_drop4+0x2c>
    716f:	90                   	nop
    7170:	c3                   	ret
    7171:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7178:	48 89 14 24          	mov    %rdx,(%rsp)
    717c:	e8 bf f6 ff ff       	call   6840 <fwp_rc_free_obj>
    7181:	48 8b 14 24          	mov    (%rsp),%rdx
    7185:	eb a9                	jmp    7130 <fwp_drop4+0x120>
    7187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    718e:	00 00 
    7190:	66 85 c0             	test   %ax,%ax
    7193:	75 9b                	jne    7130 <fwp_drop4+0x120>
    7195:	e9 7a ff ff ff       	jmp    7114 <fwp_drop4+0x104>
    719a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71a0:	48 89 c8             	mov    %rcx,%rax
    71a3:	48 c1 e8 11          	shr    $0x11,%rax
    71a7:	48 31 c8             	xor    %rcx,%rax
    71aa:	48 89 c2             	mov    %rax,%rdx
    71ad:	48 c1 ea 09          	shr    $0x9,%rdx
    71b1:	48 31 d0             	xor    %rdx,%rax
    71b4:	0f b6 d0             	movzbl %al,%edx
    71b7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    71be:	00 
    71bf:	48 85 c0             	test   %rax,%rax
    71c2:	75 29                	jne    71ed <fwp_drop4+0x1dd>
    71c4:	e9 e3 00 00 00       	jmp    72ac <fwp_drop4+0x29c>
    71c9:	90                   	nop
    71ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71d1:	00 00 00 00 
    71d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71dc:	00 00 00 00 
    71e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    71e4:	48 85 c0             	test   %rax,%rax
    71e7:	0f 84 bf 00 00 00    	je     72ac <fwp_drop4+0x29c>
    71ed:	48 89 c2             	mov    %rax,%rdx
    71f0:	48 39 08             	cmp    %rcx,(%rax)
    71f3:	75 eb                	jne    71e0 <fwp_drop4+0x1d0>
    71f5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    71f9:	48 83 ea 01          	sub    $0x1,%rdx
    71fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7201:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7208:	0f 85 8d fe ff ff    	jne    709b <fwp_drop4+0x8b>
    720e:	48 89 cf             	mov    %rcx,%rdi
    7211:	48 89 0c 24          	mov    %rcx,(%rsp)
    7215:	e8 96 e5 ff ff       	call   57b0 <fwp_rc_forget_slot>
    721a:	48 8b 0c 24          	mov    (%rsp),%rcx
    721e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7221:	e9 75 fe ff ff       	jmp    709b <fwp_drop4+0x8b>
    7226:	48 89 ce             	mov    %rcx,%rsi
    7229:	48 c1 ee 11          	shr    $0x11,%rsi
    722d:	48 31 ce             	xor    %rcx,%rsi
    7230:	48 89 f0             	mov    %rsi,%rax
    7233:	48 c1 e8 09          	shr    $0x9,%rax
    7237:	48 31 c6             	xor    %rax,%rsi
    723a:	40 0f b6 f6          	movzbl %sil,%esi
    723e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7245:	00 
    7246:	48 85 c0             	test   %rax,%rax
    7249:	75 1e                	jne    7269 <fwp_drop4+0x259>
    724b:	eb 5f                	jmp    72ac <fwp_drop4+0x29c>
    724d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7254:	00 
    7255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    725c:	00 00 00 00 
    7260:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	74 43                	je     72ac <fwp_drop4+0x29c>
    7269:	48 89 c6             	mov    %rax,%rsi
    726c:	48 39 08             	cmp    %rcx,(%rax)
    726f:	75 ef                	jne    7260 <fwp_drop4+0x250>
    7271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7275:	48 83 ee 01          	sub    $0x1,%rsi
    7279:	48 89 70 08          	mov    %rsi,0x8(%rax)
    727d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7284:	0f 85 a6 fe ff ff    	jne    7130 <fwp_drop4+0x120>
    728a:	48 89 cf             	mov    %rcx,%rdi
    728d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7292:	48 89 0c 24          	mov    %rcx,(%rsp)
    7296:	e8 15 e5 ff ff       	call   57b0 <fwp_rc_forget_slot>
    729b:	48 8b 0c 24          	mov    (%rsp),%rcx
    729f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72a4:	c6 01 fe             	movb   $0xfe,(%rcx)
    72a7:	e9 84 fe ff ff       	jmp    7130 <fwp_drop4+0x120>
    72ac:	48 8d 3d f5 46 00 00 	lea    0x46f5(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    72b3:	e8 78 d1 ff ff       	call   4430 <fwp_trap>
    72b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72bf:	00 

00000000000072c0 <fwp_arg_drop37>:
    72c0:	f3 0f 1e fa          	endbr64
    72c4:	85 f6                	test   %esi,%esi
    72c6:	75 04                	jne    72cc <fwp_arg_drop37+0xc>
    72c8:	85 d2                	test   %edx,%edx
    72ca:	75 04                	jne    72d0 <fwp_arg_drop37+0x10>
    72cc:	c3                   	ret
    72cd:	0f 1f 00             	nopl   (%rax)
    72d0:	48 8b 3f             	mov    (%rdi),%rdi
    72d3:	e9 38 fd ff ff       	jmp    7010 <fwp_drop4>
    72d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72df:	00 

00000000000072e0 <fwp_task_dispose>:
    72e0:	53                   	push   %rbx
    72e1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    72e5:	0f 84 3b c4 ff ff    	je     3726 <fwp_task_dispose.cold>
    72eb:	48 89 fb             	mov    %rdi,%rbx
    72ee:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    72f3:	0f 85 2d c4 ff ff    	jne    3726 <fwp_task_dispose.cold>
    72f9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    72fd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7304:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    730b:	00 
    730c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7310:	48 85 ff             	test   %rdi,%rdi
    7313:	74 07                	je     731c <fwp_task_dispose+0x3c>
    7315:	48 85 c0             	test   %rax,%rax
    7318:	74 02                	je     731c <fwp_task_dispose+0x3c>
    731a:	ff d0                	call   *%rax
    731c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7323:	e8 c8 e6 ff ff       	call   59f0 <fwp_mem_free>
    7328:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    732f:	00 00 00 00 
    7333:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7337:	74 6f                	je     73a8 <fwp_task_dispose+0xc8>
    7339:	48 8b 15 b8 18 06 00 	mov    0x618b8(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7340:	48 89 d8             	mov    %rbx,%rax
    7343:	48 2b 05 86 18 06 00 	sub    0x61886(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    734a:	48 c1 e2 10          	shl    $0x10,%rdx
    734e:	48 39 d0             	cmp    %rdx,%rax
    7351:	73 4c                	jae    739f <fwp_task_dispose+0xbf>
    7353:	48 89 c2             	mov    %rax,%rdx
    7356:	48 c1 ea 10          	shr    $0x10,%rdx
    735a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    735e:	48 8b 15 b3 18 06 00 	mov    0x618b3(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7365:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7369:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    736d:	48 85 c9             	test   %rcx,%rcx
    7370:	74 2d                	je     739f <fwp_task_dispose+0xbf>
    7372:	0f b6 32             	movzbl (%rdx),%esi
    7375:	40 80 fe 02          	cmp    $0x2,%sil
    7379:	74 3d                	je     73b8 <fwp_task_dispose+0xd8>
    737b:	40 80 fe 01          	cmp    $0x1,%sil
    737f:	75 1e                	jne    739f <fwp_task_dispose+0xbf>
    7381:	8b 72 18             	mov    0x18(%rdx),%esi
    7384:	0f b7 c0             	movzwl %ax,%eax
    7387:	8b 52 1c             	mov    0x1c(%rdx),%edx
    738a:	48 0f af c6          	imul   %rsi,%rax
    738e:	48 c1 e8 20          	shr    $0x20,%rax
    7392:	48 39 d0             	cmp    %rdx,%rax
    7395:	73 08                	jae    739f <fwp_task_dispose+0xbf>
    7397:	48 01 c1             	add    %rax,%rcx
    739a:	80 39 01             	cmpb   $0x1,(%rcx)
    739d:	74 09                	je     73a8 <fwp_task_dispose+0xc8>
    739f:	5b                   	pop    %rbx
    73a0:	c3                   	ret
    73a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73a8:	48 89 df             	mov    %rbx,%rdi
    73ab:	5b                   	pop    %rbx
    73ac:	e9 3f e6 ff ff       	jmp    59f0 <fwp_mem_free>
    73b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73b8:	66 85 c0             	test   %ax,%ax
    73bb:	74 dd                	je     739a <fwp_task_dispose+0xba>
    73bd:	5b                   	pop    %rbx
    73be:	c3                   	ret
    73bf:	90                   	nop

00000000000073c0 <fwp_free_zombie>:
    73c0:	48 8b 15 29 04 06 00 	mov    0x60429(%rip),%rdx        # 677f0 <fwp_zombie>
    73c7:	48 85 d2             	test   %rdx,%rdx
    73ca:	0f 84 98 00 00 00    	je     7468 <fwp_free_zombie+0xa8>
    73d0:	48 3b 15 29 04 06 00 	cmp    0x60429(%rip),%rdx        # 67800 <fwp_cur>
    73d7:	0f 84 8b 00 00 00    	je     7468 <fwp_free_zombie+0xa8>
    73dd:	48 83 ec 18          	sub    $0x18,%rsp
    73e1:	48 63 05 ec fd 05 00 	movslq 0x5fdec(%rip),%rax        # 671d4 <fwp_stack_pool_n>
    73e8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    73ec:	83 f8 3f             	cmp    $0x3f,%eax
    73ef:	7f 7f                	jg     7470 <fwp_free_zombie+0xb0>
    73f1:	8d 48 01             	lea    0x1(%rax),%ecx
    73f4:	89 0d da fd 05 00    	mov    %ecx,0x5fdda(%rip)        # 671d4 <fwp_stack_pool_n>
    73fa:	48 8d 0d df fd 05 00 	lea    0x5fddf(%rip),%rcx        # 671e0 <fwp_stack_pool>
    7401:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7405:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    740c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7410:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7417:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    741b:	48 85 c9             	test   %rcx,%rcx
    741e:	0f 84 fc 00 00 00    	je     7520 <fwp_free_zombie+0x160>
    7424:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    742b:	48 85 c0             	test   %rax,%rax
    742e:	74 07                	je     7437 <fwp_free_zombie+0x77>
    7430:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7437:	8b 42 5c             	mov    0x5c(%rdx),%eax
    743a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    743e:	48 c7 05 a7 03 06 00 	movq   $0x0,0x603a7(%rip)        # 677f0 <fwp_zombie>
    7445:	00 00 00 00 
    7449:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7450:	85 c0                	test   %eax,%eax
    7452:	74 34                	je     7488 <fwp_free_zombie+0xc8>
    7454:	83 f8 01             	cmp    $0x1,%eax
    7457:	0f 84 b3 00 00 00    	je     7510 <fwp_free_zombie+0x150>
    745d:	48 83 c4 18          	add    $0x18,%rsp
    7461:	c3                   	ret
    7462:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7468:	c3                   	ret
    7469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7470:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7474:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7479:	e8 42 c1 ff ff       	call   35c0 <munmap@plt>
    747e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7483:	eb 80                	jmp    7405 <fwp_free_zombie+0x45>
    7485:	0f 1f 00             	nopl   (%rax)
    7488:	48 8b 0d 69 17 06 00 	mov    0x61769(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    748f:	48 89 d0             	mov    %rdx,%rax
    7492:	48 2b 05 37 17 06 00 	sub    0x61737(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7499:	48 c1 e1 10          	shl    $0x10,%rcx
    749d:	48 39 c8             	cmp    %rcx,%rax
    74a0:	73 bb                	jae    745d <fwp_free_zombie+0x9d>
    74a2:	48 89 c1             	mov    %rax,%rcx
    74a5:	48 c1 e9 10          	shr    $0x10,%rcx
    74a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    74ad:	48 8b 0d 64 17 06 00 	mov    0x61764(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    74b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    74b8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    74bc:	48 85 c9             	test   %rcx,%rcx
    74bf:	74 9c                	je     745d <fwp_free_zombie+0x9d>
    74c1:	0f b6 3e             	movzbl (%rsi),%edi
    74c4:	40 80 ff 02          	cmp    $0x2,%dil
    74c8:	74 66                	je     7530 <fwp_free_zombie+0x170>
    74ca:	40 80 ff 01          	cmp    $0x1,%dil
    74ce:	75 8d                	jne    745d <fwp_free_zombie+0x9d>
    74d0:	8b 7e 18             	mov    0x18(%rsi),%edi
    74d3:	0f b7 c0             	movzwl %ax,%eax
    74d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    74d9:	48 0f af c7          	imul   %rdi,%rax
    74dd:	48 c1 e8 20          	shr    $0x20,%rax
    74e1:	48 39 f0             	cmp    %rsi,%rax
    74e4:	0f 83 73 ff ff ff    	jae    745d <fwp_free_zombie+0x9d>
    74ea:	48 01 c1             	add    %rax,%rcx
    74ed:	0f b6 01             	movzbl (%rcx),%eax
    74f0:	84 c0                	test   %al,%al
    74f2:	0f 84 65 ff ff ff    	je     745d <fwp_free_zombie+0x9d>
    74f8:	3c 01                	cmp    $0x1,%al
    74fa:	74 14                	je     7510 <fwp_free_zombie+0x150>
    74fc:	3c ff                	cmp    $0xff,%al
    74fe:	74 3b                	je     753b <fwp_free_zombie+0x17b>
    7500:	83 e8 01             	sub    $0x1,%eax
    7503:	88 01                	mov    %al,(%rcx)
    7505:	e9 53 ff ff ff       	jmp    745d <fwp_free_zombie+0x9d>
    750a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7510:	48 89 d7             	mov    %rdx,%rdi
    7513:	48 83 c4 18          	add    $0x18,%rsp
    7517:	e9 c4 fd ff ff       	jmp    72e0 <fwp_task_dispose>
    751c:	0f 1f 40 00          	nopl   0x0(%rax)
    7520:	48 89 05 a1 02 06 00 	mov    %rax,0x602a1(%rip)        # 677c8 <fwp_tasks_active>
    7527:	e9 ff fe ff ff       	jmp    742b <fwp_free_zombie+0x6b>
    752c:	0f 1f 40 00          	nopl   0x0(%rax)
    7530:	66 85 c0             	test   %ax,%ax
    7533:	0f 85 24 ff ff ff    	jne    745d <fwp_free_zombie+0x9d>
    7539:	eb b2                	jmp    74ed <fwp_free_zombie+0x12d>
    753b:	48 89 ca             	mov    %rcx,%rdx
    753e:	48 8d 35 db 02 06 00 	lea    0x602db(%rip),%rsi        # 67820 <fwp_heap>
    7545:	48 c1 ea 11          	shr    $0x11,%rdx
    7549:	48 31 ca             	xor    %rcx,%rdx
    754c:	48 89 d0             	mov    %rdx,%rax
    754f:	48 c1 e8 09          	shr    $0x9,%rax
    7553:	48 31 c2             	xor    %rax,%rdx
    7556:	0f b6 d2             	movzbl %dl,%edx
    7559:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7560:	00 
    7561:	48 85 c0             	test   %rax,%rax
    7564:	75 23                	jne    7589 <fwp_free_zombie+0x1c9>
    7566:	eb 5c                	jmp    75c4 <fwp_free_zombie+0x204>
    7568:	66 90                	xchg   %ax,%ax
    756a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7571:	00 00 00 00 
    7575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    757c:	00 00 00 00 
    7580:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7584:	48 85 c0             	test   %rax,%rax
    7587:	74 3b                	je     75c4 <fwp_free_zombie+0x204>
    7589:	48 89 c2             	mov    %rax,%rdx
    758c:	48 39 08             	cmp    %rcx,(%rax)
    758f:	75 ef                	jne    7580 <fwp_free_zombie+0x1c0>
    7591:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7595:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7599:	48 89 50 08          	mov    %rdx,0x8(%rax)
    759d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    75a4:	0f 85 b3 fe ff ff    	jne    745d <fwp_free_zombie+0x9d>
    75aa:	48 89 cf             	mov    %rcx,%rdi
    75ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    75b2:	e8 f9 e1 ff ff       	call   57b0 <fwp_rc_forget_slot>
    75b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    75bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    75bf:	e9 99 fe ff ff       	jmp    745d <fwp_free_zombie+0x9d>
    75c4:	48 8d 3d dd 43 00 00 	lea    0x43dd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    75cb:	e8 60 ce ff ff       	call   4430 <fwp_trap>

00000000000075d0 <fwp_block>:
    75d0:	48 83 ec 08          	sub    $0x8,%rsp
    75d4:	48 8b 05 0d 02 06 00 	mov    0x6020d(%rip),%rax        # 677e8 <fwp_ready_head>
    75db:	48 85 c0             	test   %rax,%rax
    75de:	0f 84 1c 01 00 00    	je     7700 <fwp_block+0x130>
    75e4:	90                   	nop
    75e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75ec:	00 00 00 00 
    75f0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    75f7:	48 89 15 ea 01 06 00 	mov    %rdx,0x601ea(%rip)        # 677e8 <fwp_ready_head>
    75fe:	48 85 d2             	test   %rdx,%rdx
    7601:	0f 84 19 01 00 00    	je     7720 <fwp_block+0x150>
    7607:	48 8b 15 f2 01 06 00 	mov    0x601f2(%rip),%rdx        # 67800 <fwp_cur>
    760e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7612:	48 39 c2             	cmp    %rax,%rdx
    7615:	0f 84 d5 00 00 00    	je     76f0 <fwp_block+0x120>
    761b:	48 8b 0d 66 1e 06 00 	mov    0x61e66(%rip),%rcx        # 69488 <fwp_state_owners>
    7622:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7626:	48 89 05 d3 01 06 00 	mov    %rax,0x601d3(%rip)        # 67800 <fwp_cur>
    762d:	f3 0f 7e 05 7b 1e 06 	movq   0x61e7b(%rip),%xmm0        # 694b0 <fwp_foreign_callbacks>
    7634:	00 
    7635:	0f 16 05 64 1e 06 00 	movhps 0x61e64(%rip),%xmm0        # 694a0 <fwp_state>
    763c:	f3 0f 7e 0d 64 1e 06 	movq   0x61e64(%rip),%xmm1        # 694a8 <fwp_handlers>
    7643:	00 
    7644:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    764b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7652:	0f 16 0d 5f 1e 06 00 	movhps 0x61e5f(%rip),%xmm1        # 694b8 <fwp_cleanups>
    7659:	f3 0f 7e 05 37 1e 06 	movq   0x61e37(%rip),%xmm0        # 69498 <fwp_state_len>
    7660:	00 
    7661:	0f 16 05 28 1e 06 00 	movhps 0x61e28(%rip),%xmm0        # 69490 <fwp_state_cap>
    7668:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    766f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7676:	48 8b 70 08          	mov    0x8(%rax),%rsi
    767a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7681:	48 89 0d 20 1e 06 00 	mov    %rcx,0x61e20(%rip)        # 694a8 <fwp_handlers>
    7688:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    768f:	48 89 0d 22 1e 06 00 	mov    %rcx,0x61e22(%rip)        # 694b8 <fwp_cleanups>
    7696:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    769d:	48 89 0d 0c 1e 06 00 	mov    %rcx,0x61e0c(%rip)        # 694b0 <fwp_foreign_callbacks>
    76a4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    76ab:	48 89 0d ee 1d 06 00 	mov    %rcx,0x61dee(%rip)        # 694a0 <fwp_state>
    76b2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    76b9:	48 89 0d d8 1d 06 00 	mov    %rcx,0x61dd8(%rip)        # 69498 <fwp_state_len>
    76c0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    76c7:	48 89 0d c2 1d 06 00 	mov    %rcx,0x61dc2(%rip)        # 69490 <fwp_state_cap>
    76ce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    76d5:	48 89 0d ac 1d 06 00 	mov    %rcx,0x61dac(%rip)        # 69488 <fwp_state_owners>
    76dc:	e8 9f bd ff ff       	call   3480 <swapcontext@plt>
    76e1:	f3 0f 1e fa          	endbr64
    76e5:	e8 d6 fc ff ff       	call   73c0 <fwp_free_zombie>
    76ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f0:	8b 05 da fa 05 00    	mov    0x5fada(%rip),%eax        # 671d0 <fwp_slice>
    76f6:	85 c0                	test   %eax,%eax
    76f8:	74 36                	je     7730 <fwp_block+0x160>
    76fa:	48 83 c4 08          	add    $0x8,%rsp
    76fe:	c3                   	ret
    76ff:	90                   	nop
    7700:	e8 eb dc ff ff       	call   53f0 <fwp_poll_events>
    7705:	48 8b 05 dc 00 06 00 	mov    0x600dc(%rip),%rax        # 677e8 <fwp_ready_head>
    770c:	48 85 c0             	test   %rax,%rax
    770f:	0f 85 db fe ff ff    	jne    75f0 <fwp_block+0x20>
    7715:	eb e9                	jmp    7700 <fwp_block+0x130>
    7717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    771e:	00 00 
    7720:	48 c7 05 b5 00 06 00 	movq   $0x0,0x600b5(%rip)        # 677e0 <fwp_ready_tail>
    7727:	00 00 00 00 
    772b:	e9 d7 fe ff ff       	jmp    7607 <fwp_block+0x37>
    7730:	48 8d 3d a8 3a 00 00 	lea    0x3aa8(%rip),%rdi        # b1df <_IO_stdin_used+0x1df>
    7737:	e8 54 bc ff ff       	call   3390 <getenv@plt>
    773c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7741:	48 85 c0             	test   %rax,%rax
    7744:	74 05                	je     774b <fwp_block+0x17b>
    7746:	80 38 00             	cmpb   $0x0,(%rax)
    7749:	75 0b                	jne    7756 <fwp_block+0x186>
    774b:	89 15 7f fa 05 00    	mov    %edx,0x5fa7f(%rip)        # 671d0 <fwp_slice>
    7751:	48 83 c4 08          	add    $0x8,%rsp
    7755:	c3                   	ret
    7756:	ba 0a 00 00 00       	mov    $0xa,%edx
    775b:	31 f6                	xor    %esi,%esi
    775d:	48 89 c7             	mov    %rax,%rdi
    7760:	e8 db bd ff ff       	call   3540 <strtoll@plt>
    7765:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7769:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7770:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7775:	0f 46 d0             	cmovbe %eax,%edx
    7778:	eb d1                	jmp    774b <fwp_block+0x17b>
    777a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007780 <fwp_caps173>:
    7780:	f3 0f 1e fa          	endbr64
    7784:	85 f6                	test   %esi,%esi
    7786:	74 08                	je     7790 <fwp_caps173+0x10>
    7788:	c3                   	ret
    7789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7790:	48 8b 15 61 14 06 00 	mov    0x61461(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7797:	48 89 f8             	mov    %rdi,%rax
    779a:	48 2b 05 2f 14 06 00 	sub    0x6142f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    77a1:	48 c1 e2 10          	shl    $0x10,%rdx
    77a5:	48 39 d0             	cmp    %rdx,%rax
    77a8:	73 de                	jae    7788 <fwp_caps173+0x8>
    77aa:	48 89 c2             	mov    %rax,%rdx
    77ad:	48 c1 ea 10          	shr    $0x10,%rdx
    77b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77b5:	48 8b 15 5c 14 06 00 	mov    0x6145c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    77bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    77c4:	48 85 c9             	test   %rcx,%rcx
    77c7:	74 bf                	je     7788 <fwp_caps173+0x8>
    77c9:	0f b6 32             	movzbl (%rdx),%esi
    77cc:	40 80 fe 02          	cmp    $0x2,%sil
    77d0:	74 2e                	je     7800 <fwp_caps173+0x80>
    77d2:	40 80 fe 01          	cmp    $0x1,%sil
    77d6:	75 b0                	jne    7788 <fwp_caps173+0x8>
    77d8:	8b 72 18             	mov    0x18(%rdx),%esi
    77db:	0f b7 c0             	movzwl %ax,%eax
    77de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77e1:	48 0f af c6          	imul   %rsi,%rax
    77e5:	48 c1 e8 20          	shr    $0x20,%rax
    77e9:	48 39 d0             	cmp    %rdx,%rax
    77ec:	73 9a                	jae    7788 <fwp_caps173+0x8>
    77ee:	48 01 c1             	add    %rax,%rcx
    77f1:	80 39 01             	cmpb   $0x1,(%rcx)
    77f4:	75 92                	jne    7788 <fwp_caps173+0x8>
    77f6:	e9 f5 e1 ff ff       	jmp    59f0 <fwp_mem_free>
    77fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7800:	66 85 c0             	test   %ax,%ax
    7803:	74 ec                	je     77f1 <fwp_caps173+0x71>
    7805:	c3                   	ret
    7806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    780d:	00 00 00 

0000000000007810 <fwp_args37>:
    7810:	f3 0f 1e fa          	endbr64
    7814:	85 d2                	test   %edx,%edx
    7816:	74 04                	je     781c <fwp_args37+0xc>
    7818:	85 f6                	test   %esi,%esi
    781a:	74 04                	je     7820 <fwp_args37+0x10>
    781c:	c3                   	ret
    781d:	0f 1f 00             	nopl   (%rax)
    7820:	48 8b 15 d1 13 06 00 	mov    0x613d1(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7827:	48 8b 07             	mov    (%rdi),%rax
    782a:	48 2b 05 9f 13 06 00 	sub    0x6139f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7831:	48 c1 e2 10          	shl    $0x10,%rdx
    7835:	48 39 d0             	cmp    %rdx,%rax
    7838:	73 e2                	jae    781c <fwp_args37+0xc>
    783a:	48 89 c2             	mov    %rax,%rdx
    783d:	48 c1 ea 10          	shr    $0x10,%rdx
    7841:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7845:	48 8b 15 cc 13 06 00 	mov    0x613cc(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    784c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7850:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7854:	48 85 ff             	test   %rdi,%rdi
    7857:	74 c3                	je     781c <fwp_args37+0xc>
    7859:	0f b6 0a             	movzbl (%rdx),%ecx
    785c:	80 f9 02             	cmp    $0x2,%cl
    785f:	74 4f                	je     78b0 <fwp_args37+0xa0>
    7861:	80 f9 01             	cmp    $0x1,%cl
    7864:	75 b6                	jne    781c <fwp_args37+0xc>
    7866:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7869:	0f b7 c0             	movzwl %ax,%eax
    786c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    786f:	48 0f af c1          	imul   %rcx,%rax
    7873:	48 c1 e8 20          	shr    $0x20,%rax
    7877:	48 39 d0             	cmp    %rdx,%rax
    787a:	73 a0                	jae    781c <fwp_args37+0xc>
    787c:	48 01 c7             	add    %rax,%rdi
    787f:	0f b6 07             	movzbl (%rdi),%eax
    7882:	84 c0                	test   %al,%al
    7884:	74 96                	je     781c <fwp_args37+0xc>
    7886:	8b 15 5c 1c 06 00    	mov    0x61c5c(%rip),%edx        # 694e8 <iteration_active>
    788c:	85 d2                	test   %edx,%edx
    788e:	75 10                	jne    78a0 <fwp_args37+0x90>
    7890:	3c fd                	cmp    $0xfd,%al
    7892:	77 22                	ja     78b6 <fwp_args37+0xa6>
    7894:	83 c0 01             	add    $0x1,%eax
    7897:	88 07                	mov    %al,(%rdi)
    7899:	c3                   	ret
    789a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78a0:	48 83 05 28 1c 06 00 	addq   $0x1,0x61c28(%rip)        # 694d0 <iteration_retains>
    78a7:	01 
    78a8:	eb e6                	jmp    7890 <fwp_args37+0x80>
    78aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 ca                	je     787f <fwp_args37+0x6f>
    78b5:	c3                   	ret
    78b6:	e9 d5 dd ff ff       	jmp    5690 <fwp_rc_wide_dup>
    78bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078c0 <fwp_caps37>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	48 83 ec 18          	sub    $0x18,%rsp
    78c8:	48 89 f8             	mov    %rdi,%rax
    78cb:	8b 7f 04             	mov    0x4(%rdi),%edi
    78ce:	85 ff                	test   %edi,%edi
    78d0:	0f 84 9a 00 00 00    	je     7970 <fwp_caps37+0xb0>
    78d6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    78da:	85 f6                	test   %esi,%esi
    78dc:	0f 85 9e 00 00 00    	jne    7980 <fwp_caps37+0xc0>
    78e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    78e7:	e8 24 f7 ff ff       	call   7010 <fwp_drop4>
    78ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78f1:	48 8b 0d 00 13 06 00 	mov    0x61300(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    78f8:	48 89 c2             	mov    %rax,%rdx
    78fb:	48 2b 15 ce 12 06 00 	sub    0x612ce(%rip),%rdx        # 68bd0 <fwp_heap+0x13b0>
    7902:	48 c1 e1 10          	shl    $0x10,%rcx
    7906:	48 39 ca             	cmp    %rcx,%rdx
    7909:	73 6d                	jae    7978 <fwp_caps37+0xb8>
    790b:	48 89 d1             	mov    %rdx,%rcx
    790e:	48 c1 e9 10          	shr    $0x10,%rcx
    7912:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7916:	48 8b 0d fb 12 06 00 	mov    0x612fb(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    791d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7921:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7925:	48 85 f6             	test   %rsi,%rsi
    7928:	74 4e                	je     7978 <fwp_caps37+0xb8>
    792a:	0f b6 39             	movzbl (%rcx),%edi
    792d:	40 80 ff 02          	cmp    $0x2,%dil
    7931:	0f 84 c9 00 00 00    	je     7a00 <fwp_caps37+0x140>
    7937:	40 80 ff 01          	cmp    $0x1,%dil
    793b:	75 3b                	jne    7978 <fwp_caps37+0xb8>
    793d:	8b 79 18             	mov    0x18(%rcx),%edi
    7940:	0f b7 d2             	movzwl %dx,%edx
    7943:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7946:	48 0f af d7          	imul   %rdi,%rdx
    794a:	48 c1 ea 20          	shr    $0x20,%rdx
    794e:	48 39 ca             	cmp    %rcx,%rdx
    7951:	73 25                	jae    7978 <fwp_caps37+0xb8>
    7953:	48 01 d6             	add    %rdx,%rsi
    7956:	80 3e 01             	cmpb   $0x1,(%rsi)
    7959:	75 1d                	jne    7978 <fwp_caps37+0xb8>
    795b:	48 89 c7             	mov    %rax,%rdi
    795e:	48 83 c4 18          	add    $0x18,%rsp
    7962:	e9 89 e0 ff ff       	jmp    59f0 <fwp_mem_free>
    7967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    796e:	00 00 
    7970:	85 f6                	test   %esi,%esi
    7972:	0f 84 79 ff ff ff    	je     78f1 <fwp_caps37+0x31>
    7978:	48 83 c4 18          	add    $0x18,%rsp
    797c:	c3                   	ret
    797d:	0f 1f 00             	nopl   (%rax)
    7980:	48 8b 05 71 12 06 00 	mov    0x61271(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    7987:	48 2b 3d 42 12 06 00 	sub    0x61242(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    798e:	48 c1 e0 10          	shl    $0x10,%rax
    7992:	48 39 c7             	cmp    %rax,%rdi
    7995:	73 e1                	jae    7978 <fwp_caps37+0xb8>
    7997:	48 89 f8             	mov    %rdi,%rax
    799a:	48 c1 e8 10          	shr    $0x10,%rax
    799e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    79a2:	48 8b 05 6f 12 06 00 	mov    0x6126f(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    79a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    79ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    79b1:	48 85 c0             	test   %rax,%rax
    79b4:	74 c2                	je     7978 <fwp_caps37+0xb8>
    79b6:	0f b6 0a             	movzbl (%rdx),%ecx
    79b9:	80 f9 02             	cmp    $0x2,%cl
    79bc:	74 52                	je     7a10 <fwp_caps37+0x150>
    79be:	80 f9 01             	cmp    $0x1,%cl
    79c1:	75 b5                	jne    7978 <fwp_caps37+0xb8>
    79c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79c6:	0f b7 ff             	movzwl %di,%edi
    79c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79cc:	48 0f af f9          	imul   %rcx,%rdi
    79d0:	48 c1 ef 20          	shr    $0x20,%rdi
    79d4:	48 39 d7             	cmp    %rdx,%rdi
    79d7:	73 9f                	jae    7978 <fwp_caps37+0xb8>
    79d9:	48 01 f8             	add    %rdi,%rax
    79dc:	0f b6 10             	movzbl (%rax),%edx
    79df:	84 d2                	test   %dl,%dl
    79e1:	74 95                	je     7978 <fwp_caps37+0xb8>
    79e3:	8b 0d ff 1a 06 00    	mov    0x61aff(%rip),%ecx        # 694e8 <iteration_active>
    79e9:	85 c9                	test   %ecx,%ecx
    79eb:	75 33                	jne    7a20 <fwp_caps37+0x160>
    79ed:	80 fa fd             	cmp    $0xfd,%dl
    79f0:	77 38                	ja     7a2a <fwp_caps37+0x16a>
    79f2:	83 c2 01             	add    $0x1,%edx
    79f5:	88 10                	mov    %dl,(%rax)
    79f7:	e9 7c ff ff ff       	jmp    7978 <fwp_caps37+0xb8>
    79fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7a00:	66 85 d2             	test   %dx,%dx
    7a03:	0f 85 6f ff ff ff    	jne    7978 <fwp_caps37+0xb8>
    7a09:	e9 48 ff ff ff       	jmp    7956 <fwp_caps37+0x96>
    7a0e:	66 90                	xchg   %ax,%ax
    7a10:	66 85 ff             	test   %di,%di
    7a13:	0f 85 5f ff ff ff    	jne    7978 <fwp_caps37+0xb8>
    7a19:	eb c1                	jmp    79dc <fwp_caps37+0x11c>
    7a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a20:	48 83 05 a8 1a 06 00 	addq   $0x1,0x61aa8(%rip)        # 694d0 <iteration_retains>
    7a27:	01 
    7a28:	eb c3                	jmp    79ed <fwp_caps37+0x12d>
    7a2a:	48 89 c7             	mov    %rax,%rdi
    7a2d:	48 83 c4 18          	add    $0x18,%rsp
    7a31:	e9 5a dc ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a3d:	00 00 00 

0000000000007a40 <fwp_drop0>:
    7a40:	f3 0f 1e fa          	endbr64
    7a44:	48 8b 15 ad 11 06 00 	mov    0x611ad(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7a4b:	48 89 f8             	mov    %rdi,%rax
    7a4e:	48 2b 05 7b 11 06 00 	sub    0x6117b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7a55:	48 c1 e2 10          	shl    $0x10,%rdx
    7a59:	48 39 d0             	cmp    %rdx,%rax
    7a5c:	0f 83 36 01 00 00    	jae    7b98 <fwp_drop0+0x158>
    7a62:	48 83 ec 18          	sub    $0x18,%rsp
    7a66:	48 8d 35 b3 fd 05 00 	lea    0x5fdb3(%rip),%rsi        # 67820 <fwp_heap>
    7a6d:	48 89 c2             	mov    %rax,%rdx
    7a70:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7a77:	48 c1 ea 10          	shr    $0x10,%rdx
    7a7b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a7f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7a83:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a87:	48 85 d2             	test   %rdx,%rdx
    7a8a:	74 42                	je     7ace <fwp_drop0+0x8e>
    7a8c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7a90:	41 80 f8 02          	cmp    $0x2,%r8b
    7a94:	74 42                	je     7ad8 <fwp_drop0+0x98>
    7a96:	41 80 f8 01          	cmp    $0x1,%r8b
    7a9a:	75 32                	jne    7ace <fwp_drop0+0x8e>
    7a9c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7aa0:	0f b7 c0             	movzwl %ax,%eax
    7aa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7aa6:	49 0f af c0          	imul   %r8,%rax
    7aaa:	48 c1 e8 20          	shr    $0x20,%rax
    7aae:	48 39 c8             	cmp    %rcx,%rax
    7ab1:	73 1b                	jae    7ace <fwp_drop0+0x8e>
    7ab3:	48 01 c2             	add    %rax,%rdx
    7ab6:	0f b6 02             	movzbl (%rdx),%eax
    7ab9:	84 c0                	test   %al,%al
    7abb:	74 11                	je     7ace <fwp_drop0+0x8e>
    7abd:	3c 01                	cmp    $0x1,%al
    7abf:	74 27                	je     7ae8 <fwp_drop0+0xa8>
    7ac1:	3c ff                	cmp    $0xff,%al
    7ac3:	0f 84 e7 00 00 00    	je     7bb0 <fwp_drop0+0x170>
    7ac9:	83 e8 01             	sub    $0x1,%eax
    7acc:	88 02                	mov    %al,(%rdx)
    7ace:	48 83 c4 18          	add    $0x18,%rsp
    7ad2:	c3                   	ret
    7ad3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ad8:	66 85 c0             	test   %ax,%ax
    7adb:	74 d9                	je     7ab6 <fwp_drop0+0x76>
    7add:	48 83 c4 18          	add    $0x18,%rsp
    7ae1:	c3                   	ret
    7ae2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ae8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7aef:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7af6:	48 89 f8             	mov    %rdi,%rax
    7af9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7afd:	48 29 c8             	sub    %rcx,%rax
    7b00:	48 c1 e2 10          	shl    $0x10,%rdx
    7b04:	48 39 d0             	cmp    %rdx,%rax
    7b07:	73 71                	jae    7b7a <fwp_drop0+0x13a>
    7b09:	49 89 c2             	mov    %rax,%r10
    7b0c:	49 c1 ea 10          	shr    $0x10,%r10
    7b10:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b14:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7b18:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7b1c:	4d 85 d2             	test   %r10,%r10
    7b1f:	74 59                	je     7b7a <fwp_drop0+0x13a>
    7b21:	45 0f b6 19          	movzbl (%r9),%r11d
    7b25:	41 80 fb 02          	cmp    $0x2,%r11b
    7b29:	74 75                	je     7ba0 <fwp_drop0+0x160>
    7b2b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b2f:	75 49                	jne    7b7a <fwp_drop0+0x13a>
    7b31:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7b35:	0f b7 c0             	movzwl %ax,%eax
    7b38:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7b3c:	49 0f af c3          	imul   %r11,%rax
    7b40:	48 c1 e8 20          	shr    $0x20,%rax
    7b44:	4c 39 c8             	cmp    %r9,%rax
    7b47:	73 31                	jae    7b7a <fwp_drop0+0x13a>
    7b49:	49 01 c2             	add    %rax,%r10
    7b4c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b50:	75 28                	jne    7b7a <fwp_drop0+0x13a>
    7b52:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7b57:	e8 94 de ff ff       	call   59f0 <fwp_mem_free>
    7b5c:	48 8d 35 bd fc 05 00 	lea    0x5fcbd(%rip),%rsi        # 67820 <fwp_heap>
    7b63:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7b68:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b6f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b76:	48 c1 e2 10          	shl    $0x10,%rdx
    7b7a:	4c 89 c0             	mov    %r8,%rax
    7b7d:	48 29 c8             	sub    %rcx,%rax
    7b80:	48 39 d0             	cmp    %rdx,%rax
    7b83:	0f 83 45 ff ff ff    	jae    7ace <fwp_drop0+0x8e>
    7b89:	4c 89 c7             	mov    %r8,%rdi
    7b8c:	e9 dc fe ff ff       	jmp    7a6d <fwp_drop0+0x2d>
    7b91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b98:	c3                   	ret
    7b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ba0:	66 85 c0             	test   %ax,%ax
    7ba3:	75 d5                	jne    7b7a <fwp_drop0+0x13a>
    7ba5:	eb a5                	jmp    7b4c <fwp_drop0+0x10c>
    7ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bae:	00 00 
    7bb0:	48 89 d0             	mov    %rdx,%rax
    7bb3:	48 c1 e8 11          	shr    $0x11,%rax
    7bb7:	48 31 d0             	xor    %rdx,%rax
    7bba:	48 89 c1             	mov    %rax,%rcx
    7bbd:	48 c1 e9 09          	shr    $0x9,%rcx
    7bc1:	48 31 c8             	xor    %rcx,%rax
    7bc4:	0f b6 c8             	movzbl %al,%ecx
    7bc7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7bce:	00 
    7bcf:	48 85 c0             	test   %rax,%rax
    7bd2:	75 15                	jne    7be9 <fwp_drop0+0x1a9>
    7bd4:	eb 4e                	jmp    7c24 <fwp_drop0+0x1e4>
    7bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bdd:	00 00 00 
    7be0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	74 3b                	je     7c24 <fwp_drop0+0x1e4>
    7be9:	48 89 c1             	mov    %rax,%rcx
    7bec:	48 39 10             	cmp    %rdx,(%rax)
    7bef:	75 ef                	jne    7be0 <fwp_drop0+0x1a0>
    7bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c04:	0f 85 c4 fe ff ff    	jne    7ace <fwp_drop0+0x8e>
    7c0a:	48 89 d7             	mov    %rdx,%rdi
    7c0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c12:	e8 99 db ff ff       	call   57b0 <fwp_rc_forget_slot>
    7c17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c1f:	e9 aa fe ff ff       	jmp    7ace <fwp_drop0+0x8e>
    7c24:	48 8d 3d 7d 3d 00 00 	lea    0x3d7d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7c2b:	e8 00 c8 ff ff       	call   4430 <fwp_trap>

0000000000007c30 <fwp_drop1>:
    7c30:	f3 0f 1e fa          	endbr64
    7c34:	48 8b 15 bd 0f 06 00 	mov    0x60fbd(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7c3b:	48 89 f8             	mov    %rdi,%rax
    7c3e:	48 2b 05 8b 0f 06 00 	sub    0x60f8b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7c45:	48 c1 e2 10          	shl    $0x10,%rdx
    7c49:	48 39 d0             	cmp    %rdx,%rax
    7c4c:	0f 83 36 01 00 00    	jae    7d88 <fwp_drop1+0x158>
    7c52:	48 83 ec 18          	sub    $0x18,%rsp
    7c56:	48 8d 35 c3 fb 05 00 	lea    0x5fbc3(%rip),%rsi        # 67820 <fwp_heap>
    7c5d:	48 89 c2             	mov    %rax,%rdx
    7c60:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7c67:	48 c1 ea 10          	shr    $0x10,%rdx
    7c6b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c6f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7c73:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c77:	48 85 d2             	test   %rdx,%rdx
    7c7a:	74 42                	je     7cbe <fwp_drop1+0x8e>
    7c7c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7c80:	41 80 f8 02          	cmp    $0x2,%r8b
    7c84:	74 42                	je     7cc8 <fwp_drop1+0x98>
    7c86:	41 80 f8 01          	cmp    $0x1,%r8b
    7c8a:	75 32                	jne    7cbe <fwp_drop1+0x8e>
    7c8c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7c90:	0f b7 c0             	movzwl %ax,%eax
    7c93:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c96:	49 0f af c0          	imul   %r8,%rax
    7c9a:	48 c1 e8 20          	shr    $0x20,%rax
    7c9e:	48 39 c8             	cmp    %rcx,%rax
    7ca1:	73 1b                	jae    7cbe <fwp_drop1+0x8e>
    7ca3:	48 01 c2             	add    %rax,%rdx
    7ca6:	0f b6 02             	movzbl (%rdx),%eax
    7ca9:	84 c0                	test   %al,%al
    7cab:	74 11                	je     7cbe <fwp_drop1+0x8e>
    7cad:	3c 01                	cmp    $0x1,%al
    7caf:	74 27                	je     7cd8 <fwp_drop1+0xa8>
    7cb1:	3c ff                	cmp    $0xff,%al
    7cb3:	0f 84 e7 00 00 00    	je     7da0 <fwp_drop1+0x170>
    7cb9:	83 e8 01             	sub    $0x1,%eax
    7cbc:	88 02                	mov    %al,(%rdx)
    7cbe:	48 83 c4 18          	add    $0x18,%rsp
    7cc2:	c3                   	ret
    7cc3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cc8:	66 85 c0             	test   %ax,%ax
    7ccb:	74 d9                	je     7ca6 <fwp_drop1+0x76>
    7ccd:	48 83 c4 18          	add    $0x18,%rsp
    7cd1:	c3                   	ret
    7cd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cd8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cdf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ce6:	48 89 f8             	mov    %rdi,%rax
    7ce9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7ced:	48 29 c8             	sub    %rcx,%rax
    7cf0:	48 c1 e2 10          	shl    $0x10,%rdx
    7cf4:	48 39 d0             	cmp    %rdx,%rax
    7cf7:	73 71                	jae    7d6a <fwp_drop1+0x13a>
    7cf9:	49 89 c2             	mov    %rax,%r10
    7cfc:	49 c1 ea 10          	shr    $0x10,%r10
    7d00:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d04:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d08:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d0c:	4d 85 d2             	test   %r10,%r10
    7d0f:	74 59                	je     7d6a <fwp_drop1+0x13a>
    7d11:	45 0f b6 19          	movzbl (%r9),%r11d
    7d15:	41 80 fb 02          	cmp    $0x2,%r11b
    7d19:	74 75                	je     7d90 <fwp_drop1+0x160>
    7d1b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d1f:	75 49                	jne    7d6a <fwp_drop1+0x13a>
    7d21:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d25:	0f b7 c0             	movzwl %ax,%eax
    7d28:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d2c:	49 0f af c3          	imul   %r11,%rax
    7d30:	48 c1 e8 20          	shr    $0x20,%rax
    7d34:	4c 39 c8             	cmp    %r9,%rax
    7d37:	73 31                	jae    7d6a <fwp_drop1+0x13a>
    7d39:	49 01 c2             	add    %rax,%r10
    7d3c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d40:	75 28                	jne    7d6a <fwp_drop1+0x13a>
    7d42:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7d47:	e8 a4 dc ff ff       	call   59f0 <fwp_mem_free>
    7d4c:	48 8d 35 cd fa 05 00 	lea    0x5facd(%rip),%rsi        # 67820 <fwp_heap>
    7d53:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7d58:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d5f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d66:	48 c1 e2 10          	shl    $0x10,%rdx
    7d6a:	4c 89 c0             	mov    %r8,%rax
    7d6d:	48 29 c8             	sub    %rcx,%rax
    7d70:	48 39 d0             	cmp    %rdx,%rax
    7d73:	0f 83 45 ff ff ff    	jae    7cbe <fwp_drop1+0x8e>
    7d79:	4c 89 c7             	mov    %r8,%rdi
    7d7c:	e9 dc fe ff ff       	jmp    7c5d <fwp_drop1+0x2d>
    7d81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d88:	c3                   	ret
    7d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d90:	66 85 c0             	test   %ax,%ax
    7d93:	75 d5                	jne    7d6a <fwp_drop1+0x13a>
    7d95:	eb a5                	jmp    7d3c <fwp_drop1+0x10c>
    7d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d9e:	00 00 
    7da0:	48 89 d0             	mov    %rdx,%rax
    7da3:	48 c1 e8 11          	shr    $0x11,%rax
    7da7:	48 31 d0             	xor    %rdx,%rax
    7daa:	48 89 c1             	mov    %rax,%rcx
    7dad:	48 c1 e9 09          	shr    $0x9,%rcx
    7db1:	48 31 c8             	xor    %rcx,%rax
    7db4:	0f b6 c8             	movzbl %al,%ecx
    7db7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7dbe:	00 
    7dbf:	48 85 c0             	test   %rax,%rax
    7dc2:	75 25                	jne    7de9 <fwp_drop1+0x1b9>
    7dc4:	eb 5e                	jmp    7e24 <fwp_drop1+0x1f4>
    7dc6:	0f 1f 40 00          	nopl   0x0(%rax)
    7dca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dd1:	00 00 00 00 
    7dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ddc:	00 00 00 00 
    7de0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7de4:	48 85 c0             	test   %rax,%rax
    7de7:	74 3b                	je     7e24 <fwp_drop1+0x1f4>
    7de9:	48 89 c1             	mov    %rax,%rcx
    7dec:	48 39 10             	cmp    %rdx,(%rax)
    7def:	75 ef                	jne    7de0 <fwp_drop1+0x1b0>
    7df1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7df5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7df9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7dfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e04:	0f 85 b4 fe ff ff    	jne    7cbe <fwp_drop1+0x8e>
    7e0a:	48 89 d7             	mov    %rdx,%rdi
    7e0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e12:	e8 99 d9 ff ff       	call   57b0 <fwp_rc_forget_slot>
    7e17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e1f:	e9 9a fe ff ff       	jmp    7cbe <fwp_drop1+0x8e>
    7e24:	48 8d 3d 7d 3b 00 00 	lea    0x3b7d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7e2b:	e8 00 c6 ff ff       	call   4430 <fwp_trap>

0000000000007e30 <fwp_drop10>:
    7e30:	48 8b 0d c1 0d 06 00 	mov    0x60dc1(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7e37:	48 89 f8             	mov    %rdi,%rax
    7e3a:	48 2b 05 8f 0d 06 00 	sub    0x60d8f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7e41:	48 c1 e1 10          	shl    $0x10,%rcx
    7e45:	48 39 c8             	cmp    %rcx,%rax
    7e48:	0f 83 c2 01 00 00    	jae    8010 <fwp_drop10+0x1e0>
    7e4e:	48 83 ec 18          	sub    $0x18,%rsp
    7e52:	48 89 fa             	mov    %rdi,%rdx
    7e55:	48 8d 35 c4 f9 05 00 	lea    0x5f9c4(%rip),%rsi        # 67820 <fwp_heap>
    7e5c:	48 89 c1             	mov    %rax,%rcx
    7e5f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7e66:	48 c1 e9 10          	shr    $0x10,%rcx
    7e6a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e6e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7e72:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7e76:	48 85 c9             	test   %rcx,%rcx
    7e79:	74 46                	je     7ec1 <fwp_drop10+0x91>
    7e7b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7e7f:	41 80 f9 02          	cmp    $0x2,%r9b
    7e83:	0f 84 d7 00 00 00    	je     7f60 <fwp_drop10+0x130>
    7e89:	41 80 f9 01          	cmp    $0x1,%r9b
    7e8d:	75 32                	jne    7ec1 <fwp_drop10+0x91>
    7e8f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7e93:	0f b7 c0             	movzwl %ax,%eax
    7e96:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7e99:	49 0f af c1          	imul   %r9,%rax
    7e9d:	48 c1 e8 20          	shr    $0x20,%rax
    7ea1:	48 39 f8             	cmp    %rdi,%rax
    7ea4:	73 1b                	jae    7ec1 <fwp_drop10+0x91>
    7ea6:	48 01 c1             	add    %rax,%rcx
    7ea9:	0f b6 01             	movzbl (%rcx),%eax
    7eac:	84 c0                	test   %al,%al
    7eae:	74 11                	je     7ec1 <fwp_drop10+0x91>
    7eb0:	3c 01                	cmp    $0x1,%al
    7eb2:	74 1c                	je     7ed0 <fwp_drop10+0xa0>
    7eb4:	3c ff                	cmp    $0xff,%al
    7eb6:	0f 84 5c 01 00 00    	je     8018 <fwp_drop10+0x1e8>
    7ebc:	83 e8 01             	sub    $0x1,%eax
    7ebf:	88 01                	mov    %al,(%rcx)
    7ec1:	48 83 c4 18          	add    $0x18,%rsp
    7ec5:	c3                   	ret
    7ec6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ecd:	00 00 00 
    7ed0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7ed7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7ede:	48 89 d0             	mov    %rdx,%rax
    7ee1:	49 89 d1             	mov    %rdx,%r9
    7ee4:	48 c1 e1 10          	shl    $0x10,%rcx
    7ee8:	48 29 f8             	sub    %rdi,%rax
    7eeb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7eef:	78 7f                	js     7f70 <fwp_drop10+0x140>
    7ef1:	48 39 c8             	cmp    %rcx,%rax
    7ef4:	73 cb                	jae    7ec1 <fwp_drop10+0x91>
    7ef6:	48 89 c1             	mov    %rax,%rcx
    7ef9:	48 c1 e9 10          	shr    $0x10,%rcx
    7efd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f01:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7f05:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f09:	48 85 f6             	test   %rsi,%rsi
    7f0c:	74 b3                	je     7ec1 <fwp_drop10+0x91>
    7f0e:	0f b6 39             	movzbl (%rcx),%edi
    7f11:	40 80 ff 02          	cmp    $0x2,%dil
    7f15:	74 39                	je     7f50 <fwp_drop10+0x120>
    7f17:	40 80 ff 01          	cmp    $0x1,%dil
    7f1b:	75 a4                	jne    7ec1 <fwp_drop10+0x91>
    7f1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7f20:	0f b7 c0             	movzwl %ax,%eax
    7f23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f26:	48 0f af c7          	imul   %rdi,%rax
    7f2a:	48 c1 e8 20          	shr    $0x20,%rax
    7f2e:	48 39 c8             	cmp    %rcx,%rax
    7f31:	73 8e                	jae    7ec1 <fwp_drop10+0x91>
    7f33:	48 01 c6             	add    %rax,%rsi
    7f36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f39:	75 86                	jne    7ec1 <fwp_drop10+0x91>
    7f3b:	48 89 d7             	mov    %rdx,%rdi
    7f3e:	48 83 c4 18          	add    $0x18,%rsp
    7f42:	e9 a9 da ff ff       	jmp    59f0 <fwp_mem_free>
    7f47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f4e:	00 00 
    7f50:	66 85 c0             	test   %ax,%ax
    7f53:	74 e1                	je     7f36 <fwp_drop10+0x106>
    7f55:	48 83 c4 18          	add    $0x18,%rsp
    7f59:	c3                   	ret
    7f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f60:	66 85 c0             	test   %ax,%ax
    7f63:	0f 84 40 ff ff ff    	je     7ea9 <fwp_drop10+0x79>
    7f69:	48 83 c4 18          	add    $0x18,%rsp
    7f6d:	c3                   	ret
    7f6e:	66 90                	xchg   %ax,%ax
    7f70:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7f74:	48 39 c8             	cmp    %rcx,%rax
    7f77:	73 74                	jae    7fed <fwp_drop10+0x1bd>
    7f79:	49 89 c2             	mov    %rax,%r10
    7f7c:	49 c1 ea 10          	shr    $0x10,%r10
    7f80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7f84:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7f88:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7f8c:	4d 85 d2             	test   %r10,%r10
    7f8f:	74 5c                	je     7fed <fwp_drop10+0x1bd>
    7f91:	45 0f b6 18          	movzbl (%r8),%r11d
    7f95:	41 80 fb 02          	cmp    $0x2,%r11b
    7f99:	74 6d                	je     8008 <fwp_drop10+0x1d8>
    7f9b:	41 80 fb 01          	cmp    $0x1,%r11b
    7f9f:	75 4c                	jne    7fed <fwp_drop10+0x1bd>
    7fa1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7fa5:	0f b7 c0             	movzwl %ax,%eax
    7fa8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7fac:	49 0f af c3          	imul   %r11,%rax
    7fb0:	48 c1 e8 20          	shr    $0x20,%rax
    7fb4:	4c 39 c0             	cmp    %r8,%rax
    7fb7:	73 34                	jae    7fed <fwp_drop10+0x1bd>
    7fb9:	49 01 c2             	add    %rax,%r10
    7fbc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7fc0:	75 2b                	jne    7fed <fwp_drop10+0x1bd>
    7fc2:	4c 89 cf             	mov    %r9,%rdi
    7fc5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7fca:	e8 21 da ff ff       	call   59f0 <fwp_mem_free>
    7fcf:	48 8d 35 4a f8 05 00 	lea    0x5f84a(%rip),%rsi        # 67820 <fwp_heap>
    7fd6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7fdb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7fe2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7fe9:	48 c1 e1 10          	shl    $0x10,%rcx
    7fed:	48 89 d0             	mov    %rdx,%rax
    7ff0:	48 29 f8             	sub    %rdi,%rax
    7ff3:	48 39 c8             	cmp    %rcx,%rax
    7ff6:	0f 82 60 fe ff ff    	jb     7e5c <fwp_drop10+0x2c>
    7ffc:	e9 c0 fe ff ff       	jmp    7ec1 <fwp_drop10+0x91>
    8001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8008:	66 85 c0             	test   %ax,%ax
    800b:	75 e0                	jne    7fed <fwp_drop10+0x1bd>
    800d:	eb ad                	jmp    7fbc <fwp_drop10+0x18c>
    800f:	90                   	nop
    8010:	c3                   	ret
    8011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8018:	48 89 c8             	mov    %rcx,%rax
    801b:	48 c1 e8 11          	shr    $0x11,%rax
    801f:	48 31 c8             	xor    %rcx,%rax
    8022:	48 89 c2             	mov    %rax,%rdx
    8025:	48 c1 ea 09          	shr    $0x9,%rdx
    8029:	48 31 d0             	xor    %rdx,%rax
    802c:	0f b6 d0             	movzbl %al,%edx
    802f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8036:	00 
    8037:	48 85 c0             	test   %rax,%rax
    803a:	75 0d                	jne    8049 <fwp_drop10+0x219>
    803c:	eb 46                	jmp    8084 <fwp_drop10+0x254>
    803e:	66 90                	xchg   %ax,%ax
    8040:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8044:	48 85 c0             	test   %rax,%rax
    8047:	74 3b                	je     8084 <fwp_drop10+0x254>
    8049:	48 89 c2             	mov    %rax,%rdx
    804c:	48 39 08             	cmp    %rcx,(%rax)
    804f:	75 ef                	jne    8040 <fwp_drop10+0x210>
    8051:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8055:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8059:	48 89 50 08          	mov    %rdx,0x8(%rax)
    805d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8064:	0f 85 57 fe ff ff    	jne    7ec1 <fwp_drop10+0x91>
    806a:	48 89 cf             	mov    %rcx,%rdi
    806d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8072:	e8 39 d7 ff ff       	call   57b0 <fwp_rc_forget_slot>
    8077:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    807c:	c6 01 fe             	movb   $0xfe,(%rcx)
    807f:	e9 3d fe ff ff       	jmp    7ec1 <fwp_drop10+0x91>
    8084:	48 8d 3d 1d 39 00 00 	lea    0x391d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    808b:	e8 a0 c3 ff ff       	call   4430 <fwp_trap>

0000000000008090 <f37>:
    8090:	41 57                	push   %r15
    8092:	41 56                	push   %r14
    8094:	41 55                	push   %r13
    8096:	41 54                	push   %r12
    8098:	55                   	push   %rbp
    8099:	53                   	push   %rbx
    809a:	48 83 ec 38          	sub    $0x38,%rsp
    809e:	48 8b 15 53 0b 06 00 	mov    0x60b53(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    80a5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    80aa:	48 c1 e2 10          	shl    $0x10,%rdx
    80ae:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    80b5:	00 00 
    80b7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    80bc:	48 8b 0d 0d 0b 06 00 	mov    0x60b0d(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    80c3:	48 85 ff             	test   %rdi,%rdi
    80c6:	0f 84 6e 03 00 00    	je     843a <f37+0x3aa>
    80cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    80d1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    80d5:	4c 89 e8             	mov    %r13,%rax
    80d8:	48 29 c8             	sub    %rcx,%rax
    80db:	48 39 d0             	cmp    %rdx,%rax
    80de:	0f 83 3c 03 00 00    	jae    8420 <f37+0x390>
    80e4:	48 89 c2             	mov    %rax,%rdx
    80e7:	48 c1 ea 10          	shr    $0x10,%rdx
    80eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80ef:	48 8b 15 22 0b 06 00 	mov    0x60b22(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    80f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80fa:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80fe:	48 85 ff             	test   %rdi,%rdi
    8101:	0f 84 19 03 00 00    	je     8420 <f37+0x390>
    8107:	0f b6 0a             	movzbl (%rdx),%ecx
    810a:	80 f9 02             	cmp    $0x2,%cl
    810d:	0f 84 9d 02 00 00    	je     83b0 <f37+0x320>
    8113:	80 f9 01             	cmp    $0x1,%cl
    8116:	75 24                	jne    813c <f37+0xac>
    8118:	8b 4a 18             	mov    0x18(%rdx),%ecx
    811b:	0f b7 c0             	movzwl %ax,%eax
    811e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8121:	48 0f af c1          	imul   %rcx,%rax
    8125:	48 c1 e8 20          	shr    $0x20,%rax
    8129:	48 39 d0             	cmp    %rdx,%rax
    812c:	73 0e                	jae    813c <f37+0xac>
    812e:	48 01 c7             	add    %rax,%rdi
    8131:	0f b6 07             	movzbl (%rdi),%eax
    8134:	84 c0                	test   %al,%al
    8136:	0f 85 94 02 00 00    	jne    83d0 <f37+0x340>
    813c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8141:	48 8b 40 10          	mov    0x10(%rax),%rax
    8145:	ba 01 00 00 00       	mov    $0x1,%edx
    814a:	48 85 c0             	test   %rax,%rax
    814d:	74 0e                	je     815d <f37+0xcd>
    814f:	90                   	nop
    8150:	48 8b 40 10          	mov    0x10(%rax),%rax
    8154:	48 83 c2 01          	add    $0x1,%rdx
    8158:	48 85 c0             	test   %rax,%rax
    815b:	75 f3                	jne    8150 <f37+0xc0>
    815d:	4d 85 ed             	test   %r13,%r13
    8160:	0f 84 ea 02 00 00    	je     8450 <f37+0x3c0>
    8166:	4c 89 e8             	mov    %r13,%rax
    8169:	31 db                	xor    %ebx,%ebx
    816b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8170:	48 8b 40 10          	mov    0x10(%rax),%rax
    8174:	48 83 c3 01          	add    $0x1,%rbx
    8178:	48 85 c0             	test   %rax,%rax
    817b:	75 f3                	jne    8170 <f37+0xe0>
    817d:	48 39 d3             	cmp    %rdx,%rbx
    8180:	48 0f 47 da          	cmova  %rdx,%rbx
    8184:	48 89 d8             	mov    %rbx,%rax
    8187:	48 c1 e8 3c          	shr    $0x3c,%rax
    818b:	0f 85 cd 03 00 00    	jne    855e <f37+0x4ce>
    8191:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8195:	be 02 00 00 00       	mov    $0x2,%esi
    819a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    81a1:	00 
    81a2:	e8 49 dd ff ff       	call   5ef0 <fwp_heap_alloc>
    81a7:	48 89 28             	mov    %rbp,(%rax)
    81aa:	48 8b 15 47 0a 06 00 	mov    0x60a47(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    81b1:	49 89 c4             	mov    %rax,%r12
    81b4:	48 2b 05 15 0a 06 00 	sub    0x60a15(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    81bb:	48 c1 e2 10          	shl    $0x10,%rdx
    81bf:	48 39 d0             	cmp    %rdx,%rax
    81c2:	73 57                	jae    821b <f37+0x18b>
    81c4:	48 89 c2             	mov    %rax,%rdx
    81c7:	48 c1 ea 10          	shr    $0x10,%rdx
    81cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81cf:	48 8b 15 42 0a 06 00 	mov    0x60a42(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    81d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81da:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81de:	48 85 ed             	test   %rbp,%rbp
    81e1:	74 38                	je     821b <f37+0x18b>
    81e3:	0f b6 0a             	movzbl (%rdx),%ecx
    81e6:	80 f9 02             	cmp    $0x2,%cl
    81e9:	0f 84 21 02 00 00    	je     8410 <f37+0x380>
    81ef:	80 f9 01             	cmp    $0x1,%cl
    81f2:	75 27                	jne    821b <f37+0x18b>
    81f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81f7:	0f b7 c0             	movzwl %ax,%eax
    81fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81fd:	48 0f af c1          	imul   %rcx,%rax
    8201:	48 c1 e8 20          	shr    $0x20,%rax
    8205:	48 39 d0             	cmp    %rdx,%rax
    8208:	73 11                	jae    821b <f37+0x18b>
    820a:	48 01 c5             	add    %rax,%rbp
    820d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8211:	0f 84 a7 02 00 00    	je     84be <f37+0x42e>
    8217:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    821b:	48 85 db             	test   %rbx,%rbx
    821e:	74 5d                	je     827d <f37+0x1ed>
    8220:	48 c1 e3 04          	shl    $0x4,%rbx
    8224:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8229:	4c 89 e5             	mov    %r12,%rbp
    822c:	4d 89 ef             	mov    %r13,%r15
    822f:	4c 01 e3             	add    %r12,%rbx
    8232:	0f 1f 00             	nopl   (%rax)
    8235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    823c:	00 00 00 00 
    8240:	49 8b 46 08          	mov    0x8(%r14),%rax
    8244:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8248:	48 83 c5 10          	add    $0x10,%rbp
    824c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8251:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8255:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8259:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    825e:	e8 ed e3 ff ff       	call   6650 <w120>
    8263:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8268:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    826c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8270:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8274:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8278:	48 39 eb             	cmp    %rbp,%rbx
    827b:	75 c3                	jne    8240 <f37+0x1b0>
    827d:	4c 89 ef             	mov    %r13,%rdi
    8280:	31 db                	xor    %ebx,%ebx
    8282:	e8 89 ed ff ff       	call   7010 <fwp_drop4>
    8287:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    828c:	e8 7f ed ff ff       	call   7010 <fwp_drop4>
    8291:	4d 8b 2c 24          	mov    (%r12),%r13
    8295:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8299:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    82a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    82a7:	4d 85 ed             	test   %r13,%r13
    82aa:	74 3f                	je     82eb <f37+0x25b>
    82ac:	0f 1f 40 00          	nopl   0x0(%rax)
    82b0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    82b7:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    82bc:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    82c3:	00 f0 3f 
    82c6:	48 83 c3 02          	add    $0x2,%rbx
    82ca:	48 89 ce             	mov    %rcx,%rsi
    82cd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    82d3:	e8 f8 df ff ff       	call   62d0 <fwp_p_ad_push>
    82d8:	4c 39 eb             	cmp    %r13,%rbx
    82db:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    82e1:	48 89 c7             	mov    %rax,%rdi
    82e4:	72 ca                	jb     82b0 <f37+0x220>
    82e6:	66 49 0f 7e c5       	movq   %xmm0,%r13
    82eb:	4c 89 e7             	mov    %r12,%rdi
    82ee:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    82f3:	e8 38 fb ff ff       	call   7e30 <fwp_drop10>
    82f8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82fd:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8302:	31 ff                	xor    %edi,%edi
    8304:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    8309:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    830e:	e8 cd dd ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    8313:	48 8b 15 de 08 06 00 	mov    0x608de(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    831a:	48 89 c5             	mov    %rax,%rbp
    831d:	48 2b 05 ac 08 06 00 	sub    0x608ac(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8324:	48 c1 e2 10          	shl    $0x10,%rdx
    8328:	48 39 d0             	cmp    %rdx,%rax
    832b:	73 55                	jae    8382 <f37+0x2f2>
    832d:	48 89 c2             	mov    %rax,%rdx
    8330:	48 c1 ea 10          	shr    $0x10,%rdx
    8334:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8338:	48 8b 15 d9 08 06 00 	mov    0x608d9(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    833f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8343:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8347:	48 85 db             	test   %rbx,%rbx
    834a:	74 36                	je     8382 <f37+0x2f2>
    834c:	0f b6 0a             	movzbl (%rdx),%ecx
    834f:	80 f9 02             	cmp    $0x2,%cl
    8352:	0f 84 a8 00 00 00    	je     8400 <f37+0x370>
    8358:	80 f9 01             	cmp    $0x1,%cl
    835b:	75 25                	jne    8382 <f37+0x2f2>
    835d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8360:	0f b7 c0             	movzwl %ax,%eax
    8363:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8366:	48 0f af c1          	imul   %rcx,%rax
    836a:	48 c1 e8 20          	shr    $0x20,%rax
    836e:	48 39 d0             	cmp    %rdx,%rax
    8371:	73 0f                	jae    8382 <f37+0x2f2>
    8373:	48 01 c3             	add    %rax,%rbx
    8376:	80 3b ff             	cmpb   $0xff,(%rbx)
    8379:	0f 84 32 01 00 00    	je     84b1 <f37+0x421>
    837f:	c6 03 01             	movb   $0x1,(%rbx)
    8382:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8387:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    838e:	00 00 
    8390:	0f 85 d4 01 00 00    	jne    856a <f37+0x4da>
    8396:	48 83 c4 38          	add    $0x38,%rsp
    839a:	48 89 e8             	mov    %rbp,%rax
    839d:	5b                   	pop    %rbx
    839e:	5d                   	pop    %rbp
    839f:	41 5c                	pop    %r12
    83a1:	41 5d                	pop    %r13
    83a3:	41 5e                	pop    %r14
    83a5:	41 5f                	pop    %r15
    83a7:	c3                   	ret
    83a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    83af:	00 
    83b0:	66 85 c0             	test   %ax,%ax
    83b3:	0f 85 83 fd ff ff    	jne    813c <f37+0xac>
    83b9:	0f b6 07             	movzbl (%rdi),%eax
    83bc:	84 c0                	test   %al,%al
    83be:	0f 84 78 fd ff ff    	je     813c <f37+0xac>
    83c4:	90                   	nop
    83c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83cc:	00 00 00 00 
    83d0:	8b 15 12 11 06 00    	mov    0x61112(%rip),%edx        # 694e8 <iteration_active>
    83d6:	85 d2                	test   %edx,%edx
    83d8:	75 56                	jne    8430 <f37+0x3a0>
    83da:	3c fd                	cmp    $0xfd,%al
    83dc:	0f 87 4b 01 00 00    	ja     852d <f37+0x49d>
    83e2:	83 c0 01             	add    $0x1,%eax
    83e5:	88 07                	mov    %al,(%rdi)
    83e7:	31 d2                	xor    %edx,%edx
    83e9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    83ef:	0f 85 47 fd ff ff    	jne    813c <f37+0xac>
    83f5:	e9 63 fd ff ff       	jmp    815d <f37+0xcd>
    83fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8400:	66 85 c0             	test   %ax,%ax
    8403:	0f 85 79 ff ff ff    	jne    8382 <f37+0x2f2>
    8409:	e9 68 ff ff ff       	jmp    8376 <f37+0x2e6>
    840e:	66 90                	xchg   %ax,%ax
    8410:	66 85 c0             	test   %ax,%ax
    8413:	0f 85 02 fe ff ff    	jne    821b <f37+0x18b>
    8419:	e9 ef fd ff ff       	jmp    820d <f37+0x17d>
    841e:	66 90                	xchg   %ax,%ax
    8420:	4c 89 e8             	mov    %r13,%rax
    8423:	e9 1d fd ff ff       	jmp    8145 <f37+0xb5>
    8428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    842f:	00 
    8430:	48 83 05 98 10 06 00 	addq   $0x1,0x61098(%rip)        # 694d0 <iteration_retains>
    8437:	01 
    8438:	eb a0                	jmp    83da <f37+0x34a>
    843a:	48 f7 d9             	neg    %rcx
    843d:	48 39 d1             	cmp    %rdx,%rcx
    8440:	0f 82 85 00 00 00    	jb     84cb <f37+0x43b>
    8446:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    844d:	00 00 00 
    8450:	be 02 00 00 00       	mov    $0x2,%esi
    8455:	bf 08 00 00 00       	mov    $0x8,%edi
    845a:	e8 91 da ff ff       	call   5ef0 <fwp_heap_alloc>
    845f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8466:	48 8b 15 8b 07 06 00 	mov    0x6078b(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    846d:	49 89 c4             	mov    %rax,%r12
    8470:	48 2b 05 59 07 06 00 	sub    0x60759(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8477:	48 c1 e2 10          	shl    $0x10,%rdx
    847b:	48 39 d0             	cmp    %rdx,%rax
    847e:	0f 83 b3 00 00 00    	jae    8537 <f37+0x4a7>
    8484:	48 89 c2             	mov    %rax,%rdx
    8487:	45 31 ed             	xor    %r13d,%r13d
    848a:	48 c1 ea 10          	shr    $0x10,%rdx
    848e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8492:	48 8b 15 7f 07 06 00 	mov    0x6077f(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8499:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    849d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84a1:	48 85 ed             	test   %rbp,%rbp
    84a4:	0f 84 d3 fd ff ff    	je     827d <f37+0x1ed>
    84aa:	31 db                	xor    %ebx,%ebx
    84ac:	e9 32 fd ff ff       	jmp    81e3 <f37+0x153>
    84b1:	48 89 df             	mov    %rbx,%rdi
    84b4:	e8 f7 d2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    84b9:	e9 c1 fe ff ff       	jmp    837f <f37+0x2ef>
    84be:	48 89 ef             	mov    %rbp,%rdi
    84c1:	e8 ea d2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    84c6:	e9 4c fd ff ff       	jmp    8217 <f37+0x187>
    84cb:	48 89 c8             	mov    %rcx,%rax
    84ce:	48 c1 e8 10          	shr    $0x10,%rax
    84d2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    84d6:	48 8b 05 3b 07 06 00 	mov    0x6073b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    84dd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    84e1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    84e5:	48 85 ff             	test   %rdi,%rdi
    84e8:	0f 84 62 ff ff ff    	je     8450 <f37+0x3c0>
    84ee:	0f b6 02             	movzbl (%rdx),%eax
    84f1:	3c 02                	cmp    $0x2,%al
    84f3:	74 4a                	je     853f <f37+0x4af>
    84f5:	3c 01                	cmp    $0x1,%al
    84f7:	0f 85 53 ff ff ff    	jne    8450 <f37+0x3c0>
    84fd:	0f b7 c1             	movzwl %cx,%eax
    8500:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8503:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8506:	48 0f af c1          	imul   %rcx,%rax
    850a:	48 c1 e8 20          	shr    $0x20,%rax
    850e:	48 39 d0             	cmp    %rdx,%rax
    8511:	0f 83 39 ff ff ff    	jae    8450 <f37+0x3c0>
    8517:	48 01 c7             	add    %rax,%rdi
    851a:	0f b6 07             	movzbl (%rdi),%eax
    851d:	84 c0                	test   %al,%al
    851f:	0f 84 2b ff ff ff    	je     8450 <f37+0x3c0>
    8525:	45 31 ed             	xor    %r13d,%r13d
    8528:	e9 a3 fe ff ff       	jmp    83d0 <f37+0x340>
    852d:	e8 5e d1 ff ff       	call   5690 <fwp_rc_wide_dup>
    8532:	e9 b0 fe ff ff       	jmp    83e7 <f37+0x357>
    8537:	45 31 ed             	xor    %r13d,%r13d
    853a:	e9 3e fd ff ff       	jmp    827d <f37+0x1ed>
    853f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8545:	49 89 cd             	mov    %rcx,%r13
    8548:	0f 85 02 ff ff ff    	jne    8450 <f37+0x3c0>
    854e:	0f b6 07             	movzbl (%rdi),%eax
    8551:	84 c0                	test   %al,%al
    8553:	0f 85 77 fe ff ff    	jne    83d0 <f37+0x340>
    8559:	e9 f2 fe ff ff       	jmp    8450 <f37+0x3c0>
    855e:	48 8d 3d 86 2c 00 00 	lea    0x2c86(%rip),%rdi        # b1eb <_IO_stdin_used+0x1eb>
    8565:	e8 c6 be ff ff       	call   4430 <fwp_trap>
    856a:	e8 e1 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    856f:	90                   	nop

0000000000008570 <fwp_owned_entry37>:
    8570:	f3 0f 1e fa          	endbr64
    8574:	48 8b 3f             	mov    (%rdi),%rdi
    8577:	e9 14 fb ff ff       	jmp    8090 <f37>
    857c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008580 <e37>:
    8580:	f3 0f 1e fa          	endbr64
    8584:	53                   	push   %rbx
    8585:	48 8b 1f             	mov    (%rdi),%rbx
    8588:	48 89 df             	mov    %rbx,%rdi
    858b:	e8 30 e2 ff ff       	call   67c0 <fwp_rc_share>
    8590:	48 89 df             	mov    %rbx,%rdi
    8593:	e8 f8 fa ff ff       	call   8090 <f37>
    8598:	48 89 c3             	mov    %rax,%rbx
    859b:	48 89 c7             	mov    %rax,%rdi
    859e:	e8 1d e2 ff ff       	call   67c0 <fwp_rc_share>
    85a3:	48 89 d8             	mov    %rbx,%rax
    85a6:	5b                   	pop    %rbx
    85a7:	c3                   	ret
    85a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85af:	00 

00000000000085b0 <fwp_write>:
    85b0:	41 57                	push   %r15
    85b2:	41 56                	push   %r14
    85b4:	41 55                	push   %r13
    85b6:	41 54                	push   %r12
    85b8:	55                   	push   %rbp
    85b9:	53                   	push   %rbx
    85ba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    85c1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    85c8:	00 00 
    85ca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    85d1:	00 
    85d2:	49 89 d4             	mov    %rdx,%r12
    85d5:	8b 12                	mov    (%rdx),%edx
    85d7:	83 fa 19             	cmp    $0x19,%edx
    85da:	77 6a                	ja     8646 <fwp_write+0x96>
    85dc:	48 89 f5             	mov    %rsi,%rbp
    85df:	89 d0                	mov    %edx,%eax
    85e1:	89 ce                	mov    %ecx,%esi
    85e3:	48 89 fb             	mov    %rdi,%rbx
    85e6:	48 8d 0d 13 36 00 00 	lea    0x3613(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    85ed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    85f1:	48 01 c8             	add    %rcx,%rax
    85f4:	3e ff e0             	notrack jmp *%rax
    85f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85fe:	00 00 
    8600:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8604:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8608:	48 89 ca             	mov    %rcx,%rdx
    860b:	48 85 c9             	test   %rcx,%rcx
    860e:	0f 88 9c 0c 00 00    	js     92b0 <fwp_write+0xd00>
    8614:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    861b:	00 
    861c:	48 89 c6             	mov    %rax,%rsi
    861f:	4c 89 e7             	mov    %r12,%rdi
    8622:	e8 f9 b3 ff ff       	call   3a20 <fwp_fmt_u128>
    8627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    862e:	00 00 
    8630:	4c 89 e7             	mov    %r12,%rdi
    8633:	e8 08 ae ff ff       	call   3440 <strlen@plt>
    8638:	4c 89 e6             	mov    %r12,%rsi
    863b:	48 89 df             	mov    %rbx,%rdi
    863e:	48 89 c2             	mov    %rax,%rdx
    8641:	e8 8a ba ff ff       	call   40d0 <buf_put>
    8646:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    864d:	00 
    864e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8655:	00 00 
    8657:	0f 85 28 04 00 00    	jne    8a85 <fwp_write+0x4d5>
    865d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8664:	5b                   	pop    %rbx
    8665:	5d                   	pop    %rbp
    8666:	41 5c                	pop    %r12
    8668:	41 5d                	pop    %r13
    866a:	41 5e                	pop    %r14
    866c:	41 5f                	pop    %r15
    866e:	c3                   	ret
    866f:	90                   	nop
    8670:	49 89 e9             	mov    %rbp,%r9
    8673:	4c 8d 05 9b 2b 00 00 	lea    0x2b9b(%rip),%r8        # b215 <_IO_stdin_used+0x215>
    867a:	b9 00 02 00 00       	mov    $0x200,%ecx
    867f:	ba 02 00 00 00       	mov    $0x2,%edx
    8684:	be 00 02 00 00       	mov    $0x200,%esi
    8689:	31 c0                	xor    %eax,%eax
    868b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8692:	00 
    8693:	e8 08 ad ff ff       	call   33a0 <__snprintf_chk@plt>
    8698:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    869f:	00 
    86a0:	e8 9b ad ff ff       	call   3440 <strlen@plt>
    86a5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    86ac:	00 
    86ad:	48 89 df             	mov    %rbx,%rdi
    86b0:	48 89 c2             	mov    %rax,%rdx
    86b3:	e8 18 ba ff ff       	call   40d0 <buf_put>
    86b8:	eb 8c                	jmp    8646 <fwp_write+0x96>
    86ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86c0:	49 89 e9             	mov    %rbp,%r9
    86c3:	4c 8d 05 46 2b 00 00 	lea    0x2b46(%rip),%r8        # b210 <_IO_stdin_used+0x210>
    86ca:	eb ae                	jmp    867a <fwp_write+0xca>
    86cc:	0f 1f 40 00          	nopl   0x0(%rax)
    86d0:	83 fa 13             	cmp    $0x13,%edx
    86d3:	48 8d 05 2c 2b 00 00 	lea    0x2b2c(%rip),%rax        # b206 <_IO_stdin_used+0x206>
    86da:	48 8d 35 2a 2b 00 00 	lea    0x2b2a(%rip),%rsi        # b20b <_IO_stdin_used+0x20b>
    86e1:	ba 04 00 00 00       	mov    $0x4,%edx
    86e6:	48 0f 44 f0          	cmove  %rax,%rsi
    86ea:	45 31 ed             	xor    %r13d,%r13d
    86ed:	e8 de b9 ff ff       	call   40d0 <buf_put>
    86f2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    86f7:	0f 84 a3 08 00 00    	je     8fa0 <fwp_write+0x9f0>
    86fd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8702:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8707:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    870c:	48 89 df             	mov    %rbx,%rdi
    870f:	49 0f 44 c5          	cmove  %r13,%rax
    8713:	31 c9                	xor    %ecx,%ecx
    8715:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    871a:	e8 91 fe ff ff       	call   85b0 <fwp_write>
    871f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8724:	0f 84 6e 09 00 00    	je     9098 <fwp_write+0xae8>
    872a:	49 83 c5 01          	add    $0x1,%r13
    872e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8732:	0f 83 68 08 00 00    	jae    8fa0 <fwp_write+0x9f0>
    8738:	ba 02 00 00 00       	mov    $0x2,%edx
    873d:	48 8d 35 11 2b 00 00 	lea    0x2b11(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8744:	48 89 df             	mov    %rbx,%rdi
    8747:	e8 84 b9 ff ff       	call   40d0 <buf_put>
    874c:	eb af                	jmp    86fd <fwp_write+0x14d>
    874e:	66 90                	xchg   %ax,%ax
    8750:	ba 06 00 00 00       	mov    $0x6,%edx
    8755:	48 8d 35 d2 2a 00 00 	lea    0x2ad2(%rip),%rsi        # b22e <_IO_stdin_used+0x22e>
    875c:	48 83 c5 10          	add    $0x10,%rbp
    8760:	e8 6b b9 ff ff       	call   40d0 <buf_put>
    8765:	48 89 ef             	mov    %rbp,%rdi
    8768:	e8 d3 ac ff ff       	call   3440 <strlen@plt>
    876d:	48 89 ee             	mov    %rbp,%rsi
    8770:	48 89 df             	mov    %rbx,%rdi
    8773:	48 89 c2             	mov    %rax,%rdx
    8776:	e8 55 b9 ff ff       	call   40d0 <buf_put>
    877b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8780:	ba 01 00 00 00       	mov    $0x1,%edx
    8785:	48 89 df             	mov    %rbx,%rdi
    8788:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    878d:	e8 3e b9 ff ff       	call   40d0 <buf_put>
    8792:	e9 af fe ff ff       	jmp    8646 <fwp_write+0x96>
    8797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    879e:	00 00 
    87a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87a7:	00 
    87a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87af:	00 00 
    87b1:	0f 85 ce 02 00 00    	jne    8a85 <fwp_write+0x4d5>
    87b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    87bc:	48 8d 35 57 2a 00 00 	lea    0x2a57(%rip),%rsi        # b21a <_IO_stdin_used+0x21a>
    87c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    87ca:	48 89 df             	mov    %rbx,%rdi
    87cd:	5b                   	pop    %rbx
    87ce:	5d                   	pop    %rbp
    87cf:	41 5c                	pop    %r12
    87d1:	41 5d                	pop    %r13
    87d3:	41 5e                	pop    %r14
    87d5:	41 5f                	pop    %r15
    87d7:	e9 f4 b8 ff ff       	jmp    40d0 <buf_put>
    87dc:	0f 1f 40 00          	nopl   0x0(%rax)
    87e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    87e5:	4d 85 ed             	test   %r13,%r13
    87e8:	0f 84 02 0c 00 00    	je     93f0 <fwp_write+0xe40>
    87ee:	48 8d 35 6d 2a 00 00 	lea    0x2a6d(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    87f5:	4c 89 ef             	mov    %r13,%rdi
    87f8:	e8 23 ad ff ff       	call   3520 <strcmp@plt>
    87fd:	41 89 c1             	mov    %eax,%r9d
    8800:	85 c0                	test   %eax,%eax
    8802:	0f 84 6c 0c 00 00    	je     9474 <fwp_write+0xec4>
    8808:	4c 89 ef             	mov    %r13,%rdi
    880b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8810:	e8 2b ac ff ff       	call   3440 <strlen@plt>
    8815:	4c 89 ee             	mov    %r13,%rsi
    8818:	48 89 df             	mov    %rbx,%rdi
    881b:	48 89 c2             	mov    %rax,%rdx
    881e:	e8 ad b8 ff ff       	call   40d0 <buf_put>
    8823:	ba 01 00 00 00       	mov    $0x1,%edx
    8828:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    882d:	48 89 df             	mov    %rbx,%rdi
    8830:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8835:	e8 96 b8 ff ff       	call   40d0 <buf_put>
    883a:	ba 01 00 00 00       	mov    $0x1,%edx
    883f:	4c 89 fe             	mov    %r15,%rsi
    8842:	48 89 df             	mov    %rbx,%rdi
    8845:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    884a:	e8 81 b8 ff ff       	call   40d0 <buf_put>
    884f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8854:	45 31 f6             	xor    %r14d,%r14d
    8857:	85 d2                	test   %edx,%edx
    8859:	0f 8e 81 0a 00 00    	jle    92e0 <fwp_write+0xd30>
    885f:	45 31 ed             	xor    %r13d,%r13d
    8862:	4d 85 ed             	test   %r13,%r13
    8865:	0f 85 75 07 00 00    	jne    8fe0 <fwp_write+0xa30>
    886b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8872:	00 
    8873:	45 85 f6             	test   %r14d,%r14d
    8876:	0f 84 84 07 00 00    	je     9000 <fwp_write+0xa50>
    887c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8881:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8886:	48 89 df             	mov    %rbx,%rdi
    8889:	49 83 c5 01          	add    $0x1,%r13
    888d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8891:	31 c9                	xor    %ecx,%ecx
    8893:	e8 18 fd ff ff       	call   85b0 <fwp_write>
    8898:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    889d:	7f c3                	jg     8862 <fwp_write+0x2b2>
    889f:	45 85 f6             	test   %r14d,%r14d
    88a2:	0f 84 38 0a 00 00    	je     92e0 <fwp_write+0xd30>
    88a8:	b8 29 00 00 00       	mov    $0x29,%eax
    88ad:	ba 01 00 00 00       	mov    $0x1,%edx
    88b2:	4c 89 fe             	mov    %r15,%rsi
    88b5:	48 89 df             	mov    %rbx,%rdi
    88b8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    88bc:	e8 0f b8 ff ff       	call   40d0 <buf_put>
    88c1:	e9 80 fd ff ff       	jmp    8646 <fwp_write+0x96>
    88c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88cd:	00 00 00 
    88d0:	ba 01 00 00 00       	mov    $0x1,%edx
    88d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88da:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    88df:	e8 ec b7 ff ff       	call   40d0 <buf_put>
    88e4:	48 85 ed             	test   %rbp,%rbp
    88e7:	0f 84 93 06 00 00    	je     8f80 <fwp_write+0x9d0>
    88ed:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    88f1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88f6:	31 c9                	xor    %ecx,%ecx
    88f8:	48 89 df             	mov    %rbx,%rdi
    88fb:	e8 b0 fc ff ff       	call   85b0 <fwp_write>
    8900:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8904:	48 85 ed             	test   %rbp,%rbp
    8907:	0f 84 73 06 00 00    	je     8f80 <fwp_write+0x9d0>
    890d:	ba 02 00 00 00       	mov    $0x2,%edx
    8912:	48 8d 35 3c 29 00 00 	lea    0x293c(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8919:	48 89 df             	mov    %rbx,%rdi
    891c:	e8 af b7 ff ff       	call   40d0 <buf_put>
    8921:	eb ca                	jmp    88ed <fwp_write+0x33d>
    8923:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8928:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    892c:	85 f6                	test   %esi,%esi
    892e:	0f 84 fc 07 00 00    	je     9130 <fwp_write+0xb80>
    8934:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    893b:	00 
    893c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8943:	00 00 
    8945:	0f 85 3a 01 00 00    	jne    8a85 <fwp_write+0x4d5>
    894b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    894f:	4c 89 ea             	mov    %r13,%rdx
    8952:	e9 6c fe ff ff       	jmp    87c3 <fwp_write+0x213>
    8957:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    895e:	00 00 
    8960:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8965:	ba 01 00 00 00       	mov    $0x1,%edx
    896a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    896f:	48 89 ee             	mov    %rbp,%rsi
    8972:	e8 59 b7 ff ff       	call   40d0 <buf_put>
    8977:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    897c:	4c 89 e7             	mov    %r12,%rdi
    897f:	e8 bc aa ff ff       	call   3440 <strlen@plt>
    8984:	4c 89 e6             	mov    %r12,%rsi
    8987:	48 89 df             	mov    %rbx,%rdi
    898a:	48 89 c2             	mov    %rax,%rdx
    898d:	e8 3e b7 ff ff       	call   40d0 <buf_put>
    8992:	ba 01 00 00 00       	mov    $0x1,%edx
    8997:	48 89 ee             	mov    %rbp,%rsi
    899a:	48 89 df             	mov    %rbx,%rdi
    899d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    89a2:	e8 29 b7 ff ff       	call   40d0 <buf_put>
    89a7:	e9 9a fc ff ff       	jmp    8646 <fwp_write+0x96>
    89ac:	0f 1f 40 00          	nopl   0x0(%rax)
    89b0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    89b5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    89b9:	0f 8a 8e 0b 00 00    	jp     954d <fwp_write+0xf9d>
    89bf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89c3:	66 0f 54 05 35 33 00 	andpd  0x3335(%rip),%xmm0        # bd00 <msg.4+0x90>
    89ca:	00 
    89cb:	bd 01 00 00 00       	mov    $0x1,%ebp
    89d0:	66 0f 2e 05 58 33 00 	ucomisd 0x3358(%rip),%xmm0        # bd30 <msg.4+0xc0>
    89d7:	00 
    89d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    89df:	00 
    89e0:	0f 87 b2 09 00 00    	ja     9398 <fwp_write+0xde8>
    89e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89ed:	00 00 00 
    89f0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89f4:	89 ee                	mov    %ebp,%esi
    89f6:	4c 89 e7             	mov    %r12,%rdi
    89f9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    89fe:	e8 4d bd ff ff       	call   4750 <fwp_format_g.constprop.0>
    8a03:	31 f6                	xor    %esi,%esi
    8a05:	4c 89 e7             	mov    %r12,%rdi
    8a08:	e8 f3 a9 ff ff       	call   3400 <strtod@plt>
    8a0d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8a12:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8a16:	7a 06                	jp     8a1e <fwp_write+0x46e>
    8a18:	0f 84 e9 01 00 00    	je     8c07 <fwp_write+0x657>
    8a1e:	83 c5 01             	add    $0x1,%ebp
    8a21:	83 fd 12             	cmp    $0x12,%ebp
    8a24:	75 ca                	jne    89f0 <fwp_write+0x440>
    8a26:	be 11 00 00 00       	mov    $0x11,%esi
    8a2b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a2f:	4c 89 e7             	mov    %r12,%rdi
    8a32:	e8 19 bd ff ff       	call   4750 <fwp_format_g.constprop.0>
    8a37:	e9 cb 01 00 00       	jmp    8c07 <fwp_write+0x657>
    8a3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a40:	48 83 fd 01          	cmp    $0x1,%rbp
    8a44:	0f 84 e6 08 00 00    	je     9330 <fwp_write+0xd80>
    8a4a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8a4e:	b8 02 00 00 00       	mov    $0x2,%eax
    8a53:	ba 01 00 00 00       	mov    $0x1,%edx
    8a58:	48 0f 44 d0          	cmove  %rax,%rdx
    8a5c:	48 8d 35 9b 27 00 00 	lea    0x279b(%rip),%rsi        # b1fe <_IO_stdin_used+0x1fe>
    8a63:	48 8d 05 99 27 00 00 	lea    0x2799(%rip),%rax        # b203 <_IO_stdin_used+0x203>
    8a6a:	48 0f 44 f0          	cmove  %rax,%rsi
    8a6e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a75:	00 
    8a76:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a7d:	00 00 
    8a7f:	0f 84 3e fd ff ff    	je     87c3 <fwp_write+0x213>
    8a85:	e8 c6 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a90:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8a95:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8a9a:	e8 71 b5 ff ff       	call   4010 <buf_grow>
    8a9f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8aa3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8aa9:	4c 03 0b             	add    (%rbx),%r9
    8aac:	66 45 89 11          	mov    %r10w,(%r9)
    8ab0:	45 85 e4             	test   %r12d,%r12d
    8ab3:	0f 8e 07 05 00 00    	jle    8fc0 <fwp_write+0xa10>
    8ab9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8ac0:	55 55 55 
    8ac3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8ac8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8acf:	aa aa aa 
    8ad2:	49 83 c1 01          	add    $0x1,%r9
    8ad6:	eb 45                	jmp    8b1d <fwp_write+0x56d>
    8ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8adf:	00 
    8ae0:	be 01 00 00 00       	mov    $0x1,%esi
    8ae5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8aea:	88 07                	mov    %al,(%rdi)
    8aec:	48 89 e8             	mov    %rbp,%rax
    8aef:	49 f7 e8             	imul   %r8
    8af2:	48 89 e8             	mov    %rbp,%rax
    8af5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8af9:	48 29 c2             	sub    %rax,%rdx
    8afc:	48 85 c9             	test   %rcx,%rcx
    8aff:	0f 95 c0             	setne  %al
    8b02:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8b06:	48 83 ef 01          	sub    $0x1,%rdi
    8b0a:	48 21 c5             	and    %rax,%rbp
    8b0d:	48 29 ea             	sub    %rbp,%rdx
    8b10:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8b14:	49 39 f9             	cmp    %rdi,%r9
    8b17:	0f 84 a3 04 00 00    	je     8fc0 <fwp_write+0xa10>
    8b1d:	48 89 e8             	mov    %rbp,%rax
    8b20:	49 f7 e8             	imul   %r8
    8b23:	48 89 e8             	mov    %rbp,%rax
    8b26:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b2a:	48 89 d1             	mov    %rdx,%rcx
    8b2d:	48 29 c1             	sub    %rax,%rcx
    8b30:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8b34:	48 89 e9             	mov    %rbp,%rcx
    8b37:	48 29 c1             	sub    %rax,%rcx
    8b3a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8b3e:	49 f7 e2             	mul    %r10
    8b41:	b8 30 00 00 00       	mov    $0x30,%eax
    8b46:	48 89 d6             	mov    %rdx,%rsi
    8b49:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8b4d:	48 d1 ee             	shr    $1,%rsi
    8b50:	48 01 f2             	add    %rsi,%rdx
    8b53:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8b57:	48 29 d6             	sub    %rdx,%rsi
    8b5a:	74 8e                	je     8aea <fwp_write+0x53a>
    8b5c:	48 83 fe 01          	cmp    $0x1,%rsi
    8b60:	0f 85 7a ff ff ff    	jne    8ae0 <fwp_write+0x530>
    8b66:	31 f6                	xor    %esi,%esi
    8b68:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8b6d:	e9 78 ff ff ff       	jmp    8aea <fwp_write+0x53a>
    8b72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b78:	66 0f 6e cd          	movd   %ebp,%xmm1
    8b7c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8b7f:	0f 8a c8 09 00 00    	jp     954d <fwp_write+0xf9d>
    8b85:	0f 28 c1             	movaps %xmm1,%xmm0
    8b88:	0f 54 05 61 31 00 00 	andps  0x3161(%rip),%xmm0        # bcf0 <msg.4+0x80>
    8b8f:	0f 2e 05 6e 24 00 00 	ucomiss 0x246e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8b96:	0f 87 24 08 00 00    	ja     93c0 <fwp_write+0xe10>
    8b9c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8ba0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8ba6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bad:	00 
    8bae:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8bb2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8bb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bbe:	00 00 
    8bc0:	44 89 ee             	mov    %r13d,%esi
    8bc3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8bc8:	4c 89 e7             	mov    %r12,%rdi
    8bcb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8bd0:	e8 7b bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8bd5:	31 f6                	xor    %esi,%esi
    8bd7:	4c 89 e7             	mov    %r12,%rdi
    8bda:	e8 c1 a8 ff ff       	call   34a0 <strtof@plt>
    8bdf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8be4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8be7:	7a 02                	jp     8beb <fwp_write+0x63b>
    8be9:	74 1c                	je     8c07 <fwp_write+0x657>
    8beb:	41 83 c5 01          	add    $0x1,%r13d
    8bef:	41 83 fd 0a          	cmp    $0xa,%r13d
    8bf3:	75 cb                	jne    8bc0 <fwp_write+0x610>
    8bf5:	be 09 00 00 00       	mov    $0x9,%esi
    8bfa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8bff:	4c 89 e7             	mov    %r12,%rdi
    8c02:	e8 49 bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8c07:	4c 89 e7             	mov    %r12,%rdi
    8c0a:	e8 81 b5 ff ff       	call   4190 <fwp_finish_float>
    8c0f:	e9 1c fa ff ff       	jmp    8630 <fwp_write+0x80>
    8c14:	0f 1f 40 00          	nopl   0x0(%rax)
    8c18:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8c1c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8c20:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8c27:	00 
    8c28:	48 89 ef             	mov    %rbp,%rdi
    8c2b:	e8 f0 ad ff ff       	call   3a20 <fwp_fmt_u128>
    8c30:	48 89 ef             	mov    %rbp,%rdi
    8c33:	e8 08 a8 ff ff       	call   3440 <strlen@plt>
    8c38:	48 89 ee             	mov    %rbp,%rsi
    8c3b:	48 89 df             	mov    %rbx,%rdi
    8c3e:	48 89 c2             	mov    %rax,%rdx
    8c41:	e8 8a b4 ff ff       	call   40d0 <buf_put>
    8c46:	e9 fb f9 ff ff       	jmp    8646 <fwp_write+0x96>
    8c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c50:	ba 06 00 00 00       	mov    $0x6,%edx
    8c55:	48 8d 35 fc 25 00 00 	lea    0x25fc(%rip),%rsi        # b258 <_IO_stdin_used+0x258>
    8c5c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8c62:	e8 69 b4 ff ff       	call   40d0 <buf_put>
    8c67:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8c6e:	ff ff 7f 
    8c71:	48 23 55 00          	and    0x0(%rbp),%rdx
    8c75:	0f 84 86 02 00 00    	je     8f01 <fwp_write+0x951>
    8c7b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8c80:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8c84:	48 85 d2             	test   %rdx,%rdx
    8c87:	0f 84 ae 00 00 00    	je     8d3b <fwp_write+0x78b>
    8c8d:	8b 0a                	mov    (%rdx),%ecx
    8c8f:	83 f9 1c             	cmp    $0x1c,%ecx
    8c92:	0f 84 58 06 00 00    	je     92f0 <fwp_write+0xd40>
    8c98:	83 f9 1b             	cmp    $0x1b,%ecx
    8c9b:	0f 87 9a 00 00 00    	ja     8d3b <fwp_write+0x78b>
    8ca1:	be 01 00 00 00       	mov    $0x1,%esi
    8ca6:	48 d3 e6             	shl    %cl,%rsi
    8ca9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8caf:	0f 85 4b 04 00 00    	jne    9100 <fwp_write+0xb50>
    8cb5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8cbb:	0f 85 0f 04 00 00    	jne    90d0 <fwp_write+0xb20>
    8cc1:	83 e6 21             	and    $0x21,%esi
    8cc4:	74 75                	je     8d3b <fwp_write+0x78b>
    8cc6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8ccb:	48 85 ff             	test   %rdi,%rdi
    8cce:	79 07                	jns    8cd7 <fwp_write+0x727>
    8cd0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8cd4:	4c 01 ee             	add    %r13,%rsi
    8cd7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8cdb:	85 c9                	test   %ecx,%ecx
    8cdd:	40 0f b6 f7          	movzbl %dil,%esi
    8ce1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cec:	00 00 00 00 
    8cf0:	31 c9                	xor    %ecx,%ecx
    8cf2:	48 89 df             	mov    %rbx,%rdi
    8cf5:	49 83 c5 01          	add    $0x1,%r13
    8cf9:	e8 b2 f8 ff ff       	call   85b0 <fwp_write>
    8cfe:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d05:	ff ff 7f 
    8d08:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d0c:	49 39 d5             	cmp    %rdx,%r13
    8d0f:	0f 83 ec 01 00 00    	jae    8f01 <fwp_write+0x951>
    8d15:	ba 02 00 00 00       	mov    $0x2,%edx
    8d1a:	48 89 df             	mov    %rbx,%rdi
    8d1d:	48 8d 35 31 25 00 00 	lea    0x2531(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8d24:	e8 a7 b3 ff ff       	call   40d0 <buf_put>
    8d29:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d2e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d32:	48 85 d2             	test   %rdx,%rdx
    8d35:	0f 85 52 ff ff ff    	jne    8c8d <fwp_write+0x6dd>
    8d3b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8d40:	48 85 ff             	test   %rdi,%rdi
    8d43:	0f 88 cf 05 00 00    	js     9318 <fwp_write+0xd68>
    8d49:	48 8b 31             	mov    (%rcx),%rsi
    8d4c:	eb a2                	jmp    8cf0 <fwp_write+0x740>
    8d4e:	66 90                	xchg   %ax,%ax
    8d50:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d57:	00 
    8d58:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d5f:	00 00 
    8d61:	0f 85 1e fd ff ff    	jne    8a85 <fwp_write+0x4d5>
    8d67:	ba 08 00 00 00       	mov    $0x8,%edx
    8d6c:	48 8d 35 b2 24 00 00 	lea    0x24b2(%rip),%rsi        # b225 <_IO_stdin_used+0x225>
    8d73:	e9 4b fa ff ff       	jmp    87c3 <fwp_write+0x213>
    8d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d7f:	00 
    8d80:	89 e8                	mov    %ebp,%eax
    8d82:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8d89:	76 03                	jbe    8d8e <fwp_write+0x7de>
    8d8b:	8b 45 00             	mov    0x0(%rbp),%eax
    8d8e:	41 89 c6             	mov    %eax,%r14d
    8d91:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8d96:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8d9b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8d9f:	4c 89 ef             	mov    %r13,%rdi
    8da2:	e8 99 a6 ff ff       	call   3440 <strlen@plt>
    8da7:	4c 89 ee             	mov    %r13,%rsi
    8daa:	48 89 df             	mov    %rbx,%rdi
    8dad:	48 89 c2             	mov    %rax,%rdx
    8db0:	e8 1b b3 ff ff       	call   40d0 <buf_put>
    8db5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8dba:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8dbe:	85 f6                	test   %esi,%esi
    8dc0:	0f 8e 80 f8 ff ff    	jle    8646 <fwp_write+0x96>
    8dc6:	45 31 ed             	xor    %r13d,%r13d
    8dc9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dce:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8dd3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8dd8:	ba 01 00 00 00       	mov    $0x1,%edx
    8ddd:	4c 89 fe             	mov    %r15,%rsi
    8de0:	48 89 04 24          	mov    %rax,(%rsp)
    8de4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8de9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8ded:	48 89 df             	mov    %rbx,%rdi
    8df0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8df4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8df9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8dfe:	e8 cd b2 ff ff       	call   40d0 <buf_put>
    8e03:	41 8b 06             	mov    (%r14),%eax
    8e06:	83 f8 0e             	cmp    $0xe,%eax
    8e09:	0f 84 71 02 00 00    	je     9080 <fwp_write+0xad0>
    8e0f:	83 f8 10             	cmp    $0x10,%eax
    8e12:	0f 84 38 02 00 00    	je     9050 <fwp_write+0xaa0>
    8e18:	83 f8 0a             	cmp    $0xa,%eax
    8e1b:	0f 84 7f 04 00 00    	je     92a0 <fwp_write+0xcf0>
    8e21:	0f 8f f9 00 00 00    	jg     8f20 <fwp_write+0x970>
    8e27:	83 f8 03             	cmp    $0x3,%eax
    8e2a:	0f 8f 50 04 00 00    	jg     9280 <fwp_write+0xcd0>
    8e30:	85 c0                	test   %eax,%eax
    8e32:	78 10                	js     8e44 <fwp_write+0x894>
    8e34:	48 8b 04 24          	mov    (%rsp),%rax
    8e38:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e3c:	85 c0                	test   %eax,%eax
    8e3e:	0f 85 f9 00 00 00    	jne    8f3d <fwp_write+0x98d>
    8e44:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e49:	48 8b 34 24          	mov    (%rsp),%rsi
    8e4d:	31 c9                	xor    %ecx,%ecx
    8e4f:	48 89 df             	mov    %rbx,%rdi
    8e52:	e8 59 f7 ff ff       	call   85b0 <fwp_write>
    8e57:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e5c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e61:	49 83 c5 01          	add    $0x1,%r13
    8e65:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8e69:	0f 8f 5f ff ff ff    	jg     8dce <fwp_write+0x81e>
    8e6f:	e9 d2 f7 ff ff       	jmp    8646 <fwp_write+0x96>
    8e74:	0f 1f 40 00          	nopl   0x0(%rax)
    8e78:	ba 06 00 00 00       	mov    $0x6,%edx
    8e7d:	48 8d 35 c7 23 00 00 	lea    0x23c7(%rip),%rsi        # b24b <_IO_stdin_used+0x24b>
    8e84:	45 31 ed             	xor    %r13d,%r13d
    8e87:	e8 44 b2 ff ff       	call   40d0 <buf_put>
    8e8c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8e91:	75 19                	jne    8eac <fwp_write+0x8fc>
    8e93:	eb 6c                	jmp    8f01 <fwp_write+0x951>
    8e95:	0f 1f 00             	nopl   (%rax)
    8e98:	ba 02 00 00 00       	mov    $0x2,%edx
    8e9d:	48 8d 35 b1 23 00 00 	lea    0x23b1(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8ea4:	48 89 df             	mov    %rbx,%rdi
    8ea7:	e8 24 b2 ff ff       	call   40d0 <buf_put>
    8eac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8eb2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8eb7:	31 c0                	xor    %eax,%eax
    8eb9:	49 83 c5 01          	add    $0x1,%r13
    8ebd:	4c 8d 05 8e 23 00 00 	lea    0x238e(%rip),%r8        # b252 <_IO_stdin_used+0x252>
    8ec4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ec9:	be 00 02 00 00       	mov    $0x200,%esi
    8ece:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ed5:	00 
    8ed6:	e8 c5 a4 ff ff       	call   33a0 <__snprintf_chk@plt>
    8edb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ee2:	00 
    8ee3:	e8 58 a5 ff ff       	call   3440 <strlen@plt>
    8ee8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8eef:	00 
    8ef0:	48 89 df             	mov    %rbx,%rdi
    8ef3:	48 89 c2             	mov    %rax,%rdx
    8ef6:	e8 d5 b1 ff ff       	call   40d0 <buf_put>
    8efb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8eff:	72 97                	jb     8e98 <fwp_write+0x8e8>
    8f01:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f06:	ba 01 00 00 00       	mov    $0x1,%edx
    8f0b:	48 89 df             	mov    %rbx,%rdi
    8f0e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f13:	e8 b8 b1 ff ff       	call   40d0 <buf_put>
    8f18:	e9 29 f7 ff ff       	jmp    8646 <fwp_write+0x96>
    8f1d:	0f 1f 00             	nopl   (%rax)
    8f20:	83 f8 0b             	cmp    $0xb,%eax
    8f23:	0f 85 1b ff ff ff    	jne    8e44 <fwp_write+0x894>
    8f29:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8f2e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8f32:	83 e0 01             	and    $0x1,%eax
    8f35:	85 c0                	test   %eax,%eax
    8f37:	0f 84 07 ff ff ff    	je     8e44 <fwp_write+0x894>
    8f3d:	4c 89 fe             	mov    %r15,%rsi
    8f40:	48 89 df             	mov    %rbx,%rdi
    8f43:	ba 01 00 00 00       	mov    $0x1,%edx
    8f48:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f4d:	e8 7e b1 ff ff       	call   40d0 <buf_put>
    8f52:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f57:	48 8b 34 24          	mov    (%rsp),%rsi
    8f5b:	31 c9                	xor    %ecx,%ecx
    8f5d:	48 89 df             	mov    %rbx,%rdi
    8f60:	e8 4b f6 ff ff       	call   85b0 <fwp_write>
    8f65:	ba 01 00 00 00       	mov    $0x1,%edx
    8f6a:	4c 89 fe             	mov    %r15,%rsi
    8f6d:	48 89 df             	mov    %rbx,%rdi
    8f70:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8f75:	e8 56 b1 ff ff       	call   40d0 <buf_put>
    8f7a:	e9 d8 fe ff ff       	jmp    8e57 <fwp_write+0x8a7>
    8f7f:	90                   	nop
    8f80:	ba 01 00 00 00       	mov    $0x1,%edx
    8f85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f8a:	48 89 df             	mov    %rbx,%rdi
    8f8d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f92:	e8 39 b1 ff ff       	call   40d0 <buf_put>
    8f97:	e9 aa f6 ff ff       	jmp    8646 <fwp_write+0x96>
    8f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    8fa0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fa5:	ba 01 00 00 00       	mov    $0x1,%edx
    8faa:	48 89 df             	mov    %rbx,%rdi
    8fad:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8fb2:	e8 19 b1 ff ff       	call   40d0 <buf_put>
    8fb7:	e9 8a f6 ff ff       	jmp    8646 <fwp_write+0x96>
    8fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fc0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8fc4:	48 8b 13             	mov    (%rbx),%rdx
    8fc7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8fcc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8fd0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8fd4:	e9 6d f6 ff ff       	jmp    8646 <fwp_write+0x96>
    8fd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fe0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fe5:	48 8d 35 69 22 00 00 	lea    0x2269(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8fec:	48 89 df             	mov    %rbx,%rdi
    8fef:	e8 dc b0 ff ff       	call   40d0 <buf_put>
    8ff4:	e9 72 f8 ff ff       	jmp    886b <fwp_write+0x2bb>
    8ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9000:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9005:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    900a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    900e:	48 89 f7             	mov    %rsi,%rdi
    9011:	48 89 34 24          	mov    %rsi,(%rsp)
    9015:	e8 26 a4 ff ff       	call   3440 <strlen@plt>
    901a:	48 8b 34 24          	mov    (%rsp),%rsi
    901e:	48 89 df             	mov    %rbx,%rdi
    9021:	48 89 c2             	mov    %rax,%rdx
    9024:	e8 a7 b0 ff ff       	call   40d0 <buf_put>
    9029:	ba 03 00 00 00       	mov    $0x3,%edx
    902e:	48 8d 35 43 22 00 00 	lea    0x2243(%rip),%rsi        # b278 <_IO_stdin_used+0x278>
    9035:	48 89 df             	mov    %rbx,%rdi
    9038:	e8 93 b0 ff ff       	call   40d0 <buf_put>
    903d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9042:	e9 35 f8 ff ff       	jmp    887c <fwp_write+0x2cc>
    9047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    904e:	00 00 
    9050:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9055:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9059:	48 85 ff             	test   %rdi,%rdi
    905c:	0f 84 e2 fd ff ff    	je     8e44 <fwp_write+0x894>
    9062:	48 8d 35 f9 21 00 00 	lea    0x21f9(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    9069:	e8 b2 a4 ff ff       	call   3520 <strcmp@plt>
    906e:	85 c0                	test   %eax,%eax
    9070:	0f 95 c0             	setne  %al
    9073:	0f b6 c0             	movzbl %al,%eax
    9076:	e9 c1 fd ff ff       	jmp    8e3c <fwp_write+0x88c>
    907b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9080:	31 c0                	xor    %eax,%eax
    9082:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9089:	00 
    908a:	0f 97 c0             	seta   %al
    908d:	e9 aa fd ff ff       	jmp    8e3c <fwp_write+0x88c>
    9092:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9098:	48 89 df             	mov    %rbx,%rdi
    909b:	ba 02 00 00 00       	mov    $0x2,%edx
    90a0:	48 8d 35 b8 21 00 00 	lea    0x21b8(%rip),%rsi        # b25f <_IO_stdin_used+0x25f>
    90a7:	e8 24 b0 ff ff       	call   40d0 <buf_put>
    90ac:	4c 89 e8             	mov    %r13,%rax
    90af:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    90b4:	31 c9                	xor    %ecx,%ecx
    90b6:	48 c1 e0 04          	shl    $0x4,%rax
    90ba:	48 89 df             	mov    %rbx,%rdi
    90bd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    90c2:	e8 e9 f4 ff ff       	call   85b0 <fwp_write>
    90c7:	e9 5e f6 ff ff       	jmp    872a <fwp_write+0x17a>
    90cc:	0f 1f 40 00          	nopl   0x0(%rax)
    90d0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    90d5:	48 85 ff             	test   %rdi,%rdi
    90d8:	79 0c                	jns    90e6 <fwp_write+0xb36>
    90da:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    90e1:	00 
    90e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    90e6:	48 63 3e             	movslq (%rsi),%rdi
    90e9:	83 f9 02             	cmp    $0x2,%ecx
    90ec:	89 fe                	mov    %edi,%esi
    90ee:	48 0f 44 f7          	cmove  %rdi,%rsi
    90f2:	e9 f9 fb ff ff       	jmp    8cf0 <fwp_write+0x740>
    90f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90fe:	00 00 
    9100:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9105:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    910a:	48 85 ff             	test   %rdi,%rdi
    910d:	0f 88 0f 03 00 00    	js     9422 <fwp_write+0xe72>
    9113:	49 0f bf 38          	movswq (%r8),%rdi
    9117:	83 f9 01             	cmp    $0x1,%ecx
    911a:	0f b7 f7             	movzwl %di,%esi
    911d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9121:	e9 ca fb ff ff       	jmp    8cf0 <fwp_write+0x740>
    9126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    912d:	00 00 00 
    9130:	ba 01 00 00 00       	mov    $0x1,%edx
    9135:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    913a:	48 83 c5 08          	add    $0x8,%rbp
    913e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9143:	e8 88 af ff ff       	call   40d0 <buf_put>
    9148:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    914d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9152:	4d 85 ed             	test   %r13,%r13
    9155:	75 46                	jne    919d <fwp_write+0xbed>
    9157:	e9 04 01 00 00       	jmp    9260 <fwp_write+0xcb0>
    915c:	0f 1f 40 00          	nopl   0x0(%rax)
    9160:	41 80 f9 09          	cmp    $0x9,%r9b
    9164:	0f 84 d6 00 00 00    	je     9240 <fwp_write+0xc90>
    916a:	41 80 f9 0a          	cmp    $0xa,%r9b
    916e:	0f 85 9c 00 00 00    	jne    9210 <fwp_write+0xc60>
    9174:	ba 02 00 00 00       	mov    $0x2,%edx
    9179:	48 8d 35 bb 20 00 00 	lea    0x20bb(%rip),%rsi        # b23b <_IO_stdin_used+0x23b>
    9180:	48 89 df             	mov    %rbx,%rdi
    9183:	e8 48 af ff ff       	call   40d0 <buf_put>
    9188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    918f:	00 
    9190:	48 83 c5 01          	add    $0x1,%rbp
    9194:	49 39 ec             	cmp    %rbp,%r12
    9197:	0f 84 c3 00 00 00    	je     9260 <fwp_write+0xcb0>
    919d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    91a2:	41 80 f9 0d          	cmp    $0xd,%r9b
    91a6:	74 28                	je     91d0 <fwp_write+0xc20>
    91a8:	7e b6                	jle    9160 <fwp_write+0xbb0>
    91aa:	41 80 f9 22          	cmp    $0x22,%r9b
    91ae:	74 40                	je     91f0 <fwp_write+0xc40>
    91b0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    91b4:	75 5a                	jne    9210 <fwp_write+0xc60>
    91b6:	ba 02 00 00 00       	mov    $0x2,%edx
    91bb:	48 8d 35 76 20 00 00 	lea    0x2076(%rip),%rsi        # b238 <_IO_stdin_used+0x238>
    91c2:	48 89 df             	mov    %rbx,%rdi
    91c5:	e8 06 af ff ff       	call   40d0 <buf_put>
    91ca:	eb c4                	jmp    9190 <fwp_write+0xbe0>
    91cc:	0f 1f 40 00          	nopl   0x0(%rax)
    91d0:	ba 02 00 00 00       	mov    $0x2,%edx
    91d5:	48 8d 35 65 20 00 00 	lea    0x2065(%rip),%rsi        # b241 <_IO_stdin_used+0x241>
    91dc:	48 89 df             	mov    %rbx,%rdi
    91df:	e8 ec ae ff ff       	call   40d0 <buf_put>
    91e4:	eb aa                	jmp    9190 <fwp_write+0xbe0>
    91e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91ed:	00 00 00 
    91f0:	ba 02 00 00 00       	mov    $0x2,%edx
    91f5:	48 8d 35 39 20 00 00 	lea    0x2039(%rip),%rsi        # b235 <_IO_stdin_used+0x235>
    91fc:	48 89 df             	mov    %rbx,%rdi
    91ff:	e8 cc ae ff ff       	call   40d0 <buf_put>
    9204:	eb 8a                	jmp    9190 <fwp_write+0xbe0>
    9206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    920d:	00 00 00 
    9210:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9214:	0f 86 2e 01 00 00    	jbe    9348 <fwp_write+0xd98>
    921a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    921e:	0f 84 24 01 00 00    	je     9348 <fwp_write+0xd98>
    9224:	ba 01 00 00 00       	mov    $0x1,%edx
    9229:	4c 89 fe             	mov    %r15,%rsi
    922c:	48 89 df             	mov    %rbx,%rdi
    922f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9234:	e8 97 ae ff ff       	call   40d0 <buf_put>
    9239:	e9 52 ff ff ff       	jmp    9190 <fwp_write+0xbe0>
    923e:	66 90                	xchg   %ax,%ax
    9240:	ba 02 00 00 00       	mov    $0x2,%edx
    9245:	48 8d 35 f2 1f 00 00 	lea    0x1ff2(%rip),%rsi        # b23e <_IO_stdin_used+0x23e>
    924c:	48 89 df             	mov    %rbx,%rdi
    924f:	e8 7c ae ff ff       	call   40d0 <buf_put>
    9254:	e9 37 ff ff ff       	jmp    9190 <fwp_write+0xbe0>
    9259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9260:	ba 01 00 00 00       	mov    $0x1,%edx
    9265:	4c 89 fe             	mov    %r15,%rsi
    9268:	48 89 df             	mov    %rbx,%rdi
    926b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9270:	e8 5b ae ff ff       	call   40d0 <buf_put>
    9275:	e9 cc f3 ff ff       	jmp    8646 <fwp_write+0x96>
    927a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9280:	83 f8 04             	cmp    $0x4,%eax
    9283:	0f 85 bb fb ff ff    	jne    8e44 <fwp_write+0x894>
    9289:	48 8b 04 24          	mov    (%rsp),%rax
    928d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9291:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9296:	48 c1 e8 3f          	shr    $0x3f,%rax
    929a:	e9 96 fc ff ff       	jmp    8f35 <fwp_write+0x985>
    929f:	90                   	nop
    92a0:	8b 0c 24             	mov    (%rsp),%ecx
    92a3:	31 c0                	xor    %eax,%eax
    92a5:	85 c9                	test   %ecx,%ecx
    92a7:	0f 98 c0             	sets   %al
    92aa:	e9 86 fc ff ff       	jmp    8f35 <fwp_write+0x985>
    92af:	90                   	nop
    92b0:	48 f7 d8             	neg    %rax
    92b3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    92ba:	00 
    92bb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    92c2:	2d 
    92c3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92ca:	00 
    92cb:	48 83 d2 00          	adc    $0x0,%rdx
    92cf:	48 89 c6             	mov    %rax,%rsi
    92d2:	48 f7 da             	neg    %rdx
    92d5:	e8 46 a7 ff ff       	call   3a20 <fwp_fmt_u128>
    92da:	e9 51 f3 ff ff       	jmp    8630 <fwp_write+0x80>
    92df:	90                   	nop
    92e0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    92e5:	e9 c3 f5 ff ff       	jmp    88ad <fwp_write+0x2fd>
    92ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92f0:	4c 89 e9             	mov    %r13,%rcx
    92f3:	48 c1 e1 04          	shl    $0x4,%rcx
    92f7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    92fc:	48 85 ff             	test   %rdi,%rdi
    92ff:	0f 89 eb f9 ff ff    	jns    8cf0 <fwp_write+0x740>
    9305:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9309:	48 89 ce             	mov    %rcx,%rsi
    930c:	e9 df f9 ff ff       	jmp    8cf0 <fwp_write+0x740>
    9311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9318:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    931f:	00 
    9320:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9324:	e9 20 fa ff ff       	jmp    8d49 <fwp_write+0x799>
    9329:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9330:	ba 02 00 00 00       	mov    $0x2,%edx
    9335:	48 8d 35 c4 1e 00 00 	lea    0x1ec4(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    933c:	e9 2d f7 ff ff       	jmp    8a6e <fwp_write+0x4be>
    9341:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9348:	4c 8d 05 f5 1e 00 00 	lea    0x1ef5(%rip),%r8        # b244 <_IO_stdin_used+0x244>
    934f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9354:	31 c0                	xor    %eax,%eax
    9356:	ba 02 00 00 00       	mov    $0x2,%edx
    935b:	be 10 00 00 00       	mov    $0x10,%esi
    9360:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9367:	00 
    9368:	e8 33 a0 ff ff       	call   33a0 <__snprintf_chk@plt>
    936d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9374:	00 
    9375:	e8 c6 a0 ff ff       	call   3440 <strlen@plt>
    937a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9381:	00 
    9382:	48 89 df             	mov    %rbx,%rdi
    9385:	48 89 c2             	mov    %rax,%rdx
    9388:	e8 43 ad ff ff       	call   40d0 <buf_put>
    938d:	e9 fe fd ff ff       	jmp    9190 <fwp_write+0xbe0>
    9392:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9398:	66 0f ef c0          	pxor   %xmm0,%xmm0
    939c:	48 8d 35 57 1e 00 00 	lea    0x1e57(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    93a3:	48 8d 05 4f 1e 00 00 	lea    0x1e4f(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    93aa:	4c 89 e7             	mov    %r12,%rdi
    93ad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    93b1:	48 0f 46 f0          	cmovbe %rax,%rsi
    93b5:	e8 26 a0 ff ff       	call   33e0 <strcpy@plt>
    93ba:	e9 71 f2 ff ff       	jmp    8630 <fwp_write+0x80>
    93bf:	90                   	nop
    93c0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93c4:	48 8d 35 2f 1e 00 00 	lea    0x1e2f(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    93cb:	48 8d 05 27 1e 00 00 	lea    0x1e27(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    93d2:	0f 2f c8             	comiss %xmm0,%xmm1
    93d5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93dc:	00 
    93dd:	4c 89 e7             	mov    %r12,%rdi
    93e0:	48 0f 46 f0          	cmovbe %rax,%rsi
    93e4:	e8 f7 9f ff ff       	call   33e0 <strcpy@plt>
    93e9:	e9 42 f2 ff ff       	jmp    8630 <fwp_write+0x80>
    93ee:	66 90                	xchg   %ax,%ax
    93f0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    93f5:	45 85 c0             	test   %r8d,%r8d
    93f8:	75 34                	jne    942e <fwp_write+0xe7e>
    93fa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9401:	00 
    9402:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9409:	00 00 
    940b:	0f 85 74 f6 ff ff    	jne    8a85 <fwp_write+0x4d5>
    9411:	ba 02 00 00 00       	mov    $0x2,%edx
    9416:	48 8d 35 58 1e 00 00 	lea    0x1e58(%rip),%rsi        # b275 <_IO_stdin_used+0x275>
    941d:	e9 a1 f3 ff ff       	jmp    87c3 <fwp_write+0x213>
    9422:	48 03 75 10          	add    0x10(%rbp),%rsi
    9426:	49 89 f0             	mov    %rsi,%r8
    9429:	e9 e5 fc ff ff       	jmp    9113 <fwp_write+0xb63>
    942e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9433:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9438:	85 ff                	test   %edi,%edi
    943a:	0f 84 fa f3 ff ff    	je     883a <fwp_write+0x28a>
    9440:	ba 01 00 00 00       	mov    $0x1,%edx
    9445:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    944a:	48 89 df             	mov    %rbx,%rdi
    944d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9452:	e8 79 ac ff ff       	call   40d0 <buf_put>
    9457:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    945c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9461:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9467:	85 c0                	test   %eax,%eax
    9469:	0f 8f f0 f3 ff ff    	jg     885f <fwp_write+0x2af>
    946f:	e9 34 f4 ff ff       	jmp    88a8 <fwp_write+0x2f8>
    9474:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9478:	49 89 c5             	mov    %rax,%r13
    947b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9480:	49 89 c4             	mov    %rax,%r12
    9483:	49 c1 fd 3f          	sar    $0x3f,%r13
    9487:	4c 09 e8             	or     %r13,%rax
    948a:	0f 84 a7 00 00 00    	je     9537 <fwp_write+0xf87>
    9490:	48 8d 2d 29 3e 00 00 	lea    0x3e29(%rip),%rbp        # d2c0 <units.0>
    9497:	4d 89 e7             	mov    %r12,%r15
    949a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    949e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    94a3:	4c 89 ff             	mov    %r15,%rdi
    94a6:	4c 89 ee             	mov    %r13,%rsi
    94a9:	44 89 0c 24          	mov    %r9d,(%rsp)
    94ad:	48 99                	cqto
    94af:	48 89 d1             	mov    %rdx,%rcx
    94b2:	48 89 c2             	mov    %rax,%rdx
    94b5:	e8 46 10 00 00       	call   a500 <__divmodti4>
    94ba:	44 8b 0c 24          	mov    (%rsp),%r9d
    94be:	48 89 c1             	mov    %rax,%rcx
    94c1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    94c6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    94cb:	0f 84 94 00 00 00    	je     9565 <fwp_write+0xfb5>
    94d1:	41 83 c1 01          	add    $0x1,%r9d
    94d5:	48 83 c5 10          	add    $0x10,%rbp
    94d9:	41 83 f9 05          	cmp    $0x5,%r9d
    94dd:	75 bb                	jne    949a <fwp_write+0xeea>
    94df:	4d 85 ed             	test   %r13,%r13
    94e2:	79 53                	jns    9537 <fwp_write+0xf87>
    94e4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    94e9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    94ee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    94f3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    94f8:	48 99                	cqto
    94fa:	48 f7 d8             	neg    %rax
    94fd:	48 83 d2 00          	adc    $0x0,%rdx
    9501:	48 89 c6             	mov    %rax,%rsi
    9504:	48 f7 da             	neg    %rdx
    9507:	e8 14 a5 ff ff       	call   3a20 <fwp_fmt_u128>
    950c:	49 89 e8             	mov    %rbp,%r8
    950f:	ba 00 02 00 00       	mov    $0x200,%edx
    9514:	be 02 00 00 00       	mov    $0x2,%esi
    9519:	31 c0                	xor    %eax,%eax
    951b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9522:	00 
    9523:	48 8d 0d 46 1d 00 00 	lea    0x1d46(%rip),%rcx        # b270 <_IO_stdin_used+0x270>
    952a:	4c 89 e7             	mov    %r12,%rdi
    952d:	e8 8e a1 ff ff       	call   36c0 <__sprintf_chk@plt>
    9532:	e9 f9 f0 ff ff       	jmp    8630 <fwp_write+0x80>
    9537:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    953c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9541:	31 d2                	xor    %edx,%edx
    9543:	48 89 ef             	mov    %rbp,%rdi
    9546:	e8 d5 a4 ff ff       	call   3a20 <fwp_fmt_u128>
    954b:	eb bf                	jmp    950c <fwp_write+0xf5c>
    954d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9554:	4e 61 4e 00 
    9558:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    955f:	00 
    9560:	e9 cb f0 ff ff       	jmp    8630 <fwp_write+0x80>
    9565:	44 89 0c 24          	mov    %r9d,(%rsp)
    9569:	48 89 c8             	mov    %rcx,%rax
    956c:	48 85 d2             	test   %rdx,%rdx
    956f:	78 51                	js     95c2 <fwp_write+0x1012>
    9571:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9576:	48 89 c6             	mov    %rax,%rsi
    9579:	48 89 ef             	mov    %rbp,%rdi
    957c:	e8 9f a4 ff ff       	call   3a20 <fwp_fmt_u128>
    9581:	44 8b 0c 24          	mov    (%rsp),%r9d
    9585:	49 63 c1             	movslq %r9d,%rax
    9588:	49 89 e8             	mov    %rbp,%r8
    958b:	ba 00 02 00 00       	mov    $0x200,%edx
    9590:	be 02 00 00 00       	mov    $0x2,%esi
    9595:	48 c1 e0 04          	shl    $0x4,%rax
    9599:	48 8d 3d 20 3d 00 00 	lea    0x3d20(%rip),%rdi        # d2c0 <units.0>
    95a0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95a7:	00 
    95a8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    95ac:	48 8d 0d b8 1c 00 00 	lea    0x1cb8(%rip),%rcx        # b26b <_IO_stdin_used+0x26b>
    95b3:	4c 89 e7             	mov    %r12,%rdi
    95b6:	31 c0                	xor    %eax,%eax
    95b8:	e8 03 a1 ff ff       	call   36c0 <__sprintf_chk@plt>
    95bd:	e9 6e f0 ff ff       	jmp    8630 <fwp_write+0x80>
    95c2:	48 f7 d8             	neg    %rax
    95c5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95ca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95cf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95d4:	48 83 d2 00          	adc    $0x0,%rdx
    95d8:	48 89 c6             	mov    %rax,%rsi
    95db:	48 f7 da             	neg    %rdx
    95de:	e8 3d a4 ff ff       	call   3a20 <fwp_fmt_u128>
    95e3:	44 8b 0c 24          	mov    (%rsp),%r9d
    95e7:	eb 9c                	jmp    9585 <fwp_write+0xfd5>
    95e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000095f0 <fwp_main_thread>:
    95f0:	f3 0f 1e fa          	endbr64
    95f4:	41 57                	push   %r15
    95f6:	41 56                	push   %r14
    95f8:	41 55                	push   %r13
    95fa:	41 54                	push   %r12
    95fc:	55                   	push   %rbp
    95fd:	53                   	push   %rbx
    95fe:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9605:	8b 3d b9 f5 05 00    	mov    0x5f5b9(%rip),%edi        # 68bc4 <fwp_heap+0x13a4>
    960b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9612:	00 00 
    9614:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    961b:	00 
    961c:	31 c0                	xor    %eax,%eax
    961e:	85 ff                	test   %edi,%edi
    9620:	0f 84 72 07 00 00    	je     9d98 <fwp_main_thread+0x7a8>
    9626:	8b 35 9c f5 05 00    	mov    0x5f59c(%rip),%esi        # 68bc8 <fwp_heap+0x13a8>
    962c:	85 f6                	test   %esi,%esi
    962e:	0f 85 4c 07 00 00    	jne    9d80 <fwp_main_thread+0x790>
    9634:	48 8d 05 45 5a 00 00 	lea    0x5a45(%rip),%rax        # f080 <alt.5>
    963b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9640:	31 f6                	xor    %esi,%esi
    9642:	48 c7 05 73 db 05 00 	movq   $0x40000000,0x5db73(%rip)        # 671c0 <fwp_main_stack_size>
    9649:	00 00 00 40 
    964d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9652:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9657:	48 89 c7             	mov    %rax,%rdi
    965a:	48 89 2d 67 db 05 00 	mov    %rbp,0x5db67(%rip)        # 671c8 <fwp_main_stack_top>
    9661:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9668:	01 00 
    966a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9671:	00 
    9672:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9677:	e8 24 a0 ff ff       	call   36a0 <sigaltstack@plt>
    967c:	85 c0                	test   %eax,%eax
    967e:	0f 85 33 0e 00 00    	jne    a4b7 <fwp_main_thread+0xec7>
    9684:	31 c0                	xor    %eax,%eax
    9686:	b9 12 00 00 00       	mov    $0x12,%ecx
    968b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9692:	00 
    9693:	f3 48 ab             	rep stos %rax,(%rdi)
    9696:	48 8d 05 83 a6 ff ff 	lea    -0x597d(%rip),%rax        # 3d20 <fwp_segv>
    969d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    96a4:	00 
    96a5:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    96ac:	04 00 00 08 
    96b0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    96b7:	00 
    96b8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    96bf:	00 
    96c0:	e8 9b 9e ff ff       	call   3560 <sigemptyset@plt>
    96c5:	85 c0                	test   %eax,%eax
    96c7:	0f 85 ea 0d 00 00    	jne    a4b7 <fwp_main_thread+0xec7>
    96cd:	31 d2                	xor    %edx,%edx
    96cf:	48 89 de             	mov    %rbx,%rsi
    96d2:	bf 0b 00 00 00       	mov    $0xb,%edi
    96d7:	e8 14 9d ff ff       	call   33f0 <sigaction@plt>
    96dc:	85 c0                	test   %eax,%eax
    96de:	0f 85 d3 0d 00 00    	jne    a4b7 <fwp_main_thread+0xec7>
    96e4:	31 d2                	xor    %edx,%edx
    96e6:	48 89 de             	mov    %rbx,%rsi
    96e9:	bf 07 00 00 00       	mov    $0x7,%edi
    96ee:	e8 fd 9c ff ff       	call   33f0 <sigaction@plt>
    96f3:	85 c0                	test   %eax,%eax
    96f5:	0f 85 bc 0d 00 00    	jne    a4b7 <fwp_main_thread+0xec7>
    96fb:	48 8b 05 3e f5 05 00 	mov    0x5f53e(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9702:	48 85 c0             	test   %rax,%rax
    9705:	0f 88 35 06 00 00    	js     9d40 <fwp_main_thread+0x750>
    970b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    970f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9714:	48 8d 3d e5 aa ff ff 	lea    -0x551b(%rip),%rdi        # 4200 <ad_raw_report>
    971b:	f2 0f 11 05 a5 fd 05 	movsd  %xmm0,0x5fda5(%rip)        # 694c8 <iteration_start_charge>
    9722:	00 
    9723:	c7 05 bb fd 05 00 01 	movl   $0x1,0x5fdbb(%rip)        # 694e8 <iteration_active>
    972a:	00 00 00 
    972d:	e8 de 0f 00 00       	call   a710 <atexit>
    9732:	85 c0                	test   %eax,%eax
    9734:	0f 85 9a 0d 00 00    	jne    a4d4 <fwp_main_thread+0xee4>
    973a:	8b 0d 28 59 00 00    	mov    0x5928(%rip),%ecx        # f068 <st.3>
    9740:	85 c9                	test   %ecx,%ecx
    9742:	0f 84 60 06 00 00    	je     9da8 <fwp_main_thread+0x7b8>
    9748:	48 8b 2d b1 e0 05 00 	mov    0x5e0b1(%rip),%rbp        # 67800 <fwp_cur>
    974f:	48 85 ed             	test   %rbp,%rbp
    9752:	0f 84 08 03 00 00    	je     9a60 <fwp_main_thread+0x470>
    9758:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    975d:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9761:	48 89 eb             	mov    %rbp,%rbx
    9764:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9769:	0f 84 41 01 00 00    	je     98b0 <fwp_main_thread+0x2c0>
    976f:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9774:	0f 84 16 02 00 00    	je     9990 <fwp_main_thread+0x3a0>
    977a:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    977e:	0f 84 fc 01 00 00    	je     9980 <fwp_main_thread+0x390>
    9784:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9788:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    978c:	0f 85 7e 02 00 00    	jne    9a10 <fwp_main_thread+0x420>
    9792:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9796:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    979d:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    97a1:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    97a8:	00 00 00 00 
    97ac:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    97b3:	48 85 d2             	test   %rdx,%rdx
    97b6:	74 07                	je     97bf <fwp_main_thread+0x1cf>
    97b8:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    97bf:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    97c3:	48 85 c0             	test   %rax,%rax
    97c6:	74 34                	je     97fc <fwp_main_thread+0x20c>
    97c8:	48 89 43 68          	mov    %rax,0x68(%rbx)
    97cc:	48 8b 05 05 e0 05 00 	mov    0x5e005(%rip),%rax        # 677d8 <fwp_timers>
    97d3:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    97d7:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    97de:	00 00 00 00 
    97e2:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    97e9:	48 85 c0             	test   %rax,%rax
    97ec:	74 07                	je     97f5 <fwp_main_thread+0x205>
    97ee:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    97f5:	48 89 1d dc df 05 00 	mov    %rbx,0x5dfdc(%rip)        # 677d8 <fwp_timers>
    97fc:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9800:	e8 cb dd ff ff       	call   75d0 <fwp_block>
    9805:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    980c:	48 85 c9             	test   %rcx,%rcx
    980f:	74 47                	je     9858 <fwp_main_thread+0x268>
    9811:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9818:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    981f:	48 85 d2             	test   %rdx,%rdx
    9822:	0f 84 28 02 00 00    	je     9a50 <fwp_main_thread+0x460>
    9828:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    982f:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9836:	48 85 c0             	test   %rax,%rax
    9839:	74 07                	je     9842 <fwp_main_thread+0x252>
    983b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9842:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9849:	00 00 00 00 
    984d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9851:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9858:	48 8b 0d a1 df 05 00 	mov    0x5dfa1(%rip),%rcx        # 67800 <fwp_cur>
    985f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9863:	0f 84 97 01 00 00    	je     9a00 <fwp_main_thread+0x410>
    9869:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9870:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9877:	48 85 d2             	test   %rdx,%rdx
    987a:	0f 84 20 04 00 00    	je     9ca0 <fwp_main_thread+0x6b0>
    9880:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9887:	48 85 c0             	test   %rax,%rax
    988a:	74 07                	je     9893 <fwp_main_thread+0x2a3>
    988c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9893:	66 0f ef db          	pxor   %xmm3,%xmm3
    9897:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    989b:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    98a2:	48 89 cb             	mov    %rcx,%rbx
    98a5:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    98aa:	0f 85 bf fe ff ff    	jne    976f <fwp_main_thread+0x17f>
    98b0:	48 83 3d e0 fb 05 00 	cmpq   $0x0,0x5fbe0(%rip)        # 69498 <fwp_state_len>
    98b7:	00 
    98b8:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    98bc:	0f 84 10 04 00 00    	je     9cd2 <fwp_main_thread+0x6e2>
    98c2:	48 39 1d 2f df 05 00 	cmp    %rbx,0x5df2f(%rip)        # 677f8 <fwp_root>
    98c9:	c7 05 ad 57 01 00 00 	movl   $0x0,0x157ad(%rip)        # 1f080 <fwp_exit_code>
    98d0:	00 00 00 
    98d3:	0f 85 18 0c 00 00    	jne    a4f1 <fwp_main_thread+0xf01>
    98d9:	48 85 db             	test   %rbx,%rbx
    98dc:	0f 84 a4 01 00 00    	je     9a86 <fwp_main_thread+0x496>
    98e2:	48 8b 15 df de 05 00 	mov    0x5dedf(%rip),%rdx        # 677c8 <fwp_tasks_active>
    98e9:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    98ed:	48 85 d2             	test   %rdx,%rdx
    98f0:	0f 84 90 01 00 00    	je     9a86 <fwp_main_thread+0x496>
    98f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98fd:	00 00 00 
    9900:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9904:	75 08                	jne    990e <fwp_main_thread+0x31e>
    9906:	48 89 d7             	mov    %rdx,%rdi
    9909:	e8 02 a8 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    990e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9915:	48 85 d2             	test   %rdx,%rdx
    9918:	75 e6                	jne    9900 <fwp_main_thread+0x310>
    991a:	eb 31                	jmp    994d <fwp_main_thread+0x35d>
    991c:	0f 1f 40 00          	nopl   0x0(%rax)
    9920:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9927:	48 89 1d b2 de 05 00 	mov    %rbx,0x5deb2(%rip)        # 677e0 <fwp_ready_tail>
    992e:	e8 9d dc ff ff       	call   75d0 <fwp_block>
    9933:	e8 88 da ff ff       	call   73c0 <fwp_free_zombie>
    9938:	48 83 3d 88 de 05 00 	cmpq   $0x0,0x5de88(%rip)        # 677c8 <fwp_tasks_active>
    993f:	00 
    9940:	0f 84 40 01 00 00    	je     9a86 <fwp_main_thread+0x496>
    9946:	48 8b 1d ab de 05 00 	mov    0x5deab(%rip),%rbx        # 677f8 <fwp_root>
    994d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9951:	75 db                	jne    992e <fwp_main_thread+0x33e>
    9953:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9957:	75 d5                	jne    992e <fwp_main_thread+0x33e>
    9959:	48 8b 05 80 de 05 00 	mov    0x5de80(%rip),%rax        # 677e0 <fwp_ready_tail>
    9960:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9964:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    996b:	00 00 00 00 
    996f:	48 85 c0             	test   %rax,%rax
    9972:	75 ac                	jne    9920 <fwp_main_thread+0x330>
    9974:	48 89 1d 6d de 05 00 	mov    %rbx,0x5de6d(%rip)        # 677e8 <fwp_ready_head>
    997b:	eb aa                	jmp    9927 <fwp_main_thread+0x337>
    997d:	0f 1f 00             	nopl   (%rax)
    9980:	e8 1b ac ff ff       	call   45a0 <fwp_now_ns>
    9985:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9989:	0f 8d 21 03 00 00    	jge    9cb0 <fwp_main_thread+0x6c0>
    998f:	90                   	nop
    9990:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9994:	0f 85 ea fd ff ff    	jne    9784 <fwp_main_thread+0x194>
    999a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    999e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    99a2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    99a6:	0f 85 ea fd ff ff    	jne    9796 <fwp_main_thread+0x1a6>
    99ac:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    99b0:	48 85 c9             	test   %rcx,%rcx
    99b3:	0f 84 dd fd ff ff    	je     9796 <fwp_main_thread+0x1a6>
    99b9:	48 39 c8             	cmp    %rcx,%rax
    99bc:	48 89 ce             	mov    %rcx,%rsi
    99bf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    99c6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    99ca:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    99d1:	00 00 00 00 
    99d5:	48 0f 4e f0          	cmovle %rax,%rsi
    99d9:	48 85 c0             	test   %rax,%rax
    99dc:	48 89 c8             	mov    %rcx,%rax
    99df:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    99e6:	48 0f 45 c6          	cmovne %rsi,%rax
    99ea:	48 85 d2             	test   %rdx,%rdx
    99ed:	74 07                	je     99f6 <fwp_main_thread+0x406>
    99ef:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    99f6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    99fa:	e9 c9 fd ff ff       	jmp    97c8 <fwp_main_thread+0x1d8>
    99ff:	90                   	nop
    9a00:	48 89 cb             	mov    %rcx,%rbx
    9a03:	e9 5c fd ff ff       	jmp    9764 <fwp_main_thread+0x174>
    9a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a0f:	00 
    9a10:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9a14:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9a1b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9a22:	00 00 00 00 
    9a26:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9a2d:	48 85 c0             	test   %rax,%rax
    9a30:	0f 84 6a 09 00 00    	je     a3a0 <fwp_main_thread+0xdb0>
    9a36:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9a3d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9a41:	e9 b6 fd ff ff       	jmp    97fc <fwp_main_thread+0x20c>
    9a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a4d:	00 00 00 
    9a50:	48 89 01             	mov    %rax,(%rcx)
    9a53:	e9 de fd ff ff       	jmp    9836 <fwp_main_thread+0x246>
    9a58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a5f:	00 
    9a60:	48 83 3d 30 fa 05 00 	cmpq   $0x0,0x5fa30(%rip)        # 69498 <fwp_state_len>
    9a67:	00 
    9a68:	0f 84 62 02 00 00    	je     9cd0 <fwp_main_thread+0x6e0>
    9a6e:	48 83 3d 82 dd 05 00 	cmpq   $0x0,0x5dd82(%rip)        # 677f8 <fwp_root>
    9a75:	00 
    9a76:	c7 05 00 56 01 00 00 	movl   $0x0,0x15600(%rip)        # 1f080 <fwp_exit_code>
    9a7d:	00 00 00 
    9a80:	0f 85 66 0a 00 00    	jne    a4ec <fwp_main_thread+0xefc>
    9a86:	e8 35 d9 ff ff       	call   73c0 <fwp_free_zombie>
    9a8b:	48 83 3d 55 dd 05 00 	cmpq   $0x0,0x5dd55(%rip)        # 677e8 <fwp_ready_head>
    9a92:	00 
    9a93:	0f 85 92 9c ff ff    	jne    372b <fwp_main_thread.cold>
    9a99:	48 83 3d 37 dd 05 00 	cmpq   $0x0,0x5dd37(%rip)        # 677d8 <fwp_timers>
    9aa0:	00 
    9aa1:	0f 85 84 9c ff ff    	jne    372b <fwp_main_thread.cold>
    9aa7:	8b 05 27 d7 05 00    	mov    0x5d727(%rip),%eax        # 671d4 <fwp_stack_pool_n>
    9aad:	85 c0                	test   %eax,%eax
    9aaf:	74 3c                	je     9aed <fwp_main_thread+0x4fd>
    9ab1:	83 e8 01             	sub    $0x1,%eax
    9ab4:	4c 8d 25 25 d7 05 00 	lea    0x5d725(%rip),%r12        # 671e0 <fwp_stack_pool>
    9abb:	48 63 d8             	movslq %eax,%rbx
    9abe:	89 c0                	mov    %eax,%eax
    9ac0:	48 89 da             	mov    %rbx,%rdx
    9ac3:	48 29 c2             	sub    %rax,%rdx
    9ac6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ad0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9ad4:	89 1d fa d6 05 00    	mov    %ebx,0x5d6fa(%rip)        # 671d4 <fwp_stack_pool_n>
    9ada:	be 00 00 00 10       	mov    $0x10000000,%esi
    9adf:	48 83 eb 01          	sub    $0x1,%rbx
    9ae3:	e8 d8 9a ff ff       	call   35c0 <munmap@plt>
    9ae8:	48 39 dd             	cmp    %rbx,%rbp
    9aeb:	75 e3                	jne    9ad0 <fwp_main_thread+0x4e0>
    9aed:	8b 3d 1d 55 00 00    	mov    0x551d(%rip),%edi        # f010 <fwp_epfd>
    9af3:	85 ff                	test   %edi,%edi
    9af5:	78 05                	js     9afc <fwp_main_thread+0x50c>
    9af7:	e8 c4 99 ff ff       	call   34c0 <close@plt>
    9afc:	4c 8b 25 dd d8 05 00 	mov    0x5d8dd(%rip),%r12        # 673e0 <fwp_nfdws>
    9b03:	48 8b 2d de d8 05 00 	mov    0x5d8de(%rip),%rbp        # 673e8 <fwp_fdws>
    9b0a:	31 db                	xor    %ebx,%ebx
    9b0c:	c7 05 fa 54 00 00 ff 	movl   $0xffffffff,0x54fa(%rip)        # f010 <fwp_epfd>
    9b13:	ff ff ff 
    9b16:	4d 85 e4             	test   %r12,%r12
    9b19:	74 32                	je     9b4d <fwp_main_thread+0x55d>
    9b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b20:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9b25:	48 85 ff             	test   %rdi,%rdi
    9b28:	74 1a                	je     9b44 <fwp_main_thread+0x554>
    9b2a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9b2e:	0f 85 f7 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b34:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9b39:	0f 85 ec 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b3f:	e8 ac be ff ff       	call   59f0 <fwp_mem_free>
    9b44:	48 83 c3 01          	add    $0x1,%rbx
    9b48:	49 39 dc             	cmp    %rbx,%r12
    9b4b:	75 d3                	jne    9b20 <fwp_main_thread+0x530>
    9b4d:	48 89 ef             	mov    %rbp,%rdi
    9b50:	e8 9b be ff ff       	call   59f0 <fwp_mem_free>
    9b55:	48 8b 15 9c dc 05 00 	mov    0x5dc9c(%rip),%rdx        # 677f8 <fwp_root>
    9b5c:	48 c7 05 81 d8 05 00 	movq   $0x0,0x5d881(%rip)        # 673e8 <fwp_fdws>
    9b63:	00 00 00 00 
    9b67:	48 c7 05 6e d8 05 00 	movq   $0x0,0x5d86e(%rip)        # 673e0 <fwp_nfdws>
    9b6e:	00 00 00 00 
    9b72:	48 85 d2             	test   %rdx,%rdx
    9b75:	74 4e                	je     9bc5 <fwp_main_thread+0x5d5>
    9b77:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9b7c:	0f 85 a9 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b82:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9b89:	00 
    9b8a:	0f 85 9b 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b90:	48 83 3d 00 f9 05 00 	cmpq   $0x0,0x5f900(%rip)        # 69498 <fwp_state_len>
    9b97:	00 
    9b98:	0f 85 8d 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b9e:	48 83 3d e2 f8 05 00 	cmpq   $0x0,0x5f8e2(%rip)        # 69488 <fwp_state_owners>
    9ba5:	00 
    9ba6:	0f 85 7f 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9bac:	b9 79 00 00 00       	mov    $0x79,%ecx
    9bb1:	31 c0                	xor    %eax,%eax
    9bb3:	48 8d 3d 46 d8 05 00 	lea    0x5d846(%rip),%rdi        # 67400 <fwp_root_context>
    9bba:	f3 48 ab             	rep stos %rax,(%rdi)
    9bbd:	48 89 d7             	mov    %rdx,%rdi
    9bc0:	e8 2b be ff ff       	call   59f0 <fwp_mem_free>
    9bc5:	66 0f 6f 05 e3 55 04 	movdqa 0x455e3(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    9bcc:	00 
    9bcd:	66 0f d4 05 cb 55 04 	paddq  0x455cb(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    9bd4:	00 
    9bd5:	48 c7 05 20 dc 05 00 	movq   $0x0,0x5dc20(%rip)        # 67800 <fwp_cur>
    9bdc:	00 00 00 00 
    9be0:	48 8b 05 59 f0 05 00 	mov    0x5f059(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9be7:	48 c7 05 06 dc 05 00 	movq   $0x0,0x5dc06(%rip)        # 677f8 <fwp_root>
    9bee:	00 00 00 00 
    9bf2:	c7 05 ec f8 05 00 00 	movl   $0x0,0x5f8ec(%rip)        # 694e8 <iteration_active>
    9bf9:	00 00 00 
    9bfc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9c00:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9c05:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9c09:	66 0f d6 05 e7 54 01 	movq   %xmm0,0x154e7(%rip)        # 1f0f8 <ad_raw_before_shutdown>
    9c10:	00 
    9c11:	48 85 c0             	test   %rax,%rax
    9c14:	0f 88 46 01 00 00    	js     9d60 <fwp_main_thread+0x770>
    9c1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c1e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9c23:	f2 0f 5c 0d 9d f8 05 	subsd  0x5f89d(%rip),%xmm1        # 694c8 <iteration_start_charge>
    9c2a:	00 
    9c2b:	48 8b 3d 0e 54 00 00 	mov    0x540e(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    9c32:	48 8d 15 67 1e 00 00 	lea    0x1e67(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    9c39:	be 02 00 00 00       	mov    $0x2,%esi
    9c3e:	f2 0f 10 05 7a f8 05 	movsd  0x5f87a(%rip),%xmm0        # 694c0 <iteration_peak>
    9c45:	00 
    9c46:	4c 8b 0d 83 f8 05 00 	mov    0x5f883(%rip),%r9        # 694d0 <iteration_retains>
    9c4d:	b8 02 00 00 00       	mov    $0x2,%eax
    9c52:	4c 8b 05 7f f8 05 00 	mov    0x5f87f(%rip),%r8        # 694d8 <iteration_bytes>
    9c59:	48 8b 0d 80 f8 05 00 	mov    0x5f880(%rip),%rcx        # 694e0 <iteration_requests>
    9c60:	e8 0b 9a ff ff       	call   3670 <__fprintf_chk@plt>
    9c65:	48 8b 3d b4 53 00 00 	mov    0x53b4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    9c6c:	e8 2f 99 ff ff       	call   35a0 <fflush@plt>
    9c71:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9c78:	00 
    9c79:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c80:	00 00 
    9c82:	0f 85 47 08 00 00    	jne    a4cf <fwp_main_thread+0xedf>
    9c88:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9c8f:	31 c0                	xor    %eax,%eax
    9c91:	5b                   	pop    %rbx
    9c92:	5d                   	pop    %rbp
    9c93:	41 5c                	pop    %r12
    9c95:	41 5d                	pop    %r13
    9c97:	41 5e                	pop    %r14
    9c99:	41 5f                	pop    %r15
    9c9b:	c3                   	ret
    9c9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9ca0:	48 89 05 31 db 05 00 	mov    %rax,0x5db31(%rip)        # 677d8 <fwp_timers>
    9ca7:	e9 db fb ff ff       	jmp    9887 <fwp_main_thread+0x297>
    9cac:	0f 1f 40 00          	nopl   0x0(%rax)
    9cb0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9cb4:	0f 85 d6 fc ff ff    	jne    9990 <fwp_main_thread+0x3a0>
    9cba:	48 89 ef             	mov    %rbp,%rdi
    9cbd:	e8 4e a4 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9cc2:	e9 c9 fc ff ff       	jmp    9990 <fwp_main_thread+0x3a0>
    9cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cce:	00 00 
    9cd0:	31 db                	xor    %ebx,%ebx
    9cd2:	48 83 3d ae f7 05 00 	cmpq   $0x0,0x5f7ae(%rip)        # 69488 <fwp_state_owners>
    9cd9:	00 
    9cda:	0f 85 e2 fb ff ff    	jne    98c2 <fwp_main_thread+0x2d2>
    9ce0:	48 8b 3d b9 f7 05 00 	mov    0x5f7b9(%rip),%rdi        # 694a0 <fwp_state>
    9ce7:	e8 04 bd ff ff       	call   59f0 <fwp_mem_free>
    9cec:	48 c7 05 a9 f7 05 00 	movq   $0x0,0x5f7a9(%rip)        # 694a0 <fwp_state>
    9cf3:	00 00 00 00 
    9cf7:	48 c7 05 8e f7 05 00 	movq   $0x0,0x5f78e(%rip)        # 69490 <fwp_state_cap>
    9cfe:	00 00 00 00 
    9d02:	48 85 db             	test   %rbx,%rbx
    9d05:	0f 84 5f 07 00 00    	je     a46a <fwp_main_thread+0xe7a>
    9d0b:	48 3b 1d e6 da 05 00 	cmp    0x5dae6(%rip),%rbx        # 677f8 <fwp_root>
    9d12:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9d19:	00 00 00 00 
    9d1d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9d24:	00 00 00 00 
    9d28:	c7 05 4e 53 01 00 00 	movl   $0x0,0x1534e(%rip)        # 1f080 <fwp_exit_code>
    9d2f:	00 00 00 
    9d32:	0f 84 aa fb ff ff    	je     98e2 <fwp_main_thread+0x2f2>
    9d38:	e9 ee 99 ff ff       	jmp    372b <fwp_main_thread.cold>
    9d3d:	0f 1f 00             	nopl   (%rax)
    9d40:	48 89 c2             	mov    %rax,%rdx
    9d43:	83 e0 01             	and    $0x1,%eax
    9d46:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d4a:	48 d1 ea             	shr    $1,%rdx
    9d4d:	48 09 c2             	or     %rax,%rdx
    9d50:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9d55:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9d59:	e9 b6 f9 ff ff       	jmp    9714 <fwp_main_thread+0x124>
    9d5e:	66 90                	xchg   %ax,%ax
    9d60:	48 89 c2             	mov    %rax,%rdx
    9d63:	83 e0 01             	and    $0x1,%eax
    9d66:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d6a:	48 d1 ea             	shr    $1,%rdx
    9d6d:	48 09 c2             	or     %rax,%rdx
    9d70:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9d75:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9d79:	e9 a5 fe ff ff       	jmp    9c23 <fwp_main_thread+0x633>
    9d7e:	66 90                	xchg   %ax,%ax
    9d80:	48 8d 3d 19 af ff ff 	lea    -0x50e7(%rip),%rdi        # 4ca0 <fwp_heap_report>
    9d87:	e8 84 09 00 00       	call   a710 <atexit>
    9d8c:	e9 a3 f8 ff ff       	jmp    9634 <fwp_main_thread+0x44>
    9d91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9d98:	e8 13 b0 ff ff       	call   4db0 <fwp_heap_init>
    9d9d:	e9 84 f8 ff ff       	jmp    9626 <fwp_main_thread+0x36>
    9da2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9da8:	48 8d 05 81 de ff ff 	lea    -0x217f(%rip),%rax        # 7c30 <fwp_drop1>
    9daf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9db3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9dba:	00 00 
    9dbc:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9dc2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9dc7:	48 8b 05 ea f6 05 00 	mov    0x5f6ea(%rip),%rax        # 694b8 <fwp_cleanups>
    9dce:	4c 8d 3d 4b da 05 00 	lea    0x5da4b(%rip),%r15        # 67820 <fwp_heap>
    9dd5:	48 89 2d dc f6 05 00 	mov    %rbp,0x5f6dc(%rip)        # 694b8 <fwp_cleanups>
    9ddc:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9de0:	31 ed                	xor    %ebp,%ebp
    9de2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9de7:	48 8d 05 c2 9d ff ff 	lea    -0x623e(%rip),%rax        # 3bb0 <fwp_range_release>
    9dee:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9df3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9df8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9dfd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9e02:	eb 3d                	jmp    9e41 <fwp_main_thread+0x851>
    9e04:	0f 1f 40 00          	nopl   0x0(%rax)
    9e08:	80 f9 01             	cmp    $0x1,%cl
    9e0b:	75 29                	jne    9e36 <fwp_main_thread+0x846>
    9e0d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e10:	0f b7 c0             	movzwl %ax,%eax
    9e13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e16:	48 0f af c1          	imul   %rcx,%rax
    9e1a:	48 c1 e8 20          	shr    $0x20,%rax
    9e1e:	48 39 d0             	cmp    %rdx,%rax
    9e21:	73 13                	jae    9e36 <fwp_main_thread+0x846>
    9e23:	49 01 c5             	add    %rax,%r13
    9e26:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9e2b:	0f 84 af 05 00 00    	je     a3e0 <fwp_main_thread+0xdf0>
    9e31:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9e36:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9e3b:	49 83 ec 01          	sub    $0x1,%r12
    9e3f:	72 7f                	jb     9ec0 <fwp_main_thread+0x8d0>
    9e41:	48 89 de             	mov    %rbx,%rsi
    9e44:	bf 01 00 00 00       	mov    $0x1,%edi
    9e49:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9e50:	00 
    9e51:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9e56:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9e5d:	00 
    9e5e:	e8 7d c2 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9e63:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9e6a:	48 89 c5             	mov    %rax,%rbp
    9e6d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9e74:	48 c1 e2 10          	shl    $0x10,%rdx
    9e78:	48 39 d0             	cmp    %rdx,%rax
    9e7b:	73 b9                	jae    9e36 <fwp_main_thread+0x846>
    9e7d:	48 89 c2             	mov    %rax,%rdx
    9e80:	48 c1 ea 10          	shr    $0x10,%rdx
    9e84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e88:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9e8f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e93:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9e97:	4d 85 ed             	test   %r13,%r13
    9e9a:	74 9a                	je     9e36 <fwp_main_thread+0x846>
    9e9c:	0f b6 0a             	movzbl (%rdx),%ecx
    9e9f:	80 f9 02             	cmp    $0x2,%cl
    9ea2:	0f 85 60 ff ff ff    	jne    9e08 <fwp_main_thread+0x818>
    9ea8:	66 85 c0             	test   %ax,%ax
    9eab:	0f 84 75 ff ff ff    	je     9e26 <fwp_main_thread+0x836>
    9eb1:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9eb6:	49 83 ec 01          	sub    $0x1,%r12
    9eba:	73 85                	jae    9e41 <fwp_main_thread+0x851>
    9ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ec0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9ec5:	66 0f 6f 05 43 1e 00 	movdqa 0x1e43(%rip),%xmm0        # bd10 <msg.4+0xa0>
    9ecc:	00 
    9ecd:	48 89 de             	mov    %rbx,%rsi
    9ed0:	bf 01 00 00 00       	mov    $0x1,%edi
    9ed5:	48 89 05 dc f5 05 00 	mov    %rax,0x5f5dc(%rip)        # 694b8 <fwp_cleanups>
    9edc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9ee3:	00 
    9ee4:	e8 f7 c1 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9ee9:	48 8b 15 08 ed 05 00 	mov    0x5ed08(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    9ef0:	49 89 c4             	mov    %rax,%r12
    9ef3:	48 2b 05 d6 ec 05 00 	sub    0x5ecd6(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    9efa:	48 c1 e2 10          	shl    $0x10,%rdx
    9efe:	48 39 d0             	cmp    %rdx,%rax
    9f01:	73 55                	jae    9f58 <fwp_main_thread+0x968>
    9f03:	48 89 c2             	mov    %rax,%rdx
    9f06:	48 c1 ea 10          	shr    $0x10,%rdx
    9f0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f0e:	48 8b 15 03 ed 05 00 	mov    0x5ed03(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    9f15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f19:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9f1d:	48 85 db             	test   %rbx,%rbx
    9f20:	74 36                	je     9f58 <fwp_main_thread+0x968>
    9f22:	0f b6 0a             	movzbl (%rdx),%ecx
    9f25:	80 f9 02             	cmp    $0x2,%cl
    9f28:	0f 84 a2 04 00 00    	je     a3d0 <fwp_main_thread+0xde0>
    9f2e:	80 f9 01             	cmp    $0x1,%cl
    9f31:	75 25                	jne    9f58 <fwp_main_thread+0x968>
    9f33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f36:	0f b7 c0             	movzwl %ax,%eax
    9f39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f3c:	48 0f af c1          	imul   %rcx,%rax
    9f40:	48 c1 e8 20          	shr    $0x20,%rax
    9f44:	48 39 d0             	cmp    %rdx,%rax
    9f47:	73 0f                	jae    9f58 <fwp_main_thread+0x968>
    9f49:	48 01 c3             	add    %rax,%rbx
    9f4c:	80 3b ff             	cmpb   $0xff,(%rbx)
    9f4f:	0f 84 3b 05 00 00    	je     a490 <fwp_main_thread+0xea0>
    9f55:	c6 03 01             	movb   $0x1,(%rbx)
    9f58:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9f5d:	bf 01 00 00 00       	mov    $0x1,%edi
    9f62:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9f67:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9f6e:	00 f0 3f 
    9f71:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9f76:	e8 65 c1 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9f7b:	48 8b 15 76 ec 05 00 	mov    0x5ec76(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    9f82:	49 89 c4             	mov    %rax,%r12
    9f85:	48 2b 05 44 ec 05 00 	sub    0x5ec44(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    9f8c:	48 c1 e2 10          	shl    $0x10,%rdx
    9f90:	48 39 d0             	cmp    %rdx,%rax
    9f93:	73 55                	jae    9fea <fwp_main_thread+0x9fa>
    9f95:	48 89 c2             	mov    %rax,%rdx
    9f98:	48 c1 ea 10          	shr    $0x10,%rdx
    9f9c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fa0:	48 8b 15 71 ec 05 00 	mov    0x5ec71(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    9fa7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fab:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9faf:	48 85 db             	test   %rbx,%rbx
    9fb2:	74 36                	je     9fea <fwp_main_thread+0x9fa>
    9fb4:	0f b6 0a             	movzbl (%rdx),%ecx
    9fb7:	80 f9 02             	cmp    $0x2,%cl
    9fba:	0f 84 00 04 00 00    	je     a3c0 <fwp_main_thread+0xdd0>
    9fc0:	80 f9 01             	cmp    $0x1,%cl
    9fc3:	75 25                	jne    9fea <fwp_main_thread+0x9fa>
    9fc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fc8:	0f b7 c0             	movzwl %ax,%eax
    9fcb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fce:	48 0f af c1          	imul   %rcx,%rax
    9fd2:	48 c1 e8 20          	shr    $0x20,%rax
    9fd6:	48 39 d0             	cmp    %rdx,%rax
    9fd9:	73 0f                	jae    9fea <fwp_main_thread+0x9fa>
    9fdb:	48 01 c3             	add    %rax,%rbx
    9fde:	80 3b ff             	cmpb   $0xff,(%rbx)
    9fe1:	0f 84 b6 04 00 00    	je     a49d <fwp_main_thread+0xead>
    9fe7:	c6 03 01             	movb   $0x1,(%rbx)
    9fea:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    9fef:	bf 01 00 00 00       	mov    $0x1,%edi
    9ff4:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9ff9:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a000:	33 f3 bf 
    a003:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a008:	e8 d3 c0 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a00d:	48 8b 15 e4 eb 05 00 	mov    0x5ebe4(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a014:	48 8b 0d b5 eb 05 00 	mov    0x5ebb5(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a01b:	49 89 c4             	mov    %rax,%r12
    a01e:	48 89 d6             	mov    %rdx,%rsi
    a021:	48 29 c8             	sub    %rcx,%rax
    a024:	48 c1 e6 10          	shl    $0x10,%rsi
    a028:	48 39 f0             	cmp    %rsi,%rax
    a02b:	73 65                	jae    a092 <fwp_main_thread+0xaa2>
    a02d:	48 89 c6             	mov    %rax,%rsi
    a030:	48 c1 ee 10          	shr    $0x10,%rsi
    a034:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a038:	48 8b 35 d9 eb 05 00 	mov    0x5ebd9(%rip),%rsi        # 68c18 <fwp_heap+0x13f8>
    a03f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a043:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a047:	48 85 db             	test   %rbx,%rbx
    a04a:	74 46                	je     a092 <fwp_main_thread+0xaa2>
    a04c:	0f b6 3e             	movzbl (%rsi),%edi
    a04f:	40 80 ff 02          	cmp    $0x2,%dil
    a053:	0f 84 57 03 00 00    	je     a3b0 <fwp_main_thread+0xdc0>
    a059:	40 80 ff 01          	cmp    $0x1,%dil
    a05d:	75 33                	jne    a092 <fwp_main_thread+0xaa2>
    a05f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a062:	0f b7 c0             	movzwl %ax,%eax
    a065:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a068:	48 0f af c7          	imul   %rdi,%rax
    a06c:	48 c1 e8 20          	shr    $0x20,%rax
    a070:	48 39 f0             	cmp    %rsi,%rax
    a073:	73 1d                	jae    a092 <fwp_main_thread+0xaa2>
    a075:	48 01 c3             	add    %rax,%rbx
    a078:	80 3b ff             	cmpb   $0xff,(%rbx)
    a07b:	0f 84 29 04 00 00    	je     a4aa <fwp_main_thread+0xeba>
    a081:	c6 03 01             	movb   $0x1,(%rbx)
    a084:	48 8b 0d 45 eb 05 00 	mov    0x5eb45(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a08b:	48 8b 15 66 eb 05 00 	mov    0x5eb66(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a092:	49 89 ed             	mov    %rbp,%r13
    a095:	e9 13 02 00 00       	jmp    a2ad <fwp_main_thread+0xcbd>
    a09a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0a0:	80 f9 01             	cmp    $0x1,%cl
    a0a3:	75 3f                	jne    a0e4 <fwp_main_thread+0xaf4>
    a0a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0a8:	0f b7 c0             	movzwl %ax,%eax
    a0ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0ae:	48 0f af c1          	imul   %rcx,%rax
    a0b2:	48 c1 e8 20          	shr    $0x20,%rax
    a0b6:	48 39 d0             	cmp    %rdx,%rax
    a0b9:	73 29                	jae    a0e4 <fwp_main_thread+0xaf4>
    a0bb:	48 01 c7             	add    %rax,%rdi
    a0be:	0f b6 07             	movzbl (%rdi),%eax
    a0c1:	84 c0                	test   %al,%al
    a0c3:	74 1f                	je     a0e4 <fwp_main_thread+0xaf4>
    a0c5:	8b 15 1d f4 05 00    	mov    0x5f41d(%rip),%edx        # 694e8 <iteration_active>
    a0cb:	85 d2                	test   %edx,%edx
    a0cd:	74 08                	je     a0d7 <fwp_main_thread+0xae7>
    a0cf:	48 83 05 f9 f3 05 00 	addq   $0x1,0x5f3f9(%rip)        # 694d0 <iteration_retains>
    a0d6:	01 
    a0d7:	3c fd                	cmp    $0xfd,%al
    a0d9:	0f 87 81 03 00 00    	ja     a460 <fwp_main_thread+0xe70>
    a0df:	83 c0 01             	add    $0x1,%eax
    a0e2:	88 07                	mov    %al,(%rdi)
    a0e4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a0e9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a0ed:	b9 01 00 00 00       	mov    $0x1,%ecx
    a0f2:	4c 89 e6             	mov    %r12,%rsi
    a0f5:	48 8d 15 a4 4a 00 00 	lea    0x4aa4(%rip),%rdx        # eba0 <d0>
    a0fc:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a101:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a108:	00 00 
    a10a:	e8 a1 e4 ff ff       	call   85b0 <fwp_write>
    a10f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a114:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a119:	48 8d 05 4c 0f 00 00 	lea    0xf4c(%rip),%rax        # b06c <_IO_stdin_used+0x6c>
    a120:	48 85 c9             	test   %rcx,%rcx
    a123:	48 0f 44 c8          	cmove  %rax,%rcx
    a127:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a12b:	0f 87 92 03 00 00    	ja     a4c3 <fwp_main_thread+0xed3>
    a131:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a135:	be 01 00 00 00       	mov    $0x1,%esi
    a13a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a13f:	e8 ac bd ff ff       	call   5ef0 <fwp_heap_alloc>
    a144:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a149:	4c 89 f2             	mov    %r14,%rdx
    a14c:	4c 89 30             	mov    %r14,(%rax)
    a14f:	48 89 c3             	mov    %rax,%rbx
    a152:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a156:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a15b:	e8 20 94 ff ff       	call   3580 <memcpy@plt>
    a160:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a166:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a16b:	e8 40 92 ff ff       	call   33b0 <free@plt>
    a170:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a177:	48 89 d8             	mov    %rbx,%rax
    a17a:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a181:	48 c1 e2 10          	shl    $0x10,%rdx
    a185:	48 39 d0             	cmp    %rdx,%rax
    a188:	73 55                	jae    a1df <fwp_main_thread+0xbef>
    a18a:	48 89 c2             	mov    %rax,%rdx
    a18d:	48 c1 ea 10          	shr    $0x10,%rdx
    a191:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a195:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a19c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1a0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a1a4:	48 85 f6             	test   %rsi,%rsi
    a1a7:	74 36                	je     a1df <fwp_main_thread+0xbef>
    a1a9:	0f b6 0a             	movzbl (%rdx),%ecx
    a1ac:	80 f9 02             	cmp    $0x2,%cl
    a1af:	0f 84 4b 01 00 00    	je     a300 <fwp_main_thread+0xd10>
    a1b5:	80 f9 01             	cmp    $0x1,%cl
    a1b8:	75 25                	jne    a1df <fwp_main_thread+0xbef>
    a1ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1bd:	0f b7 c0             	movzwl %ax,%eax
    a1c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1c3:	48 0f af c1          	imul   %rcx,%rax
    a1c7:	48 c1 e8 20          	shr    $0x20,%rax
    a1cb:	48 39 d0             	cmp    %rdx,%rax
    a1ce:	73 0f                	jae    a1df <fwp_main_thread+0xbef>
    a1d0:	48 01 c6             	add    %rax,%rsi
    a1d3:	80 3e ff             	cmpb   $0xff,(%rsi)
    a1d6:	0f 84 44 01 00 00    	je     a320 <fwp_main_thread+0xd30>
    a1dc:	c6 06 01             	movb   $0x1,(%rsi)
    a1df:	4c 89 e7             	mov    %r12,%rdi
    a1e2:	e8 59 d8 ff ff       	call   7a40 <fwp_drop0>
    a1e7:	48 8b 13             	mov    (%rbx),%rdx
    a1ea:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a1ef:	be 01 00 00 00       	mov    $0x1,%esi
    a1f4:	48 8b 0d 85 f2 05 00 	mov    0x5f285(%rip),%rcx        # 69480 <fwp_prog_out>
    a1fb:	e8 60 94 ff ff       	call   3660 <fwrite@plt>
    a200:	48 8b 35 79 f2 05 00 	mov    0x5f279(%rip),%rsi        # 69480 <fwp_prog_out>
    a207:	bf 0a 00 00 00       	mov    $0xa,%edi
    a20c:	e8 bf 92 ff ff       	call   34d0 <fputc@plt>
    a211:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a218:	48 89 d8             	mov    %rbx,%rax
    a21b:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a222:	48 c1 e2 10          	shl    $0x10,%rdx
    a226:	48 39 d0             	cmp    %rdx,%rax
    a229:	73 67                	jae    a292 <fwp_main_thread+0xca2>
    a22b:	48 89 c2             	mov    %rax,%rdx
    a22e:	48 c1 ea 10          	shr    $0x10,%rdx
    a232:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a236:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a23d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a241:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a245:	4d 85 f6             	test   %r14,%r14
    a248:	74 48                	je     a292 <fwp_main_thread+0xca2>
    a24a:	0f b6 0a             	movzbl (%rdx),%ecx
    a24d:	80 f9 02             	cmp    $0x2,%cl
    a250:	0f 84 ea 00 00 00    	je     a340 <fwp_main_thread+0xd50>
    a256:	80 f9 01             	cmp    $0x1,%cl
    a259:	75 37                	jne    a292 <fwp_main_thread+0xca2>
    a25b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a25e:	0f b7 c0             	movzwl %ax,%eax
    a261:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a264:	48 0f af c1          	imul   %rcx,%rax
    a268:	48 c1 e8 20          	shr    $0x20,%rax
    a26c:	48 39 d0             	cmp    %rdx,%rax
    a26f:	73 21                	jae    a292 <fwp_main_thread+0xca2>
    a271:	49 01 c6             	add    %rax,%r14
    a274:	41 0f b6 06          	movzbl (%r14),%eax
    a278:	84 c0                	test   %al,%al
    a27a:	74 16                	je     a292 <fwp_main_thread+0xca2>
    a27c:	3c 01                	cmp    $0x1,%al
    a27e:	0f 84 0c 01 00 00    	je     a390 <fwp_main_thread+0xda0>
    a284:	3c ff                	cmp    $0xff,%al
    a286:	0f 84 64 01 00 00    	je     a3f0 <fwp_main_thread+0xe00>
    a28c:	83 e8 01             	sub    $0x1,%eax
    a28f:	41 88 06             	mov    %al,(%r14)
    a292:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a296:	4d 85 ed             	test   %r13,%r13
    a299:	0f 84 c1 00 00 00    	je     a360 <fwp_main_thread+0xd70>
    a29f:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a2a6:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a2ad:	4c 89 e0             	mov    %r12,%rax
    a2b0:	48 c1 e2 10          	shl    $0x10,%rdx
    a2b4:	48 29 c8             	sub    %rcx,%rax
    a2b7:	48 39 d0             	cmp    %rdx,%rax
    a2ba:	0f 83 24 fe ff ff    	jae    a0e4 <fwp_main_thread+0xaf4>
    a2c0:	48 89 c2             	mov    %rax,%rdx
    a2c3:	48 c1 ea 10          	shr    $0x10,%rdx
    a2c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2cb:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a2d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2d6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a2da:	48 85 ff             	test   %rdi,%rdi
    a2dd:	0f 84 01 fe ff ff    	je     a0e4 <fwp_main_thread+0xaf4>
    a2e3:	0f b6 0a             	movzbl (%rdx),%ecx
    a2e6:	80 f9 02             	cmp    $0x2,%cl
    a2e9:	0f 85 b1 fd ff ff    	jne    a0a0 <fwp_main_thread+0xab0>
    a2ef:	66 85 c0             	test   %ax,%ax
    a2f2:	0f 85 ec fd ff ff    	jne    a0e4 <fwp_main_thread+0xaf4>
    a2f8:	e9 c1 fd ff ff       	jmp    a0be <fwp_main_thread+0xace>
    a2fd:	0f 1f 00             	nopl   (%rax)
    a300:	66 85 c0             	test   %ax,%ax
    a303:	0f 85 d6 fe ff ff    	jne    a1df <fwp_main_thread+0xbef>
    a309:	80 3e ff             	cmpb   $0xff,(%rsi)
    a30c:	0f 85 ca fe ff ff    	jne    a1dc <fwp_main_thread+0xbec>
    a312:	0f 1f 00             	nopl   (%rax)
    a315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a31c:	00 00 00 00 
    a320:	48 89 f7             	mov    %rsi,%rdi
    a323:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a328:	e8 83 b4 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a32d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a332:	e9 a5 fe ff ff       	jmp    a1dc <fwp_main_thread+0xbec>
    a337:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a33e:	00 00 
    a340:	66 85 c0             	test   %ax,%ax
    a343:	0f 84 2b ff ff ff    	je     a274 <fwp_main_thread+0xc84>
    a349:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a34d:	4d 85 ed             	test   %r13,%r13
    a350:	0f 85 49 ff ff ff    	jne    a29f <fwp_main_thread+0xcaf>
    a356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a35d:	00 00 00 
    a360:	4c 89 e7             	mov    %r12,%rdi
    a363:	e8 d8 d6 ff ff       	call   7a40 <fwp_drop0>
    a368:	48 89 ef             	mov    %rbp,%rdi
    a36b:	e8 d0 d6 ff ff       	call   7a40 <fwp_drop0>
    a370:	48 c7 05 e5 4c 00 00 	movq   $0x0,0x4ce5(%rip)        # f060 <v.2>
    a377:	00 00 00 00 
    a37b:	c7 05 e3 4c 00 00 01 	movl   $0x1,0x4ce3(%rip)        # f068 <st.3>
    a382:	00 00 00 
    a385:	e9 be f3 ff ff       	jmp    9748 <fwp_main_thread+0x158>
    a38a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a390:	48 89 df             	mov    %rbx,%rdi
    a393:	e8 58 b6 ff ff       	call   59f0 <fwp_mem_free>
    a398:	e9 f5 fe ff ff       	jmp    a292 <fwp_main_thread+0xca2>
    a39d:	0f 1f 00             	nopl   (%rax)
    a3a0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a3a4:	e9 53 f4 ff ff       	jmp    97fc <fwp_main_thread+0x20c>
    a3a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3b0:	66 85 c0             	test   %ax,%ax
    a3b3:	0f 85 d9 fc ff ff    	jne    a092 <fwp_main_thread+0xaa2>
    a3b9:	e9 ba fc ff ff       	jmp    a078 <fwp_main_thread+0xa88>
    a3be:	66 90                	xchg   %ax,%ax
    a3c0:	66 85 c0             	test   %ax,%ax
    a3c3:	0f 85 21 fc ff ff    	jne    9fea <fwp_main_thread+0x9fa>
    a3c9:	e9 10 fc ff ff       	jmp    9fde <fwp_main_thread+0x9ee>
    a3ce:	66 90                	xchg   %ax,%ax
    a3d0:	66 85 c0             	test   %ax,%ax
    a3d3:	0f 85 7f fb ff ff    	jne    9f58 <fwp_main_thread+0x968>
    a3d9:	e9 6e fb ff ff       	jmp    9f4c <fwp_main_thread+0x95c>
    a3de:	66 90                	xchg   %ax,%ax
    a3e0:	4c 89 ef             	mov    %r13,%rdi
    a3e3:	e8 c8 b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a3e8:	e9 44 fa ff ff       	jmp    9e31 <fwp_main_thread+0x841>
    a3ed:	0f 1f 00             	nopl   (%rax)
    a3f0:	4c 89 f0             	mov    %r14,%rax
    a3f3:	48 c1 e8 11          	shr    $0x11,%rax
    a3f7:	4c 31 f0             	xor    %r14,%rax
    a3fa:	48 89 c2             	mov    %rax,%rdx
    a3fd:	48 c1 ea 09          	shr    $0x9,%rdx
    a401:	48 31 d0             	xor    %rdx,%rax
    a404:	0f b6 d0             	movzbl %al,%edx
    a407:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a40e:	00 
    a40f:	48 85 c0             	test   %rax,%rax
    a412:	75 19                	jne    a42d <fwp_main_thread+0xe3d>
    a414:	e9 c7 00 00 00       	jmp    a4e0 <fwp_main_thread+0xef0>
    a419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a420:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a424:	48 85 c0             	test   %rax,%rax
    a427:	0f 84 b3 00 00 00    	je     a4e0 <fwp_main_thread+0xef0>
    a42d:	48 89 c2             	mov    %rax,%rdx
    a430:	4c 3b 30             	cmp    (%rax),%r14
    a433:	75 eb                	jne    a420 <fwp_main_thread+0xe30>
    a435:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a439:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a43d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a441:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a448:	0f 85 44 fe ff ff    	jne    a292 <fwp_main_thread+0xca2>
    a44e:	4c 89 f7             	mov    %r14,%rdi
    a451:	e8 5a b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a456:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a45a:	e9 33 fe ff ff       	jmp    a292 <fwp_main_thread+0xca2>
    a45f:	90                   	nop
    a460:	e8 2b b2 ff ff       	call   5690 <fwp_rc_wide_dup>
    a465:	e9 7a fc ff ff       	jmp    a0e4 <fwp_main_thread+0xaf4>
    a46a:	48 83 3d 86 d3 05 00 	cmpq   $0x0,0x5d386(%rip)        # 677f8 <fwp_root>
    a471:	00 
    a472:	c7 05 04 4c 01 00 00 	movl   $0x0,0x14c04(%rip)        # 1f080 <fwp_exit_code>
    a479:	00 00 00 
    a47c:	0f 84 04 f6 ff ff    	je     9a86 <fwp_main_thread+0x496>
    a482:	e9 a4 92 ff ff       	jmp    372b <fwp_main_thread.cold>
    a487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a48e:	00 00 
    a490:	48 89 df             	mov    %rbx,%rdi
    a493:	e8 18 b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a498:	e9 b8 fa ff ff       	jmp    9f55 <fwp_main_thread+0x965>
    a49d:	48 89 df             	mov    %rbx,%rdi
    a4a0:	e8 0b b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a4a5:	e9 3d fb ff ff       	jmp    9fe7 <fwp_main_thread+0x9f7>
    a4aa:	48 89 df             	mov    %rbx,%rdi
    a4ad:	e8 fe b2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a4b2:	e9 ca fb ff ff       	jmp    a081 <fwp_main_thread+0xa91>
    a4b7:	48 8d 3d ba 15 00 00 	lea    0x15ba(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    a4be:	e8 6d 9f ff ff       	call   4430 <fwp_trap>
    a4c3:	48 8d 3d cd 0d 00 00 	lea    0xdcd(%rip),%rdi        # b297 <_IO_stdin_used+0x297>
    a4ca:	e8 61 9f ff ff       	call   4430 <fwp_trap>
    a4cf:	e8 7c 8f ff ff       	call   3450 <__stack_chk_fail@plt>
    a4d4:	48 8d 3d a1 0d 00 00 	lea    0xda1(%rip),%rdi        # b27c <_IO_stdin_used+0x27c>
    a4db:	e8 00 9b ff ff       	call   3fe0 <ad_raw_fail>
    a4e0:	48 8d 3d c1 14 00 00 	lea    0x14c1(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    a4e7:	e8 44 9f ff ff       	call   4430 <fwp_trap>
    a4ec:	e9 3a 92 ff ff       	jmp    372b <fwp_main_thread.cold>
    a4f1:	e9 35 92 ff ff       	jmp    372b <fwp_main_thread.cold>
    a4f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a4fd:	00 00 00 

000000000000a500 <__divmodti4>:
    a500:	f3 0f 1e fa          	endbr64
    a504:	55                   	push   %rbp
    a505:	49 89 f1             	mov    %rsi,%r9
    a508:	49 89 d2             	mov    %rdx,%r10
    a50b:	48 89 fe             	mov    %rdi,%rsi
    a50e:	49 89 cb             	mov    %rcx,%r11
    a511:	48 89 e5             	mov    %rsp,%rbp
    a514:	41 57                	push   %r15
    a516:	41 56                	push   %r14
    a518:	41 55                	push   %r13
    a51a:	41 54                	push   %r12
    a51c:	53                   	push   %rbx
    a51d:	4c 89 c3             	mov    %r8,%rbx
    a520:	45 31 c0             	xor    %r8d,%r8d
    a523:	4d 85 c9             	test   %r9,%r9
    a526:	79 12                	jns    a53a <__divmodti4+0x3a>
    a528:	31 ff                	xor    %edi,%edi
    a52a:	48 f7 de             	neg    %rsi
    a52d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a534:	4c 19 cf             	sbb    %r9,%rdi
    a537:	49 89 f9             	mov    %rdi,%r9
    a53a:	4c 89 d8             	mov    %r11,%rax
    a53d:	4d 85 db             	test   %r11,%r11
    a540:	0f 88 1a 01 00 00    	js     a660 <__divmodti4+0x160>
    a546:	4c 89 d9             	mov    %r11,%rcx
    a549:	49 89 f3             	mov    %rsi,%r11
    a54c:	75 62                	jne    a5b0 <__divmodti4+0xb0>
    a54e:	4d 89 c4             	mov    %r8,%r12
    a551:	4d 39 d1             	cmp    %r10,%r9
    a554:	0f 83 46 01 00 00    	jae    a6a0 <__divmodti4+0x1a0>
    a55a:	4c 89 d8             	mov    %r11,%rax
    a55d:	4c 89 ca             	mov    %r9,%rdx
    a560:	49 f7 f2             	div    %r10
    a563:	49 89 c3             	mov    %rax,%r11
    a566:	31 c0                	xor    %eax,%eax
    a568:	48 89 d6             	mov    %rdx,%rsi
    a56b:	31 ff                	xor    %edi,%edi
    a56d:	4c 89 d9             	mov    %r11,%rcx
    a570:	48 89 c2             	mov    %rax,%rdx
    a573:	48 89 c8             	mov    %rcx,%rax
    a576:	4d 85 e4             	test   %r12,%r12
    a579:	74 0a                	je     a585 <__divmodti4+0x85>
    a57b:	48 f7 d8             	neg    %rax
    a57e:	48 83 d2 00          	adc    $0x0,%rdx
    a582:	48 f7 da             	neg    %rdx
    a585:	4d 85 c0             	test   %r8,%r8
    a588:	74 0a                	je     a594 <__divmodti4+0x94>
    a58a:	48 f7 de             	neg    %rsi
    a58d:	48 83 d7 00          	adc    $0x0,%rdi
    a591:	48 f7 df             	neg    %rdi
    a594:	48 89 33             	mov    %rsi,(%rbx)
    a597:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a59b:	5b                   	pop    %rbx
    a59c:	41 5c                	pop    %r12
    a59e:	41 5d                	pop    %r13
    a5a0:	41 5e                	pop    %r14
    a5a2:	41 5f                	pop    %r15
    a5a4:	5d                   	pop    %rbp
    a5a5:	c3                   	ret
    a5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5ad:	00 00 00 
    a5b0:	4d 89 c4             	mov    %r8,%r12
    a5b3:	49 39 c1             	cmp    %rax,%r9
    a5b6:	0f 82 ce 00 00 00    	jb     a68a <__divmodti4+0x18a>
    a5bc:	31 ff                	xor    %edi,%edi
    a5be:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a5c3:	48 63 c7             	movslq %edi,%rax
    a5c6:	be 40 00 00 00       	mov    $0x40,%esi
    a5cb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a5d0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a5d5:	48 29 c6             	sub    %rax,%rsi
    a5d8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a5dd:	48 09 c8             	or     %rcx,%rax
    a5e0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a5e5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a5ea:	49 89 c6             	mov    %rax,%r14
    a5ed:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a5f1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a5f6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a5fb:	49 09 c1             	or     %rax,%r9
    a5fe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a602:	4c 89 c8             	mov    %r9,%rax
    a605:	49 f7 f6             	div    %r14
    a608:	48 89 d1             	mov    %rdx,%rcx
    a60b:	49 89 c3             	mov    %rax,%r11
    a60e:	49 89 c1             	mov    %rax,%r9
    a611:	49 f7 e2             	mul    %r10
    a614:	49 89 c6             	mov    %rax,%r14
    a617:	49 89 d2             	mov    %rdx,%r10
    a61a:	48 39 d1             	cmp    %rdx,%rcx
    a61d:	72 07                	jb     a626 <__divmodti4+0x126>
    a61f:	75 17                	jne    a638 <__divmodti4+0x138>
    a621:	49 39 c7             	cmp    %rax,%r15
    a624:	73 12                	jae    a638 <__divmodti4+0x138>
    a626:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a62a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a62e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a632:	49 89 d2             	mov    %rdx,%r10
    a635:	49 89 c6             	mov    %rax,%r14
    a638:	4c 89 f8             	mov    %r15,%rax
    a63b:	4c 29 f0             	sub    %r14,%rax
    a63e:	4c 19 d1             	sbb    %r10,%rcx
    a641:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a646:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a64b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a650:	48 09 c6             	or     %rax,%rsi
    a653:	48 89 cf             	mov    %rcx,%rdi
    a656:	31 c0                	xor    %eax,%eax
    a658:	4c 89 c9             	mov    %r9,%rcx
    a65b:	e9 10 ff ff ff       	jmp    a570 <__divmodti4+0x70>
    a660:	4c 89 d0             	mov    %r10,%rax
    a663:	4c 89 da             	mov    %r11,%rdx
    a666:	4d 89 c4             	mov    %r8,%r12
    a669:	49 89 f3             	mov    %rsi,%r11
    a66c:	48 f7 d8             	neg    %rax
    a66f:	49 f7 d4             	not    %r12
    a672:	48 83 d2 00          	adc    $0x0,%rdx
    a676:	49 89 c2             	mov    %rax,%r10
    a679:	48 f7 da             	neg    %rdx
    a67c:	48 89 d1             	mov    %rdx,%rcx
    a67f:	0f 84 cc fe ff ff    	je     a551 <__divmodti4+0x51>
    a685:	49 39 d1             	cmp    %rdx,%r9
    a688:	73 46                	jae    a6d0 <__divmodti4+0x1d0>
    a68a:	4c 89 cf             	mov    %r9,%rdi
    a68d:	31 c0                	xor    %eax,%eax
    a68f:	31 c9                	xor    %ecx,%ecx
    a691:	e9 da fe ff ff       	jmp    a570 <__divmodti4+0x70>
    a696:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a69d:	00 00 00 
    a6a0:	4d 85 d2             	test   %r10,%r10
    a6a3:	75 0d                	jne    a6b2 <__divmodti4+0x1b2>
    a6a5:	b8 01 00 00 00       	mov    $0x1,%eax
    a6aa:	31 d2                	xor    %edx,%edx
    a6ac:	49 f7 f2             	div    %r10
    a6af:	49 89 c2             	mov    %rax,%r10
    a6b2:	4c 89 c8             	mov    %r9,%rax
    a6b5:	31 d2                	xor    %edx,%edx
    a6b7:	49 f7 f2             	div    %r10
    a6ba:	49 89 c1             	mov    %rax,%r9
    a6bd:	4c 89 d8             	mov    %r11,%rax
    a6c0:	49 f7 f2             	div    %r10
    a6c3:	49 89 c3             	mov    %rax,%r11
    a6c6:	4c 89 c8             	mov    %r9,%rax
    a6c9:	e9 9a fe ff ff       	jmp    a568 <__divmodti4+0x68>
    a6ce:	66 90                	xchg   %ax,%ax
    a6d0:	45 31 f6             	xor    %r14d,%r14d
    a6d3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a6d8:	44 89 f7             	mov    %r14d,%edi
    a6db:	45 85 f6             	test   %r14d,%r14d
    a6de:	0f 85 df fe ff ff    	jne    a5c3 <__divmodti4+0xc3>
    a6e4:	4c 39 ca             	cmp    %r9,%rdx
    a6e7:	72 17                	jb     a700 <__divmodti4+0x200>
    a6e9:	31 c9                	xor    %ecx,%ecx
    a6eb:	48 39 c6             	cmp    %rax,%rsi
    a6ee:	73 10                	jae    a700 <__divmodti4+0x200>
    a6f0:	4c 89 cf             	mov    %r9,%rdi
    a6f3:	31 c0                	xor    %eax,%eax
    a6f5:	e9 76 fe ff ff       	jmp    a570 <__divmodti4+0x70>
    a6fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a700:	4c 89 de             	mov    %r11,%rsi
    a703:	b9 01 00 00 00       	mov    $0x1,%ecx
    a708:	48 29 c6             	sub    %rax,%rsi
    a70b:	49 19 d1             	sbb    %rdx,%r9
    a70e:	eb e0                	jmp    a6f0 <__divmodti4+0x1f0>

000000000000a710 <atexit>:
    a710:	f3 0f 1e fa          	endbr64
    a714:	48 8b 15 ed 48 00 00 	mov    0x48ed(%rip),%rdx        # f008 <__dso_handle>
    a71b:	31 f6                	xor    %esi,%esi
    a71d:	e9 1e 8f ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a724 <_fini>:
    a724:	f3 0f 1e fa          	endbr64
    a728:	48 83 ec 08          	sub    $0x8,%rsp
    a72c:	48 83 c4 08          	add    $0x8,%rsp
    a730:	c3                   	ret
