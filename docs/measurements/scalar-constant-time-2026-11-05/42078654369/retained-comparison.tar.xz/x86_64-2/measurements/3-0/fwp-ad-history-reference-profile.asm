
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 12 6d 06 00 	mov    %rax,0x66d12(%rip)        # 6a498 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c 6d 06 00 	mov    %rax,0x66d0c(%rip)        # 6a4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 cf 75 00 00 	lea    0x75cf(%rip),%rdx        # ae30 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 c7 01 00    	mov    0x1c7f8(%rip),%eax        # 200a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 93 00 00 	lea    0x9346(%rip),%rdi        # cc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 93 00 00 	lea    0x9300(%rip),%rdi        # cc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 92 00 00 	lea    0x92c4(%rip),%rdi        # cbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 92 00 00 	lea    0x9290(%rip),%rdi        # cbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 c5 04 00 	lea    0x4c5b7(%rip),%r8        # 501c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b c5 04 00 	lea    0x4c55b(%rip),%rcx        # 50180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f c5 04 00 	lea    0x4c52f(%rip),%rcx        # 50160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 c5 04 00 	lea    0x4c561(%rip),%rcx        # 501a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 c5 04 	movdqa 0x4c570(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 c5 04 	paddq  0x4c558(%rip),%xmm0        # 501c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf c4 04 00 	cmp    %rax,0x4c4bf(%rip)        # 50140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 c4 04 	movq   %xmm0,0x4c4b5(%rip)        # 50140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e c4 01 00 	add    0x1c45e(%rip),%rdx        # 20110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c c4 01 00 	add    0x1c44c(%rip),%rax        # 20110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 67 06 00 	mov    0x66799(%rip),%rdi        # 6a4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 4a 06 00 	mov    0x64ad1(%rip),%rax        # 68820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 44 06 00 	mov    0x64419(%rip),%rax        # 681e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 44 06 00 	sub    0x64405(%rip),%rax        # 681e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 8f 00 00 	lea    0x8f1d(%rip),%rsi        # cd30 <msg.8>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 5d 06 00 	mov    0x65dab(%rip),%rax        # 69c30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 5d 06 00 	lea    0x65da4(%rip),%r8        # 69c30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 5d 06 00 	mov    0x65d85(%rip),%rbx        # 69c18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 5d 06 00 	mov    0x65d95(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 5d 06 00 	mov    0x65d31(%rip),%rdi        # 69c20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 5d 06 00 	sub    %rsi,0x65d7a(%rip)        # 69c70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 5d 06 00 	mov    0x65d0a(%rip),%rax        # 69c10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 5c 06 00 	add    0x65cc0(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 5c 06 00 	mov    0x65cce(%rip),%rsi        # 69c20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 5c 06 00 	mov    0x65cdc(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 5c 06 00 	mov    %r12,0x65c8b(%rip)        # 69c20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 5c 06 00 	mov    %rbp,0x65c79(%rip)        # 69c18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 5c 06 00 	cmp    %rdi,0x65c5e(%rip)        # 69c08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 5c 06 00 	mov    %rdi,0x65c55(%rip)        # 69c08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 5c 06 00 	sub    %rdi,0x65c99(%rip)        # 69c70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 5c 06 00 	mov    0x65c41(%rip),%rax        # 69c28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 5c 06 00 	lea    0x65c3a(%rip),%r8        # 69c28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 86 00 00 	lea    0x86ef(%rip),%rdx        # c6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 46 06 00 	cmp    0x646e9(%rip),%rdi        # 68820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 46 06 00 	mov    0x646af(%rip),%rax        # 68800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 46 06 00 	mov    %rdi,0x6468d(%rip)        # 68800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 46 06 00 	mov    %rdi,0x64669(%rip)        # 68808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 80 00 00 	lea    0x805f(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 bf 04 	movdqa 0x4bf96(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e bf 04 	paddq  0x4bf7e(%rip),%xmm0        # 501c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 be 01 00 	mov    0x1bea4(%rip),%r8        # 20118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be be 04 00 	mov    0x4bebe(%rip),%rcx        # 50140 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 84 00 00 	lea    0x84b5(%rip),%rdx        # c748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 bf 04 00 	lea    0x4bf01(%rip),%r15        # 501a0 <ad_raw_peak>
    429f:	4c 8d 35 ba be 04 00 	lea    0x4beba(%rip),%r14        # 50160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf be 04 00 	lea    0x4bebf(%rip),%r13        # 50180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 84 00 00 	lea    0x848d(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 bd 01 00 	cmpq   $0x0,0x1bdc6(%rip)        # 20120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd bd 01 00 	mov    0x1bddd(%rip),%r8        # 20140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de bd 01 00 	mov    0x1bdde(%rip),%r9        # 20148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf bd 01 00 	lea    0x1bdcf(%rip),%rbx        # 20140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 bd 01 00 	mov    0x1bdd1(%rip),%rax        # 20150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 84 00 00 	lea    0x8429(%rip),%rdx        # c7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 bd 01 00 	cmp    0x1bd53(%rip),%rbp        # 20120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 83 00 00 	lea    0x8384(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 82 00 00 	lea    0x82da(%rip),%rdi        # c720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 81 00 00 	lea    0x81d8(%rip),%rdi        # c828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # cd50 <msg.8+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 5d 06 00 	add    0x65dca(%rip),%rax        # 6a498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 81 00 00 	lea    0x812c(%rip),%rdi        # c850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 b9 01 00 	cmp    %rax,0x1b9c5(%rip)        # 20108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 b9 01 00 	add    0x1b9c0(%rip),%rax        # 20110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 81 00 00 	lea    0x8115(%rip),%rdi        # c880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 75 00 00 	lea    0x759a(%rip),%rsi        # c288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 4e 06 00 	mov    0x64ea5(%rip),%r9        # 69c08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 4e 06 00 	mov    0x64efe(%rip),%r8        # 69c68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 7b 00 00 	lea    0x7b5f(%rip),%rdx        # c8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 4e 06 00 	mov    0x64ee6(%rip),%rcx        # 69c60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 4e 06 	movsd  0x64ef4(%rip),%xmm1        # 69c80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 4e 06 	movsd  0x64ee4(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 7f 00 	movdqa 0x7f88(%rip),%xmm0        # cd60 <msg.8+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 49 06 00 	lea    0x6499f(%rip),%rax        # 69780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 7f 00 	movdqa 0x7fb1(%rip),%xmm2        # cda0 <msg.8+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 49 06 00 	movaps %xmm0,0x64945(%rip)        # 69740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 7f 00 	movdqa 0x7f6d(%rip),%xmm0        # cd70 <msg.8+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 4d 06 00 01 	movl   $0x1,0x64dd3(%rip)        # 69be4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 49 06 00 	movaps %xmm0,0x64933(%rip)        # 69750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 7f 00 	movdqa 0x7f5b(%rip),%xmm0        # cd80 <msg.8+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 49 06 00 	movaps %xmm0,0x64934(%rip)        # 69760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 7f 00 	movdqa 0x7f5c(%rip),%xmm0        # cd90 <msg.8+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 49 06 00 	movaps %xmm0,0x64935(%rip)        # 69770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 39 06 00 	lea    0x639b5(%rip),%r8        # 68840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 4c 06 00 	mov    %rax,0x64cd0(%rip)        # 69bf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 4c 06 00 	mov    %r12,0x64cae(%rip)        # 69c00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 4c 06 00 	mov    %rax,0x64c97(%rip)        # 69bf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 4c 06 00 	mov    %rbx,0x64cb0(%rip)        # 69c10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 4c 06 00 	mov    %rsi,0x64cd9(%rip)        # 69c40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 4c 06 00 	mov    %rax,0x64cb8(%rip)        # 69c38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 4c 06 00    	mov    %eax,0x64c3c(%rip)        # 69be8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <caf61>:
    4fc0:	8b 15 ba b0 00 00    	mov    0xb0ba(%rip),%edx        # 10080 <st.4>
    4fc6:	85 d2                	test   %edx,%edx
    4fc8:	74 0e                	je     4fd8 <caf61+0x18>
    4fca:	48 8b 05 a7 b0 00 00 	mov    0xb0a7(%rip),%rax        # 10078 <v.3>
    4fd1:	c3                   	ret
    4fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fd8:	8b 05 92 b0 00 00    	mov    0xb092(%rip),%eax        # 10070 <st.2>
    4fde:	85 c0                	test   %eax,%eax
    4fe0:	74 1e                	je     5000 <caf61+0x40>
    4fe2:	48 8b 05 7f b0 00 00 	mov    0xb07f(%rip),%rax        # 10068 <v.1>
    4fe9:	48 89 05 88 b0 00 00 	mov    %rax,0xb088(%rip)        # 10078 <v.3>
    4ff0:	c7 05 86 b0 00 00 01 	movl   $0x1,0xb086(%rip)        # 10080 <st.4>
    4ff7:	00 00 00 
    4ffa:	c3                   	ret
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    5007:	00 f0 3f 
    500a:	c7 05 5c b0 00 00 01 	movl   $0x1,0xb05c(%rip)        # 10070 <st.2>
    5011:	00 00 00 
    5014:	48 89 05 4d b0 00 00 	mov    %rax,0xb04d(%rip)        # 10068 <v.1>
    501b:	eb cc                	jmp    4fe9 <caf61+0x29>
    501d:	0f 1f 00             	nopl   (%rax)

0000000000005020 <fwp_wake_io>:
    5020:	48 8b 07             	mov    (%rdi),%rax
    5023:	48 85 c0             	test   %rax,%rax
    5026:	0f 84 f4 00 00 00    	je     5120 <fwp_wake_io+0x100>
    502c:	53                   	push   %rbx
    502d:	4c 8b 05 cc 37 06 00 	mov    0x637cc(%rip),%r8        # 68800 <fwp_ready_tail>
    5034:	49 89 f9             	mov    %rdi,%r9
    5037:	48 89 c2             	mov    %rax,%rdx
    503a:	45 31 db             	xor    %r11d,%r11d
    503d:	45 31 d2             	xor    %r10d,%r10d
    5040:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5044:	eb 71                	jmp    50b7 <fwp_wake_io+0x97>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    5057:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    505e:	48 85 c9             	test   %rcx,%rcx
    5061:	74 07                	je     506a <fwp_wake_io+0x4a>
    5063:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    506a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5071:	00 00 00 00 
    5075:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    507c:	49 8b 01             	mov    (%r9),%rax
    507f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5083:	75 2a                	jne    50af <fwp_wake_io+0x8f>
    5085:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5089:	75 24                	jne    50af <fwp_wake_io+0x8f>
    508b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    508f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5096:	00 00 00 00 
    509a:	4d 85 c0             	test   %r8,%r8
    509d:	74 51                	je     50f0 <fwp_wake_io+0xd0>
    509f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    50a6:	49 89 d0             	mov    %rdx,%r8
    50a9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    50af:	48 89 c2             	mov    %rax,%rdx
    50b2:	48 85 c0             	test   %rax,%rax
    50b5:	74 49                	je     5100 <fwp_wake_io+0xe0>
    50b7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    50be:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    50c2:	48 85 ff             	test   %rdi,%rdi
    50c5:	74 b8                	je     507f <fwp_wake_io+0x5f>
    50c7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    50ce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    50d5:	48 85 f6             	test   %rsi,%rsi
    50d8:	0f 85 72 ff ff ff    	jne    5050 <fwp_wake_io+0x30>
    50de:	48 89 0f             	mov    %rcx,(%rdi)
    50e1:	e9 78 ff ff ff       	jmp    505e <fwp_wake_io+0x3e>
    50e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50ed:	00 00 00 
    50f0:	48 89 d3             	mov    %rdx,%rbx
    50f3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    50f9:	eb ab                	jmp    50a6 <fwp_wake_io+0x86>
    50fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5100:	45 84 db             	test   %r11b,%r11b
    5103:	74 07                	je     510c <fwp_wake_io+0xec>
    5105:	48 89 1d fc 36 06 00 	mov    %rbx,0x636fc(%rip)        # 68808 <fwp_ready_head>
    510c:	45 84 d2             	test   %r10b,%r10b
    510f:	74 07                	je     5118 <fwp_wake_io+0xf8>
    5111:	4c 89 05 e8 36 06 00 	mov    %r8,0x636e8(%rip)        # 68800 <fwp_ready_tail>
    5118:	5b                   	pop    %rbx
    5119:	c3                   	ret
    511a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5120:	c3                   	ret
    5121:	0f 1f 40 00          	nopl   0x0(%rax)
    5125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    512c:	00 00 00 00 

0000000000005130 <ad_raw_free.part.0>:
    5130:	48 8d 0d a9 b0 04 00 	lea    0x4b0a9(%rip),%rcx        # 501e0 <ad_raw_blocks>
    5137:	31 c0                	xor    %eax,%eax
    5139:	48 89 ca             	mov    %rcx,%rdx
    513c:	eb 12                	jmp    5150 <ad_raw_free.part.0+0x20>
    513e:	66 90                	xchg   %ax,%ax
    5140:	48 83 c0 01          	add    $0x1,%rax
    5144:	48 83 c2 18          	add    $0x18,%rdx
    5148:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    514e:	74 40                	je     5190 <ad_raw_free.part.0+0x60>
    5150:	48 3b 3a             	cmp    (%rdx),%rdi
    5153:	75 eb                	jne    5140 <ad_raw_free.part.0+0x10>
    5155:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5159:	66 0f ef c0          	pxor   %xmm0,%xmm0
    515d:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5161:	48 8d 0d 58 b0 04 00 	lea    0x4b058(%rip),%rcx        # 501c0 <ad_raw_live>
    5168:	8b 70 10             	mov    0x10(%rax),%esi
    516b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5172:	00 
    5173:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5177:	48 2b 50 08          	sub    0x8(%rax),%rdx
    517b:	0f 11 00             	movups %xmm0,(%rax)
    517e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5182:	e9 29 e2 ff ff       	jmp    33b0 <free@plt>
    5187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    518e:	00 00 
    5190:	48 83 ec 08          	sub    $0x8,%rsp
    5194:	48 8d 3d 62 6f 00 00 	lea    0x6f62(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    519b:	e8 60 ee ff ff       	call   4000 <ad_raw_fail>

00000000000051a0 <fwp_tape_buffers_dispose>:
    51a0:	53                   	push   %rbx
    51a1:	48 89 fb             	mov    %rdi,%rbx
    51a4:	48 8b 3f             	mov    (%rdi),%rdi
    51a7:	48 85 ff             	test   %rdi,%rdi
    51aa:	74 05                	je     51b1 <fwp_tape_buffers_dispose+0x11>
    51ac:	e8 7f ff ff ff       	call   5130 <ad_raw_free.part.0>
    51b1:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    51b5:	48 85 ff             	test   %rdi,%rdi
    51b8:	74 05                	je     51bf <fwp_tape_buffers_dispose+0x1f>
    51ba:	e8 71 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51bf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    51c3:	48 85 ff             	test   %rdi,%rdi
    51c6:	74 05                	je     51cd <fwp_tape_buffers_dispose+0x2d>
    51c8:	e8 63 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51d1:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51d8:	00 
    51d9:	0f 11 03             	movups %xmm0,(%rbx)
    51dc:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51e0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51e4:	5b                   	pop    %rbx
    51e5:	c3                   	ret
    51e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51ed:	00 00 00 

00000000000051f0 <ad_raw_realloc>:
    51f0:	41 55                	push   %r13
    51f2:	41 54                	push   %r12
    51f4:	55                   	push   %rbp
    51f5:	53                   	push   %rbx
    51f6:	48 83 ec 08          	sub    $0x8,%rsp
    51fa:	48 85 f6             	test   %rsi,%rsi
    51fd:	0f 84 a6 00 00 00    	je     52a9 <ad_raw_realloc+0xb9>
    5203:	4c 8d 25 d6 af 04 00 	lea    0x4afd6(%rip),%r12        # 501e0 <ad_raw_blocks>
    520a:	48 89 f5             	mov    %rsi,%rbp
    520d:	41 89 d5             	mov    %edx,%r13d
    5210:	31 db                	xor    %ebx,%ebx
    5212:	4c 89 e0             	mov    %r12,%rax
    5215:	eb 1a                	jmp    5231 <ad_raw_realloc+0x41>
    5217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    521e:	00 00 
    5220:	48 83 c3 01          	add    $0x1,%rbx
    5224:	48 83 c0 18          	add    $0x18,%rax
    5228:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    522f:	74 4f                	je     5280 <ad_raw_realloc+0x90>
    5231:	48 3b 38             	cmp    (%rax),%rdi
    5234:	75 ea                	jne    5220 <ad_raw_realloc+0x30>
    5236:	48 85 ff             	test   %rdi,%rdi
    5239:	74 0b                	je     5246 <ad_raw_realloc+0x56>
    523b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    523f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    5244:	75 57                	jne    529d <ad_raw_realloc+0xad>
    5246:	48 89 ee             	mov    %rbp,%rsi
    5249:	e8 62 e3 ff ff       	call   35b0 <realloc@plt>
    524e:	49 89 c2             	mov    %rax,%r10
    5251:	48 85 c0             	test   %rax,%rax
    5254:	74 16                	je     526c <ad_raw_realloc+0x7c>
    5256:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    525a:	44 89 e9             	mov    %r13d,%ecx
    525d:	48 89 ea             	mov    %rbp,%rdx
    5260:	4c 89 d6             	mov    %r10,%rsi
    5263:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5267:	e8 94 e9 ff ff       	call   3c00 <ad_raw_record>
    526c:	48 83 c4 08          	add    $0x8,%rsp
    5270:	4c 89 d0             	mov    %r10,%rax
    5273:	5b                   	pop    %rbx
    5274:	5d                   	pop    %rbp
    5275:	41 5c                	pop    %r12
    5277:	41 5d                	pop    %r13
    5279:	c3                   	ret
    527a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5280:	48 85 ff             	test   %rdi,%rdi
    5283:	48 8d 05 88 6e 00 00 	lea    0x6e88(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    528a:	48 8d 15 6c 6e 00 00 	lea    0x6e6c(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5291:	48 0f 45 c2          	cmovne %rdx,%rax
    5295:	48 89 c7             	mov    %rax,%rdi
    5298:	e8 63 ed ff ff       	call   4000 <ad_raw_fail>
    529d:	48 8d 3d a4 6e 00 00 	lea    0x6ea4(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    52a4:	e8 57 ed ff ff       	call   4000 <ad_raw_fail>
    52a9:	48 8d 3d 7d 6e 00 00 	lea    0x6e7d(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    52b0:	e8 4b ed ff ff       	call   4000 <ad_raw_fail>
    52b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52bc:	00 00 00 00 

00000000000052c0 <fwp_tape_buffers_release>:
    52c0:	f3 0f 1e fa          	endbr64
    52c4:	53                   	push   %rbx
    52c5:	48 89 fb             	mov    %rdi,%rbx
    52c8:	48 83 ec 10          	sub    $0x10,%rsp
    52cc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    52d0:	48 85 c0             	test   %rax,%rax
    52d3:	0f 88 d7 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52d9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    52dd:	48 85 d2             	test   %rdx,%rdx
    52e0:	0f 88 ca 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52e6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    52ec:	0f 87 be 00 00 00    	ja     53b0 <fwp_tape_buffers_release+0xf0>
    52f2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    52f6:	b8 00 00 08 00       	mov    $0x80000,%eax
    52fb:	48 c1 e1 03          	shl    $0x3,%rcx
    52ff:	48 29 c8             	sub    %rcx,%rax
    5302:	48 c1 e8 03          	shr    $0x3,%rax
    5306:	48 39 d0             	cmp    %rdx,%rax
    5309:	0f 82 a1 00 00 00    	jb     53b0 <fwp_tape_buffers_release+0xf0>
    530f:	48 8d 3d 4a 6e 00 00 	lea    0x6e4a(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5316:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    531b:	48 89 14 24          	mov    %rdx,(%rsp)
    531f:	e8 6c e0 ff ff       	call   3390 <getenv@plt>
    5324:	48 8b 14 24          	mov    (%rsp),%rdx
    5328:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 09                	je     533b <fwp_tape_buffers_release+0x7b>
    5332:	80 38 30             	cmpb   $0x30,(%rax)
    5335:	0f 84 05 01 00 00    	je     5440 <fwp_tape_buffers_release+0x180>
    533b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    533f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    5343:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    5349:	77 71                	ja     53bc <fwp_tape_buffers_release+0xfc>
    534b:	48 8d 3d 6e ad 01 00 	lea    0x1ad6e(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    5352:	48 89 34 24          	mov    %rsi,(%rsp)
    5356:	e8 45 fe ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    535b:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    535f:	48 8b 34 24          	mov    (%rsp),%rsi
    5363:	0f 29 05 56 ad 01 00 	movaps %xmm0,0x1ad56(%rip)        # 200c0 <fwp_tape_workspace>
    536a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    536f:	48 89 35 32 ad 01 00 	mov    %rsi,0x1ad32(%rip)        # 200a8 <fwp_tape_cached_bytes>
    5376:	0f 29 05 53 ad 01 00 	movaps %xmm0,0x1ad53(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    537d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5382:	0f 29 05 57 ad 01 00 	movaps %xmm0,0x1ad57(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    5389:	48 8b 43 30          	mov    0x30(%rbx),%rax
    538d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5391:	48 89 05 58 ad 01 00 	mov    %rax,0x1ad58(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    5398:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    539f:	00 
    53a0:	0f 11 03             	movups %xmm0,(%rbx)
    53a3:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    53a7:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    53ab:	eb 1e                	jmp    53cb <fwp_tape_buffers_release+0x10b>
    53ad:	0f 1f 00             	nopl   (%rax)
    53b0:	48 8d 3d a9 6d 00 00 	lea    0x6da9(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    53b7:	e8 d4 df ff ff       	call   3390 <getenv@plt>
    53bc:	48 89 df             	mov    %rbx,%rdi
    53bf:	e8 dc fd ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    53c4:	48 8b 35 dd ac 01 00 	mov    0x1acdd(%rip),%rsi        # 200a8 <fwp_tape_cached_bytes>
    53cb:	48 6b 15 2d ad 01 00 	imul   $0x68,0x1ad2d(%rip),%rdx        # 20100 <fwp_tapes_cap>
    53d2:	68 
    53d3:	48 3b 15 e6 ad 04 00 	cmp    0x4ade6(%rip),%rdx        # 501c0 <ad_raw_live>
    53da:	75 73                	jne    544f <fwp_tape_buffers_release+0x18f>
    53dc:	48 8b 05 e5 ad 04 00 	mov    0x4ade5(%rip),%rax        # 501c8 <ad_raw_live+0x8>
    53e3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    53e7:	48 01 d0             	add    %rdx,%rax
    53ea:	48 03 05 df ad 04 00 	add    0x4addf(%rip),%rax        # 501d0 <ad_raw_live+0x10>
    53f1:	48 03 05 e0 ad 04 00 	add    0x4ade0(%rip),%rax        # 501d8 <ad_raw_live+0x18>
    53f8:	48 39 c8             	cmp    %rcx,%rax
    53fb:	72 52                	jb     544f <fwp_tape_buffers_release+0x18f>
    53fd:	48 8b 0d 1c ad 01 00 	mov    0x1ad1c(%rip),%rcx        # 20120 <ad_raw_checkpoint_count>
    5404:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    540b:	74 4e                	je     545b <fwp_tape_buffers_release+0x19b>
    540d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5411:	48 29 d0             	sub    %rdx,%rax
    5414:	48 89 3d 05 ad 01 00 	mov    %rdi,0x1ad05(%rip)        # 20120 <ad_raw_checkpoint_count>
    541b:	48 29 f0             	sub    %rsi,%rax
    541e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5422:	48 8d 0d 17 ad 01 00 	lea    0x1ad17(%rip),%rcx        # 20140 <ad_raw_checkpoints>
    5429:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    542d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5432:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5437:	48 83 c4 10          	add    $0x10,%rsp
    543b:	5b                   	pop    %rbx
    543c:	c3                   	ret
    543d:	0f 1f 00             	nopl   (%rax)
    5440:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5444:	0f 84 72 ff ff ff    	je     53bc <fwp_tape_buffers_release+0xfc>
    544a:	e9 ec fe ff ff       	jmp    533b <fwp_tape_buffers_release+0x7b>
    544f:	48 8d 3d 02 75 00 00 	lea    0x7502(%rip),%rdi        # c958 <_IO_stdin_used+0x958>
    5456:	e8 a5 eb ff ff       	call   4000 <ad_raw_fail>
    545b:	48 8d 3d 0f 6d 00 00 	lea    0x6d0f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5462:	e8 99 eb ff ff       	call   4000 <ad_raw_fail>
    5467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    546e:	00 00 

0000000000005470 <fwp_poll_events>:
    5470:	53                   	push   %rbx
    5471:	48 83 ec 20          	sub    $0x20,%rsp
    5475:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    547c:	00 00 
    547e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5483:	31 c0                	xor    %eax,%eax
    5485:	e8 36 f1 ff ff       	call   45c0 <fwp_now_ns>
    548a:	48 8b 1d 67 33 06 00 	mov    0x63367(%rip),%rbx        # 687f8 <fwp_timers>
    5491:	48 85 db             	test   %rbx,%rbx
    5494:	0f 84 e6 00 00 00    	je     5580 <fwp_poll_events+0x110>
    549a:	48 89 c6             	mov    %rax,%rsi
    549d:	48 89 da             	mov    %rbx,%rdx
    54a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    54a7:	eb 26                	jmp    54cf <fwp_poll_events+0x5f>
    54a9:	90                   	nop
    54aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54b1:	00 00 00 00 
    54b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54bc:	00 00 00 00 
    54c0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54c7:	48 89 c8             	mov    %rcx,%rax
    54ca:	48 85 d2             	test   %rdx,%rdx
    54cd:	74 31                	je     5500 <fwp_poll_events+0x90>
    54cf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54d3:	48 85 c0             	test   %rax,%rax
    54d6:	78 e8                	js     54c0 <fwp_poll_events+0x50>
    54d8:	48 39 c1             	cmp    %rax,%rcx
    54db:	7c e3                	jl     54c0 <fwp_poll_events+0x50>
    54dd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 1c                	je     5505 <fwp_poll_events+0x95>
    54e9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54ed:	48 39 c1             	cmp    %rax,%rcx
    54f0:	7c ce                	jl     54c0 <fwp_poll_events+0x50>
    54f2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54f9:	48 85 d2             	test   %rdx,%rdx
    54fc:	75 d1                	jne    54cf <fwp_poll_events+0x5f>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	48 85 c0             	test   %rax,%rax
    5503:	78 7b                	js     5580 <fwp_poll_events+0x110>
    5505:	48 29 f0             	sub    %rsi,%rax
    5508:	48 89 c1             	mov    %rax,%rcx
    550b:	48 85 c0             	test   %rax,%rax
    550e:	0f 8e 9c 00 00 00    	jle    55b0 <fwp_poll_events+0x140>
    5514:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    551b:	de 1b 43 
    551e:	48 f7 ea             	imul   %rdx
    5521:	48 89 c8             	mov    %rcx,%rax
    5524:	48 c1 f8 3f          	sar    $0x3f,%rax
    5528:	48 c1 fa 12          	sar    $0x12,%rdx
    552c:	48 29 c2             	sub    %rax,%rdx
    552f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5536:	48 39 c1             	cmp    %rax,%rcx
    5539:	0f 95 c0             	setne  %al
    553c:	0f b6 c0             	movzbl %al,%eax
    553f:	48 01 d0             	add    %rdx,%rax
    5542:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5548:	0f 8f 32 01 00 00    	jg     5680 <fwp_poll_events+0x210>
    554e:	48 85 c0             	test   %rax,%rax
    5551:	74 5d                	je     55b0 <fwp_poll_events+0x140>
    5553:	89 c1                	mov    %eax,%ecx
    5555:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    555c:	48 c1 e9 26          	shr    $0x26,%rcx
    5560:	48 63 d1             	movslq %ecx,%rdx
    5563:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5569:	29 c8                	sub    %ecx,%eax
    556b:	48 98                	cltq
    556d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5574:	e9 11 01 00 00       	jmp    568a <fwp_poll_events+0x21a>
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	e8 7b e7 ff ff       	call   3d00 <fwp_flush>
    5585:	ba 2b 00 00 00       	mov    $0x2b,%edx
    558a:	be 01 00 00 00       	mov    $0x1,%esi
    558f:	48 8b 0d aa aa 00 00 	mov    0xaaaa(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5596:	48 8d 3d eb 73 00 00 	lea    0x73eb(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    559d:	e8 be e0 ff ff       	call   3660 <fwrite@plt>
    55a2:	bf 65 00 00 00       	mov    $0x65,%edi
    55a7:	e8 a4 e0 ff ff       	call   3650 <exit@plt>
    55ac:	0f 1f 40 00          	nopl   0x0(%rax)
    55b0:	e8 0b f0 ff ff       	call   45c0 <fwp_now_ns>
    55b5:	48 89 c1             	mov    %rax,%rcx
    55b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55bc:	eb 44                	jmp    5602 <fwp_poll_events+0x192>
    55be:	66 90                	xchg   %ax,%ax
    55c0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    55c4:	75 33                	jne    55f9 <fwp_poll_events+0x189>
    55c6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ca:	75 2d                	jne    55f9 <fwp_poll_events+0x189>
    55cc:	48 8b 05 2d 32 06 00 	mov    0x6322d(%rip),%rax        # 68800 <fwp_ready_tail>
    55d3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    55d7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    55de:	00 00 00 00 
    55e2:	48 85 c0             	test   %rax,%rax
    55e5:	0f 84 05 01 00 00    	je     56f0 <fwp_poll_events+0x280>
    55eb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    55f2:	48 89 15 07 32 06 00 	mov    %rdx,0x63207(%rip)        # 68800 <fwp_ready_tail>
    55f9:	48 85 db             	test   %rbx,%rbx
    55fc:	0f 84 be 00 00 00    	je     56c0 <fwp_poll_events+0x250>
    5602:	48 89 da             	mov    %rbx,%rdx
    5605:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    560c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5610:	7f e7                	jg     55f9 <fwp_poll_events+0x189>
    5612:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5616:	74 2e                	je     5646 <fwp_poll_events+0x1d6>
    5618:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    561f:	48 85 c0             	test   %rax,%rax
    5622:	0f 84 b8 00 00 00    	je     56e0 <fwp_poll_events+0x270>
    5628:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    562f:	48 85 db             	test   %rbx,%rbx
    5632:	74 07                	je     563b <fwp_poll_events+0x1cb>
    5634:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    563b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    563f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5646:	48 8b 42 60          	mov    0x60(%rdx),%rax
    564a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    564e:	48 85 c0             	test   %rax,%rax
    5651:	0f 84 69 ff ff ff    	je     55c0 <fwp_poll_events+0x150>
    5657:	48 39 c8             	cmp    %rcx,%rax
    565a:	0f 8f 60 ff ff ff    	jg     55c0 <fwp_poll_events+0x150>
    5660:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5664:	0f 85 56 ff ff ff    	jne    55c0 <fwp_poll_events+0x150>
    566a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    566e:	75 89                	jne    55f9 <fwp_poll_events+0x189>
    5670:	48 89 d7             	mov    %rdx,%rdi
    5673:	e8 b8 ea ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5678:	e9 43 ff ff ff       	jmp    55c0 <fwp_poll_events+0x150>
    567d:	0f 1f 00             	nopl   (%rax)
    5680:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5685:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    568a:	48 89 e7             	mov    %rsp,%rdi
    568d:	31 f6                	xor    %esi,%esi
    568f:	48 89 14 24          	mov    %rdx,(%rsp)
    5693:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5698:	e8 f3 dd ff ff       	call   3490 <nanosleep@plt>
    569d:	48 8b 1d 54 31 06 00 	mov    0x63154(%rip),%rbx        # 687f8 <fwp_timers>
    56a4:	e8 17 ef ff ff       	call   45c0 <fwp_now_ns>
    56a9:	48 89 c1             	mov    %rax,%rcx
    56ac:	48 85 db             	test   %rbx,%rbx
    56af:	0f 85 03 ff ff ff    	jne    55b8 <fwp_poll_events+0x148>
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    56c5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    56cc:	00 00 
    56ce:	75 2c                	jne    56fc <fwp_poll_events+0x28c>
    56d0:	48 83 c4 20          	add    $0x20,%rsp
    56d4:	5b                   	pop    %rbx
    56d5:	c3                   	ret
    56d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56dd:	00 00 00 
    56e0:	48 89 1d 11 31 06 00 	mov    %rbx,0x63111(%rip)        # 687f8 <fwp_timers>
    56e7:	e9 43 ff ff ff       	jmp    562f <fwp_poll_events+0x1bf>
    56ec:	0f 1f 40 00          	nopl   0x0(%rax)
    56f0:	48 89 15 11 31 06 00 	mov    %rdx,0x63111(%rip)        # 68808 <fwp_ready_head>
    56f7:	e9 f6 fe ff ff       	jmp    55f2 <fwp_poll_events+0x182>
    56fc:	e8 4f dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5701:	0f 1f 40 00          	nopl   0x0(%rax)
    5705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    570c:	00 00 00 00 

0000000000005710 <fwp_rc_wide_dup>:
    5710:	48 89 fa             	mov    %rdi,%rdx
    5713:	48 8d 35 26 31 06 00 	lea    0x63126(%rip),%rsi        # 68840 <fwp_heap>
    571a:	48 83 ec 18          	sub    $0x18,%rsp
    571e:	48 89 f9             	mov    %rdi,%rcx
    5721:	48 c1 ea 11          	shr    $0x11,%rdx
    5725:	48 31 fa             	xor    %rdi,%rdx
    5728:	48 89 d0             	mov    %rdx,%rax
    572b:	48 c1 e8 09          	shr    $0x9,%rax
    572f:	48 31 c2             	xor    %rax,%rdx
    5732:	0f b6 d2             	movzbl %dl,%edx
    5735:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    573c:	00 
    573d:	49 8b 00             	mov    (%r8),%rax
    5740:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5747:	00 00 
    5749:	75 21                	jne    576c <fwp_rc_wide_dup+0x5c>
    574b:	e9 98 00 00 00       	jmp    57e8 <fwp_rc_wide_dup+0xd8>
    5750:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    575c:	00 00 00 00 
    5760:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5764:	48 85 d2             	test   %rdx,%rdx
    5767:	74 2f                	je     5798 <fwp_rc_wide_dup+0x88>
    5769:	48 89 d0             	mov    %rdx,%rax
    576c:	48 3b 08             	cmp    (%rax),%rcx
    576f:	75 ef                	jne    5760 <fwp_rc_wide_dup+0x50>
    5771:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5774:	74 7c                	je     57f2 <fwp_rc_wide_dup+0xe2>
    5776:	48 8b 50 08          	mov    0x8(%rax),%rdx
    577a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    577e:	0f 84 91 00 00 00    	je     5815 <fwp_rc_wide_dup+0x105>
    5784:	48 83 c2 01          	add    $0x1,%rdx
    5788:	48 89 50 08          	mov    %rdx,0x8(%rax)
    578c:	48 83 c4 18          	add    $0x18,%rsp
    5790:	c3                   	ret
    5791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5798:	4c 8d 40 10          	lea    0x10(%rax),%r8
    579c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    579f:	75 68                	jne    5809 <fwp_rc_wide_dup+0xf9>
    57a1:	bf 18 00 00 00       	mov    $0x18,%edi
    57a6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    57ab:	4c 89 04 24          	mov    %r8,(%rsp)
    57af:	e8 dc dd ff ff       	call   3590 <malloc@plt>
    57b4:	4c 8b 04 24          	mov    (%rsp),%r8
    57b8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    57bd:	48 85 c0             	test   %rax,%rax
    57c0:	74 5f                	je     5821 <fwp_rc_wide_dup+0x111>
    57c2:	48 89 08             	mov    %rcx,(%rax)
    57c5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    57cc:	00 
    57cd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    57d4:	00 
    57d5:	49 89 00             	mov    %rax,(%r8)
    57d8:	c6 01 ff             	movb   $0xff,(%rcx)
    57db:	48 83 05 a5 4c 06 00 	addq   $0x1,0x64ca5(%rip)        # 6a488 <fwp_heap+0x1c48>
    57e2:	01 
    57e3:	48 83 c4 18          	add    $0x18,%rsp
    57e7:	c3                   	ret
    57e8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    57eb:	75 13                	jne    5800 <fwp_rc_wide_dup+0xf0>
    57ed:	48 85 c0             	test   %rax,%rax
    57f0:	74 af                	je     57a1 <fwp_rc_wide_dup+0x91>
    57f2:	48 8d 3d bf 71 00 00 	lea    0x71bf(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    57f9:	e8 52 ec ff ff       	call   4450 <fwp_trap>
    57fe:	66 90                	xchg   %ax,%ax
    5800:	48 85 c0             	test   %rax,%rax
    5803:	0f 85 6d ff ff ff    	jne    5776 <fwp_rc_wide_dup+0x66>
    5809:	48 8d 3d d0 71 00 00 	lea    0x71d0(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    5810:	e8 3b ec ff ff       	call   4450 <fwp_trap>
    5815:	48 8d 3d 72 69 00 00 	lea    0x6972(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    581c:	e8 2f ec ff ff       	call   4450 <fwp_trap>
    5821:	e8 0a e6 ff ff       	call   3e30 <fwp_heap_oom>
    5826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    582d:	00 00 00 

0000000000005830 <fwp_rc_forget_slot>:
    5830:	80 3f ff             	cmpb   $0xff,(%rdi)
    5833:	74 0b                	je     5840 <fwp_rc_forget_slot+0x10>
    5835:	c3                   	ret
    5836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    583d:	00 00 00 
    5840:	48 89 f8             	mov    %rdi,%rax
    5843:	48 83 ec 08          	sub    $0x8,%rsp
    5847:	48 89 fa             	mov    %rdi,%rdx
    584a:	48 c1 e8 11          	shr    $0x11,%rax
    584e:	48 31 f8             	xor    %rdi,%rax
    5851:	48 89 c1             	mov    %rax,%rcx
    5854:	48 c1 e9 09          	shr    $0x9,%rcx
    5858:	48 31 c8             	xor    %rcx,%rax
    585b:	48 8d 0d de 2f 06 00 	lea    0x62fde(%rip),%rcx        # 68840 <fwp_heap>
    5862:	0f b6 c0             	movzbl %al,%eax
    5865:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    586c:	00 
    586d:	48 85 ff             	test   %rdi,%rdi
    5870:	74 3c                	je     58ae <fwp_rc_forget_slot+0x7e>
    5872:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5879:	00 
    587a:	48 8b 01             	mov    (%rcx),%rax
    587d:	eb 11                	jmp    5890 <fwp_rc_forget_slot+0x60>
    587f:	90                   	nop
    5880:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5884:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5888:	48 85 ff             	test   %rdi,%rdi
    588b:	74 21                	je     58ae <fwp_rc_forget_slot+0x7e>
    588d:	48 89 f8             	mov    %rdi,%rax
    5890:	48 3b 10             	cmp    (%rax),%rdx
    5893:	75 eb                	jne    5880 <fwp_rc_forget_slot+0x50>
    5895:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5899:	48 89 01             	mov    %rax,(%rcx)
    589c:	e8 0f db ff ff       	call   33b0 <free@plt>
    58a1:	48 83 2d df 4b 06 00 	subq   $0x1,0x64bdf(%rip)        # 6a488 <fwp_heap+0x1c48>
    58a8:	01 
    58a9:	48 83 c4 08          	add    $0x8,%rsp
    58ad:	c3                   	ret
    58ae:	48 8d 3d 2b 71 00 00 	lea    0x712b(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    58b5:	e8 96 eb ff ff       	call   4450 <fwp_trap>
    58ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000058c0 <fwp_rc_prepare_chunk>:
    58c0:	48 83 3d c0 4b 06 00 	cmpq   $0x0,0x64bc0(%rip)        # 6a488 <fwp_heap+0x1c48>
    58c7:	00 
    58c8:	41 54                	push   %r12
    58ca:	49 89 f4             	mov    %rsi,%r12
    58cd:	55                   	push   %rbp
    58ce:	48 89 fd             	mov    %rdi,%rbp
    58d1:	53                   	push   %rbx
    58d2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    58d5:	0f 84 7d 00 00 00    	je     5958 <fwp_rc_prepare_chunk+0x98>
    58db:	31 db                	xor    %ebx,%ebx
    58dd:	85 c0                	test   %eax,%eax
    58df:	75 5f                	jne    5940 <fwp_rc_prepare_chunk+0x80>
    58e1:	48 85 f6             	test   %rsi,%rsi
    58e4:	74 7c                	je     5962 <fwp_rc_prepare_chunk+0xa2>
    58e6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    58ea:	e8 c1 da ff ff       	call   33b0 <free@plt>
    58ef:	90                   	nop
    58f0:	be 01 00 00 00       	mov    $0x1,%esi
    58f5:	4c 89 e7             	mov    %r12,%rdi
    58f8:	e8 13 dc ff ff       	call   3510 <calloc@plt>
    58fd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5901:	48 85 c0             	test   %rax,%rax
    5904:	0f 85 87 00 00 00    	jne    5991 <fwp_rc_prepare_chunk+0xd1>
    590a:	e8 21 e5 ff ff       	call   3e30 <fwp_heap_oom>
    590f:	90                   	nop
    5910:	e8 1b ff ff ff       	call   5830 <fwp_rc_forget_slot>
    5915:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5918:	48 83 c3 01          	add    $0x1,%rbx
    591c:	48 39 c3             	cmp    %rax,%rbx
    591f:	73 37                	jae    5958 <fwp_rc_prepare_chunk+0x98>
    5921:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5928:	00 00 
    592a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5931:	00 00 00 00 
    5935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    593c:	00 00 00 00 
    5940:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5944:	48 01 df             	add    %rbx,%rdi
    5947:	80 3f ff             	cmpb   $0xff,(%rdi)
    594a:	74 c4                	je     5910 <fwp_rc_prepare_chunk+0x50>
    594c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    594f:	48 83 c3 01          	add    $0x1,%rbx
    5953:	48 39 c3             	cmp    %rax,%rbx
    5956:	72 e8                	jb     5940 <fwp_rc_prepare_chunk+0x80>
    5958:	49 39 c4             	cmp    %rax,%r12
    595b:	75 13                	jne    5970 <fwp_rc_prepare_chunk+0xb0>
    595d:	4d 85 e4             	test   %r12,%r12
    5960:	75 46                	jne    59a8 <fwp_rc_prepare_chunk+0xe8>
    5962:	5b                   	pop    %rbx
    5963:	5d                   	pop    %rbp
    5964:	41 5c                	pop    %r12
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5974:	48 29 05 15 4b 06 00 	sub    %rax,0x64b15(%rip)        # 6a490 <fwp_heap+0x1c50>
    597b:	e8 30 da ff ff       	call   33b0 <free@plt>
    5980:	4d 85 e4             	test   %r12,%r12
    5983:	0f 85 67 ff ff ff    	jne    58f0 <fwp_rc_prepare_chunk+0x30>
    5989:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5990:	00 
    5991:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5995:	5b                   	pop    %rbx
    5996:	4c 01 25 f3 4a 06 00 	add    %r12,0x64af3(%rip)        # 6a490 <fwp_heap+0x1c50>
    599d:	5d                   	pop    %rbp
    599e:	41 5c                	pop    %r12
    59a0:	c3                   	ret
    59a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    59ac:	5b                   	pop    %rbx
    59ad:	4c 89 e2             	mov    %r12,%rdx
    59b0:	31 f6                	xor    %esi,%esi
    59b2:	5d                   	pop    %rbp
    59b3:	41 5c                	pop    %r12
    59b5:	e9 f6 da ff ff       	jmp    34b0 <memset@plt>
    59ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000059c0 <fwp_heap_refill>:
    59c0:	41 56                	push   %r14
    59c2:	41 89 d6             	mov    %edx,%r14d
    59c5:	41 55                	push   %r13
    59c7:	41 89 f5             	mov    %esi,%r13d
    59ca:	41 54                	push   %r12
    59cc:	49 89 fc             	mov    %rdi,%r12
    59cf:	bf 01 00 00 00       	mov    $0x1,%edi
    59d4:	55                   	push   %rbp
    59d5:	53                   	push   %rbx
    59d6:	e8 95 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    59db:	48 89 c3             	mov    %rax,%rbx
    59de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    59e2:	48 8b 05 4f 42 06 00 	mov    0x6424f(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    59e9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    59ed:	48 8d 05 4c 2e 06 00 	lea    0x62e4c(%rip),%rax        # 68840 <fwp_heap>
    59f4:	31 d2                	xor    %edx,%edx
    59f6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    59fa:	48 89 ef             	mov    %rbp,%rdi
    59fd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5a01:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5a05:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    5a0c:	00 
    5a0d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5a12:	f7 f1                	div    %ecx
    5a14:	31 d2                	xor    %edx,%edx
    5a16:	66 0f 6e c1          	movd   %ecx,%xmm0
    5a1a:	66 0f 6e c8          	movd   %eax,%xmm1
    5a1e:	89 c6                	mov    %eax,%esi
    5a20:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5a25:	48 01 c8             	add    %rcx,%rax
    5a28:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5a2c:	48 f7 f1             	div    %rcx
    5a2f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5a34:	89 45 18             	mov    %eax,0x18(%rbp)
    5a37:	e8 84 fe ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5a3c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    5a3f:	48 89 d8             	mov    %rbx,%rax
    5a42:	48 c1 e0 10          	shl    $0x10,%rax
    5a46:	48 03 05 a3 41 06 00 	add    0x641a3(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    5a4d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5a51:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5a56:	8b 55 08             	mov    0x8(%rbp),%edx
    5a59:	48 0f af d1          	imul   %rcx,%rdx
    5a5d:	48 01 c2             	add    %rax,%rdx
    5a60:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a65:	5b                   	pop    %rbx
    5a66:	5d                   	pop    %rbp
    5a67:	41 5c                	pop    %r12
    5a69:	41 5d                	pop    %r13
    5a6b:	41 5e                	pop    %r14
    5a6d:	c3                   	ret
    5a6e:	66 90                	xchg   %ax,%ax

0000000000005a70 <fwp_mem_free>:
    5a70:	48 85 ff             	test   %rdi,%rdi
    5a73:	0f 84 17 02 00 00    	je     5c90 <fwp_mem_free+0x220>
    5a79:	48 8b 35 70 41 06 00 	mov    0x64170(%rip),%rsi        # 69bf0 <fwp_heap+0x13b0>
    5a80:	48 8b 05 91 41 06 00 	mov    0x64191(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    5a87:	48 89 fa             	mov    %rdi,%rdx
    5a8a:	48 29 f2             	sub    %rsi,%rdx
    5a8d:	48 c1 e0 10          	shl    $0x10,%rax
    5a91:	48 39 c2             	cmp    %rax,%rdx
    5a94:	0f 83 f6 01 00 00    	jae    5c90 <fwp_mem_free+0x220>
    5a9a:	49 89 d1             	mov    %rdx,%r9
    5a9d:	49 c1 e9 10          	shr    $0x10,%r9
    5aa1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5aa5:	48 c1 e0 03          	shl    $0x3,%rax
    5aa9:	49 89 c0             	mov    %rax,%r8
    5aac:	4c 03 05 85 41 06 00 	add    0x64185(%rip),%r8        # 69c38 <fwp_heap+0x13f8>
    5ab3:	0f 84 d7 01 00 00    	je     5c90 <fwp_mem_free+0x220>
    5ab9:	48 83 ec 38          	sub    $0x38,%rsp
    5abd:	48 89 f9             	mov    %rdi,%rcx
    5ac0:	41 0f b6 38          	movzbl (%r8),%edi
    5ac4:	40 80 ff 01          	cmp    $0x1,%dil
    5ac8:	74 16                	je     5ae0 <fwp_mem_free+0x70>
    5aca:	40 80 ff 02          	cmp    $0x2,%dil
    5ace:	0f 84 94 00 00 00    	je     5b68 <fwp_mem_free+0xf8>
    5ad4:	48 83 c4 38          	add    $0x38,%rsp
    5ad8:	c3                   	ret
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5ae4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5ae9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5aee:	41 8b 78 04          	mov    0x4(%r8),%edi
    5af2:	4d 85 d2             	test   %r10,%r10
    5af5:	74 1d                	je     5b14 <fwp_mem_free+0xa4>
    5af7:	0f b7 c1             	movzwl %cx,%eax
    5afa:	31 d2                	xor    %edx,%edx
    5afc:	48 f7 f7             	div    %rdi
    5aff:	49 01 c2             	add    %rax,%r10
    5b02:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5b06:	0f 84 44 01 00 00    	je     5c50 <fwp_mem_free+0x1e0>
    5b0c:	41 c6 02 00          	movb   $0x0,(%r10)
    5b10:	41 8b 78 04          	mov    0x4(%r8),%edi
    5b14:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5b1b:	49 63 c1             	movslq %r9d,%rax
    5b1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b22:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b26:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5b2b:	f2 0f 58 05 4d 41 06 	addsd  0x6414d(%rip),%xmm0        # 69c80 <fwp_heap+0x1440>
    5b32:	00 
    5b33:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5b37:	48 8d 05 02 2d 06 00 	lea    0x62d02(%rip),%rax        # 68840 <fwp_heap>
    5b3e:	48 01 d0             	add    %rdx,%rax
    5b41:	48 8b 10             	mov    (%rax),%rdx
    5b44:	48 f7 d2             	not    %rdx
    5b47:	48 89 11             	mov    %rdx,(%rcx)
    5b4a:	48 89 08             	mov    %rcx,(%rax)
    5b4d:	48 29 3d 0c 41 06 00 	sub    %rdi,0x6410c(%rip)        # 69c60 <fwp_heap+0x1420>
    5b54:	f2 0f 11 05 24 41 06 	movsd  %xmm0,0x64124(%rip)        # 69c80 <fwp_heap+0x1440>
    5b5b:	00 
    5b5c:	48 83 c4 38          	add    $0x38,%rsp
    5b60:	c3                   	ret
    5b61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b68:	66 31 d2             	xor    %dx,%dx
    5b6b:	48 01 d6             	add    %rdx,%rsi
    5b6e:	48 39 f1             	cmp    %rsi,%rcx
    5b71:	0f 85 5d ff ff ff    	jne    5ad4 <fwp_mem_free+0x64>
    5b77:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b7b:	48 29 15 de 40 06 00 	sub    %rdx,0x640de(%rip)        # 69c60 <fwp_heap+0x1420>
    5b82:	48 85 d2             	test   %rdx,%rdx
    5b85:	0f 88 a5 00 00 00    	js     5c30 <fwp_mem_free+0x1c0>
    5b8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b8f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b94:	f2 0f 58 05 e4 40 06 	addsd  0x640e4(%rip),%xmm0        # 69c80 <fwp_heap+0x1440>
    5b9b:	00 
    5b9c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ba0:	f2 0f 11 05 d8 40 06 	movsd  %xmm0,0x640d8(%rip)        # 69c80 <fwp_heap+0x1440>
    5ba7:	00 
    5ba8:	48 85 d2             	test   %rdx,%rdx
    5bab:	74 0c                	je     5bb9 <fwp_mem_free+0x149>
    5bad:	80 3a ff             	cmpb   $0xff,(%rdx)
    5bb0:	0f 84 db 00 00 00    	je     5c91 <fwp_mem_free+0x221>
    5bb6:	c6 02 00             	movb   $0x0,(%rdx)
    5bb9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5bbd:	48 85 c9             	test   %rcx,%rcx
    5bc0:	74 3e                	je     5c00 <fwp_mem_free+0x190>
    5bc2:	48 8b 15 6f 40 06 00 	mov    0x6406f(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    5bc9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bcd:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5bd1:	48 01 d0             	add    %rdx,%rax
    5bd4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5bd8:	48 89 d6             	mov    %rdx,%rsi
    5bdb:	48 29 c6             	sub    %rax,%rsi
    5bde:	83 e6 08             	and    $0x8,%esi
    5be1:	74 0d                	je     5bf0 <fwp_mem_free+0x180>
    5be3:	c6 00 00             	movb   $0x0,(%rax)
    5be6:	48 83 c0 28          	add    $0x28,%rax
    5bea:	48 39 c2             	cmp    %rax,%rdx
    5bed:	74 11                	je     5c00 <fwp_mem_free+0x190>
    5bef:	90                   	nop
    5bf0:	c6 00 00             	movb   $0x0,(%rax)
    5bf3:	48 83 c0 50          	add    $0x50,%rax
    5bf7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5bfb:	48 39 c2             	cmp    %rax,%rdx
    5bfe:	75 f0                	jne    5bf0 <fwp_mem_free+0x180>
    5c00:	48 01 0d 69 40 06 00 	add    %rcx,0x64069(%rip)        # 69c70 <fwp_heap+0x1430>
    5c07:	4c 3b 0d 22 40 06 00 	cmp    0x64022(%rip),%r9        # 69c30 <fwp_heap+0x13f0>
    5c0e:	73 07                	jae    5c17 <fwp_mem_free+0x1a7>
    5c10:	4c 89 0d 19 40 06 00 	mov    %r9,0x64019(%rip)        # 69c30 <fwp_heap+0x13f0>
    5c17:	4c 3b 0d 0a 40 06 00 	cmp    0x6400a(%rip),%r9        # 69c28 <fwp_heap+0x13e8>
    5c1e:	0f 83 b0 fe ff ff    	jae    5ad4 <fwp_mem_free+0x64>
    5c24:	4c 89 0d fd 3f 06 00 	mov    %r9,0x63ffd(%rip)        # 69c28 <fwp_heap+0x13e8>
    5c2b:	e9 a4 fe ff ff       	jmp    5ad4 <fwp_mem_free+0x64>
    5c30:	48 89 d1             	mov    %rdx,%rcx
    5c33:	83 e2 01             	and    $0x1,%edx
    5c36:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c3a:	48 d1 e9             	shr    $1,%rcx
    5c3d:	48 09 d1             	or     %rdx,%rcx
    5c40:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5c45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5c49:	e9 46 ff ff ff       	jmp    5b94 <fwp_mem_free+0x124>
    5c4e:	66 90                	xchg   %ax,%ax
    5c50:	4c 89 d7             	mov    %r10,%rdi
    5c53:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5c58:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5c5d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c62:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c66:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c6b:	e8 c0 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5c70:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c75:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c7a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c7f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c84:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c89:	e9 7e fe ff ff       	jmp    5b0c <fwp_mem_free+0x9c>
    5c8e:	66 90                	xchg   %ax,%ax
    5c90:	c3                   	ret
    5c91:	48 89 d7             	mov    %rdx,%rdi
    5c94:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c99:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c9e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5ca3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5ca8:	e8 83 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5cad:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5cb2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5cb7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5cbc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5cc1:	e9 f0 fe ff ff       	jmp    5bb6 <fwp_mem_free+0x146>
    5cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ccd:	00 00 00 

0000000000005cd0 <fwp_heap_alloc_big>:
    5cd0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5cd7:	00 00 40 
    5cda:	41 57                	push   %r15
    5cdc:	41 56                	push   %r14
    5cde:	41 55                	push   %r13
    5ce0:	41 54                	push   %r12
    5ce2:	55                   	push   %rbp
    5ce3:	53                   	push   %rbx
    5ce4:	48 83 ec 08          	sub    $0x8,%rsp
    5ce8:	48 39 f8             	cmp    %rdi,%rax
    5ceb:	0f 82 fa 00 00 00    	jb     5deb <fwp_heap_alloc_big+0x11b>
    5cf1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5cf8:	49 89 fd             	mov    %rdi,%r13
    5cfb:	41 89 f6             	mov    %esi,%r14d
    5cfe:	48 c1 ed 10          	shr    $0x10,%rbp
    5d02:	48 89 ef             	mov    %rbp,%rdi
    5d05:	e8 66 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5d0a:	be 01 00 00 00       	mov    $0x1,%esi
    5d0f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5d13:	49 89 c4             	mov    %rax,%r12
    5d16:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5d1d:	00 
    5d1e:	48 03 3d 13 3f 06 00 	add    0x63f13(%rip),%rdi        # 69c38 <fwp_heap+0x13f8>
    5d25:	c6 07 02             	movb   $0x2,(%rdi)
    5d28:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5d2c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5d2f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5d33:	e8 88 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d38:	48 83 fd 01          	cmp    $0x1,%rbp
    5d3c:	76 47                	jbe    5d85 <fwp_heap_alloc_big+0xb5>
    5d3e:	4c 01 e5             	add    %r12,%rbp
    5d41:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5d48:	00 
    5d49:	4c 8d 3d f0 2a 06 00 	lea    0x62af0(%rip),%r15        # 68840 <fwp_heap>
    5d50:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5d55:	49 c1 e6 03          	shl    $0x3,%r14
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d67:	31 f6                	xor    %esi,%esi
    5d69:	48 01 dd             	add    %rbx,%rbp
    5d6c:	48 83 c3 28          	add    $0x28,%rbx
    5d70:	48 89 ef             	mov    %rbp,%rdi
    5d73:	e8 48 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d78:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d7c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d80:	49 39 de             	cmp    %rbx,%r14
    5d83:	75 db                	jne    5d60 <fwp_heap_alloc_big+0x90>
    5d85:	49 c1 e4 10          	shl    $0x10,%r12
    5d89:	4c 03 25 60 3e 06 00 	add    0x63e60(%rip),%r12        # 69bf0 <fwp_heap+0x13b0>
    5d90:	4c 89 ea             	mov    %r13,%rdx
    5d93:	31 f6                	xor    %esi,%esi
    5d95:	4c 89 e7             	mov    %r12,%rdi
    5d98:	e8 13 d7 ff ff       	call   34b0 <memset@plt>
    5d9d:	4c 89 e8             	mov    %r13,%rax
    5da0:	48 03 05 b9 3e 06 00 	add    0x63eb9(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    5da7:	72 42                	jb     5deb <fwp_heap_alloc_big+0x11b>
    5da9:	48 39 05 b8 3e 06 00 	cmp    %rax,0x63eb8(%rip)        # 69c68 <fwp_heap+0x1428>
    5db0:	48 89 05 a9 3e 06 00 	mov    %rax,0x63ea9(%rip)        # 69c60 <fwp_heap+0x1420>
    5db7:	73 07                	jae    5dc0 <fwp_heap_alloc_big+0xf0>
    5db9:	48 89 05 a8 3e 06 00 	mov    %rax,0x63ea8(%rip)        # 69c68 <fwp_heap+0x1428>
    5dc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dc4:	4c 89 e0             	mov    %r12,%rax
    5dc7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5dcc:	f2 0f 58 05 a4 3e 06 	addsd  0x63ea4(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    5dd3:	00 
    5dd4:	f2 0f 11 05 9c 3e 06 	movsd  %xmm0,0x63e9c(%rip)        # 69c78 <fwp_heap+0x1438>
    5ddb:	00 
    5ddc:	48 83 c4 08          	add    $0x8,%rsp
    5de0:	5b                   	pop    %rbx
    5de1:	5d                   	pop    %rbp
    5de2:	41 5c                	pop    %r12
    5de4:	41 5d                	pop    %r13
    5de6:	41 5e                	pop    %r14
    5de8:	41 5f                	pop    %r15
    5dea:	c3                   	ret
    5deb:	e8 40 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005df0 <fwp_heap_alloc_slow>:
    5df0:	53                   	push   %rbx
    5df1:	48 89 f9             	mov    %rdi,%rcx
    5df4:	41 89 f1             	mov    %esi,%r9d
    5df7:	48 83 ec 10          	sub    $0x10,%rsp
    5dfb:	8b 05 e3 3d 06 00    	mov    0x63de3(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    5e01:	85 c0                	test   %eax,%eax
    5e03:	0f 84 c7 00 00 00    	je     5ed0 <fwp_heap_alloc_slow+0xe0>
    5e09:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e10:	0f 87 dd 00 00 00    	ja     5ef3 <fwp_heap_alloc_slow+0x103>
    5e16:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5e1a:	48 8d 3d 1f 2a 06 00 	lea    0x62a1f(%rip),%rdi        # 68840 <fwp_heap>
    5e21:	49 63 f1             	movslq %r9d,%rsi
    5e24:	48 c1 e8 04          	shr    $0x4,%rax
    5e28:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5e2f:	00 00 
    5e31:	41 0f b6 c2          	movzbl %r10b,%eax
    5e35:	4c 89 d2             	mov    %r10,%rdx
    5e38:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5e3c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5e43:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5e4a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5e4e:	48 01 f8             	add    %rdi,%rax
    5e51:	4c 8b 00             	mov    (%rax),%r8
    5e54:	4d 85 c0             	test   %r8,%r8
    5e57:	0f 84 ab 00 00 00    	je     5f08 <fwp_heap_alloc_slow+0x118>
    5e5d:	49 8b 10             	mov    (%r8),%rdx
    5e60:	48 f7 d2             	not    %rdx
    5e63:	48 89 10             	mov    %rdx,(%rax)
    5e66:	41 83 f9 01          	cmp    $0x1,%r9d
    5e6a:	4c 89 c7             	mov    %r8,%rdi
    5e6d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e71:	31 f6                	xor    %esi,%esi
    5e73:	48 89 ca             	mov    %rcx,%rdx
    5e76:	e8 35 d6 ff ff       	call   34b0 <memset@plt>
    5e7b:	49 89 c0             	mov    %rax,%r8
    5e7e:	48 89 d8             	mov    %rbx,%rax
    5e81:	48 03 05 d8 3d 06 00 	add    0x63dd8(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    5e88:	0f 82 d9 00 00 00    	jb     5f67 <fwp_heap_alloc_slow+0x177>
    5e8e:	48 39 05 d3 3d 06 00 	cmp    %rax,0x63dd3(%rip)        # 69c68 <fwp_heap+0x1428>
    5e95:	48 89 05 c4 3d 06 00 	mov    %rax,0x63dc4(%rip)        # 69c60 <fwp_heap+0x1420>
    5e9c:	73 07                	jae    5ea5 <fwp_heap_alloc_slow+0xb5>
    5e9e:	48 89 05 c3 3d 06 00 	mov    %rax,0x63dc3(%rip)        # 69c68 <fwp_heap+0x1428>
    5ea5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ea9:	4c 89 c0             	mov    %r8,%rax
    5eac:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5eb1:	f2 0f 58 05 bf 3d 06 	addsd  0x63dbf(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 b7 3d 06 	movsd  %xmm0,0x63db7(%rip)        # 69c78 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	48 83 c4 10          	add    $0x10,%rsp
    5ec5:	5b                   	pop    %rbx
    5ec6:	c3                   	ret
    5ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ece:	00 00 
    5ed0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5ed4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5ed8:	e8 f3 ee ff ff       	call   4dd0 <fwp_heap_init>
    5edd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5ee1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5ee6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5eed:	0f 86 23 ff ff ff    	jbe    5e16 <fwp_heap_alloc_slow+0x26>
    5ef3:	48 83 c4 10          	add    $0x10,%rsp
    5ef7:	44 89 ce             	mov    %r9d,%esi
    5efa:	48 89 cf             	mov    %rcx,%rdi
    5efd:	5b                   	pop    %rbx
    5efe:	e9 cd fd ff ff       	jmp    5cd0 <fwp_heap_alloc_big>
    5f03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f08:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5f0c:	4d 85 c0             	test   %r8,%r8
    5f0f:	74 1f                	je     5f30 <fwp_heap_alloc_slow+0x140>
    5f11:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5f15:	4d 29 c3             	sub    %r8,%r11
    5f18:	49 39 db             	cmp    %rbx,%r11
    5f1b:	72 13                	jb     5f30 <fwp_heap_alloc_slow+0x140>
    5f1d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5f21:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f25:	e9 3c ff ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5f37:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5f3b:	44 89 ca             	mov    %r9d,%edx
    5f3e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5f43:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f47:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5f4b:	44 89 d6             	mov    %r10d,%esi
    5f4e:	48 01 c7             	add    %rax,%rdi
    5f51:	e8 6a fa ff ff       	call   59c0 <fwp_heap_refill>
    5f56:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5f5b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f5f:	49 89 c0             	mov    %rax,%r8
    5f62:	e9 ff fe ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f67:	e8 c4 de ff ff       	call   3e30 <fwp_heap_oom>
    5f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f70 <fwp_heap_alloc>:
    5f70:	53                   	push   %rbx
    5f71:	48 89 fa             	mov    %rdi,%rdx
    5f74:	48 83 ec 10          	sub    $0x10,%rsp
    5f78:	8b 1d 8a 45 06 00    	mov    0x6458a(%rip),%ebx        # 6a508 <iteration_active>
    5f7e:	8b 05 60 3c 06 00    	mov    0x63c60(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    5f84:	85 db                	test   %ebx,%ebx
    5f86:	0f 85 04 01 00 00    	jne    6090 <fwp_heap_alloc+0x120>
    5f8c:	85 c0                	test   %eax,%eax
    5f8e:	0f 84 ac 01 00 00    	je     6140 <fwp_heap_alloc+0x1d0>
    5f94:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f9b:	0f 87 9f 01 00 00    	ja     6140 <fwp_heap_alloc+0x1d0>
    5fa1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5fa5:	48 8d 05 94 28 06 00 	lea    0x62894(%rip),%rax        # 68840 <fwp_heap>
    5fac:	48 c1 e9 04          	shr    $0x4,%rcx
    5fb0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5fb7:	00 
    5fb8:	48 63 ce             	movslq %esi,%rcx
    5fbb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5fc2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5fc9:	00 
    5fca:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5fce:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5fd2:	48 01 c8             	add    %rcx,%rax
    5fd5:	48 8b 08             	mov    (%rax),%rcx
    5fd8:	48 85 c9             	test   %rcx,%rcx
    5fdb:	0f 84 ff 00 00 00    	je     60e0 <fwp_heap_alloc+0x170>
    5fe1:	48 8b 39             	mov    (%rcx),%rdi
    5fe4:	48 f7 d7             	not    %rdi
    5fe7:	48 89 38             	mov    %rdi,(%rax)
    5fea:	83 fe 01             	cmp    $0x1,%esi
    5fed:	48 89 cf             	mov    %rcx,%rdi
    5ff0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ff5:	49 0f 45 d0          	cmovne %r8,%rdx
    5ff9:	31 f6                	xor    %esi,%esi
    5ffb:	e8 b0 d4 ff ff       	call   34b0 <memset@plt>
    6000:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    6005:	48 89 c1             	mov    %rax,%rcx
    6008:	4c 89 c0             	mov    %r8,%rax
    600b:	48 03 05 4e 3c 06 00 	add    0x63c4e(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    6012:	0f 82 35 01 00 00    	jb     614d <fwp_heap_alloc+0x1dd>
    6018:	48 39 05 49 3c 06 00 	cmp    %rax,0x63c49(%rip)        # 69c68 <fwp_heap+0x1428>
    601f:	48 89 05 3a 3c 06 00 	mov    %rax,0x63c3a(%rip)        # 69c60 <fwp_heap+0x1420>
    6026:	73 07                	jae    602f <fwp_heap_alloc+0xbf>
    6028:	48 89 05 39 3c 06 00 	mov    %rax,0x63c39(%rip)        # 69c68 <fwp_heap+0x1428>
    602f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6033:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    6038:	f2 0f 58 05 38 3c 06 	addsd  0x63c38(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    603f:	00 
    6040:	f2 0f 11 05 30 3c 06 	movsd  %xmm0,0x63c30(%rip)        # 69c78 <fwp_heap+0x1438>
    6047:	00 
    6048:	85 db                	test   %ebx,%ebx
    604a:	74 33                	je     607f <fwp_heap_alloc+0x10f>
    604c:	48 8b 05 0d 3c 06 00 	mov    0x63c0d(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    6053:	48 85 c0             	test   %rax,%rax
    6056:	0f 88 ac 00 00 00    	js     6108 <fwp_heap_alloc+0x198>
    605c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6060:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6065:	f2 0f 5c 05 7b 44 06 	subsd  0x6447b(%rip),%xmm0        # 6a4e8 <iteration_start_charge>
    606c:	00 
    606d:	66 0f 2f 05 6b 44 06 	comisd 0x6446b(%rip),%xmm0        # 6a4e0 <iteration_peak>
    6074:	00 
    6075:	76 08                	jbe    607f <fwp_heap_alloc+0x10f>
    6077:	f2 0f 11 05 61 44 06 	movsd  %xmm0,0x64461(%rip)        # 6a4e0 <iteration_peak>
    607e:	00 
    607f:	48 83 c4 10          	add    $0x10,%rsp
    6083:	48 89 c8             	mov    %rcx,%rax
    6086:	5b                   	pop    %rbx
    6087:	c3                   	ret
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	85 f6                	test   %esi,%esi
    6092:	74 34                	je     60c8 <fwp_heap_alloc+0x158>
    6094:	48 83 05 64 44 06 00 	addq   $0x1,0x64464(%rip)        # 6a500 <iteration_requests>
    609b:	01 
    609c:	48 01 3d 55 44 06 00 	add    %rdi,0x64455(%rip)        # 6a4f8 <iteration_bytes>
    60a3:	85 c0                	test   %eax,%eax
    60a5:	74 0d                	je     60b4 <fwp_heap_alloc+0x144>
    60a7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60ae:	0f 86 ed fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60b4:	48 89 d7             	mov    %rdx,%rdi
    60b7:	e8 34 fd ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60bc:	48 89 c1             	mov    %rax,%rcx
    60bf:	eb 8b                	jmp    604c <fwp_heap_alloc+0xdc>
    60c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c8:	85 c0                	test   %eax,%eax
    60ca:	74 0d                	je     60d9 <fwp_heap_alloc+0x169>
    60cc:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60d3:	0f 86 c8 fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60d9:	31 f6                	xor    %esi,%esi
    60db:	eb d7                	jmp    60b4 <fwp_heap_alloc+0x144>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    60e4:	48 85 c9             	test   %rcx,%rcx
    60e7:	74 0c                	je     60f5 <fwp_heap_alloc+0x185>
    60e9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    60ed:	48 29 cf             	sub    %rcx,%rdi
    60f0:	4c 39 c7             	cmp    %r8,%rdi
    60f3:	73 3b                	jae    6130 <fwp_heap_alloc+0x1c0>
    60f5:	48 89 d7             	mov    %rdx,%rdi
    60f8:	e8 f3 fc ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60fd:	48 89 c1             	mov    %rax,%rcx
    6100:	e9 43 ff ff ff       	jmp    6048 <fwp_heap_alloc+0xd8>
    6105:	0f 1f 00             	nopl   (%rax)
    6108:	48 89 c2             	mov    %rax,%rdx
    610b:	83 e0 01             	and    $0x1,%eax
    610e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6112:	48 d1 ea             	shr    $1,%rdx
    6115:	48 09 c2             	or     %rax,%rdx
    6118:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    611d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6121:	e9 3f ff ff ff       	jmp    6065 <fwp_heap_alloc+0xf5>
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6134:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6138:	e9 ad fe ff ff       	jmp    5fea <fwp_heap_alloc+0x7a>
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	48 83 c4 10          	add    $0x10,%rsp
    6144:	48 89 d7             	mov    %rdx,%rdi
    6147:	5b                   	pop    %rbx
    6148:	e9 a3 fc ff ff       	jmp    5df0 <fwp_heap_alloc_slow>
    614d:	e8 de dc ff ff       	call   3e30 <fwp_heap_oom>
    6152:	0f 1f 00             	nopl   (%rax)
    6155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    615c:	00 00 00 00 

0000000000006160 <fwp_apply>:
    6160:	55                   	push   %rbp
    6161:	48 89 f9             	mov    %rdi,%rcx
    6164:	48 89 e5             	mov    %rsp,%rbp
    6167:	41 57                	push   %r15
    6169:	41 56                	push   %r14
    616b:	41 55                	push   %r13
    616d:	41 89 f5             	mov    %esi,%r13d
    6170:	41 54                	push   %r12
    6172:	53                   	push   %rbx
    6173:	48 83 ec 28          	sub    $0x28,%rsp
    6177:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    617e:	00 00 
    6180:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6184:	49 89 d6             	mov    %rdx,%r14
    6187:	44 8b 09             	mov    (%rcx),%r9d
    618a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    618e:	49 89 e0             	mov    %rsp,%r8
    6191:	49 c1 e1 05          	shl    $0x5,%r9
    6195:	4c 03 0d fc 42 06 00 	add    0x642fc(%rip),%r9        # 6a498 <fwp_fns>
    619c:	41 8b 19             	mov    (%r9),%ebx
    619f:	45 85 e4             	test   %r12d,%r12d
    61a2:	75 2c                	jne    61d0 <fwp_apply+0x70>
    61a4:	41 39 dd             	cmp    %ebx,%r13d
    61a7:	72 27                	jb     61d0 <fwp_apply+0x70>
    61a9:	85 db                	test   %ebx,%ebx
    61ab:	0f 84 b7 01 00 00    	je     6368 <fwp_apply+0x208>
    61b1:	4c 89 f7             	mov    %r14,%rdi
    61b4:	41 ff 51 08          	call   *0x8(%r9)
    61b8:	48 89 c1             	mov    %rax,%rcx
    61bb:	41 39 dd             	cmp    %ebx,%r13d
    61be:	0f 84 7c 01 00 00    	je     6340 <fwp_apply+0x1e0>
    61c4:	89 d8                	mov    %ebx,%eax
    61c6:	41 29 dd             	sub    %ebx,%r13d
    61c9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    61cd:	eb b8                	jmp    6187 <fwp_apply+0x27>
    61cf:	90                   	nop
    61d0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    61d5:	41 39 df             	cmp    %ebx,%r15d
    61d8:	0f 82 dc 00 00 00    	jb     62ba <fwp_apply+0x15a>
    61de:	41 89 df             	mov    %ebx,%r15d
    61e1:	b8 01 00 00 00       	mov    $0x1,%eax
    61e6:	48 89 e2             	mov    %rsp,%rdx
    61e9:	45 29 e7             	sub    %r12d,%r15d
    61ec:	85 db                	test   %ebx,%ebx
    61ee:	0f 45 c3             	cmovne %ebx,%eax
    61f1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    61f8:	00 
    61f9:	48 c1 e8 04          	shr    $0x4,%rax
    61fd:	48 c1 e0 04          	shl    $0x4,%rax
    6201:	48 89 c6             	mov    %rax,%rsi
    6204:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    620b:	48 29 f2             	sub    %rsi,%rdx
    620e:	48 39 d4             	cmp    %rdx,%rsp
    6211:	74 15                	je     6228 <fwp_apply+0xc8>
    6213:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    621a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    6221:	00 00 
    6223:	48 39 d4             	cmp    %rdx,%rsp
    6226:	75 eb                	jne    6213 <fwp_apply+0xb3>
    6228:	25 ff 0f 00 00       	and    $0xfff,%eax
    622d:	48 29 c4             	sub    %rax,%rsp
    6230:	48 85 c0             	test   %rax,%rax
    6233:	0f 85 59 01 00 00    	jne    6392 <fwp_apply+0x232>
    6239:	45 89 e2             	mov    %r12d,%r10d
    623c:	48 89 e6             	mov    %rsp,%rsi
    623f:	48 89 e7             	mov    %rsp,%rdi
    6242:	31 c0                	xor    %eax,%eax
    6244:	49 c1 e2 03          	shl    $0x3,%r10
    6248:	45 85 e4             	test   %r12d,%r12d
    624b:	74 25                	je     6272 <fwp_apply+0x112>
    624d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6254:	00 
    6255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    625c:	00 00 00 00 
    6260:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6265:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6269:	48 83 c0 08          	add    $0x8,%rax
    626d:	4c 39 d0             	cmp    %r10,%rax
    6270:	75 ee                	jne    6260 <fwp_apply+0x100>
    6272:	45 85 ff             	test   %r15d,%r15d
    6275:	0f 84 f4 00 00 00    	je     636f <fwp_apply+0x20f>
    627b:	44 89 fa             	mov    %r15d,%edx
    627e:	4c 89 f0             	mov    %r14,%rax
    6281:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6285:	44 89 e2             	mov    %r12d,%edx
    6288:	66 90                	xchg   %ax,%ax
    628a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6291:	00 00 00 00 
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 
    62a0:	4c 8b 10             	mov    (%rax),%r10
    62a3:	89 d1                	mov    %edx,%ecx
    62a5:	48 83 c0 08          	add    $0x8,%rax
    62a9:	83 c2 01             	add    $0x1,%edx
    62ac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    62b0:	4c 39 d8             	cmp    %r11,%rax
    62b3:	75 eb                	jne    62a0 <fwp_apply+0x140>
    62b5:	e9 b5 00 00 00       	jmp    636f <fwp_apply+0x20f>
    62ba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    62be:	be 02 00 00 00       	mov    $0x2,%esi
    62c3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    62c7:	48 c1 e7 03          	shl    $0x3,%rdi
    62cb:	e8 a0 fc ff ff       	call   5f70 <fwp_heap_alloc>
    62d0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    62d4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    62d9:	48 89 c3             	mov    %rax,%rbx
    62dc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    62e0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    62e4:	66 0f d6 00          	movq   %xmm0,(%rax)
    62e8:	45 85 e4             	test   %r12d,%r12d
    62eb:	74 14                	je     6301 <fwp_apply+0x1a1>
    62ed:	44 89 e2             	mov    %r12d,%edx
    62f0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    62f4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    62f8:	48 c1 e2 03          	shl    $0x3,%rdx
    62fc:	e8 ef d2 ff ff       	call   35f0 <memmove@plt>
    6301:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    6305:	45 85 ed             	test   %r13d,%r13d
    6308:	74 2e                	je     6338 <fwp_apply+0x1d8>
    630a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6311:	00 00 00 00 
    6315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    631c:	00 00 00 00 
    6320:	49 8b 16             	mov    (%r14),%rdx
    6323:	44 89 e0             	mov    %r12d,%eax
    6326:	49 83 c6 08          	add    $0x8,%r14
    632a:	41 83 c4 01          	add    $0x1,%r12d
    632e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    6333:	49 39 ce             	cmp    %rcx,%r14
    6336:	75 e8                	jne    6320 <fwp_apply+0x1c0>
    6338:	48 89 d9             	mov    %rbx,%rcx
    633b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6340:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    6344:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    634b:	00 00 
    634d:	75 4e                	jne    639d <fwp_apply+0x23d>
    634f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    6353:	48 89 c8             	mov    %rcx,%rax
    6356:	5b                   	pop    %rbx
    6357:	41 5c                	pop    %r12
    6359:	41 5d                	pop    %r13
    635b:	41 5e                	pop    %r14
    635d:	41 5f                	pop    %r15
    635f:	5d                   	pop    %rbp
    6360:	c3                   	ret
    6361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6368:	45 31 ff             	xor    %r15d,%r15d
    636b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    636f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6373:	41 ff 51 08          	call   *0x8(%r9)
    6377:	48 89 c1             	mov    %rax,%rcx
    637a:	45 39 fd             	cmp    %r15d,%r13d
    637d:	74 c1                	je     6340 <fwp_apply+0x1e0>
    637f:	45 01 e5             	add    %r12d,%r13d
    6382:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6386:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    638a:	41 29 dd             	sub    %ebx,%r13d
    638d:	e9 f5 fd ff ff       	jmp    6187 <fwp_apply+0x27>
    6392:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6398:	e9 9c fe ff ff       	jmp    6239 <fwp_apply+0xd9>
    639d:	e8 ae d0 ff ff       	call   3450 <__stack_chk_fail@plt>
    63a2:	0f 1f 00             	nopl   (%rax)
    63a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ac:	00 00 00 00 

00000000000063b0 <fwp_p_ad_push>:
    63b0:	41 57                	push   %r15
    63b2:	41 56                	push   %r14
    63b4:	41 55                	push   %r13
    63b6:	49 89 d5             	mov    %rdx,%r13
    63b9:	41 54                	push   %r12
    63bb:	49 89 fc             	mov    %rdi,%r12
    63be:	55                   	push   %rbp
    63bf:	53                   	push   %rbx
    63c0:	48 83 ec 38          	sub    $0x38,%rsp
    63c4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    63c9:	48 85 ff             	test   %rdi,%rdi
    63cc:	79 09                	jns    63d7 <fwp_p_ad_push+0x27>
    63ce:	48 85 d2             	test   %rdx,%rdx
    63d1:	0f 88 a9 01 00 00    	js     6580 <fwp_p_ad_push+0x1d0>
    63d7:	48 89 f8             	mov    %rdi,%rax
    63da:	48 89 0c 24          	mov    %rcx,(%rsp)
    63de:	48 09 d0             	or     %rdx,%rax
    63e1:	0f 89 71 01 00 00    	jns    6558 <fwp_p_ad_push+0x1a8>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 f8 20          	sar    $0x20,%rax
    63ee:	48 85 ff             	test   %rdi,%rdi
    63f1:	79 24                	jns    6417 <fwp_p_ad_push+0x67>
    63f3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    63f8:	48 89 d0             	mov    %rdx,%rax
    63fb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6402:	00 
    6403:	49 89 d4             	mov    %rdx,%r12
    6406:	48 c1 f8 20          	sar    $0x20,%rax
    640a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6411:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6417:	48 89 c7             	mov    %rax,%rdi
    641a:	e8 11 e3 ff ff       	call   4730 <fwp_tape_of>
    641f:	48 89 c3             	mov    %rax,%rbx
    6422:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6427:	0f 85 6e 02 00 00    	jne    669b <fwp_p_ad_push+0x2eb>
    642d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6431:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6438:	0f 8f 51 02 00 00    	jg     668f <fwp_p_ad_push+0x2df>
    643e:	44 89 e0             	mov    %r12d,%eax
    6441:	4c 39 f8             	cmp    %r15,%rax
    6444:	0f 8d 39 02 00 00    	jge    6683 <fwp_p_ad_push+0x2d3>
    644a:	4d 85 ed             	test   %r13,%r13
    644d:	78 0c                	js     645b <fwp_p_ad_push+0xab>
    644f:	44 89 e8             	mov    %r13d,%eax
    6452:	4c 39 f8             	cmp    %r15,%rax
    6455:	0f 8d 28 02 00 00    	jge    6683 <fwp_p_ad_push+0x2d3>
    645b:	4d 89 fe             	mov    %r15,%r14
    645e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6462:	49 8d 46 01          	lea    0x1(%r14),%rax
    6466:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    646c:	0f 87 1d 02 00 00    	ja     668f <fwp_p_ad_push+0x2df>
    6472:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6476:	48 39 e8             	cmp    %rbp,%rax
    6479:	0f 8e 31 01 00 00    	jle    65b0 <fwp_p_ad_push+0x200>
    647f:	48 85 ed             	test   %rbp,%rbp
    6482:	ba 40 00 00 00       	mov    $0x40,%edx
    6487:	48 0f 44 ea          	cmove  %rdx,%rbp
    648b:	48 39 e8             	cmp    %rbp,%rax
    648e:	7e 20                	jle    64b0 <fwp_p_ad_push+0x100>
    6490:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6497:	0f 8f 03 01 00 00    	jg     65a0 <fwp_p_ad_push+0x1f0>
    649d:	48 01 ed             	add    %rbp,%rbp
    64a0:	48 39 e8             	cmp    %rbp,%rax
    64a3:	7f eb                	jg     6490 <fwp_p_ad_push+0xe0>
    64a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64ac:	00 00 00 00 
    64b0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    64b7:	00 
    64b8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    64bc:	ba 01 00 00 00       	mov    $0x1,%edx
    64c1:	48 89 c6             	mov    %rax,%rsi
    64c4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    64c9:	e8 22 ed ff ff       	call   51f0 <ad_raw_realloc>
    64ce:	48 85 c0             	test   %rax,%rax
    64d1:	0f 84 d0 01 00 00    	je     66a7 <fwp_p_ad_push+0x2f7>
    64d7:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64db:	48 89 ee             	mov    %rbp,%rsi
    64de:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    64e2:	48 89 43 20          	mov    %rax,0x20(%rbx)
    64e6:	48 c1 e6 04          	shl    $0x4,%rsi
    64ea:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    64ee:	ba 02 00 00 00       	mov    $0x2,%edx
    64f3:	48 89 43 28          	mov    %rax,0x28(%rbx)
    64f7:	e8 f4 ec ff ff       	call   51f0 <ad_raw_realloc>
    64fc:	48 85 c0             	test   %rax,%rax
    64ff:	0f 84 a2 01 00 00    	je     66a7 <fwp_p_ad_push+0x2f7>
    6505:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6509:	48 89 43 30          	mov    %rax,0x30(%rbx)
    650d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6514:	00 
    6515:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    651c:	00 
    651d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6524:	00 
    6525:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    6529:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    652e:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6532:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6536:	4d 85 f6             	test   %r14,%r14
    6539:	0f 85 e5 00 00 00    	jne    6624 <fwp_p_ad_push+0x274>
    653f:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6543:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6547:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    654b:	48 01 d1             	add    %rdx,%rcx
    654e:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6552:	eb 7c                	jmp    65d0 <fwp_p_ad_push+0x220>
    6554:	0f 1f 40 00          	nopl   0x0(%rax)
    6558:	48 89 d0             	mov    %rdx,%rax
    655b:	48 c1 ff 20          	sar    $0x20,%rdi
    655f:	48 c1 f8 20          	sar    $0x20,%rax
    6563:	48 39 c7             	cmp    %rax,%rdi
    6566:	0f 84 ab fe ff ff    	je     6417 <fwp_p_ad_push+0x67>
    656c:	48 8d 3d 95 64 00 00 	lea    0x6495(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    6573:	e8 d8 de ff ff       	call   4450 <fwp_trap>
    6578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    657f:	00 
    6580:	48 83 c4 38          	add    $0x38,%rsp
    6584:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658b:	5b                   	pop    %rbx
    658c:	5d                   	pop    %rbp
    658d:	41 5c                	pop    %r12
    658f:	41 5d                	pop    %r13
    6591:	41 5e                	pop    %r14
    6593:	41 5f                	pop    %r15
    6595:	c3                   	ret
    6596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    659d:	00 00 00 
    65a0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    65a5:	e9 06 ff ff ff       	jmp    64b0 <fwp_p_ad_push+0x100>
    65aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65b0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    65b4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65b8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    65bf:	00 
    65c0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    65c7:	00 
    65c8:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    65cc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65d0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65d6:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    65da:	4d 85 ed             	test   %r13,%r13
    65dd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    65e2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    65e8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65ef:	4c 0f 48 e8          	cmovs  %rax,%r13
    65f3:	49 8d 47 01          	lea    0x1(%r15),%rax
    65f7:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    65fb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6601:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6605:	48 83 c4 38          	add    $0x38,%rsp
    6609:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6610:	ff ff ff 
    6613:	4c 21 e0             	and    %r12,%rax
    6616:	5b                   	pop    %rbx
    6617:	5d                   	pop    %rbp
    6618:	4c 09 f8             	or     %r15,%rax
    661b:	41 5c                	pop    %r12
    661d:	41 5d                	pop    %r13
    661f:	41 5e                	pop    %r14
    6621:	41 5f                	pop    %r15
    6623:	c3                   	ret
    6624:	4c 89 ca             	mov    %r9,%rdx
    6627:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    662c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6631:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6636:	e8 b5 cf ff ff       	call   35f0 <memmove@plt>
    663b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6640:	4c 03 73 30          	add    0x30(%rbx),%r14
    6644:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6649:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    664d:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6651:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    6656:	48 03 7b 20          	add    0x20(%rbx),%rdi
    665a:	4c 89 d2             	mov    %r10,%rdx
    665d:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6662:	e8 89 cf ff ff       	call   35f0 <memmove@plt>
    6667:	48 8b 43 30          	mov    0x30(%rbx),%rax
    666b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    666f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6674:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6679:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    667e:	e9 c0 fe ff ff       	jmp    6543 <fwp_p_ad_push+0x193>
    6683:	48 8d 3d 38 5b 00 00 	lea    0x5b38(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    668a:	e8 c1 dd ff ff       	call   4450 <fwp_trap>
    668f:	48 8d 3d 11 5b 00 00 	lea    0x5b11(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    6696:	e8 b5 dd ff ff       	call   4450 <fwp_trap>
    669b:	48 8d 3d ae 63 00 00 	lea    0x63ae(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    66a2:	e8 a9 dd ff ff       	call   4450 <fwp_trap>
    66a7:	48 89 df             	mov    %rbx,%rdi
    66aa:	e8 e1 d5 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    66af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    66b3:	48 85 ff             	test   %rdi,%rdi
    66b6:	74 05                	je     66bd <fwp_p_ad_push+0x30d>
    66b8:	e8 73 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66bd:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    66c1:	48 85 ff             	test   %rdi,%rdi
    66c4:	74 05                	je     66cb <fwp_p_ad_push+0x31b>
    66c6:	e8 65 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66cb:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    66cf:	48 85 ff             	test   %rdi,%rdi
    66d2:	74 05                	je     66d9 <fwp_p_ad_push+0x329>
    66d4:	e8 57 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66d9:	31 c9                	xor    %ecx,%ecx
    66db:	31 c0                	xor    %eax,%eax
    66dd:	31 d2                	xor    %edx,%edx
    66df:	be 01 00 00 00       	mov    $0x1,%esi
    66e4:	89 53 04             	mov    %edx,0x4(%rbx)
    66e7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    66eb:	ba 13 00 00 00       	mov    $0x13,%edx
    66f0:	48 8d 3d 11 59 00 00 	lea    0x5911(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    66f7:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    66fb:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    66ff:	48 8b 0d 3a 99 00 00 	mov    0x993a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6706:	48 89 43 40          	mov    %rax,0x40(%rbx)
    670a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    670e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6712:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6716:	e8 45 cf ff ff       	call   3660 <fwrite@plt>
    671b:	31 ff                	xor    %edi,%edi
    671d:	e8 7e ce ff ff       	call   35a0 <fflush@plt>
    6722:	bf 66 00 00 00       	mov    $0x66,%edi
    6727:	e8 54 cf ff ff       	call   3680 <_Exit@plt>
    672c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006730 <w107>:
    6730:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6734:	41 55                	push   %r13
    6736:	48 89 fa             	mov    %rdi,%rdx
    6739:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    673d:	41 54                	push   %r12
    673f:	49 89 fc             	mov    %rdi,%r12
    6742:	55                   	push   %rbp
    6743:	53                   	push   %rbx
    6744:	48 89 f3             	mov    %rsi,%rbx
    6747:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    674c:	48 89 f1             	mov    %rsi,%rcx
    674f:	48 83 ec 28          	sub    $0x28,%rsp
    6753:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6759:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    675f:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6765:	e8 46 fc ff ff       	call   63b0 <fwp_p_ad_push>
    676a:	48 89 c7             	mov    %rax,%rdi
    676d:	e8 4e e8 ff ff       	call   4fc0 <caf61>
    6772:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6777:	e8 44 e8 ff ff       	call   4fc0 <caf61>
    677c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6782:	66 0f 57 05 26 66 00 	xorpd  0x6626(%rip),%xmm0        # cdb0 <msg.8+0x80>
    6789:	00 
    678a:	48 89 da             	mov    %rbx,%rdx
    678d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6793:	48 89 c1             	mov    %rax,%rcx
    6796:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    679b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    67a0:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67a6:	e8 05 fc ff ff       	call   63b0 <fwp_p_ad_push>
    67ab:	4c 89 e7             	mov    %r12,%rdi
    67ae:	49 89 c5             	mov    %rax,%r13
    67b1:	e8 0a e8 ff ff       	call   4fc0 <caf61>
    67b6:	48 89 c6             	mov    %rax,%rsi
    67b9:	e8 02 e8 ff ff       	call   4fc0 <caf61>
    67be:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    67c3:	f2 0f 10 05 25 66 00 	movsd  0x6625(%rip),%xmm0        # cdf0 <msg.8+0xc0>
    67ca:	00 
    67cb:	66 0f 57 15 dd 65 00 	xorpd  0x65dd(%rip),%xmm2        # cdb0 <msg.8+0x80>
    67d2:	00 
    67d3:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    67d9:	48 89 c1             	mov    %rax,%rcx
    67dc:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    67e3:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    67e8:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    67ed:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f3:	e8 b8 fb ff ff       	call   63b0 <fwp_p_ad_push>
    67f8:	48 89 e9             	mov    %rbp,%rcx
    67fb:	4c 89 ea             	mov    %r13,%rdx
    67fe:	48 89 ee             	mov    %rbp,%rsi
    6801:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6807:	4c 89 ef             	mov    %r13,%rdi
    680a:	49 89 c4             	mov    %rax,%r12
    680d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6811:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6817:	e8 94 fb ff ff       	call   63b0 <fwp_p_ad_push>
    681c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6822:	f2 0f 59 1d ce 65 00 	mulsd  0x65ce(%rip),%xmm3        # cdf8 <msg.8+0xc8>
    6829:	00 
    682a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6831:	00 59 40 
    6834:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6839:	48 89 c2             	mov    %rax,%rdx
    683c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6843:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6849:	e8 62 fb ff ff       	call   63b0 <fwp_p_ad_push>
    684e:	4c 89 e2             	mov    %r12,%rdx
    6851:	48 89 d9             	mov    %rbx,%rcx
    6854:	48 89 de             	mov    %rbx,%rsi
    6857:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    685d:	4c 89 e7             	mov    %r12,%rdi
    6860:	48 89 c5             	mov    %rax,%rbp
    6863:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6867:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    686d:	e8 3e fb ff ff       	call   63b0 <fwp_p_ad_push>
    6872:	48 89 c7             	mov    %rax,%rdi
    6875:	e8 46 e7 ff ff       	call   4fc0 <caf61>
    687a:	48 89 c6             	mov    %rax,%rsi
    687d:	e8 3e e7 ff ff       	call   4fc0 <caf61>
    6882:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6888:	48 89 ea             	mov    %rbp,%rdx
    688b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6891:	48 89 c1             	mov    %rax,%rcx
    6894:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6899:	e8 12 fb ff ff       	call   63b0 <fwp_p_ad_push>
    689e:	48 83 c4 28          	add    $0x28,%rsp
    68a2:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    68a7:	5b                   	pop    %rbx
    68a8:	5d                   	pop    %rbp
    68a9:	41 5c                	pop    %r12
    68ab:	41 5d                	pop    %r13
    68ad:	c3                   	ret
    68ae:	66 90                	xchg   %ax,%ax

00000000000068b0 <w164.constprop.0>:
    68b0:	41 54                	push   %r12
    68b2:	55                   	push   %rbp
    68b3:	53                   	push   %rbx
    68b4:	48 83 ec 10          	sub    $0x10,%rsp
    68b8:	4c 8b 27             	mov    (%rdi),%r12
    68bb:	4d 85 e4             	test   %r12,%r12
    68be:	74 78                	je     6938 <w164.constprop.0+0x88>
    68c0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    68c7:	00 00 
    68c9:	48 89 fd             	mov    %rdi,%rbp
    68cc:	31 db                	xor    %ebx,%ebx
    68ce:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68dc:	00 00 00 00 
    68e0:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    68e5:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    68eb:	48 83 c3 02          	add    $0x2,%rbx
    68ef:	e8 cc e6 ff ff       	call   4fc0 <caf61>
    68f4:	48 89 c6             	mov    %rax,%rsi
    68f7:	e8 c4 e6 ff ff       	call   4fc0 <caf61>
    68fc:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6902:	4c 89 c2             	mov    %r8,%rdx
    6905:	48 89 c1             	mov    %rax,%rcx
    6908:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    690e:	e8 9d fa ff ff       	call   63b0 <fwp_p_ad_push>
    6913:	48 89 c7             	mov    %rax,%rdi
    6916:	4c 39 e3             	cmp    %r12,%rbx
    6919:	72 c5                	jb     68e0 <w164.constprop.0+0x30>
    691b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6920:	48 83 c4 10          	add    $0x10,%rsp
    6924:	5b                   	pop    %rbx
    6925:	5d                   	pop    %rbp
    6926:	66 48 0f 6e c0       	movq   %rax,%xmm0
    692b:	41 5c                	pop    %r12
    692d:	48 89 f8             	mov    %rdi,%rax
    6930:	c3                   	ret
    6931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6938:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    693f:	00 00 
    6941:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6948:	eb d1                	jmp    691b <w164.constprop.0+0x6b>
    694a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000006950 <fwp_data.part.0.constprop.0>:
    6950:	41 56                	push   %r14
    6952:	8b 05 8c 32 06 00    	mov    0x6328c(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    6958:	41 89 fe             	mov    %edi,%r14d
    695b:	41 55                	push   %r13
    695d:	44 8b 2d a4 3b 06 00 	mov    0x63ba4(%rip),%r13d        # 6a508 <iteration_active>
    6964:	41 54                	push   %r12
    6966:	49 89 f4             	mov    %rsi,%r12
    6969:	55                   	push   %rbp
    696a:	53                   	push   %rbx
    696b:	45 85 ed             	test   %r13d,%r13d
    696e:	0f 84 1c 01 00 00    	je     6a90 <fwp_data.part.0.constprop.0+0x140>
    6974:	48 83 05 84 3b 06 00 	addq   $0x1,0x63b84(%rip)        # 6a500 <iteration_requests>
    697b:	01 
    697c:	48 83 05 74 3b 06 00 	addq   $0x18,0x63b74(%rip)        # 6a4f8 <iteration_bytes>
    6983:	18 
    6984:	85 c0                	test   %eax,%eax
    6986:	0f 84 8c 01 00 00    	je     6b18 <fwp_data.part.0.constprop.0+0x1c8>
    698c:	0f b6 05 4f 2e 06 00 	movzbl 0x62e4f(%rip),%eax        # 697e2 <fwp_heap+0xfa2>
    6993:	48 8d 15 a6 1e 06 00 	lea    0x61ea6(%rip),%rdx        # 68840 <fwp_heap>
    699a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    69a1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    69a5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    69a9:	48 8b 18             	mov    (%rax),%rbx
    69ac:	48 85 db             	test   %rbx,%rbx
    69af:	0f 84 fb 00 00 00    	je     6ab0 <fwp_data.part.0.constprop.0+0x160>
    69b5:	48 8b 13             	mov    (%rbx),%rdx
    69b8:	48 f7 d2             	not    %rdx
    69bb:	48 89 10             	mov    %rdx,(%rax)
    69be:	48 83 fd 18          	cmp    $0x18,%rbp
    69c2:	76 1b                	jbe    69df <fwp_data.part.0.constprop.0+0x8f>
    69c4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    69c8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    69cc:	31 f6                	xor    %esi,%esi
    69ce:	48 c1 e8 03          	shr    $0x3,%rax
    69d2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    69d9:	00 
    69da:	e8 d1 ca ff ff       	call   34b0 <memset@plt>
    69df:	48 89 e8             	mov    %rbp,%rax
    69e2:	48 03 05 77 32 06 00 	add    0x63277(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    69e9:	0f 82 3d 01 00 00    	jb     6b2c <fwp_data.part.0.constprop.0+0x1dc>
    69ef:	48 39 05 72 32 06 00 	cmp    %rax,0x63272(%rip)        # 69c68 <fwp_heap+0x1428>
    69f6:	48 89 05 63 32 06 00 	mov    %rax,0x63263(%rip)        # 69c60 <fwp_heap+0x1420>
    69fd:	73 07                	jae    6a06 <fwp_data.part.0.constprop.0+0xb6>
    69ff:	48 89 05 62 32 06 00 	mov    %rax,0x63262(%rip)        # 69c68 <fwp_heap+0x1428>
    6a06:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a0a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6a0f:	f2 0f 58 05 61 32 06 	addsd  0x63261(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    6a16:	00 
    6a17:	f2 0f 11 05 59 32 06 	movsd  %xmm0,0x63259(%rip)        # 69c78 <fwp_heap+0x1438>
    6a1e:	00 
    6a1f:	45 85 ed             	test   %r13d,%r13d
    6a22:	74 33                	je     6a57 <fwp_data.part.0.constprop.0+0x107>
    6a24:	48 8b 05 35 32 06 00 	mov    0x63235(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    6a2b:	48 85 c0             	test   %rax,%rax
    6a2e:	0f 88 a4 00 00 00    	js     6ad8 <fwp_data.part.0.constprop.0+0x188>
    6a34:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a38:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6a3d:	f2 0f 5c 05 a3 3a 06 	subsd  0x63aa3(%rip),%xmm0        # 6a4e8 <iteration_start_charge>
    6a44:	00 
    6a45:	66 0f 2f 05 93 3a 06 	comisd 0x63a93(%rip),%xmm0        # 6a4e0 <iteration_peak>
    6a4c:	00 
    6a4d:	76 08                	jbe    6a57 <fwp_data.part.0.constprop.0+0x107>
    6a4f:	f2 0f 11 05 89 3a 06 	movsd  %xmm0,0x63a89(%rip)        # 6a4e0 <iteration_peak>
    6a56:	00 
    6a57:	b8 02 00 00 00       	mov    $0x2,%eax
    6a5c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6a61:	66 0f 6e c8          	movd   %eax,%xmm1
    6a65:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6a69:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6a6d:	49 8b 04 24          	mov    (%r12),%rax
    6a71:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6a75:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6a7a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6a7e:	48 89 d8             	mov    %rbx,%rax
    6a81:	5b                   	pop    %rbx
    6a82:	5d                   	pop    %rbp
    6a83:	41 5c                	pop    %r12
    6a85:	41 5d                	pop    %r13
    6a87:	41 5e                	pop    %r14
    6a89:	c3                   	ret
    6a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a90:	85 c0                	test   %eax,%eax
    6a92:	0f 85 f4 fe ff ff    	jne    698c <fwp_data.part.0.constprop.0+0x3c>
    6a98:	31 f6                	xor    %esi,%esi
    6a9a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a9f:	e8 cc f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6aa4:	48 89 c3             	mov    %rax,%rbx
    6aa7:	eb ae                	jmp    6a57 <fwp_data.part.0.constprop.0+0x107>
    6aa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ab0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6ab4:	48 85 db             	test   %rbx,%rbx
    6ab7:	74 47                	je     6b00 <fwp_data.part.0.constprop.0+0x1b0>
    6ab9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6abd:	48 29 da             	sub    %rbx,%rdx
    6ac0:	48 39 ea             	cmp    %rbp,%rdx
    6ac3:	72 3b                	jb     6b00 <fwp_data.part.0.constprop.0+0x1b0>
    6ac5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ac9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6acd:	e9 ec fe ff ff       	jmp    69be <fwp_data.part.0.constprop.0+0x6e>
    6ad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad8:	48 89 c2             	mov    %rax,%rdx
    6adb:	83 e0 01             	and    $0x1,%eax
    6ade:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ae2:	48 d1 ea             	shr    $1,%rdx
    6ae5:	48 09 c2             	or     %rax,%rdx
    6ae8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6aed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6af1:	e9 47 ff ff ff       	jmp    6a3d <fwp_data.part.0.constprop.0+0xed>
    6af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6afd:	00 00 00 
    6b00:	31 f6                	xor    %esi,%esi
    6b02:	bf 18 00 00 00       	mov    $0x18,%edi
    6b07:	e8 64 f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6b0c:	48 89 c3             	mov    %rax,%rbx
    6b0f:	e9 0b ff ff ff       	jmp    6a1f <fwp_data.part.0.constprop.0+0xcf>
    6b14:	0f 1f 40 00          	nopl   0x0(%rax)
    6b18:	31 f6                	xor    %esi,%esi
    6b1a:	bf 18 00 00 00       	mov    $0x18,%edi
    6b1f:	e8 4c f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6b24:	48 89 c3             	mov    %rax,%rbx
    6b27:	e9 f8 fe ff ff       	jmp    6a24 <fwp_data.part.0.constprop.0+0xd4>
    6b2c:	e8 ff d2 ff ff       	call   3e30 <fwp_heap_oom>
    6b31:	0f 1f 40 00          	nopl   0x0(%rax)
    6b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b3c:	00 00 00 00 

0000000000006b40 <fwp_rc_share>:
    6b40:	48 8b 05 d1 30 06 00 	mov    0x630d1(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    6b47:	48 2b 3d a2 30 06 00 	sub    0x630a2(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    6b4e:	48 c1 e0 10          	shl    $0x10,%rax
    6b52:	48 39 c7             	cmp    %rax,%rdi
    6b55:	73 4a                	jae    6ba1 <fwp_rc_share+0x61>
    6b57:	48 89 f8             	mov    %rdi,%rax
    6b5a:	48 c1 e8 10          	shr    $0x10,%rax
    6b5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b62:	48 8b 05 cf 30 06 00 	mov    0x630cf(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    6b69:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6b6d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6b71:	48 85 d2             	test   %rdx,%rdx
    6b74:	74 2b                	je     6ba1 <fwp_rc_share+0x61>
    6b76:	0f b6 08             	movzbl (%rax),%ecx
    6b79:	80 f9 02             	cmp    $0x2,%cl
    6b7c:	74 2a                	je     6ba8 <fwp_rc_share+0x68>
    6b7e:	80 f9 01             	cmp    $0x1,%cl
    6b81:	75 1e                	jne    6ba1 <fwp_rc_share+0x61>
    6b83:	8b 48 18             	mov    0x18(%rax),%ecx
    6b86:	0f b7 ff             	movzwl %di,%edi
    6b89:	8b 40 1c             	mov    0x1c(%rax),%eax
    6b8c:	48 0f af f9          	imul   %rcx,%rdi
    6b90:	48 c1 ef 20          	shr    $0x20,%rdi
    6b94:	48 39 c7             	cmp    %rax,%rdi
    6b97:	73 08                	jae    6ba1 <fwp_rc_share+0x61>
    6b99:	48 01 fa             	add    %rdi,%rdx
    6b9c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b9f:	75 0d                	jne    6bae <fwp_rc_share+0x6e>
    6ba1:	c3                   	ret
    6ba2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ba8:	66 85 ff             	test   %di,%di
    6bab:	74 ef                	je     6b9c <fwp_rc_share+0x5c>
    6bad:	c3                   	ret
    6bae:	50                   	push   %rax
    6baf:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # ca80 <_IO_stdin_used+0xa80>
    6bb6:	e8 95 d8 ff ff       	call   4450 <fwp_trap>
    6bbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006bc0 <fwp_rc_free_arr>:
    6bc0:	48 8b 15 51 30 06 00 	mov    0x63051(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6bc7:	48 89 f8             	mov    %rdi,%rax
    6bca:	48 2b 05 1f 30 06 00 	sub    0x6301f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6bd1:	48 c1 e2 10          	shl    $0x10,%rdx
    6bd5:	48 39 d0             	cmp    %rdx,%rax
    6bd8:	73 5b                	jae    6c35 <fwp_rc_free_arr+0x75>
    6bda:	48 89 c2             	mov    %rax,%rdx
    6bdd:	48 c1 ea 10          	shr    $0x10,%rdx
    6be1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6be5:	48 8b 15 4c 30 06 00 	mov    0x6304c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6bec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6bf0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6bf4:	48 85 c9             	test   %rcx,%rcx
    6bf7:	74 3c                	je     6c35 <fwp_rc_free_arr+0x75>
    6bf9:	0f b6 32             	movzbl (%rdx),%esi
    6bfc:	40 80 fe 02          	cmp    $0x2,%sil
    6c00:	74 2e                	je     6c30 <fwp_rc_free_arr+0x70>
    6c02:	40 80 fe 01          	cmp    $0x1,%sil
    6c06:	75 2d                	jne    6c35 <fwp_rc_free_arr+0x75>
    6c08:	8b 72 18             	mov    0x18(%rdx),%esi
    6c0b:	0f b7 c0             	movzwl %ax,%eax
    6c0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c11:	48 0f af c6          	imul   %rsi,%rax
    6c15:	48 c1 e8 20          	shr    $0x20,%rax
    6c19:	48 39 d0             	cmp    %rdx,%rax
    6c1c:	73 17                	jae    6c35 <fwp_rc_free_arr+0x75>
    6c1e:	48 01 c1             	add    %rax,%rcx
    6c21:	80 39 01             	cmpb   $0x1,(%rcx)
    6c24:	75 0f                	jne    6c35 <fwp_rc_free_arr+0x75>
    6c26:	e9 45 ee ff ff       	jmp    5a70 <fwp_mem_free>
    6c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c30:	66 85 c0             	test   %ax,%ax
    6c33:	74 ec                	je     6c21 <fwp_rc_free_arr+0x61>
    6c35:	c3                   	ret
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 

0000000000006c40 <fwp_rc_dup>:
    6c40:	f3 0f 1e fa          	endbr64
    6c44:	48 8b 05 cd 2f 06 00 	mov    0x62fcd(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    6c4b:	48 2b 3d 9e 2f 06 00 	sub    0x62f9e(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    6c52:	48 c1 e0 10          	shl    $0x10,%rax
    6c56:	48 39 c7             	cmp    %rax,%rdi
    6c59:	73 60                	jae    6cbb <fwp_rc_dup+0x7b>
    6c5b:	48 89 f8             	mov    %rdi,%rax
    6c5e:	48 c1 e8 10          	shr    $0x10,%rax
    6c62:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c66:	48 8b 05 cb 2f 06 00 	mov    0x62fcb(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    6c6d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c71:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c75:	48 85 c0             	test   %rax,%rax
    6c78:	74 41                	je     6cbb <fwp_rc_dup+0x7b>
    6c7a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c7d:	80 f9 02             	cmp    $0x2,%cl
    6c80:	74 3e                	je     6cc0 <fwp_rc_dup+0x80>
    6c82:	80 f9 01             	cmp    $0x1,%cl
    6c85:	75 34                	jne    6cbb <fwp_rc_dup+0x7b>
    6c87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c8a:	0f b7 ff             	movzwl %di,%edi
    6c8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c90:	48 0f af f9          	imul   %rcx,%rdi
    6c94:	48 c1 ef 20          	shr    $0x20,%rdi
    6c98:	48 39 d7             	cmp    %rdx,%rdi
    6c9b:	73 1e                	jae    6cbb <fwp_rc_dup+0x7b>
    6c9d:	48 01 f8             	add    %rdi,%rax
    6ca0:	0f b6 10             	movzbl (%rax),%edx
    6ca3:	84 d2                	test   %dl,%dl
    6ca5:	74 14                	je     6cbb <fwp_rc_dup+0x7b>
    6ca7:	8b 0d 5b 38 06 00    	mov    0x6385b(%rip),%ecx        # 6a508 <iteration_active>
    6cad:	85 c9                	test   %ecx,%ecx
    6caf:	75 1f                	jne    6cd0 <fwp_rc_dup+0x90>
    6cb1:	80 fa fd             	cmp    $0xfd,%dl
    6cb4:	77 2a                	ja     6ce0 <fwp_rc_dup+0xa0>
    6cb6:	83 c2 01             	add    $0x1,%edx
    6cb9:	88 10                	mov    %dl,(%rax)
    6cbb:	c3                   	ret
    6cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    6cc0:	66 85 ff             	test   %di,%di
    6cc3:	74 db                	je     6ca0 <fwp_rc_dup+0x60>
    6cc5:	c3                   	ret
    6cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ccd:	00 00 00 
    6cd0:	48 83 05 18 38 06 00 	addq   $0x1,0x63818(%rip)        # 6a4f0 <iteration_retains>
    6cd7:	01 
    6cd8:	eb d7                	jmp    6cb1 <fwp_rc_dup+0x71>
    6cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce0:	48 89 c7             	mov    %rax,%rdi
    6ce3:	e9 28 ea ff ff       	jmp    5710 <fwp_rc_wide_dup>
    6ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cef:	00 

0000000000006cf0 <fwp_owned_entry161>:
    6cf0:	f3 0f 1e fa          	endbr64
    6cf4:	48 83 ec 38          	sub    $0x38,%rsp
    6cf8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cfd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d04:	00 00 
    6d06:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6d0b:	31 c0                	xor    %eax,%eax
    6d0d:	48 8b 07             	mov    (%rdi),%rax
    6d10:	48 03 47 10          	add    0x10(%rdi),%rax
    6d14:	0f 80 c2 00 00 00    	jo     6ddc <fwp_owned_entry161+0xec>
    6d1a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d1f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d24:	31 ff                	xor    %edi,%edi
    6d26:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d2a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d2f:	e8 1c fc ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    6d34:	48 8b 15 dd 2e 06 00 	mov    0x62edd(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6d3b:	48 89 c6             	mov    %rax,%rsi
    6d3e:	48 2b 05 ab 2e 06 00 	sub    0x62eab(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6d45:	48 c1 e2 10          	shl    $0x10,%rdx
    6d49:	48 39 d0             	cmp    %rdx,%rax
    6d4c:	73 4f                	jae    6d9d <fwp_owned_entry161+0xad>
    6d4e:	48 89 c2             	mov    %rax,%rdx
    6d51:	48 c1 ea 10          	shr    $0x10,%rdx
    6d55:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d59:	48 8b 15 d8 2e 06 00 	mov    0x62ed8(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6d60:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d64:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d68:	48 85 d2             	test   %rdx,%rdx
    6d6b:	74 30                	je     6d9d <fwp_owned_entry161+0xad>
    6d6d:	0f b6 39             	movzbl (%rcx),%edi
    6d70:	40 80 ff 02          	cmp    $0x2,%dil
    6d74:	74 42                	je     6db8 <fwp_owned_entry161+0xc8>
    6d76:	40 80 ff 01          	cmp    $0x1,%dil
    6d7a:	75 21                	jne    6d9d <fwp_owned_entry161+0xad>
    6d7c:	8b 79 18             	mov    0x18(%rcx),%edi
    6d7f:	0f b7 c0             	movzwl %ax,%eax
    6d82:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d85:	48 0f af c7          	imul   %rdi,%rax
    6d89:	48 c1 e8 20          	shr    $0x20,%rax
    6d8d:	48 39 c8             	cmp    %rcx,%rax
    6d90:	73 0b                	jae    6d9d <fwp_owned_entry161+0xad>
    6d92:	48 01 c2             	add    %rax,%rdx
    6d95:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d98:	74 26                	je     6dc0 <fwp_owned_entry161+0xd0>
    6d9a:	c6 02 01             	movb   $0x1,(%rdx)
    6d9d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6da2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6da9:	00 00 
    6dab:	75 34                	jne    6de1 <fwp_owned_entry161+0xf1>
    6dad:	48 89 f0             	mov    %rsi,%rax
    6db0:	48 83 c4 38          	add    $0x38,%rsp
    6db4:	c3                   	ret
    6db5:	0f 1f 00             	nopl   (%rax)
    6db8:	66 85 c0             	test   %ax,%ax
    6dbb:	75 e0                	jne    6d9d <fwp_owned_entry161+0xad>
    6dbd:	eb d6                	jmp    6d95 <fwp_owned_entry161+0xa5>
    6dbf:	90                   	nop
    6dc0:	48 89 d7             	mov    %rdx,%rdi
    6dc3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6dc8:	48 89 14 24          	mov    %rdx,(%rsp)
    6dcc:	e8 5f ea ff ff       	call   5830 <fwp_rc_forget_slot>
    6dd1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6dd6:	48 8b 14 24          	mov    (%rsp),%rdx
    6dda:	eb be                	jmp    6d9a <fwp_owned_entry161+0xaa>
    6ddc:	e8 1f c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6de1:	e8 6a c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ded:	00 00 00 

0000000000006df0 <e161>:
    6df0:	f3 0f 1e fa          	endbr64
    6df4:	53                   	push   %rbx
    6df5:	48 83 ec 30          	sub    $0x30,%rsp
    6df9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6dfe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e05:	00 00 
    6e07:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6e0c:	31 c0                	xor    %eax,%eax
    6e0e:	48 8b 07             	mov    (%rdi),%rax
    6e11:	48 03 47 10          	add    0x10(%rdi),%rax
    6e15:	0f 80 c9 00 00 00    	jo     6ee4 <e161+0xf4>
    6e1b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6e20:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6e25:	31 ff                	xor    %edi,%edi
    6e27:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6e2b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e30:	e8 1b fb ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    6e35:	48 8b 15 dc 2d 06 00 	mov    0x62ddc(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6e3c:	48 89 c3             	mov    %rax,%rbx
    6e3f:	48 2b 05 aa 2d 06 00 	sub    0x62daa(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6e46:	48 c1 e2 10          	shl    $0x10,%rdx
    6e4a:	48 39 d0             	cmp    %rdx,%rax
    6e4d:	73 4f                	jae    6e9e <e161+0xae>
    6e4f:	48 89 c2             	mov    %rax,%rdx
    6e52:	48 c1 ea 10          	shr    $0x10,%rdx
    6e56:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e5a:	48 8b 15 d7 2d 06 00 	mov    0x62dd7(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6e61:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e65:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e69:	48 85 d2             	test   %rdx,%rdx
    6e6c:	74 30                	je     6e9e <e161+0xae>
    6e6e:	0f b6 31             	movzbl (%rcx),%esi
    6e71:	40 80 fe 02          	cmp    $0x2,%sil
    6e75:	74 49                	je     6ec0 <e161+0xd0>
    6e77:	40 80 fe 01          	cmp    $0x1,%sil
    6e7b:	75 21                	jne    6e9e <e161+0xae>
    6e7d:	8b 71 18             	mov    0x18(%rcx),%esi
    6e80:	0f b7 c0             	movzwl %ax,%eax
    6e83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e86:	48 0f af c6          	imul   %rsi,%rax
    6e8a:	48 c1 e8 20          	shr    $0x20,%rax
    6e8e:	48 39 c8             	cmp    %rcx,%rax
    6e91:	73 0b                	jae    6e9e <e161+0xae>
    6e93:	48 01 c2             	add    %rax,%rdx
    6e96:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e99:	74 35                	je     6ed0 <e161+0xe0>
    6e9b:	c6 02 01             	movb   $0x1,(%rdx)
    6e9e:	48 89 df             	mov    %rbx,%rdi
    6ea1:	e8 9a fc ff ff       	call   6b40 <fwp_rc_share>
    6ea6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6eab:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6eb2:	00 00 
    6eb4:	75 33                	jne    6ee9 <e161+0xf9>
    6eb6:	48 83 c4 30          	add    $0x30,%rsp
    6eba:	48 89 d8             	mov    %rbx,%rax
    6ebd:	5b                   	pop    %rbx
    6ebe:	c3                   	ret
    6ebf:	90                   	nop
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	75 d9                	jne    6e9e <e161+0xae>
    6ec5:	eb cf                	jmp    6e96 <e161+0xa6>
    6ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6ece:	00 00 
    6ed0:	48 89 d7             	mov    %rdx,%rdi
    6ed3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ed8:	e8 53 e9 ff ff       	call   5830 <fwp_rc_forget_slot>
    6edd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ee2:	eb b7                	jmp    6e9b <e161+0xab>
    6ee4:	e8 17 c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6ee9:	e8 62 c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6eee:	66 90                	xchg   %ax,%ax

0000000000006ef0 <fwp_drop0>:
    6ef0:	f3 0f 1e fa          	endbr64
    6ef4:	48 8b 15 1d 2d 06 00 	mov    0x62d1d(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6efb:	48 89 f8             	mov    %rdi,%rax
    6efe:	48 2b 05 eb 2c 06 00 	sub    0x62ceb(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6f05:	48 c1 e2 10          	shl    $0x10,%rdx
    6f09:	48 39 d0             	cmp    %rdx,%rax
    6f0c:	0f 83 be 00 00 00    	jae    6fd0 <fwp_drop0+0xe0>
    6f12:	48 83 ec 18          	sub    $0x18,%rsp
    6f16:	4c 8d 05 23 19 06 00 	lea    0x61923(%rip),%r8        # 68840 <fwp_heap>
    6f1d:	48 89 c2             	mov    %rax,%rdx
    6f20:	48 c1 ea 10          	shr    $0x10,%rdx
    6f24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6f2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f37:	48 85 d2             	test   %rdx,%rdx
    6f3a:	74 3c                	je     6f78 <fwp_drop0+0x88>
    6f3c:	0f b6 31             	movzbl (%rcx),%esi
    6f3f:	40 80 fe 02          	cmp    $0x2,%sil
    6f43:	74 3b                	je     6f80 <fwp_drop0+0x90>
    6f45:	40 80 fe 01          	cmp    $0x1,%sil
    6f49:	75 2d                	jne    6f78 <fwp_drop0+0x88>
    6f4b:	8b 71 18             	mov    0x18(%rcx),%esi
    6f4e:	0f b7 c0             	movzwl %ax,%eax
    6f51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f54:	48 0f af c6          	imul   %rsi,%rax
    6f58:	48 c1 e8 20          	shr    $0x20,%rax
    6f5c:	48 39 c8             	cmp    %rcx,%rax
    6f5f:	73 17                	jae    6f78 <fwp_drop0+0x88>
    6f61:	48 01 c2             	add    %rax,%rdx
    6f64:	0f b6 02             	movzbl (%rdx),%eax
    6f67:	84 c0                	test   %al,%al
    6f69:	74 0d                	je     6f78 <fwp_drop0+0x88>
    6f6b:	3c 01                	cmp    $0x1,%al
    6f6d:	74 21                	je     6f90 <fwp_drop0+0xa0>
    6f6f:	3c ff                	cmp    $0xff,%al
    6f71:	74 65                	je     6fd8 <fwp_drop0+0xe8>
    6f73:	83 e8 01             	sub    $0x1,%eax
    6f76:	88 02                	mov    %al,(%rdx)
    6f78:	48 83 c4 18          	add    $0x18,%rsp
    6f7c:	c3                   	ret
    6f7d:	0f 1f 00             	nopl   (%rax)
    6f80:	66 85 c0             	test   %ax,%ax
    6f83:	74 df                	je     6f64 <fwp_drop0+0x74>
    6f85:	48 83 c4 18          	add    $0x18,%rsp
    6f89:	c3                   	ret
    6f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6f94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f99:	e8 22 fc ff ff       	call   6bc0 <fwp_rc_free_arr>
    6f9e:	4c 8d 05 9b 18 06 00 	lea    0x6189b(%rip),%r8        # 68840 <fwp_heap>
    6fa5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6faa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6fb1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6fb8:	48 c1 e2 10          	shl    $0x10,%rdx
    6fbc:	48 39 d0             	cmp    %rdx,%rax
    6fbf:	73 b7                	jae    6f78 <fwp_drop0+0x88>
    6fc1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6fc6:	e9 52 ff ff ff       	jmp    6f1d <fwp_drop0+0x2d>
    6fcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6fd0:	c3                   	ret
    6fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fd8:	48 89 d0             	mov    %rdx,%rax
    6fdb:	48 c1 e8 11          	shr    $0x11,%rax
    6fdf:	48 31 d0             	xor    %rdx,%rax
    6fe2:	48 89 c1             	mov    %rax,%rcx
    6fe5:	48 c1 e9 09          	shr    $0x9,%rcx
    6fe9:	48 31 c8             	xor    %rcx,%rax
    6fec:	0f b6 c8             	movzbl %al,%ecx
    6fef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6ff6:	00 
    6ff7:	48 85 c0             	test   %rax,%rax
    6ffa:	75 0d                	jne    7009 <fwp_drop0+0x119>
    6ffc:	eb 46                	jmp    7044 <fwp_drop0+0x154>
    6ffe:	66 90                	xchg   %ax,%ax
    7000:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7004:	48 85 c0             	test   %rax,%rax
    7007:	74 3b                	je     7044 <fwp_drop0+0x154>
    7009:	48 89 c1             	mov    %rax,%rcx
    700c:	48 39 10             	cmp    %rdx,(%rax)
    700f:	75 ef                	jne    7000 <fwp_drop0+0x110>
    7011:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7015:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7019:	48 89 48 08          	mov    %rcx,0x8(%rax)
    701d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7024:	0f 85 4e ff ff ff    	jne    6f78 <fwp_drop0+0x88>
    702a:	48 89 d7             	mov    %rdx,%rdi
    702d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7032:	e8 f9 e7 ff ff       	call   5830 <fwp_rc_forget_slot>
    7037:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    703c:	c6 02 fe             	movb   $0xfe,(%rdx)
    703f:	e9 34 ff ff ff       	jmp    6f78 <fwp_drop0+0x88>
    7044:	48 8d 3d 95 59 00 00 	lea    0x5995(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    704b:	e8 00 d4 ff ff       	call   4450 <fwp_trap>

0000000000007050 <fwp_arg_drop12>:
    7050:	f3 0f 1e fa          	endbr64
    7054:	85 f6                	test   %esi,%esi
    7056:	75 04                	jne    705c <fwp_arg_drop12+0xc>
    7058:	85 d2                	test   %edx,%edx
    705a:	75 04                	jne    7060 <fwp_arg_drop12+0x10>
    705c:	c3                   	ret
    705d:	0f 1f 00             	nopl   (%rax)
    7060:	48 8b 3f             	mov    (%rdi),%rdi
    7063:	e9 88 fe ff ff       	jmp    6ef0 <fwp_drop0>
    7068:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    706f:	00 

0000000000007070 <fwp_drop1>:
    7070:	f3 0f 1e fa          	endbr64
    7074:	48 8b 15 9d 2b 06 00 	mov    0x62b9d(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    707b:	48 89 f8             	mov    %rdi,%rax
    707e:	48 2b 05 6b 2b 06 00 	sub    0x62b6b(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7085:	48 c1 e2 10          	shl    $0x10,%rdx
    7089:	48 39 d0             	cmp    %rdx,%rax
    708c:	0f 83 be 00 00 00    	jae    7150 <fwp_drop1+0xe0>
    7092:	48 83 ec 18          	sub    $0x18,%rsp
    7096:	4c 8d 05 a3 17 06 00 	lea    0x617a3(%rip),%r8        # 68840 <fwp_heap>
    709d:	48 89 c2             	mov    %rax,%rdx
    70a0:	48 c1 ea 10          	shr    $0x10,%rdx
    70a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    70af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    70b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    70b7:	48 85 d2             	test   %rdx,%rdx
    70ba:	74 3c                	je     70f8 <fwp_drop1+0x88>
    70bc:	0f b6 31             	movzbl (%rcx),%esi
    70bf:	40 80 fe 02          	cmp    $0x2,%sil
    70c3:	74 3b                	je     7100 <fwp_drop1+0x90>
    70c5:	40 80 fe 01          	cmp    $0x1,%sil
    70c9:	75 2d                	jne    70f8 <fwp_drop1+0x88>
    70cb:	8b 71 18             	mov    0x18(%rcx),%esi
    70ce:	0f b7 c0             	movzwl %ax,%eax
    70d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70d4:	48 0f af c6          	imul   %rsi,%rax
    70d8:	48 c1 e8 20          	shr    $0x20,%rax
    70dc:	48 39 c8             	cmp    %rcx,%rax
    70df:	73 17                	jae    70f8 <fwp_drop1+0x88>
    70e1:	48 01 c2             	add    %rax,%rdx
    70e4:	0f b6 02             	movzbl (%rdx),%eax
    70e7:	84 c0                	test   %al,%al
    70e9:	74 0d                	je     70f8 <fwp_drop1+0x88>
    70eb:	3c 01                	cmp    $0x1,%al
    70ed:	74 21                	je     7110 <fwp_drop1+0xa0>
    70ef:	3c ff                	cmp    $0xff,%al
    70f1:	74 65                	je     7158 <fwp_drop1+0xe8>
    70f3:	83 e8 01             	sub    $0x1,%eax
    70f6:	88 02                	mov    %al,(%rdx)
    70f8:	48 83 c4 18          	add    $0x18,%rsp
    70fc:	c3                   	ret
    70fd:	0f 1f 00             	nopl   (%rax)
    7100:	66 85 c0             	test   %ax,%ax
    7103:	74 df                	je     70e4 <fwp_drop1+0x74>
    7105:	48 83 c4 18          	add    $0x18,%rsp
    7109:	c3                   	ret
    710a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7110:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7114:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7119:	e8 a2 fa ff ff       	call   6bc0 <fwp_rc_free_arr>
    711e:	4c 8d 05 1b 17 06 00 	lea    0x6171b(%rip),%r8        # 68840 <fwp_heap>
    7125:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    712a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7131:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7138:	48 c1 e2 10          	shl    $0x10,%rdx
    713c:	48 39 d0             	cmp    %rdx,%rax
    713f:	73 b7                	jae    70f8 <fwp_drop1+0x88>
    7141:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7146:	e9 52 ff ff ff       	jmp    709d <fwp_drop1+0x2d>
    714b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7150:	c3                   	ret
    7151:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7158:	48 89 d0             	mov    %rdx,%rax
    715b:	48 c1 e8 11          	shr    $0x11,%rax
    715f:	48 31 d0             	xor    %rdx,%rax
    7162:	48 89 c1             	mov    %rax,%rcx
    7165:	48 c1 e9 09          	shr    $0x9,%rcx
    7169:	48 31 c8             	xor    %rcx,%rax
    716c:	0f b6 c8             	movzbl %al,%ecx
    716f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7176:	00 
    7177:	48 85 c0             	test   %rax,%rax
    717a:	75 0d                	jne    7189 <fwp_drop1+0x119>
    717c:	eb 46                	jmp    71c4 <fwp_drop1+0x154>
    717e:	66 90                	xchg   %ax,%ax
    7180:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7184:	48 85 c0             	test   %rax,%rax
    7187:	74 3b                	je     71c4 <fwp_drop1+0x154>
    7189:	48 89 c1             	mov    %rax,%rcx
    718c:	48 39 10             	cmp    %rdx,(%rax)
    718f:	75 ef                	jne    7180 <fwp_drop1+0x110>
    7191:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7195:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7199:	48 89 48 08          	mov    %rcx,0x8(%rax)
    719d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71a4:	0f 85 4e ff ff ff    	jne    70f8 <fwp_drop1+0x88>
    71aa:	48 89 d7             	mov    %rdx,%rdi
    71ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71b2:	e8 79 e6 ff ff       	call   5830 <fwp_rc_forget_slot>
    71b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    71bf:	e9 34 ff ff ff       	jmp    70f8 <fwp_drop1+0x88>
    71c4:	48 8d 3d 15 58 00 00 	lea    0x5815(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    71cb:	e8 80 d2 ff ff       	call   4450 <fwp_trap>

00000000000071d0 <fwp_closure_drop>:
    71d0:	48 8b 15 41 2a 06 00 	mov    0x62a41(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    71d7:	48 89 f8             	mov    %rdi,%rax
    71da:	48 2b 05 0f 2a 06 00 	sub    0x62a0f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    71e1:	48 c1 e2 10          	shl    $0x10,%rdx
    71e5:	48 39 d0             	cmp    %rdx,%rax
    71e8:	73 6b                	jae    7255 <fwp_closure_drop+0x85>
    71ea:	48 89 c2             	mov    %rax,%rdx
    71ed:	48 c1 ea 10          	shr    $0x10,%rdx
    71f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71f5:	48 8b 15 3c 2a 06 00 	mov    0x62a3c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    71fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7200:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7204:	48 85 d2             	test   %rdx,%rdx
    7207:	74 4c                	je     7255 <fwp_closure_drop+0x85>
    7209:	0f b6 31             	movzbl (%rcx),%esi
    720c:	40 80 fe 02          	cmp    $0x2,%sil
    7210:	74 3e                	je     7250 <fwp_closure_drop+0x80>
    7212:	40 80 fe 01          	cmp    $0x1,%sil
    7216:	75 3d                	jne    7255 <fwp_closure_drop+0x85>
    7218:	8b 71 18             	mov    0x18(%rcx),%esi
    721b:	0f b7 c0             	movzwl %ax,%eax
    721e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7221:	48 0f af c6          	imul   %rsi,%rax
    7225:	48 c1 e8 20          	shr    $0x20,%rax
    7229:	48 39 c8             	cmp    %rcx,%rax
    722c:	73 27                	jae    7255 <fwp_closure_drop+0x85>
    722e:	48 01 c2             	add    %rax,%rdx
    7231:	0f b6 02             	movzbl (%rdx),%eax
    7234:	84 c0                	test   %al,%al
    7236:	74 1d                	je     7255 <fwp_closure_drop+0x85>
    7238:	3c 01                	cmp    $0x1,%al
    723a:	74 24                	je     7260 <fwp_closure_drop+0x90>
    723c:	3c ff                	cmp    $0xff,%al
    723e:	74 48                	je     7288 <fwp_closure_drop+0xb8>
    7240:	83 e8 01             	sub    $0x1,%eax
    7243:	88 02                	mov    %al,(%rdx)
    7245:	c3                   	ret
    7246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    724d:	00 00 00 
    7250:	66 85 c0             	test   %ax,%ax
    7253:	74 dc                	je     7231 <fwp_closure_drop+0x61>
    7255:	c3                   	ret
    7256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    725d:	00 00 00 
    7260:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7267:	ff ff 
    7269:	48 85 c0             	test   %rax,%rax
    726c:	74 12                	je     7280 <fwp_closure_drop+0xb0>
    726e:	48 89 fe             	mov    %rdi,%rsi
    7271:	48 89 c7             	mov    %rax,%rdi
    7274:	e9 37 d2 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7280:	e9 db d3 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7285:	0f 1f 00             	nopl   (%rax)
    7288:	48 89 d0             	mov    %rdx,%rax
    728b:	48 8d 35 ae 15 06 00 	lea    0x615ae(%rip),%rsi        # 68840 <fwp_heap>
    7292:	48 83 ec 18          	sub    $0x18,%rsp
    7296:	48 c1 e8 11          	shr    $0x11,%rax
    729a:	48 31 d0             	xor    %rdx,%rax
    729d:	48 89 c1             	mov    %rax,%rcx
    72a0:	48 c1 e9 09          	shr    $0x9,%rcx
    72a4:	48 31 c8             	xor    %rcx,%rax
    72a7:	0f b6 c8             	movzbl %al,%ecx
    72aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    72b1:	00 
    72b2:	48 85 c0             	test   %rax,%rax
    72b5:	75 12                	jne    72c9 <fwp_closure_drop+0xf9>
    72b7:	eb 49                	jmp    7302 <fwp_closure_drop+0x132>
    72b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	74 39                	je     7302 <fwp_closure_drop+0x132>
    72c9:	48 89 c1             	mov    %rax,%rcx
    72cc:	48 39 10             	cmp    %rdx,(%rax)
    72cf:	75 ef                	jne    72c0 <fwp_closure_drop+0xf0>
    72d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    72d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    72dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    72e4:	74 05                	je     72eb <fwp_closure_drop+0x11b>
    72e6:	48 83 c4 18          	add    $0x18,%rsp
    72ea:	c3                   	ret
    72eb:	48 89 d7             	mov    %rdx,%rdi
    72ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72f3:	e8 38 e5 ff ff       	call   5830 <fwp_rc_forget_slot>
    72f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7300:	eb e4                	jmp    72e6 <fwp_closure_drop+0x116>
    7302:	48 8d 3d d7 56 00 00 	lea    0x56d7(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7309:	e8 42 d1 ff ff       	call   4450 <fwp_trap>
    730e:	66 90                	xchg   %ax,%ax

0000000000007310 <fwp_owned_tape_release>:
    7310:	48 85 ff             	test   %rdi,%rdi
    7313:	0f 84 f7 00 00 00    	je     7410 <fwp_owned_tape_release+0x100>
    7319:	41 54                	push   %r12
    731b:	55                   	push   %rbp
    731c:	53                   	push   %rbx
    731d:	48 8b 07             	mov    (%rdi),%rax
    7320:	48 85 c0             	test   %rax,%rax
    7323:	74 08                	je     732d <fwp_owned_tape_release+0x1d>
    7325:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7329:	48 89 50 08          	mov    %rdx,0x8(%rax)
    732d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7331:	48 85 d2             	test   %rdx,%rdx
    7334:	74 03                	je     7339 <fwp_owned_tape_release+0x29>
    7336:	48 89 02             	mov    %rax,(%rdx)
    7339:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    733d:	48 89 fb             	mov    %rdi,%rbx
    7340:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7344:	48 85 c0             	test   %rax,%rax
    7347:	0f 84 89 00 00 00    	je     73d6 <fwp_owned_tape_release+0xc6>
    734d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7351:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7355:	7e 47                	jle    739e <fwp_owned_tape_release+0x8e>
    7357:	31 ed                	xor    %ebp,%ebp
    7359:	eb 0d                	jmp    7368 <fwp_owned_tape_release+0x58>
    735b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7360:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7364:	48 8b 40 68          	mov    0x68(%rax),%rax
    7368:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    736c:	49 89 ec             	mov    %rbp,%r12
    736f:	48 83 c5 01          	add    $0x1,%rbp
    7373:	49 c1 e4 04          	shl    $0x4,%r12
    7377:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    737b:	ff d0                	call   *%rax
    737d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7381:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7386:	48 8b 43 10          	mov    0x10(%rbx),%rax
    738a:	ff 50 68             	call   *0x68(%rax)
    738d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7391:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7395:	48 39 e8             	cmp    %rbp,%rax
    7398:	7f c6                	jg     7360 <fwp_owned_tape_release+0x50>
    739a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    739e:	31 ed                	xor    %ebp,%ebp
    73a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    73a5:	7e 28                	jle    73cf <fwp_owned_tape_release+0xbf>
    73a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73ae:	00 00 
    73b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    73b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    73b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    73bc:	74 07                	je     73c5 <fwp_owned_tape_release+0xb5>
    73be:	ff 52 68             	call   *0x68(%rdx)
    73c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    73c5:	48 83 c5 01          	add    $0x1,%rbp
    73c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    73cd:	7f e1                	jg     73b0 <fwp_owned_tape_release+0xa0>
    73cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    73d3:	ff 52 68             	call   *0x68(%rdx)
    73d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    73da:	e8 f1 fd ff ff       	call   71d0 <fwp_closure_drop>
    73df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    73e3:	e8 e8 fd ff ff       	call   71d0 <fwp_closure_drop>
    73e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    73ec:	e8 df fd ff ff       	call   71d0 <fwp_closure_drop>
    73f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    73f5:	e8 76 e6 ff ff       	call   5a70 <fwp_mem_free>
    73fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    73fe:	e8 6d e6 ff ff       	call   5a70 <fwp_mem_free>
    7403:	48 89 df             	mov    %rbx,%rdi
    7406:	5b                   	pop    %rbx
    7407:	5d                   	pop    %rbp
    7408:	41 5c                	pop    %r12
    740a:	e9 61 e6 ff ff       	jmp    5a70 <fwp_mem_free>
    740f:	90                   	nop
    7410:	c3                   	ret
    7411:	0f 1f 40 00          	nopl   0x0(%rax)
    7415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    741c:	00 00 00 00 

0000000000007420 <fwp_tape_finish>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	41 55                	push   %r13
    7426:	41 54                	push   %r12
    7428:	55                   	push   %rbp
    7429:	53                   	push   %rbx
    742a:	48 83 ec 48          	sub    $0x48,%rsp
    742e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7435:	00 00 
    7437:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    743c:	48 8d 3d 7d 8c 01 00 	lea    0x18c7d(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    7443:	e8 58 dd ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7448:	48 83 3d b8 8c 01 00 	cmpq   $0x0,0x18cb8(%rip)        # 20108 <fwp_ntapes>
    744f:	00 
    7450:	48 c7 05 4d 8c 01 00 	movq   $0x0,0x18c4d(%rip)        # 200a8 <fwp_tape_cached_bytes>
    7457:	00 00 00 00 
    745b:	7e 79                	jle    74d6 <fwp_tape_finish+0xb6>
    745d:	45 31 e4             	xor    %r12d,%r12d
    7460:	31 ed                	xor    %ebp,%ebp
    7462:	0f 1f 00             	nopl   (%rax)
    7465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    746c:	00 00 00 00 
    7470:	48 8b 1d 99 8c 01 00 	mov    0x18c99(%rip),%rbx        # 20110 <fwp_tapes>
    7477:	48 83 c5 01          	add    $0x1,%rbp
    747b:	4c 01 e3             	add    %r12,%rbx
    747e:	49 83 c4 68          	add    $0x68,%r12
    7482:	48 89 df             	mov    %rbx,%rdi
    7485:	e8 06 c8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    748a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    748f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7494:	48 89 e7             	mov    %rsp,%rdi
    7497:	48 8b 43 40          	mov    0x40(%rbx),%rax
    749b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    749f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    74a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    74ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    74b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74b7:	e8 e4 dc ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    74bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    74c0:	e8 4b fe ff ff       	call   7310 <fwp_owned_tape_release>
    74c5:	48 39 2d 3c 8c 01 00 	cmp    %rbp,0x18c3c(%rip)        # 20108 <fwp_ntapes>
    74cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    74d3:	00 
    74d4:	7f 9a                	jg     7470 <fwp_tape_finish+0x50>
    74d6:	48 8b 3d 33 8c 01 00 	mov    0x18c33(%rip),%rdi        # 20110 <fwp_tapes>
    74dd:	48 85 ff             	test   %rdi,%rdi
    74e0:	74 05                	je     74e7 <fwp_tape_finish+0xc7>
    74e2:	e8 49 dc ff ff       	call   5130 <ad_raw_free.part.0>
    74e7:	48 c7 05 1e 8c 01 00 	movq   $0x0,0x18c1e(%rip)        # 20110 <fwp_tapes>
    74ee:	00 00 00 00 
    74f2:	48 c7 05 03 8c 01 00 	movq   $0x0,0x18c03(%rip)        # 20100 <fwp_tapes_cap>
    74f9:	00 00 00 00 
    74fd:	48 c7 05 00 8c 01 00 	movq   $0x0,0x18c00(%rip)        # 20108 <fwp_ntapes>
    7504:	00 00 00 00 
    7508:	48 c7 05 e5 8b 01 00 	movq   $0x0,0x18be5(%rip)        # 200f8 <fwp_tape_next_slot>
    750f:	00 00 00 00 
    7513:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7518:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    751f:	00 00 
    7521:	75 0b                	jne    752e <fwp_tape_finish+0x10e>
    7523:	48 83 c4 48          	add    $0x48,%rsp
    7527:	5b                   	pop    %rbx
    7528:	5d                   	pop    %rbp
    7529:	41 5c                	pop    %r12
    752b:	41 5d                	pop    %r13
    752d:	c3                   	ret
    752e:	e8 1d bf ff ff       	call   3450 <__stack_chk_fail@plt>
    7533:	66 90                	xchg   %ax,%ax
    7535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    753c:	00 00 00 00 

0000000000007540 <fwp_tape_scope_release>:
    7540:	f3 0f 1e fa          	endbr64
    7544:	41 55                	push   %r13
    7546:	41 54                	push   %r12
    7548:	55                   	push   %rbp
    7549:	53                   	push   %rbx
    754a:	48 83 ec 48          	sub    $0x48,%rsp
    754e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7555:	00 00 
    7557:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    755c:	48 63 07             	movslq (%rdi),%rax
    755f:	85 c0                	test   %eax,%eax
    7561:	0f 88 e8 00 00 00    	js     764f <fwp_tape_scope_release+0x10f>
    7567:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    756e:	ec c4 4e 
    7571:	48 89 fb             	mov    %rdi,%rbx
    7574:	48 89 e5             	mov    %rsp,%rbp
    7577:	eb 1f                	jmp    7598 <fwp_tape_scope_release+0x58>
    7579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7580:	e8 1b dc ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7585:	4c 89 ef             	mov    %r13,%rdi
    7588:	e8 83 fd ff ff       	call   7310 <fwp_owned_tape_release>
    758d:	48 63 03             	movslq (%rbx),%rax
    7590:	85 c0                	test   %eax,%eax
    7592:	0f 88 b7 00 00 00    	js     764f <fwp_tape_scope_release+0x10f>
    7598:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    759c:	48 8b 35 6d 8b 01 00 	mov    0x18b6d(%rip),%rsi        # 20110 <fwp_tapes>
    75a3:	4c 01 c6             	add    %r8,%rsi
    75a6:	48 89 f7             	mov    %rsi,%rdi
    75a9:	e8 e2 c6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    75ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    75b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    75b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    75bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    75c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    75c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    75ce:	00 
    75cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    75d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    75d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    75dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    75e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    75e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    75eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    75f2:	00 
    75f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    75fa:	00 
    75fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7602:	00 
    7603:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7607:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    760b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    760f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7613:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7619:	77 18                	ja     7633 <fwp_tape_scope_release+0xf3>
    761b:	49 c1 f8 03          	sar    $0x3,%r8
    761f:	4d 0f af c4          	imul   %r12,%r8
    7623:	4c 3b 05 ce 8a 01 00 	cmp    0x18ace(%rip),%r8        # 200f8 <fwp_tape_next_slot>
    762a:	7d 07                	jge    7633 <fwp_tape_scope_release+0xf3>
    762c:	4c 89 05 c5 8a 01 00 	mov    %r8,0x18ac5(%rip)        # 200f8 <fwp_tape_next_slot>
    7633:	48 89 ef             	mov    %rbp,%rdi
    7636:	4d 85 ed             	test   %r13,%r13
    7639:	0f 85 41 ff ff ff    	jne    7580 <fwp_tape_scope_release+0x40>
    763f:	e8 7c dc ff ff       	call   52c0 <fwp_tape_buffers_release>
    7644:	48 63 03             	movslq (%rbx),%rax
    7647:	85 c0                	test   %eax,%eax
    7649:	0f 89 49 ff ff ff    	jns    7598 <fwp_tape_scope_release+0x58>
    764f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7654:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    765b:	00 00 
    765d:	75 0b                	jne    766a <fwp_tape_scope_release+0x12a>
    765f:	48 83 c4 48          	add    $0x48,%rsp
    7663:	5b                   	pop    %rbx
    7664:	5d                   	pop    %rbp
    7665:	41 5c                	pop    %r12
    7667:	41 5d                	pop    %r13
    7669:	c3                   	ret
    766a:	e8 e1 bd ff ff       	call   3450 <__stack_chk_fail@plt>
    766f:	90                   	nop

0000000000007670 <fwp_task_dispose>:
    7670:	53                   	push   %rbx
    7671:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7675:	0f 84 cb c0 ff ff    	je     3746 <fwp_task_dispose.cold>
    767b:	48 89 fb             	mov    %rdi,%rbx
    767e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7683:	0f 85 bd c0 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7689:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    768d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7694:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    769b:	00 
    769c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    76a0:	48 85 ff             	test   %rdi,%rdi
    76a3:	74 07                	je     76ac <fwp_task_dispose+0x3c>
    76a5:	48 85 c0             	test   %rax,%rax
    76a8:	74 02                	je     76ac <fwp_task_dispose+0x3c>
    76aa:	ff d0                	call   *%rax
    76ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    76b3:	e8 b8 e3 ff ff       	call   5a70 <fwp_mem_free>
    76b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    76bf:	00 00 00 00 
    76c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    76c7:	74 6f                	je     7738 <fwp_task_dispose+0xc8>
    76c9:	48 8b 15 48 25 06 00 	mov    0x62548(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    76d0:	48 89 d8             	mov    %rbx,%rax
    76d3:	48 2b 05 16 25 06 00 	sub    0x62516(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    76da:	48 c1 e2 10          	shl    $0x10,%rdx
    76de:	48 39 d0             	cmp    %rdx,%rax
    76e1:	73 4c                	jae    772f <fwp_task_dispose+0xbf>
    76e3:	48 89 c2             	mov    %rax,%rdx
    76e6:	48 c1 ea 10          	shr    $0x10,%rdx
    76ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76ee:	48 8b 15 43 25 06 00 	mov    0x62543(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    76f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    76fd:	48 85 c9             	test   %rcx,%rcx
    7700:	74 2d                	je     772f <fwp_task_dispose+0xbf>
    7702:	0f b6 32             	movzbl (%rdx),%esi
    7705:	40 80 fe 02          	cmp    $0x2,%sil
    7709:	74 3d                	je     7748 <fwp_task_dispose+0xd8>
    770b:	40 80 fe 01          	cmp    $0x1,%sil
    770f:	75 1e                	jne    772f <fwp_task_dispose+0xbf>
    7711:	8b 72 18             	mov    0x18(%rdx),%esi
    7714:	0f b7 c0             	movzwl %ax,%eax
    7717:	8b 52 1c             	mov    0x1c(%rdx),%edx
    771a:	48 0f af c6          	imul   %rsi,%rax
    771e:	48 c1 e8 20          	shr    $0x20,%rax
    7722:	48 39 d0             	cmp    %rdx,%rax
    7725:	73 08                	jae    772f <fwp_task_dispose+0xbf>
    7727:	48 01 c1             	add    %rax,%rcx
    772a:	80 39 01             	cmpb   $0x1,(%rcx)
    772d:	74 09                	je     7738 <fwp_task_dispose+0xc8>
    772f:	5b                   	pop    %rbx
    7730:	c3                   	ret
    7731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7738:	48 89 df             	mov    %rbx,%rdi
    773b:	5b                   	pop    %rbx
    773c:	e9 2f e3 ff ff       	jmp    5a70 <fwp_mem_free>
    7741:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7748:	66 85 c0             	test   %ax,%ax
    774b:	74 dd                	je     772a <fwp_task_dispose+0xba>
    774d:	5b                   	pop    %rbx
    774e:	c3                   	ret
    774f:	90                   	nop

0000000000007750 <fwp_free_zombie>:
    7750:	48 8b 15 b9 10 06 00 	mov    0x610b9(%rip),%rdx        # 68810 <fwp_zombie>
    7757:	48 85 d2             	test   %rdx,%rdx
    775a:	0f 84 98 00 00 00    	je     77f8 <fwp_free_zombie+0xa8>
    7760:	48 3b 15 b9 10 06 00 	cmp    0x610b9(%rip),%rdx        # 68820 <fwp_cur>
    7767:	0f 84 8b 00 00 00    	je     77f8 <fwp_free_zombie+0xa8>
    776d:	48 83 ec 18          	sub    $0x18,%rsp
    7771:	48 63 05 7c 0a 06 00 	movslq 0x60a7c(%rip),%rax        # 681f4 <fwp_stack_pool_n>
    7778:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    777c:	83 f8 3f             	cmp    $0x3f,%eax
    777f:	7f 7f                	jg     7800 <fwp_free_zombie+0xb0>
    7781:	8d 48 01             	lea    0x1(%rax),%ecx
    7784:	89 0d 6a 0a 06 00    	mov    %ecx,0x60a6a(%rip)        # 681f4 <fwp_stack_pool_n>
    778a:	48 8d 0d 6f 0a 06 00 	lea    0x60a6f(%rip),%rcx        # 68200 <fwp_stack_pool>
    7791:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7795:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    779c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    77a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    77ab:	48 85 c9             	test   %rcx,%rcx
    77ae:	0f 84 fc 00 00 00    	je     78b0 <fwp_free_zombie+0x160>
    77b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    77bb:	48 85 c0             	test   %rax,%rax
    77be:	74 07                	je     77c7 <fwp_free_zombie+0x77>
    77c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    77c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    77ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77ce:	48 c7 05 37 10 06 00 	movq   $0x0,0x61037(%rip)        # 68810 <fwp_zombie>
    77d5:	00 00 00 00 
    77d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    77e0:	85 c0                	test   %eax,%eax
    77e2:	74 34                	je     7818 <fwp_free_zombie+0xc8>
    77e4:	83 f8 01             	cmp    $0x1,%eax
    77e7:	0f 84 b3 00 00 00    	je     78a0 <fwp_free_zombie+0x150>
    77ed:	48 83 c4 18          	add    $0x18,%rsp
    77f1:	c3                   	ret
    77f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77f8:	c3                   	ret
    77f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7800:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7804:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7809:	e8 b2 bd ff ff       	call   35c0 <munmap@plt>
    780e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7813:	eb 80                	jmp    7795 <fwp_free_zombie+0x45>
    7815:	0f 1f 00             	nopl   (%rax)
    7818:	48 8b 0d f9 23 06 00 	mov    0x623f9(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    781f:	48 89 d0             	mov    %rdx,%rax
    7822:	48 2b 05 c7 23 06 00 	sub    0x623c7(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7829:	48 c1 e1 10          	shl    $0x10,%rcx
    782d:	48 39 c8             	cmp    %rcx,%rax
    7830:	73 bb                	jae    77ed <fwp_free_zombie+0x9d>
    7832:	48 89 c1             	mov    %rax,%rcx
    7835:	48 c1 e9 10          	shr    $0x10,%rcx
    7839:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    783d:	48 8b 0d f4 23 06 00 	mov    0x623f4(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    7844:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7848:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    784c:	48 85 c9             	test   %rcx,%rcx
    784f:	74 9c                	je     77ed <fwp_free_zombie+0x9d>
    7851:	0f b6 3e             	movzbl (%rsi),%edi
    7854:	40 80 ff 02          	cmp    $0x2,%dil
    7858:	74 66                	je     78c0 <fwp_free_zombie+0x170>
    785a:	40 80 ff 01          	cmp    $0x1,%dil
    785e:	75 8d                	jne    77ed <fwp_free_zombie+0x9d>
    7860:	8b 7e 18             	mov    0x18(%rsi),%edi
    7863:	0f b7 c0             	movzwl %ax,%eax
    7866:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7869:	48 0f af c7          	imul   %rdi,%rax
    786d:	48 c1 e8 20          	shr    $0x20,%rax
    7871:	48 39 f0             	cmp    %rsi,%rax
    7874:	0f 83 73 ff ff ff    	jae    77ed <fwp_free_zombie+0x9d>
    787a:	48 01 c1             	add    %rax,%rcx
    787d:	0f b6 01             	movzbl (%rcx),%eax
    7880:	84 c0                	test   %al,%al
    7882:	0f 84 65 ff ff ff    	je     77ed <fwp_free_zombie+0x9d>
    7888:	3c 01                	cmp    $0x1,%al
    788a:	74 14                	je     78a0 <fwp_free_zombie+0x150>
    788c:	3c ff                	cmp    $0xff,%al
    788e:	74 3b                	je     78cb <fwp_free_zombie+0x17b>
    7890:	83 e8 01             	sub    $0x1,%eax
    7893:	88 01                	mov    %al,(%rcx)
    7895:	e9 53 ff ff ff       	jmp    77ed <fwp_free_zombie+0x9d>
    789a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78a0:	48 89 d7             	mov    %rdx,%rdi
    78a3:	48 83 c4 18          	add    $0x18,%rsp
    78a7:	e9 c4 fd ff ff       	jmp    7670 <fwp_task_dispose>
    78ac:	0f 1f 40 00          	nopl   0x0(%rax)
    78b0:	48 89 05 31 0f 06 00 	mov    %rax,0x60f31(%rip)        # 687e8 <fwp_tasks_active>
    78b7:	e9 ff fe ff ff       	jmp    77bb <fwp_free_zombie+0x6b>
    78bc:	0f 1f 40 00          	nopl   0x0(%rax)
    78c0:	66 85 c0             	test   %ax,%ax
    78c3:	0f 85 24 ff ff ff    	jne    77ed <fwp_free_zombie+0x9d>
    78c9:	eb b2                	jmp    787d <fwp_free_zombie+0x12d>
    78cb:	48 89 ca             	mov    %rcx,%rdx
    78ce:	48 8d 35 6b 0f 06 00 	lea    0x60f6b(%rip),%rsi        # 68840 <fwp_heap>
    78d5:	48 c1 ea 11          	shr    $0x11,%rdx
    78d9:	48 31 ca             	xor    %rcx,%rdx
    78dc:	48 89 d0             	mov    %rdx,%rax
    78df:	48 c1 e8 09          	shr    $0x9,%rax
    78e3:	48 31 c2             	xor    %rax,%rdx
    78e6:	0f b6 d2             	movzbl %dl,%edx
    78e9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    78f0:	00 
    78f1:	48 85 c0             	test   %rax,%rax
    78f4:	75 13                	jne    7909 <fwp_free_zombie+0x1b9>
    78f6:	eb 4c                	jmp    7944 <fwp_free_zombie+0x1f4>
    78f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    78ff:	00 
    7900:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7904:	48 85 c0             	test   %rax,%rax
    7907:	74 3b                	je     7944 <fwp_free_zombie+0x1f4>
    7909:	48 89 c2             	mov    %rax,%rdx
    790c:	48 39 08             	cmp    %rcx,(%rax)
    790f:	75 ef                	jne    7900 <fwp_free_zombie+0x1b0>
    7911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7915:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7919:	48 89 50 08          	mov    %rdx,0x8(%rax)
    791d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7924:	0f 85 c3 fe ff ff    	jne    77ed <fwp_free_zombie+0x9d>
    792a:	48 89 cf             	mov    %rcx,%rdi
    792d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7932:	e8 f9 de ff ff       	call   5830 <fwp_rc_forget_slot>
    7937:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    793c:	c6 01 fe             	movb   $0xfe,(%rcx)
    793f:	e9 a9 fe ff ff       	jmp    77ed <fwp_free_zombie+0x9d>
    7944:	48 8d 3d 95 50 00 00 	lea    0x5095(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    794b:	e8 00 cb ff ff       	call   4450 <fwp_trap>

0000000000007950 <fwp_block>:
    7950:	48 83 ec 08          	sub    $0x8,%rsp
    7954:	48 8b 05 ad 0e 06 00 	mov    0x60ead(%rip),%rax        # 68808 <fwp_ready_head>
    795b:	48 85 c0             	test   %rax,%rax
    795e:	0f 84 1c 01 00 00    	je     7a80 <fwp_block+0x130>
    7964:	90                   	nop
    7965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    796c:	00 00 00 00 
    7970:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7977:	48 89 15 8a 0e 06 00 	mov    %rdx,0x60e8a(%rip)        # 68808 <fwp_ready_head>
    797e:	48 85 d2             	test   %rdx,%rdx
    7981:	0f 84 19 01 00 00    	je     7aa0 <fwp_block+0x150>
    7987:	48 8b 15 92 0e 06 00 	mov    0x60e92(%rip),%rdx        # 68820 <fwp_cur>
    798e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7992:	48 39 c2             	cmp    %rax,%rdx
    7995:	0f 84 d5 00 00 00    	je     7a70 <fwp_block+0x120>
    799b:	48 8b 0d 06 2b 06 00 	mov    0x62b06(%rip),%rcx        # 6a4a8 <fwp_state_owners>
    79a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    79a6:	48 89 05 73 0e 06 00 	mov    %rax,0x60e73(%rip)        # 68820 <fwp_cur>
    79ad:	f3 0f 7e 05 1b 2b 06 	movq   0x62b1b(%rip),%xmm0        # 6a4d0 <fwp_foreign_callbacks>
    79b4:	00 
    79b5:	0f 16 05 04 2b 06 00 	movhps 0x62b04(%rip),%xmm0        # 6a4c0 <fwp_state>
    79bc:	f3 0f 7e 0d 04 2b 06 	movq   0x62b04(%rip),%xmm1        # 6a4c8 <fwp_handlers>
    79c3:	00 
    79c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    79cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    79d2:	0f 16 0d ff 2a 06 00 	movhps 0x62aff(%rip),%xmm1        # 6a4d8 <fwp_cleanups>
    79d9:	f3 0f 7e 05 d7 2a 06 	movq   0x62ad7(%rip),%xmm0        # 6a4b8 <fwp_state_len>
    79e0:	00 
    79e1:	0f 16 05 c8 2a 06 00 	movhps 0x62ac8(%rip),%xmm0        # 6a4b0 <fwp_state_cap>
    79e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    79ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    79f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7a01:	48 89 0d c0 2a 06 00 	mov    %rcx,0x62ac0(%rip)        # 6a4c8 <fwp_handlers>
    7a08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7a0f:	48 89 0d c2 2a 06 00 	mov    %rcx,0x62ac2(%rip)        # 6a4d8 <fwp_cleanups>
    7a16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7a1d:	48 89 0d ac 2a 06 00 	mov    %rcx,0x62aac(%rip)        # 6a4d0 <fwp_foreign_callbacks>
    7a24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7a2b:	48 89 0d 8e 2a 06 00 	mov    %rcx,0x62a8e(%rip)        # 6a4c0 <fwp_state>
    7a32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7a39:	48 89 0d 78 2a 06 00 	mov    %rcx,0x62a78(%rip)        # 6a4b8 <fwp_state_len>
    7a40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7a47:	48 89 0d 62 2a 06 00 	mov    %rcx,0x62a62(%rip)        # 6a4b0 <fwp_state_cap>
    7a4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7a55:	48 89 0d 4c 2a 06 00 	mov    %rcx,0x62a4c(%rip)        # 6a4a8 <fwp_state_owners>
    7a5c:	e8 1f ba ff ff       	call   3480 <swapcontext@plt>
    7a61:	f3 0f 1e fa          	endbr64
    7a65:	e8 e6 fc ff ff       	call   7750 <fwp_free_zombie>
    7a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a70:	8b 05 7a 07 06 00    	mov    0x6077a(%rip),%eax        # 681f0 <fwp_slice>
    7a76:	85 c0                	test   %eax,%eax
    7a78:	74 36                	je     7ab0 <fwp_block+0x160>
    7a7a:	48 83 c4 08          	add    $0x8,%rsp
    7a7e:	c3                   	ret
    7a7f:	90                   	nop
    7a80:	e8 eb d9 ff ff       	call   5470 <fwp_poll_events>
    7a85:	48 8b 05 7c 0d 06 00 	mov    0x60d7c(%rip),%rax        # 68808 <fwp_ready_head>
    7a8c:	48 85 c0             	test   %rax,%rax
    7a8f:	0f 85 db fe ff ff    	jne    7970 <fwp_block+0x20>
    7a95:	eb e9                	jmp    7a80 <fwp_block+0x130>
    7a97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a9e:	00 00 
    7aa0:	48 c7 05 55 0d 06 00 	movq   $0x0,0x60d55(%rip)        # 68800 <fwp_ready_tail>
    7aa7:	00 00 00 00 
    7aab:	e9 d7 fe ff ff       	jmp    7987 <fwp_block+0x37>
    7ab0:	48 8d 3d 28 47 00 00 	lea    0x4728(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    7ab7:	e8 d4 b8 ff ff       	call   3390 <getenv@plt>
    7abc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7ac1:	48 85 c0             	test   %rax,%rax
    7ac4:	74 05                	je     7acb <fwp_block+0x17b>
    7ac6:	80 38 00             	cmpb   $0x0,(%rax)
    7ac9:	75 0b                	jne    7ad6 <fwp_block+0x186>
    7acb:	89 15 1f 07 06 00    	mov    %edx,0x6071f(%rip)        # 681f0 <fwp_slice>
    7ad1:	48 83 c4 08          	add    $0x8,%rsp
    7ad5:	c3                   	ret
    7ad6:	ba 0a 00 00 00       	mov    $0xa,%edx
    7adb:	31 f6                	xor    %esi,%esi
    7add:	48 89 c7             	mov    %rax,%rdi
    7ae0:	e8 5b ba ff ff       	call   3540 <strtoll@plt>
    7ae5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ae9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7af0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7af5:	0f 46 d0             	cmovbe %eax,%edx
    7af8:	eb d1                	jmp    7acb <fwp_block+0x17b>
    7afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007b00 <fwp_drop4>:
    7b00:	48 8b 15 11 21 06 00 	mov    0x62111(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7b07:	48 89 f8             	mov    %rdi,%rax
    7b0a:	48 2b 05 df 20 06 00 	sub    0x620df(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7b11:	48 c1 e2 10          	shl    $0x10,%rdx
    7b15:	48 39 d0             	cmp    %rdx,%rax
    7b18:	0f 83 52 01 00 00    	jae    7c70 <fwp_drop4+0x170>
    7b1e:	48 83 ec 18          	sub    $0x18,%rsp
    7b22:	4c 8d 05 17 0d 06 00 	lea    0x60d17(%rip),%r8        # 68840 <fwp_heap>
    7b29:	48 89 c2             	mov    %rax,%rdx
    7b2c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7b33:	48 c1 ea 10          	shr    $0x10,%rdx
    7b37:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b3b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7b3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b43:	48 85 d2             	test   %rdx,%rdx
    7b46:	74 46                	je     7b8e <fwp_drop4+0x8e>
    7b48:	44 0f b6 09          	movzbl (%rcx),%r9d
    7b4c:	41 80 f9 02          	cmp    $0x2,%r9b
    7b50:	0f 84 ca 00 00 00    	je     7c20 <fwp_drop4+0x120>
    7b56:	41 80 f9 01          	cmp    $0x1,%r9b
    7b5a:	75 32                	jne    7b8e <fwp_drop4+0x8e>
    7b5c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7b60:	0f b7 c0             	movzwl %ax,%eax
    7b63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b66:	49 0f af c1          	imul   %r9,%rax
    7b6a:	48 c1 e8 20          	shr    $0x20,%rax
    7b6e:	48 39 c8             	cmp    %rcx,%rax
    7b71:	73 1b                	jae    7b8e <fwp_drop4+0x8e>
    7b73:	48 01 c2             	add    %rax,%rdx
    7b76:	0f b6 02             	movzbl (%rdx),%eax
    7b79:	84 c0                	test   %al,%al
    7b7b:	74 11                	je     7b8e <fwp_drop4+0x8e>
    7b7d:	3c 01                	cmp    $0x1,%al
    7b7f:	74 17                	je     7b98 <fwp_drop4+0x98>
    7b81:	3c ff                	cmp    $0xff,%al
    7b83:	0f 84 ef 00 00 00    	je     7c78 <fwp_drop4+0x178>
    7b89:	83 e8 01             	sub    $0x1,%eax
    7b8c:	88 02                	mov    %al,(%rdx)
    7b8e:	48 83 c4 18          	add    $0x18,%rsp
    7b92:	c3                   	ret
    7b93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b98:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7b9c:	0f 88 8e 00 00 00    	js     7c30 <fwp_drop4+0x130>
    7ba2:	48 8b 15 6f 20 06 00 	mov    0x6206f(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7ba9:	48 89 f8             	mov    %rdi,%rax
    7bac:	48 2b 05 3d 20 06 00 	sub    0x6203d(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7bb3:	48 c1 e2 10          	shl    $0x10,%rdx
    7bb7:	48 39 d0             	cmp    %rdx,%rax
    7bba:	73 d2                	jae    7b8e <fwp_drop4+0x8e>
    7bbc:	48 89 c2             	mov    %rax,%rdx
    7bbf:	48 c1 ea 10          	shr    $0x10,%rdx
    7bc3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7bc7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7bcb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7bcf:	48 85 c9             	test   %rcx,%rcx
    7bd2:	74 ba                	je     7b8e <fwp_drop4+0x8e>
    7bd4:	0f b6 32             	movzbl (%rdx),%esi
    7bd7:	40 80 fe 02          	cmp    $0x2,%sil
    7bdb:	74 33                	je     7c10 <fwp_drop4+0x110>
    7bdd:	40 80 fe 01          	cmp    $0x1,%sil
    7be1:	75 ab                	jne    7b8e <fwp_drop4+0x8e>
    7be3:	8b 72 18             	mov    0x18(%rdx),%esi
    7be6:	0f b7 c0             	movzwl %ax,%eax
    7be9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bec:	48 0f af c6          	imul   %rsi,%rax
    7bf0:	48 c1 e8 20          	shr    $0x20,%rax
    7bf4:	48 39 d0             	cmp    %rdx,%rax
    7bf7:	73 95                	jae    7b8e <fwp_drop4+0x8e>
    7bf9:	48 01 c1             	add    %rax,%rcx
    7bfc:	80 39 01             	cmpb   $0x1,(%rcx)
    7bff:	75 8d                	jne    7b8e <fwp_drop4+0x8e>
    7c01:	48 83 c4 18          	add    $0x18,%rsp
    7c05:	e9 66 de ff ff       	jmp    5a70 <fwp_mem_free>
    7c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c10:	66 85 c0             	test   %ax,%ax
    7c13:	74 e7                	je     7bfc <fwp_drop4+0xfc>
    7c15:	48 83 c4 18          	add    $0x18,%rsp
    7c19:	c3                   	ret
    7c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c20:	66 85 c0             	test   %ax,%ax
    7c23:	0f 84 4d ff ff ff    	je     7b76 <fwp_drop4+0x76>
    7c29:	48 83 c4 18          	add    $0x18,%rsp
    7c2d:	c3                   	ret
    7c2e:	66 90                	xchg   %ax,%ax
    7c30:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7c34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c39:	e8 82 ef ff ff       	call   6bc0 <fwp_rc_free_arr>
    7c3e:	4c 8d 05 fb 0b 06 00 	lea    0x60bfb(%rip),%r8        # 68840 <fwp_heap>
    7c45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7c51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c58:	48 c1 e2 10          	shl    $0x10,%rdx
    7c5c:	48 39 d0             	cmp    %rdx,%rax
    7c5f:	0f 83 29 ff ff ff    	jae    7b8e <fwp_drop4+0x8e>
    7c65:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7c6a:	e9 ba fe ff ff       	jmp    7b29 <fwp_drop4+0x29>
    7c6f:	90                   	nop
    7c70:	c3                   	ret
    7c71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c78:	48 89 d0             	mov    %rdx,%rax
    7c7b:	48 c1 e8 11          	shr    $0x11,%rax
    7c7f:	48 31 d0             	xor    %rdx,%rax
    7c82:	48 89 c1             	mov    %rax,%rcx
    7c85:	48 c1 e9 09          	shr    $0x9,%rcx
    7c89:	48 31 c8             	xor    %rcx,%rax
    7c8c:	0f b6 c8             	movzbl %al,%ecx
    7c8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7c96:	00 
    7c97:	48 85 c0             	test   %rax,%rax
    7c9a:	75 0d                	jne    7ca9 <fwp_drop4+0x1a9>
    7c9c:	eb 46                	jmp    7ce4 <fwp_drop4+0x1e4>
    7c9e:	66 90                	xchg   %ax,%ax
    7ca0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ca4:	48 85 c0             	test   %rax,%rax
    7ca7:	74 3b                	je     7ce4 <fwp_drop4+0x1e4>
    7ca9:	48 89 c1             	mov    %rax,%rcx
    7cac:	48 39 10             	cmp    %rdx,(%rax)
    7caf:	75 ef                	jne    7ca0 <fwp_drop4+0x1a0>
    7cb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7cb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7cbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7cc4:	0f 85 c4 fe ff ff    	jne    7b8e <fwp_drop4+0x8e>
    7cca:	48 89 d7             	mov    %rdx,%rdi
    7ccd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cd2:	e8 59 db ff ff       	call   5830 <fwp_rc_forget_slot>
    7cd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cdf:	e9 aa fe ff ff       	jmp    7b8e <fwp_drop4+0x8e>
    7ce4:	48 8d 3d f5 4c 00 00 	lea    0x4cf5(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7ceb:	e8 60 c7 ff ff       	call   4450 <fwp_trap>

0000000000007cf0 <fwp_caps161>:
    7cf0:	f3 0f 1e fa          	endbr64
    7cf4:	85 f6                	test   %esi,%esi
    7cf6:	74 08                	je     7d00 <fwp_caps161+0x10>
    7cf8:	c3                   	ret
    7cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d00:	48 8b 15 11 1f 06 00 	mov    0x61f11(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7d07:	48 89 f8             	mov    %rdi,%rax
    7d0a:	48 2b 05 df 1e 06 00 	sub    0x61edf(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7d11:	48 c1 e2 10          	shl    $0x10,%rdx
    7d15:	48 39 d0             	cmp    %rdx,%rax
    7d18:	73 de                	jae    7cf8 <fwp_caps161+0x8>
    7d1a:	48 89 c2             	mov    %rax,%rdx
    7d1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d25:	48 8b 15 0c 1f 06 00 	mov    0x61f0c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    7d2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d34:	48 85 c9             	test   %rcx,%rcx
    7d37:	74 bf                	je     7cf8 <fwp_caps161+0x8>
    7d39:	0f b6 32             	movzbl (%rdx),%esi
    7d3c:	40 80 fe 02          	cmp    $0x2,%sil
    7d40:	74 2e                	je     7d70 <fwp_caps161+0x80>
    7d42:	40 80 fe 01          	cmp    $0x1,%sil
    7d46:	75 b0                	jne    7cf8 <fwp_caps161+0x8>
    7d48:	8b 72 18             	mov    0x18(%rdx),%esi
    7d4b:	0f b7 c0             	movzwl %ax,%eax
    7d4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d51:	48 0f af c6          	imul   %rsi,%rax
    7d55:	48 c1 e8 20          	shr    $0x20,%rax
    7d59:	48 39 d0             	cmp    %rdx,%rax
    7d5c:	73 9a                	jae    7cf8 <fwp_caps161+0x8>
    7d5e:	48 01 c1             	add    %rax,%rcx
    7d61:	80 39 01             	cmpb   $0x1,(%rcx)
    7d64:	75 92                	jne    7cf8 <fwp_caps161+0x8>
    7d66:	e9 05 dd ff ff       	jmp    5a70 <fwp_mem_free>
    7d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d70:	66 85 c0             	test   %ax,%ax
    7d73:	74 ec                	je     7d61 <fwp_caps161+0x71>
    7d75:	c3                   	ret
    7d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d7d:	00 00 00 

0000000000007d80 <f12>:
    7d80:	41 57                	push   %r15
    7d82:	41 56                	push   %r14
    7d84:	41 55                	push   %r13
    7d86:	4c 8d 2d b3 f7 ff ff 	lea    -0x84d(%rip),%r13        # 7540 <fwp_tape_scope_release>
    7d8d:	41 54                	push   %r12
    7d8f:	55                   	push   %rbp
    7d90:	53                   	push   %rbx
    7d91:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    7d98:	48 8b 05 39 27 06 00 	mov    0x62739(%rip),%rax        # 6a4d8 <fwp_cleanups>
    7d9f:	48 8b 15 72 1e 06 00 	mov    0x61e72(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7da6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    7dad:	00 00 
    7daf:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
    7db6:	00 
    7db7:	48 89 fd             	mov    %rdi,%rbp
    7dba:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
    7dbf:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    7dc6:	ff 
    7dc7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7dcc:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    7dd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7dd5:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7dda:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    7de1:	00 
    7de2:	48 8d 05 27 82 00 00 	lea    0x8227(%rip),%rax        # 10010 <fc23>
    7de9:	48 2b 05 00 1e 06 00 	sub    0x61e00(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7df0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    7df5:	4c 89 3d dc 26 06 00 	mov    %r15,0x626dc(%rip)        # 6a4d8 <fwp_cleanups>
    7dfc:	48 39 d0             	cmp    %rdx,%rax
    7dff:	73 6d                	jae    7e6e <f12+0xee>
    7e01:	48 89 c2             	mov    %rax,%rdx
    7e04:	48 c1 ea 10          	shr    $0x10,%rdx
    7e08:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e0c:	48 8b 15 25 1e 06 00 	mov    0x61e25(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    7e13:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e17:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e1b:	48 85 ff             	test   %rdi,%rdi
    7e1e:	74 4e                	je     7e6e <f12+0xee>
    7e20:	0f b6 0a             	movzbl (%rdx),%ecx
    7e23:	80 f9 02             	cmp    $0x2,%cl
    7e26:	0f 84 54 0f 00 00    	je     8d80 <f12+0x1000>
    7e2c:	80 f9 01             	cmp    $0x1,%cl
    7e2f:	75 3d                	jne    7e6e <f12+0xee>
    7e31:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e34:	0f b7 c0             	movzwl %ax,%eax
    7e37:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e3a:	48 0f af c1          	imul   %rcx,%rax
    7e3e:	48 c1 e8 20          	shr    $0x20,%rax
    7e42:	48 39 d0             	cmp    %rdx,%rax
    7e45:	73 27                	jae    7e6e <f12+0xee>
    7e47:	48 01 c7             	add    %rax,%rdi
    7e4a:	0f b6 07             	movzbl (%rdi),%eax
    7e4d:	84 c0                	test   %al,%al
    7e4f:	74 1d                	je     7e6e <f12+0xee>
    7e51:	44 8b 05 b0 26 06 00 	mov    0x626b0(%rip),%r8d        # 6a508 <iteration_active>
    7e58:	45 85 c0             	test   %r8d,%r8d
    7e5b:	0f 85 4f 10 00 00    	jne    8eb0 <f12+0x1130>
    7e61:	3c fd                	cmp    $0xfd,%al
    7e63:	0f 87 0b 12 00 00    	ja     9074 <f12+0x12f4>
    7e69:	83 c0 01             	add    $0x1,%eax
    7e6c:	88 07                	mov    %al,(%rdi)
    7e6e:	48 8d 3d 9b 81 00 00 	lea    0x819b(%rip),%rdi        # 10010 <fc23>
    7e75:	e8 56 f3 ff ff       	call   71d0 <fwp_closure_drop>
    7e7a:	48 85 ed             	test   %rbp,%rbp
    7e7d:	0f 84 46 11 00 00    	je     8fc9 <f12+0x1249>
    7e83:	48 89 e8             	mov    %rbp,%rax
    7e86:	31 d2                	xor    %edx,%edx
    7e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e8f:	00 
    7e90:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e94:	48 83 c2 01          	add    $0x1,%rdx
    7e98:	48 85 c0             	test   %rax,%rax
    7e9b:	75 f3                	jne    7e90 <f12+0x110>
    7e9d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7ea4:	0f 87 5a 12 00 00    	ja     9104 <f12+0x1384>
    7eaa:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7eaf:	8b 35 ab 81 00 00    	mov    0x81ab(%rip),%esi        # 10060 <registered_finish.0>
    7eb5:	85 f6                	test   %esi,%esi
    7eb7:	0f 84 93 0e 00 00    	je     8d50 <f12+0xfd0>
    7ebd:	48 8b 1d 34 82 01 00 	mov    0x18234(%rip),%rbx        # 200f8 <fwp_tape_next_slot>
    7ec4:	4c 8b 25 3d 82 01 00 	mov    0x1823d(%rip),%r12        # 20108 <fwp_ntapes>
    7ecb:	4c 39 e3             	cmp    %r12,%rbx
    7ece:	0f 8d d4 00 00 00    	jge    7fa8 <f12+0x228>
    7ed4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7ed8:	48 03 05 31 82 01 00 	add    0x18231(%rip),%rax        # 20110 <fwp_tapes>
    7edf:	90                   	nop
    7ee0:	8b 48 04             	mov    0x4(%rax),%ecx
    7ee3:	85 c9                	test   %ecx,%ecx
    7ee5:	75 0c                	jne    7ef3 <f12+0x173>
    7ee7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7eed:	0f 86 b5 00 00 00    	jbe    7fa8 <f12+0x228>
    7ef3:	48 83 c3 01          	add    $0x1,%rbx
    7ef7:	48 83 c0 68          	add    $0x68,%rax
    7efb:	4c 39 e3             	cmp    %r12,%rbx
    7efe:	75 e0                	jne    7ee0 <f12+0x160>
    7f00:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7f07:	0f 8f 6c 12 00 00    	jg     9179 <f12+0x13f9>
    7f0d:	4c 39 25 ec 81 01 00 	cmp    %r12,0x181ec(%rip)        # 20100 <fwp_tapes_cap>
    7f14:	4c 8b 35 f5 81 01 00 	mov    0x181f5(%rip),%r14        # 20110 <fwp_tapes>
    7f1b:	75 4b                	jne    7f68 <f12+0x1e8>
    7f1d:	4d 85 e4             	test   %r12,%r12
    7f20:	0f 84 08 11 00 00    	je     902e <f12+0x12ae>
    7f26:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    7f2a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7f2f:	48 39 c3             	cmp    %rax,%rbx
    7f32:	48 0f 4f d8          	cmovg  %rax,%rbx
    7f36:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7f3a:	31 d2                	xor    %edx,%edx
    7f3c:	4c 89 f7             	mov    %r14,%rdi
    7f3f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7f44:	e8 a7 d2 ff ff       	call   51f0 <ad_raw_realloc>
    7f49:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7f4e:	48 85 c0             	test   %rax,%rax
    7f51:	49 89 c6             	mov    %rax,%r14
    7f54:	0f 84 e5 11 00 00    	je     913f <f12+0x13bf>
    7f5a:	48 89 05 af 81 01 00 	mov    %rax,0x181af(%rip)        # 20110 <fwp_tapes>
    7f61:	48 89 1d 98 81 01 00 	mov    %rbx,0x18198(%rip)        # 20100 <fwp_tapes_cap>
    7f68:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7f6c:	4c 89 e3             	mov    %r12,%rbx
    7f6f:	4c 01 f0             	add    %r14,%rax
    7f72:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7f76:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7f7d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7f81:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7f88:	00 
    7f89:	48 29 f8             	sub    %rdi,%rax
    7f8c:	8d 48 68             	lea    0x68(%rax),%ecx
    7f8f:	31 c0                	xor    %eax,%eax
    7f91:	c1 e9 03             	shr    $0x3,%ecx
    7f94:	f3 48 ab             	rep stos %rax,(%rdi)
    7f97:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    7f9c:	48 89 05 65 81 01 00 	mov    %rax,0x18165(%rip)        # 20108 <fwp_ntapes>
    7fa3:	eb 13                	jmp    7fb8 <f12+0x238>
    7fa5:	0f 1f 00             	nopl   (%rax)
    7fa8:	49 39 dc             	cmp    %rbx,%r12
    7fab:	0f 84 4f ff ff ff    	je     7f00 <f12+0x180>
    7fb1:	4c 8b 35 58 81 01 00 	mov    0x18158(%rip),%r14        # 20110 <fwp_tapes>
    7fb8:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7fbc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7fc0:	48 8d 3d 99 41 00 00 	lea    0x4199(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    7fc7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7fcb:	4d 01 f4             	add    %r14,%r12
    7fce:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7fd5:	00 00 
    7fd7:	e8 b4 b3 ff ff       	call   3390 <getenv@plt>
    7fdc:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7fe1:	48 85 c0             	test   %rax,%rax
    7fe4:	74 09                	je     7fef <f12+0x26f>
    7fe6:	80 38 30             	cmpb   $0x30,(%rax)
    7fe9:	0f 84 11 07 00 00    	je     8700 <f12+0x980>
    7fef:	48 83 3d b1 80 01 00 	cmpq   $0x0,0x180b1(%rip)        # 200a8 <fwp_tape_cached_bytes>
    7ff6:	00 
    7ff7:	0f 85 e3 0d 00 00    	jne    8de0 <f12+0x1060>
    7ffd:	41 8b 04 24          	mov    (%r12),%eax
    8001:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    8005:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    800c:	00 00 
    800e:	48 89 3d e3 80 01 00 	mov    %rdi,0x180e3(%rip)        # 200f8 <fwp_tape_next_slot>
    8015:	8d 70 01             	lea    0x1(%rax),%esi
    8018:	48 8b 05 b9 24 06 00 	mov    0x624b9(%rip),%rax        # 6a4d8 <fwp_cleanups>
    801f:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8026:	00 00 
    8028:	41 89 34 24          	mov    %esi,(%r12)
    802c:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    8033:	ff ff 
    8035:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    803b:	48 85 c0             	test   %rax,%rax
    803e:	75 1c                	jne    805c <f12+0x2dc>
    8040:	e9 51 11 00 00       	jmp    9196 <f12+0x1416>
    8045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    804c:	00 00 00 00 
    8050:	48 8b 00             	mov    (%rax),%rax
    8053:	48 85 c0             	test   %rax,%rax
    8056:	0f 84 3a 11 00 00    	je     9196 <f12+0x1416>
    805c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8060:	75 ee                	jne    8050 <f12+0x2d0>
    8062:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8066:	89 d9                	mov    %ebx,%ecx
    8068:	48 63 02             	movslq (%rdx),%rax
    806b:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    8070:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8075:	85 c0                	test   %eax,%eax
    8077:	78 09                	js     8082 <f12+0x302>
    8079:	48 6b c0 68          	imul   $0x68,%rax,%rax
    807d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8082:	89 0a                	mov    %ecx,(%rdx)
    8084:	48 89 e8             	mov    %rbp,%rax
    8087:	31 c9                	xor    %ecx,%ecx
    8089:	48 85 ed             	test   %rbp,%rbp
    808c:	0f 84 9e 0b 00 00    	je     8c30 <f12+0xeb0>
    8092:	0f 1f 00             	nopl   (%rax)
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    80a4:	48 83 c1 01          	add    $0x1,%rcx
    80a8:	48 85 c0             	test   %rax,%rax
    80ab:	75 f3                	jne    80a0 <f12+0x320>
    80ad:	48 89 ea             	mov    %rbp,%rdx
    80b0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80b4:	48 83 c0 01          	add    $0x1,%rax
    80b8:	48 85 d2             	test   %rdx,%rdx
    80bb:	75 f3                	jne    80b0 <f12+0x330>
    80bd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    80c4:	ff ff 1f 
    80c7:	48 39 c2             	cmp    %rax,%rdx
    80ca:	0f 82 40 10 00 00    	jb     9110 <f12+0x1390>
    80d0:	48 85 c9             	test   %rcx,%rcx
    80d3:	0f 8e 57 0b 00 00    	jle    8c30 <f12+0xeb0>
    80d9:	48 39 c1             	cmp    %rax,%rcx
    80dc:	48 0f 46 c1          	cmovbe %rcx,%rax
    80e0:	49 89 c5             	mov    %rax,%r13
    80e3:	48 c1 e8 3c          	shr    $0x3c,%rax
    80e7:	0f 85 23 10 00 00    	jne    9110 <f12+0x1390>
    80ed:	48 c1 e6 10          	shl    $0x10,%rsi
    80f1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    80f6:	48 09 fe             	or     %rdi,%rsi
    80f9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8100:	00 
    8101:	49 89 f4             	mov    %rsi,%r12
    8104:	be 02 00 00 00       	mov    $0x2,%esi
    8109:	e8 62 de ff ff       	call   5f70 <fwp_heap_alloc>
    810e:	4c 89 30             	mov    %r14,(%rax)
    8111:	48 8b 15 00 1b 06 00 	mov    0x61b00(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    8118:	48 89 c3             	mov    %rax,%rbx
    811b:	48 2b 05 ce 1a 06 00 	sub    0x61ace(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8122:	48 c1 e2 10          	shl    $0x10,%rdx
    8126:	48 39 d0             	cmp    %rdx,%rax
    8129:	0f 83 99 0b 00 00    	jae    8cc8 <f12+0xf48>
    812f:	48 89 c2             	mov    %rax,%rdx
    8132:	48 c1 ea 10          	shr    $0x10,%rdx
    8136:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    813a:	48 8b 15 f7 1a 06 00 	mov    0x61af7(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8141:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8145:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8149:	48 85 d2             	test   %rdx,%rdx
    814c:	74 38                	je     8186 <f12+0x406>
    814e:	0f b6 31             	movzbl (%rcx),%esi
    8151:	40 80 fe 02          	cmp    $0x2,%sil
    8155:	0f 84 42 0b 00 00    	je     8c9d <f12+0xf1d>
    815b:	40 80 fe 01          	cmp    $0x1,%sil
    815f:	75 25                	jne    8186 <f12+0x406>
    8161:	8b 71 18             	mov    0x18(%rcx),%esi
    8164:	0f b7 c0             	movzwl %ax,%eax
    8167:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    816a:	48 0f af c6          	imul   %rsi,%rax
    816e:	48 c1 e8 20          	shr    $0x20,%rax
    8172:	48 39 c8             	cmp    %rcx,%rax
    8175:	73 0f                	jae    8186 <f12+0x406>
    8177:	48 01 c2             	add    %rax,%rdx
    817a:	80 3a ff             	cmpb   $0xff,(%rdx)
    817d:	0f 84 ba 0e 00 00    	je     903d <f12+0x12bd>
    8183:	c6 02 01             	movb   $0x1,(%rdx)
    8186:	4d 85 ed             	test   %r13,%r13
    8189:	74 68                	je     81f3 <f12+0x473>
    818b:	4c 89 e1             	mov    %r12,%rcx
    818e:	48 89 ea             	mov    %rbp,%rdx
    8191:	31 c0                	xor    %eax,%eax
    8193:	48 c1 e1 20          	shl    $0x20,%rcx
    8197:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    819e:	00 
    819f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81a6:	00 00 00 00 
    81aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81b1:	00 00 00 00 
    81b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81bc:	00 00 00 00 
    81c0:	48 89 c6             	mov    %rax,%rsi
    81c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    81c8:	48 01 ce             	add    %rcx,%rsi
    81cb:	0f 80 26 0f 00 00    	jo     90f7 <f12+0x1377>
    81d1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    81d6:	48 89 c6             	mov    %rax,%rsi
    81d9:	48 83 c0 01          	add    $0x1,%rax
    81dd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    81e1:	48 c1 e6 04          	shl    $0x4,%rsi
    81e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    81ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    81ee:	4c 39 e8             	cmp    %r13,%rax
    81f1:	72 cd                	jb     81c0 <f12+0x440>
    81f3:	48 8b 03             	mov    (%rbx),%rax
    81f6:	48 d1 e8             	shr    $1,%rax
    81f9:	0f 84 e1 0a 00 00    	je     8ce0 <f12+0xf60>
    81ff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8203:	48 89 d1             	mov    %rdx,%rcx
    8206:	48 c1 e9 3c          	shr    $0x3c,%rcx
    820a:	0f 85 00 0f 00 00    	jne    9110 <f12+0x1390>
    8210:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8214:	48 89 0c 24          	mov    %rcx,(%rsp)
    8218:	48 85 d2             	test   %rdx,%rdx
    821b:	74 41                	je     825e <f12+0x4de>
    821d:	48 c1 e0 04          	shl    $0x4,%rax
    8221:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8225:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    822a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8230:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8235:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8239:	49 83 c6 10          	add    $0x10,%r14
    823d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8241:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8246:	e8 e5 e4 ff ff       	call   6730 <w107>
    824b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8250:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8254:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8259:	4d 39 f5             	cmp    %r14,%r13
    825c:	75 d2                	jne    8230 <f12+0x4b0>
    825e:	48 8b 04 24          	mov    (%rsp),%rax
    8262:	48 89 df             	mov    %rbx,%rdi
    8265:	48 89 03             	mov    %rax,(%rbx)
    8268:	e8 43 e6 ff ff       	call   68b0 <w164.constprop.0>
    826d:	48 89 df             	mov    %rbx,%rdi
    8270:	49 63 dc             	movslq %r12d,%rbx
    8273:	49 89 c5             	mov    %rax,%r13
    8276:	e8 85 f8 ff ff       	call   7b00 <fwp_drop4>
    827b:	48 89 df             	mov    %rbx,%rdi
    827e:	e8 3d cd ff ff       	call   4fc0 <caf61>
    8283:	48 89 04 24          	mov    %rax,(%rsp)
    8287:	e8 a4 c4 ff ff       	call   4730 <fwp_tape_of>
    828c:	48 89 c6             	mov    %rax,%rsi
    828f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8294:	0f 85 f0 0e 00 00    	jne    918a <f12+0x140a>
    829a:	48 89 c7             	mov    %rax,%rdi
    829d:	e8 ee b9 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    82a2:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    82a6:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    82ab:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    82b2:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    82b6:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    82ba:	66 49 0f 6e f8       	movq   %r8,%xmm7
    82bf:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    82c4:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    82c9:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    82cd:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    82d1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    82d7:	77 19                	ja     82f2 <f12+0x572>
    82d9:	41 0f b7 c4          	movzwl %r12w,%eax
    82dd:	83 e8 01             	sub    $0x1,%eax
    82e0:	48 98                	cltq
    82e2:	48 3b 05 0f 7e 01 00 	cmp    0x17e0f(%rip),%rax        # 200f8 <fwp_tape_next_slot>
    82e9:	7d 07                	jge    82f2 <f12+0x572>
    82eb:	48 89 05 06 7e 01 00 	mov    %rax,0x17e06(%rip)        # 200f8 <fwp_tape_next_slot>
    82f2:	48 8b 05 df 21 06 00 	mov    0x621df(%rip),%rax        # 6a4d8 <fwp_cleanups>
    82f9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    82fd:	4c 8d a4 24 b0 00 00 	lea    0xb0(%rsp),%r12
    8304:	00 
    8305:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    830c:	00 
    830d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8311:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8318:	00 
    8319:	48 8d 05 a0 cf ff ff 	lea    -0x3060(%rip),%rax        # 52c0 <fwp_tape_buffers_release>
    8320:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    8327:	00 
    8328:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    832f:	00 
    8330:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8334:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8338:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    833f:	00 
    8340:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8347:	00 
    8348:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    834f:	00 
    8350:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    8357:	00 
    8358:	48 89 05 79 21 06 00 	mov    %rax,0x62179(%rip)        # 6a4d8 <fwp_cleanups>
    835f:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
    8366:	00 
    8367:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    836e:	00 
    836f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    8376:	00 
    8377:	4d 85 ed             	test   %r13,%r13
    837a:	0f 88 10 0a 00 00    	js     8d90 <f12+0x1010>
    8380:	4c 89 e8             	mov    %r13,%rax
    8383:	48 c1 f8 20          	sar    $0x20,%rax
    8387:	48 39 c3             	cmp    %rax,%rbx
    838a:	0f 85 43 0d 00 00    	jne    90d3 <f12+0x1353>
    8390:	45 89 eb             	mov    %r13d,%r11d
    8393:	4c 39 da             	cmp    %r11,%rdx
    8396:	0f 8e 43 0d 00 00    	jle    90df <f12+0x135f>
    839c:	4d 39 de             	cmp    %r11,%r14
    839f:	0f 8e 4b 09 00 00    	jle    8cf0 <f12+0xf70>
    83a5:	4d 39 c6             	cmp    %r8,%r14
    83a8:	0f 8e aa 0a 00 00    	jle    8e58 <f12+0x10d8>
    83ae:	4c 89 f3             	mov    %r14,%rbx
    83b1:	4d 85 c0             	test   %r8,%r8
    83b4:	4c 0f 44 c3          	cmove  %rbx,%r8
    83b8:	eb 1b                	jmp    83d5 <f12+0x655>
    83ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    83c0:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    83c4:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    83cb:	48 89 d8             	mov    %rbx,%rax
    83ce:	48 0f 4c c2          	cmovl  %rdx,%rax
    83d2:	49 89 c0             	mov    %rax,%r8
    83d5:	49 39 d8             	cmp    %rbx,%r8
    83d8:	7c e6                	jl     83c0 <f12+0x640>
    83da:	4d 85 c9             	test   %r9,%r9
    83dd:	0f 84 0d 0b 00 00    	je     8ef0 <f12+0x1170>
    83e3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    83ea:	00 
    83eb:	4c 89 cf             	mov    %r9,%rdi
    83ee:	ba 03 00 00 00       	mov    $0x3,%edx
    83f3:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    83f8:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    83fd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    8402:	e8 e9 cd ff ff       	call   51f0 <ad_raw_realloc>
    8407:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    840c:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    8412:	48 85 c0             	test   %rax,%rax
    8415:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    841b:	49 89 c1             	mov    %rax,%r9
    841e:	0f 84 94 0b 00 00    	je     8fb8 <f12+0x1238>
    8424:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    842b:	00 
    842c:	4c 89 84 24 e0 00 00 	mov    %r8,0xe0(%rsp)
    8433:	00 
    8434:	48 85 db             	test   %rbx,%rbx
    8437:	0f 85 44 0c 00 00    	jne    9081 <f12+0x1301>
    843d:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    8444:	4d 85 ed             	test   %r13,%r13
    8447:	78 14                	js     845d <f12+0x6dd>
    8449:	45 89 eb             	mov    %r13d,%r11d
    844c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    8451:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    8457:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    845d:	49 39 ce             	cmp    %rcx,%r14
    8460:	0f 8f 93 00 00 00    	jg     84f9 <f12+0x779>
    8466:	0f 12 fb             	movhlps %xmm3,%xmm7
    8469:	66 48 0f 7e db       	movq   %xmm3,%rbx
    846e:	66 49 0f 7e d0       	movq   %xmm2,%r8
    8473:	48 89 c8             	mov    %rcx,%rax
    8476:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    847b:	0f 12 fa             	movhlps %xmm2,%xmm7
    847e:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    8482:	4c 29 f0             	sub    %r14,%rax
    8485:	66 49 0f 7e fb       	movq   %xmm7,%r11
    848a:	48 29 f3             	sub    %rsi,%rbx
    848d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8491:	49 8d 14 c3          	lea    (%r11,%rax,8),%rdx
    8495:	4c 29 df             	sub    %r11,%rdi
    8498:	48 8d 04 86          	lea    (%rsi,%rax,4),%rax
    849c:	48 89 d9             	mov    %rbx,%rcx
    849f:	4d 29 d8             	sub    %r11,%r8
    84a2:	eb 08                	jmp    84ac <f12+0x72c>
    84a4:	0f 1f 40 00          	nopl   0x0(%rax)
    84a8:	48 83 e8 04          	sub    $0x4,%rax
    84ac:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    84b1:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    84b5:	7a 02                	jp     84b9 <f12+0x739>
    84b7:	74 37                	je     84f0 <f12+0x770>
    84b9:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    84bd:	45 85 db             	test   %r11d,%r11d
    84c0:	78 16                	js     84d8 <f12+0x758>
    84c2:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    84c8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    84cc:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    84d2:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    84d8:	4c 63 18             	movslq (%rax),%r11
    84db:	45 85 db             	test   %r11d,%r11d
    84de:	78 10                	js     84f0 <f12+0x770>
    84e0:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    84e4:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    84ea:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    84f0:	48 83 ea 08          	sub    $0x8,%rdx
    84f4:	48 39 c6             	cmp    %rax,%rsi
    84f7:	75 af                	jne    84a8 <f12+0x728>
    84f9:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8500:	ff ff 1f 
    8503:	4c 39 f0             	cmp    %r14,%rax
    8506:	0f 82 10 0c 00 00    	jb     911c <f12+0x139c>
    850c:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8513:	00 
    8514:	be 02 00 00 00       	mov    $0x2,%esi
    8519:	4c 89 0c 24          	mov    %r9,(%rsp)
    851d:	e8 4e da ff ff       	call   5f70 <fwp_heap_alloc>
    8522:	4c 8b 0c 24          	mov    (%rsp),%r9
    8526:	4c 89 30             	mov    %r14,(%rax)
    8529:	49 89 c5             	mov    %rax,%r13
    852c:	31 c0                	xor    %eax,%eax
    852e:	4d 85 f6             	test   %r14,%r14
    8531:	74 1f                	je     8552 <f12+0x7d2>
    8533:	66 90                	xchg   %ax,%ax
    8535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    853c:	00 00 00 00 
    8540:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    8544:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8549:	48 83 c0 01          	add    $0x1,%rax
    854d:	49 39 c6             	cmp    %rax,%r14
    8550:	75 ee                	jne    8540 <f12+0x7c0>
    8552:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    8559:	00 
    855a:	4c 89 e7             	mov    %r12,%rdi
    855d:	48 89 0d 74 1f 06 00 	mov    %rcx,0x61f74(%rip)        # 6a4d8 <fwp_cleanups>
    8564:	48 89 0c 24          	mov    %rcx,(%rsp)
    8568:	e8 53 cd ff ff       	call   52c0 <fwp_tape_buffers_release>
    856d:	48 8b 15 a4 16 06 00 	mov    0x616a4(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    8574:	4c 89 e8             	mov    %r13,%rax
    8577:	48 8b 0c 24          	mov    (%rsp),%rcx
    857b:	48 2b 05 6e 16 06 00 	sub    0x6166e(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8582:	48 c1 e2 10          	shl    $0x10,%rdx
    8586:	48 39 d0             	cmp    %rdx,%rax
    8589:	73 57                	jae    85e2 <f12+0x862>
    858b:	48 89 c2             	mov    %rax,%rdx
    858e:	48 c1 ea 10          	shr    $0x10,%rdx
    8592:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8596:	48 8b 15 9b 16 06 00 	mov    0x6169b(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    859d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    85a1:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    85a5:	48 85 db             	test   %rbx,%rbx
    85a8:	74 38                	je     85e2 <f12+0x862>
    85aa:	0f b6 32             	movzbl (%rdx),%esi
    85ad:	40 80 fe 02          	cmp    $0x2,%sil
    85b1:	0f 84 09 08 00 00    	je     8dc0 <f12+0x1040>
    85b7:	40 80 fe 01          	cmp    $0x1,%sil
    85bb:	75 25                	jne    85e2 <f12+0x862>
    85bd:	8b 72 18             	mov    0x18(%rdx),%esi
    85c0:	0f b7 c0             	movzwl %ax,%eax
    85c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85c6:	48 0f af c6          	imul   %rsi,%rax
    85ca:	48 c1 e8 20          	shr    $0x20,%rax
    85ce:	48 39 d0             	cmp    %rdx,%rax
    85d1:	73 0f                	jae    85e2 <f12+0x862>
    85d3:	48 01 c3             	add    %rax,%rbx
    85d6:	80 3b ff             	cmpb   $0xff,(%rbx)
    85d9:	0f 84 73 0a 00 00    	je     9052 <f12+0x12d2>
    85df:	c6 03 01             	movb   $0x1,(%rbx)
    85e2:	4c 39 f9             	cmp    %r15,%rcx
    85e5:	0f 85 60 b1 ff ff    	jne    374b <f12.cold>
    85eb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    85f0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    85f5:	48 89 05 dc 1e 06 00 	mov    %rax,0x61edc(%rip)        # 6a4d8 <fwp_cleanups>
    85fc:	e8 3f ef ff ff       	call   7540 <fwp_tape_scope_release>
    8601:	49 8b 45 00          	mov    0x0(%r13),%rax
    8605:	49 89 c4             	mov    %rax,%r12
    8608:	49 0f ba f4 3f       	btr    $0x3f,%r12
    860d:	48 85 c0             	test   %rax,%rax
    8610:	0f 88 6a 05 00 00    	js     8b80 <f12+0xe00>
    8616:	48 8b 15 fb 15 06 00 	mov    0x615fb(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    861d:	4c 89 e8             	mov    %r13,%rax
    8620:	48 2b 05 c9 15 06 00 	sub    0x615c9(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8627:	48 c1 e2 10          	shl    $0x10,%rdx
    862b:	48 39 d0             	cmp    %rdx,%rax
    862e:	0f 83 4c 05 00 00    	jae    8b80 <f12+0xe00>
    8634:	48 89 c2             	mov    %rax,%rdx
    8637:	48 c1 ea 10          	shr    $0x10,%rdx
    863b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    863f:	48 8b 15 f2 15 06 00 	mov    0x615f2(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8646:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    864a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    864e:	48 85 c9             	test   %rcx,%rcx
    8651:	0f 84 29 05 00 00    	je     8b80 <f12+0xe00>
    8657:	0f b6 32             	movzbl (%rdx),%esi
    865a:	40 80 fe 02          	cmp    $0x2,%sil
    865e:	0f 84 0c 05 00 00    	je     8b70 <f12+0xdf0>
    8664:	40 80 fe 01          	cmp    $0x1,%sil
    8668:	0f 85 12 05 00 00    	jne    8b80 <f12+0xe00>
    866e:	8b 72 18             	mov    0x18(%rdx),%esi
    8671:	0f b7 c0             	movzwl %ax,%eax
    8674:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8677:	48 0f af c6          	imul   %rsi,%rax
    867b:	48 c1 e8 20          	shr    $0x20,%rax
    867f:	48 39 d0             	cmp    %rdx,%rax
    8682:	0f 83 f8 04 00 00    	jae    8b80 <f12+0xe00>
    8688:	48 01 c1             	add    %rax,%rcx
    868b:	80 39 01             	cmpb   $0x1,(%rcx)
    868e:	0f 85 ec 04 00 00    	jne    8b80 <f12+0xe00>
    8694:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    8699:	4d 89 ef             	mov    %r13,%r15
    869c:	31 ff                	xor    %edi,%edi
    869e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    86a3:	f2 0f 10 0d 55 47 00 	movsd  0x4755(%rip),%xmm1        # ce00 <msg.8+0xd0>
    86aa:	00 
    86ab:	48 8d 50 08          	lea    0x8(%rax),%rdx
    86af:	31 c0                	xor    %eax,%eax
    86b1:	4d 85 e4             	test   %r12,%r12
    86b4:	75 2f                	jne    86e5 <f12+0x965>
    86b6:	eb 58                	jmp    8710 <f12+0x990>
    86b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86bf:	00 
    86c0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    86c4:	0f 88 21 0a 00 00    	js     90eb <f12+0x136b>
    86ca:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    86cf:	48 83 c0 01          	add    $0x1,%rax
    86d3:	48 83 c2 08          	add    $0x8,%rdx
    86d7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    86db:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    86e0:	49 39 c4             	cmp    %rax,%r12
    86e3:	74 2b                	je     8710 <f12+0x990>
    86e5:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    86e9:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    86ee:	79 d0                	jns    86c0 <f12+0x940>
    86f0:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    86f4:	eb ca                	jmp    86c0 <f12+0x940>
    86f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    86fd:	00 00 00 
    8700:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8704:	0f 84 f3 f8 ff ff    	je     7ffd <f12+0x27d>
    870a:	e9 e0 f8 ff ff       	jmp    7fef <f12+0x26f>
    870f:	90                   	nop
    8710:	e8 eb f3 ff ff       	call   7b00 <fwp_drop4>
    8715:	48 89 e8             	mov    %rbp,%rax
    8718:	31 d2                	xor    %edx,%edx
    871a:	48 85 ed             	test   %rbp,%rbp
    871d:	0f 84 af 08 00 00    	je     8fd2 <f12+0x1252>
    8723:	66 90                	xchg   %ax,%ax
    8725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    872c:	00 00 00 00 
    8730:	48 8b 40 10          	mov    0x10(%rax),%rax
    8734:	48 83 c2 01          	add    $0x1,%rdx
    8738:	48 85 c0             	test   %rax,%rax
    873b:	75 f3                	jne    8730 <f12+0x9b0>
    873d:	49 8b 07             	mov    (%r15),%rax
    8740:	49 89 c5             	mov    %rax,%r13
    8743:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8748:	48 85 c0             	test   %rax,%rax
    874b:	0f 88 81 03 00 00    	js     8ad2 <f12+0xd52>
    8751:	48 8b 05 c0 14 06 00 	mov    0x614c0(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    8758:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    875d:	48 2b 0d 8c 14 06 00 	sub    0x6148c(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    8764:	48 c1 e0 10          	shl    $0x10,%rax
    8768:	48 39 c1             	cmp    %rax,%rcx
    876b:	0f 83 61 03 00 00    	jae    8ad2 <f12+0xd52>
    8771:	48 89 c8             	mov    %rcx,%rax
    8774:	48 c1 e8 10          	shr    $0x10,%rax
    8778:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    877c:	48 8b 05 b5 14 06 00 	mov    0x614b5(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    8783:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8787:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    878b:	48 85 ff             	test   %rdi,%rdi
    878e:	0f 84 3e 03 00 00    	je     8ad2 <f12+0xd52>
    8794:	0f b6 06             	movzbl (%rsi),%eax
    8797:	3c 02                	cmp    $0x2,%al
    8799:	0f 84 21 03 00 00    	je     8ac0 <f12+0xd40>
    879f:	3c 01                	cmp    $0x1,%al
    87a1:	0f 85 22 03 00 00    	jne    8ac9 <f12+0xd49>
    87a7:	8b 46 18             	mov    0x18(%rsi),%eax
    87aa:	0f b7 c9             	movzwl %cx,%ecx
    87ad:	48 0f af c8          	imul   %rax,%rcx
    87b1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    87b4:	48 c1 e9 20          	shr    $0x20,%rcx
    87b8:	48 39 c1             	cmp    %rax,%rcx
    87bb:	0f 83 08 03 00 00    	jae    8ac9 <f12+0xd49>
    87c1:	48 01 cf             	add    %rcx,%rdi
    87c4:	80 3f 01             	cmpb   $0x1,(%rdi)
    87c7:	0f 85 fc 02 00 00    	jne    8ac9 <f12+0xd49>
    87cd:	49 39 d5             	cmp    %rdx,%r13
    87d0:	48 89 d0             	mov    %rdx,%rax
    87d3:	49 0f 46 c5          	cmovbe %r13,%rax
    87d7:	48 85 c0             	test   %rax,%rax
    87da:	0f 84 1c 09 00 00    	je     90fc <f12+0x137c>
    87e0:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    87e7:	00 
    87e8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    87ec:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    87f1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    87f8:	00 
    87f9:	48 89 e9             	mov    %rbp,%rcx
    87fc:	31 d2                	xor    %edx,%edx
    87fe:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8802:	eb 59                	jmp    885d <f12+0xadd>
    8804:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8809:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8810:	00 00 00 00 
    8814:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    881b:	00 00 00 00 
    881f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8826:	00 00 00 00 
    882a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8831:	00 00 00 00 
    8835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    883c:	00 00 00 00 
    8840:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8845:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    884a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8850:	48 83 c2 08          	add    $0x8,%rdx
    8854:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8858:	49 39 d0             	cmp    %rdx,%r8
    885b:	74 1b                	je     8878 <f12+0xaf8>
    885d:	48 89 fe             	mov    %rdi,%rsi
    8860:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8864:	79 da                	jns    8840 <f12+0xac0>
    8866:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    886b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    886f:	eb cf                	jmp    8840 <f12+0xac0>
    8871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8878:	48 85 ed             	test   %rbp,%rbp
    887b:	0f 84 4a 08 00 00    	je     90cb <f12+0x134b>
    8881:	4c 8b 05 90 13 06 00 	mov    0x61390(%rip),%r8        # 69c18 <fwp_heap+0x13d8>
    8888:	4c 8b 0d 61 13 06 00 	mov    0x61361(%rip),%r9        # 69bf0 <fwp_heap+0x13b0>
    888f:	48 89 e9             	mov    %rbp,%rcx
    8892:	45 31 ed             	xor    %r13d,%r13d
    8895:	4c 8b 15 9c 13 06 00 	mov    0x6139c(%rip),%r10        # 69c38 <fwp_heap+0x13f8>
    889c:	49 c1 e0 10          	shl    $0x10,%r8
    88a0:	eb 1c                	jmp    88be <f12+0xb3e>
    88a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88a8:	49 83 c5 01          	add    $0x1,%r13
    88ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    88b0:	49 39 c5             	cmp    %rax,%r13
    88b3:	0f 83 67 01 00 00    	jae    8a20 <f12+0xca0>
    88b9:	48 85 c9             	test   %rcx,%rcx
    88bc:	74 56                	je     8914 <f12+0xb94>
    88be:	48 89 ca             	mov    %rcx,%rdx
    88c1:	4c 29 ca             	sub    %r9,%rdx
    88c4:	4c 39 c2             	cmp    %r8,%rdx
    88c7:	73 4b                	jae    8914 <f12+0xb94>
    88c9:	48 89 d6             	mov    %rdx,%rsi
    88cc:	48 c1 ee 10          	shr    $0x10,%rsi
    88d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    88d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    88d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    88dc:	48 85 ff             	test   %rdi,%rdi
    88df:	74 33                	je     8914 <f12+0xb94>
    88e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    88e5:	41 80 fb 02          	cmp    $0x2,%r11b
    88e9:	0f 84 19 01 00 00    	je     8a08 <f12+0xc88>
    88ef:	41 80 fb 01          	cmp    $0x1,%r11b
    88f3:	75 1f                	jne    8914 <f12+0xb94>
    88f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    88f9:	0f b7 d2             	movzwl %dx,%edx
    88fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    88ff:	49 0f af d3          	imul   %r11,%rdx
    8903:	48 c1 ea 20          	shr    $0x20,%rdx
    8907:	48 39 f2             	cmp    %rsi,%rdx
    890a:	73 08                	jae    8914 <f12+0xb94>
    890c:	48 01 d7             	add    %rdx,%rdi
    890f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8912:	74 94                	je     88a8 <f12+0xb28>
    8914:	49 39 c5             	cmp    %rax,%r13
    8917:	0f 83 03 01 00 00    	jae    8a20 <f12+0xca0>
    891d:	49 89 c7             	mov    %rax,%r15
    8920:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
    8927:	00 
    8928:	45 31 e4             	xor    %r12d,%r12d
    892b:	48 89 04 24          	mov    %rax,(%rsp)
    892f:	48 8d 1d 0a ff 05 00 	lea    0x5ff0a(%rip),%rbx        # 68840 <fwp_heap>
    8936:	eb 3a                	jmp    8972 <f12+0xbf2>
    8938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    893f:	00 
    8940:	41 80 f9 01          	cmp    $0x1,%r9b
    8944:	75 27                	jne    896d <f12+0xbed>
    8946:	45 8b 48 18          	mov    0x18(%r8),%r9d
    894a:	0f b7 c0             	movzwl %ax,%eax
    894d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8951:	49 0f af c1          	imul   %r9,%rax
    8955:	48 c1 e8 20          	shr    $0x20,%rax
    8959:	4c 39 c0             	cmp    %r8,%rax
    895c:	73 0f                	jae    896d <f12+0xbed>
    895e:	48 01 c7             	add    %rax,%rdi
    8961:	80 3f ff             	cmpb   $0xff,(%rdi)
    8964:	0f 84 46 03 00 00    	je     8cb0 <f12+0xf30>
    896a:	c6 07 01             	movb   $0x1,(%rdi)
    896d:	4d 39 fd             	cmp    %r15,%r13
    8970:	73 7e                	jae    89f0 <f12+0xc70>
    8972:	49 83 ef 01          	sub    $0x1,%r15
    8976:	66 49 0f 6e f4       	movq   %r12,%xmm6
    897b:	48 8b 34 24          	mov    (%rsp),%rsi
    897f:	bf 01 00 00 00       	mov    $0x1,%edi
    8984:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    898a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    898e:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    8995:	00 
    8996:	e8 b5 df ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    899b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    89a2:	49 89 c4             	mov    %rax,%r12
    89a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    89ac:	48 c1 e7 10          	shl    $0x10,%rdi
    89b0:	48 39 f8             	cmp    %rdi,%rax
    89b3:	73 b8                	jae    896d <f12+0xbed>
    89b5:	48 89 c7             	mov    %rax,%rdi
    89b8:	48 c1 ef 10          	shr    $0x10,%rdi
    89bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    89c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    89c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    89cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    89cf:	48 85 ff             	test   %rdi,%rdi
    89d2:	74 99                	je     896d <f12+0xbed>
    89d4:	45 0f b6 08          	movzbl (%r8),%r9d
    89d8:	41 80 f9 02          	cmp    $0x2,%r9b
    89dc:	0f 85 5e ff ff ff    	jne    8940 <f12+0xbc0>
    89e2:	66 85 c0             	test   %ax,%ax
    89e5:	0f 84 76 ff ff ff    	je     8961 <f12+0xbe1>
    89eb:	4d 39 fd             	cmp    %r15,%r13
    89ee:	72 82                	jb     8972 <f12+0xbf2>
    89f0:	4d 85 ed             	test   %r13,%r13
    89f3:	75 2e                	jne    8a23 <f12+0xca3>
    89f5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    89f9:	85 c0                	test   %eax,%eax
    89fb:	4d 0f 45 f5          	cmovne %r13,%r14
    89ff:	eb 6f                	jmp    8a70 <f12+0xcf0>
    8a01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a08:	66 85 d2             	test   %dx,%dx
    8a0b:	0f 84 fe fe ff ff    	je     890f <f12+0xb8f>
    8a11:	49 39 c5             	cmp    %rax,%r13
    8a14:	0f 82 03 ff ff ff    	jb     891d <f12+0xb9d>
    8a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a20:	45 31 e4             	xor    %r12d,%r12d
    8a23:	4c 89 f2             	mov    %r14,%rdx
    8a26:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8a2a:	48 89 e8             	mov    %rbp,%rax
    8a2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a34:	00 
    8a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a3c:	00 00 00 00 
    8a40:	48 8b 0a             	mov    (%rdx),%rcx
    8a43:	48 83 c2 08          	add    $0x8,%rdx
    8a47:	48 89 c7             	mov    %rax,%rdi
    8a4a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8a4e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a52:	49 39 d0             	cmp    %rdx,%r8
    8a55:	75 e9                	jne    8a40 <f12+0xcc0>
    8a57:	8b 54 24 20          	mov    0x20(%rsp),%edx
    8a5b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8a5f:	85 d2                	test   %edx,%edx
    8a61:	0f 84 69 03 00 00    	je     8dd0 <f12+0x1050>
    8a67:	49 89 ec             	mov    %rbp,%r12
    8a6a:	45 31 f6             	xor    %r14d,%r14d
    8a6d:	48 89 c5             	mov    %rax,%rbp
    8a70:	4c 89 f7             	mov    %r14,%rdi
    8a73:	e8 f8 cf ff ff       	call   5a70 <fwp_mem_free>
    8a78:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8a7d:	e8 7e f0 ff ff       	call   7b00 <fwp_drop4>
    8a82:	48 89 ef             	mov    %rbp,%rdi
    8a85:	e8 66 e4 ff ff       	call   6ef0 <fwp_drop0>
    8a8a:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    8a91:	00 
    8a92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a99:	00 00 
    8a9b:	0f 85 e4 06 00 00    	jne    9185 <f12+0x1405>
    8aa1:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    8aa8:	4c 89 e0             	mov    %r12,%rax
    8aab:	5b                   	pop    %rbx
    8aac:	5d                   	pop    %rbp
    8aad:	41 5c                	pop    %r12
    8aaf:	41 5d                	pop    %r13
    8ab1:	41 5e                	pop    %r14
    8ab3:	41 5f                	pop    %r15
    8ab5:	c3                   	ret
    8ab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8abd:	00 00 00 
    8ac0:	66 85 c9             	test   %cx,%cx
    8ac3:	0f 84 fb fc ff ff    	je     87c4 <f12+0xa44>
    8ac9:	48 85 ed             	test   %rbp,%rbp
    8acc:	0f 84 eb 03 00 00    	je     8ebd <f12+0x113d>
    8ad2:	48 89 e8             	mov    %rbp,%rax
    8ad5:	45 31 e4             	xor    %r12d,%r12d
    8ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8adf:	00 
    8ae0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8ae4:	4c 89 e2             	mov    %r12,%rdx
    8ae7:	49 83 c4 01          	add    $0x1,%r12
    8aeb:	48 85 c0             	test   %rax,%rax
    8aee:	75 f0                	jne    8ae0 <f12+0xd60>
    8af0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8af7:	ff ff 1f 
    8afa:	4c 39 e0             	cmp    %r12,%rax
    8afd:	0f 82 0d 06 00 00    	jb     9110 <f12+0x1390>
    8b03:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8b0a:	00 
    8b0b:	be 02 00 00 00       	mov    $0x2,%esi
    8b10:	e8 5b d4 ff ff       	call   5f70 <fwp_heap_alloc>
    8b15:	4d 39 e5             	cmp    %r12,%r13
    8b18:	48 89 ea             	mov    %rbp,%rdx
    8b1b:	49 89 c6             	mov    %rax,%r14
    8b1e:	4c 89 e0             	mov    %r12,%rax
    8b21:	49 0f 46 c5          	cmovbe %r13,%rax
    8b25:	4c 89 f1             	mov    %r14,%rcx
    8b28:	66 90                	xchg   %ax,%ax
    8b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b31:	00 00 00 00 
    8b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b3c:	00 00 00 00 
    8b40:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8b44:	48 83 c1 08          	add    $0x8,%rcx
    8b48:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    8b4c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8b50:	48 85 d2             	test   %rdx,%rdx
    8b53:	75 eb                	jne    8b40 <f12+0xdc0>
    8b55:	48 85 c0             	test   %rax,%rax
    8b58:	0f 84 71 03 00 00    	je     8ecf <f12+0x114f>
    8b5e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    8b65:	00 
    8b66:	e9 81 fc ff ff       	jmp    87ec <f12+0xa6c>
    8b6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b70:	66 85 c0             	test   %ax,%ax
    8b73:	0f 84 12 fb ff ff    	je     868b <f12+0x90b>
    8b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b80:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8b87:	ff ff 1f 
    8b8a:	4c 39 e0             	cmp    %r12,%rax
    8b8d:	0f 82 89 05 00 00    	jb     911c <f12+0x139c>
    8b93:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8b9a:	00 
    8b9b:	be 01 00 00 00       	mov    $0x1,%esi
    8ba0:	e8 cb d3 ff ff       	call   5f70 <fwp_heap_alloc>
    8ba5:	4c 89 20             	mov    %r12,(%rax)
    8ba8:	48 8b 15 69 10 06 00 	mov    0x61069(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    8baf:	49 89 c7             	mov    %rax,%r15
    8bb2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8bb7:	48 2b 05 32 10 06 00 	sub    0x61032(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8bbe:	48 c1 e2 10          	shl    $0x10,%rdx
    8bc2:	48 39 d0             	cmp    %rdx,%rax
    8bc5:	73 57                	jae    8c1e <f12+0xe9e>
    8bc7:	48 89 c2             	mov    %rax,%rdx
    8bca:	48 c1 ea 10          	shr    $0x10,%rdx
    8bce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bd2:	48 8b 15 5f 10 06 00 	mov    0x6105f(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8bd9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8bdd:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8be1:	4d 85 f6             	test   %r14,%r14
    8be4:	74 38                	je     8c1e <f12+0xe9e>
    8be6:	0f b6 0a             	movzbl (%rdx),%ecx
    8be9:	80 f9 02             	cmp    $0x2,%cl
    8bec:	0f 84 ee 02 00 00    	je     8ee0 <f12+0x1160>
    8bf2:	80 f9 01             	cmp    $0x1,%cl
    8bf5:	75 27                	jne    8c1e <f12+0xe9e>
    8bf7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8bfa:	0f b7 c0             	movzwl %ax,%eax
    8bfd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c00:	48 0f af c1          	imul   %rcx,%rax
    8c04:	48 c1 e8 20          	shr    $0x20,%rax
    8c08:	48 39 d0             	cmp    %rdx,%rax
    8c0b:	73 11                	jae    8c1e <f12+0xe9e>
    8c0d:	49 01 c6             	add    %rax,%r14
    8c10:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8c14:	0f 84 4d 04 00 00    	je     9067 <f12+0x12e7>
    8c1a:	41 c6 06 01          	movb   $0x1,(%r14)
    8c1e:	4c 89 ef             	mov    %r13,%rdi
    8c21:	e9 78 fa ff ff       	jmp    869e <f12+0x91e>
    8c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c2d:	00 00 00 
    8c30:	48 c1 e6 10          	shl    $0x10,%rsi
    8c34:	48 09 fe             	or     %rdi,%rsi
    8c37:	bf 08 00 00 00       	mov    $0x8,%edi
    8c3c:	49 89 f4             	mov    %rsi,%r12
    8c3f:	be 02 00 00 00       	mov    $0x2,%esi
    8c44:	e8 27 d3 ff ff       	call   5f70 <fwp_heap_alloc>
    8c49:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8c50:	48 8b 15 c1 0f 06 00 	mov    0x60fc1(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    8c57:	48 89 c3             	mov    %rax,%rbx
    8c5a:	48 2b 05 8f 0f 06 00 	sub    0x60f8f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8c61:	48 c1 e2 10          	shl    $0x10,%rdx
    8c65:	48 39 d0             	cmp    %rdx,%rax
    8c68:	73 76                	jae    8ce0 <f12+0xf60>
    8c6a:	48 89 c2             	mov    %rax,%rdx
    8c6d:	48 c1 ea 10          	shr    $0x10,%rdx
    8c71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c75:	48 8b 15 bc 0f 06 00 	mov    0x60fbc(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8c7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8c80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8c84:	48 85 d2             	test   %rdx,%rdx
    8c87:	0f 84 66 f5 ff ff    	je     81f3 <f12+0x473>
    8c8d:	0f b6 31             	movzbl (%rcx),%esi
    8c90:	45 31 ed             	xor    %r13d,%r13d
    8c93:	40 80 fe 02          	cmp    $0x2,%sil
    8c97:	0f 85 be f4 ff ff    	jne    815b <f12+0x3db>
    8c9d:	66 85 c0             	test   %ax,%ax
    8ca0:	0f 85 e0 f4 ff ff    	jne    8186 <f12+0x406>
    8ca6:	e9 cf f4 ff ff       	jmp    817a <f12+0x3fa>
    8cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cb0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    8cb5:	e8 76 cb ff ff       	call   5830 <fwp_rc_forget_slot>
    8cba:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8cbf:	e9 a6 fc ff ff       	jmp    896a <f12+0xbea>
    8cc4:	0f 1f 40 00          	nopl   0x0(%rax)
    8cc8:	4d 85 ed             	test   %r13,%r13
    8ccb:	0f 85 ba f4 ff ff    	jne    818b <f12+0x40b>
    8cd1:	0f 1f 40 00          	nopl   0x0(%rax)
    8cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cdc:	00 00 00 00 
    8ce0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    8ce7:	00 
    8ce8:	e9 71 f5 ff ff       	jmp    825e <f12+0x4de>
    8ced:	0f 1f 00             	nopl   (%rax)
    8cf0:	49 8d 5b 01          	lea    0x1(%r11),%rbx
    8cf4:	49 39 d8             	cmp    %rbx,%r8
    8cf7:	0f 8c b4 f6 ff ff    	jl     83b1 <f12+0x631>
    8cfd:	4d 85 c9             	test   %r9,%r9
    8d00:	0f 84 22 04 00 00    	je     9128 <f12+0x13a8>
    8d06:	4c 89 cf             	mov    %r9,%rdi
    8d09:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8d10:	00 
    8d11:	31 f6                	xor    %esi,%esi
    8d13:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
    8d18:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
    8d1d:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8d22:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8d27:	e8 84 a7 ff ff       	call   34b0 <memset@plt>
    8d2c:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8d32:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8d38:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    8d3d:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    8d42:	49 89 c1             	mov    %rax,%r9
    8d45:	e9 02 f7 ff ff       	jmp    844c <f12+0x6cc>
    8d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d50:	48 8d 3d c9 e6 ff ff 	lea    -0x1937(%rip),%rdi        # 7420 <fwp_tape_finish>
    8d57:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8d5c:	e8 af 31 00 00       	call   bf10 <atexit>
    8d61:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8d66:	85 c0                	test   %eax,%eax
    8d68:	0f 85 d1 03 00 00    	jne    913f <f12+0x13bf>
    8d6e:	c7 05 e8 72 00 00 01 	movl   $0x1,0x72e8(%rip)        # 10060 <registered_finish.0>
    8d75:	00 00 00 
    8d78:	e9 40 f1 ff ff       	jmp    7ebd <f12+0x13d>
    8d7d:	0f 1f 00             	nopl   (%rax)
    8d80:	66 85 c0             	test   %ax,%ax
    8d83:	0f 85 e5 f0 ff ff    	jne    7e6e <f12+0xee>
    8d89:	e9 bc f0 ff ff       	jmp    7e4a <f12+0xca>
    8d8e:	66 90                	xchg   %ax,%ax
    8d90:	4d 39 c6             	cmp    %r8,%r14
    8d93:	0f 8f 15 f6 ff ff    	jg     83ae <f12+0x62e>
    8d99:	4d 85 f6             	test   %r14,%r14
    8d9c:	74 12                	je     8db0 <f12+0x1030>
    8d9e:	4d 85 c9             	test   %r9,%r9
    8da1:	0f 84 81 03 00 00    	je     9128 <f12+0x13a8>
    8da7:	4d 85 f6             	test   %r14,%r14
    8daa:	0f 85 ce 02 00 00    	jne    907e <f12+0x12fe>
    8db0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    8db7:	e9 a1 f6 ff ff       	jmp    845d <f12+0x6dd>
    8dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8dc0:	66 85 c0             	test   %ax,%ax
    8dc3:	0f 85 19 f8 ff ff    	jne    85e2 <f12+0x862>
    8dc9:	e9 08 f8 ff ff       	jmp    85d6 <f12+0x856>
    8dce:	66 90                	xchg   %ax,%ax
    8dd0:	49 89 ec             	mov    %rbp,%r12
    8dd3:	48 89 c5             	mov    %rax,%rbp
    8dd6:	e9 95 fc ff ff       	jmp    8a70 <f12+0xcf0>
    8ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8de0:	66 0f 6f 0d d8 72 01 	movdqa 0x172d8(%rip),%xmm1        # 200c0 <fwp_tape_workspace>
    8de7:	00 
    8de8:	48 c7 05 b5 72 01 00 	movq   $0x0,0x172b5(%rip)        # 200a8 <fwp_tape_cached_bytes>
    8def:	00 00 00 00 
    8df3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8df9:	48 8b 05 e0 72 01 00 	mov    0x172e0(%rip),%rax        # 200e0 <fwp_tape_workspace+0x20>
    8e00:	66 0f 6f 0d c8 72 01 	movdqa 0x172c8(%rip),%xmm1        # 200d0 <fwp_tape_workspace+0x10>
    8e07:	00 
    8e08:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8e0d:	48 8b 05 d4 72 01 00 	mov    0x172d4(%rip),%rax        # 200e8 <fwp_tape_workspace+0x28>
    8e14:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8e1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8e1e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8e23:	48 8b 05 c6 72 01 00 	mov    0x172c6(%rip),%rax        # 200f0 <fwp_tape_workspace+0x30>
    8e2a:	0f 29 0d 8f 72 01 00 	movaps %xmm1,0x1728f(%rip)        # 200c0 <fwp_tape_workspace>
    8e31:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8e36:	0f 29 0d 93 72 01 00 	movaps %xmm1,0x17293(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    8e3d:	48 c7 05 a8 72 01 00 	movq   $0x0,0x172a8(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    8e44:	00 00 00 00 
    8e48:	0f 29 0d 91 72 01 00 	movaps %xmm1,0x17291(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    8e4f:	e9 a9 f1 ff ff       	jmp    7ffd <f12+0x27d>
    8e54:	0f 1f 40 00          	nopl   0x0(%rax)
    8e58:	4d 85 c9             	test   %r9,%r9
    8e5b:	0f 84 c7 02 00 00    	je     9128 <f12+0x13a8>
    8e61:	49 8d 4e ff          	lea    -0x1(%r14),%rcx
    8e65:	4c 89 cf             	mov    %r9,%rdi
    8e68:	31 f6                	xor    %esi,%esi
    8e6a:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
    8e6f:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8e76:	00 
    8e77:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    8e7c:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    8e81:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    8e86:	e8 25 a6 ff ff       	call   34b0 <memset@plt>
    8e8b:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    8e90:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    8e96:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    8e9c:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
    8ea1:	49 89 c1             	mov    %rax,%r9
    8ea4:	e9 a3 f5 ff ff       	jmp    844c <f12+0x6cc>
    8ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8eb0:	48 83 05 38 16 06 00 	addq   $0x1,0x61638(%rip)        # 6a4f0 <iteration_retains>
    8eb7:	01 
    8eb8:	e9 a4 ef ff ff       	jmp    7e61 <f12+0xe1>
    8ebd:	be 02 00 00 00       	mov    $0x2,%esi
    8ec2:	bf 08 00 00 00       	mov    $0x8,%edi
    8ec7:	e8 a4 d0 ff ff       	call   5f70 <fwp_heap_alloc>
    8ecc:	49 89 c6             	mov    %rax,%r14
    8ecf:	45 31 e4             	xor    %r12d,%r12d
    8ed2:	e9 99 fb ff ff       	jmp    8a70 <f12+0xcf0>
    8ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ede:	00 00 
    8ee0:	66 85 c0             	test   %ax,%ax
    8ee3:	0f 85 35 fd ff ff    	jne    8c1e <f12+0xe9e>
    8ee9:	e9 22 fd ff ff       	jmp    8c10 <f12+0xe90>
    8eee:	66 90                	xchg   %ax,%ax
    8ef0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8ef7:	ff ff 1f 
    8efa:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    8efe:	48 39 c2             	cmp    %rax,%rdx
    8f01:	0f 82 66 02 00 00    	jb     916d <f12+0x13ed>
    8f07:	48 8d 05 d2 72 04 00 	lea    0x472d2(%rip),%rax        # 501e0 <ad_raw_blocks>
    8f0e:	31 d2                	xor    %edx,%edx
    8f10:	eb 23                	jmp    8f35 <f12+0x11b5>
    8f12:	0f 1f 00             	nopl   (%rax)
    8f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f1c:	00 00 00 00 
    8f20:	48 83 c2 01          	add    $0x1,%rdx
    8f24:	48 83 c0 18          	add    $0x18,%rax
    8f28:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    8f2f:	0f 84 8a 01 00 00    	je     90bf <f12+0x133f>
    8f35:	48 83 38 00          	cmpq   $0x0,(%rax)
    8f39:	75 e5                	jne    8f20 <f12+0x11a0>
    8f3b:	4c 89 c7             	mov    %r8,%rdi
    8f3e:	be 08 00 00 00       	mov    $0x8,%esi
    8f43:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    8f48:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8f4d:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    8f52:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    8f57:	e8 b4 a5 ff ff       	call   3510 <calloc@plt>
    8f5c:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8f61:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    8f66:	48 8d 0d 73 72 04 00 	lea    0x47273(%rip),%rcx        # 501e0 <ad_raw_blocks>
    8f6d:	48 85 c0             	test   %rax,%rax
    8f70:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    8f76:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    8f7c:	74 3a                	je     8fb8 <f12+0x1238>
    8f7e:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    8f82:	48 89 c6             	mov    %rax,%rsi
    8f85:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    8f8a:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    8f8e:	b9 03 00 00 00       	mov    $0x3,%ecx
    8f93:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8f98:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    8f9f:	00 
    8fa0:	e8 5b ac ff ff       	call   3c00 <ad_raw_record>
    8fa5:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    8faa:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    8faf:	e9 70 f4 ff ff       	jmp    8424 <f12+0x6a4>
    8fb4:	0f 1f 40 00          	nopl   0x0(%rax)
    8fb8:	48 85 db             	test   %rbx,%rbx
    8fbb:	0f 85 67 01 00 00    	jne    9128 <f12+0x13a8>
    8fc1:	45 31 c9             	xor    %r9d,%r9d
    8fc4:	e9 74 f4 ff ff       	jmp    843d <f12+0x6bd>
    8fc9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8fcd:	e9 dd ee ff ff       	jmp    7eaf <f12+0x12f>
    8fd2:	49 8b 07             	mov    (%r15),%rax
    8fd5:	48 85 c0             	test   %rax,%rax
    8fd8:	0f 88 df fe ff ff    	js     8ebd <f12+0x113d>
    8fde:	48 8b 35 33 0c 06 00 	mov    0x60c33(%rip),%rsi        # 69c18 <fwp_heap+0x13d8>
    8fe5:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8fea:	48 2b 0d ff 0b 06 00 	sub    0x60bff(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    8ff1:	48 c1 e6 10          	shl    $0x10,%rsi
    8ff5:	48 39 f1             	cmp    %rsi,%rcx
    8ff8:	0f 83 bf fe ff ff    	jae    8ebd <f12+0x113d>
    8ffe:	48 89 ce             	mov    %rcx,%rsi
    9001:	48 c1 ee 10          	shr    $0x10,%rsi
    9005:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9009:	48 8b 35 28 0c 06 00 	mov    0x60c28(%rip),%rsi        # 69c38 <fwp_heap+0x13f8>
    9010:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9014:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9018:	48 85 ff             	test   %rdi,%rdi
    901b:	0f 84 9c fe ff ff    	je     8ebd <f12+0x113d>
    9021:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9026:	49 89 c5             	mov    %rax,%r13
    9029:	e9 66 f7 ff ff       	jmp    8794 <f12+0xa14>
    902e:	be 68 00 00 00       	mov    $0x68,%esi
    9033:	bb 01 00 00 00       	mov    $0x1,%ebx
    9038:	e9 fd ee ff ff       	jmp    7f3a <f12+0x1ba>
    903d:	48 89 d7             	mov    %rdx,%rdi
    9040:	48 89 14 24          	mov    %rdx,(%rsp)
    9044:	e8 e7 c7 ff ff       	call   5830 <fwp_rc_forget_slot>
    9049:	48 8b 14 24          	mov    (%rsp),%rdx
    904d:	e9 31 f1 ff ff       	jmp    8183 <f12+0x403>
    9052:	48 89 df             	mov    %rbx,%rdi
    9055:	48 89 0c 24          	mov    %rcx,(%rsp)
    9059:	e8 d2 c7 ff ff       	call   5830 <fwp_rc_forget_slot>
    905e:	48 8b 0c 24          	mov    (%rsp),%rcx
    9062:	e9 78 f5 ff ff       	jmp    85df <f12+0x85f>
    9067:	4c 89 f7             	mov    %r14,%rdi
    906a:	e8 c1 c7 ff ff       	call   5830 <fwp_rc_forget_slot>
    906f:	e9 a6 fb ff ff       	jmp    8c1a <f12+0xe9a>
    9074:	e8 97 c6 ff ff       	call   5710 <fwp_rc_wide_dup>
    9079:	e9 f0 ed ff ff       	jmp    7e6e <f12+0xee>
    907e:	4c 89 f3             	mov    %r14,%rbx
    9081:	48 8d 4b ff          	lea    -0x1(%rbx),%rcx
    9085:	4c 89 cf             	mov    %r9,%rdi
    9088:	31 f6                	xor    %esi,%esi
    908a:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    908f:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9096:	00 
    9097:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    909c:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    90a1:	e8 0a a4 ff ff       	call   34b0 <memset@plt>
    90a6:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    90ab:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    90b1:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    90b7:	49 89 c1             	mov    %rax,%r9
    90ba:	e9 85 f3 ff ff       	jmp    8444 <f12+0x6c4>
    90bf:	48 8d 3d 4c 30 00 00 	lea    0x304c(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    90c6:	e8 35 af ff ff       	call   4000 <ad_raw_fail>
    90cb:	45 31 ed             	xor    %r13d,%r13d
    90ce:	e9 4a f8 ff ff       	jmp    891d <f12+0xb9d>
    90d3:	48 8d 3d 2e 39 00 00 	lea    0x392e(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    90da:	e8 71 b3 ff ff       	call   4450 <fwp_trap>
    90df:	48 8d 3d dc 30 00 00 	lea    0x30dc(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    90e6:	e8 65 b3 ff ff       	call   4450 <fwp_trap>
    90eb:	48 8d 3d 1e 3a 00 00 	lea    0x3a1e(%rip),%rdi        # cb10 <_IO_stdin_used+0xb10>
    90f2:	e8 59 b3 ff ff       	call   4450 <fwp_trap>
    90f7:	e8 04 a6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    90fc:	45 31 f6             	xor    %r14d,%r14d
    90ff:	e9 cb fd ff ff       	jmp    8ecf <f12+0x114f>
    9104:	48 8d 3d e0 30 00 00 	lea    0x30e0(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    910b:	e8 40 b3 ff ff       	call   4450 <fwp_trap>
    9110:	48 8d 3d ee 30 00 00 	lea    0x30ee(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    9117:	e8 34 b3 ff ff       	call   4450 <fwp_trap>
    911c:	48 8d 3d 0c 31 00 00 	lea    0x310c(%rip),%rdi        # c22f <_IO_stdin_used+0x22f>
    9123:	e8 28 b3 ff ff       	call   4450 <fwp_trap>
    9128:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    912f:	00 
    9130:	4c 89 e7             	mov    %r12,%rdi
    9133:	48 89 05 9e 13 06 00 	mov    %rax,0x6139e(%rip)        # 6a4d8 <fwp_cleanups>
    913a:	e8 81 c1 ff ff       	call   52c0 <fwp_tape_buffers_release>
    913f:	48 8b 0d fa 6e 00 00 	mov    0x6efa(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    9146:	ba 13 00 00 00       	mov    $0x13,%edx
    914b:	be 01 00 00 00       	mov    $0x1,%esi
    9150:	48 8d 3d b1 2e 00 00 	lea    0x2eb1(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    9157:	e8 04 a5 ff ff       	call   3660 <fwrite@plt>
    915c:	31 ff                	xor    %edi,%edi
    915e:	e8 3d a4 ff ff       	call   35a0 <fflush@plt>
    9163:	bf 66 00 00 00       	mov    $0x66,%edi
    9168:	e8 13 a5 ff ff       	call   3680 <_Exit@plt>
    916d:	48 8d 3d 9f 30 00 00 	lea    0x309f(%rip),%rdi        # c213 <_IO_stdin_used+0x213>
    9174:	e8 87 ae ff ff       	call   4000 <ad_raw_fail>
    9179:	48 8d 3d 30 39 00 00 	lea    0x3930(%rip),%rdi        # cab0 <_IO_stdin_used+0xab0>
    9180:	e8 cb b2 ff ff       	call   4450 <fwp_trap>
    9185:	e8 c6 a2 ff ff       	call   3450 <__stack_chk_fail@plt>
    918a:	48 8d 3d bf 38 00 00 	lea    0x38bf(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    9191:	e8 ba b2 ff ff       	call   4450 <fwp_trap>
    9196:	48 8d 3d 43 39 00 00 	lea    0x3943(%rip),%rdi        # cae0 <_IO_stdin_used+0xae0>
    919d:	e8 ae b2 ff ff       	call   4450 <fwp_trap>
    91a2:	0f 1f 00             	nopl   (%rax)
    91a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91ac:	00 00 00 00 

00000000000091b0 <fwp_owned_entry12>:
    91b0:	f3 0f 1e fa          	endbr64
    91b4:	48 8b 3f             	mov    (%rdi),%rdi
    91b7:	e9 c4 eb ff ff       	jmp    7d80 <f12>
    91bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000091c0 <e12>:
    91c0:	f3 0f 1e fa          	endbr64
    91c4:	53                   	push   %rbx
    91c5:	48 8b 1f             	mov    (%rdi),%rbx
    91c8:	48 89 df             	mov    %rbx,%rdi
    91cb:	e8 70 d9 ff ff       	call   6b40 <fwp_rc_share>
    91d0:	48 89 df             	mov    %rbx,%rdi
    91d3:	e8 a8 eb ff ff       	call   7d80 <f12>
    91d8:	48 89 c3             	mov    %rax,%rbx
    91db:	48 89 c7             	mov    %rax,%rdi
    91de:	e8 5d d9 ff ff       	call   6b40 <fwp_rc_share>
    91e3:	48 89 d8             	mov    %rbx,%rax
    91e6:	5b                   	pop    %rbx
    91e7:	c3                   	ret
    91e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91ef:	00 

00000000000091f0 <fwp_drop2>:
    91f0:	48 8b 0d 21 0a 06 00 	mov    0x60a21(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    91f7:	48 89 f8             	mov    %rdi,%rax
    91fa:	48 2b 05 ef 09 06 00 	sub    0x609ef(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    9201:	48 c1 e1 10          	shl    $0x10,%rcx
    9205:	48 39 c8             	cmp    %rcx,%rax
    9208:	0f 83 42 01 00 00    	jae    9350 <fwp_drop2+0x160>
    920e:	48 83 ec 18          	sub    $0x18,%rsp
    9212:	48 89 fa             	mov    %rdi,%rdx
    9215:	4c 8d 05 24 f6 05 00 	lea    0x5f624(%rip),%r8        # 68840 <fwp_heap>
    921c:	48 89 c1             	mov    %rax,%rcx
    921f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9226:	48 c1 e9 10          	shr    $0x10,%rcx
    922a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    922e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9232:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9236:	48 85 c9             	test   %rcx,%rcx
    9239:	74 40                	je     927b <fwp_drop2+0x8b>
    923b:	0f b6 3e             	movzbl (%rsi),%edi
    923e:	40 80 ff 02          	cmp    $0x2,%dil
    9242:	74 3c                	je     9280 <fwp_drop2+0x90>
    9244:	40 80 ff 01          	cmp    $0x1,%dil
    9248:	75 31                	jne    927b <fwp_drop2+0x8b>
    924a:	8b 7e 18             	mov    0x18(%rsi),%edi
    924d:	0f b7 c0             	movzwl %ax,%eax
    9250:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9253:	48 0f af c7          	imul   %rdi,%rax
    9257:	48 c1 e8 20          	shr    $0x20,%rax
    925b:	48 39 f0             	cmp    %rsi,%rax
    925e:	73 1b                	jae    927b <fwp_drop2+0x8b>
    9260:	48 01 c1             	add    %rax,%rcx
    9263:	0f b6 01             	movzbl (%rcx),%eax
    9266:	84 c0                	test   %al,%al
    9268:	74 11                	je     927b <fwp_drop2+0x8b>
    926a:	3c 01                	cmp    $0x1,%al
    926c:	74 22                	je     9290 <fwp_drop2+0xa0>
    926e:	3c ff                	cmp    $0xff,%al
    9270:	0f 84 0a 01 00 00    	je     9380 <fwp_drop2+0x190>
    9276:	83 e8 01             	sub    $0x1,%eax
    9279:	88 01                	mov    %al,(%rcx)
    927b:	48 83 c4 18          	add    $0x18,%rsp
    927f:	c3                   	ret
    9280:	66 85 c0             	test   %ax,%ax
    9283:	74 de                	je     9263 <fwp_drop2+0x73>
    9285:	48 83 c4 18          	add    $0x18,%rsp
    9289:	c3                   	ret
    928a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9290:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9294:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    929b:	48 89 f8             	mov    %rdi,%rax
    929e:	48 c1 e1 10          	shl    $0x10,%rcx
    92a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    92a9:	48 39 c8             	cmp    %rcx,%rax
    92ac:	73 62                	jae    9310 <fwp_drop2+0x120>
    92ae:	48 89 c1             	mov    %rax,%rcx
    92b1:	48 c1 e9 10          	shr    $0x10,%rcx
    92b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    92b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    92bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    92c1:	48 85 c9             	test   %rcx,%rcx
    92c4:	74 4a                	je     9310 <fwp_drop2+0x120>
    92c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    92ca:	41 80 f9 02          	cmp    $0x2,%r9b
    92ce:	0f 84 9c 00 00 00    	je     9370 <fwp_drop2+0x180>
    92d4:	41 80 f9 01          	cmp    $0x1,%r9b
    92d8:	75 36                	jne    9310 <fwp_drop2+0x120>
    92da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    92de:	0f b7 c0             	movzwl %ax,%eax
    92e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    92e4:	49 0f af c1          	imul   %r9,%rax
    92e8:	48 c1 e8 20          	shr    $0x20,%rax
    92ec:	48 39 f0             	cmp    %rsi,%rax
    92ef:	73 1f                	jae    9310 <fwp_drop2+0x120>
    92f1:	48 01 c1             	add    %rax,%rcx
    92f4:	0f b6 01             	movzbl (%rcx),%eax
    92f7:	84 c0                	test   %al,%al
    92f9:	74 15                	je     9310 <fwp_drop2+0x120>
    92fb:	3c 01                	cmp    $0x1,%al
    92fd:	74 59                	je     9358 <fwp_drop2+0x168>
    92ff:	3c ff                	cmp    $0xff,%al
    9301:	0f 84 ff 00 00 00    	je     9406 <fwp_drop2+0x216>
    9307:	83 e8 01             	sub    $0x1,%eax
    930a:	88 01                	mov    %al,(%rcx)
    930c:	0f 1f 40 00          	nopl   0x0(%rax)
    9310:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9314:	48 89 d7             	mov    %rdx,%rdi
    9317:	48 89 0c 24          	mov    %rcx,(%rsp)
    931b:	e8 a0 d8 ff ff       	call   6bc0 <fwp_rc_free_arr>
    9320:	4c 8d 05 19 f5 05 00 	lea    0x5f519(%rip),%r8        # 68840 <fwp_heap>
    9327:	48 8b 04 24          	mov    (%rsp),%rax
    932b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9332:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9339:	48 c1 e2 10          	shl    $0x10,%rdx
    933d:	48 39 d0             	cmp    %rdx,%rax
    9340:	0f 83 35 ff ff ff    	jae    927b <fwp_drop2+0x8b>
    9346:	48 8b 14 24          	mov    (%rsp),%rdx
    934a:	e9 cd fe ff ff       	jmp    921c <fwp_drop2+0x2c>
    934f:	90                   	nop
    9350:	c3                   	ret
    9351:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9358:	48 89 14 24          	mov    %rdx,(%rsp)
    935c:	e8 5f d8 ff ff       	call   6bc0 <fwp_rc_free_arr>
    9361:	48 8b 14 24          	mov    (%rsp),%rdx
    9365:	eb a9                	jmp    9310 <fwp_drop2+0x120>
    9367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    936e:	00 00 
    9370:	66 85 c0             	test   %ax,%ax
    9373:	75 9b                	jne    9310 <fwp_drop2+0x120>
    9375:	e9 7a ff ff ff       	jmp    92f4 <fwp_drop2+0x104>
    937a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9380:	48 89 c8             	mov    %rcx,%rax
    9383:	48 c1 e8 11          	shr    $0x11,%rax
    9387:	48 31 c8             	xor    %rcx,%rax
    938a:	48 89 c2             	mov    %rax,%rdx
    938d:	48 c1 ea 09          	shr    $0x9,%rdx
    9391:	48 31 d0             	xor    %rdx,%rax
    9394:	0f b6 d0             	movzbl %al,%edx
    9397:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    939e:	00 
    939f:	48 85 c0             	test   %rax,%rax
    93a2:	75 29                	jne    93cd <fwp_drop2+0x1dd>
    93a4:	e9 e3 00 00 00       	jmp    948c <fwp_drop2+0x29c>
    93a9:	90                   	nop
    93aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93b1:	00 00 00 00 
    93b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93bc:	00 00 00 00 
    93c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    93c4:	48 85 c0             	test   %rax,%rax
    93c7:	0f 84 bf 00 00 00    	je     948c <fwp_drop2+0x29c>
    93cd:	48 89 c2             	mov    %rax,%rdx
    93d0:	48 39 08             	cmp    %rcx,(%rax)
    93d3:	75 eb                	jne    93c0 <fwp_drop2+0x1d0>
    93d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    93d9:	48 83 ea 01          	sub    $0x1,%rdx
    93dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    93e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    93e8:	0f 85 8d fe ff ff    	jne    927b <fwp_drop2+0x8b>
    93ee:	48 89 cf             	mov    %rcx,%rdi
    93f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    93f5:	e8 36 c4 ff ff       	call   5830 <fwp_rc_forget_slot>
    93fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    93fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    9401:	e9 75 fe ff ff       	jmp    927b <fwp_drop2+0x8b>
    9406:	48 89 ce             	mov    %rcx,%rsi
    9409:	48 c1 ee 11          	shr    $0x11,%rsi
    940d:	48 31 ce             	xor    %rcx,%rsi
    9410:	48 89 f0             	mov    %rsi,%rax
    9413:	48 c1 e8 09          	shr    $0x9,%rax
    9417:	48 31 c6             	xor    %rax,%rsi
    941a:	40 0f b6 f6          	movzbl %sil,%esi
    941e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9425:	00 
    9426:	48 85 c0             	test   %rax,%rax
    9429:	75 1e                	jne    9449 <fwp_drop2+0x259>
    942b:	eb 5f                	jmp    948c <fwp_drop2+0x29c>
    942d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9434:	00 
    9435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    943c:	00 00 00 00 
    9440:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9444:	48 85 c0             	test   %rax,%rax
    9447:	74 43                	je     948c <fwp_drop2+0x29c>
    9449:	48 89 c6             	mov    %rax,%rsi
    944c:	48 39 08             	cmp    %rcx,(%rax)
    944f:	75 ef                	jne    9440 <fwp_drop2+0x250>
    9451:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9455:	48 83 ee 01          	sub    $0x1,%rsi
    9459:	48 89 70 08          	mov    %rsi,0x8(%rax)
    945d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9464:	0f 85 a6 fe ff ff    	jne    9310 <fwp_drop2+0x120>
    946a:	48 89 cf             	mov    %rcx,%rdi
    946d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9472:	48 89 0c 24          	mov    %rcx,(%rsp)
    9476:	e8 b5 c3 ff ff       	call   5830 <fwp_rc_forget_slot>
    947b:	48 8b 0c 24          	mov    (%rsp),%rcx
    947f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9484:	c6 01 fe             	movb   $0xfe,(%rcx)
    9487:	e9 84 fe ff ff       	jmp    9310 <fwp_drop2+0x120>
    948c:	48 8d 3d 4d 35 00 00 	lea    0x354d(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    9493:	e8 b8 af ff ff       	call   4450 <fwp_trap>
    9498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    949f:	00 

00000000000094a0 <fwp_arg_drop23>:
    94a0:	f3 0f 1e fa          	endbr64
    94a4:	85 f6                	test   %esi,%esi
    94a6:	75 04                	jne    94ac <fwp_arg_drop23+0xc>
    94a8:	85 d2                	test   %edx,%edx
    94aa:	75 04                	jne    94b0 <fwp_arg_drop23+0x10>
    94ac:	c3                   	ret
    94ad:	0f 1f 00             	nopl   (%rax)
    94b0:	48 8b 3f             	mov    (%rdi),%rdi
    94b3:	e9 38 fd ff ff       	jmp    91f0 <fwp_drop2>
    94b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    94bf:	00 

00000000000094c0 <f23>:
    94c0:	41 57                	push   %r15
    94c2:	41 56                	push   %r14
    94c4:	41 55                	push   %r13
    94c6:	41 54                	push   %r12
    94c8:	55                   	push   %rbp
    94c9:	53                   	push   %rbx
    94ca:	48 83 ec 38          	sub    $0x38,%rsp
    94ce:	48 8b 15 43 07 06 00 	mov    0x60743(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    94d5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    94da:	48 c1 e2 10          	shl    $0x10,%rdx
    94de:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    94e5:	00 00 
    94e7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    94ec:	48 8b 0d fd 06 06 00 	mov    0x606fd(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    94f3:	48 85 ff             	test   %rdi,%rdi
    94f6:	0f 84 1e 03 00 00    	je     981a <f23+0x35a>
    94fc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9501:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9505:	4c 89 e8             	mov    %r13,%rax
    9508:	48 29 c8             	sub    %rcx,%rax
    950b:	48 39 d0             	cmp    %rdx,%rax
    950e:	0f 83 ec 02 00 00    	jae    9800 <f23+0x340>
    9514:	48 89 c2             	mov    %rax,%rdx
    9517:	48 c1 ea 10          	shr    $0x10,%rdx
    951b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    951f:	48 8b 15 12 07 06 00 	mov    0x60712(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9526:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    952a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    952e:	48 85 ff             	test   %rdi,%rdi
    9531:	0f 84 c9 02 00 00    	je     9800 <f23+0x340>
    9537:	0f b6 0a             	movzbl (%rdx),%ecx
    953a:	80 f9 02             	cmp    $0x2,%cl
    953d:	0f 84 4d 02 00 00    	je     9790 <f23+0x2d0>
    9543:	80 f9 01             	cmp    $0x1,%cl
    9546:	75 24                	jne    956c <f23+0xac>
    9548:	8b 4a 18             	mov    0x18(%rdx),%ecx
    954b:	0f b7 c0             	movzwl %ax,%eax
    954e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9551:	48 0f af c1          	imul   %rcx,%rax
    9555:	48 c1 e8 20          	shr    $0x20,%rax
    9559:	48 39 d0             	cmp    %rdx,%rax
    955c:	73 0e                	jae    956c <f23+0xac>
    955e:	48 01 c7             	add    %rax,%rdi
    9561:	0f b6 07             	movzbl (%rdi),%eax
    9564:	84 c0                	test   %al,%al
    9566:	0f 85 44 02 00 00    	jne    97b0 <f23+0x2f0>
    956c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9571:	48 8b 40 10          	mov    0x10(%rax),%rax
    9575:	ba 01 00 00 00       	mov    $0x1,%edx
    957a:	48 85 c0             	test   %rax,%rax
    957d:	74 0e                	je     958d <f23+0xcd>
    957f:	90                   	nop
    9580:	48 8b 40 10          	mov    0x10(%rax),%rax
    9584:	48 83 c2 01          	add    $0x1,%rdx
    9588:	48 85 c0             	test   %rax,%rax
    958b:	75 f3                	jne    9580 <f23+0xc0>
    958d:	4d 85 ed             	test   %r13,%r13
    9590:	0f 84 9a 02 00 00    	je     9830 <f23+0x370>
    9596:	4c 89 e8             	mov    %r13,%rax
    9599:	31 db                	xor    %ebx,%ebx
    959b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    95a4:	48 83 c3 01          	add    $0x1,%rbx
    95a8:	48 85 c0             	test   %rax,%rax
    95ab:	75 f3                	jne    95a0 <f23+0xe0>
    95ad:	48 39 d3             	cmp    %rdx,%rbx
    95b0:	48 0f 47 da          	cmova  %rdx,%rbx
    95b4:	48 89 d8             	mov    %rbx,%rax
    95b7:	48 c1 e8 3c          	shr    $0x3c,%rax
    95bb:	0f 85 7d 03 00 00    	jne    993e <f23+0x47e>
    95c1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    95c5:	be 02 00 00 00       	mov    $0x2,%esi
    95ca:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    95d1:	00 
    95d2:	e8 99 c9 ff ff       	call   5f70 <fwp_heap_alloc>
    95d7:	48 89 28             	mov    %rbp,(%rax)
    95da:	48 8b 15 37 06 06 00 	mov    0x60637(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    95e1:	49 89 c4             	mov    %rax,%r12
    95e4:	48 2b 05 05 06 06 00 	sub    0x60605(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    95eb:	48 c1 e2 10          	shl    $0x10,%rdx
    95ef:	48 39 d0             	cmp    %rdx,%rax
    95f2:	73 57                	jae    964b <f23+0x18b>
    95f4:	48 89 c2             	mov    %rax,%rdx
    95f7:	48 c1 ea 10          	shr    $0x10,%rdx
    95fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95ff:	48 8b 15 32 06 06 00 	mov    0x60632(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9606:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    960a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    960e:	48 85 ed             	test   %rbp,%rbp
    9611:	74 38                	je     964b <f23+0x18b>
    9613:	0f b6 0a             	movzbl (%rdx),%ecx
    9616:	80 f9 02             	cmp    $0x2,%cl
    9619:	0f 84 d1 01 00 00    	je     97f0 <f23+0x330>
    961f:	80 f9 01             	cmp    $0x1,%cl
    9622:	75 27                	jne    964b <f23+0x18b>
    9624:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9627:	0f b7 c0             	movzwl %ax,%eax
    962a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    962d:	48 0f af c1          	imul   %rcx,%rax
    9631:	48 c1 e8 20          	shr    $0x20,%rax
    9635:	48 39 d0             	cmp    %rdx,%rax
    9638:	73 11                	jae    964b <f23+0x18b>
    963a:	48 01 c5             	add    %rax,%rbp
    963d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9641:	0f 84 57 02 00 00    	je     989e <f23+0x3de>
    9647:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    964b:	48 85 db             	test   %rbx,%rbx
    964e:	74 5d                	je     96ad <f23+0x1ed>
    9650:	48 c1 e3 04          	shl    $0x4,%rbx
    9654:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9659:	4c 89 e5             	mov    %r12,%rbp
    965c:	4d 89 ef             	mov    %r13,%r15
    965f:	4c 01 e3             	add    %r12,%rbx
    9662:	0f 1f 00             	nopl   (%rax)
    9665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    966c:	00 00 00 00 
    9670:	49 8b 46 08          	mov    0x8(%r14),%rax
    9674:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9678:	48 83 c5 10          	add    $0x10,%rbp
    967c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9681:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9685:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9689:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    968e:	e8 9d d0 ff ff       	call   6730 <w107>
    9693:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9698:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    969c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    96a0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    96a4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    96a8:	48 39 dd             	cmp    %rbx,%rbp
    96ab:	75 c3                	jne    9670 <f23+0x1b0>
    96ad:	4c 89 ef             	mov    %r13,%rdi
    96b0:	e8 3b fb ff ff       	call   91f0 <fwp_drop2>
    96b5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    96ba:	e8 31 fb ff ff       	call   91f0 <fwp_drop2>
    96bf:	4c 89 e7             	mov    %r12,%rdi
    96c2:	e8 e9 d1 ff ff       	call   68b0 <w164.constprop.0>
    96c7:	4c 89 e7             	mov    %r12,%rdi
    96ca:	48 89 c3             	mov    %rax,%rbx
    96cd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    96d3:	e8 28 e4 ff ff       	call   7b00 <fwp_drop4>
    96d8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    96de:	66 48 0f 6e db       	movq   %rbx,%xmm3
    96e3:	31 ff                	xor    %edi,%edi
    96e5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    96ea:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    96ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    96f3:	e8 58 d2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    96f8:	48 8b 15 19 05 06 00 	mov    0x60519(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    96ff:	48 89 c5             	mov    %rax,%rbp
    9702:	48 2b 05 e7 04 06 00 	sub    0x604e7(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    9709:	48 c1 e2 10          	shl    $0x10,%rdx
    970d:	48 39 d0             	cmp    %rdx,%rax
    9710:	73 55                	jae    9767 <f23+0x2a7>
    9712:	48 89 c2             	mov    %rax,%rdx
    9715:	48 c1 ea 10          	shr    $0x10,%rdx
    9719:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    971d:	48 8b 15 14 05 06 00 	mov    0x60514(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9724:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9728:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    972c:	48 85 db             	test   %rbx,%rbx
    972f:	74 36                	je     9767 <f23+0x2a7>
    9731:	0f b6 0a             	movzbl (%rdx),%ecx
    9734:	80 f9 02             	cmp    $0x2,%cl
    9737:	0f 84 a3 00 00 00    	je     97e0 <f23+0x320>
    973d:	80 f9 01             	cmp    $0x1,%cl
    9740:	75 25                	jne    9767 <f23+0x2a7>
    9742:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9745:	0f b7 c0             	movzwl %ax,%eax
    9748:	8b 52 1c             	mov    0x1c(%rdx),%edx
    974b:	48 0f af c1          	imul   %rcx,%rax
    974f:	48 c1 e8 20          	shr    $0x20,%rax
    9753:	48 39 d0             	cmp    %rdx,%rax
    9756:	73 0f                	jae    9767 <f23+0x2a7>
    9758:	48 01 c3             	add    %rax,%rbx
    975b:	80 3b ff             	cmpb   $0xff,(%rbx)
    975e:	0f 84 2d 01 00 00    	je     9891 <f23+0x3d1>
    9764:	c6 03 01             	movb   $0x1,(%rbx)
    9767:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    976c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9773:	00 00 
    9775:	0f 85 cf 01 00 00    	jne    994a <f23+0x48a>
    977b:	48 83 c4 38          	add    $0x38,%rsp
    977f:	48 89 e8             	mov    %rbp,%rax
    9782:	5b                   	pop    %rbx
    9783:	5d                   	pop    %rbp
    9784:	41 5c                	pop    %r12
    9786:	41 5d                	pop    %r13
    9788:	41 5e                	pop    %r14
    978a:	41 5f                	pop    %r15
    978c:	c3                   	ret
    978d:	0f 1f 00             	nopl   (%rax)
    9790:	66 85 c0             	test   %ax,%ax
    9793:	0f 85 d3 fd ff ff    	jne    956c <f23+0xac>
    9799:	0f b6 07             	movzbl (%rdi),%eax
    979c:	84 c0                	test   %al,%al
    979e:	0f 84 c8 fd ff ff    	je     956c <f23+0xac>
    97a4:	90                   	nop
    97a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97ac:	00 00 00 00 
    97b0:	8b 15 52 0d 06 00    	mov    0x60d52(%rip),%edx        # 6a508 <iteration_active>
    97b6:	85 d2                	test   %edx,%edx
    97b8:	75 56                	jne    9810 <f23+0x350>
    97ba:	3c fd                	cmp    $0xfd,%al
    97bc:	0f 87 4b 01 00 00    	ja     990d <f23+0x44d>
    97c2:	83 c0 01             	add    $0x1,%eax
    97c5:	88 07                	mov    %al,(%rdi)
    97c7:	31 d2                	xor    %edx,%edx
    97c9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    97cf:	0f 85 97 fd ff ff    	jne    956c <f23+0xac>
    97d5:	e9 b3 fd ff ff       	jmp    958d <f23+0xcd>
    97da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97e0:	66 85 c0             	test   %ax,%ax
    97e3:	0f 85 7e ff ff ff    	jne    9767 <f23+0x2a7>
    97e9:	e9 6d ff ff ff       	jmp    975b <f23+0x29b>
    97ee:	66 90                	xchg   %ax,%ax
    97f0:	66 85 c0             	test   %ax,%ax
    97f3:	0f 85 52 fe ff ff    	jne    964b <f23+0x18b>
    97f9:	e9 3f fe ff ff       	jmp    963d <f23+0x17d>
    97fe:	66 90                	xchg   %ax,%ax
    9800:	4c 89 e8             	mov    %r13,%rax
    9803:	e9 6d fd ff ff       	jmp    9575 <f23+0xb5>
    9808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    980f:	00 
    9810:	48 83 05 d8 0c 06 00 	addq   $0x1,0x60cd8(%rip)        # 6a4f0 <iteration_retains>
    9817:	01 
    9818:	eb a0                	jmp    97ba <f23+0x2fa>
    981a:	48 f7 d9             	neg    %rcx
    981d:	48 39 d1             	cmp    %rdx,%rcx
    9820:	0f 82 85 00 00 00    	jb     98ab <f23+0x3eb>
    9826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    982d:	00 00 00 
    9830:	be 02 00 00 00       	mov    $0x2,%esi
    9835:	bf 08 00 00 00       	mov    $0x8,%edi
    983a:	e8 31 c7 ff ff       	call   5f70 <fwp_heap_alloc>
    983f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9846:	48 8b 15 cb 03 06 00 	mov    0x603cb(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    984d:	49 89 c4             	mov    %rax,%r12
    9850:	48 2b 05 99 03 06 00 	sub    0x60399(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    9857:	48 c1 e2 10          	shl    $0x10,%rdx
    985b:	48 39 d0             	cmp    %rdx,%rax
    985e:	0f 83 b3 00 00 00    	jae    9917 <f23+0x457>
    9864:	48 89 c2             	mov    %rax,%rdx
    9867:	48 c1 ea 10          	shr    $0x10,%rdx
    986b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    986f:	48 8b 15 c2 03 06 00 	mov    0x603c2(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9876:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    987a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    987e:	48 85 ed             	test   %rbp,%rbp
    9881:	0f 84 90 00 00 00    	je     9917 <f23+0x457>
    9887:	31 db                	xor    %ebx,%ebx
    9889:	45 31 ed             	xor    %r13d,%r13d
    988c:	e9 82 fd ff ff       	jmp    9613 <f23+0x153>
    9891:	48 89 df             	mov    %rbx,%rdi
    9894:	e8 97 bf ff ff       	call   5830 <fwp_rc_forget_slot>
    9899:	e9 c6 fe ff ff       	jmp    9764 <f23+0x2a4>
    989e:	48 89 ef             	mov    %rbp,%rdi
    98a1:	e8 8a bf ff ff       	call   5830 <fwp_rc_forget_slot>
    98a6:	e9 9c fd ff ff       	jmp    9647 <f23+0x187>
    98ab:	48 89 c8             	mov    %rcx,%rax
    98ae:	48 c1 e8 10          	shr    $0x10,%rax
    98b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    98b6:	48 8b 05 7b 03 06 00 	mov    0x6037b(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    98bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    98c1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    98c5:	48 85 ff             	test   %rdi,%rdi
    98c8:	0f 84 62 ff ff ff    	je     9830 <f23+0x370>
    98ce:	0f b6 02             	movzbl (%rdx),%eax
    98d1:	3c 02                	cmp    $0x2,%al
    98d3:	74 4a                	je     991f <f23+0x45f>
    98d5:	3c 01                	cmp    $0x1,%al
    98d7:	0f 85 53 ff ff ff    	jne    9830 <f23+0x370>
    98dd:	0f b7 c1             	movzwl %cx,%eax
    98e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98e6:	48 0f af c1          	imul   %rcx,%rax
    98ea:	48 c1 e8 20          	shr    $0x20,%rax
    98ee:	48 39 d0             	cmp    %rdx,%rax
    98f1:	0f 83 39 ff ff ff    	jae    9830 <f23+0x370>
    98f7:	48 01 c7             	add    %rax,%rdi
    98fa:	0f b6 07             	movzbl (%rdi),%eax
    98fd:	84 c0                	test   %al,%al
    98ff:	0f 84 2b ff ff ff    	je     9830 <f23+0x370>
    9905:	45 31 ed             	xor    %r13d,%r13d
    9908:	e9 a3 fe ff ff       	jmp    97b0 <f23+0x2f0>
    990d:	e8 fe bd ff ff       	call   5710 <fwp_rc_wide_dup>
    9912:	e9 b0 fe ff ff       	jmp    97c7 <f23+0x307>
    9917:	45 31 ed             	xor    %r13d,%r13d
    991a:	e9 8e fd ff ff       	jmp    96ad <f23+0x1ed>
    991f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    9925:	49 89 cd             	mov    %rcx,%r13
    9928:	0f 85 02 ff ff ff    	jne    9830 <f23+0x370>
    992e:	0f b6 07             	movzbl (%rdi),%eax
    9931:	84 c0                	test   %al,%al
    9933:	0f 85 77 fe ff ff    	jne    97b0 <f23+0x2f0>
    9939:	e9 f2 fe ff ff       	jmp    9830 <f23+0x370>
    993e:	48 8d 3d c0 28 00 00 	lea    0x28c0(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    9945:	e8 06 ab ff ff       	call   4450 <fwp_trap>
    994a:	e8 01 9b ff ff       	call   3450 <__stack_chk_fail@plt>
    994f:	90                   	nop

0000000000009950 <fwp_owned_entry23>:
    9950:	f3 0f 1e fa          	endbr64
    9954:	48 8b 3f             	mov    (%rdi),%rdi
    9957:	e9 64 fb ff ff       	jmp    94c0 <f23>
    995c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009960 <e23>:
    9960:	f3 0f 1e fa          	endbr64
    9964:	53                   	push   %rbx
    9965:	48 8b 1f             	mov    (%rdi),%rbx
    9968:	48 89 df             	mov    %rbx,%rdi
    996b:	e8 d0 d1 ff ff       	call   6b40 <fwp_rc_share>
    9970:	48 89 df             	mov    %rbx,%rdi
    9973:	e8 48 fb ff ff       	call   94c0 <f23>
    9978:	48 89 c3             	mov    %rax,%rbx
    997b:	48 89 c7             	mov    %rax,%rdi
    997e:	e8 bd d1 ff ff       	call   6b40 <fwp_rc_share>
    9983:	48 89 d8             	mov    %rbx,%rax
    9986:	5b                   	pop    %rbx
    9987:	c3                   	ret
    9988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    998f:	00 

0000000000009990 <fwp_args12>:
    9990:	f3 0f 1e fa          	endbr64
    9994:	85 d2                	test   %edx,%edx
    9996:	74 04                	je     999c <fwp_args12+0xc>
    9998:	85 f6                	test   %esi,%esi
    999a:	74 04                	je     99a0 <fwp_args12+0x10>
    999c:	c3                   	ret
    999d:	0f 1f 00             	nopl   (%rax)
    99a0:	48 8b 15 71 02 06 00 	mov    0x60271(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    99a7:	48 8b 07             	mov    (%rdi),%rax
    99aa:	48 2b 05 3f 02 06 00 	sub    0x6023f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    99b1:	48 c1 e2 10          	shl    $0x10,%rdx
    99b5:	48 39 d0             	cmp    %rdx,%rax
    99b8:	73 e2                	jae    999c <fwp_args12+0xc>
    99ba:	48 89 c2             	mov    %rax,%rdx
    99bd:	48 c1 ea 10          	shr    $0x10,%rdx
    99c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99c5:	48 8b 15 6c 02 06 00 	mov    0x6026c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    99cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99d4:	48 85 ff             	test   %rdi,%rdi
    99d7:	74 c3                	je     999c <fwp_args12+0xc>
    99d9:	0f b6 0a             	movzbl (%rdx),%ecx
    99dc:	80 f9 02             	cmp    $0x2,%cl
    99df:	74 4f                	je     9a30 <fwp_args12+0xa0>
    99e1:	80 f9 01             	cmp    $0x1,%cl
    99e4:	75 b6                	jne    999c <fwp_args12+0xc>
    99e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99e9:	0f b7 c0             	movzwl %ax,%eax
    99ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99ef:	48 0f af c1          	imul   %rcx,%rax
    99f3:	48 c1 e8 20          	shr    $0x20,%rax
    99f7:	48 39 d0             	cmp    %rdx,%rax
    99fa:	73 a0                	jae    999c <fwp_args12+0xc>
    99fc:	48 01 c7             	add    %rax,%rdi
    99ff:	0f b6 07             	movzbl (%rdi),%eax
    9a02:	84 c0                	test   %al,%al
    9a04:	74 96                	je     999c <fwp_args12+0xc>
    9a06:	8b 15 fc 0a 06 00    	mov    0x60afc(%rip),%edx        # 6a508 <iteration_active>
    9a0c:	85 d2                	test   %edx,%edx
    9a0e:	75 10                	jne    9a20 <fwp_args12+0x90>
    9a10:	3c fd                	cmp    $0xfd,%al
    9a12:	77 22                	ja     9a36 <fwp_args12+0xa6>
    9a14:	83 c0 01             	add    $0x1,%eax
    9a17:	88 07                	mov    %al,(%rdi)
    9a19:	c3                   	ret
    9a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a20:	48 83 05 c8 0a 06 00 	addq   $0x1,0x60ac8(%rip)        # 6a4f0 <iteration_retains>
    9a27:	01 
    9a28:	eb e6                	jmp    9a10 <fwp_args12+0x80>
    9a2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a30:	66 85 c0             	test   %ax,%ax
    9a33:	74 ca                	je     99ff <fwp_args12+0x6f>
    9a35:	c3                   	ret
    9a36:	e9 d5 bc ff ff       	jmp    5710 <fwp_rc_wide_dup>
    9a3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009a40 <fwp_args23>:
    9a40:	f3 0f 1e fa          	endbr64
    9a44:	85 d2                	test   %edx,%edx
    9a46:	74 04                	je     9a4c <fwp_args23+0xc>
    9a48:	85 f6                	test   %esi,%esi
    9a4a:	74 04                	je     9a50 <fwp_args23+0x10>
    9a4c:	c3                   	ret
    9a4d:	0f 1f 00             	nopl   (%rax)
    9a50:	48 8b 15 c1 01 06 00 	mov    0x601c1(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    9a57:	48 8b 07             	mov    (%rdi),%rax
    9a5a:	48 2b 05 8f 01 06 00 	sub    0x6018f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    9a61:	48 c1 e2 10          	shl    $0x10,%rdx
    9a65:	48 39 d0             	cmp    %rdx,%rax
    9a68:	73 e2                	jae    9a4c <fwp_args23+0xc>
    9a6a:	48 89 c2             	mov    %rax,%rdx
    9a6d:	48 c1 ea 10          	shr    $0x10,%rdx
    9a71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a75:	48 8b 15 bc 01 06 00 	mov    0x601bc(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9a7c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a80:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9a84:	48 85 ff             	test   %rdi,%rdi
    9a87:	74 c3                	je     9a4c <fwp_args23+0xc>
    9a89:	0f b6 0a             	movzbl (%rdx),%ecx
    9a8c:	80 f9 02             	cmp    $0x2,%cl
    9a8f:	74 4f                	je     9ae0 <fwp_args23+0xa0>
    9a91:	80 f9 01             	cmp    $0x1,%cl
    9a94:	75 b6                	jne    9a4c <fwp_args23+0xc>
    9a96:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a99:	0f b7 c0             	movzwl %ax,%eax
    9a9c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a9f:	48 0f af c1          	imul   %rcx,%rax
    9aa3:	48 c1 e8 20          	shr    $0x20,%rax
    9aa7:	48 39 d0             	cmp    %rdx,%rax
    9aaa:	73 a0                	jae    9a4c <fwp_args23+0xc>
    9aac:	48 01 c7             	add    %rax,%rdi
    9aaf:	0f b6 07             	movzbl (%rdi),%eax
    9ab2:	84 c0                	test   %al,%al
    9ab4:	74 96                	je     9a4c <fwp_args23+0xc>
    9ab6:	8b 15 4c 0a 06 00    	mov    0x60a4c(%rip),%edx        # 6a508 <iteration_active>
    9abc:	85 d2                	test   %edx,%edx
    9abe:	75 10                	jne    9ad0 <fwp_args23+0x90>
    9ac0:	3c fd                	cmp    $0xfd,%al
    9ac2:	77 22                	ja     9ae6 <fwp_args23+0xa6>
    9ac4:	83 c0 01             	add    $0x1,%eax
    9ac7:	88 07                	mov    %al,(%rdi)
    9ac9:	c3                   	ret
    9aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ad0:	48 83 05 18 0a 06 00 	addq   $0x1,0x60a18(%rip)        # 6a4f0 <iteration_retains>
    9ad7:	01 
    9ad8:	eb e6                	jmp    9ac0 <fwp_args23+0x80>
    9ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ae0:	66 85 c0             	test   %ax,%ax
    9ae3:	74 ca                	je     9aaf <fwp_args23+0x6f>
    9ae5:	c3                   	ret
    9ae6:	e9 25 bc ff ff       	jmp    5710 <fwp_rc_wide_dup>
    9aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009af0 <fwp_caps12>:
    9af0:	f3 0f 1e fa          	endbr64
    9af4:	48 83 ec 18          	sub    $0x18,%rsp
    9af8:	48 89 f8             	mov    %rdi,%rax
    9afb:	8b 7f 04             	mov    0x4(%rdi),%edi
    9afe:	85 ff                	test   %edi,%edi
    9b00:	0f 84 9a 00 00 00    	je     9ba0 <fwp_caps12+0xb0>
    9b06:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9b0a:	85 f6                	test   %esi,%esi
    9b0c:	0f 85 9e 00 00 00    	jne    9bb0 <fwp_caps12+0xc0>
    9b12:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9b17:	e8 d4 d3 ff ff       	call   6ef0 <fwp_drop0>
    9b1c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b21:	48 8b 0d f0 00 06 00 	mov    0x600f0(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    9b28:	48 89 c2             	mov    %rax,%rdx
    9b2b:	48 2b 15 be 00 06 00 	sub    0x600be(%rip),%rdx        # 69bf0 <fwp_heap+0x13b0>
    9b32:	48 c1 e1 10          	shl    $0x10,%rcx
    9b36:	48 39 ca             	cmp    %rcx,%rdx
    9b39:	73 6d                	jae    9ba8 <fwp_caps12+0xb8>
    9b3b:	48 89 d1             	mov    %rdx,%rcx
    9b3e:	48 c1 e9 10          	shr    $0x10,%rcx
    9b42:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9b46:	48 8b 0d eb 00 06 00 	mov    0x600eb(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    9b4d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9b51:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9b55:	48 85 f6             	test   %rsi,%rsi
    9b58:	74 4e                	je     9ba8 <fwp_caps12+0xb8>
    9b5a:	0f b6 39             	movzbl (%rcx),%edi
    9b5d:	40 80 ff 02          	cmp    $0x2,%dil
    9b61:	0f 84 c9 00 00 00    	je     9c30 <fwp_caps12+0x140>
    9b67:	40 80 ff 01          	cmp    $0x1,%dil
    9b6b:	75 3b                	jne    9ba8 <fwp_caps12+0xb8>
    9b6d:	8b 79 18             	mov    0x18(%rcx),%edi
    9b70:	0f b7 d2             	movzwl %dx,%edx
    9b73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9b76:	48 0f af d7          	imul   %rdi,%rdx
    9b7a:	48 c1 ea 20          	shr    $0x20,%rdx
    9b7e:	48 39 ca             	cmp    %rcx,%rdx
    9b81:	73 25                	jae    9ba8 <fwp_caps12+0xb8>
    9b83:	48 01 d6             	add    %rdx,%rsi
    9b86:	80 3e 01             	cmpb   $0x1,(%rsi)
    9b89:	75 1d                	jne    9ba8 <fwp_caps12+0xb8>
    9b8b:	48 89 c7             	mov    %rax,%rdi
    9b8e:	48 83 c4 18          	add    $0x18,%rsp
    9b92:	e9 d9 be ff ff       	jmp    5a70 <fwp_mem_free>
    9b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b9e:	00 00 
    9ba0:	85 f6                	test   %esi,%esi
    9ba2:	0f 84 79 ff ff ff    	je     9b21 <fwp_caps12+0x31>
    9ba8:	48 83 c4 18          	add    $0x18,%rsp
    9bac:	c3                   	ret
    9bad:	0f 1f 00             	nopl   (%rax)
    9bb0:	48 8b 05 61 00 06 00 	mov    0x60061(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    9bb7:	48 2b 3d 32 00 06 00 	sub    0x60032(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    9bbe:	48 c1 e0 10          	shl    $0x10,%rax
    9bc2:	48 39 c7             	cmp    %rax,%rdi
    9bc5:	73 e1                	jae    9ba8 <fwp_caps12+0xb8>
    9bc7:	48 89 f8             	mov    %rdi,%rax
    9bca:	48 c1 e8 10          	shr    $0x10,%rax
    9bce:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9bd2:	48 8b 05 5f 00 06 00 	mov    0x6005f(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    9bd9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9bdd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9be1:	48 85 c0             	test   %rax,%rax
    9be4:	74 c2                	je     9ba8 <fwp_caps12+0xb8>
    9be6:	0f b6 0a             	movzbl (%rdx),%ecx
    9be9:	80 f9 02             	cmp    $0x2,%cl
    9bec:	74 52                	je     9c40 <fwp_caps12+0x150>
    9bee:	80 f9 01             	cmp    $0x1,%cl
    9bf1:	75 b5                	jne    9ba8 <fwp_caps12+0xb8>
    9bf3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bf6:	0f b7 ff             	movzwl %di,%edi
    9bf9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bfc:	48 0f af f9          	imul   %rcx,%rdi
    9c00:	48 c1 ef 20          	shr    $0x20,%rdi
    9c04:	48 39 d7             	cmp    %rdx,%rdi
    9c07:	73 9f                	jae    9ba8 <fwp_caps12+0xb8>
    9c09:	48 01 f8             	add    %rdi,%rax
    9c0c:	0f b6 10             	movzbl (%rax),%edx
    9c0f:	84 d2                	test   %dl,%dl
    9c11:	74 95                	je     9ba8 <fwp_caps12+0xb8>
    9c13:	8b 0d ef 08 06 00    	mov    0x608ef(%rip),%ecx        # 6a508 <iteration_active>
    9c19:	85 c9                	test   %ecx,%ecx
    9c1b:	75 33                	jne    9c50 <fwp_caps12+0x160>
    9c1d:	80 fa fd             	cmp    $0xfd,%dl
    9c20:	77 38                	ja     9c5a <fwp_caps12+0x16a>
    9c22:	83 c2 01             	add    $0x1,%edx
    9c25:	88 10                	mov    %dl,(%rax)
    9c27:	e9 7c ff ff ff       	jmp    9ba8 <fwp_caps12+0xb8>
    9c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c30:	66 85 d2             	test   %dx,%dx
    9c33:	0f 85 6f ff ff ff    	jne    9ba8 <fwp_caps12+0xb8>
    9c39:	e9 48 ff ff ff       	jmp    9b86 <fwp_caps12+0x96>
    9c3e:	66 90                	xchg   %ax,%ax
    9c40:	66 85 ff             	test   %di,%di
    9c43:	0f 85 5f ff ff ff    	jne    9ba8 <fwp_caps12+0xb8>
    9c49:	eb c1                	jmp    9c0c <fwp_caps12+0x11c>
    9c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c50:	48 83 05 98 08 06 00 	addq   $0x1,0x60898(%rip)        # 6a4f0 <iteration_retains>
    9c57:	01 
    9c58:	eb c3                	jmp    9c1d <fwp_caps12+0x12d>
    9c5a:	48 89 c7             	mov    %rax,%rdi
    9c5d:	48 83 c4 18          	add    $0x18,%rsp
    9c61:	e9 aa ba ff ff       	jmp    5710 <fwp_rc_wide_dup>
    9c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c6d:	00 00 00 

0000000000009c70 <fwp_caps23>:
    9c70:	f3 0f 1e fa          	endbr64
    9c74:	48 83 ec 18          	sub    $0x18,%rsp
    9c78:	48 89 f8             	mov    %rdi,%rax
    9c7b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9c7e:	85 ff                	test   %edi,%edi
    9c80:	0f 84 9a 00 00 00    	je     9d20 <fwp_caps23+0xb0>
    9c86:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9c8a:	85 f6                	test   %esi,%esi
    9c8c:	0f 85 9e 00 00 00    	jne    9d30 <fwp_caps23+0xc0>
    9c92:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9c97:	e8 54 f5 ff ff       	call   91f0 <fwp_drop2>
    9c9c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9ca1:	48 8b 0d 70 ff 05 00 	mov    0x5ff70(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    9ca8:	48 89 c2             	mov    %rax,%rdx
    9cab:	48 2b 15 3e ff 05 00 	sub    0x5ff3e(%rip),%rdx        # 69bf0 <fwp_heap+0x13b0>
    9cb2:	48 c1 e1 10          	shl    $0x10,%rcx
    9cb6:	48 39 ca             	cmp    %rcx,%rdx
    9cb9:	73 6d                	jae    9d28 <fwp_caps23+0xb8>
    9cbb:	48 89 d1             	mov    %rdx,%rcx
    9cbe:	48 c1 e9 10          	shr    $0x10,%rcx
    9cc2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9cc6:	48 8b 0d 6b ff 05 00 	mov    0x5ff6b(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    9ccd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9cd1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9cd5:	48 85 f6             	test   %rsi,%rsi
    9cd8:	74 4e                	je     9d28 <fwp_caps23+0xb8>
    9cda:	0f b6 39             	movzbl (%rcx),%edi
    9cdd:	40 80 ff 02          	cmp    $0x2,%dil
    9ce1:	0f 84 c9 00 00 00    	je     9db0 <fwp_caps23+0x140>
    9ce7:	40 80 ff 01          	cmp    $0x1,%dil
    9ceb:	75 3b                	jne    9d28 <fwp_caps23+0xb8>
    9ced:	8b 79 18             	mov    0x18(%rcx),%edi
    9cf0:	0f b7 d2             	movzwl %dx,%edx
    9cf3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9cf6:	48 0f af d7          	imul   %rdi,%rdx
    9cfa:	48 c1 ea 20          	shr    $0x20,%rdx
    9cfe:	48 39 ca             	cmp    %rcx,%rdx
    9d01:	73 25                	jae    9d28 <fwp_caps23+0xb8>
    9d03:	48 01 d6             	add    %rdx,%rsi
    9d06:	80 3e 01             	cmpb   $0x1,(%rsi)
    9d09:	75 1d                	jne    9d28 <fwp_caps23+0xb8>
    9d0b:	48 89 c7             	mov    %rax,%rdi
    9d0e:	48 83 c4 18          	add    $0x18,%rsp
    9d12:	e9 59 bd ff ff       	jmp    5a70 <fwp_mem_free>
    9d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d1e:	00 00 
    9d20:	85 f6                	test   %esi,%esi
    9d22:	0f 84 79 ff ff ff    	je     9ca1 <fwp_caps23+0x31>
    9d28:	48 83 c4 18          	add    $0x18,%rsp
    9d2c:	c3                   	ret
    9d2d:	0f 1f 00             	nopl   (%rax)
    9d30:	48 8b 05 e1 fe 05 00 	mov    0x5fee1(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    9d37:	48 2b 3d b2 fe 05 00 	sub    0x5feb2(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    9d3e:	48 c1 e0 10          	shl    $0x10,%rax
    9d42:	48 39 c7             	cmp    %rax,%rdi
    9d45:	73 e1                	jae    9d28 <fwp_caps23+0xb8>
    9d47:	48 89 f8             	mov    %rdi,%rax
    9d4a:	48 c1 e8 10          	shr    $0x10,%rax
    9d4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9d52:	48 8b 05 df fe 05 00 	mov    0x5fedf(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    9d59:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9d5d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9d61:	48 85 c0             	test   %rax,%rax
    9d64:	74 c2                	je     9d28 <fwp_caps23+0xb8>
    9d66:	0f b6 0a             	movzbl (%rdx),%ecx
    9d69:	80 f9 02             	cmp    $0x2,%cl
    9d6c:	74 52                	je     9dc0 <fwp_caps23+0x150>
    9d6e:	80 f9 01             	cmp    $0x1,%cl
    9d71:	75 b5                	jne    9d28 <fwp_caps23+0xb8>
    9d73:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d76:	0f b7 ff             	movzwl %di,%edi
    9d79:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d7c:	48 0f af f9          	imul   %rcx,%rdi
    9d80:	48 c1 ef 20          	shr    $0x20,%rdi
    9d84:	48 39 d7             	cmp    %rdx,%rdi
    9d87:	73 9f                	jae    9d28 <fwp_caps23+0xb8>
    9d89:	48 01 f8             	add    %rdi,%rax
    9d8c:	0f b6 10             	movzbl (%rax),%edx
    9d8f:	84 d2                	test   %dl,%dl
    9d91:	74 95                	je     9d28 <fwp_caps23+0xb8>
    9d93:	8b 0d 6f 07 06 00    	mov    0x6076f(%rip),%ecx        # 6a508 <iteration_active>
    9d99:	85 c9                	test   %ecx,%ecx
    9d9b:	75 33                	jne    9dd0 <fwp_caps23+0x160>
    9d9d:	80 fa fd             	cmp    $0xfd,%dl
    9da0:	77 38                	ja     9dda <fwp_caps23+0x16a>
    9da2:	83 c2 01             	add    $0x1,%edx
    9da5:	88 10                	mov    %dl,(%rax)
    9da7:	e9 7c ff ff ff       	jmp    9d28 <fwp_caps23+0xb8>
    9dac:	0f 1f 40 00          	nopl   0x0(%rax)
    9db0:	66 85 d2             	test   %dx,%dx
    9db3:	0f 85 6f ff ff ff    	jne    9d28 <fwp_caps23+0xb8>
    9db9:	e9 48 ff ff ff       	jmp    9d06 <fwp_caps23+0x96>
    9dbe:	66 90                	xchg   %ax,%ax
    9dc0:	66 85 ff             	test   %di,%di
    9dc3:	0f 85 5f ff ff ff    	jne    9d28 <fwp_caps23+0xb8>
    9dc9:	eb c1                	jmp    9d8c <fwp_caps23+0x11c>
    9dcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9dd0:	48 83 05 18 07 06 00 	addq   $0x1,0x60718(%rip)        # 6a4f0 <iteration_retains>
    9dd7:	01 
    9dd8:	eb c3                	jmp    9d9d <fwp_caps23+0x12d>
    9dda:	48 89 c7             	mov    %rax,%rdi
    9ddd:	48 83 c4 18          	add    $0x18,%rsp
    9de1:	e9 2a b9 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    9de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9ded:	00 00 00 

0000000000009df0 <fwp_write>:
    9df0:	41 57                	push   %r15
    9df2:	41 56                	push   %r14
    9df4:	41 55                	push   %r13
    9df6:	41 54                	push   %r12
    9df8:	55                   	push   %rbp
    9df9:	53                   	push   %rbx
    9dfa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9e01:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9e08:	00 00 
    9e0a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9e11:	00 
    9e12:	49 89 d4             	mov    %rdx,%r12
    9e15:	8b 12                	mov    (%rdx),%edx
    9e17:	83 fa 19             	cmp    $0x19,%edx
    9e1a:	77 6a                	ja     9e86 <fwp_write+0x96>
    9e1c:	48 89 f5             	mov    %rsi,%rbp
    9e1f:	89 d0                	mov    %edx,%eax
    9e21:	89 ce                	mov    %ecx,%esi
    9e23:	48 89 fb             	mov    %rdi,%rbx
    9e26:	48 8d 0d 93 2e 00 00 	lea    0x2e93(%rip),%rcx        # ccc0 <_IO_stdin_used+0xcc0>
    9e2d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9e31:	48 01 c8             	add    %rcx,%rax
    9e34:	3e ff e0             	notrack jmp *%rax
    9e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e3e:	00 00 
    9e40:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9e44:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9e48:	48 89 ca             	mov    %rcx,%rdx
    9e4b:	48 85 c9             	test   %rcx,%rcx
    9e4e:	0f 88 9c 0c 00 00    	js     aaf0 <fwp_write+0xd00>
    9e54:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e5b:	00 
    9e5c:	48 89 c6             	mov    %rax,%rsi
    9e5f:	4c 89 e7             	mov    %r12,%rdi
    9e62:	e8 d9 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e6e:	00 00 
    9e70:	4c 89 e7             	mov    %r12,%rdi
    9e73:	e8 c8 95 ff ff       	call   3440 <strlen@plt>
    9e78:	4c 89 e6             	mov    %r12,%rsi
    9e7b:	48 89 df             	mov    %rbx,%rdi
    9e7e:	48 89 c2             	mov    %rax,%rdx
    9e81:	e8 6a a2 ff ff       	call   40f0 <buf_put>
    9e86:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e8d:	00 
    9e8e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e95:	00 00 
    9e97:	0f 85 28 04 00 00    	jne    a2c5 <fwp_write+0x4d5>
    9e9d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9ea4:	5b                   	pop    %rbx
    9ea5:	5d                   	pop    %rbp
    9ea6:	41 5c                	pop    %r12
    9ea8:	41 5d                	pop    %r13
    9eaa:	41 5e                	pop    %r14
    9eac:	41 5f                	pop    %r15
    9eae:	c3                   	ret
    9eaf:	90                   	nop
    9eb0:	49 89 e9             	mov    %rbp,%r9
    9eb3:	4c 8d 05 a1 23 00 00 	lea    0x23a1(%rip),%r8        # c25b <_IO_stdin_used+0x25b>
    9eba:	b9 00 02 00 00       	mov    $0x200,%ecx
    9ebf:	ba 02 00 00 00       	mov    $0x2,%edx
    9ec4:	be 00 02 00 00       	mov    $0x200,%esi
    9ec9:	31 c0                	xor    %eax,%eax
    9ecb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ed2:	00 
    9ed3:	e8 c8 94 ff ff       	call   33a0 <__snprintf_chk@plt>
    9ed8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9edf:	00 
    9ee0:	e8 5b 95 ff ff       	call   3440 <strlen@plt>
    9ee5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9eec:	00 
    9eed:	48 89 df             	mov    %rbx,%rdi
    9ef0:	48 89 c2             	mov    %rax,%rdx
    9ef3:	e8 f8 a1 ff ff       	call   40f0 <buf_put>
    9ef8:	eb 8c                	jmp    9e86 <fwp_write+0x96>
    9efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f00:	49 89 e9             	mov    %rbp,%r9
    9f03:	4c 8d 05 4c 23 00 00 	lea    0x234c(%rip),%r8        # c256 <_IO_stdin_used+0x256>
    9f0a:	eb ae                	jmp    9eba <fwp_write+0xca>
    9f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f10:	83 fa 13             	cmp    $0x13,%edx
    9f13:	48 8d 05 32 23 00 00 	lea    0x2332(%rip),%rax        # c24c <_IO_stdin_used+0x24c>
    9f1a:	48 8d 35 30 23 00 00 	lea    0x2330(%rip),%rsi        # c251 <_IO_stdin_used+0x251>
    9f21:	ba 04 00 00 00       	mov    $0x4,%edx
    9f26:	48 0f 44 f0          	cmove  %rax,%rsi
    9f2a:	45 31 ed             	xor    %r13d,%r13d
    9f2d:	e8 be a1 ff ff       	call   40f0 <buf_put>
    9f32:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9f37:	0f 84 a3 08 00 00    	je     a7e0 <fwp_write+0x9f0>
    9f3d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9f42:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9f47:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f4c:	48 89 df             	mov    %rbx,%rdi
    9f4f:	49 0f 44 c5          	cmove  %r13,%rax
    9f53:	31 c9                	xor    %ecx,%ecx
    9f55:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9f5a:	e8 91 fe ff ff       	call   9df0 <fwp_write>
    9f5f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9f64:	0f 84 6e 09 00 00    	je     a8d8 <fwp_write+0xae8>
    9f6a:	49 83 c5 01          	add    $0x1,%r13
    9f6e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9f72:	0f 83 68 08 00 00    	jae    a7e0 <fwp_write+0x9f0>
    9f78:	ba 02 00 00 00       	mov    $0x2,%edx
    9f7d:	48 8d 35 17 23 00 00 	lea    0x2317(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    9f84:	48 89 df             	mov    %rbx,%rdi
    9f87:	e8 64 a1 ff ff       	call   40f0 <buf_put>
    9f8c:	eb af                	jmp    9f3d <fwp_write+0x14d>
    9f8e:	66 90                	xchg   %ax,%ax
    9f90:	ba 06 00 00 00       	mov    $0x6,%edx
    9f95:	48 8d 35 d8 22 00 00 	lea    0x22d8(%rip),%rsi        # c274 <_IO_stdin_used+0x274>
    9f9c:	48 83 c5 10          	add    $0x10,%rbp
    9fa0:	e8 4b a1 ff ff       	call   40f0 <buf_put>
    9fa5:	48 89 ef             	mov    %rbp,%rdi
    9fa8:	e8 93 94 ff ff       	call   3440 <strlen@plt>
    9fad:	48 89 ee             	mov    %rbp,%rsi
    9fb0:	48 89 df             	mov    %rbx,%rdi
    9fb3:	48 89 c2             	mov    %rax,%rdx
    9fb6:	e8 35 a1 ff ff       	call   40f0 <buf_put>
    9fbb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fc0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fc5:	48 89 df             	mov    %rbx,%rdi
    9fc8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9fcd:	e8 1e a1 ff ff       	call   40f0 <buf_put>
    9fd2:	e9 af fe ff ff       	jmp    9e86 <fwp_write+0x96>
    9fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9fde:	00 00 
    9fe0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9fe7:	00 
    9fe8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fef:	00 00 
    9ff1:	0f 85 ce 02 00 00    	jne    a2c5 <fwp_write+0x4d5>
    9ff7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9ffc:	48 8d 35 5d 22 00 00 	lea    0x225d(%rip),%rsi        # c260 <_IO_stdin_used+0x260>
    a003:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a00a:	48 89 df             	mov    %rbx,%rdi
    a00d:	5b                   	pop    %rbx
    a00e:	5d                   	pop    %rbp
    a00f:	41 5c                	pop    %r12
    a011:	41 5d                	pop    %r13
    a013:	41 5e                	pop    %r14
    a015:	41 5f                	pop    %r15
    a017:	e9 d4 a0 ff ff       	jmp    40f0 <buf_put>
    a01c:	0f 1f 40 00          	nopl   0x0(%rax)
    a020:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a025:	4d 85 ed             	test   %r13,%r13
    a028:	0f 84 02 0c 00 00    	je     ac30 <fwp_write+0xe40>
    a02e:	48 8d 35 73 22 00 00 	lea    0x2273(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    a035:	4c 89 ef             	mov    %r13,%rdi
    a038:	e8 e3 94 ff ff       	call   3520 <strcmp@plt>
    a03d:	41 89 c1             	mov    %eax,%r9d
    a040:	85 c0                	test   %eax,%eax
    a042:	0f 84 6c 0c 00 00    	je     acb4 <fwp_write+0xec4>
    a048:	4c 89 ef             	mov    %r13,%rdi
    a04b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a050:	e8 eb 93 ff ff       	call   3440 <strlen@plt>
    a055:	4c 89 ee             	mov    %r13,%rsi
    a058:	48 89 df             	mov    %rbx,%rdi
    a05b:	48 89 c2             	mov    %rax,%rdx
    a05e:	e8 8d a0 ff ff       	call   40f0 <buf_put>
    a063:	ba 01 00 00 00       	mov    $0x1,%edx
    a068:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a06d:	48 89 df             	mov    %rbx,%rdi
    a070:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a075:	e8 76 a0 ff ff       	call   40f0 <buf_put>
    a07a:	ba 01 00 00 00       	mov    $0x1,%edx
    a07f:	4c 89 fe             	mov    %r15,%rsi
    a082:	48 89 df             	mov    %rbx,%rdi
    a085:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a08a:	e8 61 a0 ff ff       	call   40f0 <buf_put>
    a08f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a094:	45 31 f6             	xor    %r14d,%r14d
    a097:	85 d2                	test   %edx,%edx
    a099:	0f 8e 81 0a 00 00    	jle    ab20 <fwp_write+0xd30>
    a09f:	45 31 ed             	xor    %r13d,%r13d
    a0a2:	4d 85 ed             	test   %r13,%r13
    a0a5:	0f 85 75 07 00 00    	jne    a820 <fwp_write+0xa30>
    a0ab:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a0b2:	00 
    a0b3:	45 85 f6             	test   %r14d,%r14d
    a0b6:	0f 84 84 07 00 00    	je     a840 <fwp_write+0xa50>
    a0bc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a0c1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a0c6:	48 89 df             	mov    %rbx,%rdi
    a0c9:	49 83 c5 01          	add    $0x1,%r13
    a0cd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a0d1:	31 c9                	xor    %ecx,%ecx
    a0d3:	e8 18 fd ff ff       	call   9df0 <fwp_write>
    a0d8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a0dd:	7f c3                	jg     a0a2 <fwp_write+0x2b2>
    a0df:	45 85 f6             	test   %r14d,%r14d
    a0e2:	0f 84 38 0a 00 00    	je     ab20 <fwp_write+0xd30>
    a0e8:	b8 29 00 00 00       	mov    $0x29,%eax
    a0ed:	ba 01 00 00 00       	mov    $0x1,%edx
    a0f2:	4c 89 fe             	mov    %r15,%rsi
    a0f5:	48 89 df             	mov    %rbx,%rdi
    a0f8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a0fc:	e8 ef 9f ff ff       	call   40f0 <buf_put>
    a101:	e9 80 fd ff ff       	jmp    9e86 <fwp_write+0x96>
    a106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a10d:	00 00 00 
    a110:	ba 01 00 00 00       	mov    $0x1,%edx
    a115:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a11a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a11f:	e8 cc 9f ff ff       	call   40f0 <buf_put>
    a124:	48 85 ed             	test   %rbp,%rbp
    a127:	0f 84 93 06 00 00    	je     a7c0 <fwp_write+0x9d0>
    a12d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a131:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a136:	31 c9                	xor    %ecx,%ecx
    a138:	48 89 df             	mov    %rbx,%rdi
    a13b:	e8 b0 fc ff ff       	call   9df0 <fwp_write>
    a140:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a144:	48 85 ed             	test   %rbp,%rbp
    a147:	0f 84 73 06 00 00    	je     a7c0 <fwp_write+0x9d0>
    a14d:	ba 02 00 00 00       	mov    $0x2,%edx
    a152:	48 8d 35 42 21 00 00 	lea    0x2142(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a159:	48 89 df             	mov    %rbx,%rdi
    a15c:	e8 8f 9f ff ff       	call   40f0 <buf_put>
    a161:	eb ca                	jmp    a12d <fwp_write+0x33d>
    a163:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a168:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a16c:	85 f6                	test   %esi,%esi
    a16e:	0f 84 fc 07 00 00    	je     a970 <fwp_write+0xb80>
    a174:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a17b:	00 
    a17c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a183:	00 00 
    a185:	0f 85 3a 01 00 00    	jne    a2c5 <fwp_write+0x4d5>
    a18b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a18f:	4c 89 ea             	mov    %r13,%rdx
    a192:	e9 6c fe ff ff       	jmp    a003 <fwp_write+0x213>
    a197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a19e:	00 00 
    a1a0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a1a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a1aa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a1af:	48 89 ee             	mov    %rbp,%rsi
    a1b2:	e8 39 9f ff ff       	call   40f0 <buf_put>
    a1b7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a1bc:	4c 89 e7             	mov    %r12,%rdi
    a1bf:	e8 7c 92 ff ff       	call   3440 <strlen@plt>
    a1c4:	4c 89 e6             	mov    %r12,%rsi
    a1c7:	48 89 df             	mov    %rbx,%rdi
    a1ca:	48 89 c2             	mov    %rax,%rdx
    a1cd:	e8 1e 9f ff ff       	call   40f0 <buf_put>
    a1d2:	ba 01 00 00 00       	mov    $0x1,%edx
    a1d7:	48 89 ee             	mov    %rbp,%rsi
    a1da:	48 89 df             	mov    %rbx,%rdi
    a1dd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a1e2:	e8 09 9f ff ff       	call   40f0 <buf_put>
    a1e7:	e9 9a fc ff ff       	jmp    9e86 <fwp_write+0x96>
    a1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a1f0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a1f5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a1f9:	0f 8a 8e 0b 00 00    	jp     ad8d <fwp_write+0xf9d>
    a1ff:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a203:	66 0f 54 05 c5 2b 00 	andpd  0x2bc5(%rip),%xmm0        # cdd0 <msg.8+0xa0>
    a20a:	00 
    a20b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a210:	66 0f 2e 05 f0 2b 00 	ucomisd 0x2bf0(%rip),%xmm0        # ce08 <msg.8+0xd8>
    a217:	00 
    a218:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a21f:	00 
    a220:	0f 87 b2 09 00 00    	ja     abd8 <fwp_write+0xde8>
    a226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a22d:	00 00 00 
    a230:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a234:	89 ee                	mov    %ebp,%esi
    a236:	4c 89 e7             	mov    %r12,%rdi
    a239:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a23e:	e8 2d a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a243:	31 f6                	xor    %esi,%esi
    a245:	4c 89 e7             	mov    %r12,%rdi
    a248:	e8 b3 91 ff ff       	call   3400 <strtod@plt>
    a24d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a252:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a256:	7a 06                	jp     a25e <fwp_write+0x46e>
    a258:	0f 84 e9 01 00 00    	je     a447 <fwp_write+0x657>
    a25e:	83 c5 01             	add    $0x1,%ebp
    a261:	83 fd 12             	cmp    $0x12,%ebp
    a264:	75 ca                	jne    a230 <fwp_write+0x440>
    a266:	be 11 00 00 00       	mov    $0x11,%esi
    a26b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a26f:	4c 89 e7             	mov    %r12,%rdi
    a272:	e8 f9 a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a277:	e9 cb 01 00 00       	jmp    a447 <fwp_write+0x657>
    a27c:	0f 1f 40 00          	nopl   0x0(%rax)
    a280:	48 83 fd 01          	cmp    $0x1,%rbp
    a284:	0f 84 e6 08 00 00    	je     ab70 <fwp_write+0xd80>
    a28a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a28e:	b8 02 00 00 00       	mov    $0x2,%eax
    a293:	ba 01 00 00 00       	mov    $0x1,%edx
    a298:	48 0f 44 d0          	cmove  %rax,%rdx
    a29c:	48 8d 35 a1 1f 00 00 	lea    0x1fa1(%rip),%rsi        # c244 <_IO_stdin_used+0x244>
    a2a3:	48 8d 05 9f 1f 00 00 	lea    0x1f9f(%rip),%rax        # c249 <_IO_stdin_used+0x249>
    a2aa:	48 0f 44 f0          	cmove  %rax,%rsi
    a2ae:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a2b5:	00 
    a2b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2bd:	00 00 
    a2bf:	0f 84 3e fd ff ff    	je     a003 <fwp_write+0x213>
    a2c5:	e8 86 91 ff ff       	call   3450 <__stack_chk_fail@plt>
    a2ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2d0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a2d5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a2da:	e8 51 9d ff ff       	call   4030 <buf_grow>
    a2df:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a2e3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a2e9:	4c 03 0b             	add    (%rbx),%r9
    a2ec:	66 45 89 11          	mov    %r10w,(%r9)
    a2f0:	45 85 e4             	test   %r12d,%r12d
    a2f3:	0f 8e 07 05 00 00    	jle    a800 <fwp_write+0xa10>
    a2f9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a300:	55 55 55 
    a303:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a308:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a30f:	aa aa aa 
    a312:	49 83 c1 01          	add    $0x1,%r9
    a316:	eb 45                	jmp    a35d <fwp_write+0x56d>
    a318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a31f:	00 
    a320:	be 01 00 00 00       	mov    $0x1,%esi
    a325:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a32a:	88 07                	mov    %al,(%rdi)
    a32c:	48 89 e8             	mov    %rbp,%rax
    a32f:	49 f7 e8             	imul   %r8
    a332:	48 89 e8             	mov    %rbp,%rax
    a335:	48 c1 f8 3f          	sar    $0x3f,%rax
    a339:	48 29 c2             	sub    %rax,%rdx
    a33c:	48 85 c9             	test   %rcx,%rcx
    a33f:	0f 95 c0             	setne  %al
    a342:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a346:	48 83 ef 01          	sub    $0x1,%rdi
    a34a:	48 21 c5             	and    %rax,%rbp
    a34d:	48 29 ea             	sub    %rbp,%rdx
    a350:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a354:	49 39 f9             	cmp    %rdi,%r9
    a357:	0f 84 a3 04 00 00    	je     a800 <fwp_write+0xa10>
    a35d:	48 89 e8             	mov    %rbp,%rax
    a360:	49 f7 e8             	imul   %r8
    a363:	48 89 e8             	mov    %rbp,%rax
    a366:	48 c1 f8 3f          	sar    $0x3f,%rax
    a36a:	48 89 d1             	mov    %rdx,%rcx
    a36d:	48 29 c1             	sub    %rax,%rcx
    a370:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a374:	48 89 e9             	mov    %rbp,%rcx
    a377:	48 29 c1             	sub    %rax,%rcx
    a37a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a37e:	49 f7 e2             	mul    %r10
    a381:	b8 30 00 00 00       	mov    $0x30,%eax
    a386:	48 89 d6             	mov    %rdx,%rsi
    a389:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a38d:	48 d1 ee             	shr    $1,%rsi
    a390:	48 01 f2             	add    %rsi,%rdx
    a393:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a397:	48 29 d6             	sub    %rdx,%rsi
    a39a:	74 8e                	je     a32a <fwp_write+0x53a>
    a39c:	48 83 fe 01          	cmp    $0x1,%rsi
    a3a0:	0f 85 7a ff ff ff    	jne    a320 <fwp_write+0x530>
    a3a6:	31 f6                	xor    %esi,%esi
    a3a8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a3ad:	e9 78 ff ff ff       	jmp    a32a <fwp_write+0x53a>
    a3b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3b8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a3bc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a3bf:	0f 8a c8 09 00 00    	jp     ad8d <fwp_write+0xf9d>
    a3c5:	0f 28 c1             	movaps %xmm1,%xmm0
    a3c8:	0f 54 05 f1 29 00 00 	andps  0x29f1(%rip),%xmm0        # cdc0 <msg.8+0x90>
    a3cf:	0f 2e 05 2e 1c 00 00 	ucomiss 0x1c2e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a3d6:	0f 87 24 08 00 00    	ja     ac00 <fwp_write+0xe10>
    a3dc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a3e0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a3e6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a3ed:	00 
    a3ee:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a3f2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3fe:	00 00 
    a400:	44 89 ee             	mov    %r13d,%esi
    a403:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a408:	4c 89 e7             	mov    %r12,%rdi
    a40b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a410:	e8 5b a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a415:	31 f6                	xor    %esi,%esi
    a417:	4c 89 e7             	mov    %r12,%rdi
    a41a:	e8 81 90 ff ff       	call   34a0 <strtof@plt>
    a41f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a424:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a427:	7a 02                	jp     a42b <fwp_write+0x63b>
    a429:	74 1c                	je     a447 <fwp_write+0x657>
    a42b:	41 83 c5 01          	add    $0x1,%r13d
    a42f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a433:	75 cb                	jne    a400 <fwp_write+0x610>
    a435:	be 09 00 00 00       	mov    $0x9,%esi
    a43a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a43f:	4c 89 e7             	mov    %r12,%rdi
    a442:	e8 29 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a447:	4c 89 e7             	mov    %r12,%rdi
    a44a:	e8 61 9d ff ff       	call   41b0 <fwp_finish_float>
    a44f:	e9 1c fa ff ff       	jmp    9e70 <fwp_write+0x80>
    a454:	0f 1f 40 00          	nopl   0x0(%rax)
    a458:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a45c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a460:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a467:	00 
    a468:	48 89 ef             	mov    %rbp,%rdi
    a46b:	e8 d0 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a470:	48 89 ef             	mov    %rbp,%rdi
    a473:	e8 c8 8f ff ff       	call   3440 <strlen@plt>
    a478:	48 89 ee             	mov    %rbp,%rsi
    a47b:	48 89 df             	mov    %rbx,%rdi
    a47e:	48 89 c2             	mov    %rax,%rdx
    a481:	e8 6a 9c ff ff       	call   40f0 <buf_put>
    a486:	e9 fb f9 ff ff       	jmp    9e86 <fwp_write+0x96>
    a48b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a490:	ba 06 00 00 00       	mov    $0x6,%edx
    a495:	48 8d 35 02 1e 00 00 	lea    0x1e02(%rip),%rsi        # c29e <_IO_stdin_used+0x29e>
    a49c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a4a2:	e8 49 9c ff ff       	call   40f0 <buf_put>
    a4a7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a4ae:	ff ff 7f 
    a4b1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a4b5:	0f 84 86 02 00 00    	je     a741 <fwp_write+0x951>
    a4bb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4c0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a4c4:	48 85 d2             	test   %rdx,%rdx
    a4c7:	0f 84 ae 00 00 00    	je     a57b <fwp_write+0x78b>
    a4cd:	8b 0a                	mov    (%rdx),%ecx
    a4cf:	83 f9 1c             	cmp    $0x1c,%ecx
    a4d2:	0f 84 58 06 00 00    	je     ab30 <fwp_write+0xd40>
    a4d8:	83 f9 1b             	cmp    $0x1b,%ecx
    a4db:	0f 87 9a 00 00 00    	ja     a57b <fwp_write+0x78b>
    a4e1:	be 01 00 00 00       	mov    $0x1,%esi
    a4e6:	48 d3 e6             	shl    %cl,%rsi
    a4e9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a4ef:	0f 85 4b 04 00 00    	jne    a940 <fwp_write+0xb50>
    a4f5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a4fb:	0f 85 0f 04 00 00    	jne    a910 <fwp_write+0xb20>
    a501:	83 e6 21             	and    $0x21,%esi
    a504:	74 75                	je     a57b <fwp_write+0x78b>
    a506:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a50b:	48 85 ff             	test   %rdi,%rdi
    a50e:	79 07                	jns    a517 <fwp_write+0x727>
    a510:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a514:	4c 01 ee             	add    %r13,%rsi
    a517:	48 0f be 3e          	movsbq (%rsi),%rdi
    a51b:	85 c9                	test   %ecx,%ecx
    a51d:	40 0f b6 f7          	movzbl %dil,%esi
    a521:	48 0f 44 f7          	cmove  %rdi,%rsi
    a525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a52c:	00 00 00 00 
    a530:	31 c9                	xor    %ecx,%ecx
    a532:	48 89 df             	mov    %rbx,%rdi
    a535:	49 83 c5 01          	add    $0x1,%r13
    a539:	e8 b2 f8 ff ff       	call   9df0 <fwp_write>
    a53e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a545:	ff ff 7f 
    a548:	48 23 55 00          	and    0x0(%rbp),%rdx
    a54c:	49 39 d5             	cmp    %rdx,%r13
    a54f:	0f 83 ec 01 00 00    	jae    a741 <fwp_write+0x951>
    a555:	ba 02 00 00 00       	mov    $0x2,%edx
    a55a:	48 89 df             	mov    %rbx,%rdi
    a55d:	48 8d 35 37 1d 00 00 	lea    0x1d37(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a564:	e8 87 9b ff ff       	call   40f0 <buf_put>
    a569:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a56e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a572:	48 85 d2             	test   %rdx,%rdx
    a575:	0f 85 52 ff ff ff    	jne    a4cd <fwp_write+0x6dd>
    a57b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a580:	48 85 ff             	test   %rdi,%rdi
    a583:	0f 88 cf 05 00 00    	js     ab58 <fwp_write+0xd68>
    a589:	48 8b 31             	mov    (%rcx),%rsi
    a58c:	eb a2                	jmp    a530 <fwp_write+0x740>
    a58e:	66 90                	xchg   %ax,%ax
    a590:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a597:	00 
    a598:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a59f:	00 00 
    a5a1:	0f 85 1e fd ff ff    	jne    a2c5 <fwp_write+0x4d5>
    a5a7:	ba 08 00 00 00       	mov    $0x8,%edx
    a5ac:	48 8d 35 b8 1c 00 00 	lea    0x1cb8(%rip),%rsi        # c26b <_IO_stdin_used+0x26b>
    a5b3:	e9 4b fa ff ff       	jmp    a003 <fwp_write+0x213>
    a5b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a5bf:	00 
    a5c0:	89 e8                	mov    %ebp,%eax
    a5c2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a5c9:	76 03                	jbe    a5ce <fwp_write+0x7de>
    a5cb:	8b 45 00             	mov    0x0(%rbp),%eax
    a5ce:	41 89 c6             	mov    %eax,%r14d
    a5d1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a5d6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a5db:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a5df:	4c 89 ef             	mov    %r13,%rdi
    a5e2:	e8 59 8e ff ff       	call   3440 <strlen@plt>
    a5e7:	4c 89 ee             	mov    %r13,%rsi
    a5ea:	48 89 df             	mov    %rbx,%rdi
    a5ed:	48 89 c2             	mov    %rax,%rdx
    a5f0:	e8 fb 9a ff ff       	call   40f0 <buf_put>
    a5f5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a5fa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a5fe:	85 f6                	test   %esi,%esi
    a600:	0f 8e 80 f8 ff ff    	jle    9e86 <fwp_write+0x96>
    a606:	45 31 ed             	xor    %r13d,%r13d
    a609:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a60e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a613:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a618:	ba 01 00 00 00       	mov    $0x1,%edx
    a61d:	4c 89 fe             	mov    %r15,%rsi
    a620:	48 89 04 24          	mov    %rax,(%rsp)
    a624:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a629:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a62d:	48 89 df             	mov    %rbx,%rdi
    a630:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a634:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a639:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a63e:	e8 ad 9a ff ff       	call   40f0 <buf_put>
    a643:	41 8b 06             	mov    (%r14),%eax
    a646:	83 f8 0e             	cmp    $0xe,%eax
    a649:	0f 84 71 02 00 00    	je     a8c0 <fwp_write+0xad0>
    a64f:	83 f8 10             	cmp    $0x10,%eax
    a652:	0f 84 38 02 00 00    	je     a890 <fwp_write+0xaa0>
    a658:	83 f8 0a             	cmp    $0xa,%eax
    a65b:	0f 84 7f 04 00 00    	je     aae0 <fwp_write+0xcf0>
    a661:	0f 8f f9 00 00 00    	jg     a760 <fwp_write+0x970>
    a667:	83 f8 03             	cmp    $0x3,%eax
    a66a:	0f 8f 50 04 00 00    	jg     aac0 <fwp_write+0xcd0>
    a670:	85 c0                	test   %eax,%eax
    a672:	78 10                	js     a684 <fwp_write+0x894>
    a674:	48 8b 04 24          	mov    (%rsp),%rax
    a678:	48 c1 e8 3f          	shr    $0x3f,%rax
    a67c:	85 c0                	test   %eax,%eax
    a67e:	0f 85 f9 00 00 00    	jne    a77d <fwp_write+0x98d>
    a684:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a689:	48 8b 34 24          	mov    (%rsp),%rsi
    a68d:	31 c9                	xor    %ecx,%ecx
    a68f:	48 89 df             	mov    %rbx,%rdi
    a692:	e8 59 f7 ff ff       	call   9df0 <fwp_write>
    a697:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a69c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a6a1:	49 83 c5 01          	add    $0x1,%r13
    a6a5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a6a9:	0f 8f 5f ff ff ff    	jg     a60e <fwp_write+0x81e>
    a6af:	e9 d2 f7 ff ff       	jmp    9e86 <fwp_write+0x96>
    a6b4:	0f 1f 40 00          	nopl   0x0(%rax)
    a6b8:	ba 06 00 00 00       	mov    $0x6,%edx
    a6bd:	48 8d 35 cd 1b 00 00 	lea    0x1bcd(%rip),%rsi        # c291 <_IO_stdin_used+0x291>
    a6c4:	45 31 ed             	xor    %r13d,%r13d
    a6c7:	e8 24 9a ff ff       	call   40f0 <buf_put>
    a6cc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a6d1:	75 19                	jne    a6ec <fwp_write+0x8fc>
    a6d3:	eb 6c                	jmp    a741 <fwp_write+0x951>
    a6d5:	0f 1f 00             	nopl   (%rax)
    a6d8:	ba 02 00 00 00       	mov    $0x2,%edx
    a6dd:	48 8d 35 b7 1b 00 00 	lea    0x1bb7(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a6e4:	48 89 df             	mov    %rbx,%rdi
    a6e7:	e8 04 9a ff ff       	call   40f0 <buf_put>
    a6ec:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a6f2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a6f7:	31 c0                	xor    %eax,%eax
    a6f9:	49 83 c5 01          	add    $0x1,%r13
    a6fd:	4c 8d 05 94 1b 00 00 	lea    0x1b94(%rip),%r8        # c298 <_IO_stdin_used+0x298>
    a704:	ba 02 00 00 00       	mov    $0x2,%edx
    a709:	be 00 02 00 00       	mov    $0x200,%esi
    a70e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a715:	00 
    a716:	e8 85 8c ff ff       	call   33a0 <__snprintf_chk@plt>
    a71b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a722:	00 
    a723:	e8 18 8d ff ff       	call   3440 <strlen@plt>
    a728:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a72f:	00 
    a730:	48 89 df             	mov    %rbx,%rdi
    a733:	48 89 c2             	mov    %rax,%rdx
    a736:	e8 b5 99 ff ff       	call   40f0 <buf_put>
    a73b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a73f:	72 97                	jb     a6d8 <fwp_write+0x8e8>
    a741:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a746:	ba 01 00 00 00       	mov    $0x1,%edx
    a74b:	48 89 df             	mov    %rbx,%rdi
    a74e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a753:	e8 98 99 ff ff       	call   40f0 <buf_put>
    a758:	e9 29 f7 ff ff       	jmp    9e86 <fwp_write+0x96>
    a75d:	0f 1f 00             	nopl   (%rax)
    a760:	83 f8 0b             	cmp    $0xb,%eax
    a763:	0f 85 1b ff ff ff    	jne    a684 <fwp_write+0x894>
    a769:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a76e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a772:	83 e0 01             	and    $0x1,%eax
    a775:	85 c0                	test   %eax,%eax
    a777:	0f 84 07 ff ff ff    	je     a684 <fwp_write+0x894>
    a77d:	4c 89 fe             	mov    %r15,%rsi
    a780:	48 89 df             	mov    %rbx,%rdi
    a783:	ba 01 00 00 00       	mov    $0x1,%edx
    a788:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a78d:	e8 5e 99 ff ff       	call   40f0 <buf_put>
    a792:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a797:	48 8b 34 24          	mov    (%rsp),%rsi
    a79b:	31 c9                	xor    %ecx,%ecx
    a79d:	48 89 df             	mov    %rbx,%rdi
    a7a0:	e8 4b f6 ff ff       	call   9df0 <fwp_write>
    a7a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a7aa:	4c 89 fe             	mov    %r15,%rsi
    a7ad:	48 89 df             	mov    %rbx,%rdi
    a7b0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a7b5:	e8 36 99 ff ff       	call   40f0 <buf_put>
    a7ba:	e9 d8 fe ff ff       	jmp    a697 <fwp_write+0x8a7>
    a7bf:	90                   	nop
    a7c0:	ba 01 00 00 00       	mov    $0x1,%edx
    a7c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7ca:	48 89 df             	mov    %rbx,%rdi
    a7cd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a7d2:	e8 19 99 ff ff       	call   40f0 <buf_put>
    a7d7:	e9 aa f6 ff ff       	jmp    9e86 <fwp_write+0x96>
    a7dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a7e0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7e5:	ba 01 00 00 00       	mov    $0x1,%edx
    a7ea:	48 89 df             	mov    %rbx,%rdi
    a7ed:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a7f2:	e8 f9 98 ff ff       	call   40f0 <buf_put>
    a7f7:	e9 8a f6 ff ff       	jmp    9e86 <fwp_write+0x96>
    a7fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a800:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a804:	48 8b 13             	mov    (%rbx),%rdx
    a807:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a80c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a810:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a814:	e9 6d f6 ff ff       	jmp    9e86 <fwp_write+0x96>
    a819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a820:	ba 02 00 00 00       	mov    $0x2,%edx
    a825:	48 8d 35 6f 1a 00 00 	lea    0x1a6f(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a82c:	48 89 df             	mov    %rbx,%rdi
    a82f:	e8 bc 98 ff ff       	call   40f0 <buf_put>
    a834:	e9 72 f8 ff ff       	jmp    a0ab <fwp_write+0x2bb>
    a839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a840:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a845:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a84a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a84e:	48 89 f7             	mov    %rsi,%rdi
    a851:	48 89 34 24          	mov    %rsi,(%rsp)
    a855:	e8 e6 8b ff ff       	call   3440 <strlen@plt>
    a85a:	48 8b 34 24          	mov    (%rsp),%rsi
    a85e:	48 89 df             	mov    %rbx,%rdi
    a861:	48 89 c2             	mov    %rax,%rdx
    a864:	e8 87 98 ff ff       	call   40f0 <buf_put>
    a869:	ba 03 00 00 00       	mov    $0x3,%edx
    a86e:	48 8d 35 49 1a 00 00 	lea    0x1a49(%rip),%rsi        # c2be <_IO_stdin_used+0x2be>
    a875:	48 89 df             	mov    %rbx,%rdi
    a878:	e8 73 98 ff ff       	call   40f0 <buf_put>
    a87d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a882:	e9 35 f8 ff ff       	jmp    a0bc <fwp_write+0x2cc>
    a887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a88e:	00 00 
    a890:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a895:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a899:	48 85 ff             	test   %rdi,%rdi
    a89c:	0f 84 e2 fd ff ff    	je     a684 <fwp_write+0x894>
    a8a2:	48 8d 35 ff 19 00 00 	lea    0x19ff(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    a8a9:	e8 72 8c ff ff       	call   3520 <strcmp@plt>
    a8ae:	85 c0                	test   %eax,%eax
    a8b0:	0f 95 c0             	setne  %al
    a8b3:	0f b6 c0             	movzbl %al,%eax
    a8b6:	e9 c1 fd ff ff       	jmp    a67c <fwp_write+0x88c>
    a8bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a8c0:	31 c0                	xor    %eax,%eax
    a8c2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a8c9:	00 
    a8ca:	0f 97 c0             	seta   %al
    a8cd:	e9 aa fd ff ff       	jmp    a67c <fwp_write+0x88c>
    a8d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8d8:	48 89 df             	mov    %rbx,%rdi
    a8db:	ba 02 00 00 00       	mov    $0x2,%edx
    a8e0:	48 8d 35 be 19 00 00 	lea    0x19be(%rip),%rsi        # c2a5 <_IO_stdin_used+0x2a5>
    a8e7:	e8 04 98 ff ff       	call   40f0 <buf_put>
    a8ec:	4c 89 e8             	mov    %r13,%rax
    a8ef:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a8f4:	31 c9                	xor    %ecx,%ecx
    a8f6:	48 c1 e0 04          	shl    $0x4,%rax
    a8fa:	48 89 df             	mov    %rbx,%rdi
    a8fd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a902:	e8 e9 f4 ff ff       	call   9df0 <fwp_write>
    a907:	e9 5e f6 ff ff       	jmp    9f6a <fwp_write+0x17a>
    a90c:	0f 1f 40 00          	nopl   0x0(%rax)
    a910:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a915:	48 85 ff             	test   %rdi,%rdi
    a918:	79 0c                	jns    a926 <fwp_write+0xb36>
    a91a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a921:	00 
    a922:	48 03 75 10          	add    0x10(%rbp),%rsi
    a926:	48 63 3e             	movslq (%rsi),%rdi
    a929:	83 f9 02             	cmp    $0x2,%ecx
    a92c:	89 fe                	mov    %edi,%esi
    a92e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a932:	e9 f9 fb ff ff       	jmp    a530 <fwp_write+0x740>
    a937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a93e:	00 00 
    a940:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a945:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a94a:	48 85 ff             	test   %rdi,%rdi
    a94d:	0f 88 0f 03 00 00    	js     ac62 <fwp_write+0xe72>
    a953:	49 0f bf 38          	movswq (%r8),%rdi
    a957:	83 f9 01             	cmp    $0x1,%ecx
    a95a:	0f b7 f7             	movzwl %di,%esi
    a95d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a961:	e9 ca fb ff ff       	jmp    a530 <fwp_write+0x740>
    a966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a96d:	00 00 00 
    a970:	ba 01 00 00 00       	mov    $0x1,%edx
    a975:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a97a:	48 83 c5 08          	add    $0x8,%rbp
    a97e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a983:	e8 68 97 ff ff       	call   40f0 <buf_put>
    a988:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a98d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a992:	4d 85 ed             	test   %r13,%r13
    a995:	75 46                	jne    a9dd <fwp_write+0xbed>
    a997:	e9 04 01 00 00       	jmp    aaa0 <fwp_write+0xcb0>
    a99c:	0f 1f 40 00          	nopl   0x0(%rax)
    a9a0:	41 80 f9 09          	cmp    $0x9,%r9b
    a9a4:	0f 84 d6 00 00 00    	je     aa80 <fwp_write+0xc90>
    a9aa:	41 80 f9 0a          	cmp    $0xa,%r9b
    a9ae:	0f 85 9c 00 00 00    	jne    aa50 <fwp_write+0xc60>
    a9b4:	ba 02 00 00 00       	mov    $0x2,%edx
    a9b9:	48 8d 35 c1 18 00 00 	lea    0x18c1(%rip),%rsi        # c281 <_IO_stdin_used+0x281>
    a9c0:	48 89 df             	mov    %rbx,%rdi
    a9c3:	e8 28 97 ff ff       	call   40f0 <buf_put>
    a9c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a9cf:	00 
    a9d0:	48 83 c5 01          	add    $0x1,%rbp
    a9d4:	49 39 ec             	cmp    %rbp,%r12
    a9d7:	0f 84 c3 00 00 00    	je     aaa0 <fwp_write+0xcb0>
    a9dd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a9e2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a9e6:	74 28                	je     aa10 <fwp_write+0xc20>
    a9e8:	7e b6                	jle    a9a0 <fwp_write+0xbb0>
    a9ea:	41 80 f9 22          	cmp    $0x22,%r9b
    a9ee:	74 40                	je     aa30 <fwp_write+0xc40>
    a9f0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a9f4:	75 5a                	jne    aa50 <fwp_write+0xc60>
    a9f6:	ba 02 00 00 00       	mov    $0x2,%edx
    a9fb:	48 8d 35 7c 18 00 00 	lea    0x187c(%rip),%rsi        # c27e <_IO_stdin_used+0x27e>
    aa02:	48 89 df             	mov    %rbx,%rdi
    aa05:	e8 e6 96 ff ff       	call   40f0 <buf_put>
    aa0a:	eb c4                	jmp    a9d0 <fwp_write+0xbe0>
    aa0c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa10:	ba 02 00 00 00       	mov    $0x2,%edx
    aa15:	48 8d 35 6b 18 00 00 	lea    0x186b(%rip),%rsi        # c287 <_IO_stdin_used+0x287>
    aa1c:	48 89 df             	mov    %rbx,%rdi
    aa1f:	e8 cc 96 ff ff       	call   40f0 <buf_put>
    aa24:	eb aa                	jmp    a9d0 <fwp_write+0xbe0>
    aa26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa2d:	00 00 00 
    aa30:	ba 02 00 00 00       	mov    $0x2,%edx
    aa35:	48 8d 35 3f 18 00 00 	lea    0x183f(%rip),%rsi        # c27b <_IO_stdin_used+0x27b>
    aa3c:	48 89 df             	mov    %rbx,%rdi
    aa3f:	e8 ac 96 ff ff       	call   40f0 <buf_put>
    aa44:	eb 8a                	jmp    a9d0 <fwp_write+0xbe0>
    aa46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa4d:	00 00 00 
    aa50:	41 80 f9 1f          	cmp    $0x1f,%r9b
    aa54:	0f 86 2e 01 00 00    	jbe    ab88 <fwp_write+0xd98>
    aa5a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    aa5e:	0f 84 24 01 00 00    	je     ab88 <fwp_write+0xd98>
    aa64:	ba 01 00 00 00       	mov    $0x1,%edx
    aa69:	4c 89 fe             	mov    %r15,%rsi
    aa6c:	48 89 df             	mov    %rbx,%rdi
    aa6f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    aa74:	e8 77 96 ff ff       	call   40f0 <buf_put>
    aa79:	e9 52 ff ff ff       	jmp    a9d0 <fwp_write+0xbe0>
    aa7e:	66 90                	xchg   %ax,%ax
    aa80:	ba 02 00 00 00       	mov    $0x2,%edx
    aa85:	48 8d 35 f8 17 00 00 	lea    0x17f8(%rip),%rsi        # c284 <_IO_stdin_used+0x284>
    aa8c:	48 89 df             	mov    %rbx,%rdi
    aa8f:	e8 5c 96 ff ff       	call   40f0 <buf_put>
    aa94:	e9 37 ff ff ff       	jmp    a9d0 <fwp_write+0xbe0>
    aa99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aaa0:	ba 01 00 00 00       	mov    $0x1,%edx
    aaa5:	4c 89 fe             	mov    %r15,%rsi
    aaa8:	48 89 df             	mov    %rbx,%rdi
    aaab:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aab0:	e8 3b 96 ff ff       	call   40f0 <buf_put>
    aab5:	e9 cc f3 ff ff       	jmp    9e86 <fwp_write+0x96>
    aaba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aac0:	83 f8 04             	cmp    $0x4,%eax
    aac3:	0f 85 bb fb ff ff    	jne    a684 <fwp_write+0x894>
    aac9:	48 8b 04 24          	mov    (%rsp),%rax
    aacd:	48 8b 40 08          	mov    0x8(%rax),%rax
    aad1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    aad6:	48 c1 e8 3f          	shr    $0x3f,%rax
    aada:	e9 96 fc ff ff       	jmp    a775 <fwp_write+0x985>
    aadf:	90                   	nop
    aae0:	8b 0c 24             	mov    (%rsp),%ecx
    aae3:	31 c0                	xor    %eax,%eax
    aae5:	85 c9                	test   %ecx,%ecx
    aae7:	0f 98 c0             	sets   %al
    aaea:	e9 86 fc ff ff       	jmp    a775 <fwp_write+0x985>
    aaef:	90                   	nop
    aaf0:	48 f7 d8             	neg    %rax
    aaf3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    aafa:	00 
    aafb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    ab02:	2d 
    ab03:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab0a:	00 
    ab0b:	48 83 d2 00          	adc    $0x0,%rdx
    ab0f:	48 89 c6             	mov    %rax,%rsi
    ab12:	48 f7 da             	neg    %rdx
    ab15:	e8 26 8f ff ff       	call   3a40 <fwp_fmt_u128>
    ab1a:	e9 51 f3 ff ff       	jmp    9e70 <fwp_write+0x80>
    ab1f:	90                   	nop
    ab20:	b8 7d 00 00 00       	mov    $0x7d,%eax
    ab25:	e9 c3 f5 ff ff       	jmp    a0ed <fwp_write+0x2fd>
    ab2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab30:	4c 89 e9             	mov    %r13,%rcx
    ab33:	48 c1 e1 04          	shl    $0x4,%rcx
    ab37:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    ab3c:	48 85 ff             	test   %rdi,%rdi
    ab3f:	0f 89 eb f9 ff ff    	jns    a530 <fwp_write+0x740>
    ab45:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ab49:	48 89 ce             	mov    %rcx,%rsi
    ab4c:	e9 df f9 ff ff       	jmp    a530 <fwp_write+0x740>
    ab51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab58:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    ab5f:	00 
    ab60:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ab64:	e9 20 fa ff ff       	jmp    a589 <fwp_write+0x799>
    ab69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab70:	ba 02 00 00 00       	mov    $0x2,%edx
    ab75:	48 8d 35 ca 16 00 00 	lea    0x16ca(%rip),%rsi        # c246 <_IO_stdin_used+0x246>
    ab7c:	e9 2d f7 ff ff       	jmp    a2ae <fwp_write+0x4be>
    ab81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab88:	4c 8d 05 fb 16 00 00 	lea    0x16fb(%rip),%r8        # c28a <_IO_stdin_used+0x28a>
    ab8f:	b9 10 00 00 00       	mov    $0x10,%ecx
    ab94:	31 c0                	xor    %eax,%eax
    ab96:	ba 02 00 00 00       	mov    $0x2,%edx
    ab9b:	be 10 00 00 00       	mov    $0x10,%esi
    aba0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aba7:	00 
    aba8:	e8 f3 87 ff ff       	call   33a0 <__snprintf_chk@plt>
    abad:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    abb4:	00 
    abb5:	e8 86 88 ff ff       	call   3440 <strlen@plt>
    abba:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    abc1:	00 
    abc2:	48 89 df             	mov    %rbx,%rdi
    abc5:	48 89 c2             	mov    %rax,%rdx
    abc8:	e8 23 95 ff ff       	call   40f0 <buf_put>
    abcd:	e9 fe fd ff ff       	jmp    a9d0 <fwp_write+0xbe0>
    abd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abd8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    abdc:	48 8d 35 5d 16 00 00 	lea    0x165d(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    abe3:	48 8d 05 55 16 00 00 	lea    0x1655(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    abea:	4c 89 e7             	mov    %r12,%rdi
    abed:	66 0f 2f c8          	comisd %xmm0,%xmm1
    abf1:	48 0f 46 f0          	cmovbe %rax,%rsi
    abf5:	e8 e6 87 ff ff       	call   33e0 <strcpy@plt>
    abfa:	e9 71 f2 ff ff       	jmp    9e70 <fwp_write+0x80>
    abff:	90                   	nop
    ac00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac04:	48 8d 35 35 16 00 00 	lea    0x1635(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    ac0b:	48 8d 05 2d 16 00 00 	lea    0x162d(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    ac12:	0f 2f c8             	comiss %xmm0,%xmm1
    ac15:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac1c:	00 
    ac1d:	4c 89 e7             	mov    %r12,%rdi
    ac20:	48 0f 46 f0          	cmovbe %rax,%rsi
    ac24:	e8 b7 87 ff ff       	call   33e0 <strcpy@plt>
    ac29:	e9 42 f2 ff ff       	jmp    9e70 <fwp_write+0x80>
    ac2e:	66 90                	xchg   %ax,%ax
    ac30:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ac35:	45 85 c0             	test   %r8d,%r8d
    ac38:	75 34                	jne    ac6e <fwp_write+0xe7e>
    ac3a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ac41:	00 
    ac42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ac49:	00 00 
    ac4b:	0f 85 74 f6 ff ff    	jne    a2c5 <fwp_write+0x4d5>
    ac51:	ba 02 00 00 00       	mov    $0x2,%edx
    ac56:	48 8d 35 5e 16 00 00 	lea    0x165e(%rip),%rsi        # c2bb <_IO_stdin_used+0x2bb>
    ac5d:	e9 a1 f3 ff ff       	jmp    a003 <fwp_write+0x213>
    ac62:	48 03 75 10          	add    0x10(%rbp),%rsi
    ac66:	49 89 f0             	mov    %rsi,%r8
    ac69:	e9 e5 fc ff ff       	jmp    a953 <fwp_write+0xb63>
    ac6e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ac73:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ac78:	85 ff                	test   %edi,%edi
    ac7a:	0f 84 fa f3 ff ff    	je     a07a <fwp_write+0x28a>
    ac80:	ba 01 00 00 00       	mov    $0x1,%edx
    ac85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ac8a:	48 89 df             	mov    %rbx,%rdi
    ac8d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ac92:	e8 59 94 ff ff       	call   40f0 <buf_put>
    ac97:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ac9c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aca1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    aca7:	85 c0                	test   %eax,%eax
    aca9:	0f 8f f0 f3 ff ff    	jg     a09f <fwp_write+0x2af>
    acaf:	e9 34 f4 ff ff       	jmp    a0e8 <fwp_write+0x2f8>
    acb4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    acb8:	49 89 c5             	mov    %rax,%r13
    acbb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    acc0:	49 89 c4             	mov    %rax,%r12
    acc3:	49 c1 fd 3f          	sar    $0x3f,%r13
    acc7:	4c 09 e8             	or     %r13,%rax
    acca:	0f 84 a7 00 00 00    	je     ad77 <fwp_write+0xf87>
    acd0:	48 8d 2d 49 37 00 00 	lea    0x3749(%rip),%rbp        # e420 <units.5>
    acd7:	4d 89 e7             	mov    %r12,%r15
    acda:	48 8b 45 08          	mov    0x8(%rbp),%rax
    acde:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ace3:	4c 89 ff             	mov    %r15,%rdi
    ace6:	4c 89 ee             	mov    %r13,%rsi
    ace9:	44 89 0c 24          	mov    %r9d,(%rsp)
    aced:	48 99                	cqto
    acef:	48 89 d1             	mov    %rdx,%rcx
    acf2:	48 89 c2             	mov    %rax,%rdx
    acf5:	e8 06 10 00 00       	call   bd00 <__divmodti4>
    acfa:	44 8b 0c 24          	mov    (%rsp),%r9d
    acfe:	48 89 c1             	mov    %rax,%rcx
    ad01:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ad06:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ad0b:	0f 84 94 00 00 00    	je     ada5 <fwp_write+0xfb5>
    ad11:	41 83 c1 01          	add    $0x1,%r9d
    ad15:	48 83 c5 10          	add    $0x10,%rbp
    ad19:	41 83 f9 05          	cmp    $0x5,%r9d
    ad1d:	75 bb                	jne    acda <fwp_write+0xeea>
    ad1f:	4d 85 ed             	test   %r13,%r13
    ad22:	79 53                	jns    ad77 <fwp_write+0xf87>
    ad24:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ad29:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad2e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad33:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad38:	48 99                	cqto
    ad3a:	48 f7 d8             	neg    %rax
    ad3d:	48 83 d2 00          	adc    $0x0,%rdx
    ad41:	48 89 c6             	mov    %rax,%rsi
    ad44:	48 f7 da             	neg    %rdx
    ad47:	e8 f4 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ad4c:	49 89 e8             	mov    %rbp,%r8
    ad4f:	ba 00 02 00 00       	mov    $0x200,%edx
    ad54:	be 02 00 00 00       	mov    $0x2,%esi
    ad59:	31 c0                	xor    %eax,%eax
    ad5b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad62:	00 
    ad63:	48 8d 0d 4c 15 00 00 	lea    0x154c(%rip),%rcx        # c2b6 <_IO_stdin_used+0x2b6>
    ad6a:	4c 89 e7             	mov    %r12,%rdi
    ad6d:	e8 4e 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    ad72:	e9 f9 f0 ff ff       	jmp    9e70 <fwp_write+0x80>
    ad77:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad7c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ad81:	31 d2                	xor    %edx,%edx
    ad83:	48 89 ef             	mov    %rbp,%rdi
    ad86:	e8 b5 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ad8b:	eb bf                	jmp    ad4c <fwp_write+0xf5c>
    ad8d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ad94:	4e 61 4e 00 
    ad98:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad9f:	00 
    ada0:	e9 cb f0 ff ff       	jmp    9e70 <fwp_write+0x80>
    ada5:	44 89 0c 24          	mov    %r9d,(%rsp)
    ada9:	48 89 c8             	mov    %rcx,%rax
    adac:	48 85 d2             	test   %rdx,%rdx
    adaf:	78 51                	js     ae02 <fwp_write+0x1012>
    adb1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    adb6:	48 89 c6             	mov    %rax,%rsi
    adb9:	48 89 ef             	mov    %rbp,%rdi
    adbc:	e8 7f 8c ff ff       	call   3a40 <fwp_fmt_u128>
    adc1:	44 8b 0c 24          	mov    (%rsp),%r9d
    adc5:	49 63 c1             	movslq %r9d,%rax
    adc8:	49 89 e8             	mov    %rbp,%r8
    adcb:	ba 00 02 00 00       	mov    $0x200,%edx
    add0:	be 02 00 00 00       	mov    $0x2,%esi
    add5:	48 c1 e0 04          	shl    $0x4,%rax
    add9:	48 8d 3d 40 36 00 00 	lea    0x3640(%rip),%rdi        # e420 <units.5>
    ade0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ade7:	00 
    ade8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    adec:	48 8d 0d be 14 00 00 	lea    0x14be(%rip),%rcx        # c2b1 <_IO_stdin_used+0x2b1>
    adf3:	4c 89 e7             	mov    %r12,%rdi
    adf6:	31 c0                	xor    %eax,%eax
    adf8:	e8 c3 88 ff ff       	call   36c0 <__sprintf_chk@plt>
    adfd:	e9 6e f0 ff ff       	jmp    9e70 <fwp_write+0x80>
    ae02:	48 f7 d8             	neg    %rax
    ae05:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ae0a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ae0f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae14:	48 83 d2 00          	adc    $0x0,%rdx
    ae18:	48 89 c6             	mov    %rax,%rsi
    ae1b:	48 f7 da             	neg    %rdx
    ae1e:	e8 1d 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ae23:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae27:	eb 9c                	jmp    adc5 <fwp_write+0xfd5>
    ae29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ae30 <fwp_main_thread>:
    ae30:	f3 0f 1e fa          	endbr64
    ae34:	41 57                	push   %r15
    ae36:	41 56                	push   %r14
    ae38:	41 55                	push   %r13
    ae3a:	41 54                	push   %r12
    ae3c:	55                   	push   %rbp
    ae3d:	53                   	push   %rbx
    ae3e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    ae45:	8b 3d 99 ed 05 00    	mov    0x5ed99(%rip),%edi        # 69be4 <fwp_heap+0x13a4>
    ae4b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ae52:	00 00 
    ae54:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    ae5b:	00 
    ae5c:	31 c0                	xor    %eax,%eax
    ae5e:	85 ff                	test   %edi,%edi
    ae60:	0f 84 1a 07 00 00    	je     b580 <fwp_main_thread+0x750>
    ae66:	8b 35 7c ed 05 00    	mov    0x5ed7c(%rip),%esi        # 69be8 <fwp_heap+0x13a8>
    ae6c:	85 f6                	test   %esi,%esi
    ae6e:	0f 85 1f 07 00 00    	jne    b593 <fwp_main_thread+0x763>
    ae74:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae79:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    ae7e:	31 f6                	xor    %esi,%esi
    ae80:	48 c7 05 55 d3 05 00 	movq   $0x40000000,0x5d355(%rip)        # 681e0 <fwp_main_stack_size>
    ae87:	00 00 00 40 
    ae8b:	48 8d 05 0e 52 00 00 	lea    0x520e(%rip),%rax        # 100a0 <alt.9>
    ae92:	48 89 ef             	mov    %rbp,%rdi
    ae95:	48 89 1d 4c d3 05 00 	mov    %rbx,0x5d34c(%rip)        # 681e8 <fwp_main_stack_top>
    ae9c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    aea1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    aea8:	01 00 
    aeaa:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    aeb1:	00 
    aeb2:	e8 e9 87 ff ff       	call   36a0 <sigaltstack@plt>
    aeb7:	85 c0                	test   %eax,%eax
    aeb9:	0f 85 fc 0d 00 00    	jne    bcbb <fwp_main_thread+0xe8b>
    aebf:	31 c0                	xor    %eax,%eax
    aec1:	b9 12 00 00 00       	mov    $0x12,%ecx
    aec6:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    aecd:	00 
    aece:	f3 48 ab             	rep stos %rax,(%rdi)
    aed1:	48 8d 05 68 8e ff ff 	lea    -0x7198(%rip),%rax        # 3d40 <fwp_segv>
    aed8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    aedf:	00 
    aee0:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    aee7:	04 00 00 08 
    aeeb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    aef2:	00 
    aef3:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
    aefa:	00 
    aefb:	e8 60 86 ff ff       	call   3560 <sigemptyset@plt>
    af00:	85 c0                	test   %eax,%eax
    af02:	0f 85 b3 0d 00 00    	jne    bcbb <fwp_main_thread+0xe8b>
    af08:	31 d2                	xor    %edx,%edx
    af0a:	4c 89 ee             	mov    %r13,%rsi
    af0d:	bf 0b 00 00 00       	mov    $0xb,%edi
    af12:	e8 d9 84 ff ff       	call   33f0 <sigaction@plt>
    af17:	85 c0                	test   %eax,%eax
    af19:	0f 85 9c 0d 00 00    	jne    bcbb <fwp_main_thread+0xe8b>
    af1f:	31 d2                	xor    %edx,%edx
    af21:	4c 89 ee             	mov    %r13,%rsi
    af24:	bf 07 00 00 00       	mov    $0x7,%edi
    af29:	e8 c2 84 ff ff       	call   33f0 <sigaction@plt>
    af2e:	85 c0                	test   %eax,%eax
    af30:	0f 85 85 0d 00 00    	jne    bcbb <fwp_main_thread+0xe8b>
    af36:	48 8b 05 23 ed 05 00 	mov    0x5ed23(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    af3d:	48 85 c0             	test   %rax,%rax
    af40:	0f 88 1a 06 00 00    	js     b560 <fwp_main_thread+0x730>
    af46:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af4a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    af4f:	48 8d 3d ca 92 ff ff 	lea    -0x6d36(%rip),%rdi        # 4220 <ad_raw_report>
    af56:	f2 0f 11 05 8a f5 05 	movsd  %xmm0,0x5f58a(%rip)        # 6a4e8 <iteration_start_charge>
    af5d:	00 
    af5e:	c7 05 a0 f5 05 00 01 	movl   $0x1,0x5f5a0(%rip)        # 6a508 <iteration_active>
    af65:	00 00 00 
    af68:	e8 a3 0f 00 00       	call   bf10 <atexit>
    af6d:	85 c0                	test   %eax,%eax
    af6f:	0f 85 52 0d 00 00    	jne    bcc7 <fwp_main_thread+0xe97>
    af75:	8b 0d 15 51 00 00    	mov    0x5115(%rip),%ecx        # 10090 <st.7>
    af7b:	85 c9                	test   %ecx,%ecx
    af7d:	0f 84 25 06 00 00    	je     b5a8 <fwp_main_thread+0x778>
    af83:	48 8b 2d 96 d8 05 00 	mov    0x5d896(%rip),%rbp        # 68820 <fwp_cur>
    af8a:	48 85 ed             	test   %rbp,%rbp
    af8d:	0f 84 bd 01 00 00    	je     b150 <fwp_main_thread+0x320>
    af93:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    af98:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    af9c:	48 89 eb             	mov    %rbp,%rbx
    af9f:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    afa4:	0f 84 41 01 00 00    	je     b0eb <fwp_main_thread+0x2bb>
    afaa:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    afaf:	0f 84 9b 02 00 00    	je     b250 <fwp_main_thread+0x420>
    afb5:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    afb9:	0f 84 71 02 00 00    	je     b230 <fwp_main_thread+0x400>
    afbf:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    afc3:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    afc7:	0f 85 03 03 00 00    	jne    b2d0 <fwp_main_thread+0x4a0>
    afcd:	48 8b 43 60          	mov    0x60(%rbx),%rax
    afd1:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    afd8:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    afdc:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    afe3:	00 00 00 00 
    afe7:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    afee:	48 85 d2             	test   %rdx,%rdx
    aff1:	74 07                	je     affa <fwp_main_thread+0x1ca>
    aff3:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    affa:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    affe:	48 85 c0             	test   %rax,%rax
    b001:	74 34                	je     b037 <fwp_main_thread+0x207>
    b003:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b007:	48 8b 05 ea d7 05 00 	mov    0x5d7ea(%rip),%rax        # 687f8 <fwp_timers>
    b00e:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b012:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b019:	00 00 00 00 
    b01d:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b024:	48 85 c0             	test   %rax,%rax
    b027:	74 07                	je     b030 <fwp_main_thread+0x200>
    b029:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b030:	48 89 1d c1 d7 05 00 	mov    %rbx,0x5d7c1(%rip)        # 687f8 <fwp_timers>
    b037:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b03b:	e8 10 c9 ff ff       	call   7950 <fwp_block>
    b040:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b047:	48 85 c9             	test   %rcx,%rcx
    b04a:	74 47                	je     b093 <fwp_main_thread+0x263>
    b04c:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b053:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b05a:	48 85 d2             	test   %rdx,%rdx
    b05d:	0f 84 ad 02 00 00    	je     b310 <fwp_main_thread+0x4e0>
    b063:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b06a:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b071:	48 85 c0             	test   %rax,%rax
    b074:	74 07                	je     b07d <fwp_main_thread+0x24d>
    b076:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b07d:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b084:	00 00 00 00 
    b088:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b08c:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b093:	48 8b 0d 86 d7 05 00 	mov    0x5d786(%rip),%rcx        # 68820 <fwp_cur>
    b09a:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b09e:	0f 84 1c 02 00 00    	je     b2c0 <fwp_main_thread+0x490>
    b0a4:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b0ab:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b0b2:	48 85 d2             	test   %rdx,%rdx
    b0b5:	0f 84 95 04 00 00    	je     b550 <fwp_main_thread+0x720>
    b0bb:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b0c2:	48 85 c0             	test   %rax,%rax
    b0c5:	74 07                	je     b0ce <fwp_main_thread+0x29e>
    b0c7:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b0ce:	66 0f ef db          	pxor   %xmm3,%xmm3
    b0d2:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b0d6:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b0dd:	48 89 cb             	mov    %rcx,%rbx
    b0e0:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b0e5:	0f 85 bf fe ff ff    	jne    afaa <fwp_main_thread+0x17a>
    b0eb:	48 83 3d c5 f3 05 00 	cmpq   $0x0,0x5f3c5(%rip)        # 6a4b8 <fwp_state_len>
    b0f2:	00 
    b0f3:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b0f7:	74 67                	je     b160 <fwp_main_thread+0x330>
    b0f9:	48 39 1d 18 d7 05 00 	cmp    %rbx,0x5d718(%rip)        # 68818 <fwp_root>
    b100:	c7 05 96 4f 01 00 00 	movl   $0x0,0x14f96(%rip)        # 200a0 <fwp_exit_code>
    b107:	00 00 00 
    b10a:	0f 85 e5 0b 00 00    	jne    bcf5 <fwp_main_thread+0xec5>
    b110:	48 85 db             	test   %rbx,%rbx
    b113:	0f 84 1f 02 00 00    	je     b338 <fwp_main_thread+0x508>
    b119:	48 8b 15 c8 d6 05 00 	mov    0x5d6c8(%rip),%rdx        # 687e8 <fwp_tasks_active>
    b120:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b124:	48 85 d2             	test   %rdx,%rdx
    b127:	0f 84 0b 02 00 00    	je     b338 <fwp_main_thread+0x508>
    b12d:	0f 1f 00             	nopl   (%rax)
    b130:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b134:	75 08                	jne    b13e <fwp_main_thread+0x30e>
    b136:	48 89 d7             	mov    %rdx,%rdi
    b139:	e8 f2 8f ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b13e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b145:	48 85 d2             	test   %rdx,%rdx
    b148:	75 e6                	jne    b130 <fwp_main_thread+0x300>
    b14a:	e9 ae 00 00 00       	jmp    b1fd <fwp_main_thread+0x3cd>
    b14f:	90                   	nop
    b150:	48 83 3d 60 f3 05 00 	cmpq   $0x0,0x5f360(%rip)        # 6a4b8 <fwp_state_len>
    b157:	00 
    b158:	0f 85 c2 01 00 00    	jne    b320 <fwp_main_thread+0x4f0>
    b15e:	31 db                	xor    %ebx,%ebx
    b160:	48 83 3d 40 f3 05 00 	cmpq   $0x0,0x5f340(%rip)        # 6a4a8 <fwp_state_owners>
    b167:	00 
    b168:	75 8f                	jne    b0f9 <fwp_main_thread+0x2c9>
    b16a:	48 8b 3d 4f f3 05 00 	mov    0x5f34f(%rip),%rdi        # 6a4c0 <fwp_state>
    b171:	e8 fa a8 ff ff       	call   5a70 <fwp_mem_free>
    b176:	48 c7 05 3f f3 05 00 	movq   $0x0,0x5f33f(%rip)        # 6a4c0 <fwp_state>
    b17d:	00 00 00 00 
    b181:	48 c7 05 24 f3 05 00 	movq   $0x0,0x5f324(%rip)        # 6a4b0 <fwp_state_cap>
    b188:	00 00 00 00 
    b18c:	48 85 db             	test   %rbx,%rbx
    b18f:	0f 84 2d 0a 00 00    	je     bbc2 <fwp_main_thread+0xd92>
    b195:	48 39 1d 7c d6 05 00 	cmp    %rbx,0x5d67c(%rip)        # 68818 <fwp_root>
    b19c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b1a3:	00 00 00 00 
    b1a7:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b1ae:	00 00 00 00 
    b1b2:	c7 05 e4 4e 01 00 00 	movl   $0x0,0x14ee4(%rip)        # 200a0 <fwp_exit_code>
    b1b9:	00 00 00 
    b1bc:	0f 84 57 ff ff ff    	je     b119 <fwp_main_thread+0x2e9>
    b1c2:	e9 89 85 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b1c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b1ce:	00 00 
    b1d0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b1d7:	48 89 1d 22 d6 05 00 	mov    %rbx,0x5d622(%rip)        # 68800 <fwp_ready_tail>
    b1de:	e8 6d c7 ff ff       	call   7950 <fwp_block>
    b1e3:	e8 68 c5 ff ff       	call   7750 <fwp_free_zombie>
    b1e8:	48 83 3d f8 d5 05 00 	cmpq   $0x0,0x5d5f8(%rip)        # 687e8 <fwp_tasks_active>
    b1ef:	00 
    b1f0:	0f 84 42 01 00 00    	je     b338 <fwp_main_thread+0x508>
    b1f6:	48 8b 1d 1b d6 05 00 	mov    0x5d61b(%rip),%rbx        # 68818 <fwp_root>
    b1fd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b201:	75 db                	jne    b1de <fwp_main_thread+0x3ae>
    b203:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b207:	75 d5                	jne    b1de <fwp_main_thread+0x3ae>
    b209:	48 8b 05 f0 d5 05 00 	mov    0x5d5f0(%rip),%rax        # 68800 <fwp_ready_tail>
    b210:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b214:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b21b:	00 00 00 00 
    b21f:	48 85 c0             	test   %rax,%rax
    b222:	75 ac                	jne    b1d0 <fwp_main_thread+0x3a0>
    b224:	48 89 1d dd d5 05 00 	mov    %rbx,0x5d5dd(%rip)        # 68808 <fwp_ready_head>
    b22b:	eb aa                	jmp    b1d7 <fwp_main_thread+0x3a7>
    b22d:	0f 1f 00             	nopl   (%rax)
    b230:	e8 8b 93 ff ff       	call   45c0 <fwp_now_ns>
    b235:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b239:	7c 15                	jl     b250 <fwp_main_thread+0x420>
    b23b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b23f:	75 0f                	jne    b250 <fwp_main_thread+0x420>
    b241:	48 89 ef             	mov    %rbp,%rdi
    b244:	e8 e7 8e ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b250:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b254:	0f 85 65 fd ff ff    	jne    afbf <fwp_main_thread+0x18f>
    b25a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b25e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b262:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b266:	0f 85 65 fd ff ff    	jne    afd1 <fwp_main_thread+0x1a1>
    b26c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b270:	48 85 c9             	test   %rcx,%rcx
    b273:	0f 84 58 fd ff ff    	je     afd1 <fwp_main_thread+0x1a1>
    b279:	48 39 c8             	cmp    %rcx,%rax
    b27c:	48 89 ce             	mov    %rcx,%rsi
    b27f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b286:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b28a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b291:	00 00 00 00 
    b295:	48 0f 4e f0          	cmovle %rax,%rsi
    b299:	48 85 c0             	test   %rax,%rax
    b29c:	48 89 c8             	mov    %rcx,%rax
    b29f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b2a6:	48 0f 45 c6          	cmovne %rsi,%rax
    b2aa:	48 85 d2             	test   %rdx,%rdx
    b2ad:	74 07                	je     b2b6 <fwp_main_thread+0x486>
    b2af:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b2b6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b2ba:	e9 44 fd ff ff       	jmp    b003 <fwp_main_thread+0x1d3>
    b2bf:	90                   	nop
    b2c0:	48 89 cb             	mov    %rcx,%rbx
    b2c3:	e9 d7 fc ff ff       	jmp    af9f <fwp_main_thread+0x16f>
    b2c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b2cf:	00 
    b2d0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b2d4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b2db:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b2e2:	00 00 00 00 
    b2e6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b2ed:	48 85 c0             	test   %rax,%rax
    b2f0:	0f 84 4a 08 00 00    	je     bb40 <fwp_main_thread+0xd10>
    b2f6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b2fd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b301:	e9 31 fd ff ff       	jmp    b037 <fwp_main_thread+0x207>
    b306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b30d:	00 00 00 
    b310:	48 89 01             	mov    %rax,(%rcx)
    b313:	e9 59 fd ff ff       	jmp    b071 <fwp_main_thread+0x241>
    b318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b31f:	00 
    b320:	48 83 3d f0 d4 05 00 	cmpq   $0x0,0x5d4f0(%rip)        # 68818 <fwp_root>
    b327:	00 
    b328:	c7 05 6e 4d 01 00 00 	movl   $0x0,0x14d6e(%rip)        # 200a0 <fwp_exit_code>
    b32f:	00 00 00 
    b332:	0f 85 b8 09 00 00    	jne    bcf0 <fwp_main_thread+0xec0>
    b338:	e8 13 c4 ff ff       	call   7750 <fwp_free_zombie>
    b33d:	48 83 3d c3 d4 05 00 	cmpq   $0x0,0x5d4c3(%rip)        # 68808 <fwp_ready_head>
    b344:	00 
    b345:	0f 85 05 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b34b:	48 83 3d a5 d4 05 00 	cmpq   $0x0,0x5d4a5(%rip)        # 687f8 <fwp_timers>
    b352:	00 
    b353:	0f 85 f7 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b359:	8b 05 95 ce 05 00    	mov    0x5ce95(%rip),%eax        # 681f4 <fwp_stack_pool_n>
    b35f:	85 c0                	test   %eax,%eax
    b361:	74 3a                	je     b39d <fwp_main_thread+0x56d>
    b363:	83 e8 01             	sub    $0x1,%eax
    b366:	4c 8d 25 93 ce 05 00 	lea    0x5ce93(%rip),%r12        # 68200 <fwp_stack_pool>
    b36d:	48 63 d8             	movslq %eax,%rbx
    b370:	89 c0                	mov    %eax,%eax
    b372:	48 89 da             	mov    %rbx,%rdx
    b375:	48 29 c2             	sub    %rax,%rdx
    b378:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b37c:	0f 1f 40 00          	nopl   0x0(%rax)
    b380:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b384:	89 1d 6a ce 05 00    	mov    %ebx,0x5ce6a(%rip)        # 681f4 <fwp_stack_pool_n>
    b38a:	be 00 00 00 10       	mov    $0x10000000,%esi
    b38f:	48 83 eb 01          	sub    $0x1,%rbx
    b393:	e8 28 82 ff ff       	call   35c0 <munmap@plt>
    b398:	48 39 dd             	cmp    %rbx,%rbp
    b39b:	75 e3                	jne    b380 <fwp_main_thread+0x550>
    b39d:	8b 3d 75 4c 00 00    	mov    0x4c75(%rip),%edi        # 10018 <fwp_epfd>
    b3a3:	85 ff                	test   %edi,%edi
    b3a5:	78 05                	js     b3ac <fwp_main_thread+0x57c>
    b3a7:	e8 14 81 ff ff       	call   34c0 <close@plt>
    b3ac:	4c 8b 25 4d d0 05 00 	mov    0x5d04d(%rip),%r12        # 68400 <fwp_nfdws>
    b3b3:	48 8b 2d 4e d0 05 00 	mov    0x5d04e(%rip),%rbp        # 68408 <fwp_fdws>
    b3ba:	31 db                	xor    %ebx,%ebx
    b3bc:	c7 05 52 4c 00 00 ff 	movl   $0xffffffff,0x4c52(%rip)        # 10018 <fwp_epfd>
    b3c3:	ff ff ff 
    b3c6:	4d 85 e4             	test   %r12,%r12
    b3c9:	74 32                	je     b3fd <fwp_main_thread+0x5cd>
    b3cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b3d0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b3d5:	48 85 ff             	test   %rdi,%rdi
    b3d8:	74 1a                	je     b3f4 <fwp_main_thread+0x5c4>
    b3da:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b3de:	0f 85 6c 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3e4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b3e9:	0f 85 61 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3ef:	e8 7c a6 ff ff       	call   5a70 <fwp_mem_free>
    b3f4:	48 83 c3 01          	add    $0x1,%rbx
    b3f8:	49 39 dc             	cmp    %rbx,%r12
    b3fb:	75 d3                	jne    b3d0 <fwp_main_thread+0x5a0>
    b3fd:	48 89 ef             	mov    %rbp,%rdi
    b400:	e8 6b a6 ff ff       	call   5a70 <fwp_mem_free>
    b405:	48 8b 15 0c d4 05 00 	mov    0x5d40c(%rip),%rdx        # 68818 <fwp_root>
    b40c:	48 c7 05 f1 cf 05 00 	movq   $0x0,0x5cff1(%rip)        # 68408 <fwp_fdws>
    b413:	00 00 00 00 
    b417:	48 c7 05 de cf 05 00 	movq   $0x0,0x5cfde(%rip)        # 68400 <fwp_nfdws>
    b41e:	00 00 00 00 
    b422:	48 85 d2             	test   %rdx,%rdx
    b425:	74 4e                	je     b475 <fwp_main_thread+0x645>
    b427:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b42c:	0f 85 1e 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b432:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b439:	00 
    b43a:	0f 85 10 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b440:	48 83 3d 70 f0 05 00 	cmpq   $0x0,0x5f070(%rip)        # 6a4b8 <fwp_state_len>
    b447:	00 
    b448:	0f 85 02 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b44e:	48 83 3d 52 f0 05 00 	cmpq   $0x0,0x5f052(%rip)        # 6a4a8 <fwp_state_owners>
    b455:	00 
    b456:	0f 85 f4 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b45c:	b9 79 00 00 00       	mov    $0x79,%ecx
    b461:	31 c0                	xor    %eax,%eax
    b463:	48 8d 3d b6 cf 05 00 	lea    0x5cfb6(%rip),%rdi        # 68420 <fwp_root_context>
    b46a:	f3 48 ab             	rep stos %rax,(%rdi)
    b46d:	48 89 d7             	mov    %rdx,%rdi
    b470:	e8 fb a5 ff ff       	call   5a70 <fwp_mem_free>
    b475:	66 0f 6f 05 53 4d 04 	movdqa 0x44d53(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    b47c:	00 
    b47d:	66 0f d4 05 3b 4d 04 	paddq  0x44d3b(%rip),%xmm0        # 501c0 <ad_raw_live>
    b484:	00 
    b485:	48 c7 05 90 d3 05 00 	movq   $0x0,0x5d390(%rip)        # 68820 <fwp_cur>
    b48c:	00 00 00 00 
    b490:	48 8b 05 c9 e7 05 00 	mov    0x5e7c9(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    b497:	48 c7 05 76 d3 05 00 	movq   $0x0,0x5d376(%rip)        # 68818 <fwp_root>
    b49e:	00 00 00 00 
    b4a2:	c7 05 5c f0 05 00 00 	movl   $0x0,0x5f05c(%rip)        # 6a508 <iteration_active>
    b4a9:	00 00 00 
    b4ac:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b4b0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b4b5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b4b9:	66 0f d6 05 57 4c 01 	movq   %xmm0,0x14c57(%rip)        # 20118 <ad_raw_before_shutdown>
    b4c0:	00 
    b4c1:	48 85 c0             	test   %rax,%rax
    b4c4:	0f 88 56 06 00 00    	js     bb20 <fwp_main_thread+0xcf0>
    b4ca:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b4ce:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b4d3:	f2 0f 5c 0d 0d f0 05 	subsd  0x5f00d(%rip),%xmm1        # 6a4e8 <iteration_start_charge>
    b4da:	00 
    b4db:	48 8b 3d 5e 4b 00 00 	mov    0x4b5e(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    b4e2:	48 8d 15 77 16 00 00 	lea    0x1677(%rip),%rdx        # cb60 <_IO_stdin_used+0xb60>
    b4e9:	be 02 00 00 00       	mov    $0x2,%esi
    b4ee:	f2 0f 10 05 ea ef 05 	movsd  0x5efea(%rip),%xmm0        # 6a4e0 <iteration_peak>
    b4f5:	00 
    b4f6:	4c 8b 0d f3 ef 05 00 	mov    0x5eff3(%rip),%r9        # 6a4f0 <iteration_retains>
    b4fd:	b8 02 00 00 00       	mov    $0x2,%eax
    b502:	4c 8b 05 ef ef 05 00 	mov    0x5efef(%rip),%r8        # 6a4f8 <iteration_bytes>
    b509:	48 8b 0d f0 ef 05 00 	mov    0x5eff0(%rip),%rcx        # 6a500 <iteration_requests>
    b510:	e8 5b 81 ff ff       	call   3670 <__fprintf_chk@plt>
    b515:	48 8b 3d 04 4b 00 00 	mov    0x4b04(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b51c:	e8 7f 80 ff ff       	call   35a0 <fflush@plt>
    b521:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b528:	00 
    b529:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b530:	00 00 
    b532:	0f 85 a7 07 00 00    	jne    bcdf <fwp_main_thread+0xeaf>
    b538:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b53f:	31 c0                	xor    %eax,%eax
    b541:	5b                   	pop    %rbx
    b542:	5d                   	pop    %rbp
    b543:	41 5c                	pop    %r12
    b545:	41 5d                	pop    %r13
    b547:	41 5e                	pop    %r14
    b549:	41 5f                	pop    %r15
    b54b:	c3                   	ret
    b54c:	0f 1f 40 00          	nopl   0x0(%rax)
    b550:	48 89 05 a1 d2 05 00 	mov    %rax,0x5d2a1(%rip)        # 687f8 <fwp_timers>
    b557:	e9 66 fb ff ff       	jmp    b0c2 <fwp_main_thread+0x292>
    b55c:	0f 1f 40 00          	nopl   0x0(%rax)
    b560:	48 89 c2             	mov    %rax,%rdx
    b563:	83 e0 01             	and    $0x1,%eax
    b566:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b56a:	48 d1 ea             	shr    $1,%rdx
    b56d:	48 09 c2             	or     %rax,%rdx
    b570:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b575:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b579:	e9 d1 f9 ff ff       	jmp    af4f <fwp_main_thread+0x11f>
    b57e:	66 90                	xchg   %ax,%ax
    b580:	e8 4b 98 ff ff       	call   4dd0 <fwp_heap_init>
    b585:	8b 35 5d e6 05 00    	mov    0x5e65d(%rip),%esi        # 69be8 <fwp_heap+0x13a8>
    b58b:	85 f6                	test   %esi,%esi
    b58d:	0f 84 e1 f8 ff ff    	je     ae74 <fwp_main_thread+0x44>
    b593:	48 8d 3d 26 97 ff ff 	lea    -0x68da(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b59a:	e8 71 09 00 00       	call   bf10 <atexit>
    b59f:	e9 d0 f8 ff ff       	jmp    ae74 <fwp_main_thread+0x44>
    b5a4:	0f 1f 40 00          	nopl   0x0(%rax)
    b5a8:	48 8d 05 c1 ba ff ff 	lea    -0x453f(%rip),%rax        # 7070 <fwp_drop1>
    b5af:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b5b3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b5ba:	00 00 
    b5bc:	41 be ff 7f 00 00    	mov    $0x7fff,%r14d
    b5c2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b5c7:	48 8b 05 0a ef 05 00 	mov    0x5ef0a(%rip),%rax        # 6a4d8 <fwp_cleanups>
    b5ce:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
    b5d3:	4c 8d 25 66 d2 05 00 	lea    0x5d266(%rip),%r12        # 68840 <fwp_heap>
    b5da:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b5de:	48 89 1d f3 ee 05 00 	mov    %rbx,0x5eef3(%rip)        # 6a4d8 <fwp_cleanups>
    b5e5:	31 db                	xor    %ebx,%ebx
    b5e7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b5ec:	48 8d 05 dd 85 ff ff 	lea    -0x7a23(%rip),%rax        # 3bd0 <fwp_range_release>
    b5f3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b5f8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b5fd:	eb 3b                	jmp    b63a <fwp_main_thread+0x80a>
    b5ff:	90                   	nop
    b600:	40 80 fe 01          	cmp    $0x1,%sil
    b604:	75 25                	jne    b62b <fwp_main_thread+0x7fb>
    b606:	8b 71 18             	mov    0x18(%rcx),%esi
    b609:	0f b7 c0             	movzwl %ax,%eax
    b60c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b60f:	48 0f af c6          	imul   %rsi,%rax
    b613:	48 c1 e8 20          	shr    $0x20,%rax
    b617:	48 39 c8             	cmp    %rcx,%rax
    b61a:	73 0f                	jae    b62b <fwp_main_thread+0x7fb>
    b61c:	48 01 c2             	add    %rax,%rdx
    b61f:	80 3a ff             	cmpb   $0xff,(%rdx)
    b622:	0f 84 68 05 00 00    	je     bb90 <fwp_main_thread+0xd60>
    b628:	c6 02 01             	movb   $0x1,(%rdx)
    b62b:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b630:	49 83 ee 01          	sub    $0x1,%r14
    b634:	0f 82 86 00 00 00    	jb     b6c0 <fwp_main_thread+0x890>
    b63a:	4c 89 ee             	mov    %r13,%rsi
    b63d:	bf 01 00 00 00       	mov    $0x1,%edi
    b642:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    b649:	00 
    b64a:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    b64f:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    b656:	00 
    b657:	e8 f4 b2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    b65c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b663:	00 
    b664:	48 89 c3             	mov    %rax,%rbx
    b667:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b66e:	00 
    b66f:	48 c1 e2 10          	shl    $0x10,%rdx
    b673:	48 39 d0             	cmp    %rdx,%rax
    b676:	73 b3                	jae    b62b <fwp_main_thread+0x7fb>
    b678:	48 89 c2             	mov    %rax,%rdx
    b67b:	48 c1 ea 10          	shr    $0x10,%rdx
    b67f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b683:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b68a:	00 
    b68b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b68f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b693:	48 85 d2             	test   %rdx,%rdx
    b696:	74 93                	je     b62b <fwp_main_thread+0x7fb>
    b698:	0f b6 31             	movzbl (%rcx),%esi
    b69b:	40 80 fe 02          	cmp    $0x2,%sil
    b69f:	0f 85 5b ff ff ff    	jne    b600 <fwp_main_thread+0x7d0>
    b6a5:	66 85 c0             	test   %ax,%ax
    b6a8:	0f 84 71 ff ff ff    	je     b61f <fwp_main_thread+0x7ef>
    b6ae:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b6b3:	49 83 ee 01          	sub    $0x1,%r14
    b6b7:	73 81                	jae    b63a <fwp_main_thread+0x80a>
    b6b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6c0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b6c5:	66 0f 6f 05 13 17 00 	movdqa 0x1713(%rip),%xmm0        # cde0 <msg.8+0xb0>
    b6cc:	00 
    b6cd:	4c 89 ee             	mov    %r13,%rsi
    b6d0:	bf 01 00 00 00       	mov    $0x1,%edi
    b6d5:	48 89 05 fc ed 05 00 	mov    %rax,0x5edfc(%rip)        # 6a4d8 <fwp_cleanups>
    b6dc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b6e3:	00 
    b6e4:	e8 67 b2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    b6e9:	48 8b 15 28 e5 05 00 	mov    0x5e528(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    b6f0:	49 89 c6             	mov    %rax,%r14
    b6f3:	48 2b 05 f6 e4 05 00 	sub    0x5e4f6(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    b6fa:	48 c1 e2 10          	shl    $0x10,%rdx
    b6fe:	48 39 d0             	cmp    %rdx,%rax
    b701:	73 59                	jae    b75c <fwp_main_thread+0x92c>
    b703:	48 89 c2             	mov    %rax,%rdx
    b706:	48 c1 ea 10          	shr    $0x10,%rdx
    b70a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b70e:	48 8b 15 23 e5 05 00 	mov    0x5e523(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    b715:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b719:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b71d:	4d 85 ed             	test   %r13,%r13
    b720:	74 3a                	je     b75c <fwp_main_thread+0x92c>
    b722:	0f b6 0a             	movzbl (%rdx),%ecx
    b725:	80 f9 02             	cmp    $0x2,%cl
    b728:	0f 84 52 04 00 00    	je     bb80 <fwp_main_thread+0xd50>
    b72e:	80 f9 01             	cmp    $0x1,%cl
    b731:	75 29                	jne    b75c <fwp_main_thread+0x92c>
    b733:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b736:	0f b7 c0             	movzwl %ax,%eax
    b739:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b73c:	48 0f af c1          	imul   %rcx,%rax
    b740:	48 c1 e8 20          	shr    $0x20,%rax
    b744:	48 39 d0             	cmp    %rdx,%rax
    b747:	73 13                	jae    b75c <fwp_main_thread+0x92c>
    b749:	49 01 c5             	add    %rax,%r13
    b74c:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b751:	0f 84 c2 04 00 00    	je     bc19 <fwp_main_thread+0xde9>
    b757:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b75c:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b761:	bf 01 00 00 00       	mov    $0x1,%edi
    b766:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b76b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b772:	00 f0 3f 
    b775:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b77a:	e8 d1 b1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    b77f:	48 8b 15 92 e4 05 00 	mov    0x5e492(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    b786:	49 89 c6             	mov    %rax,%r14
    b789:	48 2b 05 60 e4 05 00 	sub    0x5e460(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    b790:	48 c1 e2 10          	shl    $0x10,%rdx
    b794:	48 39 d0             	cmp    %rdx,%rax
    b797:	73 59                	jae    b7f2 <fwp_main_thread+0x9c2>
    b799:	48 89 c2             	mov    %rax,%rdx
    b79c:	48 c1 ea 10          	shr    $0x10,%rdx
    b7a0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7a4:	48 8b 15 8d e4 05 00 	mov    0x5e48d(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    b7ab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7af:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b7b3:	4d 85 ed             	test   %r13,%r13
    b7b6:	74 3a                	je     b7f2 <fwp_main_thread+0x9c2>
    b7b8:	0f b6 0a             	movzbl (%rdx),%ecx
    b7bb:	80 f9 02             	cmp    $0x2,%cl
    b7be:	0f 84 ac 03 00 00    	je     bb70 <fwp_main_thread+0xd40>
    b7c4:	80 f9 01             	cmp    $0x1,%cl
    b7c7:	75 29                	jne    b7f2 <fwp_main_thread+0x9c2>
    b7c9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7cc:	0f b7 c0             	movzwl %ax,%eax
    b7cf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7d2:	48 0f af c1          	imul   %rcx,%rax
    b7d6:	48 c1 e8 20          	shr    $0x20,%rax
    b7da:	48 39 d0             	cmp    %rdx,%rax
    b7dd:	73 13                	jae    b7f2 <fwp_main_thread+0x9c2>
    b7df:	49 01 c5             	add    %rax,%r13
    b7e2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b7e7:	0f 84 39 04 00 00    	je     bc26 <fwp_main_thread+0xdf6>
    b7ed:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b7f2:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b7f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7fc:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b801:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b808:	33 f3 bf 
    b80b:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b810:	e8 3b b1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    b815:	48 8b 15 fc e3 05 00 	mov    0x5e3fc(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    b81c:	48 8b 0d cd e3 05 00 	mov    0x5e3cd(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    b823:	49 89 c5             	mov    %rax,%r13
    b826:	48 89 d6             	mov    %rdx,%rsi
    b829:	48 29 c8             	sub    %rcx,%rax
    b82c:	48 c1 e6 10          	shl    $0x10,%rsi
    b830:	48 39 f0             	cmp    %rsi,%rax
    b833:	73 67                	jae    b89c <fwp_main_thread+0xa6c>
    b835:	48 89 c6             	mov    %rax,%rsi
    b838:	48 c1 ee 10          	shr    $0x10,%rsi
    b83c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b840:	48 8b 35 f1 e3 05 00 	mov    0x5e3f1(%rip),%rsi        # 69c38 <fwp_heap+0x13f8>
    b847:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b84b:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b84f:	4d 85 f6             	test   %r14,%r14
    b852:	74 48                	je     b89c <fwp_main_thread+0xa6c>
    b854:	0f b6 3e             	movzbl (%rsi),%edi
    b857:	40 80 ff 02          	cmp    $0x2,%dil
    b85b:	0f 84 ff 02 00 00    	je     bb60 <fwp_main_thread+0xd30>
    b861:	40 80 ff 01          	cmp    $0x1,%dil
    b865:	75 35                	jne    b89c <fwp_main_thread+0xa6c>
    b867:	8b 7e 18             	mov    0x18(%rsi),%edi
    b86a:	0f b7 c0             	movzwl %ax,%eax
    b86d:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b870:	48 0f af c7          	imul   %rdi,%rax
    b874:	48 c1 e8 20          	shr    $0x20,%rax
    b878:	48 39 f0             	cmp    %rsi,%rax
    b87b:	73 1f                	jae    b89c <fwp_main_thread+0xa6c>
    b87d:	49 01 c6             	add    %rax,%r14
    b880:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b884:	0f 84 a9 03 00 00    	je     bc33 <fwp_main_thread+0xe03>
    b88a:	41 c6 06 01          	movb   $0x1,(%r14)
    b88e:	48 8b 0d 5b e3 05 00 	mov    0x5e35b(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    b895:	48 8b 15 7c e3 05 00 	mov    0x5e37c(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    b89c:	48 89 1c 24          	mov    %rbx,(%rsp)
    b8a0:	4c 89 e8             	mov    %r13,%rax
    b8a3:	48 c1 e2 10          	shl    $0x10,%rdx
    b8a7:	48 29 c8             	sub    %rcx,%rax
    b8aa:	48 39 d0             	cmp    %rdx,%rax
    b8ad:	73 70                	jae    b91f <fwp_main_thread+0xaef>
    b8af:	48 89 c2             	mov    %rax,%rdx
    b8b2:	48 c1 ea 10          	shr    $0x10,%rdx
    b8b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8ba:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b8c1:	00 
    b8c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8c6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b8ca:	48 85 ff             	test   %rdi,%rdi
    b8cd:	74 50                	je     b91f <fwp_main_thread+0xaef>
    b8cf:	0f b6 0a             	movzbl (%rdx),%ecx
    b8d2:	80 f9 02             	cmp    $0x2,%cl
    b8d5:	0f 84 75 02 00 00    	je     bb50 <fwp_main_thread+0xd20>
    b8db:	80 f9 01             	cmp    $0x1,%cl
    b8de:	75 3f                	jne    b91f <fwp_main_thread+0xaef>
    b8e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8e3:	0f b7 c0             	movzwl %ax,%eax
    b8e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8e9:	48 0f af c1          	imul   %rcx,%rax
    b8ed:	48 c1 e8 20          	shr    $0x20,%rax
    b8f1:	48 39 d0             	cmp    %rdx,%rax
    b8f4:	73 29                	jae    b91f <fwp_main_thread+0xaef>
    b8f6:	48 01 c7             	add    %rax,%rdi
    b8f9:	0f b6 07             	movzbl (%rdi),%eax
    b8fc:	84 c0                	test   %al,%al
    b8fe:	74 1f                	je     b91f <fwp_main_thread+0xaef>
    b900:	8b 15 02 ec 05 00    	mov    0x5ec02(%rip),%edx        # 6a508 <iteration_active>
    b906:	85 d2                	test   %edx,%edx
    b908:	74 08                	je     b912 <fwp_main_thread+0xae2>
    b90a:	48 83 05 de eb 05 00 	addq   $0x1,0x5ebde(%rip)        # 6a4f0 <iteration_retains>
    b911:	01 
    b912:	3c fd                	cmp    $0xfd,%al
    b914:	0f 87 26 03 00 00    	ja     bc40 <fwp_main_thread+0xe10>
    b91a:	83 c0 01             	add    $0x1,%eax
    b91d:	88 07                	mov    %al,(%rdi)
    b91f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b923:	b9 01 00 00 00       	mov    $0x1,%ecx
    b928:	4c 89 ee             	mov    %r13,%rsi
    b92b:	48 89 ef             	mov    %rbp,%rdi
    b92e:	48 8d 15 6b 42 00 00 	lea    0x426b(%rip),%rdx        # fba0 <d0>
    b935:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b93a:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b941:	00 00 
    b943:	e8 a8 e4 ff ff       	call   9df0 <fwp_write>
    b948:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b94d:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    b952:	48 8d 05 13 07 00 00 	lea    0x713(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    b959:	4d 85 f6             	test   %r14,%r14
    b95c:	4c 0f 44 f0          	cmove  %rax,%r14
    b960:	48 83 fa f6          	cmp    $0xfffffffffffffff6,%rdx
    b964:	0f 87 7a 03 00 00    	ja     bce4 <fwp_main_thread+0xeb4>
    b96a:	48 8d 7a 09          	lea    0x9(%rdx),%rdi
    b96e:	be 01 00 00 00       	mov    $0x1,%esi
    b973:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b978:	e8 f3 a5 ff ff       	call   5f70 <fwp_heap_alloc>
    b97d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b982:	4c 89 f6             	mov    %r14,%rsi
    b985:	48 8d 78 08          	lea    0x8(%rax),%rdi
    b989:	49 89 c7             	mov    %rax,%r15
    b98c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b991:	48 89 10             	mov    %rdx,(%rax)
    b994:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    b999:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    b99e:	e8 dd 7b ff ff       	call   3580 <memcpy@plt>
    b9a3:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    b9a8:	41 c6 44 17 08 00    	movb   $0x0,0x8(%r15,%rdx,1)
    b9ae:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b9b3:	e8 f8 79 ff ff       	call   33b0 <free@plt>
    b9b8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b9bf:	00 
    b9c0:	4d 2b bc 24 b0 13 00 	sub    0x13b0(%r12),%r15
    b9c7:	00 
    b9c8:	48 c1 e2 10          	shl    $0x10,%rdx
    b9cc:	49 39 d7             	cmp    %rdx,%r15
    b9cf:	73 59                	jae    ba2a <fwp_main_thread+0xbfa>
    b9d1:	4c 89 fa             	mov    %r15,%rdx
    b9d4:	48 c1 ea 10          	shr    $0x10,%rdx
    b9d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9dc:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b9e3:	00 
    b9e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b9e8:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b9ec:	4d 85 f6             	test   %r14,%r14
    b9ef:	74 39                	je     ba2a <fwp_main_thread+0xbfa>
    b9f1:	0f b6 0a             	movzbl (%rdx),%ecx
    b9f4:	80 f9 02             	cmp    $0x2,%cl
    b9f7:	0f 84 b6 01 00 00    	je     bbb3 <fwp_main_thread+0xd83>
    b9fd:	80 f9 01             	cmp    $0x1,%cl
    ba00:	75 28                	jne    ba2a <fwp_main_thread+0xbfa>
    ba02:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba05:	41 0f b7 c7          	movzwl %r15w,%eax
    ba09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba0c:	48 0f af c1          	imul   %rcx,%rax
    ba10:	48 c1 e8 20          	shr    $0x20,%rax
    ba14:	48 39 d0             	cmp    %rdx,%rax
    ba17:	73 11                	jae    ba2a <fwp_main_thread+0xbfa>
    ba19:	49 01 c6             	add    %rax,%r14
    ba1c:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ba20:	0f 84 24 02 00 00    	je     bc4a <fwp_main_thread+0xe1a>
    ba26:	41 c6 06 01          	movb   $0x1,(%r14)
    ba2a:	4c 89 ef             	mov    %r13,%rdi
    ba2d:	e8 be b4 ff ff       	call   6ef0 <fwp_drop0>
    ba32:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    ba37:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    ba3c:	be 01 00 00 00       	mov    $0x1,%esi
    ba41:	48 8b 0d 58 ea 05 00 	mov    0x5ea58(%rip),%rcx        # 6a4a0 <fwp_prog_out>
    ba48:	49 8b 17             	mov    (%r15),%rdx
    ba4b:	e8 10 7c ff ff       	call   3660 <fwrite@plt>
    ba50:	48 8b 35 49 ea 05 00 	mov    0x5ea49(%rip),%rsi        # 6a4a0 <fwp_prog_out>
    ba57:	bf 0a 00 00 00       	mov    $0xa,%edi
    ba5c:	e8 6f 7a ff ff       	call   34d0 <fputc@plt>
    ba61:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ba68:	00 
    ba69:	4c 89 f8             	mov    %r15,%rax
    ba6c:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    ba73:	00 
    ba74:	48 c1 e2 10          	shl    $0x10,%rdx
    ba78:	48 39 d0             	cmp    %rdx,%rax
    ba7b:	73 73                	jae    baf0 <fwp_main_thread+0xcc0>
    ba7d:	48 89 c2             	mov    %rax,%rdx
    ba80:	48 c1 ea 10          	shr    $0x10,%rdx
    ba84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba88:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    ba8f:	00 
    ba90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba94:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ba98:	4d 85 f6             	test   %r14,%r14
    ba9b:	74 53                	je     baf0 <fwp_main_thread+0xcc0>
    ba9d:	0f b6 0a             	movzbl (%rdx),%ecx
    baa0:	80 f9 02             	cmp    $0x2,%cl
    baa3:	0f 84 fc 00 00 00    	je     bba5 <fwp_main_thread+0xd75>
    baa9:	80 f9 01             	cmp    $0x1,%cl
    baac:	75 42                	jne    baf0 <fwp_main_thread+0xcc0>
    baae:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bab1:	0f b7 c0             	movzwl %ax,%eax
    bab4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bab7:	48 0f af c1          	imul   %rcx,%rax
    babb:	48 c1 e8 20          	shr    $0x20,%rax
    babf:	48 39 d0             	cmp    %rdx,%rax
    bac2:	73 2c                	jae    baf0 <fwp_main_thread+0xcc0>
    bac4:	49 01 c6             	add    %rax,%r14
    bac7:	41 0f b6 06          	movzbl (%r14),%eax
    bacb:	84 c0                	test   %al,%al
    bacd:	74 21                	je     baf0 <fwp_main_thread+0xcc0>
    bacf:	3c 01                	cmp    $0x1,%al
    bad1:	0f 84 33 01 00 00    	je     bc0a <fwp_main_thread+0xdda>
    bad7:	3c ff                	cmp    $0xff,%al
    bad9:	0f 84 78 01 00 00    	je     bc57 <fwp_main_thread+0xe27>
    badf:	83 e8 01             	sub    $0x1,%eax
    bae2:	41 88 06             	mov    %al,(%r14)
    bae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    baec:	00 00 00 00 
    baf0:	48 8b 04 24          	mov    (%rsp),%rax
    baf4:	48 8b 40 10          	mov    0x10(%rax),%rax
    baf8:	48 89 04 24          	mov    %rax,(%rsp)
    bafc:	48 85 c0             	test   %rax,%rax
    baff:	0f 84 db 00 00 00    	je     bbe0 <fwp_main_thread+0xdb0>
    bb05:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    bb0c:	00 
    bb0d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    bb14:	00 
    bb15:	e9 86 fd ff ff       	jmp    b8a0 <fwp_main_thread+0xa70>
    bb1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb20:	48 89 c2             	mov    %rax,%rdx
    bb23:	83 e0 01             	and    $0x1,%eax
    bb26:	66 0f ef c9          	pxor   %xmm1,%xmm1
    bb2a:	48 d1 ea             	shr    $1,%rdx
    bb2d:	48 09 c2             	or     %rax,%rdx
    bb30:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    bb35:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    bb39:	e9 95 f9 ff ff       	jmp    b4d3 <fwp_main_thread+0x6a3>
    bb3e:	66 90                	xchg   %ax,%ax
    bb40:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    bb44:	e9 ee f4 ff ff       	jmp    b037 <fwp_main_thread+0x207>
    bb49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bb50:	66 85 c0             	test   %ax,%ax
    bb53:	0f 85 c6 fd ff ff    	jne    b91f <fwp_main_thread+0xaef>
    bb59:	e9 9b fd ff ff       	jmp    b8f9 <fwp_main_thread+0xac9>
    bb5e:	66 90                	xchg   %ax,%ax
    bb60:	66 85 c0             	test   %ax,%ax
    bb63:	0f 85 33 fd ff ff    	jne    b89c <fwp_main_thread+0xa6c>
    bb69:	e9 12 fd ff ff       	jmp    b880 <fwp_main_thread+0xa50>
    bb6e:	66 90                	xchg   %ax,%ax
    bb70:	66 85 c0             	test   %ax,%ax
    bb73:	0f 85 79 fc ff ff    	jne    b7f2 <fwp_main_thread+0x9c2>
    bb79:	e9 64 fc ff ff       	jmp    b7e2 <fwp_main_thread+0x9b2>
    bb7e:	66 90                	xchg   %ax,%ax
    bb80:	66 85 c0             	test   %ax,%ax
    bb83:	0f 85 d3 fb ff ff    	jne    b75c <fwp_main_thread+0x92c>
    bb89:	e9 be fb ff ff       	jmp    b74c <fwp_main_thread+0x91c>
    bb8e:	66 90                	xchg   %ax,%ax
    bb90:	48 89 d7             	mov    %rdx,%rdi
    bb93:	48 89 14 24          	mov    %rdx,(%rsp)
    bb97:	e8 94 9c ff ff       	call   5830 <fwp_rc_forget_slot>
    bb9c:	48 8b 14 24          	mov    (%rsp),%rdx
    bba0:	e9 83 fa ff ff       	jmp    b628 <fwp_main_thread+0x7f8>
    bba5:	66 85 c0             	test   %ax,%ax
    bba8:	0f 85 42 ff ff ff    	jne    baf0 <fwp_main_thread+0xcc0>
    bbae:	e9 14 ff ff ff       	jmp    bac7 <fwp_main_thread+0xc97>
    bbb3:	66 45 85 ff          	test   %r15w,%r15w
    bbb7:	0f 85 6d fe ff ff    	jne    ba2a <fwp_main_thread+0xbfa>
    bbbd:	e9 5a fe ff ff       	jmp    ba1c <fwp_main_thread+0xbec>
    bbc2:	48 83 3d 4e cc 05 00 	cmpq   $0x0,0x5cc4e(%rip)        # 68818 <fwp_root>
    bbc9:	00 
    bbca:	c7 05 cc 44 01 00 00 	movl   $0x0,0x144cc(%rip)        # 200a0 <fwp_exit_code>
    bbd1:	00 00 00 
    bbd4:	0f 84 5e f7 ff ff    	je     b338 <fwp_main_thread+0x508>
    bbda:	e9 71 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bbdf:	90                   	nop
    bbe0:	4c 89 ef             	mov    %r13,%rdi
    bbe3:	e8 08 b3 ff ff       	call   6ef0 <fwp_drop0>
    bbe8:	48 89 df             	mov    %rbx,%rdi
    bbeb:	e8 00 b3 ff ff       	call   6ef0 <fwp_drop0>
    bbf0:	48 c7 05 8d 44 00 00 	movq   $0x0,0x448d(%rip)        # 10088 <v.6>
    bbf7:	00 00 00 00 
    bbfb:	c7 05 8b 44 00 00 01 	movl   $0x1,0x448b(%rip)        # 10090 <st.7>
    bc02:	00 00 00 
    bc05:	e9 79 f3 ff ff       	jmp    af83 <fwp_main_thread+0x153>
    bc0a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    bc0f:	e8 ac af ff ff       	call   6bc0 <fwp_rc_free_arr>
    bc14:	e9 d7 fe ff ff       	jmp    baf0 <fwp_main_thread+0xcc0>
    bc19:	4c 89 ef             	mov    %r13,%rdi
    bc1c:	e8 0f 9c ff ff       	call   5830 <fwp_rc_forget_slot>
    bc21:	e9 31 fb ff ff       	jmp    b757 <fwp_main_thread+0x927>
    bc26:	4c 89 ef             	mov    %r13,%rdi
    bc29:	e8 02 9c ff ff       	call   5830 <fwp_rc_forget_slot>
    bc2e:	e9 ba fb ff ff       	jmp    b7ed <fwp_main_thread+0x9bd>
    bc33:	4c 89 f7             	mov    %r14,%rdi
    bc36:	e8 f5 9b ff ff       	call   5830 <fwp_rc_forget_slot>
    bc3b:	e9 4a fc ff ff       	jmp    b88a <fwp_main_thread+0xa5a>
    bc40:	e8 cb 9a ff ff       	call   5710 <fwp_rc_wide_dup>
    bc45:	e9 d5 fc ff ff       	jmp    b91f <fwp_main_thread+0xaef>
    bc4a:	4c 89 f7             	mov    %r14,%rdi
    bc4d:	e8 de 9b ff ff       	call   5830 <fwp_rc_forget_slot>
    bc52:	e9 cf fd ff ff       	jmp    ba26 <fwp_main_thread+0xbf6>
    bc57:	4c 89 f0             	mov    %r14,%rax
    bc5a:	48 c1 e8 11          	shr    $0x11,%rax
    bc5e:	4c 31 f0             	xor    %r14,%rax
    bc61:	48 89 c2             	mov    %rax,%rdx
    bc64:	48 c1 ea 09          	shr    $0x9,%rdx
    bc68:	48 31 d0             	xor    %rdx,%rax
    bc6b:	0f b6 d0             	movzbl %al,%edx
    bc6e:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bc75:	00 
    bc76:	48 85 c0             	test   %rax,%rax
    bc79:	75 0e                	jne    bc89 <fwp_main_thread+0xe59>
    bc7b:	eb 56                	jmp    bcd3 <fwp_main_thread+0xea3>
    bc7d:	0f 1f 00             	nopl   (%rax)
    bc80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bc84:	48 85 c0             	test   %rax,%rax
    bc87:	74 4a                	je     bcd3 <fwp_main_thread+0xea3>
    bc89:	48 89 c2             	mov    %rax,%rdx
    bc8c:	4c 3b 30             	cmp    (%rax),%r14
    bc8f:	75 ef                	jne    bc80 <fwp_main_thread+0xe50>
    bc91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    bc95:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    bc99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bc9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bca4:	0f 85 46 fe ff ff    	jne    baf0 <fwp_main_thread+0xcc0>
    bcaa:	4c 89 f7             	mov    %r14,%rdi
    bcad:	e8 7e 9b ff ff       	call   5830 <fwp_rc_forget_slot>
    bcb2:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bcb6:	e9 35 fe ff ff       	jmp    baf0 <fwp_main_thread+0xcc0>
    bcbb:	48 8d 3d 76 0e 00 00 	lea    0xe76(%rip),%rdi        # cb38 <_IO_stdin_used+0xb38>
    bcc2:	e8 89 87 ff ff       	call   4450 <fwp_trap>
    bcc7:	48 8d 3d f4 05 00 00 	lea    0x5f4(%rip),%rdi        # c2c2 <_IO_stdin_used+0x2c2>
    bcce:	e8 2d 83 ff ff       	call   4000 <ad_raw_fail>
    bcd3:	48 8d 3d 06 0d 00 00 	lea    0xd06(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    bcda:	e8 71 87 ff ff       	call   4450 <fwp_trap>
    bcdf:	e8 6c 77 ff ff       	call   3450 <__stack_chk_fail@plt>
    bce4:	48 8d 3d f2 05 00 00 	lea    0x5f2(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    bceb:	e8 60 87 ff ff       	call   4450 <fwp_trap>
    bcf0:	e9 5b 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bcf5:	e9 56 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bcfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000bd00 <__divmodti4>:
    bd00:	f3 0f 1e fa          	endbr64
    bd04:	55                   	push   %rbp
    bd05:	49 89 f1             	mov    %rsi,%r9
    bd08:	49 89 d2             	mov    %rdx,%r10
    bd0b:	48 89 fe             	mov    %rdi,%rsi
    bd0e:	49 89 cb             	mov    %rcx,%r11
    bd11:	48 89 e5             	mov    %rsp,%rbp
    bd14:	41 57                	push   %r15
    bd16:	41 56                	push   %r14
    bd18:	41 55                	push   %r13
    bd1a:	41 54                	push   %r12
    bd1c:	53                   	push   %rbx
    bd1d:	4c 89 c3             	mov    %r8,%rbx
    bd20:	45 31 c0             	xor    %r8d,%r8d
    bd23:	4d 85 c9             	test   %r9,%r9
    bd26:	79 12                	jns    bd3a <__divmodti4+0x3a>
    bd28:	31 ff                	xor    %edi,%edi
    bd2a:	48 f7 de             	neg    %rsi
    bd2d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bd34:	4c 19 cf             	sbb    %r9,%rdi
    bd37:	49 89 f9             	mov    %rdi,%r9
    bd3a:	4c 89 d8             	mov    %r11,%rax
    bd3d:	4d 85 db             	test   %r11,%r11
    bd40:	0f 88 1a 01 00 00    	js     be60 <__divmodti4+0x160>
    bd46:	4c 89 d9             	mov    %r11,%rcx
    bd49:	49 89 f3             	mov    %rsi,%r11
    bd4c:	75 62                	jne    bdb0 <__divmodti4+0xb0>
    bd4e:	4d 89 c4             	mov    %r8,%r12
    bd51:	4d 39 d1             	cmp    %r10,%r9
    bd54:	0f 83 46 01 00 00    	jae    bea0 <__divmodti4+0x1a0>
    bd5a:	4c 89 d8             	mov    %r11,%rax
    bd5d:	4c 89 ca             	mov    %r9,%rdx
    bd60:	49 f7 f2             	div    %r10
    bd63:	49 89 c3             	mov    %rax,%r11
    bd66:	31 c0                	xor    %eax,%eax
    bd68:	48 89 d6             	mov    %rdx,%rsi
    bd6b:	31 ff                	xor    %edi,%edi
    bd6d:	4c 89 d9             	mov    %r11,%rcx
    bd70:	48 89 c2             	mov    %rax,%rdx
    bd73:	48 89 c8             	mov    %rcx,%rax
    bd76:	4d 85 e4             	test   %r12,%r12
    bd79:	74 0a                	je     bd85 <__divmodti4+0x85>
    bd7b:	48 f7 d8             	neg    %rax
    bd7e:	48 83 d2 00          	adc    $0x0,%rdx
    bd82:	48 f7 da             	neg    %rdx
    bd85:	4d 85 c0             	test   %r8,%r8
    bd88:	74 0a                	je     bd94 <__divmodti4+0x94>
    bd8a:	48 f7 de             	neg    %rsi
    bd8d:	48 83 d7 00          	adc    $0x0,%rdi
    bd91:	48 f7 df             	neg    %rdi
    bd94:	48 89 33             	mov    %rsi,(%rbx)
    bd97:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bd9b:	5b                   	pop    %rbx
    bd9c:	41 5c                	pop    %r12
    bd9e:	41 5d                	pop    %r13
    bda0:	41 5e                	pop    %r14
    bda2:	41 5f                	pop    %r15
    bda4:	5d                   	pop    %rbp
    bda5:	c3                   	ret
    bda6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bdad:	00 00 00 
    bdb0:	4d 89 c4             	mov    %r8,%r12
    bdb3:	49 39 c1             	cmp    %rax,%r9
    bdb6:	0f 82 ce 00 00 00    	jb     be8a <__divmodti4+0x18a>
    bdbc:	31 ff                	xor    %edi,%edi
    bdbe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bdc3:	48 63 c7             	movslq %edi,%rax
    bdc6:	be 40 00 00 00       	mov    $0x40,%esi
    bdcb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bdd0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bdd5:	48 29 c6             	sub    %rax,%rsi
    bdd8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bddd:	48 09 c8             	or     %rcx,%rax
    bde0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bde5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bdea:	49 89 c6             	mov    %rax,%r14
    bded:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bdf1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bdf6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bdfb:	49 09 c1             	or     %rax,%r9
    bdfe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    be02:	4c 89 c8             	mov    %r9,%rax
    be05:	49 f7 f6             	div    %r14
    be08:	48 89 d1             	mov    %rdx,%rcx
    be0b:	49 89 c3             	mov    %rax,%r11
    be0e:	49 89 c1             	mov    %rax,%r9
    be11:	49 f7 e2             	mul    %r10
    be14:	49 89 c6             	mov    %rax,%r14
    be17:	49 89 d2             	mov    %rdx,%r10
    be1a:	48 39 d1             	cmp    %rdx,%rcx
    be1d:	72 07                	jb     be26 <__divmodti4+0x126>
    be1f:	75 17                	jne    be38 <__divmodti4+0x138>
    be21:	49 39 c7             	cmp    %rax,%r15
    be24:	73 12                	jae    be38 <__divmodti4+0x138>
    be26:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    be2a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    be2e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    be32:	49 89 d2             	mov    %rdx,%r10
    be35:	49 89 c6             	mov    %rax,%r14
    be38:	4c 89 f8             	mov    %r15,%rax
    be3b:	4c 29 f0             	sub    %r14,%rax
    be3e:	4c 19 d1             	sbb    %r10,%rcx
    be41:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    be46:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    be4b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    be50:	48 09 c6             	or     %rax,%rsi
    be53:	48 89 cf             	mov    %rcx,%rdi
    be56:	31 c0                	xor    %eax,%eax
    be58:	4c 89 c9             	mov    %r9,%rcx
    be5b:	e9 10 ff ff ff       	jmp    bd70 <__divmodti4+0x70>
    be60:	4c 89 d0             	mov    %r10,%rax
    be63:	4c 89 da             	mov    %r11,%rdx
    be66:	4d 89 c4             	mov    %r8,%r12
    be69:	49 89 f3             	mov    %rsi,%r11
    be6c:	48 f7 d8             	neg    %rax
    be6f:	49 f7 d4             	not    %r12
    be72:	48 83 d2 00          	adc    $0x0,%rdx
    be76:	49 89 c2             	mov    %rax,%r10
    be79:	48 f7 da             	neg    %rdx
    be7c:	48 89 d1             	mov    %rdx,%rcx
    be7f:	0f 84 cc fe ff ff    	je     bd51 <__divmodti4+0x51>
    be85:	49 39 d1             	cmp    %rdx,%r9
    be88:	73 46                	jae    bed0 <__divmodti4+0x1d0>
    be8a:	4c 89 cf             	mov    %r9,%rdi
    be8d:	31 c0                	xor    %eax,%eax
    be8f:	31 c9                	xor    %ecx,%ecx
    be91:	e9 da fe ff ff       	jmp    bd70 <__divmodti4+0x70>
    be96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    be9d:	00 00 00 
    bea0:	4d 85 d2             	test   %r10,%r10
    bea3:	75 0d                	jne    beb2 <__divmodti4+0x1b2>
    bea5:	b8 01 00 00 00       	mov    $0x1,%eax
    beaa:	31 d2                	xor    %edx,%edx
    beac:	49 f7 f2             	div    %r10
    beaf:	49 89 c2             	mov    %rax,%r10
    beb2:	4c 89 c8             	mov    %r9,%rax
    beb5:	31 d2                	xor    %edx,%edx
    beb7:	49 f7 f2             	div    %r10
    beba:	49 89 c1             	mov    %rax,%r9
    bebd:	4c 89 d8             	mov    %r11,%rax
    bec0:	49 f7 f2             	div    %r10
    bec3:	49 89 c3             	mov    %rax,%r11
    bec6:	4c 89 c8             	mov    %r9,%rax
    bec9:	e9 9a fe ff ff       	jmp    bd68 <__divmodti4+0x68>
    bece:	66 90                	xchg   %ax,%ax
    bed0:	45 31 f6             	xor    %r14d,%r14d
    bed3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bed8:	44 89 f7             	mov    %r14d,%edi
    bedb:	45 85 f6             	test   %r14d,%r14d
    bede:	0f 85 df fe ff ff    	jne    bdc3 <__divmodti4+0xc3>
    bee4:	4c 39 ca             	cmp    %r9,%rdx
    bee7:	72 17                	jb     bf00 <__divmodti4+0x200>
    bee9:	31 c9                	xor    %ecx,%ecx
    beeb:	48 39 c6             	cmp    %rax,%rsi
    beee:	73 10                	jae    bf00 <__divmodti4+0x200>
    bef0:	4c 89 cf             	mov    %r9,%rdi
    bef3:	31 c0                	xor    %eax,%eax
    bef5:	e9 76 fe ff ff       	jmp    bd70 <__divmodti4+0x70>
    befa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bf00:	4c 89 de             	mov    %r11,%rsi
    bf03:	b9 01 00 00 00       	mov    $0x1,%ecx
    bf08:	48 29 c6             	sub    %rax,%rsi
    bf0b:	49 19 d1             	sbb    %rdx,%r9
    bf0e:	eb e0                	jmp    bef0 <__divmodti4+0x1f0>

000000000000bf10 <atexit>:
    bf10:	f3 0f 1e fa          	endbr64
    bf14:	48 8b 15 ed 40 00 00 	mov    0x40ed(%rip),%rdx        # 10008 <__dso_handle>
    bf1b:	31 f6                	xor    %esi,%esi
    bf1d:	e9 1e 77 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bf24 <_fini>:
    bf24:	f3 0f 1e fa          	endbr64
    bf28:	48 83 ec 08          	sub    $0x8,%rsp
    bf2c:	48 83 c4 08          	add    $0x8,%rsp
    bf30:	c3                   	ret
