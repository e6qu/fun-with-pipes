
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # ffd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da cd 00 00    	push   0xcdda(%rip)        # fe00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc cd 00 00    	jmp    *0xcddc(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 cc 00 00    	jmp    *0xcc46(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fe90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fe98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # feb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # feb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # fef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # fef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ff90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ff98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be c8 00 00    	jmp    *0xc8be(%rip)        # ffb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 89 00 00 	lea    0x89dd(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 89 00 00 	lea    0x89da(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 ac 00 00 	lea    0xace1(%rip),%rax        # e460 <fwp_fn_table>
    377f:	48 89 05 92 ec 01 00 	mov    %rax,0x1ec92(%rip)        # 22418 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c ec 01 00 	mov    %rax,0x1ec8c(%rip)        # 22420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 8a 00 00 	lea    0x8ab7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 5f 74 00 00 	lea    0x745f(%rip),%rdx        # acc0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 89 00 00 	lea    0x8967(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e 91 00 00 	lea    0x917e(%rip),%rdi        # ca88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 91 00 00 	lea    0x9138(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc 90 00 00 	lea    0x90fc(%rip),%rdi        # ca30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 90 00 00 	lea    0x90c8(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b c6 00 00    	call   *0xc64b(%rip)        # ffc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e c6 00 00 	mov    0xc62e(%rip),%rax        # ffc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd c5 00 00 	mov    0xc5fd(%rip),%rax        # ffd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da c5 00 00 	cmpq   $0x0,0xc5da(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 e7 01 00 	mov    0x1e7a9(%rip),%rdi        # 22420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ca 01 00 	mov    0x1caa1(%rip),%rax        # 207a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 c3 01 00 	mov    0x1c3d9(%rip),%rax        # 20158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 c3 01 00 	sub    0x1c3c5(%rip),%rax        # 20150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 8d 00 00 	lea    0x8dad(%rip),%rsi        # cb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f 88 00 00 	lea    0x887f(%rip),%rdi        # c668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 c2 00 00 	mov    0xc242(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 c1 00 00 ff 	cmpl   $0xffffffff,0xc1e5(%rip)        # 10018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 81 00 00 	lea    0x81e2(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 c2 01 00 	mov    0x1c2c1(%rip),%r9        # 20108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f bd 00 	movq   0xbd9f(%rip),%xmm0        # fbf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 81 00 00 	lea    0x81e7(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c c2 01 00 	mov    0x1c29c(%rip),%r8        # 20100 <descent_inputs>
    3e64:	48 8b 0d a5 c2 01 00 	mov    0x1c2a5(%rip),%rcx        # 20110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 c1 00 00 	mov    0xc1c2(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 81 00 00 	lea    0x81d8(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 bd 00 	movq   0xbd67(%rip),%xmm0        # fbf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 88 00 00 	lea    0x8818(%rip),%rdx        # c6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 c2 01 00 	lea    0x1c271(%rip),%r12        # 20120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 bd 00 	movq   0xbd44(%rip),%xmm0        # fc00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b c1 00 00 	mov    0xc15b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 81 00 00 	lea    0x8175(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 81 00 00 	lea    0x8170(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 c1 00 00 	mov    0xc120(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 81 00 00 	lea    0x8144(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 c0 00 00 	mov    0xc0f9(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 81 00 00 	lea    0x8143(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 81 00 00 	lea    0x8119(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b dc 01 00 	mov    0x1dc1b(%rip),%rax        # 21bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 dc 01 00 	lea    0x1dc14(%rip),%r8        # 21bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 db 01 00 	mov    0x1dbf5(%rip),%rbx        # 21b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 dc 01 00 	mov    0x1dc05(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 db 01 00 	mov    0x1dba1(%rip),%rdi        # 21ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea db 01 00 	sub    %rsi,0x1dbea(%rip)        # 21bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a db 01 00 	mov    0x1db7a(%rip),%rax        # 21b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 db 01 00 	add    0x1db30(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e db 01 00 	mov    0x1db3e(%rip),%rsi        # 21ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c db 01 00 	mov    0x1db4c(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb da 01 00 	mov    %r12,0x1dafb(%rip)        # 21ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 da 01 00 	mov    %rbp,0x1dae9(%rip)        # 21b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce da 01 00 	cmp    %rdi,0x1dace(%rip)        # 21b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 da 01 00 	mov    %rdi,0x1dac5(%rip)        # 21b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 db 01 00 	sub    %rdi,0x1db09(%rip)        # 21bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 da 01 00 	mov    0x1dab1(%rip),%rax        # 21ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa da 01 00 	lea    0x1daaa(%rip),%r8        # 21ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d be 00 00 	mov    0xbe5d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 7e 00 00 	lea    0x7e14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad bd 00 00 	movslq 0xbdad(%rip),%rbp        # 10018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a be 01 00 	mov    0x1be7a(%rip),%rsi        # 20118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 be 01 00 	lea    0x1be76(%rip),%rcx        # 20120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b be 01 00 	addq   $0x1,0x1be4b(%rip)        # 20110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 bd 00 00    	mov    %ebx,0xbd48(%rip)        # 10018 <descent_active_phase>
    42d0:	48 89 05 41 be 01 00 	mov    %rax,0x1be41(%rip)        # 20118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 c4 01 00 	cmp    0x1c499(%rip),%rdi        # 207a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f c4 01 00 	mov    0x1c45f(%rip),%rax        # 20780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d c4 01 00 	mov    %rdi,0x1c43d(%rip)        # 20780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 c4 01 00 	mov    %rdi,0x1c419(%rip)        # 20788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 7e 00 00 	lea    0x7e18(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 7c 00 00 	lea    0x7cba(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 bc 00 00 	mov    0xbc28(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 7c 00 00 	lea    0x7c64(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 bc 00 00 	mov    0xbc10(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 bb 00 00 	mov    0xbb21(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 7a 00 00 	lea    0x7ad8(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 7a 00 00 	lea    0x7acd(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 81 00 00 	lea    0x8110(%rip),%rdi        # c700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 85 00 	movdqa 0x8580(%rip),%xmm0        # cb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa dd 01 00 	add    0x1ddaa(%rip),%rax        # 22418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 80 00 00 	lea    0x8064(%rip),%rdi        # c728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ba 01 00 	cmp    %rax,0x1ba05(%rip)        # 200e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ba 01 00 	add    0x1ba00(%rip),%rax        # 200f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d 80 00 00 	lea    0x804d(%rip),%rdi        # c758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 79 00 00 	lea    0x79a5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 77 00 00 	lea    0x77fa(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 76 00 00 	lea    0x7697(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 74 00 00 	lea    0x746f(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e 75 00 00 	lea    0x757e(%rip),%rsi        # c20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 ce 01 00 	mov    0x1ce85(%rip),%r9        # 21b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de ce 01 00 	mov    0x1cede(%rip),%r8        # 21be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 7a 00 00 	lea    0x7a97(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 ce 01 00 	mov    0x1cec6(%rip),%rcx        # 21be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 ce 01 	movsd  0x1ced4(%rip),%xmm1        # 21c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 ce 01 	movsd  0x1cec4(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 b3 00 00 	mov    0xb305(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 7e 00 	movdqa 0x7e28(%rip),%xmm0        # cba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f c9 01 00 	lea    0x1c97f(%rip),%rax        # 21700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 7e 00 	movdqa 0x7e51(%rip),%xmm2        # cbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 c9 01 00 	movaps %xmm0,0x1c925(%rip)        # 216c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d 7e 00 	movdqa 0x7e0d(%rip),%xmm0        # cbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 cd 01 00 01 	movl   $0x1,0x1cdb3(%rip)        # 21b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 c9 01 00 	movaps %xmm0,0x1c913(%rip)        # 216d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb 7d 00 	movdqa 0x7dfb(%rip),%xmm0        # cbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 14 c9 01 00 	movaps %xmm0,0x1c914(%rip)        # 216e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc 7d 00 	movdqa 0x7dfc(%rip),%xmm0        # cbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 15 c9 01 00 	movaps %xmm0,0x1c915(%rip)        # 216f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 b9 01 00 	lea    0x1b995(%rip),%r8        # 207c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 cc 01 00 	mov    %rax,0x1ccb0(%rip)        # 21b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e cc 01 00 	mov    %r12,0x1cc8e(%rip)        # 21b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 cc 01 00 	mov    %rax,0x1cc77(%rip)        # 21b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 cc 01 00 	mov    %rbx,0x1cc90(%rip)        # 21b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 cc 01 00 	mov    %rsi,0x1ccb9(%rip)        # 21bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 71 00 00 	lea    0x71f9(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 cc 01 00 	mov    %rax,0x1cc98(%rip)        # 21bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c cc 01 00    	mov    %eax,0x1cc1c(%rip)        # 21b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c b8 01 00 	mov    0x1b80c(%rip),%r8        # 20780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c b7 01 00 	mov    %rbx,0x1b73c(%rip)        # 20788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 b7 01 00 	mov    %r8,0x1b728(%rip)        # 20780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 70 00 00 	lea    0x705c(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d af 01 00 	lea    0x1af9d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 af 01 00 	movaps %xmm0,0x1af85(%rip)        # 200a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 af 01 00 	mov    %rax,0x1af61(%rip)        # 20088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 af 01 00 	movaps %xmm0,0x1af82(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 af 01 00 	movaps %xmm0,0x1af86(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 af 01 00 	mov    %rdx,0x1af87(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 6f 00 00 	lea    0x6fb3(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 b5 01 00 	mov    0x1b5b7(%rip),%rbx        # 20778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a ad 00 00 	mov    0xad8a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 75 00 00 	lea    0x7573(%rip),%rdi        # c830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d b4 01 00 	mov    0x1b48d(%rip),%rax        # 20780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 b4 01 00 	mov    %rdx,0x1b467(%rip)        # 20780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 b3 01 00 	mov    0x1b3b4(%rip),%rbx        # 20778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 b3 01 00 	mov    %rbx,0x1b371(%rip)        # 20778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 b3 01 00 	mov    %rdx,0x1b371(%rip)        # 20788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 b3 01 00 	lea    0x1b386(%rip),%rsi        # 207c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 cf 01 00 	addq   $0x1,0x1cf05(%rip)        # 22408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 73 00 00 	lea    0x7347(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 73 00 00 	lea    0x7358(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 6b 00 00 	lea    0x6bf7(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e b2 01 00 	lea    0x1b23e(%rip),%rcx        # 207c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f ce 01 00 	subq   $0x1,0x1ce3f(%rip)        # 22408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 72 00 00 	lea    0x72b3(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 ce 01 00 	cmpq   $0x0,0x1ce20(%rip)        # 22408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 cd 01 00 	sub    %rax,0x1cd75(%rip)        # 22410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 cd 01 00 	add    %r12,0x1cd53(%rip)        # 22410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af c4 01 00 	mov    0x1c4af(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac b0 01 00 	lea    0x1b0ac(%rip),%rax        # 207c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 c4 01 00 	add    0x1c403(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 c3 01 00 	mov    0x1c3d0(%rip),%rsi        # 21b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 c3 01 00 	mov    0x1c3f1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 c3 01 00 	add    0x1c3e5(%rip),%r8        # 21bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad c3 01 	addsd  0x1c3ad(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 af 01 00 	lea    0x1af62(%rip),%rax        # 207c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c c3 01 00 	sub    %rdi,0x1c36c(%rip)        # 21be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 c3 01 	movsd  %xmm0,0x1c384(%rip)        # 21c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e c3 01 00 	sub    %rdx,0x1c33e(%rip)        # 21be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 c3 01 	addsd  0x1c344(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 c3 01 	movsd  %xmm0,0x1c338(%rip)        # 21c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf c2 01 00 	mov    0x1c2cf(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 c2 01 00 	add    %rcx,0x1c2c9(%rip)        # 21bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 c2 01 00 	cmp    0x1c282(%rip),%r9        # 21bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 c2 01 00 	mov    %r9,0x1c279(%rip)        # 21bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a c2 01 00 	cmp    0x1c26a(%rip),%r9        # 21ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d c2 01 00 	mov    %r9,0x1c25d(%rip)        # 21ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 c1 01 00 	add    0x1c173(%rip),%rdi        # 21bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 ad 01 00 	lea    0x1ad50(%rip),%r15        # 207c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 c0 01 00 	add    0x1c0c0(%rip),%r12        # 21b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 c1 01 00 	add    0x1c119(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 c1 01 00 	cmp    %rax,0x1c118(%rip)        # 21be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 c1 01 00 	mov    %rax,0x1c109(%rip)        # 21be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 c1 01 00 	mov    %rax,0x1c108(%rip)        # 21be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 c1 01 	addsd  0x1c104(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc c0 01 	movsd  %xmm0,0x1c0fc(%rip)        # 21bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 c0 01 00    	mov    0x1c043(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f ac 01 00 	lea    0x1ac7f(%rip),%rdi        # 207c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 c0 01 00 	add    0x1c038(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 c0 01 00 	cmp    %rax,0x1c033(%rip)        # 21be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 c0 01 00 	mov    %rax,0x1c024(%rip)        # 21be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 c0 01 00 	mov    %rax,0x1c023(%rip)        # 21be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f c0 01 	addsd  0x1c01f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 c0 01 	movsd  %xmm0,0x1c017(%rip)        # 21bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce be 01 00    	mov    0x1bece(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 ab 01 00 	lea    0x1ab05(%rip),%rax        # 207c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb be 01 00 	add    0x1bebb(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba be 01 00 	cmp    %rax,0x1beba(%rip)        # 21be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab be 01 00 	mov    %rax,0x1beab(%rip)        # 21be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa be 01 00 	mov    %rax,0x1beaa(%rip)        # 21be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 be 01 	addsd  0x1bea6(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e be 01 	movsd  %xmm0,0x1be9e(%rip)        # 21bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 2c c6 01 00 	add    0x1c62c(%rip),%r9        # 22418 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 38          	sub    $0x38,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 a9 01 00 00    	js     61c0 <fwp_p_ad_push+0x1d0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	48 09 d0             	or     %rdx,%rax
    6021:	0f 89 79 01 00 00    	jns    61a0 <fwp_p_ad_push+0x1b0>
    6027:	48 89 f8             	mov    %rdi,%rax
    602a:	48 c1 f8 20          	sar    $0x20,%rax
    602e:	48 85 ff             	test   %rdi,%rdi
    6031:	79 24                	jns    6057 <fwp_p_ad_push+0x67>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	48 89 d0             	mov    %rdx,%rax
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	48 c1 f8 20          	sar    $0x20,%rax
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 89 c7             	mov    %rax,%rdi
    605a:	e8 71 e6 ff ff       	call   46d0 <fwp_tape_of>
    605f:	48 89 c3             	mov    %rax,%rbx
    6062:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6067:	0f 85 76 02 00 00    	jne    62e3 <fwp_p_ad_push+0x2f3>
    606d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6071:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6078:	0f 8f 59 02 00 00    	jg     62d7 <fwp_p_ad_push+0x2e7>
    607e:	44 89 e0             	mov    %r12d,%eax
    6081:	4c 39 f8             	cmp    %r15,%rax
    6084:	0f 8d 41 02 00 00    	jge    62cb <fwp_p_ad_push+0x2db>
    608a:	4d 85 ed             	test   %r13,%r13
    608d:	78 0c                	js     609b <fwp_p_ad_push+0xab>
    608f:	44 89 e8             	mov    %r13d,%eax
    6092:	4c 39 f8             	cmp    %r15,%rax
    6095:	0f 8d 30 02 00 00    	jge    62cb <fwp_p_ad_push+0x2db>
    609b:	4d 89 fe             	mov    %r15,%r14
    609e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    60a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ac:	0f 87 25 02 00 00    	ja     62d7 <fwp_p_ad_push+0x2e7>
    60b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60b6:	48 39 e8             	cmp    %rbp,%rax
    60b9:	0f 8e 31 01 00 00    	jle    61f0 <fwp_p_ad_push+0x200>
    60bf:	48 85 ed             	test   %rbp,%rbp
    60c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    60c7:	48 0f 44 e9          	cmove  %rcx,%rbp
    60cb:	48 39 e8             	cmp    %rbp,%rax
    60ce:	7e 20                	jle    60f0 <fwp_p_ad_push+0x100>
    60d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60d7:	0f 8f 03 01 00 00    	jg     61e0 <fwp_p_ad_push+0x1f0>
    60dd:	48 01 ed             	add    %rbp,%rbp
    60e0:	48 39 e8             	cmp    %rbp,%rax
    60e3:	7f eb                	jg     60d0 <fwp_p_ad_push+0xe0>
    60e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60ec:	00 00 00 00 
    60f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    60f7:	00 
    60f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60fc:	48 89 c6             	mov    %rax,%rsi
    60ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6104:	e8 c7 d4 ff ff       	call   35d0 <realloc@plt>
    6109:	48 85 c0             	test   %rax,%rax
    610c:	0f 84 dd 01 00 00    	je     62ef <fwp_p_ad_push+0x2ff>
    6112:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6116:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    611a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    611e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6122:	48 89 e9             	mov    %rbp,%rcx
    6125:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6129:	48 c1 e1 04          	shl    $0x4,%rcx
    612d:	48 89 ce             	mov    %rcx,%rsi
    6130:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6135:	e8 96 d4 ff ff       	call   35d0 <realloc@plt>
    613a:	48 85 c0             	test   %rax,%rax
    613d:	0f 84 ac 01 00 00    	je     62ef <fwp_p_ad_push+0x2ff>
    6143:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6147:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    614c:	4d 85 f6             	test   %r14,%r14
    614f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6153:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6158:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    615f:	00 
    6160:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6167:	00 
    6168:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    616c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6173:	00 
    6174:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6178:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    617c:	0f 85 e2 00 00 00    	jne    6264 <fwp_p_ad_push+0x274>
    6182:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6186:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    618a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    618e:	49 01 c8             	add    %rcx,%r8
    6191:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6195:	eb 79                	jmp    6210 <fwp_p_ad_push+0x220>
    6197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    619e:	00 00 
    61a0:	48 89 d0             	mov    %rdx,%rax
    61a3:	48 c1 ff 20          	sar    $0x20,%rdi
    61a7:	48 c1 f8 20          	sar    $0x20,%rax
    61ab:	48 39 c7             	cmp    %rax,%rdi
    61ae:	0f 84 a3 fe ff ff    	je     6057 <fwp_p_ad_push+0x67>
    61b4:	48 8d 3d f5 66 00 00 	lea    0x66f5(%rip),%rdi        # c8b0 <_IO_stdin_used+0x8b0>
    61bb:	e8 30 e2 ff ff       	call   43f0 <fwp_trap>
    61c0:	48 83 c4 38          	add    $0x38,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 06 ff ff ff       	jmp    60f0 <fwp_p_ad_push+0x100>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61ff:	00 
    6200:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6207:	00 
    6208:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    620c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6210:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6216:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    621a:	4d 85 ed             	test   %r13,%r13
    621d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6222:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6228:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6233:	49 8d 47 01          	lea    0x1(%r15),%rax
    6237:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    623b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6241:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6245:	48 83 c4 38          	add    $0x38,%rsp
    6249:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6250:	ff ff ff 
    6253:	4c 21 e0             	and    %r12,%rax
    6256:	5b                   	pop    %rbx
    6257:	5d                   	pop    %rbp
    6258:	4c 09 f8             	or     %r15,%rax
    625b:	41 5c                	pop    %r12
    625d:	41 5d                	pop    %r13
    625f:	41 5e                	pop    %r14
    6261:	41 5f                	pop    %r15
    6263:	c3                   	ret
    6264:	48 39 ca             	cmp    %rcx,%rdx
    6267:	49 89 d6             	mov    %rdx,%r14
    626a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    626f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6273:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6278:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    627d:	48 29 d1             	sub    %rdx,%rcx
    6280:	4c 89 ca             	mov    %r9,%rdx
    6283:	e8 d8 d2 ff ff       	call   3560 <__memmove_chk@plt>
    6288:	4c 03 73 30          	add    0x30(%rbx),%r14
    628c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6291:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6295:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    629a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    629e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    62a2:	4c 89 d2             	mov    %r10,%rdx
    62a5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    62aa:	e8 61 d3 ff ff       	call   3610 <memmove@plt>
    62af:	48 8b 43 30          	mov    0x30(%rbx),%rax
    62b3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62b7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    62bc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    62c1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    62c6:	e9 bb fe ff ff       	jmp    6186 <fwp_p_ad_push+0x196>
    62cb:	48 8d 3d 95 5e 00 00 	lea    0x5e95(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    62d2:	e8 19 e1 ff ff       	call   43f0 <fwp_trap>
    62d7:	48 8d 3d 6e 5e 00 00 	lea    0x5e6e(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    62de:	e8 0d e1 ff ff       	call   43f0 <fwp_trap>
    62e3:	48 8d 3d 0e 66 00 00 	lea    0x660e(%rip),%rdi        # c8f8 <_IO_stdin_used+0x8f8>
    62ea:	e8 01 e1 ff ff       	call   43f0 <fwp_trap>
    62ef:	48 89 df             	mov    %rbx,%rdi
    62f2:	e8 09 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    62f7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    62fb:	e8 c0 d0 ff ff       	call   33c0 <free@plt>
    6300:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6304:	e8 b7 d0 ff ff       	call   33c0 <free@plt>
    6309:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    630d:	e8 ae d0 ff ff       	call   33c0 <free@plt>
    6312:	31 c9                	xor    %ecx,%ecx
    6314:	31 c0                	xor    %eax,%eax
    6316:	31 d2                	xor    %edx,%edx
    6318:	89 53 04             	mov    %edx,0x4(%rbx)
    631b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    631f:	ba 13 00 00 00       	mov    $0x13,%edx
    6324:	be 01 00 00 00       	mov    $0x1,%esi
    6329:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    632d:	48 8d 3d d4 5c 00 00 	lea    0x5cd4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6334:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6338:	48 8b 0d 01 9d 00 00 	mov    0x9d01(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    633f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6343:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6347:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    634b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    634f:	e8 2c d3 ff ff       	call   3680 <fwrite@plt>
    6354:	31 ff                	xor    %edi,%edi
    6356:	e8 65 d2 ff ff       	call   35c0 <fflush@plt>
    635b:	bf 66 00 00 00       	mov    $0x66,%edi
    6360:	e8 3b d3 ff ff       	call   36a0 <_Exit@plt>
    6365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    636c:	00 00 00 00 

0000000000006370 <w107>:
    6370:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6374:	41 55                	push   %r13
    6376:	48 89 fa             	mov    %rdi,%rdx
    6379:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    637d:	41 54                	push   %r12
    637f:	49 89 fc             	mov    %rdi,%r12
    6382:	55                   	push   %rbp
    6383:	53                   	push   %rbx
    6384:	48 89 f3             	mov    %rsi,%rbx
    6387:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    638c:	48 89 f1             	mov    %rsi,%rcx
    638f:	48 83 ec 28          	sub    $0x28,%rsp
    6393:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6399:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    639f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63a5:	e8 46 fc ff ff       	call   5ff0 <fwp_p_ad_push>
    63aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    63b0:	48 89 da             	mov    %rbx,%rdx
    63b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63c0:	00 f0 3f 
    63c3:	48 89 c7             	mov    %rax,%rdi
    63c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    63cd:	00 f0 bf 
    63d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    63d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63db:	e8 10 fc ff ff       	call   5ff0 <fwp_p_ad_push>
    63e0:	f2 0f 10 05 38 68 00 	movsd  0x6838(%rip),%xmm0        # cc20 <msg.4+0xb0>
    63e7:	00 
    63e8:	4c 89 e7             	mov    %r12,%rdi
    63eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    63f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63f8:	00 f0 3f 
    63fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6402:	49 89 c5             	mov    %rax,%r13
    6405:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    640c:	00 f0 bf 
    640f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6414:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    641a:	e8 d1 fb ff ff       	call   5ff0 <fwp_p_ad_push>
    641f:	48 89 e9             	mov    %rbp,%rcx
    6422:	4c 89 ea             	mov    %r13,%rdx
    6425:	48 89 ee             	mov    %rbp,%rsi
    6428:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    642e:	4c 89 ef             	mov    %r13,%rdi
    6431:	49 89 c4             	mov    %rax,%r12
    6434:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6438:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    643e:	e8 ad fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6443:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6449:	f2 0f 59 1d d7 67 00 	mulsd  0x67d7(%rip),%xmm3        # cc28 <msg.4+0xb8>
    6450:	00 
    6451:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6458:	00 59 40 
    645b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6460:	48 89 c2             	mov    %rax,%rdx
    6463:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    646a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6470:	e8 7b fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6475:	48 89 d9             	mov    %rbx,%rcx
    6478:	4c 89 e2             	mov    %r12,%rdx
    647b:	48 89 de             	mov    %rbx,%rsi
    647e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6484:	4c 89 e7             	mov    %r12,%rdi
    6487:	48 89 c5             	mov    %rax,%rbp
    648a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    648e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6494:	e8 57 fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6499:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    649f:	48 89 ea             	mov    %rbp,%rdx
    64a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    64a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64af:	00 f0 3f 
    64b2:	48 89 c7             	mov    %rax,%rdi
    64b5:	48 89 ce             	mov    %rcx,%rsi
    64b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    64bd:	e8 2e fb ff ff       	call   5ff0 <fwp_p_ad_push>
    64c2:	48 83 c4 28          	add    $0x28,%rsp
    64c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	c3                   	ret
    64d2:	0f 1f 00             	nopl   (%rax)
    64d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64dc:	00 00 00 00 

00000000000064e0 <fwp_data.part.0.constprop.0>:
    64e0:	41 56                	push   %r14
    64e2:	41 89 fe             	mov    %edi,%r14d
    64e5:	41 54                	push   %r12
    64e7:	49 89 f4             	mov    %rsi,%r12
    64ea:	55                   	push   %rbp
    64eb:	53                   	push   %rbx
    64ec:	48 83 ec 08          	sub    $0x8,%rsp
    64f0:	8b 05 6e b6 01 00    	mov    0x1b66e(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    64f6:	85 c0                	test   %eax,%eax
    64f8:	0f 84 fa 00 00 00    	je     65f8 <fwp_data.part.0.constprop.0+0x118>
    64fe:	0f b6 05 5d b2 01 00 	movzbl 0x1b25d(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    6505:	48 8d 15 b4 a2 01 00 	lea    0x1a2b4(%rip),%rdx        # 207c0 <fwp_heap>
    650c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6513:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6517:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    651b:	48 8b 18             	mov    (%rax),%rbx
    651e:	48 85 db             	test   %rbx,%rbx
    6521:	0f 84 a9 00 00 00    	je     65d0 <fwp_data.part.0.constprop.0+0xf0>
    6527:	48 8b 13             	mov    (%rbx),%rdx
    652a:	48 f7 d2             	not    %rdx
    652d:	48 89 10             	mov    %rdx,(%rax)
    6530:	48 83 fd 18          	cmp    $0x18,%rbp
    6534:	76 1b                	jbe    6551 <fwp_data.part.0.constprop.0+0x71>
    6536:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    653a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    653e:	31 f6                	xor    %esi,%esi
    6540:	48 c1 e8 03          	shr    $0x3,%rax
    6544:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    654b:	00 
    654c:	e8 6f cf ff ff       	call   34c0 <memset@plt>
    6551:	48 89 e8             	mov    %rbp,%rax
    6554:	48 03 05 85 b6 01 00 	add    0x1b685(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    655b:	0f 82 a8 00 00 00    	jb     6609 <fwp_data.part.0.constprop.0+0x129>
    6561:	48 39 05 80 b6 01 00 	cmp    %rax,0x1b680(%rip)        # 21be8 <fwp_heap+0x1428>
    6568:	48 89 05 71 b6 01 00 	mov    %rax,0x1b671(%rip)        # 21be0 <fwp_heap+0x1420>
    656f:	73 07                	jae    6578 <fwp_data.part.0.constprop.0+0x98>
    6571:	48 89 05 70 b6 01 00 	mov    %rax,0x1b670(%rip)        # 21be8 <fwp_heap+0x1428>
    6578:	66 0f ef c0          	pxor   %xmm0,%xmm0
    657c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6581:	f2 0f 58 05 6f b6 01 	addsd  0x1b66f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    6588:	00 
    6589:	f2 0f 11 05 67 b6 01 	movsd  %xmm0,0x1b667(%rip)        # 21bf8 <fwp_heap+0x1438>
    6590:	00 
    6591:	b8 02 00 00 00       	mov    $0x2,%eax
    6596:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    659b:	66 0f 6e c8          	movd   %eax,%xmm1
    659f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    65a3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    65a7:	49 8b 04 24          	mov    (%r12),%rax
    65ab:	48 89 43 08          	mov    %rax,0x8(%rbx)
    65af:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    65b4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65b8:	48 83 c4 08          	add    $0x8,%rsp
    65bc:	48 89 d8             	mov    %rbx,%rax
    65bf:	5b                   	pop    %rbx
    65c0:	5d                   	pop    %rbp
    65c1:	41 5c                	pop    %r12
    65c3:	41 5e                	pop    %r14
    65c5:	c3                   	ret
    65c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65cd:	00 00 00 
    65d0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    65d4:	48 85 db             	test   %rbx,%rbx
    65d7:	74 1f                	je     65f8 <fwp_data.part.0.constprop.0+0x118>
    65d9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    65dd:	48 29 da             	sub    %rbx,%rdx
    65e0:	48 39 ea             	cmp    %rbp,%rdx
    65e3:	72 13                	jb     65f8 <fwp_data.part.0.constprop.0+0x118>
    65e5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    65e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    65ed:	e9 3e ff ff ff       	jmp    6530 <fwp_data.part.0.constprop.0+0x50>
    65f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65f8:	31 f6                	xor    %esi,%esi
    65fa:	bf 18 00 00 00       	mov    $0x18,%edi
    65ff:	e8 8c f6 ff ff       	call   5c90 <fwp_heap_alloc>
    6604:	48 89 c3             	mov    %rax,%rbx
    6607:	eb 88                	jmp    6591 <fwp_data.part.0.constprop.0+0xb1>
    6609:	e8 a2 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    660e:	66 90                	xchg   %ax,%ax

0000000000006610 <fwp_rc_share>:
    6610:	48 8b 05 81 b5 01 00 	mov    0x1b581(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    6617:	48 2b 3d 52 b5 01 00 	sub    0x1b552(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    661e:	48 c1 e0 10          	shl    $0x10,%rax
    6622:	48 39 c7             	cmp    %rax,%rdi
    6625:	73 4a                	jae    6671 <fwp_rc_share+0x61>
    6627:	48 89 f8             	mov    %rdi,%rax
    662a:	48 c1 e8 10          	shr    $0x10,%rax
    662e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6632:	48 8b 05 7f b5 01 00 	mov    0x1b57f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    6639:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    663d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6641:	48 85 d2             	test   %rdx,%rdx
    6644:	74 2b                	je     6671 <fwp_rc_share+0x61>
    6646:	0f b6 08             	movzbl (%rax),%ecx
    6649:	80 f9 02             	cmp    $0x2,%cl
    664c:	74 2a                	je     6678 <fwp_rc_share+0x68>
    664e:	80 f9 01             	cmp    $0x1,%cl
    6651:	75 1e                	jne    6671 <fwp_rc_share+0x61>
    6653:	8b 48 18             	mov    0x18(%rax),%ecx
    6656:	0f b7 ff             	movzwl %di,%edi
    6659:	8b 40 1c             	mov    0x1c(%rax),%eax
    665c:	48 0f af f9          	imul   %rcx,%rdi
    6660:	48 c1 ef 20          	shr    $0x20,%rdi
    6664:	48 39 c7             	cmp    %rax,%rdi
    6667:	73 08                	jae    6671 <fwp_rc_share+0x61>
    6669:	48 01 fa             	add    %rdi,%rdx
    666c:	80 3a 00             	cmpb   $0x0,(%rdx)
    666f:	75 0d                	jne    667e <fwp_rc_share+0x6e>
    6671:	c3                   	ret
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	66 85 ff             	test   %di,%di
    667b:	74 ef                	je     666c <fwp_rc_share+0x5c>
    667d:	c3                   	ret
    667e:	50                   	push   %rax
    667f:	48 8d 3d a2 62 00 00 	lea    0x62a2(%rip),%rdi        # c928 <_IO_stdin_used+0x928>
    6686:	e8 65 dd ff ff       	call   43f0 <fwp_trap>
    668b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006690 <fwp_rc_free_arr>:
    6690:	48 8b 15 01 b5 01 00 	mov    0x1b501(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6697:	48 89 f8             	mov    %rdi,%rax
    669a:	48 2b 05 cf b4 01 00 	sub    0x1b4cf(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    66a1:	48 c1 e2 10          	shl    $0x10,%rdx
    66a5:	48 39 d0             	cmp    %rdx,%rax
    66a8:	73 5b                	jae    6705 <fwp_rc_free_arr+0x75>
    66aa:	48 89 c2             	mov    %rax,%rdx
    66ad:	48 c1 ea 10          	shr    $0x10,%rdx
    66b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66b5:	48 8b 15 fc b4 01 00 	mov    0x1b4fc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    66bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    66c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    66c4:	48 85 c9             	test   %rcx,%rcx
    66c7:	74 3c                	je     6705 <fwp_rc_free_arr+0x75>
    66c9:	0f b6 32             	movzbl (%rdx),%esi
    66cc:	40 80 fe 02          	cmp    $0x2,%sil
    66d0:	74 2e                	je     6700 <fwp_rc_free_arr+0x70>
    66d2:	40 80 fe 01          	cmp    $0x1,%sil
    66d6:	75 2d                	jne    6705 <fwp_rc_free_arr+0x75>
    66d8:	8b 72 18             	mov    0x18(%rdx),%esi
    66db:	0f b7 c0             	movzwl %ax,%eax
    66de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66e1:	48 0f af c6          	imul   %rsi,%rax
    66e5:	48 c1 e8 20          	shr    $0x20,%rax
    66e9:	48 39 d0             	cmp    %rdx,%rax
    66ec:	73 17                	jae    6705 <fwp_rc_free_arr+0x75>
    66ee:	48 01 c1             	add    %rax,%rcx
    66f1:	80 39 01             	cmpb   $0x1,(%rcx)
    66f4:	75 0f                	jne    6705 <fwp_rc_free_arr+0x75>
    66f6:	e9 95 f0 ff ff       	jmp    5790 <fwp_mem_free>
    66fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6700:	66 85 c0             	test   %ax,%ax
    6703:	74 ec                	je     66f1 <fwp_rc_free_arr+0x61>
    6705:	c3                   	ret
    6706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    670d:	00 00 00 

0000000000006710 <fwp_rc_dup>:
    6710:	f3 0f 1e fa          	endbr64
    6714:	48 8b 05 7d b4 01 00 	mov    0x1b47d(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    671b:	48 2b 3d 4e b4 01 00 	sub    0x1b44e(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    6722:	48 c1 e0 10          	shl    $0x10,%rax
    6726:	48 39 c7             	cmp    %rax,%rdi
    6729:	73 56                	jae    6781 <fwp_rc_dup+0x71>
    672b:	48 89 f8             	mov    %rdi,%rax
    672e:	48 c1 e8 10          	shr    $0x10,%rax
    6732:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6736:	48 8b 05 7b b4 01 00 	mov    0x1b47b(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    673d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6741:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6745:	48 85 c0             	test   %rax,%rax
    6748:	74 37                	je     6781 <fwp_rc_dup+0x71>
    674a:	0f b6 0a             	movzbl (%rdx),%ecx
    674d:	80 f9 02             	cmp    $0x2,%cl
    6750:	74 36                	je     6788 <fwp_rc_dup+0x78>
    6752:	80 f9 01             	cmp    $0x1,%cl
    6755:	75 2a                	jne    6781 <fwp_rc_dup+0x71>
    6757:	8b 4a 18             	mov    0x18(%rdx),%ecx
    675a:	0f b7 ff             	movzwl %di,%edi
    675d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6760:	48 0f af f9          	imul   %rcx,%rdi
    6764:	48 c1 ef 20          	shr    $0x20,%rdi
    6768:	48 39 d7             	cmp    %rdx,%rdi
    676b:	73 14                	jae    6781 <fwp_rc_dup+0x71>
    676d:	48 01 f8             	add    %rdi,%rax
    6770:	0f b6 10             	movzbl (%rax),%edx
    6773:	84 d2                	test   %dl,%dl
    6775:	74 0a                	je     6781 <fwp_rc_dup+0x71>
    6777:	80 fa fd             	cmp    $0xfd,%dl
    677a:	77 14                	ja     6790 <fwp_rc_dup+0x80>
    677c:	83 c2 01             	add    $0x1,%edx
    677f:	88 10                	mov    %dl,(%rax)
    6781:	c3                   	ret
    6782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6788:	66 85 ff             	test   %di,%di
    678b:	74 e3                	je     6770 <fwp_rc_dup+0x60>
    678d:	c3                   	ret
    678e:	66 90                	xchg   %ax,%ax
    6790:	48 89 c7             	mov    %rax,%rdi
    6793:	e9 98 ec ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6798:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    679f:	00 

00000000000067a0 <fwp_drop0>:
    67a0:	f3 0f 1e fa          	endbr64
    67a4:	48 8b 15 ed b3 01 00 	mov    0x1b3ed(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    67ab:	48 89 f8             	mov    %rdi,%rax
    67ae:	48 2b 05 bb b3 01 00 	sub    0x1b3bb(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    67b5:	48 c1 e2 10          	shl    $0x10,%rdx
    67b9:	48 39 d0             	cmp    %rdx,%rax
    67bc:	0f 83 be 00 00 00    	jae    6880 <fwp_drop0+0xe0>
    67c2:	48 83 ec 18          	sub    $0x18,%rsp
    67c6:	4c 8d 05 f3 9f 01 00 	lea    0x19ff3(%rip),%r8        # 207c0 <fwp_heap>
    67cd:	48 89 c2             	mov    %rax,%rdx
    67d0:	48 c1 ea 10          	shr    $0x10,%rdx
    67d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67d8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    67df:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67e7:	48 85 d2             	test   %rdx,%rdx
    67ea:	74 3c                	je     6828 <fwp_drop0+0x88>
    67ec:	0f b6 31             	movzbl (%rcx),%esi
    67ef:	40 80 fe 02          	cmp    $0x2,%sil
    67f3:	74 3b                	je     6830 <fwp_drop0+0x90>
    67f5:	40 80 fe 01          	cmp    $0x1,%sil
    67f9:	75 2d                	jne    6828 <fwp_drop0+0x88>
    67fb:	8b 71 18             	mov    0x18(%rcx),%esi
    67fe:	0f b7 c0             	movzwl %ax,%eax
    6801:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6804:	48 0f af c6          	imul   %rsi,%rax
    6808:	48 c1 e8 20          	shr    $0x20,%rax
    680c:	48 39 c8             	cmp    %rcx,%rax
    680f:	73 17                	jae    6828 <fwp_drop0+0x88>
    6811:	48 01 c2             	add    %rax,%rdx
    6814:	0f b6 02             	movzbl (%rdx),%eax
    6817:	84 c0                	test   %al,%al
    6819:	74 0d                	je     6828 <fwp_drop0+0x88>
    681b:	3c 01                	cmp    $0x1,%al
    681d:	74 21                	je     6840 <fwp_drop0+0xa0>
    681f:	3c ff                	cmp    $0xff,%al
    6821:	74 65                	je     6888 <fwp_drop0+0xe8>
    6823:	83 e8 01             	sub    $0x1,%eax
    6826:	88 02                	mov    %al,(%rdx)
    6828:	48 83 c4 18          	add    $0x18,%rsp
    682c:	c3                   	ret
    682d:	0f 1f 00             	nopl   (%rax)
    6830:	66 85 c0             	test   %ax,%ax
    6833:	74 df                	je     6814 <fwp_drop0+0x74>
    6835:	48 83 c4 18          	add    $0x18,%rsp
    6839:	c3                   	ret
    683a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6840:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6844:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6849:	e8 42 fe ff ff       	call   6690 <fwp_rc_free_arr>
    684e:	4c 8d 05 6b 9f 01 00 	lea    0x19f6b(%rip),%r8        # 207c0 <fwp_heap>
    6855:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    685a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6861:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6868:	48 c1 e2 10          	shl    $0x10,%rdx
    686c:	48 39 d0             	cmp    %rdx,%rax
    686f:	73 b7                	jae    6828 <fwp_drop0+0x88>
    6871:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6876:	e9 52 ff ff ff       	jmp    67cd <fwp_drop0+0x2d>
    687b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6880:	c3                   	ret
    6881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6888:	48 89 d0             	mov    %rdx,%rax
    688b:	48 c1 e8 11          	shr    $0x11,%rax
    688f:	48 31 d0             	xor    %rdx,%rax
    6892:	48 89 c1             	mov    %rax,%rcx
    6895:	48 c1 e9 09          	shr    $0x9,%rcx
    6899:	48 31 c8             	xor    %rcx,%rax
    689c:	0f b6 c8             	movzbl %al,%ecx
    689f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    68a6:	00 
    68a7:	48 85 c0             	test   %rax,%rax
    68aa:	75 1d                	jne    68c9 <fwp_drop0+0x129>
    68ac:	eb 56                	jmp    6904 <fwp_drop0+0x164>
    68ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68bc:	00 00 00 00 
    68c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    68c4:	48 85 c0             	test   %rax,%rax
    68c7:	74 3b                	je     6904 <fwp_drop0+0x164>
    68c9:	48 89 c1             	mov    %rax,%rcx
    68cc:	48 39 10             	cmp    %rdx,(%rax)
    68cf:	75 ef                	jne    68c0 <fwp_drop0+0x120>
    68d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    68d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    68d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    68dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    68e4:	0f 85 3e ff ff ff    	jne    6828 <fwp_drop0+0x88>
    68ea:	48 89 d7             	mov    %rdx,%rdi
    68ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    68f2:	e8 59 ec ff ff       	call   5550 <fwp_rc_forget_slot>
    68f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    68fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    68ff:	e9 24 ff ff ff       	jmp    6828 <fwp_drop0+0x88>
    6904:	48 8d 3d 7d 5f 00 00 	lea    0x5f7d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    690b:	e8 e0 da ff ff       	call   43f0 <fwp_trap>

0000000000006910 <fwp_arg_drop12>:
    6910:	f3 0f 1e fa          	endbr64
    6914:	85 f6                	test   %esi,%esi
    6916:	75 04                	jne    691c <fwp_arg_drop12+0xc>
    6918:	85 d2                	test   %edx,%edx
    691a:	75 04                	jne    6920 <fwp_arg_drop12+0x10>
    691c:	c3                   	ret
    691d:	0f 1f 00             	nopl   (%rax)
    6920:	48 8b 3f             	mov    (%rdi),%rdi
    6923:	e9 78 fe ff ff       	jmp    67a0 <fwp_drop0>
    6928:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    692f:	00 

0000000000006930 <fwp_drop1>:
    6930:	f3 0f 1e fa          	endbr64
    6934:	48 8b 15 5d b2 01 00 	mov    0x1b25d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    693b:	48 89 f8             	mov    %rdi,%rax
    693e:	48 2b 05 2b b2 01 00 	sub    0x1b22b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6945:	48 c1 e2 10          	shl    $0x10,%rdx
    6949:	48 39 d0             	cmp    %rdx,%rax
    694c:	0f 83 be 00 00 00    	jae    6a10 <fwp_drop1+0xe0>
    6952:	48 83 ec 18          	sub    $0x18,%rsp
    6956:	4c 8d 05 63 9e 01 00 	lea    0x19e63(%rip),%r8        # 207c0 <fwp_heap>
    695d:	48 89 c2             	mov    %rax,%rdx
    6960:	48 c1 ea 10          	shr    $0x10,%rdx
    6964:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6968:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    696f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6973:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6977:	48 85 d2             	test   %rdx,%rdx
    697a:	74 3c                	je     69b8 <fwp_drop1+0x88>
    697c:	0f b6 31             	movzbl (%rcx),%esi
    697f:	40 80 fe 02          	cmp    $0x2,%sil
    6983:	74 3b                	je     69c0 <fwp_drop1+0x90>
    6985:	40 80 fe 01          	cmp    $0x1,%sil
    6989:	75 2d                	jne    69b8 <fwp_drop1+0x88>
    698b:	8b 71 18             	mov    0x18(%rcx),%esi
    698e:	0f b7 c0             	movzwl %ax,%eax
    6991:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6994:	48 0f af c6          	imul   %rsi,%rax
    6998:	48 c1 e8 20          	shr    $0x20,%rax
    699c:	48 39 c8             	cmp    %rcx,%rax
    699f:	73 17                	jae    69b8 <fwp_drop1+0x88>
    69a1:	48 01 c2             	add    %rax,%rdx
    69a4:	0f b6 02             	movzbl (%rdx),%eax
    69a7:	84 c0                	test   %al,%al
    69a9:	74 0d                	je     69b8 <fwp_drop1+0x88>
    69ab:	3c 01                	cmp    $0x1,%al
    69ad:	74 21                	je     69d0 <fwp_drop1+0xa0>
    69af:	3c ff                	cmp    $0xff,%al
    69b1:	74 65                	je     6a18 <fwp_drop1+0xe8>
    69b3:	83 e8 01             	sub    $0x1,%eax
    69b6:	88 02                	mov    %al,(%rdx)
    69b8:	48 83 c4 18          	add    $0x18,%rsp
    69bc:	c3                   	ret
    69bd:	0f 1f 00             	nopl   (%rax)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 df                	je     69a4 <fwp_drop1+0x74>
    69c5:	48 83 c4 18          	add    $0x18,%rsp
    69c9:	c3                   	ret
    69ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69d0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    69d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    69d9:	e8 b2 fc ff ff       	call   6690 <fwp_rc_free_arr>
    69de:	4c 8d 05 db 9d 01 00 	lea    0x19ddb(%rip),%r8        # 207c0 <fwp_heap>
    69e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    69ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    69f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    69f8:	48 c1 e2 10          	shl    $0x10,%rdx
    69fc:	48 39 d0             	cmp    %rdx,%rax
    69ff:	73 b7                	jae    69b8 <fwp_drop1+0x88>
    6a01:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a06:	e9 52 ff ff ff       	jmp    695d <fwp_drop1+0x2d>
    6a0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a10:	c3                   	ret
    6a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a18:	48 89 d0             	mov    %rdx,%rax
    6a1b:	48 c1 e8 11          	shr    $0x11,%rax
    6a1f:	48 31 d0             	xor    %rdx,%rax
    6a22:	48 89 c1             	mov    %rax,%rcx
    6a25:	48 c1 e9 09          	shr    $0x9,%rcx
    6a29:	48 31 c8             	xor    %rcx,%rax
    6a2c:	0f b6 c8             	movzbl %al,%ecx
    6a2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6a36:	00 
    6a37:	48 85 c0             	test   %rax,%rax
    6a3a:	75 0d                	jne    6a49 <fwp_drop1+0x119>
    6a3c:	eb 46                	jmp    6a84 <fwp_drop1+0x154>
    6a3e:	66 90                	xchg   %ax,%ax
    6a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6a44:	48 85 c0             	test   %rax,%rax
    6a47:	74 3b                	je     6a84 <fwp_drop1+0x154>
    6a49:	48 89 c1             	mov    %rax,%rcx
    6a4c:	48 39 10             	cmp    %rdx,(%rax)
    6a4f:	75 ef                	jne    6a40 <fwp_drop1+0x110>
    6a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6a64:	0f 85 4e ff ff ff    	jne    69b8 <fwp_drop1+0x88>
    6a6a:	48 89 d7             	mov    %rdx,%rdi
    6a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a72:	e8 d9 ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a7f:	e9 34 ff ff ff       	jmp    69b8 <fwp_drop1+0x88>
    6a84:	48 8d 3d fd 5d 00 00 	lea    0x5dfd(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    6a8b:	e8 60 d9 ff ff       	call   43f0 <fwp_trap>

0000000000006a90 <fwp_closure_drop>:
    6a90:	48 8b 15 01 b1 01 00 	mov    0x1b101(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6a97:	48 89 f8             	mov    %rdi,%rax
    6a9a:	48 2b 05 cf b0 01 00 	sub    0x1b0cf(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    6aa5:	48 39 d0             	cmp    %rdx,%rax
    6aa8:	73 6b                	jae    6b15 <fwp_closure_drop+0x85>
    6aaa:	48 89 c2             	mov    %rax,%rdx
    6aad:	48 c1 ea 10          	shr    $0x10,%rdx
    6ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ab5:	48 8b 15 fc b0 01 00 	mov    0x1b0fc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6abc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ac0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ac4:	48 85 d2             	test   %rdx,%rdx
    6ac7:	74 4c                	je     6b15 <fwp_closure_drop+0x85>
    6ac9:	0f b6 31             	movzbl (%rcx),%esi
    6acc:	40 80 fe 02          	cmp    $0x2,%sil
    6ad0:	74 3e                	je     6b10 <fwp_closure_drop+0x80>
    6ad2:	40 80 fe 01          	cmp    $0x1,%sil
    6ad6:	75 3d                	jne    6b15 <fwp_closure_drop+0x85>
    6ad8:	8b 71 18             	mov    0x18(%rcx),%esi
    6adb:	0f b7 c0             	movzwl %ax,%eax
    6ade:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ae1:	48 0f af c6          	imul   %rsi,%rax
    6ae5:	48 c1 e8 20          	shr    $0x20,%rax
    6ae9:	48 39 c8             	cmp    %rcx,%rax
    6aec:	73 27                	jae    6b15 <fwp_closure_drop+0x85>
    6aee:	48 01 c2             	add    %rax,%rdx
    6af1:	0f b6 02             	movzbl (%rdx),%eax
    6af4:	84 c0                	test   %al,%al
    6af6:	74 1d                	je     6b15 <fwp_closure_drop+0x85>
    6af8:	3c 01                	cmp    $0x1,%al
    6afa:	74 24                	je     6b20 <fwp_closure_drop+0x90>
    6afc:	3c ff                	cmp    $0xff,%al
    6afe:	74 48                	je     6b48 <fwp_closure_drop+0xb8>
    6b00:	83 e8 01             	sub    $0x1,%eax
    6b03:	88 02                	mov    %al,(%rdx)
    6b05:	c3                   	ret
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 
    6b10:	66 85 c0             	test   %ax,%ax
    6b13:	74 dc                	je     6af1 <fwp_closure_drop+0x61>
    6b15:	c3                   	ret
    6b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b1d:	00 00 00 
    6b20:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6b27:	ff ff 
    6b29:	48 85 c0             	test   %rax,%rax
    6b2c:	74 12                	je     6b40 <fwp_closure_drop+0xb0>
    6b2e:	48 89 fe             	mov    %rdi,%rsi
    6b31:	48 89 c7             	mov    %rax,%rdi
    6b34:	e9 17 d9 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6b39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b40:	e9 bb da ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6b45:	0f 1f 00             	nopl   (%rax)
    6b48:	48 89 d0             	mov    %rdx,%rax
    6b4b:	48 8d 35 6e 9c 01 00 	lea    0x19c6e(%rip),%rsi        # 207c0 <fwp_heap>
    6b52:	48 83 ec 18          	sub    $0x18,%rsp
    6b56:	48 c1 e8 11          	shr    $0x11,%rax
    6b5a:	48 31 d0             	xor    %rdx,%rax
    6b5d:	48 89 c1             	mov    %rax,%rcx
    6b60:	48 c1 e9 09          	shr    $0x9,%rcx
    6b64:	48 31 c8             	xor    %rcx,%rax
    6b67:	0f b6 c8             	movzbl %al,%ecx
    6b6a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6b71:	00 
    6b72:	48 85 c0             	test   %rax,%rax
    6b75:	75 12                	jne    6b89 <fwp_closure_drop+0xf9>
    6b77:	eb 49                	jmp    6bc2 <fwp_closure_drop+0x132>
    6b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b84:	48 85 c0             	test   %rax,%rax
    6b87:	74 39                	je     6bc2 <fwp_closure_drop+0x132>
    6b89:	48 89 c1             	mov    %rax,%rcx
    6b8c:	48 39 10             	cmp    %rdx,(%rax)
    6b8f:	75 ef                	jne    6b80 <fwp_closure_drop+0xf0>
    6b91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ba4:	74 05                	je     6bab <fwp_closure_drop+0x11b>
    6ba6:	48 83 c4 18          	add    $0x18,%rsp
    6baa:	c3                   	ret
    6bab:	48 89 d7             	mov    %rdx,%rdi
    6bae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bb3:	e8 98 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6bb8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6bc0:	eb e4                	jmp    6ba6 <fwp_closure_drop+0x116>
    6bc2:	48 8d 3d bf 5c 00 00 	lea    0x5cbf(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    6bc9:	e8 22 d8 ff ff       	call   43f0 <fwp_trap>
    6bce:	66 90                	xchg   %ax,%ax

0000000000006bd0 <fwp_owned_tape_release>:
    6bd0:	48 85 ff             	test   %rdi,%rdi
    6bd3:	0f 84 f7 00 00 00    	je     6cd0 <fwp_owned_tape_release+0x100>
    6bd9:	41 54                	push   %r12
    6bdb:	55                   	push   %rbp
    6bdc:	53                   	push   %rbx
    6bdd:	48 8b 07             	mov    (%rdi),%rax
    6be0:	48 85 c0             	test   %rax,%rax
    6be3:	74 08                	je     6bed <fwp_owned_tape_release+0x1d>
    6be5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6be9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6bed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6bf1:	48 85 d2             	test   %rdx,%rdx
    6bf4:	74 03                	je     6bf9 <fwp_owned_tape_release+0x29>
    6bf6:	48 89 02             	mov    %rax,(%rdx)
    6bf9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6bfd:	48 89 fb             	mov    %rdi,%rbx
    6c00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6c04:	48 85 c0             	test   %rax,%rax
    6c07:	0f 84 89 00 00 00    	je     6c96 <fwp_owned_tape_release+0xc6>
    6c0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6c11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6c15:	7e 47                	jle    6c5e <fwp_owned_tape_release+0x8e>
    6c17:	31 ed                	xor    %ebp,%ebp
    6c19:	eb 0d                	jmp    6c28 <fwp_owned_tape_release+0x58>
    6c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6c28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6c2c:	49 89 ec             	mov    %rbp,%r12
    6c2f:	48 83 c5 01          	add    $0x1,%rbp
    6c33:	49 c1 e4 04          	shl    $0x4,%r12
    6c37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6c3b:	ff d0                	call   *%rax
    6c3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6c41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6c46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c4a:	ff 50 68             	call   *0x68(%rax)
    6c4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6c51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6c55:	48 39 e8             	cmp    %rbp,%rax
    6c58:	7f c6                	jg     6c20 <fwp_owned_tape_release+0x50>
    6c5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c5e:	31 ed                	xor    %ebp,%ebp
    6c60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6c65:	7e 28                	jle    6c8f <fwp_owned_tape_release+0xbf>
    6c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c6e:	00 00 
    6c70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6c74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6c78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6c7c:	74 07                	je     6c85 <fwp_owned_tape_release+0xb5>
    6c7e:	ff 52 68             	call   *0x68(%rdx)
    6c81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c85:	48 83 c5 01          	add    $0x1,%rbp
    6c89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6c8d:	7f e1                	jg     6c70 <fwp_owned_tape_release+0xa0>
    6c8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c93:	ff 52 68             	call   *0x68(%rdx)
    6c96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6c9a:	e8 f1 fd ff ff       	call   6a90 <fwp_closure_drop>
    6c9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ca3:	e8 e8 fd ff ff       	call   6a90 <fwp_closure_drop>
    6ca8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6cac:	e8 df fd ff ff       	call   6a90 <fwp_closure_drop>
    6cb1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6cb5:	e8 d6 ea ff ff       	call   5790 <fwp_mem_free>
    6cba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6cbe:	e8 cd ea ff ff       	call   5790 <fwp_mem_free>
    6cc3:	48 89 df             	mov    %rbx,%rdi
    6cc6:	5b                   	pop    %rbx
    6cc7:	5d                   	pop    %rbp
    6cc8:	41 5c                	pop    %r12
    6cca:	e9 c1 ea ff ff       	jmp    5790 <fwp_mem_free>
    6ccf:	90                   	nop
    6cd0:	c3                   	ret
    6cd1:	0f 1f 40 00          	nopl   0x0(%rax)
    6cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cdc:	00 00 00 00 

0000000000006ce0 <fwp_tape_finish>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	41 56                	push   %r14
    6ce6:	48 8d 3d b3 93 01 00 	lea    0x193b3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6ced:	41 55                	push   %r13
    6cef:	41 54                	push   %r12
    6cf1:	55                   	push   %rbp
    6cf2:	53                   	push   %rbx
    6cf3:	e8 18 d4 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6cf8:	48 83 3d e8 93 01 00 	cmpq   $0x0,0x193e8(%rip)        # 200e8 <fwp_ntapes>
    6cff:	00 
    6d00:	48 c7 05 7d 93 01 00 	movq   $0x0,0x1937d(%rip)        # 20088 <fwp_tape_cached_bytes>
    6d07:	00 00 00 00 
    6d0b:	7e 68                	jle    6d75 <fwp_tape_finish+0x95>
    6d0d:	45 31 e4             	xor    %r12d,%r12d
    6d10:	31 ed                	xor    %ebp,%ebp
    6d12:	0f 1f 00             	nopl   (%rax)
    6d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d1c:	00 00 00 00 
    6d20:	48 8b 1d c9 93 01 00 	mov    0x193c9(%rip),%rbx        # 200f0 <fwp_tapes>
    6d27:	48 83 c5 01          	add    $0x1,%rbp
    6d2b:	4c 01 e3             	add    %r12,%rbx
    6d2e:	49 83 c4 68          	add    $0x68,%r12
    6d32:	48 89 df             	mov    %rbx,%rdi
    6d35:	e8 c6 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d3a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6d3e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d42:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6d46:	e8 75 c6 ff ff       	call   33c0 <free@plt>
    6d4b:	4c 89 f7             	mov    %r14,%rdi
    6d4e:	e8 6d c6 ff ff       	call   33c0 <free@plt>
    6d53:	4c 89 ef             	mov    %r13,%rdi
    6d56:	e8 65 c6 ff ff       	call   33c0 <free@plt>
    6d5b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6d5f:	e8 6c fe ff ff       	call   6bd0 <fwp_owned_tape_release>
    6d64:	48 39 2d 7d 93 01 00 	cmp    %rbp,0x1937d(%rip)        # 200e8 <fwp_ntapes>
    6d6b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6d72:	00 
    6d73:	7f ab                	jg     6d20 <fwp_tape_finish+0x40>
    6d75:	48 8b 3d 74 93 01 00 	mov    0x19374(%rip),%rdi        # 200f0 <fwp_tapes>
    6d7c:	e8 3f c6 ff ff       	call   33c0 <free@plt>
    6d81:	5b                   	pop    %rbx
    6d82:	5d                   	pop    %rbp
    6d83:	48 c7 05 62 93 01 00 	movq   $0x0,0x19362(%rip)        # 200f0 <fwp_tapes>
    6d8a:	00 00 00 00 
    6d8e:	48 c7 05 47 93 01 00 	movq   $0x0,0x19347(%rip)        # 200e0 <fwp_tapes_cap>
    6d95:	00 00 00 00 
    6d99:	41 5c                	pop    %r12
    6d9b:	48 c7 05 42 93 01 00 	movq   $0x0,0x19342(%rip)        # 200e8 <fwp_ntapes>
    6da2:	00 00 00 00 
    6da6:	41 5d                	pop    %r13
    6da8:	48 c7 05 25 93 01 00 	movq   $0x0,0x19325(%rip)        # 200d8 <fwp_tape_next_slot>
    6daf:	00 00 00 00 
    6db3:	41 5e                	pop    %r14
    6db5:	c3                   	ret
    6db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dbd:	00 00 00 

0000000000006dc0 <fwp_tape_scope_release>:
    6dc0:	f3 0f 1e fa          	endbr64
    6dc4:	41 55                	push   %r13
    6dc6:	41 54                	push   %r12
    6dc8:	55                   	push   %rbp
    6dc9:	53                   	push   %rbx
    6dca:	48 83 ec 58          	sub    $0x58,%rsp
    6dce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6dd5:	00 00 
    6dd7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6ddc:	48 63 07             	movslq (%rdi),%rax
    6ddf:	85 c0                	test   %eax,%eax
    6de1:	0f 88 05 01 00 00    	js     6eec <fwp_tape_scope_release+0x12c>
    6de7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6dee:	ec c4 4e 
    6df1:	48 89 fb             	mov    %rdi,%rbx
    6df4:	eb 3c                	jmp    6e32 <fwp_tape_scope_release+0x72>
    6df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dfd:	00 00 00 
    6e00:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6e05:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6e09:	e8 b2 c5 ff ff       	call   33c0 <free@plt>
    6e0e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6e12:	e8 a9 c5 ff ff       	call   33c0 <free@plt>
    6e17:	4c 89 ef             	mov    %r13,%rdi
    6e1a:	e8 a1 c5 ff ff       	call   33c0 <free@plt>
    6e1f:	4c 89 e7             	mov    %r12,%rdi
    6e22:	e8 a9 fd ff ff       	call   6bd0 <fwp_owned_tape_release>
    6e27:	48 63 03             	movslq (%rbx),%rax
    6e2a:	85 c0                	test   %eax,%eax
    6e2c:	0f 88 ba 00 00 00    	js     6eec <fwp_tape_scope_release+0x12c>
    6e32:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6e36:	48 8b 35 b3 92 01 00 	mov    0x192b3(%rip),%rsi        # 200f0 <fwp_tapes>
    6e3d:	4c 01 c6             	add    %r8,%rsi
    6e40:	48 89 f7             	mov    %rsi,%rdi
    6e43:	e8 b8 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e48:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6e4d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6e52:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6e59:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6e5d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6e61:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6e68:	00 
    6e69:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6e6e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6e72:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6e77:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6e7b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6e80:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6e87:	00 
    6e88:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6e8f:	00 
    6e90:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6e97:	00 
    6e98:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6e9d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6ea2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6ea6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6eaa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6eae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6eb4:	77 18                	ja     6ece <fwp_tape_scope_release+0x10e>
    6eb6:	49 c1 f8 03          	sar    $0x3,%r8
    6eba:	4c 0f af c5          	imul   %rbp,%r8
    6ebe:	4c 3b 05 13 92 01 00 	cmp    0x19213(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6ec5:	7d 07                	jge    6ece <fwp_tape_scope_release+0x10e>
    6ec7:	4c 89 05 0a 92 01 00 	mov    %r8,0x1920a(%rip)        # 200d8 <fwp_tape_next_slot>
    6ece:	4d 85 e4             	test   %r12,%r12
    6ed1:	0f 85 29 ff ff ff    	jne    6e00 <fwp_tape_scope_release+0x40>
    6ed7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6edc:	e8 8f e1 ff ff       	call   5070 <fwp_tape_buffers_release>
    6ee1:	48 63 03             	movslq (%rbx),%rax
    6ee4:	85 c0                	test   %eax,%eax
    6ee6:	0f 89 46 ff ff ff    	jns    6e32 <fwp_tape_scope_release+0x72>
    6eec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ef1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ef8:	00 00 
    6efa:	75 0b                	jne    6f07 <fwp_tape_scope_release+0x147>
    6efc:	48 83 c4 58          	add    $0x58,%rsp
    6f00:	5b                   	pop    %rbx
    6f01:	5d                   	pop    %rbp
    6f02:	41 5c                	pop    %r12
    6f04:	41 5d                	pop    %r13
    6f06:	c3                   	ret
    6f07:	e8 54 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f10 <fwp_task_dispose>:
    6f10:	53                   	push   %rbx
    6f11:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f15:	0f 84 2b c8 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f1b:	48 89 fb             	mov    %rdi,%rbx
    6f1e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f23:	0f 85 1d c8 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f29:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f2d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6f34:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6f3b:	00 
    6f3c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6f40:	48 85 ff             	test   %rdi,%rdi
    6f43:	74 07                	je     6f4c <fwp_task_dispose+0x3c>
    6f45:	48 85 c0             	test   %rax,%rax
    6f48:	74 02                	je     6f4c <fwp_task_dispose+0x3c>
    6f4a:	ff d0                	call   *%rax
    6f4c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6f53:	e8 38 e8 ff ff       	call   5790 <fwp_mem_free>
    6f58:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6f5f:	00 00 00 00 
    6f63:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6f67:	74 6f                	je     6fd8 <fwp_task_dispose+0xc8>
    6f69:	48 8b 15 28 ac 01 00 	mov    0x1ac28(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6f70:	48 89 d8             	mov    %rbx,%rax
    6f73:	48 2b 05 f6 ab 01 00 	sub    0x1abf6(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6f7a:	48 c1 e2 10          	shl    $0x10,%rdx
    6f7e:	48 39 d0             	cmp    %rdx,%rax
    6f81:	73 4c                	jae    6fcf <fwp_task_dispose+0xbf>
    6f83:	48 89 c2             	mov    %rax,%rdx
    6f86:	48 c1 ea 10          	shr    $0x10,%rdx
    6f8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f8e:	48 8b 15 23 ac 01 00 	mov    0x1ac23(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6f95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f99:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f9d:	48 85 c9             	test   %rcx,%rcx
    6fa0:	74 2d                	je     6fcf <fwp_task_dispose+0xbf>
    6fa2:	0f b6 32             	movzbl (%rdx),%esi
    6fa5:	40 80 fe 02          	cmp    $0x2,%sil
    6fa9:	74 3d                	je     6fe8 <fwp_task_dispose+0xd8>
    6fab:	40 80 fe 01          	cmp    $0x1,%sil
    6faf:	75 1e                	jne    6fcf <fwp_task_dispose+0xbf>
    6fb1:	8b 72 18             	mov    0x18(%rdx),%esi
    6fb4:	0f b7 c0             	movzwl %ax,%eax
    6fb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fba:	48 0f af c6          	imul   %rsi,%rax
    6fbe:	48 c1 e8 20          	shr    $0x20,%rax
    6fc2:	48 39 d0             	cmp    %rdx,%rax
    6fc5:	73 08                	jae    6fcf <fwp_task_dispose+0xbf>
    6fc7:	48 01 c1             	add    %rax,%rcx
    6fca:	80 39 01             	cmpb   $0x1,(%rcx)
    6fcd:	74 09                	je     6fd8 <fwp_task_dispose+0xc8>
    6fcf:	5b                   	pop    %rbx
    6fd0:	c3                   	ret
    6fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fd8:	48 89 df             	mov    %rbx,%rdi
    6fdb:	5b                   	pop    %rbx
    6fdc:	e9 af e7 ff ff       	jmp    5790 <fwp_mem_free>
    6fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fe8:	66 85 c0             	test   %ax,%ax
    6feb:	74 dd                	je     6fca <fwp_task_dispose+0xba>
    6fed:	5b                   	pop    %rbx
    6fee:	c3                   	ret
    6fef:	90                   	nop

0000000000006ff0 <fwp_free_zombie>:
    6ff0:	48 8b 15 99 97 01 00 	mov    0x19799(%rip),%rdx        # 20790 <fwp_zombie>
    6ff7:	48 85 d2             	test   %rdx,%rdx
    6ffa:	0f 84 98 00 00 00    	je     7098 <fwp_free_zombie+0xa8>
    7000:	48 3b 15 99 97 01 00 	cmp    0x19799(%rip),%rdx        # 207a0 <fwp_cur>
    7007:	0f 84 8b 00 00 00    	je     7098 <fwp_free_zombie+0xa8>
    700d:	48 83 ec 18          	sub    $0x18,%rsp
    7011:	48 63 05 4c 91 01 00 	movslq 0x1914c(%rip),%rax        # 20164 <fwp_stack_pool_n>
    7018:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    701c:	83 f8 3f             	cmp    $0x3f,%eax
    701f:	7f 7f                	jg     70a0 <fwp_free_zombie+0xb0>
    7021:	8d 48 01             	lea    0x1(%rax),%ecx
    7024:	89 0d 3a 91 01 00    	mov    %ecx,0x1913a(%rip)        # 20164 <fwp_stack_pool_n>
    702a:	48 8d 0d 4f 91 01 00 	lea    0x1914f(%rip),%rcx        # 20180 <fwp_stack_pool>
    7031:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7035:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    703c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7040:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7047:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    704b:	48 85 c9             	test   %rcx,%rcx
    704e:	0f 84 fc 00 00 00    	je     7150 <fwp_free_zombie+0x160>
    7054:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    705b:	48 85 c0             	test   %rax,%rax
    705e:	74 07                	je     7067 <fwp_free_zombie+0x77>
    7060:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7067:	8b 42 5c             	mov    0x5c(%rdx),%eax
    706a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    706e:	48 c7 05 17 97 01 00 	movq   $0x0,0x19717(%rip)        # 20790 <fwp_zombie>
    7075:	00 00 00 00 
    7079:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7080:	85 c0                	test   %eax,%eax
    7082:	74 34                	je     70b8 <fwp_free_zombie+0xc8>
    7084:	83 f8 01             	cmp    $0x1,%eax
    7087:	0f 84 b3 00 00 00    	je     7140 <fwp_free_zombie+0x150>
    708d:	48 83 c4 18          	add    $0x18,%rsp
    7091:	c3                   	ret
    7092:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7098:	c3                   	ret
    7099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    70a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70a9:	e8 32 c5 ff ff       	call   35e0 <munmap@plt>
    70ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70b3:	eb 80                	jmp    7035 <fwp_free_zombie+0x45>
    70b5:	0f 1f 00             	nopl   (%rax)
    70b8:	48 8b 0d d9 aa 01 00 	mov    0x1aad9(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    70bf:	48 89 d0             	mov    %rdx,%rax
    70c2:	48 2b 05 a7 aa 01 00 	sub    0x1aaa7(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    70c9:	48 c1 e1 10          	shl    $0x10,%rcx
    70cd:	48 39 c8             	cmp    %rcx,%rax
    70d0:	73 bb                	jae    708d <fwp_free_zombie+0x9d>
    70d2:	48 89 c1             	mov    %rax,%rcx
    70d5:	48 c1 e9 10          	shr    $0x10,%rcx
    70d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    70dd:	48 8b 0d d4 aa 01 00 	mov    0x1aad4(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    70e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    70e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    70ec:	48 85 c9             	test   %rcx,%rcx
    70ef:	74 9c                	je     708d <fwp_free_zombie+0x9d>
    70f1:	0f b6 3e             	movzbl (%rsi),%edi
    70f4:	40 80 ff 02          	cmp    $0x2,%dil
    70f8:	74 66                	je     7160 <fwp_free_zombie+0x170>
    70fa:	40 80 ff 01          	cmp    $0x1,%dil
    70fe:	75 8d                	jne    708d <fwp_free_zombie+0x9d>
    7100:	8b 7e 18             	mov    0x18(%rsi),%edi
    7103:	0f b7 c0             	movzwl %ax,%eax
    7106:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7109:	48 0f af c7          	imul   %rdi,%rax
    710d:	48 c1 e8 20          	shr    $0x20,%rax
    7111:	48 39 f0             	cmp    %rsi,%rax
    7114:	0f 83 73 ff ff ff    	jae    708d <fwp_free_zombie+0x9d>
    711a:	48 01 c1             	add    %rax,%rcx
    711d:	0f b6 01             	movzbl (%rcx),%eax
    7120:	84 c0                	test   %al,%al
    7122:	0f 84 65 ff ff ff    	je     708d <fwp_free_zombie+0x9d>
    7128:	3c 01                	cmp    $0x1,%al
    712a:	74 14                	je     7140 <fwp_free_zombie+0x150>
    712c:	3c ff                	cmp    $0xff,%al
    712e:	74 3b                	je     716b <fwp_free_zombie+0x17b>
    7130:	83 e8 01             	sub    $0x1,%eax
    7133:	88 01                	mov    %al,(%rcx)
    7135:	e9 53 ff ff ff       	jmp    708d <fwp_free_zombie+0x9d>
    713a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7140:	48 89 d7             	mov    %rdx,%rdi
    7143:	48 83 c4 18          	add    $0x18,%rsp
    7147:	e9 c4 fd ff ff       	jmp    6f10 <fwp_task_dispose>
    714c:	0f 1f 40 00          	nopl   0x0(%rax)
    7150:	48 89 05 11 96 01 00 	mov    %rax,0x19611(%rip)        # 20768 <fwp_tasks_active>
    7157:	e9 ff fe ff ff       	jmp    705b <fwp_free_zombie+0x6b>
    715c:	0f 1f 40 00          	nopl   0x0(%rax)
    7160:	66 85 c0             	test   %ax,%ax
    7163:	0f 85 24 ff ff ff    	jne    708d <fwp_free_zombie+0x9d>
    7169:	eb b2                	jmp    711d <fwp_free_zombie+0x12d>
    716b:	48 89 ca             	mov    %rcx,%rdx
    716e:	48 8d 35 4b 96 01 00 	lea    0x1964b(%rip),%rsi        # 207c0 <fwp_heap>
    7175:	48 c1 ea 11          	shr    $0x11,%rdx
    7179:	48 31 ca             	xor    %rcx,%rdx
    717c:	48 89 d0             	mov    %rdx,%rax
    717f:	48 c1 e8 09          	shr    $0x9,%rax
    7183:	48 31 c2             	xor    %rax,%rdx
    7186:	0f b6 d2             	movzbl %dl,%edx
    7189:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7190:	00 
    7191:	48 85 c0             	test   %rax,%rax
    7194:	75 13                	jne    71a9 <fwp_free_zombie+0x1b9>
    7196:	eb 4c                	jmp    71e4 <fwp_free_zombie+0x1f4>
    7198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    719f:	00 
    71a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    71a4:	48 85 c0             	test   %rax,%rax
    71a7:	74 3b                	je     71e4 <fwp_free_zombie+0x1f4>
    71a9:	48 89 c2             	mov    %rax,%rdx
    71ac:	48 39 08             	cmp    %rcx,(%rax)
    71af:	75 ef                	jne    71a0 <fwp_free_zombie+0x1b0>
    71b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    71b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    71bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    71c4:	0f 85 c3 fe ff ff    	jne    708d <fwp_free_zombie+0x9d>
    71ca:	48 89 cf             	mov    %rcx,%rdi
    71cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    71d2:	e8 79 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    71d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    71dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    71df:	e9 a9 fe ff ff       	jmp    708d <fwp_free_zombie+0x9d>
    71e4:	48 8d 3d 9d 56 00 00 	lea    0x569d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    71eb:	e8 00 d2 ff ff       	call   43f0 <fwp_trap>

00000000000071f0 <fwp_block>:
    71f0:	48 83 ec 08          	sub    $0x8,%rsp
    71f4:	48 8b 05 8d 95 01 00 	mov    0x1958d(%rip),%rax        # 20788 <fwp_ready_head>
    71fb:	48 85 c0             	test   %rax,%rax
    71fe:	0f 84 1c 01 00 00    	je     7320 <fwp_block+0x130>
    7204:	90                   	nop
    7205:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    720c:	00 00 00 00 
    7210:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7217:	48 89 15 6a 95 01 00 	mov    %rdx,0x1956a(%rip)        # 20788 <fwp_ready_head>
    721e:	48 85 d2             	test   %rdx,%rdx
    7221:	0f 84 19 01 00 00    	je     7340 <fwp_block+0x150>
    7227:	48 8b 15 72 95 01 00 	mov    0x19572(%rip),%rdx        # 207a0 <fwp_cur>
    722e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7232:	48 39 c2             	cmp    %rax,%rdx
    7235:	0f 84 d5 00 00 00    	je     7310 <fwp_block+0x120>
    723b:	48 8b 0d e6 b1 01 00 	mov    0x1b1e6(%rip),%rcx        # 22428 <fwp_state_owners>
    7242:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7246:	48 89 05 53 95 01 00 	mov    %rax,0x19553(%rip)        # 207a0 <fwp_cur>
    724d:	f3 0f 7e 05 fb b1 01 	movq   0x1b1fb(%rip),%xmm0        # 22450 <fwp_foreign_callbacks>
    7254:	00 
    7255:	0f 16 05 e4 b1 01 00 	movhps 0x1b1e4(%rip),%xmm0        # 22440 <fwp_state>
    725c:	f3 0f 7e 0d e4 b1 01 	movq   0x1b1e4(%rip),%xmm1        # 22448 <fwp_handlers>
    7263:	00 
    7264:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    726b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7272:	0f 16 0d df b1 01 00 	movhps 0x1b1df(%rip),%xmm1        # 22458 <fwp_cleanups>
    7279:	f3 0f 7e 05 b7 b1 01 	movq   0x1b1b7(%rip),%xmm0        # 22438 <fwp_state_len>
    7280:	00 
    7281:	0f 16 05 a8 b1 01 00 	movhps 0x1b1a8(%rip),%xmm0        # 22430 <fwp_state_cap>
    7288:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    728f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7296:	48 8b 70 08          	mov    0x8(%rax),%rsi
    729a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    72a1:	48 89 0d a0 b1 01 00 	mov    %rcx,0x1b1a0(%rip)        # 22448 <fwp_handlers>
    72a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    72af:	48 89 0d a2 b1 01 00 	mov    %rcx,0x1b1a2(%rip)        # 22458 <fwp_cleanups>
    72b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    72bd:	48 89 0d 8c b1 01 00 	mov    %rcx,0x1b18c(%rip)        # 22450 <fwp_foreign_callbacks>
    72c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    72cb:	48 89 0d 6e b1 01 00 	mov    %rcx,0x1b16e(%rip)        # 22440 <fwp_state>
    72d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    72d9:	48 89 0d 58 b1 01 00 	mov    %rcx,0x1b158(%rip)        # 22438 <fwp_state_len>
    72e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    72e7:	48 89 0d 42 b1 01 00 	mov    %rcx,0x1b142(%rip)        # 22430 <fwp_state_cap>
    72ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    72f5:	48 89 0d 2c b1 01 00 	mov    %rcx,0x1b12c(%rip)        # 22428 <fwp_state_owners>
    72fc:	e8 8f c1 ff ff       	call   3490 <swapcontext@plt>
    7301:	f3 0f 1e fa          	endbr64
    7305:	e8 e6 fc ff ff       	call   6ff0 <fwp_free_zombie>
    730a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7310:	8b 05 4a 8e 01 00    	mov    0x18e4a(%rip),%eax        # 20160 <fwp_slice>
    7316:	85 c0                	test   %eax,%eax
    7318:	74 36                	je     7350 <fwp_block+0x160>
    731a:	48 83 c4 08          	add    $0x8,%rsp
    731e:	c3                   	ret
    731f:	90                   	nop
    7320:	e8 7b de ff ff       	call   51a0 <fwp_poll_events>
    7325:	48 8b 05 5c 94 01 00 	mov    0x1945c(%rip),%rax        # 20788 <fwp_ready_head>
    732c:	48 85 c0             	test   %rax,%rax
    732f:	0f 85 db fe ff ff    	jne    7210 <fwp_block+0x20>
    7335:	eb e9                	jmp    7320 <fwp_block+0x130>
    7337:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    733e:	00 00 
    7340:	48 c7 05 35 94 01 00 	movq   $0x0,0x19435(%rip)        # 20780 <fwp_ready_tail>
    7347:	00 00 00 00 
    734b:	e9 d7 fe ff ff       	jmp    7227 <fwp_block+0x37>
    7350:	48 8d 3d 2d 4e 00 00 	lea    0x4e2d(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    7357:	e8 44 c0 ff ff       	call   33a0 <getenv@plt>
    735c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7361:	48 85 c0             	test   %rax,%rax
    7364:	74 05                	je     736b <fwp_block+0x17b>
    7366:	80 38 00             	cmpb   $0x0,(%rax)
    7369:	75 0b                	jne    7376 <fwp_block+0x186>
    736b:	89 15 ef 8d 01 00    	mov    %edx,0x18def(%rip)        # 20160 <fwp_slice>
    7371:	48 83 c4 08          	add    $0x8,%rsp
    7375:	c3                   	ret
    7376:	ba 0a 00 00 00       	mov    $0xa,%edx
    737b:	31 f6                	xor    %esi,%esi
    737d:	48 89 c7             	mov    %rax,%rdi
    7380:	e8 cb c1 ff ff       	call   3550 <strtoll@plt>
    7385:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7389:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7390:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7395:	0f 46 d0             	cmovbe %eax,%edx
    7398:	eb d1                	jmp    736b <fwp_block+0x17b>
    739a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000073a0 <fwp_owned_entry161>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	41 56                	push   %r14
    73a6:	55                   	push   %rbp
    73a7:	53                   	push   %rbx
    73a8:	48 83 ec 10          	sub    $0x10,%rsp
    73ac:	48 8b 07             	mov    (%rdi),%rax
    73af:	48 03 47 10          	add    0x10(%rdi),%rax
    73b3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    73b8:	0f 80 b7 01 00 00    	jo     7575 <fwp_owned_entry161+0x1d5>
    73be:	49 89 c6             	mov    %rax,%r14
    73c1:	8b 05 9d a7 01 00    	mov    0x1a79d(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    73c7:	48 8d 15 f2 93 01 00 	lea    0x193f2(%rip),%rdx        # 207c0 <fwp_heap>
    73ce:	85 c0                	test   %eax,%eax
    73d0:	0f 84 52 01 00 00    	je     7528 <fwp_owned_entry161+0x188>
    73d6:	0f b6 05 85 a3 01 00 	movzbl 0x1a385(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    73dd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    73e4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    73e8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    73ec:	48 8b 18             	mov    (%rax),%rbx
    73ef:	48 85 db             	test   %rbx,%rbx
    73f2:	0f 84 08 01 00 00    	je     7500 <fwp_owned_entry161+0x160>
    73f8:	48 8b 13             	mov    (%rbx),%rdx
    73fb:	48 f7 d2             	not    %rdx
    73fe:	48 89 10             	mov    %rdx,(%rax)
    7401:	48 83 fd 18          	cmp    $0x18,%rbp
    7405:	76 27                	jbe    742e <fwp_owned_entry161+0x8e>
    7407:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    740b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    740f:	31 f6                	xor    %esi,%esi
    7411:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7417:	48 c1 e8 03          	shr    $0x3,%rax
    741b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7422:	00 
    7423:	e8 98 c0 ff ff       	call   34c0 <memset@plt>
    7428:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    742e:	48 89 e8             	mov    %rbp,%rax
    7431:	48 03 05 a8 a7 01 00 	add    0x1a7a8(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    7438:	0f 82 3c 01 00 00    	jb     757a <fwp_owned_entry161+0x1da>
    743e:	48 39 05 a3 a7 01 00 	cmp    %rax,0x1a7a3(%rip)        # 21be8 <fwp_heap+0x1428>
    7445:	48 89 05 94 a7 01 00 	mov    %rax,0x1a794(%rip)        # 21be0 <fwp_heap+0x1420>
    744c:	73 07                	jae    7455 <fwp_owned_entry161+0xb5>
    744e:	48 89 05 93 a7 01 00 	mov    %rax,0x1a793(%rip)        # 21be8 <fwp_heap+0x1428>
    7455:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7459:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    745e:	f2 0f 58 0d 92 a7 01 	addsd  0x1a792(%rip),%xmm1        # 21bf8 <fwp_heap+0x1438>
    7465:	00 
    7466:	f2 0f 11 0d 8a a7 01 	movsd  %xmm1,0x1a78a(%rip)        # 21bf8 <fwp_heap+0x1438>
    746d:	00 
    746e:	48 8b 05 bb 57 00 00 	mov    0x57bb(%rip),%rax        # cc30 <msg.4+0xc0>
    7475:	66 49 0f 6e d6       	movq   %r14,%xmm2
    747a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    747e:	48 89 03             	mov    %rax,(%rbx)
    7481:	48 89 d8             	mov    %rbx,%rax
    7484:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7488:	48 8b 15 09 a7 01 00 	mov    0x1a709(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    748f:	48 2b 05 da a6 01 00 	sub    0x1a6da(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7496:	48 c1 e2 10          	shl    $0x10,%rdx
    749a:	48 39 d0             	cmp    %rdx,%rax
    749d:	73 53                	jae    74f2 <fwp_owned_entry161+0x152>
    749f:	48 89 c2             	mov    %rax,%rdx
    74a2:	48 c1 ea 10          	shr    $0x10,%rdx
    74a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74aa:	48 8b 15 07 a7 01 00 	mov    0x1a707(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    74b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74b5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    74b9:	48 85 ed             	test   %rbp,%rbp
    74bc:	74 34                	je     74f2 <fwp_owned_entry161+0x152>
    74be:	0f b6 0a             	movzbl (%rdx),%ecx
    74c1:	80 f9 02             	cmp    $0x2,%cl
    74c4:	0f 84 86 00 00 00    	je     7550 <fwp_owned_entry161+0x1b0>
    74ca:	80 f9 01             	cmp    $0x1,%cl
    74cd:	75 23                	jne    74f2 <fwp_owned_entry161+0x152>
    74cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74d2:	0f b7 c0             	movzwl %ax,%eax
    74d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74d8:	48 0f af c1          	imul   %rcx,%rax
    74dc:	48 c1 e8 20          	shr    $0x20,%rax
    74e0:	48 39 d0             	cmp    %rdx,%rax
    74e3:	73 0d                	jae    74f2 <fwp_owned_entry161+0x152>
    74e5:	48 01 c5             	add    %rax,%rbp
    74e8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    74ec:	74 7a                	je     7568 <fwp_owned_entry161+0x1c8>
    74ee:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    74f2:	48 83 c4 10          	add    $0x10,%rsp
    74f6:	48 89 d8             	mov    %rbx,%rax
    74f9:	5b                   	pop    %rbx
    74fa:	5d                   	pop    %rbp
    74fb:	41 5e                	pop    %r14
    74fd:	c3                   	ret
    74fe:	66 90                	xchg   %ax,%ax
    7500:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7504:	48 85 db             	test   %rbx,%rbx
    7507:	74 1f                	je     7528 <fwp_owned_entry161+0x188>
    7509:	48 8b 50 10          	mov    0x10(%rax),%rdx
    750d:	48 29 da             	sub    %rbx,%rdx
    7510:	48 39 ea             	cmp    %rbp,%rdx
    7513:	72 13                	jb     7528 <fwp_owned_entry161+0x188>
    7515:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7519:	48 89 50 08          	mov    %rdx,0x8(%rax)
    751d:	e9 df fe ff ff       	jmp    7401 <fwp_owned_entry161+0x61>
    7522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7528:	31 f6                	xor    %esi,%esi
    752a:	bf 18 00 00 00       	mov    $0x18,%edi
    752f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7535:	e8 56 e7 ff ff       	call   5c90 <fwp_heap_alloc>
    753a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7540:	48 89 c3             	mov    %rax,%rbx
    7543:	e9 26 ff ff ff       	jmp    746e <fwp_owned_entry161+0xce>
    7548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    754f:	00 
    7550:	66 85 c0             	test   %ax,%ax
    7553:	74 93                	je     74e8 <fwp_owned_entry161+0x148>
    7555:	48 83 c4 10          	add    $0x10,%rsp
    7559:	48 89 d8             	mov    %rbx,%rax
    755c:	5b                   	pop    %rbx
    755d:	5d                   	pop    %rbp
    755e:	41 5e                	pop    %r14
    7560:	c3                   	ret
    7561:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7568:	48 89 ef             	mov    %rbp,%rdi
    756b:	e8 e0 df ff ff       	call   5550 <fwp_rc_forget_slot>
    7570:	e9 79 ff ff ff       	jmp    74ee <fwp_owned_entry161+0x14e>
    7575:	e8 86 c1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    757a:	e8 31 c7 ff ff       	call   3cb0 <fwp_heap_oom>
    757f:	90                   	nop

0000000000007580 <e161>:
    7580:	f3 0f 1e fa          	endbr64
    7584:	41 56                	push   %r14
    7586:	55                   	push   %rbp
    7587:	53                   	push   %rbx
    7588:	48 83 ec 10          	sub    $0x10,%rsp
    758c:	48 8b 07             	mov    (%rdi),%rax
    758f:	48 03 47 10          	add    0x10(%rdi),%rax
    7593:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7598:	0f 80 bf 01 00 00    	jo     775d <e161+0x1dd>
    759e:	49 89 c6             	mov    %rax,%r14
    75a1:	8b 05 bd a5 01 00    	mov    0x1a5bd(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    75a7:	48 8d 15 12 92 01 00 	lea    0x19212(%rip),%rdx        # 207c0 <fwp_heap>
    75ae:	85 c0                	test   %eax,%eax
    75b0:	0f 84 62 01 00 00    	je     7718 <e161+0x198>
    75b6:	0f b6 05 a5 a1 01 00 	movzbl 0x1a1a5(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    75bd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    75c4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    75c8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    75cc:	48 8b 18             	mov    (%rax),%rbx
    75cf:	48 85 db             	test   %rbx,%rbx
    75d2:	0f 84 18 01 00 00    	je     76f0 <e161+0x170>
    75d8:	48 8b 13             	mov    (%rbx),%rdx
    75db:	48 f7 d2             	not    %rdx
    75de:	48 89 10             	mov    %rdx,(%rax)
    75e1:	48 83 fd 18          	cmp    $0x18,%rbp
    75e5:	76 27                	jbe    760e <e161+0x8e>
    75e7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    75eb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    75ef:	31 f6                	xor    %esi,%esi
    75f1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    75f7:	48 c1 e8 03          	shr    $0x3,%rax
    75fb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7602:	00 
    7603:	e8 b8 be ff ff       	call   34c0 <memset@plt>
    7608:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    760e:	48 89 e8             	mov    %rbp,%rax
    7611:	48 03 05 c8 a5 01 00 	add    0x1a5c8(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    7618:	0f 82 44 01 00 00    	jb     7762 <e161+0x1e2>
    761e:	48 39 05 c3 a5 01 00 	cmp    %rax,0x1a5c3(%rip)        # 21be8 <fwp_heap+0x1428>
    7625:	48 89 05 b4 a5 01 00 	mov    %rax,0x1a5b4(%rip)        # 21be0 <fwp_heap+0x1420>
    762c:	73 07                	jae    7635 <e161+0xb5>
    762e:	48 89 05 b3 a5 01 00 	mov    %rax,0x1a5b3(%rip)        # 21be8 <fwp_heap+0x1428>
    7635:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7639:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    763e:	f2 0f 58 0d b2 a5 01 	addsd  0x1a5b2(%rip),%xmm1        # 21bf8 <fwp_heap+0x1438>
    7645:	00 
    7646:	f2 0f 11 0d aa a5 01 	movsd  %xmm1,0x1a5aa(%rip)        # 21bf8 <fwp_heap+0x1438>
    764d:	00 
    764e:	48 8b 05 db 55 00 00 	mov    0x55db(%rip),%rax        # cc30 <msg.4+0xc0>
    7655:	66 49 0f 6e d6       	movq   %r14,%xmm2
    765a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    765e:	48 89 03             	mov    %rax,(%rbx)
    7661:	48 89 d8             	mov    %rbx,%rax
    7664:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7668:	48 8b 15 29 a5 01 00 	mov    0x1a529(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    766f:	48 2b 05 fa a4 01 00 	sub    0x1a4fa(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7676:	48 c1 e2 10          	shl    $0x10,%rdx
    767a:	48 39 d0             	cmp    %rdx,%rax
    767d:	73 57                	jae    76d6 <e161+0x156>
    767f:	48 89 c2             	mov    %rax,%rdx
    7682:	48 c1 ea 10          	shr    $0x10,%rdx
    7686:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    768a:	48 8b 15 27 a5 01 00 	mov    0x1a527(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7691:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7695:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7699:	48 85 ed             	test   %rbp,%rbp
    769c:	74 38                	je     76d6 <e161+0x156>
    769e:	0f b6 0a             	movzbl (%rdx),%ecx
    76a1:	80 f9 02             	cmp    $0x2,%cl
    76a4:	0f 84 96 00 00 00    	je     7740 <e161+0x1c0>
    76aa:	80 f9 01             	cmp    $0x1,%cl
    76ad:	75 27                	jne    76d6 <e161+0x156>
    76af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    76b2:	0f b7 c0             	movzwl %ax,%eax
    76b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76b8:	48 0f af c1          	imul   %rcx,%rax
    76bc:	48 c1 e8 20          	shr    $0x20,%rax
    76c0:	48 39 d0             	cmp    %rdx,%rax
    76c3:	73 11                	jae    76d6 <e161+0x156>
    76c5:	48 01 c5             	add    %rax,%rbp
    76c8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    76cc:	0f 84 7e 00 00 00    	je     7750 <e161+0x1d0>
    76d2:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    76d6:	48 89 df             	mov    %rbx,%rdi
    76d9:	e8 32 ef ff ff       	call   6610 <fwp_rc_share>
    76de:	48 83 c4 10          	add    $0x10,%rsp
    76e2:	48 89 d8             	mov    %rbx,%rax
    76e5:	5b                   	pop    %rbx
    76e6:	5d                   	pop    %rbp
    76e7:	41 5e                	pop    %r14
    76e9:	c3                   	ret
    76ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    76f4:	48 85 db             	test   %rbx,%rbx
    76f7:	74 1f                	je     7718 <e161+0x198>
    76f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    76fd:	48 29 da             	sub    %rbx,%rdx
    7700:	48 39 ea             	cmp    %rbp,%rdx
    7703:	72 13                	jb     7718 <e161+0x198>
    7705:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7709:	48 89 50 08          	mov    %rdx,0x8(%rax)
    770d:	e9 cf fe ff ff       	jmp    75e1 <e161+0x61>
    7712:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7718:	31 f6                	xor    %esi,%esi
    771a:	bf 18 00 00 00       	mov    $0x18,%edi
    771f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7725:	e8 66 e5 ff ff       	call   5c90 <fwp_heap_alloc>
    772a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7730:	48 89 c3             	mov    %rax,%rbx
    7733:	e9 16 ff ff ff       	jmp    764e <e161+0xce>
    7738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    773f:	00 
    7740:	66 85 c0             	test   %ax,%ax
    7743:	75 91                	jne    76d6 <e161+0x156>
    7745:	eb 81                	jmp    76c8 <e161+0x148>
    7747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    774e:	00 00 
    7750:	48 89 ef             	mov    %rbp,%rdi
    7753:	e8 f8 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    7758:	e9 75 ff ff ff       	jmp    76d2 <e161+0x152>
    775d:	e8 9e bf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7762:	e8 49 c5 ff ff       	call   3cb0 <fwp_heap_oom>
    7767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    776e:	00 00 

0000000000007770 <fwp_drop4>:
    7770:	48 8b 15 21 a4 01 00 	mov    0x1a421(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7777:	48 89 f8             	mov    %rdi,%rax
    777a:	48 2b 05 ef a3 01 00 	sub    0x1a3ef(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7781:	48 c1 e2 10          	shl    $0x10,%rdx
    7785:	48 39 d0             	cmp    %rdx,%rax
    7788:	0f 83 52 01 00 00    	jae    78e0 <fwp_drop4+0x170>
    778e:	48 83 ec 18          	sub    $0x18,%rsp
    7792:	4c 8d 05 27 90 01 00 	lea    0x19027(%rip),%r8        # 207c0 <fwp_heap>
    7799:	48 89 c2             	mov    %rax,%rdx
    779c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    77a3:	48 c1 ea 10          	shr    $0x10,%rdx
    77a7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    77ab:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    77af:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    77b3:	48 85 d2             	test   %rdx,%rdx
    77b6:	74 46                	je     77fe <fwp_drop4+0x8e>
    77b8:	44 0f b6 09          	movzbl (%rcx),%r9d
    77bc:	41 80 f9 02          	cmp    $0x2,%r9b
    77c0:	0f 84 ca 00 00 00    	je     7890 <fwp_drop4+0x120>
    77c6:	41 80 f9 01          	cmp    $0x1,%r9b
    77ca:	75 32                	jne    77fe <fwp_drop4+0x8e>
    77cc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    77d0:	0f b7 c0             	movzwl %ax,%eax
    77d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77d6:	49 0f af c1          	imul   %r9,%rax
    77da:	48 c1 e8 20          	shr    $0x20,%rax
    77de:	48 39 c8             	cmp    %rcx,%rax
    77e1:	73 1b                	jae    77fe <fwp_drop4+0x8e>
    77e3:	48 01 c2             	add    %rax,%rdx
    77e6:	0f b6 02             	movzbl (%rdx),%eax
    77e9:	84 c0                	test   %al,%al
    77eb:	74 11                	je     77fe <fwp_drop4+0x8e>
    77ed:	3c 01                	cmp    $0x1,%al
    77ef:	74 17                	je     7808 <fwp_drop4+0x98>
    77f1:	3c ff                	cmp    $0xff,%al
    77f3:	0f 84 ef 00 00 00    	je     78e8 <fwp_drop4+0x178>
    77f9:	83 e8 01             	sub    $0x1,%eax
    77fc:	88 02                	mov    %al,(%rdx)
    77fe:	48 83 c4 18          	add    $0x18,%rsp
    7802:	c3                   	ret
    7803:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7808:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    780c:	0f 88 8e 00 00 00    	js     78a0 <fwp_drop4+0x130>
    7812:	48 8b 15 7f a3 01 00 	mov    0x1a37f(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7819:	48 89 f8             	mov    %rdi,%rax
    781c:	48 2b 05 4d a3 01 00 	sub    0x1a34d(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7823:	48 c1 e2 10          	shl    $0x10,%rdx
    7827:	48 39 d0             	cmp    %rdx,%rax
    782a:	73 d2                	jae    77fe <fwp_drop4+0x8e>
    782c:	48 89 c2             	mov    %rax,%rdx
    782f:	48 c1 ea 10          	shr    $0x10,%rdx
    7833:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7837:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    783b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    783f:	48 85 c9             	test   %rcx,%rcx
    7842:	74 ba                	je     77fe <fwp_drop4+0x8e>
    7844:	0f b6 32             	movzbl (%rdx),%esi
    7847:	40 80 fe 02          	cmp    $0x2,%sil
    784b:	74 33                	je     7880 <fwp_drop4+0x110>
    784d:	40 80 fe 01          	cmp    $0x1,%sil
    7851:	75 ab                	jne    77fe <fwp_drop4+0x8e>
    7853:	8b 72 18             	mov    0x18(%rdx),%esi
    7856:	0f b7 c0             	movzwl %ax,%eax
    7859:	8b 52 1c             	mov    0x1c(%rdx),%edx
    785c:	48 0f af c6          	imul   %rsi,%rax
    7860:	48 c1 e8 20          	shr    $0x20,%rax
    7864:	48 39 d0             	cmp    %rdx,%rax
    7867:	73 95                	jae    77fe <fwp_drop4+0x8e>
    7869:	48 01 c1             	add    %rax,%rcx
    786c:	80 39 01             	cmpb   $0x1,(%rcx)
    786f:	75 8d                	jne    77fe <fwp_drop4+0x8e>
    7871:	48 83 c4 18          	add    $0x18,%rsp
    7875:	e9 16 df ff ff       	jmp    5790 <fwp_mem_free>
    787a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7880:	66 85 c0             	test   %ax,%ax
    7883:	74 e7                	je     786c <fwp_drop4+0xfc>
    7885:	48 83 c4 18          	add    $0x18,%rsp
    7889:	c3                   	ret
    788a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7890:	66 85 c0             	test   %ax,%ax
    7893:	0f 84 4d ff ff ff    	je     77e6 <fwp_drop4+0x76>
    7899:	48 83 c4 18          	add    $0x18,%rsp
    789d:	c3                   	ret
    789e:	66 90                	xchg   %ax,%ax
    78a0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    78a4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78a9:	e8 e2 ed ff ff       	call   6690 <fwp_rc_free_arr>
    78ae:	4c 8d 05 0b 8f 01 00 	lea    0x18f0b(%rip),%r8        # 207c0 <fwp_heap>
    78b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78ba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    78c1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    78c8:	48 c1 e2 10          	shl    $0x10,%rdx
    78cc:	48 39 d0             	cmp    %rdx,%rax
    78cf:	0f 83 29 ff ff ff    	jae    77fe <fwp_drop4+0x8e>
    78d5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    78da:	e9 ba fe ff ff       	jmp    7799 <fwp_drop4+0x29>
    78df:	90                   	nop
    78e0:	c3                   	ret
    78e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78e8:	48 89 d0             	mov    %rdx,%rax
    78eb:	48 c1 e8 11          	shr    $0x11,%rax
    78ef:	48 31 d0             	xor    %rdx,%rax
    78f2:	48 89 c1             	mov    %rax,%rcx
    78f5:	48 c1 e9 09          	shr    $0x9,%rcx
    78f9:	48 31 c8             	xor    %rcx,%rax
    78fc:	0f b6 c8             	movzbl %al,%ecx
    78ff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7906:	00 
    7907:	48 85 c0             	test   %rax,%rax
    790a:	75 1d                	jne    7929 <fwp_drop4+0x1b9>
    790c:	eb 56                	jmp    7964 <fwp_drop4+0x1f4>
    790e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    791c:	00 00 00 00 
    7920:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7924:	48 85 c0             	test   %rax,%rax
    7927:	74 3b                	je     7964 <fwp_drop4+0x1f4>
    7929:	48 89 c1             	mov    %rax,%rcx
    792c:	48 39 10             	cmp    %rdx,(%rax)
    792f:	75 ef                	jne    7920 <fwp_drop4+0x1b0>
    7931:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7935:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7939:	48 89 48 08          	mov    %rcx,0x8(%rax)
    793d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7944:	0f 85 b4 fe ff ff    	jne    77fe <fwp_drop4+0x8e>
    794a:	48 89 d7             	mov    %rdx,%rdi
    794d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7952:	e8 f9 db ff ff       	call   5550 <fwp_rc_forget_slot>
    7957:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    795c:	c6 02 fe             	movb   $0xfe,(%rdx)
    795f:	e9 9a fe ff ff       	jmp    77fe <fwp_drop4+0x8e>
    7964:	48 8d 3d 1d 4f 00 00 	lea    0x4f1d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    796b:	e8 80 ca ff ff       	call   43f0 <fwp_trap>

0000000000007970 <fwp_caps161>:
    7970:	f3 0f 1e fa          	endbr64
    7974:	85 f6                	test   %esi,%esi
    7976:	74 08                	je     7980 <fwp_caps161+0x10>
    7978:	c3                   	ret
    7979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7980:	48 8b 15 11 a2 01 00 	mov    0x1a211(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7987:	48 89 f8             	mov    %rdi,%rax
    798a:	48 2b 05 df a1 01 00 	sub    0x1a1df(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7991:	48 c1 e2 10          	shl    $0x10,%rdx
    7995:	48 39 d0             	cmp    %rdx,%rax
    7998:	73 de                	jae    7978 <fwp_caps161+0x8>
    799a:	48 89 c2             	mov    %rax,%rdx
    799d:	48 c1 ea 10          	shr    $0x10,%rdx
    79a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79a5:	48 8b 15 0c a2 01 00 	mov    0x1a20c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    79ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    79b4:	48 85 c9             	test   %rcx,%rcx
    79b7:	74 bf                	je     7978 <fwp_caps161+0x8>
    79b9:	0f b6 32             	movzbl (%rdx),%esi
    79bc:	40 80 fe 02          	cmp    $0x2,%sil
    79c0:	74 2e                	je     79f0 <fwp_caps161+0x80>
    79c2:	40 80 fe 01          	cmp    $0x1,%sil
    79c6:	75 b0                	jne    7978 <fwp_caps161+0x8>
    79c8:	8b 72 18             	mov    0x18(%rdx),%esi
    79cb:	0f b7 c0             	movzwl %ax,%eax
    79ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79d1:	48 0f af c6          	imul   %rsi,%rax
    79d5:	48 c1 e8 20          	shr    $0x20,%rax
    79d9:	48 39 d0             	cmp    %rdx,%rax
    79dc:	73 9a                	jae    7978 <fwp_caps161+0x8>
    79de:	48 01 c1             	add    %rax,%rcx
    79e1:	80 39 01             	cmpb   $0x1,(%rcx)
    79e4:	75 92                	jne    7978 <fwp_caps161+0x8>
    79e6:	e9 a5 dd ff ff       	jmp    5790 <fwp_mem_free>
    79eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79f0:	66 85 c0             	test   %ax,%ax
    79f3:	74 ec                	je     79e1 <fwp_caps161+0x71>
    79f5:	c3                   	ret
    79f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79fd:	00 00 00 

0000000000007a00 <fwp_args12>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	85 d2                	test   %edx,%edx
    7a06:	74 04                	je     7a0c <fwp_args12+0xc>
    7a08:	85 f6                	test   %esi,%esi
    7a0a:	74 04                	je     7a10 <fwp_args12+0x10>
    7a0c:	c3                   	ret
    7a0d:	0f 1f 00             	nopl   (%rax)
    7a10:	48 8b 15 81 a1 01 00 	mov    0x1a181(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7a17:	48 8b 07             	mov    (%rdi),%rax
    7a1a:	48 2b 05 4f a1 01 00 	sub    0x1a14f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7a21:	48 c1 e2 10          	shl    $0x10,%rdx
    7a25:	48 39 d0             	cmp    %rdx,%rax
    7a28:	73 e2                	jae    7a0c <fwp_args12+0xc>
    7a2a:	48 89 c2             	mov    %rax,%rdx
    7a2d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a35:	48 8b 15 7c a1 01 00 	mov    0x1a17c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7a3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a40:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a44:	48 85 ff             	test   %rdi,%rdi
    7a47:	74 c3                	je     7a0c <fwp_args12+0xc>
    7a49:	0f b6 0a             	movzbl (%rdx),%ecx
    7a4c:	80 f9 02             	cmp    $0x2,%cl
    7a4f:	74 2f                	je     7a80 <fwp_args12+0x80>
    7a51:	80 f9 01             	cmp    $0x1,%cl
    7a54:	75 b6                	jne    7a0c <fwp_args12+0xc>
    7a56:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a59:	0f b7 c0             	movzwl %ax,%eax
    7a5c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a5f:	48 0f af c1          	imul   %rcx,%rax
    7a63:	48 c1 e8 20          	shr    $0x20,%rax
    7a67:	48 39 d0             	cmp    %rdx,%rax
    7a6a:	73 a0                	jae    7a0c <fwp_args12+0xc>
    7a6c:	48 01 c7             	add    %rax,%rdi
    7a6f:	0f b6 07             	movzbl (%rdi),%eax
    7a72:	84 c0                	test   %al,%al
    7a74:	74 96                	je     7a0c <fwp_args12+0xc>
    7a76:	3c fd                	cmp    $0xfd,%al
    7a78:	77 0c                	ja     7a86 <fwp_args12+0x86>
    7a7a:	83 c0 01             	add    $0x1,%eax
    7a7d:	88 07                	mov    %al,(%rdi)
    7a7f:	c3                   	ret
    7a80:	66 85 c0             	test   %ax,%ax
    7a83:	74 ea                	je     7a6f <fwp_args12+0x6f>
    7a85:	c3                   	ret
    7a86:	e9 a5 d9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a90 <fwp_args23>:
    7a90:	f3 0f 1e fa          	endbr64
    7a94:	85 d2                	test   %edx,%edx
    7a96:	74 04                	je     7a9c <fwp_args23+0xc>
    7a98:	85 f6                	test   %esi,%esi
    7a9a:	74 04                	je     7aa0 <fwp_args23+0x10>
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 15 f1 a0 01 00 	mov    0x1a0f1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7aa7:	48 8b 07             	mov    (%rdi),%rax
    7aaa:	48 2b 05 bf a0 01 00 	sub    0x1a0bf(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7ab1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	73 e2                	jae    7a9c <fwp_args23+0xc>
    7aba:	48 89 c2             	mov    %rax,%rdx
    7abd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ac5:	48 8b 15 ec a0 01 00 	mov    0x1a0ec(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7acc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ad0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ad4:	48 85 ff             	test   %rdi,%rdi
    7ad7:	74 c3                	je     7a9c <fwp_args23+0xc>
    7ad9:	0f b6 0a             	movzbl (%rdx),%ecx
    7adc:	80 f9 02             	cmp    $0x2,%cl
    7adf:	74 2f                	je     7b10 <fwp_args23+0x80>
    7ae1:	80 f9 01             	cmp    $0x1,%cl
    7ae4:	75 b6                	jne    7a9c <fwp_args23+0xc>
    7ae6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae9:	0f b7 c0             	movzwl %ax,%eax
    7aec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aef:	48 0f af c1          	imul   %rcx,%rax
    7af3:	48 c1 e8 20          	shr    $0x20,%rax
    7af7:	48 39 d0             	cmp    %rdx,%rax
    7afa:	73 a0                	jae    7a9c <fwp_args23+0xc>
    7afc:	48 01 c7             	add    %rax,%rdi
    7aff:	0f b6 07             	movzbl (%rdi),%eax
    7b02:	84 c0                	test   %al,%al
    7b04:	74 96                	je     7a9c <fwp_args23+0xc>
    7b06:	3c fd                	cmp    $0xfd,%al
    7b08:	77 0c                	ja     7b16 <fwp_args23+0x86>
    7b0a:	83 c0 01             	add    $0x1,%eax
    7b0d:	88 07                	mov    %al,(%rdi)
    7b0f:	c3                   	ret
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 ea                	je     7aff <fwp_args23+0x6f>
    7b15:	c3                   	ret
    7b16:	e9 15 d9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b20 <fwp_caps12>:
    7b20:	f3 0f 1e fa          	endbr64
    7b24:	48 83 ec 18          	sub    $0x18,%rsp
    7b28:	8b 57 04             	mov    0x4(%rdi),%edx
    7b2b:	48 89 f8             	mov    %rdi,%rax
    7b2e:	85 d2                	test   %edx,%edx
    7b30:	0f 84 9a 00 00 00    	je     7bd0 <fwp_caps12+0xb0>
    7b36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7b3a:	85 f6                	test   %esi,%esi
    7b3c:	0f 85 9e 00 00 00    	jne    7be0 <fwp_caps12+0xc0>
    7b42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b47:	e8 54 ec ff ff       	call   67a0 <fwp_drop0>
    7b4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b51:	48 8b 0d 40 a0 01 00 	mov    0x1a040(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    7b58:	48 89 c2             	mov    %rax,%rdx
    7b5b:	48 2b 15 0e a0 01 00 	sub    0x1a00e(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    7b62:	48 c1 e1 10          	shl    $0x10,%rcx
    7b66:	48 39 ca             	cmp    %rcx,%rdx
    7b69:	73 6d                	jae    7bd8 <fwp_caps12+0xb8>
    7b6b:	48 89 d1             	mov    %rdx,%rcx
    7b6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b76:	48 8b 0d 3b a0 01 00 	mov    0x1a03b(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7b7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b85:	48 85 f6             	test   %rsi,%rsi
    7b88:	74 4e                	je     7bd8 <fwp_caps12+0xb8>
    7b8a:	0f b6 39             	movzbl (%rcx),%edi
    7b8d:	40 80 ff 02          	cmp    $0x2,%dil
    7b91:	0f 84 b9 00 00 00    	je     7c50 <fwp_caps12+0x130>
    7b97:	40 80 ff 01          	cmp    $0x1,%dil
    7b9b:	75 3b                	jne    7bd8 <fwp_caps12+0xb8>
    7b9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7ba0:	0f b7 d2             	movzwl %dx,%edx
    7ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ba6:	48 0f af d7          	imul   %rdi,%rdx
    7baa:	48 c1 ea 20          	shr    $0x20,%rdx
    7bae:	48 39 ca             	cmp    %rcx,%rdx
    7bb1:	73 25                	jae    7bd8 <fwp_caps12+0xb8>
    7bb3:	48 01 d6             	add    %rdx,%rsi
    7bb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bb9:	75 1d                	jne    7bd8 <fwp_caps12+0xb8>
    7bbb:	48 89 c7             	mov    %rax,%rdi
    7bbe:	48 83 c4 18          	add    $0x18,%rsp
    7bc2:	e9 c9 db ff ff       	jmp    5790 <fwp_mem_free>
    7bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bce:	00 00 
    7bd0:	85 f6                	test   %esi,%esi
    7bd2:	0f 84 79 ff ff ff    	je     7b51 <fwp_caps12+0x31>
    7bd8:	48 83 c4 18          	add    $0x18,%rsp
    7bdc:	c3                   	ret
    7bdd:	0f 1f 00             	nopl   (%rax)
    7be0:	48 8b 05 b1 9f 01 00 	mov    0x19fb1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    7be7:	48 2b 3d 82 9f 01 00 	sub    0x19f82(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    7bee:	48 c1 e0 10          	shl    $0x10,%rax
    7bf2:	48 39 c7             	cmp    %rax,%rdi
    7bf5:	73 e1                	jae    7bd8 <fwp_caps12+0xb8>
    7bf7:	48 89 f8             	mov    %rdi,%rax
    7bfa:	48 c1 e8 10          	shr    $0x10,%rax
    7bfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c02:	48 8b 05 af 9f 01 00 	mov    0x19faf(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    7c09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c11:	48 85 c0             	test   %rax,%rax
    7c14:	74 c2                	je     7bd8 <fwp_caps12+0xb8>
    7c16:	0f b6 0a             	movzbl (%rdx),%ecx
    7c19:	80 f9 02             	cmp    $0x2,%cl
    7c1c:	74 42                	je     7c60 <fwp_caps12+0x140>
    7c1e:	80 f9 01             	cmp    $0x1,%cl
    7c21:	75 b5                	jne    7bd8 <fwp_caps12+0xb8>
    7c23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c26:	0f b7 ff             	movzwl %di,%edi
    7c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c2c:	48 0f af f9          	imul   %rcx,%rdi
    7c30:	48 c1 ef 20          	shr    $0x20,%rdi
    7c34:	48 39 d7             	cmp    %rdx,%rdi
    7c37:	73 9f                	jae    7bd8 <fwp_caps12+0xb8>
    7c39:	48 01 f8             	add    %rdi,%rax
    7c3c:	0f b6 10             	movzbl (%rax),%edx
    7c3f:	84 d2                	test   %dl,%dl
    7c41:	74 95                	je     7bd8 <fwp_caps12+0xb8>
    7c43:	80 fa fd             	cmp    $0xfd,%dl
    7c46:	77 23                	ja     7c6b <fwp_caps12+0x14b>
    7c48:	83 c2 01             	add    $0x1,%edx
    7c4b:	88 10                	mov    %dl,(%rax)
    7c4d:	eb 89                	jmp    7bd8 <fwp_caps12+0xb8>
    7c4f:	90                   	nop
    7c50:	66 85 d2             	test   %dx,%dx
    7c53:	0f 85 7f ff ff ff    	jne    7bd8 <fwp_caps12+0xb8>
    7c59:	e9 58 ff ff ff       	jmp    7bb6 <fwp_caps12+0x96>
    7c5e:	66 90                	xchg   %ax,%ax
    7c60:	66 85 ff             	test   %di,%di
    7c63:	0f 85 6f ff ff ff    	jne    7bd8 <fwp_caps12+0xb8>
    7c69:	eb d1                	jmp    7c3c <fwp_caps12+0x11c>
    7c6b:	48 89 c7             	mov    %rax,%rdi
    7c6e:	48 83 c4 18          	add    $0x18,%rsp
    7c72:	e9 b9 d7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c7e:	00 00 

0000000000007c80 <f12>:
    7c80:	41 57                	push   %r15
    7c82:	41 56                	push   %r14
    7c84:	41 55                	push   %r13
    7c86:	41 54                	push   %r12
    7c88:	4c 8d 25 31 f1 ff ff 	lea    -0xecf(%rip),%r12        # 6dc0 <fwp_tape_scope_release>
    7c8f:	55                   	push   %rbp
    7c90:	53                   	push   %rbx
    7c91:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7c98:	48 8b 15 f9 9e 01 00 	mov    0x19ef9(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7c9f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7ca4:	48 c1 e2 10          	shl    $0x10,%rdx
    7ca8:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7caf:	00 00 
    7cb1:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7cb8:	00 
    7cb9:	31 c0                	xor    %eax,%eax
    7cbb:	48 8b 05 96 a7 01 00 	mov    0x1a796(%rip),%rax        # 22458 <fwp_cleanups>
    7cc2:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7cc9:	ff 
    7cca:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    7ccf:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7cd4:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7cd9:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7cde:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7ce3:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    7ce8:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    7ced:	48 89 05 64 a7 01 00 	mov    %rax,0x1a764(%rip)        # 22458 <fwp_cleanups>
    7cf4:	48 8d 05 15 83 00 00 	lea    0x8315(%rip),%rax        # 10010 <fc23>
    7cfb:	48 2b 05 6e 9e 01 00 	sub    0x19e6e(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7d02:	48 39 d0             	cmp    %rdx,%rax
    7d05:	73 5d                	jae    7d64 <f12+0xe4>
    7d07:	48 89 c2             	mov    %rax,%rdx
    7d0a:	48 c1 ea 10          	shr    $0x10,%rdx
    7d0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d12:	48 8b 15 9f 9e 01 00 	mov    0x19e9f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7d19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d1d:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d21:	48 85 ff             	test   %rdi,%rdi
    7d24:	74 3e                	je     7d64 <f12+0xe4>
    7d26:	0f b6 0a             	movzbl (%rdx),%ecx
    7d29:	80 f9 02             	cmp    $0x2,%cl
    7d2c:	0f 84 0e 12 00 00    	je     8f40 <f12+0x12c0>
    7d32:	80 f9 01             	cmp    $0x1,%cl
    7d35:	75 2d                	jne    7d64 <f12+0xe4>
    7d37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d3a:	0f b7 c0             	movzwl %ax,%eax
    7d3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d40:	48 0f af c1          	imul   %rcx,%rax
    7d44:	48 c1 e8 20          	shr    $0x20,%rax
    7d48:	48 39 d0             	cmp    %rdx,%rax
    7d4b:	73 17                	jae    7d64 <f12+0xe4>
    7d4d:	48 01 c7             	add    %rax,%rdi
    7d50:	0f b6 07             	movzbl (%rdi),%eax
    7d53:	84 c0                	test   %al,%al
    7d55:	74 0d                	je     7d64 <f12+0xe4>
    7d57:	3c fd                	cmp    $0xfd,%al
    7d59:	0f 87 35 14 00 00    	ja     9194 <f12+0x1514>
    7d5f:	83 c0 01             	add    $0x1,%eax
    7d62:	88 07                	mov    %al,(%rdi)
    7d64:	48 8d 3d a5 82 00 00 	lea    0x82a5(%rip),%rdi        # 10010 <fc23>
    7d6b:	e8 20 ed ff ff       	call   6a90 <fwp_closure_drop>
    7d70:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d75:	48 85 c0             	test   %rax,%rax
    7d78:	0f 84 87 13 00 00    	je     9105 <f12+0x1485>
    7d7e:	31 db                	xor    %ebx,%ebx
    7d80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d84:	48 83 c3 01          	add    $0x1,%rbx
    7d88:	48 85 c0             	test   %rax,%rax
    7d8b:	75 f3                	jne    7d80 <f12+0x100>
    7d8d:	31 ff                	xor    %edi,%edi
    7d8f:	e8 bc c4 ff ff       	call   4250 <descent_phase_step>
    7d94:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    7d9b:	0f 87 e6 14 00 00    	ja     9287 <f12+0x1607>
    7da1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    7da6:	44 8b 05 b3 82 00 00 	mov    0x82b3(%rip),%r8d        # 10060 <registered_finish.0>
    7dad:	45 85 c0             	test   %r8d,%r8d
    7db0:	0f 84 5a 11 00 00    	je     8f10 <f12+0x1290>
    7db6:	48 8b 15 1b 83 01 00 	mov    0x1831b(%rip),%rdx        # 200d8 <fwp_tape_next_slot>
    7dbd:	48 8b 1d 24 83 01 00 	mov    0x18324(%rip),%rbx        # 200e8 <fwp_ntapes>
    7dc4:	48 39 da             	cmp    %rbx,%rdx
    7dc7:	0f 8d 03 06 00 00    	jge    83d0 <f12+0x750>
    7dcd:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    7dd1:	48 03 05 18 83 01 00 	add    0x18318(%rip),%rax        # 200f0 <fwp_tapes>
    7dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7ddf:	00 
    7de0:	8b 78 04             	mov    0x4(%rax),%edi
    7de3:	85 ff                	test   %edi,%edi
    7de5:	75 0c                	jne    7df3 <f12+0x173>
    7de7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7ded:	0f 86 dd 05 00 00    	jbe    83d0 <f12+0x750>
    7df3:	48 83 c2 01          	add    $0x1,%rdx
    7df7:	48 83 c0 68          	add    $0x68,%rax
    7dfb:	48 39 da             	cmp    %rbx,%rdx
    7dfe:	75 e0                	jne    7de0 <f12+0x160>
    7e00:	48 81 fb fe ff 00 00 	cmp    $0xfffe,%rbx
    7e07:	0f 8f af 14 00 00    	jg     92bc <f12+0x163c>
    7e0d:	48 39 1d cc 82 01 00 	cmp    %rbx,0x182cc(%rip)        # 200e0 <fwp_tapes_cap>
    7e14:	48 8b 2d d5 82 01 00 	mov    0x182d5(%rip),%rbp        # 200f0 <fwp_tapes>
    7e1b:	75 42                	jne    7e5f <f12+0x1df>
    7e1d:	48 85 db             	test   %rbx,%rbx
    7e20:	0f 85 6a 12 00 00    	jne    9090 <f12+0x1410>
    7e26:	be 68 00 00 00       	mov    $0x68,%esi
    7e2b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    7e31:	48 89 ef             	mov    %rbp,%rdi
    7e34:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    7e3a:	e8 91 b7 ff ff       	call   35d0 <realloc@plt>
    7e3f:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    7e45:	48 85 c0             	test   %rax,%rax
    7e48:	48 89 c5             	mov    %rax,%rbp
    7e4b:	0f 84 36 11 00 00    	je     8f87 <f12+0x1307>
    7e51:	48 89 05 98 82 01 00 	mov    %rax,0x18298(%rip)        # 200f0 <fwp_tapes>
    7e58:	4c 89 2d 81 82 01 00 	mov    %r13,0x18281(%rip)        # 200e0 <fwp_tapes_cap>
    7e5f:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7e63:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    7e67:	48 01 e8             	add    %rbp,%rax
    7e6a:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7e6e:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e75:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7e79:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7e80:	00 
    7e81:	48 29 f8             	sub    %rdi,%rax
    7e84:	8d 48 68             	lea    0x68(%rax),%ecx
    7e87:	31 c0                	xor    %eax,%eax
    7e89:	c1 e9 03             	shr    $0x3,%ecx
    7e8c:	f3 48 ab             	rep stos %rax,(%rdi)
    7e8f:	4c 89 2d 52 82 01 00 	mov    %r13,0x18252(%rip)        # 200e8 <fwp_ntapes>
    7e96:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    7e9a:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7e9e:	48 8d 3d 7d 42 00 00 	lea    0x427d(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    7ea5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7eaa:	49 01 ee             	add    %rbp,%r14
    7ead:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    7eb4:	00 
    7eb5:	e8 e6 b4 ff ff       	call   33a0 <getenv@plt>
    7eba:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    7ec0:	48 85 c0             	test   %rax,%rax
    7ec3:	74 09                	je     7ece <f12+0x24e>
    7ec5:	80 38 30             	cmpb   $0x30,(%rax)
    7ec8:	0f 84 d2 03 00 00    	je     82a0 <f12+0x620>
    7ece:	48 83 3d b2 81 01 00 	cmpq   $0x0,0x181b2(%rip)        # 20088 <fwp_tape_cached_bytes>
    7ed5:	00 
    7ed6:	0f 85 04 11 00 00    	jne    8fe0 <f12+0x1360>
    7edc:	41 8b 06             	mov    (%r14),%eax
    7edf:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    7ee6:	00 
    7ee7:	4c 89 2d ea 81 01 00 	mov    %r13,0x181ea(%rip)        # 200d8 <fwp_tape_next_slot>
    7eee:	8d 70 01             	lea    0x1(%rax),%esi
    7ef1:	48 8b 05 60 a5 01 00 	mov    0x1a560(%rip),%rax        # 22458 <fwp_cleanups>
    7ef8:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    7efd:	41 89 36             	mov    %esi,(%r14)
    7f00:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    7f07:	00 
    7f08:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    7f0f:	ff 
    7f10:	48 85 c0             	test   %rax,%rax
    7f13:	75 17                	jne    7f2c <f12+0x2ac>
    7f15:	e9 96 13 00 00       	jmp    92b0 <f12+0x1630>
    7f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f20:	48 8b 00             	mov    (%rax),%rax
    7f23:	48 85 c0             	test   %rax,%rax
    7f26:	0f 84 84 13 00 00    	je     92b0 <f12+0x1630>
    7f2c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    7f30:	75 ee                	jne    7f20 <f12+0x2a0>
    7f32:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7f36:	89 d9                	mov    %ebx,%ecx
    7f38:	48 63 02             	movslq (%rdx),%rax
    7f3b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    7f3f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    7f43:	85 c0                	test   %eax,%eax
    7f45:	78 08                	js     7f4f <f12+0x2cf>
    7f47:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7f4b:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7f4f:	89 0a                	mov    %ecx,(%rdx)
    7f51:	bf 01 00 00 00       	mov    $0x1,%edi
    7f56:	89 74 24 10          	mov    %esi,0x10(%rsp)
    7f5a:	e8 f1 c2 ff ff       	call   4250 <descent_phase_step>
    7f5f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f64:	31 c9                	xor    %ecx,%ecx
    7f66:	8b 74 24 10          	mov    0x10(%rsp),%esi
    7f6a:	48 85 ff             	test   %rdi,%rdi
    7f6d:	48 89 f8             	mov    %rdi,%rax
    7f70:	0f 84 3a 03 00 00    	je     82b0 <f12+0x630>
    7f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f7d:	00 00 00 
    7f80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7f84:	48 83 c1 01          	add    $0x1,%rcx
    7f88:	48 85 c0             	test   %rax,%rax
    7f8b:	75 f3                	jne    7f80 <f12+0x300>
    7f8d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f92:	0f 1f 00             	nopl   (%rax)
    7f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f9c:	00 00 00 00 
    7fa0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7fa4:	48 83 c0 01          	add    $0x1,%rax
    7fa8:	48 85 d2             	test   %rdx,%rdx
    7fab:	75 f3                	jne    7fa0 <f12+0x320>
    7fad:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7fb4:	ff ff 1f 
    7fb7:	48 39 c2             	cmp    %rax,%rdx
    7fba:	0f 82 d3 12 00 00    	jb     9293 <f12+0x1613>
    7fc0:	48 85 c9             	test   %rcx,%rcx
    7fc3:	0f 8e e7 02 00 00    	jle    82b0 <f12+0x630>
    7fc9:	48 39 c1             	cmp    %rax,%rcx
    7fcc:	48 0f 46 c1          	cmovbe %rcx,%rax
    7fd0:	49 89 c4             	mov    %rax,%r12
    7fd3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7fd7:	0f 85 b6 12 00 00    	jne    9293 <f12+0x1613>
    7fdd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    7fe1:	48 c1 e6 10          	shl    $0x10,%rsi
    7fe5:	49 09 f5             	or     %rsi,%r13
    7fe8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    7fef:	00 
    7ff0:	be 02 00 00 00       	mov    $0x2,%esi
    7ff5:	e8 96 dc ff ff       	call   5c90 <fwp_heap_alloc>
    7ffa:	4c 89 30             	mov    %r14,(%rax)
    7ffd:	48 8b 15 94 9b 01 00 	mov    0x19b94(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    8004:	48 89 c3             	mov    %rax,%rbx
    8007:	48 2b 05 62 9b 01 00 	sub    0x19b62(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    800e:	48 c1 e2 10          	shl    $0x10,%rdx
    8012:	48 39 d0             	cmp    %rdx,%rax
    8015:	0f 83 c5 10 00 00    	jae    90e0 <f12+0x1460>
    801b:	48 89 c2             	mov    %rax,%rdx
    801e:	48 c1 ea 10          	shr    $0x10,%rdx
    8022:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8026:	48 8b 15 8b 9b 01 00 	mov    0x19b8b(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    802d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8031:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8035:	4d 85 f6             	test   %r14,%r14
    8038:	74 38                	je     8072 <f12+0x3f2>
    803a:	0f b6 0a             	movzbl (%rdx),%ecx
    803d:	80 f9 02             	cmp    $0x2,%cl
    8040:	0f 84 d7 02 00 00    	je     831d <f12+0x69d>
    8046:	80 f9 01             	cmp    $0x1,%cl
    8049:	75 27                	jne    8072 <f12+0x3f2>
    804b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    804e:	0f b7 c0             	movzwl %ax,%eax
    8051:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8054:	48 0f af c1          	imul   %rcx,%rax
    8058:	48 c1 e8 20          	shr    $0x20,%rax
    805c:	48 39 d0             	cmp    %rdx,%rax
    805f:	73 11                	jae    8072 <f12+0x3f2>
    8061:	49 01 c6             	add    %rax,%r14
    8064:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8068:	0f 84 ff 10 00 00    	je     916d <f12+0x14ed>
    806e:	41 c6 06 01          	movb   $0x1,(%r14)
    8072:	4d 85 e4             	test   %r12,%r12
    8075:	74 7c                	je     80f3 <f12+0x473>
    8077:	4c 89 e9             	mov    %r13,%rcx
    807a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    807f:	31 c0                	xor    %eax,%eax
    8081:	48 c1 e1 20          	shl    $0x20,%rcx
    8085:	0f 1f 40 00          	nopl   0x0(%rax)
    8089:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8090:	00 00 00 00 
    8094:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809b:	00 00 00 00 
    809f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80a6:	00 00 00 00 
    80aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80b1:	00 00 00 00 
    80b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80bc:	00 00 00 00 
    80c0:	48 89 c6             	mov    %rax,%rsi
    80c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    80c8:	48 01 ce             	add    %rcx,%rsi
    80cb:	0f 80 9d 11 00 00    	jo     926e <f12+0x15ee>
    80d1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    80d6:	48 89 c6             	mov    %rax,%rsi
    80d9:	48 83 c0 01          	add    $0x1,%rax
    80dd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    80e1:	48 c1 e6 04          	shl    $0x4,%rsi
    80e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    80ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80ee:	4c 39 e0             	cmp    %r12,%rax
    80f1:	72 cd                	jb     80c0 <f12+0x440>
    80f3:	48 8b 03             	mov    (%rbx),%rax
    80f6:	48 d1 e8             	shr    $1,%rax
    80f9:	0f 85 31 02 00 00    	jne    8330 <f12+0x6b0>
    80ff:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8106:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    810d:	0f 1f 00             	nopl   (%rax)
    8110:	48 89 df             	mov    %rbx,%rdi
    8113:	4d 63 e5             	movslq %r13d,%r12
    8116:	e8 55 f6 ff ff       	call   7770 <fwp_drop4>
    811b:	bf 02 00 00 00       	mov    $0x2,%edi
    8120:	e8 2b c1 ff ff       	call   4250 <descent_phase_step>
    8125:	4c 89 e7             	mov    %r12,%rdi
    8128:	e8 a3 c5 ff ff       	call   46d0 <fwp_tape_of>
    812d:	48 89 c6             	mov    %rax,%rsi
    8130:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8135:	0f 85 69 11 00 00    	jne    92a4 <f12+0x1624>
    813b:	48 89 c7             	mov    %rax,%rdi
    813e:	e8 bd ba ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8143:	f3 0f 6f 7e 20       	movdqu 0x20(%rsi),%xmm7
    8148:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    814c:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8153:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8158:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    815c:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    8161:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8166:	66 49 0f 6e d6       	movq   %r14,%xmm2
    816b:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    816f:	48 8b 5e 40          	mov    0x40(%rsi),%rbx
    8173:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8177:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    817c:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8182:	77 19                	ja     819d <f12+0x51d>
    8184:	41 0f b7 c5          	movzwl %r13w,%eax
    8188:	83 e8 01             	sub    $0x1,%eax
    818b:	48 98                	cltq
    818d:	48 3b 05 44 7f 01 00 	cmp    0x17f44(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    8194:	7d 07                	jge    819d <f12+0x51d>
    8196:	48 89 05 3b 7f 01 00 	mov    %rax,0x17f3b(%rip)        # 200d8 <fwp_tape_next_slot>
    819d:	66 0f ef c9          	pxor   %xmm1,%xmm1
    81a1:	48 8b 05 b0 a2 01 00 	mov    0x1a2b0(%rip),%rax        # 22458 <fwp_cleanups>
    81a8:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    81ae:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    81b5:	00 
    81b6:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    81ba:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    81c0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    81c7:	00 
    81c8:	48 8d 05 a1 ce ff ff 	lea    -0x315f(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    81cf:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    81d6:	00 
    81d7:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    81de:	00 
    81df:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    81e4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    81eb:	00 
    81ec:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    81f3:	00 
    81f4:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    81f8:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    81fc:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8203:	00 
    8204:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    820b:	00 
    820c:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
    8213:	00 
    8214:	48 89 05 3d a2 01 00 	mov    %rax,0x1a23d(%rip)        # 22458 <fwp_cleanups>
    821b:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8222:	00 
    8223:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    822a:	00 
    822b:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8232:	00 
    8233:	4d 85 ff             	test   %r15,%r15
    8236:	0f 88 14 0d 00 00    	js     8f50 <f12+0x12d0>
    823c:	4c 89 f8             	mov    %r15,%rax
    823f:	48 c1 f8 20          	sar    $0x20,%rax
    8243:	49 39 c4             	cmp    %rax,%r12
    8246:	0f 85 f9 0f 00 00    	jne    9245 <f12+0x15c5>
    824c:	45 89 fa             	mov    %r15d,%r10d
    824f:	4d 89 d5             	mov    %r10,%r13
    8252:	4c 39 d2             	cmp    %r10,%rdx
    8255:	0f 8e f6 0f 00 00    	jle    9251 <f12+0x15d1>
    825b:	4c 39 d5             	cmp    %r10,%rbp
    825e:	0f 8e 8c 01 00 00    	jle    83f0 <f12+0x770>
    8264:	4c 39 f5             	cmp    %r14,%rbp
    8267:	0f 8f 13 0e 00 00    	jg     9080 <f12+0x1400>
    826d:	48 85 db             	test   %rbx,%rbx
    8270:	0f 84 f8 0c 00 00    	je     8f6e <f12+0x12ee>
    8276:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    827d:	00 
    827e:	31 f6                	xor    %esi,%esi
    8280:	48 89 df             	mov    %rbx,%rdi
    8283:	45 31 f6             	xor    %r14d,%r14d
    8286:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    828b:	4c 8d 6d ff          	lea    -0x1(%rbp),%r13
    828f:	e8 2c b2 ff ff       	call   34c0 <memset@plt>
    8294:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    8299:	e9 ef 01 00 00       	jmp    848d <f12+0x80d>
    829e:	66 90                	xchg   %ax,%ax
    82a0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    82a4:	0f 84 32 fc ff ff    	je     7edc <f12+0x25c>
    82aa:	e9 1f fc ff ff       	jmp    7ece <f12+0x24e>
    82af:	90                   	nop
    82b0:	48 c1 e6 10          	shl    $0x10,%rsi
    82b4:	bf 08 00 00 00       	mov    $0x8,%edi
    82b9:	49 09 f5             	or     %rsi,%r13
    82bc:	be 02 00 00 00       	mov    $0x2,%esi
    82c1:	e8 ca d9 ff ff       	call   5c90 <fwp_heap_alloc>
    82c6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    82cd:	48 8b 15 c4 98 01 00 	mov    0x198c4(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    82d4:	48 89 c3             	mov    %rax,%rbx
    82d7:	48 2b 05 92 98 01 00 	sub    0x19892(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    82de:	48 c1 e2 10          	shl    $0x10,%rdx
    82e2:	48 39 d0             	cmp    %rdx,%rax
    82e5:	0f 83 14 fe ff ff    	jae    80ff <f12+0x47f>
    82eb:	48 89 c2             	mov    %rax,%rdx
    82ee:	48 c1 ea 10          	shr    $0x10,%rdx
    82f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82f6:	48 8b 15 bb 98 01 00 	mov    0x198bb(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    82fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8301:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8305:	4d 85 f6             	test   %r14,%r14
    8308:	0f 84 e5 fd ff ff    	je     80f3 <f12+0x473>
    830e:	0f b6 0a             	movzbl (%rdx),%ecx
    8311:	45 31 e4             	xor    %r12d,%r12d
    8314:	80 f9 02             	cmp    $0x2,%cl
    8317:	0f 85 29 fd ff ff    	jne    8046 <f12+0x3c6>
    831d:	66 85 c0             	test   %ax,%ax
    8320:	0f 85 4c fd ff ff    	jne    8072 <f12+0x3f2>
    8326:	e9 39 fd ff ff       	jmp    8064 <f12+0x3e4>
    832b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8330:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8334:	4c 89 e1             	mov    %r12,%rcx
    8337:	48 c1 e9 3c          	shr    $0x3c,%rcx
    833b:	0f 85 52 0f 00 00    	jne    9293 <f12+0x1613>
    8341:	4d 85 e4             	test   %r12,%r12
    8344:	0f 84 b5 fd ff ff    	je     80ff <f12+0x47f>
    834a:	48 c1 e0 04          	shl    $0x4,%rax
    834e:	4d 01 e4             	add    %r12,%r12
    8351:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    8355:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    835a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8360:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    8365:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    8369:	48 83 c5 10          	add    $0x10,%rbp
    836d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    8371:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    8376:	e8 f5 df ff ff       	call   6370 <w107>
    837b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8380:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8384:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    8388:	49 39 ee             	cmp    %rbp,%r14
    838b:	75 d3                	jne    8360 <f12+0x6e0>
    838d:	4c 89 23             	mov    %r12,(%rbx)
    8390:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8397:	45 31 f6             	xor    %r14d,%r14d
    839a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    83a0:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    83a5:	4c 89 ff             	mov    %r15,%rdi
    83a8:	49 83 c6 02          	add    $0x2,%r14
    83ac:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    83b3:	00 f0 3f 
    83b6:	48 89 ce             	mov    %rcx,%rsi
    83b9:	e8 32 dc ff ff       	call   5ff0 <fwp_p_ad_push>
    83be:	49 89 c7             	mov    %rax,%r15
    83c1:	4d 39 e6             	cmp    %r12,%r14
    83c4:	72 da                	jb     83a0 <f12+0x720>
    83c6:	e9 45 fd ff ff       	jmp    8110 <f12+0x490>
    83cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    83d0:	48 39 d3             	cmp    %rdx,%rbx
    83d3:	0f 84 27 fa ff ff    	je     7e00 <f12+0x180>
    83d9:	48 8b 2d 10 7d 01 00 	mov    0x17d10(%rip),%rbp        # 200f0 <fwp_tapes>
    83e0:	48 89 d3             	mov    %rdx,%rbx
    83e3:	4c 8d 6a 01          	lea    0x1(%rdx),%r13
    83e7:	e9 aa fa ff ff       	jmp    7e96 <f12+0x216>
    83ec:	0f 1f 40 00          	nopl   0x0(%rax)
    83f0:	4d 8d 62 01          	lea    0x1(%r10),%r12
    83f4:	4d 39 e6             	cmp    %r12,%r14
    83f7:	0f 8d 53 0c 00 00    	jge    9050 <f12+0x13d0>
    83fd:	4d 85 f6             	test   %r14,%r14
    8400:	4d 0f 44 f4          	cmove  %r12,%r14
    8404:	eb 2f                	jmp    8435 <f12+0x7b5>
    8406:	0f 1f 40 00          	nopl   0x0(%rax)
    840a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8411:	00 00 00 00 
    8415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    841c:	00 00 00 00 
    8420:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8424:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    842b:	4c 89 e0             	mov    %r12,%rax
    842e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8432:	49 89 c6             	mov    %rax,%r14
    8435:	4d 39 e6             	cmp    %r12,%r14
    8438:	7c e6                	jl     8420 <f12+0x7a0>
    843a:	48 85 db             	test   %rbx,%rbx
    843d:	0f 84 ad 0c 00 00    	je     90f0 <f12+0x1470>
    8443:	48 89 df             	mov    %rbx,%rdi
    8446:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    844d:	00 
    844e:	e8 7d b1 ff ff       	call   35d0 <realloc@plt>
    8453:	48 89 c3             	mov    %rax,%rbx
    8456:	48 85 db             	test   %rbx,%rbx
    8459:	0f 84 fd 0a 00 00    	je     8f5c <f12+0x12dc>
    845f:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
    8466:	00 
    8467:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    846e:	00 
    846f:	4d 85 e4             	test   %r12,%r12
    8472:	0f 85 26 0d 00 00    	jne    919e <f12+0x151e>
    8478:	49 89 ee             	mov    %rbp,%r14
    847b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8482:	49 f7 de             	neg    %r14
    8485:	4d 85 ff             	test   %r15,%r15
    8488:	78 17                	js     84a1 <f12+0x821>
    848a:	45 89 fa             	mov    %r15d,%r10d
    848d:	f2 0f 10 05 8b 47 00 	movsd  0x478b(%rip),%xmm0        # cc20 <msg.4+0xb0>
    8494:	00 
    8495:	f2 42 0f 58 04 d3    	addsd  (%rbx,%r10,8),%xmm0
    849b:	f2 42 0f 11 04 d3    	movsd  %xmm0,(%rbx,%r10,8)
    84a1:	bf 03 00 00 00       	mov    $0x3,%edi
    84a6:	48 01 2d 53 7c 01 00 	add    %rbp,0x17c53(%rip)        # 20100 <descent_inputs>
    84ad:	4c 01 35 54 7c 01 00 	add    %r14,0x17c54(%rip)        # 20108 <descent_nodes>
    84b4:	e8 97 bd ff ff       	call   4250 <descent_phase_step>
    84b9:	4c 39 ed             	cmp    %r13,%rbp
    84bc:	0f 8f 88 00 00 00    	jg     854a <f12+0x8ca>
    84c2:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    84c7:	49 29 ed             	sub    %rbp,%r13
    84ca:	4c 8d 04 eb          	lea    (%rbx,%rbp,8),%r8
    84ce:	66 0f ef d2          	pxor   %xmm2,%xmm2
    84d2:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    84d7:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    84dc:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    84e1:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    84e5:	4d 29 d8             	sub    %r11,%r8
    84e8:	4a 8d 04 af          	lea    (%rdi,%r13,4),%rax
    84ec:	48 29 fe             	sub    %rdi,%rsi
    84ef:	4d 29 da             	sub    %r11,%r10
    84f2:	eb 08                	jmp    84fc <f12+0x87c>
    84f4:	0f 1f 40 00          	nopl   0x0(%rax)
    84f8:	48 83 e8 04          	sub    $0x4,%rax
    84fc:	f2 41 0f 10 04 10    	movsd  (%r8,%rdx,1),%xmm0
    8502:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8506:	7a 02                	jp     850a <f12+0x88a>
    8508:	74 37                	je     8541 <f12+0x8c1>
    850a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    850e:	45 85 db             	test   %r11d,%r11d
    8511:	78 16                	js     8529 <f12+0x8a9>
    8513:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8519:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    851d:	f2 42 0f 58 0c db    	addsd  (%rbx,%r11,8),%xmm1
    8523:	f2 42 0f 11 0c db    	movsd  %xmm1,(%rbx,%r11,8)
    8529:	4c 63 18             	movslq (%rax),%r11
    852c:	45 85 db             	test   %r11d,%r11d
    852f:	78 10                	js     8541 <f12+0x8c1>
    8531:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8535:	f2 42 0f 58 04 db    	addsd  (%rbx,%r11,8),%xmm0
    853b:	f2 42 0f 11 04 db    	movsd  %xmm0,(%rbx,%r11,8)
    8541:	48 83 ea 08          	sub    $0x8,%rdx
    8545:	48 39 c7             	cmp    %rax,%rdi
    8548:	75 ae                	jne    84f8 <f12+0x878>
    854a:	bf 04 00 00 00       	mov    $0x4,%edi
    854f:	e8 fc bc ff ff       	call   4250 <descent_phase_step>
    8554:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    855b:	ff ff 1f 
    855e:	48 39 e8             	cmp    %rbp,%rax
    8561:	0f 82 14 0d 00 00    	jb     927b <f12+0x15fb>
    8567:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    856e:	00 
    856f:	be 02 00 00 00       	mov    $0x2,%esi
    8574:	e8 17 d7 ff ff       	call   5c90 <fwp_heap_alloc>
    8579:	48 89 28             	mov    %rbp,(%rax)
    857c:	49 89 c4             	mov    %rax,%r12
    857f:	31 c0                	xor    %eax,%eax
    8581:	48 85 ed             	test   %rbp,%rbp
    8584:	74 2c                	je     85b2 <f12+0x932>
    8586:	0f 1f 40 00          	nopl   0x0(%rax)
    858a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8591:	00 00 00 00 
    8595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    859c:	00 00 00 00 
    85a0:	48 8b 14 c3          	mov    (%rbx,%rax,8),%rdx
    85a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    85a9:	48 83 c0 01          	add    $0x1,%rax
    85ad:	48 39 c5             	cmp    %rax,%rbp
    85b0:	75 ee                	jne    85a0 <f12+0x920>
    85b2:	bf 05 00 00 00       	mov    $0x5,%edi
    85b7:	e8 94 bc ff ff       	call   4250 <descent_phase_step>
    85bc:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    85c3:	00 
    85c4:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    85c9:	4c 89 2d 88 9e 01 00 	mov    %r13,0x19e88(%rip)        # 22458 <fwp_cleanups>
    85d0:	e8 9b ca ff ff       	call   5070 <fwp_tape_buffers_release>
    85d5:	bf 06 00 00 00       	mov    $0x6,%edi
    85da:	e8 71 bc ff ff       	call   4250 <descent_phase_step>
    85df:	48 8b 15 b2 95 01 00 	mov    0x195b2(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    85e6:	4c 89 e0             	mov    %r12,%rax
    85e9:	48 2b 05 80 95 01 00 	sub    0x19580(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    85f0:	48 c1 e2 10          	shl    $0x10,%rdx
    85f4:	48 39 d0             	cmp    %rdx,%rax
    85f7:	73 55                	jae    864e <f12+0x9ce>
    85f9:	48 89 c2             	mov    %rax,%rdx
    85fc:	48 c1 ea 10          	shr    $0x10,%rdx
    8600:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8604:	48 8b 15 ad 95 01 00 	mov    0x195ad(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    860b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    860f:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8613:	48 85 db             	test   %rbx,%rbx
    8616:	74 36                	je     864e <f12+0x9ce>
    8618:	0f b6 0a             	movzbl (%rdx),%ecx
    861b:	80 f9 02             	cmp    $0x2,%cl
    861e:	0f 84 94 09 00 00    	je     8fb8 <f12+0x1338>
    8624:	80 f9 01             	cmp    $0x1,%cl
    8627:	75 25                	jne    864e <f12+0x9ce>
    8629:	8b 4a 18             	mov    0x18(%rdx),%ecx
    862c:	0f b7 c0             	movzwl %ax,%eax
    862f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8632:	48 0f af c1          	imul   %rcx,%rax
    8636:	48 c1 e8 20          	shr    $0x20,%rax
    863a:	48 39 d0             	cmp    %rdx,%rax
    863d:	73 0f                	jae    864e <f12+0x9ce>
    863f:	48 01 c3             	add    %rax,%rbx
    8642:	80 3b ff             	cmpb   $0xff,(%rbx)
    8645:	0f 84 2f 0b 00 00    	je     917a <f12+0x14fa>
    864b:	c6 03 01             	movb   $0x1,(%rbx)
    864e:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    8653:	0f 85 f2 b0 ff ff    	jne    374b <f12.cold>
    8659:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    865e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8663:	48 89 05 ee 9d 01 00 	mov    %rax,0x19dee(%rip)        # 22458 <fwp_cleanups>
    866a:	e8 51 e7 ff ff       	call   6dc0 <fwp_tape_scope_release>
    866f:	49 8b 04 24          	mov    (%r12),%rax
    8673:	49 89 c5             	mov    %rax,%r13
    8676:	49 0f ba f5 3f       	btr    $0x3f,%r13
    867b:	48 85 c0             	test   %rax,%rax
    867e:	0f 88 bc 07 00 00    	js     8e40 <f12+0x11c0>
    8684:	48 8b 15 0d 95 01 00 	mov    0x1950d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    868b:	4c 89 e0             	mov    %r12,%rax
    868e:	48 2b 05 db 94 01 00 	sub    0x194db(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8695:	48 c1 e2 10          	shl    $0x10,%rdx
    8699:	48 39 d0             	cmp    %rdx,%rax
    869c:	0f 83 9e 07 00 00    	jae    8e40 <f12+0x11c0>
    86a2:	48 89 c2             	mov    %rax,%rdx
    86a5:	48 c1 ea 10          	shr    $0x10,%rdx
    86a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86ad:	48 8b 15 04 95 01 00 	mov    0x19504(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    86b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86b8:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    86bc:	48 85 c9             	test   %rcx,%rcx
    86bf:	0f 84 7b 07 00 00    	je     8e40 <f12+0x11c0>
    86c5:	0f b6 32             	movzbl (%rdx),%esi
    86c8:	40 80 fe 02          	cmp    $0x2,%sil
    86cc:	0f 84 5e 07 00 00    	je     8e30 <f12+0x11b0>
    86d2:	40 80 fe 01          	cmp    $0x1,%sil
    86d6:	0f 85 64 07 00 00    	jne    8e40 <f12+0x11c0>
    86dc:	8b 72 18             	mov    0x18(%rdx),%esi
    86df:	0f b7 c0             	movzwl %ax,%eax
    86e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86e5:	48 0f af c6          	imul   %rsi,%rax
    86e9:	48 c1 e8 20          	shr    $0x20,%rax
    86ed:	48 39 d0             	cmp    %rdx,%rax
    86f0:	0f 83 4a 07 00 00    	jae    8e40 <f12+0x11c0>
    86f6:	48 01 c1             	add    %rax,%rcx
    86f9:	80 39 01             	cmpb   $0x1,(%rcx)
    86fc:	0f 85 3e 07 00 00    	jne    8e40 <f12+0x11c0>
    8702:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
    8707:	4c 89 e3             	mov    %r12,%rbx
    870a:	31 ff                	xor    %edi,%edi
    870c:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8711:	f2 0f 10 0d 1f 45 00 	movsd  0x451f(%rip),%xmm1        # cc38 <msg.4+0xc8>
    8718:	00 
    8719:	48 8d 50 08          	lea    0x8(%rax),%rdx
    871d:	31 c0                	xor    %eax,%eax
    871f:	4d 85 ed             	test   %r13,%r13
    8722:	75 31                	jne    8755 <f12+0xad5>
    8724:	eb 4a                	jmp    8770 <f12+0xaf0>
    8726:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    872d:	00 00 00 
    8730:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8734:	0f 88 28 0b 00 00    	js     9262 <f12+0x15e2>
    873a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    873f:	48 83 c0 01          	add    $0x1,%rax
    8743:	48 83 c2 08          	add    $0x8,%rdx
    8747:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    874b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8750:	49 39 c5             	cmp    %rax,%r13
    8753:	74 1b                	je     8770 <f12+0xaf0>
    8755:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    875a:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    875f:	79 cf                	jns    8730 <f12+0xab0>
    8761:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8766:	eb c8                	jmp    8730 <f12+0xab0>
    8768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    876f:	00 
    8770:	e8 fb ef ff ff       	call   7770 <fwp_drop4>
    8775:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    877a:	31 d2                	xor    %edx,%edx
    877c:	48 89 c8             	mov    %rcx,%rax
    877f:	48 85 c9             	test   %rcx,%rcx
    8782:	0f 84 8d 09 00 00    	je     9115 <f12+0x1495>
    8788:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    878f:	00 
    8790:	48 8b 40 10          	mov    0x10(%rax),%rax
    8794:	48 83 c2 01          	add    $0x1,%rdx
    8798:	48 85 c0             	test   %rax,%rax
    879b:	75 f3                	jne    8790 <f12+0xb10>
    879d:	48 8b 03             	mov    (%rbx),%rax
    87a0:	49 89 c7             	mov    %rax,%r15
    87a3:	49 0f ba f7 3f       	btr    $0x3f,%r15
    87a8:	48 85 c0             	test   %rax,%rax
    87ab:	0f 88 e4 05 00 00    	js     8d95 <f12+0x1115>
    87b1:	48 8b 0d e0 93 01 00 	mov    0x193e0(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    87b8:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    87bd:	48 2b 05 ac 93 01 00 	sub    0x193ac(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    87c4:	48 c1 e1 10          	shl    $0x10,%rcx
    87c8:	48 39 c8             	cmp    %rcx,%rax
    87cb:	0f 83 c4 05 00 00    	jae    8d95 <f12+0x1115>
    87d1:	48 89 c1             	mov    %rax,%rcx
    87d4:	48 c1 e9 10          	shr    $0x10,%rcx
    87d8:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    87dc:	48 8b 0d d5 93 01 00 	mov    0x193d5(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    87e3:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    87e7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    87eb:	48 85 ff             	test   %rdi,%rdi
    87ee:	0f 84 a1 05 00 00    	je     8d95 <f12+0x1115>
    87f4:	0f b6 0e             	movzbl (%rsi),%ecx
    87f7:	80 f9 02             	cmp    $0x2,%cl
    87fa:	0f 84 80 05 00 00    	je     8d80 <f12+0x1100>
    8800:	80 f9 01             	cmp    $0x1,%cl
    8803:	0f 85 80 05 00 00    	jne    8d89 <f12+0x1109>
    8809:	8b 4e 18             	mov    0x18(%rsi),%ecx
    880c:	0f b7 c0             	movzwl %ax,%eax
    880f:	48 0f af c1          	imul   %rcx,%rax
    8813:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    8816:	48 c1 e8 20          	shr    $0x20,%rax
    881a:	48 39 c8             	cmp    %rcx,%rax
    881d:	0f 83 66 05 00 00    	jae    8d89 <f12+0x1109>
    8823:	48 01 c7             	add    %rax,%rdi
    8826:	80 3f 01             	cmpb   $0x1,(%rdi)
    8829:	0f 85 5a 05 00 00    	jne    8d89 <f12+0x1109>
    882f:	4c 39 fa             	cmp    %r15,%rdx
    8832:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8836:	4c 89 fd             	mov    %r15,%rbp
    8839:	4d 85 ff             	test   %r15,%r15
    883c:	0f 84 31 0a 00 00    	je     9273 <f12+0x15f3>
    8842:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8849:	00 
    884a:	4c 8d 63 08          	lea    0x8(%rbx),%r12
    884e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8853:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8858:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    885f:	00 
    8860:	31 c0                	xor    %eax,%eax
    8862:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8866:	eb 35                	jmp    889d <f12+0xc1d>
    8868:	66 90                	xchg   %ax,%ax
    886a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8871:	00 00 00 00 
    8875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    887c:	00 00 00 00 
    8880:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8885:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    888a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8890:	48 83 c0 08          	add    $0x8,%rax
    8894:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8898:	49 39 c0             	cmp    %rax,%r8
    889b:	74 1b                	je     88b8 <f12+0xc38>
    889d:	48 89 fe             	mov    %rdi,%rsi
    88a0:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    88a4:	79 da                	jns    8880 <f12+0xc00>
    88a6:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    88ab:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    88af:	eb cf                	jmp    8880 <f12+0xc00>
    88b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    88b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    88bd:	48 85 d2             	test   %rdx,%rdx
    88c0:	0f 84 77 09 00 00    	je     923d <f12+0x15bd>
    88c6:	4c 8b 05 cb 92 01 00 	mov    0x192cb(%rip),%r8        # 21b98 <fwp_heap+0x13d8>
    88cd:	4c 8b 15 9c 92 01 00 	mov    0x1929c(%rip),%r10        # 21b70 <fwp_heap+0x13b0>
    88d4:	45 31 ff             	xor    %r15d,%r15d
    88d7:	4c 8b 1d da 92 01 00 	mov    0x192da(%rip),%r11        # 21bb8 <fwp_heap+0x13f8>
    88de:	49 c1 e0 10          	shl    $0x10,%r8
    88e2:	eb 1a                	jmp    88fe <f12+0xc7e>
    88e4:	0f 1f 40 00          	nopl   0x0(%rax)
    88e8:	49 83 c7 01          	add    $0x1,%r15
    88ec:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    88f0:	49 39 ef             	cmp    %rbp,%r15
    88f3:	0f 83 37 02 00 00    	jae    8b30 <f12+0xeb0>
    88f9:	48 85 d2             	test   %rdx,%rdx
    88fc:	74 52                	je     8950 <f12+0xcd0>
    88fe:	48 89 d0             	mov    %rdx,%rax
    8901:	4c 29 d0             	sub    %r10,%rax
    8904:	4c 39 c0             	cmp    %r8,%rax
    8907:	73 47                	jae    8950 <f12+0xcd0>
    8909:	48 89 c6             	mov    %rax,%rsi
    890c:	48 c1 ee 10          	shr    $0x10,%rsi
    8910:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8914:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8918:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    891c:	48 85 ff             	test   %rdi,%rdi
    891f:	74 2f                	je     8950 <f12+0xcd0>
    8921:	0f b6 1e             	movzbl (%rsi),%ebx
    8924:	80 fb 02             	cmp    $0x2,%bl
    8927:	0f 84 e3 01 00 00    	je     8b10 <f12+0xe90>
    892d:	80 fb 01             	cmp    $0x1,%bl
    8930:	75 1e                	jne    8950 <f12+0xcd0>
    8932:	8b 5e 18             	mov    0x18(%rsi),%ebx
    8935:	0f b7 c0             	movzwl %ax,%eax
    8938:	8b 76 1c             	mov    0x1c(%rsi),%esi
    893b:	48 0f af c3          	imul   %rbx,%rax
    893f:	48 c1 e8 20          	shr    $0x20,%rax
    8943:	48 39 f0             	cmp    %rsi,%rax
    8946:	73 08                	jae    8950 <f12+0xcd0>
    8948:	48 01 c7             	add    %rax,%rdi
    894b:	80 3f 01             	cmpb   $0x1,(%rdi)
    894e:	74 98                	je     88e8 <f12+0xc68>
    8950:	49 39 ef             	cmp    %rbp,%r15
    8953:	0f 83 d7 01 00 00    	jae    8b30 <f12+0xeb0>
    8959:	4c 8b 2d 80 42 00 00 	mov    0x4280(%rip),%r13        # cbe0 <msg.4+0x70>
    8960:	45 31 f6             	xor    %r14d,%r14d
    8963:	48 8d 1d 56 7e 01 00 	lea    0x17e56(%rip),%rbx        # 207c0 <fwp_heap>
    896a:	e9 19 01 00 00       	jmp    8a88 <f12+0xe08>
    896f:	90                   	nop
    8970:	49 8b 10             	mov    (%r8),%rdx
    8973:	48 f7 d2             	not    %rdx
    8976:	48 89 10             	mov    %rdx,(%rax)
    8979:	49 83 fb 18          	cmp    $0x18,%r11
    897d:	76 3b                	jbe    89ba <f12+0xd3a>
    897f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8983:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8987:	31 f6                	xor    %esi,%esi
    8989:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    898e:	48 c1 e8 03          	shr    $0x3,%rax
    8992:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8997:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    899e:	00 
    899f:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    89a5:	e8 16 ab ff ff       	call   34c0 <memset@plt>
    89aa:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    89af:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    89b4:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    89ba:	4c 89 d8             	mov    %r11,%rax
    89bd:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    89c4:	0f 82 93 08 00 00    	jb     925d <f12+0x15dd>
    89ca:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    89d1:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    89d8:	73 07                	jae    89e1 <f12+0xd61>
    89da:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    89e1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    89e5:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    89ea:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    89f1:	00 
    89f2:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    89f9:	00 
    89fa:	66 49 0f 6e ee       	movq   %r14,%xmm5
    89ff:	4d 89 28             	mov    %r13,(%r8)
    8a02:	4c 89 c0             	mov    %r8,%rax
    8a05:	4d 89 c6             	mov    %r8,%r14
    8a08:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8a0c:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8a11:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8a18:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8a1f:	48 c1 e2 10          	shl    $0x10,%rdx
    8a23:	48 39 d0             	cmp    %rdx,%rax
    8a26:	73 57                	jae    8a7f <f12+0xdff>
    8a28:	48 89 c2             	mov    %rax,%rdx
    8a2b:	48 c1 ea 10          	shr    $0x10,%rdx
    8a2f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8a33:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8a3a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8a3e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8a42:	48 85 d2             	test   %rdx,%rdx
    8a45:	74 38                	je     8a7f <f12+0xdff>
    8a47:	0f b6 3e             	movzbl (%rsi),%edi
    8a4a:	40 80 ff 02          	cmp    $0x2,%dil
    8a4e:	0f 84 7c 01 00 00    	je     8bd0 <f12+0xf50>
    8a54:	40 80 ff 01          	cmp    $0x1,%dil
    8a58:	75 25                	jne    8a7f <f12+0xdff>
    8a5a:	8b 7e 18             	mov    0x18(%rsi),%edi
    8a5d:	0f b7 c0             	movzwl %ax,%eax
    8a60:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8a63:	48 0f af c7          	imul   %rdi,%rax
    8a67:	48 c1 e8 20          	shr    $0x20,%rax
    8a6b:	48 39 f0             	cmp    %rsi,%rax
    8a6e:	73 0f                	jae    8a7f <f12+0xdff>
    8a70:	48 01 c2             	add    %rax,%rdx
    8a73:	80 3a ff             	cmpb   $0xff,(%rdx)
    8a76:	0f 84 74 04 00 00    	je     8ef0 <f12+0x1270>
    8a7c:	c6 02 01             	movb   $0x1,(%rdx)
    8a7f:	49 39 ef             	cmp    %rbp,%r15
    8a82:	0f 83 68 01 00 00    	jae    8bf0 <f12+0xf70>
    8a88:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8a8e:	48 83 ed 01          	sub    $0x1,%rbp
    8a92:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8a98:	85 f6                	test   %esi,%esi
    8a9a:	74 4c                	je     8ae8 <f12+0xe68>
    8a9c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8aa3:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8aaa:	00 
    8aab:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8aaf:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8ab3:	4c 8b 00             	mov    (%rax),%r8
    8ab6:	4d 85 c0             	test   %r8,%r8
    8ab9:	0f 85 b1 fe ff ff    	jne    8970 <f12+0xcf0>
    8abf:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8ac3:	4d 85 c0             	test   %r8,%r8
    8ac6:	74 20                	je     8ae8 <f12+0xe68>
    8ac8:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8acc:	4c 29 c2             	sub    %r8,%rdx
    8acf:	4c 39 da             	cmp    %r11,%rdx
    8ad2:	72 14                	jb     8ae8 <f12+0xe68>
    8ad4:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8ad8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8adc:	e9 98 fe ff ff       	jmp    8979 <f12+0xcf9>
    8ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ae8:	31 f6                	xor    %esi,%esi
    8aea:	bf 18 00 00 00       	mov    $0x18,%edi
    8aef:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8af5:	e8 96 d1 ff ff       	call   5c90 <fwp_heap_alloc>
    8afa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8b00:	49 89 c0             	mov    %rax,%r8
    8b03:	e9 f2 fe ff ff       	jmp    89fa <f12+0xd7a>
    8b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b0f:	00 
    8b10:	66 85 c0             	test   %ax,%ax
    8b13:	0f 84 32 fe ff ff    	je     894b <f12+0xccb>
    8b19:	49 39 ef             	cmp    %rbp,%r15
    8b1c:	0f 82 37 fe ff ff    	jb     8959 <f12+0xcd9>
    8b22:	0f 1f 00             	nopl   (%rax)
    8b25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b2c:	00 00 00 00 
    8b30:	45 31 f6             	xor    %r14d,%r14d
    8b33:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8b38:	4c 89 e2             	mov    %r12,%rdx
    8b3b:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    8b3f:	90                   	nop
    8b40:	48 8b 0a             	mov    (%rdx),%rcx
    8b43:	48 83 c2 08          	add    $0x8,%rdx
    8b47:	48 89 c6             	mov    %rax,%rsi
    8b4a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8b4e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b52:	48 39 d7             	cmp    %rdx,%rdi
    8b55:	75 e9                	jne    8b40 <f12+0xec0>
    8b57:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
    8b5b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    8b5f:	85 c9                	test   %ecx,%ecx
    8b61:	0f 84 69 04 00 00    	je     8fd0 <f12+0x1350>
    8b67:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8b6c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8b71:	45 31 e4             	xor    %r12d,%r12d
    8b74:	90                   	nop
    8b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b7c:	00 00 00 00 
    8b80:	4c 89 e7             	mov    %r12,%rdi
    8b83:	e8 08 cc ff ff       	call   5790 <fwp_mem_free>
    8b88:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8b8d:	e8 de eb ff ff       	call   7770 <fwp_drop4>
    8b92:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8b97:	e8 04 dc ff ff       	call   67a0 <fwp_drop0>
    8b9c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8ba3:	00 
    8ba4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bab:	00 00 
    8bad:	0f 85 ec 06 00 00    	jne    929f <f12+0x161f>
    8bb3:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    8bba:	4c 89 f0             	mov    %r14,%rax
    8bbd:	5b                   	pop    %rbx
    8bbe:	5d                   	pop    %rbp
    8bbf:	41 5c                	pop    %r12
    8bc1:	41 5d                	pop    %r13
    8bc3:	41 5e                	pop    %r14
    8bc5:	41 5f                	pop    %r15
    8bc7:	c3                   	ret
    8bc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bcf:	00 
    8bd0:	66 85 c0             	test   %ax,%ax
    8bd3:	0f 84 9a fe ff ff    	je     8a73 <f12+0xdf3>
    8bd9:	49 39 ef             	cmp    %rbp,%r15
    8bdc:	0f 82 a6 fe ff ff    	jb     8a88 <f12+0xe08>
    8be2:	0f 1f 00             	nopl   (%rax)
    8be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bec:	00 00 00 00 
    8bf0:	4d 85 ff             	test   %r15,%r15
    8bf3:	0f 85 3a ff ff ff    	jne    8b33 <f12+0xeb3>
    8bf9:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8bfd:	85 d2                	test   %edx,%edx
    8bff:	4d 0f 45 e7          	cmovne %r15,%r12
    8c03:	66 90                	xchg   %ax,%ax
    8c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c0c:	00 00 00 00 
    8c10:	48 85 ed             	test   %rbp,%rbp
    8c13:	0f 84 67 ff ff ff    	je     8b80 <f12+0xf00>
    8c19:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8c1f:	48 83 ed 01          	sub    $0x1,%rbp
    8c23:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8c29:	85 c0                	test   %eax,%eax
    8c2b:	0f 84 b7 05 00 00    	je     91e8 <f12+0x1568>
    8c31:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8c38:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8c3f:	00 
    8c40:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8c44:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8c48:	4c 8b 38             	mov    (%rax),%r15
    8c4b:	4d 85 ff             	test   %r15,%r15
    8c4e:	0f 84 6c 05 00 00    	je     91c0 <f12+0x1540>
    8c54:	49 8b 17             	mov    (%r15),%rdx
    8c57:	48 f7 d2             	not    %rdx
    8c5a:	48 89 10             	mov    %rdx,(%rax)
    8c5d:	49 83 f8 18          	cmp    $0x18,%r8
    8c61:	76 31                	jbe    8c94 <f12+0x1014>
    8c63:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8c67:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8c6b:	31 f6                	xor    %esi,%esi
    8c6d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8c72:	48 c1 e8 03          	shr    $0x3,%rax
    8c76:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8c7c:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8c83:	00 
    8c84:	e8 37 a8 ff ff       	call   34c0 <memset@plt>
    8c89:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8c8e:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8c94:	4c 89 c0             	mov    %r8,%rax
    8c97:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8c9e:	0f 82 b9 05 00 00    	jb     925d <f12+0x15dd>
    8ca4:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8cab:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8cb2:	73 07                	jae    8cbb <f12+0x103b>
    8cb4:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8cbb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8cbf:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8cc4:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8ccb:	00 
    8ccc:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8cd3:	00 
    8cd4:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8cd9:	4d 89 2f             	mov    %r13,(%r15)
    8cdc:	4c 89 f8             	mov    %r15,%rax
    8cdf:	4d 89 fe             	mov    %r15,%r14
    8ce2:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8ce6:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8ceb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8cf2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8cf9:	48 c1 e2 10          	shl    $0x10,%rdx
    8cfd:	48 39 d0             	cmp    %rdx,%rax
    8d00:	0f 83 0a ff ff ff    	jae    8c10 <f12+0xf90>
    8d06:	48 89 c2             	mov    %rax,%rdx
    8d09:	48 c1 ea 10          	shr    $0x10,%rdx
    8d0d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8d11:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8d18:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8d1c:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8d20:	4d 85 ff             	test   %r15,%r15
    8d23:	0f 84 e7 fe ff ff    	je     8c10 <f12+0xf90>
    8d29:	0f b6 32             	movzbl (%rdx),%esi
    8d2c:	40 80 fe 02          	cmp    $0x2,%sil
    8d30:	0f 84 da 04 00 00    	je     9210 <f12+0x1590>
    8d36:	40 80 fe 01          	cmp    $0x1,%sil
    8d3a:	0f 85 d0 fe ff ff    	jne    8c10 <f12+0xf90>
    8d40:	8b 72 18             	mov    0x18(%rdx),%esi
    8d43:	0f b7 c0             	movzwl %ax,%eax
    8d46:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d49:	48 0f af c6          	imul   %rsi,%rax
    8d4d:	48 c1 e8 20          	shr    $0x20,%rax
    8d51:	48 39 d0             	cmp    %rdx,%rax
    8d54:	0f 83 b6 fe ff ff    	jae    8c10 <f12+0xf90>
    8d5a:	49 01 c7             	add    %rax,%r15
    8d5d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8d61:	0f 84 c9 04 00 00    	je     9230 <f12+0x15b0>
    8d67:	41 c6 07 01          	movb   $0x1,(%r15)
    8d6b:	48 85 ed             	test   %rbp,%rbp
    8d6e:	0f 85 a5 fe ff ff    	jne    8c19 <f12+0xf99>
    8d74:	e9 07 fe ff ff       	jmp    8b80 <f12+0xf00>
    8d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d80:	66 85 c0             	test   %ax,%ax
    8d83:	0f 84 9d fa ff ff    	je     8826 <f12+0xba6>
    8d89:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8d8f:	0f 84 14 03 00 00    	je     90a9 <f12+0x1429>
    8d95:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8d9a:	31 ed                	xor    %ebp,%ebp
    8d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    8da0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8da4:	48 89 ea             	mov    %rbp,%rdx
    8da7:	48 83 c5 01          	add    $0x1,%rbp
    8dab:	48 85 c0             	test   %rax,%rax
    8dae:	75 f0                	jne    8da0 <f12+0x1120>
    8db0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8db7:	ff ff 1f 
    8dba:	48 39 e8             	cmp    %rbp,%rax
    8dbd:	0f 82 d0 04 00 00    	jb     9293 <f12+0x1613>
    8dc3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8dca:	00 
    8dcb:	be 02 00 00 00       	mov    $0x2,%esi
    8dd0:	e8 bb ce ff ff       	call   5c90 <fwp_heap_alloc>
    8dd5:	49 39 ef             	cmp    %rbp,%r15
    8dd8:	49 89 c4             	mov    %rax,%r12
    8ddb:	48 89 c2             	mov    %rax,%rdx
    8dde:	49 0f 46 ef          	cmovbe %r15,%rbp
    8de2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8de7:	0f 1f 00             	nopl   (%rax)
    8dea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8df1:	00 00 00 00 
    8df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dfc:	00 00 00 00 
    8e00:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8e04:	48 83 c2 08          	add    $0x8,%rdx
    8e08:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8e0c:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e10:	48 85 c0             	test   %rax,%rax
    8e13:	75 eb                	jne    8e00 <f12+0x1180>
    8e15:	48 85 ed             	test   %rbp,%rbp
    8e18:	0f 84 9d 02 00 00    	je     90bb <f12+0x143b>
    8e1e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    8e25:	00 
    8e26:	e9 23 fa ff ff       	jmp    884e <f12+0xbce>
    8e2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e30:	66 85 c0             	test   %ax,%ax
    8e33:	0f 84 c0 f8 ff ff    	je     86f9 <f12+0xa79>
    8e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e40:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e47:	ff ff 1f 
    8e4a:	4c 39 e8             	cmp    %r13,%rax
    8e4d:	0f 82 28 04 00 00    	jb     927b <f12+0x15fb>
    8e53:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    8e5a:	00 
    8e5b:	be 01 00 00 00       	mov    $0x1,%esi
    8e60:	e8 2b ce ff ff       	call   5c90 <fwp_heap_alloc>
    8e65:	4c 89 28             	mov    %r13,(%rax)
    8e68:	48 8b 15 29 8d 01 00 	mov    0x18d29(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    8e6f:	48 89 c3             	mov    %rax,%rbx
    8e72:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    8e77:	48 2b 05 f2 8c 01 00 	sub    0x18cf2(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8e7e:	48 c1 e2 10          	shl    $0x10,%rdx
    8e82:	48 39 d0             	cmp    %rdx,%rax
    8e85:	73 57                	jae    8ede <f12+0x125e>
    8e87:	48 89 c2             	mov    %rax,%rdx
    8e8a:	48 c1 ea 10          	shr    $0x10,%rdx
    8e8e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e92:	48 8b 15 1f 8d 01 00 	mov    0x18d1f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8e99:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e9d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8ea1:	4d 85 ff             	test   %r15,%r15
    8ea4:	74 38                	je     8ede <f12+0x125e>
    8ea6:	0f b6 0a             	movzbl (%rdx),%ecx
    8ea9:	80 f9 02             	cmp    $0x2,%cl
    8eac:	0f 84 16 02 00 00    	je     90c8 <f12+0x1448>
    8eb2:	80 f9 01             	cmp    $0x1,%cl
    8eb5:	75 27                	jne    8ede <f12+0x125e>
    8eb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8eba:	0f b7 c0             	movzwl %ax,%eax
    8ebd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ec0:	48 0f af c1          	imul   %rcx,%rax
    8ec4:	48 c1 e8 20          	shr    $0x20,%rax
    8ec8:	48 39 d0             	cmp    %rdx,%rax
    8ecb:	73 11                	jae    8ede <f12+0x125e>
    8ecd:	49 01 c7             	add    %rax,%r15
    8ed0:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8ed4:	0f 84 ad 02 00 00    	je     9187 <f12+0x1507>
    8eda:	41 c6 07 01          	movb   $0x1,(%r15)
    8ede:	4c 89 e7             	mov    %r12,%rdi
    8ee1:	e9 26 f8 ff ff       	jmp    870c <f12+0xa8c>
    8ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8eed:	00 00 00 
    8ef0:	48 89 d7             	mov    %rdx,%rdi
    8ef3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    8ef8:	e8 53 c6 ff ff       	call   5550 <fwp_rc_forget_slot>
    8efd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f02:	e9 75 fb ff ff       	jmp    8a7c <f12+0xdfc>
    8f07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f0e:	00 00 
    8f10:	48 8d 3d c9 dd ff ff 	lea    -0x2237(%rip),%rdi        # 6ce0 <fwp_tape_finish>
    8f17:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8f1d:	e8 6e 2e 00 00       	call   bd90 <atexit>
    8f22:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8f28:	85 c0                	test   %eax,%eax
    8f2a:	75 5b                	jne    8f87 <f12+0x1307>
    8f2c:	c7 05 2a 71 00 00 01 	movl   $0x1,0x712a(%rip)        # 10060 <registered_finish.0>
    8f33:	00 00 00 
    8f36:	e9 7b ee ff ff       	jmp    7db6 <f12+0x136>
    8f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f40:	66 85 c0             	test   %ax,%ax
    8f43:	0f 85 1b ee ff ff    	jne    7d64 <f12+0xe4>
    8f49:	e9 02 ee ff ff       	jmp    7d50 <f12+0xd0>
    8f4e:	66 90                	xchg   %ax,%ax
    8f50:	49 89 ec             	mov    %rbp,%r12
    8f53:	4c 39 f5             	cmp    %r14,%rbp
    8f56:	0f 8f a1 f4 ff ff    	jg     83fd <f12+0x77d>
    8f5c:	4d 85 e4             	test   %r12,%r12
    8f5f:	0f 84 13 f5 ff ff    	je     8478 <f12+0x7f8>
    8f65:	48 85 db             	test   %rbx,%rbx
    8f68:	0f 85 01 f5 ff ff    	jne    846f <f12+0x7ef>
    8f6e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    8f75:	00 
    8f76:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8f7b:	48 89 05 d6 94 01 00 	mov    %rax,0x194d6(%rip)        # 22458 <fwp_cleanups>
    8f82:	e8 e9 c0 ff ff       	call   5070 <fwp_tape_buffers_release>
    8f87:	48 8b 0d b2 70 00 00 	mov    0x70b2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    8f8e:	ba 13 00 00 00       	mov    $0x13,%edx
    8f93:	be 01 00 00 00       	mov    $0x1,%esi
    8f98:	48 8d 3d 69 30 00 00 	lea    0x3069(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    8f9f:	e8 dc a6 ff ff       	call   3680 <fwrite@plt>
    8fa4:	31 ff                	xor    %edi,%edi
    8fa6:	e8 15 a6 ff ff       	call   35c0 <fflush@plt>
    8fab:	bf 66 00 00 00       	mov    $0x66,%edi
    8fb0:	e8 eb a6 ff ff       	call   36a0 <_Exit@plt>
    8fb5:	0f 1f 00             	nopl   (%rax)
    8fb8:	66 85 c0             	test   %ax,%ax
    8fbb:	0f 85 8d f6 ff ff    	jne    864e <f12+0x9ce>
    8fc1:	e9 7c f6 ff ff       	jmp    8642 <f12+0x9c2>
    8fc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fcd:	00 00 00 
    8fd0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8fd5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8fda:	e9 a1 fb ff ff       	jmp    8b80 <f12+0xf00>
    8fdf:	90                   	nop
    8fe0:	66 0f 6f 0d b8 70 01 	movdqa 0x170b8(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    8fe7:	00 
    8fe8:	48 c7 05 95 70 01 00 	movq   $0x0,0x17095(%rip)        # 20088 <fwp_tape_cached_bytes>
    8fef:	00 00 00 00 
    8ff3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    8ff8:	48 8b 05 c1 70 01 00 	mov    0x170c1(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    8fff:	66 0f 6f 0d a9 70 01 	movdqa 0x170a9(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    9006:	00 
    9007:	49 89 46 40          	mov    %rax,0x40(%r14)
    900b:	48 8b 05 b6 70 01 00 	mov    0x170b6(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    9012:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9017:	66 0f ef c9          	pxor   %xmm1,%xmm1
    901b:	49 89 46 18          	mov    %rax,0x18(%r14)
    901f:	48 8b 05 aa 70 01 00 	mov    0x170aa(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    9026:	0f 29 0d 73 70 01 00 	movaps %xmm1,0x17073(%rip)        # 200a0 <fwp_tape_workspace>
    902d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9031:	0f 29 0d 78 70 01 00 	movaps %xmm1,0x17078(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    9038:	48 c7 05 8d 70 01 00 	movq   $0x0,0x1708d(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    903f:	00 00 00 00 
    9043:	0f 29 0d 76 70 01 00 	movaps %xmm1,0x17076(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    904a:	e9 8d ee ff ff       	jmp    7edc <f12+0x25c>
    904f:	90                   	nop
    9050:	48 85 db             	test   %rbx,%rbx
    9053:	0f 84 15 ff ff ff    	je     8f6e <f12+0x12ee>
    9059:	4d 89 e6             	mov    %r12,%r14
    905c:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9063:	00 
    9064:	31 f6                	xor    %esi,%esi
    9066:	48 89 df             	mov    %rbx,%rdi
    9069:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    906e:	49 29 ee             	sub    %rbp,%r14
    9071:	e8 4a a4 ff ff       	call   34c0 <memset@plt>
    9076:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    907b:	e9 0d f4 ff ff       	jmp    848d <f12+0x80d>
    9080:	49 89 ec             	mov    %rbp,%r12
    9083:	e9 75 f3 ff ff       	jmp    83fd <f12+0x77d>
    9088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    908f:	00 
    9090:	4c 8d 2c 1b          	lea    (%rbx,%rbx,1),%r13
    9094:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9099:	49 39 c5             	cmp    %rax,%r13
    909c:	4c 0f 4f e8          	cmovg  %rax,%r13
    90a0:	49 6b f5 68          	imul   $0x68,%r13,%rsi
    90a4:	e9 88 ed ff ff       	jmp    7e31 <f12+0x1b1>
    90a9:	be 02 00 00 00       	mov    $0x2,%esi
    90ae:	bf 08 00 00 00       	mov    $0x8,%edi
    90b3:	e8 d8 cb ff ff       	call   5c90 <fwp_heap_alloc>
    90b8:	49 89 c4             	mov    %rax,%r12
    90bb:	45 31 f6             	xor    %r14d,%r14d
    90be:	e9 bd fa ff ff       	jmp    8b80 <f12+0xf00>
    90c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90c8:	66 85 c0             	test   %ax,%ax
    90cb:	0f 85 0d fe ff ff    	jne    8ede <f12+0x125e>
    90d1:	e9 fa fd ff ff       	jmp    8ed0 <f12+0x1250>
    90d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90dd:	00 00 00 
    90e0:	4d 85 e4             	test   %r12,%r12
    90e3:	0f 85 8e ef ff ff    	jne    8077 <f12+0x3f7>
    90e9:	e9 11 f0 ff ff       	jmp    80ff <f12+0x47f>
    90ee:	66 90                	xchg   %ax,%ax
    90f0:	be 08 00 00 00       	mov    $0x8,%esi
    90f5:	4c 89 f7             	mov    %r14,%rdi
    90f8:	e8 23 a4 ff ff       	call   3520 <calloc@plt>
    90fd:	48 89 c3             	mov    %rax,%rbx
    9100:	e9 51 f3 ff ff       	jmp    8456 <f12+0x7d6>
    9105:	31 ff                	xor    %edi,%edi
    9107:	e8 44 b1 ff ff       	call   4250 <descent_phase_step>
    910c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9110:	e9 91 ec ff ff       	jmp    7da6 <f12+0x126>
    9115:	48 8b 0b             	mov    (%rbx),%rcx
    9118:	48 85 c9             	test   %rcx,%rcx
    911b:	78 8c                	js     90a9 <f12+0x1429>
    911d:	48 8b 35 74 8a 01 00 	mov    0x18a74(%rip),%rsi        # 21b98 <fwp_heap+0x13d8>
    9124:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9129:	48 2b 05 40 8a 01 00 	sub    0x18a40(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9130:	48 c1 e6 10          	shl    $0x10,%rsi
    9134:	48 39 f0             	cmp    %rsi,%rax
    9137:	0f 83 6c ff ff ff    	jae    90a9 <f12+0x1429>
    913d:	48 89 c6             	mov    %rax,%rsi
    9140:	48 c1 ee 10          	shr    $0x10,%rsi
    9144:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9148:	48 8b 35 69 8a 01 00 	mov    0x18a69(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    914f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9153:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9157:	48 85 ff             	test   %rdi,%rdi
    915a:	0f 84 49 ff ff ff    	je     90a9 <f12+0x1429>
    9160:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9165:	49 89 cf             	mov    %rcx,%r15
    9168:	e9 87 f6 ff ff       	jmp    87f4 <f12+0xb74>
    916d:	4c 89 f7             	mov    %r14,%rdi
    9170:	e8 db c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    9175:	e9 f4 ee ff ff       	jmp    806e <f12+0x3ee>
    917a:	48 89 df             	mov    %rbx,%rdi
    917d:	e8 ce c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    9182:	e9 c4 f4 ff ff       	jmp    864b <f12+0x9cb>
    9187:	4c 89 ff             	mov    %r15,%rdi
    918a:	e8 c1 c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    918f:	e9 46 fd ff ff       	jmp    8eda <f12+0x125a>
    9194:	e8 97 c2 ff ff       	call   5430 <fwp_rc_wide_dup>
    9199:	e9 c6 eb ff ff       	jmp    7d64 <f12+0xe4>
    919e:	4d 89 e6             	mov    %r12,%r14
    91a1:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    91a8:	00 
    91a9:	31 f6                	xor    %esi,%esi
    91ab:	48 89 df             	mov    %rbx,%rdi
    91ae:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    91b3:	49 29 ee             	sub    %rbp,%r14
    91b6:	e8 05 a3 ff ff       	call   34c0 <memset@plt>
    91bb:	e9 c5 f2 ff ff       	jmp    8485 <f12+0x805>
    91c0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    91c4:	4d 85 ff             	test   %r15,%r15
    91c7:	74 1f                	je     91e8 <f12+0x1568>
    91c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    91cd:	4c 29 fa             	sub    %r15,%rdx
    91d0:	4c 39 c2             	cmp    %r8,%rdx
    91d3:	72 13                	jb     91e8 <f12+0x1568>
    91d5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    91d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    91dd:	e9 7b fa ff ff       	jmp    8c5d <f12+0xfdd>
    91e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91e8:	31 f6                	xor    %esi,%esi
    91ea:	bf 18 00 00 00       	mov    $0x18,%edi
    91ef:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    91f5:	e8 96 ca ff ff       	call   5c90 <fwp_heap_alloc>
    91fa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9200:	49 89 c7             	mov    %rax,%r15
    9203:	e9 cc fa ff ff       	jmp    8cd4 <f12+0x1054>
    9208:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    920f:	00 
    9210:	66 85 c0             	test   %ax,%ax
    9213:	0f 85 f7 f9 ff ff    	jne    8c10 <f12+0xf90>
    9219:	41 80 3f ff          	cmpb   $0xff,(%r15)
    921d:	0f 85 44 fb ff ff    	jne    8d67 <f12+0x10e7>
    9223:	66 90                	xchg   %ax,%ax
    9225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    922c:	00 00 00 00 
    9230:	4c 89 ff             	mov    %r15,%rdi
    9233:	e8 18 c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    9238:	e9 2a fb ff ff       	jmp    8d67 <f12+0x10e7>
    923d:	45 31 ff             	xor    %r15d,%r15d
    9240:	e9 14 f7 ff ff       	jmp    8959 <f12+0xcd9>
    9245:	48 8d 3d 64 36 00 00 	lea    0x3664(%rip),%rdi        # c8b0 <_IO_stdin_used+0x8b0>
    924c:	e8 9f b1 ff ff       	call   43f0 <fwp_trap>
    9251:	48 8d 3d 0f 2f 00 00 	lea    0x2f0f(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    9258:	e8 93 b1 ff ff       	call   43f0 <fwp_trap>
    925d:	e8 4e aa ff ff       	call   3cb0 <fwp_heap_oom>
    9262:	48 8d 3d 4f 37 00 00 	lea    0x374f(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    9269:	e8 82 b1 ff ff       	call   43f0 <fwp_trap>
    926e:	e8 8d a4 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9273:	45 31 e4             	xor    %r12d,%r12d
    9276:	e9 40 fe ff ff       	jmp    90bb <f12+0x143b>
    927b:	48 8d 3d 36 2f 00 00 	lea    0x2f36(%rip),%rdi        # c1b8 <_IO_stdin_used+0x1b8>
    9282:	e8 69 b1 ff ff       	call   43f0 <fwp_trap>
    9287:	48 8d 3d 02 2f 00 00 	lea    0x2f02(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    928e:	e8 5d b1 ff ff       	call   43f0 <fwp_trap>
    9293:	48 8d 3d 10 2f 00 00 	lea    0x2f10(%rip),%rdi        # c1aa <_IO_stdin_used+0x1aa>
    929a:	e8 51 b1 ff ff       	call   43f0 <fwp_trap>
    929f:	e8 bc a1 ff ff       	call   3460 <__stack_chk_fail@plt>
    92a4:	48 8d 3d 4d 36 00 00 	lea    0x364d(%rip),%rdi        # c8f8 <_IO_stdin_used+0x8f8>
    92ab:	e8 40 b1 ff ff       	call   43f0 <fwp_trap>
    92b0:	48 8d 3d d1 36 00 00 	lea    0x36d1(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    92b7:	e8 34 b1 ff ff       	call   43f0 <fwp_trap>
    92bc:	48 8d 3d 95 36 00 00 	lea    0x3695(%rip),%rdi        # c958 <_IO_stdin_used+0x958>
    92c3:	e8 28 b1 ff ff       	call   43f0 <fwp_trap>
    92c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92cf:	00 

00000000000092d0 <fwp_owned_entry12>:
    92d0:	f3 0f 1e fa          	endbr64
    92d4:	48 8b 3f             	mov    (%rdi),%rdi
    92d7:	e9 a4 e9 ff ff       	jmp    7c80 <f12>
    92dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000092e0 <e12>:
    92e0:	f3 0f 1e fa          	endbr64
    92e4:	53                   	push   %rbx
    92e5:	48 8b 1f             	mov    (%rdi),%rbx
    92e8:	48 89 df             	mov    %rbx,%rdi
    92eb:	e8 20 d3 ff ff       	call   6610 <fwp_rc_share>
    92f0:	48 89 df             	mov    %rbx,%rdi
    92f3:	e8 88 e9 ff ff       	call   7c80 <f12>
    92f8:	48 89 c3             	mov    %rax,%rbx
    92fb:	48 89 c7             	mov    %rax,%rdi
    92fe:	e8 0d d3 ff ff       	call   6610 <fwp_rc_share>
    9303:	48 89 d8             	mov    %rbx,%rax
    9306:	5b                   	pop    %rbx
    9307:	c3                   	ret
    9308:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    930f:	00 

0000000000009310 <fwp_drop2>:
    9310:	48 8b 0d 81 88 01 00 	mov    0x18881(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    9317:	48 89 f8             	mov    %rdi,%rax
    931a:	48 2b 05 4f 88 01 00 	sub    0x1884f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9321:	48 c1 e1 10          	shl    $0x10,%rcx
    9325:	48 39 c8             	cmp    %rcx,%rax
    9328:	0f 83 42 01 00 00    	jae    9470 <fwp_drop2+0x160>
    932e:	48 83 ec 18          	sub    $0x18,%rsp
    9332:	48 89 fa             	mov    %rdi,%rdx
    9335:	4c 8d 05 84 74 01 00 	lea    0x17484(%rip),%r8        # 207c0 <fwp_heap>
    933c:	48 89 c1             	mov    %rax,%rcx
    933f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9346:	48 c1 e9 10          	shr    $0x10,%rcx
    934a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    934e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9352:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9356:	48 85 c9             	test   %rcx,%rcx
    9359:	74 40                	je     939b <fwp_drop2+0x8b>
    935b:	0f b6 3e             	movzbl (%rsi),%edi
    935e:	40 80 ff 02          	cmp    $0x2,%dil
    9362:	74 3c                	je     93a0 <fwp_drop2+0x90>
    9364:	40 80 ff 01          	cmp    $0x1,%dil
    9368:	75 31                	jne    939b <fwp_drop2+0x8b>
    936a:	8b 7e 18             	mov    0x18(%rsi),%edi
    936d:	0f b7 c0             	movzwl %ax,%eax
    9370:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9373:	48 0f af c7          	imul   %rdi,%rax
    9377:	48 c1 e8 20          	shr    $0x20,%rax
    937b:	48 39 f0             	cmp    %rsi,%rax
    937e:	73 1b                	jae    939b <fwp_drop2+0x8b>
    9380:	48 01 c1             	add    %rax,%rcx
    9383:	0f b6 01             	movzbl (%rcx),%eax
    9386:	84 c0                	test   %al,%al
    9388:	74 11                	je     939b <fwp_drop2+0x8b>
    938a:	3c 01                	cmp    $0x1,%al
    938c:	74 22                	je     93b0 <fwp_drop2+0xa0>
    938e:	3c ff                	cmp    $0xff,%al
    9390:	0f 84 0a 01 00 00    	je     94a0 <fwp_drop2+0x190>
    9396:	83 e8 01             	sub    $0x1,%eax
    9399:	88 01                	mov    %al,(%rcx)
    939b:	48 83 c4 18          	add    $0x18,%rsp
    939f:	c3                   	ret
    93a0:	66 85 c0             	test   %ax,%ax
    93a3:	74 de                	je     9383 <fwp_drop2+0x73>
    93a5:	48 83 c4 18          	add    $0x18,%rsp
    93a9:	c3                   	ret
    93aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93b0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    93b4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    93bb:	48 89 f8             	mov    %rdi,%rax
    93be:	48 c1 e1 10          	shl    $0x10,%rcx
    93c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    93c9:	48 39 c8             	cmp    %rcx,%rax
    93cc:	73 62                	jae    9430 <fwp_drop2+0x120>
    93ce:	48 89 c1             	mov    %rax,%rcx
    93d1:	48 c1 e9 10          	shr    $0x10,%rcx
    93d5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    93d9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    93dd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    93e1:	48 85 c9             	test   %rcx,%rcx
    93e4:	74 4a                	je     9430 <fwp_drop2+0x120>
    93e6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    93ea:	41 80 f9 02          	cmp    $0x2,%r9b
    93ee:	0f 84 9c 00 00 00    	je     9490 <fwp_drop2+0x180>
    93f4:	41 80 f9 01          	cmp    $0x1,%r9b
    93f8:	75 36                	jne    9430 <fwp_drop2+0x120>
    93fa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    93fe:	0f b7 c0             	movzwl %ax,%eax
    9401:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9404:	49 0f af c1          	imul   %r9,%rax
    9408:	48 c1 e8 20          	shr    $0x20,%rax
    940c:	48 39 f0             	cmp    %rsi,%rax
    940f:	73 1f                	jae    9430 <fwp_drop2+0x120>
    9411:	48 01 c1             	add    %rax,%rcx
    9414:	0f b6 01             	movzbl (%rcx),%eax
    9417:	84 c0                	test   %al,%al
    9419:	74 15                	je     9430 <fwp_drop2+0x120>
    941b:	3c 01                	cmp    $0x1,%al
    941d:	74 59                	je     9478 <fwp_drop2+0x168>
    941f:	3c ff                	cmp    $0xff,%al
    9421:	0f 84 ff 00 00 00    	je     9526 <fwp_drop2+0x216>
    9427:	83 e8 01             	sub    $0x1,%eax
    942a:	88 01                	mov    %al,(%rcx)
    942c:	0f 1f 40 00          	nopl   0x0(%rax)
    9430:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9434:	48 89 d7             	mov    %rdx,%rdi
    9437:	48 89 0c 24          	mov    %rcx,(%rsp)
    943b:	e8 50 d2 ff ff       	call   6690 <fwp_rc_free_arr>
    9440:	4c 8d 05 79 73 01 00 	lea    0x17379(%rip),%r8        # 207c0 <fwp_heap>
    9447:	48 8b 04 24          	mov    (%rsp),%rax
    944b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9452:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9459:	48 c1 e2 10          	shl    $0x10,%rdx
    945d:	48 39 d0             	cmp    %rdx,%rax
    9460:	0f 83 35 ff ff ff    	jae    939b <fwp_drop2+0x8b>
    9466:	48 8b 14 24          	mov    (%rsp),%rdx
    946a:	e9 cd fe ff ff       	jmp    933c <fwp_drop2+0x2c>
    946f:	90                   	nop
    9470:	c3                   	ret
    9471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9478:	48 89 14 24          	mov    %rdx,(%rsp)
    947c:	e8 0f d2 ff ff       	call   6690 <fwp_rc_free_arr>
    9481:	48 8b 14 24          	mov    (%rsp),%rdx
    9485:	eb a9                	jmp    9430 <fwp_drop2+0x120>
    9487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    948e:	00 00 
    9490:	66 85 c0             	test   %ax,%ax
    9493:	75 9b                	jne    9430 <fwp_drop2+0x120>
    9495:	e9 7a ff ff ff       	jmp    9414 <fwp_drop2+0x104>
    949a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94a0:	48 89 c8             	mov    %rcx,%rax
    94a3:	48 c1 e8 11          	shr    $0x11,%rax
    94a7:	48 31 c8             	xor    %rcx,%rax
    94aa:	48 89 c2             	mov    %rax,%rdx
    94ad:	48 c1 ea 09          	shr    $0x9,%rdx
    94b1:	48 31 d0             	xor    %rdx,%rax
    94b4:	0f b6 d0             	movzbl %al,%edx
    94b7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    94be:	00 
    94bf:	48 85 c0             	test   %rax,%rax
    94c2:	75 29                	jne    94ed <fwp_drop2+0x1dd>
    94c4:	e9 e3 00 00 00       	jmp    95ac <fwp_drop2+0x29c>
    94c9:	90                   	nop
    94ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94d1:	00 00 00 00 
    94d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94dc:	00 00 00 00 
    94e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    94e4:	48 85 c0             	test   %rax,%rax
    94e7:	0f 84 bf 00 00 00    	je     95ac <fwp_drop2+0x29c>
    94ed:	48 89 c2             	mov    %rax,%rdx
    94f0:	48 39 08             	cmp    %rcx,(%rax)
    94f3:	75 eb                	jne    94e0 <fwp_drop2+0x1d0>
    94f5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    94f9:	48 83 ea 01          	sub    $0x1,%rdx
    94fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9501:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9508:	0f 85 8d fe ff ff    	jne    939b <fwp_drop2+0x8b>
    950e:	48 89 cf             	mov    %rcx,%rdi
    9511:	48 89 0c 24          	mov    %rcx,(%rsp)
    9515:	e8 36 c0 ff ff       	call   5550 <fwp_rc_forget_slot>
    951a:	48 8b 0c 24          	mov    (%rsp),%rcx
    951e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9521:	e9 75 fe ff ff       	jmp    939b <fwp_drop2+0x8b>
    9526:	48 89 ce             	mov    %rcx,%rsi
    9529:	48 c1 ee 11          	shr    $0x11,%rsi
    952d:	48 31 ce             	xor    %rcx,%rsi
    9530:	48 89 f0             	mov    %rsi,%rax
    9533:	48 c1 e8 09          	shr    $0x9,%rax
    9537:	48 31 c6             	xor    %rax,%rsi
    953a:	40 0f b6 f6          	movzbl %sil,%esi
    953e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9545:	00 
    9546:	48 85 c0             	test   %rax,%rax
    9549:	75 1e                	jne    9569 <fwp_drop2+0x259>
    954b:	eb 5f                	jmp    95ac <fwp_drop2+0x29c>
    954d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9554:	00 
    9555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    955c:	00 00 00 00 
    9560:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9564:	48 85 c0             	test   %rax,%rax
    9567:	74 43                	je     95ac <fwp_drop2+0x29c>
    9569:	48 89 c6             	mov    %rax,%rsi
    956c:	48 39 08             	cmp    %rcx,(%rax)
    956f:	75 ef                	jne    9560 <fwp_drop2+0x250>
    9571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9575:	48 83 ee 01          	sub    $0x1,%rsi
    9579:	48 89 70 08          	mov    %rsi,0x8(%rax)
    957d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9584:	0f 85 a6 fe ff ff    	jne    9430 <fwp_drop2+0x120>
    958a:	48 89 cf             	mov    %rcx,%rdi
    958d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9592:	48 89 0c 24          	mov    %rcx,(%rsp)
    9596:	e8 b5 bf ff ff       	call   5550 <fwp_rc_forget_slot>
    959b:	48 8b 0c 24          	mov    (%rsp),%rcx
    959f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    95a4:	c6 01 fe             	movb   $0xfe,(%rcx)
    95a7:	e9 84 fe ff ff       	jmp    9430 <fwp_drop2+0x120>
    95ac:	48 8d 3d d5 32 00 00 	lea    0x32d5(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    95b3:	e8 38 ae ff ff       	call   43f0 <fwp_trap>
    95b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95bf:	00 

00000000000095c0 <fwp_arg_drop23>:
    95c0:	f3 0f 1e fa          	endbr64
    95c4:	85 f6                	test   %esi,%esi
    95c6:	75 04                	jne    95cc <fwp_arg_drop23+0xc>
    95c8:	85 d2                	test   %edx,%edx
    95ca:	75 04                	jne    95d0 <fwp_arg_drop23+0x10>
    95cc:	c3                   	ret
    95cd:	0f 1f 00             	nopl   (%rax)
    95d0:	48 8b 3f             	mov    (%rdi),%rdi
    95d3:	e9 38 fd ff ff       	jmp    9310 <fwp_drop2>
    95d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95df:	00 

00000000000095e0 <fwp_caps23>:
    95e0:	f3 0f 1e fa          	endbr64
    95e4:	48 83 ec 18          	sub    $0x18,%rsp
    95e8:	8b 57 04             	mov    0x4(%rdi),%edx
    95eb:	48 89 f8             	mov    %rdi,%rax
    95ee:	85 d2                	test   %edx,%edx
    95f0:	0f 84 9a 00 00 00    	je     9690 <fwp_caps23+0xb0>
    95f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    95fa:	85 f6                	test   %esi,%esi
    95fc:	0f 85 9e 00 00 00    	jne    96a0 <fwp_caps23+0xc0>
    9602:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9607:	e8 04 fd ff ff       	call   9310 <fwp_drop2>
    960c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9611:	48 8b 0d 80 85 01 00 	mov    0x18580(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    9618:	48 89 c2             	mov    %rax,%rdx
    961b:	48 2b 15 4e 85 01 00 	sub    0x1854e(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    9622:	48 c1 e1 10          	shl    $0x10,%rcx
    9626:	48 39 ca             	cmp    %rcx,%rdx
    9629:	73 6d                	jae    9698 <fwp_caps23+0xb8>
    962b:	48 89 d1             	mov    %rdx,%rcx
    962e:	48 c1 e9 10          	shr    $0x10,%rcx
    9632:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9636:	48 8b 0d 7b 85 01 00 	mov    0x1857b(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    963d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9641:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9645:	48 85 f6             	test   %rsi,%rsi
    9648:	74 4e                	je     9698 <fwp_caps23+0xb8>
    964a:	0f b6 39             	movzbl (%rcx),%edi
    964d:	40 80 ff 02          	cmp    $0x2,%dil
    9651:	0f 84 b9 00 00 00    	je     9710 <fwp_caps23+0x130>
    9657:	40 80 ff 01          	cmp    $0x1,%dil
    965b:	75 3b                	jne    9698 <fwp_caps23+0xb8>
    965d:	8b 79 18             	mov    0x18(%rcx),%edi
    9660:	0f b7 d2             	movzwl %dx,%edx
    9663:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9666:	48 0f af d7          	imul   %rdi,%rdx
    966a:	48 c1 ea 20          	shr    $0x20,%rdx
    966e:	48 39 ca             	cmp    %rcx,%rdx
    9671:	73 25                	jae    9698 <fwp_caps23+0xb8>
    9673:	48 01 d6             	add    %rdx,%rsi
    9676:	80 3e 01             	cmpb   $0x1,(%rsi)
    9679:	75 1d                	jne    9698 <fwp_caps23+0xb8>
    967b:	48 89 c7             	mov    %rax,%rdi
    967e:	48 83 c4 18          	add    $0x18,%rsp
    9682:	e9 09 c1 ff ff       	jmp    5790 <fwp_mem_free>
    9687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    968e:	00 00 
    9690:	85 f6                	test   %esi,%esi
    9692:	0f 84 79 ff ff ff    	je     9611 <fwp_caps23+0x31>
    9698:	48 83 c4 18          	add    $0x18,%rsp
    969c:	c3                   	ret
    969d:	0f 1f 00             	nopl   (%rax)
    96a0:	48 8b 05 f1 84 01 00 	mov    0x184f1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    96a7:	48 2b 3d c2 84 01 00 	sub    0x184c2(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    96ae:	48 c1 e0 10          	shl    $0x10,%rax
    96b2:	48 39 c7             	cmp    %rax,%rdi
    96b5:	73 e1                	jae    9698 <fwp_caps23+0xb8>
    96b7:	48 89 f8             	mov    %rdi,%rax
    96ba:	48 c1 e8 10          	shr    $0x10,%rax
    96be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    96c2:	48 8b 05 ef 84 01 00 	mov    0x184ef(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    96c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    96cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    96d1:	48 85 c0             	test   %rax,%rax
    96d4:	74 c2                	je     9698 <fwp_caps23+0xb8>
    96d6:	0f b6 0a             	movzbl (%rdx),%ecx
    96d9:	80 f9 02             	cmp    $0x2,%cl
    96dc:	74 42                	je     9720 <fwp_caps23+0x140>
    96de:	80 f9 01             	cmp    $0x1,%cl
    96e1:	75 b5                	jne    9698 <fwp_caps23+0xb8>
    96e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96e6:	0f b7 ff             	movzwl %di,%edi
    96e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96ec:	48 0f af f9          	imul   %rcx,%rdi
    96f0:	48 c1 ef 20          	shr    $0x20,%rdi
    96f4:	48 39 d7             	cmp    %rdx,%rdi
    96f7:	73 9f                	jae    9698 <fwp_caps23+0xb8>
    96f9:	48 01 f8             	add    %rdi,%rax
    96fc:	0f b6 10             	movzbl (%rax),%edx
    96ff:	84 d2                	test   %dl,%dl
    9701:	74 95                	je     9698 <fwp_caps23+0xb8>
    9703:	80 fa fd             	cmp    $0xfd,%dl
    9706:	77 23                	ja     972b <fwp_caps23+0x14b>
    9708:	83 c2 01             	add    $0x1,%edx
    970b:	88 10                	mov    %dl,(%rax)
    970d:	eb 89                	jmp    9698 <fwp_caps23+0xb8>
    970f:	90                   	nop
    9710:	66 85 d2             	test   %dx,%dx
    9713:	0f 85 7f ff ff ff    	jne    9698 <fwp_caps23+0xb8>
    9719:	e9 58 ff ff ff       	jmp    9676 <fwp_caps23+0x96>
    971e:	66 90                	xchg   %ax,%ax
    9720:	66 85 ff             	test   %di,%di
    9723:	0f 85 6f ff ff ff    	jne    9698 <fwp_caps23+0xb8>
    9729:	eb d1                	jmp    96fc <fwp_caps23+0x11c>
    972b:	48 89 c7             	mov    %rax,%rdi
    972e:	48 83 c4 18          	add    $0x18,%rsp
    9732:	e9 f9 bc ff ff       	jmp    5430 <fwp_rc_wide_dup>
    9737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    973e:	00 00 

0000000000009740 <f23>:
    9740:	41 57                	push   %r15
    9742:	41 56                	push   %r14
    9744:	41 55                	push   %r13
    9746:	41 54                	push   %r12
    9748:	55                   	push   %rbp
    9749:	53                   	push   %rbx
    974a:	48 83 ec 38          	sub    $0x38,%rsp
    974e:	48 8b 15 43 84 01 00 	mov    0x18443(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9755:	48 8b 0d 14 84 01 00 	mov    0x18414(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    975c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    9763:	00 00 
    9765:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    976a:	49 89 fd             	mov    %rdi,%r13
    976d:	48 c1 e2 10          	shl    $0x10,%rdx
    9771:	48 85 ff             	test   %rdi,%rdi
    9774:	0f 84 0c 03 00 00    	je     9a86 <f23+0x346>
    977a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    977e:	48 89 d8             	mov    %rbx,%rax
    9781:	48 29 c8             	sub    %rcx,%rax
    9784:	48 39 d0             	cmp    %rdx,%rax
    9787:	0f 83 c3 03 00 00    	jae    9b50 <f23+0x410>
    978d:	48 89 c2             	mov    %rax,%rdx
    9790:	48 c1 ea 10          	shr    $0x10,%rdx
    9794:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9798:	48 8b 15 19 84 01 00 	mov    0x18419(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    979f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97a3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    97a7:	48 85 ff             	test   %rdi,%rdi
    97aa:	0f 84 a0 03 00 00    	je     9b50 <f23+0x410>
    97b0:	0f b6 0a             	movzbl (%rdx),%ecx
    97b3:	80 f9 02             	cmp    $0x2,%cl
    97b6:	0f 84 a4 02 00 00    	je     9a60 <f23+0x320>
    97bc:	80 f9 01             	cmp    $0x1,%cl
    97bf:	75 24                	jne    97e5 <f23+0xa5>
    97c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97c4:	0f b7 c0             	movzwl %ax,%eax
    97c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97ca:	48 0f af c1          	imul   %rcx,%rax
    97ce:	48 c1 e8 20          	shr    $0x20,%rax
    97d2:	48 39 d0             	cmp    %rdx,%rax
    97d5:	73 0e                	jae    97e5 <f23+0xa5>
    97d7:	48 01 c7             	add    %rax,%rdi
    97da:	0f b6 07             	movzbl (%rdi),%eax
    97dd:	84 c0                	test   %al,%al
    97df:	0f 85 1b 03 00 00    	jne    9b00 <f23+0x3c0>
    97e5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    97ea:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    97ee:	ba 01 00 00 00       	mov    $0x1,%edx
    97f3:	48 85 db             	test   %rbx,%rbx
    97f6:	74 15                	je     980d <f23+0xcd>
    97f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97ff:	00 
    9800:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9804:	48 83 c2 01          	add    $0x1,%rdx
    9808:	48 85 db             	test   %rbx,%rbx
    980b:	75 f3                	jne    9800 <f23+0xc0>
    980d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9812:	48 85 c0             	test   %rax,%rax
    9815:	0f 84 65 03 00 00    	je     9b80 <f23+0x440>
    981b:	31 db                	xor    %ebx,%ebx
    981d:	0f 1f 00             	nopl   (%rax)
    9820:	48 8b 40 10          	mov    0x10(%rax),%rax
    9824:	48 83 c3 01          	add    $0x1,%rbx
    9828:	48 85 c0             	test   %rax,%rax
    982b:	75 f3                	jne    9820 <f23+0xe0>
    982d:	48 39 d3             	cmp    %rdx,%rbx
    9830:	48 0f 47 da          	cmova  %rdx,%rbx
    9834:	48 89 d8             	mov    %rbx,%rax
    9837:	48 c1 e8 3c          	shr    $0x3c,%rax
    983b:	0f 85 e3 03 00 00    	jne    9c24 <f23+0x4e4>
    9841:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9845:	be 02 00 00 00       	mov    $0x2,%esi
    984a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9851:	00 
    9852:	e8 39 c4 ff ff       	call   5c90 <fwp_heap_alloc>
    9857:	48 89 28             	mov    %rbp,(%rax)
    985a:	48 8b 15 37 83 01 00 	mov    0x18337(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9861:	49 89 c4             	mov    %rax,%r12
    9864:	48 2b 05 05 83 01 00 	sub    0x18305(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    986b:	48 c1 e2 10          	shl    $0x10,%rdx
    986f:	48 39 d0             	cmp    %rdx,%rax
    9872:	73 57                	jae    98cb <f23+0x18b>
    9874:	48 89 c2             	mov    %rax,%rdx
    9877:	48 c1 ea 10          	shr    $0x10,%rdx
    987b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    987f:	48 8b 15 32 83 01 00 	mov    0x18332(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9886:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    988a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    988e:	48 85 ed             	test   %rbp,%rbp
    9891:	74 38                	je     98cb <f23+0x18b>
    9893:	0f b6 0a             	movzbl (%rdx),%ecx
    9896:	80 f9 02             	cmp    $0x2,%cl
    9899:	0f 84 a1 02 00 00    	je     9b40 <f23+0x400>
    989f:	80 f9 01             	cmp    $0x1,%cl
    98a2:	75 27                	jne    98cb <f23+0x18b>
    98a4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98a7:	0f b7 c0             	movzwl %ax,%eax
    98aa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98ad:	48 0f af c1          	imul   %rcx,%rax
    98b1:	48 c1 e8 20          	shr    $0x20,%rax
    98b5:	48 39 d0             	cmp    %rdx,%rax
    98b8:	73 11                	jae    98cb <f23+0x18b>
    98ba:	48 01 c5             	add    %rax,%rbp
    98bd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    98c1:	0f 84 29 03 00 00    	je     9bf0 <f23+0x4b0>
    98c7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    98cb:	48 85 db             	test   %rbx,%rbx
    98ce:	74 5d                	je     992d <f23+0x1ed>
    98d0:	48 c1 e3 04          	shl    $0x4,%rbx
    98d4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    98d9:	4c 89 e5             	mov    %r12,%rbp
    98dc:	4d 89 ee             	mov    %r13,%r14
    98df:	4c 01 e3             	add    %r12,%rbx
    98e2:	0f 1f 00             	nopl   (%rax)
    98e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98ec:	00 00 00 00 
    98f0:	49 8b 46 08          	mov    0x8(%r14),%rax
    98f4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    98f8:	48 83 c5 10          	add    $0x10,%rbp
    98fc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9901:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9905:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9909:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    990e:	e8 5d ca ff ff       	call   6370 <w107>
    9913:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9918:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    991c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9920:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9924:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9928:	48 39 eb             	cmp    %rbp,%rbx
    992b:	75 c3                	jne    98f0 <f23+0x1b0>
    992d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9932:	31 db                	xor    %ebx,%ebx
    9934:	e8 d7 f9 ff ff       	call   9310 <fwp_drop2>
    9939:	4c 89 ef             	mov    %r13,%rdi
    993c:	e8 cf f9 ff ff       	call   9310 <fwp_drop2>
    9941:	4d 8b 2c 24          	mov    (%r12),%r13
    9945:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9949:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9950:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9957:	4d 85 ed             	test   %r13,%r13
    995a:	74 3f                	je     999b <f23+0x25b>
    995c:	0f 1f 40 00          	nopl   0x0(%rax)
    9960:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9967:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    996c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    9973:	00 f0 3f 
    9976:	48 83 c3 02          	add    $0x2,%rbx
    997a:	48 89 ce             	mov    %rcx,%rsi
    997d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9983:	e8 68 c6 ff ff       	call   5ff0 <fwp_p_ad_push>
    9988:	4c 39 eb             	cmp    %r13,%rbx
    998b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9991:	48 89 c7             	mov    %rax,%rdi
    9994:	72 ca                	jb     9960 <f23+0x220>
    9996:	66 49 0f 7e c5       	movq   %xmm0,%r13
    999b:	4c 89 e7             	mov    %r12,%rdi
    999e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    99a3:	e8 c8 dd ff ff       	call   7770 <fwp_drop4>
    99a8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    99ad:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    99b2:	31 ff                	xor    %edi,%edi
    99b4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    99b9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    99be:	e8 1d cb ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    99c3:	48 8b 15 ce 81 01 00 	mov    0x181ce(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    99ca:	48 89 c5             	mov    %rax,%rbp
    99cd:	48 2b 05 9c 81 01 00 	sub    0x1819c(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    99d4:	48 c1 e2 10          	shl    $0x10,%rdx
    99d8:	48 39 d0             	cmp    %rdx,%rax
    99db:	73 55                	jae    9a32 <f23+0x2f2>
    99dd:	48 89 c2             	mov    %rax,%rdx
    99e0:	48 c1 ea 10          	shr    $0x10,%rdx
    99e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99e8:	48 8b 15 c9 81 01 00 	mov    0x181c9(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    99ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99f3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    99f7:	48 85 db             	test   %rbx,%rbx
    99fa:	74 36                	je     9a32 <f23+0x2f2>
    99fc:	0f b6 0a             	movzbl (%rdx),%ecx
    99ff:	80 f9 02             	cmp    $0x2,%cl
    9a02:	0f 84 20 01 00 00    	je     9b28 <f23+0x3e8>
    9a08:	80 f9 01             	cmp    $0x1,%cl
    9a0b:	75 25                	jne    9a32 <f23+0x2f2>
    9a0d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a10:	0f b7 c0             	movzwl %ax,%eax
    9a13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a16:	48 0f af c1          	imul   %rcx,%rax
    9a1a:	48 c1 e8 20          	shr    $0x20,%rax
    9a1e:	48 39 d0             	cmp    %rdx,%rax
    9a21:	73 0f                	jae    9a32 <f23+0x2f2>
    9a23:	48 01 c3             	add    %rax,%rbx
    9a26:	80 3b ff             	cmpb   $0xff,(%rbx)
    9a29:	0f 84 b4 01 00 00    	je     9be3 <f23+0x4a3>
    9a2f:	c6 03 01             	movb   $0x1,(%rbx)
    9a32:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9a37:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a3e:	00 00 
    9a40:	0f 85 d9 01 00 00    	jne    9c1f <f23+0x4df>
    9a46:	48 83 c4 38          	add    $0x38,%rsp
    9a4a:	48 89 e8             	mov    %rbp,%rax
    9a4d:	5b                   	pop    %rbx
    9a4e:	5d                   	pop    %rbp
    9a4f:	41 5c                	pop    %r12
    9a51:	41 5d                	pop    %r13
    9a53:	41 5e                	pop    %r14
    9a55:	41 5f                	pop    %r15
    9a57:	c3                   	ret
    9a58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a5f:	00 
    9a60:	66 85 c0             	test   %ax,%ax
    9a63:	0f 85 7c fd ff ff    	jne    97e5 <f23+0xa5>
    9a69:	0f b6 07             	movzbl (%rdi),%eax
    9a6c:	84 c0                	test   %al,%al
    9a6e:	0f 84 71 fd ff ff    	je     97e5 <f23+0xa5>
    9a74:	3c fd                	cmp    $0xfd,%al
    9a76:	0f 87 99 01 00 00    	ja     9c15 <f23+0x4d5>
    9a7c:	83 c0 01             	add    $0x1,%eax
    9a7f:	88 07                	mov    %al,(%rdi)
    9a81:	e9 5f fd ff ff       	jmp    97e5 <f23+0xa5>
    9a86:	48 f7 d9             	neg    %rcx
    9a89:	48 39 d1             	cmp    %rdx,%rcx
    9a8c:	0f 83 ee 00 00 00    	jae    9b80 <f23+0x440>
    9a92:	48 89 c8             	mov    %rcx,%rax
    9a95:	48 c1 e8 10          	shr    $0x10,%rax
    9a99:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9a9d:	48 8b 05 14 81 01 00 	mov    0x18114(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    9aa4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9aa8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9aac:	48 85 ff             	test   %rdi,%rdi
    9aaf:	0f 84 cb 00 00 00    	je     9b80 <f23+0x440>
    9ab5:	0f b6 02             	movzbl (%rdx),%eax
    9ab8:	3c 02                	cmp    $0x2,%al
    9aba:	0f 84 9a 00 00 00    	je     9b5a <f23+0x41a>
    9ac0:	3c 01                	cmp    $0x1,%al
    9ac2:	0f 85 b8 00 00 00    	jne    9b80 <f23+0x440>
    9ac8:	0f b7 c1             	movzwl %cx,%eax
    9acb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ace:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ad1:	48 0f af c1          	imul   %rcx,%rax
    9ad5:	48 c1 e8 20          	shr    $0x20,%rax
    9ad9:	48 39 d0             	cmp    %rdx,%rax
    9adc:	0f 83 9e 00 00 00    	jae    9b80 <f23+0x440>
    9ae2:	48 01 c7             	add    %rax,%rdi
    9ae5:	0f b6 07             	movzbl (%rdi),%eax
    9ae8:	84 c0                	test   %al,%al
    9aea:	0f 84 90 00 00 00    	je     9b80 <f23+0x440>
    9af0:	31 db                	xor    %ebx,%ebx
    9af2:	0f 1f 00             	nopl   (%rax)
    9af5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9afc:	00 00 00 00 
    9b00:	3c fd                	cmp    $0xfd,%al
    9b02:	0f 87 f5 00 00 00    	ja     9bfd <f23+0x4bd>
    9b08:	83 c0 01             	add    $0x1,%eax
    9b0b:	88 07                	mov    %al,(%rdi)
    9b0d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9b12:	31 d2                	xor    %edx,%edx
    9b14:	4d 85 ed             	test   %r13,%r13
    9b17:	0f 85 cd fc ff ff    	jne    97ea <f23+0xaa>
    9b1d:	e9 eb fc ff ff       	jmp    980d <f23+0xcd>
    9b22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b28:	66 85 c0             	test   %ax,%ax
    9b2b:	0f 85 01 ff ff ff    	jne    9a32 <f23+0x2f2>
    9b31:	e9 f0 fe ff ff       	jmp    9a26 <f23+0x2e6>
    9b36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b3d:	00 00 00 
    9b40:	66 85 c0             	test   %ax,%ax
    9b43:	0f 85 82 fd ff ff    	jne    98cb <f23+0x18b>
    9b49:	e9 6f fd ff ff       	jmp    98bd <f23+0x17d>
    9b4e:	66 90                	xchg   %ax,%ax
    9b50:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9b55:	e9 94 fc ff ff       	jmp    97ee <f23+0xae>
    9b5a:	66 85 c9             	test   %cx,%cx
    9b5d:	75 21                	jne    9b80 <f23+0x440>
    9b5f:	0f b6 07             	movzbl (%rdi),%eax
    9b62:	84 c0                	test   %al,%al
    9b64:	74 1a                	je     9b80 <f23+0x440>
    9b66:	3c fd                	cmp    $0xfd,%al
    9b68:	0f 87 c2 00 00 00    	ja     9c30 <f23+0x4f0>
    9b6e:	83 c0 01             	add    $0x1,%eax
    9b71:	88 07                	mov    %al,(%rdi)
    9b73:	66 90                	xchg   %ax,%ax
    9b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b7c:	00 00 00 00 
    9b80:	be 02 00 00 00       	mov    $0x2,%esi
    9b85:	bf 08 00 00 00       	mov    $0x8,%edi
    9b8a:	e8 01 c1 ff ff       	call   5c90 <fwp_heap_alloc>
    9b8f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9b96:	48 8b 15 fb 7f 01 00 	mov    0x17ffb(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9b9d:	49 89 c4             	mov    %rax,%r12
    9ba0:	48 2b 05 c9 7f 01 00 	sub    0x17fc9(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9ba7:	48 c1 e2 10          	shl    $0x10,%rdx
    9bab:	48 39 d0             	cmp    %rdx,%rax
    9bae:	73 57                	jae    9c07 <f23+0x4c7>
    9bb0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9bb7:	00 00 
    9bb9:	48 89 c2             	mov    %rax,%rdx
    9bbc:	48 c1 ea 10          	shr    $0x10,%rdx
    9bc0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bc4:	48 8b 15 ed 7f 01 00 	mov    0x17fed(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9bcb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bcf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9bd3:	48 85 ed             	test   %rbp,%rbp
    9bd6:	0f 84 51 fd ff ff    	je     992d <f23+0x1ed>
    9bdc:	31 db                	xor    %ebx,%ebx
    9bde:	e9 b0 fc ff ff       	jmp    9893 <f23+0x153>
    9be3:	48 89 df             	mov    %rbx,%rdi
    9be6:	e8 65 b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9beb:	e9 3f fe ff ff       	jmp    9a2f <f23+0x2ef>
    9bf0:	48 89 ef             	mov    %rbp,%rdi
    9bf3:	e8 58 b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9bf8:	e9 ca fc ff ff       	jmp    98c7 <f23+0x187>
    9bfd:	e8 2e b8 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c02:	e9 06 ff ff ff       	jmp    9b0d <f23+0x3cd>
    9c07:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9c0e:	00 00 
    9c10:	e9 18 fd ff ff       	jmp    992d <f23+0x1ed>
    9c15:	e8 16 b8 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c1a:	e9 c6 fb ff ff       	jmp    97e5 <f23+0xa5>
    9c1f:	e8 3c 98 ff ff       	call   3460 <__stack_chk_fail@plt>
    9c24:	48 8d 3d 7f 25 00 00 	lea    0x257f(%rip),%rdi        # c1aa <_IO_stdin_used+0x1aa>
    9c2b:	e8 c0 a7 ff ff       	call   43f0 <fwp_trap>
    9c30:	e8 fb b7 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c35:	e9 46 ff ff ff       	jmp    9b80 <f23+0x440>
    9c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009c40 <fwp_owned_entry23>:
    9c40:	f3 0f 1e fa          	endbr64
    9c44:	48 8b 3f             	mov    (%rdi),%rdi
    9c47:	e9 f4 fa ff ff       	jmp    9740 <f23>
    9c4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009c50 <e23>:
    9c50:	f3 0f 1e fa          	endbr64
    9c54:	53                   	push   %rbx
    9c55:	48 8b 1f             	mov    (%rdi),%rbx
    9c58:	48 89 df             	mov    %rbx,%rdi
    9c5b:	e8 b0 c9 ff ff       	call   6610 <fwp_rc_share>
    9c60:	48 89 df             	mov    %rbx,%rdi
    9c63:	e8 d8 fa ff ff       	call   9740 <f23>
    9c68:	48 89 c3             	mov    %rax,%rbx
    9c6b:	48 89 c7             	mov    %rax,%rdi
    9c6e:	e8 9d c9 ff ff       	call   6610 <fwp_rc_share>
    9c73:	48 89 d8             	mov    %rbx,%rax
    9c76:	5b                   	pop    %rbx
    9c77:	c3                   	ret
    9c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c7f:	00 

0000000000009c80 <fwp_write>:
    9c80:	41 57                	push   %r15
    9c82:	41 56                	push   %r14
    9c84:	41 55                	push   %r13
    9c86:	41 54                	push   %r12
    9c88:	55                   	push   %rbp
    9c89:	53                   	push   %rbx
    9c8a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9c91:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9c98:	00 00 
    9c9a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9ca1:	00 
    9ca2:	49 89 d4             	mov    %rdx,%r12
    9ca5:	8b 12                	mov    (%rdx),%edx
    9ca7:	83 fa 19             	cmp    $0x19,%edx
    9caa:	77 6a                	ja     9d16 <fwp_write+0x96>
    9cac:	48 89 f5             	mov    %rsi,%rbp
    9caf:	89 d0                	mov    %edx,%eax
    9cb1:	89 ce                	mov    %ecx,%esi
    9cb3:	48 89 fb             	mov    %rdi,%rbx
    9cb6:	48 8d 0d 43 2e 00 00 	lea    0x2e43(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    9cbd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9cc1:	48 01 c8             	add    %rcx,%rax
    9cc4:	3e ff e0             	notrack jmp *%rax
    9cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cce:	00 00 
    9cd0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9cd4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9cd8:	48 89 ca             	mov    %rcx,%rdx
    9cdb:	48 85 c9             	test   %rcx,%rcx
    9cde:	0f 88 9c 0c 00 00    	js     a980 <fwp_write+0xd00>
    9ce4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ceb:	00 
    9cec:	48 89 c6             	mov    %rax,%rsi
    9cef:	4c 89 e7             	mov    %r12,%rdi
    9cf2:	e8 49 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cfe:	00 00 
    9d00:	4c 89 e7             	mov    %r12,%rdi
    9d03:	e8 48 97 ff ff       	call   3450 <strlen@plt>
    9d08:	4c 89 e6             	mov    %r12,%rsi
    9d0b:	48 89 df             	mov    %rbx,%rdi
    9d0e:	48 89 c2             	mov    %rax,%rdx
    9d11:	e8 fa a4 ff ff       	call   4210 <buf_put>
    9d16:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d1d:	00 
    9d1e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d25:	00 00 
    9d27:	0f 85 28 04 00 00    	jne    a155 <fwp_write+0x4d5>
    9d2d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9d34:	5b                   	pop    %rbx
    9d35:	5d                   	pop    %rbp
    9d36:	41 5c                	pop    %r12
    9d38:	41 5d                	pop    %r13
    9d3a:	41 5e                	pop    %r14
    9d3c:	41 5f                	pop    %r15
    9d3e:	c3                   	ret
    9d3f:	90                   	nop
    9d40:	49 89 e9             	mov    %rbp,%r9
    9d43:	4c 8d 05 2b 23 00 00 	lea    0x232b(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    9d4a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9d4f:	ba 02 00 00 00       	mov    $0x2,%edx
    9d54:	be 00 02 00 00       	mov    $0x200,%esi
    9d59:	31 c0                	xor    %eax,%eax
    9d5b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d62:	00 
    9d63:	e8 48 96 ff ff       	call   33b0 <__snprintf_chk@plt>
    9d68:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d6f:	00 
    9d70:	e8 db 96 ff ff       	call   3450 <strlen@plt>
    9d75:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9d7c:	00 
    9d7d:	48 89 df             	mov    %rbx,%rdi
    9d80:	48 89 c2             	mov    %rax,%rdx
    9d83:	e8 88 a4 ff ff       	call   4210 <buf_put>
    9d88:	eb 8c                	jmp    9d16 <fwp_write+0x96>
    9d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d90:	49 89 e9             	mov    %rbp,%r9
    9d93:	4c 8d 05 45 24 00 00 	lea    0x2445(%rip),%r8        # c1df <_IO_stdin_used+0x1df>
    9d9a:	eb ae                	jmp    9d4a <fwp_write+0xca>
    9d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9da0:	83 fa 13             	cmp    $0x13,%edx
    9da3:	48 8d 05 2b 24 00 00 	lea    0x242b(%rip),%rax        # c1d5 <_IO_stdin_used+0x1d5>
    9daa:	48 8d 35 29 24 00 00 	lea    0x2429(%rip),%rsi        # c1da <_IO_stdin_used+0x1da>
    9db1:	ba 04 00 00 00       	mov    $0x4,%edx
    9db6:	48 0f 44 f0          	cmove  %rax,%rsi
    9dba:	45 31 ed             	xor    %r13d,%r13d
    9dbd:	e8 4e a4 ff ff       	call   4210 <buf_put>
    9dc2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9dc7:	0f 84 a3 08 00 00    	je     a670 <fwp_write+0x9f0>
    9dcd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9dd2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9dd7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9ddc:	48 89 df             	mov    %rbx,%rdi
    9ddf:	49 0f 44 c5          	cmove  %r13,%rax
    9de3:	31 c9                	xor    %ecx,%ecx
    9de5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9dea:	e8 91 fe ff ff       	call   9c80 <fwp_write>
    9def:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9df4:	0f 84 6e 09 00 00    	je     a768 <fwp_write+0xae8>
    9dfa:	49 83 c5 01          	add    $0x1,%r13
    9dfe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e02:	0f 83 68 08 00 00    	jae    a670 <fwp_write+0x9f0>
    9e08:	ba 02 00 00 00       	mov    $0x2,%edx
    9e0d:	48 8d 35 0b 24 00 00 	lea    0x240b(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    9e14:	48 89 df             	mov    %rbx,%rdi
    9e17:	e8 f4 a3 ff ff       	call   4210 <buf_put>
    9e1c:	eb af                	jmp    9dcd <fwp_write+0x14d>
    9e1e:	66 90                	xchg   %ax,%ax
    9e20:	ba 06 00 00 00       	mov    $0x6,%edx
    9e25:	48 8d 35 cc 23 00 00 	lea    0x23cc(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    9e2c:	48 83 c5 10          	add    $0x10,%rbp
    9e30:	e8 db a3 ff ff       	call   4210 <buf_put>
    9e35:	48 89 ef             	mov    %rbp,%rdi
    9e38:	e8 13 96 ff ff       	call   3450 <strlen@plt>
    9e3d:	48 89 ee             	mov    %rbp,%rsi
    9e40:	48 89 df             	mov    %rbx,%rdi
    9e43:	48 89 c2             	mov    %rax,%rdx
    9e46:	e8 c5 a3 ff ff       	call   4210 <buf_put>
    9e4b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9e50:	ba 01 00 00 00       	mov    $0x1,%edx
    9e55:	48 89 df             	mov    %rbx,%rdi
    9e58:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e5d:	e8 ae a3 ff ff       	call   4210 <buf_put>
    9e62:	e9 af fe ff ff       	jmp    9d16 <fwp_write+0x96>
    9e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e6e:	00 00 
    9e70:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e77:	00 
    9e78:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e7f:	00 00 
    9e81:	0f 85 ce 02 00 00    	jne    a155 <fwp_write+0x4d5>
    9e87:	ba 0a 00 00 00       	mov    $0xa,%edx
    9e8c:	48 8d 35 51 23 00 00 	lea    0x2351(%rip),%rsi        # c1e4 <_IO_stdin_used+0x1e4>
    9e93:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9e9a:	48 89 df             	mov    %rbx,%rdi
    9e9d:	5b                   	pop    %rbx
    9e9e:	5d                   	pop    %rbp
    9e9f:	41 5c                	pop    %r12
    9ea1:	41 5d                	pop    %r13
    9ea3:	41 5e                	pop    %r14
    9ea5:	41 5f                	pop    %r15
    9ea7:	e9 64 a3 ff ff       	jmp    4210 <buf_put>
    9eac:	0f 1f 40 00          	nopl   0x0(%rax)
    9eb0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9eb5:	4d 85 ed             	test   %r13,%r13
    9eb8:	0f 84 02 0c 00 00    	je     aac0 <fwp_write+0xe40>
    9ebe:	48 8d 35 67 23 00 00 	lea    0x2367(%rip),%rsi        # c22c <_IO_stdin_used+0x22c>
    9ec5:	4c 89 ef             	mov    %r13,%rdi
    9ec8:	e8 63 96 ff ff       	call   3530 <strcmp@plt>
    9ecd:	41 89 c1             	mov    %eax,%r9d
    9ed0:	85 c0                	test   %eax,%eax
    9ed2:	0f 84 6c 0c 00 00    	je     ab44 <fwp_write+0xec4>
    9ed8:	4c 89 ef             	mov    %r13,%rdi
    9edb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9ee0:	e8 6b 95 ff ff       	call   3450 <strlen@plt>
    9ee5:	4c 89 ee             	mov    %r13,%rsi
    9ee8:	48 89 df             	mov    %rbx,%rdi
    9eeb:	48 89 c2             	mov    %rax,%rdx
    9eee:	e8 1d a3 ff ff       	call   4210 <buf_put>
    9ef3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ef8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9efd:	48 89 df             	mov    %rbx,%rdi
    9f00:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f05:	e8 06 a3 ff ff       	call   4210 <buf_put>
    9f0a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f0f:	4c 89 fe             	mov    %r15,%rsi
    9f12:	48 89 df             	mov    %rbx,%rdi
    9f15:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f1a:	e8 f1 a2 ff ff       	call   4210 <buf_put>
    9f1f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f24:	45 31 f6             	xor    %r14d,%r14d
    9f27:	85 d2                	test   %edx,%edx
    9f29:	0f 8e 81 0a 00 00    	jle    a9b0 <fwp_write+0xd30>
    9f2f:	45 31 ed             	xor    %r13d,%r13d
    9f32:	4d 85 ed             	test   %r13,%r13
    9f35:	0f 85 75 07 00 00    	jne    a6b0 <fwp_write+0xa30>
    9f3b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9f42:	00 
    9f43:	45 85 f6             	test   %r14d,%r14d
    9f46:	0f 84 84 07 00 00    	je     a6d0 <fwp_write+0xa50>
    9f4c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9f51:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9f56:	48 89 df             	mov    %rbx,%rdi
    9f59:	49 83 c5 01          	add    $0x1,%r13
    9f5d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9f61:	31 c9                	xor    %ecx,%ecx
    9f63:	e8 18 fd ff ff       	call   9c80 <fwp_write>
    9f68:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9f6d:	7f c3                	jg     9f32 <fwp_write+0x2b2>
    9f6f:	45 85 f6             	test   %r14d,%r14d
    9f72:	0f 84 38 0a 00 00    	je     a9b0 <fwp_write+0xd30>
    9f78:	b8 29 00 00 00       	mov    $0x29,%eax
    9f7d:	ba 01 00 00 00       	mov    $0x1,%edx
    9f82:	4c 89 fe             	mov    %r15,%rsi
    9f85:	48 89 df             	mov    %rbx,%rdi
    9f88:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9f8c:	e8 7f a2 ff ff       	call   4210 <buf_put>
    9f91:	e9 80 fd ff ff       	jmp    9d16 <fwp_write+0x96>
    9f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f9d:	00 00 00 
    9fa0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fa5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9faa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9faf:	e8 5c a2 ff ff       	call   4210 <buf_put>
    9fb4:	48 85 ed             	test   %rbp,%rbp
    9fb7:	0f 84 93 06 00 00    	je     a650 <fwp_write+0x9d0>
    9fbd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9fc1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fc6:	31 c9                	xor    %ecx,%ecx
    9fc8:	48 89 df             	mov    %rbx,%rdi
    9fcb:	e8 b0 fc ff ff       	call   9c80 <fwp_write>
    9fd0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9fd4:	48 85 ed             	test   %rbp,%rbp
    9fd7:	0f 84 73 06 00 00    	je     a650 <fwp_write+0x9d0>
    9fdd:	ba 02 00 00 00       	mov    $0x2,%edx
    9fe2:	48 8d 35 36 22 00 00 	lea    0x2236(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    9fe9:	48 89 df             	mov    %rbx,%rdi
    9fec:	e8 1f a2 ff ff       	call   4210 <buf_put>
    9ff1:	eb ca                	jmp    9fbd <fwp_write+0x33d>
    9ff3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ff8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9ffc:	85 f6                	test   %esi,%esi
    9ffe:	0f 84 fc 07 00 00    	je     a800 <fwp_write+0xb80>
    a004:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a00b:	00 
    a00c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a013:	00 00 
    a015:	0f 85 3a 01 00 00    	jne    a155 <fwp_write+0x4d5>
    a01b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a01f:	4c 89 ea             	mov    %r13,%rdx
    a022:	e9 6c fe ff ff       	jmp    9e93 <fwp_write+0x213>
    a027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a02e:	00 00 
    a030:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a035:	ba 01 00 00 00       	mov    $0x1,%edx
    a03a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a03f:	48 89 ee             	mov    %rbp,%rsi
    a042:	e8 c9 a1 ff ff       	call   4210 <buf_put>
    a047:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a04c:	4c 89 e7             	mov    %r12,%rdi
    a04f:	e8 fc 93 ff ff       	call   3450 <strlen@plt>
    a054:	4c 89 e6             	mov    %r12,%rsi
    a057:	48 89 df             	mov    %rbx,%rdi
    a05a:	48 89 c2             	mov    %rax,%rdx
    a05d:	e8 ae a1 ff ff       	call   4210 <buf_put>
    a062:	ba 01 00 00 00       	mov    $0x1,%edx
    a067:	48 89 ee             	mov    %rbp,%rsi
    a06a:	48 89 df             	mov    %rbx,%rdi
    a06d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a072:	e8 99 a1 ff ff       	call   4210 <buf_put>
    a077:	e9 9a fc ff ff       	jmp    9d16 <fwp_write+0x96>
    a07c:	0f 1f 40 00          	nopl   0x0(%rax)
    a080:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a085:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a089:	0f 8a 8e 0b 00 00    	jp     ac1d <fwp_write+0xf9d>
    a08f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a093:	66 0f 54 05 65 2b 00 	andpd  0x2b65(%rip),%xmm0        # cc00 <msg.4+0x90>
    a09a:	00 
    a09b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a0a0:	66 0f 2e 05 98 2b 00 	ucomisd 0x2b98(%rip),%xmm0        # cc40 <msg.4+0xd0>
    a0a7:	00 
    a0a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a0af:	00 
    a0b0:	0f 87 b2 09 00 00    	ja     aa68 <fwp_write+0xde8>
    a0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0bd:	00 00 00 
    a0c0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0c4:	89 ee                	mov    %ebp,%esi
    a0c6:	4c 89 e7             	mov    %r12,%rdi
    a0c9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a0ce:	e8 3d a6 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a0d3:	31 f6                	xor    %esi,%esi
    a0d5:	4c 89 e7             	mov    %r12,%rdi
    a0d8:	e8 33 93 ff ff       	call   3410 <strtod@plt>
    a0dd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a0e2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a0e6:	7a 06                	jp     a0ee <fwp_write+0x46e>
    a0e8:	0f 84 e9 01 00 00    	je     a2d7 <fwp_write+0x657>
    a0ee:	83 c5 01             	add    $0x1,%ebp
    a0f1:	83 fd 12             	cmp    $0x12,%ebp
    a0f4:	75 ca                	jne    a0c0 <fwp_write+0x440>
    a0f6:	be 11 00 00 00       	mov    $0x11,%esi
    a0fb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0ff:	4c 89 e7             	mov    %r12,%rdi
    a102:	e8 09 a6 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a107:	e9 cb 01 00 00       	jmp    a2d7 <fwp_write+0x657>
    a10c:	0f 1f 40 00          	nopl   0x0(%rax)
    a110:	48 83 fd 01          	cmp    $0x1,%rbp
    a114:	0f 84 e6 08 00 00    	je     aa00 <fwp_write+0xd80>
    a11a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a11e:	b8 02 00 00 00       	mov    $0x2,%eax
    a123:	ba 01 00 00 00       	mov    $0x1,%edx
    a128:	48 0f 44 d0          	cmove  %rax,%rdx
    a12c:	48 8d 35 9a 20 00 00 	lea    0x209a(%rip),%rsi        # c1cd <_IO_stdin_used+0x1cd>
    a133:	48 8d 05 98 20 00 00 	lea    0x2098(%rip),%rax        # c1d2 <_IO_stdin_used+0x1d2>
    a13a:	48 0f 44 f0          	cmove  %rax,%rsi
    a13e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a145:	00 
    a146:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a14d:	00 00 
    a14f:	0f 84 3e fd ff ff    	je     9e93 <fwp_write+0x213>
    a155:	e8 06 93 ff ff       	call   3460 <__stack_chk_fail@plt>
    a15a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a160:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a165:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a16a:	e8 e1 9f ff ff       	call   4150 <buf_grow>
    a16f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a173:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a179:	4c 03 0b             	add    (%rbx),%r9
    a17c:	66 45 89 11          	mov    %r10w,(%r9)
    a180:	45 85 e4             	test   %r12d,%r12d
    a183:	0f 8e 07 05 00 00    	jle    a690 <fwp_write+0xa10>
    a189:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a190:	55 55 55 
    a193:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a198:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a19f:	aa aa aa 
    a1a2:	49 83 c1 01          	add    $0x1,%r9
    a1a6:	eb 45                	jmp    a1ed <fwp_write+0x56d>
    a1a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1af:	00 
    a1b0:	be 01 00 00 00       	mov    $0x1,%esi
    a1b5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a1ba:	88 07                	mov    %al,(%rdi)
    a1bc:	48 89 e8             	mov    %rbp,%rax
    a1bf:	49 f7 e8             	imul   %r8
    a1c2:	48 89 e8             	mov    %rbp,%rax
    a1c5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a1c9:	48 29 c2             	sub    %rax,%rdx
    a1cc:	48 85 c9             	test   %rcx,%rcx
    a1cf:	0f 95 c0             	setne  %al
    a1d2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a1d6:	48 83 ef 01          	sub    $0x1,%rdi
    a1da:	48 21 c5             	and    %rax,%rbp
    a1dd:	48 29 ea             	sub    %rbp,%rdx
    a1e0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a1e4:	49 39 f9             	cmp    %rdi,%r9
    a1e7:	0f 84 a3 04 00 00    	je     a690 <fwp_write+0xa10>
    a1ed:	48 89 e8             	mov    %rbp,%rax
    a1f0:	49 f7 e8             	imul   %r8
    a1f3:	48 89 e8             	mov    %rbp,%rax
    a1f6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a1fa:	48 89 d1             	mov    %rdx,%rcx
    a1fd:	48 29 c1             	sub    %rax,%rcx
    a200:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a204:	48 89 e9             	mov    %rbp,%rcx
    a207:	48 29 c1             	sub    %rax,%rcx
    a20a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a20e:	49 f7 e2             	mul    %r10
    a211:	b8 30 00 00 00       	mov    $0x30,%eax
    a216:	48 89 d6             	mov    %rdx,%rsi
    a219:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a21d:	48 d1 ee             	shr    $1,%rsi
    a220:	48 01 f2             	add    %rsi,%rdx
    a223:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a227:	48 29 d6             	sub    %rdx,%rsi
    a22a:	74 8e                	je     a1ba <fwp_write+0x53a>
    a22c:	48 83 fe 01          	cmp    $0x1,%rsi
    a230:	0f 85 7a ff ff ff    	jne    a1b0 <fwp_write+0x530>
    a236:	31 f6                	xor    %esi,%esi
    a238:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a23d:	e9 78 ff ff ff       	jmp    a1ba <fwp_write+0x53a>
    a242:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a248:	66 0f 6e cd          	movd   %ebp,%xmm1
    a24c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a24f:	0f 8a c8 09 00 00    	jp     ac1d <fwp_write+0xf9d>
    a255:	0f 28 c1             	movaps %xmm1,%xmm0
    a258:	0f 54 05 91 29 00 00 	andps  0x2991(%rip),%xmm0        # cbf0 <msg.4+0x80>
    a25f:	0f 2e 05 9e 1d 00 00 	ucomiss 0x1d9e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a266:	0f 87 24 08 00 00    	ja     aa90 <fwp_write+0xe10>
    a26c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a270:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a276:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a27d:	00 
    a27e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a282:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a28e:	00 00 
    a290:	44 89 ee             	mov    %r13d,%esi
    a293:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a298:	4c 89 e7             	mov    %r12,%rdi
    a29b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a2a0:	e8 6b a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2a5:	31 f6                	xor    %esi,%esi
    a2a7:	4c 89 e7             	mov    %r12,%rdi
    a2aa:	e8 01 92 ff ff       	call   34b0 <strtof@plt>
    a2af:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a2b4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a2b7:	7a 02                	jp     a2bb <fwp_write+0x63b>
    a2b9:	74 1c                	je     a2d7 <fwp_write+0x657>
    a2bb:	41 83 c5 01          	add    $0x1,%r13d
    a2bf:	41 83 fd 0a          	cmp    $0xa,%r13d
    a2c3:	75 cb                	jne    a290 <fwp_write+0x610>
    a2c5:	be 09 00 00 00       	mov    $0x9,%esi
    a2ca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2cf:	4c 89 e7             	mov    %r12,%rdi
    a2d2:	e8 39 a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2d7:	4c 89 e7             	mov    %r12,%rdi
    a2da:	e8 a1 a0 ff ff       	call   4380 <fwp_finish_float>
    a2df:	e9 1c fa ff ff       	jmp    9d00 <fwp_write+0x80>
    a2e4:	0f 1f 40 00          	nopl   0x0(%rax)
    a2e8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a2ec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a2f0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a2f7:	00 
    a2f8:	48 89 ef             	mov    %rbp,%rdi
    a2fb:	e8 40 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a300:	48 89 ef             	mov    %rbp,%rdi
    a303:	e8 48 91 ff ff       	call   3450 <strlen@plt>
    a308:	48 89 ee             	mov    %rbp,%rsi
    a30b:	48 89 df             	mov    %rbx,%rdi
    a30e:	48 89 c2             	mov    %rax,%rdx
    a311:	e8 fa 9e ff ff       	call   4210 <buf_put>
    a316:	e9 fb f9 ff ff       	jmp    9d16 <fwp_write+0x96>
    a31b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a320:	ba 06 00 00 00       	mov    $0x6,%edx
    a325:	48 8d 35 f6 1e 00 00 	lea    0x1ef6(%rip),%rsi        # c222 <_IO_stdin_used+0x222>
    a32c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a332:	e8 d9 9e ff ff       	call   4210 <buf_put>
    a337:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a33e:	ff ff 7f 
    a341:	48 23 55 00          	and    0x0(%rbp),%rdx
    a345:	0f 84 86 02 00 00    	je     a5d1 <fwp_write+0x951>
    a34b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a350:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a354:	48 85 d2             	test   %rdx,%rdx
    a357:	0f 84 ae 00 00 00    	je     a40b <fwp_write+0x78b>
    a35d:	8b 0a                	mov    (%rdx),%ecx
    a35f:	83 f9 1c             	cmp    $0x1c,%ecx
    a362:	0f 84 58 06 00 00    	je     a9c0 <fwp_write+0xd40>
    a368:	83 f9 1b             	cmp    $0x1b,%ecx
    a36b:	0f 87 9a 00 00 00    	ja     a40b <fwp_write+0x78b>
    a371:	be 01 00 00 00       	mov    $0x1,%esi
    a376:	48 d3 e6             	shl    %cl,%rsi
    a379:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a37f:	0f 85 4b 04 00 00    	jne    a7d0 <fwp_write+0xb50>
    a385:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a38b:	0f 85 0f 04 00 00    	jne    a7a0 <fwp_write+0xb20>
    a391:	83 e6 21             	and    $0x21,%esi
    a394:	74 75                	je     a40b <fwp_write+0x78b>
    a396:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a39b:	48 85 ff             	test   %rdi,%rdi
    a39e:	79 07                	jns    a3a7 <fwp_write+0x727>
    a3a0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a3a4:	4c 01 ee             	add    %r13,%rsi
    a3a7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a3ab:	85 c9                	test   %ecx,%ecx
    a3ad:	40 0f b6 f7          	movzbl %dil,%esi
    a3b1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3bc:	00 00 00 00 
    a3c0:	31 c9                	xor    %ecx,%ecx
    a3c2:	48 89 df             	mov    %rbx,%rdi
    a3c5:	49 83 c5 01          	add    $0x1,%r13
    a3c9:	e8 b2 f8 ff ff       	call   9c80 <fwp_write>
    a3ce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a3d5:	ff ff 7f 
    a3d8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3dc:	49 39 d5             	cmp    %rdx,%r13
    a3df:	0f 83 ec 01 00 00    	jae    a5d1 <fwp_write+0x951>
    a3e5:	ba 02 00 00 00       	mov    $0x2,%edx
    a3ea:	48 89 df             	mov    %rbx,%rdi
    a3ed:	48 8d 35 2b 1e 00 00 	lea    0x1e2b(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a3f4:	e8 17 9e ff ff       	call   4210 <buf_put>
    a3f9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a3fe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a402:	48 85 d2             	test   %rdx,%rdx
    a405:	0f 85 52 ff ff ff    	jne    a35d <fwp_write+0x6dd>
    a40b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a410:	48 85 ff             	test   %rdi,%rdi
    a413:	0f 88 cf 05 00 00    	js     a9e8 <fwp_write+0xd68>
    a419:	48 8b 31             	mov    (%rcx),%rsi
    a41c:	eb a2                	jmp    a3c0 <fwp_write+0x740>
    a41e:	66 90                	xchg   %ax,%ax
    a420:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a427:	00 
    a428:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a42f:	00 00 
    a431:	0f 85 1e fd ff ff    	jne    a155 <fwp_write+0x4d5>
    a437:	ba 08 00 00 00       	mov    $0x8,%edx
    a43c:	48 8d 35 ac 1d 00 00 	lea    0x1dac(%rip),%rsi        # c1ef <_IO_stdin_used+0x1ef>
    a443:	e9 4b fa ff ff       	jmp    9e93 <fwp_write+0x213>
    a448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a44f:	00 
    a450:	89 e8                	mov    %ebp,%eax
    a452:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a459:	76 03                	jbe    a45e <fwp_write+0x7de>
    a45b:	8b 45 00             	mov    0x0(%rbp),%eax
    a45e:	41 89 c6             	mov    %eax,%r14d
    a461:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a466:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a46b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a46f:	4c 89 ef             	mov    %r13,%rdi
    a472:	e8 d9 8f ff ff       	call   3450 <strlen@plt>
    a477:	4c 89 ee             	mov    %r13,%rsi
    a47a:	48 89 df             	mov    %rbx,%rdi
    a47d:	48 89 c2             	mov    %rax,%rdx
    a480:	e8 8b 9d ff ff       	call   4210 <buf_put>
    a485:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a48a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a48e:	85 f6                	test   %esi,%esi
    a490:	0f 8e 80 f8 ff ff    	jle    9d16 <fwp_write+0x96>
    a496:	45 31 ed             	xor    %r13d,%r13d
    a499:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a49e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a4a3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a4a8:	ba 01 00 00 00       	mov    $0x1,%edx
    a4ad:	4c 89 fe             	mov    %r15,%rsi
    a4b0:	48 89 04 24          	mov    %rax,(%rsp)
    a4b4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a4b9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a4bd:	48 89 df             	mov    %rbx,%rdi
    a4c0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a4c4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a4c9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a4ce:	e8 3d 9d ff ff       	call   4210 <buf_put>
    a4d3:	41 8b 06             	mov    (%r14),%eax
    a4d6:	83 f8 0e             	cmp    $0xe,%eax
    a4d9:	0f 84 71 02 00 00    	je     a750 <fwp_write+0xad0>
    a4df:	83 f8 10             	cmp    $0x10,%eax
    a4e2:	0f 84 38 02 00 00    	je     a720 <fwp_write+0xaa0>
    a4e8:	83 f8 0a             	cmp    $0xa,%eax
    a4eb:	0f 84 7f 04 00 00    	je     a970 <fwp_write+0xcf0>
    a4f1:	0f 8f f9 00 00 00    	jg     a5f0 <fwp_write+0x970>
    a4f7:	83 f8 03             	cmp    $0x3,%eax
    a4fa:	0f 8f 50 04 00 00    	jg     a950 <fwp_write+0xcd0>
    a500:	85 c0                	test   %eax,%eax
    a502:	78 10                	js     a514 <fwp_write+0x894>
    a504:	48 8b 04 24          	mov    (%rsp),%rax
    a508:	48 c1 e8 3f          	shr    $0x3f,%rax
    a50c:	85 c0                	test   %eax,%eax
    a50e:	0f 85 f9 00 00 00    	jne    a60d <fwp_write+0x98d>
    a514:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a519:	48 8b 34 24          	mov    (%rsp),%rsi
    a51d:	31 c9                	xor    %ecx,%ecx
    a51f:	48 89 df             	mov    %rbx,%rdi
    a522:	e8 59 f7 ff ff       	call   9c80 <fwp_write>
    a527:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a52c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a531:	49 83 c5 01          	add    $0x1,%r13
    a535:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a539:	0f 8f 5f ff ff ff    	jg     a49e <fwp_write+0x81e>
    a53f:	e9 d2 f7 ff ff       	jmp    9d16 <fwp_write+0x96>
    a544:	0f 1f 40 00          	nopl   0x0(%rax)
    a548:	ba 06 00 00 00       	mov    $0x6,%edx
    a54d:	48 8d 35 c1 1c 00 00 	lea    0x1cc1(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    a554:	45 31 ed             	xor    %r13d,%r13d
    a557:	e8 b4 9c ff ff       	call   4210 <buf_put>
    a55c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a561:	75 19                	jne    a57c <fwp_write+0x8fc>
    a563:	eb 6c                	jmp    a5d1 <fwp_write+0x951>
    a565:	0f 1f 00             	nopl   (%rax)
    a568:	ba 02 00 00 00       	mov    $0x2,%edx
    a56d:	48 8d 35 ab 1c 00 00 	lea    0x1cab(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a574:	48 89 df             	mov    %rbx,%rdi
    a577:	e8 94 9c ff ff       	call   4210 <buf_put>
    a57c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a582:	b9 00 02 00 00       	mov    $0x200,%ecx
    a587:	31 c0                	xor    %eax,%eax
    a589:	49 83 c5 01          	add    $0x1,%r13
    a58d:	4c 8d 05 88 1c 00 00 	lea    0x1c88(%rip),%r8        # c21c <_IO_stdin_used+0x21c>
    a594:	ba 02 00 00 00       	mov    $0x2,%edx
    a599:	be 00 02 00 00       	mov    $0x200,%esi
    a59e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5a5:	00 
    a5a6:	e8 05 8e ff ff       	call   33b0 <__snprintf_chk@plt>
    a5ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5b2:	00 
    a5b3:	e8 98 8e ff ff       	call   3450 <strlen@plt>
    a5b8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a5bf:	00 
    a5c0:	48 89 df             	mov    %rbx,%rdi
    a5c3:	48 89 c2             	mov    %rax,%rdx
    a5c6:	e8 45 9c ff ff       	call   4210 <buf_put>
    a5cb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a5cf:	72 97                	jb     a568 <fwp_write+0x8e8>
    a5d1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5d6:	ba 01 00 00 00       	mov    $0x1,%edx
    a5db:	48 89 df             	mov    %rbx,%rdi
    a5de:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a5e3:	e8 28 9c ff ff       	call   4210 <buf_put>
    a5e8:	e9 29 f7 ff ff       	jmp    9d16 <fwp_write+0x96>
    a5ed:	0f 1f 00             	nopl   (%rax)
    a5f0:	83 f8 0b             	cmp    $0xb,%eax
    a5f3:	0f 85 1b ff ff ff    	jne    a514 <fwp_write+0x894>
    a5f9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a5fe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a602:	83 e0 01             	and    $0x1,%eax
    a605:	85 c0                	test   %eax,%eax
    a607:	0f 84 07 ff ff ff    	je     a514 <fwp_write+0x894>
    a60d:	4c 89 fe             	mov    %r15,%rsi
    a610:	48 89 df             	mov    %rbx,%rdi
    a613:	ba 01 00 00 00       	mov    $0x1,%edx
    a618:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a61d:	e8 ee 9b ff ff       	call   4210 <buf_put>
    a622:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a627:	48 8b 34 24          	mov    (%rsp),%rsi
    a62b:	31 c9                	xor    %ecx,%ecx
    a62d:	48 89 df             	mov    %rbx,%rdi
    a630:	e8 4b f6 ff ff       	call   9c80 <fwp_write>
    a635:	ba 01 00 00 00       	mov    $0x1,%edx
    a63a:	4c 89 fe             	mov    %r15,%rsi
    a63d:	48 89 df             	mov    %rbx,%rdi
    a640:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a645:	e8 c6 9b ff ff       	call   4210 <buf_put>
    a64a:	e9 d8 fe ff ff       	jmp    a527 <fwp_write+0x8a7>
    a64f:	90                   	nop
    a650:	ba 01 00 00 00       	mov    $0x1,%edx
    a655:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a65a:	48 89 df             	mov    %rbx,%rdi
    a65d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a662:	e8 a9 9b ff ff       	call   4210 <buf_put>
    a667:	e9 aa f6 ff ff       	jmp    9d16 <fwp_write+0x96>
    a66c:	0f 1f 40 00          	nopl   0x0(%rax)
    a670:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a675:	ba 01 00 00 00       	mov    $0x1,%edx
    a67a:	48 89 df             	mov    %rbx,%rdi
    a67d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a682:	e8 89 9b ff ff       	call   4210 <buf_put>
    a687:	e9 8a f6 ff ff       	jmp    9d16 <fwp_write+0x96>
    a68c:	0f 1f 40 00          	nopl   0x0(%rax)
    a690:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a694:	48 8b 13             	mov    (%rbx),%rdx
    a697:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a69c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a6a0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a6a4:	e9 6d f6 ff ff       	jmp    9d16 <fwp_write+0x96>
    a6a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6b0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6b5:	48 8d 35 63 1b 00 00 	lea    0x1b63(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a6bc:	48 89 df             	mov    %rbx,%rdi
    a6bf:	e8 4c 9b ff ff       	call   4210 <buf_put>
    a6c4:	e9 72 f8 ff ff       	jmp    9f3b <fwp_write+0x2bb>
    a6c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6d0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a6d5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a6da:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a6de:	48 89 f7             	mov    %rsi,%rdi
    a6e1:	48 89 34 24          	mov    %rsi,(%rsp)
    a6e5:	e8 66 8d ff ff       	call   3450 <strlen@plt>
    a6ea:	48 8b 34 24          	mov    (%rsp),%rsi
    a6ee:	48 89 df             	mov    %rbx,%rdi
    a6f1:	48 89 c2             	mov    %rax,%rdx
    a6f4:	e8 17 9b ff ff       	call   4210 <buf_put>
    a6f9:	ba 03 00 00 00       	mov    $0x3,%edx
    a6fe:	48 8d 35 3d 1b 00 00 	lea    0x1b3d(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    a705:	48 89 df             	mov    %rbx,%rdi
    a708:	e8 03 9b ff ff       	call   4210 <buf_put>
    a70d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a712:	e9 35 f8 ff ff       	jmp    9f4c <fwp_write+0x2cc>
    a717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a71e:	00 00 
    a720:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a725:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a729:	48 85 ff             	test   %rdi,%rdi
    a72c:	0f 84 e2 fd ff ff    	je     a514 <fwp_write+0x894>
    a732:	48 8d 35 f3 1a 00 00 	lea    0x1af3(%rip),%rsi        # c22c <_IO_stdin_used+0x22c>
    a739:	e8 f2 8d ff ff       	call   3530 <strcmp@plt>
    a73e:	85 c0                	test   %eax,%eax
    a740:	0f 95 c0             	setne  %al
    a743:	0f b6 c0             	movzbl %al,%eax
    a746:	e9 c1 fd ff ff       	jmp    a50c <fwp_write+0x88c>
    a74b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a750:	31 c0                	xor    %eax,%eax
    a752:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a759:	00 
    a75a:	0f 97 c0             	seta   %al
    a75d:	e9 aa fd ff ff       	jmp    a50c <fwp_write+0x88c>
    a762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a768:	48 89 df             	mov    %rbx,%rdi
    a76b:	ba 02 00 00 00       	mov    $0x2,%edx
    a770:	48 8d 35 b2 1a 00 00 	lea    0x1ab2(%rip),%rsi        # c229 <_IO_stdin_used+0x229>
    a777:	e8 94 9a ff ff       	call   4210 <buf_put>
    a77c:	4c 89 e8             	mov    %r13,%rax
    a77f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a784:	31 c9                	xor    %ecx,%ecx
    a786:	48 c1 e0 04          	shl    $0x4,%rax
    a78a:	48 89 df             	mov    %rbx,%rdi
    a78d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a792:	e8 e9 f4 ff ff       	call   9c80 <fwp_write>
    a797:	e9 5e f6 ff ff       	jmp    9dfa <fwp_write+0x17a>
    a79c:	0f 1f 40 00          	nopl   0x0(%rax)
    a7a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a7a5:	48 85 ff             	test   %rdi,%rdi
    a7a8:	79 0c                	jns    a7b6 <fwp_write+0xb36>
    a7aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a7b1:	00 
    a7b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a7b6:	48 63 3e             	movslq (%rsi),%rdi
    a7b9:	83 f9 02             	cmp    $0x2,%ecx
    a7bc:	89 fe                	mov    %edi,%esi
    a7be:	48 0f 44 f7          	cmove  %rdi,%rsi
    a7c2:	e9 f9 fb ff ff       	jmp    a3c0 <fwp_write+0x740>
    a7c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7ce:	00 00 
    a7d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a7d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a7da:	48 85 ff             	test   %rdi,%rdi
    a7dd:	0f 88 0f 03 00 00    	js     aaf2 <fwp_write+0xe72>
    a7e3:	49 0f bf 38          	movswq (%r8),%rdi
    a7e7:	83 f9 01             	cmp    $0x1,%ecx
    a7ea:	0f b7 f7             	movzwl %di,%esi
    a7ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    a7f1:	e9 ca fb ff ff       	jmp    a3c0 <fwp_write+0x740>
    a7f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a7fd:	00 00 00 
    a800:	ba 01 00 00 00       	mov    $0x1,%edx
    a805:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a80a:	48 83 c5 08          	add    $0x8,%rbp
    a80e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a813:	e8 f8 99 ff ff       	call   4210 <buf_put>
    a818:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a81d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a822:	4d 85 ed             	test   %r13,%r13
    a825:	75 46                	jne    a86d <fwp_write+0xbed>
    a827:	e9 04 01 00 00       	jmp    a930 <fwp_write+0xcb0>
    a82c:	0f 1f 40 00          	nopl   0x0(%rax)
    a830:	41 80 f9 09          	cmp    $0x9,%r9b
    a834:	0f 84 d6 00 00 00    	je     a910 <fwp_write+0xc90>
    a83a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a83e:	0f 85 9c 00 00 00    	jne    a8e0 <fwp_write+0xc60>
    a844:	ba 02 00 00 00       	mov    $0x2,%edx
    a849:	48 8d 35 b5 19 00 00 	lea    0x19b5(%rip),%rsi        # c205 <_IO_stdin_used+0x205>
    a850:	48 89 df             	mov    %rbx,%rdi
    a853:	e8 b8 99 ff ff       	call   4210 <buf_put>
    a858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a85f:	00 
    a860:	48 83 c5 01          	add    $0x1,%rbp
    a864:	49 39 ec             	cmp    %rbp,%r12
    a867:	0f 84 c3 00 00 00    	je     a930 <fwp_write+0xcb0>
    a86d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a872:	41 80 f9 0d          	cmp    $0xd,%r9b
    a876:	74 28                	je     a8a0 <fwp_write+0xc20>
    a878:	7e b6                	jle    a830 <fwp_write+0xbb0>
    a87a:	41 80 f9 22          	cmp    $0x22,%r9b
    a87e:	74 40                	je     a8c0 <fwp_write+0xc40>
    a880:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a884:	75 5a                	jne    a8e0 <fwp_write+0xc60>
    a886:	ba 02 00 00 00       	mov    $0x2,%edx
    a88b:	48 8d 35 70 19 00 00 	lea    0x1970(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    a892:	48 89 df             	mov    %rbx,%rdi
    a895:	e8 76 99 ff ff       	call   4210 <buf_put>
    a89a:	eb c4                	jmp    a860 <fwp_write+0xbe0>
    a89c:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8a5:	48 8d 35 5f 19 00 00 	lea    0x195f(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    a8ac:	48 89 df             	mov    %rbx,%rdi
    a8af:	e8 5c 99 ff ff       	call   4210 <buf_put>
    a8b4:	eb aa                	jmp    a860 <fwp_write+0xbe0>
    a8b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8bd:	00 00 00 
    a8c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8c5:	48 8d 35 33 19 00 00 	lea    0x1933(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    a8cc:	48 89 df             	mov    %rbx,%rdi
    a8cf:	e8 3c 99 ff ff       	call   4210 <buf_put>
    a8d4:	eb 8a                	jmp    a860 <fwp_write+0xbe0>
    a8d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8dd:	00 00 00 
    a8e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a8e4:	0f 86 2e 01 00 00    	jbe    aa18 <fwp_write+0xd98>
    a8ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a8ee:	0f 84 24 01 00 00    	je     aa18 <fwp_write+0xd98>
    a8f4:	ba 01 00 00 00       	mov    $0x1,%edx
    a8f9:	4c 89 fe             	mov    %r15,%rsi
    a8fc:	48 89 df             	mov    %rbx,%rdi
    a8ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a904:	e8 07 99 ff ff       	call   4210 <buf_put>
    a909:	e9 52 ff ff ff       	jmp    a860 <fwp_write+0xbe0>
    a90e:	66 90                	xchg   %ax,%ax
    a910:	ba 02 00 00 00       	mov    $0x2,%edx
    a915:	48 8d 35 ec 18 00 00 	lea    0x18ec(%rip),%rsi        # c208 <_IO_stdin_used+0x208>
    a91c:	48 89 df             	mov    %rbx,%rdi
    a91f:	e8 ec 98 ff ff       	call   4210 <buf_put>
    a924:	e9 37 ff ff ff       	jmp    a860 <fwp_write+0xbe0>
    a929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a930:	ba 01 00 00 00       	mov    $0x1,%edx
    a935:	4c 89 fe             	mov    %r15,%rsi
    a938:	48 89 df             	mov    %rbx,%rdi
    a93b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a940:	e8 cb 98 ff ff       	call   4210 <buf_put>
    a945:	e9 cc f3 ff ff       	jmp    9d16 <fwp_write+0x96>
    a94a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a950:	83 f8 04             	cmp    $0x4,%eax
    a953:	0f 85 bb fb ff ff    	jne    a514 <fwp_write+0x894>
    a959:	48 8b 04 24          	mov    (%rsp),%rax
    a95d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a961:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a966:	48 c1 e8 3f          	shr    $0x3f,%rax
    a96a:	e9 96 fc ff ff       	jmp    a605 <fwp_write+0x985>
    a96f:	90                   	nop
    a970:	8b 0c 24             	mov    (%rsp),%ecx
    a973:	31 c0                	xor    %eax,%eax
    a975:	85 c9                	test   %ecx,%ecx
    a977:	0f 98 c0             	sets   %al
    a97a:	e9 86 fc ff ff       	jmp    a605 <fwp_write+0x985>
    a97f:	90                   	nop
    a980:	48 f7 d8             	neg    %rax
    a983:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a98a:	00 
    a98b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a992:	2d 
    a993:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a99a:	00 
    a99b:	48 83 d2 00          	adc    $0x0,%rdx
    a99f:	48 89 c6             	mov    %rax,%rsi
    a9a2:	48 f7 da             	neg    %rdx
    a9a5:	e8 96 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9aa:	e9 51 f3 ff ff       	jmp    9d00 <fwp_write+0x80>
    a9af:	90                   	nop
    a9b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a9b5:	e9 c3 f5 ff ff       	jmp    9f7d <fwp_write+0x2fd>
    a9ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9c0:	4c 89 e9             	mov    %r13,%rcx
    a9c3:	48 c1 e1 04          	shl    $0x4,%rcx
    a9c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a9cc:	48 85 ff             	test   %rdi,%rdi
    a9cf:	0f 89 eb f9 ff ff    	jns    a3c0 <fwp_write+0x740>
    a9d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a9d9:	48 89 ce             	mov    %rcx,%rsi
    a9dc:	e9 df f9 ff ff       	jmp    a3c0 <fwp_write+0x740>
    a9e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a9ef:	00 
    a9f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a9f4:	e9 20 fa ff ff       	jmp    a419 <fwp_write+0x799>
    a9f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa00:	ba 02 00 00 00       	mov    $0x2,%edx
    aa05:	48 8d 35 c3 17 00 00 	lea    0x17c3(%rip),%rsi        # c1cf <_IO_stdin_used+0x1cf>
    aa0c:	e9 2d f7 ff ff       	jmp    a13e <fwp_write+0x4be>
    aa11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa18:	4c 8d 05 ef 17 00 00 	lea    0x17ef(%rip),%r8        # c20e <_IO_stdin_used+0x20e>
    aa1f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa24:	31 c0                	xor    %eax,%eax
    aa26:	ba 02 00 00 00       	mov    $0x2,%edx
    aa2b:	be 10 00 00 00       	mov    $0x10,%esi
    aa30:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa37:	00 
    aa38:	e8 73 89 ff ff       	call   33b0 <__snprintf_chk@plt>
    aa3d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa44:	00 
    aa45:	e8 06 8a ff ff       	call   3450 <strlen@plt>
    aa4a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aa51:	00 
    aa52:	48 89 df             	mov    %rbx,%rdi
    aa55:	48 89 c2             	mov    %rax,%rdx
    aa58:	e8 b3 97 ff ff       	call   4210 <buf_put>
    aa5d:	e9 fe fd ff ff       	jmp    a860 <fwp_write+0xbe0>
    aa62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa6c:	48 8d 35 56 17 00 00 	lea    0x1756(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    aa73:	48 8d 05 4e 17 00 00 	lea    0x174e(%rip),%rax        # c1c8 <_IO_stdin_used+0x1c8>
    aa7a:	4c 89 e7             	mov    %r12,%rdi
    aa7d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aa81:	48 0f 46 f0          	cmovbe %rax,%rsi
    aa85:	e8 66 89 ff ff       	call   33f0 <strcpy@plt>
    aa8a:	e9 71 f2 ff ff       	jmp    9d00 <fwp_write+0x80>
    aa8f:	90                   	nop
    aa90:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa94:	48 8d 35 2e 17 00 00 	lea    0x172e(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    aa9b:	48 8d 05 26 17 00 00 	lea    0x1726(%rip),%rax        # c1c8 <_IO_stdin_used+0x1c8>
    aaa2:	0f 2f c8             	comiss %xmm0,%xmm1
    aaa5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aaac:	00 
    aaad:	4c 89 e7             	mov    %r12,%rdi
    aab0:	48 0f 46 f0          	cmovbe %rax,%rsi
    aab4:	e8 37 89 ff ff       	call   33f0 <strcpy@plt>
    aab9:	e9 42 f2 ff ff       	jmp    9d00 <fwp_write+0x80>
    aabe:	66 90                	xchg   %ax,%ax
    aac0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aac5:	45 85 c0             	test   %r8d,%r8d
    aac8:	75 34                	jne    aafe <fwp_write+0xe7e>
    aaca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aad1:	00 
    aad2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aad9:	00 00 
    aadb:	0f 85 74 f6 ff ff    	jne    a155 <fwp_write+0x4d5>
    aae1:	ba 02 00 00 00       	mov    $0x2,%edx
    aae6:	48 8d 35 52 17 00 00 	lea    0x1752(%rip),%rsi        # c23f <_IO_stdin_used+0x23f>
    aaed:	e9 a1 f3 ff ff       	jmp    9e93 <fwp_write+0x213>
    aaf2:	48 03 75 10          	add    0x10(%rbp),%rsi
    aaf6:	49 89 f0             	mov    %rsi,%r8
    aaf9:	e9 e5 fc ff ff       	jmp    a7e3 <fwp_write+0xb63>
    aafe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab03:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab08:	85 ff                	test   %edi,%edi
    ab0a:	0f 84 fa f3 ff ff    	je     9f0a <fwp_write+0x28a>
    ab10:	ba 01 00 00 00       	mov    $0x1,%edx
    ab15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab1a:	48 89 df             	mov    %rbx,%rdi
    ab1d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab22:	e8 e9 96 ff ff       	call   4210 <buf_put>
    ab27:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab2c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab31:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ab37:	85 c0                	test   %eax,%eax
    ab39:	0f 8f f0 f3 ff ff    	jg     9f2f <fwp_write+0x2af>
    ab3f:	e9 34 f4 ff ff       	jmp    9f78 <fwp_write+0x2f8>
    ab44:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab48:	49 89 c5             	mov    %rax,%r13
    ab4b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab50:	49 89 c4             	mov    %rax,%r12
    ab53:	49 c1 fd 3f          	sar    $0x3f,%r13
    ab57:	4c 09 e8             	or     %r13,%rax
    ab5a:	0f 84 a7 00 00 00    	je     ac07 <fwp_write+0xf87>
    ab60:	48 8d 2d 99 38 00 00 	lea    0x3899(%rip),%rbp        # e400 <units.1>
    ab67:	4d 89 e7             	mov    %r12,%r15
    ab6a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab6e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ab73:	4c 89 ff             	mov    %r15,%rdi
    ab76:	4c 89 ee             	mov    %r13,%rsi
    ab79:	44 89 0c 24          	mov    %r9d,(%rsp)
    ab7d:	48 99                	cqto
    ab7f:	48 89 d1             	mov    %rdx,%rcx
    ab82:	48 89 c2             	mov    %rax,%rdx
    ab85:	e8 f6 0f 00 00       	call   bb80 <__divmodti4>
    ab8a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ab8e:	48 89 c1             	mov    %rax,%rcx
    ab91:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ab96:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ab9b:	0f 84 94 00 00 00    	je     ac35 <fwp_write+0xfb5>
    aba1:	41 83 c1 01          	add    $0x1,%r9d
    aba5:	48 83 c5 10          	add    $0x10,%rbp
    aba9:	41 83 f9 05          	cmp    $0x5,%r9d
    abad:	75 bb                	jne    ab6a <fwp_write+0xeea>
    abaf:	4d 85 ed             	test   %r13,%r13
    abb2:	79 53                	jns    ac07 <fwp_write+0xf87>
    abb4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    abb9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    abbe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    abc3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    abc8:	48 99                	cqto
    abca:	48 f7 d8             	neg    %rax
    abcd:	48 83 d2 00          	adc    $0x0,%rdx
    abd1:	48 89 c6             	mov    %rax,%rsi
    abd4:	48 f7 da             	neg    %rdx
    abd7:	e8 64 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abdc:	49 89 e8             	mov    %rbp,%r8
    abdf:	ba 00 02 00 00       	mov    $0x200,%edx
    abe4:	be 02 00 00 00       	mov    $0x2,%esi
    abe9:	31 c0                	xor    %eax,%eax
    abeb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    abf2:	00 
    abf3:	48 8d 0d 40 16 00 00 	lea    0x1640(%rip),%rcx        # c23a <_IO_stdin_used+0x23a>
    abfa:	4c 89 e7             	mov    %r12,%rdi
    abfd:	e8 de 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac02:	e9 f9 f0 ff ff       	jmp    9d00 <fwp_write+0x80>
    ac07:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac0c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac11:	31 d2                	xor    %edx,%edx
    ac13:	48 89 ef             	mov    %rbp,%rdi
    ac16:	e8 25 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac1b:	eb bf                	jmp    abdc <fwp_write+0xf5c>
    ac1d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac24:	4e 61 4e 00 
    ac28:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac2f:	00 
    ac30:	e9 cb f0 ff ff       	jmp    9d00 <fwp_write+0x80>
    ac35:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac39:	48 89 c8             	mov    %rcx,%rax
    ac3c:	48 85 d2             	test   %rdx,%rdx
    ac3f:	78 51                	js     ac92 <fwp_write+0x1012>
    ac41:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac46:	48 89 c6             	mov    %rax,%rsi
    ac49:	48 89 ef             	mov    %rbp,%rdi
    ac4c:	e8 ef 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac51:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac55:	49 63 c1             	movslq %r9d,%rax
    ac58:	49 89 e8             	mov    %rbp,%r8
    ac5b:	ba 00 02 00 00       	mov    $0x200,%edx
    ac60:	be 02 00 00 00       	mov    $0x2,%esi
    ac65:	48 c1 e0 04          	shl    $0x4,%rax
    ac69:	48 8d 3d 90 37 00 00 	lea    0x3790(%rip),%rdi        # e400 <units.1>
    ac70:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac77:	00 
    ac78:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ac7c:	48 8d 0d b2 15 00 00 	lea    0x15b2(%rip),%rcx        # c235 <_IO_stdin_used+0x235>
    ac83:	4c 89 e7             	mov    %r12,%rdi
    ac86:	31 c0                	xor    %eax,%eax
    ac88:	e8 53 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac8d:	e9 6e f0 ff ff       	jmp    9d00 <fwp_write+0x80>
    ac92:	48 f7 d8             	neg    %rax
    ac95:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ac9a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ac9f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aca4:	48 83 d2 00          	adc    $0x0,%rdx
    aca8:	48 89 c6             	mov    %rax,%rsi
    acab:	48 f7 da             	neg    %rdx
    acae:	e8 8d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acb3:	44 8b 0c 24          	mov    (%rsp),%r9d
    acb7:	eb 9c                	jmp    ac55 <fwp_write+0xfd5>
    acb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000acc0 <fwp_main_thread>:
    acc0:	f3 0f 1e fa          	endbr64
    acc4:	41 57                	push   %r15
    acc6:	41 56                	push   %r14
    acc8:	41 55                	push   %r13
    acca:	41 54                	push   %r12
    accc:	55                   	push   %rbp
    accd:	53                   	push   %rbx
    acce:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    acd5:	8b 3d 89 6e 01 00    	mov    0x16e89(%rip),%edi        # 21b64 <fwp_heap+0x13a4>
    acdb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ace2:	00 00 
    ace4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    aceb:	00 
    acec:	31 c0                	xor    %eax,%eax
    acee:	85 ff                	test   %edi,%edi
    acf0:	0f 84 5a 08 00 00    	je     b550 <fwp_main_thread+0x890>
    acf6:	8b 35 6c 6e 01 00    	mov    0x16e6c(%rip),%esi        # 21b68 <fwp_heap+0x13a8>
    acfc:	85 f6                	test   %esi,%esi
    acfe:	0f 85 34 08 00 00    	jne    b538 <fwp_main_thread+0x878>
    ad04:	48 8d 05 75 53 00 00 	lea    0x5375(%rip),%rax        # 10080 <alt.5>
    ad0b:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    ad10:	31 f6                	xor    %esi,%esi
    ad12:	48 c7 05 33 54 01 00 	movq   $0x40000000,0x15433(%rip)        # 20150 <fwp_main_stack_size>
    ad19:	00 00 00 40 
    ad1d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    ad22:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    ad27:	48 89 c7             	mov    %rax,%rdi
    ad2a:	48 89 1d 27 54 01 00 	mov    %rbx,0x15427(%rip)        # 20158 <fwp_main_stack_top>
    ad31:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    ad38:	01 00 
    ad3a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    ad41:	00 
    ad42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad47:	e8 74 89 ff ff       	call   36c0 <sigaltstack@plt>
    ad4c:	85 c0                	test   %eax,%eax
    ad4e:	0f 85 e7 0d 00 00    	jne    bb3b <fwp_main_thread+0xe7b>
    ad54:	31 c0                	xor    %eax,%eax
    ad56:	b9 12 00 00 00       	mov    $0x12,%ecx
    ad5b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad62:	00 
    ad63:	f3 48 ab             	rep stos %rax,(%rdi)
    ad66:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
    ad6d:	00 
    ad6e:	48 8d 05 7b 8f ff ff 	lea    -0x7085(%rip),%rax        # 3cf0 <fwp_segv>
    ad75:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    ad7c:	04 00 00 08 
    ad80:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad87:	00 
    ad88:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    ad8d:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ad94:	00 
    ad95:	e8 e6 87 ff ff       	call   3580 <sigemptyset@plt>
    ad9a:	85 c0                	test   %eax,%eax
    ad9c:	0f 85 99 0d 00 00    	jne    bb3b <fwp_main_thread+0xe7b>
    ada2:	31 d2                	xor    %edx,%edx
    ada4:	4c 89 f6             	mov    %r14,%rsi
    ada7:	bf 0b 00 00 00       	mov    $0xb,%edi
    adac:	e8 4f 86 ff ff       	call   3400 <sigaction@plt>
    adb1:	85 c0                	test   %eax,%eax
    adb3:	0f 85 82 0d 00 00    	jne    bb3b <fwp_main_thread+0xe7b>
    adb9:	31 d2                	xor    %edx,%edx
    adbb:	4c 89 f6             	mov    %r14,%rsi
    adbe:	bf 07 00 00 00       	mov    $0x7,%edi
    adc3:	e8 38 86 ff ff       	call   3400 <sigaction@plt>
    adc8:	85 c0                	test   %eax,%eax
    adca:	0f 85 6b 0d 00 00    	jne    bb3b <fwp_main_thread+0xe7b>
    add0:	8b 0d 22 53 01 00    	mov    0x15322(%rip),%ecx        # 200f8 <descent_registered>
    add6:	85 c9                	test   %ecx,%ecx
    add8:	0f 84 6a 05 00 00    	je     b348 <fwp_main_thread+0x688>
    adde:	8b 15 8c 52 00 00    	mov    0x528c(%rip),%edx        # 10070 <st.3>
    ade4:	85 d2                	test   %edx,%edx
    ade6:	0f 84 88 05 00 00    	je     b374 <fwp_main_thread+0x6b4>
    adec:	48 8b 2d ad 59 01 00 	mov    0x159ad(%rip),%rbp        # 207a0 <fwp_cur>
    adf3:	48 85 ed             	test   %rbp,%rbp
    adf6:	0f 84 c4 01 00 00    	je     afc0 <fwp_main_thread+0x300>
    adfc:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ae01:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ae05:	48 89 eb             	mov    %rbp,%rbx
    ae08:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ae0d:	0f 84 41 01 00 00    	je     af54 <fwp_main_thread+0x294>
    ae13:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ae18:	0f 84 a2 02 00 00    	je     b0c0 <fwp_main_thread+0x400>
    ae1e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ae22:	0f 84 78 02 00 00    	je     b0a0 <fwp_main_thread+0x3e0>
    ae28:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ae2c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae30:	0f 85 0a 03 00 00    	jne    b140 <fwp_main_thread+0x480>
    ae36:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ae3a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae41:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ae45:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae4c:	00 00 00 00 
    ae50:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ae57:	48 85 d2             	test   %rdx,%rdx
    ae5a:	74 07                	je     ae63 <fwp_main_thread+0x1a3>
    ae5c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ae63:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ae67:	48 85 c0             	test   %rax,%rax
    ae6a:	74 34                	je     aea0 <fwp_main_thread+0x1e0>
    ae6c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ae70:	48 8b 05 01 59 01 00 	mov    0x15901(%rip),%rax        # 20778 <fwp_timers>
    ae77:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ae7b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ae82:	00 00 00 00 
    ae86:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ae8d:	48 85 c0             	test   %rax,%rax
    ae90:	74 07                	je     ae99 <fwp_main_thread+0x1d9>
    ae92:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ae99:	48 89 1d d8 58 01 00 	mov    %rbx,0x158d8(%rip)        # 20778 <fwp_timers>
    aea0:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    aea4:	e8 47 c3 ff ff       	call   71f0 <fwp_block>
    aea9:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    aeb0:	48 85 c9             	test   %rcx,%rcx
    aeb3:	74 47                	je     aefc <fwp_main_thread+0x23c>
    aeb5:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    aebc:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    aec3:	48 85 d2             	test   %rdx,%rdx
    aec6:	0f 84 b4 02 00 00    	je     b180 <fwp_main_thread+0x4c0>
    aecc:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    aed3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    aeda:	48 85 c0             	test   %rax,%rax
    aedd:	74 07                	je     aee6 <fwp_main_thread+0x226>
    aedf:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    aee6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    aeed:	00 00 00 00 
    aef1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    aef5:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    aefc:	48 8b 0d 9d 58 01 00 	mov    0x1589d(%rip),%rcx        # 207a0 <fwp_cur>
    af03:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    af07:	0f 84 23 02 00 00    	je     b130 <fwp_main_thread+0x470>
    af0d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    af14:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    af1b:	48 85 d2             	test   %rdx,%rdx
    af1e:	0f 84 14 04 00 00    	je     b338 <fwp_main_thread+0x678>
    af24:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    af2b:	48 85 c0             	test   %rax,%rax
    af2e:	74 07                	je     af37 <fwp_main_thread+0x277>
    af30:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    af37:	66 0f ef d2          	pxor   %xmm2,%xmm2
    af3b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    af3f:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    af46:	48 89 cb             	mov    %rcx,%rbx
    af49:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    af4e:	0f 85 bf fe ff ff    	jne    ae13 <fwp_main_thread+0x153>
    af54:	48 83 3d dc 74 01 00 	cmpq   $0x0,0x174dc(%rip)        # 22438 <fwp_state_len>
    af5b:	00 
    af5c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    af60:	74 6e                	je     afd0 <fwp_main_thread+0x310>
    af62:	48 39 1d 2f 58 01 00 	cmp    %rbx,0x1582f(%rip)        # 20798 <fwp_root>
    af69:	c7 05 0d 51 01 00 00 	movl   $0x0,0x1510d(%rip)        # 20080 <fwp_exit_code>
    af70:	00 00 00 
    af73:	0f 85 f5 0b 00 00    	jne    bb6e <fwp_main_thread+0xeae>
    af79:	48 85 db             	test   %rbx,%rbx
    af7c:	0f 84 26 02 00 00    	je     b1a8 <fwp_main_thread+0x4e8>
    af82:	48 8b 15 df 57 01 00 	mov    0x157df(%rip),%rdx        # 20768 <fwp_tasks_active>
    af89:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    af8d:	48 85 d2             	test   %rdx,%rdx
    af90:	0f 84 12 02 00 00    	je     b1a8 <fwp_main_thread+0x4e8>
    af96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    af9d:	00 00 00 
    afa0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    afa4:	75 08                	jne    afae <fwp_main_thread+0x2ee>
    afa6:	48 89 d7             	mov    %rdx,%rdi
    afa9:	e8 52 93 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    afae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    afb5:	48 85 d2             	test   %rdx,%rdx
    afb8:	75 e6                	jne    afa0 <fwp_main_thread+0x2e0>
    afba:	e9 ae 00 00 00       	jmp    b06d <fwp_main_thread+0x3ad>
    afbf:	90                   	nop
    afc0:	48 83 3d 70 74 01 00 	cmpq   $0x0,0x17470(%rip)        # 22438 <fwp_state_len>
    afc7:	00 
    afc8:	0f 85 c2 01 00 00    	jne    b190 <fwp_main_thread+0x4d0>
    afce:	31 db                	xor    %ebx,%ebx
    afd0:	48 83 3d 50 74 01 00 	cmpq   $0x0,0x17450(%rip)        # 22428 <fwp_state_owners>
    afd7:	00 
    afd8:	75 88                	jne    af62 <fwp_main_thread+0x2a2>
    afda:	48 8b 3d 5f 74 01 00 	mov    0x1745f(%rip),%rdi        # 22440 <fwp_state>
    afe1:	e8 aa a7 ff ff       	call   5790 <fwp_mem_free>
    afe6:	48 c7 05 4f 74 01 00 	movq   $0x0,0x1744f(%rip)        # 22440 <fwp_state>
    afed:	00 00 00 00 
    aff1:	48 c7 05 34 74 01 00 	movq   $0x0,0x17434(%rip)        # 22430 <fwp_state_cap>
    aff8:	00 00 00 00 
    affc:	48 85 db             	test   %rbx,%rbx
    afff:	0f 84 3e 0a 00 00    	je     ba43 <fwp_main_thread+0xd83>
    b005:	48 39 1d 8c 57 01 00 	cmp    %rbx,0x1578c(%rip)        # 20798 <fwp_root>
    b00c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b013:	00 00 00 00 
    b017:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b01e:	00 00 00 00 
    b022:	c7 05 54 50 01 00 00 	movl   $0x0,0x15054(%rip)        # 20080 <fwp_exit_code>
    b029:	00 00 00 
    b02c:	0f 84 50 ff ff ff    	je     af82 <fwp_main_thread+0x2c2>
    b032:	e9 19 87 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b03e:	00 00 
    b040:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b047:	48 89 1d 32 57 01 00 	mov    %rbx,0x15732(%rip)        # 20780 <fwp_ready_tail>
    b04e:	e8 9d c1 ff ff       	call   71f0 <fwp_block>
    b053:	e8 98 bf ff ff       	call   6ff0 <fwp_free_zombie>
    b058:	48 83 3d 08 57 01 00 	cmpq   $0x0,0x15708(%rip)        # 20768 <fwp_tasks_active>
    b05f:	00 
    b060:	0f 84 42 01 00 00    	je     b1a8 <fwp_main_thread+0x4e8>
    b066:	48 8b 1d 2b 57 01 00 	mov    0x1572b(%rip),%rbx        # 20798 <fwp_root>
    b06d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b071:	75 db                	jne    b04e <fwp_main_thread+0x38e>
    b073:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b077:	75 d5                	jne    b04e <fwp_main_thread+0x38e>
    b079:	48 8b 05 00 57 01 00 	mov    0x15700(%rip),%rax        # 20780 <fwp_ready_tail>
    b080:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b084:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b08b:	00 00 00 00 
    b08f:	48 85 c0             	test   %rax,%rax
    b092:	75 ac                	jne    b040 <fwp_main_thread+0x380>
    b094:	48 89 1d ed 56 01 00 	mov    %rbx,0x156ed(%rip)        # 20788 <fwp_ready_head>
    b09b:	eb aa                	jmp    b047 <fwp_main_thread+0x387>
    b09d:	0f 1f 00             	nopl   (%rax)
    b0a0:	e8 bb 94 ff ff       	call   4560 <fwp_now_ns>
    b0a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b0a9:	7c 15                	jl     b0c0 <fwp_main_thread+0x400>
    b0ab:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b0af:	75 0f                	jne    b0c0 <fwp_main_thread+0x400>
    b0b1:	48 89 ef             	mov    %rbp,%rdi
    b0b4:	e8 47 92 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b0b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b0c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b0c4:	0f 85 5e fd ff ff    	jne    ae28 <fwp_main_thread+0x168>
    b0ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b0ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b0d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b0d6:	0f 85 5e fd ff ff    	jne    ae3a <fwp_main_thread+0x17a>
    b0dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b0e0:	48 85 c9             	test   %rcx,%rcx
    b0e3:	0f 84 51 fd ff ff    	je     ae3a <fwp_main_thread+0x17a>
    b0e9:	48 39 c8             	cmp    %rcx,%rax
    b0ec:	48 89 ce             	mov    %rcx,%rsi
    b0ef:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b0f6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b0fa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b101:	00 00 00 00 
    b105:	48 0f 4e f0          	cmovle %rax,%rsi
    b109:	48 85 c0             	test   %rax,%rax
    b10c:	48 89 c8             	mov    %rcx,%rax
    b10f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b116:	48 0f 45 c6          	cmovne %rsi,%rax
    b11a:	48 85 d2             	test   %rdx,%rdx
    b11d:	74 07                	je     b126 <fwp_main_thread+0x466>
    b11f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b126:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b12a:	e9 3d fd ff ff       	jmp    ae6c <fwp_main_thread+0x1ac>
    b12f:	90                   	nop
    b130:	48 89 cb             	mov    %rcx,%rbx
    b133:	e9 d0 fc ff ff       	jmp    ae08 <fwp_main_thread+0x148>
    b138:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b13f:	00 
    b140:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b144:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b14b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b152:	00 00 00 00 
    b156:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b15d:	48 85 c0             	test   %rax,%rax
    b160:	0f 84 5a 08 00 00    	je     b9c0 <fwp_main_thread+0xd00>
    b166:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b16d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b171:	e9 2a fd ff ff       	jmp    aea0 <fwp_main_thread+0x1e0>
    b176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b17d:	00 00 00 
    b180:	48 89 01             	mov    %rax,(%rcx)
    b183:	e9 52 fd ff ff       	jmp    aeda <fwp_main_thread+0x21a>
    b188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b18f:	00 
    b190:	48 83 3d 00 56 01 00 	cmpq   $0x0,0x15600(%rip)        # 20798 <fwp_root>
    b197:	00 
    b198:	c7 05 de 4e 01 00 00 	movl   $0x0,0x14ede(%rip)        # 20080 <fwp_exit_code>
    b19f:	00 00 00 
    b1a2:	0f 85 cb 09 00 00    	jne    bb73 <fwp_main_thread+0xeb3>
    b1a8:	e8 43 be ff ff       	call   6ff0 <fwp_free_zombie>
    b1ad:	48 83 3d d3 55 01 00 	cmpq   $0x0,0x155d3(%rip)        # 20788 <fwp_ready_head>
    b1b4:	00 
    b1b5:	0f 85 95 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1bb:	48 83 3d b5 55 01 00 	cmpq   $0x0,0x155b5(%rip)        # 20778 <fwp_timers>
    b1c2:	00 
    b1c3:	0f 85 87 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1c9:	8b 05 95 4f 01 00    	mov    0x14f95(%rip),%eax        # 20164 <fwp_stack_pool_n>
    b1cf:	85 c0                	test   %eax,%eax
    b1d1:	74 3a                	je     b20d <fwp_main_thread+0x54d>
    b1d3:	83 e8 01             	sub    $0x1,%eax
    b1d6:	4c 8d 25 a3 4f 01 00 	lea    0x14fa3(%rip),%r12        # 20180 <fwp_stack_pool>
    b1dd:	48 63 d8             	movslq %eax,%rbx
    b1e0:	89 c0                	mov    %eax,%eax
    b1e2:	48 89 da             	mov    %rbx,%rdx
    b1e5:	48 29 c2             	sub    %rax,%rdx
    b1e8:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    b1f0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b1f4:	89 1d 6a 4f 01 00    	mov    %ebx,0x14f6a(%rip)        # 20164 <fwp_stack_pool_n>
    b1fa:	be 00 00 00 10       	mov    $0x10000000,%esi
    b1ff:	48 83 eb 01          	sub    $0x1,%rbx
    b203:	e8 d8 83 ff ff       	call   35e0 <munmap@plt>
    b208:	48 39 dd             	cmp    %rbx,%rbp
    b20b:	75 e3                	jne    b1f0 <fwp_main_thread+0x530>
    b20d:	8b 3d 09 4e 00 00    	mov    0x4e09(%rip),%edi        # 1001c <fwp_epfd>
    b213:	85 ff                	test   %edi,%edi
    b215:	78 05                	js     b21c <fwp_main_thread+0x55c>
    b217:	e8 b4 82 ff ff       	call   34d0 <close@plt>
    b21c:	4c 8b 25 5d 51 01 00 	mov    0x1515d(%rip),%r12        # 20380 <fwp_nfdws>
    b223:	48 8b 2d 5e 51 01 00 	mov    0x1515e(%rip),%rbp        # 20388 <fwp_fdws>
    b22a:	31 db                	xor    %ebx,%ebx
    b22c:	c7 05 e6 4d 00 00 ff 	movl   $0xffffffff,0x4de6(%rip)        # 1001c <fwp_epfd>
    b233:	ff ff ff 
    b236:	4d 85 e4             	test   %r12,%r12
    b239:	74 32                	je     b26d <fwp_main_thread+0x5ad>
    b23b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b240:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b245:	48 85 ff             	test   %rdi,%rdi
    b248:	74 1a                	je     b264 <fwp_main_thread+0x5a4>
    b24a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b24e:	0f 85 fc 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b254:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b259:	0f 85 f1 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b25f:	e8 2c a5 ff ff       	call   5790 <fwp_mem_free>
    b264:	48 83 c3 01          	add    $0x1,%rbx
    b268:	49 39 dc             	cmp    %rbx,%r12
    b26b:	75 d3                	jne    b240 <fwp_main_thread+0x580>
    b26d:	48 89 ef             	mov    %rbp,%rdi
    b270:	e8 1b a5 ff ff       	call   5790 <fwp_mem_free>
    b275:	48 8b 15 1c 55 01 00 	mov    0x1551c(%rip),%rdx        # 20798 <fwp_root>
    b27c:	48 c7 05 01 51 01 00 	movq   $0x0,0x15101(%rip)        # 20388 <fwp_fdws>
    b283:	00 00 00 00 
    b287:	48 c7 05 ee 50 01 00 	movq   $0x0,0x150ee(%rip)        # 20380 <fwp_nfdws>
    b28e:	00 00 00 00 
    b292:	48 85 d2             	test   %rdx,%rdx
    b295:	74 4e                	je     b2e5 <fwp_main_thread+0x625>
    b297:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b29c:	0f 85 ae 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b2a9:	00 
    b2aa:	0f 85 a0 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2b0:	48 83 3d 80 71 01 00 	cmpq   $0x0,0x17180(%rip)        # 22438 <fwp_state_len>
    b2b7:	00 
    b2b8:	0f 85 92 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2be:	48 83 3d 62 71 01 00 	cmpq   $0x0,0x17162(%rip)        # 22428 <fwp_state_owners>
    b2c5:	00 
    b2c6:	0f 85 84 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b2d1:	31 c0                	xor    %eax,%eax
    b2d3:	48 8d 3d c6 50 01 00 	lea    0x150c6(%rip),%rdi        # 203a0 <fwp_root_context>
    b2da:	f3 48 ab             	rep stos %rax,(%rdi)
    b2dd:	48 89 d7             	mov    %rdx,%rdi
    b2e0:	e8 ab a4 ff ff       	call   5790 <fwp_mem_free>
    b2e5:	48 8b 3d 34 4d 00 00 	mov    0x4d34(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b2ec:	48 c7 05 a9 54 01 00 	movq   $0x0,0x154a9(%rip)        # 207a0 <fwp_cur>
    b2f3:	00 00 00 00 
    b2f7:	48 c7 05 96 54 01 00 	movq   $0x0,0x15496(%rip)        # 20798 <fwp_root>
    b2fe:	00 00 00 00 
    b302:	e8 b9 82 ff ff       	call   35c0 <fflush@plt>
    b307:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b30e:	00 
    b30f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b316:	00 00 
    b318:	0f 85 3f 08 00 00    	jne    bb5d <fwp_main_thread+0xe9d>
    b31e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b325:	31 c0                	xor    %eax,%eax
    b327:	5b                   	pop    %rbx
    b328:	5d                   	pop    %rbp
    b329:	41 5c                	pop    %r12
    b32b:	41 5d                	pop    %r13
    b32d:	41 5e                	pop    %r14
    b32f:	41 5f                	pop    %r15
    b331:	c3                   	ret
    b332:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b338:	48 89 05 39 54 01 00 	mov    %rax,0x15439(%rip)        # 20778 <fwp_timers>
    b33f:	e9 e7 fb ff ff       	jmp    af2b <fwp_main_thread+0x26b>
    b344:	0f 1f 40 00          	nopl   0x0(%rax)
    b348:	48 8d 3d c1 8a ff ff 	lea    -0x753f(%rip),%rdi        # 3e10 <descent_phase_report>
    b34f:	e8 3c 0a 00 00       	call   bd90 <atexit>
    b354:	85 c0                	test   %eax,%eax
    b356:	0f 85 fc 07 00 00    	jne    bb58 <fwp_main_thread+0xe98>
    b35c:	c7 05 92 4d 01 00 01 	movl   $0x1,0x14d92(%rip)        # 200f8 <descent_registered>
    b363:	00 00 00 
    b366:	8b 15 04 4d 00 00    	mov    0x4d04(%rip),%edx        # 10070 <st.3>
    b36c:	85 d2                	test   %edx,%edx
    b36e:	0f 85 78 fa ff ff    	jne    adec <fwp_main_thread+0x12c>
    b374:	48 8d 05 b5 b5 ff ff 	lea    -0x4a4b(%rip),%rax        # 6930 <fwp_drop1>
    b37b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b37f:	4c 8b 35 5a 18 00 00 	mov    0x185a(%rip),%r14        # cbe0 <msg.4+0x70>
    b386:	31 ed                	xor    %ebp,%ebp
    b388:	66 48 0f 6e d8       	movq   %rax,%xmm3
    b38d:	48 8b 05 c4 70 01 00 	mov    0x170c4(%rip),%rax        # 22458 <fwp_cleanups>
    b394:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b39b:	00 00 
    b39d:	41 bf ff 7f 00 00    	mov    $0x7fff,%r15d
    b3a3:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    b3a7:	48 89 1d aa 70 01 00 	mov    %rbx,0x170aa(%rip)        # 22458 <fwp_cleanups>
    b3ae:	48 8d 1d 0b 54 01 00 	lea    0x1540b(%rip),%rbx        # 207c0 <fwp_heap>
    b3b5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b3ba:	48 8d 05 0f 88 ff ff 	lea    -0x77f1(%rip),%rax        # 3bd0 <fwp_range_release>
    b3c1:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b3c6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b3cb:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b3d0:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b3d5:	e9 03 01 00 00       	jmp    b4dd <fwp_main_thread+0x81d>
    b3da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b3e0:	49 8b 14 24          	mov    (%r12),%rdx
    b3e4:	48 f7 d2             	not    %rdx
    b3e7:	48 89 10             	mov    %rdx,(%rax)
    b3ea:	49 83 fd 18          	cmp    $0x18,%r13
    b3ee:	76 1c                	jbe    b40c <fwp_main_thread+0x74c>
    b3f0:	49 8d 45 e7          	lea    -0x19(%r13),%rax
    b3f4:	49 8d 7c 24 18       	lea    0x18(%r12),%rdi
    b3f9:	31 f6                	xor    %esi,%esi
    b3fb:	48 c1 e8 03          	shr    $0x3,%rax
    b3ff:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b406:	00 
    b407:	e8 b4 80 ff ff       	call   34c0 <memset@plt>
    b40c:	4c 89 e8             	mov    %r13,%rax
    b40f:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    b416:	0f 82 2b 07 00 00    	jb     bb47 <fwp_main_thread+0xe87>
    b41c:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    b423:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    b42a:	73 07                	jae    b433 <fwp_main_thread+0x773>
    b42c:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    b433:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b437:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    b43c:	f2 0f 58 83 38 14 00 	addsd  0x1438(%rbx),%xmm0
    b443:	00 
    b444:	f2 0f 11 83 38 14 00 	movsd  %xmm0,0x1438(%rbx)
    b44b:	00 
    b44c:	49 89 6c 24 10       	mov    %rbp,0x10(%r12)
    b451:	4c 89 e0             	mov    %r12,%rax
    b454:	4c 89 e5             	mov    %r12,%rbp
    b457:	4d 89 34 24          	mov    %r14,(%r12)
    b45b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
    b460:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b467:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b46e:	48 c1 e2 10          	shl    $0x10,%rdx
    b472:	48 39 d0             	cmp    %rdx,%rax
    b475:	73 57                	jae    b4ce <fwp_main_thread+0x80e>
    b477:	48 89 c2             	mov    %rax,%rdx
    b47a:	48 c1 ea 10          	shr    $0x10,%rdx
    b47e:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b482:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b489:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b48d:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b491:	48 85 d2             	test   %rdx,%rdx
    b494:	74 38                	je     b4ce <fwp_main_thread+0x80e>
    b496:	0f b6 3e             	movzbl (%rsi),%edi
    b499:	40 80 ff 02          	cmp    $0x2,%dil
    b49d:	0f 84 d5 00 00 00    	je     b578 <fwp_main_thread+0x8b8>
    b4a3:	40 80 ff 01          	cmp    $0x1,%dil
    b4a7:	75 25                	jne    b4ce <fwp_main_thread+0x80e>
    b4a9:	8b 7e 18             	mov    0x18(%rsi),%edi
    b4ac:	0f b7 c0             	movzwl %ax,%eax
    b4af:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b4b2:	48 0f af c7          	imul   %rdi,%rax
    b4b6:	48 c1 e8 20          	shr    $0x20,%rax
    b4ba:	48 39 f0             	cmp    %rsi,%rax
    b4bd:	73 0f                	jae    b4ce <fwp_main_thread+0x80e>
    b4bf:	48 01 c2             	add    %rax,%rdx
    b4c2:	80 3a ff             	cmpb   $0xff,(%rdx)
    b4c5:	0f 84 45 05 00 00    	je     ba10 <fwp_main_thread+0xd50>
    b4cb:	c6 02 01             	movb   $0x1,(%rdx)
    b4ce:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b4d3:	49 83 ef 01          	sub    $0x1,%r15
    b4d7:	0f 82 b3 00 00 00    	jb     b590 <fwp_main_thread+0x8d0>
    b4dd:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b4e3:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
    b4e8:	85 c0                	test   %eax,%eax
    b4ea:	74 74                	je     b560 <fwp_main_thread+0x8a0>
    b4ec:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    b4f3:	44 8b ac 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r13d
    b4fa:	00 
    b4fb:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b4ff:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    b503:	4c 8b 20             	mov    (%rax),%r12
    b506:	4d 85 e4             	test   %r12,%r12
    b509:	0f 85 d1 fe ff ff    	jne    b3e0 <fwp_main_thread+0x720>
    b50f:	4c 8b 60 08          	mov    0x8(%rax),%r12
    b513:	4d 85 e4             	test   %r12,%r12
    b516:	74 48                	je     b560 <fwp_main_thread+0x8a0>
    b518:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b51c:	4c 29 e2             	sub    %r12,%rdx
    b51f:	4c 39 ea             	cmp    %r13,%rdx
    b522:	72 3c                	jb     b560 <fwp_main_thread+0x8a0>
    b524:	4b 8d 14 2c          	lea    (%r12,%r13,1),%rdx
    b528:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b52c:	e9 b9 fe ff ff       	jmp    b3ea <fwp_main_thread+0x72a>
    b531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b538:	48 8d 3d 21 97 ff ff 	lea    -0x68df(%rip),%rdi        # 4c60 <fwp_heap_report>
    b53f:	e8 4c 08 00 00       	call   bd90 <atexit>
    b544:	e9 bb f7 ff ff       	jmp    ad04 <fwp_main_thread+0x44>
    b549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b550:	e8 1b 98 ff ff       	call   4d70 <fwp_heap_init>
    b555:	e9 9c f7 ff ff       	jmp    acf6 <fwp_main_thread+0x36>
    b55a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b560:	31 f6                	xor    %esi,%esi
    b562:	bf 18 00 00 00       	mov    $0x18,%edi
    b567:	e8 24 a7 ff ff       	call   5c90 <fwp_heap_alloc>
    b56c:	49 89 c4             	mov    %rax,%r12
    b56f:	e9 d8 fe ff ff       	jmp    b44c <fwp_main_thread+0x78c>
    b574:	0f 1f 40 00          	nopl   0x0(%rax)
    b578:	66 85 c0             	test   %ax,%ax
    b57b:	0f 84 41 ff ff ff    	je     b4c2 <fwp_main_thread+0x802>
    b581:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b586:	49 83 ef 01          	sub    $0x1,%r15
    b58a:	0f 83 4d ff ff ff    	jae    b4dd <fwp_main_thread+0x81d>
    b590:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b595:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b59a:	bf 01 00 00 00       	mov    $0x1,%edi
    b59f:	66 0f 6f 05 69 16 00 	movdqa 0x1669(%rip),%xmm0        # cc10 <msg.4+0xa0>
    b5a6:	00 
    b5a7:	48 89 05 aa 6e 01 00 	mov    %rax,0x16eaa(%rip)        # 22458 <fwp_cleanups>
    b5ae:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b5b5:	00 
    b5b6:	e8 25 af ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b5bb:	48 8b 15 d6 65 01 00 	mov    0x165d6(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b5c2:	49 89 c6             	mov    %rax,%r14
    b5c5:	48 2b 05 a4 65 01 00 	sub    0x165a4(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    b5cc:	48 c1 e2 10          	shl    $0x10,%rdx
    b5d0:	48 39 d0             	cmp    %rdx,%rax
    b5d3:	73 59                	jae    b62e <fwp_main_thread+0x96e>
    b5d5:	48 89 c2             	mov    %rax,%rdx
    b5d8:	48 c1 ea 10          	shr    $0x10,%rdx
    b5dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5e0:	48 8b 15 d1 65 01 00 	mov    0x165d1(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    b5e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5eb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b5ef:	4d 85 ed             	test   %r13,%r13
    b5f2:	74 3a                	je     b62e <fwp_main_thread+0x96e>
    b5f4:	0f b6 0a             	movzbl (%rdx),%ecx
    b5f7:	80 f9 02             	cmp    $0x2,%cl
    b5fa:	0f 84 e0 03 00 00    	je     b9e0 <fwp_main_thread+0xd20>
    b600:	80 f9 01             	cmp    $0x1,%cl
    b603:	75 29                	jne    b62e <fwp_main_thread+0x96e>
    b605:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b608:	0f b7 c0             	movzwl %ax,%eax
    b60b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b60e:	48 0f af c1          	imul   %rcx,%rax
    b612:	48 c1 e8 20          	shr    $0x20,%rax
    b616:	48 39 d0             	cmp    %rdx,%rax
    b619:	73 13                	jae    b62e <fwp_main_thread+0x96e>
    b61b:	49 01 c5             	add    %rax,%r13
    b61e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b623:	0f 84 6e 04 00 00    	je     ba97 <fwp_main_thread+0xdd7>
    b629:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b62e:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b633:	bf 01 00 00 00       	mov    $0x1,%edi
    b638:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b63d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b644:	00 f0 3f 
    b647:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b64c:	e8 8f ae ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b651:	48 8b 15 40 65 01 00 	mov    0x16540(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b658:	49 89 c6             	mov    %rax,%r14
    b65b:	48 2b 05 0e 65 01 00 	sub    0x1650e(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    b662:	48 c1 e2 10          	shl    $0x10,%rdx
    b666:	48 39 d0             	cmp    %rdx,%rax
    b669:	73 59                	jae    b6c4 <fwp_main_thread+0xa04>
    b66b:	48 89 c2             	mov    %rax,%rdx
    b66e:	48 c1 ea 10          	shr    $0x10,%rdx
    b672:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b676:	48 8b 15 3b 65 01 00 	mov    0x1653b(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    b67d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b681:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b685:	4d 85 ed             	test   %r13,%r13
    b688:	74 3a                	je     b6c4 <fwp_main_thread+0xa04>
    b68a:	0f b6 0a             	movzbl (%rdx),%ecx
    b68d:	80 f9 02             	cmp    $0x2,%cl
    b690:	0f 84 6a 03 00 00    	je     ba00 <fwp_main_thread+0xd40>
    b696:	80 f9 01             	cmp    $0x1,%cl
    b699:	75 29                	jne    b6c4 <fwp_main_thread+0xa04>
    b69b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b69e:	0f b7 c0             	movzwl %ax,%eax
    b6a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6a4:	48 0f af c1          	imul   %rcx,%rax
    b6a8:	48 c1 e8 20          	shr    $0x20,%rax
    b6ac:	48 39 d0             	cmp    %rdx,%rax
    b6af:	73 13                	jae    b6c4 <fwp_main_thread+0xa04>
    b6b1:	49 01 c5             	add    %rax,%r13
    b6b4:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b6b9:	0f 84 e5 03 00 00    	je     baa4 <fwp_main_thread+0xde4>
    b6bf:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b6c4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b6c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ce:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b6d3:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b6da:	33 f3 bf 
    b6dd:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b6e2:	e8 f9 ad ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b6e7:	48 8b 15 aa 64 01 00 	mov    0x164aa(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b6ee:	48 8b 0d 7b 64 01 00 	mov    0x1647b(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    b6f5:	49 89 c5             	mov    %rax,%r13
    b6f8:	48 89 d6             	mov    %rdx,%rsi
    b6fb:	48 29 c8             	sub    %rcx,%rax
    b6fe:	48 c1 e6 10          	shl    $0x10,%rsi
    b702:	48 39 f0             	cmp    %rsi,%rax
    b705:	73 67                	jae    b76e <fwp_main_thread+0xaae>
    b707:	48 89 c6             	mov    %rax,%rsi
    b70a:	48 c1 ee 10          	shr    $0x10,%rsi
    b70e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b712:	48 8b 35 9f 64 01 00 	mov    0x1649f(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    b719:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b71d:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b721:	4d 85 f6             	test   %r14,%r14
    b724:	74 48                	je     b76e <fwp_main_thread+0xaae>
    b726:	0f b6 3e             	movzbl (%rsi),%edi
    b729:	40 80 ff 02          	cmp    $0x2,%dil
    b72d:	0f 84 bd 02 00 00    	je     b9f0 <fwp_main_thread+0xd30>
    b733:	40 80 ff 01          	cmp    $0x1,%dil
    b737:	75 35                	jne    b76e <fwp_main_thread+0xaae>
    b739:	8b 7e 18             	mov    0x18(%rsi),%edi
    b73c:	0f b7 c0             	movzwl %ax,%eax
    b73f:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b742:	48 0f af c7          	imul   %rdi,%rax
    b746:	48 c1 e8 20          	shr    $0x20,%rax
    b74a:	48 39 f0             	cmp    %rsi,%rax
    b74d:	73 1f                	jae    b76e <fwp_main_thread+0xaae>
    b74f:	49 01 c6             	add    %rax,%r14
    b752:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b756:	0f 84 55 03 00 00    	je     bab1 <fwp_main_thread+0xdf1>
    b75c:	41 c6 06 01          	movb   $0x1,(%r14)
    b760:	48 8b 0d 09 64 01 00 	mov    0x16409(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    b767:	48 8b 15 2a 64 01 00 	mov    0x1642a(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b76e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    b773:	4c 89 e8             	mov    %r13,%rax
    b776:	48 c1 e2 10          	shl    $0x10,%rdx
    b77a:	48 29 c8             	sub    %rcx,%rax
    b77d:	48 39 d0             	cmp    %rdx,%rax
    b780:	73 5d                	jae    b7df <fwp_main_thread+0xb1f>
    b782:	48 89 c2             	mov    %rax,%rdx
    b785:	48 c1 ea 10          	shr    $0x10,%rdx
    b789:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b78d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b794:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b798:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b79c:	48 85 ff             	test   %rdi,%rdi
    b79f:	74 3e                	je     b7df <fwp_main_thread+0xb1f>
    b7a1:	0f b6 0a             	movzbl (%rdx),%ecx
    b7a4:	80 f9 02             	cmp    $0x2,%cl
    b7a7:	0f 84 23 02 00 00    	je     b9d0 <fwp_main_thread+0xd10>
    b7ad:	80 f9 01             	cmp    $0x1,%cl
    b7b0:	75 2d                	jne    b7df <fwp_main_thread+0xb1f>
    b7b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7b5:	0f b7 c0             	movzwl %ax,%eax
    b7b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7bb:	48 0f af c1          	imul   %rcx,%rax
    b7bf:	48 c1 e8 20          	shr    $0x20,%rax
    b7c3:	48 39 d0             	cmp    %rdx,%rax
    b7c6:	73 17                	jae    b7df <fwp_main_thread+0xb1f>
    b7c8:	48 01 c7             	add    %rax,%rdi
    b7cb:	0f b6 07             	movzbl (%rdi),%eax
    b7ce:	84 c0                	test   %al,%al
    b7d0:	74 0d                	je     b7df <fwp_main_thread+0xb1f>
    b7d2:	3c fd                	cmp    $0xfd,%al
    b7d4:	0f 87 e4 02 00 00    	ja     babe <fwp_main_thread+0xdfe>
    b7da:	83 c0 01             	add    $0x1,%eax
    b7dd:	88 07                	mov    %al,(%rdi)
    b7df:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b7e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b7e8:	b9 01 00 00 00       	mov    $0x1,%ecx
    b7ed:	4c 89 ee             	mov    %r13,%rsi
    b7f0:	48 8d 15 89 43 00 00 	lea    0x4389(%rip),%rdx        # fb80 <d0>
    b7f7:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b7fc:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b803:	00 00 
    b805:	e8 76 e4 ff ff       	call   9c80 <fwp_write>
    b80a:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b80f:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
    b814:	48 8d 05 76 08 00 00 	lea    0x876(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    b81b:	4d 85 f6             	test   %r14,%r14
    b81e:	4c 0f 44 f0          	cmove  %rax,%r14
    b822:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b826:	0f 87 36 03 00 00    	ja     bb62 <fwp_main_thread+0xea2>
    b82c:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b830:	be 01 00 00 00       	mov    $0x1,%esi
    b835:	e8 56 a4 ff ff       	call   5c90 <fwp_heap_alloc>
    b83a:	4c 89 fa             	mov    %r15,%rdx
    b83d:	4c 89 f6             	mov    %r14,%rsi
    b840:	4c 89 38             	mov    %r15,(%rax)
    b843:	48 89 c5             	mov    %rax,%rbp
    b846:	48 8d 40 08          	lea    0x8(%rax),%rax
    b84a:	48 89 c7             	mov    %rax,%rdi
    b84d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    b852:	e8 49 7d ff ff       	call   35a0 <memcpy@plt>
    b857:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    b85d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b862:	e8 59 7b ff ff       	call   33c0 <free@plt>
    b867:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b86e:	48 89 e8             	mov    %rbp,%rax
    b871:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b878:	48 c1 e2 10          	shl    $0x10,%rdx
    b87c:	48 39 d0             	cmp    %rdx,%rax
    b87f:	73 57                	jae    b8d8 <fwp_main_thread+0xc18>
    b881:	48 89 c2             	mov    %rax,%rdx
    b884:	48 c1 ea 10          	shr    $0x10,%rdx
    b888:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b88c:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b893:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b897:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b89b:	4d 85 f6             	test   %r14,%r14
    b89e:	74 38                	je     b8d8 <fwp_main_thread+0xc18>
    b8a0:	0f b6 0a             	movzbl (%rdx),%ecx
    b8a3:	80 f9 02             	cmp    $0x2,%cl
    b8a6:	0f 84 89 01 00 00    	je     ba35 <fwp_main_thread+0xd75>
    b8ac:	80 f9 01             	cmp    $0x1,%cl
    b8af:	75 27                	jne    b8d8 <fwp_main_thread+0xc18>
    b8b1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8b4:	0f b7 c0             	movzwl %ax,%eax
    b8b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8ba:	48 0f af c1          	imul   %rcx,%rax
    b8be:	48 c1 e8 20          	shr    $0x20,%rax
    b8c2:	48 39 d0             	cmp    %rdx,%rax
    b8c5:	73 11                	jae    b8d8 <fwp_main_thread+0xc18>
    b8c7:	49 01 c6             	add    %rax,%r14
    b8ca:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b8ce:	0f 84 f4 01 00 00    	je     bac8 <fwp_main_thread+0xe08>
    b8d4:	41 c6 06 01          	movb   $0x1,(%r14)
    b8d8:	4c 89 ef             	mov    %r13,%rdi
    b8db:	e8 c0 ae ff ff       	call   67a0 <fwp_drop0>
    b8e0:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    b8e4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b8e9:	be 01 00 00 00       	mov    $0x1,%esi
    b8ee:	48 8b 0d 2b 6b 01 00 	mov    0x16b2b(%rip),%rcx        # 22420 <fwp_prog_out>
    b8f5:	e8 86 7d ff ff       	call   3680 <fwrite@plt>
    b8fa:	48 8b 35 1f 6b 01 00 	mov    0x16b1f(%rip),%rsi        # 22420 <fwp_prog_out>
    b901:	bf 0a 00 00 00       	mov    $0xa,%edi
    b906:	e8 d5 7b ff ff       	call   34e0 <fputc@plt>
    b90b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b912:	48 89 e8             	mov    %rbp,%rax
    b915:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b91c:	48 c1 e2 10          	shl    $0x10,%rdx
    b920:	48 39 d0             	cmp    %rdx,%rax
    b923:	73 6b                	jae    b990 <fwp_main_thread+0xcd0>
    b925:	48 89 c2             	mov    %rax,%rdx
    b928:	48 c1 ea 10          	shr    $0x10,%rdx
    b92c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b930:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b937:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b93b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b93f:	4d 85 f6             	test   %r14,%r14
    b942:	74 4c                	je     b990 <fwp_main_thread+0xcd0>
    b944:	0f b6 0a             	movzbl (%rdx),%ecx
    b947:	80 f9 02             	cmp    $0x2,%cl
    b94a:	0f 84 d7 00 00 00    	je     ba27 <fwp_main_thread+0xd67>
    b950:	80 f9 01             	cmp    $0x1,%cl
    b953:	75 3b                	jne    b990 <fwp_main_thread+0xcd0>
    b955:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b958:	0f b7 c0             	movzwl %ax,%eax
    b95b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b95e:	48 0f af c1          	imul   %rcx,%rax
    b962:	48 c1 e8 20          	shr    $0x20,%rax
    b966:	48 39 d0             	cmp    %rdx,%rax
    b969:	73 25                	jae    b990 <fwp_main_thread+0xcd0>
    b96b:	49 01 c6             	add    %rax,%r14
    b96e:	41 0f b6 06          	movzbl (%r14),%eax
    b972:	84 c0                	test   %al,%al
    b974:	74 1a                	je     b990 <fwp_main_thread+0xcd0>
    b976:	3c 01                	cmp    $0x1,%al
    b978:	0f 84 0c 01 00 00    	je     ba8a <fwp_main_thread+0xdca>
    b97e:	3c ff                	cmp    $0xff,%al
    b980:	0f 84 4f 01 00 00    	je     bad5 <fwp_main_thread+0xe15>
    b986:	83 e8 01             	sub    $0x1,%eax
    b989:	41 88 06             	mov    %al,(%r14)
    b98c:	0f 1f 40 00          	nopl   0x0(%rax)
    b990:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    b995:	48 8b 40 10          	mov    0x10(%rax),%rax
    b999:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b99e:	48 85 c0             	test   %rax,%rax
    b9a1:	0f 84 b9 00 00 00    	je     ba60 <fwp_main_thread+0xda0>
    b9a7:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    b9ae:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b9b5:	e9 b9 fd ff ff       	jmp    b773 <fwp_main_thread+0xab3>
    b9ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b9c0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b9c4:	e9 d7 f4 ff ff       	jmp    aea0 <fwp_main_thread+0x1e0>
    b9c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b9d0:	66 85 c0             	test   %ax,%ax
    b9d3:	0f 85 06 fe ff ff    	jne    b7df <fwp_main_thread+0xb1f>
    b9d9:	e9 ed fd ff ff       	jmp    b7cb <fwp_main_thread+0xb0b>
    b9de:	66 90                	xchg   %ax,%ax
    b9e0:	66 85 c0             	test   %ax,%ax
    b9e3:	0f 85 45 fc ff ff    	jne    b62e <fwp_main_thread+0x96e>
    b9e9:	e9 30 fc ff ff       	jmp    b61e <fwp_main_thread+0x95e>
    b9ee:	66 90                	xchg   %ax,%ax
    b9f0:	66 85 c0             	test   %ax,%ax
    b9f3:	0f 85 75 fd ff ff    	jne    b76e <fwp_main_thread+0xaae>
    b9f9:	e9 54 fd ff ff       	jmp    b752 <fwp_main_thread+0xa92>
    b9fe:	66 90                	xchg   %ax,%ax
    ba00:	66 85 c0             	test   %ax,%ax
    ba03:	0f 85 bb fc ff ff    	jne    b6c4 <fwp_main_thread+0xa04>
    ba09:	e9 a6 fc ff ff       	jmp    b6b4 <fwp_main_thread+0x9f4>
    ba0e:	66 90                	xchg   %ax,%ax
    ba10:	48 89 d7             	mov    %rdx,%rdi
    ba13:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    ba18:	e8 33 9b ff ff       	call   5550 <fwp_rc_forget_slot>
    ba1d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    ba22:	e9 a4 fa ff ff       	jmp    b4cb <fwp_main_thread+0x80b>
    ba27:	66 85 c0             	test   %ax,%ax
    ba2a:	0f 85 60 ff ff ff    	jne    b990 <fwp_main_thread+0xcd0>
    ba30:	e9 39 ff ff ff       	jmp    b96e <fwp_main_thread+0xcae>
    ba35:	66 85 c0             	test   %ax,%ax
    ba38:	0f 85 9a fe ff ff    	jne    b8d8 <fwp_main_thread+0xc18>
    ba3e:	e9 87 fe ff ff       	jmp    b8ca <fwp_main_thread+0xc0a>
    ba43:	48 83 3d 4d 4d 01 00 	cmpq   $0x0,0x14d4d(%rip)        # 20798 <fwp_root>
    ba4a:	00 
    ba4b:	c7 05 2b 46 01 00 00 	movl   $0x0,0x1462b(%rip)        # 20080 <fwp_exit_code>
    ba52:	00 00 00 
    ba55:	0f 84 4d f7 ff ff    	je     b1a8 <fwp_main_thread+0x4e8>
    ba5b:	e9 f0 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ba60:	4c 89 ef             	mov    %r13,%rdi
    ba63:	e8 38 ad ff ff       	call   67a0 <fwp_drop0>
    ba68:	4c 89 e7             	mov    %r12,%rdi
    ba6b:	e8 30 ad ff ff       	call   67a0 <fwp_drop0>
    ba70:	48 c7 05 ed 45 00 00 	movq   $0x0,0x45ed(%rip)        # 10068 <v.2>
    ba77:	00 00 00 00 
    ba7b:	c7 05 eb 45 00 00 01 	movl   $0x1,0x45eb(%rip)        # 10070 <st.3>
    ba82:	00 00 00 
    ba85:	e9 62 f3 ff ff       	jmp    adec <fwp_main_thread+0x12c>
    ba8a:	48 89 ef             	mov    %rbp,%rdi
    ba8d:	e8 fe ab ff ff       	call   6690 <fwp_rc_free_arr>
    ba92:	e9 f9 fe ff ff       	jmp    b990 <fwp_main_thread+0xcd0>
    ba97:	4c 89 ef             	mov    %r13,%rdi
    ba9a:	e8 b1 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    ba9f:	e9 85 fb ff ff       	jmp    b629 <fwp_main_thread+0x969>
    baa4:	4c 89 ef             	mov    %r13,%rdi
    baa7:	e8 a4 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    baac:	e9 0e fc ff ff       	jmp    b6bf <fwp_main_thread+0x9ff>
    bab1:	4c 89 f7             	mov    %r14,%rdi
    bab4:	e8 97 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    bab9:	e9 9e fc ff ff       	jmp    b75c <fwp_main_thread+0xa9c>
    babe:	e8 6d 99 ff ff       	call   5430 <fwp_rc_wide_dup>
    bac3:	e9 17 fd ff ff       	jmp    b7df <fwp_main_thread+0xb1f>
    bac8:	4c 89 f7             	mov    %r14,%rdi
    bacb:	e8 80 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    bad0:	e9 ff fd ff ff       	jmp    b8d4 <fwp_main_thread+0xc14>
    bad5:	4c 89 f0             	mov    %r14,%rax
    bad8:	48 c1 e8 11          	shr    $0x11,%rax
    badc:	4c 31 f0             	xor    %r14,%rax
    badf:	48 89 c2             	mov    %rax,%rdx
    bae2:	48 c1 ea 09          	shr    $0x9,%rdx
    bae6:	48 31 d0             	xor    %rdx,%rax
    bae9:	0f b6 d0             	movzbl %al,%edx
    baec:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    baf3:	00 
    baf4:	48 85 c0             	test   %rax,%rax
    baf7:	75 10                	jne    bb09 <fwp_main_thread+0xe49>
    baf9:	eb 51                	jmp    bb4c <fwp_main_thread+0xe8c>
    bafb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bb00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bb04:	48 85 c0             	test   %rax,%rax
    bb07:	74 43                	je     bb4c <fwp_main_thread+0xe8c>
    bb09:	48 89 c2             	mov    %rax,%rdx
    bb0c:	4c 3b 30             	cmp    (%rax),%r14
    bb0f:	75 ef                	jne    bb00 <fwp_main_thread+0xe40>
    bb11:	48 8b 48 08          	mov    0x8(%rax),%rcx
    bb15:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    bb19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bb1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bb24:	0f 85 66 fe ff ff    	jne    b990 <fwp_main_thread+0xcd0>
    bb2a:	4c 89 f7             	mov    %r14,%rdi
    bb2d:	e8 1e 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    bb32:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bb36:	e9 55 fe ff ff       	jmp    b990 <fwp_main_thread+0xcd0>
    bb3b:	48 8d 3d 9e 0e 00 00 	lea    0xe9e(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    bb42:	e8 a9 88 ff ff       	call   43f0 <fwp_trap>
    bb47:	e8 64 81 ff ff       	call   3cb0 <fwp_heap_oom>
    bb4c:	48 8d 3d 35 0d 00 00 	lea    0xd35(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    bb53:	e8 98 88 ff ff       	call   43f0 <fwp_trap>
    bb58:	e8 83 82 ff ff       	call   3de0 <descent_phase_fail>
    bb5d:	e8 fe 78 ff ff       	call   3460 <__stack_chk_fail@plt>
    bb62:	48 8d 3d dd 06 00 00 	lea    0x6dd(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    bb69:	e8 82 88 ff ff       	call   43f0 <fwp_trap>
    bb6e:	e9 dd 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bb73:	e9 d8 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bb78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bb7f:	00 

000000000000bb80 <__divmodti4>:
    bb80:	f3 0f 1e fa          	endbr64
    bb84:	55                   	push   %rbp
    bb85:	49 89 f1             	mov    %rsi,%r9
    bb88:	49 89 d2             	mov    %rdx,%r10
    bb8b:	48 89 fe             	mov    %rdi,%rsi
    bb8e:	49 89 cb             	mov    %rcx,%r11
    bb91:	48 89 e5             	mov    %rsp,%rbp
    bb94:	41 57                	push   %r15
    bb96:	41 56                	push   %r14
    bb98:	41 55                	push   %r13
    bb9a:	41 54                	push   %r12
    bb9c:	53                   	push   %rbx
    bb9d:	4c 89 c3             	mov    %r8,%rbx
    bba0:	45 31 c0             	xor    %r8d,%r8d
    bba3:	4d 85 c9             	test   %r9,%r9
    bba6:	79 12                	jns    bbba <__divmodti4+0x3a>
    bba8:	31 ff                	xor    %edi,%edi
    bbaa:	48 f7 de             	neg    %rsi
    bbad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bbb4:	4c 19 cf             	sbb    %r9,%rdi
    bbb7:	49 89 f9             	mov    %rdi,%r9
    bbba:	4c 89 d8             	mov    %r11,%rax
    bbbd:	4d 85 db             	test   %r11,%r11
    bbc0:	0f 88 1a 01 00 00    	js     bce0 <__divmodti4+0x160>
    bbc6:	4c 89 d9             	mov    %r11,%rcx
    bbc9:	49 89 f3             	mov    %rsi,%r11
    bbcc:	75 62                	jne    bc30 <__divmodti4+0xb0>
    bbce:	4d 89 c4             	mov    %r8,%r12
    bbd1:	4d 39 d1             	cmp    %r10,%r9
    bbd4:	0f 83 46 01 00 00    	jae    bd20 <__divmodti4+0x1a0>
    bbda:	4c 89 d8             	mov    %r11,%rax
    bbdd:	4c 89 ca             	mov    %r9,%rdx
    bbe0:	49 f7 f2             	div    %r10
    bbe3:	49 89 c3             	mov    %rax,%r11
    bbe6:	31 c0                	xor    %eax,%eax
    bbe8:	48 89 d6             	mov    %rdx,%rsi
    bbeb:	31 ff                	xor    %edi,%edi
    bbed:	4c 89 d9             	mov    %r11,%rcx
    bbf0:	48 89 c2             	mov    %rax,%rdx
    bbf3:	48 89 c8             	mov    %rcx,%rax
    bbf6:	4d 85 e4             	test   %r12,%r12
    bbf9:	74 0a                	je     bc05 <__divmodti4+0x85>
    bbfb:	48 f7 d8             	neg    %rax
    bbfe:	48 83 d2 00          	adc    $0x0,%rdx
    bc02:	48 f7 da             	neg    %rdx
    bc05:	4d 85 c0             	test   %r8,%r8
    bc08:	74 0a                	je     bc14 <__divmodti4+0x94>
    bc0a:	48 f7 de             	neg    %rsi
    bc0d:	48 83 d7 00          	adc    $0x0,%rdi
    bc11:	48 f7 df             	neg    %rdi
    bc14:	48 89 33             	mov    %rsi,(%rbx)
    bc17:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bc1b:	5b                   	pop    %rbx
    bc1c:	41 5c                	pop    %r12
    bc1e:	41 5d                	pop    %r13
    bc20:	41 5e                	pop    %r14
    bc22:	41 5f                	pop    %r15
    bc24:	5d                   	pop    %rbp
    bc25:	c3                   	ret
    bc26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc2d:	00 00 00 
    bc30:	4d 89 c4             	mov    %r8,%r12
    bc33:	49 39 c1             	cmp    %rax,%r9
    bc36:	0f 82 ce 00 00 00    	jb     bd0a <__divmodti4+0x18a>
    bc3c:	31 ff                	xor    %edi,%edi
    bc3e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bc43:	48 63 c7             	movslq %edi,%rax
    bc46:	be 40 00 00 00       	mov    $0x40,%esi
    bc4b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bc50:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bc55:	48 29 c6             	sub    %rax,%rsi
    bc58:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bc5d:	48 09 c8             	or     %rcx,%rax
    bc60:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bc65:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bc6a:	49 89 c6             	mov    %rax,%r14
    bc6d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bc71:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bc76:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bc7b:	49 09 c1             	or     %rax,%r9
    bc7e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bc82:	4c 89 c8             	mov    %r9,%rax
    bc85:	49 f7 f6             	div    %r14
    bc88:	48 89 d1             	mov    %rdx,%rcx
    bc8b:	49 89 c3             	mov    %rax,%r11
    bc8e:	49 89 c1             	mov    %rax,%r9
    bc91:	49 f7 e2             	mul    %r10
    bc94:	49 89 c6             	mov    %rax,%r14
    bc97:	49 89 d2             	mov    %rdx,%r10
    bc9a:	48 39 d1             	cmp    %rdx,%rcx
    bc9d:	72 07                	jb     bca6 <__divmodti4+0x126>
    bc9f:	75 17                	jne    bcb8 <__divmodti4+0x138>
    bca1:	49 39 c7             	cmp    %rax,%r15
    bca4:	73 12                	jae    bcb8 <__divmodti4+0x138>
    bca6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bcaa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bcae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bcb2:	49 89 d2             	mov    %rdx,%r10
    bcb5:	49 89 c6             	mov    %rax,%r14
    bcb8:	4c 89 f8             	mov    %r15,%rax
    bcbb:	4c 29 f0             	sub    %r14,%rax
    bcbe:	4c 19 d1             	sbb    %r10,%rcx
    bcc1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bcc6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bccb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bcd0:	48 09 c6             	or     %rax,%rsi
    bcd3:	48 89 cf             	mov    %rcx,%rdi
    bcd6:	31 c0                	xor    %eax,%eax
    bcd8:	4c 89 c9             	mov    %r9,%rcx
    bcdb:	e9 10 ff ff ff       	jmp    bbf0 <__divmodti4+0x70>
    bce0:	4c 89 d0             	mov    %r10,%rax
    bce3:	4c 89 da             	mov    %r11,%rdx
    bce6:	4d 89 c4             	mov    %r8,%r12
    bce9:	49 89 f3             	mov    %rsi,%r11
    bcec:	48 f7 d8             	neg    %rax
    bcef:	49 f7 d4             	not    %r12
    bcf2:	48 83 d2 00          	adc    $0x0,%rdx
    bcf6:	49 89 c2             	mov    %rax,%r10
    bcf9:	48 f7 da             	neg    %rdx
    bcfc:	48 89 d1             	mov    %rdx,%rcx
    bcff:	0f 84 cc fe ff ff    	je     bbd1 <__divmodti4+0x51>
    bd05:	49 39 d1             	cmp    %rdx,%r9
    bd08:	73 46                	jae    bd50 <__divmodti4+0x1d0>
    bd0a:	4c 89 cf             	mov    %r9,%rdi
    bd0d:	31 c0                	xor    %eax,%eax
    bd0f:	31 c9                	xor    %ecx,%ecx
    bd11:	e9 da fe ff ff       	jmp    bbf0 <__divmodti4+0x70>
    bd16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd1d:	00 00 00 
    bd20:	4d 85 d2             	test   %r10,%r10
    bd23:	75 0d                	jne    bd32 <__divmodti4+0x1b2>
    bd25:	b8 01 00 00 00       	mov    $0x1,%eax
    bd2a:	31 d2                	xor    %edx,%edx
    bd2c:	49 f7 f2             	div    %r10
    bd2f:	49 89 c2             	mov    %rax,%r10
    bd32:	4c 89 c8             	mov    %r9,%rax
    bd35:	31 d2                	xor    %edx,%edx
    bd37:	49 f7 f2             	div    %r10
    bd3a:	49 89 c1             	mov    %rax,%r9
    bd3d:	4c 89 d8             	mov    %r11,%rax
    bd40:	49 f7 f2             	div    %r10
    bd43:	49 89 c3             	mov    %rax,%r11
    bd46:	4c 89 c8             	mov    %r9,%rax
    bd49:	e9 9a fe ff ff       	jmp    bbe8 <__divmodti4+0x68>
    bd4e:	66 90                	xchg   %ax,%ax
    bd50:	45 31 f6             	xor    %r14d,%r14d
    bd53:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bd58:	44 89 f7             	mov    %r14d,%edi
    bd5b:	45 85 f6             	test   %r14d,%r14d
    bd5e:	0f 85 df fe ff ff    	jne    bc43 <__divmodti4+0xc3>
    bd64:	4c 39 ca             	cmp    %r9,%rdx
    bd67:	72 17                	jb     bd80 <__divmodti4+0x200>
    bd69:	31 c9                	xor    %ecx,%ecx
    bd6b:	48 39 c6             	cmp    %rax,%rsi
    bd6e:	73 10                	jae    bd80 <__divmodti4+0x200>
    bd70:	4c 89 cf             	mov    %r9,%rdi
    bd73:	31 c0                	xor    %eax,%eax
    bd75:	e9 76 fe ff ff       	jmp    bbf0 <__divmodti4+0x70>
    bd7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bd80:	4c 89 de             	mov    %r11,%rsi
    bd83:	b9 01 00 00 00       	mov    $0x1,%ecx
    bd88:	48 29 c6             	sub    %rax,%rsi
    bd8b:	49 19 d1             	sbb    %rdx,%r9
    bd8e:	eb e0                	jmp    bd70 <__divmodti4+0x1f0>

000000000000bd90 <atexit>:
    bd90:	f3 0f 1e fa          	endbr64
    bd94:	48 8b 15 6d 42 00 00 	mov    0x426d(%rip),%rdx        # 10008 <__dso_handle>
    bd9b:	31 f6                	xor    %esi,%esi
    bd9d:	e9 be 78 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bda4 <_fini>:
    bda4:	f3 0f 1e fa          	endbr64
    bda8:	48 83 ec 08          	sub    $0x8,%rsp
    bdac:	48 83 c4 08          	add    $0x8,%rsp
    bdb0:	c3                   	ret
