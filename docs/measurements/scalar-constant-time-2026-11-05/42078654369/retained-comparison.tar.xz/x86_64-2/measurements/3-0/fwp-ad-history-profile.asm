
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 f2 6c 06 00 	mov    %rax,0x66cf2(%rip)        # 6a478 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 6c 06 00 	mov    %rax,0x66cec(%rip)        # 6a480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f 74 00 00 	lea    0x747f(%rip),%rdx        # ace0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 93 00 00 	lea    0x9346(%rip),%rdi        # cc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 93 00 00 	lea    0x9300(%rip),%rdi        # cc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 92 00 00 	lea    0x92c4(%rip),%rdi        # cbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 92 00 00 	lea    0x9290(%rip),%rdi        # cbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 c5 04 00 	lea    0x4c597(%rip),%r8        # 501a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b c5 04 00 	lea    0x4c53b(%rip),%rcx        # 50160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f c5 04 00 	lea    0x4c50f(%rip),%rcx        # 50140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 c5 04 00 	lea    0x4c541(%rip),%rcx        # 50180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 c5 04 	movdqa 0x4c550(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 c5 04 	paddq  0x4c538(%rip),%xmm0        # 501a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f c4 04 00 	cmp    %rax,0x4c49f(%rip)        # 50120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 c4 04 	movq   %xmm0,0x4c495(%rip)        # 50120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e c4 01 00 	add    0x1c43e(%rip),%rdx        # 200f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c c4 01 00 	add    0x1c42c(%rip),%rax        # 200f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 67 06 00 	mov    0x66779(%rip),%rdi        # 6a480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 4a 06 00 	mov    0x64ab1(%rip),%rax        # 68800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 43 06 00 	mov    0x643f9(%rip),%rax        # 681c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 43 06 00 	sub    0x643e5(%rip),%rax        # 681c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 8f 00 00 	lea    0x8f1d(%rip),%rsi        # cd30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 5d 06 00 	mov    0x65d8b(%rip),%rax        # 69c10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 5d 06 00 	lea    0x65d84(%rip),%r8        # 69c10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 5d 06 00 	mov    0x65d65(%rip),%rbx        # 69bf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 5d 06 00 	mov    0x65d75(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 5d 06 00 	mov    0x65d11(%rip),%rdi        # 69c00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 5d 06 00 	sub    %rsi,0x65d5a(%rip)        # 69c50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 5c 06 00 	mov    0x65cea(%rip),%rax        # 69bf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 5c 06 00 	add    0x65ca0(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 5c 06 00 	mov    0x65cae(%rip),%rsi        # 69c00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 5c 06 00 	mov    0x65cbc(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 5c 06 00 	mov    %r12,0x65c6b(%rip)        # 69c00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 5c 06 00 	mov    %rbp,0x65c59(%rip)        # 69bf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 5c 06 00 	cmp    %rdi,0x65c3e(%rip)        # 69be8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 5c 06 00 	mov    %rdi,0x65c35(%rip)        # 69be8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 5c 06 00 	sub    %rdi,0x65c79(%rip)        # 69c50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 5c 06 00 	mov    0x65c21(%rip),%rax        # 69c08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 5c 06 00 	lea    0x65c1a(%rip),%r8        # 69c08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 86 00 00 	lea    0x86ef(%rip),%rdx        # c6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 46 06 00 	cmp    0x646c9(%rip),%rdi        # 68800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 46 06 00 	mov    0x6468f(%rip),%rax        # 687e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 46 06 00 	mov    %rdi,0x6466d(%rip)        # 687e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 46 06 00 	mov    %rdi,0x64649(%rip)        # 687e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 80 00 00 	lea    0x805f(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 bf 04 	movdqa 0x4bf76(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e bf 04 	paddq  0x4bf5e(%rip),%xmm0        # 501a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 be 01 00 	mov    0x1be84(%rip),%r8        # 200f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e be 04 00 	mov    0x4be9e(%rip),%rcx        # 50120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 84 00 00 	lea    0x84b5(%rip),%rdx        # c748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 be 04 00 	lea    0x4bee1(%rip),%r15        # 50180 <ad_raw_peak>
    429f:	4c 8d 35 9a be 04 00 	lea    0x4be9a(%rip),%r14        # 50140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f be 04 00 	lea    0x4be9f(%rip),%r13        # 50160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 84 00 00 	lea    0x848d(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 bd 01 00 	cmpq   $0x0,0x1bda6(%rip)        # 20100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd bd 01 00 	mov    0x1bdbd(%rip),%r8        # 20120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be bd 01 00 	mov    0x1bdbe(%rip),%r9        # 20128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af bd 01 00 	lea    0x1bdaf(%rip),%rbx        # 20120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 bd 01 00 	mov    0x1bdb1(%rip),%rax        # 20130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 84 00 00 	lea    0x8429(%rip),%rdx        # c7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 bd 01 00 	cmp    0x1bd33(%rip),%rbp        # 20100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 83 00 00 	lea    0x8384(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 82 00 00 	lea    0x82da(%rip),%rdi        # c720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 81 00 00 	lea    0x81d8(%rip),%rdi        # c828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # cd50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 5d 06 00 	add    0x65daa(%rip),%rax        # 6a478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 81 00 00 	lea    0x812c(%rip),%rdi        # c850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 b9 01 00 	cmp    %rax,0x1b9a5(%rip)        # 200e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 b9 01 00 	add    0x1b9a0(%rip),%rax        # 200f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 81 00 00 	lea    0x8115(%rip),%rdi        # c880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 75 00 00 	lea    0x759a(%rip),%rsi        # c288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 4e 06 00 	mov    0x64e85(%rip),%r9        # 69be8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 4e 06 00 	mov    0x64ede(%rip),%r8        # 69c48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 7b 00 00 	lea    0x7b5f(%rip),%rdx        # c8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 4e 06 00 	mov    0x64ec6(%rip),%rcx        # 69c40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 4e 06 	movsd  0x64ed4(%rip),%xmm1        # 69c60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 4e 06 	movsd  0x64ec4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 7f 00 	movdqa 0x7f88(%rip),%xmm0        # cd60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 49 06 00 	lea    0x6497f(%rip),%rax        # 69760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 7f 00 	movdqa 0x7fb1(%rip),%xmm2        # cda0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 49 06 00 	movaps %xmm0,0x64925(%rip)        # 69720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 7f 00 	movdqa 0x7f6d(%rip),%xmm0        # cd70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 4d 06 00 01 	movl   $0x1,0x64db3(%rip)        # 69bc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 49 06 00 	movaps %xmm0,0x64913(%rip)        # 69730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 7f 00 	movdqa 0x7f5b(%rip),%xmm0        # cd80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 14 49 06 00 	movaps %xmm0,0x64914(%rip)        # 69740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 7f 00 	movdqa 0x7f5c(%rip),%xmm0        # cd90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 15 49 06 00 	movaps %xmm0,0x64915(%rip)        # 69750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 39 06 00 	lea    0x63995(%rip),%r8        # 68820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 4c 06 00 	mov    %rax,0x64cb0(%rip)        # 69bd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 4c 06 00 	mov    %r12,0x64c8e(%rip)        # 69be0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 4c 06 00 	mov    %rax,0x64c77(%rip)        # 69bd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 4c 06 00 	mov    %rbx,0x64c90(%rip)        # 69bf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 4c 06 00 	mov    %rsi,0x64cb9(%rip)        # 69c20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 4c 06 00 	mov    %rax,0x64c98(%rip)        # 69c18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 4c 06 00    	mov    %eax,0x64c1c(%rip)        # 69bc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 38 06 00 	mov    0x6380c(%rip),%r8        # 687e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 37 06 00 	mov    %rbx,0x6373c(%rip)        # 687e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 37 06 00 	mov    %r8,0x63728(%rip)        # 687e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 b0 04 00 	lea    0x4b0e9(%rip),%rcx        # 501c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 b0 04 00 	lea    0x4b098(%rip),%rcx        # 501a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 6f 00 00 	lea    0x6fc2(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 b0 04 00 	lea    0x4b016(%rip),%r12        # 501c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 6e 00 00 	lea    0x6ee8(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 6e 00 00 	lea    0x6ecc(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 6f 00 00 	lea    0x6f04(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 6e 00 00 	lea    0x6edd(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 6e 00 00 	lea    0x6eaa(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae ad 01 00 	lea    0x1adae(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 ad 01 00 	movaps %xmm0,0x1ad96(%rip)        # 200a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 ad 01 00 	mov    %rsi,0x1ad72(%rip)        # 20088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 ad 01 00 	movaps %xmm0,0x1ad93(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 ad 01 00 	movaps %xmm0,0x1ad97(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 ad 01 00 	mov    %rax,0x1ad98(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 6e 00 00 	lea    0x6e09(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d ad 01 00 	mov    0x1ad1d(%rip),%rsi        # 20088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d ad 01 00 	imul   $0x68,0x1ad6d(%rip),%rdx        # 200e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 ae 04 00 	cmp    0x4ae26(%rip),%rdx        # 501a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 ae 04 00 	mov    0x4ae25(%rip),%rax        # 501a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f ae 04 00 	add    0x4ae1f(%rip),%rax        # 501b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 ae 04 00 	add    0x4ae20(%rip),%rax        # 501b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c ad 01 00 	mov    0x1ad5c(%rip),%rcx        # 20100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 ad 01 00 	mov    %rdi,0x1ad45(%rip)        # 20100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 ad 01 00 	lea    0x1ad57(%rip),%rcx        # 20120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 75 00 00 	lea    0x7562(%rip),%rdi        # c958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 6d 00 00 	lea    0x6d6f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 33 06 00 	mov    0x633a7(%rip),%rbx        # 687d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a ab 00 00 	mov    0xab0a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 32 06 00 	mov    0x6326d(%rip),%rax        # 687e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 32 06 00 	mov    %rdx,0x63247(%rip)        # 687e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 31 06 00 	mov    0x63194(%rip),%rbx        # 687d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 31 06 00 	mov    %rbx,0x63151(%rip)        # 687d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 31 06 00 	mov    %rdx,0x63151(%rip)        # 687e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 31 06 00 	lea    0x63166(%rip),%rsi        # 68820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 4c 06 00 	addq   $0x1,0x64ce5(%rip)        # 6a468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f 72 00 00 	lea    0x721f(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 72 00 00 	lea    0x7230(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 69 00 00 	lea    0x69d2(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 30 06 00 	lea    0x6301e(%rip),%rcx        # 68820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 4c 06 00 	subq   $0x1,0x64c1f(%rip)        # 6a468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b 71 00 00 	lea    0x718b(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 4c 06 00 	cmpq   $0x0,0x64c00(%rip)        # 6a468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 4b 06 00 	sub    %rax,0x64b55(%rip)        # 6a470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 4b 06 00 	add    %r12,0x64b33(%rip)        # 6a470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 42 06 00 	mov    0x6428f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 2e 06 00 	lea    0x62e8c(%rip),%rax        # 68820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 41 06 00 	add    0x641e3(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 41 06 00 	mov    0x641b0(%rip),%rsi        # 69bd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 41 06 00 	mov    0x641d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 41 06 00 	add    0x641c5(%rip),%r8        # 69c18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 41 06 	addsd  0x6418d(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 2d 06 00 	lea    0x62d42(%rip),%rax        # 68820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 41 06 00 	sub    %rdi,0x6414c(%rip)        # 69c40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 41 06 	movsd  %xmm0,0x64164(%rip)        # 69c60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 41 06 00 	sub    %rdx,0x6411e(%rip)        # 69c40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 41 06 	addsd  0x64124(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 41 06 	movsd  %xmm0,0x64118(%rip)        # 69c60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 40 06 00 	mov    0x640af(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 40 06 00 	add    %rcx,0x640a9(%rip)        # 69c50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 40 06 00 	cmp    0x64062(%rip),%r9        # 69c10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 40 06 00 	mov    %r9,0x64059(%rip)        # 69c10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 40 06 00 	cmp    0x6404a(%rip),%r9        # 69c08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 40 06 00 	mov    %r9,0x6403d(%rip)        # 69c08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 3f 06 00 	add    0x63f53(%rip),%rdi        # 69c18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 2b 06 00 	lea    0x62b30(%rip),%r15        # 68820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 3e 06 00 	add    0x63ea0(%rip),%r12        # 69bd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 3e 06 00 	add    0x63ef9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 3e 06 00 	cmp    %rax,0x63ef8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 3e 06 00 	mov    %rax,0x63ee9(%rip)        # 69c40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 3e 06 00 	mov    %rax,0x63ee8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 3e 06 	addsd  0x63ee4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 3e 06 	movsd  %xmm0,0x63edc(%rip)        # 69c58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 3e 06 00    	mov    0x63e23(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 2a 06 00 	lea    0x62a5f(%rip),%rdi        # 68820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 3e 06 00 	add    0x63e18(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 3e 06 00 	cmp    %rax,0x63e13(%rip)        # 69c48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 3e 06 00 	mov    %rax,0x63e04(%rip)        # 69c40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 3e 06 00 	mov    %rax,0x63e03(%rip)        # 69c48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 3d 06 	addsd  0x63dff(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 3d 06 	movsd  %xmm0,0x63df7(%rip)        # 69c58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 45 06 00    	mov    0x645ca(%rip),%ebx        # 6a4e8 <iteration_active>
    5f1e:	8b 05 a0 3c 06 00    	mov    0x63ca0(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 28 06 00 	lea    0x628d4(%rip),%rax        # 68820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 3c 06 00 	add    0x63c8e(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 3c 06 00 	cmp    %rax,0x63c89(%rip)        # 69c48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 3c 06 00 	mov    %rax,0x63c7a(%rip)        # 69c40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 3c 06 00 	mov    %rax,0x63c79(%rip)        # 69c48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 3c 06 	addsd  0x63c78(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 3c 06 	movsd  %xmm0,0x63c70(%rip)        # 69c58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 3c 06 00 	mov    0x63c4d(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 44 06 	subsd  0x644bb(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 44 06 	comisd 0x644ab(%rip),%xmm0        # 6a4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 44 06 	movsd  %xmm0,0x644a1(%rip)        # 6a4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 44 06 00 	addq   $0x1,0x644a4(%rip)        # 6a4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 44 06 00 	add    %rdi,0x64495(%rip)        # 6a4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 3c 43 06 00 	add    0x6433c(%rip),%r9        # 6a478 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 71 01 00 00    	jns    64f8 <fwp_p_ad_push+0x1a8>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 6e 02 00 00    	jne    663b <fwp_p_ad_push+0x2eb>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 51 02 00 00    	jg     662f <fwp_p_ad_push+0x2df>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	4c 39 f8             	cmp    %r15,%rax
    63e4:	0f 8d 39 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	4c 39 f8             	cmp    %r15,%rax
    63f5:	0f 8d 28 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 1d 02 00 00    	ja     662f <fwp_p_ad_push+0x2df>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 22 ed ff ff       	call   5190 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 d0 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 ee             	mov    %rbp,%rsi
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e6 04          	shl    $0x4,%rsi
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	ba 02 00 00 00       	mov    $0x2,%edx
    6493:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6497:	e8 f4 ec ff ff       	call   5190 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 a2 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64ad:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b4:	00 
    64b5:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bc:	00 
    64bd:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c4:	00 
    64c5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64c9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ce:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d6:	4d 85 f6             	test   %r14,%r14
    64d9:	0f 85 e5 00 00 00    	jne    65c4 <fwp_p_ad_push+0x274>
    64df:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64e7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64eb:	48 01 d1             	add    %rdx,%rcx
    64ee:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f2:	eb 7c                	jmp    6570 <fwp_p_ad_push+0x220>
    64f4:	0f 1f 40 00          	nopl   0x0(%rax)
    64f8:	48 89 d0             	mov    %rdx,%rax
    64fb:	48 c1 ff 20          	sar    $0x20,%rdi
    64ff:	48 c1 f8 20          	sar    $0x20,%rax
    6503:	48 39 c7             	cmp    %rax,%rdi
    6506:	0f 84 ab fe ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    650c:	48 8d 3d f5 64 00 00 	lea    0x64f5(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    6513:	e8 38 df ff ff       	call   4450 <fwp_trap>
    6518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    651f:	00 
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	4c 89 ca             	mov    %r9,%rdx
    65c7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65cc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65d6:	e8 15 d0 ff ff       	call   35f0 <memmove@plt>
    65db:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65e9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65ed:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65f6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fa:	4c 89 d2             	mov    %r10,%rdx
    65fd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6602:	e8 e9 cf ff ff       	call   35f0 <memmove@plt>
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    660f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6614:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6619:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    661e:	e9 c0 fe ff ff       	jmp    64e3 <fwp_p_ad_push+0x193>
    6623:	48 8d 3d 98 5b 00 00 	lea    0x5b98(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    662a:	e8 21 de ff ff       	call   4450 <fwp_trap>
    662f:	48 8d 3d 71 5b 00 00 	lea    0x5b71(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    6636:	e8 15 de ff ff       	call   4450 <fwp_trap>
    663b:	48 8d 3d 0e 64 00 00 	lea    0x640e(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    6642:	e8 09 de ff ff       	call   4450 <fwp_trap>
    6647:	48 89 df             	mov    %rbx,%rdi
    664a:	e8 41 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    664f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6653:	48 85 ff             	test   %rdi,%rdi
    6656:	74 05                	je     665d <fwp_p_ad_push+0x30d>
    6658:	e8 73 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    665d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6661:	48 85 ff             	test   %rdi,%rdi
    6664:	74 05                	je     666b <fwp_p_ad_push+0x31b>
    6666:	e8 65 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    666b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    666f:	48 85 ff             	test   %rdi,%rdi
    6672:	74 05                	je     6679 <fwp_p_ad_push+0x329>
    6674:	e8 57 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6679:	31 c9                	xor    %ecx,%ecx
    667b:	31 c0                	xor    %eax,%eax
    667d:	31 d2                	xor    %edx,%edx
    667f:	be 01 00 00 00       	mov    $0x1,%esi
    6684:	89 53 04             	mov    %edx,0x4(%rbx)
    6687:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668b:	ba 13 00 00 00       	mov    $0x13,%edx
    6690:	48 8d 3d 71 59 00 00 	lea    0x5971(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6697:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    669b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    669f:	48 8b 0d 9a 99 00 00 	mov    0x999a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    66a6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66aa:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66ae:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66b2:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66b6:	e8 a5 cf ff ff       	call   3660 <fwrite@plt>
    66bb:	31 ff                	xor    %edi,%edi
    66bd:	e8 de ce ff ff       	call   35a0 <fflush@plt>
    66c2:	bf 66 00 00 00       	mov    $0x66,%edi
    66c7:	e8 b4 cf ff ff       	call   3680 <_Exit@plt>
    66cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066d0 <w107>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66ff:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push>
    670a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6710:	48 89 da             	mov    %rbx,%rdx
    6713:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6719:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6720:	00 f0 3f 
    6723:	48 89 c7             	mov    %rax,%rdi
    6726:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    672d:	00 f0 bf 
    6730:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6735:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673b:	e8 10 fc ff ff       	call   6350 <fwp_p_ad_push>
    6740:	f2 0f 10 05 98 66 00 	movsd  0x6698(%rip),%xmm0        # cde0 <msg.4+0xb0>
    6747:	00 
    6748:	4c 89 e7             	mov    %r12,%rdi
    674b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6751:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6758:	00 f0 3f 
    675b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6762:	49 89 c5             	mov    %rax,%r13
    6765:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    676c:	00 f0 bf 
    676f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6774:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    677a:	e8 d1 fb ff ff       	call   6350 <fwp_p_ad_push>
    677f:	48 89 e9             	mov    %rbp,%rcx
    6782:	4c 89 ea             	mov    %r13,%rdx
    6785:	48 89 ee             	mov    %rbp,%rsi
    6788:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    678e:	4c 89 ef             	mov    %r13,%rdi
    6791:	49 89 c4             	mov    %rax,%r12
    6794:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6798:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    679e:	e8 ad fb ff ff       	call   6350 <fwp_p_ad_push>
    67a3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a9:	f2 0f 59 1d 37 66 00 	mulsd  0x6637(%rip),%xmm3        # cde8 <msg.4+0xb8>
    67b0:	00 
    67b1:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b8:	00 59 40 
    67bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67c0:	48 89 c2             	mov    %rax,%rdx
    67c3:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67ca:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67d0:	e8 7b fb ff ff       	call   6350 <fwp_p_ad_push>
    67d5:	48 89 d9             	mov    %rbx,%rcx
    67d8:	4c 89 e2             	mov    %r12,%rdx
    67db:	48 89 de             	mov    %rbx,%rsi
    67de:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67e4:	4c 89 e7             	mov    %r12,%rdi
    67e7:	48 89 c5             	mov    %rax,%rbp
    67ea:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67ee:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f4:	e8 57 fb ff ff       	call   6350 <fwp_p_ad_push>
    67f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67ff:	48 89 ea             	mov    %rbp,%rdx
    6802:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6808:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    680f:	00 f0 3f 
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	48 89 ce             	mov    %rcx,%rsi
    6818:	66 48 0f 7e db       	movq   %xmm3,%rbx
    681d:	e8 2e fb ff ff       	call   6350 <fwp_p_ad_push>
    6822:	48 83 c4 28          	add    $0x28,%rsp
    6826:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    682b:	5b                   	pop    %rbx
    682c:	5d                   	pop    %rbp
    682d:	41 5c                	pop    %r12
    682f:	41 5d                	pop    %r13
    6831:	c3                   	ret
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 

0000000000006840 <fwp_data.part.0.constprop.0>:
    6840:	41 56                	push   %r14
    6842:	8b 05 7c 33 06 00    	mov    0x6337c(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    6848:	41 89 fe             	mov    %edi,%r14d
    684b:	41 55                	push   %r13
    684d:	44 8b 2d 94 3c 06 00 	mov    0x63c94(%rip),%r13d        # 6a4e8 <iteration_active>
    6854:	41 54                	push   %r12
    6856:	49 89 f4             	mov    %rsi,%r12
    6859:	55                   	push   %rbp
    685a:	53                   	push   %rbx
    685b:	45 85 ed             	test   %r13d,%r13d
    685e:	0f 84 1c 01 00 00    	je     6980 <fwp_data.part.0.constprop.0+0x140>
    6864:	48 83 05 74 3c 06 00 	addq   $0x1,0x63c74(%rip)        # 6a4e0 <iteration_requests>
    686b:	01 
    686c:	48 83 05 64 3c 06 00 	addq   $0x18,0x63c64(%rip)        # 6a4d8 <iteration_bytes>
    6873:	18 
    6874:	85 c0                	test   %eax,%eax
    6876:	0f 84 8c 01 00 00    	je     6a08 <fwp_data.part.0.constprop.0+0x1c8>
    687c:	0f b6 05 3f 2f 06 00 	movzbl 0x62f3f(%rip),%eax        # 697c2 <fwp_heap+0xfa2>
    6883:	48 8d 15 96 1f 06 00 	lea    0x61f96(%rip),%rdx        # 68820 <fwp_heap>
    688a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6891:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6895:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6899:	48 8b 18             	mov    (%rax),%rbx
    689c:	48 85 db             	test   %rbx,%rbx
    689f:	0f 84 fb 00 00 00    	je     69a0 <fwp_data.part.0.constprop.0+0x160>
    68a5:	48 8b 13             	mov    (%rbx),%rdx
    68a8:	48 f7 d2             	not    %rdx
    68ab:	48 89 10             	mov    %rdx,(%rax)
    68ae:	48 83 fd 18          	cmp    $0x18,%rbp
    68b2:	76 1b                	jbe    68cf <fwp_data.part.0.constprop.0+0x8f>
    68b4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    68b8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    68bc:	31 f6                	xor    %esi,%esi
    68be:	48 c1 e8 03          	shr    $0x3,%rax
    68c2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    68c9:	00 
    68ca:	e8 e1 cb ff ff       	call   34b0 <memset@plt>
    68cf:	48 89 e8             	mov    %rbp,%rax
    68d2:	48 03 05 67 33 06 00 	add    0x63367(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    68d9:	0f 82 3d 01 00 00    	jb     6a1c <fwp_data.part.0.constprop.0+0x1dc>
    68df:	48 39 05 62 33 06 00 	cmp    %rax,0x63362(%rip)        # 69c48 <fwp_heap+0x1428>
    68e6:	48 89 05 53 33 06 00 	mov    %rax,0x63353(%rip)        # 69c40 <fwp_heap+0x1420>
    68ed:	73 07                	jae    68f6 <fwp_data.part.0.constprop.0+0xb6>
    68ef:	48 89 05 52 33 06 00 	mov    %rax,0x63352(%rip)        # 69c48 <fwp_heap+0x1428>
    68f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    68fa:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    68ff:	f2 0f 58 05 51 33 06 	addsd  0x63351(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    6906:	00 
    6907:	f2 0f 11 05 49 33 06 	movsd  %xmm0,0x63349(%rip)        # 69c58 <fwp_heap+0x1438>
    690e:	00 
    690f:	45 85 ed             	test   %r13d,%r13d
    6912:	74 33                	je     6947 <fwp_data.part.0.constprop.0+0x107>
    6914:	48 8b 05 25 33 06 00 	mov    0x63325(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    691b:	48 85 c0             	test   %rax,%rax
    691e:	0f 88 a4 00 00 00    	js     69c8 <fwp_data.part.0.constprop.0+0x188>
    6924:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6928:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    692d:	f2 0f 5c 05 93 3b 06 	subsd  0x63b93(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    6934:	00 
    6935:	66 0f 2f 05 83 3b 06 	comisd 0x63b83(%rip),%xmm0        # 6a4c0 <iteration_peak>
    693c:	00 
    693d:	76 08                	jbe    6947 <fwp_data.part.0.constprop.0+0x107>
    693f:	f2 0f 11 05 79 3b 06 	movsd  %xmm0,0x63b79(%rip)        # 6a4c0 <iteration_peak>
    6946:	00 
    6947:	b8 02 00 00 00       	mov    $0x2,%eax
    694c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6951:	66 0f 6e c8          	movd   %eax,%xmm1
    6955:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6959:	66 0f d6 03          	movq   %xmm0,(%rbx)
    695d:	49 8b 04 24          	mov    (%r12),%rax
    6961:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6965:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    696a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    696e:	48 89 d8             	mov    %rbx,%rax
    6971:	5b                   	pop    %rbx
    6972:	5d                   	pop    %rbp
    6973:	41 5c                	pop    %r12
    6975:	41 5d                	pop    %r13
    6977:	41 5e                	pop    %r14
    6979:	c3                   	ret
    697a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6980:	85 c0                	test   %eax,%eax
    6982:	0f 85 f4 fe ff ff    	jne    687c <fwp_data.part.0.constprop.0+0x3c>
    6988:	31 f6                	xor    %esi,%esi
    698a:	bf 18 00 00 00       	mov    $0x18,%edi
    698f:	e8 7c f5 ff ff       	call   5f10 <fwp_heap_alloc>
    6994:	48 89 c3             	mov    %rax,%rbx
    6997:	eb ae                	jmp    6947 <fwp_data.part.0.constprop.0+0x107>
    6999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    69a4:	48 85 db             	test   %rbx,%rbx
    69a7:	74 47                	je     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    69ad:	48 29 da             	sub    %rbx,%rdx
    69b0:	48 39 ea             	cmp    %rbp,%rdx
    69b3:	72 3b                	jb     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    69b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69bd:	e9 ec fe ff ff       	jmp    68ae <fwp_data.part.0.constprop.0+0x6e>
    69c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69c8:	48 89 c2             	mov    %rax,%rdx
    69cb:	83 e0 01             	and    $0x1,%eax
    69ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69d2:	48 d1 ea             	shr    $1,%rdx
    69d5:	48 09 c2             	or     %rax,%rdx
    69d8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    69dd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    69e1:	e9 47 ff ff ff       	jmp    692d <fwp_data.part.0.constprop.0+0xed>
    69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ed:	00 00 00 
    69f0:	31 f6                	xor    %esi,%esi
    69f2:	bf 18 00 00 00       	mov    $0x18,%edi
    69f7:	e8 14 f5 ff ff       	call   5f10 <fwp_heap_alloc>
    69fc:	48 89 c3             	mov    %rax,%rbx
    69ff:	e9 0b ff ff ff       	jmp    690f <fwp_data.part.0.constprop.0+0xcf>
    6a04:	0f 1f 40 00          	nopl   0x0(%rax)
    6a08:	31 f6                	xor    %esi,%esi
    6a0a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a0f:	e8 fc f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a14:	48 89 c3             	mov    %rax,%rbx
    6a17:	e9 f8 fe ff ff       	jmp    6914 <fwp_data.part.0.constprop.0+0xd4>
    6a1c:	e8 0f d4 ff ff       	call   3e30 <fwp_heap_oom>
    6a21:	0f 1f 40 00          	nopl   0x0(%rax)
    6a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a2c:	00 00 00 00 

0000000000006a30 <fwp_rc_share>:
    6a30:	48 8b 05 c1 31 06 00 	mov    0x631c1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6a37:	48 2b 3d 92 31 06 00 	sub    0x63192(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6a3e:	48 c1 e0 10          	shl    $0x10,%rax
    6a42:	48 39 c7             	cmp    %rax,%rdi
    6a45:	73 4a                	jae    6a91 <fwp_rc_share+0x61>
    6a47:	48 89 f8             	mov    %rdi,%rax
    6a4a:	48 c1 e8 10          	shr    $0x10,%rax
    6a4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a52:	48 8b 05 bf 31 06 00 	mov    0x631bf(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6a59:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a5d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a61:	48 85 d2             	test   %rdx,%rdx
    6a64:	74 2b                	je     6a91 <fwp_rc_share+0x61>
    6a66:	0f b6 08             	movzbl (%rax),%ecx
    6a69:	80 f9 02             	cmp    $0x2,%cl
    6a6c:	74 2a                	je     6a98 <fwp_rc_share+0x68>
    6a6e:	80 f9 01             	cmp    $0x1,%cl
    6a71:	75 1e                	jne    6a91 <fwp_rc_share+0x61>
    6a73:	8b 48 18             	mov    0x18(%rax),%ecx
    6a76:	0f b7 ff             	movzwl %di,%edi
    6a79:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a7c:	48 0f af f9          	imul   %rcx,%rdi
    6a80:	48 c1 ef 20          	shr    $0x20,%rdi
    6a84:	48 39 c7             	cmp    %rax,%rdi
    6a87:	73 08                	jae    6a91 <fwp_rc_share+0x61>
    6a89:	48 01 fa             	add    %rdi,%rdx
    6a8c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a8f:	75 0d                	jne    6a9e <fwp_rc_share+0x6e>
    6a91:	c3                   	ret
    6a92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a98:	66 85 ff             	test   %di,%di
    6a9b:	74 ef                	je     6a8c <fwp_rc_share+0x5c>
    6a9d:	c3                   	ret
    6a9e:	50                   	push   %rax
    6a9f:	48 8d 3d da 5f 00 00 	lea    0x5fda(%rip),%rdi        # ca80 <_IO_stdin_used+0xa80>
    6aa6:	e8 a5 d9 ff ff       	call   4450 <fwp_trap>
    6aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ab0 <fwp_rc_free_arr>:
    6ab0:	48 8b 15 41 31 06 00 	mov    0x63141(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 2b 05 0f 31 06 00 	sub    0x6310f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6ac1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac5:	48 39 d0             	cmp    %rdx,%rax
    6ac8:	73 5b                	jae    6b25 <fwp_rc_free_arr+0x75>
    6aca:	48 89 c2             	mov    %rax,%rdx
    6acd:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad5:	48 8b 15 3c 31 06 00 	mov    0x6313c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6adc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ae0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ae4:	48 85 c9             	test   %rcx,%rcx
    6ae7:	74 3c                	je     6b25 <fwp_rc_free_arr+0x75>
    6ae9:	0f b6 32             	movzbl (%rdx),%esi
    6aec:	40 80 fe 02          	cmp    $0x2,%sil
    6af0:	74 2e                	je     6b20 <fwp_rc_free_arr+0x70>
    6af2:	40 80 fe 01          	cmp    $0x1,%sil
    6af6:	75 2d                	jne    6b25 <fwp_rc_free_arr+0x75>
    6af8:	8b 72 18             	mov    0x18(%rdx),%esi
    6afb:	0f b7 c0             	movzwl %ax,%eax
    6afe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b01:	48 0f af c6          	imul   %rsi,%rax
    6b05:	48 c1 e8 20          	shr    $0x20,%rax
    6b09:	48 39 d0             	cmp    %rdx,%rax
    6b0c:	73 17                	jae    6b25 <fwp_rc_free_arr+0x75>
    6b0e:	48 01 c1             	add    %rax,%rcx
    6b11:	80 39 01             	cmpb   $0x1,(%rcx)
    6b14:	75 0f                	jne    6b25 <fwp_rc_free_arr+0x75>
    6b16:	e9 f5 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b20:	66 85 c0             	test   %ax,%ax
    6b23:	74 ec                	je     6b11 <fwp_rc_free_arr+0x61>
    6b25:	c3                   	ret
    6b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b2d:	00 00 00 

0000000000006b30 <fwp_rc_dup>:
    6b30:	f3 0f 1e fa          	endbr64
    6b34:	48 8b 05 bd 30 06 00 	mov    0x630bd(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6b3b:	48 2b 3d 8e 30 06 00 	sub    0x6308e(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6b42:	48 c1 e0 10          	shl    $0x10,%rax
    6b46:	48 39 c7             	cmp    %rax,%rdi
    6b49:	73 60                	jae    6bab <fwp_rc_dup+0x7b>
    6b4b:	48 89 f8             	mov    %rdi,%rax
    6b4e:	48 c1 e8 10          	shr    $0x10,%rax
    6b52:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b56:	48 8b 05 bb 30 06 00 	mov    0x630bb(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6b5d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6b61:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6b65:	48 85 c0             	test   %rax,%rax
    6b68:	74 41                	je     6bab <fwp_rc_dup+0x7b>
    6b6a:	0f b6 0a             	movzbl (%rdx),%ecx
    6b6d:	80 f9 02             	cmp    $0x2,%cl
    6b70:	74 3e                	je     6bb0 <fwp_rc_dup+0x80>
    6b72:	80 f9 01             	cmp    $0x1,%cl
    6b75:	75 34                	jne    6bab <fwp_rc_dup+0x7b>
    6b77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b7a:	0f b7 ff             	movzwl %di,%edi
    6b7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b80:	48 0f af f9          	imul   %rcx,%rdi
    6b84:	48 c1 ef 20          	shr    $0x20,%rdi
    6b88:	48 39 d7             	cmp    %rdx,%rdi
    6b8b:	73 1e                	jae    6bab <fwp_rc_dup+0x7b>
    6b8d:	48 01 f8             	add    %rdi,%rax
    6b90:	0f b6 10             	movzbl (%rax),%edx
    6b93:	84 d2                	test   %dl,%dl
    6b95:	74 14                	je     6bab <fwp_rc_dup+0x7b>
    6b97:	8b 0d 4b 39 06 00    	mov    0x6394b(%rip),%ecx        # 6a4e8 <iteration_active>
    6b9d:	85 c9                	test   %ecx,%ecx
    6b9f:	75 1f                	jne    6bc0 <fwp_rc_dup+0x90>
    6ba1:	80 fa fd             	cmp    $0xfd,%dl
    6ba4:	77 2a                	ja     6bd0 <fwp_rc_dup+0xa0>
    6ba6:	83 c2 01             	add    $0x1,%edx
    6ba9:	88 10                	mov    %dl,(%rax)
    6bab:	c3                   	ret
    6bac:	0f 1f 40 00          	nopl   0x0(%rax)
    6bb0:	66 85 ff             	test   %di,%di
    6bb3:	74 db                	je     6b90 <fwp_rc_dup+0x60>
    6bb5:	c3                   	ret
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	48 83 05 08 39 06 00 	addq   $0x1,0x63908(%rip)        # 6a4d0 <iteration_retains>
    6bc7:	01 
    6bc8:	eb d7                	jmp    6ba1 <fwp_rc_dup+0x71>
    6bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bd0:	48 89 c7             	mov    %rax,%rdi
    6bd3:	e9 d8 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bdf:	00 

0000000000006be0 <fwp_owned_entry161>:
    6be0:	f3 0f 1e fa          	endbr64
    6be4:	48 83 ec 38          	sub    $0x38,%rsp
    6be8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bf4:	00 00 
    6bf6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bfb:	31 c0                	xor    %eax,%eax
    6bfd:	48 8b 07             	mov    (%rdi),%rax
    6c00:	48 03 47 10          	add    0x10(%rdi),%rax
    6c04:	0f 80 c2 00 00 00    	jo     6ccc <fwp_owned_entry161+0xec>
    6c0a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c0f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c14:	31 ff                	xor    %edi,%edi
    6c16:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c1a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c1f:	e8 1c fc ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6c24:	48 8b 15 cd 2f 06 00 	mov    0x62fcd(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6c2b:	48 89 c6             	mov    %rax,%rsi
    6c2e:	48 2b 05 9b 2f 06 00 	sub    0x62f9b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6c35:	48 c1 e2 10          	shl    $0x10,%rdx
    6c39:	48 39 d0             	cmp    %rdx,%rax
    6c3c:	73 4f                	jae    6c8d <fwp_owned_entry161+0xad>
    6c3e:	48 89 c2             	mov    %rax,%rdx
    6c41:	48 c1 ea 10          	shr    $0x10,%rdx
    6c45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c49:	48 8b 15 c8 2f 06 00 	mov    0x62fc8(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6c50:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c54:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c58:	48 85 d2             	test   %rdx,%rdx
    6c5b:	74 30                	je     6c8d <fwp_owned_entry161+0xad>
    6c5d:	0f b6 39             	movzbl (%rcx),%edi
    6c60:	40 80 ff 02          	cmp    $0x2,%dil
    6c64:	74 42                	je     6ca8 <fwp_owned_entry161+0xc8>
    6c66:	40 80 ff 01          	cmp    $0x1,%dil
    6c6a:	75 21                	jne    6c8d <fwp_owned_entry161+0xad>
    6c6c:	8b 79 18             	mov    0x18(%rcx),%edi
    6c6f:	0f b7 c0             	movzwl %ax,%eax
    6c72:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c75:	48 0f af c7          	imul   %rdi,%rax
    6c79:	48 c1 e8 20          	shr    $0x20,%rax
    6c7d:	48 39 c8             	cmp    %rcx,%rax
    6c80:	73 0b                	jae    6c8d <fwp_owned_entry161+0xad>
    6c82:	48 01 c2             	add    %rax,%rdx
    6c85:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c88:	74 26                	je     6cb0 <fwp_owned_entry161+0xd0>
    6c8a:	c6 02 01             	movb   $0x1,(%rdx)
    6c8d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c99:	00 00 
    6c9b:	75 34                	jne    6cd1 <fwp_owned_entry161+0xf1>
    6c9d:	48 89 f0             	mov    %rsi,%rax
    6ca0:	48 83 c4 38          	add    $0x38,%rsp
    6ca4:	c3                   	ret
    6ca5:	0f 1f 00             	nopl   (%rax)
    6ca8:	66 85 c0             	test   %ax,%ax
    6cab:	75 e0                	jne    6c8d <fwp_owned_entry161+0xad>
    6cad:	eb d6                	jmp    6c85 <fwp_owned_entry161+0xa5>
    6caf:	90                   	nop
    6cb0:	48 89 d7             	mov    %rdx,%rdi
    6cb3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6cb8:	48 89 14 24          	mov    %rdx,(%rsp)
    6cbc:	e8 0f eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6cc1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6cc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6cca:	eb be                	jmp    6c8a <fwp_owned_entry161+0xaa>
    6ccc:	e8 2f ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6cd1:	e8 7a c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cdd:	00 00 00 

0000000000006ce0 <e161>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	53                   	push   %rbx
    6ce5:	48 83 ec 30          	sub    $0x30,%rsp
    6ce9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cf5:	00 00 
    6cf7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cfc:	31 c0                	xor    %eax,%eax
    6cfe:	48 8b 07             	mov    (%rdi),%rax
    6d01:	48 03 47 10          	add    0x10(%rdi),%rax
    6d05:	0f 80 c9 00 00 00    	jo     6dd4 <e161+0xf4>
    6d0b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d10:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d15:	31 ff                	xor    %edi,%edi
    6d17:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d1b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d20:	e8 1b fb ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6d25:	48 8b 15 cc 2e 06 00 	mov    0x62ecc(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6d2c:	48 89 c3             	mov    %rax,%rbx
    6d2f:	48 2b 05 9a 2e 06 00 	sub    0x62e9a(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6d36:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3a:	48 39 d0             	cmp    %rdx,%rax
    6d3d:	73 4f                	jae    6d8e <e161+0xae>
    6d3f:	48 89 c2             	mov    %rax,%rdx
    6d42:	48 c1 ea 10          	shr    $0x10,%rdx
    6d46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d4a:	48 8b 15 c7 2e 06 00 	mov    0x62ec7(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6d51:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d55:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d59:	48 85 d2             	test   %rdx,%rdx
    6d5c:	74 30                	je     6d8e <e161+0xae>
    6d5e:	0f b6 31             	movzbl (%rcx),%esi
    6d61:	40 80 fe 02          	cmp    $0x2,%sil
    6d65:	74 49                	je     6db0 <e161+0xd0>
    6d67:	40 80 fe 01          	cmp    $0x1,%sil
    6d6b:	75 21                	jne    6d8e <e161+0xae>
    6d6d:	8b 71 18             	mov    0x18(%rcx),%esi
    6d70:	0f b7 c0             	movzwl %ax,%eax
    6d73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d76:	48 0f af c6          	imul   %rsi,%rax
    6d7a:	48 c1 e8 20          	shr    $0x20,%rax
    6d7e:	48 39 c8             	cmp    %rcx,%rax
    6d81:	73 0b                	jae    6d8e <e161+0xae>
    6d83:	48 01 c2             	add    %rax,%rdx
    6d86:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d89:	74 35                	je     6dc0 <e161+0xe0>
    6d8b:	c6 02 01             	movb   $0x1,(%rdx)
    6d8e:	48 89 df             	mov    %rbx,%rdi
    6d91:	e8 9a fc ff ff       	call   6a30 <fwp_rc_share>
    6d96:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d9b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6da2:	00 00 
    6da4:	75 33                	jne    6dd9 <e161+0xf9>
    6da6:	48 83 c4 30          	add    $0x30,%rsp
    6daa:	48 89 d8             	mov    %rbx,%rax
    6dad:	5b                   	pop    %rbx
    6dae:	c3                   	ret
    6daf:	90                   	nop
    6db0:	66 85 c0             	test   %ax,%ax
    6db3:	75 d9                	jne    6d8e <e161+0xae>
    6db5:	eb cf                	jmp    6d86 <e161+0xa6>
    6db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dbe:	00 00 
    6dc0:	48 89 d7             	mov    %rdx,%rdi
    6dc3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6dc8:	e8 03 ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6dcd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dd2:	eb b7                	jmp    6d8b <e161+0xab>
    6dd4:	e8 27 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6dd9:	e8 72 c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6dde:	66 90                	xchg   %ax,%ax

0000000000006de0 <fwp_drop0>:
    6de0:	f3 0f 1e fa          	endbr64
    6de4:	48 8b 15 0d 2e 06 00 	mov    0x62e0d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6deb:	48 89 f8             	mov    %rdi,%rax
    6dee:	48 2b 05 db 2d 06 00 	sub    0x62ddb(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6df5:	48 c1 e2 10          	shl    $0x10,%rdx
    6df9:	48 39 d0             	cmp    %rdx,%rax
    6dfc:	0f 83 be 00 00 00    	jae    6ec0 <fwp_drop0+0xe0>
    6e02:	48 83 ec 18          	sub    $0x18,%rsp
    6e06:	4c 8d 05 13 1a 06 00 	lea    0x61a13(%rip),%r8        # 68820 <fwp_heap>
    6e0d:	48 89 c2             	mov    %rax,%rdx
    6e10:	48 c1 ea 10          	shr    $0x10,%rdx
    6e14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e18:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6e1f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e27:	48 85 d2             	test   %rdx,%rdx
    6e2a:	74 3c                	je     6e68 <fwp_drop0+0x88>
    6e2c:	0f b6 31             	movzbl (%rcx),%esi
    6e2f:	40 80 fe 02          	cmp    $0x2,%sil
    6e33:	74 3b                	je     6e70 <fwp_drop0+0x90>
    6e35:	40 80 fe 01          	cmp    $0x1,%sil
    6e39:	75 2d                	jne    6e68 <fwp_drop0+0x88>
    6e3b:	8b 71 18             	mov    0x18(%rcx),%esi
    6e3e:	0f b7 c0             	movzwl %ax,%eax
    6e41:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e44:	48 0f af c6          	imul   %rsi,%rax
    6e48:	48 c1 e8 20          	shr    $0x20,%rax
    6e4c:	48 39 c8             	cmp    %rcx,%rax
    6e4f:	73 17                	jae    6e68 <fwp_drop0+0x88>
    6e51:	48 01 c2             	add    %rax,%rdx
    6e54:	0f b6 02             	movzbl (%rdx),%eax
    6e57:	84 c0                	test   %al,%al
    6e59:	74 0d                	je     6e68 <fwp_drop0+0x88>
    6e5b:	3c 01                	cmp    $0x1,%al
    6e5d:	74 21                	je     6e80 <fwp_drop0+0xa0>
    6e5f:	3c ff                	cmp    $0xff,%al
    6e61:	74 65                	je     6ec8 <fwp_drop0+0xe8>
    6e63:	83 e8 01             	sub    $0x1,%eax
    6e66:	88 02                	mov    %al,(%rdx)
    6e68:	48 83 c4 18          	add    $0x18,%rsp
    6e6c:	c3                   	ret
    6e6d:	0f 1f 00             	nopl   (%rax)
    6e70:	66 85 c0             	test   %ax,%ax
    6e73:	74 df                	je     6e54 <fwp_drop0+0x74>
    6e75:	48 83 c4 18          	add    $0x18,%rsp
    6e79:	c3                   	ret
    6e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e80:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6e84:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6e89:	e8 22 fc ff ff       	call   6ab0 <fwp_rc_free_arr>
    6e8e:	4c 8d 05 8b 19 06 00 	lea    0x6198b(%rip),%r8        # 68820 <fwp_heap>
    6e95:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6e9a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ea1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ea8:	48 c1 e2 10          	shl    $0x10,%rdx
    6eac:	48 39 d0             	cmp    %rdx,%rax
    6eaf:	73 b7                	jae    6e68 <fwp_drop0+0x88>
    6eb1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6eb6:	e9 52 ff ff ff       	jmp    6e0d <fwp_drop0+0x2d>
    6ebb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ec0:	c3                   	ret
    6ec1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ec8:	48 89 d0             	mov    %rdx,%rax
    6ecb:	48 c1 e8 11          	shr    $0x11,%rax
    6ecf:	48 31 d0             	xor    %rdx,%rax
    6ed2:	48 89 c1             	mov    %rax,%rcx
    6ed5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ed9:	48 31 c8             	xor    %rcx,%rax
    6edc:	0f b6 c8             	movzbl %al,%ecx
    6edf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6ee6:	00 
    6ee7:	48 85 c0             	test   %rax,%rax
    6eea:	75 1d                	jne    6f09 <fwp_drop0+0x129>
    6eec:	eb 56                	jmp    6f44 <fwp_drop0+0x164>
    6eee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f04:	48 85 c0             	test   %rax,%rax
    6f07:	74 3b                	je     6f44 <fwp_drop0+0x164>
    6f09:	48 89 c1             	mov    %rax,%rcx
    6f0c:	48 39 10             	cmp    %rdx,(%rax)
    6f0f:	75 ef                	jne    6f00 <fwp_drop0+0x120>
    6f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f24:	0f 85 3e ff ff ff    	jne    6e68 <fwp_drop0+0x88>
    6f2a:	48 89 d7             	mov    %rdx,%rdi
    6f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f32:	e8 99 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f3f:	e9 24 ff ff ff       	jmp    6e68 <fwp_drop0+0x88>
    6f44:	48 8d 3d 95 5a 00 00 	lea    0x5a95(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    6f4b:	e8 00 d5 ff ff       	call   4450 <fwp_trap>

0000000000006f50 <fwp_arg_drop12>:
    6f50:	f3 0f 1e fa          	endbr64
    6f54:	85 f6                	test   %esi,%esi
    6f56:	75 04                	jne    6f5c <fwp_arg_drop12+0xc>
    6f58:	85 d2                	test   %edx,%edx
    6f5a:	75 04                	jne    6f60 <fwp_arg_drop12+0x10>
    6f5c:	c3                   	ret
    6f5d:	0f 1f 00             	nopl   (%rax)
    6f60:	48 8b 3f             	mov    (%rdi),%rdi
    6f63:	e9 78 fe ff ff       	jmp    6de0 <fwp_drop0>
    6f68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f6f:	00 

0000000000006f70 <fwp_drop1>:
    6f70:	f3 0f 1e fa          	endbr64
    6f74:	48 8b 15 7d 2c 06 00 	mov    0x62c7d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6f7b:	48 89 f8             	mov    %rdi,%rax
    6f7e:	48 2b 05 4b 2c 06 00 	sub    0x62c4b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6f85:	48 c1 e2 10          	shl    $0x10,%rdx
    6f89:	48 39 d0             	cmp    %rdx,%rax
    6f8c:	0f 83 be 00 00 00    	jae    7050 <fwp_drop1+0xe0>
    6f92:	48 83 ec 18          	sub    $0x18,%rsp
    6f96:	4c 8d 05 83 18 06 00 	lea    0x61883(%rip),%r8        # 68820 <fwp_heap>
    6f9d:	48 89 c2             	mov    %rax,%rdx
    6fa0:	48 c1 ea 10          	shr    $0x10,%rdx
    6fa4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fa8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6faf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fb3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fb7:	48 85 d2             	test   %rdx,%rdx
    6fba:	74 3c                	je     6ff8 <fwp_drop1+0x88>
    6fbc:	0f b6 31             	movzbl (%rcx),%esi
    6fbf:	40 80 fe 02          	cmp    $0x2,%sil
    6fc3:	74 3b                	je     7000 <fwp_drop1+0x90>
    6fc5:	40 80 fe 01          	cmp    $0x1,%sil
    6fc9:	75 2d                	jne    6ff8 <fwp_drop1+0x88>
    6fcb:	8b 71 18             	mov    0x18(%rcx),%esi
    6fce:	0f b7 c0             	movzwl %ax,%eax
    6fd1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fd4:	48 0f af c6          	imul   %rsi,%rax
    6fd8:	48 c1 e8 20          	shr    $0x20,%rax
    6fdc:	48 39 c8             	cmp    %rcx,%rax
    6fdf:	73 17                	jae    6ff8 <fwp_drop1+0x88>
    6fe1:	48 01 c2             	add    %rax,%rdx
    6fe4:	0f b6 02             	movzbl (%rdx),%eax
    6fe7:	84 c0                	test   %al,%al
    6fe9:	74 0d                	je     6ff8 <fwp_drop1+0x88>
    6feb:	3c 01                	cmp    $0x1,%al
    6fed:	74 21                	je     7010 <fwp_drop1+0xa0>
    6fef:	3c ff                	cmp    $0xff,%al
    6ff1:	74 65                	je     7058 <fwp_drop1+0xe8>
    6ff3:	83 e8 01             	sub    $0x1,%eax
    6ff6:	88 02                	mov    %al,(%rdx)
    6ff8:	48 83 c4 18          	add    $0x18,%rsp
    6ffc:	c3                   	ret
    6ffd:	0f 1f 00             	nopl   (%rax)
    7000:	66 85 c0             	test   %ax,%ax
    7003:	74 df                	je     6fe4 <fwp_drop1+0x74>
    7005:	48 83 c4 18          	add    $0x18,%rsp
    7009:	c3                   	ret
    700a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7010:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7014:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7019:	e8 92 fa ff ff       	call   6ab0 <fwp_rc_free_arr>
    701e:	4c 8d 05 fb 17 06 00 	lea    0x617fb(%rip),%r8        # 68820 <fwp_heap>
    7025:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    702a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7031:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7038:	48 c1 e2 10          	shl    $0x10,%rdx
    703c:	48 39 d0             	cmp    %rdx,%rax
    703f:	73 b7                	jae    6ff8 <fwp_drop1+0x88>
    7041:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7046:	e9 52 ff ff ff       	jmp    6f9d <fwp_drop1+0x2d>
    704b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7050:	c3                   	ret
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	48 89 d0             	mov    %rdx,%rax
    705b:	48 c1 e8 11          	shr    $0x11,%rax
    705f:	48 31 d0             	xor    %rdx,%rax
    7062:	48 89 c1             	mov    %rax,%rcx
    7065:	48 c1 e9 09          	shr    $0x9,%rcx
    7069:	48 31 c8             	xor    %rcx,%rax
    706c:	0f b6 c8             	movzbl %al,%ecx
    706f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7076:	00 
    7077:	48 85 c0             	test   %rax,%rax
    707a:	75 0d                	jne    7089 <fwp_drop1+0x119>
    707c:	eb 46                	jmp    70c4 <fwp_drop1+0x154>
    707e:	66 90                	xchg   %ax,%ax
    7080:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	74 3b                	je     70c4 <fwp_drop1+0x154>
    7089:	48 89 c1             	mov    %rax,%rcx
    708c:	48 39 10             	cmp    %rdx,(%rax)
    708f:	75 ef                	jne    7080 <fwp_drop1+0x110>
    7091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7095:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7099:	48 89 48 08          	mov    %rcx,0x8(%rax)
    709d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    70a4:	0f 85 4e ff ff ff    	jne    6ff8 <fwp_drop1+0x88>
    70aa:	48 89 d7             	mov    %rdx,%rdi
    70ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70b2:	e8 19 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    70b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    70bf:	e9 34 ff ff ff       	jmp    6ff8 <fwp_drop1+0x88>
    70c4:	48 8d 3d 15 59 00 00 	lea    0x5915(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    70cb:	e8 80 d3 ff ff       	call   4450 <fwp_trap>

00000000000070d0 <fwp_closure_drop>:
    70d0:	48 8b 15 21 2b 06 00 	mov    0x62b21(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    70d7:	48 89 f8             	mov    %rdi,%rax
    70da:	48 2b 05 ef 2a 06 00 	sub    0x62aef(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    70e1:	48 c1 e2 10          	shl    $0x10,%rdx
    70e5:	48 39 d0             	cmp    %rdx,%rax
    70e8:	73 6b                	jae    7155 <fwp_closure_drop+0x85>
    70ea:	48 89 c2             	mov    %rax,%rdx
    70ed:	48 c1 ea 10          	shr    $0x10,%rdx
    70f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70f5:	48 8b 15 1c 2b 06 00 	mov    0x62b1c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    70fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7100:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7104:	48 85 d2             	test   %rdx,%rdx
    7107:	74 4c                	je     7155 <fwp_closure_drop+0x85>
    7109:	0f b6 31             	movzbl (%rcx),%esi
    710c:	40 80 fe 02          	cmp    $0x2,%sil
    7110:	74 3e                	je     7150 <fwp_closure_drop+0x80>
    7112:	40 80 fe 01          	cmp    $0x1,%sil
    7116:	75 3d                	jne    7155 <fwp_closure_drop+0x85>
    7118:	8b 71 18             	mov    0x18(%rcx),%esi
    711b:	0f b7 c0             	movzwl %ax,%eax
    711e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7121:	48 0f af c6          	imul   %rsi,%rax
    7125:	48 c1 e8 20          	shr    $0x20,%rax
    7129:	48 39 c8             	cmp    %rcx,%rax
    712c:	73 27                	jae    7155 <fwp_closure_drop+0x85>
    712e:	48 01 c2             	add    %rax,%rdx
    7131:	0f b6 02             	movzbl (%rdx),%eax
    7134:	84 c0                	test   %al,%al
    7136:	74 1d                	je     7155 <fwp_closure_drop+0x85>
    7138:	3c 01                	cmp    $0x1,%al
    713a:	74 24                	je     7160 <fwp_closure_drop+0x90>
    713c:	3c ff                	cmp    $0xff,%al
    713e:	74 48                	je     7188 <fwp_closure_drop+0xb8>
    7140:	83 e8 01             	sub    $0x1,%eax
    7143:	88 02                	mov    %al,(%rdx)
    7145:	c3                   	ret
    7146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    714d:	00 00 00 
    7150:	66 85 c0             	test   %ax,%ax
    7153:	74 dc                	je     7131 <fwp_closure_drop+0x61>
    7155:	c3                   	ret
    7156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    715d:	00 00 00 
    7160:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7167:	ff ff 
    7169:	48 85 c0             	test   %rax,%rax
    716c:	74 12                	je     7180 <fwp_closure_drop+0xb0>
    716e:	48 89 fe             	mov    %rdi,%rsi
    7171:	48 89 c7             	mov    %rax,%rdi
    7174:	e9 37 d3 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7180:	e9 db d4 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7185:	0f 1f 00             	nopl   (%rax)
    7188:	48 89 d0             	mov    %rdx,%rax
    718b:	48 8d 35 8e 16 06 00 	lea    0x6168e(%rip),%rsi        # 68820 <fwp_heap>
    7192:	48 83 ec 18          	sub    $0x18,%rsp
    7196:	48 c1 e8 11          	shr    $0x11,%rax
    719a:	48 31 d0             	xor    %rdx,%rax
    719d:	48 89 c1             	mov    %rax,%rcx
    71a0:	48 c1 e9 09          	shr    $0x9,%rcx
    71a4:	48 31 c8             	xor    %rcx,%rax
    71a7:	0f b6 c8             	movzbl %al,%ecx
    71aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    71b1:	00 
    71b2:	48 85 c0             	test   %rax,%rax
    71b5:	75 12                	jne    71c9 <fwp_closure_drop+0xf9>
    71b7:	eb 49                	jmp    7202 <fwp_closure_drop+0x132>
    71b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    71c4:	48 85 c0             	test   %rax,%rax
    71c7:	74 39                	je     7202 <fwp_closure_drop+0x132>
    71c9:	48 89 c1             	mov    %rax,%rcx
    71cc:	48 39 10             	cmp    %rdx,(%rax)
    71cf:	75 ef                	jne    71c0 <fwp_closure_drop+0xf0>
    71d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    71d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    71dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71e4:	74 05                	je     71eb <fwp_closure_drop+0x11b>
    71e6:	48 83 c4 18          	add    $0x18,%rsp
    71ea:	c3                   	ret
    71eb:	48 89 d7             	mov    %rdx,%rdi
    71ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71f3:	e8 d8 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    71f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7200:	eb e4                	jmp    71e6 <fwp_closure_drop+0x116>
    7202:	48 8d 3d d7 57 00 00 	lea    0x57d7(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7209:	e8 42 d2 ff ff       	call   4450 <fwp_trap>
    720e:	66 90                	xchg   %ax,%ax

0000000000007210 <fwp_owned_tape_release>:
    7210:	48 85 ff             	test   %rdi,%rdi
    7213:	0f 84 f7 00 00 00    	je     7310 <fwp_owned_tape_release+0x100>
    7219:	41 54                	push   %r12
    721b:	55                   	push   %rbp
    721c:	53                   	push   %rbx
    721d:	48 8b 07             	mov    (%rdi),%rax
    7220:	48 85 c0             	test   %rax,%rax
    7223:	74 08                	je     722d <fwp_owned_tape_release+0x1d>
    7225:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7229:	48 89 50 08          	mov    %rdx,0x8(%rax)
    722d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7231:	48 85 d2             	test   %rdx,%rdx
    7234:	74 03                	je     7239 <fwp_owned_tape_release+0x29>
    7236:	48 89 02             	mov    %rax,(%rdx)
    7239:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    723d:	48 89 fb             	mov    %rdi,%rbx
    7240:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7244:	48 85 c0             	test   %rax,%rax
    7247:	0f 84 89 00 00 00    	je     72d6 <fwp_owned_tape_release+0xc6>
    724d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7251:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7255:	7e 47                	jle    729e <fwp_owned_tape_release+0x8e>
    7257:	31 ed                	xor    %ebp,%ebp
    7259:	eb 0d                	jmp    7268 <fwp_owned_tape_release+0x58>
    725b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7260:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7264:	48 8b 40 68          	mov    0x68(%rax),%rax
    7268:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    726c:	49 89 ec             	mov    %rbp,%r12
    726f:	48 83 c5 01          	add    $0x1,%rbp
    7273:	49 c1 e4 04          	shl    $0x4,%r12
    7277:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    727b:	ff d0                	call   *%rax
    727d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7281:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7286:	48 8b 43 10          	mov    0x10(%rbx),%rax
    728a:	ff 50 68             	call   *0x68(%rax)
    728d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7291:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7295:	48 39 e8             	cmp    %rbp,%rax
    7298:	7f c6                	jg     7260 <fwp_owned_tape_release+0x50>
    729a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    729e:	31 ed                	xor    %ebp,%ebp
    72a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    72a5:	7e 28                	jle    72cf <fwp_owned_tape_release+0xbf>
    72a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ae:	00 00 
    72b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    72b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    72b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    72bc:	74 07                	je     72c5 <fwp_owned_tape_release+0xb5>
    72be:	ff 52 68             	call   *0x68(%rdx)
    72c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    72c5:	48 83 c5 01          	add    $0x1,%rbp
    72c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    72cd:	7f e1                	jg     72b0 <fwp_owned_tape_release+0xa0>
    72cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    72d3:	ff 52 68             	call   *0x68(%rdx)
    72d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    72da:	e8 f1 fd ff ff       	call   70d0 <fwp_closure_drop>
    72df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    72e3:	e8 e8 fd ff ff       	call   70d0 <fwp_closure_drop>
    72e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    72ec:	e8 df fd ff ff       	call   70d0 <fwp_closure_drop>
    72f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    72f5:	e8 16 e7 ff ff       	call   5a10 <fwp_mem_free>
    72fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    72fe:	e8 0d e7 ff ff       	call   5a10 <fwp_mem_free>
    7303:	48 89 df             	mov    %rbx,%rdi
    7306:	5b                   	pop    %rbx
    7307:	5d                   	pop    %rbp
    7308:	41 5c                	pop    %r12
    730a:	e9 01 e7 ff ff       	jmp    5a10 <fwp_mem_free>
    730f:	90                   	nop
    7310:	c3                   	ret
    7311:	0f 1f 40 00          	nopl   0x0(%rax)
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 

0000000000007320 <fwp_tape_finish>:
    7320:	f3 0f 1e fa          	endbr64
    7324:	41 55                	push   %r13
    7326:	41 54                	push   %r12
    7328:	55                   	push   %rbp
    7329:	53                   	push   %rbx
    732a:	48 83 ec 48          	sub    $0x48,%rsp
    732e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7335:	00 00 
    7337:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    733c:	48 8d 3d 5d 8d 01 00 	lea    0x18d5d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    7343:	e8 f8 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7348:	48 83 3d 98 8d 01 00 	cmpq   $0x0,0x18d98(%rip)        # 200e8 <fwp_ntapes>
    734f:	00 
    7350:	48 c7 05 2d 8d 01 00 	movq   $0x0,0x18d2d(%rip)        # 20088 <fwp_tape_cached_bytes>
    7357:	00 00 00 00 
    735b:	7e 79                	jle    73d6 <fwp_tape_finish+0xb6>
    735d:	45 31 e4             	xor    %r12d,%r12d
    7360:	31 ed                	xor    %ebp,%ebp
    7362:	0f 1f 00             	nopl   (%rax)
    7365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    736c:	00 00 00 00 
    7370:	48 8b 1d 79 8d 01 00 	mov    0x18d79(%rip),%rbx        # 200f0 <fwp_tapes>
    7377:	48 83 c5 01          	add    $0x1,%rbp
    737b:	4c 01 e3             	add    %r12,%rbx
    737e:	49 83 c4 68          	add    $0x68,%r12
    7382:	48 89 df             	mov    %rbx,%rdi
    7385:	e8 06 c9 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    738a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    738f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7394:	48 89 e7             	mov    %rsp,%rdi
    7397:	48 8b 43 40          	mov    0x40(%rbx),%rax
    739b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    739f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    73a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    73a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    73ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    73b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    73b7:	e8 84 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    73bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    73c0:	e8 4b fe ff ff       	call   7210 <fwp_owned_tape_release>
    73c5:	48 39 2d 1c 8d 01 00 	cmp    %rbp,0x18d1c(%rip)        # 200e8 <fwp_ntapes>
    73cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    73d3:	00 
    73d4:	7f 9a                	jg     7370 <fwp_tape_finish+0x50>
    73d6:	48 8b 3d 13 8d 01 00 	mov    0x18d13(%rip),%rdi        # 200f0 <fwp_tapes>
    73dd:	48 85 ff             	test   %rdi,%rdi
    73e0:	74 05                	je     73e7 <fwp_tape_finish+0xc7>
    73e2:	e8 e9 dc ff ff       	call   50d0 <ad_raw_free.part.0>
    73e7:	48 c7 05 fe 8c 01 00 	movq   $0x0,0x18cfe(%rip)        # 200f0 <fwp_tapes>
    73ee:	00 00 00 00 
    73f2:	48 c7 05 e3 8c 01 00 	movq   $0x0,0x18ce3(%rip)        # 200e0 <fwp_tapes_cap>
    73f9:	00 00 00 00 
    73fd:	48 c7 05 e0 8c 01 00 	movq   $0x0,0x18ce0(%rip)        # 200e8 <fwp_ntapes>
    7404:	00 00 00 00 
    7408:	48 c7 05 c5 8c 01 00 	movq   $0x0,0x18cc5(%rip)        # 200d8 <fwp_tape_next_slot>
    740f:	00 00 00 00 
    7413:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7418:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    741f:	00 00 
    7421:	75 0b                	jne    742e <fwp_tape_finish+0x10e>
    7423:	48 83 c4 48          	add    $0x48,%rsp
    7427:	5b                   	pop    %rbx
    7428:	5d                   	pop    %rbp
    7429:	41 5c                	pop    %r12
    742b:	41 5d                	pop    %r13
    742d:	c3                   	ret
    742e:	e8 1d c0 ff ff       	call   3450 <__stack_chk_fail@plt>
    7433:	66 90                	xchg   %ax,%ax
    7435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    743c:	00 00 00 00 

0000000000007440 <fwp_tape_scope_release>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	41 55                	push   %r13
    7446:	41 54                	push   %r12
    7448:	55                   	push   %rbp
    7449:	53                   	push   %rbx
    744a:	48 83 ec 48          	sub    $0x48,%rsp
    744e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7455:	00 00 
    7457:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    745c:	48 63 07             	movslq (%rdi),%rax
    745f:	85 c0                	test   %eax,%eax
    7461:	0f 88 e8 00 00 00    	js     754f <fwp_tape_scope_release+0x10f>
    7467:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    746e:	ec c4 4e 
    7471:	48 89 fb             	mov    %rdi,%rbx
    7474:	48 89 e5             	mov    %rsp,%rbp
    7477:	eb 1f                	jmp    7498 <fwp_tape_scope_release+0x58>
    7479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7480:	e8 bb dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7485:	4c 89 ef             	mov    %r13,%rdi
    7488:	e8 83 fd ff ff       	call   7210 <fwp_owned_tape_release>
    748d:	48 63 03             	movslq (%rbx),%rax
    7490:	85 c0                	test   %eax,%eax
    7492:	0f 88 b7 00 00 00    	js     754f <fwp_tape_scope_release+0x10f>
    7498:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    749c:	48 8b 35 4d 8c 01 00 	mov    0x18c4d(%rip),%rsi        # 200f0 <fwp_tapes>
    74a3:	4c 01 c6             	add    %r8,%rsi
    74a6:	48 89 f7             	mov    %rsi,%rdi
    74a9:	e8 e2 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    74ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    74b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    74b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    74bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    74c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    74c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    74ce:	00 
    74cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    74d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    74d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    74dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    74f2:	00 
    74f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    74fa:	00 
    74fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7502:	00 
    7503:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7507:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    750b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    750f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7513:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7519:	77 18                	ja     7533 <fwp_tape_scope_release+0xf3>
    751b:	49 c1 f8 03          	sar    $0x3,%r8
    751f:	4d 0f af c4          	imul   %r12,%r8
    7523:	4c 3b 05 ae 8b 01 00 	cmp    0x18bae(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    752a:	7d 07                	jge    7533 <fwp_tape_scope_release+0xf3>
    752c:	4c 89 05 a5 8b 01 00 	mov    %r8,0x18ba5(%rip)        # 200d8 <fwp_tape_next_slot>
    7533:	48 89 ef             	mov    %rbp,%rdi
    7536:	4d 85 ed             	test   %r13,%r13
    7539:	0f 85 41 ff ff ff    	jne    7480 <fwp_tape_scope_release+0x40>
    753f:	e8 1c dd ff ff       	call   5260 <fwp_tape_buffers_release>
    7544:	48 63 03             	movslq (%rbx),%rax
    7547:	85 c0                	test   %eax,%eax
    7549:	0f 89 49 ff ff ff    	jns    7498 <fwp_tape_scope_release+0x58>
    754f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7554:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    755b:	00 00 
    755d:	75 0b                	jne    756a <fwp_tape_scope_release+0x12a>
    755f:	48 83 c4 48          	add    $0x48,%rsp
    7563:	5b                   	pop    %rbx
    7564:	5d                   	pop    %rbp
    7565:	41 5c                	pop    %r12
    7567:	41 5d                	pop    %r13
    7569:	c3                   	ret
    756a:	e8 e1 be ff ff       	call   3450 <__stack_chk_fail@plt>
    756f:	90                   	nop

0000000000007570 <fwp_task_dispose>:
    7570:	53                   	push   %rbx
    7571:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7575:	0f 84 cb c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    757b:	48 89 fb             	mov    %rdi,%rbx
    757e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7583:	0f 85 bd c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7589:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    758d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7594:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    759b:	00 
    759c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    75a0:	48 85 ff             	test   %rdi,%rdi
    75a3:	74 07                	je     75ac <fwp_task_dispose+0x3c>
    75a5:	48 85 c0             	test   %rax,%rax
    75a8:	74 02                	je     75ac <fwp_task_dispose+0x3c>
    75aa:	ff d0                	call   *%rax
    75ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    75b3:	e8 58 e4 ff ff       	call   5a10 <fwp_mem_free>
    75b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    75bf:	00 00 00 00 
    75c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    75c7:	74 6f                	je     7638 <fwp_task_dispose+0xc8>
    75c9:	48 8b 15 28 26 06 00 	mov    0x62628(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    75d0:	48 89 d8             	mov    %rbx,%rax
    75d3:	48 2b 05 f6 25 06 00 	sub    0x625f6(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    75da:	48 c1 e2 10          	shl    $0x10,%rdx
    75de:	48 39 d0             	cmp    %rdx,%rax
    75e1:	73 4c                	jae    762f <fwp_task_dispose+0xbf>
    75e3:	48 89 c2             	mov    %rax,%rdx
    75e6:	48 c1 ea 10          	shr    $0x10,%rdx
    75ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75ee:	48 8b 15 23 26 06 00 	mov    0x62623(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    75f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75fd:	48 85 c9             	test   %rcx,%rcx
    7600:	74 2d                	je     762f <fwp_task_dispose+0xbf>
    7602:	0f b6 32             	movzbl (%rdx),%esi
    7605:	40 80 fe 02          	cmp    $0x2,%sil
    7609:	74 3d                	je     7648 <fwp_task_dispose+0xd8>
    760b:	40 80 fe 01          	cmp    $0x1,%sil
    760f:	75 1e                	jne    762f <fwp_task_dispose+0xbf>
    7611:	8b 72 18             	mov    0x18(%rdx),%esi
    7614:	0f b7 c0             	movzwl %ax,%eax
    7617:	8b 52 1c             	mov    0x1c(%rdx),%edx
    761a:	48 0f af c6          	imul   %rsi,%rax
    761e:	48 c1 e8 20          	shr    $0x20,%rax
    7622:	48 39 d0             	cmp    %rdx,%rax
    7625:	73 08                	jae    762f <fwp_task_dispose+0xbf>
    7627:	48 01 c1             	add    %rax,%rcx
    762a:	80 39 01             	cmpb   $0x1,(%rcx)
    762d:	74 09                	je     7638 <fwp_task_dispose+0xc8>
    762f:	5b                   	pop    %rbx
    7630:	c3                   	ret
    7631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7638:	48 89 df             	mov    %rbx,%rdi
    763b:	5b                   	pop    %rbx
    763c:	e9 cf e3 ff ff       	jmp    5a10 <fwp_mem_free>
    7641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7648:	66 85 c0             	test   %ax,%ax
    764b:	74 dd                	je     762a <fwp_task_dispose+0xba>
    764d:	5b                   	pop    %rbx
    764e:	c3                   	ret
    764f:	90                   	nop

0000000000007650 <fwp_free_zombie>:
    7650:	48 8b 15 99 11 06 00 	mov    0x61199(%rip),%rdx        # 687f0 <fwp_zombie>
    7657:	48 85 d2             	test   %rdx,%rdx
    765a:	0f 84 98 00 00 00    	je     76f8 <fwp_free_zombie+0xa8>
    7660:	48 3b 15 99 11 06 00 	cmp    0x61199(%rip),%rdx        # 68800 <fwp_cur>
    7667:	0f 84 8b 00 00 00    	je     76f8 <fwp_free_zombie+0xa8>
    766d:	48 83 ec 18          	sub    $0x18,%rsp
    7671:	48 63 05 5c 0b 06 00 	movslq 0x60b5c(%rip),%rax        # 681d4 <fwp_stack_pool_n>
    7678:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    767c:	83 f8 3f             	cmp    $0x3f,%eax
    767f:	7f 7f                	jg     7700 <fwp_free_zombie+0xb0>
    7681:	8d 48 01             	lea    0x1(%rax),%ecx
    7684:	89 0d 4a 0b 06 00    	mov    %ecx,0x60b4a(%rip)        # 681d4 <fwp_stack_pool_n>
    768a:	48 8d 0d 4f 0b 06 00 	lea    0x60b4f(%rip),%rcx        # 681e0 <fwp_stack_pool>
    7691:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7695:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    769c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    76a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    76ab:	48 85 c9             	test   %rcx,%rcx
    76ae:	0f 84 fc 00 00 00    	je     77b0 <fwp_free_zombie+0x160>
    76b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    76bb:	48 85 c0             	test   %rax,%rax
    76be:	74 07                	je     76c7 <fwp_free_zombie+0x77>
    76c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    76c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    76ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76ce:	48 c7 05 17 11 06 00 	movq   $0x0,0x61117(%rip)        # 687f0 <fwp_zombie>
    76d5:	00 00 00 00 
    76d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    76e0:	85 c0                	test   %eax,%eax
    76e2:	74 34                	je     7718 <fwp_free_zombie+0xc8>
    76e4:	83 f8 01             	cmp    $0x1,%eax
    76e7:	0f 84 b3 00 00 00    	je     77a0 <fwp_free_zombie+0x150>
    76ed:	48 83 c4 18          	add    $0x18,%rsp
    76f1:	c3                   	ret
    76f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f8:	c3                   	ret
    76f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7700:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7704:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7709:	e8 b2 be ff ff       	call   35c0 <munmap@plt>
    770e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7713:	eb 80                	jmp    7695 <fwp_free_zombie+0x45>
    7715:	0f 1f 00             	nopl   (%rax)
    7718:	48 8b 0d d9 24 06 00 	mov    0x624d9(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    771f:	48 89 d0             	mov    %rdx,%rax
    7722:	48 2b 05 a7 24 06 00 	sub    0x624a7(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7729:	48 c1 e1 10          	shl    $0x10,%rcx
    772d:	48 39 c8             	cmp    %rcx,%rax
    7730:	73 bb                	jae    76ed <fwp_free_zombie+0x9d>
    7732:	48 89 c1             	mov    %rax,%rcx
    7735:	48 c1 e9 10          	shr    $0x10,%rcx
    7739:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    773d:	48 8b 0d d4 24 06 00 	mov    0x624d4(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    7744:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7748:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    774c:	48 85 c9             	test   %rcx,%rcx
    774f:	74 9c                	je     76ed <fwp_free_zombie+0x9d>
    7751:	0f b6 3e             	movzbl (%rsi),%edi
    7754:	40 80 ff 02          	cmp    $0x2,%dil
    7758:	74 66                	je     77c0 <fwp_free_zombie+0x170>
    775a:	40 80 ff 01          	cmp    $0x1,%dil
    775e:	75 8d                	jne    76ed <fwp_free_zombie+0x9d>
    7760:	8b 7e 18             	mov    0x18(%rsi),%edi
    7763:	0f b7 c0             	movzwl %ax,%eax
    7766:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7769:	48 0f af c7          	imul   %rdi,%rax
    776d:	48 c1 e8 20          	shr    $0x20,%rax
    7771:	48 39 f0             	cmp    %rsi,%rax
    7774:	0f 83 73 ff ff ff    	jae    76ed <fwp_free_zombie+0x9d>
    777a:	48 01 c1             	add    %rax,%rcx
    777d:	0f b6 01             	movzbl (%rcx),%eax
    7780:	84 c0                	test   %al,%al
    7782:	0f 84 65 ff ff ff    	je     76ed <fwp_free_zombie+0x9d>
    7788:	3c 01                	cmp    $0x1,%al
    778a:	74 14                	je     77a0 <fwp_free_zombie+0x150>
    778c:	3c ff                	cmp    $0xff,%al
    778e:	74 3b                	je     77cb <fwp_free_zombie+0x17b>
    7790:	83 e8 01             	sub    $0x1,%eax
    7793:	88 01                	mov    %al,(%rcx)
    7795:	e9 53 ff ff ff       	jmp    76ed <fwp_free_zombie+0x9d>
    779a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77a0:	48 89 d7             	mov    %rdx,%rdi
    77a3:	48 83 c4 18          	add    $0x18,%rsp
    77a7:	e9 c4 fd ff ff       	jmp    7570 <fwp_task_dispose>
    77ac:	0f 1f 40 00          	nopl   0x0(%rax)
    77b0:	48 89 05 11 10 06 00 	mov    %rax,0x61011(%rip)        # 687c8 <fwp_tasks_active>
    77b7:	e9 ff fe ff ff       	jmp    76bb <fwp_free_zombie+0x6b>
    77bc:	0f 1f 40 00          	nopl   0x0(%rax)
    77c0:	66 85 c0             	test   %ax,%ax
    77c3:	0f 85 24 ff ff ff    	jne    76ed <fwp_free_zombie+0x9d>
    77c9:	eb b2                	jmp    777d <fwp_free_zombie+0x12d>
    77cb:	48 89 ca             	mov    %rcx,%rdx
    77ce:	48 8d 35 4b 10 06 00 	lea    0x6104b(%rip),%rsi        # 68820 <fwp_heap>
    77d5:	48 c1 ea 11          	shr    $0x11,%rdx
    77d9:	48 31 ca             	xor    %rcx,%rdx
    77dc:	48 89 d0             	mov    %rdx,%rax
    77df:	48 c1 e8 09          	shr    $0x9,%rax
    77e3:	48 31 c2             	xor    %rax,%rdx
    77e6:	0f b6 d2             	movzbl %dl,%edx
    77e9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    77f0:	00 
    77f1:	48 85 c0             	test   %rax,%rax
    77f4:	75 13                	jne    7809 <fwp_free_zombie+0x1b9>
    77f6:	eb 4c                	jmp    7844 <fwp_free_zombie+0x1f4>
    77f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77ff:	00 
    7800:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	74 3b                	je     7844 <fwp_free_zombie+0x1f4>
    7809:	48 89 c2             	mov    %rax,%rdx
    780c:	48 39 08             	cmp    %rcx,(%rax)
    780f:	75 ef                	jne    7800 <fwp_free_zombie+0x1b0>
    7811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7815:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7819:	48 89 50 08          	mov    %rdx,0x8(%rax)
    781d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7824:	0f 85 c3 fe ff ff    	jne    76ed <fwp_free_zombie+0x9d>
    782a:	48 89 cf             	mov    %rcx,%rdi
    782d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7832:	e8 99 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    7837:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    783c:	c6 01 fe             	movb   $0xfe,(%rcx)
    783f:	e9 a9 fe ff ff       	jmp    76ed <fwp_free_zombie+0x9d>
    7844:	48 8d 3d 95 51 00 00 	lea    0x5195(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    784b:	e8 00 cc ff ff       	call   4450 <fwp_trap>

0000000000007850 <fwp_block>:
    7850:	48 83 ec 08          	sub    $0x8,%rsp
    7854:	48 8b 05 8d 0f 06 00 	mov    0x60f8d(%rip),%rax        # 687e8 <fwp_ready_head>
    785b:	48 85 c0             	test   %rax,%rax
    785e:	0f 84 1c 01 00 00    	je     7980 <fwp_block+0x130>
    7864:	90                   	nop
    7865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    786c:	00 00 00 00 
    7870:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7877:	48 89 15 6a 0f 06 00 	mov    %rdx,0x60f6a(%rip)        # 687e8 <fwp_ready_head>
    787e:	48 85 d2             	test   %rdx,%rdx
    7881:	0f 84 19 01 00 00    	je     79a0 <fwp_block+0x150>
    7887:	48 8b 15 72 0f 06 00 	mov    0x60f72(%rip),%rdx        # 68800 <fwp_cur>
    788e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7892:	48 39 c2             	cmp    %rax,%rdx
    7895:	0f 84 d5 00 00 00    	je     7970 <fwp_block+0x120>
    789b:	48 8b 0d e6 2b 06 00 	mov    0x62be6(%rip),%rcx        # 6a488 <fwp_state_owners>
    78a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    78a6:	48 89 05 53 0f 06 00 	mov    %rax,0x60f53(%rip)        # 68800 <fwp_cur>
    78ad:	f3 0f 7e 05 fb 2b 06 	movq   0x62bfb(%rip),%xmm0        # 6a4b0 <fwp_foreign_callbacks>
    78b4:	00 
    78b5:	0f 16 05 e4 2b 06 00 	movhps 0x62be4(%rip),%xmm0        # 6a4a0 <fwp_state>
    78bc:	f3 0f 7e 0d e4 2b 06 	movq   0x62be4(%rip),%xmm1        # 6a4a8 <fwp_handlers>
    78c3:	00 
    78c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    78cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    78d2:	0f 16 0d df 2b 06 00 	movhps 0x62bdf(%rip),%xmm1        # 6a4b8 <fwp_cleanups>
    78d9:	f3 0f 7e 05 b7 2b 06 	movq   0x62bb7(%rip),%xmm0        # 6a498 <fwp_state_len>
    78e0:	00 
    78e1:	0f 16 05 a8 2b 06 00 	movhps 0x62ba8(%rip),%xmm0        # 6a490 <fwp_state_cap>
    78e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    78ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    78f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7901:	48 89 0d a0 2b 06 00 	mov    %rcx,0x62ba0(%rip)        # 6a4a8 <fwp_handlers>
    7908:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    790f:	48 89 0d a2 2b 06 00 	mov    %rcx,0x62ba2(%rip)        # 6a4b8 <fwp_cleanups>
    7916:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    791d:	48 89 0d 8c 2b 06 00 	mov    %rcx,0x62b8c(%rip)        # 6a4b0 <fwp_foreign_callbacks>
    7924:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    792b:	48 89 0d 6e 2b 06 00 	mov    %rcx,0x62b6e(%rip)        # 6a4a0 <fwp_state>
    7932:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7939:	48 89 0d 58 2b 06 00 	mov    %rcx,0x62b58(%rip)        # 6a498 <fwp_state_len>
    7940:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7947:	48 89 0d 42 2b 06 00 	mov    %rcx,0x62b42(%rip)        # 6a490 <fwp_state_cap>
    794e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7955:	48 89 0d 2c 2b 06 00 	mov    %rcx,0x62b2c(%rip)        # 6a488 <fwp_state_owners>
    795c:	e8 1f bb ff ff       	call   3480 <swapcontext@plt>
    7961:	f3 0f 1e fa          	endbr64
    7965:	e8 e6 fc ff ff       	call   7650 <fwp_free_zombie>
    796a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7970:	8b 05 5a 08 06 00    	mov    0x6085a(%rip),%eax        # 681d0 <fwp_slice>
    7976:	85 c0                	test   %eax,%eax
    7978:	74 36                	je     79b0 <fwp_block+0x160>
    797a:	48 83 c4 08          	add    $0x8,%rsp
    797e:	c3                   	ret
    797f:	90                   	nop
    7980:	e8 8b da ff ff       	call   5410 <fwp_poll_events>
    7985:	48 8b 05 5c 0e 06 00 	mov    0x60e5c(%rip),%rax        # 687e8 <fwp_ready_head>
    798c:	48 85 c0             	test   %rax,%rax
    798f:	0f 85 db fe ff ff    	jne    7870 <fwp_block+0x20>
    7995:	eb e9                	jmp    7980 <fwp_block+0x130>
    7997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    799e:	00 00 
    79a0:	48 c7 05 35 0e 06 00 	movq   $0x0,0x60e35(%rip)        # 687e0 <fwp_ready_tail>
    79a7:	00 00 00 00 
    79ab:	e9 d7 fe ff ff       	jmp    7887 <fwp_block+0x37>
    79b0:	48 8d 3d 28 48 00 00 	lea    0x4828(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    79b7:	e8 d4 b9 ff ff       	call   3390 <getenv@plt>
    79bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    79c1:	48 85 c0             	test   %rax,%rax
    79c4:	74 05                	je     79cb <fwp_block+0x17b>
    79c6:	80 38 00             	cmpb   $0x0,(%rax)
    79c9:	75 0b                	jne    79d6 <fwp_block+0x186>
    79cb:	89 15 ff 07 06 00    	mov    %edx,0x607ff(%rip)        # 681d0 <fwp_slice>
    79d1:	48 83 c4 08          	add    $0x8,%rsp
    79d5:	c3                   	ret
    79d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    79db:	31 f6                	xor    %esi,%esi
    79dd:	48 89 c7             	mov    %rax,%rdi
    79e0:	e8 5b bb ff ff       	call   3540 <strtoll@plt>
    79e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    79e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    79f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    79f5:	0f 46 d0             	cmovbe %eax,%edx
    79f8:	eb d1                	jmp    79cb <fwp_block+0x17b>
    79fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007a00 <fwp_drop4>:
    7a00:	48 8b 15 f1 21 06 00 	mov    0x621f1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7a07:	48 89 f8             	mov    %rdi,%rax
    7a0a:	48 2b 05 bf 21 06 00 	sub    0x621bf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7a11:	48 c1 e2 10          	shl    $0x10,%rdx
    7a15:	48 39 d0             	cmp    %rdx,%rax
    7a18:	0f 83 52 01 00 00    	jae    7b70 <fwp_drop4+0x170>
    7a1e:	48 83 ec 18          	sub    $0x18,%rsp
    7a22:	4c 8d 05 f7 0d 06 00 	lea    0x60df7(%rip),%r8        # 68820 <fwp_heap>
    7a29:	48 89 c2             	mov    %rax,%rdx
    7a2c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7a33:	48 c1 ea 10          	shr    $0x10,%rdx
    7a37:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a3b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7a3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a43:	48 85 d2             	test   %rdx,%rdx
    7a46:	74 46                	je     7a8e <fwp_drop4+0x8e>
    7a48:	44 0f b6 09          	movzbl (%rcx),%r9d
    7a4c:	41 80 f9 02          	cmp    $0x2,%r9b
    7a50:	0f 84 ca 00 00 00    	je     7b20 <fwp_drop4+0x120>
    7a56:	41 80 f9 01          	cmp    $0x1,%r9b
    7a5a:	75 32                	jne    7a8e <fwp_drop4+0x8e>
    7a5c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7a60:	0f b7 c0             	movzwl %ax,%eax
    7a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a66:	49 0f af c1          	imul   %r9,%rax
    7a6a:	48 c1 e8 20          	shr    $0x20,%rax
    7a6e:	48 39 c8             	cmp    %rcx,%rax
    7a71:	73 1b                	jae    7a8e <fwp_drop4+0x8e>
    7a73:	48 01 c2             	add    %rax,%rdx
    7a76:	0f b6 02             	movzbl (%rdx),%eax
    7a79:	84 c0                	test   %al,%al
    7a7b:	74 11                	je     7a8e <fwp_drop4+0x8e>
    7a7d:	3c 01                	cmp    $0x1,%al
    7a7f:	74 17                	je     7a98 <fwp_drop4+0x98>
    7a81:	3c ff                	cmp    $0xff,%al
    7a83:	0f 84 ef 00 00 00    	je     7b78 <fwp_drop4+0x178>
    7a89:	83 e8 01             	sub    $0x1,%eax
    7a8c:	88 02                	mov    %al,(%rdx)
    7a8e:	48 83 c4 18          	add    $0x18,%rsp
    7a92:	c3                   	ret
    7a93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a98:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7a9c:	0f 88 8e 00 00 00    	js     7b30 <fwp_drop4+0x130>
    7aa2:	48 8b 15 4f 21 06 00 	mov    0x6214f(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7aa9:	48 89 f8             	mov    %rdi,%rax
    7aac:	48 2b 05 1d 21 06 00 	sub    0x6211d(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ab3:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab7:	48 39 d0             	cmp    %rdx,%rax
    7aba:	73 d2                	jae    7a8e <fwp_drop4+0x8e>
    7abc:	48 89 c2             	mov    %rax,%rdx
    7abf:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7ac7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7acb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7acf:	48 85 c9             	test   %rcx,%rcx
    7ad2:	74 ba                	je     7a8e <fwp_drop4+0x8e>
    7ad4:	0f b6 32             	movzbl (%rdx),%esi
    7ad7:	40 80 fe 02          	cmp    $0x2,%sil
    7adb:	74 33                	je     7b10 <fwp_drop4+0x110>
    7add:	40 80 fe 01          	cmp    $0x1,%sil
    7ae1:	75 ab                	jne    7a8e <fwp_drop4+0x8e>
    7ae3:	8b 72 18             	mov    0x18(%rdx),%esi
    7ae6:	0f b7 c0             	movzwl %ax,%eax
    7ae9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aec:	48 0f af c6          	imul   %rsi,%rax
    7af0:	48 c1 e8 20          	shr    $0x20,%rax
    7af4:	48 39 d0             	cmp    %rdx,%rax
    7af7:	73 95                	jae    7a8e <fwp_drop4+0x8e>
    7af9:	48 01 c1             	add    %rax,%rcx
    7afc:	80 39 01             	cmpb   $0x1,(%rcx)
    7aff:	75 8d                	jne    7a8e <fwp_drop4+0x8e>
    7b01:	48 83 c4 18          	add    $0x18,%rsp
    7b05:	e9 06 df ff ff       	jmp    5a10 <fwp_mem_free>
    7b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 e7                	je     7afc <fwp_drop4+0xfc>
    7b15:	48 83 c4 18          	add    $0x18,%rsp
    7b19:	c3                   	ret
    7b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b20:	66 85 c0             	test   %ax,%ax
    7b23:	0f 84 4d ff ff ff    	je     7a76 <fwp_drop4+0x76>
    7b29:	48 83 c4 18          	add    $0x18,%rsp
    7b2d:	c3                   	ret
    7b2e:	66 90                	xchg   %ax,%ax
    7b30:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7b34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b39:	e8 72 ef ff ff       	call   6ab0 <fwp_rc_free_arr>
    7b3e:	4c 8d 05 db 0c 06 00 	lea    0x60cdb(%rip),%r8        # 68820 <fwp_heap>
    7b45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7b51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7b58:	48 c1 e2 10          	shl    $0x10,%rdx
    7b5c:	48 39 d0             	cmp    %rdx,%rax
    7b5f:	0f 83 29 ff ff ff    	jae    7a8e <fwp_drop4+0x8e>
    7b65:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7b6a:	e9 ba fe ff ff       	jmp    7a29 <fwp_drop4+0x29>
    7b6f:	90                   	nop
    7b70:	c3                   	ret
    7b71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b78:	48 89 d0             	mov    %rdx,%rax
    7b7b:	48 c1 e8 11          	shr    $0x11,%rax
    7b7f:	48 31 d0             	xor    %rdx,%rax
    7b82:	48 89 c1             	mov    %rax,%rcx
    7b85:	48 c1 e9 09          	shr    $0x9,%rcx
    7b89:	48 31 c8             	xor    %rcx,%rax
    7b8c:	0f b6 c8             	movzbl %al,%ecx
    7b8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7b96:	00 
    7b97:	48 85 c0             	test   %rax,%rax
    7b9a:	75 0d                	jne    7ba9 <fwp_drop4+0x1a9>
    7b9c:	eb 46                	jmp    7be4 <fwp_drop4+0x1e4>
    7b9e:	66 90                	xchg   %ax,%ax
    7ba0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ba4:	48 85 c0             	test   %rax,%rax
    7ba7:	74 3b                	je     7be4 <fwp_drop4+0x1e4>
    7ba9:	48 89 c1             	mov    %rax,%rcx
    7bac:	48 39 10             	cmp    %rdx,(%rax)
    7baf:	75 ef                	jne    7ba0 <fwp_drop4+0x1a0>
    7bb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7bc4:	0f 85 c4 fe ff ff    	jne    7a8e <fwp_drop4+0x8e>
    7bca:	48 89 d7             	mov    %rdx,%rdi
    7bcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bd2:	e8 f9 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7bd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7bdf:	e9 aa fe ff ff       	jmp    7a8e <fwp_drop4+0x8e>
    7be4:	48 8d 3d f5 4d 00 00 	lea    0x4df5(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7beb:	e8 60 c8 ff ff       	call   4450 <fwp_trap>

0000000000007bf0 <fwp_caps161>:
    7bf0:	f3 0f 1e fa          	endbr64
    7bf4:	85 f6                	test   %esi,%esi
    7bf6:	74 08                	je     7c00 <fwp_caps161+0x10>
    7bf8:	c3                   	ret
    7bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c00:	48 8b 15 f1 1f 06 00 	mov    0x61ff1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7c07:	48 89 f8             	mov    %rdi,%rax
    7c0a:	48 2b 05 bf 1f 06 00 	sub    0x61fbf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7c11:	48 c1 e2 10          	shl    $0x10,%rdx
    7c15:	48 39 d0             	cmp    %rdx,%rax
    7c18:	73 de                	jae    7bf8 <fwp_caps161+0x8>
    7c1a:	48 89 c2             	mov    %rax,%rdx
    7c1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7c21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c25:	48 8b 15 ec 1f 06 00 	mov    0x61fec(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7c2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7c34:	48 85 c9             	test   %rcx,%rcx
    7c37:	74 bf                	je     7bf8 <fwp_caps161+0x8>
    7c39:	0f b6 32             	movzbl (%rdx),%esi
    7c3c:	40 80 fe 02          	cmp    $0x2,%sil
    7c40:	74 2e                	je     7c70 <fwp_caps161+0x80>
    7c42:	40 80 fe 01          	cmp    $0x1,%sil
    7c46:	75 b0                	jne    7bf8 <fwp_caps161+0x8>
    7c48:	8b 72 18             	mov    0x18(%rdx),%esi
    7c4b:	0f b7 c0             	movzwl %ax,%eax
    7c4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c51:	48 0f af c6          	imul   %rsi,%rax
    7c55:	48 c1 e8 20          	shr    $0x20,%rax
    7c59:	48 39 d0             	cmp    %rdx,%rax
    7c5c:	73 9a                	jae    7bf8 <fwp_caps161+0x8>
    7c5e:	48 01 c1             	add    %rax,%rcx
    7c61:	80 39 01             	cmpb   $0x1,(%rcx)
    7c64:	75 92                	jne    7bf8 <fwp_caps161+0x8>
    7c66:	e9 a5 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c70:	66 85 c0             	test   %ax,%ax
    7c73:	74 ec                	je     7c61 <fwp_caps161+0x71>
    7c75:	c3                   	ret
    7c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c7d:	00 00 00 

0000000000007c80 <f12>:
    7c80:	41 57                	push   %r15
    7c82:	41 56                	push   %r14
    7c84:	41 55                	push   %r13
    7c86:	41 54                	push   %r12
    7c88:	4c 8d 25 b1 f7 ff ff 	lea    -0x84f(%rip),%r12        # 7440 <fwp_tape_scope_release>
    7c8f:	55                   	push   %rbp
    7c90:	53                   	push   %rbx
    7c91:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    7c98:	48 8b 05 19 28 06 00 	mov    0x62819(%rip),%rax        # 6a4b8 <fwp_cleanups>
    7c9f:	48 8b 15 52 1f 06 00 	mov    0x61f52(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7ca6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    7cad:	00 00 
    7caf:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    7cb6:	00 
    7cb7:	48 89 fd             	mov    %rdi,%rbp
    7cba:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7cc1:	ff 
    7cc2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7cc7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7ccc:	48 c1 e2 10          	shl    $0x10,%rdx
    7cd0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7cd5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7cda:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    7cdf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    7ce4:	48 89 05 cd 27 06 00 	mov    %rax,0x627cd(%rip)        # 6a4b8 <fwp_cleanups>
    7ceb:	48 8d 05 1e 83 00 00 	lea    0x831e(%rip),%rax        # 10010 <fc23>
    7cf2:	48 2b 05 d7 1e 06 00 	sub    0x61ed7(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7cf9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    7cfe:	48 39 d0             	cmp    %rdx,%rax
    7d01:	73 6d                	jae    7d70 <f12+0xf0>
    7d03:	48 89 c2             	mov    %rax,%rdx
    7d06:	48 c1 ea 10          	shr    $0x10,%rdx
    7d0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d0e:	48 8b 15 03 1f 06 00 	mov    0x61f03(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7d15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d19:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d1d:	48 85 ff             	test   %rdi,%rdi
    7d20:	74 4e                	je     7d70 <f12+0xf0>
    7d22:	0f b6 0a             	movzbl (%rdx),%ecx
    7d25:	80 f9 02             	cmp    $0x2,%cl
    7d28:	0f 84 02 0f 00 00    	je     8c30 <f12+0xfb0>
    7d2e:	80 f9 01             	cmp    $0x1,%cl
    7d31:	75 3d                	jne    7d70 <f12+0xf0>
    7d33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d36:	0f b7 c0             	movzwl %ax,%eax
    7d39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d3c:	48 0f af c1          	imul   %rcx,%rax
    7d40:	48 c1 e8 20          	shr    $0x20,%rax
    7d44:	48 39 d0             	cmp    %rdx,%rax
    7d47:	73 27                	jae    7d70 <f12+0xf0>
    7d49:	48 01 c7             	add    %rax,%rdi
    7d4c:	0f b6 07             	movzbl (%rdi),%eax
    7d4f:	84 c0                	test   %al,%al
    7d51:	74 1d                	je     7d70 <f12+0xf0>
    7d53:	44 8b 05 8e 27 06 00 	mov    0x6278e(%rip),%r8d        # 6a4e8 <iteration_active>
    7d5a:	45 85 c0             	test   %r8d,%r8d
    7d5d:	0f 85 cd 0f 00 00    	jne    8d30 <f12+0x10b0>
    7d63:	3c fd                	cmp    $0xfd,%al
    7d65:	0f 87 82 11 00 00    	ja     8eed <f12+0x126d>
    7d6b:	83 c0 01             	add    $0x1,%eax
    7d6e:	88 07                	mov    %al,(%rdi)
    7d70:	48 8d 3d 99 82 00 00 	lea    0x8299(%rip),%rdi        # 10010 <fc23>
    7d77:	e8 54 f3 ff ff       	call   70d0 <fwp_closure_drop>
    7d7c:	48 85 ed             	test   %rbp,%rbp
    7d7f:	0f 84 cc 10 00 00    	je     8e51 <f12+0x11d1>
    7d85:	48 89 e8             	mov    %rbp,%rax
    7d88:	31 d2                	xor    %edx,%edx
    7d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d90:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d94:	48 83 c2 01          	add    $0x1,%rdx
    7d98:	48 85 c0             	test   %rax,%rax
    7d9b:	75 f3                	jne    7d90 <f12+0x110>
    7d9d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7da4:	0f 87 ca 11 00 00    	ja     8f74 <f12+0x12f4>
    7daa:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7daf:	8b 35 ab 82 00 00    	mov    0x82ab(%rip),%esi        # 10060 <registered_finish.0>
    7db5:	85 f6                	test   %esi,%esi
    7db7:	0f 84 43 0e 00 00    	je     8c00 <f12+0xf80>
    7dbd:	48 8b 1d 14 83 01 00 	mov    0x18314(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    7dc4:	4c 8b 2d 1d 83 01 00 	mov    0x1831d(%rip),%r13        # 200e8 <fwp_ntapes>
    7dcb:	4c 39 eb             	cmp    %r13,%rbx
    7dce:	0f 8d d4 00 00 00    	jge    7ea8 <f12+0x228>
    7dd4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7dd8:	48 03 05 11 83 01 00 	add    0x18311(%rip),%rax        # 200f0 <fwp_tapes>
    7ddf:	90                   	nop
    7de0:	8b 48 04             	mov    0x4(%rax),%ecx
    7de3:	85 c9                	test   %ecx,%ecx
    7de5:	75 0c                	jne    7df3 <f12+0x173>
    7de7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7ded:	0f 86 b5 00 00 00    	jbe    7ea8 <f12+0x228>
    7df3:	48 83 c3 01          	add    $0x1,%rbx
    7df7:	48 83 c0 68          	add    $0x68,%rax
    7dfb:	4c 39 eb             	cmp    %r13,%rbx
    7dfe:	75 e0                	jne    7de0 <f12+0x160>
    7e00:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    7e07:	0f 8f e9 11 00 00    	jg     8ff6 <f12+0x1376>
    7e0d:	4c 39 2d cc 82 01 00 	cmp    %r13,0x182cc(%rip)        # 200e0 <fwp_tapes_cap>
    7e14:	4c 8b 3d d5 82 01 00 	mov    0x182d5(%rip),%r15        # 200f0 <fwp_tapes>
    7e1b:	75 4c                	jne    7e69 <f12+0x1e9>
    7e1d:	4d 85 ed             	test   %r13,%r13
    7e20:	0f 84 91 10 00 00    	je     8eb7 <f12+0x1237>
    7e26:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    7e2b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7e30:	48 39 c3             	cmp    %rax,%rbx
    7e33:	48 0f 4f d8          	cmovg  %rax,%rbx
    7e37:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7e3b:	31 d2                	xor    %edx,%edx
    7e3d:	4c 89 ff             	mov    %r15,%rdi
    7e40:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7e45:	e8 46 d3 ff ff       	call   5190 <ad_raw_realloc>
    7e4a:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7e4f:	48 85 c0             	test   %rax,%rax
    7e52:	49 89 c7             	mov    %rax,%r15
    7e55:	0f 84 3d 11 00 00    	je     8f98 <f12+0x1318>
    7e5b:	48 89 05 8e 82 01 00 	mov    %rax,0x1828e(%rip)        # 200f0 <fwp_tapes>
    7e62:	48 89 1d 77 82 01 00 	mov    %rbx,0x18277(%rip)        # 200e0 <fwp_tapes_cap>
    7e69:	49 6b c5 68          	imul   $0x68,%r13,%rax
    7e6d:	4c 89 eb             	mov    %r13,%rbx
    7e70:	4c 01 f8             	add    %r15,%rax
    7e73:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7e77:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e7e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7e82:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7e89:	00 
    7e8a:	48 29 f8             	sub    %rdi,%rax
    7e8d:	8d 48 68             	lea    0x68(%rax),%ecx
    7e90:	31 c0                	xor    %eax,%eax
    7e92:	c1 e9 03             	shr    $0x3,%ecx
    7e95:	f3 48 ab             	rep stos %rax,(%rdi)
    7e98:	49 8d 45 01          	lea    0x1(%r13),%rax
    7e9c:	48 89 05 45 82 01 00 	mov    %rax,0x18245(%rip)        # 200e8 <fwp_ntapes>
    7ea3:	eb 13                	jmp    7eb8 <f12+0x238>
    7ea5:	0f 1f 00             	nopl   (%rax)
    7ea8:	49 39 dd             	cmp    %rbx,%r13
    7eab:	0f 84 4f ff ff ff    	je     7e00 <f12+0x180>
    7eb1:	4c 8b 3d 38 82 01 00 	mov    0x18238(%rip),%r15        # 200f0 <fwp_tapes>
    7eb8:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    7ebc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7ec0:	48 8d 3d 99 42 00 00 	lea    0x4299(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    7ec7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7ecb:	4d 01 fe             	add    %r15,%r14
    7ece:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    7ed5:	00 
    7ed6:	e8 b5 b4 ff ff       	call   3390 <getenv@plt>
    7edb:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7ee0:	48 85 c0             	test   %rax,%rax
    7ee3:	74 09                	je     7eee <f12+0x26e>
    7ee5:	80 38 30             	cmpb   $0x30,(%rax)
    7ee8:	0f 84 6a 06 00 00    	je     8558 <f12+0x8d8>
    7eee:	48 83 3d 92 81 01 00 	cmpq   $0x0,0x18192(%rip)        # 20088 <fwp_tape_cached_bytes>
    7ef5:	00 
    7ef6:	0f 85 94 0d 00 00    	jne    8c90 <f12+0x1010>
    7efc:	41 8b 06             	mov    (%r14),%eax
    7eff:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    7f03:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    7f0a:	00 
    7f0b:	4c 89 2d c6 81 01 00 	mov    %r13,0x181c6(%rip)        # 200d8 <fwp_tape_next_slot>
    7f12:	8d 70 01             	lea    0x1(%rax),%esi
    7f15:	48 8b 05 9c 25 06 00 	mov    0x6259c(%rip),%rax        # 6a4b8 <fwp_cleanups>
    7f1c:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    7f21:	41 89 36             	mov    %esi,(%r14)
    7f24:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    7f2b:	00 
    7f2c:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    7f33:	ff 
    7f34:	48 85 c0             	test   %rax,%rax
    7f37:	75 13                	jne    7f4c <f12+0x2cc>
    7f39:	e9 c9 10 00 00       	jmp    9007 <f12+0x1387>
    7f3e:	66 90                	xchg   %ax,%ax
    7f40:	48 8b 00             	mov    (%rax),%rax
    7f43:	48 85 c0             	test   %rax,%rax
    7f46:	0f 84 bb 10 00 00    	je     9007 <f12+0x1387>
    7f4c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    7f50:	75 ee                	jne    7f40 <f12+0x2c0>
    7f52:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7f56:	89 d9                	mov    %ebx,%ecx
    7f58:	48 63 02             	movslq (%rdx),%rax
    7f5b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    7f5f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    7f63:	85 c0                	test   %eax,%eax
    7f65:	78 09                	js     7f70 <f12+0x2f0>
    7f67:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7f6b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    7f70:	89 0a                	mov    %ecx,(%rdx)
    7f72:	48 89 e8             	mov    %rbp,%rax
    7f75:	31 c9                	xor    %ecx,%ecx
    7f77:	48 85 ed             	test   %rbp,%rbp
    7f7a:	0f 84 f0 0a 00 00    	je     8a70 <f12+0xdf0>
    7f80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7f84:	48 83 c1 01          	add    $0x1,%rcx
    7f88:	48 85 c0             	test   %rax,%rax
    7f8b:	75 f3                	jne    7f80 <f12+0x300>
    7f8d:	48 89 ea             	mov    %rbp,%rdx
    7f90:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7f94:	48 83 c0 01          	add    $0x1,%rax
    7f98:	48 85 d2             	test   %rdx,%rdx
    7f9b:	75 f3                	jne    7f90 <f12+0x310>
    7f9d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7fa4:	ff ff 1f 
    7fa7:	48 39 c2             	cmp    %rax,%rdx
    7faa:	0f 82 16 10 00 00    	jb     8fc6 <f12+0x1346>
    7fb0:	48 85 c9             	test   %rcx,%rcx
    7fb3:	0f 8e b7 0a 00 00    	jle    8a70 <f12+0xdf0>
    7fb9:	48 39 c1             	cmp    %rax,%rcx
    7fbc:	48 0f 46 c1          	cmovbe %rcx,%rax
    7fc0:	49 89 c4             	mov    %rax,%r12
    7fc3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7fc7:	0f 85 f9 0f 00 00    	jne    8fc6 <f12+0x1346>
    7fcd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    7fd1:	48 c1 e6 10          	shl    $0x10,%rsi
    7fd5:	49 09 f5             	or     %rsi,%r13
    7fd8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    7fdf:	00 
    7fe0:	be 02 00 00 00       	mov    $0x2,%esi
    7fe5:	e8 26 df ff ff       	call   5f10 <fwp_heap_alloc>
    7fea:	4c 89 30             	mov    %r14,(%rax)
    7fed:	48 8b 15 04 1c 06 00 	mov    0x61c04(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7ff4:	48 89 c3             	mov    %rax,%rbx
    7ff7:	48 2b 05 d2 1b 06 00 	sub    0x61bd2(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ffe:	48 c1 e2 10          	shl    $0x10,%rdx
    8002:	48 39 d0             	cmp    %rdx,%rax
    8005:	0f 83 65 0d 00 00    	jae    8d70 <f12+0x10f0>
    800b:	48 89 c2             	mov    %rax,%rdx
    800e:	48 c1 ea 10          	shr    $0x10,%rdx
    8012:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8016:	48 8b 15 fb 1b 06 00 	mov    0x61bfb(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    801d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8021:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8025:	4d 85 f6             	test   %r14,%r14
    8028:	74 38                	je     8062 <f12+0x3e2>
    802a:	0f b6 0a             	movzbl (%rdx),%ecx
    802d:	80 f9 02             	cmp    $0x2,%cl
    8030:	0f 84 a7 0a 00 00    	je     8add <f12+0xe5d>
    8036:	80 f9 01             	cmp    $0x1,%cl
    8039:	75 27                	jne    8062 <f12+0x3e2>
    803b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    803e:	0f b7 c0             	movzwl %ax,%eax
    8041:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8044:	48 0f af c1          	imul   %rcx,%rax
    8048:	48 c1 e8 20          	shr    $0x20,%rax
    804c:	48 39 d0             	cmp    %rdx,%rax
    804f:	73 11                	jae    8062 <f12+0x3e2>
    8051:	49 01 c6             	add    %rax,%r14
    8054:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8058:	0f 84 68 0e 00 00    	je     8ec6 <f12+0x1246>
    805e:	41 c6 06 01          	movb   $0x1,(%r14)
    8062:	4d 85 e4             	test   %r12,%r12
    8065:	74 4c                	je     80b3 <f12+0x433>
    8067:	4c 89 e9             	mov    %r13,%rcx
    806a:	48 89 ea             	mov    %rbp,%rdx
    806d:	31 c0                	xor    %eax,%eax
    806f:	48 c1 e1 20          	shl    $0x20,%rcx
    8073:	66 90                	xchg   %ax,%ax
    8075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    807c:	00 00 00 00 
    8080:	48 89 c6             	mov    %rax,%rsi
    8083:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8088:	48 01 ce             	add    %rcx,%rsi
    808b:	0f 80 ca 0e 00 00    	jo     8f5b <f12+0x12db>
    8091:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8096:	48 89 c6             	mov    %rax,%rsi
    8099:	48 83 c0 01          	add    $0x1,%rax
    809d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    80a1:	48 c1 e6 04          	shl    $0x4,%rsi
    80a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    80aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80ae:	4c 39 e0             	cmp    %r12,%rax
    80b1:	72 cd                	jb     8080 <f12+0x400>
    80b3:	48 8b 03             	mov    (%rbx),%rax
    80b6:	48 d1 e8             	shr    $1,%rax
    80b9:	0f 85 49 0a 00 00    	jne    8b08 <f12+0xe88>
    80bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    80c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    80cd:	0f 1f 00             	nopl   (%rax)
    80d0:	48 89 df             	mov    %rbx,%rdi
    80d3:	4d 63 e5             	movslq %r13d,%r12
    80d6:	e8 25 f9 ff ff       	call   7a00 <fwp_drop4>
    80db:	4c 89 e7             	mov    %r12,%rdi
    80de:	e8 4d c6 ff ff       	call   4730 <fwp_tape_of>
    80e3:	48 89 c6             	mov    %rax,%rsi
    80e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    80eb:	0f 85 f9 0e 00 00    	jne    8fea <f12+0x136a>
    80f1:	48 89 c7             	mov    %rax,%rdi
    80f4:	e8 97 bb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    80f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    80fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8102:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8109:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    810d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8111:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8116:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    811b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8120:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8124:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8128:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    812e:	77 19                	ja     8149 <f12+0x4c9>
    8130:	41 0f b7 c5          	movzwl %r13w,%eax
    8134:	83 e8 01             	sub    $0x1,%eax
    8137:	48 98                	cltq
    8139:	48 3b 05 98 7f 01 00 	cmp    0x17f98(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    8140:	7d 07                	jge    8149 <f12+0x4c9>
    8142:	48 89 05 8f 7f 01 00 	mov    %rax,0x17f8f(%rip)        # 200d8 <fwp_tape_next_slot>
    8149:	48 8b 05 68 23 06 00 	mov    0x62368(%rip),%rax        # 6a4b8 <fwp_cleanups>
    8150:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8154:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    815b:	00 
    815c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8160:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8167:	00 
    8168:	48 8d 05 f1 d0 ff ff 	lea    -0x2f0f(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    816f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8176:	00 
    8177:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    817e:	00 
    817f:	48 89 04 24          	mov    %rax,(%rsp)
    8183:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    818a:	00 
    818b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8192:	00 
    8193:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8197:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    819b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    81a2:	00 
    81a3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    81aa:	00 
    81ab:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    81b2:	00 
    81b3:	48 89 05 fe 22 06 00 	mov    %rax,0x622fe(%rip)        # 6a4b8 <fwp_cleanups>
    81ba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    81c1:	00 
    81c2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    81c9:	00 
    81ca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    81d1:	00 
    81d2:	4d 85 ff             	test   %r15,%r15
    81d5:	0f 88 65 0a 00 00    	js     8c40 <f12+0xfc0>
    81db:	4c 89 f8             	mov    %r15,%rax
    81de:	48 c1 f8 20          	sar    $0x20,%rax
    81e2:	49 39 c4             	cmp    %rax,%r12
    81e5:	0f 85 64 0d 00 00    	jne    8f4f <f12+0x12cf>
    81eb:	44 89 f9             	mov    %r15d,%ecx
    81ee:	49 89 cd             	mov    %rcx,%r13
    81f1:	48 39 ca             	cmp    %rcx,%rdx
    81f4:	0f 8e 49 0d 00 00    	jle    8f43 <f12+0x12c3>
    81fa:	48 39 cb             	cmp    %rcx,%rbx
    81fd:	0f 8e ad 09 00 00    	jle    8bb0 <f12+0xf30>
    8203:	4c 39 f3             	cmp    %r14,%rbx
    8206:	0f 8e f4 0a 00 00    	jle    8d00 <f12+0x1080>
    820c:	49 89 dc             	mov    %rbx,%r12
    820f:	4d 85 f6             	test   %r14,%r14
    8212:	4d 0f 44 f4          	cmove  %r12,%r14
    8216:	eb 1d                	jmp    8235 <f12+0x5b5>
    8218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    821f:	00 
    8220:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8224:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    822b:	4c 89 e0             	mov    %r12,%rax
    822e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8232:	49 89 c6             	mov    %rax,%r14
    8235:	4d 39 f4             	cmp    %r14,%r12
    8238:	7f e6                	jg     8220 <f12+0x5a0>
    823a:	4d 85 c0             	test   %r8,%r8
    823d:	0f 84 3d 0b 00 00    	je     8d80 <f12+0x1100>
    8243:	4c 89 c7             	mov    %r8,%rdi
    8246:	ba 03 00 00 00       	mov    $0x3,%edx
    824b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8250:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8257:	00 
    8258:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    825d:	e8 2e cf ff ff       	call   5190 <ad_raw_realloc>
    8262:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8268:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    826e:	48 85 c0             	test   %rax,%rax
    8271:	49 89 c0             	mov    %rax,%r8
    8274:	0f 84 c6 0b 00 00    	je     8e40 <f12+0x11c0>
    827a:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8281:	00 
    8282:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8289:	00 
    828a:	4d 85 e4             	test   %r12,%r12
    828d:	0f 85 67 0c 00 00    	jne    8efa <f12+0x127a>
    8293:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    829a:	4d 85 ff             	test   %r15,%r15
    829d:	78 17                	js     82b6 <f12+0x636>
    829f:	44 89 f9             	mov    %r15d,%ecx
    82a2:	f2 0f 10 05 36 4b 00 	movsd  0x4b36(%rip),%xmm0        # cde0 <msg.4+0xb0>
    82a9:	00 
    82aa:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    82b0:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    82b6:	4c 39 eb             	cmp    %r13,%rbx
    82b9:	0f 8f 92 00 00 00    	jg     8351 <f12+0x6d1>
    82bf:	0f 12 fb             	movhlps %xmm3,%xmm7
    82c2:	66 49 0f 7e d2       	movq   %xmm2,%r10
    82c7:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    82cc:	49 29 dd             	sub    %rbx,%r13
    82cf:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    82d4:	0f 12 fa             	movhlps %xmm2,%xmm7
    82d7:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    82db:	66 49 0f 7e fb       	movq   %xmm7,%r11
    82e0:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    82e4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    82e8:	48 29 f1             	sub    %rsi,%rcx
    82eb:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    82ef:	4c 29 df             	sub    %r11,%rdi
    82f2:	4d 29 da             	sub    %r11,%r10
    82f5:	eb 0d                	jmp    8304 <f12+0x684>
    82f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82fe:	00 00 
    8300:	48 83 e8 04          	sub    $0x4,%rax
    8304:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    8309:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    830d:	7a 02                	jp     8311 <f12+0x691>
    830f:	74 37                	je     8348 <f12+0x6c8>
    8311:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8315:	45 85 db             	test   %r11d,%r11d
    8318:	78 16                	js     8330 <f12+0x6b0>
    831a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8320:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8324:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    832a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    8330:	4c 63 18             	movslq (%rax),%r11
    8333:	45 85 db             	test   %r11d,%r11d
    8336:	78 10                	js     8348 <f12+0x6c8>
    8338:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    833c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    8342:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    8348:	48 83 ea 08          	sub    $0x8,%rdx
    834c:	48 39 c6             	cmp    %rax,%rsi
    834f:	75 af                	jne    8300 <f12+0x680>
    8351:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8358:	ff ff 1f 
    835b:	48 39 d8             	cmp    %rbx,%rax
    835e:	0f 82 6e 0c 00 00    	jb     8fd2 <f12+0x1352>
    8364:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    836b:	00 
    836c:	be 02 00 00 00       	mov    $0x2,%esi
    8371:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8376:	e8 95 db ff ff       	call   5f10 <fwp_heap_alloc>
    837b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8380:	48 89 18             	mov    %rbx,(%rax)
    8383:	49 89 c4             	mov    %rax,%r12
    8386:	31 c0                	xor    %eax,%eax
    8388:	48 85 db             	test   %rbx,%rbx
    838b:	74 25                	je     83b2 <f12+0x732>
    838d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8394:	00 
    8395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    839c:	00 00 00 00 
    83a0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    83a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    83a9:	48 83 c0 01          	add    $0x1,%rax
    83ad:	48 39 c3             	cmp    %rax,%rbx
    83b0:	75 ee                	jne    83a0 <f12+0x720>
    83b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    83b9:	00 
    83ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    83be:	4c 89 2d f3 20 06 00 	mov    %r13,0x620f3(%rip)        # 6a4b8 <fwp_cleanups>
    83c5:	e8 96 ce ff ff       	call   5260 <fwp_tape_buffers_release>
    83ca:	48 8b 15 27 18 06 00 	mov    0x61827(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    83d1:	4c 89 e0             	mov    %r12,%rax
    83d4:	48 2b 05 f5 17 06 00 	sub    0x617f5(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    83db:	48 c1 e2 10          	shl    $0x10,%rdx
    83df:	48 39 d0             	cmp    %rdx,%rax
    83e2:	73 55                	jae    8439 <f12+0x7b9>
    83e4:	48 89 c2             	mov    %rax,%rdx
    83e7:	48 c1 ea 10          	shr    $0x10,%rdx
    83eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ef:	48 8b 15 22 18 06 00 	mov    0x61822(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    83f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    83fe:	48 85 db             	test   %rbx,%rbx
    8401:	74 36                	je     8439 <f12+0x7b9>
    8403:	0f b6 0a             	movzbl (%rdx),%ecx
    8406:	80 f9 02             	cmp    $0x2,%cl
    8409:	0f 84 61 08 00 00    	je     8c70 <f12+0xff0>
    840f:	80 f9 01             	cmp    $0x1,%cl
    8412:	75 25                	jne    8439 <f12+0x7b9>
    8414:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8417:	0f b7 c0             	movzwl %ax,%eax
    841a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    841d:	48 0f af c1          	imul   %rcx,%rax
    8421:	48 c1 e8 20          	shr    $0x20,%rax
    8425:	48 39 d0             	cmp    %rdx,%rax
    8428:	73 0f                	jae    8439 <f12+0x7b9>
    842a:	48 01 c3             	add    %rax,%rbx
    842d:	80 3b ff             	cmpb   $0xff,(%rbx)
    8430:	0f 84 9d 0a 00 00    	je     8ed3 <f12+0x1253>
    8436:	c6 03 01             	movb   $0x1,(%rbx)
    8439:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    843e:	0f 85 07 b3 ff ff    	jne    374b <f12.cold>
    8444:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8449:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    844e:	48 89 05 63 20 06 00 	mov    %rax,0x62063(%rip)        # 6a4b8 <fwp_cleanups>
    8455:	e8 e6 ef ff ff       	call   7440 <fwp_tape_scope_release>
    845a:	49 8b 04 24          	mov    (%r12),%rax
    845e:	49 89 c6             	mov    %rax,%r14
    8461:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8466:	48 85 c0             	test   %rax,%rax
    8469:	0f 88 51 05 00 00    	js     89c0 <f12+0xd40>
    846f:	48 8b 15 82 17 06 00 	mov    0x61782(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8476:	4c 89 e0             	mov    %r12,%rax
    8479:	48 2b 05 50 17 06 00 	sub    0x61750(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8480:	48 c1 e2 10          	shl    $0x10,%rdx
    8484:	48 39 d0             	cmp    %rdx,%rax
    8487:	0f 83 33 05 00 00    	jae    89c0 <f12+0xd40>
    848d:	48 89 c2             	mov    %rax,%rdx
    8490:	48 c1 ea 10          	shr    $0x10,%rdx
    8494:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8498:	48 8b 15 79 17 06 00 	mov    0x61779(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    849f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84a3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    84a7:	48 85 c9             	test   %rcx,%rcx
    84aa:	0f 84 10 05 00 00    	je     89c0 <f12+0xd40>
    84b0:	0f b6 32             	movzbl (%rdx),%esi
    84b3:	40 80 fe 02          	cmp    $0x2,%sil
    84b7:	0f 84 f3 04 00 00    	je     89b0 <f12+0xd30>
    84bd:	40 80 fe 01          	cmp    $0x1,%sil
    84c1:	0f 85 f9 04 00 00    	jne    89c0 <f12+0xd40>
    84c7:	8b 72 18             	mov    0x18(%rdx),%esi
    84ca:	0f b7 c0             	movzwl %ax,%eax
    84cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84d0:	48 0f af c6          	imul   %rsi,%rax
    84d4:	48 c1 e8 20          	shr    $0x20,%rax
    84d8:	48 39 d0             	cmp    %rdx,%rax
    84db:	0f 83 df 04 00 00    	jae    89c0 <f12+0xd40>
    84e1:	48 01 c1             	add    %rax,%rcx
    84e4:	80 39 01             	cmpb   $0x1,(%rcx)
    84e7:	0f 85 d3 04 00 00    	jne    89c0 <f12+0xd40>
    84ed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    84f2:	4d 89 e5             	mov    %r12,%r13
    84f5:	31 ff                	xor    %edi,%edi
    84f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    84fc:	f2 0f 10 0d ec 48 00 	movsd  0x48ec(%rip),%xmm1        # cdf0 <msg.4+0xc0>
    8503:	00 
    8504:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8508:	31 c0                	xor    %eax,%eax
    850a:	4d 85 f6             	test   %r14,%r14
    850d:	75 2f                	jne    853e <f12+0x8be>
    850f:	eb 5f                	jmp    8570 <f12+0x8f0>
    8511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8518:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    851d:	0f 88 3d 0a 00 00    	js     8f60 <f12+0x12e0>
    8523:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8528:	48 83 c0 01          	add    $0x1,%rax
    852c:	48 83 c2 08          	add    $0x8,%rdx
    8530:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8534:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8539:	49 39 c6             	cmp    %rax,%r14
    853c:	74 32                	je     8570 <f12+0x8f0>
    853e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8543:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8548:	79 ce                	jns    8518 <f12+0x898>
    854a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    854f:	eb c7                	jmp    8518 <f12+0x898>
    8551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8558:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    855c:	0f 84 9a f9 ff ff    	je     7efc <f12+0x27c>
    8562:	e9 87 f9 ff ff       	jmp    7eee <f12+0x26e>
    8567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    856e:	00 00 
    8570:	e8 8b f4 ff ff       	call   7a00 <fwp_drop4>
    8575:	48 89 e8             	mov    %rbp,%rax
    8578:	31 d2                	xor    %edx,%edx
    857a:	48 85 ed             	test   %rbp,%rbp
    857d:	0f 84 d7 08 00 00    	je     8e5a <f12+0x11da>
    8583:	66 90                	xchg   %ax,%ax
    8585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    858c:	00 00 00 00 
    8590:	48 8b 40 10          	mov    0x10(%rax),%rax
    8594:	48 83 c2 01          	add    $0x1,%rdx
    8598:	48 85 c0             	test   %rax,%rax
    859b:	75 f3                	jne    8590 <f12+0x910>
    859d:	49 8b 45 00          	mov    0x0(%r13),%rax
    85a1:	49 89 c7             	mov    %rax,%r15
    85a4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    85a9:	48 85 c0             	test   %rax,%rax
    85ac:	0f 88 60 03 00 00    	js     8912 <f12+0xc92>
    85b2:	48 8b 05 3f 16 06 00 	mov    0x6163f(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    85b9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    85be:	48 2b 0d 0b 16 06 00 	sub    0x6160b(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    85c5:	48 c1 e0 10          	shl    $0x10,%rax
    85c9:	48 39 c1             	cmp    %rax,%rcx
    85cc:	0f 83 40 03 00 00    	jae    8912 <f12+0xc92>
    85d2:	48 89 c8             	mov    %rcx,%rax
    85d5:	48 c1 e8 10          	shr    $0x10,%rax
    85d9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    85dd:	48 8b 05 34 16 06 00 	mov    0x61634(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    85e4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    85e8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    85ec:	48 85 ff             	test   %rdi,%rdi
    85ef:	0f 84 1d 03 00 00    	je     8912 <f12+0xc92>
    85f5:	0f b6 06             	movzbl (%rsi),%eax
    85f8:	3c 02                	cmp    $0x2,%al
    85fa:	0f 84 00 03 00 00    	je     8900 <f12+0xc80>
    8600:	3c 01                	cmp    $0x1,%al
    8602:	0f 85 01 03 00 00    	jne    8909 <f12+0xc89>
    8608:	8b 46 18             	mov    0x18(%rsi),%eax
    860b:	0f b7 c9             	movzwl %cx,%ecx
    860e:	48 0f af c8          	imul   %rax,%rcx
    8612:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8615:	48 c1 e9 20          	shr    $0x20,%rcx
    8619:	48 39 c1             	cmp    %rax,%rcx
    861c:	0f 83 e7 02 00 00    	jae    8909 <f12+0xc89>
    8622:	48 01 cf             	add    %rcx,%rdi
    8625:	80 3f 01             	cmpb   $0x1,(%rdi)
    8628:	0f 85 db 02 00 00    	jne    8909 <f12+0xc89>
    862e:	49 39 d7             	cmp    %rdx,%r15
    8631:	48 89 d0             	mov    %rdx,%rax
    8634:	49 0f 46 c7          	cmovbe %r15,%rax
    8638:	48 85 c0             	test   %rax,%rax
    863b:	0f 84 2b 09 00 00    	je     8f6c <f12+0x12ec>
    8641:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8648:	00 
    8649:	4d 8d 75 08          	lea    0x8(%r13),%r14
    864d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8652:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8659:	00 
    865a:	48 89 e9             	mov    %rbp,%rcx
    865d:	31 d2                	xor    %edx,%edx
    865f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8663:	eb 38                	jmp    869d <f12+0xa1d>
    8665:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    866a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8671:	00 00 00 00 
    8675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    867c:	00 00 00 00 
    8680:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8685:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    868a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8690:	48 83 c2 08          	add    $0x8,%rdx
    8694:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8698:	49 39 d0             	cmp    %rdx,%r8
    869b:	74 1b                	je     86b8 <f12+0xa38>
    869d:	48 89 fe             	mov    %rdi,%rsi
    86a0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    86a5:	79 d9                	jns    8680 <f12+0xa00>
    86a7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    86ac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    86b0:	eb ce                	jmp    8680 <f12+0xa00>
    86b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86b8:	48 85 ed             	test   %rbp,%rbp
    86bb:	0f 84 7a 08 00 00    	je     8f3b <f12+0x12bb>
    86c1:	4c 8b 05 30 15 06 00 	mov    0x61530(%rip),%r8        # 69bf8 <fwp_heap+0x13d8>
    86c8:	4c 8b 0d 01 15 06 00 	mov    0x61501(%rip),%r9        # 69bd0 <fwp_heap+0x13b0>
    86cf:	48 89 e9             	mov    %rbp,%rcx
    86d2:	45 31 ed             	xor    %r13d,%r13d
    86d5:	4c 8b 15 3c 15 06 00 	mov    0x6153c(%rip),%r10        # 69c18 <fwp_heap+0x13f8>
    86dc:	49 c1 e0 10          	shl    $0x10,%r8
    86e0:	eb 1c                	jmp    86fe <f12+0xa7e>
    86e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86e8:	49 83 c5 01          	add    $0x1,%r13
    86ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    86f0:	49 39 c5             	cmp    %rax,%r13
    86f3:	0f 83 67 01 00 00    	jae    8860 <f12+0xbe0>
    86f9:	48 85 c9             	test   %rcx,%rcx
    86fc:	74 56                	je     8754 <f12+0xad4>
    86fe:	48 89 ca             	mov    %rcx,%rdx
    8701:	4c 29 ca             	sub    %r9,%rdx
    8704:	4c 39 c2             	cmp    %r8,%rdx
    8707:	73 4b                	jae    8754 <f12+0xad4>
    8709:	48 89 d6             	mov    %rdx,%rsi
    870c:	48 c1 ee 10          	shr    $0x10,%rsi
    8710:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8714:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8718:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    871c:	48 85 ff             	test   %rdi,%rdi
    871f:	74 33                	je     8754 <f12+0xad4>
    8721:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8725:	41 80 fb 02          	cmp    $0x2,%r11b
    8729:	0f 84 19 01 00 00    	je     8848 <f12+0xbc8>
    872f:	41 80 fb 01          	cmp    $0x1,%r11b
    8733:	75 1f                	jne    8754 <f12+0xad4>
    8735:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8739:	0f b7 d2             	movzwl %dx,%edx
    873c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    873f:	49 0f af d3          	imul   %r11,%rdx
    8743:	48 c1 ea 20          	shr    $0x20,%rdx
    8747:	48 39 f2             	cmp    %rsi,%rdx
    874a:	73 08                	jae    8754 <f12+0xad4>
    874c:	48 01 d7             	add    %rdx,%rdi
    874f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8752:	74 94                	je     86e8 <f12+0xa68>
    8754:	49 39 c5             	cmp    %rax,%r13
    8757:	0f 83 03 01 00 00    	jae    8860 <f12+0xbe0>
    875d:	49 89 c7             	mov    %rax,%r15
    8760:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    8767:	00 
    8768:	45 31 e4             	xor    %r12d,%r12d
    876b:	48 89 04 24          	mov    %rax,(%rsp)
    876f:	48 8d 1d aa 00 06 00 	lea    0x600aa(%rip),%rbx        # 68820 <fwp_heap>
    8776:	eb 3a                	jmp    87b2 <f12+0xb32>
    8778:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    877f:	00 
    8780:	41 80 f9 01          	cmp    $0x1,%r9b
    8784:	75 27                	jne    87ad <f12+0xb2d>
    8786:	45 8b 48 18          	mov    0x18(%r8),%r9d
    878a:	0f b7 c0             	movzwl %ax,%eax
    878d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8791:	49 0f af c1          	imul   %r9,%rax
    8795:	48 c1 e8 20          	shr    $0x20,%rax
    8799:	4c 39 c0             	cmp    %r8,%rax
    879c:	73 0f                	jae    87ad <f12+0xb2d>
    879e:	48 01 c7             	add    %rax,%rdi
    87a1:	80 3f ff             	cmpb   $0xff,(%rdi)
    87a4:	0f 84 46 03 00 00    	je     8af0 <f12+0xe70>
    87aa:	c6 07 01             	movb   $0x1,(%rdi)
    87ad:	4d 39 fd             	cmp    %r15,%r13
    87b0:	73 7e                	jae    8830 <f12+0xbb0>
    87b2:	49 83 ef 01          	sub    $0x1,%r15
    87b6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    87bb:	48 8b 34 24          	mov    (%rsp),%rsi
    87bf:	bf 01 00 00 00       	mov    $0x1,%edi
    87c4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    87ca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    87ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    87d5:	00 
    87d6:	e8 65 e0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    87db:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    87e2:	49 89 c4             	mov    %rax,%r12
    87e5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    87ec:	48 c1 e7 10          	shl    $0x10,%rdi
    87f0:	48 39 f8             	cmp    %rdi,%rax
    87f3:	73 b8                	jae    87ad <f12+0xb2d>
    87f5:	48 89 c7             	mov    %rax,%rdi
    87f8:	48 c1 ef 10          	shr    $0x10,%rdi
    87fc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8800:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8807:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    880b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    880f:	48 85 ff             	test   %rdi,%rdi
    8812:	74 99                	je     87ad <f12+0xb2d>
    8814:	45 0f b6 08          	movzbl (%r8),%r9d
    8818:	41 80 f9 02          	cmp    $0x2,%r9b
    881c:	0f 85 5e ff ff ff    	jne    8780 <f12+0xb00>
    8822:	66 85 c0             	test   %ax,%ax
    8825:	0f 84 76 ff ff ff    	je     87a1 <f12+0xb21>
    882b:	4d 39 fd             	cmp    %r15,%r13
    882e:	72 82                	jb     87b2 <f12+0xb32>
    8830:	4d 85 ed             	test   %r13,%r13
    8833:	75 2e                	jne    8863 <f12+0xbe3>
    8835:	8b 44 24 40          	mov    0x40(%rsp),%eax
    8839:	85 c0                	test   %eax,%eax
    883b:	4d 0f 45 f5          	cmovne %r13,%r14
    883f:	eb 6f                	jmp    88b0 <f12+0xc30>
    8841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8848:	66 85 d2             	test   %dx,%dx
    884b:	0f 84 fe fe ff ff    	je     874f <f12+0xacf>
    8851:	49 39 c5             	cmp    %rax,%r13
    8854:	0f 82 03 ff ff ff    	jb     875d <f12+0xadd>
    885a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8860:	45 31 e4             	xor    %r12d,%r12d
    8863:	4c 89 f2             	mov    %r14,%rdx
    8866:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    886a:	48 89 e8             	mov    %rbp,%rax
    886d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8874:	00 
    8875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    887c:	00 00 00 00 
    8880:	48 8b 0a             	mov    (%rdx),%rcx
    8883:	48 83 c2 08          	add    $0x8,%rdx
    8887:	48 89 c7             	mov    %rax,%rdi
    888a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    888e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8892:	49 39 d0             	cmp    %rdx,%r8
    8895:	75 e9                	jne    8880 <f12+0xc00>
    8897:	8b 54 24 40          	mov    0x40(%rsp),%edx
    889b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    889f:	85 d2                	test   %edx,%edx
    88a1:	0f 84 d9 03 00 00    	je     8c80 <f12+0x1000>
    88a7:	49 89 ec             	mov    %rbp,%r12
    88aa:	45 31 f6             	xor    %r14d,%r14d
    88ad:	48 89 c5             	mov    %rax,%rbp
    88b0:	4c 89 f7             	mov    %r14,%rdi
    88b3:	e8 58 d1 ff ff       	call   5a10 <fwp_mem_free>
    88b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    88bd:	e8 3e f1 ff ff       	call   7a00 <fwp_drop4>
    88c2:	48 89 ef             	mov    %rbp,%rdi
    88c5:	e8 16 e5 ff ff       	call   6de0 <fwp_drop0>
    88ca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    88d1:	00 
    88d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88d9:	00 00 
    88db:	0f 85 21 07 00 00    	jne    9002 <f12+0x1382>
    88e1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    88e8:	4c 89 e0             	mov    %r12,%rax
    88eb:	5b                   	pop    %rbx
    88ec:	5d                   	pop    %rbp
    88ed:	41 5c                	pop    %r12
    88ef:	41 5d                	pop    %r13
    88f1:	41 5e                	pop    %r14
    88f3:	41 5f                	pop    %r15
    88f5:	c3                   	ret
    88f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88fd:	00 00 00 
    8900:	66 85 c9             	test   %cx,%cx
    8903:	0f 84 1c fd ff ff    	je     8625 <f12+0x9a5>
    8909:	48 85 ed             	test   %rbp,%rbp
    890c:	0f 84 2b 04 00 00    	je     8d3d <f12+0x10bd>
    8912:	48 89 e8             	mov    %rbp,%rax
    8915:	45 31 e4             	xor    %r12d,%r12d
    8918:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    891f:	00 
    8920:	48 8b 40 10          	mov    0x10(%rax),%rax
    8924:	4c 89 e2             	mov    %r12,%rdx
    8927:	49 83 c4 01          	add    $0x1,%r12
    892b:	48 85 c0             	test   %rax,%rax
    892e:	75 f0                	jne    8920 <f12+0xca0>
    8930:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8937:	ff ff 1f 
    893a:	4c 39 e0             	cmp    %r12,%rax
    893d:	0f 82 83 06 00 00    	jb     8fc6 <f12+0x1346>
    8943:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    894a:	00 
    894b:	be 02 00 00 00       	mov    $0x2,%esi
    8950:	e8 bb d5 ff ff       	call   5f10 <fwp_heap_alloc>
    8955:	4d 39 e7             	cmp    %r12,%r15
    8958:	48 89 ea             	mov    %rbp,%rdx
    895b:	49 89 c6             	mov    %rax,%r14
    895e:	4c 89 e0             	mov    %r12,%rax
    8961:	49 0f 46 c7          	cmovbe %r15,%rax
    8965:	4c 89 f1             	mov    %r14,%rcx
    8968:	66 90                	xchg   %ax,%ax
    896a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8971:	00 00 00 00 
    8975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    897c:	00 00 00 00 
    8980:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8984:	48 83 c1 08          	add    $0x8,%rcx
    8988:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    898c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8990:	48 85 d2             	test   %rdx,%rdx
    8993:	75 eb                	jne    8980 <f12+0xd00>
    8995:	48 85 c0             	test   %rax,%rax
    8998:	0f 84 b1 03 00 00    	je     8d4f <f12+0x10cf>
    899e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    89a5:	00 
    89a6:	e9 a2 fc ff ff       	jmp    864d <f12+0x9cd>
    89ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    89b0:	66 85 c0             	test   %ax,%ax
    89b3:	0f 84 2b fb ff ff    	je     84e4 <f12+0x864>
    89b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    89c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    89c7:	ff ff 1f 
    89ca:	4c 39 f0             	cmp    %r14,%rax
    89cd:	0f 82 ff 05 00 00    	jb     8fd2 <f12+0x1352>
    89d3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    89da:	00 
    89db:	be 01 00 00 00       	mov    $0x1,%esi
    89e0:	e8 2b d5 ff ff       	call   5f10 <fwp_heap_alloc>
    89e5:	4c 89 30             	mov    %r14,(%rax)
    89e8:	48 8b 15 09 12 06 00 	mov    0x61209(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    89ef:	49 89 c5             	mov    %rax,%r13
    89f2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    89f7:	48 2b 05 d2 11 06 00 	sub    0x611d2(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    89fe:	48 c1 e2 10          	shl    $0x10,%rdx
    8a02:	48 39 d0             	cmp    %rdx,%rax
    8a05:	73 57                	jae    8a5e <f12+0xdde>
    8a07:	48 89 c2             	mov    %rax,%rdx
    8a0a:	48 c1 ea 10          	shr    $0x10,%rdx
    8a0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a12:	48 8b 15 ff 11 06 00 	mov    0x611ff(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8a19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a1d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8a21:	4d 85 ff             	test   %r15,%r15
    8a24:	74 38                	je     8a5e <f12+0xdde>
    8a26:	0f b6 0a             	movzbl (%rdx),%ecx
    8a29:	80 f9 02             	cmp    $0x2,%cl
    8a2c:	0f 84 2e 03 00 00    	je     8d60 <f12+0x10e0>
    8a32:	80 f9 01             	cmp    $0x1,%cl
    8a35:	75 27                	jne    8a5e <f12+0xdde>
    8a37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a3a:	0f b7 c0             	movzwl %ax,%eax
    8a3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a40:	48 0f af c1          	imul   %rcx,%rax
    8a44:	48 c1 e8 20          	shr    $0x20,%rax
    8a48:	48 39 d0             	cmp    %rdx,%rax
    8a4b:	73 11                	jae    8a5e <f12+0xdde>
    8a4d:	49 01 c7             	add    %rax,%r15
    8a50:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8a54:	0f 84 86 04 00 00    	je     8ee0 <f12+0x1260>
    8a5a:	41 c6 07 01          	movb   $0x1,(%r15)
    8a5e:	4c 89 e7             	mov    %r12,%rdi
    8a61:	e9 91 fa ff ff       	jmp    84f7 <f12+0x877>
    8a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a6d:	00 00 00 
    8a70:	48 c1 e6 10          	shl    $0x10,%rsi
    8a74:	bf 08 00 00 00       	mov    $0x8,%edi
    8a79:	49 09 f5             	or     %rsi,%r13
    8a7c:	be 02 00 00 00       	mov    $0x2,%esi
    8a81:	e8 8a d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a86:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8a8d:	48 8b 15 64 11 06 00 	mov    0x61164(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8a94:	48 89 c3             	mov    %rax,%rbx
    8a97:	48 2b 05 32 11 06 00 	sub    0x61132(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8a9e:	48 c1 e2 10          	shl    $0x10,%rdx
    8aa2:	48 39 d0             	cmp    %rdx,%rax
    8aa5:	0f 83 14 f6 ff ff    	jae    80bf <f12+0x43f>
    8aab:	48 89 c2             	mov    %rax,%rdx
    8aae:	48 c1 ea 10          	shr    $0x10,%rdx
    8ab2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ab6:	48 8b 15 5b 11 06 00 	mov    0x6115b(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8abd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ac1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8ac5:	4d 85 f6             	test   %r14,%r14
    8ac8:	0f 84 e5 f5 ff ff    	je     80b3 <f12+0x433>
    8ace:	0f b6 0a             	movzbl (%rdx),%ecx
    8ad1:	45 31 e4             	xor    %r12d,%r12d
    8ad4:	80 f9 02             	cmp    $0x2,%cl
    8ad7:	0f 85 59 f5 ff ff    	jne    8036 <f12+0x3b6>
    8add:	66 85 c0             	test   %ax,%ax
    8ae0:	0f 85 7c f5 ff ff    	jne    8062 <f12+0x3e2>
    8ae6:	e9 69 f5 ff ff       	jmp    8054 <f12+0x3d4>
    8aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8af0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    8af5:	e8 d6 cc ff ff       	call   57d0 <fwp_rc_forget_slot>
    8afa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8aff:	e9 a6 fc ff ff       	jmp    87aa <f12+0xb2a>
    8b04:	0f 1f 40 00          	nopl   0x0(%rax)
    8b08:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8b0c:	4c 89 e1             	mov    %r12,%rcx
    8b0f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8b13:	0f 85 ad 04 00 00    	jne    8fc6 <f12+0x1346>
    8b19:	4d 85 e4             	test   %r12,%r12
    8b1c:	0f 84 9d f5 ff ff    	je     80bf <f12+0x43f>
    8b22:	48 c1 e0 04          	shl    $0x4,%rax
    8b26:	4d 01 e4             	add    %r12,%r12
    8b29:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    8b2d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    8b32:	0f 1f 00             	nopl   (%rax)
    8b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b3c:	00 00 00 00 
    8b40:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    8b45:	49 8b 77 18          	mov    0x18(%r15),%rsi
    8b49:	49 83 c7 10          	add    $0x10,%r15
    8b4d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8b51:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8b56:	e8 75 db ff ff       	call   66d0 <w107>
    8b5b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8b60:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8b64:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8b69:	4d 39 fe             	cmp    %r15,%r14
    8b6c:	75 d2                	jne    8b40 <f12+0xec0>
    8b6e:	4c 89 23             	mov    %r12,(%rbx)
    8b71:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8b78:	45 31 f6             	xor    %r14d,%r14d
    8b7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b80:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    8b85:	4c 89 ff             	mov    %r15,%rdi
    8b88:	49 83 c6 02          	add    $0x2,%r14
    8b8c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8b93:	00 f0 3f 
    8b96:	48 89 ce             	mov    %rcx,%rsi
    8b99:	e8 b2 d7 ff ff       	call   6350 <fwp_p_ad_push>
    8b9e:	49 89 c7             	mov    %rax,%r15
    8ba1:	4d 39 e6             	cmp    %r12,%r14
    8ba4:	72 da                	jb     8b80 <f12+0xf00>
    8ba6:	e9 25 f5 ff ff       	jmp    80d0 <f12+0x450>
    8bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bb0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    8bb4:	4d 39 e6             	cmp    %r12,%r14
    8bb7:	0f 8c 52 f6 ff ff    	jl     820f <f12+0x58f>
    8bbd:	4d 85 c0             	test   %r8,%r8
    8bc0:	0f 84 ba 03 00 00    	je     8f80 <f12+0x1300>
    8bc6:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    8bcb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    8bd2:	00 
    8bd3:	31 f6                	xor    %esi,%esi
    8bd5:	4c 89 c7             	mov    %r8,%rdi
    8bd8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8bdd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8be2:	e8 c9 a8 ff ff       	call   34b0 <memset@plt>
    8be7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8bed:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8bf3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    8bf8:	49 89 c0             	mov    %rax,%r8
    8bfb:	e9 a2 f6 ff ff       	jmp    82a2 <f12+0x622>
    8c00:	48 8d 3d 19 e7 ff ff 	lea    -0x18e7(%rip),%rdi        # 7320 <fwp_tape_finish>
    8c07:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8c0c:	e8 bf 31 00 00       	call   bdd0 <atexit>
    8c11:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8c16:	85 c0                	test   %eax,%eax
    8c18:	0f 85 7a 03 00 00    	jne    8f98 <f12+0x1318>
    8c1e:	c7 05 38 74 00 00 01 	movl   $0x1,0x7438(%rip)        # 10060 <registered_finish.0>
    8c25:	00 00 00 
    8c28:	e9 90 f1 ff ff       	jmp    7dbd <f12+0x13d>
    8c2d:	0f 1f 00             	nopl   (%rax)
    8c30:	66 85 c0             	test   %ax,%ax
    8c33:	0f 85 37 f1 ff ff    	jne    7d70 <f12+0xf0>
    8c39:	e9 0e f1 ff ff       	jmp    7d4c <f12+0xcc>
    8c3e:	66 90                	xchg   %ax,%ax
    8c40:	4c 39 f3             	cmp    %r14,%rbx
    8c43:	0f 8f c3 f5 ff ff    	jg     820c <f12+0x58c>
    8c49:	48 85 db             	test   %rbx,%rbx
    8c4c:	74 12                	je     8c60 <f12+0xfe0>
    8c4e:	4d 85 c0             	test   %r8,%r8
    8c51:	0f 84 29 03 00 00    	je     8f80 <f12+0x1300>
    8c57:	48 85 db             	test   %rbx,%rbx
    8c5a:	0f 85 97 02 00 00    	jne    8ef7 <f12+0x1277>
    8c60:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8c67:	e9 4a f6 ff ff       	jmp    82b6 <f12+0x636>
    8c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c70:	66 85 c0             	test   %ax,%ax
    8c73:	0f 85 c0 f7 ff ff    	jne    8439 <f12+0x7b9>
    8c79:	e9 af f7 ff ff       	jmp    842d <f12+0x7ad>
    8c7e:	66 90                	xchg   %ax,%ax
    8c80:	49 89 ec             	mov    %rbp,%r12
    8c83:	48 89 c5             	mov    %rax,%rbp
    8c86:	e9 25 fc ff ff       	jmp    88b0 <f12+0xc30>
    8c8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c90:	66 0f 6f 0d 08 74 01 	movdqa 0x17408(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    8c97:	00 
    8c98:	48 c7 05 e5 73 01 00 	movq   $0x0,0x173e5(%rip)        # 20088 <fwp_tape_cached_bytes>
    8c9f:	00 00 00 00 
    8ca3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    8ca8:	48 8b 05 11 74 01 00 	mov    0x17411(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    8caf:	66 0f 6f 0d f9 73 01 	movdqa 0x173f9(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    8cb6:	00 
    8cb7:	49 89 46 40          	mov    %rax,0x40(%r14)
    8cbb:	48 8b 05 06 74 01 00 	mov    0x17406(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    8cc2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    8cc7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8ccb:	49 89 46 18          	mov    %rax,0x18(%r14)
    8ccf:	48 8b 05 fa 73 01 00 	mov    0x173fa(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    8cd6:	0f 29 0d c3 73 01 00 	movaps %xmm1,0x173c3(%rip)        # 200a0 <fwp_tape_workspace>
    8cdd:	49 89 46 48          	mov    %rax,0x48(%r14)
    8ce1:	0f 29 0d c8 73 01 00 	movaps %xmm1,0x173c8(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    8ce8:	48 c7 05 dd 73 01 00 	movq   $0x0,0x173dd(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    8cef:	00 00 00 00 
    8cf3:	0f 29 0d c6 73 01 00 	movaps %xmm1,0x173c6(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    8cfa:	e9 fd f1 ff ff       	jmp    7efc <f12+0x27c>
    8cff:	90                   	nop
    8d00:	4d 85 c0             	test   %r8,%r8
    8d03:	0f 84 77 02 00 00    	je     8f80 <f12+0x1300>
    8d09:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    8d0e:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    8d12:	31 f6                	xor    %esi,%esi
    8d14:	4c 89 c7             	mov    %r8,%rdi
    8d17:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8d1c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8d23:	00 
    8d24:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8d29:	e9 b4 fe ff ff       	jmp    8be2 <f12+0xf62>
    8d2e:	66 90                	xchg   %ax,%ax
    8d30:	48 83 05 98 17 06 00 	addq   $0x1,0x61798(%rip)        # 6a4d0 <iteration_retains>
    8d37:	01 
    8d38:	e9 26 f0 ff ff       	jmp    7d63 <f12+0xe3>
    8d3d:	be 02 00 00 00       	mov    $0x2,%esi
    8d42:	bf 08 00 00 00       	mov    $0x8,%edi
    8d47:	e8 c4 d1 ff ff       	call   5f10 <fwp_heap_alloc>
    8d4c:	49 89 c6             	mov    %rax,%r14
    8d4f:	45 31 e4             	xor    %r12d,%r12d
    8d52:	e9 59 fb ff ff       	jmp    88b0 <f12+0xc30>
    8d57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d5e:	00 00 
    8d60:	66 85 c0             	test   %ax,%ax
    8d63:	0f 85 f5 fc ff ff    	jne    8a5e <f12+0xdde>
    8d69:	e9 e2 fc ff ff       	jmp    8a50 <f12+0xdd0>
    8d6e:	66 90                	xchg   %ax,%ax
    8d70:	4d 85 e4             	test   %r12,%r12
    8d73:	0f 85 ee f2 ff ff    	jne    8067 <f12+0x3e7>
    8d79:	e9 41 f3 ff ff       	jmp    80bf <f12+0x43f>
    8d7e:	66 90                	xchg   %ax,%ax
    8d80:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8d87:	ff ff 1f 
    8d8a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    8d8e:	48 39 c2             	cmp    %rax,%rdx
    8d91:	0f 82 47 02 00 00    	jb     8fde <f12+0x135e>
    8d97:	48 8d 05 22 74 04 00 	lea    0x47422(%rip),%rax        # 501c0 <ad_raw_blocks>
    8d9e:	45 31 ed             	xor    %r13d,%r13d
    8da1:	eb 32                	jmp    8dd5 <f12+0x1155>
    8da3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8db1:	00 00 00 00 
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	49 83 c5 01          	add    $0x1,%r13
    8dc4:	48 83 c0 18          	add    $0x18,%rax
    8dc8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    8dcf:	0f 84 5a 01 00 00    	je     8f2f <f12+0x12af>
    8dd5:	48 83 38 00          	cmpq   $0x0,(%rax)
    8dd9:	75 e5                	jne    8dc0 <f12+0x1140>
    8ddb:	be 08 00 00 00       	mov    $0x8,%esi
    8de0:	4c 89 f7             	mov    %r14,%rdi
    8de3:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8de8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8ded:	e8 1e a7 ff ff       	call   3510 <calloc@plt>
    8df2:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8df8:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8dfe:	48 8d 15 bb 73 04 00 	lea    0x473bb(%rip),%rdx        # 501c0 <ad_raw_blocks>
    8e05:	48 85 c0             	test   %rax,%rax
    8e08:	74 36                	je     8e40 <f12+0x11c0>
    8e0a:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    8e0f:	48 89 c6             	mov    %rax,%rsi
    8e12:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8e17:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    8e1b:	b9 03 00 00 00       	mov    $0x3,%ecx
    8e20:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8e27:	00 
    8e28:	e8 d3 ad ff ff       	call   3c00 <ad_raw_record>
    8e2d:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8e32:	e9 43 f4 ff ff       	jmp    827a <f12+0x5fa>
    8e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e3e:	00 00 
    8e40:	4d 85 e4             	test   %r12,%r12
    8e43:	0f 85 37 01 00 00    	jne    8f80 <f12+0x1300>
    8e49:	45 31 c0             	xor    %r8d,%r8d
    8e4c:	e9 42 f4 ff ff       	jmp    8293 <f12+0x613>
    8e51:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8e55:	e9 55 ef ff ff       	jmp    7daf <f12+0x12f>
    8e5a:	49 8b 45 00          	mov    0x0(%r13),%rax
    8e5e:	48 85 c0             	test   %rax,%rax
    8e61:	0f 88 d6 fe ff ff    	js     8d3d <f12+0x10bd>
    8e67:	48 8b 35 8a 0d 06 00 	mov    0x60d8a(%rip),%rsi        # 69bf8 <fwp_heap+0x13d8>
    8e6e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8e73:	48 2b 0d 56 0d 06 00 	sub    0x60d56(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    8e7a:	48 c1 e6 10          	shl    $0x10,%rsi
    8e7e:	48 39 f1             	cmp    %rsi,%rcx
    8e81:	0f 83 b6 fe ff ff    	jae    8d3d <f12+0x10bd>
    8e87:	48 89 ce             	mov    %rcx,%rsi
    8e8a:	48 c1 ee 10          	shr    $0x10,%rsi
    8e8e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8e92:	48 8b 35 7f 0d 06 00 	mov    0x60d7f(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    8e99:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8e9d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8ea1:	48 85 ff             	test   %rdi,%rdi
    8ea4:	0f 84 93 fe ff ff    	je     8d3d <f12+0x10bd>
    8eaa:	48 0f ba f0 3f       	btr    $0x3f,%rax
    8eaf:	49 89 c7             	mov    %rax,%r15
    8eb2:	e9 3e f7 ff ff       	jmp    85f5 <f12+0x975>
    8eb7:	be 68 00 00 00       	mov    $0x68,%esi
    8ebc:	bb 01 00 00 00       	mov    $0x1,%ebx
    8ec1:	e9 75 ef ff ff       	jmp    7e3b <f12+0x1bb>
    8ec6:	4c 89 f7             	mov    %r14,%rdi
    8ec9:	e8 02 c9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8ece:	e9 8b f1 ff ff       	jmp    805e <f12+0x3de>
    8ed3:	48 89 df             	mov    %rbx,%rdi
    8ed6:	e8 f5 c8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8edb:	e9 56 f5 ff ff       	jmp    8436 <f12+0x7b6>
    8ee0:	4c 89 ff             	mov    %r15,%rdi
    8ee3:	e8 e8 c8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8ee8:	e9 6d fb ff ff       	jmp    8a5a <f12+0xdda>
    8eed:	e8 be c7 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8ef2:	e9 79 ee ff ff       	jmp    7d70 <f12+0xf0>
    8ef7:	49 89 dc             	mov    %rbx,%r12
    8efa:	4c 89 c7             	mov    %r8,%rdi
    8efd:	31 f6                	xor    %esi,%esi
    8eff:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8f04:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    8f09:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    8f10:	00 
    8f11:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8f16:	e8 95 a5 ff ff       	call   34b0 <memset@plt>
    8f1b:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8f21:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8f27:	49 89 c0             	mov    %rax,%r8
    8f2a:	e9 6b f3 ff ff       	jmp    829a <f12+0x61a>
    8f2f:	48 8d 3d dc 31 00 00 	lea    0x31dc(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    8f36:	e8 c5 b0 ff ff       	call   4000 <ad_raw_fail>
    8f3b:	45 31 ed             	xor    %r13d,%r13d
    8f3e:	e9 1a f8 ff ff       	jmp    875d <f12+0xadd>
    8f43:	48 8d 3d 78 32 00 00 	lea    0x3278(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    8f4a:	e8 01 b5 ff ff       	call   4450 <fwp_trap>
    8f4f:	48 8d 3d b2 3a 00 00 	lea    0x3ab2(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    8f56:	e8 f5 b4 ff ff       	call   4450 <fwp_trap>
    8f5b:	e8 a0 a7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    8f60:	48 8d 3d a9 3b 00 00 	lea    0x3ba9(%rip),%rdi        # cb10 <_IO_stdin_used+0xb10>
    8f67:	e8 e4 b4 ff ff       	call   4450 <fwp_trap>
    8f6c:	45 31 f6             	xor    %r14d,%r14d
    8f6f:	e9 db fd ff ff       	jmp    8d4f <f12+0x10cf>
    8f74:	48 8d 3d 70 32 00 00 	lea    0x3270(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    8f7b:	e8 d0 b4 ff ff       	call   4450 <fwp_trap>
    8f80:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    8f87:	00 
    8f88:	48 8b 3c 24          	mov    (%rsp),%rdi
    8f8c:	48 89 05 25 15 06 00 	mov    %rax,0x61525(%rip)        # 6a4b8 <fwp_cleanups>
    8f93:	e8 c8 c2 ff ff       	call   5260 <fwp_tape_buffers_release>
    8f98:	48 8b 0d a1 70 00 00 	mov    0x70a1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    8f9f:	ba 13 00 00 00       	mov    $0x13,%edx
    8fa4:	be 01 00 00 00       	mov    $0x1,%esi
    8fa9:	48 8d 3d 58 30 00 00 	lea    0x3058(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    8fb0:	e8 ab a6 ff ff       	call   3660 <fwrite@plt>
    8fb5:	31 ff                	xor    %edi,%edi
    8fb7:	e8 e4 a5 ff ff       	call   35a0 <fflush@plt>
    8fbc:	bf 66 00 00 00       	mov    $0x66,%edi
    8fc1:	e8 ba a6 ff ff       	call   3680 <_Exit@plt>
    8fc6:	48 8d 3d 38 32 00 00 	lea    0x3238(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    8fcd:	e8 7e b4 ff ff       	call   4450 <fwp_trap>
    8fd2:	48 8d 3d 56 32 00 00 	lea    0x3256(%rip),%rdi        # c22f <_IO_stdin_used+0x22f>
    8fd9:	e8 72 b4 ff ff       	call   4450 <fwp_trap>
    8fde:	48 8d 3d 2e 32 00 00 	lea    0x322e(%rip),%rdi        # c213 <_IO_stdin_used+0x213>
    8fe5:	e8 16 b0 ff ff       	call   4000 <ad_raw_fail>
    8fea:	48 8d 3d 5f 3a 00 00 	lea    0x3a5f(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    8ff1:	e8 5a b4 ff ff       	call   4450 <fwp_trap>
    8ff6:	48 8d 3d b3 3a 00 00 	lea    0x3ab3(%rip),%rdi        # cab0 <_IO_stdin_used+0xab0>
    8ffd:	e8 4e b4 ff ff       	call   4450 <fwp_trap>
    9002:	e8 49 a4 ff ff       	call   3450 <__stack_chk_fail@plt>
    9007:	48 8d 3d d2 3a 00 00 	lea    0x3ad2(%rip),%rdi        # cae0 <_IO_stdin_used+0xae0>
    900e:	e8 3d b4 ff ff       	call   4450 <fwp_trap>
    9013:	66 90                	xchg   %ax,%ax
    9015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    901c:	00 00 00 00 

0000000000009020 <fwp_owned_entry12>:
    9020:	f3 0f 1e fa          	endbr64
    9024:	48 8b 3f             	mov    (%rdi),%rdi
    9027:	e9 54 ec ff ff       	jmp    7c80 <f12>
    902c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009030 <e12>:
    9030:	f3 0f 1e fa          	endbr64
    9034:	53                   	push   %rbx
    9035:	48 8b 1f             	mov    (%rdi),%rbx
    9038:	48 89 df             	mov    %rbx,%rdi
    903b:	e8 f0 d9 ff ff       	call   6a30 <fwp_rc_share>
    9040:	48 89 df             	mov    %rbx,%rdi
    9043:	e8 38 ec ff ff       	call   7c80 <f12>
    9048:	48 89 c3             	mov    %rax,%rbx
    904b:	48 89 c7             	mov    %rax,%rdi
    904e:	e8 dd d9 ff ff       	call   6a30 <fwp_rc_share>
    9053:	48 89 d8             	mov    %rbx,%rax
    9056:	5b                   	pop    %rbx
    9057:	c3                   	ret
    9058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    905f:	00 

0000000000009060 <fwp_drop2>:
    9060:	48 8b 0d 91 0b 06 00 	mov    0x60b91(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    9067:	48 89 f8             	mov    %rdi,%rax
    906a:	48 2b 05 5f 0b 06 00 	sub    0x60b5f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9071:	48 c1 e1 10          	shl    $0x10,%rcx
    9075:	48 39 c8             	cmp    %rcx,%rax
    9078:	0f 83 42 01 00 00    	jae    91c0 <fwp_drop2+0x160>
    907e:	48 83 ec 18          	sub    $0x18,%rsp
    9082:	48 89 fa             	mov    %rdi,%rdx
    9085:	4c 8d 05 94 f7 05 00 	lea    0x5f794(%rip),%r8        # 68820 <fwp_heap>
    908c:	48 89 c1             	mov    %rax,%rcx
    908f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9096:	48 c1 e9 10          	shr    $0x10,%rcx
    909a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    909e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    90a2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    90a6:	48 85 c9             	test   %rcx,%rcx
    90a9:	74 40                	je     90eb <fwp_drop2+0x8b>
    90ab:	0f b6 3e             	movzbl (%rsi),%edi
    90ae:	40 80 ff 02          	cmp    $0x2,%dil
    90b2:	74 3c                	je     90f0 <fwp_drop2+0x90>
    90b4:	40 80 ff 01          	cmp    $0x1,%dil
    90b8:	75 31                	jne    90eb <fwp_drop2+0x8b>
    90ba:	8b 7e 18             	mov    0x18(%rsi),%edi
    90bd:	0f b7 c0             	movzwl %ax,%eax
    90c0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    90c3:	48 0f af c7          	imul   %rdi,%rax
    90c7:	48 c1 e8 20          	shr    $0x20,%rax
    90cb:	48 39 f0             	cmp    %rsi,%rax
    90ce:	73 1b                	jae    90eb <fwp_drop2+0x8b>
    90d0:	48 01 c1             	add    %rax,%rcx
    90d3:	0f b6 01             	movzbl (%rcx),%eax
    90d6:	84 c0                	test   %al,%al
    90d8:	74 11                	je     90eb <fwp_drop2+0x8b>
    90da:	3c 01                	cmp    $0x1,%al
    90dc:	74 22                	je     9100 <fwp_drop2+0xa0>
    90de:	3c ff                	cmp    $0xff,%al
    90e0:	0f 84 0a 01 00 00    	je     91f0 <fwp_drop2+0x190>
    90e6:	83 e8 01             	sub    $0x1,%eax
    90e9:	88 01                	mov    %al,(%rcx)
    90eb:	48 83 c4 18          	add    $0x18,%rsp
    90ef:	c3                   	ret
    90f0:	66 85 c0             	test   %ax,%ax
    90f3:	74 de                	je     90d3 <fwp_drop2+0x73>
    90f5:	48 83 c4 18          	add    $0x18,%rsp
    90f9:	c3                   	ret
    90fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9100:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9104:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    910b:	48 89 f8             	mov    %rdi,%rax
    910e:	48 c1 e1 10          	shl    $0x10,%rcx
    9112:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9119:	48 39 c8             	cmp    %rcx,%rax
    911c:	73 62                	jae    9180 <fwp_drop2+0x120>
    911e:	48 89 c1             	mov    %rax,%rcx
    9121:	48 c1 e9 10          	shr    $0x10,%rcx
    9125:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9129:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    912d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9131:	48 85 c9             	test   %rcx,%rcx
    9134:	74 4a                	je     9180 <fwp_drop2+0x120>
    9136:	44 0f b6 0e          	movzbl (%rsi),%r9d
    913a:	41 80 f9 02          	cmp    $0x2,%r9b
    913e:	0f 84 9c 00 00 00    	je     91e0 <fwp_drop2+0x180>
    9144:	41 80 f9 01          	cmp    $0x1,%r9b
    9148:	75 36                	jne    9180 <fwp_drop2+0x120>
    914a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    914e:	0f b7 c0             	movzwl %ax,%eax
    9151:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9154:	49 0f af c1          	imul   %r9,%rax
    9158:	48 c1 e8 20          	shr    $0x20,%rax
    915c:	48 39 f0             	cmp    %rsi,%rax
    915f:	73 1f                	jae    9180 <fwp_drop2+0x120>
    9161:	48 01 c1             	add    %rax,%rcx
    9164:	0f b6 01             	movzbl (%rcx),%eax
    9167:	84 c0                	test   %al,%al
    9169:	74 15                	je     9180 <fwp_drop2+0x120>
    916b:	3c 01                	cmp    $0x1,%al
    916d:	74 59                	je     91c8 <fwp_drop2+0x168>
    916f:	3c ff                	cmp    $0xff,%al
    9171:	0f 84 ef 00 00 00    	je     9266 <fwp_drop2+0x206>
    9177:	83 e8 01             	sub    $0x1,%eax
    917a:	88 01                	mov    %al,(%rcx)
    917c:	0f 1f 40 00          	nopl   0x0(%rax)
    9180:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9184:	48 89 d7             	mov    %rdx,%rdi
    9187:	48 89 0c 24          	mov    %rcx,(%rsp)
    918b:	e8 20 d9 ff ff       	call   6ab0 <fwp_rc_free_arr>
    9190:	4c 8d 05 89 f6 05 00 	lea    0x5f689(%rip),%r8        # 68820 <fwp_heap>
    9197:	48 8b 04 24          	mov    (%rsp),%rax
    919b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    91a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    91a9:	48 c1 e2 10          	shl    $0x10,%rdx
    91ad:	48 39 d0             	cmp    %rdx,%rax
    91b0:	0f 83 35 ff ff ff    	jae    90eb <fwp_drop2+0x8b>
    91b6:	48 8b 14 24          	mov    (%rsp),%rdx
    91ba:	e9 cd fe ff ff       	jmp    908c <fwp_drop2+0x2c>
    91bf:	90                   	nop
    91c0:	c3                   	ret
    91c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91c8:	48 89 14 24          	mov    %rdx,(%rsp)
    91cc:	e8 df d8 ff ff       	call   6ab0 <fwp_rc_free_arr>
    91d1:	48 8b 14 24          	mov    (%rsp),%rdx
    91d5:	eb a9                	jmp    9180 <fwp_drop2+0x120>
    91d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91de:	00 00 
    91e0:	66 85 c0             	test   %ax,%ax
    91e3:	75 9b                	jne    9180 <fwp_drop2+0x120>
    91e5:	e9 7a ff ff ff       	jmp    9164 <fwp_drop2+0x104>
    91ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91f0:	48 89 c8             	mov    %rcx,%rax
    91f3:	48 c1 e8 11          	shr    $0x11,%rax
    91f7:	48 31 c8             	xor    %rcx,%rax
    91fa:	48 89 c2             	mov    %rax,%rdx
    91fd:	48 c1 ea 09          	shr    $0x9,%rdx
    9201:	48 31 d0             	xor    %rdx,%rax
    9204:	0f b6 d0             	movzbl %al,%edx
    9207:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    920e:	00 
    920f:	48 85 c0             	test   %rax,%rax
    9212:	75 19                	jne    922d <fwp_drop2+0x1cd>
    9214:	e9 d3 00 00 00       	jmp    92ec <fwp_drop2+0x28c>
    9219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9224:	48 85 c0             	test   %rax,%rax
    9227:	0f 84 bf 00 00 00    	je     92ec <fwp_drop2+0x28c>
    922d:	48 89 c2             	mov    %rax,%rdx
    9230:	48 39 08             	cmp    %rcx,(%rax)
    9233:	75 eb                	jne    9220 <fwp_drop2+0x1c0>
    9235:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9239:	48 83 ea 01          	sub    $0x1,%rdx
    923d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9241:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9248:	0f 85 9d fe ff ff    	jne    90eb <fwp_drop2+0x8b>
    924e:	48 89 cf             	mov    %rcx,%rdi
    9251:	48 89 0c 24          	mov    %rcx,(%rsp)
    9255:	e8 76 c5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    925a:	48 8b 0c 24          	mov    (%rsp),%rcx
    925e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9261:	e9 85 fe ff ff       	jmp    90eb <fwp_drop2+0x8b>
    9266:	48 89 ce             	mov    %rcx,%rsi
    9269:	48 c1 ee 11          	shr    $0x11,%rsi
    926d:	48 31 ce             	xor    %rcx,%rsi
    9270:	48 89 f0             	mov    %rsi,%rax
    9273:	48 c1 e8 09          	shr    $0x9,%rax
    9277:	48 31 c6             	xor    %rax,%rsi
    927a:	40 0f b6 f6          	movzbl %sil,%esi
    927e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9285:	00 
    9286:	48 85 c0             	test   %rax,%rax
    9289:	75 1e                	jne    92a9 <fwp_drop2+0x249>
    928b:	eb 5f                	jmp    92ec <fwp_drop2+0x28c>
    928d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9294:	00 
    9295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    929c:	00 00 00 00 
    92a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    92a4:	48 85 c0             	test   %rax,%rax
    92a7:	74 43                	je     92ec <fwp_drop2+0x28c>
    92a9:	48 89 c6             	mov    %rax,%rsi
    92ac:	48 39 08             	cmp    %rcx,(%rax)
    92af:	75 ef                	jne    92a0 <fwp_drop2+0x240>
    92b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    92b5:	48 83 ee 01          	sub    $0x1,%rsi
    92b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    92bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    92c4:	0f 85 b6 fe ff ff    	jne    9180 <fwp_drop2+0x120>
    92ca:	48 89 cf             	mov    %rcx,%rdi
    92cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    92d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    92d6:	e8 f5 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    92db:	48 8b 0c 24          	mov    (%rsp),%rcx
    92df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    92e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    92e7:	e9 94 fe ff ff       	jmp    9180 <fwp_drop2+0x120>
    92ec:	48 8d 3d ed 36 00 00 	lea    0x36ed(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    92f3:	e8 58 b1 ff ff       	call   4450 <fwp_trap>
    92f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92ff:	00 

0000000000009300 <fwp_arg_drop23>:
    9300:	f3 0f 1e fa          	endbr64
    9304:	85 f6                	test   %esi,%esi
    9306:	75 04                	jne    930c <fwp_arg_drop23+0xc>
    9308:	85 d2                	test   %edx,%edx
    930a:	75 04                	jne    9310 <fwp_arg_drop23+0x10>
    930c:	c3                   	ret
    930d:	0f 1f 00             	nopl   (%rax)
    9310:	48 8b 3f             	mov    (%rdi),%rdi
    9313:	e9 48 fd ff ff       	jmp    9060 <fwp_drop2>
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 

0000000000009320 <f23>:
    9320:	41 57                	push   %r15
    9322:	41 56                	push   %r14
    9324:	41 55                	push   %r13
    9326:	41 54                	push   %r12
    9328:	55                   	push   %rbp
    9329:	53                   	push   %rbx
    932a:	48 83 ec 38          	sub    $0x38,%rsp
    932e:	48 8b 15 c3 08 06 00 	mov    0x608c3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9335:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    933a:	48 c1 e2 10          	shl    $0x10,%rdx
    933e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    9345:	00 00 
    9347:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    934c:	48 8b 0d 7d 08 06 00 	mov    0x6087d(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    9353:	48 85 ff             	test   %rdi,%rdi
    9356:	0f 84 6e 03 00 00    	je     96ca <f23+0x3aa>
    935c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9361:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9365:	4c 89 e8             	mov    %r13,%rax
    9368:	48 29 c8             	sub    %rcx,%rax
    936b:	48 39 d0             	cmp    %rdx,%rax
    936e:	0f 83 3c 03 00 00    	jae    96b0 <f23+0x390>
    9374:	48 89 c2             	mov    %rax,%rdx
    9377:	48 c1 ea 10          	shr    $0x10,%rdx
    937b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    937f:	48 8b 15 92 08 06 00 	mov    0x60892(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9386:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    938a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    938e:	48 85 ff             	test   %rdi,%rdi
    9391:	0f 84 19 03 00 00    	je     96b0 <f23+0x390>
    9397:	0f b6 0a             	movzbl (%rdx),%ecx
    939a:	80 f9 02             	cmp    $0x2,%cl
    939d:	0f 84 9d 02 00 00    	je     9640 <f23+0x320>
    93a3:	80 f9 01             	cmp    $0x1,%cl
    93a6:	75 24                	jne    93cc <f23+0xac>
    93a8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93ab:	0f b7 c0             	movzwl %ax,%eax
    93ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93b1:	48 0f af c1          	imul   %rcx,%rax
    93b5:	48 c1 e8 20          	shr    $0x20,%rax
    93b9:	48 39 d0             	cmp    %rdx,%rax
    93bc:	73 0e                	jae    93cc <f23+0xac>
    93be:	48 01 c7             	add    %rax,%rdi
    93c1:	0f b6 07             	movzbl (%rdi),%eax
    93c4:	84 c0                	test   %al,%al
    93c6:	0f 85 94 02 00 00    	jne    9660 <f23+0x340>
    93cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    93d1:	48 8b 40 10          	mov    0x10(%rax),%rax
    93d5:	ba 01 00 00 00       	mov    $0x1,%edx
    93da:	48 85 c0             	test   %rax,%rax
    93dd:	74 0e                	je     93ed <f23+0xcd>
    93df:	90                   	nop
    93e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93e4:	48 83 c2 01          	add    $0x1,%rdx
    93e8:	48 85 c0             	test   %rax,%rax
    93eb:	75 f3                	jne    93e0 <f23+0xc0>
    93ed:	4d 85 ed             	test   %r13,%r13
    93f0:	0f 84 ea 02 00 00    	je     96e0 <f23+0x3c0>
    93f6:	4c 89 e8             	mov    %r13,%rax
    93f9:	31 db                	xor    %ebx,%ebx
    93fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9400:	48 8b 40 10          	mov    0x10(%rax),%rax
    9404:	48 83 c3 01          	add    $0x1,%rbx
    9408:	48 85 c0             	test   %rax,%rax
    940b:	75 f3                	jne    9400 <f23+0xe0>
    940d:	48 39 d3             	cmp    %rdx,%rbx
    9410:	48 0f 47 da          	cmova  %rdx,%rbx
    9414:	48 89 d8             	mov    %rbx,%rax
    9417:	48 c1 e8 3c          	shr    $0x3c,%rax
    941b:	0f 85 cd 03 00 00    	jne    97ee <f23+0x4ce>
    9421:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9425:	be 02 00 00 00       	mov    $0x2,%esi
    942a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9431:	00 
    9432:	e8 d9 ca ff ff       	call   5f10 <fwp_heap_alloc>
    9437:	48 89 28             	mov    %rbp,(%rax)
    943a:	48 8b 15 b7 07 06 00 	mov    0x607b7(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9441:	49 89 c4             	mov    %rax,%r12
    9444:	48 2b 05 85 07 06 00 	sub    0x60785(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    944b:	48 c1 e2 10          	shl    $0x10,%rdx
    944f:	48 39 d0             	cmp    %rdx,%rax
    9452:	73 57                	jae    94ab <f23+0x18b>
    9454:	48 89 c2             	mov    %rax,%rdx
    9457:	48 c1 ea 10          	shr    $0x10,%rdx
    945b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    945f:	48 8b 15 b2 07 06 00 	mov    0x607b2(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9466:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    946a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    946e:	48 85 ed             	test   %rbp,%rbp
    9471:	74 38                	je     94ab <f23+0x18b>
    9473:	0f b6 0a             	movzbl (%rdx),%ecx
    9476:	80 f9 02             	cmp    $0x2,%cl
    9479:	0f 84 21 02 00 00    	je     96a0 <f23+0x380>
    947f:	80 f9 01             	cmp    $0x1,%cl
    9482:	75 27                	jne    94ab <f23+0x18b>
    9484:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9487:	0f b7 c0             	movzwl %ax,%eax
    948a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    948d:	48 0f af c1          	imul   %rcx,%rax
    9491:	48 c1 e8 20          	shr    $0x20,%rax
    9495:	48 39 d0             	cmp    %rdx,%rax
    9498:	73 11                	jae    94ab <f23+0x18b>
    949a:	48 01 c5             	add    %rax,%rbp
    949d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    94a1:	0f 84 a7 02 00 00    	je     974e <f23+0x42e>
    94a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    94ab:	48 85 db             	test   %rbx,%rbx
    94ae:	74 5d                	je     950d <f23+0x1ed>
    94b0:	48 c1 e3 04          	shl    $0x4,%rbx
    94b4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    94b9:	4c 89 e5             	mov    %r12,%rbp
    94bc:	4d 89 ef             	mov    %r13,%r15
    94bf:	4c 01 e3             	add    %r12,%rbx
    94c2:	0f 1f 00             	nopl   (%rax)
    94c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94cc:	00 00 00 00 
    94d0:	49 8b 46 08          	mov    0x8(%r14),%rax
    94d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    94d8:	48 83 c5 10          	add    $0x10,%rbp
    94dc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    94e1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    94e5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    94e9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    94ee:	e8 dd d1 ff ff       	call   66d0 <w107>
    94f3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    94f8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    94fc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9500:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9504:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9508:	48 39 eb             	cmp    %rbp,%rbx
    950b:	75 c3                	jne    94d0 <f23+0x1b0>
    950d:	4c 89 ef             	mov    %r13,%rdi
    9510:	31 db                	xor    %ebx,%ebx
    9512:	e8 49 fb ff ff       	call   9060 <fwp_drop2>
    9517:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    951c:	e8 3f fb ff ff       	call   9060 <fwp_drop2>
    9521:	4d 8b 2c 24          	mov    (%r12),%r13
    9525:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9529:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9530:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9537:	4d 85 ed             	test   %r13,%r13
    953a:	74 3f                	je     957b <f23+0x25b>
    953c:	0f 1f 40 00          	nopl   0x0(%rax)
    9540:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9547:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    954c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    9553:	00 f0 3f 
    9556:	48 83 c3 02          	add    $0x2,%rbx
    955a:	48 89 ce             	mov    %rcx,%rsi
    955d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9563:	e8 e8 cd ff ff       	call   6350 <fwp_p_ad_push>
    9568:	4c 39 eb             	cmp    %r13,%rbx
    956b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9571:	48 89 c7             	mov    %rax,%rdi
    9574:	72 ca                	jb     9540 <f23+0x220>
    9576:	66 49 0f 7e c5       	movq   %xmm0,%r13
    957b:	4c 89 e7             	mov    %r12,%rdi
    957e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9583:	e8 78 e4 ff ff       	call   7a00 <fwp_drop4>
    9588:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    958d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9592:	31 ff                	xor    %edi,%edi
    9594:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9599:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    959e:	e8 9d d2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    95a3:	48 8b 15 4e 06 06 00 	mov    0x6064e(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    95aa:	48 89 c5             	mov    %rax,%rbp
    95ad:	48 2b 05 1c 06 06 00 	sub    0x6061c(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    95b4:	48 c1 e2 10          	shl    $0x10,%rdx
    95b8:	48 39 d0             	cmp    %rdx,%rax
    95bb:	73 55                	jae    9612 <f23+0x2f2>
    95bd:	48 89 c2             	mov    %rax,%rdx
    95c0:	48 c1 ea 10          	shr    $0x10,%rdx
    95c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95c8:	48 8b 15 49 06 06 00 	mov    0x60649(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    95cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95d3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    95d7:	48 85 db             	test   %rbx,%rbx
    95da:	74 36                	je     9612 <f23+0x2f2>
    95dc:	0f b6 0a             	movzbl (%rdx),%ecx
    95df:	80 f9 02             	cmp    $0x2,%cl
    95e2:	0f 84 a8 00 00 00    	je     9690 <f23+0x370>
    95e8:	80 f9 01             	cmp    $0x1,%cl
    95eb:	75 25                	jne    9612 <f23+0x2f2>
    95ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95f0:	0f b7 c0             	movzwl %ax,%eax
    95f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95f6:	48 0f af c1          	imul   %rcx,%rax
    95fa:	48 c1 e8 20          	shr    $0x20,%rax
    95fe:	48 39 d0             	cmp    %rdx,%rax
    9601:	73 0f                	jae    9612 <f23+0x2f2>
    9603:	48 01 c3             	add    %rax,%rbx
    9606:	80 3b ff             	cmpb   $0xff,(%rbx)
    9609:	0f 84 32 01 00 00    	je     9741 <f23+0x421>
    960f:	c6 03 01             	movb   $0x1,(%rbx)
    9612:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9617:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    961e:	00 00 
    9620:	0f 85 d4 01 00 00    	jne    97fa <f23+0x4da>
    9626:	48 83 c4 38          	add    $0x38,%rsp
    962a:	48 89 e8             	mov    %rbp,%rax
    962d:	5b                   	pop    %rbx
    962e:	5d                   	pop    %rbp
    962f:	41 5c                	pop    %r12
    9631:	41 5d                	pop    %r13
    9633:	41 5e                	pop    %r14
    9635:	41 5f                	pop    %r15
    9637:	c3                   	ret
    9638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    963f:	00 
    9640:	66 85 c0             	test   %ax,%ax
    9643:	0f 85 83 fd ff ff    	jne    93cc <f23+0xac>
    9649:	0f b6 07             	movzbl (%rdi),%eax
    964c:	84 c0                	test   %al,%al
    964e:	0f 84 78 fd ff ff    	je     93cc <f23+0xac>
    9654:	90                   	nop
    9655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    965c:	00 00 00 00 
    9660:	8b 15 82 0e 06 00    	mov    0x60e82(%rip),%edx        # 6a4e8 <iteration_active>
    9666:	85 d2                	test   %edx,%edx
    9668:	75 56                	jne    96c0 <f23+0x3a0>
    966a:	3c fd                	cmp    $0xfd,%al
    966c:	0f 87 4b 01 00 00    	ja     97bd <f23+0x49d>
    9672:	83 c0 01             	add    $0x1,%eax
    9675:	88 07                	mov    %al,(%rdi)
    9677:	31 d2                	xor    %edx,%edx
    9679:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    967f:	0f 85 47 fd ff ff    	jne    93cc <f23+0xac>
    9685:	e9 63 fd ff ff       	jmp    93ed <f23+0xcd>
    968a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9690:	66 85 c0             	test   %ax,%ax
    9693:	0f 85 79 ff ff ff    	jne    9612 <f23+0x2f2>
    9699:	e9 68 ff ff ff       	jmp    9606 <f23+0x2e6>
    969e:	66 90                	xchg   %ax,%ax
    96a0:	66 85 c0             	test   %ax,%ax
    96a3:	0f 85 02 fe ff ff    	jne    94ab <f23+0x18b>
    96a9:	e9 ef fd ff ff       	jmp    949d <f23+0x17d>
    96ae:	66 90                	xchg   %ax,%ax
    96b0:	4c 89 e8             	mov    %r13,%rax
    96b3:	e9 1d fd ff ff       	jmp    93d5 <f23+0xb5>
    96b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    96bf:	00 
    96c0:	48 83 05 08 0e 06 00 	addq   $0x1,0x60e08(%rip)        # 6a4d0 <iteration_retains>
    96c7:	01 
    96c8:	eb a0                	jmp    966a <f23+0x34a>
    96ca:	48 f7 d9             	neg    %rcx
    96cd:	48 39 d1             	cmp    %rdx,%rcx
    96d0:	0f 82 85 00 00 00    	jb     975b <f23+0x43b>
    96d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96dd:	00 00 00 
    96e0:	be 02 00 00 00       	mov    $0x2,%esi
    96e5:	bf 08 00 00 00       	mov    $0x8,%edi
    96ea:	e8 21 c8 ff ff       	call   5f10 <fwp_heap_alloc>
    96ef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    96f6:	48 8b 15 fb 04 06 00 	mov    0x604fb(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    96fd:	49 89 c4             	mov    %rax,%r12
    9700:	48 2b 05 c9 04 06 00 	sub    0x604c9(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9707:	48 c1 e2 10          	shl    $0x10,%rdx
    970b:	48 39 d0             	cmp    %rdx,%rax
    970e:	0f 83 b3 00 00 00    	jae    97c7 <f23+0x4a7>
    9714:	48 89 c2             	mov    %rax,%rdx
    9717:	45 31 ed             	xor    %r13d,%r13d
    971a:	48 c1 ea 10          	shr    $0x10,%rdx
    971e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9722:	48 8b 15 ef 04 06 00 	mov    0x604ef(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9729:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    972d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9731:	48 85 ed             	test   %rbp,%rbp
    9734:	0f 84 d3 fd ff ff    	je     950d <f23+0x1ed>
    973a:	31 db                	xor    %ebx,%ebx
    973c:	e9 32 fd ff ff       	jmp    9473 <f23+0x153>
    9741:	48 89 df             	mov    %rbx,%rdi
    9744:	e8 87 c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9749:	e9 c1 fe ff ff       	jmp    960f <f23+0x2ef>
    974e:	48 89 ef             	mov    %rbp,%rdi
    9751:	e8 7a c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9756:	e9 4c fd ff ff       	jmp    94a7 <f23+0x187>
    975b:	48 89 c8             	mov    %rcx,%rax
    975e:	48 c1 e8 10          	shr    $0x10,%rax
    9762:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9766:	48 8b 05 ab 04 06 00 	mov    0x604ab(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    976d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9771:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9775:	48 85 ff             	test   %rdi,%rdi
    9778:	0f 84 62 ff ff ff    	je     96e0 <f23+0x3c0>
    977e:	0f b6 02             	movzbl (%rdx),%eax
    9781:	3c 02                	cmp    $0x2,%al
    9783:	74 4a                	je     97cf <f23+0x4af>
    9785:	3c 01                	cmp    $0x1,%al
    9787:	0f 85 53 ff ff ff    	jne    96e0 <f23+0x3c0>
    978d:	0f b7 c1             	movzwl %cx,%eax
    9790:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9793:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9796:	48 0f af c1          	imul   %rcx,%rax
    979a:	48 c1 e8 20          	shr    $0x20,%rax
    979e:	48 39 d0             	cmp    %rdx,%rax
    97a1:	0f 83 39 ff ff ff    	jae    96e0 <f23+0x3c0>
    97a7:	48 01 c7             	add    %rax,%rdi
    97aa:	0f b6 07             	movzbl (%rdi),%eax
    97ad:	84 c0                	test   %al,%al
    97af:	0f 84 2b ff ff ff    	je     96e0 <f23+0x3c0>
    97b5:	45 31 ed             	xor    %r13d,%r13d
    97b8:	e9 a3 fe ff ff       	jmp    9660 <f23+0x340>
    97bd:	e8 ee be ff ff       	call   56b0 <fwp_rc_wide_dup>
    97c2:	e9 b0 fe ff ff       	jmp    9677 <f23+0x357>
    97c7:	45 31 ed             	xor    %r13d,%r13d
    97ca:	e9 3e fd ff ff       	jmp    950d <f23+0x1ed>
    97cf:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    97d5:	49 89 cd             	mov    %rcx,%r13
    97d8:	0f 85 02 ff ff ff    	jne    96e0 <f23+0x3c0>
    97de:	0f b6 07             	movzbl (%rdi),%eax
    97e1:	84 c0                	test   %al,%al
    97e3:	0f 85 77 fe ff ff    	jne    9660 <f23+0x340>
    97e9:	e9 f2 fe ff ff       	jmp    96e0 <f23+0x3c0>
    97ee:	48 8d 3d 10 2a 00 00 	lea    0x2a10(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    97f5:	e8 56 ac ff ff       	call   4450 <fwp_trap>
    97fa:	e8 51 9c ff ff       	call   3450 <__stack_chk_fail@plt>
    97ff:	90                   	nop

0000000000009800 <fwp_owned_entry23>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	48 8b 3f             	mov    (%rdi),%rdi
    9807:	e9 14 fb ff ff       	jmp    9320 <f23>
    980c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009810 <e23>:
    9810:	f3 0f 1e fa          	endbr64
    9814:	53                   	push   %rbx
    9815:	48 8b 1f             	mov    (%rdi),%rbx
    9818:	48 89 df             	mov    %rbx,%rdi
    981b:	e8 10 d2 ff ff       	call   6a30 <fwp_rc_share>
    9820:	48 89 df             	mov    %rbx,%rdi
    9823:	e8 f8 fa ff ff       	call   9320 <f23>
    9828:	48 89 c3             	mov    %rax,%rbx
    982b:	48 89 c7             	mov    %rax,%rdi
    982e:	e8 fd d1 ff ff       	call   6a30 <fwp_rc_share>
    9833:	48 89 d8             	mov    %rbx,%rax
    9836:	5b                   	pop    %rbx
    9837:	c3                   	ret
    9838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    983f:	00 

0000000000009840 <fwp_args12>:
    9840:	f3 0f 1e fa          	endbr64
    9844:	85 d2                	test   %edx,%edx
    9846:	74 04                	je     984c <fwp_args12+0xc>
    9848:	85 f6                	test   %esi,%esi
    984a:	74 04                	je     9850 <fwp_args12+0x10>
    984c:	c3                   	ret
    984d:	0f 1f 00             	nopl   (%rax)
    9850:	48 8b 15 a1 03 06 00 	mov    0x603a1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9857:	48 8b 07             	mov    (%rdi),%rax
    985a:	48 2b 05 6f 03 06 00 	sub    0x6036f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9861:	48 c1 e2 10          	shl    $0x10,%rdx
    9865:	48 39 d0             	cmp    %rdx,%rax
    9868:	73 e2                	jae    984c <fwp_args12+0xc>
    986a:	48 89 c2             	mov    %rax,%rdx
    986d:	48 c1 ea 10          	shr    $0x10,%rdx
    9871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9875:	48 8b 15 9c 03 06 00 	mov    0x6039c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    987c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9880:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9884:	48 85 ff             	test   %rdi,%rdi
    9887:	74 c3                	je     984c <fwp_args12+0xc>
    9889:	0f b6 0a             	movzbl (%rdx),%ecx
    988c:	80 f9 02             	cmp    $0x2,%cl
    988f:	74 4f                	je     98e0 <fwp_args12+0xa0>
    9891:	80 f9 01             	cmp    $0x1,%cl
    9894:	75 b6                	jne    984c <fwp_args12+0xc>
    9896:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9899:	0f b7 c0             	movzwl %ax,%eax
    989c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    989f:	48 0f af c1          	imul   %rcx,%rax
    98a3:	48 c1 e8 20          	shr    $0x20,%rax
    98a7:	48 39 d0             	cmp    %rdx,%rax
    98aa:	73 a0                	jae    984c <fwp_args12+0xc>
    98ac:	48 01 c7             	add    %rax,%rdi
    98af:	0f b6 07             	movzbl (%rdi),%eax
    98b2:	84 c0                	test   %al,%al
    98b4:	74 96                	je     984c <fwp_args12+0xc>
    98b6:	8b 15 2c 0c 06 00    	mov    0x60c2c(%rip),%edx        # 6a4e8 <iteration_active>
    98bc:	85 d2                	test   %edx,%edx
    98be:	75 10                	jne    98d0 <fwp_args12+0x90>
    98c0:	3c fd                	cmp    $0xfd,%al
    98c2:	77 22                	ja     98e6 <fwp_args12+0xa6>
    98c4:	83 c0 01             	add    $0x1,%eax
    98c7:	88 07                	mov    %al,(%rdi)
    98c9:	c3                   	ret
    98ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98d0:	48 83 05 f8 0b 06 00 	addq   $0x1,0x60bf8(%rip)        # 6a4d0 <iteration_retains>
    98d7:	01 
    98d8:	eb e6                	jmp    98c0 <fwp_args12+0x80>
    98da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98e0:	66 85 c0             	test   %ax,%ax
    98e3:	74 ca                	je     98af <fwp_args12+0x6f>
    98e5:	c3                   	ret
    98e6:	e9 c5 bd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    98eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000098f0 <fwp_args23>:
    98f0:	f3 0f 1e fa          	endbr64
    98f4:	85 d2                	test   %edx,%edx
    98f6:	74 04                	je     98fc <fwp_args23+0xc>
    98f8:	85 f6                	test   %esi,%esi
    98fa:	74 04                	je     9900 <fwp_args23+0x10>
    98fc:	c3                   	ret
    98fd:	0f 1f 00             	nopl   (%rax)
    9900:	48 8b 15 f1 02 06 00 	mov    0x602f1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9907:	48 8b 07             	mov    (%rdi),%rax
    990a:	48 2b 05 bf 02 06 00 	sub    0x602bf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9911:	48 c1 e2 10          	shl    $0x10,%rdx
    9915:	48 39 d0             	cmp    %rdx,%rax
    9918:	73 e2                	jae    98fc <fwp_args23+0xc>
    991a:	48 89 c2             	mov    %rax,%rdx
    991d:	48 c1 ea 10          	shr    $0x10,%rdx
    9921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9925:	48 8b 15 ec 02 06 00 	mov    0x602ec(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    992c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9930:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9934:	48 85 ff             	test   %rdi,%rdi
    9937:	74 c3                	je     98fc <fwp_args23+0xc>
    9939:	0f b6 0a             	movzbl (%rdx),%ecx
    993c:	80 f9 02             	cmp    $0x2,%cl
    993f:	74 4f                	je     9990 <fwp_args23+0xa0>
    9941:	80 f9 01             	cmp    $0x1,%cl
    9944:	75 b6                	jne    98fc <fwp_args23+0xc>
    9946:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9949:	0f b7 c0             	movzwl %ax,%eax
    994c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    994f:	48 0f af c1          	imul   %rcx,%rax
    9953:	48 c1 e8 20          	shr    $0x20,%rax
    9957:	48 39 d0             	cmp    %rdx,%rax
    995a:	73 a0                	jae    98fc <fwp_args23+0xc>
    995c:	48 01 c7             	add    %rax,%rdi
    995f:	0f b6 07             	movzbl (%rdi),%eax
    9962:	84 c0                	test   %al,%al
    9964:	74 96                	je     98fc <fwp_args23+0xc>
    9966:	8b 15 7c 0b 06 00    	mov    0x60b7c(%rip),%edx        # 6a4e8 <iteration_active>
    996c:	85 d2                	test   %edx,%edx
    996e:	75 10                	jne    9980 <fwp_args23+0x90>
    9970:	3c fd                	cmp    $0xfd,%al
    9972:	77 22                	ja     9996 <fwp_args23+0xa6>
    9974:	83 c0 01             	add    $0x1,%eax
    9977:	88 07                	mov    %al,(%rdi)
    9979:	c3                   	ret
    997a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9980:	48 83 05 48 0b 06 00 	addq   $0x1,0x60b48(%rip)        # 6a4d0 <iteration_retains>
    9987:	01 
    9988:	eb e6                	jmp    9970 <fwp_args23+0x80>
    998a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9990:	66 85 c0             	test   %ax,%ax
    9993:	74 ca                	je     995f <fwp_args23+0x6f>
    9995:	c3                   	ret
    9996:	e9 15 bd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    999b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000099a0 <fwp_caps12>:
    99a0:	f3 0f 1e fa          	endbr64
    99a4:	48 83 ec 18          	sub    $0x18,%rsp
    99a8:	48 89 f8             	mov    %rdi,%rax
    99ab:	8b 7f 04             	mov    0x4(%rdi),%edi
    99ae:	85 ff                	test   %edi,%edi
    99b0:	0f 84 9a 00 00 00    	je     9a50 <fwp_caps12+0xb0>
    99b6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    99ba:	85 f6                	test   %esi,%esi
    99bc:	0f 85 9e 00 00 00    	jne    9a60 <fwp_caps12+0xc0>
    99c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    99c7:	e8 14 d4 ff ff       	call   6de0 <fwp_drop0>
    99cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    99d1:	48 8b 0d 20 02 06 00 	mov    0x60220(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    99d8:	48 89 c2             	mov    %rax,%rdx
    99db:	48 2b 15 ee 01 06 00 	sub    0x601ee(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    99e2:	48 c1 e1 10          	shl    $0x10,%rcx
    99e6:	48 39 ca             	cmp    %rcx,%rdx
    99e9:	73 6d                	jae    9a58 <fwp_caps12+0xb8>
    99eb:	48 89 d1             	mov    %rdx,%rcx
    99ee:	48 c1 e9 10          	shr    $0x10,%rcx
    99f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    99f6:	48 8b 0d 1b 02 06 00 	mov    0x6021b(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    99fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9a01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9a05:	48 85 f6             	test   %rsi,%rsi
    9a08:	74 4e                	je     9a58 <fwp_caps12+0xb8>
    9a0a:	0f b6 39             	movzbl (%rcx),%edi
    9a0d:	40 80 ff 02          	cmp    $0x2,%dil
    9a11:	0f 84 c9 00 00 00    	je     9ae0 <fwp_caps12+0x140>
    9a17:	40 80 ff 01          	cmp    $0x1,%dil
    9a1b:	75 3b                	jne    9a58 <fwp_caps12+0xb8>
    9a1d:	8b 79 18             	mov    0x18(%rcx),%edi
    9a20:	0f b7 d2             	movzwl %dx,%edx
    9a23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9a26:	48 0f af d7          	imul   %rdi,%rdx
    9a2a:	48 c1 ea 20          	shr    $0x20,%rdx
    9a2e:	48 39 ca             	cmp    %rcx,%rdx
    9a31:	73 25                	jae    9a58 <fwp_caps12+0xb8>
    9a33:	48 01 d6             	add    %rdx,%rsi
    9a36:	80 3e 01             	cmpb   $0x1,(%rsi)
    9a39:	75 1d                	jne    9a58 <fwp_caps12+0xb8>
    9a3b:	48 89 c7             	mov    %rax,%rdi
    9a3e:	48 83 c4 18          	add    $0x18,%rsp
    9a42:	e9 c9 bf ff ff       	jmp    5a10 <fwp_mem_free>
    9a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a4e:	00 00 
    9a50:	85 f6                	test   %esi,%esi
    9a52:	0f 84 79 ff ff ff    	je     99d1 <fwp_caps12+0x31>
    9a58:	48 83 c4 18          	add    $0x18,%rsp
    9a5c:	c3                   	ret
    9a5d:	0f 1f 00             	nopl   (%rax)
    9a60:	48 8b 05 91 01 06 00 	mov    0x60191(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    9a67:	48 2b 3d 62 01 06 00 	sub    0x60162(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    9a6e:	48 c1 e0 10          	shl    $0x10,%rax
    9a72:	48 39 c7             	cmp    %rax,%rdi
    9a75:	73 e1                	jae    9a58 <fwp_caps12+0xb8>
    9a77:	48 89 f8             	mov    %rdi,%rax
    9a7a:	48 c1 e8 10          	shr    $0x10,%rax
    9a7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9a82:	48 8b 05 8f 01 06 00 	mov    0x6018f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    9a89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9a8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9a91:	48 85 c0             	test   %rax,%rax
    9a94:	74 c2                	je     9a58 <fwp_caps12+0xb8>
    9a96:	0f b6 0a             	movzbl (%rdx),%ecx
    9a99:	80 f9 02             	cmp    $0x2,%cl
    9a9c:	74 52                	je     9af0 <fwp_caps12+0x150>
    9a9e:	80 f9 01             	cmp    $0x1,%cl
    9aa1:	75 b5                	jne    9a58 <fwp_caps12+0xb8>
    9aa3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9aa6:	0f b7 ff             	movzwl %di,%edi
    9aa9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9aac:	48 0f af f9          	imul   %rcx,%rdi
    9ab0:	48 c1 ef 20          	shr    $0x20,%rdi
    9ab4:	48 39 d7             	cmp    %rdx,%rdi
    9ab7:	73 9f                	jae    9a58 <fwp_caps12+0xb8>
    9ab9:	48 01 f8             	add    %rdi,%rax
    9abc:	0f b6 10             	movzbl (%rax),%edx
    9abf:	84 d2                	test   %dl,%dl
    9ac1:	74 95                	je     9a58 <fwp_caps12+0xb8>
    9ac3:	8b 0d 1f 0a 06 00    	mov    0x60a1f(%rip),%ecx        # 6a4e8 <iteration_active>
    9ac9:	85 c9                	test   %ecx,%ecx
    9acb:	75 33                	jne    9b00 <fwp_caps12+0x160>
    9acd:	80 fa fd             	cmp    $0xfd,%dl
    9ad0:	77 38                	ja     9b0a <fwp_caps12+0x16a>
    9ad2:	83 c2 01             	add    $0x1,%edx
    9ad5:	88 10                	mov    %dl,(%rax)
    9ad7:	e9 7c ff ff ff       	jmp    9a58 <fwp_caps12+0xb8>
    9adc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ae0:	66 85 d2             	test   %dx,%dx
    9ae3:	0f 85 6f ff ff ff    	jne    9a58 <fwp_caps12+0xb8>
    9ae9:	e9 48 ff ff ff       	jmp    9a36 <fwp_caps12+0x96>
    9aee:	66 90                	xchg   %ax,%ax
    9af0:	66 85 ff             	test   %di,%di
    9af3:	0f 85 5f ff ff ff    	jne    9a58 <fwp_caps12+0xb8>
    9af9:	eb c1                	jmp    9abc <fwp_caps12+0x11c>
    9afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b00:	48 83 05 c8 09 06 00 	addq   $0x1,0x609c8(%rip)        # 6a4d0 <iteration_retains>
    9b07:	01 
    9b08:	eb c3                	jmp    9acd <fwp_caps12+0x12d>
    9b0a:	48 89 c7             	mov    %rax,%rdi
    9b0d:	48 83 c4 18          	add    $0x18,%rsp
    9b11:	e9 9a bb ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b1d:	00 00 00 

0000000000009b20 <fwp_caps23>:
    9b20:	f3 0f 1e fa          	endbr64
    9b24:	48 83 ec 18          	sub    $0x18,%rsp
    9b28:	48 89 f8             	mov    %rdi,%rax
    9b2b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9b2e:	85 ff                	test   %edi,%edi
    9b30:	0f 84 9a 00 00 00    	je     9bd0 <fwp_caps23+0xb0>
    9b36:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9b3a:	85 f6                	test   %esi,%esi
    9b3c:	0f 85 9e 00 00 00    	jne    9be0 <fwp_caps23+0xc0>
    9b42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9b47:	e8 14 f5 ff ff       	call   9060 <fwp_drop2>
    9b4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b51:	48 8b 0d a0 00 06 00 	mov    0x600a0(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    9b58:	48 89 c2             	mov    %rax,%rdx
    9b5b:	48 2b 15 6e 00 06 00 	sub    0x6006e(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    9b62:	48 c1 e1 10          	shl    $0x10,%rcx
    9b66:	48 39 ca             	cmp    %rcx,%rdx
    9b69:	73 6d                	jae    9bd8 <fwp_caps23+0xb8>
    9b6b:	48 89 d1             	mov    %rdx,%rcx
    9b6e:	48 c1 e9 10          	shr    $0x10,%rcx
    9b72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9b76:	48 8b 0d 9b 00 06 00 	mov    0x6009b(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    9b7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9b81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9b85:	48 85 f6             	test   %rsi,%rsi
    9b88:	74 4e                	je     9bd8 <fwp_caps23+0xb8>
    9b8a:	0f b6 39             	movzbl (%rcx),%edi
    9b8d:	40 80 ff 02          	cmp    $0x2,%dil
    9b91:	0f 84 c9 00 00 00    	je     9c60 <fwp_caps23+0x140>
    9b97:	40 80 ff 01          	cmp    $0x1,%dil
    9b9b:	75 3b                	jne    9bd8 <fwp_caps23+0xb8>
    9b9d:	8b 79 18             	mov    0x18(%rcx),%edi
    9ba0:	0f b7 d2             	movzwl %dx,%edx
    9ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9ba6:	48 0f af d7          	imul   %rdi,%rdx
    9baa:	48 c1 ea 20          	shr    $0x20,%rdx
    9bae:	48 39 ca             	cmp    %rcx,%rdx
    9bb1:	73 25                	jae    9bd8 <fwp_caps23+0xb8>
    9bb3:	48 01 d6             	add    %rdx,%rsi
    9bb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    9bb9:	75 1d                	jne    9bd8 <fwp_caps23+0xb8>
    9bbb:	48 89 c7             	mov    %rax,%rdi
    9bbe:	48 83 c4 18          	add    $0x18,%rsp
    9bc2:	e9 49 be ff ff       	jmp    5a10 <fwp_mem_free>
    9bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bce:	00 00 
    9bd0:	85 f6                	test   %esi,%esi
    9bd2:	0f 84 79 ff ff ff    	je     9b51 <fwp_caps23+0x31>
    9bd8:	48 83 c4 18          	add    $0x18,%rsp
    9bdc:	c3                   	ret
    9bdd:	0f 1f 00             	nopl   (%rax)
    9be0:	48 8b 05 11 00 06 00 	mov    0x60011(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    9be7:	48 2b 3d e2 ff 05 00 	sub    0x5ffe2(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    9bee:	48 c1 e0 10          	shl    $0x10,%rax
    9bf2:	48 39 c7             	cmp    %rax,%rdi
    9bf5:	73 e1                	jae    9bd8 <fwp_caps23+0xb8>
    9bf7:	48 89 f8             	mov    %rdi,%rax
    9bfa:	48 c1 e8 10          	shr    $0x10,%rax
    9bfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9c02:	48 8b 05 0f 00 06 00 	mov    0x6000f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    9c09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9c0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9c11:	48 85 c0             	test   %rax,%rax
    9c14:	74 c2                	je     9bd8 <fwp_caps23+0xb8>
    9c16:	0f b6 0a             	movzbl (%rdx),%ecx
    9c19:	80 f9 02             	cmp    $0x2,%cl
    9c1c:	74 52                	je     9c70 <fwp_caps23+0x150>
    9c1e:	80 f9 01             	cmp    $0x1,%cl
    9c21:	75 b5                	jne    9bd8 <fwp_caps23+0xb8>
    9c23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c26:	0f b7 ff             	movzwl %di,%edi
    9c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c2c:	48 0f af f9          	imul   %rcx,%rdi
    9c30:	48 c1 ef 20          	shr    $0x20,%rdi
    9c34:	48 39 d7             	cmp    %rdx,%rdi
    9c37:	73 9f                	jae    9bd8 <fwp_caps23+0xb8>
    9c39:	48 01 f8             	add    %rdi,%rax
    9c3c:	0f b6 10             	movzbl (%rax),%edx
    9c3f:	84 d2                	test   %dl,%dl
    9c41:	74 95                	je     9bd8 <fwp_caps23+0xb8>
    9c43:	8b 0d 9f 08 06 00    	mov    0x6089f(%rip),%ecx        # 6a4e8 <iteration_active>
    9c49:	85 c9                	test   %ecx,%ecx
    9c4b:	75 33                	jne    9c80 <fwp_caps23+0x160>
    9c4d:	80 fa fd             	cmp    $0xfd,%dl
    9c50:	77 38                	ja     9c8a <fwp_caps23+0x16a>
    9c52:	83 c2 01             	add    $0x1,%edx
    9c55:	88 10                	mov    %dl,(%rax)
    9c57:	e9 7c ff ff ff       	jmp    9bd8 <fwp_caps23+0xb8>
    9c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c60:	66 85 d2             	test   %dx,%dx
    9c63:	0f 85 6f ff ff ff    	jne    9bd8 <fwp_caps23+0xb8>
    9c69:	e9 48 ff ff ff       	jmp    9bb6 <fwp_caps23+0x96>
    9c6e:	66 90                	xchg   %ax,%ax
    9c70:	66 85 ff             	test   %di,%di
    9c73:	0f 85 5f ff ff ff    	jne    9bd8 <fwp_caps23+0xb8>
    9c79:	eb c1                	jmp    9c3c <fwp_caps23+0x11c>
    9c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c80:	48 83 05 48 08 06 00 	addq   $0x1,0x60848(%rip)        # 6a4d0 <iteration_retains>
    9c87:	01 
    9c88:	eb c3                	jmp    9c4d <fwp_caps23+0x12d>
    9c8a:	48 89 c7             	mov    %rax,%rdi
    9c8d:	48 83 c4 18          	add    $0x18,%rsp
    9c91:	e9 1a ba ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c9d:	00 00 00 

0000000000009ca0 <fwp_write>:
    9ca0:	41 57                	push   %r15
    9ca2:	41 56                	push   %r14
    9ca4:	41 55                	push   %r13
    9ca6:	41 54                	push   %r12
    9ca8:	55                   	push   %rbp
    9ca9:	53                   	push   %rbx
    9caa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9cb1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9cb8:	00 00 
    9cba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9cc1:	00 
    9cc2:	49 89 d4             	mov    %rdx,%r12
    9cc5:	8b 12                	mov    (%rdx),%edx
    9cc7:	83 fa 19             	cmp    $0x19,%edx
    9cca:	77 6a                	ja     9d36 <fwp_write+0x96>
    9ccc:	48 89 f5             	mov    %rsi,%rbp
    9ccf:	89 d0                	mov    %edx,%eax
    9cd1:	89 ce                	mov    %ecx,%esi
    9cd3:	48 89 fb             	mov    %rdi,%rbx
    9cd6:	48 8d 0d e3 2f 00 00 	lea    0x2fe3(%rip),%rcx        # ccc0 <_IO_stdin_used+0xcc0>
    9cdd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9ce1:	48 01 c8             	add    %rcx,%rax
    9ce4:	3e ff e0             	notrack jmp *%rax
    9ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cee:	00 00 
    9cf0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9cf4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9cf8:	48 89 ca             	mov    %rcx,%rdx
    9cfb:	48 85 c9             	test   %rcx,%rcx
    9cfe:	0f 88 9c 0c 00 00    	js     a9a0 <fwp_write+0xd00>
    9d04:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9d0b:	00 
    9d0c:	48 89 c6             	mov    %rax,%rsi
    9d0f:	4c 89 e7             	mov    %r12,%rdi
    9d12:	e8 29 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d1e:	00 00 
    9d20:	4c 89 e7             	mov    %r12,%rdi
    9d23:	e8 18 97 ff ff       	call   3440 <strlen@plt>
    9d28:	4c 89 e6             	mov    %r12,%rsi
    9d2b:	48 89 df             	mov    %rbx,%rdi
    9d2e:	48 89 c2             	mov    %rax,%rdx
    9d31:	e8 ba a3 ff ff       	call   40f0 <buf_put>
    9d36:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d3d:	00 
    9d3e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d45:	00 00 
    9d47:	0f 85 28 04 00 00    	jne    a175 <fwp_write+0x4d5>
    9d4d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9d54:	5b                   	pop    %rbx
    9d55:	5d                   	pop    %rbp
    9d56:	41 5c                	pop    %r12
    9d58:	41 5d                	pop    %r13
    9d5a:	41 5e                	pop    %r14
    9d5c:	41 5f                	pop    %r15
    9d5e:	c3                   	ret
    9d5f:	90                   	nop
    9d60:	49 89 e9             	mov    %rbp,%r9
    9d63:	4c 8d 05 f1 24 00 00 	lea    0x24f1(%rip),%r8        # c25b <_IO_stdin_used+0x25b>
    9d6a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9d6f:	ba 02 00 00 00       	mov    $0x2,%edx
    9d74:	be 00 02 00 00       	mov    $0x200,%esi
    9d79:	31 c0                	xor    %eax,%eax
    9d7b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d82:	00 
    9d83:	e8 18 96 ff ff       	call   33a0 <__snprintf_chk@plt>
    9d88:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d8f:	00 
    9d90:	e8 ab 96 ff ff       	call   3440 <strlen@plt>
    9d95:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9d9c:	00 
    9d9d:	48 89 df             	mov    %rbx,%rdi
    9da0:	48 89 c2             	mov    %rax,%rdx
    9da3:	e8 48 a3 ff ff       	call   40f0 <buf_put>
    9da8:	eb 8c                	jmp    9d36 <fwp_write+0x96>
    9daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9db0:	49 89 e9             	mov    %rbp,%r9
    9db3:	4c 8d 05 9c 24 00 00 	lea    0x249c(%rip),%r8        # c256 <_IO_stdin_used+0x256>
    9dba:	eb ae                	jmp    9d6a <fwp_write+0xca>
    9dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9dc0:	83 fa 13             	cmp    $0x13,%edx
    9dc3:	48 8d 05 82 24 00 00 	lea    0x2482(%rip),%rax        # c24c <_IO_stdin_used+0x24c>
    9dca:	48 8d 35 80 24 00 00 	lea    0x2480(%rip),%rsi        # c251 <_IO_stdin_used+0x251>
    9dd1:	ba 04 00 00 00       	mov    $0x4,%edx
    9dd6:	48 0f 44 f0          	cmove  %rax,%rsi
    9dda:	45 31 ed             	xor    %r13d,%r13d
    9ddd:	e8 0e a3 ff ff       	call   40f0 <buf_put>
    9de2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9de7:	0f 84 a3 08 00 00    	je     a690 <fwp_write+0x9f0>
    9ded:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9df2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9df7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9dfc:	48 89 df             	mov    %rbx,%rdi
    9dff:	49 0f 44 c5          	cmove  %r13,%rax
    9e03:	31 c9                	xor    %ecx,%ecx
    9e05:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9e0a:	e8 91 fe ff ff       	call   9ca0 <fwp_write>
    9e0f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9e14:	0f 84 6e 09 00 00    	je     a788 <fwp_write+0xae8>
    9e1a:	49 83 c5 01          	add    $0x1,%r13
    9e1e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e22:	0f 83 68 08 00 00    	jae    a690 <fwp_write+0x9f0>
    9e28:	ba 02 00 00 00       	mov    $0x2,%edx
    9e2d:	48 8d 35 67 24 00 00 	lea    0x2467(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    9e34:	48 89 df             	mov    %rbx,%rdi
    9e37:	e8 b4 a2 ff ff       	call   40f0 <buf_put>
    9e3c:	eb af                	jmp    9ded <fwp_write+0x14d>
    9e3e:	66 90                	xchg   %ax,%ax
    9e40:	ba 06 00 00 00       	mov    $0x6,%edx
    9e45:	48 8d 35 28 24 00 00 	lea    0x2428(%rip),%rsi        # c274 <_IO_stdin_used+0x274>
    9e4c:	48 83 c5 10          	add    $0x10,%rbp
    9e50:	e8 9b a2 ff ff       	call   40f0 <buf_put>
    9e55:	48 89 ef             	mov    %rbp,%rdi
    9e58:	e8 e3 95 ff ff       	call   3440 <strlen@plt>
    9e5d:	48 89 ee             	mov    %rbp,%rsi
    9e60:	48 89 df             	mov    %rbx,%rdi
    9e63:	48 89 c2             	mov    %rax,%rdx
    9e66:	e8 85 a2 ff ff       	call   40f0 <buf_put>
    9e6b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9e70:	ba 01 00 00 00       	mov    $0x1,%edx
    9e75:	48 89 df             	mov    %rbx,%rdi
    9e78:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e7d:	e8 6e a2 ff ff       	call   40f0 <buf_put>
    9e82:	e9 af fe ff ff       	jmp    9d36 <fwp_write+0x96>
    9e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e8e:	00 00 
    9e90:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e97:	00 
    9e98:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e9f:	00 00 
    9ea1:	0f 85 ce 02 00 00    	jne    a175 <fwp_write+0x4d5>
    9ea7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9eac:	48 8d 35 ad 23 00 00 	lea    0x23ad(%rip),%rsi        # c260 <_IO_stdin_used+0x260>
    9eb3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9eba:	48 89 df             	mov    %rbx,%rdi
    9ebd:	5b                   	pop    %rbx
    9ebe:	5d                   	pop    %rbp
    9ebf:	41 5c                	pop    %r12
    9ec1:	41 5d                	pop    %r13
    9ec3:	41 5e                	pop    %r14
    9ec5:	41 5f                	pop    %r15
    9ec7:	e9 24 a2 ff ff       	jmp    40f0 <buf_put>
    9ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ed0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9ed5:	4d 85 ed             	test   %r13,%r13
    9ed8:	0f 84 02 0c 00 00    	je     aae0 <fwp_write+0xe40>
    9ede:	48 8d 35 c3 23 00 00 	lea    0x23c3(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    9ee5:	4c 89 ef             	mov    %r13,%rdi
    9ee8:	e8 33 96 ff ff       	call   3520 <strcmp@plt>
    9eed:	41 89 c1             	mov    %eax,%r9d
    9ef0:	85 c0                	test   %eax,%eax
    9ef2:	0f 84 6c 0c 00 00    	je     ab64 <fwp_write+0xec4>
    9ef8:	4c 89 ef             	mov    %r13,%rdi
    9efb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9f00:	e8 3b 95 ff ff       	call   3440 <strlen@plt>
    9f05:	4c 89 ee             	mov    %r13,%rsi
    9f08:	48 89 df             	mov    %rbx,%rdi
    9f0b:	48 89 c2             	mov    %rax,%rdx
    9f0e:	e8 dd a1 ff ff       	call   40f0 <buf_put>
    9f13:	ba 01 00 00 00       	mov    $0x1,%edx
    9f18:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f1d:	48 89 df             	mov    %rbx,%rdi
    9f20:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f25:	e8 c6 a1 ff ff       	call   40f0 <buf_put>
    9f2a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f2f:	4c 89 fe             	mov    %r15,%rsi
    9f32:	48 89 df             	mov    %rbx,%rdi
    9f35:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f3a:	e8 b1 a1 ff ff       	call   40f0 <buf_put>
    9f3f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f44:	45 31 f6             	xor    %r14d,%r14d
    9f47:	85 d2                	test   %edx,%edx
    9f49:	0f 8e 81 0a 00 00    	jle    a9d0 <fwp_write+0xd30>
    9f4f:	45 31 ed             	xor    %r13d,%r13d
    9f52:	4d 85 ed             	test   %r13,%r13
    9f55:	0f 85 75 07 00 00    	jne    a6d0 <fwp_write+0xa30>
    9f5b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9f62:	00 
    9f63:	45 85 f6             	test   %r14d,%r14d
    9f66:	0f 84 84 07 00 00    	je     a6f0 <fwp_write+0xa50>
    9f6c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9f71:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9f76:	48 89 df             	mov    %rbx,%rdi
    9f79:	49 83 c5 01          	add    $0x1,%r13
    9f7d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9f81:	31 c9                	xor    %ecx,%ecx
    9f83:	e8 18 fd ff ff       	call   9ca0 <fwp_write>
    9f88:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9f8d:	7f c3                	jg     9f52 <fwp_write+0x2b2>
    9f8f:	45 85 f6             	test   %r14d,%r14d
    9f92:	0f 84 38 0a 00 00    	je     a9d0 <fwp_write+0xd30>
    9f98:	b8 29 00 00 00       	mov    $0x29,%eax
    9f9d:	ba 01 00 00 00       	mov    $0x1,%edx
    9fa2:	4c 89 fe             	mov    %r15,%rsi
    9fa5:	48 89 df             	mov    %rbx,%rdi
    9fa8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9fac:	e8 3f a1 ff ff       	call   40f0 <buf_put>
    9fb1:	e9 80 fd ff ff       	jmp    9d36 <fwp_write+0x96>
    9fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fbd:	00 00 00 
    9fc0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fc5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9fcf:	e8 1c a1 ff ff       	call   40f0 <buf_put>
    9fd4:	48 85 ed             	test   %rbp,%rbp
    9fd7:	0f 84 93 06 00 00    	je     a670 <fwp_write+0x9d0>
    9fdd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9fe1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fe6:	31 c9                	xor    %ecx,%ecx
    9fe8:	48 89 df             	mov    %rbx,%rdi
    9feb:	e8 b0 fc ff ff       	call   9ca0 <fwp_write>
    9ff0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9ff4:	48 85 ed             	test   %rbp,%rbp
    9ff7:	0f 84 73 06 00 00    	je     a670 <fwp_write+0x9d0>
    9ffd:	ba 02 00 00 00       	mov    $0x2,%edx
    a002:	48 8d 35 92 22 00 00 	lea    0x2292(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a009:	48 89 df             	mov    %rbx,%rdi
    a00c:	e8 df a0 ff ff       	call   40f0 <buf_put>
    a011:	eb ca                	jmp    9fdd <fwp_write+0x33d>
    a013:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a018:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a01c:	85 f6                	test   %esi,%esi
    a01e:	0f 84 fc 07 00 00    	je     a820 <fwp_write+0xb80>
    a024:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a02b:	00 
    a02c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a033:	00 00 
    a035:	0f 85 3a 01 00 00    	jne    a175 <fwp_write+0x4d5>
    a03b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a03f:	4c 89 ea             	mov    %r13,%rdx
    a042:	e9 6c fe ff ff       	jmp    9eb3 <fwp_write+0x213>
    a047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a04e:	00 00 
    a050:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a055:	ba 01 00 00 00       	mov    $0x1,%edx
    a05a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a05f:	48 89 ee             	mov    %rbp,%rsi
    a062:	e8 89 a0 ff ff       	call   40f0 <buf_put>
    a067:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a06c:	4c 89 e7             	mov    %r12,%rdi
    a06f:	e8 cc 93 ff ff       	call   3440 <strlen@plt>
    a074:	4c 89 e6             	mov    %r12,%rsi
    a077:	48 89 df             	mov    %rbx,%rdi
    a07a:	48 89 c2             	mov    %rax,%rdx
    a07d:	e8 6e a0 ff ff       	call   40f0 <buf_put>
    a082:	ba 01 00 00 00       	mov    $0x1,%edx
    a087:	48 89 ee             	mov    %rbp,%rsi
    a08a:	48 89 df             	mov    %rbx,%rdi
    a08d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a092:	e8 59 a0 ff ff       	call   40f0 <buf_put>
    a097:	e9 9a fc ff ff       	jmp    9d36 <fwp_write+0x96>
    a09c:	0f 1f 40 00          	nopl   0x0(%rax)
    a0a0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a0a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a0a9:	0f 8a 8e 0b 00 00    	jp     ac3d <fwp_write+0xf9d>
    a0af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0b3:	66 0f 54 05 05 2d 00 	andpd  0x2d05(%rip),%xmm0        # cdc0 <msg.4+0x90>
    a0ba:	00 
    a0bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a0c0:	66 0f 2e 05 30 2d 00 	ucomisd 0x2d30(%rip),%xmm0        # cdf8 <msg.4+0xc8>
    a0c7:	00 
    a0c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a0cf:	00 
    a0d0:	0f 87 b2 09 00 00    	ja     aa88 <fwp_write+0xde8>
    a0d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0dd:	00 00 00 
    a0e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0e4:	89 ee                	mov    %ebp,%esi
    a0e6:	4c 89 e7             	mov    %r12,%rdi
    a0e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a0ee:	e8 7d a6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a0f3:	31 f6                	xor    %esi,%esi
    a0f5:	4c 89 e7             	mov    %r12,%rdi
    a0f8:	e8 03 93 ff ff       	call   3400 <strtod@plt>
    a0fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a102:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a106:	7a 06                	jp     a10e <fwp_write+0x46e>
    a108:	0f 84 e9 01 00 00    	je     a2f7 <fwp_write+0x657>
    a10e:	83 c5 01             	add    $0x1,%ebp
    a111:	83 fd 12             	cmp    $0x12,%ebp
    a114:	75 ca                	jne    a0e0 <fwp_write+0x440>
    a116:	be 11 00 00 00       	mov    $0x11,%esi
    a11b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a11f:	4c 89 e7             	mov    %r12,%rdi
    a122:	e8 49 a6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a127:	e9 cb 01 00 00       	jmp    a2f7 <fwp_write+0x657>
    a12c:	0f 1f 40 00          	nopl   0x0(%rax)
    a130:	48 83 fd 01          	cmp    $0x1,%rbp
    a134:	0f 84 e6 08 00 00    	je     aa20 <fwp_write+0xd80>
    a13a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a13e:	b8 02 00 00 00       	mov    $0x2,%eax
    a143:	ba 01 00 00 00       	mov    $0x1,%edx
    a148:	48 0f 44 d0          	cmove  %rax,%rdx
    a14c:	48 8d 35 f1 20 00 00 	lea    0x20f1(%rip),%rsi        # c244 <_IO_stdin_used+0x244>
    a153:	48 8d 05 ef 20 00 00 	lea    0x20ef(%rip),%rax        # c249 <_IO_stdin_used+0x249>
    a15a:	48 0f 44 f0          	cmove  %rax,%rsi
    a15e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a165:	00 
    a166:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a16d:	00 00 
    a16f:	0f 84 3e fd ff ff    	je     9eb3 <fwp_write+0x213>
    a175:	e8 d6 92 ff ff       	call   3450 <__stack_chk_fail@plt>
    a17a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a180:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a185:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a18a:	e8 a1 9e ff ff       	call   4030 <buf_grow>
    a18f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a193:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a199:	4c 03 0b             	add    (%rbx),%r9
    a19c:	66 45 89 11          	mov    %r10w,(%r9)
    a1a0:	45 85 e4             	test   %r12d,%r12d
    a1a3:	0f 8e 07 05 00 00    	jle    a6b0 <fwp_write+0xa10>
    a1a9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a1b0:	55 55 55 
    a1b3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a1b8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a1bf:	aa aa aa 
    a1c2:	49 83 c1 01          	add    $0x1,%r9
    a1c6:	eb 45                	jmp    a20d <fwp_write+0x56d>
    a1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1cf:	00 
    a1d0:	be 01 00 00 00       	mov    $0x1,%esi
    a1d5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a1da:	88 07                	mov    %al,(%rdi)
    a1dc:	48 89 e8             	mov    %rbp,%rax
    a1df:	49 f7 e8             	imul   %r8
    a1e2:	48 89 e8             	mov    %rbp,%rax
    a1e5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a1e9:	48 29 c2             	sub    %rax,%rdx
    a1ec:	48 85 c9             	test   %rcx,%rcx
    a1ef:	0f 95 c0             	setne  %al
    a1f2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a1f6:	48 83 ef 01          	sub    $0x1,%rdi
    a1fa:	48 21 c5             	and    %rax,%rbp
    a1fd:	48 29 ea             	sub    %rbp,%rdx
    a200:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a204:	49 39 f9             	cmp    %rdi,%r9
    a207:	0f 84 a3 04 00 00    	je     a6b0 <fwp_write+0xa10>
    a20d:	48 89 e8             	mov    %rbp,%rax
    a210:	49 f7 e8             	imul   %r8
    a213:	48 89 e8             	mov    %rbp,%rax
    a216:	48 c1 f8 3f          	sar    $0x3f,%rax
    a21a:	48 89 d1             	mov    %rdx,%rcx
    a21d:	48 29 c1             	sub    %rax,%rcx
    a220:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a224:	48 89 e9             	mov    %rbp,%rcx
    a227:	48 29 c1             	sub    %rax,%rcx
    a22a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a22e:	49 f7 e2             	mul    %r10
    a231:	b8 30 00 00 00       	mov    $0x30,%eax
    a236:	48 89 d6             	mov    %rdx,%rsi
    a239:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a23d:	48 d1 ee             	shr    $1,%rsi
    a240:	48 01 f2             	add    %rsi,%rdx
    a243:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a247:	48 29 d6             	sub    %rdx,%rsi
    a24a:	74 8e                	je     a1da <fwp_write+0x53a>
    a24c:	48 83 fe 01          	cmp    $0x1,%rsi
    a250:	0f 85 7a ff ff ff    	jne    a1d0 <fwp_write+0x530>
    a256:	31 f6                	xor    %esi,%esi
    a258:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a25d:	e9 78 ff ff ff       	jmp    a1da <fwp_write+0x53a>
    a262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a268:	66 0f 6e cd          	movd   %ebp,%xmm1
    a26c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a26f:	0f 8a c8 09 00 00    	jp     ac3d <fwp_write+0xf9d>
    a275:	0f 28 c1             	movaps %xmm1,%xmm0
    a278:	0f 54 05 31 2b 00 00 	andps  0x2b31(%rip),%xmm0        # cdb0 <msg.4+0x80>
    a27f:	0f 2e 05 7e 1d 00 00 	ucomiss 0x1d7e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a286:	0f 87 24 08 00 00    	ja     aab0 <fwp_write+0xe10>
    a28c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a290:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a296:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a29d:	00 
    a29e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a2a2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a2a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2ae:	00 00 
    a2b0:	44 89 ee             	mov    %r13d,%esi
    a2b3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2b8:	4c 89 e7             	mov    %r12,%rdi
    a2bb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a2c0:	e8 ab a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a2c5:	31 f6                	xor    %esi,%esi
    a2c7:	4c 89 e7             	mov    %r12,%rdi
    a2ca:	e8 d1 91 ff ff       	call   34a0 <strtof@plt>
    a2cf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a2d4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a2d7:	7a 02                	jp     a2db <fwp_write+0x63b>
    a2d9:	74 1c                	je     a2f7 <fwp_write+0x657>
    a2db:	41 83 c5 01          	add    $0x1,%r13d
    a2df:	41 83 fd 0a          	cmp    $0xa,%r13d
    a2e3:	75 cb                	jne    a2b0 <fwp_write+0x610>
    a2e5:	be 09 00 00 00       	mov    $0x9,%esi
    a2ea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2ef:	4c 89 e7             	mov    %r12,%rdi
    a2f2:	e8 79 a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a2f7:	4c 89 e7             	mov    %r12,%rdi
    a2fa:	e8 b1 9e ff ff       	call   41b0 <fwp_finish_float>
    a2ff:	e9 1c fa ff ff       	jmp    9d20 <fwp_write+0x80>
    a304:	0f 1f 40 00          	nopl   0x0(%rax)
    a308:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a30c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a310:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a317:	00 
    a318:	48 89 ef             	mov    %rbp,%rdi
    a31b:	e8 20 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a320:	48 89 ef             	mov    %rbp,%rdi
    a323:	e8 18 91 ff ff       	call   3440 <strlen@plt>
    a328:	48 89 ee             	mov    %rbp,%rsi
    a32b:	48 89 df             	mov    %rbx,%rdi
    a32e:	48 89 c2             	mov    %rax,%rdx
    a331:	e8 ba 9d ff ff       	call   40f0 <buf_put>
    a336:	e9 fb f9 ff ff       	jmp    9d36 <fwp_write+0x96>
    a33b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a340:	ba 06 00 00 00       	mov    $0x6,%edx
    a345:	48 8d 35 52 1f 00 00 	lea    0x1f52(%rip),%rsi        # c29e <_IO_stdin_used+0x29e>
    a34c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a352:	e8 99 9d ff ff       	call   40f0 <buf_put>
    a357:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a35e:	ff ff 7f 
    a361:	48 23 55 00          	and    0x0(%rbp),%rdx
    a365:	0f 84 86 02 00 00    	je     a5f1 <fwp_write+0x951>
    a36b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a370:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a374:	48 85 d2             	test   %rdx,%rdx
    a377:	0f 84 ae 00 00 00    	je     a42b <fwp_write+0x78b>
    a37d:	8b 0a                	mov    (%rdx),%ecx
    a37f:	83 f9 1c             	cmp    $0x1c,%ecx
    a382:	0f 84 58 06 00 00    	je     a9e0 <fwp_write+0xd40>
    a388:	83 f9 1b             	cmp    $0x1b,%ecx
    a38b:	0f 87 9a 00 00 00    	ja     a42b <fwp_write+0x78b>
    a391:	be 01 00 00 00       	mov    $0x1,%esi
    a396:	48 d3 e6             	shl    %cl,%rsi
    a399:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a39f:	0f 85 4b 04 00 00    	jne    a7f0 <fwp_write+0xb50>
    a3a5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a3ab:	0f 85 0f 04 00 00    	jne    a7c0 <fwp_write+0xb20>
    a3b1:	83 e6 21             	and    $0x21,%esi
    a3b4:	74 75                	je     a42b <fwp_write+0x78b>
    a3b6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a3bb:	48 85 ff             	test   %rdi,%rdi
    a3be:	79 07                	jns    a3c7 <fwp_write+0x727>
    a3c0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a3c4:	4c 01 ee             	add    %r13,%rsi
    a3c7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a3cb:	85 c9                	test   %ecx,%ecx
    a3cd:	40 0f b6 f7          	movzbl %dil,%esi
    a3d1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3dc:	00 00 00 00 
    a3e0:	31 c9                	xor    %ecx,%ecx
    a3e2:	48 89 df             	mov    %rbx,%rdi
    a3e5:	49 83 c5 01          	add    $0x1,%r13
    a3e9:	e8 b2 f8 ff ff       	call   9ca0 <fwp_write>
    a3ee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a3f5:	ff ff 7f 
    a3f8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3fc:	49 39 d5             	cmp    %rdx,%r13
    a3ff:	0f 83 ec 01 00 00    	jae    a5f1 <fwp_write+0x951>
    a405:	ba 02 00 00 00       	mov    $0x2,%edx
    a40a:	48 89 df             	mov    %rbx,%rdi
    a40d:	48 8d 35 87 1e 00 00 	lea    0x1e87(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a414:	e8 d7 9c ff ff       	call   40f0 <buf_put>
    a419:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a41e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a422:	48 85 d2             	test   %rdx,%rdx
    a425:	0f 85 52 ff ff ff    	jne    a37d <fwp_write+0x6dd>
    a42b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a430:	48 85 ff             	test   %rdi,%rdi
    a433:	0f 88 cf 05 00 00    	js     aa08 <fwp_write+0xd68>
    a439:	48 8b 31             	mov    (%rcx),%rsi
    a43c:	eb a2                	jmp    a3e0 <fwp_write+0x740>
    a43e:	66 90                	xchg   %ax,%ax
    a440:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a447:	00 
    a448:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a44f:	00 00 
    a451:	0f 85 1e fd ff ff    	jne    a175 <fwp_write+0x4d5>
    a457:	ba 08 00 00 00       	mov    $0x8,%edx
    a45c:	48 8d 35 08 1e 00 00 	lea    0x1e08(%rip),%rsi        # c26b <_IO_stdin_used+0x26b>
    a463:	e9 4b fa ff ff       	jmp    9eb3 <fwp_write+0x213>
    a468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a46f:	00 
    a470:	89 e8                	mov    %ebp,%eax
    a472:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a479:	76 03                	jbe    a47e <fwp_write+0x7de>
    a47b:	8b 45 00             	mov    0x0(%rbp),%eax
    a47e:	41 89 c6             	mov    %eax,%r14d
    a481:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a486:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a48b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a48f:	4c 89 ef             	mov    %r13,%rdi
    a492:	e8 a9 8f ff ff       	call   3440 <strlen@plt>
    a497:	4c 89 ee             	mov    %r13,%rsi
    a49a:	48 89 df             	mov    %rbx,%rdi
    a49d:	48 89 c2             	mov    %rax,%rdx
    a4a0:	e8 4b 9c ff ff       	call   40f0 <buf_put>
    a4a5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a4aa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a4ae:	85 f6                	test   %esi,%esi
    a4b0:	0f 8e 80 f8 ff ff    	jle    9d36 <fwp_write+0x96>
    a4b6:	45 31 ed             	xor    %r13d,%r13d
    a4b9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4be:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a4c3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a4c8:	ba 01 00 00 00       	mov    $0x1,%edx
    a4cd:	4c 89 fe             	mov    %r15,%rsi
    a4d0:	48 89 04 24          	mov    %rax,(%rsp)
    a4d4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a4d9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a4dd:	48 89 df             	mov    %rbx,%rdi
    a4e0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a4e4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a4e9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a4ee:	e8 fd 9b ff ff       	call   40f0 <buf_put>
    a4f3:	41 8b 06             	mov    (%r14),%eax
    a4f6:	83 f8 0e             	cmp    $0xe,%eax
    a4f9:	0f 84 71 02 00 00    	je     a770 <fwp_write+0xad0>
    a4ff:	83 f8 10             	cmp    $0x10,%eax
    a502:	0f 84 38 02 00 00    	je     a740 <fwp_write+0xaa0>
    a508:	83 f8 0a             	cmp    $0xa,%eax
    a50b:	0f 84 7f 04 00 00    	je     a990 <fwp_write+0xcf0>
    a511:	0f 8f f9 00 00 00    	jg     a610 <fwp_write+0x970>
    a517:	83 f8 03             	cmp    $0x3,%eax
    a51a:	0f 8f 50 04 00 00    	jg     a970 <fwp_write+0xcd0>
    a520:	85 c0                	test   %eax,%eax
    a522:	78 10                	js     a534 <fwp_write+0x894>
    a524:	48 8b 04 24          	mov    (%rsp),%rax
    a528:	48 c1 e8 3f          	shr    $0x3f,%rax
    a52c:	85 c0                	test   %eax,%eax
    a52e:	0f 85 f9 00 00 00    	jne    a62d <fwp_write+0x98d>
    a534:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a539:	48 8b 34 24          	mov    (%rsp),%rsi
    a53d:	31 c9                	xor    %ecx,%ecx
    a53f:	48 89 df             	mov    %rbx,%rdi
    a542:	e8 59 f7 ff ff       	call   9ca0 <fwp_write>
    a547:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a54c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a551:	49 83 c5 01          	add    $0x1,%r13
    a555:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a559:	0f 8f 5f ff ff ff    	jg     a4be <fwp_write+0x81e>
    a55f:	e9 d2 f7 ff ff       	jmp    9d36 <fwp_write+0x96>
    a564:	0f 1f 40 00          	nopl   0x0(%rax)
    a568:	ba 06 00 00 00       	mov    $0x6,%edx
    a56d:	48 8d 35 1d 1d 00 00 	lea    0x1d1d(%rip),%rsi        # c291 <_IO_stdin_used+0x291>
    a574:	45 31 ed             	xor    %r13d,%r13d
    a577:	e8 74 9b ff ff       	call   40f0 <buf_put>
    a57c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a581:	75 19                	jne    a59c <fwp_write+0x8fc>
    a583:	eb 6c                	jmp    a5f1 <fwp_write+0x951>
    a585:	0f 1f 00             	nopl   (%rax)
    a588:	ba 02 00 00 00       	mov    $0x2,%edx
    a58d:	48 8d 35 07 1d 00 00 	lea    0x1d07(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a594:	48 89 df             	mov    %rbx,%rdi
    a597:	e8 54 9b ff ff       	call   40f0 <buf_put>
    a59c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a5a2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a5a7:	31 c0                	xor    %eax,%eax
    a5a9:	49 83 c5 01          	add    $0x1,%r13
    a5ad:	4c 8d 05 e4 1c 00 00 	lea    0x1ce4(%rip),%r8        # c298 <_IO_stdin_used+0x298>
    a5b4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5b9:	be 00 02 00 00       	mov    $0x200,%esi
    a5be:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5c5:	00 
    a5c6:	e8 d5 8d ff ff       	call   33a0 <__snprintf_chk@plt>
    a5cb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5d2:	00 
    a5d3:	e8 68 8e ff ff       	call   3440 <strlen@plt>
    a5d8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a5df:	00 
    a5e0:	48 89 df             	mov    %rbx,%rdi
    a5e3:	48 89 c2             	mov    %rax,%rdx
    a5e6:	e8 05 9b ff ff       	call   40f0 <buf_put>
    a5eb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a5ef:	72 97                	jb     a588 <fwp_write+0x8e8>
    a5f1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5f6:	ba 01 00 00 00       	mov    $0x1,%edx
    a5fb:	48 89 df             	mov    %rbx,%rdi
    a5fe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a603:	e8 e8 9a ff ff       	call   40f0 <buf_put>
    a608:	e9 29 f7 ff ff       	jmp    9d36 <fwp_write+0x96>
    a60d:	0f 1f 00             	nopl   (%rax)
    a610:	83 f8 0b             	cmp    $0xb,%eax
    a613:	0f 85 1b ff ff ff    	jne    a534 <fwp_write+0x894>
    a619:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a61e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a622:	83 e0 01             	and    $0x1,%eax
    a625:	85 c0                	test   %eax,%eax
    a627:	0f 84 07 ff ff ff    	je     a534 <fwp_write+0x894>
    a62d:	4c 89 fe             	mov    %r15,%rsi
    a630:	48 89 df             	mov    %rbx,%rdi
    a633:	ba 01 00 00 00       	mov    $0x1,%edx
    a638:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a63d:	e8 ae 9a ff ff       	call   40f0 <buf_put>
    a642:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a647:	48 8b 34 24          	mov    (%rsp),%rsi
    a64b:	31 c9                	xor    %ecx,%ecx
    a64d:	48 89 df             	mov    %rbx,%rdi
    a650:	e8 4b f6 ff ff       	call   9ca0 <fwp_write>
    a655:	ba 01 00 00 00       	mov    $0x1,%edx
    a65a:	4c 89 fe             	mov    %r15,%rsi
    a65d:	48 89 df             	mov    %rbx,%rdi
    a660:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a665:	e8 86 9a ff ff       	call   40f0 <buf_put>
    a66a:	e9 d8 fe ff ff       	jmp    a547 <fwp_write+0x8a7>
    a66f:	90                   	nop
    a670:	ba 01 00 00 00       	mov    $0x1,%edx
    a675:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a67a:	48 89 df             	mov    %rbx,%rdi
    a67d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a682:	e8 69 9a ff ff       	call   40f0 <buf_put>
    a687:	e9 aa f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a68c:	0f 1f 40 00          	nopl   0x0(%rax)
    a690:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a695:	ba 01 00 00 00       	mov    $0x1,%edx
    a69a:	48 89 df             	mov    %rbx,%rdi
    a69d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a6a2:	e8 49 9a ff ff       	call   40f0 <buf_put>
    a6a7:	e9 8a f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a6ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a6b0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a6b4:	48 8b 13             	mov    (%rbx),%rdx
    a6b7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a6bc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a6c0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a6c4:	e9 6d f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a6c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6d5:	48 8d 35 bf 1b 00 00 	lea    0x1bbf(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a6dc:	48 89 df             	mov    %rbx,%rdi
    a6df:	e8 0c 9a ff ff       	call   40f0 <buf_put>
    a6e4:	e9 72 f8 ff ff       	jmp    9f5b <fwp_write+0x2bb>
    a6e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6f0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a6f5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a6fa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a6fe:	48 89 f7             	mov    %rsi,%rdi
    a701:	48 89 34 24          	mov    %rsi,(%rsp)
    a705:	e8 36 8d ff ff       	call   3440 <strlen@plt>
    a70a:	48 8b 34 24          	mov    (%rsp),%rsi
    a70e:	48 89 df             	mov    %rbx,%rdi
    a711:	48 89 c2             	mov    %rax,%rdx
    a714:	e8 d7 99 ff ff       	call   40f0 <buf_put>
    a719:	ba 03 00 00 00       	mov    $0x3,%edx
    a71e:	48 8d 35 99 1b 00 00 	lea    0x1b99(%rip),%rsi        # c2be <_IO_stdin_used+0x2be>
    a725:	48 89 df             	mov    %rbx,%rdi
    a728:	e8 c3 99 ff ff       	call   40f0 <buf_put>
    a72d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a732:	e9 35 f8 ff ff       	jmp    9f6c <fwp_write+0x2cc>
    a737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a73e:	00 00 
    a740:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a745:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a749:	48 85 ff             	test   %rdi,%rdi
    a74c:	0f 84 e2 fd ff ff    	je     a534 <fwp_write+0x894>
    a752:	48 8d 35 4f 1b 00 00 	lea    0x1b4f(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    a759:	e8 c2 8d ff ff       	call   3520 <strcmp@plt>
    a75e:	85 c0                	test   %eax,%eax
    a760:	0f 95 c0             	setne  %al
    a763:	0f b6 c0             	movzbl %al,%eax
    a766:	e9 c1 fd ff ff       	jmp    a52c <fwp_write+0x88c>
    a76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a770:	31 c0                	xor    %eax,%eax
    a772:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a779:	00 
    a77a:	0f 97 c0             	seta   %al
    a77d:	e9 aa fd ff ff       	jmp    a52c <fwp_write+0x88c>
    a782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a788:	48 89 df             	mov    %rbx,%rdi
    a78b:	ba 02 00 00 00       	mov    $0x2,%edx
    a790:	48 8d 35 0e 1b 00 00 	lea    0x1b0e(%rip),%rsi        # c2a5 <_IO_stdin_used+0x2a5>
    a797:	e8 54 99 ff ff       	call   40f0 <buf_put>
    a79c:	4c 89 e8             	mov    %r13,%rax
    a79f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a7a4:	31 c9                	xor    %ecx,%ecx
    a7a6:	48 c1 e0 04          	shl    $0x4,%rax
    a7aa:	48 89 df             	mov    %rbx,%rdi
    a7ad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a7b2:	e8 e9 f4 ff ff       	call   9ca0 <fwp_write>
    a7b7:	e9 5e f6 ff ff       	jmp    9e1a <fwp_write+0x17a>
    a7bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a7c0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a7c5:	48 85 ff             	test   %rdi,%rdi
    a7c8:	79 0c                	jns    a7d6 <fwp_write+0xb36>
    a7ca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a7d1:	00 
    a7d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a7d6:	48 63 3e             	movslq (%rsi),%rdi
    a7d9:	83 f9 02             	cmp    $0x2,%ecx
    a7dc:	89 fe                	mov    %edi,%esi
    a7de:	48 0f 44 f7          	cmove  %rdi,%rsi
    a7e2:	e9 f9 fb ff ff       	jmp    a3e0 <fwp_write+0x740>
    a7e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7ee:	00 00 
    a7f0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a7f5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a7fa:	48 85 ff             	test   %rdi,%rdi
    a7fd:	0f 88 0f 03 00 00    	js     ab12 <fwp_write+0xe72>
    a803:	49 0f bf 38          	movswq (%r8),%rdi
    a807:	83 f9 01             	cmp    $0x1,%ecx
    a80a:	0f b7 f7             	movzwl %di,%esi
    a80d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a811:	e9 ca fb ff ff       	jmp    a3e0 <fwp_write+0x740>
    a816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a81d:	00 00 00 
    a820:	ba 01 00 00 00       	mov    $0x1,%edx
    a825:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a82a:	48 83 c5 08          	add    $0x8,%rbp
    a82e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a833:	e8 b8 98 ff ff       	call   40f0 <buf_put>
    a838:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a83d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a842:	4d 85 ed             	test   %r13,%r13
    a845:	75 46                	jne    a88d <fwp_write+0xbed>
    a847:	e9 04 01 00 00       	jmp    a950 <fwp_write+0xcb0>
    a84c:	0f 1f 40 00          	nopl   0x0(%rax)
    a850:	41 80 f9 09          	cmp    $0x9,%r9b
    a854:	0f 84 d6 00 00 00    	je     a930 <fwp_write+0xc90>
    a85a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a85e:	0f 85 9c 00 00 00    	jne    a900 <fwp_write+0xc60>
    a864:	ba 02 00 00 00       	mov    $0x2,%edx
    a869:	48 8d 35 11 1a 00 00 	lea    0x1a11(%rip),%rsi        # c281 <_IO_stdin_used+0x281>
    a870:	48 89 df             	mov    %rbx,%rdi
    a873:	e8 78 98 ff ff       	call   40f0 <buf_put>
    a878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a87f:	00 
    a880:	48 83 c5 01          	add    $0x1,%rbp
    a884:	49 39 ec             	cmp    %rbp,%r12
    a887:	0f 84 c3 00 00 00    	je     a950 <fwp_write+0xcb0>
    a88d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a892:	41 80 f9 0d          	cmp    $0xd,%r9b
    a896:	74 28                	je     a8c0 <fwp_write+0xc20>
    a898:	7e b6                	jle    a850 <fwp_write+0xbb0>
    a89a:	41 80 f9 22          	cmp    $0x22,%r9b
    a89e:	74 40                	je     a8e0 <fwp_write+0xc40>
    a8a0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a8a4:	75 5a                	jne    a900 <fwp_write+0xc60>
    a8a6:	ba 02 00 00 00       	mov    $0x2,%edx
    a8ab:	48 8d 35 cc 19 00 00 	lea    0x19cc(%rip),%rsi        # c27e <_IO_stdin_used+0x27e>
    a8b2:	48 89 df             	mov    %rbx,%rdi
    a8b5:	e8 36 98 ff ff       	call   40f0 <buf_put>
    a8ba:	eb c4                	jmp    a880 <fwp_write+0xbe0>
    a8bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a8c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8c5:	48 8d 35 bb 19 00 00 	lea    0x19bb(%rip),%rsi        # c287 <_IO_stdin_used+0x287>
    a8cc:	48 89 df             	mov    %rbx,%rdi
    a8cf:	e8 1c 98 ff ff       	call   40f0 <buf_put>
    a8d4:	eb aa                	jmp    a880 <fwp_write+0xbe0>
    a8d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8dd:	00 00 00 
    a8e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8e5:	48 8d 35 8f 19 00 00 	lea    0x198f(%rip),%rsi        # c27b <_IO_stdin_used+0x27b>
    a8ec:	48 89 df             	mov    %rbx,%rdi
    a8ef:	e8 fc 97 ff ff       	call   40f0 <buf_put>
    a8f4:	eb 8a                	jmp    a880 <fwp_write+0xbe0>
    a8f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8fd:	00 00 00 
    a900:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a904:	0f 86 2e 01 00 00    	jbe    aa38 <fwp_write+0xd98>
    a90a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a90e:	0f 84 24 01 00 00    	je     aa38 <fwp_write+0xd98>
    a914:	ba 01 00 00 00       	mov    $0x1,%edx
    a919:	4c 89 fe             	mov    %r15,%rsi
    a91c:	48 89 df             	mov    %rbx,%rdi
    a91f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a924:	e8 c7 97 ff ff       	call   40f0 <buf_put>
    a929:	e9 52 ff ff ff       	jmp    a880 <fwp_write+0xbe0>
    a92e:	66 90                	xchg   %ax,%ax
    a930:	ba 02 00 00 00       	mov    $0x2,%edx
    a935:	48 8d 35 48 19 00 00 	lea    0x1948(%rip),%rsi        # c284 <_IO_stdin_used+0x284>
    a93c:	48 89 df             	mov    %rbx,%rdi
    a93f:	e8 ac 97 ff ff       	call   40f0 <buf_put>
    a944:	e9 37 ff ff ff       	jmp    a880 <fwp_write+0xbe0>
    a949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a950:	ba 01 00 00 00       	mov    $0x1,%edx
    a955:	4c 89 fe             	mov    %r15,%rsi
    a958:	48 89 df             	mov    %rbx,%rdi
    a95b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a960:	e8 8b 97 ff ff       	call   40f0 <buf_put>
    a965:	e9 cc f3 ff ff       	jmp    9d36 <fwp_write+0x96>
    a96a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a970:	83 f8 04             	cmp    $0x4,%eax
    a973:	0f 85 bb fb ff ff    	jne    a534 <fwp_write+0x894>
    a979:	48 8b 04 24          	mov    (%rsp),%rax
    a97d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a981:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a986:	48 c1 e8 3f          	shr    $0x3f,%rax
    a98a:	e9 96 fc ff ff       	jmp    a625 <fwp_write+0x985>
    a98f:	90                   	nop
    a990:	8b 0c 24             	mov    (%rsp),%ecx
    a993:	31 c0                	xor    %eax,%eax
    a995:	85 c9                	test   %ecx,%ecx
    a997:	0f 98 c0             	sets   %al
    a99a:	e9 86 fc ff ff       	jmp    a625 <fwp_write+0x985>
    a99f:	90                   	nop
    a9a0:	48 f7 d8             	neg    %rax
    a9a3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a9aa:	00 
    a9ab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a9b2:	2d 
    a9b3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9ba:	00 
    a9bb:	48 83 d2 00          	adc    $0x0,%rdx
    a9bf:	48 89 c6             	mov    %rax,%rsi
    a9c2:	48 f7 da             	neg    %rdx
    a9c5:	e8 76 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9ca:	e9 51 f3 ff ff       	jmp    9d20 <fwp_write+0x80>
    a9cf:	90                   	nop
    a9d0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a9d5:	e9 c3 f5 ff ff       	jmp    9f9d <fwp_write+0x2fd>
    a9da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9e0:	4c 89 e9             	mov    %r13,%rcx
    a9e3:	48 c1 e1 04          	shl    $0x4,%rcx
    a9e7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a9ec:	48 85 ff             	test   %rdi,%rdi
    a9ef:	0f 89 eb f9 ff ff    	jns    a3e0 <fwp_write+0x740>
    a9f5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a9f9:	48 89 ce             	mov    %rcx,%rsi
    a9fc:	e9 df f9 ff ff       	jmp    a3e0 <fwp_write+0x740>
    aa01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa08:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aa0f:	00 
    aa10:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa14:	e9 20 fa ff ff       	jmp    a439 <fwp_write+0x799>
    aa19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa20:	ba 02 00 00 00       	mov    $0x2,%edx
    aa25:	48 8d 35 1a 18 00 00 	lea    0x181a(%rip),%rsi        # c246 <_IO_stdin_used+0x246>
    aa2c:	e9 2d f7 ff ff       	jmp    a15e <fwp_write+0x4be>
    aa31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa38:	4c 8d 05 4b 18 00 00 	lea    0x184b(%rip),%r8        # c28a <_IO_stdin_used+0x28a>
    aa3f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa44:	31 c0                	xor    %eax,%eax
    aa46:	ba 02 00 00 00       	mov    $0x2,%edx
    aa4b:	be 10 00 00 00       	mov    $0x10,%esi
    aa50:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa57:	00 
    aa58:	e8 43 89 ff ff       	call   33a0 <__snprintf_chk@plt>
    aa5d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa64:	00 
    aa65:	e8 d6 89 ff ff       	call   3440 <strlen@plt>
    aa6a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aa71:	00 
    aa72:	48 89 df             	mov    %rbx,%rdi
    aa75:	48 89 c2             	mov    %rax,%rdx
    aa78:	e8 73 96 ff ff       	call   40f0 <buf_put>
    aa7d:	e9 fe fd ff ff       	jmp    a880 <fwp_write+0xbe0>
    aa82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa88:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa8c:	48 8d 35 ad 17 00 00 	lea    0x17ad(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    aa93:	48 8d 05 a5 17 00 00 	lea    0x17a5(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    aa9a:	4c 89 e7             	mov    %r12,%rdi
    aa9d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aaa1:	48 0f 46 f0          	cmovbe %rax,%rsi
    aaa5:	e8 36 89 ff ff       	call   33e0 <strcpy@plt>
    aaaa:	e9 71 f2 ff ff       	jmp    9d20 <fwp_write+0x80>
    aaaf:	90                   	nop
    aab0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aab4:	48 8d 35 85 17 00 00 	lea    0x1785(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    aabb:	48 8d 05 7d 17 00 00 	lea    0x177d(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    aac2:	0f 2f c8             	comiss %xmm0,%xmm1
    aac5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aacc:	00 
    aacd:	4c 89 e7             	mov    %r12,%rdi
    aad0:	48 0f 46 f0          	cmovbe %rax,%rsi
    aad4:	e8 07 89 ff ff       	call   33e0 <strcpy@plt>
    aad9:	e9 42 f2 ff ff       	jmp    9d20 <fwp_write+0x80>
    aade:	66 90                	xchg   %ax,%ax
    aae0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aae5:	45 85 c0             	test   %r8d,%r8d
    aae8:	75 34                	jne    ab1e <fwp_write+0xe7e>
    aaea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aaf1:	00 
    aaf2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aaf9:	00 00 
    aafb:	0f 85 74 f6 ff ff    	jne    a175 <fwp_write+0x4d5>
    ab01:	ba 02 00 00 00       	mov    $0x2,%edx
    ab06:	48 8d 35 ae 17 00 00 	lea    0x17ae(%rip),%rsi        # c2bb <_IO_stdin_used+0x2bb>
    ab0d:	e9 a1 f3 ff ff       	jmp    9eb3 <fwp_write+0x213>
    ab12:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab16:	49 89 f0             	mov    %rsi,%r8
    ab19:	e9 e5 fc ff ff       	jmp    a803 <fwp_write+0xb63>
    ab1e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab23:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab28:	85 ff                	test   %edi,%edi
    ab2a:	0f 84 fa f3 ff ff    	je     9f2a <fwp_write+0x28a>
    ab30:	ba 01 00 00 00       	mov    $0x1,%edx
    ab35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab3a:	48 89 df             	mov    %rbx,%rdi
    ab3d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab42:	e8 a9 95 ff ff       	call   40f0 <buf_put>
    ab47:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab4c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab51:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ab57:	85 c0                	test   %eax,%eax
    ab59:	0f 8f f0 f3 ff ff    	jg     9f4f <fwp_write+0x2af>
    ab5f:	e9 34 f4 ff ff       	jmp    9f98 <fwp_write+0x2f8>
    ab64:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab68:	49 89 c5             	mov    %rax,%r13
    ab6b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab70:	49 89 c4             	mov    %rax,%r12
    ab73:	49 c1 fd 3f          	sar    $0x3f,%r13
    ab77:	4c 09 e8             	or     %r13,%rax
    ab7a:	0f 84 a7 00 00 00    	je     ac27 <fwp_write+0xf87>
    ab80:	48 8d 2d 99 38 00 00 	lea    0x3899(%rip),%rbp        # e420 <units.1>
    ab87:	4d 89 e7             	mov    %r12,%r15
    ab8a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab8e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ab93:	4c 89 ff             	mov    %r15,%rdi
    ab96:	4c 89 ee             	mov    %r13,%rsi
    ab99:	44 89 0c 24          	mov    %r9d,(%rsp)
    ab9d:	48 99                	cqto
    ab9f:	48 89 d1             	mov    %rdx,%rcx
    aba2:	48 89 c2             	mov    %rax,%rdx
    aba5:	e8 16 10 00 00       	call   bbc0 <__divmodti4>
    abaa:	44 8b 0c 24          	mov    (%rsp),%r9d
    abae:	48 89 c1             	mov    %rax,%rcx
    abb1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    abb6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    abbb:	0f 84 94 00 00 00    	je     ac55 <fwp_write+0xfb5>
    abc1:	41 83 c1 01          	add    $0x1,%r9d
    abc5:	48 83 c5 10          	add    $0x10,%rbp
    abc9:	41 83 f9 05          	cmp    $0x5,%r9d
    abcd:	75 bb                	jne    ab8a <fwp_write+0xeea>
    abcf:	4d 85 ed             	test   %r13,%r13
    abd2:	79 53                	jns    ac27 <fwp_write+0xf87>
    abd4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    abd9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    abde:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    abe3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    abe8:	48 99                	cqto
    abea:	48 f7 d8             	neg    %rax
    abed:	48 83 d2 00          	adc    $0x0,%rdx
    abf1:	48 89 c6             	mov    %rax,%rsi
    abf4:	48 f7 da             	neg    %rdx
    abf7:	e8 44 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abfc:	49 89 e8             	mov    %rbp,%r8
    abff:	ba 00 02 00 00       	mov    $0x200,%edx
    ac04:	be 02 00 00 00       	mov    $0x2,%esi
    ac09:	31 c0                	xor    %eax,%eax
    ac0b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac12:	00 
    ac13:	48 8d 0d 9c 16 00 00 	lea    0x169c(%rip),%rcx        # c2b6 <_IO_stdin_used+0x2b6>
    ac1a:	4c 89 e7             	mov    %r12,%rdi
    ac1d:	e8 9e 8a ff ff       	call   36c0 <__sprintf_chk@plt>
    ac22:	e9 f9 f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    ac27:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac2c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac31:	31 d2                	xor    %edx,%edx
    ac33:	48 89 ef             	mov    %rbp,%rdi
    ac36:	e8 05 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac3b:	eb bf                	jmp    abfc <fwp_write+0xf5c>
    ac3d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac44:	4e 61 4e 00 
    ac48:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac4f:	00 
    ac50:	e9 cb f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    ac55:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac59:	48 89 c8             	mov    %rcx,%rax
    ac5c:	48 85 d2             	test   %rdx,%rdx
    ac5f:	78 51                	js     acb2 <fwp_write+0x1012>
    ac61:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac66:	48 89 c6             	mov    %rax,%rsi
    ac69:	48 89 ef             	mov    %rbp,%rdi
    ac6c:	e8 cf 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac71:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac75:	49 63 c1             	movslq %r9d,%rax
    ac78:	49 89 e8             	mov    %rbp,%r8
    ac7b:	ba 00 02 00 00       	mov    $0x200,%edx
    ac80:	be 02 00 00 00       	mov    $0x2,%esi
    ac85:	48 c1 e0 04          	shl    $0x4,%rax
    ac89:	48 8d 3d 90 37 00 00 	lea    0x3790(%rip),%rdi        # e420 <units.1>
    ac90:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac97:	00 
    ac98:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ac9c:	48 8d 0d 0e 16 00 00 	lea    0x160e(%rip),%rcx        # c2b1 <_IO_stdin_used+0x2b1>
    aca3:	4c 89 e7             	mov    %r12,%rdi
    aca6:	31 c0                	xor    %eax,%eax
    aca8:	e8 13 8a ff ff       	call   36c0 <__sprintf_chk@plt>
    acad:	e9 6e f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    acb2:	48 f7 d8             	neg    %rax
    acb5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    acba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    acbf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acc4:	48 83 d2 00          	adc    $0x0,%rdx
    acc8:	48 89 c6             	mov    %rax,%rsi
    accb:	48 f7 da             	neg    %rdx
    acce:	e8 6d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acd3:	44 8b 0c 24          	mov    (%rsp),%r9d
    acd7:	eb 9c                	jmp    ac75 <fwp_write+0xfd5>
    acd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ace0 <fwp_main_thread>:
    ace0:	f3 0f 1e fa          	endbr64
    ace4:	41 57                	push   %r15
    ace6:	41 56                	push   %r14
    ace8:	41 55                	push   %r13
    acea:	41 54                	push   %r12
    acec:	55                   	push   %rbp
    aced:	53                   	push   %rbx
    acee:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    acf5:	8b 3d c9 ee 05 00    	mov    0x5eec9(%rip),%edi        # 69bc4 <fwp_heap+0x13a4>
    acfb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ad02:	00 00 
    ad04:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    ad0b:	00 
    ad0c:	31 c0                	xor    %eax,%eax
    ad0e:	85 ff                	test   %edi,%edi
    ad10:	0f 84 1a 07 00 00    	je     b430 <fwp_main_thread+0x750>
    ad16:	8b 35 ac ee 05 00    	mov    0x5eeac(%rip),%esi        # 69bc8 <fwp_heap+0x13a8>
    ad1c:	85 f6                	test   %esi,%esi
    ad1e:	0f 85 1f 07 00 00    	jne    b443 <fwp_main_thread+0x763>
    ad24:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad29:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    ad2e:	31 f6                	xor    %esi,%esi
    ad30:	48 c7 05 85 d4 05 00 	movq   $0x40000000,0x5d485(%rip)        # 681c0 <fwp_main_stack_size>
    ad37:	00 00 00 40 
    ad3b:	48 8d 05 3e 53 00 00 	lea    0x533e(%rip),%rax        # 10080 <alt.5>
    ad42:	48 89 ef             	mov    %rbp,%rdi
    ad45:	48 89 1d 7c d4 05 00 	mov    %rbx,0x5d47c(%rip)        # 681c8 <fwp_main_stack_top>
    ad4c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    ad51:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    ad58:	01 00 
    ad5a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    ad61:	00 
    ad62:	e8 39 89 ff ff       	call   36a0 <sigaltstack@plt>
    ad67:	85 c0                	test   %eax,%eax
    ad69:	0f 85 0c 0e 00 00    	jne    bb7b <fwp_main_thread+0xe9b>
    ad6f:	31 c0                	xor    %eax,%eax
    ad71:	b9 12 00 00 00       	mov    $0x12,%ecx
    ad76:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad7d:	00 
    ad7e:	f3 48 ab             	rep stos %rax,(%rdi)
    ad81:	48 8d 05 b8 8f ff ff 	lea    -0x7048(%rip),%rax        # 3d40 <fwp_segv>
    ad88:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad8f:	00 
    ad90:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    ad97:	04 00 00 08 
    ad9b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ada2:	00 
    ada3:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
    adaa:	00 
    adab:	e8 b0 87 ff ff       	call   3560 <sigemptyset@plt>
    adb0:	85 c0                	test   %eax,%eax
    adb2:	0f 85 c3 0d 00 00    	jne    bb7b <fwp_main_thread+0xe9b>
    adb8:	31 d2                	xor    %edx,%edx
    adba:	4c 89 ee             	mov    %r13,%rsi
    adbd:	bf 0b 00 00 00       	mov    $0xb,%edi
    adc2:	e8 29 86 ff ff       	call   33f0 <sigaction@plt>
    adc7:	85 c0                	test   %eax,%eax
    adc9:	0f 85 ac 0d 00 00    	jne    bb7b <fwp_main_thread+0xe9b>
    adcf:	31 d2                	xor    %edx,%edx
    add1:	4c 89 ee             	mov    %r13,%rsi
    add4:	bf 07 00 00 00       	mov    $0x7,%edi
    add9:	e8 12 86 ff ff       	call   33f0 <sigaction@plt>
    adde:	85 c0                	test   %eax,%eax
    ade0:	0f 85 95 0d 00 00    	jne    bb7b <fwp_main_thread+0xe9b>
    ade6:	48 8b 05 53 ee 05 00 	mov    0x5ee53(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    aded:	48 85 c0             	test   %rax,%rax
    adf0:	0f 88 1a 06 00 00    	js     b410 <fwp_main_thread+0x730>
    adf6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    adfa:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    adff:	48 8d 3d 1a 94 ff ff 	lea    -0x6be6(%rip),%rdi        # 4220 <ad_raw_report>
    ae06:	f2 0f 11 05 ba f6 05 	movsd  %xmm0,0x5f6ba(%rip)        # 6a4c8 <iteration_start_charge>
    ae0d:	00 
    ae0e:	c7 05 d0 f6 05 00 01 	movl   $0x1,0x5f6d0(%rip)        # 6a4e8 <iteration_active>
    ae15:	00 00 00 
    ae18:	e8 b3 0f 00 00       	call   bdd0 <atexit>
    ae1d:	85 c0                	test   %eax,%eax
    ae1f:	0f 85 62 0d 00 00    	jne    bb87 <fwp_main_thread+0xea7>
    ae25:	8b 0d 45 52 00 00    	mov    0x5245(%rip),%ecx        # 10070 <st.3>
    ae2b:	85 c9                	test   %ecx,%ecx
    ae2d:	0f 84 25 06 00 00    	je     b458 <fwp_main_thread+0x778>
    ae33:	48 8b 2d c6 d9 05 00 	mov    0x5d9c6(%rip),%rbp        # 68800 <fwp_cur>
    ae3a:	48 85 ed             	test   %rbp,%rbp
    ae3d:	0f 84 bd 01 00 00    	je     b000 <fwp_main_thread+0x320>
    ae43:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ae48:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ae4c:	48 89 eb             	mov    %rbp,%rbx
    ae4f:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ae54:	0f 84 41 01 00 00    	je     af9b <fwp_main_thread+0x2bb>
    ae5a:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ae5f:	0f 84 9b 02 00 00    	je     b100 <fwp_main_thread+0x420>
    ae65:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ae69:	0f 84 71 02 00 00    	je     b0e0 <fwp_main_thread+0x400>
    ae6f:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ae73:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae77:	0f 85 03 03 00 00    	jne    b180 <fwp_main_thread+0x4a0>
    ae7d:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ae81:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae88:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ae8c:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae93:	00 00 00 00 
    ae97:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ae9e:	48 85 d2             	test   %rdx,%rdx
    aea1:	74 07                	je     aeaa <fwp_main_thread+0x1ca>
    aea3:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    aeaa:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    aeae:	48 85 c0             	test   %rax,%rax
    aeb1:	74 34                	je     aee7 <fwp_main_thread+0x207>
    aeb3:	48 89 43 68          	mov    %rax,0x68(%rbx)
    aeb7:	48 8b 05 1a d9 05 00 	mov    0x5d91a(%rip),%rax        # 687d8 <fwp_timers>
    aebe:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    aec2:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    aec9:	00 00 00 00 
    aecd:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    aed4:	48 85 c0             	test   %rax,%rax
    aed7:	74 07                	je     aee0 <fwp_main_thread+0x200>
    aed9:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    aee0:	48 89 1d f1 d8 05 00 	mov    %rbx,0x5d8f1(%rip)        # 687d8 <fwp_timers>
    aee7:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    aeeb:	e8 60 c9 ff ff       	call   7850 <fwp_block>
    aef0:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    aef7:	48 85 c9             	test   %rcx,%rcx
    aefa:	74 47                	je     af43 <fwp_main_thread+0x263>
    aefc:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    af03:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af0a:	48 85 d2             	test   %rdx,%rdx
    af0d:	0f 84 ad 02 00 00    	je     b1c0 <fwp_main_thread+0x4e0>
    af13:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    af1a:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af21:	48 85 c0             	test   %rax,%rax
    af24:	74 07                	je     af2d <fwp_main_thread+0x24d>
    af26:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    af2d:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    af34:	00 00 00 00 
    af38:	66 0f ef d2          	pxor   %xmm2,%xmm2
    af3c:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    af43:	48 8b 0d b6 d8 05 00 	mov    0x5d8b6(%rip),%rcx        # 68800 <fwp_cur>
    af4a:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    af4e:	0f 84 1c 02 00 00    	je     b170 <fwp_main_thread+0x490>
    af54:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    af5b:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    af62:	48 85 d2             	test   %rdx,%rdx
    af65:	0f 84 95 04 00 00    	je     b400 <fwp_main_thread+0x720>
    af6b:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    af72:	48 85 c0             	test   %rax,%rax
    af75:	74 07                	je     af7e <fwp_main_thread+0x29e>
    af77:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    af7e:	66 0f ef db          	pxor   %xmm3,%xmm3
    af82:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    af86:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    af8d:	48 89 cb             	mov    %rcx,%rbx
    af90:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    af95:	0f 85 bf fe ff ff    	jne    ae5a <fwp_main_thread+0x17a>
    af9b:	48 83 3d f5 f4 05 00 	cmpq   $0x0,0x5f4f5(%rip)        # 6a498 <fwp_state_len>
    afa2:	00 
    afa3:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    afa7:	74 67                	je     b010 <fwp_main_thread+0x330>
    afa9:	48 39 1d 48 d8 05 00 	cmp    %rbx,0x5d848(%rip)        # 687f8 <fwp_root>
    afb0:	c7 05 c6 50 01 00 00 	movl   $0x0,0x150c6(%rip)        # 20080 <fwp_exit_code>
    afb7:	00 00 00 
    afba:	0f 85 f5 0b 00 00    	jne    bbb5 <fwp_main_thread+0xed5>
    afc0:	48 85 db             	test   %rbx,%rbx
    afc3:	0f 84 1f 02 00 00    	je     b1e8 <fwp_main_thread+0x508>
    afc9:	48 8b 15 f8 d7 05 00 	mov    0x5d7f8(%rip),%rdx        # 687c8 <fwp_tasks_active>
    afd0:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    afd4:	48 85 d2             	test   %rdx,%rdx
    afd7:	0f 84 0b 02 00 00    	je     b1e8 <fwp_main_thread+0x508>
    afdd:	0f 1f 00             	nopl   (%rax)
    afe0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    afe4:	75 08                	jne    afee <fwp_main_thread+0x30e>
    afe6:	48 89 d7             	mov    %rdx,%rdi
    afe9:	e8 42 91 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    afee:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    aff5:	48 85 d2             	test   %rdx,%rdx
    aff8:	75 e6                	jne    afe0 <fwp_main_thread+0x300>
    affa:	e9 ae 00 00 00       	jmp    b0ad <fwp_main_thread+0x3cd>
    afff:	90                   	nop
    b000:	48 83 3d 90 f4 05 00 	cmpq   $0x0,0x5f490(%rip)        # 6a498 <fwp_state_len>
    b007:	00 
    b008:	0f 85 c2 01 00 00    	jne    b1d0 <fwp_main_thread+0x4f0>
    b00e:	31 db                	xor    %ebx,%ebx
    b010:	48 83 3d 70 f4 05 00 	cmpq   $0x0,0x5f470(%rip)        # 6a488 <fwp_state_owners>
    b017:	00 
    b018:	75 8f                	jne    afa9 <fwp_main_thread+0x2c9>
    b01a:	48 8b 3d 7f f4 05 00 	mov    0x5f47f(%rip),%rdi        # 6a4a0 <fwp_state>
    b021:	e8 ea a9 ff ff       	call   5a10 <fwp_mem_free>
    b026:	48 c7 05 6f f4 05 00 	movq   $0x0,0x5f46f(%rip)        # 6a4a0 <fwp_state>
    b02d:	00 00 00 00 
    b031:	48 c7 05 54 f4 05 00 	movq   $0x0,0x5f454(%rip)        # 6a490 <fwp_state_cap>
    b038:	00 00 00 00 
    b03c:	48 85 db             	test   %rbx,%rbx
    b03f:	0f 84 2d 0a 00 00    	je     ba72 <fwp_main_thread+0xd92>
    b045:	48 39 1d ac d7 05 00 	cmp    %rbx,0x5d7ac(%rip)        # 687f8 <fwp_root>
    b04c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b053:	00 00 00 00 
    b057:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b05e:	00 00 00 00 
    b062:	c7 05 14 50 01 00 00 	movl   $0x0,0x15014(%rip)        # 20080 <fwp_exit_code>
    b069:	00 00 00 
    b06c:	0f 84 57 ff ff ff    	je     afc9 <fwp_main_thread+0x2e9>
    b072:	e9 d9 86 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b07e:	00 00 
    b080:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b087:	48 89 1d 52 d7 05 00 	mov    %rbx,0x5d752(%rip)        # 687e0 <fwp_ready_tail>
    b08e:	e8 bd c7 ff ff       	call   7850 <fwp_block>
    b093:	e8 b8 c5 ff ff       	call   7650 <fwp_free_zombie>
    b098:	48 83 3d 28 d7 05 00 	cmpq   $0x0,0x5d728(%rip)        # 687c8 <fwp_tasks_active>
    b09f:	00 
    b0a0:	0f 84 42 01 00 00    	je     b1e8 <fwp_main_thread+0x508>
    b0a6:	48 8b 1d 4b d7 05 00 	mov    0x5d74b(%rip),%rbx        # 687f8 <fwp_root>
    b0ad:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b0b1:	75 db                	jne    b08e <fwp_main_thread+0x3ae>
    b0b3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b0b7:	75 d5                	jne    b08e <fwp_main_thread+0x3ae>
    b0b9:	48 8b 05 20 d7 05 00 	mov    0x5d720(%rip),%rax        # 687e0 <fwp_ready_tail>
    b0c0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b0c4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b0cb:	00 00 00 00 
    b0cf:	48 85 c0             	test   %rax,%rax
    b0d2:	75 ac                	jne    b080 <fwp_main_thread+0x3a0>
    b0d4:	48 89 1d 0d d7 05 00 	mov    %rbx,0x5d70d(%rip)        # 687e8 <fwp_ready_head>
    b0db:	eb aa                	jmp    b087 <fwp_main_thread+0x3a7>
    b0dd:	0f 1f 00             	nopl   (%rax)
    b0e0:	e8 db 94 ff ff       	call   45c0 <fwp_now_ns>
    b0e5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b0e9:	7c 15                	jl     b100 <fwp_main_thread+0x420>
    b0eb:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b0ef:	75 0f                	jne    b100 <fwp_main_thread+0x420>
    b0f1:	48 89 ef             	mov    %rbp,%rdi
    b0f4:	e8 37 90 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b0f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b100:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b104:	0f 85 65 fd ff ff    	jne    ae6f <fwp_main_thread+0x18f>
    b10a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b10e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b112:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b116:	0f 85 65 fd ff ff    	jne    ae81 <fwp_main_thread+0x1a1>
    b11c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b120:	48 85 c9             	test   %rcx,%rcx
    b123:	0f 84 58 fd ff ff    	je     ae81 <fwp_main_thread+0x1a1>
    b129:	48 39 c8             	cmp    %rcx,%rax
    b12c:	48 89 ce             	mov    %rcx,%rsi
    b12f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b136:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b13a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b141:	00 00 00 00 
    b145:	48 0f 4e f0          	cmovle %rax,%rsi
    b149:	48 85 c0             	test   %rax,%rax
    b14c:	48 89 c8             	mov    %rcx,%rax
    b14f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b156:	48 0f 45 c6          	cmovne %rsi,%rax
    b15a:	48 85 d2             	test   %rdx,%rdx
    b15d:	74 07                	je     b166 <fwp_main_thread+0x486>
    b15f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b166:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b16a:	e9 44 fd ff ff       	jmp    aeb3 <fwp_main_thread+0x1d3>
    b16f:	90                   	nop
    b170:	48 89 cb             	mov    %rcx,%rbx
    b173:	e9 d7 fc ff ff       	jmp    ae4f <fwp_main_thread+0x16f>
    b178:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b17f:	00 
    b180:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b184:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b18b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b192:	00 00 00 00 
    b196:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b19d:	48 85 c0             	test   %rax,%rax
    b1a0:	0f 84 4a 08 00 00    	je     b9f0 <fwp_main_thread+0xd10>
    b1a6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b1ad:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b1b1:	e9 31 fd ff ff       	jmp    aee7 <fwp_main_thread+0x207>
    b1b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b1bd:	00 00 00 
    b1c0:	48 89 01             	mov    %rax,(%rcx)
    b1c3:	e9 59 fd ff ff       	jmp    af21 <fwp_main_thread+0x241>
    b1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b1cf:	00 
    b1d0:	48 83 3d 20 d6 05 00 	cmpq   $0x0,0x5d620(%rip)        # 687f8 <fwp_root>
    b1d7:	00 
    b1d8:	c7 05 9e 4e 01 00 00 	movl   $0x0,0x14e9e(%rip)        # 20080 <fwp_exit_code>
    b1df:	00 00 00 
    b1e2:	0f 85 c8 09 00 00    	jne    bbb0 <fwp_main_thread+0xed0>
    b1e8:	e8 63 c4 ff ff       	call   7650 <fwp_free_zombie>
    b1ed:	48 83 3d f3 d5 05 00 	cmpq   $0x0,0x5d5f3(%rip)        # 687e8 <fwp_ready_head>
    b1f4:	00 
    b1f5:	0f 85 55 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1fb:	48 83 3d d5 d5 05 00 	cmpq   $0x0,0x5d5d5(%rip)        # 687d8 <fwp_timers>
    b202:	00 
    b203:	0f 85 47 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b209:	8b 05 c5 cf 05 00    	mov    0x5cfc5(%rip),%eax        # 681d4 <fwp_stack_pool_n>
    b20f:	85 c0                	test   %eax,%eax
    b211:	74 3a                	je     b24d <fwp_main_thread+0x56d>
    b213:	83 e8 01             	sub    $0x1,%eax
    b216:	4c 8d 25 c3 cf 05 00 	lea    0x5cfc3(%rip),%r12        # 681e0 <fwp_stack_pool>
    b21d:	48 63 d8             	movslq %eax,%rbx
    b220:	89 c0                	mov    %eax,%eax
    b222:	48 89 da             	mov    %rbx,%rdx
    b225:	48 29 c2             	sub    %rax,%rdx
    b228:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b22c:	0f 1f 40 00          	nopl   0x0(%rax)
    b230:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b234:	89 1d 9a cf 05 00    	mov    %ebx,0x5cf9a(%rip)        # 681d4 <fwp_stack_pool_n>
    b23a:	be 00 00 00 10       	mov    $0x10000000,%esi
    b23f:	48 83 eb 01          	sub    $0x1,%rbx
    b243:	e8 78 83 ff ff       	call   35c0 <munmap@plt>
    b248:	48 39 dd             	cmp    %rbx,%rbp
    b24b:	75 e3                	jne    b230 <fwp_main_thread+0x550>
    b24d:	8b 3d c5 4d 00 00    	mov    0x4dc5(%rip),%edi        # 10018 <fwp_epfd>
    b253:	85 ff                	test   %edi,%edi
    b255:	78 05                	js     b25c <fwp_main_thread+0x57c>
    b257:	e8 64 82 ff ff       	call   34c0 <close@plt>
    b25c:	4c 8b 25 7d d1 05 00 	mov    0x5d17d(%rip),%r12        # 683e0 <fwp_nfdws>
    b263:	48 8b 2d 7e d1 05 00 	mov    0x5d17e(%rip),%rbp        # 683e8 <fwp_fdws>
    b26a:	31 db                	xor    %ebx,%ebx
    b26c:	c7 05 a2 4d 00 00 ff 	movl   $0xffffffff,0x4da2(%rip)        # 10018 <fwp_epfd>
    b273:	ff ff ff 
    b276:	4d 85 e4             	test   %r12,%r12
    b279:	74 32                	je     b2ad <fwp_main_thread+0x5cd>
    b27b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b280:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b285:	48 85 ff             	test   %rdi,%rdi
    b288:	74 1a                	je     b2a4 <fwp_main_thread+0x5c4>
    b28a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b28e:	0f 85 bc 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b294:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b299:	0f 85 b1 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b29f:	e8 6c a7 ff ff       	call   5a10 <fwp_mem_free>
    b2a4:	48 83 c3 01          	add    $0x1,%rbx
    b2a8:	49 39 dc             	cmp    %rbx,%r12
    b2ab:	75 d3                	jne    b280 <fwp_main_thread+0x5a0>
    b2ad:	48 89 ef             	mov    %rbp,%rdi
    b2b0:	e8 5b a7 ff ff       	call   5a10 <fwp_mem_free>
    b2b5:	48 8b 15 3c d5 05 00 	mov    0x5d53c(%rip),%rdx        # 687f8 <fwp_root>
    b2bc:	48 c7 05 21 d1 05 00 	movq   $0x0,0x5d121(%rip)        # 683e8 <fwp_fdws>
    b2c3:	00 00 00 00 
    b2c7:	48 c7 05 0e d1 05 00 	movq   $0x0,0x5d10e(%rip)        # 683e0 <fwp_nfdws>
    b2ce:	00 00 00 00 
    b2d2:	48 85 d2             	test   %rdx,%rdx
    b2d5:	74 4e                	je     b325 <fwp_main_thread+0x645>
    b2d7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b2dc:	0f 85 6e 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2e2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b2e9:	00 
    b2ea:	0f 85 60 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2f0:	48 83 3d a0 f1 05 00 	cmpq   $0x0,0x5f1a0(%rip)        # 6a498 <fwp_state_len>
    b2f7:	00 
    b2f8:	0f 85 52 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2fe:	48 83 3d 82 f1 05 00 	cmpq   $0x0,0x5f182(%rip)        # 6a488 <fwp_state_owners>
    b305:	00 
    b306:	0f 85 44 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b30c:	b9 79 00 00 00       	mov    $0x79,%ecx
    b311:	31 c0                	xor    %eax,%eax
    b313:	48 8d 3d e6 d0 05 00 	lea    0x5d0e6(%rip),%rdi        # 68400 <fwp_root_context>
    b31a:	f3 48 ab             	rep stos %rax,(%rdi)
    b31d:	48 89 d7             	mov    %rdx,%rdi
    b320:	e8 eb a6 ff ff       	call   5a10 <fwp_mem_free>
    b325:	66 0f 6f 05 83 4e 04 	movdqa 0x44e83(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    b32c:	00 
    b32d:	66 0f d4 05 6b 4e 04 	paddq  0x44e6b(%rip),%xmm0        # 501a0 <ad_raw_live>
    b334:	00 
    b335:	48 c7 05 c0 d4 05 00 	movq   $0x0,0x5d4c0(%rip)        # 68800 <fwp_cur>
    b33c:	00 00 00 00 
    b340:	48 8b 05 f9 e8 05 00 	mov    0x5e8f9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    b347:	48 c7 05 a6 d4 05 00 	movq   $0x0,0x5d4a6(%rip)        # 687f8 <fwp_root>
    b34e:	00 00 00 00 
    b352:	c7 05 8c f1 05 00 00 	movl   $0x0,0x5f18c(%rip)        # 6a4e8 <iteration_active>
    b359:	00 00 00 
    b35c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b360:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b365:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b369:	66 0f d6 05 87 4d 01 	movq   %xmm0,0x14d87(%rip)        # 200f8 <ad_raw_before_shutdown>
    b370:	00 
    b371:	48 85 c0             	test   %rax,%rax
    b374:	0f 88 56 06 00 00    	js     b9d0 <fwp_main_thread+0xcf0>
    b37a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b37e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b383:	f2 0f 5c 0d 3d f1 05 	subsd  0x5f13d(%rip),%xmm1        # 6a4c8 <iteration_start_charge>
    b38a:	00 
    b38b:	48 8b 3d ae 4c 00 00 	mov    0x4cae(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    b392:	48 8d 15 c7 17 00 00 	lea    0x17c7(%rip),%rdx        # cb60 <_IO_stdin_used+0xb60>
    b399:	be 02 00 00 00       	mov    $0x2,%esi
    b39e:	f2 0f 10 05 1a f1 05 	movsd  0x5f11a(%rip),%xmm0        # 6a4c0 <iteration_peak>
    b3a5:	00 
    b3a6:	4c 8b 0d 23 f1 05 00 	mov    0x5f123(%rip),%r9        # 6a4d0 <iteration_retains>
    b3ad:	b8 02 00 00 00       	mov    $0x2,%eax
    b3b2:	4c 8b 05 1f f1 05 00 	mov    0x5f11f(%rip),%r8        # 6a4d8 <iteration_bytes>
    b3b9:	48 8b 0d 20 f1 05 00 	mov    0x5f120(%rip),%rcx        # 6a4e0 <iteration_requests>
    b3c0:	e8 ab 82 ff ff       	call   3670 <__fprintf_chk@plt>
    b3c5:	48 8b 3d 54 4c 00 00 	mov    0x4c54(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b3cc:	e8 cf 81 ff ff       	call   35a0 <fflush@plt>
    b3d1:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b3d8:	00 
    b3d9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b3e0:	00 00 
    b3e2:	0f 85 b7 07 00 00    	jne    bb9f <fwp_main_thread+0xebf>
    b3e8:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b3ef:	31 c0                	xor    %eax,%eax
    b3f1:	5b                   	pop    %rbx
    b3f2:	5d                   	pop    %rbp
    b3f3:	41 5c                	pop    %r12
    b3f5:	41 5d                	pop    %r13
    b3f7:	41 5e                	pop    %r14
    b3f9:	41 5f                	pop    %r15
    b3fb:	c3                   	ret
    b3fc:	0f 1f 40 00          	nopl   0x0(%rax)
    b400:	48 89 05 d1 d3 05 00 	mov    %rax,0x5d3d1(%rip)        # 687d8 <fwp_timers>
    b407:	e9 66 fb ff ff       	jmp    af72 <fwp_main_thread+0x292>
    b40c:	0f 1f 40 00          	nopl   0x0(%rax)
    b410:	48 89 c2             	mov    %rax,%rdx
    b413:	83 e0 01             	and    $0x1,%eax
    b416:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b41a:	48 d1 ea             	shr    $1,%rdx
    b41d:	48 09 c2             	or     %rax,%rdx
    b420:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b425:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b429:	e9 d1 f9 ff ff       	jmp    adff <fwp_main_thread+0x11f>
    b42e:	66 90                	xchg   %ax,%ax
    b430:	e8 9b 99 ff ff       	call   4dd0 <fwp_heap_init>
    b435:	8b 35 8d e7 05 00    	mov    0x5e78d(%rip),%esi        # 69bc8 <fwp_heap+0x13a8>
    b43b:	85 f6                	test   %esi,%esi
    b43d:	0f 84 e1 f8 ff ff    	je     ad24 <fwp_main_thread+0x44>
    b443:	48 8d 3d 76 98 ff ff 	lea    -0x678a(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b44a:	e8 81 09 00 00       	call   bdd0 <atexit>
    b44f:	e9 d0 f8 ff ff       	jmp    ad24 <fwp_main_thread+0x44>
    b454:	0f 1f 40 00          	nopl   0x0(%rax)
    b458:	48 8d 05 11 bb ff ff 	lea    -0x44ef(%rip),%rax        # 6f70 <fwp_drop1>
    b45f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b463:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b46a:	00 00 
    b46c:	41 be ff 7f 00 00    	mov    $0x7fff,%r14d
    b472:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b477:	48 8b 05 3a f0 05 00 	mov    0x5f03a(%rip),%rax        # 6a4b8 <fwp_cleanups>
    b47e:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
    b483:	4c 8d 25 96 d3 05 00 	lea    0x5d396(%rip),%r12        # 68820 <fwp_heap>
    b48a:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b48e:	48 89 1d 23 f0 05 00 	mov    %rbx,0x5f023(%rip)        # 6a4b8 <fwp_cleanups>
    b495:	31 db                	xor    %ebx,%ebx
    b497:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b49c:	48 8d 05 2d 87 ff ff 	lea    -0x78d3(%rip),%rax        # 3bd0 <fwp_range_release>
    b4a3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b4a8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b4ad:	eb 3b                	jmp    b4ea <fwp_main_thread+0x80a>
    b4af:	90                   	nop
    b4b0:	40 80 fe 01          	cmp    $0x1,%sil
    b4b4:	75 25                	jne    b4db <fwp_main_thread+0x7fb>
    b4b6:	8b 71 18             	mov    0x18(%rcx),%esi
    b4b9:	0f b7 c0             	movzwl %ax,%eax
    b4bc:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b4bf:	48 0f af c6          	imul   %rsi,%rax
    b4c3:	48 c1 e8 20          	shr    $0x20,%rax
    b4c7:	48 39 c8             	cmp    %rcx,%rax
    b4ca:	73 0f                	jae    b4db <fwp_main_thread+0x7fb>
    b4cc:	48 01 c2             	add    %rax,%rdx
    b4cf:	80 3a ff             	cmpb   $0xff,(%rdx)
    b4d2:	0f 84 68 05 00 00    	je     ba40 <fwp_main_thread+0xd60>
    b4d8:	c6 02 01             	movb   $0x1,(%rdx)
    b4db:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b4e0:	49 83 ee 01          	sub    $0x1,%r14
    b4e4:	0f 82 86 00 00 00    	jb     b570 <fwp_main_thread+0x890>
    b4ea:	4c 89 ee             	mov    %r13,%rsi
    b4ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b4f2:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    b4f9:	00 
    b4fa:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    b4ff:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    b506:	00 
    b507:	e8 34 b3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b50c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b513:	00 
    b514:	48 89 c3             	mov    %rax,%rbx
    b517:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b51e:	00 
    b51f:	48 c1 e2 10          	shl    $0x10,%rdx
    b523:	48 39 d0             	cmp    %rdx,%rax
    b526:	73 b3                	jae    b4db <fwp_main_thread+0x7fb>
    b528:	48 89 c2             	mov    %rax,%rdx
    b52b:	48 c1 ea 10          	shr    $0x10,%rdx
    b52f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b533:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b53a:	00 
    b53b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b53f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b543:	48 85 d2             	test   %rdx,%rdx
    b546:	74 93                	je     b4db <fwp_main_thread+0x7fb>
    b548:	0f b6 31             	movzbl (%rcx),%esi
    b54b:	40 80 fe 02          	cmp    $0x2,%sil
    b54f:	0f 85 5b ff ff ff    	jne    b4b0 <fwp_main_thread+0x7d0>
    b555:	66 85 c0             	test   %ax,%ax
    b558:	0f 84 71 ff ff ff    	je     b4cf <fwp_main_thread+0x7ef>
    b55e:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b563:	49 83 ee 01          	sub    $0x1,%r14
    b567:	73 81                	jae    b4ea <fwp_main_thread+0x80a>
    b569:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b570:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b575:	66 0f 6f 05 53 18 00 	movdqa 0x1853(%rip),%xmm0        # cdd0 <msg.4+0xa0>
    b57c:	00 
    b57d:	4c 89 ee             	mov    %r13,%rsi
    b580:	bf 01 00 00 00       	mov    $0x1,%edi
    b585:	48 89 05 2c ef 05 00 	mov    %rax,0x5ef2c(%rip)        # 6a4b8 <fwp_cleanups>
    b58c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b593:	00 
    b594:	e8 a7 b2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b599:	48 8b 15 58 e6 05 00 	mov    0x5e658(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b5a0:	49 89 c6             	mov    %rax,%r14
    b5a3:	48 2b 05 26 e6 05 00 	sub    0x5e626(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    b5aa:	48 c1 e2 10          	shl    $0x10,%rdx
    b5ae:	48 39 d0             	cmp    %rdx,%rax
    b5b1:	73 59                	jae    b60c <fwp_main_thread+0x92c>
    b5b3:	48 89 c2             	mov    %rax,%rdx
    b5b6:	48 c1 ea 10          	shr    $0x10,%rdx
    b5ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5be:	48 8b 15 53 e6 05 00 	mov    0x5e653(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    b5c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5c9:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b5cd:	4d 85 ed             	test   %r13,%r13
    b5d0:	74 3a                	je     b60c <fwp_main_thread+0x92c>
    b5d2:	0f b6 0a             	movzbl (%rdx),%ecx
    b5d5:	80 f9 02             	cmp    $0x2,%cl
    b5d8:	0f 84 52 04 00 00    	je     ba30 <fwp_main_thread+0xd50>
    b5de:	80 f9 01             	cmp    $0x1,%cl
    b5e1:	75 29                	jne    b60c <fwp_main_thread+0x92c>
    b5e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5e6:	0f b7 c0             	movzwl %ax,%eax
    b5e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5ec:	48 0f af c1          	imul   %rcx,%rax
    b5f0:	48 c1 e8 20          	shr    $0x20,%rax
    b5f4:	48 39 d0             	cmp    %rdx,%rax
    b5f7:	73 13                	jae    b60c <fwp_main_thread+0x92c>
    b5f9:	49 01 c5             	add    %rax,%r13
    b5fc:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b601:	0f 84 c2 04 00 00    	je     bac9 <fwp_main_thread+0xde9>
    b607:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b60c:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b611:	bf 01 00 00 00       	mov    $0x1,%edi
    b616:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b61b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b622:	00 f0 3f 
    b625:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b62a:	e8 11 b2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b62f:	48 8b 15 c2 e5 05 00 	mov    0x5e5c2(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b636:	49 89 c6             	mov    %rax,%r14
    b639:	48 2b 05 90 e5 05 00 	sub    0x5e590(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    b640:	48 c1 e2 10          	shl    $0x10,%rdx
    b644:	48 39 d0             	cmp    %rdx,%rax
    b647:	73 59                	jae    b6a2 <fwp_main_thread+0x9c2>
    b649:	48 89 c2             	mov    %rax,%rdx
    b64c:	48 c1 ea 10          	shr    $0x10,%rdx
    b650:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b654:	48 8b 15 bd e5 05 00 	mov    0x5e5bd(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    b65b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b65f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b663:	4d 85 ed             	test   %r13,%r13
    b666:	74 3a                	je     b6a2 <fwp_main_thread+0x9c2>
    b668:	0f b6 0a             	movzbl (%rdx),%ecx
    b66b:	80 f9 02             	cmp    $0x2,%cl
    b66e:	0f 84 ac 03 00 00    	je     ba20 <fwp_main_thread+0xd40>
    b674:	80 f9 01             	cmp    $0x1,%cl
    b677:	75 29                	jne    b6a2 <fwp_main_thread+0x9c2>
    b679:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b67c:	0f b7 c0             	movzwl %ax,%eax
    b67f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b682:	48 0f af c1          	imul   %rcx,%rax
    b686:	48 c1 e8 20          	shr    $0x20,%rax
    b68a:	48 39 d0             	cmp    %rdx,%rax
    b68d:	73 13                	jae    b6a2 <fwp_main_thread+0x9c2>
    b68f:	49 01 c5             	add    %rax,%r13
    b692:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b697:	0f 84 39 04 00 00    	je     bad6 <fwp_main_thread+0xdf6>
    b69d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b6a2:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b6a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ac:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b6b1:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b6b8:	33 f3 bf 
    b6bb:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b6c0:	e8 7b b1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b6c5:	48 8b 15 2c e5 05 00 	mov    0x5e52c(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b6cc:	48 8b 0d fd e4 05 00 	mov    0x5e4fd(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    b6d3:	49 89 c5             	mov    %rax,%r13
    b6d6:	48 89 d6             	mov    %rdx,%rsi
    b6d9:	48 29 c8             	sub    %rcx,%rax
    b6dc:	48 c1 e6 10          	shl    $0x10,%rsi
    b6e0:	48 39 f0             	cmp    %rsi,%rax
    b6e3:	73 67                	jae    b74c <fwp_main_thread+0xa6c>
    b6e5:	48 89 c6             	mov    %rax,%rsi
    b6e8:	48 c1 ee 10          	shr    $0x10,%rsi
    b6ec:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b6f0:	48 8b 35 21 e5 05 00 	mov    0x5e521(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    b6f7:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b6fb:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b6ff:	4d 85 f6             	test   %r14,%r14
    b702:	74 48                	je     b74c <fwp_main_thread+0xa6c>
    b704:	0f b6 3e             	movzbl (%rsi),%edi
    b707:	40 80 ff 02          	cmp    $0x2,%dil
    b70b:	0f 84 ff 02 00 00    	je     ba10 <fwp_main_thread+0xd30>
    b711:	40 80 ff 01          	cmp    $0x1,%dil
    b715:	75 35                	jne    b74c <fwp_main_thread+0xa6c>
    b717:	8b 7e 18             	mov    0x18(%rsi),%edi
    b71a:	0f b7 c0             	movzwl %ax,%eax
    b71d:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b720:	48 0f af c7          	imul   %rdi,%rax
    b724:	48 c1 e8 20          	shr    $0x20,%rax
    b728:	48 39 f0             	cmp    %rsi,%rax
    b72b:	73 1f                	jae    b74c <fwp_main_thread+0xa6c>
    b72d:	49 01 c6             	add    %rax,%r14
    b730:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b734:	0f 84 a9 03 00 00    	je     bae3 <fwp_main_thread+0xe03>
    b73a:	41 c6 06 01          	movb   $0x1,(%r14)
    b73e:	48 8b 0d 8b e4 05 00 	mov    0x5e48b(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    b745:	48 8b 15 ac e4 05 00 	mov    0x5e4ac(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b74c:	48 89 1c 24          	mov    %rbx,(%rsp)
    b750:	4c 89 e8             	mov    %r13,%rax
    b753:	48 c1 e2 10          	shl    $0x10,%rdx
    b757:	48 29 c8             	sub    %rcx,%rax
    b75a:	48 39 d0             	cmp    %rdx,%rax
    b75d:	73 70                	jae    b7cf <fwp_main_thread+0xaef>
    b75f:	48 89 c2             	mov    %rax,%rdx
    b762:	48 c1 ea 10          	shr    $0x10,%rdx
    b766:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b76a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b771:	00 
    b772:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b776:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b77a:	48 85 ff             	test   %rdi,%rdi
    b77d:	74 50                	je     b7cf <fwp_main_thread+0xaef>
    b77f:	0f b6 0a             	movzbl (%rdx),%ecx
    b782:	80 f9 02             	cmp    $0x2,%cl
    b785:	0f 84 75 02 00 00    	je     ba00 <fwp_main_thread+0xd20>
    b78b:	80 f9 01             	cmp    $0x1,%cl
    b78e:	75 3f                	jne    b7cf <fwp_main_thread+0xaef>
    b790:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b793:	0f b7 c0             	movzwl %ax,%eax
    b796:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b799:	48 0f af c1          	imul   %rcx,%rax
    b79d:	48 c1 e8 20          	shr    $0x20,%rax
    b7a1:	48 39 d0             	cmp    %rdx,%rax
    b7a4:	73 29                	jae    b7cf <fwp_main_thread+0xaef>
    b7a6:	48 01 c7             	add    %rax,%rdi
    b7a9:	0f b6 07             	movzbl (%rdi),%eax
    b7ac:	84 c0                	test   %al,%al
    b7ae:	74 1f                	je     b7cf <fwp_main_thread+0xaef>
    b7b0:	8b 15 32 ed 05 00    	mov    0x5ed32(%rip),%edx        # 6a4e8 <iteration_active>
    b7b6:	85 d2                	test   %edx,%edx
    b7b8:	74 08                	je     b7c2 <fwp_main_thread+0xae2>
    b7ba:	48 83 05 0e ed 05 00 	addq   $0x1,0x5ed0e(%rip)        # 6a4d0 <iteration_retains>
    b7c1:	01 
    b7c2:	3c fd                	cmp    $0xfd,%al
    b7c4:	0f 87 26 03 00 00    	ja     baf0 <fwp_main_thread+0xe10>
    b7ca:	83 c0 01             	add    $0x1,%eax
    b7cd:	88 07                	mov    %al,(%rdi)
    b7cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b7d3:	b9 01 00 00 00       	mov    $0x1,%ecx
    b7d8:	4c 89 ee             	mov    %r13,%rsi
    b7db:	48 89 ef             	mov    %rbp,%rdi
    b7de:	48 8d 15 bb 43 00 00 	lea    0x43bb(%rip),%rdx        # fba0 <d0>
    b7e5:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b7ea:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b7f1:	00 00 
    b7f3:	e8 a8 e4 ff ff       	call   9ca0 <fwp_write>
    b7f8:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b7fd:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    b802:	48 8d 05 63 08 00 00 	lea    0x863(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    b809:	4d 85 f6             	test   %r14,%r14
    b80c:	4c 0f 44 f0          	cmove  %rax,%r14
    b810:	48 83 fa f6          	cmp    $0xfffffffffffffff6,%rdx
    b814:	0f 87 8a 03 00 00    	ja     bba4 <fwp_main_thread+0xec4>
    b81a:	48 8d 7a 09          	lea    0x9(%rdx),%rdi
    b81e:	be 01 00 00 00       	mov    $0x1,%esi
    b823:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b828:	e8 e3 a6 ff ff       	call   5f10 <fwp_heap_alloc>
    b82d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b832:	4c 89 f6             	mov    %r14,%rsi
    b835:	48 8d 78 08          	lea    0x8(%rax),%rdi
    b839:	49 89 c7             	mov    %rax,%r15
    b83c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b841:	48 89 10             	mov    %rdx,(%rax)
    b844:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    b849:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    b84e:	e8 2d 7d ff ff       	call   3580 <memcpy@plt>
    b853:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    b858:	41 c6 44 17 08 00    	movb   $0x0,0x8(%r15,%rdx,1)
    b85e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b863:	e8 48 7b ff ff       	call   33b0 <free@plt>
    b868:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b86f:	00 
    b870:	4d 2b bc 24 b0 13 00 	sub    0x13b0(%r12),%r15
    b877:	00 
    b878:	48 c1 e2 10          	shl    $0x10,%rdx
    b87c:	49 39 d7             	cmp    %rdx,%r15
    b87f:	73 59                	jae    b8da <fwp_main_thread+0xbfa>
    b881:	4c 89 fa             	mov    %r15,%rdx
    b884:	48 c1 ea 10          	shr    $0x10,%rdx
    b888:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b88c:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b893:	00 
    b894:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b898:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b89c:	4d 85 f6             	test   %r14,%r14
    b89f:	74 39                	je     b8da <fwp_main_thread+0xbfa>
    b8a1:	0f b6 0a             	movzbl (%rdx),%ecx
    b8a4:	80 f9 02             	cmp    $0x2,%cl
    b8a7:	0f 84 b6 01 00 00    	je     ba63 <fwp_main_thread+0xd83>
    b8ad:	80 f9 01             	cmp    $0x1,%cl
    b8b0:	75 28                	jne    b8da <fwp_main_thread+0xbfa>
    b8b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8b5:	41 0f b7 c7          	movzwl %r15w,%eax
    b8b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8bc:	48 0f af c1          	imul   %rcx,%rax
    b8c0:	48 c1 e8 20          	shr    $0x20,%rax
    b8c4:	48 39 d0             	cmp    %rdx,%rax
    b8c7:	73 11                	jae    b8da <fwp_main_thread+0xbfa>
    b8c9:	49 01 c6             	add    %rax,%r14
    b8cc:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b8d0:	0f 84 24 02 00 00    	je     bafa <fwp_main_thread+0xe1a>
    b8d6:	41 c6 06 01          	movb   $0x1,(%r14)
    b8da:	4c 89 ef             	mov    %r13,%rdi
    b8dd:	e8 fe b4 ff ff       	call   6de0 <fwp_drop0>
    b8e2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    b8e7:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    b8ec:	be 01 00 00 00       	mov    $0x1,%esi
    b8f1:	48 8b 0d 88 eb 05 00 	mov    0x5eb88(%rip),%rcx        # 6a480 <fwp_prog_out>
    b8f8:	49 8b 17             	mov    (%r15),%rdx
    b8fb:	e8 60 7d ff ff       	call   3660 <fwrite@plt>
    b900:	48 8b 35 79 eb 05 00 	mov    0x5eb79(%rip),%rsi        # 6a480 <fwp_prog_out>
    b907:	bf 0a 00 00 00       	mov    $0xa,%edi
    b90c:	e8 bf 7b ff ff       	call   34d0 <fputc@plt>
    b911:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b918:	00 
    b919:	4c 89 f8             	mov    %r15,%rax
    b91c:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b923:	00 
    b924:	48 c1 e2 10          	shl    $0x10,%rdx
    b928:	48 39 d0             	cmp    %rdx,%rax
    b92b:	73 73                	jae    b9a0 <fwp_main_thread+0xcc0>
    b92d:	48 89 c2             	mov    %rax,%rdx
    b930:	48 c1 ea 10          	shr    $0x10,%rdx
    b934:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b938:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b93f:	00 
    b940:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b944:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b948:	4d 85 f6             	test   %r14,%r14
    b94b:	74 53                	je     b9a0 <fwp_main_thread+0xcc0>
    b94d:	0f b6 0a             	movzbl (%rdx),%ecx
    b950:	80 f9 02             	cmp    $0x2,%cl
    b953:	0f 84 fc 00 00 00    	je     ba55 <fwp_main_thread+0xd75>
    b959:	80 f9 01             	cmp    $0x1,%cl
    b95c:	75 42                	jne    b9a0 <fwp_main_thread+0xcc0>
    b95e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b961:	0f b7 c0             	movzwl %ax,%eax
    b964:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b967:	48 0f af c1          	imul   %rcx,%rax
    b96b:	48 c1 e8 20          	shr    $0x20,%rax
    b96f:	48 39 d0             	cmp    %rdx,%rax
    b972:	73 2c                	jae    b9a0 <fwp_main_thread+0xcc0>
    b974:	49 01 c6             	add    %rax,%r14
    b977:	41 0f b6 06          	movzbl (%r14),%eax
    b97b:	84 c0                	test   %al,%al
    b97d:	74 21                	je     b9a0 <fwp_main_thread+0xcc0>
    b97f:	3c 01                	cmp    $0x1,%al
    b981:	0f 84 33 01 00 00    	je     baba <fwp_main_thread+0xdda>
    b987:	3c ff                	cmp    $0xff,%al
    b989:	0f 84 78 01 00 00    	je     bb07 <fwp_main_thread+0xe27>
    b98f:	83 e8 01             	sub    $0x1,%eax
    b992:	41 88 06             	mov    %al,(%r14)
    b995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b99c:	00 00 00 00 
    b9a0:	48 8b 04 24          	mov    (%rsp),%rax
    b9a4:	48 8b 40 10          	mov    0x10(%rax),%rax
    b9a8:	48 89 04 24          	mov    %rax,(%rsp)
    b9ac:	48 85 c0             	test   %rax,%rax
    b9af:	0f 84 db 00 00 00    	je     ba90 <fwp_main_thread+0xdb0>
    b9b5:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b9bc:	00 
    b9bd:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b9c4:	00 
    b9c5:	e9 86 fd ff ff       	jmp    b750 <fwp_main_thread+0xa70>
    b9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b9d0:	48 89 c2             	mov    %rax,%rdx
    b9d3:	83 e0 01             	and    $0x1,%eax
    b9d6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b9da:	48 d1 ea             	shr    $1,%rdx
    b9dd:	48 09 c2             	or     %rax,%rdx
    b9e0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    b9e5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    b9e9:	e9 95 f9 ff ff       	jmp    b383 <fwp_main_thread+0x6a3>
    b9ee:	66 90                	xchg   %ax,%ax
    b9f0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b9f4:	e9 ee f4 ff ff       	jmp    aee7 <fwp_main_thread+0x207>
    b9f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ba00:	66 85 c0             	test   %ax,%ax
    ba03:	0f 85 c6 fd ff ff    	jne    b7cf <fwp_main_thread+0xaef>
    ba09:	e9 9b fd ff ff       	jmp    b7a9 <fwp_main_thread+0xac9>
    ba0e:	66 90                	xchg   %ax,%ax
    ba10:	66 85 c0             	test   %ax,%ax
    ba13:	0f 85 33 fd ff ff    	jne    b74c <fwp_main_thread+0xa6c>
    ba19:	e9 12 fd ff ff       	jmp    b730 <fwp_main_thread+0xa50>
    ba1e:	66 90                	xchg   %ax,%ax
    ba20:	66 85 c0             	test   %ax,%ax
    ba23:	0f 85 79 fc ff ff    	jne    b6a2 <fwp_main_thread+0x9c2>
    ba29:	e9 64 fc ff ff       	jmp    b692 <fwp_main_thread+0x9b2>
    ba2e:	66 90                	xchg   %ax,%ax
    ba30:	66 85 c0             	test   %ax,%ax
    ba33:	0f 85 d3 fb ff ff    	jne    b60c <fwp_main_thread+0x92c>
    ba39:	e9 be fb ff ff       	jmp    b5fc <fwp_main_thread+0x91c>
    ba3e:	66 90                	xchg   %ax,%ax
    ba40:	48 89 d7             	mov    %rdx,%rdi
    ba43:	48 89 14 24          	mov    %rdx,(%rsp)
    ba47:	e8 84 9d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ba4c:	48 8b 14 24          	mov    (%rsp),%rdx
    ba50:	e9 83 fa ff ff       	jmp    b4d8 <fwp_main_thread+0x7f8>
    ba55:	66 85 c0             	test   %ax,%ax
    ba58:	0f 85 42 ff ff ff    	jne    b9a0 <fwp_main_thread+0xcc0>
    ba5e:	e9 14 ff ff ff       	jmp    b977 <fwp_main_thread+0xc97>
    ba63:	66 45 85 ff          	test   %r15w,%r15w
    ba67:	0f 85 6d fe ff ff    	jne    b8da <fwp_main_thread+0xbfa>
    ba6d:	e9 5a fe ff ff       	jmp    b8cc <fwp_main_thread+0xbec>
    ba72:	48 83 3d 7e cd 05 00 	cmpq   $0x0,0x5cd7e(%rip)        # 687f8 <fwp_root>
    ba79:	00 
    ba7a:	c7 05 fc 45 01 00 00 	movl   $0x0,0x145fc(%rip)        # 20080 <fwp_exit_code>
    ba81:	00 00 00 
    ba84:	0f 84 5e f7 ff ff    	je     b1e8 <fwp_main_thread+0x508>
    ba8a:	e9 c1 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ba8f:	90                   	nop
    ba90:	4c 89 ef             	mov    %r13,%rdi
    ba93:	e8 48 b3 ff ff       	call   6de0 <fwp_drop0>
    ba98:	48 89 df             	mov    %rbx,%rdi
    ba9b:	e8 40 b3 ff ff       	call   6de0 <fwp_drop0>
    baa0:	48 c7 05 bd 45 00 00 	movq   $0x0,0x45bd(%rip)        # 10068 <v.2>
    baa7:	00 00 00 00 
    baab:	c7 05 bb 45 00 00 01 	movl   $0x1,0x45bb(%rip)        # 10070 <st.3>
    bab2:	00 00 00 
    bab5:	e9 79 f3 ff ff       	jmp    ae33 <fwp_main_thread+0x153>
    baba:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    babf:	e8 ec af ff ff       	call   6ab0 <fwp_rc_free_arr>
    bac4:	e9 d7 fe ff ff       	jmp    b9a0 <fwp_main_thread+0xcc0>
    bac9:	4c 89 ef             	mov    %r13,%rdi
    bacc:	e8 ff 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bad1:	e9 31 fb ff ff       	jmp    b607 <fwp_main_thread+0x927>
    bad6:	4c 89 ef             	mov    %r13,%rdi
    bad9:	e8 f2 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bade:	e9 ba fb ff ff       	jmp    b69d <fwp_main_thread+0x9bd>
    bae3:	4c 89 f7             	mov    %r14,%rdi
    bae6:	e8 e5 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    baeb:	e9 4a fc ff ff       	jmp    b73a <fwp_main_thread+0xa5a>
    baf0:	e8 bb 9b ff ff       	call   56b0 <fwp_rc_wide_dup>
    baf5:	e9 d5 fc ff ff       	jmp    b7cf <fwp_main_thread+0xaef>
    bafa:	4c 89 f7             	mov    %r14,%rdi
    bafd:	e8 ce 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb02:	e9 cf fd ff ff       	jmp    b8d6 <fwp_main_thread+0xbf6>
    bb07:	4c 89 f0             	mov    %r14,%rax
    bb0a:	48 c1 e8 11          	shr    $0x11,%rax
    bb0e:	4c 31 f0             	xor    %r14,%rax
    bb11:	48 89 c2             	mov    %rax,%rdx
    bb14:	48 c1 ea 09          	shr    $0x9,%rdx
    bb18:	48 31 d0             	xor    %rdx,%rax
    bb1b:	0f b6 d0             	movzbl %al,%edx
    bb1e:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bb25:	00 
    bb26:	48 85 c0             	test   %rax,%rax
    bb29:	75 1e                	jne    bb49 <fwp_main_thread+0xe69>
    bb2b:	eb 66                	jmp    bb93 <fwp_main_thread+0xeb3>
    bb2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bb34:	00 
    bb35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bb3c:	00 00 00 00 
    bb40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bb44:	48 85 c0             	test   %rax,%rax
    bb47:	74 4a                	je     bb93 <fwp_main_thread+0xeb3>
    bb49:	48 89 c2             	mov    %rax,%rdx
    bb4c:	4c 3b 30             	cmp    (%rax),%r14
    bb4f:	75 ef                	jne    bb40 <fwp_main_thread+0xe60>
    bb51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    bb55:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    bb59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bb5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bb64:	0f 85 36 fe ff ff    	jne    b9a0 <fwp_main_thread+0xcc0>
    bb6a:	4c 89 f7             	mov    %r14,%rdi
    bb6d:	e8 5e 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb72:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bb76:	e9 25 fe ff ff       	jmp    b9a0 <fwp_main_thread+0xcc0>
    bb7b:	48 8d 3d b6 0f 00 00 	lea    0xfb6(%rip),%rdi        # cb38 <_IO_stdin_used+0xb38>
    bb82:	e8 c9 88 ff ff       	call   4450 <fwp_trap>
    bb87:	48 8d 3d 34 07 00 00 	lea    0x734(%rip),%rdi        # c2c2 <_IO_stdin_used+0x2c2>
    bb8e:	e8 6d 84 ff ff       	call   4000 <ad_raw_fail>
    bb93:	48 8d 3d 46 0e 00 00 	lea    0xe46(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    bb9a:	e8 b1 88 ff ff       	call   4450 <fwp_trap>
    bb9f:	e8 ac 78 ff ff       	call   3450 <__stack_chk_fail@plt>
    bba4:	48 8d 3d 32 07 00 00 	lea    0x732(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    bbab:	e8 a0 88 ff ff       	call   4450 <fwp_trap>
    bbb0:	e9 9b 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bbb5:	e9 96 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bbba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000bbc0 <__divmodti4>:
    bbc0:	f3 0f 1e fa          	endbr64
    bbc4:	55                   	push   %rbp
    bbc5:	49 89 f1             	mov    %rsi,%r9
    bbc8:	49 89 d2             	mov    %rdx,%r10
    bbcb:	48 89 fe             	mov    %rdi,%rsi
    bbce:	49 89 cb             	mov    %rcx,%r11
    bbd1:	48 89 e5             	mov    %rsp,%rbp
    bbd4:	41 57                	push   %r15
    bbd6:	41 56                	push   %r14
    bbd8:	41 55                	push   %r13
    bbda:	41 54                	push   %r12
    bbdc:	53                   	push   %rbx
    bbdd:	4c 89 c3             	mov    %r8,%rbx
    bbe0:	45 31 c0             	xor    %r8d,%r8d
    bbe3:	4d 85 c9             	test   %r9,%r9
    bbe6:	79 12                	jns    bbfa <__divmodti4+0x3a>
    bbe8:	31 ff                	xor    %edi,%edi
    bbea:	48 f7 de             	neg    %rsi
    bbed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bbf4:	4c 19 cf             	sbb    %r9,%rdi
    bbf7:	49 89 f9             	mov    %rdi,%r9
    bbfa:	4c 89 d8             	mov    %r11,%rax
    bbfd:	4d 85 db             	test   %r11,%r11
    bc00:	0f 88 1a 01 00 00    	js     bd20 <__divmodti4+0x160>
    bc06:	4c 89 d9             	mov    %r11,%rcx
    bc09:	49 89 f3             	mov    %rsi,%r11
    bc0c:	75 62                	jne    bc70 <__divmodti4+0xb0>
    bc0e:	4d 89 c4             	mov    %r8,%r12
    bc11:	4d 39 d1             	cmp    %r10,%r9
    bc14:	0f 83 46 01 00 00    	jae    bd60 <__divmodti4+0x1a0>
    bc1a:	4c 89 d8             	mov    %r11,%rax
    bc1d:	4c 89 ca             	mov    %r9,%rdx
    bc20:	49 f7 f2             	div    %r10
    bc23:	49 89 c3             	mov    %rax,%r11
    bc26:	31 c0                	xor    %eax,%eax
    bc28:	48 89 d6             	mov    %rdx,%rsi
    bc2b:	31 ff                	xor    %edi,%edi
    bc2d:	4c 89 d9             	mov    %r11,%rcx
    bc30:	48 89 c2             	mov    %rax,%rdx
    bc33:	48 89 c8             	mov    %rcx,%rax
    bc36:	4d 85 e4             	test   %r12,%r12
    bc39:	74 0a                	je     bc45 <__divmodti4+0x85>
    bc3b:	48 f7 d8             	neg    %rax
    bc3e:	48 83 d2 00          	adc    $0x0,%rdx
    bc42:	48 f7 da             	neg    %rdx
    bc45:	4d 85 c0             	test   %r8,%r8
    bc48:	74 0a                	je     bc54 <__divmodti4+0x94>
    bc4a:	48 f7 de             	neg    %rsi
    bc4d:	48 83 d7 00          	adc    $0x0,%rdi
    bc51:	48 f7 df             	neg    %rdi
    bc54:	48 89 33             	mov    %rsi,(%rbx)
    bc57:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bc5b:	5b                   	pop    %rbx
    bc5c:	41 5c                	pop    %r12
    bc5e:	41 5d                	pop    %r13
    bc60:	41 5e                	pop    %r14
    bc62:	41 5f                	pop    %r15
    bc64:	5d                   	pop    %rbp
    bc65:	c3                   	ret
    bc66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc6d:	00 00 00 
    bc70:	4d 89 c4             	mov    %r8,%r12
    bc73:	49 39 c1             	cmp    %rax,%r9
    bc76:	0f 82 ce 00 00 00    	jb     bd4a <__divmodti4+0x18a>
    bc7c:	31 ff                	xor    %edi,%edi
    bc7e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bc83:	48 63 c7             	movslq %edi,%rax
    bc86:	be 40 00 00 00       	mov    $0x40,%esi
    bc8b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bc90:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bc95:	48 29 c6             	sub    %rax,%rsi
    bc98:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bc9d:	48 09 c8             	or     %rcx,%rax
    bca0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bca5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bcaa:	49 89 c6             	mov    %rax,%r14
    bcad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bcb1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bcb6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bcbb:	49 09 c1             	or     %rax,%r9
    bcbe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bcc2:	4c 89 c8             	mov    %r9,%rax
    bcc5:	49 f7 f6             	div    %r14
    bcc8:	48 89 d1             	mov    %rdx,%rcx
    bccb:	49 89 c3             	mov    %rax,%r11
    bcce:	49 89 c1             	mov    %rax,%r9
    bcd1:	49 f7 e2             	mul    %r10
    bcd4:	49 89 c6             	mov    %rax,%r14
    bcd7:	49 89 d2             	mov    %rdx,%r10
    bcda:	48 39 d1             	cmp    %rdx,%rcx
    bcdd:	72 07                	jb     bce6 <__divmodti4+0x126>
    bcdf:	75 17                	jne    bcf8 <__divmodti4+0x138>
    bce1:	49 39 c7             	cmp    %rax,%r15
    bce4:	73 12                	jae    bcf8 <__divmodti4+0x138>
    bce6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bcea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bcee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bcf2:	49 89 d2             	mov    %rdx,%r10
    bcf5:	49 89 c6             	mov    %rax,%r14
    bcf8:	4c 89 f8             	mov    %r15,%rax
    bcfb:	4c 29 f0             	sub    %r14,%rax
    bcfe:	4c 19 d1             	sbb    %r10,%rcx
    bd01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bd06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bd0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bd10:	48 09 c6             	or     %rax,%rsi
    bd13:	48 89 cf             	mov    %rcx,%rdi
    bd16:	31 c0                	xor    %eax,%eax
    bd18:	4c 89 c9             	mov    %r9,%rcx
    bd1b:	e9 10 ff ff ff       	jmp    bc30 <__divmodti4+0x70>
    bd20:	4c 89 d0             	mov    %r10,%rax
    bd23:	4c 89 da             	mov    %r11,%rdx
    bd26:	4d 89 c4             	mov    %r8,%r12
    bd29:	49 89 f3             	mov    %rsi,%r11
    bd2c:	48 f7 d8             	neg    %rax
    bd2f:	49 f7 d4             	not    %r12
    bd32:	48 83 d2 00          	adc    $0x0,%rdx
    bd36:	49 89 c2             	mov    %rax,%r10
    bd39:	48 f7 da             	neg    %rdx
    bd3c:	48 89 d1             	mov    %rdx,%rcx
    bd3f:	0f 84 cc fe ff ff    	je     bc11 <__divmodti4+0x51>
    bd45:	49 39 d1             	cmp    %rdx,%r9
    bd48:	73 46                	jae    bd90 <__divmodti4+0x1d0>
    bd4a:	4c 89 cf             	mov    %r9,%rdi
    bd4d:	31 c0                	xor    %eax,%eax
    bd4f:	31 c9                	xor    %ecx,%ecx
    bd51:	e9 da fe ff ff       	jmp    bc30 <__divmodti4+0x70>
    bd56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd5d:	00 00 00 
    bd60:	4d 85 d2             	test   %r10,%r10
    bd63:	75 0d                	jne    bd72 <__divmodti4+0x1b2>
    bd65:	b8 01 00 00 00       	mov    $0x1,%eax
    bd6a:	31 d2                	xor    %edx,%edx
    bd6c:	49 f7 f2             	div    %r10
    bd6f:	49 89 c2             	mov    %rax,%r10
    bd72:	4c 89 c8             	mov    %r9,%rax
    bd75:	31 d2                	xor    %edx,%edx
    bd77:	49 f7 f2             	div    %r10
    bd7a:	49 89 c1             	mov    %rax,%r9
    bd7d:	4c 89 d8             	mov    %r11,%rax
    bd80:	49 f7 f2             	div    %r10
    bd83:	49 89 c3             	mov    %rax,%r11
    bd86:	4c 89 c8             	mov    %r9,%rax
    bd89:	e9 9a fe ff ff       	jmp    bc28 <__divmodti4+0x68>
    bd8e:	66 90                	xchg   %ax,%ax
    bd90:	45 31 f6             	xor    %r14d,%r14d
    bd93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bd98:	44 89 f7             	mov    %r14d,%edi
    bd9b:	45 85 f6             	test   %r14d,%r14d
    bd9e:	0f 85 df fe ff ff    	jne    bc83 <__divmodti4+0xc3>
    bda4:	4c 39 ca             	cmp    %r9,%rdx
    bda7:	72 17                	jb     bdc0 <__divmodti4+0x200>
    bda9:	31 c9                	xor    %ecx,%ecx
    bdab:	48 39 c6             	cmp    %rax,%rsi
    bdae:	73 10                	jae    bdc0 <__divmodti4+0x200>
    bdb0:	4c 89 cf             	mov    %r9,%rdi
    bdb3:	31 c0                	xor    %eax,%eax
    bdb5:	e9 76 fe ff ff       	jmp    bc30 <__divmodti4+0x70>
    bdba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bdc0:	4c 89 de             	mov    %r11,%rsi
    bdc3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bdc8:	48 29 c6             	sub    %rax,%rsi
    bdcb:	49 19 d1             	sbb    %rdx,%r9
    bdce:	eb e0                	jmp    bdb0 <__divmodti4+0x1f0>

000000000000bdd0 <atexit>:
    bdd0:	f3 0f 1e fa          	endbr64
    bdd4:	48 8b 15 2d 42 00 00 	mov    0x422d(%rip),%rdx        # 10008 <__dso_handle>
    bddb:	31 f6                	xor    %esi,%esi
    bddd:	e9 5e 78 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bde4 <_fini>:
    bde4:	f3 0f 1e fa          	endbr64
    bde8:	48 83 ec 08          	sub    $0x8,%rsp
    bdec:	48 83 c4 08          	add    $0x8,%rsp
    bdf0:	c3                   	ret
