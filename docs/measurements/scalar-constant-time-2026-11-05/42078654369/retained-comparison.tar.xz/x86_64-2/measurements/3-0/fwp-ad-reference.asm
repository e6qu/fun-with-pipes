
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # efd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 bd 00 00    	push   0xbde2(%rip)        # ee08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 bd 00 00    	jmp    *0xbde4(%rip)        # ee10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e bc 00 00    	jmp    *0xbc4e(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # ee70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # ee78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # ee80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # ee88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ee90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ee98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eeb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eeb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # eed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # eed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # eee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # eee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # eef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # eef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # ef70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # ef78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # ef80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # ef88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # ef90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # ef98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 b8 00 00    	jmp    *0xb8e6(%rip)        # efa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de b8 00 00    	jmp    *0xb8de(%rip)        # efa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 b8 00 00    	jmp    *0xb8d6(%rip)        # efb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce b8 00 00    	jmp    *0xb8ce(%rip)        # efb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 b8 00 00    	jmp    *0xb8c6(%rip)        # efc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 79 00 00 	lea    0x797a(%rip),%r9        # b091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 79 00 00 	lea    0x7977(%rip),%r8        # b095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 9b 00 00 	lea    0x9ba1(%rip),%rax        # d320 <fwp_fn_table>
    377f:	48 89 05 52 dc 01 00 	mov    %rax,0x1dc52(%rip)        # 213d8 <fwp_fns>
    3786:	48 8b 05 93 b8 00 00 	mov    0xb893(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c dc 01 00 	mov    %rax,0x1dc4c(%rip)        # 213e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 2f 7a 00 00 	lea    0x7a2f(%rip),%rdi        # b1cf <_IO_stdin_used+0x1cf>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 b8 00 00 	mov    0xb818(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 bf 57 00 00 	lea    0x57bf(%rip),%rdx        # 9020 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 b7 00 00 	mov    0xb783(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f0a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d df 78 00 00 	lea    0x78df(%rip),%rdi        # b1d8 <_IO_stdin_used+0x1d8>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d e6 7f 00 00 	lea    0x7fe6(%rip),%rdi        # b8f0 <_IO_stdin_used+0x8f0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d a0 7f 00 00 	lea    0x7fa0(%rip),%rdi        # b8c8 <_IO_stdin_used+0x8c8>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 64 7f 00 00 	lea    0x7f64(%rip),%rdi        # b898 <_IO_stdin_used+0x898>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d 30 7f 00 00 	lea    0x7f30(%rip),%rdi        # b870 <_IO_stdin_used+0x870>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 b6 00 00    	call   *0xb653(%rip)        # efc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 b6 00 00 	lea    0xb691(%rip),%rdi        # f018 <__TMC_END__>
    3987:	48 8d 05 8a b6 00 00 	lea    0xb68a(%rip),%rax        # f018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 b6 00 00 	mov    0xb636(%rip),%rax        # efd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 b6 00 00 	lea    0xb661(%rip),%rdi        # f018 <__TMC_END__>
    39b7:	48 8d 35 5a b6 00 00 	lea    0xb65a(%rip),%rsi        # f018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 b6 00 00 	mov    0xb605(%rip),%rax        # efe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d b6 00 00 00 	cmpb   $0x0,0xb64d(%rip)        # f048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 b5 00 00 	cmpq   $0x0,0xb5e2(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 b5 00 00 	mov    0xb5f6(%rip),%rdi        # f008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 b6 00 00 01 	movb   $0x1,0xb625(%rip)        # f048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee b4 01 00 	add    0x1b4ee(%rip),%rdx        # 1f110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc b4 01 00 	add    0x1b4dc(%rip),%rax        # 1f110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 d7 01 00 	mov    0x1d769(%rip),%rdi        # 213e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 b3 00 00 	mov    0xb394(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 b3 00 00 	mov    0xb381(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 73 00 00 	lea    0x7345(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 ba 01 00 	mov    0x1ba61(%rip),%rax        # 1f760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 b3 01 00 	mov    0x1b3a1(%rip),%rax        # 1f120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d b3 01 00 	sub    0x1b38d(%rip),%rax        # 1f118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 0d 7c 00 00 	lea    0x7c0d(%rip),%rsi        # b9d0 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b cd 01 00 	mov    0x1cd7b(%rip),%rax        # 20b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 cd 01 00 	lea    0x1cd74(%rip),%r8        # 20b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 cd 01 00 	mov    0x1cd55(%rip),%rbx        # 20b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 cd 01 00 	mov    0x1cd65(%rip),%rcx        # 20b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 cd 01 00 	mov    0x1cd01(%rip),%rdi        # 20b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a cd 01 00 	sub    %rsi,0x1cd4a(%rip)        # 20bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da cc 01 00 	mov    0x1ccda(%rip),%rax        # 20b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 cc 01 00 	add    0x1cc90(%rip),%rdi        # 20b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e cc 01 00 	mov    0x1cc9e(%rip),%rsi        # 20b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac cc 01 00 	mov    0x1ccac(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b cc 01 00 	mov    %r12,0x1cc5b(%rip)        # 20b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 cc 01 00 	mov    %rbp,0x1cc49(%rip)        # 20b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e cc 01 00 	cmp    %rdi,0x1cc2e(%rip)        # 20b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 cc 01 00 	mov    %rdi,0x1cc25(%rip)        # 20b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 cc 01 00 	sub    %rdi,0x1cc69(%rip)        # 20bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 cc 01 00 	mov    0x1cc11(%rip),%rax        # 20b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a cc 01 00 	lea    0x1cc0a(%rip),%r8        # 20b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd af 00 00 	mov    0xaffd(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 6f 00 00 	lea    0x6fb4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 b6 01 00 	cmp    0x1b6a9(%rip),%rdi        # 1f760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f b6 01 00 	mov    0x1b66f(%rip),%rax        # 1f740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d b6 01 00 	mov    %rdi,0x1b64d(%rip)        # 1f740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 b6 01 00 	mov    %rdi,0x1b629(%rip)        # 1f748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 6f 00 00 	lea    0x6fdb(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 6e 00 00 	lea    0x6ea7(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 ae 00 00 	mov    0xae78(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 6e 00 00 	lea    0x6e51(%rip),%rdx        # b020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 ae 00 00 	mov    0xae60(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 ad 00 00 	mov    0xad71(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 6d 00 00 	lea    0x6d28(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 6d 00 00 	lea    0x6d32(%rip),%rdi        # b02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 6c 00 00 	lea    0x6cba(%rip),%rdi        # b049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 48 72 00 00 	lea    0x7248(%rip),%rdi        # b5e8 <_IO_stdin_used+0x5e8>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 30 76 00 	movdqa 0x7630(%rip),%xmm0        # b9f0 <msg.8+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba cf 01 00 	add    0x1cfba(%rip),%rax        # 213d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d a4 71 00 00 	lea    0x71a4(%rip),%rdi        # b618 <_IO_stdin_used+0x618>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 ac 01 00 	cmp    %rax,0x1ac75(%rip)        # 1f108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 ac 01 00 	add    0x1ac70(%rip),%rax        # 1f110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d 8d 71 00 00 	lea    0x718d(%rip),%rdi        # b648 <_IO_stdin_used+0x648>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 6b 00 00 	lea    0x6b92(%rip),%r8        # b065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 69 00 00 	lea    0x69e7(%rip),%r8        # b074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 68 00 00 	lea    0x6874(%rip),%r8        # b06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 66 00 00 	lea    0x664c(%rip),%rdi        # b079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 67 00 00 	lea    0x6736(%rip),%rsi        # b184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 c0 01 00 	mov    0x1c085(%rip),%r9        # 20b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de c0 01 00 	mov    0x1c0de(%rip),%r8        # 20ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 c7 6b 00 00 	lea    0x6bc7(%rip),%rdx        # b698 <_IO_stdin_used+0x698>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 c0 01 00 	mov    0x1c0c6(%rip),%rcx        # 20ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 c0 01 	movsd  0x1c0d4(%rip),%xmm1        # 20bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 c0 01 	movsd  0x1c0c4(%rip),%xmm0        # 20bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 a5 00 00 	mov    0xa545(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 c8 6e 00 	movdqa 0x6ec8(%rip),%xmm0        # ba00 <msg.8+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f bb 01 00 	lea    0x1bb7f(%rip),%rax        # 206c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 f1 6e 00 	movdqa 0x6ef1(%rip),%xmm2        # ba40 <msg.8+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 bb 01 00 	movaps %xmm0,0x1bb25(%rip)        # 20680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 ad 6e 00 	movdqa 0x6ead(%rip),%xmm0        # ba10 <msg.8+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 bf 01 00 01 	movl   $0x1,0x1bfb3(%rip)        # 20b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 bb 01 00 	movaps %xmm0,0x1bb13(%rip)        # 20690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 9b 6e 00 	movdqa 0x6e9b(%rip),%xmm0        # ba20 <msg.8+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 bb 01 00 	movaps %xmm0,0x1bb14(%rip)        # 206a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 9c 6e 00 	movdqa 0x6e9c(%rip),%xmm0        # ba30 <msg.8+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 bb 01 00 	movaps %xmm0,0x1bb15(%rip)        # 206b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 ab 01 00 	lea    0x1ab95(%rip),%r8        # 1f780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 be 01 00 	mov    %rax,0x1beb0(%rip)        # 20b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e be 01 00 	mov    %r12,0x1be8e(%rip)        # 20b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 be 01 00 	mov    %rax,0x1be77(%rip)        # 20b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 be 01 00 	mov    %rbx,0x1be90(%rip)        # 20b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 be 01 00 	mov    %rsi,0x1beb9(%rip)        # 20b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 63 00 00 	lea    0x63d6(%rip),%rdi        # b0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 be 01 00 	mov    %rax,0x1be98(%rip)        # 20b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c be 01 00    	mov    %eax,0x1be1c(%rip)        # 20b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <caf75>:
    4d20:	8b 15 52 a3 00 00    	mov    0xa352(%rip),%edx        # f078 <st.4>
    4d26:	85 d2                	test   %edx,%edx
    4d28:	74 0e                	je     4d38 <caf75+0x18>
    4d2a:	48 8b 05 3f a3 00 00 	mov    0xa33f(%rip),%rax        # f070 <v.3>
    4d31:	c3                   	ret
    4d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d38:	8b 05 2a a3 00 00    	mov    0xa32a(%rip),%eax        # f068 <st.2>
    4d3e:	85 c0                	test   %eax,%eax
    4d40:	74 1e                	je     4d60 <caf75+0x40>
    4d42:	48 8b 05 17 a3 00 00 	mov    0xa317(%rip),%rax        # f060 <v.1>
    4d49:	48 89 05 20 a3 00 00 	mov    %rax,0xa320(%rip)        # f070 <v.3>
    4d50:	c7 05 1e a3 00 00 01 	movl   $0x1,0xa31e(%rip)        # f078 <st.4>
    4d57:	00 00 00 
    4d5a:	c3                   	ret
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4d67:	00 f0 3f 
    4d6a:	c7 05 f4 a2 00 00 01 	movl   $0x1,0xa2f4(%rip)        # f068 <st.2>
    4d71:	00 00 00 
    4d74:	48 89 05 e5 a2 00 00 	mov    %rax,0xa2e5(%rip)        # f060 <v.1>
    4d7b:	eb cc                	jmp    4d49 <caf75+0x29>
    4d7d:	0f 1f 00             	nopl   (%rax)

0000000000004d80 <fwp_wake_io>:
    4d80:	48 8b 07             	mov    (%rdi),%rax
    4d83:	48 85 c0             	test   %rax,%rax
    4d86:	0f 84 f4 00 00 00    	je     4e80 <fwp_wake_io+0x100>
    4d8c:	53                   	push   %rbx
    4d8d:	4c 8b 05 ac a9 01 00 	mov    0x1a9ac(%rip),%r8        # 1f740 <fwp_ready_tail>
    4d94:	49 89 f9             	mov    %rdi,%r9
    4d97:	48 89 c2             	mov    %rax,%rdx
    4d9a:	45 31 db             	xor    %r11d,%r11d
    4d9d:	45 31 d2             	xor    %r10d,%r10d
    4da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4da4:	eb 71                	jmp    4e17 <fwp_wake_io+0x97>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4db7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dbe:	48 85 c9             	test   %rcx,%rcx
    4dc1:	74 07                	je     4dca <fwp_wake_io+0x4a>
    4dc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4dca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4dd1:	00 00 00 00 
    4dd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ddc:	49 8b 01             	mov    (%r9),%rax
    4ddf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4de3:	75 2a                	jne    4e0f <fwp_wake_io+0x8f>
    4de5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4de9:	75 24                	jne    4e0f <fwp_wake_io+0x8f>
    4deb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4def:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4df6:	00 00 00 00 
    4dfa:	4d 85 c0             	test   %r8,%r8
    4dfd:	74 51                	je     4e50 <fwp_wake_io+0xd0>
    4dff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4e06:	49 89 d0             	mov    %rdx,%r8
    4e09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4e0f:	48 89 c2             	mov    %rax,%rdx
    4e12:	48 85 c0             	test   %rax,%rax
    4e15:	74 49                	je     4e60 <fwp_wake_io+0xe0>
    4e17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4e1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4e22:	48 85 ff             	test   %rdi,%rdi
    4e25:	74 b8                	je     4ddf <fwp_wake_io+0x5f>
    4e27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4e2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4e35:	48 85 f6             	test   %rsi,%rsi
    4e38:	0f 85 72 ff ff ff    	jne    4db0 <fwp_wake_io+0x30>
    4e3e:	48 89 0f             	mov    %rcx,(%rdi)
    4e41:	e9 78 ff ff ff       	jmp    4dbe <fwp_wake_io+0x3e>
    4e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e4d:	00 00 00 
    4e50:	48 89 d3             	mov    %rdx,%rbx
    4e53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4e59:	eb ab                	jmp    4e06 <fwp_wake_io+0x86>
    4e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e60:	45 84 db             	test   %r11b,%r11b
    4e63:	74 07                	je     4e6c <fwp_wake_io+0xec>
    4e65:	48 89 1d dc a8 01 00 	mov    %rbx,0x1a8dc(%rip)        # 1f748 <fwp_ready_head>
    4e6c:	45 84 d2             	test   %r10b,%r10b
    4e6f:	74 07                	je     4e78 <fwp_wake_io+0xf8>
    4e71:	4c 89 05 c8 a8 01 00 	mov    %r8,0x1a8c8(%rip)        # 1f740 <fwp_ready_tail>
    4e78:	5b                   	pop    %rbx
    4e79:	c3                   	ret
    4e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e80:	c3                   	ret
    4e81:	0f 1f 40 00          	nopl   0x0(%rax)
    4e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e8c:	00 00 00 00 

0000000000004e90 <fwp_tape_buffers_release>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	53                   	push   %rbx
    4e95:	48 89 fb             	mov    %rdi,%rbx
    4e98:	48 83 ec 10          	sub    $0x10,%rsp
    4e9c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4ea0:	48 85 c0             	test   %rax,%rax
    4ea3:	0f 88 df 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4ea9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4ead:	48 85 d2             	test   %rdx,%rdx
    4eb0:	0f 88 d2 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4eb6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4ebc:	0f 87 c6 00 00 00    	ja     4f88 <fwp_tape_buffers_release+0xf8>
    4ec2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4ec6:	b8 00 00 08 00       	mov    $0x80000,%eax
    4ecb:	48 c1 e1 03          	shl    $0x3,%rcx
    4ecf:	48 29 c8             	sub    %rcx,%rax
    4ed2:	48 c1 e8 03          	shr    $0x3,%rax
    4ed6:	48 39 d0             	cmp    %rdx,%rax
    4ed9:	0f 82 a9 00 00 00    	jb     4f88 <fwp_tape_buffers_release+0xf8>
    4edf:	48 8d 3d d9 61 00 00 	lea    0x61d9(%rip),%rdi        # b0bf <_IO_stdin_used+0xbf>
    4ee6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4eeb:	48 89 14 24          	mov    %rdx,(%rsp)
    4eef:	e8 ac e4 ff ff       	call   33a0 <getenv@plt>
    4ef4:	48 8b 14 24          	mov    (%rsp),%rdx
    4ef8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4efd:	48 85 c0             	test   %rax,%rax
    4f00:	74 09                	je     4f0b <fwp_tape_buffers_release+0x7b>
    4f02:	80 38 30             	cmpb   $0x30,(%rax)
    4f05:	0f 84 9d 00 00 00    	je     4fa8 <fwp_tape_buffers_release+0x118>
    4f0b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4f0f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4f13:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4f1a:	77 78                	ja     4f94 <fwp_tape_buffers_release+0x104>
    4f1c:	48 8d 3d 9d a1 01 00 	lea    0x1a19d(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    4f23:	48 89 04 24          	mov    %rax,(%rsp)
    4f27:	e8 44 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4f2c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4f30:	48 8b 04 24          	mov    (%rsp),%rax
    4f34:	0f 29 05 85 a1 01 00 	movaps %xmm0,0x1a185(%rip)        # 1f0c0 <fwp_tape_workspace>
    4f3b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4f40:	48 89 05 61 a1 01 00 	mov    %rax,0x1a161(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    4f47:	0f 29 05 82 a1 01 00 	movaps %xmm0,0x1a182(%rip)        # 1f0d0 <fwp_tape_workspace+0x10>
    4f4e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4f53:	0f 29 05 86 a1 01 00 	movaps %xmm0,0x1a186(%rip)        # 1f0e0 <fwp_tape_workspace+0x20>
    4f5a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4f5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f62:	48 89 15 87 a1 01 00 	mov    %rdx,0x1a187(%rip)        # 1f0f0 <fwp_tape_workspace+0x30>
    4f69:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f70:	00 
    4f71:	0f 11 03             	movups %xmm0,(%rbx)
    4f74:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f78:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f7c:	48 83 c4 10          	add    $0x10,%rsp
    4f80:	5b                   	pop    %rbx
    4f81:	c3                   	ret
    4f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f88:	48 8d 3d 30 61 00 00 	lea    0x6130(%rip),%rdi        # b0bf <_IO_stdin_used+0xbf>
    4f8f:	e8 0c e4 ff ff       	call   33a0 <getenv@plt>
    4f94:	48 83 c4 10          	add    $0x10,%rsp
    4f98:	48 89 df             	mov    %rbx,%rdi
    4f9b:	5b                   	pop    %rbx
    4f9c:	e9 cf ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4fac:	0f 85 59 ff ff ff    	jne    4f0b <fwp_tape_buffers_release+0x7b>
    4fb2:	48 83 c4 10          	add    $0x10,%rsp
    4fb6:	48 89 df             	mov    %rbx,%rdi
    4fb9:	5b                   	pop    %rbx
    4fba:	e9 b1 ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fbf:	90                   	nop

0000000000004fc0 <fwp_poll_events>:
    4fc0:	53                   	push   %rbx
    4fc1:	48 83 ec 20          	sub    $0x20,%rsp
    4fc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4fcc:	00 00 
    4fce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4fd3:	31 c0                	xor    %eax,%eax
    4fd5:	e8 36 f3 ff ff       	call   4310 <fwp_now_ns>
    4fda:	48 8b 1d 57 a7 01 00 	mov    0x1a757(%rip),%rbx        # 1f738 <fwp_timers>
    4fe1:	48 85 db             	test   %rbx,%rbx
    4fe4:	0f 84 d6 00 00 00    	je     50c0 <fwp_poll_events+0x100>
    4fea:	48 89 c6             	mov    %rax,%rsi
    4fed:	48 89 da             	mov    %rbx,%rdx
    4ff0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4ff7:	eb 16                	jmp    500f <fwp_poll_events+0x4f>
    4ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5000:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5007:	48 89 c8             	mov    %rcx,%rax
    500a:	48 85 d2             	test   %rdx,%rdx
    500d:	74 31                	je     5040 <fwp_poll_events+0x80>
    500f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5013:	48 85 c0             	test   %rax,%rax
    5016:	78 e8                	js     5000 <fwp_poll_events+0x40>
    5018:	48 39 c1             	cmp    %rax,%rcx
    501b:	7c e3                	jl     5000 <fwp_poll_events+0x40>
    501d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5024:	48 85 d2             	test   %rdx,%rdx
    5027:	74 1c                	je     5045 <fwp_poll_events+0x85>
    5029:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    502d:	48 39 c1             	cmp    %rax,%rcx
    5030:	7c ce                	jl     5000 <fwp_poll_events+0x40>
    5032:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5039:	48 85 d2             	test   %rdx,%rdx
    503c:	75 d1                	jne    500f <fwp_poll_events+0x4f>
    503e:	66 90                	xchg   %ax,%ax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	78 7b                	js     50c0 <fwp_poll_events+0x100>
    5045:	48 29 f0             	sub    %rsi,%rax
    5048:	48 89 c1             	mov    %rax,%rcx
    504b:	48 85 c0             	test   %rax,%rax
    504e:	0f 8e 9c 00 00 00    	jle    50f0 <fwp_poll_events+0x130>
    5054:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    505b:	de 1b 43 
    505e:	48 f7 ea             	imul   %rdx
    5061:	48 89 c8             	mov    %rcx,%rax
    5064:	48 c1 f8 3f          	sar    $0x3f,%rax
    5068:	48 c1 fa 12          	sar    $0x12,%rdx
    506c:	48 29 c2             	sub    %rax,%rdx
    506f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5076:	48 39 c1             	cmp    %rax,%rcx
    5079:	0f 95 c0             	setne  %al
    507c:	0f b6 c0             	movzbl %al,%eax
    507f:	48 01 d0             	add    %rdx,%rax
    5082:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5088:	0f 8f 32 01 00 00    	jg     51c0 <fwp_poll_events+0x200>
    508e:	48 85 c0             	test   %rax,%rax
    5091:	74 5d                	je     50f0 <fwp_poll_events+0x130>
    5093:	89 c1                	mov    %eax,%ecx
    5095:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    509c:	48 c1 e9 26          	shr    $0x26,%rcx
    50a0:	48 63 d1             	movslq %ecx,%rdx
    50a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    50a9:	29 c8                	sub    %ecx,%eax
    50ab:	48 98                	cltq
    50ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    50b4:	e9 11 01 00 00       	jmp    51ca <fwp_poll_events+0x20a>
    50b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c0:	e8 ab eb ff ff       	call   3c70 <fwp_flush>
    50c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    50ca:	be 01 00 00 00       	mov    $0x1,%esi
    50cf:	48 8b 0d 6a 9f 00 00 	mov    0x9f6a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    50d6:	48 8d 3d 43 66 00 00 	lea    0x6643(%rip),%rdi        # b720 <_IO_stdin_used+0x720>
    50dd:	e8 9e e5 ff ff       	call   3680 <fwrite@plt>
    50e2:	bf 65 00 00 00       	mov    $0x65,%edi
    50e7:	e8 84 e5 ff ff       	call   3670 <exit@plt>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	e8 1b f2 ff ff       	call   4310 <fwp_now_ns>
    50f5:	48 89 c1             	mov    %rax,%rcx
    50f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fc:	eb 44                	jmp    5142 <fwp_poll_events+0x182>
    50fe:	66 90                	xchg   %ax,%ax
    5100:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5104:	75 33                	jne    5139 <fwp_poll_events+0x179>
    5106:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510a:	75 2d                	jne    5139 <fwp_poll_events+0x179>
    510c:	48 8b 05 2d a6 01 00 	mov    0x1a62d(%rip),%rax        # 1f740 <fwp_ready_tail>
    5113:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5117:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    511e:	00 00 00 00 
    5122:	48 85 c0             	test   %rax,%rax
    5125:	0f 84 05 01 00 00    	je     5230 <fwp_poll_events+0x270>
    512b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5132:	48 89 15 07 a6 01 00 	mov    %rdx,0x1a607(%rip)        # 1f740 <fwp_ready_tail>
    5139:	48 85 db             	test   %rbx,%rbx
    513c:	0f 84 be 00 00 00    	je     5200 <fwp_poll_events+0x240>
    5142:	48 89 da             	mov    %rbx,%rdx
    5145:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    514c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5150:	7f e7                	jg     5139 <fwp_poll_events+0x179>
    5152:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5156:	74 2e                	je     5186 <fwp_poll_events+0x1c6>
    5158:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    515f:	48 85 c0             	test   %rax,%rax
    5162:	0f 84 b8 00 00 00    	je     5220 <fwp_poll_events+0x260>
    5168:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    516f:	48 85 db             	test   %rbx,%rbx
    5172:	74 07                	je     517b <fwp_poll_events+0x1bb>
    5174:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    517b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    517f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5186:	48 8b 42 60          	mov    0x60(%rdx),%rax
    518a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    518e:	48 85 c0             	test   %rax,%rax
    5191:	0f 84 69 ff ff ff    	je     5100 <fwp_poll_events+0x140>
    5197:	48 39 c8             	cmp    %rcx,%rax
    519a:	0f 8f 60 ff ff ff    	jg     5100 <fwp_poll_events+0x140>
    51a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    51a4:	0f 85 56 ff ff ff    	jne    5100 <fwp_poll_events+0x140>
    51aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    51ae:	75 89                	jne    5139 <fwp_poll_events+0x179>
    51b0:	48 89 d7             	mov    %rdx,%rdi
    51b3:	e8 f8 ee ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    51b8:	e9 43 ff ff ff       	jmp    5100 <fwp_poll_events+0x140>
    51bd:	0f 1f 00             	nopl   (%rax)
    51c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    51c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    51ca:	48 89 e7             	mov    %rsp,%rdi
    51cd:	31 f6                	xor    %esi,%esi
    51cf:	48 89 14 24          	mov    %rdx,(%rsp)
    51d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    51d8:	e8 c3 e2 ff ff       	call   34a0 <nanosleep@plt>
    51dd:	48 8b 1d 54 a5 01 00 	mov    0x1a554(%rip),%rbx        # 1f738 <fwp_timers>
    51e4:	e8 27 f1 ff ff       	call   4310 <fwp_now_ns>
    51e9:	48 89 c1             	mov    %rax,%rcx
    51ec:	48 85 db             	test   %rbx,%rbx
    51ef:	0f 85 03 ff ff ff    	jne    50f8 <fwp_poll_events+0x138>
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5205:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    520c:	00 00 
    520e:	75 2c                	jne    523c <fwp_poll_events+0x27c>
    5210:	48 83 c4 20          	add    $0x20,%rsp
    5214:	5b                   	pop    %rbx
    5215:	c3                   	ret
    5216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    521d:	00 00 00 
    5220:	48 89 1d 11 a5 01 00 	mov    %rbx,0x1a511(%rip)        # 1f738 <fwp_timers>
    5227:	e9 43 ff ff ff       	jmp    516f <fwp_poll_events+0x1af>
    522c:	0f 1f 40 00          	nopl   0x0(%rax)
    5230:	48 89 15 11 a5 01 00 	mov    %rdx,0x1a511(%rip)        # 1f748 <fwp_ready_head>
    5237:	e9 f6 fe ff ff       	jmp    5132 <fwp_poll_events+0x172>
    523c:	e8 1f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    5241:	0f 1f 40 00          	nopl   0x0(%rax)
    5245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    524c:	00 00 00 00 

0000000000005250 <fwp_rc_wide_dup>:
    5250:	48 89 fa             	mov    %rdi,%rdx
    5253:	48 8d 35 26 a5 01 00 	lea    0x1a526(%rip),%rsi        # 1f780 <fwp_heap>
    525a:	48 83 ec 18          	sub    $0x18,%rsp
    525e:	48 89 f9             	mov    %rdi,%rcx
    5261:	48 c1 ea 11          	shr    $0x11,%rdx
    5265:	48 31 fa             	xor    %rdi,%rdx
    5268:	48 89 d0             	mov    %rdx,%rax
    526b:	48 c1 e8 09          	shr    $0x9,%rax
    526f:	48 31 c2             	xor    %rax,%rdx
    5272:	0f b6 d2             	movzbl %dl,%edx
    5275:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    527c:	00 
    527d:	49 8b 00             	mov    (%r8),%rax
    5280:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5287:	00 00 
    5289:	75 21                	jne    52ac <fwp_rc_wide_dup+0x5c>
    528b:	e9 98 00 00 00       	jmp    5328 <fwp_rc_wide_dup+0xd8>
    5290:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    529c:	00 00 00 00 
    52a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    52a4:	48 85 d2             	test   %rdx,%rdx
    52a7:	74 2f                	je     52d8 <fwp_rc_wide_dup+0x88>
    52a9:	48 89 d0             	mov    %rdx,%rax
    52ac:	48 3b 08             	cmp    (%rax),%rcx
    52af:	75 ef                	jne    52a0 <fwp_rc_wide_dup+0x50>
    52b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52b4:	74 7c                	je     5332 <fwp_rc_wide_dup+0xe2>
    52b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    52ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    52be:	0f 84 91 00 00 00    	je     5355 <fwp_rc_wide_dup+0x105>
    52c4:	48 83 c2 01          	add    $0x1,%rdx
    52c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    52cc:	48 83 c4 18          	add    $0x18,%rsp
    52d0:	c3                   	ret
    52d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    52dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52df:	75 68                	jne    5349 <fwp_rc_wide_dup+0xf9>
    52e1:	bf 18 00 00 00       	mov    $0x18,%edi
    52e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52eb:	4c 89 04 24          	mov    %r8,(%rsp)
    52ef:	e8 bc e2 ff ff       	call   35b0 <malloc@plt>
    52f4:	4c 8b 04 24          	mov    (%rsp),%r8
    52f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52fd:	48 85 c0             	test   %rax,%rax
    5300:	74 5f                	je     5361 <fwp_rc_wide_dup+0x111>
    5302:	48 89 08             	mov    %rcx,(%rax)
    5305:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    530c:	00 
    530d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5314:	00 
    5315:	49 89 00             	mov    %rax,(%r8)
    5318:	c6 01 ff             	movb   $0xff,(%rcx)
    531b:	48 83 05 a5 c0 01 00 	addq   $0x1,0x1c0a5(%rip)        # 213c8 <fwp_heap+0x1c48>
    5322:	01 
    5323:	48 83 c4 18          	add    $0x18,%rsp
    5327:	c3                   	ret
    5328:	80 3f fe             	cmpb   $0xfe,(%rdi)
    532b:	75 13                	jne    5340 <fwp_rc_wide_dup+0xf0>
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 af                	je     52e1 <fwp_rc_wide_dup+0x91>
    5332:	48 8d 3d 17 64 00 00 	lea    0x6417(%rip),%rdi        # b750 <_IO_stdin_used+0x750>
    5339:	e8 62 ee ff ff       	call   41a0 <fwp_trap>
    533e:	66 90                	xchg   %ax,%ax
    5340:	48 85 c0             	test   %rax,%rax
    5343:	0f 85 6d ff ff ff    	jne    52b6 <fwp_rc_wide_dup+0x66>
    5349:	48 8d 3d 28 64 00 00 	lea    0x6428(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    5350:	e8 4b ee ff ff       	call   41a0 <fwp_trap>
    5355:	48 8d 3d 74 5d 00 00 	lea    0x5d74(%rip),%rdi        # b0d0 <_IO_stdin_used+0xd0>
    535c:	e8 3f ee ff ff       	call   41a0 <fwp_trap>
    5361:	e8 4a e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    536d:	00 00 00 

0000000000005370 <fwp_rc_forget_slot>:
    5370:	80 3f ff             	cmpb   $0xff,(%rdi)
    5373:	74 0b                	je     5380 <fwp_rc_forget_slot+0x10>
    5375:	c3                   	ret
    5376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    537d:	00 00 00 
    5380:	48 89 f8             	mov    %rdi,%rax
    5383:	48 83 ec 08          	sub    $0x8,%rsp
    5387:	48 89 fa             	mov    %rdi,%rdx
    538a:	48 c1 e8 11          	shr    $0x11,%rax
    538e:	48 31 f8             	xor    %rdi,%rax
    5391:	48 89 c1             	mov    %rax,%rcx
    5394:	48 c1 e9 09          	shr    $0x9,%rcx
    5398:	48 31 c8             	xor    %rcx,%rax
    539b:	48 8d 0d de a3 01 00 	lea    0x1a3de(%rip),%rcx        # 1f780 <fwp_heap>
    53a2:	0f b6 c0             	movzbl %al,%eax
    53a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    53ac:	00 
    53ad:	48 85 ff             	test   %rdi,%rdi
    53b0:	74 3c                	je     53ee <fwp_rc_forget_slot+0x7e>
    53b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    53b9:	00 
    53ba:	48 8b 01             	mov    (%rcx),%rax
    53bd:	eb 11                	jmp    53d0 <fwp_rc_forget_slot+0x60>
    53bf:	90                   	nop
    53c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    53c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    53c8:	48 85 ff             	test   %rdi,%rdi
    53cb:	74 21                	je     53ee <fwp_rc_forget_slot+0x7e>
    53cd:	48 89 f8             	mov    %rdi,%rax
    53d0:	48 3b 10             	cmp    (%rax),%rdx
    53d3:	75 eb                	jne    53c0 <fwp_rc_forget_slot+0x50>
    53d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    53d9:	48 89 01             	mov    %rax,(%rcx)
    53dc:	e8 df df ff ff       	call   33c0 <free@plt>
    53e1:	48 83 2d df bf 01 00 	subq   $0x1,0x1bfdf(%rip)        # 213c8 <fwp_heap+0x1c48>
    53e8:	01 
    53e9:	48 83 c4 08          	add    $0x8,%rsp
    53ed:	c3                   	ret
    53ee:	48 8d 3d 83 63 00 00 	lea    0x6383(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    53f5:	e8 a6 ed ff ff       	call   41a0 <fwp_trap>
    53fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005400 <fwp_rc_prepare_chunk>:
    5400:	48 83 3d c0 bf 01 00 	cmpq   $0x0,0x1bfc0(%rip)        # 213c8 <fwp_heap+0x1c48>
    5407:	00 
    5408:	41 54                	push   %r12
    540a:	49 89 f4             	mov    %rsi,%r12
    540d:	55                   	push   %rbp
    540e:	48 89 fd             	mov    %rdi,%rbp
    5411:	53                   	push   %rbx
    5412:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5415:	0f 84 7d 00 00 00    	je     5498 <fwp_rc_prepare_chunk+0x98>
    541b:	31 db                	xor    %ebx,%ebx
    541d:	85 c0                	test   %eax,%eax
    541f:	75 5f                	jne    5480 <fwp_rc_prepare_chunk+0x80>
    5421:	48 85 f6             	test   %rsi,%rsi
    5424:	74 7c                	je     54a2 <fwp_rc_prepare_chunk+0xa2>
    5426:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    542a:	e8 91 df ff ff       	call   33c0 <free@plt>
    542f:	90                   	nop
    5430:	be 01 00 00 00       	mov    $0x1,%esi
    5435:	4c 89 e7             	mov    %r12,%rdi
    5438:	e8 e3 e0 ff ff       	call   3520 <calloc@plt>
    543d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5441:	48 85 c0             	test   %rax,%rax
    5444:	0f 85 87 00 00 00    	jne    54d1 <fwp_rc_prepare_chunk+0xd1>
    544a:	e8 61 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    544f:	90                   	nop
    5450:	e8 1b ff ff ff       	call   5370 <fwp_rc_forget_slot>
    5455:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5458:	48 83 c3 01          	add    $0x1,%rbx
    545c:	48 39 c3             	cmp    %rax,%rbx
    545f:	73 37                	jae    5498 <fwp_rc_prepare_chunk+0x98>
    5461:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5468:	00 00 
    546a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5471:	00 00 00 00 
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5484:	48 01 df             	add    %rbx,%rdi
    5487:	80 3f ff             	cmpb   $0xff,(%rdi)
    548a:	74 c4                	je     5450 <fwp_rc_prepare_chunk+0x50>
    548c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    548f:	48 83 c3 01          	add    $0x1,%rbx
    5493:	48 39 c3             	cmp    %rax,%rbx
    5496:	72 e8                	jb     5480 <fwp_rc_prepare_chunk+0x80>
    5498:	49 39 c4             	cmp    %rax,%r12
    549b:	75 13                	jne    54b0 <fwp_rc_prepare_chunk+0xb0>
    549d:	4d 85 e4             	test   %r12,%r12
    54a0:	75 46                	jne    54e8 <fwp_rc_prepare_chunk+0xe8>
    54a2:	5b                   	pop    %rbx
    54a3:	5d                   	pop    %rbp
    54a4:	41 5c                	pop    %r12
    54a6:	c3                   	ret
    54a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ae:	00 00 
    54b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54b4:	48 29 05 15 bf 01 00 	sub    %rax,0x1bf15(%rip)        # 213d0 <fwp_heap+0x1c50>
    54bb:	e8 00 df ff ff       	call   33c0 <free@plt>
    54c0:	4d 85 e4             	test   %r12,%r12
    54c3:	0f 85 67 ff ff ff    	jne    5430 <fwp_rc_prepare_chunk+0x30>
    54c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    54d0:	00 
    54d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    54d5:	5b                   	pop    %rbx
    54d6:	4c 01 25 f3 be 01 00 	add    %r12,0x1bef3(%rip)        # 213d0 <fwp_heap+0x1c50>
    54dd:	5d                   	pop    %rbp
    54de:	41 5c                	pop    %r12
    54e0:	c3                   	ret
    54e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54ec:	5b                   	pop    %rbx
    54ed:	4c 89 e2             	mov    %r12,%rdx
    54f0:	31 f6                	xor    %esi,%esi
    54f2:	5d                   	pop    %rbp
    54f3:	41 5c                	pop    %r12
    54f5:	e9 c6 df ff ff       	jmp    34c0 <memset@plt>
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005500 <fwp_heap_refill>:
    5500:	41 56                	push   %r14
    5502:	41 89 d6             	mov    %edx,%r14d
    5505:	41 55                	push   %r13
    5507:	41 89 f5             	mov    %esi,%r13d
    550a:	41 54                	push   %r12
    550c:	49 89 fc             	mov    %rdi,%r12
    550f:	bf 01 00 00 00       	mov    $0x1,%edi
    5514:	55                   	push   %rbp
    5515:	53                   	push   %rbx
    5516:	e8 c5 e8 ff ff       	call   3de0 <fwp_heap_chunks>
    551b:	48 89 c3             	mov    %rax,%rbx
    551e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5522:	48 8b 05 4f b6 01 00 	mov    0x1b64f(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    5529:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    552d:	48 8d 05 4c a2 01 00 	lea    0x1a24c(%rip),%rax        # 1f780 <fwp_heap>
    5534:	31 d2                	xor    %edx,%edx
    5536:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    553a:	48 89 ef             	mov    %rbp,%rdi
    553d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5541:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5545:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    554c:	00 
    554d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5552:	f7 f1                	div    %ecx
    5554:	31 d2                	xor    %edx,%edx
    5556:	66 0f 6e c1          	movd   %ecx,%xmm0
    555a:	66 0f 6e c8          	movd   %eax,%xmm1
    555e:	89 c6                	mov    %eax,%esi
    5560:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5565:	48 01 c8             	add    %rcx,%rax
    5568:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    556c:	48 f7 f1             	div    %rcx
    556f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5574:	89 45 18             	mov    %eax,0x18(%rbp)
    5577:	e8 84 fe ff ff       	call   5400 <fwp_rc_prepare_chunk>
    557c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    557f:	48 89 d8             	mov    %rbx,%rax
    5582:	48 c1 e0 10          	shl    $0x10,%rax
    5586:	48 03 05 a3 b5 01 00 	add    0x1b5a3(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    558d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5591:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5596:	8b 55 08             	mov    0x8(%rbp),%edx
    5599:	48 0f af d1          	imul   %rcx,%rdx
    559d:	48 01 c2             	add    %rax,%rdx
    55a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    55a5:	5b                   	pop    %rbx
    55a6:	5d                   	pop    %rbp
    55a7:	41 5c                	pop    %r12
    55a9:	41 5d                	pop    %r13
    55ab:	41 5e                	pop    %r14
    55ad:	c3                   	ret
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_mem_free>:
    55b0:	48 85 ff             	test   %rdi,%rdi
    55b3:	0f 84 17 02 00 00    	je     57d0 <fwp_mem_free+0x220>
    55b9:	48 8b 35 70 b5 01 00 	mov    0x1b570(%rip),%rsi        # 20b30 <fwp_heap+0x13b0>
    55c0:	48 8b 05 91 b5 01 00 	mov    0x1b591(%rip),%rax        # 20b58 <fwp_heap+0x13d8>
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 29 f2             	sub    %rsi,%rdx
    55cd:	48 c1 e0 10          	shl    $0x10,%rax
    55d1:	48 39 c2             	cmp    %rax,%rdx
    55d4:	0f 83 f6 01 00 00    	jae    57d0 <fwp_mem_free+0x220>
    55da:	49 89 d1             	mov    %rdx,%r9
    55dd:	49 c1 e9 10          	shr    $0x10,%r9
    55e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    55e5:	48 c1 e0 03          	shl    $0x3,%rax
    55e9:	49 89 c0             	mov    %rax,%r8
    55ec:	4c 03 05 85 b5 01 00 	add    0x1b585(%rip),%r8        # 20b78 <fwp_heap+0x13f8>
    55f3:	0f 84 d7 01 00 00    	je     57d0 <fwp_mem_free+0x220>
    55f9:	48 83 ec 38          	sub    $0x38,%rsp
    55fd:	48 89 f9             	mov    %rdi,%rcx
    5600:	41 0f b6 38          	movzbl (%r8),%edi
    5604:	40 80 ff 01          	cmp    $0x1,%dil
    5608:	74 16                	je     5620 <fwp_mem_free+0x70>
    560a:	40 80 ff 02          	cmp    $0x2,%dil
    560e:	0f 84 94 00 00 00    	je     56a8 <fwp_mem_free+0xf8>
    5614:	48 83 c4 38          	add    $0x38,%rsp
    5618:	c3                   	ret
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5624:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5629:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    562e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5632:	4d 85 d2             	test   %r10,%r10
    5635:	74 1d                	je     5654 <fwp_mem_free+0xa4>
    5637:	0f b7 c1             	movzwl %cx,%eax
    563a:	31 d2                	xor    %edx,%edx
    563c:	48 f7 f7             	div    %rdi
    563f:	49 01 c2             	add    %rax,%r10
    5642:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5646:	0f 84 44 01 00 00    	je     5790 <fwp_mem_free+0x1e0>
    564c:	41 c6 02 00          	movb   $0x0,(%r10)
    5650:	41 8b 78 04          	mov    0x4(%r8),%edi
    5654:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    565b:	49 63 c1             	movslq %r9d,%rax
    565e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5662:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5666:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    566b:	f2 0f 58 05 4d b5 01 	addsd  0x1b54d(%rip),%xmm0        # 20bc0 <fwp_heap+0x1440>
    5672:	00 
    5673:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5677:	48 8d 05 02 a1 01 00 	lea    0x1a102(%rip),%rax        # 1f780 <fwp_heap>
    567e:	48 01 d0             	add    %rdx,%rax
    5681:	48 8b 10             	mov    (%rax),%rdx
    5684:	48 f7 d2             	not    %rdx
    5687:	48 89 11             	mov    %rdx,(%rcx)
    568a:	48 89 08             	mov    %rcx,(%rax)
    568d:	48 29 3d 0c b5 01 00 	sub    %rdi,0x1b50c(%rip)        # 20ba0 <fwp_heap+0x1420>
    5694:	f2 0f 11 05 24 b5 01 	movsd  %xmm0,0x1b524(%rip)        # 20bc0 <fwp_heap+0x1440>
    569b:	00 
    569c:	48 83 c4 38          	add    $0x38,%rsp
    56a0:	c3                   	ret
    56a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56a8:	66 31 d2             	xor    %dx,%dx
    56ab:	48 01 d6             	add    %rdx,%rsi
    56ae:	48 39 f1             	cmp    %rsi,%rcx
    56b1:	0f 85 5d ff ff ff    	jne    5614 <fwp_mem_free+0x64>
    56b7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    56bb:	48 29 15 de b4 01 00 	sub    %rdx,0x1b4de(%rip)        # 20ba0 <fwp_heap+0x1420>
    56c2:	48 85 d2             	test   %rdx,%rdx
    56c5:	0f 88 a5 00 00 00    	js     5770 <fwp_mem_free+0x1c0>
    56cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56cf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    56d4:	f2 0f 58 05 e4 b4 01 	addsd  0x1b4e4(%rip),%xmm0        # 20bc0 <fwp_heap+0x1440>
    56db:	00 
    56dc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    56e0:	f2 0f 11 05 d8 b4 01 	movsd  %xmm0,0x1b4d8(%rip)        # 20bc0 <fwp_heap+0x1440>
    56e7:	00 
    56e8:	48 85 d2             	test   %rdx,%rdx
    56eb:	74 0c                	je     56f9 <fwp_mem_free+0x149>
    56ed:	80 3a ff             	cmpb   $0xff,(%rdx)
    56f0:	0f 84 db 00 00 00    	je     57d1 <fwp_mem_free+0x221>
    56f6:	c6 02 00             	movb   $0x0,(%rdx)
    56f9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    56fd:	48 85 c9             	test   %rcx,%rcx
    5700:	74 3e                	je     5740 <fwp_mem_free+0x190>
    5702:	48 8b 15 6f b4 01 00 	mov    0x1b46f(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    5709:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    570d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5711:	48 01 d0             	add    %rdx,%rax
    5714:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5718:	48 89 d6             	mov    %rdx,%rsi
    571b:	48 29 c6             	sub    %rax,%rsi
    571e:	83 e6 08             	and    $0x8,%esi
    5721:	74 0d                	je     5730 <fwp_mem_free+0x180>
    5723:	c6 00 00             	movb   $0x0,(%rax)
    5726:	48 83 c0 28          	add    $0x28,%rax
    572a:	48 39 c2             	cmp    %rax,%rdx
    572d:	74 11                	je     5740 <fwp_mem_free+0x190>
    572f:	90                   	nop
    5730:	c6 00 00             	movb   $0x0,(%rax)
    5733:	48 83 c0 50          	add    $0x50,%rax
    5737:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    573b:	48 39 c2             	cmp    %rax,%rdx
    573e:	75 f0                	jne    5730 <fwp_mem_free+0x180>
    5740:	48 01 0d 69 b4 01 00 	add    %rcx,0x1b469(%rip)        # 20bb0 <fwp_heap+0x1430>
    5747:	4c 3b 0d 22 b4 01 00 	cmp    0x1b422(%rip),%r9        # 20b70 <fwp_heap+0x13f0>
    574e:	73 07                	jae    5757 <fwp_mem_free+0x1a7>
    5750:	4c 89 0d 19 b4 01 00 	mov    %r9,0x1b419(%rip)        # 20b70 <fwp_heap+0x13f0>
    5757:	4c 3b 0d 0a b4 01 00 	cmp    0x1b40a(%rip),%r9        # 20b68 <fwp_heap+0x13e8>
    575e:	0f 83 b0 fe ff ff    	jae    5614 <fwp_mem_free+0x64>
    5764:	4c 89 0d fd b3 01 00 	mov    %r9,0x1b3fd(%rip)        # 20b68 <fwp_heap+0x13e8>
    576b:	e9 a4 fe ff ff       	jmp    5614 <fwp_mem_free+0x64>
    5770:	48 89 d1             	mov    %rdx,%rcx
    5773:	83 e2 01             	and    $0x1,%edx
    5776:	66 0f ef c0          	pxor   %xmm0,%xmm0
    577a:	48 d1 e9             	shr    $1,%rcx
    577d:	48 09 d1             	or     %rdx,%rcx
    5780:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5785:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5789:	e9 46 ff ff ff       	jmp    56d4 <fwp_mem_free+0x124>
    578e:	66 90                	xchg   %ax,%ax
    5790:	4c 89 d7             	mov    %r10,%rdi
    5793:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5798:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    579d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    57a2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    57a6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    57ab:	e8 c0 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57b0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    57b5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    57ba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    57bf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    57c4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    57c9:	e9 7e fe ff ff       	jmp    564c <fwp_mem_free+0x9c>
    57ce:	66 90                	xchg   %ax,%ax
    57d0:	c3                   	ret
    57d1:	48 89 d7             	mov    %rdx,%rdi
    57d4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    57d9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    57de:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    57e3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    57e8:	e8 83 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57ed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    57f2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    57f7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    57fc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5801:	e9 f0 fe ff ff       	jmp    56f6 <fwp_mem_free+0x146>
    5806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    580d:	00 00 00 

0000000000005810 <fwp_heap_alloc_big>:
    5810:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5817:	00 00 40 
    581a:	41 57                	push   %r15
    581c:	41 56                	push   %r14
    581e:	41 55                	push   %r13
    5820:	41 54                	push   %r12
    5822:	55                   	push   %rbp
    5823:	53                   	push   %rbx
    5824:	48 83 ec 08          	sub    $0x8,%rsp
    5828:	48 39 f8             	cmp    %rdi,%rax
    582b:	0f 82 fa 00 00 00    	jb     592b <fwp_heap_alloc_big+0x11b>
    5831:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5838:	49 89 fd             	mov    %rdi,%r13
    583b:	41 89 f6             	mov    %esi,%r14d
    583e:	48 c1 ed 10          	shr    $0x10,%rbp
    5842:	48 89 ef             	mov    %rbp,%rdi
    5845:	e8 96 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    584a:	be 01 00 00 00       	mov    $0x1,%esi
    584f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5853:	49 89 c4             	mov    %rax,%r12
    5856:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    585d:	00 
    585e:	48 03 3d 13 b3 01 00 	add    0x1b313(%rip),%rdi        # 20b78 <fwp_heap+0x13f8>
    5865:	c6 07 02             	movb   $0x2,(%rdi)
    5868:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    586c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    586f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5873:	e8 88 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    5878:	48 83 fd 01          	cmp    $0x1,%rbp
    587c:	76 47                	jbe    58c5 <fwp_heap_alloc_big+0xb5>
    587e:	4c 01 e5             	add    %r12,%rbp
    5881:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5888:	00 
    5889:	4c 8d 3d f0 9e 01 00 	lea    0x19ef0(%rip),%r15        # 1f780 <fwp_heap>
    5890:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5895:	49 c1 e6 03          	shl    $0x3,%r14
    5899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58a0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    58a7:	31 f6                	xor    %esi,%esi
    58a9:	48 01 dd             	add    %rbx,%rbp
    58ac:	48 83 c3 28          	add    $0x28,%rbx
    58b0:	48 89 ef             	mov    %rbp,%rdi
    58b3:	e8 48 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    58b8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    58bc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    58c0:	49 39 de             	cmp    %rbx,%r14
    58c3:	75 db                	jne    58a0 <fwp_heap_alloc_big+0x90>
    58c5:	49 c1 e4 10          	shl    $0x10,%r12
    58c9:	4c 03 25 60 b2 01 00 	add    0x1b260(%rip),%r12        # 20b30 <fwp_heap+0x13b0>
    58d0:	4c 89 ea             	mov    %r13,%rdx
    58d3:	31 f6                	xor    %esi,%esi
    58d5:	4c 89 e7             	mov    %r12,%rdi
    58d8:	e8 e3 db ff ff       	call   34c0 <memset@plt>
    58dd:	4c 89 e8             	mov    %r13,%rax
    58e0:	48 03 05 b9 b2 01 00 	add    0x1b2b9(%rip),%rax        # 20ba0 <fwp_heap+0x1420>
    58e7:	72 42                	jb     592b <fwp_heap_alloc_big+0x11b>
    58e9:	48 39 05 b8 b2 01 00 	cmp    %rax,0x1b2b8(%rip)        # 20ba8 <fwp_heap+0x1428>
    58f0:	48 89 05 a9 b2 01 00 	mov    %rax,0x1b2a9(%rip)        # 20ba0 <fwp_heap+0x1420>
    58f7:	73 07                	jae    5900 <fwp_heap_alloc_big+0xf0>
    58f9:	48 89 05 a8 b2 01 00 	mov    %rax,0x1b2a8(%rip)        # 20ba8 <fwp_heap+0x1428>
    5900:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5904:	4c 89 e0             	mov    %r12,%rax
    5907:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    590c:	f2 0f 58 05 a4 b2 01 	addsd  0x1b2a4(%rip),%xmm0        # 20bb8 <fwp_heap+0x1438>
    5913:	00 
    5914:	f2 0f 11 05 9c b2 01 	movsd  %xmm0,0x1b29c(%rip)        # 20bb8 <fwp_heap+0x1438>
    591b:	00 
    591c:	48 83 c4 08          	add    $0x8,%rsp
    5920:	5b                   	pop    %rbx
    5921:	5d                   	pop    %rbp
    5922:	41 5c                	pop    %r12
    5924:	41 5d                	pop    %r13
    5926:	41 5e                	pop    %r14
    5928:	41 5f                	pop    %r15
    592a:	c3                   	ret
    592b:	e8 80 e3 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005930 <fwp_heap_alloc_slow>:
    5930:	53                   	push   %rbx
    5931:	48 89 f9             	mov    %rdi,%rcx
    5934:	41 89 f1             	mov    %esi,%r9d
    5937:	48 83 ec 10          	sub    $0x10,%rsp
    593b:	8b 05 e3 b1 01 00    	mov    0x1b1e3(%rip),%eax        # 20b24 <fwp_heap+0x13a4>
    5941:	85 c0                	test   %eax,%eax
    5943:	0f 84 c7 00 00 00    	je     5a10 <fwp_heap_alloc_slow+0xe0>
    5949:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5950:	0f 87 dd 00 00 00    	ja     5a33 <fwp_heap_alloc_slow+0x103>
    5956:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    595a:	48 8d 3d 1f 9e 01 00 	lea    0x19e1f(%rip),%rdi        # 1f780 <fwp_heap>
    5961:	49 63 f1             	movslq %r9d,%rsi
    5964:	48 c1 e8 04          	shr    $0x4,%rax
    5968:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    596f:	00 00 
    5971:	41 0f b6 c2          	movzbl %r10b,%eax
    5975:	4c 89 d2             	mov    %r10,%rdx
    5978:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    597c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5983:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    598a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    598e:	48 01 f8             	add    %rdi,%rax
    5991:	4c 8b 00             	mov    (%rax),%r8
    5994:	4d 85 c0             	test   %r8,%r8
    5997:	0f 84 ab 00 00 00    	je     5a48 <fwp_heap_alloc_slow+0x118>
    599d:	49 8b 10             	mov    (%r8),%rdx
    59a0:	48 f7 d2             	not    %rdx
    59a3:	48 89 10             	mov    %rdx,(%rax)
    59a6:	41 83 f9 01          	cmp    $0x1,%r9d
    59aa:	4c 89 c7             	mov    %r8,%rdi
    59ad:	48 0f 45 cb          	cmovne %rbx,%rcx
    59b1:	31 f6                	xor    %esi,%esi
    59b3:	48 89 ca             	mov    %rcx,%rdx
    59b6:	e8 05 db ff ff       	call   34c0 <memset@plt>
    59bb:	49 89 c0             	mov    %rax,%r8
    59be:	48 89 d8             	mov    %rbx,%rax
    59c1:	48 03 05 d8 b1 01 00 	add    0x1b1d8(%rip),%rax        # 20ba0 <fwp_heap+0x1420>
    59c8:	0f 82 d9 00 00 00    	jb     5aa7 <fwp_heap_alloc_slow+0x177>
    59ce:	48 39 05 d3 b1 01 00 	cmp    %rax,0x1b1d3(%rip)        # 20ba8 <fwp_heap+0x1428>
    59d5:	48 89 05 c4 b1 01 00 	mov    %rax,0x1b1c4(%rip)        # 20ba0 <fwp_heap+0x1420>
    59dc:	73 07                	jae    59e5 <fwp_heap_alloc_slow+0xb5>
    59de:	48 89 05 c3 b1 01 00 	mov    %rax,0x1b1c3(%rip)        # 20ba8 <fwp_heap+0x1428>
    59e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59e9:	4c 89 c0             	mov    %r8,%rax
    59ec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    59f1:	f2 0f 58 05 bf b1 01 	addsd  0x1b1bf(%rip),%xmm0        # 20bb8 <fwp_heap+0x1438>
    59f8:	00 
    59f9:	f2 0f 11 05 b7 b1 01 	movsd  %xmm0,0x1b1b7(%rip)        # 20bb8 <fwp_heap+0x1438>
    5a00:	00 
    5a01:	48 83 c4 10          	add    $0x10,%rsp
    5a05:	5b                   	pop    %rbx
    5a06:	c3                   	ret
    5a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a0e:	00 00 
    5a10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5a14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5a18:	e8 13 f1 ff ff       	call   4b30 <fwp_heap_init>
    5a1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5a21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5a26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5a2d:	0f 86 23 ff ff ff    	jbe    5956 <fwp_heap_alloc_slow+0x26>
    5a33:	48 83 c4 10          	add    $0x10,%rsp
    5a37:	44 89 ce             	mov    %r9d,%esi
    5a3a:	48 89 cf             	mov    %rcx,%rdi
    5a3d:	5b                   	pop    %rbx
    5a3e:	e9 cd fd ff ff       	jmp    5810 <fwp_heap_alloc_big>
    5a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5a48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5a4c:	4d 85 c0             	test   %r8,%r8
    5a4f:	74 1f                	je     5a70 <fwp_heap_alloc_slow+0x140>
    5a51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5a55:	4d 29 c3             	sub    %r8,%r11
    5a58:	49 39 db             	cmp    %rbx,%r11
    5a5b:	72 13                	jb     5a70 <fwp_heap_alloc_slow+0x140>
    5a5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a65:	e9 3c ff ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a7b:	44 89 ca             	mov    %r9d,%edx
    5a7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a8b:	44 89 d6             	mov    %r10d,%esi
    5a8e:	48 01 c7             	add    %rax,%rdi
    5a91:	e8 6a fa ff ff       	call   5500 <fwp_heap_refill>
    5a96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a9f:	49 89 c0             	mov    %rax,%r8
    5aa2:	e9 ff fe ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5aa7:	e8 04 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ab0 <fwp_heap_alloc>:
    5ab0:	8b 05 6e b0 01 00    	mov    0x1b06e(%rip),%eax        # 20b24 <fwp_heap+0x13a4>
    5ab6:	48 89 fa             	mov    %rdi,%rdx
    5ab9:	89 f7                	mov    %esi,%edi
    5abb:	85 c0                	test   %eax,%eax
    5abd:	0f 84 f5 00 00 00    	je     5bb8 <fwp_heap_alloc+0x108>
    5ac3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5aca:	0f 87 e8 00 00 00    	ja     5bb8 <fwp_heap_alloc+0x108>
    5ad0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ad4:	48 8d 05 a5 9c 01 00 	lea    0x19ca5(%rip),%rax        # 1f780 <fwp_heap>
    5adb:	48 83 ec 18          	sub    $0x18,%rsp
    5adf:	41 89 f0             	mov    %esi,%r8d
    5ae2:	48 c1 e9 04          	shr    $0x4,%rcx
    5ae6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5aed:	00 
    5aee:	48 63 cf             	movslq %edi,%rcx
    5af1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5af8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5aff:	00 
    5b00:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5b04:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5b08:	48 01 c8             	add    %rcx,%rax
    5b0b:	48 8b 08             	mov    (%rax),%rcx
    5b0e:	48 85 c9             	test   %rcx,%rcx
    5b11:	74 6d                	je     5b80 <fwp_heap_alloc+0xd0>
    5b13:	48 8b 31             	mov    (%rcx),%rsi
    5b16:	48 f7 d6             	not    %rsi
    5b19:	48 89 30             	mov    %rsi,(%rax)
    5b1c:	41 83 f8 01          	cmp    $0x1,%r8d
    5b20:	48 89 cf             	mov    %rcx,%rdi
    5b23:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5b28:	49 0f 45 d1          	cmovne %r9,%rdx
    5b2c:	31 f6                	xor    %esi,%esi
    5b2e:	e8 8d d9 ff ff       	call   34c0 <memset@plt>
    5b33:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5b38:	48 89 c1             	mov    %rax,%rcx
    5b3b:	4c 89 c8             	mov    %r9,%rax
    5b3e:	48 03 05 5b b0 01 00 	add    0x1b05b(%rip),%rax        # 20ba0 <fwp_heap+0x1420>
    5b45:	72 7b                	jb     5bc2 <fwp_heap_alloc+0x112>
    5b47:	48 39 05 5a b0 01 00 	cmp    %rax,0x1b05a(%rip)        # 20ba8 <fwp_heap+0x1428>
    5b4e:	48 89 05 4b b0 01 00 	mov    %rax,0x1b04b(%rip)        # 20ba0 <fwp_heap+0x1420>
    5b55:	73 07                	jae    5b5e <fwp_heap_alloc+0xae>
    5b57:	48 89 05 4a b0 01 00 	mov    %rax,0x1b04a(%rip)        # 20ba8 <fwp_heap+0x1428>
    5b5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b62:	48 89 c8             	mov    %rcx,%rax
    5b65:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b6a:	f2 0f 58 05 46 b0 01 	addsd  0x1b046(%rip),%xmm0        # 20bb8 <fwp_heap+0x1438>
    5b71:	00 
    5b72:	f2 0f 11 05 3e b0 01 	movsd  %xmm0,0x1b03e(%rip)        # 20bb8 <fwp_heap+0x1438>
    5b79:	00 
    5b7a:	48 83 c4 18          	add    $0x18,%rsp
    5b7e:	c3                   	ret
    5b7f:	90                   	nop
    5b80:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b84:	48 85 c9             	test   %rcx,%rcx
    5b87:	74 0c                	je     5b95 <fwp_heap_alloc+0xe5>
    5b89:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b8d:	48 29 ce             	sub    %rcx,%rsi
    5b90:	4c 39 ce             	cmp    %r9,%rsi
    5b93:	73 13                	jae    5ba8 <fwp_heap_alloc+0xf8>
    5b95:	89 fe                	mov    %edi,%esi
    5b97:	48 83 c4 18          	add    $0x18,%rsp
    5b9b:	48 89 d7             	mov    %rdx,%rdi
    5b9e:	e9 8d fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5ba3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ba8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bac:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5bb0:	e9 67 ff ff ff       	jmp    5b1c <fwp_heap_alloc+0x6c>
    5bb5:	0f 1f 00             	nopl   (%rax)
    5bb8:	89 fe                	mov    %edi,%esi
    5bba:	48 89 d7             	mov    %rdx,%rdi
    5bbd:	e9 6e fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5bc2:	e8 e9 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bce:	00 00 

0000000000005bd0 <fwp_data.part.0.constprop.0>:
    5bd0:	41 56                	push   %r14
    5bd2:	41 89 fe             	mov    %edi,%r14d
    5bd5:	41 54                	push   %r12
    5bd7:	49 89 f4             	mov    %rsi,%r12
    5bda:	55                   	push   %rbp
    5bdb:	53                   	push   %rbx
    5bdc:	48 83 ec 08          	sub    $0x8,%rsp
    5be0:	8b 05 3e af 01 00    	mov    0x1af3e(%rip),%eax        # 20b24 <fwp_heap+0x13a4>
    5be6:	85 c0                	test   %eax,%eax
    5be8:	0f 84 fa 00 00 00    	je     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5bee:	0f b6 05 2d ab 01 00 	movzbl 0x1ab2d(%rip),%eax        # 20722 <fwp_heap+0xfa2>
    5bf5:	48 8d 15 84 9b 01 00 	lea    0x19b84(%rip),%rdx        # 1f780 <fwp_heap>
    5bfc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5c03:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5c07:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5c0b:	48 8b 18             	mov    (%rax),%rbx
    5c0e:	48 85 db             	test   %rbx,%rbx
    5c11:	0f 84 a9 00 00 00    	je     5cc0 <fwp_data.part.0.constprop.0+0xf0>
    5c17:	48 8b 13             	mov    (%rbx),%rdx
    5c1a:	48 f7 d2             	not    %rdx
    5c1d:	48 89 10             	mov    %rdx,(%rax)
    5c20:	48 83 fd 18          	cmp    $0x18,%rbp
    5c24:	76 1b                	jbe    5c41 <fwp_data.part.0.constprop.0+0x71>
    5c26:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5c2a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5c2e:	31 f6                	xor    %esi,%esi
    5c30:	48 c1 e8 03          	shr    $0x3,%rax
    5c34:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5c3b:	00 
    5c3c:	e8 7f d8 ff ff       	call   34c0 <memset@plt>
    5c41:	48 89 e8             	mov    %rbp,%rax
    5c44:	48 03 05 55 af 01 00 	add    0x1af55(%rip),%rax        # 20ba0 <fwp_heap+0x1420>
    5c4b:	0f 82 a8 00 00 00    	jb     5cf9 <fwp_data.part.0.constprop.0+0x129>
    5c51:	48 39 05 50 af 01 00 	cmp    %rax,0x1af50(%rip)        # 20ba8 <fwp_heap+0x1428>
    5c58:	48 89 05 41 af 01 00 	mov    %rax,0x1af41(%rip)        # 20ba0 <fwp_heap+0x1420>
    5c5f:	73 07                	jae    5c68 <fwp_data.part.0.constprop.0+0x98>
    5c61:	48 89 05 40 af 01 00 	mov    %rax,0x1af40(%rip)        # 20ba8 <fwp_heap+0x1428>
    5c68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c6c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c71:	f2 0f 58 05 3f af 01 	addsd  0x1af3f(%rip),%xmm0        # 20bb8 <fwp_heap+0x1438>
    5c78:	00 
    5c79:	f2 0f 11 05 37 af 01 	movsd  %xmm0,0x1af37(%rip)        # 20bb8 <fwp_heap+0x1438>
    5c80:	00 
    5c81:	b8 02 00 00 00       	mov    $0x2,%eax
    5c86:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c8b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c8f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c93:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c97:	49 8b 04 24          	mov    (%r12),%rax
    5c9b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c9f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5ca4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ca8:	48 83 c4 08          	add    $0x8,%rsp
    5cac:	48 89 d8             	mov    %rbx,%rax
    5caf:	5b                   	pop    %rbx
    5cb0:	5d                   	pop    %rbp
    5cb1:	41 5c                	pop    %r12
    5cb3:	41 5e                	pop    %r14
    5cb5:	c3                   	ret
    5cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cbd:	00 00 00 
    5cc0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5cc4:	48 85 db             	test   %rbx,%rbx
    5cc7:	74 1f                	je     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5cc9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ccd:	48 29 da             	sub    %rbx,%rdx
    5cd0:	48 39 ea             	cmp    %rbp,%rdx
    5cd3:	72 13                	jb     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5cd5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5cd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5cdd:	e9 3e ff ff ff       	jmp    5c20 <fwp_data.part.0.constprop.0+0x50>
    5ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ce8:	31 f6                	xor    %esi,%esi
    5cea:	bf 18 00 00 00       	mov    $0x18,%edi
    5cef:	e8 bc fd ff ff       	call   5ab0 <fwp_heap_alloc>
    5cf4:	48 89 c3             	mov    %rax,%rbx
    5cf7:	eb 88                	jmp    5c81 <fwp_data.part.0.constprop.0+0xb1>
    5cf9:	e8 b2 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cfe:	66 90                	xchg   %ax,%ax

0000000000005d00 <fwp_p_ad_push>:
    5d00:	41 57                	push   %r15
    5d02:	41 56                	push   %r14
    5d04:	41 55                	push   %r13
    5d06:	49 89 d5             	mov    %rdx,%r13
    5d09:	41 54                	push   %r12
    5d0b:	49 89 fc             	mov    %rdi,%r12
    5d0e:	55                   	push   %rbp
    5d0f:	53                   	push   %rbx
    5d10:	48 83 ec 38          	sub    $0x38,%rsp
    5d14:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5d19:	48 85 ff             	test   %rdi,%rdi
    5d1c:	79 09                	jns    5d27 <fwp_p_ad_push+0x27>
    5d1e:	48 85 d2             	test   %rdx,%rdx
    5d21:	0f 88 a9 01 00 00    	js     5ed0 <fwp_p_ad_push+0x1d0>
    5d27:	48 89 f8             	mov    %rdi,%rax
    5d2a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5d2e:	48 09 d0             	or     %rdx,%rax
    5d31:	0f 89 79 01 00 00    	jns    5eb0 <fwp_p_ad_push+0x1b0>
    5d37:	48 89 f8             	mov    %rdi,%rax
    5d3a:	48 c1 f8 20          	sar    $0x20,%rax
    5d3e:	48 85 ff             	test   %rdi,%rdi
    5d41:	79 24                	jns    5d67 <fwp_p_ad_push+0x67>
    5d43:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5d48:	48 89 d0             	mov    %rdx,%rax
    5d4b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5d52:	00 
    5d53:	49 89 d4             	mov    %rdx,%r12
    5d56:	48 c1 f8 20          	sar    $0x20,%rax
    5d5a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d61:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d67:	48 89 c7             	mov    %rax,%rdi
    5d6a:	e8 11 e7 ff ff       	call   4480 <fwp_tape_of>
    5d6f:	48 89 c3             	mov    %rax,%rbx
    5d72:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d77:	0f 85 76 02 00 00    	jne    5ff3 <fwp_p_ad_push+0x2f3>
    5d7d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d81:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d88:	0f 8f 59 02 00 00    	jg     5fe7 <fwp_p_ad_push+0x2e7>
    5d8e:	44 89 e0             	mov    %r12d,%eax
    5d91:	4c 39 f8             	cmp    %r15,%rax
    5d94:	0f 8d 41 02 00 00    	jge    5fdb <fwp_p_ad_push+0x2db>
    5d9a:	4d 85 ed             	test   %r13,%r13
    5d9d:	78 0c                	js     5dab <fwp_p_ad_push+0xab>
    5d9f:	44 89 e8             	mov    %r13d,%eax
    5da2:	4c 39 f8             	cmp    %r15,%rax
    5da5:	0f 8d 30 02 00 00    	jge    5fdb <fwp_p_ad_push+0x2db>
    5dab:	4d 89 fe             	mov    %r15,%r14
    5dae:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5db2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5db6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5dbc:	0f 87 25 02 00 00    	ja     5fe7 <fwp_p_ad_push+0x2e7>
    5dc2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5dc6:	48 39 e8             	cmp    %rbp,%rax
    5dc9:	0f 8e 31 01 00 00    	jle    5f00 <fwp_p_ad_push+0x200>
    5dcf:	48 85 ed             	test   %rbp,%rbp
    5dd2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5dd7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5ddb:	48 39 e8             	cmp    %rbp,%rax
    5dde:	7e 20                	jle    5e00 <fwp_p_ad_push+0x100>
    5de0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5de7:	0f 8f 03 01 00 00    	jg     5ef0 <fwp_p_ad_push+0x1f0>
    5ded:	48 01 ed             	add    %rbp,%rbp
    5df0:	48 39 e8             	cmp    %rbp,%rax
    5df3:	7f eb                	jg     5de0 <fwp_p_ad_push+0xe0>
    5df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dfc:	00 00 00 00 
    5e00:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5e07:	00 
    5e08:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5e0c:	48 89 c6             	mov    %rax,%rsi
    5e0f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5e14:	e8 b7 d7 ff ff       	call   35d0 <realloc@plt>
    5e19:	48 85 c0             	test   %rax,%rax
    5e1c:	0f 84 dd 01 00 00    	je     5fff <fwp_p_ad_push+0x2ff>
    5e22:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5e26:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5e2a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5e2e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5e32:	48 89 e9             	mov    %rbp,%rcx
    5e35:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5e39:	48 c1 e1 04          	shl    $0x4,%rcx
    5e3d:	48 89 ce             	mov    %rcx,%rsi
    5e40:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5e45:	e8 86 d7 ff ff       	call   35d0 <realloc@plt>
    5e4a:	48 85 c0             	test   %rax,%rax
    5e4d:	0f 84 ac 01 00 00    	je     5fff <fwp_p_ad_push+0x2ff>
    5e53:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5e57:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5e5c:	4d 85 f6             	test   %r14,%r14
    5e5f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e63:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e68:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e6f:	00 
    5e70:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e77:	00 
    5e78:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e7c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e83:	00 
    5e84:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e88:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e8c:	0f 85 e2 00 00 00    	jne    5f74 <fwp_p_ad_push+0x274>
    5e92:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e96:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e9a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e9e:	49 01 c8             	add    %rcx,%r8
    5ea1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5ea5:	eb 79                	jmp    5f20 <fwp_p_ad_push+0x220>
    5ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5eae:	00 00 
    5eb0:	48 89 d0             	mov    %rdx,%rax
    5eb3:	48 c1 ff 20          	sar    $0x20,%rdi
    5eb7:	48 c1 f8 20          	sar    $0x20,%rax
    5ebb:	48 39 c7             	cmp    %rax,%rdi
    5ebe:	0f 84 a3 fe ff ff    	je     5d67 <fwp_p_ad_push+0x67>
    5ec4:	48 8d 3d d5 58 00 00 	lea    0x58d5(%rip),%rdi        # b7a0 <_IO_stdin_used+0x7a0>
    5ecb:	e8 d0 e2 ff ff       	call   41a0 <fwp_trap>
    5ed0:	48 83 c4 38          	add    $0x38,%rsp
    5ed4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edb:	5b                   	pop    %rbx
    5edc:	5d                   	pop    %rbp
    5edd:	41 5c                	pop    %r12
    5edf:	41 5d                	pop    %r13
    5ee1:	41 5e                	pop    %r14
    5ee3:	41 5f                	pop    %r15
    5ee5:	c3                   	ret
    5ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5eed:	00 00 00 
    5ef0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5ef5:	e9 06 ff ff ff       	jmp    5e00 <fwp_p_ad_push+0x100>
    5efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f00:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f04:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f08:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f0f:	00 
    5f10:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f17:	00 
    5f18:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5f1c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f20:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5f26:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5f2a:	4d 85 ed             	test   %r13,%r13
    5f2d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5f32:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5f38:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f3f:	4c 0f 48 e8          	cmovs  %rax,%r13
    5f43:	49 8d 47 01          	lea    0x1(%r15),%rax
    5f47:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5f4b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5f51:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5f55:	48 83 c4 38          	add    $0x38,%rsp
    5f59:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f60:	ff ff ff 
    5f63:	4c 21 e0             	and    %r12,%rax
    5f66:	5b                   	pop    %rbx
    5f67:	5d                   	pop    %rbp
    5f68:	4c 09 f8             	or     %r15,%rax
    5f6b:	41 5c                	pop    %r12
    5f6d:	41 5d                	pop    %r13
    5f6f:	41 5e                	pop    %r14
    5f71:	41 5f                	pop    %r15
    5f73:	c3                   	ret
    5f74:	48 39 ca             	cmp    %rcx,%rdx
    5f77:	49 89 d6             	mov    %rdx,%r14
    5f7a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f7f:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f83:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f88:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f8d:	48 29 d1             	sub    %rdx,%rcx
    5f90:	4c 89 ca             	mov    %r9,%rdx
    5f93:	e8 c8 d5 ff ff       	call   3560 <__memmove_chk@plt>
    5f98:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f9c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5fa1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5fa5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5faa:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5fae:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5fb2:	4c 89 d2             	mov    %r10,%rdx
    5fb5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5fba:	e8 51 d6 ff ff       	call   3610 <memmove@plt>
    5fbf:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fc3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fc7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5fcc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5fd1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5fd6:	e9 bb fe ff ff       	jmp    5e96 <fwp_p_ad_push+0x196>
    5fdb:	48 8d 3d 22 51 00 00 	lea    0x5122(%rip),%rdi        # b104 <_IO_stdin_used+0x104>
    5fe2:	e8 b9 e1 ff ff       	call   41a0 <fwp_trap>
    5fe7:	48 8d 3d fb 50 00 00 	lea    0x50fb(%rip),%rdi        # b0e9 <_IO_stdin_used+0xe9>
    5fee:	e8 ad e1 ff ff       	call   41a0 <fwp_trap>
    5ff3:	48 8d 3d ee 57 00 00 	lea    0x57ee(%rip),%rdi        # b7e8 <_IO_stdin_used+0x7e8>
    5ffa:	e8 a1 e1 ff ff       	call   41a0 <fwp_trap>
    5fff:	48 89 df             	mov    %rbx,%rdi
    6002:	e8 f9 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6007:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    600b:	e8 b0 d3 ff ff       	call   33c0 <free@plt>
    6010:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6014:	e8 a7 d3 ff ff       	call   33c0 <free@plt>
    6019:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    601d:	e8 9e d3 ff ff       	call   33c0 <free@plt>
    6022:	31 c9                	xor    %ecx,%ecx
    6024:	31 c0                	xor    %eax,%eax
    6026:	31 d2                	xor    %edx,%edx
    6028:	89 53 04             	mov    %edx,0x4(%rbx)
    602b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    602f:	ba 13 00 00 00       	mov    $0x13,%edx
    6034:	be 01 00 00 00       	mov    $0x1,%esi
    6039:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    603d:	48 8d 3d c4 4f 00 00 	lea    0x4fc4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6044:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6048:	48 8b 0d f1 8f 00 00 	mov    0x8ff1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    604f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6053:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6057:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    605b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    605f:	e8 1c d6 ff ff       	call   3680 <fwrite@plt>
    6064:	31 ff                	xor    %edi,%edi
    6066:	e8 55 d5 ff ff       	call   35c0 <fflush@plt>
    606b:	bf 66 00 00 00       	mov    $0x66,%edi
    6070:	e8 2b d6 ff ff       	call   36a0 <_Exit@plt>
    6075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    607c:	00 00 00 00 

0000000000006080 <w120>:
    6080:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6084:	41 55                	push   %r13
    6086:	48 89 fa             	mov    %rdi,%rdx
    6089:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    608d:	41 54                	push   %r12
    608f:	49 89 fc             	mov    %rdi,%r12
    6092:	55                   	push   %rbp
    6093:	53                   	push   %rbx
    6094:	48 89 f3             	mov    %rsi,%rbx
    6097:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    609c:	48 89 f1             	mov    %rsi,%rcx
    609f:	48 83 ec 28          	sub    $0x28,%rsp
    60a3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    60a9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    60af:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60b5:	e8 46 fc ff ff       	call   5d00 <fwp_p_ad_push>
    60ba:	48 89 c7             	mov    %rax,%rdi
    60bd:	e8 5e ec ff ff       	call   4d20 <caf75>
    60c2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    60c7:	e8 54 ec ff ff       	call   4d20 <caf75>
    60cc:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    60d2:	66 0f 57 05 76 59 00 	xorpd  0x5976(%rip),%xmm0        # ba50 <msg.8+0x80>
    60d9:	00 
    60da:	48 89 da             	mov    %rbx,%rdx
    60dd:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    60e3:	48 89 c1             	mov    %rax,%rcx
    60e6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    60eb:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    60f0:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60f6:	e8 05 fc ff ff       	call   5d00 <fwp_p_ad_push>
    60fb:	4c 89 e7             	mov    %r12,%rdi
    60fe:	49 89 c5             	mov    %rax,%r13
    6101:	e8 1a ec ff ff       	call   4d20 <caf75>
    6106:	48 89 c6             	mov    %rax,%rsi
    6109:	e8 12 ec ff ff       	call   4d20 <caf75>
    610e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6113:	f2 0f 10 05 75 59 00 	movsd  0x5975(%rip),%xmm0        # ba90 <msg.8+0xc0>
    611a:	00 
    611b:	66 0f 57 15 2d 59 00 	xorpd  0x592d(%rip),%xmm2        # ba50 <msg.8+0x80>
    6122:	00 
    6123:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6129:	48 89 c1             	mov    %rax,%rcx
    612c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6133:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6138:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    613d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6143:	e8 b8 fb ff ff       	call   5d00 <fwp_p_ad_push>
    6148:	48 89 e9             	mov    %rbp,%rcx
    614b:	4c 89 ea             	mov    %r13,%rdx
    614e:	48 89 ee             	mov    %rbp,%rsi
    6151:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6157:	4c 89 ef             	mov    %r13,%rdi
    615a:	49 89 c4             	mov    %rax,%r12
    615d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6161:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6167:	e8 94 fb ff ff       	call   5d00 <fwp_p_ad_push>
    616c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6172:	f2 0f 59 1d 1e 59 00 	mulsd  0x591e(%rip),%xmm3        # ba98 <msg.8+0xc8>
    6179:	00 
    617a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6181:	00 59 40 
    6184:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6189:	48 89 c2             	mov    %rax,%rdx
    618c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6193:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6199:	e8 62 fb ff ff       	call   5d00 <fwp_p_ad_push>
    619e:	4c 89 e2             	mov    %r12,%rdx
    61a1:	48 89 d9             	mov    %rbx,%rcx
    61a4:	48 89 de             	mov    %rbx,%rsi
    61a7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    61ad:	4c 89 e7             	mov    %r12,%rdi
    61b0:	48 89 c5             	mov    %rax,%rbp
    61b3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    61b7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61bd:	e8 3e fb ff ff       	call   5d00 <fwp_p_ad_push>
    61c2:	48 89 c7             	mov    %rax,%rdi
    61c5:	e8 56 eb ff ff       	call   4d20 <caf75>
    61ca:	48 89 c6             	mov    %rax,%rsi
    61cd:	e8 4e eb ff ff       	call   4d20 <caf75>
    61d2:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    61d8:	48 89 ea             	mov    %rbp,%rdx
    61db:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    61e1:	48 89 c1             	mov    %rax,%rcx
    61e4:	66 48 0f 7e db       	movq   %xmm3,%rbx
    61e9:	e8 12 fb ff ff       	call   5d00 <fwp_p_ad_push>
    61ee:	48 83 c4 28          	add    $0x28,%rsp
    61f2:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    61f7:	5b                   	pop    %rbx
    61f8:	5d                   	pop    %rbp
    61f9:	41 5c                	pop    %r12
    61fb:	41 5d                	pop    %r13
    61fd:	c3                   	ret
    61fe:	66 90                	xchg   %ax,%ax

0000000000006200 <w176.constprop.0>:
    6200:	41 54                	push   %r12
    6202:	55                   	push   %rbp
    6203:	53                   	push   %rbx
    6204:	48 83 ec 10          	sub    $0x10,%rsp
    6208:	4c 8b 27             	mov    (%rdi),%r12
    620b:	4d 85 e4             	test   %r12,%r12
    620e:	74 78                	je     6288 <w176.constprop.0+0x88>
    6210:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6217:	00 00 
    6219:	48 89 fd             	mov    %rdi,%rbp
    621c:	31 db                	xor    %ebx,%ebx
    621e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    622c:	00 00 00 00 
    6230:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6235:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    623b:	48 83 c3 02          	add    $0x2,%rbx
    623f:	e8 dc ea ff ff       	call   4d20 <caf75>
    6244:	48 89 c6             	mov    %rax,%rsi
    6247:	e8 d4 ea ff ff       	call   4d20 <caf75>
    624c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6252:	4c 89 c2             	mov    %r8,%rdx
    6255:	48 89 c1             	mov    %rax,%rcx
    6258:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    625e:	e8 9d fa ff ff       	call   5d00 <fwp_p_ad_push>
    6263:	48 89 c7             	mov    %rax,%rdi
    6266:	4c 39 e3             	cmp    %r12,%rbx
    6269:	72 c5                	jb     6230 <w176.constprop.0+0x30>
    626b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6270:	48 83 c4 10          	add    $0x10,%rsp
    6274:	5b                   	pop    %rbx
    6275:	5d                   	pop    %rbp
    6276:	66 48 0f 6e c0       	movq   %rax,%xmm0
    627b:	41 5c                	pop    %r12
    627d:	48 89 f8             	mov    %rdi,%rax
    6280:	c3                   	ret
    6281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6288:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    628f:	00 00 
    6291:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6298:	eb d1                	jmp    626b <w176.constprop.0+0x6b>
    629a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000062a0 <fwp_rc_share>:
    62a0:	48 8b 05 b1 a8 01 00 	mov    0x1a8b1(%rip),%rax        # 20b58 <fwp_heap+0x13d8>
    62a7:	48 2b 3d 82 a8 01 00 	sub    0x1a882(%rip),%rdi        # 20b30 <fwp_heap+0x13b0>
    62ae:	48 c1 e0 10          	shl    $0x10,%rax
    62b2:	48 39 c7             	cmp    %rax,%rdi
    62b5:	73 4a                	jae    6301 <fwp_rc_share+0x61>
    62b7:	48 89 f8             	mov    %rdi,%rax
    62ba:	48 c1 e8 10          	shr    $0x10,%rax
    62be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    62c2:	48 8b 05 af a8 01 00 	mov    0x1a8af(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    62c9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    62cd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    62d1:	48 85 d2             	test   %rdx,%rdx
    62d4:	74 2b                	je     6301 <fwp_rc_share+0x61>
    62d6:	0f b6 08             	movzbl (%rax),%ecx
    62d9:	80 f9 02             	cmp    $0x2,%cl
    62dc:	74 2a                	je     6308 <fwp_rc_share+0x68>
    62de:	80 f9 01             	cmp    $0x1,%cl
    62e1:	75 1e                	jne    6301 <fwp_rc_share+0x61>
    62e3:	8b 48 18             	mov    0x18(%rax),%ecx
    62e6:	0f b7 ff             	movzwl %di,%edi
    62e9:	8b 40 1c             	mov    0x1c(%rax),%eax
    62ec:	48 0f af f9          	imul   %rcx,%rdi
    62f0:	48 c1 ef 20          	shr    $0x20,%rdi
    62f4:	48 39 c7             	cmp    %rax,%rdi
    62f7:	73 08                	jae    6301 <fwp_rc_share+0x61>
    62f9:	48 01 fa             	add    %rdi,%rdx
    62fc:	80 3a 00             	cmpb   $0x0,(%rdx)
    62ff:	75 0d                	jne    630e <fwp_rc_share+0x6e>
    6301:	c3                   	ret
    6302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6308:	66 85 ff             	test   %di,%di
    630b:	74 ef                	je     62fc <fwp_rc_share+0x5c>
    630d:	c3                   	ret
    630e:	50                   	push   %rax
    630f:	48 8d 3d 02 55 00 00 	lea    0x5502(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    6316:	e8 85 de ff ff       	call   41a0 <fwp_trap>
    631b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006320 <fwp_rc_free_obj>:
    6320:	48 8b 15 31 a8 01 00 	mov    0x1a831(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 2b 05 ff a7 01 00 	sub    0x1a7ff(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6331:	48 c1 e2 10          	shl    $0x10,%rdx
    6335:	48 39 d0             	cmp    %rdx,%rax
    6338:	73 5b                	jae    6395 <fwp_rc_free_obj+0x75>
    633a:	48 89 c2             	mov    %rax,%rdx
    633d:	48 c1 ea 10          	shr    $0x10,%rdx
    6341:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6345:	48 8b 15 2c a8 01 00 	mov    0x1a82c(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    634c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6350:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6354:	48 85 c9             	test   %rcx,%rcx
    6357:	74 3c                	je     6395 <fwp_rc_free_obj+0x75>
    6359:	0f b6 32             	movzbl (%rdx),%esi
    635c:	40 80 fe 02          	cmp    $0x2,%sil
    6360:	74 2e                	je     6390 <fwp_rc_free_obj+0x70>
    6362:	40 80 fe 01          	cmp    $0x1,%sil
    6366:	75 2d                	jne    6395 <fwp_rc_free_obj+0x75>
    6368:	8b 72 18             	mov    0x18(%rdx),%esi
    636b:	0f b7 c0             	movzwl %ax,%eax
    636e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6371:	48 0f af c6          	imul   %rsi,%rax
    6375:	48 c1 e8 20          	shr    $0x20,%rax
    6379:	48 39 d0             	cmp    %rdx,%rax
    637c:	73 17                	jae    6395 <fwp_rc_free_obj+0x75>
    637e:	48 01 c1             	add    %rax,%rcx
    6381:	80 39 01             	cmpb   $0x1,(%rcx)
    6384:	75 0f                	jne    6395 <fwp_rc_free_obj+0x75>
    6386:	e9 25 f2 ff ff       	jmp    55b0 <fwp_mem_free>
    638b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6390:	66 85 c0             	test   %ax,%ax
    6393:	74 ec                	je     6381 <fwp_rc_free_obj+0x61>
    6395:	c3                   	ret
    6396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    639d:	00 00 00 

00000000000063a0 <fwp_rc_dup>:
    63a0:	f3 0f 1e fa          	endbr64
    63a4:	48 8b 05 ad a7 01 00 	mov    0x1a7ad(%rip),%rax        # 20b58 <fwp_heap+0x13d8>
    63ab:	48 2b 3d 7e a7 01 00 	sub    0x1a77e(%rip),%rdi        # 20b30 <fwp_heap+0x13b0>
    63b2:	48 c1 e0 10          	shl    $0x10,%rax
    63b6:	48 39 c7             	cmp    %rax,%rdi
    63b9:	73 56                	jae    6411 <fwp_rc_dup+0x71>
    63bb:	48 89 f8             	mov    %rdi,%rax
    63be:	48 c1 e8 10          	shr    $0x10,%rax
    63c2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63c6:	48 8b 05 ab a7 01 00 	mov    0x1a7ab(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    63cd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    63d1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    63d5:	48 85 c0             	test   %rax,%rax
    63d8:	74 37                	je     6411 <fwp_rc_dup+0x71>
    63da:	0f b6 0a             	movzbl (%rdx),%ecx
    63dd:	80 f9 02             	cmp    $0x2,%cl
    63e0:	74 36                	je     6418 <fwp_rc_dup+0x78>
    63e2:	80 f9 01             	cmp    $0x1,%cl
    63e5:	75 2a                	jne    6411 <fwp_rc_dup+0x71>
    63e7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    63ea:	0f b7 ff             	movzwl %di,%edi
    63ed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    63f0:	48 0f af f9          	imul   %rcx,%rdi
    63f4:	48 c1 ef 20          	shr    $0x20,%rdi
    63f8:	48 39 d7             	cmp    %rdx,%rdi
    63fb:	73 14                	jae    6411 <fwp_rc_dup+0x71>
    63fd:	48 01 f8             	add    %rdi,%rax
    6400:	0f b6 10             	movzbl (%rax),%edx
    6403:	84 d2                	test   %dl,%dl
    6405:	74 0a                	je     6411 <fwp_rc_dup+0x71>
    6407:	80 fa fd             	cmp    $0xfd,%dl
    640a:	77 14                	ja     6420 <fwp_rc_dup+0x80>
    640c:	83 c2 01             	add    $0x1,%edx
    640f:	88 10                	mov    %dl,(%rax)
    6411:	c3                   	ret
    6412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6418:	66 85 ff             	test   %di,%di
    641b:	74 e3                	je     6400 <fwp_rc_dup+0x60>
    641d:	c3                   	ret
    641e:	66 90                	xchg   %ax,%ax
    6420:	48 89 c7             	mov    %rax,%rdi
    6423:	e9 28 ee ff ff       	jmp    5250 <fwp_rc_wide_dup>
    6428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    642f:	00 

0000000000006430 <fwp_owned_entry173>:
    6430:	f3 0f 1e fa          	endbr64
    6434:	48 83 ec 38          	sub    $0x38,%rsp
    6438:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    643d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6444:	00 00 
    6446:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    644b:	31 c0                	xor    %eax,%eax
    644d:	48 8b 07             	mov    (%rdi),%rax
    6450:	48 03 47 10          	add    0x10(%rdi),%rax
    6454:	0f 80 c2 00 00 00    	jo     651c <fwp_owned_entry173+0xec>
    645a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    645f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6464:	31 ff                	xor    %edi,%edi
    6466:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    646a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    646f:	e8 5c f7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    6474:	48 8b 15 dd a6 01 00 	mov    0x1a6dd(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    647b:	48 89 c6             	mov    %rax,%rsi
    647e:	48 2b 05 ab a6 01 00 	sub    0x1a6ab(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6485:	48 c1 e2 10          	shl    $0x10,%rdx
    6489:	48 39 d0             	cmp    %rdx,%rax
    648c:	73 4f                	jae    64dd <fwp_owned_entry173+0xad>
    648e:	48 89 c2             	mov    %rax,%rdx
    6491:	48 c1 ea 10          	shr    $0x10,%rdx
    6495:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6499:	48 8b 15 d8 a6 01 00 	mov    0x1a6d8(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    64a0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    64a4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    64a8:	48 85 d2             	test   %rdx,%rdx
    64ab:	74 30                	je     64dd <fwp_owned_entry173+0xad>
    64ad:	0f b6 39             	movzbl (%rcx),%edi
    64b0:	40 80 ff 02          	cmp    $0x2,%dil
    64b4:	74 42                	je     64f8 <fwp_owned_entry173+0xc8>
    64b6:	40 80 ff 01          	cmp    $0x1,%dil
    64ba:	75 21                	jne    64dd <fwp_owned_entry173+0xad>
    64bc:	8b 79 18             	mov    0x18(%rcx),%edi
    64bf:	0f b7 c0             	movzwl %ax,%eax
    64c2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64c5:	48 0f af c7          	imul   %rdi,%rax
    64c9:	48 c1 e8 20          	shr    $0x20,%rax
    64cd:	48 39 c8             	cmp    %rcx,%rax
    64d0:	73 0b                	jae    64dd <fwp_owned_entry173+0xad>
    64d2:	48 01 c2             	add    %rax,%rdx
    64d5:	80 3a ff             	cmpb   $0xff,(%rdx)
    64d8:	74 26                	je     6500 <fwp_owned_entry173+0xd0>
    64da:	c6 02 01             	movb   $0x1,(%rdx)
    64dd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    64e2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    64e9:	00 00 
    64eb:	75 34                	jne    6521 <fwp_owned_entry173+0xf1>
    64ed:	48 89 f0             	mov    %rsi,%rax
    64f0:	48 83 c4 38          	add    $0x38,%rsp
    64f4:	c3                   	ret
    64f5:	0f 1f 00             	nopl   (%rax)
    64f8:	66 85 c0             	test   %ax,%ax
    64fb:	75 e0                	jne    64dd <fwp_owned_entry173+0xad>
    64fd:	eb d6                	jmp    64d5 <fwp_owned_entry173+0xa5>
    64ff:	90                   	nop
    6500:	48 89 d7             	mov    %rdx,%rdi
    6503:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6508:	48 89 14 24          	mov    %rdx,(%rsp)
    650c:	e8 5f ee ff ff       	call   5370 <fwp_rc_forget_slot>
    6511:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6516:	48 8b 14 24          	mov    (%rsp),%rdx
    651a:	eb be                	jmp    64da <fwp_owned_entry173+0xaa>
    651c:	e8 df d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6521:	e8 3a cf ff ff       	call   3460 <__stack_chk_fail@plt>
    6526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    652d:	00 00 00 

0000000000006530 <e173>:
    6530:	f3 0f 1e fa          	endbr64
    6534:	53                   	push   %rbx
    6535:	48 83 ec 30          	sub    $0x30,%rsp
    6539:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    653e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6545:	00 00 
    6547:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    654c:	31 c0                	xor    %eax,%eax
    654e:	48 8b 07             	mov    (%rdi),%rax
    6551:	48 03 47 10          	add    0x10(%rdi),%rax
    6555:	0f 80 c9 00 00 00    	jo     6624 <e173+0xf4>
    655b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6560:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6565:	31 ff                	xor    %edi,%edi
    6567:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    656b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6570:	e8 5b f6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    6575:	48 8b 15 dc a5 01 00 	mov    0x1a5dc(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    657c:	48 89 c3             	mov    %rax,%rbx
    657f:	48 2b 05 aa a5 01 00 	sub    0x1a5aa(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6586:	48 c1 e2 10          	shl    $0x10,%rdx
    658a:	48 39 d0             	cmp    %rdx,%rax
    658d:	73 4f                	jae    65de <e173+0xae>
    658f:	48 89 c2             	mov    %rax,%rdx
    6592:	48 c1 ea 10          	shr    $0x10,%rdx
    6596:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    659a:	48 8b 15 d7 a5 01 00 	mov    0x1a5d7(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    65a1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65a5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65a9:	48 85 d2             	test   %rdx,%rdx
    65ac:	74 30                	je     65de <e173+0xae>
    65ae:	0f b6 31             	movzbl (%rcx),%esi
    65b1:	40 80 fe 02          	cmp    $0x2,%sil
    65b5:	74 49                	je     6600 <e173+0xd0>
    65b7:	40 80 fe 01          	cmp    $0x1,%sil
    65bb:	75 21                	jne    65de <e173+0xae>
    65bd:	8b 71 18             	mov    0x18(%rcx),%esi
    65c0:	0f b7 c0             	movzwl %ax,%eax
    65c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65c6:	48 0f af c6          	imul   %rsi,%rax
    65ca:	48 c1 e8 20          	shr    $0x20,%rax
    65ce:	48 39 c8             	cmp    %rcx,%rax
    65d1:	73 0b                	jae    65de <e173+0xae>
    65d3:	48 01 c2             	add    %rax,%rdx
    65d6:	80 3a ff             	cmpb   $0xff,(%rdx)
    65d9:	74 35                	je     6610 <e173+0xe0>
    65db:	c6 02 01             	movb   $0x1,(%rdx)
    65de:	48 89 df             	mov    %rbx,%rdi
    65e1:	e8 ba fc ff ff       	call   62a0 <fwp_rc_share>
    65e6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    65eb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    65f2:	00 00 
    65f4:	75 33                	jne    6629 <e173+0xf9>
    65f6:	48 83 c4 30          	add    $0x30,%rsp
    65fa:	48 89 d8             	mov    %rbx,%rax
    65fd:	5b                   	pop    %rbx
    65fe:	c3                   	ret
    65ff:	90                   	nop
    6600:	66 85 c0             	test   %ax,%ax
    6603:	75 d9                	jne    65de <e173+0xae>
    6605:	eb cf                	jmp    65d6 <e173+0xa6>
    6607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    660e:	00 00 
    6610:	48 89 d7             	mov    %rdx,%rdi
    6613:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6618:	e8 53 ed ff ff       	call   5370 <fwp_rc_forget_slot>
    661d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6622:	eb b7                	jmp    65db <e173+0xab>
    6624:	e8 d7 d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6629:	e8 32 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    662e:	66 90                	xchg   %ax,%ax

0000000000006630 <fwp_closure_drop>:
    6630:	48 8b 15 21 a5 01 00 	mov    0x1a521(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    6637:	48 89 f8             	mov    %rdi,%rax
    663a:	48 2b 05 ef a4 01 00 	sub    0x1a4ef(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6641:	48 c1 e2 10          	shl    $0x10,%rdx
    6645:	48 39 d0             	cmp    %rdx,%rax
    6648:	73 6b                	jae    66b5 <fwp_closure_drop+0x85>
    664a:	48 89 c2             	mov    %rax,%rdx
    664d:	48 c1 ea 10          	shr    $0x10,%rdx
    6651:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6655:	48 8b 15 1c a5 01 00 	mov    0x1a51c(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    665c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6660:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6664:	48 85 d2             	test   %rdx,%rdx
    6667:	74 4c                	je     66b5 <fwp_closure_drop+0x85>
    6669:	0f b6 31             	movzbl (%rcx),%esi
    666c:	40 80 fe 02          	cmp    $0x2,%sil
    6670:	74 3e                	je     66b0 <fwp_closure_drop+0x80>
    6672:	40 80 fe 01          	cmp    $0x1,%sil
    6676:	75 3d                	jne    66b5 <fwp_closure_drop+0x85>
    6678:	8b 71 18             	mov    0x18(%rcx),%esi
    667b:	0f b7 c0             	movzwl %ax,%eax
    667e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6681:	48 0f af c6          	imul   %rsi,%rax
    6685:	48 c1 e8 20          	shr    $0x20,%rax
    6689:	48 39 c8             	cmp    %rcx,%rax
    668c:	73 27                	jae    66b5 <fwp_closure_drop+0x85>
    668e:	48 01 c2             	add    %rax,%rdx
    6691:	0f b6 02             	movzbl (%rdx),%eax
    6694:	84 c0                	test   %al,%al
    6696:	74 1d                	je     66b5 <fwp_closure_drop+0x85>
    6698:	3c 01                	cmp    $0x1,%al
    669a:	74 24                	je     66c0 <fwp_closure_drop+0x90>
    669c:	3c ff                	cmp    $0xff,%al
    669e:	74 48                	je     66e8 <fwp_closure_drop+0xb8>
    66a0:	83 e8 01             	sub    $0x1,%eax
    66a3:	88 02                	mov    %al,(%rdx)
    66a5:	c3                   	ret
    66a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66ad:	00 00 00 
    66b0:	66 85 c0             	test   %ax,%ax
    66b3:	74 dc                	je     6691 <fwp_closure_drop+0x61>
    66b5:	c3                   	ret
    66b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66bd:	00 00 00 
    66c0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    66c7:	ff ff 
    66c9:	48 85 c0             	test   %rax,%rax
    66cc:	74 12                	je     66e0 <fwp_closure_drop+0xb0>
    66ce:	48 89 fe             	mov    %rdi,%rsi
    66d1:	48 89 c7             	mov    %rax,%rdi
    66d4:	e9 27 db ff ff       	jmp    4200 <fwp_closure_drop_push>
    66d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66e0:	e9 cb dc ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    66e5:	0f 1f 00             	nopl   (%rax)
    66e8:	48 89 d0             	mov    %rdx,%rax
    66eb:	48 8d 35 8e 90 01 00 	lea    0x1908e(%rip),%rsi        # 1f780 <fwp_heap>
    66f2:	48 83 ec 18          	sub    $0x18,%rsp
    66f6:	48 c1 e8 11          	shr    $0x11,%rax
    66fa:	48 31 d0             	xor    %rdx,%rax
    66fd:	48 89 c1             	mov    %rax,%rcx
    6700:	48 c1 e9 09          	shr    $0x9,%rcx
    6704:	48 31 c8             	xor    %rcx,%rax
    6707:	0f b6 c8             	movzbl %al,%ecx
    670a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6711:	00 
    6712:	48 85 c0             	test   %rax,%rax
    6715:	75 12                	jne    6729 <fwp_closure_drop+0xf9>
    6717:	eb 49                	jmp    6762 <fwp_closure_drop+0x132>
    6719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6720:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6724:	48 85 c0             	test   %rax,%rax
    6727:	74 39                	je     6762 <fwp_closure_drop+0x132>
    6729:	48 89 c1             	mov    %rax,%rcx
    672c:	48 39 10             	cmp    %rdx,(%rax)
    672f:	75 ef                	jne    6720 <fwp_closure_drop+0xf0>
    6731:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6735:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6739:	48 89 48 08          	mov    %rcx,0x8(%rax)
    673d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6744:	74 05                	je     674b <fwp_closure_drop+0x11b>
    6746:	48 83 c4 18          	add    $0x18,%rsp
    674a:	c3                   	ret
    674b:	48 89 d7             	mov    %rdx,%rdi
    674e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6753:	e8 18 ec ff ff       	call   5370 <fwp_rc_forget_slot>
    6758:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    675d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6760:	eb e4                	jmp    6746 <fwp_closure_drop+0x116>
    6762:	48 8d 3d 0f 50 00 00 	lea    0x500f(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    6769:	e8 32 da ff ff       	call   41a0 <fwp_trap>
    676e:	66 90                	xchg   %ax,%ax

0000000000006770 <fwp_owned_tape_release>:
    6770:	48 85 ff             	test   %rdi,%rdi
    6773:	0f 84 f7 00 00 00    	je     6870 <fwp_owned_tape_release+0x100>
    6779:	41 54                	push   %r12
    677b:	55                   	push   %rbp
    677c:	53                   	push   %rbx
    677d:	48 8b 07             	mov    (%rdi),%rax
    6780:	48 85 c0             	test   %rax,%rax
    6783:	74 08                	je     678d <fwp_owned_tape_release+0x1d>
    6785:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6789:	48 89 50 08          	mov    %rdx,0x8(%rax)
    678d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6791:	48 85 d2             	test   %rdx,%rdx
    6794:	74 03                	je     6799 <fwp_owned_tape_release+0x29>
    6796:	48 89 02             	mov    %rax,(%rdx)
    6799:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    679d:	48 89 fb             	mov    %rdi,%rbx
    67a0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    67a4:	48 85 c0             	test   %rax,%rax
    67a7:	0f 84 89 00 00 00    	je     6836 <fwp_owned_tape_release+0xc6>
    67ad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    67b1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    67b5:	7e 47                	jle    67fe <fwp_owned_tape_release+0x8e>
    67b7:	31 ed                	xor    %ebp,%ebp
    67b9:	eb 0d                	jmp    67c8 <fwp_owned_tape_release+0x58>
    67bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67c0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    67c4:	48 8b 40 68          	mov    0x68(%rax),%rax
    67c8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    67cc:	49 89 ec             	mov    %rbp,%r12
    67cf:	48 83 c5 01          	add    $0x1,%rbp
    67d3:	49 c1 e4 04          	shl    $0x4,%r12
    67d7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    67db:	ff d0                	call   *%rax
    67dd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    67e1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    67e6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    67ea:	ff 50 68             	call   *0x68(%rax)
    67ed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    67f1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    67f5:	48 39 e8             	cmp    %rbp,%rax
    67f8:	7f c6                	jg     67c0 <fwp_owned_tape_release+0x50>
    67fa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    67fe:	31 ed                	xor    %ebp,%ebp
    6800:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6805:	7e 28                	jle    682f <fwp_owned_tape_release+0xbf>
    6807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    680e:	00 00 
    6810:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6814:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6818:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    681c:	74 07                	je     6825 <fwp_owned_tape_release+0xb5>
    681e:	ff 52 68             	call   *0x68(%rdx)
    6821:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6825:	48 83 c5 01          	add    $0x1,%rbp
    6829:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    682d:	7f e1                	jg     6810 <fwp_owned_tape_release+0xa0>
    682f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6833:	ff 52 68             	call   *0x68(%rdx)
    6836:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    683a:	e8 f1 fd ff ff       	call   6630 <fwp_closure_drop>
    683f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6843:	e8 e8 fd ff ff       	call   6630 <fwp_closure_drop>
    6848:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    684c:	e8 df fd ff ff       	call   6630 <fwp_closure_drop>
    6851:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6855:	e8 56 ed ff ff       	call   55b0 <fwp_mem_free>
    685a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    685e:	e8 4d ed ff ff       	call   55b0 <fwp_mem_free>
    6863:	48 89 df             	mov    %rbx,%rdi
    6866:	5b                   	pop    %rbx
    6867:	5d                   	pop    %rbp
    6868:	41 5c                	pop    %r12
    686a:	e9 41 ed ff ff       	jmp    55b0 <fwp_mem_free>
    686f:	90                   	nop
    6870:	c3                   	ret
    6871:	0f 1f 40 00          	nopl   0x0(%rax)
    6875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    687c:	00 00 00 00 

0000000000006880 <fwp_tape_finish>:
    6880:	f3 0f 1e fa          	endbr64
    6884:	41 56                	push   %r14
    6886:	48 8d 3d 33 88 01 00 	lea    0x18833(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    688d:	41 55                	push   %r13
    688f:	41 54                	push   %r12
    6891:	55                   	push   %rbp
    6892:	53                   	push   %rbx
    6893:	e8 d8 d6 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6898:	48 83 3d 68 88 01 00 	cmpq   $0x0,0x18868(%rip)        # 1f108 <fwp_ntapes>
    689f:	00 
    68a0:	48 c7 05 fd 87 01 00 	movq   $0x0,0x187fd(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    68a7:	00 00 00 00 
    68ab:	7e 68                	jle    6915 <fwp_tape_finish+0x95>
    68ad:	45 31 e4             	xor    %r12d,%r12d
    68b0:	31 ed                	xor    %ebp,%ebp
    68b2:	0f 1f 00             	nopl   (%rax)
    68b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68bc:	00 00 00 00 
    68c0:	48 8b 1d 49 88 01 00 	mov    0x18849(%rip),%rbx        # 1f110 <fwp_tapes>
    68c7:	48 83 c5 01          	add    $0x1,%rbp
    68cb:	4c 01 e3             	add    %r12,%rbx
    68ce:	49 83 c4 68          	add    $0x68,%r12
    68d2:	48 89 df             	mov    %rbx,%rdi
    68d5:	e8 26 d3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    68da:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    68de:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    68e2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    68e6:	e8 d5 ca ff ff       	call   33c0 <free@plt>
    68eb:	4c 89 f7             	mov    %r14,%rdi
    68ee:	e8 cd ca ff ff       	call   33c0 <free@plt>
    68f3:	4c 89 ef             	mov    %r13,%rdi
    68f6:	e8 c5 ca ff ff       	call   33c0 <free@plt>
    68fb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    68ff:	e8 6c fe ff ff       	call   6770 <fwp_owned_tape_release>
    6904:	48 39 2d fd 87 01 00 	cmp    %rbp,0x187fd(%rip)        # 1f108 <fwp_ntapes>
    690b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6912:	00 
    6913:	7f ab                	jg     68c0 <fwp_tape_finish+0x40>
    6915:	48 8b 3d f4 87 01 00 	mov    0x187f4(%rip),%rdi        # 1f110 <fwp_tapes>
    691c:	e8 9f ca ff ff       	call   33c0 <free@plt>
    6921:	5b                   	pop    %rbx
    6922:	5d                   	pop    %rbp
    6923:	48 c7 05 e2 87 01 00 	movq   $0x0,0x187e2(%rip)        # 1f110 <fwp_tapes>
    692a:	00 00 00 00 
    692e:	48 c7 05 c7 87 01 00 	movq   $0x0,0x187c7(%rip)        # 1f100 <fwp_tapes_cap>
    6935:	00 00 00 00 
    6939:	41 5c                	pop    %r12
    693b:	48 c7 05 c2 87 01 00 	movq   $0x0,0x187c2(%rip)        # 1f108 <fwp_ntapes>
    6942:	00 00 00 00 
    6946:	41 5d                	pop    %r13
    6948:	48 c7 05 a5 87 01 00 	movq   $0x0,0x187a5(%rip)        # 1f0f8 <fwp_tape_next_slot>
    694f:	00 00 00 00 
    6953:	41 5e                	pop    %r14
    6955:	c3                   	ret
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 

0000000000006960 <fwp_tape_scope_release>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	41 55                	push   %r13
    6966:	41 54                	push   %r12
    6968:	55                   	push   %rbp
    6969:	53                   	push   %rbx
    696a:	48 83 ec 58          	sub    $0x58,%rsp
    696e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6975:	00 00 
    6977:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    697c:	48 63 07             	movslq (%rdi),%rax
    697f:	85 c0                	test   %eax,%eax
    6981:	0f 88 05 01 00 00    	js     6a8c <fwp_tape_scope_release+0x12c>
    6987:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    698e:	ec c4 4e 
    6991:	48 89 fb             	mov    %rdi,%rbx
    6994:	eb 3c                	jmp    69d2 <fwp_tape_scope_release+0x72>
    6996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    699d:	00 00 00 
    69a0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    69a5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    69a9:	e8 12 ca ff ff       	call   33c0 <free@plt>
    69ae:	48 8b 3c 24          	mov    (%rsp),%rdi
    69b2:	e8 09 ca ff ff       	call   33c0 <free@plt>
    69b7:	4c 89 ef             	mov    %r13,%rdi
    69ba:	e8 01 ca ff ff       	call   33c0 <free@plt>
    69bf:	4c 89 e7             	mov    %r12,%rdi
    69c2:	e8 a9 fd ff ff       	call   6770 <fwp_owned_tape_release>
    69c7:	48 63 03             	movslq (%rbx),%rax
    69ca:	85 c0                	test   %eax,%eax
    69cc:	0f 88 ba 00 00 00    	js     6a8c <fwp_tape_scope_release+0x12c>
    69d2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    69d6:	48 8b 35 33 87 01 00 	mov    0x18733(%rip),%rsi        # 1f110 <fwp_tapes>
    69dd:	4c 01 c6             	add    %r8,%rsi
    69e0:	48 89 f7             	mov    %rsi,%rdi
    69e3:	e8 18 d2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    69e8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    69ed:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    69f2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    69f9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    69fd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6a01:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6a08:	00 
    6a09:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6a0e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6a12:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6a17:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6a1b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6a20:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6a27:	00 
    6a28:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6a2f:	00 
    6a30:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6a37:	00 
    6a38:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6a3d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6a42:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6a46:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6a4a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6a4e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6a54:	77 18                	ja     6a6e <fwp_tape_scope_release+0x10e>
    6a56:	49 c1 f8 03          	sar    $0x3,%r8
    6a5a:	4c 0f af c5          	imul   %rbp,%r8
    6a5e:	4c 3b 05 93 86 01 00 	cmp    0x18693(%rip),%r8        # 1f0f8 <fwp_tape_next_slot>
    6a65:	7d 07                	jge    6a6e <fwp_tape_scope_release+0x10e>
    6a67:	4c 89 05 8a 86 01 00 	mov    %r8,0x1868a(%rip)        # 1f0f8 <fwp_tape_next_slot>
    6a6e:	4d 85 e4             	test   %r12,%r12
    6a71:	0f 85 29 ff ff ff    	jne    69a0 <fwp_tape_scope_release+0x40>
    6a77:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6a7c:	e8 0f e4 ff ff       	call   4e90 <fwp_tape_buffers_release>
    6a81:	48 63 03             	movslq (%rbx),%rax
    6a84:	85 c0                	test   %eax,%eax
    6a86:	0f 89 46 ff ff ff    	jns    69d2 <fwp_tape_scope_release+0x72>
    6a8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6a91:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a98:	00 00 
    6a9a:	75 0b                	jne    6aa7 <fwp_tape_scope_release+0x147>
    6a9c:	48 83 c4 58          	add    $0x58,%rsp
    6aa0:	5b                   	pop    %rbx
    6aa1:	5d                   	pop    %rbp
    6aa2:	41 5c                	pop    %r12
    6aa4:	41 5d                	pop    %r13
    6aa6:	c3                   	ret
    6aa7:	e8 b4 c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006ab0 <fwp_drop4>:
    6ab0:	48 8b 0d a1 a0 01 00 	mov    0x1a0a1(%rip),%rcx        # 20b58 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 2b 05 6f a0 01 00 	sub    0x1a06f(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6ac1:	48 c1 e1 10          	shl    $0x10,%rcx
    6ac5:	48 39 c8             	cmp    %rcx,%rax
    6ac8:	0f 83 42 01 00 00    	jae    6c10 <fwp_drop4+0x160>
    6ace:	48 83 ec 18          	sub    $0x18,%rsp
    6ad2:	48 89 fa             	mov    %rdi,%rdx
    6ad5:	4c 8d 05 a4 8c 01 00 	lea    0x18ca4(%rip),%r8        # 1f780 <fwp_heap>
    6adc:	48 89 c1             	mov    %rax,%rcx
    6adf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6ae6:	48 c1 e9 10          	shr    $0x10,%rcx
    6aea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6aee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6af2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6af6:	48 85 c9             	test   %rcx,%rcx
    6af9:	74 40                	je     6b3b <fwp_drop4+0x8b>
    6afb:	0f b6 3e             	movzbl (%rsi),%edi
    6afe:	40 80 ff 02          	cmp    $0x2,%dil
    6b02:	74 3c                	je     6b40 <fwp_drop4+0x90>
    6b04:	40 80 ff 01          	cmp    $0x1,%dil
    6b08:	75 31                	jne    6b3b <fwp_drop4+0x8b>
    6b0a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6b0d:	0f b7 c0             	movzwl %ax,%eax
    6b10:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6b13:	48 0f af c7          	imul   %rdi,%rax
    6b17:	48 c1 e8 20          	shr    $0x20,%rax
    6b1b:	48 39 f0             	cmp    %rsi,%rax
    6b1e:	73 1b                	jae    6b3b <fwp_drop4+0x8b>
    6b20:	48 01 c1             	add    %rax,%rcx
    6b23:	0f b6 01             	movzbl (%rcx),%eax
    6b26:	84 c0                	test   %al,%al
    6b28:	74 11                	je     6b3b <fwp_drop4+0x8b>
    6b2a:	3c 01                	cmp    $0x1,%al
    6b2c:	74 22                	je     6b50 <fwp_drop4+0xa0>
    6b2e:	3c ff                	cmp    $0xff,%al
    6b30:	0f 84 0a 01 00 00    	je     6c40 <fwp_drop4+0x190>
    6b36:	83 e8 01             	sub    $0x1,%eax
    6b39:	88 01                	mov    %al,(%rcx)
    6b3b:	48 83 c4 18          	add    $0x18,%rsp
    6b3f:	c3                   	ret
    6b40:	66 85 c0             	test   %ax,%ax
    6b43:	74 de                	je     6b23 <fwp_drop4+0x73>
    6b45:	48 83 c4 18          	add    $0x18,%rsp
    6b49:	c3                   	ret
    6b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b50:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6b54:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6b5b:	48 89 f8             	mov    %rdi,%rax
    6b5e:	48 c1 e1 10          	shl    $0x10,%rcx
    6b62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b69:	48 39 c8             	cmp    %rcx,%rax
    6b6c:	73 62                	jae    6bd0 <fwp_drop4+0x120>
    6b6e:	48 89 c1             	mov    %rax,%rcx
    6b71:	48 c1 e9 10          	shr    $0x10,%rcx
    6b75:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6b79:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6b7d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6b81:	48 85 c9             	test   %rcx,%rcx
    6b84:	74 4a                	je     6bd0 <fwp_drop4+0x120>
    6b86:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6b8a:	41 80 f9 02          	cmp    $0x2,%r9b
    6b8e:	0f 84 9c 00 00 00    	je     6c30 <fwp_drop4+0x180>
    6b94:	41 80 f9 01          	cmp    $0x1,%r9b
    6b98:	75 36                	jne    6bd0 <fwp_drop4+0x120>
    6b9a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6b9e:	0f b7 c0             	movzwl %ax,%eax
    6ba1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ba4:	49 0f af c1          	imul   %r9,%rax
    6ba8:	48 c1 e8 20          	shr    $0x20,%rax
    6bac:	48 39 f0             	cmp    %rsi,%rax
    6baf:	73 1f                	jae    6bd0 <fwp_drop4+0x120>
    6bb1:	48 01 c1             	add    %rax,%rcx
    6bb4:	0f b6 01             	movzbl (%rcx),%eax
    6bb7:	84 c0                	test   %al,%al
    6bb9:	74 15                	je     6bd0 <fwp_drop4+0x120>
    6bbb:	3c 01                	cmp    $0x1,%al
    6bbd:	74 59                	je     6c18 <fwp_drop4+0x168>
    6bbf:	3c ff                	cmp    $0xff,%al
    6bc1:	0f 84 ff 00 00 00    	je     6cc6 <fwp_drop4+0x216>
    6bc7:	83 e8 01             	sub    $0x1,%eax
    6bca:	88 01                	mov    %al,(%rcx)
    6bcc:	0f 1f 40 00          	nopl   0x0(%rax)
    6bd0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6bd4:	48 89 d7             	mov    %rdx,%rdi
    6bd7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6bdb:	e8 40 f7 ff ff       	call   6320 <fwp_rc_free_obj>
    6be0:	4c 8d 05 99 8b 01 00 	lea    0x18b99(%rip),%r8        # 1f780 <fwp_heap>
    6be7:	48 8b 04 24          	mov    (%rsp),%rax
    6beb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6bf2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6bf9:	48 c1 e2 10          	shl    $0x10,%rdx
    6bfd:	48 39 d0             	cmp    %rdx,%rax
    6c00:	0f 83 35 ff ff ff    	jae    6b3b <fwp_drop4+0x8b>
    6c06:	48 8b 14 24          	mov    (%rsp),%rdx
    6c0a:	e9 cd fe ff ff       	jmp    6adc <fwp_drop4+0x2c>
    6c0f:	90                   	nop
    6c10:	c3                   	ret
    6c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c18:	48 89 14 24          	mov    %rdx,(%rsp)
    6c1c:	e8 ff f6 ff ff       	call   6320 <fwp_rc_free_obj>
    6c21:	48 8b 14 24          	mov    (%rsp),%rdx
    6c25:	eb a9                	jmp    6bd0 <fwp_drop4+0x120>
    6c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c2e:	00 00 
    6c30:	66 85 c0             	test   %ax,%ax
    6c33:	75 9b                	jne    6bd0 <fwp_drop4+0x120>
    6c35:	e9 7a ff ff ff       	jmp    6bb4 <fwp_drop4+0x104>
    6c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c40:	48 89 c8             	mov    %rcx,%rax
    6c43:	48 c1 e8 11          	shr    $0x11,%rax
    6c47:	48 31 c8             	xor    %rcx,%rax
    6c4a:	48 89 c2             	mov    %rax,%rdx
    6c4d:	48 c1 ea 09          	shr    $0x9,%rdx
    6c51:	48 31 d0             	xor    %rdx,%rax
    6c54:	0f b6 d0             	movzbl %al,%edx
    6c57:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6c5e:	00 
    6c5f:	48 85 c0             	test   %rax,%rax
    6c62:	75 29                	jne    6c8d <fwp_drop4+0x1dd>
    6c64:	e9 e3 00 00 00       	jmp    6d4c <fwp_drop4+0x29c>
    6c69:	90                   	nop
    6c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c71:	00 00 00 00 
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 
    6c80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	0f 84 bf 00 00 00    	je     6d4c <fwp_drop4+0x29c>
    6c8d:	48 89 c2             	mov    %rax,%rdx
    6c90:	48 39 08             	cmp    %rcx,(%rax)
    6c93:	75 eb                	jne    6c80 <fwp_drop4+0x1d0>
    6c95:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6c99:	48 83 ea 01          	sub    $0x1,%rdx
    6c9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ca1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ca8:	0f 85 8d fe ff ff    	jne    6b3b <fwp_drop4+0x8b>
    6cae:	48 89 cf             	mov    %rcx,%rdi
    6cb1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6cb5:	e8 b6 e6 ff ff       	call   5370 <fwp_rc_forget_slot>
    6cba:	48 8b 0c 24          	mov    (%rsp),%rcx
    6cbe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6cc1:	e9 75 fe ff ff       	jmp    6b3b <fwp_drop4+0x8b>
    6cc6:	48 89 ce             	mov    %rcx,%rsi
    6cc9:	48 c1 ee 11          	shr    $0x11,%rsi
    6ccd:	48 31 ce             	xor    %rcx,%rsi
    6cd0:	48 89 f0             	mov    %rsi,%rax
    6cd3:	48 c1 e8 09          	shr    $0x9,%rax
    6cd7:	48 31 c6             	xor    %rax,%rsi
    6cda:	40 0f b6 f6          	movzbl %sil,%esi
    6cde:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6ce5:	00 
    6ce6:	48 85 c0             	test   %rax,%rax
    6ce9:	75 1e                	jne    6d09 <fwp_drop4+0x259>
    6ceb:	eb 5f                	jmp    6d4c <fwp_drop4+0x29c>
    6ced:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cf4:	00 
    6cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cfc:	00 00 00 00 
    6d00:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	74 43                	je     6d4c <fwp_drop4+0x29c>
    6d09:	48 89 c6             	mov    %rax,%rsi
    6d0c:	48 39 08             	cmp    %rcx,(%rax)
    6d0f:	75 ef                	jne    6d00 <fwp_drop4+0x250>
    6d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d15:	48 83 ee 01          	sub    $0x1,%rsi
    6d19:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6d1d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6d24:	0f 85 a6 fe ff ff    	jne    6bd0 <fwp_drop4+0x120>
    6d2a:	48 89 cf             	mov    %rcx,%rdi
    6d2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d32:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d36:	e8 35 e6 ff ff       	call   5370 <fwp_rc_forget_slot>
    6d3b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6d3f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d44:	c6 01 fe             	movb   $0xfe,(%rcx)
    6d47:	e9 84 fe ff ff       	jmp    6bd0 <fwp_drop4+0x120>
    6d4c:	48 8d 3d 25 4a 00 00 	lea    0x4a25(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    6d53:	e8 48 d4 ff ff       	call   41a0 <fwp_trap>
    6d58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d5f:	00 

0000000000006d60 <fwp_arg_drop37>:
    6d60:	f3 0f 1e fa          	endbr64
    6d64:	85 f6                	test   %esi,%esi
    6d66:	75 04                	jne    6d6c <fwp_arg_drop37+0xc>
    6d68:	85 d2                	test   %edx,%edx
    6d6a:	75 04                	jne    6d70 <fwp_arg_drop37+0x10>
    6d6c:	c3                   	ret
    6d6d:	0f 1f 00             	nopl   (%rax)
    6d70:	48 8b 3f             	mov    (%rdi),%rdi
    6d73:	e9 38 fd ff ff       	jmp    6ab0 <fwp_drop4>
    6d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d7f:	00 

0000000000006d80 <fwp_task_dispose>:
    6d80:	53                   	push   %rbx
    6d81:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6d85:	0f 84 bb c9 ff ff    	je     3746 <fwp_task_dispose.cold>
    6d8b:	48 89 fb             	mov    %rdi,%rbx
    6d8e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6d93:	0f 85 ad c9 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6d99:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6d9d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6da4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6dab:	00 
    6dac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6db0:	48 85 ff             	test   %rdi,%rdi
    6db3:	74 07                	je     6dbc <fwp_task_dispose+0x3c>
    6db5:	48 85 c0             	test   %rax,%rax
    6db8:	74 02                	je     6dbc <fwp_task_dispose+0x3c>
    6dba:	ff d0                	call   *%rax
    6dbc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6dc3:	e8 e8 e7 ff ff       	call   55b0 <fwp_mem_free>
    6dc8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6dcf:	00 00 00 00 
    6dd3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6dd7:	74 6f                	je     6e48 <fwp_task_dispose+0xc8>
    6dd9:	48 8b 15 78 9d 01 00 	mov    0x19d78(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    6de0:	48 89 d8             	mov    %rbx,%rax
    6de3:	48 2b 05 46 9d 01 00 	sub    0x19d46(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6dea:	48 c1 e2 10          	shl    $0x10,%rdx
    6dee:	48 39 d0             	cmp    %rdx,%rax
    6df1:	73 4c                	jae    6e3f <fwp_task_dispose+0xbf>
    6df3:	48 89 c2             	mov    %rax,%rdx
    6df6:	48 c1 ea 10          	shr    $0x10,%rdx
    6dfa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dfe:	48 8b 15 73 9d 01 00 	mov    0x19d73(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    6e05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6e09:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6e0d:	48 85 c9             	test   %rcx,%rcx
    6e10:	74 2d                	je     6e3f <fwp_task_dispose+0xbf>
    6e12:	0f b6 32             	movzbl (%rdx),%esi
    6e15:	40 80 fe 02          	cmp    $0x2,%sil
    6e19:	74 3d                	je     6e58 <fwp_task_dispose+0xd8>
    6e1b:	40 80 fe 01          	cmp    $0x1,%sil
    6e1f:	75 1e                	jne    6e3f <fwp_task_dispose+0xbf>
    6e21:	8b 72 18             	mov    0x18(%rdx),%esi
    6e24:	0f b7 c0             	movzwl %ax,%eax
    6e27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e2a:	48 0f af c6          	imul   %rsi,%rax
    6e2e:	48 c1 e8 20          	shr    $0x20,%rax
    6e32:	48 39 d0             	cmp    %rdx,%rax
    6e35:	73 08                	jae    6e3f <fwp_task_dispose+0xbf>
    6e37:	48 01 c1             	add    %rax,%rcx
    6e3a:	80 39 01             	cmpb   $0x1,(%rcx)
    6e3d:	74 09                	je     6e48 <fwp_task_dispose+0xc8>
    6e3f:	5b                   	pop    %rbx
    6e40:	c3                   	ret
    6e41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e48:	48 89 df             	mov    %rbx,%rdi
    6e4b:	5b                   	pop    %rbx
    6e4c:	e9 5f e7 ff ff       	jmp    55b0 <fwp_mem_free>
    6e51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e58:	66 85 c0             	test   %ax,%ax
    6e5b:	74 dd                	je     6e3a <fwp_task_dispose+0xba>
    6e5d:	5b                   	pop    %rbx
    6e5e:	c3                   	ret
    6e5f:	90                   	nop

0000000000006e60 <fwp_free_zombie>:
    6e60:	48 8b 15 e9 88 01 00 	mov    0x188e9(%rip),%rdx        # 1f750 <fwp_zombie>
    6e67:	48 85 d2             	test   %rdx,%rdx
    6e6a:	0f 84 98 00 00 00    	je     6f08 <fwp_free_zombie+0xa8>
    6e70:	48 3b 15 e9 88 01 00 	cmp    0x188e9(%rip),%rdx        # 1f760 <fwp_cur>
    6e77:	0f 84 8b 00 00 00    	je     6f08 <fwp_free_zombie+0xa8>
    6e7d:	48 83 ec 18          	sub    $0x18,%rsp
    6e81:	48 63 05 a4 82 01 00 	movslq 0x182a4(%rip),%rax        # 1f12c <fwp_stack_pool_n>
    6e88:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6e8c:	83 f8 3f             	cmp    $0x3f,%eax
    6e8f:	7f 7f                	jg     6f10 <fwp_free_zombie+0xb0>
    6e91:	8d 48 01             	lea    0x1(%rax),%ecx
    6e94:	89 0d 92 82 01 00    	mov    %ecx,0x18292(%rip)        # 1f12c <fwp_stack_pool_n>
    6e9a:	48 8d 0d 9f 82 01 00 	lea    0x1829f(%rip),%rcx        # 1f140 <fwp_stack_pool>
    6ea1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6ea5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6eac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6eb0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6eb7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6ebb:	48 85 c9             	test   %rcx,%rcx
    6ebe:	0f 84 fc 00 00 00    	je     6fc0 <fwp_free_zombie+0x160>
    6ec4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6ecb:	48 85 c0             	test   %rax,%rax
    6ece:	74 07                	je     6ed7 <fwp_free_zombie+0x77>
    6ed0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6ed7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6eda:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ede:	48 c7 05 67 88 01 00 	movq   $0x0,0x18867(%rip)        # 1f750 <fwp_zombie>
    6ee5:	00 00 00 00 
    6ee9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6ef0:	85 c0                	test   %eax,%eax
    6ef2:	74 34                	je     6f28 <fwp_free_zombie+0xc8>
    6ef4:	83 f8 01             	cmp    $0x1,%eax
    6ef7:	0f 84 b3 00 00 00    	je     6fb0 <fwp_free_zombie+0x150>
    6efd:	48 83 c4 18          	add    $0x18,%rsp
    6f01:	c3                   	ret
    6f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f08:	c3                   	ret
    6f09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f10:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6f14:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f19:	e8 c2 c6 ff ff       	call   35e0 <munmap@plt>
    6f1e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f23:	eb 80                	jmp    6ea5 <fwp_free_zombie+0x45>
    6f25:	0f 1f 00             	nopl   (%rax)
    6f28:	48 8b 0d 29 9c 01 00 	mov    0x19c29(%rip),%rcx        # 20b58 <fwp_heap+0x13d8>
    6f2f:	48 89 d0             	mov    %rdx,%rax
    6f32:	48 2b 05 f7 9b 01 00 	sub    0x19bf7(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    6f39:	48 c1 e1 10          	shl    $0x10,%rcx
    6f3d:	48 39 c8             	cmp    %rcx,%rax
    6f40:	73 bb                	jae    6efd <fwp_free_zombie+0x9d>
    6f42:	48 89 c1             	mov    %rax,%rcx
    6f45:	48 c1 e9 10          	shr    $0x10,%rcx
    6f49:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6f4d:	48 8b 0d 24 9c 01 00 	mov    0x19c24(%rip),%rcx        # 20b78 <fwp_heap+0x13f8>
    6f54:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6f58:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f5c:	48 85 c9             	test   %rcx,%rcx
    6f5f:	74 9c                	je     6efd <fwp_free_zombie+0x9d>
    6f61:	0f b6 3e             	movzbl (%rsi),%edi
    6f64:	40 80 ff 02          	cmp    $0x2,%dil
    6f68:	74 66                	je     6fd0 <fwp_free_zombie+0x170>
    6f6a:	40 80 ff 01          	cmp    $0x1,%dil
    6f6e:	75 8d                	jne    6efd <fwp_free_zombie+0x9d>
    6f70:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f73:	0f b7 c0             	movzwl %ax,%eax
    6f76:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f79:	48 0f af c7          	imul   %rdi,%rax
    6f7d:	48 c1 e8 20          	shr    $0x20,%rax
    6f81:	48 39 f0             	cmp    %rsi,%rax
    6f84:	0f 83 73 ff ff ff    	jae    6efd <fwp_free_zombie+0x9d>
    6f8a:	48 01 c1             	add    %rax,%rcx
    6f8d:	0f b6 01             	movzbl (%rcx),%eax
    6f90:	84 c0                	test   %al,%al
    6f92:	0f 84 65 ff ff ff    	je     6efd <fwp_free_zombie+0x9d>
    6f98:	3c 01                	cmp    $0x1,%al
    6f9a:	74 14                	je     6fb0 <fwp_free_zombie+0x150>
    6f9c:	3c ff                	cmp    $0xff,%al
    6f9e:	74 3b                	je     6fdb <fwp_free_zombie+0x17b>
    6fa0:	83 e8 01             	sub    $0x1,%eax
    6fa3:	88 01                	mov    %al,(%rcx)
    6fa5:	e9 53 ff ff ff       	jmp    6efd <fwp_free_zombie+0x9d>
    6faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fb0:	48 89 d7             	mov    %rdx,%rdi
    6fb3:	48 83 c4 18          	add    $0x18,%rsp
    6fb7:	e9 c4 fd ff ff       	jmp    6d80 <fwp_task_dispose>
    6fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    6fc0:	48 89 05 61 87 01 00 	mov    %rax,0x18761(%rip)        # 1f728 <fwp_tasks_active>
    6fc7:	e9 ff fe ff ff       	jmp    6ecb <fwp_free_zombie+0x6b>
    6fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    6fd0:	66 85 c0             	test   %ax,%ax
    6fd3:	0f 85 24 ff ff ff    	jne    6efd <fwp_free_zombie+0x9d>
    6fd9:	eb b2                	jmp    6f8d <fwp_free_zombie+0x12d>
    6fdb:	48 89 ca             	mov    %rcx,%rdx
    6fde:	48 8d 35 9b 87 01 00 	lea    0x1879b(%rip),%rsi        # 1f780 <fwp_heap>
    6fe5:	48 c1 ea 11          	shr    $0x11,%rdx
    6fe9:	48 31 ca             	xor    %rcx,%rdx
    6fec:	48 89 d0             	mov    %rdx,%rax
    6fef:	48 c1 e8 09          	shr    $0x9,%rax
    6ff3:	48 31 c2             	xor    %rax,%rdx
    6ff6:	0f b6 d2             	movzbl %dl,%edx
    6ff9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7000:	00 
    7001:	48 85 c0             	test   %rax,%rax
    7004:	75 23                	jne    7029 <fwp_free_zombie+0x1c9>
    7006:	eb 5c                	jmp    7064 <fwp_free_zombie+0x204>
    7008:	66 90                	xchg   %ax,%ax
    700a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7011:	00 00 00 00 
    7015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    701c:	00 00 00 00 
    7020:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7024:	48 85 c0             	test   %rax,%rax
    7027:	74 3b                	je     7064 <fwp_free_zombie+0x204>
    7029:	48 89 c2             	mov    %rax,%rdx
    702c:	48 39 08             	cmp    %rcx,(%rax)
    702f:	75 ef                	jne    7020 <fwp_free_zombie+0x1c0>
    7031:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7035:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7039:	48 89 50 08          	mov    %rdx,0x8(%rax)
    703d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7044:	0f 85 b3 fe ff ff    	jne    6efd <fwp_free_zombie+0x9d>
    704a:	48 89 cf             	mov    %rcx,%rdi
    704d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7052:	e8 19 e3 ff ff       	call   5370 <fwp_rc_forget_slot>
    7057:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    705c:	c6 01 fe             	movb   $0xfe,(%rcx)
    705f:	e9 99 fe ff ff       	jmp    6efd <fwp_free_zombie+0x9d>
    7064:	48 8d 3d 0d 47 00 00 	lea    0x470d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    706b:	e8 30 d1 ff ff       	call   41a0 <fwp_trap>

0000000000007070 <fwp_block>:
    7070:	48 83 ec 08          	sub    $0x8,%rsp
    7074:	48 8b 05 cd 86 01 00 	mov    0x186cd(%rip),%rax        # 1f748 <fwp_ready_head>
    707b:	48 85 c0             	test   %rax,%rax
    707e:	0f 84 1c 01 00 00    	je     71a0 <fwp_block+0x130>
    7084:	90                   	nop
    7085:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    708c:	00 00 00 00 
    7090:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7097:	48 89 15 aa 86 01 00 	mov    %rdx,0x186aa(%rip)        # 1f748 <fwp_ready_head>
    709e:	48 85 d2             	test   %rdx,%rdx
    70a1:	0f 84 19 01 00 00    	je     71c0 <fwp_block+0x150>
    70a7:	48 8b 15 b2 86 01 00 	mov    0x186b2(%rip),%rdx        # 1f760 <fwp_cur>
    70ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    70b2:	48 39 c2             	cmp    %rax,%rdx
    70b5:	0f 84 d5 00 00 00    	je     7190 <fwp_block+0x120>
    70bb:	48 8b 0d 26 a3 01 00 	mov    0x1a326(%rip),%rcx        # 213e8 <fwp_state_owners>
    70c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    70c6:	48 89 05 93 86 01 00 	mov    %rax,0x18693(%rip)        # 1f760 <fwp_cur>
    70cd:	f3 0f 7e 05 3b a3 01 	movq   0x1a33b(%rip),%xmm0        # 21410 <fwp_foreign_callbacks>
    70d4:	00 
    70d5:	0f 16 05 24 a3 01 00 	movhps 0x1a324(%rip),%xmm0        # 21400 <fwp_state>
    70dc:	f3 0f 7e 0d 24 a3 01 	movq   0x1a324(%rip),%xmm1        # 21408 <fwp_handlers>
    70e3:	00 
    70e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    70eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    70f2:	0f 16 0d 1f a3 01 00 	movhps 0x1a31f(%rip),%xmm1        # 21418 <fwp_cleanups>
    70f9:	f3 0f 7e 05 f7 a2 01 	movq   0x1a2f7(%rip),%xmm0        # 213f8 <fwp_state_len>
    7100:	00 
    7101:	0f 16 05 e8 a2 01 00 	movhps 0x1a2e8(%rip),%xmm0        # 213f0 <fwp_state_cap>
    7108:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    710f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7116:	48 8b 70 08          	mov    0x8(%rax),%rsi
    711a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7121:	48 89 0d e0 a2 01 00 	mov    %rcx,0x1a2e0(%rip)        # 21408 <fwp_handlers>
    7128:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    712f:	48 89 0d e2 a2 01 00 	mov    %rcx,0x1a2e2(%rip)        # 21418 <fwp_cleanups>
    7136:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    713d:	48 89 0d cc a2 01 00 	mov    %rcx,0x1a2cc(%rip)        # 21410 <fwp_foreign_callbacks>
    7144:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    714b:	48 89 0d ae a2 01 00 	mov    %rcx,0x1a2ae(%rip)        # 21400 <fwp_state>
    7152:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7159:	48 89 0d 98 a2 01 00 	mov    %rcx,0x1a298(%rip)        # 213f8 <fwp_state_len>
    7160:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7167:	48 89 0d 82 a2 01 00 	mov    %rcx,0x1a282(%rip)        # 213f0 <fwp_state_cap>
    716e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7175:	48 89 0d 6c a2 01 00 	mov    %rcx,0x1a26c(%rip)        # 213e8 <fwp_state_owners>
    717c:	e8 0f c3 ff ff       	call   3490 <swapcontext@plt>
    7181:	f3 0f 1e fa          	endbr64
    7185:	e8 d6 fc ff ff       	call   6e60 <fwp_free_zombie>
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	8b 05 92 7f 01 00    	mov    0x17f92(%rip),%eax        # 1f128 <fwp_slice>
    7196:	85 c0                	test   %eax,%eax
    7198:	74 36                	je     71d0 <fwp_block+0x160>
    719a:	48 83 c4 08          	add    $0x8,%rsp
    719e:	c3                   	ret
    719f:	90                   	nop
    71a0:	e8 1b de ff ff       	call   4fc0 <fwp_poll_events>
    71a5:	48 8b 05 9c 85 01 00 	mov    0x1859c(%rip),%rax        # 1f748 <fwp_ready_head>
    71ac:	48 85 c0             	test   %rax,%rax
    71af:	0f 85 db fe ff ff    	jne    7090 <fwp_block+0x20>
    71b5:	eb e9                	jmp    71a0 <fwp_block+0x130>
    71b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71be:	00 00 
    71c0:	48 c7 05 75 85 01 00 	movq   $0x0,0x18575(%rip)        # 1f740 <fwp_ready_tail>
    71c7:	00 00 00 00 
    71cb:	e9 d7 fe ff ff       	jmp    70a7 <fwp_block+0x37>
    71d0:	48 8d 3d 4a 3f 00 00 	lea    0x3f4a(%rip),%rdi        # b121 <_IO_stdin_used+0x121>
    71d7:	e8 c4 c1 ff ff       	call   33a0 <getenv@plt>
    71dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    71e1:	48 85 c0             	test   %rax,%rax
    71e4:	74 05                	je     71eb <fwp_block+0x17b>
    71e6:	80 38 00             	cmpb   $0x0,(%rax)
    71e9:	75 0b                	jne    71f6 <fwp_block+0x186>
    71eb:	89 15 37 7f 01 00    	mov    %edx,0x17f37(%rip)        # 1f128 <fwp_slice>
    71f1:	48 83 c4 08          	add    $0x8,%rsp
    71f5:	c3                   	ret
    71f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    71fb:	31 f6                	xor    %esi,%esi
    71fd:	48 89 c7             	mov    %rax,%rdi
    7200:	e8 4b c3 ff ff       	call   3550 <strtoll@plt>
    7205:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7209:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7210:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7215:	0f 46 d0             	cmovbe %eax,%edx
    7218:	eb d1                	jmp    71eb <fwp_block+0x17b>
    721a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007220 <fwp_caps173>:
    7220:	f3 0f 1e fa          	endbr64
    7224:	85 f6                	test   %esi,%esi
    7226:	74 08                	je     7230 <fwp_caps173+0x10>
    7228:	c3                   	ret
    7229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7230:	48 8b 15 21 99 01 00 	mov    0x19921(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    7237:	48 89 f8             	mov    %rdi,%rax
    723a:	48 2b 05 ef 98 01 00 	sub    0x198ef(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    7241:	48 c1 e2 10          	shl    $0x10,%rdx
    7245:	48 39 d0             	cmp    %rdx,%rax
    7248:	73 de                	jae    7228 <fwp_caps173+0x8>
    724a:	48 89 c2             	mov    %rax,%rdx
    724d:	48 c1 ea 10          	shr    $0x10,%rdx
    7251:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7255:	48 8b 15 1c 99 01 00 	mov    0x1991c(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    725c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7260:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7264:	48 85 c9             	test   %rcx,%rcx
    7267:	74 bf                	je     7228 <fwp_caps173+0x8>
    7269:	0f b6 32             	movzbl (%rdx),%esi
    726c:	40 80 fe 02          	cmp    $0x2,%sil
    7270:	74 2e                	je     72a0 <fwp_caps173+0x80>
    7272:	40 80 fe 01          	cmp    $0x1,%sil
    7276:	75 b0                	jne    7228 <fwp_caps173+0x8>
    7278:	8b 72 18             	mov    0x18(%rdx),%esi
    727b:	0f b7 c0             	movzwl %ax,%eax
    727e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7281:	48 0f af c6          	imul   %rsi,%rax
    7285:	48 c1 e8 20          	shr    $0x20,%rax
    7289:	48 39 d0             	cmp    %rdx,%rax
    728c:	73 9a                	jae    7228 <fwp_caps173+0x8>
    728e:	48 01 c1             	add    %rax,%rcx
    7291:	80 39 01             	cmpb   $0x1,(%rcx)
    7294:	75 92                	jne    7228 <fwp_caps173+0x8>
    7296:	e9 15 e3 ff ff       	jmp    55b0 <fwp_mem_free>
    729b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72a0:	66 85 c0             	test   %ax,%ax
    72a3:	74 ec                	je     7291 <fwp_caps173+0x71>
    72a5:	c3                   	ret
    72a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72ad:	00 00 00 

00000000000072b0 <fwp_args37>:
    72b0:	f3 0f 1e fa          	endbr64
    72b4:	85 d2                	test   %edx,%edx
    72b6:	74 04                	je     72bc <fwp_args37+0xc>
    72b8:	85 f6                	test   %esi,%esi
    72ba:	74 04                	je     72c0 <fwp_args37+0x10>
    72bc:	c3                   	ret
    72bd:	0f 1f 00             	nopl   (%rax)
    72c0:	48 8b 15 91 98 01 00 	mov    0x19891(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    72c7:	48 8b 07             	mov    (%rdi),%rax
    72ca:	48 2b 05 5f 98 01 00 	sub    0x1985f(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    72d1:	48 c1 e2 10          	shl    $0x10,%rdx
    72d5:	48 39 d0             	cmp    %rdx,%rax
    72d8:	73 e2                	jae    72bc <fwp_args37+0xc>
    72da:	48 89 c2             	mov    %rax,%rdx
    72dd:	48 c1 ea 10          	shr    $0x10,%rdx
    72e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72e5:	48 8b 15 8c 98 01 00 	mov    0x1988c(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    72ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    72f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    72f4:	48 85 ff             	test   %rdi,%rdi
    72f7:	74 c3                	je     72bc <fwp_args37+0xc>
    72f9:	0f b6 0a             	movzbl (%rdx),%ecx
    72fc:	80 f9 02             	cmp    $0x2,%cl
    72ff:	74 2f                	je     7330 <fwp_args37+0x80>
    7301:	80 f9 01             	cmp    $0x1,%cl
    7304:	75 b6                	jne    72bc <fwp_args37+0xc>
    7306:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7309:	0f b7 c0             	movzwl %ax,%eax
    730c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    730f:	48 0f af c1          	imul   %rcx,%rax
    7313:	48 c1 e8 20          	shr    $0x20,%rax
    7317:	48 39 d0             	cmp    %rdx,%rax
    731a:	73 a0                	jae    72bc <fwp_args37+0xc>
    731c:	48 01 c7             	add    %rax,%rdi
    731f:	0f b6 07             	movzbl (%rdi),%eax
    7322:	84 c0                	test   %al,%al
    7324:	74 96                	je     72bc <fwp_args37+0xc>
    7326:	3c fd                	cmp    $0xfd,%al
    7328:	77 0c                	ja     7336 <fwp_args37+0x86>
    732a:	83 c0 01             	add    $0x1,%eax
    732d:	88 07                	mov    %al,(%rdi)
    732f:	c3                   	ret
    7330:	66 85 c0             	test   %ax,%ax
    7333:	74 ea                	je     731f <fwp_args37+0x6f>
    7335:	c3                   	ret
    7336:	e9 15 df ff ff       	jmp    5250 <fwp_rc_wide_dup>
    733b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007340 <fwp_caps37>:
    7340:	f3 0f 1e fa          	endbr64
    7344:	48 83 ec 18          	sub    $0x18,%rsp
    7348:	8b 57 04             	mov    0x4(%rdi),%edx
    734b:	48 89 f8             	mov    %rdi,%rax
    734e:	85 d2                	test   %edx,%edx
    7350:	0f 84 9a 00 00 00    	je     73f0 <fwp_caps37+0xb0>
    7356:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    735a:	85 f6                	test   %esi,%esi
    735c:	0f 85 9e 00 00 00    	jne    7400 <fwp_caps37+0xc0>
    7362:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7367:	e8 44 f7 ff ff       	call   6ab0 <fwp_drop4>
    736c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7371:	48 8b 0d e0 97 01 00 	mov    0x197e0(%rip),%rcx        # 20b58 <fwp_heap+0x13d8>
    7378:	48 89 c2             	mov    %rax,%rdx
    737b:	48 2b 15 ae 97 01 00 	sub    0x197ae(%rip),%rdx        # 20b30 <fwp_heap+0x13b0>
    7382:	48 c1 e1 10          	shl    $0x10,%rcx
    7386:	48 39 ca             	cmp    %rcx,%rdx
    7389:	73 6d                	jae    73f8 <fwp_caps37+0xb8>
    738b:	48 89 d1             	mov    %rdx,%rcx
    738e:	48 c1 e9 10          	shr    $0x10,%rcx
    7392:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7396:	48 8b 0d db 97 01 00 	mov    0x197db(%rip),%rcx        # 20b78 <fwp_heap+0x13f8>
    739d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    73a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    73a5:	48 85 f6             	test   %rsi,%rsi
    73a8:	74 4e                	je     73f8 <fwp_caps37+0xb8>
    73aa:	0f b6 39             	movzbl (%rcx),%edi
    73ad:	40 80 ff 02          	cmp    $0x2,%dil
    73b1:	0f 84 b9 00 00 00    	je     7470 <fwp_caps37+0x130>
    73b7:	40 80 ff 01          	cmp    $0x1,%dil
    73bb:	75 3b                	jne    73f8 <fwp_caps37+0xb8>
    73bd:	8b 79 18             	mov    0x18(%rcx),%edi
    73c0:	0f b7 d2             	movzwl %dx,%edx
    73c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    73c6:	48 0f af d7          	imul   %rdi,%rdx
    73ca:	48 c1 ea 20          	shr    $0x20,%rdx
    73ce:	48 39 ca             	cmp    %rcx,%rdx
    73d1:	73 25                	jae    73f8 <fwp_caps37+0xb8>
    73d3:	48 01 d6             	add    %rdx,%rsi
    73d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    73d9:	75 1d                	jne    73f8 <fwp_caps37+0xb8>
    73db:	48 89 c7             	mov    %rax,%rdi
    73de:	48 83 c4 18          	add    $0x18,%rsp
    73e2:	e9 c9 e1 ff ff       	jmp    55b0 <fwp_mem_free>
    73e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73ee:	00 00 
    73f0:	85 f6                	test   %esi,%esi
    73f2:	0f 84 79 ff ff ff    	je     7371 <fwp_caps37+0x31>
    73f8:	48 83 c4 18          	add    $0x18,%rsp
    73fc:	c3                   	ret
    73fd:	0f 1f 00             	nopl   (%rax)
    7400:	48 8b 05 51 97 01 00 	mov    0x19751(%rip),%rax        # 20b58 <fwp_heap+0x13d8>
    7407:	48 2b 3d 22 97 01 00 	sub    0x19722(%rip),%rdi        # 20b30 <fwp_heap+0x13b0>
    740e:	48 c1 e0 10          	shl    $0x10,%rax
    7412:	48 39 c7             	cmp    %rax,%rdi
    7415:	73 e1                	jae    73f8 <fwp_caps37+0xb8>
    7417:	48 89 f8             	mov    %rdi,%rax
    741a:	48 c1 e8 10          	shr    $0x10,%rax
    741e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7422:	48 8b 05 4f 97 01 00 	mov    0x1974f(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    7429:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    742d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7431:	48 85 c0             	test   %rax,%rax
    7434:	74 c2                	je     73f8 <fwp_caps37+0xb8>
    7436:	0f b6 0a             	movzbl (%rdx),%ecx
    7439:	80 f9 02             	cmp    $0x2,%cl
    743c:	74 42                	je     7480 <fwp_caps37+0x140>
    743e:	80 f9 01             	cmp    $0x1,%cl
    7441:	75 b5                	jne    73f8 <fwp_caps37+0xb8>
    7443:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7446:	0f b7 ff             	movzwl %di,%edi
    7449:	8b 52 1c             	mov    0x1c(%rdx),%edx
    744c:	48 0f af f9          	imul   %rcx,%rdi
    7450:	48 c1 ef 20          	shr    $0x20,%rdi
    7454:	48 39 d7             	cmp    %rdx,%rdi
    7457:	73 9f                	jae    73f8 <fwp_caps37+0xb8>
    7459:	48 01 f8             	add    %rdi,%rax
    745c:	0f b6 10             	movzbl (%rax),%edx
    745f:	84 d2                	test   %dl,%dl
    7461:	74 95                	je     73f8 <fwp_caps37+0xb8>
    7463:	80 fa fd             	cmp    $0xfd,%dl
    7466:	77 23                	ja     748b <fwp_caps37+0x14b>
    7468:	83 c2 01             	add    $0x1,%edx
    746b:	88 10                	mov    %dl,(%rax)
    746d:	eb 89                	jmp    73f8 <fwp_caps37+0xb8>
    746f:	90                   	nop
    7470:	66 85 d2             	test   %dx,%dx
    7473:	0f 85 7f ff ff ff    	jne    73f8 <fwp_caps37+0xb8>
    7479:	e9 58 ff ff ff       	jmp    73d6 <fwp_caps37+0x96>
    747e:	66 90                	xchg   %ax,%ax
    7480:	66 85 ff             	test   %di,%di
    7483:	0f 85 6f ff ff ff    	jne    73f8 <fwp_caps37+0xb8>
    7489:	eb d1                	jmp    745c <fwp_caps37+0x11c>
    748b:	48 89 c7             	mov    %rax,%rdi
    748e:	48 83 c4 18          	add    $0x18,%rsp
    7492:	e9 b9 dd ff ff       	jmp    5250 <fwp_rc_wide_dup>
    7497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    749e:	00 00 

00000000000074a0 <fwp_drop0>:
    74a0:	f3 0f 1e fa          	endbr64
    74a4:	48 8b 15 ad 96 01 00 	mov    0x196ad(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    74ab:	48 89 f8             	mov    %rdi,%rax
    74ae:	48 2b 05 7b 96 01 00 	sub    0x1967b(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    74b5:	48 c1 e2 10          	shl    $0x10,%rdx
    74b9:	48 39 d0             	cmp    %rdx,%rax
    74bc:	0f 83 36 01 00 00    	jae    75f8 <fwp_drop0+0x158>
    74c2:	48 83 ec 18          	sub    $0x18,%rsp
    74c6:	48 8d 35 b3 82 01 00 	lea    0x182b3(%rip),%rsi        # 1f780 <fwp_heap>
    74cd:	48 89 c2             	mov    %rax,%rdx
    74d0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    74d7:	48 c1 ea 10          	shr    $0x10,%rdx
    74db:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    74df:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    74e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    74e7:	48 85 d2             	test   %rdx,%rdx
    74ea:	74 42                	je     752e <fwp_drop0+0x8e>
    74ec:	44 0f b6 01          	movzbl (%rcx),%r8d
    74f0:	41 80 f8 02          	cmp    $0x2,%r8b
    74f4:	74 42                	je     7538 <fwp_drop0+0x98>
    74f6:	41 80 f8 01          	cmp    $0x1,%r8b
    74fa:	75 32                	jne    752e <fwp_drop0+0x8e>
    74fc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7500:	0f b7 c0             	movzwl %ax,%eax
    7503:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7506:	49 0f af c0          	imul   %r8,%rax
    750a:	48 c1 e8 20          	shr    $0x20,%rax
    750e:	48 39 c8             	cmp    %rcx,%rax
    7511:	73 1b                	jae    752e <fwp_drop0+0x8e>
    7513:	48 01 c2             	add    %rax,%rdx
    7516:	0f b6 02             	movzbl (%rdx),%eax
    7519:	84 c0                	test   %al,%al
    751b:	74 11                	je     752e <fwp_drop0+0x8e>
    751d:	3c 01                	cmp    $0x1,%al
    751f:	74 27                	je     7548 <fwp_drop0+0xa8>
    7521:	3c ff                	cmp    $0xff,%al
    7523:	0f 84 e7 00 00 00    	je     7610 <fwp_drop0+0x170>
    7529:	83 e8 01             	sub    $0x1,%eax
    752c:	88 02                	mov    %al,(%rdx)
    752e:	48 83 c4 18          	add    $0x18,%rsp
    7532:	c3                   	ret
    7533:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7538:	66 85 c0             	test   %ax,%ax
    753b:	74 d9                	je     7516 <fwp_drop0+0x76>
    753d:	48 83 c4 18          	add    $0x18,%rsp
    7541:	c3                   	ret
    7542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7548:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    754f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7556:	48 89 f8             	mov    %rdi,%rax
    7559:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    755d:	48 29 c8             	sub    %rcx,%rax
    7560:	48 c1 e2 10          	shl    $0x10,%rdx
    7564:	48 39 d0             	cmp    %rdx,%rax
    7567:	73 71                	jae    75da <fwp_drop0+0x13a>
    7569:	49 89 c2             	mov    %rax,%r10
    756c:	49 c1 ea 10          	shr    $0x10,%r10
    7570:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7574:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7578:	4d 8b 51 20          	mov    0x20(%r9),%r10
    757c:	4d 85 d2             	test   %r10,%r10
    757f:	74 59                	je     75da <fwp_drop0+0x13a>
    7581:	45 0f b6 19          	movzbl (%r9),%r11d
    7585:	41 80 fb 02          	cmp    $0x2,%r11b
    7589:	74 75                	je     7600 <fwp_drop0+0x160>
    758b:	41 80 fb 01          	cmp    $0x1,%r11b
    758f:	75 49                	jne    75da <fwp_drop0+0x13a>
    7591:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7595:	0f b7 c0             	movzwl %ax,%eax
    7598:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    759c:	49 0f af c3          	imul   %r11,%rax
    75a0:	48 c1 e8 20          	shr    $0x20,%rax
    75a4:	4c 39 c8             	cmp    %r9,%rax
    75a7:	73 31                	jae    75da <fwp_drop0+0x13a>
    75a9:	49 01 c2             	add    %rax,%r10
    75ac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    75b0:	75 28                	jne    75da <fwp_drop0+0x13a>
    75b2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    75b7:	e8 f4 df ff ff       	call   55b0 <fwp_mem_free>
    75bc:	48 8d 35 bd 81 01 00 	lea    0x181bd(%rip),%rsi        # 1f780 <fwp_heap>
    75c3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    75c8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    75cf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    75d6:	48 c1 e2 10          	shl    $0x10,%rdx
    75da:	4c 89 c0             	mov    %r8,%rax
    75dd:	48 29 c8             	sub    %rcx,%rax
    75e0:	48 39 d0             	cmp    %rdx,%rax
    75e3:	0f 83 45 ff ff ff    	jae    752e <fwp_drop0+0x8e>
    75e9:	4c 89 c7             	mov    %r8,%rdi
    75ec:	e9 dc fe ff ff       	jmp    74cd <fwp_drop0+0x2d>
    75f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75f8:	c3                   	ret
    75f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7600:	66 85 c0             	test   %ax,%ax
    7603:	75 d5                	jne    75da <fwp_drop0+0x13a>
    7605:	eb a5                	jmp    75ac <fwp_drop0+0x10c>
    7607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    760e:	00 00 
    7610:	48 89 d0             	mov    %rdx,%rax
    7613:	48 c1 e8 11          	shr    $0x11,%rax
    7617:	48 31 d0             	xor    %rdx,%rax
    761a:	48 89 c1             	mov    %rax,%rcx
    761d:	48 c1 e9 09          	shr    $0x9,%rcx
    7621:	48 31 c8             	xor    %rcx,%rax
    7624:	0f b6 c8             	movzbl %al,%ecx
    7627:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    762e:	00 
    762f:	48 85 c0             	test   %rax,%rax
    7632:	75 15                	jne    7649 <fwp_drop0+0x1a9>
    7634:	eb 4e                	jmp    7684 <fwp_drop0+0x1e4>
    7636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    763d:	00 00 00 
    7640:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7644:	48 85 c0             	test   %rax,%rax
    7647:	74 3b                	je     7684 <fwp_drop0+0x1e4>
    7649:	48 89 c1             	mov    %rax,%rcx
    764c:	48 39 10             	cmp    %rdx,(%rax)
    764f:	75 ef                	jne    7640 <fwp_drop0+0x1a0>
    7651:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7655:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7659:	48 89 48 08          	mov    %rcx,0x8(%rax)
    765d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7664:	0f 85 c4 fe ff ff    	jne    752e <fwp_drop0+0x8e>
    766a:	48 89 d7             	mov    %rdx,%rdi
    766d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7672:	e8 f9 dc ff ff       	call   5370 <fwp_rc_forget_slot>
    7677:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    767c:	c6 02 fe             	movb   $0xfe,(%rdx)
    767f:	e9 aa fe ff ff       	jmp    752e <fwp_drop0+0x8e>
    7684:	48 8d 3d ed 40 00 00 	lea    0x40ed(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    768b:	e8 10 cb ff ff       	call   41a0 <fwp_trap>

0000000000007690 <fwp_drop1>:
    7690:	f3 0f 1e fa          	endbr64
    7694:	48 8b 15 bd 94 01 00 	mov    0x194bd(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    769b:	48 89 f8             	mov    %rdi,%rax
    769e:	48 2b 05 8b 94 01 00 	sub    0x1948b(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    76a5:	48 c1 e2 10          	shl    $0x10,%rdx
    76a9:	48 39 d0             	cmp    %rdx,%rax
    76ac:	0f 83 36 01 00 00    	jae    77e8 <fwp_drop1+0x158>
    76b2:	48 83 ec 18          	sub    $0x18,%rsp
    76b6:	48 8d 35 c3 80 01 00 	lea    0x180c3(%rip),%rsi        # 1f780 <fwp_heap>
    76bd:	48 89 c2             	mov    %rax,%rdx
    76c0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    76c7:	48 c1 ea 10          	shr    $0x10,%rdx
    76cb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76cf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    76d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76d7:	48 85 d2             	test   %rdx,%rdx
    76da:	74 42                	je     771e <fwp_drop1+0x8e>
    76dc:	44 0f b6 01          	movzbl (%rcx),%r8d
    76e0:	41 80 f8 02          	cmp    $0x2,%r8b
    76e4:	74 42                	je     7728 <fwp_drop1+0x98>
    76e6:	41 80 f8 01          	cmp    $0x1,%r8b
    76ea:	75 32                	jne    771e <fwp_drop1+0x8e>
    76ec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    76f0:	0f b7 c0             	movzwl %ax,%eax
    76f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76f6:	49 0f af c0          	imul   %r8,%rax
    76fa:	48 c1 e8 20          	shr    $0x20,%rax
    76fe:	48 39 c8             	cmp    %rcx,%rax
    7701:	73 1b                	jae    771e <fwp_drop1+0x8e>
    7703:	48 01 c2             	add    %rax,%rdx
    7706:	0f b6 02             	movzbl (%rdx),%eax
    7709:	84 c0                	test   %al,%al
    770b:	74 11                	je     771e <fwp_drop1+0x8e>
    770d:	3c 01                	cmp    $0x1,%al
    770f:	74 27                	je     7738 <fwp_drop1+0xa8>
    7711:	3c ff                	cmp    $0xff,%al
    7713:	0f 84 e7 00 00 00    	je     7800 <fwp_drop1+0x170>
    7719:	83 e8 01             	sub    $0x1,%eax
    771c:	88 02                	mov    %al,(%rdx)
    771e:	48 83 c4 18          	add    $0x18,%rsp
    7722:	c3                   	ret
    7723:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7728:	66 85 c0             	test   %ax,%ax
    772b:	74 d9                	je     7706 <fwp_drop1+0x76>
    772d:	48 83 c4 18          	add    $0x18,%rsp
    7731:	c3                   	ret
    7732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7738:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    773f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7746:	48 89 f8             	mov    %rdi,%rax
    7749:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    774d:	48 29 c8             	sub    %rcx,%rax
    7750:	48 c1 e2 10          	shl    $0x10,%rdx
    7754:	48 39 d0             	cmp    %rdx,%rax
    7757:	73 71                	jae    77ca <fwp_drop1+0x13a>
    7759:	49 89 c2             	mov    %rax,%r10
    775c:	49 c1 ea 10          	shr    $0x10,%r10
    7760:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7764:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7768:	4d 8b 51 20          	mov    0x20(%r9),%r10
    776c:	4d 85 d2             	test   %r10,%r10
    776f:	74 59                	je     77ca <fwp_drop1+0x13a>
    7771:	45 0f b6 19          	movzbl (%r9),%r11d
    7775:	41 80 fb 02          	cmp    $0x2,%r11b
    7779:	74 75                	je     77f0 <fwp_drop1+0x160>
    777b:	41 80 fb 01          	cmp    $0x1,%r11b
    777f:	75 49                	jne    77ca <fwp_drop1+0x13a>
    7781:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7785:	0f b7 c0             	movzwl %ax,%eax
    7788:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    778c:	49 0f af c3          	imul   %r11,%rax
    7790:	48 c1 e8 20          	shr    $0x20,%rax
    7794:	4c 39 c8             	cmp    %r9,%rax
    7797:	73 31                	jae    77ca <fwp_drop1+0x13a>
    7799:	49 01 c2             	add    %rax,%r10
    779c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    77a0:	75 28                	jne    77ca <fwp_drop1+0x13a>
    77a2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    77a7:	e8 04 de ff ff       	call   55b0 <fwp_mem_free>
    77ac:	48 8d 35 cd 7f 01 00 	lea    0x17fcd(%rip),%rsi        # 1f780 <fwp_heap>
    77b3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    77b8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    77bf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77c6:	48 c1 e2 10          	shl    $0x10,%rdx
    77ca:	4c 89 c0             	mov    %r8,%rax
    77cd:	48 29 c8             	sub    %rcx,%rax
    77d0:	48 39 d0             	cmp    %rdx,%rax
    77d3:	0f 83 45 ff ff ff    	jae    771e <fwp_drop1+0x8e>
    77d9:	4c 89 c7             	mov    %r8,%rdi
    77dc:	e9 dc fe ff ff       	jmp    76bd <fwp_drop1+0x2d>
    77e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77e8:	c3                   	ret
    77e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77f0:	66 85 c0             	test   %ax,%ax
    77f3:	75 d5                	jne    77ca <fwp_drop1+0x13a>
    77f5:	eb a5                	jmp    779c <fwp_drop1+0x10c>
    77f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77fe:	00 00 
    7800:	48 89 d0             	mov    %rdx,%rax
    7803:	48 c1 e8 11          	shr    $0x11,%rax
    7807:	48 31 d0             	xor    %rdx,%rax
    780a:	48 89 c1             	mov    %rax,%rcx
    780d:	48 c1 e9 09          	shr    $0x9,%rcx
    7811:	48 31 c8             	xor    %rcx,%rax
    7814:	0f b6 c8             	movzbl %al,%ecx
    7817:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    781e:	00 
    781f:	48 85 c0             	test   %rax,%rax
    7822:	75 25                	jne    7849 <fwp_drop1+0x1b9>
    7824:	eb 5e                	jmp    7884 <fwp_drop1+0x1f4>
    7826:	0f 1f 40 00          	nopl   0x0(%rax)
    782a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7831:	00 00 00 00 
    7835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    783c:	00 00 00 00 
    7840:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7844:	48 85 c0             	test   %rax,%rax
    7847:	74 3b                	je     7884 <fwp_drop1+0x1f4>
    7849:	48 89 c1             	mov    %rax,%rcx
    784c:	48 39 10             	cmp    %rdx,(%rax)
    784f:	75 ef                	jne    7840 <fwp_drop1+0x1b0>
    7851:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7855:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7859:	48 89 48 08          	mov    %rcx,0x8(%rax)
    785d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7864:	0f 85 b4 fe ff ff    	jne    771e <fwp_drop1+0x8e>
    786a:	48 89 d7             	mov    %rdx,%rdi
    786d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7872:	e8 f9 da ff ff       	call   5370 <fwp_rc_forget_slot>
    7877:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    787c:	c6 02 fe             	movb   $0xfe,(%rdx)
    787f:	e9 9a fe ff ff       	jmp    771e <fwp_drop1+0x8e>
    7884:	48 8d 3d ed 3e 00 00 	lea    0x3eed(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    788b:	e8 10 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007890 <fwp_drop10>:
    7890:	48 8b 0d c1 92 01 00 	mov    0x192c1(%rip),%rcx        # 20b58 <fwp_heap+0x13d8>
    7897:	48 89 f8             	mov    %rdi,%rax
    789a:	48 2b 05 8f 92 01 00 	sub    0x1928f(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    78a1:	48 c1 e1 10          	shl    $0x10,%rcx
    78a5:	48 39 c8             	cmp    %rcx,%rax
    78a8:	0f 83 c2 01 00 00    	jae    7a70 <fwp_drop10+0x1e0>
    78ae:	48 83 ec 18          	sub    $0x18,%rsp
    78b2:	48 89 fa             	mov    %rdi,%rdx
    78b5:	48 8d 35 c4 7e 01 00 	lea    0x17ec4(%rip),%rsi        # 1f780 <fwp_heap>
    78bc:	48 89 c1             	mov    %rax,%rcx
    78bf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    78c6:	48 c1 e9 10          	shr    $0x10,%rcx
    78ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    78ce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    78d2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    78d6:	48 85 c9             	test   %rcx,%rcx
    78d9:	74 46                	je     7921 <fwp_drop10+0x91>
    78db:	44 0f b6 0f          	movzbl (%rdi),%r9d
    78df:	41 80 f9 02          	cmp    $0x2,%r9b
    78e3:	0f 84 d7 00 00 00    	je     79c0 <fwp_drop10+0x130>
    78e9:	41 80 f9 01          	cmp    $0x1,%r9b
    78ed:	75 32                	jne    7921 <fwp_drop10+0x91>
    78ef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    78f3:	0f b7 c0             	movzwl %ax,%eax
    78f6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    78f9:	49 0f af c1          	imul   %r9,%rax
    78fd:	48 c1 e8 20          	shr    $0x20,%rax
    7901:	48 39 f8             	cmp    %rdi,%rax
    7904:	73 1b                	jae    7921 <fwp_drop10+0x91>
    7906:	48 01 c1             	add    %rax,%rcx
    7909:	0f b6 01             	movzbl (%rcx),%eax
    790c:	84 c0                	test   %al,%al
    790e:	74 11                	je     7921 <fwp_drop10+0x91>
    7910:	3c 01                	cmp    $0x1,%al
    7912:	74 1c                	je     7930 <fwp_drop10+0xa0>
    7914:	3c ff                	cmp    $0xff,%al
    7916:	0f 84 5c 01 00 00    	je     7a78 <fwp_drop10+0x1e8>
    791c:	83 e8 01             	sub    $0x1,%eax
    791f:	88 01                	mov    %al,(%rcx)
    7921:	48 83 c4 18          	add    $0x18,%rsp
    7925:	c3                   	ret
    7926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    792d:	00 00 00 
    7930:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7937:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    793e:	48 89 d0             	mov    %rdx,%rax
    7941:	49 89 d1             	mov    %rdx,%r9
    7944:	48 c1 e1 10          	shl    $0x10,%rcx
    7948:	48 29 f8             	sub    %rdi,%rax
    794b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    794f:	78 7f                	js     79d0 <fwp_drop10+0x140>
    7951:	48 39 c8             	cmp    %rcx,%rax
    7954:	73 cb                	jae    7921 <fwp_drop10+0x91>
    7956:	48 89 c1             	mov    %rax,%rcx
    7959:	48 c1 e9 10          	shr    $0x10,%rcx
    795d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7961:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7965:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7969:	48 85 f6             	test   %rsi,%rsi
    796c:	74 b3                	je     7921 <fwp_drop10+0x91>
    796e:	0f b6 39             	movzbl (%rcx),%edi
    7971:	40 80 ff 02          	cmp    $0x2,%dil
    7975:	74 39                	je     79b0 <fwp_drop10+0x120>
    7977:	40 80 ff 01          	cmp    $0x1,%dil
    797b:	75 a4                	jne    7921 <fwp_drop10+0x91>
    797d:	8b 79 18             	mov    0x18(%rcx),%edi
    7980:	0f b7 c0             	movzwl %ax,%eax
    7983:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7986:	48 0f af c7          	imul   %rdi,%rax
    798a:	48 c1 e8 20          	shr    $0x20,%rax
    798e:	48 39 c8             	cmp    %rcx,%rax
    7991:	73 8e                	jae    7921 <fwp_drop10+0x91>
    7993:	48 01 c6             	add    %rax,%rsi
    7996:	80 3e 01             	cmpb   $0x1,(%rsi)
    7999:	75 86                	jne    7921 <fwp_drop10+0x91>
    799b:	48 89 d7             	mov    %rdx,%rdi
    799e:	48 83 c4 18          	add    $0x18,%rsp
    79a2:	e9 09 dc ff ff       	jmp    55b0 <fwp_mem_free>
    79a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79ae:	00 00 
    79b0:	66 85 c0             	test   %ax,%ax
    79b3:	74 e1                	je     7996 <fwp_drop10+0x106>
    79b5:	48 83 c4 18          	add    $0x18,%rsp
    79b9:	c3                   	ret
    79ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79c0:	66 85 c0             	test   %ax,%ax
    79c3:	0f 84 40 ff ff ff    	je     7909 <fwp_drop10+0x79>
    79c9:	48 83 c4 18          	add    $0x18,%rsp
    79cd:	c3                   	ret
    79ce:	66 90                	xchg   %ax,%ax
    79d0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    79d4:	48 39 c8             	cmp    %rcx,%rax
    79d7:	73 74                	jae    7a4d <fwp_drop10+0x1bd>
    79d9:	49 89 c2             	mov    %rax,%r10
    79dc:	49 c1 ea 10          	shr    $0x10,%r10
    79e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    79e4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    79e8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    79ec:	4d 85 d2             	test   %r10,%r10
    79ef:	74 5c                	je     7a4d <fwp_drop10+0x1bd>
    79f1:	45 0f b6 18          	movzbl (%r8),%r11d
    79f5:	41 80 fb 02          	cmp    $0x2,%r11b
    79f9:	74 6d                	je     7a68 <fwp_drop10+0x1d8>
    79fb:	41 80 fb 01          	cmp    $0x1,%r11b
    79ff:	75 4c                	jne    7a4d <fwp_drop10+0x1bd>
    7a01:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7a05:	0f b7 c0             	movzwl %ax,%eax
    7a08:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7a0c:	49 0f af c3          	imul   %r11,%rax
    7a10:	48 c1 e8 20          	shr    $0x20,%rax
    7a14:	4c 39 c0             	cmp    %r8,%rax
    7a17:	73 34                	jae    7a4d <fwp_drop10+0x1bd>
    7a19:	49 01 c2             	add    %rax,%r10
    7a1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7a20:	75 2b                	jne    7a4d <fwp_drop10+0x1bd>
    7a22:	4c 89 cf             	mov    %r9,%rdi
    7a25:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a2a:	e8 81 db ff ff       	call   55b0 <fwp_mem_free>
    7a2f:	48 8d 35 4a 7d 01 00 	lea    0x17d4a(%rip),%rsi        # 1f780 <fwp_heap>
    7a36:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a3b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7a42:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7a49:	48 c1 e1 10          	shl    $0x10,%rcx
    7a4d:	48 89 d0             	mov    %rdx,%rax
    7a50:	48 29 f8             	sub    %rdi,%rax
    7a53:	48 39 c8             	cmp    %rcx,%rax
    7a56:	0f 82 60 fe ff ff    	jb     78bc <fwp_drop10+0x2c>
    7a5c:	e9 c0 fe ff ff       	jmp    7921 <fwp_drop10+0x91>
    7a61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a68:	66 85 c0             	test   %ax,%ax
    7a6b:	75 e0                	jne    7a4d <fwp_drop10+0x1bd>
    7a6d:	eb ad                	jmp    7a1c <fwp_drop10+0x18c>
    7a6f:	90                   	nop
    7a70:	c3                   	ret
    7a71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a78:	48 89 c8             	mov    %rcx,%rax
    7a7b:	48 c1 e8 11          	shr    $0x11,%rax
    7a7f:	48 31 c8             	xor    %rcx,%rax
    7a82:	48 89 c2             	mov    %rax,%rdx
    7a85:	48 c1 ea 09          	shr    $0x9,%rdx
    7a89:	48 31 d0             	xor    %rdx,%rax
    7a8c:	0f b6 d0             	movzbl %al,%edx
    7a8f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7a96:	00 
    7a97:	48 85 c0             	test   %rax,%rax
    7a9a:	75 0d                	jne    7aa9 <fwp_drop10+0x219>
    7a9c:	eb 46                	jmp    7ae4 <fwp_drop10+0x254>
    7a9e:	66 90                	xchg   %ax,%ax
    7aa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7aa4:	48 85 c0             	test   %rax,%rax
    7aa7:	74 3b                	je     7ae4 <fwp_drop10+0x254>
    7aa9:	48 89 c2             	mov    %rax,%rdx
    7aac:	48 39 08             	cmp    %rcx,(%rax)
    7aaf:	75 ef                	jne    7aa0 <fwp_drop10+0x210>
    7ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ab5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7ab9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7abd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ac4:	0f 85 57 fe ff ff    	jne    7921 <fwp_drop10+0x91>
    7aca:	48 89 cf             	mov    %rcx,%rdi
    7acd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7ad2:	e8 99 d8 ff ff       	call   5370 <fwp_rc_forget_slot>
    7ad7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7adc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7adf:	e9 3d fe ff ff       	jmp    7921 <fwp_drop10+0x91>
    7ae4:	48 8d 3d 8d 3c 00 00 	lea    0x3c8d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    7aeb:	e8 b0 c6 ff ff       	call   41a0 <fwp_trap>

0000000000007af0 <f37>:
    7af0:	41 57                	push   %r15
    7af2:	41 56                	push   %r14
    7af4:	41 55                	push   %r13
    7af6:	41 54                	push   %r12
    7af8:	55                   	push   %rbp
    7af9:	53                   	push   %rbx
    7afa:	48 83 ec 38          	sub    $0x38,%rsp
    7afe:	48 8b 15 53 90 01 00 	mov    0x19053(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    7b05:	48 8b 0d 24 90 01 00 	mov    0x19024(%rip),%rcx        # 20b30 <fwp_heap+0x13b0>
    7b0c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7b13:	00 00 
    7b15:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7b1a:	49 89 fc             	mov    %rdi,%r12
    7b1d:	48 c1 e2 10          	shl    $0x10,%rdx
    7b21:	48 85 ff             	test   %rdi,%rdi
    7b24:	0f 84 bc 02 00 00    	je     7de6 <f37+0x2f6>
    7b2a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7b2f:	48 89 d8             	mov    %rbx,%rax
    7b32:	48 29 c8             	sub    %rcx,%rax
    7b35:	48 39 d0             	cmp    %rdx,%rax
    7b38:	0f 83 72 03 00 00    	jae    7eb0 <f37+0x3c0>
    7b3e:	48 89 c2             	mov    %rax,%rdx
    7b41:	48 c1 ea 10          	shr    $0x10,%rdx
    7b45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b49:	48 8b 15 28 90 01 00 	mov    0x19028(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    7b50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b54:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b58:	48 85 ff             	test   %rdi,%rdi
    7b5b:	0f 84 4f 03 00 00    	je     7eb0 <f37+0x3c0>
    7b61:	0f b6 0a             	movzbl (%rdx),%ecx
    7b64:	80 f9 02             	cmp    $0x2,%cl
    7b67:	0f 84 53 02 00 00    	je     7dc0 <f37+0x2d0>
    7b6d:	80 f9 01             	cmp    $0x1,%cl
    7b70:	75 24                	jne    7b96 <f37+0xa6>
    7b72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b75:	0f b7 c0             	movzwl %ax,%eax
    7b78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b7b:	48 0f af c1          	imul   %rcx,%rax
    7b7f:	48 c1 e8 20          	shr    $0x20,%rax
    7b83:	48 39 d0             	cmp    %rdx,%rax
    7b86:	73 0e                	jae    7b96 <f37+0xa6>
    7b88:	48 01 c7             	add    %rax,%rdi
    7b8b:	0f b6 07             	movzbl (%rdi),%eax
    7b8e:	84 c0                	test   %al,%al
    7b90:	0f 85 ca 02 00 00    	jne    7e60 <f37+0x370>
    7b96:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7b9b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7ba0:	ba 01 00 00 00       	mov    $0x1,%edx
    7ba5:	48 85 db             	test   %rbx,%rbx
    7ba8:	74 13                	je     7bbd <f37+0xcd>
    7baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bb0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7bb4:	48 83 c2 01          	add    $0x1,%rdx
    7bb8:	48 85 db             	test   %rbx,%rbx
    7bbb:	75 f3                	jne    7bb0 <f37+0xc0>
    7bbd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bc2:	48 85 c0             	test   %rax,%rax
    7bc5:	0f 84 15 03 00 00    	je     7ee0 <f37+0x3f0>
    7bcb:	31 db                	xor    %ebx,%ebx
    7bcd:	0f 1f 00             	nopl   (%rax)
    7bd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7bd4:	48 83 c3 01          	add    $0x1,%rbx
    7bd8:	48 85 c0             	test   %rax,%rax
    7bdb:	75 f3                	jne    7bd0 <f37+0xe0>
    7bdd:	48 39 d3             	cmp    %rdx,%rbx
    7be0:	48 0f 47 da          	cmova  %rdx,%rbx
    7be4:	48 89 d8             	mov    %rbx,%rax
    7be7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7beb:	0f 85 8f 03 00 00    	jne    7f80 <f37+0x490>
    7bf1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7bf5:	be 02 00 00 00       	mov    $0x2,%esi
    7bfa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7c01:	00 
    7c02:	e8 a9 de ff ff       	call   5ab0 <fwp_heap_alloc>
    7c07:	48 89 28             	mov    %rbp,(%rax)
    7c0a:	48 8b 15 47 8f 01 00 	mov    0x18f47(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    7c11:	49 89 c6             	mov    %rax,%r14
    7c14:	48 2b 05 15 8f 01 00 	sub    0x18f15(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    7c1b:	48 c1 e2 10          	shl    $0x10,%rdx
    7c1f:	48 39 d0             	cmp    %rdx,%rax
    7c22:	73 57                	jae    7c7b <f37+0x18b>
    7c24:	48 89 c2             	mov    %rax,%rdx
    7c27:	48 c1 ea 10          	shr    $0x10,%rdx
    7c2b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c2f:	48 8b 15 42 8f 01 00 	mov    0x18f42(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    7c36:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c3a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7c3e:	48 85 ed             	test   %rbp,%rbp
    7c41:	74 38                	je     7c7b <f37+0x18b>
    7c43:	0f b6 0a             	movzbl (%rdx),%ecx
    7c46:	80 f9 02             	cmp    $0x2,%cl
    7c49:	0f 84 51 02 00 00    	je     7ea0 <f37+0x3b0>
    7c4f:	80 f9 01             	cmp    $0x1,%cl
    7c52:	75 27                	jne    7c7b <f37+0x18b>
    7c54:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c57:	0f b7 c0             	movzwl %ax,%eax
    7c5a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c5d:	48 0f af c1          	imul   %rcx,%rax
    7c61:	48 c1 e8 20          	shr    $0x20,%rax
    7c65:	48 39 d0             	cmp    %rdx,%rax
    7c68:	73 11                	jae    7c7b <f37+0x18b>
    7c6a:	48 01 c5             	add    %rax,%rbp
    7c6d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7c71:	0f 84 d5 02 00 00    	je     7f4c <f37+0x45c>
    7c77:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7c7b:	48 85 db             	test   %rbx,%rbx
    7c7e:	74 5d                	je     7cdd <f37+0x1ed>
    7c80:	48 c1 e3 04          	shl    $0x4,%rbx
    7c84:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7c89:	4c 89 f5             	mov    %r14,%rbp
    7c8c:	4d 89 e5             	mov    %r12,%r13
    7c8f:	4c 01 f3             	add    %r14,%rbx
    7c92:	0f 1f 00             	nopl   (%rax)
    7c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c9c:	00 00 00 00 
    7ca0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7ca4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ca8:	48 83 c5 10          	add    $0x10,%rbp
    7cac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7cb1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7cb5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7cb9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7cbe:	e8 bd e3 ff ff       	call   6080 <w120>
    7cc3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7cc8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7ccc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7cd0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7cd4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7cd8:	48 39 dd             	cmp    %rbx,%rbp
    7cdb:	75 c3                	jne    7ca0 <f37+0x1b0>
    7cdd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7ce2:	e8 c9 ed ff ff       	call   6ab0 <fwp_drop4>
    7ce7:	4c 89 e7             	mov    %r12,%rdi
    7cea:	e8 c1 ed ff ff       	call   6ab0 <fwp_drop4>
    7cef:	4c 89 f7             	mov    %r14,%rdi
    7cf2:	e8 09 e5 ff ff       	call   6200 <w176.constprop.0>
    7cf7:	4c 89 f7             	mov    %r14,%rdi
    7cfa:	48 89 c3             	mov    %rax,%rbx
    7cfd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7d03:	e8 88 fb ff ff       	call   7890 <fwp_drop10>
    7d08:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7d0e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7d13:	31 ff                	xor    %edi,%edi
    7d15:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7d1a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7d1e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7d23:	e8 a8 de ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    7d28:	48 8b 15 29 8e 01 00 	mov    0x18e29(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    7d2f:	48 89 c5             	mov    %rax,%rbp
    7d32:	48 2b 05 f7 8d 01 00 	sub    0x18df7(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    7d39:	48 c1 e2 10          	shl    $0x10,%rdx
    7d3d:	48 39 d0             	cmp    %rdx,%rax
    7d40:	73 55                	jae    7d97 <f37+0x2a7>
    7d42:	48 89 c2             	mov    %rax,%rdx
    7d45:	48 c1 ea 10          	shr    $0x10,%rdx
    7d49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d4d:	48 8b 15 24 8e 01 00 	mov    0x18e24(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    7d54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d58:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7d5c:	48 85 db             	test   %rbx,%rbx
    7d5f:	74 36                	je     7d97 <f37+0x2a7>
    7d61:	0f b6 0a             	movzbl (%rdx),%ecx
    7d64:	80 f9 02             	cmp    $0x2,%cl
    7d67:	0f 84 1b 01 00 00    	je     7e88 <f37+0x398>
    7d6d:	80 f9 01             	cmp    $0x1,%cl
    7d70:	75 25                	jne    7d97 <f37+0x2a7>
    7d72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d75:	0f b7 c0             	movzwl %ax,%eax
    7d78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d7b:	48 0f af c1          	imul   %rcx,%rax
    7d7f:	48 c1 e8 20          	shr    $0x20,%rax
    7d83:	48 39 d0             	cmp    %rdx,%rax
    7d86:	73 0f                	jae    7d97 <f37+0x2a7>
    7d88:	48 01 c3             	add    %rax,%rbx
    7d8b:	80 3b ff             	cmpb   $0xff,(%rbx)
    7d8e:	0f 84 ab 01 00 00    	je     7f3f <f37+0x44f>
    7d94:	c6 03 01             	movb   $0x1,(%rbx)
    7d97:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7d9c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7da3:	00 00 
    7da5:	0f 85 d0 01 00 00    	jne    7f7b <f37+0x48b>
    7dab:	48 83 c4 38          	add    $0x38,%rsp
    7daf:	48 89 e8             	mov    %rbp,%rax
    7db2:	5b                   	pop    %rbx
    7db3:	5d                   	pop    %rbp
    7db4:	41 5c                	pop    %r12
    7db6:	41 5d                	pop    %r13
    7db8:	41 5e                	pop    %r14
    7dba:	41 5f                	pop    %r15
    7dbc:	c3                   	ret
    7dbd:	0f 1f 00             	nopl   (%rax)
    7dc0:	66 85 c0             	test   %ax,%ax
    7dc3:	0f 85 cd fd ff ff    	jne    7b96 <f37+0xa6>
    7dc9:	0f b6 07             	movzbl (%rdi),%eax
    7dcc:	84 c0                	test   %al,%al
    7dce:	0f 84 c2 fd ff ff    	je     7b96 <f37+0xa6>
    7dd4:	3c fd                	cmp    $0xfd,%al
    7dd6:	0f 87 95 01 00 00    	ja     7f71 <f37+0x481>
    7ddc:	83 c0 01             	add    $0x1,%eax
    7ddf:	88 07                	mov    %al,(%rdi)
    7de1:	e9 b0 fd ff ff       	jmp    7b96 <f37+0xa6>
    7de6:	48 f7 d9             	neg    %rcx
    7de9:	48 39 d1             	cmp    %rdx,%rcx
    7dec:	0f 83 ee 00 00 00    	jae    7ee0 <f37+0x3f0>
    7df2:	48 89 c8             	mov    %rcx,%rax
    7df5:	48 c1 e8 10          	shr    $0x10,%rax
    7df9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7dfd:	48 8b 05 74 8d 01 00 	mov    0x18d74(%rip),%rax        # 20b78 <fwp_heap+0x13f8>
    7e04:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7e08:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e0c:	48 85 ff             	test   %rdi,%rdi
    7e0f:	0f 84 cb 00 00 00    	je     7ee0 <f37+0x3f0>
    7e15:	0f b6 02             	movzbl (%rdx),%eax
    7e18:	3c 02                	cmp    $0x2,%al
    7e1a:	0f 84 9a 00 00 00    	je     7eba <f37+0x3ca>
    7e20:	3c 01                	cmp    $0x1,%al
    7e22:	0f 85 b8 00 00 00    	jne    7ee0 <f37+0x3f0>
    7e28:	0f b7 c1             	movzwl %cx,%eax
    7e2b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e31:	48 0f af c1          	imul   %rcx,%rax
    7e35:	48 c1 e8 20          	shr    $0x20,%rax
    7e39:	48 39 d0             	cmp    %rdx,%rax
    7e3c:	0f 83 9e 00 00 00    	jae    7ee0 <f37+0x3f0>
    7e42:	48 01 c7             	add    %rax,%rdi
    7e45:	0f b6 07             	movzbl (%rdi),%eax
    7e48:	84 c0                	test   %al,%al
    7e4a:	0f 84 90 00 00 00    	je     7ee0 <f37+0x3f0>
    7e50:	31 db                	xor    %ebx,%ebx
    7e52:	0f 1f 00             	nopl   (%rax)
    7e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 00 
    7e60:	3c fd                	cmp    $0xfd,%al
    7e62:	0f 87 f1 00 00 00    	ja     7f59 <f37+0x469>
    7e68:	83 c0 01             	add    $0x1,%eax
    7e6b:	88 07                	mov    %al,(%rdi)
    7e6d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e72:	31 d2                	xor    %edx,%edx
    7e74:	4d 85 e4             	test   %r12,%r12
    7e77:	0f 85 1e fd ff ff    	jne    7b9b <f37+0xab>
    7e7d:	e9 3b fd ff ff       	jmp    7bbd <f37+0xcd>
    7e82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e88:	66 85 c0             	test   %ax,%ax
    7e8b:	0f 85 06 ff ff ff    	jne    7d97 <f37+0x2a7>
    7e91:	e9 f5 fe ff ff       	jmp    7d8b <f37+0x29b>
    7e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e9d:	00 00 00 
    7ea0:	66 85 c0             	test   %ax,%ax
    7ea3:	0f 85 d2 fd ff ff    	jne    7c7b <f37+0x18b>
    7ea9:	e9 bf fd ff ff       	jmp    7c6d <f37+0x17d>
    7eae:	66 90                	xchg   %ax,%ax
    7eb0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7eb5:	e9 e6 fc ff ff       	jmp    7ba0 <f37+0xb0>
    7eba:	66 85 c9             	test   %cx,%cx
    7ebd:	75 21                	jne    7ee0 <f37+0x3f0>
    7ebf:	0f b6 07             	movzbl (%rdi),%eax
    7ec2:	84 c0                	test   %al,%al
    7ec4:	74 1a                	je     7ee0 <f37+0x3f0>
    7ec6:	3c fd                	cmp    $0xfd,%al
    7ec8:	0f 87 be 00 00 00    	ja     7f8c <f37+0x49c>
    7ece:	83 c0 01             	add    $0x1,%eax
    7ed1:	88 07                	mov    %al,(%rdi)
    7ed3:	66 90                	xchg   %ax,%ax
    7ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7edc:	00 00 00 00 
    7ee0:	be 02 00 00 00       	mov    $0x2,%esi
    7ee5:	bf 08 00 00 00       	mov    $0x8,%edi
    7eea:	e8 c1 db ff ff       	call   5ab0 <fwp_heap_alloc>
    7eef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7ef6:	48 8b 15 5b 8c 01 00 	mov    0x18c5b(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    7efd:	49 89 c6             	mov    %rax,%r14
    7f00:	48 2b 05 29 8c 01 00 	sub    0x18c29(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    7f07:	48 c1 e2 10          	shl    $0x10,%rdx
    7f0b:	48 39 d0             	cmp    %rdx,%rax
    7f0e:	73 53                	jae    7f63 <f37+0x473>
    7f10:	48 89 c2             	mov    %rax,%rdx
    7f13:	48 c1 ea 10          	shr    $0x10,%rdx
    7f17:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f1b:	48 8b 15 56 8c 01 00 	mov    0x18c56(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    7f22:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f26:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7f2a:	48 85 ed             	test   %rbp,%rbp
    7f2d:	74 34                	je     7f63 <f37+0x473>
    7f2f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f36:	00 00 
    7f38:	31 db                	xor    %ebx,%ebx
    7f3a:	e9 04 fd ff ff       	jmp    7c43 <f37+0x153>
    7f3f:	48 89 df             	mov    %rbx,%rdi
    7f42:	e8 29 d4 ff ff       	call   5370 <fwp_rc_forget_slot>
    7f47:	e9 48 fe ff ff       	jmp    7d94 <f37+0x2a4>
    7f4c:	48 89 ef             	mov    %rbp,%rdi
    7f4f:	e8 1c d4 ff ff       	call   5370 <fwp_rc_forget_slot>
    7f54:	e9 1e fd ff ff       	jmp    7c77 <f37+0x187>
    7f59:	e8 f2 d2 ff ff       	call   5250 <fwp_rc_wide_dup>
    7f5e:	e9 0a ff ff ff       	jmp    7e6d <f37+0x37d>
    7f63:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f6a:	00 00 
    7f6c:	e9 6c fd ff ff       	jmp    7cdd <f37+0x1ed>
    7f71:	e8 da d2 ff ff       	call   5250 <fwp_rc_wide_dup>
    7f76:	e9 1b fc ff ff       	jmp    7b96 <f37+0xa6>
    7f7b:	e8 e0 b4 ff ff       	call   3460 <__stack_chk_fail@plt>
    7f80:	48 8d 3d a6 31 00 00 	lea    0x31a6(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    7f87:	e8 14 c2 ff ff       	call   41a0 <fwp_trap>
    7f8c:	e8 bf d2 ff ff       	call   5250 <fwp_rc_wide_dup>
    7f91:	e9 4a ff ff ff       	jmp    7ee0 <f37+0x3f0>
    7f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f9d:	00 00 00 

0000000000007fa0 <fwp_owned_entry37>:
    7fa0:	f3 0f 1e fa          	endbr64
    7fa4:	48 8b 3f             	mov    (%rdi),%rdi
    7fa7:	e9 44 fb ff ff       	jmp    7af0 <f37>
    7fac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007fb0 <e37>:
    7fb0:	f3 0f 1e fa          	endbr64
    7fb4:	53                   	push   %rbx
    7fb5:	48 8b 1f             	mov    (%rdi),%rbx
    7fb8:	48 89 df             	mov    %rbx,%rdi
    7fbb:	e8 e0 e2 ff ff       	call   62a0 <fwp_rc_share>
    7fc0:	48 89 df             	mov    %rbx,%rdi
    7fc3:	e8 28 fb ff ff       	call   7af0 <f37>
    7fc8:	48 89 c3             	mov    %rax,%rbx
    7fcb:	48 89 c7             	mov    %rax,%rdi
    7fce:	e8 cd e2 ff ff       	call   62a0 <fwp_rc_share>
    7fd3:	48 89 d8             	mov    %rbx,%rax
    7fd6:	5b                   	pop    %rbx
    7fd7:	c3                   	ret
    7fd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fdf:	00 

0000000000007fe0 <fwp_write>:
    7fe0:	41 57                	push   %r15
    7fe2:	41 56                	push   %r14
    7fe4:	41 55                	push   %r13
    7fe6:	41 54                	push   %r12
    7fe8:	55                   	push   %rbp
    7fe9:	53                   	push   %rbx
    7fea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    7ff1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7ff8:	00 00 
    7ffa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8001:	00 
    8002:	49 89 d4             	mov    %rdx,%r12
    8005:	8b 12                	mov    (%rdx),%edx
    8007:	83 fa 19             	cmp    $0x19,%edx
    800a:	77 6a                	ja     8076 <fwp_write+0x96>
    800c:	48 89 f5             	mov    %rsi,%rbp
    800f:	89 d0                	mov    %edx,%eax
    8011:	89 ce                	mov    %ecx,%esi
    8013:	48 89 fb             	mov    %rdi,%rbx
    8016:	48 8d 0d 43 39 00 00 	lea    0x3943(%rip),%rcx        # b960 <_IO_stdin_used+0x960>
    801d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8021:	48 01 c8             	add    %rcx,%rax
    8024:	3e ff e0             	notrack jmp *%rax
    8027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    802e:	00 00 
    8030:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8034:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8038:	48 89 ca             	mov    %rcx,%rdx
    803b:	48 85 c9             	test   %rcx,%rcx
    803e:	0f 88 9c 0c 00 00    	js     8ce0 <fwp_write+0xd00>
    8044:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    804b:	00 
    804c:	48 89 c6             	mov    %rax,%rsi
    804f:	4c 89 e7             	mov    %r12,%rdi
    8052:	e8 e9 b9 ff ff       	call   3a40 <fwp_fmt_u128>
    8057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    805e:	00 00 
    8060:	4c 89 e7             	mov    %r12,%rdi
    8063:	e8 e8 b3 ff ff       	call   3450 <strlen@plt>
    8068:	4c 89 e6             	mov    %r12,%rsi
    806b:	48 89 df             	mov    %rbx,%rdi
    806e:	48 89 c2             	mov    %rax,%rdx
    8071:	e8 fa bf ff ff       	call   4070 <buf_put>
    8076:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    807d:	00 
    807e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8085:	00 00 
    8087:	0f 85 28 04 00 00    	jne    84b5 <fwp_write+0x4d5>
    808d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8094:	5b                   	pop    %rbx
    8095:	5d                   	pop    %rbp
    8096:	41 5c                	pop    %r12
    8098:	41 5d                	pop    %r13
    809a:	41 5e                	pop    %r14
    809c:	41 5f                	pop    %r15
    809e:	c3                   	ret
    809f:	90                   	nop
    80a0:	49 89 e9             	mov    %rbp,%r9
    80a3:	4c 8d 05 ad 30 00 00 	lea    0x30ad(%rip),%r8        # b157 <_IO_stdin_used+0x157>
    80aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    80af:	ba 02 00 00 00       	mov    $0x2,%edx
    80b4:	be 00 02 00 00       	mov    $0x200,%esi
    80b9:	31 c0                	xor    %eax,%eax
    80bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80c2:	00 
    80c3:	e8 e8 b2 ff ff       	call   33b0 <__snprintf_chk@plt>
    80c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80cf:	00 
    80d0:	e8 7b b3 ff ff       	call   3450 <strlen@plt>
    80d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    80dc:	00 
    80dd:	48 89 df             	mov    %rbx,%rdi
    80e0:	48 89 c2             	mov    %rax,%rdx
    80e3:	e8 88 bf ff ff       	call   4070 <buf_put>
    80e8:	eb 8c                	jmp    8076 <fwp_write+0x96>
    80ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80f0:	49 89 e9             	mov    %rbp,%r9
    80f3:	4c 8d 05 58 30 00 00 	lea    0x3058(%rip),%r8        # b152 <_IO_stdin_used+0x152>
    80fa:	eb ae                	jmp    80aa <fwp_write+0xca>
    80fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8100:	83 fa 13             	cmp    $0x13,%edx
    8103:	48 8d 05 3e 30 00 00 	lea    0x303e(%rip),%rax        # b148 <_IO_stdin_used+0x148>
    810a:	48 8d 35 3c 30 00 00 	lea    0x303c(%rip),%rsi        # b14d <_IO_stdin_used+0x14d>
    8111:	ba 04 00 00 00       	mov    $0x4,%edx
    8116:	48 0f 44 f0          	cmove  %rax,%rsi
    811a:	45 31 ed             	xor    %r13d,%r13d
    811d:	e8 4e bf ff ff       	call   4070 <buf_put>
    8122:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8127:	0f 84 a3 08 00 00    	je     89d0 <fwp_write+0x9f0>
    812d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8132:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8137:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    813c:	48 89 df             	mov    %rbx,%rdi
    813f:	49 0f 44 c5          	cmove  %r13,%rax
    8143:	31 c9                	xor    %ecx,%ecx
    8145:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    814a:	e8 91 fe ff ff       	call   7fe0 <fwp_write>
    814f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8154:	0f 84 6e 09 00 00    	je     8ac8 <fwp_write+0xae8>
    815a:	49 83 c5 01          	add    $0x1,%r13
    815e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8162:	0f 83 68 08 00 00    	jae    89d0 <fwp_write+0x9f0>
    8168:	ba 02 00 00 00       	mov    $0x2,%edx
    816d:	48 8d 35 23 30 00 00 	lea    0x3023(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8174:	48 89 df             	mov    %rbx,%rdi
    8177:	e8 f4 be ff ff       	call   4070 <buf_put>
    817c:	eb af                	jmp    812d <fwp_write+0x14d>
    817e:	66 90                	xchg   %ax,%ax
    8180:	ba 06 00 00 00       	mov    $0x6,%edx
    8185:	48 8d 35 e4 2f 00 00 	lea    0x2fe4(%rip),%rsi        # b170 <_IO_stdin_used+0x170>
    818c:	48 83 c5 10          	add    $0x10,%rbp
    8190:	e8 db be ff ff       	call   4070 <buf_put>
    8195:	48 89 ef             	mov    %rbp,%rdi
    8198:	e8 b3 b2 ff ff       	call   3450 <strlen@plt>
    819d:	48 89 ee             	mov    %rbp,%rsi
    81a0:	48 89 df             	mov    %rbx,%rdi
    81a3:	48 89 c2             	mov    %rax,%rdx
    81a6:	e8 c5 be ff ff       	call   4070 <buf_put>
    81ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    81b0:	ba 01 00 00 00       	mov    $0x1,%edx
    81b5:	48 89 df             	mov    %rbx,%rdi
    81b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    81bd:	e8 ae be ff ff       	call   4070 <buf_put>
    81c2:	e9 af fe ff ff       	jmp    8076 <fwp_write+0x96>
    81c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ce:	00 00 
    81d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    81d7:	00 
    81d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81df:	00 00 
    81e1:	0f 85 ce 02 00 00    	jne    84b5 <fwp_write+0x4d5>
    81e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    81ec:	48 8d 35 69 2f 00 00 	lea    0x2f69(%rip),%rsi        # b15c <_IO_stdin_used+0x15c>
    81f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    81fa:	48 89 df             	mov    %rbx,%rdi
    81fd:	5b                   	pop    %rbx
    81fe:	5d                   	pop    %rbp
    81ff:	41 5c                	pop    %r12
    8201:	41 5d                	pop    %r13
    8203:	41 5e                	pop    %r14
    8205:	41 5f                	pop    %r15
    8207:	e9 64 be ff ff       	jmp    4070 <buf_put>
    820c:	0f 1f 40 00          	nopl   0x0(%rax)
    8210:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8215:	4d 85 ed             	test   %r13,%r13
    8218:	0f 84 02 0c 00 00    	je     8e20 <fwp_write+0xe40>
    821e:	48 8d 35 7f 2f 00 00 	lea    0x2f7f(%rip),%rsi        # b1a4 <_IO_stdin_used+0x1a4>
    8225:	4c 89 ef             	mov    %r13,%rdi
    8228:	e8 03 b3 ff ff       	call   3530 <strcmp@plt>
    822d:	41 89 c1             	mov    %eax,%r9d
    8230:	85 c0                	test   %eax,%eax
    8232:	0f 84 6c 0c 00 00    	je     8ea4 <fwp_write+0xec4>
    8238:	4c 89 ef             	mov    %r13,%rdi
    823b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8240:	e8 0b b2 ff ff       	call   3450 <strlen@plt>
    8245:	4c 89 ee             	mov    %r13,%rsi
    8248:	48 89 df             	mov    %rbx,%rdi
    824b:	48 89 c2             	mov    %rax,%rdx
    824e:	e8 1d be ff ff       	call   4070 <buf_put>
    8253:	ba 01 00 00 00       	mov    $0x1,%edx
    8258:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    825d:	48 89 df             	mov    %rbx,%rdi
    8260:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8265:	e8 06 be ff ff       	call   4070 <buf_put>
    826a:	ba 01 00 00 00       	mov    $0x1,%edx
    826f:	4c 89 fe             	mov    %r15,%rsi
    8272:	48 89 df             	mov    %rbx,%rdi
    8275:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    827a:	e8 f1 bd ff ff       	call   4070 <buf_put>
    827f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8284:	45 31 f6             	xor    %r14d,%r14d
    8287:	85 d2                	test   %edx,%edx
    8289:	0f 8e 81 0a 00 00    	jle    8d10 <fwp_write+0xd30>
    828f:	45 31 ed             	xor    %r13d,%r13d
    8292:	4d 85 ed             	test   %r13,%r13
    8295:	0f 85 75 07 00 00    	jne    8a10 <fwp_write+0xa30>
    829b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    82a2:	00 
    82a3:	45 85 f6             	test   %r14d,%r14d
    82a6:	0f 84 84 07 00 00    	je     8a30 <fwp_write+0xa50>
    82ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    82b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    82b6:	48 89 df             	mov    %rbx,%rdi
    82b9:	49 83 c5 01          	add    $0x1,%r13
    82bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    82c1:	31 c9                	xor    %ecx,%ecx
    82c3:	e8 18 fd ff ff       	call   7fe0 <fwp_write>
    82c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    82cd:	7f c3                	jg     8292 <fwp_write+0x2b2>
    82cf:	45 85 f6             	test   %r14d,%r14d
    82d2:	0f 84 38 0a 00 00    	je     8d10 <fwp_write+0xd30>
    82d8:	b8 29 00 00 00       	mov    $0x29,%eax
    82dd:	ba 01 00 00 00       	mov    $0x1,%edx
    82e2:	4c 89 fe             	mov    %r15,%rsi
    82e5:	48 89 df             	mov    %rbx,%rdi
    82e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    82ec:	e8 7f bd ff ff       	call   4070 <buf_put>
    82f1:	e9 80 fd ff ff       	jmp    8076 <fwp_write+0x96>
    82f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82fd:	00 00 00 
    8300:	ba 01 00 00 00       	mov    $0x1,%edx
    8305:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    830a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    830f:	e8 5c bd ff ff       	call   4070 <buf_put>
    8314:	48 85 ed             	test   %rbp,%rbp
    8317:	0f 84 93 06 00 00    	je     89b0 <fwp_write+0x9d0>
    831d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8321:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8326:	31 c9                	xor    %ecx,%ecx
    8328:	48 89 df             	mov    %rbx,%rdi
    832b:	e8 b0 fc ff ff       	call   7fe0 <fwp_write>
    8330:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8334:	48 85 ed             	test   %rbp,%rbp
    8337:	0f 84 73 06 00 00    	je     89b0 <fwp_write+0x9d0>
    833d:	ba 02 00 00 00       	mov    $0x2,%edx
    8342:	48 8d 35 4e 2e 00 00 	lea    0x2e4e(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8349:	48 89 df             	mov    %rbx,%rdi
    834c:	e8 1f bd ff ff       	call   4070 <buf_put>
    8351:	eb ca                	jmp    831d <fwp_write+0x33d>
    8353:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8358:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    835c:	85 f6                	test   %esi,%esi
    835e:	0f 84 fc 07 00 00    	je     8b60 <fwp_write+0xb80>
    8364:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    836b:	00 
    836c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8373:	00 00 
    8375:	0f 85 3a 01 00 00    	jne    84b5 <fwp_write+0x4d5>
    837b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    837f:	4c 89 ea             	mov    %r13,%rdx
    8382:	e9 6c fe ff ff       	jmp    81f3 <fwp_write+0x213>
    8387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    838e:	00 00 
    8390:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8395:	ba 01 00 00 00       	mov    $0x1,%edx
    839a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    839f:	48 89 ee             	mov    %rbp,%rsi
    83a2:	e8 c9 bc ff ff       	call   4070 <buf_put>
    83a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    83ac:	4c 89 e7             	mov    %r12,%rdi
    83af:	e8 9c b0 ff ff       	call   3450 <strlen@plt>
    83b4:	4c 89 e6             	mov    %r12,%rsi
    83b7:	48 89 df             	mov    %rbx,%rdi
    83ba:	48 89 c2             	mov    %rax,%rdx
    83bd:	e8 ae bc ff ff       	call   4070 <buf_put>
    83c2:	ba 01 00 00 00       	mov    $0x1,%edx
    83c7:	48 89 ee             	mov    %rbp,%rsi
    83ca:	48 89 df             	mov    %rbx,%rdi
    83cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83d2:	e8 99 bc ff ff       	call   4070 <buf_put>
    83d7:	e9 9a fc ff ff       	jmp    8076 <fwp_write+0x96>
    83dc:	0f 1f 40 00          	nopl   0x0(%rax)
    83e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    83e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    83e9:	0f 8a 8e 0b 00 00    	jp     8f7d <fwp_write+0xf9d>
    83ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    83f3:	66 0f 54 05 75 36 00 	andpd  0x3675(%rip),%xmm0        # ba70 <msg.8+0xa0>
    83fa:	00 
    83fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8400:	66 0f 2e 05 98 36 00 	ucomisd 0x3698(%rip),%xmm0        # baa0 <msg.8+0xd0>
    8407:	00 
    8408:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    840f:	00 
    8410:	0f 87 b2 09 00 00    	ja     8dc8 <fwp_write+0xde8>
    8416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    841d:	00 00 00 
    8420:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8424:	89 ee                	mov    %ebp,%esi
    8426:	4c 89 e7             	mov    %r12,%rdi
    8429:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    842e:	e8 8d c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8433:	31 f6                	xor    %esi,%esi
    8435:	4c 89 e7             	mov    %r12,%rdi
    8438:	e8 d3 af ff ff       	call   3410 <strtod@plt>
    843d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8442:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8446:	7a 06                	jp     844e <fwp_write+0x46e>
    8448:	0f 84 e9 01 00 00    	je     8637 <fwp_write+0x657>
    844e:	83 c5 01             	add    $0x1,%ebp
    8451:	83 fd 12             	cmp    $0x12,%ebp
    8454:	75 ca                	jne    8420 <fwp_write+0x440>
    8456:	be 11 00 00 00       	mov    $0x11,%esi
    845b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    845f:	4c 89 e7             	mov    %r12,%rdi
    8462:	e8 59 c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8467:	e9 cb 01 00 00       	jmp    8637 <fwp_write+0x657>
    846c:	0f 1f 40 00          	nopl   0x0(%rax)
    8470:	48 83 fd 01          	cmp    $0x1,%rbp
    8474:	0f 84 e6 08 00 00    	je     8d60 <fwp_write+0xd80>
    847a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    847e:	b8 02 00 00 00       	mov    $0x2,%eax
    8483:	ba 01 00 00 00       	mov    $0x1,%edx
    8488:	48 0f 44 d0          	cmove  %rax,%rdx
    848c:	48 8d 35 ad 2c 00 00 	lea    0x2cad(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    8493:	48 8d 05 ab 2c 00 00 	lea    0x2cab(%rip),%rax        # b145 <_IO_stdin_used+0x145>
    849a:	48 0f 44 f0          	cmove  %rax,%rsi
    849e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84a5:	00 
    84a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84ad:	00 00 
    84af:	0f 84 3e fd ff ff    	je     81f3 <fwp_write+0x213>
    84b5:	e8 a6 af ff ff       	call   3460 <__stack_chk_fail@plt>
    84ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    84c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    84ca:	e8 e1 ba ff ff       	call   3fb0 <buf_grow>
    84cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    84d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    84d9:	4c 03 0b             	add    (%rbx),%r9
    84dc:	66 45 89 11          	mov    %r10w,(%r9)
    84e0:	45 85 e4             	test   %r12d,%r12d
    84e3:	0f 8e 07 05 00 00    	jle    89f0 <fwp_write+0xa10>
    84e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    84f0:	55 55 55 
    84f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    84f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    84ff:	aa aa aa 
    8502:	49 83 c1 01          	add    $0x1,%r9
    8506:	eb 45                	jmp    854d <fwp_write+0x56d>
    8508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    850f:	00 
    8510:	be 01 00 00 00       	mov    $0x1,%esi
    8515:	b8 2d 00 00 00       	mov    $0x2d,%eax
    851a:	88 07                	mov    %al,(%rdi)
    851c:	48 89 e8             	mov    %rbp,%rax
    851f:	49 f7 e8             	imul   %r8
    8522:	48 89 e8             	mov    %rbp,%rax
    8525:	48 c1 f8 3f          	sar    $0x3f,%rax
    8529:	48 29 c2             	sub    %rax,%rdx
    852c:	48 85 c9             	test   %rcx,%rcx
    852f:	0f 95 c0             	setne  %al
    8532:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8536:	48 83 ef 01          	sub    $0x1,%rdi
    853a:	48 21 c5             	and    %rax,%rbp
    853d:	48 29 ea             	sub    %rbp,%rdx
    8540:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8544:	49 39 f9             	cmp    %rdi,%r9
    8547:	0f 84 a3 04 00 00    	je     89f0 <fwp_write+0xa10>
    854d:	48 89 e8             	mov    %rbp,%rax
    8550:	49 f7 e8             	imul   %r8
    8553:	48 89 e8             	mov    %rbp,%rax
    8556:	48 c1 f8 3f          	sar    $0x3f,%rax
    855a:	48 89 d1             	mov    %rdx,%rcx
    855d:	48 29 c1             	sub    %rax,%rcx
    8560:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8564:	48 89 e9             	mov    %rbp,%rcx
    8567:	48 29 c1             	sub    %rax,%rcx
    856a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    856e:	49 f7 e2             	mul    %r10
    8571:	b8 30 00 00 00       	mov    $0x30,%eax
    8576:	48 89 d6             	mov    %rdx,%rsi
    8579:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    857d:	48 d1 ee             	shr    $1,%rsi
    8580:	48 01 f2             	add    %rsi,%rdx
    8583:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8587:	48 29 d6             	sub    %rdx,%rsi
    858a:	74 8e                	je     851a <fwp_write+0x53a>
    858c:	48 83 fe 01          	cmp    $0x1,%rsi
    8590:	0f 85 7a ff ff ff    	jne    8510 <fwp_write+0x530>
    8596:	31 f6                	xor    %esi,%esi
    8598:	b8 2b 00 00 00       	mov    $0x2b,%eax
    859d:	e9 78 ff ff ff       	jmp    851a <fwp_write+0x53a>
    85a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    85ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    85af:	0f 8a c8 09 00 00    	jp     8f7d <fwp_write+0xf9d>
    85b5:	0f 28 c1             	movaps %xmm1,%xmm0
    85b8:	0f 54 05 a1 34 00 00 	andps  0x34a1(%rip),%xmm0        # ba60 <msg.8+0x90>
    85bf:	0f 2e 05 3e 2a 00 00 	ucomiss 0x2a3e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    85c6:	0f 87 24 08 00 00    	ja     8df0 <fwp_write+0xe10>
    85cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    85d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    85dd:	00 
    85de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    85e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    85e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ee:	00 00 
    85f0:	44 89 ee             	mov    %r13d,%esi
    85f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    85f8:	4c 89 e7             	mov    %r12,%rdi
    85fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8600:	e8 bb be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8605:	31 f6                	xor    %esi,%esi
    8607:	4c 89 e7             	mov    %r12,%rdi
    860a:	e8 a1 ae ff ff       	call   34b0 <strtof@plt>
    860f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8614:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8617:	7a 02                	jp     861b <fwp_write+0x63b>
    8619:	74 1c                	je     8637 <fwp_write+0x657>
    861b:	41 83 c5 01          	add    $0x1,%r13d
    861f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8623:	75 cb                	jne    85f0 <fwp_write+0x610>
    8625:	be 09 00 00 00       	mov    $0x9,%esi
    862a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    862f:	4c 89 e7             	mov    %r12,%rdi
    8632:	e8 89 be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8637:	4c 89 e7             	mov    %r12,%rdi
    863a:	e8 f1 ba ff ff       	call   4130 <fwp_finish_float>
    863f:	e9 1c fa ff ff       	jmp    8060 <fwp_write+0x80>
    8644:	0f 1f 40 00          	nopl   0x0(%rax)
    8648:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    864c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8650:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8657:	00 
    8658:	48 89 ef             	mov    %rbp,%rdi
    865b:	e8 e0 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8660:	48 89 ef             	mov    %rbp,%rdi
    8663:	e8 e8 ad ff ff       	call   3450 <strlen@plt>
    8668:	48 89 ee             	mov    %rbp,%rsi
    866b:	48 89 df             	mov    %rbx,%rdi
    866e:	48 89 c2             	mov    %rax,%rdx
    8671:	e8 fa b9 ff ff       	call   4070 <buf_put>
    8676:	e9 fb f9 ff ff       	jmp    8076 <fwp_write+0x96>
    867b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8680:	ba 06 00 00 00       	mov    $0x6,%edx
    8685:	48 8d 35 0e 2b 00 00 	lea    0x2b0e(%rip),%rsi        # b19a <_IO_stdin_used+0x19a>
    868c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8692:	e8 d9 b9 ff ff       	call   4070 <buf_put>
    8697:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    869e:	ff ff 7f 
    86a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    86a5:	0f 84 86 02 00 00    	je     8931 <fwp_write+0x951>
    86ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    86b4:	48 85 d2             	test   %rdx,%rdx
    86b7:	0f 84 ae 00 00 00    	je     876b <fwp_write+0x78b>
    86bd:	8b 0a                	mov    (%rdx),%ecx
    86bf:	83 f9 1c             	cmp    $0x1c,%ecx
    86c2:	0f 84 58 06 00 00    	je     8d20 <fwp_write+0xd40>
    86c8:	83 f9 1b             	cmp    $0x1b,%ecx
    86cb:	0f 87 9a 00 00 00    	ja     876b <fwp_write+0x78b>
    86d1:	be 01 00 00 00       	mov    $0x1,%esi
    86d6:	48 d3 e6             	shl    %cl,%rsi
    86d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    86df:	0f 85 4b 04 00 00    	jne    8b30 <fwp_write+0xb50>
    86e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    86eb:	0f 85 0f 04 00 00    	jne    8b00 <fwp_write+0xb20>
    86f1:	83 e6 21             	and    $0x21,%esi
    86f4:	74 75                	je     876b <fwp_write+0x78b>
    86f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    86fb:	48 85 ff             	test   %rdi,%rdi
    86fe:	79 07                	jns    8707 <fwp_write+0x727>
    8700:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8704:	4c 01 ee             	add    %r13,%rsi
    8707:	48 0f be 3e          	movsbq (%rsi),%rdi
    870b:	85 c9                	test   %ecx,%ecx
    870d:	40 0f b6 f7          	movzbl %dil,%esi
    8711:	48 0f 44 f7          	cmove  %rdi,%rsi
    8715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    871c:	00 00 00 00 
    8720:	31 c9                	xor    %ecx,%ecx
    8722:	48 89 df             	mov    %rbx,%rdi
    8725:	49 83 c5 01          	add    $0x1,%r13
    8729:	e8 b2 f8 ff ff       	call   7fe0 <fwp_write>
    872e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8735:	ff ff 7f 
    8738:	48 23 55 00          	and    0x0(%rbp),%rdx
    873c:	49 39 d5             	cmp    %rdx,%r13
    873f:	0f 83 ec 01 00 00    	jae    8931 <fwp_write+0x951>
    8745:	ba 02 00 00 00       	mov    $0x2,%edx
    874a:	48 89 df             	mov    %rbx,%rdi
    874d:	48 8d 35 43 2a 00 00 	lea    0x2a43(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8754:	e8 17 b9 ff ff       	call   4070 <buf_put>
    8759:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    875e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8762:	48 85 d2             	test   %rdx,%rdx
    8765:	0f 85 52 ff ff ff    	jne    86bd <fwp_write+0x6dd>
    876b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8770:	48 85 ff             	test   %rdi,%rdi
    8773:	0f 88 cf 05 00 00    	js     8d48 <fwp_write+0xd68>
    8779:	48 8b 31             	mov    (%rcx),%rsi
    877c:	eb a2                	jmp    8720 <fwp_write+0x740>
    877e:	66 90                	xchg   %ax,%ax
    8780:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8787:	00 
    8788:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    878f:	00 00 
    8791:	0f 85 1e fd ff ff    	jne    84b5 <fwp_write+0x4d5>
    8797:	ba 08 00 00 00       	mov    $0x8,%edx
    879c:	48 8d 35 c4 29 00 00 	lea    0x29c4(%rip),%rsi        # b167 <_IO_stdin_used+0x167>
    87a3:	e9 4b fa ff ff       	jmp    81f3 <fwp_write+0x213>
    87a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87af:	00 
    87b0:	89 e8                	mov    %ebp,%eax
    87b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    87b9:	76 03                	jbe    87be <fwp_write+0x7de>
    87bb:	8b 45 00             	mov    0x0(%rbp),%eax
    87be:	41 89 c6             	mov    %eax,%r14d
    87c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    87c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    87cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    87cf:	4c 89 ef             	mov    %r13,%rdi
    87d2:	e8 79 ac ff ff       	call   3450 <strlen@plt>
    87d7:	4c 89 ee             	mov    %r13,%rsi
    87da:	48 89 df             	mov    %rbx,%rdi
    87dd:	48 89 c2             	mov    %rax,%rdx
    87e0:	e8 8b b8 ff ff       	call   4070 <buf_put>
    87e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    87ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    87ee:	85 f6                	test   %esi,%esi
    87f0:	0f 8e 80 f8 ff ff    	jle    8076 <fwp_write+0x96>
    87f6:	45 31 ed             	xor    %r13d,%r13d
    87f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    87fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8803:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8808:	ba 01 00 00 00       	mov    $0x1,%edx
    880d:	4c 89 fe             	mov    %r15,%rsi
    8810:	48 89 04 24          	mov    %rax,(%rsp)
    8814:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8819:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    881d:	48 89 df             	mov    %rbx,%rdi
    8820:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8824:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8829:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    882e:	e8 3d b8 ff ff       	call   4070 <buf_put>
    8833:	41 8b 06             	mov    (%r14),%eax
    8836:	83 f8 0e             	cmp    $0xe,%eax
    8839:	0f 84 71 02 00 00    	je     8ab0 <fwp_write+0xad0>
    883f:	83 f8 10             	cmp    $0x10,%eax
    8842:	0f 84 38 02 00 00    	je     8a80 <fwp_write+0xaa0>
    8848:	83 f8 0a             	cmp    $0xa,%eax
    884b:	0f 84 7f 04 00 00    	je     8cd0 <fwp_write+0xcf0>
    8851:	0f 8f f9 00 00 00    	jg     8950 <fwp_write+0x970>
    8857:	83 f8 03             	cmp    $0x3,%eax
    885a:	0f 8f 50 04 00 00    	jg     8cb0 <fwp_write+0xcd0>
    8860:	85 c0                	test   %eax,%eax
    8862:	78 10                	js     8874 <fwp_write+0x894>
    8864:	48 8b 04 24          	mov    (%rsp),%rax
    8868:	48 c1 e8 3f          	shr    $0x3f,%rax
    886c:	85 c0                	test   %eax,%eax
    886e:	0f 85 f9 00 00 00    	jne    896d <fwp_write+0x98d>
    8874:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8879:	48 8b 34 24          	mov    (%rsp),%rsi
    887d:	31 c9                	xor    %ecx,%ecx
    887f:	48 89 df             	mov    %rbx,%rdi
    8882:	e8 59 f7 ff ff       	call   7fe0 <fwp_write>
    8887:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    888c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8891:	49 83 c5 01          	add    $0x1,%r13
    8895:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8899:	0f 8f 5f ff ff ff    	jg     87fe <fwp_write+0x81e>
    889f:	e9 d2 f7 ff ff       	jmp    8076 <fwp_write+0x96>
    88a4:	0f 1f 40 00          	nopl   0x0(%rax)
    88a8:	ba 06 00 00 00       	mov    $0x6,%edx
    88ad:	48 8d 35 d9 28 00 00 	lea    0x28d9(%rip),%rsi        # b18d <_IO_stdin_used+0x18d>
    88b4:	45 31 ed             	xor    %r13d,%r13d
    88b7:	e8 b4 b7 ff ff       	call   4070 <buf_put>
    88bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    88c1:	75 19                	jne    88dc <fwp_write+0x8fc>
    88c3:	eb 6c                	jmp    8931 <fwp_write+0x951>
    88c5:	0f 1f 00             	nopl   (%rax)
    88c8:	ba 02 00 00 00       	mov    $0x2,%edx
    88cd:	48 8d 35 c3 28 00 00 	lea    0x28c3(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    88d4:	48 89 df             	mov    %rbx,%rdi
    88d7:	e8 94 b7 ff ff       	call   4070 <buf_put>
    88dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    88e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    88e7:	31 c0                	xor    %eax,%eax
    88e9:	49 83 c5 01          	add    $0x1,%r13
    88ed:	4c 8d 05 a0 28 00 00 	lea    0x28a0(%rip),%r8        # b194 <_IO_stdin_used+0x194>
    88f4:	ba 02 00 00 00       	mov    $0x2,%edx
    88f9:	be 00 02 00 00       	mov    $0x200,%esi
    88fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8905:	00 
    8906:	e8 a5 aa ff ff       	call   33b0 <__snprintf_chk@plt>
    890b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8912:	00 
    8913:	e8 38 ab ff ff       	call   3450 <strlen@plt>
    8918:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    891f:	00 
    8920:	48 89 df             	mov    %rbx,%rdi
    8923:	48 89 c2             	mov    %rax,%rdx
    8926:	e8 45 b7 ff ff       	call   4070 <buf_put>
    892b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    892f:	72 97                	jb     88c8 <fwp_write+0x8e8>
    8931:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8936:	ba 01 00 00 00       	mov    $0x1,%edx
    893b:	48 89 df             	mov    %rbx,%rdi
    893e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8943:	e8 28 b7 ff ff       	call   4070 <buf_put>
    8948:	e9 29 f7 ff ff       	jmp    8076 <fwp_write+0x96>
    894d:	0f 1f 00             	nopl   (%rax)
    8950:	83 f8 0b             	cmp    $0xb,%eax
    8953:	0f 85 1b ff ff ff    	jne    8874 <fwp_write+0x894>
    8959:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    895e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8962:	83 e0 01             	and    $0x1,%eax
    8965:	85 c0                	test   %eax,%eax
    8967:	0f 84 07 ff ff ff    	je     8874 <fwp_write+0x894>
    896d:	4c 89 fe             	mov    %r15,%rsi
    8970:	48 89 df             	mov    %rbx,%rdi
    8973:	ba 01 00 00 00       	mov    $0x1,%edx
    8978:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    897d:	e8 ee b6 ff ff       	call   4070 <buf_put>
    8982:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8987:	48 8b 34 24          	mov    (%rsp),%rsi
    898b:	31 c9                	xor    %ecx,%ecx
    898d:	48 89 df             	mov    %rbx,%rdi
    8990:	e8 4b f6 ff ff       	call   7fe0 <fwp_write>
    8995:	ba 01 00 00 00       	mov    $0x1,%edx
    899a:	4c 89 fe             	mov    %r15,%rsi
    899d:	48 89 df             	mov    %rbx,%rdi
    89a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    89a5:	e8 c6 b6 ff ff       	call   4070 <buf_put>
    89aa:	e9 d8 fe ff ff       	jmp    8887 <fwp_write+0x8a7>
    89af:	90                   	nop
    89b0:	ba 01 00 00 00       	mov    $0x1,%edx
    89b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89ba:	48 89 df             	mov    %rbx,%rdi
    89bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    89c2:	e8 a9 b6 ff ff       	call   4070 <buf_put>
    89c7:	e9 aa f6 ff ff       	jmp    8076 <fwp_write+0x96>
    89cc:	0f 1f 40 00          	nopl   0x0(%rax)
    89d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89d5:	ba 01 00 00 00       	mov    $0x1,%edx
    89da:	48 89 df             	mov    %rbx,%rdi
    89dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    89e2:	e8 89 b6 ff ff       	call   4070 <buf_put>
    89e7:	e9 8a f6 ff ff       	jmp    8076 <fwp_write+0x96>
    89ec:	0f 1f 40 00          	nopl   0x0(%rax)
    89f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    89f4:	48 8b 13             	mov    (%rbx),%rdx
    89f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    89fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8a00:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8a04:	e9 6d f6 ff ff       	jmp    8076 <fwp_write+0x96>
    8a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a10:	ba 02 00 00 00       	mov    $0x2,%edx
    8a15:	48 8d 35 7b 27 00 00 	lea    0x277b(%rip),%rsi        # b197 <_IO_stdin_used+0x197>
    8a1c:	48 89 df             	mov    %rbx,%rdi
    8a1f:	e8 4c b6 ff ff       	call   4070 <buf_put>
    8a24:	e9 72 f8 ff ff       	jmp    829b <fwp_write+0x2bb>
    8a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a30:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a35:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8a3a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8a3e:	48 89 f7             	mov    %rsi,%rdi
    8a41:	48 89 34 24          	mov    %rsi,(%rsp)
    8a45:	e8 06 aa ff ff       	call   3450 <strlen@plt>
    8a4a:	48 8b 34 24          	mov    (%rsp),%rsi
    8a4e:	48 89 df             	mov    %rbx,%rdi
    8a51:	48 89 c2             	mov    %rax,%rdx
    8a54:	e8 17 b6 ff ff       	call   4070 <buf_put>
    8a59:	ba 03 00 00 00       	mov    $0x3,%edx
    8a5e:	48 8d 35 55 27 00 00 	lea    0x2755(%rip),%rsi        # b1ba <_IO_stdin_used+0x1ba>
    8a65:	48 89 df             	mov    %rbx,%rdi
    8a68:	e8 03 b6 ff ff       	call   4070 <buf_put>
    8a6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8a72:	e9 35 f8 ff ff       	jmp    82ac <fwp_write+0x2cc>
    8a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a7e:	00 00 
    8a80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8a85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8a89:	48 85 ff             	test   %rdi,%rdi
    8a8c:	0f 84 e2 fd ff ff    	je     8874 <fwp_write+0x894>
    8a92:	48 8d 35 0b 27 00 00 	lea    0x270b(%rip),%rsi        # b1a4 <_IO_stdin_used+0x1a4>
    8a99:	e8 92 aa ff ff       	call   3530 <strcmp@plt>
    8a9e:	85 c0                	test   %eax,%eax
    8aa0:	0f 95 c0             	setne  %al
    8aa3:	0f b6 c0             	movzbl %al,%eax
    8aa6:	e9 c1 fd ff ff       	jmp    886c <fwp_write+0x88c>
    8aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ab0:	31 c0                	xor    %eax,%eax
    8ab2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8ab9:	00 
    8aba:	0f 97 c0             	seta   %al
    8abd:	e9 aa fd ff ff       	jmp    886c <fwp_write+0x88c>
    8ac2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ac8:	48 89 df             	mov    %rbx,%rdi
    8acb:	ba 02 00 00 00       	mov    $0x2,%edx
    8ad0:	48 8d 35 ca 26 00 00 	lea    0x26ca(%rip),%rsi        # b1a1 <_IO_stdin_used+0x1a1>
    8ad7:	e8 94 b5 ff ff       	call   4070 <buf_put>
    8adc:	4c 89 e8             	mov    %r13,%rax
    8adf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8ae4:	31 c9                	xor    %ecx,%ecx
    8ae6:	48 c1 e0 04          	shl    $0x4,%rax
    8aea:	48 89 df             	mov    %rbx,%rdi
    8aed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8af2:	e8 e9 f4 ff ff       	call   7fe0 <fwp_write>
    8af7:	e9 5e f6 ff ff       	jmp    815a <fwp_write+0x17a>
    8afc:	0f 1f 40 00          	nopl   0x0(%rax)
    8b00:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8b05:	48 85 ff             	test   %rdi,%rdi
    8b08:	79 0c                	jns    8b16 <fwp_write+0xb36>
    8b0a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8b11:	00 
    8b12:	48 03 75 10          	add    0x10(%rbp),%rsi
    8b16:	48 63 3e             	movslq (%rsi),%rdi
    8b19:	83 f9 02             	cmp    $0x2,%ecx
    8b1c:	89 fe                	mov    %edi,%esi
    8b1e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b22:	e9 f9 fb ff ff       	jmp    8720 <fwp_write+0x740>
    8b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b2e:	00 00 
    8b30:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8b35:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8b3a:	48 85 ff             	test   %rdi,%rdi
    8b3d:	0f 88 0f 03 00 00    	js     8e52 <fwp_write+0xe72>
    8b43:	49 0f bf 38          	movswq (%r8),%rdi
    8b47:	83 f9 01             	cmp    $0x1,%ecx
    8b4a:	0f b7 f7             	movzwl %di,%esi
    8b4d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b51:	e9 ca fb ff ff       	jmp    8720 <fwp_write+0x740>
    8b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b5d:	00 00 00 
    8b60:	ba 01 00 00 00       	mov    $0x1,%edx
    8b65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b6a:	48 83 c5 08          	add    $0x8,%rbp
    8b6e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8b73:	e8 f8 b4 ff ff       	call   4070 <buf_put>
    8b78:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8b7d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8b82:	4d 85 ed             	test   %r13,%r13
    8b85:	75 46                	jne    8bcd <fwp_write+0xbed>
    8b87:	e9 04 01 00 00       	jmp    8c90 <fwp_write+0xcb0>
    8b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b90:	41 80 f9 09          	cmp    $0x9,%r9b
    8b94:	0f 84 d6 00 00 00    	je     8c70 <fwp_write+0xc90>
    8b9a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8b9e:	0f 85 9c 00 00 00    	jne    8c40 <fwp_write+0xc60>
    8ba4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ba9:	48 8d 35 cd 25 00 00 	lea    0x25cd(%rip),%rsi        # b17d <_IO_stdin_used+0x17d>
    8bb0:	48 89 df             	mov    %rbx,%rdi
    8bb3:	e8 b8 b4 ff ff       	call   4070 <buf_put>
    8bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bbf:	00 
    8bc0:	48 83 c5 01          	add    $0x1,%rbp
    8bc4:	49 39 ec             	cmp    %rbp,%r12
    8bc7:	0f 84 c3 00 00 00    	je     8c90 <fwp_write+0xcb0>
    8bcd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8bd2:	41 80 f9 0d          	cmp    $0xd,%r9b
    8bd6:	74 28                	je     8c00 <fwp_write+0xc20>
    8bd8:	7e b6                	jle    8b90 <fwp_write+0xbb0>
    8bda:	41 80 f9 22          	cmp    $0x22,%r9b
    8bde:	74 40                	je     8c20 <fwp_write+0xc40>
    8be0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8be4:	75 5a                	jne    8c40 <fwp_write+0xc60>
    8be6:	ba 02 00 00 00       	mov    $0x2,%edx
    8beb:	48 8d 35 88 25 00 00 	lea    0x2588(%rip),%rsi        # b17a <_IO_stdin_used+0x17a>
    8bf2:	48 89 df             	mov    %rbx,%rdi
    8bf5:	e8 76 b4 ff ff       	call   4070 <buf_put>
    8bfa:	eb c4                	jmp    8bc0 <fwp_write+0xbe0>
    8bfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8c00:	ba 02 00 00 00       	mov    $0x2,%edx
    8c05:	48 8d 35 77 25 00 00 	lea    0x2577(%rip),%rsi        # b183 <_IO_stdin_used+0x183>
    8c0c:	48 89 df             	mov    %rbx,%rdi
    8c0f:	e8 5c b4 ff ff       	call   4070 <buf_put>
    8c14:	eb aa                	jmp    8bc0 <fwp_write+0xbe0>
    8c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c1d:	00 00 00 
    8c20:	ba 02 00 00 00       	mov    $0x2,%edx
    8c25:	48 8d 35 4b 25 00 00 	lea    0x254b(%rip),%rsi        # b177 <_IO_stdin_used+0x177>
    8c2c:	48 89 df             	mov    %rbx,%rdi
    8c2f:	e8 3c b4 ff ff       	call   4070 <buf_put>
    8c34:	eb 8a                	jmp    8bc0 <fwp_write+0xbe0>
    8c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c3d:	00 00 00 
    8c40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8c44:	0f 86 2e 01 00 00    	jbe    8d78 <fwp_write+0xd98>
    8c4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8c4e:	0f 84 24 01 00 00    	je     8d78 <fwp_write+0xd98>
    8c54:	ba 01 00 00 00       	mov    $0x1,%edx
    8c59:	4c 89 fe             	mov    %r15,%rsi
    8c5c:	48 89 df             	mov    %rbx,%rdi
    8c5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8c64:	e8 07 b4 ff ff       	call   4070 <buf_put>
    8c69:	e9 52 ff ff ff       	jmp    8bc0 <fwp_write+0xbe0>
    8c6e:	66 90                	xchg   %ax,%ax
    8c70:	ba 02 00 00 00       	mov    $0x2,%edx
    8c75:	48 8d 35 04 25 00 00 	lea    0x2504(%rip),%rsi        # b180 <_IO_stdin_used+0x180>
    8c7c:	48 89 df             	mov    %rbx,%rdi
    8c7f:	e8 ec b3 ff ff       	call   4070 <buf_put>
    8c84:	e9 37 ff ff ff       	jmp    8bc0 <fwp_write+0xbe0>
    8c89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c90:	ba 01 00 00 00       	mov    $0x1,%edx
    8c95:	4c 89 fe             	mov    %r15,%rsi
    8c98:	48 89 df             	mov    %rbx,%rdi
    8c9b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ca0:	e8 cb b3 ff ff       	call   4070 <buf_put>
    8ca5:	e9 cc f3 ff ff       	jmp    8076 <fwp_write+0x96>
    8caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cb0:	83 f8 04             	cmp    $0x4,%eax
    8cb3:	0f 85 bb fb ff ff    	jne    8874 <fwp_write+0x894>
    8cb9:	48 8b 04 24          	mov    (%rsp),%rax
    8cbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8cc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8cc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8cca:	e9 96 fc ff ff       	jmp    8965 <fwp_write+0x985>
    8ccf:	90                   	nop
    8cd0:	8b 0c 24             	mov    (%rsp),%ecx
    8cd3:	31 c0                	xor    %eax,%eax
    8cd5:	85 c9                	test   %ecx,%ecx
    8cd7:	0f 98 c0             	sets   %al
    8cda:	e9 86 fc ff ff       	jmp    8965 <fwp_write+0x985>
    8cdf:	90                   	nop
    8ce0:	48 f7 d8             	neg    %rax
    8ce3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8cea:	00 
    8ceb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8cf2:	2d 
    8cf3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8cfa:	00 
    8cfb:	48 83 d2 00          	adc    $0x0,%rdx
    8cff:	48 89 c6             	mov    %rax,%rsi
    8d02:	48 f7 da             	neg    %rdx
    8d05:	e8 36 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8d0a:	e9 51 f3 ff ff       	jmp    8060 <fwp_write+0x80>
    8d0f:	90                   	nop
    8d10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8d15:	e9 c3 f5 ff ff       	jmp    82dd <fwp_write+0x2fd>
    8d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d20:	4c 89 e9             	mov    %r13,%rcx
    8d23:	48 c1 e1 04          	shl    $0x4,%rcx
    8d27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8d2c:	48 85 ff             	test   %rdi,%rdi
    8d2f:	0f 89 eb f9 ff ff    	jns    8720 <fwp_write+0x740>
    8d35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d39:	48 89 ce             	mov    %rcx,%rsi
    8d3c:	e9 df f9 ff ff       	jmp    8720 <fwp_write+0x740>
    8d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8d4f:	00 
    8d50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d54:	e9 20 fa ff ff       	jmp    8779 <fwp_write+0x799>
    8d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d60:	ba 02 00 00 00       	mov    $0x2,%edx
    8d65:	48 8d 35 d6 23 00 00 	lea    0x23d6(%rip),%rsi        # b142 <_IO_stdin_used+0x142>
    8d6c:	e9 2d f7 ff ff       	jmp    849e <fwp_write+0x4be>
    8d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d78:	4c 8d 05 07 24 00 00 	lea    0x2407(%rip),%r8        # b186 <_IO_stdin_used+0x186>
    8d7f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8d84:	31 c0                	xor    %eax,%eax
    8d86:	ba 02 00 00 00       	mov    $0x2,%edx
    8d8b:	be 10 00 00 00       	mov    $0x10,%esi
    8d90:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d97:	00 
    8d98:	e8 13 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8d9d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8da4:	00 
    8da5:	e8 a6 a6 ff ff       	call   3450 <strlen@plt>
    8daa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8db1:	00 
    8db2:	48 89 df             	mov    %rbx,%rdi
    8db5:	48 89 c2             	mov    %rax,%rdx
    8db8:	e8 b3 b2 ff ff       	call   4070 <buf_put>
    8dbd:	e9 fe fd ff ff       	jmp    8bc0 <fwp_write+0xbe0>
    8dc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8dc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8dcc:	48 8d 35 69 23 00 00 	lea    0x2369(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    8dd3:	48 8d 05 61 23 00 00 	lea    0x2361(%rip),%rax        # b13b <_IO_stdin_used+0x13b>
    8dda:	4c 89 e7             	mov    %r12,%rdi
    8ddd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8de1:	48 0f 46 f0          	cmovbe %rax,%rsi
    8de5:	e8 06 a6 ff ff       	call   33f0 <strcpy@plt>
    8dea:	e9 71 f2 ff ff       	jmp    8060 <fwp_write+0x80>
    8def:	90                   	nop
    8df0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8df4:	48 8d 35 41 23 00 00 	lea    0x2341(%rip),%rsi        # b13c <_IO_stdin_used+0x13c>
    8dfb:	48 8d 05 39 23 00 00 	lea    0x2339(%rip),%rax        # b13b <_IO_stdin_used+0x13b>
    8e02:	0f 2f c8             	comiss %xmm0,%xmm1
    8e05:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e0c:	00 
    8e0d:	4c 89 e7             	mov    %r12,%rdi
    8e10:	48 0f 46 f0          	cmovbe %rax,%rsi
    8e14:	e8 d7 a5 ff ff       	call   33f0 <strcpy@plt>
    8e19:	e9 42 f2 ff ff       	jmp    8060 <fwp_write+0x80>
    8e1e:	66 90                	xchg   %ax,%ax
    8e20:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8e25:	45 85 c0             	test   %r8d,%r8d
    8e28:	75 34                	jne    8e5e <fwp_write+0xe7e>
    8e2a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e31:	00 
    8e32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e39:	00 00 
    8e3b:	0f 85 74 f6 ff ff    	jne    84b5 <fwp_write+0x4d5>
    8e41:	ba 02 00 00 00       	mov    $0x2,%edx
    8e46:	48 8d 35 6a 23 00 00 	lea    0x236a(%rip),%rsi        # b1b7 <_IO_stdin_used+0x1b7>
    8e4d:	e9 a1 f3 ff ff       	jmp    81f3 <fwp_write+0x213>
    8e52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8e56:	49 89 f0             	mov    %rsi,%r8
    8e59:	e9 e5 fc ff ff       	jmp    8b43 <fwp_write+0xb63>
    8e5e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8e63:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e68:	85 ff                	test   %edi,%edi
    8e6a:	0f 84 fa f3 ff ff    	je     826a <fwp_write+0x28a>
    8e70:	ba 01 00 00 00       	mov    $0x1,%edx
    8e75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e7a:	48 89 df             	mov    %rbx,%rdi
    8e7d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8e82:	e8 e9 b1 ff ff       	call   4070 <buf_put>
    8e87:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8e8c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e91:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8e97:	85 c0                	test   %eax,%eax
    8e99:	0f 8f f0 f3 ff ff    	jg     828f <fwp_write+0x2af>
    8e9f:	e9 34 f4 ff ff       	jmp    82d8 <fwp_write+0x2f8>
    8ea4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8ea8:	49 89 c5             	mov    %rax,%r13
    8eab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8eb0:	49 89 c4             	mov    %rax,%r12
    8eb3:	49 c1 fd 3f          	sar    $0x3f,%r13
    8eb7:	4c 09 e8             	or     %r13,%rax
    8eba:	0f 84 a7 00 00 00    	je     8f67 <fwp_write+0xf87>
    8ec0:	48 8d 2d f9 43 00 00 	lea    0x43f9(%rip),%rbp        # d2c0 <units.0>
    8ec7:	4d 89 e7             	mov    %r12,%r15
    8eca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8ece:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8ed3:	4c 89 ff             	mov    %r15,%rdi
    8ed6:	4c 89 ee             	mov    %r13,%rsi
    8ed9:	44 89 0c 24          	mov    %r9d,(%rsp)
    8edd:	48 99                	cqto
    8edf:	48 89 d1             	mov    %rdx,%rcx
    8ee2:	48 89 c2             	mov    %rax,%rdx
    8ee5:	e8 26 0f 00 00       	call   9e10 <__divmodti4>
    8eea:	44 8b 0c 24          	mov    (%rsp),%r9d
    8eee:	48 89 c1             	mov    %rax,%rcx
    8ef1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8ef6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8efb:	0f 84 94 00 00 00    	je     8f95 <fwp_write+0xfb5>
    8f01:	41 83 c1 01          	add    $0x1,%r9d
    8f05:	48 83 c5 10          	add    $0x10,%rbp
    8f09:	41 83 f9 05          	cmp    $0x5,%r9d
    8f0d:	75 bb                	jne    8eca <fwp_write+0xeea>
    8f0f:	4d 85 ed             	test   %r13,%r13
    8f12:	79 53                	jns    8f67 <fwp_write+0xf87>
    8f14:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8f19:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8f1e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8f23:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f28:	48 99                	cqto
    8f2a:	48 f7 d8             	neg    %rax
    8f2d:	48 83 d2 00          	adc    $0x0,%rdx
    8f31:	48 89 c6             	mov    %rax,%rsi
    8f34:	48 f7 da             	neg    %rdx
    8f37:	e8 04 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f3c:	49 89 e8             	mov    %rbp,%r8
    8f3f:	ba 00 02 00 00       	mov    $0x200,%edx
    8f44:	be 02 00 00 00       	mov    $0x2,%esi
    8f49:	31 c0                	xor    %eax,%eax
    8f4b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f52:	00 
    8f53:	48 8d 0d 58 22 00 00 	lea    0x2258(%rip),%rcx        # b1b2 <_IO_stdin_used+0x1b2>
    8f5a:	4c 89 e7             	mov    %r12,%rdi
    8f5d:	e8 7e a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8f62:	e9 f9 f0 ff ff       	jmp    8060 <fwp_write+0x80>
    8f67:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    8f71:	31 d2                	xor    %edx,%edx
    8f73:	48 89 ef             	mov    %rbp,%rdi
    8f76:	e8 c5 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f7b:	eb bf                	jmp    8f3c <fwp_write+0xf5c>
    8f7d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    8f84:	4e 61 4e 00 
    8f88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f8f:	00 
    8f90:	e9 cb f0 ff ff       	jmp    8060 <fwp_write+0x80>
    8f95:	44 89 0c 24          	mov    %r9d,(%rsp)
    8f99:	48 89 c8             	mov    %rcx,%rax
    8f9c:	48 85 d2             	test   %rdx,%rdx
    8f9f:	78 51                	js     8ff2 <fwp_write+0x1012>
    8fa1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8fa6:	48 89 c6             	mov    %rax,%rsi
    8fa9:	48 89 ef             	mov    %rbp,%rdi
    8fac:	e8 8f aa ff ff       	call   3a40 <fwp_fmt_u128>
    8fb1:	44 8b 0c 24          	mov    (%rsp),%r9d
    8fb5:	49 63 c1             	movslq %r9d,%rax
    8fb8:	49 89 e8             	mov    %rbp,%r8
    8fbb:	ba 00 02 00 00       	mov    $0x200,%edx
    8fc0:	be 02 00 00 00       	mov    $0x2,%esi
    8fc5:	48 c1 e0 04          	shl    $0x4,%rax
    8fc9:	48 8d 3d f0 42 00 00 	lea    0x42f0(%rip),%rdi        # d2c0 <units.0>
    8fd0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8fd7:	00 
    8fd8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    8fdc:	48 8d 0d ca 21 00 00 	lea    0x21ca(%rip),%rcx        # b1ad <_IO_stdin_used+0x1ad>
    8fe3:	4c 89 e7             	mov    %r12,%rdi
    8fe6:	31 c0                	xor    %eax,%eax
    8fe8:	e8 f3 a6 ff ff       	call   36e0 <__sprintf_chk@plt>
    8fed:	e9 6e f0 ff ff       	jmp    8060 <fwp_write+0x80>
    8ff2:	48 f7 d8             	neg    %rax
    8ff5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8ffa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8fff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9004:	48 83 d2 00          	adc    $0x0,%rdx
    9008:	48 89 c6             	mov    %rax,%rsi
    900b:	48 f7 da             	neg    %rdx
    900e:	e8 2d aa ff ff       	call   3a40 <fwp_fmt_u128>
    9013:	44 8b 0c 24          	mov    (%rsp),%r9d
    9017:	eb 9c                	jmp    8fb5 <fwp_write+0xfd5>
    9019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009020 <fwp_main_thread>:
    9020:	f3 0f 1e fa          	endbr64
    9024:	41 57                	push   %r15
    9026:	41 56                	push   %r14
    9028:	41 55                	push   %r13
    902a:	41 54                	push   %r12
    902c:	55                   	push   %rbp
    902d:	53                   	push   %rbx
    902e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9035:	8b 0d e9 7a 01 00    	mov    0x17ae9(%rip),%ecx        # 20b24 <fwp_heap+0x13a4>
    903b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9042:	00 00 
    9044:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    904b:	00 
    904c:	31 c0                	xor    %eax,%eax
    904e:	85 c9                	test   %ecx,%ecx
    9050:	0f 84 62 06 00 00    	je     96b8 <fwp_main_thread+0x698>
    9056:	8b 15 cc 7a 01 00    	mov    0x17acc(%rip),%edx        # 20b28 <fwp_heap+0x13a8>
    905c:	85 d2                	test   %edx,%edx
    905e:	0f 85 3c 06 00 00    	jne    96a0 <fwp_main_thread+0x680>
    9064:	48 8d 05 35 60 00 00 	lea    0x6035(%rip),%rax        # f0a0 <alt.9>
    906b:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    9070:	31 f6                	xor    %esi,%esi
    9072:	48 c7 05 9b 60 01 00 	movq   $0x40000000,0x1609b(%rip)        # 1f118 <fwp_main_stack_size>
    9079:	00 00 00 40 
    907d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9082:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9087:	48 89 c7             	mov    %rax,%rdi
    908a:	4c 89 25 8f 60 01 00 	mov    %r12,0x1608f(%rip)        # 1f120 <fwp_main_stack_top>
    9091:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9098:	01 00 
    909a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    90a1:	00 
    90a2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    90a7:	e8 14 a6 ff ff       	call   36c0 <sigaltstack@plt>
    90ac:	85 c0                	test   %eax,%eax
    90ae:	0f 85 23 0d 00 00    	jne    9dd7 <fwp_main_thread+0xdb7>
    90b4:	31 ed                	xor    %ebp,%ebp
    90b6:	b9 12 00 00 00       	mov    $0x12,%ecx
    90bb:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    90c2:	00 
    90c3:	48 89 e8             	mov    %rbp,%rax
    90c6:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    90cd:	00 
    90ce:	f3 48 ab             	rep stos %rax,(%rdi)
    90d1:	48 8d 05 18 ac ff ff 	lea    -0x53e8(%rip),%rax        # 3cf0 <fwp_segv>
    90d8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    90df:	00 
    90e0:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    90e7:	04 00 00 08 
    90eb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    90f2:	00 
    90f3:	e8 88 a4 ff ff       	call   3580 <sigemptyset@plt>
    90f8:	85 c0                	test   %eax,%eax
    90fa:	0f 85 d7 0c 00 00    	jne    9dd7 <fwp_main_thread+0xdb7>
    9100:	31 d2                	xor    %edx,%edx
    9102:	48 89 de             	mov    %rbx,%rsi
    9105:	bf 0b 00 00 00       	mov    $0xb,%edi
    910a:	e8 f1 a2 ff ff       	call   3400 <sigaction@plt>
    910f:	85 c0                	test   %eax,%eax
    9111:	0f 85 c0 0c 00 00    	jne    9dd7 <fwp_main_thread+0xdb7>
    9117:	31 d2                	xor    %edx,%edx
    9119:	48 89 de             	mov    %rbx,%rsi
    911c:	bf 07 00 00 00       	mov    $0x7,%edi
    9121:	e8 da a2 ff ff       	call   3400 <sigaction@plt>
    9126:	85 c0                	test   %eax,%eax
    9128:	0f 85 a9 0c 00 00    	jne    9dd7 <fwp_main_thread+0xdb7>
    912e:	8b 05 54 5f 00 00    	mov    0x5f54(%rip),%eax        # f088 <st.7>
    9134:	85 c0                	test   %eax,%eax
    9136:	0f 84 8c 05 00 00    	je     96c8 <fwp_main_thread+0x6a8>
    913c:	48 8b 2d 1d 66 01 00 	mov    0x1661d(%rip),%rbp        # 1f760 <fwp_cur>
    9143:	48 85 ed             	test   %rbp,%rbp
    9146:	0f 84 04 03 00 00    	je     9450 <fwp_main_thread+0x430>
    914c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9151:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9155:	48 89 eb             	mov    %rbp,%rbx
    9158:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    915d:	0f 84 41 01 00 00    	je     92a4 <fwp_main_thread+0x284>
    9163:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9168:	0f 84 12 02 00 00    	je     9380 <fwp_main_thread+0x360>
    916e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9172:	0f 84 f8 01 00 00    	je     9370 <fwp_main_thread+0x350>
    9178:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    917c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9180:	0f 85 7a 02 00 00    	jne    9400 <fwp_main_thread+0x3e0>
    9186:	48 8b 43 60          	mov    0x60(%rbx),%rax
    918a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9191:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9195:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    919c:	00 00 00 00 
    91a0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    91a7:	48 85 d2             	test   %rdx,%rdx
    91aa:	74 07                	je     91b3 <fwp_main_thread+0x193>
    91ac:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    91b3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    91b7:	48 85 c0             	test   %rax,%rax
    91ba:	74 34                	je     91f0 <fwp_main_thread+0x1d0>
    91bc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    91c0:	48 8b 05 71 65 01 00 	mov    0x16571(%rip),%rax        # 1f738 <fwp_timers>
    91c7:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    91cb:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    91d2:	00 00 00 00 
    91d6:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    91dd:	48 85 c0             	test   %rax,%rax
    91e0:	74 07                	je     91e9 <fwp_main_thread+0x1c9>
    91e2:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    91e9:	48 89 1d 48 65 01 00 	mov    %rbx,0x16548(%rip)        # 1f738 <fwp_timers>
    91f0:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    91f4:	e8 77 de ff ff       	call   7070 <fwp_block>
    91f9:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9200:	48 85 c9             	test   %rcx,%rcx
    9203:	74 47                	je     924c <fwp_main_thread+0x22c>
    9205:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    920c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9213:	48 85 d2             	test   %rdx,%rdx
    9216:	0f 84 24 02 00 00    	je     9440 <fwp_main_thread+0x420>
    921c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9223:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    922a:	48 85 c0             	test   %rax,%rax
    922d:	74 07                	je     9236 <fwp_main_thread+0x216>
    922f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9236:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    923d:	00 00 00 00 
    9241:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9245:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    924c:	48 8b 0d 0d 65 01 00 	mov    0x1650d(%rip),%rcx        # 1f760 <fwp_cur>
    9253:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9257:	0f 84 93 01 00 00    	je     93f0 <fwp_main_thread+0x3d0>
    925d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9264:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    926b:	48 85 d2             	test   %rdx,%rdx
    926e:	0f 84 94 03 00 00    	je     9608 <fwp_main_thread+0x5e8>
    9274:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    927b:	48 85 c0             	test   %rax,%rax
    927e:	74 07                	je     9287 <fwp_main_thread+0x267>
    9280:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9287:	66 0f ef d2          	pxor   %xmm2,%xmm2
    928b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    928f:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    9296:	48 89 cb             	mov    %rcx,%rbx
    9299:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    929e:	0f 85 bf fe ff ff    	jne    9163 <fwp_main_thread+0x143>
    92a4:	48 83 3d 4c 81 01 00 	cmpq   $0x0,0x1814c(%rip)        # 213f8 <fwp_state_len>
    92ab:	00 
    92ac:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    92b0:	0f 84 7c 03 00 00    	je     9632 <fwp_main_thread+0x612>
    92b6:	48 39 1d 9b 64 01 00 	cmp    %rbx,0x1649b(%rip)        # 1f758 <fwp_root>
    92bd:	c7 05 d9 5d 01 00 00 	movl   $0x0,0x15dd9(%rip)        # 1f0a0 <fwp_exit_code>
    92c4:	00 00 00 
    92c7:	0f 85 38 0b 00 00    	jne    9e05 <fwp_main_thread+0xde5>
    92cd:	48 85 db             	test   %rbx,%rbx
    92d0:	0f 84 a0 01 00 00    	je     9476 <fwp_main_thread+0x456>
    92d6:	48 8b 15 4b 64 01 00 	mov    0x1644b(%rip),%rdx        # 1f728 <fwp_tasks_active>
    92dd:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    92e1:	48 85 d2             	test   %rdx,%rdx
    92e4:	0f 84 8c 01 00 00    	je     9476 <fwp_main_thread+0x456>
    92ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92f0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    92f4:	75 08                	jne    92fe <fwp_main_thread+0x2de>
    92f6:	48 89 d7             	mov    %rdx,%rdi
    92f9:	e8 b2 ad ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    92fe:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9305:	48 85 d2             	test   %rdx,%rdx
    9308:	75 e6                	jne    92f0 <fwp_main_thread+0x2d0>
    930a:	eb 31                	jmp    933d <fwp_main_thread+0x31d>
    930c:	0f 1f 40 00          	nopl   0x0(%rax)
    9310:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9317:	48 89 1d 22 64 01 00 	mov    %rbx,0x16422(%rip)        # 1f740 <fwp_ready_tail>
    931e:	e8 4d dd ff ff       	call   7070 <fwp_block>
    9323:	e8 38 db ff ff       	call   6e60 <fwp_free_zombie>
    9328:	48 83 3d f8 63 01 00 	cmpq   $0x0,0x163f8(%rip)        # 1f728 <fwp_tasks_active>
    932f:	00 
    9330:	0f 84 40 01 00 00    	je     9476 <fwp_main_thread+0x456>
    9336:	48 8b 1d 1b 64 01 00 	mov    0x1641b(%rip),%rbx        # 1f758 <fwp_root>
    933d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9341:	75 db                	jne    931e <fwp_main_thread+0x2fe>
    9343:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9347:	75 d5                	jne    931e <fwp_main_thread+0x2fe>
    9349:	48 8b 05 f0 63 01 00 	mov    0x163f0(%rip),%rax        # 1f740 <fwp_ready_tail>
    9350:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9354:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    935b:	00 00 00 00 
    935f:	48 85 c0             	test   %rax,%rax
    9362:	75 ac                	jne    9310 <fwp_main_thread+0x2f0>
    9364:	48 89 1d dd 63 01 00 	mov    %rbx,0x163dd(%rip)        # 1f748 <fwp_ready_head>
    936b:	eb aa                	jmp    9317 <fwp_main_thread+0x2f7>
    936d:	0f 1f 00             	nopl   (%rax)
    9370:	e8 9b af ff ff       	call   4310 <fwp_now_ns>
    9375:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9379:	0f 8d 99 02 00 00    	jge    9618 <fwp_main_thread+0x5f8>
    937f:	90                   	nop
    9380:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9384:	0f 85 ee fd ff ff    	jne    9178 <fwp_main_thread+0x158>
    938a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    938e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9392:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9396:	0f 85 ee fd ff ff    	jne    918a <fwp_main_thread+0x16a>
    939c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    93a0:	48 85 c9             	test   %rcx,%rcx
    93a3:	0f 84 e1 fd ff ff    	je     918a <fwp_main_thread+0x16a>
    93a9:	48 39 c8             	cmp    %rcx,%rax
    93ac:	48 89 ce             	mov    %rcx,%rsi
    93af:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    93b6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    93ba:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    93c1:	00 00 00 00 
    93c5:	48 0f 4e f0          	cmovle %rax,%rsi
    93c9:	48 85 c0             	test   %rax,%rax
    93cc:	48 89 c8             	mov    %rcx,%rax
    93cf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    93d6:	48 0f 45 c6          	cmovne %rsi,%rax
    93da:	48 85 d2             	test   %rdx,%rdx
    93dd:	74 07                	je     93e6 <fwp_main_thread+0x3c6>
    93df:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    93e6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    93ea:	e9 cd fd ff ff       	jmp    91bc <fwp_main_thread+0x19c>
    93ef:	90                   	nop
    93f0:	48 89 cb             	mov    %rcx,%rbx
    93f3:	e9 60 fd ff ff       	jmp    9158 <fwp_main_thread+0x138>
    93f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93ff:	00 
    9400:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9404:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    940b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9412:	00 00 00 00 
    9416:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    941d:	48 85 c0             	test   %rax,%rax
    9420:	0f 84 8a 08 00 00    	je     9cb0 <fwp_main_thread+0xc90>
    9426:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    942d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9431:	e9 ba fd ff ff       	jmp    91f0 <fwp_main_thread+0x1d0>
    9436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    943d:	00 00 00 
    9440:	48 89 01             	mov    %rax,(%rcx)
    9443:	e9 e2 fd ff ff       	jmp    922a <fwp_main_thread+0x20a>
    9448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    944f:	00 
    9450:	48 83 3d a0 7f 01 00 	cmpq   $0x0,0x17fa0(%rip)        # 213f8 <fwp_state_len>
    9457:	00 
    9458:	0f 84 d2 01 00 00    	je     9630 <fwp_main_thread+0x610>
    945e:	48 83 3d f2 62 01 00 	cmpq   $0x0,0x162f2(%rip)        # 1f758 <fwp_root>
    9465:	00 
    9466:	c7 05 30 5c 01 00 00 	movl   $0x0,0x15c30(%rip)        # 1f0a0 <fwp_exit_code>
    946d:	00 00 00 
    9470:	0f 85 8a 09 00 00    	jne    9e00 <fwp_main_thread+0xde0>
    9476:	e8 e5 d9 ff ff       	call   6e60 <fwp_free_zombie>
    947b:	48 83 3d c5 62 01 00 	cmpq   $0x0,0x162c5(%rip)        # 1f748 <fwp_ready_head>
    9482:	00 
    9483:	0f 85 c2 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9489:	48 83 3d a7 62 01 00 	cmpq   $0x0,0x162a7(%rip)        # 1f738 <fwp_timers>
    9490:	00 
    9491:	0f 85 b4 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9497:	8b 05 8f 5c 01 00    	mov    0x15c8f(%rip),%eax        # 1f12c <fwp_stack_pool_n>
    949d:	85 c0                	test   %eax,%eax
    949f:	74 3c                	je     94dd <fwp_main_thread+0x4bd>
    94a1:	83 e8 01             	sub    $0x1,%eax
    94a4:	4c 8d 25 95 5c 01 00 	lea    0x15c95(%rip),%r12        # 1f140 <fwp_stack_pool>
    94ab:	48 63 d8             	movslq %eax,%rbx
    94ae:	89 c0                	mov    %eax,%eax
    94b0:	48 89 da             	mov    %rbx,%rdx
    94b3:	48 29 c2             	sub    %rax,%rdx
    94b6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    94ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94c0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    94c4:	89 1d 62 5c 01 00    	mov    %ebx,0x15c62(%rip)        # 1f12c <fwp_stack_pool_n>
    94ca:	be 00 00 00 10       	mov    $0x10000000,%esi
    94cf:	48 83 eb 01          	sub    $0x1,%rbx
    94d3:	e8 08 a1 ff ff       	call   35e0 <munmap@plt>
    94d8:	48 39 dd             	cmp    %rbx,%rbp
    94db:	75 e3                	jne    94c0 <fwp_main_thread+0x4a0>
    94dd:	8b 3d 2d 5b 00 00    	mov    0x5b2d(%rip),%edi        # f010 <fwp_epfd>
    94e3:	85 ff                	test   %edi,%edi
    94e5:	78 05                	js     94ec <fwp_main_thread+0x4cc>
    94e7:	e8 e4 9f ff ff       	call   34d0 <close@plt>
    94ec:	4c 8b 25 4d 5e 01 00 	mov    0x15e4d(%rip),%r12        # 1f340 <fwp_nfdws>
    94f3:	48 8b 2d 4e 5e 01 00 	mov    0x15e4e(%rip),%rbp        # 1f348 <fwp_fdws>
    94fa:	31 db                	xor    %ebx,%ebx
    94fc:	c7 05 0a 5b 00 00 ff 	movl   $0xffffffff,0x5b0a(%rip)        # f010 <fwp_epfd>
    9503:	ff ff ff 
    9506:	4d 85 e4             	test   %r12,%r12
    9509:	74 32                	je     953d <fwp_main_thread+0x51d>
    950b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9510:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9515:	48 85 ff             	test   %rdi,%rdi
    9518:	74 1a                	je     9534 <fwp_main_thread+0x514>
    951a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    951e:	0f 85 27 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9524:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9529:	0f 85 1c a2 ff ff    	jne    374b <fwp_main_thread.cold>
    952f:	e8 7c c0 ff ff       	call   55b0 <fwp_mem_free>
    9534:	48 83 c3 01          	add    $0x1,%rbx
    9538:	49 39 dc             	cmp    %rbx,%r12
    953b:	75 d3                	jne    9510 <fwp_main_thread+0x4f0>
    953d:	48 89 ef             	mov    %rbp,%rdi
    9540:	e8 6b c0 ff ff       	call   55b0 <fwp_mem_free>
    9545:	48 8b 15 0c 62 01 00 	mov    0x1620c(%rip),%rdx        # 1f758 <fwp_root>
    954c:	48 c7 05 f1 5d 01 00 	movq   $0x0,0x15df1(%rip)        # 1f348 <fwp_fdws>
    9553:	00 00 00 00 
    9557:	48 c7 05 de 5d 01 00 	movq   $0x0,0x15dde(%rip)        # 1f340 <fwp_nfdws>
    955e:	00 00 00 00 
    9562:	48 85 d2             	test   %rdx,%rdx
    9565:	74 4e                	je     95b5 <fwp_main_thread+0x595>
    9567:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    956c:	0f 85 d9 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    9572:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9579:	00 
    957a:	0f 85 cb a1 ff ff    	jne    374b <fwp_main_thread.cold>
    9580:	48 83 3d 70 7e 01 00 	cmpq   $0x0,0x17e70(%rip)        # 213f8 <fwp_state_len>
    9587:	00 
    9588:	0f 85 bd a1 ff ff    	jne    374b <fwp_main_thread.cold>
    958e:	48 83 3d 52 7e 01 00 	cmpq   $0x0,0x17e52(%rip)        # 213e8 <fwp_state_owners>
    9595:	00 
    9596:	0f 85 af a1 ff ff    	jne    374b <fwp_main_thread.cold>
    959c:	b9 79 00 00 00       	mov    $0x79,%ecx
    95a1:	31 c0                	xor    %eax,%eax
    95a3:	48 8d 3d b6 5d 01 00 	lea    0x15db6(%rip),%rdi        # 1f360 <fwp_root_context>
    95aa:	f3 48 ab             	rep stos %rax,(%rdi)
    95ad:	48 89 d7             	mov    %rdx,%rdi
    95b0:	e8 fb bf ff ff       	call   55b0 <fwp_mem_free>
    95b5:	48 8b 3d 64 5a 00 00 	mov    0x5a64(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    95bc:	48 c7 05 99 61 01 00 	movq   $0x0,0x16199(%rip)        # 1f760 <fwp_cur>
    95c3:	00 00 00 00 
    95c7:	48 c7 05 86 61 01 00 	movq   $0x0,0x16186(%rip)        # 1f758 <fwp_root>
    95ce:	00 00 00 00 
    95d2:	e8 e9 9f ff ff       	call   35c0 <fflush@plt>
    95d7:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    95de:	00 
    95df:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    95e6:	00 00 
    95e8:	0f 85 01 08 00 00    	jne    9def <fwp_main_thread+0xdcf>
    95ee:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    95f5:	31 c0                	xor    %eax,%eax
    95f7:	5b                   	pop    %rbx
    95f8:	5d                   	pop    %rbp
    95f9:	41 5c                	pop    %r12
    95fb:	41 5d                	pop    %r13
    95fd:	41 5e                	pop    %r14
    95ff:	41 5f                	pop    %r15
    9601:	c3                   	ret
    9602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9608:	48 89 05 29 61 01 00 	mov    %rax,0x16129(%rip)        # 1f738 <fwp_timers>
    960f:	e9 67 fc ff ff       	jmp    927b <fwp_main_thread+0x25b>
    9614:	0f 1f 40 00          	nopl   0x0(%rax)
    9618:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    961c:	0f 85 5e fd ff ff    	jne    9380 <fwp_main_thread+0x360>
    9622:	48 89 ef             	mov    %rbp,%rdi
    9625:	e8 86 aa ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    962a:	e9 51 fd ff ff       	jmp    9380 <fwp_main_thread+0x360>
    962f:	90                   	nop
    9630:	31 db                	xor    %ebx,%ebx
    9632:	48 83 3d ae 7d 01 00 	cmpq   $0x0,0x17dae(%rip)        # 213e8 <fwp_state_owners>
    9639:	00 
    963a:	0f 85 76 fc ff ff    	jne    92b6 <fwp_main_thread+0x296>
    9640:	48 8b 3d b9 7d 01 00 	mov    0x17db9(%rip),%rdi        # 21400 <fwp_state>
    9647:	e8 64 bf ff ff       	call   55b0 <fwp_mem_free>
    964c:	48 c7 05 a9 7d 01 00 	movq   $0x0,0x17da9(%rip)        # 21400 <fwp_state>
    9653:	00 00 00 00 
    9657:	48 c7 05 8e 7d 01 00 	movq   $0x0,0x17d8e(%rip)        # 213f0 <fwp_state_cap>
    965e:	00 00 00 00 
    9662:	48 85 db             	test   %rbx,%rbx
    9665:	0f 84 1f 07 00 00    	je     9d8a <fwp_main_thread+0xd6a>
    966b:	48 39 1d e6 60 01 00 	cmp    %rbx,0x160e6(%rip)        # 1f758 <fwp_root>
    9672:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9679:	00 00 00 00 
    967d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9684:	00 00 00 00 
    9688:	c7 05 0e 5a 01 00 00 	movl   $0x0,0x15a0e(%rip)        # 1f0a0 <fwp_exit_code>
    968f:	00 00 00 
    9692:	0f 84 3e fc ff ff    	je     92d6 <fwp_main_thread+0x2b6>
    9698:	e9 ae a0 ff ff       	jmp    374b <fwp_main_thread.cold>
    969d:	0f 1f 00             	nopl   (%rax)
    96a0:	48 8d 3d 79 b3 ff ff 	lea    -0x4c87(%rip),%rdi        # 4a20 <fwp_heap_report>
    96a7:	e8 74 09 00 00       	call   a020 <atexit>
    96ac:	e9 b3 f9 ff ff       	jmp    9064 <fwp_main_thread+0x44>
    96b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96b8:	e8 73 b4 ff ff       	call   4b30 <fwp_heap_init>
    96bd:	e9 94 f9 ff ff       	jmp    9056 <fwp_main_thread+0x36>
    96c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96c8:	48 8d 05 c1 df ff ff 	lea    -0x203f(%rip),%rax        # 7690 <fwp_drop1>
    96cf:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    96d4:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    96db:	00 00 
    96dd:	4c 8d 3d 9c 60 01 00 	lea    0x1609c(%rip),%r15        # 1f780 <fwp_heap>
    96e4:	66 48 0f 6e d8       	movq   %rax,%xmm3
    96e9:	48 8b 05 28 7d 01 00 	mov    0x17d28(%rip),%rax        # 21418 <fwp_cleanups>
    96f0:	4c 89 25 21 7d 01 00 	mov    %r12,0x17d21(%rip)        # 21418 <fwp_cleanups>
    96f7:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    96fd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9701:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9706:	48 8d 05 c3 a4 ff ff 	lea    -0x5b3d(%rip),%rax        # 3bd0 <fwp_range_release>
    970d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9712:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9717:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    971c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9721:	eb 3e                	jmp    9761 <fwp_main_thread+0x741>
    9723:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9728:	80 f9 01             	cmp    $0x1,%cl
    972b:	75 29                	jne    9756 <fwp_main_thread+0x736>
    972d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9730:	0f b7 c0             	movzwl %ax,%eax
    9733:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9736:	48 0f af c1          	imul   %rcx,%rax
    973a:	48 c1 e8 20          	shr    $0x20,%rax
    973e:	48 39 d0             	cmp    %rdx,%rax
    9741:	73 13                	jae    9756 <fwp_main_thread+0x736>
    9743:	49 01 c5             	add    %rax,%r13
    9746:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    974b:	0f 84 9f 05 00 00    	je     9cf0 <fwp_main_thread+0xcd0>
    9751:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9756:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    975b:	49 83 ec 01          	sub    $0x1,%r12
    975f:	72 7f                	jb     97e0 <fwp_main_thread+0x7c0>
    9761:	48 89 de             	mov    %rbx,%rsi
    9764:	bf 01 00 00 00       	mov    $0x1,%edi
    9769:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9770:	00 
    9771:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9776:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    977d:	00 
    977e:	e8 4d c4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    9783:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    978a:	48 89 c5             	mov    %rax,%rbp
    978d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9794:	48 c1 e2 10          	shl    $0x10,%rdx
    9798:	48 39 d0             	cmp    %rdx,%rax
    979b:	73 b9                	jae    9756 <fwp_main_thread+0x736>
    979d:	48 89 c2             	mov    %rax,%rdx
    97a0:	48 c1 ea 10          	shr    $0x10,%rdx
    97a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97a8:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    97af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97b3:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    97b7:	4d 85 ed             	test   %r13,%r13
    97ba:	74 9a                	je     9756 <fwp_main_thread+0x736>
    97bc:	0f b6 0a             	movzbl (%rdx),%ecx
    97bf:	80 f9 02             	cmp    $0x2,%cl
    97c2:	0f 85 60 ff ff ff    	jne    9728 <fwp_main_thread+0x708>
    97c8:	66 85 c0             	test   %ax,%ax
    97cb:	0f 84 75 ff ff ff    	je     9746 <fwp_main_thread+0x726>
    97d1:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    97d6:	49 83 ec 01          	sub    $0x1,%r12
    97da:	73 85                	jae    9761 <fwp_main_thread+0x741>
    97dc:	0f 1f 40 00          	nopl   0x0(%rax)
    97e0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    97e5:	66 0f 6f 05 93 22 00 	movdqa 0x2293(%rip),%xmm0        # ba80 <msg.8+0xb0>
    97ec:	00 
    97ed:	48 89 de             	mov    %rbx,%rsi
    97f0:	bf 01 00 00 00       	mov    $0x1,%edi
    97f5:	48 89 05 1c 7c 01 00 	mov    %rax,0x17c1c(%rip)        # 21418 <fwp_cleanups>
    97fc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9803:	00 
    9804:	e8 c7 c3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    9809:	48 8b 15 48 73 01 00 	mov    0x17348(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    9810:	49 89 c4             	mov    %rax,%r12
    9813:	48 2b 05 16 73 01 00 	sub    0x17316(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    981a:	48 c1 e2 10          	shl    $0x10,%rdx
    981e:	48 39 d0             	cmp    %rdx,%rax
    9821:	73 55                	jae    9878 <fwp_main_thread+0x858>
    9823:	48 89 c2             	mov    %rax,%rdx
    9826:	48 c1 ea 10          	shr    $0x10,%rdx
    982a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    982e:	48 8b 15 43 73 01 00 	mov    0x17343(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    9835:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9839:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    983d:	48 85 db             	test   %rbx,%rbx
    9840:	74 36                	je     9878 <fwp_main_thread+0x858>
    9842:	0f b6 0a             	movzbl (%rdx),%ecx
    9845:	80 f9 02             	cmp    $0x2,%cl
    9848:	0f 84 92 04 00 00    	je     9ce0 <fwp_main_thread+0xcc0>
    984e:	80 f9 01             	cmp    $0x1,%cl
    9851:	75 25                	jne    9878 <fwp_main_thread+0x858>
    9853:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9856:	0f b7 c0             	movzwl %ax,%eax
    9859:	8b 52 1c             	mov    0x1c(%rdx),%edx
    985c:	48 0f af c1          	imul   %rcx,%rax
    9860:	48 c1 e8 20          	shr    $0x20,%rax
    9864:	48 39 d0             	cmp    %rdx,%rax
    9867:	73 0f                	jae    9878 <fwp_main_thread+0x858>
    9869:	48 01 c3             	add    %rax,%rbx
    986c:	80 3b ff             	cmpb   $0xff,(%rbx)
    986f:	0f 84 3b 05 00 00    	je     9db0 <fwp_main_thread+0xd90>
    9875:	c6 03 01             	movb   $0x1,(%rbx)
    9878:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    987d:	bf 01 00 00 00       	mov    $0x1,%edi
    9882:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9887:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    988e:	00 f0 3f 
    9891:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9896:	e8 35 c3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    989b:	48 8b 15 b6 72 01 00 	mov    0x172b6(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    98a2:	49 89 c4             	mov    %rax,%r12
    98a5:	48 2b 05 84 72 01 00 	sub    0x17284(%rip),%rax        # 20b30 <fwp_heap+0x13b0>
    98ac:	48 c1 e2 10          	shl    $0x10,%rdx
    98b0:	48 39 d0             	cmp    %rdx,%rax
    98b3:	73 55                	jae    990a <fwp_main_thread+0x8ea>
    98b5:	48 89 c2             	mov    %rax,%rdx
    98b8:	48 c1 ea 10          	shr    $0x10,%rdx
    98bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98c0:	48 8b 15 b1 72 01 00 	mov    0x172b1(%rip),%rdx        # 20b78 <fwp_heap+0x13f8>
    98c7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98cb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    98cf:	48 85 db             	test   %rbx,%rbx
    98d2:	74 36                	je     990a <fwp_main_thread+0x8ea>
    98d4:	0f b6 0a             	movzbl (%rdx),%ecx
    98d7:	80 f9 02             	cmp    $0x2,%cl
    98da:	0f 84 f0 03 00 00    	je     9cd0 <fwp_main_thread+0xcb0>
    98e0:	80 f9 01             	cmp    $0x1,%cl
    98e3:	75 25                	jne    990a <fwp_main_thread+0x8ea>
    98e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98e8:	0f b7 c0             	movzwl %ax,%eax
    98eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98ee:	48 0f af c1          	imul   %rcx,%rax
    98f2:	48 c1 e8 20          	shr    $0x20,%rax
    98f6:	48 39 d0             	cmp    %rdx,%rax
    98f9:	73 0f                	jae    990a <fwp_main_thread+0x8ea>
    98fb:	48 01 c3             	add    %rax,%rbx
    98fe:	80 3b ff             	cmpb   $0xff,(%rbx)
    9901:	0f 84 b6 04 00 00    	je     9dbd <fwp_main_thread+0xd9d>
    9907:	c6 03 01             	movb   $0x1,(%rbx)
    990a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    990f:	bf 01 00 00 00       	mov    $0x1,%edi
    9914:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9919:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9920:	33 f3 bf 
    9923:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9928:	e8 a3 c2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    992d:	48 8b 15 24 72 01 00 	mov    0x17224(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    9934:	48 8b 0d f5 71 01 00 	mov    0x171f5(%rip),%rcx        # 20b30 <fwp_heap+0x13b0>
    993b:	49 89 c4             	mov    %rax,%r12
    993e:	48 89 d6             	mov    %rdx,%rsi
    9941:	48 29 c8             	sub    %rcx,%rax
    9944:	48 c1 e6 10          	shl    $0x10,%rsi
    9948:	48 39 f0             	cmp    %rsi,%rax
    994b:	73 65                	jae    99b2 <fwp_main_thread+0x992>
    994d:	48 89 c6             	mov    %rax,%rsi
    9950:	48 c1 ee 10          	shr    $0x10,%rsi
    9954:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9958:	48 8b 35 19 72 01 00 	mov    0x17219(%rip),%rsi        # 20b78 <fwp_heap+0x13f8>
    995f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9963:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    9967:	48 85 db             	test   %rbx,%rbx
    996a:	74 46                	je     99b2 <fwp_main_thread+0x992>
    996c:	0f b6 3e             	movzbl (%rsi),%edi
    996f:	40 80 ff 02          	cmp    $0x2,%dil
    9973:	0f 84 47 03 00 00    	je     9cc0 <fwp_main_thread+0xca0>
    9979:	40 80 ff 01          	cmp    $0x1,%dil
    997d:	75 33                	jne    99b2 <fwp_main_thread+0x992>
    997f:	8b 7e 18             	mov    0x18(%rsi),%edi
    9982:	0f b7 c0             	movzwl %ax,%eax
    9985:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9988:	48 0f af c7          	imul   %rdi,%rax
    998c:	48 c1 e8 20          	shr    $0x20,%rax
    9990:	48 39 f0             	cmp    %rsi,%rax
    9993:	73 1d                	jae    99b2 <fwp_main_thread+0x992>
    9995:	48 01 c3             	add    %rax,%rbx
    9998:	80 3b ff             	cmpb   $0xff,(%rbx)
    999b:	0f 84 29 04 00 00    	je     9dca <fwp_main_thread+0xdaa>
    99a1:	c6 03 01             	movb   $0x1,(%rbx)
    99a4:	48 8b 0d 85 71 01 00 	mov    0x17185(%rip),%rcx        # 20b30 <fwp_heap+0x13b0>
    99ab:	48 8b 15 a6 71 01 00 	mov    0x171a6(%rip),%rdx        # 20b58 <fwp_heap+0x13d8>
    99b2:	49 89 ed             	mov    %rbp,%r13
    99b5:	e9 01 02 00 00       	jmp    9bbb <fwp_main_thread+0xb9b>
    99ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99c0:	80 f9 01             	cmp    $0x1,%cl
    99c3:	75 2d                	jne    99f2 <fwp_main_thread+0x9d2>
    99c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99c8:	0f b7 c0             	movzwl %ax,%eax
    99cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99ce:	48 0f af c1          	imul   %rcx,%rax
    99d2:	48 c1 e8 20          	shr    $0x20,%rax
    99d6:	48 39 d0             	cmp    %rdx,%rax
    99d9:	73 17                	jae    99f2 <fwp_main_thread+0x9d2>
    99db:	48 01 c7             	add    %rax,%rdi
    99de:	0f b6 07             	movzbl (%rdi),%eax
    99e1:	84 c0                	test   %al,%al
    99e3:	74 0d                	je     99f2 <fwp_main_thread+0x9d2>
    99e5:	3c fd                	cmp    $0xfd,%al
    99e7:	0f 87 93 03 00 00    	ja     9d80 <fwp_main_thread+0xd60>
    99ed:	83 c0 01             	add    $0x1,%eax
    99f0:	88 07                	mov    %al,(%rdi)
    99f2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    99f7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    99fb:	b9 01 00 00 00       	mov    $0x1,%ecx
    9a00:	4c 89 e6             	mov    %r12,%rsi
    9a03:	48 8d 15 96 51 00 00 	lea    0x5196(%rip),%rdx        # eba0 <d0>
    9a0a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    9a0f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9a16:	00 00 
    9a18:	e8 c3 e5 ff ff       	call   7fe0 <fwp_write>
    9a1d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9a22:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    9a27:	48 8d 05 00 16 00 00 	lea    0x1600(%rip),%rax        # b02e <_IO_stdin_used+0x2e>
    9a2e:	48 85 c9             	test   %rcx,%rcx
    9a31:	48 0f 44 c8          	cmove  %rax,%rcx
    9a35:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    9a39:	0f 87 a4 03 00 00    	ja     9de3 <fwp_main_thread+0xdc3>
    9a3f:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    9a43:	be 01 00 00 00       	mov    $0x1,%esi
    9a48:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9a4d:	e8 5e c0 ff ff       	call   5ab0 <fwp_heap_alloc>
    9a52:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9a57:	4c 89 f2             	mov    %r14,%rdx
    9a5a:	4c 89 30             	mov    %r14,(%rax)
    9a5d:	48 89 c3             	mov    %rax,%rbx
    9a60:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9a64:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    9a69:	e8 32 9b ff ff       	call   35a0 <memcpy@plt>
    9a6e:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    9a74:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    9a79:	e8 42 99 ff ff       	call   33c0 <free@plt>
    9a7e:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9a85:	48 89 d8             	mov    %rbx,%rax
    9a88:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9a8f:	48 c1 e2 10          	shl    $0x10,%rdx
    9a93:	48 39 d0             	cmp    %rdx,%rax
    9a96:	73 55                	jae    9aed <fwp_main_thread+0xacd>
    9a98:	48 89 c2             	mov    %rax,%rdx
    9a9b:	48 c1 ea 10          	shr    $0x10,%rdx
    9a9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9aa3:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9aaa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aae:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9ab2:	48 85 f6             	test   %rsi,%rsi
    9ab5:	74 36                	je     9aed <fwp_main_thread+0xacd>
    9ab7:	0f b6 0a             	movzbl (%rdx),%ecx
    9aba:	80 f9 02             	cmp    $0x2,%cl
    9abd:	0f 84 9d 01 00 00    	je     9c60 <fwp_main_thread+0xc40>
    9ac3:	80 f9 01             	cmp    $0x1,%cl
    9ac6:	75 25                	jne    9aed <fwp_main_thread+0xacd>
    9ac8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9acb:	0f b7 c0             	movzwl %ax,%eax
    9ace:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ad1:	48 0f af c1          	imul   %rcx,%rax
    9ad5:	48 c1 e8 20          	shr    $0x20,%rax
    9ad9:	48 39 d0             	cmp    %rdx,%rax
    9adc:	73 0f                	jae    9aed <fwp_main_thread+0xacd>
    9ade:	48 01 c6             	add    %rax,%rsi
    9ae1:	80 3e ff             	cmpb   $0xff,(%rsi)
    9ae4:	0f 84 96 01 00 00    	je     9c80 <fwp_main_thread+0xc60>
    9aea:	c6 06 01             	movb   $0x1,(%rsi)
    9aed:	4c 89 e7             	mov    %r12,%rdi
    9af0:	e8 ab d9 ff ff       	call   74a0 <fwp_drop0>
    9af5:	48 8b 13             	mov    (%rbx),%rdx
    9af8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9afd:	be 01 00 00 00       	mov    $0x1,%esi
    9b02:	48 8b 0d d7 78 01 00 	mov    0x178d7(%rip),%rcx        # 213e0 <fwp_prog_out>
    9b09:	e8 72 9b ff ff       	call   3680 <fwrite@plt>
    9b0e:	48 8b 35 cb 78 01 00 	mov    0x178cb(%rip),%rsi        # 213e0 <fwp_prog_out>
    9b15:	bf 0a 00 00 00       	mov    $0xa,%edi
    9b1a:	e8 c1 99 ff ff       	call   34e0 <fputc@plt>
    9b1f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9b26:	48 89 d8             	mov    %rbx,%rax
    9b29:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9b30:	48 c1 e2 10          	shl    $0x10,%rdx
    9b34:	48 39 d0             	cmp    %rdx,%rax
    9b37:	73 67                	jae    9ba0 <fwp_main_thread+0xb80>
    9b39:	48 89 c2             	mov    %rax,%rdx
    9b3c:	48 c1 ea 10          	shr    $0x10,%rdx
    9b40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b44:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9b4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b4f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9b53:	4d 85 f6             	test   %r14,%r14
    9b56:	74 48                	je     9ba0 <fwp_main_thread+0xb80>
    9b58:	0f b6 0a             	movzbl (%rdx),%ecx
    9b5b:	80 f9 02             	cmp    $0x2,%cl
    9b5e:	0f 84 ac 00 00 00    	je     9c10 <fwp_main_thread+0xbf0>
    9b64:	80 f9 01             	cmp    $0x1,%cl
    9b67:	75 37                	jne    9ba0 <fwp_main_thread+0xb80>
    9b69:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b6c:	0f b7 c0             	movzwl %ax,%eax
    9b6f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b72:	48 0f af c1          	imul   %rcx,%rax
    9b76:	48 c1 e8 20          	shr    $0x20,%rax
    9b7a:	48 39 d0             	cmp    %rdx,%rax
    9b7d:	73 21                	jae    9ba0 <fwp_main_thread+0xb80>
    9b7f:	49 01 c6             	add    %rax,%r14
    9b82:	41 0f b6 06          	movzbl (%r14),%eax
    9b86:	84 c0                	test   %al,%al
    9b88:	74 16                	je     9ba0 <fwp_main_thread+0xb80>
    9b8a:	3c 01                	cmp    $0x1,%al
    9b8c:	0f 84 0e 01 00 00    	je     9ca0 <fwp_main_thread+0xc80>
    9b92:	3c ff                	cmp    $0xff,%al
    9b94:	0f 84 66 01 00 00    	je     9d00 <fwp_main_thread+0xce0>
    9b9a:	83 e8 01             	sub    $0x1,%eax
    9b9d:	41 88 06             	mov    %al,(%r14)
    9ba0:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9ba4:	4d 85 ed             	test   %r13,%r13
    9ba7:	0f 84 83 00 00 00    	je     9c30 <fwp_main_thread+0xc10>
    9bad:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9bb4:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9bbb:	4c 89 e0             	mov    %r12,%rax
    9bbe:	48 c1 e2 10          	shl    $0x10,%rdx
    9bc2:	48 29 c8             	sub    %rcx,%rax
    9bc5:	48 39 d0             	cmp    %rdx,%rax
    9bc8:	0f 83 24 fe ff ff    	jae    99f2 <fwp_main_thread+0x9d2>
    9bce:	48 89 c2             	mov    %rax,%rdx
    9bd1:	48 c1 ea 10          	shr    $0x10,%rdx
    9bd5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bd9:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9be0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9be4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9be8:	48 85 ff             	test   %rdi,%rdi
    9beb:	0f 84 01 fe ff ff    	je     99f2 <fwp_main_thread+0x9d2>
    9bf1:	0f b6 0a             	movzbl (%rdx),%ecx
    9bf4:	80 f9 02             	cmp    $0x2,%cl
    9bf7:	0f 85 c3 fd ff ff    	jne    99c0 <fwp_main_thread+0x9a0>
    9bfd:	66 85 c0             	test   %ax,%ax
    9c00:	0f 85 ec fd ff ff    	jne    99f2 <fwp_main_thread+0x9d2>
    9c06:	e9 d3 fd ff ff       	jmp    99de <fwp_main_thread+0x9be>
    9c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c10:	66 85 c0             	test   %ax,%ax
    9c13:	0f 84 69 ff ff ff    	je     9b82 <fwp_main_thread+0xb62>
    9c19:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9c1d:	4d 85 ed             	test   %r13,%r13
    9c20:	75 8b                	jne    9bad <fwp_main_thread+0xb8d>
    9c22:	0f 1f 00             	nopl   (%rax)
    9c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c2c:	00 00 00 00 
    9c30:	4c 89 e7             	mov    %r12,%rdi
    9c33:	e8 68 d8 ff ff       	call   74a0 <fwp_drop0>
    9c38:	48 89 ef             	mov    %rbp,%rdi
    9c3b:	e8 60 d8 ff ff       	call   74a0 <fwp_drop0>
    9c40:	48 c7 05 35 54 00 00 	movq   $0x0,0x5435(%rip)        # f080 <v.6>
    9c47:	00 00 00 00 
    9c4b:	c7 05 33 54 00 00 01 	movl   $0x1,0x5433(%rip)        # f088 <st.7>
    9c52:	00 00 00 
    9c55:	e9 e2 f4 ff ff       	jmp    913c <fwp_main_thread+0x11c>
    9c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c60:	66 85 c0             	test   %ax,%ax
    9c63:	0f 85 84 fe ff ff    	jne    9aed <fwp_main_thread+0xacd>
    9c69:	80 3e ff             	cmpb   $0xff,(%rsi)
    9c6c:	0f 85 78 fe ff ff    	jne    9aea <fwp_main_thread+0xaca>
    9c72:	0f 1f 00             	nopl   (%rax)
    9c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c7c:	00 00 00 00 
    9c80:	48 89 f7             	mov    %rsi,%rdi
    9c83:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    9c88:	e8 e3 b6 ff ff       	call   5370 <fwp_rc_forget_slot>
    9c8d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9c92:	e9 53 fe ff ff       	jmp    9aea <fwp_main_thread+0xaca>
    9c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c9e:	00 00 
    9ca0:	48 89 df             	mov    %rbx,%rdi
    9ca3:	e8 08 b9 ff ff       	call   55b0 <fwp_mem_free>
    9ca8:	e9 f3 fe ff ff       	jmp    9ba0 <fwp_main_thread+0xb80>
    9cad:	0f 1f 00             	nopl   (%rax)
    9cb0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9cb4:	e9 37 f5 ff ff       	jmp    91f0 <fwp_main_thread+0x1d0>
    9cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9cc0:	66 85 c0             	test   %ax,%ax
    9cc3:	0f 85 e9 fc ff ff    	jne    99b2 <fwp_main_thread+0x992>
    9cc9:	e9 ca fc ff ff       	jmp    9998 <fwp_main_thread+0x978>
    9cce:	66 90                	xchg   %ax,%ax
    9cd0:	66 85 c0             	test   %ax,%ax
    9cd3:	0f 85 31 fc ff ff    	jne    990a <fwp_main_thread+0x8ea>
    9cd9:	e9 20 fc ff ff       	jmp    98fe <fwp_main_thread+0x8de>
    9cde:	66 90                	xchg   %ax,%ax
    9ce0:	66 85 c0             	test   %ax,%ax
    9ce3:	0f 85 8f fb ff ff    	jne    9878 <fwp_main_thread+0x858>
    9ce9:	e9 7e fb ff ff       	jmp    986c <fwp_main_thread+0x84c>
    9cee:	66 90                	xchg   %ax,%ax
    9cf0:	4c 89 ef             	mov    %r13,%rdi
    9cf3:	e8 78 b6 ff ff       	call   5370 <fwp_rc_forget_slot>
    9cf8:	e9 54 fa ff ff       	jmp    9751 <fwp_main_thread+0x731>
    9cfd:	0f 1f 00             	nopl   (%rax)
    9d00:	4c 89 f0             	mov    %r14,%rax
    9d03:	48 c1 e8 11          	shr    $0x11,%rax
    9d07:	4c 31 f0             	xor    %r14,%rax
    9d0a:	48 89 c2             	mov    %rax,%rdx
    9d0d:	48 c1 ea 09          	shr    $0x9,%rdx
    9d11:	48 31 d0             	xor    %rdx,%rax
    9d14:	0f b6 d0             	movzbl %al,%edx
    9d17:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    9d1e:	00 
    9d1f:	48 85 c0             	test   %rax,%rax
    9d22:	75 29                	jne    9d4d <fwp_main_thread+0xd2d>
    9d24:	e9 cb 00 00 00       	jmp    9df4 <fwp_main_thread+0xdd4>
    9d29:	90                   	nop
    9d2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d31:	00 00 00 00 
    9d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d3c:	00 00 00 00 
    9d40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9d44:	48 85 c0             	test   %rax,%rax
    9d47:	0f 84 a7 00 00 00    	je     9df4 <fwp_main_thread+0xdd4>
    9d4d:	48 89 c2             	mov    %rax,%rdx
    9d50:	4c 3b 30             	cmp    (%rax),%r14
    9d53:	75 eb                	jne    9d40 <fwp_main_thread+0xd20>
    9d55:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9d59:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    9d5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9d61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9d68:	0f 85 32 fe ff ff    	jne    9ba0 <fwp_main_thread+0xb80>
    9d6e:	4c 89 f7             	mov    %r14,%rdi
    9d71:	e8 fa b5 ff ff       	call   5370 <fwp_rc_forget_slot>
    9d76:	41 c6 06 fe          	movb   $0xfe,(%r14)
    9d7a:	e9 21 fe ff ff       	jmp    9ba0 <fwp_main_thread+0xb80>
    9d7f:	90                   	nop
    9d80:	e8 cb b4 ff ff       	call   5250 <fwp_rc_wide_dup>
    9d85:	e9 68 fc ff ff       	jmp    99f2 <fwp_main_thread+0x9d2>
    9d8a:	48 83 3d c6 59 01 00 	cmpq   $0x0,0x159c6(%rip)        # 1f758 <fwp_root>
    9d91:	00 
    9d92:	c7 05 04 53 01 00 00 	movl   $0x0,0x15304(%rip)        # 1f0a0 <fwp_exit_code>
    9d99:	00 00 00 
    9d9c:	0f 84 d4 f6 ff ff    	je     9476 <fwp_main_thread+0x456>
    9da2:	e9 a4 99 ff ff       	jmp    374b <fwp_main_thread.cold>
    9da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dae:	00 00 
    9db0:	48 89 df             	mov    %rbx,%rdi
    9db3:	e8 b8 b5 ff ff       	call   5370 <fwp_rc_forget_slot>
    9db8:	e9 b8 fa ff ff       	jmp    9875 <fwp_main_thread+0x855>
    9dbd:	48 89 df             	mov    %rbx,%rdi
    9dc0:	e8 ab b5 ff ff       	call   5370 <fwp_rc_forget_slot>
    9dc5:	e9 3d fb ff ff       	jmp    9907 <fwp_main_thread+0x8e7>
    9dca:	48 89 df             	mov    %rbx,%rdi
    9dcd:	e8 9e b5 ff ff       	call   5370 <fwp_rc_forget_slot>
    9dd2:	e9 ca fb ff ff       	jmp    99a1 <fwp_main_thread+0x981>
    9dd7:	48 8d 3d 6a 1a 00 00 	lea    0x1a6a(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    9dde:	e8 bd a3 ff ff       	call   41a0 <fwp_trap>
    9de3:	48 8d 3d d4 13 00 00 	lea    0x13d4(%rip),%rdi        # b1be <_IO_stdin_used+0x1be>
    9dea:	e8 b1 a3 ff ff       	call   41a0 <fwp_trap>
    9def:	e8 6c 96 ff ff       	call   3460 <__stack_chk_fail@plt>
    9df4:	48 8d 3d 7d 19 00 00 	lea    0x197d(%rip),%rdi        # b778 <_IO_stdin_used+0x778>
    9dfb:	e8 a0 a3 ff ff       	call   41a0 <fwp_trap>
    9e00:	e9 46 99 ff ff       	jmp    374b <fwp_main_thread.cold>
    9e05:	e9 41 99 ff ff       	jmp    374b <fwp_main_thread.cold>
    9e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009e10 <__divmodti4>:
    9e10:	f3 0f 1e fa          	endbr64
    9e14:	55                   	push   %rbp
    9e15:	49 89 f1             	mov    %rsi,%r9
    9e18:	49 89 d2             	mov    %rdx,%r10
    9e1b:	48 89 fe             	mov    %rdi,%rsi
    9e1e:	49 89 cb             	mov    %rcx,%r11
    9e21:	48 89 e5             	mov    %rsp,%rbp
    9e24:	41 57                	push   %r15
    9e26:	41 56                	push   %r14
    9e28:	41 55                	push   %r13
    9e2a:	41 54                	push   %r12
    9e2c:	53                   	push   %rbx
    9e2d:	4c 89 c3             	mov    %r8,%rbx
    9e30:	45 31 c0             	xor    %r8d,%r8d
    9e33:	4d 85 c9             	test   %r9,%r9
    9e36:	79 12                	jns    9e4a <__divmodti4+0x3a>
    9e38:	31 ff                	xor    %edi,%edi
    9e3a:	48 f7 de             	neg    %rsi
    9e3d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    9e44:	4c 19 cf             	sbb    %r9,%rdi
    9e47:	49 89 f9             	mov    %rdi,%r9
    9e4a:	4c 89 d8             	mov    %r11,%rax
    9e4d:	4d 85 db             	test   %r11,%r11
    9e50:	0f 88 1a 01 00 00    	js     9f70 <__divmodti4+0x160>
    9e56:	4c 89 d9             	mov    %r11,%rcx
    9e59:	49 89 f3             	mov    %rsi,%r11
    9e5c:	75 62                	jne    9ec0 <__divmodti4+0xb0>
    9e5e:	4d 89 c4             	mov    %r8,%r12
    9e61:	4d 39 d1             	cmp    %r10,%r9
    9e64:	0f 83 46 01 00 00    	jae    9fb0 <__divmodti4+0x1a0>
    9e6a:	4c 89 d8             	mov    %r11,%rax
    9e6d:	4c 89 ca             	mov    %r9,%rdx
    9e70:	49 f7 f2             	div    %r10
    9e73:	49 89 c3             	mov    %rax,%r11
    9e76:	31 c0                	xor    %eax,%eax
    9e78:	48 89 d6             	mov    %rdx,%rsi
    9e7b:	31 ff                	xor    %edi,%edi
    9e7d:	4c 89 d9             	mov    %r11,%rcx
    9e80:	48 89 c2             	mov    %rax,%rdx
    9e83:	48 89 c8             	mov    %rcx,%rax
    9e86:	4d 85 e4             	test   %r12,%r12
    9e89:	74 0a                	je     9e95 <__divmodti4+0x85>
    9e8b:	48 f7 d8             	neg    %rax
    9e8e:	48 83 d2 00          	adc    $0x0,%rdx
    9e92:	48 f7 da             	neg    %rdx
    9e95:	4d 85 c0             	test   %r8,%r8
    9e98:	74 0a                	je     9ea4 <__divmodti4+0x94>
    9e9a:	48 f7 de             	neg    %rsi
    9e9d:	48 83 d7 00          	adc    $0x0,%rdi
    9ea1:	48 f7 df             	neg    %rdi
    9ea4:	48 89 33             	mov    %rsi,(%rbx)
    9ea7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    9eab:	5b                   	pop    %rbx
    9eac:	41 5c                	pop    %r12
    9eae:	41 5d                	pop    %r13
    9eb0:	41 5e                	pop    %r14
    9eb2:	41 5f                	pop    %r15
    9eb4:	5d                   	pop    %rbp
    9eb5:	c3                   	ret
    9eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9ebd:	00 00 00 
    9ec0:	4d 89 c4             	mov    %r8,%r12
    9ec3:	49 39 c1             	cmp    %rax,%r9
    9ec6:	0f 82 ce 00 00 00    	jb     9f9a <__divmodti4+0x18a>
    9ecc:	31 ff                	xor    %edi,%edi
    9ece:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    9ed3:	48 63 c7             	movslq %edi,%rax
    9ed6:	be 40 00 00 00       	mov    $0x40,%esi
    9edb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    9ee0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    9ee5:	48 29 c6             	sub    %rax,%rsi
    9ee8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    9eed:	48 09 c8             	or     %rcx,%rax
    9ef0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    9ef5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    9efa:	49 89 c6             	mov    %rax,%r14
    9efd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    9f01:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    9f06:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    9f0b:	49 09 c1             	or     %rax,%r9
    9f0e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    9f12:	4c 89 c8             	mov    %r9,%rax
    9f15:	49 f7 f6             	div    %r14
    9f18:	48 89 d1             	mov    %rdx,%rcx
    9f1b:	49 89 c3             	mov    %rax,%r11
    9f1e:	49 89 c1             	mov    %rax,%r9
    9f21:	49 f7 e2             	mul    %r10
    9f24:	49 89 c6             	mov    %rax,%r14
    9f27:	49 89 d2             	mov    %rdx,%r10
    9f2a:	48 39 d1             	cmp    %rdx,%rcx
    9f2d:	72 07                	jb     9f36 <__divmodti4+0x126>
    9f2f:	75 17                	jne    9f48 <__divmodti4+0x138>
    9f31:	49 39 c7             	cmp    %rax,%r15
    9f34:	73 12                	jae    9f48 <__divmodti4+0x138>
    9f36:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    9f3a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    9f3e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    9f42:	49 89 d2             	mov    %rdx,%r10
    9f45:	49 89 c6             	mov    %rax,%r14
    9f48:	4c 89 f8             	mov    %r15,%rax
    9f4b:	4c 29 f0             	sub    %r14,%rax
    9f4e:	4c 19 d1             	sbb    %r10,%rcx
    9f51:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    9f56:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    9f5b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    9f60:	48 09 c6             	or     %rax,%rsi
    9f63:	48 89 cf             	mov    %rcx,%rdi
    9f66:	31 c0                	xor    %eax,%eax
    9f68:	4c 89 c9             	mov    %r9,%rcx
    9f6b:	e9 10 ff ff ff       	jmp    9e80 <__divmodti4+0x70>
    9f70:	4c 89 d0             	mov    %r10,%rax
    9f73:	4c 89 da             	mov    %r11,%rdx
    9f76:	4d 89 c4             	mov    %r8,%r12
    9f79:	49 89 f3             	mov    %rsi,%r11
    9f7c:	48 f7 d8             	neg    %rax
    9f7f:	49 f7 d4             	not    %r12
    9f82:	48 83 d2 00          	adc    $0x0,%rdx
    9f86:	49 89 c2             	mov    %rax,%r10
    9f89:	48 f7 da             	neg    %rdx
    9f8c:	48 89 d1             	mov    %rdx,%rcx
    9f8f:	0f 84 cc fe ff ff    	je     9e61 <__divmodti4+0x51>
    9f95:	49 39 d1             	cmp    %rdx,%r9
    9f98:	73 46                	jae    9fe0 <__divmodti4+0x1d0>
    9f9a:	4c 89 cf             	mov    %r9,%rdi
    9f9d:	31 c0                	xor    %eax,%eax
    9f9f:	31 c9                	xor    %ecx,%ecx
    9fa1:	e9 da fe ff ff       	jmp    9e80 <__divmodti4+0x70>
    9fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fad:	00 00 00 
    9fb0:	4d 85 d2             	test   %r10,%r10
    9fb3:	75 0d                	jne    9fc2 <__divmodti4+0x1b2>
    9fb5:	b8 01 00 00 00       	mov    $0x1,%eax
    9fba:	31 d2                	xor    %edx,%edx
    9fbc:	49 f7 f2             	div    %r10
    9fbf:	49 89 c2             	mov    %rax,%r10
    9fc2:	4c 89 c8             	mov    %r9,%rax
    9fc5:	31 d2                	xor    %edx,%edx
    9fc7:	49 f7 f2             	div    %r10
    9fca:	49 89 c1             	mov    %rax,%r9
    9fcd:	4c 89 d8             	mov    %r11,%rax
    9fd0:	49 f7 f2             	div    %r10
    9fd3:	49 89 c3             	mov    %rax,%r11
    9fd6:	4c 89 c8             	mov    %r9,%rax
    9fd9:	e9 9a fe ff ff       	jmp    9e78 <__divmodti4+0x68>
    9fde:	66 90                	xchg   %ax,%ax
    9fe0:	45 31 f6             	xor    %r14d,%r14d
    9fe3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    9fe8:	44 89 f7             	mov    %r14d,%edi
    9feb:	45 85 f6             	test   %r14d,%r14d
    9fee:	0f 85 df fe ff ff    	jne    9ed3 <__divmodti4+0xc3>
    9ff4:	4c 39 ca             	cmp    %r9,%rdx
    9ff7:	72 17                	jb     a010 <__divmodti4+0x200>
    9ff9:	31 c9                	xor    %ecx,%ecx
    9ffb:	48 39 c6             	cmp    %rax,%rsi
    9ffe:	73 10                	jae    a010 <__divmodti4+0x200>
    a000:	4c 89 cf             	mov    %r9,%rdi
    a003:	31 c0                	xor    %eax,%eax
    a005:	e9 76 fe ff ff       	jmp    9e80 <__divmodti4+0x70>
    a00a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a010:	4c 89 de             	mov    %r11,%rsi
    a013:	b9 01 00 00 00       	mov    $0x1,%ecx
    a018:	48 29 c6             	sub    %rax,%rsi
    a01b:	49 19 d1             	sbb    %rdx,%r9
    a01e:	eb e0                	jmp    a000 <__divmodti4+0x1f0>

000000000000a020 <atexit>:
    a020:	f3 0f 1e fa          	endbr64
    a024:	48 8b 15 dd 4f 00 00 	mov    0x4fdd(%rip),%rdx        # f008 <__dso_handle>
    a02b:	31 f6                	xor    %esi,%esi
    a02d:	e9 2e 96 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a034 <_fini>:
    a034:	f3 0f 1e fa          	endbr64
    a038:	48 83 ec 08          	sub    $0x8,%rsp
    a03c:	48 83 c4 08          	add    $0x8,%rsp
    a040:	c3                   	ret
