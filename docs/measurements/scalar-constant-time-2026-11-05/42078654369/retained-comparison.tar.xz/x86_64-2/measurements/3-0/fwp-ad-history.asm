
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 cf 00 00 	mov    0xcfc9(%rip),%rax        # ffd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 cd 00 00    	push   0xcde2(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 cd 00 00    	jmp    *0xcde4(%rip)        # fe10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e cc 00 00    	jmp    *0xcc4e(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # feb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # feb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ffa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ffa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 89 00 00 	lea    0x897a(%rip),%r9        # c091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 89 00 00 	lea    0x8977(%rip),%r8        # c095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 32 ec 01 00 	mov    %rax,0x1ec32(%rip)        # 223b8 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c ec 01 00 	mov    %rax,0x1ec2c(%rip)        # 223c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 8a 00 00 	lea    0x8a59(%rip),%rdi        # c1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 9f 71 00 00 	lea    0x719f(%rip),%rdx        # aa00 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 89 00 00 	lea    0x8909(%rip),%rdi        # c202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e 90 00 00 	lea    0x908e(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 90 00 00 	lea    0x9048(%rip),%rdi        # c970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c 90 00 00 	lea    0x900c(%rip),%rdi        # c940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 8f 00 00 	lea    0x8fd8(%rip),%rdi        # c918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 c6 00 00    	call   *0xc653(%rip)        # ffc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 c6 00 00 	mov    0xc636(%rip),%rax        # ffd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 c6 00 00 	mov    0xc605(%rip),%rax        # ffe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 c5 00 00 	cmpq   $0x0,0xc5e2(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 e7 01 00 	mov    0x1e749(%rip),%rdi        # 223c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ca 01 00 	mov    0x1ca41(%rip),%rax        # 20740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 c3 01 00 	mov    0x1c381(%rip),%rax        # 20100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d c3 01 00 	sub    0x1c36d(%rip),%rax        # 200f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 8c 00 00 	lea    0x8cbd(%rip),%rsi        # ca80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b dd 01 00 	mov    0x1dd5b(%rip),%rax        # 21b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 dd 01 00 	lea    0x1dd54(%rip),%r8        # 21b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 dd 01 00 	mov    0x1dd35(%rip),%rbx        # 21b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 dd 01 00 	mov    0x1dd45(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 dc 01 00 	mov    0x1dce1(%rip),%rdi        # 21b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a dd 01 00 	sub    %rsi,0x1dd2a(%rip)        # 21b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba dc 01 00 	mov    0x1dcba(%rip),%rax        # 21b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 dc 01 00 	add    0x1dc70(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e dc 01 00 	mov    0x1dc7e(%rip),%rsi        # 21b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c dc 01 00 	mov    0x1dc8c(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b dc 01 00 	mov    %r12,0x1dc3b(%rip)        # 21b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 dc 01 00 	mov    %rbp,0x1dc29(%rip)        # 21b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e dc 01 00 	cmp    %rdi,0x1dc0e(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 dc 01 00 	mov    %rdi,0x1dc05(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 dc 01 00 	sub    %rdi,0x1dc49(%rip)        # 21b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 db 01 00 	mov    0x1dbf1(%rip),%rax        # 21b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea db 01 00 	lea    0x1dbea(%rip),%r8        # 21b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd bf 00 00 	mov    0xbffd(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 7f 00 00 	lea    0x7fb4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 c6 01 00 	cmp    0x1c689(%rip),%rdi        # 20740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f c6 01 00 	mov    0x1c64f(%rip),%rax        # 20720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d c6 01 00 	mov    %rdi,0x1c62d(%rip)        # 20720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 c6 01 00 	mov    %rdi,0x1c609(%rip)        # 20728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 80 00 00 	lea    0x8005(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 7e 00 00 	lea    0x7ea7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 be 00 00 	mov    0xbe78(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 7e 00 00 	lea    0x7e51(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 be 00 00 	mov    0xbe60(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 bd 00 00 	mov    0xbd71(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 7d 00 00 	lea    0x7d28(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 7d 00 00 	lea    0x7d32(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 7c 00 00 	lea    0x7cba(%rip),%rdi        # c049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 82 00 00 	lea    0x8268(%rip),%rdi        # c608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # caa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a df 01 00 	add    0x1df9a(%rip),%rax        # 223b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 81 00 00 	lea    0x81c4(%rip),%rdi        # c638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 bc 01 00 	cmp    %rax,0x1bc55(%rip)        # 200e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 bc 01 00 	add    0x1bc50(%rip),%rax        # 200f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad 81 00 00 	lea    0x81ad(%rip),%rdi        # c668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 7b 00 00 	lea    0x7b92(%rip),%r8        # c065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 79 00 00 	lea    0x79e7(%rip),%r8        # c074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 78 00 00 	lea    0x7874(%rip),%r8        # c06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 76 00 00 	lea    0x764c(%rip),%rdi        # c079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 77 00 00 	lea    0x7760(%rip),%rsi        # c1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 d0 01 00 	mov    0x1d065(%rip),%r9        # 21b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be d0 01 00 	mov    0x1d0be(%rip),%r8        # 21b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 7b 00 00 	lea    0x7be7(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 d0 01 00 	mov    0x1d0a6(%rip),%rcx        # 21b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 d0 01 	movsd  0x1d0b4(%rip),%xmm1        # 21ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 d0 01 	movsd  0x1d0a4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 b5 00 00 	mov    0xb545(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 7f 00 	movdqa 0x7f78(%rip),%xmm0        # cab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f cb 01 00 	lea    0x1cb5f(%rip),%rax        # 216a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 7f 00 	movdqa 0x7fa1(%rip),%xmm2        # caf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 cb 01 00 	movaps %xmm0,0x1cb05(%rip)        # 21660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d 7f 00 	movdqa 0x7f5d(%rip),%xmm0        # cac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 cf 01 00 01 	movl   $0x1,0x1cf93(%rip)        # 21b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ca 01 00 	movaps %xmm0,0x1caf3(%rip)        # 21670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b 7f 00 	movdqa 0x7f4b(%rip),%xmm0        # cad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 ca 01 00 	movaps %xmm0,0x1caf4(%rip)        # 21680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c 7f 00 	movdqa 0x7f4c(%rip),%xmm0        # cae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 ca 01 00 	movaps %xmm0,0x1caf5(%rip)        # 21690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 bb 01 00 	lea    0x1bb75(%rip),%r8        # 20760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ce 01 00 	mov    %rax,0x1ce90(%rip)        # 21b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ce 01 00 	mov    %r12,0x1ce6e(%rip)        # 21b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ce 01 00 	mov    %rax,0x1ce57(%rip)        # 21b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ce 01 00 	mov    %rbx,0x1ce70(%rip)        # 21b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ce 01 00 	mov    %rsi,0x1ce99(%rip)        # 21b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 73 00 00 	lea    0x73d6(%rip),%rdi        # c0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ce 01 00 	mov    %rax,0x1ce78(%rip)        # 21b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc cd 01 00    	mov    %eax,0x1cdfc(%rip)        # 21b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec b9 01 00 	mov    0x1b9ec(%rip),%r8        # 20720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c b9 01 00 	mov    %rbx,0x1b91c(%rip)        # 20728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 b9 01 00 	mov    %r8,0x1b908(%rip)        # 20720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 72 00 00 	lea    0x7239(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd b1 01 00 	lea    0x1b1dd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 b1 01 00 	movaps %xmm0,0x1b1c5(%rip)        # 200a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 b1 01 00 	mov    %rax,0x1b1a1(%rip)        # 20088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 b1 01 00 	movaps %xmm0,0x1b1c2(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 b1 01 00 	movaps %xmm0,0x1b1c6(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 b1 01 00 	mov    %rdx,0x1b1c7(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 71 00 00 	lea    0x7190(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 b7 01 00 	mov    0x1b797(%rip),%rbx        # 20718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca af 00 00 	mov    0xafca(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 76 00 00 	lea    0x76c3(%rip),%rdi        # c740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d b6 01 00 	mov    0x1b66d(%rip),%rax        # 20720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 b6 01 00 	mov    %rdx,0x1b647(%rip)        # 20720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 b5 01 00 	mov    0x1b594(%rip),%rbx        # 20718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 b5 01 00 	mov    %rbx,0x1b551(%rip)        # 20718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 b5 01 00 	mov    %rdx,0x1b551(%rip)        # 20728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 b5 01 00 	lea    0x1b566(%rip),%rsi        # 20760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 d0 01 00 	addq   $0x1,0x1d0e5(%rip)        # 223a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 74 00 00 	lea    0x7497(%rip),%rdi        # c770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 74 00 00 	lea    0x74a8(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 6d 00 00 	lea    0x6dd4(%rip),%rdi        # c0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e b4 01 00 	lea    0x1b41e(%rip),%rcx        # 20760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f d0 01 00 	subq   $0x1,0x1d01f(%rip)        # 223a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 74 00 00 	lea    0x7403(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 d0 01 00 	cmpq   $0x0,0x1d000(%rip)        # 223a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 cf 01 00 	sub    %rax,0x1cf55(%rip)        # 223b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 cf 01 00 	add    %r12,0x1cf33(%rip)        # 223b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c b2 01 00 	lea    0x1b28c(%rip),%rax        # 20760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 c5 01 00 	add    0x1c5e3(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 c5 01 00 	mov    0x1c5b0(%rip),%rsi        # 21b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 c5 01 00 	mov    0x1c5d1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 c5 01 00 	add    0x1c5c5(%rip),%r8        # 21b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d c5 01 	addsd  0x1c58d(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 b1 01 00 	lea    0x1b142(%rip),%rax        # 20760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c c5 01 00 	sub    %rdi,0x1c54c(%rip)        # 21b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 c5 01 	movsd  %xmm0,0x1c564(%rip)        # 21ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e c5 01 00 	sub    %rdx,0x1c51e(%rip)        # 21b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 c5 01 	addsd  0x1c524(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 c5 01 	movsd  %xmm0,0x1c518(%rip)        # 21ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af c4 01 00 	mov    0x1c4af(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 c4 01 00 	add    %rcx,0x1c4a9(%rip)        # 21b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 c4 01 00 	cmp    0x1c462(%rip),%r9        # 21b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 c4 01 00 	mov    %r9,0x1c459(%rip)        # 21b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a c4 01 00 	cmp    0x1c44a(%rip),%r9        # 21b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d c4 01 00 	mov    %r9,0x1c43d(%rip)        # 21b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 c3 01 00 	add    0x1c353(%rip),%rdi        # 21b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 af 01 00 	lea    0x1af30(%rip),%r15        # 20760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 c2 01 00 	add    0x1c2a0(%rip),%r12        # 21b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 c2 01 00 	add    0x1c2f9(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 c2 01 00 	cmp    %rax,0x1c2f8(%rip)        # 21b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 c2 01 00 	mov    %rax,0x1c2e9(%rip)        # 21b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 c2 01 00 	mov    %rax,0x1c2e8(%rip)        # 21b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 c2 01 	addsd  0x1c2e4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc c2 01 	movsd  %xmm0,0x1c2dc(%rip)        # 21b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 c2 01 00    	mov    0x1c223(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ae 01 00 	lea    0x1ae5f(%rip),%rdi        # 20760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 c2 01 00 	add    0x1c218(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 c2 01 00 	cmp    %rax,0x1c213(%rip)        # 21b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 c2 01 00 	mov    %rax,0x1c204(%rip)        # 21b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 c2 01 00 	mov    %rax,0x1c203(%rip)        # 21b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff c1 01 	addsd  0x1c1ff(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 c1 01 	movsd  %xmm0,0x1c1f7(%rip)        # 21b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae c0 01 00    	mov    0x1c0ae(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 ac 01 00 	lea    0x1ace5(%rip),%rax        # 20760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b c0 01 00 	add    0x1c09b(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a c0 01 00 	cmp    %rax,0x1c09a(%rip)        # 21b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b c0 01 00 	mov    %rax,0x1c08b(%rip)        # 21b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a c0 01 00 	mov    %rax,0x1c08a(%rip)        # 21b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 c0 01 	addsd  0x1c086(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e c0 01 	movsd  %xmm0,0x1c07e(%rip)        # 21b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 0c c8 01 00 	add    0x1c80c(%rip),%r9        # 223b8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 38          	sub    $0x38,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 a9 01 00 00    	js     5f80 <fwp_p_ad_push+0x1d0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	48 09 d0             	or     %rdx,%rax
    5de1:	0f 89 79 01 00 00    	jns    5f60 <fwp_p_ad_push+0x1b0>
    5de7:	48 89 f8             	mov    %rdi,%rax
    5dea:	48 c1 f8 20          	sar    $0x20,%rax
    5dee:	48 85 ff             	test   %rdi,%rdi
    5df1:	79 24                	jns    5e17 <fwp_p_ad_push+0x67>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	48 89 d0             	mov    %rdx,%rax
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	48 c1 f8 20          	sar    $0x20,%rax
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 89 c7             	mov    %rax,%rdi
    5e1a:	e8 61 e6 ff ff       	call   4480 <fwp_tape_of>
    5e1f:	48 89 c3             	mov    %rax,%rbx
    5e22:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e27:	0f 85 76 02 00 00    	jne    60a3 <fwp_p_ad_push+0x2f3>
    5e2d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e31:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e38:	0f 8f 59 02 00 00    	jg     6097 <fwp_p_ad_push+0x2e7>
    5e3e:	44 89 e0             	mov    %r12d,%eax
    5e41:	4c 39 f8             	cmp    %r15,%rax
    5e44:	0f 8d 41 02 00 00    	jge    608b <fwp_p_ad_push+0x2db>
    5e4a:	4d 85 ed             	test   %r13,%r13
    5e4d:	78 0c                	js     5e5b <fwp_p_ad_push+0xab>
    5e4f:	44 89 e8             	mov    %r13d,%eax
    5e52:	4c 39 f8             	cmp    %r15,%rax
    5e55:	0f 8d 30 02 00 00    	jge    608b <fwp_p_ad_push+0x2db>
    5e5b:	4d 89 fe             	mov    %r15,%r14
    5e5e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5e62:	49 8d 46 01          	lea    0x1(%r14),%rax
    5e66:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e6c:	0f 87 25 02 00 00    	ja     6097 <fwp_p_ad_push+0x2e7>
    5e72:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e76:	48 39 e8             	cmp    %rbp,%rax
    5e79:	0f 8e 31 01 00 00    	jle    5fb0 <fwp_p_ad_push+0x200>
    5e7f:	48 85 ed             	test   %rbp,%rbp
    5e82:	b9 40 00 00 00       	mov    $0x40,%ecx
    5e87:	48 0f 44 e9          	cmove  %rcx,%rbp
    5e8b:	48 39 e8             	cmp    %rbp,%rax
    5e8e:	7e 20                	jle    5eb0 <fwp_p_ad_push+0x100>
    5e90:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5e97:	0f 8f 03 01 00 00    	jg     5fa0 <fwp_p_ad_push+0x1f0>
    5e9d:	48 01 ed             	add    %rbp,%rbp
    5ea0:	48 39 e8             	cmp    %rbp,%rax
    5ea3:	7f eb                	jg     5e90 <fwp_p_ad_push+0xe0>
    5ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5eac:	00 00 00 00 
    5eb0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5eb7:	00 
    5eb8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5ebc:	48 89 c6             	mov    %rax,%rsi
    5ebf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ec4:	e8 07 d7 ff ff       	call   35d0 <realloc@plt>
    5ec9:	48 85 c0             	test   %rax,%rax
    5ecc:	0f 84 dd 01 00 00    	je     60af <fwp_p_ad_push+0x2ff>
    5ed2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5ed6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5eda:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5ede:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5ee2:	48 89 e9             	mov    %rbp,%rcx
    5ee5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5ee9:	48 c1 e1 04          	shl    $0x4,%rcx
    5eed:	48 89 ce             	mov    %rcx,%rsi
    5ef0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ef5:	e8 d6 d6 ff ff       	call   35d0 <realloc@plt>
    5efa:	48 85 c0             	test   %rax,%rax
    5efd:	0f 84 ac 01 00 00    	je     60af <fwp_p_ad_push+0x2ff>
    5f03:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f07:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f0c:	4d 85 f6             	test   %r14,%r14
    5f0f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f13:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f18:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f1f:	00 
    5f20:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f27:	00 
    5f28:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f2c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f33:	00 
    5f34:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f38:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f3c:	0f 85 e2 00 00 00    	jne    6024 <fwp_p_ad_push+0x274>
    5f42:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5f46:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f4a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5f4e:	49 01 c8             	add    %rcx,%r8
    5f51:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5f55:	eb 79                	jmp    5fd0 <fwp_p_ad_push+0x220>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	48 89 d0             	mov    %rdx,%rax
    5f63:	48 c1 ff 20          	sar    $0x20,%rdi
    5f67:	48 c1 f8 20          	sar    $0x20,%rax
    5f6b:	48 39 c7             	cmp    %rax,%rdi
    5f6e:	0f 84 a3 fe ff ff    	je     5e17 <fwp_p_ad_push+0x67>
    5f74:	48 8d 3d 45 68 00 00 	lea    0x6845(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    5f7b:	e8 20 e2 ff ff       	call   41a0 <fwp_trap>
    5f80:	48 83 c4 38          	add    $0x38,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 06 ff ff ff       	jmp    5eb0 <fwp_p_ad_push+0x100>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5fb4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fb8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5fbf:	00 
    5fc0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5fc7:	00 
    5fc8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5fcc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fd0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5fd6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5fe2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5fe8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5fef:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ff3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ff7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5ffb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6001:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6005:	48 83 c4 38          	add    $0x38,%rsp
    6009:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6010:	ff ff ff 
    6013:	4c 21 e0             	and    %r12,%rax
    6016:	5b                   	pop    %rbx
    6017:	5d                   	pop    %rbp
    6018:	4c 09 f8             	or     %r15,%rax
    601b:	41 5c                	pop    %r12
    601d:	41 5d                	pop    %r13
    601f:	41 5e                	pop    %r14
    6021:	41 5f                	pop    %r15
    6023:	c3                   	ret
    6024:	48 39 ca             	cmp    %rcx,%rdx
    6027:	49 89 d6             	mov    %rdx,%r14
    602a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    602f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6033:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6038:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    603d:	48 29 d1             	sub    %rdx,%rcx
    6040:	4c 89 ca             	mov    %r9,%rdx
    6043:	e8 18 d5 ff ff       	call   3560 <__memmove_chk@plt>
    6048:	4c 03 73 30          	add    0x30(%rbx),%r14
    604c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6051:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6055:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    605a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    605e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6062:	4c 89 d2             	mov    %r10,%rdx
    6065:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    606a:	e8 a1 d5 ff ff       	call   3610 <memmove@plt>
    606f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6073:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6077:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    607c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6081:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6086:	e9 bb fe ff ff       	jmp    5f46 <fwp_p_ad_push+0x196>
    608b:	48 8d 3d 72 60 00 00 	lea    0x6072(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    6092:	e8 09 e1 ff ff       	call   41a0 <fwp_trap>
    6097:	48 8d 3d 4b 60 00 00 	lea    0x604b(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    609e:	e8 fd e0 ff ff       	call   41a0 <fwp_trap>
    60a3:	48 8d 3d 5e 67 00 00 	lea    0x675e(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    60aa:	e8 f1 e0 ff ff       	call   41a0 <fwp_trap>
    60af:	48 89 df             	mov    %rbx,%rdi
    60b2:	e8 49 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60b7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60bb:	e8 00 d3 ff ff       	call   33c0 <free@plt>
    60c0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60c4:	e8 f7 d2 ff ff       	call   33c0 <free@plt>
    60c9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    60cd:	e8 ee d2 ff ff       	call   33c0 <free@plt>
    60d2:	31 c9                	xor    %ecx,%ecx
    60d4:	31 c0                	xor    %eax,%eax
    60d6:	31 d2                	xor    %edx,%edx
    60d8:	89 53 04             	mov    %edx,0x4(%rbx)
    60db:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60df:	ba 13 00 00 00       	mov    $0x13,%edx
    60e4:	be 01 00 00 00       	mov    $0x1,%esi
    60e9:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    60ed:	48 8d 3d 14 5f 00 00 	lea    0x5f14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    60f4:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    60f8:	48 8b 0d 41 9f 00 00 	mov    0x9f41(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    60ff:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6103:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6107:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    610b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    610f:	e8 6c d5 ff ff       	call   3680 <fwrite@plt>
    6114:	31 ff                	xor    %edi,%edi
    6116:	e8 a5 d4 ff ff       	call   35c0 <fflush@plt>
    611b:	bf 66 00 00 00       	mov    $0x66,%edi
    6120:	e8 7b d5 ff ff       	call   36a0 <_Exit@plt>
    6125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    612c:	00 00 00 00 

0000000000006130 <w107>:
    6130:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6134:	41 55                	push   %r13
    6136:	48 89 fa             	mov    %rdi,%rdx
    6139:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    613d:	41 54                	push   %r12
    613f:	49 89 fc             	mov    %rdi,%r12
    6142:	55                   	push   %rbp
    6143:	53                   	push   %rbx
    6144:	48 89 f3             	mov    %rsi,%rbx
    6147:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    614c:	48 89 f1             	mov    %rsi,%rcx
    614f:	48 83 ec 28          	sub    $0x28,%rsp
    6153:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6159:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    615f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6165:	e8 46 fc ff ff       	call   5db0 <fwp_p_ad_push>
    616a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6170:	48 89 da             	mov    %rbx,%rdx
    6173:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6179:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6180:	00 f0 3f 
    6183:	48 89 c7             	mov    %rax,%rdi
    6186:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    618d:	00 f0 bf 
    6190:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6195:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    619b:	e8 10 fc ff ff       	call   5db0 <fwp_p_ad_push>
    61a0:	f2 0f 10 05 88 69 00 	movsd  0x6988(%rip),%xmm0        # cb30 <msg.4+0xb0>
    61a7:	00 
    61a8:	4c 89 e7             	mov    %r12,%rdi
    61ab:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    61b1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61b8:	00 f0 3f 
    61bb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    61c2:	49 89 c5             	mov    %rax,%r13
    61c5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    61cc:	00 f0 bf 
    61cf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    61d4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61da:	e8 d1 fb ff ff       	call   5db0 <fwp_p_ad_push>
    61df:	48 89 e9             	mov    %rbp,%rcx
    61e2:	4c 89 ea             	mov    %r13,%rdx
    61e5:	48 89 ee             	mov    %rbp,%rsi
    61e8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    61ee:	4c 89 ef             	mov    %r13,%rdi
    61f1:	49 89 c4             	mov    %rax,%r12
    61f4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    61f8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    61fe:	e8 ad fb ff ff       	call   5db0 <fwp_p_ad_push>
    6203:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6209:	f2 0f 59 1d 27 69 00 	mulsd  0x6927(%rip),%xmm3        # cb38 <msg.4+0xb8>
    6210:	00 
    6211:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6218:	00 59 40 
    621b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6220:	48 89 c2             	mov    %rax,%rdx
    6223:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    622a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6230:	e8 7b fb ff ff       	call   5db0 <fwp_p_ad_push>
    6235:	48 89 d9             	mov    %rbx,%rcx
    6238:	4c 89 e2             	mov    %r12,%rdx
    623b:	48 89 de             	mov    %rbx,%rsi
    623e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6244:	4c 89 e7             	mov    %r12,%rdi
    6247:	48 89 c5             	mov    %rax,%rbp
    624a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    624e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6254:	e8 57 fb ff ff       	call   5db0 <fwp_p_ad_push>
    6259:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    625f:	48 89 ea             	mov    %rbp,%rdx
    6262:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6268:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    626f:	00 f0 3f 
    6272:	48 89 c7             	mov    %rax,%rdi
    6275:	48 89 ce             	mov    %rcx,%rsi
    6278:	66 48 0f 7e db       	movq   %xmm3,%rbx
    627d:	e8 2e fb ff ff       	call   5db0 <fwp_p_ad_push>
    6282:	48 83 c4 28          	add    $0x28,%rsp
    6286:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    628b:	5b                   	pop    %rbx
    628c:	5d                   	pop    %rbp
    628d:	41 5c                	pop    %r12
    628f:	41 5d                	pop    %r13
    6291:	c3                   	ret
    6292:	0f 1f 00             	nopl   (%rax)
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 

00000000000062a0 <fwp_data.part.0.constprop.0>:
    62a0:	41 56                	push   %r14
    62a2:	41 89 fe             	mov    %edi,%r14d
    62a5:	41 54                	push   %r12
    62a7:	49 89 f4             	mov    %rsi,%r12
    62aa:	55                   	push   %rbp
    62ab:	53                   	push   %rbx
    62ac:	48 83 ec 08          	sub    $0x8,%rsp
    62b0:	8b 05 4e b8 01 00    	mov    0x1b84e(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    62b6:	85 c0                	test   %eax,%eax
    62b8:	0f 84 fa 00 00 00    	je     63b8 <fwp_data.part.0.constprop.0+0x118>
    62be:	0f b6 05 3d b4 01 00 	movzbl 0x1b43d(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    62c5:	48 8d 15 94 a4 01 00 	lea    0x1a494(%rip),%rdx        # 20760 <fwp_heap>
    62cc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    62d3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    62d7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    62db:	48 8b 18             	mov    (%rax),%rbx
    62de:	48 85 db             	test   %rbx,%rbx
    62e1:	0f 84 a9 00 00 00    	je     6390 <fwp_data.part.0.constprop.0+0xf0>
    62e7:	48 8b 13             	mov    (%rbx),%rdx
    62ea:	48 f7 d2             	not    %rdx
    62ed:	48 89 10             	mov    %rdx,(%rax)
    62f0:	48 83 fd 18          	cmp    $0x18,%rbp
    62f4:	76 1b                	jbe    6311 <fwp_data.part.0.constprop.0+0x71>
    62f6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    62fa:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    62fe:	31 f6                	xor    %esi,%esi
    6300:	48 c1 e8 03          	shr    $0x3,%rax
    6304:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    630b:	00 
    630c:	e8 af d1 ff ff       	call   34c0 <memset@plt>
    6311:	48 89 e8             	mov    %rbp,%rax
    6314:	48 03 05 65 b8 01 00 	add    0x1b865(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    631b:	0f 82 a8 00 00 00    	jb     63c9 <fwp_data.part.0.constprop.0+0x129>
    6321:	48 39 05 60 b8 01 00 	cmp    %rax,0x1b860(%rip)        # 21b88 <fwp_heap+0x1428>
    6328:	48 89 05 51 b8 01 00 	mov    %rax,0x1b851(%rip)        # 21b80 <fwp_heap+0x1420>
    632f:	73 07                	jae    6338 <fwp_data.part.0.constprop.0+0x98>
    6331:	48 89 05 50 b8 01 00 	mov    %rax,0x1b850(%rip)        # 21b88 <fwp_heap+0x1428>
    6338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    633c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6341:	f2 0f 58 05 4f b8 01 	addsd  0x1b84f(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    6348:	00 
    6349:	f2 0f 11 05 47 b8 01 	movsd  %xmm0,0x1b847(%rip)        # 21b98 <fwp_heap+0x1438>
    6350:	00 
    6351:	b8 02 00 00 00       	mov    $0x2,%eax
    6356:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    635b:	66 0f 6e c8          	movd   %eax,%xmm1
    635f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6363:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6367:	49 8b 04 24          	mov    (%r12),%rax
    636b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    636f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6374:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6378:	48 83 c4 08          	add    $0x8,%rsp
    637c:	48 89 d8             	mov    %rbx,%rax
    637f:	5b                   	pop    %rbx
    6380:	5d                   	pop    %rbp
    6381:	41 5c                	pop    %r12
    6383:	41 5e                	pop    %r14
    6385:	c3                   	ret
    6386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    638d:	00 00 00 
    6390:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6394:	48 85 db             	test   %rbx,%rbx
    6397:	74 1f                	je     63b8 <fwp_data.part.0.constprop.0+0x118>
    6399:	48 8b 50 10          	mov    0x10(%rax),%rdx
    639d:	48 29 da             	sub    %rbx,%rdx
    63a0:	48 39 ea             	cmp    %rbp,%rdx
    63a3:	72 13                	jb     63b8 <fwp_data.part.0.constprop.0+0x118>
    63a5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    63a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    63ad:	e9 3e ff ff ff       	jmp    62f0 <fwp_data.part.0.constprop.0+0x50>
    63b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63b8:	31 f6                	xor    %esi,%esi
    63ba:	bf 18 00 00 00       	mov    $0x18,%edi
    63bf:	e8 8c f6 ff ff       	call   5a50 <fwp_heap_alloc>
    63c4:	48 89 c3             	mov    %rax,%rbx
    63c7:	eb 88                	jmp    6351 <fwp_data.part.0.constprop.0+0xb1>
    63c9:	e8 e2 d8 ff ff       	call   3cb0 <fwp_heap_oom>
    63ce:	66 90                	xchg   %ax,%ax

00000000000063d0 <fwp_rc_share>:
    63d0:	48 8b 05 61 b7 01 00 	mov    0x1b761(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    63d7:	48 2b 3d 32 b7 01 00 	sub    0x1b732(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    63de:	48 c1 e0 10          	shl    $0x10,%rax
    63e2:	48 39 c7             	cmp    %rax,%rdi
    63e5:	73 4a                	jae    6431 <fwp_rc_share+0x61>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 e8 10          	shr    $0x10,%rax
    63ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63f2:	48 8b 05 5f b7 01 00 	mov    0x1b75f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    63f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    63fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6401:	48 85 d2             	test   %rdx,%rdx
    6404:	74 2b                	je     6431 <fwp_rc_share+0x61>
    6406:	0f b6 08             	movzbl (%rax),%ecx
    6409:	80 f9 02             	cmp    $0x2,%cl
    640c:	74 2a                	je     6438 <fwp_rc_share+0x68>
    640e:	80 f9 01             	cmp    $0x1,%cl
    6411:	75 1e                	jne    6431 <fwp_rc_share+0x61>
    6413:	8b 48 18             	mov    0x18(%rax),%ecx
    6416:	0f b7 ff             	movzwl %di,%edi
    6419:	8b 40 1c             	mov    0x1c(%rax),%eax
    641c:	48 0f af f9          	imul   %rcx,%rdi
    6420:	48 c1 ef 20          	shr    $0x20,%rdi
    6424:	48 39 c7             	cmp    %rax,%rdi
    6427:	73 08                	jae    6431 <fwp_rc_share+0x61>
    6429:	48 01 fa             	add    %rdi,%rdx
    642c:	80 3a 00             	cmpb   $0x0,(%rdx)
    642f:	75 0d                	jne    643e <fwp_rc_share+0x6e>
    6431:	c3                   	ret
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	66 85 ff             	test   %di,%di
    643b:	74 ef                	je     642c <fwp_rc_share+0x5c>
    643d:	c3                   	ret
    643e:	50                   	push   %rax
    643f:	48 8d 3d f2 63 00 00 	lea    0x63f2(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    6446:	e8 55 dd ff ff       	call   41a0 <fwp_trap>
    644b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006450 <fwp_rc_free_arr>:
    6450:	48 8b 15 e1 b6 01 00 	mov    0x1b6e1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6457:	48 89 f8             	mov    %rdi,%rax
    645a:	48 2b 05 af b6 01 00 	sub    0x1b6af(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6461:	48 c1 e2 10          	shl    $0x10,%rdx
    6465:	48 39 d0             	cmp    %rdx,%rax
    6468:	73 5b                	jae    64c5 <fwp_rc_free_arr+0x75>
    646a:	48 89 c2             	mov    %rax,%rdx
    646d:	48 c1 ea 10          	shr    $0x10,%rdx
    6471:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6475:	48 8b 15 dc b6 01 00 	mov    0x1b6dc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    647c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6480:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6484:	48 85 c9             	test   %rcx,%rcx
    6487:	74 3c                	je     64c5 <fwp_rc_free_arr+0x75>
    6489:	0f b6 32             	movzbl (%rdx),%esi
    648c:	40 80 fe 02          	cmp    $0x2,%sil
    6490:	74 2e                	je     64c0 <fwp_rc_free_arr+0x70>
    6492:	40 80 fe 01          	cmp    $0x1,%sil
    6496:	75 2d                	jne    64c5 <fwp_rc_free_arr+0x75>
    6498:	8b 72 18             	mov    0x18(%rdx),%esi
    649b:	0f b7 c0             	movzwl %ax,%eax
    649e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    64a1:	48 0f af c6          	imul   %rsi,%rax
    64a5:	48 c1 e8 20          	shr    $0x20,%rax
    64a9:	48 39 d0             	cmp    %rdx,%rax
    64ac:	73 17                	jae    64c5 <fwp_rc_free_arr+0x75>
    64ae:	48 01 c1             	add    %rax,%rcx
    64b1:	80 39 01             	cmpb   $0x1,(%rcx)
    64b4:	75 0f                	jne    64c5 <fwp_rc_free_arr+0x75>
    64b6:	e9 95 f0 ff ff       	jmp    5550 <fwp_mem_free>
    64bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    64c0:	66 85 c0             	test   %ax,%ax
    64c3:	74 ec                	je     64b1 <fwp_rc_free_arr+0x61>
    64c5:	c3                   	ret
    64c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64cd:	00 00 00 

00000000000064d0 <fwp_rc_dup>:
    64d0:	f3 0f 1e fa          	endbr64
    64d4:	48 8b 05 5d b6 01 00 	mov    0x1b65d(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    64db:	48 2b 3d 2e b6 01 00 	sub    0x1b62e(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    64e2:	48 c1 e0 10          	shl    $0x10,%rax
    64e6:	48 39 c7             	cmp    %rax,%rdi
    64e9:	73 56                	jae    6541 <fwp_rc_dup+0x71>
    64eb:	48 89 f8             	mov    %rdi,%rax
    64ee:	48 c1 e8 10          	shr    $0x10,%rax
    64f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    64f6:	48 8b 05 5b b6 01 00 	mov    0x1b65b(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    64fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6501:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6505:	48 85 c0             	test   %rax,%rax
    6508:	74 37                	je     6541 <fwp_rc_dup+0x71>
    650a:	0f b6 0a             	movzbl (%rdx),%ecx
    650d:	80 f9 02             	cmp    $0x2,%cl
    6510:	74 36                	je     6548 <fwp_rc_dup+0x78>
    6512:	80 f9 01             	cmp    $0x1,%cl
    6515:	75 2a                	jne    6541 <fwp_rc_dup+0x71>
    6517:	8b 4a 18             	mov    0x18(%rdx),%ecx
    651a:	0f b7 ff             	movzwl %di,%edi
    651d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6520:	48 0f af f9          	imul   %rcx,%rdi
    6524:	48 c1 ef 20          	shr    $0x20,%rdi
    6528:	48 39 d7             	cmp    %rdx,%rdi
    652b:	73 14                	jae    6541 <fwp_rc_dup+0x71>
    652d:	48 01 f8             	add    %rdi,%rax
    6530:	0f b6 10             	movzbl (%rax),%edx
    6533:	84 d2                	test   %dl,%dl
    6535:	74 0a                	je     6541 <fwp_rc_dup+0x71>
    6537:	80 fa fd             	cmp    $0xfd,%dl
    653a:	77 14                	ja     6550 <fwp_rc_dup+0x80>
    653c:	83 c2 01             	add    $0x1,%edx
    653f:	88 10                	mov    %dl,(%rax)
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 e3                	je     6530 <fwp_rc_dup+0x60>
    654d:	c3                   	ret
    654e:	66 90                	xchg   %ax,%ax
    6550:	48 89 c7             	mov    %rax,%rdi
    6553:	e9 98 ec ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    655f:	00 

0000000000006560 <fwp_drop0>:
    6560:	f3 0f 1e fa          	endbr64
    6564:	48 8b 15 cd b5 01 00 	mov    0x1b5cd(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    656b:	48 89 f8             	mov    %rdi,%rax
    656e:	48 2b 05 9b b5 01 00 	sub    0x1b59b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6575:	48 c1 e2 10          	shl    $0x10,%rdx
    6579:	48 39 d0             	cmp    %rdx,%rax
    657c:	0f 83 be 00 00 00    	jae    6640 <fwp_drop0+0xe0>
    6582:	48 83 ec 18          	sub    $0x18,%rsp
    6586:	4c 8d 05 d3 a1 01 00 	lea    0x1a1d3(%rip),%r8        # 20760 <fwp_heap>
    658d:	48 89 c2             	mov    %rax,%rdx
    6590:	48 c1 ea 10          	shr    $0x10,%rdx
    6594:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6598:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    659f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65a3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65a7:	48 85 d2             	test   %rdx,%rdx
    65aa:	74 3c                	je     65e8 <fwp_drop0+0x88>
    65ac:	0f b6 31             	movzbl (%rcx),%esi
    65af:	40 80 fe 02          	cmp    $0x2,%sil
    65b3:	74 3b                	je     65f0 <fwp_drop0+0x90>
    65b5:	40 80 fe 01          	cmp    $0x1,%sil
    65b9:	75 2d                	jne    65e8 <fwp_drop0+0x88>
    65bb:	8b 71 18             	mov    0x18(%rcx),%esi
    65be:	0f b7 c0             	movzwl %ax,%eax
    65c1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65c4:	48 0f af c6          	imul   %rsi,%rax
    65c8:	48 c1 e8 20          	shr    $0x20,%rax
    65cc:	48 39 c8             	cmp    %rcx,%rax
    65cf:	73 17                	jae    65e8 <fwp_drop0+0x88>
    65d1:	48 01 c2             	add    %rax,%rdx
    65d4:	0f b6 02             	movzbl (%rdx),%eax
    65d7:	84 c0                	test   %al,%al
    65d9:	74 0d                	je     65e8 <fwp_drop0+0x88>
    65db:	3c 01                	cmp    $0x1,%al
    65dd:	74 21                	je     6600 <fwp_drop0+0xa0>
    65df:	3c ff                	cmp    $0xff,%al
    65e1:	74 65                	je     6648 <fwp_drop0+0xe8>
    65e3:	83 e8 01             	sub    $0x1,%eax
    65e6:	88 02                	mov    %al,(%rdx)
    65e8:	48 83 c4 18          	add    $0x18,%rsp
    65ec:	c3                   	ret
    65ed:	0f 1f 00             	nopl   (%rax)
    65f0:	66 85 c0             	test   %ax,%ax
    65f3:	74 df                	je     65d4 <fwp_drop0+0x74>
    65f5:	48 83 c4 18          	add    $0x18,%rsp
    65f9:	c3                   	ret
    65fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6600:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6604:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6609:	e8 42 fe ff ff       	call   6450 <fwp_rc_free_arr>
    660e:	4c 8d 05 4b a1 01 00 	lea    0x1a14b(%rip),%r8        # 20760 <fwp_heap>
    6615:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    661a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6621:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6628:	48 c1 e2 10          	shl    $0x10,%rdx
    662c:	48 39 d0             	cmp    %rdx,%rax
    662f:	73 b7                	jae    65e8 <fwp_drop0+0x88>
    6631:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6636:	e9 52 ff ff ff       	jmp    658d <fwp_drop0+0x2d>
    663b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6640:	c3                   	ret
    6641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6648:	48 89 d0             	mov    %rdx,%rax
    664b:	48 c1 e8 11          	shr    $0x11,%rax
    664f:	48 31 d0             	xor    %rdx,%rax
    6652:	48 89 c1             	mov    %rax,%rcx
    6655:	48 c1 e9 09          	shr    $0x9,%rcx
    6659:	48 31 c8             	xor    %rcx,%rax
    665c:	0f b6 c8             	movzbl %al,%ecx
    665f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6666:	00 
    6667:	48 85 c0             	test   %rax,%rax
    666a:	75 1d                	jne    6689 <fwp_drop0+0x129>
    666c:	eb 56                	jmp    66c4 <fwp_drop0+0x164>
    666e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    667c:	00 00 00 00 
    6680:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6684:	48 85 c0             	test   %rax,%rax
    6687:	74 3b                	je     66c4 <fwp_drop0+0x164>
    6689:	48 89 c1             	mov    %rax,%rcx
    668c:	48 39 10             	cmp    %rdx,(%rax)
    668f:	75 ef                	jne    6680 <fwp_drop0+0x120>
    6691:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6695:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6699:	48 89 48 08          	mov    %rcx,0x8(%rax)
    669d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    66a4:	0f 85 3e ff ff ff    	jne    65e8 <fwp_drop0+0x88>
    66aa:	48 89 d7             	mov    %rdx,%rdi
    66ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    66b2:	e8 59 ec ff ff       	call   5310 <fwp_rc_forget_slot>
    66b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    66bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    66bf:	e9 24 ff ff ff       	jmp    65e8 <fwp_drop0+0x88>
    66c4:	48 8d 3d cd 60 00 00 	lea    0x60cd(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    66cb:	e8 d0 da ff ff       	call   41a0 <fwp_trap>

00000000000066d0 <fwp_arg_drop12>:
    66d0:	f3 0f 1e fa          	endbr64
    66d4:	85 f6                	test   %esi,%esi
    66d6:	75 04                	jne    66dc <fwp_arg_drop12+0xc>
    66d8:	85 d2                	test   %edx,%edx
    66da:	75 04                	jne    66e0 <fwp_arg_drop12+0x10>
    66dc:	c3                   	ret
    66dd:	0f 1f 00             	nopl   (%rax)
    66e0:	48 8b 3f             	mov    (%rdi),%rdi
    66e3:	e9 78 fe ff ff       	jmp    6560 <fwp_drop0>
    66e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    66ef:	00 

00000000000066f0 <fwp_drop1>:
    66f0:	f3 0f 1e fa          	endbr64
    66f4:	48 8b 15 3d b4 01 00 	mov    0x1b43d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    66fb:	48 89 f8             	mov    %rdi,%rax
    66fe:	48 2b 05 0b b4 01 00 	sub    0x1b40b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6705:	48 c1 e2 10          	shl    $0x10,%rdx
    6709:	48 39 d0             	cmp    %rdx,%rax
    670c:	0f 83 be 00 00 00    	jae    67d0 <fwp_drop1+0xe0>
    6712:	48 83 ec 18          	sub    $0x18,%rsp
    6716:	4c 8d 05 43 a0 01 00 	lea    0x1a043(%rip),%r8        # 20760 <fwp_heap>
    671d:	48 89 c2             	mov    %rax,%rdx
    6720:	48 c1 ea 10          	shr    $0x10,%rdx
    6724:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6728:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    672f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6733:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6737:	48 85 d2             	test   %rdx,%rdx
    673a:	74 3c                	je     6778 <fwp_drop1+0x88>
    673c:	0f b6 31             	movzbl (%rcx),%esi
    673f:	40 80 fe 02          	cmp    $0x2,%sil
    6743:	74 3b                	je     6780 <fwp_drop1+0x90>
    6745:	40 80 fe 01          	cmp    $0x1,%sil
    6749:	75 2d                	jne    6778 <fwp_drop1+0x88>
    674b:	8b 71 18             	mov    0x18(%rcx),%esi
    674e:	0f b7 c0             	movzwl %ax,%eax
    6751:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6754:	48 0f af c6          	imul   %rsi,%rax
    6758:	48 c1 e8 20          	shr    $0x20,%rax
    675c:	48 39 c8             	cmp    %rcx,%rax
    675f:	73 17                	jae    6778 <fwp_drop1+0x88>
    6761:	48 01 c2             	add    %rax,%rdx
    6764:	0f b6 02             	movzbl (%rdx),%eax
    6767:	84 c0                	test   %al,%al
    6769:	74 0d                	je     6778 <fwp_drop1+0x88>
    676b:	3c 01                	cmp    $0x1,%al
    676d:	74 21                	je     6790 <fwp_drop1+0xa0>
    676f:	3c ff                	cmp    $0xff,%al
    6771:	74 65                	je     67d8 <fwp_drop1+0xe8>
    6773:	83 e8 01             	sub    $0x1,%eax
    6776:	88 02                	mov    %al,(%rdx)
    6778:	48 83 c4 18          	add    $0x18,%rsp
    677c:	c3                   	ret
    677d:	0f 1f 00             	nopl   (%rax)
    6780:	66 85 c0             	test   %ax,%ax
    6783:	74 df                	je     6764 <fwp_drop1+0x74>
    6785:	48 83 c4 18          	add    $0x18,%rsp
    6789:	c3                   	ret
    678a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6790:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6794:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6799:	e8 b2 fc ff ff       	call   6450 <fwp_rc_free_arr>
    679e:	4c 8d 05 bb 9f 01 00 	lea    0x19fbb(%rip),%r8        # 20760 <fwp_heap>
    67a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    67aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    67b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    67b8:	48 c1 e2 10          	shl    $0x10,%rdx
    67bc:	48 39 d0             	cmp    %rdx,%rax
    67bf:	73 b7                	jae    6778 <fwp_drop1+0x88>
    67c1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    67c6:	e9 52 ff ff ff       	jmp    671d <fwp_drop1+0x2d>
    67cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67d0:	c3                   	ret
    67d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67d8:	48 89 d0             	mov    %rdx,%rax
    67db:	48 c1 e8 11          	shr    $0x11,%rax
    67df:	48 31 d0             	xor    %rdx,%rax
    67e2:	48 89 c1             	mov    %rax,%rcx
    67e5:	48 c1 e9 09          	shr    $0x9,%rcx
    67e9:	48 31 c8             	xor    %rcx,%rax
    67ec:	0f b6 c8             	movzbl %al,%ecx
    67ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    67f6:	00 
    67f7:	48 85 c0             	test   %rax,%rax
    67fa:	75 0d                	jne    6809 <fwp_drop1+0x119>
    67fc:	eb 46                	jmp    6844 <fwp_drop1+0x154>
    67fe:	66 90                	xchg   %ax,%ax
    6800:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6804:	48 85 c0             	test   %rax,%rax
    6807:	74 3b                	je     6844 <fwp_drop1+0x154>
    6809:	48 89 c1             	mov    %rax,%rcx
    680c:	48 39 10             	cmp    %rdx,(%rax)
    680f:	75 ef                	jne    6800 <fwp_drop1+0x110>
    6811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6815:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6819:	48 89 48 08          	mov    %rcx,0x8(%rax)
    681d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6824:	0f 85 4e ff ff ff    	jne    6778 <fwp_drop1+0x88>
    682a:	48 89 d7             	mov    %rdx,%rdi
    682d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6832:	e8 d9 ea ff ff       	call   5310 <fwp_rc_forget_slot>
    6837:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    683c:	c6 02 fe             	movb   $0xfe,(%rdx)
    683f:	e9 34 ff ff ff       	jmp    6778 <fwp_drop1+0x88>
    6844:	48 8d 3d 4d 5f 00 00 	lea    0x5f4d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    684b:	e8 50 d9 ff ff       	call   41a0 <fwp_trap>

0000000000006850 <fwp_closure_drop>:
    6850:	48 8b 15 e1 b2 01 00 	mov    0x1b2e1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6857:	48 89 f8             	mov    %rdi,%rax
    685a:	48 2b 05 af b2 01 00 	sub    0x1b2af(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6861:	48 c1 e2 10          	shl    $0x10,%rdx
    6865:	48 39 d0             	cmp    %rdx,%rax
    6868:	73 6b                	jae    68d5 <fwp_closure_drop+0x85>
    686a:	48 89 c2             	mov    %rax,%rdx
    686d:	48 c1 ea 10          	shr    $0x10,%rdx
    6871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6875:	48 8b 15 dc b2 01 00 	mov    0x1b2dc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    687c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6880:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6884:	48 85 d2             	test   %rdx,%rdx
    6887:	74 4c                	je     68d5 <fwp_closure_drop+0x85>
    6889:	0f b6 31             	movzbl (%rcx),%esi
    688c:	40 80 fe 02          	cmp    $0x2,%sil
    6890:	74 3e                	je     68d0 <fwp_closure_drop+0x80>
    6892:	40 80 fe 01          	cmp    $0x1,%sil
    6896:	75 3d                	jne    68d5 <fwp_closure_drop+0x85>
    6898:	8b 71 18             	mov    0x18(%rcx),%esi
    689b:	0f b7 c0             	movzwl %ax,%eax
    689e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68a1:	48 0f af c6          	imul   %rsi,%rax
    68a5:	48 c1 e8 20          	shr    $0x20,%rax
    68a9:	48 39 c8             	cmp    %rcx,%rax
    68ac:	73 27                	jae    68d5 <fwp_closure_drop+0x85>
    68ae:	48 01 c2             	add    %rax,%rdx
    68b1:	0f b6 02             	movzbl (%rdx),%eax
    68b4:	84 c0                	test   %al,%al
    68b6:	74 1d                	je     68d5 <fwp_closure_drop+0x85>
    68b8:	3c 01                	cmp    $0x1,%al
    68ba:	74 24                	je     68e0 <fwp_closure_drop+0x90>
    68bc:	3c ff                	cmp    $0xff,%al
    68be:	74 48                	je     6908 <fwp_closure_drop+0xb8>
    68c0:	83 e8 01             	sub    $0x1,%eax
    68c3:	88 02                	mov    %al,(%rdx)
    68c5:	c3                   	ret
    68c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68cd:	00 00 00 
    68d0:	66 85 c0             	test   %ax,%ax
    68d3:	74 dc                	je     68b1 <fwp_closure_drop+0x61>
    68d5:	c3                   	ret
    68d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68dd:	00 00 00 
    68e0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    68e7:	ff ff 
    68e9:	48 85 c0             	test   %rax,%rax
    68ec:	74 12                	je     6900 <fwp_closure_drop+0xb0>
    68ee:	48 89 fe             	mov    %rdi,%rsi
    68f1:	48 89 c7             	mov    %rax,%rdi
    68f4:	e9 07 d9 ff ff       	jmp    4200 <fwp_closure_drop_push>
    68f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6900:	e9 ab da ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6905:	0f 1f 00             	nopl   (%rax)
    6908:	48 89 d0             	mov    %rdx,%rax
    690b:	48 8d 35 4e 9e 01 00 	lea    0x19e4e(%rip),%rsi        # 20760 <fwp_heap>
    6912:	48 83 ec 18          	sub    $0x18,%rsp
    6916:	48 c1 e8 11          	shr    $0x11,%rax
    691a:	48 31 d0             	xor    %rdx,%rax
    691d:	48 89 c1             	mov    %rax,%rcx
    6920:	48 c1 e9 09          	shr    $0x9,%rcx
    6924:	48 31 c8             	xor    %rcx,%rax
    6927:	0f b6 c8             	movzbl %al,%ecx
    692a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6931:	00 
    6932:	48 85 c0             	test   %rax,%rax
    6935:	75 12                	jne    6949 <fwp_closure_drop+0xf9>
    6937:	eb 49                	jmp    6982 <fwp_closure_drop+0x132>
    6939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6940:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6944:	48 85 c0             	test   %rax,%rax
    6947:	74 39                	je     6982 <fwp_closure_drop+0x132>
    6949:	48 89 c1             	mov    %rax,%rcx
    694c:	48 39 10             	cmp    %rdx,(%rax)
    694f:	75 ef                	jne    6940 <fwp_closure_drop+0xf0>
    6951:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6955:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6959:	48 89 48 08          	mov    %rcx,0x8(%rax)
    695d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6964:	74 05                	je     696b <fwp_closure_drop+0x11b>
    6966:	48 83 c4 18          	add    $0x18,%rsp
    696a:	c3                   	ret
    696b:	48 89 d7             	mov    %rdx,%rdi
    696e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6973:	e8 98 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    6978:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    697d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6980:	eb e4                	jmp    6966 <fwp_closure_drop+0x116>
    6982:	48 8d 3d 0f 5e 00 00 	lea    0x5e0f(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6989:	e8 12 d8 ff ff       	call   41a0 <fwp_trap>
    698e:	66 90                	xchg   %ax,%ax

0000000000006990 <fwp_owned_tape_release>:
    6990:	48 85 ff             	test   %rdi,%rdi
    6993:	0f 84 f7 00 00 00    	je     6a90 <fwp_owned_tape_release+0x100>
    6999:	41 54                	push   %r12
    699b:	55                   	push   %rbp
    699c:	53                   	push   %rbx
    699d:	48 8b 07             	mov    (%rdi),%rax
    69a0:	48 85 c0             	test   %rax,%rax
    69a3:	74 08                	je     69ad <fwp_owned_tape_release+0x1d>
    69a5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69ad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69b1:	48 85 d2             	test   %rdx,%rdx
    69b4:	74 03                	je     69b9 <fwp_owned_tape_release+0x29>
    69b6:	48 89 02             	mov    %rax,(%rdx)
    69b9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    69bd:	48 89 fb             	mov    %rdi,%rbx
    69c0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    69c4:	48 85 c0             	test   %rax,%rax
    69c7:	0f 84 89 00 00 00    	je     6a56 <fwp_owned_tape_release+0xc6>
    69cd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    69d1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    69d5:	7e 47                	jle    6a1e <fwp_owned_tape_release+0x8e>
    69d7:	31 ed                	xor    %ebp,%ebp
    69d9:	eb 0d                	jmp    69e8 <fwp_owned_tape_release+0x58>
    69db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69e0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69e4:	48 8b 40 68          	mov    0x68(%rax),%rax
    69e8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    69ec:	49 89 ec             	mov    %rbp,%r12
    69ef:	48 83 c5 01          	add    $0x1,%rbp
    69f3:	49 c1 e4 04          	shl    $0x4,%r12
    69f7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    69fb:	ff d0                	call   *%rax
    69fd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6a01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6a06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a0a:	ff 50 68             	call   *0x68(%rax)
    6a0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6a11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6a15:	48 39 e8             	cmp    %rbp,%rax
    6a18:	7f c6                	jg     69e0 <fwp_owned_tape_release+0x50>
    6a1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a1e:	31 ed                	xor    %ebp,%ebp
    6a20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6a25:	7e 28                	jle    6a4f <fwp_owned_tape_release+0xbf>
    6a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a2e:	00 00 
    6a30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6a34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6a38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6a3c:	74 07                	je     6a45 <fwp_owned_tape_release+0xb5>
    6a3e:	ff 52 68             	call   *0x68(%rdx)
    6a41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a45:	48 83 c5 01          	add    $0x1,%rbp
    6a49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a4d:	7f e1                	jg     6a30 <fwp_owned_tape_release+0xa0>
    6a4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a53:	ff 52 68             	call   *0x68(%rdx)
    6a56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a5a:	e8 f1 fd ff ff       	call   6850 <fwp_closure_drop>
    6a5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a63:	e8 e8 fd ff ff       	call   6850 <fwp_closure_drop>
    6a68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a6c:	e8 df fd ff ff       	call   6850 <fwp_closure_drop>
    6a71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a75:	e8 d6 ea ff ff       	call   5550 <fwp_mem_free>
    6a7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a7e:	e8 cd ea ff ff       	call   5550 <fwp_mem_free>
    6a83:	48 89 df             	mov    %rbx,%rdi
    6a86:	5b                   	pop    %rbx
    6a87:	5d                   	pop    %rbp
    6a88:	41 5c                	pop    %r12
    6a8a:	e9 c1 ea ff ff       	jmp    5550 <fwp_mem_free>
    6a8f:	90                   	nop
    6a90:	c3                   	ret
    6a91:	0f 1f 40 00          	nopl   0x0(%rax)
    6a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a9c:	00 00 00 00 

0000000000006aa0 <fwp_tape_finish>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	41 56                	push   %r14
    6aa6:	48 8d 3d f3 95 01 00 	lea    0x195f3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6aad:	41 55                	push   %r13
    6aaf:	41 54                	push   %r12
    6ab1:	55                   	push   %rbp
    6ab2:	53                   	push   %rbx
    6ab3:	e8 b8 d4 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6ab8:	48 83 3d 28 96 01 00 	cmpq   $0x0,0x19628(%rip)        # 200e8 <fwp_ntapes>
    6abf:	00 
    6ac0:	48 c7 05 bd 95 01 00 	movq   $0x0,0x195bd(%rip)        # 20088 <fwp_tape_cached_bytes>
    6ac7:	00 00 00 00 
    6acb:	7e 68                	jle    6b35 <fwp_tape_finish+0x95>
    6acd:	45 31 e4             	xor    %r12d,%r12d
    6ad0:	31 ed                	xor    %ebp,%ebp
    6ad2:	0f 1f 00             	nopl   (%rax)
    6ad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6adc:	00 00 00 00 
    6ae0:	48 8b 1d 09 96 01 00 	mov    0x19609(%rip),%rbx        # 200f0 <fwp_tapes>
    6ae7:	48 83 c5 01          	add    $0x1,%rbp
    6aeb:	4c 01 e3             	add    %r12,%rbx
    6aee:	49 83 c4 68          	add    $0x68,%r12
    6af2:	48 89 df             	mov    %rbx,%rdi
    6af5:	e8 06 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6afa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6afe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b02:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6b06:	e8 b5 c8 ff ff       	call   33c0 <free@plt>
    6b0b:	4c 89 f7             	mov    %r14,%rdi
    6b0e:	e8 ad c8 ff ff       	call   33c0 <free@plt>
    6b13:	4c 89 ef             	mov    %r13,%rdi
    6b16:	e8 a5 c8 ff ff       	call   33c0 <free@plt>
    6b1b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6b1f:	e8 6c fe ff ff       	call   6990 <fwp_owned_tape_release>
    6b24:	48 39 2d bd 95 01 00 	cmp    %rbp,0x195bd(%rip)        # 200e8 <fwp_ntapes>
    6b2b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6b32:	00 
    6b33:	7f ab                	jg     6ae0 <fwp_tape_finish+0x40>
    6b35:	48 8b 3d b4 95 01 00 	mov    0x195b4(%rip),%rdi        # 200f0 <fwp_tapes>
    6b3c:	e8 7f c8 ff ff       	call   33c0 <free@plt>
    6b41:	5b                   	pop    %rbx
    6b42:	5d                   	pop    %rbp
    6b43:	48 c7 05 a2 95 01 00 	movq   $0x0,0x195a2(%rip)        # 200f0 <fwp_tapes>
    6b4a:	00 00 00 00 
    6b4e:	48 c7 05 87 95 01 00 	movq   $0x0,0x19587(%rip)        # 200e0 <fwp_tapes_cap>
    6b55:	00 00 00 00 
    6b59:	41 5c                	pop    %r12
    6b5b:	48 c7 05 82 95 01 00 	movq   $0x0,0x19582(%rip)        # 200e8 <fwp_ntapes>
    6b62:	00 00 00 00 
    6b66:	41 5d                	pop    %r13
    6b68:	48 c7 05 65 95 01 00 	movq   $0x0,0x19565(%rip)        # 200d8 <fwp_tape_next_slot>
    6b6f:	00 00 00 00 
    6b73:	41 5e                	pop    %r14
    6b75:	c3                   	ret
    6b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b7d:	00 00 00 

0000000000006b80 <fwp_tape_scope_release>:
    6b80:	f3 0f 1e fa          	endbr64
    6b84:	41 55                	push   %r13
    6b86:	41 54                	push   %r12
    6b88:	55                   	push   %rbp
    6b89:	53                   	push   %rbx
    6b8a:	48 83 ec 58          	sub    $0x58,%rsp
    6b8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b95:	00 00 
    6b97:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6b9c:	48 63 07             	movslq (%rdi),%rax
    6b9f:	85 c0                	test   %eax,%eax
    6ba1:	0f 88 05 01 00 00    	js     6cac <fwp_tape_scope_release+0x12c>
    6ba7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6bae:	ec c4 4e 
    6bb1:	48 89 fb             	mov    %rdi,%rbx
    6bb4:	eb 3c                	jmp    6bf2 <fwp_tape_scope_release+0x72>
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6bc5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6bc9:	e8 f2 c7 ff ff       	call   33c0 <free@plt>
    6bce:	48 8b 3c 24          	mov    (%rsp),%rdi
    6bd2:	e8 e9 c7 ff ff       	call   33c0 <free@plt>
    6bd7:	4c 89 ef             	mov    %r13,%rdi
    6bda:	e8 e1 c7 ff ff       	call   33c0 <free@plt>
    6bdf:	4c 89 e7             	mov    %r12,%rdi
    6be2:	e8 a9 fd ff ff       	call   6990 <fwp_owned_tape_release>
    6be7:	48 63 03             	movslq (%rbx),%rax
    6bea:	85 c0                	test   %eax,%eax
    6bec:	0f 88 ba 00 00 00    	js     6cac <fwp_tape_scope_release+0x12c>
    6bf2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6bf6:	48 8b 35 f3 94 01 00 	mov    0x194f3(%rip),%rsi        # 200f0 <fwp_tapes>
    6bfd:	4c 01 c6             	add    %r8,%rsi
    6c00:	48 89 f7             	mov    %rsi,%rdi
    6c03:	e8 f8 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c08:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6c0d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6c12:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6c19:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6c1d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6c21:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6c28:	00 
    6c29:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6c2e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6c32:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6c37:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6c3b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c40:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c47:	00 
    6c48:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c4f:	00 
    6c50:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c57:	00 
    6c58:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c5d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c62:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c66:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c6a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c6e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c74:	77 18                	ja     6c8e <fwp_tape_scope_release+0x10e>
    6c76:	49 c1 f8 03          	sar    $0x3,%r8
    6c7a:	4c 0f af c5          	imul   %rbp,%r8
    6c7e:	4c 3b 05 53 94 01 00 	cmp    0x19453(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6c85:	7d 07                	jge    6c8e <fwp_tape_scope_release+0x10e>
    6c87:	4c 89 05 4a 94 01 00 	mov    %r8,0x1944a(%rip)        # 200d8 <fwp_tape_next_slot>
    6c8e:	4d 85 e4             	test   %r12,%r12
    6c91:	0f 85 29 ff ff ff    	jne    6bc0 <fwp_tape_scope_release+0x40>
    6c97:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6c9c:	e8 8f e1 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6ca1:	48 63 03             	movslq (%rbx),%rax
    6ca4:	85 c0                	test   %eax,%eax
    6ca6:	0f 89 46 ff ff ff    	jns    6bf2 <fwp_tape_scope_release+0x72>
    6cac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6cb1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cb8:	00 00 
    6cba:	75 0b                	jne    6cc7 <fwp_tape_scope_release+0x147>
    6cbc:	48 83 c4 58          	add    $0x58,%rsp
    6cc0:	5b                   	pop    %rbx
    6cc1:	5d                   	pop    %rbp
    6cc2:	41 5c                	pop    %r12
    6cc4:	41 5d                	pop    %r13
    6cc6:	c3                   	ret
    6cc7:	e8 94 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6ccc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cd0 <fwp_task_dispose>:
    6cd0:	53                   	push   %rbx
    6cd1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6cd5:	0f 84 6b ca ff ff    	je     3746 <fwp_task_dispose.cold>
    6cdb:	48 89 fb             	mov    %rdi,%rbx
    6cde:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6ce3:	0f 85 5d ca ff ff    	jne    3746 <fwp_task_dispose.cold>
    6ce9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6ced:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6cf4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6cfb:	00 
    6cfc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6d00:	48 85 ff             	test   %rdi,%rdi
    6d03:	74 07                	je     6d0c <fwp_task_dispose+0x3c>
    6d05:	48 85 c0             	test   %rax,%rax
    6d08:	74 02                	je     6d0c <fwp_task_dispose+0x3c>
    6d0a:	ff d0                	call   *%rax
    6d0c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6d13:	e8 38 e8 ff ff       	call   5550 <fwp_mem_free>
    6d18:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6d1f:	00 00 00 00 
    6d23:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6d27:	74 6f                	je     6d98 <fwp_task_dispose+0xc8>
    6d29:	48 8b 15 08 ae 01 00 	mov    0x1ae08(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6d30:	48 89 d8             	mov    %rbx,%rax
    6d33:	48 2b 05 d6 ad 01 00 	sub    0x1add6(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6d3a:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3e:	48 39 d0             	cmp    %rdx,%rax
    6d41:	73 4c                	jae    6d8f <fwp_task_dispose+0xbf>
    6d43:	48 89 c2             	mov    %rax,%rdx
    6d46:	48 c1 ea 10          	shr    $0x10,%rdx
    6d4a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d4e:	48 8b 15 03 ae 01 00 	mov    0x1ae03(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    6d55:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d59:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d5d:	48 85 c9             	test   %rcx,%rcx
    6d60:	74 2d                	je     6d8f <fwp_task_dispose+0xbf>
    6d62:	0f b6 32             	movzbl (%rdx),%esi
    6d65:	40 80 fe 02          	cmp    $0x2,%sil
    6d69:	74 3d                	je     6da8 <fwp_task_dispose+0xd8>
    6d6b:	40 80 fe 01          	cmp    $0x1,%sil
    6d6f:	75 1e                	jne    6d8f <fwp_task_dispose+0xbf>
    6d71:	8b 72 18             	mov    0x18(%rdx),%esi
    6d74:	0f b7 c0             	movzwl %ax,%eax
    6d77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d7a:	48 0f af c6          	imul   %rsi,%rax
    6d7e:	48 c1 e8 20          	shr    $0x20,%rax
    6d82:	48 39 d0             	cmp    %rdx,%rax
    6d85:	73 08                	jae    6d8f <fwp_task_dispose+0xbf>
    6d87:	48 01 c1             	add    %rax,%rcx
    6d8a:	80 39 01             	cmpb   $0x1,(%rcx)
    6d8d:	74 09                	je     6d98 <fwp_task_dispose+0xc8>
    6d8f:	5b                   	pop    %rbx
    6d90:	c3                   	ret
    6d91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d98:	48 89 df             	mov    %rbx,%rdi
    6d9b:	5b                   	pop    %rbx
    6d9c:	e9 af e7 ff ff       	jmp    5550 <fwp_mem_free>
    6da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6da8:	66 85 c0             	test   %ax,%ax
    6dab:	74 dd                	je     6d8a <fwp_task_dispose+0xba>
    6dad:	5b                   	pop    %rbx
    6dae:	c3                   	ret
    6daf:	90                   	nop

0000000000006db0 <fwp_free_zombie>:
    6db0:	48 8b 15 79 99 01 00 	mov    0x19979(%rip),%rdx        # 20730 <fwp_zombie>
    6db7:	48 85 d2             	test   %rdx,%rdx
    6dba:	0f 84 98 00 00 00    	je     6e58 <fwp_free_zombie+0xa8>
    6dc0:	48 3b 15 79 99 01 00 	cmp    0x19979(%rip),%rdx        # 20740 <fwp_cur>
    6dc7:	0f 84 8b 00 00 00    	je     6e58 <fwp_free_zombie+0xa8>
    6dcd:	48 83 ec 18          	sub    $0x18,%rsp
    6dd1:	48 63 05 34 93 01 00 	movslq 0x19334(%rip),%rax        # 2010c <fwp_stack_pool_n>
    6dd8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6ddc:	83 f8 3f             	cmp    $0x3f,%eax
    6ddf:	7f 7f                	jg     6e60 <fwp_free_zombie+0xb0>
    6de1:	8d 48 01             	lea    0x1(%rax),%ecx
    6de4:	89 0d 22 93 01 00    	mov    %ecx,0x19322(%rip)        # 2010c <fwp_stack_pool_n>
    6dea:	48 8d 0d 2f 93 01 00 	lea    0x1932f(%rip),%rcx        # 20120 <fwp_stack_pool>
    6df1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6df5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6dfc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e00:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6e07:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6e0b:	48 85 c9             	test   %rcx,%rcx
    6e0e:	0f 84 fc 00 00 00    	je     6f10 <fwp_free_zombie+0x160>
    6e14:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6e1b:	48 85 c0             	test   %rax,%rax
    6e1e:	74 07                	je     6e27 <fwp_free_zombie+0x77>
    6e20:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6e27:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6e2a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e2e:	48 c7 05 f7 98 01 00 	movq   $0x0,0x198f7(%rip)        # 20730 <fwp_zombie>
    6e35:	00 00 00 00 
    6e39:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6e40:	85 c0                	test   %eax,%eax
    6e42:	74 34                	je     6e78 <fwp_free_zombie+0xc8>
    6e44:	83 f8 01             	cmp    $0x1,%eax
    6e47:	0f 84 b3 00 00 00    	je     6f00 <fwp_free_zombie+0x150>
    6e4d:	48 83 c4 18          	add    $0x18,%rsp
    6e51:	c3                   	ret
    6e52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e58:	c3                   	ret
    6e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e60:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6e64:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e69:	e8 72 c7 ff ff       	call   35e0 <munmap@plt>
    6e6e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e73:	eb 80                	jmp    6df5 <fwp_free_zombie+0x45>
    6e75:	0f 1f 00             	nopl   (%rax)
    6e78:	48 8b 0d b9 ac 01 00 	mov    0x1acb9(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    6e7f:	48 89 d0             	mov    %rdx,%rax
    6e82:	48 2b 05 87 ac 01 00 	sub    0x1ac87(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6e89:	48 c1 e1 10          	shl    $0x10,%rcx
    6e8d:	48 39 c8             	cmp    %rcx,%rax
    6e90:	73 bb                	jae    6e4d <fwp_free_zombie+0x9d>
    6e92:	48 89 c1             	mov    %rax,%rcx
    6e95:	48 c1 e9 10          	shr    $0x10,%rcx
    6e99:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6e9d:	48 8b 0d b4 ac 01 00 	mov    0x1acb4(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    6ea4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6ea8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6eac:	48 85 c9             	test   %rcx,%rcx
    6eaf:	74 9c                	je     6e4d <fwp_free_zombie+0x9d>
    6eb1:	0f b6 3e             	movzbl (%rsi),%edi
    6eb4:	40 80 ff 02          	cmp    $0x2,%dil
    6eb8:	74 66                	je     6f20 <fwp_free_zombie+0x170>
    6eba:	40 80 ff 01          	cmp    $0x1,%dil
    6ebe:	75 8d                	jne    6e4d <fwp_free_zombie+0x9d>
    6ec0:	8b 7e 18             	mov    0x18(%rsi),%edi
    6ec3:	0f b7 c0             	movzwl %ax,%eax
    6ec6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ec9:	48 0f af c7          	imul   %rdi,%rax
    6ecd:	48 c1 e8 20          	shr    $0x20,%rax
    6ed1:	48 39 f0             	cmp    %rsi,%rax
    6ed4:	0f 83 73 ff ff ff    	jae    6e4d <fwp_free_zombie+0x9d>
    6eda:	48 01 c1             	add    %rax,%rcx
    6edd:	0f b6 01             	movzbl (%rcx),%eax
    6ee0:	84 c0                	test   %al,%al
    6ee2:	0f 84 65 ff ff ff    	je     6e4d <fwp_free_zombie+0x9d>
    6ee8:	3c 01                	cmp    $0x1,%al
    6eea:	74 14                	je     6f00 <fwp_free_zombie+0x150>
    6eec:	3c ff                	cmp    $0xff,%al
    6eee:	74 3b                	je     6f2b <fwp_free_zombie+0x17b>
    6ef0:	83 e8 01             	sub    $0x1,%eax
    6ef3:	88 01                	mov    %al,(%rcx)
    6ef5:	e9 53 ff ff ff       	jmp    6e4d <fwp_free_zombie+0x9d>
    6efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f00:	48 89 d7             	mov    %rdx,%rdi
    6f03:	48 83 c4 18          	add    $0x18,%rsp
    6f07:	e9 c4 fd ff ff       	jmp    6cd0 <fwp_task_dispose>
    6f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f10:	48 89 05 f1 97 01 00 	mov    %rax,0x197f1(%rip)        # 20708 <fwp_tasks_active>
    6f17:	e9 ff fe ff ff       	jmp    6e1b <fwp_free_zombie+0x6b>
    6f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f20:	66 85 c0             	test   %ax,%ax
    6f23:	0f 85 24 ff ff ff    	jne    6e4d <fwp_free_zombie+0x9d>
    6f29:	eb b2                	jmp    6edd <fwp_free_zombie+0x12d>
    6f2b:	48 89 ca             	mov    %rcx,%rdx
    6f2e:	48 8d 35 2b 98 01 00 	lea    0x1982b(%rip),%rsi        # 20760 <fwp_heap>
    6f35:	48 c1 ea 11          	shr    $0x11,%rdx
    6f39:	48 31 ca             	xor    %rcx,%rdx
    6f3c:	48 89 d0             	mov    %rdx,%rax
    6f3f:	48 c1 e8 09          	shr    $0x9,%rax
    6f43:	48 31 c2             	xor    %rax,%rdx
    6f46:	0f b6 d2             	movzbl %dl,%edx
    6f49:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    6f50:	00 
    6f51:	48 85 c0             	test   %rax,%rax
    6f54:	75 13                	jne    6f69 <fwp_free_zombie+0x1b9>
    6f56:	eb 4c                	jmp    6fa4 <fwp_free_zombie+0x1f4>
    6f58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f5f:	00 
    6f60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6f64:	48 85 c0             	test   %rax,%rax
    6f67:	74 3b                	je     6fa4 <fwp_free_zombie+0x1f4>
    6f69:	48 89 c2             	mov    %rax,%rdx
    6f6c:	48 39 08             	cmp    %rcx,(%rax)
    6f6f:	75 ef                	jne    6f60 <fwp_free_zombie+0x1b0>
    6f71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    6f79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6f84:	0f 85 c3 fe ff ff    	jne    6e4d <fwp_free_zombie+0x9d>
    6f8a:	48 89 cf             	mov    %rcx,%rdi
    6f8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f92:	e8 79 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6f97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6f9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f9f:	e9 a9 fe ff ff       	jmp    6e4d <fwp_free_zombie+0x9d>
    6fa4:	48 8d 3d ed 57 00 00 	lea    0x57ed(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6fab:	e8 f0 d1 ff ff       	call   41a0 <fwp_trap>

0000000000006fb0 <fwp_block>:
    6fb0:	48 83 ec 08          	sub    $0x8,%rsp
    6fb4:	48 8b 05 6d 97 01 00 	mov    0x1976d(%rip),%rax        # 20728 <fwp_ready_head>
    6fbb:	48 85 c0             	test   %rax,%rax
    6fbe:	0f 84 1c 01 00 00    	je     70e0 <fwp_block+0x130>
    6fc4:	90                   	nop
    6fc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fcc:	00 00 00 00 
    6fd0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    6fd7:	48 89 15 4a 97 01 00 	mov    %rdx,0x1974a(%rip)        # 20728 <fwp_ready_head>
    6fde:	48 85 d2             	test   %rdx,%rdx
    6fe1:	0f 84 19 01 00 00    	je     7100 <fwp_block+0x150>
    6fe7:	48 8b 15 52 97 01 00 	mov    0x19752(%rip),%rdx        # 20740 <fwp_cur>
    6fee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    6ff2:	48 39 c2             	cmp    %rax,%rdx
    6ff5:	0f 84 d5 00 00 00    	je     70d0 <fwp_block+0x120>
    6ffb:	48 8b 0d c6 b3 01 00 	mov    0x1b3c6(%rip),%rcx        # 223c8 <fwp_state_owners>
    7002:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7006:	48 89 05 33 97 01 00 	mov    %rax,0x19733(%rip)        # 20740 <fwp_cur>
    700d:	f3 0f 7e 05 db b3 01 	movq   0x1b3db(%rip),%xmm0        # 223f0 <fwp_foreign_callbacks>
    7014:	00 
    7015:	0f 16 05 c4 b3 01 00 	movhps 0x1b3c4(%rip),%xmm0        # 223e0 <fwp_state>
    701c:	f3 0f 7e 0d c4 b3 01 	movq   0x1b3c4(%rip),%xmm1        # 223e8 <fwp_handlers>
    7023:	00 
    7024:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    702b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7032:	0f 16 0d bf b3 01 00 	movhps 0x1b3bf(%rip),%xmm1        # 223f8 <fwp_cleanups>
    7039:	f3 0f 7e 05 97 b3 01 	movq   0x1b397(%rip),%xmm0        # 223d8 <fwp_state_len>
    7040:	00 
    7041:	0f 16 05 88 b3 01 00 	movhps 0x1b388(%rip),%xmm0        # 223d0 <fwp_state_cap>
    7048:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    704f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7056:	48 8b 70 08          	mov    0x8(%rax),%rsi
    705a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7061:	48 89 0d 80 b3 01 00 	mov    %rcx,0x1b380(%rip)        # 223e8 <fwp_handlers>
    7068:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    706f:	48 89 0d 82 b3 01 00 	mov    %rcx,0x1b382(%rip)        # 223f8 <fwp_cleanups>
    7076:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    707d:	48 89 0d 6c b3 01 00 	mov    %rcx,0x1b36c(%rip)        # 223f0 <fwp_foreign_callbacks>
    7084:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    708b:	48 89 0d 4e b3 01 00 	mov    %rcx,0x1b34e(%rip)        # 223e0 <fwp_state>
    7092:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7099:	48 89 0d 38 b3 01 00 	mov    %rcx,0x1b338(%rip)        # 223d8 <fwp_state_len>
    70a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    70a7:	48 89 0d 22 b3 01 00 	mov    %rcx,0x1b322(%rip)        # 223d0 <fwp_state_cap>
    70ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    70b5:	48 89 0d 0c b3 01 00 	mov    %rcx,0x1b30c(%rip)        # 223c8 <fwp_state_owners>
    70bc:	e8 cf c3 ff ff       	call   3490 <swapcontext@plt>
    70c1:	f3 0f 1e fa          	endbr64
    70c5:	e8 e6 fc ff ff       	call   6db0 <fwp_free_zombie>
    70ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70d0:	8b 05 32 90 01 00    	mov    0x19032(%rip),%eax        # 20108 <fwp_slice>
    70d6:	85 c0                	test   %eax,%eax
    70d8:	74 36                	je     7110 <fwp_block+0x160>
    70da:	48 83 c4 08          	add    $0x8,%rsp
    70de:	c3                   	ret
    70df:	90                   	nop
    70e0:	e8 7b de ff ff       	call   4f60 <fwp_poll_events>
    70e5:	48 8b 05 3c 96 01 00 	mov    0x1963c(%rip),%rax        # 20728 <fwp_ready_head>
    70ec:	48 85 c0             	test   %rax,%rax
    70ef:	0f 85 db fe ff ff    	jne    6fd0 <fwp_block+0x20>
    70f5:	eb e9                	jmp    70e0 <fwp_block+0x130>
    70f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70fe:	00 00 
    7100:	48 c7 05 15 96 01 00 	movq   $0x0,0x19615(%rip)        # 20720 <fwp_ready_tail>
    7107:	00 00 00 00 
    710b:	e9 d7 fe ff ff       	jmp    6fe7 <fwp_block+0x37>
    7110:	48 8d 3d 0a 50 00 00 	lea    0x500a(%rip),%rdi        # c121 <_IO_stdin_used+0x121>
    7117:	e8 84 c2 ff ff       	call   33a0 <getenv@plt>
    711c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7121:	48 85 c0             	test   %rax,%rax
    7124:	74 05                	je     712b <fwp_block+0x17b>
    7126:	80 38 00             	cmpb   $0x0,(%rax)
    7129:	75 0b                	jne    7136 <fwp_block+0x186>
    712b:	89 15 d7 8f 01 00    	mov    %edx,0x18fd7(%rip)        # 20108 <fwp_slice>
    7131:	48 83 c4 08          	add    $0x8,%rsp
    7135:	c3                   	ret
    7136:	ba 0a 00 00 00       	mov    $0xa,%edx
    713b:	31 f6                	xor    %esi,%esi
    713d:	48 89 c7             	mov    %rax,%rdi
    7140:	e8 0b c4 ff ff       	call   3550 <strtoll@plt>
    7145:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7149:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7150:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7155:	0f 46 d0             	cmovbe %eax,%edx
    7158:	eb d1                	jmp    712b <fwp_block+0x17b>
    715a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007160 <fwp_owned_entry161>:
    7160:	f3 0f 1e fa          	endbr64
    7164:	41 56                	push   %r14
    7166:	55                   	push   %rbp
    7167:	53                   	push   %rbx
    7168:	48 83 ec 10          	sub    $0x10,%rsp
    716c:	48 8b 07             	mov    (%rdi),%rax
    716f:	48 03 47 10          	add    0x10(%rdi),%rax
    7173:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7178:	0f 80 b7 01 00 00    	jo     7335 <fwp_owned_entry161+0x1d5>
    717e:	49 89 c6             	mov    %rax,%r14
    7181:	8b 05 7d a9 01 00    	mov    0x1a97d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    7187:	48 8d 15 d2 95 01 00 	lea    0x195d2(%rip),%rdx        # 20760 <fwp_heap>
    718e:	85 c0                	test   %eax,%eax
    7190:	0f 84 52 01 00 00    	je     72e8 <fwp_owned_entry161+0x188>
    7196:	0f b6 05 65 a5 01 00 	movzbl 0x1a565(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    719d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    71a4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    71a8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    71ac:	48 8b 18             	mov    (%rax),%rbx
    71af:	48 85 db             	test   %rbx,%rbx
    71b2:	0f 84 08 01 00 00    	je     72c0 <fwp_owned_entry161+0x160>
    71b8:	48 8b 13             	mov    (%rbx),%rdx
    71bb:	48 f7 d2             	not    %rdx
    71be:	48 89 10             	mov    %rdx,(%rax)
    71c1:	48 83 fd 18          	cmp    $0x18,%rbp
    71c5:	76 27                	jbe    71ee <fwp_owned_entry161+0x8e>
    71c7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    71cb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    71cf:	31 f6                	xor    %esi,%esi
    71d1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    71d7:	48 c1 e8 03          	shr    $0x3,%rax
    71db:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    71e2:	00 
    71e3:	e8 d8 c2 ff ff       	call   34c0 <memset@plt>
    71e8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    71ee:	48 89 e8             	mov    %rbp,%rax
    71f1:	48 03 05 88 a9 01 00 	add    0x1a988(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    71f8:	0f 82 3c 01 00 00    	jb     733a <fwp_owned_entry161+0x1da>
    71fe:	48 39 05 83 a9 01 00 	cmp    %rax,0x1a983(%rip)        # 21b88 <fwp_heap+0x1428>
    7205:	48 89 05 74 a9 01 00 	mov    %rax,0x1a974(%rip)        # 21b80 <fwp_heap+0x1420>
    720c:	73 07                	jae    7215 <fwp_owned_entry161+0xb5>
    720e:	48 89 05 73 a9 01 00 	mov    %rax,0x1a973(%rip)        # 21b88 <fwp_heap+0x1428>
    7215:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7219:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    721e:	f2 0f 58 0d 72 a9 01 	addsd  0x1a972(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7225:	00 
    7226:	f2 0f 11 0d 6a a9 01 	movsd  %xmm1,0x1a96a(%rip)        # 21b98 <fwp_heap+0x1438>
    722d:	00 
    722e:	48 8b 05 0b 59 00 00 	mov    0x590b(%rip),%rax        # cb40 <msg.4+0xc0>
    7235:	66 49 0f 6e d6       	movq   %r14,%xmm2
    723a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    723e:	48 89 03             	mov    %rax,(%rbx)
    7241:	48 89 d8             	mov    %rbx,%rax
    7244:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7248:	48 8b 15 e9 a8 01 00 	mov    0x1a8e9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    724f:	48 2b 05 ba a8 01 00 	sub    0x1a8ba(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7256:	48 c1 e2 10          	shl    $0x10,%rdx
    725a:	48 39 d0             	cmp    %rdx,%rax
    725d:	73 53                	jae    72b2 <fwp_owned_entry161+0x152>
    725f:	48 89 c2             	mov    %rax,%rdx
    7262:	48 c1 ea 10          	shr    $0x10,%rdx
    7266:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    726a:	48 8b 15 e7 a8 01 00 	mov    0x1a8e7(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7271:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7275:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7279:	48 85 ed             	test   %rbp,%rbp
    727c:	74 34                	je     72b2 <fwp_owned_entry161+0x152>
    727e:	0f b6 0a             	movzbl (%rdx),%ecx
    7281:	80 f9 02             	cmp    $0x2,%cl
    7284:	0f 84 86 00 00 00    	je     7310 <fwp_owned_entry161+0x1b0>
    728a:	80 f9 01             	cmp    $0x1,%cl
    728d:	75 23                	jne    72b2 <fwp_owned_entry161+0x152>
    728f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7292:	0f b7 c0             	movzwl %ax,%eax
    7295:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7298:	48 0f af c1          	imul   %rcx,%rax
    729c:	48 c1 e8 20          	shr    $0x20,%rax
    72a0:	48 39 d0             	cmp    %rdx,%rax
    72a3:	73 0d                	jae    72b2 <fwp_owned_entry161+0x152>
    72a5:	48 01 c5             	add    %rax,%rbp
    72a8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    72ac:	74 7a                	je     7328 <fwp_owned_entry161+0x1c8>
    72ae:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    72b2:	48 83 c4 10          	add    $0x10,%rsp
    72b6:	48 89 d8             	mov    %rbx,%rax
    72b9:	5b                   	pop    %rbx
    72ba:	5d                   	pop    %rbp
    72bb:	41 5e                	pop    %r14
    72bd:	c3                   	ret
    72be:	66 90                	xchg   %ax,%ax
    72c0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    72c4:	48 85 db             	test   %rbx,%rbx
    72c7:	74 1f                	je     72e8 <fwp_owned_entry161+0x188>
    72c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    72cd:	48 29 da             	sub    %rbx,%rdx
    72d0:	48 39 ea             	cmp    %rbp,%rdx
    72d3:	72 13                	jb     72e8 <fwp_owned_entry161+0x188>
    72d5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    72d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72dd:	e9 df fe ff ff       	jmp    71c1 <fwp_owned_entry161+0x61>
    72e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72e8:	31 f6                	xor    %esi,%esi
    72ea:	bf 18 00 00 00       	mov    $0x18,%edi
    72ef:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    72f5:	e8 56 e7 ff ff       	call   5a50 <fwp_heap_alloc>
    72fa:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7300:	48 89 c3             	mov    %rax,%rbx
    7303:	e9 26 ff ff ff       	jmp    722e <fwp_owned_entry161+0xce>
    7308:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    730f:	00 
    7310:	66 85 c0             	test   %ax,%ax
    7313:	74 93                	je     72a8 <fwp_owned_entry161+0x148>
    7315:	48 83 c4 10          	add    $0x10,%rsp
    7319:	48 89 d8             	mov    %rbx,%rax
    731c:	5b                   	pop    %rbx
    731d:	5d                   	pop    %rbp
    731e:	41 5e                	pop    %r14
    7320:	c3                   	ret
    7321:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7328:	48 89 ef             	mov    %rbp,%rdi
    732b:	e8 e0 df ff ff       	call   5310 <fwp_rc_forget_slot>
    7330:	e9 79 ff ff ff       	jmp    72ae <fwp_owned_entry161+0x14e>
    7335:	e8 c6 c3 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    733a:	e8 71 c9 ff ff       	call   3cb0 <fwp_heap_oom>
    733f:	90                   	nop

0000000000007340 <e161>:
    7340:	f3 0f 1e fa          	endbr64
    7344:	41 56                	push   %r14
    7346:	55                   	push   %rbp
    7347:	53                   	push   %rbx
    7348:	48 83 ec 10          	sub    $0x10,%rsp
    734c:	48 8b 07             	mov    (%rdi),%rax
    734f:	48 03 47 10          	add    0x10(%rdi),%rax
    7353:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7358:	0f 80 bf 01 00 00    	jo     751d <e161+0x1dd>
    735e:	49 89 c6             	mov    %rax,%r14
    7361:	8b 05 9d a7 01 00    	mov    0x1a79d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    7367:	48 8d 15 f2 93 01 00 	lea    0x193f2(%rip),%rdx        # 20760 <fwp_heap>
    736e:	85 c0                	test   %eax,%eax
    7370:	0f 84 62 01 00 00    	je     74d8 <e161+0x198>
    7376:	0f b6 05 85 a3 01 00 	movzbl 0x1a385(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    737d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7384:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7388:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    738c:	48 8b 18             	mov    (%rax),%rbx
    738f:	48 85 db             	test   %rbx,%rbx
    7392:	0f 84 18 01 00 00    	je     74b0 <e161+0x170>
    7398:	48 8b 13             	mov    (%rbx),%rdx
    739b:	48 f7 d2             	not    %rdx
    739e:	48 89 10             	mov    %rdx,(%rax)
    73a1:	48 83 fd 18          	cmp    $0x18,%rbp
    73a5:	76 27                	jbe    73ce <e161+0x8e>
    73a7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    73ab:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    73af:	31 f6                	xor    %esi,%esi
    73b1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    73b7:	48 c1 e8 03          	shr    $0x3,%rax
    73bb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    73c2:	00 
    73c3:	e8 f8 c0 ff ff       	call   34c0 <memset@plt>
    73c8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    73ce:	48 89 e8             	mov    %rbp,%rax
    73d1:	48 03 05 a8 a7 01 00 	add    0x1a7a8(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    73d8:	0f 82 44 01 00 00    	jb     7522 <e161+0x1e2>
    73de:	48 39 05 a3 a7 01 00 	cmp    %rax,0x1a7a3(%rip)        # 21b88 <fwp_heap+0x1428>
    73e5:	48 89 05 94 a7 01 00 	mov    %rax,0x1a794(%rip)        # 21b80 <fwp_heap+0x1420>
    73ec:	73 07                	jae    73f5 <e161+0xb5>
    73ee:	48 89 05 93 a7 01 00 	mov    %rax,0x1a793(%rip)        # 21b88 <fwp_heap+0x1428>
    73f5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    73f9:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    73fe:	f2 0f 58 0d 92 a7 01 	addsd  0x1a792(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7405:	00 
    7406:	f2 0f 11 0d 8a a7 01 	movsd  %xmm1,0x1a78a(%rip)        # 21b98 <fwp_heap+0x1438>
    740d:	00 
    740e:	48 8b 05 2b 57 00 00 	mov    0x572b(%rip),%rax        # cb40 <msg.4+0xc0>
    7415:	66 49 0f 6e d6       	movq   %r14,%xmm2
    741a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    741e:	48 89 03             	mov    %rax,(%rbx)
    7421:	48 89 d8             	mov    %rbx,%rax
    7424:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7428:	48 8b 15 09 a7 01 00 	mov    0x1a709(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    742f:	48 2b 05 da a6 01 00 	sub    0x1a6da(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7436:	48 c1 e2 10          	shl    $0x10,%rdx
    743a:	48 39 d0             	cmp    %rdx,%rax
    743d:	73 57                	jae    7496 <e161+0x156>
    743f:	48 89 c2             	mov    %rax,%rdx
    7442:	48 c1 ea 10          	shr    $0x10,%rdx
    7446:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    744a:	48 8b 15 07 a7 01 00 	mov    0x1a707(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7451:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7455:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7459:	48 85 ed             	test   %rbp,%rbp
    745c:	74 38                	je     7496 <e161+0x156>
    745e:	0f b6 0a             	movzbl (%rdx),%ecx
    7461:	80 f9 02             	cmp    $0x2,%cl
    7464:	0f 84 96 00 00 00    	je     7500 <e161+0x1c0>
    746a:	80 f9 01             	cmp    $0x1,%cl
    746d:	75 27                	jne    7496 <e161+0x156>
    746f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7472:	0f b7 c0             	movzwl %ax,%eax
    7475:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7478:	48 0f af c1          	imul   %rcx,%rax
    747c:	48 c1 e8 20          	shr    $0x20,%rax
    7480:	48 39 d0             	cmp    %rdx,%rax
    7483:	73 11                	jae    7496 <e161+0x156>
    7485:	48 01 c5             	add    %rax,%rbp
    7488:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    748c:	0f 84 7e 00 00 00    	je     7510 <e161+0x1d0>
    7492:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7496:	48 89 df             	mov    %rbx,%rdi
    7499:	e8 32 ef ff ff       	call   63d0 <fwp_rc_share>
    749e:	48 83 c4 10          	add    $0x10,%rsp
    74a2:	48 89 d8             	mov    %rbx,%rax
    74a5:	5b                   	pop    %rbx
    74a6:	5d                   	pop    %rbp
    74a7:	41 5e                	pop    %r14
    74a9:	c3                   	ret
    74aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74b0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    74b4:	48 85 db             	test   %rbx,%rbx
    74b7:	74 1f                	je     74d8 <e161+0x198>
    74b9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    74bd:	48 29 da             	sub    %rbx,%rdx
    74c0:	48 39 ea             	cmp    %rbp,%rdx
    74c3:	72 13                	jb     74d8 <e161+0x198>
    74c5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    74c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    74cd:	e9 cf fe ff ff       	jmp    73a1 <e161+0x61>
    74d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74d8:	31 f6                	xor    %esi,%esi
    74da:	bf 18 00 00 00       	mov    $0x18,%edi
    74df:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    74e5:	e8 66 e5 ff ff       	call   5a50 <fwp_heap_alloc>
    74ea:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    74f0:	48 89 c3             	mov    %rax,%rbx
    74f3:	e9 16 ff ff ff       	jmp    740e <e161+0xce>
    74f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74ff:	00 
    7500:	66 85 c0             	test   %ax,%ax
    7503:	75 91                	jne    7496 <e161+0x156>
    7505:	eb 81                	jmp    7488 <e161+0x148>
    7507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    750e:	00 00 
    7510:	48 89 ef             	mov    %rbp,%rdi
    7513:	e8 f8 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    7518:	e9 75 ff ff ff       	jmp    7492 <e161+0x152>
    751d:	e8 de c1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7522:	e8 89 c7 ff ff       	call   3cb0 <fwp_heap_oom>
    7527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    752e:	00 00 

0000000000007530 <fwp_drop4>:
    7530:	48 8b 15 01 a6 01 00 	mov    0x1a601(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7537:	48 89 f8             	mov    %rdi,%rax
    753a:	48 2b 05 cf a5 01 00 	sub    0x1a5cf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7541:	48 c1 e2 10          	shl    $0x10,%rdx
    7545:	48 39 d0             	cmp    %rdx,%rax
    7548:	0f 83 52 01 00 00    	jae    76a0 <fwp_drop4+0x170>
    754e:	48 83 ec 18          	sub    $0x18,%rsp
    7552:	4c 8d 05 07 92 01 00 	lea    0x19207(%rip),%r8        # 20760 <fwp_heap>
    7559:	48 89 c2             	mov    %rax,%rdx
    755c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7563:	48 c1 ea 10          	shr    $0x10,%rdx
    7567:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    756b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    756f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7573:	48 85 d2             	test   %rdx,%rdx
    7576:	74 46                	je     75be <fwp_drop4+0x8e>
    7578:	44 0f b6 09          	movzbl (%rcx),%r9d
    757c:	41 80 f9 02          	cmp    $0x2,%r9b
    7580:	0f 84 ca 00 00 00    	je     7650 <fwp_drop4+0x120>
    7586:	41 80 f9 01          	cmp    $0x1,%r9b
    758a:	75 32                	jne    75be <fwp_drop4+0x8e>
    758c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7590:	0f b7 c0             	movzwl %ax,%eax
    7593:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7596:	49 0f af c1          	imul   %r9,%rax
    759a:	48 c1 e8 20          	shr    $0x20,%rax
    759e:	48 39 c8             	cmp    %rcx,%rax
    75a1:	73 1b                	jae    75be <fwp_drop4+0x8e>
    75a3:	48 01 c2             	add    %rax,%rdx
    75a6:	0f b6 02             	movzbl (%rdx),%eax
    75a9:	84 c0                	test   %al,%al
    75ab:	74 11                	je     75be <fwp_drop4+0x8e>
    75ad:	3c 01                	cmp    $0x1,%al
    75af:	74 17                	je     75c8 <fwp_drop4+0x98>
    75b1:	3c ff                	cmp    $0xff,%al
    75b3:	0f 84 ef 00 00 00    	je     76a8 <fwp_drop4+0x178>
    75b9:	83 e8 01             	sub    $0x1,%eax
    75bc:	88 02                	mov    %al,(%rdx)
    75be:	48 83 c4 18          	add    $0x18,%rsp
    75c2:	c3                   	ret
    75c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    75c8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    75cc:	0f 88 8e 00 00 00    	js     7660 <fwp_drop4+0x130>
    75d2:	48 8b 15 5f a5 01 00 	mov    0x1a55f(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    75d9:	48 89 f8             	mov    %rdi,%rax
    75dc:	48 2b 05 2d a5 01 00 	sub    0x1a52d(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    75e3:	48 c1 e2 10          	shl    $0x10,%rdx
    75e7:	48 39 d0             	cmp    %rdx,%rax
    75ea:	73 d2                	jae    75be <fwp_drop4+0x8e>
    75ec:	48 89 c2             	mov    %rax,%rdx
    75ef:	48 c1 ea 10          	shr    $0x10,%rdx
    75f3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    75f7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    75fb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75ff:	48 85 c9             	test   %rcx,%rcx
    7602:	74 ba                	je     75be <fwp_drop4+0x8e>
    7604:	0f b6 32             	movzbl (%rdx),%esi
    7607:	40 80 fe 02          	cmp    $0x2,%sil
    760b:	74 33                	je     7640 <fwp_drop4+0x110>
    760d:	40 80 fe 01          	cmp    $0x1,%sil
    7611:	75 ab                	jne    75be <fwp_drop4+0x8e>
    7613:	8b 72 18             	mov    0x18(%rdx),%esi
    7616:	0f b7 c0             	movzwl %ax,%eax
    7619:	8b 52 1c             	mov    0x1c(%rdx),%edx
    761c:	48 0f af c6          	imul   %rsi,%rax
    7620:	48 c1 e8 20          	shr    $0x20,%rax
    7624:	48 39 d0             	cmp    %rdx,%rax
    7627:	73 95                	jae    75be <fwp_drop4+0x8e>
    7629:	48 01 c1             	add    %rax,%rcx
    762c:	80 39 01             	cmpb   $0x1,(%rcx)
    762f:	75 8d                	jne    75be <fwp_drop4+0x8e>
    7631:	48 83 c4 18          	add    $0x18,%rsp
    7635:	e9 16 df ff ff       	jmp    5550 <fwp_mem_free>
    763a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7640:	66 85 c0             	test   %ax,%ax
    7643:	74 e7                	je     762c <fwp_drop4+0xfc>
    7645:	48 83 c4 18          	add    $0x18,%rsp
    7649:	c3                   	ret
    764a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7650:	66 85 c0             	test   %ax,%ax
    7653:	0f 84 4d ff ff ff    	je     75a6 <fwp_drop4+0x76>
    7659:	48 83 c4 18          	add    $0x18,%rsp
    765d:	c3                   	ret
    765e:	66 90                	xchg   %ax,%ax
    7660:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7664:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7669:	e8 e2 ed ff ff       	call   6450 <fwp_rc_free_arr>
    766e:	4c 8d 05 eb 90 01 00 	lea    0x190eb(%rip),%r8        # 20760 <fwp_heap>
    7675:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    767a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7681:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7688:	48 c1 e2 10          	shl    $0x10,%rdx
    768c:	48 39 d0             	cmp    %rdx,%rax
    768f:	0f 83 29 ff ff ff    	jae    75be <fwp_drop4+0x8e>
    7695:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    769a:	e9 ba fe ff ff       	jmp    7559 <fwp_drop4+0x29>
    769f:	90                   	nop
    76a0:	c3                   	ret
    76a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76a8:	48 89 d0             	mov    %rdx,%rax
    76ab:	48 c1 e8 11          	shr    $0x11,%rax
    76af:	48 31 d0             	xor    %rdx,%rax
    76b2:	48 89 c1             	mov    %rax,%rcx
    76b5:	48 c1 e9 09          	shr    $0x9,%rcx
    76b9:	48 31 c8             	xor    %rcx,%rax
    76bc:	0f b6 c8             	movzbl %al,%ecx
    76bf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    76c6:	00 
    76c7:	48 85 c0             	test   %rax,%rax
    76ca:	75 1d                	jne    76e9 <fwp_drop4+0x1b9>
    76cc:	eb 56                	jmp    7724 <fwp_drop4+0x1f4>
    76ce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76dc:	00 00 00 00 
    76e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    76e4:	48 85 c0             	test   %rax,%rax
    76e7:	74 3b                	je     7724 <fwp_drop4+0x1f4>
    76e9:	48 89 c1             	mov    %rax,%rcx
    76ec:	48 39 10             	cmp    %rdx,(%rax)
    76ef:	75 ef                	jne    76e0 <fwp_drop4+0x1b0>
    76f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    76f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    76fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7704:	0f 85 b4 fe ff ff    	jne    75be <fwp_drop4+0x8e>
    770a:	48 89 d7             	mov    %rdx,%rdi
    770d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7712:	e8 f9 db ff ff       	call   5310 <fwp_rc_forget_slot>
    7717:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    771c:	c6 02 fe             	movb   $0xfe,(%rdx)
    771f:	e9 9a fe ff ff       	jmp    75be <fwp_drop4+0x8e>
    7724:	48 8d 3d 6d 50 00 00 	lea    0x506d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    772b:	e8 70 ca ff ff       	call   41a0 <fwp_trap>

0000000000007730 <fwp_caps161>:
    7730:	f3 0f 1e fa          	endbr64
    7734:	85 f6                	test   %esi,%esi
    7736:	74 08                	je     7740 <fwp_caps161+0x10>
    7738:	c3                   	ret
    7739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7740:	48 8b 15 f1 a3 01 00 	mov    0x1a3f1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7747:	48 89 f8             	mov    %rdi,%rax
    774a:	48 2b 05 bf a3 01 00 	sub    0x1a3bf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7751:	48 c1 e2 10          	shl    $0x10,%rdx
    7755:	48 39 d0             	cmp    %rdx,%rax
    7758:	73 de                	jae    7738 <fwp_caps161+0x8>
    775a:	48 89 c2             	mov    %rax,%rdx
    775d:	48 c1 ea 10          	shr    $0x10,%rdx
    7761:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7765:	48 8b 15 ec a3 01 00 	mov    0x1a3ec(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    776c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7770:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7774:	48 85 c9             	test   %rcx,%rcx
    7777:	74 bf                	je     7738 <fwp_caps161+0x8>
    7779:	0f b6 32             	movzbl (%rdx),%esi
    777c:	40 80 fe 02          	cmp    $0x2,%sil
    7780:	74 2e                	je     77b0 <fwp_caps161+0x80>
    7782:	40 80 fe 01          	cmp    $0x1,%sil
    7786:	75 b0                	jne    7738 <fwp_caps161+0x8>
    7788:	8b 72 18             	mov    0x18(%rdx),%esi
    778b:	0f b7 c0             	movzwl %ax,%eax
    778e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7791:	48 0f af c6          	imul   %rsi,%rax
    7795:	48 c1 e8 20          	shr    $0x20,%rax
    7799:	48 39 d0             	cmp    %rdx,%rax
    779c:	73 9a                	jae    7738 <fwp_caps161+0x8>
    779e:	48 01 c1             	add    %rax,%rcx
    77a1:	80 39 01             	cmpb   $0x1,(%rcx)
    77a4:	75 92                	jne    7738 <fwp_caps161+0x8>
    77a6:	e9 a5 dd ff ff       	jmp    5550 <fwp_mem_free>
    77ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    77b0:	66 85 c0             	test   %ax,%ax
    77b3:	74 ec                	je     77a1 <fwp_caps161+0x71>
    77b5:	c3                   	ret
    77b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    77bd:	00 00 00 

00000000000077c0 <fwp_args12>:
    77c0:	f3 0f 1e fa          	endbr64
    77c4:	85 d2                	test   %edx,%edx
    77c6:	74 04                	je     77cc <fwp_args12+0xc>
    77c8:	85 f6                	test   %esi,%esi
    77ca:	74 04                	je     77d0 <fwp_args12+0x10>
    77cc:	c3                   	ret
    77cd:	0f 1f 00             	nopl   (%rax)
    77d0:	48 8b 15 61 a3 01 00 	mov    0x1a361(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    77d7:	48 8b 07             	mov    (%rdi),%rax
    77da:	48 2b 05 2f a3 01 00 	sub    0x1a32f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    77e1:	48 c1 e2 10          	shl    $0x10,%rdx
    77e5:	48 39 d0             	cmp    %rdx,%rax
    77e8:	73 e2                	jae    77cc <fwp_args12+0xc>
    77ea:	48 89 c2             	mov    %rax,%rdx
    77ed:	48 c1 ea 10          	shr    $0x10,%rdx
    77f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77f5:	48 8b 15 5c a3 01 00 	mov    0x1a35c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    77fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7800:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7804:	48 85 ff             	test   %rdi,%rdi
    7807:	74 c3                	je     77cc <fwp_args12+0xc>
    7809:	0f b6 0a             	movzbl (%rdx),%ecx
    780c:	80 f9 02             	cmp    $0x2,%cl
    780f:	74 2f                	je     7840 <fwp_args12+0x80>
    7811:	80 f9 01             	cmp    $0x1,%cl
    7814:	75 b6                	jne    77cc <fwp_args12+0xc>
    7816:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7819:	0f b7 c0             	movzwl %ax,%eax
    781c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    781f:	48 0f af c1          	imul   %rcx,%rax
    7823:	48 c1 e8 20          	shr    $0x20,%rax
    7827:	48 39 d0             	cmp    %rdx,%rax
    782a:	73 a0                	jae    77cc <fwp_args12+0xc>
    782c:	48 01 c7             	add    %rax,%rdi
    782f:	0f b6 07             	movzbl (%rdi),%eax
    7832:	84 c0                	test   %al,%al
    7834:	74 96                	je     77cc <fwp_args12+0xc>
    7836:	3c fd                	cmp    $0xfd,%al
    7838:	77 0c                	ja     7846 <fwp_args12+0x86>
    783a:	83 c0 01             	add    $0x1,%eax
    783d:	88 07                	mov    %al,(%rdi)
    783f:	c3                   	ret
    7840:	66 85 c0             	test   %ax,%ax
    7843:	74 ea                	je     782f <fwp_args12+0x6f>
    7845:	c3                   	ret
    7846:	e9 a5 d9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    784b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007850 <fwp_args23>:
    7850:	f3 0f 1e fa          	endbr64
    7854:	85 d2                	test   %edx,%edx
    7856:	74 04                	je     785c <fwp_args23+0xc>
    7858:	85 f6                	test   %esi,%esi
    785a:	74 04                	je     7860 <fwp_args23+0x10>
    785c:	c3                   	ret
    785d:	0f 1f 00             	nopl   (%rax)
    7860:	48 8b 15 d1 a2 01 00 	mov    0x1a2d1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7867:	48 8b 07             	mov    (%rdi),%rax
    786a:	48 2b 05 9f a2 01 00 	sub    0x1a29f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7871:	48 c1 e2 10          	shl    $0x10,%rdx
    7875:	48 39 d0             	cmp    %rdx,%rax
    7878:	73 e2                	jae    785c <fwp_args23+0xc>
    787a:	48 89 c2             	mov    %rax,%rdx
    787d:	48 c1 ea 10          	shr    $0x10,%rdx
    7881:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7885:	48 8b 15 cc a2 01 00 	mov    0x1a2cc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    788c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7890:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7894:	48 85 ff             	test   %rdi,%rdi
    7897:	74 c3                	je     785c <fwp_args23+0xc>
    7899:	0f b6 0a             	movzbl (%rdx),%ecx
    789c:	80 f9 02             	cmp    $0x2,%cl
    789f:	74 2f                	je     78d0 <fwp_args23+0x80>
    78a1:	80 f9 01             	cmp    $0x1,%cl
    78a4:	75 b6                	jne    785c <fwp_args23+0xc>
    78a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78a9:	0f b7 c0             	movzwl %ax,%eax
    78ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78af:	48 0f af c1          	imul   %rcx,%rax
    78b3:	48 c1 e8 20          	shr    $0x20,%rax
    78b7:	48 39 d0             	cmp    %rdx,%rax
    78ba:	73 a0                	jae    785c <fwp_args23+0xc>
    78bc:	48 01 c7             	add    %rax,%rdi
    78bf:	0f b6 07             	movzbl (%rdi),%eax
    78c2:	84 c0                	test   %al,%al
    78c4:	74 96                	je     785c <fwp_args23+0xc>
    78c6:	3c fd                	cmp    $0xfd,%al
    78c8:	77 0c                	ja     78d6 <fwp_args23+0x86>
    78ca:	83 c0 01             	add    $0x1,%eax
    78cd:	88 07                	mov    %al,(%rdi)
    78cf:	c3                   	ret
    78d0:	66 85 c0             	test   %ax,%ax
    78d3:	74 ea                	je     78bf <fwp_args23+0x6f>
    78d5:	c3                   	ret
    78d6:	e9 15 d9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    78db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078e0 <fwp_caps12>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	48 83 ec 18          	sub    $0x18,%rsp
    78e8:	8b 57 04             	mov    0x4(%rdi),%edx
    78eb:	48 89 f8             	mov    %rdi,%rax
    78ee:	85 d2                	test   %edx,%edx
    78f0:	0f 84 9a 00 00 00    	je     7990 <fwp_caps12+0xb0>
    78f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    78fa:	85 f6                	test   %esi,%esi
    78fc:	0f 85 9e 00 00 00    	jne    79a0 <fwp_caps12+0xc0>
    7902:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7907:	e8 54 ec ff ff       	call   6560 <fwp_drop0>
    790c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7911:	48 8b 0d 20 a2 01 00 	mov    0x1a220(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    7918:	48 89 c2             	mov    %rax,%rdx
    791b:	48 2b 15 ee a1 01 00 	sub    0x1a1ee(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    7922:	48 c1 e1 10          	shl    $0x10,%rcx
    7926:	48 39 ca             	cmp    %rcx,%rdx
    7929:	73 6d                	jae    7998 <fwp_caps12+0xb8>
    792b:	48 89 d1             	mov    %rdx,%rcx
    792e:	48 c1 e9 10          	shr    $0x10,%rcx
    7932:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7936:	48 8b 0d 1b a2 01 00 	mov    0x1a21b(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    793d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7941:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7945:	48 85 f6             	test   %rsi,%rsi
    7948:	74 4e                	je     7998 <fwp_caps12+0xb8>
    794a:	0f b6 39             	movzbl (%rcx),%edi
    794d:	40 80 ff 02          	cmp    $0x2,%dil
    7951:	0f 84 b9 00 00 00    	je     7a10 <fwp_caps12+0x130>
    7957:	40 80 ff 01          	cmp    $0x1,%dil
    795b:	75 3b                	jne    7998 <fwp_caps12+0xb8>
    795d:	8b 79 18             	mov    0x18(%rcx),%edi
    7960:	0f b7 d2             	movzwl %dx,%edx
    7963:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7966:	48 0f af d7          	imul   %rdi,%rdx
    796a:	48 c1 ea 20          	shr    $0x20,%rdx
    796e:	48 39 ca             	cmp    %rcx,%rdx
    7971:	73 25                	jae    7998 <fwp_caps12+0xb8>
    7973:	48 01 d6             	add    %rdx,%rsi
    7976:	80 3e 01             	cmpb   $0x1,(%rsi)
    7979:	75 1d                	jne    7998 <fwp_caps12+0xb8>
    797b:	48 89 c7             	mov    %rax,%rdi
    797e:	48 83 c4 18          	add    $0x18,%rsp
    7982:	e9 c9 db ff ff       	jmp    5550 <fwp_mem_free>
    7987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    798e:	00 00 
    7990:	85 f6                	test   %esi,%esi
    7992:	0f 84 79 ff ff ff    	je     7911 <fwp_caps12+0x31>
    7998:	48 83 c4 18          	add    $0x18,%rsp
    799c:	c3                   	ret
    799d:	0f 1f 00             	nopl   (%rax)
    79a0:	48 8b 05 91 a1 01 00 	mov    0x1a191(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    79a7:	48 2b 3d 62 a1 01 00 	sub    0x1a162(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    79ae:	48 c1 e0 10          	shl    $0x10,%rax
    79b2:	48 39 c7             	cmp    %rax,%rdi
    79b5:	73 e1                	jae    7998 <fwp_caps12+0xb8>
    79b7:	48 89 f8             	mov    %rdi,%rax
    79ba:	48 c1 e8 10          	shr    $0x10,%rax
    79be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    79c2:	48 8b 05 8f a1 01 00 	mov    0x1a18f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    79c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    79cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    79d1:	48 85 c0             	test   %rax,%rax
    79d4:	74 c2                	je     7998 <fwp_caps12+0xb8>
    79d6:	0f b6 0a             	movzbl (%rdx),%ecx
    79d9:	80 f9 02             	cmp    $0x2,%cl
    79dc:	74 42                	je     7a20 <fwp_caps12+0x140>
    79de:	80 f9 01             	cmp    $0x1,%cl
    79e1:	75 b5                	jne    7998 <fwp_caps12+0xb8>
    79e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79e6:	0f b7 ff             	movzwl %di,%edi
    79e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79ec:	48 0f af f9          	imul   %rcx,%rdi
    79f0:	48 c1 ef 20          	shr    $0x20,%rdi
    79f4:	48 39 d7             	cmp    %rdx,%rdi
    79f7:	73 9f                	jae    7998 <fwp_caps12+0xb8>
    79f9:	48 01 f8             	add    %rdi,%rax
    79fc:	0f b6 10             	movzbl (%rax),%edx
    79ff:	84 d2                	test   %dl,%dl
    7a01:	74 95                	je     7998 <fwp_caps12+0xb8>
    7a03:	80 fa fd             	cmp    $0xfd,%dl
    7a06:	77 23                	ja     7a2b <fwp_caps12+0x14b>
    7a08:	83 c2 01             	add    $0x1,%edx
    7a0b:	88 10                	mov    %dl,(%rax)
    7a0d:	eb 89                	jmp    7998 <fwp_caps12+0xb8>
    7a0f:	90                   	nop
    7a10:	66 85 d2             	test   %dx,%dx
    7a13:	0f 85 7f ff ff ff    	jne    7998 <fwp_caps12+0xb8>
    7a19:	e9 58 ff ff ff       	jmp    7976 <fwp_caps12+0x96>
    7a1e:	66 90                	xchg   %ax,%ax
    7a20:	66 85 ff             	test   %di,%di
    7a23:	0f 85 6f ff ff ff    	jne    7998 <fwp_caps12+0xb8>
    7a29:	eb d1                	jmp    79fc <fwp_caps12+0x11c>
    7a2b:	48 89 c7             	mov    %rax,%rdi
    7a2e:	48 83 c4 18          	add    $0x18,%rsp
    7a32:	e9 b9 d7 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a3e:	00 00 

0000000000007a40 <f12>:
    7a40:	41 57                	push   %r15
    7a42:	41 56                	push   %r14
    7a44:	41 55                	push   %r13
    7a46:	41 54                	push   %r12
    7a48:	4c 8d 25 31 f1 ff ff 	lea    -0xecf(%rip),%r12        # 6b80 <fwp_tape_scope_release>
    7a4f:	55                   	push   %rbp
    7a50:	53                   	push   %rbx
    7a51:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    7a58:	48 8b 15 d9 a0 01 00 	mov    0x1a0d9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7a5f:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    7a64:	48 c1 e2 10          	shl    $0x10,%rdx
    7a68:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7a6f:	00 00 
    7a71:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7a78:	00 
    7a79:	31 c0                	xor    %eax,%eax
    7a7b:	48 8b 05 76 a9 01 00 	mov    0x1a976(%rip),%rax        # 223f8 <fwp_cleanups>
    7a82:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    7a89:	ff 
    7a8a:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
    7a8f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    7a94:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    7a99:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7a9e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7aa3:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    7aa8:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7aad:	48 89 05 44 a9 01 00 	mov    %rax,0x1a944(%rip)        # 223f8 <fwp_cleanups>
    7ab4:	48 8d 05 55 85 00 00 	lea    0x8555(%rip),%rax        # 10010 <fc23>
    7abb:	48 2b 05 4e a0 01 00 	sub    0x1a04e(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7ac2:	48 39 d0             	cmp    %rdx,%rax
    7ac5:	73 5d                	jae    7b24 <f12+0xe4>
    7ac7:	48 89 c2             	mov    %rax,%rdx
    7aca:	48 c1 ea 10          	shr    $0x10,%rdx
    7ace:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ad2:	48 8b 15 7f a0 01 00 	mov    0x1a07f(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7ad9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7add:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ae1:	48 85 ff             	test   %rdi,%rdi
    7ae4:	74 3e                	je     7b24 <f12+0xe4>
    7ae6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ae9:	80 f9 02             	cmp    $0x2,%cl
    7aec:	0f 84 7e 11 00 00    	je     8c70 <f12+0x1230>
    7af2:	80 f9 01             	cmp    $0x1,%cl
    7af5:	75 2d                	jne    7b24 <f12+0xe4>
    7af7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7afa:	0f b7 c0             	movzwl %ax,%eax
    7afd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b00:	48 0f af c1          	imul   %rcx,%rax
    7b04:	48 c1 e8 20          	shr    $0x20,%rax
    7b08:	48 39 d0             	cmp    %rdx,%rax
    7b0b:	73 17                	jae    7b24 <f12+0xe4>
    7b0d:	48 01 c7             	add    %rax,%rdi
    7b10:	0f b6 07             	movzbl (%rdi),%eax
    7b13:	84 c0                	test   %al,%al
    7b15:	74 0d                	je     7b24 <f12+0xe4>
    7b17:	3c fd                	cmp    $0xfd,%al
    7b19:	0f 87 86 13 00 00    	ja     8ea5 <f12+0x1465>
    7b1f:	83 c0 01             	add    $0x1,%eax
    7b22:	88 07                	mov    %al,(%rdi)
    7b24:	48 8d 3d e5 84 00 00 	lea    0x84e5(%rip),%rdi        # 10010 <fc23>
    7b2b:	e8 20 ed ff ff       	call   6850 <fwp_closure_drop>
    7b30:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    7b35:	48 85 c0             	test   %rax,%rax
    7b38:	0f 84 92 12 00 00    	je     8dd0 <f12+0x1390>
    7b3e:	31 d2                	xor    %edx,%edx
    7b40:	48 8b 40 10          	mov    0x10(%rax),%rax
    7b44:	48 83 c2 01          	add    $0x1,%rdx
    7b48:	48 85 c0             	test   %rax,%rax
    7b4b:	75 f3                	jne    7b40 <f12+0x100>
    7b4d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7b54:	0f 87 11 14 00 00    	ja     8f6b <f12+0x152b>
    7b5a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7b5f:	44 8b 05 fa 84 00 00 	mov    0x84fa(%rip),%r8d        # 10060 <registered_finish.0>
    7b66:	45 85 c0             	test   %r8d,%r8d
    7b69:	0f 84 d1 10 00 00    	je     8c40 <f12+0x1200>
    7b6f:	48 8b 1d 62 85 01 00 	mov    0x18562(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    7b76:	4c 8b 2d 6b 85 01 00 	mov    0x1856b(%rip),%r13        # 200e8 <fwp_ntapes>
    7b7d:	4c 39 eb             	cmp    %r13,%rbx
    7b80:	0f 8d e2 00 00 00    	jge    7c68 <f12+0x228>
    7b86:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7b8a:	48 03 05 5f 85 01 00 	add    0x1855f(%rip),%rax        # 200f0 <fwp_tapes>
    7b91:	0f 1f 40 00          	nopl   0x0(%rax)
    7b95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b9c:	00 00 00 00 
    7ba0:	8b 78 04             	mov    0x4(%rax),%edi
    7ba3:	85 ff                	test   %edi,%edi
    7ba5:	75 0c                	jne    7bb3 <f12+0x173>
    7ba7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7bad:	0f 86 b5 00 00 00    	jbe    7c68 <f12+0x228>
    7bb3:	48 83 c3 01          	add    $0x1,%rbx
    7bb7:	48 83 c0 68          	add    $0x68,%rax
    7bbb:	4c 39 eb             	cmp    %r13,%rbx
    7bbe:	75 e0                	jne    7ba0 <f12+0x160>
    7bc0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    7bc7:	0f 8f 19 14 00 00    	jg     8fe6 <f12+0x15a6>
    7bcd:	4c 39 2d 0c 85 01 00 	cmp    %r13,0x1850c(%rip)        # 200e0 <fwp_tapes_cap>
    7bd4:	48 8b 2d 15 85 01 00 	mov    0x18515(%rip),%rbp        # 200f0 <fwp_tapes>
    7bdb:	75 4a                	jne    7c27 <f12+0x1e7>
    7bdd:	4d 85 ed             	test   %r13,%r13
    7be0:	0f 84 4b 12 00 00    	je     8e31 <f12+0x13f1>
    7be6:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    7beb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7bf0:	48 39 c3             	cmp    %rax,%rbx
    7bf3:	48 0f 4f d8          	cmovg  %rax,%rbx
    7bf7:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7bfb:	48 89 ef             	mov    %rbp,%rdi
    7bfe:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7c03:	e8 c8 b9 ff ff       	call   35d0 <realloc@plt>
    7c08:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7c0d:	48 85 c0             	test   %rax,%rax
    7c10:	48 89 c5             	mov    %rax,%rbp
    7c13:	0f 84 93 13 00 00    	je     8fac <f12+0x156c>
    7c19:	48 89 05 d0 84 01 00 	mov    %rax,0x184d0(%rip)        # 200f0 <fwp_tapes>
    7c20:	48 89 1d b9 84 01 00 	mov    %rbx,0x184b9(%rip)        # 200e0 <fwp_tapes_cap>
    7c27:	49 6b c5 68          	imul   $0x68,%r13,%rax
    7c2b:	4c 89 eb             	mov    %r13,%rbx
    7c2e:	48 01 e8             	add    %rbp,%rax
    7c31:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7c35:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7c3c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7c40:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7c47:	00 
    7c48:	48 29 f8             	sub    %rdi,%rax
    7c4b:	8d 48 68             	lea    0x68(%rax),%ecx
    7c4e:	31 c0                	xor    %eax,%eax
    7c50:	c1 e9 03             	shr    $0x3,%ecx
    7c53:	f3 48 ab             	rep stos %rax,(%rdi)
    7c56:	49 8d 45 01          	lea    0x1(%r13),%rax
    7c5a:	48 89 05 87 84 01 00 	mov    %rax,0x18487(%rip)        # 200e8 <fwp_ntapes>
    7c61:	eb 15                	jmp    7c78 <f12+0x238>
    7c63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c68:	49 39 dd             	cmp    %rbx,%r13
    7c6b:	0f 84 4f ff ff ff    	je     7bc0 <f12+0x180>
    7c71:	48 8b 2d 78 84 01 00 	mov    0x18478(%rip),%rbp        # 200f0 <fwp_tapes>
    7c78:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    7c7c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7c80:	48 8d 3d 38 44 00 00 	lea    0x4438(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    7c87:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7c8b:	49 01 ee             	add    %rbp,%r14
    7c8e:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    7c95:	00 
    7c96:	e8 05 b7 ff ff       	call   33a0 <getenv@plt>
    7c9b:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7ca0:	48 85 c0             	test   %rax,%rax
    7ca3:	74 09                	je     7cae <f12+0x26e>
    7ca5:	80 38 30             	cmpb   $0x30,(%rax)
    7ca8:	0f 84 82 06 00 00    	je     8330 <f12+0x8f0>
    7cae:	48 83 3d d2 83 01 00 	cmpq   $0x0,0x183d2(%rip)        # 20088 <fwp_tape_cached_bytes>
    7cb5:	00 
    7cb6:	0f 85 14 10 00 00    	jne    8cd0 <f12+0x1290>
    7cbc:	41 8b 06             	mov    (%r14),%eax
    7cbf:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    7cc3:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    7cca:	00 
    7ccb:	4c 89 2d 06 84 01 00 	mov    %r13,0x18406(%rip)        # 200d8 <fwp_tape_next_slot>
    7cd2:	8d 70 01             	lea    0x1(%rax),%esi
    7cd5:	48 8b 05 1c a7 01 00 	mov    0x1a71c(%rip),%rax        # 223f8 <fwp_cleanups>
    7cdc:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    7ce1:	41 89 36             	mov    %esi,(%r14)
    7ce4:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    7ceb:	00 
    7cec:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    7cf3:	ff 
    7cf4:	48 85 c0             	test   %rax,%rax
    7cf7:	75 13                	jne    7d0c <f12+0x2cc>
    7cf9:	e9 dc 12 00 00       	jmp    8fda <f12+0x159a>
    7cfe:	66 90                	xchg   %ax,%ax
    7d00:	48 8b 00             	mov    (%rax),%rax
    7d03:	48 85 c0             	test   %rax,%rax
    7d06:	0f 84 ce 12 00 00    	je     8fda <f12+0x159a>
    7d0c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    7d10:	75 ee                	jne    7d00 <f12+0x2c0>
    7d12:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7d16:	89 df                	mov    %ebx,%edi
    7d18:	48 63 01             	movslq (%rcx),%rax
    7d1b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    7d1f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    7d23:	85 c0                	test   %eax,%eax
    7d25:	78 08                	js     7d2f <f12+0x2ef>
    7d27:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7d2b:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7d2f:	89 39                	mov    %edi,(%rcx)
    7d31:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    7d36:	31 c9                	xor    %ecx,%ecx
    7d38:	48 89 f8             	mov    %rdi,%rax
    7d3b:	48 85 ff             	test   %rdi,%rdi
    7d3e:	0f 84 6c 0d 00 00    	je     8ab0 <f12+0x1070>
    7d44:	90                   	nop
    7d45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d4c:	00 00 00 00 
    7d50:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d54:	48 83 c1 01          	add    $0x1,%rcx
    7d58:	48 85 c0             	test   %rax,%rax
    7d5b:	75 f3                	jne    7d50 <f12+0x310>
    7d5d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7d62:	0f 1f 00             	nopl   (%rax)
    7d65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d6c:	00 00 00 00 
    7d70:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7d74:	48 83 c0 01          	add    $0x1,%rax
    7d78:	48 85 d2             	test   %rdx,%rdx
    7d7b:	75 f3                	jne    7d70 <f12+0x330>
    7d7d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7d84:	ff ff 1f 
    7d87:	48 39 c2             	cmp    %rax,%rdx
    7d8a:	0f 82 e7 11 00 00    	jb     8f77 <f12+0x1537>
    7d90:	48 85 c9             	test   %rcx,%rcx
    7d93:	0f 8e 17 0d 00 00    	jle    8ab0 <f12+0x1070>
    7d99:	48 39 c1             	cmp    %rax,%rcx
    7d9c:	48 0f 46 c1          	cmovbe %rcx,%rax
    7da0:	49 89 c4             	mov    %rax,%r12
    7da3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7da7:	0f 85 ca 11 00 00    	jne    8f77 <f12+0x1537>
    7dad:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    7db1:	48 c1 e6 10          	shl    $0x10,%rsi
    7db5:	49 09 f5             	or     %rsi,%r13
    7db8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    7dbf:	00 
    7dc0:	be 02 00 00 00       	mov    $0x2,%esi
    7dc5:	e8 86 dc ff ff       	call   5a50 <fwp_heap_alloc>
    7dca:	4c 89 30             	mov    %r14,(%rax)
    7dcd:	48 8b 15 64 9d 01 00 	mov    0x19d64(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7dd4:	48 89 c3             	mov    %rax,%rbx
    7dd7:	48 2b 05 32 9d 01 00 	sub    0x19d32(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7dde:	48 c1 e2 10          	shl    $0x10,%rdx
    7de2:	48 39 d0             	cmp    %rdx,%rax
    7de5:	0f 83 b5 0f 00 00    	jae    8da0 <f12+0x1360>
    7deb:	48 89 c2             	mov    %rax,%rdx
    7dee:	48 c1 ea 10          	shr    $0x10,%rdx
    7df2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7df6:	48 8b 15 5b 9d 01 00 	mov    0x19d5b(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7dfd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e01:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    7e05:	4d 85 f6             	test   %r14,%r14
    7e08:	74 38                	je     7e42 <f12+0x402>
    7e0a:	0f b6 0a             	movzbl (%rdx),%ecx
    7e0d:	80 f9 02             	cmp    $0x2,%cl
    7e10:	0f 84 07 0d 00 00    	je     8b1d <f12+0x10dd>
    7e16:	80 f9 01             	cmp    $0x1,%cl
    7e19:	75 27                	jne    7e42 <f12+0x402>
    7e1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e1e:	0f b7 c0             	movzwl %ax,%eax
    7e21:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e24:	48 0f af c1          	imul   %rcx,%rax
    7e28:	48 c1 e8 20          	shr    $0x20,%rax
    7e2c:	48 39 d0             	cmp    %rdx,%rax
    7e2f:	73 11                	jae    7e42 <f12+0x402>
    7e31:	49 01 c6             	add    %rax,%r14
    7e34:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7e38:	0f 84 02 10 00 00    	je     8e40 <f12+0x1400>
    7e3e:	41 c6 06 01          	movb   $0x1,(%r14)
    7e42:	4d 85 e4             	test   %r12,%r12
    7e45:	74 6c                	je     7eb3 <f12+0x473>
    7e47:	4c 89 e9             	mov    %r13,%rcx
    7e4a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7e4f:	31 c0                	xor    %eax,%eax
    7e51:	48 c1 e1 20          	shl    $0x20,%rcx
    7e55:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 
    7e5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e66:	00 00 00 00 
    7e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e71:	00 00 00 00 
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	48 89 c6             	mov    %rax,%rsi
    7e83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    7e88:	48 01 ce             	add    %rcx,%rsi
    7e8b:	0f 80 cd 10 00 00    	jo     8f5e <f12+0x151e>
    7e91:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    7e96:	48 89 c6             	mov    %rax,%rsi
    7e99:	48 83 c0 01          	add    $0x1,%rax
    7e9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    7ea1:	48 c1 e6 04          	shl    $0x4,%rsi
    7ea5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    7eaa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7eae:	4c 39 e0             	cmp    %r12,%rax
    7eb1:	72 cd                	jb     7e80 <f12+0x440>
    7eb3:	48 8b 03             	mov    (%rbx),%rax
    7eb6:	48 d1 e8             	shr    $1,%rax
    7eb9:	0f 85 89 0c 00 00    	jne    8b48 <f12+0x1108>
    7ebf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    7ec6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    7ecd:	0f 1f 00             	nopl   (%rax)
    7ed0:	48 89 df             	mov    %rbx,%rdi
    7ed3:	4d 63 e5             	movslq %r13d,%r12
    7ed6:	e8 55 f6 ff ff       	call   7530 <fwp_drop4>
    7edb:	4c 89 e7             	mov    %r12,%rdi
    7ede:	e8 9d c5 ff ff       	call   4480 <fwp_tape_of>
    7ee3:	48 89 c6             	mov    %rax,%rsi
    7ee6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    7eeb:	0f 85 01 11 00 00    	jne    8ff2 <f12+0x15b2>
    7ef1:	48 89 c7             	mov    %rax,%rdi
    7ef4:	e8 07 bd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7ef9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    7efd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7f02:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7f09:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    7f0d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    7f11:	66 49 0f 6e fe       	movq   %r14,%xmm7
    7f16:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    7f1b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    7f20:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    7f24:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    7f28:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7f2e:	77 19                	ja     7f49 <f12+0x509>
    7f30:	41 0f b7 c5          	movzwl %r13w,%eax
    7f34:	83 e8 01             	sub    $0x1,%eax
    7f37:	48 98                	cltq
    7f39:	48 3b 05 98 81 01 00 	cmp    0x18198(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    7f40:	7d 07                	jge    7f49 <f12+0x509>
    7f42:	48 89 05 8f 81 01 00 	mov    %rax,0x1818f(%rip)        # 200d8 <fwp_tape_next_slot>
    7f49:	48 8b 05 a8 a4 01 00 	mov    0x1a4a8(%rip),%rax        # 223f8 <fwp_cleanups>
    7f50:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7f54:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
    7f5b:	00 
    7f5c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7f63:	00 
    7f64:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    7f68:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7f6d:	48 8d 05 bc ce ff ff 	lea    -0x3144(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    7f74:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    7f79:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    7f7e:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    7f82:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    7f86:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7f8d:	00 
    7f8e:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    7f95:	00 
    7f96:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    7f9d:	00 
    7f9e:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
    7fa5:	00 
    7fa6:	48 89 05 4b a4 01 00 	mov    %rax,0x1a44b(%rip)        # 223f8 <fwp_cleanups>
    7fad:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
    7fb4:	00 
    7fb5:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
    7fbc:	00 
    7fbd:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    7fc4:	00 
    7fc5:	4d 85 ff             	test   %r15,%r15
    7fc8:	0f 88 b2 0c 00 00    	js     8c80 <f12+0x1240>
    7fce:	4c 89 f8             	mov    %r15,%rax
    7fd1:	48 c1 f8 20          	sar    $0x20,%rax
    7fd5:	49 39 c4             	cmp    %rax,%r12
    7fd8:	0f 85 63 0f 00 00    	jne    8f41 <f12+0x1501>
    7fde:	45 89 fa             	mov    %r15d,%r10d
    7fe1:	4d 89 d4             	mov    %r10,%r12
    7fe4:	4c 39 d2             	cmp    %r10,%rdx
    7fe7:	0f 8e 48 0f 00 00    	jle    8f35 <f12+0x14f5>
    7fed:	4c 39 d5             	cmp    %r10,%rbp
    7ff0:	0f 8e fa 0b 00 00    	jle    8bf0 <f12+0x11b0>
    7ff6:	4c 39 f5             	cmp    %r14,%rbp
    7ff9:	0f 8e 41 0d 00 00    	jle    8d40 <f12+0x1300>
    7fff:	49 89 ed             	mov    %rbp,%r13
    8002:	4d 85 f6             	test   %r14,%r14
    8005:	4d 0f 44 f5          	cmove  %r13,%r14
    8009:	eb 2a                	jmp    8035 <f12+0x5f5>
    800b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8012:	00 00 00 
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8024:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    802b:	4c 89 e8             	mov    %r13,%rax
    802e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8032:	49 89 c6             	mov    %rax,%r14
    8035:	4d 39 ee             	cmp    %r13,%r14
    8038:	7c e6                	jl     8020 <f12+0x5e0>
    803a:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    803f:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8043:	48 85 c9             	test   %rcx,%rcx
    8046:	0f 84 64 0d 00 00    	je     8db0 <f12+0x1370>
    804c:	48 89 cf             	mov    %rcx,%rdi
    804f:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8056:	00 
    8057:	e8 74 b5 ff ff       	call   35d0 <realloc@plt>
    805c:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8061:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8067:	48 89 c1             	mov    %rax,%rcx
    806a:	48 85 c9             	test   %rcx,%rcx
    806d:	0f 84 1c 0f 00 00    	je     8f8f <f12+0x154f>
    8073:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    807a:	00 
    807b:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    8082:	00 
    8083:	4d 85 ed             	test   %r13,%r13
    8086:	0f 85 da 0d 00 00    	jne    8e66 <f12+0x1426>
    808c:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    8093:	4d 85 ff             	test   %r15,%r15
    8096:	78 17                	js     80af <f12+0x66f>
    8098:	45 89 fa             	mov    %r15d,%r10d
    809b:	f2 0f 10 05 8d 4a 00 	movsd  0x4a8d(%rip),%xmm0        # cb30 <msg.4+0xb0>
    80a2:	00 
    80a3:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    80a9:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    80af:	4c 39 e5             	cmp    %r12,%rbp
    80b2:	0f 8f 8a 00 00 00    	jg     8142 <f12+0x702>
    80b8:	0f 12 f3             	movhlps %xmm3,%xmm6
    80bb:	66 48 0f 7e de       	movq   %xmm3,%rsi
    80c0:	0f 12 da             	movhlps %xmm2,%xmm3
    80c3:	49 29 ec             	sub    %rbp,%r12
    80c6:	66 49 0f 7e db       	movq   %xmm3,%r11
    80cb:	66 48 0f 7e f7       	movq   %xmm6,%rdi
    80d0:	66 49 0f 7e d2       	movq   %xmm2,%r10
    80d5:	4c 8d 04 e9          	lea    (%rcx,%rbp,8),%r8
    80d9:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    80dd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    80e1:	48 29 fe             	sub    %rdi,%rsi
    80e4:	4a 8d 04 a7          	lea    (%rdi,%r12,4),%rax
    80e8:	4d 29 d8             	sub    %r11,%r8
    80eb:	4d 29 da             	sub    %r11,%r10
    80ee:	eb 04                	jmp    80f4 <f12+0x6b4>
    80f0:	48 83 e8 04          	sub    $0x4,%rax
    80f4:	f2 41 0f 10 04 10    	movsd  (%r8,%rdx,1),%xmm0
    80fa:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    80fe:	7a 02                	jp     8102 <f12+0x6c2>
    8100:	74 37                	je     8139 <f12+0x6f9>
    8102:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8106:	45 85 db             	test   %r11d,%r11d
    8109:	78 16                	js     8121 <f12+0x6e1>
    810b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8111:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8115:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    811b:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8121:	4c 63 18             	movslq (%rax),%r11
    8124:	45 85 db             	test   %r11d,%r11d
    8127:	78 10                	js     8139 <f12+0x6f9>
    8129:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    812d:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    8133:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    8139:	48 83 ea 08          	sub    $0x8,%rdx
    813d:	48 39 c7             	cmp    %rax,%rdi
    8140:	75 ae                	jne    80f0 <f12+0x6b0>
    8142:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8149:	ff ff 1f 
    814c:	48 39 e8             	cmp    %rbp,%rax
    814f:	0f 82 2e 0e 00 00    	jb     8f83 <f12+0x1543>
    8155:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    815c:	00 
    815d:	be 02 00 00 00       	mov    $0x2,%esi
    8162:	48 89 0c 24          	mov    %rcx,(%rsp)
    8166:	e8 e5 d8 ff ff       	call   5a50 <fwp_heap_alloc>
    816b:	48 8b 0c 24          	mov    (%rsp),%rcx
    816f:	48 89 28             	mov    %rbp,(%rax)
    8172:	49 89 c4             	mov    %rax,%r12
    8175:	31 c0                	xor    %eax,%eax
    8177:	48 85 ed             	test   %rbp,%rbp
    817a:	74 16                	je     8192 <f12+0x752>
    817c:	0f 1f 40 00          	nopl   0x0(%rax)
    8180:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8184:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    8189:	48 83 c0 01          	add    $0x1,%rax
    818d:	48 39 c5             	cmp    %rax,%rbp
    8190:	75 ee                	jne    8180 <f12+0x740>
    8192:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
    8197:	48 89 df             	mov    %rbx,%rdi
    819a:	4c 89 2d 57 a2 01 00 	mov    %r13,0x1a257(%rip)        # 223f8 <fwp_cleanups>
    81a1:	e8 8a cc ff ff       	call   4e30 <fwp_tape_buffers_release>
    81a6:	48 8b 15 8b 99 01 00 	mov    0x1998b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    81ad:	4c 89 e0             	mov    %r12,%rax
    81b0:	48 2b 05 59 99 01 00 	sub    0x19959(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    81b7:	48 c1 e2 10          	shl    $0x10,%rdx
    81bb:	48 39 d0             	cmp    %rdx,%rax
    81be:	73 55                	jae    8215 <f12+0x7d5>
    81c0:	48 89 c2             	mov    %rax,%rdx
    81c3:	48 c1 ea 10          	shr    $0x10,%rdx
    81c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81cb:	48 8b 15 86 99 01 00 	mov    0x19986(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    81d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81d6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    81da:	48 85 db             	test   %rbx,%rbx
    81dd:	74 36                	je     8215 <f12+0x7d5>
    81df:	0f b6 0a             	movzbl (%rdx),%ecx
    81e2:	80 f9 02             	cmp    $0x2,%cl
    81e5:	0f 84 c5 0a 00 00    	je     8cb0 <f12+0x1270>
    81eb:	80 f9 01             	cmp    $0x1,%cl
    81ee:	75 25                	jne    8215 <f12+0x7d5>
    81f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81f3:	0f b7 c0             	movzwl %ax,%eax
    81f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81f9:	48 0f af c1          	imul   %rcx,%rax
    81fd:	48 c1 e8 20          	shr    $0x20,%rax
    8201:	48 39 d0             	cmp    %rdx,%rax
    8204:	73 0f                	jae    8215 <f12+0x7d5>
    8206:	48 01 c3             	add    %rax,%rbx
    8209:	80 3b ff             	cmpb   $0xff,(%rbx)
    820c:	0f 84 3b 0c 00 00    	je     8e4d <f12+0x140d>
    8212:	c6 03 01             	movb   $0x1,(%rbx)
    8215:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    821a:	0f 85 2b b5 ff ff    	jne    374b <f12.cold>
    8220:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    8225:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    822a:	48 89 05 c7 a1 01 00 	mov    %rax,0x1a1c7(%rip)        # 223f8 <fwp_cleanups>
    8231:	e8 4a e9 ff ff       	call   6b80 <fwp_tape_scope_release>
    8236:	49 8b 04 24          	mov    (%r12),%rax
    823a:	49 89 c5             	mov    %rax,%r13
    823d:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8242:	48 85 c0             	test   %rax,%rax
    8245:	0f 88 b5 07 00 00    	js     8a00 <f12+0xfc0>
    824b:	48 8b 15 e6 98 01 00 	mov    0x198e6(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8252:	4c 89 e0             	mov    %r12,%rax
    8255:	48 2b 05 b4 98 01 00 	sub    0x198b4(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    825c:	48 c1 e2 10          	shl    $0x10,%rdx
    8260:	48 39 d0             	cmp    %rdx,%rax
    8263:	0f 83 97 07 00 00    	jae    8a00 <f12+0xfc0>
    8269:	48 89 c2             	mov    %rax,%rdx
    826c:	48 c1 ea 10          	shr    $0x10,%rdx
    8270:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8274:	48 8b 15 dd 98 01 00 	mov    0x198dd(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    827b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    827f:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8283:	48 85 c9             	test   %rcx,%rcx
    8286:	0f 84 74 07 00 00    	je     8a00 <f12+0xfc0>
    828c:	0f b6 32             	movzbl (%rdx),%esi
    828f:	40 80 fe 02          	cmp    $0x2,%sil
    8293:	0f 84 57 07 00 00    	je     89f0 <f12+0xfb0>
    8299:	40 80 fe 01          	cmp    $0x1,%sil
    829d:	0f 85 5d 07 00 00    	jne    8a00 <f12+0xfc0>
    82a3:	8b 72 18             	mov    0x18(%rdx),%esi
    82a6:	0f b7 c0             	movzwl %ax,%eax
    82a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82ac:	48 0f af c6          	imul   %rsi,%rax
    82b0:	48 c1 e8 20          	shr    $0x20,%rax
    82b4:	48 39 d0             	cmp    %rdx,%rax
    82b7:	0f 83 43 07 00 00    	jae    8a00 <f12+0xfc0>
    82bd:	48 01 c1             	add    %rax,%rcx
    82c0:	80 39 01             	cmpb   $0x1,(%rcx)
    82c3:	0f 85 37 07 00 00    	jne    8a00 <f12+0xfc0>
    82c9:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    82ce:	4c 89 e3             	mov    %r12,%rbx
    82d1:	31 ff                	xor    %edi,%edi
    82d3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    82d8:	f2 0f 10 0d 68 48 00 	movsd  0x4868(%rip),%xmm1        # cb48 <msg.4+0xc8>
    82df:	00 
    82e0:	48 8d 50 08          	lea    0x8(%rax),%rdx
    82e4:	31 c0                	xor    %eax,%eax
    82e6:	4d 85 ed             	test   %r13,%r13
    82e9:	75 2a                	jne    8315 <f12+0x8d5>
    82eb:	eb 53                	jmp    8340 <f12+0x900>
    82ed:	0f 1f 00             	nopl   (%rax)
    82f0:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    82f4:	0f 88 58 0c 00 00    	js     8f52 <f12+0x1512>
    82fa:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    82ff:	48 83 c0 01          	add    $0x1,%rax
    8303:	48 83 c2 08          	add    $0x8,%rdx
    8307:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    830b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8310:	49 39 c5             	cmp    %rax,%r13
    8313:	74 2b                	je     8340 <f12+0x900>
    8315:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    831a:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    831f:	79 cf                	jns    82f0 <f12+0x8b0>
    8321:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8326:	eb c8                	jmp    82f0 <f12+0x8b0>
    8328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    832f:	00 
    8330:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8334:	0f 84 82 f9 ff ff    	je     7cbc <f12+0x27c>
    833a:	e9 6f f9 ff ff       	jmp    7cae <f12+0x26e>
    833f:	90                   	nop
    8340:	e8 eb f1 ff ff       	call   7530 <fwp_drop4>
    8345:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    834a:	31 d2                	xor    %edx,%edx
    834c:	48 89 c8             	mov    %rcx,%rax
    834f:	48 85 c9             	test   %rcx,%rcx
    8352:	0f 84 81 0a 00 00    	je     8dd9 <f12+0x1399>
    8358:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    835f:	00 
    8360:	48 8b 40 10          	mov    0x10(%rax),%rax
    8364:	48 83 c2 01          	add    $0x1,%rdx
    8368:	48 85 c0             	test   %rax,%rax
    836b:	75 f3                	jne    8360 <f12+0x920>
    836d:	48 8b 03             	mov    (%rbx),%rax
    8370:	49 89 c7             	mov    %rax,%r15
    8373:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8378:	48 85 c0             	test   %rax,%rax
    837b:	0f 88 d4 05 00 00    	js     8955 <f12+0xf15>
    8381:	48 8b 0d b0 97 01 00 	mov    0x197b0(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    8388:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    838d:	48 2b 05 7c 97 01 00 	sub    0x1977c(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8394:	48 c1 e1 10          	shl    $0x10,%rcx
    8398:	48 39 c8             	cmp    %rcx,%rax
    839b:	0f 83 b4 05 00 00    	jae    8955 <f12+0xf15>
    83a1:	48 89 c1             	mov    %rax,%rcx
    83a4:	48 c1 e9 10          	shr    $0x10,%rcx
    83a8:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    83ac:	48 8b 0d a5 97 01 00 	mov    0x197a5(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    83b3:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    83b7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    83bb:	48 85 ff             	test   %rdi,%rdi
    83be:	0f 84 91 05 00 00    	je     8955 <f12+0xf15>
    83c4:	0f b6 0e             	movzbl (%rsi),%ecx
    83c7:	80 f9 02             	cmp    $0x2,%cl
    83ca:	0f 84 70 05 00 00    	je     8940 <f12+0xf00>
    83d0:	80 f9 01             	cmp    $0x1,%cl
    83d3:	0f 85 70 05 00 00    	jne    8949 <f12+0xf09>
    83d9:	8b 4e 18             	mov    0x18(%rsi),%ecx
    83dc:	0f b7 c0             	movzwl %ax,%eax
    83df:	48 0f af c1          	imul   %rcx,%rax
    83e3:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    83e6:	48 c1 e8 20          	shr    $0x20,%rax
    83ea:	48 39 c8             	cmp    %rcx,%rax
    83ed:	0f 83 56 05 00 00    	jae    8949 <f12+0xf09>
    83f3:	48 01 c7             	add    %rax,%rdi
    83f6:	80 3f 01             	cmpb   $0x1,(%rdi)
    83f9:	0f 85 4a 05 00 00    	jne    8949 <f12+0xf09>
    83ff:	4c 39 fa             	cmp    %r15,%rdx
    8402:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8406:	4c 89 fd             	mov    %r15,%rbp
    8409:	4d 85 ff             	test   %r15,%r15
    840c:	0f 84 51 0b 00 00    	je     8f63 <f12+0x1523>
    8412:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
    8419:	00 
    841a:	4c 8d 63 08          	lea    0x8(%rbx),%r12
    841e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    8423:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8428:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    842f:	00 
    8430:	31 c0                	xor    %eax,%eax
    8432:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8436:	eb 25                	jmp    845d <f12+0xa1d>
    8438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    843f:	00 
    8440:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8445:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    844a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8450:	48 83 c0 08          	add    $0x8,%rax
    8454:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8458:	49 39 c0             	cmp    %rax,%r8
    845b:	74 1b                	je     8478 <f12+0xa38>
    845d:	48 89 fe             	mov    %rdi,%rsi
    8460:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8464:	79 da                	jns    8440 <f12+0xa00>
    8466:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    846b:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    846f:	eb cf                	jmp    8440 <f12+0xa00>
    8471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8478:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    847d:	48 85 d2             	test   %rdx,%rdx
    8480:	0f 84 a7 0a 00 00    	je     8f2d <f12+0x14ed>
    8486:	4c 8b 05 ab 96 01 00 	mov    0x196ab(%rip),%r8        # 21b38 <fwp_heap+0x13d8>
    848d:	4c 8b 15 7c 96 01 00 	mov    0x1967c(%rip),%r10        # 21b10 <fwp_heap+0x13b0>
    8494:	45 31 ff             	xor    %r15d,%r15d
    8497:	4c 8b 1d ba 96 01 00 	mov    0x196ba(%rip),%r11        # 21b58 <fwp_heap+0x13f8>
    849e:	49 c1 e0 10          	shl    $0x10,%r8
    84a2:	eb 1a                	jmp    84be <f12+0xa7e>
    84a4:	0f 1f 40 00          	nopl   0x0(%rax)
    84a8:	49 83 c7 01          	add    $0x1,%r15
    84ac:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    84b0:	49 39 ef             	cmp    %rbp,%r15
    84b3:	0f 83 27 02 00 00    	jae    86e0 <f12+0xca0>
    84b9:	48 85 d2             	test   %rdx,%rdx
    84bc:	74 52                	je     8510 <f12+0xad0>
    84be:	48 89 d0             	mov    %rdx,%rax
    84c1:	4c 29 d0             	sub    %r10,%rax
    84c4:	4c 39 c0             	cmp    %r8,%rax
    84c7:	73 47                	jae    8510 <f12+0xad0>
    84c9:	48 89 c6             	mov    %rax,%rsi
    84cc:	48 c1 ee 10          	shr    $0x10,%rsi
    84d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    84d4:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    84d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    84dc:	48 85 ff             	test   %rdi,%rdi
    84df:	74 2f                	je     8510 <f12+0xad0>
    84e1:	0f b6 1e             	movzbl (%rsi),%ebx
    84e4:	80 fb 02             	cmp    $0x2,%bl
    84e7:	0f 84 d3 01 00 00    	je     86c0 <f12+0xc80>
    84ed:	80 fb 01             	cmp    $0x1,%bl
    84f0:	75 1e                	jne    8510 <f12+0xad0>
    84f2:	8b 5e 18             	mov    0x18(%rsi),%ebx
    84f5:	0f b7 c0             	movzwl %ax,%eax
    84f8:	8b 76 1c             	mov    0x1c(%rsi),%esi
    84fb:	48 0f af c3          	imul   %rbx,%rax
    84ff:	48 c1 e8 20          	shr    $0x20,%rax
    8503:	48 39 f0             	cmp    %rsi,%rax
    8506:	73 08                	jae    8510 <f12+0xad0>
    8508:	48 01 c7             	add    %rax,%rdi
    850b:	80 3f 01             	cmpb   $0x1,(%rdi)
    850e:	74 98                	je     84a8 <f12+0xa68>
    8510:	49 39 ef             	cmp    %rbp,%r15
    8513:	0f 83 c7 01 00 00    	jae    86e0 <f12+0xca0>
    8519:	4c 8b 2d d0 45 00 00 	mov    0x45d0(%rip),%r13        # caf0 <msg.4+0x70>
    8520:	45 31 f6             	xor    %r14d,%r14d
    8523:	48 8d 1d 36 82 01 00 	lea    0x18236(%rip),%rbx        # 20760 <fwp_heap>
    852a:	e9 17 01 00 00       	jmp    8646 <f12+0xc06>
    852f:	90                   	nop
    8530:	49 8b 10             	mov    (%r8),%rdx
    8533:	48 f7 d2             	not    %rdx
    8536:	48 89 10             	mov    %rdx,(%rax)
    8539:	49 83 fb 18          	cmp    $0x18,%r11
    853d:	76 39                	jbe    8578 <f12+0xb38>
    853f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8543:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8547:	31 f6                	xor    %esi,%esi
    8549:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    854e:	48 c1 e8 03          	shr    $0x3,%rax
    8552:	4c 89 04 24          	mov    %r8,(%rsp)
    8556:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    855d:	00 
    855e:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    8564:	e8 57 af ff ff       	call   34c0 <memset@plt>
    8569:	4c 8b 04 24          	mov    (%rsp),%r8
    856d:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    8572:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    8578:	4c 89 d8             	mov    %r11,%rax
    857b:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8582:	0f 82 c5 09 00 00    	jb     8f4d <f12+0x150d>
    8588:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    858f:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8596:	73 07                	jae    859f <f12+0xb5f>
    8598:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    859f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    85a3:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    85a8:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    85af:	00 
    85b0:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    85b7:	00 
    85b8:	66 49 0f 6e f6       	movq   %r14,%xmm6
    85bd:	4d 89 28             	mov    %r13,(%r8)
    85c0:	4c 89 c0             	mov    %r8,%rax
    85c3:	4d 89 c6             	mov    %r8,%r14
    85c6:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    85ca:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    85cf:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    85d6:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    85dd:	48 c1 e2 10          	shl    $0x10,%rdx
    85e1:	48 39 d0             	cmp    %rdx,%rax
    85e4:	73 57                	jae    863d <f12+0xbfd>
    85e6:	48 89 c2             	mov    %rax,%rdx
    85e9:	48 c1 ea 10          	shr    $0x10,%rdx
    85ed:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    85f1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    85f8:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    85fc:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8600:	48 85 d2             	test   %rdx,%rdx
    8603:	74 38                	je     863d <f12+0xbfd>
    8605:	0f b6 3e             	movzbl (%rsi),%edi
    8608:	40 80 ff 02          	cmp    $0x2,%dil
    860c:	0f 84 7e 01 00 00    	je     8790 <f12+0xd50>
    8612:	40 80 ff 01          	cmp    $0x1,%dil
    8616:	75 25                	jne    863d <f12+0xbfd>
    8618:	8b 7e 18             	mov    0x18(%rsi),%edi
    861b:	0f b7 c0             	movzwl %ax,%eax
    861e:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8621:	48 0f af c7          	imul   %rdi,%rax
    8625:	48 c1 e8 20          	shr    $0x20,%rax
    8629:	48 39 f0             	cmp    %rsi,%rax
    862c:	73 0f                	jae    863d <f12+0xbfd>
    862e:	48 01 c2             	add    %rax,%rdx
    8631:	80 3a ff             	cmpb   $0xff,(%rdx)
    8634:	0f 84 f6 04 00 00    	je     8b30 <f12+0x10f0>
    863a:	c6 02 01             	movb   $0x1,(%rdx)
    863d:	49 39 ef             	cmp    %rbp,%r15
    8640:	0f 83 6a 01 00 00    	jae    87b0 <f12+0xd70>
    8646:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    864c:	48 83 ed 01          	sub    $0x1,%rbp
    8650:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8656:	85 f6                	test   %esi,%esi
    8658:	74 46                	je     86a0 <f12+0xc60>
    865a:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8661:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8668:	00 
    8669:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    866d:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8671:	4c 8b 00             	mov    (%rax),%r8
    8674:	4d 85 c0             	test   %r8,%r8
    8677:	0f 85 b3 fe ff ff    	jne    8530 <f12+0xaf0>
    867d:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8681:	4d 85 c0             	test   %r8,%r8
    8684:	74 1a                	je     86a0 <f12+0xc60>
    8686:	48 8b 50 10          	mov    0x10(%rax),%rdx
    868a:	4c 29 c2             	sub    %r8,%rdx
    868d:	4c 39 da             	cmp    %r11,%rdx
    8690:	72 0e                	jb     86a0 <f12+0xc60>
    8692:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8696:	48 89 50 08          	mov    %rdx,0x8(%rax)
    869a:	e9 9a fe ff ff       	jmp    8539 <f12+0xaf9>
    869f:	90                   	nop
    86a0:	31 f6                	xor    %esi,%esi
    86a2:	bf 18 00 00 00       	mov    $0x18,%edi
    86a7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    86ac:	e8 9f d3 ff ff       	call   5a50 <fwp_heap_alloc>
    86b1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    86b6:	49 89 c0             	mov    %rax,%r8
    86b9:	e9 fa fe ff ff       	jmp    85b8 <f12+0xb78>
    86be:	66 90                	xchg   %ax,%ax
    86c0:	66 85 c0             	test   %ax,%ax
    86c3:	0f 84 42 fe ff ff    	je     850b <f12+0xacb>
    86c9:	49 39 ef             	cmp    %rbp,%r15
    86cc:	0f 82 47 fe ff ff    	jb     8519 <f12+0xad9>
    86d2:	0f 1f 00             	nopl   (%rax)
    86d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86dc:	00 00 00 00 
    86e0:	45 31 f6             	xor    %r14d,%r14d
    86e3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    86e8:	4c 89 e2             	mov    %r12,%rdx
    86eb:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    86ef:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86fc:	00 00 00 00 
    8700:	48 8b 0a             	mov    (%rdx),%rcx
    8703:	48 83 c2 08          	add    $0x8,%rdx
    8707:	48 89 c6             	mov    %rax,%rsi
    870a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    870e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8712:	48 39 d7             	cmp    %rdx,%rdi
    8715:	75 e9                	jne    8700 <f12+0xcc0>
    8717:	8b 4c 24 38          	mov    0x38(%rsp),%ecx
    871b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    871f:	85 c9                	test   %ecx,%ecx
    8721:	0f 84 99 05 00 00    	je     8cc0 <f12+0x1280>
    8727:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    872c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8731:	45 31 e4             	xor    %r12d,%r12d
    8734:	90                   	nop
    8735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    873c:	00 00 00 00 
    8740:	4c 89 e7             	mov    %r12,%rdi
    8743:	e8 08 ce ff ff       	call   5550 <fwp_mem_free>
    8748:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    874d:	e8 de ed ff ff       	call   7530 <fwp_drop4>
    8752:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    8757:	e8 04 de ff ff       	call   6560 <fwp_drop0>
    875c:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    8763:	00 
    8764:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    876b:	00 00 
    876d:	0f 85 8b 08 00 00    	jne    8ffe <f12+0x15be>
    8773:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    877a:	4c 89 f0             	mov    %r14,%rax
    877d:	5b                   	pop    %rbx
    877e:	5d                   	pop    %rbp
    877f:	41 5c                	pop    %r12
    8781:	41 5d                	pop    %r13
    8783:	41 5e                	pop    %r14
    8785:	41 5f                	pop    %r15
    8787:	c3                   	ret
    8788:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    878f:	00 
    8790:	66 85 c0             	test   %ax,%ax
    8793:	0f 84 98 fe ff ff    	je     8631 <f12+0xbf1>
    8799:	49 39 ef             	cmp    %rbp,%r15
    879c:	0f 82 a4 fe ff ff    	jb     8646 <f12+0xc06>
    87a2:	0f 1f 00             	nopl   (%rax)
    87a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87ac:	00 00 00 00 
    87b0:	4d 85 ff             	test   %r15,%r15
    87b3:	0f 85 2a ff ff ff    	jne    86e3 <f12+0xca3>
    87b9:	8b 54 24 38          	mov    0x38(%rsp),%edx
    87bd:	85 d2                	test   %edx,%edx
    87bf:	4d 0f 45 e7          	cmovne %r15,%r12
    87c3:	66 90                	xchg   %ax,%ax
    87c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87cc:	00 00 00 00 
    87d0:	48 85 ed             	test   %rbp,%rbp
    87d3:	0f 84 67 ff ff ff    	je     8740 <f12+0xd00>
    87d9:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    87df:	48 83 ed 01          	sub    $0x1,%rbp
    87e3:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    87e9:	85 c0                	test   %eax,%eax
    87eb:	0f 84 e7 06 00 00    	je     8ed8 <f12+0x1498>
    87f1:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    87f8:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    87ff:	00 
    8800:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8804:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8808:	4c 8b 38             	mov    (%rax),%r15
    880b:	4d 85 ff             	test   %r15,%r15
    880e:	0f 84 9c 06 00 00    	je     8eb0 <f12+0x1470>
    8814:	49 8b 17             	mov    (%r15),%rdx
    8817:	48 f7 d2             	not    %rdx
    881a:	48 89 10             	mov    %rdx,(%rax)
    881d:	49 83 f8 18          	cmp    $0x18,%r8
    8821:	76 2f                	jbe    8852 <f12+0xe12>
    8823:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8827:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    882b:	31 f6                	xor    %esi,%esi
    882d:	4c 89 04 24          	mov    %r8,(%rsp)
    8831:	48 c1 e8 03          	shr    $0x3,%rax
    8835:	66 0f d6 44 24 18    	movq   %xmm0,0x18(%rsp)
    883b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8842:	00 
    8843:	e8 78 ac ff ff       	call   34c0 <memset@plt>
    8848:	4c 8b 04 24          	mov    (%rsp),%r8
    884c:	f3 0f 7e 44 24 18    	movq   0x18(%rsp),%xmm0
    8852:	4c 89 c0             	mov    %r8,%rax
    8855:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    885c:	0f 82 eb 06 00 00    	jb     8f4d <f12+0x150d>
    8862:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8869:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8870:	73 07                	jae    8879 <f12+0xe39>
    8872:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8879:	66 0f ef c9          	pxor   %xmm1,%xmm1
    887d:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8882:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8889:	00 
    888a:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8891:	00 
    8892:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8897:	4d 89 2f             	mov    %r13,(%r15)
    889a:	4c 89 f8             	mov    %r15,%rax
    889d:	4d 89 fe             	mov    %r15,%r14
    88a0:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    88a4:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    88a9:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    88b0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    88b7:	48 c1 e2 10          	shl    $0x10,%rdx
    88bb:	48 39 d0             	cmp    %rdx,%rax
    88be:	0f 83 0c ff ff ff    	jae    87d0 <f12+0xd90>
    88c4:	48 89 c2             	mov    %rax,%rdx
    88c7:	48 c1 ea 10          	shr    $0x10,%rdx
    88cb:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    88cf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    88d6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    88da:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    88de:	4d 85 ff             	test   %r15,%r15
    88e1:	0f 84 e9 fe ff ff    	je     87d0 <f12+0xd90>
    88e7:	0f b6 32             	movzbl (%rdx),%esi
    88ea:	40 80 fe 02          	cmp    $0x2,%sil
    88ee:	0f 84 0c 06 00 00    	je     8f00 <f12+0x14c0>
    88f4:	40 80 fe 01          	cmp    $0x1,%sil
    88f8:	0f 85 d2 fe ff ff    	jne    87d0 <f12+0xd90>
    88fe:	8b 72 18             	mov    0x18(%rdx),%esi
    8901:	0f b7 c0             	movzwl %ax,%eax
    8904:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8907:	48 0f af c6          	imul   %rsi,%rax
    890b:	48 c1 e8 20          	shr    $0x20,%rax
    890f:	48 39 d0             	cmp    %rdx,%rax
    8912:	0f 83 b8 fe ff ff    	jae    87d0 <f12+0xd90>
    8918:	49 01 c7             	add    %rax,%r15
    891b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    891f:	0f 84 fb 05 00 00    	je     8f20 <f12+0x14e0>
    8925:	41 c6 07 01          	movb   $0x1,(%r15)
    8929:	48 85 ed             	test   %rbp,%rbp
    892c:	0f 85 a7 fe ff ff    	jne    87d9 <f12+0xd99>
    8932:	e9 09 fe ff ff       	jmp    8740 <f12+0xd00>
    8937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    893e:	00 00 
    8940:	66 85 c0             	test   %ax,%ax
    8943:	0f 84 ad fa ff ff    	je     83f6 <f12+0x9b6>
    8949:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    894f:	0f 84 18 04 00 00    	je     8d6d <f12+0x132d>
    8955:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    895a:	31 ed                	xor    %ebp,%ebp
    895c:	0f 1f 40 00          	nopl   0x0(%rax)
    8960:	48 8b 40 10          	mov    0x10(%rax),%rax
    8964:	48 89 ea             	mov    %rbp,%rdx
    8967:	48 83 c5 01          	add    $0x1,%rbp
    896b:	48 85 c0             	test   %rax,%rax
    896e:	75 f0                	jne    8960 <f12+0xf20>
    8970:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8977:	ff ff 1f 
    897a:	48 39 e8             	cmp    %rbp,%rax
    897d:	0f 82 f4 05 00 00    	jb     8f77 <f12+0x1537>
    8983:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    898a:	00 
    898b:	be 02 00 00 00       	mov    $0x2,%esi
    8990:	e8 bb d0 ff ff       	call   5a50 <fwp_heap_alloc>
    8995:	49 39 ef             	cmp    %rbp,%r15
    8998:	49 89 c4             	mov    %rax,%r12
    899b:	48 89 c2             	mov    %rax,%rdx
    899e:	49 0f 46 ef          	cmovbe %r15,%rbp
    89a2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    89a7:	0f 1f 00             	nopl   (%rax)
    89aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    89b1:	00 00 00 00 
    89b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    89bc:	00 00 00 00 
    89c0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    89c4:	48 83 c2 08          	add    $0x8,%rdx
    89c8:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    89cc:	48 8b 40 10          	mov    0x10(%rax),%rax
    89d0:	48 85 c0             	test   %rax,%rax
    89d3:	75 eb                	jne    89c0 <f12+0xf80>
    89d5:	48 85 ed             	test   %rbp,%rbp
    89d8:	0f 84 a1 03 00 00    	je     8d7f <f12+0x133f>
    89de:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
    89e5:	00 
    89e6:	e9 33 fa ff ff       	jmp    841e <f12+0x9de>
    89eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    89f0:	66 85 c0             	test   %ax,%ax
    89f3:	0f 84 c7 f8 ff ff    	je     82c0 <f12+0x880>
    89f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a00:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a07:	ff ff 1f 
    8a0a:	4c 39 e8             	cmp    %r13,%rax
    8a0d:	0f 82 70 05 00 00    	jb     8f83 <f12+0x1543>
    8a13:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    8a1a:	00 
    8a1b:	be 01 00 00 00       	mov    $0x1,%esi
    8a20:	e8 2b d0 ff ff       	call   5a50 <fwp_heap_alloc>
    8a25:	4c 89 28             	mov    %r13,(%rax)
    8a28:	48 8b 15 09 91 01 00 	mov    0x19109(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8a2f:	48 89 c3             	mov    %rax,%rbx
    8a32:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8a37:	48 2b 05 d2 90 01 00 	sub    0x190d2(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8a3e:	48 c1 e2 10          	shl    $0x10,%rdx
    8a42:	48 39 d0             	cmp    %rdx,%rax
    8a45:	73 57                	jae    8a9e <f12+0x105e>
    8a47:	48 89 c2             	mov    %rax,%rdx
    8a4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8a4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a52:	48 8b 15 ff 90 01 00 	mov    0x190ff(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8a59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a5d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8a61:	4d 85 ff             	test   %r15,%r15
    8a64:	74 38                	je     8a9e <f12+0x105e>
    8a66:	0f b6 0a             	movzbl (%rdx),%ecx
    8a69:	80 f9 02             	cmp    $0x2,%cl
    8a6c:	0f 84 1e 03 00 00    	je     8d90 <f12+0x1350>
    8a72:	80 f9 01             	cmp    $0x1,%cl
    8a75:	75 27                	jne    8a9e <f12+0x105e>
    8a77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a7a:	0f b7 c0             	movzwl %ax,%eax
    8a7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a80:	48 0f af c1          	imul   %rcx,%rax
    8a84:	48 c1 e8 20          	shr    $0x20,%rax
    8a88:	48 39 d0             	cmp    %rdx,%rax
    8a8b:	73 11                	jae    8a9e <f12+0x105e>
    8a8d:	49 01 c7             	add    %rax,%r15
    8a90:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8a94:	0f 84 fe 03 00 00    	je     8e98 <f12+0x1458>
    8a9a:	41 c6 07 01          	movb   $0x1,(%r15)
    8a9e:	4c 89 e7             	mov    %r12,%rdi
    8aa1:	e9 2d f8 ff ff       	jmp    82d3 <f12+0x893>
    8aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8aad:	00 00 00 
    8ab0:	48 c1 e6 10          	shl    $0x10,%rsi
    8ab4:	bf 08 00 00 00       	mov    $0x8,%edi
    8ab9:	49 09 f5             	or     %rsi,%r13
    8abc:	be 02 00 00 00       	mov    $0x2,%esi
    8ac1:	e8 8a cf ff ff       	call   5a50 <fwp_heap_alloc>
    8ac6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8acd:	48 8b 15 64 90 01 00 	mov    0x19064(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8ad4:	48 89 c3             	mov    %rax,%rbx
    8ad7:	48 2b 05 32 90 01 00 	sub    0x19032(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8ade:	48 c1 e2 10          	shl    $0x10,%rdx
    8ae2:	48 39 d0             	cmp    %rdx,%rax
    8ae5:	0f 83 d4 f3 ff ff    	jae    7ebf <f12+0x47f>
    8aeb:	48 89 c2             	mov    %rax,%rdx
    8aee:	48 c1 ea 10          	shr    $0x10,%rdx
    8af2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8af6:	48 8b 15 5b 90 01 00 	mov    0x1905b(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8afd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b01:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8b05:	4d 85 f6             	test   %r14,%r14
    8b08:	0f 84 a5 f3 ff ff    	je     7eb3 <f12+0x473>
    8b0e:	0f b6 0a             	movzbl (%rdx),%ecx
    8b11:	45 31 e4             	xor    %r12d,%r12d
    8b14:	80 f9 02             	cmp    $0x2,%cl
    8b17:	0f 85 f9 f2 ff ff    	jne    7e16 <f12+0x3d6>
    8b1d:	66 85 c0             	test   %ax,%ax
    8b20:	0f 85 1c f3 ff ff    	jne    7e42 <f12+0x402>
    8b26:	e9 09 f3 ff ff       	jmp    7e34 <f12+0x3f4>
    8b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b30:	48 89 d7             	mov    %rdx,%rdi
    8b33:	48 89 14 24          	mov    %rdx,(%rsp)
    8b37:	e8 d4 c7 ff ff       	call   5310 <fwp_rc_forget_slot>
    8b3c:	48 8b 14 24          	mov    (%rsp),%rdx
    8b40:	e9 f5 fa ff ff       	jmp    863a <f12+0xbfa>
    8b45:	0f 1f 00             	nopl   (%rax)
    8b48:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8b4c:	4c 89 e1             	mov    %r12,%rcx
    8b4f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8b53:	0f 85 1e 04 00 00    	jne    8f77 <f12+0x1537>
    8b59:	4d 85 e4             	test   %r12,%r12
    8b5c:	0f 84 5d f3 ff ff    	je     7ebf <f12+0x47f>
    8b62:	48 c1 e0 04          	shl    $0x4,%rax
    8b66:	4d 01 e4             	add    %r12,%r12
    8b69:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    8b6d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    8b72:	0f 1f 00             	nopl   (%rax)
    8b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b7c:	00 00 00 00 
    8b80:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    8b85:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    8b89:	48 83 c5 10          	add    $0x10,%rbp
    8b8d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    8b91:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    8b96:	e8 95 d5 ff ff       	call   6130 <w107>
    8b9b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8ba0:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8ba4:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    8ba8:	49 39 ee             	cmp    %rbp,%r14
    8bab:	75 d3                	jne    8b80 <f12+0x1140>
    8bad:	4c 89 23             	mov    %r12,(%rbx)
    8bb0:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8bb7:	45 31 f6             	xor    %r14d,%r14d
    8bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bc0:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    8bc5:	4c 89 ff             	mov    %r15,%rdi
    8bc8:	49 83 c6 02          	add    $0x2,%r14
    8bcc:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8bd3:	00 f0 3f 
    8bd6:	48 89 ce             	mov    %rcx,%rsi
    8bd9:	e8 d2 d1 ff ff       	call   5db0 <fwp_p_ad_push>
    8bde:	49 89 c7             	mov    %rax,%r15
    8be1:	4d 39 e6             	cmp    %r12,%r14
    8be4:	72 da                	jb     8bc0 <f12+0x1180>
    8be6:	e9 e5 f2 ff ff       	jmp    7ed0 <f12+0x490>
    8beb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bf0:	4d 8d 6a 01          	lea    0x1(%r10),%r13
    8bf4:	4d 39 ee             	cmp    %r13,%r14
    8bf7:	0f 8c 05 f4 ff ff    	jl     8002 <f12+0x5c2>
    8bfd:	48 85 c9             	test   %rcx,%rcx
    8c00:	0f 84 92 03 00 00    	je     8f98 <f12+0x1558>
    8c06:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    8c0b:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    8c12:	00 
    8c13:	31 f6                	xor    %esi,%esi
    8c15:	48 89 cf             	mov    %rcx,%rdi
    8c18:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8c1c:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8c21:	e8 9a a8 ff ff       	call   34c0 <memset@plt>
    8c26:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8c2b:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8c31:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    8c36:	48 89 c1             	mov    %rax,%rcx
    8c39:	e9 5d f4 ff ff       	jmp    809b <f12+0x65b>
    8c3e:	66 90                	xchg   %ax,%ax
    8c40:	48 8d 3d 59 de ff ff 	lea    -0x21a7(%rip),%rdi        # 6aa0 <fwp_tape_finish>
    8c47:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8c4c:	e8 5f 2e 00 00       	call   bab0 <atexit>
    8c51:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8c56:	85 c0                	test   %eax,%eax
    8c58:	0f 85 4e 03 00 00    	jne    8fac <f12+0x156c>
    8c5e:	c7 05 f8 73 00 00 01 	movl   $0x1,0x73f8(%rip)        # 10060 <registered_finish.0>
    8c65:	00 00 00 
    8c68:	e9 02 ef ff ff       	jmp    7b6f <f12+0x12f>
    8c6d:	0f 1f 00             	nopl   (%rax)
    8c70:	66 85 c0             	test   %ax,%ax
    8c73:	0f 85 ab ee ff ff    	jne    7b24 <f12+0xe4>
    8c79:	e9 92 ee ff ff       	jmp    7b10 <f12+0xd0>
    8c7e:	66 90                	xchg   %ax,%ax
    8c80:	4c 39 f5             	cmp    %r14,%rbp
    8c83:	0f 8f 76 f3 ff ff    	jg     7fff <f12+0x5bf>
    8c89:	48 85 c9             	test   %rcx,%rcx
    8c8c:	0f 85 c8 01 00 00    	jne    8e5a <f12+0x141a>
    8c92:	48 85 ed             	test   %rbp,%rbp
    8c95:	0f 85 fd 02 00 00    	jne    8f98 <f12+0x1558>
    8c9b:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    8ca2:	e9 08 f4 ff ff       	jmp    80af <f12+0x66f>
    8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cae:	00 00 
    8cb0:	66 85 c0             	test   %ax,%ax
    8cb3:	0f 85 5c f5 ff ff    	jne    8215 <f12+0x7d5>
    8cb9:	e9 4b f5 ff ff       	jmp    8209 <f12+0x7c9>
    8cbe:	66 90                	xchg   %ax,%ax
    8cc0:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    8cc5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8cca:	e9 71 fa ff ff       	jmp    8740 <f12+0xd00>
    8ccf:	90                   	nop
    8cd0:	66 0f 6f 0d c8 73 01 	movdqa 0x173c8(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    8cd7:	00 
    8cd8:	48 c7 05 a5 73 01 00 	movq   $0x0,0x173a5(%rip)        # 20088 <fwp_tape_cached_bytes>
    8cdf:	00 00 00 00 
    8ce3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    8ce8:	48 8b 05 d1 73 01 00 	mov    0x173d1(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    8cef:	66 0f 6f 0d b9 73 01 	movdqa 0x173b9(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    8cf6:	00 
    8cf7:	49 89 46 40          	mov    %rax,0x40(%r14)
    8cfb:	48 8b 05 c6 73 01 00 	mov    0x173c6(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    8d02:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    8d07:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8d0b:	49 89 46 18          	mov    %rax,0x18(%r14)
    8d0f:	48 8b 05 ba 73 01 00 	mov    0x173ba(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    8d16:	0f 29 0d 83 73 01 00 	movaps %xmm1,0x17383(%rip)        # 200a0 <fwp_tape_workspace>
    8d1d:	49 89 46 48          	mov    %rax,0x48(%r14)
    8d21:	0f 29 0d 88 73 01 00 	movaps %xmm1,0x17388(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    8d28:	48 c7 05 9d 73 01 00 	movq   $0x0,0x1739d(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    8d2f:	00 00 00 00 
    8d33:	0f 29 0d 86 73 01 00 	movaps %xmm1,0x17386(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    8d3a:	e9 7d ef ff ff       	jmp    7cbc <f12+0x27c>
    8d3f:	90                   	nop
    8d40:	48 85 c9             	test   %rcx,%rcx
    8d43:	0f 84 4f 02 00 00    	je     8f98 <f12+0x1558>
    8d49:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    8d4e:	4c 8d 65 ff          	lea    -0x1(%rbp),%r12
    8d52:	31 f6                	xor    %esi,%esi
    8d54:	48 89 cf             	mov    %rcx,%rdi
    8d57:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8d5c:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    8d63:	00 
    8d64:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8d68:	e9 b4 fe ff ff       	jmp    8c21 <f12+0x11e1>
    8d6d:	be 02 00 00 00       	mov    $0x2,%esi
    8d72:	bf 08 00 00 00       	mov    $0x8,%edi
    8d77:	e8 d4 cc ff ff       	call   5a50 <fwp_heap_alloc>
    8d7c:	49 89 c4             	mov    %rax,%r12
    8d7f:	45 31 f6             	xor    %r14d,%r14d
    8d82:	e9 b9 f9 ff ff       	jmp    8740 <f12+0xd00>
    8d87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d8e:	00 00 
    8d90:	66 85 c0             	test   %ax,%ax
    8d93:	0f 85 05 fd ff ff    	jne    8a9e <f12+0x105e>
    8d99:	e9 f2 fc ff ff       	jmp    8a90 <f12+0x1050>
    8d9e:	66 90                	xchg   %ax,%ax
    8da0:	4d 85 e4             	test   %r12,%r12
    8da3:	0f 85 9e f0 ff ff    	jne    7e47 <f12+0x407>
    8da9:	e9 11 f1 ff ff       	jmp    7ebf <f12+0x47f>
    8dae:	66 90                	xchg   %ax,%ax
    8db0:	be 08 00 00 00       	mov    $0x8,%esi
    8db5:	4c 89 f7             	mov    %r14,%rdi
    8db8:	e8 63 a7 ff ff       	call   3520 <calloc@plt>
    8dbd:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8dc3:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8dc8:	48 89 c1             	mov    %rax,%rcx
    8dcb:	e9 9a f2 ff ff       	jmp    806a <f12+0x62a>
    8dd0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8dd4:	e9 86 ed ff ff       	jmp    7b5f <f12+0x11f>
    8dd9:	48 8b 0b             	mov    (%rbx),%rcx
    8ddc:	48 85 c9             	test   %rcx,%rcx
    8ddf:	78 8c                	js     8d6d <f12+0x132d>
    8de1:	48 8b 35 50 8d 01 00 	mov    0x18d50(%rip),%rsi        # 21b38 <fwp_heap+0x13d8>
    8de8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8ded:	48 2b 05 1c 8d 01 00 	sub    0x18d1c(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8df4:	48 c1 e6 10          	shl    $0x10,%rsi
    8df8:	48 39 f0             	cmp    %rsi,%rax
    8dfb:	0f 83 6c ff ff ff    	jae    8d6d <f12+0x132d>
    8e01:	48 89 c6             	mov    %rax,%rsi
    8e04:	48 c1 ee 10          	shr    $0x10,%rsi
    8e08:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8e0c:	48 8b 35 45 8d 01 00 	mov    0x18d45(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    8e13:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8e17:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8e1b:	48 85 ff             	test   %rdi,%rdi
    8e1e:	0f 84 49 ff ff ff    	je     8d6d <f12+0x132d>
    8e24:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    8e29:	49 89 cf             	mov    %rcx,%r15
    8e2c:	e9 93 f5 ff ff       	jmp    83c4 <f12+0x984>
    8e31:	be 68 00 00 00       	mov    $0x68,%esi
    8e36:	bb 01 00 00 00       	mov    $0x1,%ebx
    8e3b:	e9 bb ed ff ff       	jmp    7bfb <f12+0x1bb>
    8e40:	4c 89 f7             	mov    %r14,%rdi
    8e43:	e8 c8 c4 ff ff       	call   5310 <fwp_rc_forget_slot>
    8e48:	e9 f1 ef ff ff       	jmp    7e3e <f12+0x3fe>
    8e4d:	48 89 df             	mov    %rbx,%rdi
    8e50:	e8 bb c4 ff ff       	call   5310 <fwp_rc_forget_slot>
    8e55:	e9 b8 f3 ff ff       	jmp    8212 <f12+0x7d2>
    8e5a:	48 85 ed             	test   %rbp,%rbp
    8e5d:	0f 84 38 fe ff ff    	je     8c9b <f12+0x125b>
    8e63:	49 89 ed             	mov    %rbp,%r13
    8e66:	48 89 cf             	mov    %rcx,%rdi
    8e69:	31 f6                	xor    %esi,%esi
    8e6b:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8e70:	4d 8d 65 ff          	lea    -0x1(%r13),%r12
    8e74:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    8e7b:	00 
    8e7c:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8e80:	e8 3b a6 ff ff       	call   34c0 <memset@plt>
    8e85:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8e8a:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8e90:	48 89 c1             	mov    %rax,%rcx
    8e93:	e9 fb f1 ff ff       	jmp    8093 <f12+0x653>
    8e98:	4c 89 ff             	mov    %r15,%rdi
    8e9b:	e8 70 c4 ff ff       	call   5310 <fwp_rc_forget_slot>
    8ea0:	e9 f5 fb ff ff       	jmp    8a9a <f12+0x105a>
    8ea5:	e8 46 c3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    8eaa:	e9 75 ec ff ff       	jmp    7b24 <f12+0xe4>
    8eaf:	90                   	nop
    8eb0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    8eb4:	4d 85 ff             	test   %r15,%r15
    8eb7:	74 1f                	je     8ed8 <f12+0x1498>
    8eb9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8ebd:	4c 29 fa             	sub    %r15,%rdx
    8ec0:	4c 39 c2             	cmp    %r8,%rdx
    8ec3:	72 13                	jb     8ed8 <f12+0x1498>
    8ec5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    8ec9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8ecd:	e9 4b f9 ff ff       	jmp    881d <f12+0xddd>
    8ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ed8:	31 f6                	xor    %esi,%esi
    8eda:	bf 18 00 00 00       	mov    $0x18,%edi
    8edf:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8ee4:	e8 67 cb ff ff       	call   5a50 <fwp_heap_alloc>
    8ee9:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8eee:	49 89 c7             	mov    %rax,%r15
    8ef1:	e9 9c f9 ff ff       	jmp    8892 <f12+0xe52>
    8ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8efd:	00 00 00 
    8f00:	66 85 c0             	test   %ax,%ax
    8f03:	0f 85 c7 f8 ff ff    	jne    87d0 <f12+0xd90>
    8f09:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f0d:	0f 85 12 fa ff ff    	jne    8925 <f12+0xee5>
    8f13:	66 90                	xchg   %ax,%ax
    8f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f1c:	00 00 00 00 
    8f20:	4c 89 ff             	mov    %r15,%rdi
    8f23:	e8 e8 c3 ff ff       	call   5310 <fwp_rc_forget_slot>
    8f28:	e9 f8 f9 ff ff       	jmp    8925 <f12+0xee5>
    8f2d:	45 31 ff             	xor    %r15d,%r15d
    8f30:	e9 e4 f5 ff ff       	jmp    8519 <f12+0xad9>
    8f35:	48 8d 3d c8 31 00 00 	lea    0x31c8(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    8f3c:	e8 5f b2 ff ff       	call   41a0 <fwp_trap>
    8f41:	48 8d 3d 78 38 00 00 	lea    0x3878(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    8f48:	e8 53 b2 ff ff       	call   41a0 <fwp_trap>
    8f4d:	e8 5e ad ff ff       	call   3cb0 <fwp_heap_oom>
    8f52:	48 8d 3d 6f 39 00 00 	lea    0x396f(%rip),%rdi        # c8c8 <_IO_stdin_used+0x8c8>
    8f59:	e8 42 b2 ff ff       	call   41a0 <fwp_trap>
    8f5e:	e8 9d a7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    8f63:	45 31 e4             	xor    %r12d,%r12d
    8f66:	e9 14 fe ff ff       	jmp    8d7f <f12+0x133f>
    8f6b:	48 8d 3d bb 31 00 00 	lea    0x31bb(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    8f72:	e8 29 b2 ff ff       	call   41a0 <fwp_trap>
    8f77:	48 8d 3d c9 31 00 00 	lea    0x31c9(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    8f7e:	e8 1d b2 ff ff       	call   41a0 <fwp_trap>
    8f83:	48 8d 3d cb 31 00 00 	lea    0x31cb(%rip),%rdi        # c155 <_IO_stdin_used+0x155>
    8f8a:	e8 11 b2 ff ff       	call   41a0 <fwp_trap>
    8f8f:	4d 85 ed             	test   %r13,%r13
    8f92:	0f 84 f4 f0 ff ff    	je     808c <f12+0x64c>
    8f98:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    8f9d:	48 89 df             	mov    %rbx,%rdi
    8fa0:	48 89 05 51 94 01 00 	mov    %rax,0x19451(%rip)        # 223f8 <fwp_cleanups>
    8fa7:	e8 84 be ff ff       	call   4e30 <fwp_tape_buffers_release>
    8fac:	48 8b 0d 8d 70 00 00 	mov    0x708d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    8fb3:	ba 13 00 00 00       	mov    $0x13,%edx
    8fb8:	be 01 00 00 00       	mov    $0x1,%esi
    8fbd:	48 8d 3d 44 30 00 00 	lea    0x3044(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    8fc4:	e8 b7 a6 ff ff       	call   3680 <fwrite@plt>
    8fc9:	31 ff                	xor    %edi,%edi
    8fcb:	e8 f0 a5 ff ff       	call   35c0 <fflush@plt>
    8fd0:	bf 66 00 00 00       	mov    $0x66,%edi
    8fd5:	e8 c6 a6 ff ff       	call   36a0 <_Exit@plt>
    8fda:	48 8d 3d b7 38 00 00 	lea    0x38b7(%rip),%rdi        # c898 <_IO_stdin_used+0x898>
    8fe1:	e8 ba b1 ff ff       	call   41a0 <fwp_trap>
    8fe6:	48 8d 3d 7b 38 00 00 	lea    0x387b(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    8fed:	e8 ae b1 ff ff       	call   41a0 <fwp_trap>
    8ff2:	48 8d 3d 0f 38 00 00 	lea    0x380f(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    8ff9:	e8 a2 b1 ff ff       	call   41a0 <fwp_trap>
    8ffe:	e8 5d a4 ff ff       	call   3460 <__stack_chk_fail@plt>
    9003:	66 90                	xchg   %ax,%ax
    9005:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    900c:	00 00 00 00 

0000000000009010 <fwp_owned_entry12>:
    9010:	f3 0f 1e fa          	endbr64
    9014:	48 8b 3f             	mov    (%rdi),%rdi
    9017:	e9 24 ea ff ff       	jmp    7a40 <f12>
    901c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009020 <e12>:
    9020:	f3 0f 1e fa          	endbr64
    9024:	53                   	push   %rbx
    9025:	48 8b 1f             	mov    (%rdi),%rbx
    9028:	48 89 df             	mov    %rbx,%rdi
    902b:	e8 a0 d3 ff ff       	call   63d0 <fwp_rc_share>
    9030:	48 89 df             	mov    %rbx,%rdi
    9033:	e8 08 ea ff ff       	call   7a40 <f12>
    9038:	48 89 c3             	mov    %rax,%rbx
    903b:	48 89 c7             	mov    %rax,%rdi
    903e:	e8 8d d3 ff ff       	call   63d0 <fwp_rc_share>
    9043:	48 89 d8             	mov    %rbx,%rax
    9046:	5b                   	pop    %rbx
    9047:	c3                   	ret
    9048:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    904f:	00 

0000000000009050 <fwp_drop2>:
    9050:	48 8b 0d e1 8a 01 00 	mov    0x18ae1(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    9057:	48 89 f8             	mov    %rdi,%rax
    905a:	48 2b 05 af 8a 01 00 	sub    0x18aaf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9061:	48 c1 e1 10          	shl    $0x10,%rcx
    9065:	48 39 c8             	cmp    %rcx,%rax
    9068:	0f 83 42 01 00 00    	jae    91b0 <fwp_drop2+0x160>
    906e:	48 83 ec 18          	sub    $0x18,%rsp
    9072:	48 89 fa             	mov    %rdi,%rdx
    9075:	4c 8d 05 e4 76 01 00 	lea    0x176e4(%rip),%r8        # 20760 <fwp_heap>
    907c:	48 89 c1             	mov    %rax,%rcx
    907f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9086:	48 c1 e9 10          	shr    $0x10,%rcx
    908a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    908e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9092:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9096:	48 85 c9             	test   %rcx,%rcx
    9099:	74 40                	je     90db <fwp_drop2+0x8b>
    909b:	0f b6 3e             	movzbl (%rsi),%edi
    909e:	40 80 ff 02          	cmp    $0x2,%dil
    90a2:	74 3c                	je     90e0 <fwp_drop2+0x90>
    90a4:	40 80 ff 01          	cmp    $0x1,%dil
    90a8:	75 31                	jne    90db <fwp_drop2+0x8b>
    90aa:	8b 7e 18             	mov    0x18(%rsi),%edi
    90ad:	0f b7 c0             	movzwl %ax,%eax
    90b0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    90b3:	48 0f af c7          	imul   %rdi,%rax
    90b7:	48 c1 e8 20          	shr    $0x20,%rax
    90bb:	48 39 f0             	cmp    %rsi,%rax
    90be:	73 1b                	jae    90db <fwp_drop2+0x8b>
    90c0:	48 01 c1             	add    %rax,%rcx
    90c3:	0f b6 01             	movzbl (%rcx),%eax
    90c6:	84 c0                	test   %al,%al
    90c8:	74 11                	je     90db <fwp_drop2+0x8b>
    90ca:	3c 01                	cmp    $0x1,%al
    90cc:	74 22                	je     90f0 <fwp_drop2+0xa0>
    90ce:	3c ff                	cmp    $0xff,%al
    90d0:	0f 84 0a 01 00 00    	je     91e0 <fwp_drop2+0x190>
    90d6:	83 e8 01             	sub    $0x1,%eax
    90d9:	88 01                	mov    %al,(%rcx)
    90db:	48 83 c4 18          	add    $0x18,%rsp
    90df:	c3                   	ret
    90e0:	66 85 c0             	test   %ax,%ax
    90e3:	74 de                	je     90c3 <fwp_drop2+0x73>
    90e5:	48 83 c4 18          	add    $0x18,%rsp
    90e9:	c3                   	ret
    90ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90f0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    90f4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    90fb:	48 89 f8             	mov    %rdi,%rax
    90fe:	48 c1 e1 10          	shl    $0x10,%rcx
    9102:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9109:	48 39 c8             	cmp    %rcx,%rax
    910c:	73 62                	jae    9170 <fwp_drop2+0x120>
    910e:	48 89 c1             	mov    %rax,%rcx
    9111:	48 c1 e9 10          	shr    $0x10,%rcx
    9115:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9119:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    911d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9121:	48 85 c9             	test   %rcx,%rcx
    9124:	74 4a                	je     9170 <fwp_drop2+0x120>
    9126:	44 0f b6 0e          	movzbl (%rsi),%r9d
    912a:	41 80 f9 02          	cmp    $0x2,%r9b
    912e:	0f 84 9c 00 00 00    	je     91d0 <fwp_drop2+0x180>
    9134:	41 80 f9 01          	cmp    $0x1,%r9b
    9138:	75 36                	jne    9170 <fwp_drop2+0x120>
    913a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    913e:	0f b7 c0             	movzwl %ax,%eax
    9141:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9144:	49 0f af c1          	imul   %r9,%rax
    9148:	48 c1 e8 20          	shr    $0x20,%rax
    914c:	48 39 f0             	cmp    %rsi,%rax
    914f:	73 1f                	jae    9170 <fwp_drop2+0x120>
    9151:	48 01 c1             	add    %rax,%rcx
    9154:	0f b6 01             	movzbl (%rcx),%eax
    9157:	84 c0                	test   %al,%al
    9159:	74 15                	je     9170 <fwp_drop2+0x120>
    915b:	3c 01                	cmp    $0x1,%al
    915d:	74 59                	je     91b8 <fwp_drop2+0x168>
    915f:	3c ff                	cmp    $0xff,%al
    9161:	0f 84 ff 00 00 00    	je     9266 <fwp_drop2+0x216>
    9167:	83 e8 01             	sub    $0x1,%eax
    916a:	88 01                	mov    %al,(%rcx)
    916c:	0f 1f 40 00          	nopl   0x0(%rax)
    9170:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9174:	48 89 d7             	mov    %rdx,%rdi
    9177:	48 89 0c 24          	mov    %rcx,(%rsp)
    917b:	e8 d0 d2 ff ff       	call   6450 <fwp_rc_free_arr>
    9180:	4c 8d 05 d9 75 01 00 	lea    0x175d9(%rip),%r8        # 20760 <fwp_heap>
    9187:	48 8b 04 24          	mov    (%rsp),%rax
    918b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9192:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9199:	48 c1 e2 10          	shl    $0x10,%rdx
    919d:	48 39 d0             	cmp    %rdx,%rax
    91a0:	0f 83 35 ff ff ff    	jae    90db <fwp_drop2+0x8b>
    91a6:	48 8b 14 24          	mov    (%rsp),%rdx
    91aa:	e9 cd fe ff ff       	jmp    907c <fwp_drop2+0x2c>
    91af:	90                   	nop
    91b0:	c3                   	ret
    91b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91b8:	48 89 14 24          	mov    %rdx,(%rsp)
    91bc:	e8 8f d2 ff ff       	call   6450 <fwp_rc_free_arr>
    91c1:	48 8b 14 24          	mov    (%rsp),%rdx
    91c5:	eb a9                	jmp    9170 <fwp_drop2+0x120>
    91c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91ce:	00 00 
    91d0:	66 85 c0             	test   %ax,%ax
    91d3:	75 9b                	jne    9170 <fwp_drop2+0x120>
    91d5:	e9 7a ff ff ff       	jmp    9154 <fwp_drop2+0x104>
    91da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91e0:	48 89 c8             	mov    %rcx,%rax
    91e3:	48 c1 e8 11          	shr    $0x11,%rax
    91e7:	48 31 c8             	xor    %rcx,%rax
    91ea:	48 89 c2             	mov    %rax,%rdx
    91ed:	48 c1 ea 09          	shr    $0x9,%rdx
    91f1:	48 31 d0             	xor    %rdx,%rax
    91f4:	0f b6 d0             	movzbl %al,%edx
    91f7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    91fe:	00 
    91ff:	48 85 c0             	test   %rax,%rax
    9202:	75 29                	jne    922d <fwp_drop2+0x1dd>
    9204:	e9 e3 00 00 00       	jmp    92ec <fwp_drop2+0x29c>
    9209:	90                   	nop
    920a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9211:	00 00 00 00 
    9215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    921c:	00 00 00 00 
    9220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9224:	48 85 c0             	test   %rax,%rax
    9227:	0f 84 bf 00 00 00    	je     92ec <fwp_drop2+0x29c>
    922d:	48 89 c2             	mov    %rax,%rdx
    9230:	48 39 08             	cmp    %rcx,(%rax)
    9233:	75 eb                	jne    9220 <fwp_drop2+0x1d0>
    9235:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9239:	48 83 ea 01          	sub    $0x1,%rdx
    923d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9241:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9248:	0f 85 8d fe ff ff    	jne    90db <fwp_drop2+0x8b>
    924e:	48 89 cf             	mov    %rcx,%rdi
    9251:	48 89 0c 24          	mov    %rcx,(%rsp)
    9255:	e8 b6 c0 ff ff       	call   5310 <fwp_rc_forget_slot>
    925a:	48 8b 0c 24          	mov    (%rsp),%rcx
    925e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9261:	e9 75 fe ff ff       	jmp    90db <fwp_drop2+0x8b>
    9266:	48 89 ce             	mov    %rcx,%rsi
    9269:	48 c1 ee 11          	shr    $0x11,%rsi
    926d:	48 31 ce             	xor    %rcx,%rsi
    9270:	48 89 f0             	mov    %rsi,%rax
    9273:	48 c1 e8 09          	shr    $0x9,%rax
    9277:	48 31 c6             	xor    %rax,%rsi
    927a:	40 0f b6 f6          	movzbl %sil,%esi
    927e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9285:	00 
    9286:	48 85 c0             	test   %rax,%rax
    9289:	75 1e                	jne    92a9 <fwp_drop2+0x259>
    928b:	eb 5f                	jmp    92ec <fwp_drop2+0x29c>
    928d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9294:	00 
    9295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    929c:	00 00 00 00 
    92a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    92a4:	48 85 c0             	test   %rax,%rax
    92a7:	74 43                	je     92ec <fwp_drop2+0x29c>
    92a9:	48 89 c6             	mov    %rax,%rsi
    92ac:	48 39 08             	cmp    %rcx,(%rax)
    92af:	75 ef                	jne    92a0 <fwp_drop2+0x250>
    92b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    92b5:	48 83 ee 01          	sub    $0x1,%rsi
    92b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    92bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    92c4:	0f 85 a6 fe ff ff    	jne    9170 <fwp_drop2+0x120>
    92ca:	48 89 cf             	mov    %rcx,%rdi
    92cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    92d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    92d6:	e8 35 c0 ff ff       	call   5310 <fwp_rc_forget_slot>
    92db:	48 8b 0c 24          	mov    (%rsp),%rcx
    92df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    92e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    92e7:	e9 84 fe ff ff       	jmp    9170 <fwp_drop2+0x120>
    92ec:	48 8d 3d a5 34 00 00 	lea    0x34a5(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    92f3:	e8 a8 ae ff ff       	call   41a0 <fwp_trap>
    92f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92ff:	00 

0000000000009300 <fwp_arg_drop23>:
    9300:	f3 0f 1e fa          	endbr64
    9304:	85 f6                	test   %esi,%esi
    9306:	75 04                	jne    930c <fwp_arg_drop23+0xc>
    9308:	85 d2                	test   %edx,%edx
    930a:	75 04                	jne    9310 <fwp_arg_drop23+0x10>
    930c:	c3                   	ret
    930d:	0f 1f 00             	nopl   (%rax)
    9310:	48 8b 3f             	mov    (%rdi),%rdi
    9313:	e9 38 fd ff ff       	jmp    9050 <fwp_drop2>
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 

0000000000009320 <fwp_caps23>:
    9320:	f3 0f 1e fa          	endbr64
    9324:	48 83 ec 18          	sub    $0x18,%rsp
    9328:	8b 57 04             	mov    0x4(%rdi),%edx
    932b:	48 89 f8             	mov    %rdi,%rax
    932e:	85 d2                	test   %edx,%edx
    9330:	0f 84 9a 00 00 00    	je     93d0 <fwp_caps23+0xb0>
    9336:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    933a:	85 f6                	test   %esi,%esi
    933c:	0f 85 9e 00 00 00    	jne    93e0 <fwp_caps23+0xc0>
    9342:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9347:	e8 04 fd ff ff       	call   9050 <fwp_drop2>
    934c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9351:	48 8b 0d e0 87 01 00 	mov    0x187e0(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    9358:	48 89 c2             	mov    %rax,%rdx
    935b:	48 2b 15 ae 87 01 00 	sub    0x187ae(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    9362:	48 c1 e1 10          	shl    $0x10,%rcx
    9366:	48 39 ca             	cmp    %rcx,%rdx
    9369:	73 6d                	jae    93d8 <fwp_caps23+0xb8>
    936b:	48 89 d1             	mov    %rdx,%rcx
    936e:	48 c1 e9 10          	shr    $0x10,%rcx
    9372:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9376:	48 8b 0d db 87 01 00 	mov    0x187db(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    937d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9381:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9385:	48 85 f6             	test   %rsi,%rsi
    9388:	74 4e                	je     93d8 <fwp_caps23+0xb8>
    938a:	0f b6 39             	movzbl (%rcx),%edi
    938d:	40 80 ff 02          	cmp    $0x2,%dil
    9391:	0f 84 b9 00 00 00    	je     9450 <fwp_caps23+0x130>
    9397:	40 80 ff 01          	cmp    $0x1,%dil
    939b:	75 3b                	jne    93d8 <fwp_caps23+0xb8>
    939d:	8b 79 18             	mov    0x18(%rcx),%edi
    93a0:	0f b7 d2             	movzwl %dx,%edx
    93a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    93a6:	48 0f af d7          	imul   %rdi,%rdx
    93aa:	48 c1 ea 20          	shr    $0x20,%rdx
    93ae:	48 39 ca             	cmp    %rcx,%rdx
    93b1:	73 25                	jae    93d8 <fwp_caps23+0xb8>
    93b3:	48 01 d6             	add    %rdx,%rsi
    93b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    93b9:	75 1d                	jne    93d8 <fwp_caps23+0xb8>
    93bb:	48 89 c7             	mov    %rax,%rdi
    93be:	48 83 c4 18          	add    $0x18,%rsp
    93c2:	e9 89 c1 ff ff       	jmp    5550 <fwp_mem_free>
    93c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    93ce:	00 00 
    93d0:	85 f6                	test   %esi,%esi
    93d2:	0f 84 79 ff ff ff    	je     9351 <fwp_caps23+0x31>
    93d8:	48 83 c4 18          	add    $0x18,%rsp
    93dc:	c3                   	ret
    93dd:	0f 1f 00             	nopl   (%rax)
    93e0:	48 8b 05 51 87 01 00 	mov    0x18751(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    93e7:	48 2b 3d 22 87 01 00 	sub    0x18722(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    93ee:	48 c1 e0 10          	shl    $0x10,%rax
    93f2:	48 39 c7             	cmp    %rax,%rdi
    93f5:	73 e1                	jae    93d8 <fwp_caps23+0xb8>
    93f7:	48 89 f8             	mov    %rdi,%rax
    93fa:	48 c1 e8 10          	shr    $0x10,%rax
    93fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9402:	48 8b 05 4f 87 01 00 	mov    0x1874f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    9409:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    940d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9411:	48 85 c0             	test   %rax,%rax
    9414:	74 c2                	je     93d8 <fwp_caps23+0xb8>
    9416:	0f b6 0a             	movzbl (%rdx),%ecx
    9419:	80 f9 02             	cmp    $0x2,%cl
    941c:	74 42                	je     9460 <fwp_caps23+0x140>
    941e:	80 f9 01             	cmp    $0x1,%cl
    9421:	75 b5                	jne    93d8 <fwp_caps23+0xb8>
    9423:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9426:	0f b7 ff             	movzwl %di,%edi
    9429:	8b 52 1c             	mov    0x1c(%rdx),%edx
    942c:	48 0f af f9          	imul   %rcx,%rdi
    9430:	48 c1 ef 20          	shr    $0x20,%rdi
    9434:	48 39 d7             	cmp    %rdx,%rdi
    9437:	73 9f                	jae    93d8 <fwp_caps23+0xb8>
    9439:	48 01 f8             	add    %rdi,%rax
    943c:	0f b6 10             	movzbl (%rax),%edx
    943f:	84 d2                	test   %dl,%dl
    9441:	74 95                	je     93d8 <fwp_caps23+0xb8>
    9443:	80 fa fd             	cmp    $0xfd,%dl
    9446:	77 23                	ja     946b <fwp_caps23+0x14b>
    9448:	83 c2 01             	add    $0x1,%edx
    944b:	88 10                	mov    %dl,(%rax)
    944d:	eb 89                	jmp    93d8 <fwp_caps23+0xb8>
    944f:	90                   	nop
    9450:	66 85 d2             	test   %dx,%dx
    9453:	0f 85 7f ff ff ff    	jne    93d8 <fwp_caps23+0xb8>
    9459:	e9 58 ff ff ff       	jmp    93b6 <fwp_caps23+0x96>
    945e:	66 90                	xchg   %ax,%ax
    9460:	66 85 ff             	test   %di,%di
    9463:	0f 85 6f ff ff ff    	jne    93d8 <fwp_caps23+0xb8>
    9469:	eb d1                	jmp    943c <fwp_caps23+0x11c>
    946b:	48 89 c7             	mov    %rax,%rdi
    946e:	48 83 c4 18          	add    $0x18,%rsp
    9472:	e9 79 bd ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    9477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    947e:	00 00 

0000000000009480 <f23>:
    9480:	41 57                	push   %r15
    9482:	41 56                	push   %r14
    9484:	41 55                	push   %r13
    9486:	41 54                	push   %r12
    9488:	55                   	push   %rbp
    9489:	53                   	push   %rbx
    948a:	48 83 ec 38          	sub    $0x38,%rsp
    948e:	48 8b 15 a3 86 01 00 	mov    0x186a3(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9495:	48 8b 0d 74 86 01 00 	mov    0x18674(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    949c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    94a3:	00 00 
    94a5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    94aa:	49 89 fd             	mov    %rdi,%r13
    94ad:	48 c1 e2 10          	shl    $0x10,%rdx
    94b1:	48 85 ff             	test   %rdi,%rdi
    94b4:	0f 84 0c 03 00 00    	je     97c6 <f23+0x346>
    94ba:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    94be:	48 89 d8             	mov    %rbx,%rax
    94c1:	48 29 c8             	sub    %rcx,%rax
    94c4:	48 39 d0             	cmp    %rdx,%rax
    94c7:	0f 83 c3 03 00 00    	jae    9890 <f23+0x410>
    94cd:	48 89 c2             	mov    %rax,%rdx
    94d0:	48 c1 ea 10          	shr    $0x10,%rdx
    94d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94d8:	48 8b 15 79 86 01 00 	mov    0x18679(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    94df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94e3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    94e7:	48 85 ff             	test   %rdi,%rdi
    94ea:	0f 84 a0 03 00 00    	je     9890 <f23+0x410>
    94f0:	0f b6 0a             	movzbl (%rdx),%ecx
    94f3:	80 f9 02             	cmp    $0x2,%cl
    94f6:	0f 84 a4 02 00 00    	je     97a0 <f23+0x320>
    94fc:	80 f9 01             	cmp    $0x1,%cl
    94ff:	75 24                	jne    9525 <f23+0xa5>
    9501:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9504:	0f b7 c0             	movzwl %ax,%eax
    9507:	8b 52 1c             	mov    0x1c(%rdx),%edx
    950a:	48 0f af c1          	imul   %rcx,%rax
    950e:	48 c1 e8 20          	shr    $0x20,%rax
    9512:	48 39 d0             	cmp    %rdx,%rax
    9515:	73 0e                	jae    9525 <f23+0xa5>
    9517:	48 01 c7             	add    %rax,%rdi
    951a:	0f b6 07             	movzbl (%rdi),%eax
    951d:	84 c0                	test   %al,%al
    951f:	0f 85 1b 03 00 00    	jne    9840 <f23+0x3c0>
    9525:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    952a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    952e:	ba 01 00 00 00       	mov    $0x1,%edx
    9533:	48 85 db             	test   %rbx,%rbx
    9536:	74 15                	je     954d <f23+0xcd>
    9538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    953f:	00 
    9540:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9544:	48 83 c2 01          	add    $0x1,%rdx
    9548:	48 85 db             	test   %rbx,%rbx
    954b:	75 f3                	jne    9540 <f23+0xc0>
    954d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9552:	48 85 c0             	test   %rax,%rax
    9555:	0f 84 65 03 00 00    	je     98c0 <f23+0x440>
    955b:	31 db                	xor    %ebx,%ebx
    955d:	0f 1f 00             	nopl   (%rax)
    9560:	48 8b 40 10          	mov    0x10(%rax),%rax
    9564:	48 83 c3 01          	add    $0x1,%rbx
    9568:	48 85 c0             	test   %rax,%rax
    956b:	75 f3                	jne    9560 <f23+0xe0>
    956d:	48 39 d3             	cmp    %rdx,%rbx
    9570:	48 0f 47 da          	cmova  %rdx,%rbx
    9574:	48 89 d8             	mov    %rbx,%rax
    9577:	48 c1 e8 3c          	shr    $0x3c,%rax
    957b:	0f 85 e3 03 00 00    	jne    9964 <f23+0x4e4>
    9581:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9585:	be 02 00 00 00       	mov    $0x2,%esi
    958a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9591:	00 
    9592:	e8 b9 c4 ff ff       	call   5a50 <fwp_heap_alloc>
    9597:	48 89 28             	mov    %rbp,(%rax)
    959a:	48 8b 15 97 85 01 00 	mov    0x18597(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    95a1:	49 89 c4             	mov    %rax,%r12
    95a4:	48 2b 05 65 85 01 00 	sub    0x18565(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    95ab:	48 c1 e2 10          	shl    $0x10,%rdx
    95af:	48 39 d0             	cmp    %rdx,%rax
    95b2:	73 57                	jae    960b <f23+0x18b>
    95b4:	48 89 c2             	mov    %rax,%rdx
    95b7:	48 c1 ea 10          	shr    $0x10,%rdx
    95bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95bf:	48 8b 15 92 85 01 00 	mov    0x18592(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    95c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    95ce:	48 85 ed             	test   %rbp,%rbp
    95d1:	74 38                	je     960b <f23+0x18b>
    95d3:	0f b6 0a             	movzbl (%rdx),%ecx
    95d6:	80 f9 02             	cmp    $0x2,%cl
    95d9:	0f 84 a1 02 00 00    	je     9880 <f23+0x400>
    95df:	80 f9 01             	cmp    $0x1,%cl
    95e2:	75 27                	jne    960b <f23+0x18b>
    95e4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95e7:	0f b7 c0             	movzwl %ax,%eax
    95ea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95ed:	48 0f af c1          	imul   %rcx,%rax
    95f1:	48 c1 e8 20          	shr    $0x20,%rax
    95f5:	48 39 d0             	cmp    %rdx,%rax
    95f8:	73 11                	jae    960b <f23+0x18b>
    95fa:	48 01 c5             	add    %rax,%rbp
    95fd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9601:	0f 84 29 03 00 00    	je     9930 <f23+0x4b0>
    9607:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    960b:	48 85 db             	test   %rbx,%rbx
    960e:	74 5d                	je     966d <f23+0x1ed>
    9610:	48 c1 e3 04          	shl    $0x4,%rbx
    9614:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9619:	4c 89 e5             	mov    %r12,%rbp
    961c:	4d 89 ee             	mov    %r13,%r14
    961f:	4c 01 e3             	add    %r12,%rbx
    9622:	0f 1f 00             	nopl   (%rax)
    9625:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    962c:	00 00 00 00 
    9630:	49 8b 46 08          	mov    0x8(%r14),%rax
    9634:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9638:	48 83 c5 10          	add    $0x10,%rbp
    963c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9641:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9645:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9649:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    964e:	e8 dd ca ff ff       	call   6130 <w107>
    9653:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9658:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    965c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9660:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9664:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9668:	48 39 eb             	cmp    %rbp,%rbx
    966b:	75 c3                	jne    9630 <f23+0x1b0>
    966d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9672:	31 db                	xor    %ebx,%ebx
    9674:	e8 d7 f9 ff ff       	call   9050 <fwp_drop2>
    9679:	4c 89 ef             	mov    %r13,%rdi
    967c:	e8 cf f9 ff ff       	call   9050 <fwp_drop2>
    9681:	4d 8b 2c 24          	mov    (%r12),%r13
    9685:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9689:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9690:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9697:	4d 85 ed             	test   %r13,%r13
    969a:	74 3f                	je     96db <f23+0x25b>
    969c:	0f 1f 40 00          	nopl   0x0(%rax)
    96a0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    96a7:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    96ac:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    96b3:	00 f0 3f 
    96b6:	48 83 c3 02          	add    $0x2,%rbx
    96ba:	48 89 ce             	mov    %rcx,%rsi
    96bd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    96c3:	e8 e8 c6 ff ff       	call   5db0 <fwp_p_ad_push>
    96c8:	4c 39 eb             	cmp    %r13,%rbx
    96cb:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    96d1:	48 89 c7             	mov    %rax,%rdi
    96d4:	72 ca                	jb     96a0 <f23+0x220>
    96d6:	66 49 0f 7e c5       	movq   %xmm0,%r13
    96db:	4c 89 e7             	mov    %r12,%rdi
    96de:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    96e3:	e8 48 de ff ff       	call   7530 <fwp_drop4>
    96e8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    96ed:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    96f2:	31 ff                	xor    %edi,%edi
    96f4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    96f9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    96fe:	e8 9d cb ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    9703:	48 8b 15 2e 84 01 00 	mov    0x1842e(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    970a:	48 89 c5             	mov    %rax,%rbp
    970d:	48 2b 05 fc 83 01 00 	sub    0x183fc(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9714:	48 c1 e2 10          	shl    $0x10,%rdx
    9718:	48 39 d0             	cmp    %rdx,%rax
    971b:	73 55                	jae    9772 <f23+0x2f2>
    971d:	48 89 c2             	mov    %rax,%rdx
    9720:	48 c1 ea 10          	shr    $0x10,%rdx
    9724:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9728:	48 8b 15 29 84 01 00 	mov    0x18429(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    972f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9733:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9737:	48 85 db             	test   %rbx,%rbx
    973a:	74 36                	je     9772 <f23+0x2f2>
    973c:	0f b6 0a             	movzbl (%rdx),%ecx
    973f:	80 f9 02             	cmp    $0x2,%cl
    9742:	0f 84 20 01 00 00    	je     9868 <f23+0x3e8>
    9748:	80 f9 01             	cmp    $0x1,%cl
    974b:	75 25                	jne    9772 <f23+0x2f2>
    974d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9750:	0f b7 c0             	movzwl %ax,%eax
    9753:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9756:	48 0f af c1          	imul   %rcx,%rax
    975a:	48 c1 e8 20          	shr    $0x20,%rax
    975e:	48 39 d0             	cmp    %rdx,%rax
    9761:	73 0f                	jae    9772 <f23+0x2f2>
    9763:	48 01 c3             	add    %rax,%rbx
    9766:	80 3b ff             	cmpb   $0xff,(%rbx)
    9769:	0f 84 b4 01 00 00    	je     9923 <f23+0x4a3>
    976f:	c6 03 01             	movb   $0x1,(%rbx)
    9772:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9777:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    977e:	00 00 
    9780:	0f 85 d9 01 00 00    	jne    995f <f23+0x4df>
    9786:	48 83 c4 38          	add    $0x38,%rsp
    978a:	48 89 e8             	mov    %rbp,%rax
    978d:	5b                   	pop    %rbx
    978e:	5d                   	pop    %rbp
    978f:	41 5c                	pop    %r12
    9791:	41 5d                	pop    %r13
    9793:	41 5e                	pop    %r14
    9795:	41 5f                	pop    %r15
    9797:	c3                   	ret
    9798:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    979f:	00 
    97a0:	66 85 c0             	test   %ax,%ax
    97a3:	0f 85 7c fd ff ff    	jne    9525 <f23+0xa5>
    97a9:	0f b6 07             	movzbl (%rdi),%eax
    97ac:	84 c0                	test   %al,%al
    97ae:	0f 84 71 fd ff ff    	je     9525 <f23+0xa5>
    97b4:	3c fd                	cmp    $0xfd,%al
    97b6:	0f 87 99 01 00 00    	ja     9955 <f23+0x4d5>
    97bc:	83 c0 01             	add    $0x1,%eax
    97bf:	88 07                	mov    %al,(%rdi)
    97c1:	e9 5f fd ff ff       	jmp    9525 <f23+0xa5>
    97c6:	48 f7 d9             	neg    %rcx
    97c9:	48 39 d1             	cmp    %rdx,%rcx
    97cc:	0f 83 ee 00 00 00    	jae    98c0 <f23+0x440>
    97d2:	48 89 c8             	mov    %rcx,%rax
    97d5:	48 c1 e8 10          	shr    $0x10,%rax
    97d9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    97dd:	48 8b 05 74 83 01 00 	mov    0x18374(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    97e4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    97e8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    97ec:	48 85 ff             	test   %rdi,%rdi
    97ef:	0f 84 cb 00 00 00    	je     98c0 <f23+0x440>
    97f5:	0f b6 02             	movzbl (%rdx),%eax
    97f8:	3c 02                	cmp    $0x2,%al
    97fa:	0f 84 9a 00 00 00    	je     989a <f23+0x41a>
    9800:	3c 01                	cmp    $0x1,%al
    9802:	0f 85 b8 00 00 00    	jne    98c0 <f23+0x440>
    9808:	0f b7 c1             	movzwl %cx,%eax
    980b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    980e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9811:	48 0f af c1          	imul   %rcx,%rax
    9815:	48 c1 e8 20          	shr    $0x20,%rax
    9819:	48 39 d0             	cmp    %rdx,%rax
    981c:	0f 83 9e 00 00 00    	jae    98c0 <f23+0x440>
    9822:	48 01 c7             	add    %rax,%rdi
    9825:	0f b6 07             	movzbl (%rdi),%eax
    9828:	84 c0                	test   %al,%al
    982a:	0f 84 90 00 00 00    	je     98c0 <f23+0x440>
    9830:	31 db                	xor    %ebx,%ebx
    9832:	0f 1f 00             	nopl   (%rax)
    9835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    983c:	00 00 00 00 
    9840:	3c fd                	cmp    $0xfd,%al
    9842:	0f 87 f5 00 00 00    	ja     993d <f23+0x4bd>
    9848:	83 c0 01             	add    $0x1,%eax
    984b:	88 07                	mov    %al,(%rdi)
    984d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9852:	31 d2                	xor    %edx,%edx
    9854:	4d 85 ed             	test   %r13,%r13
    9857:	0f 85 cd fc ff ff    	jne    952a <f23+0xaa>
    985d:	e9 eb fc ff ff       	jmp    954d <f23+0xcd>
    9862:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9868:	66 85 c0             	test   %ax,%ax
    986b:	0f 85 01 ff ff ff    	jne    9772 <f23+0x2f2>
    9871:	e9 f0 fe ff ff       	jmp    9766 <f23+0x2e6>
    9876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    987d:	00 00 00 
    9880:	66 85 c0             	test   %ax,%ax
    9883:	0f 85 82 fd ff ff    	jne    960b <f23+0x18b>
    9889:	e9 6f fd ff ff       	jmp    95fd <f23+0x17d>
    988e:	66 90                	xchg   %ax,%ax
    9890:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9895:	e9 94 fc ff ff       	jmp    952e <f23+0xae>
    989a:	66 85 c9             	test   %cx,%cx
    989d:	75 21                	jne    98c0 <f23+0x440>
    989f:	0f b6 07             	movzbl (%rdi),%eax
    98a2:	84 c0                	test   %al,%al
    98a4:	74 1a                	je     98c0 <f23+0x440>
    98a6:	3c fd                	cmp    $0xfd,%al
    98a8:	0f 87 c2 00 00 00    	ja     9970 <f23+0x4f0>
    98ae:	83 c0 01             	add    $0x1,%eax
    98b1:	88 07                	mov    %al,(%rdi)
    98b3:	66 90                	xchg   %ax,%ax
    98b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98bc:	00 00 00 00 
    98c0:	be 02 00 00 00       	mov    $0x2,%esi
    98c5:	bf 08 00 00 00       	mov    $0x8,%edi
    98ca:	e8 81 c1 ff ff       	call   5a50 <fwp_heap_alloc>
    98cf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    98d6:	48 8b 15 5b 82 01 00 	mov    0x1825b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    98dd:	49 89 c4             	mov    %rax,%r12
    98e0:	48 2b 05 29 82 01 00 	sub    0x18229(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    98e7:	48 c1 e2 10          	shl    $0x10,%rdx
    98eb:	48 39 d0             	cmp    %rdx,%rax
    98ee:	73 57                	jae    9947 <f23+0x4c7>
    98f0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    98f7:	00 00 
    98f9:	48 89 c2             	mov    %rax,%rdx
    98fc:	48 c1 ea 10          	shr    $0x10,%rdx
    9900:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9904:	48 8b 15 4d 82 01 00 	mov    0x1824d(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    990b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    990f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9913:	48 85 ed             	test   %rbp,%rbp
    9916:	0f 84 51 fd ff ff    	je     966d <f23+0x1ed>
    991c:	31 db                	xor    %ebx,%ebx
    991e:	e9 b0 fc ff ff       	jmp    95d3 <f23+0x153>
    9923:	48 89 df             	mov    %rbx,%rdi
    9926:	e8 e5 b9 ff ff       	call   5310 <fwp_rc_forget_slot>
    992b:	e9 3f fe ff ff       	jmp    976f <f23+0x2ef>
    9930:	48 89 ef             	mov    %rbp,%rdi
    9933:	e8 d8 b9 ff ff       	call   5310 <fwp_rc_forget_slot>
    9938:	e9 ca fc ff ff       	jmp    9607 <f23+0x187>
    993d:	e8 ae b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9942:	e9 06 ff ff ff       	jmp    984d <f23+0x3cd>
    9947:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    994e:	00 00 
    9950:	e9 18 fd ff ff       	jmp    966d <f23+0x1ed>
    9955:	e8 96 b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    995a:	e9 c6 fb ff ff       	jmp    9525 <f23+0xa5>
    995f:	e8 fc 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    9964:	48 8d 3d dc 27 00 00 	lea    0x27dc(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    996b:	e8 30 a8 ff ff       	call   41a0 <fwp_trap>
    9970:	e8 7b b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9975:	e9 46 ff ff ff       	jmp    98c0 <f23+0x440>
    997a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009980 <fwp_owned_entry23>:
    9980:	f3 0f 1e fa          	endbr64
    9984:	48 8b 3f             	mov    (%rdi),%rdi
    9987:	e9 f4 fa ff ff       	jmp    9480 <f23>
    998c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009990 <e23>:
    9990:	f3 0f 1e fa          	endbr64
    9994:	53                   	push   %rbx
    9995:	48 8b 1f             	mov    (%rdi),%rbx
    9998:	48 89 df             	mov    %rbx,%rdi
    999b:	e8 30 ca ff ff       	call   63d0 <fwp_rc_share>
    99a0:	48 89 df             	mov    %rbx,%rdi
    99a3:	e8 d8 fa ff ff       	call   9480 <f23>
    99a8:	48 89 c3             	mov    %rax,%rbx
    99ab:	48 89 c7             	mov    %rax,%rdi
    99ae:	e8 1d ca ff ff       	call   63d0 <fwp_rc_share>
    99b3:	48 89 d8             	mov    %rbx,%rax
    99b6:	5b                   	pop    %rbx
    99b7:	c3                   	ret
    99b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    99bf:	00 

00000000000099c0 <fwp_write>:
    99c0:	41 57                	push   %r15
    99c2:	41 56                	push   %r14
    99c4:	41 55                	push   %r13
    99c6:	41 54                	push   %r12
    99c8:	55                   	push   %rbp
    99c9:	53                   	push   %rbx
    99ca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    99d1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    99d8:	00 00 
    99da:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    99e1:	00 
    99e2:	49 89 d4             	mov    %rdx,%r12
    99e5:	8b 12                	mov    (%rdx),%edx
    99e7:	83 fa 19             	cmp    $0x19,%edx
    99ea:	77 6a                	ja     9a56 <fwp_write+0x96>
    99ec:	48 89 f5             	mov    %rsi,%rbp
    99ef:	89 d0                	mov    %edx,%eax
    99f1:	89 ce                	mov    %ecx,%esi
    99f3:	48 89 fb             	mov    %rdi,%rbx
    99f6:	48 8d 0d 13 30 00 00 	lea    0x3013(%rip),%rcx        # ca10 <_IO_stdin_used+0xa10>
    99fd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9a01:	48 01 c8             	add    %rcx,%rax
    9a04:	3e ff e0             	notrack jmp *%rax
    9a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a0e:	00 00 
    9a10:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9a14:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9a18:	48 89 ca             	mov    %rcx,%rdx
    9a1b:	48 85 c9             	test   %rcx,%rcx
    9a1e:	0f 88 9c 0c 00 00    	js     a6c0 <fwp_write+0xd00>
    9a24:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a2b:	00 
    9a2c:	48 89 c6             	mov    %rax,%rsi
    9a2f:	4c 89 e7             	mov    %r12,%rdi
    9a32:	e8 09 a0 ff ff       	call   3a40 <fwp_fmt_u128>
    9a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a3e:	00 00 
    9a40:	4c 89 e7             	mov    %r12,%rdi
    9a43:	e8 08 9a ff ff       	call   3450 <strlen@plt>
    9a48:	4c 89 e6             	mov    %r12,%rsi
    9a4b:	48 89 df             	mov    %rbx,%rdi
    9a4e:	48 89 c2             	mov    %rax,%rdx
    9a51:	e8 1a a6 ff ff       	call   4070 <buf_put>
    9a56:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a5d:	00 
    9a5e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a65:	00 00 
    9a67:	0f 85 28 04 00 00    	jne    9e95 <fwp_write+0x4d5>
    9a6d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9a74:	5b                   	pop    %rbx
    9a75:	5d                   	pop    %rbp
    9a76:	41 5c                	pop    %r12
    9a78:	41 5d                	pop    %r13
    9a7a:	41 5e                	pop    %r14
    9a7c:	41 5f                	pop    %r15
    9a7e:	c3                   	ret
    9a7f:	90                   	nop
    9a80:	49 89 e9             	mov    %rbp,%r9
    9a83:	4c 8d 05 f7 26 00 00 	lea    0x26f7(%rip),%r8        # c181 <_IO_stdin_used+0x181>
    9a8a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9a8f:	ba 02 00 00 00       	mov    $0x2,%edx
    9a94:	be 00 02 00 00       	mov    $0x200,%esi
    9a99:	31 c0                	xor    %eax,%eax
    9a9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9aa2:	00 
    9aa3:	e8 08 99 ff ff       	call   33b0 <__snprintf_chk@plt>
    9aa8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9aaf:	00 
    9ab0:	e8 9b 99 ff ff       	call   3450 <strlen@plt>
    9ab5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9abc:	00 
    9abd:	48 89 df             	mov    %rbx,%rdi
    9ac0:	48 89 c2             	mov    %rax,%rdx
    9ac3:	e8 a8 a5 ff ff       	call   4070 <buf_put>
    9ac8:	eb 8c                	jmp    9a56 <fwp_write+0x96>
    9aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ad0:	49 89 e9             	mov    %rbp,%r9
    9ad3:	4c 8d 05 a2 26 00 00 	lea    0x26a2(%rip),%r8        # c17c <_IO_stdin_used+0x17c>
    9ada:	eb ae                	jmp    9a8a <fwp_write+0xca>
    9adc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ae0:	83 fa 13             	cmp    $0x13,%edx
    9ae3:	48 8d 05 88 26 00 00 	lea    0x2688(%rip),%rax        # c172 <_IO_stdin_used+0x172>
    9aea:	48 8d 35 86 26 00 00 	lea    0x2686(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    9af1:	ba 04 00 00 00       	mov    $0x4,%edx
    9af6:	48 0f 44 f0          	cmove  %rax,%rsi
    9afa:	45 31 ed             	xor    %r13d,%r13d
    9afd:	e8 6e a5 ff ff       	call   4070 <buf_put>
    9b02:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b07:	0f 84 a3 08 00 00    	je     a3b0 <fwp_write+0x9f0>
    9b0d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9b12:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9b17:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b1c:	48 89 df             	mov    %rbx,%rdi
    9b1f:	49 0f 44 c5          	cmove  %r13,%rax
    9b23:	31 c9                	xor    %ecx,%ecx
    9b25:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9b2a:	e8 91 fe ff ff       	call   99c0 <fwp_write>
    9b2f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9b34:	0f 84 6e 09 00 00    	je     a4a8 <fwp_write+0xae8>
    9b3a:	49 83 c5 01          	add    $0x1,%r13
    9b3e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9b42:	0f 83 68 08 00 00    	jae    a3b0 <fwp_write+0x9f0>
    9b48:	ba 02 00 00 00       	mov    $0x2,%edx
    9b4d:	48 8d 35 6d 26 00 00 	lea    0x266d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    9b54:	48 89 df             	mov    %rbx,%rdi
    9b57:	e8 14 a5 ff ff       	call   4070 <buf_put>
    9b5c:	eb af                	jmp    9b0d <fwp_write+0x14d>
    9b5e:	66 90                	xchg   %ax,%ax
    9b60:	ba 06 00 00 00       	mov    $0x6,%edx
    9b65:	48 8d 35 2e 26 00 00 	lea    0x262e(%rip),%rsi        # c19a <_IO_stdin_used+0x19a>
    9b6c:	48 83 c5 10          	add    $0x10,%rbp
    9b70:	e8 fb a4 ff ff       	call   4070 <buf_put>
    9b75:	48 89 ef             	mov    %rbp,%rdi
    9b78:	e8 d3 98 ff ff       	call   3450 <strlen@plt>
    9b7d:	48 89 ee             	mov    %rbp,%rsi
    9b80:	48 89 df             	mov    %rbx,%rdi
    9b83:	48 89 c2             	mov    %rax,%rdx
    9b86:	e8 e5 a4 ff ff       	call   4070 <buf_put>
    9b8b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9b90:	ba 01 00 00 00       	mov    $0x1,%edx
    9b95:	48 89 df             	mov    %rbx,%rdi
    9b98:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9b9d:	e8 ce a4 ff ff       	call   4070 <buf_put>
    9ba2:	e9 af fe ff ff       	jmp    9a56 <fwp_write+0x96>
    9ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bae:	00 00 
    9bb0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9bb7:	00 
    9bb8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9bbf:	00 00 
    9bc1:	0f 85 ce 02 00 00    	jne    9e95 <fwp_write+0x4d5>
    9bc7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9bcc:	48 8d 35 b3 25 00 00 	lea    0x25b3(%rip),%rsi        # c186 <_IO_stdin_used+0x186>
    9bd3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9bda:	48 89 df             	mov    %rbx,%rdi
    9bdd:	5b                   	pop    %rbx
    9bde:	5d                   	pop    %rbp
    9bdf:	41 5c                	pop    %r12
    9be1:	41 5d                	pop    %r13
    9be3:	41 5e                	pop    %r14
    9be5:	41 5f                	pop    %r15
    9be7:	e9 84 a4 ff ff       	jmp    4070 <buf_put>
    9bec:	0f 1f 40 00          	nopl   0x0(%rax)
    9bf0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9bf5:	4d 85 ed             	test   %r13,%r13
    9bf8:	0f 84 02 0c 00 00    	je     a800 <fwp_write+0xe40>
    9bfe:	48 8d 35 c9 25 00 00 	lea    0x25c9(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    9c05:	4c 89 ef             	mov    %r13,%rdi
    9c08:	e8 23 99 ff ff       	call   3530 <strcmp@plt>
    9c0d:	41 89 c1             	mov    %eax,%r9d
    9c10:	85 c0                	test   %eax,%eax
    9c12:	0f 84 6c 0c 00 00    	je     a884 <fwp_write+0xec4>
    9c18:	4c 89 ef             	mov    %r13,%rdi
    9c1b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9c20:	e8 2b 98 ff ff       	call   3450 <strlen@plt>
    9c25:	4c 89 ee             	mov    %r13,%rsi
    9c28:	48 89 df             	mov    %rbx,%rdi
    9c2b:	48 89 c2             	mov    %rax,%rdx
    9c2e:	e8 3d a4 ff ff       	call   4070 <buf_put>
    9c33:	ba 01 00 00 00       	mov    $0x1,%edx
    9c38:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9c3d:	48 89 df             	mov    %rbx,%rdi
    9c40:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9c45:	e8 26 a4 ff ff       	call   4070 <buf_put>
    9c4a:	ba 01 00 00 00       	mov    $0x1,%edx
    9c4f:	4c 89 fe             	mov    %r15,%rsi
    9c52:	48 89 df             	mov    %rbx,%rdi
    9c55:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9c5a:	e8 11 a4 ff ff       	call   4070 <buf_put>
    9c5f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9c64:	45 31 f6             	xor    %r14d,%r14d
    9c67:	85 d2                	test   %edx,%edx
    9c69:	0f 8e 81 0a 00 00    	jle    a6f0 <fwp_write+0xd30>
    9c6f:	45 31 ed             	xor    %r13d,%r13d
    9c72:	4d 85 ed             	test   %r13,%r13
    9c75:	0f 85 75 07 00 00    	jne    a3f0 <fwp_write+0xa30>
    9c7b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9c82:	00 
    9c83:	45 85 f6             	test   %r14d,%r14d
    9c86:	0f 84 84 07 00 00    	je     a410 <fwp_write+0xa50>
    9c8c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9c91:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9c96:	48 89 df             	mov    %rbx,%rdi
    9c99:	49 83 c5 01          	add    $0x1,%r13
    9c9d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9ca1:	31 c9                	xor    %ecx,%ecx
    9ca3:	e8 18 fd ff ff       	call   99c0 <fwp_write>
    9ca8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9cad:	7f c3                	jg     9c72 <fwp_write+0x2b2>
    9caf:	45 85 f6             	test   %r14d,%r14d
    9cb2:	0f 84 38 0a 00 00    	je     a6f0 <fwp_write+0xd30>
    9cb8:	b8 29 00 00 00       	mov    $0x29,%eax
    9cbd:	ba 01 00 00 00       	mov    $0x1,%edx
    9cc2:	4c 89 fe             	mov    %r15,%rsi
    9cc5:	48 89 df             	mov    %rbx,%rdi
    9cc8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9ccc:	e8 9f a3 ff ff       	call   4070 <buf_put>
    9cd1:	e9 80 fd ff ff       	jmp    9a56 <fwp_write+0x96>
    9cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9cdd:	00 00 00 
    9ce0:	ba 01 00 00 00       	mov    $0x1,%edx
    9ce5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9cea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9cef:	e8 7c a3 ff ff       	call   4070 <buf_put>
    9cf4:	48 85 ed             	test   %rbp,%rbp
    9cf7:	0f 84 93 06 00 00    	je     a390 <fwp_write+0x9d0>
    9cfd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9d01:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d06:	31 c9                	xor    %ecx,%ecx
    9d08:	48 89 df             	mov    %rbx,%rdi
    9d0b:	e8 b0 fc ff ff       	call   99c0 <fwp_write>
    9d10:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9d14:	48 85 ed             	test   %rbp,%rbp
    9d17:	0f 84 73 06 00 00    	je     a390 <fwp_write+0x9d0>
    9d1d:	ba 02 00 00 00       	mov    $0x2,%edx
    9d22:	48 8d 35 98 24 00 00 	lea    0x2498(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    9d29:	48 89 df             	mov    %rbx,%rdi
    9d2c:	e8 3f a3 ff ff       	call   4070 <buf_put>
    9d31:	eb ca                	jmp    9cfd <fwp_write+0x33d>
    9d33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d38:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9d3c:	85 f6                	test   %esi,%esi
    9d3e:	0f 84 fc 07 00 00    	je     a540 <fwp_write+0xb80>
    9d44:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d4b:	00 
    9d4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d53:	00 00 
    9d55:	0f 85 3a 01 00 00    	jne    9e95 <fwp_write+0x4d5>
    9d5b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9d5f:	4c 89 ea             	mov    %r13,%rdx
    9d62:	e9 6c fe ff ff       	jmp    9bd3 <fwp_write+0x213>
    9d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d6e:	00 00 
    9d70:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9d75:	ba 01 00 00 00       	mov    $0x1,%edx
    9d7a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9d7f:	48 89 ee             	mov    %rbp,%rsi
    9d82:	e8 e9 a2 ff ff       	call   4070 <buf_put>
    9d87:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9d8c:	4c 89 e7             	mov    %r12,%rdi
    9d8f:	e8 bc 96 ff ff       	call   3450 <strlen@plt>
    9d94:	4c 89 e6             	mov    %r12,%rsi
    9d97:	48 89 df             	mov    %rbx,%rdi
    9d9a:	48 89 c2             	mov    %rax,%rdx
    9d9d:	e8 ce a2 ff ff       	call   4070 <buf_put>
    9da2:	ba 01 00 00 00       	mov    $0x1,%edx
    9da7:	48 89 ee             	mov    %rbp,%rsi
    9daa:	48 89 df             	mov    %rbx,%rdi
    9dad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9db2:	e8 b9 a2 ff ff       	call   4070 <buf_put>
    9db7:	e9 9a fc ff ff       	jmp    9a56 <fwp_write+0x96>
    9dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9dc0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9dc5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9dc9:	0f 8a 8e 0b 00 00    	jp     a95d <fwp_write+0xf9d>
    9dcf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9dd3:	66 0f 54 05 35 2d 00 	andpd  0x2d35(%rip),%xmm0        # cb10 <msg.4+0x90>
    9dda:	00 
    9ddb:	bd 01 00 00 00       	mov    $0x1,%ebp
    9de0:	66 0f 2e 05 68 2d 00 	ucomisd 0x2d68(%rip),%xmm0        # cb50 <msg.4+0xd0>
    9de7:	00 
    9de8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9def:	00 
    9df0:	0f 87 b2 09 00 00    	ja     a7a8 <fwp_write+0xde8>
    9df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dfd:	00 00 00 
    9e00:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e04:	89 ee                	mov    %ebp,%esi
    9e06:	4c 89 e7             	mov    %r12,%rdi
    9e09:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9e0e:	e8 ad a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9e13:	31 f6                	xor    %esi,%esi
    9e15:	4c 89 e7             	mov    %r12,%rdi
    9e18:	e8 f3 95 ff ff       	call   3410 <strtod@plt>
    9e1d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9e22:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9e26:	7a 06                	jp     9e2e <fwp_write+0x46e>
    9e28:	0f 84 e9 01 00 00    	je     a017 <fwp_write+0x657>
    9e2e:	83 c5 01             	add    $0x1,%ebp
    9e31:	83 fd 12             	cmp    $0x12,%ebp
    9e34:	75 ca                	jne    9e00 <fwp_write+0x440>
    9e36:	be 11 00 00 00       	mov    $0x11,%esi
    9e3b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e3f:	4c 89 e7             	mov    %r12,%rdi
    9e42:	e8 79 a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9e47:	e9 cb 01 00 00       	jmp    a017 <fwp_write+0x657>
    9e4c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e50:	48 83 fd 01          	cmp    $0x1,%rbp
    9e54:	0f 84 e6 08 00 00    	je     a740 <fwp_write+0xd80>
    9e5a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9e5e:	b8 02 00 00 00       	mov    $0x2,%eax
    9e63:	ba 01 00 00 00       	mov    $0x1,%edx
    9e68:	48 0f 44 d0          	cmove  %rax,%rdx
    9e6c:	48 8d 35 f7 22 00 00 	lea    0x22f7(%rip),%rsi        # c16a <_IO_stdin_used+0x16a>
    9e73:	48 8d 05 f5 22 00 00 	lea    0x22f5(%rip),%rax        # c16f <_IO_stdin_used+0x16f>
    9e7a:	48 0f 44 f0          	cmove  %rax,%rsi
    9e7e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e85:	00 
    9e86:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e8d:	00 00 
    9e8f:	0f 84 3e fd ff ff    	je     9bd3 <fwp_write+0x213>
    9e95:	e8 c6 95 ff ff       	call   3460 <__stack_chk_fail@plt>
    9e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ea0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9ea5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9eaa:	e8 01 a1 ff ff       	call   3fb0 <buf_grow>
    9eaf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9eb3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9eb9:	4c 03 0b             	add    (%rbx),%r9
    9ebc:	66 45 89 11          	mov    %r10w,(%r9)
    9ec0:	45 85 e4             	test   %r12d,%r12d
    9ec3:	0f 8e 07 05 00 00    	jle    a3d0 <fwp_write+0xa10>
    9ec9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9ed0:	55 55 55 
    9ed3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9ed8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9edf:	aa aa aa 
    9ee2:	49 83 c1 01          	add    $0x1,%r9
    9ee6:	eb 45                	jmp    9f2d <fwp_write+0x56d>
    9ee8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9eef:	00 
    9ef0:	be 01 00 00 00       	mov    $0x1,%esi
    9ef5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9efa:	88 07                	mov    %al,(%rdi)
    9efc:	48 89 e8             	mov    %rbp,%rax
    9eff:	49 f7 e8             	imul   %r8
    9f02:	48 89 e8             	mov    %rbp,%rax
    9f05:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f09:	48 29 c2             	sub    %rax,%rdx
    9f0c:	48 85 c9             	test   %rcx,%rcx
    9f0f:	0f 95 c0             	setne  %al
    9f12:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9f16:	48 83 ef 01          	sub    $0x1,%rdi
    9f1a:	48 21 c5             	and    %rax,%rbp
    9f1d:	48 29 ea             	sub    %rbp,%rdx
    9f20:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9f24:	49 39 f9             	cmp    %rdi,%r9
    9f27:	0f 84 a3 04 00 00    	je     a3d0 <fwp_write+0xa10>
    9f2d:	48 89 e8             	mov    %rbp,%rax
    9f30:	49 f7 e8             	imul   %r8
    9f33:	48 89 e8             	mov    %rbp,%rax
    9f36:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f3a:	48 89 d1             	mov    %rdx,%rcx
    9f3d:	48 29 c1             	sub    %rax,%rcx
    9f40:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9f44:	48 89 e9             	mov    %rbp,%rcx
    9f47:	48 29 c1             	sub    %rax,%rcx
    9f4a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9f4e:	49 f7 e2             	mul    %r10
    9f51:	b8 30 00 00 00       	mov    $0x30,%eax
    9f56:	48 89 d6             	mov    %rdx,%rsi
    9f59:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9f5d:	48 d1 ee             	shr    $1,%rsi
    9f60:	48 01 f2             	add    %rsi,%rdx
    9f63:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9f67:	48 29 d6             	sub    %rdx,%rsi
    9f6a:	74 8e                	je     9efa <fwp_write+0x53a>
    9f6c:	48 83 fe 01          	cmp    $0x1,%rsi
    9f70:	0f 85 7a ff ff ff    	jne    9ef0 <fwp_write+0x530>
    9f76:	31 f6                	xor    %esi,%esi
    9f78:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9f7d:	e9 78 ff ff ff       	jmp    9efa <fwp_write+0x53a>
    9f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f88:	66 0f 6e cd          	movd   %ebp,%xmm1
    9f8c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9f8f:	0f 8a c8 09 00 00    	jp     a95d <fwp_write+0xf9d>
    9f95:	0f 28 c1             	movaps %xmm1,%xmm0
    9f98:	0f 54 05 61 2b 00 00 	andps  0x2b61(%rip),%xmm0        # cb00 <msg.4+0x80>
    9f9f:	0f 2e 05 5e 20 00 00 	ucomiss 0x205e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    9fa6:	0f 87 24 08 00 00    	ja     a7d0 <fwp_write+0xe10>
    9fac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9fb0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9fb6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9fbd:	00 
    9fbe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9fc2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9fce:	00 00 
    9fd0:	44 89 ee             	mov    %r13d,%esi
    9fd3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9fd8:	4c 89 e7             	mov    %r12,%rdi
    9fdb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9fe0:	e8 db a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9fe5:	31 f6                	xor    %esi,%esi
    9fe7:	4c 89 e7             	mov    %r12,%rdi
    9fea:	e8 c1 94 ff ff       	call   34b0 <strtof@plt>
    9fef:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9ff4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9ff7:	7a 02                	jp     9ffb <fwp_write+0x63b>
    9ff9:	74 1c                	je     a017 <fwp_write+0x657>
    9ffb:	41 83 c5 01          	add    $0x1,%r13d
    9fff:	41 83 fd 0a          	cmp    $0xa,%r13d
    a003:	75 cb                	jne    9fd0 <fwp_write+0x610>
    a005:	be 09 00 00 00       	mov    $0x9,%esi
    a00a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a00f:	4c 89 e7             	mov    %r12,%rdi
    a012:	e8 a9 a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a017:	4c 89 e7             	mov    %r12,%rdi
    a01a:	e8 11 a1 ff ff       	call   4130 <fwp_finish_float>
    a01f:	e9 1c fa ff ff       	jmp    9a40 <fwp_write+0x80>
    a024:	0f 1f 40 00          	nopl   0x0(%rax)
    a028:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a02c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a030:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a037:	00 
    a038:	48 89 ef             	mov    %rbp,%rdi
    a03b:	e8 00 9a ff ff       	call   3a40 <fwp_fmt_u128>
    a040:	48 89 ef             	mov    %rbp,%rdi
    a043:	e8 08 94 ff ff       	call   3450 <strlen@plt>
    a048:	48 89 ee             	mov    %rbp,%rsi
    a04b:	48 89 df             	mov    %rbx,%rdi
    a04e:	48 89 c2             	mov    %rax,%rdx
    a051:	e8 1a a0 ff ff       	call   4070 <buf_put>
    a056:	e9 fb f9 ff ff       	jmp    9a56 <fwp_write+0x96>
    a05b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a060:	ba 06 00 00 00       	mov    $0x6,%edx
    a065:	48 8d 35 58 21 00 00 	lea    0x2158(%rip),%rsi        # c1c4 <_IO_stdin_used+0x1c4>
    a06c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a072:	e8 f9 9f ff ff       	call   4070 <buf_put>
    a077:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a07e:	ff ff 7f 
    a081:	48 23 55 00          	and    0x0(%rbp),%rdx
    a085:	0f 84 86 02 00 00    	je     a311 <fwp_write+0x951>
    a08b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a090:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a094:	48 85 d2             	test   %rdx,%rdx
    a097:	0f 84 ae 00 00 00    	je     a14b <fwp_write+0x78b>
    a09d:	8b 0a                	mov    (%rdx),%ecx
    a09f:	83 f9 1c             	cmp    $0x1c,%ecx
    a0a2:	0f 84 58 06 00 00    	je     a700 <fwp_write+0xd40>
    a0a8:	83 f9 1b             	cmp    $0x1b,%ecx
    a0ab:	0f 87 9a 00 00 00    	ja     a14b <fwp_write+0x78b>
    a0b1:	be 01 00 00 00       	mov    $0x1,%esi
    a0b6:	48 d3 e6             	shl    %cl,%rsi
    a0b9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a0bf:	0f 85 4b 04 00 00    	jne    a510 <fwp_write+0xb50>
    a0c5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a0cb:	0f 85 0f 04 00 00    	jne    a4e0 <fwp_write+0xb20>
    a0d1:	83 e6 21             	and    $0x21,%esi
    a0d4:	74 75                	je     a14b <fwp_write+0x78b>
    a0d6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a0db:	48 85 ff             	test   %rdi,%rdi
    a0de:	79 07                	jns    a0e7 <fwp_write+0x727>
    a0e0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a0e4:	4c 01 ee             	add    %r13,%rsi
    a0e7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a0eb:	85 c9                	test   %ecx,%ecx
    a0ed:	40 0f b6 f7          	movzbl %dil,%esi
    a0f1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a0f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0fc:	00 00 00 00 
    a100:	31 c9                	xor    %ecx,%ecx
    a102:	48 89 df             	mov    %rbx,%rdi
    a105:	49 83 c5 01          	add    $0x1,%r13
    a109:	e8 b2 f8 ff ff       	call   99c0 <fwp_write>
    a10e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a115:	ff ff 7f 
    a118:	48 23 55 00          	and    0x0(%rbp),%rdx
    a11c:	49 39 d5             	cmp    %rdx,%r13
    a11f:	0f 83 ec 01 00 00    	jae    a311 <fwp_write+0x951>
    a125:	ba 02 00 00 00       	mov    $0x2,%edx
    a12a:	48 89 df             	mov    %rbx,%rdi
    a12d:	48 8d 35 8d 20 00 00 	lea    0x208d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a134:	e8 37 9f ff ff       	call   4070 <buf_put>
    a139:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a13e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a142:	48 85 d2             	test   %rdx,%rdx
    a145:	0f 85 52 ff ff ff    	jne    a09d <fwp_write+0x6dd>
    a14b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a150:	48 85 ff             	test   %rdi,%rdi
    a153:	0f 88 cf 05 00 00    	js     a728 <fwp_write+0xd68>
    a159:	48 8b 31             	mov    (%rcx),%rsi
    a15c:	eb a2                	jmp    a100 <fwp_write+0x740>
    a15e:	66 90                	xchg   %ax,%ax
    a160:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a167:	00 
    a168:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a16f:	00 00 
    a171:	0f 85 1e fd ff ff    	jne    9e95 <fwp_write+0x4d5>
    a177:	ba 08 00 00 00       	mov    $0x8,%edx
    a17c:	48 8d 35 0e 20 00 00 	lea    0x200e(%rip),%rsi        # c191 <_IO_stdin_used+0x191>
    a183:	e9 4b fa ff ff       	jmp    9bd3 <fwp_write+0x213>
    a188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a18f:	00 
    a190:	89 e8                	mov    %ebp,%eax
    a192:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a199:	76 03                	jbe    a19e <fwp_write+0x7de>
    a19b:	8b 45 00             	mov    0x0(%rbp),%eax
    a19e:	41 89 c6             	mov    %eax,%r14d
    a1a1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a1a6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a1ab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a1af:	4c 89 ef             	mov    %r13,%rdi
    a1b2:	e8 99 92 ff ff       	call   3450 <strlen@plt>
    a1b7:	4c 89 ee             	mov    %r13,%rsi
    a1ba:	48 89 df             	mov    %rbx,%rdi
    a1bd:	48 89 c2             	mov    %rax,%rdx
    a1c0:	e8 ab 9e ff ff       	call   4070 <buf_put>
    a1c5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a1ca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a1ce:	85 f6                	test   %esi,%esi
    a1d0:	0f 8e 80 f8 ff ff    	jle    9a56 <fwp_write+0x96>
    a1d6:	45 31 ed             	xor    %r13d,%r13d
    a1d9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a1de:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a1e3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a1e8:	ba 01 00 00 00       	mov    $0x1,%edx
    a1ed:	4c 89 fe             	mov    %r15,%rsi
    a1f0:	48 89 04 24          	mov    %rax,(%rsp)
    a1f4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a1f9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a1fd:	48 89 df             	mov    %rbx,%rdi
    a200:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a204:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a209:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a20e:	e8 5d 9e ff ff       	call   4070 <buf_put>
    a213:	41 8b 06             	mov    (%r14),%eax
    a216:	83 f8 0e             	cmp    $0xe,%eax
    a219:	0f 84 71 02 00 00    	je     a490 <fwp_write+0xad0>
    a21f:	83 f8 10             	cmp    $0x10,%eax
    a222:	0f 84 38 02 00 00    	je     a460 <fwp_write+0xaa0>
    a228:	83 f8 0a             	cmp    $0xa,%eax
    a22b:	0f 84 7f 04 00 00    	je     a6b0 <fwp_write+0xcf0>
    a231:	0f 8f f9 00 00 00    	jg     a330 <fwp_write+0x970>
    a237:	83 f8 03             	cmp    $0x3,%eax
    a23a:	0f 8f 50 04 00 00    	jg     a690 <fwp_write+0xcd0>
    a240:	85 c0                	test   %eax,%eax
    a242:	78 10                	js     a254 <fwp_write+0x894>
    a244:	48 8b 04 24          	mov    (%rsp),%rax
    a248:	48 c1 e8 3f          	shr    $0x3f,%rax
    a24c:	85 c0                	test   %eax,%eax
    a24e:	0f 85 f9 00 00 00    	jne    a34d <fwp_write+0x98d>
    a254:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a259:	48 8b 34 24          	mov    (%rsp),%rsi
    a25d:	31 c9                	xor    %ecx,%ecx
    a25f:	48 89 df             	mov    %rbx,%rdi
    a262:	e8 59 f7 ff ff       	call   99c0 <fwp_write>
    a267:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a26c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a271:	49 83 c5 01          	add    $0x1,%r13
    a275:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a279:	0f 8f 5f ff ff ff    	jg     a1de <fwp_write+0x81e>
    a27f:	e9 d2 f7 ff ff       	jmp    9a56 <fwp_write+0x96>
    a284:	0f 1f 40 00          	nopl   0x0(%rax)
    a288:	ba 06 00 00 00       	mov    $0x6,%edx
    a28d:	48 8d 35 23 1f 00 00 	lea    0x1f23(%rip),%rsi        # c1b7 <_IO_stdin_used+0x1b7>
    a294:	45 31 ed             	xor    %r13d,%r13d
    a297:	e8 d4 9d ff ff       	call   4070 <buf_put>
    a29c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a2a1:	75 19                	jne    a2bc <fwp_write+0x8fc>
    a2a3:	eb 6c                	jmp    a311 <fwp_write+0x951>
    a2a5:	0f 1f 00             	nopl   (%rax)
    a2a8:	ba 02 00 00 00       	mov    $0x2,%edx
    a2ad:	48 8d 35 0d 1f 00 00 	lea    0x1f0d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a2b4:	48 89 df             	mov    %rbx,%rdi
    a2b7:	e8 b4 9d ff ff       	call   4070 <buf_put>
    a2bc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a2c2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a2c7:	31 c0                	xor    %eax,%eax
    a2c9:	49 83 c5 01          	add    $0x1,%r13
    a2cd:	4c 8d 05 ea 1e 00 00 	lea    0x1eea(%rip),%r8        # c1be <_IO_stdin_used+0x1be>
    a2d4:	ba 02 00 00 00       	mov    $0x2,%edx
    a2d9:	be 00 02 00 00       	mov    $0x200,%esi
    a2de:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a2e5:	00 
    a2e6:	e8 c5 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a2eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a2f2:	00 
    a2f3:	e8 58 91 ff ff       	call   3450 <strlen@plt>
    a2f8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a2ff:	00 
    a300:	48 89 df             	mov    %rbx,%rdi
    a303:	48 89 c2             	mov    %rax,%rdx
    a306:	e8 65 9d ff ff       	call   4070 <buf_put>
    a30b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a30f:	72 97                	jb     a2a8 <fwp_write+0x8e8>
    a311:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a316:	ba 01 00 00 00       	mov    $0x1,%edx
    a31b:	48 89 df             	mov    %rbx,%rdi
    a31e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a323:	e8 48 9d ff ff       	call   4070 <buf_put>
    a328:	e9 29 f7 ff ff       	jmp    9a56 <fwp_write+0x96>
    a32d:	0f 1f 00             	nopl   (%rax)
    a330:	83 f8 0b             	cmp    $0xb,%eax
    a333:	0f 85 1b ff ff ff    	jne    a254 <fwp_write+0x894>
    a339:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a33e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a342:	83 e0 01             	and    $0x1,%eax
    a345:	85 c0                	test   %eax,%eax
    a347:	0f 84 07 ff ff ff    	je     a254 <fwp_write+0x894>
    a34d:	4c 89 fe             	mov    %r15,%rsi
    a350:	48 89 df             	mov    %rbx,%rdi
    a353:	ba 01 00 00 00       	mov    $0x1,%edx
    a358:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a35d:	e8 0e 9d ff ff       	call   4070 <buf_put>
    a362:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a367:	48 8b 34 24          	mov    (%rsp),%rsi
    a36b:	31 c9                	xor    %ecx,%ecx
    a36d:	48 89 df             	mov    %rbx,%rdi
    a370:	e8 4b f6 ff ff       	call   99c0 <fwp_write>
    a375:	ba 01 00 00 00       	mov    $0x1,%edx
    a37a:	4c 89 fe             	mov    %r15,%rsi
    a37d:	48 89 df             	mov    %rbx,%rdi
    a380:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a385:	e8 e6 9c ff ff       	call   4070 <buf_put>
    a38a:	e9 d8 fe ff ff       	jmp    a267 <fwp_write+0x8a7>
    a38f:	90                   	nop
    a390:	ba 01 00 00 00       	mov    $0x1,%edx
    a395:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a39a:	48 89 df             	mov    %rbx,%rdi
    a39d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a3a2:	e8 c9 9c ff ff       	call   4070 <buf_put>
    a3a7:	e9 aa f6 ff ff       	jmp    9a56 <fwp_write+0x96>
    a3ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a3b0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3b5:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ba:	48 89 df             	mov    %rbx,%rdi
    a3bd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a3c2:	e8 a9 9c ff ff       	call   4070 <buf_put>
    a3c7:	e9 8a f6 ff ff       	jmp    9a56 <fwp_write+0x96>
    a3cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a3d0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a3d4:	48 8b 13             	mov    (%rbx),%rdx
    a3d7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a3dc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a3e0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a3e4:	e9 6d f6 ff ff       	jmp    9a56 <fwp_write+0x96>
    a3e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a3f5:	48 8d 35 c5 1d 00 00 	lea    0x1dc5(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a3fc:	48 89 df             	mov    %rbx,%rdi
    a3ff:	e8 6c 9c ff ff       	call   4070 <buf_put>
    a404:	e9 72 f8 ff ff       	jmp    9c7b <fwp_write+0x2bb>
    a409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a410:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a415:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a41a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a41e:	48 89 f7             	mov    %rsi,%rdi
    a421:	48 89 34 24          	mov    %rsi,(%rsp)
    a425:	e8 26 90 ff ff       	call   3450 <strlen@plt>
    a42a:	48 8b 34 24          	mov    (%rsp),%rsi
    a42e:	48 89 df             	mov    %rbx,%rdi
    a431:	48 89 c2             	mov    %rax,%rdx
    a434:	e8 37 9c ff ff       	call   4070 <buf_put>
    a439:	ba 03 00 00 00       	mov    $0x3,%edx
    a43e:	48 8d 35 9f 1d 00 00 	lea    0x1d9f(%rip),%rsi        # c1e4 <_IO_stdin_used+0x1e4>
    a445:	48 89 df             	mov    %rbx,%rdi
    a448:	e8 23 9c ff ff       	call   4070 <buf_put>
    a44d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a452:	e9 35 f8 ff ff       	jmp    9c8c <fwp_write+0x2cc>
    a457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a45e:	00 00 
    a460:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a465:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a469:	48 85 ff             	test   %rdi,%rdi
    a46c:	0f 84 e2 fd ff ff    	je     a254 <fwp_write+0x894>
    a472:	48 8d 35 55 1d 00 00 	lea    0x1d55(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    a479:	e8 b2 90 ff ff       	call   3530 <strcmp@plt>
    a47e:	85 c0                	test   %eax,%eax
    a480:	0f 95 c0             	setne  %al
    a483:	0f b6 c0             	movzbl %al,%eax
    a486:	e9 c1 fd ff ff       	jmp    a24c <fwp_write+0x88c>
    a48b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a490:	31 c0                	xor    %eax,%eax
    a492:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a499:	00 
    a49a:	0f 97 c0             	seta   %al
    a49d:	e9 aa fd ff ff       	jmp    a24c <fwp_write+0x88c>
    a4a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4a8:	48 89 df             	mov    %rbx,%rdi
    a4ab:	ba 02 00 00 00       	mov    $0x2,%edx
    a4b0:	48 8d 35 14 1d 00 00 	lea    0x1d14(%rip),%rsi        # c1cb <_IO_stdin_used+0x1cb>
    a4b7:	e8 b4 9b ff ff       	call   4070 <buf_put>
    a4bc:	4c 89 e8             	mov    %r13,%rax
    a4bf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a4c4:	31 c9                	xor    %ecx,%ecx
    a4c6:	48 c1 e0 04          	shl    $0x4,%rax
    a4ca:	48 89 df             	mov    %rbx,%rdi
    a4cd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a4d2:	e8 e9 f4 ff ff       	call   99c0 <fwp_write>
    a4d7:	e9 5e f6 ff ff       	jmp    9b3a <fwp_write+0x17a>
    a4dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a4e0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a4e5:	48 85 ff             	test   %rdi,%rdi
    a4e8:	79 0c                	jns    a4f6 <fwp_write+0xb36>
    a4ea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a4f1:	00 
    a4f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a4f6:	48 63 3e             	movslq (%rsi),%rdi
    a4f9:	83 f9 02             	cmp    $0x2,%ecx
    a4fc:	89 fe                	mov    %edi,%esi
    a4fe:	48 0f 44 f7          	cmove  %rdi,%rsi
    a502:	e9 f9 fb ff ff       	jmp    a100 <fwp_write+0x740>
    a507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a50e:	00 00 
    a510:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a515:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a51a:	48 85 ff             	test   %rdi,%rdi
    a51d:	0f 88 0f 03 00 00    	js     a832 <fwp_write+0xe72>
    a523:	49 0f bf 38          	movswq (%r8),%rdi
    a527:	83 f9 01             	cmp    $0x1,%ecx
    a52a:	0f b7 f7             	movzwl %di,%esi
    a52d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a531:	e9 ca fb ff ff       	jmp    a100 <fwp_write+0x740>
    a536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a53d:	00 00 00 
    a540:	ba 01 00 00 00       	mov    $0x1,%edx
    a545:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a54a:	48 83 c5 08          	add    $0x8,%rbp
    a54e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a553:	e8 18 9b ff ff       	call   4070 <buf_put>
    a558:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a55d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a562:	4d 85 ed             	test   %r13,%r13
    a565:	75 46                	jne    a5ad <fwp_write+0xbed>
    a567:	e9 04 01 00 00       	jmp    a670 <fwp_write+0xcb0>
    a56c:	0f 1f 40 00          	nopl   0x0(%rax)
    a570:	41 80 f9 09          	cmp    $0x9,%r9b
    a574:	0f 84 d6 00 00 00    	je     a650 <fwp_write+0xc90>
    a57a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a57e:	0f 85 9c 00 00 00    	jne    a620 <fwp_write+0xc60>
    a584:	ba 02 00 00 00       	mov    $0x2,%edx
    a589:	48 8d 35 17 1c 00 00 	lea    0x1c17(%rip),%rsi        # c1a7 <_IO_stdin_used+0x1a7>
    a590:	48 89 df             	mov    %rbx,%rdi
    a593:	e8 d8 9a ff ff       	call   4070 <buf_put>
    a598:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a59f:	00 
    a5a0:	48 83 c5 01          	add    $0x1,%rbp
    a5a4:	49 39 ec             	cmp    %rbp,%r12
    a5a7:	0f 84 c3 00 00 00    	je     a670 <fwp_write+0xcb0>
    a5ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a5b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a5b6:	74 28                	je     a5e0 <fwp_write+0xc20>
    a5b8:	7e b6                	jle    a570 <fwp_write+0xbb0>
    a5ba:	41 80 f9 22          	cmp    $0x22,%r9b
    a5be:	74 40                	je     a600 <fwp_write+0xc40>
    a5c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a5c4:	75 5a                	jne    a620 <fwp_write+0xc60>
    a5c6:	ba 02 00 00 00       	mov    $0x2,%edx
    a5cb:	48 8d 35 d2 1b 00 00 	lea    0x1bd2(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    a5d2:	48 89 df             	mov    %rbx,%rdi
    a5d5:	e8 96 9a ff ff       	call   4070 <buf_put>
    a5da:	eb c4                	jmp    a5a0 <fwp_write+0xbe0>
    a5dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a5e5:	48 8d 35 c1 1b 00 00 	lea    0x1bc1(%rip),%rsi        # c1ad <_IO_stdin_used+0x1ad>
    a5ec:	48 89 df             	mov    %rbx,%rdi
    a5ef:	e8 7c 9a ff ff       	call   4070 <buf_put>
    a5f4:	eb aa                	jmp    a5a0 <fwp_write+0xbe0>
    a5f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5fd:	00 00 00 
    a600:	ba 02 00 00 00       	mov    $0x2,%edx
    a605:	48 8d 35 95 1b 00 00 	lea    0x1b95(%rip),%rsi        # c1a1 <_IO_stdin_used+0x1a1>
    a60c:	48 89 df             	mov    %rbx,%rdi
    a60f:	e8 5c 9a ff ff       	call   4070 <buf_put>
    a614:	eb 8a                	jmp    a5a0 <fwp_write+0xbe0>
    a616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a61d:	00 00 00 
    a620:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a624:	0f 86 2e 01 00 00    	jbe    a758 <fwp_write+0xd98>
    a62a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a62e:	0f 84 24 01 00 00    	je     a758 <fwp_write+0xd98>
    a634:	ba 01 00 00 00       	mov    $0x1,%edx
    a639:	4c 89 fe             	mov    %r15,%rsi
    a63c:	48 89 df             	mov    %rbx,%rdi
    a63f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a644:	e8 27 9a ff ff       	call   4070 <buf_put>
    a649:	e9 52 ff ff ff       	jmp    a5a0 <fwp_write+0xbe0>
    a64e:	66 90                	xchg   %ax,%ax
    a650:	ba 02 00 00 00       	mov    $0x2,%edx
    a655:	48 8d 35 4e 1b 00 00 	lea    0x1b4e(%rip),%rsi        # c1aa <_IO_stdin_used+0x1aa>
    a65c:	48 89 df             	mov    %rbx,%rdi
    a65f:	e8 0c 9a ff ff       	call   4070 <buf_put>
    a664:	e9 37 ff ff ff       	jmp    a5a0 <fwp_write+0xbe0>
    a669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a670:	ba 01 00 00 00       	mov    $0x1,%edx
    a675:	4c 89 fe             	mov    %r15,%rsi
    a678:	48 89 df             	mov    %rbx,%rdi
    a67b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a680:	e8 eb 99 ff ff       	call   4070 <buf_put>
    a685:	e9 cc f3 ff ff       	jmp    9a56 <fwp_write+0x96>
    a68a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a690:	83 f8 04             	cmp    $0x4,%eax
    a693:	0f 85 bb fb ff ff    	jne    a254 <fwp_write+0x894>
    a699:	48 8b 04 24          	mov    (%rsp),%rax
    a69d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a6a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a6a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a6aa:	e9 96 fc ff ff       	jmp    a345 <fwp_write+0x985>
    a6af:	90                   	nop
    a6b0:	8b 0c 24             	mov    (%rsp),%ecx
    a6b3:	31 c0                	xor    %eax,%eax
    a6b5:	85 c9                	test   %ecx,%ecx
    a6b7:	0f 98 c0             	sets   %al
    a6ba:	e9 86 fc ff ff       	jmp    a345 <fwp_write+0x985>
    a6bf:	90                   	nop
    a6c0:	48 f7 d8             	neg    %rax
    a6c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a6ca:	00 
    a6cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a6d2:	2d 
    a6d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a6da:	00 
    a6db:	48 83 d2 00          	adc    $0x0,%rdx
    a6df:	48 89 c6             	mov    %rax,%rsi
    a6e2:	48 f7 da             	neg    %rdx
    a6e5:	e8 56 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a6ea:	e9 51 f3 ff ff       	jmp    9a40 <fwp_write+0x80>
    a6ef:	90                   	nop
    a6f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a6f5:	e9 c3 f5 ff ff       	jmp    9cbd <fwp_write+0x2fd>
    a6fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a700:	4c 89 e9             	mov    %r13,%rcx
    a703:	48 c1 e1 04          	shl    $0x4,%rcx
    a707:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a70c:	48 85 ff             	test   %rdi,%rdi
    a70f:	0f 89 eb f9 ff ff    	jns    a100 <fwp_write+0x740>
    a715:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a719:	48 89 ce             	mov    %rcx,%rsi
    a71c:	e9 df f9 ff ff       	jmp    a100 <fwp_write+0x740>
    a721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a728:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a72f:	00 
    a730:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a734:	e9 20 fa ff ff       	jmp    a159 <fwp_write+0x799>
    a739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a740:	ba 02 00 00 00       	mov    $0x2,%edx
    a745:	48 8d 35 20 1a 00 00 	lea    0x1a20(%rip),%rsi        # c16c <_IO_stdin_used+0x16c>
    a74c:	e9 2d f7 ff ff       	jmp    9e7e <fwp_write+0x4be>
    a751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a758:	4c 8d 05 51 1a 00 00 	lea    0x1a51(%rip),%r8        # c1b0 <_IO_stdin_used+0x1b0>
    a75f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a764:	31 c0                	xor    %eax,%eax
    a766:	ba 02 00 00 00       	mov    $0x2,%edx
    a76b:	be 10 00 00 00       	mov    $0x10,%esi
    a770:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a777:	00 
    a778:	e8 33 8c ff ff       	call   33b0 <__snprintf_chk@plt>
    a77d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a784:	00 
    a785:	e8 c6 8c ff ff       	call   3450 <strlen@plt>
    a78a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a791:	00 
    a792:	48 89 df             	mov    %rbx,%rdi
    a795:	48 89 c2             	mov    %rax,%rdx
    a798:	e8 d3 98 ff ff       	call   4070 <buf_put>
    a79d:	e9 fe fd ff ff       	jmp    a5a0 <fwp_write+0xbe0>
    a7a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a7ac:	48 8d 35 b3 19 00 00 	lea    0x19b3(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    a7b3:	48 8d 05 ab 19 00 00 	lea    0x19ab(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    a7ba:	4c 89 e7             	mov    %r12,%rdi
    a7bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a7c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    a7c5:	e8 26 8c ff ff       	call   33f0 <strcpy@plt>
    a7ca:	e9 71 f2 ff ff       	jmp    9a40 <fwp_write+0x80>
    a7cf:	90                   	nop
    a7d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a7d4:	48 8d 35 8b 19 00 00 	lea    0x198b(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    a7db:	48 8d 05 83 19 00 00 	lea    0x1983(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    a7e2:	0f 2f c8             	comiss %xmm0,%xmm1
    a7e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a7ec:	00 
    a7ed:	4c 89 e7             	mov    %r12,%rdi
    a7f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    a7f4:	e8 f7 8b ff ff       	call   33f0 <strcpy@plt>
    a7f9:	e9 42 f2 ff ff       	jmp    9a40 <fwp_write+0x80>
    a7fe:	66 90                	xchg   %ax,%ax
    a800:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a805:	45 85 c0             	test   %r8d,%r8d
    a808:	75 34                	jne    a83e <fwp_write+0xe7e>
    a80a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a811:	00 
    a812:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a819:	00 00 
    a81b:	0f 85 74 f6 ff ff    	jne    9e95 <fwp_write+0x4d5>
    a821:	ba 02 00 00 00       	mov    $0x2,%edx
    a826:	48 8d 35 b4 19 00 00 	lea    0x19b4(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    a82d:	e9 a1 f3 ff ff       	jmp    9bd3 <fwp_write+0x213>
    a832:	48 03 75 10          	add    0x10(%rbp),%rsi
    a836:	49 89 f0             	mov    %rsi,%r8
    a839:	e9 e5 fc ff ff       	jmp    a523 <fwp_write+0xb63>
    a83e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a843:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a848:	85 ff                	test   %edi,%edi
    a84a:	0f 84 fa f3 ff ff    	je     9c4a <fwp_write+0x28a>
    a850:	ba 01 00 00 00       	mov    $0x1,%edx
    a855:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a85a:	48 89 df             	mov    %rbx,%rdi
    a85d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a862:	e8 09 98 ff ff       	call   4070 <buf_put>
    a867:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a86c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a871:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a877:	85 c0                	test   %eax,%eax
    a879:	0f 8f f0 f3 ff ff    	jg     9c6f <fwp_write+0x2af>
    a87f:	e9 34 f4 ff ff       	jmp    9cb8 <fwp_write+0x2f8>
    a884:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a888:	49 89 c5             	mov    %rax,%r13
    a88b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a890:	49 89 c4             	mov    %rax,%r12
    a893:	49 c1 fd 3f          	sar    $0x3f,%r13
    a897:	4c 09 e8             	or     %r13,%rax
    a89a:	0f 84 a7 00 00 00    	je     a947 <fwp_write+0xf87>
    a8a0:	48 8d 2d 79 3b 00 00 	lea    0x3b79(%rip),%rbp        # e420 <units.1>
    a8a7:	4d 89 e7             	mov    %r12,%r15
    a8aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a8b3:	4c 89 ff             	mov    %r15,%rdi
    a8b6:	4c 89 ee             	mov    %r13,%rsi
    a8b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    a8bd:	48 99                	cqto
    a8bf:	48 89 d1             	mov    %rdx,%rcx
    a8c2:	48 89 c2             	mov    %rax,%rdx
    a8c5:	e8 d6 0f 00 00       	call   b8a0 <__divmodti4>
    a8ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    a8ce:	48 89 c1             	mov    %rax,%rcx
    a8d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a8d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a8db:	0f 84 94 00 00 00    	je     a975 <fwp_write+0xfb5>
    a8e1:	41 83 c1 01          	add    $0x1,%r9d
    a8e5:	48 83 c5 10          	add    $0x10,%rbp
    a8e9:	41 83 f9 05          	cmp    $0x5,%r9d
    a8ed:	75 bb                	jne    a8aa <fwp_write+0xeea>
    a8ef:	4d 85 ed             	test   %r13,%r13
    a8f2:	79 53                	jns    a947 <fwp_write+0xf87>
    a8f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a8f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a8fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a903:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a908:	48 99                	cqto
    a90a:	48 f7 d8             	neg    %rax
    a90d:	48 83 d2 00          	adc    $0x0,%rdx
    a911:	48 89 c6             	mov    %rax,%rsi
    a914:	48 f7 da             	neg    %rdx
    a917:	e8 24 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a91c:	49 89 e8             	mov    %rbp,%r8
    a91f:	ba 00 02 00 00       	mov    $0x200,%edx
    a924:	be 02 00 00 00       	mov    $0x2,%esi
    a929:	31 c0                	xor    %eax,%eax
    a92b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a932:	00 
    a933:	48 8d 0d a2 18 00 00 	lea    0x18a2(%rip),%rcx        # c1dc <_IO_stdin_used+0x1dc>
    a93a:	4c 89 e7             	mov    %r12,%rdi
    a93d:	e8 9e 8d ff ff       	call   36e0 <__sprintf_chk@plt>
    a942:	e9 f9 f0 ff ff       	jmp    9a40 <fwp_write+0x80>
    a947:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a94c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a951:	31 d2                	xor    %edx,%edx
    a953:	48 89 ef             	mov    %rbp,%rdi
    a956:	e8 e5 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a95b:	eb bf                	jmp    a91c <fwp_write+0xf5c>
    a95d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a964:	4e 61 4e 00 
    a968:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a96f:	00 
    a970:	e9 cb f0 ff ff       	jmp    9a40 <fwp_write+0x80>
    a975:	44 89 0c 24          	mov    %r9d,(%rsp)
    a979:	48 89 c8             	mov    %rcx,%rax
    a97c:	48 85 d2             	test   %rdx,%rdx
    a97f:	78 51                	js     a9d2 <fwp_write+0x1012>
    a981:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a986:	48 89 c6             	mov    %rax,%rsi
    a989:	48 89 ef             	mov    %rbp,%rdi
    a98c:	e8 af 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a991:	44 8b 0c 24          	mov    (%rsp),%r9d
    a995:	49 63 c1             	movslq %r9d,%rax
    a998:	49 89 e8             	mov    %rbp,%r8
    a99b:	ba 00 02 00 00       	mov    $0x200,%edx
    a9a0:	be 02 00 00 00       	mov    $0x2,%esi
    a9a5:	48 c1 e0 04          	shl    $0x4,%rax
    a9a9:	48 8d 3d 70 3a 00 00 	lea    0x3a70(%rip),%rdi        # e420 <units.1>
    a9b0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9b7:	00 
    a9b8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a9bc:	48 8d 0d 14 18 00 00 	lea    0x1814(%rip),%rcx        # c1d7 <_IO_stdin_used+0x1d7>
    a9c3:	4c 89 e7             	mov    %r12,%rdi
    a9c6:	31 c0                	xor    %eax,%eax
    a9c8:	e8 13 8d ff ff       	call   36e0 <__sprintf_chk@plt>
    a9cd:	e9 6e f0 ff ff       	jmp    9a40 <fwp_write+0x80>
    a9d2:	48 f7 d8             	neg    %rax
    a9d5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a9da:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a9df:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9e4:	48 83 d2 00          	adc    $0x0,%rdx
    a9e8:	48 89 c6             	mov    %rax,%rsi
    a9eb:	48 f7 da             	neg    %rdx
    a9ee:	e8 4d 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9f3:	44 8b 0c 24          	mov    (%rsp),%r9d
    a9f7:	eb 9c                	jmp    a995 <fwp_write+0xfd5>
    a9f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aa00 <fwp_main_thread>:
    aa00:	f3 0f 1e fa          	endbr64
    aa04:	41 57                	push   %r15
    aa06:	41 56                	push   %r14
    aa08:	41 55                	push   %r13
    aa0a:	41 54                	push   %r12
    aa0c:	55                   	push   %rbp
    aa0d:	53                   	push   %rbx
    aa0e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    aa15:	8b 35 e9 70 01 00    	mov    0x170e9(%rip),%esi        # 21b04 <fwp_heap+0x13a4>
    aa1b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aa22:	00 00 
    aa24:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    aa2b:	00 
    aa2c:	31 c0                	xor    %eax,%eax
    aa2e:	85 f6                	test   %esi,%esi
    aa30:	0f 84 42 06 00 00    	je     b078 <fwp_main_thread+0x678>
    aa36:	8b 0d cc 70 01 00    	mov    0x170cc(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    aa3c:	85 c9                	test   %ecx,%ecx
    aa3e:	0f 85 47 06 00 00    	jne    b08b <fwp_main_thread+0x68b>
    aa44:	48 8d 05 35 56 00 00 	lea    0x5635(%rip),%rax        # 10080 <alt.5>
    aa4b:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    aa50:	31 f6                	xor    %esi,%esi
    aa52:	48 c7 05 9b 56 01 00 	movq   $0x40000000,0x1569b(%rip)        # 200f8 <fwp_main_stack_size>
    aa59:	00 00 00 40 
    aa5d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    aa62:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    aa67:	48 89 c7             	mov    %rax,%rdi
    aa6a:	4c 89 25 8f 56 01 00 	mov    %r12,0x1568f(%rip)        # 20100 <fwp_main_stack_top>
    aa71:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    aa78:	01 00 
    aa7a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    aa81:	00 
    aa82:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aa87:	e8 34 8c ff ff       	call   36c0 <sigaltstack@plt>
    aa8c:	85 c0                	test   %eax,%eax
    aa8e:	0f 85 c7 0d 00 00    	jne    b85b <fwp_main_thread+0xe5b>
    aa94:	31 db                	xor    %ebx,%ebx
    aa96:	b9 12 00 00 00       	mov    $0x12,%ecx
    aa9b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    aaa2:	00 
    aaa3:	48 89 d8             	mov    %rbx,%rax
    aaa6:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
    aaad:	00 
    aaae:	f3 48 ab             	rep stos %rax,(%rdi)
    aab1:	48 8d 05 38 92 ff ff 	lea    -0x6dc8(%rip),%rax        # 3cf0 <fwp_segv>
    aab8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    aabf:	00 
    aac0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    aac5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    aacc:	00 
    aacd:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    aad4:	04 00 00 08 
    aad8:	e8 a3 8a ff ff       	call   3580 <sigemptyset@plt>
    aadd:	85 c0                	test   %eax,%eax
    aadf:	0f 85 76 0d 00 00    	jne    b85b <fwp_main_thread+0xe5b>
    aae5:	31 d2                	xor    %edx,%edx
    aae7:	4c 89 f6             	mov    %r14,%rsi
    aaea:	bf 0b 00 00 00       	mov    $0xb,%edi
    aaef:	e8 0c 89 ff ff       	call   3400 <sigaction@plt>
    aaf4:	85 c0                	test   %eax,%eax
    aaf6:	0f 85 5f 0d 00 00    	jne    b85b <fwp_main_thread+0xe5b>
    aafc:	31 d2                	xor    %edx,%edx
    aafe:	4c 89 f6             	mov    %r14,%rsi
    ab01:	bf 07 00 00 00       	mov    $0x7,%edi
    ab06:	e8 f5 88 ff ff       	call   3400 <sigaction@plt>
    ab0b:	85 c0                	test   %eax,%eax
    ab0d:	0f 85 48 0d 00 00    	jne    b85b <fwp_main_thread+0xe5b>
    ab13:	8b 15 57 55 00 00    	mov    0x5557(%rip),%edx        # 10070 <st.3>
    ab19:	85 d2                	test   %edx,%edx
    ab1b:	0f 84 7f 05 00 00    	je     b0a0 <fwp_main_thread+0x6a0>
    ab21:	48 8b 2d 18 5c 01 00 	mov    0x15c18(%rip),%rbp        # 20740 <fwp_cur>
    ab28:	48 85 ed             	test   %rbp,%rbp
    ab2b:	0f 84 bf 01 00 00    	je     acf0 <fwp_main_thread+0x2f0>
    ab31:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ab36:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ab3a:	48 89 eb             	mov    %rbp,%rbx
    ab3d:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ab42:	0f 84 41 01 00 00    	je     ac89 <fwp_main_thread+0x289>
    ab48:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ab4d:	0f 84 9d 02 00 00    	je     adf0 <fwp_main_thread+0x3f0>
    ab53:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ab57:	0f 84 73 02 00 00    	je     add0 <fwp_main_thread+0x3d0>
    ab5d:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ab61:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ab65:	0f 85 05 03 00 00    	jne    ae70 <fwp_main_thread+0x470>
    ab6b:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ab6f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ab76:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ab7a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ab81:	00 00 00 00 
    ab85:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ab8c:	48 85 d2             	test   %rdx,%rdx
    ab8f:	74 07                	je     ab98 <fwp_main_thread+0x198>
    ab91:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ab98:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ab9c:	48 85 c0             	test   %rax,%rax
    ab9f:	74 34                	je     abd5 <fwp_main_thread+0x1d5>
    aba1:	48 89 43 68          	mov    %rax,0x68(%rbx)
    aba5:	48 8b 05 6c 5b 01 00 	mov    0x15b6c(%rip),%rax        # 20718 <fwp_timers>
    abac:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    abb0:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    abb7:	00 00 00 00 
    abbb:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    abc2:	48 85 c0             	test   %rax,%rax
    abc5:	74 07                	je     abce <fwp_main_thread+0x1ce>
    abc7:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    abce:	48 89 1d 43 5b 01 00 	mov    %rbx,0x15b43(%rip)        # 20718 <fwp_timers>
    abd5:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    abd9:	e8 d2 c3 ff ff       	call   6fb0 <fwp_block>
    abde:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    abe5:	48 85 c9             	test   %rcx,%rcx
    abe8:	74 47                	je     ac31 <fwp_main_thread+0x231>
    abea:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    abf1:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    abf8:	48 85 d2             	test   %rdx,%rdx
    abfb:	0f 84 af 02 00 00    	je     aeb0 <fwp_main_thread+0x4b0>
    ac01:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ac08:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ac0f:	48 85 c0             	test   %rax,%rax
    ac12:	74 07                	je     ac1b <fwp_main_thread+0x21b>
    ac14:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ac1b:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ac22:	00 00 00 00 
    ac26:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ac2a:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    ac31:	48 8b 0d 08 5b 01 00 	mov    0x15b08(%rip),%rcx        # 20740 <fwp_cur>
    ac38:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ac3c:	0f 84 1e 02 00 00    	je     ae60 <fwp_main_thread+0x460>
    ac42:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ac49:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ac50:	48 85 d2             	test   %rdx,%rdx
    ac53:	0f 84 0f 04 00 00    	je     b068 <fwp_main_thread+0x668>
    ac59:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ac60:	48 85 c0             	test   %rax,%rax
    ac63:	74 07                	je     ac6c <fwp_main_thread+0x26c>
    ac65:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ac6c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ac70:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ac74:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    ac7b:	48 89 cb             	mov    %rcx,%rbx
    ac7e:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ac83:	0f 85 bf fe ff ff    	jne    ab48 <fwp_main_thread+0x148>
    ac89:	48 83 3d 47 77 01 00 	cmpq   $0x0,0x17747(%rip)        # 223d8 <fwp_state_len>
    ac90:	00 
    ac91:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    ac95:	74 69                	je     ad00 <fwp_main_thread+0x300>
    ac97:	48 39 1d 9a 5a 01 00 	cmp    %rbx,0x15a9a(%rip)        # 20738 <fwp_root>
    ac9e:	c7 05 d8 53 01 00 00 	movl   $0x0,0x153d8(%rip)        # 20080 <fwp_exit_code>
    aca5:	00 00 00 
    aca8:	0f 85 e0 0b 00 00    	jne    b88e <fwp_main_thread+0xe8e>
    acae:	48 85 db             	test   %rbx,%rbx
    acb1:	0f 84 21 02 00 00    	je     aed8 <fwp_main_thread+0x4d8>
    acb7:	48 8b 15 4a 5a 01 00 	mov    0x15a4a(%rip),%rdx        # 20708 <fwp_tasks_active>
    acbe:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    acc2:	48 85 d2             	test   %rdx,%rdx
    acc5:	0f 84 0d 02 00 00    	je     aed8 <fwp_main_thread+0x4d8>
    accb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    acd0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    acd4:	75 08                	jne    acde <fwp_main_thread+0x2de>
    acd6:	48 89 d7             	mov    %rdx,%rdi
    acd9:	e8 d2 93 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    acde:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ace5:	48 85 d2             	test   %rdx,%rdx
    ace8:	75 e6                	jne    acd0 <fwp_main_thread+0x2d0>
    acea:	e9 ae 00 00 00       	jmp    ad9d <fwp_main_thread+0x39d>
    acef:	90                   	nop
    acf0:	48 83 3d e0 76 01 00 	cmpq   $0x0,0x176e0(%rip)        # 223d8 <fwp_state_len>
    acf7:	00 
    acf8:	0f 85 c2 01 00 00    	jne    aec0 <fwp_main_thread+0x4c0>
    acfe:	31 db                	xor    %ebx,%ebx
    ad00:	48 83 3d c0 76 01 00 	cmpq   $0x0,0x176c0(%rip)        # 223c8 <fwp_state_owners>
    ad07:	00 
    ad08:	75 8d                	jne    ac97 <fwp_main_thread+0x297>
    ad0a:	48 8b 3d cf 76 01 00 	mov    0x176cf(%rip),%rdi        # 223e0 <fwp_state>
    ad11:	e8 3a a8 ff ff       	call   5550 <fwp_mem_free>
    ad16:	48 c7 05 bf 76 01 00 	movq   $0x0,0x176bf(%rip)        # 223e0 <fwp_state>
    ad1d:	00 00 00 00 
    ad21:	48 c7 05 a4 76 01 00 	movq   $0x0,0x176a4(%rip)        # 223d0 <fwp_state_cap>
    ad28:	00 00 00 00 
    ad2c:	48 85 db             	test   %rbx,%rbx
    ad2f:	0f 84 1e 0a 00 00    	je     b753 <fwp_main_thread+0xd53>
    ad35:	48 39 1d fc 59 01 00 	cmp    %rbx,0x159fc(%rip)        # 20738 <fwp_root>
    ad3c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ad43:	00 00 00 00 
    ad47:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ad4e:	00 00 00 00 
    ad52:	c7 05 24 53 01 00 00 	movl   $0x0,0x15324(%rip)        # 20080 <fwp_exit_code>
    ad59:	00 00 00 
    ad5c:	0f 84 55 ff ff ff    	je     acb7 <fwp_main_thread+0x2b7>
    ad62:	e9 e9 89 ff ff       	jmp    3750 <fwp_main_thread.cold>
    ad67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad6e:	00 00 
    ad70:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    ad77:	48 89 1d a2 59 01 00 	mov    %rbx,0x159a2(%rip)        # 20720 <fwp_ready_tail>
    ad7e:	e8 2d c2 ff ff       	call   6fb0 <fwp_block>
    ad83:	e8 28 c0 ff ff       	call   6db0 <fwp_free_zombie>
    ad88:	48 83 3d 78 59 01 00 	cmpq   $0x0,0x15978(%rip)        # 20708 <fwp_tasks_active>
    ad8f:	00 
    ad90:	0f 84 42 01 00 00    	je     aed8 <fwp_main_thread+0x4d8>
    ad96:	48 8b 1d 9b 59 01 00 	mov    0x1599b(%rip),%rbx        # 20738 <fwp_root>
    ad9d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ada1:	75 db                	jne    ad7e <fwp_main_thread+0x37e>
    ada3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ada7:	75 d5                	jne    ad7e <fwp_main_thread+0x37e>
    ada9:	48 8b 05 70 59 01 00 	mov    0x15970(%rip),%rax        # 20720 <fwp_ready_tail>
    adb0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    adb4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    adbb:	00 00 00 00 
    adbf:	48 85 c0             	test   %rax,%rax
    adc2:	75 ac                	jne    ad70 <fwp_main_thread+0x370>
    adc4:	48 89 1d 5d 59 01 00 	mov    %rbx,0x1595d(%rip)        # 20728 <fwp_ready_head>
    adcb:	eb aa                	jmp    ad77 <fwp_main_thread+0x377>
    adcd:	0f 1f 00             	nopl   (%rax)
    add0:	e8 3b 95 ff ff       	call   4310 <fwp_now_ns>
    add5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    add9:	7c 15                	jl     adf0 <fwp_main_thread+0x3f0>
    addb:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    addf:	75 0f                	jne    adf0 <fwp_main_thread+0x3f0>
    ade1:	48 89 ef             	mov    %rbp,%rdi
    ade4:	e8 c7 92 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    ade9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    adf0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    adf4:	0f 85 63 fd ff ff    	jne    ab5d <fwp_main_thread+0x15d>
    adfa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    adfe:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ae02:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae06:	0f 85 63 fd ff ff    	jne    ab6f <fwp_main_thread+0x16f>
    ae0c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ae10:	48 85 c9             	test   %rcx,%rcx
    ae13:	0f 84 56 fd ff ff    	je     ab6f <fwp_main_thread+0x16f>
    ae19:	48 39 c8             	cmp    %rcx,%rax
    ae1c:	48 89 ce             	mov    %rcx,%rsi
    ae1f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae26:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ae2a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae31:	00 00 00 00 
    ae35:	48 0f 4e f0          	cmovle %rax,%rsi
    ae39:	48 85 c0             	test   %rax,%rax
    ae3c:	48 89 c8             	mov    %rcx,%rax
    ae3f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ae46:	48 0f 45 c6          	cmovne %rsi,%rax
    ae4a:	48 85 d2             	test   %rdx,%rdx
    ae4d:	74 07                	je     ae56 <fwp_main_thread+0x456>
    ae4f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ae56:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ae5a:	e9 42 fd ff ff       	jmp    aba1 <fwp_main_thread+0x1a1>
    ae5f:	90                   	nop
    ae60:	48 89 cb             	mov    %rcx,%rbx
    ae63:	e9 d5 fc ff ff       	jmp    ab3d <fwp_main_thread+0x13d>
    ae68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ae6f:	00 
    ae70:	48 8b 45 40          	mov    0x40(%rbp),%rax
    ae74:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae7b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae82:	00 00 00 00 
    ae86:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    ae8d:	48 85 c0             	test   %rax,%rax
    ae90:	0f 84 3a 08 00 00    	je     b6d0 <fwp_main_thread+0xcd0>
    ae96:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    ae9d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    aea1:	e9 2f fd ff ff       	jmp    abd5 <fwp_main_thread+0x1d5>
    aea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aead:	00 00 00 
    aeb0:	48 89 01             	mov    %rax,(%rcx)
    aeb3:	e9 57 fd ff ff       	jmp    ac0f <fwp_main_thread+0x20f>
    aeb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aebf:	00 
    aec0:	48 83 3d 70 58 01 00 	cmpq   $0x0,0x15870(%rip)        # 20738 <fwp_root>
    aec7:	00 
    aec8:	c7 05 ae 51 01 00 00 	movl   $0x0,0x151ae(%rip)        # 20080 <fwp_exit_code>
    aecf:	00 00 00 
    aed2:	0f 85 b1 09 00 00    	jne    b889 <fwp_main_thread+0xe89>
    aed8:	e8 d3 be ff ff       	call   6db0 <fwp_free_zombie>
    aedd:	48 83 3d 43 58 01 00 	cmpq   $0x0,0x15843(%rip)        # 20728 <fwp_ready_head>
    aee4:	00 
    aee5:	0f 85 65 88 ff ff    	jne    3750 <fwp_main_thread.cold>
    aeeb:	48 83 3d 25 58 01 00 	cmpq   $0x0,0x15825(%rip)        # 20718 <fwp_timers>
    aef2:	00 
    aef3:	0f 85 57 88 ff ff    	jne    3750 <fwp_main_thread.cold>
    aef9:	8b 05 0d 52 01 00    	mov    0x1520d(%rip),%eax        # 2010c <fwp_stack_pool_n>
    aeff:	85 c0                	test   %eax,%eax
    af01:	74 3a                	je     af3d <fwp_main_thread+0x53d>
    af03:	83 e8 01             	sub    $0x1,%eax
    af06:	4c 8d 25 13 52 01 00 	lea    0x15213(%rip),%r12        # 20120 <fwp_stack_pool>
    af0d:	48 63 d8             	movslq %eax,%rbx
    af10:	89 c0                	mov    %eax,%eax
    af12:	48 89 da             	mov    %rbx,%rdx
    af15:	48 29 c2             	sub    %rax,%rdx
    af18:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    af1c:	0f 1f 40 00          	nopl   0x0(%rax)
    af20:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    af24:	89 1d e2 51 01 00    	mov    %ebx,0x151e2(%rip)        # 2010c <fwp_stack_pool_n>
    af2a:	be 00 00 00 10       	mov    $0x10000000,%esi
    af2f:	48 83 eb 01          	sub    $0x1,%rbx
    af33:	e8 a8 86 ff ff       	call   35e0 <munmap@plt>
    af38:	48 39 dd             	cmp    %rbx,%rbp
    af3b:	75 e3                	jne    af20 <fwp_main_thread+0x520>
    af3d:	8b 3d d5 50 00 00    	mov    0x50d5(%rip),%edi        # 10018 <fwp_epfd>
    af43:	85 ff                	test   %edi,%edi
    af45:	78 05                	js     af4c <fwp_main_thread+0x54c>
    af47:	e8 84 85 ff ff       	call   34d0 <close@plt>
    af4c:	4c 8b 25 cd 53 01 00 	mov    0x153cd(%rip),%r12        # 20320 <fwp_nfdws>
    af53:	48 8b 2d ce 53 01 00 	mov    0x153ce(%rip),%rbp        # 20328 <fwp_fdws>
    af5a:	31 db                	xor    %ebx,%ebx
    af5c:	c7 05 b2 50 00 00 ff 	movl   $0xffffffff,0x50b2(%rip)        # 10018 <fwp_epfd>
    af63:	ff ff ff 
    af66:	4d 85 e4             	test   %r12,%r12
    af69:	74 32                	je     af9d <fwp_main_thread+0x59d>
    af6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    af70:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    af75:	48 85 ff             	test   %rdi,%rdi
    af78:	74 1a                	je     af94 <fwp_main_thread+0x594>
    af7a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    af7e:	0f 85 cc 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    af84:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    af89:	0f 85 c1 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    af8f:	e8 bc a5 ff ff       	call   5550 <fwp_mem_free>
    af94:	48 83 c3 01          	add    $0x1,%rbx
    af98:	49 39 dc             	cmp    %rbx,%r12
    af9b:	75 d3                	jne    af70 <fwp_main_thread+0x570>
    af9d:	48 89 ef             	mov    %rbp,%rdi
    afa0:	e8 ab a5 ff ff       	call   5550 <fwp_mem_free>
    afa5:	48 8b 15 8c 57 01 00 	mov    0x1578c(%rip),%rdx        # 20738 <fwp_root>
    afac:	48 c7 05 71 53 01 00 	movq   $0x0,0x15371(%rip)        # 20328 <fwp_fdws>
    afb3:	00 00 00 00 
    afb7:	48 c7 05 5e 53 01 00 	movq   $0x0,0x1535e(%rip)        # 20320 <fwp_nfdws>
    afbe:	00 00 00 00 
    afc2:	48 85 d2             	test   %rdx,%rdx
    afc5:	74 4e                	je     b015 <fwp_main_thread+0x615>
    afc7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    afcc:	0f 85 7e 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afd2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    afd9:	00 
    afda:	0f 85 70 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afe0:	48 83 3d f0 73 01 00 	cmpq   $0x0,0x173f0(%rip)        # 223d8 <fwp_state_len>
    afe7:	00 
    afe8:	0f 85 62 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afee:	48 83 3d d2 73 01 00 	cmpq   $0x0,0x173d2(%rip)        # 223c8 <fwp_state_owners>
    aff5:	00 
    aff6:	0f 85 54 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    affc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b001:	31 c0                	xor    %eax,%eax
    b003:	48 8d 3d 36 53 01 00 	lea    0x15336(%rip),%rdi        # 20340 <fwp_root_context>
    b00a:	f3 48 ab             	rep stos %rax,(%rdi)
    b00d:	48 89 d7             	mov    %rdx,%rdi
    b010:	e8 3b a5 ff ff       	call   5550 <fwp_mem_free>
    b015:	48 8b 3d 04 50 00 00 	mov    0x5004(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b01c:	48 c7 05 19 57 01 00 	movq   $0x0,0x15719(%rip)        # 20740 <fwp_cur>
    b023:	00 00 00 00 
    b027:	48 c7 05 06 57 01 00 	movq   $0x0,0x15706(%rip)        # 20738 <fwp_root>
    b02e:	00 00 00 00 
    b032:	e8 89 85 ff ff       	call   35c0 <fflush@plt>
    b037:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b03e:	00 
    b03f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b046:	00 00 
    b048:	0f 85 2a 08 00 00    	jne    b878 <fwp_main_thread+0xe78>
    b04e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b055:	31 c0                	xor    %eax,%eax
    b057:	5b                   	pop    %rbx
    b058:	5d                   	pop    %rbp
    b059:	41 5c                	pop    %r12
    b05b:	41 5d                	pop    %r13
    b05d:	41 5e                	pop    %r14
    b05f:	41 5f                	pop    %r15
    b061:	c3                   	ret
    b062:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b068:	48 89 05 a9 56 01 00 	mov    %rax,0x156a9(%rip)        # 20718 <fwp_timers>
    b06f:	e9 ec fb ff ff       	jmp    ac60 <fwp_main_thread+0x260>
    b074:	0f 1f 40 00          	nopl   0x0(%rax)
    b078:	e8 b3 9a ff ff       	call   4b30 <fwp_heap_init>
    b07d:	8b 0d 85 6a 01 00    	mov    0x16a85(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    b083:	85 c9                	test   %ecx,%ecx
    b085:	0f 84 b9 f9 ff ff    	je     aa44 <fwp_main_thread+0x44>
    b08b:	48 8d 3d 8e 99 ff ff 	lea    -0x6672(%rip),%rdi        # 4a20 <fwp_heap_report>
    b092:	e8 19 0a 00 00       	call   bab0 <atexit>
    b097:	e9 a8 f9 ff ff       	jmp    aa44 <fwp_main_thread+0x44>
    b09c:	0f 1f 40 00          	nopl   0x0(%rax)
    b0a0:	48 8d 05 49 b6 ff ff 	lea    -0x49b7(%rip),%rax        # 66f0 <fwp_drop1>
    b0a7:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    b0ac:	4c 8b 35 3d 1a 00 00 	mov    0x1a3d(%rip),%r14        # caf0 <msg.4+0x70>
    b0b3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b0ba:	00 00 
    b0bc:	66 48 0f 6e d8       	movq   %rax,%xmm3
    b0c1:	48 8b 05 30 73 01 00 	mov    0x17330(%rip),%rax        # 223f8 <fwp_cleanups>
    b0c8:	31 ed                	xor    %ebp,%ebp
    b0ca:	4c 89 25 27 73 01 00 	mov    %r12,0x17327(%rip)        # 223f8 <fwp_cleanups>
    b0d1:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    b0d5:	41 bf ff 7f 00 00    	mov    $0x7fff,%r15d
    b0db:	48 8d 1d 7e 56 01 00 	lea    0x1567e(%rip),%rbx        # 20760 <fwp_heap>
    b0e2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b0e7:	48 8d 05 e2 8a ff ff 	lea    -0x751e(%rip),%rax        # 3bd0 <fwp_range_release>
    b0ee:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b0f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b0f8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b0fd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b102:	e9 06 01 00 00       	jmp    b20d <fwp_main_thread+0x80d>
    b107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b10e:	00 00 
    b110:	49 8b 14 24          	mov    (%r12),%rdx
    b114:	48 f7 d2             	not    %rdx
    b117:	48 89 10             	mov    %rdx,(%rax)
    b11a:	49 83 fd 18          	cmp    $0x18,%r13
    b11e:	76 1c                	jbe    b13c <fwp_main_thread+0x73c>
    b120:	49 8d 45 e7          	lea    -0x19(%r13),%rax
    b124:	49 8d 7c 24 18       	lea    0x18(%r12),%rdi
    b129:	31 f6                	xor    %esi,%esi
    b12b:	48 c1 e8 03          	shr    $0x3,%rax
    b12f:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b136:	00 
    b137:	e8 84 83 ff ff       	call   34c0 <memset@plt>
    b13c:	4c 89 e8             	mov    %r13,%rax
    b13f:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    b146:	0f 82 1b 07 00 00    	jb     b867 <fwp_main_thread+0xe67>
    b14c:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    b153:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    b15a:	73 07                	jae    b163 <fwp_main_thread+0x763>
    b15c:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    b163:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b167:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    b16c:	f2 0f 58 83 38 14 00 	addsd  0x1438(%rbx),%xmm0
    b173:	00 
    b174:	f2 0f 11 83 38 14 00 	movsd  %xmm0,0x1438(%rbx)
    b17b:	00 
    b17c:	49 89 6c 24 10       	mov    %rbp,0x10(%r12)
    b181:	4c 89 e0             	mov    %r12,%rax
    b184:	4c 89 e5             	mov    %r12,%rbp
    b187:	4d 89 34 24          	mov    %r14,(%r12)
    b18b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
    b190:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b197:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b19e:	48 c1 e2 10          	shl    $0x10,%rdx
    b1a2:	48 39 d0             	cmp    %rdx,%rax
    b1a5:	73 57                	jae    b1fe <fwp_main_thread+0x7fe>
    b1a7:	48 89 c2             	mov    %rax,%rdx
    b1aa:	48 c1 ea 10          	shr    $0x10,%rdx
    b1ae:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b1b2:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b1b9:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b1bd:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b1c1:	48 85 d2             	test   %rdx,%rdx
    b1c4:	74 38                	je     b1fe <fwp_main_thread+0x7fe>
    b1c6:	0f b6 3e             	movzbl (%rsi),%edi
    b1c9:	40 80 ff 02          	cmp    $0x2,%dil
    b1cd:	0f 84 ad 00 00 00    	je     b280 <fwp_main_thread+0x880>
    b1d3:	40 80 ff 01          	cmp    $0x1,%dil
    b1d7:	75 25                	jne    b1fe <fwp_main_thread+0x7fe>
    b1d9:	8b 7e 18             	mov    0x18(%rsi),%edi
    b1dc:	0f b7 c0             	movzwl %ax,%eax
    b1df:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b1e2:	48 0f af c7          	imul   %rdi,%rax
    b1e6:	48 c1 e8 20          	shr    $0x20,%rax
    b1ea:	48 39 f0             	cmp    %rsi,%rax
    b1ed:	73 0f                	jae    b1fe <fwp_main_thread+0x7fe>
    b1ef:	48 01 c2             	add    %rax,%rdx
    b1f2:	80 3a ff             	cmpb   $0xff,(%rdx)
    b1f5:	0f 84 25 05 00 00    	je     b720 <fwp_main_thread+0xd20>
    b1fb:	c6 02 01             	movb   $0x1,(%rdx)
    b1fe:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b203:	49 83 ef 01          	sub    $0x1,%r15
    b207:	0f 82 93 00 00 00    	jb     b2a0 <fwp_main_thread+0x8a0>
    b20d:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b213:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
    b218:	85 c0                	test   %eax,%eax
    b21a:	74 4c                	je     b268 <fwp_main_thread+0x868>
    b21c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    b223:	44 8b ac 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r13d
    b22a:	00 
    b22b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b22f:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    b233:	4c 8b 20             	mov    (%rax),%r12
    b236:	4d 85 e4             	test   %r12,%r12
    b239:	0f 85 d1 fe ff ff    	jne    b110 <fwp_main_thread+0x710>
    b23f:	4c 8b 60 08          	mov    0x8(%rax),%r12
    b243:	4d 85 e4             	test   %r12,%r12
    b246:	74 20                	je     b268 <fwp_main_thread+0x868>
    b248:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b24c:	4c 29 e2             	sub    %r12,%rdx
    b24f:	4c 39 ea             	cmp    %r13,%rdx
    b252:	72 14                	jb     b268 <fwp_main_thread+0x868>
    b254:	4b 8d 14 2c          	lea    (%r12,%r13,1),%rdx
    b258:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b25c:	e9 b9 fe ff ff       	jmp    b11a <fwp_main_thread+0x71a>
    b261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b268:	31 f6                	xor    %esi,%esi
    b26a:	bf 18 00 00 00       	mov    $0x18,%edi
    b26f:	e8 dc a7 ff ff       	call   5a50 <fwp_heap_alloc>
    b274:	49 89 c4             	mov    %rax,%r12
    b277:	e9 00 ff ff ff       	jmp    b17c <fwp_main_thread+0x77c>
    b27c:	0f 1f 40 00          	nopl   0x0(%rax)
    b280:	66 85 c0             	test   %ax,%ax
    b283:	0f 84 69 ff ff ff    	je     b1f2 <fwp_main_thread+0x7f2>
    b289:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b28e:	49 83 ef 01          	sub    $0x1,%r15
    b292:	0f 83 75 ff ff ff    	jae    b20d <fwp_main_thread+0x80d>
    b298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b29f:	00 
    b2a0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b2a5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b2aa:	bf 01 00 00 00       	mov    $0x1,%edi
    b2af:	66 0f 6f 05 69 18 00 	movdqa 0x1869(%rip),%xmm0        # cb20 <msg.4+0xa0>
    b2b6:	00 
    b2b7:	48 89 05 3a 71 01 00 	mov    %rax,0x1713a(%rip)        # 223f8 <fwp_cleanups>
    b2be:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b2c5:	00 
    b2c6:	e8 d5 af ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b2cb:	48 8b 15 66 68 01 00 	mov    0x16866(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b2d2:	49 89 c6             	mov    %rax,%r14
    b2d5:	48 2b 05 34 68 01 00 	sub    0x16834(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b2dc:	48 c1 e2 10          	shl    $0x10,%rdx
    b2e0:	48 39 d0             	cmp    %rdx,%rax
    b2e3:	73 59                	jae    b33e <fwp_main_thread+0x93e>
    b2e5:	48 89 c2             	mov    %rax,%rdx
    b2e8:	48 c1 ea 10          	shr    $0x10,%rdx
    b2ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2f0:	48 8b 15 61 68 01 00 	mov    0x16861(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b2f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2fb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b2ff:	4d 85 ed             	test   %r13,%r13
    b302:	74 3a                	je     b33e <fwp_main_thread+0x93e>
    b304:	0f b6 0a             	movzbl (%rdx),%ecx
    b307:	80 f9 02             	cmp    $0x2,%cl
    b30a:	0f 84 00 04 00 00    	je     b710 <fwp_main_thread+0xd10>
    b310:	80 f9 01             	cmp    $0x1,%cl
    b313:	75 29                	jne    b33e <fwp_main_thread+0x93e>
    b315:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b318:	0f b7 c0             	movzwl %ax,%eax
    b31b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b31e:	48 0f af c1          	imul   %rcx,%rax
    b322:	48 c1 e8 20          	shr    $0x20,%rax
    b326:	48 39 d0             	cmp    %rdx,%rax
    b329:	73 13                	jae    b33e <fwp_main_thread+0x93e>
    b32b:	49 01 c5             	add    %rax,%r13
    b32e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b333:	0f 84 6e 04 00 00    	je     b7a7 <fwp_main_thread+0xda7>
    b339:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b33e:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b343:	bf 01 00 00 00       	mov    $0x1,%edi
    b348:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b34d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b354:	00 f0 3f 
    b357:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b35c:	e8 3f af ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b361:	48 8b 15 d0 67 01 00 	mov    0x167d0(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b368:	49 89 c6             	mov    %rax,%r14
    b36b:	48 2b 05 9e 67 01 00 	sub    0x1679e(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b372:	48 c1 e2 10          	shl    $0x10,%rdx
    b376:	48 39 d0             	cmp    %rdx,%rax
    b379:	73 59                	jae    b3d4 <fwp_main_thread+0x9d4>
    b37b:	48 89 c2             	mov    %rax,%rdx
    b37e:	48 c1 ea 10          	shr    $0x10,%rdx
    b382:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b386:	48 8b 15 cb 67 01 00 	mov    0x167cb(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b38d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b391:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b395:	4d 85 ed             	test   %r13,%r13
    b398:	74 3a                	je     b3d4 <fwp_main_thread+0x9d4>
    b39a:	0f b6 0a             	movzbl (%rdx),%ecx
    b39d:	80 f9 02             	cmp    $0x2,%cl
    b3a0:	0f 84 5a 03 00 00    	je     b700 <fwp_main_thread+0xd00>
    b3a6:	80 f9 01             	cmp    $0x1,%cl
    b3a9:	75 29                	jne    b3d4 <fwp_main_thread+0x9d4>
    b3ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3ae:	0f b7 c0             	movzwl %ax,%eax
    b3b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3b4:	48 0f af c1          	imul   %rcx,%rax
    b3b8:	48 c1 e8 20          	shr    $0x20,%rax
    b3bc:	48 39 d0             	cmp    %rdx,%rax
    b3bf:	73 13                	jae    b3d4 <fwp_main_thread+0x9d4>
    b3c1:	49 01 c5             	add    %rax,%r13
    b3c4:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b3c9:	0f 84 e5 03 00 00    	je     b7b4 <fwp_main_thread+0xdb4>
    b3cf:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b3d4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b3d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b3de:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b3e3:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b3ea:	33 f3 bf 
    b3ed:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b3f2:	e8 a9 ae ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b3f7:	48 8b 15 3a 67 01 00 	mov    0x1673a(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b3fe:	48 8b 0d 0b 67 01 00 	mov    0x1670b(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b405:	49 89 c5             	mov    %rax,%r13
    b408:	48 89 d6             	mov    %rdx,%rsi
    b40b:	48 29 c8             	sub    %rcx,%rax
    b40e:	48 c1 e6 10          	shl    $0x10,%rsi
    b412:	48 39 f0             	cmp    %rsi,%rax
    b415:	73 67                	jae    b47e <fwp_main_thread+0xa7e>
    b417:	48 89 c6             	mov    %rax,%rsi
    b41a:	48 c1 ee 10          	shr    $0x10,%rsi
    b41e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b422:	48 8b 35 2f 67 01 00 	mov    0x1672f(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    b429:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b42d:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b431:	4d 85 f6             	test   %r14,%r14
    b434:	74 48                	je     b47e <fwp_main_thread+0xa7e>
    b436:	0f b6 3e             	movzbl (%rsi),%edi
    b439:	40 80 ff 02          	cmp    $0x2,%dil
    b43d:	0f 84 ad 02 00 00    	je     b6f0 <fwp_main_thread+0xcf0>
    b443:	40 80 ff 01          	cmp    $0x1,%dil
    b447:	75 35                	jne    b47e <fwp_main_thread+0xa7e>
    b449:	8b 7e 18             	mov    0x18(%rsi),%edi
    b44c:	0f b7 c0             	movzwl %ax,%eax
    b44f:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b452:	48 0f af c7          	imul   %rdi,%rax
    b456:	48 c1 e8 20          	shr    $0x20,%rax
    b45a:	48 39 f0             	cmp    %rsi,%rax
    b45d:	73 1f                	jae    b47e <fwp_main_thread+0xa7e>
    b45f:	49 01 c6             	add    %rax,%r14
    b462:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b466:	0f 84 55 03 00 00    	je     b7c1 <fwp_main_thread+0xdc1>
    b46c:	41 c6 06 01          	movb   $0x1,(%r14)
    b470:	48 8b 0d 99 66 01 00 	mov    0x16699(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b477:	48 8b 15 ba 66 01 00 	mov    0x166ba(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b47e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    b483:	4c 89 e8             	mov    %r13,%rax
    b486:	48 c1 e2 10          	shl    $0x10,%rdx
    b48a:	48 29 c8             	sub    %rcx,%rax
    b48d:	48 39 d0             	cmp    %rdx,%rax
    b490:	73 5d                	jae    b4ef <fwp_main_thread+0xaef>
    b492:	48 89 c2             	mov    %rax,%rdx
    b495:	48 c1 ea 10          	shr    $0x10,%rdx
    b499:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b49d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b4a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4a8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b4ac:	48 85 ff             	test   %rdi,%rdi
    b4af:	74 3e                	je     b4ef <fwp_main_thread+0xaef>
    b4b1:	0f b6 0a             	movzbl (%rdx),%ecx
    b4b4:	80 f9 02             	cmp    $0x2,%cl
    b4b7:	0f 84 23 02 00 00    	je     b6e0 <fwp_main_thread+0xce0>
    b4bd:	80 f9 01             	cmp    $0x1,%cl
    b4c0:	75 2d                	jne    b4ef <fwp_main_thread+0xaef>
    b4c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4c5:	0f b7 c0             	movzwl %ax,%eax
    b4c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4cb:	48 0f af c1          	imul   %rcx,%rax
    b4cf:	48 c1 e8 20          	shr    $0x20,%rax
    b4d3:	48 39 d0             	cmp    %rdx,%rax
    b4d6:	73 17                	jae    b4ef <fwp_main_thread+0xaef>
    b4d8:	48 01 c7             	add    %rax,%rdi
    b4db:	0f b6 07             	movzbl (%rdi),%eax
    b4de:	84 c0                	test   %al,%al
    b4e0:	74 0d                	je     b4ef <fwp_main_thread+0xaef>
    b4e2:	3c fd                	cmp    $0xfd,%al
    b4e4:	0f 87 e4 02 00 00    	ja     b7ce <fwp_main_thread+0xdce>
    b4ea:	83 c0 01             	add    $0x1,%eax
    b4ed:	88 07                	mov    %al,(%rdi)
    b4ef:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b4f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b4f8:	b9 01 00 00 00       	mov    $0x1,%ecx
    b4fd:	4c 89 ee             	mov    %r13,%rsi
    b500:	48 8d 15 99 46 00 00 	lea    0x4699(%rip),%rdx        # fba0 <d0>
    b507:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b50c:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b513:	00 00 
    b515:	e8 a6 e4 ff ff       	call   99c0 <fwp_write>
    b51a:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b51f:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
    b524:	48 8d 05 03 0b 00 00 	lea    0xb03(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    b52b:	4d 85 f6             	test   %r14,%r14
    b52e:	4c 0f 44 f0          	cmove  %rax,%r14
    b532:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b536:	0f 87 41 03 00 00    	ja     b87d <fwp_main_thread+0xe7d>
    b53c:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b540:	be 01 00 00 00       	mov    $0x1,%esi
    b545:	e8 06 a5 ff ff       	call   5a50 <fwp_heap_alloc>
    b54a:	4c 89 fa             	mov    %r15,%rdx
    b54d:	4c 89 f6             	mov    %r14,%rsi
    b550:	4c 89 38             	mov    %r15,(%rax)
    b553:	48 89 c5             	mov    %rax,%rbp
    b556:	48 8d 40 08          	lea    0x8(%rax),%rax
    b55a:	48 89 c7             	mov    %rax,%rdi
    b55d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    b562:	e8 39 80 ff ff       	call   35a0 <memcpy@plt>
    b567:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    b56d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b572:	e8 49 7e ff ff       	call   33c0 <free@plt>
    b577:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b57e:	48 89 e8             	mov    %rbp,%rax
    b581:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b588:	48 c1 e2 10          	shl    $0x10,%rdx
    b58c:	48 39 d0             	cmp    %rdx,%rax
    b58f:	73 57                	jae    b5e8 <fwp_main_thread+0xbe8>
    b591:	48 89 c2             	mov    %rax,%rdx
    b594:	48 c1 ea 10          	shr    $0x10,%rdx
    b598:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b59c:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b5a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5a7:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b5ab:	4d 85 f6             	test   %r14,%r14
    b5ae:	74 38                	je     b5e8 <fwp_main_thread+0xbe8>
    b5b0:	0f b6 0a             	movzbl (%rdx),%ecx
    b5b3:	80 f9 02             	cmp    $0x2,%cl
    b5b6:	0f 84 89 01 00 00    	je     b745 <fwp_main_thread+0xd45>
    b5bc:	80 f9 01             	cmp    $0x1,%cl
    b5bf:	75 27                	jne    b5e8 <fwp_main_thread+0xbe8>
    b5c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5c4:	0f b7 c0             	movzwl %ax,%eax
    b5c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5ca:	48 0f af c1          	imul   %rcx,%rax
    b5ce:	48 c1 e8 20          	shr    $0x20,%rax
    b5d2:	48 39 d0             	cmp    %rdx,%rax
    b5d5:	73 11                	jae    b5e8 <fwp_main_thread+0xbe8>
    b5d7:	49 01 c6             	add    %rax,%r14
    b5da:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b5de:	0f 84 f4 01 00 00    	je     b7d8 <fwp_main_thread+0xdd8>
    b5e4:	41 c6 06 01          	movb   $0x1,(%r14)
    b5e8:	4c 89 ef             	mov    %r13,%rdi
    b5eb:	e8 70 af ff ff       	call   6560 <fwp_drop0>
    b5f0:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    b5f4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b5f9:	be 01 00 00 00       	mov    $0x1,%esi
    b5fe:	48 8b 0d bb 6d 01 00 	mov    0x16dbb(%rip),%rcx        # 223c0 <fwp_prog_out>
    b605:	e8 76 80 ff ff       	call   3680 <fwrite@plt>
    b60a:	48 8b 35 af 6d 01 00 	mov    0x16daf(%rip),%rsi        # 223c0 <fwp_prog_out>
    b611:	bf 0a 00 00 00       	mov    $0xa,%edi
    b616:	e8 c5 7e ff ff       	call   34e0 <fputc@plt>
    b61b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b622:	48 89 e8             	mov    %rbp,%rax
    b625:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b62c:	48 c1 e2 10          	shl    $0x10,%rdx
    b630:	48 39 d0             	cmp    %rdx,%rax
    b633:	73 6b                	jae    b6a0 <fwp_main_thread+0xca0>
    b635:	48 89 c2             	mov    %rax,%rdx
    b638:	48 c1 ea 10          	shr    $0x10,%rdx
    b63c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b640:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b647:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b64b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b64f:	4d 85 f6             	test   %r14,%r14
    b652:	74 4c                	je     b6a0 <fwp_main_thread+0xca0>
    b654:	0f b6 0a             	movzbl (%rdx),%ecx
    b657:	80 f9 02             	cmp    $0x2,%cl
    b65a:	0f 84 d7 00 00 00    	je     b737 <fwp_main_thread+0xd37>
    b660:	80 f9 01             	cmp    $0x1,%cl
    b663:	75 3b                	jne    b6a0 <fwp_main_thread+0xca0>
    b665:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b668:	0f b7 c0             	movzwl %ax,%eax
    b66b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b66e:	48 0f af c1          	imul   %rcx,%rax
    b672:	48 c1 e8 20          	shr    $0x20,%rax
    b676:	48 39 d0             	cmp    %rdx,%rax
    b679:	73 25                	jae    b6a0 <fwp_main_thread+0xca0>
    b67b:	49 01 c6             	add    %rax,%r14
    b67e:	41 0f b6 06          	movzbl (%r14),%eax
    b682:	84 c0                	test   %al,%al
    b684:	74 1a                	je     b6a0 <fwp_main_thread+0xca0>
    b686:	3c 01                	cmp    $0x1,%al
    b688:	0f 84 0c 01 00 00    	je     b79a <fwp_main_thread+0xd9a>
    b68e:	3c ff                	cmp    $0xff,%al
    b690:	0f 84 4f 01 00 00    	je     b7e5 <fwp_main_thread+0xde5>
    b696:	83 e8 01             	sub    $0x1,%eax
    b699:	41 88 06             	mov    %al,(%r14)
    b69c:	0f 1f 40 00          	nopl   0x0(%rax)
    b6a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    b6a5:	48 8b 40 10          	mov    0x10(%rax),%rax
    b6a9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b6ae:	48 85 c0             	test   %rax,%rax
    b6b1:	0f 84 b9 00 00 00    	je     b770 <fwp_main_thread+0xd70>
    b6b7:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    b6be:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b6c5:	e9 b9 fd ff ff       	jmp    b483 <fwp_main_thread+0xa83>
    b6ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b6d0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b6d4:	e9 fc f4 ff ff       	jmp    abd5 <fwp_main_thread+0x1d5>
    b6d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6e0:	66 85 c0             	test   %ax,%ax
    b6e3:	0f 85 06 fe ff ff    	jne    b4ef <fwp_main_thread+0xaef>
    b6e9:	e9 ed fd ff ff       	jmp    b4db <fwp_main_thread+0xadb>
    b6ee:	66 90                	xchg   %ax,%ax
    b6f0:	66 85 c0             	test   %ax,%ax
    b6f3:	0f 85 85 fd ff ff    	jne    b47e <fwp_main_thread+0xa7e>
    b6f9:	e9 64 fd ff ff       	jmp    b462 <fwp_main_thread+0xa62>
    b6fe:	66 90                	xchg   %ax,%ax
    b700:	66 85 c0             	test   %ax,%ax
    b703:	0f 85 cb fc ff ff    	jne    b3d4 <fwp_main_thread+0x9d4>
    b709:	e9 b6 fc ff ff       	jmp    b3c4 <fwp_main_thread+0x9c4>
    b70e:	66 90                	xchg   %ax,%ax
    b710:	66 85 c0             	test   %ax,%ax
    b713:	0f 85 25 fc ff ff    	jne    b33e <fwp_main_thread+0x93e>
    b719:	e9 10 fc ff ff       	jmp    b32e <fwp_main_thread+0x92e>
    b71e:	66 90                	xchg   %ax,%ax
    b720:	48 89 d7             	mov    %rdx,%rdi
    b723:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    b728:	e8 e3 9b ff ff       	call   5310 <fwp_rc_forget_slot>
    b72d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    b732:	e9 c4 fa ff ff       	jmp    b1fb <fwp_main_thread+0x7fb>
    b737:	66 85 c0             	test   %ax,%ax
    b73a:	0f 85 60 ff ff ff    	jne    b6a0 <fwp_main_thread+0xca0>
    b740:	e9 39 ff ff ff       	jmp    b67e <fwp_main_thread+0xc7e>
    b745:	66 85 c0             	test   %ax,%ax
    b748:	0f 85 9a fe ff ff    	jne    b5e8 <fwp_main_thread+0xbe8>
    b74e:	e9 87 fe ff ff       	jmp    b5da <fwp_main_thread+0xbda>
    b753:	48 83 3d dd 4f 01 00 	cmpq   $0x0,0x14fdd(%rip)        # 20738 <fwp_root>
    b75a:	00 
    b75b:	c7 05 1b 49 01 00 00 	movl   $0x0,0x1491b(%rip)        # 20080 <fwp_exit_code>
    b762:	00 00 00 
    b765:	0f 84 6d f7 ff ff    	je     aed8 <fwp_main_thread+0x4d8>
    b76b:	e9 e0 7f ff ff       	jmp    3750 <fwp_main_thread.cold>
    b770:	4c 89 ef             	mov    %r13,%rdi
    b773:	e8 e8 ad ff ff       	call   6560 <fwp_drop0>
    b778:	4c 89 e7             	mov    %r12,%rdi
    b77b:	e8 e0 ad ff ff       	call   6560 <fwp_drop0>
    b780:	48 c7 05 dd 48 00 00 	movq   $0x0,0x48dd(%rip)        # 10068 <v.2>
    b787:	00 00 00 00 
    b78b:	c7 05 db 48 00 00 01 	movl   $0x1,0x48db(%rip)        # 10070 <st.3>
    b792:	00 00 00 
    b795:	e9 87 f3 ff ff       	jmp    ab21 <fwp_main_thread+0x121>
    b79a:	48 89 ef             	mov    %rbp,%rdi
    b79d:	e8 ae ac ff ff       	call   6450 <fwp_rc_free_arr>
    b7a2:	e9 f9 fe ff ff       	jmp    b6a0 <fwp_main_thread+0xca0>
    b7a7:	4c 89 ef             	mov    %r13,%rdi
    b7aa:	e8 61 9b ff ff       	call   5310 <fwp_rc_forget_slot>
    b7af:	e9 85 fb ff ff       	jmp    b339 <fwp_main_thread+0x939>
    b7b4:	4c 89 ef             	mov    %r13,%rdi
    b7b7:	e8 54 9b ff ff       	call   5310 <fwp_rc_forget_slot>
    b7bc:	e9 0e fc ff ff       	jmp    b3cf <fwp_main_thread+0x9cf>
    b7c1:	4c 89 f7             	mov    %r14,%rdi
    b7c4:	e8 47 9b ff ff       	call   5310 <fwp_rc_forget_slot>
    b7c9:	e9 9e fc ff ff       	jmp    b46c <fwp_main_thread+0xa6c>
    b7ce:	e8 1d 9a ff ff       	call   51f0 <fwp_rc_wide_dup>
    b7d3:	e9 17 fd ff ff       	jmp    b4ef <fwp_main_thread+0xaef>
    b7d8:	4c 89 f7             	mov    %r14,%rdi
    b7db:	e8 30 9b ff ff       	call   5310 <fwp_rc_forget_slot>
    b7e0:	e9 ff fd ff ff       	jmp    b5e4 <fwp_main_thread+0xbe4>
    b7e5:	4c 89 f0             	mov    %r14,%rax
    b7e8:	48 c1 e8 11          	shr    $0x11,%rax
    b7ec:	4c 31 f0             	xor    %r14,%rax
    b7ef:	48 89 c2             	mov    %rax,%rdx
    b7f2:	48 c1 ea 09          	shr    $0x9,%rdx
    b7f6:	48 31 d0             	xor    %rdx,%rax
    b7f9:	0f b6 d0             	movzbl %al,%edx
    b7fc:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    b803:	00 
    b804:	48 85 c0             	test   %rax,%rax
    b807:	75 20                	jne    b829 <fwp_main_thread+0xe29>
    b809:	eb 61                	jmp    b86c <fwp_main_thread+0xe6c>
    b80b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b812:	00 00 00 
    b815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b81c:	00 00 00 00 
    b820:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b824:	48 85 c0             	test   %rax,%rax
    b827:	74 43                	je     b86c <fwp_main_thread+0xe6c>
    b829:	48 89 c2             	mov    %rax,%rdx
    b82c:	4c 3b 30             	cmp    (%rax),%r14
    b82f:	75 ef                	jne    b820 <fwp_main_thread+0xe20>
    b831:	48 8b 48 08          	mov    0x8(%rax),%rcx
    b835:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    b839:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b83d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b844:	0f 85 56 fe ff ff    	jne    b6a0 <fwp_main_thread+0xca0>
    b84a:	4c 89 f7             	mov    %r14,%rdi
    b84d:	e8 be 9a ff ff       	call   5310 <fwp_rc_forget_slot>
    b852:	41 c6 06 fe          	movb   $0xfe,(%r14)
    b856:	e9 45 fe ff ff       	jmp    b6a0 <fwp_main_thread+0xca0>
    b85b:	48 8d 3d 8e 10 00 00 	lea    0x108e(%rip),%rdi        # c8f0 <_IO_stdin_used+0x8f0>
    b862:	e8 39 89 ff ff       	call   41a0 <fwp_trap>
    b867:	e8 44 84 ff ff       	call   3cb0 <fwp_heap_oom>
    b86c:	48 8d 3d 25 0f 00 00 	lea    0xf25(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    b873:	e8 28 89 ff ff       	call   41a0 <fwp_trap>
    b878:	e8 e3 7b ff ff       	call   3460 <__stack_chk_fail@plt>
    b87d:	48 8d 3d 64 09 00 00 	lea    0x964(%rip),%rdi        # c1e8 <_IO_stdin_used+0x1e8>
    b884:	e8 17 89 ff ff       	call   41a0 <fwp_trap>
    b889:	e9 c2 7e ff ff       	jmp    3750 <fwp_main_thread.cold>
    b88e:	e9 bd 7e ff ff       	jmp    3750 <fwp_main_thread.cold>
    b893:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b89a:	00 00 00 
    b89d:	0f 1f 00             	nopl   (%rax)

000000000000b8a0 <__divmodti4>:
    b8a0:	f3 0f 1e fa          	endbr64
    b8a4:	55                   	push   %rbp
    b8a5:	49 89 f1             	mov    %rsi,%r9
    b8a8:	49 89 d2             	mov    %rdx,%r10
    b8ab:	48 89 fe             	mov    %rdi,%rsi
    b8ae:	49 89 cb             	mov    %rcx,%r11
    b8b1:	48 89 e5             	mov    %rsp,%rbp
    b8b4:	41 57                	push   %r15
    b8b6:	41 56                	push   %r14
    b8b8:	41 55                	push   %r13
    b8ba:	41 54                	push   %r12
    b8bc:	53                   	push   %rbx
    b8bd:	4c 89 c3             	mov    %r8,%rbx
    b8c0:	45 31 c0             	xor    %r8d,%r8d
    b8c3:	4d 85 c9             	test   %r9,%r9
    b8c6:	79 12                	jns    b8da <__divmodti4+0x3a>
    b8c8:	31 ff                	xor    %edi,%edi
    b8ca:	48 f7 de             	neg    %rsi
    b8cd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b8d4:	4c 19 cf             	sbb    %r9,%rdi
    b8d7:	49 89 f9             	mov    %rdi,%r9
    b8da:	4c 89 d8             	mov    %r11,%rax
    b8dd:	4d 85 db             	test   %r11,%r11
    b8e0:	0f 88 1a 01 00 00    	js     ba00 <__divmodti4+0x160>
    b8e6:	4c 89 d9             	mov    %r11,%rcx
    b8e9:	49 89 f3             	mov    %rsi,%r11
    b8ec:	75 62                	jne    b950 <__divmodti4+0xb0>
    b8ee:	4d 89 c4             	mov    %r8,%r12
    b8f1:	4d 39 d1             	cmp    %r10,%r9
    b8f4:	0f 83 46 01 00 00    	jae    ba40 <__divmodti4+0x1a0>
    b8fa:	4c 89 d8             	mov    %r11,%rax
    b8fd:	4c 89 ca             	mov    %r9,%rdx
    b900:	49 f7 f2             	div    %r10
    b903:	49 89 c3             	mov    %rax,%r11
    b906:	31 c0                	xor    %eax,%eax
    b908:	48 89 d6             	mov    %rdx,%rsi
    b90b:	31 ff                	xor    %edi,%edi
    b90d:	4c 89 d9             	mov    %r11,%rcx
    b910:	48 89 c2             	mov    %rax,%rdx
    b913:	48 89 c8             	mov    %rcx,%rax
    b916:	4d 85 e4             	test   %r12,%r12
    b919:	74 0a                	je     b925 <__divmodti4+0x85>
    b91b:	48 f7 d8             	neg    %rax
    b91e:	48 83 d2 00          	adc    $0x0,%rdx
    b922:	48 f7 da             	neg    %rdx
    b925:	4d 85 c0             	test   %r8,%r8
    b928:	74 0a                	je     b934 <__divmodti4+0x94>
    b92a:	48 f7 de             	neg    %rsi
    b92d:	48 83 d7 00          	adc    $0x0,%rdi
    b931:	48 f7 df             	neg    %rdi
    b934:	48 89 33             	mov    %rsi,(%rbx)
    b937:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b93b:	5b                   	pop    %rbx
    b93c:	41 5c                	pop    %r12
    b93e:	41 5d                	pop    %r13
    b940:	41 5e                	pop    %r14
    b942:	41 5f                	pop    %r15
    b944:	5d                   	pop    %rbp
    b945:	c3                   	ret
    b946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b94d:	00 00 00 
    b950:	4d 89 c4             	mov    %r8,%r12
    b953:	49 39 c1             	cmp    %rax,%r9
    b956:	0f 82 ce 00 00 00    	jb     ba2a <__divmodti4+0x18a>
    b95c:	31 ff                	xor    %edi,%edi
    b95e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b963:	48 63 c7             	movslq %edi,%rax
    b966:	be 40 00 00 00       	mov    $0x40,%esi
    b96b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b970:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b975:	48 29 c6             	sub    %rax,%rsi
    b978:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b97d:	48 09 c8             	or     %rcx,%rax
    b980:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b985:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b98a:	49 89 c6             	mov    %rax,%r14
    b98d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b991:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b996:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b99b:	49 09 c1             	or     %rax,%r9
    b99e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b9a2:	4c 89 c8             	mov    %r9,%rax
    b9a5:	49 f7 f6             	div    %r14
    b9a8:	48 89 d1             	mov    %rdx,%rcx
    b9ab:	49 89 c3             	mov    %rax,%r11
    b9ae:	49 89 c1             	mov    %rax,%r9
    b9b1:	49 f7 e2             	mul    %r10
    b9b4:	49 89 c6             	mov    %rax,%r14
    b9b7:	49 89 d2             	mov    %rdx,%r10
    b9ba:	48 39 d1             	cmp    %rdx,%rcx
    b9bd:	72 07                	jb     b9c6 <__divmodti4+0x126>
    b9bf:	75 17                	jne    b9d8 <__divmodti4+0x138>
    b9c1:	49 39 c7             	cmp    %rax,%r15
    b9c4:	73 12                	jae    b9d8 <__divmodti4+0x138>
    b9c6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b9ca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b9ce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b9d2:	49 89 d2             	mov    %rdx,%r10
    b9d5:	49 89 c6             	mov    %rax,%r14
    b9d8:	4c 89 f8             	mov    %r15,%rax
    b9db:	4c 29 f0             	sub    %r14,%rax
    b9de:	4c 19 d1             	sbb    %r10,%rcx
    b9e1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b9e6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b9eb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b9f0:	48 09 c6             	or     %rax,%rsi
    b9f3:	48 89 cf             	mov    %rcx,%rdi
    b9f6:	31 c0                	xor    %eax,%eax
    b9f8:	4c 89 c9             	mov    %r9,%rcx
    b9fb:	e9 10 ff ff ff       	jmp    b910 <__divmodti4+0x70>
    ba00:	4c 89 d0             	mov    %r10,%rax
    ba03:	4c 89 da             	mov    %r11,%rdx
    ba06:	4d 89 c4             	mov    %r8,%r12
    ba09:	49 89 f3             	mov    %rsi,%r11
    ba0c:	48 f7 d8             	neg    %rax
    ba0f:	49 f7 d4             	not    %r12
    ba12:	48 83 d2 00          	adc    $0x0,%rdx
    ba16:	49 89 c2             	mov    %rax,%r10
    ba19:	48 f7 da             	neg    %rdx
    ba1c:	48 89 d1             	mov    %rdx,%rcx
    ba1f:	0f 84 cc fe ff ff    	je     b8f1 <__divmodti4+0x51>
    ba25:	49 39 d1             	cmp    %rdx,%r9
    ba28:	73 46                	jae    ba70 <__divmodti4+0x1d0>
    ba2a:	4c 89 cf             	mov    %r9,%rdi
    ba2d:	31 c0                	xor    %eax,%eax
    ba2f:	31 c9                	xor    %ecx,%ecx
    ba31:	e9 da fe ff ff       	jmp    b910 <__divmodti4+0x70>
    ba36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba3d:	00 00 00 
    ba40:	4d 85 d2             	test   %r10,%r10
    ba43:	75 0d                	jne    ba52 <__divmodti4+0x1b2>
    ba45:	b8 01 00 00 00       	mov    $0x1,%eax
    ba4a:	31 d2                	xor    %edx,%edx
    ba4c:	49 f7 f2             	div    %r10
    ba4f:	49 89 c2             	mov    %rax,%r10
    ba52:	4c 89 c8             	mov    %r9,%rax
    ba55:	31 d2                	xor    %edx,%edx
    ba57:	49 f7 f2             	div    %r10
    ba5a:	49 89 c1             	mov    %rax,%r9
    ba5d:	4c 89 d8             	mov    %r11,%rax
    ba60:	49 f7 f2             	div    %r10
    ba63:	49 89 c3             	mov    %rax,%r11
    ba66:	4c 89 c8             	mov    %r9,%rax
    ba69:	e9 9a fe ff ff       	jmp    b908 <__divmodti4+0x68>
    ba6e:	66 90                	xchg   %ax,%ax
    ba70:	45 31 f6             	xor    %r14d,%r14d
    ba73:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ba78:	44 89 f7             	mov    %r14d,%edi
    ba7b:	45 85 f6             	test   %r14d,%r14d
    ba7e:	0f 85 df fe ff ff    	jne    b963 <__divmodti4+0xc3>
    ba84:	4c 39 ca             	cmp    %r9,%rdx
    ba87:	72 17                	jb     baa0 <__divmodti4+0x200>
    ba89:	31 c9                	xor    %ecx,%ecx
    ba8b:	48 39 c6             	cmp    %rax,%rsi
    ba8e:	73 10                	jae    baa0 <__divmodti4+0x200>
    ba90:	4c 89 cf             	mov    %r9,%rdi
    ba93:	31 c0                	xor    %eax,%eax
    ba95:	e9 76 fe ff ff       	jmp    b910 <__divmodti4+0x70>
    ba9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    baa0:	4c 89 de             	mov    %r11,%rsi
    baa3:	b9 01 00 00 00       	mov    $0x1,%ecx
    baa8:	48 29 c6             	sub    %rax,%rsi
    baab:	49 19 d1             	sbb    %rdx,%r9
    baae:	eb e0                	jmp    ba90 <__divmodti4+0x1f0>

000000000000bab0 <atexit>:
    bab0:	f3 0f 1e fa          	endbr64
    bab4:	48 8b 15 4d 45 00 00 	mov    0x454d(%rip),%rdx        # 10008 <__dso_handle>
    babb:	31 f6                	xor    %esi,%esi
    babd:	e9 9e 7b ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bac4 <_fini>:
    bac4:	f3 0f 1e fa          	endbr64
    bac8:	48 83 ec 08          	sub    $0x8,%rsp
    bacc:	48 83 c4 08          	add    $0x8,%rsp
    bad0:	c3                   	ret
