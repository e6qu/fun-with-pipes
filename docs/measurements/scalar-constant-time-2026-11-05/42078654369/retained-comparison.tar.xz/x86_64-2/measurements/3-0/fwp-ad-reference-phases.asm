
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 bf 00 00 	mov    0xbfc1(%rip),%rax        # efd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da bd 00 00    	push   0xbdda(%rip)        # ee00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc bd 00 00    	jmp    *0xbddc(%rip)        # ee08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 bc 00 00    	jmp    *0xbc46(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # ee60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # ee68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # ee70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # ee78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ee80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ee88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # ee90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # ee98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eeb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eeb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # eec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # eec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # eed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # eed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # eee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # eee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # eef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # eef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # ef60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # ef68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # ef70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # ef78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # ef80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # ef88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 b8 00 00    	jmp    *0xb8e6(%rip)        # ef90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de b8 00 00    	jmp    *0xb8de(%rip)        # ef98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 b8 00 00    	jmp    *0xb8d6(%rip)        # efa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce b8 00 00    	jmp    *0xb8ce(%rip)        # efa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 b8 00 00    	jmp    *0xb8c6(%rip)        # efb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be b8 00 00    	jmp    *0xb8be(%rip)        # efb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 79 00 00 	lea    0x79dd(%rip),%r9        # b0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 79 00 00 	lea    0x79da(%rip),%r8        # b0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 9b 00 00 	lea    0x9b81(%rip),%rax        # d300 <fwp_fn_table>
    377f:	48 89 05 b2 dc 01 00 	mov    %rax,0x1dcb2(%rip)        # 21438 <fwp_fns>
    3786:	48 8b 05 93 b8 00 00 	mov    0xb893(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac dc 01 00 	mov    %rax,0x1dcac(%rip)        # 21440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d 8d 7a 00 00 	lea    0x7a8d(%rip),%rdi        # b22d <_IO_stdin_used+0x22d>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 b8 00 00 	mov    0xb818(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff 59 00 00 	lea    0x59ff(%rip),%rdx        # 9260 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 b7 00 00 	mov    0xb783(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f0a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 3d 79 00 00 	lea    0x793d(%rip),%rdi        # b236 <_IO_stdin_used+0x236>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d d6 80 00 00 	lea    0x80d6(%rip),%rdi        # b9e0 <_IO_stdin_used+0x9e0>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 90 80 00 00 	lea    0x8090(%rip),%rdi        # b9b8 <_IO_stdin_used+0x9b8>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 54 80 00 00 	lea    0x8054(%rip),%rdi        # b988 <_IO_stdin_used+0x988>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d 20 80 00 00 	lea    0x8020(%rip),%rdi        # b960 <_IO_stdin_used+0x960>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b b6 00 00    	call   *0xb64b(%rip)        # efc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 b6 00 00 	lea    0xb691(%rip),%rdi        # f018 <__TMC_END__>
    3987:	48 8d 05 8a b6 00 00 	lea    0xb68a(%rip),%rax        # f018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e b6 00 00 	mov    0xb62e(%rip),%rax        # efc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 b6 00 00 	lea    0xb661(%rip),%rdi        # f018 <__TMC_END__>
    39b7:	48 8d 35 5a b6 00 00 	lea    0xb65a(%rip),%rsi        # f018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd b5 00 00 	mov    0xb5fd(%rip),%rax        # efd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d b6 00 00 00 	cmpb   $0x0,0xb64d(%rip)        # f048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da b5 00 00 	cmpq   $0x0,0xb5da(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 b5 00 00 	mov    0xb5f6(%rip),%rdi        # f008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 b6 00 00 01 	movb   $0x1,0xb625(%rip)        # f048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee b4 01 00 	add    0x1b4ee(%rip),%rdx        # 1f110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc b4 01 00 	add    0x1b4dc(%rip),%rax        # 1f110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 d7 01 00 	mov    0x1d7c9(%rip),%rdi        # 21440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 b3 00 00 	mov    0xb394(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 b3 00 00 	mov    0xb381(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 73 00 00 	lea    0x7345(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 ba 01 00 	mov    0x1bac1(%rip),%rax        # 1f7c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 b3 01 00 	mov    0x1b3f9(%rip),%rax        # 1f178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 b3 01 00 	sub    0x1b3e5(%rip),%rax        # 1f170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 fd 7c 00 00 	lea    0x7cfd(%rip),%rsi        # bac0 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 5f 78 00 00 	lea    0x785f(%rip),%rdi        # b648 <_IO_stdin_used+0x648>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 b2 00 00 	mov    0xb242(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d dd b1 00 00 ff 	cmpl   $0xffffffff,0xb1dd(%rip)        # f010 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 71 00 00 	lea    0x71e2(%rip),%rax        # b022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 b2 01 00 	mov    0x1b2e1(%rip),%r9        # 1f128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ad 00 	movq   0xad9f(%rip),%xmm0        # ebf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 71 00 00 	lea    0x71e7(%rip),%rax        # b044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc b2 01 00 	mov    0x1b2bc(%rip),%r8        # 1f120 <descent_inputs>
    3e64:	48 8b 0d c5 b2 01 00 	mov    0x1b2c5(%rip),%rcx        # 1f130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 b1 00 00 	mov    0xb1c2(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 71 00 00 	lea    0x71d8(%rip),%rax        # b061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ad 00 	movq   0xad67(%rip),%xmm0        # ebf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 f8 77 00 00 	lea    0x77f8(%rip),%rdx        # b690 <_IO_stdin_used+0x690>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 b2 01 00 	lea    0x1b291(%rip),%r12        # 1f140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ad 00 	movq   0xad44(%rip),%xmm0        # ec00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b b1 00 00 	mov    0xb15b(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 71 00 00 	lea    0x7175(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 71 00 00 	lea    0x7170(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 b1 00 00 	mov    0xb120(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 71 00 00 	lea    0x7144(%rip),%rdi        # b07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 b0 00 00 	mov    0xb0f9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 71 00 00 	lea    0x7143(%rip),%rcx        # b091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 71 00 00 	lea    0x7119(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b cc 01 00 	mov    0x1cc3b(%rip),%rax        # 20bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 cc 01 00 	lea    0x1cc34(%rip),%r8        # 20bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 cc 01 00 	mov    0x1cc15(%rip),%rbx        # 20bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 cc 01 00 	mov    0x1cc25(%rip),%rcx        # 20bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 cb 01 00 	mov    0x1cbc1(%rip),%rdi        # 20bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a cc 01 00 	sub    %rsi,0x1cc0a(%rip)        # 20c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a cb 01 00 	mov    0x1cb9a(%rip),%rax        # 20bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 cb 01 00 	add    0x1cb50(%rip),%rdi        # 20b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e cb 01 00 	mov    0x1cb5e(%rip),%rsi        # 20bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c cb 01 00 	mov    0x1cb6c(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b cb 01 00 	mov    %r12,0x1cb1b(%rip)        # 20bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 cb 01 00 	mov    %rbp,0x1cb09(%rip)        # 20bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee ca 01 00 	cmp    %rdi,0x1caee(%rip)        # 20ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 ca 01 00 	mov    %rdi,0x1cae5(%rip)        # 20ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 cb 01 00 	sub    %rdi,0x1cb29(%rip)        # 20c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 ca 01 00 	mov    0x1cad1(%rip),%rax        # 20bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca ca 01 00 	lea    0x1caca(%rip),%r8        # 20bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ae 00 00 	mov    0xae5d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 6e 00 00 	lea    0x6e14(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d a5 ad 00 00 	movslq 0xada5(%rip),%rbp        # f010 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ae 01 00 	mov    0x1ae9a(%rip),%rsi        # 1f138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ae 01 00 	lea    0x1ae96(%rip),%rcx        # 1f140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ae 01 00 	addq   $0x1,0x1ae6b(%rip)        # 1f130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 40 ad 00 00    	mov    %ebx,0xad40(%rip)        # f010 <descent_active_phase>
    42d0:	48 89 05 61 ae 01 00 	mov    %rax,0x1ae61(%rip)        # 1f138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 b4 01 00 	cmp    0x1b4b9(%rip),%rdi        # 1f7c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f b4 01 00 	mov    0x1b47f(%rip),%rax        # 1f7a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d b4 01 00 	mov    %rdi,0x1b45d(%rip)        # 1f7a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 b4 01 00 	mov    %rdi,0x1b439(%rip)        # 1f7a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 6d 00 00 	lea    0x6dee(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 6c 00 00 	lea    0x6cba(%rip),%rsi        # b07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ac 00 00 	mov    0xac28(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 6c 00 00 	lea    0x6c64(%rip),%rdx        # b083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ac 00 00 	mov    0xac10(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 ab 00 00 	mov    0xab21(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 6a 00 00 	lea    0x6ad8(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 6b 00 00 	lea    0x6b45(%rip),%rdi        # b092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 6a 00 00 	lea    0x6acd(%rip),%rdi        # b0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d f0 70 00 00 	lea    0x70f0(%rip),%rdi        # b6e0 <_IO_stdin_used+0x6e0>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 d0 74 00 	movdqa 0x74d0(%rip),%xmm0        # bae0 <msg.8+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca cd 01 00 	add    0x1cdca(%rip),%rax        # 21438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 44 70 00 00 	lea    0x7044(%rip),%rdi        # b708 <_IO_stdin_used+0x708>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 aa 01 00 	cmp    %rax,0x1aa25(%rip)        # 1f108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 aa 01 00 	add    0x1aa20(%rip),%rax        # 1f110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 2d 70 00 00 	lea    0x702d(%rip),%rdi        # b738 <_IO_stdin_used+0x738>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 69 00 00 	lea    0x69a5(%rip),%r8        # b0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 67 00 00 	lea    0x67fa(%rip),%r8        # b0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 66 00 00 	lea    0x6697(%rip),%r8        # b0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 64 00 00 	lea    0x646f(%rip),%rdi        # b0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 65 00 00 	lea    0x6554(%rip),%rsi        # b1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 be 01 00 	mov    0x1bea5(%rip),%r9        # 20ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe be 01 00 	mov    0x1befe(%rip),%r8        # 20c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 77 6a 00 00 	lea    0x6a77(%rip),%rdx        # b788 <_IO_stdin_used+0x788>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 be 01 00 	mov    0x1bee6(%rip),%rcx        # 20c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 be 01 	movsd  0x1bef4(%rip),%xmm1        # 20c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 be 01 	movsd  0x1bee4(%rip),%xmm0        # 20c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 a3 00 00 	mov    0xa305(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 78 6d 00 	movdqa 0x6d78(%rip),%xmm0        # baf0 <msg.8+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f b9 01 00 	lea    0x1b99f(%rip),%rax        # 20720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 a1 6d 00 	movdqa 0x6da1(%rip),%xmm2        # bb30 <msg.8+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 b9 01 00 	movaps %xmm0,0x1b945(%rip)        # 206e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 5d 6d 00 	movdqa 0x6d5d(%rip),%xmm0        # bb00 <msg.8+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 bd 01 00 01 	movl   $0x1,0x1bdd3(%rip)        # 20b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 b9 01 00 	movaps %xmm0,0x1b933(%rip)        # 206f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 4b 6d 00 	movdqa 0x6d4b(%rip),%xmm0        # bb10 <msg.8+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 b9 01 00 	movaps %xmm0,0x1b934(%rip)        # 20700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 4c 6d 00 	movdqa 0x6d4c(%rip),%xmm0        # bb20 <msg.8+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 b9 01 00 	movaps %xmm0,0x1b935(%rip)        # 20710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 a9 01 00 	lea    0x1a9b5(%rip),%r8        # 1f7e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 bc 01 00 	mov    %rax,0x1bcd0(%rip)        # 20b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae bc 01 00 	mov    %r12,0x1bcae(%rip)        # 20ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 bc 01 00 	mov    %rax,0x1bc97(%rip)        # 20b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 bc 01 00 	mov    %rbx,0x1bcb0(%rip)        # 20bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 bc 01 00 	mov    %rsi,0x1bcd9(%rip)        # 20be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 61 00 00 	lea    0x61f9(%rip),%rdi        # b112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 bc 01 00 	mov    %rax,0x1bcb8(%rip)        # 20bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c bc 01 00    	mov    %eax,0x1bc3c(%rip)        # 20b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <caf75>:
    4f60:	8b 15 12 a1 00 00    	mov    0xa112(%rip),%edx        # f078 <st.4>
    4f66:	85 d2                	test   %edx,%edx
    4f68:	74 0e                	je     4f78 <caf75+0x18>
    4f6a:	48 8b 05 ff a0 00 00 	mov    0xa0ff(%rip),%rax        # f070 <v.3>
    4f71:	c3                   	ret
    4f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f78:	8b 05 ea a0 00 00    	mov    0xa0ea(%rip),%eax        # f068 <st.2>
    4f7e:	85 c0                	test   %eax,%eax
    4f80:	74 1e                	je     4fa0 <caf75+0x40>
    4f82:	48 8b 05 d7 a0 00 00 	mov    0xa0d7(%rip),%rax        # f060 <v.1>
    4f89:	48 89 05 e0 a0 00 00 	mov    %rax,0xa0e0(%rip)        # f070 <v.3>
    4f90:	c7 05 de a0 00 00 01 	movl   $0x1,0xa0de(%rip)        # f078 <st.4>
    4f97:	00 00 00 
    4f9a:	c3                   	ret
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fa7:	00 f0 3f 
    4faa:	c7 05 b4 a0 00 00 01 	movl   $0x1,0xa0b4(%rip)        # f068 <st.2>
    4fb1:	00 00 00 
    4fb4:	48 89 05 a5 a0 00 00 	mov    %rax,0xa0a5(%rip)        # f060 <v.1>
    4fbb:	eb cc                	jmp    4f89 <caf75+0x29>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 cc a7 01 00 	mov    0x1a7cc(%rip),%r8        # 1f7a0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d fc a6 01 00 	mov    %rbx,0x1a6fc(%rip)        # 1f7a8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 e8 a6 01 00 	mov    %r8,0x1a6e8(%rip)        # 1f7a0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <fwp_tape_buffers_release>:
    50d0:	f3 0f 1e fa          	endbr64
    50d4:	53                   	push   %rbx
    50d5:	48 89 fb             	mov    %rdi,%rbx
    50d8:	48 83 ec 10          	sub    $0x10,%rsp
    50dc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    50e0:	48 85 c0             	test   %rax,%rax
    50e3:	0f 88 df 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50e9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    50ed:	48 85 d2             	test   %rdx,%rdx
    50f0:	0f 88 d2 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50f6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    50fc:	0f 87 c6 00 00 00    	ja     51c8 <fwp_tape_buffers_release+0xf8>
    5102:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5106:	b8 00 00 08 00       	mov    $0x80000,%eax
    510b:	48 c1 e1 03          	shl    $0x3,%rcx
    510f:	48 29 c8             	sub    %rcx,%rax
    5112:	48 c1 e8 03          	shr    $0x3,%rax
    5116:	48 39 d0             	cmp    %rdx,%rax
    5119:	0f 82 a9 00 00 00    	jb     51c8 <fwp_tape_buffers_release+0xf8>
    511f:	48 8d 3d fc 5f 00 00 	lea    0x5ffc(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    5126:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    512b:	48 89 14 24          	mov    %rdx,(%rsp)
    512f:	e8 6c e2 ff ff       	call   33a0 <getenv@plt>
    5134:	48 8b 14 24          	mov    (%rsp),%rdx
    5138:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    513d:	48 85 c0             	test   %rax,%rax
    5140:	74 09                	je     514b <fwp_tape_buffers_release+0x7b>
    5142:	80 38 30             	cmpb   $0x30,(%rax)
    5145:	0f 84 9d 00 00 00    	je     51e8 <fwp_tape_buffers_release+0x118>
    514b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    514f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    5153:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    515a:	77 78                	ja     51d4 <fwp_tape_buffers_release+0x104>
    515c:	48 8d 3d 5d 9f 01 00 	lea    0x19f5d(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    5163:	48 89 04 24          	mov    %rax,(%rsp)
    5167:	e8 a4 ef ff ff       	call   4110 <fwp_tape_buffers_dispose>
    516c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5170:	48 8b 04 24          	mov    (%rsp),%rax
    5174:	0f 29 05 45 9f 01 00 	movaps %xmm0,0x19f45(%rip)        # 1f0c0 <fwp_tape_workspace>
    517b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5180:	48 89 05 21 9f 01 00 	mov    %rax,0x19f21(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    5187:	0f 29 05 42 9f 01 00 	movaps %xmm0,0x19f42(%rip)        # 1f0d0 <fwp_tape_workspace+0x10>
    518e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5193:	0f 29 05 46 9f 01 00 	movaps %xmm0,0x19f46(%rip)        # 1f0e0 <fwp_tape_workspace+0x20>
    519a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    519e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51a2:	48 89 15 47 9f 01 00 	mov    %rdx,0x19f47(%rip)        # 1f0f0 <fwp_tape_workspace+0x30>
    51a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b0:	00 
    51b1:	0f 11 03             	movups %xmm0,(%rbx)
    51b4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51b8:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51bc:	48 83 c4 10          	add    $0x10,%rsp
    51c0:	5b                   	pop    %rbx
    51c1:	c3                   	ret
    51c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51c8:	48 8d 3d 53 5f 00 00 	lea    0x5f53(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    51cf:	e8 cc e1 ff ff       	call   33a0 <getenv@plt>
    51d4:	48 83 c4 10          	add    $0x10,%rsp
    51d8:	48 89 df             	mov    %rbx,%rdi
    51db:	5b                   	pop    %rbx
    51dc:	e9 2f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    51ec:	0f 85 59 ff ff ff    	jne    514b <fwp_tape_buffers_release+0x7b>
    51f2:	48 83 c4 10          	add    $0x10,%rsp
    51f6:	48 89 df             	mov    %rbx,%rdi
    51f9:	5b                   	pop    %rbx
    51fa:	e9 11 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51ff:	90                   	nop

0000000000005200 <fwp_poll_events>:
    5200:	53                   	push   %rbx
    5201:	48 83 ec 20          	sub    $0x20,%rsp
    5205:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    520c:	00 00 
    520e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5213:	31 c0                	xor    %eax,%eax
    5215:	e8 46 f3 ff ff       	call   4560 <fwp_now_ns>
    521a:	48 8b 1d 77 a5 01 00 	mov    0x1a577(%rip),%rbx        # 1f798 <fwp_timers>
    5221:	48 85 db             	test   %rbx,%rbx
    5224:	0f 84 d6 00 00 00    	je     5300 <fwp_poll_events+0x100>
    522a:	48 89 c6             	mov    %rax,%rsi
    522d:	48 89 da             	mov    %rbx,%rdx
    5230:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5237:	eb 16                	jmp    524f <fwp_poll_events+0x4f>
    5239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5240:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5247:	48 89 c8             	mov    %rcx,%rax
    524a:	48 85 d2             	test   %rdx,%rdx
    524d:	74 31                	je     5280 <fwp_poll_events+0x80>
    524f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5253:	48 85 c0             	test   %rax,%rax
    5256:	78 e8                	js     5240 <fwp_poll_events+0x40>
    5258:	48 39 c1             	cmp    %rax,%rcx
    525b:	7c e3                	jl     5240 <fwp_poll_events+0x40>
    525d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5264:	48 85 d2             	test   %rdx,%rdx
    5267:	74 1c                	je     5285 <fwp_poll_events+0x85>
    5269:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    526d:	48 39 c1             	cmp    %rax,%rcx
    5270:	7c ce                	jl     5240 <fwp_poll_events+0x40>
    5272:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5279:	48 85 d2             	test   %rdx,%rdx
    527c:	75 d1                	jne    524f <fwp_poll_events+0x4f>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 85 c0             	test   %rax,%rax
    5283:	78 7b                	js     5300 <fwp_poll_events+0x100>
    5285:	48 29 f0             	sub    %rsi,%rax
    5288:	48 89 c1             	mov    %rax,%rcx
    528b:	48 85 c0             	test   %rax,%rax
    528e:	0f 8e 9c 00 00 00    	jle    5330 <fwp_poll_events+0x130>
    5294:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    529b:	de 1b 43 
    529e:	48 f7 ea             	imul   %rdx
    52a1:	48 89 c8             	mov    %rcx,%rax
    52a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    52a8:	48 c1 fa 12          	sar    $0x12,%rdx
    52ac:	48 29 c2             	sub    %rax,%rdx
    52af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    52b6:	48 39 c1             	cmp    %rax,%rcx
    52b9:	0f 95 c0             	setne  %al
    52bc:	0f b6 c0             	movzbl %al,%eax
    52bf:	48 01 d0             	add    %rdx,%rax
    52c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    52c8:	0f 8f 32 01 00 00    	jg     5400 <fwp_poll_events+0x200>
    52ce:	48 85 c0             	test   %rax,%rax
    52d1:	74 5d                	je     5330 <fwp_poll_events+0x130>
    52d3:	89 c1                	mov    %eax,%ecx
    52d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    52dc:	48 c1 e9 26          	shr    $0x26,%rcx
    52e0:	48 63 d1             	movslq %ecx,%rdx
    52e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    52e9:	29 c8                	sub    %ecx,%eax
    52eb:	48 98                	cltq
    52ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    52f4:	e9 11 01 00 00       	jmp    540a <fwp_poll_events+0x20a>
    52f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5300:	e8 6b e9 ff ff       	call   3c70 <fwp_flush>
    5305:	ba 2b 00 00 00       	mov    $0x2b,%edx
    530a:	be 01 00 00 00       	mov    $0x1,%esi
    530f:	48 8b 0d 2a 9d 00 00 	mov    0x9d2a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5316:	48 8d 3d f3 64 00 00 	lea    0x64f3(%rip),%rdi        # b810 <_IO_stdin_used+0x810>
    531d:	e8 5e e3 ff ff       	call   3680 <fwrite@plt>
    5322:	bf 65 00 00 00       	mov    $0x65,%edi
    5327:	e8 44 e3 ff ff       	call   3670 <exit@plt>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	e8 2b f2 ff ff       	call   4560 <fwp_now_ns>
    5335:	48 89 c1             	mov    %rax,%rcx
    5338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    533c:	eb 44                	jmp    5382 <fwp_poll_events+0x182>
    533e:	66 90                	xchg   %ax,%ax
    5340:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5344:	75 33                	jne    5379 <fwp_poll_events+0x179>
    5346:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534a:	75 2d                	jne    5379 <fwp_poll_events+0x179>
    534c:	48 8b 05 4d a4 01 00 	mov    0x1a44d(%rip),%rax        # 1f7a0 <fwp_ready_tail>
    5353:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5357:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    535e:	00 00 00 00 
    5362:	48 85 c0             	test   %rax,%rax
    5365:	0f 84 05 01 00 00    	je     5470 <fwp_poll_events+0x270>
    536b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5372:	48 89 15 27 a4 01 00 	mov    %rdx,0x1a427(%rip)        # 1f7a0 <fwp_ready_tail>
    5379:	48 85 db             	test   %rbx,%rbx
    537c:	0f 84 be 00 00 00    	je     5440 <fwp_poll_events+0x240>
    5382:	48 89 da             	mov    %rbx,%rdx
    5385:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    538c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5390:	7f e7                	jg     5379 <fwp_poll_events+0x179>
    5392:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5396:	74 2e                	je     53c6 <fwp_poll_events+0x1c6>
    5398:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    539f:	48 85 c0             	test   %rax,%rax
    53a2:	0f 84 b8 00 00 00    	je     5460 <fwp_poll_events+0x260>
    53a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    53af:	48 85 db             	test   %rbx,%rbx
    53b2:	74 07                	je     53bb <fwp_poll_events+0x1bb>
    53b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    53bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    53bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    53c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    53ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    53ce:	48 85 c0             	test   %rax,%rax
    53d1:	0f 84 69 ff ff ff    	je     5340 <fwp_poll_events+0x140>
    53d7:	48 39 c8             	cmp    %rcx,%rax
    53da:	0f 8f 60 ff ff ff    	jg     5340 <fwp_poll_events+0x140>
    53e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    53e4:	0f 85 56 ff ff ff    	jne    5340 <fwp_poll_events+0x140>
    53ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    53ee:	75 89                	jne    5379 <fwp_poll_events+0x179>
    53f0:	48 89 d7             	mov    %rdx,%rdi
    53f3:	e8 08 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    53f8:	e9 43 ff ff ff       	jmp    5340 <fwp_poll_events+0x140>
    53fd:	0f 1f 00             	nopl   (%rax)
    5400:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5405:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    540a:	48 89 e7             	mov    %rsp,%rdi
    540d:	31 f6                	xor    %esi,%esi
    540f:	48 89 14 24          	mov    %rdx,(%rsp)
    5413:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5418:	e8 83 e0 ff ff       	call   34a0 <nanosleep@plt>
    541d:	48 8b 1d 74 a3 01 00 	mov    0x1a374(%rip),%rbx        # 1f798 <fwp_timers>
    5424:	e8 37 f1 ff ff       	call   4560 <fwp_now_ns>
    5429:	48 89 c1             	mov    %rax,%rcx
    542c:	48 85 db             	test   %rbx,%rbx
    542f:	0f 85 03 ff ff ff    	jne    5338 <fwp_poll_events+0x138>
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5445:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    544c:	00 00 
    544e:	75 2c                	jne    547c <fwp_poll_events+0x27c>
    5450:	48 83 c4 20          	add    $0x20,%rsp
    5454:	5b                   	pop    %rbx
    5455:	c3                   	ret
    5456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    545d:	00 00 00 
    5460:	48 89 1d 31 a3 01 00 	mov    %rbx,0x1a331(%rip)        # 1f798 <fwp_timers>
    5467:	e9 43 ff ff ff       	jmp    53af <fwp_poll_events+0x1af>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	48 89 15 31 a3 01 00 	mov    %rdx,0x1a331(%rip)        # 1f7a8 <fwp_ready_head>
    5477:	e9 f6 fe ff ff       	jmp    5372 <fwp_poll_events+0x172>
    547c:	e8 df df ff ff       	call   3460 <__stack_chk_fail@plt>
    5481:	0f 1f 40 00          	nopl   0x0(%rax)
    5485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    548c:	00 00 00 00 

0000000000005490 <fwp_rc_wide_dup>:
    5490:	48 89 fa             	mov    %rdi,%rdx
    5493:	48 8d 35 46 a3 01 00 	lea    0x1a346(%rip),%rsi        # 1f7e0 <fwp_heap>
    549a:	48 83 ec 18          	sub    $0x18,%rsp
    549e:	48 89 f9             	mov    %rdi,%rcx
    54a1:	48 c1 ea 11          	shr    $0x11,%rdx
    54a5:	48 31 fa             	xor    %rdi,%rdx
    54a8:	48 89 d0             	mov    %rdx,%rax
    54ab:	48 c1 e8 09          	shr    $0x9,%rax
    54af:	48 31 c2             	xor    %rax,%rdx
    54b2:	0f b6 d2             	movzbl %dl,%edx
    54b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    54bc:	00 
    54bd:	49 8b 00             	mov    (%r8),%rax
    54c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    54c7:	00 00 
    54c9:	75 21                	jne    54ec <fwp_rc_wide_dup+0x5c>
    54cb:	e9 98 00 00 00       	jmp    5568 <fwp_rc_wide_dup+0xd8>
    54d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    54d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54dc:	00 00 00 00 
    54e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 2f                	je     5518 <fwp_rc_wide_dup+0x88>
    54e9:	48 89 d0             	mov    %rdx,%rax
    54ec:	48 3b 08             	cmp    (%rax),%rcx
    54ef:	75 ef                	jne    54e0 <fwp_rc_wide_dup+0x50>
    54f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54f4:	74 7c                	je     5572 <fwp_rc_wide_dup+0xe2>
    54f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    54fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    54fe:	0f 84 91 00 00 00    	je     5595 <fwp_rc_wide_dup+0x105>
    5504:	48 83 c2 01          	add    $0x1,%rdx
    5508:	48 89 50 08          	mov    %rdx,0x8(%rax)
    550c:	48 83 c4 18          	add    $0x18,%rsp
    5510:	c3                   	ret
    5511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5518:	4c 8d 40 10          	lea    0x10(%rax),%r8
    551c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    551f:	75 68                	jne    5589 <fwp_rc_wide_dup+0xf9>
    5521:	bf 18 00 00 00       	mov    $0x18,%edi
    5526:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    552b:	4c 89 04 24          	mov    %r8,(%rsp)
    552f:	e8 7c e0 ff ff       	call   35b0 <malloc@plt>
    5534:	4c 8b 04 24          	mov    (%rsp),%r8
    5538:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    553d:	48 85 c0             	test   %rax,%rax
    5540:	74 5f                	je     55a1 <fwp_rc_wide_dup+0x111>
    5542:	48 89 08             	mov    %rcx,(%rax)
    5545:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    554c:	00 
    554d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5554:	00 
    5555:	49 89 00             	mov    %rax,(%r8)
    5558:	c6 01 ff             	movb   $0xff,(%rcx)
    555b:	48 83 05 c5 be 01 00 	addq   $0x1,0x1bec5(%rip)        # 21428 <fwp_heap+0x1c48>
    5562:	01 
    5563:	48 83 c4 18          	add    $0x18,%rsp
    5567:	c3                   	ret
    5568:	80 3f fe             	cmpb   $0xfe,(%rdi)
    556b:	75 13                	jne    5580 <fwp_rc_wide_dup+0xf0>
    556d:	48 85 c0             	test   %rax,%rax
    5570:	74 af                	je     5521 <fwp_rc_wide_dup+0x91>
    5572:	48 8d 3d c7 62 00 00 	lea    0x62c7(%rip),%rdi        # b840 <_IO_stdin_used+0x840>
    5579:	e8 72 ee ff ff       	call   43f0 <fwp_trap>
    557e:	66 90                	xchg   %ax,%ax
    5580:	48 85 c0             	test   %rax,%rax
    5583:	0f 85 6d ff ff ff    	jne    54f6 <fwp_rc_wide_dup+0x66>
    5589:	48 8d 3d d8 62 00 00 	lea    0x62d8(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    5590:	e8 5b ee ff ff       	call   43f0 <fwp_trap>
    5595:	48 8d 3d 97 5b 00 00 	lea    0x5b97(%rip),%rdi        # b133 <_IO_stdin_used+0x133>
    559c:	e8 4f ee ff ff       	call   43f0 <fwp_trap>
    55a1:	e8 0a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    55a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ad:	00 00 00 

00000000000055b0 <fwp_rc_forget_slot>:
    55b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    55b3:	74 0b                	je     55c0 <fwp_rc_forget_slot+0x10>
    55b5:	c3                   	ret
    55b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55bd:	00 00 00 
    55c0:	48 89 f8             	mov    %rdi,%rax
    55c3:	48 83 ec 08          	sub    $0x8,%rsp
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 c1 e8 11          	shr    $0x11,%rax
    55ce:	48 31 f8             	xor    %rdi,%rax
    55d1:	48 89 c1             	mov    %rax,%rcx
    55d4:	48 c1 e9 09          	shr    $0x9,%rcx
    55d8:	48 31 c8             	xor    %rcx,%rax
    55db:	48 8d 0d fe a1 01 00 	lea    0x1a1fe(%rip),%rcx        # 1f7e0 <fwp_heap>
    55e2:	0f b6 c0             	movzbl %al,%eax
    55e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    55ec:	00 
    55ed:	48 85 ff             	test   %rdi,%rdi
    55f0:	74 3c                	je     562e <fwp_rc_forget_slot+0x7e>
    55f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    55f9:	00 
    55fa:	48 8b 01             	mov    (%rcx),%rax
    55fd:	eb 11                	jmp    5610 <fwp_rc_forget_slot+0x60>
    55ff:	90                   	nop
    5600:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5604:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5608:	48 85 ff             	test   %rdi,%rdi
    560b:	74 21                	je     562e <fwp_rc_forget_slot+0x7e>
    560d:	48 89 f8             	mov    %rdi,%rax
    5610:	48 3b 10             	cmp    (%rax),%rdx
    5613:	75 eb                	jne    5600 <fwp_rc_forget_slot+0x50>
    5615:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5619:	48 89 01             	mov    %rax,(%rcx)
    561c:	e8 9f dd ff ff       	call   33c0 <free@plt>
    5621:	48 83 2d ff bd 01 00 	subq   $0x1,0x1bdff(%rip)        # 21428 <fwp_heap+0x1c48>
    5628:	01 
    5629:	48 83 c4 08          	add    $0x8,%rsp
    562d:	c3                   	ret
    562e:	48 8d 3d 33 62 00 00 	lea    0x6233(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    5635:	e8 b6 ed ff ff       	call   43f0 <fwp_trap>
    563a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005640 <fwp_rc_prepare_chunk>:
    5640:	48 83 3d e0 bd 01 00 	cmpq   $0x0,0x1bde0(%rip)        # 21428 <fwp_heap+0x1c48>
    5647:	00 
    5648:	41 54                	push   %r12
    564a:	49 89 f4             	mov    %rsi,%r12
    564d:	55                   	push   %rbp
    564e:	48 89 fd             	mov    %rdi,%rbp
    5651:	53                   	push   %rbx
    5652:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5655:	0f 84 7d 00 00 00    	je     56d8 <fwp_rc_prepare_chunk+0x98>
    565b:	31 db                	xor    %ebx,%ebx
    565d:	85 c0                	test   %eax,%eax
    565f:	75 5f                	jne    56c0 <fwp_rc_prepare_chunk+0x80>
    5661:	48 85 f6             	test   %rsi,%rsi
    5664:	74 7c                	je     56e2 <fwp_rc_prepare_chunk+0xa2>
    5666:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    566a:	e8 51 dd ff ff       	call   33c0 <free@plt>
    566f:	90                   	nop
    5670:	be 01 00 00 00       	mov    $0x1,%esi
    5675:	4c 89 e7             	mov    %r12,%rdi
    5678:	e8 a3 de ff ff       	call   3520 <calloc@plt>
    567d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5681:	48 85 c0             	test   %rax,%rax
    5684:	0f 85 87 00 00 00    	jne    5711 <fwp_rc_prepare_chunk+0xd1>
    568a:	e8 21 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    568f:	90                   	nop
    5690:	e8 1b ff ff ff       	call   55b0 <fwp_rc_forget_slot>
    5695:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5698:	48 83 c3 01          	add    $0x1,%rbx
    569c:	48 39 c3             	cmp    %rax,%rbx
    569f:	73 37                	jae    56d8 <fwp_rc_prepare_chunk+0x98>
    56a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56a8:	00 00 
    56aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56b1:	00 00 00 00 
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56c4:	48 01 df             	add    %rbx,%rdi
    56c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    56ca:	74 c4                	je     5690 <fwp_rc_prepare_chunk+0x50>
    56cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    56cf:	48 83 c3 01          	add    $0x1,%rbx
    56d3:	48 39 c3             	cmp    %rax,%rbx
    56d6:	72 e8                	jb     56c0 <fwp_rc_prepare_chunk+0x80>
    56d8:	49 39 c4             	cmp    %rax,%r12
    56db:	75 13                	jne    56f0 <fwp_rc_prepare_chunk+0xb0>
    56dd:	4d 85 e4             	test   %r12,%r12
    56e0:	75 46                	jne    5728 <fwp_rc_prepare_chunk+0xe8>
    56e2:	5b                   	pop    %rbx
    56e3:	5d                   	pop    %rbp
    56e4:	41 5c                	pop    %r12
    56e6:	c3                   	ret
    56e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56ee:	00 00 
    56f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56f4:	48 29 05 35 bd 01 00 	sub    %rax,0x1bd35(%rip)        # 21430 <fwp_heap+0x1c50>
    56fb:	e8 c0 dc ff ff       	call   33c0 <free@plt>
    5700:	4d 85 e4             	test   %r12,%r12
    5703:	0f 85 67 ff ff ff    	jne    5670 <fwp_rc_prepare_chunk+0x30>
    5709:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5710:	00 
    5711:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5715:	5b                   	pop    %rbx
    5716:	4c 01 25 13 bd 01 00 	add    %r12,0x1bd13(%rip)        # 21430 <fwp_heap+0x1c50>
    571d:	5d                   	pop    %rbp
    571e:	41 5c                	pop    %r12
    5720:	c3                   	ret
    5721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5728:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    572c:	5b                   	pop    %rbx
    572d:	4c 89 e2             	mov    %r12,%rdx
    5730:	31 f6                	xor    %esi,%esi
    5732:	5d                   	pop    %rbp
    5733:	41 5c                	pop    %r12
    5735:	e9 86 dd ff ff       	jmp    34c0 <memset@plt>
    573a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005740 <fwp_heap_refill>:
    5740:	41 56                	push   %r14
    5742:	41 89 d6             	mov    %edx,%r14d
    5745:	41 55                	push   %r13
    5747:	41 89 f5             	mov    %esi,%r13d
    574a:	41 54                	push   %r12
    574c:	49 89 fc             	mov    %rdi,%r12
    574f:	bf 01 00 00 00       	mov    $0x1,%edi
    5754:	55                   	push   %rbp
    5755:	53                   	push   %rbx
    5756:	e8 25 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    575b:	48 89 c3             	mov    %rax,%rbx
    575e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5762:	48 8b 05 6f b4 01 00 	mov    0x1b46f(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    5769:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    576d:	48 8d 05 6c a0 01 00 	lea    0x1a06c(%rip),%rax        # 1f7e0 <fwp_heap>
    5774:	31 d2                	xor    %edx,%edx
    5776:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    577a:	48 89 ef             	mov    %rbp,%rdi
    577d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5781:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5785:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    578c:	00 
    578d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5792:	f7 f1                	div    %ecx
    5794:	31 d2                	xor    %edx,%edx
    5796:	66 0f 6e c1          	movd   %ecx,%xmm0
    579a:	66 0f 6e c8          	movd   %eax,%xmm1
    579e:	89 c6                	mov    %eax,%esi
    57a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    57a5:	48 01 c8             	add    %rcx,%rax
    57a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    57ac:	48 f7 f1             	div    %rcx
    57af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    57b4:	89 45 18             	mov    %eax,0x18(%rbp)
    57b7:	e8 84 fe ff ff       	call   5640 <fwp_rc_prepare_chunk>
    57bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    57bf:	48 89 d8             	mov    %rbx,%rax
    57c2:	48 c1 e0 10          	shl    $0x10,%rax
    57c6:	48 03 05 c3 b3 01 00 	add    0x1b3c3(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    57cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    57d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    57d6:	8b 55 08             	mov    0x8(%rbp),%edx
    57d9:	48 0f af d1          	imul   %rcx,%rdx
    57dd:	48 01 c2             	add    %rax,%rdx
    57e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    57e5:	5b                   	pop    %rbx
    57e6:	5d                   	pop    %rbp
    57e7:	41 5c                	pop    %r12
    57e9:	41 5d                	pop    %r13
    57eb:	41 5e                	pop    %r14
    57ed:	c3                   	ret
    57ee:	66 90                	xchg   %ax,%ax

00000000000057f0 <fwp_mem_free>:
    57f0:	48 85 ff             	test   %rdi,%rdi
    57f3:	0f 84 17 02 00 00    	je     5a10 <fwp_mem_free+0x220>
    57f9:	48 8b 35 90 b3 01 00 	mov    0x1b390(%rip),%rsi        # 20b90 <fwp_heap+0x13b0>
    5800:	48 8b 05 b1 b3 01 00 	mov    0x1b3b1(%rip),%rax        # 20bb8 <fwp_heap+0x13d8>
    5807:	48 89 fa             	mov    %rdi,%rdx
    580a:	48 29 f2             	sub    %rsi,%rdx
    580d:	48 c1 e0 10          	shl    $0x10,%rax
    5811:	48 39 c2             	cmp    %rax,%rdx
    5814:	0f 83 f6 01 00 00    	jae    5a10 <fwp_mem_free+0x220>
    581a:	49 89 d1             	mov    %rdx,%r9
    581d:	49 c1 e9 10          	shr    $0x10,%r9
    5821:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5825:	48 c1 e0 03          	shl    $0x3,%rax
    5829:	49 89 c0             	mov    %rax,%r8
    582c:	4c 03 05 a5 b3 01 00 	add    0x1b3a5(%rip),%r8        # 20bd8 <fwp_heap+0x13f8>
    5833:	0f 84 d7 01 00 00    	je     5a10 <fwp_mem_free+0x220>
    5839:	48 83 ec 38          	sub    $0x38,%rsp
    583d:	48 89 f9             	mov    %rdi,%rcx
    5840:	41 0f b6 38          	movzbl (%r8),%edi
    5844:	40 80 ff 01          	cmp    $0x1,%dil
    5848:	74 16                	je     5860 <fwp_mem_free+0x70>
    584a:	40 80 ff 02          	cmp    $0x2,%dil
    584e:	0f 84 94 00 00 00    	je     58e8 <fwp_mem_free+0xf8>
    5854:	48 83 c4 38          	add    $0x38,%rsp
    5858:	c3                   	ret
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5864:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5869:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    586e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5872:	4d 85 d2             	test   %r10,%r10
    5875:	74 1d                	je     5894 <fwp_mem_free+0xa4>
    5877:	0f b7 c1             	movzwl %cx,%eax
    587a:	31 d2                	xor    %edx,%edx
    587c:	48 f7 f7             	div    %rdi
    587f:	49 01 c2             	add    %rax,%r10
    5882:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5886:	0f 84 44 01 00 00    	je     59d0 <fwp_mem_free+0x1e0>
    588c:	41 c6 02 00          	movb   $0x0,(%r10)
    5890:	41 8b 78 04          	mov    0x4(%r8),%edi
    5894:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    589b:	49 63 c1             	movslq %r9d,%rax
    589e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    58a6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    58ab:	f2 0f 58 05 6d b3 01 	addsd  0x1b36d(%rip),%xmm0        # 20c20 <fwp_heap+0x1440>
    58b2:	00 
    58b3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    58b7:	48 8d 05 22 9f 01 00 	lea    0x19f22(%rip),%rax        # 1f7e0 <fwp_heap>
    58be:	48 01 d0             	add    %rdx,%rax
    58c1:	48 8b 10             	mov    (%rax),%rdx
    58c4:	48 f7 d2             	not    %rdx
    58c7:	48 89 11             	mov    %rdx,(%rcx)
    58ca:	48 89 08             	mov    %rcx,(%rax)
    58cd:	48 29 3d 2c b3 01 00 	sub    %rdi,0x1b32c(%rip)        # 20c00 <fwp_heap+0x1420>
    58d4:	f2 0f 11 05 44 b3 01 	movsd  %xmm0,0x1b344(%rip)        # 20c20 <fwp_heap+0x1440>
    58db:	00 
    58dc:	48 83 c4 38          	add    $0x38,%rsp
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	66 31 d2             	xor    %dx,%dx
    58eb:	48 01 d6             	add    %rdx,%rsi
    58ee:	48 39 f1             	cmp    %rsi,%rcx
    58f1:	0f 85 5d ff ff ff    	jne    5854 <fwp_mem_free+0x64>
    58f7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    58fb:	48 29 15 fe b2 01 00 	sub    %rdx,0x1b2fe(%rip)        # 20c00 <fwp_heap+0x1420>
    5902:	48 85 d2             	test   %rdx,%rdx
    5905:	0f 88 a5 00 00 00    	js     59b0 <fwp_mem_free+0x1c0>
    590b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    590f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5914:	f2 0f 58 05 04 b3 01 	addsd  0x1b304(%rip),%xmm0        # 20c20 <fwp_heap+0x1440>
    591b:	00 
    591c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5920:	f2 0f 11 05 f8 b2 01 	movsd  %xmm0,0x1b2f8(%rip)        # 20c20 <fwp_heap+0x1440>
    5927:	00 
    5928:	48 85 d2             	test   %rdx,%rdx
    592b:	74 0c                	je     5939 <fwp_mem_free+0x149>
    592d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5930:	0f 84 db 00 00 00    	je     5a11 <fwp_mem_free+0x221>
    5936:	c6 02 00             	movb   $0x0,(%rdx)
    5939:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    593d:	48 85 c9             	test   %rcx,%rcx
    5940:	74 3e                	je     5980 <fwp_mem_free+0x190>
    5942:	48 8b 15 8f b2 01 00 	mov    0x1b28f(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    5949:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    594d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5951:	48 01 d0             	add    %rdx,%rax
    5954:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5958:	48 89 d6             	mov    %rdx,%rsi
    595b:	48 29 c6             	sub    %rax,%rsi
    595e:	83 e6 08             	and    $0x8,%esi
    5961:	74 0d                	je     5970 <fwp_mem_free+0x180>
    5963:	c6 00 00             	movb   $0x0,(%rax)
    5966:	48 83 c0 28          	add    $0x28,%rax
    596a:	48 39 c2             	cmp    %rax,%rdx
    596d:	74 11                	je     5980 <fwp_mem_free+0x190>
    596f:	90                   	nop
    5970:	c6 00 00             	movb   $0x0,(%rax)
    5973:	48 83 c0 50          	add    $0x50,%rax
    5977:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    597b:	48 39 c2             	cmp    %rax,%rdx
    597e:	75 f0                	jne    5970 <fwp_mem_free+0x180>
    5980:	48 01 0d 89 b2 01 00 	add    %rcx,0x1b289(%rip)        # 20c10 <fwp_heap+0x1430>
    5987:	4c 3b 0d 42 b2 01 00 	cmp    0x1b242(%rip),%r9        # 20bd0 <fwp_heap+0x13f0>
    598e:	73 07                	jae    5997 <fwp_mem_free+0x1a7>
    5990:	4c 89 0d 39 b2 01 00 	mov    %r9,0x1b239(%rip)        # 20bd0 <fwp_heap+0x13f0>
    5997:	4c 3b 0d 2a b2 01 00 	cmp    0x1b22a(%rip),%r9        # 20bc8 <fwp_heap+0x13e8>
    599e:	0f 83 b0 fe ff ff    	jae    5854 <fwp_mem_free+0x64>
    59a4:	4c 89 0d 1d b2 01 00 	mov    %r9,0x1b21d(%rip)        # 20bc8 <fwp_heap+0x13e8>
    59ab:	e9 a4 fe ff ff       	jmp    5854 <fwp_mem_free+0x64>
    59b0:	48 89 d1             	mov    %rdx,%rcx
    59b3:	83 e2 01             	and    $0x1,%edx
    59b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59ba:	48 d1 e9             	shr    $1,%rcx
    59bd:	48 09 d1             	or     %rdx,%rcx
    59c0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    59c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    59c9:	e9 46 ff ff ff       	jmp    5914 <fwp_mem_free+0x124>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	4c 89 d7             	mov    %r10,%rdi
    59d3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    59d8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    59dd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    59e2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    59e6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    59eb:	e8 c0 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    59f0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    59f5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    59fa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    59ff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5a04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5a09:	e9 7e fe ff ff       	jmp    588c <fwp_mem_free+0x9c>
    5a0e:	66 90                	xchg   %ax,%ax
    5a10:	c3                   	ret
    5a11:	48 89 d7             	mov    %rdx,%rdi
    5a14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5a19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5a1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5a23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5a28:	e8 83 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    5a2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5a32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5a37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5a3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5a41:	e9 f0 fe ff ff       	jmp    5936 <fwp_mem_free+0x146>
    5a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5a4d:	00 00 00 

0000000000005a50 <fwp_heap_alloc_big>:
    5a50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5a57:	00 00 40 
    5a5a:	41 57                	push   %r15
    5a5c:	41 56                	push   %r14
    5a5e:	41 55                	push   %r13
    5a60:	41 54                	push   %r12
    5a62:	55                   	push   %rbp
    5a63:	53                   	push   %rbx
    5a64:	48 83 ec 08          	sub    $0x8,%rsp
    5a68:	48 39 f8             	cmp    %rdi,%rax
    5a6b:	0f 82 fa 00 00 00    	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5a71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a78:	49 89 fd             	mov    %rdi,%r13
    5a7b:	41 89 f6             	mov    %esi,%r14d
    5a7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a82:	48 89 ef             	mov    %rbp,%rdi
    5a85:	e8 f6 e4 ff ff       	call   3f80 <fwp_heap_chunks>
    5a8a:	be 01 00 00 00       	mov    $0x1,%esi
    5a8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a93:	49 89 c4             	mov    %rax,%r12
    5a96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a9d:	00 
    5a9e:	48 03 3d 33 b1 01 00 	add    0x1b133(%rip),%rdi        # 20bd8 <fwp_heap+0x13f8>
    5aa5:	c6 07 02             	movb   $0x2,(%rdi)
    5aa8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5aac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5aaf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5ab3:	e8 88 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5ab8:	48 83 fd 01          	cmp    $0x1,%rbp
    5abc:	76 47                	jbe    5b05 <fwp_heap_alloc_big+0xb5>
    5abe:	4c 01 e5             	add    %r12,%rbp
    5ac1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ac8:	00 
    5ac9:	4c 8d 3d 10 9d 01 00 	lea    0x19d10(%rip),%r15        # 1f7e0 <fwp_heap>
    5ad0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5ad5:	49 c1 e6 03          	shl    $0x3,%r14
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ae7:	31 f6                	xor    %esi,%esi
    5ae9:	48 01 dd             	add    %rbx,%rbp
    5aec:	48 83 c3 28          	add    $0x28,%rbx
    5af0:	48 89 ef             	mov    %rbp,%rdi
    5af3:	e8 48 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5af8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5afc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5b00:	49 39 de             	cmp    %rbx,%r14
    5b03:	75 db                	jne    5ae0 <fwp_heap_alloc_big+0x90>
    5b05:	49 c1 e4 10          	shl    $0x10,%r12
    5b09:	4c 03 25 80 b0 01 00 	add    0x1b080(%rip),%r12        # 20b90 <fwp_heap+0x13b0>
    5b10:	4c 89 ea             	mov    %r13,%rdx
    5b13:	31 f6                	xor    %esi,%esi
    5b15:	4c 89 e7             	mov    %r12,%rdi
    5b18:	e8 a3 d9 ff ff       	call   34c0 <memset@plt>
    5b1d:	4c 89 e8             	mov    %r13,%rax
    5b20:	48 03 05 d9 b0 01 00 	add    0x1b0d9(%rip),%rax        # 20c00 <fwp_heap+0x1420>
    5b27:	72 42                	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5b29:	48 39 05 d8 b0 01 00 	cmp    %rax,0x1b0d8(%rip)        # 20c08 <fwp_heap+0x1428>
    5b30:	48 89 05 c9 b0 01 00 	mov    %rax,0x1b0c9(%rip)        # 20c00 <fwp_heap+0x1420>
    5b37:	73 07                	jae    5b40 <fwp_heap_alloc_big+0xf0>
    5b39:	48 89 05 c8 b0 01 00 	mov    %rax,0x1b0c8(%rip)        # 20c08 <fwp_heap+0x1428>
    5b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b44:	4c 89 e0             	mov    %r12,%rax
    5b47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5b4c:	f2 0f 58 05 c4 b0 01 	addsd  0x1b0c4(%rip),%xmm0        # 20c18 <fwp_heap+0x1438>
    5b53:	00 
    5b54:	f2 0f 11 05 bc b0 01 	movsd  %xmm0,0x1b0bc(%rip)        # 20c18 <fwp_heap+0x1438>
    5b5b:	00 
    5b5c:	48 83 c4 08          	add    $0x8,%rsp
    5b60:	5b                   	pop    %rbx
    5b61:	5d                   	pop    %rbp
    5b62:	41 5c                	pop    %r12
    5b64:	41 5d                	pop    %r13
    5b66:	41 5e                	pop    %r14
    5b68:	41 5f                	pop    %r15
    5b6a:	c3                   	ret
    5b6b:	e8 40 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b70 <fwp_heap_alloc_slow>:
    5b70:	53                   	push   %rbx
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	41 89 f1             	mov    %esi,%r9d
    5b77:	48 83 ec 10          	sub    $0x10,%rsp
    5b7b:	8b 05 03 b0 01 00    	mov    0x1b003(%rip),%eax        # 20b84 <fwp_heap+0x13a4>
    5b81:	85 c0                	test   %eax,%eax
    5b83:	0f 84 c7 00 00 00    	je     5c50 <fwp_heap_alloc_slow+0xe0>
    5b89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b90:	0f 87 dd 00 00 00    	ja     5c73 <fwp_heap_alloc_slow+0x103>
    5b96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b9a:	48 8d 3d 3f 9c 01 00 	lea    0x19c3f(%rip),%rdi        # 1f7e0 <fwp_heap>
    5ba1:	49 63 f1             	movslq %r9d,%rsi
    5ba4:	48 c1 e8 04          	shr    $0x4,%rax
    5ba8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5baf:	00 00 
    5bb1:	41 0f b6 c2          	movzbl %r10b,%eax
    5bb5:	4c 89 d2             	mov    %r10,%rdx
    5bb8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5bbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5bc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5bca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5bce:	48 01 f8             	add    %rdi,%rax
    5bd1:	4c 8b 00             	mov    (%rax),%r8
    5bd4:	4d 85 c0             	test   %r8,%r8
    5bd7:	0f 84 ab 00 00 00    	je     5c88 <fwp_heap_alloc_slow+0x118>
    5bdd:	49 8b 10             	mov    (%r8),%rdx
    5be0:	48 f7 d2             	not    %rdx
    5be3:	48 89 10             	mov    %rdx,(%rax)
    5be6:	41 83 f9 01          	cmp    $0x1,%r9d
    5bea:	4c 89 c7             	mov    %r8,%rdi
    5bed:	48 0f 45 cb          	cmovne %rbx,%rcx
    5bf1:	31 f6                	xor    %esi,%esi
    5bf3:	48 89 ca             	mov    %rcx,%rdx
    5bf6:	e8 c5 d8 ff ff       	call   34c0 <memset@plt>
    5bfb:	49 89 c0             	mov    %rax,%r8
    5bfe:	48 89 d8             	mov    %rbx,%rax
    5c01:	48 03 05 f8 af 01 00 	add    0x1aff8(%rip),%rax        # 20c00 <fwp_heap+0x1420>
    5c08:	0f 82 d9 00 00 00    	jb     5ce7 <fwp_heap_alloc_slow+0x177>
    5c0e:	48 39 05 f3 af 01 00 	cmp    %rax,0x1aff3(%rip)        # 20c08 <fwp_heap+0x1428>
    5c15:	48 89 05 e4 af 01 00 	mov    %rax,0x1afe4(%rip)        # 20c00 <fwp_heap+0x1420>
    5c1c:	73 07                	jae    5c25 <fwp_heap_alloc_slow+0xb5>
    5c1e:	48 89 05 e3 af 01 00 	mov    %rax,0x1afe3(%rip)        # 20c08 <fwp_heap+0x1428>
    5c25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c29:	4c 89 c0             	mov    %r8,%rax
    5c2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5c31:	f2 0f 58 05 df af 01 	addsd  0x1afdf(%rip),%xmm0        # 20c18 <fwp_heap+0x1438>
    5c38:	00 
    5c39:	f2 0f 11 05 d7 af 01 	movsd  %xmm0,0x1afd7(%rip)        # 20c18 <fwp_heap+0x1438>
    5c40:	00 
    5c41:	48 83 c4 10          	add    $0x10,%rsp
    5c45:	5b                   	pop    %rbx
    5c46:	c3                   	ret
    5c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c4e:	00 00 
    5c50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5c54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5c58:	e8 13 f1 ff ff       	call   4d70 <fwp_heap_init>
    5c5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c6d:	0f 86 23 ff ff ff    	jbe    5b96 <fwp_heap_alloc_slow+0x26>
    5c73:	48 83 c4 10          	add    $0x10,%rsp
    5c77:	44 89 ce             	mov    %r9d,%esi
    5c7a:	48 89 cf             	mov    %rcx,%rdi
    5c7d:	5b                   	pop    %rbx
    5c7e:	e9 cd fd ff ff       	jmp    5a50 <fwp_heap_alloc_big>
    5c83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c8c:	4d 85 c0             	test   %r8,%r8
    5c8f:	74 1f                	je     5cb0 <fwp_heap_alloc_slow+0x140>
    5c91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c95:	4d 29 c3             	sub    %r8,%r11
    5c98:	49 39 db             	cmp    %rbx,%r11
    5c9b:	72 13                	jb     5cb0 <fwp_heap_alloc_slow+0x140>
    5c9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ca1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ca5:	e9 3c ff ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5cb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5cb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5cbb:	44 89 ca             	mov    %r9d,%edx
    5cbe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5cc3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5cc7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ccb:	44 89 d6             	mov    %r10d,%esi
    5cce:	48 01 c7             	add    %rax,%rdi
    5cd1:	e8 6a fa ff ff       	call   5740 <fwp_heap_refill>
    5cd6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5cdb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5cdf:	49 89 c0             	mov    %rax,%r8
    5ce2:	e9 ff fe ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5ce7:	e8 c4 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005cf0 <fwp_heap_alloc>:
    5cf0:	8b 05 8e ae 01 00    	mov    0x1ae8e(%rip),%eax        # 20b84 <fwp_heap+0x13a4>
    5cf6:	48 89 fa             	mov    %rdi,%rdx
    5cf9:	89 f7                	mov    %esi,%edi
    5cfb:	85 c0                	test   %eax,%eax
    5cfd:	0f 84 f5 00 00 00    	je     5df8 <fwp_heap_alloc+0x108>
    5d03:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5d0a:	0f 87 e8 00 00 00    	ja     5df8 <fwp_heap_alloc+0x108>
    5d10:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5d14:	48 8d 05 c5 9a 01 00 	lea    0x19ac5(%rip),%rax        # 1f7e0 <fwp_heap>
    5d1b:	48 83 ec 18          	sub    $0x18,%rsp
    5d1f:	41 89 f0             	mov    %esi,%r8d
    5d22:	48 c1 e9 04          	shr    $0x4,%rcx
    5d26:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5d2d:	00 
    5d2e:	48 63 cf             	movslq %edi,%rcx
    5d31:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5d38:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5d3f:	00 
    5d40:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5d44:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5d48:	48 01 c8             	add    %rcx,%rax
    5d4b:	48 8b 08             	mov    (%rax),%rcx
    5d4e:	48 85 c9             	test   %rcx,%rcx
    5d51:	74 6d                	je     5dc0 <fwp_heap_alloc+0xd0>
    5d53:	48 8b 31             	mov    (%rcx),%rsi
    5d56:	48 f7 d6             	not    %rsi
    5d59:	48 89 30             	mov    %rsi,(%rax)
    5d5c:	41 83 f8 01          	cmp    $0x1,%r8d
    5d60:	48 89 cf             	mov    %rcx,%rdi
    5d63:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d68:	49 0f 45 d1          	cmovne %r9,%rdx
    5d6c:	31 f6                	xor    %esi,%esi
    5d6e:	e8 4d d7 ff ff       	call   34c0 <memset@plt>
    5d73:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d78:	48 89 c1             	mov    %rax,%rcx
    5d7b:	4c 89 c8             	mov    %r9,%rax
    5d7e:	48 03 05 7b ae 01 00 	add    0x1ae7b(%rip),%rax        # 20c00 <fwp_heap+0x1420>
    5d85:	72 7b                	jb     5e02 <fwp_heap_alloc+0x112>
    5d87:	48 39 05 7a ae 01 00 	cmp    %rax,0x1ae7a(%rip)        # 20c08 <fwp_heap+0x1428>
    5d8e:	48 89 05 6b ae 01 00 	mov    %rax,0x1ae6b(%rip)        # 20c00 <fwp_heap+0x1420>
    5d95:	73 07                	jae    5d9e <fwp_heap_alloc+0xae>
    5d97:	48 89 05 6a ae 01 00 	mov    %rax,0x1ae6a(%rip)        # 20c08 <fwp_heap+0x1428>
    5d9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da2:	48 89 c8             	mov    %rcx,%rax
    5da5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5daa:	f2 0f 58 05 66 ae 01 	addsd  0x1ae66(%rip),%xmm0        # 20c18 <fwp_heap+0x1438>
    5db1:	00 
    5db2:	f2 0f 11 05 5e ae 01 	movsd  %xmm0,0x1ae5e(%rip)        # 20c18 <fwp_heap+0x1438>
    5db9:	00 
    5dba:	48 83 c4 18          	add    $0x18,%rsp
    5dbe:	c3                   	ret
    5dbf:	90                   	nop
    5dc0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5dc4:	48 85 c9             	test   %rcx,%rcx
    5dc7:	74 0c                	je     5dd5 <fwp_heap_alloc+0xe5>
    5dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5dcd:	48 29 ce             	sub    %rcx,%rsi
    5dd0:	4c 39 ce             	cmp    %r9,%rsi
    5dd3:	73 13                	jae    5de8 <fwp_heap_alloc+0xf8>
    5dd5:	89 fe                	mov    %edi,%esi
    5dd7:	48 83 c4 18          	add    $0x18,%rsp
    5ddb:	48 89 d7             	mov    %rdx,%rdi
    5dde:	e9 8d fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5de8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5dec:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5df0:	e9 67 ff ff ff       	jmp    5d5c <fwp_heap_alloc+0x6c>
    5df5:	0f 1f 00             	nopl   (%rax)
    5df8:	89 fe                	mov    %edi,%esi
    5dfa:	48 89 d7             	mov    %rdx,%rdi
    5dfd:	e9 6e fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5e02:	e8 a9 de ff ff       	call   3cb0 <fwp_heap_oom>
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 

0000000000005e10 <fwp_data.part.0.constprop.0>:
    5e10:	41 56                	push   %r14
    5e12:	41 89 fe             	mov    %edi,%r14d
    5e15:	41 54                	push   %r12
    5e17:	49 89 f4             	mov    %rsi,%r12
    5e1a:	55                   	push   %rbp
    5e1b:	53                   	push   %rbx
    5e1c:	48 83 ec 08          	sub    $0x8,%rsp
    5e20:	8b 05 5e ad 01 00    	mov    0x1ad5e(%rip),%eax        # 20b84 <fwp_heap+0x13a4>
    5e26:	85 c0                	test   %eax,%eax
    5e28:	0f 84 fa 00 00 00    	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5e2e:	0f b6 05 4d a9 01 00 	movzbl 0x1a94d(%rip),%eax        # 20782 <fwp_heap+0xfa2>
    5e35:	48 8d 15 a4 99 01 00 	lea    0x199a4(%rip),%rdx        # 1f7e0 <fwp_heap>
    5e3c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5e43:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5e47:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5e4b:	48 8b 18             	mov    (%rax),%rbx
    5e4e:	48 85 db             	test   %rbx,%rbx
    5e51:	0f 84 a9 00 00 00    	je     5f00 <fwp_data.part.0.constprop.0+0xf0>
    5e57:	48 8b 13             	mov    (%rbx),%rdx
    5e5a:	48 f7 d2             	not    %rdx
    5e5d:	48 89 10             	mov    %rdx,(%rax)
    5e60:	48 83 fd 18          	cmp    $0x18,%rbp
    5e64:	76 1b                	jbe    5e81 <fwp_data.part.0.constprop.0+0x71>
    5e66:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e6a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e6e:	31 f6                	xor    %esi,%esi
    5e70:	48 c1 e8 03          	shr    $0x3,%rax
    5e74:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e7b:	00 
    5e7c:	e8 3f d6 ff ff       	call   34c0 <memset@plt>
    5e81:	48 89 e8             	mov    %rbp,%rax
    5e84:	48 03 05 75 ad 01 00 	add    0x1ad75(%rip),%rax        # 20c00 <fwp_heap+0x1420>
    5e8b:	0f 82 a8 00 00 00    	jb     5f39 <fwp_data.part.0.constprop.0+0x129>
    5e91:	48 39 05 70 ad 01 00 	cmp    %rax,0x1ad70(%rip)        # 20c08 <fwp_heap+0x1428>
    5e98:	48 89 05 61 ad 01 00 	mov    %rax,0x1ad61(%rip)        # 20c00 <fwp_heap+0x1420>
    5e9f:	73 07                	jae    5ea8 <fwp_data.part.0.constprop.0+0x98>
    5ea1:	48 89 05 60 ad 01 00 	mov    %rax,0x1ad60(%rip)        # 20c08 <fwp_heap+0x1428>
    5ea8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5eac:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5eb1:	f2 0f 58 05 5f ad 01 	addsd  0x1ad5f(%rip),%xmm0        # 20c18 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 57 ad 01 	movsd  %xmm0,0x1ad57(%rip)        # 20c18 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	b8 02 00 00 00       	mov    $0x2,%eax
    5ec6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5ecb:	66 0f 6e c8          	movd   %eax,%xmm1
    5ecf:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ed3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5ed7:	49 8b 04 24          	mov    (%r12),%rax
    5edb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5edf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5ee4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ee8:	48 83 c4 08          	add    $0x8,%rsp
    5eec:	48 89 d8             	mov    %rbx,%rax
    5eef:	5b                   	pop    %rbx
    5ef0:	5d                   	pop    %rbp
    5ef1:	41 5c                	pop    %r12
    5ef3:	41 5e                	pop    %r14
    5ef5:	c3                   	ret
    5ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5efd:	00 00 00 
    5f00:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5f04:	48 85 db             	test   %rbx,%rbx
    5f07:	74 1f                	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f09:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5f0d:	48 29 da             	sub    %rbx,%rdx
    5f10:	48 39 ea             	cmp    %rbp,%rdx
    5f13:	72 13                	jb     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f15:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5f19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f1d:	e9 3e ff ff ff       	jmp    5e60 <fwp_data.part.0.constprop.0+0x50>
    5f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f28:	31 f6                	xor    %esi,%esi
    5f2a:	bf 18 00 00 00       	mov    $0x18,%edi
    5f2f:	e8 bc fd ff ff       	call   5cf0 <fwp_heap_alloc>
    5f34:	48 89 c3             	mov    %rax,%rbx
    5f37:	eb 88                	jmp    5ec1 <fwp_data.part.0.constprop.0+0xb1>
    5f39:	e8 72 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5f3e:	66 90                	xchg   %ax,%ax

0000000000005f40 <fwp_p_ad_push>:
    5f40:	41 57                	push   %r15
    5f42:	41 56                	push   %r14
    5f44:	41 55                	push   %r13
    5f46:	49 89 d5             	mov    %rdx,%r13
    5f49:	41 54                	push   %r12
    5f4b:	49 89 fc             	mov    %rdi,%r12
    5f4e:	55                   	push   %rbp
    5f4f:	53                   	push   %rbx
    5f50:	48 83 ec 38          	sub    $0x38,%rsp
    5f54:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5f59:	48 85 ff             	test   %rdi,%rdi
    5f5c:	79 09                	jns    5f67 <fwp_p_ad_push+0x27>
    5f5e:	48 85 d2             	test   %rdx,%rdx
    5f61:	0f 88 a9 01 00 00    	js     6110 <fwp_p_ad_push+0x1d0>
    5f67:	48 89 f8             	mov    %rdi,%rax
    5f6a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f6e:	48 09 d0             	or     %rdx,%rax
    5f71:	0f 89 79 01 00 00    	jns    60f0 <fwp_p_ad_push+0x1b0>
    5f77:	48 89 f8             	mov    %rdi,%rax
    5f7a:	48 c1 f8 20          	sar    $0x20,%rax
    5f7e:	48 85 ff             	test   %rdi,%rdi
    5f81:	79 24                	jns    5fa7 <fwp_p_ad_push+0x67>
    5f83:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f88:	48 89 d0             	mov    %rdx,%rax
    5f8b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f92:	00 
    5f93:	49 89 d4             	mov    %rdx,%r12
    5f96:	48 c1 f8 20          	sar    $0x20,%rax
    5f9a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5fa1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5fa7:	48 89 c7             	mov    %rax,%rdi
    5faa:	e8 21 e7 ff ff       	call   46d0 <fwp_tape_of>
    5faf:	48 89 c3             	mov    %rax,%rbx
    5fb2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5fb7:	0f 85 76 02 00 00    	jne    6233 <fwp_p_ad_push+0x2f3>
    5fbd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5fc1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5fc8:	0f 8f 59 02 00 00    	jg     6227 <fwp_p_ad_push+0x2e7>
    5fce:	44 89 e0             	mov    %r12d,%eax
    5fd1:	4c 39 f8             	cmp    %r15,%rax
    5fd4:	0f 8d 41 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	78 0c                	js     5feb <fwp_p_ad_push+0xab>
    5fdf:	44 89 e8             	mov    %r13d,%eax
    5fe2:	4c 39 f8             	cmp    %r15,%rax
    5fe5:	0f 8d 30 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5feb:	4d 89 fe             	mov    %r15,%r14
    5fee:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5ff2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5ff6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5ffc:	0f 87 25 02 00 00    	ja     6227 <fwp_p_ad_push+0x2e7>
    6002:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6006:	48 39 e8             	cmp    %rbp,%rax
    6009:	0f 8e 31 01 00 00    	jle    6140 <fwp_p_ad_push+0x200>
    600f:	48 85 ed             	test   %rbp,%rbp
    6012:	b9 40 00 00 00       	mov    $0x40,%ecx
    6017:	48 0f 44 e9          	cmove  %rcx,%rbp
    601b:	48 39 e8             	cmp    %rbp,%rax
    601e:	7e 20                	jle    6040 <fwp_p_ad_push+0x100>
    6020:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6027:	0f 8f 03 01 00 00    	jg     6130 <fwp_p_ad_push+0x1f0>
    602d:	48 01 ed             	add    %rbp,%rbp
    6030:	48 39 e8             	cmp    %rbp,%rax
    6033:	7f eb                	jg     6020 <fwp_p_ad_push+0xe0>
    6035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    603c:	00 00 00 00 
    6040:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6047:	00 
    6048:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    604c:	48 89 c6             	mov    %rax,%rsi
    604f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6054:	e8 77 d5 ff ff       	call   35d0 <realloc@plt>
    6059:	48 85 c0             	test   %rax,%rax
    605c:	0f 84 dd 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6062:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6066:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    606a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    606e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6072:	48 89 e9             	mov    %rbp,%rcx
    6075:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6079:	48 c1 e1 04          	shl    $0x4,%rcx
    607d:	48 89 ce             	mov    %rcx,%rsi
    6080:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6085:	e8 46 d5 ff ff       	call   35d0 <realloc@plt>
    608a:	48 85 c0             	test   %rax,%rax
    608d:	0f 84 ac 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6093:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6097:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    609c:	4d 85 f6             	test   %r14,%r14
    609f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    60a3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    60a8:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60af:	00 
    60b0:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60b7:	00 
    60b8:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    60bc:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    60c3:	00 
    60c4:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    60c8:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    60cc:	0f 85 e2 00 00 00    	jne    61b4 <fwp_p_ad_push+0x274>
    60d2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    60d6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60da:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    60de:	49 01 c8             	add    %rcx,%r8
    60e1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    60e5:	eb 79                	jmp    6160 <fwp_p_ad_push+0x220>
    60e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    60ee:	00 00 
    60f0:	48 89 d0             	mov    %rdx,%rax
    60f3:	48 c1 ff 20          	sar    $0x20,%rdi
    60f7:	48 c1 f8 20          	sar    $0x20,%rax
    60fb:	48 39 c7             	cmp    %rax,%rdi
    60fe:	0f 84 a3 fe ff ff    	je     5fa7 <fwp_p_ad_push+0x67>
    6104:	48 8d 3d 85 57 00 00 	lea    0x5785(%rip),%rdi        # b890 <_IO_stdin_used+0x890>
    610b:	e8 e0 e2 ff ff       	call   43f0 <fwp_trap>
    6110:	48 83 c4 38          	add    $0x38,%rsp
    6114:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611b:	5b                   	pop    %rbx
    611c:	5d                   	pop    %rbp
    611d:	41 5c                	pop    %r12
    611f:	41 5d                	pop    %r13
    6121:	41 5e                	pop    %r14
    6123:	41 5f                	pop    %r15
    6125:	c3                   	ret
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6135:	e9 06 ff ff ff       	jmp    6040 <fwp_p_ad_push+0x100>
    613a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6140:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6144:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6148:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    614f:	00 
    6150:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6157:	00 
    6158:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    615c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6160:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6166:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    616a:	4d 85 ed             	test   %r13,%r13
    616d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6172:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6178:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    617f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6183:	49 8d 47 01          	lea    0x1(%r15),%rax
    6187:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    618b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6191:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6195:	48 83 c4 38          	add    $0x38,%rsp
    6199:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    61a0:	ff ff ff 
    61a3:	4c 21 e0             	and    %r12,%rax
    61a6:	5b                   	pop    %rbx
    61a7:	5d                   	pop    %rbp
    61a8:	4c 09 f8             	or     %r15,%rax
    61ab:	41 5c                	pop    %r12
    61ad:	41 5d                	pop    %r13
    61af:	41 5e                	pop    %r14
    61b1:	41 5f                	pop    %r15
    61b3:	c3                   	ret
    61b4:	48 39 ca             	cmp    %rcx,%rdx
    61b7:	49 89 d6             	mov    %rdx,%r14
    61ba:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    61bf:	48 0f 43 ca          	cmovae %rdx,%rcx
    61c3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    61c8:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    61cd:	48 29 d1             	sub    %rdx,%rcx
    61d0:	4c 89 ca             	mov    %r9,%rdx
    61d3:	e8 88 d3 ff ff       	call   3560 <__memmove_chk@plt>
    61d8:	4c 03 73 30          	add    0x30(%rbx),%r14
    61dc:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    61e1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    61e5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    61ea:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    61ee:	48 03 7b 20          	add    0x20(%rbx),%rdi
    61f2:	4c 89 d2             	mov    %r10,%rdx
    61f5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    61fa:	e8 11 d4 ff ff       	call   3610 <memmove@plt>
    61ff:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6203:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6207:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    620c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6211:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6216:	e9 bb fe ff ff       	jmp    60d6 <fwp_p_ad_push+0x196>
    621b:	48 8d 3d 45 4f 00 00 	lea    0x4f45(%rip),%rdi        # b167 <_IO_stdin_used+0x167>
    6222:	e8 c9 e1 ff ff       	call   43f0 <fwp_trap>
    6227:	48 8d 3d 1e 4f 00 00 	lea    0x4f1e(%rip),%rdi        # b14c <_IO_stdin_used+0x14c>
    622e:	e8 bd e1 ff ff       	call   43f0 <fwp_trap>
    6233:	48 8d 3d 9e 56 00 00 	lea    0x569e(%rip),%rdi        # b8d8 <_IO_stdin_used+0x8d8>
    623a:	e8 b1 e1 ff ff       	call   43f0 <fwp_trap>
    623f:	48 89 df             	mov    %rbx,%rdi
    6242:	e8 b9 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6247:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    624b:	e8 70 d1 ff ff       	call   33c0 <free@plt>
    6250:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6254:	e8 67 d1 ff ff       	call   33c0 <free@plt>
    6259:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    625d:	e8 5e d1 ff ff       	call   33c0 <free@plt>
    6262:	31 c9                	xor    %ecx,%ecx
    6264:	31 c0                	xor    %eax,%eax
    6266:	31 d2                	xor    %edx,%edx
    6268:	89 53 04             	mov    %edx,0x4(%rbx)
    626b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    626f:	ba 13 00 00 00       	mov    $0x13,%edx
    6274:	be 01 00 00 00       	mov    $0x1,%esi
    6279:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    627d:	48 8d 3d 84 4d 00 00 	lea    0x4d84(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6284:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6288:	48 8b 0d b1 8d 00 00 	mov    0x8db1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    628f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6293:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6297:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    629b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    629f:	e8 dc d3 ff ff       	call   3680 <fwrite@plt>
    62a4:	31 ff                	xor    %edi,%edi
    62a6:	e8 15 d3 ff ff       	call   35c0 <fflush@plt>
    62ab:	bf 66 00 00 00       	mov    $0x66,%edi
    62b0:	e8 eb d3 ff ff       	call   36a0 <_Exit@plt>
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 

00000000000062c0 <w120>:
    62c0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    62c4:	41 55                	push   %r13
    62c6:	48 89 fa             	mov    %rdi,%rdx
    62c9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    62cd:	41 54                	push   %r12
    62cf:	49 89 fc             	mov    %rdi,%r12
    62d2:	55                   	push   %rbp
    62d3:	53                   	push   %rbx
    62d4:	48 89 f3             	mov    %rsi,%rbx
    62d7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    62dc:	48 89 f1             	mov    %rsi,%rcx
    62df:	48 83 ec 28          	sub    $0x28,%rsp
    62e3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    62e9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    62ef:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62f5:	e8 46 fc ff ff       	call   5f40 <fwp_p_ad_push>
    62fa:	48 89 c7             	mov    %rax,%rdi
    62fd:	e8 5e ec ff ff       	call   4f60 <caf75>
    6302:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6307:	e8 54 ec ff ff       	call   4f60 <caf75>
    630c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6312:	66 0f 57 05 26 58 00 	xorpd  0x5826(%rip),%xmm0        # bb40 <msg.8+0x80>
    6319:	00 
    631a:	48 89 da             	mov    %rbx,%rdx
    631d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6323:	48 89 c1             	mov    %rax,%rcx
    6326:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    632b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6330:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6336:	e8 05 fc ff ff       	call   5f40 <fwp_p_ad_push>
    633b:	4c 89 e7             	mov    %r12,%rdi
    633e:	49 89 c5             	mov    %rax,%r13
    6341:	e8 1a ec ff ff       	call   4f60 <caf75>
    6346:	48 89 c6             	mov    %rax,%rsi
    6349:	e8 12 ec ff ff       	call   4f60 <caf75>
    634e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6353:	f2 0f 10 05 25 58 00 	movsd  0x5825(%rip),%xmm0        # bb80 <msg.8+0xc0>
    635a:	00 
    635b:	66 0f 57 15 dd 57 00 	xorpd  0x57dd(%rip),%xmm2        # bb40 <msg.8+0x80>
    6362:	00 
    6363:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6369:	48 89 c1             	mov    %rax,%rcx
    636c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6373:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6378:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    637d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6383:	e8 b8 fb ff ff       	call   5f40 <fwp_p_ad_push>
    6388:	48 89 e9             	mov    %rbp,%rcx
    638b:	4c 89 ea             	mov    %r13,%rdx
    638e:	48 89 ee             	mov    %rbp,%rsi
    6391:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6397:	4c 89 ef             	mov    %r13,%rdi
    639a:	49 89 c4             	mov    %rax,%r12
    639d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    63a1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63a7:	e8 94 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63ac:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    63b2:	f2 0f 59 1d ce 57 00 	mulsd  0x57ce(%rip),%xmm3        # bb88 <msg.8+0xc8>
    63b9:	00 
    63ba:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    63c1:	00 59 40 
    63c4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63c9:	48 89 c2             	mov    %rax,%rdx
    63cc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63d3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63d9:	e8 62 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63de:	4c 89 e2             	mov    %r12,%rdx
    63e1:	48 89 d9             	mov    %rbx,%rcx
    63e4:	48 89 de             	mov    %rbx,%rsi
    63e7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    63ed:	4c 89 e7             	mov    %r12,%rdi
    63f0:	48 89 c5             	mov    %rax,%rbp
    63f3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    63f7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    63fd:	e8 3e fb ff ff       	call   5f40 <fwp_p_ad_push>
    6402:	48 89 c7             	mov    %rax,%rdi
    6405:	e8 56 eb ff ff       	call   4f60 <caf75>
    640a:	48 89 c6             	mov    %rax,%rsi
    640d:	e8 4e eb ff ff       	call   4f60 <caf75>
    6412:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6418:	48 89 ea             	mov    %rbp,%rdx
    641b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6421:	48 89 c1             	mov    %rax,%rcx
    6424:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6429:	e8 12 fb ff ff       	call   5f40 <fwp_p_ad_push>
    642e:	48 83 c4 28          	add    $0x28,%rsp
    6432:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6437:	5b                   	pop    %rbx
    6438:	5d                   	pop    %rbp
    6439:	41 5c                	pop    %r12
    643b:	41 5d                	pop    %r13
    643d:	c3                   	ret
    643e:	66 90                	xchg   %ax,%ax

0000000000006440 <w176.constprop.0>:
    6440:	41 54                	push   %r12
    6442:	55                   	push   %rbp
    6443:	53                   	push   %rbx
    6444:	48 83 ec 10          	sub    $0x10,%rsp
    6448:	4c 8b 27             	mov    (%rdi),%r12
    644b:	4d 85 e4             	test   %r12,%r12
    644e:	74 78                	je     64c8 <w176.constprop.0+0x88>
    6450:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6457:	00 00 
    6459:	48 89 fd             	mov    %rdi,%rbp
    645c:	31 db                	xor    %ebx,%ebx
    645e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    646c:	00 00 00 00 
    6470:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6475:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    647b:	48 83 c3 02          	add    $0x2,%rbx
    647f:	e8 dc ea ff ff       	call   4f60 <caf75>
    6484:	48 89 c6             	mov    %rax,%rsi
    6487:	e8 d4 ea ff ff       	call   4f60 <caf75>
    648c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6492:	4c 89 c2             	mov    %r8,%rdx
    6495:	48 89 c1             	mov    %rax,%rcx
    6498:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    649e:	e8 9d fa ff ff       	call   5f40 <fwp_p_ad_push>
    64a3:	48 89 c7             	mov    %rax,%rdi
    64a6:	4c 39 e3             	cmp    %r12,%rbx
    64a9:	72 c5                	jb     6470 <w176.constprop.0+0x30>
    64ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    64b0:	48 83 c4 10          	add    $0x10,%rsp
    64b4:	5b                   	pop    %rbx
    64b5:	5d                   	pop    %rbp
    64b6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    64bb:	41 5c                	pop    %r12
    64bd:	48 89 f8             	mov    %rdi,%rax
    64c0:	c3                   	ret
    64c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64c8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    64cf:	00 00 
    64d1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64d8:	eb d1                	jmp    64ab <w176.constprop.0+0x6b>
    64da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000064e0 <fwp_rc_share>:
    64e0:	48 8b 05 d1 a6 01 00 	mov    0x1a6d1(%rip),%rax        # 20bb8 <fwp_heap+0x13d8>
    64e7:	48 2b 3d a2 a6 01 00 	sub    0x1a6a2(%rip),%rdi        # 20b90 <fwp_heap+0x13b0>
    64ee:	48 c1 e0 10          	shl    $0x10,%rax
    64f2:	48 39 c7             	cmp    %rax,%rdi
    64f5:	73 4a                	jae    6541 <fwp_rc_share+0x61>
    64f7:	48 89 f8             	mov    %rdi,%rax
    64fa:	48 c1 e8 10          	shr    $0x10,%rax
    64fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6502:	48 8b 05 cf a6 01 00 	mov    0x1a6cf(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    6509:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    650d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6511:	48 85 d2             	test   %rdx,%rdx
    6514:	74 2b                	je     6541 <fwp_rc_share+0x61>
    6516:	0f b6 08             	movzbl (%rax),%ecx
    6519:	80 f9 02             	cmp    $0x2,%cl
    651c:	74 2a                	je     6548 <fwp_rc_share+0x68>
    651e:	80 f9 01             	cmp    $0x1,%cl
    6521:	75 1e                	jne    6541 <fwp_rc_share+0x61>
    6523:	8b 48 18             	mov    0x18(%rax),%ecx
    6526:	0f b7 ff             	movzwl %di,%edi
    6529:	8b 40 1c             	mov    0x1c(%rax),%eax
    652c:	48 0f af f9          	imul   %rcx,%rdi
    6530:	48 c1 ef 20          	shr    $0x20,%rdi
    6534:	48 39 c7             	cmp    %rax,%rdi
    6537:	73 08                	jae    6541 <fwp_rc_share+0x61>
    6539:	48 01 fa             	add    %rdi,%rdx
    653c:	80 3a 00             	cmpb   $0x0,(%rdx)
    653f:	75 0d                	jne    654e <fwp_rc_share+0x6e>
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 ef                	je     653c <fwp_rc_share+0x5c>
    654d:	c3                   	ret
    654e:	50                   	push   %rax
    654f:	48 8d 3d b2 53 00 00 	lea    0x53b2(%rip),%rdi        # b908 <_IO_stdin_used+0x908>
    6556:	e8 95 de ff ff       	call   43f0 <fwp_trap>
    655b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006560 <fwp_rc_free_obj>:
    6560:	48 8b 15 51 a6 01 00 	mov    0x1a651(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    6567:	48 89 f8             	mov    %rdi,%rax
    656a:	48 2b 05 1f a6 01 00 	sub    0x1a61f(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    6571:	48 c1 e2 10          	shl    $0x10,%rdx
    6575:	48 39 d0             	cmp    %rdx,%rax
    6578:	73 5b                	jae    65d5 <fwp_rc_free_obj+0x75>
    657a:	48 89 c2             	mov    %rax,%rdx
    657d:	48 c1 ea 10          	shr    $0x10,%rdx
    6581:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6585:	48 8b 15 4c a6 01 00 	mov    0x1a64c(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    658c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6590:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6594:	48 85 c9             	test   %rcx,%rcx
    6597:	74 3c                	je     65d5 <fwp_rc_free_obj+0x75>
    6599:	0f b6 32             	movzbl (%rdx),%esi
    659c:	40 80 fe 02          	cmp    $0x2,%sil
    65a0:	74 2e                	je     65d0 <fwp_rc_free_obj+0x70>
    65a2:	40 80 fe 01          	cmp    $0x1,%sil
    65a6:	75 2d                	jne    65d5 <fwp_rc_free_obj+0x75>
    65a8:	8b 72 18             	mov    0x18(%rdx),%esi
    65ab:	0f b7 c0             	movzwl %ax,%eax
    65ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65b1:	48 0f af c6          	imul   %rsi,%rax
    65b5:	48 c1 e8 20          	shr    $0x20,%rax
    65b9:	48 39 d0             	cmp    %rdx,%rax
    65bc:	73 17                	jae    65d5 <fwp_rc_free_obj+0x75>
    65be:	48 01 c1             	add    %rax,%rcx
    65c1:	80 39 01             	cmpb   $0x1,(%rcx)
    65c4:	75 0f                	jne    65d5 <fwp_rc_free_obj+0x75>
    65c6:	e9 25 f2 ff ff       	jmp    57f0 <fwp_mem_free>
    65cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65d0:	66 85 c0             	test   %ax,%ax
    65d3:	74 ec                	je     65c1 <fwp_rc_free_obj+0x61>
    65d5:	c3                   	ret
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 

00000000000065e0 <fwp_rc_dup>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	48 8b 05 cd a5 01 00 	mov    0x1a5cd(%rip),%rax        # 20bb8 <fwp_heap+0x13d8>
    65eb:	48 2b 3d 9e a5 01 00 	sub    0x1a59e(%rip),%rdi        # 20b90 <fwp_heap+0x13b0>
    65f2:	48 c1 e0 10          	shl    $0x10,%rax
    65f6:	48 39 c7             	cmp    %rax,%rdi
    65f9:	73 56                	jae    6651 <fwp_rc_dup+0x71>
    65fb:	48 89 f8             	mov    %rdi,%rax
    65fe:	48 c1 e8 10          	shr    $0x10,%rax
    6602:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6606:	48 8b 05 cb a5 01 00 	mov    0x1a5cb(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    660d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6611:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6615:	48 85 c0             	test   %rax,%rax
    6618:	74 37                	je     6651 <fwp_rc_dup+0x71>
    661a:	0f b6 0a             	movzbl (%rdx),%ecx
    661d:	80 f9 02             	cmp    $0x2,%cl
    6620:	74 36                	je     6658 <fwp_rc_dup+0x78>
    6622:	80 f9 01             	cmp    $0x1,%cl
    6625:	75 2a                	jne    6651 <fwp_rc_dup+0x71>
    6627:	8b 4a 18             	mov    0x18(%rdx),%ecx
    662a:	0f b7 ff             	movzwl %di,%edi
    662d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6630:	48 0f af f9          	imul   %rcx,%rdi
    6634:	48 c1 ef 20          	shr    $0x20,%rdi
    6638:	48 39 d7             	cmp    %rdx,%rdi
    663b:	73 14                	jae    6651 <fwp_rc_dup+0x71>
    663d:	48 01 f8             	add    %rdi,%rax
    6640:	0f b6 10             	movzbl (%rax),%edx
    6643:	84 d2                	test   %dl,%dl
    6645:	74 0a                	je     6651 <fwp_rc_dup+0x71>
    6647:	80 fa fd             	cmp    $0xfd,%dl
    664a:	77 14                	ja     6660 <fwp_rc_dup+0x80>
    664c:	83 c2 01             	add    $0x1,%edx
    664f:	88 10                	mov    %dl,(%rax)
    6651:	c3                   	ret
    6652:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6658:	66 85 ff             	test   %di,%di
    665b:	74 e3                	je     6640 <fwp_rc_dup+0x60>
    665d:	c3                   	ret
    665e:	66 90                	xchg   %ax,%ax
    6660:	48 89 c7             	mov    %rax,%rdi
    6663:	e9 28 ee ff ff       	jmp    5490 <fwp_rc_wide_dup>
    6668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    666f:	00 

0000000000006670 <fwp_owned_entry173>:
    6670:	f3 0f 1e fa          	endbr64
    6674:	48 83 ec 38          	sub    $0x38,%rsp
    6678:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    667d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6684:	00 00 
    6686:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    668b:	31 c0                	xor    %eax,%eax
    668d:	48 8b 07             	mov    (%rdi),%rax
    6690:	48 03 47 10          	add    0x10(%rdi),%rax
    6694:	0f 80 c2 00 00 00    	jo     675c <fwp_owned_entry173+0xec>
    669a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    669f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    66a4:	31 ff                	xor    %edi,%edi
    66a6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    66aa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66af:	e8 5c f7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    66b4:	48 8b 15 fd a4 01 00 	mov    0x1a4fd(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    66bb:	48 89 c6             	mov    %rax,%rsi
    66be:	48 2b 05 cb a4 01 00 	sub    0x1a4cb(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    66c5:	48 c1 e2 10          	shl    $0x10,%rdx
    66c9:	48 39 d0             	cmp    %rdx,%rax
    66cc:	73 4f                	jae    671d <fwp_owned_entry173+0xad>
    66ce:	48 89 c2             	mov    %rax,%rdx
    66d1:	48 c1 ea 10          	shr    $0x10,%rdx
    66d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66d9:	48 8b 15 f8 a4 01 00 	mov    0x1a4f8(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    66e0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66e4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66e8:	48 85 d2             	test   %rdx,%rdx
    66eb:	74 30                	je     671d <fwp_owned_entry173+0xad>
    66ed:	0f b6 39             	movzbl (%rcx),%edi
    66f0:	40 80 ff 02          	cmp    $0x2,%dil
    66f4:	74 42                	je     6738 <fwp_owned_entry173+0xc8>
    66f6:	40 80 ff 01          	cmp    $0x1,%dil
    66fa:	75 21                	jne    671d <fwp_owned_entry173+0xad>
    66fc:	8b 79 18             	mov    0x18(%rcx),%edi
    66ff:	0f b7 c0             	movzwl %ax,%eax
    6702:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6705:	48 0f af c7          	imul   %rdi,%rax
    6709:	48 c1 e8 20          	shr    $0x20,%rax
    670d:	48 39 c8             	cmp    %rcx,%rax
    6710:	73 0b                	jae    671d <fwp_owned_entry173+0xad>
    6712:	48 01 c2             	add    %rax,%rdx
    6715:	80 3a ff             	cmpb   $0xff,(%rdx)
    6718:	74 26                	je     6740 <fwp_owned_entry173+0xd0>
    671a:	c6 02 01             	movb   $0x1,(%rdx)
    671d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6722:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6729:	00 00 
    672b:	75 34                	jne    6761 <fwp_owned_entry173+0xf1>
    672d:	48 89 f0             	mov    %rsi,%rax
    6730:	48 83 c4 38          	add    $0x38,%rsp
    6734:	c3                   	ret
    6735:	0f 1f 00             	nopl   (%rax)
    6738:	66 85 c0             	test   %ax,%ax
    673b:	75 e0                	jne    671d <fwp_owned_entry173+0xad>
    673d:	eb d6                	jmp    6715 <fwp_owned_entry173+0xa5>
    673f:	90                   	nop
    6740:	48 89 d7             	mov    %rdx,%rdi
    6743:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6748:	48 89 14 24          	mov    %rdx,(%rsp)
    674c:	e8 5f ee ff ff       	call   55b0 <fwp_rc_forget_slot>
    6751:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6756:	48 8b 14 24          	mov    (%rsp),%rdx
    675a:	eb be                	jmp    671a <fwp_owned_entry173+0xaa>
    675c:	e8 9f cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6761:	e8 fa cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    676d:	00 00 00 

0000000000006770 <e173>:
    6770:	f3 0f 1e fa          	endbr64
    6774:	53                   	push   %rbx
    6775:	48 83 ec 30          	sub    $0x30,%rsp
    6779:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    677e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6785:	00 00 
    6787:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    678c:	31 c0                	xor    %eax,%eax
    678e:	48 8b 07             	mov    (%rdi),%rax
    6791:	48 03 47 10          	add    0x10(%rdi),%rax
    6795:	0f 80 c9 00 00 00    	jo     6864 <e173+0xf4>
    679b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    67a0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    67a5:	31 ff                	xor    %edi,%edi
    67a7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    67ab:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67b0:	e8 5b f6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    67b5:	48 8b 15 fc a3 01 00 	mov    0x1a3fc(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    67bc:	48 89 c3             	mov    %rax,%rbx
    67bf:	48 2b 05 ca a3 01 00 	sub    0x1a3ca(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    67c6:	48 c1 e2 10          	shl    $0x10,%rdx
    67ca:	48 39 d0             	cmp    %rdx,%rax
    67cd:	73 4f                	jae    681e <e173+0xae>
    67cf:	48 89 c2             	mov    %rax,%rdx
    67d2:	48 c1 ea 10          	shr    $0x10,%rdx
    67d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67da:	48 8b 15 f7 a3 01 00 	mov    0x1a3f7(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    67e1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67e5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67e9:	48 85 d2             	test   %rdx,%rdx
    67ec:	74 30                	je     681e <e173+0xae>
    67ee:	0f b6 31             	movzbl (%rcx),%esi
    67f1:	40 80 fe 02          	cmp    $0x2,%sil
    67f5:	74 49                	je     6840 <e173+0xd0>
    67f7:	40 80 fe 01          	cmp    $0x1,%sil
    67fb:	75 21                	jne    681e <e173+0xae>
    67fd:	8b 71 18             	mov    0x18(%rcx),%esi
    6800:	0f b7 c0             	movzwl %ax,%eax
    6803:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6806:	48 0f af c6          	imul   %rsi,%rax
    680a:	48 c1 e8 20          	shr    $0x20,%rax
    680e:	48 39 c8             	cmp    %rcx,%rax
    6811:	73 0b                	jae    681e <e173+0xae>
    6813:	48 01 c2             	add    %rax,%rdx
    6816:	80 3a ff             	cmpb   $0xff,(%rdx)
    6819:	74 35                	je     6850 <e173+0xe0>
    681b:	c6 02 01             	movb   $0x1,(%rdx)
    681e:	48 89 df             	mov    %rbx,%rdi
    6821:	e8 ba fc ff ff       	call   64e0 <fwp_rc_share>
    6826:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    682b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6832:	00 00 
    6834:	75 33                	jne    6869 <e173+0xf9>
    6836:	48 83 c4 30          	add    $0x30,%rsp
    683a:	48 89 d8             	mov    %rbx,%rax
    683d:	5b                   	pop    %rbx
    683e:	c3                   	ret
    683f:	90                   	nop
    6840:	66 85 c0             	test   %ax,%ax
    6843:	75 d9                	jne    681e <e173+0xae>
    6845:	eb cf                	jmp    6816 <e173+0xa6>
    6847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    684e:	00 00 
    6850:	48 89 d7             	mov    %rdx,%rdi
    6853:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6858:	e8 53 ed ff ff       	call   55b0 <fwp_rc_forget_slot>
    685d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6862:	eb b7                	jmp    681b <e173+0xab>
    6864:	e8 97 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6869:	e8 f2 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    686e:	66 90                	xchg   %ax,%ax

0000000000006870 <fwp_closure_drop>:
    6870:	48 8b 15 41 a3 01 00 	mov    0x1a341(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 2b 05 0f a3 01 00 	sub    0x1a30f(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    6881:	48 c1 e2 10          	shl    $0x10,%rdx
    6885:	48 39 d0             	cmp    %rdx,%rax
    6888:	73 6b                	jae    68f5 <fwp_closure_drop+0x85>
    688a:	48 89 c2             	mov    %rax,%rdx
    688d:	48 c1 ea 10          	shr    $0x10,%rdx
    6891:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6895:	48 8b 15 3c a3 01 00 	mov    0x1a33c(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    689c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68a0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68a4:	48 85 d2             	test   %rdx,%rdx
    68a7:	74 4c                	je     68f5 <fwp_closure_drop+0x85>
    68a9:	0f b6 31             	movzbl (%rcx),%esi
    68ac:	40 80 fe 02          	cmp    $0x2,%sil
    68b0:	74 3e                	je     68f0 <fwp_closure_drop+0x80>
    68b2:	40 80 fe 01          	cmp    $0x1,%sil
    68b6:	75 3d                	jne    68f5 <fwp_closure_drop+0x85>
    68b8:	8b 71 18             	mov    0x18(%rcx),%esi
    68bb:	0f b7 c0             	movzwl %ax,%eax
    68be:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68c1:	48 0f af c6          	imul   %rsi,%rax
    68c5:	48 c1 e8 20          	shr    $0x20,%rax
    68c9:	48 39 c8             	cmp    %rcx,%rax
    68cc:	73 27                	jae    68f5 <fwp_closure_drop+0x85>
    68ce:	48 01 c2             	add    %rax,%rdx
    68d1:	0f b6 02             	movzbl (%rdx),%eax
    68d4:	84 c0                	test   %al,%al
    68d6:	74 1d                	je     68f5 <fwp_closure_drop+0x85>
    68d8:	3c 01                	cmp    $0x1,%al
    68da:	74 24                	je     6900 <fwp_closure_drop+0x90>
    68dc:	3c ff                	cmp    $0xff,%al
    68de:	74 48                	je     6928 <fwp_closure_drop+0xb8>
    68e0:	83 e8 01             	sub    $0x1,%eax
    68e3:	88 02                	mov    %al,(%rdx)
    68e5:	c3                   	ret
    68e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68ed:	00 00 00 
    68f0:	66 85 c0             	test   %ax,%ax
    68f3:	74 dc                	je     68d1 <fwp_closure_drop+0x61>
    68f5:	c3                   	ret
    68f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68fd:	00 00 00 
    6900:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6907:	ff ff 
    6909:	48 85 c0             	test   %rax,%rax
    690c:	74 12                	je     6920 <fwp_closure_drop+0xb0>
    690e:	48 89 fe             	mov    %rdi,%rsi
    6911:	48 89 c7             	mov    %rax,%rdi
    6914:	e9 37 db ff ff       	jmp    4450 <fwp_closure_drop_push>
    6919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6920:	e9 db dc ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6925:	0f 1f 00             	nopl   (%rax)
    6928:	48 89 d0             	mov    %rdx,%rax
    692b:	48 8d 35 ae 8e 01 00 	lea    0x18eae(%rip),%rsi        # 1f7e0 <fwp_heap>
    6932:	48 83 ec 18          	sub    $0x18,%rsp
    6936:	48 c1 e8 11          	shr    $0x11,%rax
    693a:	48 31 d0             	xor    %rdx,%rax
    693d:	48 89 c1             	mov    %rax,%rcx
    6940:	48 c1 e9 09          	shr    $0x9,%rcx
    6944:	48 31 c8             	xor    %rcx,%rax
    6947:	0f b6 c8             	movzbl %al,%ecx
    694a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6951:	00 
    6952:	48 85 c0             	test   %rax,%rax
    6955:	75 12                	jne    6969 <fwp_closure_drop+0xf9>
    6957:	eb 49                	jmp    69a2 <fwp_closure_drop+0x132>
    6959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6960:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6964:	48 85 c0             	test   %rax,%rax
    6967:	74 39                	je     69a2 <fwp_closure_drop+0x132>
    6969:	48 89 c1             	mov    %rax,%rcx
    696c:	48 39 10             	cmp    %rdx,(%rax)
    696f:	75 ef                	jne    6960 <fwp_closure_drop+0xf0>
    6971:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6975:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6979:	48 89 48 08          	mov    %rcx,0x8(%rax)
    697d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6984:	74 05                	je     698b <fwp_closure_drop+0x11b>
    6986:	48 83 c4 18          	add    $0x18,%rsp
    698a:	c3                   	ret
    698b:	48 89 d7             	mov    %rdx,%rdi
    698e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6993:	e8 18 ec ff ff       	call   55b0 <fwp_rc_forget_slot>
    6998:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    699d:	c6 02 fe             	movb   $0xfe,(%rdx)
    69a0:	eb e4                	jmp    6986 <fwp_closure_drop+0x116>
    69a2:	48 8d 3d bf 4e 00 00 	lea    0x4ebf(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    69a9:	e8 42 da ff ff       	call   43f0 <fwp_trap>
    69ae:	66 90                	xchg   %ax,%ax

00000000000069b0 <fwp_owned_tape_release>:
    69b0:	48 85 ff             	test   %rdi,%rdi
    69b3:	0f 84 f7 00 00 00    	je     6ab0 <fwp_owned_tape_release+0x100>
    69b9:	41 54                	push   %r12
    69bb:	55                   	push   %rbp
    69bc:	53                   	push   %rbx
    69bd:	48 8b 07             	mov    (%rdi),%rax
    69c0:	48 85 c0             	test   %rax,%rax
    69c3:	74 08                	je     69cd <fwp_owned_tape_release+0x1d>
    69c5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69cd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69d1:	48 85 d2             	test   %rdx,%rdx
    69d4:	74 03                	je     69d9 <fwp_owned_tape_release+0x29>
    69d6:	48 89 02             	mov    %rax,(%rdx)
    69d9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    69dd:	48 89 fb             	mov    %rdi,%rbx
    69e0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    69e4:	48 85 c0             	test   %rax,%rax
    69e7:	0f 84 89 00 00 00    	je     6a76 <fwp_owned_tape_release+0xc6>
    69ed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    69f1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    69f5:	7e 47                	jle    6a3e <fwp_owned_tape_release+0x8e>
    69f7:	31 ed                	xor    %ebp,%ebp
    69f9:	eb 0d                	jmp    6a08 <fwp_owned_tape_release+0x58>
    69fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6a08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6a0c:	49 89 ec             	mov    %rbp,%r12
    6a0f:	48 83 c5 01          	add    $0x1,%rbp
    6a13:	49 c1 e4 04          	shl    $0x4,%r12
    6a17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6a1b:	ff d0                	call   *%rax
    6a1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6a21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6a26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a2a:	ff 50 68             	call   *0x68(%rax)
    6a2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6a31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6a35:	48 39 e8             	cmp    %rbp,%rax
    6a38:	7f c6                	jg     6a00 <fwp_owned_tape_release+0x50>
    6a3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a3e:	31 ed                	xor    %ebp,%ebp
    6a40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6a45:	7e 28                	jle    6a6f <fwp_owned_tape_release+0xbf>
    6a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a4e:	00 00 
    6a50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6a54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6a58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6a5c:	74 07                	je     6a65 <fwp_owned_tape_release+0xb5>
    6a5e:	ff 52 68             	call   *0x68(%rdx)
    6a61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a65:	48 83 c5 01          	add    $0x1,%rbp
    6a69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a6d:	7f e1                	jg     6a50 <fwp_owned_tape_release+0xa0>
    6a6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a73:	ff 52 68             	call   *0x68(%rdx)
    6a76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a7a:	e8 f1 fd ff ff       	call   6870 <fwp_closure_drop>
    6a7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a83:	e8 e8 fd ff ff       	call   6870 <fwp_closure_drop>
    6a88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a8c:	e8 df fd ff ff       	call   6870 <fwp_closure_drop>
    6a91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a95:	e8 56 ed ff ff       	call   57f0 <fwp_mem_free>
    6a9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a9e:	e8 4d ed ff ff       	call   57f0 <fwp_mem_free>
    6aa3:	48 89 df             	mov    %rbx,%rdi
    6aa6:	5b                   	pop    %rbx
    6aa7:	5d                   	pop    %rbp
    6aa8:	41 5c                	pop    %r12
    6aaa:	e9 41 ed ff ff       	jmp    57f0 <fwp_mem_free>
    6aaf:	90                   	nop
    6ab0:	c3                   	ret
    6ab1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6abc:	00 00 00 00 

0000000000006ac0 <fwp_tape_finish>:
    6ac0:	f3 0f 1e fa          	endbr64
    6ac4:	41 56                	push   %r14
    6ac6:	48 8d 3d f3 85 01 00 	lea    0x185f3(%rip),%rdi        # 1f0c0 <fwp_tape_workspace>
    6acd:	41 55                	push   %r13
    6acf:	41 54                	push   %r12
    6ad1:	55                   	push   %rbp
    6ad2:	53                   	push   %rbx
    6ad3:	e8 38 d6 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6ad8:	48 83 3d 28 86 01 00 	cmpq   $0x0,0x18628(%rip)        # 1f108 <fwp_ntapes>
    6adf:	00 
    6ae0:	48 c7 05 bd 85 01 00 	movq   $0x0,0x185bd(%rip)        # 1f0a8 <fwp_tape_cached_bytes>
    6ae7:	00 00 00 00 
    6aeb:	7e 68                	jle    6b55 <fwp_tape_finish+0x95>
    6aed:	45 31 e4             	xor    %r12d,%r12d
    6af0:	31 ed                	xor    %ebp,%ebp
    6af2:	0f 1f 00             	nopl   (%rax)
    6af5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6afc:	00 00 00 00 
    6b00:	48 8b 1d 09 86 01 00 	mov    0x18609(%rip),%rbx        # 1f110 <fwp_tapes>
    6b07:	48 83 c5 01          	add    $0x1,%rbp
    6b0b:	4c 01 e3             	add    %r12,%rbx
    6b0e:	49 83 c4 68          	add    $0x68,%r12
    6b12:	48 89 df             	mov    %rbx,%rdi
    6b15:	e8 e6 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6b1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6b26:	e8 95 c8 ff ff       	call   33c0 <free@plt>
    6b2b:	4c 89 f7             	mov    %r14,%rdi
    6b2e:	e8 8d c8 ff ff       	call   33c0 <free@plt>
    6b33:	4c 89 ef             	mov    %r13,%rdi
    6b36:	e8 85 c8 ff ff       	call   33c0 <free@plt>
    6b3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6b3f:	e8 6c fe ff ff       	call   69b0 <fwp_owned_tape_release>
    6b44:	48 39 2d bd 85 01 00 	cmp    %rbp,0x185bd(%rip)        # 1f108 <fwp_ntapes>
    6b4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6b52:	00 
    6b53:	7f ab                	jg     6b00 <fwp_tape_finish+0x40>
    6b55:	48 8b 3d b4 85 01 00 	mov    0x185b4(%rip),%rdi        # 1f110 <fwp_tapes>
    6b5c:	e8 5f c8 ff ff       	call   33c0 <free@plt>
    6b61:	5b                   	pop    %rbx
    6b62:	5d                   	pop    %rbp
    6b63:	48 c7 05 a2 85 01 00 	movq   $0x0,0x185a2(%rip)        # 1f110 <fwp_tapes>
    6b6a:	00 00 00 00 
    6b6e:	48 c7 05 87 85 01 00 	movq   $0x0,0x18587(%rip)        # 1f100 <fwp_tapes_cap>
    6b75:	00 00 00 00 
    6b79:	41 5c                	pop    %r12
    6b7b:	48 c7 05 82 85 01 00 	movq   $0x0,0x18582(%rip)        # 1f108 <fwp_ntapes>
    6b82:	00 00 00 00 
    6b86:	41 5d                	pop    %r13
    6b88:	48 c7 05 65 85 01 00 	movq   $0x0,0x18565(%rip)        # 1f0f8 <fwp_tape_next_slot>
    6b8f:	00 00 00 00 
    6b93:	41 5e                	pop    %r14
    6b95:	c3                   	ret
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 

0000000000006ba0 <fwp_tape_scope_release>:
    6ba0:	f3 0f 1e fa          	endbr64
    6ba4:	41 55                	push   %r13
    6ba6:	41 54                	push   %r12
    6ba8:	55                   	push   %rbp
    6ba9:	53                   	push   %rbx
    6baa:	48 83 ec 58          	sub    $0x58,%rsp
    6bae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bb5:	00 00 
    6bb7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6bbc:	48 63 07             	movslq (%rdi),%rax
    6bbf:	85 c0                	test   %eax,%eax
    6bc1:	0f 88 05 01 00 00    	js     6ccc <fwp_tape_scope_release+0x12c>
    6bc7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6bce:	ec c4 4e 
    6bd1:	48 89 fb             	mov    %rdi,%rbx
    6bd4:	eb 3c                	jmp    6c12 <fwp_tape_scope_release+0x72>
    6bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bdd:	00 00 00 
    6be0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6be5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6be9:	e8 d2 c7 ff ff       	call   33c0 <free@plt>
    6bee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6bf2:	e8 c9 c7 ff ff       	call   33c0 <free@plt>
    6bf7:	4c 89 ef             	mov    %r13,%rdi
    6bfa:	e8 c1 c7 ff ff       	call   33c0 <free@plt>
    6bff:	4c 89 e7             	mov    %r12,%rdi
    6c02:	e8 a9 fd ff ff       	call   69b0 <fwp_owned_tape_release>
    6c07:	48 63 03             	movslq (%rbx),%rax
    6c0a:	85 c0                	test   %eax,%eax
    6c0c:	0f 88 ba 00 00 00    	js     6ccc <fwp_tape_scope_release+0x12c>
    6c12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6c16:	48 8b 35 f3 84 01 00 	mov    0x184f3(%rip),%rsi        # 1f110 <fwp_tapes>
    6c1d:	4c 01 c6             	add    %r8,%rsi
    6c20:	48 89 f7             	mov    %rsi,%rdi
    6c23:	e8 d8 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6c2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6c32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6c39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6c3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6c41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6c48:	00 
    6c49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6c4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6c52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6c57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6c5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c67:	00 
    6c68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c6f:	00 
    6c70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c77:	00 
    6c78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c94:	77 18                	ja     6cae <fwp_tape_scope_release+0x10e>
    6c96:	49 c1 f8 03          	sar    $0x3,%r8
    6c9a:	4c 0f af c5          	imul   %rbp,%r8
    6c9e:	4c 3b 05 53 84 01 00 	cmp    0x18453(%rip),%r8        # 1f0f8 <fwp_tape_next_slot>
    6ca5:	7d 07                	jge    6cae <fwp_tape_scope_release+0x10e>
    6ca7:	4c 89 05 4a 84 01 00 	mov    %r8,0x1844a(%rip)        # 1f0f8 <fwp_tape_next_slot>
    6cae:	4d 85 e4             	test   %r12,%r12
    6cb1:	0f 85 29 ff ff ff    	jne    6be0 <fwp_tape_scope_release+0x40>
    6cb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6cbc:	e8 0f e4 ff ff       	call   50d0 <fwp_tape_buffers_release>
    6cc1:	48 63 03             	movslq (%rbx),%rax
    6cc4:	85 c0                	test   %eax,%eax
    6cc6:	0f 89 46 ff ff ff    	jns    6c12 <fwp_tape_scope_release+0x72>
    6ccc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6cd1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cd8:	00 00 
    6cda:	75 0b                	jne    6ce7 <fwp_tape_scope_release+0x147>
    6cdc:	48 83 c4 58          	add    $0x58,%rsp
    6ce0:	5b                   	pop    %rbx
    6ce1:	5d                   	pop    %rbp
    6ce2:	41 5c                	pop    %r12
    6ce4:	41 5d                	pop    %r13
    6ce6:	c3                   	ret
    6ce7:	e8 74 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cf0 <fwp_drop4>:
    6cf0:	48 8b 0d c1 9e 01 00 	mov    0x19ec1(%rip),%rcx        # 20bb8 <fwp_heap+0x13d8>
    6cf7:	48 89 f8             	mov    %rdi,%rax
    6cfa:	48 2b 05 8f 9e 01 00 	sub    0x19e8f(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    6d01:	48 c1 e1 10          	shl    $0x10,%rcx
    6d05:	48 39 c8             	cmp    %rcx,%rax
    6d08:	0f 83 42 01 00 00    	jae    6e50 <fwp_drop4+0x160>
    6d0e:	48 83 ec 18          	sub    $0x18,%rsp
    6d12:	48 89 fa             	mov    %rdi,%rdx
    6d15:	4c 8d 05 c4 8a 01 00 	lea    0x18ac4(%rip),%r8        # 1f7e0 <fwp_heap>
    6d1c:	48 89 c1             	mov    %rax,%rcx
    6d1f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6d26:	48 c1 e9 10          	shr    $0x10,%rcx
    6d2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d2e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d32:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d36:	48 85 c9             	test   %rcx,%rcx
    6d39:	74 40                	je     6d7b <fwp_drop4+0x8b>
    6d3b:	0f b6 3e             	movzbl (%rsi),%edi
    6d3e:	40 80 ff 02          	cmp    $0x2,%dil
    6d42:	74 3c                	je     6d80 <fwp_drop4+0x90>
    6d44:	40 80 ff 01          	cmp    $0x1,%dil
    6d48:	75 31                	jne    6d7b <fwp_drop4+0x8b>
    6d4a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6d4d:	0f b7 c0             	movzwl %ax,%eax
    6d50:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d53:	48 0f af c7          	imul   %rdi,%rax
    6d57:	48 c1 e8 20          	shr    $0x20,%rax
    6d5b:	48 39 f0             	cmp    %rsi,%rax
    6d5e:	73 1b                	jae    6d7b <fwp_drop4+0x8b>
    6d60:	48 01 c1             	add    %rax,%rcx
    6d63:	0f b6 01             	movzbl (%rcx),%eax
    6d66:	84 c0                	test   %al,%al
    6d68:	74 11                	je     6d7b <fwp_drop4+0x8b>
    6d6a:	3c 01                	cmp    $0x1,%al
    6d6c:	74 22                	je     6d90 <fwp_drop4+0xa0>
    6d6e:	3c ff                	cmp    $0xff,%al
    6d70:	0f 84 0a 01 00 00    	je     6e80 <fwp_drop4+0x190>
    6d76:	83 e8 01             	sub    $0x1,%eax
    6d79:	88 01                	mov    %al,(%rcx)
    6d7b:	48 83 c4 18          	add    $0x18,%rsp
    6d7f:	c3                   	ret
    6d80:	66 85 c0             	test   %ax,%ax
    6d83:	74 de                	je     6d63 <fwp_drop4+0x73>
    6d85:	48 83 c4 18          	add    $0x18,%rsp
    6d89:	c3                   	ret
    6d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d90:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6d94:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6d9b:	48 89 f8             	mov    %rdi,%rax
    6d9e:	48 c1 e1 10          	shl    $0x10,%rcx
    6da2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6da9:	48 39 c8             	cmp    %rcx,%rax
    6dac:	73 62                	jae    6e10 <fwp_drop4+0x120>
    6dae:	48 89 c1             	mov    %rax,%rcx
    6db1:	48 c1 e9 10          	shr    $0x10,%rcx
    6db5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6db9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6dbd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6dc1:	48 85 c9             	test   %rcx,%rcx
    6dc4:	74 4a                	je     6e10 <fwp_drop4+0x120>
    6dc6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6dca:	41 80 f9 02          	cmp    $0x2,%r9b
    6dce:	0f 84 9c 00 00 00    	je     6e70 <fwp_drop4+0x180>
    6dd4:	41 80 f9 01          	cmp    $0x1,%r9b
    6dd8:	75 36                	jne    6e10 <fwp_drop4+0x120>
    6dda:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6dde:	0f b7 c0             	movzwl %ax,%eax
    6de1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6de4:	49 0f af c1          	imul   %r9,%rax
    6de8:	48 c1 e8 20          	shr    $0x20,%rax
    6dec:	48 39 f0             	cmp    %rsi,%rax
    6def:	73 1f                	jae    6e10 <fwp_drop4+0x120>
    6df1:	48 01 c1             	add    %rax,%rcx
    6df4:	0f b6 01             	movzbl (%rcx),%eax
    6df7:	84 c0                	test   %al,%al
    6df9:	74 15                	je     6e10 <fwp_drop4+0x120>
    6dfb:	3c 01                	cmp    $0x1,%al
    6dfd:	74 59                	je     6e58 <fwp_drop4+0x168>
    6dff:	3c ff                	cmp    $0xff,%al
    6e01:	0f 84 ff 00 00 00    	je     6f06 <fwp_drop4+0x216>
    6e07:	83 e8 01             	sub    $0x1,%eax
    6e0a:	88 01                	mov    %al,(%rcx)
    6e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e10:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6e14:	48 89 d7             	mov    %rdx,%rdi
    6e17:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e1b:	e8 40 f7 ff ff       	call   6560 <fwp_rc_free_obj>
    6e20:	4c 8d 05 b9 89 01 00 	lea    0x189b9(%rip),%r8        # 1f7e0 <fwp_heap>
    6e27:	48 8b 04 24          	mov    (%rsp),%rax
    6e2b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6e32:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6e39:	48 c1 e2 10          	shl    $0x10,%rdx
    6e3d:	48 39 d0             	cmp    %rdx,%rax
    6e40:	0f 83 35 ff ff ff    	jae    6d7b <fwp_drop4+0x8b>
    6e46:	48 8b 14 24          	mov    (%rsp),%rdx
    6e4a:	e9 cd fe ff ff       	jmp    6d1c <fwp_drop4+0x2c>
    6e4f:	90                   	nop
    6e50:	c3                   	ret
    6e51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e58:	48 89 14 24          	mov    %rdx,(%rsp)
    6e5c:	e8 ff f6 ff ff       	call   6560 <fwp_rc_free_obj>
    6e61:	48 8b 14 24          	mov    (%rsp),%rdx
    6e65:	eb a9                	jmp    6e10 <fwp_drop4+0x120>
    6e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e6e:	00 00 
    6e70:	66 85 c0             	test   %ax,%ax
    6e73:	75 9b                	jne    6e10 <fwp_drop4+0x120>
    6e75:	e9 7a ff ff ff       	jmp    6df4 <fwp_drop4+0x104>
    6e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e80:	48 89 c8             	mov    %rcx,%rax
    6e83:	48 c1 e8 11          	shr    $0x11,%rax
    6e87:	48 31 c8             	xor    %rcx,%rax
    6e8a:	48 89 c2             	mov    %rax,%rdx
    6e8d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e91:	48 31 d0             	xor    %rdx,%rax
    6e94:	0f b6 d0             	movzbl %al,%edx
    6e97:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6e9e:	00 
    6e9f:	48 85 c0             	test   %rax,%rax
    6ea2:	75 29                	jne    6ecd <fwp_drop4+0x1dd>
    6ea4:	e9 e3 00 00 00       	jmp    6f8c <fwp_drop4+0x29c>
    6ea9:	90                   	nop
    6eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6eb1:	00 00 00 00 
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 
    6ec0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	0f 84 bf 00 00 00    	je     6f8c <fwp_drop4+0x29c>
    6ecd:	48 89 c2             	mov    %rax,%rdx
    6ed0:	48 39 08             	cmp    %rcx,(%rax)
    6ed3:	75 eb                	jne    6ec0 <fwp_drop4+0x1d0>
    6ed5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6ed9:	48 83 ea 01          	sub    $0x1,%rdx
    6edd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ee1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ee8:	0f 85 8d fe ff ff    	jne    6d7b <fwp_drop4+0x8b>
    6eee:	48 89 cf             	mov    %rcx,%rdi
    6ef1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6ef5:	e8 b6 e6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6efa:	48 8b 0c 24          	mov    (%rsp),%rcx
    6efe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f01:	e9 75 fe ff ff       	jmp    6d7b <fwp_drop4+0x8b>
    6f06:	48 89 ce             	mov    %rcx,%rsi
    6f09:	48 c1 ee 11          	shr    $0x11,%rsi
    6f0d:	48 31 ce             	xor    %rcx,%rsi
    6f10:	48 89 f0             	mov    %rsi,%rax
    6f13:	48 c1 e8 09          	shr    $0x9,%rax
    6f17:	48 31 c6             	xor    %rax,%rsi
    6f1a:	40 0f b6 f6          	movzbl %sil,%esi
    6f1e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6f25:	00 
    6f26:	48 85 c0             	test   %rax,%rax
    6f29:	75 1e                	jne    6f49 <fwp_drop4+0x259>
    6f2b:	eb 5f                	jmp    6f8c <fwp_drop4+0x29c>
    6f2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f34:	00 
    6f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f3c:	00 00 00 00 
    6f40:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	74 43                	je     6f8c <fwp_drop4+0x29c>
    6f49:	48 89 c6             	mov    %rax,%rsi
    6f4c:	48 39 08             	cmp    %rcx,(%rax)
    6f4f:	75 ef                	jne    6f40 <fwp_drop4+0x250>
    6f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f55:	48 83 ee 01          	sub    $0x1,%rsi
    6f59:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6f5d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6f64:	0f 85 a6 fe ff ff    	jne    6e10 <fwp_drop4+0x120>
    6f6a:	48 89 cf             	mov    %rcx,%rdi
    6f6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f72:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f76:	e8 35 e6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6f7b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f7f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f84:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f87:	e9 84 fe ff ff       	jmp    6e10 <fwp_drop4+0x120>
    6f8c:	48 8d 3d d5 48 00 00 	lea    0x48d5(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    6f93:	e8 58 d4 ff ff       	call   43f0 <fwp_trap>
    6f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f9f:	00 

0000000000006fa0 <fwp_arg_drop37>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	85 f6                	test   %esi,%esi
    6fa6:	75 04                	jne    6fac <fwp_arg_drop37+0xc>
    6fa8:	85 d2                	test   %edx,%edx
    6faa:	75 04                	jne    6fb0 <fwp_arg_drop37+0x10>
    6fac:	c3                   	ret
    6fad:	0f 1f 00             	nopl   (%rax)
    6fb0:	48 8b 3f             	mov    (%rdi),%rdi
    6fb3:	e9 38 fd ff ff       	jmp    6cf0 <fwp_drop4>
    6fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fbf:	00 

0000000000006fc0 <fwp_task_dispose>:
    6fc0:	53                   	push   %rbx
    6fc1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6fc5:	0f 84 7b c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6fcb:	48 89 fb             	mov    %rdi,%rbx
    6fce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6fd3:	0f 85 6d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6fd9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6fdd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6fe4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6feb:	00 
    6fec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6ff0:	48 85 ff             	test   %rdi,%rdi
    6ff3:	74 07                	je     6ffc <fwp_task_dispose+0x3c>
    6ff5:	48 85 c0             	test   %rax,%rax
    6ff8:	74 02                	je     6ffc <fwp_task_dispose+0x3c>
    6ffa:	ff d0                	call   *%rax
    6ffc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7003:	e8 e8 e7 ff ff       	call   57f0 <fwp_mem_free>
    7008:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    700f:	00 00 00 00 
    7013:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7017:	74 6f                	je     7088 <fwp_task_dispose+0xc8>
    7019:	48 8b 15 98 9b 01 00 	mov    0x19b98(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7020:	48 89 d8             	mov    %rbx,%rax
    7023:	48 2b 05 66 9b 01 00 	sub    0x19b66(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    702a:	48 c1 e2 10          	shl    $0x10,%rdx
    702e:	48 39 d0             	cmp    %rdx,%rax
    7031:	73 4c                	jae    707f <fwp_task_dispose+0xbf>
    7033:	48 89 c2             	mov    %rax,%rdx
    7036:	48 c1 ea 10          	shr    $0x10,%rdx
    703a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    703e:	48 8b 15 93 9b 01 00 	mov    0x19b93(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    7045:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7049:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    704d:	48 85 c9             	test   %rcx,%rcx
    7050:	74 2d                	je     707f <fwp_task_dispose+0xbf>
    7052:	0f b6 32             	movzbl (%rdx),%esi
    7055:	40 80 fe 02          	cmp    $0x2,%sil
    7059:	74 3d                	je     7098 <fwp_task_dispose+0xd8>
    705b:	40 80 fe 01          	cmp    $0x1,%sil
    705f:	75 1e                	jne    707f <fwp_task_dispose+0xbf>
    7061:	8b 72 18             	mov    0x18(%rdx),%esi
    7064:	0f b7 c0             	movzwl %ax,%eax
    7067:	8b 52 1c             	mov    0x1c(%rdx),%edx
    706a:	48 0f af c6          	imul   %rsi,%rax
    706e:	48 c1 e8 20          	shr    $0x20,%rax
    7072:	48 39 d0             	cmp    %rdx,%rax
    7075:	73 08                	jae    707f <fwp_task_dispose+0xbf>
    7077:	48 01 c1             	add    %rax,%rcx
    707a:	80 39 01             	cmpb   $0x1,(%rcx)
    707d:	74 09                	je     7088 <fwp_task_dispose+0xc8>
    707f:	5b                   	pop    %rbx
    7080:	c3                   	ret
    7081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7088:	48 89 df             	mov    %rbx,%rdi
    708b:	5b                   	pop    %rbx
    708c:	e9 5f e7 ff ff       	jmp    57f0 <fwp_mem_free>
    7091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7098:	66 85 c0             	test   %ax,%ax
    709b:	74 dd                	je     707a <fwp_task_dispose+0xba>
    709d:	5b                   	pop    %rbx
    709e:	c3                   	ret
    709f:	90                   	nop

00000000000070a0 <fwp_free_zombie>:
    70a0:	48 8b 15 09 87 01 00 	mov    0x18709(%rip),%rdx        # 1f7b0 <fwp_zombie>
    70a7:	48 85 d2             	test   %rdx,%rdx
    70aa:	0f 84 98 00 00 00    	je     7148 <fwp_free_zombie+0xa8>
    70b0:	48 3b 15 09 87 01 00 	cmp    0x18709(%rip),%rdx        # 1f7c0 <fwp_cur>
    70b7:	0f 84 8b 00 00 00    	je     7148 <fwp_free_zombie+0xa8>
    70bd:	48 83 ec 18          	sub    $0x18,%rsp
    70c1:	48 63 05 bc 80 01 00 	movslq 0x180bc(%rip),%rax        # 1f184 <fwp_stack_pool_n>
    70c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    70cc:	83 f8 3f             	cmp    $0x3f,%eax
    70cf:	7f 7f                	jg     7150 <fwp_free_zombie+0xb0>
    70d1:	8d 48 01             	lea    0x1(%rax),%ecx
    70d4:	89 0d aa 80 01 00    	mov    %ecx,0x180aa(%rip)        # 1f184 <fwp_stack_pool_n>
    70da:	48 8d 0d bf 80 01 00 	lea    0x180bf(%rip),%rcx        # 1f1a0 <fwp_stack_pool>
    70e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    70e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    70ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    70f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    70fb:	48 85 c9             	test   %rcx,%rcx
    70fe:	0f 84 fc 00 00 00    	je     7200 <fwp_free_zombie+0x160>
    7104:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    710b:	48 85 c0             	test   %rax,%rax
    710e:	74 07                	je     7117 <fwp_free_zombie+0x77>
    7110:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7117:	8b 42 5c             	mov    0x5c(%rdx),%eax
    711a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    711e:	48 c7 05 87 86 01 00 	movq   $0x0,0x18687(%rip)        # 1f7b0 <fwp_zombie>
    7125:	00 00 00 00 
    7129:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7130:	85 c0                	test   %eax,%eax
    7132:	74 34                	je     7168 <fwp_free_zombie+0xc8>
    7134:	83 f8 01             	cmp    $0x1,%eax
    7137:	0f 84 b3 00 00 00    	je     71f0 <fwp_free_zombie+0x150>
    713d:	48 83 c4 18          	add    $0x18,%rsp
    7141:	c3                   	ret
    7142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7148:	c3                   	ret
    7149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7150:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7154:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7159:	e8 82 c4 ff ff       	call   35e0 <munmap@plt>
    715e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7163:	eb 80                	jmp    70e5 <fwp_free_zombie+0x45>
    7165:	0f 1f 00             	nopl   (%rax)
    7168:	48 8b 0d 49 9a 01 00 	mov    0x19a49(%rip),%rcx        # 20bb8 <fwp_heap+0x13d8>
    716f:	48 89 d0             	mov    %rdx,%rax
    7172:	48 2b 05 17 9a 01 00 	sub    0x19a17(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7179:	48 c1 e1 10          	shl    $0x10,%rcx
    717d:	48 39 c8             	cmp    %rcx,%rax
    7180:	73 bb                	jae    713d <fwp_free_zombie+0x9d>
    7182:	48 89 c1             	mov    %rax,%rcx
    7185:	48 c1 e9 10          	shr    $0x10,%rcx
    7189:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    718d:	48 8b 0d 44 9a 01 00 	mov    0x19a44(%rip),%rcx        # 20bd8 <fwp_heap+0x13f8>
    7194:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7198:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    719c:	48 85 c9             	test   %rcx,%rcx
    719f:	74 9c                	je     713d <fwp_free_zombie+0x9d>
    71a1:	0f b6 3e             	movzbl (%rsi),%edi
    71a4:	40 80 ff 02          	cmp    $0x2,%dil
    71a8:	74 66                	je     7210 <fwp_free_zombie+0x170>
    71aa:	40 80 ff 01          	cmp    $0x1,%dil
    71ae:	75 8d                	jne    713d <fwp_free_zombie+0x9d>
    71b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    71b3:	0f b7 c0             	movzwl %ax,%eax
    71b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71b9:	48 0f af c7          	imul   %rdi,%rax
    71bd:	48 c1 e8 20          	shr    $0x20,%rax
    71c1:	48 39 f0             	cmp    %rsi,%rax
    71c4:	0f 83 73 ff ff ff    	jae    713d <fwp_free_zombie+0x9d>
    71ca:	48 01 c1             	add    %rax,%rcx
    71cd:	0f b6 01             	movzbl (%rcx),%eax
    71d0:	84 c0                	test   %al,%al
    71d2:	0f 84 65 ff ff ff    	je     713d <fwp_free_zombie+0x9d>
    71d8:	3c 01                	cmp    $0x1,%al
    71da:	74 14                	je     71f0 <fwp_free_zombie+0x150>
    71dc:	3c ff                	cmp    $0xff,%al
    71de:	74 3b                	je     721b <fwp_free_zombie+0x17b>
    71e0:	83 e8 01             	sub    $0x1,%eax
    71e3:	88 01                	mov    %al,(%rcx)
    71e5:	e9 53 ff ff ff       	jmp    713d <fwp_free_zombie+0x9d>
    71ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71f0:	48 89 d7             	mov    %rdx,%rdi
    71f3:	48 83 c4 18          	add    $0x18,%rsp
    71f7:	e9 c4 fd ff ff       	jmp    6fc0 <fwp_task_dispose>
    71fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7200:	48 89 05 81 85 01 00 	mov    %rax,0x18581(%rip)        # 1f788 <fwp_tasks_active>
    7207:	e9 ff fe ff ff       	jmp    710b <fwp_free_zombie+0x6b>
    720c:	0f 1f 40 00          	nopl   0x0(%rax)
    7210:	66 85 c0             	test   %ax,%ax
    7213:	0f 85 24 ff ff ff    	jne    713d <fwp_free_zombie+0x9d>
    7219:	eb b2                	jmp    71cd <fwp_free_zombie+0x12d>
    721b:	48 89 ca             	mov    %rcx,%rdx
    721e:	48 8d 35 bb 85 01 00 	lea    0x185bb(%rip),%rsi        # 1f7e0 <fwp_heap>
    7225:	48 c1 ea 11          	shr    $0x11,%rdx
    7229:	48 31 ca             	xor    %rcx,%rdx
    722c:	48 89 d0             	mov    %rdx,%rax
    722f:	48 c1 e8 09          	shr    $0x9,%rax
    7233:	48 31 c2             	xor    %rax,%rdx
    7236:	0f b6 d2             	movzbl %dl,%edx
    7239:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7240:	00 
    7241:	48 85 c0             	test   %rax,%rax
    7244:	75 23                	jne    7269 <fwp_free_zombie+0x1c9>
    7246:	eb 5c                	jmp    72a4 <fwp_free_zombie+0x204>
    7248:	66 90                	xchg   %ax,%ax
    724a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7251:	00 00 00 00 
    7255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    725c:	00 00 00 00 
    7260:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	74 3b                	je     72a4 <fwp_free_zombie+0x204>
    7269:	48 89 c2             	mov    %rax,%rdx
    726c:	48 39 08             	cmp    %rcx,(%rax)
    726f:	75 ef                	jne    7260 <fwp_free_zombie+0x1c0>
    7271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7275:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    727d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7284:	0f 85 b3 fe ff ff    	jne    713d <fwp_free_zombie+0x9d>
    728a:	48 89 cf             	mov    %rcx,%rdi
    728d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7292:	e8 19 e3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7297:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    729c:	c6 01 fe             	movb   $0xfe,(%rcx)
    729f:	e9 99 fe ff ff       	jmp    713d <fwp_free_zombie+0x9d>
    72a4:	48 8d 3d bd 45 00 00 	lea    0x45bd(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    72ab:	e8 40 d1 ff ff       	call   43f0 <fwp_trap>

00000000000072b0 <fwp_block>:
    72b0:	48 83 ec 08          	sub    $0x8,%rsp
    72b4:	48 8b 05 ed 84 01 00 	mov    0x184ed(%rip),%rax        # 1f7a8 <fwp_ready_head>
    72bb:	48 85 c0             	test   %rax,%rax
    72be:	0f 84 1c 01 00 00    	je     73e0 <fwp_block+0x130>
    72c4:	90                   	nop
    72c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72cc:	00 00 00 00 
    72d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    72d7:	48 89 15 ca 84 01 00 	mov    %rdx,0x184ca(%rip)        # 1f7a8 <fwp_ready_head>
    72de:	48 85 d2             	test   %rdx,%rdx
    72e1:	0f 84 19 01 00 00    	je     7400 <fwp_block+0x150>
    72e7:	48 8b 15 d2 84 01 00 	mov    0x184d2(%rip),%rdx        # 1f7c0 <fwp_cur>
    72ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    72f2:	48 39 c2             	cmp    %rax,%rdx
    72f5:	0f 84 d5 00 00 00    	je     73d0 <fwp_block+0x120>
    72fb:	48 8b 0d 46 a1 01 00 	mov    0x1a146(%rip),%rcx        # 21448 <fwp_state_owners>
    7302:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7306:	48 89 05 b3 84 01 00 	mov    %rax,0x184b3(%rip)        # 1f7c0 <fwp_cur>
    730d:	f3 0f 7e 05 5b a1 01 	movq   0x1a15b(%rip),%xmm0        # 21470 <fwp_foreign_callbacks>
    7314:	00 
    7315:	0f 16 05 44 a1 01 00 	movhps 0x1a144(%rip),%xmm0        # 21460 <fwp_state>
    731c:	f3 0f 7e 0d 44 a1 01 	movq   0x1a144(%rip),%xmm1        # 21468 <fwp_handlers>
    7323:	00 
    7324:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    732b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7332:	0f 16 0d 3f a1 01 00 	movhps 0x1a13f(%rip),%xmm1        # 21478 <fwp_cleanups>
    7339:	f3 0f 7e 05 17 a1 01 	movq   0x1a117(%rip),%xmm0        # 21458 <fwp_state_len>
    7340:	00 
    7341:	0f 16 05 08 a1 01 00 	movhps 0x1a108(%rip),%xmm0        # 21450 <fwp_state_cap>
    7348:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    734f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7356:	48 8b 70 08          	mov    0x8(%rax),%rsi
    735a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7361:	48 89 0d 00 a1 01 00 	mov    %rcx,0x1a100(%rip)        # 21468 <fwp_handlers>
    7368:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    736f:	48 89 0d 02 a1 01 00 	mov    %rcx,0x1a102(%rip)        # 21478 <fwp_cleanups>
    7376:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    737d:	48 89 0d ec a0 01 00 	mov    %rcx,0x1a0ec(%rip)        # 21470 <fwp_foreign_callbacks>
    7384:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    738b:	48 89 0d ce a0 01 00 	mov    %rcx,0x1a0ce(%rip)        # 21460 <fwp_state>
    7392:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7399:	48 89 0d b8 a0 01 00 	mov    %rcx,0x1a0b8(%rip)        # 21458 <fwp_state_len>
    73a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    73a7:	48 89 0d a2 a0 01 00 	mov    %rcx,0x1a0a2(%rip)        # 21450 <fwp_state_cap>
    73ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    73b5:	48 89 0d 8c a0 01 00 	mov    %rcx,0x1a08c(%rip)        # 21448 <fwp_state_owners>
    73bc:	e8 cf c0 ff ff       	call   3490 <swapcontext@plt>
    73c1:	f3 0f 1e fa          	endbr64
    73c5:	e8 d6 fc ff ff       	call   70a0 <fwp_free_zombie>
    73ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73d0:	8b 05 aa 7d 01 00    	mov    0x17daa(%rip),%eax        # 1f180 <fwp_slice>
    73d6:	85 c0                	test   %eax,%eax
    73d8:	74 36                	je     7410 <fwp_block+0x160>
    73da:	48 83 c4 08          	add    $0x8,%rsp
    73de:	c3                   	ret
    73df:	90                   	nop
    73e0:	e8 1b de ff ff       	call   5200 <fwp_poll_events>
    73e5:	48 8b 05 bc 83 01 00 	mov    0x183bc(%rip),%rax        # 1f7a8 <fwp_ready_head>
    73ec:	48 85 c0             	test   %rax,%rax
    73ef:	0f 85 db fe ff ff    	jne    72d0 <fwp_block+0x20>
    73f5:	eb e9                	jmp    73e0 <fwp_block+0x130>
    73f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73fe:	00 00 
    7400:	48 c7 05 95 83 01 00 	movq   $0x0,0x18395(%rip)        # 1f7a0 <fwp_ready_tail>
    7407:	00 00 00 00 
    740b:	e9 d7 fe ff ff       	jmp    72e7 <fwp_block+0x37>
    7410:	48 8d 3d 6d 3d 00 00 	lea    0x3d6d(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    7417:	e8 84 bf ff ff       	call   33a0 <getenv@plt>
    741c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7421:	48 85 c0             	test   %rax,%rax
    7424:	74 05                	je     742b <fwp_block+0x17b>
    7426:	80 38 00             	cmpb   $0x0,(%rax)
    7429:	75 0b                	jne    7436 <fwp_block+0x186>
    742b:	89 15 4f 7d 01 00    	mov    %edx,0x17d4f(%rip)        # 1f180 <fwp_slice>
    7431:	48 83 c4 08          	add    $0x8,%rsp
    7435:	c3                   	ret
    7436:	ba 0a 00 00 00       	mov    $0xa,%edx
    743b:	31 f6                	xor    %esi,%esi
    743d:	48 89 c7             	mov    %rax,%rdi
    7440:	e8 0b c1 ff ff       	call   3550 <strtoll@plt>
    7445:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7449:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7450:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7455:	0f 46 d0             	cmovbe %eax,%edx
    7458:	eb d1                	jmp    742b <fwp_block+0x17b>
    745a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007460 <fwp_caps173>:
    7460:	f3 0f 1e fa          	endbr64
    7464:	85 f6                	test   %esi,%esi
    7466:	74 08                	je     7470 <fwp_caps173+0x10>
    7468:	c3                   	ret
    7469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7470:	48 8b 15 41 97 01 00 	mov    0x19741(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7477:	48 89 f8             	mov    %rdi,%rax
    747a:	48 2b 05 0f 97 01 00 	sub    0x1970f(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7481:	48 c1 e2 10          	shl    $0x10,%rdx
    7485:	48 39 d0             	cmp    %rdx,%rax
    7488:	73 de                	jae    7468 <fwp_caps173+0x8>
    748a:	48 89 c2             	mov    %rax,%rdx
    748d:	48 c1 ea 10          	shr    $0x10,%rdx
    7491:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7495:	48 8b 15 3c 97 01 00 	mov    0x1973c(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    749c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74a4:	48 85 c9             	test   %rcx,%rcx
    74a7:	74 bf                	je     7468 <fwp_caps173+0x8>
    74a9:	0f b6 32             	movzbl (%rdx),%esi
    74ac:	40 80 fe 02          	cmp    $0x2,%sil
    74b0:	74 2e                	je     74e0 <fwp_caps173+0x80>
    74b2:	40 80 fe 01          	cmp    $0x1,%sil
    74b6:	75 b0                	jne    7468 <fwp_caps173+0x8>
    74b8:	8b 72 18             	mov    0x18(%rdx),%esi
    74bb:	0f b7 c0             	movzwl %ax,%eax
    74be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74c1:	48 0f af c6          	imul   %rsi,%rax
    74c5:	48 c1 e8 20          	shr    $0x20,%rax
    74c9:	48 39 d0             	cmp    %rdx,%rax
    74cc:	73 9a                	jae    7468 <fwp_caps173+0x8>
    74ce:	48 01 c1             	add    %rax,%rcx
    74d1:	80 39 01             	cmpb   $0x1,(%rcx)
    74d4:	75 92                	jne    7468 <fwp_caps173+0x8>
    74d6:	e9 15 e3 ff ff       	jmp    57f0 <fwp_mem_free>
    74db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74e0:	66 85 c0             	test   %ax,%ax
    74e3:	74 ec                	je     74d1 <fwp_caps173+0x71>
    74e5:	c3                   	ret
    74e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    74ed:	00 00 00 

00000000000074f0 <fwp_args37>:
    74f0:	f3 0f 1e fa          	endbr64
    74f4:	85 d2                	test   %edx,%edx
    74f6:	74 04                	je     74fc <fwp_args37+0xc>
    74f8:	85 f6                	test   %esi,%esi
    74fa:	74 04                	je     7500 <fwp_args37+0x10>
    74fc:	c3                   	ret
    74fd:	0f 1f 00             	nopl   (%rax)
    7500:	48 8b 15 b1 96 01 00 	mov    0x196b1(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7507:	48 8b 07             	mov    (%rdi),%rax
    750a:	48 2b 05 7f 96 01 00 	sub    0x1967f(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7511:	48 c1 e2 10          	shl    $0x10,%rdx
    7515:	48 39 d0             	cmp    %rdx,%rax
    7518:	73 e2                	jae    74fc <fwp_args37+0xc>
    751a:	48 89 c2             	mov    %rax,%rdx
    751d:	48 c1 ea 10          	shr    $0x10,%rdx
    7521:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7525:	48 8b 15 ac 96 01 00 	mov    0x196ac(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    752c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7530:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7534:	48 85 ff             	test   %rdi,%rdi
    7537:	74 c3                	je     74fc <fwp_args37+0xc>
    7539:	0f b6 0a             	movzbl (%rdx),%ecx
    753c:	80 f9 02             	cmp    $0x2,%cl
    753f:	74 2f                	je     7570 <fwp_args37+0x80>
    7541:	80 f9 01             	cmp    $0x1,%cl
    7544:	75 b6                	jne    74fc <fwp_args37+0xc>
    7546:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7549:	0f b7 c0             	movzwl %ax,%eax
    754c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    754f:	48 0f af c1          	imul   %rcx,%rax
    7553:	48 c1 e8 20          	shr    $0x20,%rax
    7557:	48 39 d0             	cmp    %rdx,%rax
    755a:	73 a0                	jae    74fc <fwp_args37+0xc>
    755c:	48 01 c7             	add    %rax,%rdi
    755f:	0f b6 07             	movzbl (%rdi),%eax
    7562:	84 c0                	test   %al,%al
    7564:	74 96                	je     74fc <fwp_args37+0xc>
    7566:	3c fd                	cmp    $0xfd,%al
    7568:	77 0c                	ja     7576 <fwp_args37+0x86>
    756a:	83 c0 01             	add    $0x1,%eax
    756d:	88 07                	mov    %al,(%rdi)
    756f:	c3                   	ret
    7570:	66 85 c0             	test   %ax,%ax
    7573:	74 ea                	je     755f <fwp_args37+0x6f>
    7575:	c3                   	ret
    7576:	e9 15 df ff ff       	jmp    5490 <fwp_rc_wide_dup>
    757b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007580 <fwp_caps37>:
    7580:	f3 0f 1e fa          	endbr64
    7584:	48 83 ec 18          	sub    $0x18,%rsp
    7588:	8b 57 04             	mov    0x4(%rdi),%edx
    758b:	48 89 f8             	mov    %rdi,%rax
    758e:	85 d2                	test   %edx,%edx
    7590:	0f 84 9a 00 00 00    	je     7630 <fwp_caps37+0xb0>
    7596:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    759a:	85 f6                	test   %esi,%esi
    759c:	0f 85 9e 00 00 00    	jne    7640 <fwp_caps37+0xc0>
    75a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    75a7:	e8 44 f7 ff ff       	call   6cf0 <fwp_drop4>
    75ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    75b1:	48 8b 0d 00 96 01 00 	mov    0x19600(%rip),%rcx        # 20bb8 <fwp_heap+0x13d8>
    75b8:	48 89 c2             	mov    %rax,%rdx
    75bb:	48 2b 15 ce 95 01 00 	sub    0x195ce(%rip),%rdx        # 20b90 <fwp_heap+0x13b0>
    75c2:	48 c1 e1 10          	shl    $0x10,%rcx
    75c6:	48 39 ca             	cmp    %rcx,%rdx
    75c9:	73 6d                	jae    7638 <fwp_caps37+0xb8>
    75cb:	48 89 d1             	mov    %rdx,%rcx
    75ce:	48 c1 e9 10          	shr    $0x10,%rcx
    75d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75d6:	48 8b 0d fb 95 01 00 	mov    0x195fb(%rip),%rcx        # 20bd8 <fwp_heap+0x13f8>
    75dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    75e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    75e5:	48 85 f6             	test   %rsi,%rsi
    75e8:	74 4e                	je     7638 <fwp_caps37+0xb8>
    75ea:	0f b6 39             	movzbl (%rcx),%edi
    75ed:	40 80 ff 02          	cmp    $0x2,%dil
    75f1:	0f 84 b9 00 00 00    	je     76b0 <fwp_caps37+0x130>
    75f7:	40 80 ff 01          	cmp    $0x1,%dil
    75fb:	75 3b                	jne    7638 <fwp_caps37+0xb8>
    75fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7600:	0f b7 d2             	movzwl %dx,%edx
    7603:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7606:	48 0f af d7          	imul   %rdi,%rdx
    760a:	48 c1 ea 20          	shr    $0x20,%rdx
    760e:	48 39 ca             	cmp    %rcx,%rdx
    7611:	73 25                	jae    7638 <fwp_caps37+0xb8>
    7613:	48 01 d6             	add    %rdx,%rsi
    7616:	80 3e 01             	cmpb   $0x1,(%rsi)
    7619:	75 1d                	jne    7638 <fwp_caps37+0xb8>
    761b:	48 89 c7             	mov    %rax,%rdi
    761e:	48 83 c4 18          	add    $0x18,%rsp
    7622:	e9 c9 e1 ff ff       	jmp    57f0 <fwp_mem_free>
    7627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    762e:	00 00 
    7630:	85 f6                	test   %esi,%esi
    7632:	0f 84 79 ff ff ff    	je     75b1 <fwp_caps37+0x31>
    7638:	48 83 c4 18          	add    $0x18,%rsp
    763c:	c3                   	ret
    763d:	0f 1f 00             	nopl   (%rax)
    7640:	48 8b 05 71 95 01 00 	mov    0x19571(%rip),%rax        # 20bb8 <fwp_heap+0x13d8>
    7647:	48 2b 3d 42 95 01 00 	sub    0x19542(%rip),%rdi        # 20b90 <fwp_heap+0x13b0>
    764e:	48 c1 e0 10          	shl    $0x10,%rax
    7652:	48 39 c7             	cmp    %rax,%rdi
    7655:	73 e1                	jae    7638 <fwp_caps37+0xb8>
    7657:	48 89 f8             	mov    %rdi,%rax
    765a:	48 c1 e8 10          	shr    $0x10,%rax
    765e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7662:	48 8b 05 6f 95 01 00 	mov    0x1956f(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    7669:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    766d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7671:	48 85 c0             	test   %rax,%rax
    7674:	74 c2                	je     7638 <fwp_caps37+0xb8>
    7676:	0f b6 0a             	movzbl (%rdx),%ecx
    7679:	80 f9 02             	cmp    $0x2,%cl
    767c:	74 42                	je     76c0 <fwp_caps37+0x140>
    767e:	80 f9 01             	cmp    $0x1,%cl
    7681:	75 b5                	jne    7638 <fwp_caps37+0xb8>
    7683:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7686:	0f b7 ff             	movzwl %di,%edi
    7689:	8b 52 1c             	mov    0x1c(%rdx),%edx
    768c:	48 0f af f9          	imul   %rcx,%rdi
    7690:	48 c1 ef 20          	shr    $0x20,%rdi
    7694:	48 39 d7             	cmp    %rdx,%rdi
    7697:	73 9f                	jae    7638 <fwp_caps37+0xb8>
    7699:	48 01 f8             	add    %rdi,%rax
    769c:	0f b6 10             	movzbl (%rax),%edx
    769f:	84 d2                	test   %dl,%dl
    76a1:	74 95                	je     7638 <fwp_caps37+0xb8>
    76a3:	80 fa fd             	cmp    $0xfd,%dl
    76a6:	77 23                	ja     76cb <fwp_caps37+0x14b>
    76a8:	83 c2 01             	add    $0x1,%edx
    76ab:	88 10                	mov    %dl,(%rax)
    76ad:	eb 89                	jmp    7638 <fwp_caps37+0xb8>
    76af:	90                   	nop
    76b0:	66 85 d2             	test   %dx,%dx
    76b3:	0f 85 7f ff ff ff    	jne    7638 <fwp_caps37+0xb8>
    76b9:	e9 58 ff ff ff       	jmp    7616 <fwp_caps37+0x96>
    76be:	66 90                	xchg   %ax,%ax
    76c0:	66 85 ff             	test   %di,%di
    76c3:	0f 85 6f ff ff ff    	jne    7638 <fwp_caps37+0xb8>
    76c9:	eb d1                	jmp    769c <fwp_caps37+0x11c>
    76cb:	48 89 c7             	mov    %rax,%rdi
    76ce:	48 83 c4 18          	add    $0x18,%rsp
    76d2:	e9 b9 dd ff ff       	jmp    5490 <fwp_rc_wide_dup>
    76d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76de:	00 00 

00000000000076e0 <fwp_drop0>:
    76e0:	f3 0f 1e fa          	endbr64
    76e4:	48 8b 15 cd 94 01 00 	mov    0x194cd(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    76eb:	48 89 f8             	mov    %rdi,%rax
    76ee:	48 2b 05 9b 94 01 00 	sub    0x1949b(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    76f5:	48 c1 e2 10          	shl    $0x10,%rdx
    76f9:	48 39 d0             	cmp    %rdx,%rax
    76fc:	0f 83 36 01 00 00    	jae    7838 <fwp_drop0+0x158>
    7702:	48 83 ec 18          	sub    $0x18,%rsp
    7706:	48 8d 35 d3 80 01 00 	lea    0x180d3(%rip),%rsi        # 1f7e0 <fwp_heap>
    770d:	48 89 c2             	mov    %rax,%rdx
    7710:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7717:	48 c1 ea 10          	shr    $0x10,%rdx
    771b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    771f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7723:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7727:	48 85 d2             	test   %rdx,%rdx
    772a:	74 42                	je     776e <fwp_drop0+0x8e>
    772c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7730:	41 80 f8 02          	cmp    $0x2,%r8b
    7734:	74 42                	je     7778 <fwp_drop0+0x98>
    7736:	41 80 f8 01          	cmp    $0x1,%r8b
    773a:	75 32                	jne    776e <fwp_drop0+0x8e>
    773c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7740:	0f b7 c0             	movzwl %ax,%eax
    7743:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7746:	49 0f af c0          	imul   %r8,%rax
    774a:	48 c1 e8 20          	shr    $0x20,%rax
    774e:	48 39 c8             	cmp    %rcx,%rax
    7751:	73 1b                	jae    776e <fwp_drop0+0x8e>
    7753:	48 01 c2             	add    %rax,%rdx
    7756:	0f b6 02             	movzbl (%rdx),%eax
    7759:	84 c0                	test   %al,%al
    775b:	74 11                	je     776e <fwp_drop0+0x8e>
    775d:	3c 01                	cmp    $0x1,%al
    775f:	74 27                	je     7788 <fwp_drop0+0xa8>
    7761:	3c ff                	cmp    $0xff,%al
    7763:	0f 84 e7 00 00 00    	je     7850 <fwp_drop0+0x170>
    7769:	83 e8 01             	sub    $0x1,%eax
    776c:	88 02                	mov    %al,(%rdx)
    776e:	48 83 c4 18          	add    $0x18,%rsp
    7772:	c3                   	ret
    7773:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7778:	66 85 c0             	test   %ax,%ax
    777b:	74 d9                	je     7756 <fwp_drop0+0x76>
    777d:	48 83 c4 18          	add    $0x18,%rsp
    7781:	c3                   	ret
    7782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7788:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    778f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7796:	48 89 f8             	mov    %rdi,%rax
    7799:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    779d:	48 29 c8             	sub    %rcx,%rax
    77a0:	48 c1 e2 10          	shl    $0x10,%rdx
    77a4:	48 39 d0             	cmp    %rdx,%rax
    77a7:	73 71                	jae    781a <fwp_drop0+0x13a>
    77a9:	49 89 c2             	mov    %rax,%r10
    77ac:	49 c1 ea 10          	shr    $0x10,%r10
    77b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    77b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    77b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    77bc:	4d 85 d2             	test   %r10,%r10
    77bf:	74 59                	je     781a <fwp_drop0+0x13a>
    77c1:	45 0f b6 19          	movzbl (%r9),%r11d
    77c5:	41 80 fb 02          	cmp    $0x2,%r11b
    77c9:	74 75                	je     7840 <fwp_drop0+0x160>
    77cb:	41 80 fb 01          	cmp    $0x1,%r11b
    77cf:	75 49                	jne    781a <fwp_drop0+0x13a>
    77d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    77d5:	0f b7 c0             	movzwl %ax,%eax
    77d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    77dc:	49 0f af c3          	imul   %r11,%rax
    77e0:	48 c1 e8 20          	shr    $0x20,%rax
    77e4:	4c 39 c8             	cmp    %r9,%rax
    77e7:	73 31                	jae    781a <fwp_drop0+0x13a>
    77e9:	49 01 c2             	add    %rax,%r10
    77ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    77f0:	75 28                	jne    781a <fwp_drop0+0x13a>
    77f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    77f7:	e8 f4 df ff ff       	call   57f0 <fwp_mem_free>
    77fc:	48 8d 35 dd 7f 01 00 	lea    0x17fdd(%rip),%rsi        # 1f7e0 <fwp_heap>
    7803:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7808:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    780f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7816:	48 c1 e2 10          	shl    $0x10,%rdx
    781a:	4c 89 c0             	mov    %r8,%rax
    781d:	48 29 c8             	sub    %rcx,%rax
    7820:	48 39 d0             	cmp    %rdx,%rax
    7823:	0f 83 45 ff ff ff    	jae    776e <fwp_drop0+0x8e>
    7829:	4c 89 c7             	mov    %r8,%rdi
    782c:	e9 dc fe ff ff       	jmp    770d <fwp_drop0+0x2d>
    7831:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7838:	c3                   	ret
    7839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7840:	66 85 c0             	test   %ax,%ax
    7843:	75 d5                	jne    781a <fwp_drop0+0x13a>
    7845:	eb a5                	jmp    77ec <fwp_drop0+0x10c>
    7847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    784e:	00 00 
    7850:	48 89 d0             	mov    %rdx,%rax
    7853:	48 c1 e8 11          	shr    $0x11,%rax
    7857:	48 31 d0             	xor    %rdx,%rax
    785a:	48 89 c1             	mov    %rax,%rcx
    785d:	48 c1 e9 09          	shr    $0x9,%rcx
    7861:	48 31 c8             	xor    %rcx,%rax
    7864:	0f b6 c8             	movzbl %al,%ecx
    7867:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    786e:	00 
    786f:	48 85 c0             	test   %rax,%rax
    7872:	75 15                	jne    7889 <fwp_drop0+0x1a9>
    7874:	eb 4e                	jmp    78c4 <fwp_drop0+0x1e4>
    7876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    787d:	00 00 00 
    7880:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7884:	48 85 c0             	test   %rax,%rax
    7887:	74 3b                	je     78c4 <fwp_drop0+0x1e4>
    7889:	48 89 c1             	mov    %rax,%rcx
    788c:	48 39 10             	cmp    %rdx,(%rax)
    788f:	75 ef                	jne    7880 <fwp_drop0+0x1a0>
    7891:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7895:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7899:	48 89 48 08          	mov    %rcx,0x8(%rax)
    789d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    78a4:	0f 85 c4 fe ff ff    	jne    776e <fwp_drop0+0x8e>
    78aa:	48 89 d7             	mov    %rdx,%rdi
    78ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    78b2:	e8 f9 dc ff ff       	call   55b0 <fwp_rc_forget_slot>
    78b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    78bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    78bf:	e9 aa fe ff ff       	jmp    776e <fwp_drop0+0x8e>
    78c4:	48 8d 3d 9d 3f 00 00 	lea    0x3f9d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    78cb:	e8 20 cb ff ff       	call   43f0 <fwp_trap>

00000000000078d0 <fwp_drop1>:
    78d0:	f3 0f 1e fa          	endbr64
    78d4:	48 8b 15 dd 92 01 00 	mov    0x192dd(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    78db:	48 89 f8             	mov    %rdi,%rax
    78de:	48 2b 05 ab 92 01 00 	sub    0x192ab(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    78e5:	48 c1 e2 10          	shl    $0x10,%rdx
    78e9:	48 39 d0             	cmp    %rdx,%rax
    78ec:	0f 83 36 01 00 00    	jae    7a28 <fwp_drop1+0x158>
    78f2:	48 83 ec 18          	sub    $0x18,%rsp
    78f6:	48 8d 35 e3 7e 01 00 	lea    0x17ee3(%rip),%rsi        # 1f7e0 <fwp_heap>
    78fd:	48 89 c2             	mov    %rax,%rdx
    7900:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7907:	48 c1 ea 10          	shr    $0x10,%rdx
    790b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    790f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7913:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7917:	48 85 d2             	test   %rdx,%rdx
    791a:	74 42                	je     795e <fwp_drop1+0x8e>
    791c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7920:	41 80 f8 02          	cmp    $0x2,%r8b
    7924:	74 42                	je     7968 <fwp_drop1+0x98>
    7926:	41 80 f8 01          	cmp    $0x1,%r8b
    792a:	75 32                	jne    795e <fwp_drop1+0x8e>
    792c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7930:	0f b7 c0             	movzwl %ax,%eax
    7933:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7936:	49 0f af c0          	imul   %r8,%rax
    793a:	48 c1 e8 20          	shr    $0x20,%rax
    793e:	48 39 c8             	cmp    %rcx,%rax
    7941:	73 1b                	jae    795e <fwp_drop1+0x8e>
    7943:	48 01 c2             	add    %rax,%rdx
    7946:	0f b6 02             	movzbl (%rdx),%eax
    7949:	84 c0                	test   %al,%al
    794b:	74 11                	je     795e <fwp_drop1+0x8e>
    794d:	3c 01                	cmp    $0x1,%al
    794f:	74 27                	je     7978 <fwp_drop1+0xa8>
    7951:	3c ff                	cmp    $0xff,%al
    7953:	0f 84 e7 00 00 00    	je     7a40 <fwp_drop1+0x170>
    7959:	83 e8 01             	sub    $0x1,%eax
    795c:	88 02                	mov    %al,(%rdx)
    795e:	48 83 c4 18          	add    $0x18,%rsp
    7962:	c3                   	ret
    7963:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7968:	66 85 c0             	test   %ax,%ax
    796b:	74 d9                	je     7946 <fwp_drop1+0x76>
    796d:	48 83 c4 18          	add    $0x18,%rsp
    7971:	c3                   	ret
    7972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7978:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    797f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7986:	48 89 f8             	mov    %rdi,%rax
    7989:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    798d:	48 29 c8             	sub    %rcx,%rax
    7990:	48 c1 e2 10          	shl    $0x10,%rdx
    7994:	48 39 d0             	cmp    %rdx,%rax
    7997:	73 71                	jae    7a0a <fwp_drop1+0x13a>
    7999:	49 89 c2             	mov    %rax,%r10
    799c:	49 c1 ea 10          	shr    $0x10,%r10
    79a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    79a4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    79a8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    79ac:	4d 85 d2             	test   %r10,%r10
    79af:	74 59                	je     7a0a <fwp_drop1+0x13a>
    79b1:	45 0f b6 19          	movzbl (%r9),%r11d
    79b5:	41 80 fb 02          	cmp    $0x2,%r11b
    79b9:	74 75                	je     7a30 <fwp_drop1+0x160>
    79bb:	41 80 fb 01          	cmp    $0x1,%r11b
    79bf:	75 49                	jne    7a0a <fwp_drop1+0x13a>
    79c1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    79c5:	0f b7 c0             	movzwl %ax,%eax
    79c8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    79cc:	49 0f af c3          	imul   %r11,%rax
    79d0:	48 c1 e8 20          	shr    $0x20,%rax
    79d4:	4c 39 c8             	cmp    %r9,%rax
    79d7:	73 31                	jae    7a0a <fwp_drop1+0x13a>
    79d9:	49 01 c2             	add    %rax,%r10
    79dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79e0:	75 28                	jne    7a0a <fwp_drop1+0x13a>
    79e2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    79e7:	e8 04 de ff ff       	call   57f0 <fwp_mem_free>
    79ec:	48 8d 35 ed 7d 01 00 	lea    0x17ded(%rip),%rsi        # 1f7e0 <fwp_heap>
    79f3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    79f8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79ff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a06:	48 c1 e2 10          	shl    $0x10,%rdx
    7a0a:	4c 89 c0             	mov    %r8,%rax
    7a0d:	48 29 c8             	sub    %rcx,%rax
    7a10:	48 39 d0             	cmp    %rdx,%rax
    7a13:	0f 83 45 ff ff ff    	jae    795e <fwp_drop1+0x8e>
    7a19:	4c 89 c7             	mov    %r8,%rdi
    7a1c:	e9 dc fe ff ff       	jmp    78fd <fwp_drop1+0x2d>
    7a21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a28:	c3                   	ret
    7a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a30:	66 85 c0             	test   %ax,%ax
    7a33:	75 d5                	jne    7a0a <fwp_drop1+0x13a>
    7a35:	eb a5                	jmp    79dc <fwp_drop1+0x10c>
    7a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a3e:	00 00 
    7a40:	48 89 d0             	mov    %rdx,%rax
    7a43:	48 c1 e8 11          	shr    $0x11,%rax
    7a47:	48 31 d0             	xor    %rdx,%rax
    7a4a:	48 89 c1             	mov    %rax,%rcx
    7a4d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a51:	48 31 c8             	xor    %rcx,%rax
    7a54:	0f b6 c8             	movzbl %al,%ecx
    7a57:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a5e:	00 
    7a5f:	48 85 c0             	test   %rax,%rax
    7a62:	75 25                	jne    7a89 <fwp_drop1+0x1b9>
    7a64:	eb 5e                	jmp    7ac4 <fwp_drop1+0x1f4>
    7a66:	0f 1f 40 00          	nopl   0x0(%rax)
    7a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a71:	00 00 00 00 
    7a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a7c:	00 00 00 00 
    7a80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a84:	48 85 c0             	test   %rax,%rax
    7a87:	74 3b                	je     7ac4 <fwp_drop1+0x1f4>
    7a89:	48 89 c1             	mov    %rax,%rcx
    7a8c:	48 39 10             	cmp    %rdx,(%rax)
    7a8f:	75 ef                	jne    7a80 <fwp_drop1+0x1b0>
    7a91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7aa4:	0f 85 b4 fe ff ff    	jne    795e <fwp_drop1+0x8e>
    7aaa:	48 89 d7             	mov    %rdx,%rdi
    7aad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ab2:	e8 f9 da ff ff       	call   55b0 <fwp_rc_forget_slot>
    7ab7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7abc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7abf:	e9 9a fe ff ff       	jmp    795e <fwp_drop1+0x8e>
    7ac4:	48 8d 3d 9d 3d 00 00 	lea    0x3d9d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7acb:	e8 20 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007ad0 <fwp_drop10>:
    7ad0:	48 8b 0d e1 90 01 00 	mov    0x190e1(%rip),%rcx        # 20bb8 <fwp_heap+0x13d8>
    7ad7:	48 89 f8             	mov    %rdi,%rax
    7ada:	48 2b 05 af 90 01 00 	sub    0x190af(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7ae1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ae5:	48 39 c8             	cmp    %rcx,%rax
    7ae8:	0f 83 c2 01 00 00    	jae    7cb0 <fwp_drop10+0x1e0>
    7aee:	48 83 ec 18          	sub    $0x18,%rsp
    7af2:	48 89 fa             	mov    %rdi,%rdx
    7af5:	48 8d 35 e4 7c 01 00 	lea    0x17ce4(%rip),%rsi        # 1f7e0 <fwp_heap>
    7afc:	48 89 c1             	mov    %rax,%rcx
    7aff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7b06:	48 c1 e9 10          	shr    $0x10,%rcx
    7b0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7b12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7b16:	48 85 c9             	test   %rcx,%rcx
    7b19:	74 46                	je     7b61 <fwp_drop10+0x91>
    7b1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7b1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7b23:	0f 84 d7 00 00 00    	je     7c00 <fwp_drop10+0x130>
    7b29:	41 80 f9 01          	cmp    $0x1,%r9b
    7b2d:	75 32                	jne    7b61 <fwp_drop10+0x91>
    7b2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7b33:	0f b7 c0             	movzwl %ax,%eax
    7b36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7b39:	49 0f af c1          	imul   %r9,%rax
    7b3d:	48 c1 e8 20          	shr    $0x20,%rax
    7b41:	48 39 f8             	cmp    %rdi,%rax
    7b44:	73 1b                	jae    7b61 <fwp_drop10+0x91>
    7b46:	48 01 c1             	add    %rax,%rcx
    7b49:	0f b6 01             	movzbl (%rcx),%eax
    7b4c:	84 c0                	test   %al,%al
    7b4e:	74 11                	je     7b61 <fwp_drop10+0x91>
    7b50:	3c 01                	cmp    $0x1,%al
    7b52:	74 1c                	je     7b70 <fwp_drop10+0xa0>
    7b54:	3c ff                	cmp    $0xff,%al
    7b56:	0f 84 5c 01 00 00    	je     7cb8 <fwp_drop10+0x1e8>
    7b5c:	83 e8 01             	sub    $0x1,%eax
    7b5f:	88 01                	mov    %al,(%rcx)
    7b61:	48 83 c4 18          	add    $0x18,%rsp
    7b65:	c3                   	ret
    7b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b6d:	00 00 00 
    7b70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b7e:	48 89 d0             	mov    %rdx,%rax
    7b81:	49 89 d1             	mov    %rdx,%r9
    7b84:	48 c1 e1 10          	shl    $0x10,%rcx
    7b88:	48 29 f8             	sub    %rdi,%rax
    7b8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7b8f:	78 7f                	js     7c10 <fwp_drop10+0x140>
    7b91:	48 39 c8             	cmp    %rcx,%rax
    7b94:	73 cb                	jae    7b61 <fwp_drop10+0x91>
    7b96:	48 89 c1             	mov    %rax,%rcx
    7b99:	48 c1 e9 10          	shr    $0x10,%rcx
    7b9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ba1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7ba5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ba9:	48 85 f6             	test   %rsi,%rsi
    7bac:	74 b3                	je     7b61 <fwp_drop10+0x91>
    7bae:	0f b6 39             	movzbl (%rcx),%edi
    7bb1:	40 80 ff 02          	cmp    $0x2,%dil
    7bb5:	74 39                	je     7bf0 <fwp_drop10+0x120>
    7bb7:	40 80 ff 01          	cmp    $0x1,%dil
    7bbb:	75 a4                	jne    7b61 <fwp_drop10+0x91>
    7bbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7bc0:	0f b7 c0             	movzwl %ax,%eax
    7bc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7bc6:	48 0f af c7          	imul   %rdi,%rax
    7bca:	48 c1 e8 20          	shr    $0x20,%rax
    7bce:	48 39 c8             	cmp    %rcx,%rax
    7bd1:	73 8e                	jae    7b61 <fwp_drop10+0x91>
    7bd3:	48 01 c6             	add    %rax,%rsi
    7bd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bd9:	75 86                	jne    7b61 <fwp_drop10+0x91>
    7bdb:	48 89 d7             	mov    %rdx,%rdi
    7bde:	48 83 c4 18          	add    $0x18,%rsp
    7be2:	e9 09 dc ff ff       	jmp    57f0 <fwp_mem_free>
    7be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bee:	00 00 
    7bf0:	66 85 c0             	test   %ax,%ax
    7bf3:	74 e1                	je     7bd6 <fwp_drop10+0x106>
    7bf5:	48 83 c4 18          	add    $0x18,%rsp
    7bf9:	c3                   	ret
    7bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c00:	66 85 c0             	test   %ax,%ax
    7c03:	0f 84 40 ff ff ff    	je     7b49 <fwp_drop10+0x79>
    7c09:	48 83 c4 18          	add    $0x18,%rsp
    7c0d:	c3                   	ret
    7c0e:	66 90                	xchg   %ax,%ax
    7c10:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7c14:	48 39 c8             	cmp    %rcx,%rax
    7c17:	73 74                	jae    7c8d <fwp_drop10+0x1bd>
    7c19:	49 89 c2             	mov    %rax,%r10
    7c1c:	49 c1 ea 10          	shr    $0x10,%r10
    7c20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c24:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7c28:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7c2c:	4d 85 d2             	test   %r10,%r10
    7c2f:	74 5c                	je     7c8d <fwp_drop10+0x1bd>
    7c31:	45 0f b6 18          	movzbl (%r8),%r11d
    7c35:	41 80 fb 02          	cmp    $0x2,%r11b
    7c39:	74 6d                	je     7ca8 <fwp_drop10+0x1d8>
    7c3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c3f:	75 4c                	jne    7c8d <fwp_drop10+0x1bd>
    7c41:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7c45:	0f b7 c0             	movzwl %ax,%eax
    7c48:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7c4c:	49 0f af c3          	imul   %r11,%rax
    7c50:	48 c1 e8 20          	shr    $0x20,%rax
    7c54:	4c 39 c0             	cmp    %r8,%rax
    7c57:	73 34                	jae    7c8d <fwp_drop10+0x1bd>
    7c59:	49 01 c2             	add    %rax,%r10
    7c5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c60:	75 2b                	jne    7c8d <fwp_drop10+0x1bd>
    7c62:	4c 89 cf             	mov    %r9,%rdi
    7c65:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c6a:	e8 81 db ff ff       	call   57f0 <fwp_mem_free>
    7c6f:	48 8d 35 6a 7b 01 00 	lea    0x17b6a(%rip),%rsi        # 1f7e0 <fwp_heap>
    7c76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c7b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c82:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c89:	48 c1 e1 10          	shl    $0x10,%rcx
    7c8d:	48 89 d0             	mov    %rdx,%rax
    7c90:	48 29 f8             	sub    %rdi,%rax
    7c93:	48 39 c8             	cmp    %rcx,%rax
    7c96:	0f 82 60 fe ff ff    	jb     7afc <fwp_drop10+0x2c>
    7c9c:	e9 c0 fe ff ff       	jmp    7b61 <fwp_drop10+0x91>
    7ca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ca8:	66 85 c0             	test   %ax,%ax
    7cab:	75 e0                	jne    7c8d <fwp_drop10+0x1bd>
    7cad:	eb ad                	jmp    7c5c <fwp_drop10+0x18c>
    7caf:	90                   	nop
    7cb0:	c3                   	ret
    7cb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cb8:	48 89 c8             	mov    %rcx,%rax
    7cbb:	48 c1 e8 11          	shr    $0x11,%rax
    7cbf:	48 31 c8             	xor    %rcx,%rax
    7cc2:	48 89 c2             	mov    %rax,%rdx
    7cc5:	48 c1 ea 09          	shr    $0x9,%rdx
    7cc9:	48 31 d0             	xor    %rdx,%rax
    7ccc:	0f b6 d0             	movzbl %al,%edx
    7ccf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7cd6:	00 
    7cd7:	48 85 c0             	test   %rax,%rax
    7cda:	75 0d                	jne    7ce9 <fwp_drop10+0x219>
    7cdc:	eb 46                	jmp    7d24 <fwp_drop10+0x254>
    7cde:	66 90                	xchg   %ax,%ax
    7ce0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ce4:	48 85 c0             	test   %rax,%rax
    7ce7:	74 3b                	je     7d24 <fwp_drop10+0x254>
    7ce9:	48 89 c2             	mov    %rax,%rdx
    7cec:	48 39 08             	cmp    %rcx,(%rax)
    7cef:	75 ef                	jne    7ce0 <fwp_drop10+0x210>
    7cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cf5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7cf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7cfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d04:	0f 85 57 fe ff ff    	jne    7b61 <fwp_drop10+0x91>
    7d0a:	48 89 cf             	mov    %rcx,%rdi
    7d0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7d12:	e8 99 d8 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7d17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7d1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d1f:	e9 3d fe ff ff       	jmp    7b61 <fwp_drop10+0x91>
    7d24:	48 8d 3d 3d 3b 00 00 	lea    0x3b3d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7d2b:	e8 c0 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007d30 <f37>:
    7d30:	41 57                	push   %r15
    7d32:	41 56                	push   %r14
    7d34:	41 55                	push   %r13
    7d36:	41 54                	push   %r12
    7d38:	55                   	push   %rbp
    7d39:	53                   	push   %rbx
    7d3a:	48 83 ec 38          	sub    $0x38,%rsp
    7d3e:	48 8b 15 73 8e 01 00 	mov    0x18e73(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7d45:	48 8b 0d 44 8e 01 00 	mov    0x18e44(%rip),%rcx        # 20b90 <fwp_heap+0x13b0>
    7d4c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7d53:	00 00 
    7d55:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7d5a:	49 89 fc             	mov    %rdi,%r12
    7d5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d61:	48 85 ff             	test   %rdi,%rdi
    7d64:	0f 84 bc 02 00 00    	je     8026 <f37+0x2f6>
    7d6a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7d6f:	48 89 d8             	mov    %rbx,%rax
    7d72:	48 29 c8             	sub    %rcx,%rax
    7d75:	48 39 d0             	cmp    %rdx,%rax
    7d78:	0f 83 72 03 00 00    	jae    80f0 <f37+0x3c0>
    7d7e:	48 89 c2             	mov    %rax,%rdx
    7d81:	48 c1 ea 10          	shr    $0x10,%rdx
    7d85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d89:	48 8b 15 48 8e 01 00 	mov    0x18e48(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    7d90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d94:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d98:	48 85 ff             	test   %rdi,%rdi
    7d9b:	0f 84 4f 03 00 00    	je     80f0 <f37+0x3c0>
    7da1:	0f b6 0a             	movzbl (%rdx),%ecx
    7da4:	80 f9 02             	cmp    $0x2,%cl
    7da7:	0f 84 53 02 00 00    	je     8000 <f37+0x2d0>
    7dad:	80 f9 01             	cmp    $0x1,%cl
    7db0:	75 24                	jne    7dd6 <f37+0xa6>
    7db2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7db5:	0f b7 c0             	movzwl %ax,%eax
    7db8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dbb:	48 0f af c1          	imul   %rcx,%rax
    7dbf:	48 c1 e8 20          	shr    $0x20,%rax
    7dc3:	48 39 d0             	cmp    %rdx,%rax
    7dc6:	73 0e                	jae    7dd6 <f37+0xa6>
    7dc8:	48 01 c7             	add    %rax,%rdi
    7dcb:	0f b6 07             	movzbl (%rdi),%eax
    7dce:	84 c0                	test   %al,%al
    7dd0:	0f 85 ca 02 00 00    	jne    80a0 <f37+0x370>
    7dd6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7ddb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7de0:	ba 01 00 00 00       	mov    $0x1,%edx
    7de5:	48 85 db             	test   %rbx,%rbx
    7de8:	74 13                	je     7dfd <f37+0xcd>
    7dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7df0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7df4:	48 83 c2 01          	add    $0x1,%rdx
    7df8:	48 85 db             	test   %rbx,%rbx
    7dfb:	75 f3                	jne    7df0 <f37+0xc0>
    7dfd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e02:	48 85 c0             	test   %rax,%rax
    7e05:	0f 84 15 03 00 00    	je     8120 <f37+0x3f0>
    7e0b:	31 db                	xor    %ebx,%ebx
    7e0d:	0f 1f 00             	nopl   (%rax)
    7e10:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e14:	48 83 c3 01          	add    $0x1,%rbx
    7e18:	48 85 c0             	test   %rax,%rax
    7e1b:	75 f3                	jne    7e10 <f37+0xe0>
    7e1d:	48 39 d3             	cmp    %rdx,%rbx
    7e20:	48 0f 47 da          	cmova  %rdx,%rbx
    7e24:	48 89 d8             	mov    %rbx,%rax
    7e27:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e2b:	0f 85 8f 03 00 00    	jne    81c0 <f37+0x490>
    7e31:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7e35:	be 02 00 00 00       	mov    $0x2,%esi
    7e3a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e41:	00 
    7e42:	e8 a9 de ff ff       	call   5cf0 <fwp_heap_alloc>
    7e47:	48 89 28             	mov    %rbp,(%rax)
    7e4a:	48 8b 15 67 8d 01 00 	mov    0x18d67(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7e51:	49 89 c6             	mov    %rax,%r14
    7e54:	48 2b 05 35 8d 01 00 	sub    0x18d35(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7e5b:	48 c1 e2 10          	shl    $0x10,%rdx
    7e5f:	48 39 d0             	cmp    %rdx,%rax
    7e62:	73 57                	jae    7ebb <f37+0x18b>
    7e64:	48 89 c2             	mov    %rax,%rdx
    7e67:	48 c1 ea 10          	shr    $0x10,%rdx
    7e6b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e6f:	48 8b 15 62 8d 01 00 	mov    0x18d62(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    7e76:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e7a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e7e:	48 85 ed             	test   %rbp,%rbp
    7e81:	74 38                	je     7ebb <f37+0x18b>
    7e83:	0f b6 0a             	movzbl (%rdx),%ecx
    7e86:	80 f9 02             	cmp    $0x2,%cl
    7e89:	0f 84 51 02 00 00    	je     80e0 <f37+0x3b0>
    7e8f:	80 f9 01             	cmp    $0x1,%cl
    7e92:	75 27                	jne    7ebb <f37+0x18b>
    7e94:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e97:	0f b7 c0             	movzwl %ax,%eax
    7e9a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e9d:	48 0f af c1          	imul   %rcx,%rax
    7ea1:	48 c1 e8 20          	shr    $0x20,%rax
    7ea5:	48 39 d0             	cmp    %rdx,%rax
    7ea8:	73 11                	jae    7ebb <f37+0x18b>
    7eaa:	48 01 c5             	add    %rax,%rbp
    7ead:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7eb1:	0f 84 d5 02 00 00    	je     818c <f37+0x45c>
    7eb7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7ebb:	48 85 db             	test   %rbx,%rbx
    7ebe:	74 5d                	je     7f1d <f37+0x1ed>
    7ec0:	48 c1 e3 04          	shl    $0x4,%rbx
    7ec4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7ec9:	4c 89 f5             	mov    %r14,%rbp
    7ecc:	4d 89 e5             	mov    %r12,%r13
    7ecf:	4c 01 f3             	add    %r14,%rbx
    7ed2:	0f 1f 00             	nopl   (%rax)
    7ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7edc:	00 00 00 00 
    7ee0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7ee4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ee8:	48 83 c5 10          	add    $0x10,%rbp
    7eec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7ef1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7ef5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7ef9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7efe:	e8 bd e3 ff ff       	call   62c0 <w120>
    7f03:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7f08:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7f0c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7f10:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7f14:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7f18:	48 39 dd             	cmp    %rbx,%rbp
    7f1b:	75 c3                	jne    7ee0 <f37+0x1b0>
    7f1d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f22:	e8 c9 ed ff ff       	call   6cf0 <fwp_drop4>
    7f27:	4c 89 e7             	mov    %r12,%rdi
    7f2a:	e8 c1 ed ff ff       	call   6cf0 <fwp_drop4>
    7f2f:	4c 89 f7             	mov    %r14,%rdi
    7f32:	e8 09 e5 ff ff       	call   6440 <w176.constprop.0>
    7f37:	4c 89 f7             	mov    %r14,%rdi
    7f3a:	48 89 c3             	mov    %rax,%rbx
    7f3d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f43:	e8 88 fb ff ff       	call   7ad0 <fwp_drop10>
    7f48:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f4e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7f53:	31 ff                	xor    %edi,%edi
    7f55:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f5a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7f5e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7f63:	e8 a8 de ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    7f68:	48 8b 15 49 8c 01 00 	mov    0x18c49(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    7f6f:	48 89 c5             	mov    %rax,%rbp
    7f72:	48 2b 05 17 8c 01 00 	sub    0x18c17(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    7f79:	48 c1 e2 10          	shl    $0x10,%rdx
    7f7d:	48 39 d0             	cmp    %rdx,%rax
    7f80:	73 55                	jae    7fd7 <f37+0x2a7>
    7f82:	48 89 c2             	mov    %rax,%rdx
    7f85:	48 c1 ea 10          	shr    $0x10,%rdx
    7f89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f8d:	48 8b 15 44 8c 01 00 	mov    0x18c44(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    7f94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f98:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7f9c:	48 85 db             	test   %rbx,%rbx
    7f9f:	74 36                	je     7fd7 <f37+0x2a7>
    7fa1:	0f b6 0a             	movzbl (%rdx),%ecx
    7fa4:	80 f9 02             	cmp    $0x2,%cl
    7fa7:	0f 84 1b 01 00 00    	je     80c8 <f37+0x398>
    7fad:	80 f9 01             	cmp    $0x1,%cl
    7fb0:	75 25                	jne    7fd7 <f37+0x2a7>
    7fb2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fb5:	0f b7 c0             	movzwl %ax,%eax
    7fb8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fbb:	48 0f af c1          	imul   %rcx,%rax
    7fbf:	48 c1 e8 20          	shr    $0x20,%rax
    7fc3:	48 39 d0             	cmp    %rdx,%rax
    7fc6:	73 0f                	jae    7fd7 <f37+0x2a7>
    7fc8:	48 01 c3             	add    %rax,%rbx
    7fcb:	80 3b ff             	cmpb   $0xff,(%rbx)
    7fce:	0f 84 ab 01 00 00    	je     817f <f37+0x44f>
    7fd4:	c6 03 01             	movb   $0x1,(%rbx)
    7fd7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7fdc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7fe3:	00 00 
    7fe5:	0f 85 d0 01 00 00    	jne    81bb <f37+0x48b>
    7feb:	48 83 c4 38          	add    $0x38,%rsp
    7fef:	48 89 e8             	mov    %rbp,%rax
    7ff2:	5b                   	pop    %rbx
    7ff3:	5d                   	pop    %rbp
    7ff4:	41 5c                	pop    %r12
    7ff6:	41 5d                	pop    %r13
    7ff8:	41 5e                	pop    %r14
    7ffa:	41 5f                	pop    %r15
    7ffc:	c3                   	ret
    7ffd:	0f 1f 00             	nopl   (%rax)
    8000:	66 85 c0             	test   %ax,%ax
    8003:	0f 85 cd fd ff ff    	jne    7dd6 <f37+0xa6>
    8009:	0f b6 07             	movzbl (%rdi),%eax
    800c:	84 c0                	test   %al,%al
    800e:	0f 84 c2 fd ff ff    	je     7dd6 <f37+0xa6>
    8014:	3c fd                	cmp    $0xfd,%al
    8016:	0f 87 95 01 00 00    	ja     81b1 <f37+0x481>
    801c:	83 c0 01             	add    $0x1,%eax
    801f:	88 07                	mov    %al,(%rdi)
    8021:	e9 b0 fd ff ff       	jmp    7dd6 <f37+0xa6>
    8026:	48 f7 d9             	neg    %rcx
    8029:	48 39 d1             	cmp    %rdx,%rcx
    802c:	0f 83 ee 00 00 00    	jae    8120 <f37+0x3f0>
    8032:	48 89 c8             	mov    %rcx,%rax
    8035:	48 c1 e8 10          	shr    $0x10,%rax
    8039:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    803d:	48 8b 05 94 8b 01 00 	mov    0x18b94(%rip),%rax        # 20bd8 <fwp_heap+0x13f8>
    8044:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8048:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    804c:	48 85 ff             	test   %rdi,%rdi
    804f:	0f 84 cb 00 00 00    	je     8120 <f37+0x3f0>
    8055:	0f b6 02             	movzbl (%rdx),%eax
    8058:	3c 02                	cmp    $0x2,%al
    805a:	0f 84 9a 00 00 00    	je     80fa <f37+0x3ca>
    8060:	3c 01                	cmp    $0x1,%al
    8062:	0f 85 b8 00 00 00    	jne    8120 <f37+0x3f0>
    8068:	0f b7 c1             	movzwl %cx,%eax
    806b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    806e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8071:	48 0f af c1          	imul   %rcx,%rax
    8075:	48 c1 e8 20          	shr    $0x20,%rax
    8079:	48 39 d0             	cmp    %rdx,%rax
    807c:	0f 83 9e 00 00 00    	jae    8120 <f37+0x3f0>
    8082:	48 01 c7             	add    %rax,%rdi
    8085:	0f b6 07             	movzbl (%rdi),%eax
    8088:	84 c0                	test   %al,%al
    808a:	0f 84 90 00 00 00    	je     8120 <f37+0x3f0>
    8090:	31 db                	xor    %ebx,%ebx
    8092:	0f 1f 00             	nopl   (%rax)
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	3c fd                	cmp    $0xfd,%al
    80a2:	0f 87 f1 00 00 00    	ja     8199 <f37+0x469>
    80a8:	83 c0 01             	add    $0x1,%eax
    80ab:	88 07                	mov    %al,(%rdi)
    80ad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80b2:	31 d2                	xor    %edx,%edx
    80b4:	4d 85 e4             	test   %r12,%r12
    80b7:	0f 85 1e fd ff ff    	jne    7ddb <f37+0xab>
    80bd:	e9 3b fd ff ff       	jmp    7dfd <f37+0xcd>
    80c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80c8:	66 85 c0             	test   %ax,%ax
    80cb:	0f 85 06 ff ff ff    	jne    7fd7 <f37+0x2a7>
    80d1:	e9 f5 fe ff ff       	jmp    7fcb <f37+0x29b>
    80d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80dd:	00 00 00 
    80e0:	66 85 c0             	test   %ax,%ax
    80e3:	0f 85 d2 fd ff ff    	jne    7ebb <f37+0x18b>
    80e9:	e9 bf fd ff ff       	jmp    7ead <f37+0x17d>
    80ee:	66 90                	xchg   %ax,%ax
    80f0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80f5:	e9 e6 fc ff ff       	jmp    7de0 <f37+0xb0>
    80fa:	66 85 c9             	test   %cx,%cx
    80fd:	75 21                	jne    8120 <f37+0x3f0>
    80ff:	0f b6 07             	movzbl (%rdi),%eax
    8102:	84 c0                	test   %al,%al
    8104:	74 1a                	je     8120 <f37+0x3f0>
    8106:	3c fd                	cmp    $0xfd,%al
    8108:	0f 87 be 00 00 00    	ja     81cc <f37+0x49c>
    810e:	83 c0 01             	add    $0x1,%eax
    8111:	88 07                	mov    %al,(%rdi)
    8113:	66 90                	xchg   %ax,%ax
    8115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    811c:	00 00 00 00 
    8120:	be 02 00 00 00       	mov    $0x2,%esi
    8125:	bf 08 00 00 00       	mov    $0x8,%edi
    812a:	e8 c1 db ff ff       	call   5cf0 <fwp_heap_alloc>
    812f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8136:	48 8b 15 7b 8a 01 00 	mov    0x18a7b(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    813d:	49 89 c6             	mov    %rax,%r14
    8140:	48 2b 05 49 8a 01 00 	sub    0x18a49(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    8147:	48 c1 e2 10          	shl    $0x10,%rdx
    814b:	48 39 d0             	cmp    %rdx,%rax
    814e:	73 53                	jae    81a3 <f37+0x473>
    8150:	48 89 c2             	mov    %rax,%rdx
    8153:	48 c1 ea 10          	shr    $0x10,%rdx
    8157:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    815b:	48 8b 15 76 8a 01 00 	mov    0x18a76(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    8162:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8166:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    816a:	48 85 ed             	test   %rbp,%rbp
    816d:	74 34                	je     81a3 <f37+0x473>
    816f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8176:	00 00 
    8178:	31 db                	xor    %ebx,%ebx
    817a:	e9 04 fd ff ff       	jmp    7e83 <f37+0x153>
    817f:	48 89 df             	mov    %rbx,%rdi
    8182:	e8 29 d4 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8187:	e9 48 fe ff ff       	jmp    7fd4 <f37+0x2a4>
    818c:	48 89 ef             	mov    %rbp,%rdi
    818f:	e8 1c d4 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8194:	e9 1e fd ff ff       	jmp    7eb7 <f37+0x187>
    8199:	e8 f2 d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    819e:	e9 0a ff ff ff       	jmp    80ad <f37+0x37d>
    81a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    81aa:	00 00 
    81ac:	e9 6c fd ff ff       	jmp    7f1d <f37+0x1ed>
    81b1:	e8 da d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    81b6:	e9 1b fc ff ff       	jmp    7dd6 <f37+0xa6>
    81bb:	e8 a0 b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    81c0:	48 8d 3d c9 2f 00 00 	lea    0x2fc9(%rip),%rdi        # b190 <_IO_stdin_used+0x190>
    81c7:	e8 24 c2 ff ff       	call   43f0 <fwp_trap>
    81cc:	e8 bf d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    81d1:	e9 4a ff ff ff       	jmp    8120 <f37+0x3f0>
    81d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81dd:	00 00 00 

00000000000081e0 <fwp_owned_entry37>:
    81e0:	f3 0f 1e fa          	endbr64
    81e4:	48 8b 3f             	mov    (%rdi),%rdi
    81e7:	e9 44 fb ff ff       	jmp    7d30 <f37>
    81ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000081f0 <e37>:
    81f0:	f3 0f 1e fa          	endbr64
    81f4:	53                   	push   %rbx
    81f5:	48 8b 1f             	mov    (%rdi),%rbx
    81f8:	48 89 df             	mov    %rbx,%rdi
    81fb:	e8 e0 e2 ff ff       	call   64e0 <fwp_rc_share>
    8200:	48 89 df             	mov    %rbx,%rdi
    8203:	e8 28 fb ff ff       	call   7d30 <f37>
    8208:	48 89 c3             	mov    %rax,%rbx
    820b:	48 89 c7             	mov    %rax,%rdi
    820e:	e8 cd e2 ff ff       	call   64e0 <fwp_rc_share>
    8213:	48 89 d8             	mov    %rbx,%rax
    8216:	5b                   	pop    %rbx
    8217:	c3                   	ret
    8218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    821f:	00 

0000000000008220 <fwp_write>:
    8220:	41 57                	push   %r15
    8222:	41 56                	push   %r14
    8224:	41 55                	push   %r13
    8226:	41 54                	push   %r12
    8228:	55                   	push   %rbp
    8229:	53                   	push   %rbx
    822a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8231:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8238:	00 00 
    823a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8241:	00 
    8242:	49 89 d4             	mov    %rdx,%r12
    8245:	8b 12                	mov    (%rdx),%edx
    8247:	83 fa 19             	cmp    $0x19,%edx
    824a:	77 6a                	ja     82b6 <fwp_write+0x96>
    824c:	48 89 f5             	mov    %rsi,%rbp
    824f:	89 d0                	mov    %edx,%eax
    8251:	89 ce                	mov    %ecx,%esi
    8253:	48 89 fb             	mov    %rdi,%rbx
    8256:	48 8d 0d f3 37 00 00 	lea    0x37f3(%rip),%rcx        # ba50 <_IO_stdin_used+0xa50>
    825d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8261:	48 01 c8             	add    %rcx,%rax
    8264:	3e ff e0             	notrack jmp *%rax
    8267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    826e:	00 00 
    8270:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8274:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8278:	48 89 ca             	mov    %rcx,%rdx
    827b:	48 85 c9             	test   %rcx,%rcx
    827e:	0f 88 9c 0c 00 00    	js     8f20 <fwp_write+0xd00>
    8284:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    828b:	00 
    828c:	48 89 c6             	mov    %rax,%rsi
    828f:	4c 89 e7             	mov    %r12,%rdi
    8292:	e8 a9 b7 ff ff       	call   3a40 <fwp_fmt_u128>
    8297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    829e:	00 00 
    82a0:	4c 89 e7             	mov    %r12,%rdi
    82a3:	e8 a8 b1 ff ff       	call   3450 <strlen@plt>
    82a8:	4c 89 e6             	mov    %r12,%rsi
    82ab:	48 89 df             	mov    %rbx,%rdi
    82ae:	48 89 c2             	mov    %rax,%rdx
    82b1:	e8 5a bf ff ff       	call   4210 <buf_put>
    82b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82bd:	00 
    82be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82c5:	00 00 
    82c7:	0f 85 28 04 00 00    	jne    86f5 <fwp_write+0x4d5>
    82cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    82d4:	5b                   	pop    %rbx
    82d5:	5d                   	pop    %rbp
    82d6:	41 5c                	pop    %r12
    82d8:	41 5d                	pop    %r13
    82da:	41 5e                	pop    %r14
    82dc:	41 5f                	pop    %r15
    82de:	c3                   	ret
    82df:	90                   	nop
    82e0:	49 89 e9             	mov    %rbp,%r9
    82e3:	4c 8d 05 8b 2d 00 00 	lea    0x2d8b(%rip),%r8        # b075 <_IO_stdin_used+0x75>
    82ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    82ef:	ba 02 00 00 00       	mov    $0x2,%edx
    82f4:	be 00 02 00 00       	mov    $0x200,%esi
    82f9:	31 c0                	xor    %eax,%eax
    82fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8302:	00 
    8303:	e8 a8 b0 ff ff       	call   33b0 <__snprintf_chk@plt>
    8308:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    830f:	00 
    8310:	e8 3b b1 ff ff       	call   3450 <strlen@plt>
    8315:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    831c:	00 
    831d:	48 89 df             	mov    %rbx,%rdi
    8320:	48 89 c2             	mov    %rax,%rdx
    8323:	e8 e8 be ff ff       	call   4210 <buf_put>
    8328:	eb 8c                	jmp    82b6 <fwp_write+0x96>
    832a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8330:	49 89 e9             	mov    %rbp,%r9
    8333:	4c 8d 05 7b 2e 00 00 	lea    0x2e7b(%rip),%r8        # b1b5 <_IO_stdin_used+0x1b5>
    833a:	eb ae                	jmp    82ea <fwp_write+0xca>
    833c:	0f 1f 40 00          	nopl   0x0(%rax)
    8340:	83 fa 13             	cmp    $0x13,%edx
    8343:	48 8d 05 61 2e 00 00 	lea    0x2e61(%rip),%rax        # b1ab <_IO_stdin_used+0x1ab>
    834a:	48 8d 35 5f 2e 00 00 	lea    0x2e5f(%rip),%rsi        # b1b0 <_IO_stdin_used+0x1b0>
    8351:	ba 04 00 00 00       	mov    $0x4,%edx
    8356:	48 0f 44 f0          	cmove  %rax,%rsi
    835a:	45 31 ed             	xor    %r13d,%r13d
    835d:	e8 ae be ff ff       	call   4210 <buf_put>
    8362:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8367:	0f 84 a3 08 00 00    	je     8c10 <fwp_write+0x9f0>
    836d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8372:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8377:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    837c:	48 89 df             	mov    %rbx,%rdi
    837f:	49 0f 44 c5          	cmove  %r13,%rax
    8383:	31 c9                	xor    %ecx,%ecx
    8385:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    838a:	e8 91 fe ff ff       	call   8220 <fwp_write>
    838f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8394:	0f 84 6e 09 00 00    	je     8d08 <fwp_write+0xae8>
    839a:	49 83 c5 01          	add    $0x1,%r13
    839e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    83a2:	0f 83 68 08 00 00    	jae    8c10 <fwp_write+0x9f0>
    83a8:	ba 02 00 00 00       	mov    $0x2,%edx
    83ad:	48 8d 35 41 2e 00 00 	lea    0x2e41(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    83b4:	48 89 df             	mov    %rbx,%rdi
    83b7:	e8 54 be ff ff       	call   4210 <buf_put>
    83bc:	eb af                	jmp    836d <fwp_write+0x14d>
    83be:	66 90                	xchg   %ax,%ax
    83c0:	ba 06 00 00 00       	mov    $0x6,%edx
    83c5:	48 8d 35 02 2e 00 00 	lea    0x2e02(%rip),%rsi        # b1ce <_IO_stdin_used+0x1ce>
    83cc:	48 83 c5 10          	add    $0x10,%rbp
    83d0:	e8 3b be ff ff       	call   4210 <buf_put>
    83d5:	48 89 ef             	mov    %rbp,%rdi
    83d8:	e8 73 b0 ff ff       	call   3450 <strlen@plt>
    83dd:	48 89 ee             	mov    %rbp,%rsi
    83e0:	48 89 df             	mov    %rbx,%rdi
    83e3:	48 89 c2             	mov    %rax,%rdx
    83e6:	e8 25 be ff ff       	call   4210 <buf_put>
    83eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83f0:	ba 01 00 00 00       	mov    $0x1,%edx
    83f5:	48 89 df             	mov    %rbx,%rdi
    83f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83fd:	e8 0e be ff ff       	call   4210 <buf_put>
    8402:	e9 af fe ff ff       	jmp    82b6 <fwp_write+0x96>
    8407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    840e:	00 00 
    8410:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8417:	00 
    8418:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    841f:	00 00 
    8421:	0f 85 ce 02 00 00    	jne    86f5 <fwp_write+0x4d5>
    8427:	ba 0a 00 00 00       	mov    $0xa,%edx
    842c:	48 8d 35 87 2d 00 00 	lea    0x2d87(%rip),%rsi        # b1ba <_IO_stdin_used+0x1ba>
    8433:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    843a:	48 89 df             	mov    %rbx,%rdi
    843d:	5b                   	pop    %rbx
    843e:	5d                   	pop    %rbp
    843f:	41 5c                	pop    %r12
    8441:	41 5d                	pop    %r13
    8443:	41 5e                	pop    %r14
    8445:	41 5f                	pop    %r15
    8447:	e9 c4 bd ff ff       	jmp    4210 <buf_put>
    844c:	0f 1f 40 00          	nopl   0x0(%rax)
    8450:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8455:	4d 85 ed             	test   %r13,%r13
    8458:	0f 84 02 0c 00 00    	je     9060 <fwp_write+0xe40>
    845e:	48 8d 35 9d 2d 00 00 	lea    0x2d9d(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    8465:	4c 89 ef             	mov    %r13,%rdi
    8468:	e8 c3 b0 ff ff       	call   3530 <strcmp@plt>
    846d:	41 89 c1             	mov    %eax,%r9d
    8470:	85 c0                	test   %eax,%eax
    8472:	0f 84 6c 0c 00 00    	je     90e4 <fwp_write+0xec4>
    8478:	4c 89 ef             	mov    %r13,%rdi
    847b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8480:	e8 cb af ff ff       	call   3450 <strlen@plt>
    8485:	4c 89 ee             	mov    %r13,%rsi
    8488:	48 89 df             	mov    %rbx,%rdi
    848b:	48 89 c2             	mov    %rax,%rdx
    848e:	e8 7d bd ff ff       	call   4210 <buf_put>
    8493:	ba 01 00 00 00       	mov    $0x1,%edx
    8498:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    849d:	48 89 df             	mov    %rbx,%rdi
    84a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    84a5:	e8 66 bd ff ff       	call   4210 <buf_put>
    84aa:	ba 01 00 00 00       	mov    $0x1,%edx
    84af:	4c 89 fe             	mov    %r15,%rsi
    84b2:	48 89 df             	mov    %rbx,%rdi
    84b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    84ba:	e8 51 bd ff ff       	call   4210 <buf_put>
    84bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    84c4:	45 31 f6             	xor    %r14d,%r14d
    84c7:	85 d2                	test   %edx,%edx
    84c9:	0f 8e 81 0a 00 00    	jle    8f50 <fwp_write+0xd30>
    84cf:	45 31 ed             	xor    %r13d,%r13d
    84d2:	4d 85 ed             	test   %r13,%r13
    84d5:	0f 85 75 07 00 00    	jne    8c50 <fwp_write+0xa30>
    84db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    84e2:	00 
    84e3:	45 85 f6             	test   %r14d,%r14d
    84e6:	0f 84 84 07 00 00    	je     8c70 <fwp_write+0xa50>
    84ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    84f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    84f6:	48 89 df             	mov    %rbx,%rdi
    84f9:	49 83 c5 01          	add    $0x1,%r13
    84fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8501:	31 c9                	xor    %ecx,%ecx
    8503:	e8 18 fd ff ff       	call   8220 <fwp_write>
    8508:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    850d:	7f c3                	jg     84d2 <fwp_write+0x2b2>
    850f:	45 85 f6             	test   %r14d,%r14d
    8512:	0f 84 38 0a 00 00    	je     8f50 <fwp_write+0xd30>
    8518:	b8 29 00 00 00       	mov    $0x29,%eax
    851d:	ba 01 00 00 00       	mov    $0x1,%edx
    8522:	4c 89 fe             	mov    %r15,%rsi
    8525:	48 89 df             	mov    %rbx,%rdi
    8528:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    852c:	e8 df bc ff ff       	call   4210 <buf_put>
    8531:	e9 80 fd ff ff       	jmp    82b6 <fwp_write+0x96>
    8536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    853d:	00 00 00 
    8540:	ba 01 00 00 00       	mov    $0x1,%edx
    8545:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    854a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    854f:	e8 bc bc ff ff       	call   4210 <buf_put>
    8554:	48 85 ed             	test   %rbp,%rbp
    8557:	0f 84 93 06 00 00    	je     8bf0 <fwp_write+0x9d0>
    855d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8561:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8566:	31 c9                	xor    %ecx,%ecx
    8568:	48 89 df             	mov    %rbx,%rdi
    856b:	e8 b0 fc ff ff       	call   8220 <fwp_write>
    8570:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8574:	48 85 ed             	test   %rbp,%rbp
    8577:	0f 84 73 06 00 00    	je     8bf0 <fwp_write+0x9d0>
    857d:	ba 02 00 00 00       	mov    $0x2,%edx
    8582:	48 8d 35 6c 2c 00 00 	lea    0x2c6c(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8589:	48 89 df             	mov    %rbx,%rdi
    858c:	e8 7f bc ff ff       	call   4210 <buf_put>
    8591:	eb ca                	jmp    855d <fwp_write+0x33d>
    8593:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8598:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    859c:	85 f6                	test   %esi,%esi
    859e:	0f 84 fc 07 00 00    	je     8da0 <fwp_write+0xb80>
    85a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    85ab:	00 
    85ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85b3:	00 00 
    85b5:	0f 85 3a 01 00 00    	jne    86f5 <fwp_write+0x4d5>
    85bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    85bf:	4c 89 ea             	mov    %r13,%rdx
    85c2:	e9 6c fe ff ff       	jmp    8433 <fwp_write+0x213>
    85c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ce:	00 00 
    85d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    85d5:	ba 01 00 00 00       	mov    $0x1,%edx
    85da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    85df:	48 89 ee             	mov    %rbp,%rsi
    85e2:	e8 29 bc ff ff       	call   4210 <buf_put>
    85e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    85ec:	4c 89 e7             	mov    %r12,%rdi
    85ef:	e8 5c ae ff ff       	call   3450 <strlen@plt>
    85f4:	4c 89 e6             	mov    %r12,%rsi
    85f7:	48 89 df             	mov    %rbx,%rdi
    85fa:	48 89 c2             	mov    %rax,%rdx
    85fd:	e8 0e bc ff ff       	call   4210 <buf_put>
    8602:	ba 01 00 00 00       	mov    $0x1,%edx
    8607:	48 89 ee             	mov    %rbp,%rsi
    860a:	48 89 df             	mov    %rbx,%rdi
    860d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8612:	e8 f9 bb ff ff       	call   4210 <buf_put>
    8617:	e9 9a fc ff ff       	jmp    82b6 <fwp_write+0x96>
    861c:	0f 1f 40 00          	nopl   0x0(%rax)
    8620:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8625:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8629:	0f 8a 8e 0b 00 00    	jp     91bd <fwp_write+0xf9d>
    862f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8633:	66 0f 54 05 25 35 00 	andpd  0x3525(%rip),%xmm0        # bb60 <msg.8+0xa0>
    863a:	00 
    863b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8640:	66 0f 2e 05 48 35 00 	ucomisd 0x3548(%rip),%xmm0        # bb90 <msg.8+0xd0>
    8647:	00 
    8648:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    864f:	00 
    8650:	0f 87 b2 09 00 00    	ja     9008 <fwp_write+0xde8>
    8656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    865d:	00 00 00 
    8660:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8664:	89 ee                	mov    %ebp,%esi
    8666:	4c 89 e7             	mov    %r12,%rdi
    8669:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    866e:	e8 9d c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8673:	31 f6                	xor    %esi,%esi
    8675:	4c 89 e7             	mov    %r12,%rdi
    8678:	e8 93 ad ff ff       	call   3410 <strtod@plt>
    867d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8682:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8686:	7a 06                	jp     868e <fwp_write+0x46e>
    8688:	0f 84 e9 01 00 00    	je     8877 <fwp_write+0x657>
    868e:	83 c5 01             	add    $0x1,%ebp
    8691:	83 fd 12             	cmp    $0x12,%ebp
    8694:	75 ca                	jne    8660 <fwp_write+0x440>
    8696:	be 11 00 00 00       	mov    $0x11,%esi
    869b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    869f:	4c 89 e7             	mov    %r12,%rdi
    86a2:	e8 69 c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    86a7:	e9 cb 01 00 00       	jmp    8877 <fwp_write+0x657>
    86ac:	0f 1f 40 00          	nopl   0x0(%rax)
    86b0:	48 83 fd 01          	cmp    $0x1,%rbp
    86b4:	0f 84 e6 08 00 00    	je     8fa0 <fwp_write+0xd80>
    86ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    86be:	b8 02 00 00 00       	mov    $0x2,%eax
    86c3:	ba 01 00 00 00       	mov    $0x1,%edx
    86c8:	48 0f 44 d0          	cmove  %rax,%rdx
    86cc:	48 8d 35 d0 2a 00 00 	lea    0x2ad0(%rip),%rsi        # b1a3 <_IO_stdin_used+0x1a3>
    86d3:	48 8d 05 ce 2a 00 00 	lea    0x2ace(%rip),%rax        # b1a8 <_IO_stdin_used+0x1a8>
    86da:	48 0f 44 f0          	cmove  %rax,%rsi
    86de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86e5:	00 
    86e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86ed:	00 00 
    86ef:	0f 84 3e fd ff ff    	je     8433 <fwp_write+0x213>
    86f5:	e8 66 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8700:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8705:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    870a:	e8 41 ba ff ff       	call   4150 <buf_grow>
    870f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8713:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8719:	4c 03 0b             	add    (%rbx),%r9
    871c:	66 45 89 11          	mov    %r10w,(%r9)
    8720:	45 85 e4             	test   %r12d,%r12d
    8723:	0f 8e 07 05 00 00    	jle    8c30 <fwp_write+0xa10>
    8729:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8730:	55 55 55 
    8733:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8738:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    873f:	aa aa aa 
    8742:	49 83 c1 01          	add    $0x1,%r9
    8746:	eb 45                	jmp    878d <fwp_write+0x56d>
    8748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    874f:	00 
    8750:	be 01 00 00 00       	mov    $0x1,%esi
    8755:	b8 2d 00 00 00       	mov    $0x2d,%eax
    875a:	88 07                	mov    %al,(%rdi)
    875c:	48 89 e8             	mov    %rbp,%rax
    875f:	49 f7 e8             	imul   %r8
    8762:	48 89 e8             	mov    %rbp,%rax
    8765:	48 c1 f8 3f          	sar    $0x3f,%rax
    8769:	48 29 c2             	sub    %rax,%rdx
    876c:	48 85 c9             	test   %rcx,%rcx
    876f:	0f 95 c0             	setne  %al
    8772:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8776:	48 83 ef 01          	sub    $0x1,%rdi
    877a:	48 21 c5             	and    %rax,%rbp
    877d:	48 29 ea             	sub    %rbp,%rdx
    8780:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8784:	49 39 f9             	cmp    %rdi,%r9
    8787:	0f 84 a3 04 00 00    	je     8c30 <fwp_write+0xa10>
    878d:	48 89 e8             	mov    %rbp,%rax
    8790:	49 f7 e8             	imul   %r8
    8793:	48 89 e8             	mov    %rbp,%rax
    8796:	48 c1 f8 3f          	sar    $0x3f,%rax
    879a:	48 89 d1             	mov    %rdx,%rcx
    879d:	48 29 c1             	sub    %rax,%rcx
    87a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    87a4:	48 89 e9             	mov    %rbp,%rcx
    87a7:	48 29 c1             	sub    %rax,%rcx
    87aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    87ae:	49 f7 e2             	mul    %r10
    87b1:	b8 30 00 00 00       	mov    $0x30,%eax
    87b6:	48 89 d6             	mov    %rdx,%rsi
    87b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    87bd:	48 d1 ee             	shr    $1,%rsi
    87c0:	48 01 f2             	add    %rsi,%rdx
    87c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    87c7:	48 29 d6             	sub    %rdx,%rsi
    87ca:	74 8e                	je     875a <fwp_write+0x53a>
    87cc:	48 83 fe 01          	cmp    $0x1,%rsi
    87d0:	0f 85 7a ff ff ff    	jne    8750 <fwp_write+0x530>
    87d6:	31 f6                	xor    %esi,%esi
    87d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    87dd:	e9 78 ff ff ff       	jmp    875a <fwp_write+0x53a>
    87e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87e8:	66 0f 6e cd          	movd   %ebp,%xmm1
    87ec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    87ef:	0f 8a c8 09 00 00    	jp     91bd <fwp_write+0xf9d>
    87f5:	0f 28 c1             	movaps %xmm1,%xmm0
    87f8:	0f 54 05 51 33 00 00 	andps  0x3351(%rip),%xmm0        # bb50 <msg.8+0x90>
    87ff:	0f 2e 05 fe 27 00 00 	ucomiss 0x27fe(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8806:	0f 87 24 08 00 00    	ja     9030 <fwp_write+0xe10>
    880c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8810:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8816:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    881d:	00 
    881e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8822:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    882e:	00 00 
    8830:	44 89 ee             	mov    %r13d,%esi
    8833:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8838:	4c 89 e7             	mov    %r12,%rdi
    883b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8840:	e8 cb be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8845:	31 f6                	xor    %esi,%esi
    8847:	4c 89 e7             	mov    %r12,%rdi
    884a:	e8 61 ac ff ff       	call   34b0 <strtof@plt>
    884f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8854:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8857:	7a 02                	jp     885b <fwp_write+0x63b>
    8859:	74 1c                	je     8877 <fwp_write+0x657>
    885b:	41 83 c5 01          	add    $0x1,%r13d
    885f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8863:	75 cb                	jne    8830 <fwp_write+0x610>
    8865:	be 09 00 00 00       	mov    $0x9,%esi
    886a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    886f:	4c 89 e7             	mov    %r12,%rdi
    8872:	e8 99 be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8877:	4c 89 e7             	mov    %r12,%rdi
    887a:	e8 01 bb ff ff       	call   4380 <fwp_finish_float>
    887f:	e9 1c fa ff ff       	jmp    82a0 <fwp_write+0x80>
    8884:	0f 1f 40 00          	nopl   0x0(%rax)
    8888:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    888c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8890:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8897:	00 
    8898:	48 89 ef             	mov    %rbp,%rdi
    889b:	e8 a0 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    88a0:	48 89 ef             	mov    %rbp,%rdi
    88a3:	e8 a8 ab ff ff       	call   3450 <strlen@plt>
    88a8:	48 89 ee             	mov    %rbp,%rsi
    88ab:	48 89 df             	mov    %rbx,%rdi
    88ae:	48 89 c2             	mov    %rax,%rdx
    88b1:	e8 5a b9 ff ff       	call   4210 <buf_put>
    88b6:	e9 fb f9 ff ff       	jmp    82b6 <fwp_write+0x96>
    88bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88c0:	ba 06 00 00 00       	mov    $0x6,%edx
    88c5:	48 8d 35 2c 29 00 00 	lea    0x292c(%rip),%rsi        # b1f8 <_IO_stdin_used+0x1f8>
    88cc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    88d2:	e8 39 b9 ff ff       	call   4210 <buf_put>
    88d7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88de:	ff ff 7f 
    88e1:	48 23 55 00          	and    0x0(%rbp),%rdx
    88e5:	0f 84 86 02 00 00    	je     8b71 <fwp_write+0x951>
    88eb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88f0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88f4:	48 85 d2             	test   %rdx,%rdx
    88f7:	0f 84 ae 00 00 00    	je     89ab <fwp_write+0x78b>
    88fd:	8b 0a                	mov    (%rdx),%ecx
    88ff:	83 f9 1c             	cmp    $0x1c,%ecx
    8902:	0f 84 58 06 00 00    	je     8f60 <fwp_write+0xd40>
    8908:	83 f9 1b             	cmp    $0x1b,%ecx
    890b:	0f 87 9a 00 00 00    	ja     89ab <fwp_write+0x78b>
    8911:	be 01 00 00 00       	mov    $0x1,%esi
    8916:	48 d3 e6             	shl    %cl,%rsi
    8919:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    891f:	0f 85 4b 04 00 00    	jne    8d70 <fwp_write+0xb50>
    8925:	f7 c6 84 04 00 00    	test   $0x484,%esi
    892b:	0f 85 0f 04 00 00    	jne    8d40 <fwp_write+0xb20>
    8931:	83 e6 21             	and    $0x21,%esi
    8934:	74 75                	je     89ab <fwp_write+0x78b>
    8936:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    893b:	48 85 ff             	test   %rdi,%rdi
    893e:	79 07                	jns    8947 <fwp_write+0x727>
    8940:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8944:	4c 01 ee             	add    %r13,%rsi
    8947:	48 0f be 3e          	movsbq (%rsi),%rdi
    894b:	85 c9                	test   %ecx,%ecx
    894d:	40 0f b6 f7          	movzbl %dil,%esi
    8951:	48 0f 44 f7          	cmove  %rdi,%rsi
    8955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    895c:	00 00 00 00 
    8960:	31 c9                	xor    %ecx,%ecx
    8962:	48 89 df             	mov    %rbx,%rdi
    8965:	49 83 c5 01          	add    $0x1,%r13
    8969:	e8 b2 f8 ff ff       	call   8220 <fwp_write>
    896e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8975:	ff ff 7f 
    8978:	48 23 55 00          	and    0x0(%rbp),%rdx
    897c:	49 39 d5             	cmp    %rdx,%r13
    897f:	0f 83 ec 01 00 00    	jae    8b71 <fwp_write+0x951>
    8985:	ba 02 00 00 00       	mov    $0x2,%edx
    898a:	48 89 df             	mov    %rbx,%rdi
    898d:	48 8d 35 61 28 00 00 	lea    0x2861(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8994:	e8 77 b8 ff ff       	call   4210 <buf_put>
    8999:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    899e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    89a2:	48 85 d2             	test   %rdx,%rdx
    89a5:	0f 85 52 ff ff ff    	jne    88fd <fwp_write+0x6dd>
    89ab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    89b0:	48 85 ff             	test   %rdi,%rdi
    89b3:	0f 88 cf 05 00 00    	js     8f88 <fwp_write+0xd68>
    89b9:	48 8b 31             	mov    (%rcx),%rsi
    89bc:	eb a2                	jmp    8960 <fwp_write+0x740>
    89be:	66 90                	xchg   %ax,%ax
    89c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89c7:	00 
    89c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89cf:	00 00 
    89d1:	0f 85 1e fd ff ff    	jne    86f5 <fwp_write+0x4d5>
    89d7:	ba 08 00 00 00       	mov    $0x8,%edx
    89dc:	48 8d 35 e2 27 00 00 	lea    0x27e2(%rip),%rsi        # b1c5 <_IO_stdin_used+0x1c5>
    89e3:	e9 4b fa ff ff       	jmp    8433 <fwp_write+0x213>
    89e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89ef:	00 
    89f0:	89 e8                	mov    %ebp,%eax
    89f2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    89f9:	76 03                	jbe    89fe <fwp_write+0x7de>
    89fb:	8b 45 00             	mov    0x0(%rbp),%eax
    89fe:	41 89 c6             	mov    %eax,%r14d
    8a01:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a06:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8a0b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8a0f:	4c 89 ef             	mov    %r13,%rdi
    8a12:	e8 39 aa ff ff       	call   3450 <strlen@plt>
    8a17:	4c 89 ee             	mov    %r13,%rsi
    8a1a:	48 89 df             	mov    %rbx,%rdi
    8a1d:	48 89 c2             	mov    %rax,%rdx
    8a20:	e8 eb b7 ff ff       	call   4210 <buf_put>
    8a25:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a2a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8a2e:	85 f6                	test   %esi,%esi
    8a30:	0f 8e 80 f8 ff ff    	jle    82b6 <fwp_write+0x96>
    8a36:	45 31 ed             	xor    %r13d,%r13d
    8a39:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a3e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8a43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a48:	ba 01 00 00 00       	mov    $0x1,%edx
    8a4d:	4c 89 fe             	mov    %r15,%rsi
    8a50:	48 89 04 24          	mov    %rax,(%rsp)
    8a54:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8a59:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8a5d:	48 89 df             	mov    %rbx,%rdi
    8a60:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8a64:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a69:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8a6e:	e8 9d b7 ff ff       	call   4210 <buf_put>
    8a73:	41 8b 06             	mov    (%r14),%eax
    8a76:	83 f8 0e             	cmp    $0xe,%eax
    8a79:	0f 84 71 02 00 00    	je     8cf0 <fwp_write+0xad0>
    8a7f:	83 f8 10             	cmp    $0x10,%eax
    8a82:	0f 84 38 02 00 00    	je     8cc0 <fwp_write+0xaa0>
    8a88:	83 f8 0a             	cmp    $0xa,%eax
    8a8b:	0f 84 7f 04 00 00    	je     8f10 <fwp_write+0xcf0>
    8a91:	0f 8f f9 00 00 00    	jg     8b90 <fwp_write+0x970>
    8a97:	83 f8 03             	cmp    $0x3,%eax
    8a9a:	0f 8f 50 04 00 00    	jg     8ef0 <fwp_write+0xcd0>
    8aa0:	85 c0                	test   %eax,%eax
    8aa2:	78 10                	js     8ab4 <fwp_write+0x894>
    8aa4:	48 8b 04 24          	mov    (%rsp),%rax
    8aa8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8aac:	85 c0                	test   %eax,%eax
    8aae:	0f 85 f9 00 00 00    	jne    8bad <fwp_write+0x98d>
    8ab4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8ab9:	48 8b 34 24          	mov    (%rsp),%rsi
    8abd:	31 c9                	xor    %ecx,%ecx
    8abf:	48 89 df             	mov    %rbx,%rdi
    8ac2:	e8 59 f7 ff ff       	call   8220 <fwp_write>
    8ac7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8acc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ad1:	49 83 c5 01          	add    $0x1,%r13
    8ad5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8ad9:	0f 8f 5f ff ff ff    	jg     8a3e <fwp_write+0x81e>
    8adf:	e9 d2 f7 ff ff       	jmp    82b6 <fwp_write+0x96>
    8ae4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ae8:	ba 06 00 00 00       	mov    $0x6,%edx
    8aed:	48 8d 35 f7 26 00 00 	lea    0x26f7(%rip),%rsi        # b1eb <_IO_stdin_used+0x1eb>
    8af4:	45 31 ed             	xor    %r13d,%r13d
    8af7:	e8 14 b7 ff ff       	call   4210 <buf_put>
    8afc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8b01:	75 19                	jne    8b1c <fwp_write+0x8fc>
    8b03:	eb 6c                	jmp    8b71 <fwp_write+0x951>
    8b05:	0f 1f 00             	nopl   (%rax)
    8b08:	ba 02 00 00 00       	mov    $0x2,%edx
    8b0d:	48 8d 35 e1 26 00 00 	lea    0x26e1(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8b14:	48 89 df             	mov    %rbx,%rdi
    8b17:	e8 f4 b6 ff ff       	call   4210 <buf_put>
    8b1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8b22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8b27:	31 c0                	xor    %eax,%eax
    8b29:	49 83 c5 01          	add    $0x1,%r13
    8b2d:	4c 8d 05 be 26 00 00 	lea    0x26be(%rip),%r8        # b1f2 <_IO_stdin_used+0x1f2>
    8b34:	ba 02 00 00 00       	mov    $0x2,%edx
    8b39:	be 00 02 00 00       	mov    $0x200,%esi
    8b3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b45:	00 
    8b46:	e8 65 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8b4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b52:	00 
    8b53:	e8 f8 a8 ff ff       	call   3450 <strlen@plt>
    8b58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8b5f:	00 
    8b60:	48 89 df             	mov    %rbx,%rdi
    8b63:	48 89 c2             	mov    %rax,%rdx
    8b66:	e8 a5 b6 ff ff       	call   4210 <buf_put>
    8b6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8b6f:	72 97                	jb     8b08 <fwp_write+0x8e8>
    8b71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b76:	ba 01 00 00 00       	mov    $0x1,%edx
    8b7b:	48 89 df             	mov    %rbx,%rdi
    8b7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b83:	e8 88 b6 ff ff       	call   4210 <buf_put>
    8b88:	e9 29 f7 ff ff       	jmp    82b6 <fwp_write+0x96>
    8b8d:	0f 1f 00             	nopl   (%rax)
    8b90:	83 f8 0b             	cmp    $0xb,%eax
    8b93:	0f 85 1b ff ff ff    	jne    8ab4 <fwp_write+0x894>
    8b99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8b9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8ba2:	83 e0 01             	and    $0x1,%eax
    8ba5:	85 c0                	test   %eax,%eax
    8ba7:	0f 84 07 ff ff ff    	je     8ab4 <fwp_write+0x894>
    8bad:	4c 89 fe             	mov    %r15,%rsi
    8bb0:	48 89 df             	mov    %rbx,%rdi
    8bb3:	ba 01 00 00 00       	mov    $0x1,%edx
    8bb8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8bbd:	e8 4e b6 ff ff       	call   4210 <buf_put>
    8bc2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8bc7:	48 8b 34 24          	mov    (%rsp),%rsi
    8bcb:	31 c9                	xor    %ecx,%ecx
    8bcd:	48 89 df             	mov    %rbx,%rdi
    8bd0:	e8 4b f6 ff ff       	call   8220 <fwp_write>
    8bd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8bda:	4c 89 fe             	mov    %r15,%rsi
    8bdd:	48 89 df             	mov    %rbx,%rdi
    8be0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8be5:	e8 26 b6 ff ff       	call   4210 <buf_put>
    8bea:	e9 d8 fe ff ff       	jmp    8ac7 <fwp_write+0x8a7>
    8bef:	90                   	nop
    8bf0:	ba 01 00 00 00       	mov    $0x1,%edx
    8bf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8bfa:	48 89 df             	mov    %rbx,%rdi
    8bfd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8c02:	e8 09 b6 ff ff       	call   4210 <buf_put>
    8c07:	e9 aa f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c15:	ba 01 00 00 00       	mov    $0x1,%edx
    8c1a:	48 89 df             	mov    %rbx,%rdi
    8c1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8c22:	e8 e9 b5 ff ff       	call   4210 <buf_put>
    8c27:	e9 8a f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8c34:	48 8b 13             	mov    (%rbx),%rdx
    8c37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8c3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8c40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8c44:	e9 6d f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c50:	ba 02 00 00 00       	mov    $0x2,%edx
    8c55:	48 8d 35 99 25 00 00 	lea    0x2599(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8c5c:	48 89 df             	mov    %rbx,%rdi
    8c5f:	e8 ac b5 ff ff       	call   4210 <buf_put>
    8c64:	e9 72 f8 ff ff       	jmp    84db <fwp_write+0x2bb>
    8c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8c7e:	48 89 f7             	mov    %rsi,%rdi
    8c81:	48 89 34 24          	mov    %rsi,(%rsp)
    8c85:	e8 c6 a7 ff ff       	call   3450 <strlen@plt>
    8c8a:	48 8b 34 24          	mov    (%rsp),%rsi
    8c8e:	48 89 df             	mov    %rbx,%rdi
    8c91:	48 89 c2             	mov    %rax,%rdx
    8c94:	e8 77 b5 ff ff       	call   4210 <buf_put>
    8c99:	ba 03 00 00 00       	mov    $0x3,%edx
    8c9e:	48 8d 35 73 25 00 00 	lea    0x2573(%rip),%rsi        # b218 <_IO_stdin_used+0x218>
    8ca5:	48 89 df             	mov    %rbx,%rdi
    8ca8:	e8 63 b5 ff ff       	call   4210 <buf_put>
    8cad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8cb2:	e9 35 f8 ff ff       	jmp    84ec <fwp_write+0x2cc>
    8cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cbe:	00 00 
    8cc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8cc5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8cc9:	48 85 ff             	test   %rdi,%rdi
    8ccc:	0f 84 e2 fd ff ff    	je     8ab4 <fwp_write+0x894>
    8cd2:	48 8d 35 29 25 00 00 	lea    0x2529(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    8cd9:	e8 52 a8 ff ff       	call   3530 <strcmp@plt>
    8cde:	85 c0                	test   %eax,%eax
    8ce0:	0f 95 c0             	setne  %al
    8ce3:	0f b6 c0             	movzbl %al,%eax
    8ce6:	e9 c1 fd ff ff       	jmp    8aac <fwp_write+0x88c>
    8ceb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cf0:	31 c0                	xor    %eax,%eax
    8cf2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8cf9:	00 
    8cfa:	0f 97 c0             	seta   %al
    8cfd:	e9 aa fd ff ff       	jmp    8aac <fwp_write+0x88c>
    8d02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d08:	48 89 df             	mov    %rbx,%rdi
    8d0b:	ba 02 00 00 00       	mov    $0x2,%edx
    8d10:	48 8d 35 e8 24 00 00 	lea    0x24e8(%rip),%rsi        # b1ff <_IO_stdin_used+0x1ff>
    8d17:	e8 f4 b4 ff ff       	call   4210 <buf_put>
    8d1c:	4c 89 e8             	mov    %r13,%rax
    8d1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8d24:	31 c9                	xor    %ecx,%ecx
    8d26:	48 c1 e0 04          	shl    $0x4,%rax
    8d2a:	48 89 df             	mov    %rbx,%rdi
    8d2d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8d32:	e8 e9 f4 ff ff       	call   8220 <fwp_write>
    8d37:	e9 5e f6 ff ff       	jmp    839a <fwp_write+0x17a>
    8d3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d40:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8d45:	48 85 ff             	test   %rdi,%rdi
    8d48:	79 0c                	jns    8d56 <fwp_write+0xb36>
    8d4a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8d51:	00 
    8d52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8d56:	48 63 3e             	movslq (%rsi),%rdi
    8d59:	83 f9 02             	cmp    $0x2,%ecx
    8d5c:	89 fe                	mov    %edi,%esi
    8d5e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d62:	e9 f9 fb ff ff       	jmp    8960 <fwp_write+0x740>
    8d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d6e:	00 00 
    8d70:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8d75:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8d7a:	48 85 ff             	test   %rdi,%rdi
    8d7d:	0f 88 0f 03 00 00    	js     9092 <fwp_write+0xe72>
    8d83:	49 0f bf 38          	movswq (%r8),%rdi
    8d87:	83 f9 01             	cmp    $0x1,%ecx
    8d8a:	0f b7 f7             	movzwl %di,%esi
    8d8d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d91:	e9 ca fb ff ff       	jmp    8960 <fwp_write+0x740>
    8d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d9d:	00 00 00 
    8da0:	ba 01 00 00 00       	mov    $0x1,%edx
    8da5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8daa:	48 83 c5 08          	add    $0x8,%rbp
    8dae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8db3:	e8 58 b4 ff ff       	call   4210 <buf_put>
    8db8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dbd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8dc2:	4d 85 ed             	test   %r13,%r13
    8dc5:	75 46                	jne    8e0d <fwp_write+0xbed>
    8dc7:	e9 04 01 00 00       	jmp    8ed0 <fwp_write+0xcb0>
    8dcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8dd0:	41 80 f9 09          	cmp    $0x9,%r9b
    8dd4:	0f 84 d6 00 00 00    	je     8eb0 <fwp_write+0xc90>
    8dda:	41 80 f9 0a          	cmp    $0xa,%r9b
    8dde:	0f 85 9c 00 00 00    	jne    8e80 <fwp_write+0xc60>
    8de4:	ba 02 00 00 00       	mov    $0x2,%edx
    8de9:	48 8d 35 eb 23 00 00 	lea    0x23eb(%rip),%rsi        # b1db <_IO_stdin_used+0x1db>
    8df0:	48 89 df             	mov    %rbx,%rdi
    8df3:	e8 18 b4 ff ff       	call   4210 <buf_put>
    8df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dff:	00 
    8e00:	48 83 c5 01          	add    $0x1,%rbp
    8e04:	49 39 ec             	cmp    %rbp,%r12
    8e07:	0f 84 c3 00 00 00    	je     8ed0 <fwp_write+0xcb0>
    8e0d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8e12:	41 80 f9 0d          	cmp    $0xd,%r9b
    8e16:	74 28                	je     8e40 <fwp_write+0xc20>
    8e18:	7e b6                	jle    8dd0 <fwp_write+0xbb0>
    8e1a:	41 80 f9 22          	cmp    $0x22,%r9b
    8e1e:	74 40                	je     8e60 <fwp_write+0xc40>
    8e20:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8e24:	75 5a                	jne    8e80 <fwp_write+0xc60>
    8e26:	ba 02 00 00 00       	mov    $0x2,%edx
    8e2b:	48 8d 35 a6 23 00 00 	lea    0x23a6(%rip),%rsi        # b1d8 <_IO_stdin_used+0x1d8>
    8e32:	48 89 df             	mov    %rbx,%rdi
    8e35:	e8 d6 b3 ff ff       	call   4210 <buf_put>
    8e3a:	eb c4                	jmp    8e00 <fwp_write+0xbe0>
    8e3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e40:	ba 02 00 00 00       	mov    $0x2,%edx
    8e45:	48 8d 35 95 23 00 00 	lea    0x2395(%rip),%rsi        # b1e1 <_IO_stdin_used+0x1e1>
    8e4c:	48 89 df             	mov    %rbx,%rdi
    8e4f:	e8 bc b3 ff ff       	call   4210 <buf_put>
    8e54:	eb aa                	jmp    8e00 <fwp_write+0xbe0>
    8e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e5d:	00 00 00 
    8e60:	ba 02 00 00 00       	mov    $0x2,%edx
    8e65:	48 8d 35 69 23 00 00 	lea    0x2369(%rip),%rsi        # b1d5 <_IO_stdin_used+0x1d5>
    8e6c:	48 89 df             	mov    %rbx,%rdi
    8e6f:	e8 9c b3 ff ff       	call   4210 <buf_put>
    8e74:	eb 8a                	jmp    8e00 <fwp_write+0xbe0>
    8e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e7d:	00 00 00 
    8e80:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8e84:	0f 86 2e 01 00 00    	jbe    8fb8 <fwp_write+0xd98>
    8e8a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8e8e:	0f 84 24 01 00 00    	je     8fb8 <fwp_write+0xd98>
    8e94:	ba 01 00 00 00       	mov    $0x1,%edx
    8e99:	4c 89 fe             	mov    %r15,%rsi
    8e9c:	48 89 df             	mov    %rbx,%rdi
    8e9f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8ea4:	e8 67 b3 ff ff       	call   4210 <buf_put>
    8ea9:	e9 52 ff ff ff       	jmp    8e00 <fwp_write+0xbe0>
    8eae:	66 90                	xchg   %ax,%ax
    8eb0:	ba 02 00 00 00       	mov    $0x2,%edx
    8eb5:	48 8d 35 22 23 00 00 	lea    0x2322(%rip),%rsi        # b1de <_IO_stdin_used+0x1de>
    8ebc:	48 89 df             	mov    %rbx,%rdi
    8ebf:	e8 4c b3 ff ff       	call   4210 <buf_put>
    8ec4:	e9 37 ff ff ff       	jmp    8e00 <fwp_write+0xbe0>
    8ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ed0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ed5:	4c 89 fe             	mov    %r15,%rsi
    8ed8:	48 89 df             	mov    %rbx,%rdi
    8edb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ee0:	e8 2b b3 ff ff       	call   4210 <buf_put>
    8ee5:	e9 cc f3 ff ff       	jmp    82b6 <fwp_write+0x96>
    8eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ef0:	83 f8 04             	cmp    $0x4,%eax
    8ef3:	0f 85 bb fb ff ff    	jne    8ab4 <fwp_write+0x894>
    8ef9:	48 8b 04 24          	mov    (%rsp),%rax
    8efd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8f01:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8f06:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f0a:	e9 96 fc ff ff       	jmp    8ba5 <fwp_write+0x985>
    8f0f:	90                   	nop
    8f10:	8b 0c 24             	mov    (%rsp),%ecx
    8f13:	31 c0                	xor    %eax,%eax
    8f15:	85 c9                	test   %ecx,%ecx
    8f17:	0f 98 c0             	sets   %al
    8f1a:	e9 86 fc ff ff       	jmp    8ba5 <fwp_write+0x985>
    8f1f:	90                   	nop
    8f20:	48 f7 d8             	neg    %rax
    8f23:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8f2a:	00 
    8f2b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8f32:	2d 
    8f33:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f3a:	00 
    8f3b:	48 83 d2 00          	adc    $0x0,%rdx
    8f3f:	48 89 c6             	mov    %rax,%rsi
    8f42:	48 f7 da             	neg    %rdx
    8f45:	e8 f6 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f4a:	e9 51 f3 ff ff       	jmp    82a0 <fwp_write+0x80>
    8f4f:	90                   	nop
    8f50:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8f55:	e9 c3 f5 ff ff       	jmp    851d <fwp_write+0x2fd>
    8f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f60:	4c 89 e9             	mov    %r13,%rcx
    8f63:	48 c1 e1 04          	shl    $0x4,%rcx
    8f67:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8f6c:	48 85 ff             	test   %rdi,%rdi
    8f6f:	0f 89 eb f9 ff ff    	jns    8960 <fwp_write+0x740>
    8f75:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f79:	48 89 ce             	mov    %rcx,%rsi
    8f7c:	e9 df f9 ff ff       	jmp    8960 <fwp_write+0x740>
    8f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f88:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f8f:	00 
    8f90:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f94:	e9 20 fa ff ff       	jmp    89b9 <fwp_write+0x799>
    8f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fa0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fa5:	48 8d 35 f9 21 00 00 	lea    0x21f9(%rip),%rsi        # b1a5 <_IO_stdin_used+0x1a5>
    8fac:	e9 2d f7 ff ff       	jmp    86de <fwp_write+0x4be>
    8fb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fb8:	4c 8d 05 25 22 00 00 	lea    0x2225(%rip),%r8        # b1e4 <_IO_stdin_used+0x1e4>
    8fbf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8fc4:	31 c0                	xor    %eax,%eax
    8fc6:	ba 02 00 00 00       	mov    $0x2,%edx
    8fcb:	be 10 00 00 00       	mov    $0x10,%esi
    8fd0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fd7:	00 
    8fd8:	e8 d3 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8fdd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fe4:	00 
    8fe5:	e8 66 a4 ff ff       	call   3450 <strlen@plt>
    8fea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8ff1:	00 
    8ff2:	48 89 df             	mov    %rbx,%rdi
    8ff5:	48 89 c2             	mov    %rax,%rdx
    8ff8:	e8 13 b2 ff ff       	call   4210 <buf_put>
    8ffd:	e9 fe fd ff ff       	jmp    8e00 <fwp_write+0xbe0>
    9002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9008:	66 0f ef c0          	pxor   %xmm0,%xmm0
    900c:	48 8d 35 8c 21 00 00 	lea    0x218c(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    9013:	48 8d 05 84 21 00 00 	lea    0x2184(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    901a:	4c 89 e7             	mov    %r12,%rdi
    901d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9021:	48 0f 46 f0          	cmovbe %rax,%rsi
    9025:	e8 c6 a3 ff ff       	call   33f0 <strcpy@plt>
    902a:	e9 71 f2 ff ff       	jmp    82a0 <fwp_write+0x80>
    902f:	90                   	nop
    9030:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9034:	48 8d 35 64 21 00 00 	lea    0x2164(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    903b:	48 8d 05 5c 21 00 00 	lea    0x215c(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    9042:	0f 2f c8             	comiss %xmm0,%xmm1
    9045:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    904c:	00 
    904d:	4c 89 e7             	mov    %r12,%rdi
    9050:	48 0f 46 f0          	cmovbe %rax,%rsi
    9054:	e8 97 a3 ff ff       	call   33f0 <strcpy@plt>
    9059:	e9 42 f2 ff ff       	jmp    82a0 <fwp_write+0x80>
    905e:	66 90                	xchg   %ax,%ax
    9060:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9065:	45 85 c0             	test   %r8d,%r8d
    9068:	75 34                	jne    909e <fwp_write+0xe7e>
    906a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9071:	00 
    9072:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9079:	00 00 
    907b:	0f 85 74 f6 ff ff    	jne    86f5 <fwp_write+0x4d5>
    9081:	ba 02 00 00 00       	mov    $0x2,%edx
    9086:	48 8d 35 88 21 00 00 	lea    0x2188(%rip),%rsi        # b215 <_IO_stdin_used+0x215>
    908d:	e9 a1 f3 ff ff       	jmp    8433 <fwp_write+0x213>
    9092:	48 03 75 10          	add    0x10(%rbp),%rsi
    9096:	49 89 f0             	mov    %rsi,%r8
    9099:	e9 e5 fc ff ff       	jmp    8d83 <fwp_write+0xb63>
    909e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    90a3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90a8:	85 ff                	test   %edi,%edi
    90aa:	0f 84 fa f3 ff ff    	je     84aa <fwp_write+0x28a>
    90b0:	ba 01 00 00 00       	mov    $0x1,%edx
    90b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90ba:	48 89 df             	mov    %rbx,%rdi
    90bd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    90c2:	e8 49 b1 ff ff       	call   4210 <buf_put>
    90c7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    90cc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90d1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    90d7:	85 c0                	test   %eax,%eax
    90d9:	0f 8f f0 f3 ff ff    	jg     84cf <fwp_write+0x2af>
    90df:	e9 34 f4 ff ff       	jmp    8518 <fwp_write+0x2f8>
    90e4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90e8:	49 89 c5             	mov    %rax,%r13
    90eb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    90f0:	49 89 c4             	mov    %rax,%r12
    90f3:	49 c1 fd 3f          	sar    $0x3f,%r13
    90f7:	4c 09 e8             	or     %r13,%rax
    90fa:	0f 84 a7 00 00 00    	je     91a7 <fwp_write+0xf87>
    9100:	48 8d 2d 99 41 00 00 	lea    0x4199(%rip),%rbp        # d2a0 <units.0>
    9107:	4d 89 e7             	mov    %r12,%r15
    910a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    910e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9113:	4c 89 ff             	mov    %r15,%rdi
    9116:	4c 89 ee             	mov    %r13,%rsi
    9119:	44 89 0c 24          	mov    %r9d,(%rsp)
    911d:	48 99                	cqto
    911f:	48 89 d1             	mov    %rdx,%rcx
    9122:	48 89 c2             	mov    %rax,%rdx
    9125:	e8 66 0f 00 00       	call   a090 <__divmodti4>
    912a:	44 8b 0c 24          	mov    (%rsp),%r9d
    912e:	48 89 c1             	mov    %rax,%rcx
    9131:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9136:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    913b:	0f 84 94 00 00 00    	je     91d5 <fwp_write+0xfb5>
    9141:	41 83 c1 01          	add    $0x1,%r9d
    9145:	48 83 c5 10          	add    $0x10,%rbp
    9149:	41 83 f9 05          	cmp    $0x5,%r9d
    914d:	75 bb                	jne    910a <fwp_write+0xeea>
    914f:	4d 85 ed             	test   %r13,%r13
    9152:	79 53                	jns    91a7 <fwp_write+0xf87>
    9154:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9159:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    915e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9163:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9168:	48 99                	cqto
    916a:	48 f7 d8             	neg    %rax
    916d:	48 83 d2 00          	adc    $0x0,%rdx
    9171:	48 89 c6             	mov    %rax,%rsi
    9174:	48 f7 da             	neg    %rdx
    9177:	e8 c4 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    917c:	49 89 e8             	mov    %rbp,%r8
    917f:	ba 00 02 00 00       	mov    $0x200,%edx
    9184:	be 02 00 00 00       	mov    $0x2,%esi
    9189:	31 c0                	xor    %eax,%eax
    918b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9192:	00 
    9193:	48 8d 0d 76 20 00 00 	lea    0x2076(%rip),%rcx        # b210 <_IO_stdin_used+0x210>
    919a:	4c 89 e7             	mov    %r12,%rdi
    919d:	e8 3e a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    91a2:	e9 f9 f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    91a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    91b1:	31 d2                	xor    %edx,%edx
    91b3:	48 89 ef             	mov    %rbp,%rdi
    91b6:	e8 85 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91bb:	eb bf                	jmp    917c <fwp_write+0xf5c>
    91bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    91c4:	4e 61 4e 00 
    91c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91cf:	00 
    91d0:	e9 cb f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    91d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    91d9:	48 89 c8             	mov    %rcx,%rax
    91dc:	48 85 d2             	test   %rdx,%rdx
    91df:	78 51                	js     9232 <fwp_write+0x1012>
    91e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91e6:	48 89 c6             	mov    %rax,%rsi
    91e9:	48 89 ef             	mov    %rbp,%rdi
    91ec:	e8 4f a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    91f5:	49 63 c1             	movslq %r9d,%rax
    91f8:	49 89 e8             	mov    %rbp,%r8
    91fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9200:	be 02 00 00 00       	mov    $0x2,%esi
    9205:	48 c1 e0 04          	shl    $0x4,%rax
    9209:	48 8d 3d 90 40 00 00 	lea    0x4090(%rip),%rdi        # d2a0 <units.0>
    9210:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9217:	00 
    9218:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    921c:	48 8d 0d e8 1f 00 00 	lea    0x1fe8(%rip),%rcx        # b20b <_IO_stdin_used+0x20b>
    9223:	4c 89 e7             	mov    %r12,%rdi
    9226:	31 c0                	xor    %eax,%eax
    9228:	e8 b3 a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    922d:	e9 6e f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    9232:	48 f7 d8             	neg    %rax
    9235:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    923a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    923f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9244:	48 83 d2 00          	adc    $0x0,%rdx
    9248:	48 89 c6             	mov    %rax,%rsi
    924b:	48 f7 da             	neg    %rdx
    924e:	e8 ed a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9253:	44 8b 0c 24          	mov    (%rsp),%r9d
    9257:	eb 9c                	jmp    91f5 <fwp_write+0xfd5>
    9259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009260 <fwp_main_thread>:
    9260:	f3 0f 1e fa          	endbr64
    9264:	41 57                	push   %r15
    9266:	41 56                	push   %r14
    9268:	41 55                	push   %r13
    926a:	41 54                	push   %r12
    926c:	55                   	push   %rbp
    926d:	53                   	push   %rbx
    926e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9275:	8b 35 09 79 01 00    	mov    0x17909(%rip),%esi        # 20b84 <fwp_heap+0x13a4>
    927b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9282:	00 00 
    9284:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    928b:	00 
    928c:	31 c0                	xor    %eax,%eax
    928e:	85 f6                	test   %esi,%esi
    9290:	0f 84 f2 0b 00 00    	je     9e88 <fwp_main_thread+0xc28>
    9296:	8b 0d ec 78 01 00    	mov    0x178ec(%rip),%ecx        # 20b88 <fwp_heap+0x13a8>
    929c:	85 c9                	test   %ecx,%ecx
    929e:	0f 85 cc 0b 00 00    	jne    9e70 <fwp_main_thread+0xc10>
    92a4:	48 8d 05 f5 5d 00 00 	lea    0x5df5(%rip),%rax        # f0a0 <alt.9>
    92ab:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    92b0:	31 f6                	xor    %esi,%esi
    92b2:	48 c7 05 b3 5e 01 00 	movq   $0x40000000,0x15eb3(%rip)        # 1f170 <fwp_main_stack_size>
    92b9:	00 00 00 40 
    92bd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    92c2:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    92c7:	48 89 c7             	mov    %rax,%rdi
    92ca:	48 89 2d a7 5e 01 00 	mov    %rbp,0x15ea7(%rip)        # 1f178 <fwp_main_stack_top>
    92d1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    92d8:	01 00 
    92da:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    92e1:	00 
    92e2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    92e7:	e8 d4 a3 ff ff       	call   36c0 <sigaltstack@plt>
    92ec:	85 c0                	test   %eax,%eax
    92ee:	0f 85 63 0d 00 00    	jne    a057 <fwp_main_thread+0xdf7>
    92f4:	31 c0                	xor    %eax,%eax
    92f6:	b9 12 00 00 00       	mov    $0x12,%ecx
    92fb:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9302:	00 
    9303:	f3 48 ab             	rep stos %rax,(%rdi)
    9306:	48 8d 05 e3 a9 ff ff 	lea    -0x561d(%rip),%rax        # 3cf0 <fwp_segv>
    930d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9314:	00 
    9315:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    931c:	04 00 00 08 
    9320:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9327:	00 
    9328:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    932f:	00 
    9330:	e8 4b a2 ff ff       	call   3580 <sigemptyset@plt>
    9335:	85 c0                	test   %eax,%eax
    9337:	0f 85 1a 0d 00 00    	jne    a057 <fwp_main_thread+0xdf7>
    933d:	31 d2                	xor    %edx,%edx
    933f:	48 89 de             	mov    %rbx,%rsi
    9342:	bf 0b 00 00 00       	mov    $0xb,%edi
    9347:	e8 b4 a0 ff ff       	call   3400 <sigaction@plt>
    934c:	85 c0                	test   %eax,%eax
    934e:	0f 85 03 0d 00 00    	jne    a057 <fwp_main_thread+0xdf7>
    9354:	31 d2                	xor    %edx,%edx
    9356:	48 89 de             	mov    %rbx,%rsi
    9359:	bf 07 00 00 00       	mov    $0x7,%edi
    935e:	e8 9d a0 ff ff       	call   3400 <sigaction@plt>
    9363:	85 c0                	test   %eax,%eax
    9365:	0f 85 ec 0c 00 00    	jne    a057 <fwp_main_thread+0xdf7>
    936b:	8b 15 a7 5d 01 00    	mov    0x15da7(%rip),%edx        # 1f118 <descent_registered>
    9371:	85 d2                	test   %edx,%edx
    9373:	0f 84 77 05 00 00    	je     98f0 <fwp_main_thread+0x690>
    9379:	8b 05 09 5d 00 00    	mov    0x5d09(%rip),%eax        # f088 <st.7>
    937f:	85 c0                	test   %eax,%eax
    9381:	0f 84 95 05 00 00    	je     991c <fwp_main_thread+0x6bc>
    9387:	48 8b 2d 32 64 01 00 	mov    0x16432(%rip),%rbp        # 1f7c0 <fwp_cur>
    938e:	48 85 ed             	test   %rbp,%rbp
    9391:	0f 84 09 03 00 00    	je     96a0 <fwp_main_thread+0x440>
    9397:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    939c:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    93a0:	48 89 eb             	mov    %rbp,%rbx
    93a3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    93a8:	0f 84 41 01 00 00    	je     94ef <fwp_main_thread+0x28f>
    93ae:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    93b3:	0f 84 17 02 00 00    	je     95d0 <fwp_main_thread+0x370>
    93b9:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    93bd:	0f 84 fd 01 00 00    	je     95c0 <fwp_main_thread+0x360>
    93c3:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    93c7:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    93cb:	0f 85 7f 02 00 00    	jne    9650 <fwp_main_thread+0x3f0>
    93d1:	48 8b 43 60          	mov    0x60(%rbx),%rax
    93d5:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    93dc:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    93e0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    93e7:	00 00 00 00 
    93eb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    93f2:	48 85 d2             	test   %rdx,%rdx
    93f5:	74 07                	je     93fe <fwp_main_thread+0x19e>
    93f7:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    93fe:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9402:	48 85 c0             	test   %rax,%rax
    9405:	74 34                	je     943b <fwp_main_thread+0x1db>
    9407:	48 89 43 68          	mov    %rax,0x68(%rbx)
    940b:	48 8b 05 86 63 01 00 	mov    0x16386(%rip),%rax        # 1f798 <fwp_timers>
    9412:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9416:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    941d:	00 00 00 00 
    9421:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9428:	48 85 c0             	test   %rax,%rax
    942b:	74 07                	je     9434 <fwp_main_thread+0x1d4>
    942d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9434:	48 89 1d 5d 63 01 00 	mov    %rbx,0x1635d(%rip)        # 1f798 <fwp_timers>
    943b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    943f:	e8 6c de ff ff       	call   72b0 <fwp_block>
    9444:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    944b:	48 85 c9             	test   %rcx,%rcx
    944e:	74 47                	je     9497 <fwp_main_thread+0x237>
    9450:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9457:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    945e:	48 85 d2             	test   %rdx,%rdx
    9461:	0f 84 29 02 00 00    	je     9690 <fwp_main_thread+0x430>
    9467:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    946e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9475:	48 85 c0             	test   %rax,%rax
    9478:	74 07                	je     9481 <fwp_main_thread+0x221>
    947a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9481:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9488:	00 00 00 00 
    948c:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9490:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    9497:	48 8b 0d 22 63 01 00 	mov    0x16322(%rip),%rcx        # 1f7c0 <fwp_cur>
    949e:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    94a2:	0f 84 98 01 00 00    	je     9640 <fwp_main_thread+0x3e0>
    94a8:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    94af:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    94b6:	48 85 d2             	test   %rdx,%rdx
    94b9:	0f 84 99 03 00 00    	je     9858 <fwp_main_thread+0x5f8>
    94bf:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    94c6:	48 85 c0             	test   %rax,%rax
    94c9:	74 07                	je     94d2 <fwp_main_thread+0x272>
    94cb:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    94d2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    94d6:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    94da:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    94e1:	48 89 cb             	mov    %rcx,%rbx
    94e4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    94e9:	0f 85 bf fe ff ff    	jne    93ae <fwp_main_thread+0x14e>
    94ef:	48 83 3d 61 7f 01 00 	cmpq   $0x0,0x17f61(%rip)        # 21458 <fwp_state_len>
    94f6:	00 
    94f7:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    94fb:	0f 84 81 03 00 00    	je     9882 <fwp_main_thread+0x622>
    9501:	48 39 1d b0 62 01 00 	cmp    %rbx,0x162b0(%rip)        # 1f7b8 <fwp_root>
    9508:	c7 05 8e 5b 01 00 00 	movl   $0x0,0x15b8e(%rip)        # 1f0a0 <fwp_exit_code>
    950f:	00 00 00 
    9512:	0f 85 6d 0b 00 00    	jne    a085 <fwp_main_thread+0xe25>
    9518:	48 85 db             	test   %rbx,%rbx
    951b:	0f 84 a5 01 00 00    	je     96c6 <fwp_main_thread+0x466>
    9521:	48 8b 15 60 62 01 00 	mov    0x16260(%rip),%rdx        # 1f788 <fwp_tasks_active>
    9528:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    952c:	48 85 d2             	test   %rdx,%rdx
    952f:	0f 84 91 01 00 00    	je     96c6 <fwp_main_thread+0x466>
    9535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    953c:	00 00 00 00 
    9540:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9544:	75 08                	jne    954e <fwp_main_thread+0x2ee>
    9546:	48 89 d7             	mov    %rdx,%rdi
    9549:	e8 b2 ad ff ff       	call   4300 <fwp_cancel_tree.part.0>
    954e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9555:	48 85 d2             	test   %rdx,%rdx
    9558:	75 e6                	jne    9540 <fwp_main_thread+0x2e0>
    955a:	eb 31                	jmp    958d <fwp_main_thread+0x32d>
    955c:	0f 1f 40 00          	nopl   0x0(%rax)
    9560:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9567:	48 89 1d 32 62 01 00 	mov    %rbx,0x16232(%rip)        # 1f7a0 <fwp_ready_tail>
    956e:	e8 3d dd ff ff       	call   72b0 <fwp_block>
    9573:	e8 28 db ff ff       	call   70a0 <fwp_free_zombie>
    9578:	48 83 3d 08 62 01 00 	cmpq   $0x0,0x16208(%rip)        # 1f788 <fwp_tasks_active>
    957f:	00 
    9580:	0f 84 40 01 00 00    	je     96c6 <fwp_main_thread+0x466>
    9586:	48 8b 1d 2b 62 01 00 	mov    0x1622b(%rip),%rbx        # 1f7b8 <fwp_root>
    958d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9591:	75 db                	jne    956e <fwp_main_thread+0x30e>
    9593:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9597:	75 d5                	jne    956e <fwp_main_thread+0x30e>
    9599:	48 8b 05 00 62 01 00 	mov    0x16200(%rip),%rax        # 1f7a0 <fwp_ready_tail>
    95a0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    95a4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    95ab:	00 00 00 00 
    95af:	48 85 c0             	test   %rax,%rax
    95b2:	75 ac                	jne    9560 <fwp_main_thread+0x300>
    95b4:	48 89 1d ed 61 01 00 	mov    %rbx,0x161ed(%rip)        # 1f7a8 <fwp_ready_head>
    95bb:	eb aa                	jmp    9567 <fwp_main_thread+0x307>
    95bd:	0f 1f 00             	nopl   (%rax)
    95c0:	e8 9b af ff ff       	call   4560 <fwp_now_ns>
    95c5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    95c9:	0f 8d 99 02 00 00    	jge    9868 <fwp_main_thread+0x608>
    95cf:	90                   	nop
    95d0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    95d4:	0f 85 e9 fd ff ff    	jne    93c3 <fwp_main_thread+0x163>
    95da:	48 8b 45 60          	mov    0x60(%rbp),%rax
    95de:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    95e2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    95e6:	0f 85 e9 fd ff ff    	jne    93d5 <fwp_main_thread+0x175>
    95ec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    95f0:	48 85 c9             	test   %rcx,%rcx
    95f3:	0f 84 dc fd ff ff    	je     93d5 <fwp_main_thread+0x175>
    95f9:	48 39 c8             	cmp    %rcx,%rax
    95fc:	48 89 ce             	mov    %rcx,%rsi
    95ff:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9606:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    960a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9611:	00 00 00 00 
    9615:	48 0f 4e f0          	cmovle %rax,%rsi
    9619:	48 85 c0             	test   %rax,%rax
    961c:	48 89 c8             	mov    %rcx,%rax
    961f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9626:	48 0f 45 c6          	cmovne %rsi,%rax
    962a:	48 85 d2             	test   %rdx,%rdx
    962d:	74 07                	je     9636 <fwp_main_thread+0x3d6>
    962f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9636:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    963a:	e9 c8 fd ff ff       	jmp    9407 <fwp_main_thread+0x1a7>
    963f:	90                   	nop
    9640:	48 89 cb             	mov    %rcx,%rbx
    9643:	e9 5b fd ff ff       	jmp    93a3 <fwp_main_thread+0x143>
    9648:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    964f:	00 
    9650:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9654:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    965b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9662:	00 00 00 00 
    9666:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    966d:	48 85 c0             	test   %rax,%rax
    9670:	0f 84 ba 08 00 00    	je     9f30 <fwp_main_thread+0xcd0>
    9676:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    967d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9681:	e9 b5 fd ff ff       	jmp    943b <fwp_main_thread+0x1db>
    9686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    968d:	00 00 00 
    9690:	48 89 01             	mov    %rax,(%rcx)
    9693:	e9 dd fd ff ff       	jmp    9475 <fwp_main_thread+0x215>
    9698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    969f:	00 
    96a0:	48 83 3d b0 7d 01 00 	cmpq   $0x0,0x17db0(%rip)        # 21458 <fwp_state_len>
    96a7:	00 
    96a8:	0f 84 d2 01 00 00    	je     9880 <fwp_main_thread+0x620>
    96ae:	48 83 3d 02 61 01 00 	cmpq   $0x0,0x16102(%rip)        # 1f7b8 <fwp_root>
    96b5:	00 
    96b6:	c7 05 e0 59 01 00 00 	movl   $0x0,0x159e0(%rip)        # 1f0a0 <fwp_exit_code>
    96bd:	00 00 00 
    96c0:	0f 85 c4 09 00 00    	jne    a08a <fwp_main_thread+0xe2a>
    96c6:	e8 d5 d9 ff ff       	call   70a0 <fwp_free_zombie>
    96cb:	48 83 3d d5 60 01 00 	cmpq   $0x0,0x160d5(%rip)        # 1f7a8 <fwp_ready_head>
    96d2:	00 
    96d3:	0f 85 72 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96d9:	48 83 3d b7 60 01 00 	cmpq   $0x0,0x160b7(%rip)        # 1f798 <fwp_timers>
    96e0:	00 
    96e1:	0f 85 64 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96e7:	8b 05 97 5a 01 00    	mov    0x15a97(%rip),%eax        # 1f184 <fwp_stack_pool_n>
    96ed:	85 c0                	test   %eax,%eax
    96ef:	74 3c                	je     972d <fwp_main_thread+0x4cd>
    96f1:	83 e8 01             	sub    $0x1,%eax
    96f4:	4c 8d 25 a5 5a 01 00 	lea    0x15aa5(%rip),%r12        # 1f1a0 <fwp_stack_pool>
    96fb:	48 63 d8             	movslq %eax,%rbx
    96fe:	89 c0                	mov    %eax,%eax
    9700:	48 89 da             	mov    %rbx,%rdx
    9703:	48 29 c2             	sub    %rax,%rdx
    9706:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    970a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9710:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9714:	89 1d 6a 5a 01 00    	mov    %ebx,0x15a6a(%rip)        # 1f184 <fwp_stack_pool_n>
    971a:	be 00 00 00 10       	mov    $0x10000000,%esi
    971f:	48 83 eb 01          	sub    $0x1,%rbx
    9723:	e8 b8 9e ff ff       	call   35e0 <munmap@plt>
    9728:	48 39 dd             	cmp    %rbx,%rbp
    972b:	75 e3                	jne    9710 <fwp_main_thread+0x4b0>
    972d:	8b 3d e1 58 00 00    	mov    0x58e1(%rip),%edi        # f014 <fwp_epfd>
    9733:	85 ff                	test   %edi,%edi
    9735:	78 05                	js     973c <fwp_main_thread+0x4dc>
    9737:	e8 94 9d ff ff       	call   34d0 <close@plt>
    973c:	4c 8b 25 5d 5c 01 00 	mov    0x15c5d(%rip),%r12        # 1f3a0 <fwp_nfdws>
    9743:	48 8b 2d 5e 5c 01 00 	mov    0x15c5e(%rip),%rbp        # 1f3a8 <fwp_fdws>
    974a:	31 db                	xor    %ebx,%ebx
    974c:	c7 05 be 58 00 00 ff 	movl   $0xffffffff,0x58be(%rip)        # f014 <fwp_epfd>
    9753:	ff ff ff 
    9756:	4d 85 e4             	test   %r12,%r12
    9759:	74 32                	je     978d <fwp_main_thread+0x52d>
    975b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9760:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9765:	48 85 ff             	test   %rdi,%rdi
    9768:	74 1a                	je     9784 <fwp_main_thread+0x524>
    976a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    976e:	0f 85 d7 9f ff ff    	jne    374b <fwp_main_thread.cold>
    9774:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9779:	0f 85 cc 9f ff ff    	jne    374b <fwp_main_thread.cold>
    977f:	e8 6c c0 ff ff       	call   57f0 <fwp_mem_free>
    9784:	48 83 c3 01          	add    $0x1,%rbx
    9788:	49 39 dc             	cmp    %rbx,%r12
    978b:	75 d3                	jne    9760 <fwp_main_thread+0x500>
    978d:	48 89 ef             	mov    %rbp,%rdi
    9790:	e8 5b c0 ff ff       	call   57f0 <fwp_mem_free>
    9795:	48 8b 15 1c 60 01 00 	mov    0x1601c(%rip),%rdx        # 1f7b8 <fwp_root>
    979c:	48 c7 05 01 5c 01 00 	movq   $0x0,0x15c01(%rip)        # 1f3a8 <fwp_fdws>
    97a3:	00 00 00 00 
    97a7:	48 c7 05 ee 5b 01 00 	movq   $0x0,0x15bee(%rip)        # 1f3a0 <fwp_nfdws>
    97ae:	00 00 00 00 
    97b2:	48 85 d2             	test   %rdx,%rdx
    97b5:	74 4e                	je     9805 <fwp_main_thread+0x5a5>
    97b7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    97bc:	0f 85 89 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97c2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    97c9:	00 
    97ca:	0f 85 7b 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97d0:	48 83 3d 80 7c 01 00 	cmpq   $0x0,0x17c80(%rip)        # 21458 <fwp_state_len>
    97d7:	00 
    97d8:	0f 85 6d 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97de:	48 83 3d 62 7c 01 00 	cmpq   $0x0,0x17c62(%rip)        # 21448 <fwp_state_owners>
    97e5:	00 
    97e6:	0f 85 5f 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97ec:	b9 79 00 00 00       	mov    $0x79,%ecx
    97f1:	31 c0                	xor    %eax,%eax
    97f3:	48 8d 3d c6 5b 01 00 	lea    0x15bc6(%rip),%rdi        # 1f3c0 <fwp_root_context>
    97fa:	f3 48 ab             	rep stos %rax,(%rdi)
    97fd:	48 89 d7             	mov    %rdx,%rdi
    9800:	e8 eb bf ff ff       	call   57f0 <fwp_mem_free>
    9805:	48 8b 3d 14 58 00 00 	mov    0x5814(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    980c:	48 c7 05 a9 5f 01 00 	movq   $0x0,0x15fa9(%rip)        # 1f7c0 <fwp_cur>
    9813:	00 00 00 00 
    9817:	48 c7 05 96 5f 01 00 	movq   $0x0,0x15f96(%rip)        # 1f7b8 <fwp_root>
    981e:	00 00 00 00 
    9822:	e8 99 9d ff ff       	call   35c0 <fflush@plt>
    9827:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    982e:	00 
    982f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9836:	00 00 
    9838:	0f 85 36 08 00 00    	jne    a074 <fwp_main_thread+0xe14>
    983e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9845:	31 c0                	xor    %eax,%eax
    9847:	5b                   	pop    %rbx
    9848:	5d                   	pop    %rbp
    9849:	41 5c                	pop    %r12
    984b:	41 5d                	pop    %r13
    984d:	41 5e                	pop    %r14
    984f:	41 5f                	pop    %r15
    9851:	c3                   	ret
    9852:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9858:	48 89 05 39 5f 01 00 	mov    %rax,0x15f39(%rip)        # 1f798 <fwp_timers>
    985f:	e9 62 fc ff ff       	jmp    94c6 <fwp_main_thread+0x266>
    9864:	0f 1f 40 00          	nopl   0x0(%rax)
    9868:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    986c:	0f 85 5e fd ff ff    	jne    95d0 <fwp_main_thread+0x370>
    9872:	48 89 ef             	mov    %rbp,%rdi
    9875:	e8 86 aa ff ff       	call   4300 <fwp_cancel_tree.part.0>
    987a:	e9 51 fd ff ff       	jmp    95d0 <fwp_main_thread+0x370>
    987f:	90                   	nop
    9880:	31 db                	xor    %ebx,%ebx
    9882:	48 83 3d be 7b 01 00 	cmpq   $0x0,0x17bbe(%rip)        # 21448 <fwp_state_owners>
    9889:	00 
    988a:	0f 85 71 fc ff ff    	jne    9501 <fwp_main_thread+0x2a1>
    9890:	48 8b 3d c9 7b 01 00 	mov    0x17bc9(%rip),%rdi        # 21460 <fwp_state>
    9897:	e8 54 bf ff ff       	call   57f0 <fwp_mem_free>
    989c:	48 c7 05 b9 7b 01 00 	movq   $0x0,0x17bb9(%rip)        # 21460 <fwp_state>
    98a3:	00 00 00 00 
    98a7:	48 c7 05 9e 7b 01 00 	movq   $0x0,0x17b9e(%rip)        # 21450 <fwp_state_cap>
    98ae:	00 00 00 00 
    98b2:	48 85 db             	test   %rbx,%rbx
    98b5:	0f 84 4f 07 00 00    	je     a00a <fwp_main_thread+0xdaa>
    98bb:	48 39 1d f6 5e 01 00 	cmp    %rbx,0x15ef6(%rip)        # 1f7b8 <fwp_root>
    98c2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    98c9:	00 00 00 00 
    98cd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    98d4:	00 00 00 00 
    98d8:	c7 05 be 57 01 00 00 	movl   $0x0,0x157be(%rip)        # 1f0a0 <fwp_exit_code>
    98df:	00 00 00 
    98e2:	0f 84 39 fc ff ff    	je     9521 <fwp_main_thread+0x2c1>
    98e8:	e9 5e 9e ff ff       	jmp    374b <fwp_main_thread.cold>
    98ed:	0f 1f 00             	nopl   (%rax)
    98f0:	48 8d 3d 19 a5 ff ff 	lea    -0x5ae7(%rip),%rdi        # 3e10 <descent_phase_report>
    98f7:	e8 a4 09 00 00       	call   a2a0 <atexit>
    98fc:	85 c0                	test   %eax,%eax
    98fe:	0f 85 6b 07 00 00    	jne    a06f <fwp_main_thread+0xe0f>
    9904:	c7 05 0a 58 01 00 01 	movl   $0x1,0x1580a(%rip)        # 1f118 <descent_registered>
    990b:	00 00 00 
    990e:	8b 05 74 57 00 00    	mov    0x5774(%rip),%eax        # f088 <st.7>
    9914:	85 c0                	test   %eax,%eax
    9916:	0f 85 6b fa ff ff    	jne    9387 <fwp_main_thread+0x127>
    991c:	48 8d 05 ad df ff ff 	lea    -0x2053(%rip),%rax        # 78d0 <fwp_drop1>
    9923:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9927:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    992e:	00 00 
    9930:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9936:	66 48 0f 6e d8       	movq   %rax,%xmm3
    993b:	48 8b 05 36 7b 01 00 	mov    0x17b36(%rip),%rax        # 21478 <fwp_cleanups>
    9942:	4c 8d 3d 97 5e 01 00 	lea    0x15e97(%rip),%r15        # 1f7e0 <fwp_heap>
    9949:	48 89 2d 28 7b 01 00 	mov    %rbp,0x17b28(%rip)        # 21478 <fwp_cleanups>
    9950:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9954:	31 ed                	xor    %ebp,%ebp
    9956:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    995b:	48 8d 05 6e a2 ff ff 	lea    -0x5d92(%rip),%rax        # 3bd0 <fwp_range_release>
    9962:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9967:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    996c:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9971:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9976:	eb 45                	jmp    99bd <fwp_main_thread+0x75d>
    9978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    997f:	00 
    9980:	80 f9 01             	cmp    $0x1,%cl
    9983:	75 29                	jne    99ae <fwp_main_thread+0x74e>
    9985:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9988:	0f b7 c0             	movzwl %ax,%eax
    998b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    998e:	48 0f af c1          	imul   %rcx,%rax
    9992:	48 c1 e8 20          	shr    $0x20,%rax
    9996:	48 39 d0             	cmp    %rdx,%rax
    9999:	73 13                	jae    99ae <fwp_main_thread+0x74e>
    999b:	49 01 c5             	add    %rax,%r13
    999e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    99a3:	0f 84 c7 05 00 00    	je     9f70 <fwp_main_thread+0xd10>
    99a9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    99ae:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    99b3:	49 83 ec 01          	sub    $0x1,%r12
    99b7:	0f 82 83 00 00 00    	jb     9a40 <fwp_main_thread+0x7e0>
    99bd:	48 89 de             	mov    %rbx,%rsi
    99c0:	bf 01 00 00 00       	mov    $0x1,%edi
    99c5:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    99cc:	00 
    99cd:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    99d2:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    99d9:	00 
    99da:	e8 31 c4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    99df:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    99e6:	48 89 c5             	mov    %rax,%rbp
    99e9:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    99f0:	48 c1 e2 10          	shl    $0x10,%rdx
    99f4:	48 39 d0             	cmp    %rdx,%rax
    99f7:	73 b5                	jae    99ae <fwp_main_thread+0x74e>
    99f9:	48 89 c2             	mov    %rax,%rdx
    99fc:	48 c1 ea 10          	shr    $0x10,%rdx
    9a00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a04:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9a0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a0f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9a13:	4d 85 ed             	test   %r13,%r13
    9a16:	74 96                	je     99ae <fwp_main_thread+0x74e>
    9a18:	0f b6 0a             	movzbl (%rdx),%ecx
    9a1b:	80 f9 02             	cmp    $0x2,%cl
    9a1e:	0f 85 5c ff ff ff    	jne    9980 <fwp_main_thread+0x720>
    9a24:	66 85 c0             	test   %ax,%ax
    9a27:	0f 84 71 ff ff ff    	je     999e <fwp_main_thread+0x73e>
    9a2d:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9a32:	49 83 ec 01          	sub    $0x1,%r12
    9a36:	73 85                	jae    99bd <fwp_main_thread+0x75d>
    9a38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a3f:	00 
    9a40:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9a45:	66 0f 6f 05 23 21 00 	movdqa 0x2123(%rip),%xmm0        # bb70 <msg.8+0xb0>
    9a4c:	00 
    9a4d:	48 89 de             	mov    %rbx,%rsi
    9a50:	bf 01 00 00 00       	mov    $0x1,%edi
    9a55:	48 89 05 1c 7a 01 00 	mov    %rax,0x17a1c(%rip)        # 21478 <fwp_cleanups>
    9a5c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9a63:	00 
    9a64:	e8 a7 c3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9a69:	48 8b 15 48 71 01 00 	mov    0x17148(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    9a70:	49 89 c4             	mov    %rax,%r12
    9a73:	48 2b 05 16 71 01 00 	sub    0x17116(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    9a7a:	48 c1 e2 10          	shl    $0x10,%rdx
    9a7e:	48 39 d0             	cmp    %rdx,%rax
    9a81:	73 55                	jae    9ad8 <fwp_main_thread+0x878>
    9a83:	48 89 c2             	mov    %rax,%rdx
    9a86:	48 c1 ea 10          	shr    $0x10,%rdx
    9a8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a8e:	48 8b 15 43 71 01 00 	mov    0x17143(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    9a95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a99:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9a9d:	48 85 db             	test   %rbx,%rbx
    9aa0:	74 36                	je     9ad8 <fwp_main_thread+0x878>
    9aa2:	0f b6 0a             	movzbl (%rdx),%ecx
    9aa5:	80 f9 02             	cmp    $0x2,%cl
    9aa8:	0f 84 b2 04 00 00    	je     9f60 <fwp_main_thread+0xd00>
    9aae:	80 f9 01             	cmp    $0x1,%cl
    9ab1:	75 25                	jne    9ad8 <fwp_main_thread+0x878>
    9ab3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ab6:	0f b7 c0             	movzwl %ax,%eax
    9ab9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9abc:	48 0f af c1          	imul   %rcx,%rax
    9ac0:	48 c1 e8 20          	shr    $0x20,%rax
    9ac4:	48 39 d0             	cmp    %rdx,%rax
    9ac7:	73 0f                	jae    9ad8 <fwp_main_thread+0x878>
    9ac9:	48 01 c3             	add    %rax,%rbx
    9acc:	80 3b ff             	cmpb   $0xff,(%rbx)
    9acf:	0f 84 5b 05 00 00    	je     a030 <fwp_main_thread+0xdd0>
    9ad5:	c6 03 01             	movb   $0x1,(%rbx)
    9ad8:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9add:	bf 01 00 00 00       	mov    $0x1,%edi
    9ae2:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9ae7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9aee:	00 f0 3f 
    9af1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9af6:	e8 15 c3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9afb:	48 8b 15 b6 70 01 00 	mov    0x170b6(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    9b02:	49 89 c4             	mov    %rax,%r12
    9b05:	48 2b 05 84 70 01 00 	sub    0x17084(%rip),%rax        # 20b90 <fwp_heap+0x13b0>
    9b0c:	48 c1 e2 10          	shl    $0x10,%rdx
    9b10:	48 39 d0             	cmp    %rdx,%rax
    9b13:	73 55                	jae    9b6a <fwp_main_thread+0x90a>
    9b15:	48 89 c2             	mov    %rax,%rdx
    9b18:	48 c1 ea 10          	shr    $0x10,%rdx
    9b1c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b20:	48 8b 15 b1 70 01 00 	mov    0x170b1(%rip),%rdx        # 20bd8 <fwp_heap+0x13f8>
    9b27:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b2b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9b2f:	48 85 db             	test   %rbx,%rbx
    9b32:	74 36                	je     9b6a <fwp_main_thread+0x90a>
    9b34:	0f b6 0a             	movzbl (%rdx),%ecx
    9b37:	80 f9 02             	cmp    $0x2,%cl
    9b3a:	0f 84 10 04 00 00    	je     9f50 <fwp_main_thread+0xcf0>
    9b40:	80 f9 01             	cmp    $0x1,%cl
    9b43:	75 25                	jne    9b6a <fwp_main_thread+0x90a>
    9b45:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b48:	0f b7 c0             	movzwl %ax,%eax
    9b4b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b4e:	48 0f af c1          	imul   %rcx,%rax
    9b52:	48 c1 e8 20          	shr    $0x20,%rax
    9b56:	48 39 d0             	cmp    %rdx,%rax
    9b59:	73 0f                	jae    9b6a <fwp_main_thread+0x90a>
    9b5b:	48 01 c3             	add    %rax,%rbx
    9b5e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9b61:	0f 84 d6 04 00 00    	je     a03d <fwp_main_thread+0xddd>
    9b67:	c6 03 01             	movb   $0x1,(%rbx)
    9b6a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    9b6f:	bf 01 00 00 00       	mov    $0x1,%edi
    9b74:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9b79:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9b80:	33 f3 bf 
    9b83:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9b88:	e8 83 c2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9b8d:	48 8b 15 24 70 01 00 	mov    0x17024(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    9b94:	48 8b 0d f5 6f 01 00 	mov    0x16ff5(%rip),%rcx        # 20b90 <fwp_heap+0x13b0>
    9b9b:	49 89 c4             	mov    %rax,%r12
    9b9e:	48 89 d6             	mov    %rdx,%rsi
    9ba1:	48 29 c8             	sub    %rcx,%rax
    9ba4:	48 c1 e6 10          	shl    $0x10,%rsi
    9ba8:	48 39 f0             	cmp    %rsi,%rax
    9bab:	73 65                	jae    9c12 <fwp_main_thread+0x9b2>
    9bad:	48 89 c6             	mov    %rax,%rsi
    9bb0:	48 c1 ee 10          	shr    $0x10,%rsi
    9bb4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9bb8:	48 8b 35 19 70 01 00 	mov    0x17019(%rip),%rsi        # 20bd8 <fwp_heap+0x13f8>
    9bbf:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9bc3:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    9bc7:	48 85 db             	test   %rbx,%rbx
    9bca:	74 46                	je     9c12 <fwp_main_thread+0x9b2>
    9bcc:	0f b6 3e             	movzbl (%rsi),%edi
    9bcf:	40 80 ff 02          	cmp    $0x2,%dil
    9bd3:	0f 84 67 03 00 00    	je     9f40 <fwp_main_thread+0xce0>
    9bd9:	40 80 ff 01          	cmp    $0x1,%dil
    9bdd:	75 33                	jne    9c12 <fwp_main_thread+0x9b2>
    9bdf:	8b 7e 18             	mov    0x18(%rsi),%edi
    9be2:	0f b7 c0             	movzwl %ax,%eax
    9be5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9be8:	48 0f af c7          	imul   %rdi,%rax
    9bec:	48 c1 e8 20          	shr    $0x20,%rax
    9bf0:	48 39 f0             	cmp    %rsi,%rax
    9bf3:	73 1d                	jae    9c12 <fwp_main_thread+0x9b2>
    9bf5:	48 01 c3             	add    %rax,%rbx
    9bf8:	80 3b ff             	cmpb   $0xff,(%rbx)
    9bfb:	0f 84 49 04 00 00    	je     a04a <fwp_main_thread+0xdea>
    9c01:	c6 03 01             	movb   $0x1,(%rbx)
    9c04:	48 8b 0d 85 6f 01 00 	mov    0x16f85(%rip),%rcx        # 20b90 <fwp_heap+0x13b0>
    9c0b:	48 8b 15 a6 6f 01 00 	mov    0x16fa6(%rip),%rdx        # 20bb8 <fwp_heap+0x13d8>
    9c12:	49 89 ed             	mov    %rbp,%r13
    9c15:	e9 01 02 00 00       	jmp    9e1b <fwp_main_thread+0xbbb>
    9c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c20:	80 f9 01             	cmp    $0x1,%cl
    9c23:	75 2d                	jne    9c52 <fwp_main_thread+0x9f2>
    9c25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c28:	0f b7 c0             	movzwl %ax,%eax
    9c2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c2e:	48 0f af c1          	imul   %rcx,%rax
    9c32:	48 c1 e8 20          	shr    $0x20,%rax
    9c36:	48 39 d0             	cmp    %rdx,%rax
    9c39:	73 17                	jae    9c52 <fwp_main_thread+0x9f2>
    9c3b:	48 01 c7             	add    %rax,%rdi
    9c3e:	0f b6 07             	movzbl (%rdi),%eax
    9c41:	84 c0                	test   %al,%al
    9c43:	74 0d                	je     9c52 <fwp_main_thread+0x9f2>
    9c45:	3c fd                	cmp    $0xfd,%al
    9c47:	0f 87 b3 03 00 00    	ja     a000 <fwp_main_thread+0xda0>
    9c4d:	83 c0 01             	add    $0x1,%eax
    9c50:	88 07                	mov    %al,(%rdi)
    9c52:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9c57:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9c5b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9c60:	4c 89 e6             	mov    %r12,%rsi
    9c63:	48 8d 15 16 4f 00 00 	lea    0x4f16(%rip),%rdx        # eb80 <d0>
    9c6a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    9c6f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9c76:	00 00 
    9c78:	e8 a3 e5 ff ff       	call   8220 <fwp_write>
    9c7d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9c82:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    9c87:	48 8d 05 03 14 00 00 	lea    0x1403(%rip),%rax        # b091 <_IO_stdin_used+0x91>
    9c8e:	48 85 c9             	test   %rcx,%rcx
    9c91:	48 0f 44 c8          	cmove  %rax,%rcx
    9c95:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    9c99:	0f 87 c4 03 00 00    	ja     a063 <fwp_main_thread+0xe03>
    9c9f:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    9ca3:	be 01 00 00 00       	mov    $0x1,%esi
    9ca8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9cad:	e8 3e c0 ff ff       	call   5cf0 <fwp_heap_alloc>
    9cb2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9cb7:	4c 89 f2             	mov    %r14,%rdx
    9cba:	4c 89 30             	mov    %r14,(%rax)
    9cbd:	48 89 c3             	mov    %rax,%rbx
    9cc0:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9cc4:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    9cc9:	e8 d2 98 ff ff       	call   35a0 <memcpy@plt>
    9cce:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    9cd4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    9cd9:	e8 e2 96 ff ff       	call   33c0 <free@plt>
    9cde:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9ce5:	48 89 d8             	mov    %rbx,%rax
    9ce8:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9cef:	48 c1 e2 10          	shl    $0x10,%rdx
    9cf3:	48 39 d0             	cmp    %rdx,%rax
    9cf6:	73 55                	jae    9d4d <fwp_main_thread+0xaed>
    9cf8:	48 89 c2             	mov    %rax,%rdx
    9cfb:	48 c1 ea 10          	shr    $0x10,%rdx
    9cff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d03:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9d0a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d0e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9d12:	48 85 f6             	test   %rsi,%rsi
    9d15:	74 36                	je     9d4d <fwp_main_thread+0xaed>
    9d17:	0f b6 0a             	movzbl (%rdx),%ecx
    9d1a:	80 f9 02             	cmp    $0x2,%cl
    9d1d:	0f 84 bd 01 00 00    	je     9ee0 <fwp_main_thread+0xc80>
    9d23:	80 f9 01             	cmp    $0x1,%cl
    9d26:	75 25                	jne    9d4d <fwp_main_thread+0xaed>
    9d28:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d2b:	0f b7 c0             	movzwl %ax,%eax
    9d2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d31:	48 0f af c1          	imul   %rcx,%rax
    9d35:	48 c1 e8 20          	shr    $0x20,%rax
    9d39:	48 39 d0             	cmp    %rdx,%rax
    9d3c:	73 0f                	jae    9d4d <fwp_main_thread+0xaed>
    9d3e:	48 01 c6             	add    %rax,%rsi
    9d41:	80 3e ff             	cmpb   $0xff,(%rsi)
    9d44:	0f 84 b6 01 00 00    	je     9f00 <fwp_main_thread+0xca0>
    9d4a:	c6 06 01             	movb   $0x1,(%rsi)
    9d4d:	4c 89 e7             	mov    %r12,%rdi
    9d50:	e8 8b d9 ff ff       	call   76e0 <fwp_drop0>
    9d55:	48 8b 13             	mov    (%rbx),%rdx
    9d58:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9d5d:	be 01 00 00 00       	mov    $0x1,%esi
    9d62:	48 8b 0d d7 76 01 00 	mov    0x176d7(%rip),%rcx        # 21440 <fwp_prog_out>
    9d69:	e8 12 99 ff ff       	call   3680 <fwrite@plt>
    9d6e:	48 8b 35 cb 76 01 00 	mov    0x176cb(%rip),%rsi        # 21440 <fwp_prog_out>
    9d75:	bf 0a 00 00 00       	mov    $0xa,%edi
    9d7a:	e8 61 97 ff ff       	call   34e0 <fputc@plt>
    9d7f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9d86:	48 89 d8             	mov    %rbx,%rax
    9d89:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9d90:	48 c1 e2 10          	shl    $0x10,%rdx
    9d94:	48 39 d0             	cmp    %rdx,%rax
    9d97:	73 67                	jae    9e00 <fwp_main_thread+0xba0>
    9d99:	48 89 c2             	mov    %rax,%rdx
    9d9c:	48 c1 ea 10          	shr    $0x10,%rdx
    9da0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9da4:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9dab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9daf:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9db3:	4d 85 f6             	test   %r14,%r14
    9db6:	74 48                	je     9e00 <fwp_main_thread+0xba0>
    9db8:	0f b6 0a             	movzbl (%rdx),%ecx
    9dbb:	80 f9 02             	cmp    $0x2,%cl
    9dbe:	0f 84 d4 00 00 00    	je     9e98 <fwp_main_thread+0xc38>
    9dc4:	80 f9 01             	cmp    $0x1,%cl
    9dc7:	75 37                	jne    9e00 <fwp_main_thread+0xba0>
    9dc9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9dcc:	0f b7 c0             	movzwl %ax,%eax
    9dcf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dd2:	48 0f af c1          	imul   %rcx,%rax
    9dd6:	48 c1 e8 20          	shr    $0x20,%rax
    9dda:	48 39 d0             	cmp    %rdx,%rax
    9ddd:	73 21                	jae    9e00 <fwp_main_thread+0xba0>
    9ddf:	49 01 c6             	add    %rax,%r14
    9de2:	41 0f b6 06          	movzbl (%r14),%eax
    9de6:	84 c0                	test   %al,%al
    9de8:	74 16                	je     9e00 <fwp_main_thread+0xba0>
    9dea:	3c 01                	cmp    $0x1,%al
    9dec:	0f 84 2e 01 00 00    	je     9f20 <fwp_main_thread+0xcc0>
    9df2:	3c ff                	cmp    $0xff,%al
    9df4:	0f 84 86 01 00 00    	je     9f80 <fwp_main_thread+0xd20>
    9dfa:	83 e8 01             	sub    $0x1,%eax
    9dfd:	41 88 06             	mov    %al,(%r14)
    9e00:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9e04:	4d 85 ed             	test   %r13,%r13
    9e07:	0f 84 a3 00 00 00    	je     9eb0 <fwp_main_thread+0xc50>
    9e0d:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9e14:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9e1b:	4c 89 e0             	mov    %r12,%rax
    9e1e:	48 c1 e2 10          	shl    $0x10,%rdx
    9e22:	48 29 c8             	sub    %rcx,%rax
    9e25:	48 39 d0             	cmp    %rdx,%rax
    9e28:	0f 83 24 fe ff ff    	jae    9c52 <fwp_main_thread+0x9f2>
    9e2e:	48 89 c2             	mov    %rax,%rdx
    9e31:	48 c1 ea 10          	shr    $0x10,%rdx
    9e35:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e39:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9e40:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e44:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9e48:	48 85 ff             	test   %rdi,%rdi
    9e4b:	0f 84 01 fe ff ff    	je     9c52 <fwp_main_thread+0x9f2>
    9e51:	0f b6 0a             	movzbl (%rdx),%ecx
    9e54:	80 f9 02             	cmp    $0x2,%cl
    9e57:	0f 85 c3 fd ff ff    	jne    9c20 <fwp_main_thread+0x9c0>
    9e5d:	66 85 c0             	test   %ax,%ax
    9e60:	0f 85 ec fd ff ff    	jne    9c52 <fwp_main_thread+0x9f2>
    9e66:	e9 d3 fd ff ff       	jmp    9c3e <fwp_main_thread+0x9de>
    9e6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e70:	48 8d 3d e9 ad ff ff 	lea    -0x5217(%rip),%rdi        # 4c60 <fwp_heap_report>
    9e77:	e8 24 04 00 00       	call   a2a0 <atexit>
    9e7c:	e9 23 f4 ff ff       	jmp    92a4 <fwp_main_thread+0x44>
    9e81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9e88:	e8 e3 ae ff ff       	call   4d70 <fwp_heap_init>
    9e8d:	e9 04 f4 ff ff       	jmp    9296 <fwp_main_thread+0x36>
    9e92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e98:	66 85 c0             	test   %ax,%ax
    9e9b:	0f 84 41 ff ff ff    	je     9de2 <fwp_main_thread+0xb82>
    9ea1:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9ea5:	4d 85 ed             	test   %r13,%r13
    9ea8:	0f 85 5f ff ff ff    	jne    9e0d <fwp_main_thread+0xbad>
    9eae:	66 90                	xchg   %ax,%ax
    9eb0:	4c 89 e7             	mov    %r12,%rdi
    9eb3:	e8 28 d8 ff ff       	call   76e0 <fwp_drop0>
    9eb8:	48 89 ef             	mov    %rbp,%rdi
    9ebb:	e8 20 d8 ff ff       	call   76e0 <fwp_drop0>
    9ec0:	48 c7 05 b5 51 00 00 	movq   $0x0,0x51b5(%rip)        # f080 <v.6>
    9ec7:	00 00 00 00 
    9ecb:	c7 05 b3 51 00 00 01 	movl   $0x1,0x51b3(%rip)        # f088 <st.7>
    9ed2:	00 00 00 
    9ed5:	e9 ad f4 ff ff       	jmp    9387 <fwp_main_thread+0x127>
    9eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ee0:	66 85 c0             	test   %ax,%ax
    9ee3:	0f 85 64 fe ff ff    	jne    9d4d <fwp_main_thread+0xaed>
    9ee9:	80 3e ff             	cmpb   $0xff,(%rsi)
    9eec:	0f 85 58 fe ff ff    	jne    9d4a <fwp_main_thread+0xaea>
    9ef2:	0f 1f 00             	nopl   (%rax)
    9ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9efc:	00 00 00 00 
    9f00:	48 89 f7             	mov    %rsi,%rdi
    9f03:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    9f08:	e8 a3 b6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9f0d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9f12:	e9 33 fe ff ff       	jmp    9d4a <fwp_main_thread+0xaea>
    9f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f1e:	00 00 
    9f20:	48 89 df             	mov    %rbx,%rdi
    9f23:	e8 c8 b8 ff ff       	call   57f0 <fwp_mem_free>
    9f28:	e9 d3 fe ff ff       	jmp    9e00 <fwp_main_thread+0xba0>
    9f2d:	0f 1f 00             	nopl   (%rax)
    9f30:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9f34:	e9 02 f5 ff ff       	jmp    943b <fwp_main_thread+0x1db>
    9f39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9f40:	66 85 c0             	test   %ax,%ax
    9f43:	0f 85 c9 fc ff ff    	jne    9c12 <fwp_main_thread+0x9b2>
    9f49:	e9 aa fc ff ff       	jmp    9bf8 <fwp_main_thread+0x998>
    9f4e:	66 90                	xchg   %ax,%ax
    9f50:	66 85 c0             	test   %ax,%ax
    9f53:	0f 85 11 fc ff ff    	jne    9b6a <fwp_main_thread+0x90a>
    9f59:	e9 00 fc ff ff       	jmp    9b5e <fwp_main_thread+0x8fe>
    9f5e:	66 90                	xchg   %ax,%ax
    9f60:	66 85 c0             	test   %ax,%ax
    9f63:	0f 85 6f fb ff ff    	jne    9ad8 <fwp_main_thread+0x878>
    9f69:	e9 5e fb ff ff       	jmp    9acc <fwp_main_thread+0x86c>
    9f6e:	66 90                	xchg   %ax,%ax
    9f70:	4c 89 ef             	mov    %r13,%rdi
    9f73:	e8 38 b6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9f78:	e9 2c fa ff ff       	jmp    99a9 <fwp_main_thread+0x749>
    9f7d:	0f 1f 00             	nopl   (%rax)
    9f80:	4c 89 f0             	mov    %r14,%rax
    9f83:	48 c1 e8 11          	shr    $0x11,%rax
    9f87:	4c 31 f0             	xor    %r14,%rax
    9f8a:	48 89 c2             	mov    %rax,%rdx
    9f8d:	48 c1 ea 09          	shr    $0x9,%rdx
    9f91:	48 31 d0             	xor    %rdx,%rax
    9f94:	0f b6 d0             	movzbl %al,%edx
    9f97:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    9f9e:	00 
    9f9f:	48 85 c0             	test   %rax,%rax
    9fa2:	75 29                	jne    9fcd <fwp_main_thread+0xd6d>
    9fa4:	e9 d0 00 00 00       	jmp    a079 <fwp_main_thread+0xe19>
    9fa9:	90                   	nop
    9faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fb1:	00 00 00 00 
    9fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fbc:	00 00 00 00 
    9fc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9fc4:	48 85 c0             	test   %rax,%rax
    9fc7:	0f 84 ac 00 00 00    	je     a079 <fwp_main_thread+0xe19>
    9fcd:	48 89 c2             	mov    %rax,%rdx
    9fd0:	4c 3b 30             	cmp    (%rax),%r14
    9fd3:	75 eb                	jne    9fc0 <fwp_main_thread+0xd60>
    9fd5:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9fd9:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    9fdd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9fe1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9fe8:	0f 85 12 fe ff ff    	jne    9e00 <fwp_main_thread+0xba0>
    9fee:	4c 89 f7             	mov    %r14,%rdi
    9ff1:	e8 ba b5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9ff6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    9ffa:	e9 01 fe ff ff       	jmp    9e00 <fwp_main_thread+0xba0>
    9fff:	90                   	nop
    a000:	e8 8b b4 ff ff       	call   5490 <fwp_rc_wide_dup>
    a005:	e9 48 fc ff ff       	jmp    9c52 <fwp_main_thread+0x9f2>
    a00a:	48 83 3d a6 57 01 00 	cmpq   $0x0,0x157a6(%rip)        # 1f7b8 <fwp_root>
    a011:	00 
    a012:	c7 05 84 50 01 00 00 	movl   $0x0,0x15084(%rip)        # 1f0a0 <fwp_exit_code>
    a019:	00 00 00 
    a01c:	0f 84 a4 f6 ff ff    	je     96c6 <fwp_main_thread+0x466>
    a022:	e9 24 97 ff ff       	jmp    374b <fwp_main_thread.cold>
    a027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a02e:	00 00 
    a030:	48 89 df             	mov    %rbx,%rdi
    a033:	e8 78 b5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    a038:	e9 98 fa ff ff       	jmp    9ad5 <fwp_main_thread+0x875>
    a03d:	48 89 df             	mov    %rbx,%rdi
    a040:	e8 6b b5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    a045:	e9 1d fb ff ff       	jmp    9b67 <fwp_main_thread+0x907>
    a04a:	48 89 df             	mov    %rbx,%rdi
    a04d:	e8 5e b5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    a052:	e9 aa fb ff ff       	jmp    9c01 <fwp_main_thread+0x9a1>
    a057:	48 8d 3d da 18 00 00 	lea    0x18da(%rip),%rdi        # b938 <_IO_stdin_used+0x938>
    a05e:	e8 8d a3 ff ff       	call   43f0 <fwp_trap>
    a063:	48 8d 3d b2 11 00 00 	lea    0x11b2(%rip),%rdi        # b21c <_IO_stdin_used+0x21c>
    a06a:	e8 81 a3 ff ff       	call   43f0 <fwp_trap>
    a06f:	e8 6c 9d ff ff       	call   3de0 <descent_phase_fail>
    a074:	e8 e7 93 ff ff       	call   3460 <__stack_chk_fail@plt>
    a079:	48 8d 3d e8 17 00 00 	lea    0x17e8(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    a080:	e8 6b a3 ff ff       	call   43f0 <fwp_trap>
    a085:	e9 c1 96 ff ff       	jmp    374b <fwp_main_thread.cold>
    a08a:	e9 bc 96 ff ff       	jmp    374b <fwp_main_thread.cold>
    a08f:	90                   	nop

000000000000a090 <__divmodti4>:
    a090:	f3 0f 1e fa          	endbr64
    a094:	55                   	push   %rbp
    a095:	49 89 f1             	mov    %rsi,%r9
    a098:	49 89 d2             	mov    %rdx,%r10
    a09b:	48 89 fe             	mov    %rdi,%rsi
    a09e:	49 89 cb             	mov    %rcx,%r11
    a0a1:	48 89 e5             	mov    %rsp,%rbp
    a0a4:	41 57                	push   %r15
    a0a6:	41 56                	push   %r14
    a0a8:	41 55                	push   %r13
    a0aa:	41 54                	push   %r12
    a0ac:	53                   	push   %rbx
    a0ad:	4c 89 c3             	mov    %r8,%rbx
    a0b0:	45 31 c0             	xor    %r8d,%r8d
    a0b3:	4d 85 c9             	test   %r9,%r9
    a0b6:	79 12                	jns    a0ca <__divmodti4+0x3a>
    a0b8:	31 ff                	xor    %edi,%edi
    a0ba:	48 f7 de             	neg    %rsi
    a0bd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a0c4:	4c 19 cf             	sbb    %r9,%rdi
    a0c7:	49 89 f9             	mov    %rdi,%r9
    a0ca:	4c 89 d8             	mov    %r11,%rax
    a0cd:	4d 85 db             	test   %r11,%r11
    a0d0:	0f 88 1a 01 00 00    	js     a1f0 <__divmodti4+0x160>
    a0d6:	4c 89 d9             	mov    %r11,%rcx
    a0d9:	49 89 f3             	mov    %rsi,%r11
    a0dc:	75 62                	jne    a140 <__divmodti4+0xb0>
    a0de:	4d 89 c4             	mov    %r8,%r12
    a0e1:	4d 39 d1             	cmp    %r10,%r9
    a0e4:	0f 83 46 01 00 00    	jae    a230 <__divmodti4+0x1a0>
    a0ea:	4c 89 d8             	mov    %r11,%rax
    a0ed:	4c 89 ca             	mov    %r9,%rdx
    a0f0:	49 f7 f2             	div    %r10
    a0f3:	49 89 c3             	mov    %rax,%r11
    a0f6:	31 c0                	xor    %eax,%eax
    a0f8:	48 89 d6             	mov    %rdx,%rsi
    a0fb:	31 ff                	xor    %edi,%edi
    a0fd:	4c 89 d9             	mov    %r11,%rcx
    a100:	48 89 c2             	mov    %rax,%rdx
    a103:	48 89 c8             	mov    %rcx,%rax
    a106:	4d 85 e4             	test   %r12,%r12
    a109:	74 0a                	je     a115 <__divmodti4+0x85>
    a10b:	48 f7 d8             	neg    %rax
    a10e:	48 83 d2 00          	adc    $0x0,%rdx
    a112:	48 f7 da             	neg    %rdx
    a115:	4d 85 c0             	test   %r8,%r8
    a118:	74 0a                	je     a124 <__divmodti4+0x94>
    a11a:	48 f7 de             	neg    %rsi
    a11d:	48 83 d7 00          	adc    $0x0,%rdi
    a121:	48 f7 df             	neg    %rdi
    a124:	48 89 33             	mov    %rsi,(%rbx)
    a127:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a12b:	5b                   	pop    %rbx
    a12c:	41 5c                	pop    %r12
    a12e:	41 5d                	pop    %r13
    a130:	41 5e                	pop    %r14
    a132:	41 5f                	pop    %r15
    a134:	5d                   	pop    %rbp
    a135:	c3                   	ret
    a136:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a13d:	00 00 00 
    a140:	4d 89 c4             	mov    %r8,%r12
    a143:	49 39 c1             	cmp    %rax,%r9
    a146:	0f 82 ce 00 00 00    	jb     a21a <__divmodti4+0x18a>
    a14c:	31 ff                	xor    %edi,%edi
    a14e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a153:	48 63 c7             	movslq %edi,%rax
    a156:	be 40 00 00 00       	mov    $0x40,%esi
    a15b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a160:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a165:	48 29 c6             	sub    %rax,%rsi
    a168:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a16d:	48 09 c8             	or     %rcx,%rax
    a170:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a175:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a17a:	49 89 c6             	mov    %rax,%r14
    a17d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a181:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a186:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a18b:	49 09 c1             	or     %rax,%r9
    a18e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a192:	4c 89 c8             	mov    %r9,%rax
    a195:	49 f7 f6             	div    %r14
    a198:	48 89 d1             	mov    %rdx,%rcx
    a19b:	49 89 c3             	mov    %rax,%r11
    a19e:	49 89 c1             	mov    %rax,%r9
    a1a1:	49 f7 e2             	mul    %r10
    a1a4:	49 89 c6             	mov    %rax,%r14
    a1a7:	49 89 d2             	mov    %rdx,%r10
    a1aa:	48 39 d1             	cmp    %rdx,%rcx
    a1ad:	72 07                	jb     a1b6 <__divmodti4+0x126>
    a1af:	75 17                	jne    a1c8 <__divmodti4+0x138>
    a1b1:	49 39 c7             	cmp    %rax,%r15
    a1b4:	73 12                	jae    a1c8 <__divmodti4+0x138>
    a1b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a1ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a1be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a1c2:	49 89 d2             	mov    %rdx,%r10
    a1c5:	49 89 c6             	mov    %rax,%r14
    a1c8:	4c 89 f8             	mov    %r15,%rax
    a1cb:	4c 29 f0             	sub    %r14,%rax
    a1ce:	4c 19 d1             	sbb    %r10,%rcx
    a1d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a1d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a1db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a1e0:	48 09 c6             	or     %rax,%rsi
    a1e3:	48 89 cf             	mov    %rcx,%rdi
    a1e6:	31 c0                	xor    %eax,%eax
    a1e8:	4c 89 c9             	mov    %r9,%rcx
    a1eb:	e9 10 ff ff ff       	jmp    a100 <__divmodti4+0x70>
    a1f0:	4c 89 d0             	mov    %r10,%rax
    a1f3:	4c 89 da             	mov    %r11,%rdx
    a1f6:	4d 89 c4             	mov    %r8,%r12
    a1f9:	49 89 f3             	mov    %rsi,%r11
    a1fc:	48 f7 d8             	neg    %rax
    a1ff:	49 f7 d4             	not    %r12
    a202:	48 83 d2 00          	adc    $0x0,%rdx
    a206:	49 89 c2             	mov    %rax,%r10
    a209:	48 f7 da             	neg    %rdx
    a20c:	48 89 d1             	mov    %rdx,%rcx
    a20f:	0f 84 cc fe ff ff    	je     a0e1 <__divmodti4+0x51>
    a215:	49 39 d1             	cmp    %rdx,%r9
    a218:	73 46                	jae    a260 <__divmodti4+0x1d0>
    a21a:	4c 89 cf             	mov    %r9,%rdi
    a21d:	31 c0                	xor    %eax,%eax
    a21f:	31 c9                	xor    %ecx,%ecx
    a221:	e9 da fe ff ff       	jmp    a100 <__divmodti4+0x70>
    a226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a22d:	00 00 00 
    a230:	4d 85 d2             	test   %r10,%r10
    a233:	75 0d                	jne    a242 <__divmodti4+0x1b2>
    a235:	b8 01 00 00 00       	mov    $0x1,%eax
    a23a:	31 d2                	xor    %edx,%edx
    a23c:	49 f7 f2             	div    %r10
    a23f:	49 89 c2             	mov    %rax,%r10
    a242:	4c 89 c8             	mov    %r9,%rax
    a245:	31 d2                	xor    %edx,%edx
    a247:	49 f7 f2             	div    %r10
    a24a:	49 89 c1             	mov    %rax,%r9
    a24d:	4c 89 d8             	mov    %r11,%rax
    a250:	49 f7 f2             	div    %r10
    a253:	49 89 c3             	mov    %rax,%r11
    a256:	4c 89 c8             	mov    %r9,%rax
    a259:	e9 9a fe ff ff       	jmp    a0f8 <__divmodti4+0x68>
    a25e:	66 90                	xchg   %ax,%ax
    a260:	45 31 f6             	xor    %r14d,%r14d
    a263:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a268:	44 89 f7             	mov    %r14d,%edi
    a26b:	45 85 f6             	test   %r14d,%r14d
    a26e:	0f 85 df fe ff ff    	jne    a153 <__divmodti4+0xc3>
    a274:	4c 39 ca             	cmp    %r9,%rdx
    a277:	72 17                	jb     a290 <__divmodti4+0x200>
    a279:	31 c9                	xor    %ecx,%ecx
    a27b:	48 39 c6             	cmp    %rax,%rsi
    a27e:	73 10                	jae    a290 <__divmodti4+0x200>
    a280:	4c 89 cf             	mov    %r9,%rdi
    a283:	31 c0                	xor    %eax,%eax
    a285:	e9 76 fe ff ff       	jmp    a100 <__divmodti4+0x70>
    a28a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a290:	4c 89 de             	mov    %r11,%rsi
    a293:	b9 01 00 00 00       	mov    $0x1,%ecx
    a298:	48 29 c6             	sub    %rax,%rsi
    a29b:	49 19 d1             	sbb    %rdx,%r9
    a29e:	eb e0                	jmp    a280 <__divmodti4+0x1f0>

000000000000a2a0 <atexit>:
    a2a0:	f3 0f 1e fa          	endbr64
    a2a4:	48 8b 15 5d 4d 00 00 	mov    0x4d5d(%rip),%rdx        # f008 <__dso_handle>
    a2ab:	31 f6                	xor    %esi,%esi
    a2ad:	e9 ae 93 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a2b4 <_fini>:
    a2b4:	f3 0f 1e fa          	endbr64
    a2b8:	48 83 ec 08          	sub    $0x8,%rsp
    a2bc:	48 83 c4 08          	add    $0x8,%rsp
    a2c0:	c3                   	ret
