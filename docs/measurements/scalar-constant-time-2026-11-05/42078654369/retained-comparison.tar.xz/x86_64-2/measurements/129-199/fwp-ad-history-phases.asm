
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 dc 00 00 	lea    0xdce1(%rip),%rax        # 11460 <fwp_fn_table>
    377f:	48 89 05 b2 1c 02 00 	mov    %rax,0x21cb2(%rip)        # 25438 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac 1c 02 00 	mov    %rax,0x21cac(%rip)        # 25440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 1f a9 00 00 	lea    0xa91f(%rip),%rdx        # e180 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e c1 00 00 	lea    0xc17e(%rip),%rdi        # fa88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 c1 00 00 	lea    0xc138(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc c0 00 00 	lea    0xc0fc(%rip),%rdi        # fa30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 c0 00 00 	lea    0xc0c8(%rip),%rdi        # fa08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 17 02 00 	mov    0x217c9(%rip),%rdi        # 25440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 fa 01 00 	mov    0x1fac1(%rip),%rax        # 237c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 f3 01 00 	mov    0x1f3f9(%rip),%rax        # 23178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 f3 01 00 	sub    0x1f3e5(%rip),%rax        # 23170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f b8 00 00 	lea    0xb87f(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 f2 00 00 	mov    0xf262(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed f1 00 00 ff 	cmpl   $0xffffffff,0xf1ed(%rip)        # 13020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 f2 01 00 	mov    0x1f2e1(%rip),%r9        # 23128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc f2 01 00 	mov    0x1f2bc(%rip),%r8        # 23120 <descent_inputs>
    3e64:	48 8b 0d c5 f2 01 00 	mov    0x1f2c5(%rip),%rcx        # 23130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 f1 00 00 	mov    0xf1e2(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 b8 00 00 	lea    0xb818(%rip),%rdx        # f6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 f2 01 00 	lea    0x1f291(%rip),%r12        # 23140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b f1 00 00 	mov    0xf17b(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 f1 00 00 	mov    0xf140(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 f1 00 00 	mov    0xf119(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b 0c 02 00 	mov    0x20c3b(%rip),%rax        # 24bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 0c 02 00 	lea    0x20c34(%rip),%r8        # 24bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 0c 02 00 	mov    0x20c15(%rip),%rbx        # 24bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 0c 02 00 	mov    0x20c25(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 0b 02 00 	mov    0x20bc1(%rip),%rdi        # 24bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a 0c 02 00 	sub    %rsi,0x20c0a(%rip)        # 24c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a 0b 02 00 	mov    0x20b9a(%rip),%rax        # 24bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 0b 02 00 	add    0x20b50(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e 0b 02 00 	mov    0x20b5e(%rip),%rsi        # 24bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c 0b 02 00 	mov    0x20b6c(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b 0b 02 00 	mov    %r12,0x20b1b(%rip)        # 24bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 0b 02 00 	mov    %rbp,0x20b09(%rip)        # 24bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee 0a 02 00 	cmp    %rdi,0x20aee(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 0a 02 00 	mov    %rdi,0x20ae5(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 0b 02 00 	sub    %rdi,0x20b29(%rip)        # 24c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 0a 02 00 	mov    0x20ad1(%rip),%rax        # 24bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca 0a 02 00 	lea    0x20aca(%rip),%r8        # 24bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ee 00 00 	mov    0xee7d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 ed 00 00 	movslq 0xedb5(%rip),%rbp        # 13020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ee 01 00 	mov    0x1ee9a(%rip),%rsi        # 23138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ee 01 00 	lea    0x1ee96(%rip),%rcx        # 23140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ee 01 00 	addq   $0x1,0x1ee6b(%rip)        # 23130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 ed 00 00    	mov    %ebx,0xed50(%rip)        # 13020 <descent_active_phase>
    42d0:	48 89 05 61 ee 01 00 	mov    %rax,0x1ee61(%rip)        # 23138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 f4 01 00 	cmp    0x1f4b9(%rip),%rdi        # 237c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f f4 01 00 	mov    0x1f47f(%rip),%rax        # 237a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d f4 01 00 	mov    %rdi,0x1f45d(%rip)        # 237a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 f4 01 00 	mov    %rdi,0x1f439(%rip)        # 237a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 ae 00 00 	lea    0xae18(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 ec 00 00 	mov    0xec48(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 ec 00 00 	mov    0xec30(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 eb 00 00 	mov    0xeb41(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 b1 00 00 	lea    0xb110(%rip),%rdi        # f700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 b5 00 	movdqa 0xb580(%rip),%xmm0        # fb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca 0d 02 00 	add    0x20dca(%rip),%rax        # 25438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 b0 00 00 	lea    0xb064(%rip),%rdi        # f728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ea 01 00 	cmp    %rax,0x1ea25(%rip)        # 23108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ea 01 00 	add    0x1ea20(%rip),%rax        # 23110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d b0 00 00 	lea    0xb04d(%rip),%rdi        # f758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e a5 00 00 	lea    0xa57e(%rip),%rsi        # f20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 fe 01 00 	mov    0x1fea5(%rip),%r9        # 24ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe fe 01 00 	mov    0x1fefe(%rip),%r8        # 24c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 aa 00 00 	lea    0xaa97(%rip),%rdx        # f7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 fe 01 00 	mov    0x1fee6(%rip),%rcx        # 24c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 fe 01 	movsd  0x1fef4(%rip),%xmm1        # 24c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 fe 01 	movsd  0x1fee4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 e3 00 00 	mov    0xe325(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 ae 00 	movdqa 0xae28(%rip),%xmm0        # fba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f f9 01 00 	lea    0x1f99f(%rip),%rax        # 24720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 ae 00 	movdqa 0xae51(%rip),%xmm2        # fbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 f9 01 00 	movaps %xmm0,0x1f945(%rip)        # 246e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d ae 00 	movdqa 0xae0d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 fd 01 00 01 	movl   $0x1,0x1fdd3(%rip)        # 24b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 f9 01 00 	movaps %xmm0,0x1f933(%rip)        # 246f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb ad 00 	movdqa 0xadfb(%rip),%xmm0        # fbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 f9 01 00 	movaps %xmm0,0x1f934(%rip)        # 24700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc ad 00 	movdqa 0xadfc(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 f9 01 00 	movaps %xmm0,0x1f935(%rip)        # 24710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 e9 01 00 	lea    0x1e9b5(%rip),%r8        # 237e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 fc 01 00 	mov    %rax,0x1fcd0(%rip)        # 24b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae fc 01 00 	mov    %r12,0x1fcae(%rip)        # 24ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 fc 01 00 	mov    %rax,0x1fc97(%rip)        # 24b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 fc 01 00 	mov    %rbx,0x1fcb0(%rip)        # 24bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 fc 01 00 	mov    %rsi,0x1fcd9(%rip)        # 24be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 fc 01 00 	mov    %rax,0x1fcb8(%rip)        # 24bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c fc 01 00    	mov    %eax,0x1fc3c(%rip)        # 24b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c e8 01 00 	mov    0x1e82c(%rip),%r8        # 237a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c e7 01 00 	mov    %rbx,0x1e75c(%rip)        # 237a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 e7 01 00 	mov    %r8,0x1e748(%rip)        # 237a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd df 01 00 	lea    0x1dfbd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 df 01 00 	movaps %xmm0,0x1dfa5(%rip)        # 230c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 df 01 00 	movaps %xmm0,0x1dfa2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 df 01 00 	movaps %xmm0,0x1dfa6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 df 01 00 	mov    %rdx,0x1dfa7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 e5 01 00 	mov    0x1e5d7(%rip),%rbx        # 23798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa dd 00 00 	mov    0xddaa(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 a5 00 00 	lea    0xa573(%rip),%rdi        # f830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad e4 01 00 	mov    0x1e4ad(%rip),%rax        # 237a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 e4 01 00 	mov    %rdx,0x1e487(%rip)        # 237a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 e3 01 00 	mov    0x1e3d4(%rip),%rbx        # 23798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 e3 01 00 	mov    %rbx,0x1e391(%rip)        # 23798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 e3 01 00 	mov    %rdx,0x1e391(%rip)        # 237a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 e3 01 00 	lea    0x1e3a6(%rip),%rsi        # 237e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 ff 01 00 	addq   $0x1,0x1ff25(%rip)        # 25428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 a3 00 00 	lea    0xa347(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 a3 00 00 	lea    0xa358(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e e2 01 00 	lea    0x1e25e(%rip),%rcx        # 237e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f fe 01 00 	subq   $0x1,0x1fe5f(%rip)        # 25428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 a2 00 00 	lea    0xa2b3(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 fe 01 00 	cmpq   $0x0,0x1fe40(%rip)        # 25428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 fd 01 00 	sub    %rax,0x1fd95(%rip)        # 25430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 fd 01 00 	add    %r12,0x1fd73(%rip)        # 25430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf f4 01 00 	mov    0x1f4cf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc e0 01 00 	lea    0x1e0cc(%rip),%rax        # 237e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 f4 01 00 	add    0x1f423(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 f3 01 00 	mov    0x1f3f0(%rip),%rsi        # 24b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 f4 01 00 	mov    0x1f411(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 f4 01 00 	add    0x1f405(%rip),%r8        # 24bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd f3 01 	addsd  0x1f3cd(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 df 01 00 	lea    0x1df82(%rip),%rax        # 237e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c f3 01 00 	sub    %rdi,0x1f38c(%rip)        # 24c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 f3 01 	movsd  %xmm0,0x1f3a4(%rip)        # 24c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e f3 01 00 	sub    %rdx,0x1f35e(%rip)        # 24c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 f3 01 	addsd  0x1f364(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 f3 01 	movsd  %xmm0,0x1f358(%rip)        # 24c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef f2 01 00 	mov    0x1f2ef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 f2 01 00 	add    %rcx,0x1f2e9(%rip)        # 24c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 f2 01 00 	cmp    0x1f2a2(%rip),%r9        # 24bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 f2 01 00 	mov    %r9,0x1f299(%rip)        # 24bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a f2 01 00 	cmp    0x1f28a(%rip),%r9        # 24bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d f2 01 00 	mov    %r9,0x1f27d(%rip)        # 24bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 f1 01 00 	add    0x1f193(%rip),%rdi        # 24bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 dd 01 00 	lea    0x1dd70(%rip),%r15        # 237e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 f0 01 00 	add    0x1f0e0(%rip),%r12        # 24b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 f1 01 00 	add    0x1f139(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 f1 01 00 	cmp    %rax,0x1f138(%rip)        # 24c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 f1 01 00 	mov    %rax,0x1f129(%rip)        # 24c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 f1 01 00 	mov    %rax,0x1f128(%rip)        # 24c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 f1 01 	addsd  0x1f124(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c f1 01 	movsd  %xmm0,0x1f11c(%rip)        # 24c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 f0 01 00    	mov    0x1f063(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f dc 01 00 	lea    0x1dc9f(%rip),%rdi        # 237e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 f0 01 00 	add    0x1f058(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 f0 01 00 	cmp    %rax,0x1f053(%rip)        # 24c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 f0 01 00 	mov    %rax,0x1f044(%rip)        # 24c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 f0 01 00 	mov    %rax,0x1f043(%rip)        # 24c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f f0 01 	addsd  0x1f03f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 f0 01 	movsd  %xmm0,0x1f037(%rip)        # 24c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ee 01 00    	mov    0x1eeee(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 db 01 00 	lea    0x1db25(%rip),%rax        # 237e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ee 01 00 	add    0x1eedb(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ee 01 00 	cmp    %rax,0x1eeda(%rip)        # 24c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ee 01 00 	mov    %rax,0x1eecb(%rip)        # 24c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ee 01 00 	mov    %rax,0x1eeca(%rip)        # 24c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ee 01 	addsd  0x1eec6(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ee 01 	movsd  %xmm0,0x1eebe(%rip)        # 24c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c f6 01 00 	add    0x1f64c(%rip),%r9        # 25438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 38          	sub    $0x38,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 a9 01 00 00    	js     61c0 <fwp_p_ad_push+0x1d0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	48 09 d0             	or     %rdx,%rax
    6021:	0f 89 79 01 00 00    	jns    61a0 <fwp_p_ad_push+0x1b0>
    6027:	48 89 f8             	mov    %rdi,%rax
    602a:	48 c1 f8 20          	sar    $0x20,%rax
    602e:	48 85 ff             	test   %rdi,%rdi
    6031:	79 24                	jns    6057 <fwp_p_ad_push+0x67>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	48 89 d0             	mov    %rdx,%rax
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	48 c1 f8 20          	sar    $0x20,%rax
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 89 c7             	mov    %rax,%rdi
    605a:	e8 71 e6 ff ff       	call   46d0 <fwp_tape_of>
    605f:	48 89 c3             	mov    %rax,%rbx
    6062:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6067:	0f 85 76 02 00 00    	jne    62e3 <fwp_p_ad_push+0x2f3>
    606d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6071:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6078:	0f 8f 59 02 00 00    	jg     62d7 <fwp_p_ad_push+0x2e7>
    607e:	44 89 e0             	mov    %r12d,%eax
    6081:	4c 39 f8             	cmp    %r15,%rax
    6084:	0f 8d 41 02 00 00    	jge    62cb <fwp_p_ad_push+0x2db>
    608a:	4d 85 ed             	test   %r13,%r13
    608d:	78 0c                	js     609b <fwp_p_ad_push+0xab>
    608f:	44 89 e8             	mov    %r13d,%eax
    6092:	4c 39 f8             	cmp    %r15,%rax
    6095:	0f 8d 30 02 00 00    	jge    62cb <fwp_p_ad_push+0x2db>
    609b:	4d 89 fe             	mov    %r15,%r14
    609e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    60a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ac:	0f 87 25 02 00 00    	ja     62d7 <fwp_p_ad_push+0x2e7>
    60b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60b6:	48 39 e8             	cmp    %rbp,%rax
    60b9:	0f 8e 31 01 00 00    	jle    61f0 <fwp_p_ad_push+0x200>
    60bf:	48 85 ed             	test   %rbp,%rbp
    60c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    60c7:	48 0f 44 e9          	cmove  %rcx,%rbp
    60cb:	48 39 e8             	cmp    %rbp,%rax
    60ce:	7e 20                	jle    60f0 <fwp_p_ad_push+0x100>
    60d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60d7:	0f 8f 03 01 00 00    	jg     61e0 <fwp_p_ad_push+0x1f0>
    60dd:	48 01 ed             	add    %rbp,%rbp
    60e0:	48 39 e8             	cmp    %rbp,%rax
    60e3:	7f eb                	jg     60d0 <fwp_p_ad_push+0xe0>
    60e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60ec:	00 00 00 00 
    60f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    60f7:	00 
    60f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60fc:	48 89 c6             	mov    %rax,%rsi
    60ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6104:	e8 c7 d4 ff ff       	call   35d0 <realloc@plt>
    6109:	48 85 c0             	test   %rax,%rax
    610c:	0f 84 dd 01 00 00    	je     62ef <fwp_p_ad_push+0x2ff>
    6112:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6116:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    611a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    611e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6122:	48 89 e9             	mov    %rbp,%rcx
    6125:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6129:	48 c1 e1 04          	shl    $0x4,%rcx
    612d:	48 89 ce             	mov    %rcx,%rsi
    6130:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6135:	e8 96 d4 ff ff       	call   35d0 <realloc@plt>
    613a:	48 85 c0             	test   %rax,%rax
    613d:	0f 84 ac 01 00 00    	je     62ef <fwp_p_ad_push+0x2ff>
    6143:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6147:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    614c:	4d 85 f6             	test   %r14,%r14
    614f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6153:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6158:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    615f:	00 
    6160:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6167:	00 
    6168:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    616c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6173:	00 
    6174:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6178:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    617c:	0f 85 e2 00 00 00    	jne    6264 <fwp_p_ad_push+0x274>
    6182:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6186:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    618a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    618e:	49 01 c8             	add    %rcx,%r8
    6191:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6195:	eb 79                	jmp    6210 <fwp_p_ad_push+0x220>
    6197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    619e:	00 00 
    61a0:	48 89 d0             	mov    %rdx,%rax
    61a3:	48 c1 ff 20          	sar    $0x20,%rdi
    61a7:	48 c1 f8 20          	sar    $0x20,%rax
    61ab:	48 39 c7             	cmp    %rax,%rdi
    61ae:	0f 84 a3 fe ff ff    	je     6057 <fwp_p_ad_push+0x67>
    61b4:	48 8d 3d f5 96 00 00 	lea    0x96f5(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    61bb:	e8 30 e2 ff ff       	call   43f0 <fwp_trap>
    61c0:	48 83 c4 38          	add    $0x38,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 06 ff ff ff       	jmp    60f0 <fwp_p_ad_push+0x100>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61ff:	00 
    6200:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6207:	00 
    6208:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    620c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6210:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6216:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    621a:	4d 85 ed             	test   %r13,%r13
    621d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6222:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6228:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6233:	49 8d 47 01          	lea    0x1(%r15),%rax
    6237:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    623b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6241:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6245:	48 83 c4 38          	add    $0x38,%rsp
    6249:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6250:	ff ff ff 
    6253:	4c 21 e0             	and    %r12,%rax
    6256:	5b                   	pop    %rbx
    6257:	5d                   	pop    %rbp
    6258:	4c 09 f8             	or     %r15,%rax
    625b:	41 5c                	pop    %r12
    625d:	41 5d                	pop    %r13
    625f:	41 5e                	pop    %r14
    6261:	41 5f                	pop    %r15
    6263:	c3                   	ret
    6264:	48 39 ca             	cmp    %rcx,%rdx
    6267:	49 89 d6             	mov    %rdx,%r14
    626a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    626f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6273:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6278:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    627d:	48 29 d1             	sub    %rdx,%rcx
    6280:	4c 89 ca             	mov    %r9,%rdx
    6283:	e8 d8 d2 ff ff       	call   3560 <__memmove_chk@plt>
    6288:	4c 03 73 30          	add    0x30(%rbx),%r14
    628c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6291:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6295:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    629a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    629e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    62a2:	4c 89 d2             	mov    %r10,%rdx
    62a5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    62aa:	e8 61 d3 ff ff       	call   3610 <memmove@plt>
    62af:	48 8b 43 30          	mov    0x30(%rbx),%rax
    62b3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62b7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    62bc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    62c1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    62c6:	e9 bb fe ff ff       	jmp    6186 <fwp_p_ad_push+0x196>
    62cb:	48 8d 3d 95 8e 00 00 	lea    0x8e95(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    62d2:	e8 19 e1 ff ff       	call   43f0 <fwp_trap>
    62d7:	48 8d 3d 6e 8e 00 00 	lea    0x8e6e(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    62de:	e8 0d e1 ff ff       	call   43f0 <fwp_trap>
    62e3:	48 8d 3d 0e 96 00 00 	lea    0x960e(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    62ea:	e8 01 e1 ff ff       	call   43f0 <fwp_trap>
    62ef:	48 89 df             	mov    %rbx,%rdi
    62f2:	e8 09 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    62f7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    62fb:	e8 c0 d0 ff ff       	call   33c0 <free@plt>
    6300:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6304:	e8 b7 d0 ff ff       	call   33c0 <free@plt>
    6309:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    630d:	e8 ae d0 ff ff       	call   33c0 <free@plt>
    6312:	31 c9                	xor    %ecx,%ecx
    6314:	31 c0                	xor    %eax,%eax
    6316:	31 d2                	xor    %edx,%edx
    6318:	89 53 04             	mov    %edx,0x4(%rbx)
    631b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    631f:	ba 13 00 00 00       	mov    $0x13,%edx
    6324:	be 01 00 00 00       	mov    $0x1,%esi
    6329:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    632d:	48 8d 3d d4 8c 00 00 	lea    0x8cd4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6334:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6338:	48 8b 0d 21 cd 00 00 	mov    0xcd21(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    633f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6343:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6347:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    634b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    634f:	e8 2c d3 ff ff       	call   3680 <fwrite@plt>
    6354:	31 ff                	xor    %edi,%edi
    6356:	e8 65 d2 ff ff       	call   35c0 <fflush@plt>
    635b:	bf 66 00 00 00       	mov    $0x66,%edi
    6360:	e8 3b d3 ff ff       	call   36a0 <_Exit@plt>
    6365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    636c:	00 00 00 00 

0000000000006370 <w107>:
    6370:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6374:	41 55                	push   %r13
    6376:	48 89 fa             	mov    %rdi,%rdx
    6379:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    637d:	41 54                	push   %r12
    637f:	49 89 fc             	mov    %rdi,%r12
    6382:	55                   	push   %rbp
    6383:	53                   	push   %rbx
    6384:	48 89 f3             	mov    %rsi,%rbx
    6387:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    638c:	48 89 f1             	mov    %rsi,%rcx
    638f:	48 83 ec 28          	sub    $0x28,%rsp
    6393:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6399:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    639f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63a5:	e8 46 fc ff ff       	call   5ff0 <fwp_p_ad_push>
    63aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    63b0:	48 89 da             	mov    %rbx,%rdx
    63b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63c0:	00 f0 3f 
    63c3:	48 89 c7             	mov    %rax,%rdi
    63c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    63cd:	00 f0 bf 
    63d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    63d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63db:	e8 10 fc ff ff       	call   5ff0 <fwp_p_ad_push>
    63e0:	f2 0f 10 05 38 98 00 	movsd  0x9838(%rip),%xmm0        # fc20 <msg.4+0xb0>
    63e7:	00 
    63e8:	4c 89 e7             	mov    %r12,%rdi
    63eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    63f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63f8:	00 f0 3f 
    63fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6402:	49 89 c5             	mov    %rax,%r13
    6405:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    640c:	00 f0 bf 
    640f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6414:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    641a:	e8 d1 fb ff ff       	call   5ff0 <fwp_p_ad_push>
    641f:	48 89 e9             	mov    %rbp,%rcx
    6422:	4c 89 ea             	mov    %r13,%rdx
    6425:	48 89 ee             	mov    %rbp,%rsi
    6428:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    642e:	4c 89 ef             	mov    %r13,%rdi
    6431:	49 89 c4             	mov    %rax,%r12
    6434:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6438:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    643e:	e8 ad fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6443:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6449:	f2 0f 59 1d d7 97 00 	mulsd  0x97d7(%rip),%xmm3        # fc28 <msg.4+0xb8>
    6450:	00 
    6451:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6458:	00 59 40 
    645b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6460:	48 89 c2             	mov    %rax,%rdx
    6463:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    646a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6470:	e8 7b fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6475:	48 89 d9             	mov    %rbx,%rcx
    6478:	4c 89 e2             	mov    %r12,%rdx
    647b:	48 89 de             	mov    %rbx,%rsi
    647e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6484:	4c 89 e7             	mov    %r12,%rdi
    6487:	48 89 c5             	mov    %rax,%rbp
    648a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    648e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6494:	e8 57 fb ff ff       	call   5ff0 <fwp_p_ad_push>
    6499:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    649f:	48 89 ea             	mov    %rbp,%rdx
    64a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    64a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64af:	00 f0 3f 
    64b2:	48 89 c7             	mov    %rax,%rdi
    64b5:	48 89 ce             	mov    %rcx,%rsi
    64b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    64bd:	e8 2e fb ff ff       	call   5ff0 <fwp_p_ad_push>
    64c2:	48 83 c4 28          	add    $0x28,%rsp
    64c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	c3                   	ret
    64d2:	0f 1f 00             	nopl   (%rax)
    64d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64dc:	00 00 00 00 

00000000000064e0 <fwp_data.part.0.constprop.0>:
    64e0:	41 56                	push   %r14
    64e2:	41 89 fe             	mov    %edi,%r14d
    64e5:	41 54                	push   %r12
    64e7:	49 89 f4             	mov    %rsi,%r12
    64ea:	55                   	push   %rbp
    64eb:	53                   	push   %rbx
    64ec:	48 83 ec 08          	sub    $0x8,%rsp
    64f0:	8b 05 8e e6 01 00    	mov    0x1e68e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    64f6:	85 c0                	test   %eax,%eax
    64f8:	0f 84 fa 00 00 00    	je     65f8 <fwp_data.part.0.constprop.0+0x118>
    64fe:	0f b6 05 7d e2 01 00 	movzbl 0x1e27d(%rip),%eax        # 24782 <fwp_heap+0xfa2>
    6505:	48 8d 15 d4 d2 01 00 	lea    0x1d2d4(%rip),%rdx        # 237e0 <fwp_heap>
    650c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6513:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6517:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    651b:	48 8b 18             	mov    (%rax),%rbx
    651e:	48 85 db             	test   %rbx,%rbx
    6521:	0f 84 a9 00 00 00    	je     65d0 <fwp_data.part.0.constprop.0+0xf0>
    6527:	48 8b 13             	mov    (%rbx),%rdx
    652a:	48 f7 d2             	not    %rdx
    652d:	48 89 10             	mov    %rdx,(%rax)
    6530:	48 83 fd 18          	cmp    $0x18,%rbp
    6534:	76 1b                	jbe    6551 <fwp_data.part.0.constprop.0+0x71>
    6536:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    653a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    653e:	31 f6                	xor    %esi,%esi
    6540:	48 c1 e8 03          	shr    $0x3,%rax
    6544:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    654b:	00 
    654c:	e8 6f cf ff ff       	call   34c0 <memset@plt>
    6551:	48 89 e8             	mov    %rbp,%rax
    6554:	48 03 05 a5 e6 01 00 	add    0x1e6a5(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    655b:	0f 82 a8 00 00 00    	jb     6609 <fwp_data.part.0.constprop.0+0x129>
    6561:	48 39 05 a0 e6 01 00 	cmp    %rax,0x1e6a0(%rip)        # 24c08 <fwp_heap+0x1428>
    6568:	48 89 05 91 e6 01 00 	mov    %rax,0x1e691(%rip)        # 24c00 <fwp_heap+0x1420>
    656f:	73 07                	jae    6578 <fwp_data.part.0.constprop.0+0x98>
    6571:	48 89 05 90 e6 01 00 	mov    %rax,0x1e690(%rip)        # 24c08 <fwp_heap+0x1428>
    6578:	66 0f ef c0          	pxor   %xmm0,%xmm0
    657c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6581:	f2 0f 58 05 8f e6 01 	addsd  0x1e68f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    6588:	00 
    6589:	f2 0f 11 05 87 e6 01 	movsd  %xmm0,0x1e687(%rip)        # 24c18 <fwp_heap+0x1438>
    6590:	00 
    6591:	b8 02 00 00 00       	mov    $0x2,%eax
    6596:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    659b:	66 0f 6e c8          	movd   %eax,%xmm1
    659f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    65a3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    65a7:	49 8b 04 24          	mov    (%r12),%rax
    65ab:	48 89 43 08          	mov    %rax,0x8(%rbx)
    65af:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    65b4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65b8:	48 83 c4 08          	add    $0x8,%rsp
    65bc:	48 89 d8             	mov    %rbx,%rax
    65bf:	5b                   	pop    %rbx
    65c0:	5d                   	pop    %rbp
    65c1:	41 5c                	pop    %r12
    65c3:	41 5e                	pop    %r14
    65c5:	c3                   	ret
    65c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65cd:	00 00 00 
    65d0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    65d4:	48 85 db             	test   %rbx,%rbx
    65d7:	74 1f                	je     65f8 <fwp_data.part.0.constprop.0+0x118>
    65d9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    65dd:	48 29 da             	sub    %rbx,%rdx
    65e0:	48 39 ea             	cmp    %rbp,%rdx
    65e3:	72 13                	jb     65f8 <fwp_data.part.0.constprop.0+0x118>
    65e5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    65e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    65ed:	e9 3e ff ff ff       	jmp    6530 <fwp_data.part.0.constprop.0+0x50>
    65f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65f8:	31 f6                	xor    %esi,%esi
    65fa:	bf 18 00 00 00       	mov    $0x18,%edi
    65ff:	e8 8c f6 ff ff       	call   5c90 <fwp_heap_alloc>
    6604:	48 89 c3             	mov    %rax,%rbx
    6607:	eb 88                	jmp    6591 <fwp_data.part.0.constprop.0+0xb1>
    6609:	e8 a2 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    660e:	66 90                	xchg   %ax,%ax

0000000000006610 <fwp_rc_share>:
    6610:	48 8b 05 a1 e5 01 00 	mov    0x1e5a1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6617:	48 2b 3d 72 e5 01 00 	sub    0x1e572(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    661e:	48 c1 e0 10          	shl    $0x10,%rax
    6622:	48 39 c7             	cmp    %rax,%rdi
    6625:	73 4a                	jae    6671 <fwp_rc_share+0x61>
    6627:	48 89 f8             	mov    %rdi,%rax
    662a:	48 c1 e8 10          	shr    $0x10,%rax
    662e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6632:	48 8b 05 9f e5 01 00 	mov    0x1e59f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6639:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    663d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6641:	48 85 d2             	test   %rdx,%rdx
    6644:	74 2b                	je     6671 <fwp_rc_share+0x61>
    6646:	0f b6 08             	movzbl (%rax),%ecx
    6649:	80 f9 02             	cmp    $0x2,%cl
    664c:	74 2a                	je     6678 <fwp_rc_share+0x68>
    664e:	80 f9 01             	cmp    $0x1,%cl
    6651:	75 1e                	jne    6671 <fwp_rc_share+0x61>
    6653:	8b 48 18             	mov    0x18(%rax),%ecx
    6656:	0f b7 ff             	movzwl %di,%edi
    6659:	8b 40 1c             	mov    0x1c(%rax),%eax
    665c:	48 0f af f9          	imul   %rcx,%rdi
    6660:	48 c1 ef 20          	shr    $0x20,%rdi
    6664:	48 39 c7             	cmp    %rax,%rdi
    6667:	73 08                	jae    6671 <fwp_rc_share+0x61>
    6669:	48 01 fa             	add    %rdi,%rdx
    666c:	80 3a 00             	cmpb   $0x0,(%rdx)
    666f:	75 0d                	jne    667e <fwp_rc_share+0x6e>
    6671:	c3                   	ret
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	66 85 ff             	test   %di,%di
    667b:	74 ef                	je     666c <fwp_rc_share+0x5c>
    667d:	c3                   	ret
    667e:	50                   	push   %rax
    667f:	48 8d 3d a2 92 00 00 	lea    0x92a2(%rip),%rdi        # f928 <_IO_stdin_used+0x928>
    6686:	e8 65 dd ff ff       	call   43f0 <fwp_trap>
    668b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006690 <fwp_rc_fresh>:
    6690:	48 8b 15 21 e5 01 00 	mov    0x1e521(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6697:	48 89 f8             	mov    %rdi,%rax
    669a:	48 89 fe             	mov    %rdi,%rsi
    669d:	48 2b 05 ec e4 01 00 	sub    0x1e4ec(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    66a4:	48 c1 e2 10          	shl    $0x10,%rdx
    66a8:	48 39 d0             	cmp    %rdx,%rax
    66ab:	73 4f                	jae    66fc <fwp_rc_fresh+0x6c>
    66ad:	48 89 c2             	mov    %rax,%rdx
    66b0:	48 c1 ea 10          	shr    $0x10,%rdx
    66b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66b8:	48 8b 15 19 e5 01 00 	mov    0x1e519(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    66bf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66c3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66c7:	48 85 d2             	test   %rdx,%rdx
    66ca:	74 30                	je     66fc <fwp_rc_fresh+0x6c>
    66cc:	0f b6 39             	movzbl (%rcx),%edi
    66cf:	40 80 ff 02          	cmp    $0x2,%dil
    66d3:	74 2b                	je     6700 <fwp_rc_fresh+0x70>
    66d5:	40 80 ff 01          	cmp    $0x1,%dil
    66d9:	75 21                	jne    66fc <fwp_rc_fresh+0x6c>
    66db:	8b 79 18             	mov    0x18(%rcx),%edi
    66de:	0f b7 c0             	movzwl %ax,%eax
    66e1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66e4:	48 0f af c7          	imul   %rdi,%rax
    66e8:	48 c1 e8 20          	shr    $0x20,%rax
    66ec:	48 39 c8             	cmp    %rcx,%rax
    66ef:	73 0b                	jae    66fc <fwp_rc_fresh+0x6c>
    66f1:	48 01 c2             	add    %rax,%rdx
    66f4:	80 3a ff             	cmpb   $0xff,(%rdx)
    66f7:	74 17                	je     6710 <fwp_rc_fresh+0x80>
    66f9:	c6 02 01             	movb   $0x1,(%rdx)
    66fc:	48 89 f0             	mov    %rsi,%rax
    66ff:	c3                   	ret
    6700:	66 85 c0             	test   %ax,%ax
    6703:	74 ef                	je     66f4 <fwp_rc_fresh+0x64>
    6705:	48 89 f0             	mov    %rsi,%rax
    6708:	c3                   	ret
    6709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6710:	48 83 ec 18          	sub    $0x18,%rsp
    6714:	48 89 d7             	mov    %rdx,%rdi
    6717:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    671c:	48 89 14 24          	mov    %rdx,(%rsp)
    6720:	e8 2b ee ff ff       	call   5550 <fwp_rc_forget_slot>
    6725:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    672a:	48 8b 14 24          	mov    (%rsp),%rdx
    672e:	48 89 f0             	mov    %rsi,%rax
    6731:	c6 02 01             	movb   $0x1,(%rdx)
    6734:	48 83 c4 18          	add    $0x18,%rsp
    6738:	c3                   	ret
    6739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006740 <fwp_rc_free_arr>:
    6740:	48 8b 15 71 e4 01 00 	mov    0x1e471(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6747:	48 89 f8             	mov    %rdi,%rax
    674a:	48 2b 05 3f e4 01 00 	sub    0x1e43f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6751:	48 c1 e2 10          	shl    $0x10,%rdx
    6755:	48 39 d0             	cmp    %rdx,%rax
    6758:	73 5b                	jae    67b5 <fwp_rc_free_arr+0x75>
    675a:	48 89 c2             	mov    %rax,%rdx
    675d:	48 c1 ea 10          	shr    $0x10,%rdx
    6761:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6765:	48 8b 15 6c e4 01 00 	mov    0x1e46c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    676c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6770:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6774:	48 85 c9             	test   %rcx,%rcx
    6777:	74 3c                	je     67b5 <fwp_rc_free_arr+0x75>
    6779:	0f b6 32             	movzbl (%rdx),%esi
    677c:	40 80 fe 02          	cmp    $0x2,%sil
    6780:	74 2e                	je     67b0 <fwp_rc_free_arr+0x70>
    6782:	40 80 fe 01          	cmp    $0x1,%sil
    6786:	75 2d                	jne    67b5 <fwp_rc_free_arr+0x75>
    6788:	8b 72 18             	mov    0x18(%rdx),%esi
    678b:	0f b7 c0             	movzwl %ax,%eax
    678e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6791:	48 0f af c6          	imul   %rsi,%rax
    6795:	48 c1 e8 20          	shr    $0x20,%rax
    6799:	48 39 d0             	cmp    %rdx,%rax
    679c:	73 17                	jae    67b5 <fwp_rc_free_arr+0x75>
    679e:	48 01 c1             	add    %rax,%rcx
    67a1:	80 39 01             	cmpb   $0x1,(%rcx)
    67a4:	75 0f                	jne    67b5 <fwp_rc_free_arr+0x75>
    67a6:	e9 e5 ef ff ff       	jmp    5790 <fwp_mem_free>
    67ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67b0:	66 85 c0             	test   %ax,%ax
    67b3:	74 ec                	je     67a1 <fwp_rc_free_arr+0x61>
    67b5:	c3                   	ret
    67b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67bd:	00 00 00 

00000000000067c0 <fwp_rc_dup>:
    67c0:	f3 0f 1e fa          	endbr64
    67c4:	48 8b 05 ed e3 01 00 	mov    0x1e3ed(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    67cb:	48 2b 3d be e3 01 00 	sub    0x1e3be(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    67d2:	48 c1 e0 10          	shl    $0x10,%rax
    67d6:	48 39 c7             	cmp    %rax,%rdi
    67d9:	73 56                	jae    6831 <fwp_rc_dup+0x71>
    67db:	48 89 f8             	mov    %rdi,%rax
    67de:	48 c1 e8 10          	shr    $0x10,%rax
    67e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67e6:	48 8b 05 eb e3 01 00 	mov    0x1e3eb(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    67ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    67f1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    67f5:	48 85 c0             	test   %rax,%rax
    67f8:	74 37                	je     6831 <fwp_rc_dup+0x71>
    67fa:	0f b6 0a             	movzbl (%rdx),%ecx
    67fd:	80 f9 02             	cmp    $0x2,%cl
    6800:	74 36                	je     6838 <fwp_rc_dup+0x78>
    6802:	80 f9 01             	cmp    $0x1,%cl
    6805:	75 2a                	jne    6831 <fwp_rc_dup+0x71>
    6807:	8b 4a 18             	mov    0x18(%rdx),%ecx
    680a:	0f b7 ff             	movzwl %di,%edi
    680d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6810:	48 0f af f9          	imul   %rcx,%rdi
    6814:	48 c1 ef 20          	shr    $0x20,%rdi
    6818:	48 39 d7             	cmp    %rdx,%rdi
    681b:	73 14                	jae    6831 <fwp_rc_dup+0x71>
    681d:	48 01 f8             	add    %rdi,%rax
    6820:	0f b6 10             	movzbl (%rax),%edx
    6823:	84 d2                	test   %dl,%dl
    6825:	74 0a                	je     6831 <fwp_rc_dup+0x71>
    6827:	80 fa fd             	cmp    $0xfd,%dl
    682a:	77 14                	ja     6840 <fwp_rc_dup+0x80>
    682c:	83 c2 01             	add    $0x1,%edx
    682f:	88 10                	mov    %dl,(%rax)
    6831:	c3                   	ret
    6832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6838:	66 85 ff             	test   %di,%di
    683b:	74 e3                	je     6820 <fwp_rc_dup+0x60>
    683d:	c3                   	ret
    683e:	66 90                	xchg   %ax,%ax
    6840:	48 89 c7             	mov    %rax,%rdi
    6843:	e9 e8 eb ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    684f:	00 

0000000000006850 <fwp_owned_entry161>:
    6850:	f3 0f 1e fa          	endbr64
    6854:	48 83 ec 38          	sub    $0x38,%rsp
    6858:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    685d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6864:	00 00 
    6866:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    686b:	31 c0                	xor    %eax,%eax
    686d:	48 8b 07             	mov    (%rdi),%rax
    6870:	48 03 47 10          	add    0x10(%rdi),%rax
    6874:	0f 80 c2 00 00 00    	jo     693c <fwp_owned_entry161+0xec>
    687a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    687f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6884:	31 ff                	xor    %edi,%edi
    6886:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    688a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    688f:	e8 4c fc ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    6894:	48 8b 15 1d e3 01 00 	mov    0x1e31d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    689b:	48 89 c6             	mov    %rax,%rsi
    689e:	48 2b 05 eb e2 01 00 	sub    0x1e2eb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    68a5:	48 c1 e2 10          	shl    $0x10,%rdx
    68a9:	48 39 d0             	cmp    %rdx,%rax
    68ac:	73 4f                	jae    68fd <fwp_owned_entry161+0xad>
    68ae:	48 89 c2             	mov    %rax,%rdx
    68b1:	48 c1 ea 10          	shr    $0x10,%rdx
    68b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68b9:	48 8b 15 18 e3 01 00 	mov    0x1e318(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    68c0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68c4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68c8:	48 85 d2             	test   %rdx,%rdx
    68cb:	74 30                	je     68fd <fwp_owned_entry161+0xad>
    68cd:	0f b6 39             	movzbl (%rcx),%edi
    68d0:	40 80 ff 02          	cmp    $0x2,%dil
    68d4:	74 42                	je     6918 <fwp_owned_entry161+0xc8>
    68d6:	40 80 ff 01          	cmp    $0x1,%dil
    68da:	75 21                	jne    68fd <fwp_owned_entry161+0xad>
    68dc:	8b 79 18             	mov    0x18(%rcx),%edi
    68df:	0f b7 c0             	movzwl %ax,%eax
    68e2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68e5:	48 0f af c7          	imul   %rdi,%rax
    68e9:	48 c1 e8 20          	shr    $0x20,%rax
    68ed:	48 39 c8             	cmp    %rcx,%rax
    68f0:	73 0b                	jae    68fd <fwp_owned_entry161+0xad>
    68f2:	48 01 c2             	add    %rax,%rdx
    68f5:	80 3a ff             	cmpb   $0xff,(%rdx)
    68f8:	74 26                	je     6920 <fwp_owned_entry161+0xd0>
    68fa:	c6 02 01             	movb   $0x1,(%rdx)
    68fd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6902:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6909:	00 00 
    690b:	75 34                	jne    6941 <fwp_owned_entry161+0xf1>
    690d:	48 89 f0             	mov    %rsi,%rax
    6910:	48 83 c4 38          	add    $0x38,%rsp
    6914:	c3                   	ret
    6915:	0f 1f 00             	nopl   (%rax)
    6918:	66 85 c0             	test   %ax,%ax
    691b:	75 e0                	jne    68fd <fwp_owned_entry161+0xad>
    691d:	eb d6                	jmp    68f5 <fwp_owned_entry161+0xa5>
    691f:	90                   	nop
    6920:	48 89 d7             	mov    %rdx,%rdi
    6923:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6928:	48 89 14 24          	mov    %rdx,(%rsp)
    692c:	e8 1f ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6931:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6936:	48 8b 14 24          	mov    (%rsp),%rdx
    693a:	eb be                	jmp    68fa <fwp_owned_entry161+0xaa>
    693c:	e8 bf cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6941:	e8 1a cb ff ff       	call   3460 <__stack_chk_fail@plt>
    6946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    694d:	00 00 00 

0000000000006950 <e161>:
    6950:	f3 0f 1e fa          	endbr64
    6954:	53                   	push   %rbx
    6955:	48 83 ec 30          	sub    $0x30,%rsp
    6959:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    695e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6965:	00 00 
    6967:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    696c:	31 c0                	xor    %eax,%eax
    696e:	48 8b 07             	mov    (%rdi),%rax
    6971:	48 03 47 10          	add    0x10(%rdi),%rax
    6975:	0f 80 c9 00 00 00    	jo     6a44 <e161+0xf4>
    697b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6980:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6985:	31 ff                	xor    %edi,%edi
    6987:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    698b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6990:	e8 4b fb ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    6995:	48 8b 15 1c e2 01 00 	mov    0x1e21c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    699c:	48 89 c3             	mov    %rax,%rbx
    699f:	48 2b 05 ea e1 01 00 	sub    0x1e1ea(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    69a6:	48 c1 e2 10          	shl    $0x10,%rdx
    69aa:	48 39 d0             	cmp    %rdx,%rax
    69ad:	73 4f                	jae    69fe <e161+0xae>
    69af:	48 89 c2             	mov    %rax,%rdx
    69b2:	48 c1 ea 10          	shr    $0x10,%rdx
    69b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69ba:	48 8b 15 17 e2 01 00 	mov    0x1e217(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    69c1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69c5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69c9:	48 85 d2             	test   %rdx,%rdx
    69cc:	74 30                	je     69fe <e161+0xae>
    69ce:	0f b6 31             	movzbl (%rcx),%esi
    69d1:	40 80 fe 02          	cmp    $0x2,%sil
    69d5:	74 49                	je     6a20 <e161+0xd0>
    69d7:	40 80 fe 01          	cmp    $0x1,%sil
    69db:	75 21                	jne    69fe <e161+0xae>
    69dd:	8b 71 18             	mov    0x18(%rcx),%esi
    69e0:	0f b7 c0             	movzwl %ax,%eax
    69e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69e6:	48 0f af c6          	imul   %rsi,%rax
    69ea:	48 c1 e8 20          	shr    $0x20,%rax
    69ee:	48 39 c8             	cmp    %rcx,%rax
    69f1:	73 0b                	jae    69fe <e161+0xae>
    69f3:	48 01 c2             	add    %rax,%rdx
    69f6:	80 3a ff             	cmpb   $0xff,(%rdx)
    69f9:	74 35                	je     6a30 <e161+0xe0>
    69fb:	c6 02 01             	movb   $0x1,(%rdx)
    69fe:	48 89 df             	mov    %rbx,%rdi
    6a01:	e8 0a fc ff ff       	call   6610 <fwp_rc_share>
    6a06:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a0b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a12:	00 00 
    6a14:	75 33                	jne    6a49 <e161+0xf9>
    6a16:	48 83 c4 30          	add    $0x30,%rsp
    6a1a:	48 89 d8             	mov    %rbx,%rax
    6a1d:	5b                   	pop    %rbx
    6a1e:	c3                   	ret
    6a1f:	90                   	nop
    6a20:	66 85 c0             	test   %ax,%ax
    6a23:	75 d9                	jne    69fe <e161+0xae>
    6a25:	eb cf                	jmp    69f6 <e161+0xa6>
    6a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a2e:	00 00 
    6a30:	48 89 d7             	mov    %rdx,%rdi
    6a33:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a38:	e8 13 eb ff ff       	call   5550 <fwp_rc_forget_slot>
    6a3d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a42:	eb b7                	jmp    69fb <e161+0xab>
    6a44:	e8 b7 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a49:	e8 12 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a4e:	66 90                	xchg   %ax,%ax

0000000000006a50 <fwp_drop0>:
    6a50:	f3 0f 1e fa          	endbr64
    6a54:	48 8b 15 5d e1 01 00 	mov    0x1e15d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6a5b:	48 89 f8             	mov    %rdi,%rax
    6a5e:	48 2b 05 2b e1 01 00 	sub    0x1e12b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6a65:	48 c1 e2 10          	shl    $0x10,%rdx
    6a69:	48 39 d0             	cmp    %rdx,%rax
    6a6c:	0f 83 be 00 00 00    	jae    6b30 <fwp_drop0+0xe0>
    6a72:	48 83 ec 18          	sub    $0x18,%rsp
    6a76:	4c 8d 05 63 cd 01 00 	lea    0x1cd63(%rip),%r8        # 237e0 <fwp_heap>
    6a7d:	48 89 c2             	mov    %rax,%rdx
    6a80:	48 c1 ea 10          	shr    $0x10,%rdx
    6a84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a88:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a8f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a97:	48 85 d2             	test   %rdx,%rdx
    6a9a:	74 3c                	je     6ad8 <fwp_drop0+0x88>
    6a9c:	0f b6 31             	movzbl (%rcx),%esi
    6a9f:	40 80 fe 02          	cmp    $0x2,%sil
    6aa3:	74 3b                	je     6ae0 <fwp_drop0+0x90>
    6aa5:	40 80 fe 01          	cmp    $0x1,%sil
    6aa9:	75 2d                	jne    6ad8 <fwp_drop0+0x88>
    6aab:	8b 71 18             	mov    0x18(%rcx),%esi
    6aae:	0f b7 c0             	movzwl %ax,%eax
    6ab1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ab4:	48 0f af c6          	imul   %rsi,%rax
    6ab8:	48 c1 e8 20          	shr    $0x20,%rax
    6abc:	48 39 c8             	cmp    %rcx,%rax
    6abf:	73 17                	jae    6ad8 <fwp_drop0+0x88>
    6ac1:	48 01 c2             	add    %rax,%rdx
    6ac4:	0f b6 02             	movzbl (%rdx),%eax
    6ac7:	84 c0                	test   %al,%al
    6ac9:	74 0d                	je     6ad8 <fwp_drop0+0x88>
    6acb:	3c 01                	cmp    $0x1,%al
    6acd:	74 21                	je     6af0 <fwp_drop0+0xa0>
    6acf:	3c ff                	cmp    $0xff,%al
    6ad1:	74 65                	je     6b38 <fwp_drop0+0xe8>
    6ad3:	83 e8 01             	sub    $0x1,%eax
    6ad6:	88 02                	mov    %al,(%rdx)
    6ad8:	48 83 c4 18          	add    $0x18,%rsp
    6adc:	c3                   	ret
    6add:	0f 1f 00             	nopl   (%rax)
    6ae0:	66 85 c0             	test   %ax,%ax
    6ae3:	74 df                	je     6ac4 <fwp_drop0+0x74>
    6ae5:	48 83 c4 18          	add    $0x18,%rsp
    6ae9:	c3                   	ret
    6aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6af4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6af9:	e8 42 fc ff ff       	call   6740 <fwp_rc_free_arr>
    6afe:	4c 8d 05 db cc 01 00 	lea    0x1ccdb(%rip),%r8        # 237e0 <fwp_heap>
    6b05:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6b0a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b11:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b18:	48 c1 e2 10          	shl    $0x10,%rdx
    6b1c:	48 39 d0             	cmp    %rdx,%rax
    6b1f:	73 b7                	jae    6ad8 <fwp_drop0+0x88>
    6b21:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b26:	e9 52 ff ff ff       	jmp    6a7d <fwp_drop0+0x2d>
    6b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b30:	c3                   	ret
    6b31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b38:	48 89 d0             	mov    %rdx,%rax
    6b3b:	48 c1 e8 11          	shr    $0x11,%rax
    6b3f:	48 31 d0             	xor    %rdx,%rax
    6b42:	48 89 c1             	mov    %rax,%rcx
    6b45:	48 c1 e9 09          	shr    $0x9,%rcx
    6b49:	48 31 c8             	xor    %rcx,%rax
    6b4c:	0f b6 c8             	movzbl %al,%ecx
    6b4f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6b56:	00 
    6b57:	48 85 c0             	test   %rax,%rax
    6b5a:	75 0d                	jne    6b69 <fwp_drop0+0x119>
    6b5c:	eb 46                	jmp    6ba4 <fwp_drop0+0x154>
    6b5e:	66 90                	xchg   %ax,%ax
    6b60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b64:	48 85 c0             	test   %rax,%rax
    6b67:	74 3b                	je     6ba4 <fwp_drop0+0x154>
    6b69:	48 89 c1             	mov    %rax,%rcx
    6b6c:	48 39 10             	cmp    %rdx,(%rax)
    6b6f:	75 ef                	jne    6b60 <fwp_drop0+0x110>
    6b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b84:	0f 85 4e ff ff ff    	jne    6ad8 <fwp_drop0+0x88>
    6b8a:	48 89 d7             	mov    %rdx,%rdi
    6b8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b92:	e8 b9 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6b97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6b9f:	e9 34 ff ff ff       	jmp    6ad8 <fwp_drop0+0x88>
    6ba4:	48 8d 3d dd 8c 00 00 	lea    0x8cdd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6bab:	e8 40 d8 ff ff       	call   43f0 <fwp_trap>

0000000000006bb0 <fwp_arg_drop12>:
    6bb0:	f3 0f 1e fa          	endbr64
    6bb4:	85 f6                	test   %esi,%esi
    6bb6:	75 04                	jne    6bbc <fwp_arg_drop12+0xc>
    6bb8:	85 d2                	test   %edx,%edx
    6bba:	75 04                	jne    6bc0 <fwp_arg_drop12+0x10>
    6bbc:	c3                   	ret
    6bbd:	0f 1f 00             	nopl   (%rax)
    6bc0:	48 8b 3f             	mov    (%rdi),%rdi
    6bc3:	e9 88 fe ff ff       	jmp    6a50 <fwp_drop0>
    6bc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bcf:	00 

0000000000006bd0 <fwp_drop1>:
    6bd0:	f3 0f 1e fa          	endbr64
    6bd4:	48 8b 15 dd df 01 00 	mov    0x1dfdd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6bdb:	48 89 f8             	mov    %rdi,%rax
    6bde:	48 2b 05 ab df 01 00 	sub    0x1dfab(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6be5:	48 c1 e2 10          	shl    $0x10,%rdx
    6be9:	48 39 d0             	cmp    %rdx,%rax
    6bec:	0f 83 be 00 00 00    	jae    6cb0 <fwp_drop1+0xe0>
    6bf2:	48 83 ec 18          	sub    $0x18,%rsp
    6bf6:	4c 8d 05 e3 cb 01 00 	lea    0x1cbe3(%rip),%r8        # 237e0 <fwp_heap>
    6bfd:	48 89 c2             	mov    %rax,%rdx
    6c00:	48 c1 ea 10          	shr    $0x10,%rdx
    6c04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c08:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6c0f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c17:	48 85 d2             	test   %rdx,%rdx
    6c1a:	74 3c                	je     6c58 <fwp_drop1+0x88>
    6c1c:	0f b6 31             	movzbl (%rcx),%esi
    6c1f:	40 80 fe 02          	cmp    $0x2,%sil
    6c23:	74 3b                	je     6c60 <fwp_drop1+0x90>
    6c25:	40 80 fe 01          	cmp    $0x1,%sil
    6c29:	75 2d                	jne    6c58 <fwp_drop1+0x88>
    6c2b:	8b 71 18             	mov    0x18(%rcx),%esi
    6c2e:	0f b7 c0             	movzwl %ax,%eax
    6c31:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c34:	48 0f af c6          	imul   %rsi,%rax
    6c38:	48 c1 e8 20          	shr    $0x20,%rax
    6c3c:	48 39 c8             	cmp    %rcx,%rax
    6c3f:	73 17                	jae    6c58 <fwp_drop1+0x88>
    6c41:	48 01 c2             	add    %rax,%rdx
    6c44:	0f b6 02             	movzbl (%rdx),%eax
    6c47:	84 c0                	test   %al,%al
    6c49:	74 0d                	je     6c58 <fwp_drop1+0x88>
    6c4b:	3c 01                	cmp    $0x1,%al
    6c4d:	74 21                	je     6c70 <fwp_drop1+0xa0>
    6c4f:	3c ff                	cmp    $0xff,%al
    6c51:	74 65                	je     6cb8 <fwp_drop1+0xe8>
    6c53:	83 e8 01             	sub    $0x1,%eax
    6c56:	88 02                	mov    %al,(%rdx)
    6c58:	48 83 c4 18          	add    $0x18,%rsp
    6c5c:	c3                   	ret
    6c5d:	0f 1f 00             	nopl   (%rax)
    6c60:	66 85 c0             	test   %ax,%ax
    6c63:	74 df                	je     6c44 <fwp_drop1+0x74>
    6c65:	48 83 c4 18          	add    $0x18,%rsp
    6c69:	c3                   	ret
    6c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c70:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6c74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c79:	e8 c2 fa ff ff       	call   6740 <fwp_rc_free_arr>
    6c7e:	4c 8d 05 5b cb 01 00 	lea    0x1cb5b(%rip),%r8        # 237e0 <fwp_heap>
    6c85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6c8a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6c91:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6c98:	48 c1 e2 10          	shl    $0x10,%rdx
    6c9c:	48 39 d0             	cmp    %rdx,%rax
    6c9f:	73 b7                	jae    6c58 <fwp_drop1+0x88>
    6ca1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ca6:	e9 52 ff ff ff       	jmp    6bfd <fwp_drop1+0x2d>
    6cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6cb0:	c3                   	ret
    6cb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cb8:	48 89 d0             	mov    %rdx,%rax
    6cbb:	48 c1 e8 11          	shr    $0x11,%rax
    6cbf:	48 31 d0             	xor    %rdx,%rax
    6cc2:	48 89 c1             	mov    %rax,%rcx
    6cc5:	48 c1 e9 09          	shr    $0x9,%rcx
    6cc9:	48 31 c8             	xor    %rcx,%rax
    6ccc:	0f b6 c8             	movzbl %al,%ecx
    6ccf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6cd6:	00 
    6cd7:	48 85 c0             	test   %rax,%rax
    6cda:	75 0d                	jne    6ce9 <fwp_drop1+0x119>
    6cdc:	eb 46                	jmp    6d24 <fwp_drop1+0x154>
    6cde:	66 90                	xchg   %ax,%ax
    6ce0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ce4:	48 85 c0             	test   %rax,%rax
    6ce7:	74 3b                	je     6d24 <fwp_drop1+0x154>
    6ce9:	48 89 c1             	mov    %rax,%rcx
    6cec:	48 39 10             	cmp    %rdx,(%rax)
    6cef:	75 ef                	jne    6ce0 <fwp_drop1+0x110>
    6cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6cf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6cf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6cfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d04:	0f 85 4e ff ff ff    	jne    6c58 <fwp_drop1+0x88>
    6d0a:	48 89 d7             	mov    %rdx,%rdi
    6d0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d12:	e8 39 e8 ff ff       	call   5550 <fwp_rc_forget_slot>
    6d17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d1f:	e9 34 ff ff ff       	jmp    6c58 <fwp_drop1+0x88>
    6d24:	48 8d 3d 5d 8b 00 00 	lea    0x8b5d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6d2b:	e8 c0 d6 ff ff       	call   43f0 <fwp_trap>

0000000000006d30 <fwp_closure_drop>:
    6d30:	48 8b 15 81 de 01 00 	mov    0x1de81(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6d37:	48 89 f8             	mov    %rdi,%rax
    6d3a:	48 2b 05 4f de 01 00 	sub    0x1de4f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6d41:	48 c1 e2 10          	shl    $0x10,%rdx
    6d45:	48 39 d0             	cmp    %rdx,%rax
    6d48:	73 6b                	jae    6db5 <fwp_closure_drop+0x85>
    6d4a:	48 89 c2             	mov    %rax,%rdx
    6d4d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d55:	48 8b 15 7c de 01 00 	mov    0x1de7c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6d5c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d60:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d64:	48 85 d2             	test   %rdx,%rdx
    6d67:	74 4c                	je     6db5 <fwp_closure_drop+0x85>
    6d69:	0f b6 31             	movzbl (%rcx),%esi
    6d6c:	40 80 fe 02          	cmp    $0x2,%sil
    6d70:	74 3e                	je     6db0 <fwp_closure_drop+0x80>
    6d72:	40 80 fe 01          	cmp    $0x1,%sil
    6d76:	75 3d                	jne    6db5 <fwp_closure_drop+0x85>
    6d78:	8b 71 18             	mov    0x18(%rcx),%esi
    6d7b:	0f b7 c0             	movzwl %ax,%eax
    6d7e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d81:	48 0f af c6          	imul   %rsi,%rax
    6d85:	48 c1 e8 20          	shr    $0x20,%rax
    6d89:	48 39 c8             	cmp    %rcx,%rax
    6d8c:	73 27                	jae    6db5 <fwp_closure_drop+0x85>
    6d8e:	48 01 c2             	add    %rax,%rdx
    6d91:	0f b6 02             	movzbl (%rdx),%eax
    6d94:	84 c0                	test   %al,%al
    6d96:	74 1d                	je     6db5 <fwp_closure_drop+0x85>
    6d98:	3c 01                	cmp    $0x1,%al
    6d9a:	74 24                	je     6dc0 <fwp_closure_drop+0x90>
    6d9c:	3c ff                	cmp    $0xff,%al
    6d9e:	74 48                	je     6de8 <fwp_closure_drop+0xb8>
    6da0:	83 e8 01             	sub    $0x1,%eax
    6da3:	88 02                	mov    %al,(%rdx)
    6da5:	c3                   	ret
    6da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dad:	00 00 00 
    6db0:	66 85 c0             	test   %ax,%ax
    6db3:	74 dc                	je     6d91 <fwp_closure_drop+0x61>
    6db5:	c3                   	ret
    6db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dbd:	00 00 00 
    6dc0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6dc7:	ff ff 
    6dc9:	48 85 c0             	test   %rax,%rax
    6dcc:	74 12                	je     6de0 <fwp_closure_drop+0xb0>
    6dce:	48 89 fe             	mov    %rdi,%rsi
    6dd1:	48 89 c7             	mov    %rax,%rdi
    6dd4:	e9 77 d6 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6dd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6de0:	e9 1b d8 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6de5:	0f 1f 00             	nopl   (%rax)
    6de8:	48 89 d0             	mov    %rdx,%rax
    6deb:	48 8d 35 ee c9 01 00 	lea    0x1c9ee(%rip),%rsi        # 237e0 <fwp_heap>
    6df2:	48 83 ec 18          	sub    $0x18,%rsp
    6df6:	48 c1 e8 11          	shr    $0x11,%rax
    6dfa:	48 31 d0             	xor    %rdx,%rax
    6dfd:	48 89 c1             	mov    %rax,%rcx
    6e00:	48 c1 e9 09          	shr    $0x9,%rcx
    6e04:	48 31 c8             	xor    %rcx,%rax
    6e07:	0f b6 c8             	movzbl %al,%ecx
    6e0a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6e11:	00 
    6e12:	48 85 c0             	test   %rax,%rax
    6e15:	75 12                	jne    6e29 <fwp_closure_drop+0xf9>
    6e17:	eb 49                	jmp    6e62 <fwp_closure_drop+0x132>
    6e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e24:	48 85 c0             	test   %rax,%rax
    6e27:	74 39                	je     6e62 <fwp_closure_drop+0x132>
    6e29:	48 89 c1             	mov    %rax,%rcx
    6e2c:	48 39 10             	cmp    %rdx,(%rax)
    6e2f:	75 ef                	jne    6e20 <fwp_closure_drop+0xf0>
    6e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e44:	74 05                	je     6e4b <fwp_closure_drop+0x11b>
    6e46:	48 83 c4 18          	add    $0x18,%rsp
    6e4a:	c3                   	ret
    6e4b:	48 89 d7             	mov    %rdx,%rdi
    6e4e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e53:	e8 f8 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e58:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e5d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e60:	eb e4                	jmp    6e46 <fwp_closure_drop+0x116>
    6e62:	48 8d 3d 1f 8a 00 00 	lea    0x8a1f(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6e69:	e8 82 d5 ff ff       	call   43f0 <fwp_trap>
    6e6e:	66 90                	xchg   %ax,%ax

0000000000006e70 <fwp_owned_tape_release>:
    6e70:	48 85 ff             	test   %rdi,%rdi
    6e73:	0f 84 f7 00 00 00    	je     6f70 <fwp_owned_tape_release+0x100>
    6e79:	41 54                	push   %r12
    6e7b:	55                   	push   %rbp
    6e7c:	53                   	push   %rbx
    6e7d:	48 8b 07             	mov    (%rdi),%rax
    6e80:	48 85 c0             	test   %rax,%rax
    6e83:	74 08                	je     6e8d <fwp_owned_tape_release+0x1d>
    6e85:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e89:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e8d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e91:	48 85 d2             	test   %rdx,%rdx
    6e94:	74 03                	je     6e99 <fwp_owned_tape_release+0x29>
    6e96:	48 89 02             	mov    %rax,(%rdx)
    6e99:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6e9d:	48 89 fb             	mov    %rdi,%rbx
    6ea0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ea4:	48 85 c0             	test   %rax,%rax
    6ea7:	0f 84 89 00 00 00    	je     6f36 <fwp_owned_tape_release+0xc6>
    6ead:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6eb1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6eb5:	7e 47                	jle    6efe <fwp_owned_tape_release+0x8e>
    6eb7:	31 ed                	xor    %ebp,%ebp
    6eb9:	eb 0d                	jmp    6ec8 <fwp_owned_tape_release+0x58>
    6ebb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ec0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ec4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ec8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6ecc:	49 89 ec             	mov    %rbp,%r12
    6ecf:	48 83 c5 01          	add    $0x1,%rbp
    6ed3:	49 c1 e4 04          	shl    $0x4,%r12
    6ed7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6edb:	ff d0                	call   *%rax
    6edd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6ee1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6ee6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6eea:	ff 50 68             	call   *0x68(%rax)
    6eed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6ef1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6ef5:	48 39 e8             	cmp    %rbp,%rax
    6ef8:	7f c6                	jg     6ec0 <fwp_owned_tape_release+0x50>
    6efa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6efe:	31 ed                	xor    %ebp,%ebp
    6f00:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6f05:	7e 28                	jle    6f2f <fwp_owned_tape_release+0xbf>
    6f07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f0e:	00 00 
    6f10:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6f14:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6f18:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6f1c:	74 07                	je     6f25 <fwp_owned_tape_release+0xb5>
    6f1e:	ff 52 68             	call   *0x68(%rdx)
    6f21:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f25:	48 83 c5 01          	add    $0x1,%rbp
    6f29:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6f2d:	7f e1                	jg     6f10 <fwp_owned_tape_release+0xa0>
    6f2f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f33:	ff 52 68             	call   *0x68(%rdx)
    6f36:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6f3a:	e8 f1 fd ff ff       	call   6d30 <fwp_closure_drop>
    6f3f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6f43:	e8 e8 fd ff ff       	call   6d30 <fwp_closure_drop>
    6f48:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6f4c:	e8 df fd ff ff       	call   6d30 <fwp_closure_drop>
    6f51:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6f55:	e8 36 e8 ff ff       	call   5790 <fwp_mem_free>
    6f5a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6f5e:	e8 2d e8 ff ff       	call   5790 <fwp_mem_free>
    6f63:	48 89 df             	mov    %rbx,%rdi
    6f66:	5b                   	pop    %rbx
    6f67:	5d                   	pop    %rbp
    6f68:	41 5c                	pop    %r12
    6f6a:	e9 21 e8 ff ff       	jmp    5790 <fwp_mem_free>
    6f6f:	90                   	nop
    6f70:	c3                   	ret
    6f71:	0f 1f 40 00          	nopl   0x0(%rax)
    6f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f7c:	00 00 00 00 

0000000000006f80 <fwp_tape_finish>:
    6f80:	f3 0f 1e fa          	endbr64
    6f84:	41 56                	push   %r14
    6f86:	48 8d 3d 33 c1 01 00 	lea    0x1c133(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6f8d:	41 55                	push   %r13
    6f8f:	41 54                	push   %r12
    6f91:	55                   	push   %rbp
    6f92:	53                   	push   %rbx
    6f93:	e8 78 d1 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6f98:	48 83 3d 68 c1 01 00 	cmpq   $0x0,0x1c168(%rip)        # 23108 <fwp_ntapes>
    6f9f:	00 
    6fa0:	48 c7 05 fd c0 01 00 	movq   $0x0,0x1c0fd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6fa7:	00 00 00 00 
    6fab:	7e 68                	jle    7015 <fwp_tape_finish+0x95>
    6fad:	45 31 e4             	xor    %r12d,%r12d
    6fb0:	31 ed                	xor    %ebp,%ebp
    6fb2:	0f 1f 00             	nopl   (%rax)
    6fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fbc:	00 00 00 00 
    6fc0:	48 8b 1d 49 c1 01 00 	mov    0x1c149(%rip),%rbx        # 23110 <fwp_tapes>
    6fc7:	48 83 c5 01          	add    $0x1,%rbp
    6fcb:	4c 01 e3             	add    %r12,%rbx
    6fce:	49 83 c4 68          	add    $0x68,%r12
    6fd2:	48 89 df             	mov    %rbx,%rdi
    6fd5:	e8 26 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6fda:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6fde:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6fe2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6fe6:	e8 d5 c3 ff ff       	call   33c0 <free@plt>
    6feb:	4c 89 f7             	mov    %r14,%rdi
    6fee:	e8 cd c3 ff ff       	call   33c0 <free@plt>
    6ff3:	4c 89 ef             	mov    %r13,%rdi
    6ff6:	e8 c5 c3 ff ff       	call   33c0 <free@plt>
    6ffb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6fff:	e8 6c fe ff ff       	call   6e70 <fwp_owned_tape_release>
    7004:	48 39 2d fd c0 01 00 	cmp    %rbp,0x1c0fd(%rip)        # 23108 <fwp_ntapes>
    700b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7012:	00 
    7013:	7f ab                	jg     6fc0 <fwp_tape_finish+0x40>
    7015:	48 8b 3d f4 c0 01 00 	mov    0x1c0f4(%rip),%rdi        # 23110 <fwp_tapes>
    701c:	e8 9f c3 ff ff       	call   33c0 <free@plt>
    7021:	5b                   	pop    %rbx
    7022:	5d                   	pop    %rbp
    7023:	48 c7 05 e2 c0 01 00 	movq   $0x0,0x1c0e2(%rip)        # 23110 <fwp_tapes>
    702a:	00 00 00 00 
    702e:	48 c7 05 c7 c0 01 00 	movq   $0x0,0x1c0c7(%rip)        # 23100 <fwp_tapes_cap>
    7035:	00 00 00 00 
    7039:	41 5c                	pop    %r12
    703b:	48 c7 05 c2 c0 01 00 	movq   $0x0,0x1c0c2(%rip)        # 23108 <fwp_ntapes>
    7042:	00 00 00 00 
    7046:	41 5d                	pop    %r13
    7048:	48 c7 05 a5 c0 01 00 	movq   $0x0,0x1c0a5(%rip)        # 230f8 <fwp_tape_next_slot>
    704f:	00 00 00 00 
    7053:	41 5e                	pop    %r14
    7055:	c3                   	ret
    7056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    705d:	00 00 00 

0000000000007060 <fwp_tape_scope_release>:
    7060:	f3 0f 1e fa          	endbr64
    7064:	41 55                	push   %r13
    7066:	41 54                	push   %r12
    7068:	55                   	push   %rbp
    7069:	53                   	push   %rbx
    706a:	48 83 ec 58          	sub    $0x58,%rsp
    706e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7075:	00 00 
    7077:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    707c:	48 63 07             	movslq (%rdi),%rax
    707f:	85 c0                	test   %eax,%eax
    7081:	0f 88 05 01 00 00    	js     718c <fwp_tape_scope_release+0x12c>
    7087:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    708e:	ec c4 4e 
    7091:	48 89 fb             	mov    %rdi,%rbx
    7094:	eb 3c                	jmp    70d2 <fwp_tape_scope_release+0x72>
    7096:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    709d:	00 00 00 
    70a0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    70a5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    70a9:	e8 12 c3 ff ff       	call   33c0 <free@plt>
    70ae:	48 8b 3c 24          	mov    (%rsp),%rdi
    70b2:	e8 09 c3 ff ff       	call   33c0 <free@plt>
    70b7:	4c 89 ef             	mov    %r13,%rdi
    70ba:	e8 01 c3 ff ff       	call   33c0 <free@plt>
    70bf:	4c 89 e7             	mov    %r12,%rdi
    70c2:	e8 a9 fd ff ff       	call   6e70 <fwp_owned_tape_release>
    70c7:	48 63 03             	movslq (%rbx),%rax
    70ca:	85 c0                	test   %eax,%eax
    70cc:	0f 88 ba 00 00 00    	js     718c <fwp_tape_scope_release+0x12c>
    70d2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    70d6:	48 8b 35 33 c0 01 00 	mov    0x1c033(%rip),%rsi        # 23110 <fwp_tapes>
    70dd:	4c 01 c6             	add    %r8,%rsi
    70e0:	48 89 f7             	mov    %rsi,%rdi
    70e3:	e8 18 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    70e8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    70ed:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    70f2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    70f9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    70fd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7101:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7108:	00 
    7109:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    710e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7112:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7117:	66 0f ef d2          	pxor   %xmm2,%xmm2
    711b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7120:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7127:	00 
    7128:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    712f:	00 
    7130:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7137:	00 
    7138:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    713d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7142:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7146:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    714a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    714e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7154:	77 18                	ja     716e <fwp_tape_scope_release+0x10e>
    7156:	49 c1 f8 03          	sar    $0x3,%r8
    715a:	4c 0f af c5          	imul   %rbp,%r8
    715e:	4c 3b 05 93 bf 01 00 	cmp    0x1bf93(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    7165:	7d 07                	jge    716e <fwp_tape_scope_release+0x10e>
    7167:	4c 89 05 8a bf 01 00 	mov    %r8,0x1bf8a(%rip)        # 230f8 <fwp_tape_next_slot>
    716e:	4d 85 e4             	test   %r12,%r12
    7171:	0f 85 29 ff ff ff    	jne    70a0 <fwp_tape_scope_release+0x40>
    7177:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    717c:	e8 ef de ff ff       	call   5070 <fwp_tape_buffers_release>
    7181:	48 63 03             	movslq (%rbx),%rax
    7184:	85 c0                	test   %eax,%eax
    7186:	0f 89 46 ff ff ff    	jns    70d2 <fwp_tape_scope_release+0x72>
    718c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7191:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7198:	00 00 
    719a:	75 0b                	jne    71a7 <fwp_tape_scope_release+0x147>
    719c:	48 83 c4 58          	add    $0x58,%rsp
    71a0:	5b                   	pop    %rbx
    71a1:	5d                   	pop    %rbp
    71a2:	41 5c                	pop    %r12
    71a4:	41 5d                	pop    %r13
    71a6:	c3                   	ret
    71a7:	e8 b4 c2 ff ff       	call   3460 <__stack_chk_fail@plt>
    71ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000071b0 <fwp_task_dispose>:
    71b0:	53                   	push   %rbx
    71b1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    71b5:	0f 84 8b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    71bb:	48 89 fb             	mov    %rdi,%rbx
    71be:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    71c3:	0f 85 7d c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    71c9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    71cd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    71d4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    71db:	00 
    71dc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    71e0:	48 85 ff             	test   %rdi,%rdi
    71e3:	74 07                	je     71ec <fwp_task_dispose+0x3c>
    71e5:	48 85 c0             	test   %rax,%rax
    71e8:	74 02                	je     71ec <fwp_task_dispose+0x3c>
    71ea:	ff d0                	call   *%rax
    71ec:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    71f3:	e8 98 e5 ff ff       	call   5790 <fwp_mem_free>
    71f8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    71ff:	00 00 00 00 
    7203:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7207:	74 6f                	je     7278 <fwp_task_dispose+0xc8>
    7209:	48 8b 15 a8 d9 01 00 	mov    0x1d9a8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7210:	48 89 d8             	mov    %rbx,%rax
    7213:	48 2b 05 76 d9 01 00 	sub    0x1d976(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    721a:	48 c1 e2 10          	shl    $0x10,%rdx
    721e:	48 39 d0             	cmp    %rdx,%rax
    7221:	73 4c                	jae    726f <fwp_task_dispose+0xbf>
    7223:	48 89 c2             	mov    %rax,%rdx
    7226:	48 c1 ea 10          	shr    $0x10,%rdx
    722a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    722e:	48 8b 15 a3 d9 01 00 	mov    0x1d9a3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7235:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7239:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    723d:	48 85 c9             	test   %rcx,%rcx
    7240:	74 2d                	je     726f <fwp_task_dispose+0xbf>
    7242:	0f b6 32             	movzbl (%rdx),%esi
    7245:	40 80 fe 02          	cmp    $0x2,%sil
    7249:	74 3d                	je     7288 <fwp_task_dispose+0xd8>
    724b:	40 80 fe 01          	cmp    $0x1,%sil
    724f:	75 1e                	jne    726f <fwp_task_dispose+0xbf>
    7251:	8b 72 18             	mov    0x18(%rdx),%esi
    7254:	0f b7 c0             	movzwl %ax,%eax
    7257:	8b 52 1c             	mov    0x1c(%rdx),%edx
    725a:	48 0f af c6          	imul   %rsi,%rax
    725e:	48 c1 e8 20          	shr    $0x20,%rax
    7262:	48 39 d0             	cmp    %rdx,%rax
    7265:	73 08                	jae    726f <fwp_task_dispose+0xbf>
    7267:	48 01 c1             	add    %rax,%rcx
    726a:	80 39 01             	cmpb   $0x1,(%rcx)
    726d:	74 09                	je     7278 <fwp_task_dispose+0xc8>
    726f:	5b                   	pop    %rbx
    7270:	c3                   	ret
    7271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7278:	48 89 df             	mov    %rbx,%rdi
    727b:	5b                   	pop    %rbx
    727c:	e9 0f e5 ff ff       	jmp    5790 <fwp_mem_free>
    7281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7288:	66 85 c0             	test   %ax,%ax
    728b:	74 dd                	je     726a <fwp_task_dispose+0xba>
    728d:	5b                   	pop    %rbx
    728e:	c3                   	ret
    728f:	90                   	nop

0000000000007290 <fwp_free_zombie>:
    7290:	48 8b 15 19 c5 01 00 	mov    0x1c519(%rip),%rdx        # 237b0 <fwp_zombie>
    7297:	48 85 d2             	test   %rdx,%rdx
    729a:	0f 84 98 00 00 00    	je     7338 <fwp_free_zombie+0xa8>
    72a0:	48 3b 15 19 c5 01 00 	cmp    0x1c519(%rip),%rdx        # 237c0 <fwp_cur>
    72a7:	0f 84 8b 00 00 00    	je     7338 <fwp_free_zombie+0xa8>
    72ad:	48 83 ec 18          	sub    $0x18,%rsp
    72b1:	48 63 05 cc be 01 00 	movslq 0x1becc(%rip),%rax        # 23184 <fwp_stack_pool_n>
    72b8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    72bc:	83 f8 3f             	cmp    $0x3f,%eax
    72bf:	7f 7f                	jg     7340 <fwp_free_zombie+0xb0>
    72c1:	8d 48 01             	lea    0x1(%rax),%ecx
    72c4:	89 0d ba be 01 00    	mov    %ecx,0x1beba(%rip)        # 23184 <fwp_stack_pool_n>
    72ca:	48 8d 0d cf be 01 00 	lea    0x1becf(%rip),%rcx        # 231a0 <fwp_stack_pool>
    72d1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    72d5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    72dc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72e0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    72e7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    72eb:	48 85 c9             	test   %rcx,%rcx
    72ee:	0f 84 fc 00 00 00    	je     73f0 <fwp_free_zombie+0x160>
    72f4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    72fb:	48 85 c0             	test   %rax,%rax
    72fe:	74 07                	je     7307 <fwp_free_zombie+0x77>
    7300:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7307:	8b 42 5c             	mov    0x5c(%rdx),%eax
    730a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    730e:	48 c7 05 97 c4 01 00 	movq   $0x0,0x1c497(%rip)        # 237b0 <fwp_zombie>
    7315:	00 00 00 00 
    7319:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7320:	85 c0                	test   %eax,%eax
    7322:	74 34                	je     7358 <fwp_free_zombie+0xc8>
    7324:	83 f8 01             	cmp    $0x1,%eax
    7327:	0f 84 b3 00 00 00    	je     73e0 <fwp_free_zombie+0x150>
    732d:	48 83 c4 18          	add    $0x18,%rsp
    7331:	c3                   	ret
    7332:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7338:	c3                   	ret
    7339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7340:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7344:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7349:	e8 92 c2 ff ff       	call   35e0 <munmap@plt>
    734e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7353:	eb 80                	jmp    72d5 <fwp_free_zombie+0x45>
    7355:	0f 1f 00             	nopl   (%rax)
    7358:	48 8b 0d 59 d8 01 00 	mov    0x1d859(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    735f:	48 89 d0             	mov    %rdx,%rax
    7362:	48 2b 05 27 d8 01 00 	sub    0x1d827(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7369:	48 c1 e1 10          	shl    $0x10,%rcx
    736d:	48 39 c8             	cmp    %rcx,%rax
    7370:	73 bb                	jae    732d <fwp_free_zombie+0x9d>
    7372:	48 89 c1             	mov    %rax,%rcx
    7375:	48 c1 e9 10          	shr    $0x10,%rcx
    7379:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    737d:	48 8b 0d 54 d8 01 00 	mov    0x1d854(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7384:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7388:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    738c:	48 85 c9             	test   %rcx,%rcx
    738f:	74 9c                	je     732d <fwp_free_zombie+0x9d>
    7391:	0f b6 3e             	movzbl (%rsi),%edi
    7394:	40 80 ff 02          	cmp    $0x2,%dil
    7398:	74 66                	je     7400 <fwp_free_zombie+0x170>
    739a:	40 80 ff 01          	cmp    $0x1,%dil
    739e:	75 8d                	jne    732d <fwp_free_zombie+0x9d>
    73a0:	8b 7e 18             	mov    0x18(%rsi),%edi
    73a3:	0f b7 c0             	movzwl %ax,%eax
    73a6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    73a9:	48 0f af c7          	imul   %rdi,%rax
    73ad:	48 c1 e8 20          	shr    $0x20,%rax
    73b1:	48 39 f0             	cmp    %rsi,%rax
    73b4:	0f 83 73 ff ff ff    	jae    732d <fwp_free_zombie+0x9d>
    73ba:	48 01 c1             	add    %rax,%rcx
    73bd:	0f b6 01             	movzbl (%rcx),%eax
    73c0:	84 c0                	test   %al,%al
    73c2:	0f 84 65 ff ff ff    	je     732d <fwp_free_zombie+0x9d>
    73c8:	3c 01                	cmp    $0x1,%al
    73ca:	74 14                	je     73e0 <fwp_free_zombie+0x150>
    73cc:	3c ff                	cmp    $0xff,%al
    73ce:	74 3b                	je     740b <fwp_free_zombie+0x17b>
    73d0:	83 e8 01             	sub    $0x1,%eax
    73d3:	88 01                	mov    %al,(%rcx)
    73d5:	e9 53 ff ff ff       	jmp    732d <fwp_free_zombie+0x9d>
    73da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73e0:	48 89 d7             	mov    %rdx,%rdi
    73e3:	48 83 c4 18          	add    $0x18,%rsp
    73e7:	e9 c4 fd ff ff       	jmp    71b0 <fwp_task_dispose>
    73ec:	0f 1f 40 00          	nopl   0x0(%rax)
    73f0:	48 89 05 91 c3 01 00 	mov    %rax,0x1c391(%rip)        # 23788 <fwp_tasks_active>
    73f7:	e9 ff fe ff ff       	jmp    72fb <fwp_free_zombie+0x6b>
    73fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7400:	66 85 c0             	test   %ax,%ax
    7403:	0f 85 24 ff ff ff    	jne    732d <fwp_free_zombie+0x9d>
    7409:	eb b2                	jmp    73bd <fwp_free_zombie+0x12d>
    740b:	48 89 ca             	mov    %rcx,%rdx
    740e:	48 8d 35 cb c3 01 00 	lea    0x1c3cb(%rip),%rsi        # 237e0 <fwp_heap>
    7415:	48 c1 ea 11          	shr    $0x11,%rdx
    7419:	48 31 ca             	xor    %rcx,%rdx
    741c:	48 89 d0             	mov    %rdx,%rax
    741f:	48 c1 e8 09          	shr    $0x9,%rax
    7423:	48 31 c2             	xor    %rax,%rdx
    7426:	0f b6 d2             	movzbl %dl,%edx
    7429:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7430:	00 
    7431:	48 85 c0             	test   %rax,%rax
    7434:	75 13                	jne    7449 <fwp_free_zombie+0x1b9>
    7436:	eb 4c                	jmp    7484 <fwp_free_zombie+0x1f4>
    7438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    743f:	00 
    7440:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7444:	48 85 c0             	test   %rax,%rax
    7447:	74 3b                	je     7484 <fwp_free_zombie+0x1f4>
    7449:	48 89 c2             	mov    %rax,%rdx
    744c:	48 39 08             	cmp    %rcx,(%rax)
    744f:	75 ef                	jne    7440 <fwp_free_zombie+0x1b0>
    7451:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7455:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7459:	48 89 50 08          	mov    %rdx,0x8(%rax)
    745d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7464:	0f 85 c3 fe ff ff    	jne    732d <fwp_free_zombie+0x9d>
    746a:	48 89 cf             	mov    %rcx,%rdi
    746d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7472:	e8 d9 e0 ff ff       	call   5550 <fwp_rc_forget_slot>
    7477:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    747c:	c6 01 fe             	movb   $0xfe,(%rcx)
    747f:	e9 a9 fe ff ff       	jmp    732d <fwp_free_zombie+0x9d>
    7484:	48 8d 3d fd 83 00 00 	lea    0x83fd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    748b:	e8 60 cf ff ff       	call   43f0 <fwp_trap>

0000000000007490 <fwp_block>:
    7490:	48 83 ec 08          	sub    $0x8,%rsp
    7494:	48 8b 05 0d c3 01 00 	mov    0x1c30d(%rip),%rax        # 237a8 <fwp_ready_head>
    749b:	48 85 c0             	test   %rax,%rax
    749e:	0f 84 1c 01 00 00    	je     75c0 <fwp_block+0x130>
    74a4:	90                   	nop
    74a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74ac:	00 00 00 00 
    74b0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    74b7:	48 89 15 ea c2 01 00 	mov    %rdx,0x1c2ea(%rip)        # 237a8 <fwp_ready_head>
    74be:	48 85 d2             	test   %rdx,%rdx
    74c1:	0f 84 19 01 00 00    	je     75e0 <fwp_block+0x150>
    74c7:	48 8b 15 f2 c2 01 00 	mov    0x1c2f2(%rip),%rdx        # 237c0 <fwp_cur>
    74ce:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    74d2:	48 39 c2             	cmp    %rax,%rdx
    74d5:	0f 84 d5 00 00 00    	je     75b0 <fwp_block+0x120>
    74db:	48 8b 0d 66 df 01 00 	mov    0x1df66(%rip),%rcx        # 25448 <fwp_state_owners>
    74e2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    74e6:	48 89 05 d3 c2 01 00 	mov    %rax,0x1c2d3(%rip)        # 237c0 <fwp_cur>
    74ed:	f3 0f 7e 05 7b df 01 	movq   0x1df7b(%rip),%xmm0        # 25470 <fwp_foreign_callbacks>
    74f4:	00 
    74f5:	0f 16 05 64 df 01 00 	movhps 0x1df64(%rip),%xmm0        # 25460 <fwp_state>
    74fc:	f3 0f 7e 0d 64 df 01 	movq   0x1df64(%rip),%xmm1        # 25468 <fwp_handlers>
    7503:	00 
    7504:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    750b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7512:	0f 16 0d 5f df 01 00 	movhps 0x1df5f(%rip),%xmm1        # 25478 <fwp_cleanups>
    7519:	f3 0f 7e 05 37 df 01 	movq   0x1df37(%rip),%xmm0        # 25458 <fwp_state_len>
    7520:	00 
    7521:	0f 16 05 28 df 01 00 	movhps 0x1df28(%rip),%xmm0        # 25450 <fwp_state_cap>
    7528:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    752f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7536:	48 8b 70 08          	mov    0x8(%rax),%rsi
    753a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7541:	48 89 0d 20 df 01 00 	mov    %rcx,0x1df20(%rip)        # 25468 <fwp_handlers>
    7548:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    754f:	48 89 0d 22 df 01 00 	mov    %rcx,0x1df22(%rip)        # 25478 <fwp_cleanups>
    7556:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    755d:	48 89 0d 0c df 01 00 	mov    %rcx,0x1df0c(%rip)        # 25470 <fwp_foreign_callbacks>
    7564:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    756b:	48 89 0d ee de 01 00 	mov    %rcx,0x1deee(%rip)        # 25460 <fwp_state>
    7572:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7579:	48 89 0d d8 de 01 00 	mov    %rcx,0x1ded8(%rip)        # 25458 <fwp_state_len>
    7580:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7587:	48 89 0d c2 de 01 00 	mov    %rcx,0x1dec2(%rip)        # 25450 <fwp_state_cap>
    758e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7595:	48 89 0d ac de 01 00 	mov    %rcx,0x1deac(%rip)        # 25448 <fwp_state_owners>
    759c:	e8 ef be ff ff       	call   3490 <swapcontext@plt>
    75a1:	f3 0f 1e fa          	endbr64
    75a5:	e8 e6 fc ff ff       	call   7290 <fwp_free_zombie>
    75aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75b0:	8b 05 ca bb 01 00    	mov    0x1bbca(%rip),%eax        # 23180 <fwp_slice>
    75b6:	85 c0                	test   %eax,%eax
    75b8:	74 36                	je     75f0 <fwp_block+0x160>
    75ba:	48 83 c4 08          	add    $0x8,%rsp
    75be:	c3                   	ret
    75bf:	90                   	nop
    75c0:	e8 db db ff ff       	call   51a0 <fwp_poll_events>
    75c5:	48 8b 05 dc c1 01 00 	mov    0x1c1dc(%rip),%rax        # 237a8 <fwp_ready_head>
    75cc:	48 85 c0             	test   %rax,%rax
    75cf:	0f 85 db fe ff ff    	jne    74b0 <fwp_block+0x20>
    75d5:	eb e9                	jmp    75c0 <fwp_block+0x130>
    75d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75de:	00 00 
    75e0:	48 c7 05 b5 c1 01 00 	movq   $0x0,0x1c1b5(%rip)        # 237a0 <fwp_ready_tail>
    75e7:	00 00 00 00 
    75eb:	e9 d7 fe ff ff       	jmp    74c7 <fwp_block+0x37>
    75f0:	48 8d 3d 8d 7b 00 00 	lea    0x7b8d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    75f7:	e8 a4 bd ff ff       	call   33a0 <getenv@plt>
    75fc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7601:	48 85 c0             	test   %rax,%rax
    7604:	74 05                	je     760b <fwp_block+0x17b>
    7606:	80 38 00             	cmpb   $0x0,(%rax)
    7609:	75 0b                	jne    7616 <fwp_block+0x186>
    760b:	89 15 6f bb 01 00    	mov    %edx,0x1bb6f(%rip)        # 23180 <fwp_slice>
    7611:	48 83 c4 08          	add    $0x8,%rsp
    7615:	c3                   	ret
    7616:	ba 0a 00 00 00       	mov    $0xa,%edx
    761b:	31 f6                	xor    %esi,%esi
    761d:	48 89 c7             	mov    %rax,%rdi
    7620:	e8 2b bf ff ff       	call   3550 <strtoll@plt>
    7625:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7629:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7630:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7635:	0f 46 d0             	cmovbe %eax,%edx
    7638:	eb d1                	jmp    760b <fwp_block+0x17b>
    763a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007640 <fwp_drop4>:
    7640:	48 8b 15 71 d5 01 00 	mov    0x1d571(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7647:	48 89 f8             	mov    %rdi,%rax
    764a:	48 2b 05 3f d5 01 00 	sub    0x1d53f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7651:	48 c1 e2 10          	shl    $0x10,%rdx
    7655:	48 39 d0             	cmp    %rdx,%rax
    7658:	0f 83 52 01 00 00    	jae    77b0 <fwp_drop4+0x170>
    765e:	48 83 ec 18          	sub    $0x18,%rsp
    7662:	4c 8d 05 77 c1 01 00 	lea    0x1c177(%rip),%r8        # 237e0 <fwp_heap>
    7669:	48 89 c2             	mov    %rax,%rdx
    766c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7673:	48 c1 ea 10          	shr    $0x10,%rdx
    7677:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    767b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    767f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7683:	48 85 d2             	test   %rdx,%rdx
    7686:	74 46                	je     76ce <fwp_drop4+0x8e>
    7688:	44 0f b6 09          	movzbl (%rcx),%r9d
    768c:	41 80 f9 02          	cmp    $0x2,%r9b
    7690:	0f 84 ca 00 00 00    	je     7760 <fwp_drop4+0x120>
    7696:	41 80 f9 01          	cmp    $0x1,%r9b
    769a:	75 32                	jne    76ce <fwp_drop4+0x8e>
    769c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    76a0:	0f b7 c0             	movzwl %ax,%eax
    76a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76a6:	49 0f af c1          	imul   %r9,%rax
    76aa:	48 c1 e8 20          	shr    $0x20,%rax
    76ae:	48 39 c8             	cmp    %rcx,%rax
    76b1:	73 1b                	jae    76ce <fwp_drop4+0x8e>
    76b3:	48 01 c2             	add    %rax,%rdx
    76b6:	0f b6 02             	movzbl (%rdx),%eax
    76b9:	84 c0                	test   %al,%al
    76bb:	74 11                	je     76ce <fwp_drop4+0x8e>
    76bd:	3c 01                	cmp    $0x1,%al
    76bf:	74 17                	je     76d8 <fwp_drop4+0x98>
    76c1:	3c ff                	cmp    $0xff,%al
    76c3:	0f 84 ef 00 00 00    	je     77b8 <fwp_drop4+0x178>
    76c9:	83 e8 01             	sub    $0x1,%eax
    76cc:	88 02                	mov    %al,(%rdx)
    76ce:	48 83 c4 18          	add    $0x18,%rsp
    76d2:	c3                   	ret
    76d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76d8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    76dc:	0f 88 8e 00 00 00    	js     7770 <fwp_drop4+0x130>
    76e2:	48 8b 15 cf d4 01 00 	mov    0x1d4cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    76e9:	48 89 f8             	mov    %rdi,%rax
    76ec:	48 2b 05 9d d4 01 00 	sub    0x1d49d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    76f3:	48 c1 e2 10          	shl    $0x10,%rdx
    76f7:	48 39 d0             	cmp    %rdx,%rax
    76fa:	73 d2                	jae    76ce <fwp_drop4+0x8e>
    76fc:	48 89 c2             	mov    %rax,%rdx
    76ff:	48 c1 ea 10          	shr    $0x10,%rdx
    7703:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7707:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    770b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    770f:	48 85 c9             	test   %rcx,%rcx
    7712:	74 ba                	je     76ce <fwp_drop4+0x8e>
    7714:	0f b6 32             	movzbl (%rdx),%esi
    7717:	40 80 fe 02          	cmp    $0x2,%sil
    771b:	74 33                	je     7750 <fwp_drop4+0x110>
    771d:	40 80 fe 01          	cmp    $0x1,%sil
    7721:	75 ab                	jne    76ce <fwp_drop4+0x8e>
    7723:	8b 72 18             	mov    0x18(%rdx),%esi
    7726:	0f b7 c0             	movzwl %ax,%eax
    7729:	8b 52 1c             	mov    0x1c(%rdx),%edx
    772c:	48 0f af c6          	imul   %rsi,%rax
    7730:	48 c1 e8 20          	shr    $0x20,%rax
    7734:	48 39 d0             	cmp    %rdx,%rax
    7737:	73 95                	jae    76ce <fwp_drop4+0x8e>
    7739:	48 01 c1             	add    %rax,%rcx
    773c:	80 39 01             	cmpb   $0x1,(%rcx)
    773f:	75 8d                	jne    76ce <fwp_drop4+0x8e>
    7741:	48 83 c4 18          	add    $0x18,%rsp
    7745:	e9 46 e0 ff ff       	jmp    5790 <fwp_mem_free>
    774a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7750:	66 85 c0             	test   %ax,%ax
    7753:	74 e7                	je     773c <fwp_drop4+0xfc>
    7755:	48 83 c4 18          	add    $0x18,%rsp
    7759:	c3                   	ret
    775a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7760:	66 85 c0             	test   %ax,%ax
    7763:	0f 84 4d ff ff ff    	je     76b6 <fwp_drop4+0x76>
    7769:	48 83 c4 18          	add    $0x18,%rsp
    776d:	c3                   	ret
    776e:	66 90                	xchg   %ax,%ax
    7770:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7774:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7779:	e8 c2 ef ff ff       	call   6740 <fwp_rc_free_arr>
    777e:	4c 8d 05 5b c0 01 00 	lea    0x1c05b(%rip),%r8        # 237e0 <fwp_heap>
    7785:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    778a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7791:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7798:	48 c1 e2 10          	shl    $0x10,%rdx
    779c:	48 39 d0             	cmp    %rdx,%rax
    779f:	0f 83 29 ff ff ff    	jae    76ce <fwp_drop4+0x8e>
    77a5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    77aa:	e9 ba fe ff ff       	jmp    7669 <fwp_drop4+0x29>
    77af:	90                   	nop
    77b0:	c3                   	ret
    77b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77b8:	48 89 d0             	mov    %rdx,%rax
    77bb:	48 c1 e8 11          	shr    $0x11,%rax
    77bf:	48 31 d0             	xor    %rdx,%rax
    77c2:	48 89 c1             	mov    %rax,%rcx
    77c5:	48 c1 e9 09          	shr    $0x9,%rcx
    77c9:	48 31 c8             	xor    %rcx,%rax
    77cc:	0f b6 c8             	movzbl %al,%ecx
    77cf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    77d6:	00 
    77d7:	48 85 c0             	test   %rax,%rax
    77da:	75 0d                	jne    77e9 <fwp_drop4+0x1a9>
    77dc:	eb 46                	jmp    7824 <fwp_drop4+0x1e4>
    77de:	66 90                	xchg   %ax,%ax
    77e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    77e4:	48 85 c0             	test   %rax,%rax
    77e7:	74 3b                	je     7824 <fwp_drop4+0x1e4>
    77e9:	48 89 c1             	mov    %rax,%rcx
    77ec:	48 39 10             	cmp    %rdx,(%rax)
    77ef:	75 ef                	jne    77e0 <fwp_drop4+0x1a0>
    77f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    77f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    77fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7804:	0f 85 c4 fe ff ff    	jne    76ce <fwp_drop4+0x8e>
    780a:	48 89 d7             	mov    %rdx,%rdi
    780d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7812:	e8 39 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    7817:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    781c:	c6 02 fe             	movb   $0xfe,(%rdx)
    781f:	e9 aa fe ff ff       	jmp    76ce <fwp_drop4+0x8e>
    7824:	48 8d 3d 5d 80 00 00 	lea    0x805d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    782b:	e8 c0 cb ff ff       	call   43f0 <fwp_trap>

0000000000007830 <fwp_caps161>:
    7830:	f3 0f 1e fa          	endbr64
    7834:	85 f6                	test   %esi,%esi
    7836:	74 08                	je     7840 <fwp_caps161+0x10>
    7838:	c3                   	ret
    7839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7840:	48 8b 15 71 d3 01 00 	mov    0x1d371(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7847:	48 89 f8             	mov    %rdi,%rax
    784a:	48 2b 05 3f d3 01 00 	sub    0x1d33f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7851:	48 c1 e2 10          	shl    $0x10,%rdx
    7855:	48 39 d0             	cmp    %rdx,%rax
    7858:	73 de                	jae    7838 <fwp_caps161+0x8>
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 10          	shr    $0x10,%rdx
    7861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7865:	48 8b 15 6c d3 01 00 	mov    0x1d36c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    786c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7870:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7874:	48 85 c9             	test   %rcx,%rcx
    7877:	74 bf                	je     7838 <fwp_caps161+0x8>
    7879:	0f b6 32             	movzbl (%rdx),%esi
    787c:	40 80 fe 02          	cmp    $0x2,%sil
    7880:	74 2e                	je     78b0 <fwp_caps161+0x80>
    7882:	40 80 fe 01          	cmp    $0x1,%sil
    7886:	75 b0                	jne    7838 <fwp_caps161+0x8>
    7888:	8b 72 18             	mov    0x18(%rdx),%esi
    788b:	0f b7 c0             	movzwl %ax,%eax
    788e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7891:	48 0f af c6          	imul   %rsi,%rax
    7895:	48 c1 e8 20          	shr    $0x20,%rax
    7899:	48 39 d0             	cmp    %rdx,%rax
    789c:	73 9a                	jae    7838 <fwp_caps161+0x8>
    789e:	48 01 c1             	add    %rax,%rcx
    78a1:	80 39 01             	cmpb   $0x1,(%rcx)
    78a4:	75 92                	jne    7838 <fwp_caps161+0x8>
    78a6:	e9 e5 de ff ff       	jmp    5790 <fwp_mem_free>
    78ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 ec                	je     78a1 <fwp_caps161+0x71>
    78b5:	c3                   	ret
    78b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78bd:	00 00 00 

00000000000078c0 <fwp_args12>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	85 d2                	test   %edx,%edx
    78c6:	74 04                	je     78cc <fwp_args12+0xc>
    78c8:	85 f6                	test   %esi,%esi
    78ca:	74 04                	je     78d0 <fwp_args12+0x10>
    78cc:	c3                   	ret
    78cd:	0f 1f 00             	nopl   (%rax)
    78d0:	48 8b 15 e1 d2 01 00 	mov    0x1d2e1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    78d7:	48 8b 07             	mov    (%rdi),%rax
    78da:	48 2b 05 af d2 01 00 	sub    0x1d2af(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    78e1:	48 c1 e2 10          	shl    $0x10,%rdx
    78e5:	48 39 d0             	cmp    %rdx,%rax
    78e8:	73 e2                	jae    78cc <fwp_args12+0xc>
    78ea:	48 89 c2             	mov    %rax,%rdx
    78ed:	48 c1 ea 10          	shr    $0x10,%rdx
    78f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78f5:	48 8b 15 dc d2 01 00 	mov    0x1d2dc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    78fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7900:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7904:	48 85 ff             	test   %rdi,%rdi
    7907:	74 c3                	je     78cc <fwp_args12+0xc>
    7909:	0f b6 0a             	movzbl (%rdx),%ecx
    790c:	80 f9 02             	cmp    $0x2,%cl
    790f:	74 2f                	je     7940 <fwp_args12+0x80>
    7911:	80 f9 01             	cmp    $0x1,%cl
    7914:	75 b6                	jne    78cc <fwp_args12+0xc>
    7916:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7919:	0f b7 c0             	movzwl %ax,%eax
    791c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    791f:	48 0f af c1          	imul   %rcx,%rax
    7923:	48 c1 e8 20          	shr    $0x20,%rax
    7927:	48 39 d0             	cmp    %rdx,%rax
    792a:	73 a0                	jae    78cc <fwp_args12+0xc>
    792c:	48 01 c7             	add    %rax,%rdi
    792f:	0f b6 07             	movzbl (%rdi),%eax
    7932:	84 c0                	test   %al,%al
    7934:	74 96                	je     78cc <fwp_args12+0xc>
    7936:	3c fd                	cmp    $0xfd,%al
    7938:	77 0c                	ja     7946 <fwp_args12+0x86>
    793a:	83 c0 01             	add    $0x1,%eax
    793d:	88 07                	mov    %al,(%rdi)
    793f:	c3                   	ret
    7940:	66 85 c0             	test   %ax,%ax
    7943:	74 ea                	je     792f <fwp_args12+0x6f>
    7945:	c3                   	ret
    7946:	e9 e5 da ff ff       	jmp    5430 <fwp_rc_wide_dup>
    794b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007950 <fwp_args23>:
    7950:	f3 0f 1e fa          	endbr64
    7954:	85 d2                	test   %edx,%edx
    7956:	74 04                	je     795c <fwp_args23+0xc>
    7958:	85 f6                	test   %esi,%esi
    795a:	74 04                	je     7960 <fwp_args23+0x10>
    795c:	c3                   	ret
    795d:	0f 1f 00             	nopl   (%rax)
    7960:	48 8b 15 51 d2 01 00 	mov    0x1d251(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7967:	48 8b 07             	mov    (%rdi),%rax
    796a:	48 2b 05 1f d2 01 00 	sub    0x1d21f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7971:	48 c1 e2 10          	shl    $0x10,%rdx
    7975:	48 39 d0             	cmp    %rdx,%rax
    7978:	73 e2                	jae    795c <fwp_args23+0xc>
    797a:	48 89 c2             	mov    %rax,%rdx
    797d:	48 c1 ea 10          	shr    $0x10,%rdx
    7981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7985:	48 8b 15 4c d2 01 00 	mov    0x1d24c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    798c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7990:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7994:	48 85 ff             	test   %rdi,%rdi
    7997:	74 c3                	je     795c <fwp_args23+0xc>
    7999:	0f b6 0a             	movzbl (%rdx),%ecx
    799c:	80 f9 02             	cmp    $0x2,%cl
    799f:	74 2f                	je     79d0 <fwp_args23+0x80>
    79a1:	80 f9 01             	cmp    $0x1,%cl
    79a4:	75 b6                	jne    795c <fwp_args23+0xc>
    79a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79a9:	0f b7 c0             	movzwl %ax,%eax
    79ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79af:	48 0f af c1          	imul   %rcx,%rax
    79b3:	48 c1 e8 20          	shr    $0x20,%rax
    79b7:	48 39 d0             	cmp    %rdx,%rax
    79ba:	73 a0                	jae    795c <fwp_args23+0xc>
    79bc:	48 01 c7             	add    %rax,%rdi
    79bf:	0f b6 07             	movzbl (%rdi),%eax
    79c2:	84 c0                	test   %al,%al
    79c4:	74 96                	je     795c <fwp_args23+0xc>
    79c6:	3c fd                	cmp    $0xfd,%al
    79c8:	77 0c                	ja     79d6 <fwp_args23+0x86>
    79ca:	83 c0 01             	add    $0x1,%eax
    79cd:	88 07                	mov    %al,(%rdi)
    79cf:	c3                   	ret
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	74 ea                	je     79bf <fwp_args23+0x6f>
    79d5:	c3                   	ret
    79d6:	e9 55 da ff ff       	jmp    5430 <fwp_rc_wide_dup>
    79db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000079e0 <fwp_caps12>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	48 83 ec 18          	sub    $0x18,%rsp
    79e8:	8b 57 04             	mov    0x4(%rdi),%edx
    79eb:	48 89 f8             	mov    %rdi,%rax
    79ee:	85 d2                	test   %edx,%edx
    79f0:	0f 84 9a 00 00 00    	je     7a90 <fwp_caps12+0xb0>
    79f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    79fa:	85 f6                	test   %esi,%esi
    79fc:	0f 85 9e 00 00 00    	jne    7aa0 <fwp_caps12+0xc0>
    7a02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a07:	e8 44 f0 ff ff       	call   6a50 <fwp_drop0>
    7a0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a11:	48 8b 0d a0 d1 01 00 	mov    0x1d1a0(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7a18:	48 89 c2             	mov    %rax,%rdx
    7a1b:	48 2b 15 6e d1 01 00 	sub    0x1d16e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7a22:	48 c1 e1 10          	shl    $0x10,%rcx
    7a26:	48 39 ca             	cmp    %rcx,%rdx
    7a29:	73 6d                	jae    7a98 <fwp_caps12+0xb8>
    7a2b:	48 89 d1             	mov    %rdx,%rcx
    7a2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a36:	48 8b 0d 9b d1 01 00 	mov    0x1d19b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7a3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a45:	48 85 f6             	test   %rsi,%rsi
    7a48:	74 4e                	je     7a98 <fwp_caps12+0xb8>
    7a4a:	0f b6 39             	movzbl (%rcx),%edi
    7a4d:	40 80 ff 02          	cmp    $0x2,%dil
    7a51:	0f 84 b9 00 00 00    	je     7b10 <fwp_caps12+0x130>
    7a57:	40 80 ff 01          	cmp    $0x1,%dil
    7a5b:	75 3b                	jne    7a98 <fwp_caps12+0xb8>
    7a5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a60:	0f b7 d2             	movzwl %dx,%edx
    7a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a66:	48 0f af d7          	imul   %rdi,%rdx
    7a6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a6e:	48 39 ca             	cmp    %rcx,%rdx
    7a71:	73 25                	jae    7a98 <fwp_caps12+0xb8>
    7a73:	48 01 d6             	add    %rdx,%rsi
    7a76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a79:	75 1d                	jne    7a98 <fwp_caps12+0xb8>
    7a7b:	48 89 c7             	mov    %rax,%rdi
    7a7e:	48 83 c4 18          	add    $0x18,%rsp
    7a82:	e9 09 dd ff ff       	jmp    5790 <fwp_mem_free>
    7a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a8e:	00 00 
    7a90:	85 f6                	test   %esi,%esi
    7a92:	0f 84 79 ff ff ff    	je     7a11 <fwp_caps12+0x31>
    7a98:	48 83 c4 18          	add    $0x18,%rsp
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 05 11 d1 01 00 	mov    0x1d111(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7aa7:	48 2b 3d e2 d0 01 00 	sub    0x1d0e2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7aae:	48 c1 e0 10          	shl    $0x10,%rax
    7ab2:	48 39 c7             	cmp    %rax,%rdi
    7ab5:	73 e1                	jae    7a98 <fwp_caps12+0xb8>
    7ab7:	48 89 f8             	mov    %rdi,%rax
    7aba:	48 c1 e8 10          	shr    $0x10,%rax
    7abe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ac2:	48 8b 05 0f d1 01 00 	mov    0x1d10f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7ac9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7acd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ad1:	48 85 c0             	test   %rax,%rax
    7ad4:	74 c2                	je     7a98 <fwp_caps12+0xb8>
    7ad6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ad9:	80 f9 02             	cmp    $0x2,%cl
    7adc:	74 42                	je     7b20 <fwp_caps12+0x140>
    7ade:	80 f9 01             	cmp    $0x1,%cl
    7ae1:	75 b5                	jne    7a98 <fwp_caps12+0xb8>
    7ae3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae6:	0f b7 ff             	movzwl %di,%edi
    7ae9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aec:	48 0f af f9          	imul   %rcx,%rdi
    7af0:	48 c1 ef 20          	shr    $0x20,%rdi
    7af4:	48 39 d7             	cmp    %rdx,%rdi
    7af7:	73 9f                	jae    7a98 <fwp_caps12+0xb8>
    7af9:	48 01 f8             	add    %rdi,%rax
    7afc:	0f b6 10             	movzbl (%rax),%edx
    7aff:	84 d2                	test   %dl,%dl
    7b01:	74 95                	je     7a98 <fwp_caps12+0xb8>
    7b03:	80 fa fd             	cmp    $0xfd,%dl
    7b06:	77 23                	ja     7b2b <fwp_caps12+0x14b>
    7b08:	83 c2 01             	add    $0x1,%edx
    7b0b:	88 10                	mov    %dl,(%rax)
    7b0d:	eb 89                	jmp    7a98 <fwp_caps12+0xb8>
    7b0f:	90                   	nop
    7b10:	66 85 d2             	test   %dx,%dx
    7b13:	0f 85 7f ff ff ff    	jne    7a98 <fwp_caps12+0xb8>
    7b19:	e9 58 ff ff ff       	jmp    7a76 <fwp_caps12+0x96>
    7b1e:	66 90                	xchg   %ax,%ax
    7b20:	66 85 ff             	test   %di,%di
    7b23:	0f 85 6f ff ff ff    	jne    7a98 <fwp_caps12+0xb8>
    7b29:	eb d1                	jmp    7afc <fwp_caps12+0x11c>
    7b2b:	48 89 c7             	mov    %rax,%rdi
    7b2e:	48 83 c4 18          	add    $0x18,%rsp
    7b32:	e9 f9 d8 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b3e:	00 00 

0000000000007b40 <fwp_drop2>:
    7b40:	48 8b 0d 71 d0 01 00 	mov    0x1d071(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7b47:	48 89 f8             	mov    %rdi,%rax
    7b4a:	48 2b 05 3f d0 01 00 	sub    0x1d03f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7b51:	48 c1 e1 10          	shl    $0x10,%rcx
    7b55:	48 39 c8             	cmp    %rcx,%rax
    7b58:	0f 83 42 01 00 00    	jae    7ca0 <fwp_drop2+0x160>
    7b5e:	48 83 ec 18          	sub    $0x18,%rsp
    7b62:	48 89 fa             	mov    %rdi,%rdx
    7b65:	4c 8d 05 74 bc 01 00 	lea    0x1bc74(%rip),%r8        # 237e0 <fwp_heap>
    7b6c:	48 89 c1             	mov    %rax,%rcx
    7b6f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7b76:	48 c1 e9 10          	shr    $0x10,%rcx
    7b7a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b7e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7b82:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7b86:	48 85 c9             	test   %rcx,%rcx
    7b89:	74 40                	je     7bcb <fwp_drop2+0x8b>
    7b8b:	0f b6 3e             	movzbl (%rsi),%edi
    7b8e:	40 80 ff 02          	cmp    $0x2,%dil
    7b92:	74 3c                	je     7bd0 <fwp_drop2+0x90>
    7b94:	40 80 ff 01          	cmp    $0x1,%dil
    7b98:	75 31                	jne    7bcb <fwp_drop2+0x8b>
    7b9a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7b9d:	0f b7 c0             	movzwl %ax,%eax
    7ba0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7ba3:	48 0f af c7          	imul   %rdi,%rax
    7ba7:	48 c1 e8 20          	shr    $0x20,%rax
    7bab:	48 39 f0             	cmp    %rsi,%rax
    7bae:	73 1b                	jae    7bcb <fwp_drop2+0x8b>
    7bb0:	48 01 c1             	add    %rax,%rcx
    7bb3:	0f b6 01             	movzbl (%rcx),%eax
    7bb6:	84 c0                	test   %al,%al
    7bb8:	74 11                	je     7bcb <fwp_drop2+0x8b>
    7bba:	3c 01                	cmp    $0x1,%al
    7bbc:	74 22                	je     7be0 <fwp_drop2+0xa0>
    7bbe:	3c ff                	cmp    $0xff,%al
    7bc0:	0f 84 0a 01 00 00    	je     7cd0 <fwp_drop2+0x190>
    7bc6:	83 e8 01             	sub    $0x1,%eax
    7bc9:	88 01                	mov    %al,(%rcx)
    7bcb:	48 83 c4 18          	add    $0x18,%rsp
    7bcf:	c3                   	ret
    7bd0:	66 85 c0             	test   %ax,%ax
    7bd3:	74 de                	je     7bb3 <fwp_drop2+0x73>
    7bd5:	48 83 c4 18          	add    $0x18,%rsp
    7bd9:	c3                   	ret
    7bda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7be0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7be4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7beb:	48 89 f8             	mov    %rdi,%rax
    7bee:	48 c1 e1 10          	shl    $0x10,%rcx
    7bf2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7bf9:	48 39 c8             	cmp    %rcx,%rax
    7bfc:	73 62                	jae    7c60 <fwp_drop2+0x120>
    7bfe:	48 89 c1             	mov    %rax,%rcx
    7c01:	48 c1 e9 10          	shr    $0x10,%rcx
    7c05:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c09:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7c0d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7c11:	48 85 c9             	test   %rcx,%rcx
    7c14:	74 4a                	je     7c60 <fwp_drop2+0x120>
    7c16:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7c1a:	41 80 f9 02          	cmp    $0x2,%r9b
    7c1e:	0f 84 9c 00 00 00    	je     7cc0 <fwp_drop2+0x180>
    7c24:	41 80 f9 01          	cmp    $0x1,%r9b
    7c28:	75 36                	jne    7c60 <fwp_drop2+0x120>
    7c2a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7c2e:	0f b7 c0             	movzwl %ax,%eax
    7c31:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7c34:	49 0f af c1          	imul   %r9,%rax
    7c38:	48 c1 e8 20          	shr    $0x20,%rax
    7c3c:	48 39 f0             	cmp    %rsi,%rax
    7c3f:	73 1f                	jae    7c60 <fwp_drop2+0x120>
    7c41:	48 01 c1             	add    %rax,%rcx
    7c44:	0f b6 01             	movzbl (%rcx),%eax
    7c47:	84 c0                	test   %al,%al
    7c49:	74 15                	je     7c60 <fwp_drop2+0x120>
    7c4b:	3c 01                	cmp    $0x1,%al
    7c4d:	74 59                	je     7ca8 <fwp_drop2+0x168>
    7c4f:	3c ff                	cmp    $0xff,%al
    7c51:	0f 84 ef 00 00 00    	je     7d46 <fwp_drop2+0x206>
    7c57:	83 e8 01             	sub    $0x1,%eax
    7c5a:	88 01                	mov    %al,(%rcx)
    7c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c60:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7c64:	48 89 d7             	mov    %rdx,%rdi
    7c67:	48 89 0c 24          	mov    %rcx,(%rsp)
    7c6b:	e8 d0 ea ff ff       	call   6740 <fwp_rc_free_arr>
    7c70:	4c 8d 05 69 bb 01 00 	lea    0x1bb69(%rip),%r8        # 237e0 <fwp_heap>
    7c77:	48 8b 04 24          	mov    (%rsp),%rax
    7c7b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7c82:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c89:	48 c1 e2 10          	shl    $0x10,%rdx
    7c8d:	48 39 d0             	cmp    %rdx,%rax
    7c90:	0f 83 35 ff ff ff    	jae    7bcb <fwp_drop2+0x8b>
    7c96:	48 8b 14 24          	mov    (%rsp),%rdx
    7c9a:	e9 cd fe ff ff       	jmp    7b6c <fwp_drop2+0x2c>
    7c9f:	90                   	nop
    7ca0:	c3                   	ret
    7ca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ca8:	48 89 14 24          	mov    %rdx,(%rsp)
    7cac:	e8 8f ea ff ff       	call   6740 <fwp_rc_free_arr>
    7cb1:	48 8b 14 24          	mov    (%rsp),%rdx
    7cb5:	eb a9                	jmp    7c60 <fwp_drop2+0x120>
    7cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cbe:	00 00 
    7cc0:	66 85 c0             	test   %ax,%ax
    7cc3:	75 9b                	jne    7c60 <fwp_drop2+0x120>
    7cc5:	e9 7a ff ff ff       	jmp    7c44 <fwp_drop2+0x104>
    7cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cd0:	48 89 c8             	mov    %rcx,%rax
    7cd3:	48 c1 e8 11          	shr    $0x11,%rax
    7cd7:	48 31 c8             	xor    %rcx,%rax
    7cda:	48 89 c2             	mov    %rax,%rdx
    7cdd:	48 c1 ea 09          	shr    $0x9,%rdx
    7ce1:	48 31 d0             	xor    %rdx,%rax
    7ce4:	0f b6 d0             	movzbl %al,%edx
    7ce7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7cee:	00 
    7cef:	48 85 c0             	test   %rax,%rax
    7cf2:	75 19                	jne    7d0d <fwp_drop2+0x1cd>
    7cf4:	e9 d3 00 00 00       	jmp    7dcc <fwp_drop2+0x28c>
    7cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7d04:	48 85 c0             	test   %rax,%rax
    7d07:	0f 84 bf 00 00 00    	je     7dcc <fwp_drop2+0x28c>
    7d0d:	48 89 c2             	mov    %rax,%rdx
    7d10:	48 39 08             	cmp    %rcx,(%rax)
    7d13:	75 eb                	jne    7d00 <fwp_drop2+0x1c0>
    7d15:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7d19:	48 83 ea 01          	sub    $0x1,%rdx
    7d1d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7d21:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d28:	0f 85 9d fe ff ff    	jne    7bcb <fwp_drop2+0x8b>
    7d2e:	48 89 cf             	mov    %rcx,%rdi
    7d31:	48 89 0c 24          	mov    %rcx,(%rsp)
    7d35:	e8 16 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7d3a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7d3e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d41:	e9 85 fe ff ff       	jmp    7bcb <fwp_drop2+0x8b>
    7d46:	48 89 ce             	mov    %rcx,%rsi
    7d49:	48 c1 ee 11          	shr    $0x11,%rsi
    7d4d:	48 31 ce             	xor    %rcx,%rsi
    7d50:	48 89 f0             	mov    %rsi,%rax
    7d53:	48 c1 e8 09          	shr    $0x9,%rax
    7d57:	48 31 c6             	xor    %rax,%rsi
    7d5a:	40 0f b6 f6          	movzbl %sil,%esi
    7d5e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7d65:	00 
    7d66:	48 85 c0             	test   %rax,%rax
    7d69:	75 1e                	jne    7d89 <fwp_drop2+0x249>
    7d6b:	eb 5f                	jmp    7dcc <fwp_drop2+0x28c>
    7d6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7d74:	00 
    7d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d7c:	00 00 00 00 
    7d80:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7d84:	48 85 c0             	test   %rax,%rax
    7d87:	74 43                	je     7dcc <fwp_drop2+0x28c>
    7d89:	48 89 c6             	mov    %rax,%rsi
    7d8c:	48 39 08             	cmp    %rcx,(%rax)
    7d8f:	75 ef                	jne    7d80 <fwp_drop2+0x240>
    7d91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d95:	48 83 ee 01          	sub    $0x1,%rsi
    7d99:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7d9d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7da4:	0f 85 b6 fe ff ff    	jne    7c60 <fwp_drop2+0x120>
    7daa:	48 89 cf             	mov    %rcx,%rdi
    7dad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7db2:	48 89 0c 24          	mov    %rcx,(%rsp)
    7db6:	e8 95 d7 ff ff       	call   5550 <fwp_rc_forget_slot>
    7dbb:	48 8b 0c 24          	mov    (%rsp),%rcx
    7dbf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7dc4:	c6 01 fe             	movb   $0xfe,(%rcx)
    7dc7:	e9 94 fe ff ff       	jmp    7c60 <fwp_drop2+0x120>
    7dcc:	48 8d 3d b5 7a 00 00 	lea    0x7ab5(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7dd3:	e8 18 c6 ff ff       	call   43f0 <fwp_trap>
    7dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7ddf:	00 

0000000000007de0 <fwp_arg_drop23>:
    7de0:	f3 0f 1e fa          	endbr64
    7de4:	85 f6                	test   %esi,%esi
    7de6:	75 04                	jne    7dec <fwp_arg_drop23+0xc>
    7de8:	85 d2                	test   %edx,%edx
    7dea:	75 04                	jne    7df0 <fwp_arg_drop23+0x10>
    7dec:	c3                   	ret
    7ded:	0f 1f 00             	nopl   (%rax)
    7df0:	48 8b 3f             	mov    (%rdi),%rdi
    7df3:	e9 48 fd ff ff       	jmp    7b40 <fwp_drop2>
    7df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7dff:	00 

0000000000007e00 <fwp_caps23>:
    7e00:	f3 0f 1e fa          	endbr64
    7e04:	48 83 ec 18          	sub    $0x18,%rsp
    7e08:	8b 57 04             	mov    0x4(%rdi),%edx
    7e0b:	48 89 f8             	mov    %rdi,%rax
    7e0e:	85 d2                	test   %edx,%edx
    7e10:	0f 84 9a 00 00 00    	je     7eb0 <fwp_caps23+0xb0>
    7e16:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7e1a:	85 f6                	test   %esi,%esi
    7e1c:	0f 85 9e 00 00 00    	jne    7ec0 <fwp_caps23+0xc0>
    7e22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e27:	e8 14 fd ff ff       	call   7b40 <fwp_drop2>
    7e2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e31:	48 8b 0d 80 cd 01 00 	mov    0x1cd80(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7e38:	48 89 c2             	mov    %rax,%rdx
    7e3b:	48 2b 15 4e cd 01 00 	sub    0x1cd4e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7e42:	48 c1 e1 10          	shl    $0x10,%rcx
    7e46:	48 39 ca             	cmp    %rcx,%rdx
    7e49:	73 6d                	jae    7eb8 <fwp_caps23+0xb8>
    7e4b:	48 89 d1             	mov    %rdx,%rcx
    7e4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7e52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e56:	48 8b 0d 7b cd 01 00 	mov    0x1cd7b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7e5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e65:	48 85 f6             	test   %rsi,%rsi
    7e68:	74 4e                	je     7eb8 <fwp_caps23+0xb8>
    7e6a:	0f b6 39             	movzbl (%rcx),%edi
    7e6d:	40 80 ff 02          	cmp    $0x2,%dil
    7e71:	0f 84 b9 00 00 00    	je     7f30 <fwp_caps23+0x130>
    7e77:	40 80 ff 01          	cmp    $0x1,%dil
    7e7b:	75 3b                	jne    7eb8 <fwp_caps23+0xb8>
    7e7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7e80:	0f b7 d2             	movzwl %dx,%edx
    7e83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e86:	48 0f af d7          	imul   %rdi,%rdx
    7e8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7e8e:	48 39 ca             	cmp    %rcx,%rdx
    7e91:	73 25                	jae    7eb8 <fwp_caps23+0xb8>
    7e93:	48 01 d6             	add    %rdx,%rsi
    7e96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7e99:	75 1d                	jne    7eb8 <fwp_caps23+0xb8>
    7e9b:	48 89 c7             	mov    %rax,%rdi
    7e9e:	48 83 c4 18          	add    $0x18,%rsp
    7ea2:	e9 e9 d8 ff ff       	jmp    5790 <fwp_mem_free>
    7ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7eae:	00 00 
    7eb0:	85 f6                	test   %esi,%esi
    7eb2:	0f 84 79 ff ff ff    	je     7e31 <fwp_caps23+0x31>
    7eb8:	48 83 c4 18          	add    $0x18,%rsp
    7ebc:	c3                   	ret
    7ebd:	0f 1f 00             	nopl   (%rax)
    7ec0:	48 8b 05 f1 cc 01 00 	mov    0x1ccf1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7ec7:	48 2b 3d c2 cc 01 00 	sub    0x1ccc2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7ece:	48 c1 e0 10          	shl    $0x10,%rax
    7ed2:	48 39 c7             	cmp    %rax,%rdi
    7ed5:	73 e1                	jae    7eb8 <fwp_caps23+0xb8>
    7ed7:	48 89 f8             	mov    %rdi,%rax
    7eda:	48 c1 e8 10          	shr    $0x10,%rax
    7ede:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ee2:	48 8b 05 ef cc 01 00 	mov    0x1ccef(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7ee9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7eed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ef1:	48 85 c0             	test   %rax,%rax
    7ef4:	74 c2                	je     7eb8 <fwp_caps23+0xb8>
    7ef6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ef9:	80 f9 02             	cmp    $0x2,%cl
    7efc:	74 42                	je     7f40 <fwp_caps23+0x140>
    7efe:	80 f9 01             	cmp    $0x1,%cl
    7f01:	75 b5                	jne    7eb8 <fwp_caps23+0xb8>
    7f03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f06:	0f b7 ff             	movzwl %di,%edi
    7f09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f0c:	48 0f af f9          	imul   %rcx,%rdi
    7f10:	48 c1 ef 20          	shr    $0x20,%rdi
    7f14:	48 39 d7             	cmp    %rdx,%rdi
    7f17:	73 9f                	jae    7eb8 <fwp_caps23+0xb8>
    7f19:	48 01 f8             	add    %rdi,%rax
    7f1c:	0f b6 10             	movzbl (%rax),%edx
    7f1f:	84 d2                	test   %dl,%dl
    7f21:	74 95                	je     7eb8 <fwp_caps23+0xb8>
    7f23:	80 fa fd             	cmp    $0xfd,%dl
    7f26:	77 23                	ja     7f4b <fwp_caps23+0x14b>
    7f28:	83 c2 01             	add    $0x1,%edx
    7f2b:	88 10                	mov    %dl,(%rax)
    7f2d:	eb 89                	jmp    7eb8 <fwp_caps23+0xb8>
    7f2f:	90                   	nop
    7f30:	66 85 d2             	test   %dx,%dx
    7f33:	0f 85 7f ff ff ff    	jne    7eb8 <fwp_caps23+0xb8>
    7f39:	e9 58 ff ff ff       	jmp    7e96 <fwp_caps23+0x96>
    7f3e:	66 90                	xchg   %ax,%ax
    7f40:	66 85 ff             	test   %di,%di
    7f43:	0f 85 6f ff ff ff    	jne    7eb8 <fwp_caps23+0xb8>
    7f49:	eb d1                	jmp    7f1c <fwp_caps23+0x11c>
    7f4b:	48 89 c7             	mov    %rax,%rdi
    7f4e:	48 83 c4 18          	add    $0x18,%rsp
    7f52:	e9 d9 d4 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f5e:	00 00 

0000000000007f60 <f23>:
    7f60:	41 57                	push   %r15
    7f62:	41 56                	push   %r14
    7f64:	41 55                	push   %r13
    7f66:	41 54                	push   %r12
    7f68:	55                   	push   %rbp
    7f69:	53                   	push   %rbx
    7f6a:	48 83 ec 38          	sub    $0x38,%rsp
    7f6e:	48 8b 15 43 cc 01 00 	mov    0x1cc43(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7f75:	48 8b 0d 14 cc 01 00 	mov    0x1cc14(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    7f7c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7f83:	00 00 
    7f85:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7f8a:	49 89 fd             	mov    %rdi,%r13
    7f8d:	48 c1 e2 10          	shl    $0x10,%rdx
    7f91:	48 85 ff             	test   %rdi,%rdi
    7f94:	0f 84 0c 03 00 00    	je     82a6 <f23+0x346>
    7f9a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7f9e:	48 89 d8             	mov    %rbx,%rax
    7fa1:	48 29 c8             	sub    %rcx,%rax
    7fa4:	48 39 d0             	cmp    %rdx,%rax
    7fa7:	0f 83 c3 03 00 00    	jae    8370 <f23+0x410>
    7fad:	48 89 c2             	mov    %rax,%rdx
    7fb0:	48 c1 ea 10          	shr    $0x10,%rdx
    7fb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fb8:	48 8b 15 19 cc 01 00 	mov    0x1cc19(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7fbf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fc3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7fc7:	48 85 ff             	test   %rdi,%rdi
    7fca:	0f 84 a0 03 00 00    	je     8370 <f23+0x410>
    7fd0:	0f b6 0a             	movzbl (%rdx),%ecx
    7fd3:	80 f9 02             	cmp    $0x2,%cl
    7fd6:	0f 84 a4 02 00 00    	je     8280 <f23+0x320>
    7fdc:	80 f9 01             	cmp    $0x1,%cl
    7fdf:	75 24                	jne    8005 <f23+0xa5>
    7fe1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fe4:	0f b7 c0             	movzwl %ax,%eax
    7fe7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fea:	48 0f af c1          	imul   %rcx,%rax
    7fee:	48 c1 e8 20          	shr    $0x20,%rax
    7ff2:	48 39 d0             	cmp    %rdx,%rax
    7ff5:	73 0e                	jae    8005 <f23+0xa5>
    7ff7:	48 01 c7             	add    %rax,%rdi
    7ffa:	0f b6 07             	movzbl (%rdi),%eax
    7ffd:	84 c0                	test   %al,%al
    7fff:	0f 85 1b 03 00 00    	jne    8320 <f23+0x3c0>
    8005:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    800a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    800e:	ba 01 00 00 00       	mov    $0x1,%edx
    8013:	48 85 db             	test   %rbx,%rbx
    8016:	74 15                	je     802d <f23+0xcd>
    8018:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    801f:	00 
    8020:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8024:	48 83 c2 01          	add    $0x1,%rdx
    8028:	48 85 db             	test   %rbx,%rbx
    802b:	75 f3                	jne    8020 <f23+0xc0>
    802d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8032:	48 85 c0             	test   %rax,%rax
    8035:	0f 84 65 03 00 00    	je     83a0 <f23+0x440>
    803b:	31 db                	xor    %ebx,%ebx
    803d:	0f 1f 00             	nopl   (%rax)
    8040:	48 8b 40 10          	mov    0x10(%rax),%rax
    8044:	48 83 c3 01          	add    $0x1,%rbx
    8048:	48 85 c0             	test   %rax,%rax
    804b:	75 f3                	jne    8040 <f23+0xe0>
    804d:	48 39 d3             	cmp    %rdx,%rbx
    8050:	48 0f 47 da          	cmova  %rdx,%rbx
    8054:	48 89 d8             	mov    %rbx,%rax
    8057:	48 c1 e8 3c          	shr    $0x3c,%rax
    805b:	0f 85 e3 03 00 00    	jne    8444 <f23+0x4e4>
    8061:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8065:	be 02 00 00 00       	mov    $0x2,%esi
    806a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8071:	00 
    8072:	e8 19 dc ff ff       	call   5c90 <fwp_heap_alloc>
    8077:	48 89 28             	mov    %rbp,(%rax)
    807a:	48 8b 15 37 cb 01 00 	mov    0x1cb37(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8081:	49 89 c4             	mov    %rax,%r12
    8084:	48 2b 05 05 cb 01 00 	sub    0x1cb05(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    808b:	48 c1 e2 10          	shl    $0x10,%rdx
    808f:	48 39 d0             	cmp    %rdx,%rax
    8092:	73 57                	jae    80eb <f23+0x18b>
    8094:	48 89 c2             	mov    %rax,%rdx
    8097:	48 c1 ea 10          	shr    $0x10,%rdx
    809b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    809f:	48 8b 15 32 cb 01 00 	mov    0x1cb32(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    80a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    80ae:	48 85 ed             	test   %rbp,%rbp
    80b1:	74 38                	je     80eb <f23+0x18b>
    80b3:	0f b6 0a             	movzbl (%rdx),%ecx
    80b6:	80 f9 02             	cmp    $0x2,%cl
    80b9:	0f 84 a1 02 00 00    	je     8360 <f23+0x400>
    80bf:	80 f9 01             	cmp    $0x1,%cl
    80c2:	75 27                	jne    80eb <f23+0x18b>
    80c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80c7:	0f b7 c0             	movzwl %ax,%eax
    80ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80cd:	48 0f af c1          	imul   %rcx,%rax
    80d1:	48 c1 e8 20          	shr    $0x20,%rax
    80d5:	48 39 d0             	cmp    %rdx,%rax
    80d8:	73 11                	jae    80eb <f23+0x18b>
    80da:	48 01 c5             	add    %rax,%rbp
    80dd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    80e1:	0f 84 29 03 00 00    	je     8410 <f23+0x4b0>
    80e7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    80eb:	48 85 db             	test   %rbx,%rbx
    80ee:	74 5d                	je     814d <f23+0x1ed>
    80f0:	48 c1 e3 04          	shl    $0x4,%rbx
    80f4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    80f9:	4c 89 e5             	mov    %r12,%rbp
    80fc:	4d 89 ee             	mov    %r13,%r14
    80ff:	4c 01 e3             	add    %r12,%rbx
    8102:	0f 1f 00             	nopl   (%rax)
    8105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    810c:	00 00 00 00 
    8110:	49 8b 46 08          	mov    0x8(%r14),%rax
    8114:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8118:	48 83 c5 10          	add    $0x10,%rbp
    811c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8121:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8125:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8129:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    812e:	e8 3d e2 ff ff       	call   6370 <w107>
    8133:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8138:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    813c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8140:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8144:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8148:	48 39 eb             	cmp    %rbp,%rbx
    814b:	75 c3                	jne    8110 <f23+0x1b0>
    814d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8152:	31 db                	xor    %ebx,%ebx
    8154:	e8 e7 f9 ff ff       	call   7b40 <fwp_drop2>
    8159:	4c 89 ef             	mov    %r13,%rdi
    815c:	e8 df f9 ff ff       	call   7b40 <fwp_drop2>
    8161:	4d 8b 2c 24          	mov    (%r12),%r13
    8165:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8169:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8170:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8177:	4d 85 ed             	test   %r13,%r13
    817a:	74 3f                	je     81bb <f23+0x25b>
    817c:	0f 1f 40 00          	nopl   0x0(%rax)
    8180:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8187:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    818c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8193:	00 f0 3f 
    8196:	48 83 c3 02          	add    $0x2,%rbx
    819a:	48 89 ce             	mov    %rcx,%rsi
    819d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    81a3:	e8 48 de ff ff       	call   5ff0 <fwp_p_ad_push>
    81a8:	4c 39 eb             	cmp    %r13,%rbx
    81ab:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    81b1:	48 89 c7             	mov    %rax,%rdi
    81b4:	72 ca                	jb     8180 <f23+0x220>
    81b6:	66 49 0f 7e c5       	movq   %xmm0,%r13
    81bb:	4c 89 e7             	mov    %r12,%rdi
    81be:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    81c3:	e8 78 f4 ff ff       	call   7640 <fwp_drop4>
    81c8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81cd:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    81d2:	31 ff                	xor    %edi,%edi
    81d4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    81d9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    81de:	e8 fd e2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    81e3:	48 8b 15 ce c9 01 00 	mov    0x1c9ce(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    81ea:	48 89 c5             	mov    %rax,%rbp
    81ed:	48 2b 05 9c c9 01 00 	sub    0x1c99c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    81f4:	48 c1 e2 10          	shl    $0x10,%rdx
    81f8:	48 39 d0             	cmp    %rdx,%rax
    81fb:	73 55                	jae    8252 <f23+0x2f2>
    81fd:	48 89 c2             	mov    %rax,%rdx
    8200:	48 c1 ea 10          	shr    $0x10,%rdx
    8204:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8208:	48 8b 15 c9 c9 01 00 	mov    0x1c9c9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    820f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8213:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8217:	48 85 db             	test   %rbx,%rbx
    821a:	74 36                	je     8252 <f23+0x2f2>
    821c:	0f b6 0a             	movzbl (%rdx),%ecx
    821f:	80 f9 02             	cmp    $0x2,%cl
    8222:	0f 84 20 01 00 00    	je     8348 <f23+0x3e8>
    8228:	80 f9 01             	cmp    $0x1,%cl
    822b:	75 25                	jne    8252 <f23+0x2f2>
    822d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8230:	0f b7 c0             	movzwl %ax,%eax
    8233:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8236:	48 0f af c1          	imul   %rcx,%rax
    823a:	48 c1 e8 20          	shr    $0x20,%rax
    823e:	48 39 d0             	cmp    %rdx,%rax
    8241:	73 0f                	jae    8252 <f23+0x2f2>
    8243:	48 01 c3             	add    %rax,%rbx
    8246:	80 3b ff             	cmpb   $0xff,(%rbx)
    8249:	0f 84 b4 01 00 00    	je     8403 <f23+0x4a3>
    824f:	c6 03 01             	movb   $0x1,(%rbx)
    8252:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8257:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    825e:	00 00 
    8260:	0f 85 d9 01 00 00    	jne    843f <f23+0x4df>
    8266:	48 83 c4 38          	add    $0x38,%rsp
    826a:	48 89 e8             	mov    %rbp,%rax
    826d:	5b                   	pop    %rbx
    826e:	5d                   	pop    %rbp
    826f:	41 5c                	pop    %r12
    8271:	41 5d                	pop    %r13
    8273:	41 5e                	pop    %r14
    8275:	41 5f                	pop    %r15
    8277:	c3                   	ret
    8278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    827f:	00 
    8280:	66 85 c0             	test   %ax,%ax
    8283:	0f 85 7c fd ff ff    	jne    8005 <f23+0xa5>
    8289:	0f b6 07             	movzbl (%rdi),%eax
    828c:	84 c0                	test   %al,%al
    828e:	0f 84 71 fd ff ff    	je     8005 <f23+0xa5>
    8294:	3c fd                	cmp    $0xfd,%al
    8296:	0f 87 99 01 00 00    	ja     8435 <f23+0x4d5>
    829c:	83 c0 01             	add    $0x1,%eax
    829f:	88 07                	mov    %al,(%rdi)
    82a1:	e9 5f fd ff ff       	jmp    8005 <f23+0xa5>
    82a6:	48 f7 d9             	neg    %rcx
    82a9:	48 39 d1             	cmp    %rdx,%rcx
    82ac:	0f 83 ee 00 00 00    	jae    83a0 <f23+0x440>
    82b2:	48 89 c8             	mov    %rcx,%rax
    82b5:	48 c1 e8 10          	shr    $0x10,%rax
    82b9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    82bd:	48 8b 05 14 c9 01 00 	mov    0x1c914(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    82c4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    82c8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    82cc:	48 85 ff             	test   %rdi,%rdi
    82cf:	0f 84 cb 00 00 00    	je     83a0 <f23+0x440>
    82d5:	0f b6 02             	movzbl (%rdx),%eax
    82d8:	3c 02                	cmp    $0x2,%al
    82da:	0f 84 9a 00 00 00    	je     837a <f23+0x41a>
    82e0:	3c 01                	cmp    $0x1,%al
    82e2:	0f 85 b8 00 00 00    	jne    83a0 <f23+0x440>
    82e8:	0f b7 c1             	movzwl %cx,%eax
    82eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82f1:	48 0f af c1          	imul   %rcx,%rax
    82f5:	48 c1 e8 20          	shr    $0x20,%rax
    82f9:	48 39 d0             	cmp    %rdx,%rax
    82fc:	0f 83 9e 00 00 00    	jae    83a0 <f23+0x440>
    8302:	48 01 c7             	add    %rax,%rdi
    8305:	0f b6 07             	movzbl (%rdi),%eax
    8308:	84 c0                	test   %al,%al
    830a:	0f 84 90 00 00 00    	je     83a0 <f23+0x440>
    8310:	31 db                	xor    %ebx,%ebx
    8312:	0f 1f 00             	nopl   (%rax)
    8315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    831c:	00 00 00 00 
    8320:	3c fd                	cmp    $0xfd,%al
    8322:	0f 87 f5 00 00 00    	ja     841d <f23+0x4bd>
    8328:	83 c0 01             	add    $0x1,%eax
    832b:	88 07                	mov    %al,(%rdi)
    832d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8332:	31 d2                	xor    %edx,%edx
    8334:	4d 85 ed             	test   %r13,%r13
    8337:	0f 85 cd fc ff ff    	jne    800a <f23+0xaa>
    833d:	e9 eb fc ff ff       	jmp    802d <f23+0xcd>
    8342:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8348:	66 85 c0             	test   %ax,%ax
    834b:	0f 85 01 ff ff ff    	jne    8252 <f23+0x2f2>
    8351:	e9 f0 fe ff ff       	jmp    8246 <f23+0x2e6>
    8356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    835d:	00 00 00 
    8360:	66 85 c0             	test   %ax,%ax
    8363:	0f 85 82 fd ff ff    	jne    80eb <f23+0x18b>
    8369:	e9 6f fd ff ff       	jmp    80dd <f23+0x17d>
    836e:	66 90                	xchg   %ax,%ax
    8370:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8375:	e9 94 fc ff ff       	jmp    800e <f23+0xae>
    837a:	66 85 c9             	test   %cx,%cx
    837d:	75 21                	jne    83a0 <f23+0x440>
    837f:	0f b6 07             	movzbl (%rdi),%eax
    8382:	84 c0                	test   %al,%al
    8384:	74 1a                	je     83a0 <f23+0x440>
    8386:	3c fd                	cmp    $0xfd,%al
    8388:	0f 87 c2 00 00 00    	ja     8450 <f23+0x4f0>
    838e:	83 c0 01             	add    $0x1,%eax
    8391:	88 07                	mov    %al,(%rdi)
    8393:	66 90                	xchg   %ax,%ax
    8395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    839c:	00 00 00 00 
    83a0:	be 02 00 00 00       	mov    $0x2,%esi
    83a5:	bf 08 00 00 00       	mov    $0x8,%edi
    83aa:	e8 e1 d8 ff ff       	call   5c90 <fwp_heap_alloc>
    83af:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    83b6:	48 8b 15 fb c7 01 00 	mov    0x1c7fb(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    83bd:	49 89 c4             	mov    %rax,%r12
    83c0:	48 2b 05 c9 c7 01 00 	sub    0x1c7c9(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    83c7:	48 c1 e2 10          	shl    $0x10,%rdx
    83cb:	48 39 d0             	cmp    %rdx,%rax
    83ce:	73 57                	jae    8427 <f23+0x4c7>
    83d0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83d7:	00 00 
    83d9:	48 89 c2             	mov    %rax,%rdx
    83dc:	48 c1 ea 10          	shr    $0x10,%rdx
    83e0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83e4:	48 8b 15 ed c7 01 00 	mov    0x1c7ed(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    83eb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83ef:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    83f3:	48 85 ed             	test   %rbp,%rbp
    83f6:	0f 84 51 fd ff ff    	je     814d <f23+0x1ed>
    83fc:	31 db                	xor    %ebx,%ebx
    83fe:	e9 b0 fc ff ff       	jmp    80b3 <f23+0x153>
    8403:	48 89 df             	mov    %rbx,%rdi
    8406:	e8 45 d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    840b:	e9 3f fe ff ff       	jmp    824f <f23+0x2ef>
    8410:	48 89 ef             	mov    %rbp,%rdi
    8413:	e8 38 d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    8418:	e9 ca fc ff ff       	jmp    80e7 <f23+0x187>
    841d:	e8 0e d0 ff ff       	call   5430 <fwp_rc_wide_dup>
    8422:	e9 06 ff ff ff       	jmp    832d <f23+0x3cd>
    8427:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    842e:	00 00 
    8430:	e9 18 fd ff ff       	jmp    814d <f23+0x1ed>
    8435:	e8 f6 cf ff ff       	call   5430 <fwp_rc_wide_dup>
    843a:	e9 c6 fb ff ff       	jmp    8005 <f23+0xa5>
    843f:	e8 1c b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    8444:	48 8d 3d 45 6d 00 00 	lea    0x6d45(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    844b:	e8 a0 bf ff ff       	call   43f0 <fwp_trap>
    8450:	e8 db cf ff ff       	call   5430 <fwp_rc_wide_dup>
    8455:	e9 46 ff ff ff       	jmp    83a0 <f23+0x440>
    845a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008460 <fwp_owned_entry23>:
    8460:	f3 0f 1e fa          	endbr64
    8464:	48 8b 3f             	mov    (%rdi),%rdi
    8467:	e9 f4 fa ff ff       	jmp    7f60 <f23>
    846c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008470 <e23>:
    8470:	f3 0f 1e fa          	endbr64
    8474:	53                   	push   %rbx
    8475:	48 8b 1f             	mov    (%rdi),%rbx
    8478:	48 89 df             	mov    %rbx,%rdi
    847b:	e8 90 e1 ff ff       	call   6610 <fwp_rc_share>
    8480:	48 89 df             	mov    %rbx,%rdi
    8483:	e8 d8 fa ff ff       	call   7f60 <f23>
    8488:	48 89 c3             	mov    %rax,%rbx
    848b:	48 89 c7             	mov    %rax,%rdi
    848e:	e8 7d e1 ff ff       	call   6610 <fwp_rc_share>
    8493:	48 89 d8             	mov    %rbx,%rax
    8496:	5b                   	pop    %rbx
    8497:	c3                   	ret
    8498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    849f:	00 

00000000000084a0 <f12>:
    84a0:	41 57                	push   %r15
    84a2:	41 56                	push   %r14
    84a4:	41 55                	push   %r13
    84a6:	41 54                	push   %r12
    84a8:	4c 8d 25 b1 eb ff ff 	lea    -0x144f(%rip),%r12        # 7060 <fwp_tape_scope_release>
    84af:	55                   	push   %rbp
    84b0:	53                   	push   %rbx
    84b1:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    84b8:	48 8b 05 b9 cf 01 00 	mov    0x1cfb9(%rip),%rax        # 25478 <fwp_cleanups>
    84bf:	48 8b 15 f2 c6 01 00 	mov    0x1c6f2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    84c6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    84cd:	00 00 
    84cf:	48 89 ac 24 e8 00 00 	mov    %rbp,0xe8(%rsp)
    84d6:	00 
    84d7:	48 89 fd             	mov    %rdi,%rbp
    84da:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    84e1:	ff 
    84e2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    84e7:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    84ec:	48 c1 e2 10          	shl    $0x10,%rdx
    84f0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    84f5:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    84fa:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    84ff:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    8504:	48 89 05 6d cf 01 00 	mov    %rax,0x1cf6d(%rip)        # 25478 <fwp_cleanups>
    850b:	48 8d 05 fe aa 00 00 	lea    0xaafe(%rip),%rax        # 13010 <fc23>
    8512:	48 2b 05 77 c6 01 00 	sub    0x1c677(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8519:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
    851e:	48 39 d0             	cmp    %rdx,%rax
    8521:	73 5d                	jae    8580 <f12+0xe0>
    8523:	48 89 c2             	mov    %rax,%rdx
    8526:	48 c1 ea 10          	shr    $0x10,%rdx
    852a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    852e:	48 8b 15 a3 c6 01 00 	mov    0x1c6a3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8535:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8539:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    853d:	48 85 ff             	test   %rdi,%rdi
    8540:	74 3e                	je     8580 <f12+0xe0>
    8542:	0f b6 0a             	movzbl (%rdx),%ecx
    8545:	80 f9 02             	cmp    $0x2,%cl
    8548:	0f 84 2a 0f 00 00    	je     9478 <f12+0xfd8>
    854e:	80 f9 01             	cmp    $0x1,%cl
    8551:	75 2d                	jne    8580 <f12+0xe0>
    8553:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8556:	0f b7 c0             	movzwl %ax,%eax
    8559:	8b 52 1c             	mov    0x1c(%rdx),%edx
    855c:	48 0f af c1          	imul   %rcx,%rax
    8560:	48 c1 e8 20          	shr    $0x20,%rax
    8564:	48 39 d0             	cmp    %rdx,%rax
    8567:	73 17                	jae    8580 <f12+0xe0>
    8569:	48 01 c7             	add    %rax,%rdi
    856c:	0f b6 07             	movzbl (%rdi),%eax
    856f:	84 c0                	test   %al,%al
    8571:	74 0d                	je     8580 <f12+0xe0>
    8573:	3c fd                	cmp    $0xfd,%al
    8575:	0f 87 5f 11 00 00    	ja     96da <f12+0x123a>
    857b:	83 c0 01             	add    $0x1,%eax
    857e:	88 07                	mov    %al,(%rdi)
    8580:	48 8d 3d 89 aa 00 00 	lea    0xaa89(%rip),%rdi        # 13010 <fc23>
    8587:	e8 a4 e7 ff ff       	call   6d30 <fwp_closure_drop>
    858c:	48 85 ed             	test   %rbp,%rbp
    858f:	0f 84 b5 10 00 00    	je     964a <f12+0x11aa>
    8595:	48 89 e8             	mov    %rbp,%rax
    8598:	31 db                	xor    %ebx,%ebx
    859a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    85a4:	48 83 c3 01          	add    $0x1,%rbx
    85a8:	48 85 c0             	test   %rax,%rax
    85ab:	75 f3                	jne    85a0 <f12+0x100>
    85ad:	31 ff                	xor    %edi,%edi
    85af:	e8 9c bc ff ff       	call   4250 <descent_phase_step>
    85b4:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    85bb:	0f 87 94 11 00 00    	ja     9755 <f12+0x12b5>
    85c1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    85c6:	8b 35 b4 aa 00 00    	mov    0xaab4(%rip),%esi        # 13080 <registered_finish.0>
    85cc:	85 f6                	test   %esi,%esi
    85ce:	0f 84 74 0e 00 00    	je     9448 <f12+0xfa8>
    85d4:	48 8b 1d 1d ab 01 00 	mov    0x1ab1d(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    85db:	4c 8b 2d 26 ab 01 00 	mov    0x1ab26(%rip),%r13        # 23108 <fwp_ntapes>
    85e2:	4c 39 eb             	cmp    %r13,%rbx
    85e5:	0f 8d e5 05 00 00    	jge    8bd0 <f12+0x730>
    85eb:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    85ef:	48 03 05 1a ab 01 00 	add    0x1ab1a(%rip),%rax        # 23110 <fwp_tapes>
    85f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85fd:	00 00 00 
    8600:	8b 48 04             	mov    0x4(%rax),%ecx
    8603:	85 c9                	test   %ecx,%ecx
    8605:	75 0c                	jne    8613 <f12+0x173>
    8607:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    860d:	0f 86 bd 05 00 00    	jbe    8bd0 <f12+0x730>
    8613:	48 83 c3 01          	add    $0x1,%rbx
    8617:	48 83 c0 68          	add    $0x68,%rax
    861b:	4c 39 eb             	cmp    %r13,%rbx
    861e:	75 e0                	jne    8600 <f12+0x160>
    8620:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    8627:	0f 8f 4c 11 00 00    	jg     9779 <f12+0x12d9>
    862d:	4c 39 2d cc aa 01 00 	cmp    %r13,0x1aacc(%rip)        # 23100 <fwp_tapes_cap>
    8634:	4c 8b 3d d5 aa 01 00 	mov    0x1aad5(%rip),%r15        # 23110 <fwp_tapes>
    863b:	75 40                	jne    867d <f12+0x1dd>
    863d:	4d 85 ed             	test   %r13,%r13
    8640:	0f 85 8a 0f 00 00    	jne    95d0 <f12+0x1130>
    8646:	be 68 00 00 00       	mov    $0x68,%esi
    864b:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8651:	4c 89 ff             	mov    %r15,%rdi
    8654:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8659:	e8 72 af ff ff       	call   35d0 <realloc@plt>
    865e:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8663:	48 85 c0             	test   %rax,%rax
    8666:	49 89 c7             	mov    %rax,%r15
    8669:	0f 84 55 0e 00 00    	je     94c4 <f12+0x1024>
    866f:	48 89 05 9a aa 01 00 	mov    %rax,0x1aa9a(%rip)        # 23110 <fwp_tapes>
    8676:	4c 89 35 83 aa 01 00 	mov    %r14,0x1aa83(%rip)        # 23100 <fwp_tapes_cap>
    867d:	49 6b c5 68          	imul   $0x68,%r13,%rax
    8681:	49 83 c5 01          	add    $0x1,%r13
    8685:	4c 01 f8             	add    %r15,%rax
    8688:	48 8d 78 08          	lea    0x8(%rax),%rdi
    868c:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8693:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8697:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    869e:	00 
    869f:	48 29 f8             	sub    %rdi,%rax
    86a2:	8d 48 68             	lea    0x68(%rax),%ecx
    86a5:	31 c0                	xor    %eax,%eax
    86a7:	c1 e9 03             	shr    $0x3,%ecx
    86aa:	f3 48 ab             	rep stos %rax,(%rdi)
    86ad:	4c 89 2d 54 aa 01 00 	mov    %r13,0x1aa54(%rip)        # 23108 <fwp_ntapes>
    86b4:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    86b8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    86bc:	48 8d 3d 5f 6a 00 00 	lea    0x6a5f(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    86c3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    86c7:	4d 01 fe             	add    %r15,%r14
    86ca:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    86d1:	00 
    86d2:	e8 c9 ac ff ff       	call   33a0 <getenv@plt>
    86d7:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    86dc:	48 85 c0             	test   %rax,%rax
    86df:	74 09                	je     86ea <f12+0x24a>
    86e1:	80 38 30             	cmpb   $0x30,(%rax)
    86e4:	0f 84 b6 03 00 00    	je     8aa0 <f12+0x600>
    86ea:	48 83 3d b6 a9 01 00 	cmpq   $0x0,0x1a9b6(%rip)        # 230a8 <fwp_tape_cached_bytes>
    86f1:	00 
    86f2:	0f 85 28 0e 00 00    	jne    9520 <f12+0x1080>
    86f8:	41 8b 06             	mov    (%r14),%eax
    86fb:	48 8d 73 01          	lea    0x1(%rbx),%rsi
    86ff:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    8706:	00 
    8707:	48 89 35 ea a9 01 00 	mov    %rsi,0x1a9ea(%rip)        # 230f8 <fwp_tape_next_slot>
    870e:	44 8d 68 01          	lea    0x1(%rax),%r13d
    8712:	48 8b 05 5f cd 01 00 	mov    0x1cd5f(%rip),%rax        # 25478 <fwp_cleanups>
    8719:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    871e:	45 89 2e             	mov    %r13d,(%r14)
    8721:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    8728:	00 
    8729:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    8730:	ff 
    8731:	48 85 c0             	test   %rax,%rax
    8734:	75 16                	jne    874c <f12+0x2ac>
    8736:	e9 32 10 00 00       	jmp    976d <f12+0x12cd>
    873b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8740:	48 8b 00             	mov    (%rax),%rax
    8743:	48 85 c0             	test   %rax,%rax
    8746:	0f 84 21 10 00 00    	je     976d <f12+0x12cd>
    874c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8750:	75 ee                	jne    8740 <f12+0x2a0>
    8752:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8756:	89 df                	mov    %ebx,%edi
    8758:	48 63 01             	movslq (%rcx),%rax
    875b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    875f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8763:	85 c0                	test   %eax,%eax
    8765:	78 09                	js     8770 <f12+0x2d0>
    8767:	48 6b c0 68          	imul   $0x68,%rax,%rax
    876b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8770:	89 39                	mov    %edi,(%rcx)
    8772:	bf 01 00 00 00       	mov    $0x1,%edi
    8777:	48 89 34 24          	mov    %rsi,(%rsp)
    877b:	e8 d0 ba ff ff       	call   4250 <descent_phase_step>
    8780:	31 c9                	xor    %ecx,%ecx
    8782:	48 85 ed             	test   %rbp,%rbp
    8785:	48 8b 34 24          	mov    (%rsp),%rsi
    8789:	48 89 e8             	mov    %rbp,%rax
    878c:	0f 84 1e 03 00 00    	je     8ab0 <f12+0x610>
    8792:	0f 1f 00             	nopl   (%rax)
    8795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    879c:	00 00 00 00 
    87a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87a4:	48 83 c1 01          	add    $0x1,%rcx
    87a8:	48 85 c0             	test   %rax,%rax
    87ab:	75 f3                	jne    87a0 <f12+0x300>
    87ad:	48 89 ea             	mov    %rbp,%rdx
    87b0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    87b4:	48 83 c0 01          	add    $0x1,%rax
    87b8:	48 85 d2             	test   %rdx,%rdx
    87bb:	75 f3                	jne    87b0 <f12+0x310>
    87bd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    87c4:	ff ff 1f 
    87c7:	48 39 c2             	cmp    %rax,%rdx
    87ca:	0f 82 79 0f 00 00    	jb     9749 <f12+0x12a9>
    87d0:	48 85 c9             	test   %rcx,%rcx
    87d3:	0f 8e d7 02 00 00    	jle    8ab0 <f12+0x610>
    87d9:	48 39 c1             	cmp    %rax,%rcx
    87dc:	48 0f 46 c1          	cmovbe %rcx,%rax
    87e0:	49 89 c4             	mov    %rax,%r12
    87e3:	48 c1 e8 3c          	shr    $0x3c,%rax
    87e7:	0f 85 5c 0f 00 00    	jne    9749 <f12+0x12a9>
    87ed:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    87f1:	49 c1 e5 10          	shl    $0x10,%r13
    87f5:	49 09 f5             	or     %rsi,%r13
    87f8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    87ff:	00 
    8800:	be 02 00 00 00       	mov    $0x2,%esi
    8805:	e8 86 d4 ff ff       	call   5c90 <fwp_heap_alloc>
    880a:	4c 89 30             	mov    %r14,(%rax)
    880d:	48 8b 15 a4 c3 01 00 	mov    0x1c3a4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8814:	48 89 c3             	mov    %rax,%rbx
    8817:	48 2b 05 72 c3 01 00 	sub    0x1c372(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    881e:	48 c1 e2 10          	shl    $0x10,%rdx
    8822:	48 39 d0             	cmp    %rdx,%rax
    8825:	0f 83 f5 0d 00 00    	jae    9620 <f12+0x1180>
    882b:	48 89 c2             	mov    %rax,%rdx
    882e:	48 c1 ea 10          	shr    $0x10,%rdx
    8832:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8836:	48 8b 15 9b c3 01 00 	mov    0x1c39b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    883d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8841:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8845:	4d 85 f6             	test   %r14,%r14
    8848:	74 38                	je     8882 <f12+0x3e2>
    884a:	0f b6 0a             	movzbl (%rdx),%ecx
    884d:	80 f9 02             	cmp    $0x2,%cl
    8850:	0f 84 c7 02 00 00    	je     8b1d <f12+0x67d>
    8856:	80 f9 01             	cmp    $0x1,%cl
    8859:	75 27                	jne    8882 <f12+0x3e2>
    885b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    885e:	0f b7 c0             	movzwl %ax,%eax
    8861:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8864:	48 0f af c1          	imul   %rcx,%rax
    8868:	48 c1 e8 20          	shr    $0x20,%rax
    886c:	48 39 d0             	cmp    %rdx,%rax
    886f:	73 11                	jae    8882 <f12+0x3e2>
    8871:	49 01 c6             	add    %rax,%r14
    8874:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8878:	0f 84 35 0e 00 00    	je     96b3 <f12+0x1213>
    887e:	41 c6 06 01          	movb   $0x1,(%r14)
    8882:	4d 85 e4             	test   %r12,%r12
    8885:	74 6c                	je     88f3 <f12+0x453>
    8887:	4c 89 e9             	mov    %r13,%rcx
    888a:	48 89 ea             	mov    %rbp,%rdx
    888d:	31 c0                	xor    %eax,%eax
    888f:	48 c1 e1 20          	shl    $0x20,%rcx
    8893:	90                   	nop
    8894:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    889b:	00 00 00 00 
    889f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88a6:	00 00 00 00 
    88aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88b1:	00 00 00 00 
    88b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88bc:	00 00 00 00 
    88c0:	48 89 c6             	mov    %rax,%rsi
    88c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    88c8:	48 01 ce             	add    %rcx,%rsi
    88cb:	0f 80 5f 0e 00 00    	jo     9730 <f12+0x1290>
    88d1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    88d6:	48 89 c6             	mov    %rax,%rsi
    88d9:	48 83 c0 01          	add    $0x1,%rax
    88dd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    88e1:	48 c1 e6 04          	shl    $0x4,%rsi
    88e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    88ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    88ee:	4c 39 e0             	cmp    %r12,%rax
    88f1:	72 cd                	jb     88c0 <f12+0x420>
    88f3:	48 8b 03             	mov    (%rbx),%rax
    88f6:	48 d1 e8             	shr    $1,%rax
    88f9:	0f 85 31 02 00 00    	jne    8b30 <f12+0x690>
    88ff:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8906:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    890d:	0f 1f 00             	nopl   (%rax)
    8910:	48 89 df             	mov    %rbx,%rdi
    8913:	4c 89 04 24          	mov    %r8,(%rsp)
    8917:	4d 63 e5             	movslq %r13d,%r12
    891a:	e8 21 ed ff ff       	call   7640 <fwp_drop4>
    891f:	bf 02 00 00 00       	mov    $0x2,%edi
    8924:	e8 27 b9 ff ff       	call   4250 <descent_phase_step>
    8929:	4c 89 e7             	mov    %r12,%rdi
    892c:	e8 9f bd ff ff       	call   46d0 <fwp_tape_of>
    8931:	4c 8b 04 24          	mov    (%rsp),%r8
    8935:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    893a:	48 89 c6             	mov    %rax,%rsi
    893d:	0f 85 47 0e 00 00    	jne    978a <f12+0x12ea>
    8943:	48 89 c7             	mov    %rax,%rdi
    8946:	e8 b5 b2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    894b:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    8950:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    8954:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    895b:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8960:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8965:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    896a:	66 49 0f 6e f6       	movq   %r14,%xmm6
    896f:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    8973:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8977:	4c 8b 7e 40          	mov    0x40(%rsi),%r15
    897b:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    897f:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8983:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8989:	77 19                	ja     89a4 <f12+0x504>
    898b:	41 0f b7 c5          	movzwl %r13w,%eax
    898f:	83 e8 01             	sub    $0x1,%eax
    8992:	48 98                	cltq
    8994:	48 3b 05 5d a7 01 00 	cmp    0x1a75d(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    899b:	7d 07                	jge    89a4 <f12+0x504>
    899d:	48 89 05 54 a7 01 00 	mov    %rax,0x1a754(%rip)        # 230f8 <fwp_tape_next_slot>
    89a4:	48 8b 05 cd ca 01 00 	mov    0x1cacd(%rip),%rax        # 25478 <fwp_cleanups>
    89ab:	66 0f ef c9          	pxor   %xmm1,%xmm1
    89af:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    89b5:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    89bc:	00 
    89bd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    89c1:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    89c6:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    89cb:	48 8d 05 9e c6 ff ff 	lea    -0x3962(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    89d2:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    89d7:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    89de:	00 
    89df:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    89e4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    89eb:	00 
    89ec:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    89f1:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    89f5:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    89f9:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8a00:	00 
    8a01:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8a08:	00 
    8a09:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
    8a10:	00 
    8a11:	48 89 05 60 ca 01 00 	mov    %rax,0x1ca60(%rip)        # 25478 <fwp_cleanups>
    8a18:	0f 29 bc 24 90 00 00 	movaps %xmm7,0x90(%rsp)
    8a1f:	00 
    8a20:	0f 29 b4 24 a0 00 00 	movaps %xmm6,0xa0(%rsp)
    8a27:	00 
    8a28:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    8a2f:	00 
    8a30:	4d 85 c0             	test   %r8,%r8
    8a33:	0f 88 57 0a 00 00    	js     9490 <f12+0xff0>
    8a39:	4c 89 c0             	mov    %r8,%rax
    8a3c:	48 c1 f8 20          	sar    $0x20,%rax
    8a40:	49 39 c4             	cmp    %rax,%r12
    8a43:	0f 85 db 0c 00 00    	jne    9724 <f12+0x1284>
    8a49:	45 89 c2             	mov    %r8d,%r10d
    8a4c:	4d 89 d5             	mov    %r10,%r13
    8a4f:	4c 39 d2             	cmp    %r10,%rdx
    8a52:	0f 8e c0 0c 00 00    	jle    9718 <f12+0x1278>
    8a58:	4c 39 d3             	cmp    %r10,%rbx
    8a5b:	0f 8e 87 01 00 00    	jle    8be8 <f12+0x748>
    8a61:	4c 39 f3             	cmp    %r14,%rbx
    8a64:	0f 8f 56 0b 00 00    	jg     95c0 <f12+0x1120>
    8a6a:	4d 85 ff             	test   %r15,%r15
    8a6d:	0f 84 3b 0a 00 00    	je     94ae <f12+0x100e>
    8a73:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8a7a:	00 
    8a7b:	31 f6                	xor    %esi,%esi
    8a7d:	4c 89 ff             	mov    %r15,%rdi
    8a80:	45 31 f6             	xor    %r14d,%r14d
    8a83:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    8a88:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    8a8c:	e8 2f aa ff ff       	call   34c0 <memset@plt>
    8a91:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    8a96:	e9 dc 01 00 00       	jmp    8c77 <f12+0x7d7>
    8a9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8aa0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8aa4:	0f 84 4e fc ff ff    	je     86f8 <f12+0x258>
    8aaa:	e9 3b fc ff ff       	jmp    86ea <f12+0x24a>
    8aaf:	90                   	nop
    8ab0:	49 c1 e5 10          	shl    $0x10,%r13
    8ab4:	bf 08 00 00 00       	mov    $0x8,%edi
    8ab9:	49 09 f5             	or     %rsi,%r13
    8abc:	be 02 00 00 00       	mov    $0x2,%esi
    8ac1:	e8 ca d1 ff ff       	call   5c90 <fwp_heap_alloc>
    8ac6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8acd:	48 8b 15 e4 c0 01 00 	mov    0x1c0e4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8ad4:	48 89 c3             	mov    %rax,%rbx
    8ad7:	48 2b 05 b2 c0 01 00 	sub    0x1c0b2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8ade:	48 c1 e2 10          	shl    $0x10,%rdx
    8ae2:	48 39 d0             	cmp    %rdx,%rax
    8ae5:	0f 83 14 fe ff ff    	jae    88ff <f12+0x45f>
    8aeb:	48 89 c2             	mov    %rax,%rdx
    8aee:	48 c1 ea 10          	shr    $0x10,%rdx
    8af2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8af6:	48 8b 15 db c0 01 00 	mov    0x1c0db(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8afd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b01:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8b05:	4d 85 f6             	test   %r14,%r14
    8b08:	0f 84 e5 fd ff ff    	je     88f3 <f12+0x453>
    8b0e:	0f b6 0a             	movzbl (%rdx),%ecx
    8b11:	45 31 e4             	xor    %r12d,%r12d
    8b14:	80 f9 02             	cmp    $0x2,%cl
    8b17:	0f 85 39 fd ff ff    	jne    8856 <f12+0x3b6>
    8b1d:	66 85 c0             	test   %ax,%ax
    8b20:	0f 85 5c fd ff ff    	jne    8882 <f12+0x3e2>
    8b26:	e9 49 fd ff ff       	jmp    8874 <f12+0x3d4>
    8b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b30:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8b34:	4c 89 e1             	mov    %r12,%rcx
    8b37:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8b3b:	0f 85 08 0c 00 00    	jne    9749 <f12+0x12a9>
    8b41:	4d 85 e4             	test   %r12,%r12
    8b44:	0f 84 b5 fd ff ff    	je     88ff <f12+0x45f>
    8b4a:	48 c1 e0 04          	shl    $0x4,%rax
    8b4e:	4d 01 e4             	add    %r12,%r12
    8b51:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    8b55:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    8b5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b60:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    8b65:	49 8b 77 18          	mov    0x18(%r15),%rsi
    8b69:	49 83 c7 10          	add    $0x10,%r15
    8b6d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8b71:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8b76:	e8 f5 d7 ff ff       	call   6370 <w107>
    8b7b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8b80:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8b84:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8b89:	4d 39 fe             	cmp    %r15,%r14
    8b8c:	75 d2                	jne    8b60 <f12+0x6c0>
    8b8e:	4c 89 23             	mov    %r12,(%rbx)
    8b91:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    8b98:	45 31 f6             	xor    %r14d,%r14d
    8b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ba0:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    8ba5:	4c 89 c7             	mov    %r8,%rdi
    8ba8:	49 83 c6 02          	add    $0x2,%r14
    8bac:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8bb3:	00 f0 3f 
    8bb6:	48 89 ce             	mov    %rcx,%rsi
    8bb9:	e8 32 d4 ff ff       	call   5ff0 <fwp_p_ad_push>
    8bbe:	49 89 c0             	mov    %rax,%r8
    8bc1:	4d 39 e6             	cmp    %r12,%r14
    8bc4:	72 da                	jb     8ba0 <f12+0x700>
    8bc6:	e9 45 fd ff ff       	jmp    8910 <f12+0x470>
    8bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bd0:	4c 39 eb             	cmp    %r13,%rbx
    8bd3:	0f 84 47 fa ff ff    	je     8620 <f12+0x180>
    8bd9:	4c 8b 3d 30 a5 01 00 	mov    0x1a530(%rip),%r15        # 23110 <fwp_tapes>
    8be0:	e9 cf fa ff ff       	jmp    86b4 <f12+0x214>
    8be5:	0f 1f 00             	nopl   (%rax)
    8be8:	4d 8d 62 01          	lea    0x1(%r10),%r12
    8bec:	4d 39 e6             	cmp    %r12,%r14
    8bef:	0f 8d 9b 09 00 00    	jge    9590 <f12+0x10f0>
    8bf5:	4d 85 f6             	test   %r14,%r14
    8bf8:	4d 0f 44 f4          	cmove  %r12,%r14
    8bfc:	eb 17                	jmp    8c15 <f12+0x775>
    8bfe:	66 90                	xchg   %ax,%ax
    8c00:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8c04:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    8c0b:	4c 89 e0             	mov    %r12,%rax
    8c0e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8c12:	49 89 c6             	mov    %rax,%r14
    8c15:	4d 39 e6             	cmp    %r12,%r14
    8c18:	7c e6                	jl     8c00 <f12+0x760>
    8c1a:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
    8c1f:	4d 85 ff             	test   %r15,%r15
    8c22:	0f 84 08 0a 00 00    	je     9630 <f12+0x1190>
    8c28:	4c 89 ff             	mov    %r15,%rdi
    8c2b:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8c32:	00 
    8c33:	e8 98 a9 ff ff       	call   35d0 <realloc@plt>
    8c38:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    8c3d:	49 89 c7             	mov    %rax,%r15
    8c40:	4d 85 ff             	test   %r15,%r15
    8c43:	0f 84 53 08 00 00    	je     949c <f12+0xffc>
    8c49:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
    8c50:	00 
    8c51:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    8c58:	00 
    8c59:	4d 85 e4             	test   %r12,%r12
    8c5c:	0f 85 82 0a 00 00    	jne    96e4 <f12+0x1244>
    8c62:	49 89 de             	mov    %rbx,%r14
    8c65:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8c6c:	49 f7 de             	neg    %r14
    8c6f:	4d 85 c0             	test   %r8,%r8
    8c72:	78 17                	js     8c8b <f12+0x7eb>
    8c74:	45 89 c2             	mov    %r8d,%r10d
    8c77:	f2 0f 10 05 a1 6f 00 	movsd  0x6fa1(%rip),%xmm0        # fc20 <msg.4+0xb0>
    8c7e:	00 
    8c7f:	f2 43 0f 58 04 d7    	addsd  (%r15,%r10,8),%xmm0
    8c85:	f2 43 0f 11 04 d7    	movsd  %xmm0,(%r15,%r10,8)
    8c8b:	bf 03 00 00 00       	mov    $0x3,%edi
    8c90:	48 01 1d 89 a4 01 00 	add    %rbx,0x1a489(%rip)        # 23120 <descent_inputs>
    8c97:	4c 01 35 8a a4 01 00 	add    %r14,0x1a48a(%rip)        # 23128 <descent_nodes>
    8c9e:	e8 ad b5 ff ff       	call   4250 <descent_phase_step>
    8ca3:	49 39 dd             	cmp    %rbx,%r13
    8ca6:	0f 8c 86 00 00 00    	jl     8d32 <f12+0x892>
    8cac:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    8cb1:	4c 8b 14 24          	mov    (%rsp),%r10
    8cb5:	49 29 dd             	sub    %rbx,%r13
    8cb8:	4d 8d 04 df          	lea    (%r15,%rbx,8),%r8
    8cbc:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8cc1:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    8cc6:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8cca:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    8cce:	4d 29 d8             	sub    %r11,%r8
    8cd1:	4d 29 da             	sub    %r11,%r10
    8cd4:	4a 8d 04 af          	lea    (%rdi,%r13,4),%rax
    8cd8:	48 29 fe             	sub    %rdi,%rsi
    8cdb:	eb 07                	jmp    8ce4 <f12+0x844>
    8cdd:	0f 1f 00             	nopl   (%rax)
    8ce0:	48 83 e8 04          	sub    $0x4,%rax
    8ce4:	f2 41 0f 10 04 10    	movsd  (%r8,%rdx,1),%xmm0
    8cea:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8cee:	7a 02                	jp     8cf2 <f12+0x852>
    8cf0:	74 37                	je     8d29 <f12+0x889>
    8cf2:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8cf6:	45 85 db             	test   %r11d,%r11d
    8cf9:	78 16                	js     8d11 <f12+0x871>
    8cfb:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8d01:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8d05:	f2 43 0f 58 0c df    	addsd  (%r15,%r11,8),%xmm1
    8d0b:	f2 43 0f 11 0c df    	movsd  %xmm1,(%r15,%r11,8)
    8d11:	4c 63 18             	movslq (%rax),%r11
    8d14:	45 85 db             	test   %r11d,%r11d
    8d17:	78 10                	js     8d29 <f12+0x889>
    8d19:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8d1d:	f2 43 0f 58 04 df    	addsd  (%r15,%r11,8),%xmm0
    8d23:	f2 43 0f 11 04 df    	movsd  %xmm0,(%r15,%r11,8)
    8d29:	48 83 ea 08          	sub    $0x8,%rdx
    8d2d:	48 39 c7             	cmp    %rax,%rdi
    8d30:	75 ae                	jne    8ce0 <f12+0x840>
    8d32:	bf 04 00 00 00       	mov    $0x4,%edi
    8d37:	e8 14 b5 ff ff       	call   4250 <descent_phase_step>
    8d3c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8d43:	ff ff 1f 
    8d46:	48 39 d8             	cmp    %rbx,%rax
    8d49:	0f 82 12 0a 00 00    	jb     9761 <f12+0x12c1>
    8d4f:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    8d56:	00 
    8d57:	be 02 00 00 00       	mov    $0x2,%esi
    8d5c:	e8 2f cf ff ff       	call   5c90 <fwp_heap_alloc>
    8d61:	48 89 18             	mov    %rbx,(%rax)
    8d64:	49 89 c4             	mov    %rax,%r12
    8d67:	31 c0                	xor    %eax,%eax
    8d69:	48 85 db             	test   %rbx,%rbx
    8d6c:	74 24                	je     8d92 <f12+0x8f2>
    8d6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d7c:	00 00 00 00 
    8d80:	49 8b 14 c7          	mov    (%r15,%rax,8),%rdx
    8d84:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    8d89:	48 83 c0 01          	add    $0x1,%rax
    8d8d:	48 39 c3             	cmp    %rax,%rbx
    8d90:	75 ee                	jne    8d80 <f12+0x8e0>
    8d92:	bf 05 00 00 00       	mov    $0x5,%edi
    8d97:	e8 b4 b4 ff ff       	call   4250 <descent_phase_step>
    8d9c:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
    8da1:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8da6:	4c 89 2d cb c6 01 00 	mov    %r13,0x1c6cb(%rip)        # 25478 <fwp_cleanups>
    8dad:	e8 be c2 ff ff       	call   5070 <fwp_tape_buffers_release>
    8db2:	bf 06 00 00 00       	mov    $0x6,%edi
    8db7:	e8 94 b4 ff ff       	call   4250 <descent_phase_step>
    8dbc:	48 8b 15 f5 bd 01 00 	mov    0x1bdf5(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8dc3:	4c 89 e0             	mov    %r12,%rax
    8dc6:	48 2b 05 c3 bd 01 00 	sub    0x1bdc3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8dcd:	48 c1 e2 10          	shl    $0x10,%rdx
    8dd1:	48 39 d0             	cmp    %rdx,%rax
    8dd4:	73 55                	jae    8e2b <f12+0x98b>
    8dd6:	48 89 c2             	mov    %rax,%rdx
    8dd9:	48 c1 ea 10          	shr    $0x10,%rdx
    8ddd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8de1:	48 8b 15 f0 bd 01 00 	mov    0x1bdf0(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8de8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8dec:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8df0:	48 85 db             	test   %rbx,%rbx
    8df3:	74 36                	je     8e2b <f12+0x98b>
    8df5:	0f b6 0a             	movzbl (%rdx),%ecx
    8df8:	80 f9 02             	cmp    $0x2,%cl
    8dfb:	0f 84 f7 06 00 00    	je     94f8 <f12+0x1058>
    8e01:	80 f9 01             	cmp    $0x1,%cl
    8e04:	75 25                	jne    8e2b <f12+0x98b>
    8e06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e09:	0f b7 c0             	movzwl %ax,%eax
    8e0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e0f:	48 0f af c1          	imul   %rcx,%rax
    8e13:	48 c1 e8 20          	shr    $0x20,%rax
    8e17:	48 39 d0             	cmp    %rdx,%rax
    8e1a:	73 0f                	jae    8e2b <f12+0x98b>
    8e1c:	48 01 c3             	add    %rax,%rbx
    8e1f:	80 3b ff             	cmpb   $0xff,(%rbx)
    8e22:	0f 84 98 08 00 00    	je     96c0 <f12+0x1220>
    8e28:	c6 03 01             	movb   $0x1,(%rbx)
    8e2b:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    8e30:	0f 85 15 a9 ff ff    	jne    374b <f12.cold>
    8e36:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    8e3b:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    8e40:	48 89 05 31 c6 01 00 	mov    %rax,0x1c631(%rip)        # 25478 <fwp_cleanups>
    8e47:	e8 14 e2 ff ff       	call   7060 <fwp_tape_scope_release>
    8e4c:	49 8b 04 24          	mov    (%r12),%rax
    8e50:	49 89 c6             	mov    %rax,%r14
    8e53:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8e58:	48 85 c0             	test   %rax,%rax
    8e5b:	0f 88 1f 05 00 00    	js     9380 <f12+0xee0>
    8e61:	48 8b 15 50 bd 01 00 	mov    0x1bd50(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8e68:	4c 89 e0             	mov    %r12,%rax
    8e6b:	48 2b 05 1e bd 01 00 	sub    0x1bd1e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8e72:	48 c1 e2 10          	shl    $0x10,%rdx
    8e76:	48 39 d0             	cmp    %rdx,%rax
    8e79:	0f 83 01 05 00 00    	jae    9380 <f12+0xee0>
    8e7f:	48 89 c2             	mov    %rax,%rdx
    8e82:	48 c1 ea 10          	shr    $0x10,%rdx
    8e86:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e8a:	48 8b 15 47 bd 01 00 	mov    0x1bd47(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8e91:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e95:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8e99:	48 85 c9             	test   %rcx,%rcx
    8e9c:	0f 84 de 04 00 00    	je     9380 <f12+0xee0>
    8ea2:	0f b6 32             	movzbl (%rdx),%esi
    8ea5:	40 80 fe 02          	cmp    $0x2,%sil
    8ea9:	0f 84 c1 04 00 00    	je     9370 <f12+0xed0>
    8eaf:	40 80 fe 01          	cmp    $0x1,%sil
    8eb3:	0f 85 c7 04 00 00    	jne    9380 <f12+0xee0>
    8eb9:	8b 72 18             	mov    0x18(%rdx),%esi
    8ebc:	0f b7 c0             	movzwl %ax,%eax
    8ebf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ec2:	48 0f af c6          	imul   %rsi,%rax
    8ec6:	48 c1 e8 20          	shr    $0x20,%rax
    8eca:	48 39 d0             	cmp    %rdx,%rax
    8ecd:	0f 83 ad 04 00 00    	jae    9380 <f12+0xee0>
    8ed3:	48 01 c1             	add    %rax,%rcx
    8ed6:	80 39 01             	cmpb   $0x1,(%rcx)
    8ed9:	0f 85 a1 04 00 00    	jne    9380 <f12+0xee0>
    8edf:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    8ee4:	4d 89 e5             	mov    %r12,%r13
    8ee7:	31 ff                	xor    %edi,%edi
    8ee9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8eee:	f2 0f 10 0d 3a 6d 00 	movsd  0x6d3a(%rip),%xmm1        # fc30 <msg.4+0xc0>
    8ef5:	00 
    8ef6:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8efa:	31 c0                	xor    %eax,%eax
    8efc:	4d 85 f6             	test   %r14,%r14
    8eff:	75 2d                	jne    8f2e <f12+0xa8e>
    8f01:	eb 45                	jmp    8f48 <f12+0xaa8>
    8f03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f08:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8f0d:	0f 88 22 08 00 00    	js     9735 <f12+0x1295>
    8f13:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8f18:	48 83 c0 01          	add    $0x1,%rax
    8f1c:	48 83 c2 08          	add    $0x8,%rdx
    8f20:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8f24:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8f29:	49 39 c6             	cmp    %rax,%r14
    8f2c:	74 1a                	je     8f48 <f12+0xaa8>
    8f2e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8f33:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8f38:	79 ce                	jns    8f08 <f12+0xa68>
    8f3a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8f3f:	eb c7                	jmp    8f08 <f12+0xa68>
    8f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f48:	e8 f3 e6 ff ff       	call   7640 <fwp_drop4>
    8f4d:	48 89 e8             	mov    %rbp,%rax
    8f50:	31 d2                	xor    %edx,%edx
    8f52:	48 85 ed             	test   %rbp,%rbp
    8f55:	0f 84 ff 06 00 00    	je     965a <f12+0x11ba>
    8f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8f64:	48 83 c2 01          	add    $0x1,%rdx
    8f68:	48 85 c0             	test   %rax,%rax
    8f6b:	75 f3                	jne    8f60 <f12+0xac0>
    8f6d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8f71:	49 89 c7             	mov    %rax,%r15
    8f74:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8f79:	48 85 c0             	test   %rax,%rax
    8f7c:	0f 88 50 03 00 00    	js     92d2 <f12+0xe32>
    8f82:	48 8b 05 2f bc 01 00 	mov    0x1bc2f(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    8f89:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    8f8e:	48 2b 0d fb bb 01 00 	sub    0x1bbfb(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    8f95:	48 c1 e0 10          	shl    $0x10,%rax
    8f99:	48 39 c1             	cmp    %rax,%rcx
    8f9c:	0f 83 30 03 00 00    	jae    92d2 <f12+0xe32>
    8fa2:	48 89 c8             	mov    %rcx,%rax
    8fa5:	48 c1 e8 10          	shr    $0x10,%rax
    8fa9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8fad:	48 8b 05 24 bc 01 00 	mov    0x1bc24(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    8fb4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8fb8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8fbc:	48 85 ff             	test   %rdi,%rdi
    8fbf:	0f 84 0d 03 00 00    	je     92d2 <f12+0xe32>
    8fc5:	0f b6 06             	movzbl (%rsi),%eax
    8fc8:	3c 02                	cmp    $0x2,%al
    8fca:	0f 84 f0 02 00 00    	je     92c0 <f12+0xe20>
    8fd0:	3c 01                	cmp    $0x1,%al
    8fd2:	0f 85 f1 02 00 00    	jne    92c9 <f12+0xe29>
    8fd8:	8b 46 18             	mov    0x18(%rsi),%eax
    8fdb:	0f b7 c9             	movzwl %cx,%ecx
    8fde:	48 0f af c8          	imul   %rax,%rcx
    8fe2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8fe5:	48 c1 e9 20          	shr    $0x20,%rcx
    8fe9:	48 39 c1             	cmp    %rax,%rcx
    8fec:	0f 83 d7 02 00 00    	jae    92c9 <f12+0xe29>
    8ff2:	48 01 cf             	add    %rcx,%rdi
    8ff5:	80 3f 01             	cmpb   $0x1,(%rdi)
    8ff8:	0f 85 cb 02 00 00    	jne    92c9 <f12+0xe29>
    8ffe:	49 39 d7             	cmp    %rdx,%r15
    9001:	48 89 d0             	mov    %rdx,%rax
    9004:	49 0f 46 c7          	cmovbe %r15,%rax
    9008:	48 85 c0             	test   %rax,%rax
    900b:	0f 84 30 07 00 00    	je     9741 <f12+0x12a1>
    9011:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    9018:	00 
    9019:	4d 8d 75 08          	lea    0x8(%r13),%r14
    901d:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9022:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9029:	00 
    902a:	48 89 e9             	mov    %rbp,%rcx
    902d:	31 d2                	xor    %edx,%edx
    902f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9033:	eb 28                	jmp    905d <f12+0xbbd>
    9035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    903c:	00 00 00 00 
    9040:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9045:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    904a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9050:	48 83 c2 08          	add    $0x8,%rdx
    9054:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9058:	49 39 d0             	cmp    %rdx,%r8
    905b:	74 1b                	je     9078 <f12+0xbd8>
    905d:	48 89 fe             	mov    %rdi,%rsi
    9060:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    9065:	79 d9                	jns    9040 <f12+0xba0>
    9067:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    906c:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    9070:	eb ce                	jmp    9040 <f12+0xba0>
    9072:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9078:	48 85 ed             	test   %rbp,%rbp
    907b:	0f 84 8f 06 00 00    	je     9710 <f12+0x1270>
    9081:	4c 8b 05 30 bb 01 00 	mov    0x1bb30(%rip),%r8        # 24bb8 <fwp_heap+0x13d8>
    9088:	4c 8b 0d 01 bb 01 00 	mov    0x1bb01(%rip),%r9        # 24b90 <fwp_heap+0x13b0>
    908f:	48 89 e9             	mov    %rbp,%rcx
    9092:	45 31 ed             	xor    %r13d,%r13d
    9095:	4c 8b 15 3c bb 01 00 	mov    0x1bb3c(%rip),%r10        # 24bd8 <fwp_heap+0x13f8>
    909c:	49 c1 e0 10          	shl    $0x10,%r8
    90a0:	eb 1c                	jmp    90be <f12+0xc1e>
    90a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90a8:	49 83 c5 01          	add    $0x1,%r13
    90ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    90b0:	49 39 c5             	cmp    %rax,%r13
    90b3:	0f 83 67 01 00 00    	jae    9220 <f12+0xd80>
    90b9:	48 85 c9             	test   %rcx,%rcx
    90bc:	74 56                	je     9114 <f12+0xc74>
    90be:	48 89 ca             	mov    %rcx,%rdx
    90c1:	4c 29 ca             	sub    %r9,%rdx
    90c4:	4c 39 c2             	cmp    %r8,%rdx
    90c7:	73 4b                	jae    9114 <f12+0xc74>
    90c9:	48 89 d6             	mov    %rdx,%rsi
    90cc:	48 c1 ee 10          	shr    $0x10,%rsi
    90d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    90d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    90d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    90dc:	48 85 ff             	test   %rdi,%rdi
    90df:	74 33                	je     9114 <f12+0xc74>
    90e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    90e5:	41 80 fb 02          	cmp    $0x2,%r11b
    90e9:	0f 84 19 01 00 00    	je     9208 <f12+0xd68>
    90ef:	41 80 fb 01          	cmp    $0x1,%r11b
    90f3:	75 1f                	jne    9114 <f12+0xc74>
    90f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    90f9:	0f b7 d2             	movzwl %dx,%edx
    90fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    90ff:	49 0f af d3          	imul   %r11,%rdx
    9103:	48 c1 ea 20          	shr    $0x20,%rdx
    9107:	48 39 f2             	cmp    %rsi,%rdx
    910a:	73 08                	jae    9114 <f12+0xc74>
    910c:	48 01 d7             	add    %rdx,%rdi
    910f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9112:	74 94                	je     90a8 <f12+0xc08>
    9114:	49 39 c5             	cmp    %rax,%r13
    9117:	0f 83 03 01 00 00    	jae    9220 <f12+0xd80>
    911d:	49 89 c7             	mov    %rax,%r15
    9120:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    9127:	00 
    9128:	45 31 e4             	xor    %r12d,%r12d
    912b:	48 89 04 24          	mov    %rax,(%rsp)
    912f:	48 8d 1d aa a6 01 00 	lea    0x1a6aa(%rip),%rbx        # 237e0 <fwp_heap>
    9136:	eb 3a                	jmp    9172 <f12+0xcd2>
    9138:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    913f:	00 
    9140:	41 80 f9 01          	cmp    $0x1,%r9b
    9144:	75 27                	jne    916d <f12+0xccd>
    9146:	45 8b 48 18          	mov    0x18(%r8),%r9d
    914a:	0f b7 c0             	movzwl %ax,%eax
    914d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9151:	49 0f af c1          	imul   %r9,%rax
    9155:	48 c1 e8 20          	shr    $0x20,%rax
    9159:	4c 39 c0             	cmp    %r8,%rax
    915c:	73 0f                	jae    916d <f12+0xccd>
    915e:	48 01 c7             	add    %rax,%rdi
    9161:	80 3f ff             	cmpb   $0xff,(%rdi)
    9164:	0f 84 c6 02 00 00    	je     9430 <f12+0xf90>
    916a:	c6 07 01             	movb   $0x1,(%rdi)
    916d:	4d 39 fd             	cmp    %r15,%r13
    9170:	73 7e                	jae    91f0 <f12+0xd50>
    9172:	49 83 ef 01          	sub    $0x1,%r15
    9176:	66 49 0f 6e ec       	movq   %r12,%xmm5
    917b:	48 8b 34 24          	mov    (%rsp),%rsi
    917f:	bf 01 00 00 00       	mov    $0x1,%edi
    9184:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    918a:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    918e:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9195:	00 
    9196:	e8 45 d3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    919b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    91a2:	49 89 c4             	mov    %rax,%r12
    91a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    91ac:	48 c1 e7 10          	shl    $0x10,%rdi
    91b0:	48 39 f8             	cmp    %rdi,%rax
    91b3:	73 b8                	jae    916d <f12+0xccd>
    91b5:	48 89 c7             	mov    %rax,%rdi
    91b8:	48 c1 ef 10          	shr    $0x10,%rdi
    91bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    91c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    91c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    91cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    91cf:	48 85 ff             	test   %rdi,%rdi
    91d2:	74 99                	je     916d <f12+0xccd>
    91d4:	45 0f b6 08          	movzbl (%r8),%r9d
    91d8:	41 80 f9 02          	cmp    $0x2,%r9b
    91dc:	0f 85 5e ff ff ff    	jne    9140 <f12+0xca0>
    91e2:	66 85 c0             	test   %ax,%ax
    91e5:	0f 84 76 ff ff ff    	je     9161 <f12+0xcc1>
    91eb:	4d 39 fd             	cmp    %r15,%r13
    91ee:	72 82                	jb     9172 <f12+0xcd2>
    91f0:	4d 85 ed             	test   %r13,%r13
    91f3:	75 2e                	jne    9223 <f12+0xd83>
    91f5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    91f9:	85 c0                	test   %eax,%eax
    91fb:	4d 0f 45 f5          	cmovne %r13,%r14
    91ff:	eb 6f                	jmp    9270 <f12+0xdd0>
    9201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9208:	66 85 d2             	test   %dx,%dx
    920b:	0f 84 fe fe ff ff    	je     910f <f12+0xc6f>
    9211:	49 39 c5             	cmp    %rax,%r13
    9214:	0f 82 03 ff ff ff    	jb     911d <f12+0xc7d>
    921a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9220:	45 31 e4             	xor    %r12d,%r12d
    9223:	4c 89 f2             	mov    %r14,%rdx
    9226:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    922a:	48 89 e8             	mov    %rbp,%rax
    922d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9234:	00 
    9235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    923c:	00 00 00 00 
    9240:	48 8b 0a             	mov    (%rdx),%rcx
    9243:	48 83 c2 08          	add    $0x8,%rdx
    9247:	48 89 c7             	mov    %rax,%rdi
    924a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    924e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9252:	4c 39 c2             	cmp    %r8,%rdx
    9255:	75 e9                	jne    9240 <f12+0xda0>
    9257:	8b 54 24 20          	mov    0x20(%rsp),%edx
    925b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    925f:	85 d2                	test   %edx,%edx
    9261:	0f 84 a9 02 00 00    	je     9510 <f12+0x1070>
    9267:	49 89 ec             	mov    %rbp,%r12
    926a:	45 31 f6             	xor    %r14d,%r14d
    926d:	48 89 c5             	mov    %rax,%rbp
    9270:	4c 89 f7             	mov    %r14,%rdi
    9273:	e8 18 c5 ff ff       	call   5790 <fwp_mem_free>
    9278:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    927d:	e8 be e3 ff ff       	call   7640 <fwp_drop4>
    9282:	48 89 ef             	mov    %rbp,%rdi
    9285:	e8 c6 d7 ff ff       	call   6a50 <fwp_drop0>
    928a:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    9291:	00 
    9292:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9299:	00 00 
    929b:	0f 85 e4 04 00 00    	jne    9785 <f12+0x12e5>
    92a1:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    92a8:	4c 89 e0             	mov    %r12,%rax
    92ab:	5b                   	pop    %rbx
    92ac:	5d                   	pop    %rbp
    92ad:	41 5c                	pop    %r12
    92af:	41 5d                	pop    %r13
    92b1:	41 5e                	pop    %r14
    92b3:	41 5f                	pop    %r15
    92b5:	c3                   	ret
    92b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92bd:	00 00 00 
    92c0:	66 85 c9             	test   %cx,%cx
    92c3:	0f 84 2c fd ff ff    	je     8ff5 <f12+0xb55>
    92c9:	48 85 ed             	test   %rbp,%rbp
    92cc:	0f 84 18 03 00 00    	je     95ea <f12+0x114a>
    92d2:	48 89 e8             	mov    %rbp,%rax
    92d5:	45 31 e4             	xor    %r12d,%r12d
    92d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92df:	00 
    92e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    92e4:	4c 89 e2             	mov    %r12,%rdx
    92e7:	49 83 c4 01          	add    $0x1,%r12
    92eb:	48 85 c0             	test   %rax,%rax
    92ee:	75 f0                	jne    92e0 <f12+0xe40>
    92f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    92f7:	ff ff 1f 
    92fa:	4c 39 e0             	cmp    %r12,%rax
    92fd:	0f 82 46 04 00 00    	jb     9749 <f12+0x12a9>
    9303:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    930a:	00 
    930b:	be 02 00 00 00       	mov    $0x2,%esi
    9310:	e8 7b c9 ff ff       	call   5c90 <fwp_heap_alloc>
    9315:	4d 39 e7             	cmp    %r12,%r15
    9318:	48 89 ea             	mov    %rbp,%rdx
    931b:	49 89 c6             	mov    %rax,%r14
    931e:	4c 89 e0             	mov    %r12,%rax
    9321:	49 0f 46 c7          	cmovbe %r15,%rax
    9325:	4c 89 f1             	mov    %r14,%rcx
    9328:	66 90                	xchg   %ax,%ax
    932a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9331:	00 00 00 00 
    9335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    933c:	00 00 00 00 
    9340:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9344:	48 83 c1 08          	add    $0x8,%rcx
    9348:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    934c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9350:	48 85 d2             	test   %rdx,%rdx
    9353:	75 eb                	jne    9340 <f12+0xea0>
    9355:	48 85 c0             	test   %rax,%rax
    9358:	0f 84 9e 02 00 00    	je     95fc <f12+0x115c>
    935e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    9365:	00 
    9366:	e9 b2 fc ff ff       	jmp    901d <f12+0xb7d>
    936b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9370:	66 85 c0             	test   %ax,%ax
    9373:	0f 84 5d fb ff ff    	je     8ed6 <f12+0xa36>
    9379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9380:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9387:	ff ff 1f 
    938a:	4c 39 f0             	cmp    %r14,%rax
    938d:	0f 82 ce 03 00 00    	jb     9761 <f12+0x12c1>
    9393:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    939a:	00 
    939b:	be 01 00 00 00       	mov    $0x1,%esi
    93a0:	e8 eb c8 ff ff       	call   5c90 <fwp_heap_alloc>
    93a5:	4c 89 30             	mov    %r14,(%rax)
    93a8:	48 8b 15 09 b8 01 00 	mov    0x1b809(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    93af:	49 89 c5             	mov    %rax,%r13
    93b2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    93b7:	48 2b 05 d2 b7 01 00 	sub    0x1b7d2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    93be:	48 c1 e2 10          	shl    $0x10,%rdx
    93c2:	48 39 d0             	cmp    %rdx,%rax
    93c5:	73 57                	jae    941e <f12+0xf7e>
    93c7:	48 89 c2             	mov    %rax,%rdx
    93ca:	48 c1 ea 10          	shr    $0x10,%rdx
    93ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93d2:	48 8b 15 ff b7 01 00 	mov    0x1b7ff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    93d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93dd:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    93e1:	4d 85 ff             	test   %r15,%r15
    93e4:	74 38                	je     941e <f12+0xf7e>
    93e6:	0f b6 0a             	movzbl (%rdx),%ecx
    93e9:	80 f9 02             	cmp    $0x2,%cl
    93ec:	0f 84 16 02 00 00    	je     9608 <f12+0x1168>
    93f2:	80 f9 01             	cmp    $0x1,%cl
    93f5:	75 27                	jne    941e <f12+0xf7e>
    93f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93fa:	0f b7 c0             	movzwl %ax,%eax
    93fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9400:	48 0f af c1          	imul   %rcx,%rax
    9404:	48 c1 e8 20          	shr    $0x20,%rax
    9408:	48 39 d0             	cmp    %rdx,%rax
    940b:	73 11                	jae    941e <f12+0xf7e>
    940d:	49 01 c7             	add    %rax,%r15
    9410:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9414:	0f 84 b3 02 00 00    	je     96cd <f12+0x122d>
    941a:	41 c6 07 01          	movb   $0x1,(%r15)
    941e:	4c 89 e7             	mov    %r12,%rdi
    9421:	e9 c3 fa ff ff       	jmp    8ee9 <f12+0xa49>
    9426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    942d:	00 00 00 
    9430:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    9435:	e8 16 c1 ff ff       	call   5550 <fwp_rc_forget_slot>
    943a:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    943f:	e9 26 fd ff ff       	jmp    916a <f12+0xcca>
    9444:	0f 1f 40 00          	nopl   0x0(%rax)
    9448:	48 8d 3d 31 db ff ff 	lea    -0x24cf(%rip),%rdi        # 6f80 <fwp_tape_finish>
    944f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9454:	e8 77 56 00 00       	call   ead0 <atexit>
    9459:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    945e:	85 c0                	test   %eax,%eax
    9460:	75 62                	jne    94c4 <f12+0x1024>
    9462:	c7 05 14 9c 00 00 01 	movl   $0x1,0x9c14(%rip)        # 13080 <registered_finish.0>
    9469:	00 00 00 
    946c:	e9 63 f1 ff ff       	jmp    85d4 <f12+0x134>
    9471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9478:	66 85 c0             	test   %ax,%ax
    947b:	0f 85 ff f0 ff ff    	jne    8580 <f12+0xe0>
    9481:	e9 e6 f0 ff ff       	jmp    856c <f12+0xcc>
    9486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    948d:	00 00 00 
    9490:	49 89 dc             	mov    %rbx,%r12
    9493:	4c 39 f3             	cmp    %r14,%rbx
    9496:	0f 8f 59 f7 ff ff    	jg     8bf5 <f12+0x755>
    949c:	4d 85 e4             	test   %r12,%r12
    949f:	0f 84 bd f7 ff ff    	je     8c62 <f12+0x7c2>
    94a5:	4d 85 ff             	test   %r15,%r15
    94a8:	0f 85 ab f7 ff ff    	jne    8c59 <f12+0x7b9>
    94ae:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    94b3:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    94b8:	48 89 05 b9 bf 01 00 	mov    %rax,0x1bfb9(%rip)        # 25478 <fwp_cleanups>
    94bf:	e8 ac bb ff ff       	call   5070 <fwp_tape_buffers_release>
    94c4:	48 8b 0d 95 9b 00 00 	mov    0x9b95(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    94cb:	ba 13 00 00 00       	mov    $0x13,%edx
    94d0:	be 01 00 00 00       	mov    $0x1,%esi
    94d5:	48 8d 3d 2c 5b 00 00 	lea    0x5b2c(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    94dc:	e8 9f a1 ff ff       	call   3680 <fwrite@plt>
    94e1:	31 ff                	xor    %edi,%edi
    94e3:	e8 d8 a0 ff ff       	call   35c0 <fflush@plt>
    94e8:	bf 66 00 00 00       	mov    $0x66,%edi
    94ed:	e8 ae a1 ff ff       	call   36a0 <_Exit@plt>
    94f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94f8:	66 85 c0             	test   %ax,%ax
    94fb:	0f 85 2a f9 ff ff    	jne    8e2b <f12+0x98b>
    9501:	e9 19 f9 ff ff       	jmp    8e1f <f12+0x97f>
    9506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    950d:	00 00 00 
    9510:	49 89 ec             	mov    %rbp,%r12
    9513:	48 89 c5             	mov    %rax,%rbp
    9516:	e9 55 fd ff ff       	jmp    9270 <f12+0xdd0>
    951b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9520:	66 0f 6f 0d 98 9b 01 	movdqa 0x19b98(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9527:	00 
    9528:	48 c7 05 75 9b 01 00 	movq   $0x0,0x19b75(%rip)        # 230a8 <fwp_tape_cached_bytes>
    952f:	00 00 00 00 
    9533:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    9538:	48 8b 05 a1 9b 01 00 	mov    0x19ba1(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    953f:	66 0f 6f 0d 89 9b 01 	movdqa 0x19b89(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9546:	00 
    9547:	49 89 46 40          	mov    %rax,0x40(%r14)
    954b:	48 8b 05 96 9b 01 00 	mov    0x19b96(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9552:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9557:	66 0f ef c9          	pxor   %xmm1,%xmm1
    955b:	49 89 46 18          	mov    %rax,0x18(%r14)
    955f:	48 8b 05 8a 9b 01 00 	mov    0x19b8a(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    9566:	0f 29 0d 53 9b 01 00 	movaps %xmm1,0x19b53(%rip)        # 230c0 <fwp_tape_workspace>
    956d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9571:	0f 29 0d 58 9b 01 00 	movaps %xmm1,0x19b58(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    9578:	48 c7 05 6d 9b 01 00 	movq   $0x0,0x19b6d(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    957f:	00 00 00 00 
    9583:	0f 29 0d 56 9b 01 00 	movaps %xmm1,0x19b56(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    958a:	e9 69 f1 ff ff       	jmp    86f8 <f12+0x258>
    958f:	90                   	nop
    9590:	4d 85 ff             	test   %r15,%r15
    9593:	0f 84 15 ff ff ff    	je     94ae <f12+0x100e>
    9599:	4d 89 e6             	mov    %r12,%r14
    959c:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    95a3:	00 
    95a4:	31 f6                	xor    %esi,%esi
    95a6:	4c 89 ff             	mov    %r15,%rdi
    95a9:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    95ae:	49 29 de             	sub    %rbx,%r14
    95b1:	e8 0a 9f ff ff       	call   34c0 <memset@plt>
    95b6:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    95bb:	e9 b7 f6 ff ff       	jmp    8c77 <f12+0x7d7>
    95c0:	49 89 dc             	mov    %rbx,%r12
    95c3:	e9 2d f6 ff ff       	jmp    8bf5 <f12+0x755>
    95c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95cf:	00 
    95d0:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    95d5:	b8 ff ff 00 00       	mov    $0xffff,%eax
    95da:	49 39 c6             	cmp    %rax,%r14
    95dd:	4c 0f 4f f0          	cmovg  %rax,%r14
    95e1:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    95e5:	e9 67 f0 ff ff       	jmp    8651 <f12+0x1b1>
    95ea:	be 02 00 00 00       	mov    $0x2,%esi
    95ef:	bf 08 00 00 00       	mov    $0x8,%edi
    95f4:	e8 97 c6 ff ff       	call   5c90 <fwp_heap_alloc>
    95f9:	49 89 c6             	mov    %rax,%r14
    95fc:	45 31 e4             	xor    %r12d,%r12d
    95ff:	e9 6c fc ff ff       	jmp    9270 <f12+0xdd0>
    9604:	0f 1f 40 00          	nopl   0x0(%rax)
    9608:	66 85 c0             	test   %ax,%ax
    960b:	0f 85 0d fe ff ff    	jne    941e <f12+0xf7e>
    9611:	e9 fa fd ff ff       	jmp    9410 <f12+0xf70>
    9616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    961d:	00 00 00 
    9620:	4d 85 e4             	test   %r12,%r12
    9623:	0f 85 5e f2 ff ff    	jne    8887 <f12+0x3e7>
    9629:	e9 d1 f2 ff ff       	jmp    88ff <f12+0x45f>
    962e:	66 90                	xchg   %ax,%ax
    9630:	be 08 00 00 00       	mov    $0x8,%esi
    9635:	4c 89 f7             	mov    %r14,%rdi
    9638:	e8 e3 9e ff ff       	call   3520 <calloc@plt>
    963d:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    9642:	49 89 c7             	mov    %rax,%r15
    9645:	e9 f6 f5 ff ff       	jmp    8c40 <f12+0x7a0>
    964a:	31 ff                	xor    %edi,%edi
    964c:	e8 ff ab ff ff       	call   4250 <descent_phase_step>
    9651:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9655:	e9 6c ef ff ff       	jmp    85c6 <f12+0x126>
    965a:	49 8b 45 00          	mov    0x0(%r13),%rax
    965e:	48 85 c0             	test   %rax,%rax
    9661:	78 87                	js     95ea <f12+0x114a>
    9663:	48 8b 35 4e b5 01 00 	mov    0x1b54e(%rip),%rsi        # 24bb8 <fwp_heap+0x13d8>
    966a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    966f:	48 2b 0d 1a b5 01 00 	sub    0x1b51a(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    9676:	48 c1 e6 10          	shl    $0x10,%rsi
    967a:	48 39 f1             	cmp    %rsi,%rcx
    967d:	0f 83 67 ff ff ff    	jae    95ea <f12+0x114a>
    9683:	48 89 ce             	mov    %rcx,%rsi
    9686:	48 c1 ee 10          	shr    $0x10,%rsi
    968a:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    968e:	48 8b 35 43 b5 01 00 	mov    0x1b543(%rip),%rsi        # 24bd8 <fwp_heap+0x13f8>
    9695:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9699:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    969d:	48 85 ff             	test   %rdi,%rdi
    96a0:	0f 84 44 ff ff ff    	je     95ea <f12+0x114a>
    96a6:	48 0f ba f0 3f       	btr    $0x3f,%rax
    96ab:	49 89 c7             	mov    %rax,%r15
    96ae:	e9 12 f9 ff ff       	jmp    8fc5 <f12+0xb25>
    96b3:	4c 89 f7             	mov    %r14,%rdi
    96b6:	e8 95 be ff ff       	call   5550 <fwp_rc_forget_slot>
    96bb:	e9 be f1 ff ff       	jmp    887e <f12+0x3de>
    96c0:	48 89 df             	mov    %rbx,%rdi
    96c3:	e8 88 be ff ff       	call   5550 <fwp_rc_forget_slot>
    96c8:	e9 5b f7 ff ff       	jmp    8e28 <f12+0x988>
    96cd:	4c 89 ff             	mov    %r15,%rdi
    96d0:	e8 7b be ff ff       	call   5550 <fwp_rc_forget_slot>
    96d5:	e9 40 fd ff ff       	jmp    941a <f12+0xf7a>
    96da:	e8 51 bd ff ff       	call   5430 <fwp_rc_wide_dup>
    96df:	e9 9c ee ff ff       	jmp    8580 <f12+0xe0>
    96e4:	4d 89 e6             	mov    %r12,%r14
    96e7:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    96ee:	00 
    96ef:	31 f6                	xor    %esi,%esi
    96f1:	4c 89 ff             	mov    %r15,%rdi
    96f4:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
    96f9:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    96fe:	49 29 de             	sub    %rbx,%r14
    9701:	e8 ba 9d ff ff       	call   34c0 <memset@plt>
    9706:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    970b:	e9 5f f5 ff ff       	jmp    8c6f <f12+0x7cf>
    9710:	45 31 ed             	xor    %r13d,%r13d
    9713:	e9 05 fa ff ff       	jmp    911d <f12+0xc7d>
    9718:	48 8d 3d 48 5a 00 00 	lea    0x5a48(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    971f:	e8 cc ac ff ff       	call   43f0 <fwp_trap>
    9724:	48 8d 3d 85 61 00 00 	lea    0x6185(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    972b:	e8 c0 ac ff ff       	call   43f0 <fwp_trap>
    9730:	e8 cb 9f ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9735:	48 8d 3d 7c 62 00 00 	lea    0x627c(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    973c:	e8 af ac ff ff       	call   43f0 <fwp_trap>
    9741:	45 31 f6             	xor    %r14d,%r14d
    9744:	e9 b3 fe ff ff       	jmp    95fc <f12+0x115c>
    9749:	48 8d 3d 40 5a 00 00 	lea    0x5a40(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    9750:	e8 9b ac ff ff       	call   43f0 <fwp_trap>
    9755:	48 8d 3d 42 5a 00 00 	lea    0x5a42(%rip),%rdi        # f19e <_IO_stdin_used+0x19e>
    975c:	e8 8f ac ff ff       	call   43f0 <fwp_trap>
    9761:	48 8d 3d 50 5a 00 00 	lea    0x5a50(%rip),%rdi        # f1b8 <_IO_stdin_used+0x1b8>
    9768:	e8 83 ac ff ff       	call   43f0 <fwp_trap>
    976d:	48 8d 3d 14 62 00 00 	lea    0x6214(%rip),%rdi        # f988 <_IO_stdin_used+0x988>
    9774:	e8 77 ac ff ff       	call   43f0 <fwp_trap>
    9779:	48 8d 3d d8 61 00 00 	lea    0x61d8(%rip),%rdi        # f958 <_IO_stdin_used+0x958>
    9780:	e8 6b ac ff ff       	call   43f0 <fwp_trap>
    9785:	e8 d6 9c ff ff       	call   3460 <__stack_chk_fail@plt>
    978a:	48 8d 3d 67 61 00 00 	lea    0x6167(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    9791:	e8 5a ac ff ff       	call   43f0 <fwp_trap>
    9796:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    979d:	00 00 00 

00000000000097a0 <fwp_owned_entry12>:
    97a0:	f3 0f 1e fa          	endbr64
    97a4:	48 8b 3f             	mov    (%rdi),%rdi
    97a7:	e9 f4 ec ff ff       	jmp    84a0 <f12>
    97ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000097b0 <e12>:
    97b0:	f3 0f 1e fa          	endbr64
    97b4:	53                   	push   %rbx
    97b5:	48 8b 1f             	mov    (%rdi),%rbx
    97b8:	48 89 df             	mov    %rbx,%rdi
    97bb:	e8 50 ce ff ff       	call   6610 <fwp_rc_share>
    97c0:	48 89 df             	mov    %rbx,%rdi
    97c3:	e8 d8 ec ff ff       	call   84a0 <f12>
    97c8:	48 89 c3             	mov    %rax,%rbx
    97cb:	48 89 c7             	mov    %rax,%rdi
    97ce:	e8 3d ce ff ff       	call   6610 <fwp_rc_share>
    97d3:	48 89 d8             	mov    %rbx,%rax
    97d6:	5b                   	pop    %rbx
    97d7:	c3                   	ret
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 

00000000000097e0 <fwp_write>:
    97e0:	41 57                	push   %r15
    97e2:	41 56                	push   %r14
    97e4:	41 55                	push   %r13
    97e6:	41 54                	push   %r12
    97e8:	55                   	push   %rbp
    97e9:	53                   	push   %rbx
    97ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    97f1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    97f8:	00 00 
    97fa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9801:	00 
    9802:	49 89 d4             	mov    %rdx,%r12
    9805:	8b 12                	mov    (%rdx),%edx
    9807:	83 fa 19             	cmp    $0x19,%edx
    980a:	77 6a                	ja     9876 <fwp_write+0x96>
    980c:	48 89 f5             	mov    %rsi,%rbp
    980f:	89 d0                	mov    %edx,%eax
    9811:	89 ce                	mov    %ecx,%esi
    9813:	48 89 fb             	mov    %rdi,%rbx
    9816:	48 8d 0d e3 62 00 00 	lea    0x62e3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    981d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9821:	48 01 c8             	add    %rcx,%rax
    9824:	3e ff e0             	notrack jmp *%rax
    9827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    982e:	00 00 
    9830:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9834:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9838:	48 89 ca             	mov    %rcx,%rdx
    983b:	48 85 c9             	test   %rcx,%rcx
    983e:	0f 88 9c 0c 00 00    	js     a4e0 <fwp_write+0xd00>
    9844:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    984b:	00 
    984c:	48 89 c6             	mov    %rax,%rsi
    984f:	4c 89 e7             	mov    %r12,%rdi
    9852:	e8 e9 a1 ff ff       	call   3a40 <fwp_fmt_u128>
    9857:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    985e:	00 00 
    9860:	4c 89 e7             	mov    %r12,%rdi
    9863:	e8 e8 9b ff ff       	call   3450 <strlen@plt>
    9868:	4c 89 e6             	mov    %r12,%rsi
    986b:	48 89 df             	mov    %rbx,%rdi
    986e:	48 89 c2             	mov    %rax,%rdx
    9871:	e8 9a a9 ff ff       	call   4210 <buf_put>
    9876:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    987d:	00 
    987e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9885:	00 00 
    9887:	0f 85 28 04 00 00    	jne    9cb5 <fwp_write+0x4d5>
    988d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9894:	5b                   	pop    %rbx
    9895:	5d                   	pop    %rbp
    9896:	41 5c                	pop    %r12
    9898:	41 5d                	pop    %r13
    989a:	41 5e                	pop    %r14
    989c:	41 5f                	pop    %r15
    989e:	c3                   	ret
    989f:	90                   	nop
    98a0:	49 89 e9             	mov    %rbp,%r9
    98a3:	4c 8d 05 cb 57 00 00 	lea    0x57cb(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    98aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    98af:	ba 02 00 00 00       	mov    $0x2,%edx
    98b4:	be 00 02 00 00       	mov    $0x200,%esi
    98b9:	31 c0                	xor    %eax,%eax
    98bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    98c2:	00 
    98c3:	e8 e8 9a ff ff       	call   33b0 <__snprintf_chk@plt>
    98c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    98cf:	00 
    98d0:	e8 7b 9b ff ff       	call   3450 <strlen@plt>
    98d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    98dc:	00 
    98dd:	48 89 df             	mov    %rbx,%rdi
    98e0:	48 89 c2             	mov    %rax,%rdx
    98e3:	e8 28 a9 ff ff       	call   4210 <buf_put>
    98e8:	eb 8c                	jmp    9876 <fwp_write+0x96>
    98ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98f0:	49 89 e9             	mov    %rbp,%r9
    98f3:	4c 8d 05 e5 58 00 00 	lea    0x58e5(%rip),%r8        # f1df <_IO_stdin_used+0x1df>
    98fa:	eb ae                	jmp    98aa <fwp_write+0xca>
    98fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9900:	83 fa 13             	cmp    $0x13,%edx
    9903:	48 8d 05 cb 58 00 00 	lea    0x58cb(%rip),%rax        # f1d5 <_IO_stdin_used+0x1d5>
    990a:	48 8d 35 c9 58 00 00 	lea    0x58c9(%rip),%rsi        # f1da <_IO_stdin_used+0x1da>
    9911:	ba 04 00 00 00       	mov    $0x4,%edx
    9916:	48 0f 44 f0          	cmove  %rax,%rsi
    991a:	45 31 ed             	xor    %r13d,%r13d
    991d:	e8 ee a8 ff ff       	call   4210 <buf_put>
    9922:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9927:	0f 84 a3 08 00 00    	je     a1d0 <fwp_write+0x9f0>
    992d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9932:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9937:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    993c:	48 89 df             	mov    %rbx,%rdi
    993f:	49 0f 44 c5          	cmove  %r13,%rax
    9943:	31 c9                	xor    %ecx,%ecx
    9945:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    994a:	e8 91 fe ff ff       	call   97e0 <fwp_write>
    994f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9954:	0f 84 6e 09 00 00    	je     a2c8 <fwp_write+0xae8>
    995a:	49 83 c5 01          	add    $0x1,%r13
    995e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9962:	0f 83 68 08 00 00    	jae    a1d0 <fwp_write+0x9f0>
    9968:	ba 02 00 00 00       	mov    $0x2,%edx
    996d:	48 8d 35 ab 58 00 00 	lea    0x58ab(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9974:	48 89 df             	mov    %rbx,%rdi
    9977:	e8 94 a8 ff ff       	call   4210 <buf_put>
    997c:	eb af                	jmp    992d <fwp_write+0x14d>
    997e:	66 90                	xchg   %ax,%ax
    9980:	ba 06 00 00 00       	mov    $0x6,%edx
    9985:	48 8d 35 6c 58 00 00 	lea    0x586c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    998c:	48 83 c5 10          	add    $0x10,%rbp
    9990:	e8 7b a8 ff ff       	call   4210 <buf_put>
    9995:	48 89 ef             	mov    %rbp,%rdi
    9998:	e8 b3 9a ff ff       	call   3450 <strlen@plt>
    999d:	48 89 ee             	mov    %rbp,%rsi
    99a0:	48 89 df             	mov    %rbx,%rdi
    99a3:	48 89 c2             	mov    %rax,%rdx
    99a6:	e8 65 a8 ff ff       	call   4210 <buf_put>
    99ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    99b0:	ba 01 00 00 00       	mov    $0x1,%edx
    99b5:	48 89 df             	mov    %rbx,%rdi
    99b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    99bd:	e8 4e a8 ff ff       	call   4210 <buf_put>
    99c2:	e9 af fe ff ff       	jmp    9876 <fwp_write+0x96>
    99c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    99ce:	00 00 
    99d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    99d7:	00 
    99d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    99df:	00 00 
    99e1:	0f 85 ce 02 00 00    	jne    9cb5 <fwp_write+0x4d5>
    99e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    99ec:	48 8d 35 f1 57 00 00 	lea    0x57f1(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    99f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    99fa:	48 89 df             	mov    %rbx,%rdi
    99fd:	5b                   	pop    %rbx
    99fe:	5d                   	pop    %rbp
    99ff:	41 5c                	pop    %r12
    9a01:	41 5d                	pop    %r13
    9a03:	41 5e                	pop    %r14
    9a05:	41 5f                	pop    %r15
    9a07:	e9 04 a8 ff ff       	jmp    4210 <buf_put>
    9a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a10:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9a15:	4d 85 ed             	test   %r13,%r13
    9a18:	0f 84 02 0c 00 00    	je     a620 <fwp_write+0xe40>
    9a1e:	48 8d 35 07 58 00 00 	lea    0x5807(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    9a25:	4c 89 ef             	mov    %r13,%rdi
    9a28:	e8 03 9b ff ff       	call   3530 <strcmp@plt>
    9a2d:	41 89 c1             	mov    %eax,%r9d
    9a30:	85 c0                	test   %eax,%eax
    9a32:	0f 84 6c 0c 00 00    	je     a6a4 <fwp_write+0xec4>
    9a38:	4c 89 ef             	mov    %r13,%rdi
    9a3b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9a40:	e8 0b 9a ff ff       	call   3450 <strlen@plt>
    9a45:	4c 89 ee             	mov    %r13,%rsi
    9a48:	48 89 df             	mov    %rbx,%rdi
    9a4b:	48 89 c2             	mov    %rax,%rdx
    9a4e:	e8 bd a7 ff ff       	call   4210 <buf_put>
    9a53:	ba 01 00 00 00       	mov    $0x1,%edx
    9a58:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9a5d:	48 89 df             	mov    %rbx,%rdi
    9a60:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9a65:	e8 a6 a7 ff ff       	call   4210 <buf_put>
    9a6a:	ba 01 00 00 00       	mov    $0x1,%edx
    9a6f:	4c 89 fe             	mov    %r15,%rsi
    9a72:	48 89 df             	mov    %rbx,%rdi
    9a75:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9a7a:	e8 91 a7 ff ff       	call   4210 <buf_put>
    9a7f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9a84:	45 31 f6             	xor    %r14d,%r14d
    9a87:	85 d2                	test   %edx,%edx
    9a89:	0f 8e 81 0a 00 00    	jle    a510 <fwp_write+0xd30>
    9a8f:	45 31 ed             	xor    %r13d,%r13d
    9a92:	4d 85 ed             	test   %r13,%r13
    9a95:	0f 85 75 07 00 00    	jne    a210 <fwp_write+0xa30>
    9a9b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9aa2:	00 
    9aa3:	45 85 f6             	test   %r14d,%r14d
    9aa6:	0f 84 84 07 00 00    	je     a230 <fwp_write+0xa50>
    9aac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9ab1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9ab6:	48 89 df             	mov    %rbx,%rdi
    9ab9:	49 83 c5 01          	add    $0x1,%r13
    9abd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9ac1:	31 c9                	xor    %ecx,%ecx
    9ac3:	e8 18 fd ff ff       	call   97e0 <fwp_write>
    9ac8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9acd:	7f c3                	jg     9a92 <fwp_write+0x2b2>
    9acf:	45 85 f6             	test   %r14d,%r14d
    9ad2:	0f 84 38 0a 00 00    	je     a510 <fwp_write+0xd30>
    9ad8:	b8 29 00 00 00       	mov    $0x29,%eax
    9add:	ba 01 00 00 00       	mov    $0x1,%edx
    9ae2:	4c 89 fe             	mov    %r15,%rsi
    9ae5:	48 89 df             	mov    %rbx,%rdi
    9ae8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9aec:	e8 1f a7 ff ff       	call   4210 <buf_put>
    9af1:	e9 80 fd ff ff       	jmp    9876 <fwp_write+0x96>
    9af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9afd:	00 00 00 
    9b00:	ba 01 00 00 00       	mov    $0x1,%edx
    9b05:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9b0a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9b0f:	e8 fc a6 ff ff       	call   4210 <buf_put>
    9b14:	48 85 ed             	test   %rbp,%rbp
    9b17:	0f 84 93 06 00 00    	je     a1b0 <fwp_write+0x9d0>
    9b1d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9b21:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b26:	31 c9                	xor    %ecx,%ecx
    9b28:	48 89 df             	mov    %rbx,%rdi
    9b2b:	e8 b0 fc ff ff       	call   97e0 <fwp_write>
    9b30:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9b34:	48 85 ed             	test   %rbp,%rbp
    9b37:	0f 84 73 06 00 00    	je     a1b0 <fwp_write+0x9d0>
    9b3d:	ba 02 00 00 00       	mov    $0x2,%edx
    9b42:	48 8d 35 d6 56 00 00 	lea    0x56d6(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9b49:	48 89 df             	mov    %rbx,%rdi
    9b4c:	e8 bf a6 ff ff       	call   4210 <buf_put>
    9b51:	eb ca                	jmp    9b1d <fwp_write+0x33d>
    9b53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b58:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9b5c:	85 f6                	test   %esi,%esi
    9b5e:	0f 84 fc 07 00 00    	je     a360 <fwp_write+0xb80>
    9b64:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9b6b:	00 
    9b6c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9b73:	00 00 
    9b75:	0f 85 3a 01 00 00    	jne    9cb5 <fwp_write+0x4d5>
    9b7b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9b7f:	4c 89 ea             	mov    %r13,%rdx
    9b82:	e9 6c fe ff ff       	jmp    99f3 <fwp_write+0x213>
    9b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b8e:	00 00 
    9b90:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9b95:	ba 01 00 00 00       	mov    $0x1,%edx
    9b9a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9b9f:	48 89 ee             	mov    %rbp,%rsi
    9ba2:	e8 69 a6 ff ff       	call   4210 <buf_put>
    9ba7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9bac:	4c 89 e7             	mov    %r12,%rdi
    9baf:	e8 9c 98 ff ff       	call   3450 <strlen@plt>
    9bb4:	4c 89 e6             	mov    %r12,%rsi
    9bb7:	48 89 df             	mov    %rbx,%rdi
    9bba:	48 89 c2             	mov    %rax,%rdx
    9bbd:	e8 4e a6 ff ff       	call   4210 <buf_put>
    9bc2:	ba 01 00 00 00       	mov    $0x1,%edx
    9bc7:	48 89 ee             	mov    %rbp,%rsi
    9bca:	48 89 df             	mov    %rbx,%rdi
    9bcd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9bd2:	e8 39 a6 ff ff       	call   4210 <buf_put>
    9bd7:	e9 9a fc ff ff       	jmp    9876 <fwp_write+0x96>
    9bdc:	0f 1f 40 00          	nopl   0x0(%rax)
    9be0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9be5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9be9:	0f 8a 8e 0b 00 00    	jp     a77d <fwp_write+0xf9d>
    9bef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9bf3:	66 0f 54 05 05 60 00 	andpd  0x6005(%rip),%xmm0        # fc00 <msg.4+0x90>
    9bfa:	00 
    9bfb:	bd 01 00 00 00       	mov    $0x1,%ebp
    9c00:	66 0f 2e 05 30 60 00 	ucomisd 0x6030(%rip),%xmm0        # fc38 <msg.4+0xc8>
    9c07:	00 
    9c08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c0f:	00 
    9c10:	0f 87 b2 09 00 00    	ja     a5c8 <fwp_write+0xde8>
    9c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c1d:	00 00 00 
    9c20:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9c24:	89 ee                	mov    %ebp,%esi
    9c26:	4c 89 e7             	mov    %r12,%rdi
    9c29:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9c2e:	e8 dd aa ff ff       	call   4710 <fwp_format_g.constprop.0>
    9c33:	31 f6                	xor    %esi,%esi
    9c35:	4c 89 e7             	mov    %r12,%rdi
    9c38:	e8 d3 97 ff ff       	call   3410 <strtod@plt>
    9c3d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9c42:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9c46:	7a 06                	jp     9c4e <fwp_write+0x46e>
    9c48:	0f 84 e9 01 00 00    	je     9e37 <fwp_write+0x657>
    9c4e:	83 c5 01             	add    $0x1,%ebp
    9c51:	83 fd 12             	cmp    $0x12,%ebp
    9c54:	75 ca                	jne    9c20 <fwp_write+0x440>
    9c56:	be 11 00 00 00       	mov    $0x11,%esi
    9c5b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9c5f:	4c 89 e7             	mov    %r12,%rdi
    9c62:	e8 a9 aa ff ff       	call   4710 <fwp_format_g.constprop.0>
    9c67:	e9 cb 01 00 00       	jmp    9e37 <fwp_write+0x657>
    9c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c70:	48 83 fd 01          	cmp    $0x1,%rbp
    9c74:	0f 84 e6 08 00 00    	je     a560 <fwp_write+0xd80>
    9c7a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9c7e:	b8 02 00 00 00       	mov    $0x2,%eax
    9c83:	ba 01 00 00 00       	mov    $0x1,%edx
    9c88:	48 0f 44 d0          	cmove  %rax,%rdx
    9c8c:	48 8d 35 3a 55 00 00 	lea    0x553a(%rip),%rsi        # f1cd <_IO_stdin_used+0x1cd>
    9c93:	48 8d 05 38 55 00 00 	lea    0x5538(%rip),%rax        # f1d2 <_IO_stdin_used+0x1d2>
    9c9a:	48 0f 44 f0          	cmove  %rax,%rsi
    9c9e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ca5:	00 
    9ca6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9cad:	00 00 
    9caf:	0f 84 3e fd ff ff    	je     99f3 <fwp_write+0x213>
    9cb5:	e8 a6 97 ff ff       	call   3460 <__stack_chk_fail@plt>
    9cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9cc0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9cc5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9cca:	e8 81 a4 ff ff       	call   4150 <buf_grow>
    9ccf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9cd3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9cd9:	4c 03 0b             	add    (%rbx),%r9
    9cdc:	66 45 89 11          	mov    %r10w,(%r9)
    9ce0:	45 85 e4             	test   %r12d,%r12d
    9ce3:	0f 8e 07 05 00 00    	jle    a1f0 <fwp_write+0xa10>
    9ce9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9cf0:	55 55 55 
    9cf3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9cf8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9cff:	aa aa aa 
    9d02:	49 83 c1 01          	add    $0x1,%r9
    9d06:	eb 45                	jmp    9d4d <fwp_write+0x56d>
    9d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d0f:	00 
    9d10:	be 01 00 00 00       	mov    $0x1,%esi
    9d15:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9d1a:	88 07                	mov    %al,(%rdi)
    9d1c:	48 89 e8             	mov    %rbp,%rax
    9d1f:	49 f7 e8             	imul   %r8
    9d22:	48 89 e8             	mov    %rbp,%rax
    9d25:	48 c1 f8 3f          	sar    $0x3f,%rax
    9d29:	48 29 c2             	sub    %rax,%rdx
    9d2c:	48 85 c9             	test   %rcx,%rcx
    9d2f:	0f 95 c0             	setne  %al
    9d32:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9d36:	48 83 ef 01          	sub    $0x1,%rdi
    9d3a:	48 21 c5             	and    %rax,%rbp
    9d3d:	48 29 ea             	sub    %rbp,%rdx
    9d40:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9d44:	49 39 f9             	cmp    %rdi,%r9
    9d47:	0f 84 a3 04 00 00    	je     a1f0 <fwp_write+0xa10>
    9d4d:	48 89 e8             	mov    %rbp,%rax
    9d50:	49 f7 e8             	imul   %r8
    9d53:	48 89 e8             	mov    %rbp,%rax
    9d56:	48 c1 f8 3f          	sar    $0x3f,%rax
    9d5a:	48 89 d1             	mov    %rdx,%rcx
    9d5d:	48 29 c1             	sub    %rax,%rcx
    9d60:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9d64:	48 89 e9             	mov    %rbp,%rcx
    9d67:	48 29 c1             	sub    %rax,%rcx
    9d6a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9d6e:	49 f7 e2             	mul    %r10
    9d71:	b8 30 00 00 00       	mov    $0x30,%eax
    9d76:	48 89 d6             	mov    %rdx,%rsi
    9d79:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9d7d:	48 d1 ee             	shr    $1,%rsi
    9d80:	48 01 f2             	add    %rsi,%rdx
    9d83:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9d87:	48 29 d6             	sub    %rdx,%rsi
    9d8a:	74 8e                	je     9d1a <fwp_write+0x53a>
    9d8c:	48 83 fe 01          	cmp    $0x1,%rsi
    9d90:	0f 85 7a ff ff ff    	jne    9d10 <fwp_write+0x530>
    9d96:	31 f6                	xor    %esi,%esi
    9d98:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9d9d:	e9 78 ff ff ff       	jmp    9d1a <fwp_write+0x53a>
    9da2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9da8:	66 0f 6e cd          	movd   %ebp,%xmm1
    9dac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9daf:	0f 8a c8 09 00 00    	jp     a77d <fwp_write+0xf9d>
    9db5:	0f 28 c1             	movaps %xmm1,%xmm0
    9db8:	0f 54 05 31 5e 00 00 	andps  0x5e31(%rip),%xmm0        # fbf0 <msg.4+0x80>
    9dbf:	0f 2e 05 3e 52 00 00 	ucomiss 0x523e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9dc6:	0f 87 24 08 00 00    	ja     a5f0 <fwp_write+0xe10>
    9dcc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9dd0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9dd6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ddd:	00 
    9dde:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9de2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dee:	00 00 
    9df0:	44 89 ee             	mov    %r13d,%esi
    9df3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9df8:	4c 89 e7             	mov    %r12,%rdi
    9dfb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9e00:	e8 0b a9 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e05:	31 f6                	xor    %esi,%esi
    9e07:	4c 89 e7             	mov    %r12,%rdi
    9e0a:	e8 a1 96 ff ff       	call   34b0 <strtof@plt>
    9e0f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9e14:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9e17:	7a 02                	jp     9e1b <fwp_write+0x63b>
    9e19:	74 1c                	je     9e37 <fwp_write+0x657>
    9e1b:	41 83 c5 01          	add    $0x1,%r13d
    9e1f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9e23:	75 cb                	jne    9df0 <fwp_write+0x610>
    9e25:	be 09 00 00 00       	mov    $0x9,%esi
    9e2a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9e2f:	4c 89 e7             	mov    %r12,%rdi
    9e32:	e8 d9 a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e37:	4c 89 e7             	mov    %r12,%rdi
    9e3a:	e8 41 a5 ff ff       	call   4380 <fwp_finish_float>
    9e3f:	e9 1c fa ff ff       	jmp    9860 <fwp_write+0x80>
    9e44:	0f 1f 40 00          	nopl   0x0(%rax)
    9e48:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9e4c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9e50:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9e57:	00 
    9e58:	48 89 ef             	mov    %rbp,%rdi
    9e5b:	e8 e0 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9e60:	48 89 ef             	mov    %rbp,%rdi
    9e63:	e8 e8 95 ff ff       	call   3450 <strlen@plt>
    9e68:	48 89 ee             	mov    %rbp,%rsi
    9e6b:	48 89 df             	mov    %rbx,%rdi
    9e6e:	48 89 c2             	mov    %rax,%rdx
    9e71:	e8 9a a3 ff ff       	call   4210 <buf_put>
    9e76:	e9 fb f9 ff ff       	jmp    9876 <fwp_write+0x96>
    9e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e80:	ba 06 00 00 00       	mov    $0x6,%edx
    9e85:	48 8d 35 96 53 00 00 	lea    0x5396(%rip),%rsi        # f222 <_IO_stdin_used+0x222>
    9e8c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9e92:	e8 79 a3 ff ff       	call   4210 <buf_put>
    9e97:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9e9e:	ff ff 7f 
    9ea1:	48 23 55 00          	and    0x0(%rbp),%rdx
    9ea5:	0f 84 86 02 00 00    	je     a131 <fwp_write+0x951>
    9eab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9eb0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9eb4:	48 85 d2             	test   %rdx,%rdx
    9eb7:	0f 84 ae 00 00 00    	je     9f6b <fwp_write+0x78b>
    9ebd:	8b 0a                	mov    (%rdx),%ecx
    9ebf:	83 f9 1c             	cmp    $0x1c,%ecx
    9ec2:	0f 84 58 06 00 00    	je     a520 <fwp_write+0xd40>
    9ec8:	83 f9 1b             	cmp    $0x1b,%ecx
    9ecb:	0f 87 9a 00 00 00    	ja     9f6b <fwp_write+0x78b>
    9ed1:	be 01 00 00 00       	mov    $0x1,%esi
    9ed6:	48 d3 e6             	shl    %cl,%rsi
    9ed9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9edf:	0f 85 4b 04 00 00    	jne    a330 <fwp_write+0xb50>
    9ee5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9eeb:	0f 85 0f 04 00 00    	jne    a300 <fwp_write+0xb20>
    9ef1:	83 e6 21             	and    $0x21,%esi
    9ef4:	74 75                	je     9f6b <fwp_write+0x78b>
    9ef6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9efb:	48 85 ff             	test   %rdi,%rdi
    9efe:	79 07                	jns    9f07 <fwp_write+0x727>
    9f00:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9f04:	4c 01 ee             	add    %r13,%rsi
    9f07:	48 0f be 3e          	movsbq (%rsi),%rdi
    9f0b:	85 c9                	test   %ecx,%ecx
    9f0d:	40 0f b6 f7          	movzbl %dil,%esi
    9f11:	48 0f 44 f7          	cmove  %rdi,%rsi
    9f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f1c:	00 00 00 00 
    9f20:	31 c9                	xor    %ecx,%ecx
    9f22:	48 89 df             	mov    %rbx,%rdi
    9f25:	49 83 c5 01          	add    $0x1,%r13
    9f29:	e8 b2 f8 ff ff       	call   97e0 <fwp_write>
    9f2e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9f35:	ff ff 7f 
    9f38:	48 23 55 00          	and    0x0(%rbp),%rdx
    9f3c:	49 39 d5             	cmp    %rdx,%r13
    9f3f:	0f 83 ec 01 00 00    	jae    a131 <fwp_write+0x951>
    9f45:	ba 02 00 00 00       	mov    $0x2,%edx
    9f4a:	48 89 df             	mov    %rbx,%rdi
    9f4d:	48 8d 35 cb 52 00 00 	lea    0x52cb(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9f54:	e8 b7 a2 ff ff       	call   4210 <buf_put>
    9f59:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f5e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9f62:	48 85 d2             	test   %rdx,%rdx
    9f65:	0f 85 52 ff ff ff    	jne    9ebd <fwp_write+0x6dd>
    9f6b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9f70:	48 85 ff             	test   %rdi,%rdi
    9f73:	0f 88 cf 05 00 00    	js     a548 <fwp_write+0xd68>
    9f79:	48 8b 31             	mov    (%rcx),%rsi
    9f7c:	eb a2                	jmp    9f20 <fwp_write+0x740>
    9f7e:	66 90                	xchg   %ax,%ax
    9f80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f87:	00 
    9f88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f8f:	00 00 
    9f91:	0f 85 1e fd ff ff    	jne    9cb5 <fwp_write+0x4d5>
    9f97:	ba 08 00 00 00       	mov    $0x8,%edx
    9f9c:	48 8d 35 4c 52 00 00 	lea    0x524c(%rip),%rsi        # f1ef <_IO_stdin_used+0x1ef>
    9fa3:	e9 4b fa ff ff       	jmp    99f3 <fwp_write+0x213>
    9fa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9faf:	00 
    9fb0:	89 e8                	mov    %ebp,%eax
    9fb2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9fb9:	76 03                	jbe    9fbe <fwp_write+0x7de>
    9fbb:	8b 45 00             	mov    0x0(%rbp),%eax
    9fbe:	41 89 c6             	mov    %eax,%r14d
    9fc1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9fc6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    9fcb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    9fcf:	4c 89 ef             	mov    %r13,%rdi
    9fd2:	e8 79 94 ff ff       	call   3450 <strlen@plt>
    9fd7:	4c 89 ee             	mov    %r13,%rsi
    9fda:	48 89 df             	mov    %rbx,%rdi
    9fdd:	48 89 c2             	mov    %rax,%rdx
    9fe0:	e8 2b a2 ff ff       	call   4210 <buf_put>
    9fe5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9fea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    9fee:	85 f6                	test   %esi,%esi
    9ff0:	0f 8e 80 f8 ff ff    	jle    9876 <fwp_write+0x96>
    9ff6:	45 31 ed             	xor    %r13d,%r13d
    9ff9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9ffe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a003:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a008:	ba 01 00 00 00       	mov    $0x1,%edx
    a00d:	4c 89 fe             	mov    %r15,%rsi
    a010:	48 89 04 24          	mov    %rax,(%rsp)
    a014:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a019:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a01d:	48 89 df             	mov    %rbx,%rdi
    a020:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a024:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a029:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a02e:	e8 dd a1 ff ff       	call   4210 <buf_put>
    a033:	41 8b 06             	mov    (%r14),%eax
    a036:	83 f8 0e             	cmp    $0xe,%eax
    a039:	0f 84 71 02 00 00    	je     a2b0 <fwp_write+0xad0>
    a03f:	83 f8 10             	cmp    $0x10,%eax
    a042:	0f 84 38 02 00 00    	je     a280 <fwp_write+0xaa0>
    a048:	83 f8 0a             	cmp    $0xa,%eax
    a04b:	0f 84 7f 04 00 00    	je     a4d0 <fwp_write+0xcf0>
    a051:	0f 8f f9 00 00 00    	jg     a150 <fwp_write+0x970>
    a057:	83 f8 03             	cmp    $0x3,%eax
    a05a:	0f 8f 50 04 00 00    	jg     a4b0 <fwp_write+0xcd0>
    a060:	85 c0                	test   %eax,%eax
    a062:	78 10                	js     a074 <fwp_write+0x894>
    a064:	48 8b 04 24          	mov    (%rsp),%rax
    a068:	48 c1 e8 3f          	shr    $0x3f,%rax
    a06c:	85 c0                	test   %eax,%eax
    a06e:	0f 85 f9 00 00 00    	jne    a16d <fwp_write+0x98d>
    a074:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a079:	48 8b 34 24          	mov    (%rsp),%rsi
    a07d:	31 c9                	xor    %ecx,%ecx
    a07f:	48 89 df             	mov    %rbx,%rdi
    a082:	e8 59 f7 ff ff       	call   97e0 <fwp_write>
    a087:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a08c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a091:	49 83 c5 01          	add    $0x1,%r13
    a095:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a099:	0f 8f 5f ff ff ff    	jg     9ffe <fwp_write+0x81e>
    a09f:	e9 d2 f7 ff ff       	jmp    9876 <fwp_write+0x96>
    a0a4:	0f 1f 40 00          	nopl   0x0(%rax)
    a0a8:	ba 06 00 00 00       	mov    $0x6,%edx
    a0ad:	48 8d 35 61 51 00 00 	lea    0x5161(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    a0b4:	45 31 ed             	xor    %r13d,%r13d
    a0b7:	e8 54 a1 ff ff       	call   4210 <buf_put>
    a0bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a0c1:	75 19                	jne    a0dc <fwp_write+0x8fc>
    a0c3:	eb 6c                	jmp    a131 <fwp_write+0x951>
    a0c5:	0f 1f 00             	nopl   (%rax)
    a0c8:	ba 02 00 00 00       	mov    $0x2,%edx
    a0cd:	48 8d 35 4b 51 00 00 	lea    0x514b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a0d4:	48 89 df             	mov    %rbx,%rdi
    a0d7:	e8 34 a1 ff ff       	call   4210 <buf_put>
    a0dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a0e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a0e7:	31 c0                	xor    %eax,%eax
    a0e9:	49 83 c5 01          	add    $0x1,%r13
    a0ed:	4c 8d 05 28 51 00 00 	lea    0x5128(%rip),%r8        # f21c <_IO_stdin_used+0x21c>
    a0f4:	ba 02 00 00 00       	mov    $0x2,%edx
    a0f9:	be 00 02 00 00       	mov    $0x200,%esi
    a0fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a105:	00 
    a106:	e8 a5 92 ff ff       	call   33b0 <__snprintf_chk@plt>
    a10b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a112:	00 
    a113:	e8 38 93 ff ff       	call   3450 <strlen@plt>
    a118:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a11f:	00 
    a120:	48 89 df             	mov    %rbx,%rdi
    a123:	48 89 c2             	mov    %rax,%rdx
    a126:	e8 e5 a0 ff ff       	call   4210 <buf_put>
    a12b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a12f:	72 97                	jb     a0c8 <fwp_write+0x8e8>
    a131:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a136:	ba 01 00 00 00       	mov    $0x1,%edx
    a13b:	48 89 df             	mov    %rbx,%rdi
    a13e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a143:	e8 c8 a0 ff ff       	call   4210 <buf_put>
    a148:	e9 29 f7 ff ff       	jmp    9876 <fwp_write+0x96>
    a14d:	0f 1f 00             	nopl   (%rax)
    a150:	83 f8 0b             	cmp    $0xb,%eax
    a153:	0f 85 1b ff ff ff    	jne    a074 <fwp_write+0x894>
    a159:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a15e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a162:	83 e0 01             	and    $0x1,%eax
    a165:	85 c0                	test   %eax,%eax
    a167:	0f 84 07 ff ff ff    	je     a074 <fwp_write+0x894>
    a16d:	4c 89 fe             	mov    %r15,%rsi
    a170:	48 89 df             	mov    %rbx,%rdi
    a173:	ba 01 00 00 00       	mov    $0x1,%edx
    a178:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a17d:	e8 8e a0 ff ff       	call   4210 <buf_put>
    a182:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a187:	48 8b 34 24          	mov    (%rsp),%rsi
    a18b:	31 c9                	xor    %ecx,%ecx
    a18d:	48 89 df             	mov    %rbx,%rdi
    a190:	e8 4b f6 ff ff       	call   97e0 <fwp_write>
    a195:	ba 01 00 00 00       	mov    $0x1,%edx
    a19a:	4c 89 fe             	mov    %r15,%rsi
    a19d:	48 89 df             	mov    %rbx,%rdi
    a1a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a1a5:	e8 66 a0 ff ff       	call   4210 <buf_put>
    a1aa:	e9 d8 fe ff ff       	jmp    a087 <fwp_write+0x8a7>
    a1af:	90                   	nop
    a1b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a1b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1ba:	48 89 df             	mov    %rbx,%rdi
    a1bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a1c2:	e8 49 a0 ff ff       	call   4210 <buf_put>
    a1c7:	e9 aa f6 ff ff       	jmp    9876 <fwp_write+0x96>
    a1cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1d5:	ba 01 00 00 00       	mov    $0x1,%edx
    a1da:	48 89 df             	mov    %rbx,%rdi
    a1dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a1e2:	e8 29 a0 ff ff       	call   4210 <buf_put>
    a1e7:	e9 8a f6 ff ff       	jmp    9876 <fwp_write+0x96>
    a1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a1f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a1f4:	48 8b 13             	mov    (%rbx),%rdx
    a1f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a1fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a200:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a204:	e9 6d f6 ff ff       	jmp    9876 <fwp_write+0x96>
    a209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a210:	ba 02 00 00 00       	mov    $0x2,%edx
    a215:	48 8d 35 03 50 00 00 	lea    0x5003(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a21c:	48 89 df             	mov    %rbx,%rdi
    a21f:	e8 ec 9f ff ff       	call   4210 <buf_put>
    a224:	e9 72 f8 ff ff       	jmp    9a9b <fwp_write+0x2bb>
    a229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a230:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a235:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a23a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a23e:	48 89 f7             	mov    %rsi,%rdi
    a241:	48 89 34 24          	mov    %rsi,(%rsp)
    a245:	e8 06 92 ff ff       	call   3450 <strlen@plt>
    a24a:	48 8b 34 24          	mov    (%rsp),%rsi
    a24e:	48 89 df             	mov    %rbx,%rdi
    a251:	48 89 c2             	mov    %rax,%rdx
    a254:	e8 b7 9f ff ff       	call   4210 <buf_put>
    a259:	ba 03 00 00 00       	mov    $0x3,%edx
    a25e:	48 8d 35 dd 4f 00 00 	lea    0x4fdd(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    a265:	48 89 df             	mov    %rbx,%rdi
    a268:	e8 a3 9f ff ff       	call   4210 <buf_put>
    a26d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a272:	e9 35 f8 ff ff       	jmp    9aac <fwp_write+0x2cc>
    a277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a27e:	00 00 
    a280:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a285:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a289:	48 85 ff             	test   %rdi,%rdi
    a28c:	0f 84 e2 fd ff ff    	je     a074 <fwp_write+0x894>
    a292:	48 8d 35 93 4f 00 00 	lea    0x4f93(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    a299:	e8 92 92 ff ff       	call   3530 <strcmp@plt>
    a29e:	85 c0                	test   %eax,%eax
    a2a0:	0f 95 c0             	setne  %al
    a2a3:	0f b6 c0             	movzbl %al,%eax
    a2a6:	e9 c1 fd ff ff       	jmp    a06c <fwp_write+0x88c>
    a2ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2b0:	31 c0                	xor    %eax,%eax
    a2b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a2b9:	00 
    a2ba:	0f 97 c0             	seta   %al
    a2bd:	e9 aa fd ff ff       	jmp    a06c <fwp_write+0x88c>
    a2c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2c8:	48 89 df             	mov    %rbx,%rdi
    a2cb:	ba 02 00 00 00       	mov    $0x2,%edx
    a2d0:	48 8d 35 52 4f 00 00 	lea    0x4f52(%rip),%rsi        # f229 <_IO_stdin_used+0x229>
    a2d7:	e8 34 9f ff ff       	call   4210 <buf_put>
    a2dc:	4c 89 e8             	mov    %r13,%rax
    a2df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a2e4:	31 c9                	xor    %ecx,%ecx
    a2e6:	48 c1 e0 04          	shl    $0x4,%rax
    a2ea:	48 89 df             	mov    %rbx,%rdi
    a2ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a2f2:	e8 e9 f4 ff ff       	call   97e0 <fwp_write>
    a2f7:	e9 5e f6 ff ff       	jmp    995a <fwp_write+0x17a>
    a2fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a300:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a305:	48 85 ff             	test   %rdi,%rdi
    a308:	79 0c                	jns    a316 <fwp_write+0xb36>
    a30a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a311:	00 
    a312:	48 03 75 10          	add    0x10(%rbp),%rsi
    a316:	48 63 3e             	movslq (%rsi),%rdi
    a319:	83 f9 02             	cmp    $0x2,%ecx
    a31c:	89 fe                	mov    %edi,%esi
    a31e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a322:	e9 f9 fb ff ff       	jmp    9f20 <fwp_write+0x740>
    a327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a32e:	00 00 
    a330:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a335:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a33a:	48 85 ff             	test   %rdi,%rdi
    a33d:	0f 88 0f 03 00 00    	js     a652 <fwp_write+0xe72>
    a343:	49 0f bf 38          	movswq (%r8),%rdi
    a347:	83 f9 01             	cmp    $0x1,%ecx
    a34a:	0f b7 f7             	movzwl %di,%esi
    a34d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a351:	e9 ca fb ff ff       	jmp    9f20 <fwp_write+0x740>
    a356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a35d:	00 00 00 
    a360:	ba 01 00 00 00       	mov    $0x1,%edx
    a365:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a36a:	48 83 c5 08          	add    $0x8,%rbp
    a36e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a373:	e8 98 9e ff ff       	call   4210 <buf_put>
    a378:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a37d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a382:	4d 85 ed             	test   %r13,%r13
    a385:	75 46                	jne    a3cd <fwp_write+0xbed>
    a387:	e9 04 01 00 00       	jmp    a490 <fwp_write+0xcb0>
    a38c:	0f 1f 40 00          	nopl   0x0(%rax)
    a390:	41 80 f9 09          	cmp    $0x9,%r9b
    a394:	0f 84 d6 00 00 00    	je     a470 <fwp_write+0xc90>
    a39a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a39e:	0f 85 9c 00 00 00    	jne    a440 <fwp_write+0xc60>
    a3a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a3a9:	48 8d 35 55 4e 00 00 	lea    0x4e55(%rip),%rsi        # f205 <_IO_stdin_used+0x205>
    a3b0:	48 89 df             	mov    %rbx,%rdi
    a3b3:	e8 58 9e ff ff       	call   4210 <buf_put>
    a3b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3bf:	00 
    a3c0:	48 83 c5 01          	add    $0x1,%rbp
    a3c4:	49 39 ec             	cmp    %rbp,%r12
    a3c7:	0f 84 c3 00 00 00    	je     a490 <fwp_write+0xcb0>
    a3cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a3d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a3d6:	74 28                	je     a400 <fwp_write+0xc20>
    a3d8:	7e b6                	jle    a390 <fwp_write+0xbb0>
    a3da:	41 80 f9 22          	cmp    $0x22,%r9b
    a3de:	74 40                	je     a420 <fwp_write+0xc40>
    a3e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a3e4:	75 5a                	jne    a440 <fwp_write+0xc60>
    a3e6:	ba 02 00 00 00       	mov    $0x2,%edx
    a3eb:	48 8d 35 10 4e 00 00 	lea    0x4e10(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    a3f2:	48 89 df             	mov    %rbx,%rdi
    a3f5:	e8 16 9e ff ff       	call   4210 <buf_put>
    a3fa:	eb c4                	jmp    a3c0 <fwp_write+0xbe0>
    a3fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a400:	ba 02 00 00 00       	mov    $0x2,%edx
    a405:	48 8d 35 ff 4d 00 00 	lea    0x4dff(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    a40c:	48 89 df             	mov    %rbx,%rdi
    a40f:	e8 fc 9d ff ff       	call   4210 <buf_put>
    a414:	eb aa                	jmp    a3c0 <fwp_write+0xbe0>
    a416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a41d:	00 00 00 
    a420:	ba 02 00 00 00       	mov    $0x2,%edx
    a425:	48 8d 35 d3 4d 00 00 	lea    0x4dd3(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    a42c:	48 89 df             	mov    %rbx,%rdi
    a42f:	e8 dc 9d ff ff       	call   4210 <buf_put>
    a434:	eb 8a                	jmp    a3c0 <fwp_write+0xbe0>
    a436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a43d:	00 00 00 
    a440:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a444:	0f 86 2e 01 00 00    	jbe    a578 <fwp_write+0xd98>
    a44a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a44e:	0f 84 24 01 00 00    	je     a578 <fwp_write+0xd98>
    a454:	ba 01 00 00 00       	mov    $0x1,%edx
    a459:	4c 89 fe             	mov    %r15,%rsi
    a45c:	48 89 df             	mov    %rbx,%rdi
    a45f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a464:	e8 a7 9d ff ff       	call   4210 <buf_put>
    a469:	e9 52 ff ff ff       	jmp    a3c0 <fwp_write+0xbe0>
    a46e:	66 90                	xchg   %ax,%ax
    a470:	ba 02 00 00 00       	mov    $0x2,%edx
    a475:	48 8d 35 8c 4d 00 00 	lea    0x4d8c(%rip),%rsi        # f208 <_IO_stdin_used+0x208>
    a47c:	48 89 df             	mov    %rbx,%rdi
    a47f:	e8 8c 9d ff ff       	call   4210 <buf_put>
    a484:	e9 37 ff ff ff       	jmp    a3c0 <fwp_write+0xbe0>
    a489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a490:	ba 01 00 00 00       	mov    $0x1,%edx
    a495:	4c 89 fe             	mov    %r15,%rsi
    a498:	48 89 df             	mov    %rbx,%rdi
    a49b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a4a0:	e8 6b 9d ff ff       	call   4210 <buf_put>
    a4a5:	e9 cc f3 ff ff       	jmp    9876 <fwp_write+0x96>
    a4aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4b0:	83 f8 04             	cmp    $0x4,%eax
    a4b3:	0f 85 bb fb ff ff    	jne    a074 <fwp_write+0x894>
    a4b9:	48 8b 04 24          	mov    (%rsp),%rax
    a4bd:	48 8b 40 08          	mov    0x8(%rax),%rax
    a4c1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a4c6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a4ca:	e9 96 fc ff ff       	jmp    a165 <fwp_write+0x985>
    a4cf:	90                   	nop
    a4d0:	8b 0c 24             	mov    (%rsp),%ecx
    a4d3:	31 c0                	xor    %eax,%eax
    a4d5:	85 c9                	test   %ecx,%ecx
    a4d7:	0f 98 c0             	sets   %al
    a4da:	e9 86 fc ff ff       	jmp    a165 <fwp_write+0x985>
    a4df:	90                   	nop
    a4e0:	48 f7 d8             	neg    %rax
    a4e3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a4ea:	00 
    a4eb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a4f2:	2d 
    a4f3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a4fa:	00 
    a4fb:	48 83 d2 00          	adc    $0x0,%rdx
    a4ff:	48 89 c6             	mov    %rax,%rsi
    a502:	48 f7 da             	neg    %rdx
    a505:	e8 36 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a50a:	e9 51 f3 ff ff       	jmp    9860 <fwp_write+0x80>
    a50f:	90                   	nop
    a510:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a515:	e9 c3 f5 ff ff       	jmp    9add <fwp_write+0x2fd>
    a51a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a520:	4c 89 e9             	mov    %r13,%rcx
    a523:	48 c1 e1 04          	shl    $0x4,%rcx
    a527:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a52c:	48 85 ff             	test   %rdi,%rdi
    a52f:	0f 89 eb f9 ff ff    	jns    9f20 <fwp_write+0x740>
    a535:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a539:	48 89 ce             	mov    %rcx,%rsi
    a53c:	e9 df f9 ff ff       	jmp    9f20 <fwp_write+0x740>
    a541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a548:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a54f:	00 
    a550:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a554:	e9 20 fa ff ff       	jmp    9f79 <fwp_write+0x799>
    a559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a560:	ba 02 00 00 00       	mov    $0x2,%edx
    a565:	48 8d 35 63 4c 00 00 	lea    0x4c63(%rip),%rsi        # f1cf <_IO_stdin_used+0x1cf>
    a56c:	e9 2d f7 ff ff       	jmp    9c9e <fwp_write+0x4be>
    a571:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a578:	4c 8d 05 8f 4c 00 00 	lea    0x4c8f(%rip),%r8        # f20e <_IO_stdin_used+0x20e>
    a57f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a584:	31 c0                	xor    %eax,%eax
    a586:	ba 02 00 00 00       	mov    $0x2,%edx
    a58b:	be 10 00 00 00       	mov    $0x10,%esi
    a590:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a597:	00 
    a598:	e8 13 8e ff ff       	call   33b0 <__snprintf_chk@plt>
    a59d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5a4:	00 
    a5a5:	e8 a6 8e ff ff       	call   3450 <strlen@plt>
    a5aa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a5b1:	00 
    a5b2:	48 89 df             	mov    %rbx,%rdi
    a5b5:	48 89 c2             	mov    %rax,%rdx
    a5b8:	e8 53 9c ff ff       	call   4210 <buf_put>
    a5bd:	e9 fe fd ff ff       	jmp    a3c0 <fwp_write+0xbe0>
    a5c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a5cc:	48 8d 35 f6 4b 00 00 	lea    0x4bf6(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a5d3:	48 8d 05 ee 4b 00 00 	lea    0x4bee(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a5da:	4c 89 e7             	mov    %r12,%rdi
    a5dd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a5e1:	48 0f 46 f0          	cmovbe %rax,%rsi
    a5e5:	e8 06 8e ff ff       	call   33f0 <strcpy@plt>
    a5ea:	e9 71 f2 ff ff       	jmp    9860 <fwp_write+0x80>
    a5ef:	90                   	nop
    a5f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a5f4:	48 8d 35 ce 4b 00 00 	lea    0x4bce(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a5fb:	48 8d 05 c6 4b 00 00 	lea    0x4bc6(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a602:	0f 2f c8             	comiss %xmm0,%xmm1
    a605:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a60c:	00 
    a60d:	4c 89 e7             	mov    %r12,%rdi
    a610:	48 0f 46 f0          	cmovbe %rax,%rsi
    a614:	e8 d7 8d ff ff       	call   33f0 <strcpy@plt>
    a619:	e9 42 f2 ff ff       	jmp    9860 <fwp_write+0x80>
    a61e:	66 90                	xchg   %ax,%ax
    a620:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a625:	45 85 c0             	test   %r8d,%r8d
    a628:	75 34                	jne    a65e <fwp_write+0xe7e>
    a62a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a631:	00 
    a632:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a639:	00 00 
    a63b:	0f 85 74 f6 ff ff    	jne    9cb5 <fwp_write+0x4d5>
    a641:	ba 02 00 00 00       	mov    $0x2,%edx
    a646:	48 8d 35 f2 4b 00 00 	lea    0x4bf2(%rip),%rsi        # f23f <_IO_stdin_used+0x23f>
    a64d:	e9 a1 f3 ff ff       	jmp    99f3 <fwp_write+0x213>
    a652:	48 03 75 10          	add    0x10(%rbp),%rsi
    a656:	49 89 f0             	mov    %rsi,%r8
    a659:	e9 e5 fc ff ff       	jmp    a343 <fwp_write+0xb63>
    a65e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a663:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a668:	85 ff                	test   %edi,%edi
    a66a:	0f 84 fa f3 ff ff    	je     9a6a <fwp_write+0x28a>
    a670:	ba 01 00 00 00       	mov    $0x1,%edx
    a675:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a67a:	48 89 df             	mov    %rbx,%rdi
    a67d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a682:	e8 89 9b ff ff       	call   4210 <buf_put>
    a687:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a68c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a691:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a697:	85 c0                	test   %eax,%eax
    a699:	0f 8f f0 f3 ff ff    	jg     9a8f <fwp_write+0x2af>
    a69f:	e9 34 f4 ff ff       	jmp    9ad8 <fwp_write+0x2f8>
    a6a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a6a8:	49 89 c5             	mov    %rax,%r13
    a6ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a6b0:	49 89 c4             	mov    %rax,%r12
    a6b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    a6b7:	4c 09 e8             	or     %r13,%rax
    a6ba:	0f 84 a7 00 00 00    	je     a767 <fwp_write+0xf87>
    a6c0:	48 8d 2d 39 6d 00 00 	lea    0x6d39(%rip),%rbp        # 11400 <units.1>
    a6c7:	4d 89 e7             	mov    %r12,%r15
    a6ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a6ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a6d3:	4c 89 ff             	mov    %r15,%rdi
    a6d6:	4c 89 ee             	mov    %r13,%rsi
    a6d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    a6dd:	48 99                	cqto
    a6df:	48 89 d1             	mov    %rdx,%rcx
    a6e2:	48 89 c2             	mov    %rax,%rdx
    a6e5:	e8 d6 41 00 00       	call   e8c0 <__divmodti4>
    a6ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    a6ee:	48 89 c1             	mov    %rax,%rcx
    a6f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a6f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a6fb:	0f 84 94 00 00 00    	je     a795 <fwp_write+0xfb5>
    a701:	41 83 c1 01          	add    $0x1,%r9d
    a705:	48 83 c5 10          	add    $0x10,%rbp
    a709:	41 83 f9 05          	cmp    $0x5,%r9d
    a70d:	75 bb                	jne    a6ca <fwp_write+0xeea>
    a70f:	4d 85 ed             	test   %r13,%r13
    a712:	79 53                	jns    a767 <fwp_write+0xf87>
    a714:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a719:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a71e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a723:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a728:	48 99                	cqto
    a72a:	48 f7 d8             	neg    %rax
    a72d:	48 83 d2 00          	adc    $0x0,%rdx
    a731:	48 89 c6             	mov    %rax,%rsi
    a734:	48 f7 da             	neg    %rdx
    a737:	e8 04 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a73c:	49 89 e8             	mov    %rbp,%r8
    a73f:	ba 00 02 00 00       	mov    $0x200,%edx
    a744:	be 02 00 00 00       	mov    $0x2,%esi
    a749:	31 c0                	xor    %eax,%eax
    a74b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a752:	00 
    a753:	48 8d 0d e0 4a 00 00 	lea    0x4ae0(%rip),%rcx        # f23a <_IO_stdin_used+0x23a>
    a75a:	4c 89 e7             	mov    %r12,%rdi
    a75d:	e8 7e 8f ff ff       	call   36e0 <__sprintf_chk@plt>
    a762:	e9 f9 f0 ff ff       	jmp    9860 <fwp_write+0x80>
    a767:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a76c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a771:	31 d2                	xor    %edx,%edx
    a773:	48 89 ef             	mov    %rbp,%rdi
    a776:	e8 c5 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a77b:	eb bf                	jmp    a73c <fwp_write+0xf5c>
    a77d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a784:	4e 61 4e 00 
    a788:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a78f:	00 
    a790:	e9 cb f0 ff ff       	jmp    9860 <fwp_write+0x80>
    a795:	44 89 0c 24          	mov    %r9d,(%rsp)
    a799:	48 89 c8             	mov    %rcx,%rax
    a79c:	48 85 d2             	test   %rdx,%rdx
    a79f:	78 51                	js     a7f2 <fwp_write+0x1012>
    a7a1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a7a6:	48 89 c6             	mov    %rax,%rsi
    a7a9:	48 89 ef             	mov    %rbp,%rdi
    a7ac:	e8 8f 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a7b1:	44 8b 0c 24          	mov    (%rsp),%r9d
    a7b5:	49 63 c1             	movslq %r9d,%rax
    a7b8:	49 89 e8             	mov    %rbp,%r8
    a7bb:	ba 00 02 00 00       	mov    $0x200,%edx
    a7c0:	be 02 00 00 00       	mov    $0x2,%esi
    a7c5:	48 c1 e0 04          	shl    $0x4,%rax
    a7c9:	48 8d 3d 30 6c 00 00 	lea    0x6c30(%rip),%rdi        # 11400 <units.1>
    a7d0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a7d7:	00 
    a7d8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a7dc:	48 8d 0d 52 4a 00 00 	lea    0x4a52(%rip),%rcx        # f235 <_IO_stdin_used+0x235>
    a7e3:	4c 89 e7             	mov    %r12,%rdi
    a7e6:	31 c0                	xor    %eax,%eax
    a7e8:	e8 f3 8e ff ff       	call   36e0 <__sprintf_chk@plt>
    a7ed:	e9 6e f0 ff ff       	jmp    9860 <fwp_write+0x80>
    a7f2:	48 f7 d8             	neg    %rax
    a7f5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a7fa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a7ff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a804:	48 83 d2 00          	adc    $0x0,%rdx
    a808:	48 89 c6             	mov    %rax,%rsi
    a80b:	48 f7 da             	neg    %rdx
    a80e:	e8 2d 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a813:	44 8b 0c 24          	mov    (%rsp),%r9d
    a817:	eb 9c                	jmp    a7b5 <fwp_write+0xfd5>
    a819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a820 <fwp_hof0.constprop.0>:
    a820:	55                   	push   %rbp
    a821:	48 89 e5             	mov    %rsp,%rbp
    a824:	41 57                	push   %r15
    a826:	41 56                	push   %r14
    a828:	41 55                	push   %r13
    a82a:	41 54                	push   %r12
    a82c:	53                   	push   %rbx
    a82d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a834:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a83b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a842:	00 00 
    a844:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a848:	31 c0                	xor    %eax,%eax
    a84a:	48 85 f6             	test   %rsi,%rsi
    a84d:	0f 84 86 06 00 00    	je     aed9 <fwp_hof0.constprop.0+0x6b9>
    a853:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a857:	49 89 f7             	mov    %rsi,%r15
    a85a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a861:	48 8d 35 78 8f 01 00 	lea    0x18f78(%rip),%rsi        # 237e0 <fwp_heap>
    a868:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a86f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a876:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a87d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a881:	48 c1 e2 10          	shl    $0x10,%rdx
    a885:	48 39 d0             	cmp    %rdx,%rax
    a888:	73 5d                	jae    a8e7 <fwp_hof0.constprop.0+0xc7>
    a88a:	48 89 c2             	mov    %rax,%rdx
    a88d:	48 c1 ea 10          	shr    $0x10,%rdx
    a891:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a895:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a89c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a8a0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a8a4:	48 85 ff             	test   %rdi,%rdi
    a8a7:	74 3e                	je     a8e7 <fwp_hof0.constprop.0+0xc7>
    a8a9:	0f b6 0a             	movzbl (%rdx),%ecx
    a8ac:	80 f9 02             	cmp    $0x2,%cl
    a8af:	0f 84 cd 0a 00 00    	je     b382 <fwp_hof0.constprop.0+0xb62>
    a8b5:	80 f9 01             	cmp    $0x1,%cl
    a8b8:	75 2d                	jne    a8e7 <fwp_hof0.constprop.0+0xc7>
    a8ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a8bd:	0f b7 c0             	movzwl %ax,%eax
    a8c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a8c3:	48 0f af c1          	imul   %rcx,%rax
    a8c7:	48 c1 e8 20          	shr    $0x20,%rax
    a8cb:	48 39 d0             	cmp    %rdx,%rax
    a8ce:	73 17                	jae    a8e7 <fwp_hof0.constprop.0+0xc7>
    a8d0:	48 01 c7             	add    %rax,%rdi
    a8d3:	0f b6 07             	movzbl (%rdi),%eax
    a8d6:	84 c0                	test   %al,%al
    a8d8:	74 0d                	je     a8e7 <fwp_hof0.constprop.0+0xc7>
    a8da:	3c fd                	cmp    $0xfd,%al
    a8dc:	0f 87 7e 0b 00 00    	ja     b460 <fwp_hof0.constprop.0+0xc40>
    a8e2:	83 c0 01             	add    $0x1,%eax
    a8e5:	88 07                	mov    %al,(%rdi)
    a8e7:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a8ee:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a8f5:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a8fc:	c7 00 00 00 
    a900:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a904:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a908:	48 8b 15 29 ab 01 00 	mov    0x1ab29(%rip),%rdx        # 25438 <fwp_fns>
    a90f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a913:	48 8d 05 fe 86 00 00 	lea    0x86fe(%rip),%rax        # 13018 <fc12>
    a91a:	44 8b 20             	mov    (%rax),%r12d
    a91d:	49 c1 e4 05          	shl    $0x5,%r12
    a921:	49 01 d4             	add    %rdx,%r12
    a924:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a929:	48 85 c9             	test   %rcx,%rcx
    a92c:	0f 84 1d 0a 00 00    	je     b34f <fwp_hof0.constprop.0+0xb2f>
    a932:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a937:	0f 84 7b 08 00 00    	je     b1b8 <fwp_hof0.constprop.0+0x998>
    a93d:	48 8d 3d 9c 8e 01 00 	lea    0x18e9c(%rip),%rdi        # 237e0 <fwp_heap>
    a944:	48 8d 05 cd 86 00 00 	lea    0x86cd(%rip),%rax        # 13018 <fc12>
    a94b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a952:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a959:	48 89 f1             	mov    %rsi,%rcx
    a95c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a960:	48 c1 e1 10          	shl    $0x10,%rcx
    a964:	48 39 c8             	cmp    %rcx,%rax
    a967:	73 5f                	jae    a9c8 <fwp_hof0.constprop.0+0x1a8>
    a969:	48 89 c1             	mov    %rax,%rcx
    a96c:	48 c1 e9 10          	shr    $0x10,%rcx
    a970:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a974:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a97b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a97f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a983:	48 85 ff             	test   %rdi,%rdi
    a986:	74 40                	je     a9c8 <fwp_hof0.constprop.0+0x1a8>
    a988:	0f b6 31             	movzbl (%rcx),%esi
    a98b:	40 80 fe 02          	cmp    $0x2,%sil
    a98f:	0f 84 08 09 00 00    	je     b29d <fwp_hof0.constprop.0+0xa7d>
    a995:	40 80 fe 01          	cmp    $0x1,%sil
    a999:	75 2d                	jne    a9c8 <fwp_hof0.constprop.0+0x1a8>
    a99b:	8b 71 18             	mov    0x18(%rcx),%esi
    a99e:	0f b7 c0             	movzwl %ax,%eax
    a9a1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a9a4:	48 0f af c6          	imul   %rsi,%rax
    a9a8:	48 c1 e8 20          	shr    $0x20,%rax
    a9ac:	48 39 c8             	cmp    %rcx,%rax
    a9af:	73 17                	jae    a9c8 <fwp_hof0.constprop.0+0x1a8>
    a9b1:	48 01 c7             	add    %rax,%rdi
    a9b4:	0f b6 07             	movzbl (%rdi),%eax
    a9b7:	84 c0                	test   %al,%al
    a9b9:	74 0d                	je     a9c8 <fwp_hof0.constprop.0+0x1a8>
    a9bb:	3c fd                	cmp    $0xfd,%al
    a9bd:	0f 87 66 09 00 00    	ja     b329 <fwp_hof0.constprop.0+0xb09>
    a9c3:	83 c0 01             	add    $0x1,%eax
    a9c6:	88 07                	mov    %al,(%rdi)
    a9c8:	48 8d 05 49 86 00 00 	lea    0x8649(%rip),%rax        # 13018 <fc12>
    a9cf:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    a9d6:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a9da:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    a9e1:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    a9e5:	48 8d 05 2c 86 00 00 	lea    0x862c(%rip),%rax        # 13018 <fc12>
    a9ec:	41 8b 0c 24          	mov    (%r12),%ecx
    a9f0:	2b 48 04             	sub    0x4(%rax),%ecx
    a9f3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a9f7:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    a9fb:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    a9fe:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aa02:	49 89 c1             	mov    %rax,%r9
    aa05:	8b 00                	mov    (%rax),%eax
    aa07:	44 39 e9             	cmp    %r13d,%ecx
    aa0a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    aa0e:	4d 89 cf             	mov    %r9,%r15
    aa11:	48 c1 e0 05          	shl    $0x5,%rax
    aa15:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    aa19:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    aa20:	4d 8b 50 18          	mov    0x18(%r8),%r10
    aa24:	4d 85 d2             	test   %r10,%r10
    aa27:	75 58                	jne    aa81 <fwp_hof0.constprop.0+0x261>
    aa29:	e9 f5 01 00 00       	jmp    ac23 <fwp_hof0.constprop.0+0x403>
    aa2e:	66 90                	xchg   %ax,%ax
    aa30:	45 85 ff             	test   %r15d,%r15d
    aa33:	74 69                	je     aa9e <fwp_hof0.constprop.0+0x27e>
    aa35:	4c 89 e7             	mov    %r12,%rdi
    aa38:	41 ff 12             	call   *(%r10)
    aa3b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa3f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    aa43:	e8 e8 c2 ff ff       	call   6d30 <fwp_closure_drop>
    aa48:	44 39 eb             	cmp    %r13d,%ebx
    aa4b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    aa4f:	0f 84 53 07 00 00    	je     b1a8 <fwp_hof0.constprop.0+0x988>
    aa55:	44 8b 00             	mov    (%rax),%r8d
    aa58:	45 29 fe             	sub    %r15d,%r14d
    aa5b:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    aa5f:	49 89 c1             	mov    %rax,%r9
    aa62:	45 89 f5             	mov    %r14d,%r13d
    aa65:	49 c1 e0 05          	shl    $0x5,%r8
    aa69:	4c 03 05 c8 a9 01 00 	add    0x1a9c8(%rip),%r8        # 25438 <fwp_fns>
    aa70:	4d 8b 50 18          	mov    0x18(%r8),%r10
    aa74:	4d 85 d2             	test   %r10,%r10
    aa77:	0f 84 a3 01 00 00    	je     ac20 <fwp_hof0.constprop.0+0x400>
    aa7d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa81:	41 8b 49 04          	mov    0x4(%r9),%ecx
    aa85:	45 8b 38             	mov    (%r8),%r15d
    aa88:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    aa8c:	45 39 fe             	cmp    %r15d,%r14d
    aa8f:	0f 82 6b 04 00 00    	jb     af00 <fwp_hof0.constprop.0+0x6e0>
    aa95:	44 89 fb             	mov    %r15d,%ebx
    aa98:	29 cb                	sub    %ecx,%ebx
    aa9a:	85 c9                	test   %ecx,%ecx
    aa9c:	74 92                	je     aa30 <fwp_hof0.constprop.0+0x210>
    aa9e:	45 85 ff             	test   %r15d,%r15d
    aaa1:	b8 01 00 00 00       	mov    $0x1,%eax
    aaa6:	48 89 e6             	mov    %rsp,%rsi
    aaa9:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    aaad:	41 0f 45 c7          	cmovne %r15d,%eax
    aab1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    aab8:	00 
    aab9:	48 c1 e8 04          	shr    $0x4,%rax
    aabd:	48 c1 e0 04          	shl    $0x4,%rax
    aac1:	48 89 c7             	mov    %rax,%rdi
    aac4:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    aacb:	48 29 fe             	sub    %rdi,%rsi
    aace:	48 39 f4             	cmp    %rsi,%rsp
    aad1:	74 15                	je     aae8 <fwp_hof0.constprop.0+0x2c8>
    aad3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    aada:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    aae1:	00 00 
    aae3:	48 39 f4             	cmp    %rsi,%rsp
    aae6:	75 eb                	jne    aad3 <fwp_hof0.constprop.0+0x2b3>
    aae8:	25 ff 0f 00 00       	and    $0xfff,%eax
    aaed:	48 29 c4             	sub    %rax,%rsp
    aaf0:	48 85 c0             	test   %rax,%rax
    aaf3:	74 06                	je     aafb <fwp_hof0.constprop.0+0x2db>
    aaf5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    aafb:	89 cf                	mov    %ecx,%edi
    aafd:	49 89 e3             	mov    %rsp,%r11
    ab00:	31 c0                	xor    %eax,%eax
    ab02:	48 c1 e7 03          	shl    $0x3,%rdi
    ab06:	85 c9                	test   %ecx,%ecx
    ab08:	74 28                	je     ab32 <fwp_hof0.constprop.0+0x312>
    ab0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab11:	00 00 00 00 
    ab15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab1c:	00 00 00 00 
    ab20:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    ab25:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    ab29:	48 83 c0 08          	add    $0x8,%rax
    ab2d:	48 39 c7             	cmp    %rax,%rdi
    ab30:	75 ee                	jne    ab20 <fwp_hof0.constprop.0+0x300>
    ab32:	85 db                	test   %ebx,%ebx
    ab34:	74 1f                	je     ab55 <fwp_hof0.constprop.0+0x335>
    ab36:	89 de                	mov    %ebx,%esi
    ab38:	4c 89 e0             	mov    %r12,%rax
    ab3b:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    ab3f:	90                   	nop
    ab40:	48 8b 30             	mov    (%rax),%rsi
    ab43:	89 ca                	mov    %ecx,%edx
    ab45:	48 83 c0 08          	add    $0x8,%rax
    ab49:	83 c1 01             	add    $0x1,%ecx
    ab4c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    ab50:	48 39 c7             	cmp    %rax,%rdi
    ab53:	75 eb                	jne    ab40 <fwp_hof0.constprop.0+0x320>
    ab55:	48 8d 15 84 8c 01 00 	lea    0x18c84(%rip),%rdx        # 237e0 <fwp_heap>
    ab5c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ab60:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    ab67:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    ab6e:	48 89 f1             	mov    %rsi,%rcx
    ab71:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    ab75:	48 c1 e1 10          	shl    $0x10,%rcx
    ab79:	48 39 c8             	cmp    %rcx,%rax
    ab7c:	73 4c                	jae    abca <fwp_hof0.constprop.0+0x3aa>
    ab7e:	48 89 c1             	mov    %rax,%rcx
    ab81:	48 c1 e9 10          	shr    $0x10,%rcx
    ab85:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ab89:	48 8b 0d 48 a0 01 00 	mov    0x1a048(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    ab90:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ab94:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    ab98:	48 85 f6             	test   %rsi,%rsi
    ab9b:	74 2d                	je     abca <fwp_hof0.constprop.0+0x3aa>
    ab9d:	0f b6 39             	movzbl (%rcx),%edi
    aba0:	40 80 ff 02          	cmp    $0x2,%dil
    aba4:	74 6a                	je     ac10 <fwp_hof0.constprop.0+0x3f0>
    aba6:	40 80 ff 01          	cmp    $0x1,%dil
    abaa:	75 1e                	jne    abca <fwp_hof0.constprop.0+0x3aa>
    abac:	8b 79 18             	mov    0x18(%rcx),%edi
    abaf:	0f b7 c0             	movzwl %ax,%eax
    abb2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abb5:	48 0f af c7          	imul   %rdi,%rax
    abb9:	48 c1 e8 20          	shr    $0x20,%rax
    abbd:	48 39 c8             	cmp    %rcx,%rax
    abc0:	73 08                	jae    abca <fwp_hof0.constprop.0+0x3aa>
    abc2:	48 01 c6             	add    %rax,%rsi
    abc5:	80 3e 01             	cmpb   $0x1,(%rsi)
    abc8:	74 36                	je     ac00 <fwp_hof0.constprop.0+0x3e0>
    abca:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    abce:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    abd2:	be 01 00 00 00       	mov    $0x1,%esi
    abd7:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    abdb:	41 ff 52 08          	call   *0x8(%r10)
    abdf:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    abe3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    abe7:	49 8b 40 18          	mov    0x18(%r8),%rax
    abeb:	4c 89 df             	mov    %r11,%rdi
    abee:	ff 10                	call   *(%rax)
    abf0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    abf4:	e9 42 fe ff ff       	jmp    aa3b <fwp_hof0.constprop.0+0x21b>
    abf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac00:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ac07:	00 
    ac08:	eb dd                	jmp    abe7 <fwp_hof0.constprop.0+0x3c7>
    ac0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac10:	66 85 c0             	test   %ax,%ax
    ac13:	75 b5                	jne    abca <fwp_hof0.constprop.0+0x3aa>
    ac15:	eb ae                	jmp    abc5 <fwp_hof0.constprop.0+0x3a5>
    ac17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac1e:	00 00 
    ac20:	49 89 c7             	mov    %rax,%r15
    ac23:	4c 89 ff             	mov    %r15,%rdi
    ac26:	e8 e5 b9 ff ff       	call   6610 <fwp_rc_share>
    ac2b:	45 85 ed             	test   %r13d,%r13d
    ac2e:	74 21                	je     ac51 <fwp_hof0.constprop.0+0x431>
    ac30:	44 89 ea             	mov    %r13d,%edx
    ac33:	4c 89 e3             	mov    %r12,%rbx
    ac36:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    ac3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac40:	48 8b 3b             	mov    (%rbx),%rdi
    ac43:	48 83 c3 08          	add    $0x8,%rbx
    ac47:	e8 c4 b9 ff ff       	call   6610 <fwp_rc_share>
    ac4c:	4c 39 f3             	cmp    %r14,%rbx
    ac4f:	75 ef                	jne    ac40 <fwp_hof0.constprop.0+0x420>
    ac51:	4c 89 e2             	mov    %r12,%rdx
    ac54:	44 89 ee             	mov    %r13d,%esi
    ac57:	4c 89 ff             	mov    %r15,%rdi
    ac5a:	e8 51 b1 ff ff       	call   5db0 <fwp_apply>
    ac5f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ac63:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ac66:	39 75 90             	cmp    %esi,-0x70(%rbp)
    ac69:	0f 83 87 00 00 00    	jae    acf6 <fwp_hof0.constprop.0+0x4d6>
    ac6f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    ac75:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    ac79:	48 89 c2             	mov    %rax,%rdx
    ac7c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    ac80:	29 d6                	sub    %edx,%esi
    ac82:	48 8b 15 af a7 01 00 	mov    0x1a7af(%rip),%rdx        # 25438 <fwp_fns>
    ac89:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ac8d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    ac90:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ac94:	44 8b 26             	mov    (%rsi),%r12d
    ac97:	48 89 f0             	mov    %rsi,%rax
    ac9a:	49 c1 e4 05          	shl    $0x5,%r12
    ac9e:	49 01 d4             	add    %rdx,%r12
    aca1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    aca7:	0f 85 3f fd ff ff    	jne    a9ec <fwp_hof0.constprop.0+0x1cc>
    acad:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    acb1:	e8 5a b9 ff ff       	call   6610 <fwp_rc_share>
    acb6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    acba:	45 85 f6             	test   %r14d,%r14d
    acbd:	74 23                	je     ace2 <fwp_hof0.constprop.0+0x4c2>
    acbf:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    acc3:	31 db                	xor    %ebx,%ebx
    acc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    accc:	00 00 00 00 
    acd0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    acd4:	48 83 c3 01          	add    $0x1,%rbx
    acd8:	e8 33 b9 ff ff       	call   6610 <fwp_rc_share>
    acdd:	44 39 f3             	cmp    %r14d,%ebx
    ace0:	72 ee                	jb     acd0 <fwp_hof0.constprop.0+0x4b0>
    ace2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    ace6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ace9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aced:	e8 be b0 ff ff       	call   5db0 <fwp_apply>
    acf2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    acf6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    acfd:	01 
    acfe:	0f 85 00 fc ff ff    	jne    a904 <fwp_hof0.constprop.0+0xe4>
    ad04:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ad08:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ad0f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad13:	b9 01 00 00 00       	mov    $0x1,%ecx
    ad18:	48 8d 15 61 7e 00 00 	lea    0x7e61(%rip),%rdx        # 12b80 <d0>
    ad1f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    ad26:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    ad2d:	00 
    ad2e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    ad32:	e8 a9 ea ff ff       	call   97e0 <fwp_write>
    ad37:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    ad3b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    ad3f:	48 8d 05 4b 43 00 00 	lea    0x434b(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    ad46:	48 85 c9             	test   %rcx,%rcx
    ad49:	48 0f 44 c8          	cmove  %rax,%rcx
    ad4d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    ad51:	0f 87 f5 06 00 00    	ja     b44c <fwp_hof0.constprop.0+0xc2c>
    ad57:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    ad5b:	be 01 00 00 00       	mov    $0x1,%esi
    ad60:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    ad64:	e8 27 af ff ff       	call   5c90 <fwp_heap_alloc>
    ad69:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    ad6d:	4c 89 f2             	mov    %r14,%rdx
    ad70:	4c 89 30             	mov    %r14,(%rax)
    ad73:	4c 8d 60 08          	lea    0x8(%rax),%r12
    ad77:	48 89 c3             	mov    %rax,%rbx
    ad7a:	4c 89 e7             	mov    %r12,%rdi
    ad7d:	e8 1e 88 ff ff       	call   35a0 <memcpy@plt>
    ad82:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ad88:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ad8c:	e8 2f 86 ff ff       	call   33c0 <free@plt>
    ad91:	48 8d 35 48 8a 01 00 	lea    0x18a48(%rip),%rsi        # 237e0 <fwp_heap>
    ad98:	48 89 d8             	mov    %rbx,%rax
    ad9b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ada2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ada9:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    adad:	48 c1 e2 10          	shl    $0x10,%rdx
    adb1:	48 39 d0             	cmp    %rdx,%rax
    adb4:	73 57                	jae    ae0d <fwp_hof0.constprop.0+0x5ed>
    adb6:	48 89 c2             	mov    %rax,%rdx
    adb9:	48 c1 ea 10          	shr    $0x10,%rdx
    adbd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adc1:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    adc8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adcc:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    add0:	4d 85 f6             	test   %r14,%r14
    add3:	74 38                	je     ae0d <fwp_hof0.constprop.0+0x5ed>
    add5:	0f b6 0a             	movzbl (%rdx),%ecx
    add8:	80 f9 02             	cmp    $0x2,%cl
    addb:	0f 84 c9 05 00 00    	je     b3aa <fwp_hof0.constprop.0+0xb8a>
    ade1:	80 f9 01             	cmp    $0x1,%cl
    ade4:	75 27                	jne    ae0d <fwp_hof0.constprop.0+0x5ed>
    ade6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ade9:	0f b7 c0             	movzwl %ax,%eax
    adec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    adef:	48 0f af c1          	imul   %rcx,%rax
    adf3:	48 c1 e8 20          	shr    $0x20,%rax
    adf7:	48 39 d0             	cmp    %rdx,%rax
    adfa:	73 11                	jae    ae0d <fwp_hof0.constprop.0+0x5ed>
    adfc:	49 01 c6             	add    %rax,%r14
    adff:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ae03:	0f 84 67 06 00 00    	je     b470 <fwp_hof0.constprop.0+0xc50>
    ae09:	41 c6 06 01          	movb   $0x1,(%r14)
    ae0d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ae11:	e8 3a bc ff ff       	call   6a50 <fwp_drop0>
    ae16:	48 8b 13             	mov    (%rbx),%rdx
    ae19:	be 01 00 00 00       	mov    $0x1,%esi
    ae1e:	4c 89 e7             	mov    %r12,%rdi
    ae21:	48 8b 0d 18 a6 01 00 	mov    0x1a618(%rip),%rcx        # 25440 <fwp_prog_out>
    ae28:	e8 53 88 ff ff       	call   3680 <fwrite@plt>
    ae2d:	48 8b 35 0c a6 01 00 	mov    0x1a60c(%rip),%rsi        # 25440 <fwp_prog_out>
    ae34:	bf 0a 00 00 00       	mov    $0xa,%edi
    ae39:	e8 a2 86 ff ff       	call   34e0 <fputc@plt>
    ae3e:	48 8d 35 9b 89 01 00 	lea    0x1899b(%rip),%rsi        # 237e0 <fwp_heap>
    ae45:	48 89 d8             	mov    %rbx,%rax
    ae48:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ae4f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae56:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    ae5a:	48 c1 e2 10          	shl    $0x10,%rdx
    ae5e:	48 39 d0             	cmp    %rdx,%rax
    ae61:	73 69                	jae    aecc <fwp_hof0.constprop.0+0x6ac>
    ae63:	48 89 c2             	mov    %rax,%rdx
    ae66:	48 c1 ea 10          	shr    $0x10,%rdx
    ae6a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae6e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ae75:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae79:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae7d:	4d 85 e4             	test   %r12,%r12
    ae80:	74 4a                	je     aecc <fwp_hof0.constprop.0+0x6ac>
    ae82:	0f b6 0a             	movzbl (%rdx),%ecx
    ae85:	80 f9 02             	cmp    $0x2,%cl
    ae88:	0f 84 2a 05 00 00    	je     b3b8 <fwp_hof0.constprop.0+0xb98>
    ae8e:	80 f9 01             	cmp    $0x1,%cl
    ae91:	75 39                	jne    aecc <fwp_hof0.constprop.0+0x6ac>
    ae93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae96:	0f b7 c0             	movzwl %ax,%eax
    ae99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae9c:	48 0f af c1          	imul   %rcx,%rax
    aea0:	48 c1 e8 20          	shr    $0x20,%rax
    aea4:	48 39 d0             	cmp    %rdx,%rax
    aea7:	73 23                	jae    aecc <fwp_hof0.constprop.0+0x6ac>
    aea9:	49 01 c4             	add    %rax,%r12
    aeac:	41 0f b6 04 24       	movzbl (%r12),%eax
    aeb1:	84 c0                	test   %al,%al
    aeb3:	74 17                	je     aecc <fwp_hof0.constprop.0+0x6ac>
    aeb5:	3c 01                	cmp    $0x1,%al
    aeb7:	0f 84 d3 04 00 00    	je     b390 <fwp_hof0.constprop.0+0xb70>
    aebd:	3c ff                	cmp    $0xff,%al
    aebf:	0f 84 01 05 00 00    	je     b3c6 <fwp_hof0.constprop.0+0xba6>
    aec5:	83 e8 01             	sub    $0x1,%eax
    aec8:	41 88 04 24          	mov    %al,(%r12)
    aecc:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    aed0:	4d 85 ff             	test   %r15,%r15
    aed3:	0f 85 88 f9 ff ff    	jne    a861 <fwp_hof0.constprop.0+0x41>
    aed9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    aedd:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aee4:	00 00 
    aee6:	0f 85 7e 05 00 00    	jne    b46a <fwp_hof0.constprop.0+0xc4a>
    aeec:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    aef0:	31 c0                	xor    %eax,%eax
    aef2:	5b                   	pop    %rbx
    aef3:	41 5c                	pop    %r12
    aef5:	41 5d                	pop    %r13
    aef7:	41 5e                	pop    %r14
    aef9:	41 5f                	pop    %r15
    aefb:	5d                   	pop    %rbp
    aefc:	c3                   	ret
    aefd:	0f 1f 00             	nopl   (%rax)
    af00:	48 8d 1d d9 88 01 00 	lea    0x188d9(%rip),%rbx        # 237e0 <fwp_heap>
    af07:	41 8d 76 01          	lea    0x1(%r14),%esi
    af0b:	45 89 f7             	mov    %r14d,%r15d
    af0e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    af14:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    af1b:	00 
    af1c:	85 c0                	test   %eax,%eax
    af1e:	0f 84 a9 03 00 00    	je     b2cd <fwp_hof0.constprop.0+0xaad>
    af24:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    af2b:	0f 87 9c 03 00 00    	ja     b2cd <fwp_hof0.constprop.0+0xaad>
    af31:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    af35:	48 c1 e8 04          	shr    $0x4,%rax
    af39:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    af40:	00 
    af41:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    af48:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    af4c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    af50:	4c 8b 12             	mov    (%rdx),%r10
    af53:	4d 85 d2             	test   %r10,%r10
    af56:	0f 84 4f 03 00 00    	je     b2ab <fwp_hof0.constprop.0+0xa8b>
    af5c:	4d 8b 1a             	mov    (%r10),%r11
    af5f:	49 f7 d3             	not    %r11
    af62:	4c 89 1a             	mov    %r11,(%rdx)
    af65:	48 39 c7             	cmp    %rax,%rdi
    af68:	73 50                	jae    afba <fwp_hof0.constprop.0+0x79a>
    af6a:	48 89 fa             	mov    %rdi,%rdx
    af6d:	48 83 c7 08          	add    $0x8,%rdi
    af71:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    af78:	00 
    af79:	48 f7 d2             	not    %rdx
    af7c:	48 01 c2             	add    %rax,%rdx
    af7f:	48 c1 ea 03          	shr    $0x3,%rdx
    af83:	48 39 c7             	cmp    %rax,%rdi
    af86:	73 32                	jae    afba <fwp_hof0.constprop.0+0x79a>
    af88:	83 e2 01             	and    $0x1,%edx
    af8b:	74 13                	je     afa0 <fwp_hof0.constprop.0+0x780>
    af8d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    af94:	00 
    af95:	48 83 c7 08          	add    $0x8,%rdi
    af99:	48 39 c7             	cmp    %rax,%rdi
    af9c:	73 1c                	jae    afba <fwp_hof0.constprop.0+0x79a>
    af9e:	66 90                	xchg   %ax,%ax
    afa0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    afa7:	00 
    afa8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    afaf:	00 00 
    afb1:	48 83 c7 10          	add    $0x10,%rdi
    afb5:	48 39 c7             	cmp    %rax,%rdi
    afb8:	72 e6                	jb     afa0 <fwp_hof0.constprop.0+0x780>
    afba:	48 8d 35 1f 88 01 00 	lea    0x1881f(%rip),%rsi        # 237e0 <fwp_heap>
    afc1:	48 89 c2             	mov    %rax,%rdx
    afc4:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    afcb:	0f 82 6a 04 00 00    	jb     b43b <fwp_hof0.constprop.0+0xc1b>
    afd1:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    afd8:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    afdf:	73 07                	jae    afe8 <fwp_hof0.constprop.0+0x7c8>
    afe1:	48 89 15 20 9c 01 00 	mov    %rdx,0x19c20(%rip)        # 24c08 <fwp_heap+0x1428>
    afe8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    afec:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    aff1:	f2 0f 58 05 1f 9c 01 	addsd  0x19c1f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    aff8:	00 
    aff9:	f2 0f 11 05 17 9c 01 	movsd  %xmm0,0x19c17(%rip)        # 24c18 <fwp_heap+0x1438>
    b000:	00 
    b001:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b006:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b00b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b00f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b014:	85 c9                	test   %ecx,%ecx
    b016:	74 37                	je     b04f <fwp_hof0.constprop.0+0x82f>
    b018:	89 ca                	mov    %ecx,%edx
    b01a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b01e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b022:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b025:	48 c1 e2 03          	shl    $0x3,%rdx
    b029:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b030:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b034:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b038:	e8 d3 85 ff ff       	call   3610 <memmove@plt>
    b03d:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b041:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b045:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b048:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b04f:	45 85 ed             	test   %r13d,%r13d
    b052:	74 23                	je     b077 <fwp_hof0.constprop.0+0x857>
    b054:	45 89 ed             	mov    %r13d,%r13d
    b057:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b05b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b060:	49 8b 14 24          	mov    (%r12),%rdx
    b064:	89 c8                	mov    %ecx,%eax
    b066:	49 83 c4 08          	add    $0x8,%r12
    b06a:	83 c1 01             	add    $0x1,%ecx
    b06d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b072:	4c 39 e6             	cmp    %r12,%rsi
    b075:	75 e9                	jne    b060 <fwp_hof0.constprop.0+0x840>
    b077:	48 8d 35 62 87 01 00 	lea    0x18762(%rip),%rsi        # 237e0 <fwp_heap>
    b07e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b082:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b089:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b090:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b094:	48 c1 e2 10          	shl    $0x10,%rdx
    b098:	48 39 d0             	cmp    %rdx,%rax
    b09b:	73 54                	jae    b0f1 <fwp_hof0.constprop.0+0x8d1>
    b09d:	48 89 c2             	mov    %rax,%rdx
    b0a0:	48 c1 ea 10          	shr    $0x10,%rdx
    b0a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0a8:	48 8b 15 29 9b 01 00 	mov    0x19b29(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b0af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0b3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b0b7:	48 85 c9             	test   %rcx,%rcx
    b0ba:	74 35                	je     b0f1 <fwp_hof0.constprop.0+0x8d1>
    b0bc:	0f b6 32             	movzbl (%rdx),%esi
    b0bf:	40 80 fe 02          	cmp    $0x2,%sil
    b0c3:	0f 84 52 02 00 00    	je     b31b <fwp_hof0.constprop.0+0xafb>
    b0c9:	40 80 fe 01          	cmp    $0x1,%sil
    b0cd:	75 22                	jne    b0f1 <fwp_hof0.constprop.0+0x8d1>
    b0cf:	8b 72 18             	mov    0x18(%rdx),%esi
    b0d2:	0f b7 c0             	movzwl %ax,%eax
    b0d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0d8:	48 0f af c6          	imul   %rsi,%rax
    b0dc:	48 c1 e8 20          	shr    $0x20,%rax
    b0e0:	48 39 d0             	cmp    %rdx,%rax
    b0e3:	73 0c                	jae    b0f1 <fwp_hof0.constprop.0+0x8d1>
    b0e5:	48 01 c1             	add    %rax,%rcx
    b0e8:	80 39 01             	cmpb   $0x1,(%rcx)
    b0eb:	0f 84 9f 01 00 00    	je     b290 <fwp_hof0.constprop.0+0xa70>
    b0f1:	49 8b 40 18          	mov    0x18(%r8),%rax
    b0f5:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b0f9:	be 01 00 00 00       	mov    $0x1,%esi
    b0fe:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b102:	ff 50 08             	call   *0x8(%rax)
    b105:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b109:	48 8d 35 d0 86 01 00 	lea    0x186d0(%rip),%rsi        # 237e0 <fwp_heap>
    b110:	4c 89 d0             	mov    %r10,%rax
    b113:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b11a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b121:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b125:	48 c1 e2 10          	shl    $0x10,%rdx
    b129:	48 39 d0             	cmp    %rdx,%rax
    b12c:	73 59                	jae    b187 <fwp_hof0.constprop.0+0x967>
    b12e:	48 89 c2             	mov    %rax,%rdx
    b131:	48 c1 ea 10          	shr    $0x10,%rdx
    b135:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b139:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b140:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b144:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b148:	4d 85 e4             	test   %r12,%r12
    b14b:	74 3a                	je     b187 <fwp_hof0.constprop.0+0x967>
    b14d:	0f b6 0a             	movzbl (%rdx),%ecx
    b150:	80 f9 02             	cmp    $0x2,%cl
    b153:	0f 84 99 01 00 00    	je     b2f2 <fwp_hof0.constprop.0+0xad2>
    b159:	80 f9 01             	cmp    $0x1,%cl
    b15c:	75 29                	jne    b187 <fwp_hof0.constprop.0+0x967>
    b15e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b161:	0f b7 c0             	movzwl %ax,%eax
    b164:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b167:	48 0f af c1          	imul   %rcx,%rax
    b16b:	48 c1 e8 20          	shr    $0x20,%rax
    b16f:	48 39 d0             	cmp    %rdx,%rax
    b172:	73 13                	jae    b187 <fwp_hof0.constprop.0+0x967>
    b174:	49 01 c4             	add    %rax,%r12
    b177:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b17c:	0f 84 84 01 00 00    	je     b306 <fwp_hof0.constprop.0+0xae6>
    b182:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b187:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b18b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b18f:	e8 9c bb ff ff       	call   6d30 <fwp_closure_drop>
    b194:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b198:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b19c:	e9 c2 fa ff ff       	jmp    ac63 <fwp_hof0.constprop.0+0x443>
    b1a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1a8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b1ac:	e9 b2 fa ff ff       	jmp    ac63 <fwp_hof0.constprop.0+0x443>
    b1b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1b8:	41 8b 34 24          	mov    (%r12),%esi
    b1bc:	8b 05 5a 7e 00 00    	mov    0x7e5a(%rip),%eax        # 1301c <fc12+0x4>
    b1c2:	89 f7                	mov    %esi,%edi
    b1c4:	29 c7                	sub    %eax,%edi
    b1c6:	83 ff 01             	cmp    $0x1,%edi
    b1c9:	0f 85 6e f7 ff ff    	jne    a93d <fwp_hof0.constprop.0+0x11d>
    b1cf:	48 89 e3             	mov    %rsp,%rbx
    b1d2:	85 c0                	test   %eax,%eax
    b1d4:	0f 84 60 01 00 00    	je     b33a <fwp_hof0.constprop.0+0xb1a>
    b1da:	89 f1                	mov    %esi,%ecx
    b1dc:	ba 08 00 00 00       	mov    $0x8,%edx
    b1e1:	48 c1 e1 03          	shl    $0x3,%rcx
    b1e5:	85 f6                	test   %esi,%esi
    b1e7:	48 89 e6             	mov    %rsp,%rsi
    b1ea:	48 0f 45 d1          	cmovne %rcx,%rdx
    b1ee:	49 89 d7             	mov    %rdx,%r15
    b1f1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b1f5:	48 c1 ea 04          	shr    $0x4,%rdx
    b1f9:	48 c1 e2 04          	shl    $0x4,%rdx
    b1fd:	48 89 d7             	mov    %rdx,%rdi
    b200:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b207:	48 29 fe             	sub    %rdi,%rsi
    b20a:	48 39 f4             	cmp    %rsi,%rsp
    b20d:	74 15                	je     b224 <fwp_hof0.constprop.0+0xa04>
    b20f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b216:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b21d:	00 00 
    b21f:	48 39 f4             	cmp    %rsi,%rsp
    b222:	75 eb                	jne    b20f <fwp_hof0.constprop.0+0x9ef>
    b224:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b22a:	48 29 d4             	sub    %rdx,%rsp
    b22d:	48 85 d2             	test   %rdx,%rdx
    b230:	74 06                	je     b238 <fwp_hof0.constprop.0+0xa18>
    b232:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b238:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b23f:	00 
    b240:	4c 89 f9             	mov    %r15,%rcx
    b243:	48 8d 35 d6 7d 00 00 	lea    0x7dd6(%rip),%rsi        # 13020 <descent_active_phase>
    b24a:	48 89 e7             	mov    %rsp,%rdi
    b24d:	4c 89 f2             	mov    %r14,%rdx
    b250:	e8 1b 83 ff ff       	call   3570 <__memcpy_chk@plt>
    b255:	4d 39 f7             	cmp    %r14,%r15
    b258:	4c 89 f9             	mov    %r15,%rcx
    b25b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b25f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b263:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b26a:	ba 08 00 00 00       	mov    $0x8,%edx
    b26f:	4c 29 f1             	sub    %r14,%rcx
    b272:	e8 f9 82 ff ff       	call   3570 <__memcpy_chk@plt>
    b277:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b27c:	48 89 e7             	mov    %rsp,%rdi
    b27f:	ff 10                	call   *(%rax)
    b281:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b285:	e9 bd 00 00 00       	jmp    b347 <fwp_hof0.constprop.0+0xb27>
    b28a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b290:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b297:	00 
    b298:	e9 6c fe ff ff       	jmp    b109 <fwp_hof0.constprop.0+0x8e9>
    b29d:	66 85 c0             	test   %ax,%ax
    b2a0:	0f 85 22 f7 ff ff    	jne    a9c8 <fwp_hof0.constprop.0+0x1a8>
    b2a6:	e9 09 f7 ff ff       	jmp    a9b4 <fwp_hof0.constprop.0+0x194>
    b2ab:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b2af:	4d 85 d2             	test   %r10,%r10
    b2b2:	74 19                	je     b2cd <fwp_hof0.constprop.0+0xaad>
    b2b4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b2b8:	4d 29 d3             	sub    %r10,%r11
    b2bb:	49 39 c3             	cmp    %rax,%r11
    b2be:	72 0d                	jb     b2cd <fwp_hof0.constprop.0+0xaad>
    b2c0:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b2c4:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b2c8:	e9 98 fc ff ff       	jmp    af65 <fwp_hof0.constprop.0+0x745>
    b2cd:	31 f6                	xor    %esi,%esi
    b2cf:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b2d2:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b2d6:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b2da:	e8 b1 a9 ff ff       	call   5c90 <fwp_heap_alloc>
    b2df:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b2e2:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b2e6:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b2ea:	49 89 c2             	mov    %rax,%r10
    b2ed:	e9 0f fd ff ff       	jmp    b001 <fwp_hof0.constprop.0+0x7e1>
    b2f2:	66 85 c0             	test   %ax,%ax
    b2f5:	0f 85 8c fe ff ff    	jne    b187 <fwp_hof0.constprop.0+0x967>
    b2fb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b300:	0f 85 7c fe ff ff    	jne    b182 <fwp_hof0.constprop.0+0x962>
    b306:	4c 89 e7             	mov    %r12,%rdi
    b309:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b30d:	e8 3e a2 ff ff       	call   5550 <fwp_rc_forget_slot>
    b312:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b316:	e9 67 fe ff ff       	jmp    b182 <fwp_hof0.constprop.0+0x962>
    b31b:	66 85 c0             	test   %ax,%ax
    b31e:	0f 85 cd fd ff ff    	jne    b0f1 <fwp_hof0.constprop.0+0x8d1>
    b324:	e9 bf fd ff ff       	jmp    b0e8 <fwp_hof0.constprop.0+0x8c8>
    b329:	e8 02 a1 ff ff       	call   5430 <fwp_rc_wide_dup>
    b32e:	48 8b 15 03 a1 01 00 	mov    0x1a103(%rip),%rdx        # 25438 <fwp_fns>
    b335:	e9 8e f6 ff ff       	jmp    a9c8 <fwp_hof0.constprop.0+0x1a8>
    b33a:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b341:	ff 11                	call   *(%rcx)
    b343:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b347:	48 89 dc             	mov    %rbx,%rsp
    b34a:	e9 a7 f9 ff ff       	jmp    acf6 <fwp_hof0.constprop.0+0x4d6>
    b34f:	48 89 c7             	mov    %rax,%rdi
    b352:	e8 b9 b2 ff ff       	call   6610 <fwp_rc_share>
    b357:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b35b:	e8 b0 b2 ff ff       	call   6610 <fwp_rc_share>
    b360:	48 8d 05 b1 7c 00 00 	lea    0x7cb1(%rip),%rax        # 13018 <fc12>
    b367:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b36e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b372:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b379:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b37d:	e9 60 f9 ff ff       	jmp    ace2 <fwp_hof0.constprop.0+0x4c2>
    b382:	66 85 c0             	test   %ax,%ax
    b385:	0f 85 5c f5 ff ff    	jne    a8e7 <fwp_hof0.constprop.0+0xc7>
    b38b:	e9 43 f5 ff ff       	jmp    a8d3 <fwp_hof0.constprop.0+0xb3>
    b390:	48 89 df             	mov    %rbx,%rdi
    b393:	e8 a8 b3 ff ff       	call   6740 <fwp_rc_free_arr>
    b398:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b39c:	4d 85 ff             	test   %r15,%r15
    b39f:	0f 85 bc f4 ff ff    	jne    a861 <fwp_hof0.constprop.0+0x41>
    b3a5:	e9 2f fb ff ff       	jmp    aed9 <fwp_hof0.constprop.0+0x6b9>
    b3aa:	66 85 c0             	test   %ax,%ax
    b3ad:	0f 85 5a fa ff ff    	jne    ae0d <fwp_hof0.constprop.0+0x5ed>
    b3b3:	e9 47 fa ff ff       	jmp    adff <fwp_hof0.constprop.0+0x5df>
    b3b8:	66 85 c0             	test   %ax,%ax
    b3bb:	0f 85 0b fb ff ff    	jne    aecc <fwp_hof0.constprop.0+0x6ac>
    b3c1:	e9 e6 fa ff ff       	jmp    aeac <fwp_hof0.constprop.0+0x68c>
    b3c6:	4c 89 e0             	mov    %r12,%rax
    b3c9:	48 8d 35 10 84 01 00 	lea    0x18410(%rip),%rsi        # 237e0 <fwp_heap>
    b3d0:	48 c1 e8 11          	shr    $0x11,%rax
    b3d4:	4c 31 e0             	xor    %r12,%rax
    b3d7:	48 89 c2             	mov    %rax,%rdx
    b3da:	48 c1 ea 09          	shr    $0x9,%rdx
    b3de:	48 31 d0             	xor    %rdx,%rax
    b3e1:	0f b6 c0             	movzbl %al,%eax
    b3e4:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b3eb:	00 
    b3ec:	48 85 d2             	test   %rdx,%rdx
    b3ef:	75 18                	jne    b409 <fwp_hof0.constprop.0+0xbe9>
    b3f1:	eb 4d                	jmp    b440 <fwp_hof0.constprop.0+0xc20>
    b3f3:	66 90                	xchg   %ax,%ax
    b3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b3fc:	00 00 00 00 
    b400:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b404:	48 85 d2             	test   %rdx,%rdx
    b407:	74 37                	je     b440 <fwp_hof0.constprop.0+0xc20>
    b409:	48 89 d0             	mov    %rdx,%rax
    b40c:	4c 39 22             	cmp    %r12,(%rdx)
    b40f:	75 ef                	jne    b400 <fwp_hof0.constprop.0+0xbe0>
    b411:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b415:	48 83 e8 01          	sub    $0x1,%rax
    b419:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b41d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b423:	0f 85 a3 fa ff ff    	jne    aecc <fwp_hof0.constprop.0+0x6ac>
    b429:	4c 89 e7             	mov    %r12,%rdi
    b42c:	e8 1f a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b431:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b436:	e9 91 fa ff ff       	jmp    aecc <fwp_hof0.constprop.0+0x6ac>
    b43b:	e8 70 88 ff ff       	call   3cb0 <fwp_heap_oom>
    b440:	48 8d 3d 41 44 00 00 	lea    0x4441(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    b447:	e8 a4 8f ff ff       	call   43f0 <fwp_trap>
    b44c:	48 8d 3d f3 3d 00 00 	lea    0x3df3(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b453:	e8 98 8f ff ff       	call   43f0 <fwp_trap>
    b458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b45f:	00 
    b460:	e8 cb 9f ff ff       	call   5430 <fwp_rc_wide_dup>
    b465:	e9 7d f4 ff ff       	jmp    a8e7 <fwp_hof0.constprop.0+0xc7>
    b46a:	e8 f1 7f ff ff       	call   3460 <__stack_chk_fail@plt>
    b46f:	90                   	nop
    b470:	4c 89 f7             	mov    %r14,%rdi
    b473:	e8 d8 a0 ff ff       	call   5550 <fwp_rc_forget_slot>
    b478:	e9 8c f9 ff ff       	jmp    ae09 <fwp_hof0.constprop.0+0x5e9>
    b47d:	0f 1f 00             	nopl   (%rax)

000000000000b480 <f0>:
    b480:	41 56                	push   %r14
    b482:	4c 8d 35 57 83 01 00 	lea    0x18357(%rip),%r14        # 237e0 <fwp_heap>
    b489:	41 55                	push   %r13
    b48b:	41 54                	push   %r12
    b48d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b493:	55                   	push   %rbp
    b494:	53                   	push   %rbx
    b495:	31 db                	xor    %ebx,%ebx
    b497:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b49e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b4a5:	00 00 
    b4a7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b4ae:	00 
    b4af:	31 c0                	xor    %eax,%eax
    b4b1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b4b8:	00 
    b4b9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b4c0:	00 00 
    b4c2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b4c7:	48 8d 05 02 b7 ff ff 	lea    -0x48fe(%rip),%rax        # 6bd0 <fwp_drop1>
    b4ce:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b4d3:	48 8b 05 9e 9f 01 00 	mov    0x19f9e(%rip),%rax        # 25478 <fwp_cleanups>
    b4da:	48 89 25 97 9f 01 00 	mov    %rsp,0x19f97(%rip)        # 25478 <fwp_cleanups>
    b4e1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b4e5:	48 89 04 24          	mov    %rax,(%rsp)
    b4e9:	48 8d 05 e0 86 ff ff 	lea    -0x7920(%rip),%rax        # 3bd0 <fwp_range_release>
    b4f0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b4f5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b4fa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b4ff:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b504:	eb 47                	jmp    b54d <f0+0xcd>
    b506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b50d:	00 00 00 
    b510:	80 f9 01             	cmp    $0x1,%cl
    b513:	75 29                	jne    b53e <f0+0xbe>
    b515:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b518:	0f b7 c0             	movzwl %ax,%eax
    b51b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b51e:	48 0f af c1          	imul   %rcx,%rax
    b522:	48 c1 e8 20          	shr    $0x20,%rax
    b526:	48 39 d0             	cmp    %rdx,%rax
    b529:	73 13                	jae    b53e <f0+0xbe>
    b52b:	49 01 c5             	add    %rax,%r13
    b52e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b533:	0f 84 c7 27 00 00    	je     dd00 <f0+0x2880>
    b539:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b53e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b543:	49 83 ec 01          	sub    $0x1,%r12
    b547:	0f 82 83 00 00 00    	jb     b5d0 <f0+0x150>
    b54d:	48 89 ee             	mov    %rbp,%rsi
    b550:	bf 01 00 00 00       	mov    $0x1,%edi
    b555:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b55c:	00 
    b55d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b562:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b569:	00 
    b56a:	e8 71 af ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b56f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b576:	48 89 c3             	mov    %rax,%rbx
    b579:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b580:	48 c1 e2 10          	shl    $0x10,%rdx
    b584:	48 39 d0             	cmp    %rdx,%rax
    b587:	73 b5                	jae    b53e <f0+0xbe>
    b589:	48 89 c2             	mov    %rax,%rdx
    b58c:	48 c1 ea 10          	shr    $0x10,%rdx
    b590:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b594:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b59b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b59f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b5a3:	4d 85 ed             	test   %r13,%r13
    b5a6:	74 96                	je     b53e <f0+0xbe>
    b5a8:	0f b6 0a             	movzbl (%rdx),%ecx
    b5ab:	80 f9 02             	cmp    $0x2,%cl
    b5ae:	0f 85 5c ff ff ff    	jne    b510 <f0+0x90>
    b5b4:	66 85 c0             	test   %ax,%ax
    b5b7:	0f 84 71 ff ff ff    	je     b52e <f0+0xae>
    b5bd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b5c2:	49 83 ec 01          	sub    $0x1,%r12
    b5c6:	73 85                	jae    b54d <f0+0xcd>
    b5c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b5cf:	00 
    b5d0:	48 8b 04 24          	mov    (%rsp),%rax
    b5d4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b5d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5de:	66 0f 6f 05 2a 46 00 	movdqa 0x462a(%rip),%xmm0        # fc10 <msg.4+0xa0>
    b5e5:	00 
    b5e6:	48 89 05 8b 9e 01 00 	mov    %rax,0x19e8b(%rip)        # 25478 <fwp_cleanups>
    b5ed:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b5f2:	e8 e9 ae ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b5f7:	48 8b 15 ba 95 01 00 	mov    0x195ba(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b5fe:	49 89 c5             	mov    %rax,%r13
    b601:	48 2b 05 88 95 01 00 	sub    0x19588(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b608:	48 c1 e2 10          	shl    $0x10,%rdx
    b60c:	48 39 d0             	cmp    %rdx,%rax
    b60f:	73 59                	jae    b66a <f0+0x1ea>
    b611:	48 89 c2             	mov    %rax,%rdx
    b614:	48 c1 ea 10          	shr    $0x10,%rdx
    b618:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b61c:	48 8b 15 b5 95 01 00 	mov    0x195b5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b623:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b627:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b62b:	4d 85 e4             	test   %r12,%r12
    b62e:	74 3a                	je     b66a <f0+0x1ea>
    b630:	0f b6 0a             	movzbl (%rdx),%ecx
    b633:	80 f9 02             	cmp    $0x2,%cl
    b636:	0f 84 74 27 00 00    	je     ddb0 <f0+0x2930>
    b63c:	80 f9 01             	cmp    $0x1,%cl
    b63f:	75 29                	jne    b66a <f0+0x1ea>
    b641:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b644:	0f b7 c0             	movzwl %ax,%eax
    b647:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b64a:	48 0f af c1          	imul   %rcx,%rax
    b64e:	48 c1 e8 20          	shr    $0x20,%rax
    b652:	48 39 d0             	cmp    %rdx,%rax
    b655:	73 13                	jae    b66a <f0+0x1ea>
    b657:	49 01 c4             	add    %rax,%r12
    b65a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b65f:	0f 84 26 29 00 00    	je     df8b <f0+0x2b0b>
    b665:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b66a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b66f:	bf 01 00 00 00       	mov    $0x1,%edi
    b674:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b679:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b680:	00 f0 3f 
    b683:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b688:	e8 53 ae ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b68d:	48 8b 15 24 95 01 00 	mov    0x19524(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b694:	49 89 c5             	mov    %rax,%r13
    b697:	48 2b 05 f2 94 01 00 	sub    0x194f2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b69e:	48 c1 e2 10          	shl    $0x10,%rdx
    b6a2:	48 39 d0             	cmp    %rdx,%rax
    b6a5:	73 59                	jae    b700 <f0+0x280>
    b6a7:	48 89 c2             	mov    %rax,%rdx
    b6aa:	48 c1 ea 10          	shr    $0x10,%rdx
    b6ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6b2:	48 8b 15 1f 95 01 00 	mov    0x1951f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b6b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6bd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b6c1:	4d 85 e4             	test   %r12,%r12
    b6c4:	74 3a                	je     b700 <f0+0x280>
    b6c6:	0f b6 0a             	movzbl (%rdx),%ecx
    b6c9:	80 f9 02             	cmp    $0x2,%cl
    b6cc:	0f 84 ce 26 00 00    	je     dda0 <f0+0x2920>
    b6d2:	80 f9 01             	cmp    $0x1,%cl
    b6d5:	75 29                	jne    b700 <f0+0x280>
    b6d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6da:	0f b7 c0             	movzwl %ax,%eax
    b6dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6e0:	48 0f af c1          	imul   %rcx,%rax
    b6e4:	48 c1 e8 20          	shr    $0x20,%rax
    b6e8:	48 39 d0             	cmp    %rdx,%rax
    b6eb:	73 13                	jae    b700 <f0+0x280>
    b6ed:	49 01 c4             	add    %rax,%r12
    b6f0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b6f5:	0f 84 9d 28 00 00    	je     df98 <f0+0x2b18>
    b6fb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b700:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b705:	bf 01 00 00 00       	mov    $0x1,%edi
    b70a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b70f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b716:	33 f3 bf 
    b719:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b71e:	e8 bd ad ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b723:	48 8b 15 8e 94 01 00 	mov    0x1948e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b72a:	49 89 c5             	mov    %rax,%r13
    b72d:	48 2b 05 5c 94 01 00 	sub    0x1945c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b734:	48 c1 e2 10          	shl    $0x10,%rdx
    b738:	48 39 d0             	cmp    %rdx,%rax
    b73b:	73 59                	jae    b796 <f0+0x316>
    b73d:	48 89 c2             	mov    %rax,%rdx
    b740:	48 c1 ea 10          	shr    $0x10,%rdx
    b744:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b748:	48 8b 15 89 94 01 00 	mov    0x19489(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b74f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b753:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b757:	4d 85 e4             	test   %r12,%r12
    b75a:	74 3a                	je     b796 <f0+0x316>
    b75c:	0f b6 0a             	movzbl (%rdx),%ecx
    b75f:	80 f9 02             	cmp    $0x2,%cl
    b762:	0f 84 28 26 00 00    	je     dd90 <f0+0x2910>
    b768:	80 f9 01             	cmp    $0x1,%cl
    b76b:	75 29                	jne    b796 <f0+0x316>
    b76d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b770:	0f b7 c0             	movzwl %ax,%eax
    b773:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b776:	48 0f af c1          	imul   %rcx,%rax
    b77a:	48 c1 e8 20          	shr    $0x20,%rax
    b77e:	48 39 d0             	cmp    %rdx,%rax
    b781:	73 13                	jae    b796 <f0+0x316>
    b783:	49 01 c4             	add    %rax,%r12
    b786:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b78b:	0f 84 14 28 00 00    	je     dfa5 <f0+0x2b25>
    b791:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b796:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b79b:	bf 01 00 00 00       	mov    $0x1,%edi
    b7a0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b7a5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b7ac:	00 f0 3f 
    b7af:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b7b4:	e8 27 ad ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b7b9:	48 8b 15 f8 93 01 00 	mov    0x193f8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b7c0:	49 89 c5             	mov    %rax,%r13
    b7c3:	48 2b 05 c6 93 01 00 	sub    0x193c6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b7ca:	48 c1 e2 10          	shl    $0x10,%rdx
    b7ce:	48 39 d0             	cmp    %rdx,%rax
    b7d1:	73 59                	jae    b82c <f0+0x3ac>
    b7d3:	48 89 c2             	mov    %rax,%rdx
    b7d6:	48 c1 ea 10          	shr    $0x10,%rdx
    b7da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7de:	48 8b 15 f3 93 01 00 	mov    0x193f3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b7e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7e9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b7ed:	4d 85 e4             	test   %r12,%r12
    b7f0:	74 3a                	je     b82c <f0+0x3ac>
    b7f2:	0f b6 0a             	movzbl (%rdx),%ecx
    b7f5:	80 f9 02             	cmp    $0x2,%cl
    b7f8:	0f 84 f2 25 00 00    	je     ddf0 <f0+0x2970>
    b7fe:	80 f9 01             	cmp    $0x1,%cl
    b801:	75 29                	jne    b82c <f0+0x3ac>
    b803:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b806:	0f b7 c0             	movzwl %ax,%eax
    b809:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b80c:	48 0f af c1          	imul   %rcx,%rax
    b810:	48 c1 e8 20          	shr    $0x20,%rax
    b814:	48 39 d0             	cmp    %rdx,%rax
    b817:	73 13                	jae    b82c <f0+0x3ac>
    b819:	49 01 c4             	add    %rax,%r12
    b81c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b821:	0f 84 8b 27 00 00    	je     dfb2 <f0+0x2b32>
    b827:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b82c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b833:	33 f3 bf 
    b836:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b83d:	00 
    b83e:	bf 01 00 00 00       	mov    $0x1,%edi
    b843:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b84a:	00 
    b84b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b852:	00 
    b853:	e8 88 ac ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b858:	48 8b 15 59 93 01 00 	mov    0x19359(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b85f:	49 89 c5             	mov    %rax,%r13
    b862:	48 2b 05 27 93 01 00 	sub    0x19327(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b869:	48 c1 e2 10          	shl    $0x10,%rdx
    b86d:	48 39 d0             	cmp    %rdx,%rax
    b870:	73 59                	jae    b8cb <f0+0x44b>
    b872:	48 89 c2             	mov    %rax,%rdx
    b875:	48 c1 ea 10          	shr    $0x10,%rdx
    b879:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b87d:	48 8b 15 54 93 01 00 	mov    0x19354(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b884:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b888:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b88c:	4d 85 e4             	test   %r12,%r12
    b88f:	74 3a                	je     b8cb <f0+0x44b>
    b891:	0f b6 0a             	movzbl (%rdx),%ecx
    b894:	80 f9 02             	cmp    $0x2,%cl
    b897:	0f 84 43 25 00 00    	je     dde0 <f0+0x2960>
    b89d:	80 f9 01             	cmp    $0x1,%cl
    b8a0:	75 29                	jne    b8cb <f0+0x44b>
    b8a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8a5:	0f b7 c0             	movzwl %ax,%eax
    b8a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8ab:	48 0f af c1          	imul   %rcx,%rax
    b8af:	48 c1 e8 20          	shr    $0x20,%rax
    b8b3:	48 39 d0             	cmp    %rdx,%rax
    b8b6:	73 13                	jae    b8cb <f0+0x44b>
    b8b8:	49 01 c4             	add    %rax,%r12
    b8bb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b8c0:	0f 84 f9 26 00 00    	je     dfbf <f0+0x2b3f>
    b8c6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b8cb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b8d2:	00 f0 3f 
    b8d5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b8dc:	00 
    b8dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b8e9:	00 
    b8ea:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b8f1:	00 
    b8f2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b8f9:	33 f3 bf 
    b8fc:	e8 df ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b901:	48 89 c7             	mov    %rax,%rdi
    b904:	e8 87 ad ff ff       	call   6690 <fwp_rc_fresh>
    b909:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b910:	00 
    b911:	bf 01 00 00 00       	mov    $0x1,%edi
    b916:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b91d:	00 
    b91e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b925:	00 
    b926:	e8 b5 ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b92b:	48 89 c7             	mov    %rax,%rdi
    b92e:	e8 5d ad ff ff       	call   6690 <fwp_rc_fresh>
    b933:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b93a:	00 
    b93b:	bf 01 00 00 00       	mov    $0x1,%edi
    b940:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b947:	00 
    b948:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b94f:	00 
    b950:	e8 8b ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b955:	48 89 c7             	mov    %rax,%rdi
    b958:	e8 33 ad ff ff       	call   6690 <fwp_rc_fresh>
    b95d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b964:	00 
    b965:	bf 01 00 00 00       	mov    $0x1,%edi
    b96a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b971:	00 
    b972:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b979:	00 
    b97a:	e8 61 ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b97f:	48 89 c7             	mov    %rax,%rdi
    b982:	e8 09 ad ff ff       	call   6690 <fwp_rc_fresh>
    b987:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b98e:	00 
    b98f:	bf 01 00 00 00       	mov    $0x1,%edi
    b994:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b99b:	00 
    b99c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b9a3:	00 
    b9a4:	e8 37 ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b9a9:	48 89 c7             	mov    %rax,%rdi
    b9ac:	e8 df ac ff ff       	call   6690 <fwp_rc_fresh>
    b9b1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b9b8:	00 
    b9b9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9be:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b9c5:	00 
    b9c6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b9cd:	00 
    b9ce:	e8 0d ab ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b9d3:	48 89 c7             	mov    %rax,%rdi
    b9d6:	e8 b5 ac ff ff       	call   6690 <fwp_rc_fresh>
    b9db:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b9e2:	00 
    b9e3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b9ef:	00 
    b9f0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b9f7:	00 
    b9f8:	e8 e3 aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    b9fd:	48 89 c7             	mov    %rax,%rdi
    ba00:	e8 8b ac ff ff       	call   6690 <fwp_rc_fresh>
    ba05:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    ba0c:	00 
    ba0d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba12:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    ba19:	00 
    ba1a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    ba21:	00 
    ba22:	e8 b9 aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ba27:	48 89 c7             	mov    %rax,%rdi
    ba2a:	e8 61 ac ff ff       	call   6690 <fwp_rc_fresh>
    ba2f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    ba36:	00 
    ba37:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    ba43:	00 
    ba44:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    ba4b:	00 
    ba4c:	e8 8f aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ba51:	48 89 c7             	mov    %rax,%rdi
    ba54:	e8 37 ac ff ff       	call   6690 <fwp_rc_fresh>
    ba59:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    ba60:	00 
    ba61:	bf 01 00 00 00       	mov    $0x1,%edi
    ba66:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    ba6d:	00 
    ba6e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    ba75:	00 
    ba76:	e8 65 aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ba7b:	48 89 c7             	mov    %rax,%rdi
    ba7e:	e8 0d ac ff ff       	call   6690 <fwp_rc_fresh>
    ba83:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    ba8a:	00 
    ba8b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba90:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    ba97:	00 
    ba98:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    ba9f:	00 
    baa0:	e8 3b aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    baa5:	48 89 c7             	mov    %rax,%rdi
    baa8:	e8 e3 ab ff ff       	call   6690 <fwp_rc_fresh>
    baad:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bab4:	00 
    bab5:	bf 01 00 00 00       	mov    $0x1,%edi
    baba:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bac1:	00 
    bac2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bac9:	00 
    baca:	e8 11 aa ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bacf:	48 89 c7             	mov    %rax,%rdi
    bad2:	e8 b9 ab ff ff       	call   6690 <fwp_rc_fresh>
    bad7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bade:	00 
    badf:	bf 01 00 00 00       	mov    $0x1,%edi
    bae4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    baeb:	00 
    baec:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    baf3:	00 
    baf4:	e8 e7 a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    baf9:	48 89 c7             	mov    %rax,%rdi
    bafc:	e8 8f ab ff ff       	call   6690 <fwp_rc_fresh>
    bb01:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bb08:	00 
    bb09:	bf 01 00 00 00       	mov    $0x1,%edi
    bb0e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bb15:	00 
    bb16:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bb1d:	00 
    bb1e:	e8 bd a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bb23:	48 89 c7             	mov    %rax,%rdi
    bb26:	e8 65 ab ff ff       	call   6690 <fwp_rc_fresh>
    bb2b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bb32:	00 
    bb33:	bf 01 00 00 00       	mov    $0x1,%edi
    bb38:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bb3f:	00 
    bb40:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bb47:	00 
    bb48:	e8 93 a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bb4d:	48 89 c7             	mov    %rax,%rdi
    bb50:	e8 3b ab ff ff       	call   6690 <fwp_rc_fresh>
    bb55:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bb5c:	00 
    bb5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb62:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bb69:	00 
    bb6a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bb71:	00 
    bb72:	e8 69 a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bb77:	48 89 c7             	mov    %rax,%rdi
    bb7a:	e8 11 ab ff ff       	call   6690 <fwp_rc_fresh>
    bb7f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bb86:	00 
    bb87:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bb93:	00 
    bb94:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bb9b:	00 
    bb9c:	e8 3f a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bba1:	48 89 c7             	mov    %rax,%rdi
    bba4:	e8 e7 aa ff ff       	call   6690 <fwp_rc_fresh>
    bba9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bbb0:	00 
    bbb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bbbd:	00 
    bbbe:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bbc5:	00 
    bbc6:	e8 15 a9 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bbcb:	48 89 c7             	mov    %rax,%rdi
    bbce:	e8 bd aa ff ff       	call   6690 <fwp_rc_fresh>
    bbd3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bbda:	00 
    bbdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    bbe7:	00 
    bbe8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    bbef:	00 
    bbf0:	e8 eb a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bbf5:	48 89 c7             	mov    %rax,%rdi
    bbf8:	e8 93 aa ff ff       	call   6690 <fwp_rc_fresh>
    bbfd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    bc04:	00 
    bc05:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    bc11:	00 
    bc12:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    bc19:	00 
    bc1a:	e8 c1 a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bc1f:	48 89 c7             	mov    %rax,%rdi
    bc22:	e8 69 aa ff ff       	call   6690 <fwp_rc_fresh>
    bc27:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    bc2e:	00 
    bc2f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc34:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    bc3b:	00 
    bc3c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bc43:	00 
    bc44:	e8 97 a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bc49:	48 89 c7             	mov    %rax,%rdi
    bc4c:	e8 3f aa ff ff       	call   6690 <fwp_rc_fresh>
    bc51:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bc58:	00 
    bc59:	bf 01 00 00 00       	mov    $0x1,%edi
    bc5e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bc65:	00 
    bc66:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bc6d:	00 
    bc6e:	e8 6d a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bc73:	48 89 c7             	mov    %rax,%rdi
    bc76:	e8 15 aa ff ff       	call   6690 <fwp_rc_fresh>
    bc7b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bc82:	00 
    bc83:	bf 01 00 00 00       	mov    $0x1,%edi
    bc88:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bc8f:	00 
    bc90:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bc97:	00 
    bc98:	e8 43 a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bc9d:	48 89 c7             	mov    %rax,%rdi
    bca0:	e8 eb a9 ff ff       	call   6690 <fwp_rc_fresh>
    bca5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bcac:	00 
    bcad:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bcb9:	00 
    bcba:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bcc1:	00 
    bcc2:	e8 19 a8 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bcc7:	48 89 c7             	mov    %rax,%rdi
    bcca:	e8 c1 a9 ff ff       	call   6690 <fwp_rc_fresh>
    bccf:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bcd6:	00 
    bcd7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcdc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bce3:	00 
    bce4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bceb:	00 
    bcec:	e8 ef a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bcf1:	48 89 c7             	mov    %rax,%rdi
    bcf4:	e8 97 a9 ff ff       	call   6690 <fwp_rc_fresh>
    bcf9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bd00:	00 
    bd01:	bf 01 00 00 00       	mov    $0x1,%edi
    bd06:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bd0d:	00 
    bd0e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bd15:	00 
    bd16:	e8 c5 a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bd1b:	48 89 c7             	mov    %rax,%rdi
    bd1e:	e8 6d a9 ff ff       	call   6690 <fwp_rc_fresh>
    bd23:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bd2a:	00 
    bd2b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd30:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bd37:	00 
    bd38:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bd3f:	00 
    bd40:	e8 9b a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bd45:	48 89 c7             	mov    %rax,%rdi
    bd48:	e8 43 a9 ff ff       	call   6690 <fwp_rc_fresh>
    bd4d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bd54:	00 
    bd55:	bf 01 00 00 00       	mov    $0x1,%edi
    bd5a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bd61:	00 
    bd62:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bd69:	00 
    bd6a:	e8 71 a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bd6f:	48 89 c7             	mov    %rax,%rdi
    bd72:	e8 19 a9 ff ff       	call   6690 <fwp_rc_fresh>
    bd77:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bd7e:	00 
    bd7f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd84:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bd8b:	00 
    bd8c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bd93:	00 
    bd94:	e8 47 a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bd99:	48 89 c7             	mov    %rax,%rdi
    bd9c:	e8 ef a8 ff ff       	call   6690 <fwp_rc_fresh>
    bda1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bda8:	00 
    bda9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdae:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bdb5:	00 
    bdb6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bdbd:	00 
    bdbe:	e8 1d a7 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bdc3:	48 89 c7             	mov    %rax,%rdi
    bdc6:	e8 c5 a8 ff ff       	call   6690 <fwp_rc_fresh>
    bdcb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bdd2:	00 
    bdd3:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bddf:	00 
    bde0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bde7:	00 
    bde8:	e8 f3 a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bded:	48 89 c7             	mov    %rax,%rdi
    bdf0:	e8 9b a8 ff ff       	call   6690 <fwp_rc_fresh>
    bdf5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bdfc:	00 
    bdfd:	bf 01 00 00 00       	mov    $0x1,%edi
    be02:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    be09:	00 
    be0a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    be11:	00 
    be12:	e8 c9 a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    be17:	48 89 c7             	mov    %rax,%rdi
    be1a:	e8 71 a8 ff ff       	call   6690 <fwp_rc_fresh>
    be1f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    be26:	00 
    be27:	bf 01 00 00 00       	mov    $0x1,%edi
    be2c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    be33:	00 
    be34:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    be3b:	00 
    be3c:	e8 9f a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    be41:	48 89 c7             	mov    %rax,%rdi
    be44:	e8 47 a8 ff ff       	call   6690 <fwp_rc_fresh>
    be49:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    be50:	00 
    be51:	bf 01 00 00 00       	mov    $0x1,%edi
    be56:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    be5d:	00 
    be5e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    be65:	00 
    be66:	e8 75 a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    be6b:	48 89 c7             	mov    %rax,%rdi
    be6e:	e8 1d a8 ff ff       	call   6690 <fwp_rc_fresh>
    be73:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    be7a:	00 
    be7b:	bf 01 00 00 00       	mov    $0x1,%edi
    be80:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    be87:	00 
    be88:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    be8f:	00 
    be90:	e8 4b a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    be95:	48 89 c7             	mov    %rax,%rdi
    be98:	e8 f3 a7 ff ff       	call   6690 <fwp_rc_fresh>
    be9d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bea4:	00 
    bea5:	bf 01 00 00 00       	mov    $0x1,%edi
    beaa:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    beb1:	00 
    beb2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    beb9:	00 
    beba:	e8 21 a6 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bebf:	48 89 c7             	mov    %rax,%rdi
    bec2:	e8 c9 a7 ff ff       	call   6690 <fwp_rc_fresh>
    bec7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bece:	00 
    becf:	bf 01 00 00 00       	mov    $0x1,%edi
    bed4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bedb:	00 
    bedc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bee3:	00 
    bee4:	e8 f7 a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bee9:	48 89 c7             	mov    %rax,%rdi
    beec:	e8 9f a7 ff ff       	call   6690 <fwp_rc_fresh>
    bef1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bef8:	00 
    bef9:	bf 01 00 00 00       	mov    $0x1,%edi
    befe:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bf05:	00 
    bf06:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bf0d:	00 
    bf0e:	e8 cd a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bf13:	48 89 c7             	mov    %rax,%rdi
    bf16:	e8 75 a7 ff ff       	call   6690 <fwp_rc_fresh>
    bf1b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bf22:	00 
    bf23:	bf 01 00 00 00       	mov    $0x1,%edi
    bf28:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bf2f:	00 
    bf30:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bf37:	00 
    bf38:	e8 a3 a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bf3d:	48 89 c7             	mov    %rax,%rdi
    bf40:	e8 4b a7 ff ff       	call   6690 <fwp_rc_fresh>
    bf45:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bf4c:	00 
    bf4d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf52:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bf59:	00 
    bf5a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bf61:	00 
    bf62:	e8 79 a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bf67:	48 89 c7             	mov    %rax,%rdi
    bf6a:	e8 21 a7 ff ff       	call   6690 <fwp_rc_fresh>
    bf6f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bf76:	00 
    bf77:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bf83:	00 
    bf84:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bf8b:	00 
    bf8c:	e8 4f a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bf91:	48 89 c7             	mov    %rax,%rdi
    bf94:	e8 f7 a6 ff ff       	call   6690 <fwp_rc_fresh>
    bf99:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bfa0:	00 
    bfa1:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bfad:	00 
    bfae:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bfb5:	00 
    bfb6:	e8 25 a5 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bfbb:	48 89 c7             	mov    %rax,%rdi
    bfbe:	e8 cd a6 ff ff       	call   6690 <fwp_rc_fresh>
    bfc3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bfca:	00 
    bfcb:	bf 01 00 00 00       	mov    $0x1,%edi
    bfd0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bfd7:	00 
    bfd8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bfdf:	00 
    bfe0:	e8 fb a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    bfe5:	48 89 c7             	mov    %rax,%rdi
    bfe8:	e8 a3 a6 ff ff       	call   6690 <fwp_rc_fresh>
    bfed:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bff4:	00 
    bff5:	bf 01 00 00 00       	mov    $0x1,%edi
    bffa:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c001:	00 
    c002:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c009:	00 
    c00a:	e8 d1 a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c00f:	48 89 c7             	mov    %rax,%rdi
    c012:	e8 79 a6 ff ff       	call   6690 <fwp_rc_fresh>
    c017:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c01e:	00 
    c01f:	bf 01 00 00 00       	mov    $0x1,%edi
    c024:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c02b:	00 
    c02c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c033:	00 
    c034:	e8 a7 a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c039:	48 89 c7             	mov    %rax,%rdi
    c03c:	e8 4f a6 ff ff       	call   6690 <fwp_rc_fresh>
    c041:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c048:	00 
    c049:	bf 01 00 00 00       	mov    $0x1,%edi
    c04e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c055:	00 
    c056:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c05d:	00 
    c05e:	e8 7d a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c063:	48 89 c7             	mov    %rax,%rdi
    c066:	e8 25 a6 ff ff       	call   6690 <fwp_rc_fresh>
    c06b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c072:	00 
    c073:	bf 01 00 00 00       	mov    $0x1,%edi
    c078:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c07f:	00 
    c080:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c087:	00 
    c088:	e8 53 a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c08d:	48 89 c7             	mov    %rax,%rdi
    c090:	e8 fb a5 ff ff       	call   6690 <fwp_rc_fresh>
    c095:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c09c:	00 
    c09d:	bf 01 00 00 00       	mov    $0x1,%edi
    c0a2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c0a9:	00 
    c0aa:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c0b1:	00 
    c0b2:	e8 29 a4 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c0b7:	48 89 c7             	mov    %rax,%rdi
    c0ba:	e8 d1 a5 ff ff       	call   6690 <fwp_rc_fresh>
    c0bf:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c0c6:	00 
    c0c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c0cc:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c0d3:	00 
    c0d4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c0db:	00 
    c0dc:	e8 ff a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c0e1:	48 89 c7             	mov    %rax,%rdi
    c0e4:	e8 a7 a5 ff ff       	call   6690 <fwp_rc_fresh>
    c0e9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c0f0:	00 
    c0f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c0fd:	00 
    c0fe:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c105:	00 
    c106:	e8 d5 a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c10b:	48 89 c7             	mov    %rax,%rdi
    c10e:	e8 7d a5 ff ff       	call   6690 <fwp_rc_fresh>
    c113:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c11a:	00 
    c11b:	bf 01 00 00 00       	mov    $0x1,%edi
    c120:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c127:	00 
    c128:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c12f:	00 
    c130:	e8 ab a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c135:	48 89 c7             	mov    %rax,%rdi
    c138:	e8 53 a5 ff ff       	call   6690 <fwp_rc_fresh>
    c13d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c144:	00 
    c145:	bf 01 00 00 00       	mov    $0x1,%edi
    c14a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c151:	00 
    c152:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c159:	00 
    c15a:	e8 81 a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c15f:	48 89 c7             	mov    %rax,%rdi
    c162:	e8 29 a5 ff ff       	call   6690 <fwp_rc_fresh>
    c167:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c16e:	00 
    c16f:	bf 01 00 00 00       	mov    $0x1,%edi
    c174:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c17b:	00 
    c17c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c183:	00 
    c184:	e8 57 a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c189:	48 89 c7             	mov    %rax,%rdi
    c18c:	e8 ff a4 ff ff       	call   6690 <fwp_rc_fresh>
    c191:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c198:	00 
    c199:	bf 01 00 00 00       	mov    $0x1,%edi
    c19e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c1a5:	00 
    c1a6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c1ad:	00 
    c1ae:	e8 2d a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c1b3:	48 89 c7             	mov    %rax,%rdi
    c1b6:	e8 d5 a4 ff ff       	call   6690 <fwp_rc_fresh>
    c1bb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c1c2:	00 
    c1c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c1cf:	00 
    c1d0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c1d7:	00 
    c1d8:	e8 03 a3 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c1dd:	48 89 c7             	mov    %rax,%rdi
    c1e0:	e8 ab a4 ff ff       	call   6690 <fwp_rc_fresh>
    c1e5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c1ec:	00 
    c1ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c1f2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c1f9:	00 
    c1fa:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c201:	00 
    c202:	e8 d9 a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c207:	48 89 c7             	mov    %rax,%rdi
    c20a:	e8 81 a4 ff ff       	call   6690 <fwp_rc_fresh>
    c20f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c216:	00 
    c217:	bf 01 00 00 00       	mov    $0x1,%edi
    c21c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c223:	00 
    c224:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c22b:	00 
    c22c:	e8 af a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c231:	48 89 c7             	mov    %rax,%rdi
    c234:	e8 57 a4 ff ff       	call   6690 <fwp_rc_fresh>
    c239:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c240:	00 
    c241:	bf 01 00 00 00       	mov    $0x1,%edi
    c246:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c24d:	00 
    c24e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c255:	00 
    c256:	e8 85 a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c25b:	48 89 c7             	mov    %rax,%rdi
    c25e:	e8 2d a4 ff ff       	call   6690 <fwp_rc_fresh>
    c263:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c26a:	00 
    c26b:	bf 01 00 00 00       	mov    $0x1,%edi
    c270:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c277:	00 
    c278:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c27f:	00 
    c280:	e8 5b a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c285:	48 89 c7             	mov    %rax,%rdi
    c288:	e8 03 a4 ff ff       	call   6690 <fwp_rc_fresh>
    c28d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c294:	00 
    c295:	bf 01 00 00 00       	mov    $0x1,%edi
    c29a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c2a1:	00 
    c2a2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c2a9:	00 
    c2aa:	e8 31 a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c2af:	48 89 c7             	mov    %rax,%rdi
    c2b2:	e8 d9 a3 ff ff       	call   6690 <fwp_rc_fresh>
    c2b7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c2be:	00 
    c2bf:	bf 01 00 00 00       	mov    $0x1,%edi
    c2c4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c2cb:	00 
    c2cc:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c2d3:	00 
    c2d4:	e8 07 a2 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c2d9:	48 89 c7             	mov    %rax,%rdi
    c2dc:	e8 af a3 ff ff       	call   6690 <fwp_rc_fresh>
    c2e1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c2e8:	00 
    c2e9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ee:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c2f5:	00 
    c2f6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c2fd:	00 
    c2fe:	e8 dd a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c303:	48 89 c7             	mov    %rax,%rdi
    c306:	e8 85 a3 ff ff       	call   6690 <fwp_rc_fresh>
    c30b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c312:	00 
    c313:	bf 01 00 00 00       	mov    $0x1,%edi
    c318:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c31f:	00 
    c320:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c327:	00 
    c328:	e8 b3 a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c32d:	48 89 c7             	mov    %rax,%rdi
    c330:	e8 5b a3 ff ff       	call   6690 <fwp_rc_fresh>
    c335:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c33c:	00 
    c33d:	bf 01 00 00 00       	mov    $0x1,%edi
    c342:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c349:	00 
    c34a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c351:	00 
    c352:	e8 89 a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c357:	48 89 c7             	mov    %rax,%rdi
    c35a:	e8 31 a3 ff ff       	call   6690 <fwp_rc_fresh>
    c35f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c366:	00 
    c367:	bf 01 00 00 00       	mov    $0x1,%edi
    c36c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c373:	00 
    c374:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c37b:	00 
    c37c:	e8 5f a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c381:	48 89 c7             	mov    %rax,%rdi
    c384:	e8 07 a3 ff ff       	call   6690 <fwp_rc_fresh>
    c389:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c390:	00 
    c391:	bf 01 00 00 00       	mov    $0x1,%edi
    c396:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c39d:	00 
    c39e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c3a5:	00 
    c3a6:	e8 35 a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c3ab:	48 89 c7             	mov    %rax,%rdi
    c3ae:	e8 dd a2 ff ff       	call   6690 <fwp_rc_fresh>
    c3b3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c3ba:	00 
    c3bb:	bf 01 00 00 00       	mov    $0x1,%edi
    c3c0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c3c7:	00 
    c3c8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c3cf:	00 
    c3d0:	e8 0b a1 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c3d5:	48 89 c7             	mov    %rax,%rdi
    c3d8:	e8 b3 a2 ff ff       	call   6690 <fwp_rc_fresh>
    c3dd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c3e4:	00 
    c3e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ea:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c3f1:	00 
    c3f2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c3f9:	00 
    c3fa:	e8 e1 a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c3ff:	48 89 c7             	mov    %rax,%rdi
    c402:	e8 89 a2 ff ff       	call   6690 <fwp_rc_fresh>
    c407:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c40e:	00 
    c40f:	bf 01 00 00 00       	mov    $0x1,%edi
    c414:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c41b:	00 
    c41c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c423:	00 
    c424:	e8 b7 a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c429:	48 89 c7             	mov    %rax,%rdi
    c42c:	e8 5f a2 ff ff       	call   6690 <fwp_rc_fresh>
    c431:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c438:	00 
    c439:	bf 01 00 00 00       	mov    $0x1,%edi
    c43e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c445:	00 
    c446:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c44d:	00 
    c44e:	e8 8d a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c453:	48 89 c7             	mov    %rax,%rdi
    c456:	e8 35 a2 ff ff       	call   6690 <fwp_rc_fresh>
    c45b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c462:	00 
    c463:	bf 01 00 00 00       	mov    $0x1,%edi
    c468:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c46f:	00 
    c470:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c477:	00 
    c478:	e8 63 a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c47d:	48 89 c7             	mov    %rax,%rdi
    c480:	e8 0b a2 ff ff       	call   6690 <fwp_rc_fresh>
    c485:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c48c:	00 
    c48d:	bf 01 00 00 00       	mov    $0x1,%edi
    c492:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c499:	00 
    c49a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c4a1:	00 
    c4a2:	e8 39 a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c4a7:	48 89 c7             	mov    %rax,%rdi
    c4aa:	e8 e1 a1 ff ff       	call   6690 <fwp_rc_fresh>
    c4af:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c4b6:	00 
    c4b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c4bc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c4c3:	00 
    c4c4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c4cb:	00 
    c4cc:	e8 0f a0 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c4d1:	48 89 c7             	mov    %rax,%rdi
    c4d4:	e8 b7 a1 ff ff       	call   6690 <fwp_rc_fresh>
    c4d9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c4e0:	00 
    c4e1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c4ed:	00 
    c4ee:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c4f5:	00 
    c4f6:	e8 e5 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c4fb:	48 89 c7             	mov    %rax,%rdi
    c4fe:	e8 8d a1 ff ff       	call   6690 <fwp_rc_fresh>
    c503:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c50a:	00 
    c50b:	bf 01 00 00 00       	mov    $0x1,%edi
    c510:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c517:	00 
    c518:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c51f:	00 
    c520:	e8 bb 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c525:	48 89 c7             	mov    %rax,%rdi
    c528:	e8 63 a1 ff ff       	call   6690 <fwp_rc_fresh>
    c52d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c534:	00 
    c535:	bf 01 00 00 00       	mov    $0x1,%edi
    c53a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c541:	00 
    c542:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c549:	00 
    c54a:	e8 91 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c54f:	48 89 c7             	mov    %rax,%rdi
    c552:	e8 39 a1 ff ff       	call   6690 <fwp_rc_fresh>
    c557:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c55e:	00 
    c55f:	bf 01 00 00 00       	mov    $0x1,%edi
    c564:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c56b:	00 
    c56c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c573:	00 
    c574:	e8 67 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c579:	48 89 c7             	mov    %rax,%rdi
    c57c:	e8 0f a1 ff ff       	call   6690 <fwp_rc_fresh>
    c581:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c588:	00 
    c589:	bf 01 00 00 00       	mov    $0x1,%edi
    c58e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c595:	00 
    c596:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c59d:	00 
    c59e:	e8 3d 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c5a3:	48 89 c7             	mov    %rax,%rdi
    c5a6:	e8 e5 a0 ff ff       	call   6690 <fwp_rc_fresh>
    c5ab:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c5b2:	00 
    c5b3:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c5bf:	00 
    c5c0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c5c7:	00 
    c5c8:	e8 13 9f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c5cd:	48 89 c7             	mov    %rax,%rdi
    c5d0:	e8 bb a0 ff ff       	call   6690 <fwp_rc_fresh>
    c5d5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c5dc:	00 
    c5dd:	bf 01 00 00 00       	mov    $0x1,%edi
    c5e2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c5e9:	00 
    c5ea:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c5f1:	00 
    c5f2:	e8 e9 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c5f7:	48 89 c7             	mov    %rax,%rdi
    c5fa:	e8 91 a0 ff ff       	call   6690 <fwp_rc_fresh>
    c5ff:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c606:	00 
    c607:	bf 01 00 00 00       	mov    $0x1,%edi
    c60c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c613:	00 
    c614:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c61b:	00 
    c61c:	e8 bf 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c621:	48 89 c7             	mov    %rax,%rdi
    c624:	e8 67 a0 ff ff       	call   6690 <fwp_rc_fresh>
    c629:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c630:	00 
    c631:	bf 01 00 00 00       	mov    $0x1,%edi
    c636:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c63d:	00 
    c63e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c645:	00 
    c646:	e8 95 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c64b:	48 89 c7             	mov    %rax,%rdi
    c64e:	e8 3d a0 ff ff       	call   6690 <fwp_rc_fresh>
    c653:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c65a:	00 
    c65b:	bf 01 00 00 00       	mov    $0x1,%edi
    c660:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c667:	00 
    c668:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c66f:	00 
    c670:	e8 6b 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c675:	48 89 c7             	mov    %rax,%rdi
    c678:	e8 13 a0 ff ff       	call   6690 <fwp_rc_fresh>
    c67d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c684:	00 
    c685:	bf 01 00 00 00       	mov    $0x1,%edi
    c68a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c691:	00 
    c692:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c699:	00 
    c69a:	e8 41 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c69f:	48 89 c7             	mov    %rax,%rdi
    c6a2:	e8 e9 9f ff ff       	call   6690 <fwp_rc_fresh>
    c6a7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c6ae:	00 
    c6af:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c6bb:	00 
    c6bc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c6c3:	00 
    c6c4:	e8 17 9e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c6c9:	48 89 c7             	mov    %rax,%rdi
    c6cc:	e8 bf 9f ff ff       	call   6690 <fwp_rc_fresh>
    c6d1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c6d8:	00 
    c6d9:	bf 01 00 00 00       	mov    $0x1,%edi
    c6de:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c6e5:	00 
    c6e6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c6ed:	00 
    c6ee:	e8 ed 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c6f3:	48 89 c7             	mov    %rax,%rdi
    c6f6:	e8 95 9f ff ff       	call   6690 <fwp_rc_fresh>
    c6fb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c702:	00 
    c703:	bf 01 00 00 00       	mov    $0x1,%edi
    c708:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c70f:	00 
    c710:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c717:	00 
    c718:	e8 c3 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c71d:	48 89 c7             	mov    %rax,%rdi
    c720:	e8 6b 9f ff ff       	call   6690 <fwp_rc_fresh>
    c725:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c72c:	00 
    c72d:	bf 01 00 00 00       	mov    $0x1,%edi
    c732:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c739:	00 
    c73a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c741:	00 
    c742:	e8 99 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c747:	48 89 c7             	mov    %rax,%rdi
    c74a:	e8 41 9f ff ff       	call   6690 <fwp_rc_fresh>
    c74f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c756:	00 
    c757:	bf 01 00 00 00       	mov    $0x1,%edi
    c75c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c763:	00 
    c764:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c76b:	00 
    c76c:	e8 6f 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c771:	48 89 c7             	mov    %rax,%rdi
    c774:	e8 17 9f ff ff       	call   6690 <fwp_rc_fresh>
    c779:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c780:	00 
    c781:	bf 01 00 00 00       	mov    $0x1,%edi
    c786:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c78d:	00 
    c78e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c795:	00 
    c796:	e8 45 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c79b:	48 89 c7             	mov    %rax,%rdi
    c79e:	e8 ed 9e ff ff       	call   6690 <fwp_rc_fresh>
    c7a3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c7aa:	00 
    c7ab:	bf 01 00 00 00       	mov    $0x1,%edi
    c7b0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c7b7:	00 
    c7b8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c7bf:	00 
    c7c0:	e8 1b 9d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c7c5:	48 8b 15 ec 83 01 00 	mov    0x183ec(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c7cc:	49 89 c5             	mov    %rax,%r13
    c7cf:	48 2b 05 ba 83 01 00 	sub    0x183ba(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c7d6:	48 c1 e2 10          	shl    $0x10,%rdx
    c7da:	48 39 d0             	cmp    %rdx,%rax
    c7dd:	73 59                	jae    c838 <f0+0x13b8>
    c7df:	48 89 c2             	mov    %rax,%rdx
    c7e2:	48 c1 ea 10          	shr    $0x10,%rdx
    c7e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7ea:	48 8b 15 e7 83 01 00 	mov    0x183e7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c7f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7f5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7f9:	4d 85 e4             	test   %r12,%r12
    c7fc:	74 3a                	je     c838 <f0+0x13b8>
    c7fe:	0f b6 0a             	movzbl (%rdx),%ecx
    c801:	80 f9 02             	cmp    $0x2,%cl
    c804:	0f 84 c6 15 00 00    	je     ddd0 <f0+0x2950>
    c80a:	80 f9 01             	cmp    $0x1,%cl
    c80d:	75 29                	jne    c838 <f0+0x13b8>
    c80f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c812:	0f b7 c0             	movzwl %ax,%eax
    c815:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c818:	48 0f af c1          	imul   %rcx,%rax
    c81c:	48 c1 e8 20          	shr    $0x20,%rax
    c820:	48 39 d0             	cmp    %rdx,%rax
    c823:	73 13                	jae    c838 <f0+0x13b8>
    c825:	49 01 c4             	add    %rax,%r12
    c828:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c82d:	0f 84 99 17 00 00    	je     dfcc <f0+0x2b4c>
    c833:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c838:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c83f:	33 f3 bf 
    c842:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c849:	00 
    c84a:	bf 01 00 00 00       	mov    $0x1,%edi
    c84f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c856:	00 
    c857:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c85e:	00 
    c85f:	e8 7c 9c ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c864:	48 8b 15 4d 83 01 00 	mov    0x1834d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c86b:	49 89 c5             	mov    %rax,%r13
    c86e:	48 2b 05 1b 83 01 00 	sub    0x1831b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c875:	48 c1 e2 10          	shl    $0x10,%rdx
    c879:	48 39 d0             	cmp    %rdx,%rax
    c87c:	73 59                	jae    c8d7 <f0+0x1457>
    c87e:	48 89 c2             	mov    %rax,%rdx
    c881:	48 c1 ea 10          	shr    $0x10,%rdx
    c885:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c889:	48 8b 15 48 83 01 00 	mov    0x18348(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c890:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c894:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c898:	4d 85 e4             	test   %r12,%r12
    c89b:	74 3a                	je     c8d7 <f0+0x1457>
    c89d:	0f b6 0a             	movzbl (%rdx),%ecx
    c8a0:	80 f9 02             	cmp    $0x2,%cl
    c8a3:	0f 84 17 15 00 00    	je     ddc0 <f0+0x2940>
    c8a9:	80 f9 01             	cmp    $0x1,%cl
    c8ac:	75 29                	jne    c8d7 <f0+0x1457>
    c8ae:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8b1:	0f b7 c0             	movzwl %ax,%eax
    c8b4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8b7:	48 0f af c1          	imul   %rcx,%rax
    c8bb:	48 c1 e8 20          	shr    $0x20,%rax
    c8bf:	48 39 d0             	cmp    %rdx,%rax
    c8c2:	73 13                	jae    c8d7 <f0+0x1457>
    c8c4:	49 01 c4             	add    %rax,%r12
    c8c7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8cc:	0f 84 07 17 00 00    	je     dfd9 <f0+0x2b59>
    c8d2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8d7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8de:	00 f0 3f 
    c8e1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c8e8:	00 
    c8e9:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ee:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c8f5:	00 
    c8f6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c8fd:	00 
    c8fe:	e8 dd 9b ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c903:	48 8b 15 ae 82 01 00 	mov    0x182ae(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c90a:	49 89 c5             	mov    %rax,%r13
    c90d:	48 2b 05 7c 82 01 00 	sub    0x1827c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c914:	48 c1 e2 10          	shl    $0x10,%rdx
    c918:	48 39 d0             	cmp    %rdx,%rax
    c91b:	73 59                	jae    c976 <f0+0x14f6>
    c91d:	48 89 c2             	mov    %rax,%rdx
    c920:	48 c1 ea 10          	shr    $0x10,%rdx
    c924:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c928:	48 8b 15 a9 82 01 00 	mov    0x182a9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c92f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c933:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c937:	4d 85 e4             	test   %r12,%r12
    c93a:	74 3a                	je     c976 <f0+0x14f6>
    c93c:	0f b6 0a             	movzbl (%rdx),%ecx
    c93f:	80 f9 02             	cmp    $0x2,%cl
    c942:	0f 84 28 15 00 00    	je     de70 <f0+0x29f0>
    c948:	80 f9 01             	cmp    $0x1,%cl
    c94b:	75 29                	jne    c976 <f0+0x14f6>
    c94d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c950:	0f b7 c0             	movzwl %ax,%eax
    c953:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c956:	48 0f af c1          	imul   %rcx,%rax
    c95a:	48 c1 e8 20          	shr    $0x20,%rax
    c95e:	48 39 d0             	cmp    %rdx,%rax
    c961:	73 13                	jae    c976 <f0+0x14f6>
    c963:	49 01 c4             	add    %rax,%r12
    c966:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c96b:	0f 84 75 16 00 00    	je     dfe6 <f0+0x2b66>
    c971:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c976:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c97d:	33 f3 bf 
    c980:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c987:	00 
    c988:	bf 01 00 00 00       	mov    $0x1,%edi
    c98d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c994:	00 
    c995:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c99c:	00 
    c99d:	e8 3e 9b ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    c9a2:	48 8b 15 0f 82 01 00 	mov    0x1820f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c9a9:	49 89 c5             	mov    %rax,%r13
    c9ac:	48 2b 05 dd 81 01 00 	sub    0x181dd(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c9b3:	48 c1 e2 10          	shl    $0x10,%rdx
    c9b7:	48 39 d0             	cmp    %rdx,%rax
    c9ba:	73 59                	jae    ca15 <f0+0x1595>
    c9bc:	48 89 c2             	mov    %rax,%rdx
    c9bf:	48 c1 ea 10          	shr    $0x10,%rdx
    c9c3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9c7:	48 8b 15 0a 82 01 00 	mov    0x1820a(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c9ce:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9d2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9d6:	4d 85 e4             	test   %r12,%r12
    c9d9:	74 3a                	je     ca15 <f0+0x1595>
    c9db:	0f b6 0a             	movzbl (%rdx),%ecx
    c9de:	80 f9 02             	cmp    $0x2,%cl
    c9e1:	0f 84 79 14 00 00    	je     de60 <f0+0x29e0>
    c9e7:	80 f9 01             	cmp    $0x1,%cl
    c9ea:	75 29                	jne    ca15 <f0+0x1595>
    c9ec:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9ef:	0f b7 c0             	movzwl %ax,%eax
    c9f2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9f5:	48 0f af c1          	imul   %rcx,%rax
    c9f9:	48 c1 e8 20          	shr    $0x20,%rax
    c9fd:	48 39 d0             	cmp    %rdx,%rax
    ca00:	73 13                	jae    ca15 <f0+0x1595>
    ca02:	49 01 c4             	add    %rax,%r12
    ca05:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca0a:	0f 84 e3 15 00 00    	je     dff3 <f0+0x2b73>
    ca10:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca15:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca1c:	00 f0 3f 
    ca1f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    ca26:	00 
    ca27:	bf 01 00 00 00       	mov    $0x1,%edi
    ca2c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    ca33:	00 
    ca34:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    ca3b:	00 
    ca3c:	e8 9f 9a ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ca41:	48 8b 15 70 81 01 00 	mov    0x18170(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ca48:	49 89 c5             	mov    %rax,%r13
    ca4b:	48 2b 05 3e 81 01 00 	sub    0x1813e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ca52:	48 c1 e2 10          	shl    $0x10,%rdx
    ca56:	48 39 d0             	cmp    %rdx,%rax
    ca59:	73 59                	jae    cab4 <f0+0x1634>
    ca5b:	48 89 c2             	mov    %rax,%rdx
    ca5e:	48 c1 ea 10          	shr    $0x10,%rdx
    ca62:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca66:	48 8b 15 6b 81 01 00 	mov    0x1816b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ca6d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca71:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca75:	4d 85 e4             	test   %r12,%r12
    ca78:	74 3a                	je     cab4 <f0+0x1634>
    ca7a:	0f b6 0a             	movzbl (%rdx),%ecx
    ca7d:	80 f9 02             	cmp    $0x2,%cl
    ca80:	0f 84 ca 13 00 00    	je     de50 <f0+0x29d0>
    ca86:	80 f9 01             	cmp    $0x1,%cl
    ca89:	75 29                	jne    cab4 <f0+0x1634>
    ca8b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca8e:	0f b7 c0             	movzwl %ax,%eax
    ca91:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca94:	48 0f af c1          	imul   %rcx,%rax
    ca98:	48 c1 e8 20          	shr    $0x20,%rax
    ca9c:	48 39 d0             	cmp    %rdx,%rax
    ca9f:	73 13                	jae    cab4 <f0+0x1634>
    caa1:	49 01 c4             	add    %rax,%r12
    caa4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caa9:	0f 84 51 15 00 00    	je     e000 <f0+0x2b80>
    caaf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cab4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cabb:	33 f3 bf 
    cabe:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cac5:	00 
    cac6:	bf 01 00 00 00       	mov    $0x1,%edi
    cacb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cad2:	00 
    cad3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cada:	00 
    cadb:	e8 00 9a ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cae0:	48 8b 15 d1 80 01 00 	mov    0x180d1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cae7:	49 89 c5             	mov    %rax,%r13
    caea:	48 2b 05 9f 80 01 00 	sub    0x1809f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    caf1:	48 c1 e2 10          	shl    $0x10,%rdx
    caf5:	48 39 d0             	cmp    %rdx,%rax
    caf8:	73 59                	jae    cb53 <f0+0x16d3>
    cafa:	48 89 c2             	mov    %rax,%rdx
    cafd:	48 c1 ea 10          	shr    $0x10,%rdx
    cb01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb05:	48 8b 15 cc 80 01 00 	mov    0x180cc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cb0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb10:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb14:	4d 85 e4             	test   %r12,%r12
    cb17:	74 3a                	je     cb53 <f0+0x16d3>
    cb19:	0f b6 0a             	movzbl (%rdx),%ecx
    cb1c:	80 f9 02             	cmp    $0x2,%cl
    cb1f:	0f 84 1b 13 00 00    	je     de40 <f0+0x29c0>
    cb25:	80 f9 01             	cmp    $0x1,%cl
    cb28:	75 29                	jne    cb53 <f0+0x16d3>
    cb2a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb2d:	0f b7 c0             	movzwl %ax,%eax
    cb30:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb33:	48 0f af c1          	imul   %rcx,%rax
    cb37:	48 c1 e8 20          	shr    $0x20,%rax
    cb3b:	48 39 d0             	cmp    %rdx,%rax
    cb3e:	73 13                	jae    cb53 <f0+0x16d3>
    cb40:	49 01 c4             	add    %rax,%r12
    cb43:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb48:	0f 84 bf 14 00 00    	je     e00d <f0+0x2b8d>
    cb4e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb53:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb5a:	00 f0 3f 
    cb5d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cb64:	00 
    cb65:	bf 01 00 00 00       	mov    $0x1,%edi
    cb6a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cb71:	00 
    cb72:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cb79:	00 
    cb7a:	e8 61 99 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cb7f:	48 8b 15 32 80 01 00 	mov    0x18032(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cb86:	49 89 c5             	mov    %rax,%r13
    cb89:	48 2b 05 00 80 01 00 	sub    0x18000(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cb90:	48 c1 e2 10          	shl    $0x10,%rdx
    cb94:	48 39 d0             	cmp    %rdx,%rax
    cb97:	73 59                	jae    cbf2 <f0+0x1772>
    cb99:	48 89 c2             	mov    %rax,%rdx
    cb9c:	48 c1 ea 10          	shr    $0x10,%rdx
    cba0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cba4:	48 8b 15 2d 80 01 00 	mov    0x1802d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cbab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbaf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbb3:	4d 85 e4             	test   %r12,%r12
    cbb6:	74 3a                	je     cbf2 <f0+0x1772>
    cbb8:	0f b6 0a             	movzbl (%rdx),%ecx
    cbbb:	80 f9 02             	cmp    $0x2,%cl
    cbbe:	0f 84 6c 12 00 00    	je     de30 <f0+0x29b0>
    cbc4:	80 f9 01             	cmp    $0x1,%cl
    cbc7:	75 29                	jne    cbf2 <f0+0x1772>
    cbc9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbcc:	0f b7 c0             	movzwl %ax,%eax
    cbcf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbd2:	48 0f af c1          	imul   %rcx,%rax
    cbd6:	48 c1 e8 20          	shr    $0x20,%rax
    cbda:	48 39 d0             	cmp    %rdx,%rax
    cbdd:	73 13                	jae    cbf2 <f0+0x1772>
    cbdf:	49 01 c4             	add    %rax,%r12
    cbe2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbe7:	0f 84 2d 14 00 00    	je     e01a <f0+0x2b9a>
    cbed:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbf2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbf9:	33 f3 bf 
    cbfc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    cc03:	00 
    cc04:	bf 01 00 00 00       	mov    $0x1,%edi
    cc09:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    cc10:	00 
    cc11:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    cc18:	00 
    cc19:	e8 c2 98 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cc1e:	48 8b 15 93 7f 01 00 	mov    0x17f93(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cc25:	49 89 c5             	mov    %rax,%r13
    cc28:	48 2b 05 61 7f 01 00 	sub    0x17f61(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cc2f:	48 c1 e2 10          	shl    $0x10,%rdx
    cc33:	48 39 d0             	cmp    %rdx,%rax
    cc36:	73 59                	jae    cc91 <f0+0x1811>
    cc38:	48 89 c2             	mov    %rax,%rdx
    cc3b:	48 c1 ea 10          	shr    $0x10,%rdx
    cc3f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc43:	48 8b 15 8e 7f 01 00 	mov    0x17f8e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cc4a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc4e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc52:	4d 85 e4             	test   %r12,%r12
    cc55:	74 3a                	je     cc91 <f0+0x1811>
    cc57:	0f b6 0a             	movzbl (%rdx),%ecx
    cc5a:	80 f9 02             	cmp    $0x2,%cl
    cc5d:	0f 84 bd 11 00 00    	je     de20 <f0+0x29a0>
    cc63:	80 f9 01             	cmp    $0x1,%cl
    cc66:	75 29                	jne    cc91 <f0+0x1811>
    cc68:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc6b:	0f b7 c0             	movzwl %ax,%eax
    cc6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc71:	48 0f af c1          	imul   %rcx,%rax
    cc75:	48 c1 e8 20          	shr    $0x20,%rax
    cc79:	48 39 d0             	cmp    %rdx,%rax
    cc7c:	73 13                	jae    cc91 <f0+0x1811>
    cc7e:	49 01 c4             	add    %rax,%r12
    cc81:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc86:	0f 84 9b 13 00 00    	je     e027 <f0+0x2ba7>
    cc8c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc91:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc98:	00 f0 3f 
    cc9b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cca2:	00 
    cca3:	bf 01 00 00 00       	mov    $0x1,%edi
    cca8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    ccaf:	00 
    ccb0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    ccb7:	00 
    ccb8:	e8 23 98 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ccbd:	48 8b 15 f4 7e 01 00 	mov    0x17ef4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ccc4:	49 89 c5             	mov    %rax,%r13
    ccc7:	48 2b 05 c2 7e 01 00 	sub    0x17ec2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ccce:	48 c1 e2 10          	shl    $0x10,%rdx
    ccd2:	48 39 d0             	cmp    %rdx,%rax
    ccd5:	73 59                	jae    cd30 <f0+0x18b0>
    ccd7:	48 89 c2             	mov    %rax,%rdx
    ccda:	48 c1 ea 10          	shr    $0x10,%rdx
    ccde:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cce2:	48 8b 15 ef 7e 01 00 	mov    0x17eef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cce9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cced:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccf1:	4d 85 e4             	test   %r12,%r12
    ccf4:	74 3a                	je     cd30 <f0+0x18b0>
    ccf6:	0f b6 0a             	movzbl (%rdx),%ecx
    ccf9:	80 f9 02             	cmp    $0x2,%cl
    ccfc:	0f 84 0e 11 00 00    	je     de10 <f0+0x2990>
    cd02:	80 f9 01             	cmp    $0x1,%cl
    cd05:	75 29                	jne    cd30 <f0+0x18b0>
    cd07:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd0a:	0f b7 c0             	movzwl %ax,%eax
    cd0d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd10:	48 0f af c1          	imul   %rcx,%rax
    cd14:	48 c1 e8 20          	shr    $0x20,%rax
    cd18:	48 39 d0             	cmp    %rdx,%rax
    cd1b:	73 13                	jae    cd30 <f0+0x18b0>
    cd1d:	49 01 c4             	add    %rax,%r12
    cd20:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd25:	0f 84 09 13 00 00    	je     e034 <f0+0x2bb4>
    cd2b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd30:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd37:	33 f3 bf 
    cd3a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cd41:	00 
    cd42:	bf 01 00 00 00       	mov    $0x1,%edi
    cd47:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cd4e:	00 
    cd4f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cd56:	00 
    cd57:	e8 84 97 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cd5c:	48 8b 15 55 7e 01 00 	mov    0x17e55(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cd63:	49 89 c5             	mov    %rax,%r13
    cd66:	48 2b 05 23 7e 01 00 	sub    0x17e23(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cd6d:	48 c1 e2 10          	shl    $0x10,%rdx
    cd71:	48 39 d0             	cmp    %rdx,%rax
    cd74:	73 59                	jae    cdcf <f0+0x194f>
    cd76:	48 89 c2             	mov    %rax,%rdx
    cd79:	48 c1 ea 10          	shr    $0x10,%rdx
    cd7d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd81:	48 8b 15 50 7e 01 00 	mov    0x17e50(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cd88:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd8c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd90:	4d 85 e4             	test   %r12,%r12
    cd93:	74 3a                	je     cdcf <f0+0x194f>
    cd95:	0f b6 0a             	movzbl (%rdx),%ecx
    cd98:	80 f9 02             	cmp    $0x2,%cl
    cd9b:	0f 84 5f 10 00 00    	je     de00 <f0+0x2980>
    cda1:	80 f9 01             	cmp    $0x1,%cl
    cda4:	75 29                	jne    cdcf <f0+0x194f>
    cda6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cda9:	0f b7 c0             	movzwl %ax,%eax
    cdac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdaf:	48 0f af c1          	imul   %rcx,%rax
    cdb3:	48 c1 e8 20          	shr    $0x20,%rax
    cdb7:	48 39 d0             	cmp    %rdx,%rax
    cdba:	73 13                	jae    cdcf <f0+0x194f>
    cdbc:	49 01 c4             	add    %rax,%r12
    cdbf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cdc4:	0f 84 77 12 00 00    	je     e041 <f0+0x2bc1>
    cdca:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdcf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdd6:	00 f0 3f 
    cdd9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cde0:	00 
    cde1:	bf 01 00 00 00       	mov    $0x1,%edi
    cde6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cded:	00 
    cdee:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cdf5:	00 
    cdf6:	e8 e5 96 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cdfb:	48 8b 15 b6 7d 01 00 	mov    0x17db6(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ce02:	49 89 c5             	mov    %rax,%r13
    ce05:	48 2b 05 84 7d 01 00 	sub    0x17d84(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ce0c:	48 c1 e2 10          	shl    $0x10,%rdx
    ce10:	48 39 d0             	cmp    %rdx,%rax
    ce13:	73 59                	jae    ce6e <f0+0x19ee>
    ce15:	48 89 c2             	mov    %rax,%rdx
    ce18:	48 c1 ea 10          	shr    $0x10,%rdx
    ce1c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce20:	48 8b 15 b1 7d 01 00 	mov    0x17db1(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ce27:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce2b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce2f:	4d 85 e4             	test   %r12,%r12
    ce32:	74 3a                	je     ce6e <f0+0x19ee>
    ce34:	0f b6 0a             	movzbl (%rdx),%ecx
    ce37:	80 f9 02             	cmp    $0x2,%cl
    ce3a:	0f 84 40 0f 00 00    	je     dd80 <f0+0x2900>
    ce40:	80 f9 01             	cmp    $0x1,%cl
    ce43:	75 29                	jne    ce6e <f0+0x19ee>
    ce45:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce48:	0f b7 c0             	movzwl %ax,%eax
    ce4b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce4e:	48 0f af c1          	imul   %rcx,%rax
    ce52:	48 c1 e8 20          	shr    $0x20,%rax
    ce56:	48 39 d0             	cmp    %rdx,%rax
    ce59:	73 13                	jae    ce6e <f0+0x19ee>
    ce5b:	49 01 c4             	add    %rax,%r12
    ce5e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce63:	0f 84 e5 11 00 00    	je     e04e <f0+0x2bce>
    ce69:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce6e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce75:	33 f3 bf 
    ce78:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    ce7f:	00 
    ce80:	bf 01 00 00 00       	mov    $0x1,%edi
    ce85:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    ce8c:	00 
    ce8d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    ce94:	00 
    ce95:	e8 46 96 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    ce9a:	48 8b 15 17 7d 01 00 	mov    0x17d17(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cea1:	49 89 c5             	mov    %rax,%r13
    cea4:	48 2b 05 e5 7c 01 00 	sub    0x17ce5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ceab:	48 c1 e2 10          	shl    $0x10,%rdx
    ceaf:	48 39 d0             	cmp    %rdx,%rax
    ceb2:	73 59                	jae    cf0d <f0+0x1a8d>
    ceb4:	48 89 c2             	mov    %rax,%rdx
    ceb7:	48 c1 ea 10          	shr    $0x10,%rdx
    cebb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cebf:	48 8b 15 12 7d 01 00 	mov    0x17d12(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cec6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ceca:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cece:	4d 85 e4             	test   %r12,%r12
    ced1:	74 3a                	je     cf0d <f0+0x1a8d>
    ced3:	0f b6 0a             	movzbl (%rdx),%ecx
    ced6:	80 f9 02             	cmp    $0x2,%cl
    ced9:	0f 84 91 0e 00 00    	je     dd70 <f0+0x28f0>
    cedf:	80 f9 01             	cmp    $0x1,%cl
    cee2:	75 29                	jne    cf0d <f0+0x1a8d>
    cee4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cee7:	0f b7 c0             	movzwl %ax,%eax
    ceea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceed:	48 0f af c1          	imul   %rcx,%rax
    cef1:	48 c1 e8 20          	shr    $0x20,%rax
    cef5:	48 39 d0             	cmp    %rdx,%rax
    cef8:	73 13                	jae    cf0d <f0+0x1a8d>
    cefa:	49 01 c4             	add    %rax,%r12
    cefd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf02:	0f 84 53 11 00 00    	je     e05b <f0+0x2bdb>
    cf08:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf0d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf14:	00 f0 3f 
    cf17:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cf1e:	00 
    cf1f:	bf 01 00 00 00       	mov    $0x1,%edi
    cf24:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cf2b:	00 
    cf2c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cf33:	00 
    cf34:	e8 a7 95 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cf39:	48 8b 15 78 7c 01 00 	mov    0x17c78(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cf40:	49 89 c5             	mov    %rax,%r13
    cf43:	48 2b 05 46 7c 01 00 	sub    0x17c46(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cf4a:	48 c1 e2 10          	shl    $0x10,%rdx
    cf4e:	48 39 d0             	cmp    %rdx,%rax
    cf51:	73 59                	jae    cfac <f0+0x1b2c>
    cf53:	48 89 c2             	mov    %rax,%rdx
    cf56:	48 c1 ea 10          	shr    $0x10,%rdx
    cf5a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf5e:	48 8b 15 73 7c 01 00 	mov    0x17c73(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cf65:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf69:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf6d:	4d 85 e4             	test   %r12,%r12
    cf70:	74 3a                	je     cfac <f0+0x1b2c>
    cf72:	0f b6 0a             	movzbl (%rdx),%ecx
    cf75:	80 f9 02             	cmp    $0x2,%cl
    cf78:	0f 84 e2 0d 00 00    	je     dd60 <f0+0x28e0>
    cf7e:	80 f9 01             	cmp    $0x1,%cl
    cf81:	75 29                	jne    cfac <f0+0x1b2c>
    cf83:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf86:	0f b7 c0             	movzwl %ax,%eax
    cf89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf8c:	48 0f af c1          	imul   %rcx,%rax
    cf90:	48 c1 e8 20          	shr    $0x20,%rax
    cf94:	48 39 d0             	cmp    %rdx,%rax
    cf97:	73 13                	jae    cfac <f0+0x1b2c>
    cf99:	49 01 c4             	add    %rax,%r12
    cf9c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfa1:	0f 84 c1 10 00 00    	je     e068 <f0+0x2be8>
    cfa7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfac:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfb3:	33 f3 bf 
    cfb6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cfbd:	00 
    cfbe:	bf 01 00 00 00       	mov    $0x1,%edi
    cfc3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cfca:	00 
    cfcb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cfd2:	00 
    cfd3:	e8 08 95 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    cfd8:	48 8b 15 d9 7b 01 00 	mov    0x17bd9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cfdf:	49 89 c5             	mov    %rax,%r13
    cfe2:	48 2b 05 a7 7b 01 00 	sub    0x17ba7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cfe9:	48 c1 e2 10          	shl    $0x10,%rdx
    cfed:	48 39 d0             	cmp    %rdx,%rax
    cff0:	73 59                	jae    d04b <f0+0x1bcb>
    cff2:	48 89 c2             	mov    %rax,%rdx
    cff5:	48 c1 ea 10          	shr    $0x10,%rdx
    cff9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cffd:	48 8b 15 d4 7b 01 00 	mov    0x17bd4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d004:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d008:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d00c:	4d 85 e4             	test   %r12,%r12
    d00f:	74 3a                	je     d04b <f0+0x1bcb>
    d011:	0f b6 0a             	movzbl (%rdx),%ecx
    d014:	80 f9 02             	cmp    $0x2,%cl
    d017:	0f 84 33 0d 00 00    	je     dd50 <f0+0x28d0>
    d01d:	80 f9 01             	cmp    $0x1,%cl
    d020:	75 29                	jne    d04b <f0+0x1bcb>
    d022:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d025:	0f b7 c0             	movzwl %ax,%eax
    d028:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d02b:	48 0f af c1          	imul   %rcx,%rax
    d02f:	48 c1 e8 20          	shr    $0x20,%rax
    d033:	48 39 d0             	cmp    %rdx,%rax
    d036:	73 13                	jae    d04b <f0+0x1bcb>
    d038:	49 01 c4             	add    %rax,%r12
    d03b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d040:	0f 84 2f 10 00 00    	je     e075 <f0+0x2bf5>
    d046:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d04b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d052:	00 f0 3f 
    d055:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d05c:	00 
    d05d:	bf 01 00 00 00       	mov    $0x1,%edi
    d062:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d069:	00 
    d06a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d071:	00 
    d072:	e8 69 94 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d077:	48 8b 15 3a 7b 01 00 	mov    0x17b3a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d07e:	49 89 c5             	mov    %rax,%r13
    d081:	48 2b 05 08 7b 01 00 	sub    0x17b08(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d088:	48 c1 e2 10          	shl    $0x10,%rdx
    d08c:	48 39 d0             	cmp    %rdx,%rax
    d08f:	73 59                	jae    d0ea <f0+0x1c6a>
    d091:	48 89 c2             	mov    %rax,%rdx
    d094:	48 c1 ea 10          	shr    $0x10,%rdx
    d098:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d09c:	48 8b 15 35 7b 01 00 	mov    0x17b35(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d0a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0a7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0ab:	4d 85 e4             	test   %r12,%r12
    d0ae:	74 3a                	je     d0ea <f0+0x1c6a>
    d0b0:	0f b6 0a             	movzbl (%rdx),%ecx
    d0b3:	80 f9 02             	cmp    $0x2,%cl
    d0b6:	0f 84 84 0c 00 00    	je     dd40 <f0+0x28c0>
    d0bc:	80 f9 01             	cmp    $0x1,%cl
    d0bf:	75 29                	jne    d0ea <f0+0x1c6a>
    d0c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0c4:	0f b7 c0             	movzwl %ax,%eax
    d0c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0ca:	48 0f af c1          	imul   %rcx,%rax
    d0ce:	48 c1 e8 20          	shr    $0x20,%rax
    d0d2:	48 39 d0             	cmp    %rdx,%rax
    d0d5:	73 13                	jae    d0ea <f0+0x1c6a>
    d0d7:	49 01 c4             	add    %rax,%r12
    d0da:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0df:	0f 84 9d 0f 00 00    	je     e082 <f0+0x2c02>
    d0e5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ea:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0f1:	33 f3 bf 
    d0f4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d0fb:	00 
    d0fc:	bf 01 00 00 00       	mov    $0x1,%edi
    d101:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d108:	00 
    d109:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d110:	00 
    d111:	e8 ca 93 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d116:	48 8b 15 9b 7a 01 00 	mov    0x17a9b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d11d:	49 89 c5             	mov    %rax,%r13
    d120:	48 2b 05 69 7a 01 00 	sub    0x17a69(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d127:	48 c1 e2 10          	shl    $0x10,%rdx
    d12b:	48 39 d0             	cmp    %rdx,%rax
    d12e:	73 59                	jae    d189 <f0+0x1d09>
    d130:	48 89 c2             	mov    %rax,%rdx
    d133:	48 c1 ea 10          	shr    $0x10,%rdx
    d137:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d13b:	48 8b 15 96 7a 01 00 	mov    0x17a96(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d142:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d146:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d14a:	4d 85 e4             	test   %r12,%r12
    d14d:	74 3a                	je     d189 <f0+0x1d09>
    d14f:	0f b6 0a             	movzbl (%rdx),%ecx
    d152:	80 f9 02             	cmp    $0x2,%cl
    d155:	0f 84 d5 0b 00 00    	je     dd30 <f0+0x28b0>
    d15b:	80 f9 01             	cmp    $0x1,%cl
    d15e:	75 29                	jne    d189 <f0+0x1d09>
    d160:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d163:	0f b7 c0             	movzwl %ax,%eax
    d166:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d169:	48 0f af c1          	imul   %rcx,%rax
    d16d:	48 c1 e8 20          	shr    $0x20,%rax
    d171:	48 39 d0             	cmp    %rdx,%rax
    d174:	73 13                	jae    d189 <f0+0x1d09>
    d176:	49 01 c4             	add    %rax,%r12
    d179:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d17e:	0f 84 0b 0f 00 00    	je     e08f <f0+0x2c0f>
    d184:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d189:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d190:	00 f0 3f 
    d193:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d19a:	00 
    d19b:	bf 01 00 00 00       	mov    $0x1,%edi
    d1a0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d1a7:	00 
    d1a8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d1af:	00 
    d1b0:	e8 2b 93 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d1b5:	48 8b 15 fc 79 01 00 	mov    0x179fc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d1bc:	49 89 c5             	mov    %rax,%r13
    d1bf:	48 2b 05 ca 79 01 00 	sub    0x179ca(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d1c6:	48 c1 e2 10          	shl    $0x10,%rdx
    d1ca:	48 39 d0             	cmp    %rdx,%rax
    d1cd:	73 59                	jae    d228 <f0+0x1da8>
    d1cf:	48 89 c2             	mov    %rax,%rdx
    d1d2:	48 c1 ea 10          	shr    $0x10,%rdx
    d1d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1da:	48 8b 15 f7 79 01 00 	mov    0x179f7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d1e1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1e5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1e9:	4d 85 e4             	test   %r12,%r12
    d1ec:	74 3a                	je     d228 <f0+0x1da8>
    d1ee:	0f b6 0a             	movzbl (%rdx),%ecx
    d1f1:	80 f9 02             	cmp    $0x2,%cl
    d1f4:	0f 84 26 0b 00 00    	je     dd20 <f0+0x28a0>
    d1fa:	80 f9 01             	cmp    $0x1,%cl
    d1fd:	75 29                	jne    d228 <f0+0x1da8>
    d1ff:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d202:	0f b7 c0             	movzwl %ax,%eax
    d205:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d208:	48 0f af c1          	imul   %rcx,%rax
    d20c:	48 c1 e8 20          	shr    $0x20,%rax
    d210:	48 39 d0             	cmp    %rdx,%rax
    d213:	73 13                	jae    d228 <f0+0x1da8>
    d215:	49 01 c4             	add    %rax,%r12
    d218:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d21d:	0f 84 79 0e 00 00    	je     e09c <f0+0x2c1c>
    d223:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d228:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d22f:	33 f3 bf 
    d232:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d239:	00 
    d23a:	bf 01 00 00 00       	mov    $0x1,%edi
    d23f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d246:	00 
    d247:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d24e:	00 
    d24f:	e8 8c 92 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d254:	48 8b 15 5d 79 01 00 	mov    0x1795d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d25b:	49 89 c5             	mov    %rax,%r13
    d25e:	48 2b 05 2b 79 01 00 	sub    0x1792b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d265:	48 c1 e2 10          	shl    $0x10,%rdx
    d269:	48 39 d0             	cmp    %rdx,%rax
    d26c:	73 59                	jae    d2c7 <f0+0x1e47>
    d26e:	48 89 c2             	mov    %rax,%rdx
    d271:	48 c1 ea 10          	shr    $0x10,%rdx
    d275:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d279:	48 8b 15 58 79 01 00 	mov    0x17958(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d280:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d284:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d288:	4d 85 e4             	test   %r12,%r12
    d28b:	74 3a                	je     d2c7 <f0+0x1e47>
    d28d:	0f b6 0a             	movzbl (%rdx),%ecx
    d290:	80 f9 02             	cmp    $0x2,%cl
    d293:	0f 84 77 0a 00 00    	je     dd10 <f0+0x2890>
    d299:	80 f9 01             	cmp    $0x1,%cl
    d29c:	75 29                	jne    d2c7 <f0+0x1e47>
    d29e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2a1:	0f b7 c0             	movzwl %ax,%eax
    d2a4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2a7:	48 0f af c1          	imul   %rcx,%rax
    d2ab:	48 c1 e8 20          	shr    $0x20,%rax
    d2af:	48 39 d0             	cmp    %rdx,%rax
    d2b2:	73 13                	jae    d2c7 <f0+0x1e47>
    d2b4:	49 01 c4             	add    %rax,%r12
    d2b7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2bc:	0f 84 e7 0d 00 00    	je     e0a9 <f0+0x2c29>
    d2c2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2c7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2ce:	00 f0 3f 
    d2d1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d2d8:	00 
    d2d9:	bf 01 00 00 00       	mov    $0x1,%edi
    d2de:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d2e5:	00 
    d2e6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d2ed:	00 
    d2ee:	e8 ed 91 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d2f3:	48 8b 15 be 78 01 00 	mov    0x178be(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d2fa:	49 89 c5             	mov    %rax,%r13
    d2fd:	48 2b 05 8c 78 01 00 	sub    0x1788c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d304:	48 c1 e2 10          	shl    $0x10,%rdx
    d308:	48 39 d0             	cmp    %rdx,%rax
    d30b:	73 59                	jae    d366 <f0+0x1ee6>
    d30d:	48 89 c2             	mov    %rax,%rdx
    d310:	48 c1 ea 10          	shr    $0x10,%rdx
    d314:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d318:	48 8b 15 b9 78 01 00 	mov    0x178b9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d31f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d323:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d327:	4d 85 e4             	test   %r12,%r12
    d32a:	74 3a                	je     d366 <f0+0x1ee6>
    d32c:	0f b6 0a             	movzbl (%rdx),%ecx
    d32f:	80 f9 02             	cmp    $0x2,%cl
    d332:	0f 84 38 0c 00 00    	je     df70 <f0+0x2af0>
    d338:	80 f9 01             	cmp    $0x1,%cl
    d33b:	75 29                	jne    d366 <f0+0x1ee6>
    d33d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d340:	0f b7 c0             	movzwl %ax,%eax
    d343:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d346:	48 0f af c1          	imul   %rcx,%rax
    d34a:	48 c1 e8 20          	shr    $0x20,%rax
    d34e:	48 39 d0             	cmp    %rdx,%rax
    d351:	73 13                	jae    d366 <f0+0x1ee6>
    d353:	49 01 c4             	add    %rax,%r12
    d356:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d35b:	0f 84 55 0d 00 00    	je     e0b6 <f0+0x2c36>
    d361:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d366:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d36d:	33 f3 bf 
    d370:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d377:	00 
    d378:	bf 01 00 00 00       	mov    $0x1,%edi
    d37d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d384:	00 
    d385:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d38c:	00 
    d38d:	e8 4e 91 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d392:	48 8b 15 1f 78 01 00 	mov    0x1781f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d399:	49 89 c5             	mov    %rax,%r13
    d39c:	48 2b 05 ed 77 01 00 	sub    0x177ed(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d3a3:	48 c1 e2 10          	shl    $0x10,%rdx
    d3a7:	48 39 d0             	cmp    %rdx,%rax
    d3aa:	73 59                	jae    d405 <f0+0x1f85>
    d3ac:	48 89 c2             	mov    %rax,%rdx
    d3af:	48 c1 ea 10          	shr    $0x10,%rdx
    d3b3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3b7:	48 8b 15 1a 78 01 00 	mov    0x1781a(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d3be:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3c2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3c6:	4d 85 e4             	test   %r12,%r12
    d3c9:	74 3a                	je     d405 <f0+0x1f85>
    d3cb:	0f b6 0a             	movzbl (%rdx),%ecx
    d3ce:	80 f9 02             	cmp    $0x2,%cl
    d3d1:	0f 84 89 0b 00 00    	je     df60 <f0+0x2ae0>
    d3d7:	80 f9 01             	cmp    $0x1,%cl
    d3da:	75 29                	jne    d405 <f0+0x1f85>
    d3dc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3df:	0f b7 c0             	movzwl %ax,%eax
    d3e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3e5:	48 0f af c1          	imul   %rcx,%rax
    d3e9:	48 c1 e8 20          	shr    $0x20,%rax
    d3ed:	48 39 d0             	cmp    %rdx,%rax
    d3f0:	73 13                	jae    d405 <f0+0x1f85>
    d3f2:	49 01 c4             	add    %rax,%r12
    d3f5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3fa:	0f 84 c3 0c 00 00    	je     e0c3 <f0+0x2c43>
    d400:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d405:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d40c:	00 f0 3f 
    d40f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d416:	00 
    d417:	bf 01 00 00 00       	mov    $0x1,%edi
    d41c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d423:	00 
    d424:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d42b:	00 
    d42c:	e8 af 90 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d431:	48 8b 15 80 77 01 00 	mov    0x17780(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d438:	49 89 c5             	mov    %rax,%r13
    d43b:	48 2b 05 4e 77 01 00 	sub    0x1774e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d442:	48 c1 e2 10          	shl    $0x10,%rdx
    d446:	48 39 d0             	cmp    %rdx,%rax
    d449:	73 59                	jae    d4a4 <f0+0x2024>
    d44b:	48 89 c2             	mov    %rax,%rdx
    d44e:	48 c1 ea 10          	shr    $0x10,%rdx
    d452:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d456:	48 8b 15 7b 77 01 00 	mov    0x1777b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d45d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d461:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d465:	4d 85 e4             	test   %r12,%r12
    d468:	74 3a                	je     d4a4 <f0+0x2024>
    d46a:	0f b6 0a             	movzbl (%rdx),%ecx
    d46d:	80 f9 02             	cmp    $0x2,%cl
    d470:	0f 84 da 0a 00 00    	je     df50 <f0+0x2ad0>
    d476:	80 f9 01             	cmp    $0x1,%cl
    d479:	75 29                	jne    d4a4 <f0+0x2024>
    d47b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d47e:	0f b7 c0             	movzwl %ax,%eax
    d481:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d484:	48 0f af c1          	imul   %rcx,%rax
    d488:	48 c1 e8 20          	shr    $0x20,%rax
    d48c:	48 39 d0             	cmp    %rdx,%rax
    d48f:	73 13                	jae    d4a4 <f0+0x2024>
    d491:	49 01 c4             	add    %rax,%r12
    d494:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d499:	0f 84 31 0c 00 00    	je     e0d0 <f0+0x2c50>
    d49f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4a4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d4ab:	33 f3 bf 
    d4ae:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d4b5:	00 
    d4b6:	bf 01 00 00 00       	mov    $0x1,%edi
    d4bb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d4c2:	00 
    d4c3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d4ca:	00 
    d4cb:	e8 10 90 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d4d0:	48 8b 15 e1 76 01 00 	mov    0x176e1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d4d7:	49 89 c5             	mov    %rax,%r13
    d4da:	48 2b 05 af 76 01 00 	sub    0x176af(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d4e1:	48 c1 e2 10          	shl    $0x10,%rdx
    d4e5:	48 39 d0             	cmp    %rdx,%rax
    d4e8:	73 59                	jae    d543 <f0+0x20c3>
    d4ea:	48 89 c2             	mov    %rax,%rdx
    d4ed:	48 c1 ea 10          	shr    $0x10,%rdx
    d4f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4f5:	48 8b 15 dc 76 01 00 	mov    0x176dc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d4fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d500:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d504:	4d 85 e4             	test   %r12,%r12
    d507:	74 3a                	je     d543 <f0+0x20c3>
    d509:	0f b6 0a             	movzbl (%rdx),%ecx
    d50c:	80 f9 02             	cmp    $0x2,%cl
    d50f:	0f 84 2b 0a 00 00    	je     df40 <f0+0x2ac0>
    d515:	80 f9 01             	cmp    $0x1,%cl
    d518:	75 29                	jne    d543 <f0+0x20c3>
    d51a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d51d:	0f b7 c0             	movzwl %ax,%eax
    d520:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d523:	48 0f af c1          	imul   %rcx,%rax
    d527:	48 c1 e8 20          	shr    $0x20,%rax
    d52b:	48 39 d0             	cmp    %rdx,%rax
    d52e:	73 13                	jae    d543 <f0+0x20c3>
    d530:	49 01 c4             	add    %rax,%r12
    d533:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d538:	0f 84 9f 0b 00 00    	je     e0dd <f0+0x2c5d>
    d53e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d543:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d54a:	00 f0 3f 
    d54d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d554:	00 
    d555:	bf 01 00 00 00       	mov    $0x1,%edi
    d55a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d561:	00 
    d562:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d569:	00 
    d56a:	e8 71 8f ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d56f:	48 8b 15 42 76 01 00 	mov    0x17642(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d576:	49 89 c5             	mov    %rax,%r13
    d579:	48 2b 05 10 76 01 00 	sub    0x17610(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d580:	48 c1 e2 10          	shl    $0x10,%rdx
    d584:	48 39 d0             	cmp    %rdx,%rax
    d587:	73 59                	jae    d5e2 <f0+0x2162>
    d589:	48 89 c2             	mov    %rax,%rdx
    d58c:	48 c1 ea 10          	shr    $0x10,%rdx
    d590:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d594:	48 8b 15 3d 76 01 00 	mov    0x1763d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d59b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d59f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5a3:	4d 85 e4             	test   %r12,%r12
    d5a6:	74 3a                	je     d5e2 <f0+0x2162>
    d5a8:	0f b6 0a             	movzbl (%rdx),%ecx
    d5ab:	80 f9 02             	cmp    $0x2,%cl
    d5ae:	0f 84 7c 09 00 00    	je     df30 <f0+0x2ab0>
    d5b4:	80 f9 01             	cmp    $0x1,%cl
    d5b7:	75 29                	jne    d5e2 <f0+0x2162>
    d5b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5bc:	0f b7 c0             	movzwl %ax,%eax
    d5bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5c2:	48 0f af c1          	imul   %rcx,%rax
    d5c6:	48 c1 e8 20          	shr    $0x20,%rax
    d5ca:	48 39 d0             	cmp    %rdx,%rax
    d5cd:	73 13                	jae    d5e2 <f0+0x2162>
    d5cf:	49 01 c4             	add    %rax,%r12
    d5d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5d7:	0f 84 0d 0b 00 00    	je     e0ea <f0+0x2c6a>
    d5dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5e2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5e9:	33 f3 bf 
    d5ec:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d5f3:	00 
    d5f4:	bf 01 00 00 00       	mov    $0x1,%edi
    d5f9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d600:	00 
    d601:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d608:	00 
    d609:	e8 d2 8e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d60e:	48 8b 15 a3 75 01 00 	mov    0x175a3(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d615:	49 89 c5             	mov    %rax,%r13
    d618:	48 2b 05 71 75 01 00 	sub    0x17571(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d61f:	48 c1 e2 10          	shl    $0x10,%rdx
    d623:	48 39 d0             	cmp    %rdx,%rax
    d626:	73 59                	jae    d681 <f0+0x2201>
    d628:	48 89 c2             	mov    %rax,%rdx
    d62b:	48 c1 ea 10          	shr    $0x10,%rdx
    d62f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d633:	48 8b 15 9e 75 01 00 	mov    0x1759e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d63a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d63e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d642:	4d 85 e4             	test   %r12,%r12
    d645:	74 3a                	je     d681 <f0+0x2201>
    d647:	0f b6 0a             	movzbl (%rdx),%ecx
    d64a:	80 f9 02             	cmp    $0x2,%cl
    d64d:	0f 84 cd 08 00 00    	je     df20 <f0+0x2aa0>
    d653:	80 f9 01             	cmp    $0x1,%cl
    d656:	75 29                	jne    d681 <f0+0x2201>
    d658:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d65b:	0f b7 c0             	movzwl %ax,%eax
    d65e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d661:	48 0f af c1          	imul   %rcx,%rax
    d665:	48 c1 e8 20          	shr    $0x20,%rax
    d669:	48 39 d0             	cmp    %rdx,%rax
    d66c:	73 13                	jae    d681 <f0+0x2201>
    d66e:	49 01 c4             	add    %rax,%r12
    d671:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d676:	0f 84 7b 0a 00 00    	je     e0f7 <f0+0x2c77>
    d67c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d681:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d688:	00 f0 3f 
    d68b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d692:	00 
    d693:	bf 01 00 00 00       	mov    $0x1,%edi
    d698:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d69f:	00 
    d6a0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d6a7:	00 
    d6a8:	e8 33 8e ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d6ad:	48 8b 15 04 75 01 00 	mov    0x17504(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d6b4:	49 89 c5             	mov    %rax,%r13
    d6b7:	48 2b 05 d2 74 01 00 	sub    0x174d2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d6be:	48 c1 e2 10          	shl    $0x10,%rdx
    d6c2:	48 39 d0             	cmp    %rdx,%rax
    d6c5:	73 59                	jae    d720 <f0+0x22a0>
    d6c7:	48 89 c2             	mov    %rax,%rdx
    d6ca:	48 c1 ea 10          	shr    $0x10,%rdx
    d6ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6d2:	48 8b 15 ff 74 01 00 	mov    0x174ff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d6d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6e1:	4d 85 e4             	test   %r12,%r12
    d6e4:	74 3a                	je     d720 <f0+0x22a0>
    d6e6:	0f b6 0a             	movzbl (%rdx),%ecx
    d6e9:	80 f9 02             	cmp    $0x2,%cl
    d6ec:	0f 84 1e 08 00 00    	je     df10 <f0+0x2a90>
    d6f2:	80 f9 01             	cmp    $0x1,%cl
    d6f5:	75 29                	jne    d720 <f0+0x22a0>
    d6f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6fa:	0f b7 c0             	movzwl %ax,%eax
    d6fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d700:	48 0f af c1          	imul   %rcx,%rax
    d704:	48 c1 e8 20          	shr    $0x20,%rax
    d708:	48 39 d0             	cmp    %rdx,%rax
    d70b:	73 13                	jae    d720 <f0+0x22a0>
    d70d:	49 01 c4             	add    %rax,%r12
    d710:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d715:	0f 84 e9 09 00 00    	je     e104 <f0+0x2c84>
    d71b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d720:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d727:	33 f3 bf 
    d72a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d731:	00 
    d732:	bf 01 00 00 00       	mov    $0x1,%edi
    d737:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d73e:	00 
    d73f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d746:	00 
    d747:	e8 94 8d ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d74c:	48 8b 15 65 74 01 00 	mov    0x17465(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d753:	49 89 c5             	mov    %rax,%r13
    d756:	48 2b 05 33 74 01 00 	sub    0x17433(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d75d:	48 c1 e2 10          	shl    $0x10,%rdx
    d761:	48 39 d0             	cmp    %rdx,%rax
    d764:	73 59                	jae    d7bf <f0+0x233f>
    d766:	48 89 c2             	mov    %rax,%rdx
    d769:	48 c1 ea 10          	shr    $0x10,%rdx
    d76d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d771:	48 8b 15 60 74 01 00 	mov    0x17460(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d778:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d77c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d780:	4d 85 e4             	test   %r12,%r12
    d783:	74 3a                	je     d7bf <f0+0x233f>
    d785:	0f b6 0a             	movzbl (%rdx),%ecx
    d788:	80 f9 02             	cmp    $0x2,%cl
    d78b:	0f 84 6f 07 00 00    	je     df00 <f0+0x2a80>
    d791:	80 f9 01             	cmp    $0x1,%cl
    d794:	75 29                	jne    d7bf <f0+0x233f>
    d796:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d799:	0f b7 c0             	movzwl %ax,%eax
    d79c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d79f:	48 0f af c1          	imul   %rcx,%rax
    d7a3:	48 c1 e8 20          	shr    $0x20,%rax
    d7a7:	48 39 d0             	cmp    %rdx,%rax
    d7aa:	73 13                	jae    d7bf <f0+0x233f>
    d7ac:	49 01 c4             	add    %rax,%r12
    d7af:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7b4:	0f 84 57 09 00 00    	je     e111 <f0+0x2c91>
    d7ba:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7bf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7c6:	00 f0 3f 
    d7c9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d7d0:	00 
    d7d1:	bf 01 00 00 00       	mov    $0x1,%edi
    d7d6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d7dd:	00 
    d7de:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d7e5:	00 
    d7e6:	e8 f5 8c ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d7eb:	48 8b 15 c6 73 01 00 	mov    0x173c6(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d7f2:	49 89 c5             	mov    %rax,%r13
    d7f5:	48 2b 05 94 73 01 00 	sub    0x17394(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d7fc:	48 c1 e2 10          	shl    $0x10,%rdx
    d800:	48 39 d0             	cmp    %rdx,%rax
    d803:	73 59                	jae    d85e <f0+0x23de>
    d805:	48 89 c2             	mov    %rax,%rdx
    d808:	48 c1 ea 10          	shr    $0x10,%rdx
    d80c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d810:	48 8b 15 c1 73 01 00 	mov    0x173c1(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d817:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d81b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d81f:	4d 85 e4             	test   %r12,%r12
    d822:	74 3a                	je     d85e <f0+0x23de>
    d824:	0f b6 0a             	movzbl (%rdx),%ecx
    d827:	80 f9 02             	cmp    $0x2,%cl
    d82a:	0f 84 c0 06 00 00    	je     def0 <f0+0x2a70>
    d830:	80 f9 01             	cmp    $0x1,%cl
    d833:	75 29                	jne    d85e <f0+0x23de>
    d835:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d838:	0f b7 c0             	movzwl %ax,%eax
    d83b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d83e:	48 0f af c1          	imul   %rcx,%rax
    d842:	48 c1 e8 20          	shr    $0x20,%rax
    d846:	48 39 d0             	cmp    %rdx,%rax
    d849:	73 13                	jae    d85e <f0+0x23de>
    d84b:	49 01 c4             	add    %rax,%r12
    d84e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d853:	0f 84 c5 08 00 00    	je     e11e <f0+0x2c9e>
    d859:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d85e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d865:	33 f3 bf 
    d868:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d86f:	00 
    d870:	bf 01 00 00 00       	mov    $0x1,%edi
    d875:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d87c:	00 
    d87d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d884:	00 
    d885:	e8 56 8c ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d88a:	48 8b 15 27 73 01 00 	mov    0x17327(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d891:	49 89 c5             	mov    %rax,%r13
    d894:	48 2b 05 f5 72 01 00 	sub    0x172f5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d89b:	48 c1 e2 10          	shl    $0x10,%rdx
    d89f:	48 39 d0             	cmp    %rdx,%rax
    d8a2:	73 59                	jae    d8fd <f0+0x247d>
    d8a4:	48 89 c2             	mov    %rax,%rdx
    d8a7:	48 c1 ea 10          	shr    $0x10,%rdx
    d8ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8af:	48 8b 15 22 73 01 00 	mov    0x17322(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d8b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8ba:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8be:	4d 85 e4             	test   %r12,%r12
    d8c1:	74 3a                	je     d8fd <f0+0x247d>
    d8c3:	0f b6 0a             	movzbl (%rdx),%ecx
    d8c6:	80 f9 02             	cmp    $0x2,%cl
    d8c9:	0f 84 11 06 00 00    	je     dee0 <f0+0x2a60>
    d8cf:	80 f9 01             	cmp    $0x1,%cl
    d8d2:	75 29                	jne    d8fd <f0+0x247d>
    d8d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8d7:	0f b7 c0             	movzwl %ax,%eax
    d8da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8dd:	48 0f af c1          	imul   %rcx,%rax
    d8e1:	48 c1 e8 20          	shr    $0x20,%rax
    d8e5:	48 39 d0             	cmp    %rdx,%rax
    d8e8:	73 13                	jae    d8fd <f0+0x247d>
    d8ea:	49 01 c4             	add    %rax,%r12
    d8ed:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8f2:	0f 84 33 08 00 00    	je     e12b <f0+0x2cab>
    d8f8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8fd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d904:	00 f0 3f 
    d907:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d90e:	00 
    d90f:	bf 01 00 00 00       	mov    $0x1,%edi
    d914:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d91b:	00 
    d91c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d923:	00 
    d924:	e8 b7 8b ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d929:	48 8b 15 88 72 01 00 	mov    0x17288(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d930:	49 89 c5             	mov    %rax,%r13
    d933:	48 2b 05 56 72 01 00 	sub    0x17256(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d93a:	48 c1 e2 10          	shl    $0x10,%rdx
    d93e:	48 39 d0             	cmp    %rdx,%rax
    d941:	73 59                	jae    d99c <f0+0x251c>
    d943:	48 89 c2             	mov    %rax,%rdx
    d946:	48 c1 ea 10          	shr    $0x10,%rdx
    d94a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d94e:	48 8b 15 83 72 01 00 	mov    0x17283(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d955:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d959:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d95d:	4d 85 e4             	test   %r12,%r12
    d960:	74 3a                	je     d99c <f0+0x251c>
    d962:	0f b6 0a             	movzbl (%rdx),%ecx
    d965:	80 f9 02             	cmp    $0x2,%cl
    d968:	0f 84 62 05 00 00    	je     ded0 <f0+0x2a50>
    d96e:	80 f9 01             	cmp    $0x1,%cl
    d971:	75 29                	jne    d99c <f0+0x251c>
    d973:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d976:	0f b7 c0             	movzwl %ax,%eax
    d979:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d97c:	48 0f af c1          	imul   %rcx,%rax
    d980:	48 c1 e8 20          	shr    $0x20,%rax
    d984:	48 39 d0             	cmp    %rdx,%rax
    d987:	73 13                	jae    d99c <f0+0x251c>
    d989:	49 01 c4             	add    %rax,%r12
    d98c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d991:	0f 84 a1 07 00 00    	je     e138 <f0+0x2cb8>
    d997:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d99c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d9a3:	33 f3 bf 
    d9a6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d9ad:	00 
    d9ae:	bf 01 00 00 00       	mov    $0x1,%edi
    d9b3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d9ba:	00 
    d9bb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d9c2:	00 
    d9c3:	e8 18 8b ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    d9c8:	48 8b 15 e9 71 01 00 	mov    0x171e9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d9cf:	49 89 c5             	mov    %rax,%r13
    d9d2:	48 2b 05 b7 71 01 00 	sub    0x171b7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d9d9:	48 c1 e2 10          	shl    $0x10,%rdx
    d9dd:	48 39 d0             	cmp    %rdx,%rax
    d9e0:	73 59                	jae    da3b <f0+0x25bb>
    d9e2:	48 89 c2             	mov    %rax,%rdx
    d9e5:	48 c1 ea 10          	shr    $0x10,%rdx
    d9e9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9ed:	48 8b 15 e4 71 01 00 	mov    0x171e4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d9f4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9f8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9fc:	4d 85 e4             	test   %r12,%r12
    d9ff:	74 3a                	je     da3b <f0+0x25bb>
    da01:	0f b6 0a             	movzbl (%rdx),%ecx
    da04:	80 f9 02             	cmp    $0x2,%cl
    da07:	0f 84 b3 04 00 00    	je     dec0 <f0+0x2a40>
    da0d:	80 f9 01             	cmp    $0x1,%cl
    da10:	75 29                	jne    da3b <f0+0x25bb>
    da12:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da15:	0f b7 c0             	movzwl %ax,%eax
    da18:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da1b:	48 0f af c1          	imul   %rcx,%rax
    da1f:	48 c1 e8 20          	shr    $0x20,%rax
    da23:	48 39 d0             	cmp    %rdx,%rax
    da26:	73 13                	jae    da3b <f0+0x25bb>
    da28:	49 01 c4             	add    %rax,%r12
    da2b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da30:	0f 84 0f 07 00 00    	je     e145 <f0+0x2cc5>
    da36:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da3b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da42:	00 f0 3f 
    da45:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    da4c:	00 
    da4d:	bf 01 00 00 00       	mov    $0x1,%edi
    da52:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    da59:	00 
    da5a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    da61:	00 
    da62:	e8 79 8a ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    da67:	48 8b 15 4a 71 01 00 	mov    0x1714a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    da6e:	49 89 c5             	mov    %rax,%r13
    da71:	48 2b 05 18 71 01 00 	sub    0x17118(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    da78:	48 c1 e2 10          	shl    $0x10,%rdx
    da7c:	48 39 d0             	cmp    %rdx,%rax
    da7f:	73 59                	jae    dada <f0+0x265a>
    da81:	48 89 c2             	mov    %rax,%rdx
    da84:	48 c1 ea 10          	shr    $0x10,%rdx
    da88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da8c:	48 8b 15 45 71 01 00 	mov    0x17145(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    da93:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da97:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da9b:	4d 85 e4             	test   %r12,%r12
    da9e:	74 3a                	je     dada <f0+0x265a>
    daa0:	0f b6 0a             	movzbl (%rdx),%ecx
    daa3:	80 f9 02             	cmp    $0x2,%cl
    daa6:	0f 84 04 04 00 00    	je     deb0 <f0+0x2a30>
    daac:	80 f9 01             	cmp    $0x1,%cl
    daaf:	75 29                	jne    dada <f0+0x265a>
    dab1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dab4:	0f b7 c0             	movzwl %ax,%eax
    dab7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    daba:	48 0f af c1          	imul   %rcx,%rax
    dabe:	48 c1 e8 20          	shr    $0x20,%rax
    dac2:	48 39 d0             	cmp    %rdx,%rax
    dac5:	73 13                	jae    dada <f0+0x265a>
    dac7:	49 01 c4             	add    %rax,%r12
    daca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dacf:	0f 84 7d 06 00 00    	je     e152 <f0+0x2cd2>
    dad5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dada:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dae1:	33 f3 bf 
    dae4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    daeb:	00 
    daec:	bf 01 00 00 00       	mov    $0x1,%edi
    daf1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    daf8:	00 
    daf9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    db00:	00 
    db01:	e8 da 89 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    db06:	48 8b 15 ab 70 01 00 	mov    0x170ab(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    db0d:	49 89 c5             	mov    %rax,%r13
    db10:	48 2b 05 79 70 01 00 	sub    0x17079(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    db17:	48 c1 e2 10          	shl    $0x10,%rdx
    db1b:	48 39 d0             	cmp    %rdx,%rax
    db1e:	73 59                	jae    db79 <f0+0x26f9>
    db20:	48 89 c2             	mov    %rax,%rdx
    db23:	48 c1 ea 10          	shr    $0x10,%rdx
    db27:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db2b:	48 8b 15 a6 70 01 00 	mov    0x170a6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    db32:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db36:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db3a:	4d 85 e4             	test   %r12,%r12
    db3d:	74 3a                	je     db79 <f0+0x26f9>
    db3f:	0f b6 0a             	movzbl (%rdx),%ecx
    db42:	80 f9 02             	cmp    $0x2,%cl
    db45:	0f 84 55 03 00 00    	je     dea0 <f0+0x2a20>
    db4b:	80 f9 01             	cmp    $0x1,%cl
    db4e:	75 29                	jne    db79 <f0+0x26f9>
    db50:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db53:	0f b7 c0             	movzwl %ax,%eax
    db56:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db59:	48 0f af c1          	imul   %rcx,%rax
    db5d:	48 c1 e8 20          	shr    $0x20,%rax
    db61:	48 39 d0             	cmp    %rdx,%rax
    db64:	73 13                	jae    db79 <f0+0x26f9>
    db66:	49 01 c4             	add    %rax,%r12
    db69:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db6e:	0f 84 eb 05 00 00    	je     e15f <f0+0x2cdf>
    db74:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db79:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db80:	00 f0 3f 
    db83:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    db8a:	00 
    db8b:	bf 01 00 00 00       	mov    $0x1,%edi
    db90:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    db97:	00 
    db98:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    db9f:	00 
    dba0:	e8 3b 89 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    dba5:	48 8b 15 0c 70 01 00 	mov    0x1700c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dbac:	49 89 c5             	mov    %rax,%r13
    dbaf:	48 2b 05 da 6f 01 00 	sub    0x16fda(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dbb6:	48 c1 e2 10          	shl    $0x10,%rdx
    dbba:	48 39 d0             	cmp    %rdx,%rax
    dbbd:	73 59                	jae    dc18 <f0+0x2798>
    dbbf:	48 89 c2             	mov    %rax,%rdx
    dbc2:	48 c1 ea 10          	shr    $0x10,%rdx
    dbc6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbca:	48 8b 15 07 70 01 00 	mov    0x17007(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dbd1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbd5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbd9:	4d 85 e4             	test   %r12,%r12
    dbdc:	74 3a                	je     dc18 <f0+0x2798>
    dbde:	0f b6 0a             	movzbl (%rdx),%ecx
    dbe1:	80 f9 02             	cmp    $0x2,%cl
    dbe4:	0f 84 a6 02 00 00    	je     de90 <f0+0x2a10>
    dbea:	80 f9 01             	cmp    $0x1,%cl
    dbed:	75 29                	jne    dc18 <f0+0x2798>
    dbef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbf2:	0f b7 c0             	movzwl %ax,%eax
    dbf5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbf8:	48 0f af c1          	imul   %rcx,%rax
    dbfc:	48 c1 e8 20          	shr    $0x20,%rax
    dc00:	48 39 d0             	cmp    %rdx,%rax
    dc03:	73 13                	jae    dc18 <f0+0x2798>
    dc05:	49 01 c4             	add    %rax,%r12
    dc08:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc0d:	0f 84 59 05 00 00    	je     e16c <f0+0x2cec>
    dc13:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc18:	48 89 ee             	mov    %rbp,%rsi
    dc1b:	bf 01 00 00 00       	mov    $0x1,%edi
    dc20:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc27:	33 f3 bf 
    dc2a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dc31:	00 
    dc32:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dc39:	00 
    dc3a:	e8 a1 88 ff ff       	call   64e0 <fwp_data.part.0.constprop.0>
    dc3f:	48 8b 15 72 6f 01 00 	mov    0x16f72(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dc46:	48 89 c5             	mov    %rax,%rbp
    dc49:	48 2b 05 40 6f 01 00 	sub    0x16f40(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dc50:	48 c1 e2 10          	shl    $0x10,%rdx
    dc54:	48 39 d0             	cmp    %rdx,%rax
    dc57:	73 59                	jae    dcb2 <f0+0x2832>
    dc59:	48 89 c2             	mov    %rax,%rdx
    dc5c:	48 c1 ea 10          	shr    $0x10,%rdx
    dc60:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc64:	48 8b 15 6d 6f 01 00 	mov    0x16f6d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dc6b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc6f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc73:	4d 85 e4             	test   %r12,%r12
    dc76:	74 3a                	je     dcb2 <f0+0x2832>
    dc78:	0f b6 0a             	movzbl (%rdx),%ecx
    dc7b:	80 f9 02             	cmp    $0x2,%cl
    dc7e:	0f 84 fc 01 00 00    	je     de80 <f0+0x2a00>
    dc84:	80 f9 01             	cmp    $0x1,%cl
    dc87:	75 29                	jne    dcb2 <f0+0x2832>
    dc89:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc8c:	0f b7 c0             	movzwl %ax,%eax
    dc8f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc92:	48 0f af c1          	imul   %rcx,%rax
    dc96:	48 c1 e8 20          	shr    $0x20,%rax
    dc9a:	48 39 d0             	cmp    %rdx,%rax
    dc9d:	73 13                	jae    dcb2 <f0+0x2832>
    dc9f:	49 01 c4             	add    %rax,%r12
    dca2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dca7:	0f 84 d1 02 00 00    	je     df7e <f0+0x2afe>
    dcad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcb2:	48 89 de             	mov    %rbx,%rsi
    dcb5:	48 89 ef             	mov    %rbp,%rdi
    dcb8:	e8 63 cb ff ff       	call   a820 <fwp_hof0.constprop.0>
    dcbd:	48 89 ef             	mov    %rbp,%rdi
    dcc0:	e8 8b 8d ff ff       	call   6a50 <fwp_drop0>
    dcc5:	48 89 df             	mov    %rbx,%rdi
    dcc8:	e8 83 8d ff ff       	call   6a50 <fwp_drop0>
    dccd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    dcd4:	00 
    dcd5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dcdc:	00 00 
    dcde:	0f 85 95 04 00 00    	jne    e179 <f0+0x2cf9>
    dce4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    dceb:	31 c0                	xor    %eax,%eax
    dced:	5b                   	pop    %rbx
    dcee:	5d                   	pop    %rbp
    dcef:	41 5c                	pop    %r12
    dcf1:	41 5d                	pop    %r13
    dcf3:	41 5e                	pop    %r14
    dcf5:	c3                   	ret
    dcf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dcfd:	00 00 00 
    dd00:	4c 89 ef             	mov    %r13,%rdi
    dd03:	e8 48 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd08:	e9 2c d8 ff ff       	jmp    b539 <f0+0xb9>
    dd0d:	0f 1f 00             	nopl   (%rax)
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 ae f5 ff ff    	jne    d2c7 <f0+0x1e47>
    dd19:	e9 99 f5 ff ff       	jmp    d2b7 <f0+0x1e37>
    dd1e:	66 90                	xchg   %ax,%ax
    dd20:	66 85 c0             	test   %ax,%ax
    dd23:	0f 85 ff f4 ff ff    	jne    d228 <f0+0x1da8>
    dd29:	e9 ea f4 ff ff       	jmp    d218 <f0+0x1d98>
    dd2e:	66 90                	xchg   %ax,%ax
    dd30:	66 85 c0             	test   %ax,%ax
    dd33:	0f 85 50 f4 ff ff    	jne    d189 <f0+0x1d09>
    dd39:	e9 3b f4 ff ff       	jmp    d179 <f0+0x1cf9>
    dd3e:	66 90                	xchg   %ax,%ax
    dd40:	66 85 c0             	test   %ax,%ax
    dd43:	0f 85 a1 f3 ff ff    	jne    d0ea <f0+0x1c6a>
    dd49:	e9 8c f3 ff ff       	jmp    d0da <f0+0x1c5a>
    dd4e:	66 90                	xchg   %ax,%ax
    dd50:	66 85 c0             	test   %ax,%ax
    dd53:	0f 85 f2 f2 ff ff    	jne    d04b <f0+0x1bcb>
    dd59:	e9 dd f2 ff ff       	jmp    d03b <f0+0x1bbb>
    dd5e:	66 90                	xchg   %ax,%ax
    dd60:	66 85 c0             	test   %ax,%ax
    dd63:	0f 85 43 f2 ff ff    	jne    cfac <f0+0x1b2c>
    dd69:	e9 2e f2 ff ff       	jmp    cf9c <f0+0x1b1c>
    dd6e:	66 90                	xchg   %ax,%ax
    dd70:	66 85 c0             	test   %ax,%ax
    dd73:	0f 85 94 f1 ff ff    	jne    cf0d <f0+0x1a8d>
    dd79:	e9 7f f1 ff ff       	jmp    cefd <f0+0x1a7d>
    dd7e:	66 90                	xchg   %ax,%ax
    dd80:	66 85 c0             	test   %ax,%ax
    dd83:	0f 85 e5 f0 ff ff    	jne    ce6e <f0+0x19ee>
    dd89:	e9 d0 f0 ff ff       	jmp    ce5e <f0+0x19de>
    dd8e:	66 90                	xchg   %ax,%ax
    dd90:	66 85 c0             	test   %ax,%ax
    dd93:	0f 85 fd d9 ff ff    	jne    b796 <f0+0x316>
    dd99:	e9 e8 d9 ff ff       	jmp    b786 <f0+0x306>
    dd9e:	66 90                	xchg   %ax,%ax
    dda0:	66 85 c0             	test   %ax,%ax
    dda3:	0f 85 57 d9 ff ff    	jne    b700 <f0+0x280>
    dda9:	e9 42 d9 ff ff       	jmp    b6f0 <f0+0x270>
    ddae:	66 90                	xchg   %ax,%ax
    ddb0:	66 85 c0             	test   %ax,%ax
    ddb3:	0f 85 b1 d8 ff ff    	jne    b66a <f0+0x1ea>
    ddb9:	e9 9c d8 ff ff       	jmp    b65a <f0+0x1da>
    ddbe:	66 90                	xchg   %ax,%ax
    ddc0:	66 85 c0             	test   %ax,%ax
    ddc3:	0f 85 0e eb ff ff    	jne    c8d7 <f0+0x1457>
    ddc9:	e9 f9 ea ff ff       	jmp    c8c7 <f0+0x1447>
    ddce:	66 90                	xchg   %ax,%ax
    ddd0:	66 85 c0             	test   %ax,%ax
    ddd3:	0f 85 5f ea ff ff    	jne    c838 <f0+0x13b8>
    ddd9:	e9 4a ea ff ff       	jmp    c828 <f0+0x13a8>
    ddde:	66 90                	xchg   %ax,%ax
    dde0:	66 85 c0             	test   %ax,%ax
    dde3:	0f 85 e2 da ff ff    	jne    b8cb <f0+0x44b>
    dde9:	e9 cd da ff ff       	jmp    b8bb <f0+0x43b>
    ddee:	66 90                	xchg   %ax,%ax
    ddf0:	66 85 c0             	test   %ax,%ax
    ddf3:	0f 85 33 da ff ff    	jne    b82c <f0+0x3ac>
    ddf9:	e9 1e da ff ff       	jmp    b81c <f0+0x39c>
    ddfe:	66 90                	xchg   %ax,%ax
    de00:	66 85 c0             	test   %ax,%ax
    de03:	0f 85 c6 ef ff ff    	jne    cdcf <f0+0x194f>
    de09:	e9 b1 ef ff ff       	jmp    cdbf <f0+0x193f>
    de0e:	66 90                	xchg   %ax,%ax
    de10:	66 85 c0             	test   %ax,%ax
    de13:	0f 85 17 ef ff ff    	jne    cd30 <f0+0x18b0>
    de19:	e9 02 ef ff ff       	jmp    cd20 <f0+0x18a0>
    de1e:	66 90                	xchg   %ax,%ax
    de20:	66 85 c0             	test   %ax,%ax
    de23:	0f 85 68 ee ff ff    	jne    cc91 <f0+0x1811>
    de29:	e9 53 ee ff ff       	jmp    cc81 <f0+0x1801>
    de2e:	66 90                	xchg   %ax,%ax
    de30:	66 85 c0             	test   %ax,%ax
    de33:	0f 85 b9 ed ff ff    	jne    cbf2 <f0+0x1772>
    de39:	e9 a4 ed ff ff       	jmp    cbe2 <f0+0x1762>
    de3e:	66 90                	xchg   %ax,%ax
    de40:	66 85 c0             	test   %ax,%ax
    de43:	0f 85 0a ed ff ff    	jne    cb53 <f0+0x16d3>
    de49:	e9 f5 ec ff ff       	jmp    cb43 <f0+0x16c3>
    de4e:	66 90                	xchg   %ax,%ax
    de50:	66 85 c0             	test   %ax,%ax
    de53:	0f 85 5b ec ff ff    	jne    cab4 <f0+0x1634>
    de59:	e9 46 ec ff ff       	jmp    caa4 <f0+0x1624>
    de5e:	66 90                	xchg   %ax,%ax
    de60:	66 85 c0             	test   %ax,%ax
    de63:	0f 85 ac eb ff ff    	jne    ca15 <f0+0x1595>
    de69:	e9 97 eb ff ff       	jmp    ca05 <f0+0x1585>
    de6e:	66 90                	xchg   %ax,%ax
    de70:	66 85 c0             	test   %ax,%ax
    de73:	0f 85 fd ea ff ff    	jne    c976 <f0+0x14f6>
    de79:	e9 e8 ea ff ff       	jmp    c966 <f0+0x14e6>
    de7e:	66 90                	xchg   %ax,%ax
    de80:	66 85 c0             	test   %ax,%ax
    de83:	0f 85 29 fe ff ff    	jne    dcb2 <f0+0x2832>
    de89:	e9 14 fe ff ff       	jmp    dca2 <f0+0x2822>
    de8e:	66 90                	xchg   %ax,%ax
    de90:	66 85 c0             	test   %ax,%ax
    de93:	0f 85 7f fd ff ff    	jne    dc18 <f0+0x2798>
    de99:	e9 6a fd ff ff       	jmp    dc08 <f0+0x2788>
    de9e:	66 90                	xchg   %ax,%ax
    dea0:	66 85 c0             	test   %ax,%ax
    dea3:	0f 85 d0 fc ff ff    	jne    db79 <f0+0x26f9>
    dea9:	e9 bb fc ff ff       	jmp    db69 <f0+0x26e9>
    deae:	66 90                	xchg   %ax,%ax
    deb0:	66 85 c0             	test   %ax,%ax
    deb3:	0f 85 21 fc ff ff    	jne    dada <f0+0x265a>
    deb9:	e9 0c fc ff ff       	jmp    daca <f0+0x264a>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	66 85 c0             	test   %ax,%ax
    dec3:	0f 85 72 fb ff ff    	jne    da3b <f0+0x25bb>
    dec9:	e9 5d fb ff ff       	jmp    da2b <f0+0x25ab>
    dece:	66 90                	xchg   %ax,%ax
    ded0:	66 85 c0             	test   %ax,%ax
    ded3:	0f 85 c3 fa ff ff    	jne    d99c <f0+0x251c>
    ded9:	e9 ae fa ff ff       	jmp    d98c <f0+0x250c>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	66 85 c0             	test   %ax,%ax
    dee3:	0f 85 14 fa ff ff    	jne    d8fd <f0+0x247d>
    dee9:	e9 ff f9 ff ff       	jmp    d8ed <f0+0x246d>
    deee:	66 90                	xchg   %ax,%ax
    def0:	66 85 c0             	test   %ax,%ax
    def3:	0f 85 65 f9 ff ff    	jne    d85e <f0+0x23de>
    def9:	e9 50 f9 ff ff       	jmp    d84e <f0+0x23ce>
    defe:	66 90                	xchg   %ax,%ax
    df00:	66 85 c0             	test   %ax,%ax
    df03:	0f 85 b6 f8 ff ff    	jne    d7bf <f0+0x233f>
    df09:	e9 a1 f8 ff ff       	jmp    d7af <f0+0x232f>
    df0e:	66 90                	xchg   %ax,%ax
    df10:	66 85 c0             	test   %ax,%ax
    df13:	0f 85 07 f8 ff ff    	jne    d720 <f0+0x22a0>
    df19:	e9 f2 f7 ff ff       	jmp    d710 <f0+0x2290>
    df1e:	66 90                	xchg   %ax,%ax
    df20:	66 85 c0             	test   %ax,%ax
    df23:	0f 85 58 f7 ff ff    	jne    d681 <f0+0x2201>
    df29:	e9 43 f7 ff ff       	jmp    d671 <f0+0x21f1>
    df2e:	66 90                	xchg   %ax,%ax
    df30:	66 85 c0             	test   %ax,%ax
    df33:	0f 85 a9 f6 ff ff    	jne    d5e2 <f0+0x2162>
    df39:	e9 94 f6 ff ff       	jmp    d5d2 <f0+0x2152>
    df3e:	66 90                	xchg   %ax,%ax
    df40:	66 85 c0             	test   %ax,%ax
    df43:	0f 85 fa f5 ff ff    	jne    d543 <f0+0x20c3>
    df49:	e9 e5 f5 ff ff       	jmp    d533 <f0+0x20b3>
    df4e:	66 90                	xchg   %ax,%ax
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 4b f5 ff ff    	jne    d4a4 <f0+0x2024>
    df59:	e9 36 f5 ff ff       	jmp    d494 <f0+0x2014>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 9c f4 ff ff    	jne    d405 <f0+0x1f85>
    df69:	e9 87 f4 ff ff       	jmp    d3f5 <f0+0x1f75>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 ed f3 ff ff    	jne    d366 <f0+0x1ee6>
    df79:	e9 d8 f3 ff ff       	jmp    d356 <f0+0x1ed6>
    df7e:	4c 89 e7             	mov    %r12,%rdi
    df81:	e8 ca 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    df86:	e9 22 fd ff ff       	jmp    dcad <f0+0x282d>
    df8b:	4c 89 e7             	mov    %r12,%rdi
    df8e:	e8 bd 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    df93:	e9 cd d6 ff ff       	jmp    b665 <f0+0x1e5>
    df98:	4c 89 e7             	mov    %r12,%rdi
    df9b:	e8 b0 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfa0:	e9 56 d7 ff ff       	jmp    b6fb <f0+0x27b>
    dfa5:	4c 89 e7             	mov    %r12,%rdi
    dfa8:	e8 a3 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfad:	e9 df d7 ff ff       	jmp    b791 <f0+0x311>
    dfb2:	4c 89 e7             	mov    %r12,%rdi
    dfb5:	e8 96 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfba:	e9 68 d8 ff ff       	jmp    b827 <f0+0x3a7>
    dfbf:	4c 89 e7             	mov    %r12,%rdi
    dfc2:	e8 89 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfc7:	e9 fa d8 ff ff       	jmp    b8c6 <f0+0x446>
    dfcc:	4c 89 e7             	mov    %r12,%rdi
    dfcf:	e8 7c 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfd4:	e9 5a e8 ff ff       	jmp    c833 <f0+0x13b3>
    dfd9:	4c 89 e7             	mov    %r12,%rdi
    dfdc:	e8 6f 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfe1:	e9 ec e8 ff ff       	jmp    c8d2 <f0+0x1452>
    dfe6:	4c 89 e7             	mov    %r12,%rdi
    dfe9:	e8 62 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfee:	e9 7e e9 ff ff       	jmp    c971 <f0+0x14f1>
    dff3:	4c 89 e7             	mov    %r12,%rdi
    dff6:	e8 55 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dffb:	e9 10 ea ff ff       	jmp    ca10 <f0+0x1590>
    e000:	4c 89 e7             	mov    %r12,%rdi
    e003:	e8 48 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e008:	e9 a2 ea ff ff       	jmp    caaf <f0+0x162f>
    e00d:	4c 89 e7             	mov    %r12,%rdi
    e010:	e8 3b 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e015:	e9 34 eb ff ff       	jmp    cb4e <f0+0x16ce>
    e01a:	4c 89 e7             	mov    %r12,%rdi
    e01d:	e8 2e 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e022:	e9 c6 eb ff ff       	jmp    cbed <f0+0x176d>
    e027:	4c 89 e7             	mov    %r12,%rdi
    e02a:	e8 21 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e02f:	e9 58 ec ff ff       	jmp    cc8c <f0+0x180c>
    e034:	4c 89 e7             	mov    %r12,%rdi
    e037:	e8 14 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e03c:	e9 ea ec ff ff       	jmp    cd2b <f0+0x18ab>
    e041:	4c 89 e7             	mov    %r12,%rdi
    e044:	e8 07 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e049:	e9 7c ed ff ff       	jmp    cdca <f0+0x194a>
    e04e:	4c 89 e7             	mov    %r12,%rdi
    e051:	e8 fa 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e056:	e9 0e ee ff ff       	jmp    ce69 <f0+0x19e9>
    e05b:	4c 89 e7             	mov    %r12,%rdi
    e05e:	e8 ed 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e063:	e9 a0 ee ff ff       	jmp    cf08 <f0+0x1a88>
    e068:	4c 89 e7             	mov    %r12,%rdi
    e06b:	e8 e0 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e070:	e9 32 ef ff ff       	jmp    cfa7 <f0+0x1b27>
    e075:	4c 89 e7             	mov    %r12,%rdi
    e078:	e8 d3 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e07d:	e9 c4 ef ff ff       	jmp    d046 <f0+0x1bc6>
    e082:	4c 89 e7             	mov    %r12,%rdi
    e085:	e8 c6 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e08a:	e9 56 f0 ff ff       	jmp    d0e5 <f0+0x1c65>
    e08f:	4c 89 e7             	mov    %r12,%rdi
    e092:	e8 b9 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e097:	e9 e8 f0 ff ff       	jmp    d184 <f0+0x1d04>
    e09c:	4c 89 e7             	mov    %r12,%rdi
    e09f:	e8 ac 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0a4:	e9 7a f1 ff ff       	jmp    d223 <f0+0x1da3>
    e0a9:	4c 89 e7             	mov    %r12,%rdi
    e0ac:	e8 9f 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0b1:	e9 0c f2 ff ff       	jmp    d2c2 <f0+0x1e42>
    e0b6:	4c 89 e7             	mov    %r12,%rdi
    e0b9:	e8 92 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0be:	e9 9e f2 ff ff       	jmp    d361 <f0+0x1ee1>
    e0c3:	4c 89 e7             	mov    %r12,%rdi
    e0c6:	e8 85 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0cb:	e9 30 f3 ff ff       	jmp    d400 <f0+0x1f80>
    e0d0:	4c 89 e7             	mov    %r12,%rdi
    e0d3:	e8 78 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0d8:	e9 c2 f3 ff ff       	jmp    d49f <f0+0x201f>
    e0dd:	4c 89 e7             	mov    %r12,%rdi
    e0e0:	e8 6b 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0e5:	e9 54 f4 ff ff       	jmp    d53e <f0+0x20be>
    e0ea:	4c 89 e7             	mov    %r12,%rdi
    e0ed:	e8 5e 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0f2:	e9 e6 f4 ff ff       	jmp    d5dd <f0+0x215d>
    e0f7:	4c 89 e7             	mov    %r12,%rdi
    e0fa:	e8 51 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0ff:	e9 78 f5 ff ff       	jmp    d67c <f0+0x21fc>
    e104:	4c 89 e7             	mov    %r12,%rdi
    e107:	e8 44 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e10c:	e9 0a f6 ff ff       	jmp    d71b <f0+0x229b>
    e111:	4c 89 e7             	mov    %r12,%rdi
    e114:	e8 37 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e119:	e9 9c f6 ff ff       	jmp    d7ba <f0+0x233a>
    e11e:	4c 89 e7             	mov    %r12,%rdi
    e121:	e8 2a 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e126:	e9 2e f7 ff ff       	jmp    d859 <f0+0x23d9>
    e12b:	4c 89 e7             	mov    %r12,%rdi
    e12e:	e8 1d 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e133:	e9 c0 f7 ff ff       	jmp    d8f8 <f0+0x2478>
    e138:	4c 89 e7             	mov    %r12,%rdi
    e13b:	e8 10 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e140:	e9 52 f8 ff ff       	jmp    d997 <f0+0x2517>
    e145:	4c 89 e7             	mov    %r12,%rdi
    e148:	e8 03 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e14d:	e9 e4 f8 ff ff       	jmp    da36 <f0+0x25b6>
    e152:	4c 89 e7             	mov    %r12,%rdi
    e155:	e8 f6 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e15a:	e9 76 f9 ff ff       	jmp    dad5 <f0+0x2655>
    e15f:	4c 89 e7             	mov    %r12,%rdi
    e162:	e8 e9 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e167:	e9 08 fa ff ff       	jmp    db74 <f0+0x26f4>
    e16c:	4c 89 e7             	mov    %r12,%rdi
    e16f:	e8 dc 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e174:	e9 9a fa ff ff       	jmp    dc13 <f0+0x2793>
    e179:	e8 e2 52 ff ff       	call   3460 <__stack_chk_fail@plt>
    e17e:	66 90                	xchg   %ax,%ax

000000000000e180 <fwp_main_thread>:
    e180:	f3 0f 1e fa          	endbr64
    e184:	41 54                	push   %r12
    e186:	55                   	push   %rbp
    e187:	53                   	push   %rbx
    e188:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e18f:	8b 35 ef 69 01 00    	mov    0x169ef(%rip),%esi        # 24b84 <fwp_heap+0x13a4>
    e195:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e19c:	00 00 
    e19e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e1a5:	00 
    e1a6:	31 c0                	xor    %eax,%eax
    e1a8:	85 f6                	test   %esi,%esi
    e1aa:	0f 84 a8 06 00 00    	je     e858 <fwp_main_thread+0x6d8>
    e1b0:	8b 0d d2 69 01 00    	mov    0x169d2(%rip),%ecx        # 24b88 <fwp_heap+0x13a8>
    e1b6:	85 c9                	test   %ecx,%ecx
    e1b8:	0f 85 82 06 00 00    	jne    e840 <fwp_main_thread+0x6c0>
    e1be:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e1c3:	31 f6                	xor    %esi,%esi
    e1c5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e1ca:	48 c7 05 9b 4f 01 00 	movq   $0x40000000,0x14f9b(%rip)        # 23170 <fwp_main_stack_size>
    e1d1:	00 00 00 40 
    e1d5:	48 89 05 9c 4f 01 00 	mov    %rax,0x14f9c(%rip)        # 23178 <fwp_main_stack_top>
    e1dc:	48 8d 05 bd 4e 00 00 	lea    0x4ebd(%rip),%rax        # 130a0 <alt.5>
    e1e3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e1e8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e1ef:	01 00 
    e1f1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e1f8:	00 
    e1f9:	e8 c2 54 ff ff       	call   36c0 <sigaltstack@plt>
    e1fe:	85 c0                	test   %eax,%eax
    e200:	0f 85 8a 06 00 00    	jne    e890 <fwp_main_thread+0x710>
    e206:	31 c0                	xor    %eax,%eax
    e208:	b9 12 00 00 00       	mov    $0x12,%ecx
    e20d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e212:	f3 48 ab             	rep stos %rax,(%rdi)
    e215:	48 8d 05 d4 5a ff ff 	lea    -0xa52c(%rip),%rax        # 3cf0 <fwp_segv>
    e21c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e221:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e228:	04 00 00 08 
    e22c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e231:	e8 4a 53 ff ff       	call   3580 <sigemptyset@plt>
    e236:	85 c0                	test   %eax,%eax
    e238:	0f 85 52 06 00 00    	jne    e890 <fwp_main_thread+0x710>
    e23e:	31 d2                	xor    %edx,%edx
    e240:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e245:	bf 0b 00 00 00       	mov    $0xb,%edi
    e24a:	e8 b1 51 ff ff       	call   3400 <sigaction@plt>
    e24f:	85 c0                	test   %eax,%eax
    e251:	0f 85 39 06 00 00    	jne    e890 <fwp_main_thread+0x710>
    e257:	31 d2                	xor    %edx,%edx
    e259:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e25e:	bf 07 00 00 00       	mov    $0x7,%edi
    e263:	e8 98 51 ff ff       	call   3400 <sigaction@plt>
    e268:	85 c0                	test   %eax,%eax
    e26a:	0f 85 20 06 00 00    	jne    e890 <fwp_main_thread+0x710>
    e270:	8b 15 a2 4e 01 00    	mov    0x14ea2(%rip),%edx        # 23118 <descent_registered>
    e276:	85 d2                	test   %edx,%edx
    e278:	0f 84 72 05 00 00    	je     e7f0 <fwp_main_thread+0x670>
    e27e:	8b 05 0c 4e 00 00    	mov    0x4e0c(%rip),%eax        # 13090 <st.3>
    e284:	85 c0                	test   %eax,%eax
    e286:	0f 84 90 05 00 00    	je     e81c <fwp_main_thread+0x69c>
    e28c:	48 8b 2d 2d 55 01 00 	mov    0x1552d(%rip),%rbp        # 237c0 <fwp_cur>
    e293:	48 85 ed             	test   %rbp,%rbp
    e296:	0f 84 74 03 00 00    	je     e610 <fwp_main_thread+0x490>
    e29c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e2a1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e2a5:	48 89 eb             	mov    %rbp,%rbx
    e2a8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e2ad:	0f 84 41 01 00 00    	je     e3f4 <fwp_main_thread+0x274>
    e2b3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e2b8:	0f 84 82 02 00 00    	je     e540 <fwp_main_thread+0x3c0>
    e2be:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e2c2:	0f 84 68 02 00 00    	je     e530 <fwp_main_thread+0x3b0>
    e2c8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e2cc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e2d0:	0f 85 ea 02 00 00    	jne    e5c0 <fwp_main_thread+0x440>
    e2d6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e2da:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e2e1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e2e5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e2ec:	00 00 00 00 
    e2f0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e2f7:	48 85 d2             	test   %rdx,%rdx
    e2fa:	74 07                	je     e303 <fwp_main_thread+0x183>
    e2fc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e303:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e307:	48 85 c0             	test   %rax,%rax
    e30a:	74 34                	je     e340 <fwp_main_thread+0x1c0>
    e30c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e310:	48 8b 05 81 54 01 00 	mov    0x15481(%rip),%rax        # 23798 <fwp_timers>
    e317:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e31b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e322:	00 00 00 00 
    e326:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e32d:	48 85 c0             	test   %rax,%rax
    e330:	74 07                	je     e339 <fwp_main_thread+0x1b9>
    e332:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e339:	48 89 1d 58 54 01 00 	mov    %rbx,0x15458(%rip)        # 23798 <fwp_timers>
    e340:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e344:	e8 47 91 ff ff       	call   7490 <fwp_block>
    e349:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e350:	48 85 c9             	test   %rcx,%rcx
    e353:	74 47                	je     e39c <fwp_main_thread+0x21c>
    e355:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e35c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e363:	48 85 d2             	test   %rdx,%rdx
    e366:	0f 84 94 02 00 00    	je     e600 <fwp_main_thread+0x480>
    e36c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e373:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e37a:	48 85 c0             	test   %rax,%rax
    e37d:	74 07                	je     e386 <fwp_main_thread+0x206>
    e37f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e386:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e38d:	00 00 00 00 
    e391:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e395:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e39c:	48 8b 0d 1d 54 01 00 	mov    0x1541d(%rip),%rcx        # 237c0 <fwp_cur>
    e3a3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e3a7:	0f 84 03 02 00 00    	je     e5b0 <fwp_main_thread+0x430>
    e3ad:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e3b4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e3bb:	48 85 d2             	test   %rdx,%rdx
    e3be:	0f 84 fc 03 00 00    	je     e7c0 <fwp_main_thread+0x640>
    e3c4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e3cb:	48 85 c0             	test   %rax,%rax
    e3ce:	74 07                	je     e3d7 <fwp_main_thread+0x257>
    e3d0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e3d7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e3db:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e3df:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e3e6:	48 89 cb             	mov    %rcx,%rbx
    e3e9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e3ee:	0f 85 bf fe ff ff    	jne    e2b3 <fwp_main_thread+0x133>
    e3f4:	48 83 3d 5c 70 01 00 	cmpq   $0x0,0x1705c(%rip)        # 25458 <fwp_state_len>
    e3fb:	00 
    e3fc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e400:	0f 84 bc 00 00 00    	je     e4c2 <fwp_main_thread+0x342>
    e406:	48 39 1d ab 53 01 00 	cmp    %rbx,0x153ab(%rip)        # 237b8 <fwp_root>
    e40d:	c7 05 89 4c 01 00 00 	movl   $0x0,0x14c89(%rip)        # 230a0 <fwp_exit_code>
    e414:	00 00 00 
    e417:	0f 85 91 04 00 00    	jne    e8ae <fwp_main_thread+0x72e>
    e41d:	48 85 db             	test   %rbx,%rbx
    e420:	0f 84 10 02 00 00    	je     e636 <fwp_main_thread+0x4b6>
    e426:	48 8b 15 5b 53 01 00 	mov    0x1535b(%rip),%rdx        # 23788 <fwp_tasks_active>
    e42d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e431:	48 85 d2             	test   %rdx,%rdx
    e434:	0f 84 fc 01 00 00    	je     e636 <fwp_main_thread+0x4b6>
    e43a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e440:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e444:	75 08                	jne    e44e <fwp_main_thread+0x2ce>
    e446:	48 89 d7             	mov    %rdx,%rdi
    e449:	e8 b2 5e ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e44e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e455:	48 85 d2             	test   %rdx,%rdx
    e458:	75 e6                	jne    e440 <fwp_main_thread+0x2c0>
    e45a:	eb 31                	jmp    e48d <fwp_main_thread+0x30d>
    e45c:	0f 1f 40 00          	nopl   0x0(%rax)
    e460:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e467:	48 89 1d 32 53 01 00 	mov    %rbx,0x15332(%rip)        # 237a0 <fwp_ready_tail>
    e46e:	e8 1d 90 ff ff       	call   7490 <fwp_block>
    e473:	e8 18 8e ff ff       	call   7290 <fwp_free_zombie>
    e478:	48 83 3d 08 53 01 00 	cmpq   $0x0,0x15308(%rip)        # 23788 <fwp_tasks_active>
    e47f:	00 
    e480:	0f 84 b0 01 00 00    	je     e636 <fwp_main_thread+0x4b6>
    e486:	48 8b 1d 2b 53 01 00 	mov    0x1532b(%rip),%rbx        # 237b8 <fwp_root>
    e48d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e491:	75 db                	jne    e46e <fwp_main_thread+0x2ee>
    e493:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e497:	75 d5                	jne    e46e <fwp_main_thread+0x2ee>
    e499:	48 8b 05 00 53 01 00 	mov    0x15300(%rip),%rax        # 237a0 <fwp_ready_tail>
    e4a0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e4a4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e4ab:	00 00 00 00 
    e4af:	48 85 c0             	test   %rax,%rax
    e4b2:	75 ac                	jne    e460 <fwp_main_thread+0x2e0>
    e4b4:	48 89 1d ed 52 01 00 	mov    %rbx,0x152ed(%rip)        # 237a8 <fwp_ready_head>
    e4bb:	eb aa                	jmp    e467 <fwp_main_thread+0x2e7>
    e4bd:	0f 1f 00             	nopl   (%rax)
    e4c0:	31 db                	xor    %ebx,%ebx
    e4c2:	48 83 3d 7e 6f 01 00 	cmpq   $0x0,0x16f7e(%rip)        # 25448 <fwp_state_owners>
    e4c9:	00 
    e4ca:	0f 85 36 ff ff ff    	jne    e406 <fwp_main_thread+0x286>
    e4d0:	48 8b 3d 89 6f 01 00 	mov    0x16f89(%rip),%rdi        # 25460 <fwp_state>
    e4d7:	e8 b4 72 ff ff       	call   5790 <fwp_mem_free>
    e4dc:	48 c7 05 79 6f 01 00 	movq   $0x0,0x16f79(%rip)        # 25460 <fwp_state>
    e4e3:	00 00 00 00 
    e4e7:	48 c7 05 5e 6f 01 00 	movq   $0x0,0x16f5e(%rip)        # 25450 <fwp_state_cap>
    e4ee:	00 00 00 00 
    e4f2:	48 85 db             	test   %rbx,%rbx
    e4f5:	0f 84 76 03 00 00    	je     e871 <fwp_main_thread+0x6f1>
    e4fb:	48 39 1d b6 52 01 00 	cmp    %rbx,0x152b6(%rip)        # 237b8 <fwp_root>
    e502:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e509:	00 00 00 00 
    e50d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e514:	00 00 00 00 
    e518:	c7 05 7e 4b 01 00 00 	movl   $0x0,0x14b7e(%rip)        # 230a0 <fwp_exit_code>
    e51f:	00 00 00 
    e522:	0f 84 fe fe ff ff    	je     e426 <fwp_main_thread+0x2a6>
    e528:	e9 23 52 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e52d:	0f 1f 00             	nopl   (%rax)
    e530:	e8 2b 60 ff ff       	call   4560 <fwp_now_ns>
    e535:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e539:	0f 8d 91 02 00 00    	jge    e7d0 <fwp_main_thread+0x650>
    e53f:	90                   	nop
    e540:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e544:	0f 85 7e fd ff ff    	jne    e2c8 <fwp_main_thread+0x148>
    e54a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e54e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e552:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e556:	0f 85 7e fd ff ff    	jne    e2da <fwp_main_thread+0x15a>
    e55c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e560:	48 85 c9             	test   %rcx,%rcx
    e563:	0f 84 71 fd ff ff    	je     e2da <fwp_main_thread+0x15a>
    e569:	48 85 c0             	test   %rax,%rax
    e56c:	0f 84 2f 03 00 00    	je     e8a1 <fwp_main_thread+0x721>
    e572:	48 39 c8             	cmp    %rcx,%rax
    e575:	48 0f 4f c1          	cmovg  %rcx,%rax
    e579:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e580:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e584:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e58b:	00 00 00 00 
    e58f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e596:	48 85 d2             	test   %rdx,%rdx
    e599:	74 07                	je     e5a2 <fwp_main_thread+0x422>
    e59b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e5a2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e5a6:	e9 61 fd ff ff       	jmp    e30c <fwp_main_thread+0x18c>
    e5ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e5b0:	48 89 cb             	mov    %rcx,%rbx
    e5b3:	e9 f0 fc ff ff       	jmp    e2a8 <fwp_main_thread+0x128>
    e5b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e5bf:	00 
    e5c0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e5c4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e5cb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e5d2:	00 00 00 00 
    e5d6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e5dd:	48 85 c0             	test   %rax,%rax
    e5e0:	0f 84 82 02 00 00    	je     e868 <fwp_main_thread+0x6e8>
    e5e6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e5ed:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e5f1:	e9 4a fd ff ff       	jmp    e340 <fwp_main_thread+0x1c0>
    e5f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e5fd:	00 00 00 
    e600:	48 89 01             	mov    %rax,(%rcx)
    e603:	e9 72 fd ff ff       	jmp    e37a <fwp_main_thread+0x1fa>
    e608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e60f:	00 
    e610:	48 83 3d 40 6e 01 00 	cmpq   $0x0,0x16e40(%rip)        # 25458 <fwp_state_len>
    e617:	00 
    e618:	0f 84 a2 fe ff ff    	je     e4c0 <fwp_main_thread+0x340>
    e61e:	48 83 3d 92 51 01 00 	cmpq   $0x0,0x15192(%rip)        # 237b8 <fwp_root>
    e625:	00 
    e626:	c7 05 70 4a 01 00 00 	movl   $0x0,0x14a70(%rip)        # 230a0 <fwp_exit_code>
    e62d:	00 00 00 
    e630:	0f 85 7d 02 00 00    	jne    e8b3 <fwp_main_thread+0x733>
    e636:	e8 55 8c ff ff       	call   7290 <fwp_free_zombie>
    e63b:	48 83 3d 65 51 01 00 	cmpq   $0x0,0x15165(%rip)        # 237a8 <fwp_ready_head>
    e642:	00 
    e643:	0f 85 07 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e649:	48 83 3d 47 51 01 00 	cmpq   $0x0,0x15147(%rip)        # 23798 <fwp_timers>
    e650:	00 
    e651:	0f 85 f9 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e657:	8b 1d 27 4b 01 00    	mov    0x14b27(%rip),%ebx        # 23184 <fwp_stack_pool_n>
    e65d:	85 db                	test   %ebx,%ebx
    e65f:	74 36                	je     e697 <fwp_main_thread+0x517>
    e661:	83 eb 01             	sub    $0x1,%ebx
    e664:	48 8d 05 35 4b 01 00 	lea    0x14b35(%rip),%rax        # 231a0 <fwp_stack_pool>
    e66b:	48 63 d3             	movslq %ebx,%rdx
    e66e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e672:	eb 07                	jmp    e67b <fwp_main_thread+0x4fb>
    e674:	0f 1f 40 00          	nopl   0x0(%rax)
    e678:	83 eb 01             	sub    $0x1,%ebx
    e67b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e67f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e684:	89 1d fa 4a 01 00    	mov    %ebx,0x14afa(%rip)        # 23184 <fwp_stack_pool_n>
    e68a:	48 83 ed 08          	sub    $0x8,%rbp
    e68e:	e8 4d 4f ff ff       	call   35e0 <munmap@plt>
    e693:	85 db                	test   %ebx,%ebx
    e695:	75 e1                	jne    e678 <fwp_main_thread+0x4f8>
    e697:	8b 3d 87 49 00 00    	mov    0x4987(%rip),%edi        # 13024 <fwp_epfd>
    e69d:	85 ff                	test   %edi,%edi
    e69f:	78 05                	js     e6a6 <fwp_main_thread+0x526>
    e6a1:	e8 2a 4e ff ff       	call   34d0 <close@plt>
    e6a6:	4c 8b 25 f3 4c 01 00 	mov    0x14cf3(%rip),%r12        # 233a0 <fwp_nfdws>
    e6ad:	48 8b 2d f4 4c 01 00 	mov    0x14cf4(%rip),%rbp        # 233a8 <fwp_fdws>
    e6b4:	31 db                	xor    %ebx,%ebx
    e6b6:	c7 05 64 49 00 00 ff 	movl   $0xffffffff,0x4964(%rip)        # 13024 <fwp_epfd>
    e6bd:	ff ff ff 
    e6c0:	4d 85 e4             	test   %r12,%r12
    e6c3:	74 38                	je     e6fd <fwp_main_thread+0x57d>
    e6c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e6cc:	00 00 00 00 
    e6d0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e6d5:	48 85 ff             	test   %rdi,%rdi
    e6d8:	74 1a                	je     e6f4 <fwp_main_thread+0x574>
    e6da:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e6de:	0f 85 6c 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6e4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e6e9:	0f 85 61 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6ef:	e8 9c 70 ff ff       	call   5790 <fwp_mem_free>
    e6f4:	48 83 c3 01          	add    $0x1,%rbx
    e6f8:	4c 39 e3             	cmp    %r12,%rbx
    e6fb:	75 d3                	jne    e6d0 <fwp_main_thread+0x550>
    e6fd:	48 89 ef             	mov    %rbp,%rdi
    e700:	e8 8b 70 ff ff       	call   5790 <fwp_mem_free>
    e705:	48 8b 15 ac 50 01 00 	mov    0x150ac(%rip),%rdx        # 237b8 <fwp_root>
    e70c:	48 c7 05 91 4c 01 00 	movq   $0x0,0x14c91(%rip)        # 233a8 <fwp_fdws>
    e713:	00 00 00 00 
    e717:	48 c7 05 7e 4c 01 00 	movq   $0x0,0x14c7e(%rip)        # 233a0 <fwp_nfdws>
    e71e:	00 00 00 00 
    e722:	48 85 d2             	test   %rdx,%rdx
    e725:	74 4e                	je     e775 <fwp_main_thread+0x5f5>
    e727:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e72c:	0f 85 1e 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e732:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e739:	00 
    e73a:	0f 85 10 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e740:	48 83 3d 10 6d 01 00 	cmpq   $0x0,0x16d10(%rip)        # 25458 <fwp_state_len>
    e747:	00 
    e748:	0f 85 02 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e74e:	48 83 3d f2 6c 01 00 	cmpq   $0x0,0x16cf2(%rip)        # 25448 <fwp_state_owners>
    e755:	00 
    e756:	0f 85 f4 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e75c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e761:	31 c0                	xor    %eax,%eax
    e763:	48 8d 3d 56 4c 01 00 	lea    0x14c56(%rip),%rdi        # 233c0 <fwp_root_context>
    e76a:	f3 48 ab             	rep stos %rax,(%rdi)
    e76d:	48 89 d7             	mov    %rdx,%rdi
    e770:	e8 1b 70 ff ff       	call   5790 <fwp_mem_free>
    e775:	48 8b 3d c4 48 00 00 	mov    0x48c4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e77c:	48 c7 05 39 50 01 00 	movq   $0x0,0x15039(%rip)        # 237c0 <fwp_cur>
    e783:	00 00 00 00 
    e787:	48 c7 05 26 50 01 00 	movq   $0x0,0x15026(%rip)        # 237b8 <fwp_root>
    e78e:	00 00 00 00 
    e792:	e8 29 4e ff ff       	call   35c0 <fflush@plt>
    e797:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e79e:	00 
    e79f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e7a6:	00 00 
    e7a8:	0f 85 fb 00 00 00    	jne    e8a9 <fwp_main_thread+0x729>
    e7ae:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e7b5:	31 c0                	xor    %eax,%eax
    e7b7:	5b                   	pop    %rbx
    e7b8:	5d                   	pop    %rbp
    e7b9:	41 5c                	pop    %r12
    e7bb:	c3                   	ret
    e7bc:	0f 1f 40 00          	nopl   0x0(%rax)
    e7c0:	48 89 05 d1 4f 01 00 	mov    %rax,0x14fd1(%rip)        # 23798 <fwp_timers>
    e7c7:	e9 ff fb ff ff       	jmp    e3cb <fwp_main_thread+0x24b>
    e7cc:	0f 1f 40 00          	nopl   0x0(%rax)
    e7d0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e7d4:	0f 85 66 fd ff ff    	jne    e540 <fwp_main_thread+0x3c0>
    e7da:	48 89 ef             	mov    %rbp,%rdi
    e7dd:	e8 1e 5b ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e7e2:	e9 59 fd ff ff       	jmp    e540 <fwp_main_thread+0x3c0>
    e7e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e7ee:	00 00 
    e7f0:	48 8d 3d 19 56 ff ff 	lea    -0xa9e7(%rip),%rdi        # 3e10 <descent_phase_report>
    e7f7:	e8 d4 02 00 00       	call   ead0 <atexit>
    e7fc:	85 c0                	test   %eax,%eax
    e7fe:	0f 85 98 00 00 00    	jne    e89c <fwp_main_thread+0x71c>
    e804:	c7 05 0a 49 01 00 01 	movl   $0x1,0x1490a(%rip)        # 23118 <descent_registered>
    e80b:	00 00 00 
    e80e:	8b 05 7c 48 00 00    	mov    0x487c(%rip),%eax        # 13090 <st.3>
    e814:	85 c0                	test   %eax,%eax
    e816:	0f 85 70 fa ff ff    	jne    e28c <fwp_main_thread+0x10c>
    e81c:	e8 5f cc ff ff       	call   b480 <f0>
    e821:	48 c7 05 5c 48 00 00 	movq   $0x0,0x485c(%rip)        # 13088 <v.2>
    e828:	00 00 00 00 
    e82c:	c7 05 5a 48 00 00 01 	movl   $0x1,0x485a(%rip)        # 13090 <st.3>
    e833:	00 00 00 
    e836:	e9 51 fa ff ff       	jmp    e28c <fwp_main_thread+0x10c>
    e83b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e840:	48 8d 3d 19 64 ff ff 	lea    -0x9be7(%rip),%rdi        # 4c60 <fwp_heap_report>
    e847:	e8 84 02 00 00       	call   ead0 <atexit>
    e84c:	e9 6d f9 ff ff       	jmp    e1be <fwp_main_thread+0x3e>
    e851:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e858:	e8 13 65 ff ff       	call   4d70 <fwp_heap_init>
    e85d:	e9 4e f9 ff ff       	jmp    e1b0 <fwp_main_thread+0x30>
    e862:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e868:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e86c:	e9 cf fa ff ff       	jmp    e340 <fwp_main_thread+0x1c0>
    e871:	48 83 3d 3f 4f 01 00 	cmpq   $0x0,0x14f3f(%rip)        # 237b8 <fwp_root>
    e878:	00 
    e879:	c7 05 1d 48 01 00 00 	movl   $0x0,0x1481d(%rip)        # 230a0 <fwp_exit_code>
    e880:	00 00 00 
    e883:	0f 84 ad fd ff ff    	je     e636 <fwp_main_thread+0x4b6>
    e889:	e9 c2 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e88e:	66 90                	xchg   %ax,%ax
    e890:	48 8d 3d 49 11 00 00 	lea    0x1149(%rip),%rdi        # f9e0 <_IO_stdin_used+0x9e0>
    e897:	e8 54 5b ff ff       	call   43f0 <fwp_trap>
    e89c:	e8 3f 55 ff ff       	call   3de0 <descent_phase_fail>
    e8a1:	48 89 c8             	mov    %rcx,%rax
    e8a4:	e9 d0 fc ff ff       	jmp    e579 <fwp_main_thread+0x3f9>
    e8a9:	e8 b2 4b ff ff       	call   3460 <__stack_chk_fail@plt>
    e8ae:	e9 9d 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e8b3:	e9 98 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e8b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e8bf:	00 

000000000000e8c0 <__divmodti4>:
    e8c0:	f3 0f 1e fa          	endbr64
    e8c4:	55                   	push   %rbp
    e8c5:	49 89 f1             	mov    %rsi,%r9
    e8c8:	49 89 d2             	mov    %rdx,%r10
    e8cb:	48 89 fe             	mov    %rdi,%rsi
    e8ce:	49 89 cb             	mov    %rcx,%r11
    e8d1:	48 89 e5             	mov    %rsp,%rbp
    e8d4:	41 57                	push   %r15
    e8d6:	41 56                	push   %r14
    e8d8:	41 55                	push   %r13
    e8da:	41 54                	push   %r12
    e8dc:	53                   	push   %rbx
    e8dd:	4c 89 c3             	mov    %r8,%rbx
    e8e0:	45 31 c0             	xor    %r8d,%r8d
    e8e3:	4d 85 c9             	test   %r9,%r9
    e8e6:	79 12                	jns    e8fa <__divmodti4+0x3a>
    e8e8:	31 ff                	xor    %edi,%edi
    e8ea:	48 f7 de             	neg    %rsi
    e8ed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e8f4:	4c 19 cf             	sbb    %r9,%rdi
    e8f7:	49 89 f9             	mov    %rdi,%r9
    e8fa:	4c 89 d8             	mov    %r11,%rax
    e8fd:	4d 85 db             	test   %r11,%r11
    e900:	0f 88 1a 01 00 00    	js     ea20 <__divmodti4+0x160>
    e906:	4c 89 d9             	mov    %r11,%rcx
    e909:	49 89 f3             	mov    %rsi,%r11
    e90c:	75 62                	jne    e970 <__divmodti4+0xb0>
    e90e:	4d 89 c4             	mov    %r8,%r12
    e911:	4d 39 d1             	cmp    %r10,%r9
    e914:	0f 83 46 01 00 00    	jae    ea60 <__divmodti4+0x1a0>
    e91a:	4c 89 d8             	mov    %r11,%rax
    e91d:	4c 89 ca             	mov    %r9,%rdx
    e920:	49 f7 f2             	div    %r10
    e923:	49 89 c3             	mov    %rax,%r11
    e926:	31 c0                	xor    %eax,%eax
    e928:	48 89 d6             	mov    %rdx,%rsi
    e92b:	31 ff                	xor    %edi,%edi
    e92d:	4c 89 d9             	mov    %r11,%rcx
    e930:	48 89 c2             	mov    %rax,%rdx
    e933:	48 89 c8             	mov    %rcx,%rax
    e936:	4d 85 e4             	test   %r12,%r12
    e939:	74 0a                	je     e945 <__divmodti4+0x85>
    e93b:	48 f7 d8             	neg    %rax
    e93e:	48 83 d2 00          	adc    $0x0,%rdx
    e942:	48 f7 da             	neg    %rdx
    e945:	4d 85 c0             	test   %r8,%r8
    e948:	74 0a                	je     e954 <__divmodti4+0x94>
    e94a:	48 f7 de             	neg    %rsi
    e94d:	48 83 d7 00          	adc    $0x0,%rdi
    e951:	48 f7 df             	neg    %rdi
    e954:	48 89 33             	mov    %rsi,(%rbx)
    e957:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e95b:	5b                   	pop    %rbx
    e95c:	41 5c                	pop    %r12
    e95e:	41 5d                	pop    %r13
    e960:	41 5e                	pop    %r14
    e962:	41 5f                	pop    %r15
    e964:	5d                   	pop    %rbp
    e965:	c3                   	ret
    e966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e96d:	00 00 00 
    e970:	4d 89 c4             	mov    %r8,%r12
    e973:	49 39 c1             	cmp    %rax,%r9
    e976:	0f 82 ce 00 00 00    	jb     ea4a <__divmodti4+0x18a>
    e97c:	31 ff                	xor    %edi,%edi
    e97e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e983:	48 63 c7             	movslq %edi,%rax
    e986:	be 40 00 00 00       	mov    $0x40,%esi
    e98b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e990:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e995:	48 29 c6             	sub    %rax,%rsi
    e998:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e99d:	48 09 c8             	or     %rcx,%rax
    e9a0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e9a5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e9aa:	49 89 c6             	mov    %rax,%r14
    e9ad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e9b1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e9b6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e9bb:	49 09 c1             	or     %rax,%r9
    e9be:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e9c2:	4c 89 c8             	mov    %r9,%rax
    e9c5:	49 f7 f6             	div    %r14
    e9c8:	48 89 d1             	mov    %rdx,%rcx
    e9cb:	49 89 c3             	mov    %rax,%r11
    e9ce:	49 89 c1             	mov    %rax,%r9
    e9d1:	49 f7 e2             	mul    %r10
    e9d4:	49 89 c6             	mov    %rax,%r14
    e9d7:	49 89 d2             	mov    %rdx,%r10
    e9da:	48 39 d1             	cmp    %rdx,%rcx
    e9dd:	72 07                	jb     e9e6 <__divmodti4+0x126>
    e9df:	75 17                	jne    e9f8 <__divmodti4+0x138>
    e9e1:	49 39 c7             	cmp    %rax,%r15
    e9e4:	73 12                	jae    e9f8 <__divmodti4+0x138>
    e9e6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e9ea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e9ee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e9f2:	49 89 d2             	mov    %rdx,%r10
    e9f5:	49 89 c6             	mov    %rax,%r14
    e9f8:	4c 89 f8             	mov    %r15,%rax
    e9fb:	4c 29 f0             	sub    %r14,%rax
    e9fe:	4c 19 d1             	sbb    %r10,%rcx
    ea01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ea06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ea0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ea10:	48 09 c6             	or     %rax,%rsi
    ea13:	48 89 cf             	mov    %rcx,%rdi
    ea16:	31 c0                	xor    %eax,%eax
    ea18:	4c 89 c9             	mov    %r9,%rcx
    ea1b:	e9 10 ff ff ff       	jmp    e930 <__divmodti4+0x70>
    ea20:	4c 89 d0             	mov    %r10,%rax
    ea23:	4c 89 da             	mov    %r11,%rdx
    ea26:	4d 89 c4             	mov    %r8,%r12
    ea29:	49 89 f3             	mov    %rsi,%r11
    ea2c:	48 f7 d8             	neg    %rax
    ea2f:	49 f7 d4             	not    %r12
    ea32:	48 83 d2 00          	adc    $0x0,%rdx
    ea36:	49 89 c2             	mov    %rax,%r10
    ea39:	48 f7 da             	neg    %rdx
    ea3c:	48 89 d1             	mov    %rdx,%rcx
    ea3f:	0f 84 cc fe ff ff    	je     e911 <__divmodti4+0x51>
    ea45:	49 39 d1             	cmp    %rdx,%r9
    ea48:	73 46                	jae    ea90 <__divmodti4+0x1d0>
    ea4a:	4c 89 cf             	mov    %r9,%rdi
    ea4d:	31 c0                	xor    %eax,%eax
    ea4f:	31 c9                	xor    %ecx,%ecx
    ea51:	e9 da fe ff ff       	jmp    e930 <__divmodti4+0x70>
    ea56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ea5d:	00 00 00 
    ea60:	4d 85 d2             	test   %r10,%r10
    ea63:	75 0d                	jne    ea72 <__divmodti4+0x1b2>
    ea65:	b8 01 00 00 00       	mov    $0x1,%eax
    ea6a:	31 d2                	xor    %edx,%edx
    ea6c:	49 f7 f2             	div    %r10
    ea6f:	49 89 c2             	mov    %rax,%r10
    ea72:	4c 89 c8             	mov    %r9,%rax
    ea75:	31 d2                	xor    %edx,%edx
    ea77:	49 f7 f2             	div    %r10
    ea7a:	49 89 c1             	mov    %rax,%r9
    ea7d:	4c 89 d8             	mov    %r11,%rax
    ea80:	49 f7 f2             	div    %r10
    ea83:	49 89 c3             	mov    %rax,%r11
    ea86:	4c 89 c8             	mov    %r9,%rax
    ea89:	e9 9a fe ff ff       	jmp    e928 <__divmodti4+0x68>
    ea8e:	66 90                	xchg   %ax,%ax
    ea90:	45 31 f6             	xor    %r14d,%r14d
    ea93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ea98:	44 89 f7             	mov    %r14d,%edi
    ea9b:	45 85 f6             	test   %r14d,%r14d
    ea9e:	0f 85 df fe ff ff    	jne    e983 <__divmodti4+0xc3>
    eaa4:	4c 39 ca             	cmp    %r9,%rdx
    eaa7:	72 17                	jb     eac0 <__divmodti4+0x200>
    eaa9:	31 c9                	xor    %ecx,%ecx
    eaab:	48 39 c6             	cmp    %rax,%rsi
    eaae:	73 10                	jae    eac0 <__divmodti4+0x200>
    eab0:	4c 89 cf             	mov    %r9,%rdi
    eab3:	31 c0                	xor    %eax,%eax
    eab5:	e9 76 fe ff ff       	jmp    e930 <__divmodti4+0x70>
    eaba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    eac0:	4c 89 de             	mov    %r11,%rsi
    eac3:	b9 01 00 00 00       	mov    $0x1,%ecx
    eac8:	48 29 c6             	sub    %rax,%rsi
    eacb:	49 19 d1             	sbb    %rdx,%r9
    eace:	eb e0                	jmp    eab0 <__divmodti4+0x1f0>

000000000000ead0 <atexit>:
    ead0:	f3 0f 1e fa          	endbr64
    ead4:	48 8b 15 2d 45 00 00 	mov    0x452d(%rip),%rdx        # 13008 <__dso_handle>
    eadb:	31 f6                	xor    %esi,%esi
    eadd:	e9 7e 4b ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000eae4 <_fini>:
    eae4:	f3 0f 1e fa          	endbr64
    eae8:	48 83 ec 08          	sub    $0x8,%rsp
    eaec:	48 83 c4 08          	add    $0x8,%rsp
    eaf0:	c3                   	ret
