
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ef 00 00 	mov    0xefc9(%rip),%rax        # 11fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 ed 00 00    	push   0xede2(%rip)        # 11e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 ed 00 00    	jmp    *0xede4(%rip)        # 11e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e ec 00 00    	jmp    *0xec4e(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ea 00 00    	jmp    *0xea6e(%rip)        # 11e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ea 00 00    	jmp    *0xea66(%rip)        # 11e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ea 00 00    	jmp    *0xea5e(%rip)        # 11e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ea 00 00    	jmp    *0xea56(%rip)        # 11e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ea 00 00    	jmp    *0xea4e(%rip)        # 11e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ea 00 00    	jmp    *0xea46(%rip)        # 11e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ea 00 00    	jmp    *0xea3e(%rip)        # 11e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ea 00 00    	jmp    *0xea36(%rip)        # 11e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ea 00 00    	jmp    *0xea2e(%rip)        # 11e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ea 00 00    	jmp    *0xea26(%rip)        # 11e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ea 00 00    	jmp    *0xea1e(%rip)        # 11e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ea 00 00    	jmp    *0xea16(%rip)        # 11e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ea 00 00    	jmp    *0xea0e(%rip)        # 11e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ea 00 00    	jmp    *0xea06(%rip)        # 11e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe e9 00 00    	jmp    *0xe9fe(%rip)        # 11e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 e9 00 00    	jmp    *0xe9f6(%rip)        # 11e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee e9 00 00    	jmp    *0xe9ee(%rip)        # 11e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 e9 00 00    	jmp    *0xe9e6(%rip)        # 11ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de e9 00 00    	jmp    *0xe9de(%rip)        # 11ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 e9 00 00    	jmp    *0xe9d6(%rip)        # 11eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce e9 00 00    	jmp    *0xe9ce(%rip)        # 11eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 e9 00 00    	jmp    *0xe9c6(%rip)        # 11ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be e9 00 00    	jmp    *0xe9be(%rip)        # 11ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 e9 00 00    	jmp    *0xe9b6(%rip)        # 11ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae e9 00 00    	jmp    *0xe9ae(%rip)        # 11ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 e9 00 00    	jmp    *0xe9a6(%rip)        # 11ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e e9 00 00    	jmp    *0xe99e(%rip)        # 11ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 e9 00 00    	jmp    *0xe996(%rip)        # 11ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e e9 00 00    	jmp    *0xe98e(%rip)        # 11ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 e9 00 00    	jmp    *0xe986(%rip)        # 11f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e e9 00 00    	jmp    *0xe97e(%rip)        # 11f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 e9 00 00    	jmp    *0xe976(%rip)        # 11f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e e9 00 00    	jmp    *0xe96e(%rip)        # 11f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 e9 00 00    	jmp    *0xe966(%rip)        # 11f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e e9 00 00    	jmp    *0xe95e(%rip)        # 11f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 e9 00 00    	jmp    *0xe956(%rip)        # 11f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e e9 00 00    	jmp    *0xe94e(%rip)        # 11f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 e9 00 00    	jmp    *0xe946(%rip)        # 11f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e e9 00 00    	jmp    *0xe93e(%rip)        # 11f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 e9 00 00    	jmp    *0xe936(%rip)        # 11f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e e9 00 00    	jmp    *0xe92e(%rip)        # 11f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 e9 00 00    	jmp    *0xe926(%rip)        # 11f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e e9 00 00    	jmp    *0xe91e(%rip)        # 11f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 e9 00 00    	jmp    *0xe916(%rip)        # 11f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e e9 00 00    	jmp    *0xe90e(%rip)        # 11f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 e9 00 00    	jmp    *0xe906(%rip)        # 11f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe e8 00 00    	jmp    *0xe8fe(%rip)        # 11f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 e8 00 00    	jmp    *0xe8f6(%rip)        # 11f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee e8 00 00    	jmp    *0xe8ee(%rip)        # 11f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 e8 00 00    	jmp    *0xe8e6(%rip)        # 11fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de e8 00 00    	jmp    *0xe8de(%rip)        # 11fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 e8 00 00    	jmp    *0xe8d6(%rip)        # 11fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce e8 00 00    	jmp    *0xe8ce(%rip)        # 11fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 e8 00 00    	jmp    *0xe8c6(%rip)        # 11fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a a9 00 00 	lea    0xa97a(%rip),%r9        # e091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 a9 00 00 	lea    0xa977(%rip),%r8        # e095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 cb 00 00 	lea    0xcba1(%rip),%rax        # 10320 <fwp_fn_table>
    377f:	48 89 05 32 0c 02 00 	mov    %rax,0x20c32(%rip)        # 243b8 <fwp_fns>
    3786:	48 8b 05 93 e8 00 00 	mov    0xe893(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c 0c 02 00 	mov    %rax,0x20c2c(%rip)        # 243c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 aa 00 00 	lea    0xaa59(%rip),%rdi        # e1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 e8 00 00 	mov    0xe818(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 af 9d 00 00 	lea    0x9daf(%rip),%rdx        # d610 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 e7 00 00 	mov    0xe783(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 e7 01 00    	mov    0x1e7d8(%rip),%eax        # 22080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 a9 00 00 	lea    0xa909(%rip),%rdi        # e202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 b0 00 00 	lea    0xb096(%rip),%rdi        # e9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 50 b0 00 00 	lea    0xb050(%rip),%rdi        # e978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 b0 00 00 	lea    0xb014(%rip),%rdi        # e948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 af 00 00 	lea    0xafe0(%rip),%rdi        # e920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 e6 00 00    	call   *0xe653(%rip)        # 11fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 e6 00 00 	lea    0xe699(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 e6 00 00 	lea    0xe692(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 e6 00 00 	mov    0xe636(%rip),%rax        # 11fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 e6 00 00 	lea    0xe669(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 e6 00 00 	lea    0xe662(%rip),%rsi        # 12020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 e6 00 00 	mov    0xe605(%rip),%rax        # 11fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d e6 00 00 00 	cmpb   $0x0,0xe64d(%rip)        # 12048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 e5 00 00 	cmpq   $0x0,0xe5e2(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 e5 00 00 	mov    0xe5f6(%rip),%rdi        # 12008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 e6 00 00 01 	movb   $0x1,0xe625(%rip)        # 12048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce e4 01 00 	add    0x1e4ce(%rip),%rdx        # 220f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc e4 01 00 	add    0x1e4bc(%rip),%rax        # 220f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 07 02 00 	mov    0x20749(%rip),%rdi        # 243c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 e3 00 00 	mov    0xe394(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 e3 00 00 	mov    0xe381(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 a3 00 00 	lea    0xa345(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 e3 00 00 	mov    0xe372(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ea 01 00 	mov    0x1ea41(%rip),%rax        # 22740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 e3 01 00 	mov    0x1e381(%rip),%rax        # 22100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d e3 01 00 	sub    0x1e36d(%rip),%rax        # 220f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd ac 00 00 	lea    0xacbd(%rip),%rsi        # ea80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b fd 01 00 	mov    0x1fd5b(%rip),%rax        # 23b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 fd 01 00 	lea    0x1fd54(%rip),%r8        # 23b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 fd 01 00 	mov    0x1fd35(%rip),%rbx        # 23b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 fd 01 00 	mov    0x1fd45(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 fc 01 00 	mov    0x1fce1(%rip),%rdi        # 23b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a fd 01 00 	sub    %rsi,0x1fd2a(%rip)        # 23b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba fc 01 00 	mov    0x1fcba(%rip),%rax        # 23b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 fc 01 00 	add    0x1fc70(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e fc 01 00 	mov    0x1fc7e(%rip),%rsi        # 23b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c fc 01 00 	mov    0x1fc8c(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b fc 01 00 	mov    %r12,0x1fc3b(%rip)        # 23b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 fc 01 00 	mov    %rbp,0x1fc29(%rip)        # 23b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e fc 01 00 	cmp    %rdi,0x1fc0e(%rip)        # 23b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 fc 01 00 	mov    %rdi,0x1fc05(%rip)        # 23b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 fc 01 00 	sub    %rdi,0x1fc49(%rip)        # 23b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 fb 01 00 	mov    0x1fbf1(%rip),%rax        # 23b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea fb 01 00 	lea    0x1fbea(%rip),%r8        # 23b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd df 00 00 	mov    0xdffd(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 9f 00 00 	lea    0x9fb4(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 e6 01 00 	cmp    0x1e689(%rip),%rdi        # 22740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f e6 01 00 	mov    0x1e64f(%rip),%rax        # 22720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d e6 01 00 	mov    %rdi,0x1e62d(%rip)        # 22720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 e6 01 00 	mov    %rdi,0x1e609(%rip)        # 22728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 9f 00 00 	lea    0x9fdb(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 9e 00 00 	lea    0x9ea7(%rip),%rsi        # e01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 de 00 00 	mov    0xde78(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 9e 00 00 	lea    0x9e51(%rip),%rdx        # e020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 de 00 00 	mov    0xde60(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 dd 00 00 	mov    0xdd71(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 9d 00 00 	lea    0x9d28(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 9d 00 00 	lea    0x9d32(%rip),%rdi        # e02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 9c 00 00 	lea    0x9cba(%rip),%rdi        # e049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 a2 00 00 	lea    0xa270(%rip),%rdi        # e610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 a7 00 	movdqa 0xa710(%rip),%xmm0        # ead0 <msg.4+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a ff 01 00 	add    0x1ff9a(%rip),%rax        # 243b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc a1 00 00 	lea    0xa1cc(%rip),%rdi        # e640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 dc 01 00 	cmp    %rax,0x1dc55(%rip)        # 220e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 dc 01 00 	add    0x1dc50(%rip),%rax        # 220f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 a1 00 00 	lea    0xa1b5(%rip),%rdi        # e670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 9b 00 00 	lea    0x9b92(%rip),%r8        # e065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 99 00 00 	lea    0x99e7(%rip),%r8        # e074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 98 00 00 	lea    0x9874(%rip),%r8        # e06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 96 00 00 	lea    0x964c(%rip),%rdi        # e079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 97 00 00 	lea    0x9736(%rip),%rsi        # e184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 f0 01 00 	mov    0x1f065(%rip),%r9        # 23b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be f0 01 00 	mov    0x1f0be(%rip),%r8        # 23b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef 9b 00 00 	lea    0x9bef(%rip),%rdx        # e6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 f0 01 00 	mov    0x1f0a6(%rip),%rcx        # 23b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 f0 01 	movsd  0x1f0b4(%rip),%xmm1        # 23ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 f0 01 	movsd  0x1f0a4(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 d5 00 00 	mov    0xd545(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 9f 00 	movdqa 0x9fa8(%rip),%xmm0        # eae0 <msg.4+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f eb 01 00 	lea    0x1eb5f(%rip),%rax        # 236a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 9f 00 	movdqa 0x9fd1(%rip),%xmm2        # eb20 <msg.4+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 eb 01 00 	movaps %xmm0,0x1eb05(%rip)        # 23660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d 9f 00 	movdqa 0x9f8d(%rip),%xmm0        # eaf0 <msg.4+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 ef 01 00 01 	movl   $0x1,0x1ef93(%rip)        # 23b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ea 01 00 	movaps %xmm0,0x1eaf3(%rip)        # 23670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b 9f 00 	movdqa 0x9f7b(%rip),%xmm0        # eb00 <msg.4+0x80>
    4b84:	00 
    4b85:	0f 29 05 f4 ea 01 00 	movaps %xmm0,0x1eaf4(%rip)        # 23680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c 9f 00 	movdqa 0x9f7c(%rip),%xmm0        # eb10 <msg.4+0x90>
    4b93:	00 
    4b94:	0f 29 05 f5 ea 01 00 	movaps %xmm0,0x1eaf5(%rip)        # 23690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 db 01 00 	lea    0x1db75(%rip),%r8        # 22760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ee 01 00 	mov    %rax,0x1ee90(%rip)        # 23b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ee 01 00 	mov    %r12,0x1ee6e(%rip)        # 23b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ee 01 00 	mov    %rax,0x1ee57(%rip)        # 23b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ee 01 00 	mov    %rbx,0x1ee70(%rip)        # 23b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ee 01 00 	mov    %rsi,0x1ee99(%rip)        # 23b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 93 00 00 	lea    0x93d6(%rip),%rdi        # e0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ee 01 00 	mov    %rax,0x1ee78(%rip)        # 23b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc ed 01 00    	mov    %eax,0x1edfc(%rip)        # 23b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec d9 01 00 	mov    0x1d9ec(%rip),%r8        # 22720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c d9 01 00 	mov    %rbx,0x1d91c(%rip)        # 22728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 d9 01 00 	mov    %r8,0x1d908(%rip)        # 22720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 92 00 00 	lea    0x9239(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd d1 01 00 	lea    0x1d1dd(%rip),%rdi        # 220a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 d1 01 00 	movaps %xmm0,0x1d1c5(%rip)        # 220a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 d1 01 00 	mov    %rax,0x1d1a1(%rip)        # 22088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 d1 01 00 	movaps %xmm0,0x1d1c2(%rip)        # 220b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 d1 01 00 	movaps %xmm0,0x1d1c6(%rip)        # 220c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 d1 01 00 	mov    %rdx,0x1d1c7(%rip)        # 220d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 91 00 00 	lea    0x9190(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 d7 01 00 	mov    0x1d797(%rip),%rbx        # 22718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca cf 00 00 	mov    0xcfca(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d cb 96 00 00 	lea    0x96cb(%rip),%rdi        # e748 <_IO_stdin_used+0x748>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d d6 01 00 	mov    0x1d66d(%rip),%rax        # 22720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 d6 01 00 	mov    %rdx,0x1d647(%rip)        # 22720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 d5 01 00 	mov    0x1d594(%rip),%rbx        # 22718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 d5 01 00 	mov    %rbx,0x1d551(%rip)        # 22718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 d5 01 00 	mov    %rdx,0x1d551(%rip)        # 22728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 d5 01 00 	lea    0x1d566(%rip),%rsi        # 22760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 f0 01 00 	addq   $0x1,0x1f0e5(%rip)        # 243a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 9f 94 00 00 	lea    0x949f(%rip),%rdi        # e778 <_IO_stdin_used+0x778>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d b0 94 00 00 	lea    0x94b0(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 8d 00 00 	lea    0x8dd4(%rip),%rdi        # e0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e d4 01 00 	lea    0x1d41e(%rip),%rcx        # 22760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f f0 01 00 	subq   $0x1,0x1f01f(%rip)        # 243a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 0b 94 00 00 	lea    0x940b(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 f0 01 00 	cmpq   $0x0,0x1f000(%rip)        # 243a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 ef 01 00 	sub    %rax,0x1ef55(%rip)        # 243b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 ef 01 00 	add    %r12,0x1ef33(%rip)        # 243b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f e6 01 00 	mov    0x1e68f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c d2 01 00 	lea    0x1d28c(%rip),%rax        # 22760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 e5 01 00 	add    0x1e5e3(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 e5 01 00 	mov    0x1e5b0(%rip),%rsi        # 23b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 e5 01 00 	mov    0x1e5d1(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 e5 01 00 	add    0x1e5c5(%rip),%r8        # 23b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d e5 01 	addsd  0x1e58d(%rip),%xmm0        # 23ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 d1 01 00 	lea    0x1d142(%rip),%rax        # 22760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c e5 01 00 	sub    %rdi,0x1e54c(%rip)        # 23b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 e5 01 	movsd  %xmm0,0x1e564(%rip)        # 23ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e e5 01 00 	sub    %rdx,0x1e51e(%rip)        # 23b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 e5 01 	addsd  0x1e524(%rip),%xmm0        # 23ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 e5 01 	movsd  %xmm0,0x1e518(%rip)        # 23ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af e4 01 00 	mov    0x1e4af(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 e4 01 00 	add    %rcx,0x1e4a9(%rip)        # 23b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 e4 01 00 	cmp    0x1e462(%rip),%r9        # 23b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 e4 01 00 	mov    %r9,0x1e459(%rip)        # 23b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a e4 01 00 	cmp    0x1e44a(%rip),%r9        # 23b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d e4 01 00 	mov    %r9,0x1e43d(%rip)        # 23b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 e3 01 00 	add    0x1e353(%rip),%rdi        # 23b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 cf 01 00 	lea    0x1cf30(%rip),%r15        # 22760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 e2 01 00 	add    0x1e2a0(%rip),%r12        # 23b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 e2 01 00 	add    0x1e2f9(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 e2 01 00 	cmp    %rax,0x1e2f8(%rip)        # 23b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 e2 01 00 	mov    %rax,0x1e2e9(%rip)        # 23b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 e2 01 00 	mov    %rax,0x1e2e8(%rip)        # 23b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 e2 01 	addsd  0x1e2e4(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc e2 01 	movsd  %xmm0,0x1e2dc(%rip)        # 23b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 e2 01 00    	mov    0x1e223(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ce 01 00 	lea    0x1ce5f(%rip),%rdi        # 22760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 e2 01 00 	add    0x1e218(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 e2 01 00 	cmp    %rax,0x1e213(%rip)        # 23b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 e2 01 00 	mov    %rax,0x1e204(%rip)        # 23b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 e2 01 00 	mov    %rax,0x1e203(%rip)        # 23b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff e1 01 	addsd  0x1e1ff(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 e1 01 	movsd  %xmm0,0x1e1f7(%rip)        # 23b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae e0 01 00    	mov    0x1e0ae(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 cc 01 00 	lea    0x1cce5(%rip),%rax        # 22760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b e0 01 00 	add    0x1e09b(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a e0 01 00 	cmp    %rax,0x1e09a(%rip)        # 23b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b e0 01 00 	mov    %rax,0x1e08b(%rip)        # 23b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a e0 01 00 	mov    %rax,0x1e08a(%rip)        # 23b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 e0 01 	addsd  0x1e086(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e e0 01 	movsd  %xmm0,0x1e07e(%rip)        # 23b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e df 01 00    	mov    0x1df7e(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d db 01 00 	movzbl 0x1db6d(%rip),%eax        # 23702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 cb 01 00 	lea    0x1cbc4(%rip),%rdx        # 22760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 df 01 00 	add    0x1df95(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 df 01 00 	cmp    %rax,0x1df90(%rip)        # 23b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 23b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 df 01 00 	mov    %rax,0x1df80(%rip)        # 23b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f df 01 	addsd  0x1df7f(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 df 01 	movsd  %xmm0,0x1df77(%rip)        # 23b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 38          	sub    $0x38,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 a9 01 00 00    	js     5e70 <fwp_p_ad_push+0x1d0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	48 09 d0             	or     %rdx,%rax
    5cd1:	0f 89 79 01 00 00    	jns    5e50 <fwp_p_ad_push+0x1b0>
    5cd7:	48 89 f8             	mov    %rdi,%rax
    5cda:	48 c1 f8 20          	sar    $0x20,%rax
    5cde:	48 85 ff             	test   %rdi,%rdi
    5ce1:	79 24                	jns    5d07 <fwp_p_ad_push+0x67>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	48 89 d0             	mov    %rdx,%rax
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	48 c1 f8 20          	sar    $0x20,%rax
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 89 c7             	mov    %rax,%rdi
    5d0a:	e8 71 e7 ff ff       	call   4480 <fwp_tape_of>
    5d0f:	48 89 c3             	mov    %rax,%rbx
    5d12:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d17:	0f 85 76 02 00 00    	jne    5f93 <fwp_p_ad_push+0x2f3>
    5d1d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d21:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d28:	0f 8f 59 02 00 00    	jg     5f87 <fwp_p_ad_push+0x2e7>
    5d2e:	44 89 e0             	mov    %r12d,%eax
    5d31:	4c 39 f8             	cmp    %r15,%rax
    5d34:	0f 8d 41 02 00 00    	jge    5f7b <fwp_p_ad_push+0x2db>
    5d3a:	4d 85 ed             	test   %r13,%r13
    5d3d:	78 0c                	js     5d4b <fwp_p_ad_push+0xab>
    5d3f:	44 89 e8             	mov    %r13d,%eax
    5d42:	4c 39 f8             	cmp    %r15,%rax
    5d45:	0f 8d 30 02 00 00    	jge    5f7b <fwp_p_ad_push+0x2db>
    5d4b:	4d 89 fe             	mov    %r15,%r14
    5d4e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5d52:	49 8d 46 01          	lea    0x1(%r14),%rax
    5d56:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d5c:	0f 87 25 02 00 00    	ja     5f87 <fwp_p_ad_push+0x2e7>
    5d62:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d66:	48 39 e8             	cmp    %rbp,%rax
    5d69:	0f 8e 31 01 00 00    	jle    5ea0 <fwp_p_ad_push+0x200>
    5d6f:	48 85 ed             	test   %rbp,%rbp
    5d72:	b9 40 00 00 00       	mov    $0x40,%ecx
    5d77:	48 0f 44 e9          	cmove  %rcx,%rbp
    5d7b:	48 39 e8             	cmp    %rbp,%rax
    5d7e:	7e 20                	jle    5da0 <fwp_p_ad_push+0x100>
    5d80:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5d87:	0f 8f 03 01 00 00    	jg     5e90 <fwp_p_ad_push+0x1f0>
    5d8d:	48 01 ed             	add    %rbp,%rbp
    5d90:	48 39 e8             	cmp    %rbp,%rax
    5d93:	7f eb                	jg     5d80 <fwp_p_ad_push+0xe0>
    5d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d9c:	00 00 00 00 
    5da0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5da7:	00 
    5da8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dac:	48 89 c6             	mov    %rax,%rsi
    5daf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5db4:	e8 17 d8 ff ff       	call   35d0 <realloc@plt>
    5db9:	48 85 c0             	test   %rax,%rax
    5dbc:	0f 84 dd 01 00 00    	je     5f9f <fwp_p_ad_push+0x2ff>
    5dc2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5dc6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5dca:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5dce:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5dd2:	48 89 e9             	mov    %rbp,%rcx
    5dd5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5dd9:	48 c1 e1 04          	shl    $0x4,%rcx
    5ddd:	48 89 ce             	mov    %rcx,%rsi
    5de0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5de5:	e8 e6 d7 ff ff       	call   35d0 <realloc@plt>
    5dea:	48 85 c0             	test   %rax,%rax
    5ded:	0f 84 ac 01 00 00    	je     5f9f <fwp_p_ad_push+0x2ff>
    5df3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5df7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5dfc:	4d 85 f6             	test   %r14,%r14
    5dff:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e03:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e08:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e0f:	00 
    5e10:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e17:	00 
    5e18:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e1c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e23:	00 
    5e24:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e28:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e2c:	0f 85 e2 00 00 00    	jne    5f14 <fwp_p_ad_push+0x274>
    5e32:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e36:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e3a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e3e:	49 01 c8             	add    %rcx,%r8
    5e41:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5e45:	eb 79                	jmp    5ec0 <fwp_p_ad_push+0x220>
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	48 89 d0             	mov    %rdx,%rax
    5e53:	48 c1 ff 20          	sar    $0x20,%rdi
    5e57:	48 c1 f8 20          	sar    $0x20,%rax
    5e5b:	48 39 c7             	cmp    %rax,%rdi
    5e5e:	0f 84 a3 fe ff ff    	je     5d07 <fwp_p_ad_push+0x67>
    5e64:	48 8d 3d 5d 89 00 00 	lea    0x895d(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    5e6b:	e8 30 e3 ff ff       	call   41a0 <fwp_trap>
    5e70:	48 83 c4 38          	add    $0x38,%rsp
    5e74:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5e7b:	5b                   	pop    %rbx
    5e7c:	5d                   	pop    %rbp
    5e7d:	41 5c                	pop    %r12
    5e7f:	41 5d                	pop    %r13
    5e81:	41 5e                	pop    %r14
    5e83:	41 5f                	pop    %r15
    5e85:	c3                   	ret
    5e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e8d:	00 00 00 
    5e90:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5e95:	e9 06 ff ff ff       	jmp    5da0 <fwp_p_ad_push+0x100>
    5e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5ea4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5ea8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5eaf:	00 
    5eb0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5eb7:	00 
    5eb8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5ebc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ec0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5ec6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5eca:	4d 85 ed             	test   %r13,%r13
    5ecd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5ed2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5ed8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edf:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ee3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ee7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5eeb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5ef1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ef5:	48 83 c4 38          	add    $0x38,%rsp
    5ef9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f00:	ff ff ff 
    5f03:	4c 21 e0             	and    %r12,%rax
    5f06:	5b                   	pop    %rbx
    5f07:	5d                   	pop    %rbp
    5f08:	4c 09 f8             	or     %r15,%rax
    5f0b:	41 5c                	pop    %r12
    5f0d:	41 5d                	pop    %r13
    5f0f:	41 5e                	pop    %r14
    5f11:	41 5f                	pop    %r15
    5f13:	c3                   	ret
    5f14:	48 39 ca             	cmp    %rcx,%rdx
    5f17:	49 89 d6             	mov    %rdx,%r14
    5f1a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f1f:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f23:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f28:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f2d:	48 29 d1             	sub    %rdx,%rcx
    5f30:	4c 89 ca             	mov    %r9,%rdx
    5f33:	e8 28 d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f38:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f3c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5f41:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5f45:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5f4a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5f4e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5f52:	4c 89 d2             	mov    %r10,%rdx
    5f55:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5f5a:	e8 b1 d6 ff ff       	call   3610 <memmove@plt>
    5f5f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f63:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f67:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5f6c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5f71:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5f76:	e9 bb fe ff ff       	jmp    5e36 <fwp_p_ad_push+0x196>
    5f7b:	48 8d 3d 82 81 00 00 	lea    0x8182(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    5f82:	e8 19 e2 ff ff       	call   41a0 <fwp_trap>
    5f87:	48 8d 3d 5b 81 00 00 	lea    0x815b(%rip),%rdi        # e0e9 <_IO_stdin_used+0xe9>
    5f8e:	e8 0d e2 ff ff       	call   41a0 <fwp_trap>
    5f93:	48 8d 3d 76 88 00 00 	lea    0x8876(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    5f9a:	e8 01 e2 ff ff       	call   41a0 <fwp_trap>
    5f9f:	48 89 df             	mov    %rbx,%rdi
    5fa2:	e8 59 dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5fa7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fab:	e8 10 d4 ff ff       	call   33c0 <free@plt>
    5fb0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fb4:	e8 07 d4 ff ff       	call   33c0 <free@plt>
    5fb9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    5fbd:	e8 fe d3 ff ff       	call   33c0 <free@plt>
    5fc2:	31 c9                	xor    %ecx,%ecx
    5fc4:	31 c0                	xor    %eax,%eax
    5fc6:	31 d2                	xor    %edx,%edx
    5fc8:	89 53 04             	mov    %edx,0x4(%rbx)
    5fcb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fcf:	ba 13 00 00 00       	mov    $0x13,%edx
    5fd4:	be 01 00 00 00       	mov    $0x1,%esi
    5fd9:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    5fdd:	48 8d 3d 24 80 00 00 	lea    0x8024(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    5fe4:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    5fe8:	48 8b 0d 51 c0 00 00 	mov    0xc051(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    5fef:	48 89 43 40          	mov    %rax,0x40(%rbx)
    5ff3:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5ff7:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    5ffb:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    5fff:	e8 7c d6 ff ff       	call   3680 <fwrite@plt>
    6004:	31 ff                	xor    %edi,%edi
    6006:	e8 b5 d5 ff ff       	call   35c0 <fflush@plt>
    600b:	bf 66 00 00 00       	mov    $0x66,%edi
    6010:	e8 8b d6 ff ff       	call   36a0 <_Exit@plt>
    6015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    601c:	00 00 00 00 

0000000000006020 <w120>:
    6020:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6024:	41 55                	push   %r13
    6026:	48 89 fa             	mov    %rdi,%rdx
    6029:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    602d:	41 54                	push   %r12
    602f:	49 89 fc             	mov    %rdi,%r12
    6032:	55                   	push   %rbp
    6033:	53                   	push   %rbx
    6034:	48 89 f3             	mov    %rsi,%rbx
    6037:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    603c:	48 89 f1             	mov    %rsi,%rcx
    603f:	48 83 ec 28          	sub    $0x28,%rsp
    6043:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6049:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    604f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6055:	e8 46 fc ff ff       	call   5ca0 <fwp_p_ad_push>
    605a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6060:	48 89 da             	mov    %rbx,%rdx
    6063:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6069:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6070:	00 f0 3f 
    6073:	48 89 c7             	mov    %rax,%rdi
    6076:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    607d:	00 f0 bf 
    6080:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6085:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    608b:	e8 10 fc ff ff       	call   5ca0 <fwp_p_ad_push>
    6090:	f2 0f 10 05 10 8a 00 	movsd  0x8a10(%rip),%xmm0        # eaa8 <msg.4+0x28>
    6097:	00 
    6098:	4c 89 e7             	mov    %r12,%rdi
    609b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    60a1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    60a8:	00 f0 3f 
    60ab:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60b2:	49 89 c5             	mov    %rax,%r13
    60b5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    60bc:	00 f0 bf 
    60bf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    60c4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60ca:	e8 d1 fb ff ff       	call   5ca0 <fwp_p_ad_push>
    60cf:	48 89 e9             	mov    %rbp,%rcx
    60d2:	4c 89 ea             	mov    %r13,%rdx
    60d5:	48 89 ee             	mov    %rbp,%rsi
    60d8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    60de:	4c 89 ef             	mov    %r13,%rdi
    60e1:	49 89 c4             	mov    %rax,%r12
    60e4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    60e8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60ee:	e8 ad fb ff ff       	call   5ca0 <fwp_p_ad_push>
    60f3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    60f9:	f2 0f 59 1d af 89 00 	mulsd  0x89af(%rip),%xmm3        # eab0 <msg.4+0x30>
    6100:	00 
    6101:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6108:	00 59 40 
    610b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6110:	48 89 c2             	mov    %rax,%rdx
    6113:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    611a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6120:	e8 7b fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6125:	48 89 d9             	mov    %rbx,%rcx
    6128:	4c 89 e2             	mov    %r12,%rdx
    612b:	48 89 de             	mov    %rbx,%rsi
    612e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6134:	4c 89 e7             	mov    %r12,%rdi
    6137:	48 89 c5             	mov    %rax,%rbp
    613a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    613e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6144:	e8 57 fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6149:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    614f:	48 89 ea             	mov    %rbp,%rdx
    6152:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6158:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    615f:	00 f0 3f 
    6162:	48 89 c7             	mov    %rax,%rdi
    6165:	48 89 ce             	mov    %rcx,%rsi
    6168:	66 48 0f 7e db       	movq   %xmm3,%rbx
    616d:	e8 2e fb ff ff       	call   5ca0 <fwp_p_ad_push>
    6172:	48 83 c4 28          	add    $0x28,%rsp
    6176:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    617b:	5b                   	pop    %rbx
    617c:	5d                   	pop    %rbp
    617d:	41 5c                	pop    %r12
    617f:	41 5d                	pop    %r13
    6181:	c3                   	ret
    6182:	0f 1f 00             	nopl   (%rax)
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <fwp_rc_share>:
    6190:	48 8b 05 a1 d9 01 00 	mov    0x1d9a1(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    6197:	48 2b 3d 72 d9 01 00 	sub    0x1d972(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    619e:	48 c1 e0 10          	shl    $0x10,%rax
    61a2:	48 39 c7             	cmp    %rax,%rdi
    61a5:	73 4a                	jae    61f1 <fwp_rc_share+0x61>
    61a7:	48 89 f8             	mov    %rdi,%rax
    61aa:	48 c1 e8 10          	shr    $0x10,%rax
    61ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    61b2:	48 8b 05 9f d9 01 00 	mov    0x1d99f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    61b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    61bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    61c1:	48 85 d2             	test   %rdx,%rdx
    61c4:	74 2b                	je     61f1 <fwp_rc_share+0x61>
    61c6:	0f b6 08             	movzbl (%rax),%ecx
    61c9:	80 f9 02             	cmp    $0x2,%cl
    61cc:	74 2a                	je     61f8 <fwp_rc_share+0x68>
    61ce:	80 f9 01             	cmp    $0x1,%cl
    61d1:	75 1e                	jne    61f1 <fwp_rc_share+0x61>
    61d3:	8b 48 18             	mov    0x18(%rax),%ecx
    61d6:	0f b7 ff             	movzwl %di,%edi
    61d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    61dc:	48 0f af f9          	imul   %rcx,%rdi
    61e0:	48 c1 ef 20          	shr    $0x20,%rdi
    61e4:	48 39 c7             	cmp    %rax,%rdi
    61e7:	73 08                	jae    61f1 <fwp_rc_share+0x61>
    61e9:	48 01 fa             	add    %rdi,%rdx
    61ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    61ef:	75 0d                	jne    61fe <fwp_rc_share+0x6e>
    61f1:	c3                   	ret
    61f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f8:	66 85 ff             	test   %di,%di
    61fb:	74 ef                	je     61ec <fwp_rc_share+0x5c>
    61fd:	c3                   	ret
    61fe:	50                   	push   %rax
    61ff:	48 8d 3d 3a 86 00 00 	lea    0x863a(%rip),%rdi        # e840 <_IO_stdin_used+0x840>
    6206:	e8 95 df ff ff       	call   41a0 <fwp_trap>
    620b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006210 <fwp_rc_fresh>:
    6210:	48 8b 15 21 d9 01 00 	mov    0x1d921(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6217:	48 89 f8             	mov    %rdi,%rax
    621a:	48 89 fe             	mov    %rdi,%rsi
    621d:	48 2b 05 ec d8 01 00 	sub    0x1d8ec(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6224:	48 c1 e2 10          	shl    $0x10,%rdx
    6228:	48 39 d0             	cmp    %rdx,%rax
    622b:	73 4f                	jae    627c <fwp_rc_fresh+0x6c>
    622d:	48 89 c2             	mov    %rax,%rdx
    6230:	48 c1 ea 10          	shr    $0x10,%rdx
    6234:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6238:	48 8b 15 19 d9 01 00 	mov    0x1d919(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    623f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6243:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6247:	48 85 d2             	test   %rdx,%rdx
    624a:	74 30                	je     627c <fwp_rc_fresh+0x6c>
    624c:	0f b6 39             	movzbl (%rcx),%edi
    624f:	40 80 ff 02          	cmp    $0x2,%dil
    6253:	74 2b                	je     6280 <fwp_rc_fresh+0x70>
    6255:	40 80 ff 01          	cmp    $0x1,%dil
    6259:	75 21                	jne    627c <fwp_rc_fresh+0x6c>
    625b:	8b 79 18             	mov    0x18(%rcx),%edi
    625e:	0f b7 c0             	movzwl %ax,%eax
    6261:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6264:	48 0f af c7          	imul   %rdi,%rax
    6268:	48 c1 e8 20          	shr    $0x20,%rax
    626c:	48 39 c8             	cmp    %rcx,%rax
    626f:	73 0b                	jae    627c <fwp_rc_fresh+0x6c>
    6271:	48 01 c2             	add    %rax,%rdx
    6274:	80 3a ff             	cmpb   $0xff,(%rdx)
    6277:	74 17                	je     6290 <fwp_rc_fresh+0x80>
    6279:	c6 02 01             	movb   $0x1,(%rdx)
    627c:	48 89 f0             	mov    %rsi,%rax
    627f:	c3                   	ret
    6280:	66 85 c0             	test   %ax,%ax
    6283:	74 ef                	je     6274 <fwp_rc_fresh+0x64>
    6285:	48 89 f0             	mov    %rsi,%rax
    6288:	c3                   	ret
    6289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6290:	48 83 ec 18          	sub    $0x18,%rsp
    6294:	48 89 d7             	mov    %rdx,%rdi
    6297:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    629c:	48 89 14 24          	mov    %rdx,(%rsp)
    62a0:	e8 6b f0 ff ff       	call   5310 <fwp_rc_forget_slot>
    62a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    62aa:	48 8b 14 24          	mov    (%rsp),%rdx
    62ae:	48 89 f0             	mov    %rsi,%rax
    62b1:	c6 02 01             	movb   $0x1,(%rdx)
    62b4:	48 83 c4 18          	add    $0x18,%rsp
    62b8:	c3                   	ret
    62b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000062c0 <fwp_rc_free_obj>:
    62c0:	48 8b 15 71 d8 01 00 	mov    0x1d871(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    62c7:	48 89 f8             	mov    %rdi,%rax
    62ca:	48 2b 05 3f d8 01 00 	sub    0x1d83f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    62d1:	48 c1 e2 10          	shl    $0x10,%rdx
    62d5:	48 39 d0             	cmp    %rdx,%rax
    62d8:	73 5b                	jae    6335 <fwp_rc_free_obj+0x75>
    62da:	48 89 c2             	mov    %rax,%rdx
    62dd:	48 c1 ea 10          	shr    $0x10,%rdx
    62e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    62e5:	48 8b 15 6c d8 01 00 	mov    0x1d86c(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    62ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    62f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    62f4:	48 85 c9             	test   %rcx,%rcx
    62f7:	74 3c                	je     6335 <fwp_rc_free_obj+0x75>
    62f9:	0f b6 32             	movzbl (%rdx),%esi
    62fc:	40 80 fe 02          	cmp    $0x2,%sil
    6300:	74 2e                	je     6330 <fwp_rc_free_obj+0x70>
    6302:	40 80 fe 01          	cmp    $0x1,%sil
    6306:	75 2d                	jne    6335 <fwp_rc_free_obj+0x75>
    6308:	8b 72 18             	mov    0x18(%rdx),%esi
    630b:	0f b7 c0             	movzwl %ax,%eax
    630e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6311:	48 0f af c6          	imul   %rsi,%rax
    6315:	48 c1 e8 20          	shr    $0x20,%rax
    6319:	48 39 d0             	cmp    %rdx,%rax
    631c:	73 17                	jae    6335 <fwp_rc_free_obj+0x75>
    631e:	48 01 c1             	add    %rax,%rcx
    6321:	80 39 01             	cmpb   $0x1,(%rcx)
    6324:	75 0f                	jne    6335 <fwp_rc_free_obj+0x75>
    6326:	e9 25 f2 ff ff       	jmp    5550 <fwp_mem_free>
    632b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6330:	66 85 c0             	test   %ax,%ax
    6333:	74 ec                	je     6321 <fwp_rc_free_obj+0x61>
    6335:	c3                   	ret
    6336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    633d:	00 00 00 

0000000000006340 <fwp_rc_dup>:
    6340:	f3 0f 1e fa          	endbr64
    6344:	48 8b 05 ed d7 01 00 	mov    0x1d7ed(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    634b:	48 2b 3d be d7 01 00 	sub    0x1d7be(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    6352:	48 c1 e0 10          	shl    $0x10,%rax
    6356:	48 39 c7             	cmp    %rax,%rdi
    6359:	73 56                	jae    63b1 <fwp_rc_dup+0x71>
    635b:	48 89 f8             	mov    %rdi,%rax
    635e:	48 c1 e8 10          	shr    $0x10,%rax
    6362:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6366:	48 8b 05 eb d7 01 00 	mov    0x1d7eb(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    636d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6371:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6375:	48 85 c0             	test   %rax,%rax
    6378:	74 37                	je     63b1 <fwp_rc_dup+0x71>
    637a:	0f b6 0a             	movzbl (%rdx),%ecx
    637d:	80 f9 02             	cmp    $0x2,%cl
    6380:	74 36                	je     63b8 <fwp_rc_dup+0x78>
    6382:	80 f9 01             	cmp    $0x1,%cl
    6385:	75 2a                	jne    63b1 <fwp_rc_dup+0x71>
    6387:	8b 4a 18             	mov    0x18(%rdx),%ecx
    638a:	0f b7 ff             	movzwl %di,%edi
    638d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6390:	48 0f af f9          	imul   %rcx,%rdi
    6394:	48 c1 ef 20          	shr    $0x20,%rdi
    6398:	48 39 d7             	cmp    %rdx,%rdi
    639b:	73 14                	jae    63b1 <fwp_rc_dup+0x71>
    639d:	48 01 f8             	add    %rdi,%rax
    63a0:	0f b6 10             	movzbl (%rax),%edx
    63a3:	84 d2                	test   %dl,%dl
    63a5:	74 0a                	je     63b1 <fwp_rc_dup+0x71>
    63a7:	80 fa fd             	cmp    $0xfd,%dl
    63aa:	77 14                	ja     63c0 <fwp_rc_dup+0x80>
    63ac:	83 c2 01             	add    $0x1,%edx
    63af:	88 10                	mov    %dl,(%rax)
    63b1:	c3                   	ret
    63b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63b8:	66 85 ff             	test   %di,%di
    63bb:	74 e3                	je     63a0 <fwp_rc_dup+0x60>
    63bd:	c3                   	ret
    63be:	66 90                	xchg   %ax,%ax
    63c0:	48 89 c7             	mov    %rax,%rdi
    63c3:	e9 28 ee ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    63c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63cf:	00 

00000000000063d0 <fwp_owned_entry173>:
    63d0:	f3 0f 1e fa          	endbr64
    63d4:	48 83 ec 38          	sub    $0x38,%rsp
    63d8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    63dd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    63e4:	00 00 
    63e6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    63eb:	31 c0                	xor    %eax,%eax
    63ed:	48 8b 07             	mov    (%rdi),%rax
    63f0:	48 03 47 10          	add    0x10(%rdi),%rax
    63f4:	0f 80 c2 00 00 00    	jo     64bc <fwp_owned_entry173+0xec>
    63fa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    63ff:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6404:	31 ff                	xor    %edi,%edi
    6406:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    640a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    640f:	e8 5c f7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6414:	48 8b 15 1d d7 01 00 	mov    0x1d71d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    641b:	48 89 c6             	mov    %rax,%rsi
    641e:	48 2b 05 eb d6 01 00 	sub    0x1d6eb(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6425:	48 c1 e2 10          	shl    $0x10,%rdx
    6429:	48 39 d0             	cmp    %rdx,%rax
    642c:	73 4f                	jae    647d <fwp_owned_entry173+0xad>
    642e:	48 89 c2             	mov    %rax,%rdx
    6431:	48 c1 ea 10          	shr    $0x10,%rdx
    6435:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6439:	48 8b 15 18 d7 01 00 	mov    0x1d718(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    6440:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6444:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6448:	48 85 d2             	test   %rdx,%rdx
    644b:	74 30                	je     647d <fwp_owned_entry173+0xad>
    644d:	0f b6 39             	movzbl (%rcx),%edi
    6450:	40 80 ff 02          	cmp    $0x2,%dil
    6454:	74 42                	je     6498 <fwp_owned_entry173+0xc8>
    6456:	40 80 ff 01          	cmp    $0x1,%dil
    645a:	75 21                	jne    647d <fwp_owned_entry173+0xad>
    645c:	8b 79 18             	mov    0x18(%rcx),%edi
    645f:	0f b7 c0             	movzwl %ax,%eax
    6462:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6465:	48 0f af c7          	imul   %rdi,%rax
    6469:	48 c1 e8 20          	shr    $0x20,%rax
    646d:	48 39 c8             	cmp    %rcx,%rax
    6470:	73 0b                	jae    647d <fwp_owned_entry173+0xad>
    6472:	48 01 c2             	add    %rax,%rdx
    6475:	80 3a ff             	cmpb   $0xff,(%rdx)
    6478:	74 26                	je     64a0 <fwp_owned_entry173+0xd0>
    647a:	c6 02 01             	movb   $0x1,(%rdx)
    647d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6482:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6489:	00 00 
    648b:	75 34                	jne    64c1 <fwp_owned_entry173+0xf1>
    648d:	48 89 f0             	mov    %rsi,%rax
    6490:	48 83 c4 38          	add    $0x38,%rsp
    6494:	c3                   	ret
    6495:	0f 1f 00             	nopl   (%rax)
    6498:	66 85 c0             	test   %ax,%ax
    649b:	75 e0                	jne    647d <fwp_owned_entry173+0xad>
    649d:	eb d6                	jmp    6475 <fwp_owned_entry173+0xa5>
    649f:	90                   	nop
    64a0:	48 89 d7             	mov    %rdx,%rdi
    64a3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    64a8:	48 89 14 24          	mov    %rdx,(%rsp)
    64ac:	e8 5f ee ff ff       	call   5310 <fwp_rc_forget_slot>
    64b1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64b6:	48 8b 14 24          	mov    (%rsp),%rdx
    64ba:	eb be                	jmp    647a <fwp_owned_entry173+0xaa>
    64bc:	e8 3f d2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    64c1:	e8 9a cf ff ff       	call   3460 <__stack_chk_fail@plt>
    64c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64cd:	00 00 00 

00000000000064d0 <e173>:
    64d0:	f3 0f 1e fa          	endbr64
    64d4:	53                   	push   %rbx
    64d5:	48 83 ec 30          	sub    $0x30,%rsp
    64d9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    64de:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    64e5:	00 00 
    64e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    64ec:	31 c0                	xor    %eax,%eax
    64ee:	48 8b 07             	mov    (%rdi),%rax
    64f1:	48 03 47 10          	add    0x10(%rdi),%rax
    64f5:	0f 80 c9 00 00 00    	jo     65c4 <e173+0xf4>
    64fb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6500:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6505:	31 ff                	xor    %edi,%edi
    6507:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    650b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6510:	e8 5b f6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6515:	48 8b 15 1c d6 01 00 	mov    0x1d61c(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    651c:	48 89 c3             	mov    %rax,%rbx
    651f:	48 2b 05 ea d5 01 00 	sub    0x1d5ea(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6526:	48 c1 e2 10          	shl    $0x10,%rdx
    652a:	48 39 d0             	cmp    %rdx,%rax
    652d:	73 4f                	jae    657e <e173+0xae>
    652f:	48 89 c2             	mov    %rax,%rdx
    6532:	48 c1 ea 10          	shr    $0x10,%rdx
    6536:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    653a:	48 8b 15 17 d6 01 00 	mov    0x1d617(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    6541:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6545:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6549:	48 85 d2             	test   %rdx,%rdx
    654c:	74 30                	je     657e <e173+0xae>
    654e:	0f b6 31             	movzbl (%rcx),%esi
    6551:	40 80 fe 02          	cmp    $0x2,%sil
    6555:	74 49                	je     65a0 <e173+0xd0>
    6557:	40 80 fe 01          	cmp    $0x1,%sil
    655b:	75 21                	jne    657e <e173+0xae>
    655d:	8b 71 18             	mov    0x18(%rcx),%esi
    6560:	0f b7 c0             	movzwl %ax,%eax
    6563:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6566:	48 0f af c6          	imul   %rsi,%rax
    656a:	48 c1 e8 20          	shr    $0x20,%rax
    656e:	48 39 c8             	cmp    %rcx,%rax
    6571:	73 0b                	jae    657e <e173+0xae>
    6573:	48 01 c2             	add    %rax,%rdx
    6576:	80 3a ff             	cmpb   $0xff,(%rdx)
    6579:	74 35                	je     65b0 <e173+0xe0>
    657b:	c6 02 01             	movb   $0x1,(%rdx)
    657e:	48 89 df             	mov    %rbx,%rdi
    6581:	e8 0a fc ff ff       	call   6190 <fwp_rc_share>
    6586:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    658b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6592:	00 00 
    6594:	75 33                	jne    65c9 <e173+0xf9>
    6596:	48 83 c4 30          	add    $0x30,%rsp
    659a:	48 89 d8             	mov    %rbx,%rax
    659d:	5b                   	pop    %rbx
    659e:	c3                   	ret
    659f:	90                   	nop
    65a0:	66 85 c0             	test   %ax,%ax
    65a3:	75 d9                	jne    657e <e173+0xae>
    65a5:	eb cf                	jmp    6576 <e173+0xa6>
    65a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    65ae:	00 00 
    65b0:	48 89 d7             	mov    %rdx,%rdi
    65b3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    65b8:	e8 53 ed ff ff       	call   5310 <fwp_rc_forget_slot>
    65bd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    65c2:	eb b7                	jmp    657b <e173+0xab>
    65c4:	e8 37 d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    65c9:	e8 92 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    65ce:	66 90                	xchg   %ax,%ax

00000000000065d0 <fwp_closure_drop>:
    65d0:	48 8b 15 61 d5 01 00 	mov    0x1d561(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    65d7:	48 89 f8             	mov    %rdi,%rax
    65da:	48 2b 05 2f d5 01 00 	sub    0x1d52f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    65e1:	48 c1 e2 10          	shl    $0x10,%rdx
    65e5:	48 39 d0             	cmp    %rdx,%rax
    65e8:	73 6b                	jae    6655 <fwp_closure_drop+0x85>
    65ea:	48 89 c2             	mov    %rax,%rdx
    65ed:	48 c1 ea 10          	shr    $0x10,%rdx
    65f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65f5:	48 8b 15 5c d5 01 00 	mov    0x1d55c(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    65fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6600:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6604:	48 85 d2             	test   %rdx,%rdx
    6607:	74 4c                	je     6655 <fwp_closure_drop+0x85>
    6609:	0f b6 31             	movzbl (%rcx),%esi
    660c:	40 80 fe 02          	cmp    $0x2,%sil
    6610:	74 3e                	je     6650 <fwp_closure_drop+0x80>
    6612:	40 80 fe 01          	cmp    $0x1,%sil
    6616:	75 3d                	jne    6655 <fwp_closure_drop+0x85>
    6618:	8b 71 18             	mov    0x18(%rcx),%esi
    661b:	0f b7 c0             	movzwl %ax,%eax
    661e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6621:	48 0f af c6          	imul   %rsi,%rax
    6625:	48 c1 e8 20          	shr    $0x20,%rax
    6629:	48 39 c8             	cmp    %rcx,%rax
    662c:	73 27                	jae    6655 <fwp_closure_drop+0x85>
    662e:	48 01 c2             	add    %rax,%rdx
    6631:	0f b6 02             	movzbl (%rdx),%eax
    6634:	84 c0                	test   %al,%al
    6636:	74 1d                	je     6655 <fwp_closure_drop+0x85>
    6638:	3c 01                	cmp    $0x1,%al
    663a:	74 24                	je     6660 <fwp_closure_drop+0x90>
    663c:	3c ff                	cmp    $0xff,%al
    663e:	74 48                	je     6688 <fwp_closure_drop+0xb8>
    6640:	83 e8 01             	sub    $0x1,%eax
    6643:	88 02                	mov    %al,(%rdx)
    6645:	c3                   	ret
    6646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    664d:	00 00 00 
    6650:	66 85 c0             	test   %ax,%ax
    6653:	74 dc                	je     6631 <fwp_closure_drop+0x61>
    6655:	c3                   	ret
    6656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    665d:	00 00 00 
    6660:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6667:	ff ff 
    6669:	48 85 c0             	test   %rax,%rax
    666c:	74 12                	je     6680 <fwp_closure_drop+0xb0>
    666e:	48 89 fe             	mov    %rdi,%rsi
    6671:	48 89 c7             	mov    %rax,%rdi
    6674:	e9 87 db ff ff       	jmp    4200 <fwp_closure_drop_push>
    6679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6680:	e9 2b dd ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6685:	0f 1f 00             	nopl   (%rax)
    6688:	48 89 d0             	mov    %rdx,%rax
    668b:	48 8d 35 ce c0 01 00 	lea    0x1c0ce(%rip),%rsi        # 22760 <fwp_heap>
    6692:	48 83 ec 18          	sub    $0x18,%rsp
    6696:	48 c1 e8 11          	shr    $0x11,%rax
    669a:	48 31 d0             	xor    %rdx,%rax
    669d:	48 89 c1             	mov    %rax,%rcx
    66a0:	48 c1 e9 09          	shr    $0x9,%rcx
    66a4:	48 31 c8             	xor    %rcx,%rax
    66a7:	0f b6 c8             	movzbl %al,%ecx
    66aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    66b1:	00 
    66b2:	48 85 c0             	test   %rax,%rax
    66b5:	75 12                	jne    66c9 <fwp_closure_drop+0xf9>
    66b7:	eb 49                	jmp    6702 <fwp_closure_drop+0x132>
    66b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    66c4:	48 85 c0             	test   %rax,%rax
    66c7:	74 39                	je     6702 <fwp_closure_drop+0x132>
    66c9:	48 89 c1             	mov    %rax,%rcx
    66cc:	48 39 10             	cmp    %rdx,(%rax)
    66cf:	75 ef                	jne    66c0 <fwp_closure_drop+0xf0>
    66d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    66d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    66d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    66dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    66e4:	74 05                	je     66eb <fwp_closure_drop+0x11b>
    66e6:	48 83 c4 18          	add    $0x18,%rsp
    66ea:	c3                   	ret
    66eb:	48 89 d7             	mov    %rdx,%rdi
    66ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    66f3:	e8 18 ec ff ff       	call   5310 <fwp_rc_forget_slot>
    66f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    66fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6700:	eb e4                	jmp    66e6 <fwp_closure_drop+0x116>
    6702:	48 8d 3d 97 80 00 00 	lea    0x8097(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6709:	e8 92 da ff ff       	call   41a0 <fwp_trap>
    670e:	66 90                	xchg   %ax,%ax

0000000000006710 <fwp_owned_tape_release>:
    6710:	48 85 ff             	test   %rdi,%rdi
    6713:	0f 84 f7 00 00 00    	je     6810 <fwp_owned_tape_release+0x100>
    6719:	41 54                	push   %r12
    671b:	55                   	push   %rbp
    671c:	53                   	push   %rbx
    671d:	48 8b 07             	mov    (%rdi),%rax
    6720:	48 85 c0             	test   %rax,%rax
    6723:	74 08                	je     672d <fwp_owned_tape_release+0x1d>
    6725:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6729:	48 89 50 08          	mov    %rdx,0x8(%rax)
    672d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6731:	48 85 d2             	test   %rdx,%rdx
    6734:	74 03                	je     6739 <fwp_owned_tape_release+0x29>
    6736:	48 89 02             	mov    %rax,(%rdx)
    6739:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    673d:	48 89 fb             	mov    %rdi,%rbx
    6740:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6744:	48 85 c0             	test   %rax,%rax
    6747:	0f 84 89 00 00 00    	je     67d6 <fwp_owned_tape_release+0xc6>
    674d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6751:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6755:	7e 47                	jle    679e <fwp_owned_tape_release+0x8e>
    6757:	31 ed                	xor    %ebp,%ebp
    6759:	eb 0d                	jmp    6768 <fwp_owned_tape_release+0x58>
    675b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6760:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6764:	48 8b 40 68          	mov    0x68(%rax),%rax
    6768:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    676c:	49 89 ec             	mov    %rbp,%r12
    676f:	48 83 c5 01          	add    $0x1,%rbp
    6773:	49 c1 e4 04          	shl    $0x4,%r12
    6777:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    677b:	ff d0                	call   *%rax
    677d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6781:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6786:	48 8b 43 10          	mov    0x10(%rbx),%rax
    678a:	ff 50 68             	call   *0x68(%rax)
    678d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6791:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6795:	48 39 e8             	cmp    %rbp,%rax
    6798:	7f c6                	jg     6760 <fwp_owned_tape_release+0x50>
    679a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    679e:	31 ed                	xor    %ebp,%ebp
    67a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    67a5:	7e 28                	jle    67cf <fwp_owned_tape_release+0xbf>
    67a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67ae:	00 00 
    67b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    67b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    67b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    67bc:	74 07                	je     67c5 <fwp_owned_tape_release+0xb5>
    67be:	ff 52 68             	call   *0x68(%rdx)
    67c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    67c5:	48 83 c5 01          	add    $0x1,%rbp
    67c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    67cd:	7f e1                	jg     67b0 <fwp_owned_tape_release+0xa0>
    67cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    67d3:	ff 52 68             	call   *0x68(%rdx)
    67d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    67da:	e8 f1 fd ff ff       	call   65d0 <fwp_closure_drop>
    67df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    67e3:	e8 e8 fd ff ff       	call   65d0 <fwp_closure_drop>
    67e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    67ec:	e8 df fd ff ff       	call   65d0 <fwp_closure_drop>
    67f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    67f5:	e8 56 ed ff ff       	call   5550 <fwp_mem_free>
    67fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    67fe:	e8 4d ed ff ff       	call   5550 <fwp_mem_free>
    6803:	48 89 df             	mov    %rbx,%rdi
    6806:	5b                   	pop    %rbx
    6807:	5d                   	pop    %rbp
    6808:	41 5c                	pop    %r12
    680a:	e9 41 ed ff ff       	jmp    5550 <fwp_mem_free>
    680f:	90                   	nop
    6810:	c3                   	ret
    6811:	0f 1f 40 00          	nopl   0x0(%rax)
    6815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    681c:	00 00 00 00 

0000000000006820 <fwp_tape_finish>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	41 56                	push   %r14
    6826:	48 8d 3d 73 b8 01 00 	lea    0x1b873(%rip),%rdi        # 220a0 <fwp_tape_workspace>
    682d:	41 55                	push   %r13
    682f:	41 54                	push   %r12
    6831:	55                   	push   %rbp
    6832:	53                   	push   %rbx
    6833:	e8 38 d7 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6838:	48 83 3d a8 b8 01 00 	cmpq   $0x0,0x1b8a8(%rip)        # 220e8 <fwp_ntapes>
    683f:	00 
    6840:	48 c7 05 3d b8 01 00 	movq   $0x0,0x1b83d(%rip)        # 22088 <fwp_tape_cached_bytes>
    6847:	00 00 00 00 
    684b:	7e 68                	jle    68b5 <fwp_tape_finish+0x95>
    684d:	45 31 e4             	xor    %r12d,%r12d
    6850:	31 ed                	xor    %ebp,%ebp
    6852:	0f 1f 00             	nopl   (%rax)
    6855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    685c:	00 00 00 00 
    6860:	48 8b 1d 89 b8 01 00 	mov    0x1b889(%rip),%rbx        # 220f0 <fwp_tapes>
    6867:	48 83 c5 01          	add    $0x1,%rbp
    686b:	4c 01 e3             	add    %r12,%rbx
    686e:	49 83 c4 68          	add    $0x68,%r12
    6872:	48 89 df             	mov    %rbx,%rdi
    6875:	e8 86 d3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    687a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    687e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6882:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6886:	e8 35 cb ff ff       	call   33c0 <free@plt>
    688b:	4c 89 f7             	mov    %r14,%rdi
    688e:	e8 2d cb ff ff       	call   33c0 <free@plt>
    6893:	4c 89 ef             	mov    %r13,%rdi
    6896:	e8 25 cb ff ff       	call   33c0 <free@plt>
    689b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    689f:	e8 6c fe ff ff       	call   6710 <fwp_owned_tape_release>
    68a4:	48 39 2d 3d b8 01 00 	cmp    %rbp,0x1b83d(%rip)        # 220e8 <fwp_ntapes>
    68ab:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    68b2:	00 
    68b3:	7f ab                	jg     6860 <fwp_tape_finish+0x40>
    68b5:	48 8b 3d 34 b8 01 00 	mov    0x1b834(%rip),%rdi        # 220f0 <fwp_tapes>
    68bc:	e8 ff ca ff ff       	call   33c0 <free@plt>
    68c1:	5b                   	pop    %rbx
    68c2:	5d                   	pop    %rbp
    68c3:	48 c7 05 22 b8 01 00 	movq   $0x0,0x1b822(%rip)        # 220f0 <fwp_tapes>
    68ca:	00 00 00 00 
    68ce:	48 c7 05 07 b8 01 00 	movq   $0x0,0x1b807(%rip)        # 220e0 <fwp_tapes_cap>
    68d5:	00 00 00 00 
    68d9:	41 5c                	pop    %r12
    68db:	48 c7 05 02 b8 01 00 	movq   $0x0,0x1b802(%rip)        # 220e8 <fwp_ntapes>
    68e2:	00 00 00 00 
    68e6:	41 5d                	pop    %r13
    68e8:	48 c7 05 e5 b7 01 00 	movq   $0x0,0x1b7e5(%rip)        # 220d8 <fwp_tape_next_slot>
    68ef:	00 00 00 00 
    68f3:	41 5e                	pop    %r14
    68f5:	c3                   	ret
    68f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68fd:	00 00 00 

0000000000006900 <fwp_tape_scope_release>:
    6900:	f3 0f 1e fa          	endbr64
    6904:	41 55                	push   %r13
    6906:	41 54                	push   %r12
    6908:	55                   	push   %rbp
    6909:	53                   	push   %rbx
    690a:	48 83 ec 58          	sub    $0x58,%rsp
    690e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6915:	00 00 
    6917:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    691c:	48 63 07             	movslq (%rdi),%rax
    691f:	85 c0                	test   %eax,%eax
    6921:	0f 88 05 01 00 00    	js     6a2c <fwp_tape_scope_release+0x12c>
    6927:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    692e:	ec c4 4e 
    6931:	48 89 fb             	mov    %rdi,%rbx
    6934:	eb 3c                	jmp    6972 <fwp_tape_scope_release+0x72>
    6936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    693d:	00 00 00 
    6940:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6945:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6949:	e8 72 ca ff ff       	call   33c0 <free@plt>
    694e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6952:	e8 69 ca ff ff       	call   33c0 <free@plt>
    6957:	4c 89 ef             	mov    %r13,%rdi
    695a:	e8 61 ca ff ff       	call   33c0 <free@plt>
    695f:	4c 89 e7             	mov    %r12,%rdi
    6962:	e8 a9 fd ff ff       	call   6710 <fwp_owned_tape_release>
    6967:	48 63 03             	movslq (%rbx),%rax
    696a:	85 c0                	test   %eax,%eax
    696c:	0f 88 ba 00 00 00    	js     6a2c <fwp_tape_scope_release+0x12c>
    6972:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6976:	48 8b 35 73 b7 01 00 	mov    0x1b773(%rip),%rsi        # 220f0 <fwp_tapes>
    697d:	4c 01 c6             	add    %r8,%rsi
    6980:	48 89 f7             	mov    %rsi,%rdi
    6983:	e8 78 d2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6988:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    698d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6992:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6999:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    699d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    69a1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    69a8:	00 
    69a9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    69ae:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    69b2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    69b7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    69bb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    69c0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    69c7:	00 
    69c8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    69cf:	00 
    69d0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    69d7:	00 
    69d8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    69dd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    69e2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    69e6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    69ea:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    69ee:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    69f4:	77 18                	ja     6a0e <fwp_tape_scope_release+0x10e>
    69f6:	49 c1 f8 03          	sar    $0x3,%r8
    69fa:	4c 0f af c5          	imul   %rbp,%r8
    69fe:	4c 3b 05 d3 b6 01 00 	cmp    0x1b6d3(%rip),%r8        # 220d8 <fwp_tape_next_slot>
    6a05:	7d 07                	jge    6a0e <fwp_tape_scope_release+0x10e>
    6a07:	4c 89 05 ca b6 01 00 	mov    %r8,0x1b6ca(%rip)        # 220d8 <fwp_tape_next_slot>
    6a0e:	4d 85 e4             	test   %r12,%r12
    6a11:	0f 85 29 ff ff ff    	jne    6940 <fwp_tape_scope_release+0x40>
    6a17:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6a1c:	e8 0f e4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6a21:	48 63 03             	movslq (%rbx),%rax
    6a24:	85 c0                	test   %eax,%eax
    6a26:	0f 89 46 ff ff ff    	jns    6972 <fwp_tape_scope_release+0x72>
    6a2c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6a31:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a38:	00 00 
    6a3a:	75 0b                	jne    6a47 <fwp_tape_scope_release+0x147>
    6a3c:	48 83 c4 58          	add    $0x58,%rsp
    6a40:	5b                   	pop    %rbx
    6a41:	5d                   	pop    %rbp
    6a42:	41 5c                	pop    %r12
    6a44:	41 5d                	pop    %r13
    6a46:	c3                   	ret
    6a47:	e8 14 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006a50 <fwp_drop4>:
    6a50:	48 8b 0d e1 d0 01 00 	mov    0x1d0e1(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    6a57:	48 89 f8             	mov    %rdi,%rax
    6a5a:	48 2b 05 af d0 01 00 	sub    0x1d0af(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6a61:	48 c1 e1 10          	shl    $0x10,%rcx
    6a65:	48 39 c8             	cmp    %rcx,%rax
    6a68:	0f 83 42 01 00 00    	jae    6bb0 <fwp_drop4+0x160>
    6a6e:	48 83 ec 18          	sub    $0x18,%rsp
    6a72:	48 89 fa             	mov    %rdi,%rdx
    6a75:	4c 8d 05 e4 bc 01 00 	lea    0x1bce4(%rip),%r8        # 22760 <fwp_heap>
    6a7c:	48 89 c1             	mov    %rax,%rcx
    6a7f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6a86:	48 c1 e9 10          	shr    $0x10,%rcx
    6a8a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6a8e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6a92:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6a96:	48 85 c9             	test   %rcx,%rcx
    6a99:	74 40                	je     6adb <fwp_drop4+0x8b>
    6a9b:	0f b6 3e             	movzbl (%rsi),%edi
    6a9e:	40 80 ff 02          	cmp    $0x2,%dil
    6aa2:	74 3c                	je     6ae0 <fwp_drop4+0x90>
    6aa4:	40 80 ff 01          	cmp    $0x1,%dil
    6aa8:	75 31                	jne    6adb <fwp_drop4+0x8b>
    6aaa:	8b 7e 18             	mov    0x18(%rsi),%edi
    6aad:	0f b7 c0             	movzwl %ax,%eax
    6ab0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ab3:	48 0f af c7          	imul   %rdi,%rax
    6ab7:	48 c1 e8 20          	shr    $0x20,%rax
    6abb:	48 39 f0             	cmp    %rsi,%rax
    6abe:	73 1b                	jae    6adb <fwp_drop4+0x8b>
    6ac0:	48 01 c1             	add    %rax,%rcx
    6ac3:	0f b6 01             	movzbl (%rcx),%eax
    6ac6:	84 c0                	test   %al,%al
    6ac8:	74 11                	je     6adb <fwp_drop4+0x8b>
    6aca:	3c 01                	cmp    $0x1,%al
    6acc:	74 22                	je     6af0 <fwp_drop4+0xa0>
    6ace:	3c ff                	cmp    $0xff,%al
    6ad0:	0f 84 0a 01 00 00    	je     6be0 <fwp_drop4+0x190>
    6ad6:	83 e8 01             	sub    $0x1,%eax
    6ad9:	88 01                	mov    %al,(%rcx)
    6adb:	48 83 c4 18          	add    $0x18,%rsp
    6adf:	c3                   	ret
    6ae0:	66 85 c0             	test   %ax,%ax
    6ae3:	74 de                	je     6ac3 <fwp_drop4+0x73>
    6ae5:	48 83 c4 18          	add    $0x18,%rsp
    6ae9:	c3                   	ret
    6aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6af4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6afb:	48 89 f8             	mov    %rdi,%rax
    6afe:	48 c1 e1 10          	shl    $0x10,%rcx
    6b02:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b09:	48 39 c8             	cmp    %rcx,%rax
    6b0c:	73 62                	jae    6b70 <fwp_drop4+0x120>
    6b0e:	48 89 c1             	mov    %rax,%rcx
    6b11:	48 c1 e9 10          	shr    $0x10,%rcx
    6b15:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6b19:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6b1d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6b21:	48 85 c9             	test   %rcx,%rcx
    6b24:	74 4a                	je     6b70 <fwp_drop4+0x120>
    6b26:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6b2a:	41 80 f9 02          	cmp    $0x2,%r9b
    6b2e:	0f 84 9c 00 00 00    	je     6bd0 <fwp_drop4+0x180>
    6b34:	41 80 f9 01          	cmp    $0x1,%r9b
    6b38:	75 36                	jne    6b70 <fwp_drop4+0x120>
    6b3a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6b3e:	0f b7 c0             	movzwl %ax,%eax
    6b41:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6b44:	49 0f af c1          	imul   %r9,%rax
    6b48:	48 c1 e8 20          	shr    $0x20,%rax
    6b4c:	48 39 f0             	cmp    %rsi,%rax
    6b4f:	73 1f                	jae    6b70 <fwp_drop4+0x120>
    6b51:	48 01 c1             	add    %rax,%rcx
    6b54:	0f b6 01             	movzbl (%rcx),%eax
    6b57:	84 c0                	test   %al,%al
    6b59:	74 15                	je     6b70 <fwp_drop4+0x120>
    6b5b:	3c 01                	cmp    $0x1,%al
    6b5d:	74 59                	je     6bb8 <fwp_drop4+0x168>
    6b5f:	3c ff                	cmp    $0xff,%al
    6b61:	0f 84 ff 00 00 00    	je     6c66 <fwp_drop4+0x216>
    6b67:	83 e8 01             	sub    $0x1,%eax
    6b6a:	88 01                	mov    %al,(%rcx)
    6b6c:	0f 1f 40 00          	nopl   0x0(%rax)
    6b70:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6b74:	48 89 d7             	mov    %rdx,%rdi
    6b77:	48 89 0c 24          	mov    %rcx,(%rsp)
    6b7b:	e8 40 f7 ff ff       	call   62c0 <fwp_rc_free_obj>
    6b80:	4c 8d 05 d9 bb 01 00 	lea    0x1bbd9(%rip),%r8        # 22760 <fwp_heap>
    6b87:	48 8b 04 24          	mov    (%rsp),%rax
    6b8b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b92:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b99:	48 c1 e2 10          	shl    $0x10,%rdx
    6b9d:	48 39 d0             	cmp    %rdx,%rax
    6ba0:	0f 83 35 ff ff ff    	jae    6adb <fwp_drop4+0x8b>
    6ba6:	48 8b 14 24          	mov    (%rsp),%rdx
    6baa:	e9 cd fe ff ff       	jmp    6a7c <fwp_drop4+0x2c>
    6baf:	90                   	nop
    6bb0:	c3                   	ret
    6bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bb8:	48 89 14 24          	mov    %rdx,(%rsp)
    6bbc:	e8 ff f6 ff ff       	call   62c0 <fwp_rc_free_obj>
    6bc1:	48 8b 14 24          	mov    (%rsp),%rdx
    6bc5:	eb a9                	jmp    6b70 <fwp_drop4+0x120>
    6bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bce:	00 00 
    6bd0:	66 85 c0             	test   %ax,%ax
    6bd3:	75 9b                	jne    6b70 <fwp_drop4+0x120>
    6bd5:	e9 7a ff ff ff       	jmp    6b54 <fwp_drop4+0x104>
    6bda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6be0:	48 89 c8             	mov    %rcx,%rax
    6be3:	48 c1 e8 11          	shr    $0x11,%rax
    6be7:	48 31 c8             	xor    %rcx,%rax
    6bea:	48 89 c2             	mov    %rax,%rdx
    6bed:	48 c1 ea 09          	shr    $0x9,%rdx
    6bf1:	48 31 d0             	xor    %rdx,%rax
    6bf4:	0f b6 d0             	movzbl %al,%edx
    6bf7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6bfe:	00 
    6bff:	48 85 c0             	test   %rax,%rax
    6c02:	75 29                	jne    6c2d <fwp_drop4+0x1dd>
    6c04:	e9 e3 00 00 00       	jmp    6cec <fwp_drop4+0x29c>
    6c09:	90                   	nop
    6c0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c11:	00 00 00 00 
    6c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c1c:	00 00 00 00 
    6c20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6c24:	48 85 c0             	test   %rax,%rax
    6c27:	0f 84 bf 00 00 00    	je     6cec <fwp_drop4+0x29c>
    6c2d:	48 89 c2             	mov    %rax,%rdx
    6c30:	48 39 08             	cmp    %rcx,(%rax)
    6c33:	75 eb                	jne    6c20 <fwp_drop4+0x1d0>
    6c35:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6c39:	48 83 ea 01          	sub    $0x1,%rdx
    6c3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6c48:	0f 85 8d fe ff ff    	jne    6adb <fwp_drop4+0x8b>
    6c4e:	48 89 cf             	mov    %rcx,%rdi
    6c51:	48 89 0c 24          	mov    %rcx,(%rsp)
    6c55:	e8 b6 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6c5a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6c5e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6c61:	e9 75 fe ff ff       	jmp    6adb <fwp_drop4+0x8b>
    6c66:	48 89 ce             	mov    %rcx,%rsi
    6c69:	48 c1 ee 11          	shr    $0x11,%rsi
    6c6d:	48 31 ce             	xor    %rcx,%rsi
    6c70:	48 89 f0             	mov    %rsi,%rax
    6c73:	48 c1 e8 09          	shr    $0x9,%rax
    6c77:	48 31 c6             	xor    %rax,%rsi
    6c7a:	40 0f b6 f6          	movzbl %sil,%esi
    6c7e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6c85:	00 
    6c86:	48 85 c0             	test   %rax,%rax
    6c89:	75 1e                	jne    6ca9 <fwp_drop4+0x259>
    6c8b:	eb 5f                	jmp    6cec <fwp_drop4+0x29c>
    6c8d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c94:	00 
    6c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c9c:	00 00 00 00 
    6ca0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6ca4:	48 85 c0             	test   %rax,%rax
    6ca7:	74 43                	je     6cec <fwp_drop4+0x29c>
    6ca9:	48 89 c6             	mov    %rax,%rsi
    6cac:	48 39 08             	cmp    %rcx,(%rax)
    6caf:	75 ef                	jne    6ca0 <fwp_drop4+0x250>
    6cb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6cb5:	48 83 ee 01          	sub    $0x1,%rsi
    6cb9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6cbd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6cc4:	0f 85 a6 fe ff ff    	jne    6b70 <fwp_drop4+0x120>
    6cca:	48 89 cf             	mov    %rcx,%rdi
    6ccd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cd2:	48 89 0c 24          	mov    %rcx,(%rsp)
    6cd6:	e8 35 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6cdb:	48 8b 0c 24          	mov    (%rsp),%rcx
    6cdf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ce4:	c6 01 fe             	movb   $0xfe,(%rcx)
    6ce7:	e9 84 fe ff ff       	jmp    6b70 <fwp_drop4+0x120>
    6cec:	48 8d 3d ad 7a 00 00 	lea    0x7aad(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6cf3:	e8 a8 d4 ff ff       	call   41a0 <fwp_trap>
    6cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cff:	00 

0000000000006d00 <fwp_arg_drop37>:
    6d00:	f3 0f 1e fa          	endbr64
    6d04:	85 f6                	test   %esi,%esi
    6d06:	75 04                	jne    6d0c <fwp_arg_drop37+0xc>
    6d08:	85 d2                	test   %edx,%edx
    6d0a:	75 04                	jne    6d10 <fwp_arg_drop37+0x10>
    6d0c:	c3                   	ret
    6d0d:	0f 1f 00             	nopl   (%rax)
    6d10:	48 8b 3f             	mov    (%rdi),%rdi
    6d13:	e9 38 fd ff ff       	jmp    6a50 <fwp_drop4>
    6d18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d1f:	00 

0000000000006d20 <fwp_task_dispose>:
    6d20:	53                   	push   %rbx
    6d21:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6d25:	0f 84 1b ca ff ff    	je     3746 <fwp_task_dispose.cold>
    6d2b:	48 89 fb             	mov    %rdi,%rbx
    6d2e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6d33:	0f 85 0d ca ff ff    	jne    3746 <fwp_task_dispose.cold>
    6d39:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6d3d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6d44:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6d4b:	00 
    6d4c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6d50:	48 85 ff             	test   %rdi,%rdi
    6d53:	74 07                	je     6d5c <fwp_task_dispose+0x3c>
    6d55:	48 85 c0             	test   %rax,%rax
    6d58:	74 02                	je     6d5c <fwp_task_dispose+0x3c>
    6d5a:	ff d0                	call   *%rax
    6d5c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6d63:	e8 e8 e7 ff ff       	call   5550 <fwp_mem_free>
    6d68:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6d6f:	00 00 00 00 
    6d73:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6d77:	74 6f                	je     6de8 <fwp_task_dispose+0xc8>
    6d79:	48 8b 15 b8 cd 01 00 	mov    0x1cdb8(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6d80:	48 89 d8             	mov    %rbx,%rax
    6d83:	48 2b 05 86 cd 01 00 	sub    0x1cd86(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6d8a:	48 c1 e2 10          	shl    $0x10,%rdx
    6d8e:	48 39 d0             	cmp    %rdx,%rax
    6d91:	73 4c                	jae    6ddf <fwp_task_dispose+0xbf>
    6d93:	48 89 c2             	mov    %rax,%rdx
    6d96:	48 c1 ea 10          	shr    $0x10,%rdx
    6d9a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d9e:	48 8b 15 b3 cd 01 00 	mov    0x1cdb3(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    6da5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6da9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6dad:	48 85 c9             	test   %rcx,%rcx
    6db0:	74 2d                	je     6ddf <fwp_task_dispose+0xbf>
    6db2:	0f b6 32             	movzbl (%rdx),%esi
    6db5:	40 80 fe 02          	cmp    $0x2,%sil
    6db9:	74 3d                	je     6df8 <fwp_task_dispose+0xd8>
    6dbb:	40 80 fe 01          	cmp    $0x1,%sil
    6dbf:	75 1e                	jne    6ddf <fwp_task_dispose+0xbf>
    6dc1:	8b 72 18             	mov    0x18(%rdx),%esi
    6dc4:	0f b7 c0             	movzwl %ax,%eax
    6dc7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6dca:	48 0f af c6          	imul   %rsi,%rax
    6dce:	48 c1 e8 20          	shr    $0x20,%rax
    6dd2:	48 39 d0             	cmp    %rdx,%rax
    6dd5:	73 08                	jae    6ddf <fwp_task_dispose+0xbf>
    6dd7:	48 01 c1             	add    %rax,%rcx
    6dda:	80 39 01             	cmpb   $0x1,(%rcx)
    6ddd:	74 09                	je     6de8 <fwp_task_dispose+0xc8>
    6ddf:	5b                   	pop    %rbx
    6de0:	c3                   	ret
    6de1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6de8:	48 89 df             	mov    %rbx,%rdi
    6deb:	5b                   	pop    %rbx
    6dec:	e9 5f e7 ff ff       	jmp    5550 <fwp_mem_free>
    6df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6df8:	66 85 c0             	test   %ax,%ax
    6dfb:	74 dd                	je     6dda <fwp_task_dispose+0xba>
    6dfd:	5b                   	pop    %rbx
    6dfe:	c3                   	ret
    6dff:	90                   	nop

0000000000006e00 <fwp_free_zombie>:
    6e00:	48 8b 15 29 b9 01 00 	mov    0x1b929(%rip),%rdx        # 22730 <fwp_zombie>
    6e07:	48 85 d2             	test   %rdx,%rdx
    6e0a:	0f 84 98 00 00 00    	je     6ea8 <fwp_free_zombie+0xa8>
    6e10:	48 3b 15 29 b9 01 00 	cmp    0x1b929(%rip),%rdx        # 22740 <fwp_cur>
    6e17:	0f 84 8b 00 00 00    	je     6ea8 <fwp_free_zombie+0xa8>
    6e1d:	48 83 ec 18          	sub    $0x18,%rsp
    6e21:	48 63 05 e4 b2 01 00 	movslq 0x1b2e4(%rip),%rax        # 2210c <fwp_stack_pool_n>
    6e28:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6e2c:	83 f8 3f             	cmp    $0x3f,%eax
    6e2f:	7f 7f                	jg     6eb0 <fwp_free_zombie+0xb0>
    6e31:	8d 48 01             	lea    0x1(%rax),%ecx
    6e34:	89 0d d2 b2 01 00    	mov    %ecx,0x1b2d2(%rip)        # 2210c <fwp_stack_pool_n>
    6e3a:	48 8d 0d df b2 01 00 	lea    0x1b2df(%rip),%rcx        # 22120 <fwp_stack_pool>
    6e41:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6e45:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6e4c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e50:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6e57:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6e5b:	48 85 c9             	test   %rcx,%rcx
    6e5e:	0f 84 fc 00 00 00    	je     6f60 <fwp_free_zombie+0x160>
    6e64:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6e6b:	48 85 c0             	test   %rax,%rax
    6e6e:	74 07                	je     6e77 <fwp_free_zombie+0x77>
    6e70:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6e77:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6e7a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e7e:	48 c7 05 a7 b8 01 00 	movq   $0x0,0x1b8a7(%rip)        # 22730 <fwp_zombie>
    6e85:	00 00 00 00 
    6e89:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6e90:	85 c0                	test   %eax,%eax
    6e92:	74 34                	je     6ec8 <fwp_free_zombie+0xc8>
    6e94:	83 f8 01             	cmp    $0x1,%eax
    6e97:	0f 84 b3 00 00 00    	je     6f50 <fwp_free_zombie+0x150>
    6e9d:	48 83 c4 18          	add    $0x18,%rsp
    6ea1:	c3                   	ret
    6ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ea8:	c3                   	ret
    6ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6eb0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6eb4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6eb9:	e8 22 c7 ff ff       	call   35e0 <munmap@plt>
    6ebe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ec3:	eb 80                	jmp    6e45 <fwp_free_zombie+0x45>
    6ec5:	0f 1f 00             	nopl   (%rax)
    6ec8:	48 8b 0d 69 cc 01 00 	mov    0x1cc69(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    6ecf:	48 89 d0             	mov    %rdx,%rax
    6ed2:	48 2b 05 37 cc 01 00 	sub    0x1cc37(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6ed9:	48 c1 e1 10          	shl    $0x10,%rcx
    6edd:	48 39 c8             	cmp    %rcx,%rax
    6ee0:	73 bb                	jae    6e9d <fwp_free_zombie+0x9d>
    6ee2:	48 89 c1             	mov    %rax,%rcx
    6ee5:	48 c1 e9 10          	shr    $0x10,%rcx
    6ee9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6eed:	48 8b 0d 64 cc 01 00 	mov    0x1cc64(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    6ef4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6ef8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6efc:	48 85 c9             	test   %rcx,%rcx
    6eff:	74 9c                	je     6e9d <fwp_free_zombie+0x9d>
    6f01:	0f b6 3e             	movzbl (%rsi),%edi
    6f04:	40 80 ff 02          	cmp    $0x2,%dil
    6f08:	74 66                	je     6f70 <fwp_free_zombie+0x170>
    6f0a:	40 80 ff 01          	cmp    $0x1,%dil
    6f0e:	75 8d                	jne    6e9d <fwp_free_zombie+0x9d>
    6f10:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f13:	0f b7 c0             	movzwl %ax,%eax
    6f16:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f19:	48 0f af c7          	imul   %rdi,%rax
    6f1d:	48 c1 e8 20          	shr    $0x20,%rax
    6f21:	48 39 f0             	cmp    %rsi,%rax
    6f24:	0f 83 73 ff ff ff    	jae    6e9d <fwp_free_zombie+0x9d>
    6f2a:	48 01 c1             	add    %rax,%rcx
    6f2d:	0f b6 01             	movzbl (%rcx),%eax
    6f30:	84 c0                	test   %al,%al
    6f32:	0f 84 65 ff ff ff    	je     6e9d <fwp_free_zombie+0x9d>
    6f38:	3c 01                	cmp    $0x1,%al
    6f3a:	74 14                	je     6f50 <fwp_free_zombie+0x150>
    6f3c:	3c ff                	cmp    $0xff,%al
    6f3e:	74 3b                	je     6f7b <fwp_free_zombie+0x17b>
    6f40:	83 e8 01             	sub    $0x1,%eax
    6f43:	88 01                	mov    %al,(%rcx)
    6f45:	e9 53 ff ff ff       	jmp    6e9d <fwp_free_zombie+0x9d>
    6f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f50:	48 89 d7             	mov    %rdx,%rdi
    6f53:	48 83 c4 18          	add    $0x18,%rsp
    6f57:	e9 c4 fd ff ff       	jmp    6d20 <fwp_task_dispose>
    6f5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f60:	48 89 05 a1 b7 01 00 	mov    %rax,0x1b7a1(%rip)        # 22708 <fwp_tasks_active>
    6f67:	e9 ff fe ff ff       	jmp    6e6b <fwp_free_zombie+0x6b>
    6f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f70:	66 85 c0             	test   %ax,%ax
    6f73:	0f 85 24 ff ff ff    	jne    6e9d <fwp_free_zombie+0x9d>
    6f79:	eb b2                	jmp    6f2d <fwp_free_zombie+0x12d>
    6f7b:	48 89 ca             	mov    %rcx,%rdx
    6f7e:	48 8d 35 db b7 01 00 	lea    0x1b7db(%rip),%rsi        # 22760 <fwp_heap>
    6f85:	48 c1 ea 11          	shr    $0x11,%rdx
    6f89:	48 31 ca             	xor    %rcx,%rdx
    6f8c:	48 89 d0             	mov    %rdx,%rax
    6f8f:	48 c1 e8 09          	shr    $0x9,%rax
    6f93:	48 31 c2             	xor    %rax,%rdx
    6f96:	0f b6 d2             	movzbl %dl,%edx
    6f99:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    6fa0:	00 
    6fa1:	48 85 c0             	test   %rax,%rax
    6fa4:	75 23                	jne    6fc9 <fwp_free_zombie+0x1c9>
    6fa6:	eb 5c                	jmp    7004 <fwp_free_zombie+0x204>
    6fa8:	66 90                	xchg   %ax,%ax
    6faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fb1:	00 00 00 00 
    6fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fbc:	00 00 00 00 
    6fc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6fc4:	48 85 c0             	test   %rax,%rax
    6fc7:	74 3b                	je     7004 <fwp_free_zombie+0x204>
    6fc9:	48 89 c2             	mov    %rax,%rdx
    6fcc:	48 39 08             	cmp    %rcx,(%rax)
    6fcf:	75 ef                	jne    6fc0 <fwp_free_zombie+0x1c0>
    6fd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6fd5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    6fd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fdd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6fe4:	0f 85 b3 fe ff ff    	jne    6e9d <fwp_free_zombie+0x9d>
    6fea:	48 89 cf             	mov    %rcx,%rdi
    6fed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ff2:	e8 19 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6ff7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6ffc:	c6 01 fe             	movb   $0xfe,(%rcx)
    6fff:	e9 99 fe ff ff       	jmp    6e9d <fwp_free_zombie+0x9d>
    7004:	48 8d 3d 95 77 00 00 	lea    0x7795(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    700b:	e8 90 d1 ff ff       	call   41a0 <fwp_trap>

0000000000007010 <fwp_block>:
    7010:	48 83 ec 08          	sub    $0x8,%rsp
    7014:	48 8b 05 0d b7 01 00 	mov    0x1b70d(%rip),%rax        # 22728 <fwp_ready_head>
    701b:	48 85 c0             	test   %rax,%rax
    701e:	0f 84 1c 01 00 00    	je     7140 <fwp_block+0x130>
    7024:	90                   	nop
    7025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    702c:	00 00 00 00 
    7030:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7037:	48 89 15 ea b6 01 00 	mov    %rdx,0x1b6ea(%rip)        # 22728 <fwp_ready_head>
    703e:	48 85 d2             	test   %rdx,%rdx
    7041:	0f 84 19 01 00 00    	je     7160 <fwp_block+0x150>
    7047:	48 8b 15 f2 b6 01 00 	mov    0x1b6f2(%rip),%rdx        # 22740 <fwp_cur>
    704e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7052:	48 39 c2             	cmp    %rax,%rdx
    7055:	0f 84 d5 00 00 00    	je     7130 <fwp_block+0x120>
    705b:	48 8b 0d 66 d3 01 00 	mov    0x1d366(%rip),%rcx        # 243c8 <fwp_state_owners>
    7062:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7066:	48 89 05 d3 b6 01 00 	mov    %rax,0x1b6d3(%rip)        # 22740 <fwp_cur>
    706d:	f3 0f 7e 05 7b d3 01 	movq   0x1d37b(%rip),%xmm0        # 243f0 <fwp_foreign_callbacks>
    7074:	00 
    7075:	0f 16 05 64 d3 01 00 	movhps 0x1d364(%rip),%xmm0        # 243e0 <fwp_state>
    707c:	f3 0f 7e 0d 64 d3 01 	movq   0x1d364(%rip),%xmm1        # 243e8 <fwp_handlers>
    7083:	00 
    7084:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    708b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7092:	0f 16 0d 5f d3 01 00 	movhps 0x1d35f(%rip),%xmm1        # 243f8 <fwp_cleanups>
    7099:	f3 0f 7e 05 37 d3 01 	movq   0x1d337(%rip),%xmm0        # 243d8 <fwp_state_len>
    70a0:	00 
    70a1:	0f 16 05 28 d3 01 00 	movhps 0x1d328(%rip),%xmm0        # 243d0 <fwp_state_cap>
    70a8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    70af:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    70b6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    70ba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    70c1:	48 89 0d 20 d3 01 00 	mov    %rcx,0x1d320(%rip)        # 243e8 <fwp_handlers>
    70c8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    70cf:	48 89 0d 22 d3 01 00 	mov    %rcx,0x1d322(%rip)        # 243f8 <fwp_cleanups>
    70d6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    70dd:	48 89 0d 0c d3 01 00 	mov    %rcx,0x1d30c(%rip)        # 243f0 <fwp_foreign_callbacks>
    70e4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    70eb:	48 89 0d ee d2 01 00 	mov    %rcx,0x1d2ee(%rip)        # 243e0 <fwp_state>
    70f2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    70f9:	48 89 0d d8 d2 01 00 	mov    %rcx,0x1d2d8(%rip)        # 243d8 <fwp_state_len>
    7100:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7107:	48 89 0d c2 d2 01 00 	mov    %rcx,0x1d2c2(%rip)        # 243d0 <fwp_state_cap>
    710e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7115:	48 89 0d ac d2 01 00 	mov    %rcx,0x1d2ac(%rip)        # 243c8 <fwp_state_owners>
    711c:	e8 6f c3 ff ff       	call   3490 <swapcontext@plt>
    7121:	f3 0f 1e fa          	endbr64
    7125:	e8 d6 fc ff ff       	call   6e00 <fwp_free_zombie>
    712a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7130:	8b 05 d2 af 01 00    	mov    0x1afd2(%rip),%eax        # 22108 <fwp_slice>
    7136:	85 c0                	test   %eax,%eax
    7138:	74 36                	je     7170 <fwp_block+0x160>
    713a:	48 83 c4 08          	add    $0x8,%rsp
    713e:	c3                   	ret
    713f:	90                   	nop
    7140:	e8 1b de ff ff       	call   4f60 <fwp_poll_events>
    7145:	48 8b 05 dc b5 01 00 	mov    0x1b5dc(%rip),%rax        # 22728 <fwp_ready_head>
    714c:	48 85 c0             	test   %rax,%rax
    714f:	0f 85 db fe ff ff    	jne    7030 <fwp_block+0x20>
    7155:	eb e9                	jmp    7140 <fwp_block+0x130>
    7157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    715e:	00 00 
    7160:	48 c7 05 b5 b5 01 00 	movq   $0x0,0x1b5b5(%rip)        # 22720 <fwp_ready_tail>
    7167:	00 00 00 00 
    716b:	e9 d7 fe ff ff       	jmp    7047 <fwp_block+0x37>
    7170:	48 8d 3d aa 6f 00 00 	lea    0x6faa(%rip),%rdi        # e121 <_IO_stdin_used+0x121>
    7177:	e8 24 c2 ff ff       	call   33a0 <getenv@plt>
    717c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7181:	48 85 c0             	test   %rax,%rax
    7184:	74 05                	je     718b <fwp_block+0x17b>
    7186:	80 38 00             	cmpb   $0x0,(%rax)
    7189:	75 0b                	jne    7196 <fwp_block+0x186>
    718b:	89 15 77 af 01 00    	mov    %edx,0x1af77(%rip)        # 22108 <fwp_slice>
    7191:	48 83 c4 08          	add    $0x8,%rsp
    7195:	c3                   	ret
    7196:	ba 0a 00 00 00       	mov    $0xa,%edx
    719b:	31 f6                	xor    %esi,%esi
    719d:	48 89 c7             	mov    %rax,%rdi
    71a0:	e8 ab c3 ff ff       	call   3550 <strtoll@plt>
    71a5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    71a9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    71b0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    71b5:	0f 46 d0             	cmovbe %eax,%edx
    71b8:	eb d1                	jmp    718b <fwp_block+0x17b>
    71ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000071c0 <fwp_caps173>:
    71c0:	f3 0f 1e fa          	endbr64
    71c4:	85 f6                	test   %esi,%esi
    71c6:	74 08                	je     71d0 <fwp_caps173+0x10>
    71c8:	c3                   	ret
    71c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71d0:	48 8b 15 61 c9 01 00 	mov    0x1c961(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    71d7:	48 89 f8             	mov    %rdi,%rax
    71da:	48 2b 05 2f c9 01 00 	sub    0x1c92f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    71e1:	48 c1 e2 10          	shl    $0x10,%rdx
    71e5:	48 39 d0             	cmp    %rdx,%rax
    71e8:	73 de                	jae    71c8 <fwp_caps173+0x8>
    71ea:	48 89 c2             	mov    %rax,%rdx
    71ed:	48 c1 ea 10          	shr    $0x10,%rdx
    71f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71f5:	48 8b 15 5c c9 01 00 	mov    0x1c95c(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    71fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7200:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7204:	48 85 c9             	test   %rcx,%rcx
    7207:	74 bf                	je     71c8 <fwp_caps173+0x8>
    7209:	0f b6 32             	movzbl (%rdx),%esi
    720c:	40 80 fe 02          	cmp    $0x2,%sil
    7210:	74 2e                	je     7240 <fwp_caps173+0x80>
    7212:	40 80 fe 01          	cmp    $0x1,%sil
    7216:	75 b0                	jne    71c8 <fwp_caps173+0x8>
    7218:	8b 72 18             	mov    0x18(%rdx),%esi
    721b:	0f b7 c0             	movzwl %ax,%eax
    721e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7221:	48 0f af c6          	imul   %rsi,%rax
    7225:	48 c1 e8 20          	shr    $0x20,%rax
    7229:	48 39 d0             	cmp    %rdx,%rax
    722c:	73 9a                	jae    71c8 <fwp_caps173+0x8>
    722e:	48 01 c1             	add    %rax,%rcx
    7231:	80 39 01             	cmpb   $0x1,(%rcx)
    7234:	75 92                	jne    71c8 <fwp_caps173+0x8>
    7236:	e9 15 e3 ff ff       	jmp    5550 <fwp_mem_free>
    723b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7240:	66 85 c0             	test   %ax,%ax
    7243:	74 ec                	je     7231 <fwp_caps173+0x71>
    7245:	c3                   	ret
    7246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    724d:	00 00 00 

0000000000007250 <fwp_args37>:
    7250:	f3 0f 1e fa          	endbr64
    7254:	85 d2                	test   %edx,%edx
    7256:	74 04                	je     725c <fwp_args37+0xc>
    7258:	85 f6                	test   %esi,%esi
    725a:	74 04                	je     7260 <fwp_args37+0x10>
    725c:	c3                   	ret
    725d:	0f 1f 00             	nopl   (%rax)
    7260:	48 8b 15 d1 c8 01 00 	mov    0x1c8d1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7267:	48 8b 07             	mov    (%rdi),%rax
    726a:	48 2b 05 9f c8 01 00 	sub    0x1c89f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7271:	48 c1 e2 10          	shl    $0x10,%rdx
    7275:	48 39 d0             	cmp    %rdx,%rax
    7278:	73 e2                	jae    725c <fwp_args37+0xc>
    727a:	48 89 c2             	mov    %rax,%rdx
    727d:	48 c1 ea 10          	shr    $0x10,%rdx
    7281:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7285:	48 8b 15 cc c8 01 00 	mov    0x1c8cc(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    728c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7290:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7294:	48 85 ff             	test   %rdi,%rdi
    7297:	74 c3                	je     725c <fwp_args37+0xc>
    7299:	0f b6 0a             	movzbl (%rdx),%ecx
    729c:	80 f9 02             	cmp    $0x2,%cl
    729f:	74 2f                	je     72d0 <fwp_args37+0x80>
    72a1:	80 f9 01             	cmp    $0x1,%cl
    72a4:	75 b6                	jne    725c <fwp_args37+0xc>
    72a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    72a9:	0f b7 c0             	movzwl %ax,%eax
    72ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72af:	48 0f af c1          	imul   %rcx,%rax
    72b3:	48 c1 e8 20          	shr    $0x20,%rax
    72b7:	48 39 d0             	cmp    %rdx,%rax
    72ba:	73 a0                	jae    725c <fwp_args37+0xc>
    72bc:	48 01 c7             	add    %rax,%rdi
    72bf:	0f b6 07             	movzbl (%rdi),%eax
    72c2:	84 c0                	test   %al,%al
    72c4:	74 96                	je     725c <fwp_args37+0xc>
    72c6:	3c fd                	cmp    $0xfd,%al
    72c8:	77 0c                	ja     72d6 <fwp_args37+0x86>
    72ca:	83 c0 01             	add    $0x1,%eax
    72cd:	88 07                	mov    %al,(%rdi)
    72cf:	c3                   	ret
    72d0:	66 85 c0             	test   %ax,%ax
    72d3:	74 ea                	je     72bf <fwp_args37+0x6f>
    72d5:	c3                   	ret
    72d6:	e9 15 df ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    72db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000072e0 <fwp_caps37>:
    72e0:	f3 0f 1e fa          	endbr64
    72e4:	48 83 ec 18          	sub    $0x18,%rsp
    72e8:	8b 57 04             	mov    0x4(%rdi),%edx
    72eb:	48 89 f8             	mov    %rdi,%rax
    72ee:	85 d2                	test   %edx,%edx
    72f0:	0f 84 9a 00 00 00    	je     7390 <fwp_caps37+0xb0>
    72f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    72fa:	85 f6                	test   %esi,%esi
    72fc:	0f 85 9e 00 00 00    	jne    73a0 <fwp_caps37+0xc0>
    7302:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7307:	e8 44 f7 ff ff       	call   6a50 <fwp_drop4>
    730c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7311:	48 8b 0d 20 c8 01 00 	mov    0x1c820(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    7318:	48 89 c2             	mov    %rax,%rdx
    731b:	48 2b 15 ee c7 01 00 	sub    0x1c7ee(%rip),%rdx        # 23b10 <fwp_heap+0x13b0>
    7322:	48 c1 e1 10          	shl    $0x10,%rcx
    7326:	48 39 ca             	cmp    %rcx,%rdx
    7329:	73 6d                	jae    7398 <fwp_caps37+0xb8>
    732b:	48 89 d1             	mov    %rdx,%rcx
    732e:	48 c1 e9 10          	shr    $0x10,%rcx
    7332:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7336:	48 8b 0d 1b c8 01 00 	mov    0x1c81b(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    733d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7341:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7345:	48 85 f6             	test   %rsi,%rsi
    7348:	74 4e                	je     7398 <fwp_caps37+0xb8>
    734a:	0f b6 39             	movzbl (%rcx),%edi
    734d:	40 80 ff 02          	cmp    $0x2,%dil
    7351:	0f 84 b9 00 00 00    	je     7410 <fwp_caps37+0x130>
    7357:	40 80 ff 01          	cmp    $0x1,%dil
    735b:	75 3b                	jne    7398 <fwp_caps37+0xb8>
    735d:	8b 79 18             	mov    0x18(%rcx),%edi
    7360:	0f b7 d2             	movzwl %dx,%edx
    7363:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7366:	48 0f af d7          	imul   %rdi,%rdx
    736a:	48 c1 ea 20          	shr    $0x20,%rdx
    736e:	48 39 ca             	cmp    %rcx,%rdx
    7371:	73 25                	jae    7398 <fwp_caps37+0xb8>
    7373:	48 01 d6             	add    %rdx,%rsi
    7376:	80 3e 01             	cmpb   $0x1,(%rsi)
    7379:	75 1d                	jne    7398 <fwp_caps37+0xb8>
    737b:	48 89 c7             	mov    %rax,%rdi
    737e:	48 83 c4 18          	add    $0x18,%rsp
    7382:	e9 c9 e1 ff ff       	jmp    5550 <fwp_mem_free>
    7387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    738e:	00 00 
    7390:	85 f6                	test   %esi,%esi
    7392:	0f 84 79 ff ff ff    	je     7311 <fwp_caps37+0x31>
    7398:	48 83 c4 18          	add    $0x18,%rsp
    739c:	c3                   	ret
    739d:	0f 1f 00             	nopl   (%rax)
    73a0:	48 8b 05 91 c7 01 00 	mov    0x1c791(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    73a7:	48 2b 3d 62 c7 01 00 	sub    0x1c762(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    73ae:	48 c1 e0 10          	shl    $0x10,%rax
    73b2:	48 39 c7             	cmp    %rax,%rdi
    73b5:	73 e1                	jae    7398 <fwp_caps37+0xb8>
    73b7:	48 89 f8             	mov    %rdi,%rax
    73ba:	48 c1 e8 10          	shr    $0x10,%rax
    73be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    73c2:	48 8b 05 8f c7 01 00 	mov    0x1c78f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    73c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    73cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    73d1:	48 85 c0             	test   %rax,%rax
    73d4:	74 c2                	je     7398 <fwp_caps37+0xb8>
    73d6:	0f b6 0a             	movzbl (%rdx),%ecx
    73d9:	80 f9 02             	cmp    $0x2,%cl
    73dc:	74 42                	je     7420 <fwp_caps37+0x140>
    73de:	80 f9 01             	cmp    $0x1,%cl
    73e1:	75 b5                	jne    7398 <fwp_caps37+0xb8>
    73e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73e6:	0f b7 ff             	movzwl %di,%edi
    73e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73ec:	48 0f af f9          	imul   %rcx,%rdi
    73f0:	48 c1 ef 20          	shr    $0x20,%rdi
    73f4:	48 39 d7             	cmp    %rdx,%rdi
    73f7:	73 9f                	jae    7398 <fwp_caps37+0xb8>
    73f9:	48 01 f8             	add    %rdi,%rax
    73fc:	0f b6 10             	movzbl (%rax),%edx
    73ff:	84 d2                	test   %dl,%dl
    7401:	74 95                	je     7398 <fwp_caps37+0xb8>
    7403:	80 fa fd             	cmp    $0xfd,%dl
    7406:	77 23                	ja     742b <fwp_caps37+0x14b>
    7408:	83 c2 01             	add    $0x1,%edx
    740b:	88 10                	mov    %dl,(%rax)
    740d:	eb 89                	jmp    7398 <fwp_caps37+0xb8>
    740f:	90                   	nop
    7410:	66 85 d2             	test   %dx,%dx
    7413:	0f 85 7f ff ff ff    	jne    7398 <fwp_caps37+0xb8>
    7419:	e9 58 ff ff ff       	jmp    7376 <fwp_caps37+0x96>
    741e:	66 90                	xchg   %ax,%ax
    7420:	66 85 ff             	test   %di,%di
    7423:	0f 85 6f ff ff ff    	jne    7398 <fwp_caps37+0xb8>
    7429:	eb d1                	jmp    73fc <fwp_caps37+0x11c>
    742b:	48 89 c7             	mov    %rax,%rdi
    742e:	48 83 c4 18          	add    $0x18,%rsp
    7432:	e9 b9 dd ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7437:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    743e:	00 00 

0000000000007440 <fwp_drop0>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	48 8b 15 ed c6 01 00 	mov    0x1c6ed(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    744b:	48 89 f8             	mov    %rdi,%rax
    744e:	48 2b 05 bb c6 01 00 	sub    0x1c6bb(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7455:	48 c1 e2 10          	shl    $0x10,%rdx
    7459:	48 39 d0             	cmp    %rdx,%rax
    745c:	0f 83 36 01 00 00    	jae    7598 <fwp_drop0+0x158>
    7462:	48 83 ec 18          	sub    $0x18,%rsp
    7466:	48 8d 35 f3 b2 01 00 	lea    0x1b2f3(%rip),%rsi        # 22760 <fwp_heap>
    746d:	48 89 c2             	mov    %rax,%rdx
    7470:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7477:	48 c1 ea 10          	shr    $0x10,%rdx
    747b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    747f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7483:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7487:	48 85 d2             	test   %rdx,%rdx
    748a:	74 42                	je     74ce <fwp_drop0+0x8e>
    748c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7490:	41 80 f8 02          	cmp    $0x2,%r8b
    7494:	74 42                	je     74d8 <fwp_drop0+0x98>
    7496:	41 80 f8 01          	cmp    $0x1,%r8b
    749a:	75 32                	jne    74ce <fwp_drop0+0x8e>
    749c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    74a0:	0f b7 c0             	movzwl %ax,%eax
    74a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    74a6:	49 0f af c0          	imul   %r8,%rax
    74aa:	48 c1 e8 20          	shr    $0x20,%rax
    74ae:	48 39 c8             	cmp    %rcx,%rax
    74b1:	73 1b                	jae    74ce <fwp_drop0+0x8e>
    74b3:	48 01 c2             	add    %rax,%rdx
    74b6:	0f b6 02             	movzbl (%rdx),%eax
    74b9:	84 c0                	test   %al,%al
    74bb:	74 11                	je     74ce <fwp_drop0+0x8e>
    74bd:	3c 01                	cmp    $0x1,%al
    74bf:	74 27                	je     74e8 <fwp_drop0+0xa8>
    74c1:	3c ff                	cmp    $0xff,%al
    74c3:	0f 84 e7 00 00 00    	je     75b0 <fwp_drop0+0x170>
    74c9:	83 e8 01             	sub    $0x1,%eax
    74cc:	88 02                	mov    %al,(%rdx)
    74ce:	48 83 c4 18          	add    $0x18,%rsp
    74d2:	c3                   	ret
    74d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74d8:	66 85 c0             	test   %ax,%ax
    74db:	74 d9                	je     74b6 <fwp_drop0+0x76>
    74dd:	48 83 c4 18          	add    $0x18,%rsp
    74e1:	c3                   	ret
    74e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74e8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    74ef:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    74f6:	48 89 f8             	mov    %rdi,%rax
    74f9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    74fd:	48 29 c8             	sub    %rcx,%rax
    7500:	48 c1 e2 10          	shl    $0x10,%rdx
    7504:	48 39 d0             	cmp    %rdx,%rax
    7507:	73 71                	jae    757a <fwp_drop0+0x13a>
    7509:	49 89 c2             	mov    %rax,%r10
    750c:	49 c1 ea 10          	shr    $0x10,%r10
    7510:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7514:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7518:	4d 8b 51 20          	mov    0x20(%r9),%r10
    751c:	4d 85 d2             	test   %r10,%r10
    751f:	74 59                	je     757a <fwp_drop0+0x13a>
    7521:	45 0f b6 19          	movzbl (%r9),%r11d
    7525:	41 80 fb 02          	cmp    $0x2,%r11b
    7529:	74 75                	je     75a0 <fwp_drop0+0x160>
    752b:	41 80 fb 01          	cmp    $0x1,%r11b
    752f:	75 49                	jne    757a <fwp_drop0+0x13a>
    7531:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7535:	0f b7 c0             	movzwl %ax,%eax
    7538:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    753c:	49 0f af c3          	imul   %r11,%rax
    7540:	48 c1 e8 20          	shr    $0x20,%rax
    7544:	4c 39 c8             	cmp    %r9,%rax
    7547:	73 31                	jae    757a <fwp_drop0+0x13a>
    7549:	49 01 c2             	add    %rax,%r10
    754c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7550:	75 28                	jne    757a <fwp_drop0+0x13a>
    7552:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7557:	e8 f4 df ff ff       	call   5550 <fwp_mem_free>
    755c:	48 8d 35 fd b1 01 00 	lea    0x1b1fd(%rip),%rsi        # 22760 <fwp_heap>
    7563:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7568:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    756f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7576:	48 c1 e2 10          	shl    $0x10,%rdx
    757a:	4c 89 c0             	mov    %r8,%rax
    757d:	48 29 c8             	sub    %rcx,%rax
    7580:	48 39 d0             	cmp    %rdx,%rax
    7583:	0f 83 45 ff ff ff    	jae    74ce <fwp_drop0+0x8e>
    7589:	4c 89 c7             	mov    %r8,%rdi
    758c:	e9 dc fe ff ff       	jmp    746d <fwp_drop0+0x2d>
    7591:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7598:	c3                   	ret
    7599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75a0:	66 85 c0             	test   %ax,%ax
    75a3:	75 d5                	jne    757a <fwp_drop0+0x13a>
    75a5:	eb a5                	jmp    754c <fwp_drop0+0x10c>
    75a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ae:	00 00 
    75b0:	48 89 d0             	mov    %rdx,%rax
    75b3:	48 c1 e8 11          	shr    $0x11,%rax
    75b7:	48 31 d0             	xor    %rdx,%rax
    75ba:	48 89 c1             	mov    %rax,%rcx
    75bd:	48 c1 e9 09          	shr    $0x9,%rcx
    75c1:	48 31 c8             	xor    %rcx,%rax
    75c4:	0f b6 c8             	movzbl %al,%ecx
    75c7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    75ce:	00 
    75cf:	48 85 c0             	test   %rax,%rax
    75d2:	75 15                	jne    75e9 <fwp_drop0+0x1a9>
    75d4:	eb 4e                	jmp    7624 <fwp_drop0+0x1e4>
    75d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    75dd:	00 00 00 
    75e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    75e4:	48 85 c0             	test   %rax,%rax
    75e7:	74 3b                	je     7624 <fwp_drop0+0x1e4>
    75e9:	48 89 c1             	mov    %rax,%rcx
    75ec:	48 39 10             	cmp    %rdx,(%rax)
    75ef:	75 ef                	jne    75e0 <fwp_drop0+0x1a0>
    75f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    75f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    75fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7604:	0f 85 c4 fe ff ff    	jne    74ce <fwp_drop0+0x8e>
    760a:	48 89 d7             	mov    %rdx,%rdi
    760d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7612:	e8 f9 dc ff ff       	call   5310 <fwp_rc_forget_slot>
    7617:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    761c:	c6 02 fe             	movb   $0xfe,(%rdx)
    761f:	e9 aa fe ff ff       	jmp    74ce <fwp_drop0+0x8e>
    7624:	48 8d 3d 75 71 00 00 	lea    0x7175(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    762b:	e8 70 cb ff ff       	call   41a0 <fwp_trap>

0000000000007630 <fwp_drop1>:
    7630:	f3 0f 1e fa          	endbr64
    7634:	48 8b 15 fd c4 01 00 	mov    0x1c4fd(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    763b:	48 89 f8             	mov    %rdi,%rax
    763e:	48 2b 05 cb c4 01 00 	sub    0x1c4cb(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7645:	48 c1 e2 10          	shl    $0x10,%rdx
    7649:	48 39 d0             	cmp    %rdx,%rax
    764c:	0f 83 36 01 00 00    	jae    7788 <fwp_drop1+0x158>
    7652:	48 83 ec 18          	sub    $0x18,%rsp
    7656:	48 8d 35 03 b1 01 00 	lea    0x1b103(%rip),%rsi        # 22760 <fwp_heap>
    765d:	48 89 c2             	mov    %rax,%rdx
    7660:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7667:	48 c1 ea 10          	shr    $0x10,%rdx
    766b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    766f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7673:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7677:	48 85 d2             	test   %rdx,%rdx
    767a:	74 42                	je     76be <fwp_drop1+0x8e>
    767c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7680:	41 80 f8 02          	cmp    $0x2,%r8b
    7684:	74 42                	je     76c8 <fwp_drop1+0x98>
    7686:	41 80 f8 01          	cmp    $0x1,%r8b
    768a:	75 32                	jne    76be <fwp_drop1+0x8e>
    768c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7690:	0f b7 c0             	movzwl %ax,%eax
    7693:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7696:	49 0f af c0          	imul   %r8,%rax
    769a:	48 c1 e8 20          	shr    $0x20,%rax
    769e:	48 39 c8             	cmp    %rcx,%rax
    76a1:	73 1b                	jae    76be <fwp_drop1+0x8e>
    76a3:	48 01 c2             	add    %rax,%rdx
    76a6:	0f b6 02             	movzbl (%rdx),%eax
    76a9:	84 c0                	test   %al,%al
    76ab:	74 11                	je     76be <fwp_drop1+0x8e>
    76ad:	3c 01                	cmp    $0x1,%al
    76af:	74 27                	je     76d8 <fwp_drop1+0xa8>
    76b1:	3c ff                	cmp    $0xff,%al
    76b3:	0f 84 e7 00 00 00    	je     77a0 <fwp_drop1+0x170>
    76b9:	83 e8 01             	sub    $0x1,%eax
    76bc:	88 02                	mov    %al,(%rdx)
    76be:	48 83 c4 18          	add    $0x18,%rsp
    76c2:	c3                   	ret
    76c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76c8:	66 85 c0             	test   %ax,%ax
    76cb:	74 d9                	je     76a6 <fwp_drop1+0x76>
    76cd:	48 83 c4 18          	add    $0x18,%rsp
    76d1:	c3                   	ret
    76d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76d8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    76df:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    76e6:	48 89 f8             	mov    %rdi,%rax
    76e9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    76ed:	48 29 c8             	sub    %rcx,%rax
    76f0:	48 c1 e2 10          	shl    $0x10,%rdx
    76f4:	48 39 d0             	cmp    %rdx,%rax
    76f7:	73 71                	jae    776a <fwp_drop1+0x13a>
    76f9:	49 89 c2             	mov    %rax,%r10
    76fc:	49 c1 ea 10          	shr    $0x10,%r10
    7700:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7704:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7708:	4d 8b 51 20          	mov    0x20(%r9),%r10
    770c:	4d 85 d2             	test   %r10,%r10
    770f:	74 59                	je     776a <fwp_drop1+0x13a>
    7711:	45 0f b6 19          	movzbl (%r9),%r11d
    7715:	41 80 fb 02          	cmp    $0x2,%r11b
    7719:	74 75                	je     7790 <fwp_drop1+0x160>
    771b:	41 80 fb 01          	cmp    $0x1,%r11b
    771f:	75 49                	jne    776a <fwp_drop1+0x13a>
    7721:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7725:	0f b7 c0             	movzwl %ax,%eax
    7728:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    772c:	49 0f af c3          	imul   %r11,%rax
    7730:	48 c1 e8 20          	shr    $0x20,%rax
    7734:	4c 39 c8             	cmp    %r9,%rax
    7737:	73 31                	jae    776a <fwp_drop1+0x13a>
    7739:	49 01 c2             	add    %rax,%r10
    773c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7740:	75 28                	jne    776a <fwp_drop1+0x13a>
    7742:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7747:	e8 04 de ff ff       	call   5550 <fwp_mem_free>
    774c:	48 8d 35 0d b0 01 00 	lea    0x1b00d(%rip),%rsi        # 22760 <fwp_heap>
    7753:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7758:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    775f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7766:	48 c1 e2 10          	shl    $0x10,%rdx
    776a:	4c 89 c0             	mov    %r8,%rax
    776d:	48 29 c8             	sub    %rcx,%rax
    7770:	48 39 d0             	cmp    %rdx,%rax
    7773:	0f 83 45 ff ff ff    	jae    76be <fwp_drop1+0x8e>
    7779:	4c 89 c7             	mov    %r8,%rdi
    777c:	e9 dc fe ff ff       	jmp    765d <fwp_drop1+0x2d>
    7781:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7788:	c3                   	ret
    7789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7790:	66 85 c0             	test   %ax,%ax
    7793:	75 d5                	jne    776a <fwp_drop1+0x13a>
    7795:	eb a5                	jmp    773c <fwp_drop1+0x10c>
    7797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    779e:	00 00 
    77a0:	48 89 d0             	mov    %rdx,%rax
    77a3:	48 c1 e8 11          	shr    $0x11,%rax
    77a7:	48 31 d0             	xor    %rdx,%rax
    77aa:	48 89 c1             	mov    %rax,%rcx
    77ad:	48 c1 e9 09          	shr    $0x9,%rcx
    77b1:	48 31 c8             	xor    %rcx,%rax
    77b4:	0f b6 c8             	movzbl %al,%ecx
    77b7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    77be:	00 
    77bf:	48 85 c0             	test   %rax,%rax
    77c2:	75 25                	jne    77e9 <fwp_drop1+0x1b9>
    77c4:	eb 5e                	jmp    7824 <fwp_drop1+0x1f4>
    77c6:	0f 1f 40 00          	nopl   0x0(%rax)
    77ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77d1:	00 00 00 00 
    77d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77dc:	00 00 00 00 
    77e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    77e4:	48 85 c0             	test   %rax,%rax
    77e7:	74 3b                	je     7824 <fwp_drop1+0x1f4>
    77e9:	48 89 c1             	mov    %rax,%rcx
    77ec:	48 39 10             	cmp    %rdx,(%rax)
    77ef:	75 ef                	jne    77e0 <fwp_drop1+0x1b0>
    77f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    77f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    77fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7804:	0f 85 b4 fe ff ff    	jne    76be <fwp_drop1+0x8e>
    780a:	48 89 d7             	mov    %rdx,%rdi
    780d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7812:	e8 f9 da ff ff       	call   5310 <fwp_rc_forget_slot>
    7817:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    781c:	c6 02 fe             	movb   $0xfe,(%rdx)
    781f:	e9 9a fe ff ff       	jmp    76be <fwp_drop1+0x8e>
    7824:	48 8d 3d 75 6f 00 00 	lea    0x6f75(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    782b:	e8 70 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007830 <fwp_drop10>:
    7830:	48 8b 0d 01 c3 01 00 	mov    0x1c301(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    7837:	48 89 f8             	mov    %rdi,%rax
    783a:	48 2b 05 cf c2 01 00 	sub    0x1c2cf(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7841:	48 c1 e1 10          	shl    $0x10,%rcx
    7845:	48 39 c8             	cmp    %rcx,%rax
    7848:	0f 83 c2 01 00 00    	jae    7a10 <fwp_drop10+0x1e0>
    784e:	48 83 ec 18          	sub    $0x18,%rsp
    7852:	48 89 fa             	mov    %rdi,%rdx
    7855:	48 8d 35 04 af 01 00 	lea    0x1af04(%rip),%rsi        # 22760 <fwp_heap>
    785c:	48 89 c1             	mov    %rax,%rcx
    785f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7866:	48 c1 e9 10          	shr    $0x10,%rcx
    786a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    786e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7872:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7876:	48 85 c9             	test   %rcx,%rcx
    7879:	74 46                	je     78c1 <fwp_drop10+0x91>
    787b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    787f:	41 80 f9 02          	cmp    $0x2,%r9b
    7883:	0f 84 d7 00 00 00    	je     7960 <fwp_drop10+0x130>
    7889:	41 80 f9 01          	cmp    $0x1,%r9b
    788d:	75 32                	jne    78c1 <fwp_drop10+0x91>
    788f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7893:	0f b7 c0             	movzwl %ax,%eax
    7896:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7899:	49 0f af c1          	imul   %r9,%rax
    789d:	48 c1 e8 20          	shr    $0x20,%rax
    78a1:	48 39 f8             	cmp    %rdi,%rax
    78a4:	73 1b                	jae    78c1 <fwp_drop10+0x91>
    78a6:	48 01 c1             	add    %rax,%rcx
    78a9:	0f b6 01             	movzbl (%rcx),%eax
    78ac:	84 c0                	test   %al,%al
    78ae:	74 11                	je     78c1 <fwp_drop10+0x91>
    78b0:	3c 01                	cmp    $0x1,%al
    78b2:	74 1c                	je     78d0 <fwp_drop10+0xa0>
    78b4:	3c ff                	cmp    $0xff,%al
    78b6:	0f 84 5c 01 00 00    	je     7a18 <fwp_drop10+0x1e8>
    78bc:	83 e8 01             	sub    $0x1,%eax
    78bf:	88 01                	mov    %al,(%rcx)
    78c1:	48 83 c4 18          	add    $0x18,%rsp
    78c5:	c3                   	ret
    78c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78cd:	00 00 00 
    78d0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    78d7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    78de:	48 89 d0             	mov    %rdx,%rax
    78e1:	49 89 d1             	mov    %rdx,%r9
    78e4:	48 c1 e1 10          	shl    $0x10,%rcx
    78e8:	48 29 f8             	sub    %rdi,%rax
    78eb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    78ef:	78 7f                	js     7970 <fwp_drop10+0x140>
    78f1:	48 39 c8             	cmp    %rcx,%rax
    78f4:	73 cb                	jae    78c1 <fwp_drop10+0x91>
    78f6:	48 89 c1             	mov    %rax,%rcx
    78f9:	48 c1 e9 10          	shr    $0x10,%rcx
    78fd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7901:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7905:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7909:	48 85 f6             	test   %rsi,%rsi
    790c:	74 b3                	je     78c1 <fwp_drop10+0x91>
    790e:	0f b6 39             	movzbl (%rcx),%edi
    7911:	40 80 ff 02          	cmp    $0x2,%dil
    7915:	74 39                	je     7950 <fwp_drop10+0x120>
    7917:	40 80 ff 01          	cmp    $0x1,%dil
    791b:	75 a4                	jne    78c1 <fwp_drop10+0x91>
    791d:	8b 79 18             	mov    0x18(%rcx),%edi
    7920:	0f b7 c0             	movzwl %ax,%eax
    7923:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7926:	48 0f af c7          	imul   %rdi,%rax
    792a:	48 c1 e8 20          	shr    $0x20,%rax
    792e:	48 39 c8             	cmp    %rcx,%rax
    7931:	73 8e                	jae    78c1 <fwp_drop10+0x91>
    7933:	48 01 c6             	add    %rax,%rsi
    7936:	80 3e 01             	cmpb   $0x1,(%rsi)
    7939:	75 86                	jne    78c1 <fwp_drop10+0x91>
    793b:	48 89 d7             	mov    %rdx,%rdi
    793e:	48 83 c4 18          	add    $0x18,%rsp
    7942:	e9 09 dc ff ff       	jmp    5550 <fwp_mem_free>
    7947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    794e:	00 00 
    7950:	66 85 c0             	test   %ax,%ax
    7953:	74 e1                	je     7936 <fwp_drop10+0x106>
    7955:	48 83 c4 18          	add    $0x18,%rsp
    7959:	c3                   	ret
    795a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7960:	66 85 c0             	test   %ax,%ax
    7963:	0f 84 40 ff ff ff    	je     78a9 <fwp_drop10+0x79>
    7969:	48 83 c4 18          	add    $0x18,%rsp
    796d:	c3                   	ret
    796e:	66 90                	xchg   %ax,%ax
    7970:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7974:	48 39 c8             	cmp    %rcx,%rax
    7977:	73 74                	jae    79ed <fwp_drop10+0x1bd>
    7979:	49 89 c2             	mov    %rax,%r10
    797c:	49 c1 ea 10          	shr    $0x10,%r10
    7980:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7984:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7988:	4d 8b 50 20          	mov    0x20(%r8),%r10
    798c:	4d 85 d2             	test   %r10,%r10
    798f:	74 5c                	je     79ed <fwp_drop10+0x1bd>
    7991:	45 0f b6 18          	movzbl (%r8),%r11d
    7995:	41 80 fb 02          	cmp    $0x2,%r11b
    7999:	74 6d                	je     7a08 <fwp_drop10+0x1d8>
    799b:	41 80 fb 01          	cmp    $0x1,%r11b
    799f:	75 4c                	jne    79ed <fwp_drop10+0x1bd>
    79a1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    79a5:	0f b7 c0             	movzwl %ax,%eax
    79a8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    79ac:	49 0f af c3          	imul   %r11,%rax
    79b0:	48 c1 e8 20          	shr    $0x20,%rax
    79b4:	4c 39 c0             	cmp    %r8,%rax
    79b7:	73 34                	jae    79ed <fwp_drop10+0x1bd>
    79b9:	49 01 c2             	add    %rax,%r10
    79bc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79c0:	75 2b                	jne    79ed <fwp_drop10+0x1bd>
    79c2:	4c 89 cf             	mov    %r9,%rdi
    79c5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79ca:	e8 81 db ff ff       	call   5550 <fwp_mem_free>
    79cf:	48 8d 35 8a ad 01 00 	lea    0x1ad8a(%rip),%rsi        # 22760 <fwp_heap>
    79d6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79db:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    79e2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    79e9:	48 c1 e1 10          	shl    $0x10,%rcx
    79ed:	48 89 d0             	mov    %rdx,%rax
    79f0:	48 29 f8             	sub    %rdi,%rax
    79f3:	48 39 c8             	cmp    %rcx,%rax
    79f6:	0f 82 60 fe ff ff    	jb     785c <fwp_drop10+0x2c>
    79fc:	e9 c0 fe ff ff       	jmp    78c1 <fwp_drop10+0x91>
    7a01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a08:	66 85 c0             	test   %ax,%ax
    7a0b:	75 e0                	jne    79ed <fwp_drop10+0x1bd>
    7a0d:	eb ad                	jmp    79bc <fwp_drop10+0x18c>
    7a0f:	90                   	nop
    7a10:	c3                   	ret
    7a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a18:	48 89 c8             	mov    %rcx,%rax
    7a1b:	48 c1 e8 11          	shr    $0x11,%rax
    7a1f:	48 31 c8             	xor    %rcx,%rax
    7a22:	48 89 c2             	mov    %rax,%rdx
    7a25:	48 c1 ea 09          	shr    $0x9,%rdx
    7a29:	48 31 d0             	xor    %rdx,%rax
    7a2c:	0f b6 d0             	movzbl %al,%edx
    7a2f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7a36:	00 
    7a37:	48 85 c0             	test   %rax,%rax
    7a3a:	75 0d                	jne    7a49 <fwp_drop10+0x219>
    7a3c:	eb 46                	jmp    7a84 <fwp_drop10+0x254>
    7a3e:	66 90                	xchg   %ax,%ax
    7a40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7a44:	48 85 c0             	test   %rax,%rax
    7a47:	74 3b                	je     7a84 <fwp_drop10+0x254>
    7a49:	48 89 c2             	mov    %rax,%rdx
    7a4c:	48 39 08             	cmp    %rcx,(%rax)
    7a4f:	75 ef                	jne    7a40 <fwp_drop10+0x210>
    7a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a55:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7a59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7a5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7a64:	0f 85 57 fe ff ff    	jne    78c1 <fwp_drop10+0x91>
    7a6a:	48 89 cf             	mov    %rcx,%rdi
    7a6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7a72:	e8 99 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7a77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7a7c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7a7f:	e9 3d fe ff ff       	jmp    78c1 <fwp_drop10+0x91>
    7a84:	48 8d 3d 15 6d 00 00 	lea    0x6d15(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    7a8b:	e8 10 c7 ff ff       	call   41a0 <fwp_trap>

0000000000007a90 <f37>:
    7a90:	41 57                	push   %r15
    7a92:	41 56                	push   %r14
    7a94:	41 55                	push   %r13
    7a96:	41 54                	push   %r12
    7a98:	55                   	push   %rbp
    7a99:	53                   	push   %rbx
    7a9a:	48 83 ec 38          	sub    $0x38,%rsp
    7a9e:	48 8b 15 93 c0 01 00 	mov    0x1c093(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7aa5:	48 8b 0d 64 c0 01 00 	mov    0x1c064(%rip),%rcx        # 23b10 <fwp_heap+0x13b0>
    7aac:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7ab3:	00 00 
    7ab5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7aba:	49 89 fd             	mov    %rdi,%r13
    7abd:	48 c1 e2 10          	shl    $0x10,%rdx
    7ac1:	48 85 ff             	test   %rdi,%rdi
    7ac4:	0f 84 0c 03 00 00    	je     7dd6 <f37+0x346>
    7aca:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7ace:	48 89 d8             	mov    %rbx,%rax
    7ad1:	48 29 c8             	sub    %rcx,%rax
    7ad4:	48 39 d0             	cmp    %rdx,%rax
    7ad7:	0f 83 c3 03 00 00    	jae    7ea0 <f37+0x410>
    7add:	48 89 c2             	mov    %rax,%rdx
    7ae0:	48 c1 ea 10          	shr    $0x10,%rdx
    7ae4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ae8:	48 8b 15 69 c0 01 00 	mov    0x1c069(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7aef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7af3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7af7:	48 85 ff             	test   %rdi,%rdi
    7afa:	0f 84 a0 03 00 00    	je     7ea0 <f37+0x410>
    7b00:	0f b6 0a             	movzbl (%rdx),%ecx
    7b03:	80 f9 02             	cmp    $0x2,%cl
    7b06:	0f 84 a4 02 00 00    	je     7db0 <f37+0x320>
    7b0c:	80 f9 01             	cmp    $0x1,%cl
    7b0f:	75 24                	jne    7b35 <f37+0xa5>
    7b11:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b14:	0f b7 c0             	movzwl %ax,%eax
    7b17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b1a:	48 0f af c1          	imul   %rcx,%rax
    7b1e:	48 c1 e8 20          	shr    $0x20,%rax
    7b22:	48 39 d0             	cmp    %rdx,%rax
    7b25:	73 0e                	jae    7b35 <f37+0xa5>
    7b27:	48 01 c7             	add    %rax,%rdi
    7b2a:	0f b6 07             	movzbl (%rdi),%eax
    7b2d:	84 c0                	test   %al,%al
    7b2f:	0f 85 1b 03 00 00    	jne    7e50 <f37+0x3c0>
    7b35:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7b3a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7b3e:	ba 01 00 00 00       	mov    $0x1,%edx
    7b43:	48 85 db             	test   %rbx,%rbx
    7b46:	74 15                	je     7b5d <f37+0xcd>
    7b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7b4f:	00 
    7b50:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7b54:	48 83 c2 01          	add    $0x1,%rdx
    7b58:	48 85 db             	test   %rbx,%rbx
    7b5b:	75 f3                	jne    7b50 <f37+0xc0>
    7b5d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b62:	48 85 c0             	test   %rax,%rax
    7b65:	0f 84 65 03 00 00    	je     7ed0 <f37+0x440>
    7b6b:	31 db                	xor    %ebx,%ebx
    7b6d:	0f 1f 00             	nopl   (%rax)
    7b70:	48 8b 40 10          	mov    0x10(%rax),%rax
    7b74:	48 83 c3 01          	add    $0x1,%rbx
    7b78:	48 85 c0             	test   %rax,%rax
    7b7b:	75 f3                	jne    7b70 <f37+0xe0>
    7b7d:	48 39 d3             	cmp    %rdx,%rbx
    7b80:	48 0f 47 da          	cmova  %rdx,%rbx
    7b84:	48 89 d8             	mov    %rbx,%rax
    7b87:	48 c1 e8 3c          	shr    $0x3c,%rax
    7b8b:	0f 85 e3 03 00 00    	jne    7f74 <f37+0x4e4>
    7b91:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7b95:	be 02 00 00 00       	mov    $0x2,%esi
    7b9a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7ba1:	00 
    7ba2:	e8 a9 de ff ff       	call   5a50 <fwp_heap_alloc>
    7ba7:	48 89 28             	mov    %rbp,(%rax)
    7baa:	48 8b 15 87 bf 01 00 	mov    0x1bf87(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7bb1:	49 89 c4             	mov    %rax,%r12
    7bb4:	48 2b 05 55 bf 01 00 	sub    0x1bf55(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7bbb:	48 c1 e2 10          	shl    $0x10,%rdx
    7bbf:	48 39 d0             	cmp    %rdx,%rax
    7bc2:	73 57                	jae    7c1b <f37+0x18b>
    7bc4:	48 89 c2             	mov    %rax,%rdx
    7bc7:	48 c1 ea 10          	shr    $0x10,%rdx
    7bcb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7bcf:	48 8b 15 82 bf 01 00 	mov    0x1bf82(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7bd6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bda:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7bde:	48 85 ed             	test   %rbp,%rbp
    7be1:	74 38                	je     7c1b <f37+0x18b>
    7be3:	0f b6 0a             	movzbl (%rdx),%ecx
    7be6:	80 f9 02             	cmp    $0x2,%cl
    7be9:	0f 84 a1 02 00 00    	je     7e90 <f37+0x400>
    7bef:	80 f9 01             	cmp    $0x1,%cl
    7bf2:	75 27                	jne    7c1b <f37+0x18b>
    7bf4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7bf7:	0f b7 c0             	movzwl %ax,%eax
    7bfa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bfd:	48 0f af c1          	imul   %rcx,%rax
    7c01:	48 c1 e8 20          	shr    $0x20,%rax
    7c05:	48 39 d0             	cmp    %rdx,%rax
    7c08:	73 11                	jae    7c1b <f37+0x18b>
    7c0a:	48 01 c5             	add    %rax,%rbp
    7c0d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7c11:	0f 84 29 03 00 00    	je     7f40 <f37+0x4b0>
    7c17:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7c1b:	48 85 db             	test   %rbx,%rbx
    7c1e:	74 5d                	je     7c7d <f37+0x1ed>
    7c20:	48 c1 e3 04          	shl    $0x4,%rbx
    7c24:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7c29:	4c 89 e5             	mov    %r12,%rbp
    7c2c:	4d 89 ee             	mov    %r13,%r14
    7c2f:	4c 01 e3             	add    %r12,%rbx
    7c32:	0f 1f 00             	nopl   (%rax)
    7c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c3c:	00 00 00 00 
    7c40:	49 8b 46 08          	mov    0x8(%r14),%rax
    7c44:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7c48:	48 83 c5 10          	add    $0x10,%rbp
    7c4c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7c51:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7c55:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7c59:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7c5e:	e8 bd e3 ff ff       	call   6020 <w120>
    7c63:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7c68:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7c6c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7c70:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7c74:	4d 8b 76 10          	mov    0x10(%r14),%r14
    7c78:	48 39 eb             	cmp    %rbp,%rbx
    7c7b:	75 c3                	jne    7c40 <f37+0x1b0>
    7c7d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7c82:	31 db                	xor    %ebx,%ebx
    7c84:	e8 c7 ed ff ff       	call   6a50 <fwp_drop4>
    7c89:	4c 89 ef             	mov    %r13,%rdi
    7c8c:	e8 bf ed ff ff       	call   6a50 <fwp_drop4>
    7c91:	4d 8b 2c 24          	mov    (%r12),%r13
    7c95:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7c99:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    7ca0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    7ca7:	4d 85 ed             	test   %r13,%r13
    7caa:	74 3f                	je     7ceb <f37+0x25b>
    7cac:	0f 1f 40 00          	nopl   0x0(%rax)
    7cb0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    7cb7:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    7cbc:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    7cc3:	00 f0 3f 
    7cc6:	48 83 c3 02          	add    $0x2,%rbx
    7cca:	48 89 ce             	mov    %rcx,%rsi
    7ccd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7cd3:	e8 c8 df ff ff       	call   5ca0 <fwp_p_ad_push>
    7cd8:	4c 39 eb             	cmp    %r13,%rbx
    7cdb:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7ce1:	48 89 c7             	mov    %rax,%rdi
    7ce4:	72 ca                	jb     7cb0 <f37+0x220>
    7ce6:	66 49 0f 7e c5       	movq   %xmm0,%r13
    7ceb:	4c 89 e7             	mov    %r12,%rdi
    7cee:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7cf3:	e8 38 fb ff ff       	call   7830 <fwp_drop10>
    7cf8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7cfd:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7d02:	31 ff                	xor    %edi,%edi
    7d04:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    7d09:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7d0e:	e8 5d de ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7d13:	48 8b 15 1e be 01 00 	mov    0x1be1e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7d1a:	48 89 c5             	mov    %rax,%rbp
    7d1d:	48 2b 05 ec bd 01 00 	sub    0x1bdec(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7d24:	48 c1 e2 10          	shl    $0x10,%rdx
    7d28:	48 39 d0             	cmp    %rdx,%rax
    7d2b:	73 55                	jae    7d82 <f37+0x2f2>
    7d2d:	48 89 c2             	mov    %rax,%rdx
    7d30:	48 c1 ea 10          	shr    $0x10,%rdx
    7d34:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d38:	48 8b 15 19 be 01 00 	mov    0x1be19(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7d3f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d43:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7d47:	48 85 db             	test   %rbx,%rbx
    7d4a:	74 36                	je     7d82 <f37+0x2f2>
    7d4c:	0f b6 0a             	movzbl (%rdx),%ecx
    7d4f:	80 f9 02             	cmp    $0x2,%cl
    7d52:	0f 84 20 01 00 00    	je     7e78 <f37+0x3e8>
    7d58:	80 f9 01             	cmp    $0x1,%cl
    7d5b:	75 25                	jne    7d82 <f37+0x2f2>
    7d5d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d60:	0f b7 c0             	movzwl %ax,%eax
    7d63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d66:	48 0f af c1          	imul   %rcx,%rax
    7d6a:	48 c1 e8 20          	shr    $0x20,%rax
    7d6e:	48 39 d0             	cmp    %rdx,%rax
    7d71:	73 0f                	jae    7d82 <f37+0x2f2>
    7d73:	48 01 c3             	add    %rax,%rbx
    7d76:	80 3b ff             	cmpb   $0xff,(%rbx)
    7d79:	0f 84 b4 01 00 00    	je     7f33 <f37+0x4a3>
    7d7f:	c6 03 01             	movb   $0x1,(%rbx)
    7d82:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7d87:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7d8e:	00 00 
    7d90:	0f 85 d9 01 00 00    	jne    7f6f <f37+0x4df>
    7d96:	48 83 c4 38          	add    $0x38,%rsp
    7d9a:	48 89 e8             	mov    %rbp,%rax
    7d9d:	5b                   	pop    %rbx
    7d9e:	5d                   	pop    %rbp
    7d9f:	41 5c                	pop    %r12
    7da1:	41 5d                	pop    %r13
    7da3:	41 5e                	pop    %r14
    7da5:	41 5f                	pop    %r15
    7da7:	c3                   	ret
    7da8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7daf:	00 
    7db0:	66 85 c0             	test   %ax,%ax
    7db3:	0f 85 7c fd ff ff    	jne    7b35 <f37+0xa5>
    7db9:	0f b6 07             	movzbl (%rdi),%eax
    7dbc:	84 c0                	test   %al,%al
    7dbe:	0f 84 71 fd ff ff    	je     7b35 <f37+0xa5>
    7dc4:	3c fd                	cmp    $0xfd,%al
    7dc6:	0f 87 99 01 00 00    	ja     7f65 <f37+0x4d5>
    7dcc:	83 c0 01             	add    $0x1,%eax
    7dcf:	88 07                	mov    %al,(%rdi)
    7dd1:	e9 5f fd ff ff       	jmp    7b35 <f37+0xa5>
    7dd6:	48 f7 d9             	neg    %rcx
    7dd9:	48 39 d1             	cmp    %rdx,%rcx
    7ddc:	0f 83 ee 00 00 00    	jae    7ed0 <f37+0x440>
    7de2:	48 89 c8             	mov    %rcx,%rax
    7de5:	48 c1 e8 10          	shr    $0x10,%rax
    7de9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ded:	48 8b 05 64 bd 01 00 	mov    0x1bd64(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    7df4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7df8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7dfc:	48 85 ff             	test   %rdi,%rdi
    7dff:	0f 84 cb 00 00 00    	je     7ed0 <f37+0x440>
    7e05:	0f b6 02             	movzbl (%rdx),%eax
    7e08:	3c 02                	cmp    $0x2,%al
    7e0a:	0f 84 9a 00 00 00    	je     7eaa <f37+0x41a>
    7e10:	3c 01                	cmp    $0x1,%al
    7e12:	0f 85 b8 00 00 00    	jne    7ed0 <f37+0x440>
    7e18:	0f b7 c1             	movzwl %cx,%eax
    7e1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e21:	48 0f af c1          	imul   %rcx,%rax
    7e25:	48 c1 e8 20          	shr    $0x20,%rax
    7e29:	48 39 d0             	cmp    %rdx,%rax
    7e2c:	0f 83 9e 00 00 00    	jae    7ed0 <f37+0x440>
    7e32:	48 01 c7             	add    %rax,%rdi
    7e35:	0f b6 07             	movzbl (%rdi),%eax
    7e38:	84 c0                	test   %al,%al
    7e3a:	0f 84 90 00 00 00    	je     7ed0 <f37+0x440>
    7e40:	31 db                	xor    %ebx,%ebx
    7e42:	0f 1f 00             	nopl   (%rax)
    7e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e4c:	00 00 00 00 
    7e50:	3c fd                	cmp    $0xfd,%al
    7e52:	0f 87 f5 00 00 00    	ja     7f4d <f37+0x4bd>
    7e58:	83 c0 01             	add    $0x1,%eax
    7e5b:	88 07                	mov    %al,(%rdi)
    7e5d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e62:	31 d2                	xor    %edx,%edx
    7e64:	4d 85 ed             	test   %r13,%r13
    7e67:	0f 85 cd fc ff ff    	jne    7b3a <f37+0xaa>
    7e6d:	e9 eb fc ff ff       	jmp    7b5d <f37+0xcd>
    7e72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e78:	66 85 c0             	test   %ax,%ax
    7e7b:	0f 85 01 ff ff ff    	jne    7d82 <f37+0x2f2>
    7e81:	e9 f0 fe ff ff       	jmp    7d76 <f37+0x2e6>
    7e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e8d:	00 00 00 
    7e90:	66 85 c0             	test   %ax,%ax
    7e93:	0f 85 82 fd ff ff    	jne    7c1b <f37+0x18b>
    7e99:	e9 6f fd ff ff       	jmp    7c0d <f37+0x17d>
    7e9e:	66 90                	xchg   %ax,%ax
    7ea0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7ea5:	e9 94 fc ff ff       	jmp    7b3e <f37+0xae>
    7eaa:	66 85 c9             	test   %cx,%cx
    7ead:	75 21                	jne    7ed0 <f37+0x440>
    7eaf:	0f b6 07             	movzbl (%rdi),%eax
    7eb2:	84 c0                	test   %al,%al
    7eb4:	74 1a                	je     7ed0 <f37+0x440>
    7eb6:	3c fd                	cmp    $0xfd,%al
    7eb8:	0f 87 c2 00 00 00    	ja     7f80 <f37+0x4f0>
    7ebe:	83 c0 01             	add    $0x1,%eax
    7ec1:	88 07                	mov    %al,(%rdi)
    7ec3:	66 90                	xchg   %ax,%ax
    7ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ecc:	00 00 00 00 
    7ed0:	be 02 00 00 00       	mov    $0x2,%esi
    7ed5:	bf 08 00 00 00       	mov    $0x8,%edi
    7eda:	e8 71 db ff ff       	call   5a50 <fwp_heap_alloc>
    7edf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7ee6:	48 8b 15 4b bc 01 00 	mov    0x1bc4b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7eed:	49 89 c4             	mov    %rax,%r12
    7ef0:	48 2b 05 19 bc 01 00 	sub    0x1bc19(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7ef7:	48 c1 e2 10          	shl    $0x10,%rdx
    7efb:	48 39 d0             	cmp    %rdx,%rax
    7efe:	73 57                	jae    7f57 <f37+0x4c7>
    7f00:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f07:	00 00 
    7f09:	48 89 c2             	mov    %rax,%rdx
    7f0c:	48 c1 ea 10          	shr    $0x10,%rdx
    7f10:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f14:	48 8b 15 3d bc 01 00 	mov    0x1bc3d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7f1b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f1f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7f23:	48 85 ed             	test   %rbp,%rbp
    7f26:	0f 84 51 fd ff ff    	je     7c7d <f37+0x1ed>
    7f2c:	31 db                	xor    %ebx,%ebx
    7f2e:	e9 b0 fc ff ff       	jmp    7be3 <f37+0x153>
    7f33:	48 89 df             	mov    %rbx,%rdi
    7f36:	e8 d5 d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7f3b:	e9 3f fe ff ff       	jmp    7d7f <f37+0x2ef>
    7f40:	48 89 ef             	mov    %rbp,%rdi
    7f43:	e8 c8 d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7f48:	e9 ca fc ff ff       	jmp    7c17 <f37+0x187>
    7f4d:	e8 9e d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f52:	e9 06 ff ff ff       	jmp    7e5d <f37+0x3cd>
    7f57:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f5e:	00 00 
    7f60:	e9 18 fd ff ff       	jmp    7c7d <f37+0x1ed>
    7f65:	e8 86 d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f6a:	e9 c6 fb ff ff       	jmp    7b35 <f37+0xa5>
    7f6f:	e8 ec b4 ff ff       	call   3460 <__stack_chk_fail@plt>
    7f74:	48 8d 3d b2 61 00 00 	lea    0x61b2(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    7f7b:	e8 20 c2 ff ff       	call   41a0 <fwp_trap>
    7f80:	e8 6b d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f85:	e9 46 ff ff ff       	jmp    7ed0 <f37+0x440>
    7f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007f90 <fwp_owned_entry37>:
    7f90:	f3 0f 1e fa          	endbr64
    7f94:	48 8b 3f             	mov    (%rdi),%rdi
    7f97:	e9 f4 fa ff ff       	jmp    7a90 <f37>
    7f9c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007fa0 <e37>:
    7fa0:	f3 0f 1e fa          	endbr64
    7fa4:	53                   	push   %rbx
    7fa5:	48 8b 1f             	mov    (%rdi),%rbx
    7fa8:	48 89 df             	mov    %rbx,%rdi
    7fab:	e8 e0 e1 ff ff       	call   6190 <fwp_rc_share>
    7fb0:	48 89 df             	mov    %rbx,%rdi
    7fb3:	e8 d8 fa ff ff       	call   7a90 <f37>
    7fb8:	48 89 c3             	mov    %rax,%rbx
    7fbb:	48 89 c7             	mov    %rax,%rdi
    7fbe:	e8 cd e1 ff ff       	call   6190 <fwp_rc_share>
    7fc3:	48 89 d8             	mov    %rbx,%rax
    7fc6:	5b                   	pop    %rbx
    7fc7:	c3                   	ret
    7fc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fcf:	00 

0000000000007fd0 <fwp_write>:
    7fd0:	41 57                	push   %r15
    7fd2:	41 56                	push   %r14
    7fd4:	41 55                	push   %r13
    7fd6:	41 54                	push   %r12
    7fd8:	55                   	push   %rbp
    7fd9:	53                   	push   %rbx
    7fda:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    7fe1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7fe8:	00 00 
    7fea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    7ff1:	00 
    7ff2:	49 89 d4             	mov    %rdx,%r12
    7ff5:	8b 12                	mov    (%rdx),%edx
    7ff7:	83 fa 19             	cmp    $0x19,%edx
    7ffa:	77 6a                	ja     8066 <fwp_write+0x96>
    7ffc:	48 89 f5             	mov    %rsi,%rbp
    7fff:	89 d0                	mov    %edx,%eax
    8001:	89 ce                	mov    %ecx,%esi
    8003:	48 89 fb             	mov    %rdi,%rbx
    8006:	48 8d 0d 03 6a 00 00 	lea    0x6a03(%rip),%rcx        # ea10 <_IO_stdin_used+0xa10>
    800d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8011:	48 01 c8             	add    %rcx,%rax
    8014:	3e ff e0             	notrack jmp *%rax
    8017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    801e:	00 00 
    8020:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8024:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8028:	48 89 ca             	mov    %rcx,%rdx
    802b:	48 85 c9             	test   %rcx,%rcx
    802e:	0f 88 9c 0c 00 00    	js     8cd0 <fwp_write+0xd00>
    8034:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    803b:	00 
    803c:	48 89 c6             	mov    %rax,%rsi
    803f:	4c 89 e7             	mov    %r12,%rdi
    8042:	e8 f9 b9 ff ff       	call   3a40 <fwp_fmt_u128>
    8047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    804e:	00 00 
    8050:	4c 89 e7             	mov    %r12,%rdi
    8053:	e8 f8 b3 ff ff       	call   3450 <strlen@plt>
    8058:	4c 89 e6             	mov    %r12,%rsi
    805b:	48 89 df             	mov    %rbx,%rdi
    805e:	48 89 c2             	mov    %rax,%rdx
    8061:	e8 0a c0 ff ff       	call   4070 <buf_put>
    8066:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    806d:	00 
    806e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8075:	00 00 
    8077:	0f 85 28 04 00 00    	jne    84a5 <fwp_write+0x4d5>
    807d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8084:	5b                   	pop    %rbx
    8085:	5d                   	pop    %rbp
    8086:	41 5c                	pop    %r12
    8088:	41 5d                	pop    %r13
    808a:	41 5e                	pop    %r14
    808c:	41 5f                	pop    %r15
    808e:	c3                   	ret
    808f:	90                   	nop
    8090:	49 89 e9             	mov    %rbp,%r9
    8093:	4c 8d 05 bd 60 00 00 	lea    0x60bd(%rip),%r8        # e157 <_IO_stdin_used+0x157>
    809a:	b9 00 02 00 00       	mov    $0x200,%ecx
    809f:	ba 02 00 00 00       	mov    $0x2,%edx
    80a4:	be 00 02 00 00       	mov    $0x200,%esi
    80a9:	31 c0                	xor    %eax,%eax
    80ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80b2:	00 
    80b3:	e8 f8 b2 ff ff       	call   33b0 <__snprintf_chk@plt>
    80b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80bf:	00 
    80c0:	e8 8b b3 ff ff       	call   3450 <strlen@plt>
    80c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    80cc:	00 
    80cd:	48 89 df             	mov    %rbx,%rdi
    80d0:	48 89 c2             	mov    %rax,%rdx
    80d3:	e8 98 bf ff ff       	call   4070 <buf_put>
    80d8:	eb 8c                	jmp    8066 <fwp_write+0x96>
    80da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80e0:	49 89 e9             	mov    %rbp,%r9
    80e3:	4c 8d 05 68 60 00 00 	lea    0x6068(%rip),%r8        # e152 <_IO_stdin_used+0x152>
    80ea:	eb ae                	jmp    809a <fwp_write+0xca>
    80ec:	0f 1f 40 00          	nopl   0x0(%rax)
    80f0:	83 fa 13             	cmp    $0x13,%edx
    80f3:	48 8d 05 4e 60 00 00 	lea    0x604e(%rip),%rax        # e148 <_IO_stdin_used+0x148>
    80fa:	48 8d 35 4c 60 00 00 	lea    0x604c(%rip),%rsi        # e14d <_IO_stdin_used+0x14d>
    8101:	ba 04 00 00 00       	mov    $0x4,%edx
    8106:	48 0f 44 f0          	cmove  %rax,%rsi
    810a:	45 31 ed             	xor    %r13d,%r13d
    810d:	e8 5e bf ff ff       	call   4070 <buf_put>
    8112:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8117:	0f 84 a3 08 00 00    	je     89c0 <fwp_write+0x9f0>
    811d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8122:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8127:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    812c:	48 89 df             	mov    %rbx,%rdi
    812f:	49 0f 44 c5          	cmove  %r13,%rax
    8133:	31 c9                	xor    %ecx,%ecx
    8135:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    813a:	e8 91 fe ff ff       	call   7fd0 <fwp_write>
    813f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8144:	0f 84 6e 09 00 00    	je     8ab8 <fwp_write+0xae8>
    814a:	49 83 c5 01          	add    $0x1,%r13
    814e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8152:	0f 83 68 08 00 00    	jae    89c0 <fwp_write+0x9f0>
    8158:	ba 02 00 00 00       	mov    $0x2,%edx
    815d:	48 8d 35 33 60 00 00 	lea    0x6033(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8164:	48 89 df             	mov    %rbx,%rdi
    8167:	e8 04 bf ff ff       	call   4070 <buf_put>
    816c:	eb af                	jmp    811d <fwp_write+0x14d>
    816e:	66 90                	xchg   %ax,%ax
    8170:	ba 06 00 00 00       	mov    $0x6,%edx
    8175:	48 8d 35 f4 5f 00 00 	lea    0x5ff4(%rip),%rsi        # e170 <_IO_stdin_used+0x170>
    817c:	48 83 c5 10          	add    $0x10,%rbp
    8180:	e8 eb be ff ff       	call   4070 <buf_put>
    8185:	48 89 ef             	mov    %rbp,%rdi
    8188:	e8 c3 b2 ff ff       	call   3450 <strlen@plt>
    818d:	48 89 ee             	mov    %rbp,%rsi
    8190:	48 89 df             	mov    %rbx,%rdi
    8193:	48 89 c2             	mov    %rax,%rdx
    8196:	e8 d5 be ff ff       	call   4070 <buf_put>
    819b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    81a0:	ba 01 00 00 00       	mov    $0x1,%edx
    81a5:	48 89 df             	mov    %rbx,%rdi
    81a8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    81ad:	e8 be be ff ff       	call   4070 <buf_put>
    81b2:	e9 af fe ff ff       	jmp    8066 <fwp_write+0x96>
    81b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81be:	00 00 
    81c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    81c7:	00 
    81c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81cf:	00 00 
    81d1:	0f 85 ce 02 00 00    	jne    84a5 <fwp_write+0x4d5>
    81d7:	ba 0a 00 00 00       	mov    $0xa,%edx
    81dc:	48 8d 35 79 5f 00 00 	lea    0x5f79(%rip),%rsi        # e15c <_IO_stdin_used+0x15c>
    81e3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    81ea:	48 89 df             	mov    %rbx,%rdi
    81ed:	5b                   	pop    %rbx
    81ee:	5d                   	pop    %rbp
    81ef:	41 5c                	pop    %r12
    81f1:	41 5d                	pop    %r13
    81f3:	41 5e                	pop    %r14
    81f5:	41 5f                	pop    %r15
    81f7:	e9 74 be ff ff       	jmp    4070 <buf_put>
    81fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8200:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8205:	4d 85 ed             	test   %r13,%r13
    8208:	0f 84 02 0c 00 00    	je     8e10 <fwp_write+0xe40>
    820e:	48 8d 35 8f 5f 00 00 	lea    0x5f8f(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    8215:	4c 89 ef             	mov    %r13,%rdi
    8218:	e8 13 b3 ff ff       	call   3530 <strcmp@plt>
    821d:	41 89 c1             	mov    %eax,%r9d
    8220:	85 c0                	test   %eax,%eax
    8222:	0f 84 6c 0c 00 00    	je     8e94 <fwp_write+0xec4>
    8228:	4c 89 ef             	mov    %r13,%rdi
    822b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8230:	e8 1b b2 ff ff       	call   3450 <strlen@plt>
    8235:	4c 89 ee             	mov    %r13,%rsi
    8238:	48 89 df             	mov    %rbx,%rdi
    823b:	48 89 c2             	mov    %rax,%rdx
    823e:	e8 2d be ff ff       	call   4070 <buf_put>
    8243:	ba 01 00 00 00       	mov    $0x1,%edx
    8248:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    824d:	48 89 df             	mov    %rbx,%rdi
    8250:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8255:	e8 16 be ff ff       	call   4070 <buf_put>
    825a:	ba 01 00 00 00       	mov    $0x1,%edx
    825f:	4c 89 fe             	mov    %r15,%rsi
    8262:	48 89 df             	mov    %rbx,%rdi
    8265:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    826a:	e8 01 be ff ff       	call   4070 <buf_put>
    826f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8274:	45 31 f6             	xor    %r14d,%r14d
    8277:	85 d2                	test   %edx,%edx
    8279:	0f 8e 81 0a 00 00    	jle    8d00 <fwp_write+0xd30>
    827f:	45 31 ed             	xor    %r13d,%r13d
    8282:	4d 85 ed             	test   %r13,%r13
    8285:	0f 85 75 07 00 00    	jne    8a00 <fwp_write+0xa30>
    828b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8292:	00 
    8293:	45 85 f6             	test   %r14d,%r14d
    8296:	0f 84 84 07 00 00    	je     8a20 <fwp_write+0xa50>
    829c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    82a1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    82a6:	48 89 df             	mov    %rbx,%rdi
    82a9:	49 83 c5 01          	add    $0x1,%r13
    82ad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    82b1:	31 c9                	xor    %ecx,%ecx
    82b3:	e8 18 fd ff ff       	call   7fd0 <fwp_write>
    82b8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    82bd:	7f c3                	jg     8282 <fwp_write+0x2b2>
    82bf:	45 85 f6             	test   %r14d,%r14d
    82c2:	0f 84 38 0a 00 00    	je     8d00 <fwp_write+0xd30>
    82c8:	b8 29 00 00 00       	mov    $0x29,%eax
    82cd:	ba 01 00 00 00       	mov    $0x1,%edx
    82d2:	4c 89 fe             	mov    %r15,%rsi
    82d5:	48 89 df             	mov    %rbx,%rdi
    82d8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    82dc:	e8 8f bd ff ff       	call   4070 <buf_put>
    82e1:	e9 80 fd ff ff       	jmp    8066 <fwp_write+0x96>
    82e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82ed:	00 00 00 
    82f0:	ba 01 00 00 00       	mov    $0x1,%edx
    82f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    82fa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    82ff:	e8 6c bd ff ff       	call   4070 <buf_put>
    8304:	48 85 ed             	test   %rbp,%rbp
    8307:	0f 84 93 06 00 00    	je     89a0 <fwp_write+0x9d0>
    830d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8311:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8316:	31 c9                	xor    %ecx,%ecx
    8318:	48 89 df             	mov    %rbx,%rdi
    831b:	e8 b0 fc ff ff       	call   7fd0 <fwp_write>
    8320:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8324:	48 85 ed             	test   %rbp,%rbp
    8327:	0f 84 73 06 00 00    	je     89a0 <fwp_write+0x9d0>
    832d:	ba 02 00 00 00       	mov    $0x2,%edx
    8332:	48 8d 35 5e 5e 00 00 	lea    0x5e5e(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8339:	48 89 df             	mov    %rbx,%rdi
    833c:	e8 2f bd ff ff       	call   4070 <buf_put>
    8341:	eb ca                	jmp    830d <fwp_write+0x33d>
    8343:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8348:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    834c:	85 f6                	test   %esi,%esi
    834e:	0f 84 fc 07 00 00    	je     8b50 <fwp_write+0xb80>
    8354:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    835b:	00 
    835c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8363:	00 00 
    8365:	0f 85 3a 01 00 00    	jne    84a5 <fwp_write+0x4d5>
    836b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    836f:	4c 89 ea             	mov    %r13,%rdx
    8372:	e9 6c fe ff ff       	jmp    81e3 <fwp_write+0x213>
    8377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    837e:	00 00 
    8380:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8385:	ba 01 00 00 00       	mov    $0x1,%edx
    838a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    838f:	48 89 ee             	mov    %rbp,%rsi
    8392:	e8 d9 bc ff ff       	call   4070 <buf_put>
    8397:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    839c:	4c 89 e7             	mov    %r12,%rdi
    839f:	e8 ac b0 ff ff       	call   3450 <strlen@plt>
    83a4:	4c 89 e6             	mov    %r12,%rsi
    83a7:	48 89 df             	mov    %rbx,%rdi
    83aa:	48 89 c2             	mov    %rax,%rdx
    83ad:	e8 be bc ff ff       	call   4070 <buf_put>
    83b2:	ba 01 00 00 00       	mov    $0x1,%edx
    83b7:	48 89 ee             	mov    %rbp,%rsi
    83ba:	48 89 df             	mov    %rbx,%rdi
    83bd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83c2:	e8 a9 bc ff ff       	call   4070 <buf_put>
    83c7:	e9 9a fc ff ff       	jmp    8066 <fwp_write+0x96>
    83cc:	0f 1f 40 00          	nopl   0x0(%rax)
    83d0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    83d5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    83d9:	0f 8a 8e 0b 00 00    	jp     8f6d <fwp_write+0xf9d>
    83df:	66 0f 28 c1          	movapd %xmm1,%xmm0
    83e3:	66 0f 54 05 55 67 00 	andpd  0x6755(%rip),%xmm0        # eb40 <msg.4+0xc0>
    83ea:	00 
    83eb:	bd 01 00 00 00       	mov    $0x1,%ebp
    83f0:	66 0f 2e 05 c0 66 00 	ucomisd 0x66c0(%rip),%xmm0        # eab8 <msg.4+0x38>
    83f7:	00 
    83f8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    83ff:	00 
    8400:	0f 87 b2 09 00 00    	ja     8db8 <fwp_write+0xde8>
    8406:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    840d:	00 00 00 
    8410:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8414:	89 ee                	mov    %ebp,%esi
    8416:	4c 89 e7             	mov    %r12,%rdi
    8419:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    841e:	e8 9d c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8423:	31 f6                	xor    %esi,%esi
    8425:	4c 89 e7             	mov    %r12,%rdi
    8428:	e8 e3 af ff ff       	call   3410 <strtod@plt>
    842d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8432:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8436:	7a 06                	jp     843e <fwp_write+0x46e>
    8438:	0f 84 e9 01 00 00    	je     8627 <fwp_write+0x657>
    843e:	83 c5 01             	add    $0x1,%ebp
    8441:	83 fd 12             	cmp    $0x12,%ebp
    8444:	75 ca                	jne    8410 <fwp_write+0x440>
    8446:	be 11 00 00 00       	mov    $0x11,%esi
    844b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    844f:	4c 89 e7             	mov    %r12,%rdi
    8452:	e8 69 c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8457:	e9 cb 01 00 00       	jmp    8627 <fwp_write+0x657>
    845c:	0f 1f 40 00          	nopl   0x0(%rax)
    8460:	48 83 fd 01          	cmp    $0x1,%rbp
    8464:	0f 84 e6 08 00 00    	je     8d50 <fwp_write+0xd80>
    846a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    846e:	b8 02 00 00 00       	mov    $0x2,%eax
    8473:	ba 01 00 00 00       	mov    $0x1,%edx
    8478:	48 0f 44 d0          	cmove  %rax,%rdx
    847c:	48 8d 35 bd 5c 00 00 	lea    0x5cbd(%rip),%rsi        # e140 <_IO_stdin_used+0x140>
    8483:	48 8d 05 bb 5c 00 00 	lea    0x5cbb(%rip),%rax        # e145 <_IO_stdin_used+0x145>
    848a:	48 0f 44 f0          	cmove  %rax,%rsi
    848e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8495:	00 
    8496:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    849d:	00 00 
    849f:	0f 84 3e fd ff ff    	je     81e3 <fwp_write+0x213>
    84a5:	e8 b6 af ff ff       	call   3460 <__stack_chk_fail@plt>
    84aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84b0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    84b5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    84ba:	e8 f1 ba ff ff       	call   3fb0 <buf_grow>
    84bf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    84c3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    84c9:	4c 03 0b             	add    (%rbx),%r9
    84cc:	66 45 89 11          	mov    %r10w,(%r9)
    84d0:	45 85 e4             	test   %r12d,%r12d
    84d3:	0f 8e 07 05 00 00    	jle    89e0 <fwp_write+0xa10>
    84d9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    84e0:	55 55 55 
    84e3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    84e8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    84ef:	aa aa aa 
    84f2:	49 83 c1 01          	add    $0x1,%r9
    84f6:	eb 45                	jmp    853d <fwp_write+0x56d>
    84f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84ff:	00 
    8500:	be 01 00 00 00       	mov    $0x1,%esi
    8505:	b8 2d 00 00 00       	mov    $0x2d,%eax
    850a:	88 07                	mov    %al,(%rdi)
    850c:	48 89 e8             	mov    %rbp,%rax
    850f:	49 f7 e8             	imul   %r8
    8512:	48 89 e8             	mov    %rbp,%rax
    8515:	48 c1 f8 3f          	sar    $0x3f,%rax
    8519:	48 29 c2             	sub    %rax,%rdx
    851c:	48 85 c9             	test   %rcx,%rcx
    851f:	0f 95 c0             	setne  %al
    8522:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8526:	48 83 ef 01          	sub    $0x1,%rdi
    852a:	48 21 c5             	and    %rax,%rbp
    852d:	48 29 ea             	sub    %rbp,%rdx
    8530:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8534:	49 39 f9             	cmp    %rdi,%r9
    8537:	0f 84 a3 04 00 00    	je     89e0 <fwp_write+0xa10>
    853d:	48 89 e8             	mov    %rbp,%rax
    8540:	49 f7 e8             	imul   %r8
    8543:	48 89 e8             	mov    %rbp,%rax
    8546:	48 c1 f8 3f          	sar    $0x3f,%rax
    854a:	48 89 d1             	mov    %rdx,%rcx
    854d:	48 29 c1             	sub    %rax,%rcx
    8550:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8554:	48 89 e9             	mov    %rbp,%rcx
    8557:	48 29 c1             	sub    %rax,%rcx
    855a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    855e:	49 f7 e2             	mul    %r10
    8561:	b8 30 00 00 00       	mov    $0x30,%eax
    8566:	48 89 d6             	mov    %rdx,%rsi
    8569:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    856d:	48 d1 ee             	shr    $1,%rsi
    8570:	48 01 f2             	add    %rsi,%rdx
    8573:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8577:	48 29 d6             	sub    %rdx,%rsi
    857a:	74 8e                	je     850a <fwp_write+0x53a>
    857c:	48 83 fe 01          	cmp    $0x1,%rsi
    8580:	0f 85 7a ff ff ff    	jne    8500 <fwp_write+0x530>
    8586:	31 f6                	xor    %esi,%esi
    8588:	b8 2b 00 00 00       	mov    $0x2b,%eax
    858d:	e9 78 ff ff ff       	jmp    850a <fwp_write+0x53a>
    8592:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8598:	66 0f 6e cd          	movd   %ebp,%xmm1
    859c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    859f:	0f 8a c8 09 00 00    	jp     8f6d <fwp_write+0xf9d>
    85a5:	0f 28 c1             	movaps %xmm1,%xmm0
    85a8:	0f 54 05 81 65 00 00 	andps  0x6581(%rip),%xmm0        # eb30 <msg.4+0xb0>
    85af:	0f 2e 05 4e 5a 00 00 	ucomiss 0x5a4e(%rip),%xmm0        # e004 <_IO_stdin_used+0x4>
    85b6:	0f 87 24 08 00 00    	ja     8de0 <fwp_write+0xe10>
    85bc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85c0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    85c6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    85cd:	00 
    85ce:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    85d2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    85d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85de:	00 00 
    85e0:	44 89 ee             	mov    %r13d,%esi
    85e3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    85e8:	4c 89 e7             	mov    %r12,%rdi
    85eb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    85f0:	e8 cb be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    85f5:	31 f6                	xor    %esi,%esi
    85f7:	4c 89 e7             	mov    %r12,%rdi
    85fa:	e8 b1 ae ff ff       	call   34b0 <strtof@plt>
    85ff:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8604:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8607:	7a 02                	jp     860b <fwp_write+0x63b>
    8609:	74 1c                	je     8627 <fwp_write+0x657>
    860b:	41 83 c5 01          	add    $0x1,%r13d
    860f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8613:	75 cb                	jne    85e0 <fwp_write+0x610>
    8615:	be 09 00 00 00       	mov    $0x9,%esi
    861a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    861f:	4c 89 e7             	mov    %r12,%rdi
    8622:	e8 99 be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8627:	4c 89 e7             	mov    %r12,%rdi
    862a:	e8 01 bb ff ff       	call   4130 <fwp_finish_float>
    862f:	e9 1c fa ff ff       	jmp    8050 <fwp_write+0x80>
    8634:	0f 1f 40 00          	nopl   0x0(%rax)
    8638:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    863c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8640:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8647:	00 
    8648:	48 89 ef             	mov    %rbp,%rdi
    864b:	e8 f0 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8650:	48 89 ef             	mov    %rbp,%rdi
    8653:	e8 f8 ad ff ff       	call   3450 <strlen@plt>
    8658:	48 89 ee             	mov    %rbp,%rsi
    865b:	48 89 df             	mov    %rbx,%rdi
    865e:	48 89 c2             	mov    %rax,%rdx
    8661:	e8 0a ba ff ff       	call   4070 <buf_put>
    8666:	e9 fb f9 ff ff       	jmp    8066 <fwp_write+0x96>
    866b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8670:	ba 06 00 00 00       	mov    $0x6,%edx
    8675:	48 8d 35 1e 5b 00 00 	lea    0x5b1e(%rip),%rsi        # e19a <_IO_stdin_used+0x19a>
    867c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8682:	e8 e9 b9 ff ff       	call   4070 <buf_put>
    8687:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    868e:	ff ff 7f 
    8691:	48 23 55 00          	and    0x0(%rbp),%rdx
    8695:	0f 84 86 02 00 00    	je     8921 <fwp_write+0x951>
    869b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86a0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    86a4:	48 85 d2             	test   %rdx,%rdx
    86a7:	0f 84 ae 00 00 00    	je     875b <fwp_write+0x78b>
    86ad:	8b 0a                	mov    (%rdx),%ecx
    86af:	83 f9 1c             	cmp    $0x1c,%ecx
    86b2:	0f 84 58 06 00 00    	je     8d10 <fwp_write+0xd40>
    86b8:	83 f9 1b             	cmp    $0x1b,%ecx
    86bb:	0f 87 9a 00 00 00    	ja     875b <fwp_write+0x78b>
    86c1:	be 01 00 00 00       	mov    $0x1,%esi
    86c6:	48 d3 e6             	shl    %cl,%rsi
    86c9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    86cf:	0f 85 4b 04 00 00    	jne    8b20 <fwp_write+0xb50>
    86d5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    86db:	0f 85 0f 04 00 00    	jne    8af0 <fwp_write+0xb20>
    86e1:	83 e6 21             	and    $0x21,%esi
    86e4:	74 75                	je     875b <fwp_write+0x78b>
    86e6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    86eb:	48 85 ff             	test   %rdi,%rdi
    86ee:	79 07                	jns    86f7 <fwp_write+0x727>
    86f0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    86f4:	4c 01 ee             	add    %r13,%rsi
    86f7:	48 0f be 3e          	movsbq (%rsi),%rdi
    86fb:	85 c9                	test   %ecx,%ecx
    86fd:	40 0f b6 f7          	movzbl %dil,%esi
    8701:	48 0f 44 f7          	cmove  %rdi,%rsi
    8705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    870c:	00 00 00 00 
    8710:	31 c9                	xor    %ecx,%ecx
    8712:	48 89 df             	mov    %rbx,%rdi
    8715:	49 83 c5 01          	add    $0x1,%r13
    8719:	e8 b2 f8 ff ff       	call   7fd0 <fwp_write>
    871e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8725:	ff ff 7f 
    8728:	48 23 55 00          	and    0x0(%rbp),%rdx
    872c:	49 39 d5             	cmp    %rdx,%r13
    872f:	0f 83 ec 01 00 00    	jae    8921 <fwp_write+0x951>
    8735:	ba 02 00 00 00       	mov    $0x2,%edx
    873a:	48 89 df             	mov    %rbx,%rdi
    873d:	48 8d 35 53 5a 00 00 	lea    0x5a53(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8744:	e8 27 b9 ff ff       	call   4070 <buf_put>
    8749:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    874e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8752:	48 85 d2             	test   %rdx,%rdx
    8755:	0f 85 52 ff ff ff    	jne    86ad <fwp_write+0x6dd>
    875b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8760:	48 85 ff             	test   %rdi,%rdi
    8763:	0f 88 cf 05 00 00    	js     8d38 <fwp_write+0xd68>
    8769:	48 8b 31             	mov    (%rcx),%rsi
    876c:	eb a2                	jmp    8710 <fwp_write+0x740>
    876e:	66 90                	xchg   %ax,%ax
    8770:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8777:	00 
    8778:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    877f:	00 00 
    8781:	0f 85 1e fd ff ff    	jne    84a5 <fwp_write+0x4d5>
    8787:	ba 08 00 00 00       	mov    $0x8,%edx
    878c:	48 8d 35 d4 59 00 00 	lea    0x59d4(%rip),%rsi        # e167 <_IO_stdin_used+0x167>
    8793:	e9 4b fa ff ff       	jmp    81e3 <fwp_write+0x213>
    8798:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    879f:	00 
    87a0:	89 e8                	mov    %ebp,%eax
    87a2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    87a9:	76 03                	jbe    87ae <fwp_write+0x7de>
    87ab:	8b 45 00             	mov    0x0(%rbp),%eax
    87ae:	41 89 c6             	mov    %eax,%r14d
    87b1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    87b6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    87bb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    87bf:	4c 89 ef             	mov    %r13,%rdi
    87c2:	e8 89 ac ff ff       	call   3450 <strlen@plt>
    87c7:	4c 89 ee             	mov    %r13,%rsi
    87ca:	48 89 df             	mov    %rbx,%rdi
    87cd:	48 89 c2             	mov    %rax,%rdx
    87d0:	e8 9b b8 ff ff       	call   4070 <buf_put>
    87d5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    87da:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    87de:	85 f6                	test   %esi,%esi
    87e0:	0f 8e 80 f8 ff ff    	jle    8066 <fwp_write+0x96>
    87e6:	45 31 ed             	xor    %r13d,%r13d
    87e9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    87ee:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    87f3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    87f8:	ba 01 00 00 00       	mov    $0x1,%edx
    87fd:	4c 89 fe             	mov    %r15,%rsi
    8800:	48 89 04 24          	mov    %rax,(%rsp)
    8804:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8809:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    880d:	48 89 df             	mov    %rbx,%rdi
    8810:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8814:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8819:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    881e:	e8 4d b8 ff ff       	call   4070 <buf_put>
    8823:	41 8b 06             	mov    (%r14),%eax
    8826:	83 f8 0e             	cmp    $0xe,%eax
    8829:	0f 84 71 02 00 00    	je     8aa0 <fwp_write+0xad0>
    882f:	83 f8 10             	cmp    $0x10,%eax
    8832:	0f 84 38 02 00 00    	je     8a70 <fwp_write+0xaa0>
    8838:	83 f8 0a             	cmp    $0xa,%eax
    883b:	0f 84 7f 04 00 00    	je     8cc0 <fwp_write+0xcf0>
    8841:	0f 8f f9 00 00 00    	jg     8940 <fwp_write+0x970>
    8847:	83 f8 03             	cmp    $0x3,%eax
    884a:	0f 8f 50 04 00 00    	jg     8ca0 <fwp_write+0xcd0>
    8850:	85 c0                	test   %eax,%eax
    8852:	78 10                	js     8864 <fwp_write+0x894>
    8854:	48 8b 04 24          	mov    (%rsp),%rax
    8858:	48 c1 e8 3f          	shr    $0x3f,%rax
    885c:	85 c0                	test   %eax,%eax
    885e:	0f 85 f9 00 00 00    	jne    895d <fwp_write+0x98d>
    8864:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8869:	48 8b 34 24          	mov    (%rsp),%rsi
    886d:	31 c9                	xor    %ecx,%ecx
    886f:	48 89 df             	mov    %rbx,%rdi
    8872:	e8 59 f7 ff ff       	call   7fd0 <fwp_write>
    8877:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    887c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8881:	49 83 c5 01          	add    $0x1,%r13
    8885:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8889:	0f 8f 5f ff ff ff    	jg     87ee <fwp_write+0x81e>
    888f:	e9 d2 f7 ff ff       	jmp    8066 <fwp_write+0x96>
    8894:	0f 1f 40 00          	nopl   0x0(%rax)
    8898:	ba 06 00 00 00       	mov    $0x6,%edx
    889d:	48 8d 35 e9 58 00 00 	lea    0x58e9(%rip),%rsi        # e18d <_IO_stdin_used+0x18d>
    88a4:	45 31 ed             	xor    %r13d,%r13d
    88a7:	e8 c4 b7 ff ff       	call   4070 <buf_put>
    88ac:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    88b1:	75 19                	jne    88cc <fwp_write+0x8fc>
    88b3:	eb 6c                	jmp    8921 <fwp_write+0x951>
    88b5:	0f 1f 00             	nopl   (%rax)
    88b8:	ba 02 00 00 00       	mov    $0x2,%edx
    88bd:	48 8d 35 d3 58 00 00 	lea    0x58d3(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    88c4:	48 89 df             	mov    %rbx,%rdi
    88c7:	e8 a4 b7 ff ff       	call   4070 <buf_put>
    88cc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    88d2:	b9 00 02 00 00       	mov    $0x200,%ecx
    88d7:	31 c0                	xor    %eax,%eax
    88d9:	49 83 c5 01          	add    $0x1,%r13
    88dd:	4c 8d 05 b0 58 00 00 	lea    0x58b0(%rip),%r8        # e194 <_IO_stdin_used+0x194>
    88e4:	ba 02 00 00 00       	mov    $0x2,%edx
    88e9:	be 00 02 00 00       	mov    $0x200,%esi
    88ee:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88f5:	00 
    88f6:	e8 b5 aa ff ff       	call   33b0 <__snprintf_chk@plt>
    88fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8902:	00 
    8903:	e8 48 ab ff ff       	call   3450 <strlen@plt>
    8908:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    890f:	00 
    8910:	48 89 df             	mov    %rbx,%rdi
    8913:	48 89 c2             	mov    %rax,%rdx
    8916:	e8 55 b7 ff ff       	call   4070 <buf_put>
    891b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    891f:	72 97                	jb     88b8 <fwp_write+0x8e8>
    8921:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8926:	ba 01 00 00 00       	mov    $0x1,%edx
    892b:	48 89 df             	mov    %rbx,%rdi
    892e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8933:	e8 38 b7 ff ff       	call   4070 <buf_put>
    8938:	e9 29 f7 ff ff       	jmp    8066 <fwp_write+0x96>
    893d:	0f 1f 00             	nopl   (%rax)
    8940:	83 f8 0b             	cmp    $0xb,%eax
    8943:	0f 85 1b ff ff ff    	jne    8864 <fwp_write+0x894>
    8949:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    894e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8952:	83 e0 01             	and    $0x1,%eax
    8955:	85 c0                	test   %eax,%eax
    8957:	0f 84 07 ff ff ff    	je     8864 <fwp_write+0x894>
    895d:	4c 89 fe             	mov    %r15,%rsi
    8960:	48 89 df             	mov    %rbx,%rdi
    8963:	ba 01 00 00 00       	mov    $0x1,%edx
    8968:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    896d:	e8 fe b6 ff ff       	call   4070 <buf_put>
    8972:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8977:	48 8b 34 24          	mov    (%rsp),%rsi
    897b:	31 c9                	xor    %ecx,%ecx
    897d:	48 89 df             	mov    %rbx,%rdi
    8980:	e8 4b f6 ff ff       	call   7fd0 <fwp_write>
    8985:	ba 01 00 00 00       	mov    $0x1,%edx
    898a:	4c 89 fe             	mov    %r15,%rsi
    898d:	48 89 df             	mov    %rbx,%rdi
    8990:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8995:	e8 d6 b6 ff ff       	call   4070 <buf_put>
    899a:	e9 d8 fe ff ff       	jmp    8877 <fwp_write+0x8a7>
    899f:	90                   	nop
    89a0:	ba 01 00 00 00       	mov    $0x1,%edx
    89a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89aa:	48 89 df             	mov    %rbx,%rdi
    89ad:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    89b2:	e8 b9 b6 ff ff       	call   4070 <buf_put>
    89b7:	e9 aa f6 ff ff       	jmp    8066 <fwp_write+0x96>
    89bc:	0f 1f 40 00          	nopl   0x0(%rax)
    89c0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89c5:	ba 01 00 00 00       	mov    $0x1,%edx
    89ca:	48 89 df             	mov    %rbx,%rdi
    89cd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    89d2:	e8 99 b6 ff ff       	call   4070 <buf_put>
    89d7:	e9 8a f6 ff ff       	jmp    8066 <fwp_write+0x96>
    89dc:	0f 1f 40 00          	nopl   0x0(%rax)
    89e0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    89e4:	48 8b 13             	mov    (%rbx),%rdx
    89e7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    89ec:	48 89 43 08          	mov    %rax,0x8(%rbx)
    89f0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    89f4:	e9 6d f6 ff ff       	jmp    8066 <fwp_write+0x96>
    89f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a00:	ba 02 00 00 00       	mov    $0x2,%edx
    8a05:	48 8d 35 8b 57 00 00 	lea    0x578b(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8a0c:	48 89 df             	mov    %rbx,%rdi
    8a0f:	e8 5c b6 ff ff       	call   4070 <buf_put>
    8a14:	e9 72 f8 ff ff       	jmp    828b <fwp_write+0x2bb>
    8a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a20:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a25:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8a2a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8a2e:	48 89 f7             	mov    %rsi,%rdi
    8a31:	48 89 34 24          	mov    %rsi,(%rsp)
    8a35:	e8 16 aa ff ff       	call   3450 <strlen@plt>
    8a3a:	48 8b 34 24          	mov    (%rsp),%rsi
    8a3e:	48 89 df             	mov    %rbx,%rdi
    8a41:	48 89 c2             	mov    %rax,%rdx
    8a44:	e8 27 b6 ff ff       	call   4070 <buf_put>
    8a49:	ba 03 00 00 00       	mov    $0x3,%edx
    8a4e:	48 8d 35 65 57 00 00 	lea    0x5765(%rip),%rsi        # e1ba <_IO_stdin_used+0x1ba>
    8a55:	48 89 df             	mov    %rbx,%rdi
    8a58:	e8 13 b6 ff ff       	call   4070 <buf_put>
    8a5d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8a62:	e9 35 f8 ff ff       	jmp    829c <fwp_write+0x2cc>
    8a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a6e:	00 00 
    8a70:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8a75:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8a79:	48 85 ff             	test   %rdi,%rdi
    8a7c:	0f 84 e2 fd ff ff    	je     8864 <fwp_write+0x894>
    8a82:	48 8d 35 1b 57 00 00 	lea    0x571b(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    8a89:	e8 a2 aa ff ff       	call   3530 <strcmp@plt>
    8a8e:	85 c0                	test   %eax,%eax
    8a90:	0f 95 c0             	setne  %al
    8a93:	0f b6 c0             	movzbl %al,%eax
    8a96:	e9 c1 fd ff ff       	jmp    885c <fwp_write+0x88c>
    8a9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8aa0:	31 c0                	xor    %eax,%eax
    8aa2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8aa9:	00 
    8aaa:	0f 97 c0             	seta   %al
    8aad:	e9 aa fd ff ff       	jmp    885c <fwp_write+0x88c>
    8ab2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ab8:	48 89 df             	mov    %rbx,%rdi
    8abb:	ba 02 00 00 00       	mov    $0x2,%edx
    8ac0:	48 8d 35 da 56 00 00 	lea    0x56da(%rip),%rsi        # e1a1 <_IO_stdin_used+0x1a1>
    8ac7:	e8 a4 b5 ff ff       	call   4070 <buf_put>
    8acc:	4c 89 e8             	mov    %r13,%rax
    8acf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8ad4:	31 c9                	xor    %ecx,%ecx
    8ad6:	48 c1 e0 04          	shl    $0x4,%rax
    8ada:	48 89 df             	mov    %rbx,%rdi
    8add:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8ae2:	e8 e9 f4 ff ff       	call   7fd0 <fwp_write>
    8ae7:	e9 5e f6 ff ff       	jmp    814a <fwp_write+0x17a>
    8aec:	0f 1f 40 00          	nopl   0x0(%rax)
    8af0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8af5:	48 85 ff             	test   %rdi,%rdi
    8af8:	79 0c                	jns    8b06 <fwp_write+0xb36>
    8afa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8b01:	00 
    8b02:	48 03 75 10          	add    0x10(%rbp),%rsi
    8b06:	48 63 3e             	movslq (%rsi),%rdi
    8b09:	83 f9 02             	cmp    $0x2,%ecx
    8b0c:	89 fe                	mov    %edi,%esi
    8b0e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b12:	e9 f9 fb ff ff       	jmp    8710 <fwp_write+0x740>
    8b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b1e:	00 00 
    8b20:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8b25:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8b2a:	48 85 ff             	test   %rdi,%rdi
    8b2d:	0f 88 0f 03 00 00    	js     8e42 <fwp_write+0xe72>
    8b33:	49 0f bf 38          	movswq (%r8),%rdi
    8b37:	83 f9 01             	cmp    $0x1,%ecx
    8b3a:	0f b7 f7             	movzwl %di,%esi
    8b3d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b41:	e9 ca fb ff ff       	jmp    8710 <fwp_write+0x740>
    8b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b4d:	00 00 00 
    8b50:	ba 01 00 00 00       	mov    $0x1,%edx
    8b55:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b5a:	48 83 c5 08          	add    $0x8,%rbp
    8b5e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8b63:	e8 08 b5 ff ff       	call   4070 <buf_put>
    8b68:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8b6d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8b72:	4d 85 ed             	test   %r13,%r13
    8b75:	75 46                	jne    8bbd <fwp_write+0xbed>
    8b77:	e9 04 01 00 00       	jmp    8c80 <fwp_write+0xcb0>
    8b7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b80:	41 80 f9 09          	cmp    $0x9,%r9b
    8b84:	0f 84 d6 00 00 00    	je     8c60 <fwp_write+0xc90>
    8b8a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8b8e:	0f 85 9c 00 00 00    	jne    8c30 <fwp_write+0xc60>
    8b94:	ba 02 00 00 00       	mov    $0x2,%edx
    8b99:	48 8d 35 dd 55 00 00 	lea    0x55dd(%rip),%rsi        # e17d <_IO_stdin_used+0x17d>
    8ba0:	48 89 df             	mov    %rbx,%rdi
    8ba3:	e8 c8 b4 ff ff       	call   4070 <buf_put>
    8ba8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8baf:	00 
    8bb0:	48 83 c5 01          	add    $0x1,%rbp
    8bb4:	49 39 ec             	cmp    %rbp,%r12
    8bb7:	0f 84 c3 00 00 00    	je     8c80 <fwp_write+0xcb0>
    8bbd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8bc2:	41 80 f9 0d          	cmp    $0xd,%r9b
    8bc6:	74 28                	je     8bf0 <fwp_write+0xc20>
    8bc8:	7e b6                	jle    8b80 <fwp_write+0xbb0>
    8bca:	41 80 f9 22          	cmp    $0x22,%r9b
    8bce:	74 40                	je     8c10 <fwp_write+0xc40>
    8bd0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8bd4:	75 5a                	jne    8c30 <fwp_write+0xc60>
    8bd6:	ba 02 00 00 00       	mov    $0x2,%edx
    8bdb:	48 8d 35 98 55 00 00 	lea    0x5598(%rip),%rsi        # e17a <_IO_stdin_used+0x17a>
    8be2:	48 89 df             	mov    %rbx,%rdi
    8be5:	e8 86 b4 ff ff       	call   4070 <buf_put>
    8bea:	eb c4                	jmp    8bb0 <fwp_write+0xbe0>
    8bec:	0f 1f 40 00          	nopl   0x0(%rax)
    8bf0:	ba 02 00 00 00       	mov    $0x2,%edx
    8bf5:	48 8d 35 87 55 00 00 	lea    0x5587(%rip),%rsi        # e183 <_IO_stdin_used+0x183>
    8bfc:	48 89 df             	mov    %rbx,%rdi
    8bff:	e8 6c b4 ff ff       	call   4070 <buf_put>
    8c04:	eb aa                	jmp    8bb0 <fwp_write+0xbe0>
    8c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c0d:	00 00 00 
    8c10:	ba 02 00 00 00       	mov    $0x2,%edx
    8c15:	48 8d 35 5b 55 00 00 	lea    0x555b(%rip),%rsi        # e177 <_IO_stdin_used+0x177>
    8c1c:	48 89 df             	mov    %rbx,%rdi
    8c1f:	e8 4c b4 ff ff       	call   4070 <buf_put>
    8c24:	eb 8a                	jmp    8bb0 <fwp_write+0xbe0>
    8c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c2d:	00 00 00 
    8c30:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8c34:	0f 86 2e 01 00 00    	jbe    8d68 <fwp_write+0xd98>
    8c3a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8c3e:	0f 84 24 01 00 00    	je     8d68 <fwp_write+0xd98>
    8c44:	ba 01 00 00 00       	mov    $0x1,%edx
    8c49:	4c 89 fe             	mov    %r15,%rsi
    8c4c:	48 89 df             	mov    %rbx,%rdi
    8c4f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8c54:	e8 17 b4 ff ff       	call   4070 <buf_put>
    8c59:	e9 52 ff ff ff       	jmp    8bb0 <fwp_write+0xbe0>
    8c5e:	66 90                	xchg   %ax,%ax
    8c60:	ba 02 00 00 00       	mov    $0x2,%edx
    8c65:	48 8d 35 14 55 00 00 	lea    0x5514(%rip),%rsi        # e180 <_IO_stdin_used+0x180>
    8c6c:	48 89 df             	mov    %rbx,%rdi
    8c6f:	e8 fc b3 ff ff       	call   4070 <buf_put>
    8c74:	e9 37 ff ff ff       	jmp    8bb0 <fwp_write+0xbe0>
    8c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c80:	ba 01 00 00 00       	mov    $0x1,%edx
    8c85:	4c 89 fe             	mov    %r15,%rsi
    8c88:	48 89 df             	mov    %rbx,%rdi
    8c8b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8c90:	e8 db b3 ff ff       	call   4070 <buf_put>
    8c95:	e9 cc f3 ff ff       	jmp    8066 <fwp_write+0x96>
    8c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ca0:	83 f8 04             	cmp    $0x4,%eax
    8ca3:	0f 85 bb fb ff ff    	jne    8864 <fwp_write+0x894>
    8ca9:	48 8b 04 24          	mov    (%rsp),%rax
    8cad:	48 8b 40 08          	mov    0x8(%rax),%rax
    8cb1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8cb6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8cba:	e9 96 fc ff ff       	jmp    8955 <fwp_write+0x985>
    8cbf:	90                   	nop
    8cc0:	8b 0c 24             	mov    (%rsp),%ecx
    8cc3:	31 c0                	xor    %eax,%eax
    8cc5:	85 c9                	test   %ecx,%ecx
    8cc7:	0f 98 c0             	sets   %al
    8cca:	e9 86 fc ff ff       	jmp    8955 <fwp_write+0x985>
    8ccf:	90                   	nop
    8cd0:	48 f7 d8             	neg    %rax
    8cd3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8cda:	00 
    8cdb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8ce2:	2d 
    8ce3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8cea:	00 
    8ceb:	48 83 d2 00          	adc    $0x0,%rdx
    8cef:	48 89 c6             	mov    %rax,%rsi
    8cf2:	48 f7 da             	neg    %rdx
    8cf5:	e8 46 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8cfa:	e9 51 f3 ff ff       	jmp    8050 <fwp_write+0x80>
    8cff:	90                   	nop
    8d00:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8d05:	e9 c3 f5 ff ff       	jmp    82cd <fwp_write+0x2fd>
    8d0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d10:	4c 89 e9             	mov    %r13,%rcx
    8d13:	48 c1 e1 04          	shl    $0x4,%rcx
    8d17:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8d1c:	48 85 ff             	test   %rdi,%rdi
    8d1f:	0f 89 eb f9 ff ff    	jns    8710 <fwp_write+0x740>
    8d25:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d29:	48 89 ce             	mov    %rcx,%rsi
    8d2c:	e9 df f9 ff ff       	jmp    8710 <fwp_write+0x740>
    8d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d38:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8d3f:	00 
    8d40:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d44:	e9 20 fa ff ff       	jmp    8769 <fwp_write+0x799>
    8d49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d50:	ba 02 00 00 00       	mov    $0x2,%edx
    8d55:	48 8d 35 e6 53 00 00 	lea    0x53e6(%rip),%rsi        # e142 <_IO_stdin_used+0x142>
    8d5c:	e9 2d f7 ff ff       	jmp    848e <fwp_write+0x4be>
    8d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d68:	4c 8d 05 17 54 00 00 	lea    0x5417(%rip),%r8        # e186 <_IO_stdin_used+0x186>
    8d6f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8d74:	31 c0                	xor    %eax,%eax
    8d76:	ba 02 00 00 00       	mov    $0x2,%edx
    8d7b:	be 10 00 00 00       	mov    $0x10,%esi
    8d80:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d87:	00 
    8d88:	e8 23 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8d8d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d94:	00 
    8d95:	e8 b6 a6 ff ff       	call   3450 <strlen@plt>
    8d9a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8da1:	00 
    8da2:	48 89 df             	mov    %rbx,%rdi
    8da5:	48 89 c2             	mov    %rax,%rdx
    8da8:	e8 c3 b2 ff ff       	call   4070 <buf_put>
    8dad:	e9 fe fd ff ff       	jmp    8bb0 <fwp_write+0xbe0>
    8db2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8db8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8dbc:	48 8d 35 79 53 00 00 	lea    0x5379(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8dc3:	48 8d 05 71 53 00 00 	lea    0x5371(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8dca:	4c 89 e7             	mov    %r12,%rdi
    8dcd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8dd1:	48 0f 46 f0          	cmovbe %rax,%rsi
    8dd5:	e8 16 a6 ff ff       	call   33f0 <strcpy@plt>
    8dda:	e9 71 f2 ff ff       	jmp    8050 <fwp_write+0x80>
    8ddf:	90                   	nop
    8de0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8de4:	48 8d 35 51 53 00 00 	lea    0x5351(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8deb:	48 8d 05 49 53 00 00 	lea    0x5349(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8df2:	0f 2f c8             	comiss %xmm0,%xmm1
    8df5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8dfc:	00 
    8dfd:	4c 89 e7             	mov    %r12,%rdi
    8e00:	48 0f 46 f0          	cmovbe %rax,%rsi
    8e04:	e8 e7 a5 ff ff       	call   33f0 <strcpy@plt>
    8e09:	e9 42 f2 ff ff       	jmp    8050 <fwp_write+0x80>
    8e0e:	66 90                	xchg   %ax,%ax
    8e10:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8e15:	45 85 c0             	test   %r8d,%r8d
    8e18:	75 34                	jne    8e4e <fwp_write+0xe7e>
    8e1a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e21:	00 
    8e22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e29:	00 00 
    8e2b:	0f 85 74 f6 ff ff    	jne    84a5 <fwp_write+0x4d5>
    8e31:	ba 02 00 00 00       	mov    $0x2,%edx
    8e36:	48 8d 35 7a 53 00 00 	lea    0x537a(%rip),%rsi        # e1b7 <_IO_stdin_used+0x1b7>
    8e3d:	e9 a1 f3 ff ff       	jmp    81e3 <fwp_write+0x213>
    8e42:	48 03 75 10          	add    0x10(%rbp),%rsi
    8e46:	49 89 f0             	mov    %rsi,%r8
    8e49:	e9 e5 fc ff ff       	jmp    8b33 <fwp_write+0xb63>
    8e4e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8e53:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e58:	85 ff                	test   %edi,%edi
    8e5a:	0f 84 fa f3 ff ff    	je     825a <fwp_write+0x28a>
    8e60:	ba 01 00 00 00       	mov    $0x1,%edx
    8e65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e6a:	48 89 df             	mov    %rbx,%rdi
    8e6d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8e72:	e8 f9 b1 ff ff       	call   4070 <buf_put>
    8e77:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8e7c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e81:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8e87:	85 c0                	test   %eax,%eax
    8e89:	0f 8f f0 f3 ff ff    	jg     827f <fwp_write+0x2af>
    8e8f:	e9 34 f4 ff ff       	jmp    82c8 <fwp_write+0x2f8>
    8e94:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8e98:	49 89 c5             	mov    %rax,%r13
    8e9b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8ea0:	49 89 c4             	mov    %rax,%r12
    8ea3:	49 c1 fd 3f          	sar    $0x3f,%r13
    8ea7:	4c 09 e8             	or     %r13,%rax
    8eaa:	0f 84 a7 00 00 00    	je     8f57 <fwp_write+0xf87>
    8eb0:	48 8d 2d 09 74 00 00 	lea    0x7409(%rip),%rbp        # 102c0 <units.0>
    8eb7:	4d 89 e7             	mov    %r12,%r15
    8eba:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8ebe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8ec3:	4c 89 ff             	mov    %r15,%rdi
    8ec6:	4c 89 ee             	mov    %r13,%rsi
    8ec9:	44 89 0c 24          	mov    %r9d,(%rsp)
    8ecd:	48 99                	cqto
    8ecf:	48 89 d1             	mov    %rdx,%rcx
    8ed2:	48 89 c2             	mov    %rax,%rdx
    8ed5:	e8 36 4e 00 00       	call   dd10 <__divmodti4>
    8eda:	44 8b 0c 24          	mov    (%rsp),%r9d
    8ede:	48 89 c1             	mov    %rax,%rcx
    8ee1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8ee6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8eeb:	0f 84 94 00 00 00    	je     8f85 <fwp_write+0xfb5>
    8ef1:	41 83 c1 01          	add    $0x1,%r9d
    8ef5:	48 83 c5 10          	add    $0x10,%rbp
    8ef9:	41 83 f9 05          	cmp    $0x5,%r9d
    8efd:	75 bb                	jne    8eba <fwp_write+0xeea>
    8eff:	4d 85 ed             	test   %r13,%r13
    8f02:	79 53                	jns    8f57 <fwp_write+0xf87>
    8f04:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8f09:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8f0e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8f13:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f18:	48 99                	cqto
    8f1a:	48 f7 d8             	neg    %rax
    8f1d:	48 83 d2 00          	adc    $0x0,%rdx
    8f21:	48 89 c6             	mov    %rax,%rsi
    8f24:	48 f7 da             	neg    %rdx
    8f27:	e8 14 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f2c:	49 89 e8             	mov    %rbp,%r8
    8f2f:	ba 00 02 00 00       	mov    $0x200,%edx
    8f34:	be 02 00 00 00       	mov    $0x2,%esi
    8f39:	31 c0                	xor    %eax,%eax
    8f3b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f42:	00 
    8f43:	48 8d 0d 68 52 00 00 	lea    0x5268(%rip),%rcx        # e1b2 <_IO_stdin_used+0x1b2>
    8f4a:	4c 89 e7             	mov    %r12,%rdi
    8f4d:	e8 8e a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8f52:	e9 f9 f0 ff ff       	jmp    8050 <fwp_write+0x80>
    8f57:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f5c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    8f61:	31 d2                	xor    %edx,%edx
    8f63:	48 89 ef             	mov    %rbp,%rdi
    8f66:	e8 d5 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f6b:	eb bf                	jmp    8f2c <fwp_write+0xf5c>
    8f6d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    8f74:	4e 61 4e 00 
    8f78:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f7f:	00 
    8f80:	e9 cb f0 ff ff       	jmp    8050 <fwp_write+0x80>
    8f85:	44 89 0c 24          	mov    %r9d,(%rsp)
    8f89:	48 89 c8             	mov    %rcx,%rax
    8f8c:	48 85 d2             	test   %rdx,%rdx
    8f8f:	78 51                	js     8fe2 <fwp_write+0x1012>
    8f91:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f96:	48 89 c6             	mov    %rax,%rsi
    8f99:	48 89 ef             	mov    %rbp,%rdi
    8f9c:	e8 9f aa ff ff       	call   3a40 <fwp_fmt_u128>
    8fa1:	44 8b 0c 24          	mov    (%rsp),%r9d
    8fa5:	49 63 c1             	movslq %r9d,%rax
    8fa8:	49 89 e8             	mov    %rbp,%r8
    8fab:	ba 00 02 00 00       	mov    $0x200,%edx
    8fb0:	be 02 00 00 00       	mov    $0x2,%esi
    8fb5:	48 c1 e0 04          	shl    $0x4,%rax
    8fb9:	48 8d 3d 00 73 00 00 	lea    0x7300(%rip),%rdi        # 102c0 <units.0>
    8fc0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8fc7:	00 
    8fc8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    8fcc:	48 8d 0d da 51 00 00 	lea    0x51da(%rip),%rcx        # e1ad <_IO_stdin_used+0x1ad>
    8fd3:	4c 89 e7             	mov    %r12,%rdi
    8fd6:	31 c0                	xor    %eax,%eax
    8fd8:	e8 03 a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8fdd:	e9 6e f0 ff ff       	jmp    8050 <fwp_write+0x80>
    8fe2:	48 f7 d8             	neg    %rax
    8fe5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8fea:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8fef:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8ff4:	48 83 d2 00          	adc    $0x0,%rdx
    8ff8:	48 89 c6             	mov    %rax,%rsi
    8ffb:	48 f7 da             	neg    %rdx
    8ffe:	e8 3d aa ff ff       	call   3a40 <fwp_fmt_u128>
    9003:	44 8b 0c 24          	mov    (%rsp),%r9d
    9007:	eb 9c                	jmp    8fa5 <fwp_write+0xfd5>
    9009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009010 <fwp_hof0.constprop.0>:
    9010:	41 57                	push   %r15
    9012:	41 56                	push   %r14
    9014:	41 55                	push   %r13
    9016:	41 54                	push   %r12
    9018:	55                   	push   %rbp
    9019:	53                   	push   %rbx
    901a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9021:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9028:	00 00 
    902a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9031:	00 
    9032:	31 c0                	xor    %eax,%eax
    9034:	48 85 f6             	test   %rsi,%rsi
    9037:	0f 84 da 0e 00 00    	je     9f17 <fwp_hof0.constprop.0+0xf07>
    903d:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    9042:	48 8d 1d 17 97 01 00 	lea    0x19717(%rip),%rbx        # 22760 <fwp_heap>
    9049:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    904e:	66 90                	xchg   %ax,%ax
    9050:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9057:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    905c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9063:	48 c1 e2 10          	shl    $0x10,%rdx
    9067:	48 39 d0             	cmp    %rdx,%rax
    906a:	73 5d                	jae    90c9 <fwp_hof0.constprop.0+0xb9>
    906c:	48 89 c2             	mov    %rax,%rdx
    906f:	48 c1 ea 10          	shr    $0x10,%rdx
    9073:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9077:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    907e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9082:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9086:	48 85 ff             	test   %rdi,%rdi
    9089:	74 3e                	je     90c9 <fwp_hof0.constprop.0+0xb9>
    908b:	0f b6 0a             	movzbl (%rdx),%ecx
    908e:	80 f9 02             	cmp    $0x2,%cl
    9091:	0f 84 19 15 00 00    	je     a5b0 <fwp_hof0.constprop.0+0x15a0>
    9097:	80 f9 01             	cmp    $0x1,%cl
    909a:	75 2d                	jne    90c9 <fwp_hof0.constprop.0+0xb9>
    909c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    909f:	0f b7 c0             	movzwl %ax,%eax
    90a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90a5:	48 0f af c1          	imul   %rcx,%rax
    90a9:	48 c1 e8 20          	shr    $0x20,%rax
    90ad:	48 39 d0             	cmp    %rdx,%rax
    90b0:	73 17                	jae    90c9 <fwp_hof0.constprop.0+0xb9>
    90b2:	48 01 c7             	add    %rax,%rdi
    90b5:	0f b6 07             	movzbl (%rdi),%eax
    90b8:	84 c0                	test   %al,%al
    90ba:	74 0d                	je     90c9 <fwp_hof0.constprop.0+0xb9>
    90bc:	3c fd                	cmp    $0xfd,%al
    90be:	0f 87 f8 16 00 00    	ja     a7bc <fwp_hof0.constprop.0+0x17ac>
    90c4:	83 c0 01             	add    $0x1,%eax
    90c7:	88 07                	mov    %al,(%rdi)
    90c9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    90ce:	45 31 c0             	xor    %r8d,%r8d
    90d1:	48 c7 44 24 20 c6 00 	movq   $0xc6,0x20(%rsp)
    90d8:	00 00 
    90da:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    90df:	4d 89 c7             	mov    %r8,%r15
    90e2:	4d 85 c0             	test   %r8,%r8
    90e5:	0f 85 65 a6 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    90eb:	48 8b 05 06 b3 01 00 	mov    0x1b306(%rip),%rax        # 243f8 <fwp_cleanups>
    90f2:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    90f9:	4c 8d 35 00 d8 ff ff 	lea    -0x2800(%rip),%r14        # 6900 <fwp_tape_scope_release>
    9100:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9107:	ff 
    9108:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
    910f:	00 
    9110:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9117:	00 
    9118:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    911d:	48 c1 e2 10          	shl    $0x10,%rdx
    9121:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9126:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    912d:	00 
    912e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9135:	00 
    9136:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    913b:	48 89 05 b6 b2 01 00 	mov    %rax,0x1b2b6(%rip)        # 243f8 <fwp_cleanups>
    9142:	48 8d 05 c7 8e 00 00 	lea    0x8ec7(%rip),%rax        # 12010 <fc37>
    9149:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9150:	48 39 d0             	cmp    %rdx,%rax
    9153:	73 5d                	jae    91b2 <fwp_hof0.constprop.0+0x1a2>
    9155:	48 89 c2             	mov    %rax,%rdx
    9158:	48 c1 ea 10          	shr    $0x10,%rdx
    915c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9160:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9167:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    916b:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    916f:	48 85 ff             	test   %rdi,%rdi
    9172:	74 3e                	je     91b2 <fwp_hof0.constprop.0+0x1a2>
    9174:	0f b6 0a             	movzbl (%rdx),%ecx
    9177:	80 f9 02             	cmp    $0x2,%cl
    917a:	0f 84 a0 12 00 00    	je     a420 <fwp_hof0.constprop.0+0x1410>
    9180:	80 f9 01             	cmp    $0x1,%cl
    9183:	75 2d                	jne    91b2 <fwp_hof0.constprop.0+0x1a2>
    9185:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9188:	0f b7 c0             	movzwl %ax,%eax
    918b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    918e:	48 0f af c1          	imul   %rcx,%rax
    9192:	48 c1 e8 20          	shr    $0x20,%rax
    9196:	48 39 d0             	cmp    %rdx,%rax
    9199:	73 17                	jae    91b2 <fwp_hof0.constprop.0+0x1a2>
    919b:	48 01 c7             	add    %rax,%rdi
    919e:	0f b6 07             	movzbl (%rdi),%eax
    91a1:	84 c0                	test   %al,%al
    91a3:	74 0d                	je     91b2 <fwp_hof0.constprop.0+0x1a2>
    91a5:	3c fd                	cmp    $0xfd,%al
    91a7:	0f 87 4f 15 00 00    	ja     a6fc <fwp_hof0.constprop.0+0x16ec>
    91ad:	83 c0 01             	add    $0x1,%eax
    91b0:	88 07                	mov    %al,(%rdi)
    91b2:	48 8d 3d 57 8e 00 00 	lea    0x8e57(%rip),%rdi        # 12010 <fc37>
    91b9:	e8 12 d4 ff ff       	call   65d0 <fwp_closure_drop>
    91be:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    91c3:	48 85 c0             	test   %rax,%rax
    91c6:	0f 84 45 14 00 00    	je     a611 <fwp_hof0.constprop.0+0x1601>
    91cc:	31 d2                	xor    %edx,%edx
    91ce:	66 90                	xchg   %ax,%ax
    91d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    91d4:	48 83 c2 01          	add    $0x1,%rdx
    91d8:	48 85 c0             	test   %rax,%rax
    91db:	75 f3                	jne    91d0 <fwp_hof0.constprop.0+0x1c0>
    91dd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    91e4:	0f 87 10 16 00 00    	ja     a7fa <fwp_hof0.constprop.0+0x17ea>
    91ea:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    91ef:	8b 35 6b 8e 00 00    	mov    0x8e6b(%rip),%esi        # 12060 <registered_finish.1>
    91f5:	85 f6                	test   %esi,%esi
    91f7:	0f 84 e3 11 00 00    	je     a3e0 <fwp_hof0.constprop.0+0x13d0>
    91fd:	4c 8b 2d d4 8e 01 00 	mov    0x18ed4(%rip),%r13        # 220d8 <fwp_tape_next_slot>
    9204:	4c 8b 25 dd 8e 01 00 	mov    0x18edd(%rip),%r12        # 220e8 <fwp_ntapes>
    920b:	4d 39 ec             	cmp    %r13,%r12
    920e:	0f 8e dc 0d 00 00    	jle    9ff0 <fwp_hof0.constprop.0+0xfe0>
    9214:	49 6b c5 68          	imul   $0x68,%r13,%rax
    9218:	48 03 05 d1 8e 01 00 	add    0x18ed1(%rip),%rax        # 220f0 <fwp_tapes>
    921f:	90                   	nop
    9220:	8b 48 04             	mov    0x4(%rax),%ecx
    9223:	85 c9                	test   %ecx,%ecx
    9225:	75 0c                	jne    9233 <fwp_hof0.constprop.0+0x223>
    9227:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    922d:	0f 86 bd 0d 00 00    	jbe    9ff0 <fwp_hof0.constprop.0+0xfe0>
    9233:	49 83 c5 01          	add    $0x1,%r13
    9237:	48 83 c0 68          	add    $0x68,%rax
    923b:	4d 39 ec             	cmp    %r13,%r12
    923e:	75 e0                	jne    9220 <fwp_hof0.constprop.0+0x210>
    9240:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9247:	0f 8f 2f 16 00 00    	jg     a87c <fwp_hof0.constprop.0+0x186c>
    924d:	4c 39 25 8c 8e 01 00 	cmp    %r12,0x18e8c(%rip)        # 220e0 <fwp_tapes_cap>
    9254:	48 8b 2d 95 8e 01 00 	mov    0x18e95(%rip),%rbp        # 220f0 <fwp_tapes>
    925b:	75 49                	jne    92a6 <fwp_hof0.constprop.0+0x296>
    925d:	4d 85 e4             	test   %r12,%r12
    9260:	0f 84 10 14 00 00    	je     a676 <fwp_hof0.constprop.0+0x1666>
    9266:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    926a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    926f:	49 39 c5             	cmp    %rax,%r13
    9272:	4c 0f 4f e8          	cmovg  %rax,%r13
    9276:	49 6b f5 68          	imul   $0x68,%r13,%rsi
    927a:	48 89 ef             	mov    %rbp,%rdi
    927d:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9282:	e8 49 a3 ff ff       	call   35d0 <realloc@plt>
    9287:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    928c:	48 85 c0             	test   %rax,%rax
    928f:	48 89 c5             	mov    %rax,%rbp
    9292:	0f 84 f0 15 00 00    	je     a888 <fwp_hof0.constprop.0+0x1878>
    9298:	48 89 05 51 8e 01 00 	mov    %rax,0x18e51(%rip)        # 220f0 <fwp_tapes>
    929f:	4c 89 2d 3a 8e 01 00 	mov    %r13,0x18e3a(%rip)        # 220e0 <fwp_tapes_cap>
    92a6:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    92aa:	31 c0                	xor    %eax,%eax
    92ac:	4d 89 e5             	mov    %r12,%r13
    92af:	48 01 e9             	add    %rbp,%rcx
    92b2:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    92b6:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    92bd:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    92c1:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    92c8:	00 
    92c9:	48 29 f9             	sub    %rdi,%rcx
    92cc:	83 c1 68             	add    $0x68,%ecx
    92cf:	c1 e9 03             	shr    $0x3,%ecx
    92d2:	f3 48 ab             	rep stos %rax,(%rdi)
    92d5:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    92da:	48 89 05 07 8e 01 00 	mov    %rax,0x18e07(%rip)        # 220e8 <fwp_ntapes>
    92e1:	4d 6b e5 68          	imul   $0x68,%r13,%r12
    92e5:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    92e9:	48 8d 3d cf 4d 00 00 	lea    0x4dcf(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    92f0:	0f 29 04 24          	movaps %xmm0,(%rsp)
    92f4:	49 01 ec             	add    %rbp,%r12
    92f7:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    92fe:	00 00 
    9300:	e8 9b a0 ff ff       	call   33a0 <getenv@plt>
    9305:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    930a:	48 85 c0             	test   %rax,%rax
    930d:	0f 84 f5 0c 00 00    	je     a008 <fwp_hof0.constprop.0+0xff8>
    9313:	80 38 30             	cmpb   $0x30,(%rax)
    9316:	0f 85 ec 0c 00 00    	jne    a008 <fwp_hof0.constprop.0+0xff8>
    931c:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9320:	0f 85 e2 0c 00 00    	jne    a008 <fwp_hof0.constprop.0+0xff8>
    9326:	41 8b 04 24          	mov    (%r12),%eax
    932a:	49 8d 75 01          	lea    0x1(%r13),%rsi
    932e:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    9335:	00 00 
    9337:	48 89 35 9a 8d 01 00 	mov    %rsi,0x18d9a(%rip)        # 220d8 <fwp_tape_next_slot>
    933e:	8d 48 01             	lea    0x1(%rax),%ecx
    9341:	48 8b 05 58 57 00 00 	mov    0x5758(%rip),%rax        # eaa0 <msg.4+0x20>
    9348:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    934f:	00 00 
    9351:	41 89 0c 24          	mov    %ecx,(%r12)
    9355:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    935a:	48 8b 05 97 b0 01 00 	mov    0x1b097(%rip),%rax        # 243f8 <fwp_cleanups>
    9361:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    9367:	48 85 c0             	test   %rax,%rax
    936a:	75 20                	jne    938c <fwp_hof0.constprop.0+0x37c>
    936c:	e9 af 14 00 00       	jmp    a820 <fwp_hof0.constprop.0+0x1810>
    9371:	0f 1f 40 00          	nopl   0x0(%rax)
    9375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    937c:	00 00 00 00 
    9380:	48 8b 00             	mov    (%rax),%rax
    9383:	48 85 c0             	test   %rax,%rax
    9386:	0f 84 94 14 00 00    	je     a820 <fwp_hof0.constprop.0+0x1810>
    938c:	4c 39 70 08          	cmp    %r14,0x8(%rax)
    9390:	75 ee                	jne    9380 <fwp_hof0.constprop.0+0x370>
    9392:	4c 8b 48 10          	mov    0x10(%rax),%r9
    9396:	44 89 ef             	mov    %r13d,%edi
    9399:	49 63 01             	movslq (%r9),%rax
    939c:	4d 89 4c 24 50       	mov    %r9,0x50(%r12)
    93a1:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    93a6:	85 c0                	test   %eax,%eax
    93a8:	78 09                	js     93b3 <fwp_hof0.constprop.0+0x3a3>
    93aa:	48 6b c0 68          	imul   $0x68,%rax,%rax
    93ae:	44 89 6c 05 58       	mov    %r13d,0x58(%rbp,%rax,1)
    93b3:	41 89 39             	mov    %edi,(%r9)
    93b6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    93bb:	45 31 e4             	xor    %r12d,%r12d
    93be:	48 89 f8             	mov    %rdi,%rax
    93c1:	48 85 ff             	test   %rdi,%rdi
    93c4:	0f 84 a6 0d 00 00    	je     a170 <fwp_hof0.constprop.0+0x1160>
    93ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93d4:	49 83 c4 01          	add    $0x1,%r12
    93d8:	48 85 c0             	test   %rax,%rax
    93db:	75 f3                	jne    93d0 <fwp_hof0.constprop.0+0x3c0>
    93dd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    93e2:	0f 1f 00             	nopl   (%rax)
    93e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93ec:	00 00 00 00 
    93f0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    93f4:	48 83 c0 01          	add    $0x1,%rax
    93f8:	48 85 d2             	test   %rdx,%rdx
    93fb:	75 f3                	jne    93f0 <fwp_hof0.constprop.0+0x3e0>
    93fd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9404:	ff ff 1f 
    9407:	48 39 c2             	cmp    %rax,%rdx
    940a:	0f 82 02 14 00 00    	jb     a812 <fwp_hof0.constprop.0+0x1802>
    9410:	4d 85 e4             	test   %r12,%r12
    9413:	0f 8e 57 0d 00 00    	jle    a170 <fwp_hof0.constprop.0+0x1160>
    9419:	49 39 c4             	cmp    %rax,%r12
    941c:	4c 0f 47 e0          	cmova  %rax,%r12
    9420:	4c 89 e0             	mov    %r12,%rax
    9423:	48 c1 e8 3c          	shr    $0x3c,%rax
    9427:	0f 85 e5 13 00 00    	jne    a812 <fwp_hof0.constprop.0+0x1802>
    942d:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9431:	48 c1 e1 10          	shl    $0x10,%rcx
    9435:	48 09 f1             	or     %rsi,%rcx
    9438:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    943f:	00 
    9440:	be 02 00 00 00       	mov    $0x2,%esi
    9445:	48 89 0c 24          	mov    %rcx,(%rsp)
    9449:	e8 02 c6 ff ff       	call   5a50 <fwp_heap_alloc>
    944e:	4c 89 30             	mov    %r14,(%rax)
    9451:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9458:	49 89 c5             	mov    %rax,%r13
    945b:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9462:	48 c1 e2 10          	shl    $0x10,%rdx
    9466:	48 39 d0             	cmp    %rdx,%rax
    9469:	0f 83 01 11 00 00    	jae    a570 <fwp_hof0.constprop.0+0x1560>
    946f:	48 89 c2             	mov    %rax,%rdx
    9472:	48 c1 ea 10          	shr    $0x10,%rdx
    9476:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    947a:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9481:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9485:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9489:	4d 85 f6             	test   %r14,%r14
    948c:	74 38                	je     94c6 <fwp_hof0.constprop.0+0x4b6>
    948e:	0f b6 0a             	movzbl (%rdx),%ecx
    9491:	80 f9 02             	cmp    $0x2,%cl
    9494:	0f 84 47 0d 00 00    	je     a1e1 <fwp_hof0.constprop.0+0x11d1>
    949a:	80 f9 01             	cmp    $0x1,%cl
    949d:	75 27                	jne    94c6 <fwp_hof0.constprop.0+0x4b6>
    949f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94a2:	0f b7 c0             	movzwl %ax,%eax
    94a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94a8:	48 0f af c1          	imul   %rcx,%rax
    94ac:	48 c1 e8 20          	shr    $0x20,%rax
    94b0:	48 39 d0             	cmp    %rdx,%rax
    94b3:	73 11                	jae    94c6 <fwp_hof0.constprop.0+0x4b6>
    94b5:	49 01 c6             	add    %rax,%r14
    94b8:	41 80 3e ff          	cmpb   $0xff,(%r14)
    94bc:	0f 84 32 0d 00 00    	je     a1f4 <fwp_hof0.constprop.0+0x11e4>
    94c2:	41 c6 06 01          	movb   $0x1,(%r14)
    94c6:	4d 85 e4             	test   %r12,%r12
    94c9:	74 69                	je     9534 <fwp_hof0.constprop.0+0x524>
    94cb:	48 8b 0c 24          	mov    (%rsp),%rcx
    94cf:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    94d4:	31 c0                	xor    %eax,%eax
    94d6:	48 c1 e1 20          	shl    $0x20,%rcx
    94da:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    94df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94e6:	00 00 00 00 
    94ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94f1:	00 00 00 00 
    94f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94fc:	00 00 00 00 
    9500:	48 89 c6             	mov    %rax,%rsi
    9503:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9508:	48 01 ce             	add    %rcx,%rsi
    950b:	0f 80 3f a2 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9511:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    9516:	48 89 c6             	mov    %rax,%rsi
    9519:	48 83 c0 01          	add    $0x1,%rax
    951d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9521:	48 c1 e6 04          	shl    $0x4,%rsi
    9525:	41 0f 11 44 35 08    	movups %xmm0,0x8(%r13,%rsi,1)
    952b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    952f:	4c 39 e0             	cmp    %r12,%rax
    9532:	72 cc                	jb     9500 <fwp_hof0.constprop.0+0x4f0>
    9534:	49 8b 45 00          	mov    0x0(%r13),%rax
    9538:	48 d1 e8             	shr    $1,%rax
    953b:	0f 85 df 0c 00 00    	jne    a220 <fwp_hof0.constprop.0+0x1210>
    9541:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
    9548:	00 
    9549:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    9550:	4c 89 ef             	mov    %r13,%rdi
    9553:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
    9558:	e8 d3 e2 ff ff       	call   7830 <fwp_drop10>
    955d:	4c 63 24 24          	movslq (%rsp),%r12
    9561:	4c 89 e7             	mov    %r12,%rdi
    9564:	e8 17 af ff ff       	call   4480 <fwp_tape_of>
    9569:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
    956e:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9573:	48 89 c6             	mov    %rax,%rsi
    9576:	0f 85 3a 13 00 00    	jne    a8b6 <fwp_hof0.constprop.0+0x18a6>
    957c:	48 89 c7             	mov    %rax,%rdi
    957f:	e8 7c a6 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9584:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    9588:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    958d:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9594:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    9598:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    959c:	66 49 0f 6e fe       	movq   %r14,%xmm7
    95a1:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    95a6:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    95ab:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    95af:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    95b3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    95b9:	77 19                	ja     95d4 <fwp_hof0.constprop.0+0x5c4>
    95bb:	0f b7 04 24          	movzwl (%rsp),%eax
    95bf:	83 e8 01             	sub    $0x1,%eax
    95c2:	48 98                	cltq
    95c4:	48 3b 05 0d 8b 01 00 	cmp    0x18b0d(%rip),%rax        # 220d8 <fwp_tape_next_slot>
    95cb:	7d 07                	jge    95d4 <fwp_hof0.constprop.0+0x5c4>
    95cd:	48 89 05 04 8b 01 00 	mov    %rax,0x18b04(%rip)        # 220d8 <fwp_tape_next_slot>
    95d4:	48 8b 05 1d ae 01 00 	mov    0x1ae1d(%rip),%rax        # 243f8 <fwp_cleanups>
    95db:	66 0f ef c9          	pxor   %xmm1,%xmm1
    95df:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    95e6:	00 
    95e7:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    95eb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    95f2:	00 
    95f3:	48 8d 05 36 b8 ff ff 	lea    -0x47ca(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    95fa:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9601:	00 
    9602:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9609:	00 
    960a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    960f:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9616:	00 
    9617:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    961e:	00 
    961f:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9626:	00 
    9627:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    962e:	00 
    962f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9633:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9637:	48 89 05 ba ad 01 00 	mov    %rax,0x1adba(%rip)        # 243f8 <fwp_cleanups>
    963e:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
    9645:	00 
    9646:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    964d:	00 
    964e:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    9655:	00 
    9656:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    965d:	00 
    965e:	4d 85 c9             	test   %r9,%r9
    9661:	0f 88 c9 0d 00 00    	js     a430 <fwp_hof0.constprop.0+0x1420>
    9667:	4c 89 c8             	mov    %r9,%rax
    966a:	48 c1 f8 20          	sar    $0x20,%rax
    966e:	49 39 c4             	cmp    %rax,%r12
    9671:	0f 85 57 11 00 00    	jne    a7ce <fwp_hof0.constprop.0+0x17be>
    9677:	45 89 cd             	mov    %r9d,%r13d
    967a:	4d 89 ec             	mov    %r13,%r12
    967d:	4c 39 ea             	cmp    %r13,%rdx
    9680:	0f 8e 54 11 00 00    	jle    a7da <fwp_hof0.constprop.0+0x17ca>
    9686:	4c 39 ed             	cmp    %r13,%rbp
    9689:	0f 8e 51 0c 00 00    	jle    a2e0 <fwp_hof0.constprop.0+0x12d0>
    968f:	4c 39 f5             	cmp    %r14,%rbp
    9692:	0f 8f 88 0c 00 00    	jg     a320 <fwp_hof0.constprop.0+0x1310>
    9698:	48 85 c9             	test   %rcx,%rcx
    969b:	0f 84 94 11 00 00    	je     a835 <fwp_hof0.constprop.0+0x1825>
    96a1:	48 89 cf             	mov    %rcx,%rdi
    96a4:	31 f6                	xor    %esi,%esi
    96a6:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    96ab:	4c 8d 65 ff          	lea    -0x1(%rbp),%r12
    96af:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    96b6:	00 
    96b7:	0f 29 14 24          	movaps %xmm2,(%rsp)
    96bb:	e8 00 9e ff ff       	call   34c0 <memset@plt>
    96c0:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    96c5:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    96cb:	48 89 c1             	mov    %rax,%rcx
    96ce:	f2 0f 10 05 d2 53 00 	movsd  0x53d2(%rip),%xmm0        # eaa8 <msg.4+0x28>
    96d5:	00 
    96d6:	f2 42 0f 58 04 e9    	addsd  (%rcx,%r13,8),%xmm0
    96dc:	f2 42 0f 11 04 e9    	movsd  %xmm0,(%rcx,%r13,8)
    96e2:	4c 39 e5             	cmp    %r12,%rbp
    96e5:	0f 8f 8f 00 00 00    	jg     977a <fwp_hof0.constprop.0+0x76a>
    96eb:	0f 12 fb             	movhlps %xmm3,%xmm7
    96ee:	66 49 0f 7e d1       	movq   %xmm2,%r9
    96f3:	66 48 0f 7e de       	movq   %xmm3,%rsi
    96f8:	49 29 ec             	sub    %rbp,%r12
    96fb:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    9700:	0f 12 fa             	movhlps %xmm2,%xmm7
    9703:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9707:	66 49 0f 7e fb       	movq   %xmm7,%r11
    970c:	4a 8d 04 a7          	lea    (%rdi,%r12,4),%rax
    9710:	48 29 fe             	sub    %rdi,%rsi
    9713:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    9717:	4c 8d 24 e9          	lea    (%rcx,%rbp,8),%r12
    971b:	4d 29 d9             	sub    %r11,%r9
    971e:	4d 29 dc             	sub    %r11,%r12
    9721:	eb 09                	jmp    972c <fwp_hof0.constprop.0+0x71c>
    9723:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9728:	48 83 e8 04          	sub    $0x4,%rax
    972c:	f2 41 0f 10 04 14    	movsd  (%r12,%rdx,1),%xmm0
    9732:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9736:	7a 02                	jp     973a <fwp_hof0.constprop.0+0x72a>
    9738:	74 37                	je     9771 <fwp_hof0.constprop.0+0x761>
    973a:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    973e:	45 85 c0             	test   %r8d,%r8d
    9741:	78 16                	js     9759 <fwp_hof0.constprop.0+0x749>
    9743:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    9749:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    974d:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    9753:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    9759:	4c 63 00             	movslq (%rax),%r8
    975c:	45 85 c0             	test   %r8d,%r8d
    975f:	78 10                	js     9771 <fwp_hof0.constprop.0+0x761>
    9761:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9765:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    976b:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    9771:	48 83 ea 08          	sub    $0x8,%rdx
    9775:	48 39 c7             	cmp    %rax,%rdi
    9778:	75 ae                	jne    9728 <fwp_hof0.constprop.0+0x718>
    977a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9781:	ff ff 1f 
    9784:	48 39 e8             	cmp    %rbp,%rax
    9787:	0f 82 79 10 00 00    	jb     a806 <fwp_hof0.constprop.0+0x17f6>
    978d:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9794:	00 
    9795:	be 02 00 00 00       	mov    $0x2,%esi
    979a:	48 89 0c 24          	mov    %rcx,(%rsp)
    979e:	e8 ad c2 ff ff       	call   5a50 <fwp_heap_alloc>
    97a3:	48 85 ed             	test   %rbp,%rbp
    97a6:	48 8b 0c 24          	mov    (%rsp),%rcx
    97aa:	48 89 28             	mov    %rbp,(%rax)
    97ad:	49 89 c6             	mov    %rax,%r14
    97b0:	74 20                	je     97d2 <fwp_hof0.constprop.0+0x7c2>
    97b2:	0f 1f 00             	nopl   (%rax)
    97b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97bc:	00 00 00 00 
    97c0:	4a 8b 04 f9          	mov    (%rcx,%r15,8),%rax
    97c4:	4b 89 44 fe 08       	mov    %rax,0x8(%r14,%r15,8)
    97c9:	49 83 c7 01          	add    $0x1,%r15
    97cd:	4c 39 fd             	cmp    %r15,%rbp
    97d0:	75 ee                	jne    97c0 <fwp_hof0.constprop.0+0x7b0>
    97d2:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
    97d9:	00 
    97da:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    97df:	4c 89 2d 12 ac 01 00 	mov    %r13,0x1ac12(%rip)        # 243f8 <fwp_cleanups>
    97e6:	e8 45 b6 ff ff       	call   4e30 <fwp_tape_buffers_release>
    97eb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    97f2:	4c 89 f0             	mov    %r14,%rax
    97f5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    97fc:	48 c1 e2 10          	shl    $0x10,%rdx
    9800:	48 39 d0             	cmp    %rdx,%rax
    9803:	73 59                	jae    985e <fwp_hof0.constprop.0+0x84e>
    9805:	48 89 c2             	mov    %rax,%rdx
    9808:	48 c1 ea 10          	shr    $0x10,%rdx
    980c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9810:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9817:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    981b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    981f:	4d 85 e4             	test   %r12,%r12
    9822:	74 3a                	je     985e <fwp_hof0.constprop.0+0x84e>
    9824:	0f b6 0a             	movzbl (%rdx),%ecx
    9827:	80 f9 02             	cmp    $0x2,%cl
    982a:	0f 84 30 0c 00 00    	je     a460 <fwp_hof0.constprop.0+0x1450>
    9830:	80 f9 01             	cmp    $0x1,%cl
    9833:	75 29                	jne    985e <fwp_hof0.constprop.0+0x84e>
    9835:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9838:	0f b7 c0             	movzwl %ax,%eax
    983b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    983e:	48 0f af c1          	imul   %rcx,%rax
    9842:	48 c1 e8 20          	shr    $0x20,%rax
    9846:	48 39 d0             	cmp    %rdx,%rax
    9849:	73 13                	jae    985e <fwp_hof0.constprop.0+0x84e>
    984b:	49 01 c4             	add    %rax,%r12
    984e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9853:	0f 84 1b 0c 00 00    	je     a474 <fwp_hof0.constprop.0+0x1464>
    9859:	41 c6 04 24 01       	movb   $0x1,(%r12)
    985e:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    9863:	0f 85 e2 9e ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9869:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9870:	00 
    9871:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    9876:	48 89 05 7b ab 01 00 	mov    %rax,0x1ab7b(%rip)        # 243f8 <fwp_cleanups>
    987d:	e8 7e d0 ff ff       	call   6900 <fwp_tape_scope_release>
    9882:	49 8b 06             	mov    (%r14),%rax
    9885:	49 89 c7             	mov    %rax,%r15
    9888:	49 0f ba f7 3f       	btr    $0x3f,%r15
    988d:	48 85 c0             	test   %rax,%rax
    9890:	0f 88 0a 08 00 00    	js     a0a0 <fwp_hof0.constprop.0+0x1090>
    9896:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    989d:	4c 89 f0             	mov    %r14,%rax
    98a0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    98a7:	48 c1 e2 10          	shl    $0x10,%rdx
    98ab:	48 39 d0             	cmp    %rdx,%rax
    98ae:	0f 83 ec 07 00 00    	jae    a0a0 <fwp_hof0.constprop.0+0x1090>
    98b4:	48 89 c2             	mov    %rax,%rdx
    98b7:	48 c1 ea 10          	shr    $0x10,%rdx
    98bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98bf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    98c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98ca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    98ce:	48 85 c9             	test   %rcx,%rcx
    98d1:	0f 84 c9 07 00 00    	je     a0a0 <fwp_hof0.constprop.0+0x1090>
    98d7:	0f b6 32             	movzbl (%rdx),%esi
    98da:	40 80 fe 02          	cmp    $0x2,%sil
    98de:	0f 84 ac 07 00 00    	je     a090 <fwp_hof0.constprop.0+0x1080>
    98e4:	40 80 fe 01          	cmp    $0x1,%sil
    98e8:	0f 85 b2 07 00 00    	jne    a0a0 <fwp_hof0.constprop.0+0x1090>
    98ee:	8b 72 18             	mov    0x18(%rdx),%esi
    98f1:	0f b7 c0             	movzwl %ax,%eax
    98f4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98f7:	48 0f af c6          	imul   %rsi,%rax
    98fb:	48 c1 e8 20          	shr    $0x20,%rax
    98ff:	48 39 d0             	cmp    %rdx,%rax
    9902:	0f 83 98 07 00 00    	jae    a0a0 <fwp_hof0.constprop.0+0x1090>
    9908:	48 01 c1             	add    %rax,%rcx
    990b:	80 39 01             	cmpb   $0x1,(%rcx)
    990e:	0f 85 8c 07 00 00    	jne    a0a0 <fwp_hof0.constprop.0+0x1090>
    9914:	4c 89 34 24          	mov    %r14,(%rsp)
    9918:	4d 89 f4             	mov    %r14,%r12
    991b:	31 ff                	xor    %edi,%edi
    991d:	48 8b 04 24          	mov    (%rsp),%rax
    9921:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9925:	31 c0                	xor    %eax,%eax
    9927:	4d 85 ff             	test   %r15,%r15
    992a:	75 2e                	jne    995a <fwp_hof0.constprop.0+0x94a>
    992c:	eb 42                	jmp    9970 <fwp_hof0.constprop.0+0x960>
    992e:	66 90                	xchg   %ax,%ax
    9930:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9935:	0f 88 ab 0e 00 00    	js     a7e6 <fwp_hof0.constprop.0+0x17d6>
    993b:	f2 0f 10 05 7d 51 00 	movsd  0x517d(%rip),%xmm0        # eac0 <msg.4+0x40>
    9942:	00 
    9943:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9948:	48 83 c0 01          	add    $0x1,%rax
    994c:	48 83 c2 08          	add    $0x8,%rdx
    9950:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9955:	49 39 c7             	cmp    %rax,%r15
    9958:	74 16                	je     9970 <fwp_hof0.constprop.0+0x960>
    995a:	49 8d 4e 08          	lea    0x8(%r14),%rcx
    995e:	49 83 3e 00          	cmpq   $0x0,(%r14)
    9962:	79 cc                	jns    9930 <fwp_hof0.constprop.0+0x920>
    9964:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    9968:	eb c6                	jmp    9930 <fwp_hof0.constprop.0+0x920>
    996a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9970:	e8 bb de ff ff       	call   7830 <fwp_drop10>
    9975:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    997a:	31 d2                	xor    %edx,%edx
    997c:	48 89 f8             	mov    %rdi,%rax
    997f:	48 85 ff             	test   %rdi,%rdi
    9982:	0f 84 92 0c 00 00    	je     a61a <fwp_hof0.constprop.0+0x160a>
    9988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    998f:	00 
    9990:	48 8b 40 10          	mov    0x10(%rax),%rax
    9994:	48 83 c2 01          	add    $0x1,%rdx
    9998:	48 85 c0             	test   %rax,%rax
    999b:	75 f3                	jne    9990 <fwp_hof0.constprop.0+0x980>
    999d:	49 8b 04 24          	mov    (%r12),%rax
    99a1:	49 89 c7             	mov    %rax,%r15
    99a4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    99a9:	48 85 c0             	test   %rax,%rax
    99ac:	0f 88 ab 05 00 00    	js     9f5d <fwp_hof0.constprop.0+0xf4d>
    99b2:	48 8b 83 d8 13 00 00 	mov    0x13d8(%rbx),%rax
    99b9:	48 8b 0c 24          	mov    (%rsp),%rcx
    99bd:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    99c4:	48 c1 e0 10          	shl    $0x10,%rax
    99c8:	48 39 c1             	cmp    %rax,%rcx
    99cb:	0f 83 8c 05 00 00    	jae    9f5d <fwp_hof0.constprop.0+0xf4d>
    99d1:	48 89 c8             	mov    %rcx,%rax
    99d4:	48 c1 e8 10          	shr    $0x10,%rax
    99d8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    99dc:	48 8b 83 f8 13 00 00 	mov    0x13f8(%rbx),%rax
    99e3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    99e7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    99eb:	48 85 ff             	test   %rdi,%rdi
    99ee:	0f 84 69 05 00 00    	je     9f5d <fwp_hof0.constprop.0+0xf4d>
    99f4:	0f b6 06             	movzbl (%rsi),%eax
    99f7:	3c 02                	cmp    $0x2,%al
    99f9:	0f 84 49 05 00 00    	je     9f48 <fwp_hof0.constprop.0+0xf38>
    99ff:	3c 01                	cmp    $0x1,%al
    9a01:	0f 85 4a 05 00 00    	jne    9f51 <fwp_hof0.constprop.0+0xf41>
    9a07:	8b 46 18             	mov    0x18(%rsi),%eax
    9a0a:	0f b7 c9             	movzwl %cx,%ecx
    9a0d:	48 0f af c8          	imul   %rax,%rcx
    9a11:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9a14:	48 c1 e9 20          	shr    $0x20,%rcx
    9a18:	48 39 c1             	cmp    %rax,%rcx
    9a1b:	0f 83 30 05 00 00    	jae    9f51 <fwp_hof0.constprop.0+0xf41>
    9a21:	48 01 cf             	add    %rcx,%rdi
    9a24:	80 3f 01             	cmpb   $0x1,(%rdi)
    9a27:	0f 85 24 05 00 00    	jne    9f51 <fwp_hof0.constprop.0+0xf41>
    9a2d:	4c 39 fa             	cmp    %r15,%rdx
    9a30:	4c 89 f8             	mov    %r15,%rax
    9a33:	48 0f 46 c2          	cmovbe %rdx,%rax
    9a37:	48 85 c0             	test   %rax,%rax
    9a3a:	0f 84 b2 0d 00 00    	je     a7f2 <fwp_hof0.constprop.0+0x17e2>
    9a40:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    9a47:	00 
    9a48:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    9a4d:	4c 8b 04 24          	mov    (%rsp),%r8
    9a51:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9a56:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9a5d:	00 
    9a5e:	31 d2                	xor    %edx,%edx
    9a60:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9a64:	eb 38                	jmp    9a9e <fwp_hof0.constprop.0+0xa8e>
    9a66:	0f 1f 40 00          	nopl   0x0(%rax)
    9a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a71:	00 00 00 00 
    9a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a7c:	00 00 00 00 
    9a80:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9a85:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9a8a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    9a91:	48 83 c2 08          	add    $0x8,%rdx
    9a95:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9a99:	49 39 d1             	cmp    %rdx,%r9
    9a9c:	74 12                	je     9ab0 <fwp_hof0.constprop.0+0xaa0>
    9a9e:	48 89 fe             	mov    %rdi,%rsi
    9aa1:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9aa6:	79 d8                	jns    9a80 <fwp_hof0.constprop.0+0xa70>
    9aa8:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9aac:	eb d2                	jmp    9a80 <fwp_hof0.constprop.0+0xa70>
    9aae:	66 90                	xchg   %ax,%ax
    9ab0:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9ab5:	48 85 c9             	test   %rcx,%rcx
    9ab8:	0f 84 08 0d 00 00    	je     a7c6 <fwp_hof0.constprop.0+0x17b6>
    9abe:	4c 8b 8b d8 13 00 00 	mov    0x13d8(%rbx),%r9
    9ac5:	4c 8b 93 b0 13 00 00 	mov    0x13b0(%rbx),%r10
    9acc:	45 31 ff             	xor    %r15d,%r15d
    9acf:	4c 8b 9b f8 13 00 00 	mov    0x13f8(%rbx),%r11
    9ad6:	49 c1 e1 10          	shl    $0x10,%r9
    9ada:	eb 1a                	jmp    9af6 <fwp_hof0.constprop.0+0xae6>
    9adc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ae0:	49 83 c7 01          	add    $0x1,%r15
    9ae4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9ae8:	49 39 c7             	cmp    %rax,%r15
    9aeb:	0f 83 5f 01 00 00    	jae    9c50 <fwp_hof0.constprop.0+0xc40>
    9af1:	48 85 c9             	test   %rcx,%rcx
    9af4:	74 56                	je     9b4c <fwp_hof0.constprop.0+0xb3c>
    9af6:	48 89 ca             	mov    %rcx,%rdx
    9af9:	4c 29 d2             	sub    %r10,%rdx
    9afc:	4c 39 ca             	cmp    %r9,%rdx
    9aff:	73 4b                	jae    9b4c <fwp_hof0.constprop.0+0xb3c>
    9b01:	48 89 d6             	mov    %rdx,%rsi
    9b04:	48 c1 ee 10          	shr    $0x10,%rsi
    9b08:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9b0c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9b10:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9b14:	48 85 ff             	test   %rdi,%rdi
    9b17:	74 33                	je     9b4c <fwp_hof0.constprop.0+0xb3c>
    9b19:	44 0f b6 06          	movzbl (%rsi),%r8d
    9b1d:	41 80 f8 02          	cmp    $0x2,%r8b
    9b21:	0f 84 11 01 00 00    	je     9c38 <fwp_hof0.constprop.0+0xc28>
    9b27:	41 80 f8 01          	cmp    $0x1,%r8b
    9b2b:	75 1f                	jne    9b4c <fwp_hof0.constprop.0+0xb3c>
    9b2d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9b31:	0f b7 d2             	movzwl %dx,%edx
    9b34:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9b37:	49 0f af d0          	imul   %r8,%rdx
    9b3b:	48 c1 ea 20          	shr    $0x20,%rdx
    9b3f:	48 39 f2             	cmp    %rsi,%rdx
    9b42:	73 08                	jae    9b4c <fwp_hof0.constprop.0+0xb3c>
    9b44:	48 01 d7             	add    %rdx,%rdi
    9b47:	80 3f 01             	cmpb   $0x1,(%rdi)
    9b4a:	74 94                	je     9ae0 <fwp_hof0.constprop.0+0xad0>
    9b4c:	49 39 c7             	cmp    %rax,%r15
    9b4f:	0f 83 fb 00 00 00    	jae    9c50 <fwp_hof0.constprop.0+0xc40>
    9b55:	48 89 c5             	mov    %rax,%rbp
    9b58:	45 31 f6             	xor    %r14d,%r14d
    9b5b:	eb 37                	jmp    9b94 <fwp_hof0.constprop.0+0xb84>
    9b5d:	0f 1f 00             	nopl   (%rax)
    9b60:	40 80 fe 01          	cmp    $0x1,%sil
    9b64:	75 25                	jne    9b8b <fwp_hof0.constprop.0+0xb7b>
    9b66:	8b 71 18             	mov    0x18(%rcx),%esi
    9b69:	0f b7 c0             	movzwl %ax,%eax
    9b6c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9b6f:	48 0f af c6          	imul   %rsi,%rax
    9b73:	48 c1 e8 20          	shr    $0x20,%rax
    9b77:	48 39 c8             	cmp    %rcx,%rax
    9b7a:	73 0f                	jae    9b8b <fwp_hof0.constprop.0+0xb7b>
    9b7c:	48 01 c2             	add    %rax,%rdx
    9b7f:	80 3a ff             	cmpb   $0xff,(%rdx)
    9b82:	0f 84 c8 05 00 00    	je     a150 <fwp_hof0.constprop.0+0x1140>
    9b88:	c6 02 01             	movb   $0x1,(%rdx)
    9b8b:	49 39 ef             	cmp    %rbp,%r15
    9b8e:	0f 83 8c 00 00 00    	jae    9c20 <fwp_hof0.constprop.0+0xc10>
    9b94:	48 83 ed 01          	sub    $0x1,%rbp
    9b98:	66 49 0f 6e f6       	movq   %r14,%xmm6
    9b9d:	bf 01 00 00 00       	mov    $0x1,%edi
    9ba2:	f3 41 0f 7e 44 ed 00 	movq   0x0(%r13,%rbp,8),%xmm0
    9ba9:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    9bb0:	00 
    9bb1:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9bb5:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    9bbc:	00 
    9bbd:	e8 ae bf ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9bc2:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9bc9:	49 89 c6             	mov    %rax,%r14
    9bcc:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9bd3:	48 c1 e2 10          	shl    $0x10,%rdx
    9bd7:	48 39 d0             	cmp    %rdx,%rax
    9bda:	73 af                	jae    9b8b <fwp_hof0.constprop.0+0xb7b>
    9bdc:	48 89 c2             	mov    %rax,%rdx
    9bdf:	48 c1 ea 10          	shr    $0x10,%rdx
    9be3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9be7:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9bee:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9bf2:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9bf6:	48 85 d2             	test   %rdx,%rdx
    9bf9:	74 90                	je     9b8b <fwp_hof0.constprop.0+0xb7b>
    9bfb:	0f b6 31             	movzbl (%rcx),%esi
    9bfe:	40 80 fe 02          	cmp    $0x2,%sil
    9c02:	0f 85 58 ff ff ff    	jne    9b60 <fwp_hof0.constprop.0+0xb50>
    9c08:	66 85 c0             	test   %ax,%ax
    9c0b:	0f 84 6e ff ff ff    	je     9b7f <fwp_hof0.constprop.0+0xb6f>
    9c11:	49 39 ef             	cmp    %rbp,%r15
    9c14:	0f 82 7a ff ff ff    	jb     9b94 <fwp_hof0.constprop.0+0xb84>
    9c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c20:	4d 85 ff             	test   %r15,%r15
    9c23:	75 2e                	jne    9c53 <fwp_hof0.constprop.0+0xc43>
    9c25:	8b 44 24 28          	mov    0x28(%rsp),%eax
    9c29:	85 c0                	test   %eax,%eax
    9c2b:	4d 0f 45 ef          	cmovne %r15,%r13
    9c2f:	eb 63                	jmp    9c94 <fwp_hof0.constprop.0+0xc84>
    9c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9c38:	66 85 d2             	test   %dx,%dx
    9c3b:	0f 84 06 ff ff ff    	je     9b47 <fwp_hof0.constprop.0+0xb37>
    9c41:	49 39 c7             	cmp    %rax,%r15
    9c44:	0f 82 0b ff ff ff    	jb     9b55 <fwp_hof0.constprop.0+0xb45>
    9c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c50:	45 31 f6             	xor    %r14d,%r14d
    9c53:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9c58:	4c 89 ea             	mov    %r13,%rdx
    9c5b:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    9c60:	48 8b 0a             	mov    (%rdx),%rcx
    9c63:	48 83 c2 08          	add    $0x8,%rdx
    9c67:	48 89 c7             	mov    %rax,%rdi
    9c6a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9c6e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9c72:	4c 39 ca             	cmp    %r9,%rdx
    9c75:	75 e9                	jne    9c60 <fwp_hof0.constprop.0+0xc50>
    9c77:	8b 54 24 28          	mov    0x28(%rsp),%edx
    9c7b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9c7f:	85 d2                	test   %edx,%edx
    9c81:	0f 84 01 08 00 00    	je     a488 <fwp_hof0.constprop.0+0x1478>
    9c87:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    9c8c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9c91:	45 31 ed             	xor    %r13d,%r13d
    9c94:	4c 89 ef             	mov    %r13,%rdi
    9c97:	e8 b4 b8 ff ff       	call   5550 <fwp_mem_free>
    9c9c:	48 8b 3c 24          	mov    (%rsp),%rdi
    9ca0:	e8 8b db ff ff       	call   7830 <fwp_drop10>
    9ca5:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9cac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9cb1:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9cb8:	48 c1 e2 10          	shl    $0x10,%rdx
    9cbc:	48 39 d0             	cmp    %rdx,%rax
    9cbf:	73 6f                	jae    9d30 <fwp_hof0.constprop.0+0xd20>
    9cc1:	48 89 c2             	mov    %rax,%rdx
    9cc4:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    9ccb:	48 c1 ea 10          	shr    $0x10,%rdx
    9ccf:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9cd3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9cd7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9cdb:	4d 85 e4             	test   %r12,%r12
    9cde:	74 50                	je     9d30 <fwp_hof0.constprop.0+0xd20>
    9ce0:	0f b6 0a             	movzbl (%rdx),%ecx
    9ce3:	80 f9 02             	cmp    $0x2,%cl
    9ce6:	0f 84 24 07 00 00    	je     a410 <fwp_hof0.constprop.0+0x1400>
    9cec:	80 f9 01             	cmp    $0x1,%cl
    9cef:	75 3f                	jne    9d30 <fwp_hof0.constprop.0+0xd20>
    9cf1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cf4:	0f b7 c0             	movzwl %ax,%eax
    9cf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cfa:	48 0f af c1          	imul   %rcx,%rax
    9cfe:	48 c1 e8 20          	shr    $0x20,%rax
    9d02:	48 39 d0             	cmp    %rdx,%rax
    9d05:	73 29                	jae    9d30 <fwp_hof0.constprop.0+0xd20>
    9d07:	49 01 c4             	add    %rax,%r12
    9d0a:	41 0f b6 04 24       	movzbl (%r12),%eax
    9d0f:	84 c0                	test   %al,%al
    9d11:	74 1d                	je     9d30 <fwp_hof0.constprop.0+0xd20>
    9d13:	3c 01                	cmp    $0x1,%al
    9d15:	0f 84 85 07 00 00    	je     a4a0 <fwp_hof0.constprop.0+0x1490>
    9d1b:	3c ff                	cmp    $0xff,%al
    9d1d:	0f 84 71 09 00 00    	je     a694 <fwp_hof0.constprop.0+0x1684>
    9d23:	83 e8 01             	sub    $0x1,%eax
    9d26:	41 88 04 24          	mov    %al,(%r12)
    9d2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d30:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
    9d36:	0f 85 84 05 00 00    	jne    a2c0 <fwp_hof0.constprop.0+0x12b0>
    9d3c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9d41:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d45:	4c 89 f6             	mov    %r14,%rsi
    9d48:	4d 89 f4             	mov    %r14,%r12
    9d4b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9d50:	48 8d 15 49 7e 00 00 	lea    0x7e49(%rip),%rdx        # 11ba0 <d0>
    9d57:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9d5e:	00 00 00 00 00 
    9d63:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    9d6a:	00 
    9d6b:	e8 60 e2 ff ff       	call   7fd0 <fwp_write>
    9d70:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    9d77:	00 
    9d78:	4c 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%r13
    9d7f:	00 
    9d80:	48 8d 05 a7 42 00 00 	lea    0x42a7(%rip),%rax        # e02e <_IO_stdin_used+0x2e>
    9d87:	48 85 c9             	test   %rcx,%rcx
    9d8a:	48 0f 44 c8          	cmove  %rax,%rcx
    9d8e:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    9d92:	0f 87 2f 0b 00 00    	ja     a8c7 <fwp_hof0.constprop.0+0x18b7>
    9d98:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    9d9c:	be 01 00 00 00       	mov    $0x1,%esi
    9da1:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9da6:	e8 a5 bc ff ff       	call   5a50 <fwp_heap_alloc>
    9dab:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9db0:	4c 89 ea             	mov    %r13,%rdx
    9db3:	4c 89 28             	mov    %r13,(%rax)
    9db6:	4c 8d 78 08          	lea    0x8(%rax),%r15
    9dba:	48 89 c5             	mov    %rax,%rbp
    9dbd:	4c 89 ff             	mov    %r15,%rdi
    9dc0:	e8 db 97 ff ff       	call   35a0 <memcpy@plt>
    9dc5:	42 c6 44 2d 08 00    	movb   $0x0,0x8(%rbp,%r13,1)
    9dcb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    9dd2:	00 
    9dd3:	e8 e8 95 ff ff       	call   33c0 <free@plt>
    9dd8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9ddf:	48 89 e8             	mov    %rbp,%rax
    9de2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9de9:	48 c1 e2 10          	shl    $0x10,%rdx
    9ded:	48 39 d0             	cmp    %rdx,%rax
    9df0:	73 59                	jae    9e4b <fwp_hof0.constprop.0+0xe3b>
    9df2:	48 89 c2             	mov    %rax,%rdx
    9df5:	48 c1 ea 10          	shr    $0x10,%rdx
    9df9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9dfd:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9e04:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e08:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9e0c:	4d 85 ed             	test   %r13,%r13
    9e0f:	74 3a                	je     9e4b <fwp_hof0.constprop.0+0xe3b>
    9e11:	0f b6 0a             	movzbl (%rdx),%ecx
    9e14:	80 f9 02             	cmp    $0x2,%cl
    9e17:	0f 84 d3 07 00 00    	je     a5f0 <fwp_hof0.constprop.0+0x15e0>
    9e1d:	80 f9 01             	cmp    $0x1,%cl
    9e20:	75 29                	jne    9e4b <fwp_hof0.constprop.0+0xe3b>
    9e22:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e25:	0f b7 c0             	movzwl %ax,%eax
    9e28:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e2b:	48 0f af c1          	imul   %rcx,%rax
    9e2f:	48 c1 e8 20          	shr    $0x20,%rax
    9e33:	48 39 d0             	cmp    %rdx,%rax
    9e36:	73 13                	jae    9e4b <fwp_hof0.constprop.0+0xe3b>
    9e38:	49 01 c5             	add    %rax,%r13
    9e3b:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9e40:	0f 84 be 07 00 00    	je     a604 <fwp_hof0.constprop.0+0x15f4>
    9e46:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9e4b:	4c 89 e7             	mov    %r12,%rdi
    9e4e:	e8 ed d5 ff ff       	call   7440 <fwp_drop0>
    9e53:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    9e57:	be 01 00 00 00       	mov    $0x1,%esi
    9e5c:	4c 89 ff             	mov    %r15,%rdi
    9e5f:	48 8b 0d 5a a5 01 00 	mov    0x1a55a(%rip),%rcx        # 243c0 <fwp_prog_out>
    9e66:	e8 15 98 ff ff       	call   3680 <fwrite@plt>
    9e6b:	48 8b 35 4e a5 01 00 	mov    0x1a54e(%rip),%rsi        # 243c0 <fwp_prog_out>
    9e72:	bf 0a 00 00 00       	mov    $0xa,%edi
    9e77:	e8 64 96 ff ff       	call   34e0 <fputc@plt>
    9e7c:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9e83:	48 89 e8             	mov    %rbp,%rax
    9e86:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9e8d:	48 c1 e2 10          	shl    $0x10,%rdx
    9e91:	48 39 d0             	cmp    %rdx,%rax
    9e94:	73 6a                	jae    9f00 <fwp_hof0.constprop.0+0xef0>
    9e96:	48 89 c2             	mov    %rax,%rdx
    9e99:	48 c1 ea 10          	shr    $0x10,%rdx
    9e9d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ea1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9ea8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9eac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9eb0:	4d 85 e4             	test   %r12,%r12
    9eb3:	74 4b                	je     9f00 <fwp_hof0.constprop.0+0xef0>
    9eb5:	0f b6 0a             	movzbl (%rdx),%ecx
    9eb8:	80 f9 02             	cmp    $0x2,%cl
    9ebb:	0f 84 ff 06 00 00    	je     a5c0 <fwp_hof0.constprop.0+0x15b0>
    9ec1:	80 f9 01             	cmp    $0x1,%cl
    9ec4:	75 3a                	jne    9f00 <fwp_hof0.constprop.0+0xef0>
    9ec6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ec9:	0f b7 c0             	movzwl %ax,%eax
    9ecc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ecf:	48 0f af c1          	imul   %rcx,%rax
    9ed3:	48 c1 e8 20          	shr    $0x20,%rax
    9ed7:	48 39 d0             	cmp    %rdx,%rax
    9eda:	73 24                	jae    9f00 <fwp_hof0.constprop.0+0xef0>
    9edc:	49 01 c4             	add    %rax,%r12
    9edf:	41 0f b6 04 24       	movzbl (%r12),%eax
    9ee4:	84 c0                	test   %al,%al
    9ee6:	74 18                	je     9f00 <fwp_hof0.constprop.0+0xef0>
    9ee8:	3c 01                	cmp    $0x1,%al
    9eea:	0f 84 ee 06 00 00    	je     a5de <fwp_hof0.constprop.0+0x15ce>
    9ef0:	3c ff                	cmp    $0xff,%al
    9ef2:	0f 84 0e 08 00 00    	je     a706 <fwp_hof0.constprop.0+0x16f6>
    9ef8:	83 e8 01             	sub    $0x1,%eax
    9efb:	41 88 04 24          	mov    %al,(%r12)
    9eff:	90                   	nop
    9f00:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9f05:	48 8b 40 10          	mov    0x10(%rax),%rax
    9f09:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9f0e:	48 85 c0             	test   %rax,%rax
    9f11:	0f 85 39 f1 ff ff    	jne    9050 <fwp_hof0.constprop.0+0x40>
    9f17:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9f1e:	00 
    9f1f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f26:	00 00 
    9f28:	0f 85 94 09 00 00    	jne    a8c2 <fwp_hof0.constprop.0+0x18b2>
    9f2e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9f35:	31 c0                	xor    %eax,%eax
    9f37:	5b                   	pop    %rbx
    9f38:	5d                   	pop    %rbp
    9f39:	41 5c                	pop    %r12
    9f3b:	41 5d                	pop    %r13
    9f3d:	41 5e                	pop    %r14
    9f3f:	41 5f                	pop    %r15
    9f41:	c3                   	ret
    9f42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f48:	66 85 c9             	test   %cx,%cx
    9f4b:	0f 84 d3 fa ff ff    	je     9a24 <fwp_hof0.constprop.0+0xa14>
    9f51:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    9f57:	0f 84 a4 02 00 00    	je     a201 <fwp_hof0.constprop.0+0x11f1>
    9f5d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9f62:	45 31 f6             	xor    %r14d,%r14d
    9f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f6c:	00 00 00 00 
    9f70:	48 8b 40 10          	mov    0x10(%rax),%rax
    9f74:	4c 89 f2             	mov    %r14,%rdx
    9f77:	49 83 c6 01          	add    $0x1,%r14
    9f7b:	48 85 c0             	test   %rax,%rax
    9f7e:	75 f0                	jne    9f70 <fwp_hof0.constprop.0+0xf60>
    9f80:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9f87:	ff ff 1f 
    9f8a:	4c 39 f0             	cmp    %r14,%rax
    9f8d:	0f 82 7f 08 00 00    	jb     a812 <fwp_hof0.constprop.0+0x1802>
    9f93:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    9f9a:	00 
    9f9b:	be 02 00 00 00       	mov    $0x2,%esi
    9fa0:	e8 ab ba ff ff       	call   5a50 <fwp_heap_alloc>
    9fa5:	4d 39 f7             	cmp    %r14,%r15
    9fa8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9fad:	49 89 c5             	mov    %rax,%r13
    9fb0:	4c 89 f0             	mov    %r14,%rax
    9fb3:	49 0f 46 c7          	cmovbe %r15,%rax
    9fb7:	4c 89 e9             	mov    %r13,%rcx
    9fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fc0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9fc4:	48 83 c1 08          	add    $0x8,%rcx
    9fc8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    9fcc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9fd0:	48 85 d2             	test   %rdx,%rdx
    9fd3:	75 eb                	jne    9fc0 <fwp_hof0.constprop.0+0xfb0>
    9fd5:	48 85 c0             	test   %rax,%rax
    9fd8:	0f 84 35 02 00 00    	je     a213 <fwp_hof0.constprop.0+0x1203>
    9fde:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    9fe5:	00 
    9fe6:	e9 62 fa ff ff       	jmp    9a4d <fwp_hof0.constprop.0+0xa3d>
    9feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ff0:	4d 39 ec             	cmp    %r13,%r12
    9ff3:	0f 84 47 f2 ff ff    	je     9240 <fwp_hof0.constprop.0+0x230>
    9ff9:	48 8b 2d f0 80 01 00 	mov    0x180f0(%rip),%rbp        # 220f0 <fwp_tapes>
    a000:	e9 dc f2 ff ff       	jmp    92e1 <fwp_hof0.constprop.0+0x2d1>
    a005:	0f 1f 00             	nopl   (%rax)
    a008:	48 83 3d 78 80 01 00 	cmpq   $0x0,0x18078(%rip)        # 22088 <fwp_tape_cached_bytes>
    a00f:	00 
    a010:	0f 84 10 f3 ff ff    	je     9326 <fwp_hof0.constprop.0+0x316>
    a016:	66 0f 6f 0d 82 80 01 	movdqa 0x18082(%rip),%xmm1        # 220a0 <fwp_tape_workspace>
    a01d:	00 
    a01e:	48 c7 05 5f 80 01 00 	movq   $0x0,0x1805f(%rip)        # 22088 <fwp_tape_cached_bytes>
    a025:	00 00 00 00 
    a029:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    a02f:	48 8b 05 8a 80 01 00 	mov    0x1808a(%rip),%rax        # 220c0 <fwp_tape_workspace+0x20>
    a036:	66 0f 6f 0d 72 80 01 	movdqa 0x18072(%rip),%xmm1        # 220b0 <fwp_tape_workspace+0x10>
    a03d:	00 
    a03e:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a043:	48 8b 05 7e 80 01 00 	mov    0x1807e(%rip),%rax        # 220c8 <fwp_tape_workspace+0x28>
    a04a:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    a050:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a054:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    a059:	48 8b 05 70 80 01 00 	mov    0x18070(%rip),%rax        # 220d0 <fwp_tape_workspace+0x30>
    a060:	0f 29 0d 39 80 01 00 	movaps %xmm1,0x18039(%rip)        # 220a0 <fwp_tape_workspace>
    a067:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a06c:	0f 29 0d 3d 80 01 00 	movaps %xmm1,0x1803d(%rip)        # 220b0 <fwp_tape_workspace+0x10>
    a073:	48 c7 05 52 80 01 00 	movq   $0x0,0x18052(%rip)        # 220d0 <fwp_tape_workspace+0x30>
    a07a:	00 00 00 00 
    a07e:	0f 29 0d 3b 80 01 00 	movaps %xmm1,0x1803b(%rip)        # 220c0 <fwp_tape_workspace+0x20>
    a085:	e9 9c f2 ff ff       	jmp    9326 <fwp_hof0.constprop.0+0x316>
    a08a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a090:	66 85 c0             	test   %ax,%ax
    a093:	0f 84 72 f8 ff ff    	je     990b <fwp_hof0.constprop.0+0x8fb>
    a099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a0a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a0a7:	ff ff 1f 
    a0aa:	4c 39 f8             	cmp    %r15,%rax
    a0ad:	0f 82 53 07 00 00    	jb     a806 <fwp_hof0.constprop.0+0x17f6>
    a0b3:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    a0ba:	00 
    a0bb:	be 01 00 00 00       	mov    $0x1,%esi
    a0c0:	e8 8b b9 ff ff       	call   5a50 <fwp_heap_alloc>
    a0c5:	4c 89 38             	mov    %r15,(%rax)
    a0c8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a0cf:	49 89 c4             	mov    %rax,%r12
    a0d2:	48 89 04 24          	mov    %rax,(%rsp)
    a0d6:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a0dd:	48 c1 e2 10          	shl    $0x10,%rdx
    a0e1:	48 39 d0             	cmp    %rdx,%rax
    a0e4:	73 59                	jae    a13f <fwp_hof0.constprop.0+0x112f>
    a0e6:	48 89 c2             	mov    %rax,%rdx
    a0e9:	48 c1 ea 10          	shr    $0x10,%rdx
    a0ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0f1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a0f8:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a0fc:	48 8b 69 20          	mov    0x20(%rcx),%rbp
    a100:	48 85 ed             	test   %rbp,%rbp
    a103:	74 3a                	je     a13f <fwp_hof0.constprop.0+0x112f>
    a105:	0f b6 31             	movzbl (%rcx),%esi
    a108:	40 80 fe 02          	cmp    $0x2,%sil
    a10c:	0f 84 36 04 00 00    	je     a548 <fwp_hof0.constprop.0+0x1538>
    a112:	40 80 fe 01          	cmp    $0x1,%sil
    a116:	75 27                	jne    a13f <fwp_hof0.constprop.0+0x112f>
    a118:	8b 71 18             	mov    0x18(%rcx),%esi
    a11b:	0f b7 c0             	movzwl %ax,%eax
    a11e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a121:	48 0f af c6          	imul   %rsi,%rax
    a125:	48 c1 e8 20          	shr    $0x20,%rax
    a129:	48 39 c8             	cmp    %rcx,%rax
    a12c:	73 11                	jae    a13f <fwp_hof0.constprop.0+0x112f>
    a12e:	48 01 c5             	add    %rax,%rbp
    a131:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a135:	0f 84 20 04 00 00    	je     a55b <fwp_hof0.constprop.0+0x154b>
    a13b:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a13f:	4c 89 f7             	mov    %r14,%rdi
    a142:	e9 d6 f7 ff ff       	jmp    991d <fwp_hof0.constprop.0+0x90d>
    a147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a14e:	00 00 
    a150:	48 89 d7             	mov    %rdx,%rdi
    a153:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a158:	e8 b3 b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a15d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a162:	e9 21 fa ff ff       	jmp    9b88 <fwp_hof0.constprop.0+0xb78>
    a167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a16e:	00 00 
    a170:	48 c1 e1 10          	shl    $0x10,%rcx
    a174:	bf 08 00 00 00       	mov    $0x8,%edi
    a179:	48 09 f1             	or     %rsi,%rcx
    a17c:	be 02 00 00 00       	mov    $0x2,%esi
    a181:	48 89 0c 24          	mov    %rcx,(%rsp)
    a185:	e8 c6 b8 ff ff       	call   5a50 <fwp_heap_alloc>
    a18a:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a191:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a198:	49 89 c5             	mov    %rax,%r13
    a19b:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a1a2:	48 c1 e2 10          	shl    $0x10,%rdx
    a1a6:	48 39 d0             	cmp    %rdx,%rax
    a1a9:	0f 83 92 f3 ff ff    	jae    9541 <fwp_hof0.constprop.0+0x531>
    a1af:	48 89 c2             	mov    %rax,%rdx
    a1b2:	48 c1 ea 10          	shr    $0x10,%rdx
    a1b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1ba:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a1c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1c5:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a1c9:	4d 85 f6             	test   %r14,%r14
    a1cc:	0f 84 62 f3 ff ff    	je     9534 <fwp_hof0.constprop.0+0x524>
    a1d2:	0f b6 0a             	movzbl (%rdx),%ecx
    a1d5:	45 31 e4             	xor    %r12d,%r12d
    a1d8:	80 f9 02             	cmp    $0x2,%cl
    a1db:	0f 85 b9 f2 ff ff    	jne    949a <fwp_hof0.constprop.0+0x48a>
    a1e1:	66 85 c0             	test   %ax,%ax
    a1e4:	0f 85 dc f2 ff ff    	jne    94c6 <fwp_hof0.constprop.0+0x4b6>
    a1ea:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a1ee:	0f 85 ce f2 ff ff    	jne    94c2 <fwp_hof0.constprop.0+0x4b2>
    a1f4:	4c 89 f7             	mov    %r14,%rdi
    a1f7:	e8 14 b1 ff ff       	call   5310 <fwp_rc_forget_slot>
    a1fc:	e9 c1 f2 ff ff       	jmp    94c2 <fwp_hof0.constprop.0+0x4b2>
    a201:	be 02 00 00 00       	mov    $0x2,%esi
    a206:	bf 08 00 00 00       	mov    $0x8,%edi
    a20b:	e8 40 b8 ff ff       	call   5a50 <fwp_heap_alloc>
    a210:	49 89 c5             	mov    %rax,%r13
    a213:	45 31 f6             	xor    %r14d,%r14d
    a216:	e9 79 fa ff ff       	jmp    9c94 <fwp_hof0.constprop.0+0xc84>
    a21b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a220:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    a224:	4c 89 e7             	mov    %r12,%rdi
    a227:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a22b:	0f 85 e1 05 00 00    	jne    a812 <fwp_hof0.constprop.0+0x1802>
    a231:	4d 85 e4             	test   %r12,%r12
    a234:	0f 84 07 f3 ff ff    	je     9541 <fwp_hof0.constprop.0+0x531>
    a23a:	48 c1 e0 04          	shl    $0x4,%rax
    a23e:	4d 01 e4             	add    %r12,%r12
    a241:	49 8d 6d 08          	lea    0x8(%r13),%rbp
    a245:	4d 8d 74 05 f8       	lea    -0x8(%r13,%rax,1),%r14
    a24a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a250:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    a255:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    a259:	48 83 c5 10          	add    $0x10,%rbp
    a25d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    a261:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    a266:	e8 b5 bd ff ff       	call   6020 <w120>
    a26b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a270:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a274:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    a278:	49 39 ee             	cmp    %rbp,%r14
    a27b:	75 d3                	jne    a250 <fwp_hof0.constprop.0+0x1240>
    a27d:	4d 89 65 00          	mov    %r12,0x0(%r13)
    a281:	45 31 f6             	xor    %r14d,%r14d
    a284:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    a28b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a290:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    a297:	00 f0 3f 
    a29a:	4b 8b 54 f5 10       	mov    0x10(%r13,%r14,8),%rdx
    a29f:	49 83 c6 02          	add    $0x2,%r14
    a2a3:	48 89 ce             	mov    %rcx,%rsi
    a2a6:	e8 f5 b9 ff ff       	call   5ca0 <fwp_p_ad_push>
    a2ab:	48 89 c7             	mov    %rax,%rdi
    a2ae:	4d 39 e6             	cmp    %r12,%r14
    a2b1:	72 dd                	jb     a290 <fwp_hof0.constprop.0+0x1280>
    a2b3:	49 89 c1             	mov    %rax,%r9
    a2b6:	e9 95 f2 ff ff       	jmp    9550 <fwp_hof0.constprop.0+0x540>
    a2bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2c0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a2c5:	45 31 c0             	xor    %r8d,%r8d
    a2c8:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a2cd:	48 83 e8 01          	sub    $0x1,%rax
    a2d1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a2d6:	41 0f 90 c0          	seto   %r8b
    a2da:	e9 00 ee ff ff       	jmp    90df <fwp_hof0.constprop.0+0xcf>
    a2df:	90                   	nop
    a2e0:	49 8d 55 01          	lea    0x1(%r13),%rdx
    a2e4:	49 39 d6             	cmp    %rdx,%r14
    a2e7:	7c 3a                	jl     a323 <fwp_hof0.constprop.0+0x1313>
    a2e9:	48 85 c9             	test   %rcx,%rcx
    a2ec:	0f 84 43 05 00 00    	je     a835 <fwp_hof0.constprop.0+0x1825>
    a2f2:	48 89 cf             	mov    %rcx,%rdi
    a2f5:	48 c1 e2 03          	shl    $0x3,%rdx
    a2f9:	31 f6                	xor    %esi,%esi
    a2fb:	0f 29 14 24          	movaps %xmm2,(%rsp)
    a2ff:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    a304:	e8 b7 91 ff ff       	call   34c0 <memset@plt>
    a309:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    a30e:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    a314:	48 89 c1             	mov    %rax,%rcx
    a317:	e9 b2 f3 ff ff       	jmp    96ce <fwp_hof0.constprop.0+0x6be>
    a31c:	0f 1f 40 00          	nopl   0x0(%rax)
    a320:	48 89 ea             	mov    %rbp,%rdx
    a323:	4d 85 f6             	test   %r14,%r14
    a326:	4c 0f 44 f2          	cmove  %rdx,%r14
    a32a:	eb 29                	jmp    a355 <fwp_hof0.constprop.0+0x1345>
    a32c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a333:	00 00 
    a335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a33c:	00 00 00 00 
    a340:	4b 8d 34 36          	lea    (%r14,%r14,1),%rsi
    a344:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    a34b:	48 89 d0             	mov    %rdx,%rax
    a34e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a352:	49 89 c6             	mov    %rax,%r14
    a355:	49 39 d6             	cmp    %rdx,%r14
    a358:	7c e6                	jl     a340 <fwp_hof0.constprop.0+0x1330>
    a35a:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a35f:	4c 89 0c 24          	mov    %r9,(%rsp)
    a363:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a368:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    a36d:	48 85 c9             	test   %rcx,%rcx
    a370:	0f 84 0a 02 00 00    	je     a580 <fwp_hof0.constprop.0+0x1570>
    a376:	48 89 cf             	mov    %rcx,%rdi
    a379:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    a380:	00 
    a381:	e8 4a 92 ff ff       	call   35d0 <realloc@plt>
    a386:	4c 8b 0c 24          	mov    (%rsp),%r9
    a38a:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    a390:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a396:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a39b:	48 89 c1             	mov    %rax,%rcx
    a39e:	48 85 c9             	test   %rcx,%rcx
    a3a1:	0f 84 85 04 00 00    	je     a82c <fwp_hof0.constprop.0+0x181c>
    a3a7:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
    a3ae:	00 
    a3af:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
    a3b6:	00 
    a3b7:	48 85 d2             	test   %rdx,%rdx
    a3ba:	0f 85 79 03 00 00    	jne    a739 <fwp_hof0.constprop.0+0x1729>
    a3c0:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    a3c7:	4d 85 c9             	test   %r9,%r9
    a3ca:	0f 88 12 f3 ff ff    	js     96e2 <fwp_hof0.constprop.0+0x6d2>
    a3d0:	45 89 cd             	mov    %r9d,%r13d
    a3d3:	e9 f6 f2 ff ff       	jmp    96ce <fwp_hof0.constprop.0+0x6be>
    a3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3df:	00 
    a3e0:	48 8d 3d 39 c4 ff ff 	lea    -0x3bc7(%rip),%rdi        # 6820 <fwp_tape_finish>
    a3e7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    a3ec:	e8 2f 3b 00 00       	call   df20 <atexit>
    a3f1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    a3f6:	85 c0                	test   %eax,%eax
    a3f8:	0f 85 d5 04 00 00    	jne    a8d3 <fwp_hof0.constprop.0+0x18c3>
    a3fe:	c7 05 58 7c 00 00 01 	movl   $0x1,0x7c58(%rip)        # 12060 <registered_finish.1>
    a405:	00 00 00 
    a408:	e9 f0 ed ff ff       	jmp    91fd <fwp_hof0.constprop.0+0x1ed>
    a40d:	0f 1f 00             	nopl   (%rax)
    a410:	66 85 c0             	test   %ax,%ax
    a413:	0f 85 17 f9 ff ff    	jne    9d30 <fwp_hof0.constprop.0+0xd20>
    a419:	e9 ec f8 ff ff       	jmp    9d0a <fwp_hof0.constprop.0+0xcfa>
    a41e:	66 90                	xchg   %ax,%ax
    a420:	66 85 c0             	test   %ax,%ax
    a423:	0f 85 89 ed ff ff    	jne    91b2 <fwp_hof0.constprop.0+0x1a2>
    a429:	e9 70 ed ff ff       	jmp    919e <fwp_hof0.constprop.0+0x18e>
    a42e:	66 90                	xchg   %ax,%ax
    a430:	4c 39 f5             	cmp    %r14,%rbp
    a433:	0f 8f e7 fe ff ff    	jg     a320 <fwp_hof0.constprop.0+0x1310>
    a439:	48 85 ed             	test   %rbp,%rbp
    a43c:	74 12                	je     a450 <fwp_hof0.constprop.0+0x1440>
    a43e:	48 85 c9             	test   %rcx,%rcx
    a441:	0f 84 ee 03 00 00    	je     a835 <fwp_hof0.constprop.0+0x1825>
    a447:	48 85 ed             	test   %rbp,%rbp
    a44a:	0f 85 e6 02 00 00    	jne    a736 <fwp_hof0.constprop.0+0x1726>
    a450:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    a457:	e9 86 f2 ff ff       	jmp    96e2 <fwp_hof0.constprop.0+0x6d2>
    a45c:	0f 1f 40 00          	nopl   0x0(%rax)
    a460:	66 85 c0             	test   %ax,%ax
    a463:	0f 85 f5 f3 ff ff    	jne    985e <fwp_hof0.constprop.0+0x84e>
    a469:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a46e:	0f 85 e5 f3 ff ff    	jne    9859 <fwp_hof0.constprop.0+0x849>
    a474:	4c 89 e7             	mov    %r12,%rdi
    a477:	e8 94 ae ff ff       	call   5310 <fwp_rc_forget_slot>
    a47c:	e9 d8 f3 ff ff       	jmp    9859 <fwp_hof0.constprop.0+0x849>
    a481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a488:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    a48d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a492:	e9 fd f7 ff ff       	jmp    9c94 <fwp_hof0.constprop.0+0xc84>
    a497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a49e:	00 00 
    a4a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a4a5:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a4ac:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a4b3:	48 8b 68 10          	mov    0x10(%rax),%rbp
    a4b7:	48 29 c8             	sub    %rcx,%rax
    a4ba:	48 c1 e2 10          	shl    $0x10,%rdx
    a4be:	48 39 d0             	cmp    %rdx,%rax
    a4c1:	73 67                	jae    a52a <fwp_hof0.constprop.0+0x151a>
    a4c3:	48 89 c7             	mov    %rax,%rdi
    a4c6:	48 c1 ef 10          	shr    $0x10,%rdi
    a4ca:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a4ce:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a4d2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a4d6:	48 85 ff             	test   %rdi,%rdi
    a4d9:	74 4f                	je     a52a <fwp_hof0.constprop.0+0x151a>
    a4db:	44 0f b6 06          	movzbl (%rsi),%r8d
    a4df:	41 80 f8 02          	cmp    $0x2,%r8b
    a4e3:	0f 84 9d 01 00 00    	je     a686 <fwp_hof0.constprop.0+0x1676>
    a4e9:	41 80 f8 01          	cmp    $0x1,%r8b
    a4ed:	75 3b                	jne    a52a <fwp_hof0.constprop.0+0x151a>
    a4ef:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a4f3:	0f b7 c0             	movzwl %ax,%eax
    a4f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a4f9:	49 0f af c0          	imul   %r8,%rax
    a4fd:	48 c1 e8 20          	shr    $0x20,%rax
    a501:	48 39 f0             	cmp    %rsi,%rax
    a504:	73 24                	jae    a52a <fwp_hof0.constprop.0+0x151a>
    a506:	48 01 c7             	add    %rax,%rdi
    a509:	80 3f 01             	cmpb   $0x1,(%rdi)
    a50c:	75 1c                	jne    a52a <fwp_hof0.constprop.0+0x151a>
    a50e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a513:	e8 38 b0 ff ff       	call   5550 <fwp_mem_free>
    a518:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a51f:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a526:	48 c1 e2 10          	shl    $0x10,%rdx
    a52a:	48 89 e8             	mov    %rbp,%rax
    a52d:	48 29 c8             	sub    %rcx,%rax
    a530:	48 39 d0             	cmp    %rdx,%rax
    a533:	0f 83 f7 f7 ff ff    	jae    9d30 <fwp_hof0.constprop.0+0xd20>
    a539:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
    a53e:	e9 7e f7 ff ff       	jmp    9cc1 <fwp_hof0.constprop.0+0xcb1>
    a543:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a548:	66 85 c0             	test   %ax,%ax
    a54b:	0f 85 ee fb ff ff    	jne    a13f <fwp_hof0.constprop.0+0x112f>
    a551:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a555:	0f 85 e0 fb ff ff    	jne    a13b <fwp_hof0.constprop.0+0x112b>
    a55b:	48 89 ef             	mov    %rbp,%rdi
    a55e:	e8 ad ad ff ff       	call   5310 <fwp_rc_forget_slot>
    a563:	e9 d3 fb ff ff       	jmp    a13b <fwp_hof0.constprop.0+0x112b>
    a568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a56f:	00 
    a570:	4d 85 e4             	test   %r12,%r12
    a573:	0f 85 52 ef ff ff    	jne    94cb <fwp_hof0.constprop.0+0x4bb>
    a579:	e9 c3 ef ff ff       	jmp    9541 <fwp_hof0.constprop.0+0x531>
    a57e:	66 90                	xchg   %ax,%ax
    a580:	be 08 00 00 00       	mov    $0x8,%esi
    a585:	4c 89 f7             	mov    %r14,%rdi
    a588:	e8 93 8f ff ff       	call   3520 <calloc@plt>
    a58d:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a592:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a598:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    a59e:	4c 8b 0c 24          	mov    (%rsp),%r9
    a5a2:	48 89 c1             	mov    %rax,%rcx
    a5a5:	e9 f4 fd ff ff       	jmp    a39e <fwp_hof0.constprop.0+0x138e>
    a5aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5b0:	66 85 c0             	test   %ax,%ax
    a5b3:	0f 85 10 eb ff ff    	jne    90c9 <fwp_hof0.constprop.0+0xb9>
    a5b9:	e9 f7 ea ff ff       	jmp    90b5 <fwp_hof0.constprop.0+0xa5>
    a5be:	66 90                	xchg   %ax,%ax
    a5c0:	66 85 c0             	test   %ax,%ax
    a5c3:	0f 85 37 f9 ff ff    	jne    9f00 <fwp_hof0.constprop.0+0xef0>
    a5c9:	41 0f b6 04 24       	movzbl (%r12),%eax
    a5ce:	84 c0                	test   %al,%al
    a5d0:	0f 84 2a f9 ff ff    	je     9f00 <fwp_hof0.constprop.0+0xef0>
    a5d6:	3c 01                	cmp    $0x1,%al
    a5d8:	0f 85 12 f9 ff ff    	jne    9ef0 <fwp_hof0.constprop.0+0xee0>
    a5de:	48 89 ef             	mov    %rbp,%rdi
    a5e1:	e8 6a af ff ff       	call   5550 <fwp_mem_free>
    a5e6:	e9 15 f9 ff ff       	jmp    9f00 <fwp_hof0.constprop.0+0xef0>
    a5eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a5f0:	66 85 c0             	test   %ax,%ax
    a5f3:	0f 85 52 f8 ff ff    	jne    9e4b <fwp_hof0.constprop.0+0xe3b>
    a5f9:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a5fe:	0f 85 42 f8 ff ff    	jne    9e46 <fwp_hof0.constprop.0+0xe36>
    a604:	4c 89 ef             	mov    %r13,%rdi
    a607:	e8 04 ad ff ff       	call   5310 <fwp_rc_forget_slot>
    a60c:	e9 35 f8 ff ff       	jmp    9e46 <fwp_hof0.constprop.0+0xe36>
    a611:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a615:	e9 d5 eb ff ff       	jmp    91ef <fwp_hof0.constprop.0+0x1df>
    a61a:	49 8b 04 24          	mov    (%r12),%rax
    a61e:	48 85 c0             	test   %rax,%rax
    a621:	0f 88 da fb ff ff    	js     a201 <fwp_hof0.constprop.0+0x11f1>
    a627:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    a62e:	48 8b 0c 24          	mov    (%rsp),%rcx
    a632:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    a639:	48 c1 e6 10          	shl    $0x10,%rsi
    a63d:	48 39 f1             	cmp    %rsi,%rcx
    a640:	0f 83 bb fb ff ff    	jae    a201 <fwp_hof0.constprop.0+0x11f1>
    a646:	48 89 ce             	mov    %rcx,%rsi
    a649:	48 c1 ee 10          	shr    $0x10,%rsi
    a64d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a651:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    a658:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a65c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a660:	48 85 ff             	test   %rdi,%rdi
    a663:	0f 84 98 fb ff ff    	je     a201 <fwp_hof0.constprop.0+0x11f1>
    a669:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a66e:	49 89 c7             	mov    %rax,%r15
    a671:	e9 7e f3 ff ff       	jmp    99f4 <fwp_hof0.constprop.0+0x9e4>
    a676:	be 68 00 00 00       	mov    $0x68,%esi
    a67b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a681:	e9 f4 eb ff ff       	jmp    927a <fwp_hof0.constprop.0+0x26a>
    a686:	66 85 c0             	test   %ax,%ax
    a689:	0f 85 9b fe ff ff    	jne    a52a <fwp_hof0.constprop.0+0x151a>
    a68f:	e9 75 fe ff ff       	jmp    a509 <fwp_hof0.constprop.0+0x14f9>
    a694:	4c 89 e2             	mov    %r12,%rdx
    a697:	48 c1 ea 11          	shr    $0x11,%rdx
    a69b:	4c 31 e2             	xor    %r12,%rdx
    a69e:	48 89 d0             	mov    %rdx,%rax
    a6a1:	48 c1 e8 09          	shr    $0x9,%rax
    a6a5:	48 31 c2             	xor    %rax,%rdx
    a6a8:	0f b6 d2             	movzbl %dl,%edx
    a6ab:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    a6b2:	00 
    a6b3:	48 85 c0             	test   %rax,%rax
    a6b6:	75 11                	jne    a6c9 <fwp_hof0.constprop.0+0x16b9>
    a6b8:	eb 70                	jmp    a72a <fwp_hof0.constprop.0+0x171a>
    a6ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a6c4:	48 85 c0             	test   %rax,%rax
    a6c7:	74 61                	je     a72a <fwp_hof0.constprop.0+0x171a>
    a6c9:	48 89 c2             	mov    %rax,%rdx
    a6cc:	4c 39 20             	cmp    %r12,(%rax)
    a6cf:	75 ef                	jne    a6c0 <fwp_hof0.constprop.0+0x16b0>
    a6d1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a6d5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a6d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a6dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a6e4:	0f 85 46 f6 ff ff    	jne    9d30 <fwp_hof0.constprop.0+0xd20>
    a6ea:	4c 89 e7             	mov    %r12,%rdi
    a6ed:	e8 1e ac ff ff       	call   5310 <fwp_rc_forget_slot>
    a6f2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    a6f7:	e9 34 f6 ff ff       	jmp    9d30 <fwp_hof0.constprop.0+0xd20>
    a6fc:	e8 ef aa ff ff       	call   51f0 <fwp_rc_wide_dup>
    a701:	e9 ac ea ff ff       	jmp    91b2 <fwp_hof0.constprop.0+0x1a2>
    a706:	4c 89 e0             	mov    %r12,%rax
    a709:	48 c1 e8 11          	shr    $0x11,%rax
    a70d:	4c 31 e0             	xor    %r12,%rax
    a710:	48 89 c2             	mov    %rax,%rdx
    a713:	48 c1 ea 09          	shr    $0x9,%rdx
    a717:	48 31 d0             	xor    %rdx,%rax
    a71a:	0f b6 d0             	movzbl %al,%edx
    a71d:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    a724:	00 
    a725:	48 85 c0             	test   %rax,%rax
    a728:	75 5f                	jne    a789 <fwp_hof0.constprop.0+0x1779>
    a72a:	48 8d 3d 6f 40 00 00 	lea    0x406f(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    a731:	e8 6a 9a ff ff       	call   41a0 <fwp_trap>
    a736:	48 89 ea             	mov    %rbp,%rdx
    a739:	48 89 cf             	mov    %rcx,%rdi
    a73c:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    a740:	31 f6                	xor    %esi,%esi
    a742:	48 c1 e2 03          	shl    $0x3,%rdx
    a746:	4c 89 0c 24          	mov    %r9,(%rsp)
    a74a:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a74f:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    a754:	e8 67 8d ff ff       	call   34c0 <memset@plt>
    a759:	4c 8b 0c 24          	mov    (%rsp),%r9
    a75d:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    a763:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a769:	48 89 c1             	mov    %rax,%rcx
    a76c:	e9 56 fc ff ff       	jmp    a3c7 <fwp_hof0.constprop.0+0x13b7>
    a771:	0f 1f 40 00          	nopl   0x0(%rax)
    a775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a77c:	00 00 00 00 
    a780:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a784:	48 85 c0             	test   %rax,%rax
    a787:	74 a1                	je     a72a <fwp_hof0.constprop.0+0x171a>
    a789:	48 89 c2             	mov    %rax,%rdx
    a78c:	4c 3b 20             	cmp    (%rax),%r12
    a78f:	75 ef                	jne    a780 <fwp_hof0.constprop.0+0x1770>
    a791:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a795:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a799:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a79d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a7a4:	0f 85 56 f7 ff ff    	jne    9f00 <fwp_hof0.constprop.0+0xef0>
    a7aa:	4c 89 e7             	mov    %r12,%rdi
    a7ad:	e8 5e ab ff ff       	call   5310 <fwp_rc_forget_slot>
    a7b2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    a7b7:	e9 44 f7 ff ff       	jmp    9f00 <fwp_hof0.constprop.0+0xef0>
    a7bc:	e8 2f aa ff ff       	call   51f0 <fwp_rc_wide_dup>
    a7c1:	e9 03 e9 ff ff       	jmp    90c9 <fwp_hof0.constprop.0+0xb9>
    a7c6:	45 31 ff             	xor    %r15d,%r15d
    a7c9:	e9 87 f3 ff ff       	jmp    9b55 <fwp_hof0.constprop.0+0xb45>
    a7ce:	48 8d 3d f3 3f 00 00 	lea    0x3ff3(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    a7d5:	e8 c6 99 ff ff       	call   41a0 <fwp_trap>
    a7da:	48 8d 3d 23 39 00 00 	lea    0x3923(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    a7e1:	e8 ba 99 ff ff       	call   41a0 <fwp_trap>
    a7e6:	48 8d 3d b3 40 00 00 	lea    0x40b3(%rip),%rdi        # e8a0 <_IO_stdin_used+0x8a0>
    a7ed:	e8 ae 99 ff ff       	call   41a0 <fwp_trap>
    a7f2:	45 31 ed             	xor    %r13d,%r13d
    a7f5:	e9 19 fa ff ff       	jmp    a213 <fwp_hof0.constprop.0+0x1203>
    a7fa:	48 8d 3d bd 39 00 00 	lea    0x39bd(%rip),%rdi        # e1be <_IO_stdin_used+0x1be>
    a801:	e8 9a 99 ff ff       	call   41a0 <fwp_trap>
    a806:	48 8d 3d cb 39 00 00 	lea    0x39cb(%rip),%rdi        # e1d8 <_IO_stdin_used+0x1d8>
    a80d:	e8 8e 99 ff ff       	call   41a0 <fwp_trap>
    a812:	48 8d 3d 14 39 00 00 	lea    0x3914(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    a819:	e8 82 99 ff ff       	call   41a0 <fwp_trap>
    a81e:	66 90                	xchg   %ax,%ax
    a820:	48 8d 3d a1 40 00 00 	lea    0x40a1(%rip),%rdi        # e8c8 <_IO_stdin_used+0x8c8>
    a827:	e8 74 99 ff ff       	call   41a0 <fwp_trap>
    a82c:	48 85 d2             	test   %rdx,%rdx
    a82f:	0f 84 8b fb ff ff    	je     a3c0 <fwp_hof0.constprop.0+0x13b0>
    a835:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    a83c:	00 
    a83d:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a842:	48 89 05 af 9b 01 00 	mov    %rax,0x19baf(%rip)        # 243f8 <fwp_cleanups>
    a849:	e8 e2 a5 ff ff       	call   4e30 <fwp_tape_buffers_release>
    a84e:	ba 13 00 00 00       	mov    $0x13,%edx
    a853:	48 8b 0d e6 77 00 00 	mov    0x77e6(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a85a:	be 01 00 00 00       	mov    $0x1,%esi
    a85f:	48 8d 3d a2 37 00 00 	lea    0x37a2(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a866:	e8 15 8e ff ff       	call   3680 <fwrite@plt>
    a86b:	31 ff                	xor    %edi,%edi
    a86d:	e8 4e 8d ff ff       	call   35c0 <fflush@plt>
    a872:	bf 66 00 00 00       	mov    $0x66,%edi
    a877:	e8 24 8e ff ff       	call   36a0 <_Exit@plt>
    a87c:	48 8d 3d ed 3f 00 00 	lea    0x3fed(%rip),%rdi        # e870 <_IO_stdin_used+0x870>
    a883:	e8 18 99 ff ff       	call   41a0 <fwp_trap>
    a888:	48 8b 0d b1 77 00 00 	mov    0x77b1(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a88f:	ba 13 00 00 00       	mov    $0x13,%edx
    a894:	be 01 00 00 00       	mov    $0x1,%esi
    a899:	48 8d 3d 68 37 00 00 	lea    0x3768(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a8a0:	e8 db 8d ff ff       	call   3680 <fwrite@plt>
    a8a5:	31 ff                	xor    %edi,%edi
    a8a7:	e8 14 8d ff ff       	call   35c0 <fflush@plt>
    a8ac:	bf 66 00 00 00       	mov    $0x66,%edi
    a8b1:	e8 ea 8d ff ff       	call   36a0 <_Exit@plt>
    a8b6:	48 8d 3d 53 3f 00 00 	lea    0x3f53(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    a8bd:	e8 de 98 ff ff       	call   41a0 <fwp_trap>
    a8c2:	e8 99 8b ff ff       	call   3460 <__stack_chk_fail@plt>
    a8c7:	48 8d 3d 1a 39 00 00 	lea    0x391a(%rip),%rdi        # e1e8 <_IO_stdin_used+0x1e8>
    a8ce:	e8 cd 98 ff ff       	call   41a0 <fwp_trap>
    a8d3:	48 8b 0d 66 77 00 00 	mov    0x7766(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a8da:	ba 13 00 00 00       	mov    $0x13,%edx
    a8df:	be 01 00 00 00       	mov    $0x1,%esi
    a8e4:	48 8d 3d 1d 37 00 00 	lea    0x371d(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a8eb:	e8 90 8d ff ff       	call   3680 <fwrite@plt>
    a8f0:	31 ff                	xor    %edi,%edi
    a8f2:	e8 c9 8c ff ff       	call   35c0 <fflush@plt>
    a8f7:	bf 66 00 00 00       	mov    $0x66,%edi
    a8fc:	e8 9f 8d ff ff       	call   36a0 <_Exit@plt>
    a901:	0f 1f 40 00          	nopl   0x0(%rax)
    a905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a90c:	00 00 00 00 

000000000000a910 <f0>:
    a910:	41 56                	push   %r14
    a912:	4c 8d 35 47 7e 01 00 	lea    0x17e47(%rip),%r14        # 22760 <fwp_heap>
    a919:	41 55                	push   %r13
    a91b:	41 54                	push   %r12
    a91d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    a923:	55                   	push   %rbp
    a924:	53                   	push   %rbx
    a925:	31 db                	xor    %ebx,%ebx
    a927:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    a92e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a935:	00 00 
    a937:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    a93e:	00 
    a93f:	31 c0                	xor    %eax,%eax
    a941:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    a948:	00 
    a949:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    a950:	00 00 
    a952:	66 48 0f 6e c0       	movq   %rax,%xmm0
    a957:	48 8d 05 d2 cc ff ff 	lea    -0x332e(%rip),%rax        # 7630 <fwp_drop1>
    a95e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    a963:	48 8b 05 8e 9a 01 00 	mov    0x19a8e(%rip),%rax        # 243f8 <fwp_cleanups>
    a96a:	48 89 25 87 9a 01 00 	mov    %rsp,0x19a87(%rip)        # 243f8 <fwp_cleanups>
    a971:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    a975:	48 89 04 24          	mov    %rax,(%rsp)
    a979:	48 8d 05 50 92 ff ff 	lea    -0x6db0(%rip),%rax        # 3bd0 <fwp_range_release>
    a980:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a985:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    a98a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a98f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    a994:	eb 47                	jmp    a9dd <f0+0xcd>
    a996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a99d:	00 00 00 
    a9a0:	80 f9 01             	cmp    $0x1,%cl
    a9a3:	75 29                	jne    a9ce <f0+0xbe>
    a9a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9a8:	0f b7 c0             	movzwl %ax,%eax
    a9ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9ae:	48 0f af c1          	imul   %rcx,%rax
    a9b2:	48 c1 e8 20          	shr    $0x20,%rax
    a9b6:	48 39 d0             	cmp    %rdx,%rax
    a9b9:	73 13                	jae    a9ce <f0+0xbe>
    a9bb:	49 01 c5             	add    %rax,%r13
    a9be:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a9c3:	0f 84 c7 27 00 00    	je     d190 <f0+0x2880>
    a9c9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a9ce:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    a9d3:	49 83 ec 01          	sub    $0x1,%r12
    a9d7:	0f 82 83 00 00 00    	jb     aa60 <f0+0x150>
    a9dd:	48 89 ee             	mov    %rbp,%rsi
    a9e0:	bf 01 00 00 00       	mov    $0x1,%edi
    a9e5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    a9ec:	00 
    a9ed:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    a9f2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    a9f9:	00 
    a9fa:	e8 71 b1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    a9ff:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    aa06:	48 89 c3             	mov    %rax,%rbx
    aa09:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    aa10:	48 c1 e2 10          	shl    $0x10,%rdx
    aa14:	48 39 d0             	cmp    %rdx,%rax
    aa17:	73 b5                	jae    a9ce <f0+0xbe>
    aa19:	48 89 c2             	mov    %rax,%rdx
    aa1c:	48 c1 ea 10          	shr    $0x10,%rdx
    aa20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa24:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    aa2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa2f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    aa33:	4d 85 ed             	test   %r13,%r13
    aa36:	74 96                	je     a9ce <f0+0xbe>
    aa38:	0f b6 0a             	movzbl (%rdx),%ecx
    aa3b:	80 f9 02             	cmp    $0x2,%cl
    aa3e:	0f 85 5c ff ff ff    	jne    a9a0 <f0+0x90>
    aa44:	66 85 c0             	test   %ax,%ax
    aa47:	0f 84 71 ff ff ff    	je     a9be <f0+0xae>
    aa4d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    aa52:	49 83 ec 01          	sub    $0x1,%r12
    aa56:	73 85                	jae    a9dd <f0+0xcd>
    aa58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa5f:	00 
    aa60:	48 8b 04 24          	mov    (%rsp),%rax
    aa64:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    aa69:	bf 01 00 00 00       	mov    $0x1,%edi
    aa6e:	66 0f 6f 05 da 40 00 	movdqa 0x40da(%rip),%xmm0        # eb50 <msg.4+0xd0>
    aa75:	00 
    aa76:	48 89 05 7b 99 01 00 	mov    %rax,0x1997b(%rip)        # 243f8 <fwp_cleanups>
    aa7d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    aa82:	e8 e9 b0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aa87:	48 8b 15 aa 90 01 00 	mov    0x190aa(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    aa8e:	49 89 c5             	mov    %rax,%r13
    aa91:	48 2b 05 78 90 01 00 	sub    0x19078(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    aa98:	48 c1 e2 10          	shl    $0x10,%rdx
    aa9c:	48 39 d0             	cmp    %rdx,%rax
    aa9f:	73 59                	jae    aafa <f0+0x1ea>
    aaa1:	48 89 c2             	mov    %rax,%rdx
    aaa4:	48 c1 ea 10          	shr    $0x10,%rdx
    aaa8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aaac:	48 8b 15 a5 90 01 00 	mov    0x190a5(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    aab3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aab7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aabb:	4d 85 e4             	test   %r12,%r12
    aabe:	74 3a                	je     aafa <f0+0x1ea>
    aac0:	0f b6 0a             	movzbl (%rdx),%ecx
    aac3:	80 f9 02             	cmp    $0x2,%cl
    aac6:	0f 84 74 27 00 00    	je     d240 <f0+0x2930>
    aacc:	80 f9 01             	cmp    $0x1,%cl
    aacf:	75 29                	jne    aafa <f0+0x1ea>
    aad1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aad4:	0f b7 c0             	movzwl %ax,%eax
    aad7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aada:	48 0f af c1          	imul   %rcx,%rax
    aade:	48 c1 e8 20          	shr    $0x20,%rax
    aae2:	48 39 d0             	cmp    %rdx,%rax
    aae5:	73 13                	jae    aafa <f0+0x1ea>
    aae7:	49 01 c4             	add    %rax,%r12
    aaea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aaef:	0f 84 26 29 00 00    	je     d41b <f0+0x2b0b>
    aaf5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    aafa:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    aaff:	bf 01 00 00 00       	mov    $0x1,%edi
    ab04:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    ab09:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ab10:	00 f0 3f 
    ab13:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    ab18:	e8 53 b0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ab1d:	48 8b 15 14 90 01 00 	mov    0x19014(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ab24:	49 89 c5             	mov    %rax,%r13
    ab27:	48 2b 05 e2 8f 01 00 	sub    0x18fe2(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ab2e:	48 c1 e2 10          	shl    $0x10,%rdx
    ab32:	48 39 d0             	cmp    %rdx,%rax
    ab35:	73 59                	jae    ab90 <f0+0x280>
    ab37:	48 89 c2             	mov    %rax,%rdx
    ab3a:	48 c1 ea 10          	shr    $0x10,%rdx
    ab3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab42:	48 8b 15 0f 90 01 00 	mov    0x1900f(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ab49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ab51:	4d 85 e4             	test   %r12,%r12
    ab54:	74 3a                	je     ab90 <f0+0x280>
    ab56:	0f b6 0a             	movzbl (%rdx),%ecx
    ab59:	80 f9 02             	cmp    $0x2,%cl
    ab5c:	0f 84 ce 26 00 00    	je     d230 <f0+0x2920>
    ab62:	80 f9 01             	cmp    $0x1,%cl
    ab65:	75 29                	jne    ab90 <f0+0x280>
    ab67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab6a:	0f b7 c0             	movzwl %ax,%eax
    ab6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab70:	48 0f af c1          	imul   %rcx,%rax
    ab74:	48 c1 e8 20          	shr    $0x20,%rax
    ab78:	48 39 d0             	cmp    %rdx,%rax
    ab7b:	73 13                	jae    ab90 <f0+0x280>
    ab7d:	49 01 c4             	add    %rax,%r12
    ab80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ab85:	0f 84 9d 28 00 00    	je     d428 <f0+0x2b18>
    ab8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ab90:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    ab95:	bf 01 00 00 00       	mov    $0x1,%edi
    ab9a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    ab9f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    aba6:	33 f3 bf 
    aba9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    abae:	e8 bd af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    abb3:	48 8b 15 7e 8f 01 00 	mov    0x18f7e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    abba:	49 89 c5             	mov    %rax,%r13
    abbd:	48 2b 05 4c 8f 01 00 	sub    0x18f4c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    abc4:	48 c1 e2 10          	shl    $0x10,%rdx
    abc8:	48 39 d0             	cmp    %rdx,%rax
    abcb:	73 59                	jae    ac26 <f0+0x316>
    abcd:	48 89 c2             	mov    %rax,%rdx
    abd0:	48 c1 ea 10          	shr    $0x10,%rdx
    abd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    abd8:	48 8b 15 79 8f 01 00 	mov    0x18f79(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    abdf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    abe3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    abe7:	4d 85 e4             	test   %r12,%r12
    abea:	74 3a                	je     ac26 <f0+0x316>
    abec:	0f b6 0a             	movzbl (%rdx),%ecx
    abef:	80 f9 02             	cmp    $0x2,%cl
    abf2:	0f 84 28 26 00 00    	je     d220 <f0+0x2910>
    abf8:	80 f9 01             	cmp    $0x1,%cl
    abfb:	75 29                	jne    ac26 <f0+0x316>
    abfd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac00:	0f b7 c0             	movzwl %ax,%eax
    ac03:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac06:	48 0f af c1          	imul   %rcx,%rax
    ac0a:	48 c1 e8 20          	shr    $0x20,%rax
    ac0e:	48 39 d0             	cmp    %rdx,%rax
    ac11:	73 13                	jae    ac26 <f0+0x316>
    ac13:	49 01 c4             	add    %rax,%r12
    ac16:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ac1b:	0f 84 14 28 00 00    	je     d435 <f0+0x2b25>
    ac21:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ac26:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    ac2b:	bf 01 00 00 00       	mov    $0x1,%edi
    ac30:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ac35:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ac3c:	00 f0 3f 
    ac3f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ac44:	e8 27 af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ac49:	48 8b 15 e8 8e 01 00 	mov    0x18ee8(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ac50:	49 89 c5             	mov    %rax,%r13
    ac53:	48 2b 05 b6 8e 01 00 	sub    0x18eb6(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ac5a:	48 c1 e2 10          	shl    $0x10,%rdx
    ac5e:	48 39 d0             	cmp    %rdx,%rax
    ac61:	73 59                	jae    acbc <f0+0x3ac>
    ac63:	48 89 c2             	mov    %rax,%rdx
    ac66:	48 c1 ea 10          	shr    $0x10,%rdx
    ac6a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac6e:	48 8b 15 e3 8e 01 00 	mov    0x18ee3(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ac75:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac79:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac7d:	4d 85 e4             	test   %r12,%r12
    ac80:	74 3a                	je     acbc <f0+0x3ac>
    ac82:	0f b6 0a             	movzbl (%rdx),%ecx
    ac85:	80 f9 02             	cmp    $0x2,%cl
    ac88:	0f 84 f2 25 00 00    	je     d280 <f0+0x2970>
    ac8e:	80 f9 01             	cmp    $0x1,%cl
    ac91:	75 29                	jne    acbc <f0+0x3ac>
    ac93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac96:	0f b7 c0             	movzwl %ax,%eax
    ac99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac9c:	48 0f af c1          	imul   %rcx,%rax
    aca0:	48 c1 e8 20          	shr    $0x20,%rax
    aca4:	48 39 d0             	cmp    %rdx,%rax
    aca7:	73 13                	jae    acbc <f0+0x3ac>
    aca9:	49 01 c4             	add    %rax,%r12
    acac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    acb1:	0f 84 8b 27 00 00    	je     d442 <f0+0x2b32>
    acb7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    acbc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    acc3:	33 f3 bf 
    acc6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    accd:	00 
    acce:	bf 01 00 00 00       	mov    $0x1,%edi
    acd3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    acda:	00 
    acdb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ace2:	00 
    ace3:	e8 88 ae ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ace8:	48 8b 15 49 8e 01 00 	mov    0x18e49(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    acef:	49 89 c5             	mov    %rax,%r13
    acf2:	48 2b 05 17 8e 01 00 	sub    0x18e17(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    acf9:	48 c1 e2 10          	shl    $0x10,%rdx
    acfd:	48 39 d0             	cmp    %rdx,%rax
    ad00:	73 59                	jae    ad5b <f0+0x44b>
    ad02:	48 89 c2             	mov    %rax,%rdx
    ad05:	48 c1 ea 10          	shr    $0x10,%rdx
    ad09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad0d:	48 8b 15 44 8e 01 00 	mov    0x18e44(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ad14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad18:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad1c:	4d 85 e4             	test   %r12,%r12
    ad1f:	74 3a                	je     ad5b <f0+0x44b>
    ad21:	0f b6 0a             	movzbl (%rdx),%ecx
    ad24:	80 f9 02             	cmp    $0x2,%cl
    ad27:	0f 84 43 25 00 00    	je     d270 <f0+0x2960>
    ad2d:	80 f9 01             	cmp    $0x1,%cl
    ad30:	75 29                	jne    ad5b <f0+0x44b>
    ad32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad35:	0f b7 c0             	movzwl %ax,%eax
    ad38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad3b:	48 0f af c1          	imul   %rcx,%rax
    ad3f:	48 c1 e8 20          	shr    $0x20,%rax
    ad43:	48 39 d0             	cmp    %rdx,%rax
    ad46:	73 13                	jae    ad5b <f0+0x44b>
    ad48:	49 01 c4             	add    %rax,%r12
    ad4b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad50:	0f 84 f9 26 00 00    	je     d44f <f0+0x2b3f>
    ad56:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad5b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    ad62:	00 f0 3f 
    ad65:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    ad6c:	00 
    ad6d:	bf 01 00 00 00       	mov    $0x1,%edi
    ad72:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    ad79:	00 
    ad7a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    ad81:	00 
    ad82:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    ad89:	33 f3 bf 
    ad8c:	e8 df ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ad91:	48 89 c7             	mov    %rax,%rdi
    ad94:	e8 77 b4 ff ff       	call   6210 <fwp_rc_fresh>
    ad99:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    ada0:	00 
    ada1:	bf 01 00 00 00       	mov    $0x1,%edi
    ada6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    adad:	00 
    adae:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    adb5:	00 
    adb6:	e8 b5 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    adbb:	48 89 c7             	mov    %rax,%rdi
    adbe:	e8 4d b4 ff ff       	call   6210 <fwp_rc_fresh>
    adc3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    adca:	00 
    adcb:	bf 01 00 00 00       	mov    $0x1,%edi
    add0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    add7:	00 
    add8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    addf:	00 
    ade0:	e8 8b ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ade5:	48 89 c7             	mov    %rax,%rdi
    ade8:	e8 23 b4 ff ff       	call   6210 <fwp_rc_fresh>
    aded:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    adf4:	00 
    adf5:	bf 01 00 00 00       	mov    $0x1,%edi
    adfa:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    ae01:	00 
    ae02:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ae09:	00 
    ae0a:	e8 61 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae0f:	48 89 c7             	mov    %rax,%rdi
    ae12:	e8 f9 b3 ff ff       	call   6210 <fwp_rc_fresh>
    ae17:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    ae1e:	00 
    ae1f:	bf 01 00 00 00       	mov    $0x1,%edi
    ae24:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    ae2b:	00 
    ae2c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    ae33:	00 
    ae34:	e8 37 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae39:	48 89 c7             	mov    %rax,%rdi
    ae3c:	e8 cf b3 ff ff       	call   6210 <fwp_rc_fresh>
    ae41:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    ae48:	00 
    ae49:	bf 01 00 00 00       	mov    $0x1,%edi
    ae4e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    ae55:	00 
    ae56:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    ae5d:	00 
    ae5e:	e8 0d ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae63:	48 89 c7             	mov    %rax,%rdi
    ae66:	e8 a5 b3 ff ff       	call   6210 <fwp_rc_fresh>
    ae6b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    ae72:	00 
    ae73:	bf 01 00 00 00       	mov    $0x1,%edi
    ae78:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    ae7f:	00 
    ae80:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    ae87:	00 
    ae88:	e8 e3 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae8d:	48 89 c7             	mov    %rax,%rdi
    ae90:	e8 7b b3 ff ff       	call   6210 <fwp_rc_fresh>
    ae95:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    ae9c:	00 
    ae9d:	bf 01 00 00 00       	mov    $0x1,%edi
    aea2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    aea9:	00 
    aeaa:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    aeb1:	00 
    aeb2:	e8 b9 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aeb7:	48 89 c7             	mov    %rax,%rdi
    aeba:	e8 51 b3 ff ff       	call   6210 <fwp_rc_fresh>
    aebf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    aec6:	00 
    aec7:	bf 01 00 00 00       	mov    $0x1,%edi
    aecc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    aed3:	00 
    aed4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    aedb:	00 
    aedc:	e8 8f ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aee1:	48 89 c7             	mov    %rax,%rdi
    aee4:	e8 27 b3 ff ff       	call   6210 <fwp_rc_fresh>
    aee9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    aef0:	00 
    aef1:	bf 01 00 00 00       	mov    $0x1,%edi
    aef6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    aefd:	00 
    aefe:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    af05:	00 
    af06:	e8 65 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af0b:	48 89 c7             	mov    %rax,%rdi
    af0e:	e8 fd b2 ff ff       	call   6210 <fwp_rc_fresh>
    af13:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    af1a:	00 
    af1b:	bf 01 00 00 00       	mov    $0x1,%edi
    af20:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    af27:	00 
    af28:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    af2f:	00 
    af30:	e8 3b ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af35:	48 89 c7             	mov    %rax,%rdi
    af38:	e8 d3 b2 ff ff       	call   6210 <fwp_rc_fresh>
    af3d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    af44:	00 
    af45:	bf 01 00 00 00       	mov    $0x1,%edi
    af4a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    af51:	00 
    af52:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    af59:	00 
    af5a:	e8 11 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af5f:	48 89 c7             	mov    %rax,%rdi
    af62:	e8 a9 b2 ff ff       	call   6210 <fwp_rc_fresh>
    af67:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    af6e:	00 
    af6f:	bf 01 00 00 00       	mov    $0x1,%edi
    af74:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    af7b:	00 
    af7c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    af83:	00 
    af84:	e8 e7 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af89:	48 89 c7             	mov    %rax,%rdi
    af8c:	e8 7f b2 ff ff       	call   6210 <fwp_rc_fresh>
    af91:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    af98:	00 
    af99:	bf 01 00 00 00       	mov    $0x1,%edi
    af9e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    afa5:	00 
    afa6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    afad:	00 
    afae:	e8 bd ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afb3:	48 89 c7             	mov    %rax,%rdi
    afb6:	e8 55 b2 ff ff       	call   6210 <fwp_rc_fresh>
    afbb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    afc2:	00 
    afc3:	bf 01 00 00 00       	mov    $0x1,%edi
    afc8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    afcf:	00 
    afd0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    afd7:	00 
    afd8:	e8 93 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afdd:	48 89 c7             	mov    %rax,%rdi
    afe0:	e8 2b b2 ff ff       	call   6210 <fwp_rc_fresh>
    afe5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    afec:	00 
    afed:	bf 01 00 00 00       	mov    $0x1,%edi
    aff2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    aff9:	00 
    affa:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b001:	00 
    b002:	e8 69 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b007:	48 89 c7             	mov    %rax,%rdi
    b00a:	e8 01 b2 ff ff       	call   6210 <fwp_rc_fresh>
    b00f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b016:	00 
    b017:	bf 01 00 00 00       	mov    $0x1,%edi
    b01c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b023:	00 
    b024:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b02b:	00 
    b02c:	e8 3f ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b031:	48 89 c7             	mov    %rax,%rdi
    b034:	e8 d7 b1 ff ff       	call   6210 <fwp_rc_fresh>
    b039:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b040:	00 
    b041:	bf 01 00 00 00       	mov    $0x1,%edi
    b046:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b04d:	00 
    b04e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b055:	00 
    b056:	e8 15 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b05b:	48 89 c7             	mov    %rax,%rdi
    b05e:	e8 ad b1 ff ff       	call   6210 <fwp_rc_fresh>
    b063:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b06a:	00 
    b06b:	bf 01 00 00 00       	mov    $0x1,%edi
    b070:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b077:	00 
    b078:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b07f:	00 
    b080:	e8 eb aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b085:	48 89 c7             	mov    %rax,%rdi
    b088:	e8 83 b1 ff ff       	call   6210 <fwp_rc_fresh>
    b08d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b094:	00 
    b095:	bf 01 00 00 00       	mov    $0x1,%edi
    b09a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b0a1:	00 
    b0a2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b0a9:	00 
    b0aa:	e8 c1 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0af:	48 89 c7             	mov    %rax,%rdi
    b0b2:	e8 59 b1 ff ff       	call   6210 <fwp_rc_fresh>
    b0b7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b0be:	00 
    b0bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b0c4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b0cb:	00 
    b0cc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b0d3:	00 
    b0d4:	e8 97 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0d9:	48 89 c7             	mov    %rax,%rdi
    b0dc:	e8 2f b1 ff ff       	call   6210 <fwp_rc_fresh>
    b0e1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b0e8:	00 
    b0e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b0ee:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b0f5:	00 
    b0f6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b0fd:	00 
    b0fe:	e8 6d aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b103:	48 89 c7             	mov    %rax,%rdi
    b106:	e8 05 b1 ff ff       	call   6210 <fwp_rc_fresh>
    b10b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b112:	00 
    b113:	bf 01 00 00 00       	mov    $0x1,%edi
    b118:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b11f:	00 
    b120:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b127:	00 
    b128:	e8 43 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b12d:	48 89 c7             	mov    %rax,%rdi
    b130:	e8 db b0 ff ff       	call   6210 <fwp_rc_fresh>
    b135:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b13c:	00 
    b13d:	bf 01 00 00 00       	mov    $0x1,%edi
    b142:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b149:	00 
    b14a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b151:	00 
    b152:	e8 19 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b157:	48 89 c7             	mov    %rax,%rdi
    b15a:	e8 b1 b0 ff ff       	call   6210 <fwp_rc_fresh>
    b15f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b166:	00 
    b167:	bf 01 00 00 00       	mov    $0x1,%edi
    b16c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b173:	00 
    b174:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b17b:	00 
    b17c:	e8 ef a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b181:	48 89 c7             	mov    %rax,%rdi
    b184:	e8 87 b0 ff ff       	call   6210 <fwp_rc_fresh>
    b189:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b190:	00 
    b191:	bf 01 00 00 00       	mov    $0x1,%edi
    b196:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b19d:	00 
    b19e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b1a5:	00 
    b1a6:	e8 c5 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1ab:	48 89 c7             	mov    %rax,%rdi
    b1ae:	e8 5d b0 ff ff       	call   6210 <fwp_rc_fresh>
    b1b3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b1ba:	00 
    b1bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b1c0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b1c7:	00 
    b1c8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b1cf:	00 
    b1d0:	e8 9b a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1d5:	48 89 c7             	mov    %rax,%rdi
    b1d8:	e8 33 b0 ff ff       	call   6210 <fwp_rc_fresh>
    b1dd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b1e4:	00 
    b1e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b1ea:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b1f1:	00 
    b1f2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b1f9:	00 
    b1fa:	e8 71 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1ff:	48 89 c7             	mov    %rax,%rdi
    b202:	e8 09 b0 ff ff       	call   6210 <fwp_rc_fresh>
    b207:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b20e:	00 
    b20f:	bf 01 00 00 00       	mov    $0x1,%edi
    b214:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b21b:	00 
    b21c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b223:	00 
    b224:	e8 47 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b229:	48 89 c7             	mov    %rax,%rdi
    b22c:	e8 df af ff ff       	call   6210 <fwp_rc_fresh>
    b231:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b238:	00 
    b239:	bf 01 00 00 00       	mov    $0x1,%edi
    b23e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b245:	00 
    b246:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b24d:	00 
    b24e:	e8 1d a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b253:	48 89 c7             	mov    %rax,%rdi
    b256:	e8 b5 af ff ff       	call   6210 <fwp_rc_fresh>
    b25b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b262:	00 
    b263:	bf 01 00 00 00       	mov    $0x1,%edi
    b268:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b26f:	00 
    b270:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b277:	00 
    b278:	e8 f3 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b27d:	48 89 c7             	mov    %rax,%rdi
    b280:	e8 8b af ff ff       	call   6210 <fwp_rc_fresh>
    b285:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b28c:	00 
    b28d:	bf 01 00 00 00       	mov    $0x1,%edi
    b292:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b299:	00 
    b29a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b2a1:	00 
    b2a2:	e8 c9 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2a7:	48 89 c7             	mov    %rax,%rdi
    b2aa:	e8 61 af ff ff       	call   6210 <fwp_rc_fresh>
    b2af:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b2b6:	00 
    b2b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b2bc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b2c3:	00 
    b2c4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b2cb:	00 
    b2cc:	e8 9f a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2d1:	48 89 c7             	mov    %rax,%rdi
    b2d4:	e8 37 af ff ff       	call   6210 <fwp_rc_fresh>
    b2d9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b2e0:	00 
    b2e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b2e6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b2ed:	00 
    b2ee:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b2f5:	00 
    b2f6:	e8 75 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2fb:	48 89 c7             	mov    %rax,%rdi
    b2fe:	e8 0d af ff ff       	call   6210 <fwp_rc_fresh>
    b303:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b30a:	00 
    b30b:	bf 01 00 00 00       	mov    $0x1,%edi
    b310:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b317:	00 
    b318:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b31f:	00 
    b320:	e8 4b a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b325:	48 89 c7             	mov    %rax,%rdi
    b328:	e8 e3 ae ff ff       	call   6210 <fwp_rc_fresh>
    b32d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b334:	00 
    b335:	bf 01 00 00 00       	mov    $0x1,%edi
    b33a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b341:	00 
    b342:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b349:	00 
    b34a:	e8 21 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b34f:	48 89 c7             	mov    %rax,%rdi
    b352:	e8 b9 ae ff ff       	call   6210 <fwp_rc_fresh>
    b357:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b35e:	00 
    b35f:	bf 01 00 00 00       	mov    $0x1,%edi
    b364:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b36b:	00 
    b36c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b373:	00 
    b374:	e8 f7 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b379:	48 89 c7             	mov    %rax,%rdi
    b37c:	e8 8f ae ff ff       	call   6210 <fwp_rc_fresh>
    b381:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b388:	00 
    b389:	bf 01 00 00 00       	mov    $0x1,%edi
    b38e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b395:	00 
    b396:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b39d:	00 
    b39e:	e8 cd a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3a3:	48 89 c7             	mov    %rax,%rdi
    b3a6:	e8 65 ae ff ff       	call   6210 <fwp_rc_fresh>
    b3ab:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b3b2:	00 
    b3b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b3b8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b3bf:	00 
    b3c0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b3c7:	00 
    b3c8:	e8 a3 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3cd:	48 89 c7             	mov    %rax,%rdi
    b3d0:	e8 3b ae ff ff       	call   6210 <fwp_rc_fresh>
    b3d5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b3dc:	00 
    b3dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b3e2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b3e9:	00 
    b3ea:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b3f1:	00 
    b3f2:	e8 79 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3f7:	48 89 c7             	mov    %rax,%rdi
    b3fa:	e8 11 ae ff ff       	call   6210 <fwp_rc_fresh>
    b3ff:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b406:	00 
    b407:	bf 01 00 00 00       	mov    $0x1,%edi
    b40c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b413:	00 
    b414:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b41b:	00 
    b41c:	e8 4f a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b421:	48 89 c7             	mov    %rax,%rdi
    b424:	e8 e7 ad ff ff       	call   6210 <fwp_rc_fresh>
    b429:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b430:	00 
    b431:	bf 01 00 00 00       	mov    $0x1,%edi
    b436:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b43d:	00 
    b43e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b445:	00 
    b446:	e8 25 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b44b:	48 89 c7             	mov    %rax,%rdi
    b44e:	e8 bd ad ff ff       	call   6210 <fwp_rc_fresh>
    b453:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b45a:	00 
    b45b:	bf 01 00 00 00       	mov    $0x1,%edi
    b460:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b467:	00 
    b468:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b46f:	00 
    b470:	e8 fb a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b475:	48 89 c7             	mov    %rax,%rdi
    b478:	e8 93 ad ff ff       	call   6210 <fwp_rc_fresh>
    b47d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b484:	00 
    b485:	bf 01 00 00 00       	mov    $0x1,%edi
    b48a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b491:	00 
    b492:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b499:	00 
    b49a:	e8 d1 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b49f:	48 89 c7             	mov    %rax,%rdi
    b4a2:	e8 69 ad ff ff       	call   6210 <fwp_rc_fresh>
    b4a7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b4ae:	00 
    b4af:	bf 01 00 00 00       	mov    $0x1,%edi
    b4b4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b4bb:	00 
    b4bc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b4c3:	00 
    b4c4:	e8 a7 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4c9:	48 89 c7             	mov    %rax,%rdi
    b4cc:	e8 3f ad ff ff       	call   6210 <fwp_rc_fresh>
    b4d1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b4d8:	00 
    b4d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b4de:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b4e5:	00 
    b4e6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b4ed:	00 
    b4ee:	e8 7d a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4f3:	48 89 c7             	mov    %rax,%rdi
    b4f6:	e8 15 ad ff ff       	call   6210 <fwp_rc_fresh>
    b4fb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b502:	00 
    b503:	bf 01 00 00 00       	mov    $0x1,%edi
    b508:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b50f:	00 
    b510:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b517:	00 
    b518:	e8 53 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b51d:	48 89 c7             	mov    %rax,%rdi
    b520:	e8 eb ac ff ff       	call   6210 <fwp_rc_fresh>
    b525:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b52c:	00 
    b52d:	bf 01 00 00 00       	mov    $0x1,%edi
    b532:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b539:	00 
    b53a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b541:	00 
    b542:	e8 29 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b547:	48 89 c7             	mov    %rax,%rdi
    b54a:	e8 c1 ac ff ff       	call   6210 <fwp_rc_fresh>
    b54f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b556:	00 
    b557:	bf 01 00 00 00       	mov    $0x1,%edi
    b55c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b563:	00 
    b564:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b56b:	00 
    b56c:	e8 ff a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b571:	48 89 c7             	mov    %rax,%rdi
    b574:	e8 97 ac ff ff       	call   6210 <fwp_rc_fresh>
    b579:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b580:	00 
    b581:	bf 01 00 00 00       	mov    $0x1,%edi
    b586:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b58d:	00 
    b58e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b595:	00 
    b596:	e8 d5 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b59b:	48 89 c7             	mov    %rax,%rdi
    b59e:	e8 6d ac ff ff       	call   6210 <fwp_rc_fresh>
    b5a3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b5aa:	00 
    b5ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b5b7:	00 
    b5b8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b5bf:	00 
    b5c0:	e8 ab a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5c5:	48 89 c7             	mov    %rax,%rdi
    b5c8:	e8 43 ac ff ff       	call   6210 <fwp_rc_fresh>
    b5cd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b5d4:	00 
    b5d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b5da:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b5e1:	00 
    b5e2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b5e9:	00 
    b5ea:	e8 81 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5ef:	48 89 c7             	mov    %rax,%rdi
    b5f2:	e8 19 ac ff ff       	call   6210 <fwp_rc_fresh>
    b5f7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b5fe:	00 
    b5ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b604:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b60b:	00 
    b60c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b613:	00 
    b614:	e8 57 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b619:	48 89 c7             	mov    %rax,%rdi
    b61c:	e8 ef ab ff ff       	call   6210 <fwp_rc_fresh>
    b621:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b628:	00 
    b629:	bf 01 00 00 00       	mov    $0x1,%edi
    b62e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b635:	00 
    b636:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b63d:	00 
    b63e:	e8 2d a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b643:	48 89 c7             	mov    %rax,%rdi
    b646:	e8 c5 ab ff ff       	call   6210 <fwp_rc_fresh>
    b64b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b652:	00 
    b653:	bf 01 00 00 00       	mov    $0x1,%edi
    b658:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b65f:	00 
    b660:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b667:	00 
    b668:	e8 03 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b66d:	48 89 c7             	mov    %rax,%rdi
    b670:	e8 9b ab ff ff       	call   6210 <fwp_rc_fresh>
    b675:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b67c:	00 
    b67d:	bf 01 00 00 00       	mov    $0x1,%edi
    b682:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b689:	00 
    b68a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b691:	00 
    b692:	e8 d9 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b697:	48 89 c7             	mov    %rax,%rdi
    b69a:	e8 71 ab ff ff       	call   6210 <fwp_rc_fresh>
    b69f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b6a6:	00 
    b6a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ac:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b6b3:	00 
    b6b4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b6bb:	00 
    b6bc:	e8 af a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6c1:	48 89 c7             	mov    %rax,%rdi
    b6c4:	e8 47 ab ff ff       	call   6210 <fwp_rc_fresh>
    b6c9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b6d0:	00 
    b6d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6d6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b6dd:	00 
    b6de:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b6e5:	00 
    b6e6:	e8 85 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6eb:	48 89 c7             	mov    %rax,%rdi
    b6ee:	e8 1d ab ff ff       	call   6210 <fwp_rc_fresh>
    b6f3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b6fa:	00 
    b6fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b700:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b707:	00 
    b708:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b70f:	00 
    b710:	e8 5b a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b715:	48 89 c7             	mov    %rax,%rdi
    b718:	e8 f3 aa ff ff       	call   6210 <fwp_rc_fresh>
    b71d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b724:	00 
    b725:	bf 01 00 00 00       	mov    $0x1,%edi
    b72a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b731:	00 
    b732:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b739:	00 
    b73a:	e8 31 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b73f:	48 89 c7             	mov    %rax,%rdi
    b742:	e8 c9 aa ff ff       	call   6210 <fwp_rc_fresh>
    b747:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b74e:	00 
    b74f:	bf 01 00 00 00       	mov    $0x1,%edi
    b754:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b75b:	00 
    b75c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b763:	00 
    b764:	e8 07 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b769:	48 89 c7             	mov    %rax,%rdi
    b76c:	e8 9f aa ff ff       	call   6210 <fwp_rc_fresh>
    b771:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b778:	00 
    b779:	bf 01 00 00 00       	mov    $0x1,%edi
    b77e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b785:	00 
    b786:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b78d:	00 
    b78e:	e8 dd a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b793:	48 89 c7             	mov    %rax,%rdi
    b796:	e8 75 aa ff ff       	call   6210 <fwp_rc_fresh>
    b79b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    b7a2:	00 
    b7a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7a8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    b7af:	00 
    b7b0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    b7b7:	00 
    b7b8:	e8 b3 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7bd:	48 89 c7             	mov    %rax,%rdi
    b7c0:	e8 4b aa ff ff       	call   6210 <fwp_rc_fresh>
    b7c5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    b7cc:	00 
    b7cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    b7d9:	00 
    b7da:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    b7e1:	00 
    b7e2:	e8 89 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7e7:	48 89 c7             	mov    %rax,%rdi
    b7ea:	e8 21 aa ff ff       	call   6210 <fwp_rc_fresh>
    b7ef:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    b7f6:	00 
    b7f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7fc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    b803:	00 
    b804:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    b80b:	00 
    b80c:	e8 5f a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b811:	48 89 c7             	mov    %rax,%rdi
    b814:	e8 f7 a9 ff ff       	call   6210 <fwp_rc_fresh>
    b819:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    b820:	00 
    b821:	bf 01 00 00 00       	mov    $0x1,%edi
    b826:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    b82d:	00 
    b82e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    b835:	00 
    b836:	e8 35 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b83b:	48 89 c7             	mov    %rax,%rdi
    b83e:	e8 cd a9 ff ff       	call   6210 <fwp_rc_fresh>
    b843:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    b84a:	00 
    b84b:	bf 01 00 00 00       	mov    $0x1,%edi
    b850:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    b857:	00 
    b858:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    b85f:	00 
    b860:	e8 0b a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b865:	48 89 c7             	mov    %rax,%rdi
    b868:	e8 a3 a9 ff ff       	call   6210 <fwp_rc_fresh>
    b86d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    b874:	00 
    b875:	bf 01 00 00 00       	mov    $0x1,%edi
    b87a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    b881:	00 
    b882:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    b889:	00 
    b88a:	e8 e1 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b88f:	48 89 c7             	mov    %rax,%rdi
    b892:	e8 79 a9 ff ff       	call   6210 <fwp_rc_fresh>
    b897:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    b89e:	00 
    b89f:	bf 01 00 00 00       	mov    $0x1,%edi
    b8a4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    b8ab:	00 
    b8ac:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    b8b3:	00 
    b8b4:	e8 b7 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8b9:	48 89 c7             	mov    %rax,%rdi
    b8bc:	e8 4f a9 ff ff       	call   6210 <fwp_rc_fresh>
    b8c1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    b8c8:	00 
    b8c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ce:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    b8d5:	00 
    b8d6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    b8dd:	00 
    b8de:	e8 8d a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8e3:	48 89 c7             	mov    %rax,%rdi
    b8e6:	e8 25 a9 ff ff       	call   6210 <fwp_rc_fresh>
    b8eb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    b8f2:	00 
    b8f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8f8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    b8ff:	00 
    b900:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    b907:	00 
    b908:	e8 63 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b90d:	48 89 c7             	mov    %rax,%rdi
    b910:	e8 fb a8 ff ff       	call   6210 <fwp_rc_fresh>
    b915:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    b91c:	00 
    b91d:	bf 01 00 00 00       	mov    $0x1,%edi
    b922:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    b929:	00 
    b92a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    b931:	00 
    b932:	e8 39 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b937:	48 89 c7             	mov    %rax,%rdi
    b93a:	e8 d1 a8 ff ff       	call   6210 <fwp_rc_fresh>
    b93f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    b946:	00 
    b947:	bf 01 00 00 00       	mov    $0x1,%edi
    b94c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    b953:	00 
    b954:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    b95b:	00 
    b95c:	e8 0f a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b961:	48 89 c7             	mov    %rax,%rdi
    b964:	e8 a7 a8 ff ff       	call   6210 <fwp_rc_fresh>
    b969:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    b970:	00 
    b971:	bf 01 00 00 00       	mov    $0x1,%edi
    b976:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    b97d:	00 
    b97e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    b985:	00 
    b986:	e8 e5 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b98b:	48 89 c7             	mov    %rax,%rdi
    b98e:	e8 7d a8 ff ff       	call   6210 <fwp_rc_fresh>
    b993:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    b99a:	00 
    b99b:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    b9a7:	00 
    b9a8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    b9af:	00 
    b9b0:	e8 bb a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9b5:	48 89 c7             	mov    %rax,%rdi
    b9b8:	e8 53 a8 ff ff       	call   6210 <fwp_rc_fresh>
    b9bd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    b9c4:	00 
    b9c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ca:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    b9d1:	00 
    b9d2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    b9d9:	00 
    b9da:	e8 91 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9df:	48 89 c7             	mov    %rax,%rdi
    b9e2:	e8 29 a8 ff ff       	call   6210 <fwp_rc_fresh>
    b9e7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    b9ee:	00 
    b9ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b9f4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    b9fb:	00 
    b9fc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    ba03:	00 
    ba04:	e8 67 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba09:	48 89 c7             	mov    %rax,%rdi
    ba0c:	e8 ff a7 ff ff       	call   6210 <fwp_rc_fresh>
    ba11:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    ba18:	00 
    ba19:	bf 01 00 00 00       	mov    $0x1,%edi
    ba1e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    ba25:	00 
    ba26:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    ba2d:	00 
    ba2e:	e8 3d a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba33:	48 89 c7             	mov    %rax,%rdi
    ba36:	e8 d5 a7 ff ff       	call   6210 <fwp_rc_fresh>
    ba3b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    ba42:	00 
    ba43:	bf 01 00 00 00       	mov    $0x1,%edi
    ba48:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    ba4f:	00 
    ba50:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    ba57:	00 
    ba58:	e8 13 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba5d:	48 89 c7             	mov    %rax,%rdi
    ba60:	e8 ab a7 ff ff       	call   6210 <fwp_rc_fresh>
    ba65:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    ba6c:	00 
    ba6d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba72:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    ba79:	00 
    ba7a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    ba81:	00 
    ba82:	e8 e9 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba87:	48 89 c7             	mov    %rax,%rdi
    ba8a:	e8 81 a7 ff ff       	call   6210 <fwp_rc_fresh>
    ba8f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    ba96:	00 
    ba97:	bf 01 00 00 00       	mov    $0x1,%edi
    ba9c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    baa3:	00 
    baa4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    baab:	00 
    baac:	e8 bf a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bab1:	48 89 c7             	mov    %rax,%rdi
    bab4:	e8 57 a7 ff ff       	call   6210 <fwp_rc_fresh>
    bab9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bac0:	00 
    bac1:	bf 01 00 00 00       	mov    $0x1,%edi
    bac6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bacd:	00 
    bace:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bad5:	00 
    bad6:	e8 95 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    badb:	48 89 c7             	mov    %rax,%rdi
    bade:	e8 2d a7 ff ff       	call   6210 <fwp_rc_fresh>
    bae3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    baea:	00 
    baeb:	bf 01 00 00 00       	mov    $0x1,%edi
    baf0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    baf7:	00 
    baf8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    baff:	00 
    bb00:	e8 6b a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb05:	48 89 c7             	mov    %rax,%rdi
    bb08:	e8 03 a7 ff ff       	call   6210 <fwp_rc_fresh>
    bb0d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bb14:	00 
    bb15:	bf 01 00 00 00       	mov    $0x1,%edi
    bb1a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bb21:	00 
    bb22:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bb29:	00 
    bb2a:	e8 41 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb2f:	48 89 c7             	mov    %rax,%rdi
    bb32:	e8 d9 a6 ff ff       	call   6210 <fwp_rc_fresh>
    bb37:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bb3e:	00 
    bb3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb44:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bb4b:	00 
    bb4c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bb53:	00 
    bb54:	e8 17 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb59:	48 89 c7             	mov    %rax,%rdi
    bb5c:	e8 af a6 ff ff       	call   6210 <fwp_rc_fresh>
    bb61:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bb68:	00 
    bb69:	bf 01 00 00 00       	mov    $0x1,%edi
    bb6e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bb75:	00 
    bb76:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bb7d:	00 
    bb7e:	e8 ed 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb83:	48 89 c7             	mov    %rax,%rdi
    bb86:	e8 85 a6 ff ff       	call   6210 <fwp_rc_fresh>
    bb8b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bb92:	00 
    bb93:	bf 01 00 00 00       	mov    $0x1,%edi
    bb98:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bb9f:	00 
    bba0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bba7:	00 
    bba8:	e8 c3 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbad:	48 89 c7             	mov    %rax,%rdi
    bbb0:	e8 5b a6 ff ff       	call   6210 <fwp_rc_fresh>
    bbb5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bbbc:	00 
    bbbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    bbc9:	00 
    bbca:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    bbd1:	00 
    bbd2:	e8 99 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbd7:	48 89 c7             	mov    %rax,%rdi
    bbda:	e8 31 a6 ff ff       	call   6210 <fwp_rc_fresh>
    bbdf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bbe6:	00 
    bbe7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbec:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    bbf3:	00 
    bbf4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bbfb:	00 
    bbfc:	e8 6f 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc01:	48 89 c7             	mov    %rax,%rdi
    bc04:	e8 07 a6 ff ff       	call   6210 <fwp_rc_fresh>
    bc09:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    bc10:	00 
    bc11:	bf 01 00 00 00       	mov    $0x1,%edi
    bc16:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    bc1d:	00 
    bc1e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    bc25:	00 
    bc26:	e8 45 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc2b:	48 89 c7             	mov    %rax,%rdi
    bc2e:	e8 dd a5 ff ff       	call   6210 <fwp_rc_fresh>
    bc33:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    bc3a:	00 
    bc3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc40:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    bc47:	00 
    bc48:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    bc4f:	00 
    bc50:	e8 1b 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc55:	48 8b 15 dc 7e 01 00 	mov    0x17edc(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bc5c:	49 89 c5             	mov    %rax,%r13
    bc5f:	48 2b 05 aa 7e 01 00 	sub    0x17eaa(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bc66:	48 c1 e2 10          	shl    $0x10,%rdx
    bc6a:	48 39 d0             	cmp    %rdx,%rax
    bc6d:	73 59                	jae    bcc8 <f0+0x13b8>
    bc6f:	48 89 c2             	mov    %rax,%rdx
    bc72:	48 c1 ea 10          	shr    $0x10,%rdx
    bc76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc7a:	48 8b 15 d7 7e 01 00 	mov    0x17ed7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bc81:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc85:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bc89:	4d 85 e4             	test   %r12,%r12
    bc8c:	74 3a                	je     bcc8 <f0+0x13b8>
    bc8e:	0f b6 0a             	movzbl (%rdx),%ecx
    bc91:	80 f9 02             	cmp    $0x2,%cl
    bc94:	0f 84 c6 15 00 00    	je     d260 <f0+0x2950>
    bc9a:	80 f9 01             	cmp    $0x1,%cl
    bc9d:	75 29                	jne    bcc8 <f0+0x13b8>
    bc9f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bca2:	0f b7 c0             	movzwl %ax,%eax
    bca5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bca8:	48 0f af c1          	imul   %rcx,%rax
    bcac:	48 c1 e8 20          	shr    $0x20,%rax
    bcb0:	48 39 d0             	cmp    %rdx,%rax
    bcb3:	73 13                	jae    bcc8 <f0+0x13b8>
    bcb5:	49 01 c4             	add    %rax,%r12
    bcb8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bcbd:	0f 84 99 17 00 00    	je     d45c <f0+0x2b4c>
    bcc3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bcc8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bccf:	33 f3 bf 
    bcd2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bcd9:	00 
    bcda:	bf 01 00 00 00       	mov    $0x1,%edi
    bcdf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bce6:	00 
    bce7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bcee:	00 
    bcef:	e8 7c 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bcf4:	48 8b 15 3d 7e 01 00 	mov    0x17e3d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bcfb:	49 89 c5             	mov    %rax,%r13
    bcfe:	48 2b 05 0b 7e 01 00 	sub    0x17e0b(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bd05:	48 c1 e2 10          	shl    $0x10,%rdx
    bd09:	48 39 d0             	cmp    %rdx,%rax
    bd0c:	73 59                	jae    bd67 <f0+0x1457>
    bd0e:	48 89 c2             	mov    %rax,%rdx
    bd11:	48 c1 ea 10          	shr    $0x10,%rdx
    bd15:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd19:	48 8b 15 38 7e 01 00 	mov    0x17e38(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bd20:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd24:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd28:	4d 85 e4             	test   %r12,%r12
    bd2b:	74 3a                	je     bd67 <f0+0x1457>
    bd2d:	0f b6 0a             	movzbl (%rdx),%ecx
    bd30:	80 f9 02             	cmp    $0x2,%cl
    bd33:	0f 84 17 15 00 00    	je     d250 <f0+0x2940>
    bd39:	80 f9 01             	cmp    $0x1,%cl
    bd3c:	75 29                	jne    bd67 <f0+0x1457>
    bd3e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd41:	0f b7 c0             	movzwl %ax,%eax
    bd44:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd47:	48 0f af c1          	imul   %rcx,%rax
    bd4b:	48 c1 e8 20          	shr    $0x20,%rax
    bd4f:	48 39 d0             	cmp    %rdx,%rax
    bd52:	73 13                	jae    bd67 <f0+0x1457>
    bd54:	49 01 c4             	add    %rax,%r12
    bd57:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bd5c:	0f 84 07 17 00 00    	je     d469 <f0+0x2b59>
    bd62:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bd67:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bd6e:	00 f0 3f 
    bd71:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    bd78:	00 
    bd79:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    bd85:	00 
    bd86:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    bd8d:	00 
    bd8e:	e8 dd 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd93:	48 8b 15 9e 7d 01 00 	mov    0x17d9e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bd9a:	49 89 c5             	mov    %rax,%r13
    bd9d:	48 2b 05 6c 7d 01 00 	sub    0x17d6c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bda4:	48 c1 e2 10          	shl    $0x10,%rdx
    bda8:	48 39 d0             	cmp    %rdx,%rax
    bdab:	73 59                	jae    be06 <f0+0x14f6>
    bdad:	48 89 c2             	mov    %rax,%rdx
    bdb0:	48 c1 ea 10          	shr    $0x10,%rdx
    bdb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdb8:	48 8b 15 99 7d 01 00 	mov    0x17d99(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bdbf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bdc3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bdc7:	4d 85 e4             	test   %r12,%r12
    bdca:	74 3a                	je     be06 <f0+0x14f6>
    bdcc:	0f b6 0a             	movzbl (%rdx),%ecx
    bdcf:	80 f9 02             	cmp    $0x2,%cl
    bdd2:	0f 84 28 15 00 00    	je     d300 <f0+0x29f0>
    bdd8:	80 f9 01             	cmp    $0x1,%cl
    bddb:	75 29                	jne    be06 <f0+0x14f6>
    bddd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bde0:	0f b7 c0             	movzwl %ax,%eax
    bde3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bde6:	48 0f af c1          	imul   %rcx,%rax
    bdea:	48 c1 e8 20          	shr    $0x20,%rax
    bdee:	48 39 d0             	cmp    %rdx,%rax
    bdf1:	73 13                	jae    be06 <f0+0x14f6>
    bdf3:	49 01 c4             	add    %rax,%r12
    bdf6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bdfb:	0f 84 75 16 00 00    	je     d476 <f0+0x2b66>
    be01:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be06:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    be0d:	33 f3 bf 
    be10:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    be17:	00 
    be18:	bf 01 00 00 00       	mov    $0x1,%edi
    be1d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    be24:	00 
    be25:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    be2c:	00 
    be2d:	e8 3e 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be32:	48 8b 15 ff 7c 01 00 	mov    0x17cff(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    be39:	49 89 c5             	mov    %rax,%r13
    be3c:	48 2b 05 cd 7c 01 00 	sub    0x17ccd(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    be43:	48 c1 e2 10          	shl    $0x10,%rdx
    be47:	48 39 d0             	cmp    %rdx,%rax
    be4a:	73 59                	jae    bea5 <f0+0x1595>
    be4c:	48 89 c2             	mov    %rax,%rdx
    be4f:	48 c1 ea 10          	shr    $0x10,%rdx
    be53:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be57:	48 8b 15 fa 7c 01 00 	mov    0x17cfa(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    be5e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be62:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be66:	4d 85 e4             	test   %r12,%r12
    be69:	74 3a                	je     bea5 <f0+0x1595>
    be6b:	0f b6 0a             	movzbl (%rdx),%ecx
    be6e:	80 f9 02             	cmp    $0x2,%cl
    be71:	0f 84 79 14 00 00    	je     d2f0 <f0+0x29e0>
    be77:	80 f9 01             	cmp    $0x1,%cl
    be7a:	75 29                	jne    bea5 <f0+0x1595>
    be7c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be7f:	0f b7 c0             	movzwl %ax,%eax
    be82:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be85:	48 0f af c1          	imul   %rcx,%rax
    be89:	48 c1 e8 20          	shr    $0x20,%rax
    be8d:	48 39 d0             	cmp    %rdx,%rax
    be90:	73 13                	jae    bea5 <f0+0x1595>
    be92:	49 01 c4             	add    %rax,%r12
    be95:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be9a:	0f 84 e3 15 00 00    	je     d483 <f0+0x2b73>
    bea0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bea5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    beac:	00 f0 3f 
    beaf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    beb6:	00 
    beb7:	bf 01 00 00 00       	mov    $0x1,%edi
    bebc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    bec3:	00 
    bec4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    becb:	00 
    becc:	e8 9f 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bed1:	48 8b 15 60 7c 01 00 	mov    0x17c60(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bed8:	49 89 c5             	mov    %rax,%r13
    bedb:	48 2b 05 2e 7c 01 00 	sub    0x17c2e(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bee2:	48 c1 e2 10          	shl    $0x10,%rdx
    bee6:	48 39 d0             	cmp    %rdx,%rax
    bee9:	73 59                	jae    bf44 <f0+0x1634>
    beeb:	48 89 c2             	mov    %rax,%rdx
    beee:	48 c1 ea 10          	shr    $0x10,%rdx
    bef2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bef6:	48 8b 15 5b 7c 01 00 	mov    0x17c5b(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    befd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf01:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf05:	4d 85 e4             	test   %r12,%r12
    bf08:	74 3a                	je     bf44 <f0+0x1634>
    bf0a:	0f b6 0a             	movzbl (%rdx),%ecx
    bf0d:	80 f9 02             	cmp    $0x2,%cl
    bf10:	0f 84 ca 13 00 00    	je     d2e0 <f0+0x29d0>
    bf16:	80 f9 01             	cmp    $0x1,%cl
    bf19:	75 29                	jne    bf44 <f0+0x1634>
    bf1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf1e:	0f b7 c0             	movzwl %ax,%eax
    bf21:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf24:	48 0f af c1          	imul   %rcx,%rax
    bf28:	48 c1 e8 20          	shr    $0x20,%rax
    bf2c:	48 39 d0             	cmp    %rdx,%rax
    bf2f:	73 13                	jae    bf44 <f0+0x1634>
    bf31:	49 01 c4             	add    %rax,%r12
    bf34:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf39:	0f 84 51 15 00 00    	je     d490 <f0+0x2b80>
    bf3f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf44:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf4b:	33 f3 bf 
    bf4e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    bf55:	00 
    bf56:	bf 01 00 00 00       	mov    $0x1,%edi
    bf5b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    bf62:	00 
    bf63:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    bf6a:	00 
    bf6b:	e8 00 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf70:	48 8b 15 c1 7b 01 00 	mov    0x17bc1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bf77:	49 89 c5             	mov    %rax,%r13
    bf7a:	48 2b 05 8f 7b 01 00 	sub    0x17b8f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bf81:	48 c1 e2 10          	shl    $0x10,%rdx
    bf85:	48 39 d0             	cmp    %rdx,%rax
    bf88:	73 59                	jae    bfe3 <f0+0x16d3>
    bf8a:	48 89 c2             	mov    %rax,%rdx
    bf8d:	48 c1 ea 10          	shr    $0x10,%rdx
    bf91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf95:	48 8b 15 bc 7b 01 00 	mov    0x17bbc(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bf9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfa0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfa4:	4d 85 e4             	test   %r12,%r12
    bfa7:	74 3a                	je     bfe3 <f0+0x16d3>
    bfa9:	0f b6 0a             	movzbl (%rdx),%ecx
    bfac:	80 f9 02             	cmp    $0x2,%cl
    bfaf:	0f 84 1b 13 00 00    	je     d2d0 <f0+0x29c0>
    bfb5:	80 f9 01             	cmp    $0x1,%cl
    bfb8:	75 29                	jne    bfe3 <f0+0x16d3>
    bfba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfbd:	0f b7 c0             	movzwl %ax,%eax
    bfc0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfc3:	48 0f af c1          	imul   %rcx,%rax
    bfc7:	48 c1 e8 20          	shr    $0x20,%rax
    bfcb:	48 39 d0             	cmp    %rdx,%rax
    bfce:	73 13                	jae    bfe3 <f0+0x16d3>
    bfd0:	49 01 c4             	add    %rax,%r12
    bfd3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfd8:	0f 84 bf 14 00 00    	je     d49d <f0+0x2b8d>
    bfde:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfe3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfea:	00 f0 3f 
    bfed:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    bff4:	00 
    bff5:	bf 01 00 00 00       	mov    $0x1,%edi
    bffa:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c001:	00 
    c002:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c009:	00 
    c00a:	e8 61 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c00f:	48 8b 15 22 7b 01 00 	mov    0x17b22(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c016:	49 89 c5             	mov    %rax,%r13
    c019:	48 2b 05 f0 7a 01 00 	sub    0x17af0(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c020:	48 c1 e2 10          	shl    $0x10,%rdx
    c024:	48 39 d0             	cmp    %rdx,%rax
    c027:	73 59                	jae    c082 <f0+0x1772>
    c029:	48 89 c2             	mov    %rax,%rdx
    c02c:	48 c1 ea 10          	shr    $0x10,%rdx
    c030:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c034:	48 8b 15 1d 7b 01 00 	mov    0x17b1d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c03b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c03f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c043:	4d 85 e4             	test   %r12,%r12
    c046:	74 3a                	je     c082 <f0+0x1772>
    c048:	0f b6 0a             	movzbl (%rdx),%ecx
    c04b:	80 f9 02             	cmp    $0x2,%cl
    c04e:	0f 84 6c 12 00 00    	je     d2c0 <f0+0x29b0>
    c054:	80 f9 01             	cmp    $0x1,%cl
    c057:	75 29                	jne    c082 <f0+0x1772>
    c059:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c05c:	0f b7 c0             	movzwl %ax,%eax
    c05f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c062:	48 0f af c1          	imul   %rcx,%rax
    c066:	48 c1 e8 20          	shr    $0x20,%rax
    c06a:	48 39 d0             	cmp    %rdx,%rax
    c06d:	73 13                	jae    c082 <f0+0x1772>
    c06f:	49 01 c4             	add    %rax,%r12
    c072:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c077:	0f 84 2d 14 00 00    	je     d4aa <f0+0x2b9a>
    c07d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c082:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c089:	33 f3 bf 
    c08c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c093:	00 
    c094:	bf 01 00 00 00       	mov    $0x1,%edi
    c099:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c0a0:	00 
    c0a1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c0a8:	00 
    c0a9:	e8 c2 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c0ae:	48 8b 15 83 7a 01 00 	mov    0x17a83(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c0b5:	49 89 c5             	mov    %rax,%r13
    c0b8:	48 2b 05 51 7a 01 00 	sub    0x17a51(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c0bf:	48 c1 e2 10          	shl    $0x10,%rdx
    c0c3:	48 39 d0             	cmp    %rdx,%rax
    c0c6:	73 59                	jae    c121 <f0+0x1811>
    c0c8:	48 89 c2             	mov    %rax,%rdx
    c0cb:	48 c1 ea 10          	shr    $0x10,%rdx
    c0cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0d3:	48 8b 15 7e 7a 01 00 	mov    0x17a7e(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c0da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0de:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0e2:	4d 85 e4             	test   %r12,%r12
    c0e5:	74 3a                	je     c121 <f0+0x1811>
    c0e7:	0f b6 0a             	movzbl (%rdx),%ecx
    c0ea:	80 f9 02             	cmp    $0x2,%cl
    c0ed:	0f 84 bd 11 00 00    	je     d2b0 <f0+0x29a0>
    c0f3:	80 f9 01             	cmp    $0x1,%cl
    c0f6:	75 29                	jne    c121 <f0+0x1811>
    c0f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0fb:	0f b7 c0             	movzwl %ax,%eax
    c0fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c101:	48 0f af c1          	imul   %rcx,%rax
    c105:	48 c1 e8 20          	shr    $0x20,%rax
    c109:	48 39 d0             	cmp    %rdx,%rax
    c10c:	73 13                	jae    c121 <f0+0x1811>
    c10e:	49 01 c4             	add    %rax,%r12
    c111:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c116:	0f 84 9b 13 00 00    	je     d4b7 <f0+0x2ba7>
    c11c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c121:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c128:	00 f0 3f 
    c12b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c132:	00 
    c133:	bf 01 00 00 00       	mov    $0x1,%edi
    c138:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c13f:	00 
    c140:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c147:	00 
    c148:	e8 23 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c14d:	48 8b 15 e4 79 01 00 	mov    0x179e4(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c154:	49 89 c5             	mov    %rax,%r13
    c157:	48 2b 05 b2 79 01 00 	sub    0x179b2(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c15e:	48 c1 e2 10          	shl    $0x10,%rdx
    c162:	48 39 d0             	cmp    %rdx,%rax
    c165:	73 59                	jae    c1c0 <f0+0x18b0>
    c167:	48 89 c2             	mov    %rax,%rdx
    c16a:	48 c1 ea 10          	shr    $0x10,%rdx
    c16e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c172:	48 8b 15 df 79 01 00 	mov    0x179df(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c179:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c17d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c181:	4d 85 e4             	test   %r12,%r12
    c184:	74 3a                	je     c1c0 <f0+0x18b0>
    c186:	0f b6 0a             	movzbl (%rdx),%ecx
    c189:	80 f9 02             	cmp    $0x2,%cl
    c18c:	0f 84 0e 11 00 00    	je     d2a0 <f0+0x2990>
    c192:	80 f9 01             	cmp    $0x1,%cl
    c195:	75 29                	jne    c1c0 <f0+0x18b0>
    c197:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c19a:	0f b7 c0             	movzwl %ax,%eax
    c19d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1a0:	48 0f af c1          	imul   %rcx,%rax
    c1a4:	48 c1 e8 20          	shr    $0x20,%rax
    c1a8:	48 39 d0             	cmp    %rdx,%rax
    c1ab:	73 13                	jae    c1c0 <f0+0x18b0>
    c1ad:	49 01 c4             	add    %rax,%r12
    c1b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1b5:	0f 84 09 13 00 00    	je     d4c4 <f0+0x2bb4>
    c1bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c1c7:	33 f3 bf 
    c1ca:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c1d1:	00 
    c1d2:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c1de:	00 
    c1df:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c1e6:	00 
    c1e7:	e8 84 99 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c1ec:	48 8b 15 45 79 01 00 	mov    0x17945(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c1f3:	49 89 c5             	mov    %rax,%r13
    c1f6:	48 2b 05 13 79 01 00 	sub    0x17913(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c1fd:	48 c1 e2 10          	shl    $0x10,%rdx
    c201:	48 39 d0             	cmp    %rdx,%rax
    c204:	73 59                	jae    c25f <f0+0x194f>
    c206:	48 89 c2             	mov    %rax,%rdx
    c209:	48 c1 ea 10          	shr    $0x10,%rdx
    c20d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c211:	48 8b 15 40 79 01 00 	mov    0x17940(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c218:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c21c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c220:	4d 85 e4             	test   %r12,%r12
    c223:	74 3a                	je     c25f <f0+0x194f>
    c225:	0f b6 0a             	movzbl (%rdx),%ecx
    c228:	80 f9 02             	cmp    $0x2,%cl
    c22b:	0f 84 5f 10 00 00    	je     d290 <f0+0x2980>
    c231:	80 f9 01             	cmp    $0x1,%cl
    c234:	75 29                	jne    c25f <f0+0x194f>
    c236:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c239:	0f b7 c0             	movzwl %ax,%eax
    c23c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c23f:	48 0f af c1          	imul   %rcx,%rax
    c243:	48 c1 e8 20          	shr    $0x20,%rax
    c247:	48 39 d0             	cmp    %rdx,%rax
    c24a:	73 13                	jae    c25f <f0+0x194f>
    c24c:	49 01 c4             	add    %rax,%r12
    c24f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c254:	0f 84 77 12 00 00    	je     d4d1 <f0+0x2bc1>
    c25a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c25f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c266:	00 f0 3f 
    c269:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c270:	00 
    c271:	bf 01 00 00 00       	mov    $0x1,%edi
    c276:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c27d:	00 
    c27e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c285:	00 
    c286:	e8 e5 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c28b:	48 8b 15 a6 78 01 00 	mov    0x178a6(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c292:	49 89 c5             	mov    %rax,%r13
    c295:	48 2b 05 74 78 01 00 	sub    0x17874(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c29c:	48 c1 e2 10          	shl    $0x10,%rdx
    c2a0:	48 39 d0             	cmp    %rdx,%rax
    c2a3:	73 59                	jae    c2fe <f0+0x19ee>
    c2a5:	48 89 c2             	mov    %rax,%rdx
    c2a8:	48 c1 ea 10          	shr    $0x10,%rdx
    c2ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2b0:	48 8b 15 a1 78 01 00 	mov    0x178a1(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c2b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2bf:	4d 85 e4             	test   %r12,%r12
    c2c2:	74 3a                	je     c2fe <f0+0x19ee>
    c2c4:	0f b6 0a             	movzbl (%rdx),%ecx
    c2c7:	80 f9 02             	cmp    $0x2,%cl
    c2ca:	0f 84 40 0f 00 00    	je     d210 <f0+0x2900>
    c2d0:	80 f9 01             	cmp    $0x1,%cl
    c2d3:	75 29                	jne    c2fe <f0+0x19ee>
    c2d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2d8:	0f b7 c0             	movzwl %ax,%eax
    c2db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2de:	48 0f af c1          	imul   %rcx,%rax
    c2e2:	48 c1 e8 20          	shr    $0x20,%rax
    c2e6:	48 39 d0             	cmp    %rdx,%rax
    c2e9:	73 13                	jae    c2fe <f0+0x19ee>
    c2eb:	49 01 c4             	add    %rax,%r12
    c2ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2f3:	0f 84 e5 11 00 00    	je     d4de <f0+0x2bce>
    c2f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2fe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c305:	33 f3 bf 
    c308:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c30f:	00 
    c310:	bf 01 00 00 00       	mov    $0x1,%edi
    c315:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c31c:	00 
    c31d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c324:	00 
    c325:	e8 46 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c32a:	48 8b 15 07 78 01 00 	mov    0x17807(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c331:	49 89 c5             	mov    %rax,%r13
    c334:	48 2b 05 d5 77 01 00 	sub    0x177d5(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c33b:	48 c1 e2 10          	shl    $0x10,%rdx
    c33f:	48 39 d0             	cmp    %rdx,%rax
    c342:	73 59                	jae    c39d <f0+0x1a8d>
    c344:	48 89 c2             	mov    %rax,%rdx
    c347:	48 c1 ea 10          	shr    $0x10,%rdx
    c34b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c34f:	48 8b 15 02 78 01 00 	mov    0x17802(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c356:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c35a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c35e:	4d 85 e4             	test   %r12,%r12
    c361:	74 3a                	je     c39d <f0+0x1a8d>
    c363:	0f b6 0a             	movzbl (%rdx),%ecx
    c366:	80 f9 02             	cmp    $0x2,%cl
    c369:	0f 84 91 0e 00 00    	je     d200 <f0+0x28f0>
    c36f:	80 f9 01             	cmp    $0x1,%cl
    c372:	75 29                	jne    c39d <f0+0x1a8d>
    c374:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c377:	0f b7 c0             	movzwl %ax,%eax
    c37a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c37d:	48 0f af c1          	imul   %rcx,%rax
    c381:	48 c1 e8 20          	shr    $0x20,%rax
    c385:	48 39 d0             	cmp    %rdx,%rax
    c388:	73 13                	jae    c39d <f0+0x1a8d>
    c38a:	49 01 c4             	add    %rax,%r12
    c38d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c392:	0f 84 53 11 00 00    	je     d4eb <f0+0x2bdb>
    c398:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c39d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c3a4:	00 f0 3f 
    c3a7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c3ae:	00 
    c3af:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c3bb:	00 
    c3bc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c3c3:	00 
    c3c4:	e8 a7 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c3c9:	48 8b 15 68 77 01 00 	mov    0x17768(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c3d0:	49 89 c5             	mov    %rax,%r13
    c3d3:	48 2b 05 36 77 01 00 	sub    0x17736(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c3da:	48 c1 e2 10          	shl    $0x10,%rdx
    c3de:	48 39 d0             	cmp    %rdx,%rax
    c3e1:	73 59                	jae    c43c <f0+0x1b2c>
    c3e3:	48 89 c2             	mov    %rax,%rdx
    c3e6:	48 c1 ea 10          	shr    $0x10,%rdx
    c3ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3ee:	48 8b 15 63 77 01 00 	mov    0x17763(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c3f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3fd:	4d 85 e4             	test   %r12,%r12
    c400:	74 3a                	je     c43c <f0+0x1b2c>
    c402:	0f b6 0a             	movzbl (%rdx),%ecx
    c405:	80 f9 02             	cmp    $0x2,%cl
    c408:	0f 84 e2 0d 00 00    	je     d1f0 <f0+0x28e0>
    c40e:	80 f9 01             	cmp    $0x1,%cl
    c411:	75 29                	jne    c43c <f0+0x1b2c>
    c413:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c416:	0f b7 c0             	movzwl %ax,%eax
    c419:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c41c:	48 0f af c1          	imul   %rcx,%rax
    c420:	48 c1 e8 20          	shr    $0x20,%rax
    c424:	48 39 d0             	cmp    %rdx,%rax
    c427:	73 13                	jae    c43c <f0+0x1b2c>
    c429:	49 01 c4             	add    %rax,%r12
    c42c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c431:	0f 84 c1 10 00 00    	je     d4f8 <f0+0x2be8>
    c437:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c43c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c443:	33 f3 bf 
    c446:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c44d:	00 
    c44e:	bf 01 00 00 00       	mov    $0x1,%edi
    c453:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c45a:	00 
    c45b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c462:	00 
    c463:	e8 08 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c468:	48 8b 15 c9 76 01 00 	mov    0x176c9(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c46f:	49 89 c5             	mov    %rax,%r13
    c472:	48 2b 05 97 76 01 00 	sub    0x17697(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c479:	48 c1 e2 10          	shl    $0x10,%rdx
    c47d:	48 39 d0             	cmp    %rdx,%rax
    c480:	73 59                	jae    c4db <f0+0x1bcb>
    c482:	48 89 c2             	mov    %rax,%rdx
    c485:	48 c1 ea 10          	shr    $0x10,%rdx
    c489:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c48d:	48 8b 15 c4 76 01 00 	mov    0x176c4(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c494:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c498:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c49c:	4d 85 e4             	test   %r12,%r12
    c49f:	74 3a                	je     c4db <f0+0x1bcb>
    c4a1:	0f b6 0a             	movzbl (%rdx),%ecx
    c4a4:	80 f9 02             	cmp    $0x2,%cl
    c4a7:	0f 84 33 0d 00 00    	je     d1e0 <f0+0x28d0>
    c4ad:	80 f9 01             	cmp    $0x1,%cl
    c4b0:	75 29                	jne    c4db <f0+0x1bcb>
    c4b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4b5:	0f b7 c0             	movzwl %ax,%eax
    c4b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4bb:	48 0f af c1          	imul   %rcx,%rax
    c4bf:	48 c1 e8 20          	shr    $0x20,%rax
    c4c3:	48 39 d0             	cmp    %rdx,%rax
    c4c6:	73 13                	jae    c4db <f0+0x1bcb>
    c4c8:	49 01 c4             	add    %rax,%r12
    c4cb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4d0:	0f 84 2f 10 00 00    	je     d505 <f0+0x2bf5>
    c4d6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4db:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4e2:	00 f0 3f 
    c4e5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c4ec:	00 
    c4ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c4f9:	00 
    c4fa:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c501:	00 
    c502:	e8 69 96 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c507:	48 8b 15 2a 76 01 00 	mov    0x1762a(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c50e:	49 89 c5             	mov    %rax,%r13
    c511:	48 2b 05 f8 75 01 00 	sub    0x175f8(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c518:	48 c1 e2 10          	shl    $0x10,%rdx
    c51c:	48 39 d0             	cmp    %rdx,%rax
    c51f:	73 59                	jae    c57a <f0+0x1c6a>
    c521:	48 89 c2             	mov    %rax,%rdx
    c524:	48 c1 ea 10          	shr    $0x10,%rdx
    c528:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c52c:	48 8b 15 25 76 01 00 	mov    0x17625(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c533:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c537:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c53b:	4d 85 e4             	test   %r12,%r12
    c53e:	74 3a                	je     c57a <f0+0x1c6a>
    c540:	0f b6 0a             	movzbl (%rdx),%ecx
    c543:	80 f9 02             	cmp    $0x2,%cl
    c546:	0f 84 84 0c 00 00    	je     d1d0 <f0+0x28c0>
    c54c:	80 f9 01             	cmp    $0x1,%cl
    c54f:	75 29                	jne    c57a <f0+0x1c6a>
    c551:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c554:	0f b7 c0             	movzwl %ax,%eax
    c557:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c55a:	48 0f af c1          	imul   %rcx,%rax
    c55e:	48 c1 e8 20          	shr    $0x20,%rax
    c562:	48 39 d0             	cmp    %rdx,%rax
    c565:	73 13                	jae    c57a <f0+0x1c6a>
    c567:	49 01 c4             	add    %rax,%r12
    c56a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c56f:	0f 84 9d 0f 00 00    	je     d512 <f0+0x2c02>
    c575:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c57a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c581:	33 f3 bf 
    c584:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c58b:	00 
    c58c:	bf 01 00 00 00       	mov    $0x1,%edi
    c591:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c598:	00 
    c599:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c5a0:	00 
    c5a1:	e8 ca 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c5a6:	48 8b 15 8b 75 01 00 	mov    0x1758b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c5ad:	49 89 c5             	mov    %rax,%r13
    c5b0:	48 2b 05 59 75 01 00 	sub    0x17559(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c5b7:	48 c1 e2 10          	shl    $0x10,%rdx
    c5bb:	48 39 d0             	cmp    %rdx,%rax
    c5be:	73 59                	jae    c619 <f0+0x1d09>
    c5c0:	48 89 c2             	mov    %rax,%rdx
    c5c3:	48 c1 ea 10          	shr    $0x10,%rdx
    c5c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5cb:	48 8b 15 86 75 01 00 	mov    0x17586(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c5d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5d6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5da:	4d 85 e4             	test   %r12,%r12
    c5dd:	74 3a                	je     c619 <f0+0x1d09>
    c5df:	0f b6 0a             	movzbl (%rdx),%ecx
    c5e2:	80 f9 02             	cmp    $0x2,%cl
    c5e5:	0f 84 d5 0b 00 00    	je     d1c0 <f0+0x28b0>
    c5eb:	80 f9 01             	cmp    $0x1,%cl
    c5ee:	75 29                	jne    c619 <f0+0x1d09>
    c5f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5f3:	0f b7 c0             	movzwl %ax,%eax
    c5f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5f9:	48 0f af c1          	imul   %rcx,%rax
    c5fd:	48 c1 e8 20          	shr    $0x20,%rax
    c601:	48 39 d0             	cmp    %rdx,%rax
    c604:	73 13                	jae    c619 <f0+0x1d09>
    c606:	49 01 c4             	add    %rax,%r12
    c609:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c60e:	0f 84 0b 0f 00 00    	je     d51f <f0+0x2c0f>
    c614:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c619:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c620:	00 f0 3f 
    c623:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c62a:	00 
    c62b:	bf 01 00 00 00       	mov    $0x1,%edi
    c630:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c637:	00 
    c638:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c63f:	00 
    c640:	e8 2b 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c645:	48 8b 15 ec 74 01 00 	mov    0x174ec(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c64c:	49 89 c5             	mov    %rax,%r13
    c64f:	48 2b 05 ba 74 01 00 	sub    0x174ba(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c656:	48 c1 e2 10          	shl    $0x10,%rdx
    c65a:	48 39 d0             	cmp    %rdx,%rax
    c65d:	73 59                	jae    c6b8 <f0+0x1da8>
    c65f:	48 89 c2             	mov    %rax,%rdx
    c662:	48 c1 ea 10          	shr    $0x10,%rdx
    c666:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c66a:	48 8b 15 e7 74 01 00 	mov    0x174e7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c671:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c675:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c679:	4d 85 e4             	test   %r12,%r12
    c67c:	74 3a                	je     c6b8 <f0+0x1da8>
    c67e:	0f b6 0a             	movzbl (%rdx),%ecx
    c681:	80 f9 02             	cmp    $0x2,%cl
    c684:	0f 84 26 0b 00 00    	je     d1b0 <f0+0x28a0>
    c68a:	80 f9 01             	cmp    $0x1,%cl
    c68d:	75 29                	jne    c6b8 <f0+0x1da8>
    c68f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c692:	0f b7 c0             	movzwl %ax,%eax
    c695:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c698:	48 0f af c1          	imul   %rcx,%rax
    c69c:	48 c1 e8 20          	shr    $0x20,%rax
    c6a0:	48 39 d0             	cmp    %rdx,%rax
    c6a3:	73 13                	jae    c6b8 <f0+0x1da8>
    c6a5:	49 01 c4             	add    %rax,%r12
    c6a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6ad:	0f 84 79 0e 00 00    	je     d52c <f0+0x2c1c>
    c6b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6b8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6bf:	33 f3 bf 
    c6c2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c6c9:	00 
    c6ca:	bf 01 00 00 00       	mov    $0x1,%edi
    c6cf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c6d6:	00 
    c6d7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c6de:	00 
    c6df:	e8 8c 94 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c6e4:	48 8b 15 4d 74 01 00 	mov    0x1744d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c6eb:	49 89 c5             	mov    %rax,%r13
    c6ee:	48 2b 05 1b 74 01 00 	sub    0x1741b(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c6f5:	48 c1 e2 10          	shl    $0x10,%rdx
    c6f9:	48 39 d0             	cmp    %rdx,%rax
    c6fc:	73 59                	jae    c757 <f0+0x1e47>
    c6fe:	48 89 c2             	mov    %rax,%rdx
    c701:	48 c1 ea 10          	shr    $0x10,%rdx
    c705:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c709:	48 8b 15 48 74 01 00 	mov    0x17448(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c710:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c714:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c718:	4d 85 e4             	test   %r12,%r12
    c71b:	74 3a                	je     c757 <f0+0x1e47>
    c71d:	0f b6 0a             	movzbl (%rdx),%ecx
    c720:	80 f9 02             	cmp    $0x2,%cl
    c723:	0f 84 77 0a 00 00    	je     d1a0 <f0+0x2890>
    c729:	80 f9 01             	cmp    $0x1,%cl
    c72c:	75 29                	jne    c757 <f0+0x1e47>
    c72e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c731:	0f b7 c0             	movzwl %ax,%eax
    c734:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c737:	48 0f af c1          	imul   %rcx,%rax
    c73b:	48 c1 e8 20          	shr    $0x20,%rax
    c73f:	48 39 d0             	cmp    %rdx,%rax
    c742:	73 13                	jae    c757 <f0+0x1e47>
    c744:	49 01 c4             	add    %rax,%r12
    c747:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c74c:	0f 84 e7 0d 00 00    	je     d539 <f0+0x2c29>
    c752:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c757:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c75e:	00 f0 3f 
    c761:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c768:	00 
    c769:	bf 01 00 00 00       	mov    $0x1,%edi
    c76e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c775:	00 
    c776:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c77d:	00 
    c77e:	e8 ed 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c783:	48 8b 15 ae 73 01 00 	mov    0x173ae(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c78a:	49 89 c5             	mov    %rax,%r13
    c78d:	48 2b 05 7c 73 01 00 	sub    0x1737c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c794:	48 c1 e2 10          	shl    $0x10,%rdx
    c798:	48 39 d0             	cmp    %rdx,%rax
    c79b:	73 59                	jae    c7f6 <f0+0x1ee6>
    c79d:	48 89 c2             	mov    %rax,%rdx
    c7a0:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7a8:	48 8b 15 a9 73 01 00 	mov    0x173a9(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c7af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7b7:	4d 85 e4             	test   %r12,%r12
    c7ba:	74 3a                	je     c7f6 <f0+0x1ee6>
    c7bc:	0f b6 0a             	movzbl (%rdx),%ecx
    c7bf:	80 f9 02             	cmp    $0x2,%cl
    c7c2:	0f 84 38 0c 00 00    	je     d400 <f0+0x2af0>
    c7c8:	80 f9 01             	cmp    $0x1,%cl
    c7cb:	75 29                	jne    c7f6 <f0+0x1ee6>
    c7cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7d0:	0f b7 c0             	movzwl %ax,%eax
    c7d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d6:	48 0f af c1          	imul   %rcx,%rax
    c7da:	48 c1 e8 20          	shr    $0x20,%rax
    c7de:	48 39 d0             	cmp    %rdx,%rax
    c7e1:	73 13                	jae    c7f6 <f0+0x1ee6>
    c7e3:	49 01 c4             	add    %rax,%r12
    c7e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7eb:	0f 84 55 0d 00 00    	je     d546 <f0+0x2c36>
    c7f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7fd:	33 f3 bf 
    c800:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    c807:	00 
    c808:	bf 01 00 00 00       	mov    $0x1,%edi
    c80d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    c814:	00 
    c815:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    c81c:	00 
    c81d:	e8 4e 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c822:	48 8b 15 0f 73 01 00 	mov    0x1730f(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c829:	49 89 c5             	mov    %rax,%r13
    c82c:	48 2b 05 dd 72 01 00 	sub    0x172dd(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c833:	48 c1 e2 10          	shl    $0x10,%rdx
    c837:	48 39 d0             	cmp    %rdx,%rax
    c83a:	73 59                	jae    c895 <f0+0x1f85>
    c83c:	48 89 c2             	mov    %rax,%rdx
    c83f:	48 c1 ea 10          	shr    $0x10,%rdx
    c843:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c847:	48 8b 15 0a 73 01 00 	mov    0x1730a(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c84e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c852:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c856:	4d 85 e4             	test   %r12,%r12
    c859:	74 3a                	je     c895 <f0+0x1f85>
    c85b:	0f b6 0a             	movzbl (%rdx),%ecx
    c85e:	80 f9 02             	cmp    $0x2,%cl
    c861:	0f 84 89 0b 00 00    	je     d3f0 <f0+0x2ae0>
    c867:	80 f9 01             	cmp    $0x1,%cl
    c86a:	75 29                	jne    c895 <f0+0x1f85>
    c86c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c86f:	0f b7 c0             	movzwl %ax,%eax
    c872:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c875:	48 0f af c1          	imul   %rcx,%rax
    c879:	48 c1 e8 20          	shr    $0x20,%rax
    c87d:	48 39 d0             	cmp    %rdx,%rax
    c880:	73 13                	jae    c895 <f0+0x1f85>
    c882:	49 01 c4             	add    %rax,%r12
    c885:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c88a:	0f 84 c3 0c 00 00    	je     d553 <f0+0x2c43>
    c890:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c895:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c89c:	00 f0 3f 
    c89f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    c8a6:	00 
    c8a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ac:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    c8b3:	00 
    c8b4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    c8bb:	00 
    c8bc:	e8 af 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c8c1:	48 8b 15 70 72 01 00 	mov    0x17270(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c8c8:	49 89 c5             	mov    %rax,%r13
    c8cb:	48 2b 05 3e 72 01 00 	sub    0x1723e(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c8d2:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d6:	48 39 d0             	cmp    %rdx,%rax
    c8d9:	73 59                	jae    c934 <f0+0x2024>
    c8db:	48 89 c2             	mov    %rax,%rdx
    c8de:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e6:	48 8b 15 6b 72 01 00 	mov    0x1726b(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c8ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f5:	4d 85 e4             	test   %r12,%r12
    c8f8:	74 3a                	je     c934 <f0+0x2024>
    c8fa:	0f b6 0a             	movzbl (%rdx),%ecx
    c8fd:	80 f9 02             	cmp    $0x2,%cl
    c900:	0f 84 da 0a 00 00    	je     d3e0 <f0+0x2ad0>
    c906:	80 f9 01             	cmp    $0x1,%cl
    c909:	75 29                	jne    c934 <f0+0x2024>
    c90b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c90e:	0f b7 c0             	movzwl %ax,%eax
    c911:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c914:	48 0f af c1          	imul   %rcx,%rax
    c918:	48 c1 e8 20          	shr    $0x20,%rax
    c91c:	48 39 d0             	cmp    %rdx,%rax
    c91f:	73 13                	jae    c934 <f0+0x2024>
    c921:	49 01 c4             	add    %rax,%r12
    c924:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c929:	0f 84 31 0c 00 00    	je     d560 <f0+0x2c50>
    c92f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c934:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c93b:	33 f3 bf 
    c93e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    c945:	00 
    c946:	bf 01 00 00 00       	mov    $0x1,%edi
    c94b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    c952:	00 
    c953:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    c95a:	00 
    c95b:	e8 10 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c960:	48 8b 15 d1 71 01 00 	mov    0x171d1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c967:	49 89 c5             	mov    %rax,%r13
    c96a:	48 2b 05 9f 71 01 00 	sub    0x1719f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c971:	48 c1 e2 10          	shl    $0x10,%rdx
    c975:	48 39 d0             	cmp    %rdx,%rax
    c978:	73 59                	jae    c9d3 <f0+0x20c3>
    c97a:	48 89 c2             	mov    %rax,%rdx
    c97d:	48 c1 ea 10          	shr    $0x10,%rdx
    c981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c985:	48 8b 15 cc 71 01 00 	mov    0x171cc(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c98c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c990:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c994:	4d 85 e4             	test   %r12,%r12
    c997:	74 3a                	je     c9d3 <f0+0x20c3>
    c999:	0f b6 0a             	movzbl (%rdx),%ecx
    c99c:	80 f9 02             	cmp    $0x2,%cl
    c99f:	0f 84 2b 0a 00 00    	je     d3d0 <f0+0x2ac0>
    c9a5:	80 f9 01             	cmp    $0x1,%cl
    c9a8:	75 29                	jne    c9d3 <f0+0x20c3>
    c9aa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9ad:	0f b7 c0             	movzwl %ax,%eax
    c9b0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b3:	48 0f af c1          	imul   %rcx,%rax
    c9b7:	48 c1 e8 20          	shr    $0x20,%rax
    c9bb:	48 39 d0             	cmp    %rdx,%rax
    c9be:	73 13                	jae    c9d3 <f0+0x20c3>
    c9c0:	49 01 c4             	add    %rax,%r12
    c9c3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9c8:	0f 84 9f 0b 00 00    	je     d56d <f0+0x2c5d>
    c9ce:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9da:	00 f0 3f 
    c9dd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    c9e4:	00 
    c9e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ea:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    c9f1:	00 
    c9f2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    c9f9:	00 
    c9fa:	e8 71 91 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c9ff:	48 8b 15 32 71 01 00 	mov    0x17132(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ca06:	49 89 c5             	mov    %rax,%r13
    ca09:	48 2b 05 00 71 01 00 	sub    0x17100(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ca10:	48 c1 e2 10          	shl    $0x10,%rdx
    ca14:	48 39 d0             	cmp    %rdx,%rax
    ca17:	73 59                	jae    ca72 <f0+0x2162>
    ca19:	48 89 c2             	mov    %rax,%rdx
    ca1c:	48 c1 ea 10          	shr    $0x10,%rdx
    ca20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca24:	48 8b 15 2d 71 01 00 	mov    0x1712d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ca2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca33:	4d 85 e4             	test   %r12,%r12
    ca36:	74 3a                	je     ca72 <f0+0x2162>
    ca38:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3b:	80 f9 02             	cmp    $0x2,%cl
    ca3e:	0f 84 7c 09 00 00    	je     d3c0 <f0+0x2ab0>
    ca44:	80 f9 01             	cmp    $0x1,%cl
    ca47:	75 29                	jne    ca72 <f0+0x2162>
    ca49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4c:	0f b7 c0             	movzwl %ax,%eax
    ca4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca52:	48 0f af c1          	imul   %rcx,%rax
    ca56:	48 c1 e8 20          	shr    $0x20,%rax
    ca5a:	48 39 d0             	cmp    %rdx,%rax
    ca5d:	73 13                	jae    ca72 <f0+0x2162>
    ca5f:	49 01 c4             	add    %rax,%r12
    ca62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca67:	0f 84 0d 0b 00 00    	je     d57a <f0+0x2c6a>
    ca6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca72:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca79:	33 f3 bf 
    ca7c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    ca83:	00 
    ca84:	bf 01 00 00 00       	mov    $0x1,%edi
    ca89:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    ca90:	00 
    ca91:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    ca98:	00 
    ca99:	e8 d2 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ca9e:	48 8b 15 93 70 01 00 	mov    0x17093(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    caa5:	49 89 c5             	mov    %rax,%r13
    caa8:	48 2b 05 61 70 01 00 	sub    0x17061(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    caaf:	48 c1 e2 10          	shl    $0x10,%rdx
    cab3:	48 39 d0             	cmp    %rdx,%rax
    cab6:	73 59                	jae    cb11 <f0+0x2201>
    cab8:	48 89 c2             	mov    %rax,%rdx
    cabb:	48 c1 ea 10          	shr    $0x10,%rdx
    cabf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac3:	48 8b 15 8e 70 01 00 	mov    0x1708e(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    caca:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cace:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad2:	4d 85 e4             	test   %r12,%r12
    cad5:	74 3a                	je     cb11 <f0+0x2201>
    cad7:	0f b6 0a             	movzbl (%rdx),%ecx
    cada:	80 f9 02             	cmp    $0x2,%cl
    cadd:	0f 84 cd 08 00 00    	je     d3b0 <f0+0x2aa0>
    cae3:	80 f9 01             	cmp    $0x1,%cl
    cae6:	75 29                	jne    cb11 <f0+0x2201>
    cae8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caeb:	0f b7 c0             	movzwl %ax,%eax
    caee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf1:	48 0f af c1          	imul   %rcx,%rax
    caf5:	48 c1 e8 20          	shr    $0x20,%rax
    caf9:	48 39 d0             	cmp    %rdx,%rax
    cafc:	73 13                	jae    cb11 <f0+0x2201>
    cafe:	49 01 c4             	add    %rax,%r12
    cb01:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb06:	0f 84 7b 0a 00 00    	je     d587 <f0+0x2c77>
    cb0c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb11:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb18:	00 f0 3f 
    cb1b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cb22:	00 
    cb23:	bf 01 00 00 00       	mov    $0x1,%edi
    cb28:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cb2f:	00 
    cb30:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cb37:	00 
    cb38:	e8 33 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cb3d:	48 8b 15 f4 6f 01 00 	mov    0x16ff4(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cb44:	49 89 c5             	mov    %rax,%r13
    cb47:	48 2b 05 c2 6f 01 00 	sub    0x16fc2(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cb4e:	48 c1 e2 10          	shl    $0x10,%rdx
    cb52:	48 39 d0             	cmp    %rdx,%rax
    cb55:	73 59                	jae    cbb0 <f0+0x22a0>
    cb57:	48 89 c2             	mov    %rax,%rdx
    cb5a:	48 c1 ea 10          	shr    $0x10,%rdx
    cb5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb62:	48 8b 15 ef 6f 01 00 	mov    0x16fef(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cb69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb6d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb71:	4d 85 e4             	test   %r12,%r12
    cb74:	74 3a                	je     cbb0 <f0+0x22a0>
    cb76:	0f b6 0a             	movzbl (%rdx),%ecx
    cb79:	80 f9 02             	cmp    $0x2,%cl
    cb7c:	0f 84 1e 08 00 00    	je     d3a0 <f0+0x2a90>
    cb82:	80 f9 01             	cmp    $0x1,%cl
    cb85:	75 29                	jne    cbb0 <f0+0x22a0>
    cb87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb8a:	0f b7 c0             	movzwl %ax,%eax
    cb8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb90:	48 0f af c1          	imul   %rcx,%rax
    cb94:	48 c1 e8 20          	shr    $0x20,%rax
    cb98:	48 39 d0             	cmp    %rdx,%rax
    cb9b:	73 13                	jae    cbb0 <f0+0x22a0>
    cb9d:	49 01 c4             	add    %rax,%r12
    cba0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba5:	0f 84 e9 09 00 00    	je     d594 <f0+0x2c84>
    cbab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbb7:	33 f3 bf 
    cbba:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    cbc1:	00 
    cbc2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    cbce:	00 
    cbcf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    cbd6:	00 
    cbd7:	e8 94 8f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cbdc:	48 8b 15 55 6f 01 00 	mov    0x16f55(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cbe3:	49 89 c5             	mov    %rax,%r13
    cbe6:	48 2b 05 23 6f 01 00 	sub    0x16f23(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cbed:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf1:	48 39 d0             	cmp    %rdx,%rax
    cbf4:	73 59                	jae    cc4f <f0+0x233f>
    cbf6:	48 89 c2             	mov    %rax,%rdx
    cbf9:	48 c1 ea 10          	shr    $0x10,%rdx
    cbfd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc01:	48 8b 15 50 6f 01 00 	mov    0x16f50(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cc08:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc10:	4d 85 e4             	test   %r12,%r12
    cc13:	74 3a                	je     cc4f <f0+0x233f>
    cc15:	0f b6 0a             	movzbl (%rdx),%ecx
    cc18:	80 f9 02             	cmp    $0x2,%cl
    cc1b:	0f 84 6f 07 00 00    	je     d390 <f0+0x2a80>
    cc21:	80 f9 01             	cmp    $0x1,%cl
    cc24:	75 29                	jne    cc4f <f0+0x233f>
    cc26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc29:	0f b7 c0             	movzwl %ax,%eax
    cc2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc2f:	48 0f af c1          	imul   %rcx,%rax
    cc33:	48 c1 e8 20          	shr    $0x20,%rax
    cc37:	48 39 d0             	cmp    %rdx,%rax
    cc3a:	73 13                	jae    cc4f <f0+0x233f>
    cc3c:	49 01 c4             	add    %rax,%r12
    cc3f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc44:	0f 84 57 09 00 00    	je     d5a1 <f0+0x2c91>
    cc4a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc4f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc56:	00 f0 3f 
    cc59:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cc60:	00 
    cc61:	bf 01 00 00 00       	mov    $0x1,%edi
    cc66:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cc6d:	00 
    cc6e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    cc75:	00 
    cc76:	e8 f5 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cc7b:	48 8b 15 b6 6e 01 00 	mov    0x16eb6(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cc82:	49 89 c5             	mov    %rax,%r13
    cc85:	48 2b 05 84 6e 01 00 	sub    0x16e84(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cc8c:	48 c1 e2 10          	shl    $0x10,%rdx
    cc90:	48 39 d0             	cmp    %rdx,%rax
    cc93:	73 59                	jae    ccee <f0+0x23de>
    cc95:	48 89 c2             	mov    %rax,%rdx
    cc98:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca0:	48 8b 15 b1 6e 01 00 	mov    0x16eb1(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cca7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccab:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccaf:	4d 85 e4             	test   %r12,%r12
    ccb2:	74 3a                	je     ccee <f0+0x23de>
    ccb4:	0f b6 0a             	movzbl (%rdx),%ecx
    ccb7:	80 f9 02             	cmp    $0x2,%cl
    ccba:	0f 84 c0 06 00 00    	je     d380 <f0+0x2a70>
    ccc0:	80 f9 01             	cmp    $0x1,%cl
    ccc3:	75 29                	jne    ccee <f0+0x23de>
    ccc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccc8:	0f b7 c0             	movzwl %ax,%eax
    cccb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccce:	48 0f af c1          	imul   %rcx,%rax
    ccd2:	48 c1 e8 20          	shr    $0x20,%rax
    ccd6:	48 39 d0             	cmp    %rdx,%rax
    ccd9:	73 13                	jae    ccee <f0+0x23de>
    ccdb:	49 01 c4             	add    %rax,%r12
    ccde:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce3:	0f 84 c5 08 00 00    	je     d5ae <f0+0x2c9e>
    cce9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccee:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccf5:	33 f3 bf 
    ccf8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    ccff:	00 
    cd00:	bf 01 00 00 00       	mov    $0x1,%edi
    cd05:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cd0c:	00 
    cd0d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cd14:	00 
    cd15:	e8 56 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cd1a:	48 8b 15 17 6e 01 00 	mov    0x16e17(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cd21:	49 89 c5             	mov    %rax,%r13
    cd24:	48 2b 05 e5 6d 01 00 	sub    0x16de5(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cd2b:	48 c1 e2 10          	shl    $0x10,%rdx
    cd2f:	48 39 d0             	cmp    %rdx,%rax
    cd32:	73 59                	jae    cd8d <f0+0x247d>
    cd34:	48 89 c2             	mov    %rax,%rdx
    cd37:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd3f:	48 8b 15 12 6e 01 00 	mov    0x16e12(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cd46:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd4a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd4e:	4d 85 e4             	test   %r12,%r12
    cd51:	74 3a                	je     cd8d <f0+0x247d>
    cd53:	0f b6 0a             	movzbl (%rdx),%ecx
    cd56:	80 f9 02             	cmp    $0x2,%cl
    cd59:	0f 84 11 06 00 00    	je     d370 <f0+0x2a60>
    cd5f:	80 f9 01             	cmp    $0x1,%cl
    cd62:	75 29                	jne    cd8d <f0+0x247d>
    cd64:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd67:	0f b7 c0             	movzwl %ax,%eax
    cd6a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd6d:	48 0f af c1          	imul   %rcx,%rax
    cd71:	48 c1 e8 20          	shr    $0x20,%rax
    cd75:	48 39 d0             	cmp    %rdx,%rax
    cd78:	73 13                	jae    cd8d <f0+0x247d>
    cd7a:	49 01 c4             	add    %rax,%r12
    cd7d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd82:	0f 84 33 08 00 00    	je     d5bb <f0+0x2cab>
    cd88:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd8d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd94:	00 f0 3f 
    cd97:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    cd9e:	00 
    cd9f:	bf 01 00 00 00       	mov    $0x1,%edi
    cda4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    cdab:	00 
    cdac:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    cdb3:	00 
    cdb4:	e8 b7 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cdb9:	48 8b 15 78 6d 01 00 	mov    0x16d78(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cdc0:	49 89 c5             	mov    %rax,%r13
    cdc3:	48 2b 05 46 6d 01 00 	sub    0x16d46(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cdca:	48 c1 e2 10          	shl    $0x10,%rdx
    cdce:	48 39 d0             	cmp    %rdx,%rax
    cdd1:	73 59                	jae    ce2c <f0+0x251c>
    cdd3:	48 89 c2             	mov    %rax,%rdx
    cdd6:	48 c1 ea 10          	shr    $0x10,%rdx
    cdda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdde:	48 8b 15 73 6d 01 00 	mov    0x16d73(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cde5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cde9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cded:	4d 85 e4             	test   %r12,%r12
    cdf0:	74 3a                	je     ce2c <f0+0x251c>
    cdf2:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf5:	80 f9 02             	cmp    $0x2,%cl
    cdf8:	0f 84 62 05 00 00    	je     d360 <f0+0x2a50>
    cdfe:	80 f9 01             	cmp    $0x1,%cl
    ce01:	75 29                	jne    ce2c <f0+0x251c>
    ce03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce06:	0f b7 c0             	movzwl %ax,%eax
    ce09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0c:	48 0f af c1          	imul   %rcx,%rax
    ce10:	48 c1 e8 20          	shr    $0x20,%rax
    ce14:	48 39 d0             	cmp    %rdx,%rax
    ce17:	73 13                	jae    ce2c <f0+0x251c>
    ce19:	49 01 c4             	add    %rax,%r12
    ce1c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce21:	0f 84 a1 07 00 00    	je     d5c8 <f0+0x2cb8>
    ce27:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce33:	33 f3 bf 
    ce36:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    ce3d:	00 
    ce3e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce43:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    ce4a:	00 
    ce4b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    ce52:	00 
    ce53:	e8 18 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ce58:	48 8b 15 d9 6c 01 00 	mov    0x16cd9(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ce5f:	49 89 c5             	mov    %rax,%r13
    ce62:	48 2b 05 a7 6c 01 00 	sub    0x16ca7(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ce69:	48 c1 e2 10          	shl    $0x10,%rdx
    ce6d:	48 39 d0             	cmp    %rdx,%rax
    ce70:	73 59                	jae    cecb <f0+0x25bb>
    ce72:	48 89 c2             	mov    %rax,%rdx
    ce75:	48 c1 ea 10          	shr    $0x10,%rdx
    ce79:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce7d:	48 8b 15 d4 6c 01 00 	mov    0x16cd4(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ce84:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce88:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8c:	4d 85 e4             	test   %r12,%r12
    ce8f:	74 3a                	je     cecb <f0+0x25bb>
    ce91:	0f b6 0a             	movzbl (%rdx),%ecx
    ce94:	80 f9 02             	cmp    $0x2,%cl
    ce97:	0f 84 b3 04 00 00    	je     d350 <f0+0x2a40>
    ce9d:	80 f9 01             	cmp    $0x1,%cl
    cea0:	75 29                	jne    cecb <f0+0x25bb>
    cea2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea5:	0f b7 c0             	movzwl %ax,%eax
    cea8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceab:	48 0f af c1          	imul   %rcx,%rax
    ceaf:	48 c1 e8 20          	shr    $0x20,%rax
    ceb3:	48 39 d0             	cmp    %rdx,%rax
    ceb6:	73 13                	jae    cecb <f0+0x25bb>
    ceb8:	49 01 c4             	add    %rax,%r12
    cebb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec0:	0f 84 0f 07 00 00    	je     d5d5 <f0+0x2cc5>
    cec6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cecb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ced2:	00 f0 3f 
    ced5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    cedc:	00 
    cedd:	bf 01 00 00 00       	mov    $0x1,%edi
    cee2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    cee9:	00 
    ceea:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    cef1:	00 
    cef2:	e8 79 8c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cef7:	48 8b 15 3a 6c 01 00 	mov    0x16c3a(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cefe:	49 89 c5             	mov    %rax,%r13
    cf01:	48 2b 05 08 6c 01 00 	sub    0x16c08(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cf08:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0c:	48 39 d0             	cmp    %rdx,%rax
    cf0f:	73 59                	jae    cf6a <f0+0x265a>
    cf11:	48 89 c2             	mov    %rax,%rdx
    cf14:	48 c1 ea 10          	shr    $0x10,%rdx
    cf18:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1c:	48 8b 15 35 6c 01 00 	mov    0x16c35(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cf23:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf27:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2b:	4d 85 e4             	test   %r12,%r12
    cf2e:	74 3a                	je     cf6a <f0+0x265a>
    cf30:	0f b6 0a             	movzbl (%rdx),%ecx
    cf33:	80 f9 02             	cmp    $0x2,%cl
    cf36:	0f 84 04 04 00 00    	je     d340 <f0+0x2a30>
    cf3c:	80 f9 01             	cmp    $0x1,%cl
    cf3f:	75 29                	jne    cf6a <f0+0x265a>
    cf41:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf44:	0f b7 c0             	movzwl %ax,%eax
    cf47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf4a:	48 0f af c1          	imul   %rcx,%rax
    cf4e:	48 c1 e8 20          	shr    $0x20,%rax
    cf52:	48 39 d0             	cmp    %rdx,%rax
    cf55:	73 13                	jae    cf6a <f0+0x265a>
    cf57:	49 01 c4             	add    %rax,%r12
    cf5a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf5f:	0f 84 7d 06 00 00    	je     d5e2 <f0+0x2cd2>
    cf65:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf6a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf71:	33 f3 bf 
    cf74:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    cf7b:	00 
    cf7c:	bf 01 00 00 00       	mov    $0x1,%edi
    cf81:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    cf88:	00 
    cf89:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    cf90:	00 
    cf91:	e8 da 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cf96:	48 8b 15 9b 6b 01 00 	mov    0x16b9b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cf9d:	49 89 c5             	mov    %rax,%r13
    cfa0:	48 2b 05 69 6b 01 00 	sub    0x16b69(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cfa7:	48 c1 e2 10          	shl    $0x10,%rdx
    cfab:	48 39 d0             	cmp    %rdx,%rax
    cfae:	73 59                	jae    d009 <f0+0x26f9>
    cfb0:	48 89 c2             	mov    %rax,%rdx
    cfb3:	48 c1 ea 10          	shr    $0x10,%rdx
    cfb7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfbb:	48 8b 15 96 6b 01 00 	mov    0x16b96(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cfc2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfca:	4d 85 e4             	test   %r12,%r12
    cfcd:	74 3a                	je     d009 <f0+0x26f9>
    cfcf:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd2:	80 f9 02             	cmp    $0x2,%cl
    cfd5:	0f 84 55 03 00 00    	je     d330 <f0+0x2a20>
    cfdb:	80 f9 01             	cmp    $0x1,%cl
    cfde:	75 29                	jne    d009 <f0+0x26f9>
    cfe0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe3:	0f b7 c0             	movzwl %ax,%eax
    cfe6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfe9:	48 0f af c1          	imul   %rcx,%rax
    cfed:	48 c1 e8 20          	shr    $0x20,%rax
    cff1:	48 39 d0             	cmp    %rdx,%rax
    cff4:	73 13                	jae    d009 <f0+0x26f9>
    cff6:	49 01 c4             	add    %rax,%r12
    cff9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cffe:	0f 84 eb 05 00 00    	je     d5ef <f0+0x2cdf>
    d004:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d009:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d010:	00 f0 3f 
    d013:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d01a:	00 
    d01b:	bf 01 00 00 00       	mov    $0x1,%edi
    d020:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d027:	00 
    d028:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d02f:	00 
    d030:	e8 3b 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d035:	48 8b 15 fc 6a 01 00 	mov    0x16afc(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    d03c:	49 89 c5             	mov    %rax,%r13
    d03f:	48 2b 05 ca 6a 01 00 	sub    0x16aca(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    d046:	48 c1 e2 10          	shl    $0x10,%rdx
    d04a:	48 39 d0             	cmp    %rdx,%rax
    d04d:	73 59                	jae    d0a8 <f0+0x2798>
    d04f:	48 89 c2             	mov    %rax,%rdx
    d052:	48 c1 ea 10          	shr    $0x10,%rdx
    d056:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d05a:	48 8b 15 f7 6a 01 00 	mov    0x16af7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    d061:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d065:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d069:	4d 85 e4             	test   %r12,%r12
    d06c:	74 3a                	je     d0a8 <f0+0x2798>
    d06e:	0f b6 0a             	movzbl (%rdx),%ecx
    d071:	80 f9 02             	cmp    $0x2,%cl
    d074:	0f 84 a6 02 00 00    	je     d320 <f0+0x2a10>
    d07a:	80 f9 01             	cmp    $0x1,%cl
    d07d:	75 29                	jne    d0a8 <f0+0x2798>
    d07f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d082:	0f b7 c0             	movzwl %ax,%eax
    d085:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d088:	48 0f af c1          	imul   %rcx,%rax
    d08c:	48 c1 e8 20          	shr    $0x20,%rax
    d090:	48 39 d0             	cmp    %rdx,%rax
    d093:	73 13                	jae    d0a8 <f0+0x2798>
    d095:	49 01 c4             	add    %rax,%r12
    d098:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d09d:	0f 84 59 05 00 00    	je     d5fc <f0+0x2cec>
    d0a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0a8:	48 89 ee             	mov    %rbp,%rsi
    d0ab:	bf 01 00 00 00       	mov    $0x1,%edi
    d0b0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0b7:	33 f3 bf 
    d0ba:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d0c1:	00 
    d0c2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d0c9:	00 
    d0ca:	e8 a1 8a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d0cf:	48 8b 15 62 6a 01 00 	mov    0x16a62(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    d0d6:	48 89 c5             	mov    %rax,%rbp
    d0d9:	48 2b 05 30 6a 01 00 	sub    0x16a30(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    d0e0:	48 c1 e2 10          	shl    $0x10,%rdx
    d0e4:	48 39 d0             	cmp    %rdx,%rax
    d0e7:	73 59                	jae    d142 <f0+0x2832>
    d0e9:	48 89 c2             	mov    %rax,%rdx
    d0ec:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0f4:	48 8b 15 5d 6a 01 00 	mov    0x16a5d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    d0fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d103:	4d 85 e4             	test   %r12,%r12
    d106:	74 3a                	je     d142 <f0+0x2832>
    d108:	0f b6 0a             	movzbl (%rdx),%ecx
    d10b:	80 f9 02             	cmp    $0x2,%cl
    d10e:	0f 84 fc 01 00 00    	je     d310 <f0+0x2a00>
    d114:	80 f9 01             	cmp    $0x1,%cl
    d117:	75 29                	jne    d142 <f0+0x2832>
    d119:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d11c:	0f b7 c0             	movzwl %ax,%eax
    d11f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d122:	48 0f af c1          	imul   %rcx,%rax
    d126:	48 c1 e8 20          	shr    $0x20,%rax
    d12a:	48 39 d0             	cmp    %rdx,%rax
    d12d:	73 13                	jae    d142 <f0+0x2832>
    d12f:	49 01 c4             	add    %rax,%r12
    d132:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d137:	0f 84 d1 02 00 00    	je     d40e <f0+0x2afe>
    d13d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d142:	48 89 de             	mov    %rbx,%rsi
    d145:	48 89 ef             	mov    %rbp,%rdi
    d148:	e8 c3 be ff ff       	call   9010 <fwp_hof0.constprop.0>
    d14d:	48 89 ef             	mov    %rbp,%rdi
    d150:	e8 eb a2 ff ff       	call   7440 <fwp_drop0>
    d155:	48 89 df             	mov    %rbx,%rdi
    d158:	e8 e3 a2 ff ff       	call   7440 <fwp_drop0>
    d15d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d164:	00 
    d165:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d16c:	00 00 
    d16e:	0f 85 95 04 00 00    	jne    d609 <f0+0x2cf9>
    d174:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d17b:	31 c0                	xor    %eax,%eax
    d17d:	5b                   	pop    %rbx
    d17e:	5d                   	pop    %rbp
    d17f:	41 5c                	pop    %r12
    d181:	41 5d                	pop    %r13
    d183:	41 5e                	pop    %r14
    d185:	c3                   	ret
    d186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d18d:	00 00 00 
    d190:	4c 89 ef             	mov    %r13,%rdi
    d193:	e8 78 81 ff ff       	call   5310 <fwp_rc_forget_slot>
    d198:	e9 2c d8 ff ff       	jmp    a9c9 <f0+0xb9>
    d19d:	0f 1f 00             	nopl   (%rax)
    d1a0:	66 85 c0             	test   %ax,%ax
    d1a3:	0f 85 ae f5 ff ff    	jne    c757 <f0+0x1e47>
    d1a9:	e9 99 f5 ff ff       	jmp    c747 <f0+0x1e37>
    d1ae:	66 90                	xchg   %ax,%ax
    d1b0:	66 85 c0             	test   %ax,%ax
    d1b3:	0f 85 ff f4 ff ff    	jne    c6b8 <f0+0x1da8>
    d1b9:	e9 ea f4 ff ff       	jmp    c6a8 <f0+0x1d98>
    d1be:	66 90                	xchg   %ax,%ax
    d1c0:	66 85 c0             	test   %ax,%ax
    d1c3:	0f 85 50 f4 ff ff    	jne    c619 <f0+0x1d09>
    d1c9:	e9 3b f4 ff ff       	jmp    c609 <f0+0x1cf9>
    d1ce:	66 90                	xchg   %ax,%ax
    d1d0:	66 85 c0             	test   %ax,%ax
    d1d3:	0f 85 a1 f3 ff ff    	jne    c57a <f0+0x1c6a>
    d1d9:	e9 8c f3 ff ff       	jmp    c56a <f0+0x1c5a>
    d1de:	66 90                	xchg   %ax,%ax
    d1e0:	66 85 c0             	test   %ax,%ax
    d1e3:	0f 85 f2 f2 ff ff    	jne    c4db <f0+0x1bcb>
    d1e9:	e9 dd f2 ff ff       	jmp    c4cb <f0+0x1bbb>
    d1ee:	66 90                	xchg   %ax,%ax
    d1f0:	66 85 c0             	test   %ax,%ax
    d1f3:	0f 85 43 f2 ff ff    	jne    c43c <f0+0x1b2c>
    d1f9:	e9 2e f2 ff ff       	jmp    c42c <f0+0x1b1c>
    d1fe:	66 90                	xchg   %ax,%ax
    d200:	66 85 c0             	test   %ax,%ax
    d203:	0f 85 94 f1 ff ff    	jne    c39d <f0+0x1a8d>
    d209:	e9 7f f1 ff ff       	jmp    c38d <f0+0x1a7d>
    d20e:	66 90                	xchg   %ax,%ax
    d210:	66 85 c0             	test   %ax,%ax
    d213:	0f 85 e5 f0 ff ff    	jne    c2fe <f0+0x19ee>
    d219:	e9 d0 f0 ff ff       	jmp    c2ee <f0+0x19de>
    d21e:	66 90                	xchg   %ax,%ax
    d220:	66 85 c0             	test   %ax,%ax
    d223:	0f 85 fd d9 ff ff    	jne    ac26 <f0+0x316>
    d229:	e9 e8 d9 ff ff       	jmp    ac16 <f0+0x306>
    d22e:	66 90                	xchg   %ax,%ax
    d230:	66 85 c0             	test   %ax,%ax
    d233:	0f 85 57 d9 ff ff    	jne    ab90 <f0+0x280>
    d239:	e9 42 d9 ff ff       	jmp    ab80 <f0+0x270>
    d23e:	66 90                	xchg   %ax,%ax
    d240:	66 85 c0             	test   %ax,%ax
    d243:	0f 85 b1 d8 ff ff    	jne    aafa <f0+0x1ea>
    d249:	e9 9c d8 ff ff       	jmp    aaea <f0+0x1da>
    d24e:	66 90                	xchg   %ax,%ax
    d250:	66 85 c0             	test   %ax,%ax
    d253:	0f 85 0e eb ff ff    	jne    bd67 <f0+0x1457>
    d259:	e9 f9 ea ff ff       	jmp    bd57 <f0+0x1447>
    d25e:	66 90                	xchg   %ax,%ax
    d260:	66 85 c0             	test   %ax,%ax
    d263:	0f 85 5f ea ff ff    	jne    bcc8 <f0+0x13b8>
    d269:	e9 4a ea ff ff       	jmp    bcb8 <f0+0x13a8>
    d26e:	66 90                	xchg   %ax,%ax
    d270:	66 85 c0             	test   %ax,%ax
    d273:	0f 85 e2 da ff ff    	jne    ad5b <f0+0x44b>
    d279:	e9 cd da ff ff       	jmp    ad4b <f0+0x43b>
    d27e:	66 90                	xchg   %ax,%ax
    d280:	66 85 c0             	test   %ax,%ax
    d283:	0f 85 33 da ff ff    	jne    acbc <f0+0x3ac>
    d289:	e9 1e da ff ff       	jmp    acac <f0+0x39c>
    d28e:	66 90                	xchg   %ax,%ax
    d290:	66 85 c0             	test   %ax,%ax
    d293:	0f 85 c6 ef ff ff    	jne    c25f <f0+0x194f>
    d299:	e9 b1 ef ff ff       	jmp    c24f <f0+0x193f>
    d29e:	66 90                	xchg   %ax,%ax
    d2a0:	66 85 c0             	test   %ax,%ax
    d2a3:	0f 85 17 ef ff ff    	jne    c1c0 <f0+0x18b0>
    d2a9:	e9 02 ef ff ff       	jmp    c1b0 <f0+0x18a0>
    d2ae:	66 90                	xchg   %ax,%ax
    d2b0:	66 85 c0             	test   %ax,%ax
    d2b3:	0f 85 68 ee ff ff    	jne    c121 <f0+0x1811>
    d2b9:	e9 53 ee ff ff       	jmp    c111 <f0+0x1801>
    d2be:	66 90                	xchg   %ax,%ax
    d2c0:	66 85 c0             	test   %ax,%ax
    d2c3:	0f 85 b9 ed ff ff    	jne    c082 <f0+0x1772>
    d2c9:	e9 a4 ed ff ff       	jmp    c072 <f0+0x1762>
    d2ce:	66 90                	xchg   %ax,%ax
    d2d0:	66 85 c0             	test   %ax,%ax
    d2d3:	0f 85 0a ed ff ff    	jne    bfe3 <f0+0x16d3>
    d2d9:	e9 f5 ec ff ff       	jmp    bfd3 <f0+0x16c3>
    d2de:	66 90                	xchg   %ax,%ax
    d2e0:	66 85 c0             	test   %ax,%ax
    d2e3:	0f 85 5b ec ff ff    	jne    bf44 <f0+0x1634>
    d2e9:	e9 46 ec ff ff       	jmp    bf34 <f0+0x1624>
    d2ee:	66 90                	xchg   %ax,%ax
    d2f0:	66 85 c0             	test   %ax,%ax
    d2f3:	0f 85 ac eb ff ff    	jne    bea5 <f0+0x1595>
    d2f9:	e9 97 eb ff ff       	jmp    be95 <f0+0x1585>
    d2fe:	66 90                	xchg   %ax,%ax
    d300:	66 85 c0             	test   %ax,%ax
    d303:	0f 85 fd ea ff ff    	jne    be06 <f0+0x14f6>
    d309:	e9 e8 ea ff ff       	jmp    bdf6 <f0+0x14e6>
    d30e:	66 90                	xchg   %ax,%ax
    d310:	66 85 c0             	test   %ax,%ax
    d313:	0f 85 29 fe ff ff    	jne    d142 <f0+0x2832>
    d319:	e9 14 fe ff ff       	jmp    d132 <f0+0x2822>
    d31e:	66 90                	xchg   %ax,%ax
    d320:	66 85 c0             	test   %ax,%ax
    d323:	0f 85 7f fd ff ff    	jne    d0a8 <f0+0x2798>
    d329:	e9 6a fd ff ff       	jmp    d098 <f0+0x2788>
    d32e:	66 90                	xchg   %ax,%ax
    d330:	66 85 c0             	test   %ax,%ax
    d333:	0f 85 d0 fc ff ff    	jne    d009 <f0+0x26f9>
    d339:	e9 bb fc ff ff       	jmp    cff9 <f0+0x26e9>
    d33e:	66 90                	xchg   %ax,%ax
    d340:	66 85 c0             	test   %ax,%ax
    d343:	0f 85 21 fc ff ff    	jne    cf6a <f0+0x265a>
    d349:	e9 0c fc ff ff       	jmp    cf5a <f0+0x264a>
    d34e:	66 90                	xchg   %ax,%ax
    d350:	66 85 c0             	test   %ax,%ax
    d353:	0f 85 72 fb ff ff    	jne    cecb <f0+0x25bb>
    d359:	e9 5d fb ff ff       	jmp    cebb <f0+0x25ab>
    d35e:	66 90                	xchg   %ax,%ax
    d360:	66 85 c0             	test   %ax,%ax
    d363:	0f 85 c3 fa ff ff    	jne    ce2c <f0+0x251c>
    d369:	e9 ae fa ff ff       	jmp    ce1c <f0+0x250c>
    d36e:	66 90                	xchg   %ax,%ax
    d370:	66 85 c0             	test   %ax,%ax
    d373:	0f 85 14 fa ff ff    	jne    cd8d <f0+0x247d>
    d379:	e9 ff f9 ff ff       	jmp    cd7d <f0+0x246d>
    d37e:	66 90                	xchg   %ax,%ax
    d380:	66 85 c0             	test   %ax,%ax
    d383:	0f 85 65 f9 ff ff    	jne    ccee <f0+0x23de>
    d389:	e9 50 f9 ff ff       	jmp    ccde <f0+0x23ce>
    d38e:	66 90                	xchg   %ax,%ax
    d390:	66 85 c0             	test   %ax,%ax
    d393:	0f 85 b6 f8 ff ff    	jne    cc4f <f0+0x233f>
    d399:	e9 a1 f8 ff ff       	jmp    cc3f <f0+0x232f>
    d39e:	66 90                	xchg   %ax,%ax
    d3a0:	66 85 c0             	test   %ax,%ax
    d3a3:	0f 85 07 f8 ff ff    	jne    cbb0 <f0+0x22a0>
    d3a9:	e9 f2 f7 ff ff       	jmp    cba0 <f0+0x2290>
    d3ae:	66 90                	xchg   %ax,%ax
    d3b0:	66 85 c0             	test   %ax,%ax
    d3b3:	0f 85 58 f7 ff ff    	jne    cb11 <f0+0x2201>
    d3b9:	e9 43 f7 ff ff       	jmp    cb01 <f0+0x21f1>
    d3be:	66 90                	xchg   %ax,%ax
    d3c0:	66 85 c0             	test   %ax,%ax
    d3c3:	0f 85 a9 f6 ff ff    	jne    ca72 <f0+0x2162>
    d3c9:	e9 94 f6 ff ff       	jmp    ca62 <f0+0x2152>
    d3ce:	66 90                	xchg   %ax,%ax
    d3d0:	66 85 c0             	test   %ax,%ax
    d3d3:	0f 85 fa f5 ff ff    	jne    c9d3 <f0+0x20c3>
    d3d9:	e9 e5 f5 ff ff       	jmp    c9c3 <f0+0x20b3>
    d3de:	66 90                	xchg   %ax,%ax
    d3e0:	66 85 c0             	test   %ax,%ax
    d3e3:	0f 85 4b f5 ff ff    	jne    c934 <f0+0x2024>
    d3e9:	e9 36 f5 ff ff       	jmp    c924 <f0+0x2014>
    d3ee:	66 90                	xchg   %ax,%ax
    d3f0:	66 85 c0             	test   %ax,%ax
    d3f3:	0f 85 9c f4 ff ff    	jne    c895 <f0+0x1f85>
    d3f9:	e9 87 f4 ff ff       	jmp    c885 <f0+0x1f75>
    d3fe:	66 90                	xchg   %ax,%ax
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 ed f3 ff ff    	jne    c7f6 <f0+0x1ee6>
    d409:	e9 d8 f3 ff ff       	jmp    c7e6 <f0+0x1ed6>
    d40e:	4c 89 e7             	mov    %r12,%rdi
    d411:	e8 fa 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d416:	e9 22 fd ff ff       	jmp    d13d <f0+0x282d>
    d41b:	4c 89 e7             	mov    %r12,%rdi
    d41e:	e8 ed 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d423:	e9 cd d6 ff ff       	jmp    aaf5 <f0+0x1e5>
    d428:	4c 89 e7             	mov    %r12,%rdi
    d42b:	e8 e0 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d430:	e9 56 d7 ff ff       	jmp    ab8b <f0+0x27b>
    d435:	4c 89 e7             	mov    %r12,%rdi
    d438:	e8 d3 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d43d:	e9 df d7 ff ff       	jmp    ac21 <f0+0x311>
    d442:	4c 89 e7             	mov    %r12,%rdi
    d445:	e8 c6 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d44a:	e9 68 d8 ff ff       	jmp    acb7 <f0+0x3a7>
    d44f:	4c 89 e7             	mov    %r12,%rdi
    d452:	e8 b9 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d457:	e9 fa d8 ff ff       	jmp    ad56 <f0+0x446>
    d45c:	4c 89 e7             	mov    %r12,%rdi
    d45f:	e8 ac 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d464:	e9 5a e8 ff ff       	jmp    bcc3 <f0+0x13b3>
    d469:	4c 89 e7             	mov    %r12,%rdi
    d46c:	e8 9f 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d471:	e9 ec e8 ff ff       	jmp    bd62 <f0+0x1452>
    d476:	4c 89 e7             	mov    %r12,%rdi
    d479:	e8 92 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d47e:	e9 7e e9 ff ff       	jmp    be01 <f0+0x14f1>
    d483:	4c 89 e7             	mov    %r12,%rdi
    d486:	e8 85 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d48b:	e9 10 ea ff ff       	jmp    bea0 <f0+0x1590>
    d490:	4c 89 e7             	mov    %r12,%rdi
    d493:	e8 78 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d498:	e9 a2 ea ff ff       	jmp    bf3f <f0+0x162f>
    d49d:	4c 89 e7             	mov    %r12,%rdi
    d4a0:	e8 6b 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4a5:	e9 34 eb ff ff       	jmp    bfde <f0+0x16ce>
    d4aa:	4c 89 e7             	mov    %r12,%rdi
    d4ad:	e8 5e 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4b2:	e9 c6 eb ff ff       	jmp    c07d <f0+0x176d>
    d4b7:	4c 89 e7             	mov    %r12,%rdi
    d4ba:	e8 51 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4bf:	e9 58 ec ff ff       	jmp    c11c <f0+0x180c>
    d4c4:	4c 89 e7             	mov    %r12,%rdi
    d4c7:	e8 44 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4cc:	e9 ea ec ff ff       	jmp    c1bb <f0+0x18ab>
    d4d1:	4c 89 e7             	mov    %r12,%rdi
    d4d4:	e8 37 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4d9:	e9 7c ed ff ff       	jmp    c25a <f0+0x194a>
    d4de:	4c 89 e7             	mov    %r12,%rdi
    d4e1:	e8 2a 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4e6:	e9 0e ee ff ff       	jmp    c2f9 <f0+0x19e9>
    d4eb:	4c 89 e7             	mov    %r12,%rdi
    d4ee:	e8 1d 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4f3:	e9 a0 ee ff ff       	jmp    c398 <f0+0x1a88>
    d4f8:	4c 89 e7             	mov    %r12,%rdi
    d4fb:	e8 10 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d500:	e9 32 ef ff ff       	jmp    c437 <f0+0x1b27>
    d505:	4c 89 e7             	mov    %r12,%rdi
    d508:	e8 03 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d50d:	e9 c4 ef ff ff       	jmp    c4d6 <f0+0x1bc6>
    d512:	4c 89 e7             	mov    %r12,%rdi
    d515:	e8 f6 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d51a:	e9 56 f0 ff ff       	jmp    c575 <f0+0x1c65>
    d51f:	4c 89 e7             	mov    %r12,%rdi
    d522:	e8 e9 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d527:	e9 e8 f0 ff ff       	jmp    c614 <f0+0x1d04>
    d52c:	4c 89 e7             	mov    %r12,%rdi
    d52f:	e8 dc 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d534:	e9 7a f1 ff ff       	jmp    c6b3 <f0+0x1da3>
    d539:	4c 89 e7             	mov    %r12,%rdi
    d53c:	e8 cf 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d541:	e9 0c f2 ff ff       	jmp    c752 <f0+0x1e42>
    d546:	4c 89 e7             	mov    %r12,%rdi
    d549:	e8 c2 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d54e:	e9 9e f2 ff ff       	jmp    c7f1 <f0+0x1ee1>
    d553:	4c 89 e7             	mov    %r12,%rdi
    d556:	e8 b5 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d55b:	e9 30 f3 ff ff       	jmp    c890 <f0+0x1f80>
    d560:	4c 89 e7             	mov    %r12,%rdi
    d563:	e8 a8 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d568:	e9 c2 f3 ff ff       	jmp    c92f <f0+0x201f>
    d56d:	4c 89 e7             	mov    %r12,%rdi
    d570:	e8 9b 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d575:	e9 54 f4 ff ff       	jmp    c9ce <f0+0x20be>
    d57a:	4c 89 e7             	mov    %r12,%rdi
    d57d:	e8 8e 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d582:	e9 e6 f4 ff ff       	jmp    ca6d <f0+0x215d>
    d587:	4c 89 e7             	mov    %r12,%rdi
    d58a:	e8 81 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d58f:	e9 78 f5 ff ff       	jmp    cb0c <f0+0x21fc>
    d594:	4c 89 e7             	mov    %r12,%rdi
    d597:	e8 74 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d59c:	e9 0a f6 ff ff       	jmp    cbab <f0+0x229b>
    d5a1:	4c 89 e7             	mov    %r12,%rdi
    d5a4:	e8 67 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5a9:	e9 9c f6 ff ff       	jmp    cc4a <f0+0x233a>
    d5ae:	4c 89 e7             	mov    %r12,%rdi
    d5b1:	e8 5a 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5b6:	e9 2e f7 ff ff       	jmp    cce9 <f0+0x23d9>
    d5bb:	4c 89 e7             	mov    %r12,%rdi
    d5be:	e8 4d 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5c3:	e9 c0 f7 ff ff       	jmp    cd88 <f0+0x2478>
    d5c8:	4c 89 e7             	mov    %r12,%rdi
    d5cb:	e8 40 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5d0:	e9 52 f8 ff ff       	jmp    ce27 <f0+0x2517>
    d5d5:	4c 89 e7             	mov    %r12,%rdi
    d5d8:	e8 33 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5dd:	e9 e4 f8 ff ff       	jmp    cec6 <f0+0x25b6>
    d5e2:	4c 89 e7             	mov    %r12,%rdi
    d5e5:	e8 26 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5ea:	e9 76 f9 ff ff       	jmp    cf65 <f0+0x2655>
    d5ef:	4c 89 e7             	mov    %r12,%rdi
    d5f2:	e8 19 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5f7:	e9 08 fa ff ff       	jmp    d004 <f0+0x26f4>
    d5fc:	4c 89 e7             	mov    %r12,%rdi
    d5ff:	e8 0c 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d604:	e9 9a fa ff ff       	jmp    d0a3 <f0+0x2793>
    d609:	e8 52 5e ff ff       	call   3460 <__stack_chk_fail@plt>
    d60e:	66 90                	xchg   %ax,%ax

000000000000d610 <fwp_main_thread>:
    d610:	f3 0f 1e fa          	endbr64
    d614:	41 54                	push   %r12
    d616:	55                   	push   %rbp
    d617:	53                   	push   %rbx
    d618:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d61f:	8b 0d df 64 01 00    	mov    0x164df(%rip),%ecx        # 23b04 <fwp_heap+0x13a4>
    d625:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d62c:	00 00 
    d62e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d635:	00 
    d636:	31 c0                	xor    %eax,%eax
    d638:	85 c9                	test   %ecx,%ecx
    d63a:	0f 84 68 06 00 00    	je     dca8 <fwp_main_thread+0x698>
    d640:	8b 15 c2 64 01 00    	mov    0x164c2(%rip),%edx        # 23b08 <fwp_heap+0x13a8>
    d646:	85 d2                	test   %edx,%edx
    d648:	0f 85 42 06 00 00    	jne    dc90 <fwp_main_thread+0x680>
    d64e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d653:	31 f6                	xor    %esi,%esi
    d655:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d65a:	48 c7 05 93 4a 01 00 	movq   $0x40000000,0x14a93(%rip)        # 220f8 <fwp_main_stack_size>
    d661:	00 00 00 40 
    d665:	48 89 05 94 4a 01 00 	mov    %rax,0x14a94(%rip)        # 22100 <fwp_main_stack_top>
    d66c:	48 8d 05 0d 4a 00 00 	lea    0x4a0d(%rip),%rax        # 12080 <alt.5>
    d673:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d678:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d67f:	01 00 
    d681:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d688:	00 
    d689:	e8 32 60 ff ff       	call   36c0 <sigaltstack@plt>
    d68e:	85 c0                	test   %eax,%eax
    d690:	0f 85 4a 06 00 00    	jne    dce0 <fwp_main_thread+0x6d0>
    d696:	31 c0                	xor    %eax,%eax
    d698:	b9 12 00 00 00       	mov    $0x12,%ecx
    d69d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d6a2:	f3 48 ab             	rep stos %rax,(%rdi)
    d6a5:	48 8d 05 44 66 ff ff 	lea    -0x99bc(%rip),%rax        # 3cf0 <fwp_segv>
    d6ac:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d6b1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d6b8:	04 00 00 08 
    d6bc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d6c1:	e8 ba 5e ff ff       	call   3580 <sigemptyset@plt>
    d6c6:	85 c0                	test   %eax,%eax
    d6c8:	0f 85 12 06 00 00    	jne    dce0 <fwp_main_thread+0x6d0>
    d6ce:	31 d2                	xor    %edx,%edx
    d6d0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d6d5:	bf 0b 00 00 00       	mov    $0xb,%edi
    d6da:	e8 21 5d ff ff       	call   3400 <sigaction@plt>
    d6df:	85 c0                	test   %eax,%eax
    d6e1:	0f 85 f9 05 00 00    	jne    dce0 <fwp_main_thread+0x6d0>
    d6e7:	31 d2                	xor    %edx,%edx
    d6e9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d6ee:	bf 07 00 00 00       	mov    $0x7,%edi
    d6f3:	e8 08 5d ff ff       	call   3400 <sigaction@plt>
    d6f8:	85 c0                	test   %eax,%eax
    d6fa:	0f 85 e0 05 00 00    	jne    dce0 <fwp_main_thread+0x6d0>
    d700:	8b 05 6a 49 00 00    	mov    0x496a(%rip),%eax        # 12070 <st.3>
    d706:	85 c0                	test   %eax,%eax
    d708:	0f 84 62 05 00 00    	je     dc70 <fwp_main_thread+0x660>
    d70e:	48 8b 2d 2b 50 01 00 	mov    0x1502b(%rip),%rbp        # 22740 <fwp_cur>
    d715:	48 85 ed             	test   %rbp,%rbp
    d718:	0f 84 72 03 00 00    	je     da90 <fwp_main_thread+0x480>
    d71e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d723:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d727:	48 89 eb             	mov    %rbp,%rbx
    d72a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d72f:	0f 84 41 01 00 00    	je     d876 <fwp_main_thread+0x266>
    d735:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d73a:	0f 84 80 02 00 00    	je     d9c0 <fwp_main_thread+0x3b0>
    d740:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d744:	0f 84 66 02 00 00    	je     d9b0 <fwp_main_thread+0x3a0>
    d74a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d74e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d752:	0f 85 e8 02 00 00    	jne    da40 <fwp_main_thread+0x430>
    d758:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d75c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d763:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d767:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d76e:	00 00 00 00 
    d772:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d779:	48 85 d2             	test   %rdx,%rdx
    d77c:	74 07                	je     d785 <fwp_main_thread+0x175>
    d77e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d785:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d789:	48 85 c0             	test   %rax,%rax
    d78c:	74 34                	je     d7c2 <fwp_main_thread+0x1b2>
    d78e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    d792:	48 8b 05 7f 4f 01 00 	mov    0x14f7f(%rip),%rax        # 22718 <fwp_timers>
    d799:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    d79d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    d7a4:	00 00 00 00 
    d7a8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    d7af:	48 85 c0             	test   %rax,%rax
    d7b2:	74 07                	je     d7bb <fwp_main_thread+0x1ab>
    d7b4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    d7bb:	48 89 1d 56 4f 01 00 	mov    %rbx,0x14f56(%rip)        # 22718 <fwp_timers>
    d7c2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    d7c6:	e8 45 98 ff ff       	call   7010 <fwp_block>
    d7cb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    d7d2:	48 85 c9             	test   %rcx,%rcx
    d7d5:	74 47                	je     d81e <fwp_main_thread+0x20e>
    d7d7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    d7de:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d7e5:	48 85 d2             	test   %rdx,%rdx
    d7e8:	0f 84 92 02 00 00    	je     da80 <fwp_main_thread+0x470>
    d7ee:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    d7f5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d7fc:	48 85 c0             	test   %rax,%rax
    d7ff:	74 07                	je     d808 <fwp_main_thread+0x1f8>
    d801:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    d808:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    d80f:	00 00 00 00 
    d813:	66 0f ef c0          	pxor   %xmm0,%xmm0
    d817:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    d81e:	48 8b 0d 1b 4f 01 00 	mov    0x14f1b(%rip),%rcx        # 22740 <fwp_cur>
    d825:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    d829:	0f 84 01 02 00 00    	je     da30 <fwp_main_thread+0x420>
    d82f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    d836:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    d83d:	48 85 d2             	test   %rdx,%rdx
    d840:	0f 84 fa 03 00 00    	je     dc40 <fwp_main_thread+0x630>
    d846:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    d84d:	48 85 c0             	test   %rax,%rax
    d850:	74 07                	je     d859 <fwp_main_thread+0x249>
    d852:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    d859:	66 0f ef c9          	pxor   %xmm1,%xmm1
    d85d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    d861:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    d868:	48 89 cb             	mov    %rcx,%rbx
    d86b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d870:	0f 85 bf fe ff ff    	jne    d735 <fwp_main_thread+0x125>
    d876:	48 83 3d 5a 6b 01 00 	cmpq   $0x0,0x16b5a(%rip)        # 243d8 <fwp_state_len>
    d87d:	00 
    d87e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    d882:	0f 84 ba 00 00 00    	je     d942 <fwp_main_thread+0x332>
    d888:	48 39 1d a9 4e 01 00 	cmp    %rbx,0x14ea9(%rip)        # 22738 <fwp_root>
    d88f:	c7 05 e7 47 01 00 00 	movl   $0x0,0x147e7(%rip)        # 22080 <fwp_exit_code>
    d896:	00 00 00 
    d899:	0f 85 5f 04 00 00    	jne    dcfe <fwp_main_thread+0x6ee>
    d89f:	48 85 db             	test   %rbx,%rbx
    d8a2:	0f 84 0e 02 00 00    	je     dab6 <fwp_main_thread+0x4a6>
    d8a8:	48 8b 15 59 4e 01 00 	mov    0x14e59(%rip),%rdx        # 22708 <fwp_tasks_active>
    d8af:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    d8b3:	48 85 d2             	test   %rdx,%rdx
    d8b6:	0f 84 fa 01 00 00    	je     dab6 <fwp_main_thread+0x4a6>
    d8bc:	0f 1f 40 00          	nopl   0x0(%rax)
    d8c0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    d8c4:	75 08                	jne    d8ce <fwp_main_thread+0x2be>
    d8c6:	48 89 d7             	mov    %rdx,%rdi
    d8c9:	e8 e2 67 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    d8ce:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    d8d5:	48 85 d2             	test   %rdx,%rdx
    d8d8:	75 e6                	jne    d8c0 <fwp_main_thread+0x2b0>
    d8da:	eb 31                	jmp    d90d <fwp_main_thread+0x2fd>
    d8dc:	0f 1f 40 00          	nopl   0x0(%rax)
    d8e0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    d8e7:	48 89 1d 32 4e 01 00 	mov    %rbx,0x14e32(%rip)        # 22720 <fwp_ready_tail>
    d8ee:	e8 1d 97 ff ff       	call   7010 <fwp_block>
    d8f3:	e8 08 95 ff ff       	call   6e00 <fwp_free_zombie>
    d8f8:	48 83 3d 08 4e 01 00 	cmpq   $0x0,0x14e08(%rip)        # 22708 <fwp_tasks_active>
    d8ff:	00 
    d900:	0f 84 b0 01 00 00    	je     dab6 <fwp_main_thread+0x4a6>
    d906:	48 8b 1d 2b 4e 01 00 	mov    0x14e2b(%rip),%rbx        # 22738 <fwp_root>
    d90d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    d911:	75 db                	jne    d8ee <fwp_main_thread+0x2de>
    d913:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    d917:	75 d5                	jne    d8ee <fwp_main_thread+0x2de>
    d919:	48 8b 05 00 4e 01 00 	mov    0x14e00(%rip),%rax        # 22720 <fwp_ready_tail>
    d920:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    d924:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    d92b:	00 00 00 00 
    d92f:	48 85 c0             	test   %rax,%rax
    d932:	75 ac                	jne    d8e0 <fwp_main_thread+0x2d0>
    d934:	48 89 1d ed 4d 01 00 	mov    %rbx,0x14ded(%rip)        # 22728 <fwp_ready_head>
    d93b:	eb aa                	jmp    d8e7 <fwp_main_thread+0x2d7>
    d93d:	0f 1f 00             	nopl   (%rax)
    d940:	31 db                	xor    %ebx,%ebx
    d942:	48 83 3d 7e 6a 01 00 	cmpq   $0x0,0x16a7e(%rip)        # 243c8 <fwp_state_owners>
    d949:	00 
    d94a:	0f 85 38 ff ff ff    	jne    d888 <fwp_main_thread+0x278>
    d950:	48 8b 3d 89 6a 01 00 	mov    0x16a89(%rip),%rdi        # 243e0 <fwp_state>
    d957:	e8 f4 7b ff ff       	call   5550 <fwp_mem_free>
    d95c:	48 c7 05 79 6a 01 00 	movq   $0x0,0x16a79(%rip)        # 243e0 <fwp_state>
    d963:	00 00 00 00 
    d967:	48 c7 05 5e 6a 01 00 	movq   $0x0,0x16a5e(%rip)        # 243d0 <fwp_state_cap>
    d96e:	00 00 00 00 
    d972:	48 85 db             	test   %rbx,%rbx
    d975:	0f 84 46 03 00 00    	je     dcc1 <fwp_main_thread+0x6b1>
    d97b:	48 39 1d b6 4d 01 00 	cmp    %rbx,0x14db6(%rip)        # 22738 <fwp_root>
    d982:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    d989:	00 00 00 00 
    d98d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    d994:	00 00 00 00 
    d998:	c7 05 de 46 01 00 00 	movl   $0x0,0x146de(%rip)        # 22080 <fwp_exit_code>
    d99f:	00 00 00 
    d9a2:	0f 84 00 ff ff ff    	je     d8a8 <fwp_main_thread+0x298>
    d9a8:	e9 a8 5d ff ff       	jmp    3755 <fwp_main_thread.cold>
    d9ad:	0f 1f 00             	nopl   (%rax)
    d9b0:	e8 5b 69 ff ff       	call   4310 <fwp_now_ns>
    d9b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    d9b9:	0f 8d 91 02 00 00    	jge    dc50 <fwp_main_thread+0x640>
    d9bf:	90                   	nop
    d9c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d9c4:	0f 85 80 fd ff ff    	jne    d74a <fwp_main_thread+0x13a>
    d9ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    d9ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d9d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d9d6:	0f 85 80 fd ff ff    	jne    d75c <fwp_main_thread+0x14c>
    d9dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    d9e0:	48 85 c9             	test   %rcx,%rcx
    d9e3:	0f 84 73 fd ff ff    	je     d75c <fwp_main_thread+0x14c>
    d9e9:	48 85 c0             	test   %rax,%rax
    d9ec:	0f 84 ff 02 00 00    	je     dcf1 <fwp_main_thread+0x6e1>
    d9f2:	48 39 c8             	cmp    %rcx,%rax
    d9f5:	48 0f 4f c1          	cmovg  %rcx,%rax
    d9f9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    da00:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    da04:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    da0b:	00 00 00 00 
    da0f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    da16:	48 85 d2             	test   %rdx,%rdx
    da19:	74 07                	je     da22 <fwp_main_thread+0x412>
    da1b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    da22:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    da26:	e9 63 fd ff ff       	jmp    d78e <fwp_main_thread+0x17e>
    da2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    da30:	48 89 cb             	mov    %rcx,%rbx
    da33:	e9 f2 fc ff ff       	jmp    d72a <fwp_main_thread+0x11a>
    da38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    da3f:	00 
    da40:	48 8b 45 40          	mov    0x40(%rbp),%rax
    da44:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    da4b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    da52:	00 00 00 00 
    da56:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    da5d:	48 85 c0             	test   %rax,%rax
    da60:	0f 84 52 02 00 00    	je     dcb8 <fwp_main_thread+0x6a8>
    da66:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    da6d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    da71:	e9 4c fd ff ff       	jmp    d7c2 <fwp_main_thread+0x1b2>
    da76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    da7d:	00 00 00 
    da80:	48 89 01             	mov    %rax,(%rcx)
    da83:	e9 74 fd ff ff       	jmp    d7fc <fwp_main_thread+0x1ec>
    da88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    da8f:	00 
    da90:	48 83 3d 40 69 01 00 	cmpq   $0x0,0x16940(%rip)        # 243d8 <fwp_state_len>
    da97:	00 
    da98:	0f 84 a2 fe ff ff    	je     d940 <fwp_main_thread+0x330>
    da9e:	48 83 3d 92 4c 01 00 	cmpq   $0x0,0x14c92(%rip)        # 22738 <fwp_root>
    daa5:	00 
    daa6:	c7 05 d0 45 01 00 00 	movl   $0x0,0x145d0(%rip)        # 22080 <fwp_exit_code>
    daad:	00 00 00 
    dab0:	0f 85 43 02 00 00    	jne    dcf9 <fwp_main_thread+0x6e9>
    dab6:	e8 45 93 ff ff       	call   6e00 <fwp_free_zombie>
    dabb:	48 83 3d 65 4c 01 00 	cmpq   $0x0,0x14c65(%rip)        # 22728 <fwp_ready_head>
    dac2:	00 
    dac3:	0f 85 8c 5c ff ff    	jne    3755 <fwp_main_thread.cold>
    dac9:	48 83 3d 47 4c 01 00 	cmpq   $0x0,0x14c47(%rip)        # 22718 <fwp_timers>
    dad0:	00 
    dad1:	0f 85 7e 5c ff ff    	jne    3755 <fwp_main_thread.cold>
    dad7:	8b 1d 2f 46 01 00    	mov    0x1462f(%rip),%ebx        # 2210c <fwp_stack_pool_n>
    dadd:	85 db                	test   %ebx,%ebx
    dadf:	74 36                	je     db17 <fwp_main_thread+0x507>
    dae1:	83 eb 01             	sub    $0x1,%ebx
    dae4:	48 8d 05 35 46 01 00 	lea    0x14635(%rip),%rax        # 22120 <fwp_stack_pool>
    daeb:	48 63 d3             	movslq %ebx,%rdx
    daee:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    daf2:	eb 07                	jmp    dafb <fwp_main_thread+0x4eb>
    daf4:	0f 1f 40 00          	nopl   0x0(%rax)
    daf8:	83 eb 01             	sub    $0x1,%ebx
    dafb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    daff:	be 00 00 00 10       	mov    $0x10000000,%esi
    db04:	89 1d 02 46 01 00    	mov    %ebx,0x14602(%rip)        # 2210c <fwp_stack_pool_n>
    db0a:	48 83 ed 08          	sub    $0x8,%rbp
    db0e:	e8 cd 5a ff ff       	call   35e0 <munmap@plt>
    db13:	85 db                	test   %ebx,%ebx
    db15:	75 e1                	jne    daf8 <fwp_main_thread+0x4e8>
    db17:	8b 3d fb 44 00 00    	mov    0x44fb(%rip),%edi        # 12018 <fwp_epfd>
    db1d:	85 ff                	test   %edi,%edi
    db1f:	78 05                	js     db26 <fwp_main_thread+0x516>
    db21:	e8 aa 59 ff ff       	call   34d0 <close@plt>
    db26:	4c 8b 25 f3 47 01 00 	mov    0x147f3(%rip),%r12        # 22320 <fwp_nfdws>
    db2d:	48 8b 2d f4 47 01 00 	mov    0x147f4(%rip),%rbp        # 22328 <fwp_fdws>
    db34:	31 db                	xor    %ebx,%ebx
    db36:	c7 05 d8 44 00 00 ff 	movl   $0xffffffff,0x44d8(%rip)        # 12018 <fwp_epfd>
    db3d:	ff ff ff 
    db40:	4d 85 e4             	test   %r12,%r12
    db43:	74 38                	je     db7d <fwp_main_thread+0x56d>
    db45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    db4c:	00 00 00 00 
    db50:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    db55:	48 85 ff             	test   %rdi,%rdi
    db58:	74 1a                	je     db74 <fwp_main_thread+0x564>
    db5a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    db5e:	0f 85 f1 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db64:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    db69:	0f 85 e6 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db6f:	e8 dc 79 ff ff       	call   5550 <fwp_mem_free>
    db74:	48 83 c3 01          	add    $0x1,%rbx
    db78:	4c 39 e3             	cmp    %r12,%rbx
    db7b:	75 d3                	jne    db50 <fwp_main_thread+0x540>
    db7d:	48 89 ef             	mov    %rbp,%rdi
    db80:	e8 cb 79 ff ff       	call   5550 <fwp_mem_free>
    db85:	48 8b 15 ac 4b 01 00 	mov    0x14bac(%rip),%rdx        # 22738 <fwp_root>
    db8c:	48 c7 05 91 47 01 00 	movq   $0x0,0x14791(%rip)        # 22328 <fwp_fdws>
    db93:	00 00 00 00 
    db97:	48 c7 05 7e 47 01 00 	movq   $0x0,0x1477e(%rip)        # 22320 <fwp_nfdws>
    db9e:	00 00 00 00 
    dba2:	48 85 d2             	test   %rdx,%rdx
    dba5:	74 4e                	je     dbf5 <fwp_main_thread+0x5e5>
    dba7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    dbac:	0f 85 a3 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbb2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    dbb9:	00 
    dbba:	0f 85 95 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbc0:	48 83 3d 10 68 01 00 	cmpq   $0x0,0x16810(%rip)        # 243d8 <fwp_state_len>
    dbc7:	00 
    dbc8:	0f 85 87 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbce:	48 83 3d f2 67 01 00 	cmpq   $0x0,0x167f2(%rip)        # 243c8 <fwp_state_owners>
    dbd5:	00 
    dbd6:	0f 85 79 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbdc:	b9 79 00 00 00       	mov    $0x79,%ecx
    dbe1:	31 c0                	xor    %eax,%eax
    dbe3:	48 8d 3d 56 47 01 00 	lea    0x14756(%rip),%rdi        # 22340 <fwp_root_context>
    dbea:	f3 48 ab             	rep stos %rax,(%rdi)
    dbed:	48 89 d7             	mov    %rdx,%rdi
    dbf0:	e8 5b 79 ff ff       	call   5550 <fwp_mem_free>
    dbf5:	48 8b 3d 24 44 00 00 	mov    0x4424(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    dbfc:	48 c7 05 39 4b 01 00 	movq   $0x0,0x14b39(%rip)        # 22740 <fwp_cur>
    dc03:	00 00 00 00 
    dc07:	48 c7 05 26 4b 01 00 	movq   $0x0,0x14b26(%rip)        # 22738 <fwp_root>
    dc0e:	00 00 00 00 
    dc12:	e8 a9 59 ff ff       	call   35c0 <fflush@plt>
    dc17:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    dc1e:	00 
    dc1f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dc26:	00 00 
    dc28:	0f 85 be 00 00 00    	jne    dcec <fwp_main_thread+0x6dc>
    dc2e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    dc35:	31 c0                	xor    %eax,%eax
    dc37:	5b                   	pop    %rbx
    dc38:	5d                   	pop    %rbp
    dc39:	41 5c                	pop    %r12
    dc3b:	c3                   	ret
    dc3c:	0f 1f 40 00          	nopl   0x0(%rax)
    dc40:	48 89 05 d1 4a 01 00 	mov    %rax,0x14ad1(%rip)        # 22718 <fwp_timers>
    dc47:	e9 01 fc ff ff       	jmp    d84d <fwp_main_thread+0x23d>
    dc4c:	0f 1f 40 00          	nopl   0x0(%rax)
    dc50:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    dc54:	0f 85 66 fd ff ff    	jne    d9c0 <fwp_main_thread+0x3b0>
    dc5a:	48 89 ef             	mov    %rbp,%rdi
    dc5d:	e8 4e 64 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    dc62:	e9 59 fd ff ff       	jmp    d9c0 <fwp_main_thread+0x3b0>
    dc67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    dc6e:	00 00 
    dc70:	e8 9b cc ff ff       	call   a910 <f0>
    dc75:	48 c7 05 e8 43 00 00 	movq   $0x0,0x43e8(%rip)        # 12068 <v.2>
    dc7c:	00 00 00 00 
    dc80:	c7 05 e6 43 00 00 01 	movl   $0x1,0x43e6(%rip)        # 12070 <st.3>
    dc87:	00 00 00 
    dc8a:	e9 7f fa ff ff       	jmp    d70e <fwp_main_thread+0xfe>
    dc8f:	90                   	nop
    dc90:	48 8d 3d 89 6d ff ff 	lea    -0x9277(%rip),%rdi        # 4a20 <fwp_heap_report>
    dc97:	e8 84 02 00 00       	call   df20 <atexit>
    dc9c:	e9 ad f9 ff ff       	jmp    d64e <fwp_main_thread+0x3e>
    dca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    dca8:	e8 83 6e ff ff       	call   4b30 <fwp_heap_init>
    dcad:	e9 8e f9 ff ff       	jmp    d640 <fwp_main_thread+0x30>
    dcb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dcb8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dcbc:	e9 01 fb ff ff       	jmp    d7c2 <fwp_main_thread+0x1b2>
    dcc1:	48 83 3d 6f 4a 01 00 	cmpq   $0x0,0x14a6f(%rip)        # 22738 <fwp_root>
    dcc8:	00 
    dcc9:	c7 05 ad 43 01 00 00 	movl   $0x0,0x143ad(%rip)        # 22080 <fwp_exit_code>
    dcd0:	00 00 00 
    dcd3:	0f 84 dd fd ff ff    	je     dab6 <fwp_main_thread+0x4a6>
    dcd9:	e9 77 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	48 8d 3d 11 0c 00 00 	lea    0xc11(%rip),%rdi        # e8f8 <_IO_stdin_used+0x8f8>
    dce7:	e8 b4 64 ff ff       	call   41a0 <fwp_trap>
    dcec:	e8 6f 57 ff ff       	call   3460 <__stack_chk_fail@plt>
    dcf1:	48 89 c8             	mov    %rcx,%rax
    dcf4:	e9 00 fd ff ff       	jmp    d9f9 <fwp_main_thread+0x3e9>
    dcf9:	e9 57 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dcfe:	e9 52 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dd03:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dd0a:	00 00 00 
    dd0d:	0f 1f 00             	nopl   (%rax)

000000000000dd10 <__divmodti4>:
    dd10:	f3 0f 1e fa          	endbr64
    dd14:	55                   	push   %rbp
    dd15:	49 89 f1             	mov    %rsi,%r9
    dd18:	49 89 d2             	mov    %rdx,%r10
    dd1b:	48 89 fe             	mov    %rdi,%rsi
    dd1e:	49 89 cb             	mov    %rcx,%r11
    dd21:	48 89 e5             	mov    %rsp,%rbp
    dd24:	41 57                	push   %r15
    dd26:	41 56                	push   %r14
    dd28:	41 55                	push   %r13
    dd2a:	41 54                	push   %r12
    dd2c:	53                   	push   %rbx
    dd2d:	4c 89 c3             	mov    %r8,%rbx
    dd30:	45 31 c0             	xor    %r8d,%r8d
    dd33:	4d 85 c9             	test   %r9,%r9
    dd36:	79 12                	jns    dd4a <__divmodti4+0x3a>
    dd38:	31 ff                	xor    %edi,%edi
    dd3a:	48 f7 de             	neg    %rsi
    dd3d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    dd44:	4c 19 cf             	sbb    %r9,%rdi
    dd47:	49 89 f9             	mov    %rdi,%r9
    dd4a:	4c 89 d8             	mov    %r11,%rax
    dd4d:	4d 85 db             	test   %r11,%r11
    dd50:	0f 88 1a 01 00 00    	js     de70 <__divmodti4+0x160>
    dd56:	4c 89 d9             	mov    %r11,%rcx
    dd59:	49 89 f3             	mov    %rsi,%r11
    dd5c:	75 62                	jne    ddc0 <__divmodti4+0xb0>
    dd5e:	4d 89 c4             	mov    %r8,%r12
    dd61:	4d 39 d1             	cmp    %r10,%r9
    dd64:	0f 83 46 01 00 00    	jae    deb0 <__divmodti4+0x1a0>
    dd6a:	4c 89 d8             	mov    %r11,%rax
    dd6d:	4c 89 ca             	mov    %r9,%rdx
    dd70:	49 f7 f2             	div    %r10
    dd73:	49 89 c3             	mov    %rax,%r11
    dd76:	31 c0                	xor    %eax,%eax
    dd78:	48 89 d6             	mov    %rdx,%rsi
    dd7b:	31 ff                	xor    %edi,%edi
    dd7d:	4c 89 d9             	mov    %r11,%rcx
    dd80:	48 89 c2             	mov    %rax,%rdx
    dd83:	48 89 c8             	mov    %rcx,%rax
    dd86:	4d 85 e4             	test   %r12,%r12
    dd89:	74 0a                	je     dd95 <__divmodti4+0x85>
    dd8b:	48 f7 d8             	neg    %rax
    dd8e:	48 83 d2 00          	adc    $0x0,%rdx
    dd92:	48 f7 da             	neg    %rdx
    dd95:	4d 85 c0             	test   %r8,%r8
    dd98:	74 0a                	je     dda4 <__divmodti4+0x94>
    dd9a:	48 f7 de             	neg    %rsi
    dd9d:	48 83 d7 00          	adc    $0x0,%rdi
    dda1:	48 f7 df             	neg    %rdi
    dda4:	48 89 33             	mov    %rsi,(%rbx)
    dda7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ddab:	5b                   	pop    %rbx
    ddac:	41 5c                	pop    %r12
    ddae:	41 5d                	pop    %r13
    ddb0:	41 5e                	pop    %r14
    ddb2:	41 5f                	pop    %r15
    ddb4:	5d                   	pop    %rbp
    ddb5:	c3                   	ret
    ddb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ddbd:	00 00 00 
    ddc0:	4d 89 c4             	mov    %r8,%r12
    ddc3:	49 39 c1             	cmp    %rax,%r9
    ddc6:	0f 82 ce 00 00 00    	jb     de9a <__divmodti4+0x18a>
    ddcc:	31 ff                	xor    %edi,%edi
    ddce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ddd3:	48 63 c7             	movslq %edi,%rax
    ddd6:	be 40 00 00 00       	mov    $0x40,%esi
    dddb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    dde0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    dde5:	48 29 c6             	sub    %rax,%rsi
    dde8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    dded:	48 09 c8             	or     %rcx,%rax
    ddf0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ddf5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ddfa:	49 89 c6             	mov    %rax,%r14
    ddfd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    de01:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    de06:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    de0b:	49 09 c1             	or     %rax,%r9
    de0e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    de12:	4c 89 c8             	mov    %r9,%rax
    de15:	49 f7 f6             	div    %r14
    de18:	48 89 d1             	mov    %rdx,%rcx
    de1b:	49 89 c3             	mov    %rax,%r11
    de1e:	49 89 c1             	mov    %rax,%r9
    de21:	49 f7 e2             	mul    %r10
    de24:	49 89 c6             	mov    %rax,%r14
    de27:	49 89 d2             	mov    %rdx,%r10
    de2a:	48 39 d1             	cmp    %rdx,%rcx
    de2d:	72 07                	jb     de36 <__divmodti4+0x126>
    de2f:	75 17                	jne    de48 <__divmodti4+0x138>
    de31:	49 39 c7             	cmp    %rax,%r15
    de34:	73 12                	jae    de48 <__divmodti4+0x138>
    de36:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    de3a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    de3e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    de42:	49 89 d2             	mov    %rdx,%r10
    de45:	49 89 c6             	mov    %rax,%r14
    de48:	4c 89 f8             	mov    %r15,%rax
    de4b:	4c 29 f0             	sub    %r14,%rax
    de4e:	4c 19 d1             	sbb    %r10,%rcx
    de51:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    de56:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    de5b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    de60:	48 09 c6             	or     %rax,%rsi
    de63:	48 89 cf             	mov    %rcx,%rdi
    de66:	31 c0                	xor    %eax,%eax
    de68:	4c 89 c9             	mov    %r9,%rcx
    de6b:	e9 10 ff ff ff       	jmp    dd80 <__divmodti4+0x70>
    de70:	4c 89 d0             	mov    %r10,%rax
    de73:	4c 89 da             	mov    %r11,%rdx
    de76:	4d 89 c4             	mov    %r8,%r12
    de79:	49 89 f3             	mov    %rsi,%r11
    de7c:	48 f7 d8             	neg    %rax
    de7f:	49 f7 d4             	not    %r12
    de82:	48 83 d2 00          	adc    $0x0,%rdx
    de86:	49 89 c2             	mov    %rax,%r10
    de89:	48 f7 da             	neg    %rdx
    de8c:	48 89 d1             	mov    %rdx,%rcx
    de8f:	0f 84 cc fe ff ff    	je     dd61 <__divmodti4+0x51>
    de95:	49 39 d1             	cmp    %rdx,%r9
    de98:	73 46                	jae    dee0 <__divmodti4+0x1d0>
    de9a:	4c 89 cf             	mov    %r9,%rdi
    de9d:	31 c0                	xor    %eax,%eax
    de9f:	31 c9                	xor    %ecx,%ecx
    dea1:	e9 da fe ff ff       	jmp    dd80 <__divmodti4+0x70>
    dea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dead:	00 00 00 
    deb0:	4d 85 d2             	test   %r10,%r10
    deb3:	75 0d                	jne    dec2 <__divmodti4+0x1b2>
    deb5:	b8 01 00 00 00       	mov    $0x1,%eax
    deba:	31 d2                	xor    %edx,%edx
    debc:	49 f7 f2             	div    %r10
    debf:	49 89 c2             	mov    %rax,%r10
    dec2:	4c 89 c8             	mov    %r9,%rax
    dec5:	31 d2                	xor    %edx,%edx
    dec7:	49 f7 f2             	div    %r10
    deca:	49 89 c1             	mov    %rax,%r9
    decd:	4c 89 d8             	mov    %r11,%rax
    ded0:	49 f7 f2             	div    %r10
    ded3:	49 89 c3             	mov    %rax,%r11
    ded6:	4c 89 c8             	mov    %r9,%rax
    ded9:	e9 9a fe ff ff       	jmp    dd78 <__divmodti4+0x68>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	45 31 f6             	xor    %r14d,%r14d
    dee3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    dee8:	44 89 f7             	mov    %r14d,%edi
    deeb:	45 85 f6             	test   %r14d,%r14d
    deee:	0f 85 df fe ff ff    	jne    ddd3 <__divmodti4+0xc3>
    def4:	4c 39 ca             	cmp    %r9,%rdx
    def7:	72 17                	jb     df10 <__divmodti4+0x200>
    def9:	31 c9                	xor    %ecx,%ecx
    defb:	48 39 c6             	cmp    %rax,%rsi
    defe:	73 10                	jae    df10 <__divmodti4+0x200>
    df00:	4c 89 cf             	mov    %r9,%rdi
    df03:	31 c0                	xor    %eax,%eax
    df05:	e9 76 fe ff ff       	jmp    dd80 <__divmodti4+0x70>
    df0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    df10:	4c 89 de             	mov    %r11,%rsi
    df13:	b9 01 00 00 00       	mov    $0x1,%ecx
    df18:	48 29 c6             	sub    %rax,%rsi
    df1b:	49 19 d1             	sbb    %rdx,%r9
    df1e:	eb e0                	jmp    df00 <__divmodti4+0x1f0>

000000000000df20 <atexit>:
    df20:	f3 0f 1e fa          	endbr64
    df24:	48 8b 15 dd 40 00 00 	mov    0x40dd(%rip),%rdx        # 12008 <__dso_handle>
    df2b:	31 f6                	xor    %esi,%esi
    df2d:	e9 2e 57 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000df34 <_fini>:
    df34:	f3 0f 1e fa          	endbr64
    df38:	48 83 ec 08          	sub    $0x8,%rsp
    df3c:	48 83 c4 08          	add    $0x8,%rsp
    df40:	c3                   	ret
