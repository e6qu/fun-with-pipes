
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 fc 00 00    	jmp    *0xfc66(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 b9 00 00 	lea    0xb9b8(%rip),%r9        # f0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 b9 00 00 	lea    0xb9b5(%rip),%r8        # f0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 61 fc ff ff       	call   33c0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 12 9d 06 00 	mov    %rax,0x69d12(%rip)        # 6d498 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c 9d 06 00 	mov    %rax,0x69d0c(%rip)        # 6d4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e bb 00 00 	lea    0xbb4e(%rip),%rdi        # f2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 bf a5 00 00 	lea    0xa5bf(%rip),%rdx        # de20 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe b9 00 00 	lea    0xb9fe(%rip),%rdi        # f2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 c3 00 00 	lea    0xc356(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 10 c3 00 00 	lea    0xc310(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 c2 00 00 	lea    0xc2d4(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 c2 00 00 	lea    0xc2a0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b f6 00 00    	call   *0xf65b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e f6 00 00 	mov    0xf63e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d f6 00 00 	mov    0xf60d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea f5 00 00 	cmpq   $0x0,0xf5ea(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 f5 04 00 	lea    0x4f5b7(%rip),%r8        # 531c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b f5 04 00 	lea    0x4f55b(%rip),%rcx        # 53180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f f5 04 00 	lea    0x4f52f(%rip),%rcx        # 53160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 f5 04 00 	lea    0x4f561(%rip),%rcx        # 531a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 f5 04 	movdqa 0x4f570(%rip),%xmm0        # 531d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 f5 04 	paddq  0x4f558(%rip),%xmm0        # 531c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf f4 04 00 	cmp    %rax,0x4f4bf(%rip)        # 53140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 f4 04 	movq   %xmm0,0x4f4b5(%rip)        # 53140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e f4 01 00 	add    0x1f45e(%rip),%rdx        # 23110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c f4 01 00 	add    0x1f44c(%rip),%rax        # 23110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 97 06 00 	mov    0x69799(%rip),%rdi        # 6d4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 f3 00 00 	mov    0xf304(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 f2 00 00 	mov    0xf2f1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 7a 06 00 	mov    0x67ad1(%rip),%rax        # 6b820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 74 06 00 	mov    0x67419(%rip),%rax        # 6b1e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 74 06 00 	sub    0x67405(%rip),%rax        # 6b1e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d bf 00 00 	lea    0xbf2d(%rip),%rsi        # fd40 <msg.8>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 b1 00 00 	lea    0xb1c5(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 f1 00 00 	mov    0xf1f2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 8d 06 00 	mov    0x68dab(%rip),%rax        # 6cc30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 8d 06 00 	lea    0x68da4(%rip),%r8        # 6cc30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 8d 06 00 	mov    0x68d85(%rip),%rbx        # 6cc18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 8d 06 00 	mov    0x68d95(%rip),%rcx        # 6cc38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 8d 06 00 	mov    0x68d31(%rip),%rdi        # 6cc20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 8d 06 00 	sub    %rsi,0x68d7a(%rip)        # 6cc70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 8d 06 00 	mov    0x68d0a(%rip),%rax        # 6cc10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 8c 06 00 	add    0x68cc0(%rip),%rdi        # 6cbf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 8c 06 00 	mov    0x68cce(%rip),%rsi        # 6cc20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 8c 06 00 	mov    0x68cdc(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 8c 06 00 	mov    %r12,0x68c8b(%rip)        # 6cc20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 8c 06 00 	mov    %rbp,0x68c79(%rip)        # 6cc18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 8c 06 00 	cmp    %rdi,0x68c5e(%rip)        # 6cc08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 8c 06 00 	mov    %rdi,0x68c55(%rip)        # 6cc08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 8c 06 00 	sub    %rdi,0x68c99(%rip)        # 6cc70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 8c 06 00 	mov    0x68c41(%rip),%rax        # 6cc28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 8c 06 00 	lea    0x68c3a(%rip),%r8        # 6cc28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff b6 00 00 	lea    0xb6ff(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 f0 00 00 	mov    0xf022(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d ef 00 00 	mov    0xef7d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 af 00 00 	lea    0xaf34(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 76 06 00 	cmp    0x676e9(%rip),%rdi        # 6b820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 76 06 00 	mov    0x676af(%rip),%rax        # 6b800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 76 06 00 	mov    %rdi,0x6768d(%rip)        # 6b800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 76 06 00 	mov    %rdi,0x67669(%rip)        # 6b808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 b0 00 00 	lea    0xb019(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 ae 00 00 	lea    0xae27(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 ef 04 	movdqa 0x4ef96(%rip),%xmm0        # 531d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e ef 04 	paddq  0x4ef7e(%rip),%xmm0        # 531c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 ee 01 00 	mov    0x1eea4(%rip),%r8        # 23118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be ee 04 00 	mov    0x4eebe(%rip),%rcx        # 53140 <ad_raw_total_peak>
    4282:	48 8b 3d b7 ed 00 00 	mov    0xedb7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 b4 00 00 	lea    0xb4c5(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 ef 04 00 	lea    0x4ef01(%rip),%r15        # 531a0 <ad_raw_peak>
    429f:	4c 8d 35 ba ee 04 00 	lea    0x4eeba(%rip),%r14        # 53160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 ad 00 00 	lea    0xad79(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 e9 00 	movq   0xe956(%rip),%xmm0        # 12c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf ee 04 00 	lea    0x4eebf(%rip),%r13        # 53180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f ad 00 00 	lea    0xad6f(%rip),%rax        # f03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 e9 00 	movq   0xe936(%rip),%xmm0        # 12c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 ed 00 00 	mov    0xed33(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c ad 00 00 	lea    0xad0c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d b4 00 00 	lea    0xb49d(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 ed 00 00 	mov    0xed04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 ac 00 00 	lea    0xacf8(%rip),%rdi        # f045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 ed 01 00 	cmpq   $0x0,0x1edc6(%rip)        # 23120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd ed 01 00 	mov    0x1eddd(%rip),%r8        # 23140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de ed 01 00 	mov    0x1edde(%rip),%r9        # 23148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf ed 01 00 	lea    0x1edcf(%rip),%rbx        # 23140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 ac 00 00 	lea    0xacf4(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 ed 01 00 	mov    0x1edd1(%rip),%rax        # 23150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a ac 00 00 	lea    0xac9a(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 ec 00 00 	mov    0xec89(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 b4 00 00 	lea    0xb439(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 ed 01 00 	cmp    0x1ed53(%rip),%rbp        # 23120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 ec 00 00 	mov    0xec58(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b ac 00 00 	lea    0xac5b(%rip),%rdi        # f059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 ec 00 00 	mov    0xec23(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 b3 00 00 	lea    0xb394(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 ac 00 00 	lea    0xac40(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea b2 00 00 	lea    0xb2ea(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 eb 00 00 	mov    0xebc8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df ab 00 00 	lea    0xabdf(%rip),%rdx        # f05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 eb 00 00 	mov    0xebb0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ea 00 00 	mov    0xeac1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 aa 00 00 	lea    0xaa78(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 aa 00 00 	lea    0xaac0(%rip),%rdi        # f06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 aa 00 00 	lea    0xaa48(%rip),%rdi        # f087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 b1 00 00 	lea    0xb1e8(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 b7 00 	movdqa 0xb720(%rip),%xmm0        # fd90 <msg.8+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 8d 06 00 	add    0x68dca(%rip),%rax        # 6d498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c b1 00 00 	lea    0xb13c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 e9 01 00 	cmp    %rax,0x1e9c5(%rip)        # 23108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 e9 01 00 	add    0x1e9c0(%rip),%rax        # 23110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 b1 00 00 	lea    0xb125(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 a9 00 00 	lea    0xa920(%rip),%r8        # f0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 a7 00 00 	lea    0xa775(%rip),%r8        # f0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 a6 00 00 	lea    0xa612(%rip),%r8        # f0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea a3 00 00 	lea    0xa3ea(%rip),%rdi        # f0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 7e 06 00 	mov    0x67ea5(%rip),%r9        # 6cc08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 7e 06 00 	mov    0x67efe(%rip),%r8        # 6cc68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f ab 00 00 	lea    0xab6f(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 7e 06 00 	mov    0x67ee6(%rip),%rcx        # 6cc60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 7e 06 	movsd  0x67ef4(%rip),%xmm1        # 6cc80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 7e 06 	movsd  0x67ee4(%rip),%xmm0        # 6cc78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 e2 00 00 	mov    0xe2a5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 af 00 	movdqa 0xafc8(%rip),%xmm0        # fda0 <msg.8+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 79 06 00 	lea    0x6799f(%rip),%rax        # 6c780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 af 00 	movdqa 0xaff1(%rip),%xmm2        # fde0 <msg.8+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 79 06 00 	movaps %xmm0,0x67945(%rip)        # 6c740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad af 00 	movdqa 0xafad(%rip),%xmm0        # fdb0 <msg.8+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 7d 06 00 01 	movl   $0x1,0x67dd3(%rip)        # 6cbe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 79 06 00 	movaps %xmm0,0x67933(%rip)        # 6c750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b af 00 	movdqa 0xaf9b(%rip),%xmm0        # fdc0 <msg.8+0x80>
    4e24:	00 
    4e25:	0f 29 05 34 79 06 00 	movaps %xmm0,0x67934(%rip)        # 6c760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c af 00 	movdqa 0xaf9c(%rip),%xmm0        # fdd0 <msg.8+0x90>
    4e33:	00 
    4e34:	0f 29 05 35 79 06 00 	movaps %xmm0,0x67935(%rip)        # 6c770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 69 06 00 	lea    0x669b5(%rip),%r8        # 6b840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 7c 06 00 	mov    %rax,0x67cd0(%rip)        # 6cbf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 7c 06 00 	mov    %r12,0x67cae(%rip)        # 6cc00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 7c 06 00 	mov    %rax,0x67c97(%rip)        # 6cbf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 7c 06 00 	mov    %rbx,0x67cb0(%rip)        # 6cc10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 7c 06 00 	mov    %rsi,0x67cd9(%rip)        # 6cc40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 a1 00 00 	lea    0xa174(%rip),%rdi        # f0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 7c 06 00 	mov    %rax,0x67cb8(%rip)        # 6cc38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 7c 06 00    	mov    %eax,0x67c3c(%rip)        # 6cbe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <caf75>:
    4fc0:	8b 15 b2 e0 00 00    	mov    0xe0b2(%rip),%edx        # 13078 <st.4>
    4fc6:	85 d2                	test   %edx,%edx
    4fc8:	74 0e                	je     4fd8 <caf75+0x18>
    4fca:	48 8b 05 9f e0 00 00 	mov    0xe09f(%rip),%rax        # 13070 <v.3>
    4fd1:	c3                   	ret
    4fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fd8:	8b 05 8a e0 00 00    	mov    0xe08a(%rip),%eax        # 13068 <st.2>
    4fde:	85 c0                	test   %eax,%eax
    4fe0:	74 1e                	je     5000 <caf75+0x40>
    4fe2:	48 8b 05 77 e0 00 00 	mov    0xe077(%rip),%rax        # 13060 <v.1>
    4fe9:	48 89 05 80 e0 00 00 	mov    %rax,0xe080(%rip)        # 13070 <v.3>
    4ff0:	c7 05 7e e0 00 00 01 	movl   $0x1,0xe07e(%rip)        # 13078 <st.4>
    4ff7:	00 00 00 
    4ffa:	c3                   	ret
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    5007:	00 f0 3f 
    500a:	c7 05 54 e0 00 00 01 	movl   $0x1,0xe054(%rip)        # 13068 <st.2>
    5011:	00 00 00 
    5014:	48 89 05 45 e0 00 00 	mov    %rax,0xe045(%rip)        # 13060 <v.1>
    501b:	eb cc                	jmp    4fe9 <caf75+0x29>
    501d:	0f 1f 00             	nopl   (%rax)

0000000000005020 <fwp_wake_io>:
    5020:	48 8b 07             	mov    (%rdi),%rax
    5023:	48 85 c0             	test   %rax,%rax
    5026:	0f 84 f4 00 00 00    	je     5120 <fwp_wake_io+0x100>
    502c:	53                   	push   %rbx
    502d:	4c 8b 05 cc 67 06 00 	mov    0x667cc(%rip),%r8        # 6b800 <fwp_ready_tail>
    5034:	49 89 f9             	mov    %rdi,%r9
    5037:	48 89 c2             	mov    %rax,%rdx
    503a:	45 31 db             	xor    %r11d,%r11d
    503d:	45 31 d2             	xor    %r10d,%r10d
    5040:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5044:	eb 71                	jmp    50b7 <fwp_wake_io+0x97>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    5057:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    505e:	48 85 c9             	test   %rcx,%rcx
    5061:	74 07                	je     506a <fwp_wake_io+0x4a>
    5063:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    506a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5071:	00 00 00 00 
    5075:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    507c:	49 8b 01             	mov    (%r9),%rax
    507f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5083:	75 2a                	jne    50af <fwp_wake_io+0x8f>
    5085:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5089:	75 24                	jne    50af <fwp_wake_io+0x8f>
    508b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    508f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5096:	00 00 00 00 
    509a:	4d 85 c0             	test   %r8,%r8
    509d:	74 51                	je     50f0 <fwp_wake_io+0xd0>
    509f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    50a6:	49 89 d0             	mov    %rdx,%r8
    50a9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    50af:	48 89 c2             	mov    %rax,%rdx
    50b2:	48 85 c0             	test   %rax,%rax
    50b5:	74 49                	je     5100 <fwp_wake_io+0xe0>
    50b7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    50be:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    50c2:	48 85 ff             	test   %rdi,%rdi
    50c5:	74 b8                	je     507f <fwp_wake_io+0x5f>
    50c7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    50ce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    50d5:	48 85 f6             	test   %rsi,%rsi
    50d8:	0f 85 72 ff ff ff    	jne    5050 <fwp_wake_io+0x30>
    50de:	48 89 0f             	mov    %rcx,(%rdi)
    50e1:	e9 78 ff ff ff       	jmp    505e <fwp_wake_io+0x3e>
    50e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50ed:	00 00 00 
    50f0:	48 89 d3             	mov    %rdx,%rbx
    50f3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    50f9:	eb ab                	jmp    50a6 <fwp_wake_io+0x86>
    50fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5100:	45 84 db             	test   %r11b,%r11b
    5103:	74 07                	je     510c <fwp_wake_io+0xec>
    5105:	48 89 1d fc 66 06 00 	mov    %rbx,0x666fc(%rip)        # 6b808 <fwp_ready_head>
    510c:	45 84 d2             	test   %r10b,%r10b
    510f:	74 07                	je     5118 <fwp_wake_io+0xf8>
    5111:	4c 89 05 e8 66 06 00 	mov    %r8,0x666e8(%rip)        # 6b800 <fwp_ready_tail>
    5118:	5b                   	pop    %rbx
    5119:	c3                   	ret
    511a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5120:	c3                   	ret
    5121:	0f 1f 40 00          	nopl   0x0(%rax)
    5125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    512c:	00 00 00 00 

0000000000005130 <ad_raw_free.part.0>:
    5130:	48 8d 0d a9 e0 04 00 	lea    0x4e0a9(%rip),%rcx        # 531e0 <ad_raw_blocks>
    5137:	31 c0                	xor    %eax,%eax
    5139:	48 89 ca             	mov    %rcx,%rdx
    513c:	eb 12                	jmp    5150 <ad_raw_free.part.0+0x20>
    513e:	66 90                	xchg   %ax,%ax
    5140:	48 83 c0 01          	add    $0x1,%rax
    5144:	48 83 c2 18          	add    $0x18,%rdx
    5148:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    514e:	74 40                	je     5190 <ad_raw_free.part.0+0x60>
    5150:	48 3b 3a             	cmp    (%rdx),%rdi
    5153:	75 eb                	jne    5140 <ad_raw_free.part.0+0x10>
    5155:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5159:	66 0f ef c0          	pxor   %xmm0,%xmm0
    515d:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5161:	48 8d 0d 58 e0 04 00 	lea    0x4e058(%rip),%rcx        # 531c0 <ad_raw_live>
    5168:	8b 70 10             	mov    0x10(%rax),%esi
    516b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5172:	00 
    5173:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5177:	48 2b 50 08          	sub    0x8(%rax),%rdx
    517b:	0f 11 00             	movups %xmm0,(%rax)
    517e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5182:	e9 29 e2 ff ff       	jmp    33b0 <free@plt>
    5187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    518e:	00 00 
    5190:	48 83 ec 08          	sub    $0x8,%rsp
    5194:	48 8d 3d 62 9f 00 00 	lea    0x9f62(%rip),%rdi        # f0fd <_IO_stdin_used+0xfd>
    519b:	e8 60 ee ff ff       	call   4000 <ad_raw_fail>

00000000000051a0 <fwp_tape_buffers_dispose>:
    51a0:	53                   	push   %rbx
    51a1:	48 89 fb             	mov    %rdi,%rbx
    51a4:	48 8b 3f             	mov    (%rdi),%rdi
    51a7:	48 85 ff             	test   %rdi,%rdi
    51aa:	74 05                	je     51b1 <fwp_tape_buffers_dispose+0x11>
    51ac:	e8 7f ff ff ff       	call   5130 <ad_raw_free.part.0>
    51b1:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    51b5:	48 85 ff             	test   %rdi,%rdi
    51b8:	74 05                	je     51bf <fwp_tape_buffers_dispose+0x1f>
    51ba:	e8 71 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51bf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    51c3:	48 85 ff             	test   %rdi,%rdi
    51c6:	74 05                	je     51cd <fwp_tape_buffers_dispose+0x2d>
    51c8:	e8 63 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51d1:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51d8:	00 
    51d9:	0f 11 03             	movups %xmm0,(%rbx)
    51dc:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51e0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51e4:	5b                   	pop    %rbx
    51e5:	c3                   	ret
    51e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51ed:	00 00 00 

00000000000051f0 <ad_raw_realloc>:
    51f0:	41 55                	push   %r13
    51f2:	41 54                	push   %r12
    51f4:	55                   	push   %rbp
    51f5:	53                   	push   %rbx
    51f6:	48 83 ec 08          	sub    $0x8,%rsp
    51fa:	48 85 f6             	test   %rsi,%rsi
    51fd:	0f 84 a6 00 00 00    	je     52a9 <ad_raw_realloc+0xb9>
    5203:	4c 8d 25 d6 df 04 00 	lea    0x4dfd6(%rip),%r12        # 531e0 <ad_raw_blocks>
    520a:	48 89 f5             	mov    %rsi,%rbp
    520d:	41 89 d5             	mov    %edx,%r13d
    5210:	31 db                	xor    %ebx,%ebx
    5212:	4c 89 e0             	mov    %r12,%rax
    5215:	eb 1a                	jmp    5231 <ad_raw_realloc+0x41>
    5217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    521e:	00 00 
    5220:	48 83 c3 01          	add    $0x1,%rbx
    5224:	48 83 c0 18          	add    $0x18,%rax
    5228:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    522f:	74 4f                	je     5280 <ad_raw_realloc+0x90>
    5231:	48 3b 38             	cmp    (%rax),%rdi
    5234:	75 ea                	jne    5220 <ad_raw_realloc+0x30>
    5236:	48 85 ff             	test   %rdi,%rdi
    5239:	74 0b                	je     5246 <ad_raw_realloc+0x56>
    523b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    523f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    5244:	75 57                	jne    529d <ad_raw_realloc+0xad>
    5246:	48 89 ee             	mov    %rbp,%rsi
    5249:	e8 62 e3 ff ff       	call   35b0 <realloc@plt>
    524e:	49 89 c2             	mov    %rax,%r10
    5251:	48 85 c0             	test   %rax,%rax
    5254:	74 16                	je     526c <ad_raw_realloc+0x7c>
    5256:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    525a:	44 89 e9             	mov    %r13d,%ecx
    525d:	48 89 ea             	mov    %rbp,%rdx
    5260:	4c 89 d6             	mov    %r10,%rsi
    5263:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5267:	e8 94 e9 ff ff       	call   3c00 <ad_raw_record>
    526c:	48 83 c4 08          	add    $0x8,%rsp
    5270:	4c 89 d0             	mov    %r10,%rax
    5273:	5b                   	pop    %rbx
    5274:	5d                   	pop    %rbp
    5275:	41 5c                	pop    %r12
    5277:	41 5d                	pop    %r13
    5279:	c3                   	ret
    527a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5280:	48 85 ff             	test   %rdi,%rdi
    5283:	48 8d 05 88 9e 00 00 	lea    0x9e88(%rip),%rax        # f112 <_IO_stdin_used+0x112>
    528a:	48 8d 15 6c 9e 00 00 	lea    0x9e6c(%rip),%rdx        # f0fd <_IO_stdin_used+0xfd>
    5291:	48 0f 45 c2          	cmovne %rdx,%rax
    5295:	48 89 c7             	mov    %rax,%rdi
    5298:	e8 63 ed ff ff       	call   4000 <ad_raw_fail>
    529d:	48 8d 3d a4 9e 00 00 	lea    0x9ea4(%rip),%rdi        # f148 <_IO_stdin_used+0x148>
    52a4:	e8 57 ed ff ff       	call   4000 <ad_raw_fail>
    52a9:	48 8d 3d 7d 9e 00 00 	lea    0x9e7d(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    52b0:	e8 4b ed ff ff       	call   4000 <ad_raw_fail>
    52b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52bc:	00 00 00 00 

00000000000052c0 <fwp_tape_buffers_release>:
    52c0:	f3 0f 1e fa          	endbr64
    52c4:	53                   	push   %rbx
    52c5:	48 89 fb             	mov    %rdi,%rbx
    52c8:	48 83 ec 10          	sub    $0x10,%rsp
    52cc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    52d0:	48 85 c0             	test   %rax,%rax
    52d3:	0f 88 d7 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52d9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    52dd:	48 85 d2             	test   %rdx,%rdx
    52e0:	0f 88 ca 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52e6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    52ec:	0f 87 be 00 00 00    	ja     53b0 <fwp_tape_buffers_release+0xf0>
    52f2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    52f6:	b8 00 00 08 00       	mov    $0x80000,%eax
    52fb:	48 c1 e1 03          	shl    $0x3,%rcx
    52ff:	48 29 c8             	sub    %rcx,%rax
    5302:	48 c1 e8 03          	shr    $0x3,%rax
    5306:	48 39 d0             	cmp    %rdx,%rax
    5309:	0f 82 a1 00 00 00    	jb     53b0 <fwp_tape_buffers_release+0xf0>
    530f:	48 8d 3d 4a 9e 00 00 	lea    0x9e4a(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    5316:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    531b:	48 89 14 24          	mov    %rdx,(%rsp)
    531f:	e8 6c e0 ff ff       	call   3390 <getenv@plt>
    5324:	48 8b 14 24          	mov    (%rsp),%rdx
    5328:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 09                	je     533b <fwp_tape_buffers_release+0x7b>
    5332:	80 38 30             	cmpb   $0x30,(%rax)
    5335:	0f 84 05 01 00 00    	je     5440 <fwp_tape_buffers_release+0x180>
    533b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    533f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    5343:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    5349:	77 71                	ja     53bc <fwp_tape_buffers_release+0xfc>
    534b:	48 8d 3d 6e dd 01 00 	lea    0x1dd6e(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5352:	48 89 34 24          	mov    %rsi,(%rsp)
    5356:	e8 45 fe ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    535b:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    535f:	48 8b 34 24          	mov    (%rsp),%rsi
    5363:	0f 29 05 56 dd 01 00 	movaps %xmm0,0x1dd56(%rip)        # 230c0 <fwp_tape_workspace>
    536a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    536f:	48 89 35 32 dd 01 00 	mov    %rsi,0x1dd32(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5376:	0f 29 05 53 dd 01 00 	movaps %xmm0,0x1dd53(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    537d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5382:	0f 29 05 57 dd 01 00 	movaps %xmm0,0x1dd57(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    5389:	48 8b 43 30          	mov    0x30(%rbx),%rax
    538d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5391:	48 89 05 58 dd 01 00 	mov    %rax,0x1dd58(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    5398:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    539f:	00 
    53a0:	0f 11 03             	movups %xmm0,(%rbx)
    53a3:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    53a7:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    53ab:	eb 1e                	jmp    53cb <fwp_tape_buffers_release+0x10b>
    53ad:	0f 1f 00             	nopl   (%rax)
    53b0:	48 8d 3d a9 9d 00 00 	lea    0x9da9(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    53b7:	e8 d4 df ff ff       	call   3390 <getenv@plt>
    53bc:	48 89 df             	mov    %rbx,%rdi
    53bf:	e8 dc fd ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    53c4:	48 8b 35 dd dc 01 00 	mov    0x1dcdd(%rip),%rsi        # 230a8 <fwp_tape_cached_bytes>
    53cb:	48 6b 15 2d dd 01 00 	imul   $0x68,0x1dd2d(%rip),%rdx        # 23100 <fwp_tapes_cap>
    53d2:	68 
    53d3:	48 3b 15 e6 dd 04 00 	cmp    0x4dde6(%rip),%rdx        # 531c0 <ad_raw_live>
    53da:	75 73                	jne    544f <fwp_tape_buffers_release+0x18f>
    53dc:	48 8b 05 e5 dd 04 00 	mov    0x4dde5(%rip),%rax        # 531c8 <ad_raw_live+0x8>
    53e3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    53e7:	48 01 d0             	add    %rdx,%rax
    53ea:	48 03 05 df dd 04 00 	add    0x4dddf(%rip),%rax        # 531d0 <ad_raw_live+0x10>
    53f1:	48 03 05 e0 dd 04 00 	add    0x4dde0(%rip),%rax        # 531d8 <ad_raw_live+0x18>
    53f8:	48 39 c8             	cmp    %rcx,%rax
    53fb:	72 52                	jb     544f <fwp_tape_buffers_release+0x18f>
    53fd:	48 8b 0d 1c dd 01 00 	mov    0x1dd1c(%rip),%rcx        # 23120 <ad_raw_checkpoint_count>
    5404:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    540b:	74 4e                	je     545b <fwp_tape_buffers_release+0x19b>
    540d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5411:	48 29 d0             	sub    %rdx,%rax
    5414:	48 89 3d 05 dd 01 00 	mov    %rdi,0x1dd05(%rip)        # 23120 <ad_raw_checkpoint_count>
    541b:	48 29 f0             	sub    %rsi,%rax
    541e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5422:	48 8d 0d 17 dd 01 00 	lea    0x1dd17(%rip),%rcx        # 23140 <ad_raw_checkpoints>
    5429:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    542d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5432:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5437:	48 83 c4 10          	add    $0x10,%rsp
    543b:	5b                   	pop    %rbx
    543c:	c3                   	ret
    543d:	0f 1f 00             	nopl   (%rax)
    5440:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5444:	0f 84 72 ff ff ff    	je     53bc <fwp_tape_buffers_release+0xfc>
    544a:	e9 ec fe ff ff       	jmp    533b <fwp_tape_buffers_release+0x7b>
    544f:	48 8d 3d 12 a5 00 00 	lea    0xa512(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    5456:	e8 a5 eb ff ff       	call   4000 <ad_raw_fail>
    545b:	48 8d 3d 0f 9d 00 00 	lea    0x9d0f(%rip),%rdi        # f171 <_IO_stdin_used+0x171>
    5462:	e8 99 eb ff ff       	call   4000 <ad_raw_fail>
    5467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    546e:	00 00 

0000000000005470 <fwp_poll_events>:
    5470:	53                   	push   %rbx
    5471:	48 83 ec 20          	sub    $0x20,%rsp
    5475:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    547c:	00 00 
    547e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5483:	31 c0                	xor    %eax,%eax
    5485:	e8 36 f1 ff ff       	call   45c0 <fwp_now_ns>
    548a:	48 8b 1d 67 63 06 00 	mov    0x66367(%rip),%rbx        # 6b7f8 <fwp_timers>
    5491:	48 85 db             	test   %rbx,%rbx
    5494:	0f 84 e6 00 00 00    	je     5580 <fwp_poll_events+0x110>
    549a:	48 89 c6             	mov    %rax,%rsi
    549d:	48 89 da             	mov    %rbx,%rdx
    54a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    54a7:	eb 26                	jmp    54cf <fwp_poll_events+0x5f>
    54a9:	90                   	nop
    54aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54b1:	00 00 00 00 
    54b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54bc:	00 00 00 00 
    54c0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54c7:	48 89 c8             	mov    %rcx,%rax
    54ca:	48 85 d2             	test   %rdx,%rdx
    54cd:	74 31                	je     5500 <fwp_poll_events+0x90>
    54cf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54d3:	48 85 c0             	test   %rax,%rax
    54d6:	78 e8                	js     54c0 <fwp_poll_events+0x50>
    54d8:	48 39 c1             	cmp    %rax,%rcx
    54db:	7c e3                	jl     54c0 <fwp_poll_events+0x50>
    54dd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 1c                	je     5505 <fwp_poll_events+0x95>
    54e9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54ed:	48 39 c1             	cmp    %rax,%rcx
    54f0:	7c ce                	jl     54c0 <fwp_poll_events+0x50>
    54f2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54f9:	48 85 d2             	test   %rdx,%rdx
    54fc:	75 d1                	jne    54cf <fwp_poll_events+0x5f>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	48 85 c0             	test   %rax,%rax
    5503:	78 7b                	js     5580 <fwp_poll_events+0x110>
    5505:	48 29 f0             	sub    %rsi,%rax
    5508:	48 89 c1             	mov    %rax,%rcx
    550b:	48 85 c0             	test   %rax,%rax
    550e:	0f 8e 9c 00 00 00    	jle    55b0 <fwp_poll_events+0x140>
    5514:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    551b:	de 1b 43 
    551e:	48 f7 ea             	imul   %rdx
    5521:	48 89 c8             	mov    %rcx,%rax
    5524:	48 c1 f8 3f          	sar    $0x3f,%rax
    5528:	48 c1 fa 12          	sar    $0x12,%rdx
    552c:	48 29 c2             	sub    %rax,%rdx
    552f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5536:	48 39 c1             	cmp    %rax,%rcx
    5539:	0f 95 c0             	setne  %al
    553c:	0f b6 c0             	movzbl %al,%eax
    553f:	48 01 d0             	add    %rdx,%rax
    5542:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5548:	0f 8f 32 01 00 00    	jg     5680 <fwp_poll_events+0x210>
    554e:	48 85 c0             	test   %rax,%rax
    5551:	74 5d                	je     55b0 <fwp_poll_events+0x140>
    5553:	89 c1                	mov    %eax,%ecx
    5555:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    555c:	48 c1 e9 26          	shr    $0x26,%rcx
    5560:	48 63 d1             	movslq %ecx,%rdx
    5563:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5569:	29 c8                	sub    %ecx,%eax
    556b:	48 98                	cltq
    556d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5574:	e9 11 01 00 00       	jmp    568a <fwp_poll_events+0x21a>
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	e8 7b e7 ff ff       	call   3d00 <fwp_flush>
    5585:	ba 2b 00 00 00       	mov    $0x2b,%edx
    558a:	be 01 00 00 00       	mov    $0x1,%esi
    558f:	48 8b 0d aa da 00 00 	mov    0xdaaa(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5596:	48 8d 3d fb a3 00 00 	lea    0xa3fb(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    559d:	e8 be e0 ff ff       	call   3660 <fwrite@plt>
    55a2:	bf 65 00 00 00       	mov    $0x65,%edi
    55a7:	e8 a4 e0 ff ff       	call   3650 <exit@plt>
    55ac:	0f 1f 40 00          	nopl   0x0(%rax)
    55b0:	e8 0b f0 ff ff       	call   45c0 <fwp_now_ns>
    55b5:	48 89 c1             	mov    %rax,%rcx
    55b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55bc:	eb 44                	jmp    5602 <fwp_poll_events+0x192>
    55be:	66 90                	xchg   %ax,%ax
    55c0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    55c4:	75 33                	jne    55f9 <fwp_poll_events+0x189>
    55c6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ca:	75 2d                	jne    55f9 <fwp_poll_events+0x189>
    55cc:	48 8b 05 2d 62 06 00 	mov    0x6622d(%rip),%rax        # 6b800 <fwp_ready_tail>
    55d3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    55d7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    55de:	00 00 00 00 
    55e2:	48 85 c0             	test   %rax,%rax
    55e5:	0f 84 05 01 00 00    	je     56f0 <fwp_poll_events+0x280>
    55eb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    55f2:	48 89 15 07 62 06 00 	mov    %rdx,0x66207(%rip)        # 6b800 <fwp_ready_tail>
    55f9:	48 85 db             	test   %rbx,%rbx
    55fc:	0f 84 be 00 00 00    	je     56c0 <fwp_poll_events+0x250>
    5602:	48 89 da             	mov    %rbx,%rdx
    5605:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    560c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5610:	7f e7                	jg     55f9 <fwp_poll_events+0x189>
    5612:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5616:	74 2e                	je     5646 <fwp_poll_events+0x1d6>
    5618:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    561f:	48 85 c0             	test   %rax,%rax
    5622:	0f 84 b8 00 00 00    	je     56e0 <fwp_poll_events+0x270>
    5628:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    562f:	48 85 db             	test   %rbx,%rbx
    5632:	74 07                	je     563b <fwp_poll_events+0x1cb>
    5634:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    563b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    563f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5646:	48 8b 42 60          	mov    0x60(%rdx),%rax
    564a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    564e:	48 85 c0             	test   %rax,%rax
    5651:	0f 84 69 ff ff ff    	je     55c0 <fwp_poll_events+0x150>
    5657:	48 39 c8             	cmp    %rcx,%rax
    565a:	0f 8f 60 ff ff ff    	jg     55c0 <fwp_poll_events+0x150>
    5660:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5664:	0f 85 56 ff ff ff    	jne    55c0 <fwp_poll_events+0x150>
    566a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    566e:	75 89                	jne    55f9 <fwp_poll_events+0x189>
    5670:	48 89 d7             	mov    %rdx,%rdi
    5673:	e8 b8 ea ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5678:	e9 43 ff ff ff       	jmp    55c0 <fwp_poll_events+0x150>
    567d:	0f 1f 00             	nopl   (%rax)
    5680:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5685:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    568a:	48 89 e7             	mov    %rsp,%rdi
    568d:	31 f6                	xor    %esi,%esi
    568f:	48 89 14 24          	mov    %rdx,(%rsp)
    5693:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5698:	e8 f3 dd ff ff       	call   3490 <nanosleep@plt>
    569d:	48 8b 1d 54 61 06 00 	mov    0x66154(%rip),%rbx        # 6b7f8 <fwp_timers>
    56a4:	e8 17 ef ff ff       	call   45c0 <fwp_now_ns>
    56a9:	48 89 c1             	mov    %rax,%rcx
    56ac:	48 85 db             	test   %rbx,%rbx
    56af:	0f 85 03 ff ff ff    	jne    55b8 <fwp_poll_events+0x148>
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    56c5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    56cc:	00 00 
    56ce:	75 2c                	jne    56fc <fwp_poll_events+0x28c>
    56d0:	48 83 c4 20          	add    $0x20,%rsp
    56d4:	5b                   	pop    %rbx
    56d5:	c3                   	ret
    56d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56dd:	00 00 00 
    56e0:	48 89 1d 11 61 06 00 	mov    %rbx,0x66111(%rip)        # 6b7f8 <fwp_timers>
    56e7:	e9 43 ff ff ff       	jmp    562f <fwp_poll_events+0x1bf>
    56ec:	0f 1f 40 00          	nopl   0x0(%rax)
    56f0:	48 89 15 11 61 06 00 	mov    %rdx,0x66111(%rip)        # 6b808 <fwp_ready_head>
    56f7:	e9 f6 fe ff ff       	jmp    55f2 <fwp_poll_events+0x182>
    56fc:	e8 4f dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5701:	0f 1f 40 00          	nopl   0x0(%rax)
    5705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    570c:	00 00 00 00 

0000000000005710 <fwp_rc_wide_dup>:
    5710:	48 89 fa             	mov    %rdi,%rdx
    5713:	48 8d 35 26 61 06 00 	lea    0x66126(%rip),%rsi        # 6b840 <fwp_heap>
    571a:	48 83 ec 18          	sub    $0x18,%rsp
    571e:	48 89 f9             	mov    %rdi,%rcx
    5721:	48 c1 ea 11          	shr    $0x11,%rdx
    5725:	48 31 fa             	xor    %rdi,%rdx
    5728:	48 89 d0             	mov    %rdx,%rax
    572b:	48 c1 e8 09          	shr    $0x9,%rax
    572f:	48 31 c2             	xor    %rax,%rdx
    5732:	0f b6 d2             	movzbl %dl,%edx
    5735:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    573c:	00 
    573d:	49 8b 00             	mov    (%r8),%rax
    5740:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5747:	00 00 
    5749:	75 21                	jne    576c <fwp_rc_wide_dup+0x5c>
    574b:	e9 98 00 00 00       	jmp    57e8 <fwp_rc_wide_dup+0xd8>
    5750:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    575c:	00 00 00 00 
    5760:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5764:	48 85 d2             	test   %rdx,%rdx
    5767:	74 2f                	je     5798 <fwp_rc_wide_dup+0x88>
    5769:	48 89 d0             	mov    %rdx,%rax
    576c:	48 3b 08             	cmp    (%rax),%rcx
    576f:	75 ef                	jne    5760 <fwp_rc_wide_dup+0x50>
    5771:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5774:	74 7c                	je     57f2 <fwp_rc_wide_dup+0xe2>
    5776:	48 8b 50 08          	mov    0x8(%rax),%rdx
    577a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    577e:	0f 84 91 00 00 00    	je     5815 <fwp_rc_wide_dup+0x105>
    5784:	48 83 c2 01          	add    $0x1,%rdx
    5788:	48 89 50 08          	mov    %rdx,0x8(%rax)
    578c:	48 83 c4 18          	add    $0x18,%rsp
    5790:	c3                   	ret
    5791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5798:	4c 8d 40 10          	lea    0x10(%rax),%r8
    579c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    579f:	75 68                	jne    5809 <fwp_rc_wide_dup+0xf9>
    57a1:	bf 18 00 00 00       	mov    $0x18,%edi
    57a6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    57ab:	4c 89 04 24          	mov    %r8,(%rsp)
    57af:	e8 dc dd ff ff       	call   3590 <malloc@plt>
    57b4:	4c 8b 04 24          	mov    (%rsp),%r8
    57b8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    57bd:	48 85 c0             	test   %rax,%rax
    57c0:	74 5f                	je     5821 <fwp_rc_wide_dup+0x111>
    57c2:	48 89 08             	mov    %rcx,(%rax)
    57c5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    57cc:	00 
    57cd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    57d4:	00 
    57d5:	49 89 00             	mov    %rax,(%r8)
    57d8:	c6 01 ff             	movb   $0xff,(%rcx)
    57db:	48 83 05 a5 7c 06 00 	addq   $0x1,0x67ca5(%rip)        # 6d488 <fwp_heap+0x1c48>
    57e2:	01 
    57e3:	48 83 c4 18          	add    $0x18,%rsp
    57e7:	c3                   	ret
    57e8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    57eb:	75 13                	jne    5800 <fwp_rc_wide_dup+0xf0>
    57ed:	48 85 c0             	test   %rax,%rax
    57f0:	74 af                	je     57a1 <fwp_rc_wide_dup+0x91>
    57f2:	48 8d 3d cf a1 00 00 	lea    0xa1cf(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    57f9:	e8 52 ec ff ff       	call   4450 <fwp_trap>
    57fe:	66 90                	xchg   %ax,%ax
    5800:	48 85 c0             	test   %rax,%rax
    5803:	0f 85 6d ff ff ff    	jne    5776 <fwp_rc_wide_dup+0x66>
    5809:	48 8d 3d e0 a1 00 00 	lea    0xa1e0(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5810:	e8 3b ec ff ff       	call   4450 <fwp_trap>
    5815:	48 8d 3d 72 99 00 00 	lea    0x9972(%rip),%rdi        # f18e <_IO_stdin_used+0x18e>
    581c:	e8 2f ec ff ff       	call   4450 <fwp_trap>
    5821:	e8 0a e6 ff ff       	call   3e30 <fwp_heap_oom>
    5826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    582d:	00 00 00 

0000000000005830 <fwp_rc_forget_slot>:
    5830:	80 3f ff             	cmpb   $0xff,(%rdi)
    5833:	74 0b                	je     5840 <fwp_rc_forget_slot+0x10>
    5835:	c3                   	ret
    5836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    583d:	00 00 00 
    5840:	48 89 f8             	mov    %rdi,%rax
    5843:	48 83 ec 08          	sub    $0x8,%rsp
    5847:	48 89 fa             	mov    %rdi,%rdx
    584a:	48 c1 e8 11          	shr    $0x11,%rax
    584e:	48 31 f8             	xor    %rdi,%rax
    5851:	48 89 c1             	mov    %rax,%rcx
    5854:	48 c1 e9 09          	shr    $0x9,%rcx
    5858:	48 31 c8             	xor    %rcx,%rax
    585b:	48 8d 0d de 5f 06 00 	lea    0x65fde(%rip),%rcx        # 6b840 <fwp_heap>
    5862:	0f b6 c0             	movzbl %al,%eax
    5865:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    586c:	00 
    586d:	48 85 ff             	test   %rdi,%rdi
    5870:	74 3c                	je     58ae <fwp_rc_forget_slot+0x7e>
    5872:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5879:	00 
    587a:	48 8b 01             	mov    (%rcx),%rax
    587d:	eb 11                	jmp    5890 <fwp_rc_forget_slot+0x60>
    587f:	90                   	nop
    5880:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5884:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5888:	48 85 ff             	test   %rdi,%rdi
    588b:	74 21                	je     58ae <fwp_rc_forget_slot+0x7e>
    588d:	48 89 f8             	mov    %rdi,%rax
    5890:	48 3b 10             	cmp    (%rax),%rdx
    5893:	75 eb                	jne    5880 <fwp_rc_forget_slot+0x50>
    5895:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5899:	48 89 01             	mov    %rax,(%rcx)
    589c:	e8 0f db ff ff       	call   33b0 <free@plt>
    58a1:	48 83 2d df 7b 06 00 	subq   $0x1,0x67bdf(%rip)        # 6d488 <fwp_heap+0x1c48>
    58a8:	01 
    58a9:	48 83 c4 08          	add    $0x8,%rsp
    58ad:	c3                   	ret
    58ae:	48 8d 3d 3b a1 00 00 	lea    0xa13b(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    58b5:	e8 96 eb ff ff       	call   4450 <fwp_trap>
    58ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000058c0 <fwp_rc_prepare_chunk>:
    58c0:	48 83 3d c0 7b 06 00 	cmpq   $0x0,0x67bc0(%rip)        # 6d488 <fwp_heap+0x1c48>
    58c7:	00 
    58c8:	41 54                	push   %r12
    58ca:	49 89 f4             	mov    %rsi,%r12
    58cd:	55                   	push   %rbp
    58ce:	48 89 fd             	mov    %rdi,%rbp
    58d1:	53                   	push   %rbx
    58d2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    58d5:	0f 84 7d 00 00 00    	je     5958 <fwp_rc_prepare_chunk+0x98>
    58db:	31 db                	xor    %ebx,%ebx
    58dd:	85 c0                	test   %eax,%eax
    58df:	75 5f                	jne    5940 <fwp_rc_prepare_chunk+0x80>
    58e1:	48 85 f6             	test   %rsi,%rsi
    58e4:	74 7c                	je     5962 <fwp_rc_prepare_chunk+0xa2>
    58e6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    58ea:	e8 c1 da ff ff       	call   33b0 <free@plt>
    58ef:	90                   	nop
    58f0:	be 01 00 00 00       	mov    $0x1,%esi
    58f5:	4c 89 e7             	mov    %r12,%rdi
    58f8:	e8 13 dc ff ff       	call   3510 <calloc@plt>
    58fd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5901:	48 85 c0             	test   %rax,%rax
    5904:	0f 85 87 00 00 00    	jne    5991 <fwp_rc_prepare_chunk+0xd1>
    590a:	e8 21 e5 ff ff       	call   3e30 <fwp_heap_oom>
    590f:	90                   	nop
    5910:	e8 1b ff ff ff       	call   5830 <fwp_rc_forget_slot>
    5915:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5918:	48 83 c3 01          	add    $0x1,%rbx
    591c:	48 39 c3             	cmp    %rax,%rbx
    591f:	73 37                	jae    5958 <fwp_rc_prepare_chunk+0x98>
    5921:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5928:	00 00 
    592a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5931:	00 00 00 00 
    5935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    593c:	00 00 00 00 
    5940:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5944:	48 01 df             	add    %rbx,%rdi
    5947:	80 3f ff             	cmpb   $0xff,(%rdi)
    594a:	74 c4                	je     5910 <fwp_rc_prepare_chunk+0x50>
    594c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    594f:	48 83 c3 01          	add    $0x1,%rbx
    5953:	48 39 c3             	cmp    %rax,%rbx
    5956:	72 e8                	jb     5940 <fwp_rc_prepare_chunk+0x80>
    5958:	49 39 c4             	cmp    %rax,%r12
    595b:	75 13                	jne    5970 <fwp_rc_prepare_chunk+0xb0>
    595d:	4d 85 e4             	test   %r12,%r12
    5960:	75 46                	jne    59a8 <fwp_rc_prepare_chunk+0xe8>
    5962:	5b                   	pop    %rbx
    5963:	5d                   	pop    %rbp
    5964:	41 5c                	pop    %r12
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5974:	48 29 05 15 7b 06 00 	sub    %rax,0x67b15(%rip)        # 6d490 <fwp_heap+0x1c50>
    597b:	e8 30 da ff ff       	call   33b0 <free@plt>
    5980:	4d 85 e4             	test   %r12,%r12
    5983:	0f 85 67 ff ff ff    	jne    58f0 <fwp_rc_prepare_chunk+0x30>
    5989:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5990:	00 
    5991:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5995:	5b                   	pop    %rbx
    5996:	4c 01 25 f3 7a 06 00 	add    %r12,0x67af3(%rip)        # 6d490 <fwp_heap+0x1c50>
    599d:	5d                   	pop    %rbp
    599e:	41 5c                	pop    %r12
    59a0:	c3                   	ret
    59a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    59ac:	5b                   	pop    %rbx
    59ad:	4c 89 e2             	mov    %r12,%rdx
    59b0:	31 f6                	xor    %esi,%esi
    59b2:	5d                   	pop    %rbp
    59b3:	41 5c                	pop    %r12
    59b5:	e9 f6 da ff ff       	jmp    34b0 <memset@plt>
    59ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000059c0 <fwp_heap_refill>:
    59c0:	41 56                	push   %r14
    59c2:	41 89 d6             	mov    %edx,%r14d
    59c5:	41 55                	push   %r13
    59c7:	41 89 f5             	mov    %esi,%r13d
    59ca:	41 54                	push   %r12
    59cc:	49 89 fc             	mov    %rdi,%r12
    59cf:	bf 01 00 00 00       	mov    $0x1,%edi
    59d4:	55                   	push   %rbp
    59d5:	53                   	push   %rbx
    59d6:	e8 95 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    59db:	48 89 c3             	mov    %rax,%rbx
    59de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    59e2:	48 8b 05 4f 72 06 00 	mov    0x6724f(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    59e9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    59ed:	48 8d 05 4c 5e 06 00 	lea    0x65e4c(%rip),%rax        # 6b840 <fwp_heap>
    59f4:	31 d2                	xor    %edx,%edx
    59f6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    59fa:	48 89 ef             	mov    %rbp,%rdi
    59fd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5a01:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5a05:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    5a0c:	00 
    5a0d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5a12:	f7 f1                	div    %ecx
    5a14:	31 d2                	xor    %edx,%edx
    5a16:	66 0f 6e c1          	movd   %ecx,%xmm0
    5a1a:	66 0f 6e c8          	movd   %eax,%xmm1
    5a1e:	89 c6                	mov    %eax,%esi
    5a20:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5a25:	48 01 c8             	add    %rcx,%rax
    5a28:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5a2c:	48 f7 f1             	div    %rcx
    5a2f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5a34:	89 45 18             	mov    %eax,0x18(%rbp)
    5a37:	e8 84 fe ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5a3c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    5a3f:	48 89 d8             	mov    %rbx,%rax
    5a42:	48 c1 e0 10          	shl    $0x10,%rax
    5a46:	48 03 05 a3 71 06 00 	add    0x671a3(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    5a4d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5a51:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5a56:	8b 55 08             	mov    0x8(%rbp),%edx
    5a59:	48 0f af d1          	imul   %rcx,%rdx
    5a5d:	48 01 c2             	add    %rax,%rdx
    5a60:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a65:	5b                   	pop    %rbx
    5a66:	5d                   	pop    %rbp
    5a67:	41 5c                	pop    %r12
    5a69:	41 5d                	pop    %r13
    5a6b:	41 5e                	pop    %r14
    5a6d:	c3                   	ret
    5a6e:	66 90                	xchg   %ax,%ax

0000000000005a70 <fwp_mem_free>:
    5a70:	48 85 ff             	test   %rdi,%rdi
    5a73:	0f 84 17 02 00 00    	je     5c90 <fwp_mem_free+0x220>
    5a79:	48 8b 35 70 71 06 00 	mov    0x67170(%rip),%rsi        # 6cbf0 <fwp_heap+0x13b0>
    5a80:	48 8b 05 91 71 06 00 	mov    0x67191(%rip),%rax        # 6cc18 <fwp_heap+0x13d8>
    5a87:	48 89 fa             	mov    %rdi,%rdx
    5a8a:	48 29 f2             	sub    %rsi,%rdx
    5a8d:	48 c1 e0 10          	shl    $0x10,%rax
    5a91:	48 39 c2             	cmp    %rax,%rdx
    5a94:	0f 83 f6 01 00 00    	jae    5c90 <fwp_mem_free+0x220>
    5a9a:	49 89 d1             	mov    %rdx,%r9
    5a9d:	49 c1 e9 10          	shr    $0x10,%r9
    5aa1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5aa5:	48 c1 e0 03          	shl    $0x3,%rax
    5aa9:	49 89 c0             	mov    %rax,%r8
    5aac:	4c 03 05 85 71 06 00 	add    0x67185(%rip),%r8        # 6cc38 <fwp_heap+0x13f8>
    5ab3:	0f 84 d7 01 00 00    	je     5c90 <fwp_mem_free+0x220>
    5ab9:	48 83 ec 38          	sub    $0x38,%rsp
    5abd:	48 89 f9             	mov    %rdi,%rcx
    5ac0:	41 0f b6 38          	movzbl (%r8),%edi
    5ac4:	40 80 ff 01          	cmp    $0x1,%dil
    5ac8:	74 16                	je     5ae0 <fwp_mem_free+0x70>
    5aca:	40 80 ff 02          	cmp    $0x2,%dil
    5ace:	0f 84 94 00 00 00    	je     5b68 <fwp_mem_free+0xf8>
    5ad4:	48 83 c4 38          	add    $0x38,%rsp
    5ad8:	c3                   	ret
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5ae4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5ae9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5aee:	41 8b 78 04          	mov    0x4(%r8),%edi
    5af2:	4d 85 d2             	test   %r10,%r10
    5af5:	74 1d                	je     5b14 <fwp_mem_free+0xa4>
    5af7:	0f b7 c1             	movzwl %cx,%eax
    5afa:	31 d2                	xor    %edx,%edx
    5afc:	48 f7 f7             	div    %rdi
    5aff:	49 01 c2             	add    %rax,%r10
    5b02:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5b06:	0f 84 44 01 00 00    	je     5c50 <fwp_mem_free+0x1e0>
    5b0c:	41 c6 02 00          	movb   $0x0,(%r10)
    5b10:	41 8b 78 04          	mov    0x4(%r8),%edi
    5b14:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5b1b:	49 63 c1             	movslq %r9d,%rax
    5b1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b22:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b26:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5b2b:	f2 0f 58 05 4d 71 06 	addsd  0x6714d(%rip),%xmm0        # 6cc80 <fwp_heap+0x1440>
    5b32:	00 
    5b33:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5b37:	48 8d 05 02 5d 06 00 	lea    0x65d02(%rip),%rax        # 6b840 <fwp_heap>
    5b3e:	48 01 d0             	add    %rdx,%rax
    5b41:	48 8b 10             	mov    (%rax),%rdx
    5b44:	48 f7 d2             	not    %rdx
    5b47:	48 89 11             	mov    %rdx,(%rcx)
    5b4a:	48 89 08             	mov    %rcx,(%rax)
    5b4d:	48 29 3d 0c 71 06 00 	sub    %rdi,0x6710c(%rip)        # 6cc60 <fwp_heap+0x1420>
    5b54:	f2 0f 11 05 24 71 06 	movsd  %xmm0,0x67124(%rip)        # 6cc80 <fwp_heap+0x1440>
    5b5b:	00 
    5b5c:	48 83 c4 38          	add    $0x38,%rsp
    5b60:	c3                   	ret
    5b61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b68:	66 31 d2             	xor    %dx,%dx
    5b6b:	48 01 d6             	add    %rdx,%rsi
    5b6e:	48 39 f1             	cmp    %rsi,%rcx
    5b71:	0f 85 5d ff ff ff    	jne    5ad4 <fwp_mem_free+0x64>
    5b77:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b7b:	48 29 15 de 70 06 00 	sub    %rdx,0x670de(%rip)        # 6cc60 <fwp_heap+0x1420>
    5b82:	48 85 d2             	test   %rdx,%rdx
    5b85:	0f 88 a5 00 00 00    	js     5c30 <fwp_mem_free+0x1c0>
    5b8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b8f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b94:	f2 0f 58 05 e4 70 06 	addsd  0x670e4(%rip),%xmm0        # 6cc80 <fwp_heap+0x1440>
    5b9b:	00 
    5b9c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ba0:	f2 0f 11 05 d8 70 06 	movsd  %xmm0,0x670d8(%rip)        # 6cc80 <fwp_heap+0x1440>
    5ba7:	00 
    5ba8:	48 85 d2             	test   %rdx,%rdx
    5bab:	74 0c                	je     5bb9 <fwp_mem_free+0x149>
    5bad:	80 3a ff             	cmpb   $0xff,(%rdx)
    5bb0:	0f 84 db 00 00 00    	je     5c91 <fwp_mem_free+0x221>
    5bb6:	c6 02 00             	movb   $0x0,(%rdx)
    5bb9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5bbd:	48 85 c9             	test   %rcx,%rcx
    5bc0:	74 3e                	je     5c00 <fwp_mem_free+0x190>
    5bc2:	48 8b 15 6f 70 06 00 	mov    0x6706f(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    5bc9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bcd:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5bd1:	48 01 d0             	add    %rdx,%rax
    5bd4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5bd8:	48 89 d6             	mov    %rdx,%rsi
    5bdb:	48 29 c6             	sub    %rax,%rsi
    5bde:	83 e6 08             	and    $0x8,%esi
    5be1:	74 0d                	je     5bf0 <fwp_mem_free+0x180>
    5be3:	c6 00 00             	movb   $0x0,(%rax)
    5be6:	48 83 c0 28          	add    $0x28,%rax
    5bea:	48 39 c2             	cmp    %rax,%rdx
    5bed:	74 11                	je     5c00 <fwp_mem_free+0x190>
    5bef:	90                   	nop
    5bf0:	c6 00 00             	movb   $0x0,(%rax)
    5bf3:	48 83 c0 50          	add    $0x50,%rax
    5bf7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5bfb:	48 39 c2             	cmp    %rax,%rdx
    5bfe:	75 f0                	jne    5bf0 <fwp_mem_free+0x180>
    5c00:	48 01 0d 69 70 06 00 	add    %rcx,0x67069(%rip)        # 6cc70 <fwp_heap+0x1430>
    5c07:	4c 3b 0d 22 70 06 00 	cmp    0x67022(%rip),%r9        # 6cc30 <fwp_heap+0x13f0>
    5c0e:	73 07                	jae    5c17 <fwp_mem_free+0x1a7>
    5c10:	4c 89 0d 19 70 06 00 	mov    %r9,0x67019(%rip)        # 6cc30 <fwp_heap+0x13f0>
    5c17:	4c 3b 0d 0a 70 06 00 	cmp    0x6700a(%rip),%r9        # 6cc28 <fwp_heap+0x13e8>
    5c1e:	0f 83 b0 fe ff ff    	jae    5ad4 <fwp_mem_free+0x64>
    5c24:	4c 89 0d fd 6f 06 00 	mov    %r9,0x66ffd(%rip)        # 6cc28 <fwp_heap+0x13e8>
    5c2b:	e9 a4 fe ff ff       	jmp    5ad4 <fwp_mem_free+0x64>
    5c30:	48 89 d1             	mov    %rdx,%rcx
    5c33:	83 e2 01             	and    $0x1,%edx
    5c36:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c3a:	48 d1 e9             	shr    $1,%rcx
    5c3d:	48 09 d1             	or     %rdx,%rcx
    5c40:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5c45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5c49:	e9 46 ff ff ff       	jmp    5b94 <fwp_mem_free+0x124>
    5c4e:	66 90                	xchg   %ax,%ax
    5c50:	4c 89 d7             	mov    %r10,%rdi
    5c53:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5c58:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5c5d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c62:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c66:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c6b:	e8 c0 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5c70:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c75:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c7a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c7f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c84:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c89:	e9 7e fe ff ff       	jmp    5b0c <fwp_mem_free+0x9c>
    5c8e:	66 90                	xchg   %ax,%ax
    5c90:	c3                   	ret
    5c91:	48 89 d7             	mov    %rdx,%rdi
    5c94:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c99:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c9e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5ca3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5ca8:	e8 83 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5cad:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5cb2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5cb7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5cbc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5cc1:	e9 f0 fe ff ff       	jmp    5bb6 <fwp_mem_free+0x146>
    5cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ccd:	00 00 00 

0000000000005cd0 <fwp_heap_alloc_big>:
    5cd0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5cd7:	00 00 40 
    5cda:	41 57                	push   %r15
    5cdc:	41 56                	push   %r14
    5cde:	41 55                	push   %r13
    5ce0:	41 54                	push   %r12
    5ce2:	55                   	push   %rbp
    5ce3:	53                   	push   %rbx
    5ce4:	48 83 ec 08          	sub    $0x8,%rsp
    5ce8:	48 39 f8             	cmp    %rdi,%rax
    5ceb:	0f 82 fa 00 00 00    	jb     5deb <fwp_heap_alloc_big+0x11b>
    5cf1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5cf8:	49 89 fd             	mov    %rdi,%r13
    5cfb:	41 89 f6             	mov    %esi,%r14d
    5cfe:	48 c1 ed 10          	shr    $0x10,%rbp
    5d02:	48 89 ef             	mov    %rbp,%rdi
    5d05:	e8 66 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5d0a:	be 01 00 00 00       	mov    $0x1,%esi
    5d0f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5d13:	49 89 c4             	mov    %rax,%r12
    5d16:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5d1d:	00 
    5d1e:	48 03 3d 13 6f 06 00 	add    0x66f13(%rip),%rdi        # 6cc38 <fwp_heap+0x13f8>
    5d25:	c6 07 02             	movb   $0x2,(%rdi)
    5d28:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5d2c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5d2f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5d33:	e8 88 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d38:	48 83 fd 01          	cmp    $0x1,%rbp
    5d3c:	76 47                	jbe    5d85 <fwp_heap_alloc_big+0xb5>
    5d3e:	4c 01 e5             	add    %r12,%rbp
    5d41:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5d48:	00 
    5d49:	4c 8d 3d f0 5a 06 00 	lea    0x65af0(%rip),%r15        # 6b840 <fwp_heap>
    5d50:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5d55:	49 c1 e6 03          	shl    $0x3,%r14
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d67:	31 f6                	xor    %esi,%esi
    5d69:	48 01 dd             	add    %rbx,%rbp
    5d6c:	48 83 c3 28          	add    $0x28,%rbx
    5d70:	48 89 ef             	mov    %rbp,%rdi
    5d73:	e8 48 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d78:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d7c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d80:	49 39 de             	cmp    %rbx,%r14
    5d83:	75 db                	jne    5d60 <fwp_heap_alloc_big+0x90>
    5d85:	49 c1 e4 10          	shl    $0x10,%r12
    5d89:	4c 03 25 60 6e 06 00 	add    0x66e60(%rip),%r12        # 6cbf0 <fwp_heap+0x13b0>
    5d90:	4c 89 ea             	mov    %r13,%rdx
    5d93:	31 f6                	xor    %esi,%esi
    5d95:	4c 89 e7             	mov    %r12,%rdi
    5d98:	e8 13 d7 ff ff       	call   34b0 <memset@plt>
    5d9d:	4c 89 e8             	mov    %r13,%rax
    5da0:	48 03 05 b9 6e 06 00 	add    0x66eb9(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    5da7:	72 42                	jb     5deb <fwp_heap_alloc_big+0x11b>
    5da9:	48 39 05 b8 6e 06 00 	cmp    %rax,0x66eb8(%rip)        # 6cc68 <fwp_heap+0x1428>
    5db0:	48 89 05 a9 6e 06 00 	mov    %rax,0x66ea9(%rip)        # 6cc60 <fwp_heap+0x1420>
    5db7:	73 07                	jae    5dc0 <fwp_heap_alloc_big+0xf0>
    5db9:	48 89 05 a8 6e 06 00 	mov    %rax,0x66ea8(%rip)        # 6cc68 <fwp_heap+0x1428>
    5dc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dc4:	4c 89 e0             	mov    %r12,%rax
    5dc7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5dcc:	f2 0f 58 05 a4 6e 06 	addsd  0x66ea4(%rip),%xmm0        # 6cc78 <fwp_heap+0x1438>
    5dd3:	00 
    5dd4:	f2 0f 11 05 9c 6e 06 	movsd  %xmm0,0x66e9c(%rip)        # 6cc78 <fwp_heap+0x1438>
    5ddb:	00 
    5ddc:	48 83 c4 08          	add    $0x8,%rsp
    5de0:	5b                   	pop    %rbx
    5de1:	5d                   	pop    %rbp
    5de2:	41 5c                	pop    %r12
    5de4:	41 5d                	pop    %r13
    5de6:	41 5e                	pop    %r14
    5de8:	41 5f                	pop    %r15
    5dea:	c3                   	ret
    5deb:	e8 40 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005df0 <fwp_heap_alloc_slow>:
    5df0:	53                   	push   %rbx
    5df1:	48 89 f9             	mov    %rdi,%rcx
    5df4:	41 89 f1             	mov    %esi,%r9d
    5df7:	48 83 ec 10          	sub    $0x10,%rsp
    5dfb:	8b 05 e3 6d 06 00    	mov    0x66de3(%rip),%eax        # 6cbe4 <fwp_heap+0x13a4>
    5e01:	85 c0                	test   %eax,%eax
    5e03:	0f 84 c7 00 00 00    	je     5ed0 <fwp_heap_alloc_slow+0xe0>
    5e09:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e10:	0f 87 dd 00 00 00    	ja     5ef3 <fwp_heap_alloc_slow+0x103>
    5e16:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5e1a:	48 8d 3d 1f 5a 06 00 	lea    0x65a1f(%rip),%rdi        # 6b840 <fwp_heap>
    5e21:	49 63 f1             	movslq %r9d,%rsi
    5e24:	48 c1 e8 04          	shr    $0x4,%rax
    5e28:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5e2f:	00 00 
    5e31:	41 0f b6 c2          	movzbl %r10b,%eax
    5e35:	4c 89 d2             	mov    %r10,%rdx
    5e38:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5e3c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5e43:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5e4a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5e4e:	48 01 f8             	add    %rdi,%rax
    5e51:	4c 8b 00             	mov    (%rax),%r8
    5e54:	4d 85 c0             	test   %r8,%r8
    5e57:	0f 84 ab 00 00 00    	je     5f08 <fwp_heap_alloc_slow+0x118>
    5e5d:	49 8b 10             	mov    (%r8),%rdx
    5e60:	48 f7 d2             	not    %rdx
    5e63:	48 89 10             	mov    %rdx,(%rax)
    5e66:	41 83 f9 01          	cmp    $0x1,%r9d
    5e6a:	4c 89 c7             	mov    %r8,%rdi
    5e6d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e71:	31 f6                	xor    %esi,%esi
    5e73:	48 89 ca             	mov    %rcx,%rdx
    5e76:	e8 35 d6 ff ff       	call   34b0 <memset@plt>
    5e7b:	49 89 c0             	mov    %rax,%r8
    5e7e:	48 89 d8             	mov    %rbx,%rax
    5e81:	48 03 05 d8 6d 06 00 	add    0x66dd8(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    5e88:	0f 82 d9 00 00 00    	jb     5f67 <fwp_heap_alloc_slow+0x177>
    5e8e:	48 39 05 d3 6d 06 00 	cmp    %rax,0x66dd3(%rip)        # 6cc68 <fwp_heap+0x1428>
    5e95:	48 89 05 c4 6d 06 00 	mov    %rax,0x66dc4(%rip)        # 6cc60 <fwp_heap+0x1420>
    5e9c:	73 07                	jae    5ea5 <fwp_heap_alloc_slow+0xb5>
    5e9e:	48 89 05 c3 6d 06 00 	mov    %rax,0x66dc3(%rip)        # 6cc68 <fwp_heap+0x1428>
    5ea5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ea9:	4c 89 c0             	mov    %r8,%rax
    5eac:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5eb1:	f2 0f 58 05 bf 6d 06 	addsd  0x66dbf(%rip),%xmm0        # 6cc78 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 b7 6d 06 	movsd  %xmm0,0x66db7(%rip)        # 6cc78 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	48 83 c4 10          	add    $0x10,%rsp
    5ec5:	5b                   	pop    %rbx
    5ec6:	c3                   	ret
    5ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ece:	00 00 
    5ed0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5ed4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5ed8:	e8 f3 ee ff ff       	call   4dd0 <fwp_heap_init>
    5edd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5ee1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5ee6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5eed:	0f 86 23 ff ff ff    	jbe    5e16 <fwp_heap_alloc_slow+0x26>
    5ef3:	48 83 c4 10          	add    $0x10,%rsp
    5ef7:	44 89 ce             	mov    %r9d,%esi
    5efa:	48 89 cf             	mov    %rcx,%rdi
    5efd:	5b                   	pop    %rbx
    5efe:	e9 cd fd ff ff       	jmp    5cd0 <fwp_heap_alloc_big>
    5f03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f08:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5f0c:	4d 85 c0             	test   %r8,%r8
    5f0f:	74 1f                	je     5f30 <fwp_heap_alloc_slow+0x140>
    5f11:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5f15:	4d 29 c3             	sub    %r8,%r11
    5f18:	49 39 db             	cmp    %rbx,%r11
    5f1b:	72 13                	jb     5f30 <fwp_heap_alloc_slow+0x140>
    5f1d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5f21:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f25:	e9 3c ff ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5f37:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5f3b:	44 89 ca             	mov    %r9d,%edx
    5f3e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5f43:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f47:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5f4b:	44 89 d6             	mov    %r10d,%esi
    5f4e:	48 01 c7             	add    %rax,%rdi
    5f51:	e8 6a fa ff ff       	call   59c0 <fwp_heap_refill>
    5f56:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5f5b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f5f:	49 89 c0             	mov    %rax,%r8
    5f62:	e9 ff fe ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f67:	e8 c4 de ff ff       	call   3e30 <fwp_heap_oom>
    5f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f70 <fwp_heap_alloc>:
    5f70:	53                   	push   %rbx
    5f71:	48 89 fa             	mov    %rdi,%rdx
    5f74:	48 83 ec 10          	sub    $0x10,%rsp
    5f78:	8b 1d 8a 75 06 00    	mov    0x6758a(%rip),%ebx        # 6d508 <iteration_active>
    5f7e:	8b 05 60 6c 06 00    	mov    0x66c60(%rip),%eax        # 6cbe4 <fwp_heap+0x13a4>
    5f84:	85 db                	test   %ebx,%ebx
    5f86:	0f 85 04 01 00 00    	jne    6090 <fwp_heap_alloc+0x120>
    5f8c:	85 c0                	test   %eax,%eax
    5f8e:	0f 84 ac 01 00 00    	je     6140 <fwp_heap_alloc+0x1d0>
    5f94:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f9b:	0f 87 9f 01 00 00    	ja     6140 <fwp_heap_alloc+0x1d0>
    5fa1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5fa5:	48 8d 05 94 58 06 00 	lea    0x65894(%rip),%rax        # 6b840 <fwp_heap>
    5fac:	48 c1 e9 04          	shr    $0x4,%rcx
    5fb0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5fb7:	00 
    5fb8:	48 63 ce             	movslq %esi,%rcx
    5fbb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5fc2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5fc9:	00 
    5fca:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5fce:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5fd2:	48 01 c8             	add    %rcx,%rax
    5fd5:	48 8b 08             	mov    (%rax),%rcx
    5fd8:	48 85 c9             	test   %rcx,%rcx
    5fdb:	0f 84 ff 00 00 00    	je     60e0 <fwp_heap_alloc+0x170>
    5fe1:	48 8b 39             	mov    (%rcx),%rdi
    5fe4:	48 f7 d7             	not    %rdi
    5fe7:	48 89 38             	mov    %rdi,(%rax)
    5fea:	83 fe 01             	cmp    $0x1,%esi
    5fed:	48 89 cf             	mov    %rcx,%rdi
    5ff0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ff5:	49 0f 45 d0          	cmovne %r8,%rdx
    5ff9:	31 f6                	xor    %esi,%esi
    5ffb:	e8 b0 d4 ff ff       	call   34b0 <memset@plt>
    6000:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    6005:	48 89 c1             	mov    %rax,%rcx
    6008:	4c 89 c0             	mov    %r8,%rax
    600b:	48 03 05 4e 6c 06 00 	add    0x66c4e(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    6012:	0f 82 35 01 00 00    	jb     614d <fwp_heap_alloc+0x1dd>
    6018:	48 39 05 49 6c 06 00 	cmp    %rax,0x66c49(%rip)        # 6cc68 <fwp_heap+0x1428>
    601f:	48 89 05 3a 6c 06 00 	mov    %rax,0x66c3a(%rip)        # 6cc60 <fwp_heap+0x1420>
    6026:	73 07                	jae    602f <fwp_heap_alloc+0xbf>
    6028:	48 89 05 39 6c 06 00 	mov    %rax,0x66c39(%rip)        # 6cc68 <fwp_heap+0x1428>
    602f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6033:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    6038:	f2 0f 58 05 38 6c 06 	addsd  0x66c38(%rip),%xmm0        # 6cc78 <fwp_heap+0x1438>
    603f:	00 
    6040:	f2 0f 11 05 30 6c 06 	movsd  %xmm0,0x66c30(%rip)        # 6cc78 <fwp_heap+0x1438>
    6047:	00 
    6048:	85 db                	test   %ebx,%ebx
    604a:	74 33                	je     607f <fwp_heap_alloc+0x10f>
    604c:	48 8b 05 0d 6c 06 00 	mov    0x66c0d(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    6053:	48 85 c0             	test   %rax,%rax
    6056:	0f 88 ac 00 00 00    	js     6108 <fwp_heap_alloc+0x198>
    605c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6060:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6065:	f2 0f 5c 05 7b 74 06 	subsd  0x6747b(%rip),%xmm0        # 6d4e8 <iteration_start_charge>
    606c:	00 
    606d:	66 0f 2f 05 6b 74 06 	comisd 0x6746b(%rip),%xmm0        # 6d4e0 <iteration_peak>
    6074:	00 
    6075:	76 08                	jbe    607f <fwp_heap_alloc+0x10f>
    6077:	f2 0f 11 05 61 74 06 	movsd  %xmm0,0x67461(%rip)        # 6d4e0 <iteration_peak>
    607e:	00 
    607f:	48 83 c4 10          	add    $0x10,%rsp
    6083:	48 89 c8             	mov    %rcx,%rax
    6086:	5b                   	pop    %rbx
    6087:	c3                   	ret
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	85 f6                	test   %esi,%esi
    6092:	74 34                	je     60c8 <fwp_heap_alloc+0x158>
    6094:	48 83 05 64 74 06 00 	addq   $0x1,0x67464(%rip)        # 6d500 <iteration_requests>
    609b:	01 
    609c:	48 01 3d 55 74 06 00 	add    %rdi,0x67455(%rip)        # 6d4f8 <iteration_bytes>
    60a3:	85 c0                	test   %eax,%eax
    60a5:	74 0d                	je     60b4 <fwp_heap_alloc+0x144>
    60a7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60ae:	0f 86 ed fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60b4:	48 89 d7             	mov    %rdx,%rdi
    60b7:	e8 34 fd ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60bc:	48 89 c1             	mov    %rax,%rcx
    60bf:	eb 8b                	jmp    604c <fwp_heap_alloc+0xdc>
    60c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c8:	85 c0                	test   %eax,%eax
    60ca:	74 0d                	je     60d9 <fwp_heap_alloc+0x169>
    60cc:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60d3:	0f 86 c8 fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60d9:	31 f6                	xor    %esi,%esi
    60db:	eb d7                	jmp    60b4 <fwp_heap_alloc+0x144>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    60e4:	48 85 c9             	test   %rcx,%rcx
    60e7:	74 0c                	je     60f5 <fwp_heap_alloc+0x185>
    60e9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    60ed:	48 29 cf             	sub    %rcx,%rdi
    60f0:	4c 39 c7             	cmp    %r8,%rdi
    60f3:	73 3b                	jae    6130 <fwp_heap_alloc+0x1c0>
    60f5:	48 89 d7             	mov    %rdx,%rdi
    60f8:	e8 f3 fc ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60fd:	48 89 c1             	mov    %rax,%rcx
    6100:	e9 43 ff ff ff       	jmp    6048 <fwp_heap_alloc+0xd8>
    6105:	0f 1f 00             	nopl   (%rax)
    6108:	48 89 c2             	mov    %rax,%rdx
    610b:	83 e0 01             	and    $0x1,%eax
    610e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6112:	48 d1 ea             	shr    $1,%rdx
    6115:	48 09 c2             	or     %rax,%rdx
    6118:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    611d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6121:	e9 3f ff ff ff       	jmp    6065 <fwp_heap_alloc+0xf5>
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6134:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6138:	e9 ad fe ff ff       	jmp    5fea <fwp_heap_alloc+0x7a>
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	48 83 c4 10          	add    $0x10,%rsp
    6144:	48 89 d7             	mov    %rdx,%rdi
    6147:	5b                   	pop    %rbx
    6148:	e9 a3 fc ff ff       	jmp    5df0 <fwp_heap_alloc_slow>
    614d:	e8 de dc ff ff       	call   3e30 <fwp_heap_oom>
    6152:	0f 1f 00             	nopl   (%rax)
    6155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    615c:	00 00 00 00 

0000000000006160 <fwp_data.part.0.constprop.0>:
    6160:	41 56                	push   %r14
    6162:	8b 05 7c 6a 06 00    	mov    0x66a7c(%rip),%eax        # 6cbe4 <fwp_heap+0x13a4>
    6168:	41 89 fe             	mov    %edi,%r14d
    616b:	41 55                	push   %r13
    616d:	44 8b 2d 94 73 06 00 	mov    0x67394(%rip),%r13d        # 6d508 <iteration_active>
    6174:	41 54                	push   %r12
    6176:	49 89 f4             	mov    %rsi,%r12
    6179:	55                   	push   %rbp
    617a:	53                   	push   %rbx
    617b:	45 85 ed             	test   %r13d,%r13d
    617e:	0f 84 1c 01 00 00    	je     62a0 <fwp_data.part.0.constprop.0+0x140>
    6184:	48 83 05 74 73 06 00 	addq   $0x1,0x67374(%rip)        # 6d500 <iteration_requests>
    618b:	01 
    618c:	48 83 05 64 73 06 00 	addq   $0x18,0x67364(%rip)        # 6d4f8 <iteration_bytes>
    6193:	18 
    6194:	85 c0                	test   %eax,%eax
    6196:	0f 84 8c 01 00 00    	je     6328 <fwp_data.part.0.constprop.0+0x1c8>
    619c:	0f b6 05 3f 66 06 00 	movzbl 0x6663f(%rip),%eax        # 6c7e2 <fwp_heap+0xfa2>
    61a3:	48 8d 15 96 56 06 00 	lea    0x65696(%rip),%rdx        # 6b840 <fwp_heap>
    61aa:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    61b1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    61b5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    61b9:	48 8b 18             	mov    (%rax),%rbx
    61bc:	48 85 db             	test   %rbx,%rbx
    61bf:	0f 84 fb 00 00 00    	je     62c0 <fwp_data.part.0.constprop.0+0x160>
    61c5:	48 8b 13             	mov    (%rbx),%rdx
    61c8:	48 f7 d2             	not    %rdx
    61cb:	48 89 10             	mov    %rdx,(%rax)
    61ce:	48 83 fd 18          	cmp    $0x18,%rbp
    61d2:	76 1b                	jbe    61ef <fwp_data.part.0.constprop.0+0x8f>
    61d4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    61d8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    61dc:	31 f6                	xor    %esi,%esi
    61de:	48 c1 e8 03          	shr    $0x3,%rax
    61e2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    61e9:	00 
    61ea:	e8 c1 d2 ff ff       	call   34b0 <memset@plt>
    61ef:	48 89 e8             	mov    %rbp,%rax
    61f2:	48 03 05 67 6a 06 00 	add    0x66a67(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    61f9:	0f 82 3d 01 00 00    	jb     633c <fwp_data.part.0.constprop.0+0x1dc>
    61ff:	48 39 05 62 6a 06 00 	cmp    %rax,0x66a62(%rip)        # 6cc68 <fwp_heap+0x1428>
    6206:	48 89 05 53 6a 06 00 	mov    %rax,0x66a53(%rip)        # 6cc60 <fwp_heap+0x1420>
    620d:	73 07                	jae    6216 <fwp_data.part.0.constprop.0+0xb6>
    620f:	48 89 05 52 6a 06 00 	mov    %rax,0x66a52(%rip)        # 6cc68 <fwp_heap+0x1428>
    6216:	66 0f ef c0          	pxor   %xmm0,%xmm0
    621a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    621f:	f2 0f 58 05 51 6a 06 	addsd  0x66a51(%rip),%xmm0        # 6cc78 <fwp_heap+0x1438>
    6226:	00 
    6227:	f2 0f 11 05 49 6a 06 	movsd  %xmm0,0x66a49(%rip)        # 6cc78 <fwp_heap+0x1438>
    622e:	00 
    622f:	45 85 ed             	test   %r13d,%r13d
    6232:	74 33                	je     6267 <fwp_data.part.0.constprop.0+0x107>
    6234:	48 8b 05 25 6a 06 00 	mov    0x66a25(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    623b:	48 85 c0             	test   %rax,%rax
    623e:	0f 88 a4 00 00 00    	js     62e8 <fwp_data.part.0.constprop.0+0x188>
    6244:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6248:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    624d:	f2 0f 5c 05 93 72 06 	subsd  0x67293(%rip),%xmm0        # 6d4e8 <iteration_start_charge>
    6254:	00 
    6255:	66 0f 2f 05 83 72 06 	comisd 0x67283(%rip),%xmm0        # 6d4e0 <iteration_peak>
    625c:	00 
    625d:	76 08                	jbe    6267 <fwp_data.part.0.constprop.0+0x107>
    625f:	f2 0f 11 05 79 72 06 	movsd  %xmm0,0x67279(%rip)        # 6d4e0 <iteration_peak>
    6266:	00 
    6267:	b8 02 00 00 00       	mov    $0x2,%eax
    626c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6271:	66 0f 6e c8          	movd   %eax,%xmm1
    6275:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6279:	66 0f d6 03          	movq   %xmm0,(%rbx)
    627d:	49 8b 04 24          	mov    (%r12),%rax
    6281:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6285:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    628a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    628e:	48 89 d8             	mov    %rbx,%rax
    6291:	5b                   	pop    %rbx
    6292:	5d                   	pop    %rbp
    6293:	41 5c                	pop    %r12
    6295:	41 5d                	pop    %r13
    6297:	41 5e                	pop    %r14
    6299:	c3                   	ret
    629a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62a0:	85 c0                	test   %eax,%eax
    62a2:	0f 85 f4 fe ff ff    	jne    619c <fwp_data.part.0.constprop.0+0x3c>
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 bc fc ff ff       	call   5f70 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	eb ae                	jmp    6267 <fwp_data.part.0.constprop.0+0x107>
    62b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62c0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    62c4:	48 85 db             	test   %rbx,%rbx
    62c7:	74 47                	je     6310 <fwp_data.part.0.constprop.0+0x1b0>
    62c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    62cd:	48 29 da             	sub    %rbx,%rdx
    62d0:	48 39 ea             	cmp    %rbp,%rdx
    62d3:	72 3b                	jb     6310 <fwp_data.part.0.constprop.0+0x1b0>
    62d5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    62d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    62dd:	e9 ec fe ff ff       	jmp    61ce <fwp_data.part.0.constprop.0+0x6e>
    62e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62e8:	48 89 c2             	mov    %rax,%rdx
    62eb:	83 e0 01             	and    $0x1,%eax
    62ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
    62f2:	48 d1 ea             	shr    $1,%rdx
    62f5:	48 09 c2             	or     %rax,%rdx
    62f8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    62fd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6301:	e9 47 ff ff ff       	jmp    624d <fwp_data.part.0.constprop.0+0xed>
    6306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    630d:	00 00 00 
    6310:	31 f6                	xor    %esi,%esi
    6312:	bf 18 00 00 00       	mov    $0x18,%edi
    6317:	e8 54 fc ff ff       	call   5f70 <fwp_heap_alloc>
    631c:	48 89 c3             	mov    %rax,%rbx
    631f:	e9 0b ff ff ff       	jmp    622f <fwp_data.part.0.constprop.0+0xcf>
    6324:	0f 1f 40 00          	nopl   0x0(%rax)
    6328:	31 f6                	xor    %esi,%esi
    632a:	bf 18 00 00 00       	mov    $0x18,%edi
    632f:	e8 3c fc ff ff       	call   5f70 <fwp_heap_alloc>
    6334:	48 89 c3             	mov    %rax,%rbx
    6337:	e9 f8 fe ff ff       	jmp    6234 <fwp_data.part.0.constprop.0+0xd4>
    633c:	e8 ef da ff ff       	call   3e30 <fwp_heap_oom>
    6341:	0f 1f 40 00          	nopl   0x0(%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 71 01 00 00    	jns    64f8 <fwp_p_ad_push+0x1a8>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 6e 02 00 00    	jne    663b <fwp_p_ad_push+0x2eb>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 51 02 00 00    	jg     662f <fwp_p_ad_push+0x2df>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	4c 39 f8             	cmp    %r15,%rax
    63e4:	0f 8d 39 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	4c 39 f8             	cmp    %r15,%rax
    63f5:	0f 8d 28 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 1d 02 00 00    	ja     662f <fwp_p_ad_push+0x2df>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 82 ed ff ff       	call   51f0 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 d0 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 ee             	mov    %rbp,%rsi
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e6 04          	shl    $0x4,%rsi
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	ba 02 00 00 00       	mov    $0x2,%edx
    6493:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6497:	e8 54 ed ff ff       	call   51f0 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 a2 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64ad:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b4:	00 
    64b5:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bc:	00 
    64bd:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c4:	00 
    64c5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64c9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ce:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d6:	4d 85 f6             	test   %r14,%r14
    64d9:	0f 85 e5 00 00 00    	jne    65c4 <fwp_p_ad_push+0x274>
    64df:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64e7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64eb:	48 01 d1             	add    %rdx,%rcx
    64ee:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f2:	eb 7c                	jmp    6570 <fwp_p_ad_push+0x220>
    64f4:	0f 1f 40 00          	nopl   0x0(%rax)
    64f8:	48 89 d0             	mov    %rdx,%rax
    64fb:	48 c1 ff 20          	sar    $0x20,%rdi
    64ff:	48 c1 f8 20          	sar    $0x20,%rax
    6503:	48 39 c7             	cmp    %rax,%rdi
    6506:	0f 84 ab fe ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    650c:	48 8d 3d 05 95 00 00 	lea    0x9505(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    6513:	e8 38 df ff ff       	call   4450 <fwp_trap>
    6518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    651f:	00 
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	4c 89 ca             	mov    %r9,%rdx
    65c7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65cc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65d6:	e8 15 d0 ff ff       	call   35f0 <memmove@plt>
    65db:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65e9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65ed:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65f6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fa:	4c 89 d2             	mov    %r10,%rdx
    65fd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6602:	e8 e9 cf ff ff       	call   35f0 <memmove@plt>
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    660f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6614:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6619:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    661e:	e9 c0 fe ff ff       	jmp    64e3 <fwp_p_ad_push+0x193>
    6623:	48 8d 3d 98 8b 00 00 	lea    0x8b98(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    662a:	e8 21 de ff ff       	call   4450 <fwp_trap>
    662f:	48 8d 3d 71 8b 00 00 	lea    0x8b71(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    6636:	e8 15 de ff ff       	call   4450 <fwp_trap>
    663b:	48 8d 3d 1e 94 00 00 	lea    0x941e(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    6642:	e8 09 de ff ff       	call   4450 <fwp_trap>
    6647:	48 89 df             	mov    %rbx,%rdi
    664a:	e8 41 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    664f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6653:	48 85 ff             	test   %rdi,%rdi
    6656:	74 05                	je     665d <fwp_p_ad_push+0x30d>
    6658:	e8 d3 ea ff ff       	call   5130 <ad_raw_free.part.0>
    665d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6661:	48 85 ff             	test   %rdi,%rdi
    6664:	74 05                	je     666b <fwp_p_ad_push+0x31b>
    6666:	e8 c5 ea ff ff       	call   5130 <ad_raw_free.part.0>
    666b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    666f:	48 85 ff             	test   %rdi,%rdi
    6672:	74 05                	je     6679 <fwp_p_ad_push+0x329>
    6674:	e8 b7 ea ff ff       	call   5130 <ad_raw_free.part.0>
    6679:	31 c9                	xor    %ecx,%ecx
    667b:	31 c0                	xor    %eax,%eax
    667d:	31 d2                	xor    %edx,%edx
    667f:	be 01 00 00 00       	mov    $0x1,%esi
    6684:	89 53 04             	mov    %edx,0x4(%rbx)
    6687:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668b:	ba 13 00 00 00       	mov    $0x13,%edx
    6690:	48 8d 3d 71 89 00 00 	lea    0x8971(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6697:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    669b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    669f:	48 8b 0d 9a c9 00 00 	mov    0xc99a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    66a6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66aa:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66ae:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66b2:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66b6:	e8 a5 cf ff ff       	call   3660 <fwrite@plt>
    66bb:	31 ff                	xor    %edi,%edi
    66bd:	e8 de ce ff ff       	call   35a0 <fflush@plt>
    66c2:	bf 66 00 00 00       	mov    $0x66,%edi
    66c7:	e8 b4 cf ff ff       	call   3680 <_Exit@plt>
    66cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066d0 <w120>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66ff:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push>
    670a:	48 89 c7             	mov    %rax,%rdi
    670d:	e8 ae e8 ff ff       	call   4fc0 <caf75>
    6712:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6717:	e8 a4 e8 ff ff       	call   4fc0 <caf75>
    671c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6722:	66 0f 57 05 c6 96 00 	xorpd  0x96c6(%rip),%xmm0        # fdf0 <msg.8+0xb0>
    6729:	00 
    672a:	48 89 da             	mov    %rbx,%rdx
    672d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6733:	48 89 c1             	mov    %rax,%rcx
    6736:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    673b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6740:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6746:	e8 05 fc ff ff       	call   6350 <fwp_p_ad_push>
    674b:	4c 89 e7             	mov    %r12,%rdi
    674e:	49 89 c5             	mov    %rax,%r13
    6751:	e8 6a e8 ff ff       	call   4fc0 <caf75>
    6756:	48 89 c6             	mov    %rax,%rsi
    6759:	e8 62 e8 ff ff       	call   4fc0 <caf75>
    675e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6763:	f2 0f 10 05 fd 95 00 	movsd  0x95fd(%rip),%xmm0        # fd68 <msg.8+0x28>
    676a:	00 
    676b:	66 0f 57 15 7d 96 00 	xorpd  0x967d(%rip),%xmm2        # fdf0 <msg.8+0xb0>
    6772:	00 
    6773:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6779:	48 89 c1             	mov    %rax,%rcx
    677c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6783:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6788:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    678d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6793:	e8 b8 fb ff ff       	call   6350 <fwp_p_ad_push>
    6798:	48 89 e9             	mov    %rbp,%rcx
    679b:	4c 89 ea             	mov    %r13,%rdx
    679e:	48 89 ee             	mov    %rbp,%rsi
    67a1:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    67a7:	4c 89 ef             	mov    %r13,%rdi
    67aa:	49 89 c4             	mov    %rax,%r12
    67ad:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    67b1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67b7:	e8 94 fb ff ff       	call   6350 <fwp_p_ad_push>
    67bc:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67c2:	f2 0f 59 1d a6 95 00 	mulsd  0x95a6(%rip),%xmm3        # fd70 <msg.8+0x30>
    67c9:	00 
    67ca:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67d1:	00 59 40 
    67d4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67d9:	48 89 c2             	mov    %rax,%rdx
    67dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67e3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67e9:	e8 62 fb ff ff       	call   6350 <fwp_p_ad_push>
    67ee:	4c 89 e2             	mov    %r12,%rdx
    67f1:	48 89 d9             	mov    %rbx,%rcx
    67f4:	48 89 de             	mov    %rbx,%rsi
    67f7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67fd:	4c 89 e7             	mov    %r12,%rdi
    6800:	48 89 c5             	mov    %rax,%rbp
    6803:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6807:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    680d:	e8 3e fb ff ff       	call   6350 <fwp_p_ad_push>
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	e8 a6 e7 ff ff       	call   4fc0 <caf75>
    681a:	48 89 c6             	mov    %rax,%rsi
    681d:	e8 9e e7 ff ff       	call   4fc0 <caf75>
    6822:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6828:	48 89 ea             	mov    %rbp,%rdx
    682b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6831:	48 89 c1             	mov    %rax,%rcx
    6834:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6839:	e8 12 fb ff ff       	call   6350 <fwp_p_ad_push>
    683e:	48 83 c4 28          	add    $0x28,%rsp
    6842:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6847:	5b                   	pop    %rbx
    6848:	5d                   	pop    %rbp
    6849:	41 5c                	pop    %r12
    684b:	41 5d                	pop    %r13
    684d:	c3                   	ret
    684e:	66 90                	xchg   %ax,%ax

0000000000006850 <w176.constprop.0>:
    6850:	41 54                	push   %r12
    6852:	55                   	push   %rbp
    6853:	53                   	push   %rbx
    6854:	48 83 ec 10          	sub    $0x10,%rsp
    6858:	4c 8b 27             	mov    (%rdi),%r12
    685b:	4d 85 e4             	test   %r12,%r12
    685e:	74 78                	je     68d8 <w176.constprop.0+0x88>
    6860:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6867:	00 00 
    6869:	48 89 fd             	mov    %rdi,%rbp
    686c:	31 db                	xor    %ebx,%ebx
    686e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    687c:	00 00 00 00 
    6880:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6885:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    688b:	48 83 c3 02          	add    $0x2,%rbx
    688f:	e8 2c e7 ff ff       	call   4fc0 <caf75>
    6894:	48 89 c6             	mov    %rax,%rsi
    6897:	e8 24 e7 ff ff       	call   4fc0 <caf75>
    689c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    68a2:	4c 89 c2             	mov    %r8,%rdx
    68a5:	48 89 c1             	mov    %rax,%rcx
    68a8:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    68ae:	e8 9d fa ff ff       	call   6350 <fwp_p_ad_push>
    68b3:	48 89 c7             	mov    %rax,%rdi
    68b6:	4c 39 e3             	cmp    %r12,%rbx
    68b9:	72 c5                	jb     6880 <w176.constprop.0+0x30>
    68bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68c0:	48 83 c4 10          	add    $0x10,%rsp
    68c4:	5b                   	pop    %rbx
    68c5:	5d                   	pop    %rbp
    68c6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    68cb:	41 5c                	pop    %r12
    68cd:	48 89 f8             	mov    %rdi,%rax
    68d0:	c3                   	ret
    68d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68d8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    68df:	00 00 
    68e1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68e8:	eb d1                	jmp    68bb <w176.constprop.0+0x6b>
    68ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000068f0 <fwp_rc_share>:
    68f0:	48 8b 05 21 63 06 00 	mov    0x66321(%rip),%rax        # 6cc18 <fwp_heap+0x13d8>
    68f7:	48 2b 3d f2 62 06 00 	sub    0x662f2(%rip),%rdi        # 6cbf0 <fwp_heap+0x13b0>
    68fe:	48 c1 e0 10          	shl    $0x10,%rax
    6902:	48 39 c7             	cmp    %rax,%rdi
    6905:	73 4a                	jae    6951 <fwp_rc_share+0x61>
    6907:	48 89 f8             	mov    %rdi,%rax
    690a:	48 c1 e8 10          	shr    $0x10,%rax
    690e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6912:	48 8b 05 1f 63 06 00 	mov    0x6631f(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    6919:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    691d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6921:	48 85 d2             	test   %rdx,%rdx
    6924:	74 2b                	je     6951 <fwp_rc_share+0x61>
    6926:	0f b6 08             	movzbl (%rax),%ecx
    6929:	80 f9 02             	cmp    $0x2,%cl
    692c:	74 2a                	je     6958 <fwp_rc_share+0x68>
    692e:	80 f9 01             	cmp    $0x1,%cl
    6931:	75 1e                	jne    6951 <fwp_rc_share+0x61>
    6933:	8b 48 18             	mov    0x18(%rax),%ecx
    6936:	0f b7 ff             	movzwl %di,%edi
    6939:	8b 40 1c             	mov    0x1c(%rax),%eax
    693c:	48 0f af f9          	imul   %rcx,%rdi
    6940:	48 c1 ef 20          	shr    $0x20,%rdi
    6944:	48 39 c7             	cmp    %rax,%rdi
    6947:	73 08                	jae    6951 <fwp_rc_share+0x61>
    6949:	48 01 fa             	add    %rdi,%rdx
    694c:	80 3a 00             	cmpb   $0x0,(%rdx)
    694f:	75 0d                	jne    695e <fwp_rc_share+0x6e>
    6951:	c3                   	ret
    6952:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6958:	66 85 ff             	test   %di,%di
    695b:	74 ef                	je     694c <fwp_rc_share+0x5c>
    695d:	c3                   	ret
    695e:	50                   	push   %rax
    695f:	48 8d 3d 2a 91 00 00 	lea    0x912a(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    6966:	e8 e5 da ff ff       	call   4450 <fwp_trap>
    696b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006970 <fwp_rc_fresh>:
    6970:	48 8b 15 a1 62 06 00 	mov    0x662a1(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    6977:	48 89 f8             	mov    %rdi,%rax
    697a:	48 89 fe             	mov    %rdi,%rsi
    697d:	48 2b 05 6c 62 06 00 	sub    0x6626c(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    6984:	48 c1 e2 10          	shl    $0x10,%rdx
    6988:	48 39 d0             	cmp    %rdx,%rax
    698b:	73 4f                	jae    69dc <fwp_rc_fresh+0x6c>
    698d:	48 89 c2             	mov    %rax,%rdx
    6990:	48 c1 ea 10          	shr    $0x10,%rdx
    6994:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6998:	48 8b 15 99 62 06 00 	mov    0x66299(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    699f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69a3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69a7:	48 85 d2             	test   %rdx,%rdx
    69aa:	74 30                	je     69dc <fwp_rc_fresh+0x6c>
    69ac:	0f b6 39             	movzbl (%rcx),%edi
    69af:	40 80 ff 02          	cmp    $0x2,%dil
    69b3:	74 2b                	je     69e0 <fwp_rc_fresh+0x70>
    69b5:	40 80 ff 01          	cmp    $0x1,%dil
    69b9:	75 21                	jne    69dc <fwp_rc_fresh+0x6c>
    69bb:	8b 79 18             	mov    0x18(%rcx),%edi
    69be:	0f b7 c0             	movzwl %ax,%eax
    69c1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69c4:	48 0f af c7          	imul   %rdi,%rax
    69c8:	48 c1 e8 20          	shr    $0x20,%rax
    69cc:	48 39 c8             	cmp    %rcx,%rax
    69cf:	73 0b                	jae    69dc <fwp_rc_fresh+0x6c>
    69d1:	48 01 c2             	add    %rax,%rdx
    69d4:	80 3a ff             	cmpb   $0xff,(%rdx)
    69d7:	74 17                	je     69f0 <fwp_rc_fresh+0x80>
    69d9:	c6 02 01             	movb   $0x1,(%rdx)
    69dc:	48 89 f0             	mov    %rsi,%rax
    69df:	c3                   	ret
    69e0:	66 85 c0             	test   %ax,%ax
    69e3:	74 ef                	je     69d4 <fwp_rc_fresh+0x64>
    69e5:	48 89 f0             	mov    %rsi,%rax
    69e8:	c3                   	ret
    69e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69f0:	48 83 ec 18          	sub    $0x18,%rsp
    69f4:	48 89 d7             	mov    %rdx,%rdi
    69f7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    69fc:	48 89 14 24          	mov    %rdx,(%rsp)
    6a00:	e8 2b ee ff ff       	call   5830 <fwp_rc_forget_slot>
    6a05:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6a0a:	48 8b 14 24          	mov    (%rsp),%rdx
    6a0e:	48 89 f0             	mov    %rsi,%rax
    6a11:	c6 02 01             	movb   $0x1,(%rdx)
    6a14:	48 83 c4 18          	add    $0x18,%rsp
    6a18:	c3                   	ret
    6a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006a20 <fwp_rc_free_obj>:
    6a20:	48 8b 15 f1 61 06 00 	mov    0x661f1(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    6a27:	48 89 f8             	mov    %rdi,%rax
    6a2a:	48 2b 05 bf 61 06 00 	sub    0x661bf(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    6a31:	48 c1 e2 10          	shl    $0x10,%rdx
    6a35:	48 39 d0             	cmp    %rdx,%rax
    6a38:	73 5b                	jae    6a95 <fwp_rc_free_obj+0x75>
    6a3a:	48 89 c2             	mov    %rax,%rdx
    6a3d:	48 c1 ea 10          	shr    $0x10,%rdx
    6a41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a45:	48 8b 15 ec 61 06 00 	mov    0x661ec(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    6a4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6a50:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6a54:	48 85 c9             	test   %rcx,%rcx
    6a57:	74 3c                	je     6a95 <fwp_rc_free_obj+0x75>
    6a59:	0f b6 32             	movzbl (%rdx),%esi
    6a5c:	40 80 fe 02          	cmp    $0x2,%sil
    6a60:	74 2e                	je     6a90 <fwp_rc_free_obj+0x70>
    6a62:	40 80 fe 01          	cmp    $0x1,%sil
    6a66:	75 2d                	jne    6a95 <fwp_rc_free_obj+0x75>
    6a68:	8b 72 18             	mov    0x18(%rdx),%esi
    6a6b:	0f b7 c0             	movzwl %ax,%eax
    6a6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a71:	48 0f af c6          	imul   %rsi,%rax
    6a75:	48 c1 e8 20          	shr    $0x20,%rax
    6a79:	48 39 d0             	cmp    %rdx,%rax
    6a7c:	73 17                	jae    6a95 <fwp_rc_free_obj+0x75>
    6a7e:	48 01 c1             	add    %rax,%rcx
    6a81:	80 39 01             	cmpb   $0x1,(%rcx)
    6a84:	75 0f                	jne    6a95 <fwp_rc_free_obj+0x75>
    6a86:	e9 e5 ef ff ff       	jmp    5a70 <fwp_mem_free>
    6a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a90:	66 85 c0             	test   %ax,%ax
    6a93:	74 ec                	je     6a81 <fwp_rc_free_obj+0x61>
    6a95:	c3                   	ret
    6a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a9d:	00 00 00 

0000000000006aa0 <fwp_rc_dup>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	48 8b 05 6d 61 06 00 	mov    0x6616d(%rip),%rax        # 6cc18 <fwp_heap+0x13d8>
    6aab:	48 2b 3d 3e 61 06 00 	sub    0x6613e(%rip),%rdi        # 6cbf0 <fwp_heap+0x13b0>
    6ab2:	48 c1 e0 10          	shl    $0x10,%rax
    6ab6:	48 39 c7             	cmp    %rax,%rdi
    6ab9:	73 60                	jae    6b1b <fwp_rc_dup+0x7b>
    6abb:	48 89 f8             	mov    %rdi,%rax
    6abe:	48 c1 e8 10          	shr    $0x10,%rax
    6ac2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ac6:	48 8b 05 6b 61 06 00 	mov    0x6616b(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    6acd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6ad1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6ad5:	48 85 c0             	test   %rax,%rax
    6ad8:	74 41                	je     6b1b <fwp_rc_dup+0x7b>
    6ada:	0f b6 0a             	movzbl (%rdx),%ecx
    6add:	80 f9 02             	cmp    $0x2,%cl
    6ae0:	74 3e                	je     6b20 <fwp_rc_dup+0x80>
    6ae2:	80 f9 01             	cmp    $0x1,%cl
    6ae5:	75 34                	jne    6b1b <fwp_rc_dup+0x7b>
    6ae7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6aea:	0f b7 ff             	movzwl %di,%edi
    6aed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6af0:	48 0f af f9          	imul   %rcx,%rdi
    6af4:	48 c1 ef 20          	shr    $0x20,%rdi
    6af8:	48 39 d7             	cmp    %rdx,%rdi
    6afb:	73 1e                	jae    6b1b <fwp_rc_dup+0x7b>
    6afd:	48 01 f8             	add    %rdi,%rax
    6b00:	0f b6 10             	movzbl (%rax),%edx
    6b03:	84 d2                	test   %dl,%dl
    6b05:	74 14                	je     6b1b <fwp_rc_dup+0x7b>
    6b07:	8b 0d fb 69 06 00    	mov    0x669fb(%rip),%ecx        # 6d508 <iteration_active>
    6b0d:	85 c9                	test   %ecx,%ecx
    6b0f:	75 1f                	jne    6b30 <fwp_rc_dup+0x90>
    6b11:	80 fa fd             	cmp    $0xfd,%dl
    6b14:	77 2a                	ja     6b40 <fwp_rc_dup+0xa0>
    6b16:	83 c2 01             	add    $0x1,%edx
    6b19:	88 10                	mov    %dl,(%rax)
    6b1b:	c3                   	ret
    6b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    6b20:	66 85 ff             	test   %di,%di
    6b23:	74 db                	je     6b00 <fwp_rc_dup+0x60>
    6b25:	c3                   	ret
    6b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b2d:	00 00 00 
    6b30:	48 83 05 b8 69 06 00 	addq   $0x1,0x669b8(%rip)        # 6d4f0 <iteration_retains>
    6b37:	01 
    6b38:	eb d7                	jmp    6b11 <fwp_rc_dup+0x71>
    6b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b40:	48 89 c7             	mov    %rax,%rdi
    6b43:	e9 c8 eb ff ff       	jmp    5710 <fwp_rc_wide_dup>
    6b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b4f:	00 

0000000000006b50 <fwp_owned_entry173>:
    6b50:	f3 0f 1e fa          	endbr64
    6b54:	48 83 ec 38          	sub    $0x38,%rsp
    6b58:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b5d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b64:	00 00 
    6b66:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b6b:	31 c0                	xor    %eax,%eax
    6b6d:	48 8b 07             	mov    (%rdi),%rax
    6b70:	48 03 47 10          	add    0x10(%rdi),%rax
    6b74:	0f 80 c2 00 00 00    	jo     6c3c <fwp_owned_entry173+0xec>
    6b7a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b7f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b84:	31 ff                	xor    %edi,%edi
    6b86:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b8a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b8f:	e8 cc f5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    6b94:	48 8b 15 7d 60 06 00 	mov    0x6607d(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    6b9b:	48 89 c6             	mov    %rax,%rsi
    6b9e:	48 2b 05 4b 60 06 00 	sub    0x6604b(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    6ba5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba9:	48 39 d0             	cmp    %rdx,%rax
    6bac:	73 4f                	jae    6bfd <fwp_owned_entry173+0xad>
    6bae:	48 89 c2             	mov    %rax,%rdx
    6bb1:	48 c1 ea 10          	shr    $0x10,%rdx
    6bb5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bb9:	48 8b 15 78 60 06 00 	mov    0x66078(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    6bc0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bc4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bc8:	48 85 d2             	test   %rdx,%rdx
    6bcb:	74 30                	je     6bfd <fwp_owned_entry173+0xad>
    6bcd:	0f b6 39             	movzbl (%rcx),%edi
    6bd0:	40 80 ff 02          	cmp    $0x2,%dil
    6bd4:	74 42                	je     6c18 <fwp_owned_entry173+0xc8>
    6bd6:	40 80 ff 01          	cmp    $0x1,%dil
    6bda:	75 21                	jne    6bfd <fwp_owned_entry173+0xad>
    6bdc:	8b 79 18             	mov    0x18(%rcx),%edi
    6bdf:	0f b7 c0             	movzwl %ax,%eax
    6be2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6be5:	48 0f af c7          	imul   %rdi,%rax
    6be9:	48 c1 e8 20          	shr    $0x20,%rax
    6bed:	48 39 c8             	cmp    %rcx,%rax
    6bf0:	73 0b                	jae    6bfd <fwp_owned_entry173+0xad>
    6bf2:	48 01 c2             	add    %rax,%rdx
    6bf5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6bf8:	74 26                	je     6c20 <fwp_owned_entry173+0xd0>
    6bfa:	c6 02 01             	movb   $0x1,(%rdx)
    6bfd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c09:	00 00 
    6c0b:	75 34                	jne    6c41 <fwp_owned_entry173+0xf1>
    6c0d:	48 89 f0             	mov    %rsi,%rax
    6c10:	48 83 c4 38          	add    $0x38,%rsp
    6c14:	c3                   	ret
    6c15:	0f 1f 00             	nopl   (%rax)
    6c18:	66 85 c0             	test   %ax,%ax
    6c1b:	75 e0                	jne    6bfd <fwp_owned_entry173+0xad>
    6c1d:	eb d6                	jmp    6bf5 <fwp_owned_entry173+0xa5>
    6c1f:	90                   	nop
    6c20:	48 89 d7             	mov    %rdx,%rdi
    6c23:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6c28:	48 89 14 24          	mov    %rdx,(%rsp)
    6c2c:	e8 ff eb ff ff       	call   5830 <fwp_rc_forget_slot>
    6c31:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6c36:	48 8b 14 24          	mov    (%rsp),%rdx
    6c3a:	eb be                	jmp    6bfa <fwp_owned_entry173+0xaa>
    6c3c:	e8 bf ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c41:	e8 0a c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c4d:	00 00 00 

0000000000006c50 <e173>:
    6c50:	f3 0f 1e fa          	endbr64
    6c54:	53                   	push   %rbx
    6c55:	48 83 ec 30          	sub    $0x30,%rsp
    6c59:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c5e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c65:	00 00 
    6c67:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6c6c:	31 c0                	xor    %eax,%eax
    6c6e:	48 8b 07             	mov    (%rdi),%rax
    6c71:	48 03 47 10          	add    0x10(%rdi),%rax
    6c75:	0f 80 c9 00 00 00    	jo     6d44 <e173+0xf4>
    6c7b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c80:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c85:	31 ff                	xor    %edi,%edi
    6c87:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c8b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c90:	e8 cb f4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    6c95:	48 8b 15 7c 5f 06 00 	mov    0x65f7c(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    6c9c:	48 89 c3             	mov    %rax,%rbx
    6c9f:	48 2b 05 4a 5f 06 00 	sub    0x65f4a(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    6ca6:	48 c1 e2 10          	shl    $0x10,%rdx
    6caa:	48 39 d0             	cmp    %rdx,%rax
    6cad:	73 4f                	jae    6cfe <e173+0xae>
    6caf:	48 89 c2             	mov    %rax,%rdx
    6cb2:	48 c1 ea 10          	shr    $0x10,%rdx
    6cb6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cba:	48 8b 15 77 5f 06 00 	mov    0x65f77(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    6cc1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6cc5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6cc9:	48 85 d2             	test   %rdx,%rdx
    6ccc:	74 30                	je     6cfe <e173+0xae>
    6cce:	0f b6 31             	movzbl (%rcx),%esi
    6cd1:	40 80 fe 02          	cmp    $0x2,%sil
    6cd5:	74 49                	je     6d20 <e173+0xd0>
    6cd7:	40 80 fe 01          	cmp    $0x1,%sil
    6cdb:	75 21                	jne    6cfe <e173+0xae>
    6cdd:	8b 71 18             	mov    0x18(%rcx),%esi
    6ce0:	0f b7 c0             	movzwl %ax,%eax
    6ce3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ce6:	48 0f af c6          	imul   %rsi,%rax
    6cea:	48 c1 e8 20          	shr    $0x20,%rax
    6cee:	48 39 c8             	cmp    %rcx,%rax
    6cf1:	73 0b                	jae    6cfe <e173+0xae>
    6cf3:	48 01 c2             	add    %rax,%rdx
    6cf6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6cf9:	74 35                	je     6d30 <e173+0xe0>
    6cfb:	c6 02 01             	movb   $0x1,(%rdx)
    6cfe:	48 89 df             	mov    %rbx,%rdi
    6d01:	e8 ea fb ff ff       	call   68f0 <fwp_rc_share>
    6d06:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d0b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d12:	00 00 
    6d14:	75 33                	jne    6d49 <e173+0xf9>
    6d16:	48 83 c4 30          	add    $0x30,%rsp
    6d1a:	48 89 d8             	mov    %rbx,%rax
    6d1d:	5b                   	pop    %rbx
    6d1e:	c3                   	ret
    6d1f:	90                   	nop
    6d20:	66 85 c0             	test   %ax,%ax
    6d23:	75 d9                	jne    6cfe <e173+0xae>
    6d25:	eb cf                	jmp    6cf6 <e173+0xa6>
    6d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d2e:	00 00 
    6d30:	48 89 d7             	mov    %rdx,%rdi
    6d33:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d38:	e8 f3 ea ff ff       	call   5830 <fwp_rc_forget_slot>
    6d3d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d42:	eb b7                	jmp    6cfb <e173+0xab>
    6d44:	e8 b7 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d49:	e8 02 c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6d4e:	66 90                	xchg   %ax,%ax

0000000000006d50 <fwp_closure_drop>:
    6d50:	48 8b 15 c1 5e 06 00 	mov    0x65ec1(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    6d57:	48 89 f8             	mov    %rdi,%rax
    6d5a:	48 2b 05 8f 5e 06 00 	sub    0x65e8f(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    6d61:	48 c1 e2 10          	shl    $0x10,%rdx
    6d65:	48 39 d0             	cmp    %rdx,%rax
    6d68:	73 6b                	jae    6dd5 <fwp_closure_drop+0x85>
    6d6a:	48 89 c2             	mov    %rax,%rdx
    6d6d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d75:	48 8b 15 bc 5e 06 00 	mov    0x65ebc(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    6d7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d84:	48 85 d2             	test   %rdx,%rdx
    6d87:	74 4c                	je     6dd5 <fwp_closure_drop+0x85>
    6d89:	0f b6 31             	movzbl (%rcx),%esi
    6d8c:	40 80 fe 02          	cmp    $0x2,%sil
    6d90:	74 3e                	je     6dd0 <fwp_closure_drop+0x80>
    6d92:	40 80 fe 01          	cmp    $0x1,%sil
    6d96:	75 3d                	jne    6dd5 <fwp_closure_drop+0x85>
    6d98:	8b 71 18             	mov    0x18(%rcx),%esi
    6d9b:	0f b7 c0             	movzwl %ax,%eax
    6d9e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6da1:	48 0f af c6          	imul   %rsi,%rax
    6da5:	48 c1 e8 20          	shr    $0x20,%rax
    6da9:	48 39 c8             	cmp    %rcx,%rax
    6dac:	73 27                	jae    6dd5 <fwp_closure_drop+0x85>
    6dae:	48 01 c2             	add    %rax,%rdx
    6db1:	0f b6 02             	movzbl (%rdx),%eax
    6db4:	84 c0                	test   %al,%al
    6db6:	74 1d                	je     6dd5 <fwp_closure_drop+0x85>
    6db8:	3c 01                	cmp    $0x1,%al
    6dba:	74 24                	je     6de0 <fwp_closure_drop+0x90>
    6dbc:	3c ff                	cmp    $0xff,%al
    6dbe:	74 48                	je     6e08 <fwp_closure_drop+0xb8>
    6dc0:	83 e8 01             	sub    $0x1,%eax
    6dc3:	88 02                	mov    %al,(%rdx)
    6dc5:	c3                   	ret
    6dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dcd:	00 00 00 
    6dd0:	66 85 c0             	test   %ax,%ax
    6dd3:	74 dc                	je     6db1 <fwp_closure_drop+0x61>
    6dd5:	c3                   	ret
    6dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ddd:	00 00 00 
    6de0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6de7:	ff ff 
    6de9:	48 85 c0             	test   %rax,%rax
    6dec:	74 12                	je     6e00 <fwp_closure_drop+0xb0>
    6dee:	48 89 fe             	mov    %rdi,%rsi
    6df1:	48 89 c7             	mov    %rax,%rdi
    6df4:	e9 b7 d6 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e00:	e9 5b d8 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6e05:	0f 1f 00             	nopl   (%rax)
    6e08:	48 89 d0             	mov    %rdx,%rax
    6e0b:	48 8d 35 2e 4a 06 00 	lea    0x64a2e(%rip),%rsi        # 6b840 <fwp_heap>
    6e12:	48 83 ec 18          	sub    $0x18,%rsp
    6e16:	48 c1 e8 11          	shr    $0x11,%rax
    6e1a:	48 31 d0             	xor    %rdx,%rax
    6e1d:	48 89 c1             	mov    %rax,%rcx
    6e20:	48 c1 e9 09          	shr    $0x9,%rcx
    6e24:	48 31 c8             	xor    %rcx,%rax
    6e27:	0f b6 c8             	movzbl %al,%ecx
    6e2a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6e31:	00 
    6e32:	48 85 c0             	test   %rax,%rax
    6e35:	75 12                	jne    6e49 <fwp_closure_drop+0xf9>
    6e37:	eb 49                	jmp    6e82 <fwp_closure_drop+0x132>
    6e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	74 39                	je     6e82 <fwp_closure_drop+0x132>
    6e49:	48 89 c1             	mov    %rax,%rcx
    6e4c:	48 39 10             	cmp    %rdx,(%rax)
    6e4f:	75 ef                	jne    6e40 <fwp_closure_drop+0xf0>
    6e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e64:	74 05                	je     6e6b <fwp_closure_drop+0x11b>
    6e66:	48 83 c4 18          	add    $0x18,%rsp
    6e6a:	c3                   	ret
    6e6b:	48 89 d7             	mov    %rdx,%rdi
    6e6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e73:	e8 b8 e9 ff ff       	call   5830 <fwp_rc_forget_slot>
    6e78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e80:	eb e4                	jmp    6e66 <fwp_closure_drop+0x116>
    6e82:	48 8d 3d 67 8b 00 00 	lea    0x8b67(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    6e89:	e8 c2 d5 ff ff       	call   4450 <fwp_trap>
    6e8e:	66 90                	xchg   %ax,%ax

0000000000006e90 <fwp_owned_tape_release>:
    6e90:	48 85 ff             	test   %rdi,%rdi
    6e93:	0f 84 f7 00 00 00    	je     6f90 <fwp_owned_tape_release+0x100>
    6e99:	41 54                	push   %r12
    6e9b:	55                   	push   %rbp
    6e9c:	53                   	push   %rbx
    6e9d:	48 8b 07             	mov    (%rdi),%rax
    6ea0:	48 85 c0             	test   %rax,%rax
    6ea3:	74 08                	je     6ead <fwp_owned_tape_release+0x1d>
    6ea5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ea9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ead:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6eb1:	48 85 d2             	test   %rdx,%rdx
    6eb4:	74 03                	je     6eb9 <fwp_owned_tape_release+0x29>
    6eb6:	48 89 02             	mov    %rax,(%rdx)
    6eb9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ebd:	48 89 fb             	mov    %rdi,%rbx
    6ec0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	0f 84 89 00 00 00    	je     6f56 <fwp_owned_tape_release+0xc6>
    6ecd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6ed1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6ed5:	7e 47                	jle    6f1e <fwp_owned_tape_release+0x8e>
    6ed7:	31 ed                	xor    %ebp,%ebp
    6ed9:	eb 0d                	jmp    6ee8 <fwp_owned_tape_release+0x58>
    6edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ee0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ee4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ee8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6eec:	49 89 ec             	mov    %rbp,%r12
    6eef:	48 83 c5 01          	add    $0x1,%rbp
    6ef3:	49 c1 e4 04          	shl    $0x4,%r12
    6ef7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6efb:	ff d0                	call   *%rax
    6efd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6f06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f0a:	ff 50 68             	call   *0x68(%rax)
    6f0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6f11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6f15:	48 39 e8             	cmp    %rbp,%rax
    6f18:	7f c6                	jg     6ee0 <fwp_owned_tape_release+0x50>
    6f1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f1e:	31 ed                	xor    %ebp,%ebp
    6f20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6f25:	7e 28                	jle    6f4f <fwp_owned_tape_release+0xbf>
    6f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f2e:	00 00 
    6f30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6f34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6f38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6f3c:	74 07                	je     6f45 <fwp_owned_tape_release+0xb5>
    6f3e:	ff 52 68             	call   *0x68(%rdx)
    6f41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f45:	48 83 c5 01          	add    $0x1,%rbp
    6f49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6f4d:	7f e1                	jg     6f30 <fwp_owned_tape_release+0xa0>
    6f4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f53:	ff 52 68             	call   *0x68(%rdx)
    6f56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6f5a:	e8 f1 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6f63:	e8 e8 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6f6c:	e8 df fd ff ff       	call   6d50 <fwp_closure_drop>
    6f71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6f75:	e8 f6 ea ff ff       	call   5a70 <fwp_mem_free>
    6f7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6f7e:	e8 ed ea ff ff       	call   5a70 <fwp_mem_free>
    6f83:	48 89 df             	mov    %rbx,%rdi
    6f86:	5b                   	pop    %rbx
    6f87:	5d                   	pop    %rbp
    6f88:	41 5c                	pop    %r12
    6f8a:	e9 e1 ea ff ff       	jmp    5a70 <fwp_mem_free>
    6f8f:	90                   	nop
    6f90:	c3                   	ret
    6f91:	0f 1f 40 00          	nopl   0x0(%rax)
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 

0000000000006fa0 <fwp_tape_finish>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	41 55                	push   %r13
    6fa6:	41 54                	push   %r12
    6fa8:	55                   	push   %rbp
    6fa9:	53                   	push   %rbx
    6faa:	48 83 ec 48          	sub    $0x48,%rsp
    6fae:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6fb5:	00 00 
    6fb7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6fbc:	48 8d 3d fd c0 01 00 	lea    0x1c0fd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6fc3:	e8 d8 e1 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    6fc8:	48 83 3d 38 c1 01 00 	cmpq   $0x0,0x1c138(%rip)        # 23108 <fwp_ntapes>
    6fcf:	00 
    6fd0:	48 c7 05 cd c0 01 00 	movq   $0x0,0x1c0cd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6fd7:	00 00 00 00 
    6fdb:	7e 79                	jle    7056 <fwp_tape_finish+0xb6>
    6fdd:	45 31 e4             	xor    %r12d,%r12d
    6fe0:	31 ed                	xor    %ebp,%ebp
    6fe2:	0f 1f 00             	nopl   (%rax)
    6fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fec:	00 00 00 00 
    6ff0:	48 8b 1d 19 c1 01 00 	mov    0x1c119(%rip),%rbx        # 23110 <fwp_tapes>
    6ff7:	48 83 c5 01          	add    $0x1,%rbp
    6ffb:	4c 01 e3             	add    %r12,%rbx
    6ffe:	49 83 c4 68          	add    $0x68,%r12
    7002:	48 89 df             	mov    %rbx,%rdi
    7005:	e8 86 cc ff ff       	call   3c90 <fwp_tape_unlink_scope>
    700a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    700f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7014:	48 89 e7             	mov    %rsp,%rdi
    7017:	48 8b 43 40          	mov    0x40(%rbx),%rax
    701b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    701f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7024:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7029:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    702e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7032:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7037:	e8 64 e1 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    703c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7040:	e8 4b fe ff ff       	call   6e90 <fwp_owned_tape_release>
    7045:	48 39 2d bc c0 01 00 	cmp    %rbp,0x1c0bc(%rip)        # 23108 <fwp_ntapes>
    704c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7053:	00 
    7054:	7f 9a                	jg     6ff0 <fwp_tape_finish+0x50>
    7056:	48 8b 3d b3 c0 01 00 	mov    0x1c0b3(%rip),%rdi        # 23110 <fwp_tapes>
    705d:	48 85 ff             	test   %rdi,%rdi
    7060:	74 05                	je     7067 <fwp_tape_finish+0xc7>
    7062:	e8 c9 e0 ff ff       	call   5130 <ad_raw_free.part.0>
    7067:	48 c7 05 9e c0 01 00 	movq   $0x0,0x1c09e(%rip)        # 23110 <fwp_tapes>
    706e:	00 00 00 00 
    7072:	48 c7 05 83 c0 01 00 	movq   $0x0,0x1c083(%rip)        # 23100 <fwp_tapes_cap>
    7079:	00 00 00 00 
    707d:	48 c7 05 80 c0 01 00 	movq   $0x0,0x1c080(%rip)        # 23108 <fwp_ntapes>
    7084:	00 00 00 00 
    7088:	48 c7 05 65 c0 01 00 	movq   $0x0,0x1c065(%rip)        # 230f8 <fwp_tape_next_slot>
    708f:	00 00 00 00 
    7093:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7098:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    709f:	00 00 
    70a1:	75 0b                	jne    70ae <fwp_tape_finish+0x10e>
    70a3:	48 83 c4 48          	add    $0x48,%rsp
    70a7:	5b                   	pop    %rbx
    70a8:	5d                   	pop    %rbp
    70a9:	41 5c                	pop    %r12
    70ab:	41 5d                	pop    %r13
    70ad:	c3                   	ret
    70ae:	e8 9d c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    70b3:	66 90                	xchg   %ax,%ax
    70b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70bc:	00 00 00 00 

00000000000070c0 <fwp_tape_scope_release>:
    70c0:	f3 0f 1e fa          	endbr64
    70c4:	41 55                	push   %r13
    70c6:	41 54                	push   %r12
    70c8:	55                   	push   %rbp
    70c9:	53                   	push   %rbx
    70ca:	48 83 ec 48          	sub    $0x48,%rsp
    70ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    70d5:	00 00 
    70d7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    70dc:	48 63 07             	movslq (%rdi),%rax
    70df:	85 c0                	test   %eax,%eax
    70e1:	0f 88 e8 00 00 00    	js     71cf <fwp_tape_scope_release+0x10f>
    70e7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    70ee:	ec c4 4e 
    70f1:	48 89 fb             	mov    %rdi,%rbx
    70f4:	48 89 e5             	mov    %rsp,%rbp
    70f7:	eb 1f                	jmp    7118 <fwp_tape_scope_release+0x58>
    70f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7100:	e8 9b e0 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7105:	4c 89 ef             	mov    %r13,%rdi
    7108:	e8 83 fd ff ff       	call   6e90 <fwp_owned_tape_release>
    710d:	48 63 03             	movslq (%rbx),%rax
    7110:	85 c0                	test   %eax,%eax
    7112:	0f 88 b7 00 00 00    	js     71cf <fwp_tape_scope_release+0x10f>
    7118:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    711c:	48 8b 35 ed bf 01 00 	mov    0x1bfed(%rip),%rsi        # 23110 <fwp_tapes>
    7123:	4c 01 c6             	add    %r8,%rsi
    7126:	48 89 f7             	mov    %rsi,%rdi
    7129:	e8 62 cb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    712e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7133:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7138:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    713f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7143:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7147:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    714e:	00 
    714f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7154:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7159:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    715d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7162:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7166:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    716b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7172:	00 
    7173:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    717a:	00 
    717b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7182:	00 
    7183:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7187:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    718b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    718f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7193:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7199:	77 18                	ja     71b3 <fwp_tape_scope_release+0xf3>
    719b:	49 c1 f8 03          	sar    $0x3,%r8
    719f:	4d 0f af c4          	imul   %r12,%r8
    71a3:	4c 3b 05 4e bf 01 00 	cmp    0x1bf4e(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    71aa:	7d 07                	jge    71b3 <fwp_tape_scope_release+0xf3>
    71ac:	4c 89 05 45 bf 01 00 	mov    %r8,0x1bf45(%rip)        # 230f8 <fwp_tape_next_slot>
    71b3:	48 89 ef             	mov    %rbp,%rdi
    71b6:	4d 85 ed             	test   %r13,%r13
    71b9:	0f 85 41 ff ff ff    	jne    7100 <fwp_tape_scope_release+0x40>
    71bf:	e8 fc e0 ff ff       	call   52c0 <fwp_tape_buffers_release>
    71c4:	48 63 03             	movslq (%rbx),%rax
    71c7:	85 c0                	test   %eax,%eax
    71c9:	0f 89 49 ff ff ff    	jns    7118 <fwp_tape_scope_release+0x58>
    71cf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    71d4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71db:	00 00 
    71dd:	75 0b                	jne    71ea <fwp_tape_scope_release+0x12a>
    71df:	48 83 c4 48          	add    $0x48,%rsp
    71e3:	5b                   	pop    %rbx
    71e4:	5d                   	pop    %rbp
    71e5:	41 5c                	pop    %r12
    71e7:	41 5d                	pop    %r13
    71e9:	c3                   	ret
    71ea:	e8 61 c2 ff ff       	call   3450 <__stack_chk_fail@plt>
    71ef:	90                   	nop

00000000000071f0 <fwp_drop4>:
    71f0:	48 8b 0d 21 5a 06 00 	mov    0x65a21(%rip),%rcx        # 6cc18 <fwp_heap+0x13d8>
    71f7:	48 89 f8             	mov    %rdi,%rax
    71fa:	48 2b 05 ef 59 06 00 	sub    0x659ef(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7201:	48 c1 e1 10          	shl    $0x10,%rcx
    7205:	48 39 c8             	cmp    %rcx,%rax
    7208:	0f 83 42 01 00 00    	jae    7350 <fwp_drop4+0x160>
    720e:	48 83 ec 18          	sub    $0x18,%rsp
    7212:	48 89 fa             	mov    %rdi,%rdx
    7215:	4c 8d 05 24 46 06 00 	lea    0x64624(%rip),%r8        # 6b840 <fwp_heap>
    721c:	48 89 c1             	mov    %rax,%rcx
    721f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7226:	48 c1 e9 10          	shr    $0x10,%rcx
    722a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    722e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7232:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7236:	48 85 c9             	test   %rcx,%rcx
    7239:	74 40                	je     727b <fwp_drop4+0x8b>
    723b:	0f b6 3e             	movzbl (%rsi),%edi
    723e:	40 80 ff 02          	cmp    $0x2,%dil
    7242:	74 3c                	je     7280 <fwp_drop4+0x90>
    7244:	40 80 ff 01          	cmp    $0x1,%dil
    7248:	75 31                	jne    727b <fwp_drop4+0x8b>
    724a:	8b 7e 18             	mov    0x18(%rsi),%edi
    724d:	0f b7 c0             	movzwl %ax,%eax
    7250:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7253:	48 0f af c7          	imul   %rdi,%rax
    7257:	48 c1 e8 20          	shr    $0x20,%rax
    725b:	48 39 f0             	cmp    %rsi,%rax
    725e:	73 1b                	jae    727b <fwp_drop4+0x8b>
    7260:	48 01 c1             	add    %rax,%rcx
    7263:	0f b6 01             	movzbl (%rcx),%eax
    7266:	84 c0                	test   %al,%al
    7268:	74 11                	je     727b <fwp_drop4+0x8b>
    726a:	3c 01                	cmp    $0x1,%al
    726c:	74 22                	je     7290 <fwp_drop4+0xa0>
    726e:	3c ff                	cmp    $0xff,%al
    7270:	0f 84 0a 01 00 00    	je     7380 <fwp_drop4+0x190>
    7276:	83 e8 01             	sub    $0x1,%eax
    7279:	88 01                	mov    %al,(%rcx)
    727b:	48 83 c4 18          	add    $0x18,%rsp
    727f:	c3                   	ret
    7280:	66 85 c0             	test   %ax,%ax
    7283:	74 de                	je     7263 <fwp_drop4+0x73>
    7285:	48 83 c4 18          	add    $0x18,%rsp
    7289:	c3                   	ret
    728a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7290:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7294:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    729b:	48 89 f8             	mov    %rdi,%rax
    729e:	48 c1 e1 10          	shl    $0x10,%rcx
    72a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    72a9:	48 39 c8             	cmp    %rcx,%rax
    72ac:	73 62                	jae    7310 <fwp_drop4+0x120>
    72ae:	48 89 c1             	mov    %rax,%rcx
    72b1:	48 c1 e9 10          	shr    $0x10,%rcx
    72b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    72b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    72bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72c1:	48 85 c9             	test   %rcx,%rcx
    72c4:	74 4a                	je     7310 <fwp_drop4+0x120>
    72c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    72ca:	41 80 f9 02          	cmp    $0x2,%r9b
    72ce:	0f 84 9c 00 00 00    	je     7370 <fwp_drop4+0x180>
    72d4:	41 80 f9 01          	cmp    $0x1,%r9b
    72d8:	75 36                	jne    7310 <fwp_drop4+0x120>
    72da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    72de:	0f b7 c0             	movzwl %ax,%eax
    72e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    72e4:	49 0f af c1          	imul   %r9,%rax
    72e8:	48 c1 e8 20          	shr    $0x20,%rax
    72ec:	48 39 f0             	cmp    %rsi,%rax
    72ef:	73 1f                	jae    7310 <fwp_drop4+0x120>
    72f1:	48 01 c1             	add    %rax,%rcx
    72f4:	0f b6 01             	movzbl (%rcx),%eax
    72f7:	84 c0                	test   %al,%al
    72f9:	74 15                	je     7310 <fwp_drop4+0x120>
    72fb:	3c 01                	cmp    $0x1,%al
    72fd:	74 59                	je     7358 <fwp_drop4+0x168>
    72ff:	3c ff                	cmp    $0xff,%al
    7301:	0f 84 ff 00 00 00    	je     7406 <fwp_drop4+0x216>
    7307:	83 e8 01             	sub    $0x1,%eax
    730a:	88 01                	mov    %al,(%rcx)
    730c:	0f 1f 40 00          	nopl   0x0(%rax)
    7310:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7314:	48 89 d7             	mov    %rdx,%rdi
    7317:	48 89 0c 24          	mov    %rcx,(%rsp)
    731b:	e8 00 f7 ff ff       	call   6a20 <fwp_rc_free_obj>
    7320:	4c 8d 05 19 45 06 00 	lea    0x64519(%rip),%r8        # 6b840 <fwp_heap>
    7327:	48 8b 04 24          	mov    (%rsp),%rax
    732b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7332:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7339:	48 c1 e2 10          	shl    $0x10,%rdx
    733d:	48 39 d0             	cmp    %rdx,%rax
    7340:	0f 83 35 ff ff ff    	jae    727b <fwp_drop4+0x8b>
    7346:	48 8b 14 24          	mov    (%rsp),%rdx
    734a:	e9 cd fe ff ff       	jmp    721c <fwp_drop4+0x2c>
    734f:	90                   	nop
    7350:	c3                   	ret
    7351:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7358:	48 89 14 24          	mov    %rdx,(%rsp)
    735c:	e8 bf f6 ff ff       	call   6a20 <fwp_rc_free_obj>
    7361:	48 8b 14 24          	mov    (%rsp),%rdx
    7365:	eb a9                	jmp    7310 <fwp_drop4+0x120>
    7367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    736e:	00 00 
    7370:	66 85 c0             	test   %ax,%ax
    7373:	75 9b                	jne    7310 <fwp_drop4+0x120>
    7375:	e9 7a ff ff ff       	jmp    72f4 <fwp_drop4+0x104>
    737a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7380:	48 89 c8             	mov    %rcx,%rax
    7383:	48 c1 e8 11          	shr    $0x11,%rax
    7387:	48 31 c8             	xor    %rcx,%rax
    738a:	48 89 c2             	mov    %rax,%rdx
    738d:	48 c1 ea 09          	shr    $0x9,%rdx
    7391:	48 31 d0             	xor    %rdx,%rax
    7394:	0f b6 d0             	movzbl %al,%edx
    7397:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    739e:	00 
    739f:	48 85 c0             	test   %rax,%rax
    73a2:	75 29                	jne    73cd <fwp_drop4+0x1dd>
    73a4:	e9 e3 00 00 00       	jmp    748c <fwp_drop4+0x29c>
    73a9:	90                   	nop
    73aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73b1:	00 00 00 00 
    73b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73bc:	00 00 00 00 
    73c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    73c4:	48 85 c0             	test   %rax,%rax
    73c7:	0f 84 bf 00 00 00    	je     748c <fwp_drop4+0x29c>
    73cd:	48 89 c2             	mov    %rax,%rdx
    73d0:	48 39 08             	cmp    %rcx,(%rax)
    73d3:	75 eb                	jne    73c0 <fwp_drop4+0x1d0>
    73d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    73d9:	48 83 ea 01          	sub    $0x1,%rdx
    73dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    73e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    73e8:	0f 85 8d fe ff ff    	jne    727b <fwp_drop4+0x8b>
    73ee:	48 89 cf             	mov    %rcx,%rdi
    73f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    73f5:	e8 36 e4 ff ff       	call   5830 <fwp_rc_forget_slot>
    73fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    73fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7401:	e9 75 fe ff ff       	jmp    727b <fwp_drop4+0x8b>
    7406:	48 89 ce             	mov    %rcx,%rsi
    7409:	48 c1 ee 11          	shr    $0x11,%rsi
    740d:	48 31 ce             	xor    %rcx,%rsi
    7410:	48 89 f0             	mov    %rsi,%rax
    7413:	48 c1 e8 09          	shr    $0x9,%rax
    7417:	48 31 c6             	xor    %rax,%rsi
    741a:	40 0f b6 f6          	movzbl %sil,%esi
    741e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7425:	00 
    7426:	48 85 c0             	test   %rax,%rax
    7429:	75 1e                	jne    7449 <fwp_drop4+0x259>
    742b:	eb 5f                	jmp    748c <fwp_drop4+0x29c>
    742d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7434:	00 
    7435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    743c:	00 00 00 00 
    7440:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7444:	48 85 c0             	test   %rax,%rax
    7447:	74 43                	je     748c <fwp_drop4+0x29c>
    7449:	48 89 c6             	mov    %rax,%rsi
    744c:	48 39 08             	cmp    %rcx,(%rax)
    744f:	75 ef                	jne    7440 <fwp_drop4+0x250>
    7451:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7455:	48 83 ee 01          	sub    $0x1,%rsi
    7459:	48 89 70 08          	mov    %rsi,0x8(%rax)
    745d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7464:	0f 85 a6 fe ff ff    	jne    7310 <fwp_drop4+0x120>
    746a:	48 89 cf             	mov    %rcx,%rdi
    746d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7472:	48 89 0c 24          	mov    %rcx,(%rsp)
    7476:	e8 b5 e3 ff ff       	call   5830 <fwp_rc_forget_slot>
    747b:	48 8b 0c 24          	mov    (%rsp),%rcx
    747f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7484:	c6 01 fe             	movb   $0xfe,(%rcx)
    7487:	e9 84 fe ff ff       	jmp    7310 <fwp_drop4+0x120>
    748c:	48 8d 3d 5d 85 00 00 	lea    0x855d(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7493:	e8 b8 cf ff ff       	call   4450 <fwp_trap>
    7498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    749f:	00 

00000000000074a0 <fwp_arg_drop37>:
    74a0:	f3 0f 1e fa          	endbr64
    74a4:	85 f6                	test   %esi,%esi
    74a6:	75 04                	jne    74ac <fwp_arg_drop37+0xc>
    74a8:	85 d2                	test   %edx,%edx
    74aa:	75 04                	jne    74b0 <fwp_arg_drop37+0x10>
    74ac:	c3                   	ret
    74ad:	0f 1f 00             	nopl   (%rax)
    74b0:	48 8b 3f             	mov    (%rdi),%rdi
    74b3:	e9 38 fd ff ff       	jmp    71f0 <fwp_drop4>
    74b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74bf:	00 

00000000000074c0 <fwp_task_dispose>:
    74c0:	53                   	push   %rbx
    74c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    74c5:	0f 84 7b c2 ff ff    	je     3746 <fwp_task_dispose.cold>
    74cb:	48 89 fb             	mov    %rdi,%rbx
    74ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    74d3:	0f 85 6d c2 ff ff    	jne    3746 <fwp_task_dispose.cold>
    74d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    74dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    74e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    74eb:	00 
    74ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    74f0:	48 85 ff             	test   %rdi,%rdi
    74f3:	74 07                	je     74fc <fwp_task_dispose+0x3c>
    74f5:	48 85 c0             	test   %rax,%rax
    74f8:	74 02                	je     74fc <fwp_task_dispose+0x3c>
    74fa:	ff d0                	call   *%rax
    74fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7503:	e8 68 e5 ff ff       	call   5a70 <fwp_mem_free>
    7508:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    750f:	00 00 00 00 
    7513:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7517:	74 6f                	je     7588 <fwp_task_dispose+0xc8>
    7519:	48 8b 15 f8 56 06 00 	mov    0x656f8(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    7520:	48 89 d8             	mov    %rbx,%rax
    7523:	48 2b 05 c6 56 06 00 	sub    0x656c6(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    752a:	48 c1 e2 10          	shl    $0x10,%rdx
    752e:	48 39 d0             	cmp    %rdx,%rax
    7531:	73 4c                	jae    757f <fwp_task_dispose+0xbf>
    7533:	48 89 c2             	mov    %rax,%rdx
    7536:	48 c1 ea 10          	shr    $0x10,%rdx
    753a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    753e:	48 8b 15 f3 56 06 00 	mov    0x656f3(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    7545:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7549:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    754d:	48 85 c9             	test   %rcx,%rcx
    7550:	74 2d                	je     757f <fwp_task_dispose+0xbf>
    7552:	0f b6 32             	movzbl (%rdx),%esi
    7555:	40 80 fe 02          	cmp    $0x2,%sil
    7559:	74 3d                	je     7598 <fwp_task_dispose+0xd8>
    755b:	40 80 fe 01          	cmp    $0x1,%sil
    755f:	75 1e                	jne    757f <fwp_task_dispose+0xbf>
    7561:	8b 72 18             	mov    0x18(%rdx),%esi
    7564:	0f b7 c0             	movzwl %ax,%eax
    7567:	8b 52 1c             	mov    0x1c(%rdx),%edx
    756a:	48 0f af c6          	imul   %rsi,%rax
    756e:	48 c1 e8 20          	shr    $0x20,%rax
    7572:	48 39 d0             	cmp    %rdx,%rax
    7575:	73 08                	jae    757f <fwp_task_dispose+0xbf>
    7577:	48 01 c1             	add    %rax,%rcx
    757a:	80 39 01             	cmpb   $0x1,(%rcx)
    757d:	74 09                	je     7588 <fwp_task_dispose+0xc8>
    757f:	5b                   	pop    %rbx
    7580:	c3                   	ret
    7581:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7588:	48 89 df             	mov    %rbx,%rdi
    758b:	5b                   	pop    %rbx
    758c:	e9 df e4 ff ff       	jmp    5a70 <fwp_mem_free>
    7591:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7598:	66 85 c0             	test   %ax,%ax
    759b:	74 dd                	je     757a <fwp_task_dispose+0xba>
    759d:	5b                   	pop    %rbx
    759e:	c3                   	ret
    759f:	90                   	nop

00000000000075a0 <fwp_free_zombie>:
    75a0:	48 8b 15 69 42 06 00 	mov    0x64269(%rip),%rdx        # 6b810 <fwp_zombie>
    75a7:	48 85 d2             	test   %rdx,%rdx
    75aa:	0f 84 98 00 00 00    	je     7648 <fwp_free_zombie+0xa8>
    75b0:	48 3b 15 69 42 06 00 	cmp    0x64269(%rip),%rdx        # 6b820 <fwp_cur>
    75b7:	0f 84 8b 00 00 00    	je     7648 <fwp_free_zombie+0xa8>
    75bd:	48 83 ec 18          	sub    $0x18,%rsp
    75c1:	48 63 05 2c 3c 06 00 	movslq 0x63c2c(%rip),%rax        # 6b1f4 <fwp_stack_pool_n>
    75c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    75cc:	83 f8 3f             	cmp    $0x3f,%eax
    75cf:	7f 7f                	jg     7650 <fwp_free_zombie+0xb0>
    75d1:	8d 48 01             	lea    0x1(%rax),%ecx
    75d4:	89 0d 1a 3c 06 00    	mov    %ecx,0x63c1a(%rip)        # 6b1f4 <fwp_stack_pool_n>
    75da:	48 8d 0d 1f 3c 06 00 	lea    0x63c1f(%rip),%rcx        # 6b200 <fwp_stack_pool>
    75e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    75e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    75ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    75f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    75f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    75fb:	48 85 c9             	test   %rcx,%rcx
    75fe:	0f 84 fc 00 00 00    	je     7700 <fwp_free_zombie+0x160>
    7604:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    760b:	48 85 c0             	test   %rax,%rax
    760e:	74 07                	je     7617 <fwp_free_zombie+0x77>
    7610:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7617:	8b 42 5c             	mov    0x5c(%rdx),%eax
    761a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    761e:	48 c7 05 e7 41 06 00 	movq   $0x0,0x641e7(%rip)        # 6b810 <fwp_zombie>
    7625:	00 00 00 00 
    7629:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7630:	85 c0                	test   %eax,%eax
    7632:	74 34                	je     7668 <fwp_free_zombie+0xc8>
    7634:	83 f8 01             	cmp    $0x1,%eax
    7637:	0f 84 b3 00 00 00    	je     76f0 <fwp_free_zombie+0x150>
    763d:	48 83 c4 18          	add    $0x18,%rsp
    7641:	c3                   	ret
    7642:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7648:	c3                   	ret
    7649:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7650:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7654:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7659:	e8 62 bf ff ff       	call   35c0 <munmap@plt>
    765e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7663:	eb 80                	jmp    75e5 <fwp_free_zombie+0x45>
    7665:	0f 1f 00             	nopl   (%rax)
    7668:	48 8b 0d a9 55 06 00 	mov    0x655a9(%rip),%rcx        # 6cc18 <fwp_heap+0x13d8>
    766f:	48 89 d0             	mov    %rdx,%rax
    7672:	48 2b 05 77 55 06 00 	sub    0x65577(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7679:	48 c1 e1 10          	shl    $0x10,%rcx
    767d:	48 39 c8             	cmp    %rcx,%rax
    7680:	73 bb                	jae    763d <fwp_free_zombie+0x9d>
    7682:	48 89 c1             	mov    %rax,%rcx
    7685:	48 c1 e9 10          	shr    $0x10,%rcx
    7689:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    768d:	48 8b 0d a4 55 06 00 	mov    0x655a4(%rip),%rcx        # 6cc38 <fwp_heap+0x13f8>
    7694:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7698:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    769c:	48 85 c9             	test   %rcx,%rcx
    769f:	74 9c                	je     763d <fwp_free_zombie+0x9d>
    76a1:	0f b6 3e             	movzbl (%rsi),%edi
    76a4:	40 80 ff 02          	cmp    $0x2,%dil
    76a8:	74 66                	je     7710 <fwp_free_zombie+0x170>
    76aa:	40 80 ff 01          	cmp    $0x1,%dil
    76ae:	75 8d                	jne    763d <fwp_free_zombie+0x9d>
    76b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    76b3:	0f b7 c0             	movzwl %ax,%eax
    76b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    76b9:	48 0f af c7          	imul   %rdi,%rax
    76bd:	48 c1 e8 20          	shr    $0x20,%rax
    76c1:	48 39 f0             	cmp    %rsi,%rax
    76c4:	0f 83 73 ff ff ff    	jae    763d <fwp_free_zombie+0x9d>
    76ca:	48 01 c1             	add    %rax,%rcx
    76cd:	0f b6 01             	movzbl (%rcx),%eax
    76d0:	84 c0                	test   %al,%al
    76d2:	0f 84 65 ff ff ff    	je     763d <fwp_free_zombie+0x9d>
    76d8:	3c 01                	cmp    $0x1,%al
    76da:	74 14                	je     76f0 <fwp_free_zombie+0x150>
    76dc:	3c ff                	cmp    $0xff,%al
    76de:	74 3b                	je     771b <fwp_free_zombie+0x17b>
    76e0:	83 e8 01             	sub    $0x1,%eax
    76e3:	88 01                	mov    %al,(%rcx)
    76e5:	e9 53 ff ff ff       	jmp    763d <fwp_free_zombie+0x9d>
    76ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f0:	48 89 d7             	mov    %rdx,%rdi
    76f3:	48 83 c4 18          	add    $0x18,%rsp
    76f7:	e9 c4 fd ff ff       	jmp    74c0 <fwp_task_dispose>
    76fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7700:	48 89 05 e1 40 06 00 	mov    %rax,0x640e1(%rip)        # 6b7e8 <fwp_tasks_active>
    7707:	e9 ff fe ff ff       	jmp    760b <fwp_free_zombie+0x6b>
    770c:	0f 1f 40 00          	nopl   0x0(%rax)
    7710:	66 85 c0             	test   %ax,%ax
    7713:	0f 85 24 ff ff ff    	jne    763d <fwp_free_zombie+0x9d>
    7719:	eb b2                	jmp    76cd <fwp_free_zombie+0x12d>
    771b:	48 89 ca             	mov    %rcx,%rdx
    771e:	48 8d 35 1b 41 06 00 	lea    0x6411b(%rip),%rsi        # 6b840 <fwp_heap>
    7725:	48 c1 ea 11          	shr    $0x11,%rdx
    7729:	48 31 ca             	xor    %rcx,%rdx
    772c:	48 89 d0             	mov    %rdx,%rax
    772f:	48 c1 e8 09          	shr    $0x9,%rax
    7733:	48 31 c2             	xor    %rax,%rdx
    7736:	0f b6 d2             	movzbl %dl,%edx
    7739:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7740:	00 
    7741:	48 85 c0             	test   %rax,%rax
    7744:	75 23                	jne    7769 <fwp_free_zombie+0x1c9>
    7746:	eb 5c                	jmp    77a4 <fwp_free_zombie+0x204>
    7748:	66 90                	xchg   %ax,%ax
    774a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7751:	00 00 00 00 
    7755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    775c:	00 00 00 00 
    7760:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7764:	48 85 c0             	test   %rax,%rax
    7767:	74 3b                	je     77a4 <fwp_free_zombie+0x204>
    7769:	48 89 c2             	mov    %rax,%rdx
    776c:	48 39 08             	cmp    %rcx,(%rax)
    776f:	75 ef                	jne    7760 <fwp_free_zombie+0x1c0>
    7771:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7775:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7779:	48 89 50 08          	mov    %rdx,0x8(%rax)
    777d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7784:	0f 85 b3 fe ff ff    	jne    763d <fwp_free_zombie+0x9d>
    778a:	48 89 cf             	mov    %rcx,%rdi
    778d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7792:	e8 99 e0 ff ff       	call   5830 <fwp_rc_forget_slot>
    7797:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    779c:	c6 01 fe             	movb   $0xfe,(%rcx)
    779f:	e9 99 fe ff ff       	jmp    763d <fwp_free_zombie+0x9d>
    77a4:	48 8d 3d 45 82 00 00 	lea    0x8245(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    77ab:	e8 a0 cc ff ff       	call   4450 <fwp_trap>

00000000000077b0 <fwp_block>:
    77b0:	48 83 ec 08          	sub    $0x8,%rsp
    77b4:	48 8b 05 4d 40 06 00 	mov    0x6404d(%rip),%rax        # 6b808 <fwp_ready_head>
    77bb:	48 85 c0             	test   %rax,%rax
    77be:	0f 84 1c 01 00 00    	je     78e0 <fwp_block+0x130>
    77c4:	90                   	nop
    77c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77cc:	00 00 00 00 
    77d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    77d7:	48 89 15 2a 40 06 00 	mov    %rdx,0x6402a(%rip)        # 6b808 <fwp_ready_head>
    77de:	48 85 d2             	test   %rdx,%rdx
    77e1:	0f 84 19 01 00 00    	je     7900 <fwp_block+0x150>
    77e7:	48 8b 15 32 40 06 00 	mov    0x64032(%rip),%rdx        # 6b820 <fwp_cur>
    77ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    77f2:	48 39 c2             	cmp    %rax,%rdx
    77f5:	0f 84 d5 00 00 00    	je     78d0 <fwp_block+0x120>
    77fb:	48 8b 0d a6 5c 06 00 	mov    0x65ca6(%rip),%rcx        # 6d4a8 <fwp_state_owners>
    7802:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7806:	48 89 05 13 40 06 00 	mov    %rax,0x64013(%rip)        # 6b820 <fwp_cur>
    780d:	f3 0f 7e 05 bb 5c 06 	movq   0x65cbb(%rip),%xmm0        # 6d4d0 <fwp_foreign_callbacks>
    7814:	00 
    7815:	0f 16 05 a4 5c 06 00 	movhps 0x65ca4(%rip),%xmm0        # 6d4c0 <fwp_state>
    781c:	f3 0f 7e 0d a4 5c 06 	movq   0x65ca4(%rip),%xmm1        # 6d4c8 <fwp_handlers>
    7823:	00 
    7824:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    782b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7832:	0f 16 0d 9f 5c 06 00 	movhps 0x65c9f(%rip),%xmm1        # 6d4d8 <fwp_cleanups>
    7839:	f3 0f 7e 05 77 5c 06 	movq   0x65c77(%rip),%xmm0        # 6d4b8 <fwp_state_len>
    7840:	00 
    7841:	0f 16 05 68 5c 06 00 	movhps 0x65c68(%rip),%xmm0        # 6d4b0 <fwp_state_cap>
    7848:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    784f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7856:	48 8b 70 08          	mov    0x8(%rax),%rsi
    785a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7861:	48 89 0d 60 5c 06 00 	mov    %rcx,0x65c60(%rip)        # 6d4c8 <fwp_handlers>
    7868:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    786f:	48 89 0d 62 5c 06 00 	mov    %rcx,0x65c62(%rip)        # 6d4d8 <fwp_cleanups>
    7876:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    787d:	48 89 0d 4c 5c 06 00 	mov    %rcx,0x65c4c(%rip)        # 6d4d0 <fwp_foreign_callbacks>
    7884:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    788b:	48 89 0d 2e 5c 06 00 	mov    %rcx,0x65c2e(%rip)        # 6d4c0 <fwp_state>
    7892:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7899:	48 89 0d 18 5c 06 00 	mov    %rcx,0x65c18(%rip)        # 6d4b8 <fwp_state_len>
    78a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    78a7:	48 89 0d 02 5c 06 00 	mov    %rcx,0x65c02(%rip)        # 6d4b0 <fwp_state_cap>
    78ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    78b5:	48 89 0d ec 5b 06 00 	mov    %rcx,0x65bec(%rip)        # 6d4a8 <fwp_state_owners>
    78bc:	e8 bf bb ff ff       	call   3480 <swapcontext@plt>
    78c1:	f3 0f 1e fa          	endbr64
    78c5:	e8 d6 fc ff ff       	call   75a0 <fwp_free_zombie>
    78ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78d0:	8b 05 1a 39 06 00    	mov    0x6391a(%rip),%eax        # 6b1f0 <fwp_slice>
    78d6:	85 c0                	test   %eax,%eax
    78d8:	74 36                	je     7910 <fwp_block+0x160>
    78da:	48 83 c4 08          	add    $0x8,%rsp
    78de:	c3                   	ret
    78df:	90                   	nop
    78e0:	e8 8b db ff ff       	call   5470 <fwp_poll_events>
    78e5:	48 8b 05 1c 3f 06 00 	mov    0x63f1c(%rip),%rax        # 6b808 <fwp_ready_head>
    78ec:	48 85 c0             	test   %rax,%rax
    78ef:	0f 85 db fe ff ff    	jne    77d0 <fwp_block+0x20>
    78f5:	eb e9                	jmp    78e0 <fwp_block+0x130>
    78f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78fe:	00 00 
    7900:	48 c7 05 f5 3e 06 00 	movq   $0x0,0x63ef5(%rip)        # 6b800 <fwp_ready_tail>
    7907:	00 00 00 00 
    790b:	e9 d7 fe ff ff       	jmp    77e7 <fwp_block+0x37>
    7910:	48 8d 3d c8 78 00 00 	lea    0x78c8(%rip),%rdi        # f1df <_IO_stdin_used+0x1df>
    7917:	e8 74 ba ff ff       	call   3390 <getenv@plt>
    791c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7921:	48 85 c0             	test   %rax,%rax
    7924:	74 05                	je     792b <fwp_block+0x17b>
    7926:	80 38 00             	cmpb   $0x0,(%rax)
    7929:	75 0b                	jne    7936 <fwp_block+0x186>
    792b:	89 15 bf 38 06 00    	mov    %edx,0x638bf(%rip)        # 6b1f0 <fwp_slice>
    7931:	48 83 c4 08          	add    $0x8,%rsp
    7935:	c3                   	ret
    7936:	ba 0a 00 00 00       	mov    $0xa,%edx
    793b:	31 f6                	xor    %esi,%esi
    793d:	48 89 c7             	mov    %rax,%rdi
    7940:	e8 fb bb ff ff       	call   3540 <strtoll@plt>
    7945:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7949:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7950:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7955:	0f 46 d0             	cmovbe %eax,%edx
    7958:	eb d1                	jmp    792b <fwp_block+0x17b>
    795a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007960 <fwp_caps173>:
    7960:	f3 0f 1e fa          	endbr64
    7964:	85 f6                	test   %esi,%esi
    7966:	74 08                	je     7970 <fwp_caps173+0x10>
    7968:	c3                   	ret
    7969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7970:	48 8b 15 a1 52 06 00 	mov    0x652a1(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    7977:	48 89 f8             	mov    %rdi,%rax
    797a:	48 2b 05 6f 52 06 00 	sub    0x6526f(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7981:	48 c1 e2 10          	shl    $0x10,%rdx
    7985:	48 39 d0             	cmp    %rdx,%rax
    7988:	73 de                	jae    7968 <fwp_caps173+0x8>
    798a:	48 89 c2             	mov    %rax,%rdx
    798d:	48 c1 ea 10          	shr    $0x10,%rdx
    7991:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7995:	48 8b 15 9c 52 06 00 	mov    0x6529c(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    799c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    79a4:	48 85 c9             	test   %rcx,%rcx
    79a7:	74 bf                	je     7968 <fwp_caps173+0x8>
    79a9:	0f b6 32             	movzbl (%rdx),%esi
    79ac:	40 80 fe 02          	cmp    $0x2,%sil
    79b0:	74 2e                	je     79e0 <fwp_caps173+0x80>
    79b2:	40 80 fe 01          	cmp    $0x1,%sil
    79b6:	75 b0                	jne    7968 <fwp_caps173+0x8>
    79b8:	8b 72 18             	mov    0x18(%rdx),%esi
    79bb:	0f b7 c0             	movzwl %ax,%eax
    79be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79c1:	48 0f af c6          	imul   %rsi,%rax
    79c5:	48 c1 e8 20          	shr    $0x20,%rax
    79c9:	48 39 d0             	cmp    %rdx,%rax
    79cc:	73 9a                	jae    7968 <fwp_caps173+0x8>
    79ce:	48 01 c1             	add    %rax,%rcx
    79d1:	80 39 01             	cmpb   $0x1,(%rcx)
    79d4:	75 92                	jne    7968 <fwp_caps173+0x8>
    79d6:	e9 95 e0 ff ff       	jmp    5a70 <fwp_mem_free>
    79db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79e0:	66 85 c0             	test   %ax,%ax
    79e3:	74 ec                	je     79d1 <fwp_caps173+0x71>
    79e5:	c3                   	ret
    79e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79ed:	00 00 00 

00000000000079f0 <fwp_args37>:
    79f0:	f3 0f 1e fa          	endbr64
    79f4:	85 d2                	test   %edx,%edx
    79f6:	74 04                	je     79fc <fwp_args37+0xc>
    79f8:	85 f6                	test   %esi,%esi
    79fa:	74 04                	je     7a00 <fwp_args37+0x10>
    79fc:	c3                   	ret
    79fd:	0f 1f 00             	nopl   (%rax)
    7a00:	48 8b 15 11 52 06 00 	mov    0x65211(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    7a07:	48 8b 07             	mov    (%rdi),%rax
    7a0a:	48 2b 05 df 51 06 00 	sub    0x651df(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7a11:	48 c1 e2 10          	shl    $0x10,%rdx
    7a15:	48 39 d0             	cmp    %rdx,%rax
    7a18:	73 e2                	jae    79fc <fwp_args37+0xc>
    7a1a:	48 89 c2             	mov    %rax,%rdx
    7a1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a25:	48 8b 15 0c 52 06 00 	mov    0x6520c(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    7a2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a30:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a34:	48 85 ff             	test   %rdi,%rdi
    7a37:	74 c3                	je     79fc <fwp_args37+0xc>
    7a39:	0f b6 0a             	movzbl (%rdx),%ecx
    7a3c:	80 f9 02             	cmp    $0x2,%cl
    7a3f:	74 4f                	je     7a90 <fwp_args37+0xa0>
    7a41:	80 f9 01             	cmp    $0x1,%cl
    7a44:	75 b6                	jne    79fc <fwp_args37+0xc>
    7a46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a49:	0f b7 c0             	movzwl %ax,%eax
    7a4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a4f:	48 0f af c1          	imul   %rcx,%rax
    7a53:	48 c1 e8 20          	shr    $0x20,%rax
    7a57:	48 39 d0             	cmp    %rdx,%rax
    7a5a:	73 a0                	jae    79fc <fwp_args37+0xc>
    7a5c:	48 01 c7             	add    %rax,%rdi
    7a5f:	0f b6 07             	movzbl (%rdi),%eax
    7a62:	84 c0                	test   %al,%al
    7a64:	74 96                	je     79fc <fwp_args37+0xc>
    7a66:	8b 15 9c 5a 06 00    	mov    0x65a9c(%rip),%edx        # 6d508 <iteration_active>
    7a6c:	85 d2                	test   %edx,%edx
    7a6e:	75 10                	jne    7a80 <fwp_args37+0x90>
    7a70:	3c fd                	cmp    $0xfd,%al
    7a72:	77 22                	ja     7a96 <fwp_args37+0xa6>
    7a74:	83 c0 01             	add    $0x1,%eax
    7a77:	88 07                	mov    %al,(%rdi)
    7a79:	c3                   	ret
    7a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a80:	48 83 05 68 5a 06 00 	addq   $0x1,0x65a68(%rip)        # 6d4f0 <iteration_retains>
    7a87:	01 
    7a88:	eb e6                	jmp    7a70 <fwp_args37+0x80>
    7a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a90:	66 85 c0             	test   %ax,%ax
    7a93:	74 ca                	je     7a5f <fwp_args37+0x6f>
    7a95:	c3                   	ret
    7a96:	e9 75 dc ff ff       	jmp    5710 <fwp_rc_wide_dup>
    7a9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007aa0 <fwp_caps37>:
    7aa0:	f3 0f 1e fa          	endbr64
    7aa4:	48 83 ec 18          	sub    $0x18,%rsp
    7aa8:	48 89 f8             	mov    %rdi,%rax
    7aab:	8b 7f 04             	mov    0x4(%rdi),%edi
    7aae:	85 ff                	test   %edi,%edi
    7ab0:	0f 84 9a 00 00 00    	je     7b50 <fwp_caps37+0xb0>
    7ab6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7aba:	85 f6                	test   %esi,%esi
    7abc:	0f 85 9e 00 00 00    	jne    7b60 <fwp_caps37+0xc0>
    7ac2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7ac7:	e8 24 f7 ff ff       	call   71f0 <fwp_drop4>
    7acc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7ad1:	48 8b 0d 40 51 06 00 	mov    0x65140(%rip),%rcx        # 6cc18 <fwp_heap+0x13d8>
    7ad8:	48 89 c2             	mov    %rax,%rdx
    7adb:	48 2b 15 0e 51 06 00 	sub    0x6510e(%rip),%rdx        # 6cbf0 <fwp_heap+0x13b0>
    7ae2:	48 c1 e1 10          	shl    $0x10,%rcx
    7ae6:	48 39 ca             	cmp    %rcx,%rdx
    7ae9:	73 6d                	jae    7b58 <fwp_caps37+0xb8>
    7aeb:	48 89 d1             	mov    %rdx,%rcx
    7aee:	48 c1 e9 10          	shr    $0x10,%rcx
    7af2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7af6:	48 8b 0d 3b 51 06 00 	mov    0x6513b(%rip),%rcx        # 6cc38 <fwp_heap+0x13f8>
    7afd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b05:	48 85 f6             	test   %rsi,%rsi
    7b08:	74 4e                	je     7b58 <fwp_caps37+0xb8>
    7b0a:	0f b6 39             	movzbl (%rcx),%edi
    7b0d:	40 80 ff 02          	cmp    $0x2,%dil
    7b11:	0f 84 c9 00 00 00    	je     7be0 <fwp_caps37+0x140>
    7b17:	40 80 ff 01          	cmp    $0x1,%dil
    7b1b:	75 3b                	jne    7b58 <fwp_caps37+0xb8>
    7b1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b20:	0f b7 d2             	movzwl %dx,%edx
    7b23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b26:	48 0f af d7          	imul   %rdi,%rdx
    7b2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7b2e:	48 39 ca             	cmp    %rcx,%rdx
    7b31:	73 25                	jae    7b58 <fwp_caps37+0xb8>
    7b33:	48 01 d6             	add    %rdx,%rsi
    7b36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b39:	75 1d                	jne    7b58 <fwp_caps37+0xb8>
    7b3b:	48 89 c7             	mov    %rax,%rdi
    7b3e:	48 83 c4 18          	add    $0x18,%rsp
    7b42:	e9 29 df ff ff       	jmp    5a70 <fwp_mem_free>
    7b47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b4e:	00 00 
    7b50:	85 f6                	test   %esi,%esi
    7b52:	0f 84 79 ff ff ff    	je     7ad1 <fwp_caps37+0x31>
    7b58:	48 83 c4 18          	add    $0x18,%rsp
    7b5c:	c3                   	ret
    7b5d:	0f 1f 00             	nopl   (%rax)
    7b60:	48 8b 05 b1 50 06 00 	mov    0x650b1(%rip),%rax        # 6cc18 <fwp_heap+0x13d8>
    7b67:	48 2b 3d 82 50 06 00 	sub    0x65082(%rip),%rdi        # 6cbf0 <fwp_heap+0x13b0>
    7b6e:	48 c1 e0 10          	shl    $0x10,%rax
    7b72:	48 39 c7             	cmp    %rax,%rdi
    7b75:	73 e1                	jae    7b58 <fwp_caps37+0xb8>
    7b77:	48 89 f8             	mov    %rdi,%rax
    7b7a:	48 c1 e8 10          	shr    $0x10,%rax
    7b7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7b82:	48 8b 05 af 50 06 00 	mov    0x650af(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    7b89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7b8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7b91:	48 85 c0             	test   %rax,%rax
    7b94:	74 c2                	je     7b58 <fwp_caps37+0xb8>
    7b96:	0f b6 0a             	movzbl (%rdx),%ecx
    7b99:	80 f9 02             	cmp    $0x2,%cl
    7b9c:	74 52                	je     7bf0 <fwp_caps37+0x150>
    7b9e:	80 f9 01             	cmp    $0x1,%cl
    7ba1:	75 b5                	jne    7b58 <fwp_caps37+0xb8>
    7ba3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ba6:	0f b7 ff             	movzwl %di,%edi
    7ba9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bac:	48 0f af f9          	imul   %rcx,%rdi
    7bb0:	48 c1 ef 20          	shr    $0x20,%rdi
    7bb4:	48 39 d7             	cmp    %rdx,%rdi
    7bb7:	73 9f                	jae    7b58 <fwp_caps37+0xb8>
    7bb9:	48 01 f8             	add    %rdi,%rax
    7bbc:	0f b6 10             	movzbl (%rax),%edx
    7bbf:	84 d2                	test   %dl,%dl
    7bc1:	74 95                	je     7b58 <fwp_caps37+0xb8>
    7bc3:	8b 0d 3f 59 06 00    	mov    0x6593f(%rip),%ecx        # 6d508 <iteration_active>
    7bc9:	85 c9                	test   %ecx,%ecx
    7bcb:	75 33                	jne    7c00 <fwp_caps37+0x160>
    7bcd:	80 fa fd             	cmp    $0xfd,%dl
    7bd0:	77 38                	ja     7c0a <fwp_caps37+0x16a>
    7bd2:	83 c2 01             	add    $0x1,%edx
    7bd5:	88 10                	mov    %dl,(%rax)
    7bd7:	e9 7c ff ff ff       	jmp    7b58 <fwp_caps37+0xb8>
    7bdc:	0f 1f 40 00          	nopl   0x0(%rax)
    7be0:	66 85 d2             	test   %dx,%dx
    7be3:	0f 85 6f ff ff ff    	jne    7b58 <fwp_caps37+0xb8>
    7be9:	e9 48 ff ff ff       	jmp    7b36 <fwp_caps37+0x96>
    7bee:	66 90                	xchg   %ax,%ax
    7bf0:	66 85 ff             	test   %di,%di
    7bf3:	0f 85 5f ff ff ff    	jne    7b58 <fwp_caps37+0xb8>
    7bf9:	eb c1                	jmp    7bbc <fwp_caps37+0x11c>
    7bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c00:	48 83 05 e8 58 06 00 	addq   $0x1,0x658e8(%rip)        # 6d4f0 <iteration_retains>
    7c07:	01 
    7c08:	eb c3                	jmp    7bcd <fwp_caps37+0x12d>
    7c0a:	48 89 c7             	mov    %rax,%rdi
    7c0d:	48 83 c4 18          	add    $0x18,%rsp
    7c11:	e9 fa da ff ff       	jmp    5710 <fwp_rc_wide_dup>
    7c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c1d:	00 00 00 

0000000000007c20 <fwp_drop0>:
    7c20:	f3 0f 1e fa          	endbr64
    7c24:	48 8b 15 ed 4f 06 00 	mov    0x64fed(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    7c2b:	48 89 f8             	mov    %rdi,%rax
    7c2e:	48 2b 05 bb 4f 06 00 	sub    0x64fbb(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7c35:	48 c1 e2 10          	shl    $0x10,%rdx
    7c39:	48 39 d0             	cmp    %rdx,%rax
    7c3c:	0f 83 36 01 00 00    	jae    7d78 <fwp_drop0+0x158>
    7c42:	48 83 ec 18          	sub    $0x18,%rsp
    7c46:	48 8d 35 f3 3b 06 00 	lea    0x63bf3(%rip),%rsi        # 6b840 <fwp_heap>
    7c4d:	48 89 c2             	mov    %rax,%rdx
    7c50:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7c57:	48 c1 ea 10          	shr    $0x10,%rdx
    7c5b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c5f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7c63:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c67:	48 85 d2             	test   %rdx,%rdx
    7c6a:	74 42                	je     7cae <fwp_drop0+0x8e>
    7c6c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7c70:	41 80 f8 02          	cmp    $0x2,%r8b
    7c74:	74 42                	je     7cb8 <fwp_drop0+0x98>
    7c76:	41 80 f8 01          	cmp    $0x1,%r8b
    7c7a:	75 32                	jne    7cae <fwp_drop0+0x8e>
    7c7c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7c80:	0f b7 c0             	movzwl %ax,%eax
    7c83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c86:	49 0f af c0          	imul   %r8,%rax
    7c8a:	48 c1 e8 20          	shr    $0x20,%rax
    7c8e:	48 39 c8             	cmp    %rcx,%rax
    7c91:	73 1b                	jae    7cae <fwp_drop0+0x8e>
    7c93:	48 01 c2             	add    %rax,%rdx
    7c96:	0f b6 02             	movzbl (%rdx),%eax
    7c99:	84 c0                	test   %al,%al
    7c9b:	74 11                	je     7cae <fwp_drop0+0x8e>
    7c9d:	3c 01                	cmp    $0x1,%al
    7c9f:	74 27                	je     7cc8 <fwp_drop0+0xa8>
    7ca1:	3c ff                	cmp    $0xff,%al
    7ca3:	0f 84 e7 00 00 00    	je     7d90 <fwp_drop0+0x170>
    7ca9:	83 e8 01             	sub    $0x1,%eax
    7cac:	88 02                	mov    %al,(%rdx)
    7cae:	48 83 c4 18          	add    $0x18,%rsp
    7cb2:	c3                   	ret
    7cb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cb8:	66 85 c0             	test   %ax,%ax
    7cbb:	74 d9                	je     7c96 <fwp_drop0+0x76>
    7cbd:	48 83 c4 18          	add    $0x18,%rsp
    7cc1:	c3                   	ret
    7cc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cc8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ccf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7cd6:	48 89 f8             	mov    %rdi,%rax
    7cd9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7cdd:	48 29 c8             	sub    %rcx,%rax
    7ce0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce4:	48 39 d0             	cmp    %rdx,%rax
    7ce7:	73 71                	jae    7d5a <fwp_drop0+0x13a>
    7ce9:	49 89 c2             	mov    %rax,%r10
    7cec:	49 c1 ea 10          	shr    $0x10,%r10
    7cf0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7cf4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7cf8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7cfc:	4d 85 d2             	test   %r10,%r10
    7cff:	74 59                	je     7d5a <fwp_drop0+0x13a>
    7d01:	45 0f b6 19          	movzbl (%r9),%r11d
    7d05:	41 80 fb 02          	cmp    $0x2,%r11b
    7d09:	74 75                	je     7d80 <fwp_drop0+0x160>
    7d0b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d0f:	75 49                	jne    7d5a <fwp_drop0+0x13a>
    7d11:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d15:	0f b7 c0             	movzwl %ax,%eax
    7d18:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d1c:	49 0f af c3          	imul   %r11,%rax
    7d20:	48 c1 e8 20          	shr    $0x20,%rax
    7d24:	4c 39 c8             	cmp    %r9,%rax
    7d27:	73 31                	jae    7d5a <fwp_drop0+0x13a>
    7d29:	49 01 c2             	add    %rax,%r10
    7d2c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d30:	75 28                	jne    7d5a <fwp_drop0+0x13a>
    7d32:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7d37:	e8 34 dd ff ff       	call   5a70 <fwp_mem_free>
    7d3c:	48 8d 35 fd 3a 06 00 	lea    0x63afd(%rip),%rsi        # 6b840 <fwp_heap>
    7d43:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7d48:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d4f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d56:	48 c1 e2 10          	shl    $0x10,%rdx
    7d5a:	4c 89 c0             	mov    %r8,%rax
    7d5d:	48 29 c8             	sub    %rcx,%rax
    7d60:	48 39 d0             	cmp    %rdx,%rax
    7d63:	0f 83 45 ff ff ff    	jae    7cae <fwp_drop0+0x8e>
    7d69:	4c 89 c7             	mov    %r8,%rdi
    7d6c:	e9 dc fe ff ff       	jmp    7c4d <fwp_drop0+0x2d>
    7d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d78:	c3                   	ret
    7d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d80:	66 85 c0             	test   %ax,%ax
    7d83:	75 d5                	jne    7d5a <fwp_drop0+0x13a>
    7d85:	eb a5                	jmp    7d2c <fwp_drop0+0x10c>
    7d87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d8e:	00 00 
    7d90:	48 89 d0             	mov    %rdx,%rax
    7d93:	48 c1 e8 11          	shr    $0x11,%rax
    7d97:	48 31 d0             	xor    %rdx,%rax
    7d9a:	48 89 c1             	mov    %rax,%rcx
    7d9d:	48 c1 e9 09          	shr    $0x9,%rcx
    7da1:	48 31 c8             	xor    %rcx,%rax
    7da4:	0f b6 c8             	movzbl %al,%ecx
    7da7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7dae:	00 
    7daf:	48 85 c0             	test   %rax,%rax
    7db2:	75 15                	jne    7dc9 <fwp_drop0+0x1a9>
    7db4:	eb 4e                	jmp    7e04 <fwp_drop0+0x1e4>
    7db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7dbd:	00 00 00 
    7dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7dc4:	48 85 c0             	test   %rax,%rax
    7dc7:	74 3b                	je     7e04 <fwp_drop0+0x1e4>
    7dc9:	48 89 c1             	mov    %rax,%rcx
    7dcc:	48 39 10             	cmp    %rdx,(%rax)
    7dcf:	75 ef                	jne    7dc0 <fwp_drop0+0x1a0>
    7dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7de4:	0f 85 c4 fe ff ff    	jne    7cae <fwp_drop0+0x8e>
    7dea:	48 89 d7             	mov    %rdx,%rdi
    7ded:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7df2:	e8 39 da ff ff       	call   5830 <fwp_rc_forget_slot>
    7df7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7dfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7dff:	e9 aa fe ff ff       	jmp    7cae <fwp_drop0+0x8e>
    7e04:	48 8d 3d e5 7b 00 00 	lea    0x7be5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7e0b:	e8 40 c6 ff ff       	call   4450 <fwp_trap>

0000000000007e10 <fwp_drop1>:
    7e10:	f3 0f 1e fa          	endbr64
    7e14:	48 8b 15 fd 4d 06 00 	mov    0x64dfd(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    7e1b:	48 89 f8             	mov    %rdi,%rax
    7e1e:	48 2b 05 cb 4d 06 00 	sub    0x64dcb(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    7e25:	48 c1 e2 10          	shl    $0x10,%rdx
    7e29:	48 39 d0             	cmp    %rdx,%rax
    7e2c:	0f 83 36 01 00 00    	jae    7f68 <fwp_drop1+0x158>
    7e32:	48 83 ec 18          	sub    $0x18,%rsp
    7e36:	48 8d 35 03 3a 06 00 	lea    0x63a03(%rip),%rsi        # 6b840 <fwp_heap>
    7e3d:	48 89 c2             	mov    %rax,%rdx
    7e40:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7e47:	48 c1 ea 10          	shr    $0x10,%rdx
    7e4b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7e4f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7e53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7e57:	48 85 d2             	test   %rdx,%rdx
    7e5a:	74 42                	je     7e9e <fwp_drop1+0x8e>
    7e5c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7e60:	41 80 f8 02          	cmp    $0x2,%r8b
    7e64:	74 42                	je     7ea8 <fwp_drop1+0x98>
    7e66:	41 80 f8 01          	cmp    $0x1,%r8b
    7e6a:	75 32                	jne    7e9e <fwp_drop1+0x8e>
    7e6c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7e70:	0f b7 c0             	movzwl %ax,%eax
    7e73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e76:	49 0f af c0          	imul   %r8,%rax
    7e7a:	48 c1 e8 20          	shr    $0x20,%rax
    7e7e:	48 39 c8             	cmp    %rcx,%rax
    7e81:	73 1b                	jae    7e9e <fwp_drop1+0x8e>
    7e83:	48 01 c2             	add    %rax,%rdx
    7e86:	0f b6 02             	movzbl (%rdx),%eax
    7e89:	84 c0                	test   %al,%al
    7e8b:	74 11                	je     7e9e <fwp_drop1+0x8e>
    7e8d:	3c 01                	cmp    $0x1,%al
    7e8f:	74 27                	je     7eb8 <fwp_drop1+0xa8>
    7e91:	3c ff                	cmp    $0xff,%al
    7e93:	0f 84 e7 00 00 00    	je     7f80 <fwp_drop1+0x170>
    7e99:	83 e8 01             	sub    $0x1,%eax
    7e9c:	88 02                	mov    %al,(%rdx)
    7e9e:	48 83 c4 18          	add    $0x18,%rsp
    7ea2:	c3                   	ret
    7ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ea8:	66 85 c0             	test   %ax,%ax
    7eab:	74 d9                	je     7e86 <fwp_drop1+0x76>
    7ead:	48 83 c4 18          	add    $0x18,%rsp
    7eb1:	c3                   	ret
    7eb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7eb8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ebf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ec6:	48 89 f8             	mov    %rdi,%rax
    7ec9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7ecd:	48 29 c8             	sub    %rcx,%rax
    7ed0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ed4:	48 39 d0             	cmp    %rdx,%rax
    7ed7:	73 71                	jae    7f4a <fwp_drop1+0x13a>
    7ed9:	49 89 c2             	mov    %rax,%r10
    7edc:	49 c1 ea 10          	shr    $0x10,%r10
    7ee0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ee4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7ee8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7eec:	4d 85 d2             	test   %r10,%r10
    7eef:	74 59                	je     7f4a <fwp_drop1+0x13a>
    7ef1:	45 0f b6 19          	movzbl (%r9),%r11d
    7ef5:	41 80 fb 02          	cmp    $0x2,%r11b
    7ef9:	74 75                	je     7f70 <fwp_drop1+0x160>
    7efb:	41 80 fb 01          	cmp    $0x1,%r11b
    7eff:	75 49                	jne    7f4a <fwp_drop1+0x13a>
    7f01:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7f05:	0f b7 c0             	movzwl %ax,%eax
    7f08:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7f0c:	49 0f af c3          	imul   %r11,%rax
    7f10:	48 c1 e8 20          	shr    $0x20,%rax
    7f14:	4c 39 c8             	cmp    %r9,%rax
    7f17:	73 31                	jae    7f4a <fwp_drop1+0x13a>
    7f19:	49 01 c2             	add    %rax,%r10
    7f1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7f20:	75 28                	jne    7f4a <fwp_drop1+0x13a>
    7f22:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7f27:	e8 44 db ff ff       	call   5a70 <fwp_mem_free>
    7f2c:	48 8d 35 0d 39 06 00 	lea    0x6390d(%rip),%rsi        # 6b840 <fwp_heap>
    7f33:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7f38:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7f3f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7f46:	48 c1 e2 10          	shl    $0x10,%rdx
    7f4a:	4c 89 c0             	mov    %r8,%rax
    7f4d:	48 29 c8             	sub    %rcx,%rax
    7f50:	48 39 d0             	cmp    %rdx,%rax
    7f53:	0f 83 45 ff ff ff    	jae    7e9e <fwp_drop1+0x8e>
    7f59:	4c 89 c7             	mov    %r8,%rdi
    7f5c:	e9 dc fe ff ff       	jmp    7e3d <fwp_drop1+0x2d>
    7f61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f68:	c3                   	ret
    7f69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f70:	66 85 c0             	test   %ax,%ax
    7f73:	75 d5                	jne    7f4a <fwp_drop1+0x13a>
    7f75:	eb a5                	jmp    7f1c <fwp_drop1+0x10c>
    7f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f7e:	00 00 
    7f80:	48 89 d0             	mov    %rdx,%rax
    7f83:	48 c1 e8 11          	shr    $0x11,%rax
    7f87:	48 31 d0             	xor    %rdx,%rax
    7f8a:	48 89 c1             	mov    %rax,%rcx
    7f8d:	48 c1 e9 09          	shr    $0x9,%rcx
    7f91:	48 31 c8             	xor    %rcx,%rax
    7f94:	0f b6 c8             	movzbl %al,%ecx
    7f97:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7f9e:	00 
    7f9f:	48 85 c0             	test   %rax,%rax
    7fa2:	75 25                	jne    7fc9 <fwp_drop1+0x1b9>
    7fa4:	eb 5e                	jmp    8004 <fwp_drop1+0x1f4>
    7fa6:	0f 1f 40 00          	nopl   0x0(%rax)
    7faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fb1:	00 00 00 00 
    7fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fbc:	00 00 00 00 
    7fc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7fc4:	48 85 c0             	test   %rax,%rax
    7fc7:	74 3b                	je     8004 <fwp_drop1+0x1f4>
    7fc9:	48 89 c1             	mov    %rax,%rcx
    7fcc:	48 39 10             	cmp    %rdx,(%rax)
    7fcf:	75 ef                	jne    7fc0 <fwp_drop1+0x1b0>
    7fd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7fd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7fd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7fdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7fe4:	0f 85 b4 fe ff ff    	jne    7e9e <fwp_drop1+0x8e>
    7fea:	48 89 d7             	mov    %rdx,%rdi
    7fed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ff2:	e8 39 d8 ff ff       	call   5830 <fwp_rc_forget_slot>
    7ff7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ffc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7fff:	e9 9a fe ff ff       	jmp    7e9e <fwp_drop1+0x8e>
    8004:	48 8d 3d e5 79 00 00 	lea    0x79e5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    800b:	e8 40 c4 ff ff       	call   4450 <fwp_trap>

0000000000008010 <fwp_drop10>:
    8010:	48 8b 0d 01 4c 06 00 	mov    0x64c01(%rip),%rcx        # 6cc18 <fwp_heap+0x13d8>
    8017:	48 89 f8             	mov    %rdi,%rax
    801a:	48 2b 05 cf 4b 06 00 	sub    0x64bcf(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    8021:	48 c1 e1 10          	shl    $0x10,%rcx
    8025:	48 39 c8             	cmp    %rcx,%rax
    8028:	0f 83 c2 01 00 00    	jae    81f0 <fwp_drop10+0x1e0>
    802e:	48 83 ec 18          	sub    $0x18,%rsp
    8032:	48 89 fa             	mov    %rdi,%rdx
    8035:	48 8d 35 04 38 06 00 	lea    0x63804(%rip),%rsi        # 6b840 <fwp_heap>
    803c:	48 89 c1             	mov    %rax,%rcx
    803f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8046:	48 c1 e9 10          	shr    $0x10,%rcx
    804a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    804e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8052:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8056:	48 85 c9             	test   %rcx,%rcx
    8059:	74 46                	je     80a1 <fwp_drop10+0x91>
    805b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    805f:	41 80 f9 02          	cmp    $0x2,%r9b
    8063:	0f 84 d7 00 00 00    	je     8140 <fwp_drop10+0x130>
    8069:	41 80 f9 01          	cmp    $0x1,%r9b
    806d:	75 32                	jne    80a1 <fwp_drop10+0x91>
    806f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    8073:	0f b7 c0             	movzwl %ax,%eax
    8076:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    8079:	49 0f af c1          	imul   %r9,%rax
    807d:	48 c1 e8 20          	shr    $0x20,%rax
    8081:	48 39 f8             	cmp    %rdi,%rax
    8084:	73 1b                	jae    80a1 <fwp_drop10+0x91>
    8086:	48 01 c1             	add    %rax,%rcx
    8089:	0f b6 01             	movzbl (%rcx),%eax
    808c:	84 c0                	test   %al,%al
    808e:	74 11                	je     80a1 <fwp_drop10+0x91>
    8090:	3c 01                	cmp    $0x1,%al
    8092:	74 1c                	je     80b0 <fwp_drop10+0xa0>
    8094:	3c ff                	cmp    $0xff,%al
    8096:	0f 84 5c 01 00 00    	je     81f8 <fwp_drop10+0x1e8>
    809c:	83 e8 01             	sub    $0x1,%eax
    809f:	88 01                	mov    %al,(%rcx)
    80a1:	48 83 c4 18          	add    $0x18,%rsp
    80a5:	c3                   	ret
    80a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80ad:	00 00 00 
    80b0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    80b7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    80be:	48 89 d0             	mov    %rdx,%rax
    80c1:	49 89 d1             	mov    %rdx,%r9
    80c4:	48 c1 e1 10          	shl    $0x10,%rcx
    80c8:	48 29 f8             	sub    %rdi,%rax
    80cb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    80cf:	78 7f                	js     8150 <fwp_drop10+0x140>
    80d1:	48 39 c8             	cmp    %rcx,%rax
    80d4:	73 cb                	jae    80a1 <fwp_drop10+0x91>
    80d6:	48 89 c1             	mov    %rax,%rcx
    80d9:	48 c1 e9 10          	shr    $0x10,%rcx
    80dd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    80e1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    80e5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    80e9:	48 85 f6             	test   %rsi,%rsi
    80ec:	74 b3                	je     80a1 <fwp_drop10+0x91>
    80ee:	0f b6 39             	movzbl (%rcx),%edi
    80f1:	40 80 ff 02          	cmp    $0x2,%dil
    80f5:	74 39                	je     8130 <fwp_drop10+0x120>
    80f7:	40 80 ff 01          	cmp    $0x1,%dil
    80fb:	75 a4                	jne    80a1 <fwp_drop10+0x91>
    80fd:	8b 79 18             	mov    0x18(%rcx),%edi
    8100:	0f b7 c0             	movzwl %ax,%eax
    8103:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8106:	48 0f af c7          	imul   %rdi,%rax
    810a:	48 c1 e8 20          	shr    $0x20,%rax
    810e:	48 39 c8             	cmp    %rcx,%rax
    8111:	73 8e                	jae    80a1 <fwp_drop10+0x91>
    8113:	48 01 c6             	add    %rax,%rsi
    8116:	80 3e 01             	cmpb   $0x1,(%rsi)
    8119:	75 86                	jne    80a1 <fwp_drop10+0x91>
    811b:	48 89 d7             	mov    %rdx,%rdi
    811e:	48 83 c4 18          	add    $0x18,%rsp
    8122:	e9 49 d9 ff ff       	jmp    5a70 <fwp_mem_free>
    8127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    812e:	00 00 
    8130:	66 85 c0             	test   %ax,%ax
    8133:	74 e1                	je     8116 <fwp_drop10+0x106>
    8135:	48 83 c4 18          	add    $0x18,%rsp
    8139:	c3                   	ret
    813a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8140:	66 85 c0             	test   %ax,%ax
    8143:	0f 84 40 ff ff ff    	je     8089 <fwp_drop10+0x79>
    8149:	48 83 c4 18          	add    $0x18,%rsp
    814d:	c3                   	ret
    814e:	66 90                	xchg   %ax,%ax
    8150:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8154:	48 39 c8             	cmp    %rcx,%rax
    8157:	73 74                	jae    81cd <fwp_drop10+0x1bd>
    8159:	49 89 c2             	mov    %rax,%r10
    815c:	49 c1 ea 10          	shr    $0x10,%r10
    8160:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8164:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8168:	4d 8b 50 20          	mov    0x20(%r8),%r10
    816c:	4d 85 d2             	test   %r10,%r10
    816f:	74 5c                	je     81cd <fwp_drop10+0x1bd>
    8171:	45 0f b6 18          	movzbl (%r8),%r11d
    8175:	41 80 fb 02          	cmp    $0x2,%r11b
    8179:	74 6d                	je     81e8 <fwp_drop10+0x1d8>
    817b:	41 80 fb 01          	cmp    $0x1,%r11b
    817f:	75 4c                	jne    81cd <fwp_drop10+0x1bd>
    8181:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8185:	0f b7 c0             	movzwl %ax,%eax
    8188:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    818c:	49 0f af c3          	imul   %r11,%rax
    8190:	48 c1 e8 20          	shr    $0x20,%rax
    8194:	4c 39 c0             	cmp    %r8,%rax
    8197:	73 34                	jae    81cd <fwp_drop10+0x1bd>
    8199:	49 01 c2             	add    %rax,%r10
    819c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    81a0:	75 2b                	jne    81cd <fwp_drop10+0x1bd>
    81a2:	4c 89 cf             	mov    %r9,%rdi
    81a5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    81aa:	e8 c1 d8 ff ff       	call   5a70 <fwp_mem_free>
    81af:	48 8d 35 8a 36 06 00 	lea    0x6368a(%rip),%rsi        # 6b840 <fwp_heap>
    81b6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    81bb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    81c2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    81c9:	48 c1 e1 10          	shl    $0x10,%rcx
    81cd:	48 89 d0             	mov    %rdx,%rax
    81d0:	48 29 f8             	sub    %rdi,%rax
    81d3:	48 39 c8             	cmp    %rcx,%rax
    81d6:	0f 82 60 fe ff ff    	jb     803c <fwp_drop10+0x2c>
    81dc:	e9 c0 fe ff ff       	jmp    80a1 <fwp_drop10+0x91>
    81e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    81e8:	66 85 c0             	test   %ax,%ax
    81eb:	75 e0                	jne    81cd <fwp_drop10+0x1bd>
    81ed:	eb ad                	jmp    819c <fwp_drop10+0x18c>
    81ef:	90                   	nop
    81f0:	c3                   	ret
    81f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    81f8:	48 89 c8             	mov    %rcx,%rax
    81fb:	48 c1 e8 11          	shr    $0x11,%rax
    81ff:	48 31 c8             	xor    %rcx,%rax
    8202:	48 89 c2             	mov    %rax,%rdx
    8205:	48 c1 ea 09          	shr    $0x9,%rdx
    8209:	48 31 d0             	xor    %rdx,%rax
    820c:	0f b6 d0             	movzbl %al,%edx
    820f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8216:	00 
    8217:	48 85 c0             	test   %rax,%rax
    821a:	75 0d                	jne    8229 <fwp_drop10+0x219>
    821c:	eb 46                	jmp    8264 <fwp_drop10+0x254>
    821e:	66 90                	xchg   %ax,%ax
    8220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8224:	48 85 c0             	test   %rax,%rax
    8227:	74 3b                	je     8264 <fwp_drop10+0x254>
    8229:	48 89 c2             	mov    %rax,%rdx
    822c:	48 39 08             	cmp    %rcx,(%rax)
    822f:	75 ef                	jne    8220 <fwp_drop10+0x210>
    8231:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8235:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8239:	48 89 50 08          	mov    %rdx,0x8(%rax)
    823d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8244:	0f 85 57 fe ff ff    	jne    80a1 <fwp_drop10+0x91>
    824a:	48 89 cf             	mov    %rcx,%rdi
    824d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8252:	e8 d9 d5 ff ff       	call   5830 <fwp_rc_forget_slot>
    8257:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    825c:	c6 01 fe             	movb   $0xfe,(%rcx)
    825f:	e9 3d fe ff ff       	jmp    80a1 <fwp_drop10+0x91>
    8264:	48 8d 3d 85 77 00 00 	lea    0x7785(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    826b:	e8 e0 c1 ff ff       	call   4450 <fwp_trap>

0000000000008270 <f37>:
    8270:	41 57                	push   %r15
    8272:	41 56                	push   %r14
    8274:	41 55                	push   %r13
    8276:	41 54                	push   %r12
    8278:	55                   	push   %rbp
    8279:	53                   	push   %rbx
    827a:	48 83 ec 38          	sub    $0x38,%rsp
    827e:	48 8b 15 93 49 06 00 	mov    0x64993(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    8285:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    828a:	48 c1 e2 10          	shl    $0x10,%rdx
    828e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8295:	00 00 
    8297:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    829c:	48 8b 0d 4d 49 06 00 	mov    0x6494d(%rip),%rcx        # 6cbf0 <fwp_heap+0x13b0>
    82a3:	48 85 ff             	test   %rdi,%rdi
    82a6:	0f 84 1e 03 00 00    	je     85ca <f37+0x35a>
    82ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82b1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    82b5:	4c 89 e8             	mov    %r13,%rax
    82b8:	48 29 c8             	sub    %rcx,%rax
    82bb:	48 39 d0             	cmp    %rdx,%rax
    82be:	0f 83 ec 02 00 00    	jae    85b0 <f37+0x340>
    82c4:	48 89 c2             	mov    %rax,%rdx
    82c7:	48 c1 ea 10          	shr    $0x10,%rdx
    82cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82cf:	48 8b 15 62 49 06 00 	mov    0x64962(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    82d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82da:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    82de:	48 85 ff             	test   %rdi,%rdi
    82e1:	0f 84 c9 02 00 00    	je     85b0 <f37+0x340>
    82e7:	0f b6 0a             	movzbl (%rdx),%ecx
    82ea:	80 f9 02             	cmp    $0x2,%cl
    82ed:	0f 84 4d 02 00 00    	je     8540 <f37+0x2d0>
    82f3:	80 f9 01             	cmp    $0x1,%cl
    82f6:	75 24                	jne    831c <f37+0xac>
    82f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82fb:	0f b7 c0             	movzwl %ax,%eax
    82fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8301:	48 0f af c1          	imul   %rcx,%rax
    8305:	48 c1 e8 20          	shr    $0x20,%rax
    8309:	48 39 d0             	cmp    %rdx,%rax
    830c:	73 0e                	jae    831c <f37+0xac>
    830e:	48 01 c7             	add    %rax,%rdi
    8311:	0f b6 07             	movzbl (%rdi),%eax
    8314:	84 c0                	test   %al,%al
    8316:	0f 85 44 02 00 00    	jne    8560 <f37+0x2f0>
    831c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8321:	48 8b 40 10          	mov    0x10(%rax),%rax
    8325:	ba 01 00 00 00       	mov    $0x1,%edx
    832a:	48 85 c0             	test   %rax,%rax
    832d:	74 0e                	je     833d <f37+0xcd>
    832f:	90                   	nop
    8330:	48 8b 40 10          	mov    0x10(%rax),%rax
    8334:	48 83 c2 01          	add    $0x1,%rdx
    8338:	48 85 c0             	test   %rax,%rax
    833b:	75 f3                	jne    8330 <f37+0xc0>
    833d:	4d 85 ed             	test   %r13,%r13
    8340:	0f 84 9a 02 00 00    	je     85e0 <f37+0x370>
    8346:	4c 89 e8             	mov    %r13,%rax
    8349:	31 db                	xor    %ebx,%ebx
    834b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8350:	48 8b 40 10          	mov    0x10(%rax),%rax
    8354:	48 83 c3 01          	add    $0x1,%rbx
    8358:	48 85 c0             	test   %rax,%rax
    835b:	75 f3                	jne    8350 <f37+0xe0>
    835d:	48 39 d3             	cmp    %rdx,%rbx
    8360:	48 0f 47 da          	cmova  %rdx,%rbx
    8364:	48 89 d8             	mov    %rbx,%rax
    8367:	48 c1 e8 3c          	shr    $0x3c,%rax
    836b:	0f 85 7d 03 00 00    	jne    86ee <f37+0x47e>
    8371:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8375:	be 02 00 00 00       	mov    $0x2,%esi
    837a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8381:	00 
    8382:	e8 e9 db ff ff       	call   5f70 <fwp_heap_alloc>
    8387:	48 89 28             	mov    %rbp,(%rax)
    838a:	48 8b 15 87 48 06 00 	mov    0x64887(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    8391:	49 89 c4             	mov    %rax,%r12
    8394:	48 2b 05 55 48 06 00 	sub    0x64855(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    839b:	48 c1 e2 10          	shl    $0x10,%rdx
    839f:	48 39 d0             	cmp    %rdx,%rax
    83a2:	73 57                	jae    83fb <f37+0x18b>
    83a4:	48 89 c2             	mov    %rax,%rdx
    83a7:	48 c1 ea 10          	shr    $0x10,%rdx
    83ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83af:	48 8b 15 82 48 06 00 	mov    0x64882(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    83b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83ba:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    83be:	48 85 ed             	test   %rbp,%rbp
    83c1:	74 38                	je     83fb <f37+0x18b>
    83c3:	0f b6 0a             	movzbl (%rdx),%ecx
    83c6:	80 f9 02             	cmp    $0x2,%cl
    83c9:	0f 84 d1 01 00 00    	je     85a0 <f37+0x330>
    83cf:	80 f9 01             	cmp    $0x1,%cl
    83d2:	75 27                	jne    83fb <f37+0x18b>
    83d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83d7:	0f b7 c0             	movzwl %ax,%eax
    83da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83dd:	48 0f af c1          	imul   %rcx,%rax
    83e1:	48 c1 e8 20          	shr    $0x20,%rax
    83e5:	48 39 d0             	cmp    %rdx,%rax
    83e8:	73 11                	jae    83fb <f37+0x18b>
    83ea:	48 01 c5             	add    %rax,%rbp
    83ed:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    83f1:	0f 84 57 02 00 00    	je     864e <f37+0x3de>
    83f7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    83fb:	48 85 db             	test   %rbx,%rbx
    83fe:	74 5d                	je     845d <f37+0x1ed>
    8400:	48 c1 e3 04          	shl    $0x4,%rbx
    8404:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8409:	4c 89 e5             	mov    %r12,%rbp
    840c:	4d 89 ef             	mov    %r13,%r15
    840f:	4c 01 e3             	add    %r12,%rbx
    8412:	0f 1f 00             	nopl   (%rax)
    8415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    841c:	00 00 00 00 
    8420:	49 8b 46 08          	mov    0x8(%r14),%rax
    8424:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8428:	48 83 c5 10          	add    $0x10,%rbp
    842c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8431:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8435:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8439:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    843e:	e8 8d e2 ff ff       	call   66d0 <w120>
    8443:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8448:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    844c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8450:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8454:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8458:	48 39 dd             	cmp    %rbx,%rbp
    845b:	75 c3                	jne    8420 <f37+0x1b0>
    845d:	4c 89 ef             	mov    %r13,%rdi
    8460:	e8 8b ed ff ff       	call   71f0 <fwp_drop4>
    8465:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    846a:	e8 81 ed ff ff       	call   71f0 <fwp_drop4>
    846f:	4c 89 e7             	mov    %r12,%rdi
    8472:	e8 d9 e3 ff ff       	call   6850 <w176.constprop.0>
    8477:	4c 89 e7             	mov    %r12,%rdi
    847a:	48 89 c3             	mov    %rax,%rbx
    847d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8483:	e8 88 fb ff ff       	call   8010 <fwp_drop10>
    8488:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    848e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8493:	31 ff                	xor    %edi,%edi
    8495:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    849a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    849e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    84a3:	e8 b8 dc ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    84a8:	48 8b 15 69 47 06 00 	mov    0x64769(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    84af:	48 89 c5             	mov    %rax,%rbp
    84b2:	48 2b 05 37 47 06 00 	sub    0x64737(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    84b9:	48 c1 e2 10          	shl    $0x10,%rdx
    84bd:	48 39 d0             	cmp    %rdx,%rax
    84c0:	73 55                	jae    8517 <f37+0x2a7>
    84c2:	48 89 c2             	mov    %rax,%rdx
    84c5:	48 c1 ea 10          	shr    $0x10,%rdx
    84c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84cd:	48 8b 15 64 47 06 00 	mov    0x64764(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    84d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84d8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    84dc:	48 85 db             	test   %rbx,%rbx
    84df:	74 36                	je     8517 <f37+0x2a7>
    84e1:	0f b6 0a             	movzbl (%rdx),%ecx
    84e4:	80 f9 02             	cmp    $0x2,%cl
    84e7:	0f 84 a3 00 00 00    	je     8590 <f37+0x320>
    84ed:	80 f9 01             	cmp    $0x1,%cl
    84f0:	75 25                	jne    8517 <f37+0x2a7>
    84f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84f5:	0f b7 c0             	movzwl %ax,%eax
    84f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84fb:	48 0f af c1          	imul   %rcx,%rax
    84ff:	48 c1 e8 20          	shr    $0x20,%rax
    8503:	48 39 d0             	cmp    %rdx,%rax
    8506:	73 0f                	jae    8517 <f37+0x2a7>
    8508:	48 01 c3             	add    %rax,%rbx
    850b:	80 3b ff             	cmpb   $0xff,(%rbx)
    850e:	0f 84 2d 01 00 00    	je     8641 <f37+0x3d1>
    8514:	c6 03 01             	movb   $0x1,(%rbx)
    8517:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    851c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8523:	00 00 
    8525:	0f 85 cf 01 00 00    	jne    86fa <f37+0x48a>
    852b:	48 83 c4 38          	add    $0x38,%rsp
    852f:	48 89 e8             	mov    %rbp,%rax
    8532:	5b                   	pop    %rbx
    8533:	5d                   	pop    %rbp
    8534:	41 5c                	pop    %r12
    8536:	41 5d                	pop    %r13
    8538:	41 5e                	pop    %r14
    853a:	41 5f                	pop    %r15
    853c:	c3                   	ret
    853d:	0f 1f 00             	nopl   (%rax)
    8540:	66 85 c0             	test   %ax,%ax
    8543:	0f 85 d3 fd ff ff    	jne    831c <f37+0xac>
    8549:	0f b6 07             	movzbl (%rdi),%eax
    854c:	84 c0                	test   %al,%al
    854e:	0f 84 c8 fd ff ff    	je     831c <f37+0xac>
    8554:	90                   	nop
    8555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    855c:	00 00 00 00 
    8560:	8b 15 a2 4f 06 00    	mov    0x64fa2(%rip),%edx        # 6d508 <iteration_active>
    8566:	85 d2                	test   %edx,%edx
    8568:	75 56                	jne    85c0 <f37+0x350>
    856a:	3c fd                	cmp    $0xfd,%al
    856c:	0f 87 4b 01 00 00    	ja     86bd <f37+0x44d>
    8572:	83 c0 01             	add    $0x1,%eax
    8575:	88 07                	mov    %al,(%rdi)
    8577:	31 d2                	xor    %edx,%edx
    8579:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    857f:	0f 85 97 fd ff ff    	jne    831c <f37+0xac>
    8585:	e9 b3 fd ff ff       	jmp    833d <f37+0xcd>
    858a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8590:	66 85 c0             	test   %ax,%ax
    8593:	0f 85 7e ff ff ff    	jne    8517 <f37+0x2a7>
    8599:	e9 6d ff ff ff       	jmp    850b <f37+0x29b>
    859e:	66 90                	xchg   %ax,%ax
    85a0:	66 85 c0             	test   %ax,%ax
    85a3:	0f 85 52 fe ff ff    	jne    83fb <f37+0x18b>
    85a9:	e9 3f fe ff ff       	jmp    83ed <f37+0x17d>
    85ae:	66 90                	xchg   %ax,%ax
    85b0:	4c 89 e8             	mov    %r13,%rax
    85b3:	e9 6d fd ff ff       	jmp    8325 <f37+0xb5>
    85b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85bf:	00 
    85c0:	48 83 05 28 4f 06 00 	addq   $0x1,0x64f28(%rip)        # 6d4f0 <iteration_retains>
    85c7:	01 
    85c8:	eb a0                	jmp    856a <f37+0x2fa>
    85ca:	48 f7 d9             	neg    %rcx
    85cd:	48 39 d1             	cmp    %rdx,%rcx
    85d0:	0f 82 85 00 00 00    	jb     865b <f37+0x3eb>
    85d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85dd:	00 00 00 
    85e0:	be 02 00 00 00       	mov    $0x2,%esi
    85e5:	bf 08 00 00 00       	mov    $0x8,%edi
    85ea:	e8 81 d9 ff ff       	call   5f70 <fwp_heap_alloc>
    85ef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    85f6:	48 8b 15 1b 46 06 00 	mov    0x6461b(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    85fd:	49 89 c4             	mov    %rax,%r12
    8600:	48 2b 05 e9 45 06 00 	sub    0x645e9(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    8607:	48 c1 e2 10          	shl    $0x10,%rdx
    860b:	48 39 d0             	cmp    %rdx,%rax
    860e:	0f 83 b3 00 00 00    	jae    86c7 <f37+0x457>
    8614:	48 89 c2             	mov    %rax,%rdx
    8617:	48 c1 ea 10          	shr    $0x10,%rdx
    861b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    861f:	48 8b 15 12 46 06 00 	mov    0x64612(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    8626:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    862a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    862e:	48 85 ed             	test   %rbp,%rbp
    8631:	0f 84 90 00 00 00    	je     86c7 <f37+0x457>
    8637:	31 db                	xor    %ebx,%ebx
    8639:	45 31 ed             	xor    %r13d,%r13d
    863c:	e9 82 fd ff ff       	jmp    83c3 <f37+0x153>
    8641:	48 89 df             	mov    %rbx,%rdi
    8644:	e8 e7 d1 ff ff       	call   5830 <fwp_rc_forget_slot>
    8649:	e9 c6 fe ff ff       	jmp    8514 <f37+0x2a4>
    864e:	48 89 ef             	mov    %rbp,%rdi
    8651:	e8 da d1 ff ff       	call   5830 <fwp_rc_forget_slot>
    8656:	e9 9c fd ff ff       	jmp    83f7 <f37+0x187>
    865b:	48 89 c8             	mov    %rcx,%rax
    865e:	48 c1 e8 10          	shr    $0x10,%rax
    8662:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8666:	48 8b 05 cb 45 06 00 	mov    0x645cb(%rip),%rax        # 6cc38 <fwp_heap+0x13f8>
    866d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8671:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8675:	48 85 ff             	test   %rdi,%rdi
    8678:	0f 84 62 ff ff ff    	je     85e0 <f37+0x370>
    867e:	0f b6 02             	movzbl (%rdx),%eax
    8681:	3c 02                	cmp    $0x2,%al
    8683:	74 4a                	je     86cf <f37+0x45f>
    8685:	3c 01                	cmp    $0x1,%al
    8687:	0f 85 53 ff ff ff    	jne    85e0 <f37+0x370>
    868d:	0f b7 c1             	movzwl %cx,%eax
    8690:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8693:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8696:	48 0f af c1          	imul   %rcx,%rax
    869a:	48 c1 e8 20          	shr    $0x20,%rax
    869e:	48 39 d0             	cmp    %rdx,%rax
    86a1:	0f 83 39 ff ff ff    	jae    85e0 <f37+0x370>
    86a7:	48 01 c7             	add    %rax,%rdi
    86aa:	0f b6 07             	movzbl (%rdi),%eax
    86ad:	84 c0                	test   %al,%al
    86af:	0f 84 2b ff ff ff    	je     85e0 <f37+0x370>
    86b5:	45 31 ed             	xor    %r13d,%r13d
    86b8:	e9 a3 fe ff ff       	jmp    8560 <f37+0x2f0>
    86bd:	e8 4e d0 ff ff       	call   5710 <fwp_rc_wide_dup>
    86c2:	e9 b0 fe ff ff       	jmp    8577 <f37+0x307>
    86c7:	45 31 ed             	xor    %r13d,%r13d
    86ca:	e9 8e fd ff ff       	jmp    845d <f37+0x1ed>
    86cf:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    86d5:	49 89 cd             	mov    %rcx,%r13
    86d8:	0f 85 02 ff ff ff    	jne    85e0 <f37+0x370>
    86de:	0f b6 07             	movzbl (%rdi),%eax
    86e1:	84 c0                	test   %al,%al
    86e3:	0f 85 77 fe ff ff    	jne    8560 <f37+0x2f0>
    86e9:	e9 f2 fe ff ff       	jmp    85e0 <f37+0x370>
    86ee:	48 8d 3d f6 6a 00 00 	lea    0x6af6(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    86f5:	e8 56 bd ff ff       	call   4450 <fwp_trap>
    86fa:	e8 51 ad ff ff       	call   3450 <__stack_chk_fail@plt>
    86ff:	90                   	nop

0000000000008700 <fwp_owned_entry37>:
    8700:	f3 0f 1e fa          	endbr64
    8704:	48 8b 3f             	mov    (%rdi),%rdi
    8707:	e9 64 fb ff ff       	jmp    8270 <f37>
    870c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008710 <e37>:
    8710:	f3 0f 1e fa          	endbr64
    8714:	53                   	push   %rbx
    8715:	48 8b 1f             	mov    (%rdi),%rbx
    8718:	48 89 df             	mov    %rbx,%rdi
    871b:	e8 d0 e1 ff ff       	call   68f0 <fwp_rc_share>
    8720:	48 89 df             	mov    %rbx,%rdi
    8723:	e8 48 fb ff ff       	call   8270 <f37>
    8728:	48 89 c3             	mov    %rax,%rbx
    872b:	48 89 c7             	mov    %rax,%rdi
    872e:	e8 bd e1 ff ff       	call   68f0 <fwp_rc_share>
    8733:	48 89 d8             	mov    %rbx,%rax
    8736:	5b                   	pop    %rbx
    8737:	c3                   	ret
    8738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    873f:	00 

0000000000008740 <fwp_write>:
    8740:	41 57                	push   %r15
    8742:	41 56                	push   %r14
    8744:	41 55                	push   %r13
    8746:	41 54                	push   %r12
    8748:	55                   	push   %rbp
    8749:	53                   	push   %rbx
    874a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8751:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8758:	00 00 
    875a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8761:	00 
    8762:	49 89 d4             	mov    %rdx,%r12
    8765:	8b 12                	mov    (%rdx),%edx
    8767:	83 fa 19             	cmp    $0x19,%edx
    876a:	77 6a                	ja     87d6 <fwp_write+0x96>
    876c:	48 89 f5             	mov    %rsi,%rbp
    876f:	89 d0                	mov    %edx,%eax
    8771:	89 ce                	mov    %ecx,%esi
    8773:	48 89 fb             	mov    %rdi,%rbx
    8776:	48 8d 0d 53 75 00 00 	lea    0x7553(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    877d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8781:	48 01 c8             	add    %rcx,%rax
    8784:	3e ff e0             	notrack jmp *%rax
    8787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    878e:	00 00 
    8790:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8794:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8798:	48 89 ca             	mov    %rcx,%rdx
    879b:	48 85 c9             	test   %rcx,%rcx
    879e:	0f 88 9c 0c 00 00    	js     9440 <fwp_write+0xd00>
    87a4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    87ab:	00 
    87ac:	48 89 c6             	mov    %rax,%rsi
    87af:	4c 89 e7             	mov    %r12,%rdi
    87b2:	e8 89 b2 ff ff       	call   3a40 <fwp_fmt_u128>
    87b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87be:	00 00 
    87c0:	4c 89 e7             	mov    %r12,%rdi
    87c3:	e8 78 ac ff ff       	call   3440 <strlen@plt>
    87c8:	4c 89 e6             	mov    %r12,%rsi
    87cb:	48 89 df             	mov    %rbx,%rdi
    87ce:	48 89 c2             	mov    %rax,%rdx
    87d1:	e8 1a b9 ff ff       	call   40f0 <buf_put>
    87d6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87dd:	00 
    87de:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87e5:	00 00 
    87e7:	0f 85 28 04 00 00    	jne    8c15 <fwp_write+0x4d5>
    87ed:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    87f4:	5b                   	pop    %rbx
    87f5:	5d                   	pop    %rbp
    87f6:	41 5c                	pop    %r12
    87f8:	41 5d                	pop    %r13
    87fa:	41 5e                	pop    %r14
    87fc:	41 5f                	pop    %r15
    87fe:	c3                   	ret
    87ff:	90                   	nop
    8800:	49 89 e9             	mov    %rbp,%r9
    8803:	4c 8d 05 0b 6a 00 00 	lea    0x6a0b(%rip),%r8        # f215 <_IO_stdin_used+0x215>
    880a:	b9 00 02 00 00       	mov    $0x200,%ecx
    880f:	ba 02 00 00 00       	mov    $0x2,%edx
    8814:	be 00 02 00 00       	mov    $0x200,%esi
    8819:	31 c0                	xor    %eax,%eax
    881b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8822:	00 
    8823:	e8 78 ab ff ff       	call   33a0 <__snprintf_chk@plt>
    8828:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    882f:	00 
    8830:	e8 0b ac ff ff       	call   3440 <strlen@plt>
    8835:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    883c:	00 
    883d:	48 89 df             	mov    %rbx,%rdi
    8840:	48 89 c2             	mov    %rax,%rdx
    8843:	e8 a8 b8 ff ff       	call   40f0 <buf_put>
    8848:	eb 8c                	jmp    87d6 <fwp_write+0x96>
    884a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8850:	49 89 e9             	mov    %rbp,%r9
    8853:	4c 8d 05 b6 69 00 00 	lea    0x69b6(%rip),%r8        # f210 <_IO_stdin_used+0x210>
    885a:	eb ae                	jmp    880a <fwp_write+0xca>
    885c:	0f 1f 40 00          	nopl   0x0(%rax)
    8860:	83 fa 13             	cmp    $0x13,%edx
    8863:	48 8d 05 9c 69 00 00 	lea    0x699c(%rip),%rax        # f206 <_IO_stdin_used+0x206>
    886a:	48 8d 35 9a 69 00 00 	lea    0x699a(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    8871:	ba 04 00 00 00       	mov    $0x4,%edx
    8876:	48 0f 44 f0          	cmove  %rax,%rsi
    887a:	45 31 ed             	xor    %r13d,%r13d
    887d:	e8 6e b8 ff ff       	call   40f0 <buf_put>
    8882:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8887:	0f 84 a3 08 00 00    	je     9130 <fwp_write+0x9f0>
    888d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8892:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8897:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    889c:	48 89 df             	mov    %rbx,%rdi
    889f:	49 0f 44 c5          	cmove  %r13,%rax
    88a3:	31 c9                	xor    %ecx,%ecx
    88a5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    88aa:	e8 91 fe ff ff       	call   8740 <fwp_write>
    88af:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    88b4:	0f 84 6e 09 00 00    	je     9228 <fwp_write+0xae8>
    88ba:	49 83 c5 01          	add    $0x1,%r13
    88be:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    88c2:	0f 83 68 08 00 00    	jae    9130 <fwp_write+0x9f0>
    88c8:	ba 02 00 00 00       	mov    $0x2,%edx
    88cd:	48 8d 35 81 69 00 00 	lea    0x6981(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    88d4:	48 89 df             	mov    %rbx,%rdi
    88d7:	e8 14 b8 ff ff       	call   40f0 <buf_put>
    88dc:	eb af                	jmp    888d <fwp_write+0x14d>
    88de:	66 90                	xchg   %ax,%ax
    88e0:	ba 06 00 00 00       	mov    $0x6,%edx
    88e5:	48 8d 35 42 69 00 00 	lea    0x6942(%rip),%rsi        # f22e <_IO_stdin_used+0x22e>
    88ec:	48 83 c5 10          	add    $0x10,%rbp
    88f0:	e8 fb b7 ff ff       	call   40f0 <buf_put>
    88f5:	48 89 ef             	mov    %rbp,%rdi
    88f8:	e8 43 ab ff ff       	call   3440 <strlen@plt>
    88fd:	48 89 ee             	mov    %rbp,%rsi
    8900:	48 89 df             	mov    %rbx,%rdi
    8903:	48 89 c2             	mov    %rax,%rdx
    8906:	e8 e5 b7 ff ff       	call   40f0 <buf_put>
    890b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8910:	ba 01 00 00 00       	mov    $0x1,%edx
    8915:	48 89 df             	mov    %rbx,%rdi
    8918:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    891d:	e8 ce b7 ff ff       	call   40f0 <buf_put>
    8922:	e9 af fe ff ff       	jmp    87d6 <fwp_write+0x96>
    8927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    892e:	00 00 
    8930:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8937:	00 
    8938:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    893f:	00 00 
    8941:	0f 85 ce 02 00 00    	jne    8c15 <fwp_write+0x4d5>
    8947:	ba 0a 00 00 00       	mov    $0xa,%edx
    894c:	48 8d 35 c7 68 00 00 	lea    0x68c7(%rip),%rsi        # f21a <_IO_stdin_used+0x21a>
    8953:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    895a:	48 89 df             	mov    %rbx,%rdi
    895d:	5b                   	pop    %rbx
    895e:	5d                   	pop    %rbp
    895f:	41 5c                	pop    %r12
    8961:	41 5d                	pop    %r13
    8963:	41 5e                	pop    %r14
    8965:	41 5f                	pop    %r15
    8967:	e9 84 b7 ff ff       	jmp    40f0 <buf_put>
    896c:	0f 1f 40 00          	nopl   0x0(%rax)
    8970:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8975:	4d 85 ed             	test   %r13,%r13
    8978:	0f 84 02 0c 00 00    	je     9580 <fwp_write+0xe40>
    897e:	48 8d 35 dd 68 00 00 	lea    0x68dd(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    8985:	4c 89 ef             	mov    %r13,%rdi
    8988:	e8 93 ab ff ff       	call   3520 <strcmp@plt>
    898d:	41 89 c1             	mov    %eax,%r9d
    8990:	85 c0                	test   %eax,%eax
    8992:	0f 84 6c 0c 00 00    	je     9604 <fwp_write+0xec4>
    8998:	4c 89 ef             	mov    %r13,%rdi
    899b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    89a0:	e8 9b aa ff ff       	call   3440 <strlen@plt>
    89a5:	4c 89 ee             	mov    %r13,%rsi
    89a8:	48 89 df             	mov    %rbx,%rdi
    89ab:	48 89 c2             	mov    %rax,%rdx
    89ae:	e8 3d b7 ff ff       	call   40f0 <buf_put>
    89b3:	ba 01 00 00 00       	mov    $0x1,%edx
    89b8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89bd:	48 89 df             	mov    %rbx,%rdi
    89c0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    89c5:	e8 26 b7 ff ff       	call   40f0 <buf_put>
    89ca:	ba 01 00 00 00       	mov    $0x1,%edx
    89cf:	4c 89 fe             	mov    %r15,%rsi
    89d2:	48 89 df             	mov    %rbx,%rdi
    89d5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    89da:	e8 11 b7 ff ff       	call   40f0 <buf_put>
    89df:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    89e4:	45 31 f6             	xor    %r14d,%r14d
    89e7:	85 d2                	test   %edx,%edx
    89e9:	0f 8e 81 0a 00 00    	jle    9470 <fwp_write+0xd30>
    89ef:	45 31 ed             	xor    %r13d,%r13d
    89f2:	4d 85 ed             	test   %r13,%r13
    89f5:	0f 85 75 07 00 00    	jne    9170 <fwp_write+0xa30>
    89fb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8a02:	00 
    8a03:	45 85 f6             	test   %r14d,%r14d
    8a06:	0f 84 84 07 00 00    	je     9190 <fwp_write+0xa50>
    8a0c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8a11:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8a16:	48 89 df             	mov    %rbx,%rdi
    8a19:	49 83 c5 01          	add    $0x1,%r13
    8a1d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8a21:	31 c9                	xor    %ecx,%ecx
    8a23:	e8 18 fd ff ff       	call   8740 <fwp_write>
    8a28:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8a2d:	7f c3                	jg     89f2 <fwp_write+0x2b2>
    8a2f:	45 85 f6             	test   %r14d,%r14d
    8a32:	0f 84 38 0a 00 00    	je     9470 <fwp_write+0xd30>
    8a38:	b8 29 00 00 00       	mov    $0x29,%eax
    8a3d:	ba 01 00 00 00       	mov    $0x1,%edx
    8a42:	4c 89 fe             	mov    %r15,%rsi
    8a45:	48 89 df             	mov    %rbx,%rdi
    8a48:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8a4c:	e8 9f b6 ff ff       	call   40f0 <buf_put>
    8a51:	e9 80 fd ff ff       	jmp    87d6 <fwp_write+0x96>
    8a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a5d:	00 00 00 
    8a60:	ba 01 00 00 00       	mov    $0x1,%edx
    8a65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a6a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8a6f:	e8 7c b6 ff ff       	call   40f0 <buf_put>
    8a74:	48 85 ed             	test   %rbp,%rbp
    8a77:	0f 84 93 06 00 00    	je     9110 <fwp_write+0x9d0>
    8a7d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8a81:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8a86:	31 c9                	xor    %ecx,%ecx
    8a88:	48 89 df             	mov    %rbx,%rdi
    8a8b:	e8 b0 fc ff ff       	call   8740 <fwp_write>
    8a90:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8a94:	48 85 ed             	test   %rbp,%rbp
    8a97:	0f 84 73 06 00 00    	je     9110 <fwp_write+0x9d0>
    8a9d:	ba 02 00 00 00       	mov    $0x2,%edx
    8aa2:	48 8d 35 ac 67 00 00 	lea    0x67ac(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8aa9:	48 89 df             	mov    %rbx,%rdi
    8aac:	e8 3f b6 ff ff       	call   40f0 <buf_put>
    8ab1:	eb ca                	jmp    8a7d <fwp_write+0x33d>
    8ab3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ab8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8abc:	85 f6                	test   %esi,%esi
    8abe:	0f 84 fc 07 00 00    	je     92c0 <fwp_write+0xb80>
    8ac4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8acb:	00 
    8acc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8ad3:	00 00 
    8ad5:	0f 85 3a 01 00 00    	jne    8c15 <fwp_write+0x4d5>
    8adb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8adf:	4c 89 ea             	mov    %r13,%rdx
    8ae2:	e9 6c fe ff ff       	jmp    8953 <fwp_write+0x213>
    8ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8aee:	00 00 
    8af0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8af5:	ba 01 00 00 00       	mov    $0x1,%edx
    8afa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8aff:	48 89 ee             	mov    %rbp,%rsi
    8b02:	e8 e9 b5 ff ff       	call   40f0 <buf_put>
    8b07:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8b0c:	4c 89 e7             	mov    %r12,%rdi
    8b0f:	e8 2c a9 ff ff       	call   3440 <strlen@plt>
    8b14:	4c 89 e6             	mov    %r12,%rsi
    8b17:	48 89 df             	mov    %rbx,%rdi
    8b1a:	48 89 c2             	mov    %rax,%rdx
    8b1d:	e8 ce b5 ff ff       	call   40f0 <buf_put>
    8b22:	ba 01 00 00 00       	mov    $0x1,%edx
    8b27:	48 89 ee             	mov    %rbp,%rsi
    8b2a:	48 89 df             	mov    %rbx,%rdi
    8b2d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8b32:	e8 b9 b5 ff ff       	call   40f0 <buf_put>
    8b37:	e9 9a fc ff ff       	jmp    87d6 <fwp_write+0x96>
    8b3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b40:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8b45:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8b49:	0f 8a 8e 0b 00 00    	jp     96dd <fwp_write+0xf9d>
    8b4f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b53:	66 0f 54 05 b5 72 00 	andpd  0x72b5(%rip),%xmm0        # fe10 <msg.8+0xd0>
    8b5a:	00 
    8b5b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8b60:	66 0f 2e 05 10 72 00 	ucomisd 0x7210(%rip),%xmm0        # fd78 <msg.8+0x38>
    8b67:	00 
    8b68:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8b6f:	00 
    8b70:	0f 87 b2 09 00 00    	ja     9528 <fwp_write+0xde8>
    8b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b7d:	00 00 00 
    8b80:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b84:	89 ee                	mov    %ebp,%esi
    8b86:	4c 89 e7             	mov    %r12,%rdi
    8b89:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8b8e:	e8 dd bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8b93:	31 f6                	xor    %esi,%esi
    8b95:	4c 89 e7             	mov    %r12,%rdi
    8b98:	e8 63 a8 ff ff       	call   3400 <strtod@plt>
    8b9d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8ba2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8ba6:	7a 06                	jp     8bae <fwp_write+0x46e>
    8ba8:	0f 84 e9 01 00 00    	je     8d97 <fwp_write+0x657>
    8bae:	83 c5 01             	add    $0x1,%ebp
    8bb1:	83 fd 12             	cmp    $0x12,%ebp
    8bb4:	75 ca                	jne    8b80 <fwp_write+0x440>
    8bb6:	be 11 00 00 00       	mov    $0x11,%esi
    8bbb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8bbf:	4c 89 e7             	mov    %r12,%rdi
    8bc2:	e8 a9 bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8bc7:	e9 cb 01 00 00       	jmp    8d97 <fwp_write+0x657>
    8bcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8bd0:	48 83 fd 01          	cmp    $0x1,%rbp
    8bd4:	0f 84 e6 08 00 00    	je     94c0 <fwp_write+0xd80>
    8bda:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8bde:	b8 02 00 00 00       	mov    $0x2,%eax
    8be3:	ba 01 00 00 00       	mov    $0x1,%edx
    8be8:	48 0f 44 d0          	cmove  %rax,%rdx
    8bec:	48 8d 35 0b 66 00 00 	lea    0x660b(%rip),%rsi        # f1fe <_IO_stdin_used+0x1fe>
    8bf3:	48 8d 05 09 66 00 00 	lea    0x6609(%rip),%rax        # f203 <_IO_stdin_used+0x203>
    8bfa:	48 0f 44 f0          	cmove  %rax,%rsi
    8bfe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c05:	00 
    8c06:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c0d:	00 00 
    8c0f:	0f 84 3e fd ff ff    	je     8953 <fwp_write+0x213>
    8c15:	e8 36 a8 ff ff       	call   3450 <__stack_chk_fail@plt>
    8c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c20:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8c25:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8c2a:	e8 01 b4 ff ff       	call   4030 <buf_grow>
    8c2f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8c33:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8c39:	4c 03 0b             	add    (%rbx),%r9
    8c3c:	66 45 89 11          	mov    %r10w,(%r9)
    8c40:	45 85 e4             	test   %r12d,%r12d
    8c43:	0f 8e 07 05 00 00    	jle    9150 <fwp_write+0xa10>
    8c49:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8c50:	55 55 55 
    8c53:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8c58:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8c5f:	aa aa aa 
    8c62:	49 83 c1 01          	add    $0x1,%r9
    8c66:	eb 45                	jmp    8cad <fwp_write+0x56d>
    8c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c6f:	00 
    8c70:	be 01 00 00 00       	mov    $0x1,%esi
    8c75:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8c7a:	88 07                	mov    %al,(%rdi)
    8c7c:	48 89 e8             	mov    %rbp,%rax
    8c7f:	49 f7 e8             	imul   %r8
    8c82:	48 89 e8             	mov    %rbp,%rax
    8c85:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c89:	48 29 c2             	sub    %rax,%rdx
    8c8c:	48 85 c9             	test   %rcx,%rcx
    8c8f:	0f 95 c0             	setne  %al
    8c92:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8c96:	48 83 ef 01          	sub    $0x1,%rdi
    8c9a:	48 21 c5             	and    %rax,%rbp
    8c9d:	48 29 ea             	sub    %rbp,%rdx
    8ca0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8ca4:	49 39 f9             	cmp    %rdi,%r9
    8ca7:	0f 84 a3 04 00 00    	je     9150 <fwp_write+0xa10>
    8cad:	48 89 e8             	mov    %rbp,%rax
    8cb0:	49 f7 e8             	imul   %r8
    8cb3:	48 89 e8             	mov    %rbp,%rax
    8cb6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8cba:	48 89 d1             	mov    %rdx,%rcx
    8cbd:	48 29 c1             	sub    %rax,%rcx
    8cc0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8cc4:	48 89 e9             	mov    %rbp,%rcx
    8cc7:	48 29 c1             	sub    %rax,%rcx
    8cca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8cce:	49 f7 e2             	mul    %r10
    8cd1:	b8 30 00 00 00       	mov    $0x30,%eax
    8cd6:	48 89 d6             	mov    %rdx,%rsi
    8cd9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8cdd:	48 d1 ee             	shr    $1,%rsi
    8ce0:	48 01 f2             	add    %rsi,%rdx
    8ce3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8ce7:	48 29 d6             	sub    %rdx,%rsi
    8cea:	74 8e                	je     8c7a <fwp_write+0x53a>
    8cec:	48 83 fe 01          	cmp    $0x1,%rsi
    8cf0:	0f 85 7a ff ff ff    	jne    8c70 <fwp_write+0x530>
    8cf6:	31 f6                	xor    %esi,%esi
    8cf8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8cfd:	e9 78 ff ff ff       	jmp    8c7a <fwp_write+0x53a>
    8d02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d08:	66 0f 6e cd          	movd   %ebp,%xmm1
    8d0c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8d0f:	0f 8a c8 09 00 00    	jp     96dd <fwp_write+0xf9d>
    8d15:	0f 28 c1             	movaps %xmm1,%xmm0
    8d18:	0f 54 05 e1 70 00 00 	andps  0x70e1(%rip),%xmm0        # fe00 <msg.8+0xc0>
    8d1f:	0f 2e 05 de 62 00 00 	ucomiss 0x62de(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8d26:	0f 87 24 08 00 00    	ja     9550 <fwp_write+0xe10>
    8d2c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8d30:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8d36:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8d3d:	00 
    8d3e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8d42:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d4e:	00 00 
    8d50:	44 89 ee             	mov    %r13d,%esi
    8d53:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8d58:	4c 89 e7             	mov    %r12,%rdi
    8d5b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8d60:	e8 0b ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8d65:	31 f6                	xor    %esi,%esi
    8d67:	4c 89 e7             	mov    %r12,%rdi
    8d6a:	e8 31 a7 ff ff       	call   34a0 <strtof@plt>
    8d6f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8d74:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8d77:	7a 02                	jp     8d7b <fwp_write+0x63b>
    8d79:	74 1c                	je     8d97 <fwp_write+0x657>
    8d7b:	41 83 c5 01          	add    $0x1,%r13d
    8d7f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8d83:	75 cb                	jne    8d50 <fwp_write+0x610>
    8d85:	be 09 00 00 00       	mov    $0x9,%esi
    8d8a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8d8f:	4c 89 e7             	mov    %r12,%rdi
    8d92:	e8 d9 b9 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8d97:	4c 89 e7             	mov    %r12,%rdi
    8d9a:	e8 11 b4 ff ff       	call   41b0 <fwp_finish_float>
    8d9f:	e9 1c fa ff ff       	jmp    87c0 <fwp_write+0x80>
    8da4:	0f 1f 40 00          	nopl   0x0(%rax)
    8da8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8dac:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8db0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8db7:	00 
    8db8:	48 89 ef             	mov    %rbp,%rdi
    8dbb:	e8 80 ac ff ff       	call   3a40 <fwp_fmt_u128>
    8dc0:	48 89 ef             	mov    %rbp,%rdi
    8dc3:	e8 78 a6 ff ff       	call   3440 <strlen@plt>
    8dc8:	48 89 ee             	mov    %rbp,%rsi
    8dcb:	48 89 df             	mov    %rbx,%rdi
    8dce:	48 89 c2             	mov    %rax,%rdx
    8dd1:	e8 1a b3 ff ff       	call   40f0 <buf_put>
    8dd6:	e9 fb f9 ff ff       	jmp    87d6 <fwp_write+0x96>
    8ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8de0:	ba 06 00 00 00       	mov    $0x6,%edx
    8de5:	48 8d 35 6c 64 00 00 	lea    0x646c(%rip),%rsi        # f258 <_IO_stdin_used+0x258>
    8dec:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8df2:	e8 f9 b2 ff ff       	call   40f0 <buf_put>
    8df7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8dfe:	ff ff 7f 
    8e01:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e05:	0f 84 86 02 00 00    	je     9091 <fwp_write+0x951>
    8e0b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e10:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e14:	48 85 d2             	test   %rdx,%rdx
    8e17:	0f 84 ae 00 00 00    	je     8ecb <fwp_write+0x78b>
    8e1d:	8b 0a                	mov    (%rdx),%ecx
    8e1f:	83 f9 1c             	cmp    $0x1c,%ecx
    8e22:	0f 84 58 06 00 00    	je     9480 <fwp_write+0xd40>
    8e28:	83 f9 1b             	cmp    $0x1b,%ecx
    8e2b:	0f 87 9a 00 00 00    	ja     8ecb <fwp_write+0x78b>
    8e31:	be 01 00 00 00       	mov    $0x1,%esi
    8e36:	48 d3 e6             	shl    %cl,%rsi
    8e39:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8e3f:	0f 85 4b 04 00 00    	jne    9290 <fwp_write+0xb50>
    8e45:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8e4b:	0f 85 0f 04 00 00    	jne    9260 <fwp_write+0xb20>
    8e51:	83 e6 21             	and    $0x21,%esi
    8e54:	74 75                	je     8ecb <fwp_write+0x78b>
    8e56:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8e5b:	48 85 ff             	test   %rdi,%rdi
    8e5e:	79 07                	jns    8e67 <fwp_write+0x727>
    8e60:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8e64:	4c 01 ee             	add    %r13,%rsi
    8e67:	48 0f be 3e          	movsbq (%rsi),%rdi
    8e6b:	85 c9                	test   %ecx,%ecx
    8e6d:	40 0f b6 f7          	movzbl %dil,%esi
    8e71:	48 0f 44 f7          	cmove  %rdi,%rsi
    8e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e7c:	00 00 00 00 
    8e80:	31 c9                	xor    %ecx,%ecx
    8e82:	48 89 df             	mov    %rbx,%rdi
    8e85:	49 83 c5 01          	add    $0x1,%r13
    8e89:	e8 b2 f8 ff ff       	call   8740 <fwp_write>
    8e8e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e95:	ff ff 7f 
    8e98:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e9c:	49 39 d5             	cmp    %rdx,%r13
    8e9f:	0f 83 ec 01 00 00    	jae    9091 <fwp_write+0x951>
    8ea5:	ba 02 00 00 00       	mov    $0x2,%edx
    8eaa:	48 89 df             	mov    %rbx,%rdi
    8ead:	48 8d 35 a1 63 00 00 	lea    0x63a1(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8eb4:	e8 37 b2 ff ff       	call   40f0 <buf_put>
    8eb9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ebe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8ec2:	48 85 d2             	test   %rdx,%rdx
    8ec5:	0f 85 52 ff ff ff    	jne    8e1d <fwp_write+0x6dd>
    8ecb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8ed0:	48 85 ff             	test   %rdi,%rdi
    8ed3:	0f 88 cf 05 00 00    	js     94a8 <fwp_write+0xd68>
    8ed9:	48 8b 31             	mov    (%rcx),%rsi
    8edc:	eb a2                	jmp    8e80 <fwp_write+0x740>
    8ede:	66 90                	xchg   %ax,%ax
    8ee0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ee7:	00 
    8ee8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8eef:	00 00 
    8ef1:	0f 85 1e fd ff ff    	jne    8c15 <fwp_write+0x4d5>
    8ef7:	ba 08 00 00 00       	mov    $0x8,%edx
    8efc:	48 8d 35 22 63 00 00 	lea    0x6322(%rip),%rsi        # f225 <_IO_stdin_used+0x225>
    8f03:	e9 4b fa ff ff       	jmp    8953 <fwp_write+0x213>
    8f08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f0f:	00 
    8f10:	89 e8                	mov    %ebp,%eax
    8f12:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8f19:	76 03                	jbe    8f1e <fwp_write+0x7de>
    8f1b:	8b 45 00             	mov    0x0(%rbp),%eax
    8f1e:	41 89 c6             	mov    %eax,%r14d
    8f21:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8f26:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8f2b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8f2f:	4c 89 ef             	mov    %r13,%rdi
    8f32:	e8 09 a5 ff ff       	call   3440 <strlen@plt>
    8f37:	4c 89 ee             	mov    %r13,%rsi
    8f3a:	48 89 df             	mov    %rbx,%rdi
    8f3d:	48 89 c2             	mov    %rax,%rdx
    8f40:	e8 ab b1 ff ff       	call   40f0 <buf_put>
    8f45:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f4a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8f4e:	85 f6                	test   %esi,%esi
    8f50:	0f 8e 80 f8 ff ff    	jle    87d6 <fwp_write+0x96>
    8f56:	45 31 ed             	xor    %r13d,%r13d
    8f59:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8f5e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8f63:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f68:	ba 01 00 00 00       	mov    $0x1,%edx
    8f6d:	4c 89 fe             	mov    %r15,%rsi
    8f70:	48 89 04 24          	mov    %rax,(%rsp)
    8f74:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8f79:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8f7d:	48 89 df             	mov    %rbx,%rdi
    8f80:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8f84:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8f89:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8f8e:	e8 5d b1 ff ff       	call   40f0 <buf_put>
    8f93:	41 8b 06             	mov    (%r14),%eax
    8f96:	83 f8 0e             	cmp    $0xe,%eax
    8f99:	0f 84 71 02 00 00    	je     9210 <fwp_write+0xad0>
    8f9f:	83 f8 10             	cmp    $0x10,%eax
    8fa2:	0f 84 38 02 00 00    	je     91e0 <fwp_write+0xaa0>
    8fa8:	83 f8 0a             	cmp    $0xa,%eax
    8fab:	0f 84 7f 04 00 00    	je     9430 <fwp_write+0xcf0>
    8fb1:	0f 8f f9 00 00 00    	jg     90b0 <fwp_write+0x970>
    8fb7:	83 f8 03             	cmp    $0x3,%eax
    8fba:	0f 8f 50 04 00 00    	jg     9410 <fwp_write+0xcd0>
    8fc0:	85 c0                	test   %eax,%eax
    8fc2:	78 10                	js     8fd4 <fwp_write+0x894>
    8fc4:	48 8b 04 24          	mov    (%rsp),%rax
    8fc8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8fcc:	85 c0                	test   %eax,%eax
    8fce:	0f 85 f9 00 00 00    	jne    90cd <fwp_write+0x98d>
    8fd4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8fd9:	48 8b 34 24          	mov    (%rsp),%rsi
    8fdd:	31 c9                	xor    %ecx,%ecx
    8fdf:	48 89 df             	mov    %rbx,%rdi
    8fe2:	e8 59 f7 ff ff       	call   8740 <fwp_write>
    8fe7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8fec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ff1:	49 83 c5 01          	add    $0x1,%r13
    8ff5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8ff9:	0f 8f 5f ff ff ff    	jg     8f5e <fwp_write+0x81e>
    8fff:	e9 d2 f7 ff ff       	jmp    87d6 <fwp_write+0x96>
    9004:	0f 1f 40 00          	nopl   0x0(%rax)
    9008:	ba 06 00 00 00       	mov    $0x6,%edx
    900d:	48 8d 35 37 62 00 00 	lea    0x6237(%rip),%rsi        # f24b <_IO_stdin_used+0x24b>
    9014:	45 31 ed             	xor    %r13d,%r13d
    9017:	e8 d4 b0 ff ff       	call   40f0 <buf_put>
    901c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9021:	75 19                	jne    903c <fwp_write+0x8fc>
    9023:	eb 6c                	jmp    9091 <fwp_write+0x951>
    9025:	0f 1f 00             	nopl   (%rax)
    9028:	ba 02 00 00 00       	mov    $0x2,%edx
    902d:	48 8d 35 21 62 00 00 	lea    0x6221(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    9034:	48 89 df             	mov    %rbx,%rdi
    9037:	e8 b4 b0 ff ff       	call   40f0 <buf_put>
    903c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9042:	b9 00 02 00 00       	mov    $0x200,%ecx
    9047:	31 c0                	xor    %eax,%eax
    9049:	49 83 c5 01          	add    $0x1,%r13
    904d:	4c 8d 05 fe 61 00 00 	lea    0x61fe(%rip),%r8        # f252 <_IO_stdin_used+0x252>
    9054:	ba 02 00 00 00       	mov    $0x2,%edx
    9059:	be 00 02 00 00       	mov    $0x200,%esi
    905e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9065:	00 
    9066:	e8 35 a3 ff ff       	call   33a0 <__snprintf_chk@plt>
    906b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9072:	00 
    9073:	e8 c8 a3 ff ff       	call   3440 <strlen@plt>
    9078:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    907f:	00 
    9080:	48 89 df             	mov    %rbx,%rdi
    9083:	48 89 c2             	mov    %rax,%rdx
    9086:	e8 65 b0 ff ff       	call   40f0 <buf_put>
    908b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    908f:	72 97                	jb     9028 <fwp_write+0x8e8>
    9091:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9096:	ba 01 00 00 00       	mov    $0x1,%edx
    909b:	48 89 df             	mov    %rbx,%rdi
    909e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    90a3:	e8 48 b0 ff ff       	call   40f0 <buf_put>
    90a8:	e9 29 f7 ff ff       	jmp    87d6 <fwp_write+0x96>
    90ad:	0f 1f 00             	nopl   (%rax)
    90b0:	83 f8 0b             	cmp    $0xb,%eax
    90b3:	0f 85 1b ff ff ff    	jne    8fd4 <fwp_write+0x894>
    90b9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    90be:	66 0f 50 c3          	movmskpd %xmm3,%eax
    90c2:	83 e0 01             	and    $0x1,%eax
    90c5:	85 c0                	test   %eax,%eax
    90c7:	0f 84 07 ff ff ff    	je     8fd4 <fwp_write+0x894>
    90cd:	4c 89 fe             	mov    %r15,%rsi
    90d0:	48 89 df             	mov    %rbx,%rdi
    90d3:	ba 01 00 00 00       	mov    $0x1,%edx
    90d8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    90dd:	e8 0e b0 ff ff       	call   40f0 <buf_put>
    90e2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    90e7:	48 8b 34 24          	mov    (%rsp),%rsi
    90eb:	31 c9                	xor    %ecx,%ecx
    90ed:	48 89 df             	mov    %rbx,%rdi
    90f0:	e8 4b f6 ff ff       	call   8740 <fwp_write>
    90f5:	ba 01 00 00 00       	mov    $0x1,%edx
    90fa:	4c 89 fe             	mov    %r15,%rsi
    90fd:	48 89 df             	mov    %rbx,%rdi
    9100:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9105:	e8 e6 af ff ff       	call   40f0 <buf_put>
    910a:	e9 d8 fe ff ff       	jmp    8fe7 <fwp_write+0x8a7>
    910f:	90                   	nop
    9110:	ba 01 00 00 00       	mov    $0x1,%edx
    9115:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    911a:	48 89 df             	mov    %rbx,%rdi
    911d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9122:	e8 c9 af ff ff       	call   40f0 <buf_put>
    9127:	e9 aa f6 ff ff       	jmp    87d6 <fwp_write+0x96>
    912c:	0f 1f 40 00          	nopl   0x0(%rax)
    9130:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9135:	ba 01 00 00 00       	mov    $0x1,%edx
    913a:	48 89 df             	mov    %rbx,%rdi
    913d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9142:	e8 a9 af ff ff       	call   40f0 <buf_put>
    9147:	e9 8a f6 ff ff       	jmp    87d6 <fwp_write+0x96>
    914c:	0f 1f 40 00          	nopl   0x0(%rax)
    9150:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9154:	48 8b 13             	mov    (%rbx),%rdx
    9157:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    915c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9160:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9164:	e9 6d f6 ff ff       	jmp    87d6 <fwp_write+0x96>
    9169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9170:	ba 02 00 00 00       	mov    $0x2,%edx
    9175:	48 8d 35 d9 60 00 00 	lea    0x60d9(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    917c:	48 89 df             	mov    %rbx,%rdi
    917f:	e8 6c af ff ff       	call   40f0 <buf_put>
    9184:	e9 72 f8 ff ff       	jmp    89fb <fwp_write+0x2bb>
    9189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9190:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9195:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    919a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    919e:	48 89 f7             	mov    %rsi,%rdi
    91a1:	48 89 34 24          	mov    %rsi,(%rsp)
    91a5:	e8 96 a2 ff ff       	call   3440 <strlen@plt>
    91aa:	48 8b 34 24          	mov    (%rsp),%rsi
    91ae:	48 89 df             	mov    %rbx,%rdi
    91b1:	48 89 c2             	mov    %rax,%rdx
    91b4:	e8 37 af ff ff       	call   40f0 <buf_put>
    91b9:	ba 03 00 00 00       	mov    $0x3,%edx
    91be:	48 8d 35 b3 60 00 00 	lea    0x60b3(%rip),%rsi        # f278 <_IO_stdin_used+0x278>
    91c5:	48 89 df             	mov    %rbx,%rdi
    91c8:	e8 23 af ff ff       	call   40f0 <buf_put>
    91cd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    91d2:	e9 35 f8 ff ff       	jmp    8a0c <fwp_write+0x2cc>
    91d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91de:	00 00 
    91e0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    91e5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    91e9:	48 85 ff             	test   %rdi,%rdi
    91ec:	0f 84 e2 fd ff ff    	je     8fd4 <fwp_write+0x894>
    91f2:	48 8d 35 69 60 00 00 	lea    0x6069(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    91f9:	e8 22 a3 ff ff       	call   3520 <strcmp@plt>
    91fe:	85 c0                	test   %eax,%eax
    9200:	0f 95 c0             	setne  %al
    9203:	0f b6 c0             	movzbl %al,%eax
    9206:	e9 c1 fd ff ff       	jmp    8fcc <fwp_write+0x88c>
    920b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9210:	31 c0                	xor    %eax,%eax
    9212:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9219:	00 
    921a:	0f 97 c0             	seta   %al
    921d:	e9 aa fd ff ff       	jmp    8fcc <fwp_write+0x88c>
    9222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9228:	48 89 df             	mov    %rbx,%rdi
    922b:	ba 02 00 00 00       	mov    $0x2,%edx
    9230:	48 8d 35 28 60 00 00 	lea    0x6028(%rip),%rsi        # f25f <_IO_stdin_used+0x25f>
    9237:	e8 b4 ae ff ff       	call   40f0 <buf_put>
    923c:	4c 89 e8             	mov    %r13,%rax
    923f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9244:	31 c9                	xor    %ecx,%ecx
    9246:	48 c1 e0 04          	shl    $0x4,%rax
    924a:	48 89 df             	mov    %rbx,%rdi
    924d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9252:	e8 e9 f4 ff ff       	call   8740 <fwp_write>
    9257:	e9 5e f6 ff ff       	jmp    88ba <fwp_write+0x17a>
    925c:	0f 1f 40 00          	nopl   0x0(%rax)
    9260:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9265:	48 85 ff             	test   %rdi,%rdi
    9268:	79 0c                	jns    9276 <fwp_write+0xb36>
    926a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9271:	00 
    9272:	48 03 75 10          	add    0x10(%rbp),%rsi
    9276:	48 63 3e             	movslq (%rsi),%rdi
    9279:	83 f9 02             	cmp    $0x2,%ecx
    927c:	89 fe                	mov    %edi,%esi
    927e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9282:	e9 f9 fb ff ff       	jmp    8e80 <fwp_write+0x740>
    9287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    928e:	00 00 
    9290:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9295:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    929a:	48 85 ff             	test   %rdi,%rdi
    929d:	0f 88 0f 03 00 00    	js     95b2 <fwp_write+0xe72>
    92a3:	49 0f bf 38          	movswq (%r8),%rdi
    92a7:	83 f9 01             	cmp    $0x1,%ecx
    92aa:	0f b7 f7             	movzwl %di,%esi
    92ad:	48 0f 44 f7          	cmove  %rdi,%rsi
    92b1:	e9 ca fb ff ff       	jmp    8e80 <fwp_write+0x740>
    92b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92bd:	00 00 00 
    92c0:	ba 01 00 00 00       	mov    $0x1,%edx
    92c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    92ca:	48 83 c5 08          	add    $0x8,%rbp
    92ce:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    92d3:	e8 18 ae ff ff       	call   40f0 <buf_put>
    92d8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92dd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    92e2:	4d 85 ed             	test   %r13,%r13
    92e5:	75 46                	jne    932d <fwp_write+0xbed>
    92e7:	e9 04 01 00 00       	jmp    93f0 <fwp_write+0xcb0>
    92ec:	0f 1f 40 00          	nopl   0x0(%rax)
    92f0:	41 80 f9 09          	cmp    $0x9,%r9b
    92f4:	0f 84 d6 00 00 00    	je     93d0 <fwp_write+0xc90>
    92fa:	41 80 f9 0a          	cmp    $0xa,%r9b
    92fe:	0f 85 9c 00 00 00    	jne    93a0 <fwp_write+0xc60>
    9304:	ba 02 00 00 00       	mov    $0x2,%edx
    9309:	48 8d 35 2b 5f 00 00 	lea    0x5f2b(%rip),%rsi        # f23b <_IO_stdin_used+0x23b>
    9310:	48 89 df             	mov    %rbx,%rdi
    9313:	e8 d8 ad ff ff       	call   40f0 <buf_put>
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 
    9320:	48 83 c5 01          	add    $0x1,%rbp
    9324:	49 39 ec             	cmp    %rbp,%r12
    9327:	0f 84 c3 00 00 00    	je     93f0 <fwp_write+0xcb0>
    932d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9332:	41 80 f9 0d          	cmp    $0xd,%r9b
    9336:	74 28                	je     9360 <fwp_write+0xc20>
    9338:	7e b6                	jle    92f0 <fwp_write+0xbb0>
    933a:	41 80 f9 22          	cmp    $0x22,%r9b
    933e:	74 40                	je     9380 <fwp_write+0xc40>
    9340:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9344:	75 5a                	jne    93a0 <fwp_write+0xc60>
    9346:	ba 02 00 00 00       	mov    $0x2,%edx
    934b:	48 8d 35 e6 5e 00 00 	lea    0x5ee6(%rip),%rsi        # f238 <_IO_stdin_used+0x238>
    9352:	48 89 df             	mov    %rbx,%rdi
    9355:	e8 96 ad ff ff       	call   40f0 <buf_put>
    935a:	eb c4                	jmp    9320 <fwp_write+0xbe0>
    935c:	0f 1f 40 00          	nopl   0x0(%rax)
    9360:	ba 02 00 00 00       	mov    $0x2,%edx
    9365:	48 8d 35 d5 5e 00 00 	lea    0x5ed5(%rip),%rsi        # f241 <_IO_stdin_used+0x241>
    936c:	48 89 df             	mov    %rbx,%rdi
    936f:	e8 7c ad ff ff       	call   40f0 <buf_put>
    9374:	eb aa                	jmp    9320 <fwp_write+0xbe0>
    9376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    937d:	00 00 00 
    9380:	ba 02 00 00 00       	mov    $0x2,%edx
    9385:	48 8d 35 a9 5e 00 00 	lea    0x5ea9(%rip),%rsi        # f235 <_IO_stdin_used+0x235>
    938c:	48 89 df             	mov    %rbx,%rdi
    938f:	e8 5c ad ff ff       	call   40f0 <buf_put>
    9394:	eb 8a                	jmp    9320 <fwp_write+0xbe0>
    9396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    939d:	00 00 00 
    93a0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    93a4:	0f 86 2e 01 00 00    	jbe    94d8 <fwp_write+0xd98>
    93aa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    93ae:	0f 84 24 01 00 00    	je     94d8 <fwp_write+0xd98>
    93b4:	ba 01 00 00 00       	mov    $0x1,%edx
    93b9:	4c 89 fe             	mov    %r15,%rsi
    93bc:	48 89 df             	mov    %rbx,%rdi
    93bf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    93c4:	e8 27 ad ff ff       	call   40f0 <buf_put>
    93c9:	e9 52 ff ff ff       	jmp    9320 <fwp_write+0xbe0>
    93ce:	66 90                	xchg   %ax,%ax
    93d0:	ba 02 00 00 00       	mov    $0x2,%edx
    93d5:	48 8d 35 62 5e 00 00 	lea    0x5e62(%rip),%rsi        # f23e <_IO_stdin_used+0x23e>
    93dc:	48 89 df             	mov    %rbx,%rdi
    93df:	e8 0c ad ff ff       	call   40f0 <buf_put>
    93e4:	e9 37 ff ff ff       	jmp    9320 <fwp_write+0xbe0>
    93e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93f0:	ba 01 00 00 00       	mov    $0x1,%edx
    93f5:	4c 89 fe             	mov    %r15,%rsi
    93f8:	48 89 df             	mov    %rbx,%rdi
    93fb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9400:	e8 eb ac ff ff       	call   40f0 <buf_put>
    9405:	e9 cc f3 ff ff       	jmp    87d6 <fwp_write+0x96>
    940a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9410:	83 f8 04             	cmp    $0x4,%eax
    9413:	0f 85 bb fb ff ff    	jne    8fd4 <fwp_write+0x894>
    9419:	48 8b 04 24          	mov    (%rsp),%rax
    941d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9421:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9426:	48 c1 e8 3f          	shr    $0x3f,%rax
    942a:	e9 96 fc ff ff       	jmp    90c5 <fwp_write+0x985>
    942f:	90                   	nop
    9430:	8b 0c 24             	mov    (%rsp),%ecx
    9433:	31 c0                	xor    %eax,%eax
    9435:	85 c9                	test   %ecx,%ecx
    9437:	0f 98 c0             	sets   %al
    943a:	e9 86 fc ff ff       	jmp    90c5 <fwp_write+0x985>
    943f:	90                   	nop
    9440:	48 f7 d8             	neg    %rax
    9443:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    944a:	00 
    944b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9452:	2d 
    9453:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    945a:	00 
    945b:	48 83 d2 00          	adc    $0x0,%rdx
    945f:	48 89 c6             	mov    %rax,%rsi
    9462:	48 f7 da             	neg    %rdx
    9465:	e8 d6 a5 ff ff       	call   3a40 <fwp_fmt_u128>
    946a:	e9 51 f3 ff ff       	jmp    87c0 <fwp_write+0x80>
    946f:	90                   	nop
    9470:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9475:	e9 c3 f5 ff ff       	jmp    8a3d <fwp_write+0x2fd>
    947a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9480:	4c 89 e9             	mov    %r13,%rcx
    9483:	48 c1 e1 04          	shl    $0x4,%rcx
    9487:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    948c:	48 85 ff             	test   %rdi,%rdi
    948f:	0f 89 eb f9 ff ff    	jns    8e80 <fwp_write+0x740>
    9495:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9499:	48 89 ce             	mov    %rcx,%rsi
    949c:	e9 df f9 ff ff       	jmp    8e80 <fwp_write+0x740>
    94a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94a8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    94af:	00 
    94b0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    94b4:	e9 20 fa ff ff       	jmp    8ed9 <fwp_write+0x799>
    94b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94c0:	ba 02 00 00 00       	mov    $0x2,%edx
    94c5:	48 8d 35 34 5d 00 00 	lea    0x5d34(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    94cc:	e9 2d f7 ff ff       	jmp    8bfe <fwp_write+0x4be>
    94d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94d8:	4c 8d 05 65 5d 00 00 	lea    0x5d65(%rip),%r8        # f244 <_IO_stdin_used+0x244>
    94df:	b9 10 00 00 00       	mov    $0x10,%ecx
    94e4:	31 c0                	xor    %eax,%eax
    94e6:	ba 02 00 00 00       	mov    $0x2,%edx
    94eb:	be 10 00 00 00       	mov    $0x10,%esi
    94f0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    94f7:	00 
    94f8:	e8 a3 9e ff ff       	call   33a0 <__snprintf_chk@plt>
    94fd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9504:	00 
    9505:	e8 36 9f ff ff       	call   3440 <strlen@plt>
    950a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9511:	00 
    9512:	48 89 df             	mov    %rbx,%rdi
    9515:	48 89 c2             	mov    %rax,%rdx
    9518:	e8 d3 ab ff ff       	call   40f0 <buf_put>
    951d:	e9 fe fd ff ff       	jmp    9320 <fwp_write+0xbe0>
    9522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9528:	66 0f ef c0          	pxor   %xmm0,%xmm0
    952c:	48 8d 35 c7 5c 00 00 	lea    0x5cc7(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    9533:	48 8d 05 bf 5c 00 00 	lea    0x5cbf(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    953a:	4c 89 e7             	mov    %r12,%rdi
    953d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9541:	48 0f 46 f0          	cmovbe %rax,%rsi
    9545:	e8 96 9e ff ff       	call   33e0 <strcpy@plt>
    954a:	e9 71 f2 ff ff       	jmp    87c0 <fwp_write+0x80>
    954f:	90                   	nop
    9550:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9554:	48 8d 35 9f 5c 00 00 	lea    0x5c9f(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    955b:	48 8d 05 97 5c 00 00 	lea    0x5c97(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    9562:	0f 2f c8             	comiss %xmm0,%xmm1
    9565:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    956c:	00 
    956d:	4c 89 e7             	mov    %r12,%rdi
    9570:	48 0f 46 f0          	cmovbe %rax,%rsi
    9574:	e8 67 9e ff ff       	call   33e0 <strcpy@plt>
    9579:	e9 42 f2 ff ff       	jmp    87c0 <fwp_write+0x80>
    957e:	66 90                	xchg   %ax,%ax
    9580:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9585:	45 85 c0             	test   %r8d,%r8d
    9588:	75 34                	jne    95be <fwp_write+0xe7e>
    958a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9591:	00 
    9592:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9599:	00 00 
    959b:	0f 85 74 f6 ff ff    	jne    8c15 <fwp_write+0x4d5>
    95a1:	ba 02 00 00 00       	mov    $0x2,%edx
    95a6:	48 8d 35 c8 5c 00 00 	lea    0x5cc8(%rip),%rsi        # f275 <_IO_stdin_used+0x275>
    95ad:	e9 a1 f3 ff ff       	jmp    8953 <fwp_write+0x213>
    95b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    95b6:	49 89 f0             	mov    %rsi,%r8
    95b9:	e9 e5 fc ff ff       	jmp    92a3 <fwp_write+0xb63>
    95be:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    95c3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    95c8:	85 ff                	test   %edi,%edi
    95ca:	0f 84 fa f3 ff ff    	je     89ca <fwp_write+0x28a>
    95d0:	ba 01 00 00 00       	mov    $0x1,%edx
    95d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    95da:	48 89 df             	mov    %rbx,%rdi
    95dd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    95e2:	e8 09 ab ff ff       	call   40f0 <buf_put>
    95e7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    95ec:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    95f1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    95f7:	85 c0                	test   %eax,%eax
    95f9:	0f 8f f0 f3 ff ff    	jg     89ef <fwp_write+0x2af>
    95ff:	e9 34 f4 ff ff       	jmp    8a38 <fwp_write+0x2f8>
    9604:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9608:	49 89 c5             	mov    %rax,%r13
    960b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9610:	49 89 c4             	mov    %rax,%r12
    9613:	49 c1 fd 3f          	sar    $0x3f,%r13
    9617:	4c 09 e8             	or     %r13,%rax
    961a:	0f 84 a7 00 00 00    	je     96c7 <fwp_write+0xf87>
    9620:	48 8d 2d 99 7c 00 00 	lea    0x7c99(%rip),%rbp        # 112c0 <units.0>
    9627:	4d 89 e7             	mov    %r12,%r15
    962a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    962e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9633:	4c 89 ff             	mov    %r15,%rdi
    9636:	4c 89 ee             	mov    %r13,%rsi
    9639:	44 89 0c 24          	mov    %r9d,(%rsp)
    963d:	48 99                	cqto
    963f:	48 89 d1             	mov    %rdx,%rcx
    9642:	48 89 c2             	mov    %rax,%rdx
    9645:	e8 f6 4f 00 00       	call   e640 <__divmodti4>
    964a:	44 8b 0c 24          	mov    (%rsp),%r9d
    964e:	48 89 c1             	mov    %rax,%rcx
    9651:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9656:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    965b:	0f 84 94 00 00 00    	je     96f5 <fwp_write+0xfb5>
    9661:	41 83 c1 01          	add    $0x1,%r9d
    9665:	48 83 c5 10          	add    $0x10,%rbp
    9669:	41 83 f9 05          	cmp    $0x5,%r9d
    966d:	75 bb                	jne    962a <fwp_write+0xeea>
    966f:	4d 85 ed             	test   %r13,%r13
    9672:	79 53                	jns    96c7 <fwp_write+0xf87>
    9674:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9679:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    967e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9683:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9688:	48 99                	cqto
    968a:	48 f7 d8             	neg    %rax
    968d:	48 83 d2 00          	adc    $0x0,%rdx
    9691:	48 89 c6             	mov    %rax,%rsi
    9694:	48 f7 da             	neg    %rdx
    9697:	e8 a4 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    969c:	49 89 e8             	mov    %rbp,%r8
    969f:	ba 00 02 00 00       	mov    $0x200,%edx
    96a4:	be 02 00 00 00       	mov    $0x2,%esi
    96a9:	31 c0                	xor    %eax,%eax
    96ab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96b2:	00 
    96b3:	48 8d 0d b6 5b 00 00 	lea    0x5bb6(%rip),%rcx        # f270 <_IO_stdin_used+0x270>
    96ba:	4c 89 e7             	mov    %r12,%rdi
    96bd:	e8 fe 9f ff ff       	call   36c0 <__sprintf_chk@plt>
    96c2:	e9 f9 f0 ff ff       	jmp    87c0 <fwp_write+0x80>
    96c7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    96d1:	31 d2                	xor    %edx,%edx
    96d3:	48 89 ef             	mov    %rbp,%rdi
    96d6:	e8 65 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96db:	eb bf                	jmp    969c <fwp_write+0xf5c>
    96dd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    96e4:	4e 61 4e 00 
    96e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96ef:	00 
    96f0:	e9 cb f0 ff ff       	jmp    87c0 <fwp_write+0x80>
    96f5:	44 89 0c 24          	mov    %r9d,(%rsp)
    96f9:	48 89 c8             	mov    %rcx,%rax
    96fc:	48 85 d2             	test   %rdx,%rdx
    96ff:	78 51                	js     9752 <fwp_write+0x1012>
    9701:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9706:	48 89 c6             	mov    %rax,%rsi
    9709:	48 89 ef             	mov    %rbp,%rdi
    970c:	e8 2f a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9711:	44 8b 0c 24          	mov    (%rsp),%r9d
    9715:	49 63 c1             	movslq %r9d,%rax
    9718:	49 89 e8             	mov    %rbp,%r8
    971b:	ba 00 02 00 00       	mov    $0x200,%edx
    9720:	be 02 00 00 00       	mov    $0x2,%esi
    9725:	48 c1 e0 04          	shl    $0x4,%rax
    9729:	48 8d 3d 90 7b 00 00 	lea    0x7b90(%rip),%rdi        # 112c0 <units.0>
    9730:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9737:	00 
    9738:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    973c:	48 8d 0d 28 5b 00 00 	lea    0x5b28(%rip),%rcx        # f26b <_IO_stdin_used+0x26b>
    9743:	4c 89 e7             	mov    %r12,%rdi
    9746:	31 c0                	xor    %eax,%eax
    9748:	e8 73 9f ff ff       	call   36c0 <__sprintf_chk@plt>
    974d:	e9 6e f0 ff ff       	jmp    87c0 <fwp_write+0x80>
    9752:	48 f7 d8             	neg    %rax
    9755:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    975a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    975f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9764:	48 83 d2 00          	adc    $0x0,%rdx
    9768:	48 89 c6             	mov    %rax,%rsi
    976b:	48 f7 da             	neg    %rdx
    976e:	e8 cd a2 ff ff       	call   3a40 <fwp_fmt_u128>
    9773:	44 8b 0c 24          	mov    (%rsp),%r9d
    9777:	eb 9c                	jmp    9715 <fwp_write+0xfd5>
    9779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009780 <fwp_hof0.constprop.0>:
    9780:	41 57                	push   %r15
    9782:	41 56                	push   %r14
    9784:	41 55                	push   %r13
    9786:	41 54                	push   %r12
    9788:	55                   	push   %rbp
    9789:	53                   	push   %rbx
    978a:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    9791:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    9796:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    979d:	00 00 
    979f:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    97a6:	00 
    97a7:	31 c0                	xor    %eax,%eax
    97a9:	48 85 f6             	test   %rsi,%rsi
    97ac:	0f 84 65 0f 00 00    	je     a717 <fwp_hof0.constprop.0+0xf97>
    97b2:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    97b7:	48 8d 2d 82 20 06 00 	lea    0x62082(%rip),%rbp        # 6b840 <fwp_heap>
    97be:	66 90                	xchg   %ax,%ax
    97c0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    97c7:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    97cc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    97d3:	48 c1 e2 10          	shl    $0x10,%rdx
    97d7:	48 39 d0             	cmp    %rdx,%rax
    97da:	73 71                	jae    984d <fwp_hof0.constprop.0+0xcd>
    97dc:	48 89 c2             	mov    %rax,%rdx
    97df:	48 c1 ea 10          	shr    $0x10,%rdx
    97e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97e7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    97ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97f2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    97f6:	48 85 ff             	test   %rdi,%rdi
    97f9:	74 52                	je     984d <fwp_hof0.constprop.0+0xcd>
    97fb:	0f b6 0a             	movzbl (%rdx),%ecx
    97fe:	80 f9 02             	cmp    $0x2,%cl
    9801:	0f 84 81 15 00 00    	je     ad88 <fwp_hof0.constprop.0+0x1608>
    9807:	80 f9 01             	cmp    $0x1,%cl
    980a:	75 41                	jne    984d <fwp_hof0.constprop.0+0xcd>
    980c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    980f:	0f b7 c0             	movzwl %ax,%eax
    9812:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9815:	48 0f af c1          	imul   %rcx,%rax
    9819:	48 c1 e8 20          	shr    $0x20,%rax
    981d:	48 39 d0             	cmp    %rdx,%rax
    9820:	73 2b                	jae    984d <fwp_hof0.constprop.0+0xcd>
    9822:	48 01 c7             	add    %rax,%rdi
    9825:	0f b6 07             	movzbl (%rdi),%eax
    9828:	84 c0                	test   %al,%al
    982a:	74 21                	je     984d <fwp_hof0.constprop.0+0xcd>
    982c:	44 8b 0d d5 3c 06 00 	mov    0x63cd5(%rip),%r9d        # 6d508 <iteration_active>
    9833:	45 85 c9             	test   %r9d,%r9d
    9836:	74 08                	je     9840 <fwp_hof0.constprop.0+0xc0>
    9838:	48 83 05 b0 3c 06 00 	addq   $0x1,0x63cb0(%rip)        # 6d4f0 <iteration_retains>
    983f:	01 
    9840:	3c fd                	cmp    $0xfd,%al
    9842:	0f 87 0e 17 00 00    	ja     af56 <fwp_hof0.constprop.0+0x17d6>
    9848:	83 c0 01             	add    $0x1,%eax
    984b:	88 07                	mov    %al,(%rdi)
    984d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9852:	45 31 c9             	xor    %r9d,%r9d
    9855:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    985c:	00 00 
    985e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9863:	4c 89 cb             	mov    %r9,%rbx
    9866:	4d 85 c9             	test   %r9,%r9
    9869:	0f 85 e1 9e ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    986f:	48 8b 05 62 3c 06 00 	mov    0x63c62(%rip),%rax        # 6d4d8 <fwp_cleanups>
    9876:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    987d:	4c 8d 2d 3c d8 ff ff 	lea    -0x27c4(%rip),%r13        # 70c0 <fwp_tape_scope_release>
    9884:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    988b:	ff ff ff ff 
    988f:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    9896:	00 
    9897:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    989e:	00 
    989f:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    98a6:	00 
    98a7:	48 c1 e2 10          	shl    $0x10,%rdx
    98ab:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    98b0:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    98b7:	00 
    98b8:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    98bf:	00 
    98c0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    98c5:	48 89 05 0c 3c 06 00 	mov    %rax,0x63c0c(%rip)        # 6d4d8 <fwp_cleanups>
    98cc:	48 8d 05 3d 97 00 00 	lea    0x973d(%rip),%rax        # 13010 <fc37>
    98d3:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    98da:	48 39 d0             	cmp    %rdx,%rax
    98dd:	73 71                	jae    9950 <fwp_hof0.constprop.0+0x1d0>
    98df:	48 89 c2             	mov    %rax,%rdx
    98e2:	48 c1 ea 10          	shr    $0x10,%rdx
    98e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98ea:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    98f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98f5:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    98f9:	48 85 ff             	test   %rdi,%rdi
    98fc:	74 52                	je     9950 <fwp_hof0.constprop.0+0x1d0>
    98fe:	0f b6 0a             	movzbl (%rdx),%ecx
    9901:	80 f9 02             	cmp    $0x2,%cl
    9904:	0f 84 76 12 00 00    	je     ab80 <fwp_hof0.constprop.0+0x1400>
    990a:	80 f9 01             	cmp    $0x1,%cl
    990d:	75 41                	jne    9950 <fwp_hof0.constprop.0+0x1d0>
    990f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9912:	0f b7 c0             	movzwl %ax,%eax
    9915:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9918:	48 0f af c1          	imul   %rcx,%rax
    991c:	48 c1 e8 20          	shr    $0x20,%rax
    9920:	48 39 d0             	cmp    %rdx,%rax
    9923:	73 2b                	jae    9950 <fwp_hof0.constprop.0+0x1d0>
    9925:	48 01 c7             	add    %rax,%rdi
    9928:	0f b6 07             	movzbl (%rdi),%eax
    992b:	84 c0                	test   %al,%al
    992d:	74 21                	je     9950 <fwp_hof0.constprop.0+0x1d0>
    992f:	44 8b 05 d2 3b 06 00 	mov    0x63bd2(%rip),%r8d        # 6d508 <iteration_active>
    9936:	45 85 c0             	test   %r8d,%r8d
    9939:	74 08                	je     9943 <fwp_hof0.constprop.0+0x1c3>
    993b:	48 83 05 ad 3b 06 00 	addq   $0x1,0x63bad(%rip)        # 6d4f0 <iteration_retains>
    9942:	01 
    9943:	3c fd                	cmp    $0xfd,%al
    9945:	0f 87 b1 15 00 00    	ja     aefc <fwp_hof0.constprop.0+0x177c>
    994b:	83 c0 01             	add    $0x1,%eax
    994e:	88 07                	mov    %al,(%rdi)
    9950:	48 8d 3d b9 96 00 00 	lea    0x96b9(%rip),%rdi        # 13010 <fc37>
    9957:	e8 f4 d3 ff ff       	call   6d50 <fwp_closure_drop>
    995c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9961:	48 85 c0             	test   %rax,%rax
    9964:	0f 84 a1 14 00 00    	je     ae0b <fwp_hof0.constprop.0+0x168b>
    996a:	31 d2                	xor    %edx,%edx
    996c:	0f 1f 40 00          	nopl   0x0(%rax)
    9970:	48 8b 40 10          	mov    0x10(%rax),%rax
    9974:	48 83 c2 01          	add    $0x1,%rdx
    9978:	48 85 c0             	test   %rax,%rax
    997b:	75 f3                	jne    9970 <fwp_hof0.constprop.0+0x1f0>
    997d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9984:	0f 87 95 16 00 00    	ja     b01f <fwp_hof0.constprop.0+0x189f>
    998a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    998f:	8b 35 e7 96 00 00    	mov    0x96e7(%rip),%esi        # 1307c <registered_finish.5>
    9995:	85 f6                	test   %esi,%esi
    9997:	0f 84 a3 11 00 00    	je     ab40 <fwp_hof0.constprop.0+0x13c0>
    999d:	4c 8b 35 54 97 01 00 	mov    0x19754(%rip),%r14        # 230f8 <fwp_tape_next_slot>
    99a4:	4c 8b 25 5d 97 01 00 	mov    0x1975d(%rip),%r12        # 23108 <fwp_ntapes>
    99ab:	4d 39 f4             	cmp    %r14,%r12
    99ae:	0f 8e 3c 0e 00 00    	jle    a7f0 <fwp_hof0.constprop.0+0x1070>
    99b4:	49 6b c6 68          	imul   $0x68,%r14,%rax
    99b8:	48 03 05 51 97 01 00 	add    0x19751(%rip),%rax        # 23110 <fwp_tapes>
    99bf:	90                   	nop
    99c0:	8b 48 04             	mov    0x4(%rax),%ecx
    99c3:	85 c9                	test   %ecx,%ecx
    99c5:	75 0c                	jne    99d3 <fwp_hof0.constprop.0+0x253>
    99c7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    99cd:	0f 86 1d 0e 00 00    	jbe    a7f0 <fwp_hof0.constprop.0+0x1070>
    99d3:	49 83 c6 01          	add    $0x1,%r14
    99d7:	48 83 c0 68          	add    $0x68,%rax
    99db:	4d 39 f4             	cmp    %r14,%r12
    99de:	75 e0                	jne    99c0 <fwp_hof0.constprop.0+0x240>
    99e0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    99e7:	0f 8f 4a 16 00 00    	jg     b037 <fwp_hof0.constprop.0+0x18b7>
    99ed:	4c 3b 25 0c 97 01 00 	cmp    0x1970c(%rip),%r12        # 23100 <fwp_tapes_cap>
    99f4:	4c 8b 3d 15 97 01 00 	mov    0x19715(%rip),%r15        # 23110 <fwp_tapes>
    99fb:	75 4d                	jne    9a4a <fwp_hof0.constprop.0+0x2ca>
    99fd:	4d 85 e4             	test   %r12,%r12
    9a00:	0f 84 6b 14 00 00    	je     ae71 <fwp_hof0.constprop.0+0x16f1>
    9a06:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9a0a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9a0f:	49 39 c6             	cmp    %rax,%r14
    9a12:	4c 0f 4f f0          	cmovg  %rax,%r14
    9a16:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    9a1a:	31 d2                	xor    %edx,%edx
    9a1c:	4c 89 ff             	mov    %r15,%rdi
    9a1f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9a25:	e8 c6 b7 ff ff       	call   51f0 <ad_raw_realloc>
    9a2a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9a30:	48 85 c0             	test   %rax,%rax
    9a33:	49 89 c7             	mov    %rax,%r15
    9a36:	0f 84 50 16 00 00    	je     b08c <fwp_hof0.constprop.0+0x190c>
    9a3c:	48 89 05 cd 96 01 00 	mov    %rax,0x196cd(%rip)        # 23110 <fwp_tapes>
    9a43:	4c 89 35 b6 96 01 00 	mov    %r14,0x196b6(%rip)        # 23100 <fwp_tapes_cap>
    9a4a:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    9a4e:	31 c0                	xor    %eax,%eax
    9a50:	4d 89 e6             	mov    %r12,%r14
    9a53:	4c 01 f9             	add    %r15,%rcx
    9a56:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9a5a:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9a61:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9a65:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9a6c:	00 
    9a6d:	48 29 f9             	sub    %rdi,%rcx
    9a70:	83 c1 68             	add    $0x68,%ecx
    9a73:	c1 e9 03             	shr    $0x3,%ecx
    9a76:	f3 48 ab             	rep stos %rax,(%rdi)
    9a79:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    9a7e:	48 89 05 83 96 01 00 	mov    %rax,0x19683(%rip)        # 23108 <fwp_ntapes>
    9a85:	4d 6b e6 68          	imul   $0x68,%r14,%r12
    9a89:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9a8d:	48 8d 3d cc 56 00 00 	lea    0x56cc(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    9a94:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9a99:	4d 01 fc             	add    %r15,%r12
    9a9c:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    9aa3:	00 00 
    9aa5:	e8 e6 98 ff ff       	call   3390 <getenv@plt>
    9aaa:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9ab0:	48 85 c0             	test   %rax,%rax
    9ab3:	0f 84 4f 0d 00 00    	je     a808 <fwp_hof0.constprop.0+0x1088>
    9ab9:	80 38 30             	cmpb   $0x30,(%rax)
    9abc:	0f 85 46 0d 00 00    	jne    a808 <fwp_hof0.constprop.0+0x1088>
    9ac2:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9ac6:	0f 85 3c 0d 00 00    	jne    a808 <fwp_hof0.constprop.0+0x1088>
    9acc:	41 8b 04 24          	mov    (%r12),%eax
    9ad0:	49 8d 76 01          	lea    0x1(%r14),%rsi
    9ad4:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    9adb:	00 00 
    9add:	48 89 35 14 96 01 00 	mov    %rsi,0x19614(%rip)        # 230f8 <fwp_tape_next_slot>
    9ae4:	8d 48 01             	lea    0x1(%rax),%ecx
    9ae7:	48 8b 05 72 62 00 00 	mov    0x6272(%rip),%rax        # fd60 <msg.8+0x20>
    9aee:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    9af5:	00 00 
    9af7:	41 89 0c 24          	mov    %ecx,(%r12)
    9afb:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    9b00:	48 8b 05 d1 39 06 00 	mov    0x639d1(%rip),%rax        # 6d4d8 <fwp_cleanups>
    9b07:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    9b0d:	48 85 c0             	test   %rax,%rax
    9b10:	75 1a                	jne    9b2c <fwp_hof0.constprop.0+0x3ac>
    9b12:	e9 69 15 00 00       	jmp    b080 <fwp_hof0.constprop.0+0x1900>
    9b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b1e:	00 00 
    9b20:	48 8b 00             	mov    (%rax),%rax
    9b23:	48 85 c0             	test   %rax,%rax
    9b26:	0f 84 54 15 00 00    	je     b080 <fwp_hof0.constprop.0+0x1900>
    9b2c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    9b30:	75 ee                	jne    9b20 <fwp_hof0.constprop.0+0x3a0>
    9b32:	4c 8b 40 10          	mov    0x10(%rax),%r8
    9b36:	44 89 f7             	mov    %r14d,%edi
    9b39:	49 63 00             	movslq (%r8),%rax
    9b3c:	4d 89 44 24 50       	mov    %r8,0x50(%r12)
    9b41:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    9b46:	85 c0                	test   %eax,%eax
    9b48:	78 09                	js     9b53 <fwp_hof0.constprop.0+0x3d3>
    9b4a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9b4e:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9b53:	41 89 38             	mov    %edi,(%r8)
    9b56:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9b5b:	45 31 ed             	xor    %r13d,%r13d
    9b5e:	48 89 f8             	mov    %rdi,%rax
    9b61:	48 85 ff             	test   %rdi,%rdi
    9b64:	0f 84 e6 0d 00 00    	je     a950 <fwp_hof0.constprop.0+0x11d0>
    9b6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b70:	48 8b 40 10          	mov    0x10(%rax),%rax
    9b74:	49 83 c5 01          	add    $0x1,%r13
    9b78:	48 85 c0             	test   %rax,%rax
    9b7b:	75 f3                	jne    9b70 <fwp_hof0.constprop.0+0x3f0>
    9b7d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9b82:	0f 1f 00             	nopl   (%rax)
    9b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b8c:	00 00 00 00 
    9b90:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9b94:	48 83 c0 01          	add    $0x1,%rax
    9b98:	48 85 d2             	test   %rdx,%rdx
    9b9b:	75 f3                	jne    9b90 <fwp_hof0.constprop.0+0x410>
    9b9d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9ba4:	ff ff 1f 
    9ba7:	48 39 c2             	cmp    %rax,%rdx
    9baa:	0f 82 63 14 00 00    	jb     b013 <fwp_hof0.constprop.0+0x1893>
    9bb0:	4d 85 ed             	test   %r13,%r13
    9bb3:	0f 8e 97 0d 00 00    	jle    a950 <fwp_hof0.constprop.0+0x11d0>
    9bb9:	49 39 c5             	cmp    %rax,%r13
    9bbc:	4c 0f 47 e8          	cmova  %rax,%r13
    9bc0:	4c 89 e8             	mov    %r13,%rax
    9bc3:	48 c1 e8 3c          	shr    $0x3c,%rax
    9bc7:	0f 85 46 14 00 00    	jne    b013 <fwp_hof0.constprop.0+0x1893>
    9bcd:	4f 8d 7c 2d 00       	lea    0x0(%r13,%r13,1),%r15
    9bd2:	48 c1 e1 10          	shl    $0x10,%rcx
    9bd6:	48 09 f1             	or     %rsi,%rcx
    9bd9:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9be0:	00 
    9be1:	be 02 00 00 00       	mov    $0x2,%esi
    9be6:	49 89 cc             	mov    %rcx,%r12
    9be9:	e8 82 c3 ff ff       	call   5f70 <fwp_heap_alloc>
    9bee:	4c 89 38             	mov    %r15,(%rax)
    9bf1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9bf8:	49 89 c6             	mov    %rax,%r14
    9bfb:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9c02:	48 c1 e2 10          	shl    $0x10,%rdx
    9c06:	48 39 d0             	cmp    %rdx,%rax
    9c09:	0f 83 f1 0d 00 00    	jae    aa00 <fwp_hof0.constprop.0+0x1280>
    9c0f:	48 89 c2             	mov    %rax,%rdx
    9c12:	48 c1 ea 10          	shr    $0x10,%rdx
    9c16:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9c1a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9c21:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9c25:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9c29:	4d 85 ff             	test   %r15,%r15
    9c2c:	74 3a                	je     9c68 <fwp_hof0.constprop.0+0x4e8>
    9c2e:	0f b6 32             	movzbl (%rdx),%esi
    9c31:	40 80 fe 02          	cmp    $0x2,%sil
    9c35:	0f 84 86 0d 00 00    	je     a9c1 <fwp_hof0.constprop.0+0x1241>
    9c3b:	40 80 fe 01          	cmp    $0x1,%sil
    9c3f:	75 27                	jne    9c68 <fwp_hof0.constprop.0+0x4e8>
    9c41:	8b 72 18             	mov    0x18(%rdx),%esi
    9c44:	0f b7 c0             	movzwl %ax,%eax
    9c47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c4a:	48 0f af c6          	imul   %rsi,%rax
    9c4e:	48 c1 e8 20          	shr    $0x20,%rax
    9c52:	48 39 d0             	cmp    %rdx,%rax
    9c55:	73 11                	jae    9c68 <fwp_hof0.constprop.0+0x4e8>
    9c57:	49 01 c7             	add    %rax,%r15
    9c5a:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9c5e:	0f 84 70 0d 00 00    	je     a9d4 <fwp_hof0.constprop.0+0x1254>
    9c64:	41 c6 07 01          	movb   $0x1,(%r15)
    9c68:	4d 85 ed             	test   %r13,%r13
    9c6b:	74 47                	je     9cb4 <fwp_hof0.constprop.0+0x534>
    9c6d:	4c 89 e6             	mov    %r12,%rsi
    9c70:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9c75:	31 c0                	xor    %eax,%eax
    9c77:	48 c1 e6 20          	shl    $0x20,%rsi
    9c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c80:	48 89 c1             	mov    %rax,%rcx
    9c83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9c88:	48 01 f1             	add    %rsi,%rcx
    9c8b:	0f 80 bf 9a ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9c91:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    9c96:	48 89 c1             	mov    %rax,%rcx
    9c99:	48 83 c0 01          	add    $0x1,%rax
    9c9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9ca1:	48 c1 e1 04          	shl    $0x4,%rcx
    9ca5:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    9cab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9caf:	4c 39 e8             	cmp    %r13,%rax
    9cb2:	72 cc                	jb     9c80 <fwp_hof0.constprop.0+0x500>
    9cb4:	49 8b 06             	mov    (%r14),%rax
    9cb7:	48 d1 e8             	shr    $1,%rax
    9cba:	0f 84 50 0d 00 00    	je     aa10 <fwp_hof0.constprop.0+0x1290>
    9cc0:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9cc4:	48 89 f7             	mov    %rsi,%rdi
    9cc7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9ccb:	0f 85 42 13 00 00    	jne    b013 <fwp_hof0.constprop.0+0x1893>
    9cd1:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9cd5:	48 85 f6             	test   %rsi,%rsi
    9cd8:	74 49                	je     9d23 <fwp_hof0.constprop.0+0x5a3>
    9cda:	48 c1 e0 04          	shl    $0x4,%rax
    9cde:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    9ce3:	49 89 d7             	mov    %rdx,%r15
    9ce6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    9cea:	4d 8d 6c 06 f8       	lea    -0x8(%r14,%rax,1),%r13
    9cef:	90                   	nop
    9cf0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9cf4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9cf8:	48 83 c3 10          	add    $0x10,%rbx
    9cfc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9d00:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9d04:	e8 c7 c9 ff ff       	call   66d0 <w120>
    9d09:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9d0e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9d12:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9d16:	49 39 dd             	cmp    %rbx,%r13
    9d19:	75 d5                	jne    9cf0 <fwp_hof0.constprop.0+0x570>
    9d1b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9d20:	4c 89 fa             	mov    %r15,%rdx
    9d23:	49 89 16             	mov    %rdx,(%r14)
    9d26:	4c 89 f7             	mov    %r14,%rdi
    9d29:	4d 63 fc             	movslq %r12d,%r15
    9d2c:	e8 1f cb ff ff       	call   6850 <w176.constprop.0>
    9d31:	4c 89 f7             	mov    %r14,%rdi
    9d34:	49 89 c5             	mov    %rax,%r13
    9d37:	e8 d4 e2 ff ff       	call   8010 <fwp_drop10>
    9d3c:	4c 89 ff             	mov    %r15,%rdi
    9d3f:	e8 7c b2 ff ff       	call   4fc0 <caf75>
    9d44:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9d49:	e8 e2 a9 ff ff       	call   4730 <fwp_tape_of>
    9d4e:	48 89 c6             	mov    %rax,%rsi
    9d51:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9d56:	0f 85 a5 13 00 00    	jne    b101 <fwp_hof0.constprop.0+0x1981>
    9d5c:	48 89 c7             	mov    %rax,%rdi
    9d5f:	e8 2c 9f ff ff       	call   3c90 <fwp_tape_unlink_scope>
    9d64:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    9d68:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9d6d:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9d74:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9d78:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9d7c:	66 49 0f 6e f8       	movq   %r8,%xmm7
    9d81:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    9d86:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9d8b:	4c 8b 56 40          	mov    0x40(%rsi),%r10
    9d8f:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9d93:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9d99:	77 19                	ja     9db4 <fwp_hof0.constprop.0+0x634>
    9d9b:	41 0f b7 c4          	movzwl %r12w,%eax
    9d9f:	83 e8 01             	sub    $0x1,%eax
    9da2:	48 98                	cltq
    9da4:	48 3b 05 4d 93 01 00 	cmp    0x1934d(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    9dab:	7d 07                	jge    9db4 <fwp_hof0.constprop.0+0x634>
    9dad:	48 89 05 44 93 01 00 	mov    %rax,0x19344(%rip)        # 230f8 <fwp_tape_next_slot>
    9db4:	48 8b 05 1d 37 06 00 	mov    0x6371d(%rip),%rax        # 6d4d8 <fwp_cleanups>
    9dbb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9dbf:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9dc6:	00 
    9dc7:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9dcb:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9dd2:	00 
    9dd3:	48 8d 05 e6 b4 ff ff 	lea    -0x4b1a(%rip),%rax        # 52c0 <fwp_tape_buffers_release>
    9dda:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9de1:	00 
    9de2:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    9de9:	00 
    9dea:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9def:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9df6:	00 
    9df7:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    9dfe:	00 
    9dff:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9e06:	00 
    9e07:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9e0e:	00 
    9e0f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9e13:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9e17:	48 89 05 ba 36 06 00 	mov    %rax,0x636ba(%rip)        # 6d4d8 <fwp_cleanups>
    9e1e:	4c 89 94 24 f0 00 00 	mov    %r10,0xf0(%rsp)
    9e25:	00 
    9e26:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    9e2d:	00 
    9e2e:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    9e35:	00 
    9e36:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    9e3d:	00 
    9e3e:	4d 85 ed             	test   %r13,%r13
    9e41:	0f 88 49 0d 00 00    	js     ab90 <fwp_hof0.constprop.0+0x1410>
    9e47:	4c 89 e8             	mov    %r13,%rax
    9e4a:	48 c1 f8 20          	sar    $0x20,%rax
    9e4e:	49 39 c7             	cmp    %rax,%r15
    9e51:	0f 85 91 11 00 00    	jne    afe8 <fwp_hof0.constprop.0+0x1868>
    9e57:	44 89 e9             	mov    %r13d,%ecx
    9e5a:	49 89 cf             	mov    %rcx,%r15
    9e5d:	48 39 ca             	cmp    %rcx,%rdx
    9e60:	0f 8e 8e 11 00 00    	jle    aff4 <fwp_hof0.constprop.0+0x1874>
    9e66:	49 39 ce             	cmp    %rcx,%r14
    9e69:	0f 8e c9 0b 00 00    	jle    aa38 <fwp_hof0.constprop.0+0x12b8>
    9e6f:	4d 39 c6             	cmp    %r8,%r14
    9e72:	0f 8f f8 0b 00 00    	jg     aa70 <fwp_hof0.constprop.0+0x12f0>
    9e78:	4d 85 d2             	test   %r10,%r10
    9e7b:	0f 84 39 12 00 00    	je     b0ba <fwp_hof0.constprop.0+0x193a>
    9e81:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    9e86:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9e8a:	31 f6                	xor    %esi,%esi
    9e8c:	4c 89 d7             	mov    %r10,%rdi
    9e8f:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    9e94:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9e9b:	00 
    9e9c:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    9ea1:	e8 0a 96 ff ff       	call   34b0 <memset@plt>
    9ea6:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    9eac:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    9eb2:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    9eb7:	49 89 c2             	mov    %rax,%r10
    9eba:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    9ec0:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    9ec6:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    9ecc:	4d 39 fe             	cmp    %r15,%r14
    9ecf:	0f 8f 8c 00 00 00    	jg     9f61 <fwp_hof0.constprop.0+0x7e1>
    9ed5:	0f 12 fb             	movhlps %xmm3,%xmm7
    9ed8:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    9edd:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9ee2:	4d 29 f7             	sub    %r14,%r15
    9ee5:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    9eea:	0f 12 fa             	movhlps %xmm2,%xmm7
    9eed:	4f 8d 24 f2          	lea    (%r10,%r14,8),%r12
    9ef1:	66 49 0f 7e f8       	movq   %xmm7,%r8
    9ef6:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    9efa:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9efe:	48 29 f1             	sub    %rsi,%rcx
    9f01:	4b 8d 14 f8          	lea    (%r8,%r15,8),%rdx
    9f05:	4d 29 c4             	sub    %r8,%r12
    9f08:	4c 29 c7             	sub    %r8,%rdi
    9f0b:	eb 07                	jmp    9f14 <fwp_hof0.constprop.0+0x794>
    9f0d:	0f 1f 00             	nopl   (%rax)
    9f10:	48 83 e8 04          	sub    $0x4,%rax
    9f14:	f2 41 0f 10 04 14    	movsd  (%r12,%rdx,1),%xmm0
    9f1a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9f1e:	7a 02                	jp     9f22 <fwp_hof0.constprop.0+0x7a2>
    9f20:	74 36                	je     9f58 <fwp_hof0.constprop.0+0x7d8>
    9f22:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    9f26:	45 85 c0             	test   %r8d,%r8d
    9f29:	78 15                	js     9f40 <fwp_hof0.constprop.0+0x7c0>
    9f2b:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    9f30:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9f34:	f2 43 0f 58 0c c2    	addsd  (%r10,%r8,8),%xmm1
    9f3a:	f2 43 0f 11 0c c2    	movsd  %xmm1,(%r10,%r8,8)
    9f40:	4c 63 00             	movslq (%rax),%r8
    9f43:	45 85 c0             	test   %r8d,%r8d
    9f46:	78 10                	js     9f58 <fwp_hof0.constprop.0+0x7d8>
    9f48:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9f4c:	f2 43 0f 58 04 c2    	addsd  (%r10,%r8,8),%xmm0
    9f52:	f2 43 0f 11 04 c2    	movsd  %xmm0,(%r10,%r8,8)
    9f58:	48 83 ea 08          	sub    $0x8,%rdx
    9f5c:	48 39 c6             	cmp    %rax,%rsi
    9f5f:	75 af                	jne    9f10 <fwp_hof0.constprop.0+0x790>
    9f61:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9f68:	ff ff 1f 
    9f6b:	4c 39 f0             	cmp    %r14,%rax
    9f6e:	0f 82 b7 10 00 00    	jb     b02b <fwp_hof0.constprop.0+0x18ab>
    9f74:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9f7b:	00 
    9f7c:	be 02 00 00 00       	mov    $0x2,%esi
    9f81:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    9f86:	e8 e5 bf ff ff       	call   5f70 <fwp_heap_alloc>
    9f8b:	4d 85 f6             	test   %r14,%r14
    9f8e:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    9f93:	4c 89 30             	mov    %r14,(%rax)
    9f96:	49 89 c7             	mov    %rax,%r15
    9f99:	74 17                	je     9fb2 <fwp_hof0.constprop.0+0x832>
    9f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9fa0:	49 8b 04 da          	mov    (%r10,%rbx,8),%rax
    9fa4:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    9fa9:	48 83 c3 01          	add    $0x1,%rbx
    9fad:	49 39 de             	cmp    %rbx,%r14
    9fb0:	75 ee                	jne    9fa0 <fwp_hof0.constprop.0+0x820>
    9fb2:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
    9fb9:	00 
    9fba:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9fbf:	4c 89 2d 12 35 06 00 	mov    %r13,0x63512(%rip)        # 6d4d8 <fwp_cleanups>
    9fc6:	e8 f5 b2 ff ff       	call   52c0 <fwp_tape_buffers_release>
    9fcb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9fd2:	4c 89 f8             	mov    %r15,%rax
    9fd5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9fdc:	48 c1 e2 10          	shl    $0x10,%rdx
    9fe0:	48 39 d0             	cmp    %rdx,%rax
    9fe3:	73 59                	jae    a03e <fwp_hof0.constprop.0+0x8be>
    9fe5:	48 89 c2             	mov    %rax,%rdx
    9fe8:	48 c1 ea 10          	shr    $0x10,%rdx
    9fec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ff0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9ff7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ffb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9fff:	4d 85 e4             	test   %r12,%r12
    a002:	74 3a                	je     a03e <fwp_hof0.constprop.0+0x8be>
    a004:	0f b6 0a             	movzbl (%rdx),%ecx
    a007:	80 f9 02             	cmp    $0x2,%cl
    a00a:	0f 84 b0 0b 00 00    	je     abc0 <fwp_hof0.constprop.0+0x1440>
    a010:	80 f9 01             	cmp    $0x1,%cl
    a013:	75 29                	jne    a03e <fwp_hof0.constprop.0+0x8be>
    a015:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a018:	0f b7 c0             	movzwl %ax,%eax
    a01b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a01e:	48 0f af c1          	imul   %rcx,%rax
    a022:	48 c1 e8 20          	shr    $0x20,%rax
    a026:	48 39 d0             	cmp    %rdx,%rax
    a029:	73 13                	jae    a03e <fwp_hof0.constprop.0+0x8be>
    a02b:	49 01 c4             	add    %rax,%r12
    a02e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a033:	0f 84 9b 0b 00 00    	je     abd4 <fwp_hof0.constprop.0+0x1454>
    a039:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a03e:	4c 3b 6c 24 38       	cmp    0x38(%rsp),%r13
    a043:	0f 85 02 97 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    a049:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a050:	00 
    a051:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a056:	48 89 05 7b 34 06 00 	mov    %rax,0x6347b(%rip)        # 6d4d8 <fwp_cleanups>
    a05d:	e8 5e d0 ff ff       	call   70c0 <fwp_tape_scope_release>
    a062:	49 8b 07             	mov    (%r15),%rax
    a065:	49 89 c6             	mov    %rax,%r14
    a068:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a06d:	48 85 c0             	test   %rax,%rax
    a070:	0f 88 2a 08 00 00    	js     a8a0 <fwp_hof0.constprop.0+0x1120>
    a076:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a07d:	4c 89 f8             	mov    %r15,%rax
    a080:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a087:	48 c1 e2 10          	shl    $0x10,%rdx
    a08b:	48 39 d0             	cmp    %rdx,%rax
    a08e:	0f 83 0c 08 00 00    	jae    a8a0 <fwp_hof0.constprop.0+0x1120>
    a094:	48 89 c2             	mov    %rax,%rdx
    a097:	48 c1 ea 10          	shr    $0x10,%rdx
    a09b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a09f:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a0a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0aa:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a0ae:	48 85 c9             	test   %rcx,%rcx
    a0b1:	0f 84 e9 07 00 00    	je     a8a0 <fwp_hof0.constprop.0+0x1120>
    a0b7:	0f b6 32             	movzbl (%rdx),%esi
    a0ba:	40 80 fe 02          	cmp    $0x2,%sil
    a0be:	0f 84 cc 07 00 00    	je     a890 <fwp_hof0.constprop.0+0x1110>
    a0c4:	40 80 fe 01          	cmp    $0x1,%sil
    a0c8:	0f 85 d2 07 00 00    	jne    a8a0 <fwp_hof0.constprop.0+0x1120>
    a0ce:	8b 72 18             	mov    0x18(%rdx),%esi
    a0d1:	0f b7 c0             	movzwl %ax,%eax
    a0d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0d7:	48 0f af c6          	imul   %rsi,%rax
    a0db:	48 c1 e8 20          	shr    $0x20,%rax
    a0df:	48 39 d0             	cmp    %rdx,%rax
    a0e2:	0f 83 b8 07 00 00    	jae    a8a0 <fwp_hof0.constprop.0+0x1120>
    a0e8:	48 01 c1             	add    %rax,%rcx
    a0eb:	80 39 01             	cmpb   $0x1,(%rcx)
    a0ee:	0f 85 ac 07 00 00    	jne    a8a0 <fwp_hof0.constprop.0+0x1120>
    a0f4:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    a0f9:	4d 89 fc             	mov    %r15,%r12
    a0fc:	31 ff                	xor    %edi,%edi
    a0fe:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a103:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a107:	31 c0                	xor    %eax,%eax
    a109:	4d 85 f6             	test   %r14,%r14
    a10c:	75 2c                	jne    a13a <fwp_hof0.constprop.0+0x9ba>
    a10e:	eb 40                	jmp    a150 <fwp_hof0.constprop.0+0x9d0>
    a110:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a115:	0f 88 e5 0e 00 00    	js     b000 <fwp_hof0.constprop.0+0x1880>
    a11b:	f2 0f 10 05 5d 5c 00 	movsd  0x5c5d(%rip),%xmm0        # fd80 <msg.8+0x40>
    a122:	00 
    a123:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a128:	48 83 c0 01          	add    $0x1,%rax
    a12c:	48 83 c2 08          	add    $0x8,%rdx
    a130:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a135:	49 39 c6             	cmp    %rax,%r14
    a138:	74 16                	je     a150 <fwp_hof0.constprop.0+0x9d0>
    a13a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a13e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a142:	79 cc                	jns    a110 <fwp_hof0.constprop.0+0x990>
    a144:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a148:	eb c6                	jmp    a110 <fwp_hof0.constprop.0+0x990>
    a14a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a150:	e8 bb de ff ff       	call   8010 <fwp_drop10>
    a155:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a15a:	31 d2                	xor    %edx,%edx
    a15c:	48 89 f8             	mov    %rdi,%rax
    a15f:	48 85 ff             	test   %rdi,%rdi
    a162:	0f 84 ac 0c 00 00    	je     ae14 <fwp_hof0.constprop.0+0x1694>
    a168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a16f:	00 
    a170:	48 8b 40 10          	mov    0x10(%rax),%rax
    a174:	48 83 c2 01          	add    $0x1,%rdx
    a178:	48 85 c0             	test   %rax,%rax
    a17b:	75 f3                	jne    a170 <fwp_hof0.constprop.0+0x9f0>
    a17d:	49 8b 04 24          	mov    (%r12),%rax
    a181:	49 89 c7             	mov    %rax,%r15
    a184:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a189:	48 85 c0             	test   %rax,%rax
    a18c:	0f 88 cb 05 00 00    	js     a75d <fwp_hof0.constprop.0+0xfdd>
    a192:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a199:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a19e:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    a1a5:	48 c1 e0 10          	shl    $0x10,%rax
    a1a9:	48 39 c1             	cmp    %rax,%rcx
    a1ac:	0f 83 ab 05 00 00    	jae    a75d <fwp_hof0.constprop.0+0xfdd>
    a1b2:	48 89 c8             	mov    %rcx,%rax
    a1b5:	48 c1 e8 10          	shr    $0x10,%rax
    a1b9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a1bd:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a1c4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a1c8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a1cc:	48 85 ff             	test   %rdi,%rdi
    a1cf:	0f 84 88 05 00 00    	je     a75d <fwp_hof0.constprop.0+0xfdd>
    a1d5:	0f b6 06             	movzbl (%rsi),%eax
    a1d8:	3c 02                	cmp    $0x2,%al
    a1da:	0f 84 68 05 00 00    	je     a748 <fwp_hof0.constprop.0+0xfc8>
    a1e0:	3c 01                	cmp    $0x1,%al
    a1e2:	0f 85 69 05 00 00    	jne    a751 <fwp_hof0.constprop.0+0xfd1>
    a1e8:	8b 46 18             	mov    0x18(%rsi),%eax
    a1eb:	0f b7 c9             	movzwl %cx,%ecx
    a1ee:	48 0f af c8          	imul   %rax,%rcx
    a1f2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a1f5:	48 c1 e9 20          	shr    $0x20,%rcx
    a1f9:	48 39 c1             	cmp    %rax,%rcx
    a1fc:	0f 83 4f 05 00 00    	jae    a751 <fwp_hof0.constprop.0+0xfd1>
    a202:	48 01 cf             	add    %rcx,%rdi
    a205:	80 3f 01             	cmpb   $0x1,(%rdi)
    a208:	0f 85 43 05 00 00    	jne    a751 <fwp_hof0.constprop.0+0xfd1>
    a20e:	49 39 d7             	cmp    %rdx,%r15
    a211:	48 89 d0             	mov    %rdx,%rax
    a214:	49 0f 46 c7          	cmovbe %r15,%rax
    a218:	48 85 c0             	test   %rax,%rax
    a21b:	0f 84 eb 0d 00 00    	je     b00c <fwp_hof0.constprop.0+0x188c>
    a221:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    a228:	00 
    a229:	49 8d 5c 24 08       	lea    0x8(%r12),%rbx
    a22e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a233:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a238:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a23f:	00 
    a240:	31 d2                	xor    %edx,%edx
    a242:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a246:	eb 54                	jmp    a29c <fwp_hof0.constprop.0+0xb1c>
    a248:	90                   	nop
    a249:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a250:	00 00 00 00 
    a254:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a25b:	00 00 00 00 
    a25f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a266:	00 00 00 00 
    a26a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a271:	00 00 00 00 
    a275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a27c:	00 00 00 00 
    a280:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a285:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a28a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a28f:	48 83 c2 08          	add    $0x8,%rdx
    a293:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a297:	49 39 d1             	cmp    %rdx,%r9
    a29a:	74 14                	je     a2b0 <fwp_hof0.constprop.0+0xb30>
    a29c:	48 89 fe             	mov    %rdi,%rsi
    a29f:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a2a4:	79 da                	jns    a280 <fwp_hof0.constprop.0+0xb00>
    a2a6:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a2aa:	eb d4                	jmp    a280 <fwp_hof0.constprop.0+0xb00>
    a2ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a2b0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a2b5:	48 85 c9             	test   %rcx,%rcx
    a2b8:	0f 84 22 0d 00 00    	je     afe0 <fwp_hof0.constprop.0+0x1860>
    a2be:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a2c5:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a2cc:	45 31 ff             	xor    %r15d,%r15d
    a2cf:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a2d6:	49 c1 e1 10          	shl    $0x10,%r9
    a2da:	eb 1a                	jmp    a2f6 <fwp_hof0.constprop.0+0xb76>
    a2dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a2e0:	49 83 c7 01          	add    $0x1,%r15
    a2e4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a2e8:	49 39 c7             	cmp    %rax,%r15
    a2eb:	0f 83 5f 01 00 00    	jae    a450 <fwp_hof0.constprop.0+0xcd0>
    a2f1:	48 85 c9             	test   %rcx,%rcx
    a2f4:	74 56                	je     a34c <fwp_hof0.constprop.0+0xbcc>
    a2f6:	48 89 ca             	mov    %rcx,%rdx
    a2f9:	4c 29 d2             	sub    %r10,%rdx
    a2fc:	4c 39 ca             	cmp    %r9,%rdx
    a2ff:	73 4b                	jae    a34c <fwp_hof0.constprop.0+0xbcc>
    a301:	48 89 d6             	mov    %rdx,%rsi
    a304:	48 c1 ee 10          	shr    $0x10,%rsi
    a308:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a30c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a310:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a314:	48 85 ff             	test   %rdi,%rdi
    a317:	74 33                	je     a34c <fwp_hof0.constprop.0+0xbcc>
    a319:	44 0f b6 06          	movzbl (%rsi),%r8d
    a31d:	41 80 f8 02          	cmp    $0x2,%r8b
    a321:	0f 84 11 01 00 00    	je     a438 <fwp_hof0.constprop.0+0xcb8>
    a327:	41 80 f8 01          	cmp    $0x1,%r8b
    a32b:	75 1f                	jne    a34c <fwp_hof0.constprop.0+0xbcc>
    a32d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a331:	0f b7 d2             	movzwl %dx,%edx
    a334:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a337:	49 0f af d0          	imul   %r8,%rdx
    a33b:	48 c1 ea 20          	shr    $0x20,%rdx
    a33f:	48 39 f2             	cmp    %rsi,%rdx
    a342:	73 08                	jae    a34c <fwp_hof0.constprop.0+0xbcc>
    a344:	48 01 d7             	add    %rdx,%rdi
    a347:	80 3f 01             	cmpb   $0x1,(%rdi)
    a34a:	74 94                	je     a2e0 <fwp_hof0.constprop.0+0xb60>
    a34c:	49 39 c7             	cmp    %rax,%r15
    a34f:	0f 83 fb 00 00 00    	jae    a450 <fwp_hof0.constprop.0+0xcd0>
    a355:	49 89 c5             	mov    %rax,%r13
    a358:	45 31 f6             	xor    %r14d,%r14d
    a35b:	eb 37                	jmp    a394 <fwp_hof0.constprop.0+0xc14>
    a35d:	0f 1f 00             	nopl   (%rax)
    a360:	40 80 fe 01          	cmp    $0x1,%sil
    a364:	75 25                	jne    a38b <fwp_hof0.constprop.0+0xc0b>
    a366:	8b 71 18             	mov    0x18(%rcx),%esi
    a369:	0f b7 c0             	movzwl %ax,%eax
    a36c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a36f:	48 0f af c6          	imul   %rsi,%rax
    a373:	48 c1 e8 20          	shr    $0x20,%rax
    a377:	48 39 c8             	cmp    %rcx,%rax
    a37a:	73 0f                	jae    a38b <fwp_hof0.constprop.0+0xc0b>
    a37c:	48 01 c2             	add    %rax,%rdx
    a37f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a382:	0f 84 60 06 00 00    	je     a9e8 <fwp_hof0.constprop.0+0x1268>
    a388:	c6 02 01             	movb   $0x1,(%rdx)
    a38b:	4d 39 ef             	cmp    %r13,%r15
    a38e:	0f 83 8c 00 00 00    	jae    a420 <fwp_hof0.constprop.0+0xca0>
    a394:	49 83 ed 01          	sub    $0x1,%r13
    a398:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a39d:	bf 01 00 00 00       	mov    $0x1,%edi
    a3a2:	f3 42 0f 7e 04 eb    	movq   (%rbx,%r13,8),%xmm0
    a3a8:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    a3af:	00 
    a3b0:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a3b4:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    a3bb:	00 
    a3bc:	e8 9f bd ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    a3c1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a3c8:	49 89 c6             	mov    %rax,%r14
    a3cb:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a3d2:	48 c1 e2 10          	shl    $0x10,%rdx
    a3d6:	48 39 d0             	cmp    %rdx,%rax
    a3d9:	73 b0                	jae    a38b <fwp_hof0.constprop.0+0xc0b>
    a3db:	48 89 c2             	mov    %rax,%rdx
    a3de:	48 c1 ea 10          	shr    $0x10,%rdx
    a3e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3e6:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a3ed:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a3f1:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a3f5:	48 85 d2             	test   %rdx,%rdx
    a3f8:	74 91                	je     a38b <fwp_hof0.constprop.0+0xc0b>
    a3fa:	0f b6 31             	movzbl (%rcx),%esi
    a3fd:	40 80 fe 02          	cmp    $0x2,%sil
    a401:	0f 85 59 ff ff ff    	jne    a360 <fwp_hof0.constprop.0+0xbe0>
    a407:	66 85 c0             	test   %ax,%ax
    a40a:	0f 84 6f ff ff ff    	je     a37f <fwp_hof0.constprop.0+0xbff>
    a410:	4d 39 ef             	cmp    %r13,%r15
    a413:	0f 82 7b ff ff ff    	jb     a394 <fwp_hof0.constprop.0+0xc14>
    a419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a420:	4d 85 ff             	test   %r15,%r15
    a423:	75 2e                	jne    a453 <fwp_hof0.constprop.0+0xcd3>
    a425:	8b 44 24 30          	mov    0x30(%rsp),%eax
    a429:	85 c0                	test   %eax,%eax
    a42b:	49 0f 45 df          	cmovne %r15,%rbx
    a42f:	eb 62                	jmp    a493 <fwp_hof0.constprop.0+0xd13>
    a431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a438:	66 85 d2             	test   %dx,%dx
    a43b:	0f 84 06 ff ff ff    	je     a347 <fwp_hof0.constprop.0+0xbc7>
    a441:	49 39 c7             	cmp    %rax,%r15
    a444:	0f 82 0b ff ff ff    	jb     a355 <fwp_hof0.constprop.0+0xbd5>
    a44a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a450:	45 31 f6             	xor    %r14d,%r14d
    a453:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a458:	48 89 da             	mov    %rbx,%rdx
    a45b:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a45f:	90                   	nop
    a460:	48 8b 0a             	mov    (%rdx),%rcx
    a463:	48 83 c2 08          	add    $0x8,%rdx
    a467:	48 89 c7             	mov    %rax,%rdi
    a46a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a46e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a472:	49 39 d1             	cmp    %rdx,%r9
    a475:	75 e9                	jne    a460 <fwp_hof0.constprop.0+0xce0>
    a477:	8b 54 24 30          	mov    0x30(%rsp),%edx
    a47b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a47f:	85 d2                	test   %edx,%edx
    a481:	0f 84 61 07 00 00    	je     abe8 <fwp_hof0.constprop.0+0x1468>
    a487:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a48c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a491:	31 db                	xor    %ebx,%ebx
    a493:	48 89 df             	mov    %rbx,%rdi
    a496:	e8 d5 b5 ff ff       	call   5a70 <fwp_mem_free>
    a49b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a4a0:	e8 6b db ff ff       	call   8010 <fwp_drop10>
    a4a5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a4ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a4b1:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a4b8:	48 c1 e2 10          	shl    $0x10,%rdx
    a4bc:	48 39 d0             	cmp    %rdx,%rax
    a4bf:	73 6f                	jae    a530 <fwp_hof0.constprop.0+0xdb0>
    a4c1:	48 89 c2             	mov    %rax,%rdx
    a4c4:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a4cb:	48 c1 ea 10          	shr    $0x10,%rdx
    a4cf:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a4d3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a4d7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a4db:	4d 85 e4             	test   %r12,%r12
    a4de:	74 50                	je     a530 <fwp_hof0.constprop.0+0xdb0>
    a4e0:	0f b6 0a             	movzbl (%rdx),%ecx
    a4e3:	80 f9 02             	cmp    $0x2,%cl
    a4e6:	0f 84 84 06 00 00    	je     ab70 <fwp_hof0.constprop.0+0x13f0>
    a4ec:	80 f9 01             	cmp    $0x1,%cl
    a4ef:	75 3f                	jne    a530 <fwp_hof0.constprop.0+0xdb0>
    a4f1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4f4:	0f b7 c0             	movzwl %ax,%eax
    a4f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4fa:	48 0f af c1          	imul   %rcx,%rax
    a4fe:	48 c1 e8 20          	shr    $0x20,%rax
    a502:	48 39 d0             	cmp    %rdx,%rax
    a505:	73 29                	jae    a530 <fwp_hof0.constprop.0+0xdb0>
    a507:	49 01 c4             	add    %rax,%r12
    a50a:	41 0f b6 04 24       	movzbl (%r12),%eax
    a50f:	84 c0                	test   %al,%al
    a511:	74 1d                	je     a530 <fwp_hof0.constprop.0+0xdb0>
    a513:	3c 01                	cmp    $0x1,%al
    a515:	0f 84 e5 06 00 00    	je     ac00 <fwp_hof0.constprop.0+0x1480>
    a51b:	3c ff                	cmp    $0xff,%al
    a51d:	0f 84 6c 09 00 00    	je     ae8f <fwp_hof0.constprop.0+0x170f>
    a523:	83 e8 01             	sub    $0x1,%eax
    a526:	41 88 04 24          	mov    %al,(%r12)
    a52a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a530:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a536:	0f 85 dc 05 00 00    	jne    ab18 <fwp_hof0.constprop.0+0x1398>
    a53c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a541:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a545:	4c 89 f6             	mov    %r14,%rsi
    a548:	4d 89 f4             	mov    %r14,%r12
    a54b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a550:	48 8d 15 49 86 00 00 	lea    0x8649(%rip),%rdx        # 12ba0 <d0>
    a557:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    a55e:	00 00 00 00 00 
    a563:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    a56a:	00 
    a56b:	e8 d0 e1 ff ff       	call   8740 <fwp_write>
    a570:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    a577:	00 
    a578:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    a57f:	00 
    a580:	48 8d 05 e5 4a 00 00 	lea    0x4ae5(%rip),%rax        # f06c <_IO_stdin_used+0x6c>
    a587:	4d 85 f6             	test   %r14,%r14
    a58a:	4c 0f 44 f0          	cmove  %rax,%r14
    a58e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a592:	0f 87 d9 0a 00 00    	ja     b071 <fwp_hof0.constprop.0+0x18f1>
    a598:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a59c:	be 01 00 00 00       	mov    $0x1,%esi
    a5a1:	e8 ca b9 ff ff       	call   5f70 <fwp_heap_alloc>
    a5a6:	4c 89 fa             	mov    %r15,%rdx
    a5a9:	4c 89 f6             	mov    %r14,%rsi
    a5ac:	4c 89 38             	mov    %r15,(%rax)
    a5af:	48 89 c3             	mov    %rax,%rbx
    a5b2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a5b6:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a5ba:	e8 c1 8f ff ff       	call   3580 <memcpy@plt>
    a5bf:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a5c5:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    a5cc:	00 
    a5cd:	e8 de 8d ff ff       	call   33b0 <free@plt>
    a5d2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5d9:	48 89 d8             	mov    %rbx,%rax
    a5dc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a5e3:	48 c1 e2 10          	shl    $0x10,%rdx
    a5e7:	48 39 d0             	cmp    %rdx,%rax
    a5ea:	73 57                	jae    a643 <fwp_hof0.constprop.0+0xec3>
    a5ec:	48 89 c2             	mov    %rax,%rdx
    a5ef:	48 c1 ea 10          	shr    $0x10,%rdx
    a5f3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5f7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a5fe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a602:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a606:	4d 85 ff             	test   %r15,%r15
    a609:	74 38                	je     a643 <fwp_hof0.constprop.0+0xec3>
    a60b:	0f b6 0a             	movzbl (%rdx),%ecx
    a60e:	80 f9 02             	cmp    $0x2,%cl
    a611:	0f 84 a1 07 00 00    	je     adb8 <fwp_hof0.constprop.0+0x1638>
    a617:	80 f9 01             	cmp    $0x1,%cl
    a61a:	75 27                	jne    a643 <fwp_hof0.constprop.0+0xec3>
    a61c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a61f:	0f b7 c0             	movzwl %ax,%eax
    a622:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a625:	48 0f af c1          	imul   %rcx,%rax
    a629:	48 c1 e8 20          	shr    $0x20,%rax
    a62d:	48 39 d0             	cmp    %rdx,%rax
    a630:	73 11                	jae    a643 <fwp_hof0.constprop.0+0xec3>
    a632:	49 01 c7             	add    %rax,%r15
    a635:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a639:	0f 84 8c 07 00 00    	je     adcb <fwp_hof0.constprop.0+0x164b>
    a63f:	41 c6 07 01          	movb   $0x1,(%r15)
    a643:	4c 89 e7             	mov    %r12,%rdi
    a646:	e8 d5 d5 ff ff       	call   7c20 <fwp_drop0>
    a64b:	48 8b 13             	mov    (%rbx),%rdx
    a64e:	be 01 00 00 00       	mov    $0x1,%esi
    a653:	4c 89 ef             	mov    %r13,%rdi
    a656:	48 8b 0d 43 2e 06 00 	mov    0x62e43(%rip),%rcx        # 6d4a0 <fwp_prog_out>
    a65d:	e8 fe 8f ff ff       	call   3660 <fwrite@plt>
    a662:	48 8b 35 37 2e 06 00 	mov    0x62e37(%rip),%rsi        # 6d4a0 <fwp_prog_out>
    a669:	bf 0a 00 00 00       	mov    $0xa,%edi
    a66e:	e8 5d 8e ff ff       	call   34d0 <fputc@plt>
    a673:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a67a:	48 89 d8             	mov    %rbx,%rax
    a67d:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a684:	48 c1 e2 10          	shl    $0x10,%rdx
    a688:	48 39 d0             	cmp    %rdx,%rax
    a68b:	73 73                	jae    a700 <fwp_hof0.constprop.0+0xf80>
    a68d:	48 89 c2             	mov    %rax,%rdx
    a690:	48 c1 ea 10          	shr    $0x10,%rdx
    a694:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a698:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a69f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a6a3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a6a7:	4d 85 e4             	test   %r12,%r12
    a6aa:	74 54                	je     a700 <fwp_hof0.constprop.0+0xf80>
    a6ac:	0f b6 0a             	movzbl (%rdx),%ecx
    a6af:	80 f9 02             	cmp    $0x2,%cl
    a6b2:	0f 84 28 07 00 00    	je     ade0 <fwp_hof0.constprop.0+0x1660>
    a6b8:	80 f9 01             	cmp    $0x1,%cl
    a6bb:	75 43                	jne    a700 <fwp_hof0.constprop.0+0xf80>
    a6bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a6c0:	0f b7 c0             	movzwl %ax,%eax
    a6c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a6c6:	48 0f af c1          	imul   %rcx,%rax
    a6ca:	48 c1 e8 20          	shr    $0x20,%rax
    a6ce:	48 39 d0             	cmp    %rdx,%rax
    a6d1:	73 2d                	jae    a700 <fwp_hof0.constprop.0+0xf80>
    a6d3:	49 01 c4             	add    %rax,%r12
    a6d6:	41 0f b6 04 24       	movzbl (%r12),%eax
    a6db:	84 c0                	test   %al,%al
    a6dd:	74 21                	je     a700 <fwp_hof0.constprop.0+0xf80>
    a6df:	3c 01                	cmp    $0x1,%al
    a6e1:	0f 84 17 07 00 00    	je     adfe <fwp_hof0.constprop.0+0x167e>
    a6e7:	3c ff                	cmp    $0xff,%al
    a6e9:	0f 84 71 08 00 00    	je     af60 <fwp_hof0.constprop.0+0x17e0>
    a6ef:	83 e8 01             	sub    $0x1,%eax
    a6f2:	41 88 04 24          	mov    %al,(%r12)
    a6f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a6fd:	00 00 00 
    a700:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a705:	48 8b 40 10          	mov    0x10(%rax),%rax
    a709:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a70e:	48 85 c0             	test   %rax,%rax
    a711:	0f 85 a9 f0 ff ff    	jne    97c0 <fwp_hof0.constprop.0+0x40>
    a717:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    a71e:	00 
    a71f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a726:	00 00 
    a728:	0f 85 eb 09 00 00    	jne    b119 <fwp_hof0.constprop.0+0x1999>
    a72e:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    a735:	31 c0                	xor    %eax,%eax
    a737:	5b                   	pop    %rbx
    a738:	5d                   	pop    %rbp
    a739:	41 5c                	pop    %r12
    a73b:	41 5d                	pop    %r13
    a73d:	41 5e                	pop    %r14
    a73f:	41 5f                	pop    %r15
    a741:	c3                   	ret
    a742:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a748:	66 85 c9             	test   %cx,%cx
    a74b:	0f 84 b4 fa ff ff    	je     a205 <fwp_hof0.constprop.0+0xa85>
    a751:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a757:	0f 84 ba 02 00 00    	je     aa17 <fwp_hof0.constprop.0+0x1297>
    a75d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a762:	45 31 f6             	xor    %r14d,%r14d
    a765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a76c:	00 00 00 00 
    a770:	48 8b 40 10          	mov    0x10(%rax),%rax
    a774:	4c 89 f2             	mov    %r14,%rdx
    a777:	49 83 c6 01          	add    $0x1,%r14
    a77b:	48 85 c0             	test   %rax,%rax
    a77e:	75 f0                	jne    a770 <fwp_hof0.constprop.0+0xff0>
    a780:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a787:	ff ff 1f 
    a78a:	4c 39 f0             	cmp    %r14,%rax
    a78d:	0f 82 80 08 00 00    	jb     b013 <fwp_hof0.constprop.0+0x1893>
    a793:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a79a:	00 
    a79b:	be 02 00 00 00       	mov    $0x2,%esi
    a7a0:	e8 cb b7 ff ff       	call   5f70 <fwp_heap_alloc>
    a7a5:	4d 39 fe             	cmp    %r15,%r14
    a7a8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a7ad:	48 89 c3             	mov    %rax,%rbx
    a7b0:	4c 89 f8             	mov    %r15,%rax
    a7b3:	49 0f 46 c6          	cmovbe %r14,%rax
    a7b7:	48 89 d9             	mov    %rbx,%rcx
    a7ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a7c4:	48 83 c1 08          	add    $0x8,%rcx
    a7c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a7cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a7d0:	48 85 d2             	test   %rdx,%rdx
    a7d3:	75 eb                	jne    a7c0 <fwp_hof0.constprop.0+0x1040>
    a7d5:	48 85 c0             	test   %rax,%rax
    a7d8:	0f 84 4b 02 00 00    	je     aa29 <fwp_hof0.constprop.0+0x12a9>
    a7de:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a7e5:	00 
    a7e6:	e9 43 fa ff ff       	jmp    a22e <fwp_hof0.constprop.0+0xaae>
    a7eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a7f0:	4d 39 f4             	cmp    %r14,%r12
    a7f3:	0f 84 e7 f1 ff ff    	je     99e0 <fwp_hof0.constprop.0+0x260>
    a7f9:	4c 8b 3d 10 89 01 00 	mov    0x18910(%rip),%r15        # 23110 <fwp_tapes>
    a800:	e9 80 f2 ff ff       	jmp    9a85 <fwp_hof0.constprop.0+0x305>
    a805:	0f 1f 00             	nopl   (%rax)
    a808:	48 83 3d 98 88 01 00 	cmpq   $0x0,0x18898(%rip)        # 230a8 <fwp_tape_cached_bytes>
    a80f:	00 
    a810:	0f 84 b6 f2 ff ff    	je     9acc <fwp_hof0.constprop.0+0x34c>
    a816:	66 0f 6f 0d a2 88 01 	movdqa 0x188a2(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    a81d:	00 
    a81e:	48 c7 05 7f 88 01 00 	movq   $0x0,0x1887f(%rip)        # 230a8 <fwp_tape_cached_bytes>
    a825:	00 00 00 00 
    a829:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    a82f:	48 8b 05 aa 88 01 00 	mov    0x188aa(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    a836:	66 0f 6f 0d 92 88 01 	movdqa 0x18892(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    a83d:	00 
    a83e:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a843:	48 8b 05 9e 88 01 00 	mov    0x1889e(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    a84a:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    a850:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a854:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    a859:	48 8b 05 90 88 01 00 	mov    0x18890(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    a860:	0f 29 0d 59 88 01 00 	movaps %xmm1,0x18859(%rip)        # 230c0 <fwp_tape_workspace>
    a867:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a86c:	0f 29 0d 5d 88 01 00 	movaps %xmm1,0x1885d(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    a873:	48 c7 05 72 88 01 00 	movq   $0x0,0x18872(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    a87a:	00 00 00 00 
    a87e:	0f 29 0d 5b 88 01 00 	movaps %xmm1,0x1885b(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    a885:	e9 42 f2 ff ff       	jmp    9acc <fwp_hof0.constprop.0+0x34c>
    a88a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a890:	66 85 c0             	test   %ax,%ax
    a893:	0f 84 52 f8 ff ff    	je     a0eb <fwp_hof0.constprop.0+0x96b>
    a899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a8a7:	ff ff 1f 
    a8aa:	4c 39 f0             	cmp    %r14,%rax
    a8ad:	0f 82 78 07 00 00    	jb     b02b <fwp_hof0.constprop.0+0x18ab>
    a8b3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a8ba:	00 
    a8bb:	be 01 00 00 00       	mov    $0x1,%esi
    a8c0:	e8 ab b6 ff ff       	call   5f70 <fwp_heap_alloc>
    a8c5:	4c 89 30             	mov    %r14,(%rax)
    a8c8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8cf:	49 89 c4             	mov    %rax,%r12
    a8d2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a8d7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a8de:	48 c1 e2 10          	shl    $0x10,%rdx
    a8e2:	48 39 d0             	cmp    %rdx,%rax
    a8e5:	73 57                	jae    a93e <fwp_hof0.constprop.0+0x11be>
    a8e7:	48 89 c2             	mov    %rax,%rdx
    a8ea:	48 c1 ea 10          	shr    $0x10,%rdx
    a8ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8f2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a8f9:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a8fd:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a901:	48 85 db             	test   %rbx,%rbx
    a904:	74 38                	je     a93e <fwp_hof0.constprop.0+0x11be>
    a906:	0f b6 31             	movzbl (%rcx),%esi
    a909:	40 80 fe 02          	cmp    $0x2,%sil
    a90d:	0f 84 95 03 00 00    	je     aca8 <fwp_hof0.constprop.0+0x1528>
    a913:	40 80 fe 01          	cmp    $0x1,%sil
    a917:	75 25                	jne    a93e <fwp_hof0.constprop.0+0x11be>
    a919:	8b 71 18             	mov    0x18(%rcx),%esi
    a91c:	0f b7 c0             	movzwl %ax,%eax
    a91f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a922:	48 0f af c6          	imul   %rsi,%rax
    a926:	48 c1 e8 20          	shr    $0x20,%rax
    a92a:	48 39 c8             	cmp    %rcx,%rax
    a92d:	73 0f                	jae    a93e <fwp_hof0.constprop.0+0x11be>
    a92f:	48 01 c3             	add    %rax,%rbx
    a932:	80 3b ff             	cmpb   $0xff,(%rbx)
    a935:	0f 84 7f 03 00 00    	je     acba <fwp_hof0.constprop.0+0x153a>
    a93b:	c6 03 01             	movb   $0x1,(%rbx)
    a93e:	4c 89 ff             	mov    %r15,%rdi
    a941:	e9 b8 f7 ff ff       	jmp    a0fe <fwp_hof0.constprop.0+0x97e>
    a946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a94d:	00 00 00 
    a950:	48 c1 e1 10          	shl    $0x10,%rcx
    a954:	bf 08 00 00 00       	mov    $0x8,%edi
    a959:	48 09 f1             	or     %rsi,%rcx
    a95c:	be 02 00 00 00       	mov    $0x2,%esi
    a961:	49 89 cc             	mov    %rcx,%r12
    a964:	e8 07 b6 ff ff       	call   5f70 <fwp_heap_alloc>
    a969:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a970:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a977:	49 89 c6             	mov    %rax,%r14
    a97a:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a981:	48 c1 e2 10          	shl    $0x10,%rdx
    a985:	48 39 d0             	cmp    %rdx,%rax
    a988:	0f 83 82 00 00 00    	jae    aa10 <fwp_hof0.constprop.0+0x1290>
    a98e:	48 89 c2             	mov    %rax,%rdx
    a991:	48 c1 ea 10          	shr    $0x10,%rdx
    a995:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a999:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a9a0:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a9a4:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a9a8:	4d 85 ff             	test   %r15,%r15
    a9ab:	0f 84 03 f3 ff ff    	je     9cb4 <fwp_hof0.constprop.0+0x534>
    a9b1:	0f b6 32             	movzbl (%rdx),%esi
    a9b4:	45 31 ed             	xor    %r13d,%r13d
    a9b7:	40 80 fe 02          	cmp    $0x2,%sil
    a9bb:	0f 85 7a f2 ff ff    	jne    9c3b <fwp_hof0.constprop.0+0x4bb>
    a9c1:	66 85 c0             	test   %ax,%ax
    a9c4:	0f 85 9e f2 ff ff    	jne    9c68 <fwp_hof0.constprop.0+0x4e8>
    a9ca:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a9ce:	0f 85 90 f2 ff ff    	jne    9c64 <fwp_hof0.constprop.0+0x4e4>
    a9d4:	4c 89 ff             	mov    %r15,%rdi
    a9d7:	e8 54 ae ff ff       	call   5830 <fwp_rc_forget_slot>
    a9dc:	e9 83 f2 ff ff       	jmp    9c64 <fwp_hof0.constprop.0+0x4e4>
    a9e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9e8:	48 89 d7             	mov    %rdx,%rdi
    a9eb:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a9f0:	e8 3b ae ff ff       	call   5830 <fwp_rc_forget_slot>
    a9f5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a9fa:	e9 89 f9 ff ff       	jmp    a388 <fwp_hof0.constprop.0+0xc08>
    a9ff:	90                   	nop
    aa00:	4d 85 ed             	test   %r13,%r13
    aa03:	0f 85 64 f2 ff ff    	jne    9c6d <fwp_hof0.constprop.0+0x4ed>
    aa09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa10:	31 d2                	xor    %edx,%edx
    aa12:	e9 0c f3 ff ff       	jmp    9d23 <fwp_hof0.constprop.0+0x5a3>
    aa17:	be 02 00 00 00       	mov    $0x2,%esi
    aa1c:	bf 08 00 00 00       	mov    $0x8,%edi
    aa21:	e8 4a b5 ff ff       	call   5f70 <fwp_heap_alloc>
    aa26:	48 89 c3             	mov    %rax,%rbx
    aa29:	45 31 f6             	xor    %r14d,%r14d
    aa2c:	e9 62 fa ff ff       	jmp    a493 <fwp_hof0.constprop.0+0xd13>
    aa31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa38:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    aa3c:	4d 39 e0             	cmp    %r12,%r8
    aa3f:	7c 32                	jl     aa73 <fwp_hof0.constprop.0+0x12f3>
    aa41:	4d 85 d2             	test   %r10,%r10
    aa44:	0f 84 70 06 00 00    	je     b0ba <fwp_hof0.constprop.0+0x193a>
    aa4a:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    aa4f:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    aa56:	00 
    aa57:	31 f6                	xor    %esi,%esi
    aa59:	4c 89 d7             	mov    %r10,%rdi
    aa5c:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    aa61:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    aa66:	e9 36 f4 ff ff       	jmp    9ea1 <fwp_hof0.constprop.0+0x721>
    aa6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aa70:	4d 89 f4             	mov    %r14,%r12
    aa73:	4d 85 c0             	test   %r8,%r8
    aa76:	4d 0f 44 c4          	cmove  %r12,%r8
    aa7a:	eb 19                	jmp    aa95 <fwp_hof0.constprop.0+0x1315>
    aa7c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa80:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    aa84:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    aa8b:	4c 89 e0             	mov    %r12,%rax
    aa8e:	48 0f 4c c2          	cmovl  %rdx,%rax
    aa92:	49 89 c0             	mov    %rax,%r8
    aa95:	4d 39 e0             	cmp    %r12,%r8
    aa98:	7c e6                	jl     aa80 <fwp_hof0.constprop.0+0x1300>
    aa9a:	4d 85 d2             	test   %r10,%r10
    aa9d:	0f 84 2d 02 00 00    	je     acd0 <fwp_hof0.constprop.0+0x1550>
    aaa3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    aaaa:	00 
    aaab:	4c 89 d7             	mov    %r10,%rdi
    aaae:	ba 03 00 00 00       	mov    $0x3,%edx
    aab3:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
    aab8:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    aabd:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    aac2:	e8 29 a7 ff ff       	call   51f0 <ad_raw_realloc>
    aac7:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
    aacc:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    aad2:	48 85 c0             	test   %rax,%rax
    aad5:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    aadb:	49 89 c2             	mov    %rax,%r10
    aade:	0f 84 bc 02 00 00    	je     ada0 <fwp_hof0.constprop.0+0x1620>
    aae4:	4c 89 94 24 f0 00 00 	mov    %r10,0xf0(%rsp)
    aaeb:	00 
    aaec:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
    aaf3:	00 
    aaf4:	4d 85 e4             	test   %r12,%r12
    aaf7:	0f 85 18 04 00 00    	jne    af15 <fwp_hof0.constprop.0+0x1795>
    aafd:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ab04:	4d 85 ed             	test   %r13,%r13
    ab07:	0f 88 bf f3 ff ff    	js     9ecc <fwp_hof0.constprop.0+0x74c>
    ab0d:	44 89 e9             	mov    %r13d,%ecx
    ab10:	e9 a5 f3 ff ff       	jmp    9eba <fwp_hof0.constprop.0+0x73a>
    ab15:	0f 1f 00             	nopl   (%rax)
    ab18:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    ab1d:	45 31 c9             	xor    %r9d,%r9d
    ab20:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    ab25:	48 83 e8 01          	sub    $0x1,%rax
    ab29:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    ab2e:	41 0f 90 c1          	seto   %r9b
    ab32:	e9 2c ed ff ff       	jmp    9863 <fwp_hof0.constprop.0+0xe3>
    ab37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab3e:	00 00 
    ab40:	48 8d 3d 59 c4 ff ff 	lea    -0x3ba7(%rip),%rdi        # 6fa0 <fwp_tape_finish>
    ab47:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    ab4d:	e8 fe 3c 00 00       	call   e850 <atexit>
    ab52:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    ab58:	85 c0                	test   %eax,%eax
    ab5a:	0f 85 e3 04 00 00    	jne    b043 <fwp_hof0.constprop.0+0x18c3>
    ab60:	c7 05 12 85 00 00 01 	movl   $0x1,0x8512(%rip)        # 1307c <registered_finish.5>
    ab67:	00 00 00 
    ab6a:	e9 2e ee ff ff       	jmp    999d <fwp_hof0.constprop.0+0x21d>
    ab6f:	90                   	nop
    ab70:	66 85 c0             	test   %ax,%ax
    ab73:	0f 85 b7 f9 ff ff    	jne    a530 <fwp_hof0.constprop.0+0xdb0>
    ab79:	e9 8c f9 ff ff       	jmp    a50a <fwp_hof0.constprop.0+0xd8a>
    ab7e:	66 90                	xchg   %ax,%ax
    ab80:	66 85 c0             	test   %ax,%ax
    ab83:	0f 85 c7 ed ff ff    	jne    9950 <fwp_hof0.constprop.0+0x1d0>
    ab89:	e9 9a ed ff ff       	jmp    9928 <fwp_hof0.constprop.0+0x1a8>
    ab8e:	66 90                	xchg   %ax,%ax
    ab90:	4d 39 c6             	cmp    %r8,%r14
    ab93:	0f 8f d7 fe ff ff    	jg     aa70 <fwp_hof0.constprop.0+0x12f0>
    ab99:	4d 85 f6             	test   %r14,%r14
    ab9c:	74 12                	je     abb0 <fwp_hof0.constprop.0+0x1430>
    ab9e:	4d 85 d2             	test   %r10,%r10
    aba1:	0f 84 13 05 00 00    	je     b0ba <fwp_hof0.constprop.0+0x193a>
    aba7:	4d 85 f6             	test   %r14,%r14
    abaa:	0f 85 62 03 00 00    	jne    af12 <fwp_hof0.constprop.0+0x1792>
    abb0:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    abb7:	e9 10 f3 ff ff       	jmp    9ecc <fwp_hof0.constprop.0+0x74c>
    abbc:	0f 1f 40 00          	nopl   0x0(%rax)
    abc0:	66 85 c0             	test   %ax,%ax
    abc3:	0f 85 75 f4 ff ff    	jne    a03e <fwp_hof0.constprop.0+0x8be>
    abc9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    abce:	0f 85 65 f4 ff ff    	jne    a039 <fwp_hof0.constprop.0+0x8b9>
    abd4:	4c 89 e7             	mov    %r12,%rdi
    abd7:	e8 54 ac ff ff       	call   5830 <fwp_rc_forget_slot>
    abdc:	e9 58 f4 ff ff       	jmp    a039 <fwp_hof0.constprop.0+0x8b9>
    abe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abe8:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    abed:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    abf2:	e9 9c f8 ff ff       	jmp    a493 <fwp_hof0.constprop.0+0xd13>
    abf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    abfe:	00 00 
    ac00:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac05:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ac0c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ac13:	48 8b 58 10          	mov    0x10(%rax),%rbx
    ac17:	48 29 c8             	sub    %rcx,%rax
    ac1a:	48 c1 e2 10          	shl    $0x10,%rdx
    ac1e:	48 39 d0             	cmp    %rdx,%rax
    ac21:	73 67                	jae    ac8a <fwp_hof0.constprop.0+0x150a>
    ac23:	48 89 c7             	mov    %rax,%rdi
    ac26:	48 c1 ef 10          	shr    $0x10,%rdi
    ac2a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    ac2e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ac32:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ac36:	48 85 ff             	test   %rdi,%rdi
    ac39:	74 4f                	je     ac8a <fwp_hof0.constprop.0+0x150a>
    ac3b:	44 0f b6 06          	movzbl (%rsi),%r8d
    ac3f:	41 80 f8 02          	cmp    $0x2,%r8b
    ac43:	0f 84 38 02 00 00    	je     ae81 <fwp_hof0.constprop.0+0x1701>
    ac49:	41 80 f8 01          	cmp    $0x1,%r8b
    ac4d:	75 3b                	jne    ac8a <fwp_hof0.constprop.0+0x150a>
    ac4f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    ac53:	0f b7 c0             	movzwl %ax,%eax
    ac56:	8b 76 1c             	mov    0x1c(%rsi),%esi
    ac59:	49 0f af c0          	imul   %r8,%rax
    ac5d:	48 c1 e8 20          	shr    $0x20,%rax
    ac61:	48 39 f0             	cmp    %rsi,%rax
    ac64:	73 24                	jae    ac8a <fwp_hof0.constprop.0+0x150a>
    ac66:	48 01 c7             	add    %rax,%rdi
    ac69:	80 3f 01             	cmpb   $0x1,(%rdi)
    ac6c:	75 1c                	jne    ac8a <fwp_hof0.constprop.0+0x150a>
    ac6e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    ac73:	e8 f8 ad ff ff       	call   5a70 <fwp_mem_free>
    ac78:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ac7f:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ac86:	48 c1 e2 10          	shl    $0x10,%rdx
    ac8a:	48 89 d8             	mov    %rbx,%rax
    ac8d:	48 29 c8             	sub    %rcx,%rax
    ac90:	48 39 d0             	cmp    %rdx,%rax
    ac93:	0f 83 97 f8 ff ff    	jae    a530 <fwp_hof0.constprop.0+0xdb0>
    ac99:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    ac9e:	e9 1e f8 ff ff       	jmp    a4c1 <fwp_hof0.constprop.0+0xd41>
    aca3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aca8:	66 85 c0             	test   %ax,%ax
    acab:	0f 85 8d fc ff ff    	jne    a93e <fwp_hof0.constprop.0+0x11be>
    acb1:	80 3b ff             	cmpb   $0xff,(%rbx)
    acb4:	0f 85 81 fc ff ff    	jne    a93b <fwp_hof0.constprop.0+0x11bb>
    acba:	48 89 df             	mov    %rbx,%rdi
    acbd:	e8 6e ab ff ff       	call   5830 <fwp_rc_forget_slot>
    acc2:	e9 74 fc ff ff       	jmp    a93b <fwp_hof0.constprop.0+0x11bb>
    acc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acce:	00 00 
    acd0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    acd7:	ff ff 1f 
    acda:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    acde:	48 39 c2             	cmp    %rax,%rdx
    ace1:	0f 82 26 04 00 00    	jb     b10d <fwp_hof0.constprop.0+0x198d>
    ace7:	48 8d 05 f2 84 04 00 	lea    0x484f2(%rip),%rax        # 531e0 <ad_raw_blocks>
    acee:	45 31 ff             	xor    %r15d,%r15d
    acf1:	eb 22                	jmp    ad15 <fwp_hof0.constprop.0+0x1595>
    acf3:	66 90                	xchg   %ax,%ax
    acf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    acfc:	00 00 00 00 
    ad00:	49 83 c7 01          	add    $0x1,%r15
    ad04:	48 83 c0 18          	add    $0x18,%rax
    ad08:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    ad0f:	0f 84 35 02 00 00    	je     af4a <fwp_hof0.constprop.0+0x17ca>
    ad15:	48 83 38 00          	cmpq   $0x0,(%rax)
    ad19:	75 e5                	jne    ad00 <fwp_hof0.constprop.0+0x1580>
    ad1b:	4c 89 c7             	mov    %r8,%rdi
    ad1e:	be 08 00 00 00       	mov    $0x8,%esi
    ad23:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
    ad28:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    ad2d:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    ad32:	e8 d9 87 ff ff       	call   3510 <calloc@plt>
    ad37:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
    ad3c:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    ad42:	48 8d 15 97 84 04 00 	lea    0x48497(%rip),%rdx        # 531e0 <ad_raw_blocks>
    ad49:	48 85 c0             	test   %rax,%rax
    ad4c:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    ad52:	49 89 c2             	mov    %rax,%r10
    ad55:	74 49                	je     ada0 <fwp_hof0.constprop.0+0x1620>
    ad57:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    ad5b:	48 89 c6             	mov    %rax,%rsi
    ad5e:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
    ad63:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    ad67:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    ad6e:	00 
    ad6f:	b9 03 00 00 00       	mov    $0x3,%ecx
    ad74:	e8 87 8e ff ff       	call   3c00 <ad_raw_record>
    ad79:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
    ad7e:	e9 61 fd ff ff       	jmp    aae4 <fwp_hof0.constprop.0+0x1364>
    ad83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad88:	66 85 c0             	test   %ax,%ax
    ad8b:	0f 85 bc ea ff ff    	jne    984d <fwp_hof0.constprop.0+0xcd>
    ad91:	e9 8f ea ff ff       	jmp    9825 <fwp_hof0.constprop.0+0xa5>
    ad96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad9d:	00 00 00 
    ada0:	4d 85 e4             	test   %r12,%r12
    ada3:	0f 85 11 03 00 00    	jne    b0ba <fwp_hof0.constprop.0+0x193a>
    ada9:	45 31 d2             	xor    %r10d,%r10d
    adac:	e9 4c fd ff ff       	jmp    aafd <fwp_hof0.constprop.0+0x137d>
    adb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    adb8:	66 85 c0             	test   %ax,%ax
    adbb:	0f 85 82 f8 ff ff    	jne    a643 <fwp_hof0.constprop.0+0xec3>
    adc1:	41 80 3f ff          	cmpb   $0xff,(%r15)
    adc5:	0f 85 74 f8 ff ff    	jne    a63f <fwp_hof0.constprop.0+0xebf>
    adcb:	4c 89 ff             	mov    %r15,%rdi
    adce:	e8 5d aa ff ff       	call   5830 <fwp_rc_forget_slot>
    add3:	e9 67 f8 ff ff       	jmp    a63f <fwp_hof0.constprop.0+0xebf>
    add8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    addf:	00 
    ade0:	66 85 c0             	test   %ax,%ax
    ade3:	0f 85 17 f9 ff ff    	jne    a700 <fwp_hof0.constprop.0+0xf80>
    ade9:	41 0f b6 04 24       	movzbl (%r12),%eax
    adee:	84 c0                	test   %al,%al
    adf0:	0f 84 0a f9 ff ff    	je     a700 <fwp_hof0.constprop.0+0xf80>
    adf6:	3c 01                	cmp    $0x1,%al
    adf8:	0f 85 e9 f8 ff ff    	jne    a6e7 <fwp_hof0.constprop.0+0xf67>
    adfe:	48 89 df             	mov    %rbx,%rdi
    ae01:	e8 6a ac ff ff       	call   5a70 <fwp_mem_free>
    ae06:	e9 f5 f8 ff ff       	jmp    a700 <fwp_hof0.constprop.0+0xf80>
    ae0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ae0f:	e9 7b eb ff ff       	jmp    998f <fwp_hof0.constprop.0+0x20f>
    ae14:	49 8b 04 24          	mov    (%r12),%rax
    ae18:	48 85 c0             	test   %rax,%rax
    ae1b:	0f 88 f6 fb ff ff    	js     aa17 <fwp_hof0.constprop.0+0x1297>
    ae21:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    ae28:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    ae2d:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    ae34:	48 c1 e6 10          	shl    $0x10,%rsi
    ae38:	48 39 f1             	cmp    %rsi,%rcx
    ae3b:	0f 83 d6 fb ff ff    	jae    aa17 <fwp_hof0.constprop.0+0x1297>
    ae41:	48 89 ce             	mov    %rcx,%rsi
    ae44:	48 c1 ee 10          	shr    $0x10,%rsi
    ae48:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    ae4c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    ae53:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ae57:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ae5b:	48 85 ff             	test   %rdi,%rdi
    ae5e:	0f 84 b3 fb ff ff    	je     aa17 <fwp_hof0.constprop.0+0x1297>
    ae64:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ae69:	49 89 c7             	mov    %rax,%r15
    ae6c:	e9 64 f3 ff ff       	jmp    a1d5 <fwp_hof0.constprop.0+0xa55>
    ae71:	be 68 00 00 00       	mov    $0x68,%esi
    ae76:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ae7c:	e9 99 eb ff ff       	jmp    9a1a <fwp_hof0.constprop.0+0x29a>
    ae81:	66 85 c0             	test   %ax,%ax
    ae84:	0f 85 00 fe ff ff    	jne    ac8a <fwp_hof0.constprop.0+0x150a>
    ae8a:	e9 da fd ff ff       	jmp    ac69 <fwp_hof0.constprop.0+0x14e9>
    ae8f:	4c 89 e2             	mov    %r12,%rdx
    ae92:	48 c1 ea 11          	shr    $0x11,%rdx
    ae96:	4c 31 e2             	xor    %r12,%rdx
    ae99:	48 89 d0             	mov    %rdx,%rax
    ae9c:	48 c1 e8 09          	shr    $0x9,%rax
    aea0:	48 31 c2             	xor    %rax,%rdx
    aea3:	0f b6 d2             	movzbl %dl,%edx
    aea6:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    aead:	00 
    aeae:	48 85 c0             	test   %rax,%rax
    aeb1:	75 16                	jne    aec9 <fwp_hof0.constprop.0+0x1749>
    aeb3:	eb 51                	jmp    af06 <fwp_hof0.constprop.0+0x1786>
    aeb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aebc:	00 00 00 00 
    aec0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aec4:	48 85 c0             	test   %rax,%rax
    aec7:	74 3d                	je     af06 <fwp_hof0.constprop.0+0x1786>
    aec9:	48 89 c2             	mov    %rax,%rdx
    aecc:	4c 39 20             	cmp    %r12,(%rax)
    aecf:	75 ef                	jne    aec0 <fwp_hof0.constprop.0+0x1740>
    aed1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    aed5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    aed9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    aedd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aee4:	0f 85 46 f6 ff ff    	jne    a530 <fwp_hof0.constprop.0+0xdb0>
    aeea:	4c 89 e7             	mov    %r12,%rdi
    aeed:	e8 3e a9 ff ff       	call   5830 <fwp_rc_forget_slot>
    aef2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    aef7:	e9 34 f6 ff ff       	jmp    a530 <fwp_hof0.constprop.0+0xdb0>
    aefc:	e8 0f a8 ff ff       	call   5710 <fwp_rc_wide_dup>
    af01:	e9 4a ea ff ff       	jmp    9950 <fwp_hof0.constprop.0+0x1d0>
    af06:	48 8d 3d e3 4a 00 00 	lea    0x4ae3(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    af0d:	e8 3e 95 ff ff       	call   4450 <fwp_trap>
    af12:	4d 89 f4             	mov    %r14,%r12
    af15:	4c 89 d7             	mov    %r10,%rdi
    af18:	31 f6                	xor    %esi,%esi
    af1a:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    af1f:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    af24:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    af2b:	00 
    af2c:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    af31:	e8 7a 85 ff ff       	call   34b0 <memset@plt>
    af36:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    af3c:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    af42:	49 89 c2             	mov    %rax,%r10
    af45:	e9 ba fb ff ff       	jmp    ab04 <fwp_hof0.constprop.0+0x1384>
    af4a:	48 8d 3d c1 41 00 00 	lea    0x41c1(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    af51:	e8 aa 90 ff ff       	call   4000 <ad_raw_fail>
    af56:	e8 b5 a7 ff ff       	call   5710 <fwp_rc_wide_dup>
    af5b:	e9 ed e8 ff ff       	jmp    984d <fwp_hof0.constprop.0+0xcd>
    af60:	4c 89 e0             	mov    %r12,%rax
    af63:	48 c1 e8 11          	shr    $0x11,%rax
    af67:	4c 31 e0             	xor    %r12,%rax
    af6a:	48 89 c2             	mov    %rax,%rdx
    af6d:	48 c1 ea 09          	shr    $0x9,%rdx
    af71:	48 31 d0             	xor    %rdx,%rax
    af74:	0f b6 d0             	movzbl %al,%edx
    af77:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    af7e:	00 
    af7f:	48 85 c0             	test   %rax,%rax
    af82:	75 29                	jne    afad <fwp_hof0.constprop.0+0x182d>
    af84:	eb 80                	jmp    af06 <fwp_hof0.constprop.0+0x1786>
    af86:	0f 1f 40 00          	nopl   0x0(%rax)
    af8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af91:	00 00 00 00 
    af95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af9c:	00 00 00 00 
    afa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    afa4:	48 85 c0             	test   %rax,%rax
    afa7:	0f 84 59 ff ff ff    	je     af06 <fwp_hof0.constprop.0+0x1786>
    afad:	48 89 c2             	mov    %rax,%rdx
    afb0:	4c 3b 20             	cmp    (%rax),%r12
    afb3:	75 eb                	jne    afa0 <fwp_hof0.constprop.0+0x1820>
    afb5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    afb9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    afbd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    afc1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    afc8:	0f 85 32 f7 ff ff    	jne    a700 <fwp_hof0.constprop.0+0xf80>
    afce:	4c 89 e7             	mov    %r12,%rdi
    afd1:	e8 5a a8 ff ff       	call   5830 <fwp_rc_forget_slot>
    afd6:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    afdb:	e9 20 f7 ff ff       	jmp    a700 <fwp_hof0.constprop.0+0xf80>
    afe0:	45 31 ff             	xor    %r15d,%r15d
    afe3:	e9 6d f3 ff ff       	jmp    a355 <fwp_hof0.constprop.0+0xbd5>
    afe8:	48 8d 3d 29 4a 00 00 	lea    0x4a29(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    afef:	e8 5c 94 ff ff       	call   4450 <fwp_trap>
    aff4:	48 8d 3d c7 41 00 00 	lea    0x41c7(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    affb:	e8 50 94 ff ff       	call   4450 <fwp_trap>
    b000:	48 8d 3d e9 4a 00 00 	lea    0x4ae9(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    b007:	e8 44 94 ff ff       	call   4450 <fwp_trap>
    b00c:	31 db                	xor    %ebx,%ebx
    b00e:	e9 16 fa ff ff       	jmp    aa29 <fwp_hof0.constprop.0+0x12a9>
    b013:	48 8d 3d d1 41 00 00 	lea    0x41d1(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    b01a:	e8 31 94 ff ff       	call   4450 <fwp_trap>
    b01f:	48 8d 3d 56 42 00 00 	lea    0x4256(%rip),%rdi        # f27c <_IO_stdin_used+0x27c>
    b026:	e8 25 94 ff ff       	call   4450 <fwp_trap>
    b02b:	48 8d 3d 80 42 00 00 	lea    0x4280(%rip),%rdi        # f2b2 <_IO_stdin_used+0x2b2>
    b032:	e8 19 94 ff ff       	call   4450 <fwp_trap>
    b037:	48 8d 3d 82 4a 00 00 	lea    0x4a82(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    b03e:	e8 0d 94 ff ff       	call   4450 <fwp_trap>
    b043:	48 8b 0d f6 7f 00 00 	mov    0x7ff6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b04a:	ba 13 00 00 00       	mov    $0x13,%edx
    b04f:	be 01 00 00 00       	mov    $0x1,%esi
    b054:	48 8d 3d ad 3f 00 00 	lea    0x3fad(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b05b:	e8 00 86 ff ff       	call   3660 <fwrite@plt>
    b060:	31 ff                	xor    %edi,%edi
    b062:	e8 39 85 ff ff       	call   35a0 <fflush@plt>
    b067:	bf 66 00 00 00       	mov    $0x66,%edi
    b06c:	e8 0f 86 ff ff       	call   3680 <_Exit@plt>
    b071:	48 8d 3d 4a 42 00 00 	lea    0x424a(%rip),%rdi        # f2c2 <_IO_stdin_used+0x2c2>
    b078:	e8 d3 93 ff ff       	call   4450 <fwp_trap>
    b07d:	0f 1f 00             	nopl   (%rax)
    b080:	48 8d 3d 91 4a 00 00 	lea    0x4a91(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b087:	e8 c4 93 ff ff       	call   4450 <fwp_trap>
    b08c:	48 8b 0d ad 7f 00 00 	mov    0x7fad(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b093:	ba 13 00 00 00       	mov    $0x13,%edx
    b098:	be 01 00 00 00       	mov    $0x1,%esi
    b09d:	48 8d 3d 64 3f 00 00 	lea    0x3f64(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b0a4:	e8 b7 85 ff ff       	call   3660 <fwrite@plt>
    b0a9:	31 ff                	xor    %edi,%edi
    b0ab:	e8 f0 84 ff ff       	call   35a0 <fflush@plt>
    b0b0:	bf 66 00 00 00       	mov    $0x66,%edi
    b0b5:	e8 c6 85 ff ff       	call   3680 <_Exit@plt>
    b0ba:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    b0c1:	00 
    b0c2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    b0c7:	48 89 05 0a 24 06 00 	mov    %rax,0x6240a(%rip)        # 6d4d8 <fwp_cleanups>
    b0ce:	e8 ed a1 ff ff       	call   52c0 <fwp_tape_buffers_release>
    b0d3:	ba 13 00 00 00       	mov    $0x13,%edx
    b0d8:	48 8b 0d 61 7f 00 00 	mov    0x7f61(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b0df:	be 01 00 00 00       	mov    $0x1,%esi
    b0e4:	48 8d 3d 1d 3f 00 00 	lea    0x3f1d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b0eb:	e8 70 85 ff ff       	call   3660 <fwrite@plt>
    b0f0:	31 ff                	xor    %edi,%edi
    b0f2:	e8 a9 84 ff ff       	call   35a0 <fflush@plt>
    b0f7:	bf 66 00 00 00       	mov    $0x66,%edi
    b0fc:	e8 7f 85 ff ff       	call   3680 <_Exit@plt>
    b101:	48 8d 3d 58 49 00 00 	lea    0x4958(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b108:	e8 43 93 ff ff       	call   4450 <fwp_trap>
    b10d:	48 8d 3d 82 41 00 00 	lea    0x4182(%rip),%rdi        # f296 <_IO_stdin_used+0x296>
    b114:	e8 e7 8e ff ff       	call   4000 <ad_raw_fail>
    b119:	e8 32 83 ff ff       	call   3450 <__stack_chk_fail@plt>
    b11e:	66 90                	xchg   %ax,%ax

000000000000b120 <f0>:
    b120:	41 56                	push   %r14
    b122:	4c 8d 35 17 07 06 00 	lea    0x60717(%rip),%r14        # 6b840 <fwp_heap>
    b129:	41 55                	push   %r13
    b12b:	41 54                	push   %r12
    b12d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b133:	55                   	push   %rbp
    b134:	53                   	push   %rbx
    b135:	31 db                	xor    %ebx,%ebx
    b137:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b13e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b145:	00 00 
    b147:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b14e:	00 
    b14f:	31 c0                	xor    %eax,%eax
    b151:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b158:	00 
    b159:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b160:	00 00 
    b162:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b167:	48 8d 05 a2 cc ff ff 	lea    -0x335e(%rip),%rax        # 7e10 <fwp_drop1>
    b16e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b173:	48 8b 05 5e 23 06 00 	mov    0x6235e(%rip),%rax        # 6d4d8 <fwp_cleanups>
    b17a:	48 89 25 57 23 06 00 	mov    %rsp,0x62357(%rip)        # 6d4d8 <fwp_cleanups>
    b181:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b185:	48 89 04 24          	mov    %rax,(%rsp)
    b189:	48 8d 05 40 8a ff ff 	lea    -0x75c0(%rip),%rax        # 3bd0 <fwp_range_release>
    b190:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b195:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b19a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b19f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b1a4:	eb 47                	jmp    b1ed <f0+0xcd>
    b1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b1ad:	00 00 00 
    b1b0:	80 f9 01             	cmp    $0x1,%cl
    b1b3:	75 29                	jne    b1de <f0+0xbe>
    b1b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b1b8:	0f b7 c0             	movzwl %ax,%eax
    b1bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b1be:	48 0f af c1          	imul   %rcx,%rax
    b1c2:	48 c1 e8 20          	shr    $0x20,%rax
    b1c6:	48 39 d0             	cmp    %rdx,%rax
    b1c9:	73 13                	jae    b1de <f0+0xbe>
    b1cb:	49 01 c5             	add    %rax,%r13
    b1ce:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b1d3:	0f 84 c7 27 00 00    	je     d9a0 <f0+0x2880>
    b1d9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b1de:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b1e3:	49 83 ec 01          	sub    $0x1,%r12
    b1e7:	0f 82 83 00 00 00    	jb     b270 <f0+0x150>
    b1ed:	48 89 ee             	mov    %rbp,%rsi
    b1f0:	bf 01 00 00 00       	mov    $0x1,%edi
    b1f5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b1fc:	00 
    b1fd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b202:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b209:	00 
    b20a:	e8 51 af ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b20f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b216:	48 89 c3             	mov    %rax,%rbx
    b219:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b220:	48 c1 e2 10          	shl    $0x10,%rdx
    b224:	48 39 d0             	cmp    %rdx,%rax
    b227:	73 b5                	jae    b1de <f0+0xbe>
    b229:	48 89 c2             	mov    %rax,%rdx
    b22c:	48 c1 ea 10          	shr    $0x10,%rdx
    b230:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b234:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b23b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b23f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b243:	4d 85 ed             	test   %r13,%r13
    b246:	74 96                	je     b1de <f0+0xbe>
    b248:	0f b6 0a             	movzbl (%rdx),%ecx
    b24b:	80 f9 02             	cmp    $0x2,%cl
    b24e:	0f 85 5c ff ff ff    	jne    b1b0 <f0+0x90>
    b254:	66 85 c0             	test   %ax,%ax
    b257:	0f 84 71 ff ff ff    	je     b1ce <f0+0xae>
    b25d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b262:	49 83 ec 01          	sub    $0x1,%r12
    b266:	73 85                	jae    b1ed <f0+0xcd>
    b268:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b26f:	00 
    b270:	48 8b 04 24          	mov    (%rsp),%rax
    b274:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b279:	bf 01 00 00 00       	mov    $0x1,%edi
    b27e:	66 0f 6f 05 9a 4b 00 	movdqa 0x4b9a(%rip),%xmm0        # fe20 <msg.8+0xe0>
    b285:	00 
    b286:	48 89 05 4b 22 06 00 	mov    %rax,0x6224b(%rip)        # 6d4d8 <fwp_cleanups>
    b28d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b292:	e8 c9 ae ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b297:	48 8b 15 7a 19 06 00 	mov    0x6197a(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    b29e:	49 89 c5             	mov    %rax,%r13
    b2a1:	48 2b 05 48 19 06 00 	sub    0x61948(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    b2a8:	48 c1 e2 10          	shl    $0x10,%rdx
    b2ac:	48 39 d0             	cmp    %rdx,%rax
    b2af:	73 59                	jae    b30a <f0+0x1ea>
    b2b1:	48 89 c2             	mov    %rax,%rdx
    b2b4:	48 c1 ea 10          	shr    $0x10,%rdx
    b2b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2bc:	48 8b 15 75 19 06 00 	mov    0x61975(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    b2c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b2cb:	4d 85 e4             	test   %r12,%r12
    b2ce:	74 3a                	je     b30a <f0+0x1ea>
    b2d0:	0f b6 0a             	movzbl (%rdx),%ecx
    b2d3:	80 f9 02             	cmp    $0x2,%cl
    b2d6:	0f 84 74 27 00 00    	je     da50 <f0+0x2930>
    b2dc:	80 f9 01             	cmp    $0x1,%cl
    b2df:	75 29                	jne    b30a <f0+0x1ea>
    b2e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2e4:	0f b7 c0             	movzwl %ax,%eax
    b2e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2ea:	48 0f af c1          	imul   %rcx,%rax
    b2ee:	48 c1 e8 20          	shr    $0x20,%rax
    b2f2:	48 39 d0             	cmp    %rdx,%rax
    b2f5:	73 13                	jae    b30a <f0+0x1ea>
    b2f7:	49 01 c4             	add    %rax,%r12
    b2fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b2ff:	0f 84 26 29 00 00    	je     dc2b <f0+0x2b0b>
    b305:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b30a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b30f:	bf 01 00 00 00       	mov    $0x1,%edi
    b314:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b319:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b320:	00 f0 3f 
    b323:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b328:	e8 33 ae ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b32d:	48 8b 15 e4 18 06 00 	mov    0x618e4(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    b334:	49 89 c5             	mov    %rax,%r13
    b337:	48 2b 05 b2 18 06 00 	sub    0x618b2(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    b33e:	48 c1 e2 10          	shl    $0x10,%rdx
    b342:	48 39 d0             	cmp    %rdx,%rax
    b345:	73 59                	jae    b3a0 <f0+0x280>
    b347:	48 89 c2             	mov    %rax,%rdx
    b34a:	48 c1 ea 10          	shr    $0x10,%rdx
    b34e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b352:	48 8b 15 df 18 06 00 	mov    0x618df(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    b359:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b35d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b361:	4d 85 e4             	test   %r12,%r12
    b364:	74 3a                	je     b3a0 <f0+0x280>
    b366:	0f b6 0a             	movzbl (%rdx),%ecx
    b369:	80 f9 02             	cmp    $0x2,%cl
    b36c:	0f 84 ce 26 00 00    	je     da40 <f0+0x2920>
    b372:	80 f9 01             	cmp    $0x1,%cl
    b375:	75 29                	jne    b3a0 <f0+0x280>
    b377:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b37a:	0f b7 c0             	movzwl %ax,%eax
    b37d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b380:	48 0f af c1          	imul   %rcx,%rax
    b384:	48 c1 e8 20          	shr    $0x20,%rax
    b388:	48 39 d0             	cmp    %rdx,%rax
    b38b:	73 13                	jae    b3a0 <f0+0x280>
    b38d:	49 01 c4             	add    %rax,%r12
    b390:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b395:	0f 84 9d 28 00 00    	je     dc38 <f0+0x2b18>
    b39b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3a0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b3a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b3aa:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b3af:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b3b6:	33 f3 bf 
    b3b9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b3be:	e8 9d ad ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b3c3:	48 8b 15 4e 18 06 00 	mov    0x6184e(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    b3ca:	49 89 c5             	mov    %rax,%r13
    b3cd:	48 2b 05 1c 18 06 00 	sub    0x6181c(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    b3d4:	48 c1 e2 10          	shl    $0x10,%rdx
    b3d8:	48 39 d0             	cmp    %rdx,%rax
    b3db:	73 59                	jae    b436 <f0+0x316>
    b3dd:	48 89 c2             	mov    %rax,%rdx
    b3e0:	48 c1 ea 10          	shr    $0x10,%rdx
    b3e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3e8:	48 8b 15 49 18 06 00 	mov    0x61849(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    b3ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b3f7:	4d 85 e4             	test   %r12,%r12
    b3fa:	74 3a                	je     b436 <f0+0x316>
    b3fc:	0f b6 0a             	movzbl (%rdx),%ecx
    b3ff:	80 f9 02             	cmp    $0x2,%cl
    b402:	0f 84 28 26 00 00    	je     da30 <f0+0x2910>
    b408:	80 f9 01             	cmp    $0x1,%cl
    b40b:	75 29                	jne    b436 <f0+0x316>
    b40d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b410:	0f b7 c0             	movzwl %ax,%eax
    b413:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b416:	48 0f af c1          	imul   %rcx,%rax
    b41a:	48 c1 e8 20          	shr    $0x20,%rax
    b41e:	48 39 d0             	cmp    %rdx,%rax
    b421:	73 13                	jae    b436 <f0+0x316>
    b423:	49 01 c4             	add    %rax,%r12
    b426:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b42b:	0f 84 14 28 00 00    	je     dc45 <f0+0x2b25>
    b431:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b436:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b43b:	bf 01 00 00 00       	mov    $0x1,%edi
    b440:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b445:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b44c:	00 f0 3f 
    b44f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b454:	e8 07 ad ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b459:	48 8b 15 b8 17 06 00 	mov    0x617b8(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    b460:	49 89 c5             	mov    %rax,%r13
    b463:	48 2b 05 86 17 06 00 	sub    0x61786(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    b46a:	48 c1 e2 10          	shl    $0x10,%rdx
    b46e:	48 39 d0             	cmp    %rdx,%rax
    b471:	73 59                	jae    b4cc <f0+0x3ac>
    b473:	48 89 c2             	mov    %rax,%rdx
    b476:	48 c1 ea 10          	shr    $0x10,%rdx
    b47a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b47e:	48 8b 15 b3 17 06 00 	mov    0x617b3(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    b485:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b489:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b48d:	4d 85 e4             	test   %r12,%r12
    b490:	74 3a                	je     b4cc <f0+0x3ac>
    b492:	0f b6 0a             	movzbl (%rdx),%ecx
    b495:	80 f9 02             	cmp    $0x2,%cl
    b498:	0f 84 f2 25 00 00    	je     da90 <f0+0x2970>
    b49e:	80 f9 01             	cmp    $0x1,%cl
    b4a1:	75 29                	jne    b4cc <f0+0x3ac>
    b4a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4a6:	0f b7 c0             	movzwl %ax,%eax
    b4a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4ac:	48 0f af c1          	imul   %rcx,%rax
    b4b0:	48 c1 e8 20          	shr    $0x20,%rax
    b4b4:	48 39 d0             	cmp    %rdx,%rax
    b4b7:	73 13                	jae    b4cc <f0+0x3ac>
    b4b9:	49 01 c4             	add    %rax,%r12
    b4bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4c1:	0f 84 8b 27 00 00    	je     dc52 <f0+0x2b32>
    b4c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b4d3:	33 f3 bf 
    b4d6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b4dd:	00 
    b4de:	bf 01 00 00 00       	mov    $0x1,%edi
    b4e3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b4ea:	00 
    b4eb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b4f2:	00 
    b4f3:	e8 68 ac ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b4f8:	48 8b 15 19 17 06 00 	mov    0x61719(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    b4ff:	49 89 c5             	mov    %rax,%r13
    b502:	48 2b 05 e7 16 06 00 	sub    0x616e7(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    b509:	48 c1 e2 10          	shl    $0x10,%rdx
    b50d:	48 39 d0             	cmp    %rdx,%rax
    b510:	73 59                	jae    b56b <f0+0x44b>
    b512:	48 89 c2             	mov    %rax,%rdx
    b515:	48 c1 ea 10          	shr    $0x10,%rdx
    b519:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b51d:	48 8b 15 14 17 06 00 	mov    0x61714(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    b524:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b528:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b52c:	4d 85 e4             	test   %r12,%r12
    b52f:	74 3a                	je     b56b <f0+0x44b>
    b531:	0f b6 0a             	movzbl (%rdx),%ecx
    b534:	80 f9 02             	cmp    $0x2,%cl
    b537:	0f 84 43 25 00 00    	je     da80 <f0+0x2960>
    b53d:	80 f9 01             	cmp    $0x1,%cl
    b540:	75 29                	jne    b56b <f0+0x44b>
    b542:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b545:	0f b7 c0             	movzwl %ax,%eax
    b548:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b54b:	48 0f af c1          	imul   %rcx,%rax
    b54f:	48 c1 e8 20          	shr    $0x20,%rax
    b553:	48 39 d0             	cmp    %rdx,%rax
    b556:	73 13                	jae    b56b <f0+0x44b>
    b558:	49 01 c4             	add    %rax,%r12
    b55b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b560:	0f 84 f9 26 00 00    	je     dc5f <f0+0x2b3f>
    b566:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b56b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b572:	00 f0 3f 
    b575:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b57c:	00 
    b57d:	bf 01 00 00 00       	mov    $0x1,%edi
    b582:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b589:	00 
    b58a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b591:	00 
    b592:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b599:	33 f3 bf 
    b59c:	e8 bf ab ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b5a1:	48 89 c7             	mov    %rax,%rdi
    b5a4:	e8 c7 b3 ff ff       	call   6970 <fwp_rc_fresh>
    b5a9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b5b0:	00 
    b5b1:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b5bd:	00 
    b5be:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b5c5:	00 
    b5c6:	e8 95 ab ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b5cb:	48 89 c7             	mov    %rax,%rdi
    b5ce:	e8 9d b3 ff ff       	call   6970 <fwp_rc_fresh>
    b5d3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b5da:	00 
    b5db:	bf 01 00 00 00       	mov    $0x1,%edi
    b5e0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b5e7:	00 
    b5e8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b5ef:	00 
    b5f0:	e8 6b ab ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b5f5:	48 89 c7             	mov    %rax,%rdi
    b5f8:	e8 73 b3 ff ff       	call   6970 <fwp_rc_fresh>
    b5fd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b604:	00 
    b605:	bf 01 00 00 00       	mov    $0x1,%edi
    b60a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b611:	00 
    b612:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b619:	00 
    b61a:	e8 41 ab ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b61f:	48 89 c7             	mov    %rax,%rdi
    b622:	e8 49 b3 ff ff       	call   6970 <fwp_rc_fresh>
    b627:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b62e:	00 
    b62f:	bf 01 00 00 00       	mov    $0x1,%edi
    b634:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b63b:	00 
    b63c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b643:	00 
    b644:	e8 17 ab ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b649:	48 89 c7             	mov    %rax,%rdi
    b64c:	e8 1f b3 ff ff       	call   6970 <fwp_rc_fresh>
    b651:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b658:	00 
    b659:	bf 01 00 00 00       	mov    $0x1,%edi
    b65e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b665:	00 
    b666:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b66d:	00 
    b66e:	e8 ed aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b673:	48 89 c7             	mov    %rax,%rdi
    b676:	e8 f5 b2 ff ff       	call   6970 <fwp_rc_fresh>
    b67b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b682:	00 
    b683:	bf 01 00 00 00       	mov    $0x1,%edi
    b688:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b68f:	00 
    b690:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b697:	00 
    b698:	e8 c3 aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b69d:	48 89 c7             	mov    %rax,%rdi
    b6a0:	e8 cb b2 ff ff       	call   6970 <fwp_rc_fresh>
    b6a5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b6ac:	00 
    b6ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b6b2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b6b9:	00 
    b6ba:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b6c1:	00 
    b6c2:	e8 99 aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b6c7:	48 89 c7             	mov    %rax,%rdi
    b6ca:	e8 a1 b2 ff ff       	call   6970 <fwp_rc_fresh>
    b6cf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b6d6:	00 
    b6d7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6dc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b6e3:	00 
    b6e4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b6eb:	00 
    b6ec:	e8 6f aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b6f1:	48 89 c7             	mov    %rax,%rdi
    b6f4:	e8 77 b2 ff ff       	call   6970 <fwp_rc_fresh>
    b6f9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b700:	00 
    b701:	bf 01 00 00 00       	mov    $0x1,%edi
    b706:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b70d:	00 
    b70e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b715:	00 
    b716:	e8 45 aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b71b:	48 89 c7             	mov    %rax,%rdi
    b71e:	e8 4d b2 ff ff       	call   6970 <fwp_rc_fresh>
    b723:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b72a:	00 
    b72b:	bf 01 00 00 00       	mov    $0x1,%edi
    b730:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b737:	00 
    b738:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b73f:	00 
    b740:	e8 1b aa ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b745:	48 89 c7             	mov    %rax,%rdi
    b748:	e8 23 b2 ff ff       	call   6970 <fwp_rc_fresh>
    b74d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b754:	00 
    b755:	bf 01 00 00 00       	mov    $0x1,%edi
    b75a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b761:	00 
    b762:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b769:	00 
    b76a:	e8 f1 a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b76f:	48 89 c7             	mov    %rax,%rdi
    b772:	e8 f9 b1 ff ff       	call   6970 <fwp_rc_fresh>
    b777:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b77e:	00 
    b77f:	bf 01 00 00 00       	mov    $0x1,%edi
    b784:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b78b:	00 
    b78c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b793:	00 
    b794:	e8 c7 a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b799:	48 89 c7             	mov    %rax,%rdi
    b79c:	e8 cf b1 ff ff       	call   6970 <fwp_rc_fresh>
    b7a1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b7a8:	00 
    b7a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ae:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b7b5:	00 
    b7b6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b7bd:	00 
    b7be:	e8 9d a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b7c3:	48 89 c7             	mov    %rax,%rdi
    b7c6:	e8 a5 b1 ff ff       	call   6970 <fwp_rc_fresh>
    b7cb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b7d2:	00 
    b7d3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b7df:	00 
    b7e0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b7e7:	00 
    b7e8:	e8 73 a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b7ed:	48 89 c7             	mov    %rax,%rdi
    b7f0:	e8 7b b1 ff ff       	call   6970 <fwp_rc_fresh>
    b7f5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b7fc:	00 
    b7fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b802:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b809:	00 
    b80a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b811:	00 
    b812:	e8 49 a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b817:	48 89 c7             	mov    %rax,%rdi
    b81a:	e8 51 b1 ff ff       	call   6970 <fwp_rc_fresh>
    b81f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b826:	00 
    b827:	bf 01 00 00 00       	mov    $0x1,%edi
    b82c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b833:	00 
    b834:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b83b:	00 
    b83c:	e8 1f a9 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b841:	48 89 c7             	mov    %rax,%rdi
    b844:	e8 27 b1 ff ff       	call   6970 <fwp_rc_fresh>
    b849:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b850:	00 
    b851:	bf 01 00 00 00       	mov    $0x1,%edi
    b856:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b85d:	00 
    b85e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b865:	00 
    b866:	e8 f5 a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b86b:	48 89 c7             	mov    %rax,%rdi
    b86e:	e8 fd b0 ff ff       	call   6970 <fwp_rc_fresh>
    b873:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b87a:	00 
    b87b:	bf 01 00 00 00       	mov    $0x1,%edi
    b880:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b887:	00 
    b888:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b88f:	00 
    b890:	e8 cb a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b895:	48 89 c7             	mov    %rax,%rdi
    b898:	e8 d3 b0 ff ff       	call   6970 <fwp_rc_fresh>
    b89d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b8a4:	00 
    b8a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b8aa:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b8b1:	00 
    b8b2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b8b9:	00 
    b8ba:	e8 a1 a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b8bf:	48 89 c7             	mov    %rax,%rdi
    b8c2:	e8 a9 b0 ff ff       	call   6970 <fwp_rc_fresh>
    b8c7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b8ce:	00 
    b8cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b8db:	00 
    b8dc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b8e3:	00 
    b8e4:	e8 77 a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b8e9:	48 89 c7             	mov    %rax,%rdi
    b8ec:	e8 7f b0 ff ff       	call   6970 <fwp_rc_fresh>
    b8f1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b8f8:	00 
    b8f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8fe:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b905:	00 
    b906:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b90d:	00 
    b90e:	e8 4d a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b913:	48 89 c7             	mov    %rax,%rdi
    b916:	e8 55 b0 ff ff       	call   6970 <fwp_rc_fresh>
    b91b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b922:	00 
    b923:	bf 01 00 00 00       	mov    $0x1,%edi
    b928:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b92f:	00 
    b930:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b937:	00 
    b938:	e8 23 a8 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b93d:	48 89 c7             	mov    %rax,%rdi
    b940:	e8 2b b0 ff ff       	call   6970 <fwp_rc_fresh>
    b945:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b94c:	00 
    b94d:	bf 01 00 00 00       	mov    $0x1,%edi
    b952:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b959:	00 
    b95a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b961:	00 
    b962:	e8 f9 a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b967:	48 89 c7             	mov    %rax,%rdi
    b96a:	e8 01 b0 ff ff       	call   6970 <fwp_rc_fresh>
    b96f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b976:	00 
    b977:	bf 01 00 00 00       	mov    $0x1,%edi
    b97c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b983:	00 
    b984:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b98b:	00 
    b98c:	e8 cf a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b991:	48 89 c7             	mov    %rax,%rdi
    b994:	e8 d7 af ff ff       	call   6970 <fwp_rc_fresh>
    b999:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b9a0:	00 
    b9a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b9ad:	00 
    b9ae:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b9b5:	00 
    b9b6:	e8 a5 a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b9bb:	48 89 c7             	mov    %rax,%rdi
    b9be:	e8 ad af ff ff       	call   6970 <fwp_rc_fresh>
    b9c3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b9ca:	00 
    b9cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b9d0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b9d7:	00 
    b9d8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b9df:	00 
    b9e0:	e8 7b a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    b9e5:	48 89 c7             	mov    %rax,%rdi
    b9e8:	e8 83 af ff ff       	call   6970 <fwp_rc_fresh>
    b9ed:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b9f4:	00 
    b9f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9fa:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    ba01:	00 
    ba02:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    ba09:	00 
    ba0a:	e8 51 a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ba0f:	48 89 c7             	mov    %rax,%rdi
    ba12:	e8 59 af ff ff       	call   6970 <fwp_rc_fresh>
    ba17:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    ba1e:	00 
    ba1f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba24:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    ba2b:	00 
    ba2c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    ba33:	00 
    ba34:	e8 27 a7 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ba39:	48 89 c7             	mov    %rax,%rdi
    ba3c:	e8 2f af ff ff       	call   6970 <fwp_rc_fresh>
    ba41:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    ba48:	00 
    ba49:	bf 01 00 00 00       	mov    $0x1,%edi
    ba4e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    ba55:	00 
    ba56:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    ba5d:	00 
    ba5e:	e8 fd a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ba63:	48 89 c7             	mov    %rax,%rdi
    ba66:	e8 05 af ff ff       	call   6970 <fwp_rc_fresh>
    ba6b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    ba72:	00 
    ba73:	bf 01 00 00 00       	mov    $0x1,%edi
    ba78:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    ba7f:	00 
    ba80:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    ba87:	00 
    ba88:	e8 d3 a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ba8d:	48 89 c7             	mov    %rax,%rdi
    ba90:	e8 db ae ff ff       	call   6970 <fwp_rc_fresh>
    ba95:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    ba9c:	00 
    ba9d:	bf 01 00 00 00       	mov    $0x1,%edi
    baa2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    baa9:	00 
    baaa:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bab1:	00 
    bab2:	e8 a9 a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bab7:	48 89 c7             	mov    %rax,%rdi
    baba:	e8 b1 ae ff ff       	call   6970 <fwp_rc_fresh>
    babf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bac6:	00 
    bac7:	bf 01 00 00 00       	mov    $0x1,%edi
    bacc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bad3:	00 
    bad4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    badb:	00 
    badc:	e8 7f a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bae1:	48 89 c7             	mov    %rax,%rdi
    bae4:	e8 87 ae ff ff       	call   6970 <fwp_rc_fresh>
    bae9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    baf0:	00 
    baf1:	bf 01 00 00 00       	mov    $0x1,%edi
    baf6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bafd:	00 
    bafe:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bb05:	00 
    bb06:	e8 55 a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bb0b:	48 89 c7             	mov    %rax,%rdi
    bb0e:	e8 5d ae ff ff       	call   6970 <fwp_rc_fresh>
    bb13:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bb1a:	00 
    bb1b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb20:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bb27:	00 
    bb28:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bb2f:	00 
    bb30:	e8 2b a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bb35:	48 89 c7             	mov    %rax,%rdi
    bb38:	e8 33 ae ff ff       	call   6970 <fwp_rc_fresh>
    bb3d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bb44:	00 
    bb45:	bf 01 00 00 00       	mov    $0x1,%edi
    bb4a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bb51:	00 
    bb52:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bb59:	00 
    bb5a:	e8 01 a6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bb5f:	48 89 c7             	mov    %rax,%rdi
    bb62:	e8 09 ae ff ff       	call   6970 <fwp_rc_fresh>
    bb67:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bb6e:	00 
    bb6f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb74:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bb7b:	00 
    bb7c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bb83:	00 
    bb84:	e8 d7 a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bb89:	48 89 c7             	mov    %rax,%rdi
    bb8c:	e8 df ad ff ff       	call   6970 <fwp_rc_fresh>
    bb91:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bb98:	00 
    bb99:	bf 01 00 00 00       	mov    $0x1,%edi
    bb9e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bba5:	00 
    bba6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bbad:	00 
    bbae:	e8 ad a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bbb3:	48 89 c7             	mov    %rax,%rdi
    bbb6:	e8 b5 ad ff ff       	call   6970 <fwp_rc_fresh>
    bbbb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bbc2:	00 
    bbc3:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bbcf:	00 
    bbd0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bbd7:	00 
    bbd8:	e8 83 a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bbdd:	48 89 c7             	mov    %rax,%rdi
    bbe0:	e8 8b ad ff ff       	call   6970 <fwp_rc_fresh>
    bbe5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bbec:	00 
    bbed:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bbf9:	00 
    bbfa:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bc01:	00 
    bc02:	e8 59 a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bc07:	48 89 c7             	mov    %rax,%rdi
    bc0a:	e8 61 ad ff ff       	call   6970 <fwp_rc_fresh>
    bc0f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bc16:	00 
    bc17:	bf 01 00 00 00       	mov    $0x1,%edi
    bc1c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bc23:	00 
    bc24:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bc2b:	00 
    bc2c:	e8 2f a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bc31:	48 89 c7             	mov    %rax,%rdi
    bc34:	e8 37 ad ff ff       	call   6970 <fwp_rc_fresh>
    bc39:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bc40:	00 
    bc41:	bf 01 00 00 00       	mov    $0x1,%edi
    bc46:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bc4d:	00 
    bc4e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bc55:	00 
    bc56:	e8 05 a5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bc5b:	48 89 c7             	mov    %rax,%rdi
    bc5e:	e8 0d ad ff ff       	call   6970 <fwp_rc_fresh>
    bc63:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bc6a:	00 
    bc6b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc70:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bc77:	00 
    bc78:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bc7f:	00 
    bc80:	e8 db a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bc85:	48 89 c7             	mov    %rax,%rdi
    bc88:	e8 e3 ac ff ff       	call   6970 <fwp_rc_fresh>
    bc8d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bc94:	00 
    bc95:	bf 01 00 00 00       	mov    $0x1,%edi
    bc9a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bca1:	00 
    bca2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bca9:	00 
    bcaa:	e8 b1 a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bcaf:	48 89 c7             	mov    %rax,%rdi
    bcb2:	e8 b9 ac ff ff       	call   6970 <fwp_rc_fresh>
    bcb7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bcbe:	00 
    bcbf:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bccb:	00 
    bccc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bcd3:	00 
    bcd4:	e8 87 a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bcd9:	48 89 c7             	mov    %rax,%rdi
    bcdc:	e8 8f ac ff ff       	call   6970 <fwp_rc_fresh>
    bce1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bce8:	00 
    bce9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcee:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bcf5:	00 
    bcf6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bcfd:	00 
    bcfe:	e8 5d a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bd03:	48 89 c7             	mov    %rax,%rdi
    bd06:	e8 65 ac ff ff       	call   6970 <fwp_rc_fresh>
    bd0b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bd12:	00 
    bd13:	bf 01 00 00 00       	mov    $0x1,%edi
    bd18:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bd1f:	00 
    bd20:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bd27:	00 
    bd28:	e8 33 a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bd2d:	48 89 c7             	mov    %rax,%rdi
    bd30:	e8 3b ac ff ff       	call   6970 <fwp_rc_fresh>
    bd35:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bd3c:	00 
    bd3d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd42:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bd49:	00 
    bd4a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bd51:	00 
    bd52:	e8 09 a4 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bd57:	48 89 c7             	mov    %rax,%rdi
    bd5a:	e8 11 ac ff ff       	call   6970 <fwp_rc_fresh>
    bd5f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bd66:	00 
    bd67:	bf 01 00 00 00       	mov    $0x1,%edi
    bd6c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bd73:	00 
    bd74:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bd7b:	00 
    bd7c:	e8 df a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bd81:	48 89 c7             	mov    %rax,%rdi
    bd84:	e8 e7 ab ff ff       	call   6970 <fwp_rc_fresh>
    bd89:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bd90:	00 
    bd91:	bf 01 00 00 00       	mov    $0x1,%edi
    bd96:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bd9d:	00 
    bd9e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bda5:	00 
    bda6:	e8 b5 a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bdab:	48 89 c7             	mov    %rax,%rdi
    bdae:	e8 bd ab ff ff       	call   6970 <fwp_rc_fresh>
    bdb3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bdba:	00 
    bdbb:	bf 01 00 00 00       	mov    $0x1,%edi
    bdc0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bdc7:	00 
    bdc8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bdcf:	00 
    bdd0:	e8 8b a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bdd5:	48 89 c7             	mov    %rax,%rdi
    bdd8:	e8 93 ab ff ff       	call   6970 <fwp_rc_fresh>
    bddd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bde4:	00 
    bde5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdea:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bdf1:	00 
    bdf2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bdf9:	00 
    bdfa:	e8 61 a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bdff:	48 89 c7             	mov    %rax,%rdi
    be02:	e8 69 ab ff ff       	call   6970 <fwp_rc_fresh>
    be07:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    be0e:	00 
    be0f:	bf 01 00 00 00       	mov    $0x1,%edi
    be14:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    be1b:	00 
    be1c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    be23:	00 
    be24:	e8 37 a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    be29:	48 89 c7             	mov    %rax,%rdi
    be2c:	e8 3f ab ff ff       	call   6970 <fwp_rc_fresh>
    be31:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    be38:	00 
    be39:	bf 01 00 00 00       	mov    $0x1,%edi
    be3e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    be45:	00 
    be46:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    be4d:	00 
    be4e:	e8 0d a3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    be53:	48 89 c7             	mov    %rax,%rdi
    be56:	e8 15 ab ff ff       	call   6970 <fwp_rc_fresh>
    be5b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    be62:	00 
    be63:	bf 01 00 00 00       	mov    $0x1,%edi
    be68:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    be6f:	00 
    be70:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    be77:	00 
    be78:	e8 e3 a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    be7d:	48 89 c7             	mov    %rax,%rdi
    be80:	e8 eb aa ff ff       	call   6970 <fwp_rc_fresh>
    be85:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    be8c:	00 
    be8d:	bf 01 00 00 00       	mov    $0x1,%edi
    be92:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    be99:	00 
    be9a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bea1:	00 
    bea2:	e8 b9 a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bea7:	48 89 c7             	mov    %rax,%rdi
    beaa:	e8 c1 aa ff ff       	call   6970 <fwp_rc_fresh>
    beaf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    beb6:	00 
    beb7:	bf 01 00 00 00       	mov    $0x1,%edi
    bebc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bec3:	00 
    bec4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    becb:	00 
    becc:	e8 8f a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bed1:	48 89 c7             	mov    %rax,%rdi
    bed4:	e8 97 aa ff ff       	call   6970 <fwp_rc_fresh>
    bed9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bee0:	00 
    bee1:	bf 01 00 00 00       	mov    $0x1,%edi
    bee6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    beed:	00 
    beee:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bef5:	00 
    bef6:	e8 65 a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    befb:	48 89 c7             	mov    %rax,%rdi
    befe:	e8 6d aa ff ff       	call   6970 <fwp_rc_fresh>
    bf03:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    bf0a:	00 
    bf0b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf10:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    bf17:	00 
    bf18:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    bf1f:	00 
    bf20:	e8 3b a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bf25:	48 89 c7             	mov    %rax,%rdi
    bf28:	e8 43 aa ff ff       	call   6970 <fwp_rc_fresh>
    bf2d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    bf34:	00 
    bf35:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bf41:	00 
    bf42:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bf49:	00 
    bf4a:	e8 11 a2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bf4f:	48 89 c7             	mov    %rax,%rdi
    bf52:	e8 19 aa ff ff       	call   6970 <fwp_rc_fresh>
    bf57:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bf5e:	00 
    bf5f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf64:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    bf6b:	00 
    bf6c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bf73:	00 
    bf74:	e8 e7 a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bf79:	48 89 c7             	mov    %rax,%rdi
    bf7c:	e8 ef a9 ff ff       	call   6970 <fwp_rc_fresh>
    bf81:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bf88:	00 
    bf89:	bf 01 00 00 00       	mov    $0x1,%edi
    bf8e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bf95:	00 
    bf96:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bf9d:	00 
    bf9e:	e8 bd a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bfa3:	48 89 c7             	mov    %rax,%rdi
    bfa6:	e8 c5 a9 ff ff       	call   6970 <fwp_rc_fresh>
    bfab:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bfb2:	00 
    bfb3:	bf 01 00 00 00       	mov    $0x1,%edi
    bfb8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bfbf:	00 
    bfc0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bfc7:	00 
    bfc8:	e8 93 a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bfcd:	48 89 c7             	mov    %rax,%rdi
    bfd0:	e8 9b a9 ff ff       	call   6970 <fwp_rc_fresh>
    bfd5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bfdc:	00 
    bfdd:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bfe9:	00 
    bfea:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bff1:	00 
    bff2:	e8 69 a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    bff7:	48 89 c7             	mov    %rax,%rdi
    bffa:	e8 71 a9 ff ff       	call   6970 <fwp_rc_fresh>
    bfff:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c006:	00 
    c007:	bf 01 00 00 00       	mov    $0x1,%edi
    c00c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c013:	00 
    c014:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c01b:	00 
    c01c:	e8 3f a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c021:	48 89 c7             	mov    %rax,%rdi
    c024:	e8 47 a9 ff ff       	call   6970 <fwp_rc_fresh>
    c029:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c030:	00 
    c031:	bf 01 00 00 00       	mov    $0x1,%edi
    c036:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c03d:	00 
    c03e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c045:	00 
    c046:	e8 15 a1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c04b:	48 89 c7             	mov    %rax,%rdi
    c04e:	e8 1d a9 ff ff       	call   6970 <fwp_rc_fresh>
    c053:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c05a:	00 
    c05b:	bf 01 00 00 00       	mov    $0x1,%edi
    c060:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c067:	00 
    c068:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c06f:	00 
    c070:	e8 eb a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c075:	48 89 c7             	mov    %rax,%rdi
    c078:	e8 f3 a8 ff ff       	call   6970 <fwp_rc_fresh>
    c07d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c084:	00 
    c085:	bf 01 00 00 00       	mov    $0x1,%edi
    c08a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c091:	00 
    c092:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c099:	00 
    c09a:	e8 c1 a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c09f:	48 89 c7             	mov    %rax,%rdi
    c0a2:	e8 c9 a8 ff ff       	call   6970 <fwp_rc_fresh>
    c0a7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c0ae:	00 
    c0af:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c0bb:	00 
    c0bc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c0c3:	00 
    c0c4:	e8 97 a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c0c9:	48 89 c7             	mov    %rax,%rdi
    c0cc:	e8 9f a8 ff ff       	call   6970 <fwp_rc_fresh>
    c0d1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c0d8:	00 
    c0d9:	bf 01 00 00 00       	mov    $0x1,%edi
    c0de:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c0e5:	00 
    c0e6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c0ed:	00 
    c0ee:	e8 6d a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c0f3:	48 89 c7             	mov    %rax,%rdi
    c0f6:	e8 75 a8 ff ff       	call   6970 <fwp_rc_fresh>
    c0fb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c102:	00 
    c103:	bf 01 00 00 00       	mov    $0x1,%edi
    c108:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c10f:	00 
    c110:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c117:	00 
    c118:	e8 43 a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c11d:	48 89 c7             	mov    %rax,%rdi
    c120:	e8 4b a8 ff ff       	call   6970 <fwp_rc_fresh>
    c125:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c12c:	00 
    c12d:	bf 01 00 00 00       	mov    $0x1,%edi
    c132:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c139:	00 
    c13a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c141:	00 
    c142:	e8 19 a0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c147:	48 89 c7             	mov    %rax,%rdi
    c14a:	e8 21 a8 ff ff       	call   6970 <fwp_rc_fresh>
    c14f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c156:	00 
    c157:	bf 01 00 00 00       	mov    $0x1,%edi
    c15c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c163:	00 
    c164:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c16b:	00 
    c16c:	e8 ef 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c171:	48 89 c7             	mov    %rax,%rdi
    c174:	e8 f7 a7 ff ff       	call   6970 <fwp_rc_fresh>
    c179:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c180:	00 
    c181:	bf 01 00 00 00       	mov    $0x1,%edi
    c186:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c18d:	00 
    c18e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c195:	00 
    c196:	e8 c5 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c19b:	48 89 c7             	mov    %rax,%rdi
    c19e:	e8 cd a7 ff ff       	call   6970 <fwp_rc_fresh>
    c1a3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c1aa:	00 
    c1ab:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c1b7:	00 
    c1b8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c1bf:	00 
    c1c0:	e8 9b 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c1c5:	48 89 c7             	mov    %rax,%rdi
    c1c8:	e8 a3 a7 ff ff       	call   6970 <fwp_rc_fresh>
    c1cd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c1d4:	00 
    c1d5:	bf 01 00 00 00       	mov    $0x1,%edi
    c1da:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c1e1:	00 
    c1e2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c1e9:	00 
    c1ea:	e8 71 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c1ef:	48 89 c7             	mov    %rax,%rdi
    c1f2:	e8 79 a7 ff ff       	call   6970 <fwp_rc_fresh>
    c1f7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c1fe:	00 
    c1ff:	bf 01 00 00 00       	mov    $0x1,%edi
    c204:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c20b:	00 
    c20c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c213:	00 
    c214:	e8 47 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c219:	48 89 c7             	mov    %rax,%rdi
    c21c:	e8 4f a7 ff ff       	call   6970 <fwp_rc_fresh>
    c221:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c228:	00 
    c229:	bf 01 00 00 00       	mov    $0x1,%edi
    c22e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c235:	00 
    c236:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c23d:	00 
    c23e:	e8 1d 9f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c243:	48 89 c7             	mov    %rax,%rdi
    c246:	e8 25 a7 ff ff       	call   6970 <fwp_rc_fresh>
    c24b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c252:	00 
    c253:	bf 01 00 00 00       	mov    $0x1,%edi
    c258:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c25f:	00 
    c260:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c267:	00 
    c268:	e8 f3 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c26d:	48 89 c7             	mov    %rax,%rdi
    c270:	e8 fb a6 ff ff       	call   6970 <fwp_rc_fresh>
    c275:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c27c:	00 
    c27d:	bf 01 00 00 00       	mov    $0x1,%edi
    c282:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c289:	00 
    c28a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c291:	00 
    c292:	e8 c9 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c297:	48 89 c7             	mov    %rax,%rdi
    c29a:	e8 d1 a6 ff ff       	call   6970 <fwp_rc_fresh>
    c29f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c2a6:	00 
    c2a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ac:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c2b3:	00 
    c2b4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c2bb:	00 
    c2bc:	e8 9f 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c2c1:	48 89 c7             	mov    %rax,%rdi
    c2c4:	e8 a7 a6 ff ff       	call   6970 <fwp_rc_fresh>
    c2c9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c2d0:	00 
    c2d1:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c2dd:	00 
    c2de:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c2e5:	00 
    c2e6:	e8 75 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c2eb:	48 89 c7             	mov    %rax,%rdi
    c2ee:	e8 7d a6 ff ff       	call   6970 <fwp_rc_fresh>
    c2f3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c2fa:	00 
    c2fb:	bf 01 00 00 00       	mov    $0x1,%edi
    c300:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c307:	00 
    c308:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c30f:	00 
    c310:	e8 4b 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c315:	48 89 c7             	mov    %rax,%rdi
    c318:	e8 53 a6 ff ff       	call   6970 <fwp_rc_fresh>
    c31d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c324:	00 
    c325:	bf 01 00 00 00       	mov    $0x1,%edi
    c32a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c331:	00 
    c332:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c339:	00 
    c33a:	e8 21 9e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c33f:	48 89 c7             	mov    %rax,%rdi
    c342:	e8 29 a6 ff ff       	call   6970 <fwp_rc_fresh>
    c347:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c34e:	00 
    c34f:	bf 01 00 00 00       	mov    $0x1,%edi
    c354:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c35b:	00 
    c35c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c363:	00 
    c364:	e8 f7 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c369:	48 89 c7             	mov    %rax,%rdi
    c36c:	e8 ff a5 ff ff       	call   6970 <fwp_rc_fresh>
    c371:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c378:	00 
    c379:	bf 01 00 00 00       	mov    $0x1,%edi
    c37e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c385:	00 
    c386:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c38d:	00 
    c38e:	e8 cd 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c393:	48 89 c7             	mov    %rax,%rdi
    c396:	e8 d5 a5 ff ff       	call   6970 <fwp_rc_fresh>
    c39b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c3a2:	00 
    c3a3:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c3af:	00 
    c3b0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c3b7:	00 
    c3b8:	e8 a3 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c3bd:	48 89 c7             	mov    %rax,%rdi
    c3c0:	e8 ab a5 ff ff       	call   6970 <fwp_rc_fresh>
    c3c5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c3cc:	00 
    c3cd:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c3d9:	00 
    c3da:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c3e1:	00 
    c3e2:	e8 79 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c3e7:	48 89 c7             	mov    %rax,%rdi
    c3ea:	e8 81 a5 ff ff       	call   6970 <fwp_rc_fresh>
    c3ef:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c3f6:	00 
    c3f7:	bf 01 00 00 00       	mov    $0x1,%edi
    c3fc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c403:	00 
    c404:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c40b:	00 
    c40c:	e8 4f 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c411:	48 89 c7             	mov    %rax,%rdi
    c414:	e8 57 a5 ff ff       	call   6970 <fwp_rc_fresh>
    c419:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c420:	00 
    c421:	bf 01 00 00 00       	mov    $0x1,%edi
    c426:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c42d:	00 
    c42e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c435:	00 
    c436:	e8 25 9d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c43b:	48 89 c7             	mov    %rax,%rdi
    c43e:	e8 2d a5 ff ff       	call   6970 <fwp_rc_fresh>
    c443:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c44a:	00 
    c44b:	bf 01 00 00 00       	mov    $0x1,%edi
    c450:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c457:	00 
    c458:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c45f:	00 
    c460:	e8 fb 9c ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c465:	48 8b 15 ac 07 06 00 	mov    0x607ac(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c46c:	49 89 c5             	mov    %rax,%r13
    c46f:	48 2b 05 7a 07 06 00 	sub    0x6077a(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c476:	48 c1 e2 10          	shl    $0x10,%rdx
    c47a:	48 39 d0             	cmp    %rdx,%rax
    c47d:	73 59                	jae    c4d8 <f0+0x13b8>
    c47f:	48 89 c2             	mov    %rax,%rdx
    c482:	48 c1 ea 10          	shr    $0x10,%rdx
    c486:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c48a:	48 8b 15 a7 07 06 00 	mov    0x607a7(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c491:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c495:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c499:	4d 85 e4             	test   %r12,%r12
    c49c:	74 3a                	je     c4d8 <f0+0x13b8>
    c49e:	0f b6 0a             	movzbl (%rdx),%ecx
    c4a1:	80 f9 02             	cmp    $0x2,%cl
    c4a4:	0f 84 c6 15 00 00    	je     da70 <f0+0x2950>
    c4aa:	80 f9 01             	cmp    $0x1,%cl
    c4ad:	75 29                	jne    c4d8 <f0+0x13b8>
    c4af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4b2:	0f b7 c0             	movzwl %ax,%eax
    c4b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4b8:	48 0f af c1          	imul   %rcx,%rax
    c4bc:	48 c1 e8 20          	shr    $0x20,%rax
    c4c0:	48 39 d0             	cmp    %rdx,%rax
    c4c3:	73 13                	jae    c4d8 <f0+0x13b8>
    c4c5:	49 01 c4             	add    %rax,%r12
    c4c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4cd:	0f 84 99 17 00 00    	je     dc6c <f0+0x2b4c>
    c4d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4d8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c4df:	33 f3 bf 
    c4e2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c4e9:	00 
    c4ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c4ef:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c4f6:	00 
    c4f7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c4fe:	00 
    c4ff:	e8 5c 9c ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c504:	48 8b 15 0d 07 06 00 	mov    0x6070d(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c50b:	49 89 c5             	mov    %rax,%r13
    c50e:	48 2b 05 db 06 06 00 	sub    0x606db(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c515:	48 c1 e2 10          	shl    $0x10,%rdx
    c519:	48 39 d0             	cmp    %rdx,%rax
    c51c:	73 59                	jae    c577 <f0+0x1457>
    c51e:	48 89 c2             	mov    %rax,%rdx
    c521:	48 c1 ea 10          	shr    $0x10,%rdx
    c525:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c529:	48 8b 15 08 07 06 00 	mov    0x60708(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c530:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c534:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c538:	4d 85 e4             	test   %r12,%r12
    c53b:	74 3a                	je     c577 <f0+0x1457>
    c53d:	0f b6 0a             	movzbl (%rdx),%ecx
    c540:	80 f9 02             	cmp    $0x2,%cl
    c543:	0f 84 17 15 00 00    	je     da60 <f0+0x2940>
    c549:	80 f9 01             	cmp    $0x1,%cl
    c54c:	75 29                	jne    c577 <f0+0x1457>
    c54e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c551:	0f b7 c0             	movzwl %ax,%eax
    c554:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c557:	48 0f af c1          	imul   %rcx,%rax
    c55b:	48 c1 e8 20          	shr    $0x20,%rax
    c55f:	48 39 d0             	cmp    %rdx,%rax
    c562:	73 13                	jae    c577 <f0+0x1457>
    c564:	49 01 c4             	add    %rax,%r12
    c567:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c56c:	0f 84 07 17 00 00    	je     dc79 <f0+0x2b59>
    c572:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c577:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c57e:	00 f0 3f 
    c581:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c588:	00 
    c589:	bf 01 00 00 00       	mov    $0x1,%edi
    c58e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c595:	00 
    c596:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c59d:	00 
    c59e:	e8 bd 9b ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c5a3:	48 8b 15 6e 06 06 00 	mov    0x6066e(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c5aa:	49 89 c5             	mov    %rax,%r13
    c5ad:	48 2b 05 3c 06 06 00 	sub    0x6063c(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c5b4:	48 c1 e2 10          	shl    $0x10,%rdx
    c5b8:	48 39 d0             	cmp    %rdx,%rax
    c5bb:	73 59                	jae    c616 <f0+0x14f6>
    c5bd:	48 89 c2             	mov    %rax,%rdx
    c5c0:	48 c1 ea 10          	shr    $0x10,%rdx
    c5c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5c8:	48 8b 15 69 06 06 00 	mov    0x60669(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c5cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5d7:	4d 85 e4             	test   %r12,%r12
    c5da:	74 3a                	je     c616 <f0+0x14f6>
    c5dc:	0f b6 0a             	movzbl (%rdx),%ecx
    c5df:	80 f9 02             	cmp    $0x2,%cl
    c5e2:	0f 84 28 15 00 00    	je     db10 <f0+0x29f0>
    c5e8:	80 f9 01             	cmp    $0x1,%cl
    c5eb:	75 29                	jne    c616 <f0+0x14f6>
    c5ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5f0:	0f b7 c0             	movzwl %ax,%eax
    c5f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5f6:	48 0f af c1          	imul   %rcx,%rax
    c5fa:	48 c1 e8 20          	shr    $0x20,%rax
    c5fe:	48 39 d0             	cmp    %rdx,%rax
    c601:	73 13                	jae    c616 <f0+0x14f6>
    c603:	49 01 c4             	add    %rax,%r12
    c606:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c60b:	0f 84 75 16 00 00    	je     dc86 <f0+0x2b66>
    c611:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c616:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c61d:	33 f3 bf 
    c620:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c627:	00 
    c628:	bf 01 00 00 00       	mov    $0x1,%edi
    c62d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c634:	00 
    c635:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c63c:	00 
    c63d:	e8 1e 9b ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c642:	48 8b 15 cf 05 06 00 	mov    0x605cf(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c649:	49 89 c5             	mov    %rax,%r13
    c64c:	48 2b 05 9d 05 06 00 	sub    0x6059d(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c653:	48 c1 e2 10          	shl    $0x10,%rdx
    c657:	48 39 d0             	cmp    %rdx,%rax
    c65a:	73 59                	jae    c6b5 <f0+0x1595>
    c65c:	48 89 c2             	mov    %rax,%rdx
    c65f:	48 c1 ea 10          	shr    $0x10,%rdx
    c663:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c667:	48 8b 15 ca 05 06 00 	mov    0x605ca(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c66e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c672:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c676:	4d 85 e4             	test   %r12,%r12
    c679:	74 3a                	je     c6b5 <f0+0x1595>
    c67b:	0f b6 0a             	movzbl (%rdx),%ecx
    c67e:	80 f9 02             	cmp    $0x2,%cl
    c681:	0f 84 79 14 00 00    	je     db00 <f0+0x29e0>
    c687:	80 f9 01             	cmp    $0x1,%cl
    c68a:	75 29                	jne    c6b5 <f0+0x1595>
    c68c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c68f:	0f b7 c0             	movzwl %ax,%eax
    c692:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c695:	48 0f af c1          	imul   %rcx,%rax
    c699:	48 c1 e8 20          	shr    $0x20,%rax
    c69d:	48 39 d0             	cmp    %rdx,%rax
    c6a0:	73 13                	jae    c6b5 <f0+0x1595>
    c6a2:	49 01 c4             	add    %rax,%r12
    c6a5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6aa:	0f 84 e3 15 00 00    	je     dc93 <f0+0x2b73>
    c6b0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6b5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c6bc:	00 f0 3f 
    c6bf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c6c6:	00 
    c6c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c6cc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c6d3:	00 
    c6d4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c6db:	00 
    c6dc:	e8 7f 9a ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c6e1:	48 8b 15 30 05 06 00 	mov    0x60530(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c6e8:	49 89 c5             	mov    %rax,%r13
    c6eb:	48 2b 05 fe 04 06 00 	sub    0x604fe(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c6f2:	48 c1 e2 10          	shl    $0x10,%rdx
    c6f6:	48 39 d0             	cmp    %rdx,%rax
    c6f9:	73 59                	jae    c754 <f0+0x1634>
    c6fb:	48 89 c2             	mov    %rax,%rdx
    c6fe:	48 c1 ea 10          	shr    $0x10,%rdx
    c702:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c706:	48 8b 15 2b 05 06 00 	mov    0x6052b(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c70d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c711:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c715:	4d 85 e4             	test   %r12,%r12
    c718:	74 3a                	je     c754 <f0+0x1634>
    c71a:	0f b6 0a             	movzbl (%rdx),%ecx
    c71d:	80 f9 02             	cmp    $0x2,%cl
    c720:	0f 84 ca 13 00 00    	je     daf0 <f0+0x29d0>
    c726:	80 f9 01             	cmp    $0x1,%cl
    c729:	75 29                	jne    c754 <f0+0x1634>
    c72b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c72e:	0f b7 c0             	movzwl %ax,%eax
    c731:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c734:	48 0f af c1          	imul   %rcx,%rax
    c738:	48 c1 e8 20          	shr    $0x20,%rax
    c73c:	48 39 d0             	cmp    %rdx,%rax
    c73f:	73 13                	jae    c754 <f0+0x1634>
    c741:	49 01 c4             	add    %rax,%r12
    c744:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c749:	0f 84 51 15 00 00    	je     dca0 <f0+0x2b80>
    c74f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c754:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c75b:	33 f3 bf 
    c75e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c765:	00 
    c766:	bf 01 00 00 00       	mov    $0x1,%edi
    c76b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c772:	00 
    c773:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c77a:	00 
    c77b:	e8 e0 99 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c780:	48 8b 15 91 04 06 00 	mov    0x60491(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c787:	49 89 c5             	mov    %rax,%r13
    c78a:	48 2b 05 5f 04 06 00 	sub    0x6045f(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c791:	48 c1 e2 10          	shl    $0x10,%rdx
    c795:	48 39 d0             	cmp    %rdx,%rax
    c798:	73 59                	jae    c7f3 <f0+0x16d3>
    c79a:	48 89 c2             	mov    %rax,%rdx
    c79d:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7a5:	48 8b 15 8c 04 06 00 	mov    0x6048c(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c7ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7b4:	4d 85 e4             	test   %r12,%r12
    c7b7:	74 3a                	je     c7f3 <f0+0x16d3>
    c7b9:	0f b6 0a             	movzbl (%rdx),%ecx
    c7bc:	80 f9 02             	cmp    $0x2,%cl
    c7bf:	0f 84 1b 13 00 00    	je     dae0 <f0+0x29c0>
    c7c5:	80 f9 01             	cmp    $0x1,%cl
    c7c8:	75 29                	jne    c7f3 <f0+0x16d3>
    c7ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7cd:	0f b7 c0             	movzwl %ax,%eax
    c7d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d3:	48 0f af c1          	imul   %rcx,%rax
    c7d7:	48 c1 e8 20          	shr    $0x20,%rax
    c7db:	48 39 d0             	cmp    %rdx,%rax
    c7de:	73 13                	jae    c7f3 <f0+0x16d3>
    c7e0:	49 01 c4             	add    %rax,%r12
    c7e3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7e8:	0f 84 bf 14 00 00    	je     dcad <f0+0x2b8d>
    c7ee:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7fa:	00 f0 3f 
    c7fd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c804:	00 
    c805:	bf 01 00 00 00       	mov    $0x1,%edi
    c80a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c811:	00 
    c812:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c819:	00 
    c81a:	e8 41 99 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c81f:	48 8b 15 f2 03 06 00 	mov    0x603f2(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c826:	49 89 c5             	mov    %rax,%r13
    c829:	48 2b 05 c0 03 06 00 	sub    0x603c0(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c830:	48 c1 e2 10          	shl    $0x10,%rdx
    c834:	48 39 d0             	cmp    %rdx,%rax
    c837:	73 59                	jae    c892 <f0+0x1772>
    c839:	48 89 c2             	mov    %rax,%rdx
    c83c:	48 c1 ea 10          	shr    $0x10,%rdx
    c840:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c844:	48 8b 15 ed 03 06 00 	mov    0x603ed(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c84b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c84f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c853:	4d 85 e4             	test   %r12,%r12
    c856:	74 3a                	je     c892 <f0+0x1772>
    c858:	0f b6 0a             	movzbl (%rdx),%ecx
    c85b:	80 f9 02             	cmp    $0x2,%cl
    c85e:	0f 84 6c 12 00 00    	je     dad0 <f0+0x29b0>
    c864:	80 f9 01             	cmp    $0x1,%cl
    c867:	75 29                	jne    c892 <f0+0x1772>
    c869:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c86c:	0f b7 c0             	movzwl %ax,%eax
    c86f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c872:	48 0f af c1          	imul   %rcx,%rax
    c876:	48 c1 e8 20          	shr    $0x20,%rax
    c87a:	48 39 d0             	cmp    %rdx,%rax
    c87d:	73 13                	jae    c892 <f0+0x1772>
    c87f:	49 01 c4             	add    %rax,%r12
    c882:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c887:	0f 84 2d 14 00 00    	je     dcba <f0+0x2b9a>
    c88d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c892:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c899:	33 f3 bf 
    c89c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c8a3:	00 
    c8a4:	bf 01 00 00 00       	mov    $0x1,%edi
    c8a9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c8b0:	00 
    c8b1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c8b8:	00 
    c8b9:	e8 a2 98 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c8be:	48 8b 15 53 03 06 00 	mov    0x60353(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c8c5:	49 89 c5             	mov    %rax,%r13
    c8c8:	48 2b 05 21 03 06 00 	sub    0x60321(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c8cf:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d3:	48 39 d0             	cmp    %rdx,%rax
    c8d6:	73 59                	jae    c931 <f0+0x1811>
    c8d8:	48 89 c2             	mov    %rax,%rdx
    c8db:	48 c1 ea 10          	shr    $0x10,%rdx
    c8df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e3:	48 8b 15 4e 03 06 00 	mov    0x6034e(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c8ea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8ee:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f2:	4d 85 e4             	test   %r12,%r12
    c8f5:	74 3a                	je     c931 <f0+0x1811>
    c8f7:	0f b6 0a             	movzbl (%rdx),%ecx
    c8fa:	80 f9 02             	cmp    $0x2,%cl
    c8fd:	0f 84 bd 11 00 00    	je     dac0 <f0+0x29a0>
    c903:	80 f9 01             	cmp    $0x1,%cl
    c906:	75 29                	jne    c931 <f0+0x1811>
    c908:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c90b:	0f b7 c0             	movzwl %ax,%eax
    c90e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c911:	48 0f af c1          	imul   %rcx,%rax
    c915:	48 c1 e8 20          	shr    $0x20,%rax
    c919:	48 39 d0             	cmp    %rdx,%rax
    c91c:	73 13                	jae    c931 <f0+0x1811>
    c91e:	49 01 c4             	add    %rax,%r12
    c921:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c926:	0f 84 9b 13 00 00    	je     dcc7 <f0+0x2ba7>
    c92c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c931:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c938:	00 f0 3f 
    c93b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c942:	00 
    c943:	bf 01 00 00 00       	mov    $0x1,%edi
    c948:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c94f:	00 
    c950:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c957:	00 
    c958:	e8 03 98 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c95d:	48 8b 15 b4 02 06 00 	mov    0x602b4(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    c964:	49 89 c5             	mov    %rax,%r13
    c967:	48 2b 05 82 02 06 00 	sub    0x60282(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    c96e:	48 c1 e2 10          	shl    $0x10,%rdx
    c972:	48 39 d0             	cmp    %rdx,%rax
    c975:	73 59                	jae    c9d0 <f0+0x18b0>
    c977:	48 89 c2             	mov    %rax,%rdx
    c97a:	48 c1 ea 10          	shr    $0x10,%rdx
    c97e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c982:	48 8b 15 af 02 06 00 	mov    0x602af(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    c989:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c98d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c991:	4d 85 e4             	test   %r12,%r12
    c994:	74 3a                	je     c9d0 <f0+0x18b0>
    c996:	0f b6 0a             	movzbl (%rdx),%ecx
    c999:	80 f9 02             	cmp    $0x2,%cl
    c99c:	0f 84 0e 11 00 00    	je     dab0 <f0+0x2990>
    c9a2:	80 f9 01             	cmp    $0x1,%cl
    c9a5:	75 29                	jne    c9d0 <f0+0x18b0>
    c9a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9aa:	0f b7 c0             	movzwl %ax,%eax
    c9ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b0:	48 0f af c1          	imul   %rcx,%rax
    c9b4:	48 c1 e8 20          	shr    $0x20,%rax
    c9b8:	48 39 d0             	cmp    %rdx,%rax
    c9bb:	73 13                	jae    c9d0 <f0+0x18b0>
    c9bd:	49 01 c4             	add    %rax,%r12
    c9c0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9c5:	0f 84 09 13 00 00    	je     dcd4 <f0+0x2bb4>
    c9cb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9d7:	33 f3 bf 
    c9da:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c9e1:	00 
    c9e2:	bf 01 00 00 00       	mov    $0x1,%edi
    c9e7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c9ee:	00 
    c9ef:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c9f6:	00 
    c9f7:	e8 64 97 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    c9fc:	48 8b 15 15 02 06 00 	mov    0x60215(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    ca03:	49 89 c5             	mov    %rax,%r13
    ca06:	48 2b 05 e3 01 06 00 	sub    0x601e3(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    ca0d:	48 c1 e2 10          	shl    $0x10,%rdx
    ca11:	48 39 d0             	cmp    %rdx,%rax
    ca14:	73 59                	jae    ca6f <f0+0x194f>
    ca16:	48 89 c2             	mov    %rax,%rdx
    ca19:	48 c1 ea 10          	shr    $0x10,%rdx
    ca1d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca21:	48 8b 15 10 02 06 00 	mov    0x60210(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    ca28:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca2c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca30:	4d 85 e4             	test   %r12,%r12
    ca33:	74 3a                	je     ca6f <f0+0x194f>
    ca35:	0f b6 0a             	movzbl (%rdx),%ecx
    ca38:	80 f9 02             	cmp    $0x2,%cl
    ca3b:	0f 84 5f 10 00 00    	je     daa0 <f0+0x2980>
    ca41:	80 f9 01             	cmp    $0x1,%cl
    ca44:	75 29                	jne    ca6f <f0+0x194f>
    ca46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca49:	0f b7 c0             	movzwl %ax,%eax
    ca4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca4f:	48 0f af c1          	imul   %rcx,%rax
    ca53:	48 c1 e8 20          	shr    $0x20,%rax
    ca57:	48 39 d0             	cmp    %rdx,%rax
    ca5a:	73 13                	jae    ca6f <f0+0x194f>
    ca5c:	49 01 c4             	add    %rax,%r12
    ca5f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca64:	0f 84 77 12 00 00    	je     dce1 <f0+0x2bc1>
    ca6a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca6f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca76:	00 f0 3f 
    ca79:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    ca80:	00 
    ca81:	bf 01 00 00 00       	mov    $0x1,%edi
    ca86:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    ca8d:	00 
    ca8e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    ca95:	00 
    ca96:	e8 c5 96 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ca9b:	48 8b 15 76 01 06 00 	mov    0x60176(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    caa2:	49 89 c5             	mov    %rax,%r13
    caa5:	48 2b 05 44 01 06 00 	sub    0x60144(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    caac:	48 c1 e2 10          	shl    $0x10,%rdx
    cab0:	48 39 d0             	cmp    %rdx,%rax
    cab3:	73 59                	jae    cb0e <f0+0x19ee>
    cab5:	48 89 c2             	mov    %rax,%rdx
    cab8:	48 c1 ea 10          	shr    $0x10,%rdx
    cabc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac0:	48 8b 15 71 01 06 00 	mov    0x60171(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cac7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cacb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cacf:	4d 85 e4             	test   %r12,%r12
    cad2:	74 3a                	je     cb0e <f0+0x19ee>
    cad4:	0f b6 0a             	movzbl (%rdx),%ecx
    cad7:	80 f9 02             	cmp    $0x2,%cl
    cada:	0f 84 40 0f 00 00    	je     da20 <f0+0x2900>
    cae0:	80 f9 01             	cmp    $0x1,%cl
    cae3:	75 29                	jne    cb0e <f0+0x19ee>
    cae5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cae8:	0f b7 c0             	movzwl %ax,%eax
    caeb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caee:	48 0f af c1          	imul   %rcx,%rax
    caf2:	48 c1 e8 20          	shr    $0x20,%rax
    caf6:	48 39 d0             	cmp    %rdx,%rax
    caf9:	73 13                	jae    cb0e <f0+0x19ee>
    cafb:	49 01 c4             	add    %rax,%r12
    cafe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb03:	0f 84 e5 11 00 00    	je     dcee <f0+0x2bce>
    cb09:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb0e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb15:	33 f3 bf 
    cb18:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cb1f:	00 
    cb20:	bf 01 00 00 00       	mov    $0x1,%edi
    cb25:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cb2c:	00 
    cb2d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cb34:	00 
    cb35:	e8 26 96 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cb3a:	48 8b 15 d7 00 06 00 	mov    0x600d7(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cb41:	49 89 c5             	mov    %rax,%r13
    cb44:	48 2b 05 a5 00 06 00 	sub    0x600a5(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cb4b:	48 c1 e2 10          	shl    $0x10,%rdx
    cb4f:	48 39 d0             	cmp    %rdx,%rax
    cb52:	73 59                	jae    cbad <f0+0x1a8d>
    cb54:	48 89 c2             	mov    %rax,%rdx
    cb57:	48 c1 ea 10          	shr    $0x10,%rdx
    cb5b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb5f:	48 8b 15 d2 00 06 00 	mov    0x600d2(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cb66:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb6a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb6e:	4d 85 e4             	test   %r12,%r12
    cb71:	74 3a                	je     cbad <f0+0x1a8d>
    cb73:	0f b6 0a             	movzbl (%rdx),%ecx
    cb76:	80 f9 02             	cmp    $0x2,%cl
    cb79:	0f 84 91 0e 00 00    	je     da10 <f0+0x28f0>
    cb7f:	80 f9 01             	cmp    $0x1,%cl
    cb82:	75 29                	jne    cbad <f0+0x1a8d>
    cb84:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb87:	0f b7 c0             	movzwl %ax,%eax
    cb8a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb8d:	48 0f af c1          	imul   %rcx,%rax
    cb91:	48 c1 e8 20          	shr    $0x20,%rax
    cb95:	48 39 d0             	cmp    %rdx,%rax
    cb98:	73 13                	jae    cbad <f0+0x1a8d>
    cb9a:	49 01 c4             	add    %rax,%r12
    cb9d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba2:	0f 84 53 11 00 00    	je     dcfb <f0+0x2bdb>
    cba8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbad:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cbb4:	00 f0 3f 
    cbb7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cbbe:	00 
    cbbf:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cbcb:	00 
    cbcc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cbd3:	00 
    cbd4:	e8 87 95 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cbd9:	48 8b 15 38 00 06 00 	mov    0x60038(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cbe0:	49 89 c5             	mov    %rax,%r13
    cbe3:	48 2b 05 06 00 06 00 	sub    0x60006(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cbea:	48 c1 e2 10          	shl    $0x10,%rdx
    cbee:	48 39 d0             	cmp    %rdx,%rax
    cbf1:	73 59                	jae    cc4c <f0+0x1b2c>
    cbf3:	48 89 c2             	mov    %rax,%rdx
    cbf6:	48 c1 ea 10          	shr    $0x10,%rdx
    cbfa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbfe:	48 8b 15 33 00 06 00 	mov    0x60033(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cc05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc09:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc0d:	4d 85 e4             	test   %r12,%r12
    cc10:	74 3a                	je     cc4c <f0+0x1b2c>
    cc12:	0f b6 0a             	movzbl (%rdx),%ecx
    cc15:	80 f9 02             	cmp    $0x2,%cl
    cc18:	0f 84 e2 0d 00 00    	je     da00 <f0+0x28e0>
    cc1e:	80 f9 01             	cmp    $0x1,%cl
    cc21:	75 29                	jne    cc4c <f0+0x1b2c>
    cc23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc26:	0f b7 c0             	movzwl %ax,%eax
    cc29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc2c:	48 0f af c1          	imul   %rcx,%rax
    cc30:	48 c1 e8 20          	shr    $0x20,%rax
    cc34:	48 39 d0             	cmp    %rdx,%rax
    cc37:	73 13                	jae    cc4c <f0+0x1b2c>
    cc39:	49 01 c4             	add    %rax,%r12
    cc3c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc41:	0f 84 c1 10 00 00    	je     dd08 <f0+0x2be8>
    cc47:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc4c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc53:	33 f3 bf 
    cc56:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cc5d:	00 
    cc5e:	bf 01 00 00 00       	mov    $0x1,%edi
    cc63:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cc6a:	00 
    cc6b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cc72:	00 
    cc73:	e8 e8 94 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cc78:	48 8b 15 99 ff 05 00 	mov    0x5ff99(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cc7f:	49 89 c5             	mov    %rax,%r13
    cc82:	48 2b 05 67 ff 05 00 	sub    0x5ff67(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cc89:	48 c1 e2 10          	shl    $0x10,%rdx
    cc8d:	48 39 d0             	cmp    %rdx,%rax
    cc90:	73 59                	jae    cceb <f0+0x1bcb>
    cc92:	48 89 c2             	mov    %rax,%rdx
    cc95:	48 c1 ea 10          	shr    $0x10,%rdx
    cc99:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc9d:	48 8b 15 94 ff 05 00 	mov    0x5ff94(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cca4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cca8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccac:	4d 85 e4             	test   %r12,%r12
    ccaf:	74 3a                	je     cceb <f0+0x1bcb>
    ccb1:	0f b6 0a             	movzbl (%rdx),%ecx
    ccb4:	80 f9 02             	cmp    $0x2,%cl
    ccb7:	0f 84 33 0d 00 00    	je     d9f0 <f0+0x28d0>
    ccbd:	80 f9 01             	cmp    $0x1,%cl
    ccc0:	75 29                	jne    cceb <f0+0x1bcb>
    ccc2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccc5:	0f b7 c0             	movzwl %ax,%eax
    ccc8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cccb:	48 0f af c1          	imul   %rcx,%rax
    cccf:	48 c1 e8 20          	shr    $0x20,%rax
    ccd3:	48 39 d0             	cmp    %rdx,%rax
    ccd6:	73 13                	jae    cceb <f0+0x1bcb>
    ccd8:	49 01 c4             	add    %rax,%r12
    ccdb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce0:	0f 84 2f 10 00 00    	je     dd15 <f0+0x2bf5>
    cce6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cceb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccf2:	00 f0 3f 
    ccf5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    ccfc:	00 
    ccfd:	bf 01 00 00 00       	mov    $0x1,%edi
    cd02:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cd09:	00 
    cd0a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cd11:	00 
    cd12:	e8 49 94 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cd17:	48 8b 15 fa fe 05 00 	mov    0x5fefa(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cd1e:	49 89 c5             	mov    %rax,%r13
    cd21:	48 2b 05 c8 fe 05 00 	sub    0x5fec8(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cd28:	48 c1 e2 10          	shl    $0x10,%rdx
    cd2c:	48 39 d0             	cmp    %rdx,%rax
    cd2f:	73 59                	jae    cd8a <f0+0x1c6a>
    cd31:	48 89 c2             	mov    %rax,%rdx
    cd34:	48 c1 ea 10          	shr    $0x10,%rdx
    cd38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd3c:	48 8b 15 f5 fe 05 00 	mov    0x5fef5(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cd43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd47:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd4b:	4d 85 e4             	test   %r12,%r12
    cd4e:	74 3a                	je     cd8a <f0+0x1c6a>
    cd50:	0f b6 0a             	movzbl (%rdx),%ecx
    cd53:	80 f9 02             	cmp    $0x2,%cl
    cd56:	0f 84 84 0c 00 00    	je     d9e0 <f0+0x28c0>
    cd5c:	80 f9 01             	cmp    $0x1,%cl
    cd5f:	75 29                	jne    cd8a <f0+0x1c6a>
    cd61:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd64:	0f b7 c0             	movzwl %ax,%eax
    cd67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd6a:	48 0f af c1          	imul   %rcx,%rax
    cd6e:	48 c1 e8 20          	shr    $0x20,%rax
    cd72:	48 39 d0             	cmp    %rdx,%rax
    cd75:	73 13                	jae    cd8a <f0+0x1c6a>
    cd77:	49 01 c4             	add    %rax,%r12
    cd7a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd7f:	0f 84 9d 0f 00 00    	je     dd22 <f0+0x2c02>
    cd85:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd8a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd91:	33 f3 bf 
    cd94:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cd9b:	00 
    cd9c:	bf 01 00 00 00       	mov    $0x1,%edi
    cda1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cda8:	00 
    cda9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cdb0:	00 
    cdb1:	e8 aa 93 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cdb6:	48 8b 15 5b fe 05 00 	mov    0x5fe5b(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cdbd:	49 89 c5             	mov    %rax,%r13
    cdc0:	48 2b 05 29 fe 05 00 	sub    0x5fe29(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cdc7:	48 c1 e2 10          	shl    $0x10,%rdx
    cdcb:	48 39 d0             	cmp    %rdx,%rax
    cdce:	73 59                	jae    ce29 <f0+0x1d09>
    cdd0:	48 89 c2             	mov    %rax,%rdx
    cdd3:	48 c1 ea 10          	shr    $0x10,%rdx
    cdd7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cddb:	48 8b 15 56 fe 05 00 	mov    0x5fe56(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cde2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cde6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdea:	4d 85 e4             	test   %r12,%r12
    cded:	74 3a                	je     ce29 <f0+0x1d09>
    cdef:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf2:	80 f9 02             	cmp    $0x2,%cl
    cdf5:	0f 84 d5 0b 00 00    	je     d9d0 <f0+0x28b0>
    cdfb:	80 f9 01             	cmp    $0x1,%cl
    cdfe:	75 29                	jne    ce29 <f0+0x1d09>
    ce00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce03:	0f b7 c0             	movzwl %ax,%eax
    ce06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce09:	48 0f af c1          	imul   %rcx,%rax
    ce0d:	48 c1 e8 20          	shr    $0x20,%rax
    ce11:	48 39 d0             	cmp    %rdx,%rax
    ce14:	73 13                	jae    ce29 <f0+0x1d09>
    ce16:	49 01 c4             	add    %rax,%r12
    ce19:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce1e:	0f 84 0b 0f 00 00    	je     dd2f <f0+0x2c0f>
    ce24:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce29:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce30:	00 f0 3f 
    ce33:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    ce3a:	00 
    ce3b:	bf 01 00 00 00       	mov    $0x1,%edi
    ce40:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    ce47:	00 
    ce48:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    ce4f:	00 
    ce50:	e8 0b 93 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ce55:	48 8b 15 bc fd 05 00 	mov    0x5fdbc(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    ce5c:	49 89 c5             	mov    %rax,%r13
    ce5f:	48 2b 05 8a fd 05 00 	sub    0x5fd8a(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    ce66:	48 c1 e2 10          	shl    $0x10,%rdx
    ce6a:	48 39 d0             	cmp    %rdx,%rax
    ce6d:	73 59                	jae    cec8 <f0+0x1da8>
    ce6f:	48 89 c2             	mov    %rax,%rdx
    ce72:	48 c1 ea 10          	shr    $0x10,%rdx
    ce76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce7a:	48 8b 15 b7 fd 05 00 	mov    0x5fdb7(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    ce81:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce85:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce89:	4d 85 e4             	test   %r12,%r12
    ce8c:	74 3a                	je     cec8 <f0+0x1da8>
    ce8e:	0f b6 0a             	movzbl (%rdx),%ecx
    ce91:	80 f9 02             	cmp    $0x2,%cl
    ce94:	0f 84 26 0b 00 00    	je     d9c0 <f0+0x28a0>
    ce9a:	80 f9 01             	cmp    $0x1,%cl
    ce9d:	75 29                	jne    cec8 <f0+0x1da8>
    ce9f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea2:	0f b7 c0             	movzwl %ax,%eax
    cea5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cea8:	48 0f af c1          	imul   %rcx,%rax
    ceac:	48 c1 e8 20          	shr    $0x20,%rax
    ceb0:	48 39 d0             	cmp    %rdx,%rax
    ceb3:	73 13                	jae    cec8 <f0+0x1da8>
    ceb5:	49 01 c4             	add    %rax,%r12
    ceb8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cebd:	0f 84 79 0e 00 00    	je     dd3c <f0+0x2c1c>
    cec3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cec8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cecf:	33 f3 bf 
    ced2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ced9:	00 
    ceda:	bf 01 00 00 00       	mov    $0x1,%edi
    cedf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    cee6:	00 
    cee7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    ceee:	00 
    ceef:	e8 6c 92 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cef4:	48 8b 15 1d fd 05 00 	mov    0x5fd1d(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cefb:	49 89 c5             	mov    %rax,%r13
    cefe:	48 2b 05 eb fc 05 00 	sub    0x5fceb(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cf05:	48 c1 e2 10          	shl    $0x10,%rdx
    cf09:	48 39 d0             	cmp    %rdx,%rax
    cf0c:	73 59                	jae    cf67 <f0+0x1e47>
    cf0e:	48 89 c2             	mov    %rax,%rdx
    cf11:	48 c1 ea 10          	shr    $0x10,%rdx
    cf15:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf19:	48 8b 15 18 fd 05 00 	mov    0x5fd18(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cf20:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf24:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf28:	4d 85 e4             	test   %r12,%r12
    cf2b:	74 3a                	je     cf67 <f0+0x1e47>
    cf2d:	0f b6 0a             	movzbl (%rdx),%ecx
    cf30:	80 f9 02             	cmp    $0x2,%cl
    cf33:	0f 84 77 0a 00 00    	je     d9b0 <f0+0x2890>
    cf39:	80 f9 01             	cmp    $0x1,%cl
    cf3c:	75 29                	jne    cf67 <f0+0x1e47>
    cf3e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf41:	0f b7 c0             	movzwl %ax,%eax
    cf44:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf47:	48 0f af c1          	imul   %rcx,%rax
    cf4b:	48 c1 e8 20          	shr    $0x20,%rax
    cf4f:	48 39 d0             	cmp    %rdx,%rax
    cf52:	73 13                	jae    cf67 <f0+0x1e47>
    cf54:	49 01 c4             	add    %rax,%r12
    cf57:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf5c:	0f 84 e7 0d 00 00    	je     dd49 <f0+0x2c29>
    cf62:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf67:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf6e:	00 f0 3f 
    cf71:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cf78:	00 
    cf79:	bf 01 00 00 00       	mov    $0x1,%edi
    cf7e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cf85:	00 
    cf86:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cf8d:	00 
    cf8e:	e8 cd 91 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    cf93:	48 8b 15 7e fc 05 00 	mov    0x5fc7e(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    cf9a:	49 89 c5             	mov    %rax,%r13
    cf9d:	48 2b 05 4c fc 05 00 	sub    0x5fc4c(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    cfa4:	48 c1 e2 10          	shl    $0x10,%rdx
    cfa8:	48 39 d0             	cmp    %rdx,%rax
    cfab:	73 59                	jae    d006 <f0+0x1ee6>
    cfad:	48 89 c2             	mov    %rax,%rdx
    cfb0:	48 c1 ea 10          	shr    $0x10,%rdx
    cfb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfb8:	48 8b 15 79 fc 05 00 	mov    0x5fc79(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    cfbf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfc7:	4d 85 e4             	test   %r12,%r12
    cfca:	74 3a                	je     d006 <f0+0x1ee6>
    cfcc:	0f b6 0a             	movzbl (%rdx),%ecx
    cfcf:	80 f9 02             	cmp    $0x2,%cl
    cfd2:	0f 84 38 0c 00 00    	je     dc10 <f0+0x2af0>
    cfd8:	80 f9 01             	cmp    $0x1,%cl
    cfdb:	75 29                	jne    d006 <f0+0x1ee6>
    cfdd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe0:	0f b7 c0             	movzwl %ax,%eax
    cfe3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfe6:	48 0f af c1          	imul   %rcx,%rax
    cfea:	48 c1 e8 20          	shr    $0x20,%rax
    cfee:	48 39 d0             	cmp    %rdx,%rax
    cff1:	73 13                	jae    d006 <f0+0x1ee6>
    cff3:	49 01 c4             	add    %rax,%r12
    cff6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cffb:	0f 84 55 0d 00 00    	je     dd56 <f0+0x2c36>
    d001:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d006:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d00d:	33 f3 bf 
    d010:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d017:	00 
    d018:	bf 01 00 00 00       	mov    $0x1,%edi
    d01d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d024:	00 
    d025:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d02c:	00 
    d02d:	e8 2e 91 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d032:	48 8b 15 df fb 05 00 	mov    0x5fbdf(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d039:	49 89 c5             	mov    %rax,%r13
    d03c:	48 2b 05 ad fb 05 00 	sub    0x5fbad(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d043:	48 c1 e2 10          	shl    $0x10,%rdx
    d047:	48 39 d0             	cmp    %rdx,%rax
    d04a:	73 59                	jae    d0a5 <f0+0x1f85>
    d04c:	48 89 c2             	mov    %rax,%rdx
    d04f:	48 c1 ea 10          	shr    $0x10,%rdx
    d053:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d057:	48 8b 15 da fb 05 00 	mov    0x5fbda(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d05e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d062:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d066:	4d 85 e4             	test   %r12,%r12
    d069:	74 3a                	je     d0a5 <f0+0x1f85>
    d06b:	0f b6 0a             	movzbl (%rdx),%ecx
    d06e:	80 f9 02             	cmp    $0x2,%cl
    d071:	0f 84 89 0b 00 00    	je     dc00 <f0+0x2ae0>
    d077:	80 f9 01             	cmp    $0x1,%cl
    d07a:	75 29                	jne    d0a5 <f0+0x1f85>
    d07c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d07f:	0f b7 c0             	movzwl %ax,%eax
    d082:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d085:	48 0f af c1          	imul   %rcx,%rax
    d089:	48 c1 e8 20          	shr    $0x20,%rax
    d08d:	48 39 d0             	cmp    %rdx,%rax
    d090:	73 13                	jae    d0a5 <f0+0x1f85>
    d092:	49 01 c4             	add    %rax,%r12
    d095:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d09a:	0f 84 c3 0c 00 00    	je     dd63 <f0+0x2c43>
    d0a0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0a5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0ac:	00 f0 3f 
    d0af:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d0b6:	00 
    d0b7:	bf 01 00 00 00       	mov    $0x1,%edi
    d0bc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d0c3:	00 
    d0c4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d0cb:	00 
    d0cc:	e8 8f 90 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d0d1:	48 8b 15 40 fb 05 00 	mov    0x5fb40(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d0d8:	49 89 c5             	mov    %rax,%r13
    d0db:	48 2b 05 0e fb 05 00 	sub    0x5fb0e(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d0e2:	48 c1 e2 10          	shl    $0x10,%rdx
    d0e6:	48 39 d0             	cmp    %rdx,%rax
    d0e9:	73 59                	jae    d144 <f0+0x2024>
    d0eb:	48 89 c2             	mov    %rax,%rdx
    d0ee:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0f6:	48 8b 15 3b fb 05 00 	mov    0x5fb3b(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d0fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d101:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d105:	4d 85 e4             	test   %r12,%r12
    d108:	74 3a                	je     d144 <f0+0x2024>
    d10a:	0f b6 0a             	movzbl (%rdx),%ecx
    d10d:	80 f9 02             	cmp    $0x2,%cl
    d110:	0f 84 da 0a 00 00    	je     dbf0 <f0+0x2ad0>
    d116:	80 f9 01             	cmp    $0x1,%cl
    d119:	75 29                	jne    d144 <f0+0x2024>
    d11b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d11e:	0f b7 c0             	movzwl %ax,%eax
    d121:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d124:	48 0f af c1          	imul   %rcx,%rax
    d128:	48 c1 e8 20          	shr    $0x20,%rax
    d12c:	48 39 d0             	cmp    %rdx,%rax
    d12f:	73 13                	jae    d144 <f0+0x2024>
    d131:	49 01 c4             	add    %rax,%r12
    d134:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d139:	0f 84 31 0c 00 00    	je     dd70 <f0+0x2c50>
    d13f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d144:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d14b:	33 f3 bf 
    d14e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d155:	00 
    d156:	bf 01 00 00 00       	mov    $0x1,%edi
    d15b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d162:	00 
    d163:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d16a:	00 
    d16b:	e8 f0 8f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d170:	48 8b 15 a1 fa 05 00 	mov    0x5faa1(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d177:	49 89 c5             	mov    %rax,%r13
    d17a:	48 2b 05 6f fa 05 00 	sub    0x5fa6f(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d181:	48 c1 e2 10          	shl    $0x10,%rdx
    d185:	48 39 d0             	cmp    %rdx,%rax
    d188:	73 59                	jae    d1e3 <f0+0x20c3>
    d18a:	48 89 c2             	mov    %rax,%rdx
    d18d:	48 c1 ea 10          	shr    $0x10,%rdx
    d191:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d195:	48 8b 15 9c fa 05 00 	mov    0x5fa9c(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d19c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1a4:	4d 85 e4             	test   %r12,%r12
    d1a7:	74 3a                	je     d1e3 <f0+0x20c3>
    d1a9:	0f b6 0a             	movzbl (%rdx),%ecx
    d1ac:	80 f9 02             	cmp    $0x2,%cl
    d1af:	0f 84 2b 0a 00 00    	je     dbe0 <f0+0x2ac0>
    d1b5:	80 f9 01             	cmp    $0x1,%cl
    d1b8:	75 29                	jne    d1e3 <f0+0x20c3>
    d1ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1bd:	0f b7 c0             	movzwl %ax,%eax
    d1c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c3:	48 0f af c1          	imul   %rcx,%rax
    d1c7:	48 c1 e8 20          	shr    $0x20,%rax
    d1cb:	48 39 d0             	cmp    %rdx,%rax
    d1ce:	73 13                	jae    d1e3 <f0+0x20c3>
    d1d0:	49 01 c4             	add    %rax,%r12
    d1d3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1d8:	0f 84 9f 0b 00 00    	je     dd7d <f0+0x2c5d>
    d1de:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1ea:	00 f0 3f 
    d1ed:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d1f4:	00 
    d1f5:	bf 01 00 00 00       	mov    $0x1,%edi
    d1fa:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d201:	00 
    d202:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d209:	00 
    d20a:	e8 51 8f ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d20f:	48 8b 15 02 fa 05 00 	mov    0x5fa02(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d216:	49 89 c5             	mov    %rax,%r13
    d219:	48 2b 05 d0 f9 05 00 	sub    0x5f9d0(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d220:	48 c1 e2 10          	shl    $0x10,%rdx
    d224:	48 39 d0             	cmp    %rdx,%rax
    d227:	73 59                	jae    d282 <f0+0x2162>
    d229:	48 89 c2             	mov    %rax,%rdx
    d22c:	48 c1 ea 10          	shr    $0x10,%rdx
    d230:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d234:	48 8b 15 fd f9 05 00 	mov    0x5f9fd(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d23b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d23f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d243:	4d 85 e4             	test   %r12,%r12
    d246:	74 3a                	je     d282 <f0+0x2162>
    d248:	0f b6 0a             	movzbl (%rdx),%ecx
    d24b:	80 f9 02             	cmp    $0x2,%cl
    d24e:	0f 84 7c 09 00 00    	je     dbd0 <f0+0x2ab0>
    d254:	80 f9 01             	cmp    $0x1,%cl
    d257:	75 29                	jne    d282 <f0+0x2162>
    d259:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d25c:	0f b7 c0             	movzwl %ax,%eax
    d25f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d262:	48 0f af c1          	imul   %rcx,%rax
    d266:	48 c1 e8 20          	shr    $0x20,%rax
    d26a:	48 39 d0             	cmp    %rdx,%rax
    d26d:	73 13                	jae    d282 <f0+0x2162>
    d26f:	49 01 c4             	add    %rax,%r12
    d272:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d277:	0f 84 0d 0b 00 00    	je     dd8a <f0+0x2c6a>
    d27d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d282:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d289:	33 f3 bf 
    d28c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d293:	00 
    d294:	bf 01 00 00 00       	mov    $0x1,%edi
    d299:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d2a0:	00 
    d2a1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d2a8:	00 
    d2a9:	e8 b2 8e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d2ae:	48 8b 15 63 f9 05 00 	mov    0x5f963(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d2b5:	49 89 c5             	mov    %rax,%r13
    d2b8:	48 2b 05 31 f9 05 00 	sub    0x5f931(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d2bf:	48 c1 e2 10          	shl    $0x10,%rdx
    d2c3:	48 39 d0             	cmp    %rdx,%rax
    d2c6:	73 59                	jae    d321 <f0+0x2201>
    d2c8:	48 89 c2             	mov    %rax,%rdx
    d2cb:	48 c1 ea 10          	shr    $0x10,%rdx
    d2cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2d3:	48 8b 15 5e f9 05 00 	mov    0x5f95e(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d2da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2de:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2e2:	4d 85 e4             	test   %r12,%r12
    d2e5:	74 3a                	je     d321 <f0+0x2201>
    d2e7:	0f b6 0a             	movzbl (%rdx),%ecx
    d2ea:	80 f9 02             	cmp    $0x2,%cl
    d2ed:	0f 84 cd 08 00 00    	je     dbc0 <f0+0x2aa0>
    d2f3:	80 f9 01             	cmp    $0x1,%cl
    d2f6:	75 29                	jne    d321 <f0+0x2201>
    d2f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2fb:	0f b7 c0             	movzwl %ax,%eax
    d2fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d301:	48 0f af c1          	imul   %rcx,%rax
    d305:	48 c1 e8 20          	shr    $0x20,%rax
    d309:	48 39 d0             	cmp    %rdx,%rax
    d30c:	73 13                	jae    d321 <f0+0x2201>
    d30e:	49 01 c4             	add    %rax,%r12
    d311:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d316:	0f 84 7b 0a 00 00    	je     dd97 <f0+0x2c77>
    d31c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d321:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d328:	00 f0 3f 
    d32b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d332:	00 
    d333:	bf 01 00 00 00       	mov    $0x1,%edi
    d338:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d33f:	00 
    d340:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d347:	00 
    d348:	e8 13 8e ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d34d:	48 8b 15 c4 f8 05 00 	mov    0x5f8c4(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d354:	49 89 c5             	mov    %rax,%r13
    d357:	48 2b 05 92 f8 05 00 	sub    0x5f892(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d35e:	48 c1 e2 10          	shl    $0x10,%rdx
    d362:	48 39 d0             	cmp    %rdx,%rax
    d365:	73 59                	jae    d3c0 <f0+0x22a0>
    d367:	48 89 c2             	mov    %rax,%rdx
    d36a:	48 c1 ea 10          	shr    $0x10,%rdx
    d36e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d372:	48 8b 15 bf f8 05 00 	mov    0x5f8bf(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d379:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d37d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d381:	4d 85 e4             	test   %r12,%r12
    d384:	74 3a                	je     d3c0 <f0+0x22a0>
    d386:	0f b6 0a             	movzbl (%rdx),%ecx
    d389:	80 f9 02             	cmp    $0x2,%cl
    d38c:	0f 84 1e 08 00 00    	je     dbb0 <f0+0x2a90>
    d392:	80 f9 01             	cmp    $0x1,%cl
    d395:	75 29                	jne    d3c0 <f0+0x22a0>
    d397:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d39a:	0f b7 c0             	movzwl %ax,%eax
    d39d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3a0:	48 0f af c1          	imul   %rcx,%rax
    d3a4:	48 c1 e8 20          	shr    $0x20,%rax
    d3a8:	48 39 d0             	cmp    %rdx,%rax
    d3ab:	73 13                	jae    d3c0 <f0+0x22a0>
    d3ad:	49 01 c4             	add    %rax,%r12
    d3b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3b5:	0f 84 e9 09 00 00    	je     dda4 <f0+0x2c84>
    d3bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d3c7:	33 f3 bf 
    d3ca:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d3d1:	00 
    d3d2:	bf 01 00 00 00       	mov    $0x1,%edi
    d3d7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d3de:	00 
    d3df:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d3e6:	00 
    d3e7:	e8 74 8d ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d3ec:	48 8b 15 25 f8 05 00 	mov    0x5f825(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d3f3:	49 89 c5             	mov    %rax,%r13
    d3f6:	48 2b 05 f3 f7 05 00 	sub    0x5f7f3(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d3fd:	48 c1 e2 10          	shl    $0x10,%rdx
    d401:	48 39 d0             	cmp    %rdx,%rax
    d404:	73 59                	jae    d45f <f0+0x233f>
    d406:	48 89 c2             	mov    %rax,%rdx
    d409:	48 c1 ea 10          	shr    $0x10,%rdx
    d40d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d411:	48 8b 15 20 f8 05 00 	mov    0x5f820(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d418:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d41c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d420:	4d 85 e4             	test   %r12,%r12
    d423:	74 3a                	je     d45f <f0+0x233f>
    d425:	0f b6 0a             	movzbl (%rdx),%ecx
    d428:	80 f9 02             	cmp    $0x2,%cl
    d42b:	0f 84 6f 07 00 00    	je     dba0 <f0+0x2a80>
    d431:	80 f9 01             	cmp    $0x1,%cl
    d434:	75 29                	jne    d45f <f0+0x233f>
    d436:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d439:	0f b7 c0             	movzwl %ax,%eax
    d43c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d43f:	48 0f af c1          	imul   %rcx,%rax
    d443:	48 c1 e8 20          	shr    $0x20,%rax
    d447:	48 39 d0             	cmp    %rdx,%rax
    d44a:	73 13                	jae    d45f <f0+0x233f>
    d44c:	49 01 c4             	add    %rax,%r12
    d44f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d454:	0f 84 57 09 00 00    	je     ddb1 <f0+0x2c91>
    d45a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d45f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d466:	00 f0 3f 
    d469:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d470:	00 
    d471:	bf 01 00 00 00       	mov    $0x1,%edi
    d476:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d47d:	00 
    d47e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d485:	00 
    d486:	e8 d5 8c ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d48b:	48 8b 15 86 f7 05 00 	mov    0x5f786(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d492:	49 89 c5             	mov    %rax,%r13
    d495:	48 2b 05 54 f7 05 00 	sub    0x5f754(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d49c:	48 c1 e2 10          	shl    $0x10,%rdx
    d4a0:	48 39 d0             	cmp    %rdx,%rax
    d4a3:	73 59                	jae    d4fe <f0+0x23de>
    d4a5:	48 89 c2             	mov    %rax,%rdx
    d4a8:	48 c1 ea 10          	shr    $0x10,%rdx
    d4ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4b0:	48 8b 15 81 f7 05 00 	mov    0x5f781(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d4b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4bf:	4d 85 e4             	test   %r12,%r12
    d4c2:	74 3a                	je     d4fe <f0+0x23de>
    d4c4:	0f b6 0a             	movzbl (%rdx),%ecx
    d4c7:	80 f9 02             	cmp    $0x2,%cl
    d4ca:	0f 84 c0 06 00 00    	je     db90 <f0+0x2a70>
    d4d0:	80 f9 01             	cmp    $0x1,%cl
    d4d3:	75 29                	jne    d4fe <f0+0x23de>
    d4d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4d8:	0f b7 c0             	movzwl %ax,%eax
    d4db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4de:	48 0f af c1          	imul   %rcx,%rax
    d4e2:	48 c1 e8 20          	shr    $0x20,%rax
    d4e6:	48 39 d0             	cmp    %rdx,%rax
    d4e9:	73 13                	jae    d4fe <f0+0x23de>
    d4eb:	49 01 c4             	add    %rax,%r12
    d4ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4f3:	0f 84 c5 08 00 00    	je     ddbe <f0+0x2c9e>
    d4f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4fe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d505:	33 f3 bf 
    d508:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d50f:	00 
    d510:	bf 01 00 00 00       	mov    $0x1,%edi
    d515:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d51c:	00 
    d51d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d524:	00 
    d525:	e8 36 8c ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d52a:	48 8b 15 e7 f6 05 00 	mov    0x5f6e7(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d531:	49 89 c5             	mov    %rax,%r13
    d534:	48 2b 05 b5 f6 05 00 	sub    0x5f6b5(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d53b:	48 c1 e2 10          	shl    $0x10,%rdx
    d53f:	48 39 d0             	cmp    %rdx,%rax
    d542:	73 59                	jae    d59d <f0+0x247d>
    d544:	48 89 c2             	mov    %rax,%rdx
    d547:	48 c1 ea 10          	shr    $0x10,%rdx
    d54b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d54f:	48 8b 15 e2 f6 05 00 	mov    0x5f6e2(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d556:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d55a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d55e:	4d 85 e4             	test   %r12,%r12
    d561:	74 3a                	je     d59d <f0+0x247d>
    d563:	0f b6 0a             	movzbl (%rdx),%ecx
    d566:	80 f9 02             	cmp    $0x2,%cl
    d569:	0f 84 11 06 00 00    	je     db80 <f0+0x2a60>
    d56f:	80 f9 01             	cmp    $0x1,%cl
    d572:	75 29                	jne    d59d <f0+0x247d>
    d574:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d577:	0f b7 c0             	movzwl %ax,%eax
    d57a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d57d:	48 0f af c1          	imul   %rcx,%rax
    d581:	48 c1 e8 20          	shr    $0x20,%rax
    d585:	48 39 d0             	cmp    %rdx,%rax
    d588:	73 13                	jae    d59d <f0+0x247d>
    d58a:	49 01 c4             	add    %rax,%r12
    d58d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d592:	0f 84 33 08 00 00    	je     ddcb <f0+0x2cab>
    d598:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d59d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5a4:	00 f0 3f 
    d5a7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d5ae:	00 
    d5af:	bf 01 00 00 00       	mov    $0x1,%edi
    d5b4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d5bb:	00 
    d5bc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d5c3:	00 
    d5c4:	e8 97 8b ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d5c9:	48 8b 15 48 f6 05 00 	mov    0x5f648(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d5d0:	49 89 c5             	mov    %rax,%r13
    d5d3:	48 2b 05 16 f6 05 00 	sub    0x5f616(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d5da:	48 c1 e2 10          	shl    $0x10,%rdx
    d5de:	48 39 d0             	cmp    %rdx,%rax
    d5e1:	73 59                	jae    d63c <f0+0x251c>
    d5e3:	48 89 c2             	mov    %rax,%rdx
    d5e6:	48 c1 ea 10          	shr    $0x10,%rdx
    d5ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5ee:	48 8b 15 43 f6 05 00 	mov    0x5f643(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d5f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5fd:	4d 85 e4             	test   %r12,%r12
    d600:	74 3a                	je     d63c <f0+0x251c>
    d602:	0f b6 0a             	movzbl (%rdx),%ecx
    d605:	80 f9 02             	cmp    $0x2,%cl
    d608:	0f 84 62 05 00 00    	je     db70 <f0+0x2a50>
    d60e:	80 f9 01             	cmp    $0x1,%cl
    d611:	75 29                	jne    d63c <f0+0x251c>
    d613:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d616:	0f b7 c0             	movzwl %ax,%eax
    d619:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d61c:	48 0f af c1          	imul   %rcx,%rax
    d620:	48 c1 e8 20          	shr    $0x20,%rax
    d624:	48 39 d0             	cmp    %rdx,%rax
    d627:	73 13                	jae    d63c <f0+0x251c>
    d629:	49 01 c4             	add    %rax,%r12
    d62c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d631:	0f 84 a1 07 00 00    	je     ddd8 <f0+0x2cb8>
    d637:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d63c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d643:	33 f3 bf 
    d646:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d64d:	00 
    d64e:	bf 01 00 00 00       	mov    $0x1,%edi
    d653:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d65a:	00 
    d65b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d662:	00 
    d663:	e8 f8 8a ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d668:	48 8b 15 a9 f5 05 00 	mov    0x5f5a9(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d66f:	49 89 c5             	mov    %rax,%r13
    d672:	48 2b 05 77 f5 05 00 	sub    0x5f577(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d679:	48 c1 e2 10          	shl    $0x10,%rdx
    d67d:	48 39 d0             	cmp    %rdx,%rax
    d680:	73 59                	jae    d6db <f0+0x25bb>
    d682:	48 89 c2             	mov    %rax,%rdx
    d685:	48 c1 ea 10          	shr    $0x10,%rdx
    d689:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d68d:	48 8b 15 a4 f5 05 00 	mov    0x5f5a4(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d694:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d698:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d69c:	4d 85 e4             	test   %r12,%r12
    d69f:	74 3a                	je     d6db <f0+0x25bb>
    d6a1:	0f b6 0a             	movzbl (%rdx),%ecx
    d6a4:	80 f9 02             	cmp    $0x2,%cl
    d6a7:	0f 84 b3 04 00 00    	je     db60 <f0+0x2a40>
    d6ad:	80 f9 01             	cmp    $0x1,%cl
    d6b0:	75 29                	jne    d6db <f0+0x25bb>
    d6b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6b5:	0f b7 c0             	movzwl %ax,%eax
    d6b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6bb:	48 0f af c1          	imul   %rcx,%rax
    d6bf:	48 c1 e8 20          	shr    $0x20,%rax
    d6c3:	48 39 d0             	cmp    %rdx,%rax
    d6c6:	73 13                	jae    d6db <f0+0x25bb>
    d6c8:	49 01 c4             	add    %rax,%r12
    d6cb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6d0:	0f 84 0f 07 00 00    	je     dde5 <f0+0x2cc5>
    d6d6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6db:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d6e2:	00 f0 3f 
    d6e5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d6ec:	00 
    d6ed:	bf 01 00 00 00       	mov    $0x1,%edi
    d6f2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d6f9:	00 
    d6fa:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d701:	00 
    d702:	e8 59 8a ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d707:	48 8b 15 0a f5 05 00 	mov    0x5f50a(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d70e:	49 89 c5             	mov    %rax,%r13
    d711:	48 2b 05 d8 f4 05 00 	sub    0x5f4d8(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d718:	48 c1 e2 10          	shl    $0x10,%rdx
    d71c:	48 39 d0             	cmp    %rdx,%rax
    d71f:	73 59                	jae    d77a <f0+0x265a>
    d721:	48 89 c2             	mov    %rax,%rdx
    d724:	48 c1 ea 10          	shr    $0x10,%rdx
    d728:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d72c:	48 8b 15 05 f5 05 00 	mov    0x5f505(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d733:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d737:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d73b:	4d 85 e4             	test   %r12,%r12
    d73e:	74 3a                	je     d77a <f0+0x265a>
    d740:	0f b6 0a             	movzbl (%rdx),%ecx
    d743:	80 f9 02             	cmp    $0x2,%cl
    d746:	0f 84 04 04 00 00    	je     db50 <f0+0x2a30>
    d74c:	80 f9 01             	cmp    $0x1,%cl
    d74f:	75 29                	jne    d77a <f0+0x265a>
    d751:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d754:	0f b7 c0             	movzwl %ax,%eax
    d757:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d75a:	48 0f af c1          	imul   %rcx,%rax
    d75e:	48 c1 e8 20          	shr    $0x20,%rax
    d762:	48 39 d0             	cmp    %rdx,%rax
    d765:	73 13                	jae    d77a <f0+0x265a>
    d767:	49 01 c4             	add    %rax,%r12
    d76a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d76f:	0f 84 7d 06 00 00    	je     ddf2 <f0+0x2cd2>
    d775:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d77a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d781:	33 f3 bf 
    d784:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d78b:	00 
    d78c:	bf 01 00 00 00       	mov    $0x1,%edi
    d791:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d798:	00 
    d799:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d7a0:	00 
    d7a1:	e8 ba 89 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d7a6:	48 8b 15 6b f4 05 00 	mov    0x5f46b(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d7ad:	49 89 c5             	mov    %rax,%r13
    d7b0:	48 2b 05 39 f4 05 00 	sub    0x5f439(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d7b7:	48 c1 e2 10          	shl    $0x10,%rdx
    d7bb:	48 39 d0             	cmp    %rdx,%rax
    d7be:	73 59                	jae    d819 <f0+0x26f9>
    d7c0:	48 89 c2             	mov    %rax,%rdx
    d7c3:	48 c1 ea 10          	shr    $0x10,%rdx
    d7c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7cb:	48 8b 15 66 f4 05 00 	mov    0x5f466(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d7d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7d6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7da:	4d 85 e4             	test   %r12,%r12
    d7dd:	74 3a                	je     d819 <f0+0x26f9>
    d7df:	0f b6 0a             	movzbl (%rdx),%ecx
    d7e2:	80 f9 02             	cmp    $0x2,%cl
    d7e5:	0f 84 55 03 00 00    	je     db40 <f0+0x2a20>
    d7eb:	80 f9 01             	cmp    $0x1,%cl
    d7ee:	75 29                	jne    d819 <f0+0x26f9>
    d7f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7f3:	0f b7 c0             	movzwl %ax,%eax
    d7f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7f9:	48 0f af c1          	imul   %rcx,%rax
    d7fd:	48 c1 e8 20          	shr    $0x20,%rax
    d801:	48 39 d0             	cmp    %rdx,%rax
    d804:	73 13                	jae    d819 <f0+0x26f9>
    d806:	49 01 c4             	add    %rax,%r12
    d809:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d80e:	0f 84 eb 05 00 00    	je     ddff <f0+0x2cdf>
    d814:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d819:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d820:	00 f0 3f 
    d823:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d82a:	00 
    d82b:	bf 01 00 00 00       	mov    $0x1,%edi
    d830:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d837:	00 
    d838:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d83f:	00 
    d840:	e8 1b 89 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d845:	48 8b 15 cc f3 05 00 	mov    0x5f3cc(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d84c:	49 89 c5             	mov    %rax,%r13
    d84f:	48 2b 05 9a f3 05 00 	sub    0x5f39a(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d856:	48 c1 e2 10          	shl    $0x10,%rdx
    d85a:	48 39 d0             	cmp    %rdx,%rax
    d85d:	73 59                	jae    d8b8 <f0+0x2798>
    d85f:	48 89 c2             	mov    %rax,%rdx
    d862:	48 c1 ea 10          	shr    $0x10,%rdx
    d866:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d86a:	48 8b 15 c7 f3 05 00 	mov    0x5f3c7(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d871:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d875:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d879:	4d 85 e4             	test   %r12,%r12
    d87c:	74 3a                	je     d8b8 <f0+0x2798>
    d87e:	0f b6 0a             	movzbl (%rdx),%ecx
    d881:	80 f9 02             	cmp    $0x2,%cl
    d884:	0f 84 a6 02 00 00    	je     db30 <f0+0x2a10>
    d88a:	80 f9 01             	cmp    $0x1,%cl
    d88d:	75 29                	jne    d8b8 <f0+0x2798>
    d88f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d892:	0f b7 c0             	movzwl %ax,%eax
    d895:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d898:	48 0f af c1          	imul   %rcx,%rax
    d89c:	48 c1 e8 20          	shr    $0x20,%rax
    d8a0:	48 39 d0             	cmp    %rdx,%rax
    d8a3:	73 13                	jae    d8b8 <f0+0x2798>
    d8a5:	49 01 c4             	add    %rax,%r12
    d8a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8ad:	0f 84 59 05 00 00    	je     de0c <f0+0x2cec>
    d8b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8b8:	48 89 ee             	mov    %rbp,%rsi
    d8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d8c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d8c7:	33 f3 bf 
    d8ca:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d8d1:	00 
    d8d2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d8d9:	00 
    d8da:	e8 81 88 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    d8df:	48 8b 15 32 f3 05 00 	mov    0x5f332(%rip),%rdx        # 6cc18 <fwp_heap+0x13d8>
    d8e6:	48 89 c5             	mov    %rax,%rbp
    d8e9:	48 2b 05 00 f3 05 00 	sub    0x5f300(%rip),%rax        # 6cbf0 <fwp_heap+0x13b0>
    d8f0:	48 c1 e2 10          	shl    $0x10,%rdx
    d8f4:	48 39 d0             	cmp    %rdx,%rax
    d8f7:	73 59                	jae    d952 <f0+0x2832>
    d8f9:	48 89 c2             	mov    %rax,%rdx
    d8fc:	48 c1 ea 10          	shr    $0x10,%rdx
    d900:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d904:	48 8b 15 2d f3 05 00 	mov    0x5f32d(%rip),%rdx        # 6cc38 <fwp_heap+0x13f8>
    d90b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d90f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d913:	4d 85 e4             	test   %r12,%r12
    d916:	74 3a                	je     d952 <f0+0x2832>
    d918:	0f b6 0a             	movzbl (%rdx),%ecx
    d91b:	80 f9 02             	cmp    $0x2,%cl
    d91e:	0f 84 fc 01 00 00    	je     db20 <f0+0x2a00>
    d924:	80 f9 01             	cmp    $0x1,%cl
    d927:	75 29                	jne    d952 <f0+0x2832>
    d929:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d92c:	0f b7 c0             	movzwl %ax,%eax
    d92f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d932:	48 0f af c1          	imul   %rcx,%rax
    d936:	48 c1 e8 20          	shr    $0x20,%rax
    d93a:	48 39 d0             	cmp    %rdx,%rax
    d93d:	73 13                	jae    d952 <f0+0x2832>
    d93f:	49 01 c4             	add    %rax,%r12
    d942:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d947:	0f 84 d1 02 00 00    	je     dc1e <f0+0x2afe>
    d94d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d952:	48 89 de             	mov    %rbx,%rsi
    d955:	48 89 ef             	mov    %rbp,%rdi
    d958:	e8 23 be ff ff       	call   9780 <fwp_hof0.constprop.0>
    d95d:	48 89 ef             	mov    %rbp,%rdi
    d960:	e8 bb a2 ff ff       	call   7c20 <fwp_drop0>
    d965:	48 89 df             	mov    %rbx,%rdi
    d968:	e8 b3 a2 ff ff       	call   7c20 <fwp_drop0>
    d96d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d974:	00 
    d975:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d97c:	00 00 
    d97e:	0f 85 95 04 00 00    	jne    de19 <f0+0x2cf9>
    d984:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d98b:	31 c0                	xor    %eax,%eax
    d98d:	5b                   	pop    %rbx
    d98e:	5d                   	pop    %rbp
    d98f:	41 5c                	pop    %r12
    d991:	41 5d                	pop    %r13
    d993:	41 5e                	pop    %r14
    d995:	c3                   	ret
    d996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d99d:	00 00 00 
    d9a0:	4c 89 ef             	mov    %r13,%rdi
    d9a3:	e8 88 7e ff ff       	call   5830 <fwp_rc_forget_slot>
    d9a8:	e9 2c d8 ff ff       	jmp    b1d9 <f0+0xb9>
    d9ad:	0f 1f 00             	nopl   (%rax)
    d9b0:	66 85 c0             	test   %ax,%ax
    d9b3:	0f 85 ae f5 ff ff    	jne    cf67 <f0+0x1e47>
    d9b9:	e9 99 f5 ff ff       	jmp    cf57 <f0+0x1e37>
    d9be:	66 90                	xchg   %ax,%ax
    d9c0:	66 85 c0             	test   %ax,%ax
    d9c3:	0f 85 ff f4 ff ff    	jne    cec8 <f0+0x1da8>
    d9c9:	e9 ea f4 ff ff       	jmp    ceb8 <f0+0x1d98>
    d9ce:	66 90                	xchg   %ax,%ax
    d9d0:	66 85 c0             	test   %ax,%ax
    d9d3:	0f 85 50 f4 ff ff    	jne    ce29 <f0+0x1d09>
    d9d9:	e9 3b f4 ff ff       	jmp    ce19 <f0+0x1cf9>
    d9de:	66 90                	xchg   %ax,%ax
    d9e0:	66 85 c0             	test   %ax,%ax
    d9e3:	0f 85 a1 f3 ff ff    	jne    cd8a <f0+0x1c6a>
    d9e9:	e9 8c f3 ff ff       	jmp    cd7a <f0+0x1c5a>
    d9ee:	66 90                	xchg   %ax,%ax
    d9f0:	66 85 c0             	test   %ax,%ax
    d9f3:	0f 85 f2 f2 ff ff    	jne    cceb <f0+0x1bcb>
    d9f9:	e9 dd f2 ff ff       	jmp    ccdb <f0+0x1bbb>
    d9fe:	66 90                	xchg   %ax,%ax
    da00:	66 85 c0             	test   %ax,%ax
    da03:	0f 85 43 f2 ff ff    	jne    cc4c <f0+0x1b2c>
    da09:	e9 2e f2 ff ff       	jmp    cc3c <f0+0x1b1c>
    da0e:	66 90                	xchg   %ax,%ax
    da10:	66 85 c0             	test   %ax,%ax
    da13:	0f 85 94 f1 ff ff    	jne    cbad <f0+0x1a8d>
    da19:	e9 7f f1 ff ff       	jmp    cb9d <f0+0x1a7d>
    da1e:	66 90                	xchg   %ax,%ax
    da20:	66 85 c0             	test   %ax,%ax
    da23:	0f 85 e5 f0 ff ff    	jne    cb0e <f0+0x19ee>
    da29:	e9 d0 f0 ff ff       	jmp    cafe <f0+0x19de>
    da2e:	66 90                	xchg   %ax,%ax
    da30:	66 85 c0             	test   %ax,%ax
    da33:	0f 85 fd d9 ff ff    	jne    b436 <f0+0x316>
    da39:	e9 e8 d9 ff ff       	jmp    b426 <f0+0x306>
    da3e:	66 90                	xchg   %ax,%ax
    da40:	66 85 c0             	test   %ax,%ax
    da43:	0f 85 57 d9 ff ff    	jne    b3a0 <f0+0x280>
    da49:	e9 42 d9 ff ff       	jmp    b390 <f0+0x270>
    da4e:	66 90                	xchg   %ax,%ax
    da50:	66 85 c0             	test   %ax,%ax
    da53:	0f 85 b1 d8 ff ff    	jne    b30a <f0+0x1ea>
    da59:	e9 9c d8 ff ff       	jmp    b2fa <f0+0x1da>
    da5e:	66 90                	xchg   %ax,%ax
    da60:	66 85 c0             	test   %ax,%ax
    da63:	0f 85 0e eb ff ff    	jne    c577 <f0+0x1457>
    da69:	e9 f9 ea ff ff       	jmp    c567 <f0+0x1447>
    da6e:	66 90                	xchg   %ax,%ax
    da70:	66 85 c0             	test   %ax,%ax
    da73:	0f 85 5f ea ff ff    	jne    c4d8 <f0+0x13b8>
    da79:	e9 4a ea ff ff       	jmp    c4c8 <f0+0x13a8>
    da7e:	66 90                	xchg   %ax,%ax
    da80:	66 85 c0             	test   %ax,%ax
    da83:	0f 85 e2 da ff ff    	jne    b56b <f0+0x44b>
    da89:	e9 cd da ff ff       	jmp    b55b <f0+0x43b>
    da8e:	66 90                	xchg   %ax,%ax
    da90:	66 85 c0             	test   %ax,%ax
    da93:	0f 85 33 da ff ff    	jne    b4cc <f0+0x3ac>
    da99:	e9 1e da ff ff       	jmp    b4bc <f0+0x39c>
    da9e:	66 90                	xchg   %ax,%ax
    daa0:	66 85 c0             	test   %ax,%ax
    daa3:	0f 85 c6 ef ff ff    	jne    ca6f <f0+0x194f>
    daa9:	e9 b1 ef ff ff       	jmp    ca5f <f0+0x193f>
    daae:	66 90                	xchg   %ax,%ax
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 17 ef ff ff    	jne    c9d0 <f0+0x18b0>
    dab9:	e9 02 ef ff ff       	jmp    c9c0 <f0+0x18a0>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 68 ee ff ff    	jne    c931 <f0+0x1811>
    dac9:	e9 53 ee ff ff       	jmp    c921 <f0+0x1801>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 b9 ed ff ff    	jne    c892 <f0+0x1772>
    dad9:	e9 a4 ed ff ff       	jmp    c882 <f0+0x1762>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 0a ed ff ff    	jne    c7f3 <f0+0x16d3>
    dae9:	e9 f5 ec ff ff       	jmp    c7e3 <f0+0x16c3>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 5b ec ff ff    	jne    c754 <f0+0x1634>
    daf9:	e9 46 ec ff ff       	jmp    c744 <f0+0x1624>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 ac eb ff ff    	jne    c6b5 <f0+0x1595>
    db09:	e9 97 eb ff ff       	jmp    c6a5 <f0+0x1585>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 fd ea ff ff    	jne    c616 <f0+0x14f6>
    db19:	e9 e8 ea ff ff       	jmp    c606 <f0+0x14e6>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 29 fe ff ff    	jne    d952 <f0+0x2832>
    db29:	e9 14 fe ff ff       	jmp    d942 <f0+0x2822>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 7f fd ff ff    	jne    d8b8 <f0+0x2798>
    db39:	e9 6a fd ff ff       	jmp    d8a8 <f0+0x2788>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 d0 fc ff ff    	jne    d819 <f0+0x26f9>
    db49:	e9 bb fc ff ff       	jmp    d809 <f0+0x26e9>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 21 fc ff ff    	jne    d77a <f0+0x265a>
    db59:	e9 0c fc ff ff       	jmp    d76a <f0+0x264a>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 72 fb ff ff    	jne    d6db <f0+0x25bb>
    db69:	e9 5d fb ff ff       	jmp    d6cb <f0+0x25ab>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 c3 fa ff ff    	jne    d63c <f0+0x251c>
    db79:	e9 ae fa ff ff       	jmp    d62c <f0+0x250c>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 14 fa ff ff    	jne    d59d <f0+0x247d>
    db89:	e9 ff f9 ff ff       	jmp    d58d <f0+0x246d>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 65 f9 ff ff    	jne    d4fe <f0+0x23de>
    db99:	e9 50 f9 ff ff       	jmp    d4ee <f0+0x23ce>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 b6 f8 ff ff    	jne    d45f <f0+0x233f>
    dba9:	e9 a1 f8 ff ff       	jmp    d44f <f0+0x232f>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 07 f8 ff ff    	jne    d3c0 <f0+0x22a0>
    dbb9:	e9 f2 f7 ff ff       	jmp    d3b0 <f0+0x2290>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 58 f7 ff ff    	jne    d321 <f0+0x2201>
    dbc9:	e9 43 f7 ff ff       	jmp    d311 <f0+0x21f1>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 a9 f6 ff ff    	jne    d282 <f0+0x2162>
    dbd9:	e9 94 f6 ff ff       	jmp    d272 <f0+0x2152>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 fa f5 ff ff    	jne    d1e3 <f0+0x20c3>
    dbe9:	e9 e5 f5 ff ff       	jmp    d1d3 <f0+0x20b3>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 4b f5 ff ff    	jne    d144 <f0+0x2024>
    dbf9:	e9 36 f5 ff ff       	jmp    d134 <f0+0x2014>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 9c f4 ff ff    	jne    d0a5 <f0+0x1f85>
    dc09:	e9 87 f4 ff ff       	jmp    d095 <f0+0x1f75>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 ed f3 ff ff    	jne    d006 <f0+0x1ee6>
    dc19:	e9 d8 f3 ff ff       	jmp    cff6 <f0+0x1ed6>
    dc1e:	4c 89 e7             	mov    %r12,%rdi
    dc21:	e8 0a 7c ff ff       	call   5830 <fwp_rc_forget_slot>
    dc26:	e9 22 fd ff ff       	jmp    d94d <f0+0x282d>
    dc2b:	4c 89 e7             	mov    %r12,%rdi
    dc2e:	e8 fd 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc33:	e9 cd d6 ff ff       	jmp    b305 <f0+0x1e5>
    dc38:	4c 89 e7             	mov    %r12,%rdi
    dc3b:	e8 f0 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc40:	e9 56 d7 ff ff       	jmp    b39b <f0+0x27b>
    dc45:	4c 89 e7             	mov    %r12,%rdi
    dc48:	e8 e3 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc4d:	e9 df d7 ff ff       	jmp    b431 <f0+0x311>
    dc52:	4c 89 e7             	mov    %r12,%rdi
    dc55:	e8 d6 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc5a:	e9 68 d8 ff ff       	jmp    b4c7 <f0+0x3a7>
    dc5f:	4c 89 e7             	mov    %r12,%rdi
    dc62:	e8 c9 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc67:	e9 fa d8 ff ff       	jmp    b566 <f0+0x446>
    dc6c:	4c 89 e7             	mov    %r12,%rdi
    dc6f:	e8 bc 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc74:	e9 5a e8 ff ff       	jmp    c4d3 <f0+0x13b3>
    dc79:	4c 89 e7             	mov    %r12,%rdi
    dc7c:	e8 af 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc81:	e9 ec e8 ff ff       	jmp    c572 <f0+0x1452>
    dc86:	4c 89 e7             	mov    %r12,%rdi
    dc89:	e8 a2 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc8e:	e9 7e e9 ff ff       	jmp    c611 <f0+0x14f1>
    dc93:	4c 89 e7             	mov    %r12,%rdi
    dc96:	e8 95 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dc9b:	e9 10 ea ff ff       	jmp    c6b0 <f0+0x1590>
    dca0:	4c 89 e7             	mov    %r12,%rdi
    dca3:	e8 88 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dca8:	e9 a2 ea ff ff       	jmp    c74f <f0+0x162f>
    dcad:	4c 89 e7             	mov    %r12,%rdi
    dcb0:	e8 7b 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dcb5:	e9 34 eb ff ff       	jmp    c7ee <f0+0x16ce>
    dcba:	4c 89 e7             	mov    %r12,%rdi
    dcbd:	e8 6e 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dcc2:	e9 c6 eb ff ff       	jmp    c88d <f0+0x176d>
    dcc7:	4c 89 e7             	mov    %r12,%rdi
    dcca:	e8 61 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dccf:	e9 58 ec ff ff       	jmp    c92c <f0+0x180c>
    dcd4:	4c 89 e7             	mov    %r12,%rdi
    dcd7:	e8 54 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dcdc:	e9 ea ec ff ff       	jmp    c9cb <f0+0x18ab>
    dce1:	4c 89 e7             	mov    %r12,%rdi
    dce4:	e8 47 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dce9:	e9 7c ed ff ff       	jmp    ca6a <f0+0x194a>
    dcee:	4c 89 e7             	mov    %r12,%rdi
    dcf1:	e8 3a 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dcf6:	e9 0e ee ff ff       	jmp    cb09 <f0+0x19e9>
    dcfb:	4c 89 e7             	mov    %r12,%rdi
    dcfe:	e8 2d 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dd03:	e9 a0 ee ff ff       	jmp    cba8 <f0+0x1a88>
    dd08:	4c 89 e7             	mov    %r12,%rdi
    dd0b:	e8 20 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dd10:	e9 32 ef ff ff       	jmp    cc47 <f0+0x1b27>
    dd15:	4c 89 e7             	mov    %r12,%rdi
    dd18:	e8 13 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dd1d:	e9 c4 ef ff ff       	jmp    cce6 <f0+0x1bc6>
    dd22:	4c 89 e7             	mov    %r12,%rdi
    dd25:	e8 06 7b ff ff       	call   5830 <fwp_rc_forget_slot>
    dd2a:	e9 56 f0 ff ff       	jmp    cd85 <f0+0x1c65>
    dd2f:	4c 89 e7             	mov    %r12,%rdi
    dd32:	e8 f9 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd37:	e9 e8 f0 ff ff       	jmp    ce24 <f0+0x1d04>
    dd3c:	4c 89 e7             	mov    %r12,%rdi
    dd3f:	e8 ec 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd44:	e9 7a f1 ff ff       	jmp    cec3 <f0+0x1da3>
    dd49:	4c 89 e7             	mov    %r12,%rdi
    dd4c:	e8 df 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd51:	e9 0c f2 ff ff       	jmp    cf62 <f0+0x1e42>
    dd56:	4c 89 e7             	mov    %r12,%rdi
    dd59:	e8 d2 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd5e:	e9 9e f2 ff ff       	jmp    d001 <f0+0x1ee1>
    dd63:	4c 89 e7             	mov    %r12,%rdi
    dd66:	e8 c5 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd6b:	e9 30 f3 ff ff       	jmp    d0a0 <f0+0x1f80>
    dd70:	4c 89 e7             	mov    %r12,%rdi
    dd73:	e8 b8 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd78:	e9 c2 f3 ff ff       	jmp    d13f <f0+0x201f>
    dd7d:	4c 89 e7             	mov    %r12,%rdi
    dd80:	e8 ab 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd85:	e9 54 f4 ff ff       	jmp    d1de <f0+0x20be>
    dd8a:	4c 89 e7             	mov    %r12,%rdi
    dd8d:	e8 9e 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd92:	e9 e6 f4 ff ff       	jmp    d27d <f0+0x215d>
    dd97:	4c 89 e7             	mov    %r12,%rdi
    dd9a:	e8 91 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dd9f:	e9 78 f5 ff ff       	jmp    d31c <f0+0x21fc>
    dda4:	4c 89 e7             	mov    %r12,%rdi
    dda7:	e8 84 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    ddac:	e9 0a f6 ff ff       	jmp    d3bb <f0+0x229b>
    ddb1:	4c 89 e7             	mov    %r12,%rdi
    ddb4:	e8 77 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    ddb9:	e9 9c f6 ff ff       	jmp    d45a <f0+0x233a>
    ddbe:	4c 89 e7             	mov    %r12,%rdi
    ddc1:	e8 6a 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    ddc6:	e9 2e f7 ff ff       	jmp    d4f9 <f0+0x23d9>
    ddcb:	4c 89 e7             	mov    %r12,%rdi
    ddce:	e8 5d 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    ddd3:	e9 c0 f7 ff ff       	jmp    d598 <f0+0x2478>
    ddd8:	4c 89 e7             	mov    %r12,%rdi
    dddb:	e8 50 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dde0:	e9 52 f8 ff ff       	jmp    d637 <f0+0x2517>
    dde5:	4c 89 e7             	mov    %r12,%rdi
    dde8:	e8 43 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    dded:	e9 e4 f8 ff ff       	jmp    d6d6 <f0+0x25b6>
    ddf2:	4c 89 e7             	mov    %r12,%rdi
    ddf5:	e8 36 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    ddfa:	e9 76 f9 ff ff       	jmp    d775 <f0+0x2655>
    ddff:	4c 89 e7             	mov    %r12,%rdi
    de02:	e8 29 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    de07:	e9 08 fa ff ff       	jmp    d814 <f0+0x26f4>
    de0c:	4c 89 e7             	mov    %r12,%rdi
    de0f:	e8 1c 7a ff ff       	call   5830 <fwp_rc_forget_slot>
    de14:	e9 9a fa ff ff       	jmp    d8b3 <f0+0x2793>
    de19:	e8 32 56 ff ff       	call   3450 <__stack_chk_fail@plt>
    de1e:	66 90                	xchg   %ax,%ax

000000000000de20 <fwp_main_thread>:
    de20:	f3 0f 1e fa          	endbr64
    de24:	41 54                	push   %r12
    de26:	55                   	push   %rbp
    de27:	53                   	push   %rbx
    de28:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    de2f:	8b 0d af ed 05 00    	mov    0x5edaf(%rip),%ecx        # 6cbe4 <fwp_heap+0x13a4>
    de35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    de3c:	00 00 
    de3e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    de45:	00 
    de46:	31 c0                	xor    %eax,%eax
    de48:	85 c9                	test   %ecx,%ecx
    de4a:	0f 84 58 07 00 00    	je     e5a8 <fwp_main_thread+0x788>
    de50:	8b 15 92 ed 05 00    	mov    0x5ed92(%rip),%edx        # 6cbe8 <fwp_heap+0x13a8>
    de56:	85 d2                	test   %edx,%edx
    de58:	0f 85 32 07 00 00    	jne    e590 <fwp_main_thread+0x770>
    de5e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    de63:	31 f6                	xor    %esi,%esi
    de65:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    de6a:	48 c7 05 6b d3 05 00 	movq   $0x40000000,0x5d36b(%rip)        # 6b1e0 <fwp_main_stack_size>
    de71:	00 00 00 40 
    de75:	48 89 05 6c d3 05 00 	mov    %rax,0x5d36c(%rip)        # 6b1e8 <fwp_main_stack_top>
    de7c:	48 8d 05 1d 52 00 00 	lea    0x521d(%rip),%rax        # 130a0 <alt.9>
    de83:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    de88:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    de8f:	01 00 
    de91:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    de98:	00 
    de99:	e8 02 58 ff ff       	call   36a0 <sigaltstack@plt>
    de9e:	85 c0                	test   %eax,%eax
    dea0:	0f 85 6a 07 00 00    	jne    e610 <fwp_main_thread+0x7f0>
    dea6:	31 c0                	xor    %eax,%eax
    dea8:	b9 12 00 00 00       	mov    $0x12,%ecx
    dead:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    deb2:	f3 48 ab             	rep stos %rax,(%rdi)
    deb5:	48 8d 05 84 5e ff ff 	lea    -0xa17c(%rip),%rax        # 3d40 <fwp_segv>
    debc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dec1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    dec8:	04 00 00 08 
    decc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    ded1:	e8 8a 56 ff ff       	call   3560 <sigemptyset@plt>
    ded6:	85 c0                	test   %eax,%eax
    ded8:	0f 85 32 07 00 00    	jne    e610 <fwp_main_thread+0x7f0>
    dede:	31 d2                	xor    %edx,%edx
    dee0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dee5:	bf 0b 00 00 00       	mov    $0xb,%edi
    deea:	e8 01 55 ff ff       	call   33f0 <sigaction@plt>
    deef:	85 c0                	test   %eax,%eax
    def1:	0f 85 19 07 00 00    	jne    e610 <fwp_main_thread+0x7f0>
    def7:	31 d2                	xor    %edx,%edx
    def9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    defe:	bf 07 00 00 00       	mov    $0x7,%edi
    df03:	e8 e8 54 ff ff       	call   33f0 <sigaction@plt>
    df08:	85 c0                	test   %eax,%eax
    df0a:	0f 85 00 07 00 00    	jne    e610 <fwp_main_thread+0x7f0>
    df10:	48 8b 05 49 ed 05 00 	mov    0x5ed49(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    df17:	48 85 c0             	test   %rax,%rax
    df1a:	0f 88 50 06 00 00    	js     e570 <fwp_main_thread+0x750>
    df20:	66 0f ef c0          	pxor   %xmm0,%xmm0
    df24:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    df29:	48 8d 3d f0 62 ff ff 	lea    -0x9d10(%rip),%rdi        # 4220 <ad_raw_report>
    df30:	f2 0f 11 05 b0 f5 05 	movsd  %xmm0,0x5f5b0(%rip)        # 6d4e8 <iteration_start_charge>
    df37:	00 
    df38:	c7 05 c6 f5 05 00 01 	movl   $0x1,0x5f5c6(%rip)        # 6d508 <iteration_active>
    df3f:	00 00 00 
    df42:	e8 09 09 00 00       	call   e850 <atexit>
    df47:	85 c0                	test   %eax,%eax
    df49:	0f 85 cd 06 00 00    	jne    e61c <fwp_main_thread+0x7fc>
    df4f:	8b 05 33 51 00 00    	mov    0x5133(%rip),%eax        # 13088 <st.7>
    df55:	85 c0                	test   %eax,%eax
    df57:	0f 84 5b 06 00 00    	je     e5b8 <fwp_main_thread+0x798>
    df5d:	48 8b 2d bc d8 05 00 	mov    0x5d8bc(%rip),%rbp        # 6b820 <fwp_cur>
    df64:	48 85 ed             	test   %rbp,%rbp
    df67:	0f 84 03 03 00 00    	je     e270 <fwp_main_thread+0x450>
    df6d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    df72:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    df76:	48 89 eb             	mov    %rbp,%rbx
    df79:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    df7e:	0f 84 41 01 00 00    	je     e0c5 <fwp_main_thread+0x2a5>
    df84:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    df89:	0f 84 11 02 00 00    	je     e1a0 <fwp_main_thread+0x380>
    df8f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    df93:	0f 84 f7 01 00 00    	je     e190 <fwp_main_thread+0x370>
    df99:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    df9d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dfa1:	0f 85 79 02 00 00    	jne    e220 <fwp_main_thread+0x400>
    dfa7:	48 8b 43 60          	mov    0x60(%rbx),%rax
    dfab:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dfb2:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dfb6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dfbd:	00 00 00 00 
    dfc1:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dfc8:	48 85 d2             	test   %rdx,%rdx
    dfcb:	74 07                	je     dfd4 <fwp_main_thread+0x1b4>
    dfcd:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dfd4:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dfd8:	48 85 c0             	test   %rax,%rax
    dfdb:	74 34                	je     e011 <fwp_main_thread+0x1f1>
    dfdd:	48 89 43 68          	mov    %rax,0x68(%rbx)
    dfe1:	48 8b 05 10 d8 05 00 	mov    0x5d810(%rip),%rax        # 6b7f8 <fwp_timers>
    dfe8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    dfec:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    dff3:	00 00 00 00 
    dff7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    dffe:	48 85 c0             	test   %rax,%rax
    e001:	74 07                	je     e00a <fwp_main_thread+0x1ea>
    e003:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e00a:	48 89 1d e7 d7 05 00 	mov    %rbx,0x5d7e7(%rip)        # 6b7f8 <fwp_timers>
    e011:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e015:	e8 96 97 ff ff       	call   77b0 <fwp_block>
    e01a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e021:	48 85 c9             	test   %rcx,%rcx
    e024:	74 47                	je     e06d <fwp_main_thread+0x24d>
    e026:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e02d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e034:	48 85 d2             	test   %rdx,%rdx
    e037:	0f 84 23 02 00 00    	je     e260 <fwp_main_thread+0x440>
    e03d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e044:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e04b:	48 85 c0             	test   %rax,%rax
    e04e:	74 07                	je     e057 <fwp_main_thread+0x237>
    e050:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e057:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e05e:	00 00 00 00 
    e062:	66 0f ef d2          	pxor   %xmm2,%xmm2
    e066:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    e06d:	48 8b 0d ac d7 05 00 	mov    0x5d7ac(%rip),%rcx        # 6b820 <fwp_cur>
    e074:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e078:	0f 84 92 01 00 00    	je     e210 <fwp_main_thread+0x3f0>
    e07e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e085:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e08c:	48 85 d2             	test   %rdx,%rdx
    e08f:	0f 84 1b 04 00 00    	je     e4b0 <fwp_main_thread+0x690>
    e095:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e09c:	48 85 c0             	test   %rax,%rax
    e09f:	74 07                	je     e0a8 <fwp_main_thread+0x288>
    e0a1:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e0a8:	66 0f ef db          	pxor   %xmm3,%xmm3
    e0ac:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e0b0:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e0b7:	48 89 cb             	mov    %rcx,%rbx
    e0ba:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e0bf:	0f 85 bf fe ff ff    	jne    df84 <fwp_main_thread+0x164>
    e0c5:	48 83 3d eb f3 05 00 	cmpq   $0x0,0x5f3eb(%rip)        # 6d4b8 <fwp_state_len>
    e0cc:	00 
    e0cd:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e0d1:	0f 84 0b 04 00 00    	je     e4e2 <fwp_main_thread+0x6c2>
    e0d7:	48 3b 1d 3a d7 05 00 	cmp    0x5d73a(%rip),%rbx        # 6b818 <fwp_root>
    e0de:	c7 05 b8 4f 01 00 00 	movl   $0x0,0x14fb8(%rip)        # 230a0 <fwp_exit_code>
    e0e5:	00 00 00 
    e0e8:	0f 85 4c 05 00 00    	jne    e63a <fwp_main_thread+0x81a>
    e0ee:	48 85 db             	test   %rbx,%rbx
    e0f1:	0f 84 9f 01 00 00    	je     e296 <fwp_main_thread+0x476>
    e0f7:	48 8b 15 ea d6 05 00 	mov    0x5d6ea(%rip),%rdx        # 6b7e8 <fwp_tasks_active>
    e0fe:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e102:	48 85 d2             	test   %rdx,%rdx
    e105:	0f 84 8b 01 00 00    	je     e296 <fwp_main_thread+0x476>
    e10b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e110:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e114:	75 08                	jne    e11e <fwp_main_thread+0x2fe>
    e116:	48 89 d7             	mov    %rdx,%rdi
    e119:	e8 12 60 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e11e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e125:	48 85 d2             	test   %rdx,%rdx
    e128:	75 e6                	jne    e110 <fwp_main_thread+0x2f0>
    e12a:	eb 31                	jmp    e15d <fwp_main_thread+0x33d>
    e12c:	0f 1f 40 00          	nopl   0x0(%rax)
    e130:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e137:	48 89 1d c2 d6 05 00 	mov    %rbx,0x5d6c2(%rip)        # 6b800 <fwp_ready_tail>
    e13e:	e8 6d 96 ff ff       	call   77b0 <fwp_block>
    e143:	e8 58 94 ff ff       	call   75a0 <fwp_free_zombie>
    e148:	48 83 3d 98 d6 05 00 	cmpq   $0x0,0x5d698(%rip)        # 6b7e8 <fwp_tasks_active>
    e14f:	00 
    e150:	0f 84 40 01 00 00    	je     e296 <fwp_main_thread+0x476>
    e156:	48 8b 1d bb d6 05 00 	mov    0x5d6bb(%rip),%rbx        # 6b818 <fwp_root>
    e15d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e161:	75 db                	jne    e13e <fwp_main_thread+0x31e>
    e163:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e167:	75 d5                	jne    e13e <fwp_main_thread+0x31e>
    e169:	48 8b 05 90 d6 05 00 	mov    0x5d690(%rip),%rax        # 6b800 <fwp_ready_tail>
    e170:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e174:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e17b:	00 00 00 00 
    e17f:	48 85 c0             	test   %rax,%rax
    e182:	75 ac                	jne    e130 <fwp_main_thread+0x310>
    e184:	48 89 1d 7d d6 05 00 	mov    %rbx,0x5d67d(%rip)        # 6b808 <fwp_ready_head>
    e18b:	eb aa                	jmp    e137 <fwp_main_thread+0x317>
    e18d:	0f 1f 00             	nopl   (%rax)
    e190:	e8 2b 64 ff ff       	call   45c0 <fwp_now_ns>
    e195:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e199:	0f 8d 21 03 00 00    	jge    e4c0 <fwp_main_thread+0x6a0>
    e19f:	90                   	nop
    e1a0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e1a4:	0f 85 ef fd ff ff    	jne    df99 <fwp_main_thread+0x179>
    e1aa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e1ae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e1b2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e1b6:	0f 85 ef fd ff ff    	jne    dfab <fwp_main_thread+0x18b>
    e1bc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e1c0:	48 85 c9             	test   %rcx,%rcx
    e1c3:	0f 84 e2 fd ff ff    	je     dfab <fwp_main_thread+0x18b>
    e1c9:	48 85 c0             	test   %rax,%rax
    e1cc:	0f 84 5b 04 00 00    	je     e62d <fwp_main_thread+0x80d>
    e1d2:	48 39 c8             	cmp    %rcx,%rax
    e1d5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e1d9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e1e0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e1e4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e1eb:	00 00 00 00 
    e1ef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e1f6:	48 85 d2             	test   %rdx,%rdx
    e1f9:	74 07                	je     e202 <fwp_main_thread+0x3e2>
    e1fb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e202:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e206:	e9 d2 fd ff ff       	jmp    dfdd <fwp_main_thread+0x1bd>
    e20b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e210:	48 89 cb             	mov    %rcx,%rbx
    e213:	e9 61 fd ff ff       	jmp    df79 <fwp_main_thread+0x159>
    e218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e21f:	00 
    e220:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e224:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e22b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e232:	00 00 00 00 
    e236:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e23d:	48 85 c0             	test   %rax,%rax
    e240:	0f 84 9a 03 00 00    	je     e5e0 <fwp_main_thread+0x7c0>
    e246:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e24d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e251:	e9 bb fd ff ff       	jmp    e011 <fwp_main_thread+0x1f1>
    e256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e25d:	00 00 00 
    e260:	48 89 01             	mov    %rax,(%rcx)
    e263:	e9 e3 fd ff ff       	jmp    e04b <fwp_main_thread+0x22b>
    e268:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e26f:	00 
    e270:	48 83 3d 40 f2 05 00 	cmpq   $0x0,0x5f240(%rip)        # 6d4b8 <fwp_state_len>
    e277:	00 
    e278:	0f 84 62 02 00 00    	je     e4e0 <fwp_main_thread+0x6c0>
    e27e:	48 83 3d 92 d5 05 00 	cmpq   $0x0,0x5d592(%rip)        # 6b818 <fwp_root>
    e285:	00 
    e286:	c7 05 10 4e 01 00 00 	movl   $0x0,0x14e10(%rip)        # 230a0 <fwp_exit_code>
    e28d:	00 00 00 
    e290:	0f 85 9f 03 00 00    	jne    e635 <fwp_main_thread+0x815>
    e296:	e8 05 93 ff ff       	call   75a0 <fwp_free_zombie>
    e29b:	48 83 3d 65 d5 05 00 	cmpq   $0x0,0x5d565(%rip)        # 6b808 <fwp_ready_head>
    e2a2:	00 
    e2a3:	0f 85 ac 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2a9:	48 83 3d 47 d5 05 00 	cmpq   $0x0,0x5d547(%rip)        # 6b7f8 <fwp_timers>
    e2b0:	00 
    e2b1:	0f 85 9e 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2b7:	8b 1d 37 cf 05 00    	mov    0x5cf37(%rip),%ebx        # 6b1f4 <fwp_stack_pool_n>
    e2bd:	85 db                	test   %ebx,%ebx
    e2bf:	74 36                	je     e2f7 <fwp_main_thread+0x4d7>
    e2c1:	83 eb 01             	sub    $0x1,%ebx
    e2c4:	48 8d 05 35 cf 05 00 	lea    0x5cf35(%rip),%rax        # 6b200 <fwp_stack_pool>
    e2cb:	48 63 d3             	movslq %ebx,%rdx
    e2ce:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e2d2:	eb 07                	jmp    e2db <fwp_main_thread+0x4bb>
    e2d4:	0f 1f 40 00          	nopl   0x0(%rax)
    e2d8:	83 eb 01             	sub    $0x1,%ebx
    e2db:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e2df:	be 00 00 00 10       	mov    $0x10000000,%esi
    e2e4:	89 1d 0a cf 05 00    	mov    %ebx,0x5cf0a(%rip)        # 6b1f4 <fwp_stack_pool_n>
    e2ea:	48 83 ed 08          	sub    $0x8,%rbp
    e2ee:	e8 cd 52 ff ff       	call   35c0 <munmap@plt>
    e2f3:	85 db                	test   %ebx,%ebx
    e2f5:	75 e1                	jne    e2d8 <fwp_main_thread+0x4b8>
    e2f7:	8b 3d 1b 4d 00 00    	mov    0x4d1b(%rip),%edi        # 13018 <fwp_epfd>
    e2fd:	85 ff                	test   %edi,%edi
    e2ff:	78 05                	js     e306 <fwp_main_thread+0x4e6>
    e301:	e8 ba 51 ff ff       	call   34c0 <close@plt>
    e306:	4c 8b 25 f3 d0 05 00 	mov    0x5d0f3(%rip),%r12        # 6b400 <fwp_nfdws>
    e30d:	48 8b 2d f4 d0 05 00 	mov    0x5d0f4(%rip),%rbp        # 6b408 <fwp_fdws>
    e314:	31 db                	xor    %ebx,%ebx
    e316:	c7 05 f8 4c 00 00 ff 	movl   $0xffffffff,0x4cf8(%rip)        # 13018 <fwp_epfd>
    e31d:	ff ff ff 
    e320:	4d 85 e4             	test   %r12,%r12
    e323:	74 38                	je     e35d <fwp_main_thread+0x53d>
    e325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e32c:	00 00 00 00 
    e330:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e335:	48 85 ff             	test   %rdi,%rdi
    e338:	74 1a                	je     e354 <fwp_main_thread+0x534>
    e33a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e33e:	0f 85 11 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e344:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e349:	0f 85 06 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e34f:	e8 1c 77 ff ff       	call   5a70 <fwp_mem_free>
    e354:	48 83 c3 01          	add    $0x1,%rbx
    e358:	49 39 dc             	cmp    %rbx,%r12
    e35b:	75 d3                	jne    e330 <fwp_main_thread+0x510>
    e35d:	48 89 ef             	mov    %rbp,%rdi
    e360:	e8 0b 77 ff ff       	call   5a70 <fwp_mem_free>
    e365:	48 8b 15 ac d4 05 00 	mov    0x5d4ac(%rip),%rdx        # 6b818 <fwp_root>
    e36c:	48 c7 05 91 d0 05 00 	movq   $0x0,0x5d091(%rip)        # 6b408 <fwp_fdws>
    e373:	00 00 00 00 
    e377:	48 c7 05 7e d0 05 00 	movq   $0x0,0x5d07e(%rip)        # 6b400 <fwp_nfdws>
    e37e:	00 00 00 00 
    e382:	48 85 d2             	test   %rdx,%rdx
    e385:	74 4e                	je     e3d5 <fwp_main_thread+0x5b5>
    e387:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e38c:	0f 85 c3 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e392:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e399:	00 
    e39a:	0f 85 b5 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e3a0:	48 83 3d 10 f1 05 00 	cmpq   $0x0,0x5f110(%rip)        # 6d4b8 <fwp_state_len>
    e3a7:	00 
    e3a8:	0f 85 a7 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e3ae:	48 83 3d f2 f0 05 00 	cmpq   $0x0,0x5f0f2(%rip)        # 6d4a8 <fwp_state_owners>
    e3b5:	00 
    e3b6:	0f 85 99 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e3bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e3c1:	31 c0                	xor    %eax,%eax
    e3c3:	48 8d 3d 56 d0 05 00 	lea    0x5d056(%rip),%rdi        # 6b420 <fwp_root_context>
    e3ca:	f3 48 ab             	rep stos %rax,(%rdi)
    e3cd:	48 89 d7             	mov    %rdx,%rdi
    e3d0:	e8 9b 76 ff ff       	call   5a70 <fwp_mem_free>
    e3d5:	66 0f 6f 05 f3 4d 04 	movdqa 0x44df3(%rip),%xmm0        # 531d0 <ad_raw_live+0x10>
    e3dc:	00 
    e3dd:	66 0f d4 05 db 4d 04 	paddq  0x44ddb(%rip),%xmm0        # 531c0 <ad_raw_live>
    e3e4:	00 
    e3e5:	48 c7 05 30 d4 05 00 	movq   $0x0,0x5d430(%rip)        # 6b820 <fwp_cur>
    e3ec:	00 00 00 00 
    e3f0:	48 8b 05 69 e8 05 00 	mov    0x5e869(%rip),%rax        # 6cc60 <fwp_heap+0x1420>
    e3f7:	48 c7 05 16 d4 05 00 	movq   $0x0,0x5d416(%rip)        # 6b818 <fwp_root>
    e3fe:	00 00 00 00 
    e402:	c7 05 fc f0 05 00 00 	movl   $0x0,0x5f0fc(%rip)        # 6d508 <iteration_active>
    e409:	00 00 00 
    e40c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e410:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e415:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e419:	66 0f d6 05 f7 4c 01 	movq   %xmm0,0x14cf7(%rip)        # 23118 <ad_raw_before_shutdown>
    e420:	00 
    e421:	48 85 c0             	test   %rax,%rax
    e424:	0f 88 26 01 00 00    	js     e550 <fwp_main_thread+0x730>
    e42a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e42e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e433:	f2 0f 5c 0d ad f0 05 	subsd  0x5f0ad(%rip),%xmm1        # 6d4e8 <iteration_start_charge>
    e43a:	00 
    e43b:	48 8b 3d fe 4b 00 00 	mov    0x4bfe(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    e442:	48 8d 15 27 17 00 00 	lea    0x1727(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    e449:	be 02 00 00 00       	mov    $0x2,%esi
    e44e:	f2 0f 10 05 8a f0 05 	movsd  0x5f08a(%rip),%xmm0        # 6d4e0 <iteration_peak>
    e455:	00 
    e456:	4c 8b 0d 93 f0 05 00 	mov    0x5f093(%rip),%r9        # 6d4f0 <iteration_retains>
    e45d:	b8 02 00 00 00       	mov    $0x2,%eax
    e462:	4c 8b 05 8f f0 05 00 	mov    0x5f08f(%rip),%r8        # 6d4f8 <iteration_bytes>
    e469:	48 8b 0d 90 f0 05 00 	mov    0x5f090(%rip),%rcx        # 6d500 <iteration_requests>
    e470:	e8 fb 51 ff ff       	call   3670 <__fprintf_chk@plt>
    e475:	48 8b 3d a4 4b 00 00 	mov    0x4ba4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e47c:	e8 1f 51 ff ff       	call   35a0 <fflush@plt>
    e481:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e488:	00 
    e489:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e490:	00 00 
    e492:	0f 85 90 01 00 00    	jne    e628 <fwp_main_thread+0x808>
    e498:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e49f:	31 c0                	xor    %eax,%eax
    e4a1:	5b                   	pop    %rbx
    e4a2:	5d                   	pop    %rbp
    e4a3:	41 5c                	pop    %r12
    e4a5:	c3                   	ret
    e4a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e4ad:	00 00 00 
    e4b0:	48 89 05 41 d3 05 00 	mov    %rax,0x5d341(%rip)        # 6b7f8 <fwp_timers>
    e4b7:	e9 e0 fb ff ff       	jmp    e09c <fwp_main_thread+0x27c>
    e4bc:	0f 1f 40 00          	nopl   0x0(%rax)
    e4c0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e4c4:	0f 85 d6 fc ff ff    	jne    e1a0 <fwp_main_thread+0x380>
    e4ca:	48 89 ef             	mov    %rbp,%rdi
    e4cd:	e8 5e 5c ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e4d2:	e9 c9 fc ff ff       	jmp    e1a0 <fwp_main_thread+0x380>
    e4d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e4de:	00 00 
    e4e0:	31 db                	xor    %ebx,%ebx
    e4e2:	48 83 3d be ef 05 00 	cmpq   $0x0,0x5efbe(%rip)        # 6d4a8 <fwp_state_owners>
    e4e9:	00 
    e4ea:	0f 85 e7 fb ff ff    	jne    e0d7 <fwp_main_thread+0x2b7>
    e4f0:	48 8b 3d c9 ef 05 00 	mov    0x5efc9(%rip),%rdi        # 6d4c0 <fwp_state>
    e4f7:	e8 74 75 ff ff       	call   5a70 <fwp_mem_free>
    e4fc:	48 c7 05 b9 ef 05 00 	movq   $0x0,0x5efb9(%rip)        # 6d4c0 <fwp_state>
    e503:	00 00 00 00 
    e507:	48 c7 05 9e ef 05 00 	movq   $0x0,0x5ef9e(%rip)        # 6d4b0 <fwp_state_cap>
    e50e:	00 00 00 00 
    e512:	48 85 db             	test   %rbx,%rbx
    e515:	0f 84 ce 00 00 00    	je     e5e9 <fwp_main_thread+0x7c9>
    e51b:	48 39 1d f6 d2 05 00 	cmp    %rbx,0x5d2f6(%rip)        # 6b818 <fwp_root>
    e522:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e529:	00 00 00 00 
    e52d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e534:	00 00 00 00 
    e538:	c7 05 5e 4b 01 00 00 	movl   $0x0,0x14b5e(%rip)        # 230a0 <fwp_exit_code>
    e53f:	00 00 00 
    e542:	0f 84 af fb ff ff    	je     e0f7 <fwp_main_thread+0x2d7>
    e548:	e9 08 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e54d:	0f 1f 00             	nopl   (%rax)
    e550:	48 89 c2             	mov    %rax,%rdx
    e553:	83 e0 01             	and    $0x1,%eax
    e556:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e55a:	48 d1 ea             	shr    $1,%rdx
    e55d:	48 09 c2             	or     %rax,%rdx
    e560:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    e565:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    e569:	e9 c5 fe ff ff       	jmp    e433 <fwp_main_thread+0x613>
    e56e:	66 90                	xchg   %ax,%ax
    e570:	48 89 c2             	mov    %rax,%rdx
    e573:	83 e0 01             	and    $0x1,%eax
    e576:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e57a:	48 d1 ea             	shr    $1,%rdx
    e57d:	48 09 c2             	or     %rax,%rdx
    e580:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    e585:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    e589:	e9 9b f9 ff ff       	jmp    df29 <fwp_main_thread+0x109>
    e58e:	66 90                	xchg   %ax,%ax
    e590:	48 8d 3d 29 67 ff ff 	lea    -0x98d7(%rip),%rdi        # 4cc0 <fwp_heap_report>
    e597:	e8 b4 02 00 00       	call   e850 <atexit>
    e59c:	e9 bd f8 ff ff       	jmp    de5e <fwp_main_thread+0x3e>
    e5a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e5a8:	e8 23 68 ff ff       	call   4dd0 <fwp_heap_init>
    e5ad:	e9 9e f8 ff ff       	jmp    de50 <fwp_main_thread+0x30>
    e5b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e5b8:	e8 63 cb ff ff       	call   b120 <f0>
    e5bd:	48 c7 05 b8 4a 00 00 	movq   $0x0,0x4ab8(%rip)        # 13080 <v.6>
    e5c4:	00 00 00 00 
    e5c8:	c7 05 b6 4a 00 00 01 	movl   $0x1,0x4ab6(%rip)        # 13088 <st.7>
    e5cf:	00 00 00 
    e5d2:	e9 86 f9 ff ff       	jmp    df5d <fwp_main_thread+0x13d>
    e5d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e5de:	00 00 
    e5e0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e5e4:	e9 28 fa ff ff       	jmp    e011 <fwp_main_thread+0x1f1>
    e5e9:	48 83 3d 27 d2 05 00 	cmpq   $0x0,0x5d227(%rip)        # 6b818 <fwp_root>
    e5f0:	00 
    e5f1:	c7 05 a5 4a 01 00 00 	movl   $0x0,0x14aa5(%rip)        # 230a0 <fwp_exit_code>
    e5f8:	00 00 00 
    e5fb:	0f 84 95 fc ff ff    	je     e296 <fwp_main_thread+0x476>
    e601:	e9 4f 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e60d:	00 00 00 
    e610:	48 8d 3d 31 15 00 00 	lea    0x1531(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    e617:	e8 34 5e ff ff       	call   4450 <fwp_trap>
    e61c:	48 8d 3d b0 0c 00 00 	lea    0xcb0(%rip),%rdi        # f2d3 <_IO_stdin_used+0x2d3>
    e623:	e8 d8 59 ff ff       	call   4000 <ad_raw_fail>
    e628:	e8 23 4e ff ff       	call   3450 <__stack_chk_fail@plt>
    e62d:	48 89 c8             	mov    %rcx,%rax
    e630:	e9 a4 fb ff ff       	jmp    e1d9 <fwp_main_thread+0x3b9>
    e635:	e9 1b 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e63a:	e9 16 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e63f:	90                   	nop

000000000000e640 <__divmodti4>:
    e640:	f3 0f 1e fa          	endbr64
    e644:	55                   	push   %rbp
    e645:	49 89 f1             	mov    %rsi,%r9
    e648:	49 89 d2             	mov    %rdx,%r10
    e64b:	48 89 fe             	mov    %rdi,%rsi
    e64e:	49 89 cb             	mov    %rcx,%r11
    e651:	48 89 e5             	mov    %rsp,%rbp
    e654:	41 57                	push   %r15
    e656:	41 56                	push   %r14
    e658:	41 55                	push   %r13
    e65a:	41 54                	push   %r12
    e65c:	53                   	push   %rbx
    e65d:	4c 89 c3             	mov    %r8,%rbx
    e660:	45 31 c0             	xor    %r8d,%r8d
    e663:	4d 85 c9             	test   %r9,%r9
    e666:	79 12                	jns    e67a <__divmodti4+0x3a>
    e668:	31 ff                	xor    %edi,%edi
    e66a:	48 f7 de             	neg    %rsi
    e66d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e674:	4c 19 cf             	sbb    %r9,%rdi
    e677:	49 89 f9             	mov    %rdi,%r9
    e67a:	4c 89 d8             	mov    %r11,%rax
    e67d:	4d 85 db             	test   %r11,%r11
    e680:	0f 88 1a 01 00 00    	js     e7a0 <__divmodti4+0x160>
    e686:	4c 89 d9             	mov    %r11,%rcx
    e689:	49 89 f3             	mov    %rsi,%r11
    e68c:	75 62                	jne    e6f0 <__divmodti4+0xb0>
    e68e:	4d 89 c4             	mov    %r8,%r12
    e691:	4d 39 d1             	cmp    %r10,%r9
    e694:	0f 83 46 01 00 00    	jae    e7e0 <__divmodti4+0x1a0>
    e69a:	4c 89 d8             	mov    %r11,%rax
    e69d:	4c 89 ca             	mov    %r9,%rdx
    e6a0:	49 f7 f2             	div    %r10
    e6a3:	49 89 c3             	mov    %rax,%r11
    e6a6:	31 c0                	xor    %eax,%eax
    e6a8:	48 89 d6             	mov    %rdx,%rsi
    e6ab:	31 ff                	xor    %edi,%edi
    e6ad:	4c 89 d9             	mov    %r11,%rcx
    e6b0:	48 89 c2             	mov    %rax,%rdx
    e6b3:	48 89 c8             	mov    %rcx,%rax
    e6b6:	4d 85 e4             	test   %r12,%r12
    e6b9:	74 0a                	je     e6c5 <__divmodti4+0x85>
    e6bb:	48 f7 d8             	neg    %rax
    e6be:	48 83 d2 00          	adc    $0x0,%rdx
    e6c2:	48 f7 da             	neg    %rdx
    e6c5:	4d 85 c0             	test   %r8,%r8
    e6c8:	74 0a                	je     e6d4 <__divmodti4+0x94>
    e6ca:	48 f7 de             	neg    %rsi
    e6cd:	48 83 d7 00          	adc    $0x0,%rdi
    e6d1:	48 f7 df             	neg    %rdi
    e6d4:	48 89 33             	mov    %rsi,(%rbx)
    e6d7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e6db:	5b                   	pop    %rbx
    e6dc:	41 5c                	pop    %r12
    e6de:	41 5d                	pop    %r13
    e6e0:	41 5e                	pop    %r14
    e6e2:	41 5f                	pop    %r15
    e6e4:	5d                   	pop    %rbp
    e6e5:	c3                   	ret
    e6e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6ed:	00 00 00 
    e6f0:	4d 89 c4             	mov    %r8,%r12
    e6f3:	49 39 c1             	cmp    %rax,%r9
    e6f6:	0f 82 ce 00 00 00    	jb     e7ca <__divmodti4+0x18a>
    e6fc:	31 ff                	xor    %edi,%edi
    e6fe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e703:	48 63 c7             	movslq %edi,%rax
    e706:	be 40 00 00 00       	mov    $0x40,%esi
    e70b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e710:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e715:	48 29 c6             	sub    %rax,%rsi
    e718:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e71d:	48 09 c8             	or     %rcx,%rax
    e720:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e725:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e72a:	49 89 c6             	mov    %rax,%r14
    e72d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e731:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e736:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e73b:	49 09 c1             	or     %rax,%r9
    e73e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e742:	4c 89 c8             	mov    %r9,%rax
    e745:	49 f7 f6             	div    %r14
    e748:	48 89 d1             	mov    %rdx,%rcx
    e74b:	49 89 c3             	mov    %rax,%r11
    e74e:	49 89 c1             	mov    %rax,%r9
    e751:	49 f7 e2             	mul    %r10
    e754:	49 89 c6             	mov    %rax,%r14
    e757:	49 89 d2             	mov    %rdx,%r10
    e75a:	48 39 d1             	cmp    %rdx,%rcx
    e75d:	72 07                	jb     e766 <__divmodti4+0x126>
    e75f:	75 17                	jne    e778 <__divmodti4+0x138>
    e761:	49 39 c7             	cmp    %rax,%r15
    e764:	73 12                	jae    e778 <__divmodti4+0x138>
    e766:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e76a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e76e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e772:	49 89 d2             	mov    %rdx,%r10
    e775:	49 89 c6             	mov    %rax,%r14
    e778:	4c 89 f8             	mov    %r15,%rax
    e77b:	4c 29 f0             	sub    %r14,%rax
    e77e:	4c 19 d1             	sbb    %r10,%rcx
    e781:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e786:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e78b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e790:	48 09 c6             	or     %rax,%rsi
    e793:	48 89 cf             	mov    %rcx,%rdi
    e796:	31 c0                	xor    %eax,%eax
    e798:	4c 89 c9             	mov    %r9,%rcx
    e79b:	e9 10 ff ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e7a0:	4c 89 d0             	mov    %r10,%rax
    e7a3:	4c 89 da             	mov    %r11,%rdx
    e7a6:	4d 89 c4             	mov    %r8,%r12
    e7a9:	49 89 f3             	mov    %rsi,%r11
    e7ac:	48 f7 d8             	neg    %rax
    e7af:	49 f7 d4             	not    %r12
    e7b2:	48 83 d2 00          	adc    $0x0,%rdx
    e7b6:	49 89 c2             	mov    %rax,%r10
    e7b9:	48 f7 da             	neg    %rdx
    e7bc:	48 89 d1             	mov    %rdx,%rcx
    e7bf:	0f 84 cc fe ff ff    	je     e691 <__divmodti4+0x51>
    e7c5:	49 39 d1             	cmp    %rdx,%r9
    e7c8:	73 46                	jae    e810 <__divmodti4+0x1d0>
    e7ca:	4c 89 cf             	mov    %r9,%rdi
    e7cd:	31 c0                	xor    %eax,%eax
    e7cf:	31 c9                	xor    %ecx,%ecx
    e7d1:	e9 da fe ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e7d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e7dd:	00 00 00 
    e7e0:	4d 85 d2             	test   %r10,%r10
    e7e3:	75 0d                	jne    e7f2 <__divmodti4+0x1b2>
    e7e5:	b8 01 00 00 00       	mov    $0x1,%eax
    e7ea:	31 d2                	xor    %edx,%edx
    e7ec:	49 f7 f2             	div    %r10
    e7ef:	49 89 c2             	mov    %rax,%r10
    e7f2:	4c 89 c8             	mov    %r9,%rax
    e7f5:	31 d2                	xor    %edx,%edx
    e7f7:	49 f7 f2             	div    %r10
    e7fa:	49 89 c1             	mov    %rax,%r9
    e7fd:	4c 89 d8             	mov    %r11,%rax
    e800:	49 f7 f2             	div    %r10
    e803:	49 89 c3             	mov    %rax,%r11
    e806:	4c 89 c8             	mov    %r9,%rax
    e809:	e9 9a fe ff ff       	jmp    e6a8 <__divmodti4+0x68>
    e80e:	66 90                	xchg   %ax,%ax
    e810:	45 31 f6             	xor    %r14d,%r14d
    e813:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e818:	44 89 f7             	mov    %r14d,%edi
    e81b:	45 85 f6             	test   %r14d,%r14d
    e81e:	0f 85 df fe ff ff    	jne    e703 <__divmodti4+0xc3>
    e824:	4c 39 ca             	cmp    %r9,%rdx
    e827:	72 17                	jb     e840 <__divmodti4+0x200>
    e829:	31 c9                	xor    %ecx,%ecx
    e82b:	48 39 c6             	cmp    %rax,%rsi
    e82e:	73 10                	jae    e840 <__divmodti4+0x200>
    e830:	4c 89 cf             	mov    %r9,%rdi
    e833:	31 c0                	xor    %eax,%eax
    e835:	e9 76 fe ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e83a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e840:	4c 89 de             	mov    %r11,%rsi
    e843:	b9 01 00 00 00       	mov    $0x1,%ecx
    e848:	48 29 c6             	sub    %rax,%rsi
    e84b:	49 19 d1             	sbb    %rdx,%r9
    e84e:	eb e0                	jmp    e830 <__divmodti4+0x1f0>

000000000000e850 <atexit>:
    e850:	f3 0f 1e fa          	endbr64
    e854:	48 8b 15 ad 47 00 00 	mov    0x47ad(%rip),%rdx        # 13008 <__dso_handle>
    e85b:	31 f6                	xor    %esi,%esi
    e85d:	e9 de 4d ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e864 <_fini>:
    e864:	f3 0f 1e fa          	endbr64
    e868:	48 83 ec 08          	sub    $0x8,%rsp
    e86c:	48 83 c4 08          	add    $0x8,%rsp
    e870:	c3                   	ret
