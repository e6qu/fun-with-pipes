
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ef 00 00 	mov    0xefc9(%rip),%rax        # 11fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 ed 00 00    	push   0xede2(%rip)        # 11e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 ed 00 00    	jmp    *0xede4(%rip)        # 11e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e ec 00 00    	jmp    *0xec4e(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ea 00 00    	jmp    *0xea6e(%rip)        # 11e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ea 00 00    	jmp    *0xea66(%rip)        # 11e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ea 00 00    	jmp    *0xea5e(%rip)        # 11e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ea 00 00    	jmp    *0xea56(%rip)        # 11e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ea 00 00    	jmp    *0xea4e(%rip)        # 11e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ea 00 00    	jmp    *0xea46(%rip)        # 11e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ea 00 00    	jmp    *0xea3e(%rip)        # 11e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ea 00 00    	jmp    *0xea36(%rip)        # 11e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ea 00 00    	jmp    *0xea2e(%rip)        # 11e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ea 00 00    	jmp    *0xea26(%rip)        # 11e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ea 00 00    	jmp    *0xea1e(%rip)        # 11e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ea 00 00    	jmp    *0xea16(%rip)        # 11e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ea 00 00    	jmp    *0xea0e(%rip)        # 11e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ea 00 00    	jmp    *0xea06(%rip)        # 11e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe e9 00 00    	jmp    *0xe9fe(%rip)        # 11e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 e9 00 00    	jmp    *0xe9f6(%rip)        # 11e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee e9 00 00    	jmp    *0xe9ee(%rip)        # 11e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 e9 00 00    	jmp    *0xe9e6(%rip)        # 11ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de e9 00 00    	jmp    *0xe9de(%rip)        # 11ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 e9 00 00    	jmp    *0xe9d6(%rip)        # 11eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce e9 00 00    	jmp    *0xe9ce(%rip)        # 11eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 e9 00 00    	jmp    *0xe9c6(%rip)        # 11ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be e9 00 00    	jmp    *0xe9be(%rip)        # 11ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 e9 00 00    	jmp    *0xe9b6(%rip)        # 11ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae e9 00 00    	jmp    *0xe9ae(%rip)        # 11ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 e9 00 00    	jmp    *0xe9a6(%rip)        # 11ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e e9 00 00    	jmp    *0xe99e(%rip)        # 11ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 e9 00 00    	jmp    *0xe996(%rip)        # 11ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e e9 00 00    	jmp    *0xe98e(%rip)        # 11ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 e9 00 00    	jmp    *0xe986(%rip)        # 11f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e e9 00 00    	jmp    *0xe97e(%rip)        # 11f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 e9 00 00    	jmp    *0xe976(%rip)        # 11f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e e9 00 00    	jmp    *0xe96e(%rip)        # 11f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 e9 00 00    	jmp    *0xe966(%rip)        # 11f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e e9 00 00    	jmp    *0xe95e(%rip)        # 11f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 e9 00 00    	jmp    *0xe956(%rip)        # 11f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e e9 00 00    	jmp    *0xe94e(%rip)        # 11f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 e9 00 00    	jmp    *0xe946(%rip)        # 11f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e e9 00 00    	jmp    *0xe93e(%rip)        # 11f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 e9 00 00    	jmp    *0xe936(%rip)        # 11f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e e9 00 00    	jmp    *0xe92e(%rip)        # 11f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 e9 00 00    	jmp    *0xe926(%rip)        # 11f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e e9 00 00    	jmp    *0xe91e(%rip)        # 11f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 e9 00 00    	jmp    *0xe916(%rip)        # 11f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e e9 00 00    	jmp    *0xe90e(%rip)        # 11f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 e9 00 00    	jmp    *0xe906(%rip)        # 11f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe e8 00 00    	jmp    *0xe8fe(%rip)        # 11f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 e8 00 00    	jmp    *0xe8f6(%rip)        # 11f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee e8 00 00    	jmp    *0xe8ee(%rip)        # 11f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 e8 00 00    	jmp    *0xe8e6(%rip)        # 11fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de e8 00 00    	jmp    *0xe8de(%rip)        # 11fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 e8 00 00    	jmp    *0xe8d6(%rip)        # 11fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce e8 00 00    	jmp    *0xe8ce(%rip)        # 11fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 e8 00 00    	jmp    *0xe8c6(%rip)        # 11fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a a9 00 00 	lea    0xa97a(%rip),%r9        # e091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 a9 00 00 	lea    0xa977(%rip),%r8        # e095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 cb 00 00 	lea    0xcba1(%rip),%rax        # 10320 <fwp_fn_table>
    377f:	48 89 05 52 0c 02 00 	mov    %rax,0x20c52(%rip)        # 243d8 <fwp_fns>
    3786:	48 8b 05 93 e8 00 00 	mov    0xe893(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c 0c 02 00 	mov    %rax,0x20c4c(%rip)        # 243e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 aa 00 00 	lea    0xaa59(%rip),%rdi        # e1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 e8 00 00 	mov    0xe818(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 4f 9e 00 00 	lea    0x9e4f(%rip),%rdx        # d6b0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 e7 00 00 	mov    0xe783(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 e7 01 00    	mov    0x1e7f8(%rip),%eax        # 220a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 a9 00 00 	lea    0xa909(%rip),%rdi        # e202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 b0 00 00 	lea    0xb096(%rip),%rdi        # e9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 50 b0 00 00 	lea    0xb050(%rip),%rdi        # e978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 b0 00 00 	lea    0xb014(%rip),%rdi        # e948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 af 00 00 	lea    0xafe0(%rip),%rdi        # e920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 e6 00 00    	call   *0xe653(%rip)        # 11fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 e6 00 00 	lea    0xe699(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 e6 00 00 	lea    0xe692(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 e6 00 00 	mov    0xe636(%rip),%rax        # 11fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 e6 00 00 	lea    0xe669(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 e6 00 00 	lea    0xe662(%rip),%rsi        # 12020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 e6 00 00 	mov    0xe605(%rip),%rax        # 11fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d e6 00 00 00 	cmpb   $0x0,0xe64d(%rip)        # 12048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 e5 00 00 	cmpq   $0x0,0xe5e2(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 e5 00 00 	mov    0xe5f6(%rip),%rdi        # 12008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 e6 00 00 01 	movb   $0x1,0xe625(%rip)        # 12048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee e4 01 00 	add    0x1e4ee(%rip),%rdx        # 22110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc e4 01 00 	add    0x1e4dc(%rip),%rax        # 22110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 07 02 00 	mov    0x20769(%rip),%rdi        # 243e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 e3 00 00 	mov    0xe394(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 e3 00 00 	mov    0xe381(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 a3 00 00 	lea    0xa345(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 e3 00 00 	mov    0xe372(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 ea 01 00 	mov    0x1ea61(%rip),%rax        # 22760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 e3 01 00 	mov    0x1e3a1(%rip),%rax        # 22120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d e3 01 00 	sub    0x1e38d(%rip),%rax        # 22118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd ac 00 00 	lea    0xacbd(%rip),%rsi        # ea80 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b fd 01 00 	mov    0x1fd7b(%rip),%rax        # 23b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 fd 01 00 	lea    0x1fd74(%rip),%r8        # 23b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 fd 01 00 	mov    0x1fd55(%rip),%rbx        # 23b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 fd 01 00 	mov    0x1fd65(%rip),%rcx        # 23b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 fd 01 00 	mov    0x1fd01(%rip),%rdi        # 23b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a fd 01 00 	sub    %rsi,0x1fd4a(%rip)        # 23bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da fc 01 00 	mov    0x1fcda(%rip),%rax        # 23b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 fc 01 00 	add    0x1fc90(%rip),%rdi        # 23b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e fc 01 00 	mov    0x1fc9e(%rip),%rsi        # 23b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac fc 01 00 	mov    0x1fcac(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b fc 01 00 	mov    %r12,0x1fc5b(%rip)        # 23b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 fc 01 00 	mov    %rbp,0x1fc49(%rip)        # 23b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e fc 01 00 	cmp    %rdi,0x1fc2e(%rip)        # 23b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 fc 01 00 	mov    %rdi,0x1fc25(%rip)        # 23b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 fc 01 00 	sub    %rdi,0x1fc69(%rip)        # 23bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 fc 01 00 	mov    0x1fc11(%rip),%rax        # 23b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a fc 01 00 	lea    0x1fc0a(%rip),%r8        # 23b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd df 00 00 	mov    0xdffd(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 9f 00 00 	lea    0x9fb4(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 e6 01 00 	cmp    0x1e6a9(%rip),%rdi        # 22760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f e6 01 00 	mov    0x1e66f(%rip),%rax        # 22740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d e6 01 00 	mov    %rdi,0x1e64d(%rip)        # 22740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 e6 01 00 	mov    %rdi,0x1e629(%rip)        # 22748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 9f 00 00 	lea    0x9fdb(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 9e 00 00 	lea    0x9ea7(%rip),%rsi        # e01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 de 00 00 	mov    0xde78(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 9e 00 00 	lea    0x9e51(%rip),%rdx        # e020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 de 00 00 	mov    0xde60(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 dd 00 00 	mov    0xdd71(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 9d 00 00 	lea    0x9d28(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 9d 00 00 	lea    0x9d32(%rip),%rdi        # e02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 9c 00 00 	lea    0x9cba(%rip),%rdi        # e049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 a2 00 00 	lea    0xa270(%rip),%rdi        # e610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 a7 00 	movdqa 0xa710(%rip),%xmm0        # ead0 <msg.8+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba ff 01 00 	add    0x1ffba(%rip),%rax        # 243d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc a1 00 00 	lea    0xa1cc(%rip),%rdi        # e640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 dc 01 00 	cmp    %rax,0x1dc75(%rip)        # 22108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 dc 01 00 	add    0x1dc70(%rip),%rax        # 22110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 a1 00 00 	lea    0xa1b5(%rip),%rdi        # e670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 9b 00 00 	lea    0x9b92(%rip),%r8        # e065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 99 00 00 	lea    0x99e7(%rip),%r8        # e074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 98 00 00 	lea    0x9874(%rip),%r8        # e06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 96 00 00 	lea    0x964c(%rip),%rdi        # e079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 97 00 00 	lea    0x9736(%rip),%rsi        # e184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 f0 01 00 	mov    0x1f085(%rip),%r9        # 23b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de f0 01 00 	mov    0x1f0de(%rip),%r8        # 23ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef 9b 00 00 	lea    0x9bef(%rip),%rdx        # e6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 f0 01 00 	mov    0x1f0c6(%rip),%rcx        # 23ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 f0 01 	movsd  0x1f0d4(%rip),%xmm1        # 23bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 f0 01 	movsd  0x1f0c4(%rip),%xmm0        # 23bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 d5 00 00 	mov    0xd545(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 9f 00 	movdqa 0x9fa8(%rip),%xmm0        # eae0 <msg.8+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f eb 01 00 	lea    0x1eb7f(%rip),%rax        # 236c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 9f 00 	movdqa 0x9fd1(%rip),%xmm2        # eb20 <msg.8+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 eb 01 00 	movaps %xmm0,0x1eb25(%rip)        # 23680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d 9f 00 	movdqa 0x9f8d(%rip),%xmm0        # eaf0 <msg.8+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 ef 01 00 01 	movl   $0x1,0x1efb3(%rip)        # 23b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 eb 01 00 	movaps %xmm0,0x1eb13(%rip)        # 23690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b 9f 00 	movdqa 0x9f7b(%rip),%xmm0        # eb00 <msg.8+0x80>
    4b84:	00 
    4b85:	0f 29 05 14 eb 01 00 	movaps %xmm0,0x1eb14(%rip)        # 236a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c 9f 00 	movdqa 0x9f7c(%rip),%xmm0        # eb10 <msg.8+0x90>
    4b93:	00 
    4b94:	0f 29 05 15 eb 01 00 	movaps %xmm0,0x1eb15(%rip)        # 236b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 db 01 00 	lea    0x1db95(%rip),%r8        # 22780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 ee 01 00 	mov    %rax,0x1eeb0(%rip)        # 23b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e ee 01 00 	mov    %r12,0x1ee8e(%rip)        # 23b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 ee 01 00 	mov    %rax,0x1ee77(%rip)        # 23b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 ee 01 00 	mov    %rbx,0x1ee90(%rip)        # 23b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 ee 01 00 	mov    %rsi,0x1eeb9(%rip)        # 23b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 93 00 00 	lea    0x93d6(%rip),%rdi        # e0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 ee 01 00 	mov    %rax,0x1ee98(%rip)        # 23b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c ee 01 00    	mov    %eax,0x1ee1c(%rip)        # 23b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <caf75>:
    4d20:	8b 15 52 d3 00 00    	mov    0xd352(%rip),%edx        # 12078 <st.4>
    4d26:	85 d2                	test   %edx,%edx
    4d28:	74 0e                	je     4d38 <caf75+0x18>
    4d2a:	48 8b 05 3f d3 00 00 	mov    0xd33f(%rip),%rax        # 12070 <v.3>
    4d31:	c3                   	ret
    4d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d38:	8b 05 2a d3 00 00    	mov    0xd32a(%rip),%eax        # 12068 <st.2>
    4d3e:	85 c0                	test   %eax,%eax
    4d40:	74 1e                	je     4d60 <caf75+0x40>
    4d42:	48 8b 05 17 d3 00 00 	mov    0xd317(%rip),%rax        # 12060 <v.1>
    4d49:	48 89 05 20 d3 00 00 	mov    %rax,0xd320(%rip)        # 12070 <v.3>
    4d50:	c7 05 1e d3 00 00 01 	movl   $0x1,0xd31e(%rip)        # 12078 <st.4>
    4d57:	00 00 00 
    4d5a:	c3                   	ret
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4d67:	00 f0 3f 
    4d6a:	c7 05 f4 d2 00 00 01 	movl   $0x1,0xd2f4(%rip)        # 12068 <st.2>
    4d71:	00 00 00 
    4d74:	48 89 05 e5 d2 00 00 	mov    %rax,0xd2e5(%rip)        # 12060 <v.1>
    4d7b:	eb cc                	jmp    4d49 <caf75+0x29>
    4d7d:	0f 1f 00             	nopl   (%rax)

0000000000004d80 <fwp_wake_io>:
    4d80:	48 8b 07             	mov    (%rdi),%rax
    4d83:	48 85 c0             	test   %rax,%rax
    4d86:	0f 84 f4 00 00 00    	je     4e80 <fwp_wake_io+0x100>
    4d8c:	53                   	push   %rbx
    4d8d:	4c 8b 05 ac d9 01 00 	mov    0x1d9ac(%rip),%r8        # 22740 <fwp_ready_tail>
    4d94:	49 89 f9             	mov    %rdi,%r9
    4d97:	48 89 c2             	mov    %rax,%rdx
    4d9a:	45 31 db             	xor    %r11d,%r11d
    4d9d:	45 31 d2             	xor    %r10d,%r10d
    4da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4da4:	eb 71                	jmp    4e17 <fwp_wake_io+0x97>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4db7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dbe:	48 85 c9             	test   %rcx,%rcx
    4dc1:	74 07                	je     4dca <fwp_wake_io+0x4a>
    4dc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4dca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4dd1:	00 00 00 00 
    4dd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ddc:	49 8b 01             	mov    (%r9),%rax
    4ddf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4de3:	75 2a                	jne    4e0f <fwp_wake_io+0x8f>
    4de5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4de9:	75 24                	jne    4e0f <fwp_wake_io+0x8f>
    4deb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4def:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4df6:	00 00 00 00 
    4dfa:	4d 85 c0             	test   %r8,%r8
    4dfd:	74 51                	je     4e50 <fwp_wake_io+0xd0>
    4dff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4e06:	49 89 d0             	mov    %rdx,%r8
    4e09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4e0f:	48 89 c2             	mov    %rax,%rdx
    4e12:	48 85 c0             	test   %rax,%rax
    4e15:	74 49                	je     4e60 <fwp_wake_io+0xe0>
    4e17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4e1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4e22:	48 85 ff             	test   %rdi,%rdi
    4e25:	74 b8                	je     4ddf <fwp_wake_io+0x5f>
    4e27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4e2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4e35:	48 85 f6             	test   %rsi,%rsi
    4e38:	0f 85 72 ff ff ff    	jne    4db0 <fwp_wake_io+0x30>
    4e3e:	48 89 0f             	mov    %rcx,(%rdi)
    4e41:	e9 78 ff ff ff       	jmp    4dbe <fwp_wake_io+0x3e>
    4e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e4d:	00 00 00 
    4e50:	48 89 d3             	mov    %rdx,%rbx
    4e53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4e59:	eb ab                	jmp    4e06 <fwp_wake_io+0x86>
    4e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e60:	45 84 db             	test   %r11b,%r11b
    4e63:	74 07                	je     4e6c <fwp_wake_io+0xec>
    4e65:	48 89 1d dc d8 01 00 	mov    %rbx,0x1d8dc(%rip)        # 22748 <fwp_ready_head>
    4e6c:	45 84 d2             	test   %r10b,%r10b
    4e6f:	74 07                	je     4e78 <fwp_wake_io+0xf8>
    4e71:	4c 89 05 c8 d8 01 00 	mov    %r8,0x1d8c8(%rip)        # 22740 <fwp_ready_tail>
    4e78:	5b                   	pop    %rbx
    4e79:	c3                   	ret
    4e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e80:	c3                   	ret
    4e81:	0f 1f 40 00          	nopl   0x0(%rax)
    4e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e8c:	00 00 00 00 

0000000000004e90 <fwp_tape_buffers_release>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	53                   	push   %rbx
    4e95:	48 89 fb             	mov    %rdi,%rbx
    4e98:	48 83 ec 10          	sub    $0x10,%rsp
    4e9c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4ea0:	48 85 c0             	test   %rax,%rax
    4ea3:	0f 88 df 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4ea9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4ead:	48 85 d2             	test   %rdx,%rdx
    4eb0:	0f 88 d2 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4eb6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4ebc:	0f 87 c6 00 00 00    	ja     4f88 <fwp_tape_buffers_release+0xf8>
    4ec2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4ec6:	b8 00 00 08 00       	mov    $0x80000,%eax
    4ecb:	48 c1 e1 03          	shl    $0x3,%rcx
    4ecf:	48 29 c8             	sub    %rcx,%rax
    4ed2:	48 c1 e8 03          	shr    $0x3,%rax
    4ed6:	48 39 d0             	cmp    %rdx,%rax
    4ed9:	0f 82 a9 00 00 00    	jb     4f88 <fwp_tape_buffers_release+0xf8>
    4edf:	48 8d 3d d9 91 00 00 	lea    0x91d9(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4ee6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4eeb:	48 89 14 24          	mov    %rdx,(%rsp)
    4eef:	e8 ac e4 ff ff       	call   33a0 <getenv@plt>
    4ef4:	48 8b 14 24          	mov    (%rsp),%rdx
    4ef8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4efd:	48 85 c0             	test   %rax,%rax
    4f00:	74 09                	je     4f0b <fwp_tape_buffers_release+0x7b>
    4f02:	80 38 30             	cmpb   $0x30,(%rax)
    4f05:	0f 84 9d 00 00 00    	je     4fa8 <fwp_tape_buffers_release+0x118>
    4f0b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4f0f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4f13:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4f1a:	77 78                	ja     4f94 <fwp_tape_buffers_release+0x104>
    4f1c:	48 8d 3d 9d d1 01 00 	lea    0x1d19d(%rip),%rdi        # 220c0 <fwp_tape_workspace>
    4f23:	48 89 04 24          	mov    %rax,(%rsp)
    4f27:	e8 44 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4f2c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4f30:	48 8b 04 24          	mov    (%rsp),%rax
    4f34:	0f 29 05 85 d1 01 00 	movaps %xmm0,0x1d185(%rip)        # 220c0 <fwp_tape_workspace>
    4f3b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4f40:	48 89 05 61 d1 01 00 	mov    %rax,0x1d161(%rip)        # 220a8 <fwp_tape_cached_bytes>
    4f47:	0f 29 05 82 d1 01 00 	movaps %xmm0,0x1d182(%rip)        # 220d0 <fwp_tape_workspace+0x10>
    4f4e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4f53:	0f 29 05 86 d1 01 00 	movaps %xmm0,0x1d186(%rip)        # 220e0 <fwp_tape_workspace+0x20>
    4f5a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4f5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f62:	48 89 15 87 d1 01 00 	mov    %rdx,0x1d187(%rip)        # 220f0 <fwp_tape_workspace+0x30>
    4f69:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f70:	00 
    4f71:	0f 11 03             	movups %xmm0,(%rbx)
    4f74:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f78:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f7c:	48 83 c4 10          	add    $0x10,%rsp
    4f80:	5b                   	pop    %rbx
    4f81:	c3                   	ret
    4f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f88:	48 8d 3d 30 91 00 00 	lea    0x9130(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4f8f:	e8 0c e4 ff ff       	call   33a0 <getenv@plt>
    4f94:	48 83 c4 10          	add    $0x10,%rsp
    4f98:	48 89 df             	mov    %rbx,%rdi
    4f9b:	5b                   	pop    %rbx
    4f9c:	e9 cf ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4fac:	0f 85 59 ff ff ff    	jne    4f0b <fwp_tape_buffers_release+0x7b>
    4fb2:	48 83 c4 10          	add    $0x10,%rsp
    4fb6:	48 89 df             	mov    %rbx,%rdi
    4fb9:	5b                   	pop    %rbx
    4fba:	e9 b1 ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fbf:	90                   	nop

0000000000004fc0 <fwp_poll_events>:
    4fc0:	53                   	push   %rbx
    4fc1:	48 83 ec 20          	sub    $0x20,%rsp
    4fc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4fcc:	00 00 
    4fce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4fd3:	31 c0                	xor    %eax,%eax
    4fd5:	e8 36 f3 ff ff       	call   4310 <fwp_now_ns>
    4fda:	48 8b 1d 57 d7 01 00 	mov    0x1d757(%rip),%rbx        # 22738 <fwp_timers>
    4fe1:	48 85 db             	test   %rbx,%rbx
    4fe4:	0f 84 d6 00 00 00    	je     50c0 <fwp_poll_events+0x100>
    4fea:	48 89 c6             	mov    %rax,%rsi
    4fed:	48 89 da             	mov    %rbx,%rdx
    4ff0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4ff7:	eb 16                	jmp    500f <fwp_poll_events+0x4f>
    4ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5000:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5007:	48 89 c8             	mov    %rcx,%rax
    500a:	48 85 d2             	test   %rdx,%rdx
    500d:	74 31                	je     5040 <fwp_poll_events+0x80>
    500f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5013:	48 85 c0             	test   %rax,%rax
    5016:	78 e8                	js     5000 <fwp_poll_events+0x40>
    5018:	48 39 c1             	cmp    %rax,%rcx
    501b:	7c e3                	jl     5000 <fwp_poll_events+0x40>
    501d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5024:	48 85 d2             	test   %rdx,%rdx
    5027:	74 1c                	je     5045 <fwp_poll_events+0x85>
    5029:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    502d:	48 39 c1             	cmp    %rax,%rcx
    5030:	7c ce                	jl     5000 <fwp_poll_events+0x40>
    5032:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5039:	48 85 d2             	test   %rdx,%rdx
    503c:	75 d1                	jne    500f <fwp_poll_events+0x4f>
    503e:	66 90                	xchg   %ax,%ax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	78 7b                	js     50c0 <fwp_poll_events+0x100>
    5045:	48 29 f0             	sub    %rsi,%rax
    5048:	48 89 c1             	mov    %rax,%rcx
    504b:	48 85 c0             	test   %rax,%rax
    504e:	0f 8e 9c 00 00 00    	jle    50f0 <fwp_poll_events+0x130>
    5054:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    505b:	de 1b 43 
    505e:	48 f7 ea             	imul   %rdx
    5061:	48 89 c8             	mov    %rcx,%rax
    5064:	48 c1 f8 3f          	sar    $0x3f,%rax
    5068:	48 c1 fa 12          	sar    $0x12,%rdx
    506c:	48 29 c2             	sub    %rax,%rdx
    506f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5076:	48 39 c1             	cmp    %rax,%rcx
    5079:	0f 95 c0             	setne  %al
    507c:	0f b6 c0             	movzbl %al,%eax
    507f:	48 01 d0             	add    %rdx,%rax
    5082:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5088:	0f 8f 32 01 00 00    	jg     51c0 <fwp_poll_events+0x200>
    508e:	48 85 c0             	test   %rax,%rax
    5091:	74 5d                	je     50f0 <fwp_poll_events+0x130>
    5093:	89 c1                	mov    %eax,%ecx
    5095:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    509c:	48 c1 e9 26          	shr    $0x26,%rcx
    50a0:	48 63 d1             	movslq %ecx,%rdx
    50a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    50a9:	29 c8                	sub    %ecx,%eax
    50ab:	48 98                	cltq
    50ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    50b4:	e9 11 01 00 00       	jmp    51ca <fwp_poll_events+0x20a>
    50b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c0:	e8 ab eb ff ff       	call   3c70 <fwp_flush>
    50c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    50ca:	be 01 00 00 00       	mov    $0x1,%esi
    50cf:	48 8b 0d 6a cf 00 00 	mov    0xcf6a(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    50d6:	48 8d 3d 6b 96 00 00 	lea    0x966b(%rip),%rdi        # e748 <_IO_stdin_used+0x748>
    50dd:	e8 9e e5 ff ff       	call   3680 <fwrite@plt>
    50e2:	bf 65 00 00 00       	mov    $0x65,%edi
    50e7:	e8 84 e5 ff ff       	call   3670 <exit@plt>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	e8 1b f2 ff ff       	call   4310 <fwp_now_ns>
    50f5:	48 89 c1             	mov    %rax,%rcx
    50f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fc:	eb 44                	jmp    5142 <fwp_poll_events+0x182>
    50fe:	66 90                	xchg   %ax,%ax
    5100:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5104:	75 33                	jne    5139 <fwp_poll_events+0x179>
    5106:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510a:	75 2d                	jne    5139 <fwp_poll_events+0x179>
    510c:	48 8b 05 2d d6 01 00 	mov    0x1d62d(%rip),%rax        # 22740 <fwp_ready_tail>
    5113:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5117:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    511e:	00 00 00 00 
    5122:	48 85 c0             	test   %rax,%rax
    5125:	0f 84 05 01 00 00    	je     5230 <fwp_poll_events+0x270>
    512b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5132:	48 89 15 07 d6 01 00 	mov    %rdx,0x1d607(%rip)        # 22740 <fwp_ready_tail>
    5139:	48 85 db             	test   %rbx,%rbx
    513c:	0f 84 be 00 00 00    	je     5200 <fwp_poll_events+0x240>
    5142:	48 89 da             	mov    %rbx,%rdx
    5145:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    514c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5150:	7f e7                	jg     5139 <fwp_poll_events+0x179>
    5152:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5156:	74 2e                	je     5186 <fwp_poll_events+0x1c6>
    5158:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    515f:	48 85 c0             	test   %rax,%rax
    5162:	0f 84 b8 00 00 00    	je     5220 <fwp_poll_events+0x260>
    5168:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    516f:	48 85 db             	test   %rbx,%rbx
    5172:	74 07                	je     517b <fwp_poll_events+0x1bb>
    5174:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    517b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    517f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5186:	48 8b 42 60          	mov    0x60(%rdx),%rax
    518a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    518e:	48 85 c0             	test   %rax,%rax
    5191:	0f 84 69 ff ff ff    	je     5100 <fwp_poll_events+0x140>
    5197:	48 39 c8             	cmp    %rcx,%rax
    519a:	0f 8f 60 ff ff ff    	jg     5100 <fwp_poll_events+0x140>
    51a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    51a4:	0f 85 56 ff ff ff    	jne    5100 <fwp_poll_events+0x140>
    51aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    51ae:	75 89                	jne    5139 <fwp_poll_events+0x179>
    51b0:	48 89 d7             	mov    %rdx,%rdi
    51b3:	e8 f8 ee ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    51b8:	e9 43 ff ff ff       	jmp    5100 <fwp_poll_events+0x140>
    51bd:	0f 1f 00             	nopl   (%rax)
    51c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    51c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    51ca:	48 89 e7             	mov    %rsp,%rdi
    51cd:	31 f6                	xor    %esi,%esi
    51cf:	48 89 14 24          	mov    %rdx,(%rsp)
    51d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    51d8:	e8 c3 e2 ff ff       	call   34a0 <nanosleep@plt>
    51dd:	48 8b 1d 54 d5 01 00 	mov    0x1d554(%rip),%rbx        # 22738 <fwp_timers>
    51e4:	e8 27 f1 ff ff       	call   4310 <fwp_now_ns>
    51e9:	48 89 c1             	mov    %rax,%rcx
    51ec:	48 85 db             	test   %rbx,%rbx
    51ef:	0f 85 03 ff ff ff    	jne    50f8 <fwp_poll_events+0x138>
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5205:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    520c:	00 00 
    520e:	75 2c                	jne    523c <fwp_poll_events+0x27c>
    5210:	48 83 c4 20          	add    $0x20,%rsp
    5214:	5b                   	pop    %rbx
    5215:	c3                   	ret
    5216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    521d:	00 00 00 
    5220:	48 89 1d 11 d5 01 00 	mov    %rbx,0x1d511(%rip)        # 22738 <fwp_timers>
    5227:	e9 43 ff ff ff       	jmp    516f <fwp_poll_events+0x1af>
    522c:	0f 1f 40 00          	nopl   0x0(%rax)
    5230:	48 89 15 11 d5 01 00 	mov    %rdx,0x1d511(%rip)        # 22748 <fwp_ready_head>
    5237:	e9 f6 fe ff ff       	jmp    5132 <fwp_poll_events+0x172>
    523c:	e8 1f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    5241:	0f 1f 40 00          	nopl   0x0(%rax)
    5245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    524c:	00 00 00 00 

0000000000005250 <fwp_rc_wide_dup>:
    5250:	48 89 fa             	mov    %rdi,%rdx
    5253:	48 8d 35 26 d5 01 00 	lea    0x1d526(%rip),%rsi        # 22780 <fwp_heap>
    525a:	48 83 ec 18          	sub    $0x18,%rsp
    525e:	48 89 f9             	mov    %rdi,%rcx
    5261:	48 c1 ea 11          	shr    $0x11,%rdx
    5265:	48 31 fa             	xor    %rdi,%rdx
    5268:	48 89 d0             	mov    %rdx,%rax
    526b:	48 c1 e8 09          	shr    $0x9,%rax
    526f:	48 31 c2             	xor    %rax,%rdx
    5272:	0f b6 d2             	movzbl %dl,%edx
    5275:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    527c:	00 
    527d:	49 8b 00             	mov    (%r8),%rax
    5280:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5287:	00 00 
    5289:	75 21                	jne    52ac <fwp_rc_wide_dup+0x5c>
    528b:	e9 98 00 00 00       	jmp    5328 <fwp_rc_wide_dup+0xd8>
    5290:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    529c:	00 00 00 00 
    52a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    52a4:	48 85 d2             	test   %rdx,%rdx
    52a7:	74 2f                	je     52d8 <fwp_rc_wide_dup+0x88>
    52a9:	48 89 d0             	mov    %rdx,%rax
    52ac:	48 3b 08             	cmp    (%rax),%rcx
    52af:	75 ef                	jne    52a0 <fwp_rc_wide_dup+0x50>
    52b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52b4:	74 7c                	je     5332 <fwp_rc_wide_dup+0xe2>
    52b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    52ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    52be:	0f 84 91 00 00 00    	je     5355 <fwp_rc_wide_dup+0x105>
    52c4:	48 83 c2 01          	add    $0x1,%rdx
    52c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    52cc:	48 83 c4 18          	add    $0x18,%rsp
    52d0:	c3                   	ret
    52d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    52dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52df:	75 68                	jne    5349 <fwp_rc_wide_dup+0xf9>
    52e1:	bf 18 00 00 00       	mov    $0x18,%edi
    52e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52eb:	4c 89 04 24          	mov    %r8,(%rsp)
    52ef:	e8 bc e2 ff ff       	call   35b0 <malloc@plt>
    52f4:	4c 8b 04 24          	mov    (%rsp),%r8
    52f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52fd:	48 85 c0             	test   %rax,%rax
    5300:	74 5f                	je     5361 <fwp_rc_wide_dup+0x111>
    5302:	48 89 08             	mov    %rcx,(%rax)
    5305:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    530c:	00 
    530d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5314:	00 
    5315:	49 89 00             	mov    %rax,(%r8)
    5318:	c6 01 ff             	movb   $0xff,(%rcx)
    531b:	48 83 05 a5 f0 01 00 	addq   $0x1,0x1f0a5(%rip)        # 243c8 <fwp_heap+0x1c48>
    5322:	01 
    5323:	48 83 c4 18          	add    $0x18,%rsp
    5327:	c3                   	ret
    5328:	80 3f fe             	cmpb   $0xfe,(%rdi)
    532b:	75 13                	jne    5340 <fwp_rc_wide_dup+0xf0>
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 af                	je     52e1 <fwp_rc_wide_dup+0x91>
    5332:	48 8d 3d 3f 94 00 00 	lea    0x943f(%rip),%rdi        # e778 <_IO_stdin_used+0x778>
    5339:	e8 62 ee ff ff       	call   41a0 <fwp_trap>
    533e:	66 90                	xchg   %ax,%ax
    5340:	48 85 c0             	test   %rax,%rax
    5343:	0f 85 6d ff ff ff    	jne    52b6 <fwp_rc_wide_dup+0x66>
    5349:	48 8d 3d 50 94 00 00 	lea    0x9450(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    5350:	e8 4b ee ff ff       	call   41a0 <fwp_trap>
    5355:	48 8d 3d 74 8d 00 00 	lea    0x8d74(%rip),%rdi        # e0d0 <_IO_stdin_used+0xd0>
    535c:	e8 3f ee ff ff       	call   41a0 <fwp_trap>
    5361:	e8 4a e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    536d:	00 00 00 

0000000000005370 <fwp_rc_forget_slot>:
    5370:	80 3f ff             	cmpb   $0xff,(%rdi)
    5373:	74 0b                	je     5380 <fwp_rc_forget_slot+0x10>
    5375:	c3                   	ret
    5376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    537d:	00 00 00 
    5380:	48 89 f8             	mov    %rdi,%rax
    5383:	48 83 ec 08          	sub    $0x8,%rsp
    5387:	48 89 fa             	mov    %rdi,%rdx
    538a:	48 c1 e8 11          	shr    $0x11,%rax
    538e:	48 31 f8             	xor    %rdi,%rax
    5391:	48 89 c1             	mov    %rax,%rcx
    5394:	48 c1 e9 09          	shr    $0x9,%rcx
    5398:	48 31 c8             	xor    %rcx,%rax
    539b:	48 8d 0d de d3 01 00 	lea    0x1d3de(%rip),%rcx        # 22780 <fwp_heap>
    53a2:	0f b6 c0             	movzbl %al,%eax
    53a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    53ac:	00 
    53ad:	48 85 ff             	test   %rdi,%rdi
    53b0:	74 3c                	je     53ee <fwp_rc_forget_slot+0x7e>
    53b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    53b9:	00 
    53ba:	48 8b 01             	mov    (%rcx),%rax
    53bd:	eb 11                	jmp    53d0 <fwp_rc_forget_slot+0x60>
    53bf:	90                   	nop
    53c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    53c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    53c8:	48 85 ff             	test   %rdi,%rdi
    53cb:	74 21                	je     53ee <fwp_rc_forget_slot+0x7e>
    53cd:	48 89 f8             	mov    %rdi,%rax
    53d0:	48 3b 10             	cmp    (%rax),%rdx
    53d3:	75 eb                	jne    53c0 <fwp_rc_forget_slot+0x50>
    53d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    53d9:	48 89 01             	mov    %rax,(%rcx)
    53dc:	e8 df df ff ff       	call   33c0 <free@plt>
    53e1:	48 83 2d df ef 01 00 	subq   $0x1,0x1efdf(%rip)        # 243c8 <fwp_heap+0x1c48>
    53e8:	01 
    53e9:	48 83 c4 08          	add    $0x8,%rsp
    53ed:	c3                   	ret
    53ee:	48 8d 3d ab 93 00 00 	lea    0x93ab(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    53f5:	e8 a6 ed ff ff       	call   41a0 <fwp_trap>
    53fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005400 <fwp_rc_prepare_chunk>:
    5400:	48 83 3d c0 ef 01 00 	cmpq   $0x0,0x1efc0(%rip)        # 243c8 <fwp_heap+0x1c48>
    5407:	00 
    5408:	41 54                	push   %r12
    540a:	49 89 f4             	mov    %rsi,%r12
    540d:	55                   	push   %rbp
    540e:	48 89 fd             	mov    %rdi,%rbp
    5411:	53                   	push   %rbx
    5412:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5415:	0f 84 7d 00 00 00    	je     5498 <fwp_rc_prepare_chunk+0x98>
    541b:	31 db                	xor    %ebx,%ebx
    541d:	85 c0                	test   %eax,%eax
    541f:	75 5f                	jne    5480 <fwp_rc_prepare_chunk+0x80>
    5421:	48 85 f6             	test   %rsi,%rsi
    5424:	74 7c                	je     54a2 <fwp_rc_prepare_chunk+0xa2>
    5426:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    542a:	e8 91 df ff ff       	call   33c0 <free@plt>
    542f:	90                   	nop
    5430:	be 01 00 00 00       	mov    $0x1,%esi
    5435:	4c 89 e7             	mov    %r12,%rdi
    5438:	e8 e3 e0 ff ff       	call   3520 <calloc@plt>
    543d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5441:	48 85 c0             	test   %rax,%rax
    5444:	0f 85 87 00 00 00    	jne    54d1 <fwp_rc_prepare_chunk+0xd1>
    544a:	e8 61 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    544f:	90                   	nop
    5450:	e8 1b ff ff ff       	call   5370 <fwp_rc_forget_slot>
    5455:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5458:	48 83 c3 01          	add    $0x1,%rbx
    545c:	48 39 c3             	cmp    %rax,%rbx
    545f:	73 37                	jae    5498 <fwp_rc_prepare_chunk+0x98>
    5461:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5468:	00 00 
    546a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5471:	00 00 00 00 
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5484:	48 01 df             	add    %rbx,%rdi
    5487:	80 3f ff             	cmpb   $0xff,(%rdi)
    548a:	74 c4                	je     5450 <fwp_rc_prepare_chunk+0x50>
    548c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    548f:	48 83 c3 01          	add    $0x1,%rbx
    5493:	48 39 c3             	cmp    %rax,%rbx
    5496:	72 e8                	jb     5480 <fwp_rc_prepare_chunk+0x80>
    5498:	49 39 c4             	cmp    %rax,%r12
    549b:	75 13                	jne    54b0 <fwp_rc_prepare_chunk+0xb0>
    549d:	4d 85 e4             	test   %r12,%r12
    54a0:	75 46                	jne    54e8 <fwp_rc_prepare_chunk+0xe8>
    54a2:	5b                   	pop    %rbx
    54a3:	5d                   	pop    %rbp
    54a4:	41 5c                	pop    %r12
    54a6:	c3                   	ret
    54a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ae:	00 00 
    54b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54b4:	48 29 05 15 ef 01 00 	sub    %rax,0x1ef15(%rip)        # 243d0 <fwp_heap+0x1c50>
    54bb:	e8 00 df ff ff       	call   33c0 <free@plt>
    54c0:	4d 85 e4             	test   %r12,%r12
    54c3:	0f 85 67 ff ff ff    	jne    5430 <fwp_rc_prepare_chunk+0x30>
    54c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    54d0:	00 
    54d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    54d5:	5b                   	pop    %rbx
    54d6:	4c 01 25 f3 ee 01 00 	add    %r12,0x1eef3(%rip)        # 243d0 <fwp_heap+0x1c50>
    54dd:	5d                   	pop    %rbp
    54de:	41 5c                	pop    %r12
    54e0:	c3                   	ret
    54e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54ec:	5b                   	pop    %rbx
    54ed:	4c 89 e2             	mov    %r12,%rdx
    54f0:	31 f6                	xor    %esi,%esi
    54f2:	5d                   	pop    %rbp
    54f3:	41 5c                	pop    %r12
    54f5:	e9 c6 df ff ff       	jmp    34c0 <memset@plt>
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005500 <fwp_heap_refill>:
    5500:	41 56                	push   %r14
    5502:	41 89 d6             	mov    %edx,%r14d
    5505:	41 55                	push   %r13
    5507:	41 89 f5             	mov    %esi,%r13d
    550a:	41 54                	push   %r12
    550c:	49 89 fc             	mov    %rdi,%r12
    550f:	bf 01 00 00 00       	mov    $0x1,%edi
    5514:	55                   	push   %rbp
    5515:	53                   	push   %rbx
    5516:	e8 c5 e8 ff ff       	call   3de0 <fwp_heap_chunks>
    551b:	48 89 c3             	mov    %rax,%rbx
    551e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5522:	48 8b 05 4f e6 01 00 	mov    0x1e64f(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    5529:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    552d:	48 8d 05 4c d2 01 00 	lea    0x1d24c(%rip),%rax        # 22780 <fwp_heap>
    5534:	31 d2                	xor    %edx,%edx
    5536:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    553a:	48 89 ef             	mov    %rbp,%rdi
    553d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5541:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5545:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    554c:	00 
    554d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5552:	f7 f1                	div    %ecx
    5554:	31 d2                	xor    %edx,%edx
    5556:	66 0f 6e c1          	movd   %ecx,%xmm0
    555a:	66 0f 6e c8          	movd   %eax,%xmm1
    555e:	89 c6                	mov    %eax,%esi
    5560:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5565:	48 01 c8             	add    %rcx,%rax
    5568:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    556c:	48 f7 f1             	div    %rcx
    556f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5574:	89 45 18             	mov    %eax,0x18(%rbp)
    5577:	e8 84 fe ff ff       	call   5400 <fwp_rc_prepare_chunk>
    557c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    557f:	48 89 d8             	mov    %rbx,%rax
    5582:	48 c1 e0 10          	shl    $0x10,%rax
    5586:	48 03 05 a3 e5 01 00 	add    0x1e5a3(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    558d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5591:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5596:	8b 55 08             	mov    0x8(%rbp),%edx
    5599:	48 0f af d1          	imul   %rcx,%rdx
    559d:	48 01 c2             	add    %rax,%rdx
    55a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    55a5:	5b                   	pop    %rbx
    55a6:	5d                   	pop    %rbp
    55a7:	41 5c                	pop    %r12
    55a9:	41 5d                	pop    %r13
    55ab:	41 5e                	pop    %r14
    55ad:	c3                   	ret
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_mem_free>:
    55b0:	48 85 ff             	test   %rdi,%rdi
    55b3:	0f 84 17 02 00 00    	je     57d0 <fwp_mem_free+0x220>
    55b9:	48 8b 35 70 e5 01 00 	mov    0x1e570(%rip),%rsi        # 23b30 <fwp_heap+0x13b0>
    55c0:	48 8b 05 91 e5 01 00 	mov    0x1e591(%rip),%rax        # 23b58 <fwp_heap+0x13d8>
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 29 f2             	sub    %rsi,%rdx
    55cd:	48 c1 e0 10          	shl    $0x10,%rax
    55d1:	48 39 c2             	cmp    %rax,%rdx
    55d4:	0f 83 f6 01 00 00    	jae    57d0 <fwp_mem_free+0x220>
    55da:	49 89 d1             	mov    %rdx,%r9
    55dd:	49 c1 e9 10          	shr    $0x10,%r9
    55e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    55e5:	48 c1 e0 03          	shl    $0x3,%rax
    55e9:	49 89 c0             	mov    %rax,%r8
    55ec:	4c 03 05 85 e5 01 00 	add    0x1e585(%rip),%r8        # 23b78 <fwp_heap+0x13f8>
    55f3:	0f 84 d7 01 00 00    	je     57d0 <fwp_mem_free+0x220>
    55f9:	48 83 ec 38          	sub    $0x38,%rsp
    55fd:	48 89 f9             	mov    %rdi,%rcx
    5600:	41 0f b6 38          	movzbl (%r8),%edi
    5604:	40 80 ff 01          	cmp    $0x1,%dil
    5608:	74 16                	je     5620 <fwp_mem_free+0x70>
    560a:	40 80 ff 02          	cmp    $0x2,%dil
    560e:	0f 84 94 00 00 00    	je     56a8 <fwp_mem_free+0xf8>
    5614:	48 83 c4 38          	add    $0x38,%rsp
    5618:	c3                   	ret
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5624:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5629:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    562e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5632:	4d 85 d2             	test   %r10,%r10
    5635:	74 1d                	je     5654 <fwp_mem_free+0xa4>
    5637:	0f b7 c1             	movzwl %cx,%eax
    563a:	31 d2                	xor    %edx,%edx
    563c:	48 f7 f7             	div    %rdi
    563f:	49 01 c2             	add    %rax,%r10
    5642:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5646:	0f 84 44 01 00 00    	je     5790 <fwp_mem_free+0x1e0>
    564c:	41 c6 02 00          	movb   $0x0,(%r10)
    5650:	41 8b 78 04          	mov    0x4(%r8),%edi
    5654:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    565b:	49 63 c1             	movslq %r9d,%rax
    565e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5662:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5666:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    566b:	f2 0f 58 05 4d e5 01 	addsd  0x1e54d(%rip),%xmm0        # 23bc0 <fwp_heap+0x1440>
    5672:	00 
    5673:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5677:	48 8d 05 02 d1 01 00 	lea    0x1d102(%rip),%rax        # 22780 <fwp_heap>
    567e:	48 01 d0             	add    %rdx,%rax
    5681:	48 8b 10             	mov    (%rax),%rdx
    5684:	48 f7 d2             	not    %rdx
    5687:	48 89 11             	mov    %rdx,(%rcx)
    568a:	48 89 08             	mov    %rcx,(%rax)
    568d:	48 29 3d 0c e5 01 00 	sub    %rdi,0x1e50c(%rip)        # 23ba0 <fwp_heap+0x1420>
    5694:	f2 0f 11 05 24 e5 01 	movsd  %xmm0,0x1e524(%rip)        # 23bc0 <fwp_heap+0x1440>
    569b:	00 
    569c:	48 83 c4 38          	add    $0x38,%rsp
    56a0:	c3                   	ret
    56a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56a8:	66 31 d2             	xor    %dx,%dx
    56ab:	48 01 d6             	add    %rdx,%rsi
    56ae:	48 39 f1             	cmp    %rsi,%rcx
    56b1:	0f 85 5d ff ff ff    	jne    5614 <fwp_mem_free+0x64>
    56b7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    56bb:	48 29 15 de e4 01 00 	sub    %rdx,0x1e4de(%rip)        # 23ba0 <fwp_heap+0x1420>
    56c2:	48 85 d2             	test   %rdx,%rdx
    56c5:	0f 88 a5 00 00 00    	js     5770 <fwp_mem_free+0x1c0>
    56cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56cf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    56d4:	f2 0f 58 05 e4 e4 01 	addsd  0x1e4e4(%rip),%xmm0        # 23bc0 <fwp_heap+0x1440>
    56db:	00 
    56dc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    56e0:	f2 0f 11 05 d8 e4 01 	movsd  %xmm0,0x1e4d8(%rip)        # 23bc0 <fwp_heap+0x1440>
    56e7:	00 
    56e8:	48 85 d2             	test   %rdx,%rdx
    56eb:	74 0c                	je     56f9 <fwp_mem_free+0x149>
    56ed:	80 3a ff             	cmpb   $0xff,(%rdx)
    56f0:	0f 84 db 00 00 00    	je     57d1 <fwp_mem_free+0x221>
    56f6:	c6 02 00             	movb   $0x0,(%rdx)
    56f9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    56fd:	48 85 c9             	test   %rcx,%rcx
    5700:	74 3e                	je     5740 <fwp_mem_free+0x190>
    5702:	48 8b 15 6f e4 01 00 	mov    0x1e46f(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    5709:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    570d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5711:	48 01 d0             	add    %rdx,%rax
    5714:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5718:	48 89 d6             	mov    %rdx,%rsi
    571b:	48 29 c6             	sub    %rax,%rsi
    571e:	83 e6 08             	and    $0x8,%esi
    5721:	74 0d                	je     5730 <fwp_mem_free+0x180>
    5723:	c6 00 00             	movb   $0x0,(%rax)
    5726:	48 83 c0 28          	add    $0x28,%rax
    572a:	48 39 c2             	cmp    %rax,%rdx
    572d:	74 11                	je     5740 <fwp_mem_free+0x190>
    572f:	90                   	nop
    5730:	c6 00 00             	movb   $0x0,(%rax)
    5733:	48 83 c0 50          	add    $0x50,%rax
    5737:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    573b:	48 39 c2             	cmp    %rax,%rdx
    573e:	75 f0                	jne    5730 <fwp_mem_free+0x180>
    5740:	48 01 0d 69 e4 01 00 	add    %rcx,0x1e469(%rip)        # 23bb0 <fwp_heap+0x1430>
    5747:	4c 3b 0d 22 e4 01 00 	cmp    0x1e422(%rip),%r9        # 23b70 <fwp_heap+0x13f0>
    574e:	73 07                	jae    5757 <fwp_mem_free+0x1a7>
    5750:	4c 89 0d 19 e4 01 00 	mov    %r9,0x1e419(%rip)        # 23b70 <fwp_heap+0x13f0>
    5757:	4c 3b 0d 0a e4 01 00 	cmp    0x1e40a(%rip),%r9        # 23b68 <fwp_heap+0x13e8>
    575e:	0f 83 b0 fe ff ff    	jae    5614 <fwp_mem_free+0x64>
    5764:	4c 89 0d fd e3 01 00 	mov    %r9,0x1e3fd(%rip)        # 23b68 <fwp_heap+0x13e8>
    576b:	e9 a4 fe ff ff       	jmp    5614 <fwp_mem_free+0x64>
    5770:	48 89 d1             	mov    %rdx,%rcx
    5773:	83 e2 01             	and    $0x1,%edx
    5776:	66 0f ef c0          	pxor   %xmm0,%xmm0
    577a:	48 d1 e9             	shr    $1,%rcx
    577d:	48 09 d1             	or     %rdx,%rcx
    5780:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5785:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5789:	e9 46 ff ff ff       	jmp    56d4 <fwp_mem_free+0x124>
    578e:	66 90                	xchg   %ax,%ax
    5790:	4c 89 d7             	mov    %r10,%rdi
    5793:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5798:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    579d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    57a2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    57a6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    57ab:	e8 c0 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57b0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    57b5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    57ba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    57bf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    57c4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    57c9:	e9 7e fe ff ff       	jmp    564c <fwp_mem_free+0x9c>
    57ce:	66 90                	xchg   %ax,%ax
    57d0:	c3                   	ret
    57d1:	48 89 d7             	mov    %rdx,%rdi
    57d4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    57d9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    57de:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    57e3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    57e8:	e8 83 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57ed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    57f2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    57f7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    57fc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5801:	e9 f0 fe ff ff       	jmp    56f6 <fwp_mem_free+0x146>
    5806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    580d:	00 00 00 

0000000000005810 <fwp_heap_alloc_big>:
    5810:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5817:	00 00 40 
    581a:	41 57                	push   %r15
    581c:	41 56                	push   %r14
    581e:	41 55                	push   %r13
    5820:	41 54                	push   %r12
    5822:	55                   	push   %rbp
    5823:	53                   	push   %rbx
    5824:	48 83 ec 08          	sub    $0x8,%rsp
    5828:	48 39 f8             	cmp    %rdi,%rax
    582b:	0f 82 fa 00 00 00    	jb     592b <fwp_heap_alloc_big+0x11b>
    5831:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5838:	49 89 fd             	mov    %rdi,%r13
    583b:	41 89 f6             	mov    %esi,%r14d
    583e:	48 c1 ed 10          	shr    $0x10,%rbp
    5842:	48 89 ef             	mov    %rbp,%rdi
    5845:	e8 96 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    584a:	be 01 00 00 00       	mov    $0x1,%esi
    584f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5853:	49 89 c4             	mov    %rax,%r12
    5856:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    585d:	00 
    585e:	48 03 3d 13 e3 01 00 	add    0x1e313(%rip),%rdi        # 23b78 <fwp_heap+0x13f8>
    5865:	c6 07 02             	movb   $0x2,(%rdi)
    5868:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    586c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    586f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5873:	e8 88 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    5878:	48 83 fd 01          	cmp    $0x1,%rbp
    587c:	76 47                	jbe    58c5 <fwp_heap_alloc_big+0xb5>
    587e:	4c 01 e5             	add    %r12,%rbp
    5881:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5888:	00 
    5889:	4c 8d 3d f0 ce 01 00 	lea    0x1cef0(%rip),%r15        # 22780 <fwp_heap>
    5890:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5895:	49 c1 e6 03          	shl    $0x3,%r14
    5899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58a0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    58a7:	31 f6                	xor    %esi,%esi
    58a9:	48 01 dd             	add    %rbx,%rbp
    58ac:	48 83 c3 28          	add    $0x28,%rbx
    58b0:	48 89 ef             	mov    %rbp,%rdi
    58b3:	e8 48 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    58b8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    58bc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    58c0:	49 39 de             	cmp    %rbx,%r14
    58c3:	75 db                	jne    58a0 <fwp_heap_alloc_big+0x90>
    58c5:	49 c1 e4 10          	shl    $0x10,%r12
    58c9:	4c 03 25 60 e2 01 00 	add    0x1e260(%rip),%r12        # 23b30 <fwp_heap+0x13b0>
    58d0:	4c 89 ea             	mov    %r13,%rdx
    58d3:	31 f6                	xor    %esi,%esi
    58d5:	4c 89 e7             	mov    %r12,%rdi
    58d8:	e8 e3 db ff ff       	call   34c0 <memset@plt>
    58dd:	4c 89 e8             	mov    %r13,%rax
    58e0:	48 03 05 b9 e2 01 00 	add    0x1e2b9(%rip),%rax        # 23ba0 <fwp_heap+0x1420>
    58e7:	72 42                	jb     592b <fwp_heap_alloc_big+0x11b>
    58e9:	48 39 05 b8 e2 01 00 	cmp    %rax,0x1e2b8(%rip)        # 23ba8 <fwp_heap+0x1428>
    58f0:	48 89 05 a9 e2 01 00 	mov    %rax,0x1e2a9(%rip)        # 23ba0 <fwp_heap+0x1420>
    58f7:	73 07                	jae    5900 <fwp_heap_alloc_big+0xf0>
    58f9:	48 89 05 a8 e2 01 00 	mov    %rax,0x1e2a8(%rip)        # 23ba8 <fwp_heap+0x1428>
    5900:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5904:	4c 89 e0             	mov    %r12,%rax
    5907:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    590c:	f2 0f 58 05 a4 e2 01 	addsd  0x1e2a4(%rip),%xmm0        # 23bb8 <fwp_heap+0x1438>
    5913:	00 
    5914:	f2 0f 11 05 9c e2 01 	movsd  %xmm0,0x1e29c(%rip)        # 23bb8 <fwp_heap+0x1438>
    591b:	00 
    591c:	48 83 c4 08          	add    $0x8,%rsp
    5920:	5b                   	pop    %rbx
    5921:	5d                   	pop    %rbp
    5922:	41 5c                	pop    %r12
    5924:	41 5d                	pop    %r13
    5926:	41 5e                	pop    %r14
    5928:	41 5f                	pop    %r15
    592a:	c3                   	ret
    592b:	e8 80 e3 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005930 <fwp_heap_alloc_slow>:
    5930:	53                   	push   %rbx
    5931:	48 89 f9             	mov    %rdi,%rcx
    5934:	41 89 f1             	mov    %esi,%r9d
    5937:	48 83 ec 10          	sub    $0x10,%rsp
    593b:	8b 05 e3 e1 01 00    	mov    0x1e1e3(%rip),%eax        # 23b24 <fwp_heap+0x13a4>
    5941:	85 c0                	test   %eax,%eax
    5943:	0f 84 c7 00 00 00    	je     5a10 <fwp_heap_alloc_slow+0xe0>
    5949:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5950:	0f 87 dd 00 00 00    	ja     5a33 <fwp_heap_alloc_slow+0x103>
    5956:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    595a:	48 8d 3d 1f ce 01 00 	lea    0x1ce1f(%rip),%rdi        # 22780 <fwp_heap>
    5961:	49 63 f1             	movslq %r9d,%rsi
    5964:	48 c1 e8 04          	shr    $0x4,%rax
    5968:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    596f:	00 00 
    5971:	41 0f b6 c2          	movzbl %r10b,%eax
    5975:	4c 89 d2             	mov    %r10,%rdx
    5978:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    597c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5983:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    598a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    598e:	48 01 f8             	add    %rdi,%rax
    5991:	4c 8b 00             	mov    (%rax),%r8
    5994:	4d 85 c0             	test   %r8,%r8
    5997:	0f 84 ab 00 00 00    	je     5a48 <fwp_heap_alloc_slow+0x118>
    599d:	49 8b 10             	mov    (%r8),%rdx
    59a0:	48 f7 d2             	not    %rdx
    59a3:	48 89 10             	mov    %rdx,(%rax)
    59a6:	41 83 f9 01          	cmp    $0x1,%r9d
    59aa:	4c 89 c7             	mov    %r8,%rdi
    59ad:	48 0f 45 cb          	cmovne %rbx,%rcx
    59b1:	31 f6                	xor    %esi,%esi
    59b3:	48 89 ca             	mov    %rcx,%rdx
    59b6:	e8 05 db ff ff       	call   34c0 <memset@plt>
    59bb:	49 89 c0             	mov    %rax,%r8
    59be:	48 89 d8             	mov    %rbx,%rax
    59c1:	48 03 05 d8 e1 01 00 	add    0x1e1d8(%rip),%rax        # 23ba0 <fwp_heap+0x1420>
    59c8:	0f 82 d9 00 00 00    	jb     5aa7 <fwp_heap_alloc_slow+0x177>
    59ce:	48 39 05 d3 e1 01 00 	cmp    %rax,0x1e1d3(%rip)        # 23ba8 <fwp_heap+0x1428>
    59d5:	48 89 05 c4 e1 01 00 	mov    %rax,0x1e1c4(%rip)        # 23ba0 <fwp_heap+0x1420>
    59dc:	73 07                	jae    59e5 <fwp_heap_alloc_slow+0xb5>
    59de:	48 89 05 c3 e1 01 00 	mov    %rax,0x1e1c3(%rip)        # 23ba8 <fwp_heap+0x1428>
    59e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59e9:	4c 89 c0             	mov    %r8,%rax
    59ec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    59f1:	f2 0f 58 05 bf e1 01 	addsd  0x1e1bf(%rip),%xmm0        # 23bb8 <fwp_heap+0x1438>
    59f8:	00 
    59f9:	f2 0f 11 05 b7 e1 01 	movsd  %xmm0,0x1e1b7(%rip)        # 23bb8 <fwp_heap+0x1438>
    5a00:	00 
    5a01:	48 83 c4 10          	add    $0x10,%rsp
    5a05:	5b                   	pop    %rbx
    5a06:	c3                   	ret
    5a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a0e:	00 00 
    5a10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5a14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5a18:	e8 13 f1 ff ff       	call   4b30 <fwp_heap_init>
    5a1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5a21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5a26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5a2d:	0f 86 23 ff ff ff    	jbe    5956 <fwp_heap_alloc_slow+0x26>
    5a33:	48 83 c4 10          	add    $0x10,%rsp
    5a37:	44 89 ce             	mov    %r9d,%esi
    5a3a:	48 89 cf             	mov    %rcx,%rdi
    5a3d:	5b                   	pop    %rbx
    5a3e:	e9 cd fd ff ff       	jmp    5810 <fwp_heap_alloc_big>
    5a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5a48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5a4c:	4d 85 c0             	test   %r8,%r8
    5a4f:	74 1f                	je     5a70 <fwp_heap_alloc_slow+0x140>
    5a51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5a55:	4d 29 c3             	sub    %r8,%r11
    5a58:	49 39 db             	cmp    %rbx,%r11
    5a5b:	72 13                	jb     5a70 <fwp_heap_alloc_slow+0x140>
    5a5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a65:	e9 3c ff ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a7b:	44 89 ca             	mov    %r9d,%edx
    5a7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a8b:	44 89 d6             	mov    %r10d,%esi
    5a8e:	48 01 c7             	add    %rax,%rdi
    5a91:	e8 6a fa ff ff       	call   5500 <fwp_heap_refill>
    5a96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a9f:	49 89 c0             	mov    %rax,%r8
    5aa2:	e9 ff fe ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5aa7:	e8 04 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ab0 <fwp_heap_alloc>:
    5ab0:	8b 05 6e e0 01 00    	mov    0x1e06e(%rip),%eax        # 23b24 <fwp_heap+0x13a4>
    5ab6:	48 89 fa             	mov    %rdi,%rdx
    5ab9:	89 f7                	mov    %esi,%edi
    5abb:	85 c0                	test   %eax,%eax
    5abd:	0f 84 f5 00 00 00    	je     5bb8 <fwp_heap_alloc+0x108>
    5ac3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5aca:	0f 87 e8 00 00 00    	ja     5bb8 <fwp_heap_alloc+0x108>
    5ad0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ad4:	48 8d 05 a5 cc 01 00 	lea    0x1cca5(%rip),%rax        # 22780 <fwp_heap>
    5adb:	48 83 ec 18          	sub    $0x18,%rsp
    5adf:	41 89 f0             	mov    %esi,%r8d
    5ae2:	48 c1 e9 04          	shr    $0x4,%rcx
    5ae6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5aed:	00 
    5aee:	48 63 cf             	movslq %edi,%rcx
    5af1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5af8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5aff:	00 
    5b00:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5b04:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5b08:	48 01 c8             	add    %rcx,%rax
    5b0b:	48 8b 08             	mov    (%rax),%rcx
    5b0e:	48 85 c9             	test   %rcx,%rcx
    5b11:	74 6d                	je     5b80 <fwp_heap_alloc+0xd0>
    5b13:	48 8b 31             	mov    (%rcx),%rsi
    5b16:	48 f7 d6             	not    %rsi
    5b19:	48 89 30             	mov    %rsi,(%rax)
    5b1c:	41 83 f8 01          	cmp    $0x1,%r8d
    5b20:	48 89 cf             	mov    %rcx,%rdi
    5b23:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5b28:	49 0f 45 d1          	cmovne %r9,%rdx
    5b2c:	31 f6                	xor    %esi,%esi
    5b2e:	e8 8d d9 ff ff       	call   34c0 <memset@plt>
    5b33:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5b38:	48 89 c1             	mov    %rax,%rcx
    5b3b:	4c 89 c8             	mov    %r9,%rax
    5b3e:	48 03 05 5b e0 01 00 	add    0x1e05b(%rip),%rax        # 23ba0 <fwp_heap+0x1420>
    5b45:	72 7b                	jb     5bc2 <fwp_heap_alloc+0x112>
    5b47:	48 39 05 5a e0 01 00 	cmp    %rax,0x1e05a(%rip)        # 23ba8 <fwp_heap+0x1428>
    5b4e:	48 89 05 4b e0 01 00 	mov    %rax,0x1e04b(%rip)        # 23ba0 <fwp_heap+0x1420>
    5b55:	73 07                	jae    5b5e <fwp_heap_alloc+0xae>
    5b57:	48 89 05 4a e0 01 00 	mov    %rax,0x1e04a(%rip)        # 23ba8 <fwp_heap+0x1428>
    5b5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b62:	48 89 c8             	mov    %rcx,%rax
    5b65:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b6a:	f2 0f 58 05 46 e0 01 	addsd  0x1e046(%rip),%xmm0        # 23bb8 <fwp_heap+0x1438>
    5b71:	00 
    5b72:	f2 0f 11 05 3e e0 01 	movsd  %xmm0,0x1e03e(%rip)        # 23bb8 <fwp_heap+0x1438>
    5b79:	00 
    5b7a:	48 83 c4 18          	add    $0x18,%rsp
    5b7e:	c3                   	ret
    5b7f:	90                   	nop
    5b80:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b84:	48 85 c9             	test   %rcx,%rcx
    5b87:	74 0c                	je     5b95 <fwp_heap_alloc+0xe5>
    5b89:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b8d:	48 29 ce             	sub    %rcx,%rsi
    5b90:	4c 39 ce             	cmp    %r9,%rsi
    5b93:	73 13                	jae    5ba8 <fwp_heap_alloc+0xf8>
    5b95:	89 fe                	mov    %edi,%esi
    5b97:	48 83 c4 18          	add    $0x18,%rsp
    5b9b:	48 89 d7             	mov    %rdx,%rdi
    5b9e:	e9 8d fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5ba3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ba8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bac:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5bb0:	e9 67 ff ff ff       	jmp    5b1c <fwp_heap_alloc+0x6c>
    5bb5:	0f 1f 00             	nopl   (%rax)
    5bb8:	89 fe                	mov    %edi,%esi
    5bba:	48 89 d7             	mov    %rdx,%rdi
    5bbd:	e9 6e fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5bc2:	e8 e9 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bce:	00 00 

0000000000005bd0 <fwp_data.part.0.constprop.0>:
    5bd0:	41 56                	push   %r14
    5bd2:	41 89 fe             	mov    %edi,%r14d
    5bd5:	41 54                	push   %r12
    5bd7:	49 89 f4             	mov    %rsi,%r12
    5bda:	55                   	push   %rbp
    5bdb:	53                   	push   %rbx
    5bdc:	48 83 ec 08          	sub    $0x8,%rsp
    5be0:	8b 05 3e df 01 00    	mov    0x1df3e(%rip),%eax        # 23b24 <fwp_heap+0x13a4>
    5be6:	85 c0                	test   %eax,%eax
    5be8:	0f 84 fa 00 00 00    	je     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5bee:	0f b6 05 2d db 01 00 	movzbl 0x1db2d(%rip),%eax        # 23722 <fwp_heap+0xfa2>
    5bf5:	48 8d 15 84 cb 01 00 	lea    0x1cb84(%rip),%rdx        # 22780 <fwp_heap>
    5bfc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5c03:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5c07:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5c0b:	48 8b 18             	mov    (%rax),%rbx
    5c0e:	48 85 db             	test   %rbx,%rbx
    5c11:	0f 84 a9 00 00 00    	je     5cc0 <fwp_data.part.0.constprop.0+0xf0>
    5c17:	48 8b 13             	mov    (%rbx),%rdx
    5c1a:	48 f7 d2             	not    %rdx
    5c1d:	48 89 10             	mov    %rdx,(%rax)
    5c20:	48 83 fd 18          	cmp    $0x18,%rbp
    5c24:	76 1b                	jbe    5c41 <fwp_data.part.0.constprop.0+0x71>
    5c26:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5c2a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5c2e:	31 f6                	xor    %esi,%esi
    5c30:	48 c1 e8 03          	shr    $0x3,%rax
    5c34:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5c3b:	00 
    5c3c:	e8 7f d8 ff ff       	call   34c0 <memset@plt>
    5c41:	48 89 e8             	mov    %rbp,%rax
    5c44:	48 03 05 55 df 01 00 	add    0x1df55(%rip),%rax        # 23ba0 <fwp_heap+0x1420>
    5c4b:	0f 82 a8 00 00 00    	jb     5cf9 <fwp_data.part.0.constprop.0+0x129>
    5c51:	48 39 05 50 df 01 00 	cmp    %rax,0x1df50(%rip)        # 23ba8 <fwp_heap+0x1428>
    5c58:	48 89 05 41 df 01 00 	mov    %rax,0x1df41(%rip)        # 23ba0 <fwp_heap+0x1420>
    5c5f:	73 07                	jae    5c68 <fwp_data.part.0.constprop.0+0x98>
    5c61:	48 89 05 40 df 01 00 	mov    %rax,0x1df40(%rip)        # 23ba8 <fwp_heap+0x1428>
    5c68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c6c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c71:	f2 0f 58 05 3f df 01 	addsd  0x1df3f(%rip),%xmm0        # 23bb8 <fwp_heap+0x1438>
    5c78:	00 
    5c79:	f2 0f 11 05 37 df 01 	movsd  %xmm0,0x1df37(%rip)        # 23bb8 <fwp_heap+0x1438>
    5c80:	00 
    5c81:	b8 02 00 00 00       	mov    $0x2,%eax
    5c86:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c8b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c8f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c93:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c97:	49 8b 04 24          	mov    (%r12),%rax
    5c9b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c9f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5ca4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ca8:	48 83 c4 08          	add    $0x8,%rsp
    5cac:	48 89 d8             	mov    %rbx,%rax
    5caf:	5b                   	pop    %rbx
    5cb0:	5d                   	pop    %rbp
    5cb1:	41 5c                	pop    %r12
    5cb3:	41 5e                	pop    %r14
    5cb5:	c3                   	ret
    5cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cbd:	00 00 00 
    5cc0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5cc4:	48 85 db             	test   %rbx,%rbx
    5cc7:	74 1f                	je     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5cc9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ccd:	48 29 da             	sub    %rbx,%rdx
    5cd0:	48 39 ea             	cmp    %rbp,%rdx
    5cd3:	72 13                	jb     5ce8 <fwp_data.part.0.constprop.0+0x118>
    5cd5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5cd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5cdd:	e9 3e ff ff ff       	jmp    5c20 <fwp_data.part.0.constprop.0+0x50>
    5ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ce8:	31 f6                	xor    %esi,%esi
    5cea:	bf 18 00 00 00       	mov    $0x18,%edi
    5cef:	e8 bc fd ff ff       	call   5ab0 <fwp_heap_alloc>
    5cf4:	48 89 c3             	mov    %rax,%rbx
    5cf7:	eb 88                	jmp    5c81 <fwp_data.part.0.constprop.0+0xb1>
    5cf9:	e8 b2 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cfe:	66 90                	xchg   %ax,%ax

0000000000005d00 <fwp_p_ad_push>:
    5d00:	41 57                	push   %r15
    5d02:	41 56                	push   %r14
    5d04:	41 55                	push   %r13
    5d06:	49 89 d5             	mov    %rdx,%r13
    5d09:	41 54                	push   %r12
    5d0b:	49 89 fc             	mov    %rdi,%r12
    5d0e:	55                   	push   %rbp
    5d0f:	53                   	push   %rbx
    5d10:	48 83 ec 38          	sub    $0x38,%rsp
    5d14:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5d19:	48 85 ff             	test   %rdi,%rdi
    5d1c:	79 09                	jns    5d27 <fwp_p_ad_push+0x27>
    5d1e:	48 85 d2             	test   %rdx,%rdx
    5d21:	0f 88 a9 01 00 00    	js     5ed0 <fwp_p_ad_push+0x1d0>
    5d27:	48 89 f8             	mov    %rdi,%rax
    5d2a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5d2e:	48 09 d0             	or     %rdx,%rax
    5d31:	0f 89 79 01 00 00    	jns    5eb0 <fwp_p_ad_push+0x1b0>
    5d37:	48 89 f8             	mov    %rdi,%rax
    5d3a:	48 c1 f8 20          	sar    $0x20,%rax
    5d3e:	48 85 ff             	test   %rdi,%rdi
    5d41:	79 24                	jns    5d67 <fwp_p_ad_push+0x67>
    5d43:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5d48:	48 89 d0             	mov    %rdx,%rax
    5d4b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5d52:	00 
    5d53:	49 89 d4             	mov    %rdx,%r12
    5d56:	48 c1 f8 20          	sar    $0x20,%rax
    5d5a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d61:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d67:	48 89 c7             	mov    %rax,%rdi
    5d6a:	e8 11 e7 ff ff       	call   4480 <fwp_tape_of>
    5d6f:	48 89 c3             	mov    %rax,%rbx
    5d72:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d77:	0f 85 76 02 00 00    	jne    5ff3 <fwp_p_ad_push+0x2f3>
    5d7d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d81:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d88:	0f 8f 59 02 00 00    	jg     5fe7 <fwp_p_ad_push+0x2e7>
    5d8e:	44 89 e0             	mov    %r12d,%eax
    5d91:	4c 39 f8             	cmp    %r15,%rax
    5d94:	0f 8d 41 02 00 00    	jge    5fdb <fwp_p_ad_push+0x2db>
    5d9a:	4d 85 ed             	test   %r13,%r13
    5d9d:	78 0c                	js     5dab <fwp_p_ad_push+0xab>
    5d9f:	44 89 e8             	mov    %r13d,%eax
    5da2:	4c 39 f8             	cmp    %r15,%rax
    5da5:	0f 8d 30 02 00 00    	jge    5fdb <fwp_p_ad_push+0x2db>
    5dab:	4d 89 fe             	mov    %r15,%r14
    5dae:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5db2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5db6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5dbc:	0f 87 25 02 00 00    	ja     5fe7 <fwp_p_ad_push+0x2e7>
    5dc2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5dc6:	48 39 e8             	cmp    %rbp,%rax
    5dc9:	0f 8e 31 01 00 00    	jle    5f00 <fwp_p_ad_push+0x200>
    5dcf:	48 85 ed             	test   %rbp,%rbp
    5dd2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5dd7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5ddb:	48 39 e8             	cmp    %rbp,%rax
    5dde:	7e 20                	jle    5e00 <fwp_p_ad_push+0x100>
    5de0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5de7:	0f 8f 03 01 00 00    	jg     5ef0 <fwp_p_ad_push+0x1f0>
    5ded:	48 01 ed             	add    %rbp,%rbp
    5df0:	48 39 e8             	cmp    %rbp,%rax
    5df3:	7f eb                	jg     5de0 <fwp_p_ad_push+0xe0>
    5df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dfc:	00 00 00 00 
    5e00:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5e07:	00 
    5e08:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5e0c:	48 89 c6             	mov    %rax,%rsi
    5e0f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5e14:	e8 b7 d7 ff ff       	call   35d0 <realloc@plt>
    5e19:	48 85 c0             	test   %rax,%rax
    5e1c:	0f 84 dd 01 00 00    	je     5fff <fwp_p_ad_push+0x2ff>
    5e22:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5e26:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5e2a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5e2e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5e32:	48 89 e9             	mov    %rbp,%rcx
    5e35:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5e39:	48 c1 e1 04          	shl    $0x4,%rcx
    5e3d:	48 89 ce             	mov    %rcx,%rsi
    5e40:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5e45:	e8 86 d7 ff ff       	call   35d0 <realloc@plt>
    5e4a:	48 85 c0             	test   %rax,%rax
    5e4d:	0f 84 ac 01 00 00    	je     5fff <fwp_p_ad_push+0x2ff>
    5e53:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5e57:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5e5c:	4d 85 f6             	test   %r14,%r14
    5e5f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e63:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e68:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e6f:	00 
    5e70:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e77:	00 
    5e78:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e7c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e83:	00 
    5e84:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e88:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e8c:	0f 85 e2 00 00 00    	jne    5f74 <fwp_p_ad_push+0x274>
    5e92:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e96:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e9a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e9e:	49 01 c8             	add    %rcx,%r8
    5ea1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5ea5:	eb 79                	jmp    5f20 <fwp_p_ad_push+0x220>
    5ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5eae:	00 00 
    5eb0:	48 89 d0             	mov    %rdx,%rax
    5eb3:	48 c1 ff 20          	sar    $0x20,%rdi
    5eb7:	48 c1 f8 20          	sar    $0x20,%rax
    5ebb:	48 39 c7             	cmp    %rax,%rdi
    5ebe:	0f 84 a3 fe ff ff    	je     5d67 <fwp_p_ad_push+0x67>
    5ec4:	48 8d 3d fd 88 00 00 	lea    0x88fd(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    5ecb:	e8 d0 e2 ff ff       	call   41a0 <fwp_trap>
    5ed0:	48 83 c4 38          	add    $0x38,%rsp
    5ed4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edb:	5b                   	pop    %rbx
    5edc:	5d                   	pop    %rbp
    5edd:	41 5c                	pop    %r12
    5edf:	41 5d                	pop    %r13
    5ee1:	41 5e                	pop    %r14
    5ee3:	41 5f                	pop    %r15
    5ee5:	c3                   	ret
    5ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5eed:	00 00 00 
    5ef0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5ef5:	e9 06 ff ff ff       	jmp    5e00 <fwp_p_ad_push+0x100>
    5efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f00:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f04:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f08:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f0f:	00 
    5f10:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f17:	00 
    5f18:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5f1c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f20:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5f26:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5f2a:	4d 85 ed             	test   %r13,%r13
    5f2d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5f32:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5f38:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f3f:	4c 0f 48 e8          	cmovs  %rax,%r13
    5f43:	49 8d 47 01          	lea    0x1(%r15),%rax
    5f47:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5f4b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5f51:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5f55:	48 83 c4 38          	add    $0x38,%rsp
    5f59:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f60:	ff ff ff 
    5f63:	4c 21 e0             	and    %r12,%rax
    5f66:	5b                   	pop    %rbx
    5f67:	5d                   	pop    %rbp
    5f68:	4c 09 f8             	or     %r15,%rax
    5f6b:	41 5c                	pop    %r12
    5f6d:	41 5d                	pop    %r13
    5f6f:	41 5e                	pop    %r14
    5f71:	41 5f                	pop    %r15
    5f73:	c3                   	ret
    5f74:	48 39 ca             	cmp    %rcx,%rdx
    5f77:	49 89 d6             	mov    %rdx,%r14
    5f7a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f7f:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f83:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f88:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f8d:	48 29 d1             	sub    %rdx,%rcx
    5f90:	4c 89 ca             	mov    %r9,%rdx
    5f93:	e8 c8 d5 ff ff       	call   3560 <__memmove_chk@plt>
    5f98:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f9c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5fa1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5fa5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5faa:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5fae:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5fb2:	4c 89 d2             	mov    %r10,%rdx
    5fb5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5fba:	e8 51 d6 ff ff       	call   3610 <memmove@plt>
    5fbf:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fc3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fc7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5fcc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5fd1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5fd6:	e9 bb fe ff ff       	jmp    5e96 <fwp_p_ad_push+0x196>
    5fdb:	48 8d 3d 22 81 00 00 	lea    0x8122(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    5fe2:	e8 b9 e1 ff ff       	call   41a0 <fwp_trap>
    5fe7:	48 8d 3d fb 80 00 00 	lea    0x80fb(%rip),%rdi        # e0e9 <_IO_stdin_used+0xe9>
    5fee:	e8 ad e1 ff ff       	call   41a0 <fwp_trap>
    5ff3:	48 8d 3d 16 88 00 00 	lea    0x8816(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    5ffa:	e8 a1 e1 ff ff       	call   41a0 <fwp_trap>
    5fff:	48 89 df             	mov    %rbx,%rdi
    6002:	e8 f9 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6007:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    600b:	e8 b0 d3 ff ff       	call   33c0 <free@plt>
    6010:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6014:	e8 a7 d3 ff ff       	call   33c0 <free@plt>
    6019:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    601d:	e8 9e d3 ff ff       	call   33c0 <free@plt>
    6022:	31 c9                	xor    %ecx,%ecx
    6024:	31 c0                	xor    %eax,%eax
    6026:	31 d2                	xor    %edx,%edx
    6028:	89 53 04             	mov    %edx,0x4(%rbx)
    602b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    602f:	ba 13 00 00 00       	mov    $0x13,%edx
    6034:	be 01 00 00 00       	mov    $0x1,%esi
    6039:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    603d:	48 8d 3d c4 7f 00 00 	lea    0x7fc4(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    6044:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6048:	48 8b 0d f1 bf 00 00 	mov    0xbff1(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    604f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6053:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6057:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    605b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    605f:	e8 1c d6 ff ff       	call   3680 <fwrite@plt>
    6064:	31 ff                	xor    %edi,%edi
    6066:	e8 55 d5 ff ff       	call   35c0 <fflush@plt>
    606b:	bf 66 00 00 00       	mov    $0x66,%edi
    6070:	e8 2b d6 ff ff       	call   36a0 <_Exit@plt>
    6075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    607c:	00 00 00 00 

0000000000006080 <w120>:
    6080:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6084:	41 55                	push   %r13
    6086:	48 89 fa             	mov    %rdi,%rdx
    6089:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    608d:	41 54                	push   %r12
    608f:	49 89 fc             	mov    %rdi,%r12
    6092:	55                   	push   %rbp
    6093:	53                   	push   %rbx
    6094:	48 89 f3             	mov    %rsi,%rbx
    6097:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    609c:	48 89 f1             	mov    %rsi,%rcx
    609f:	48 83 ec 28          	sub    $0x28,%rsp
    60a3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    60a9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    60af:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60b5:	e8 46 fc ff ff       	call   5d00 <fwp_p_ad_push>
    60ba:	48 89 c7             	mov    %rax,%rdi
    60bd:	e8 5e ec ff ff       	call   4d20 <caf75>
    60c2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    60c7:	e8 54 ec ff ff       	call   4d20 <caf75>
    60cc:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    60d2:	66 0f 57 05 56 8a 00 	xorpd  0x8a56(%rip),%xmm0        # eb30 <msg.8+0xb0>
    60d9:	00 
    60da:	48 89 da             	mov    %rbx,%rdx
    60dd:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    60e3:	48 89 c1             	mov    %rax,%rcx
    60e6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    60eb:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    60f0:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60f6:	e8 05 fc ff ff       	call   5d00 <fwp_p_ad_push>
    60fb:	4c 89 e7             	mov    %r12,%rdi
    60fe:	49 89 c5             	mov    %rax,%r13
    6101:	e8 1a ec ff ff       	call   4d20 <caf75>
    6106:	48 89 c6             	mov    %rax,%rsi
    6109:	e8 12 ec ff ff       	call   4d20 <caf75>
    610e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6113:	f2 0f 10 05 8d 89 00 	movsd  0x898d(%rip),%xmm0        # eaa8 <msg.8+0x28>
    611a:	00 
    611b:	66 0f 57 15 0d 8a 00 	xorpd  0x8a0d(%rip),%xmm2        # eb30 <msg.8+0xb0>
    6122:	00 
    6123:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6129:	48 89 c1             	mov    %rax,%rcx
    612c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6133:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6138:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    613d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6143:	e8 b8 fb ff ff       	call   5d00 <fwp_p_ad_push>
    6148:	48 89 e9             	mov    %rbp,%rcx
    614b:	4c 89 ea             	mov    %r13,%rdx
    614e:	48 89 ee             	mov    %rbp,%rsi
    6151:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6157:	4c 89 ef             	mov    %r13,%rdi
    615a:	49 89 c4             	mov    %rax,%r12
    615d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6161:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6167:	e8 94 fb ff ff       	call   5d00 <fwp_p_ad_push>
    616c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6172:	f2 0f 59 1d 36 89 00 	mulsd  0x8936(%rip),%xmm3        # eab0 <msg.8+0x30>
    6179:	00 
    617a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6181:	00 59 40 
    6184:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6189:	48 89 c2             	mov    %rax,%rdx
    618c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6193:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6199:	e8 62 fb ff ff       	call   5d00 <fwp_p_ad_push>
    619e:	4c 89 e2             	mov    %r12,%rdx
    61a1:	48 89 d9             	mov    %rbx,%rcx
    61a4:	48 89 de             	mov    %rbx,%rsi
    61a7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    61ad:	4c 89 e7             	mov    %r12,%rdi
    61b0:	48 89 c5             	mov    %rax,%rbp
    61b3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    61b7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61bd:	e8 3e fb ff ff       	call   5d00 <fwp_p_ad_push>
    61c2:	48 89 c7             	mov    %rax,%rdi
    61c5:	e8 56 eb ff ff       	call   4d20 <caf75>
    61ca:	48 89 c6             	mov    %rax,%rsi
    61cd:	e8 4e eb ff ff       	call   4d20 <caf75>
    61d2:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    61d8:	48 89 ea             	mov    %rbp,%rdx
    61db:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    61e1:	48 89 c1             	mov    %rax,%rcx
    61e4:	66 48 0f 7e db       	movq   %xmm3,%rbx
    61e9:	e8 12 fb ff ff       	call   5d00 <fwp_p_ad_push>
    61ee:	48 83 c4 28          	add    $0x28,%rsp
    61f2:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    61f7:	5b                   	pop    %rbx
    61f8:	5d                   	pop    %rbp
    61f9:	41 5c                	pop    %r12
    61fb:	41 5d                	pop    %r13
    61fd:	c3                   	ret
    61fe:	66 90                	xchg   %ax,%ax

0000000000006200 <w176.constprop.0>:
    6200:	41 54                	push   %r12
    6202:	55                   	push   %rbp
    6203:	53                   	push   %rbx
    6204:	48 83 ec 10          	sub    $0x10,%rsp
    6208:	4c 8b 27             	mov    (%rdi),%r12
    620b:	4d 85 e4             	test   %r12,%r12
    620e:	74 78                	je     6288 <w176.constprop.0+0x88>
    6210:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6217:	00 00 
    6219:	48 89 fd             	mov    %rdi,%rbp
    621c:	31 db                	xor    %ebx,%ebx
    621e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    622c:	00 00 00 00 
    6230:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6235:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    623b:	48 83 c3 02          	add    $0x2,%rbx
    623f:	e8 dc ea ff ff       	call   4d20 <caf75>
    6244:	48 89 c6             	mov    %rax,%rsi
    6247:	e8 d4 ea ff ff       	call   4d20 <caf75>
    624c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6252:	4c 89 c2             	mov    %r8,%rdx
    6255:	48 89 c1             	mov    %rax,%rcx
    6258:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    625e:	e8 9d fa ff ff       	call   5d00 <fwp_p_ad_push>
    6263:	48 89 c7             	mov    %rax,%rdi
    6266:	4c 39 e3             	cmp    %r12,%rbx
    6269:	72 c5                	jb     6230 <w176.constprop.0+0x30>
    626b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6270:	48 83 c4 10          	add    $0x10,%rsp
    6274:	5b                   	pop    %rbx
    6275:	5d                   	pop    %rbp
    6276:	66 48 0f 6e c0       	movq   %rax,%xmm0
    627b:	41 5c                	pop    %r12
    627d:	48 89 f8             	mov    %rdi,%rax
    6280:	c3                   	ret
    6281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6288:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    628f:	00 00 
    6291:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6298:	eb d1                	jmp    626b <w176.constprop.0+0x6b>
    629a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000062a0 <fwp_rc_share>:
    62a0:	48 8b 05 b1 d8 01 00 	mov    0x1d8b1(%rip),%rax        # 23b58 <fwp_heap+0x13d8>
    62a7:	48 2b 3d 82 d8 01 00 	sub    0x1d882(%rip),%rdi        # 23b30 <fwp_heap+0x13b0>
    62ae:	48 c1 e0 10          	shl    $0x10,%rax
    62b2:	48 39 c7             	cmp    %rax,%rdi
    62b5:	73 4a                	jae    6301 <fwp_rc_share+0x61>
    62b7:	48 89 f8             	mov    %rdi,%rax
    62ba:	48 c1 e8 10          	shr    $0x10,%rax
    62be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    62c2:	48 8b 05 af d8 01 00 	mov    0x1d8af(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    62c9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    62cd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    62d1:	48 85 d2             	test   %rdx,%rdx
    62d4:	74 2b                	je     6301 <fwp_rc_share+0x61>
    62d6:	0f b6 08             	movzbl (%rax),%ecx
    62d9:	80 f9 02             	cmp    $0x2,%cl
    62dc:	74 2a                	je     6308 <fwp_rc_share+0x68>
    62de:	80 f9 01             	cmp    $0x1,%cl
    62e1:	75 1e                	jne    6301 <fwp_rc_share+0x61>
    62e3:	8b 48 18             	mov    0x18(%rax),%ecx
    62e6:	0f b7 ff             	movzwl %di,%edi
    62e9:	8b 40 1c             	mov    0x1c(%rax),%eax
    62ec:	48 0f af f9          	imul   %rcx,%rdi
    62f0:	48 c1 ef 20          	shr    $0x20,%rdi
    62f4:	48 39 c7             	cmp    %rax,%rdi
    62f7:	73 08                	jae    6301 <fwp_rc_share+0x61>
    62f9:	48 01 fa             	add    %rdi,%rdx
    62fc:	80 3a 00             	cmpb   $0x0,(%rdx)
    62ff:	75 0d                	jne    630e <fwp_rc_share+0x6e>
    6301:	c3                   	ret
    6302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6308:	66 85 ff             	test   %di,%di
    630b:	74 ef                	je     62fc <fwp_rc_share+0x5c>
    630d:	c3                   	ret
    630e:	50                   	push   %rax
    630f:	48 8d 3d 2a 85 00 00 	lea    0x852a(%rip),%rdi        # e840 <_IO_stdin_used+0x840>
    6316:	e8 85 de ff ff       	call   41a0 <fwp_trap>
    631b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006320 <fwp_rc_fresh>:
    6320:	48 8b 15 31 d8 01 00 	mov    0x1d831(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 89 fe             	mov    %rdi,%rsi
    632d:	48 2b 05 fc d7 01 00 	sub    0x1d7fc(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6334:	48 c1 e2 10          	shl    $0x10,%rdx
    6338:	48 39 d0             	cmp    %rdx,%rax
    633b:	73 4f                	jae    638c <fwp_rc_fresh+0x6c>
    633d:	48 89 c2             	mov    %rax,%rdx
    6340:	48 c1 ea 10          	shr    $0x10,%rdx
    6344:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6348:	48 8b 15 29 d8 01 00 	mov    0x1d829(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    634f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6353:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6357:	48 85 d2             	test   %rdx,%rdx
    635a:	74 30                	je     638c <fwp_rc_fresh+0x6c>
    635c:	0f b6 39             	movzbl (%rcx),%edi
    635f:	40 80 ff 02          	cmp    $0x2,%dil
    6363:	74 2b                	je     6390 <fwp_rc_fresh+0x70>
    6365:	40 80 ff 01          	cmp    $0x1,%dil
    6369:	75 21                	jne    638c <fwp_rc_fresh+0x6c>
    636b:	8b 79 18             	mov    0x18(%rcx),%edi
    636e:	0f b7 c0             	movzwl %ax,%eax
    6371:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6374:	48 0f af c7          	imul   %rdi,%rax
    6378:	48 c1 e8 20          	shr    $0x20,%rax
    637c:	48 39 c8             	cmp    %rcx,%rax
    637f:	73 0b                	jae    638c <fwp_rc_fresh+0x6c>
    6381:	48 01 c2             	add    %rax,%rdx
    6384:	80 3a ff             	cmpb   $0xff,(%rdx)
    6387:	74 17                	je     63a0 <fwp_rc_fresh+0x80>
    6389:	c6 02 01             	movb   $0x1,(%rdx)
    638c:	48 89 f0             	mov    %rsi,%rax
    638f:	c3                   	ret
    6390:	66 85 c0             	test   %ax,%ax
    6393:	74 ef                	je     6384 <fwp_rc_fresh+0x64>
    6395:	48 89 f0             	mov    %rsi,%rax
    6398:	c3                   	ret
    6399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    63a0:	48 83 ec 18          	sub    $0x18,%rsp
    63a4:	48 89 d7             	mov    %rdx,%rdi
    63a7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    63ac:	48 89 14 24          	mov    %rdx,(%rsp)
    63b0:	e8 bb ef ff ff       	call   5370 <fwp_rc_forget_slot>
    63b5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63ba:	48 8b 14 24          	mov    (%rsp),%rdx
    63be:	48 89 f0             	mov    %rsi,%rax
    63c1:	c6 02 01             	movb   $0x1,(%rdx)
    63c4:	48 83 c4 18          	add    $0x18,%rsp
    63c8:	c3                   	ret
    63c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000063d0 <fwp_rc_free_obj>:
    63d0:	48 8b 15 81 d7 01 00 	mov    0x1d781(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    63d7:	48 89 f8             	mov    %rdi,%rax
    63da:	48 2b 05 4f d7 01 00 	sub    0x1d74f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    63e1:	48 c1 e2 10          	shl    $0x10,%rdx
    63e5:	48 39 d0             	cmp    %rdx,%rax
    63e8:	73 5b                	jae    6445 <fwp_rc_free_obj+0x75>
    63ea:	48 89 c2             	mov    %rax,%rdx
    63ed:	48 c1 ea 10          	shr    $0x10,%rdx
    63f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    63f5:	48 8b 15 7c d7 01 00 	mov    0x1d77c(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    63fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6400:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6404:	48 85 c9             	test   %rcx,%rcx
    6407:	74 3c                	je     6445 <fwp_rc_free_obj+0x75>
    6409:	0f b6 32             	movzbl (%rdx),%esi
    640c:	40 80 fe 02          	cmp    $0x2,%sil
    6410:	74 2e                	je     6440 <fwp_rc_free_obj+0x70>
    6412:	40 80 fe 01          	cmp    $0x1,%sil
    6416:	75 2d                	jne    6445 <fwp_rc_free_obj+0x75>
    6418:	8b 72 18             	mov    0x18(%rdx),%esi
    641b:	0f b7 c0             	movzwl %ax,%eax
    641e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6421:	48 0f af c6          	imul   %rsi,%rax
    6425:	48 c1 e8 20          	shr    $0x20,%rax
    6429:	48 39 d0             	cmp    %rdx,%rax
    642c:	73 17                	jae    6445 <fwp_rc_free_obj+0x75>
    642e:	48 01 c1             	add    %rax,%rcx
    6431:	80 39 01             	cmpb   $0x1,(%rcx)
    6434:	75 0f                	jne    6445 <fwp_rc_free_obj+0x75>
    6436:	e9 75 f1 ff ff       	jmp    55b0 <fwp_mem_free>
    643b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6440:	66 85 c0             	test   %ax,%ax
    6443:	74 ec                	je     6431 <fwp_rc_free_obj+0x61>
    6445:	c3                   	ret
    6446:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    644d:	00 00 00 

0000000000006450 <fwp_rc_dup>:
    6450:	f3 0f 1e fa          	endbr64
    6454:	48 8b 05 fd d6 01 00 	mov    0x1d6fd(%rip),%rax        # 23b58 <fwp_heap+0x13d8>
    645b:	48 2b 3d ce d6 01 00 	sub    0x1d6ce(%rip),%rdi        # 23b30 <fwp_heap+0x13b0>
    6462:	48 c1 e0 10          	shl    $0x10,%rax
    6466:	48 39 c7             	cmp    %rax,%rdi
    6469:	73 56                	jae    64c1 <fwp_rc_dup+0x71>
    646b:	48 89 f8             	mov    %rdi,%rax
    646e:	48 c1 e8 10          	shr    $0x10,%rax
    6472:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6476:	48 8b 05 fb d6 01 00 	mov    0x1d6fb(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    647d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6481:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6485:	48 85 c0             	test   %rax,%rax
    6488:	74 37                	je     64c1 <fwp_rc_dup+0x71>
    648a:	0f b6 0a             	movzbl (%rdx),%ecx
    648d:	80 f9 02             	cmp    $0x2,%cl
    6490:	74 36                	je     64c8 <fwp_rc_dup+0x78>
    6492:	80 f9 01             	cmp    $0x1,%cl
    6495:	75 2a                	jne    64c1 <fwp_rc_dup+0x71>
    6497:	8b 4a 18             	mov    0x18(%rdx),%ecx
    649a:	0f b7 ff             	movzwl %di,%edi
    649d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    64a0:	48 0f af f9          	imul   %rcx,%rdi
    64a4:	48 c1 ef 20          	shr    $0x20,%rdi
    64a8:	48 39 d7             	cmp    %rdx,%rdi
    64ab:	73 14                	jae    64c1 <fwp_rc_dup+0x71>
    64ad:	48 01 f8             	add    %rdi,%rax
    64b0:	0f b6 10             	movzbl (%rax),%edx
    64b3:	84 d2                	test   %dl,%dl
    64b5:	74 0a                	je     64c1 <fwp_rc_dup+0x71>
    64b7:	80 fa fd             	cmp    $0xfd,%dl
    64ba:	77 14                	ja     64d0 <fwp_rc_dup+0x80>
    64bc:	83 c2 01             	add    $0x1,%edx
    64bf:	88 10                	mov    %dl,(%rax)
    64c1:	c3                   	ret
    64c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64c8:	66 85 ff             	test   %di,%di
    64cb:	74 e3                	je     64b0 <fwp_rc_dup+0x60>
    64cd:	c3                   	ret
    64ce:	66 90                	xchg   %ax,%ax
    64d0:	48 89 c7             	mov    %rax,%rdi
    64d3:	e9 78 ed ff ff       	jmp    5250 <fwp_rc_wide_dup>
    64d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64df:	00 

00000000000064e0 <fwp_owned_entry173>:
    64e0:	f3 0f 1e fa          	endbr64
    64e4:	48 83 ec 38          	sub    $0x38,%rsp
    64e8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    64ed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    64f4:	00 00 
    64f6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    64fb:	31 c0                	xor    %eax,%eax
    64fd:	48 8b 07             	mov    (%rdi),%rax
    6500:	48 03 47 10          	add    0x10(%rdi),%rax
    6504:	0f 80 c2 00 00 00    	jo     65cc <fwp_owned_entry173+0xec>
    650a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    650f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6514:	31 ff                	xor    %edi,%edi
    6516:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    651a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    651f:	e8 ac f6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    6524:	48 8b 15 2d d6 01 00 	mov    0x1d62d(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    652b:	48 89 c6             	mov    %rax,%rsi
    652e:	48 2b 05 fb d5 01 00 	sub    0x1d5fb(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6535:	48 c1 e2 10          	shl    $0x10,%rdx
    6539:	48 39 d0             	cmp    %rdx,%rax
    653c:	73 4f                	jae    658d <fwp_owned_entry173+0xad>
    653e:	48 89 c2             	mov    %rax,%rdx
    6541:	48 c1 ea 10          	shr    $0x10,%rdx
    6545:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6549:	48 8b 15 28 d6 01 00 	mov    0x1d628(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    6550:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6554:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6558:	48 85 d2             	test   %rdx,%rdx
    655b:	74 30                	je     658d <fwp_owned_entry173+0xad>
    655d:	0f b6 39             	movzbl (%rcx),%edi
    6560:	40 80 ff 02          	cmp    $0x2,%dil
    6564:	74 42                	je     65a8 <fwp_owned_entry173+0xc8>
    6566:	40 80 ff 01          	cmp    $0x1,%dil
    656a:	75 21                	jne    658d <fwp_owned_entry173+0xad>
    656c:	8b 79 18             	mov    0x18(%rcx),%edi
    656f:	0f b7 c0             	movzwl %ax,%eax
    6572:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6575:	48 0f af c7          	imul   %rdi,%rax
    6579:	48 c1 e8 20          	shr    $0x20,%rax
    657d:	48 39 c8             	cmp    %rcx,%rax
    6580:	73 0b                	jae    658d <fwp_owned_entry173+0xad>
    6582:	48 01 c2             	add    %rax,%rdx
    6585:	80 3a ff             	cmpb   $0xff,(%rdx)
    6588:	74 26                	je     65b0 <fwp_owned_entry173+0xd0>
    658a:	c6 02 01             	movb   $0x1,(%rdx)
    658d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6592:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6599:	00 00 
    659b:	75 34                	jne    65d1 <fwp_owned_entry173+0xf1>
    659d:	48 89 f0             	mov    %rsi,%rax
    65a0:	48 83 c4 38          	add    $0x38,%rsp
    65a4:	c3                   	ret
    65a5:	0f 1f 00             	nopl   (%rax)
    65a8:	66 85 c0             	test   %ax,%ax
    65ab:	75 e0                	jne    658d <fwp_owned_entry173+0xad>
    65ad:	eb d6                	jmp    6585 <fwp_owned_entry173+0xa5>
    65af:	90                   	nop
    65b0:	48 89 d7             	mov    %rdx,%rdi
    65b3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    65b8:	48 89 14 24          	mov    %rdx,(%rsp)
    65bc:	e8 af ed ff ff       	call   5370 <fwp_rc_forget_slot>
    65c1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    65c6:	48 8b 14 24          	mov    (%rsp),%rdx
    65ca:	eb be                	jmp    658a <fwp_owned_entry173+0xaa>
    65cc:	e8 2f d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    65d1:	e8 8a ce ff ff       	call   3460 <__stack_chk_fail@plt>
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 

00000000000065e0 <e173>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	53                   	push   %rbx
    65e5:	48 83 ec 30          	sub    $0x30,%rsp
    65e9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    65ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    65f5:	00 00 
    65f7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    65fc:	31 c0                	xor    %eax,%eax
    65fe:	48 8b 07             	mov    (%rdi),%rax
    6601:	48 03 47 10          	add    0x10(%rdi),%rax
    6605:	0f 80 c9 00 00 00    	jo     66d4 <e173+0xf4>
    660b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6610:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6615:	31 ff                	xor    %edi,%edi
    6617:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    661b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6620:	e8 ab f5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    6625:	48 8b 15 2c d5 01 00 	mov    0x1d52c(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    662c:	48 89 c3             	mov    %rax,%rbx
    662f:	48 2b 05 fa d4 01 00 	sub    0x1d4fa(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6636:	48 c1 e2 10          	shl    $0x10,%rdx
    663a:	48 39 d0             	cmp    %rdx,%rax
    663d:	73 4f                	jae    668e <e173+0xae>
    663f:	48 89 c2             	mov    %rax,%rdx
    6642:	48 c1 ea 10          	shr    $0x10,%rdx
    6646:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    664a:	48 8b 15 27 d5 01 00 	mov    0x1d527(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    6651:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6655:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6659:	48 85 d2             	test   %rdx,%rdx
    665c:	74 30                	je     668e <e173+0xae>
    665e:	0f b6 31             	movzbl (%rcx),%esi
    6661:	40 80 fe 02          	cmp    $0x2,%sil
    6665:	74 49                	je     66b0 <e173+0xd0>
    6667:	40 80 fe 01          	cmp    $0x1,%sil
    666b:	75 21                	jne    668e <e173+0xae>
    666d:	8b 71 18             	mov    0x18(%rcx),%esi
    6670:	0f b7 c0             	movzwl %ax,%eax
    6673:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6676:	48 0f af c6          	imul   %rsi,%rax
    667a:	48 c1 e8 20          	shr    $0x20,%rax
    667e:	48 39 c8             	cmp    %rcx,%rax
    6681:	73 0b                	jae    668e <e173+0xae>
    6683:	48 01 c2             	add    %rax,%rdx
    6686:	80 3a ff             	cmpb   $0xff,(%rdx)
    6689:	74 35                	je     66c0 <e173+0xe0>
    668b:	c6 02 01             	movb   $0x1,(%rdx)
    668e:	48 89 df             	mov    %rbx,%rdi
    6691:	e8 0a fc ff ff       	call   62a0 <fwp_rc_share>
    6696:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    669b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    66a2:	00 00 
    66a4:	75 33                	jne    66d9 <e173+0xf9>
    66a6:	48 83 c4 30          	add    $0x30,%rsp
    66aa:	48 89 d8             	mov    %rbx,%rax
    66ad:	5b                   	pop    %rbx
    66ae:	c3                   	ret
    66af:	90                   	nop
    66b0:	66 85 c0             	test   %ax,%ax
    66b3:	75 d9                	jne    668e <e173+0xae>
    66b5:	eb cf                	jmp    6686 <e173+0xa6>
    66b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    66be:	00 00 
    66c0:	48 89 d7             	mov    %rdx,%rdi
    66c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    66c8:	e8 a3 ec ff ff       	call   5370 <fwp_rc_forget_slot>
    66cd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    66d2:	eb b7                	jmp    668b <e173+0xab>
    66d4:	e8 27 d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    66d9:	e8 82 cd ff ff       	call   3460 <__stack_chk_fail@plt>
    66de:	66 90                	xchg   %ax,%ax

00000000000066e0 <fwp_closure_drop>:
    66e0:	48 8b 15 71 d4 01 00 	mov    0x1d471(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    66e7:	48 89 f8             	mov    %rdi,%rax
    66ea:	48 2b 05 3f d4 01 00 	sub    0x1d43f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    66f1:	48 c1 e2 10          	shl    $0x10,%rdx
    66f5:	48 39 d0             	cmp    %rdx,%rax
    66f8:	73 6b                	jae    6765 <fwp_closure_drop+0x85>
    66fa:	48 89 c2             	mov    %rax,%rdx
    66fd:	48 c1 ea 10          	shr    $0x10,%rdx
    6701:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6705:	48 8b 15 6c d4 01 00 	mov    0x1d46c(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    670c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6710:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6714:	48 85 d2             	test   %rdx,%rdx
    6717:	74 4c                	je     6765 <fwp_closure_drop+0x85>
    6719:	0f b6 31             	movzbl (%rcx),%esi
    671c:	40 80 fe 02          	cmp    $0x2,%sil
    6720:	74 3e                	je     6760 <fwp_closure_drop+0x80>
    6722:	40 80 fe 01          	cmp    $0x1,%sil
    6726:	75 3d                	jne    6765 <fwp_closure_drop+0x85>
    6728:	8b 71 18             	mov    0x18(%rcx),%esi
    672b:	0f b7 c0             	movzwl %ax,%eax
    672e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6731:	48 0f af c6          	imul   %rsi,%rax
    6735:	48 c1 e8 20          	shr    $0x20,%rax
    6739:	48 39 c8             	cmp    %rcx,%rax
    673c:	73 27                	jae    6765 <fwp_closure_drop+0x85>
    673e:	48 01 c2             	add    %rax,%rdx
    6741:	0f b6 02             	movzbl (%rdx),%eax
    6744:	84 c0                	test   %al,%al
    6746:	74 1d                	je     6765 <fwp_closure_drop+0x85>
    6748:	3c 01                	cmp    $0x1,%al
    674a:	74 24                	je     6770 <fwp_closure_drop+0x90>
    674c:	3c ff                	cmp    $0xff,%al
    674e:	74 48                	je     6798 <fwp_closure_drop+0xb8>
    6750:	83 e8 01             	sub    $0x1,%eax
    6753:	88 02                	mov    %al,(%rdx)
    6755:	c3                   	ret
    6756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    675d:	00 00 00 
    6760:	66 85 c0             	test   %ax,%ax
    6763:	74 dc                	je     6741 <fwp_closure_drop+0x61>
    6765:	c3                   	ret
    6766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    676d:	00 00 00 
    6770:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6777:	ff ff 
    6779:	48 85 c0             	test   %rax,%rax
    677c:	74 12                	je     6790 <fwp_closure_drop+0xb0>
    677e:	48 89 fe             	mov    %rdi,%rsi
    6781:	48 89 c7             	mov    %rax,%rdi
    6784:	e9 77 da ff ff       	jmp    4200 <fwp_closure_drop_push>
    6789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6790:	e9 1b dc ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6795:	0f 1f 00             	nopl   (%rax)
    6798:	48 89 d0             	mov    %rdx,%rax
    679b:	48 8d 35 de bf 01 00 	lea    0x1bfde(%rip),%rsi        # 22780 <fwp_heap>
    67a2:	48 83 ec 18          	sub    $0x18,%rsp
    67a6:	48 c1 e8 11          	shr    $0x11,%rax
    67aa:	48 31 d0             	xor    %rdx,%rax
    67ad:	48 89 c1             	mov    %rax,%rcx
    67b0:	48 c1 e9 09          	shr    $0x9,%rcx
    67b4:	48 31 c8             	xor    %rcx,%rax
    67b7:	0f b6 c8             	movzbl %al,%ecx
    67ba:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    67c1:	00 
    67c2:	48 85 c0             	test   %rax,%rax
    67c5:	75 22                	jne    67e9 <fwp_closure_drop+0x109>
    67c7:	eb 59                	jmp    6822 <fwp_closure_drop+0x142>
    67c9:	90                   	nop
    67ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67d1:	00 00 00 00 
    67d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67dc:	00 00 00 00 
    67e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    67e4:	48 85 c0             	test   %rax,%rax
    67e7:	74 39                	je     6822 <fwp_closure_drop+0x142>
    67e9:	48 89 c1             	mov    %rax,%rcx
    67ec:	48 39 10             	cmp    %rdx,(%rax)
    67ef:	75 ef                	jne    67e0 <fwp_closure_drop+0x100>
    67f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    67f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    67f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    67fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6804:	74 05                	je     680b <fwp_closure_drop+0x12b>
    6806:	48 83 c4 18          	add    $0x18,%rsp
    680a:	c3                   	ret
    680b:	48 89 d7             	mov    %rdx,%rdi
    680e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6813:	e8 58 eb ff ff       	call   5370 <fwp_rc_forget_slot>
    6818:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    681d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6820:	eb e4                	jmp    6806 <fwp_closure_drop+0x126>
    6822:	48 8d 3d 77 7f 00 00 	lea    0x7f77(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6829:	e8 72 d9 ff ff       	call   41a0 <fwp_trap>
    682e:	66 90                	xchg   %ax,%ax

0000000000006830 <fwp_owned_tape_release>:
    6830:	48 85 ff             	test   %rdi,%rdi
    6833:	0f 84 f7 00 00 00    	je     6930 <fwp_owned_tape_release+0x100>
    6839:	41 54                	push   %r12
    683b:	55                   	push   %rbp
    683c:	53                   	push   %rbx
    683d:	48 8b 07             	mov    (%rdi),%rax
    6840:	48 85 c0             	test   %rax,%rax
    6843:	74 08                	je     684d <fwp_owned_tape_release+0x1d>
    6845:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6849:	48 89 50 08          	mov    %rdx,0x8(%rax)
    684d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6851:	48 85 d2             	test   %rdx,%rdx
    6854:	74 03                	je     6859 <fwp_owned_tape_release+0x29>
    6856:	48 89 02             	mov    %rax,(%rdx)
    6859:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    685d:	48 89 fb             	mov    %rdi,%rbx
    6860:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6864:	48 85 c0             	test   %rax,%rax
    6867:	0f 84 89 00 00 00    	je     68f6 <fwp_owned_tape_release+0xc6>
    686d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6871:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6875:	7e 47                	jle    68be <fwp_owned_tape_release+0x8e>
    6877:	31 ed                	xor    %ebp,%ebp
    6879:	eb 0d                	jmp    6888 <fwp_owned_tape_release+0x58>
    687b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6880:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6884:	48 8b 40 68          	mov    0x68(%rax),%rax
    6888:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    688c:	49 89 ec             	mov    %rbp,%r12
    688f:	48 83 c5 01          	add    $0x1,%rbp
    6893:	49 c1 e4 04          	shl    $0x4,%r12
    6897:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    689b:	ff d0                	call   *%rax
    689d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    68a1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    68a6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    68aa:	ff 50 68             	call   *0x68(%rax)
    68ad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    68b1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    68b5:	48 39 e8             	cmp    %rbp,%rax
    68b8:	7f c6                	jg     6880 <fwp_owned_tape_release+0x50>
    68ba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    68be:	31 ed                	xor    %ebp,%ebp
    68c0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    68c5:	7e 28                	jle    68ef <fwp_owned_tape_release+0xbf>
    68c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68ce:	00 00 
    68d0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    68d4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    68d8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    68dc:	74 07                	je     68e5 <fwp_owned_tape_release+0xb5>
    68de:	ff 52 68             	call   *0x68(%rdx)
    68e1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    68e5:	48 83 c5 01          	add    $0x1,%rbp
    68e9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    68ed:	7f e1                	jg     68d0 <fwp_owned_tape_release+0xa0>
    68ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    68f3:	ff 52 68             	call   *0x68(%rdx)
    68f6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    68fa:	e8 e1 fd ff ff       	call   66e0 <fwp_closure_drop>
    68ff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6903:	e8 d8 fd ff ff       	call   66e0 <fwp_closure_drop>
    6908:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    690c:	e8 cf fd ff ff       	call   66e0 <fwp_closure_drop>
    6911:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6915:	e8 96 ec ff ff       	call   55b0 <fwp_mem_free>
    691a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    691e:	e8 8d ec ff ff       	call   55b0 <fwp_mem_free>
    6923:	48 89 df             	mov    %rbx,%rdi
    6926:	5b                   	pop    %rbx
    6927:	5d                   	pop    %rbp
    6928:	41 5c                	pop    %r12
    692a:	e9 81 ec ff ff       	jmp    55b0 <fwp_mem_free>
    692f:	90                   	nop
    6930:	c3                   	ret
    6931:	0f 1f 40 00          	nopl   0x0(%rax)
    6935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    693c:	00 00 00 00 

0000000000006940 <fwp_tape_finish>:
    6940:	f3 0f 1e fa          	endbr64
    6944:	41 56                	push   %r14
    6946:	48 8d 3d 73 b7 01 00 	lea    0x1b773(%rip),%rdi        # 220c0 <fwp_tape_workspace>
    694d:	41 55                	push   %r13
    694f:	41 54                	push   %r12
    6951:	55                   	push   %rbp
    6952:	53                   	push   %rbx
    6953:	e8 18 d6 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6958:	48 83 3d a8 b7 01 00 	cmpq   $0x0,0x1b7a8(%rip)        # 22108 <fwp_ntapes>
    695f:	00 
    6960:	48 c7 05 3d b7 01 00 	movq   $0x0,0x1b73d(%rip)        # 220a8 <fwp_tape_cached_bytes>
    6967:	00 00 00 00 
    696b:	7e 68                	jle    69d5 <fwp_tape_finish+0x95>
    696d:	45 31 e4             	xor    %r12d,%r12d
    6970:	31 ed                	xor    %ebp,%ebp
    6972:	0f 1f 00             	nopl   (%rax)
    6975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    697c:	00 00 00 00 
    6980:	48 8b 1d 89 b7 01 00 	mov    0x1b789(%rip),%rbx        # 22110 <fwp_tapes>
    6987:	48 83 c5 01          	add    $0x1,%rbp
    698b:	4c 01 e3             	add    %r12,%rbx
    698e:	49 83 c4 68          	add    $0x68,%r12
    6992:	48 89 df             	mov    %rbx,%rdi
    6995:	e8 66 d2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    699a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    699e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    69a2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    69a6:	e8 15 ca ff ff       	call   33c0 <free@plt>
    69ab:	4c 89 f7             	mov    %r14,%rdi
    69ae:	e8 0d ca ff ff       	call   33c0 <free@plt>
    69b3:	4c 89 ef             	mov    %r13,%rdi
    69b6:	e8 05 ca ff ff       	call   33c0 <free@plt>
    69bb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    69bf:	e8 6c fe ff ff       	call   6830 <fwp_owned_tape_release>
    69c4:	48 39 2d 3d b7 01 00 	cmp    %rbp,0x1b73d(%rip)        # 22108 <fwp_ntapes>
    69cb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    69d2:	00 
    69d3:	7f ab                	jg     6980 <fwp_tape_finish+0x40>
    69d5:	48 8b 3d 34 b7 01 00 	mov    0x1b734(%rip),%rdi        # 22110 <fwp_tapes>
    69dc:	e8 df c9 ff ff       	call   33c0 <free@plt>
    69e1:	5b                   	pop    %rbx
    69e2:	5d                   	pop    %rbp
    69e3:	48 c7 05 22 b7 01 00 	movq   $0x0,0x1b722(%rip)        # 22110 <fwp_tapes>
    69ea:	00 00 00 00 
    69ee:	48 c7 05 07 b7 01 00 	movq   $0x0,0x1b707(%rip)        # 22100 <fwp_tapes_cap>
    69f5:	00 00 00 00 
    69f9:	41 5c                	pop    %r12
    69fb:	48 c7 05 02 b7 01 00 	movq   $0x0,0x1b702(%rip)        # 22108 <fwp_ntapes>
    6a02:	00 00 00 00 
    6a06:	41 5d                	pop    %r13
    6a08:	48 c7 05 e5 b6 01 00 	movq   $0x0,0x1b6e5(%rip)        # 220f8 <fwp_tape_next_slot>
    6a0f:	00 00 00 00 
    6a13:	41 5e                	pop    %r14
    6a15:	c3                   	ret
    6a16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a1d:	00 00 00 

0000000000006a20 <fwp_tape_scope_release>:
    6a20:	f3 0f 1e fa          	endbr64
    6a24:	41 55                	push   %r13
    6a26:	41 54                	push   %r12
    6a28:	55                   	push   %rbp
    6a29:	53                   	push   %rbx
    6a2a:	48 83 ec 58          	sub    $0x58,%rsp
    6a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a35:	00 00 
    6a37:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6a3c:	48 63 07             	movslq (%rdi),%rax
    6a3f:	85 c0                	test   %eax,%eax
    6a41:	0f 88 05 01 00 00    	js     6b4c <fwp_tape_scope_release+0x12c>
    6a47:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6a4e:	ec c4 4e 
    6a51:	48 89 fb             	mov    %rdi,%rbx
    6a54:	eb 3c                	jmp    6a92 <fwp_tape_scope_release+0x72>
    6a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a5d:	00 00 00 
    6a60:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6a65:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6a69:	e8 52 c9 ff ff       	call   33c0 <free@plt>
    6a6e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6a72:	e8 49 c9 ff ff       	call   33c0 <free@plt>
    6a77:	4c 89 ef             	mov    %r13,%rdi
    6a7a:	e8 41 c9 ff ff       	call   33c0 <free@plt>
    6a7f:	4c 89 e7             	mov    %r12,%rdi
    6a82:	e8 a9 fd ff ff       	call   6830 <fwp_owned_tape_release>
    6a87:	48 63 03             	movslq (%rbx),%rax
    6a8a:	85 c0                	test   %eax,%eax
    6a8c:	0f 88 ba 00 00 00    	js     6b4c <fwp_tape_scope_release+0x12c>
    6a92:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6a96:	48 8b 35 73 b6 01 00 	mov    0x1b673(%rip),%rsi        # 22110 <fwp_tapes>
    6a9d:	4c 01 c6             	add    %r8,%rsi
    6aa0:	48 89 f7             	mov    %rsi,%rdi
    6aa3:	e8 58 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6aa8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6aad:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6ab2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6ab9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6abd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6ac1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6ac8:	00 
    6ac9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6ace:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6ad2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6ad7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6adb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6ae0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6ae7:	00 
    6ae8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6aef:	00 
    6af0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6af7:	00 
    6af8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6afd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6b02:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6b06:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6b0a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6b0e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6b14:	77 18                	ja     6b2e <fwp_tape_scope_release+0x10e>
    6b16:	49 c1 f8 03          	sar    $0x3,%r8
    6b1a:	4c 0f af c5          	imul   %rbp,%r8
    6b1e:	4c 3b 05 d3 b5 01 00 	cmp    0x1b5d3(%rip),%r8        # 220f8 <fwp_tape_next_slot>
    6b25:	7d 07                	jge    6b2e <fwp_tape_scope_release+0x10e>
    6b27:	4c 89 05 ca b5 01 00 	mov    %r8,0x1b5ca(%rip)        # 220f8 <fwp_tape_next_slot>
    6b2e:	4d 85 e4             	test   %r12,%r12
    6b31:	0f 85 29 ff ff ff    	jne    6a60 <fwp_tape_scope_release+0x40>
    6b37:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6b3c:	e8 4f e3 ff ff       	call   4e90 <fwp_tape_buffers_release>
    6b41:	48 63 03             	movslq (%rbx),%rax
    6b44:	85 c0                	test   %eax,%eax
    6b46:	0f 89 46 ff ff ff    	jns    6a92 <fwp_tape_scope_release+0x72>
    6b4c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6b51:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b58:	00 00 
    6b5a:	75 0b                	jne    6b67 <fwp_tape_scope_release+0x147>
    6b5c:	48 83 c4 58          	add    $0x58,%rsp
    6b60:	5b                   	pop    %rbx
    6b61:	5d                   	pop    %rbp
    6b62:	41 5c                	pop    %r12
    6b64:	41 5d                	pop    %r13
    6b66:	c3                   	ret
    6b67:	e8 f4 c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6b6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006b70 <fwp_drop4>:
    6b70:	48 8b 0d e1 cf 01 00 	mov    0x1cfe1(%rip),%rcx        # 23b58 <fwp_heap+0x13d8>
    6b77:	48 89 f8             	mov    %rdi,%rax
    6b7a:	48 2b 05 af cf 01 00 	sub    0x1cfaf(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6b81:	48 c1 e1 10          	shl    $0x10,%rcx
    6b85:	48 39 c8             	cmp    %rcx,%rax
    6b88:	0f 83 42 01 00 00    	jae    6cd0 <fwp_drop4+0x160>
    6b8e:	48 83 ec 18          	sub    $0x18,%rsp
    6b92:	48 89 fa             	mov    %rdi,%rdx
    6b95:	4c 8d 05 e4 bb 01 00 	lea    0x1bbe4(%rip),%r8        # 22780 <fwp_heap>
    6b9c:	48 89 c1             	mov    %rax,%rcx
    6b9f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6ba6:	48 c1 e9 10          	shr    $0x10,%rcx
    6baa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6bae:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6bb2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6bb6:	48 85 c9             	test   %rcx,%rcx
    6bb9:	74 40                	je     6bfb <fwp_drop4+0x8b>
    6bbb:	0f b6 3e             	movzbl (%rsi),%edi
    6bbe:	40 80 ff 02          	cmp    $0x2,%dil
    6bc2:	74 3c                	je     6c00 <fwp_drop4+0x90>
    6bc4:	40 80 ff 01          	cmp    $0x1,%dil
    6bc8:	75 31                	jne    6bfb <fwp_drop4+0x8b>
    6bca:	8b 7e 18             	mov    0x18(%rsi),%edi
    6bcd:	0f b7 c0             	movzwl %ax,%eax
    6bd0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6bd3:	48 0f af c7          	imul   %rdi,%rax
    6bd7:	48 c1 e8 20          	shr    $0x20,%rax
    6bdb:	48 39 f0             	cmp    %rsi,%rax
    6bde:	73 1b                	jae    6bfb <fwp_drop4+0x8b>
    6be0:	48 01 c1             	add    %rax,%rcx
    6be3:	0f b6 01             	movzbl (%rcx),%eax
    6be6:	84 c0                	test   %al,%al
    6be8:	74 11                	je     6bfb <fwp_drop4+0x8b>
    6bea:	3c 01                	cmp    $0x1,%al
    6bec:	74 22                	je     6c10 <fwp_drop4+0xa0>
    6bee:	3c ff                	cmp    $0xff,%al
    6bf0:	0f 84 0a 01 00 00    	je     6d00 <fwp_drop4+0x190>
    6bf6:	83 e8 01             	sub    $0x1,%eax
    6bf9:	88 01                	mov    %al,(%rcx)
    6bfb:	48 83 c4 18          	add    $0x18,%rsp
    6bff:	c3                   	ret
    6c00:	66 85 c0             	test   %ax,%ax
    6c03:	74 de                	je     6be3 <fwp_drop4+0x73>
    6c05:	48 83 c4 18          	add    $0x18,%rsp
    6c09:	c3                   	ret
    6c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c10:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6c14:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6c1b:	48 89 f8             	mov    %rdi,%rax
    6c1e:	48 c1 e1 10          	shl    $0x10,%rcx
    6c22:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6c29:	48 39 c8             	cmp    %rcx,%rax
    6c2c:	73 62                	jae    6c90 <fwp_drop4+0x120>
    6c2e:	48 89 c1             	mov    %rax,%rcx
    6c31:	48 c1 e9 10          	shr    $0x10,%rcx
    6c35:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6c39:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6c3d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6c41:	48 85 c9             	test   %rcx,%rcx
    6c44:	74 4a                	je     6c90 <fwp_drop4+0x120>
    6c46:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6c4a:	41 80 f9 02          	cmp    $0x2,%r9b
    6c4e:	0f 84 9c 00 00 00    	je     6cf0 <fwp_drop4+0x180>
    6c54:	41 80 f9 01          	cmp    $0x1,%r9b
    6c58:	75 36                	jne    6c90 <fwp_drop4+0x120>
    6c5a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6c5e:	0f b7 c0             	movzwl %ax,%eax
    6c61:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6c64:	49 0f af c1          	imul   %r9,%rax
    6c68:	48 c1 e8 20          	shr    $0x20,%rax
    6c6c:	48 39 f0             	cmp    %rsi,%rax
    6c6f:	73 1f                	jae    6c90 <fwp_drop4+0x120>
    6c71:	48 01 c1             	add    %rax,%rcx
    6c74:	0f b6 01             	movzbl (%rcx),%eax
    6c77:	84 c0                	test   %al,%al
    6c79:	74 15                	je     6c90 <fwp_drop4+0x120>
    6c7b:	3c 01                	cmp    $0x1,%al
    6c7d:	74 59                	je     6cd8 <fwp_drop4+0x168>
    6c7f:	3c ff                	cmp    $0xff,%al
    6c81:	0f 84 ff 00 00 00    	je     6d86 <fwp_drop4+0x216>
    6c87:	83 e8 01             	sub    $0x1,%eax
    6c8a:	88 01                	mov    %al,(%rcx)
    6c8c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c90:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6c94:	48 89 d7             	mov    %rdx,%rdi
    6c97:	48 89 0c 24          	mov    %rcx,(%rsp)
    6c9b:	e8 30 f7 ff ff       	call   63d0 <fwp_rc_free_obj>
    6ca0:	4c 8d 05 d9 ba 01 00 	lea    0x1bad9(%rip),%r8        # 22780 <fwp_heap>
    6ca7:	48 8b 04 24          	mov    (%rsp),%rax
    6cab:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6cb2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6cb9:	48 c1 e2 10          	shl    $0x10,%rdx
    6cbd:	48 39 d0             	cmp    %rdx,%rax
    6cc0:	0f 83 35 ff ff ff    	jae    6bfb <fwp_drop4+0x8b>
    6cc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6cca:	e9 cd fe ff ff       	jmp    6b9c <fwp_drop4+0x2c>
    6ccf:	90                   	nop
    6cd0:	c3                   	ret
    6cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cd8:	48 89 14 24          	mov    %rdx,(%rsp)
    6cdc:	e8 ef f6 ff ff       	call   63d0 <fwp_rc_free_obj>
    6ce1:	48 8b 14 24          	mov    (%rsp),%rdx
    6ce5:	eb a9                	jmp    6c90 <fwp_drop4+0x120>
    6ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cee:	00 00 
    6cf0:	66 85 c0             	test   %ax,%ax
    6cf3:	75 9b                	jne    6c90 <fwp_drop4+0x120>
    6cf5:	e9 7a ff ff ff       	jmp    6c74 <fwp_drop4+0x104>
    6cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d00:	48 89 c8             	mov    %rcx,%rax
    6d03:	48 c1 e8 11          	shr    $0x11,%rax
    6d07:	48 31 c8             	xor    %rcx,%rax
    6d0a:	48 89 c2             	mov    %rax,%rdx
    6d0d:	48 c1 ea 09          	shr    $0x9,%rdx
    6d11:	48 31 d0             	xor    %rdx,%rax
    6d14:	0f b6 d0             	movzbl %al,%edx
    6d17:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6d1e:	00 
    6d1f:	48 85 c0             	test   %rax,%rax
    6d22:	75 29                	jne    6d4d <fwp_drop4+0x1dd>
    6d24:	e9 e3 00 00 00       	jmp    6e0c <fwp_drop4+0x29c>
    6d29:	90                   	nop
    6d2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d31:	00 00 00 00 
    6d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d3c:	00 00 00 00 
    6d40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6d44:	48 85 c0             	test   %rax,%rax
    6d47:	0f 84 bf 00 00 00    	je     6e0c <fwp_drop4+0x29c>
    6d4d:	48 89 c2             	mov    %rax,%rdx
    6d50:	48 39 08             	cmp    %rcx,(%rax)
    6d53:	75 eb                	jne    6d40 <fwp_drop4+0x1d0>
    6d55:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6d59:	48 83 ea 01          	sub    $0x1,%rdx
    6d5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6d68:	0f 85 8d fe ff ff    	jne    6bfb <fwp_drop4+0x8b>
    6d6e:	48 89 cf             	mov    %rcx,%rdi
    6d71:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d75:	e8 f6 e5 ff ff       	call   5370 <fwp_rc_forget_slot>
    6d7a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6d7e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6d81:	e9 75 fe ff ff       	jmp    6bfb <fwp_drop4+0x8b>
    6d86:	48 89 ce             	mov    %rcx,%rsi
    6d89:	48 c1 ee 11          	shr    $0x11,%rsi
    6d8d:	48 31 ce             	xor    %rcx,%rsi
    6d90:	48 89 f0             	mov    %rsi,%rax
    6d93:	48 c1 e8 09          	shr    $0x9,%rax
    6d97:	48 31 c6             	xor    %rax,%rsi
    6d9a:	40 0f b6 f6          	movzbl %sil,%esi
    6d9e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6da5:	00 
    6da6:	48 85 c0             	test   %rax,%rax
    6da9:	75 1e                	jne    6dc9 <fwp_drop4+0x259>
    6dab:	eb 5f                	jmp    6e0c <fwp_drop4+0x29c>
    6dad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6db4:	00 
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	74 43                	je     6e0c <fwp_drop4+0x29c>
    6dc9:	48 89 c6             	mov    %rax,%rsi
    6dcc:	48 39 08             	cmp    %rcx,(%rax)
    6dcf:	75 ef                	jne    6dc0 <fwp_drop4+0x250>
    6dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6dd5:	48 83 ee 01          	sub    $0x1,%rsi
    6dd9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6ddd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6de4:	0f 85 a6 fe ff ff    	jne    6c90 <fwp_drop4+0x120>
    6dea:	48 89 cf             	mov    %rcx,%rdi
    6ded:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6df2:	48 89 0c 24          	mov    %rcx,(%rsp)
    6df6:	e8 75 e5 ff ff       	call   5370 <fwp_rc_forget_slot>
    6dfb:	48 8b 0c 24          	mov    (%rsp),%rcx
    6dff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e04:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e07:	e9 84 fe ff ff       	jmp    6c90 <fwp_drop4+0x120>
    6e0c:	48 8d 3d 8d 79 00 00 	lea    0x798d(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6e13:	e8 88 d3 ff ff       	call   41a0 <fwp_trap>
    6e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e1f:	00 

0000000000006e20 <fwp_arg_drop37>:
    6e20:	f3 0f 1e fa          	endbr64
    6e24:	85 f6                	test   %esi,%esi
    6e26:	75 04                	jne    6e2c <fwp_arg_drop37+0xc>
    6e28:	85 d2                	test   %edx,%edx
    6e2a:	75 04                	jne    6e30 <fwp_arg_drop37+0x10>
    6e2c:	c3                   	ret
    6e2d:	0f 1f 00             	nopl   (%rax)
    6e30:	48 8b 3f             	mov    (%rdi),%rdi
    6e33:	e9 38 fd ff ff       	jmp    6b70 <fwp_drop4>
    6e38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e3f:	00 

0000000000006e40 <fwp_task_dispose>:
    6e40:	53                   	push   %rbx
    6e41:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6e45:	0f 84 fb c8 ff ff    	je     3746 <fwp_task_dispose.cold>
    6e4b:	48 89 fb             	mov    %rdi,%rbx
    6e4e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6e53:	0f 85 ed c8 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6e59:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6e5d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6e64:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6e6b:	00 
    6e6c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6e70:	48 85 ff             	test   %rdi,%rdi
    6e73:	74 07                	je     6e7c <fwp_task_dispose+0x3c>
    6e75:	48 85 c0             	test   %rax,%rax
    6e78:	74 02                	je     6e7c <fwp_task_dispose+0x3c>
    6e7a:	ff d0                	call   *%rax
    6e7c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6e83:	e8 28 e7 ff ff       	call   55b0 <fwp_mem_free>
    6e88:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6e8f:	00 00 00 00 
    6e93:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6e97:	74 6f                	je     6f08 <fwp_task_dispose+0xc8>
    6e99:	48 8b 15 b8 cc 01 00 	mov    0x1ccb8(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    6ea0:	48 89 d8             	mov    %rbx,%rax
    6ea3:	48 2b 05 86 cc 01 00 	sub    0x1cc86(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6eaa:	48 c1 e2 10          	shl    $0x10,%rdx
    6eae:	48 39 d0             	cmp    %rdx,%rax
    6eb1:	73 4c                	jae    6eff <fwp_task_dispose+0xbf>
    6eb3:	48 89 c2             	mov    %rax,%rdx
    6eb6:	48 c1 ea 10          	shr    $0x10,%rdx
    6eba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ebe:	48 8b 15 b3 cc 01 00 	mov    0x1ccb3(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    6ec5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ec9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ecd:	48 85 c9             	test   %rcx,%rcx
    6ed0:	74 2d                	je     6eff <fwp_task_dispose+0xbf>
    6ed2:	0f b6 32             	movzbl (%rdx),%esi
    6ed5:	40 80 fe 02          	cmp    $0x2,%sil
    6ed9:	74 3d                	je     6f18 <fwp_task_dispose+0xd8>
    6edb:	40 80 fe 01          	cmp    $0x1,%sil
    6edf:	75 1e                	jne    6eff <fwp_task_dispose+0xbf>
    6ee1:	8b 72 18             	mov    0x18(%rdx),%esi
    6ee4:	0f b7 c0             	movzwl %ax,%eax
    6ee7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6eea:	48 0f af c6          	imul   %rsi,%rax
    6eee:	48 c1 e8 20          	shr    $0x20,%rax
    6ef2:	48 39 d0             	cmp    %rdx,%rax
    6ef5:	73 08                	jae    6eff <fwp_task_dispose+0xbf>
    6ef7:	48 01 c1             	add    %rax,%rcx
    6efa:	80 39 01             	cmpb   $0x1,(%rcx)
    6efd:	74 09                	je     6f08 <fwp_task_dispose+0xc8>
    6eff:	5b                   	pop    %rbx
    6f00:	c3                   	ret
    6f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f08:	48 89 df             	mov    %rbx,%rdi
    6f0b:	5b                   	pop    %rbx
    6f0c:	e9 9f e6 ff ff       	jmp    55b0 <fwp_mem_free>
    6f11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f18:	66 85 c0             	test   %ax,%ax
    6f1b:	74 dd                	je     6efa <fwp_task_dispose+0xba>
    6f1d:	5b                   	pop    %rbx
    6f1e:	c3                   	ret
    6f1f:	90                   	nop

0000000000006f20 <fwp_free_zombie>:
    6f20:	48 8b 15 29 b8 01 00 	mov    0x1b829(%rip),%rdx        # 22750 <fwp_zombie>
    6f27:	48 85 d2             	test   %rdx,%rdx
    6f2a:	0f 84 98 00 00 00    	je     6fc8 <fwp_free_zombie+0xa8>
    6f30:	48 3b 15 29 b8 01 00 	cmp    0x1b829(%rip),%rdx        # 22760 <fwp_cur>
    6f37:	0f 84 8b 00 00 00    	je     6fc8 <fwp_free_zombie+0xa8>
    6f3d:	48 83 ec 18          	sub    $0x18,%rsp
    6f41:	48 63 05 e4 b1 01 00 	movslq 0x1b1e4(%rip),%rax        # 2212c <fwp_stack_pool_n>
    6f48:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6f4c:	83 f8 3f             	cmp    $0x3f,%eax
    6f4f:	7f 7f                	jg     6fd0 <fwp_free_zombie+0xb0>
    6f51:	8d 48 01             	lea    0x1(%rax),%ecx
    6f54:	89 0d d2 b1 01 00    	mov    %ecx,0x1b1d2(%rip)        # 2212c <fwp_stack_pool_n>
    6f5a:	48 8d 0d df b1 01 00 	lea    0x1b1df(%rip),%rcx        # 22140 <fwp_stack_pool>
    6f61:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6f65:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6f6c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f70:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6f77:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6f7b:	48 85 c9             	test   %rcx,%rcx
    6f7e:	0f 84 fc 00 00 00    	je     7080 <fwp_free_zombie+0x160>
    6f84:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6f8b:	48 85 c0             	test   %rax,%rax
    6f8e:	74 07                	je     6f97 <fwp_free_zombie+0x77>
    6f90:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6f97:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6f9a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f9e:	48 c7 05 a7 b7 01 00 	movq   $0x0,0x1b7a7(%rip)        # 22750 <fwp_zombie>
    6fa5:	00 00 00 00 
    6fa9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6fb0:	85 c0                	test   %eax,%eax
    6fb2:	74 34                	je     6fe8 <fwp_free_zombie+0xc8>
    6fb4:	83 f8 01             	cmp    $0x1,%eax
    6fb7:	0f 84 b3 00 00 00    	je     7070 <fwp_free_zombie+0x150>
    6fbd:	48 83 c4 18          	add    $0x18,%rsp
    6fc1:	c3                   	ret
    6fc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fc8:	c3                   	ret
    6fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fd0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6fd4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fd9:	e8 02 c6 ff ff       	call   35e0 <munmap@plt>
    6fde:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fe3:	eb 80                	jmp    6f65 <fwp_free_zombie+0x45>
    6fe5:	0f 1f 00             	nopl   (%rax)
    6fe8:	48 8b 0d 69 cb 01 00 	mov    0x1cb69(%rip),%rcx        # 23b58 <fwp_heap+0x13d8>
    6fef:	48 89 d0             	mov    %rdx,%rax
    6ff2:	48 2b 05 37 cb 01 00 	sub    0x1cb37(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    6ff9:	48 c1 e1 10          	shl    $0x10,%rcx
    6ffd:	48 39 c8             	cmp    %rcx,%rax
    7000:	73 bb                	jae    6fbd <fwp_free_zombie+0x9d>
    7002:	48 89 c1             	mov    %rax,%rcx
    7005:	48 c1 e9 10          	shr    $0x10,%rcx
    7009:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    700d:	48 8b 0d 64 cb 01 00 	mov    0x1cb64(%rip),%rcx        # 23b78 <fwp_heap+0x13f8>
    7014:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7018:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    701c:	48 85 c9             	test   %rcx,%rcx
    701f:	74 9c                	je     6fbd <fwp_free_zombie+0x9d>
    7021:	0f b6 3e             	movzbl (%rsi),%edi
    7024:	40 80 ff 02          	cmp    $0x2,%dil
    7028:	74 66                	je     7090 <fwp_free_zombie+0x170>
    702a:	40 80 ff 01          	cmp    $0x1,%dil
    702e:	75 8d                	jne    6fbd <fwp_free_zombie+0x9d>
    7030:	8b 7e 18             	mov    0x18(%rsi),%edi
    7033:	0f b7 c0             	movzwl %ax,%eax
    7036:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7039:	48 0f af c7          	imul   %rdi,%rax
    703d:	48 c1 e8 20          	shr    $0x20,%rax
    7041:	48 39 f0             	cmp    %rsi,%rax
    7044:	0f 83 73 ff ff ff    	jae    6fbd <fwp_free_zombie+0x9d>
    704a:	48 01 c1             	add    %rax,%rcx
    704d:	0f b6 01             	movzbl (%rcx),%eax
    7050:	84 c0                	test   %al,%al
    7052:	0f 84 65 ff ff ff    	je     6fbd <fwp_free_zombie+0x9d>
    7058:	3c 01                	cmp    $0x1,%al
    705a:	74 14                	je     7070 <fwp_free_zombie+0x150>
    705c:	3c ff                	cmp    $0xff,%al
    705e:	74 3b                	je     709b <fwp_free_zombie+0x17b>
    7060:	83 e8 01             	sub    $0x1,%eax
    7063:	88 01                	mov    %al,(%rcx)
    7065:	e9 53 ff ff ff       	jmp    6fbd <fwp_free_zombie+0x9d>
    706a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7070:	48 89 d7             	mov    %rdx,%rdi
    7073:	48 83 c4 18          	add    $0x18,%rsp
    7077:	e9 c4 fd ff ff       	jmp    6e40 <fwp_task_dispose>
    707c:	0f 1f 40 00          	nopl   0x0(%rax)
    7080:	48 89 05 a1 b6 01 00 	mov    %rax,0x1b6a1(%rip)        # 22728 <fwp_tasks_active>
    7087:	e9 ff fe ff ff       	jmp    6f8b <fwp_free_zombie+0x6b>
    708c:	0f 1f 40 00          	nopl   0x0(%rax)
    7090:	66 85 c0             	test   %ax,%ax
    7093:	0f 85 24 ff ff ff    	jne    6fbd <fwp_free_zombie+0x9d>
    7099:	eb b2                	jmp    704d <fwp_free_zombie+0x12d>
    709b:	48 89 ca             	mov    %rcx,%rdx
    709e:	48 8d 35 db b6 01 00 	lea    0x1b6db(%rip),%rsi        # 22780 <fwp_heap>
    70a5:	48 c1 ea 11          	shr    $0x11,%rdx
    70a9:	48 31 ca             	xor    %rcx,%rdx
    70ac:	48 89 d0             	mov    %rdx,%rax
    70af:	48 c1 e8 09          	shr    $0x9,%rax
    70b3:	48 31 c2             	xor    %rax,%rdx
    70b6:	0f b6 d2             	movzbl %dl,%edx
    70b9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    70c0:	00 
    70c1:	48 85 c0             	test   %rax,%rax
    70c4:	75 23                	jne    70e9 <fwp_free_zombie+0x1c9>
    70c6:	eb 5c                	jmp    7124 <fwp_free_zombie+0x204>
    70c8:	66 90                	xchg   %ax,%ax
    70ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70d1:	00 00 00 00 
    70d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70dc:	00 00 00 00 
    70e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    70e4:	48 85 c0             	test   %rax,%rax
    70e7:	74 3b                	je     7124 <fwp_free_zombie+0x204>
    70e9:	48 89 c2             	mov    %rax,%rdx
    70ec:	48 39 08             	cmp    %rcx,(%rax)
    70ef:	75 ef                	jne    70e0 <fwp_free_zombie+0x1c0>
    70f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    70f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    70f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7104:	0f 85 b3 fe ff ff    	jne    6fbd <fwp_free_zombie+0x9d>
    710a:	48 89 cf             	mov    %rcx,%rdi
    710d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7112:	e8 59 e2 ff ff       	call   5370 <fwp_rc_forget_slot>
    7117:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    711c:	c6 01 fe             	movb   $0xfe,(%rcx)
    711f:	e9 99 fe ff ff       	jmp    6fbd <fwp_free_zombie+0x9d>
    7124:	48 8d 3d 75 76 00 00 	lea    0x7675(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    712b:	e8 70 d0 ff ff       	call   41a0 <fwp_trap>

0000000000007130 <fwp_block>:
    7130:	48 83 ec 08          	sub    $0x8,%rsp
    7134:	48 8b 05 0d b6 01 00 	mov    0x1b60d(%rip),%rax        # 22748 <fwp_ready_head>
    713b:	48 85 c0             	test   %rax,%rax
    713e:	0f 84 1c 01 00 00    	je     7260 <fwp_block+0x130>
    7144:	90                   	nop
    7145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    714c:	00 00 00 00 
    7150:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7157:	48 89 15 ea b5 01 00 	mov    %rdx,0x1b5ea(%rip)        # 22748 <fwp_ready_head>
    715e:	48 85 d2             	test   %rdx,%rdx
    7161:	0f 84 19 01 00 00    	je     7280 <fwp_block+0x150>
    7167:	48 8b 15 f2 b5 01 00 	mov    0x1b5f2(%rip),%rdx        # 22760 <fwp_cur>
    716e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7172:	48 39 c2             	cmp    %rax,%rdx
    7175:	0f 84 d5 00 00 00    	je     7250 <fwp_block+0x120>
    717b:	48 8b 0d 66 d2 01 00 	mov    0x1d266(%rip),%rcx        # 243e8 <fwp_state_owners>
    7182:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7186:	48 89 05 d3 b5 01 00 	mov    %rax,0x1b5d3(%rip)        # 22760 <fwp_cur>
    718d:	f3 0f 7e 05 7b d2 01 	movq   0x1d27b(%rip),%xmm0        # 24410 <fwp_foreign_callbacks>
    7194:	00 
    7195:	0f 16 05 64 d2 01 00 	movhps 0x1d264(%rip),%xmm0        # 24400 <fwp_state>
    719c:	f3 0f 7e 0d 64 d2 01 	movq   0x1d264(%rip),%xmm1        # 24408 <fwp_handlers>
    71a3:	00 
    71a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    71ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    71b2:	0f 16 0d 5f d2 01 00 	movhps 0x1d25f(%rip),%xmm1        # 24418 <fwp_cleanups>
    71b9:	f3 0f 7e 05 37 d2 01 	movq   0x1d237(%rip),%xmm0        # 243f8 <fwp_state_len>
    71c0:	00 
    71c1:	0f 16 05 28 d2 01 00 	movhps 0x1d228(%rip),%xmm0        # 243f0 <fwp_state_cap>
    71c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    71cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    71d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    71e1:	48 89 0d 20 d2 01 00 	mov    %rcx,0x1d220(%rip)        # 24408 <fwp_handlers>
    71e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    71ef:	48 89 0d 22 d2 01 00 	mov    %rcx,0x1d222(%rip)        # 24418 <fwp_cleanups>
    71f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    71fd:	48 89 0d 0c d2 01 00 	mov    %rcx,0x1d20c(%rip)        # 24410 <fwp_foreign_callbacks>
    7204:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    720b:	48 89 0d ee d1 01 00 	mov    %rcx,0x1d1ee(%rip)        # 24400 <fwp_state>
    7212:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7219:	48 89 0d d8 d1 01 00 	mov    %rcx,0x1d1d8(%rip)        # 243f8 <fwp_state_len>
    7220:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7227:	48 89 0d c2 d1 01 00 	mov    %rcx,0x1d1c2(%rip)        # 243f0 <fwp_state_cap>
    722e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7235:	48 89 0d ac d1 01 00 	mov    %rcx,0x1d1ac(%rip)        # 243e8 <fwp_state_owners>
    723c:	e8 4f c2 ff ff       	call   3490 <swapcontext@plt>
    7241:	f3 0f 1e fa          	endbr64
    7245:	e8 d6 fc ff ff       	call   6f20 <fwp_free_zombie>
    724a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7250:	8b 05 d2 ae 01 00    	mov    0x1aed2(%rip),%eax        # 22128 <fwp_slice>
    7256:	85 c0                	test   %eax,%eax
    7258:	74 36                	je     7290 <fwp_block+0x160>
    725a:	48 83 c4 08          	add    $0x8,%rsp
    725e:	c3                   	ret
    725f:	90                   	nop
    7260:	e8 5b dd ff ff       	call   4fc0 <fwp_poll_events>
    7265:	48 8b 05 dc b4 01 00 	mov    0x1b4dc(%rip),%rax        # 22748 <fwp_ready_head>
    726c:	48 85 c0             	test   %rax,%rax
    726f:	0f 85 db fe ff ff    	jne    7150 <fwp_block+0x20>
    7275:	eb e9                	jmp    7260 <fwp_block+0x130>
    7277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    727e:	00 00 
    7280:	48 c7 05 b5 b4 01 00 	movq   $0x0,0x1b4b5(%rip)        # 22740 <fwp_ready_tail>
    7287:	00 00 00 00 
    728b:	e9 d7 fe ff ff       	jmp    7167 <fwp_block+0x37>
    7290:	48 8d 3d 8a 6e 00 00 	lea    0x6e8a(%rip),%rdi        # e121 <_IO_stdin_used+0x121>
    7297:	e8 04 c1 ff ff       	call   33a0 <getenv@plt>
    729c:	ba 10 27 00 00       	mov    $0x2710,%edx
    72a1:	48 85 c0             	test   %rax,%rax
    72a4:	74 05                	je     72ab <fwp_block+0x17b>
    72a6:	80 38 00             	cmpb   $0x0,(%rax)
    72a9:	75 0b                	jne    72b6 <fwp_block+0x186>
    72ab:	89 15 77 ae 01 00    	mov    %edx,0x1ae77(%rip)        # 22128 <fwp_slice>
    72b1:	48 83 c4 08          	add    $0x8,%rsp
    72b5:	c3                   	ret
    72b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    72bb:	31 f6                	xor    %esi,%esi
    72bd:	48 89 c7             	mov    %rax,%rdi
    72c0:	e8 8b c2 ff ff       	call   3550 <strtoll@plt>
    72c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    72c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    72d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    72d5:	0f 46 d0             	cmovbe %eax,%edx
    72d8:	eb d1                	jmp    72ab <fwp_block+0x17b>
    72da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000072e0 <fwp_caps173>:
    72e0:	f3 0f 1e fa          	endbr64
    72e4:	85 f6                	test   %esi,%esi
    72e6:	74 08                	je     72f0 <fwp_caps173+0x10>
    72e8:	c3                   	ret
    72e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f0:	48 8b 15 61 c8 01 00 	mov    0x1c861(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    72f7:	48 89 f8             	mov    %rdi,%rax
    72fa:	48 2b 05 2f c8 01 00 	sub    0x1c82f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7301:	48 c1 e2 10          	shl    $0x10,%rdx
    7305:	48 39 d0             	cmp    %rdx,%rax
    7308:	73 de                	jae    72e8 <fwp_caps173+0x8>
    730a:	48 89 c2             	mov    %rax,%rdx
    730d:	48 c1 ea 10          	shr    $0x10,%rdx
    7311:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7315:	48 8b 15 5c c8 01 00 	mov    0x1c85c(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    731c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7320:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7324:	48 85 c9             	test   %rcx,%rcx
    7327:	74 bf                	je     72e8 <fwp_caps173+0x8>
    7329:	0f b6 32             	movzbl (%rdx),%esi
    732c:	40 80 fe 02          	cmp    $0x2,%sil
    7330:	74 2e                	je     7360 <fwp_caps173+0x80>
    7332:	40 80 fe 01          	cmp    $0x1,%sil
    7336:	75 b0                	jne    72e8 <fwp_caps173+0x8>
    7338:	8b 72 18             	mov    0x18(%rdx),%esi
    733b:	0f b7 c0             	movzwl %ax,%eax
    733e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7341:	48 0f af c6          	imul   %rsi,%rax
    7345:	48 c1 e8 20          	shr    $0x20,%rax
    7349:	48 39 d0             	cmp    %rdx,%rax
    734c:	73 9a                	jae    72e8 <fwp_caps173+0x8>
    734e:	48 01 c1             	add    %rax,%rcx
    7351:	80 39 01             	cmpb   $0x1,(%rcx)
    7354:	75 92                	jne    72e8 <fwp_caps173+0x8>
    7356:	e9 55 e2 ff ff       	jmp    55b0 <fwp_mem_free>
    735b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7360:	66 85 c0             	test   %ax,%ax
    7363:	74 ec                	je     7351 <fwp_caps173+0x71>
    7365:	c3                   	ret
    7366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    736d:	00 00 00 

0000000000007370 <fwp_args37>:
    7370:	f3 0f 1e fa          	endbr64
    7374:	85 d2                	test   %edx,%edx
    7376:	74 04                	je     737c <fwp_args37+0xc>
    7378:	85 f6                	test   %esi,%esi
    737a:	74 04                	je     7380 <fwp_args37+0x10>
    737c:	c3                   	ret
    737d:	0f 1f 00             	nopl   (%rax)
    7380:	48 8b 15 d1 c7 01 00 	mov    0x1c7d1(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    7387:	48 8b 07             	mov    (%rdi),%rax
    738a:	48 2b 05 9f c7 01 00 	sub    0x1c79f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7391:	48 c1 e2 10          	shl    $0x10,%rdx
    7395:	48 39 d0             	cmp    %rdx,%rax
    7398:	73 e2                	jae    737c <fwp_args37+0xc>
    739a:	48 89 c2             	mov    %rax,%rdx
    739d:	48 c1 ea 10          	shr    $0x10,%rdx
    73a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73a5:	48 8b 15 cc c7 01 00 	mov    0x1c7cc(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    73ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73b0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    73b4:	48 85 ff             	test   %rdi,%rdi
    73b7:	74 c3                	je     737c <fwp_args37+0xc>
    73b9:	0f b6 0a             	movzbl (%rdx),%ecx
    73bc:	80 f9 02             	cmp    $0x2,%cl
    73bf:	74 2f                	je     73f0 <fwp_args37+0x80>
    73c1:	80 f9 01             	cmp    $0x1,%cl
    73c4:	75 b6                	jne    737c <fwp_args37+0xc>
    73c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73c9:	0f b7 c0             	movzwl %ax,%eax
    73cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73cf:	48 0f af c1          	imul   %rcx,%rax
    73d3:	48 c1 e8 20          	shr    $0x20,%rax
    73d7:	48 39 d0             	cmp    %rdx,%rax
    73da:	73 a0                	jae    737c <fwp_args37+0xc>
    73dc:	48 01 c7             	add    %rax,%rdi
    73df:	0f b6 07             	movzbl (%rdi),%eax
    73e2:	84 c0                	test   %al,%al
    73e4:	74 96                	je     737c <fwp_args37+0xc>
    73e6:	3c fd                	cmp    $0xfd,%al
    73e8:	77 0c                	ja     73f6 <fwp_args37+0x86>
    73ea:	83 c0 01             	add    $0x1,%eax
    73ed:	88 07                	mov    %al,(%rdi)
    73ef:	c3                   	ret
    73f0:	66 85 c0             	test   %ax,%ax
    73f3:	74 ea                	je     73df <fwp_args37+0x6f>
    73f5:	c3                   	ret
    73f6:	e9 55 de ff ff       	jmp    5250 <fwp_rc_wide_dup>
    73fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007400 <fwp_caps37>:
    7400:	f3 0f 1e fa          	endbr64
    7404:	48 83 ec 18          	sub    $0x18,%rsp
    7408:	8b 57 04             	mov    0x4(%rdi),%edx
    740b:	48 89 f8             	mov    %rdi,%rax
    740e:	85 d2                	test   %edx,%edx
    7410:	0f 84 9a 00 00 00    	je     74b0 <fwp_caps37+0xb0>
    7416:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    741a:	85 f6                	test   %esi,%esi
    741c:	0f 85 9e 00 00 00    	jne    74c0 <fwp_caps37+0xc0>
    7422:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7427:	e8 44 f7 ff ff       	call   6b70 <fwp_drop4>
    742c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7431:	48 8b 0d 20 c7 01 00 	mov    0x1c720(%rip),%rcx        # 23b58 <fwp_heap+0x13d8>
    7438:	48 89 c2             	mov    %rax,%rdx
    743b:	48 2b 15 ee c6 01 00 	sub    0x1c6ee(%rip),%rdx        # 23b30 <fwp_heap+0x13b0>
    7442:	48 c1 e1 10          	shl    $0x10,%rcx
    7446:	48 39 ca             	cmp    %rcx,%rdx
    7449:	73 6d                	jae    74b8 <fwp_caps37+0xb8>
    744b:	48 89 d1             	mov    %rdx,%rcx
    744e:	48 c1 e9 10          	shr    $0x10,%rcx
    7452:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7456:	48 8b 0d 1b c7 01 00 	mov    0x1c71b(%rip),%rcx        # 23b78 <fwp_heap+0x13f8>
    745d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7461:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7465:	48 85 f6             	test   %rsi,%rsi
    7468:	74 4e                	je     74b8 <fwp_caps37+0xb8>
    746a:	0f b6 39             	movzbl (%rcx),%edi
    746d:	40 80 ff 02          	cmp    $0x2,%dil
    7471:	0f 84 b9 00 00 00    	je     7530 <fwp_caps37+0x130>
    7477:	40 80 ff 01          	cmp    $0x1,%dil
    747b:	75 3b                	jne    74b8 <fwp_caps37+0xb8>
    747d:	8b 79 18             	mov    0x18(%rcx),%edi
    7480:	0f b7 d2             	movzwl %dx,%edx
    7483:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7486:	48 0f af d7          	imul   %rdi,%rdx
    748a:	48 c1 ea 20          	shr    $0x20,%rdx
    748e:	48 39 ca             	cmp    %rcx,%rdx
    7491:	73 25                	jae    74b8 <fwp_caps37+0xb8>
    7493:	48 01 d6             	add    %rdx,%rsi
    7496:	80 3e 01             	cmpb   $0x1,(%rsi)
    7499:	75 1d                	jne    74b8 <fwp_caps37+0xb8>
    749b:	48 89 c7             	mov    %rax,%rdi
    749e:	48 83 c4 18          	add    $0x18,%rsp
    74a2:	e9 09 e1 ff ff       	jmp    55b0 <fwp_mem_free>
    74a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74ae:	00 00 
    74b0:	85 f6                	test   %esi,%esi
    74b2:	0f 84 79 ff ff ff    	je     7431 <fwp_caps37+0x31>
    74b8:	48 83 c4 18          	add    $0x18,%rsp
    74bc:	c3                   	ret
    74bd:	0f 1f 00             	nopl   (%rax)
    74c0:	48 8b 05 91 c6 01 00 	mov    0x1c691(%rip),%rax        # 23b58 <fwp_heap+0x13d8>
    74c7:	48 2b 3d 62 c6 01 00 	sub    0x1c662(%rip),%rdi        # 23b30 <fwp_heap+0x13b0>
    74ce:	48 c1 e0 10          	shl    $0x10,%rax
    74d2:	48 39 c7             	cmp    %rax,%rdi
    74d5:	73 e1                	jae    74b8 <fwp_caps37+0xb8>
    74d7:	48 89 f8             	mov    %rdi,%rax
    74da:	48 c1 e8 10          	shr    $0x10,%rax
    74de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    74e2:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    74e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    74ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    74f1:	48 85 c0             	test   %rax,%rax
    74f4:	74 c2                	je     74b8 <fwp_caps37+0xb8>
    74f6:	0f b6 0a             	movzbl (%rdx),%ecx
    74f9:	80 f9 02             	cmp    $0x2,%cl
    74fc:	74 42                	je     7540 <fwp_caps37+0x140>
    74fe:	80 f9 01             	cmp    $0x1,%cl
    7501:	75 b5                	jne    74b8 <fwp_caps37+0xb8>
    7503:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7506:	0f b7 ff             	movzwl %di,%edi
    7509:	8b 52 1c             	mov    0x1c(%rdx),%edx
    750c:	48 0f af f9          	imul   %rcx,%rdi
    7510:	48 c1 ef 20          	shr    $0x20,%rdi
    7514:	48 39 d7             	cmp    %rdx,%rdi
    7517:	73 9f                	jae    74b8 <fwp_caps37+0xb8>
    7519:	48 01 f8             	add    %rdi,%rax
    751c:	0f b6 10             	movzbl (%rax),%edx
    751f:	84 d2                	test   %dl,%dl
    7521:	74 95                	je     74b8 <fwp_caps37+0xb8>
    7523:	80 fa fd             	cmp    $0xfd,%dl
    7526:	77 23                	ja     754b <fwp_caps37+0x14b>
    7528:	83 c2 01             	add    $0x1,%edx
    752b:	88 10                	mov    %dl,(%rax)
    752d:	eb 89                	jmp    74b8 <fwp_caps37+0xb8>
    752f:	90                   	nop
    7530:	66 85 d2             	test   %dx,%dx
    7533:	0f 85 7f ff ff ff    	jne    74b8 <fwp_caps37+0xb8>
    7539:	e9 58 ff ff ff       	jmp    7496 <fwp_caps37+0x96>
    753e:	66 90                	xchg   %ax,%ax
    7540:	66 85 ff             	test   %di,%di
    7543:	0f 85 6f ff ff ff    	jne    74b8 <fwp_caps37+0xb8>
    7549:	eb d1                	jmp    751c <fwp_caps37+0x11c>
    754b:	48 89 c7             	mov    %rax,%rdi
    754e:	48 83 c4 18          	add    $0x18,%rsp
    7552:	e9 f9 dc ff ff       	jmp    5250 <fwp_rc_wide_dup>
    7557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    755e:	00 00 

0000000000007560 <fwp_drop0>:
    7560:	f3 0f 1e fa          	endbr64
    7564:	48 8b 15 ed c5 01 00 	mov    0x1c5ed(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    756b:	48 89 f8             	mov    %rdi,%rax
    756e:	48 2b 05 bb c5 01 00 	sub    0x1c5bb(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7575:	48 c1 e2 10          	shl    $0x10,%rdx
    7579:	48 39 d0             	cmp    %rdx,%rax
    757c:	0f 83 36 01 00 00    	jae    76b8 <fwp_drop0+0x158>
    7582:	48 83 ec 18          	sub    $0x18,%rsp
    7586:	48 8d 35 f3 b1 01 00 	lea    0x1b1f3(%rip),%rsi        # 22780 <fwp_heap>
    758d:	48 89 c2             	mov    %rax,%rdx
    7590:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7597:	48 c1 ea 10          	shr    $0x10,%rdx
    759b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    759f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    75a3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    75a7:	48 85 d2             	test   %rdx,%rdx
    75aa:	74 42                	je     75ee <fwp_drop0+0x8e>
    75ac:	44 0f b6 01          	movzbl (%rcx),%r8d
    75b0:	41 80 f8 02          	cmp    $0x2,%r8b
    75b4:	74 42                	je     75f8 <fwp_drop0+0x98>
    75b6:	41 80 f8 01          	cmp    $0x1,%r8b
    75ba:	75 32                	jne    75ee <fwp_drop0+0x8e>
    75bc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    75c0:	0f b7 c0             	movzwl %ax,%eax
    75c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    75c6:	49 0f af c0          	imul   %r8,%rax
    75ca:	48 c1 e8 20          	shr    $0x20,%rax
    75ce:	48 39 c8             	cmp    %rcx,%rax
    75d1:	73 1b                	jae    75ee <fwp_drop0+0x8e>
    75d3:	48 01 c2             	add    %rax,%rdx
    75d6:	0f b6 02             	movzbl (%rdx),%eax
    75d9:	84 c0                	test   %al,%al
    75db:	74 11                	je     75ee <fwp_drop0+0x8e>
    75dd:	3c 01                	cmp    $0x1,%al
    75df:	74 27                	je     7608 <fwp_drop0+0xa8>
    75e1:	3c ff                	cmp    $0xff,%al
    75e3:	0f 84 e7 00 00 00    	je     76d0 <fwp_drop0+0x170>
    75e9:	83 e8 01             	sub    $0x1,%eax
    75ec:	88 02                	mov    %al,(%rdx)
    75ee:	48 83 c4 18          	add    $0x18,%rsp
    75f2:	c3                   	ret
    75f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    75f8:	66 85 c0             	test   %ax,%ax
    75fb:	74 d9                	je     75d6 <fwp_drop0+0x76>
    75fd:	48 83 c4 18          	add    $0x18,%rsp
    7601:	c3                   	ret
    7602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7608:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    760f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7616:	48 89 f8             	mov    %rdi,%rax
    7619:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    761d:	48 29 c8             	sub    %rcx,%rax
    7620:	48 c1 e2 10          	shl    $0x10,%rdx
    7624:	48 39 d0             	cmp    %rdx,%rax
    7627:	73 71                	jae    769a <fwp_drop0+0x13a>
    7629:	49 89 c2             	mov    %rax,%r10
    762c:	49 c1 ea 10          	shr    $0x10,%r10
    7630:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7634:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7638:	4d 8b 51 20          	mov    0x20(%r9),%r10
    763c:	4d 85 d2             	test   %r10,%r10
    763f:	74 59                	je     769a <fwp_drop0+0x13a>
    7641:	45 0f b6 19          	movzbl (%r9),%r11d
    7645:	41 80 fb 02          	cmp    $0x2,%r11b
    7649:	74 75                	je     76c0 <fwp_drop0+0x160>
    764b:	41 80 fb 01          	cmp    $0x1,%r11b
    764f:	75 49                	jne    769a <fwp_drop0+0x13a>
    7651:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7655:	0f b7 c0             	movzwl %ax,%eax
    7658:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    765c:	49 0f af c3          	imul   %r11,%rax
    7660:	48 c1 e8 20          	shr    $0x20,%rax
    7664:	4c 39 c8             	cmp    %r9,%rax
    7667:	73 31                	jae    769a <fwp_drop0+0x13a>
    7669:	49 01 c2             	add    %rax,%r10
    766c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7670:	75 28                	jne    769a <fwp_drop0+0x13a>
    7672:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7677:	e8 34 df ff ff       	call   55b0 <fwp_mem_free>
    767c:	48 8d 35 fd b0 01 00 	lea    0x1b0fd(%rip),%rsi        # 22780 <fwp_heap>
    7683:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7688:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    768f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7696:	48 c1 e2 10          	shl    $0x10,%rdx
    769a:	4c 89 c0             	mov    %r8,%rax
    769d:	48 29 c8             	sub    %rcx,%rax
    76a0:	48 39 d0             	cmp    %rdx,%rax
    76a3:	0f 83 45 ff ff ff    	jae    75ee <fwp_drop0+0x8e>
    76a9:	4c 89 c7             	mov    %r8,%rdi
    76ac:	e9 dc fe ff ff       	jmp    758d <fwp_drop0+0x2d>
    76b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76b8:	c3                   	ret
    76b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c0:	66 85 c0             	test   %ax,%ax
    76c3:	75 d5                	jne    769a <fwp_drop0+0x13a>
    76c5:	eb a5                	jmp    766c <fwp_drop0+0x10c>
    76c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76ce:	00 00 
    76d0:	48 89 d0             	mov    %rdx,%rax
    76d3:	48 c1 e8 11          	shr    $0x11,%rax
    76d7:	48 31 d0             	xor    %rdx,%rax
    76da:	48 89 c1             	mov    %rax,%rcx
    76dd:	48 c1 e9 09          	shr    $0x9,%rcx
    76e1:	48 31 c8             	xor    %rcx,%rax
    76e4:	0f b6 c8             	movzbl %al,%ecx
    76e7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    76ee:	00 
    76ef:	48 85 c0             	test   %rax,%rax
    76f2:	75 15                	jne    7709 <fwp_drop0+0x1a9>
    76f4:	eb 4e                	jmp    7744 <fwp_drop0+0x1e4>
    76f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    76fd:	00 00 00 
    7700:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7704:	48 85 c0             	test   %rax,%rax
    7707:	74 3b                	je     7744 <fwp_drop0+0x1e4>
    7709:	48 89 c1             	mov    %rax,%rcx
    770c:	48 39 10             	cmp    %rdx,(%rax)
    770f:	75 ef                	jne    7700 <fwp_drop0+0x1a0>
    7711:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7715:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7719:	48 89 48 08          	mov    %rcx,0x8(%rax)
    771d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7724:	0f 85 c4 fe ff ff    	jne    75ee <fwp_drop0+0x8e>
    772a:	48 89 d7             	mov    %rdx,%rdi
    772d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7732:	e8 39 dc ff ff       	call   5370 <fwp_rc_forget_slot>
    7737:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    773c:	c6 02 fe             	movb   $0xfe,(%rdx)
    773f:	e9 aa fe ff ff       	jmp    75ee <fwp_drop0+0x8e>
    7744:	48 8d 3d 55 70 00 00 	lea    0x7055(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    774b:	e8 50 ca ff ff       	call   41a0 <fwp_trap>

0000000000007750 <fwp_drop1>:
    7750:	f3 0f 1e fa          	endbr64
    7754:	48 8b 15 fd c3 01 00 	mov    0x1c3fd(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    775b:	48 89 f8             	mov    %rdi,%rax
    775e:	48 2b 05 cb c3 01 00 	sub    0x1c3cb(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7765:	48 c1 e2 10          	shl    $0x10,%rdx
    7769:	48 39 d0             	cmp    %rdx,%rax
    776c:	0f 83 36 01 00 00    	jae    78a8 <fwp_drop1+0x158>
    7772:	48 83 ec 18          	sub    $0x18,%rsp
    7776:	48 8d 35 03 b0 01 00 	lea    0x1b003(%rip),%rsi        # 22780 <fwp_heap>
    777d:	48 89 c2             	mov    %rax,%rdx
    7780:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7787:	48 c1 ea 10          	shr    $0x10,%rdx
    778b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    778f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7793:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7797:	48 85 d2             	test   %rdx,%rdx
    779a:	74 42                	je     77de <fwp_drop1+0x8e>
    779c:	44 0f b6 01          	movzbl (%rcx),%r8d
    77a0:	41 80 f8 02          	cmp    $0x2,%r8b
    77a4:	74 42                	je     77e8 <fwp_drop1+0x98>
    77a6:	41 80 f8 01          	cmp    $0x1,%r8b
    77aa:	75 32                	jne    77de <fwp_drop1+0x8e>
    77ac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    77b0:	0f b7 c0             	movzwl %ax,%eax
    77b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77b6:	49 0f af c0          	imul   %r8,%rax
    77ba:	48 c1 e8 20          	shr    $0x20,%rax
    77be:	48 39 c8             	cmp    %rcx,%rax
    77c1:	73 1b                	jae    77de <fwp_drop1+0x8e>
    77c3:	48 01 c2             	add    %rax,%rdx
    77c6:	0f b6 02             	movzbl (%rdx),%eax
    77c9:	84 c0                	test   %al,%al
    77cb:	74 11                	je     77de <fwp_drop1+0x8e>
    77cd:	3c 01                	cmp    $0x1,%al
    77cf:	74 27                	je     77f8 <fwp_drop1+0xa8>
    77d1:	3c ff                	cmp    $0xff,%al
    77d3:	0f 84 e7 00 00 00    	je     78c0 <fwp_drop1+0x170>
    77d9:	83 e8 01             	sub    $0x1,%eax
    77dc:	88 02                	mov    %al,(%rdx)
    77de:	48 83 c4 18          	add    $0x18,%rsp
    77e2:	c3                   	ret
    77e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    77e8:	66 85 c0             	test   %ax,%ax
    77eb:	74 d9                	je     77c6 <fwp_drop1+0x76>
    77ed:	48 83 c4 18          	add    $0x18,%rsp
    77f1:	c3                   	ret
    77f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77f8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77ff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7806:	48 89 f8             	mov    %rdi,%rax
    7809:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    780d:	48 29 c8             	sub    %rcx,%rax
    7810:	48 c1 e2 10          	shl    $0x10,%rdx
    7814:	48 39 d0             	cmp    %rdx,%rax
    7817:	73 71                	jae    788a <fwp_drop1+0x13a>
    7819:	49 89 c2             	mov    %rax,%r10
    781c:	49 c1 ea 10          	shr    $0x10,%r10
    7820:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7824:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7828:	4d 8b 51 20          	mov    0x20(%r9),%r10
    782c:	4d 85 d2             	test   %r10,%r10
    782f:	74 59                	je     788a <fwp_drop1+0x13a>
    7831:	45 0f b6 19          	movzbl (%r9),%r11d
    7835:	41 80 fb 02          	cmp    $0x2,%r11b
    7839:	74 75                	je     78b0 <fwp_drop1+0x160>
    783b:	41 80 fb 01          	cmp    $0x1,%r11b
    783f:	75 49                	jne    788a <fwp_drop1+0x13a>
    7841:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7845:	0f b7 c0             	movzwl %ax,%eax
    7848:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    784c:	49 0f af c3          	imul   %r11,%rax
    7850:	48 c1 e8 20          	shr    $0x20,%rax
    7854:	4c 39 c8             	cmp    %r9,%rax
    7857:	73 31                	jae    788a <fwp_drop1+0x13a>
    7859:	49 01 c2             	add    %rax,%r10
    785c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7860:	75 28                	jne    788a <fwp_drop1+0x13a>
    7862:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7867:	e8 44 dd ff ff       	call   55b0 <fwp_mem_free>
    786c:	48 8d 35 0d af 01 00 	lea    0x1af0d(%rip),%rsi        # 22780 <fwp_heap>
    7873:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7878:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    787f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7886:	48 c1 e2 10          	shl    $0x10,%rdx
    788a:	4c 89 c0             	mov    %r8,%rax
    788d:	48 29 c8             	sub    %rcx,%rax
    7890:	48 39 d0             	cmp    %rdx,%rax
    7893:	0f 83 45 ff ff ff    	jae    77de <fwp_drop1+0x8e>
    7899:	4c 89 c7             	mov    %r8,%rdi
    789c:	e9 dc fe ff ff       	jmp    777d <fwp_drop1+0x2d>
    78a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78a8:	c3                   	ret
    78a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	75 d5                	jne    788a <fwp_drop1+0x13a>
    78b5:	eb a5                	jmp    785c <fwp_drop1+0x10c>
    78b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78be:	00 00 
    78c0:	48 89 d0             	mov    %rdx,%rax
    78c3:	48 c1 e8 11          	shr    $0x11,%rax
    78c7:	48 31 d0             	xor    %rdx,%rax
    78ca:	48 89 c1             	mov    %rax,%rcx
    78cd:	48 c1 e9 09          	shr    $0x9,%rcx
    78d1:	48 31 c8             	xor    %rcx,%rax
    78d4:	0f b6 c8             	movzbl %al,%ecx
    78d7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    78de:	00 
    78df:	48 85 c0             	test   %rax,%rax
    78e2:	75 25                	jne    7909 <fwp_drop1+0x1b9>
    78e4:	eb 5e                	jmp    7944 <fwp_drop1+0x1f4>
    78e6:	0f 1f 40 00          	nopl   0x0(%rax)
    78ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78f1:	00 00 00 00 
    78f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78fc:	00 00 00 00 
    7900:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7904:	48 85 c0             	test   %rax,%rax
    7907:	74 3b                	je     7944 <fwp_drop1+0x1f4>
    7909:	48 89 c1             	mov    %rax,%rcx
    790c:	48 39 10             	cmp    %rdx,(%rax)
    790f:	75 ef                	jne    7900 <fwp_drop1+0x1b0>
    7911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7915:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7919:	48 89 48 08          	mov    %rcx,0x8(%rax)
    791d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7924:	0f 85 b4 fe ff ff    	jne    77de <fwp_drop1+0x8e>
    792a:	48 89 d7             	mov    %rdx,%rdi
    792d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7932:	e8 39 da ff ff       	call   5370 <fwp_rc_forget_slot>
    7937:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    793c:	c6 02 fe             	movb   $0xfe,(%rdx)
    793f:	e9 9a fe ff ff       	jmp    77de <fwp_drop1+0x8e>
    7944:	48 8d 3d 55 6e 00 00 	lea    0x6e55(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    794b:	e8 50 c8 ff ff       	call   41a0 <fwp_trap>

0000000000007950 <fwp_drop10>:
    7950:	48 8b 0d 01 c2 01 00 	mov    0x1c201(%rip),%rcx        # 23b58 <fwp_heap+0x13d8>
    7957:	48 89 f8             	mov    %rdi,%rax
    795a:	48 2b 05 cf c1 01 00 	sub    0x1c1cf(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7961:	48 c1 e1 10          	shl    $0x10,%rcx
    7965:	48 39 c8             	cmp    %rcx,%rax
    7968:	0f 83 c2 01 00 00    	jae    7b30 <fwp_drop10+0x1e0>
    796e:	48 83 ec 18          	sub    $0x18,%rsp
    7972:	48 89 fa             	mov    %rdi,%rdx
    7975:	48 8d 35 04 ae 01 00 	lea    0x1ae04(%rip),%rsi        # 22780 <fwp_heap>
    797c:	48 89 c1             	mov    %rax,%rcx
    797f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7986:	48 c1 e9 10          	shr    $0x10,%rcx
    798a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    798e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7992:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7996:	48 85 c9             	test   %rcx,%rcx
    7999:	74 46                	je     79e1 <fwp_drop10+0x91>
    799b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    799f:	41 80 f9 02          	cmp    $0x2,%r9b
    79a3:	0f 84 d7 00 00 00    	je     7a80 <fwp_drop10+0x130>
    79a9:	41 80 f9 01          	cmp    $0x1,%r9b
    79ad:	75 32                	jne    79e1 <fwp_drop10+0x91>
    79af:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    79b3:	0f b7 c0             	movzwl %ax,%eax
    79b6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    79b9:	49 0f af c1          	imul   %r9,%rax
    79bd:	48 c1 e8 20          	shr    $0x20,%rax
    79c1:	48 39 f8             	cmp    %rdi,%rax
    79c4:	73 1b                	jae    79e1 <fwp_drop10+0x91>
    79c6:	48 01 c1             	add    %rax,%rcx
    79c9:	0f b6 01             	movzbl (%rcx),%eax
    79cc:	84 c0                	test   %al,%al
    79ce:	74 11                	je     79e1 <fwp_drop10+0x91>
    79d0:	3c 01                	cmp    $0x1,%al
    79d2:	74 1c                	je     79f0 <fwp_drop10+0xa0>
    79d4:	3c ff                	cmp    $0xff,%al
    79d6:	0f 84 5c 01 00 00    	je     7b38 <fwp_drop10+0x1e8>
    79dc:	83 e8 01             	sub    $0x1,%eax
    79df:	88 01                	mov    %al,(%rcx)
    79e1:	48 83 c4 18          	add    $0x18,%rsp
    79e5:	c3                   	ret
    79e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79ed:	00 00 00 
    79f0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    79f7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    79fe:	48 89 d0             	mov    %rdx,%rax
    7a01:	49 89 d1             	mov    %rdx,%r9
    7a04:	48 c1 e1 10          	shl    $0x10,%rcx
    7a08:	48 29 f8             	sub    %rdi,%rax
    7a0b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7a0f:	78 7f                	js     7a90 <fwp_drop10+0x140>
    7a11:	48 39 c8             	cmp    %rcx,%rax
    7a14:	73 cb                	jae    79e1 <fwp_drop10+0x91>
    7a16:	48 89 c1             	mov    %rax,%rcx
    7a19:	48 c1 e9 10          	shr    $0x10,%rcx
    7a1d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a21:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7a25:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a29:	48 85 f6             	test   %rsi,%rsi
    7a2c:	74 b3                	je     79e1 <fwp_drop10+0x91>
    7a2e:	0f b6 39             	movzbl (%rcx),%edi
    7a31:	40 80 ff 02          	cmp    $0x2,%dil
    7a35:	74 39                	je     7a70 <fwp_drop10+0x120>
    7a37:	40 80 ff 01          	cmp    $0x1,%dil
    7a3b:	75 a4                	jne    79e1 <fwp_drop10+0x91>
    7a3d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a40:	0f b7 c0             	movzwl %ax,%eax
    7a43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a46:	48 0f af c7          	imul   %rdi,%rax
    7a4a:	48 c1 e8 20          	shr    $0x20,%rax
    7a4e:	48 39 c8             	cmp    %rcx,%rax
    7a51:	73 8e                	jae    79e1 <fwp_drop10+0x91>
    7a53:	48 01 c6             	add    %rax,%rsi
    7a56:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a59:	75 86                	jne    79e1 <fwp_drop10+0x91>
    7a5b:	48 89 d7             	mov    %rdx,%rdi
    7a5e:	48 83 c4 18          	add    $0x18,%rsp
    7a62:	e9 49 db ff ff       	jmp    55b0 <fwp_mem_free>
    7a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a6e:	00 00 
    7a70:	66 85 c0             	test   %ax,%ax
    7a73:	74 e1                	je     7a56 <fwp_drop10+0x106>
    7a75:	48 83 c4 18          	add    $0x18,%rsp
    7a79:	c3                   	ret
    7a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a80:	66 85 c0             	test   %ax,%ax
    7a83:	0f 84 40 ff ff ff    	je     79c9 <fwp_drop10+0x79>
    7a89:	48 83 c4 18          	add    $0x18,%rsp
    7a8d:	c3                   	ret
    7a8e:	66 90                	xchg   %ax,%ax
    7a90:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7a94:	48 39 c8             	cmp    %rcx,%rax
    7a97:	73 74                	jae    7b0d <fwp_drop10+0x1bd>
    7a99:	49 89 c2             	mov    %rax,%r10
    7a9c:	49 c1 ea 10          	shr    $0x10,%r10
    7aa0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7aa4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7aa8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7aac:	4d 85 d2             	test   %r10,%r10
    7aaf:	74 5c                	je     7b0d <fwp_drop10+0x1bd>
    7ab1:	45 0f b6 18          	movzbl (%r8),%r11d
    7ab5:	41 80 fb 02          	cmp    $0x2,%r11b
    7ab9:	74 6d                	je     7b28 <fwp_drop10+0x1d8>
    7abb:	41 80 fb 01          	cmp    $0x1,%r11b
    7abf:	75 4c                	jne    7b0d <fwp_drop10+0x1bd>
    7ac1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7ac5:	0f b7 c0             	movzwl %ax,%eax
    7ac8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7acc:	49 0f af c3          	imul   %r11,%rax
    7ad0:	48 c1 e8 20          	shr    $0x20,%rax
    7ad4:	4c 39 c0             	cmp    %r8,%rax
    7ad7:	73 34                	jae    7b0d <fwp_drop10+0x1bd>
    7ad9:	49 01 c2             	add    %rax,%r10
    7adc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7ae0:	75 2b                	jne    7b0d <fwp_drop10+0x1bd>
    7ae2:	4c 89 cf             	mov    %r9,%rdi
    7ae5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7aea:	e8 c1 da ff ff       	call   55b0 <fwp_mem_free>
    7aef:	48 8d 35 8a ac 01 00 	lea    0x1ac8a(%rip),%rsi        # 22780 <fwp_heap>
    7af6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7afb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b02:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b09:	48 c1 e1 10          	shl    $0x10,%rcx
    7b0d:	48 89 d0             	mov    %rdx,%rax
    7b10:	48 29 f8             	sub    %rdi,%rax
    7b13:	48 39 c8             	cmp    %rcx,%rax
    7b16:	0f 82 60 fe ff ff    	jb     797c <fwp_drop10+0x2c>
    7b1c:	e9 c0 fe ff ff       	jmp    79e1 <fwp_drop10+0x91>
    7b21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b28:	66 85 c0             	test   %ax,%ax
    7b2b:	75 e0                	jne    7b0d <fwp_drop10+0x1bd>
    7b2d:	eb ad                	jmp    7adc <fwp_drop10+0x18c>
    7b2f:	90                   	nop
    7b30:	c3                   	ret
    7b31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b38:	48 89 c8             	mov    %rcx,%rax
    7b3b:	48 c1 e8 11          	shr    $0x11,%rax
    7b3f:	48 31 c8             	xor    %rcx,%rax
    7b42:	48 89 c2             	mov    %rax,%rdx
    7b45:	48 c1 ea 09          	shr    $0x9,%rdx
    7b49:	48 31 d0             	xor    %rdx,%rax
    7b4c:	0f b6 d0             	movzbl %al,%edx
    7b4f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7b56:	00 
    7b57:	48 85 c0             	test   %rax,%rax
    7b5a:	75 0d                	jne    7b69 <fwp_drop10+0x219>
    7b5c:	eb 46                	jmp    7ba4 <fwp_drop10+0x254>
    7b5e:	66 90                	xchg   %ax,%ax
    7b60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7b64:	48 85 c0             	test   %rax,%rax
    7b67:	74 3b                	je     7ba4 <fwp_drop10+0x254>
    7b69:	48 89 c2             	mov    %rax,%rdx
    7b6c:	48 39 08             	cmp    %rcx,(%rax)
    7b6f:	75 ef                	jne    7b60 <fwp_drop10+0x210>
    7b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7b79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7b7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7b84:	0f 85 57 fe ff ff    	jne    79e1 <fwp_drop10+0x91>
    7b8a:	48 89 cf             	mov    %rcx,%rdi
    7b8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b92:	e8 d9 d7 ff ff       	call   5370 <fwp_rc_forget_slot>
    7b97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7b9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b9f:	e9 3d fe ff ff       	jmp    79e1 <fwp_drop10+0x91>
    7ba4:	48 8d 3d f5 6b 00 00 	lea    0x6bf5(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    7bab:	e8 f0 c5 ff ff       	call   41a0 <fwp_trap>

0000000000007bb0 <f37>:
    7bb0:	41 57                	push   %r15
    7bb2:	41 56                	push   %r14
    7bb4:	41 55                	push   %r13
    7bb6:	41 54                	push   %r12
    7bb8:	55                   	push   %rbp
    7bb9:	53                   	push   %rbx
    7bba:	48 83 ec 38          	sub    $0x38,%rsp
    7bbe:	48 8b 15 93 bf 01 00 	mov    0x1bf93(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    7bc5:	48 8b 0d 64 bf 01 00 	mov    0x1bf64(%rip),%rcx        # 23b30 <fwp_heap+0x13b0>
    7bcc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7bd3:	00 00 
    7bd5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7bda:	49 89 fc             	mov    %rdi,%r12
    7bdd:	48 c1 e2 10          	shl    $0x10,%rdx
    7be1:	48 85 ff             	test   %rdi,%rdi
    7be4:	0f 84 bc 02 00 00    	je     7ea6 <f37+0x2f6>
    7bea:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7bef:	48 89 d8             	mov    %rbx,%rax
    7bf2:	48 29 c8             	sub    %rcx,%rax
    7bf5:	48 39 d0             	cmp    %rdx,%rax
    7bf8:	0f 83 72 03 00 00    	jae    7f70 <f37+0x3c0>
    7bfe:	48 89 c2             	mov    %rax,%rdx
    7c01:	48 c1 ea 10          	shr    $0x10,%rdx
    7c05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c09:	48 8b 15 68 bf 01 00 	mov    0x1bf68(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    7c10:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c14:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7c18:	48 85 ff             	test   %rdi,%rdi
    7c1b:	0f 84 4f 03 00 00    	je     7f70 <f37+0x3c0>
    7c21:	0f b6 0a             	movzbl (%rdx),%ecx
    7c24:	80 f9 02             	cmp    $0x2,%cl
    7c27:	0f 84 53 02 00 00    	je     7e80 <f37+0x2d0>
    7c2d:	80 f9 01             	cmp    $0x1,%cl
    7c30:	75 24                	jne    7c56 <f37+0xa6>
    7c32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c35:	0f b7 c0             	movzwl %ax,%eax
    7c38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c3b:	48 0f af c1          	imul   %rcx,%rax
    7c3f:	48 c1 e8 20          	shr    $0x20,%rax
    7c43:	48 39 d0             	cmp    %rdx,%rax
    7c46:	73 0e                	jae    7c56 <f37+0xa6>
    7c48:	48 01 c7             	add    %rax,%rdi
    7c4b:	0f b6 07             	movzbl (%rdi),%eax
    7c4e:	84 c0                	test   %al,%al
    7c50:	0f 85 ca 02 00 00    	jne    7f20 <f37+0x370>
    7c56:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7c5b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7c60:	ba 01 00 00 00       	mov    $0x1,%edx
    7c65:	48 85 db             	test   %rbx,%rbx
    7c68:	74 13                	je     7c7d <f37+0xcd>
    7c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c70:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7c74:	48 83 c2 01          	add    $0x1,%rdx
    7c78:	48 85 db             	test   %rbx,%rbx
    7c7b:	75 f3                	jne    7c70 <f37+0xc0>
    7c7d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c82:	48 85 c0             	test   %rax,%rax
    7c85:	0f 84 15 03 00 00    	je     7fa0 <f37+0x3f0>
    7c8b:	31 db                	xor    %ebx,%ebx
    7c8d:	0f 1f 00             	nopl   (%rax)
    7c90:	48 8b 40 10          	mov    0x10(%rax),%rax
    7c94:	48 83 c3 01          	add    $0x1,%rbx
    7c98:	48 85 c0             	test   %rax,%rax
    7c9b:	75 f3                	jne    7c90 <f37+0xe0>
    7c9d:	48 39 d3             	cmp    %rdx,%rbx
    7ca0:	48 0f 47 da          	cmova  %rdx,%rbx
    7ca4:	48 89 d8             	mov    %rbx,%rax
    7ca7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7cab:	0f 85 8f 03 00 00    	jne    8040 <f37+0x490>
    7cb1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7cb5:	be 02 00 00 00       	mov    $0x2,%esi
    7cba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7cc1:	00 
    7cc2:	e8 e9 dd ff ff       	call   5ab0 <fwp_heap_alloc>
    7cc7:	48 89 28             	mov    %rbp,(%rax)
    7cca:	48 8b 15 87 be 01 00 	mov    0x1be87(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    7cd1:	49 89 c6             	mov    %rax,%r14
    7cd4:	48 2b 05 55 be 01 00 	sub    0x1be55(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7cdb:	48 c1 e2 10          	shl    $0x10,%rdx
    7cdf:	48 39 d0             	cmp    %rdx,%rax
    7ce2:	73 57                	jae    7d3b <f37+0x18b>
    7ce4:	48 89 c2             	mov    %rax,%rdx
    7ce7:	48 c1 ea 10          	shr    $0x10,%rdx
    7ceb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7cef:	48 8b 15 82 be 01 00 	mov    0x1be82(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    7cf6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7cfa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7cfe:	48 85 ed             	test   %rbp,%rbp
    7d01:	74 38                	je     7d3b <f37+0x18b>
    7d03:	0f b6 0a             	movzbl (%rdx),%ecx
    7d06:	80 f9 02             	cmp    $0x2,%cl
    7d09:	0f 84 51 02 00 00    	je     7f60 <f37+0x3b0>
    7d0f:	80 f9 01             	cmp    $0x1,%cl
    7d12:	75 27                	jne    7d3b <f37+0x18b>
    7d14:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d17:	0f b7 c0             	movzwl %ax,%eax
    7d1a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d1d:	48 0f af c1          	imul   %rcx,%rax
    7d21:	48 c1 e8 20          	shr    $0x20,%rax
    7d25:	48 39 d0             	cmp    %rdx,%rax
    7d28:	73 11                	jae    7d3b <f37+0x18b>
    7d2a:	48 01 c5             	add    %rax,%rbp
    7d2d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7d31:	0f 84 d5 02 00 00    	je     800c <f37+0x45c>
    7d37:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7d3b:	48 85 db             	test   %rbx,%rbx
    7d3e:	74 5d                	je     7d9d <f37+0x1ed>
    7d40:	48 c1 e3 04          	shl    $0x4,%rbx
    7d44:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7d49:	4c 89 f5             	mov    %r14,%rbp
    7d4c:	4d 89 e5             	mov    %r12,%r13
    7d4f:	4c 01 f3             	add    %r14,%rbx
    7d52:	0f 1f 00             	nopl   (%rax)
    7d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d5c:	00 00 00 00 
    7d60:	49 8b 45 08          	mov    0x8(%r13),%rax
    7d64:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7d68:	48 83 c5 10          	add    $0x10,%rbp
    7d6c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7d71:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7d75:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7d79:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7d7e:	e8 fd e2 ff ff       	call   6080 <w120>
    7d83:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7d88:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7d8c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7d90:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7d94:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7d98:	48 39 dd             	cmp    %rbx,%rbp
    7d9b:	75 c3                	jne    7d60 <f37+0x1b0>
    7d9d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7da2:	e8 c9 ed ff ff       	call   6b70 <fwp_drop4>
    7da7:	4c 89 e7             	mov    %r12,%rdi
    7daa:	e8 c1 ed ff ff       	call   6b70 <fwp_drop4>
    7daf:	4c 89 f7             	mov    %r14,%rdi
    7db2:	e8 49 e4 ff ff       	call   6200 <w176.constprop.0>
    7db7:	4c 89 f7             	mov    %r14,%rdi
    7dba:	48 89 c3             	mov    %rax,%rbx
    7dbd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7dc3:	e8 88 fb ff ff       	call   7950 <fwp_drop10>
    7dc8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7dce:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7dd3:	31 ff                	xor    %edi,%edi
    7dd5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7dda:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7dde:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7de3:	e8 e8 dd ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    7de8:	48 8b 15 69 bd 01 00 	mov    0x1bd69(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    7def:	48 89 c5             	mov    %rax,%rbp
    7df2:	48 2b 05 37 bd 01 00 	sub    0x1bd37(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7df9:	48 c1 e2 10          	shl    $0x10,%rdx
    7dfd:	48 39 d0             	cmp    %rdx,%rax
    7e00:	73 55                	jae    7e57 <f37+0x2a7>
    7e02:	48 89 c2             	mov    %rax,%rdx
    7e05:	48 c1 ea 10          	shr    $0x10,%rdx
    7e09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e0d:	48 8b 15 64 bd 01 00 	mov    0x1bd64(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    7e14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e18:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7e1c:	48 85 db             	test   %rbx,%rbx
    7e1f:	74 36                	je     7e57 <f37+0x2a7>
    7e21:	0f b6 0a             	movzbl (%rdx),%ecx
    7e24:	80 f9 02             	cmp    $0x2,%cl
    7e27:	0f 84 1b 01 00 00    	je     7f48 <f37+0x398>
    7e2d:	80 f9 01             	cmp    $0x1,%cl
    7e30:	75 25                	jne    7e57 <f37+0x2a7>
    7e32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e35:	0f b7 c0             	movzwl %ax,%eax
    7e38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e3b:	48 0f af c1          	imul   %rcx,%rax
    7e3f:	48 c1 e8 20          	shr    $0x20,%rax
    7e43:	48 39 d0             	cmp    %rdx,%rax
    7e46:	73 0f                	jae    7e57 <f37+0x2a7>
    7e48:	48 01 c3             	add    %rax,%rbx
    7e4b:	80 3b ff             	cmpb   $0xff,(%rbx)
    7e4e:	0f 84 ab 01 00 00    	je     7fff <f37+0x44f>
    7e54:	c6 03 01             	movb   $0x1,(%rbx)
    7e57:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7e5c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7e63:	00 00 
    7e65:	0f 85 d0 01 00 00    	jne    803b <f37+0x48b>
    7e6b:	48 83 c4 38          	add    $0x38,%rsp
    7e6f:	48 89 e8             	mov    %rbp,%rax
    7e72:	5b                   	pop    %rbx
    7e73:	5d                   	pop    %rbp
    7e74:	41 5c                	pop    %r12
    7e76:	41 5d                	pop    %r13
    7e78:	41 5e                	pop    %r14
    7e7a:	41 5f                	pop    %r15
    7e7c:	c3                   	ret
    7e7d:	0f 1f 00             	nopl   (%rax)
    7e80:	66 85 c0             	test   %ax,%ax
    7e83:	0f 85 cd fd ff ff    	jne    7c56 <f37+0xa6>
    7e89:	0f b6 07             	movzbl (%rdi),%eax
    7e8c:	84 c0                	test   %al,%al
    7e8e:	0f 84 c2 fd ff ff    	je     7c56 <f37+0xa6>
    7e94:	3c fd                	cmp    $0xfd,%al
    7e96:	0f 87 95 01 00 00    	ja     8031 <f37+0x481>
    7e9c:	83 c0 01             	add    $0x1,%eax
    7e9f:	88 07                	mov    %al,(%rdi)
    7ea1:	e9 b0 fd ff ff       	jmp    7c56 <f37+0xa6>
    7ea6:	48 f7 d9             	neg    %rcx
    7ea9:	48 39 d1             	cmp    %rdx,%rcx
    7eac:	0f 83 ee 00 00 00    	jae    7fa0 <f37+0x3f0>
    7eb2:	48 89 c8             	mov    %rcx,%rax
    7eb5:	48 c1 e8 10          	shr    $0x10,%rax
    7eb9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ebd:	48 8b 05 b4 bc 01 00 	mov    0x1bcb4(%rip),%rax        # 23b78 <fwp_heap+0x13f8>
    7ec4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7ec8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ecc:	48 85 ff             	test   %rdi,%rdi
    7ecf:	0f 84 cb 00 00 00    	je     7fa0 <f37+0x3f0>
    7ed5:	0f b6 02             	movzbl (%rdx),%eax
    7ed8:	3c 02                	cmp    $0x2,%al
    7eda:	0f 84 9a 00 00 00    	je     7f7a <f37+0x3ca>
    7ee0:	3c 01                	cmp    $0x1,%al
    7ee2:	0f 85 b8 00 00 00    	jne    7fa0 <f37+0x3f0>
    7ee8:	0f b7 c1             	movzwl %cx,%eax
    7eeb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7eee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ef1:	48 0f af c1          	imul   %rcx,%rax
    7ef5:	48 c1 e8 20          	shr    $0x20,%rax
    7ef9:	48 39 d0             	cmp    %rdx,%rax
    7efc:	0f 83 9e 00 00 00    	jae    7fa0 <f37+0x3f0>
    7f02:	48 01 c7             	add    %rax,%rdi
    7f05:	0f b6 07             	movzbl (%rdi),%eax
    7f08:	84 c0                	test   %al,%al
    7f0a:	0f 84 90 00 00 00    	je     7fa0 <f37+0x3f0>
    7f10:	31 db                	xor    %ebx,%ebx
    7f12:	0f 1f 00             	nopl   (%rax)
    7f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f1c:	00 00 00 00 
    7f20:	3c fd                	cmp    $0xfd,%al
    7f22:	0f 87 f1 00 00 00    	ja     8019 <f37+0x469>
    7f28:	83 c0 01             	add    $0x1,%eax
    7f2b:	88 07                	mov    %al,(%rdi)
    7f2d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7f32:	31 d2                	xor    %edx,%edx
    7f34:	4d 85 e4             	test   %r12,%r12
    7f37:	0f 85 1e fd ff ff    	jne    7c5b <f37+0xab>
    7f3d:	e9 3b fd ff ff       	jmp    7c7d <f37+0xcd>
    7f42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f48:	66 85 c0             	test   %ax,%ax
    7f4b:	0f 85 06 ff ff ff    	jne    7e57 <f37+0x2a7>
    7f51:	e9 f5 fe ff ff       	jmp    7e4b <f37+0x29b>
    7f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f5d:	00 00 00 
    7f60:	66 85 c0             	test   %ax,%ax
    7f63:	0f 85 d2 fd ff ff    	jne    7d3b <f37+0x18b>
    7f69:	e9 bf fd ff ff       	jmp    7d2d <f37+0x17d>
    7f6e:	66 90                	xchg   %ax,%ax
    7f70:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7f75:	e9 e6 fc ff ff       	jmp    7c60 <f37+0xb0>
    7f7a:	66 85 c9             	test   %cx,%cx
    7f7d:	75 21                	jne    7fa0 <f37+0x3f0>
    7f7f:	0f b6 07             	movzbl (%rdi),%eax
    7f82:	84 c0                	test   %al,%al
    7f84:	74 1a                	je     7fa0 <f37+0x3f0>
    7f86:	3c fd                	cmp    $0xfd,%al
    7f88:	0f 87 be 00 00 00    	ja     804c <f37+0x49c>
    7f8e:	83 c0 01             	add    $0x1,%eax
    7f91:	88 07                	mov    %al,(%rdi)
    7f93:	66 90                	xchg   %ax,%ax
    7f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f9c:	00 00 00 00 
    7fa0:	be 02 00 00 00       	mov    $0x2,%esi
    7fa5:	bf 08 00 00 00       	mov    $0x8,%edi
    7faa:	e8 01 db ff ff       	call   5ab0 <fwp_heap_alloc>
    7faf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7fb6:	48 8b 15 9b bb 01 00 	mov    0x1bb9b(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    7fbd:	49 89 c6             	mov    %rax,%r14
    7fc0:	48 2b 05 69 bb 01 00 	sub    0x1bb69(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    7fc7:	48 c1 e2 10          	shl    $0x10,%rdx
    7fcb:	48 39 d0             	cmp    %rdx,%rax
    7fce:	73 53                	jae    8023 <f37+0x473>
    7fd0:	48 89 c2             	mov    %rax,%rdx
    7fd3:	48 c1 ea 10          	shr    $0x10,%rdx
    7fd7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fdb:	48 8b 15 96 bb 01 00 	mov    0x1bb96(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    7fe2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fe6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7fea:	48 85 ed             	test   %rbp,%rbp
    7fed:	74 34                	je     8023 <f37+0x473>
    7fef:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7ff6:	00 00 
    7ff8:	31 db                	xor    %ebx,%ebx
    7ffa:	e9 04 fd ff ff       	jmp    7d03 <f37+0x153>
    7fff:	48 89 df             	mov    %rbx,%rdi
    8002:	e8 69 d3 ff ff       	call   5370 <fwp_rc_forget_slot>
    8007:	e9 48 fe ff ff       	jmp    7e54 <f37+0x2a4>
    800c:	48 89 ef             	mov    %rbp,%rdi
    800f:	e8 5c d3 ff ff       	call   5370 <fwp_rc_forget_slot>
    8014:	e9 1e fd ff ff       	jmp    7d37 <f37+0x187>
    8019:	e8 32 d2 ff ff       	call   5250 <fwp_rc_wide_dup>
    801e:	e9 0a ff ff ff       	jmp    7f2d <f37+0x37d>
    8023:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    802a:	00 00 
    802c:	e9 6c fd ff ff       	jmp    7d9d <f37+0x1ed>
    8031:	e8 1a d2 ff ff       	call   5250 <fwp_rc_wide_dup>
    8036:	e9 1b fc ff ff       	jmp    7c56 <f37+0xa6>
    803b:	e8 20 b4 ff ff       	call   3460 <__stack_chk_fail@plt>
    8040:	48 8d 3d e6 60 00 00 	lea    0x60e6(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    8047:	e8 54 c1 ff ff       	call   41a0 <fwp_trap>
    804c:	e8 ff d1 ff ff       	call   5250 <fwp_rc_wide_dup>
    8051:	e9 4a ff ff ff       	jmp    7fa0 <f37+0x3f0>
    8056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    805d:	00 00 00 

0000000000008060 <fwp_owned_entry37>:
    8060:	f3 0f 1e fa          	endbr64
    8064:	48 8b 3f             	mov    (%rdi),%rdi
    8067:	e9 44 fb ff ff       	jmp    7bb0 <f37>
    806c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008070 <e37>:
    8070:	f3 0f 1e fa          	endbr64
    8074:	53                   	push   %rbx
    8075:	48 8b 1f             	mov    (%rdi),%rbx
    8078:	48 89 df             	mov    %rbx,%rdi
    807b:	e8 20 e2 ff ff       	call   62a0 <fwp_rc_share>
    8080:	48 89 df             	mov    %rbx,%rdi
    8083:	e8 28 fb ff ff       	call   7bb0 <f37>
    8088:	48 89 c3             	mov    %rax,%rbx
    808b:	48 89 c7             	mov    %rax,%rdi
    808e:	e8 0d e2 ff ff       	call   62a0 <fwp_rc_share>
    8093:	48 89 d8             	mov    %rbx,%rax
    8096:	5b                   	pop    %rbx
    8097:	c3                   	ret
    8098:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    809f:	00 

00000000000080a0 <fwp_write>:
    80a0:	41 57                	push   %r15
    80a2:	41 56                	push   %r14
    80a4:	41 55                	push   %r13
    80a6:	41 54                	push   %r12
    80a8:	55                   	push   %rbp
    80a9:	53                   	push   %rbx
    80aa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    80b1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    80b8:	00 00 
    80ba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    80c1:	00 
    80c2:	49 89 d4             	mov    %rdx,%r12
    80c5:	8b 12                	mov    (%rdx),%edx
    80c7:	83 fa 19             	cmp    $0x19,%edx
    80ca:	77 6a                	ja     8136 <fwp_write+0x96>
    80cc:	48 89 f5             	mov    %rsi,%rbp
    80cf:	89 d0                	mov    %edx,%eax
    80d1:	89 ce                	mov    %ecx,%esi
    80d3:	48 89 fb             	mov    %rdi,%rbx
    80d6:	48 8d 0d 33 69 00 00 	lea    0x6933(%rip),%rcx        # ea10 <_IO_stdin_used+0xa10>
    80dd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    80e1:	48 01 c8             	add    %rcx,%rax
    80e4:	3e ff e0             	notrack jmp *%rax
    80e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ee:	00 00 
    80f0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    80f4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    80f8:	48 89 ca             	mov    %rcx,%rdx
    80fb:	48 85 c9             	test   %rcx,%rcx
    80fe:	0f 88 9c 0c 00 00    	js     8da0 <fwp_write+0xd00>
    8104:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    810b:	00 
    810c:	48 89 c6             	mov    %rax,%rsi
    810f:	4c 89 e7             	mov    %r12,%rdi
    8112:	e8 29 b9 ff ff       	call   3a40 <fwp_fmt_u128>
    8117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    811e:	00 00 
    8120:	4c 89 e7             	mov    %r12,%rdi
    8123:	e8 28 b3 ff ff       	call   3450 <strlen@plt>
    8128:	4c 89 e6             	mov    %r12,%rsi
    812b:	48 89 df             	mov    %rbx,%rdi
    812e:	48 89 c2             	mov    %rax,%rdx
    8131:	e8 3a bf ff ff       	call   4070 <buf_put>
    8136:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    813d:	00 
    813e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8145:	00 00 
    8147:	0f 85 28 04 00 00    	jne    8575 <fwp_write+0x4d5>
    814d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8154:	5b                   	pop    %rbx
    8155:	5d                   	pop    %rbp
    8156:	41 5c                	pop    %r12
    8158:	41 5d                	pop    %r13
    815a:	41 5e                	pop    %r14
    815c:	41 5f                	pop    %r15
    815e:	c3                   	ret
    815f:	90                   	nop
    8160:	49 89 e9             	mov    %rbp,%r9
    8163:	4c 8d 05 ed 5f 00 00 	lea    0x5fed(%rip),%r8        # e157 <_IO_stdin_used+0x157>
    816a:	b9 00 02 00 00       	mov    $0x200,%ecx
    816f:	ba 02 00 00 00       	mov    $0x2,%edx
    8174:	be 00 02 00 00       	mov    $0x200,%esi
    8179:	31 c0                	xor    %eax,%eax
    817b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8182:	00 
    8183:	e8 28 b2 ff ff       	call   33b0 <__snprintf_chk@plt>
    8188:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    818f:	00 
    8190:	e8 bb b2 ff ff       	call   3450 <strlen@plt>
    8195:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    819c:	00 
    819d:	48 89 df             	mov    %rbx,%rdi
    81a0:	48 89 c2             	mov    %rax,%rdx
    81a3:	e8 c8 be ff ff       	call   4070 <buf_put>
    81a8:	eb 8c                	jmp    8136 <fwp_write+0x96>
    81aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81b0:	49 89 e9             	mov    %rbp,%r9
    81b3:	4c 8d 05 98 5f 00 00 	lea    0x5f98(%rip),%r8        # e152 <_IO_stdin_used+0x152>
    81ba:	eb ae                	jmp    816a <fwp_write+0xca>
    81bc:	0f 1f 40 00          	nopl   0x0(%rax)
    81c0:	83 fa 13             	cmp    $0x13,%edx
    81c3:	48 8d 05 7e 5f 00 00 	lea    0x5f7e(%rip),%rax        # e148 <_IO_stdin_used+0x148>
    81ca:	48 8d 35 7c 5f 00 00 	lea    0x5f7c(%rip),%rsi        # e14d <_IO_stdin_used+0x14d>
    81d1:	ba 04 00 00 00       	mov    $0x4,%edx
    81d6:	48 0f 44 f0          	cmove  %rax,%rsi
    81da:	45 31 ed             	xor    %r13d,%r13d
    81dd:	e8 8e be ff ff       	call   4070 <buf_put>
    81e2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    81e7:	0f 84 a3 08 00 00    	je     8a90 <fwp_write+0x9f0>
    81ed:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    81f2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    81f7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    81fc:	48 89 df             	mov    %rbx,%rdi
    81ff:	49 0f 44 c5          	cmove  %r13,%rax
    8203:	31 c9                	xor    %ecx,%ecx
    8205:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    820a:	e8 91 fe ff ff       	call   80a0 <fwp_write>
    820f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8214:	0f 84 6e 09 00 00    	je     8b88 <fwp_write+0xae8>
    821a:	49 83 c5 01          	add    $0x1,%r13
    821e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8222:	0f 83 68 08 00 00    	jae    8a90 <fwp_write+0x9f0>
    8228:	ba 02 00 00 00       	mov    $0x2,%edx
    822d:	48 8d 35 63 5f 00 00 	lea    0x5f63(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8234:	48 89 df             	mov    %rbx,%rdi
    8237:	e8 34 be ff ff       	call   4070 <buf_put>
    823c:	eb af                	jmp    81ed <fwp_write+0x14d>
    823e:	66 90                	xchg   %ax,%ax
    8240:	ba 06 00 00 00       	mov    $0x6,%edx
    8245:	48 8d 35 24 5f 00 00 	lea    0x5f24(%rip),%rsi        # e170 <_IO_stdin_used+0x170>
    824c:	48 83 c5 10          	add    $0x10,%rbp
    8250:	e8 1b be ff ff       	call   4070 <buf_put>
    8255:	48 89 ef             	mov    %rbp,%rdi
    8258:	e8 f3 b1 ff ff       	call   3450 <strlen@plt>
    825d:	48 89 ee             	mov    %rbp,%rsi
    8260:	48 89 df             	mov    %rbx,%rdi
    8263:	48 89 c2             	mov    %rax,%rdx
    8266:	e8 05 be ff ff       	call   4070 <buf_put>
    826b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8270:	ba 01 00 00 00       	mov    $0x1,%edx
    8275:	48 89 df             	mov    %rbx,%rdi
    8278:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    827d:	e8 ee bd ff ff       	call   4070 <buf_put>
    8282:	e9 af fe ff ff       	jmp    8136 <fwp_write+0x96>
    8287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    828e:	00 00 
    8290:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8297:	00 
    8298:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    829f:	00 00 
    82a1:	0f 85 ce 02 00 00    	jne    8575 <fwp_write+0x4d5>
    82a7:	ba 0a 00 00 00       	mov    $0xa,%edx
    82ac:	48 8d 35 a9 5e 00 00 	lea    0x5ea9(%rip),%rsi        # e15c <_IO_stdin_used+0x15c>
    82b3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    82ba:	48 89 df             	mov    %rbx,%rdi
    82bd:	5b                   	pop    %rbx
    82be:	5d                   	pop    %rbp
    82bf:	41 5c                	pop    %r12
    82c1:	41 5d                	pop    %r13
    82c3:	41 5e                	pop    %r14
    82c5:	41 5f                	pop    %r15
    82c7:	e9 a4 bd ff ff       	jmp    4070 <buf_put>
    82cc:	0f 1f 40 00          	nopl   0x0(%rax)
    82d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    82d5:	4d 85 ed             	test   %r13,%r13
    82d8:	0f 84 02 0c 00 00    	je     8ee0 <fwp_write+0xe40>
    82de:	48 8d 35 bf 5e 00 00 	lea    0x5ebf(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    82e5:	4c 89 ef             	mov    %r13,%rdi
    82e8:	e8 43 b2 ff ff       	call   3530 <strcmp@plt>
    82ed:	41 89 c1             	mov    %eax,%r9d
    82f0:	85 c0                	test   %eax,%eax
    82f2:	0f 84 6c 0c 00 00    	je     8f64 <fwp_write+0xec4>
    82f8:	4c 89 ef             	mov    %r13,%rdi
    82fb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8300:	e8 4b b1 ff ff       	call   3450 <strlen@plt>
    8305:	4c 89 ee             	mov    %r13,%rsi
    8308:	48 89 df             	mov    %rbx,%rdi
    830b:	48 89 c2             	mov    %rax,%rdx
    830e:	e8 5d bd ff ff       	call   4070 <buf_put>
    8313:	ba 01 00 00 00       	mov    $0x1,%edx
    8318:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    831d:	48 89 df             	mov    %rbx,%rdi
    8320:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8325:	e8 46 bd ff ff       	call   4070 <buf_put>
    832a:	ba 01 00 00 00       	mov    $0x1,%edx
    832f:	4c 89 fe             	mov    %r15,%rsi
    8332:	48 89 df             	mov    %rbx,%rdi
    8335:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    833a:	e8 31 bd ff ff       	call   4070 <buf_put>
    833f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8344:	45 31 f6             	xor    %r14d,%r14d
    8347:	85 d2                	test   %edx,%edx
    8349:	0f 8e 81 0a 00 00    	jle    8dd0 <fwp_write+0xd30>
    834f:	45 31 ed             	xor    %r13d,%r13d
    8352:	4d 85 ed             	test   %r13,%r13
    8355:	0f 85 75 07 00 00    	jne    8ad0 <fwp_write+0xa30>
    835b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8362:	00 
    8363:	45 85 f6             	test   %r14d,%r14d
    8366:	0f 84 84 07 00 00    	je     8af0 <fwp_write+0xa50>
    836c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8371:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8376:	48 89 df             	mov    %rbx,%rdi
    8379:	49 83 c5 01          	add    $0x1,%r13
    837d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8381:	31 c9                	xor    %ecx,%ecx
    8383:	e8 18 fd ff ff       	call   80a0 <fwp_write>
    8388:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    838d:	7f c3                	jg     8352 <fwp_write+0x2b2>
    838f:	45 85 f6             	test   %r14d,%r14d
    8392:	0f 84 38 0a 00 00    	je     8dd0 <fwp_write+0xd30>
    8398:	b8 29 00 00 00       	mov    $0x29,%eax
    839d:	ba 01 00 00 00       	mov    $0x1,%edx
    83a2:	4c 89 fe             	mov    %r15,%rsi
    83a5:	48 89 df             	mov    %rbx,%rdi
    83a8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    83ac:	e8 bf bc ff ff       	call   4070 <buf_put>
    83b1:	e9 80 fd ff ff       	jmp    8136 <fwp_write+0x96>
    83b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    83bd:	00 00 00 
    83c0:	ba 01 00 00 00       	mov    $0x1,%edx
    83c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83ca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    83cf:	e8 9c bc ff ff       	call   4070 <buf_put>
    83d4:	48 85 ed             	test   %rbp,%rbp
    83d7:	0f 84 93 06 00 00    	je     8a70 <fwp_write+0x9d0>
    83dd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    83e1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    83e6:	31 c9                	xor    %ecx,%ecx
    83e8:	48 89 df             	mov    %rbx,%rdi
    83eb:	e8 b0 fc ff ff       	call   80a0 <fwp_write>
    83f0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    83f4:	48 85 ed             	test   %rbp,%rbp
    83f7:	0f 84 73 06 00 00    	je     8a70 <fwp_write+0x9d0>
    83fd:	ba 02 00 00 00       	mov    $0x2,%edx
    8402:	48 8d 35 8e 5d 00 00 	lea    0x5d8e(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8409:	48 89 df             	mov    %rbx,%rdi
    840c:	e8 5f bc ff ff       	call   4070 <buf_put>
    8411:	eb ca                	jmp    83dd <fwp_write+0x33d>
    8413:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8418:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    841c:	85 f6                	test   %esi,%esi
    841e:	0f 84 fc 07 00 00    	je     8c20 <fwp_write+0xb80>
    8424:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    842b:	00 
    842c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8433:	00 00 
    8435:	0f 85 3a 01 00 00    	jne    8575 <fwp_write+0x4d5>
    843b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    843f:	4c 89 ea             	mov    %r13,%rdx
    8442:	e9 6c fe ff ff       	jmp    82b3 <fwp_write+0x213>
    8447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    844e:	00 00 
    8450:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8455:	ba 01 00 00 00       	mov    $0x1,%edx
    845a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    845f:	48 89 ee             	mov    %rbp,%rsi
    8462:	e8 09 bc ff ff       	call   4070 <buf_put>
    8467:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    846c:	4c 89 e7             	mov    %r12,%rdi
    846f:	e8 dc af ff ff       	call   3450 <strlen@plt>
    8474:	4c 89 e6             	mov    %r12,%rsi
    8477:	48 89 df             	mov    %rbx,%rdi
    847a:	48 89 c2             	mov    %rax,%rdx
    847d:	e8 ee bb ff ff       	call   4070 <buf_put>
    8482:	ba 01 00 00 00       	mov    $0x1,%edx
    8487:	48 89 ee             	mov    %rbp,%rsi
    848a:	48 89 df             	mov    %rbx,%rdi
    848d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8492:	e8 d9 bb ff ff       	call   4070 <buf_put>
    8497:	e9 9a fc ff ff       	jmp    8136 <fwp_write+0x96>
    849c:	0f 1f 40 00          	nopl   0x0(%rax)
    84a0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    84a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    84a9:	0f 8a 8e 0b 00 00    	jp     903d <fwp_write+0xf9d>
    84af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    84b3:	66 0f 54 05 95 66 00 	andpd  0x6695(%rip),%xmm0        # eb50 <msg.8+0xd0>
    84ba:	00 
    84bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    84c0:	66 0f 2e 05 f0 65 00 	ucomisd 0x65f0(%rip),%xmm0        # eab8 <msg.8+0x38>
    84c7:	00 
    84c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    84cf:	00 
    84d0:	0f 87 b2 09 00 00    	ja     8e88 <fwp_write+0xde8>
    84d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84dd:	00 00 00 
    84e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    84e4:	89 ee                	mov    %ebp,%esi
    84e6:	4c 89 e7             	mov    %r12,%rdi
    84e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    84ee:	e8 cd bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    84f3:	31 f6                	xor    %esi,%esi
    84f5:	4c 89 e7             	mov    %r12,%rdi
    84f8:	e8 13 af ff ff       	call   3410 <strtod@plt>
    84fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8502:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8506:	7a 06                	jp     850e <fwp_write+0x46e>
    8508:	0f 84 e9 01 00 00    	je     86f7 <fwp_write+0x657>
    850e:	83 c5 01             	add    $0x1,%ebp
    8511:	83 fd 12             	cmp    $0x12,%ebp
    8514:	75 ca                	jne    84e0 <fwp_write+0x440>
    8516:	be 11 00 00 00       	mov    $0x11,%esi
    851b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    851f:	4c 89 e7             	mov    %r12,%rdi
    8522:	e8 99 bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8527:	e9 cb 01 00 00       	jmp    86f7 <fwp_write+0x657>
    852c:	0f 1f 40 00          	nopl   0x0(%rax)
    8530:	48 83 fd 01          	cmp    $0x1,%rbp
    8534:	0f 84 e6 08 00 00    	je     8e20 <fwp_write+0xd80>
    853a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    853e:	b8 02 00 00 00       	mov    $0x2,%eax
    8543:	ba 01 00 00 00       	mov    $0x1,%edx
    8548:	48 0f 44 d0          	cmove  %rax,%rdx
    854c:	48 8d 35 ed 5b 00 00 	lea    0x5bed(%rip),%rsi        # e140 <_IO_stdin_used+0x140>
    8553:	48 8d 05 eb 5b 00 00 	lea    0x5beb(%rip),%rax        # e145 <_IO_stdin_used+0x145>
    855a:	48 0f 44 f0          	cmove  %rax,%rsi
    855e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8565:	00 
    8566:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    856d:	00 00 
    856f:	0f 84 3e fd ff ff    	je     82b3 <fwp_write+0x213>
    8575:	e8 e6 ae ff ff       	call   3460 <__stack_chk_fail@plt>
    857a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8580:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8585:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    858a:	e8 21 ba ff ff       	call   3fb0 <buf_grow>
    858f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8593:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8599:	4c 03 0b             	add    (%rbx),%r9
    859c:	66 45 89 11          	mov    %r10w,(%r9)
    85a0:	45 85 e4             	test   %r12d,%r12d
    85a3:	0f 8e 07 05 00 00    	jle    8ab0 <fwp_write+0xa10>
    85a9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    85b0:	55 55 55 
    85b3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    85b8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    85bf:	aa aa aa 
    85c2:	49 83 c1 01          	add    $0x1,%r9
    85c6:	eb 45                	jmp    860d <fwp_write+0x56d>
    85c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85cf:	00 
    85d0:	be 01 00 00 00       	mov    $0x1,%esi
    85d5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    85da:	88 07                	mov    %al,(%rdi)
    85dc:	48 89 e8             	mov    %rbp,%rax
    85df:	49 f7 e8             	imul   %r8
    85e2:	48 89 e8             	mov    %rbp,%rax
    85e5:	48 c1 f8 3f          	sar    $0x3f,%rax
    85e9:	48 29 c2             	sub    %rax,%rdx
    85ec:	48 85 c9             	test   %rcx,%rcx
    85ef:	0f 95 c0             	setne  %al
    85f2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    85f6:	48 83 ef 01          	sub    $0x1,%rdi
    85fa:	48 21 c5             	and    %rax,%rbp
    85fd:	48 29 ea             	sub    %rbp,%rdx
    8600:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8604:	49 39 f9             	cmp    %rdi,%r9
    8607:	0f 84 a3 04 00 00    	je     8ab0 <fwp_write+0xa10>
    860d:	48 89 e8             	mov    %rbp,%rax
    8610:	49 f7 e8             	imul   %r8
    8613:	48 89 e8             	mov    %rbp,%rax
    8616:	48 c1 f8 3f          	sar    $0x3f,%rax
    861a:	48 89 d1             	mov    %rdx,%rcx
    861d:	48 29 c1             	sub    %rax,%rcx
    8620:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8624:	48 89 e9             	mov    %rbp,%rcx
    8627:	48 29 c1             	sub    %rax,%rcx
    862a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    862e:	49 f7 e2             	mul    %r10
    8631:	b8 30 00 00 00       	mov    $0x30,%eax
    8636:	48 89 d6             	mov    %rdx,%rsi
    8639:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    863d:	48 d1 ee             	shr    $1,%rsi
    8640:	48 01 f2             	add    %rsi,%rdx
    8643:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8647:	48 29 d6             	sub    %rdx,%rsi
    864a:	74 8e                	je     85da <fwp_write+0x53a>
    864c:	48 83 fe 01          	cmp    $0x1,%rsi
    8650:	0f 85 7a ff ff ff    	jne    85d0 <fwp_write+0x530>
    8656:	31 f6                	xor    %esi,%esi
    8658:	b8 2b 00 00 00       	mov    $0x2b,%eax
    865d:	e9 78 ff ff ff       	jmp    85da <fwp_write+0x53a>
    8662:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8668:	66 0f 6e cd          	movd   %ebp,%xmm1
    866c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    866f:	0f 8a c8 09 00 00    	jp     903d <fwp_write+0xf9d>
    8675:	0f 28 c1             	movaps %xmm1,%xmm0
    8678:	0f 54 05 c1 64 00 00 	andps  0x64c1(%rip),%xmm0        # eb40 <msg.8+0xc0>
    867f:	0f 2e 05 7e 59 00 00 	ucomiss 0x597e(%rip),%xmm0        # e004 <_IO_stdin_used+0x4>
    8686:	0f 87 24 08 00 00    	ja     8eb0 <fwp_write+0xe10>
    868c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8690:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8696:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    869d:	00 
    869e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    86a2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    86a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86ae:	00 00 
    86b0:	44 89 ee             	mov    %r13d,%esi
    86b3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    86b8:	4c 89 e7             	mov    %r12,%rdi
    86bb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    86c0:	e8 fb bd ff ff       	call   44c0 <fwp_format_g.constprop.0>
    86c5:	31 f6                	xor    %esi,%esi
    86c7:	4c 89 e7             	mov    %r12,%rdi
    86ca:	e8 e1 ad ff ff       	call   34b0 <strtof@plt>
    86cf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    86d4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    86d7:	7a 02                	jp     86db <fwp_write+0x63b>
    86d9:	74 1c                	je     86f7 <fwp_write+0x657>
    86db:	41 83 c5 01          	add    $0x1,%r13d
    86df:	41 83 fd 0a          	cmp    $0xa,%r13d
    86e3:	75 cb                	jne    86b0 <fwp_write+0x610>
    86e5:	be 09 00 00 00       	mov    $0x9,%esi
    86ea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    86ef:	4c 89 e7             	mov    %r12,%rdi
    86f2:	e8 c9 bd ff ff       	call   44c0 <fwp_format_g.constprop.0>
    86f7:	4c 89 e7             	mov    %r12,%rdi
    86fa:	e8 31 ba ff ff       	call   4130 <fwp_finish_float>
    86ff:	e9 1c fa ff ff       	jmp    8120 <fwp_write+0x80>
    8704:	0f 1f 40 00          	nopl   0x0(%rax)
    8708:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    870c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8710:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8717:	00 
    8718:	48 89 ef             	mov    %rbp,%rdi
    871b:	e8 20 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8720:	48 89 ef             	mov    %rbp,%rdi
    8723:	e8 28 ad ff ff       	call   3450 <strlen@plt>
    8728:	48 89 ee             	mov    %rbp,%rsi
    872b:	48 89 df             	mov    %rbx,%rdi
    872e:	48 89 c2             	mov    %rax,%rdx
    8731:	e8 3a b9 ff ff       	call   4070 <buf_put>
    8736:	e9 fb f9 ff ff       	jmp    8136 <fwp_write+0x96>
    873b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8740:	ba 06 00 00 00       	mov    $0x6,%edx
    8745:	48 8d 35 4e 5a 00 00 	lea    0x5a4e(%rip),%rsi        # e19a <_IO_stdin_used+0x19a>
    874c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8752:	e8 19 b9 ff ff       	call   4070 <buf_put>
    8757:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    875e:	ff ff 7f 
    8761:	48 23 55 00          	and    0x0(%rbp),%rdx
    8765:	0f 84 86 02 00 00    	je     89f1 <fwp_write+0x951>
    876b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8770:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8774:	48 85 d2             	test   %rdx,%rdx
    8777:	0f 84 ae 00 00 00    	je     882b <fwp_write+0x78b>
    877d:	8b 0a                	mov    (%rdx),%ecx
    877f:	83 f9 1c             	cmp    $0x1c,%ecx
    8782:	0f 84 58 06 00 00    	je     8de0 <fwp_write+0xd40>
    8788:	83 f9 1b             	cmp    $0x1b,%ecx
    878b:	0f 87 9a 00 00 00    	ja     882b <fwp_write+0x78b>
    8791:	be 01 00 00 00       	mov    $0x1,%esi
    8796:	48 d3 e6             	shl    %cl,%rsi
    8799:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    879f:	0f 85 4b 04 00 00    	jne    8bf0 <fwp_write+0xb50>
    87a5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    87ab:	0f 85 0f 04 00 00    	jne    8bc0 <fwp_write+0xb20>
    87b1:	83 e6 21             	and    $0x21,%esi
    87b4:	74 75                	je     882b <fwp_write+0x78b>
    87b6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    87bb:	48 85 ff             	test   %rdi,%rdi
    87be:	79 07                	jns    87c7 <fwp_write+0x727>
    87c0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    87c4:	4c 01 ee             	add    %r13,%rsi
    87c7:	48 0f be 3e          	movsbq (%rsi),%rdi
    87cb:	85 c9                	test   %ecx,%ecx
    87cd:	40 0f b6 f7          	movzbl %dil,%esi
    87d1:	48 0f 44 f7          	cmove  %rdi,%rsi
    87d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87dc:	00 00 00 00 
    87e0:	31 c9                	xor    %ecx,%ecx
    87e2:	48 89 df             	mov    %rbx,%rdi
    87e5:	49 83 c5 01          	add    $0x1,%r13
    87e9:	e8 b2 f8 ff ff       	call   80a0 <fwp_write>
    87ee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    87f5:	ff ff 7f 
    87f8:	48 23 55 00          	and    0x0(%rbp),%rdx
    87fc:	49 39 d5             	cmp    %rdx,%r13
    87ff:	0f 83 ec 01 00 00    	jae    89f1 <fwp_write+0x951>
    8805:	ba 02 00 00 00       	mov    $0x2,%edx
    880a:	48 89 df             	mov    %rbx,%rdi
    880d:	48 8d 35 83 59 00 00 	lea    0x5983(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8814:	e8 57 b8 ff ff       	call   4070 <buf_put>
    8819:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    881e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8822:	48 85 d2             	test   %rdx,%rdx
    8825:	0f 85 52 ff ff ff    	jne    877d <fwp_write+0x6dd>
    882b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8830:	48 85 ff             	test   %rdi,%rdi
    8833:	0f 88 cf 05 00 00    	js     8e08 <fwp_write+0xd68>
    8839:	48 8b 31             	mov    (%rcx),%rsi
    883c:	eb a2                	jmp    87e0 <fwp_write+0x740>
    883e:	66 90                	xchg   %ax,%ax
    8840:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8847:	00 
    8848:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    884f:	00 00 
    8851:	0f 85 1e fd ff ff    	jne    8575 <fwp_write+0x4d5>
    8857:	ba 08 00 00 00       	mov    $0x8,%edx
    885c:	48 8d 35 04 59 00 00 	lea    0x5904(%rip),%rsi        # e167 <_IO_stdin_used+0x167>
    8863:	e9 4b fa ff ff       	jmp    82b3 <fwp_write+0x213>
    8868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    886f:	00 
    8870:	89 e8                	mov    %ebp,%eax
    8872:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8879:	76 03                	jbe    887e <fwp_write+0x7de>
    887b:	8b 45 00             	mov    0x0(%rbp),%eax
    887e:	41 89 c6             	mov    %eax,%r14d
    8881:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8886:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    888b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    888f:	4c 89 ef             	mov    %r13,%rdi
    8892:	e8 b9 ab ff ff       	call   3450 <strlen@plt>
    8897:	4c 89 ee             	mov    %r13,%rsi
    889a:	48 89 df             	mov    %rbx,%rdi
    889d:	48 89 c2             	mov    %rax,%rdx
    88a0:	e8 cb b7 ff ff       	call   4070 <buf_put>
    88a5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    88aa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    88ae:	85 f6                	test   %esi,%esi
    88b0:	0f 8e 80 f8 ff ff    	jle    8136 <fwp_write+0x96>
    88b6:	45 31 ed             	xor    %r13d,%r13d
    88b9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    88be:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    88c3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    88c8:	ba 01 00 00 00       	mov    $0x1,%edx
    88cd:	4c 89 fe             	mov    %r15,%rsi
    88d0:	48 89 04 24          	mov    %rax,(%rsp)
    88d4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    88d9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    88dd:	48 89 df             	mov    %rbx,%rdi
    88e0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    88e4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    88e9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    88ee:	e8 7d b7 ff ff       	call   4070 <buf_put>
    88f3:	41 8b 06             	mov    (%r14),%eax
    88f6:	83 f8 0e             	cmp    $0xe,%eax
    88f9:	0f 84 71 02 00 00    	je     8b70 <fwp_write+0xad0>
    88ff:	83 f8 10             	cmp    $0x10,%eax
    8902:	0f 84 38 02 00 00    	je     8b40 <fwp_write+0xaa0>
    8908:	83 f8 0a             	cmp    $0xa,%eax
    890b:	0f 84 7f 04 00 00    	je     8d90 <fwp_write+0xcf0>
    8911:	0f 8f f9 00 00 00    	jg     8a10 <fwp_write+0x970>
    8917:	83 f8 03             	cmp    $0x3,%eax
    891a:	0f 8f 50 04 00 00    	jg     8d70 <fwp_write+0xcd0>
    8920:	85 c0                	test   %eax,%eax
    8922:	78 10                	js     8934 <fwp_write+0x894>
    8924:	48 8b 04 24          	mov    (%rsp),%rax
    8928:	48 c1 e8 3f          	shr    $0x3f,%rax
    892c:	85 c0                	test   %eax,%eax
    892e:	0f 85 f9 00 00 00    	jne    8a2d <fwp_write+0x98d>
    8934:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8939:	48 8b 34 24          	mov    (%rsp),%rsi
    893d:	31 c9                	xor    %ecx,%ecx
    893f:	48 89 df             	mov    %rbx,%rdi
    8942:	e8 59 f7 ff ff       	call   80a0 <fwp_write>
    8947:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    894c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8951:	49 83 c5 01          	add    $0x1,%r13
    8955:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8959:	0f 8f 5f ff ff ff    	jg     88be <fwp_write+0x81e>
    895f:	e9 d2 f7 ff ff       	jmp    8136 <fwp_write+0x96>
    8964:	0f 1f 40 00          	nopl   0x0(%rax)
    8968:	ba 06 00 00 00       	mov    $0x6,%edx
    896d:	48 8d 35 19 58 00 00 	lea    0x5819(%rip),%rsi        # e18d <_IO_stdin_used+0x18d>
    8974:	45 31 ed             	xor    %r13d,%r13d
    8977:	e8 f4 b6 ff ff       	call   4070 <buf_put>
    897c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8981:	75 19                	jne    899c <fwp_write+0x8fc>
    8983:	eb 6c                	jmp    89f1 <fwp_write+0x951>
    8985:	0f 1f 00             	nopl   (%rax)
    8988:	ba 02 00 00 00       	mov    $0x2,%edx
    898d:	48 8d 35 03 58 00 00 	lea    0x5803(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8994:	48 89 df             	mov    %rbx,%rdi
    8997:	e8 d4 b6 ff ff       	call   4070 <buf_put>
    899c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    89a2:	b9 00 02 00 00       	mov    $0x200,%ecx
    89a7:	31 c0                	xor    %eax,%eax
    89a9:	49 83 c5 01          	add    $0x1,%r13
    89ad:	4c 8d 05 e0 57 00 00 	lea    0x57e0(%rip),%r8        # e194 <_IO_stdin_used+0x194>
    89b4:	ba 02 00 00 00       	mov    $0x2,%edx
    89b9:	be 00 02 00 00       	mov    $0x200,%esi
    89be:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    89c5:	00 
    89c6:	e8 e5 a9 ff ff       	call   33b0 <__snprintf_chk@plt>
    89cb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    89d2:	00 
    89d3:	e8 78 aa ff ff       	call   3450 <strlen@plt>
    89d8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    89df:	00 
    89e0:	48 89 df             	mov    %rbx,%rdi
    89e3:	48 89 c2             	mov    %rax,%rdx
    89e6:	e8 85 b6 ff ff       	call   4070 <buf_put>
    89eb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    89ef:	72 97                	jb     8988 <fwp_write+0x8e8>
    89f1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89f6:	ba 01 00 00 00       	mov    $0x1,%edx
    89fb:	48 89 df             	mov    %rbx,%rdi
    89fe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8a03:	e8 68 b6 ff ff       	call   4070 <buf_put>
    8a08:	e9 29 f7 ff ff       	jmp    8136 <fwp_write+0x96>
    8a0d:	0f 1f 00             	nopl   (%rax)
    8a10:	83 f8 0b             	cmp    $0xb,%eax
    8a13:	0f 85 1b ff ff ff    	jne    8934 <fwp_write+0x894>
    8a19:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8a1e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8a22:	83 e0 01             	and    $0x1,%eax
    8a25:	85 c0                	test   %eax,%eax
    8a27:	0f 84 07 ff ff ff    	je     8934 <fwp_write+0x894>
    8a2d:	4c 89 fe             	mov    %r15,%rsi
    8a30:	48 89 df             	mov    %rbx,%rdi
    8a33:	ba 01 00 00 00       	mov    $0x1,%edx
    8a38:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8a3d:	e8 2e b6 ff ff       	call   4070 <buf_put>
    8a42:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8a47:	48 8b 34 24          	mov    (%rsp),%rsi
    8a4b:	31 c9                	xor    %ecx,%ecx
    8a4d:	48 89 df             	mov    %rbx,%rdi
    8a50:	e8 4b f6 ff ff       	call   80a0 <fwp_write>
    8a55:	ba 01 00 00 00       	mov    $0x1,%edx
    8a5a:	4c 89 fe             	mov    %r15,%rsi
    8a5d:	48 89 df             	mov    %rbx,%rdi
    8a60:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8a65:	e8 06 b6 ff ff       	call   4070 <buf_put>
    8a6a:	e9 d8 fe ff ff       	jmp    8947 <fwp_write+0x8a7>
    8a6f:	90                   	nop
    8a70:	ba 01 00 00 00       	mov    $0x1,%edx
    8a75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a7a:	48 89 df             	mov    %rbx,%rdi
    8a7d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8a82:	e8 e9 b5 ff ff       	call   4070 <buf_put>
    8a87:	e9 aa f6 ff ff       	jmp    8136 <fwp_write+0x96>
    8a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a90:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a95:	ba 01 00 00 00       	mov    $0x1,%edx
    8a9a:	48 89 df             	mov    %rbx,%rdi
    8a9d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8aa2:	e8 c9 b5 ff ff       	call   4070 <buf_put>
    8aa7:	e9 8a f6 ff ff       	jmp    8136 <fwp_write+0x96>
    8aac:	0f 1f 40 00          	nopl   0x0(%rax)
    8ab0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8ab4:	48 8b 13             	mov    (%rbx),%rdx
    8ab7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8abc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8ac0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8ac4:	e9 6d f6 ff ff       	jmp    8136 <fwp_write+0x96>
    8ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ad0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ad5:	48 8d 35 bb 56 00 00 	lea    0x56bb(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8adc:	48 89 df             	mov    %rbx,%rdi
    8adf:	e8 8c b5 ff ff       	call   4070 <buf_put>
    8ae4:	e9 72 f8 ff ff       	jmp    835b <fwp_write+0x2bb>
    8ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8af0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8af5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8afa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8afe:	48 89 f7             	mov    %rsi,%rdi
    8b01:	48 89 34 24          	mov    %rsi,(%rsp)
    8b05:	e8 46 a9 ff ff       	call   3450 <strlen@plt>
    8b0a:	48 8b 34 24          	mov    (%rsp),%rsi
    8b0e:	48 89 df             	mov    %rbx,%rdi
    8b11:	48 89 c2             	mov    %rax,%rdx
    8b14:	e8 57 b5 ff ff       	call   4070 <buf_put>
    8b19:	ba 03 00 00 00       	mov    $0x3,%edx
    8b1e:	48 8d 35 95 56 00 00 	lea    0x5695(%rip),%rsi        # e1ba <_IO_stdin_used+0x1ba>
    8b25:	48 89 df             	mov    %rbx,%rdi
    8b28:	e8 43 b5 ff ff       	call   4070 <buf_put>
    8b2d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8b32:	e9 35 f8 ff ff       	jmp    836c <fwp_write+0x2cc>
    8b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b3e:	00 00 
    8b40:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8b45:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8b49:	48 85 ff             	test   %rdi,%rdi
    8b4c:	0f 84 e2 fd ff ff    	je     8934 <fwp_write+0x894>
    8b52:	48 8d 35 4b 56 00 00 	lea    0x564b(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    8b59:	e8 d2 a9 ff ff       	call   3530 <strcmp@plt>
    8b5e:	85 c0                	test   %eax,%eax
    8b60:	0f 95 c0             	setne  %al
    8b63:	0f b6 c0             	movzbl %al,%eax
    8b66:	e9 c1 fd ff ff       	jmp    892c <fwp_write+0x88c>
    8b6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b70:	31 c0                	xor    %eax,%eax
    8b72:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8b79:	00 
    8b7a:	0f 97 c0             	seta   %al
    8b7d:	e9 aa fd ff ff       	jmp    892c <fwp_write+0x88c>
    8b82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b88:	48 89 df             	mov    %rbx,%rdi
    8b8b:	ba 02 00 00 00       	mov    $0x2,%edx
    8b90:	48 8d 35 0a 56 00 00 	lea    0x560a(%rip),%rsi        # e1a1 <_IO_stdin_used+0x1a1>
    8b97:	e8 d4 b4 ff ff       	call   4070 <buf_put>
    8b9c:	4c 89 e8             	mov    %r13,%rax
    8b9f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8ba4:	31 c9                	xor    %ecx,%ecx
    8ba6:	48 c1 e0 04          	shl    $0x4,%rax
    8baa:	48 89 df             	mov    %rbx,%rdi
    8bad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8bb2:	e8 e9 f4 ff ff       	call   80a0 <fwp_write>
    8bb7:	e9 5e f6 ff ff       	jmp    821a <fwp_write+0x17a>
    8bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8bc0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8bc5:	48 85 ff             	test   %rdi,%rdi
    8bc8:	79 0c                	jns    8bd6 <fwp_write+0xb36>
    8bca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8bd1:	00 
    8bd2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8bd6:	48 63 3e             	movslq (%rsi),%rdi
    8bd9:	83 f9 02             	cmp    $0x2,%ecx
    8bdc:	89 fe                	mov    %edi,%esi
    8bde:	48 0f 44 f7          	cmove  %rdi,%rsi
    8be2:	e9 f9 fb ff ff       	jmp    87e0 <fwp_write+0x740>
    8be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bee:	00 00 
    8bf0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8bf5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8bfa:	48 85 ff             	test   %rdi,%rdi
    8bfd:	0f 88 0f 03 00 00    	js     8f12 <fwp_write+0xe72>
    8c03:	49 0f bf 38          	movswq (%r8),%rdi
    8c07:	83 f9 01             	cmp    $0x1,%ecx
    8c0a:	0f b7 f7             	movzwl %di,%esi
    8c0d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8c11:	e9 ca fb ff ff       	jmp    87e0 <fwp_write+0x740>
    8c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c1d:	00 00 00 
    8c20:	ba 01 00 00 00       	mov    $0x1,%edx
    8c25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c2a:	48 83 c5 08          	add    $0x8,%rbp
    8c2e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8c33:	e8 38 b4 ff ff       	call   4070 <buf_put>
    8c38:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8c3d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8c42:	4d 85 ed             	test   %r13,%r13
    8c45:	75 46                	jne    8c8d <fwp_write+0xbed>
    8c47:	e9 04 01 00 00       	jmp    8d50 <fwp_write+0xcb0>
    8c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c50:	41 80 f9 09          	cmp    $0x9,%r9b
    8c54:	0f 84 d6 00 00 00    	je     8d30 <fwp_write+0xc90>
    8c5a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8c5e:	0f 85 9c 00 00 00    	jne    8d00 <fwp_write+0xc60>
    8c64:	ba 02 00 00 00       	mov    $0x2,%edx
    8c69:	48 8d 35 0d 55 00 00 	lea    0x550d(%rip),%rsi        # e17d <_IO_stdin_used+0x17d>
    8c70:	48 89 df             	mov    %rbx,%rdi
    8c73:	e8 f8 b3 ff ff       	call   4070 <buf_put>
    8c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c7f:	00 
    8c80:	48 83 c5 01          	add    $0x1,%rbp
    8c84:	49 39 ec             	cmp    %rbp,%r12
    8c87:	0f 84 c3 00 00 00    	je     8d50 <fwp_write+0xcb0>
    8c8d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8c92:	41 80 f9 0d          	cmp    $0xd,%r9b
    8c96:	74 28                	je     8cc0 <fwp_write+0xc20>
    8c98:	7e b6                	jle    8c50 <fwp_write+0xbb0>
    8c9a:	41 80 f9 22          	cmp    $0x22,%r9b
    8c9e:	74 40                	je     8ce0 <fwp_write+0xc40>
    8ca0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8ca4:	75 5a                	jne    8d00 <fwp_write+0xc60>
    8ca6:	ba 02 00 00 00       	mov    $0x2,%edx
    8cab:	48 8d 35 c8 54 00 00 	lea    0x54c8(%rip),%rsi        # e17a <_IO_stdin_used+0x17a>
    8cb2:	48 89 df             	mov    %rbx,%rdi
    8cb5:	e8 b6 b3 ff ff       	call   4070 <buf_put>
    8cba:	eb c4                	jmp    8c80 <fwp_write+0xbe0>
    8cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8cc0:	ba 02 00 00 00       	mov    $0x2,%edx
    8cc5:	48 8d 35 b7 54 00 00 	lea    0x54b7(%rip),%rsi        # e183 <_IO_stdin_used+0x183>
    8ccc:	48 89 df             	mov    %rbx,%rdi
    8ccf:	e8 9c b3 ff ff       	call   4070 <buf_put>
    8cd4:	eb aa                	jmp    8c80 <fwp_write+0xbe0>
    8cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8cdd:	00 00 00 
    8ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ce5:	48 8d 35 8b 54 00 00 	lea    0x548b(%rip),%rsi        # e177 <_IO_stdin_used+0x177>
    8cec:	48 89 df             	mov    %rbx,%rdi
    8cef:	e8 7c b3 ff ff       	call   4070 <buf_put>
    8cf4:	eb 8a                	jmp    8c80 <fwp_write+0xbe0>
    8cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8cfd:	00 00 00 
    8d00:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8d04:	0f 86 2e 01 00 00    	jbe    8e38 <fwp_write+0xd98>
    8d0a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8d0e:	0f 84 24 01 00 00    	je     8e38 <fwp_write+0xd98>
    8d14:	ba 01 00 00 00       	mov    $0x1,%edx
    8d19:	4c 89 fe             	mov    %r15,%rsi
    8d1c:	48 89 df             	mov    %rbx,%rdi
    8d1f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8d24:	e8 47 b3 ff ff       	call   4070 <buf_put>
    8d29:	e9 52 ff ff ff       	jmp    8c80 <fwp_write+0xbe0>
    8d2e:	66 90                	xchg   %ax,%ax
    8d30:	ba 02 00 00 00       	mov    $0x2,%edx
    8d35:	48 8d 35 44 54 00 00 	lea    0x5444(%rip),%rsi        # e180 <_IO_stdin_used+0x180>
    8d3c:	48 89 df             	mov    %rbx,%rdi
    8d3f:	e8 2c b3 ff ff       	call   4070 <buf_put>
    8d44:	e9 37 ff ff ff       	jmp    8c80 <fwp_write+0xbe0>
    8d49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d50:	ba 01 00 00 00       	mov    $0x1,%edx
    8d55:	4c 89 fe             	mov    %r15,%rsi
    8d58:	48 89 df             	mov    %rbx,%rdi
    8d5b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8d60:	e8 0b b3 ff ff       	call   4070 <buf_put>
    8d65:	e9 cc f3 ff ff       	jmp    8136 <fwp_write+0x96>
    8d6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d70:	83 f8 04             	cmp    $0x4,%eax
    8d73:	0f 85 bb fb ff ff    	jne    8934 <fwp_write+0x894>
    8d79:	48 8b 04 24          	mov    (%rsp),%rax
    8d7d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8d81:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8d86:	48 c1 e8 3f          	shr    $0x3f,%rax
    8d8a:	e9 96 fc ff ff       	jmp    8a25 <fwp_write+0x985>
    8d8f:	90                   	nop
    8d90:	8b 0c 24             	mov    (%rsp),%ecx
    8d93:	31 c0                	xor    %eax,%eax
    8d95:	85 c9                	test   %ecx,%ecx
    8d97:	0f 98 c0             	sets   %al
    8d9a:	e9 86 fc ff ff       	jmp    8a25 <fwp_write+0x985>
    8d9f:	90                   	nop
    8da0:	48 f7 d8             	neg    %rax
    8da3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8daa:	00 
    8dab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8db2:	2d 
    8db3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8dba:	00 
    8dbb:	48 83 d2 00          	adc    $0x0,%rdx
    8dbf:	48 89 c6             	mov    %rax,%rsi
    8dc2:	48 f7 da             	neg    %rdx
    8dc5:	e8 76 ac ff ff       	call   3a40 <fwp_fmt_u128>
    8dca:	e9 51 f3 ff ff       	jmp    8120 <fwp_write+0x80>
    8dcf:	90                   	nop
    8dd0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8dd5:	e9 c3 f5 ff ff       	jmp    839d <fwp_write+0x2fd>
    8dda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8de0:	4c 89 e9             	mov    %r13,%rcx
    8de3:	48 c1 e1 04          	shl    $0x4,%rcx
    8de7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8dec:	48 85 ff             	test   %rdi,%rdi
    8def:	0f 89 eb f9 ff ff    	jns    87e0 <fwp_write+0x740>
    8df5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8df9:	48 89 ce             	mov    %rcx,%rsi
    8dfc:	e9 df f9 ff ff       	jmp    87e0 <fwp_write+0x740>
    8e01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e08:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8e0f:	00 
    8e10:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8e14:	e9 20 fa ff ff       	jmp    8839 <fwp_write+0x799>
    8e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e20:	ba 02 00 00 00       	mov    $0x2,%edx
    8e25:	48 8d 35 16 53 00 00 	lea    0x5316(%rip),%rsi        # e142 <_IO_stdin_used+0x142>
    8e2c:	e9 2d f7 ff ff       	jmp    855e <fwp_write+0x4be>
    8e31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e38:	4c 8d 05 47 53 00 00 	lea    0x5347(%rip),%r8        # e186 <_IO_stdin_used+0x186>
    8e3f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8e44:	31 c0                	xor    %eax,%eax
    8e46:	ba 02 00 00 00       	mov    $0x2,%edx
    8e4b:	be 10 00 00 00       	mov    $0x10,%esi
    8e50:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8e57:	00 
    8e58:	e8 53 a5 ff ff       	call   33b0 <__snprintf_chk@plt>
    8e5d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8e64:	00 
    8e65:	e8 e6 a5 ff ff       	call   3450 <strlen@plt>
    8e6a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8e71:	00 
    8e72:	48 89 df             	mov    %rbx,%rdi
    8e75:	48 89 c2             	mov    %rax,%rdx
    8e78:	e8 f3 b1 ff ff       	call   4070 <buf_put>
    8e7d:	e9 fe fd ff ff       	jmp    8c80 <fwp_write+0xbe0>
    8e82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e88:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8e8c:	48 8d 35 a9 52 00 00 	lea    0x52a9(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8e93:	48 8d 05 a1 52 00 00 	lea    0x52a1(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8e9a:	4c 89 e7             	mov    %r12,%rdi
    8e9d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8ea1:	48 0f 46 f0          	cmovbe %rax,%rsi
    8ea5:	e8 46 a5 ff ff       	call   33f0 <strcpy@plt>
    8eaa:	e9 71 f2 ff ff       	jmp    8120 <fwp_write+0x80>
    8eaf:	90                   	nop
    8eb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8eb4:	48 8d 35 81 52 00 00 	lea    0x5281(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8ebb:	48 8d 05 79 52 00 00 	lea    0x5279(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8ec2:	0f 2f c8             	comiss %xmm0,%xmm1
    8ec5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ecc:	00 
    8ecd:	4c 89 e7             	mov    %r12,%rdi
    8ed0:	48 0f 46 f0          	cmovbe %rax,%rsi
    8ed4:	e8 17 a5 ff ff       	call   33f0 <strcpy@plt>
    8ed9:	e9 42 f2 ff ff       	jmp    8120 <fwp_write+0x80>
    8ede:	66 90                	xchg   %ax,%ax
    8ee0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8ee5:	45 85 c0             	test   %r8d,%r8d
    8ee8:	75 34                	jne    8f1e <fwp_write+0xe7e>
    8eea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ef1:	00 
    8ef2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8ef9:	00 00 
    8efb:	0f 85 74 f6 ff ff    	jne    8575 <fwp_write+0x4d5>
    8f01:	ba 02 00 00 00       	mov    $0x2,%edx
    8f06:	48 8d 35 aa 52 00 00 	lea    0x52aa(%rip),%rsi        # e1b7 <_IO_stdin_used+0x1b7>
    8f0d:	e9 a1 f3 ff ff       	jmp    82b3 <fwp_write+0x213>
    8f12:	48 03 75 10          	add    0x10(%rbp),%rsi
    8f16:	49 89 f0             	mov    %rsi,%r8
    8f19:	e9 e5 fc ff ff       	jmp    8c03 <fwp_write+0xb63>
    8f1e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8f23:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8f28:	85 ff                	test   %edi,%edi
    8f2a:	0f 84 fa f3 ff ff    	je     832a <fwp_write+0x28a>
    8f30:	ba 01 00 00 00       	mov    $0x1,%edx
    8f35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f3a:	48 89 df             	mov    %rbx,%rdi
    8f3d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f42:	e8 29 b1 ff ff       	call   4070 <buf_put>
    8f47:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8f4c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8f51:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8f57:	85 c0                	test   %eax,%eax
    8f59:	0f 8f f0 f3 ff ff    	jg     834f <fwp_write+0x2af>
    8f5f:	e9 34 f4 ff ff       	jmp    8398 <fwp_write+0x2f8>
    8f64:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8f68:	49 89 c5             	mov    %rax,%r13
    8f6b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8f70:	49 89 c4             	mov    %rax,%r12
    8f73:	49 c1 fd 3f          	sar    $0x3f,%r13
    8f77:	4c 09 e8             	or     %r13,%rax
    8f7a:	0f 84 a7 00 00 00    	je     9027 <fwp_write+0xf87>
    8f80:	48 8d 2d 39 73 00 00 	lea    0x7339(%rip),%rbp        # 102c0 <units.0>
    8f87:	4d 89 e7             	mov    %r12,%r15
    8f8a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8f8e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8f93:	4c 89 ff             	mov    %r15,%rdi
    8f96:	4c 89 ee             	mov    %r13,%rsi
    8f99:	44 89 0c 24          	mov    %r9d,(%rsp)
    8f9d:	48 99                	cqto
    8f9f:	48 89 d1             	mov    %rdx,%rcx
    8fa2:	48 89 c2             	mov    %rax,%rdx
    8fa5:	e8 06 4e 00 00       	call   ddb0 <__divmodti4>
    8faa:	44 8b 0c 24          	mov    (%rsp),%r9d
    8fae:	48 89 c1             	mov    %rax,%rcx
    8fb1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8fb6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8fbb:	0f 84 94 00 00 00    	je     9055 <fwp_write+0xfb5>
    8fc1:	41 83 c1 01          	add    $0x1,%r9d
    8fc5:	48 83 c5 10          	add    $0x10,%rbp
    8fc9:	41 83 f9 05          	cmp    $0x5,%r9d
    8fcd:	75 bb                	jne    8f8a <fwp_write+0xeea>
    8fcf:	4d 85 ed             	test   %r13,%r13
    8fd2:	79 53                	jns    9027 <fwp_write+0xf87>
    8fd4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8fd9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8fde:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8fe3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8fe8:	48 99                	cqto
    8fea:	48 f7 d8             	neg    %rax
    8fed:	48 83 d2 00          	adc    $0x0,%rdx
    8ff1:	48 89 c6             	mov    %rax,%rsi
    8ff4:	48 f7 da             	neg    %rdx
    8ff7:	e8 44 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8ffc:	49 89 e8             	mov    %rbp,%r8
    8fff:	ba 00 02 00 00       	mov    $0x200,%edx
    9004:	be 02 00 00 00       	mov    $0x2,%esi
    9009:	31 c0                	xor    %eax,%eax
    900b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9012:	00 
    9013:	48 8d 0d 98 51 00 00 	lea    0x5198(%rip),%rcx        # e1b2 <_IO_stdin_used+0x1b2>
    901a:	4c 89 e7             	mov    %r12,%rdi
    901d:	e8 be a6 ff ff       	call   36e0 <__sprintf_chk@plt>
    9022:	e9 f9 f0 ff ff       	jmp    8120 <fwp_write+0x80>
    9027:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    902c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9031:	31 d2                	xor    %edx,%edx
    9033:	48 89 ef             	mov    %rbp,%rdi
    9036:	e8 05 aa ff ff       	call   3a40 <fwp_fmt_u128>
    903b:	eb bf                	jmp    8ffc <fwp_write+0xf5c>
    903d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9044:	4e 61 4e 00 
    9048:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    904f:	00 
    9050:	e9 cb f0 ff ff       	jmp    8120 <fwp_write+0x80>
    9055:	44 89 0c 24          	mov    %r9d,(%rsp)
    9059:	48 89 c8             	mov    %rcx,%rax
    905c:	48 85 d2             	test   %rdx,%rdx
    905f:	78 51                	js     90b2 <fwp_write+0x1012>
    9061:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9066:	48 89 c6             	mov    %rax,%rsi
    9069:	48 89 ef             	mov    %rbp,%rdi
    906c:	e8 cf a9 ff ff       	call   3a40 <fwp_fmt_u128>
    9071:	44 8b 0c 24          	mov    (%rsp),%r9d
    9075:	49 63 c1             	movslq %r9d,%rax
    9078:	49 89 e8             	mov    %rbp,%r8
    907b:	ba 00 02 00 00       	mov    $0x200,%edx
    9080:	be 02 00 00 00       	mov    $0x2,%esi
    9085:	48 c1 e0 04          	shl    $0x4,%rax
    9089:	48 8d 3d 30 72 00 00 	lea    0x7230(%rip),%rdi        # 102c0 <units.0>
    9090:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9097:	00 
    9098:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    909c:	48 8d 0d 0a 51 00 00 	lea    0x510a(%rip),%rcx        # e1ad <_IO_stdin_used+0x1ad>
    90a3:	4c 89 e7             	mov    %r12,%rdi
    90a6:	31 c0                	xor    %eax,%eax
    90a8:	e8 33 a6 ff ff       	call   36e0 <__sprintf_chk@plt>
    90ad:	e9 6e f0 ff ff       	jmp    8120 <fwp_write+0x80>
    90b2:	48 f7 d8             	neg    %rax
    90b5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    90ba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    90bf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90c4:	48 83 d2 00          	adc    $0x0,%rdx
    90c8:	48 89 c6             	mov    %rax,%rsi
    90cb:	48 f7 da             	neg    %rdx
    90ce:	e8 6d a9 ff ff       	call   3a40 <fwp_fmt_u128>
    90d3:	44 8b 0c 24          	mov    (%rsp),%r9d
    90d7:	eb 9c                	jmp    9075 <fwp_write+0xfd5>
    90d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000090e0 <fwp_hof0.constprop.0>:
    90e0:	41 57                	push   %r15
    90e2:	41 56                	push   %r14
    90e4:	41 55                	push   %r13
    90e6:	41 54                	push   %r12
    90e8:	55                   	push   %rbp
    90e9:	53                   	push   %rbx
    90ea:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    90f1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    90f8:	00 00 
    90fa:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    9101:	00 
    9102:	31 c0                	xor    %eax,%eax
    9104:	48 85 f6             	test   %rsi,%rsi
    9107:	0f 84 4a 0f 00 00    	je     a057 <fwp_hof0.constprop.0+0xf77>
    910d:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
    9112:	4c 8d 2d 67 96 01 00 	lea    0x19667(%rip),%r13        # 22780 <fwp_heap>
    9119:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
    911e:	66 90                	xchg   %ax,%ax
    9120:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9127:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    912c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9133:	48 c1 e2 10          	shl    $0x10,%rdx
    9137:	48 39 d0             	cmp    %rdx,%rax
    913a:	73 5d                	jae    9199 <fwp_hof0.constprop.0+0xb9>
    913c:	48 89 c2             	mov    %rax,%rdx
    913f:	48 c1 ea 10          	shr    $0x10,%rdx
    9143:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9147:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    914e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9152:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9156:	48 85 ff             	test   %rdi,%rdi
    9159:	74 3e                	je     9199 <fwp_hof0.constprop.0+0xb9>
    915b:	0f b6 0a             	movzbl (%rdx),%ecx
    915e:	80 f9 02             	cmp    $0x2,%cl
    9161:	0f 84 e9 14 00 00    	je     a650 <fwp_hof0.constprop.0+0x1570>
    9167:	80 f9 01             	cmp    $0x1,%cl
    916a:	75 2d                	jne    9199 <fwp_hof0.constprop.0+0xb9>
    916c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    916f:	0f b7 c0             	movzwl %ax,%eax
    9172:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9175:	48 0f af c1          	imul   %rcx,%rax
    9179:	48 c1 e8 20          	shr    $0x20,%rax
    917d:	48 39 d0             	cmp    %rdx,%rax
    9180:	73 17                	jae    9199 <fwp_hof0.constprop.0+0xb9>
    9182:	48 01 c7             	add    %rax,%rdi
    9185:	0f b6 07             	movzbl (%rdi),%eax
    9188:	84 c0                	test   %al,%al
    918a:	74 0d                	je     9199 <fwp_hof0.constprop.0+0xb9>
    918c:	3c fd                	cmp    $0xfd,%al
    918e:	0f 87 c7 16 00 00    	ja     a85b <fwp_hof0.constprop.0+0x177b>
    9194:	83 c0 01             	add    $0x1,%eax
    9197:	88 07                	mov    %al,(%rdi)
    9199:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    919e:	45 31 c0             	xor    %r8d,%r8d
    91a1:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    91a8:	00 00 
    91aa:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    91af:	4d 89 c6             	mov    %r8,%r14
    91b2:	4d 85 c0             	test   %r8,%r8
    91b5:	0f 85 95 a5 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    91bb:	48 8b 05 56 b2 01 00 	mov    0x1b256(%rip),%rax        # 24418 <fwp_cleanups>
    91c2:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    91c9:	4c 8d 25 50 d8 ff ff 	lea    -0x27b0(%rip),%r12        # 6a20 <fwp_tape_scope_release>
    91d0:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    91d7:	ff ff ff ff 
    91db:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
    91e2:	00 
    91e3:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    91ea:	00 
    91eb:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    91f2:	00 
    91f3:	48 c1 e2 10          	shl    $0x10,%rdx
    91f7:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    91fc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9203:	00 
    9204:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    920b:	00 
    920c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9211:	48 89 05 00 b2 01 00 	mov    %rax,0x1b200(%rip)        # 24418 <fwp_cleanups>
    9218:	48 8d 05 f1 8d 00 00 	lea    0x8df1(%rip),%rax        # 12010 <fc37>
    921f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9226:	48 39 d0             	cmp    %rdx,%rax
    9229:	73 5d                	jae    9288 <fwp_hof0.constprop.0+0x1a8>
    922b:	48 89 c2             	mov    %rax,%rdx
    922e:	48 c1 ea 10          	shr    $0x10,%rdx
    9232:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9236:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    923d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9241:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9245:	48 85 ff             	test   %rdi,%rdi
    9248:	74 3e                	je     9288 <fwp_hof0.constprop.0+0x1a8>
    924a:	0f b6 0a             	movzbl (%rdx),%ecx
    924d:	80 f9 02             	cmp    $0x2,%cl
    9250:	0f 84 8a 12 00 00    	je     a4e0 <fwp_hof0.constprop.0+0x1400>
    9256:	80 f9 01             	cmp    $0x1,%cl
    9259:	75 2d                	jne    9288 <fwp_hof0.constprop.0+0x1a8>
    925b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    925e:	0f b7 c0             	movzwl %ax,%eax
    9261:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9264:	48 0f af c1          	imul   %rcx,%rax
    9268:	48 c1 e8 20          	shr    $0x20,%rax
    926c:	48 39 d0             	cmp    %rdx,%rax
    926f:	73 17                	jae    9288 <fwp_hof0.constprop.0+0x1a8>
    9271:	48 01 c7             	add    %rax,%rdi
    9274:	0f b6 07             	movzbl (%rdi),%eax
    9277:	84 c0                	test   %al,%al
    9279:	74 0d                	je     9288 <fwp_hof0.constprop.0+0x1a8>
    927b:	3c fd                	cmp    $0xfd,%al
    927d:	0f 87 18 15 00 00    	ja     a79b <fwp_hof0.constprop.0+0x16bb>
    9283:	83 c0 01             	add    $0x1,%eax
    9286:	88 07                	mov    %al,(%rdi)
    9288:	48 8d 3d 81 8d 00 00 	lea    0x8d81(%rip),%rdi        # 12010 <fc37>
    928f:	e8 4c d4 ff ff       	call   66e0 <fwp_closure_drop>
    9294:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9299:	48 85 c0             	test   %rax,%rax
    929c:	0f 84 0e 14 00 00    	je     a6b0 <fwp_hof0.constprop.0+0x15d0>
    92a2:	31 d2                	xor    %edx,%edx
    92a4:	90                   	nop
    92a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92ac:	00 00 00 00 
    92b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    92b4:	48 83 c2 01          	add    $0x1,%rdx
    92b8:	48 85 c0             	test   %rax,%rax
    92bb:	75 f3                	jne    92b0 <fwp_hof0.constprop.0+0x1d0>
    92bd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    92c4:	0f 87 cf 15 00 00    	ja     a899 <fwp_hof0.constprop.0+0x17b9>
    92ca:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    92cf:	8b 35 a7 8d 00 00    	mov    0x8da7(%rip),%esi        # 1207c <registered_finish.5>
    92d5:	85 f6                	test   %esi,%esi
    92d7:	0f 84 c3 11 00 00    	je     a4a0 <fwp_hof0.constprop.0+0x13c0>
    92dd:	4c 8b 3d 14 8e 01 00 	mov    0x18e14(%rip),%r15        # 220f8 <fwp_tape_next_slot>
    92e4:	48 8b 2d 1d 8e 01 00 	mov    0x18e1d(%rip),%rbp        # 22108 <fwp_ntapes>
    92eb:	4c 39 fd             	cmp    %r15,%rbp
    92ee:	0f 8e 3c 0e 00 00    	jle    a130 <fwp_hof0.constprop.0+0x1050>
    92f4:	49 6b c7 68          	imul   $0x68,%r15,%rax
    92f8:	48 03 05 11 8e 01 00 	add    0x18e11(%rip),%rax        # 22110 <fwp_tapes>
    92ff:	90                   	nop
    9300:	8b 48 04             	mov    0x4(%rax),%ecx
    9303:	85 c9                	test   %ecx,%ecx
    9305:	75 0c                	jne    9313 <fwp_hof0.constprop.0+0x233>
    9307:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    930d:	0f 86 1d 0e 00 00    	jbe    a130 <fwp_hof0.constprop.0+0x1050>
    9313:	49 83 c7 01          	add    $0x1,%r15
    9317:	48 83 c0 68          	add    $0x68,%rax
    931b:	4c 39 fd             	cmp    %r15,%rbp
    931e:	75 e0                	jne    9300 <fwp_hof0.constprop.0+0x220>
    9320:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9327:	0f 8f ef 15 00 00    	jg     a91c <fwp_hof0.constprop.0+0x183c>
    932d:	48 3b 2d cc 8d 01 00 	cmp    0x18dcc(%rip),%rbp        # 22100 <fwp_tapes_cap>
    9334:	48 8b 1d d5 8d 01 00 	mov    0x18dd5(%rip),%rbx        # 22110 <fwp_tapes>
    933b:	75 4c                	jne    9389 <fwp_hof0.constprop.0+0x2a9>
    933d:	48 85 ed             	test   %rbp,%rbp
    9340:	0f 84 d0 13 00 00    	je     a716 <fwp_hof0.constprop.0+0x1636>
    9346:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    934b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9350:	49 39 c7             	cmp    %rax,%r15
    9353:	4c 0f 4f f8          	cmovg  %rax,%r15
    9357:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    935b:	48 89 df             	mov    %rbx,%rdi
    935e:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9364:	e8 67 a2 ff ff       	call   35d0 <realloc@plt>
    9369:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    936f:	48 85 c0             	test   %rax,%rax
    9372:	48 89 c3             	mov    %rax,%rbx
    9375:	0f 84 ad 15 00 00    	je     a928 <fwp_hof0.constprop.0+0x1848>
    937b:	48 89 05 8e 8d 01 00 	mov    %rax,0x18d8e(%rip)        # 22110 <fwp_tapes>
    9382:	4c 89 3d 77 8d 01 00 	mov    %r15,0x18d77(%rip)        # 22100 <fwp_tapes_cap>
    9389:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    938d:	31 c0                	xor    %eax,%eax
    938f:	49 89 ef             	mov    %rbp,%r15
    9392:	48 01 d9             	add    %rbx,%rcx
    9395:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9399:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    93a0:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    93a4:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    93ab:	00 
    93ac:	48 29 f9             	sub    %rdi,%rcx
    93af:	83 c1 68             	add    $0x68,%ecx
    93b2:	c1 e9 03             	shr    $0x3,%ecx
    93b5:	f3 48 ab             	rep stos %rax,(%rdi)
    93b8:	48 8d 45 01          	lea    0x1(%rbp),%rax
    93bc:	48 89 05 45 8d 01 00 	mov    %rax,0x18d45(%rip)        # 22108 <fwp_ntapes>
    93c3:	49 6b ef 68          	imul   $0x68,%r15,%rbp
    93c7:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    93cb:	48 8d 3d ed 4c 00 00 	lea    0x4ced(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    93d2:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    93d7:	48 01 dd             	add    %rbx,%rbp
    93da:	48 c7 45 60 00 00 00 	movq   $0x0,0x60(%rbp)
    93e1:	00 
    93e2:	e8 b9 9f ff ff       	call   33a0 <getenv@plt>
    93e7:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    93ed:	48 85 c0             	test   %rax,%rax
    93f0:	0f 84 52 0d 00 00    	je     a148 <fwp_hof0.constprop.0+0x1068>
    93f6:	80 38 30             	cmpb   $0x30,(%rax)
    93f9:	0f 85 49 0d 00 00    	jne    a148 <fwp_hof0.constprop.0+0x1068>
    93ff:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9403:	0f 85 3f 0d 00 00    	jne    a148 <fwp_hof0.constprop.0+0x1068>
    9409:	8b 45 00             	mov    0x0(%rbp),%eax
    940c:	49 8d 77 01          	lea    0x1(%r15),%rsi
    9410:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    9414:	c7 45 04 01 00 00 00 	movl   $0x1,0x4(%rbp)
    941b:	8d 48 01             	lea    0x1(%rax),%ecx
    941e:	48 8b 05 7b 56 00 00 	mov    0x567b(%rip),%rax        # eaa0 <msg.8+0x20>
    9425:	48 89 35 cc 8c 01 00 	mov    %rsi,0x18ccc(%rip)        # 220f8 <fwp_tape_next_slot>
    942c:	89 4d 00             	mov    %ecx,0x0(%rbp)
    942f:	48 89 45 58          	mov    %rax,0x58(%rbp)
    9433:	48 8b 05 de af 01 00 	mov    0x1afde(%rip),%rax        # 24418 <fwp_cleanups>
    943a:	48 c7 45 50 00 00 00 	movq   $0x0,0x50(%rbp)
    9441:	00 
    9442:	48 85 c0             	test   %rax,%rax
    9445:	75 15                	jne    945c <fwp_hof0.constprop.0+0x37c>
    9447:	e9 74 14 00 00       	jmp    a8c0 <fwp_hof0.constprop.0+0x17e0>
    944c:	0f 1f 40 00          	nopl   0x0(%rax)
    9450:	48 8b 00             	mov    (%rax),%rax
    9453:	48 85 c0             	test   %rax,%rax
    9456:	0f 84 64 14 00 00    	je     a8c0 <fwp_hof0.constprop.0+0x17e0>
    945c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    9460:	75 ee                	jne    9450 <fwp_hof0.constprop.0+0x370>
    9462:	4c 8b 48 10          	mov    0x10(%rax),%r9
    9466:	44 89 ff             	mov    %r15d,%edi
    9469:	49 63 01             	movslq (%r9),%rax
    946c:	4c 89 4d 50          	mov    %r9,0x50(%rbp)
    9470:	89 45 5c             	mov    %eax,0x5c(%rbp)
    9473:	85 c0                	test   %eax,%eax
    9475:	78 09                	js     9480 <fwp_hof0.constprop.0+0x3a0>
    9477:	48 6b c0 68          	imul   $0x68,%rax,%rax
    947b:	44 89 7c 03 58       	mov    %r15d,0x58(%rbx,%rax,1)
    9480:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9485:	41 89 39             	mov    %edi,(%r9)
    9488:	45 31 e4             	xor    %r12d,%r12d
    948b:	48 89 d8             	mov    %rbx,%rax
    948e:	48 85 db             	test   %rbx,%rbx
    9491:	0f 84 19 0e 00 00    	je     a2b0 <fwp_hof0.constprop.0+0x11d0>
    9497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    949e:	00 00 
    94a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    94a4:	49 83 c4 01          	add    $0x1,%r12
    94a8:	48 85 c0             	test   %rax,%rax
    94ab:	75 f3                	jne    94a0 <fwp_hof0.constprop.0+0x3c0>
    94ad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    94b2:	0f 1f 00             	nopl   (%rax)
    94b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94bc:	00 00 00 00 
    94c0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    94c4:	48 83 c0 01          	add    $0x1,%rax
    94c8:	48 85 d2             	test   %rdx,%rdx
    94cb:	75 f3                	jne    94c0 <fwp_hof0.constprop.0+0x3e0>
    94cd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    94d4:	ff ff 1f 
    94d7:	48 39 c2             	cmp    %rax,%rdx
    94da:	0f 82 d1 13 00 00    	jb     a8b1 <fwp_hof0.constprop.0+0x17d1>
    94e0:	4d 85 e4             	test   %r12,%r12
    94e3:	0f 8e c7 0d 00 00    	jle    a2b0 <fwp_hof0.constprop.0+0x11d0>
    94e9:	49 39 c4             	cmp    %rax,%r12
    94ec:	4c 0f 47 e0          	cmova  %rax,%r12
    94f0:	4c 89 e0             	mov    %r12,%rax
    94f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    94f7:	0f 85 b4 13 00 00    	jne    a8b1 <fwp_hof0.constprop.0+0x17d1>
    94fd:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9501:	48 c1 e1 10          	shl    $0x10,%rcx
    9505:	48 09 f1             	or     %rsi,%rcx
    9508:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    950f:	00 
    9510:	be 02 00 00 00       	mov    $0x2,%esi
    9515:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    951a:	e8 91 c5 ff ff       	call   5ab0 <fwp_heap_alloc>
    951f:	4c 89 38             	mov    %r15,(%rax)
    9522:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9529:	48 89 c5             	mov    %rax,%rbp
    952c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9533:	48 c1 e2 10          	shl    $0x10,%rdx
    9537:	48 39 d0             	cmp    %rdx,%rax
    953a:	0f 83 20 0e 00 00    	jae    a360 <fwp_hof0.constprop.0+0x1280>
    9540:	48 89 c2             	mov    %rax,%rdx
    9543:	48 c1 ea 10          	shr    $0x10,%rdx
    9547:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    954b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9552:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9556:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    955a:	4d 85 ff             	test   %r15,%r15
    955d:	74 3a                	je     9599 <fwp_hof0.constprop.0+0x4b9>
    955f:	0f b6 32             	movzbl (%rdx),%esi
    9562:	40 80 fe 02          	cmp    $0x2,%sil
    9566:	0f 84 b7 0d 00 00    	je     a323 <fwp_hof0.constprop.0+0x1243>
    956c:	40 80 fe 01          	cmp    $0x1,%sil
    9570:	75 27                	jne    9599 <fwp_hof0.constprop.0+0x4b9>
    9572:	8b 72 18             	mov    0x18(%rdx),%esi
    9575:	0f b7 c0             	movzwl %ax,%eax
    9578:	8b 52 1c             	mov    0x1c(%rdx),%edx
    957b:	48 0f af c6          	imul   %rsi,%rax
    957f:	48 c1 e8 20          	shr    $0x20,%rax
    9583:	48 39 d0             	cmp    %rdx,%rax
    9586:	73 11                	jae    9599 <fwp_hof0.constprop.0+0x4b9>
    9588:	49 01 c7             	add    %rax,%r15
    958b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    958f:	0f 84 a1 0d 00 00    	je     a336 <fwp_hof0.constprop.0+0x1256>
    9595:	41 c6 07 01          	movb   $0x1,(%r15)
    9599:	4d 85 e4             	test   %r12,%r12
    959c:	74 55                	je     95f3 <fwp_hof0.constprop.0+0x513>
    959e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    95a3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    95a8:	31 c0                	xor    %eax,%eax
    95aa:	48 c1 e6 20          	shl    $0x20,%rsi
    95ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95bc:	00 00 00 00 
    95c0:	48 89 c1             	mov    %rax,%rcx
    95c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    95c8:	48 01 f1             	add    %rsi,%rcx
    95cb:	0f 80 7f a1 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    95d1:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    95d6:	48 89 c1             	mov    %rax,%rcx
    95d9:	48 83 c0 01          	add    $0x1,%rax
    95dd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    95e1:	48 c1 e1 04          	shl    $0x4,%rcx
    95e5:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    95ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    95ee:	4c 39 e0             	cmp    %r12,%rax
    95f1:	72 cd                	jb     95c0 <fwp_hof0.constprop.0+0x4e0>
    95f3:	48 8b 45 00          	mov    0x0(%rbp),%rax
    95f7:	48 d1 e8             	shr    $1,%rax
    95fa:	0f 84 70 0d 00 00    	je     a370 <fwp_hof0.constprop.0+0x1290>
    9600:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9604:	48 89 f3             	mov    %rsi,%rbx
    9607:	48 c1 eb 3c          	shr    $0x3c,%rbx
    960b:	0f 85 a0 12 00 00    	jne    a8b1 <fwp_hof0.constprop.0+0x17d1>
    9611:	48 8d 1c 36          	lea    (%rsi,%rsi,1),%rbx
    9615:	48 85 f6             	test   %rsi,%rsi
    9618:	74 44                	je     965e <fwp_hof0.constprop.0+0x57e>
    961a:	48 c1 e0 04          	shl    $0x4,%rax
    961e:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    9622:	4c 8d 64 05 f8       	lea    -0x8(%rbp,%rax,1),%r12
    9627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    962e:	00 00 
    9630:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9635:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9639:	49 83 c7 10          	add    $0x10,%r15
    963d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9641:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9646:	e8 35 ca ff ff       	call   6080 <w120>
    964b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9650:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9654:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9659:	4d 39 fc             	cmp    %r15,%r12
    965c:	75 d2                	jne    9630 <fwp_hof0.constprop.0+0x550>
    965e:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    9662:	48 89 ef             	mov    %rbp,%rdi
    9665:	e8 96 cb ff ff       	call   6200 <w176.constprop.0>
    966a:	48 89 ef             	mov    %rbp,%rdi
    966d:	49 89 c4             	mov    %rax,%r12
    9670:	e8 db e2 ff ff       	call   7950 <fwp_drop10>
    9675:	e8 a6 b6 ff ff       	call   4d20 <caf75>
    967a:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    967f:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9684:	4c 89 ff             	mov    %r15,%rdi
    9687:	e8 f4 ad ff ff       	call   4480 <fwp_tape_of>
    968c:	48 89 c6             	mov    %rax,%rsi
    968f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9694:	0f 85 bc 12 00 00    	jne    a956 <fwp_hof0.constprop.0+0x1876>
    969a:	48 89 c7             	mov    %rax,%rdi
    969d:	e8 5e a5 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    96a2:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    96a6:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    96ab:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    96b2:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    96b6:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    96ba:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    96bf:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    96c4:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    96c9:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    96cd:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    96d1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    96d7:	77 1a                	ja     96f3 <fwp_hof0.constprop.0+0x613>
    96d9:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    96de:	83 e8 01             	sub    $0x1,%eax
    96e1:	48 98                	cltq
    96e3:	48 3b 05 0e 8a 01 00 	cmp    0x18a0e(%rip),%rax        # 220f8 <fwp_tape_next_slot>
    96ea:	7d 07                	jge    96f3 <fwp_hof0.constprop.0+0x613>
    96ec:	48 89 05 05 8a 01 00 	mov    %rax,0x18a05(%rip)        # 220f8 <fwp_tape_next_slot>
    96f3:	48 8b 05 1e ad 01 00 	mov    0x1ad1e(%rip),%rax        # 24418 <fwp_cleanups>
    96fa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    96fe:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9705:	00 
    9706:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    970a:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9711:	00 
    9712:	48 8d 05 77 b7 ff ff 	lea    -0x4889(%rip),%rax        # 4e90 <fwp_tape_buffers_release>
    9719:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9720:	00 
    9721:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    9728:	00 
    9729:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    972e:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9735:	00 
    9736:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    973d:	00 
    973e:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9745:	00 
    9746:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    974d:	00 
    974e:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9752:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9756:	48 89 05 bb ac 01 00 	mov    %rax,0x1acbb(%rip)        # 24418 <fwp_cleanups>
    975d:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    9764:	00 
    9765:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    976c:	00 
    976d:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    9774:	00 
    9775:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    977c:	00 
    977d:	4d 85 e4             	test   %r12,%r12
    9780:	0f 88 6a 0d 00 00    	js     a4f0 <fwp_hof0.constprop.0+0x1410>
    9786:	4c 89 e0             	mov    %r12,%rax
    9789:	48 c1 f8 20          	sar    $0x20,%rax
    978d:	49 39 c7             	cmp    %rax,%r15
    9790:	0f 85 d7 10 00 00    	jne    a86d <fwp_hof0.constprop.0+0x178d>
    9796:	45 89 e7             	mov    %r12d,%r15d
    9799:	4c 89 fd             	mov    %r15,%rbp
    979c:	4c 39 ff             	cmp    %r15,%rdi
    979f:	0f 8e d4 10 00 00    	jle    a879 <fwp_hof0.constprop.0+0x1799>
    97a5:	4c 39 fb             	cmp    %r15,%rbx
    97a8:	0f 8e f2 0b 00 00    	jle    a3a0 <fwp_hof0.constprop.0+0x12c0>
    97ae:	48 39 d3             	cmp    %rdx,%rbx
    97b1:	0f 8f 31 0c 00 00    	jg     a3e8 <fwp_hof0.constprop.0+0x1308>
    97b7:	48 85 c9             	test   %rcx,%rcx
    97ba:	0f 84 15 11 00 00    	je     a8d5 <fwp_hof0.constprop.0+0x17f5>
    97c0:	48 89 cf             	mov    %rcx,%rdi
    97c3:	31 f6                	xor    %esi,%esi
    97c5:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    97ca:	48 8d 6b ff          	lea    -0x1(%rbx),%rbp
    97ce:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    97d5:	00 
    97d6:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    97db:	e8 e0 9c ff ff       	call   34c0 <memset@plt>
    97e0:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    97e6:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    97ec:	48 89 c1             	mov    %rax,%rcx
    97ef:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
    97f5:	f2 42 0f 58 04 f9    	addsd  (%rcx,%r15,8),%xmm0
    97fb:	f2 42 0f 11 04 f9    	movsd  %xmm0,(%rcx,%r15,8)
    9801:	48 39 eb             	cmp    %rbp,%rbx
    9804:	0f 8f 90 00 00 00    	jg     989a <fwp_hof0.constprop.0+0x7ba>
    980a:	0f 12 fb             	movhlps %xmm3,%xmm7
    980d:	66 49 0f 7e d2       	movq   %xmm2,%r10
    9812:	66 48 0f 7e de       	movq   %xmm3,%rsi
    9817:	48 29 dd             	sub    %rbx,%rbp
    981a:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    981f:	0f 12 fa             	movhlps %xmm2,%xmm7
    9822:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9826:	66 49 0f 7e fb       	movq   %xmm7,%r11
    982b:	48 8d 04 af          	lea    (%rdi,%rbp,4),%rax
    982f:	48 29 fe             	sub    %rdi,%rsi
    9832:	49 8d 14 eb          	lea    (%r11,%rbp,8),%rdx
    9836:	48 8d 2c d9          	lea    (%rcx,%rbx,8),%rbp
    983a:	4d 29 da             	sub    %r11,%r10
    983d:	4c 29 dd             	sub    %r11,%rbp
    9840:	eb 0a                	jmp    984c <fwp_hof0.constprop.0+0x76c>
    9842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9848:	48 83 e8 04          	sub    $0x4,%rax
    984c:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    9852:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9856:	7a 02                	jp     985a <fwp_hof0.constprop.0+0x77a>
    9858:	74 37                	je     9891 <fwp_hof0.constprop.0+0x7b1>
    985a:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    985e:	45 85 c0             	test   %r8d,%r8d
    9861:	78 16                	js     9879 <fwp_hof0.constprop.0+0x799>
    9863:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9869:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    986d:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    9873:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    9879:	4c 63 00             	movslq (%rax),%r8
    987c:	45 85 c0             	test   %r8d,%r8d
    987f:	78 10                	js     9891 <fwp_hof0.constprop.0+0x7b1>
    9881:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9885:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    988b:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    9891:	48 83 ea 08          	sub    $0x8,%rdx
    9895:	48 39 c7             	cmp    %rax,%rdi
    9898:	75 ae                	jne    9848 <fwp_hof0.constprop.0+0x768>
    989a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    98a1:	ff ff 1f 
    98a4:	48 39 d8             	cmp    %rbx,%rax
    98a7:	0f 82 f8 0f 00 00    	jb     a8a5 <fwp_hof0.constprop.0+0x17c5>
    98ad:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    98b4:	00 
    98b5:	be 02 00 00 00       	mov    $0x2,%esi
    98ba:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    98bf:	e8 ec c1 ff ff       	call   5ab0 <fwp_heap_alloc>
    98c4:	48 85 db             	test   %rbx,%rbx
    98c7:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    98cc:	48 89 18             	mov    %rbx,(%rax)
    98cf:	49 89 c7             	mov    %rax,%r15
    98d2:	74 1e                	je     98f2 <fwp_hof0.constprop.0+0x812>
    98d4:	90                   	nop
    98d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98dc:	00 00 00 00 
    98e0:	4a 8b 04 f1          	mov    (%rcx,%r14,8),%rax
    98e4:	4b 89 44 f7 08       	mov    %rax,0x8(%r15,%r14,8)
    98e9:	49 83 c6 01          	add    $0x1,%r14
    98ed:	4c 39 f3             	cmp    %r14,%rbx
    98f0:	75 ee                	jne    98e0 <fwp_hof0.constprop.0+0x800>
    98f2:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    98f9:	00 
    98fa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    98ff:	4c 89 25 12 ab 01 00 	mov    %r12,0x1ab12(%rip)        # 24418 <fwp_cleanups>
    9906:	e8 85 b5 ff ff       	call   4e90 <fwp_tape_buffers_release>
    990b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9912:	4c 89 f8             	mov    %r15,%rax
    9915:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    991c:	48 c1 e2 10          	shl    $0x10,%rdx
    9920:	48 39 d0             	cmp    %rdx,%rax
    9923:	73 57                	jae    997c <fwp_hof0.constprop.0+0x89c>
    9925:	48 89 c2             	mov    %rax,%rdx
    9928:	48 c1 ea 10          	shr    $0x10,%rdx
    992c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9930:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9937:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    993b:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    993f:	48 85 ed             	test   %rbp,%rbp
    9942:	74 38                	je     997c <fwp_hof0.constprop.0+0x89c>
    9944:	0f b6 0a             	movzbl (%rdx),%ecx
    9947:	80 f9 02             	cmp    $0x2,%cl
    994a:	0f 84 d0 0b 00 00    	je     a520 <fwp_hof0.constprop.0+0x1440>
    9950:	80 f9 01             	cmp    $0x1,%cl
    9953:	75 27                	jne    997c <fwp_hof0.constprop.0+0x89c>
    9955:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9958:	0f b7 c0             	movzwl %ax,%eax
    995b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    995e:	48 0f af c1          	imul   %rcx,%rax
    9962:	48 c1 e8 20          	shr    $0x20,%rax
    9966:	48 39 d0             	cmp    %rdx,%rax
    9969:	73 11                	jae    997c <fwp_hof0.constprop.0+0x89c>
    996b:	48 01 c5             	add    %rax,%rbp
    996e:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9972:	0f 84 bb 0b 00 00    	je     a533 <fwp_hof0.constprop.0+0x1453>
    9978:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    997c:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
    9981:	0f 85 c4 9d ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9987:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    998e:	00 
    998f:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9994:	48 89 05 7d aa 01 00 	mov    %rax,0x1aa7d(%rip)        # 24418 <fwp_cleanups>
    999b:	e8 80 d0 ff ff       	call   6a20 <fwp_tape_scope_release>
    99a0:	49 8b 07             	mov    (%r15),%rax
    99a3:	49 89 c6             	mov    %rax,%r14
    99a6:	49 0f ba f6 3f       	btr    $0x3f,%r14
    99ab:	48 85 c0             	test   %rax,%rax
    99ae:	0f 88 2c 08 00 00    	js     a1e0 <fwp_hof0.constprop.0+0x1100>
    99b4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    99bb:	4c 89 f8             	mov    %r15,%rax
    99be:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    99c5:	48 c1 e2 10          	shl    $0x10,%rdx
    99c9:	48 39 d0             	cmp    %rdx,%rax
    99cc:	0f 83 0e 08 00 00    	jae    a1e0 <fwp_hof0.constprop.0+0x1100>
    99d2:	48 89 c2             	mov    %rax,%rdx
    99d5:	48 c1 ea 10          	shr    $0x10,%rdx
    99d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99dd:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    99e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99e8:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    99ec:	48 85 c9             	test   %rcx,%rcx
    99ef:	0f 84 eb 07 00 00    	je     a1e0 <fwp_hof0.constprop.0+0x1100>
    99f5:	0f b6 32             	movzbl (%rdx),%esi
    99f8:	40 80 fe 02          	cmp    $0x2,%sil
    99fc:	0f 84 c6 07 00 00    	je     a1c8 <fwp_hof0.constprop.0+0x10e8>
    9a02:	40 80 fe 01          	cmp    $0x1,%sil
    9a06:	0f 85 d4 07 00 00    	jne    a1e0 <fwp_hof0.constprop.0+0x1100>
    9a0c:	8b 72 18             	mov    0x18(%rdx),%esi
    9a0f:	0f b7 c0             	movzwl %ax,%eax
    9a12:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a15:	48 0f af c6          	imul   %rsi,%rax
    9a19:	48 c1 e8 20          	shr    $0x20,%rax
    9a1d:	48 39 d0             	cmp    %rdx,%rax
    9a20:	0f 83 ba 07 00 00    	jae    a1e0 <fwp_hof0.constprop.0+0x1100>
    9a26:	48 01 c1             	add    %rax,%rcx
    9a29:	80 39 01             	cmpb   $0x1,(%rcx)
    9a2c:	0f 85 ae 07 00 00    	jne    a1e0 <fwp_hof0.constprop.0+0x1100>
    9a32:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    9a37:	4c 89 fd             	mov    %r15,%rbp
    9a3a:	31 ff                	xor    %edi,%edi
    9a3c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9a41:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9a45:	31 c0                	xor    %eax,%eax
    9a47:	4d 85 f6             	test   %r14,%r14
    9a4a:	75 2e                	jne    9a7a <fwp_hof0.constprop.0+0x99a>
    9a4c:	eb 42                	jmp    9a90 <fwp_hof0.constprop.0+0x9b0>
    9a4e:	66 90                	xchg   %ax,%ax
    9a50:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9a55:	0f 88 2a 0e 00 00    	js     a885 <fwp_hof0.constprop.0+0x17a5>
    9a5b:	f2 0f 10 05 5d 50 00 	movsd  0x505d(%rip),%xmm0        # eac0 <msg.8+0x40>
    9a62:	00 
    9a63:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9a68:	48 83 c0 01          	add    $0x1,%rax
    9a6c:	48 83 c2 08          	add    $0x8,%rdx
    9a70:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9a75:	49 39 c6             	cmp    %rax,%r14
    9a78:	74 16                	je     9a90 <fwp_hof0.constprop.0+0x9b0>
    9a7a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9a7e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9a82:	79 cc                	jns    9a50 <fwp_hof0.constprop.0+0x970>
    9a84:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9a88:	eb c6                	jmp    9a50 <fwp_hof0.constprop.0+0x970>
    9a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a90:	e8 bb de ff ff       	call   7950 <fwp_drop10>
    9a95:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9a9a:	31 d2                	xor    %edx,%edx
    9a9c:	48 89 d8             	mov    %rbx,%rax
    9a9f:	48 85 db             	test   %rbx,%rbx
    9aa2:	0f 84 11 0c 00 00    	je     a6b9 <fwp_hof0.constprop.0+0x15d9>
    9aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9aaf:	00 
    9ab0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ab4:	48 83 c2 01          	add    $0x1,%rdx
    9ab8:	48 85 c0             	test   %rax,%rax
    9abb:	75 f3                	jne    9ab0 <fwp_hof0.constprop.0+0x9d0>
    9abd:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9ac1:	49 89 c7             	mov    %rax,%r15
    9ac4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9ac9:	48 85 c0             	test   %rax,%rax
    9acc:	0f 88 cb 05 00 00    	js     a09d <fwp_hof0.constprop.0+0xfbd>
    9ad2:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9ad9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9ade:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9ae5:	48 c1 e0 10          	shl    $0x10,%rax
    9ae9:	48 39 c1             	cmp    %rax,%rcx
    9aec:	0f 83 ab 05 00 00    	jae    a09d <fwp_hof0.constprop.0+0xfbd>
    9af2:	48 89 c8             	mov    %rcx,%rax
    9af5:	48 c1 e8 10          	shr    $0x10,%rax
    9af9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9afd:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9b04:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9b08:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9b0c:	48 85 ff             	test   %rdi,%rdi
    9b0f:	0f 84 88 05 00 00    	je     a09d <fwp_hof0.constprop.0+0xfbd>
    9b15:	0f b6 06             	movzbl (%rsi),%eax
    9b18:	3c 02                	cmp    $0x2,%al
    9b1a:	0f 84 68 05 00 00    	je     a088 <fwp_hof0.constprop.0+0xfa8>
    9b20:	3c 01                	cmp    $0x1,%al
    9b22:	0f 85 69 05 00 00    	jne    a091 <fwp_hof0.constprop.0+0xfb1>
    9b28:	8b 46 18             	mov    0x18(%rsi),%eax
    9b2b:	0f b7 c9             	movzwl %cx,%ecx
    9b2e:	48 0f af c8          	imul   %rax,%rcx
    9b32:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9b35:	48 c1 e9 20          	shr    $0x20,%rcx
    9b39:	48 39 c1             	cmp    %rax,%rcx
    9b3c:	0f 83 4f 05 00 00    	jae    a091 <fwp_hof0.constprop.0+0xfb1>
    9b42:	48 01 cf             	add    %rcx,%rdi
    9b45:	80 3f 01             	cmpb   $0x1,(%rdi)
    9b48:	0f 85 43 05 00 00    	jne    a091 <fwp_hof0.constprop.0+0xfb1>
    9b4e:	4c 39 fa             	cmp    %r15,%rdx
    9b51:	4c 89 f8             	mov    %r15,%rax
    9b54:	48 0f 46 c2          	cmovbe %rdx,%rax
    9b58:	48 85 c0             	test   %rax,%rax
    9b5b:	0f 84 30 0d 00 00    	je     a891 <fwp_hof0.constprop.0+0x17b1>
    9b61:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    9b68:	00 
    9b69:	4c 8d 65 08          	lea    0x8(%rbp),%r12
    9b6d:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    9b72:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9b77:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9b7e:	00 
    9b7f:	31 d2                	xor    %edx,%edx
    9b81:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9b85:	eb 56                	jmp    9bdd <fwp_hof0.constprop.0+0xafd>
    9b87:	66 90                	xchg   %ax,%ax
    9b89:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b90:	00 00 00 00 
    9b94:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b9b:	00 00 00 00 
    9b9f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ba6:	00 00 00 00 
    9baa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bb1:	00 00 00 00 
    9bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bbc:	00 00 00 00 
    9bc0:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9bc5:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9bca:	f2 41 0f 11 04 14    	movsd  %xmm0,(%r12,%rdx,1)
    9bd0:	48 83 c2 08          	add    $0x8,%rdx
    9bd4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9bd8:	49 39 d1             	cmp    %rdx,%r9
    9bdb:	74 13                	je     9bf0 <fwp_hof0.constprop.0+0xb10>
    9bdd:	48 89 fe             	mov    %rdi,%rsi
    9be0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9be5:	79 d9                	jns    9bc0 <fwp_hof0.constprop.0+0xae0>
    9be7:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9beb:	eb d3                	jmp    9bc0 <fwp_hof0.constprop.0+0xae0>
    9bed:	0f 1f 00             	nopl   (%rax)
    9bf0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9bf5:	48 85 c9             	test   %rcx,%rcx
    9bf8:	0f 84 67 0c 00 00    	je     a865 <fwp_hof0.constprop.0+0x1785>
    9bfe:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9c05:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9c0c:	45 31 ff             	xor    %r15d,%r15d
    9c0f:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9c16:	49 c1 e1 10          	shl    $0x10,%r9
    9c1a:	eb 1a                	jmp    9c36 <fwp_hof0.constprop.0+0xb56>
    9c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c20:	49 83 c7 01          	add    $0x1,%r15
    9c24:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9c28:	49 39 c7             	cmp    %rax,%r15
    9c2b:	0f 83 5f 01 00 00    	jae    9d90 <fwp_hof0.constprop.0+0xcb0>
    9c31:	48 85 c9             	test   %rcx,%rcx
    9c34:	74 56                	je     9c8c <fwp_hof0.constprop.0+0xbac>
    9c36:	48 89 ca             	mov    %rcx,%rdx
    9c39:	4c 29 d2             	sub    %r10,%rdx
    9c3c:	4c 39 ca             	cmp    %r9,%rdx
    9c3f:	73 4b                	jae    9c8c <fwp_hof0.constprop.0+0xbac>
    9c41:	48 89 d6             	mov    %rdx,%rsi
    9c44:	48 c1 ee 10          	shr    $0x10,%rsi
    9c48:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9c4c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9c50:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9c54:	48 85 ff             	test   %rdi,%rdi
    9c57:	74 33                	je     9c8c <fwp_hof0.constprop.0+0xbac>
    9c59:	44 0f b6 06          	movzbl (%rsi),%r8d
    9c5d:	41 80 f8 02          	cmp    $0x2,%r8b
    9c61:	0f 84 11 01 00 00    	je     9d78 <fwp_hof0.constprop.0+0xc98>
    9c67:	41 80 f8 01          	cmp    $0x1,%r8b
    9c6b:	75 1f                	jne    9c8c <fwp_hof0.constprop.0+0xbac>
    9c6d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9c71:	0f b7 d2             	movzwl %dx,%edx
    9c74:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9c77:	49 0f af d0          	imul   %r8,%rdx
    9c7b:	48 c1 ea 20          	shr    $0x20,%rdx
    9c7f:	48 39 f2             	cmp    %rsi,%rdx
    9c82:	73 08                	jae    9c8c <fwp_hof0.constprop.0+0xbac>
    9c84:	48 01 d7             	add    %rdx,%rdi
    9c87:	80 3f 01             	cmpb   $0x1,(%rdi)
    9c8a:	74 94                	je     9c20 <fwp_hof0.constprop.0+0xb40>
    9c8c:	49 39 c7             	cmp    %rax,%r15
    9c8f:	0f 83 fb 00 00 00    	jae    9d90 <fwp_hof0.constprop.0+0xcb0>
    9c95:	48 89 c3             	mov    %rax,%rbx
    9c98:	45 31 f6             	xor    %r14d,%r14d
    9c9b:	48 8d ac 24 10 01 00 	lea    0x110(%rsp),%rbp
    9ca2:	00 
    9ca3:	eb 37                	jmp    9cdc <fwp_hof0.constprop.0+0xbfc>
    9ca5:	0f 1f 00             	nopl   (%rax)
    9ca8:	40 80 fe 01          	cmp    $0x1,%sil
    9cac:	75 25                	jne    9cd3 <fwp_hof0.constprop.0+0xbf3>
    9cae:	8b 71 18             	mov    0x18(%rcx),%esi
    9cb1:	0f b7 c0             	movzwl %ax,%eax
    9cb4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9cb7:	48 0f af c6          	imul   %rsi,%rax
    9cbb:	48 c1 e8 20          	shr    $0x20,%rax
    9cbf:	48 39 c8             	cmp    %rcx,%rax
    9cc2:	73 0f                	jae    9cd3 <fwp_hof0.constprop.0+0xbf3>
    9cc4:	48 01 c2             	add    %rax,%rdx
    9cc7:	80 3a ff             	cmpb   $0xff,(%rdx)
    9cca:	0f 84 c0 05 00 00    	je     a290 <fwp_hof0.constprop.0+0x11b0>
    9cd0:	c6 02 01             	movb   $0x1,(%rdx)
    9cd3:	49 39 df             	cmp    %rbx,%r15
    9cd6:	0f 83 84 00 00 00    	jae    9d60 <fwp_hof0.constprop.0+0xc80>
    9cdc:	48 83 eb 01          	sub    $0x1,%rbx
    9ce0:	66 49 0f 6e f6       	movq   %r14,%xmm6
    9ce5:	48 89 ee             	mov    %rbp,%rsi
    9ce8:	bf 01 00 00 00       	mov    $0x1,%edi
    9ced:	f3 41 0f 7e 04 dc    	movq   (%r12,%rbx,8),%xmm0
    9cf3:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9cf7:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    9cfe:	00 
    9cff:	e8 cc be ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    9d04:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9d0b:	49 89 c6             	mov    %rax,%r14
    9d0e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9d15:	48 c1 e2 10          	shl    $0x10,%rdx
    9d19:	48 39 d0             	cmp    %rdx,%rax
    9d1c:	73 b5                	jae    9cd3 <fwp_hof0.constprop.0+0xbf3>
    9d1e:	48 89 c2             	mov    %rax,%rdx
    9d21:	48 c1 ea 10          	shr    $0x10,%rdx
    9d25:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d29:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9d30:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9d34:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9d38:	48 85 d2             	test   %rdx,%rdx
    9d3b:	74 96                	je     9cd3 <fwp_hof0.constprop.0+0xbf3>
    9d3d:	0f b6 31             	movzbl (%rcx),%esi
    9d40:	40 80 fe 02          	cmp    $0x2,%sil
    9d44:	0f 85 5e ff ff ff    	jne    9ca8 <fwp_hof0.constprop.0+0xbc8>
    9d4a:	66 85 c0             	test   %ax,%ax
    9d4d:	0f 84 74 ff ff ff    	je     9cc7 <fwp_hof0.constprop.0+0xbe7>
    9d53:	49 39 df             	cmp    %rbx,%r15
    9d56:	72 84                	jb     9cdc <fwp_hof0.constprop.0+0xbfc>
    9d58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d5f:	00 
    9d60:	4d 85 ff             	test   %r15,%r15
    9d63:	75 2e                	jne    9d93 <fwp_hof0.constprop.0+0xcb3>
    9d65:	8b 44 24 30          	mov    0x30(%rsp),%eax
    9d69:	85 c0                	test   %eax,%eax
    9d6b:	4d 0f 45 e7          	cmovne %r15,%r12
    9d6f:	eb 63                	jmp    9dd4 <fwp_hof0.constprop.0+0xcf4>
    9d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9d78:	66 85 d2             	test   %dx,%dx
    9d7b:	0f 84 06 ff ff ff    	je     9c87 <fwp_hof0.constprop.0+0xba7>
    9d81:	49 39 c7             	cmp    %rax,%r15
    9d84:	0f 82 0b ff ff ff    	jb     9c95 <fwp_hof0.constprop.0+0xbb5>
    9d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d90:	45 31 f6             	xor    %r14d,%r14d
    9d93:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d98:	4c 89 e2             	mov    %r12,%rdx
    9d9b:	4f 8d 0c fc          	lea    (%r12,%r15,8),%r9
    9d9f:	90                   	nop
    9da0:	48 8b 0a             	mov    (%rdx),%rcx
    9da3:	48 83 c2 08          	add    $0x8,%rdx
    9da7:	48 89 c7             	mov    %rax,%rdi
    9daa:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9dae:	48 8b 40 10          	mov    0x10(%rax),%rax
    9db2:	4c 39 ca             	cmp    %r9,%rdx
    9db5:	75 e9                	jne    9da0 <fwp_hof0.constprop.0+0xcc0>
    9db7:	8b 54 24 30          	mov    0x30(%rsp),%edx
    9dbb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9dbf:	85 d2                	test   %edx,%edx
    9dc1:	0f 84 79 07 00 00    	je     a540 <fwp_hof0.constprop.0+0x1460>
    9dc7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9dcc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9dd1:	45 31 e4             	xor    %r12d,%r12d
    9dd4:	4c 89 e7             	mov    %r12,%rdi
    9dd7:	e8 d4 b7 ff ff       	call   55b0 <fwp_mem_free>
    9ddc:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    9de1:	e8 6a db ff ff       	call   7950 <fwp_drop10>
    9de6:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9ded:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9df2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9df9:	48 c1 e2 10          	shl    $0x10,%rdx
    9dfd:	48 39 d0             	cmp    %rdx,%rax
    9e00:	73 6e                	jae    9e70 <fwp_hof0.constprop.0+0xd90>
    9e02:	48 89 c2             	mov    %rax,%rdx
    9e05:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    9e0c:	48 c1 ea 10          	shr    $0x10,%rdx
    9e10:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9e14:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9e18:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9e1c:	48 85 ed             	test   %rbp,%rbp
    9e1f:	74 4f                	je     9e70 <fwp_hof0.constprop.0+0xd90>
    9e21:	0f b6 0a             	movzbl (%rdx),%ecx
    9e24:	80 f9 02             	cmp    $0x2,%cl
    9e27:	0f 84 a3 06 00 00    	je     a4d0 <fwp_hof0.constprop.0+0x13f0>
    9e2d:	80 f9 01             	cmp    $0x1,%cl
    9e30:	75 3e                	jne    9e70 <fwp_hof0.constprop.0+0xd90>
    9e32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e35:	0f b7 c0             	movzwl %ax,%eax
    9e38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e3b:	48 0f af c1          	imul   %rcx,%rax
    9e3f:	48 c1 e8 20          	shr    $0x20,%rax
    9e43:	48 39 d0             	cmp    %rdx,%rax
    9e46:	73 28                	jae    9e70 <fwp_hof0.constprop.0+0xd90>
    9e48:	48 01 c5             	add    %rax,%rbp
    9e4b:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    9e4f:	84 c0                	test   %al,%al
    9e51:	74 1d                	je     9e70 <fwp_hof0.constprop.0+0xd90>
    9e53:	3c 01                	cmp    $0x1,%al
    9e55:	0f 84 f5 06 00 00    	je     a550 <fwp_hof0.constprop.0+0x1470>
    9e5b:	3c ff                	cmp    $0xff,%al
    9e5d:	0f 84 d1 08 00 00    	je     a734 <fwp_hof0.constprop.0+0x1654>
    9e63:	83 e8 01             	sub    $0x1,%eax
    9e66:	88 45 00             	mov    %al,0x0(%rbp)
    9e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9e70:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    9e76:	0f 85 04 05 00 00    	jne    a380 <fwp_hof0.constprop.0+0x12a0>
    9e7c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9e81:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e85:	4c 89 f6             	mov    %r14,%rsi
    9e88:	4c 89 f5             	mov    %r14,%rbp
    9e8b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9e90:	48 8d 15 09 7d 00 00 	lea    0x7d09(%rip),%rdx        # 11ba0 <d0>
    9e97:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    9e9e:	00 00 00 00 00 
    9ea3:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9eaa:	00 
    9eab:	e8 f0 e1 ff ff       	call   80a0 <fwp_write>
    9eb0:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
    9eb7:	00 
    9eb8:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    9ebf:	00 
    9ec0:	48 8d 05 67 41 00 00 	lea    0x4167(%rip),%rax        # e02e <_IO_stdin_used+0x2e>
    9ec7:	48 85 c9             	test   %rcx,%rcx
    9eca:	48 0f 44 c8          	cmove  %rax,%rcx
    9ece:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    9ed2:	0f 87 8f 0a 00 00    	ja     a967 <fwp_hof0.constprop.0+0x1887>
    9ed8:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    9edc:	be 01 00 00 00       	mov    $0x1,%esi
    9ee1:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9ee6:	e8 c5 bb ff ff       	call   5ab0 <fwp_heap_alloc>
    9eeb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9ef0:	4c 89 fa             	mov    %r15,%rdx
    9ef3:	4c 89 38             	mov    %r15,(%rax)
    9ef6:	4c 8d 60 08          	lea    0x8(%rax),%r12
    9efa:	48 89 c3             	mov    %rax,%rbx
    9efd:	4c 89 e7             	mov    %r12,%rdi
    9f00:	e8 9b 96 ff ff       	call   35a0 <memcpy@plt>
    9f05:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    9f0b:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    9f12:	00 
    9f13:	e8 a8 94 ff ff       	call   33c0 <free@plt>
    9f18:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9f1f:	48 89 d8             	mov    %rbx,%rax
    9f22:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9f29:	48 c1 e2 10          	shl    $0x10,%rdx
    9f2d:	48 39 d0             	cmp    %rdx,%rax
    9f30:	73 57                	jae    9f89 <fwp_hof0.constprop.0+0xea9>
    9f32:	48 89 c2             	mov    %rax,%rdx
    9f35:	48 c1 ea 10          	shr    $0x10,%rdx
    9f39:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f3d:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9f44:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f48:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9f4c:	4d 85 ff             	test   %r15,%r15
    9f4f:	74 38                	je     9f89 <fwp_hof0.constprop.0+0xea9>
    9f51:	0f b6 0a             	movzbl (%rdx),%ecx
    9f54:	80 f9 02             	cmp    $0x2,%cl
    9f57:	0f 84 33 07 00 00    	je     a690 <fwp_hof0.constprop.0+0x15b0>
    9f5d:	80 f9 01             	cmp    $0x1,%cl
    9f60:	75 27                	jne    9f89 <fwp_hof0.constprop.0+0xea9>
    9f62:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f65:	0f b7 c0             	movzwl %ax,%eax
    9f68:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f6b:	48 0f af c1          	imul   %rcx,%rax
    9f6f:	48 c1 e8 20          	shr    $0x20,%rax
    9f73:	48 39 d0             	cmp    %rdx,%rax
    9f76:	73 11                	jae    9f89 <fwp_hof0.constprop.0+0xea9>
    9f78:	49 01 c7             	add    %rax,%r15
    9f7b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9f7f:	0f 84 1e 07 00 00    	je     a6a3 <fwp_hof0.constprop.0+0x15c3>
    9f85:	41 c6 07 01          	movb   $0x1,(%r15)
    9f89:	48 89 ef             	mov    %rbp,%rdi
    9f8c:	e8 cf d5 ff ff       	call   7560 <fwp_drop0>
    9f91:	48 8b 13             	mov    (%rbx),%rdx
    9f94:	be 01 00 00 00       	mov    $0x1,%esi
    9f99:	4c 89 e7             	mov    %r12,%rdi
    9f9c:	48 8b 0d 3d a4 01 00 	mov    0x1a43d(%rip),%rcx        # 243e0 <fwp_prog_out>
    9fa3:	e8 d8 96 ff ff       	call   3680 <fwrite@plt>
    9fa8:	48 8b 35 31 a4 01 00 	mov    0x1a431(%rip),%rsi        # 243e0 <fwp_prog_out>
    9faf:	bf 0a 00 00 00       	mov    $0xa,%edi
    9fb4:	e8 27 95 ff ff       	call   34e0 <fputc@plt>
    9fb9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9fc0:	48 89 d8             	mov    %rbx,%rax
    9fc3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9fca:	48 c1 e2 10          	shl    $0x10,%rdx
    9fce:	48 39 d0             	cmp    %rdx,%rax
    9fd1:	73 6d                	jae    a040 <fwp_hof0.constprop.0+0xf60>
    9fd3:	48 89 c2             	mov    %rax,%rdx
    9fd6:	48 c1 ea 10          	shr    $0x10,%rdx
    9fda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fde:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9fe5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fe9:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9fed:	48 85 ed             	test   %rbp,%rbp
    9ff0:	74 4e                	je     a040 <fwp_hof0.constprop.0+0xf60>
    9ff2:	0f b6 0a             	movzbl (%rdx),%ecx
    9ff5:	80 f9 02             	cmp    $0x2,%cl
    9ff8:	0f 84 62 06 00 00    	je     a660 <fwp_hof0.constprop.0+0x1580>
    9ffe:	80 f9 01             	cmp    $0x1,%cl
    a001:	75 3d                	jne    a040 <fwp_hof0.constprop.0+0xf60>
    a003:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a006:	0f b7 c0             	movzwl %ax,%eax
    a009:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a00c:	48 0f af c1          	imul   %rcx,%rax
    a010:	48 c1 e8 20          	shr    $0x20,%rax
    a014:	48 39 d0             	cmp    %rdx,%rax
    a017:	73 27                	jae    a040 <fwp_hof0.constprop.0+0xf60>
    a019:	48 01 c5             	add    %rax,%rbp
    a01c:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a020:	84 c0                	test   %al,%al
    a022:	74 1c                	je     a040 <fwp_hof0.constprop.0+0xf60>
    a024:	3c 01                	cmp    $0x1,%al
    a026:	0f 84 51 06 00 00    	je     a67d <fwp_hof0.constprop.0+0x159d>
    a02c:	3c ff                	cmp    $0xff,%al
    a02e:	0f 84 71 07 00 00    	je     a7a5 <fwp_hof0.constprop.0+0x16c5>
    a034:	83 e8 01             	sub    $0x1,%eax
    a037:	88 45 00             	mov    %al,0x0(%rbp)
    a03a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a040:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    a045:	48 8b 40 10          	mov    0x10(%rax),%rax
    a049:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    a04e:	48 85 c0             	test   %rax,%rax
    a051:	0f 85 c9 f0 ff ff    	jne    9120 <fwp_hof0.constprop.0+0x40>
    a057:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    a05e:	00 
    a05f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a066:	00 00 
    a068:	0f 85 f4 08 00 00    	jne    a962 <fwp_hof0.constprop.0+0x1882>
    a06e:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    a075:	31 c0                	xor    %eax,%eax
    a077:	5b                   	pop    %rbx
    a078:	5d                   	pop    %rbp
    a079:	41 5c                	pop    %r12
    a07b:	41 5d                	pop    %r13
    a07d:	41 5e                	pop    %r14
    a07f:	41 5f                	pop    %r15
    a081:	c3                   	ret
    a082:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a088:	66 85 c9             	test   %cx,%cx
    a08b:	0f 84 b4 fa ff ff    	je     9b45 <fwp_hof0.constprop.0+0xa65>
    a091:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a097:	0f 84 a6 02 00 00    	je     a343 <fwp_hof0.constprop.0+0x1263>
    a09d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a0a2:	45 31 f6             	xor    %r14d,%r14d
    a0a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0ac:	00 00 00 00 
    a0b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a0b4:	4c 89 f2             	mov    %r14,%rdx
    a0b7:	49 83 c6 01          	add    $0x1,%r14
    a0bb:	48 85 c0             	test   %rax,%rax
    a0be:	75 f0                	jne    a0b0 <fwp_hof0.constprop.0+0xfd0>
    a0c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a0c7:	ff ff 1f 
    a0ca:	4c 39 f0             	cmp    %r14,%rax
    a0cd:	0f 82 de 07 00 00    	jb     a8b1 <fwp_hof0.constprop.0+0x17d1>
    a0d3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a0da:	00 
    a0db:	be 02 00 00 00       	mov    $0x2,%esi
    a0e0:	e8 cb b9 ff ff       	call   5ab0 <fwp_heap_alloc>
    a0e5:	4d 39 f7             	cmp    %r14,%r15
    a0e8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a0ed:	49 89 c4             	mov    %rax,%r12
    a0f0:	4c 89 f0             	mov    %r14,%rax
    a0f3:	49 0f 46 c7          	cmovbe %r15,%rax
    a0f7:	4c 89 e1             	mov    %r12,%rcx
    a0fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a100:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a104:	48 83 c1 08          	add    $0x8,%rcx
    a108:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a10c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a110:	48 85 d2             	test   %rdx,%rdx
    a113:	75 eb                	jne    a100 <fwp_hof0.constprop.0+0x1020>
    a115:	48 85 c0             	test   %rax,%rax
    a118:	0f 84 37 02 00 00    	je     a355 <fwp_hof0.constprop.0+0x1275>
    a11e:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a125:	00 
    a126:	e9 42 fa ff ff       	jmp    9b6d <fwp_hof0.constprop.0+0xa8d>
    a12b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a130:	4c 39 fd             	cmp    %r15,%rbp
    a133:	0f 84 e7 f1 ff ff    	je     9320 <fwp_hof0.constprop.0+0x240>
    a139:	48 8b 1d d0 7f 01 00 	mov    0x17fd0(%rip),%rbx        # 22110 <fwp_tapes>
    a140:	e9 7e f2 ff ff       	jmp    93c3 <fwp_hof0.constprop.0+0x2e3>
    a145:	0f 1f 00             	nopl   (%rax)
    a148:	48 83 3d 58 7f 01 00 	cmpq   $0x0,0x17f58(%rip)        # 220a8 <fwp_tape_cached_bytes>
    a14f:	00 
    a150:	0f 84 b3 f2 ff ff    	je     9409 <fwp_hof0.constprop.0+0x329>
    a156:	66 0f 6f 0d 62 7f 01 	movdqa 0x17f62(%rip),%xmm1        # 220c0 <fwp_tape_workspace>
    a15d:	00 
    a15e:	48 c7 05 3f 7f 01 00 	movq   $0x0,0x17f3f(%rip)        # 220a8 <fwp_tape_cached_bytes>
    a165:	00 00 00 00 
    a169:	0f 11 4d 20          	movups %xmm1,0x20(%rbp)
    a16d:	48 8b 05 6c 7f 01 00 	mov    0x17f6c(%rip),%rax        # 220e0 <fwp_tape_workspace+0x20>
    a174:	66 0f 6f 0d 54 7f 01 	movdqa 0x17f54(%rip),%xmm1        # 220d0 <fwp_tape_workspace+0x10>
    a17b:	00 
    a17c:	48 89 45 40          	mov    %rax,0x40(%rbp)
    a180:	48 8b 05 61 7f 01 00 	mov    0x17f61(%rip),%rax        # 220e8 <fwp_tape_workspace+0x28>
    a187:	0f 11 4d 30          	movups %xmm1,0x30(%rbp)
    a18b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a18f:	48 89 45 18          	mov    %rax,0x18(%rbp)
    a193:	48 8b 05 56 7f 01 00 	mov    0x17f56(%rip),%rax        # 220f0 <fwp_tape_workspace+0x30>
    a19a:	0f 29 0d 1f 7f 01 00 	movaps %xmm1,0x17f1f(%rip)        # 220c0 <fwp_tape_workspace>
    a1a1:	48 89 45 48          	mov    %rax,0x48(%rbp)
    a1a5:	0f 29 0d 24 7f 01 00 	movaps %xmm1,0x17f24(%rip)        # 220d0 <fwp_tape_workspace+0x10>
    a1ac:	48 c7 05 39 7f 01 00 	movq   $0x0,0x17f39(%rip)        # 220f0 <fwp_tape_workspace+0x30>
    a1b3:	00 00 00 00 
    a1b7:	0f 29 0d 22 7f 01 00 	movaps %xmm1,0x17f22(%rip)        # 220e0 <fwp_tape_workspace+0x20>
    a1be:	e9 46 f2 ff ff       	jmp    9409 <fwp_hof0.constprop.0+0x329>
    a1c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a1c8:	66 85 c0             	test   %ax,%ax
    a1cb:	0f 84 58 f8 ff ff    	je     9a29 <fwp_hof0.constprop.0+0x949>
    a1d1:	0f 1f 40 00          	nopl   0x0(%rax)
    a1d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1dc:	00 00 00 00 
    a1e0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a1e7:	ff ff 1f 
    a1ea:	4c 39 f0             	cmp    %r14,%rax
    a1ed:	0f 82 b2 06 00 00    	jb     a8a5 <fwp_hof0.constprop.0+0x17c5>
    a1f3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a1fa:	00 
    a1fb:	be 01 00 00 00       	mov    $0x1,%esi
    a200:	e8 ab b8 ff ff       	call   5ab0 <fwp_heap_alloc>
    a205:	4c 89 30             	mov    %r14,(%rax)
    a208:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a20f:	48 89 c5             	mov    %rax,%rbp
    a212:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a217:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a21e:	48 c1 e2 10          	shl    $0x10,%rdx
    a222:	48 39 d0             	cmp    %rdx,%rax
    a225:	73 57                	jae    a27e <fwp_hof0.constprop.0+0x119e>
    a227:	48 89 c2             	mov    %rax,%rdx
    a22a:	48 c1 ea 10          	shr    $0x10,%rdx
    a22e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a232:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a239:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a23d:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a241:	48 85 db             	test   %rbx,%rbx
    a244:	74 38                	je     a27e <fwp_hof0.constprop.0+0x119e>
    a246:	0f b6 31             	movzbl (%rcx),%esi
    a249:	40 80 fe 02          	cmp    $0x2,%sil
    a24d:	0f 84 a5 03 00 00    	je     a5f8 <fwp_hof0.constprop.0+0x1518>
    a253:	40 80 fe 01          	cmp    $0x1,%sil
    a257:	75 25                	jne    a27e <fwp_hof0.constprop.0+0x119e>
    a259:	8b 71 18             	mov    0x18(%rcx),%esi
    a25c:	0f b7 c0             	movzwl %ax,%eax
    a25f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a262:	48 0f af c6          	imul   %rsi,%rax
    a266:	48 c1 e8 20          	shr    $0x20,%rax
    a26a:	48 39 c8             	cmp    %rcx,%rax
    a26d:	73 0f                	jae    a27e <fwp_hof0.constprop.0+0x119e>
    a26f:	48 01 c3             	add    %rax,%rbx
    a272:	80 3b ff             	cmpb   $0xff,(%rbx)
    a275:	0f 84 8f 03 00 00    	je     a60a <fwp_hof0.constprop.0+0x152a>
    a27b:	c6 03 01             	movb   $0x1,(%rbx)
    a27e:	4c 89 ff             	mov    %r15,%rdi
    a281:	e9 b6 f7 ff ff       	jmp    9a3c <fwp_hof0.constprop.0+0x95c>
    a286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a28d:	00 00 00 
    a290:	48 89 d7             	mov    %rdx,%rdi
    a293:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a298:	e8 d3 b0 ff ff       	call   5370 <fwp_rc_forget_slot>
    a29d:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a2a2:	e9 29 fa ff ff       	jmp    9cd0 <fwp_hof0.constprop.0+0xbf0>
    a2a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2ae:	00 00 
    a2b0:	48 c1 e1 10          	shl    $0x10,%rcx
    a2b4:	bf 08 00 00 00       	mov    $0x8,%edi
    a2b9:	48 09 f1             	or     %rsi,%rcx
    a2bc:	be 02 00 00 00       	mov    $0x2,%esi
    a2c1:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a2c6:	e8 e5 b7 ff ff       	call   5ab0 <fwp_heap_alloc>
    a2cb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a2d2:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a2d9:	48 89 c5             	mov    %rax,%rbp
    a2dc:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a2e3:	48 c1 e2 10          	shl    $0x10,%rdx
    a2e7:	48 39 d0             	cmp    %rdx,%rax
    a2ea:	0f 83 80 00 00 00    	jae    a370 <fwp_hof0.constprop.0+0x1290>
    a2f0:	48 89 c2             	mov    %rax,%rdx
    a2f3:	48 c1 ea 10          	shr    $0x10,%rdx
    a2f7:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a2fb:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a302:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a306:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a30a:	4d 85 ff             	test   %r15,%r15
    a30d:	0f 84 e0 f2 ff ff    	je     95f3 <fwp_hof0.constprop.0+0x513>
    a313:	0f b6 32             	movzbl (%rdx),%esi
    a316:	45 31 e4             	xor    %r12d,%r12d
    a319:	40 80 fe 02          	cmp    $0x2,%sil
    a31d:	0f 85 49 f2 ff ff    	jne    956c <fwp_hof0.constprop.0+0x48c>
    a323:	66 85 c0             	test   %ax,%ax
    a326:	0f 85 6d f2 ff ff    	jne    9599 <fwp_hof0.constprop.0+0x4b9>
    a32c:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a330:	0f 85 5f f2 ff ff    	jne    9595 <fwp_hof0.constprop.0+0x4b5>
    a336:	4c 89 ff             	mov    %r15,%rdi
    a339:	e8 32 b0 ff ff       	call   5370 <fwp_rc_forget_slot>
    a33e:	e9 52 f2 ff ff       	jmp    9595 <fwp_hof0.constprop.0+0x4b5>
    a343:	be 02 00 00 00       	mov    $0x2,%esi
    a348:	bf 08 00 00 00       	mov    $0x8,%edi
    a34d:	e8 5e b7 ff ff       	call   5ab0 <fwp_heap_alloc>
    a352:	49 89 c4             	mov    %rax,%r12
    a355:	45 31 f6             	xor    %r14d,%r14d
    a358:	e9 77 fa ff ff       	jmp    9dd4 <fwp_hof0.constprop.0+0xcf4>
    a35d:	0f 1f 00             	nopl   (%rax)
    a360:	4d 85 e4             	test   %r12,%r12
    a363:	0f 85 35 f2 ff ff    	jne    959e <fwp_hof0.constprop.0+0x4be>
    a369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a370:	31 db                	xor    %ebx,%ebx
    a372:	e9 e7 f2 ff ff       	jmp    965e <fwp_hof0.constprop.0+0x57e>
    a377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a37e:	00 00 
    a380:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a385:	45 31 c0             	xor    %r8d,%r8d
    a388:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a38d:	48 83 e8 01          	sub    $0x1,%rax
    a391:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a396:	41 0f 90 c0          	seto   %r8b
    a39a:	e9 10 ee ff ff       	jmp    91af <fwp_hof0.constprop.0+0xcf>
    a39f:	90                   	nop
    a3a0:	4d 8d 57 01          	lea    0x1(%r15),%r10
    a3a4:	4c 39 d2             	cmp    %r10,%rdx
    a3a7:	7c 42                	jl     a3eb <fwp_hof0.constprop.0+0x130b>
    a3a9:	48 85 c9             	test   %rcx,%rcx
    a3ac:	0f 84 23 05 00 00    	je     a8d5 <fwp_hof0.constprop.0+0x17f5>
    a3b2:	48 89 cf             	mov    %rcx,%rdi
    a3b5:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a3bc:	00 
    a3bd:	31 f6                	xor    %esi,%esi
    a3bf:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a3c4:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a3c9:	e8 f2 90 ff ff       	call   34c0 <memset@plt>
    a3ce:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a3d4:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a3da:	48 89 c1             	mov    %rax,%rcx
    a3dd:	e9 0d f4 ff ff       	jmp    97ef <fwp_hof0.constprop.0+0x70f>
    a3e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3e8:	49 89 da             	mov    %rbx,%r10
    a3eb:	48 85 d2             	test   %rdx,%rdx
    a3ee:	49 0f 44 d2          	cmove  %r10,%rdx
    a3f2:	eb 21                	jmp    a415 <fwp_hof0.constprop.0+0x1335>
    a3f4:	90                   	nop
    a3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3fc:	00 00 00 00 
    a400:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    a404:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a40b:	4c 89 d0             	mov    %r10,%rax
    a40e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a412:	48 89 c2             	mov    %rax,%rdx
    a415:	4c 39 d2             	cmp    %r10,%rdx
    a418:	7c e6                	jl     a400 <fwp_hof0.constprop.0+0x1320>
    a41a:	4c 89 54 24 78       	mov    %r10,0x78(%rsp)
    a41f:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    a424:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    a429:	48 85 c9             	test   %rcx,%rcx
    a42c:	0f 84 ee 01 00 00    	je     a620 <fwp_hof0.constprop.0+0x1540>
    a432:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a439:	00 
    a43a:	48 89 cf             	mov    %rcx,%rdi
    a43d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a442:	e8 89 91 ff ff       	call   35d0 <realloc@plt>
    a447:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a44c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    a452:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a458:	4c 8b 54 24 78       	mov    0x78(%rsp),%r10
    a45d:	48 89 c1             	mov    %rax,%rcx
    a460:	48 85 c9             	test   %rcx,%rcx
    a463:	0f 84 63 04 00 00    	je     a8cc <fwp_hof0.constprop.0+0x17ec>
    a469:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a470:	00 
    a471:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
    a478:	00 
    a479:	4d 85 d2             	test   %r10,%r10
    a47c:	0f 85 56 03 00 00    	jne    a7d8 <fwp_hof0.constprop.0+0x16f8>
    a482:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a489:	4d 85 e4             	test   %r12,%r12
    a48c:	0f 88 6f f3 ff ff    	js     9801 <fwp_hof0.constprop.0+0x721>
    a492:	45 89 e7             	mov    %r12d,%r15d
    a495:	e9 55 f3 ff ff       	jmp    97ef <fwp_hof0.constprop.0+0x70f>
    a49a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4a0:	48 8d 3d 99 c4 ff ff 	lea    -0x3b67(%rip),%rdi        # 6940 <fwp_tape_finish>
    a4a7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    a4ad:	e8 0e 3b 00 00       	call   dfc0 <atexit>
    a4b2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    a4b8:	85 c0                	test   %eax,%eax
    a4ba:	0f 85 b3 04 00 00    	jne    a973 <fwp_hof0.constprop.0+0x1893>
    a4c0:	c7 05 b2 7b 00 00 01 	movl   $0x1,0x7bb2(%rip)        # 1207c <registered_finish.5>
    a4c7:	00 00 00 
    a4ca:	e9 0e ee ff ff       	jmp    92dd <fwp_hof0.constprop.0+0x1fd>
    a4cf:	90                   	nop
    a4d0:	66 85 c0             	test   %ax,%ax
    a4d3:	0f 85 97 f9 ff ff    	jne    9e70 <fwp_hof0.constprop.0+0xd90>
    a4d9:	e9 6d f9 ff ff       	jmp    9e4b <fwp_hof0.constprop.0+0xd6b>
    a4de:	66 90                	xchg   %ax,%ax
    a4e0:	66 85 c0             	test   %ax,%ax
    a4e3:	0f 85 9f ed ff ff    	jne    9288 <fwp_hof0.constprop.0+0x1a8>
    a4e9:	e9 86 ed ff ff       	jmp    9274 <fwp_hof0.constprop.0+0x194>
    a4ee:	66 90                	xchg   %ax,%ax
    a4f0:	48 39 d3             	cmp    %rdx,%rbx
    a4f3:	0f 8f ef fe ff ff    	jg     a3e8 <fwp_hof0.constprop.0+0x1308>
    a4f9:	48 85 db             	test   %rbx,%rbx
    a4fc:	74 12                	je     a510 <fwp_hof0.constprop.0+0x1430>
    a4fe:	48 85 c9             	test   %rcx,%rcx
    a501:	0f 84 ce 03 00 00    	je     a8d5 <fwp_hof0.constprop.0+0x17f5>
    a507:	48 85 db             	test   %rbx,%rbx
    a50a:	0f 85 c5 02 00 00    	jne    a7d5 <fwp_hof0.constprop.0+0x16f5>
    a510:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a517:	e9 e5 f2 ff ff       	jmp    9801 <fwp_hof0.constprop.0+0x721>
    a51c:	0f 1f 40 00          	nopl   0x0(%rax)
    a520:	66 85 c0             	test   %ax,%ax
    a523:	0f 85 53 f4 ff ff    	jne    997c <fwp_hof0.constprop.0+0x89c>
    a529:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a52d:	0f 85 45 f4 ff ff    	jne    9978 <fwp_hof0.constprop.0+0x898>
    a533:	48 89 ef             	mov    %rbp,%rdi
    a536:	e8 35 ae ff ff       	call   5370 <fwp_rc_forget_slot>
    a53b:	e9 38 f4 ff ff       	jmp    9978 <fwp_hof0.constprop.0+0x898>
    a540:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a545:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a54a:	e9 85 f8 ff ff       	jmp    9dd4 <fwp_hof0.constprop.0+0xcf4>
    a54f:	90                   	nop
    a550:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a555:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a55c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a563:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a567:	48 29 c8             	sub    %rcx,%rax
    a56a:	48 c1 e2 10          	shl    $0x10,%rdx
    a56e:	48 39 d0             	cmp    %rdx,%rax
    a571:	73 67                	jae    a5da <fwp_hof0.constprop.0+0x14fa>
    a573:	48 89 c7             	mov    %rax,%rdi
    a576:	48 c1 ef 10          	shr    $0x10,%rdi
    a57a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a57e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a582:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a586:	48 85 ff             	test   %rdi,%rdi
    a589:	74 4f                	je     a5da <fwp_hof0.constprop.0+0x14fa>
    a58b:	44 0f b6 06          	movzbl (%rsi),%r8d
    a58f:	41 80 f8 02          	cmp    $0x2,%r8b
    a593:	0f 84 8d 01 00 00    	je     a726 <fwp_hof0.constprop.0+0x1646>
    a599:	41 80 f8 01          	cmp    $0x1,%r8b
    a59d:	75 3b                	jne    a5da <fwp_hof0.constprop.0+0x14fa>
    a59f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a5a3:	0f b7 c0             	movzwl %ax,%eax
    a5a6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a5a9:	49 0f af c0          	imul   %r8,%rax
    a5ad:	48 c1 e8 20          	shr    $0x20,%rax
    a5b1:	48 39 f0             	cmp    %rsi,%rax
    a5b4:	73 24                	jae    a5da <fwp_hof0.constprop.0+0x14fa>
    a5b6:	48 01 c7             	add    %rax,%rdi
    a5b9:	80 3f 01             	cmpb   $0x1,(%rdi)
    a5bc:	75 1c                	jne    a5da <fwp_hof0.constprop.0+0x14fa>
    a5be:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a5c3:	e8 e8 af ff ff       	call   55b0 <fwp_mem_free>
    a5c8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a5cf:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a5d6:	48 c1 e2 10          	shl    $0x10,%rdx
    a5da:	48 89 d8             	mov    %rbx,%rax
    a5dd:	48 29 c8             	sub    %rcx,%rax
    a5e0:	48 39 d0             	cmp    %rdx,%rax
    a5e3:	0f 83 87 f8 ff ff    	jae    9e70 <fwp_hof0.constprop.0+0xd90>
    a5e9:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    a5ee:	e9 0f f8 ff ff       	jmp    9e02 <fwp_hof0.constprop.0+0xd22>
    a5f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a5f8:	66 85 c0             	test   %ax,%ax
    a5fb:	0f 85 7d fc ff ff    	jne    a27e <fwp_hof0.constprop.0+0x119e>
    a601:	80 3b ff             	cmpb   $0xff,(%rbx)
    a604:	0f 85 71 fc ff ff    	jne    a27b <fwp_hof0.constprop.0+0x119b>
    a60a:	48 89 df             	mov    %rbx,%rdi
    a60d:	e8 5e ad ff ff       	call   5370 <fwp_rc_forget_slot>
    a612:	e9 64 fc ff ff       	jmp    a27b <fwp_hof0.constprop.0+0x119b>
    a617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a61e:	00 00 
    a620:	48 89 d7             	mov    %rdx,%rdi
    a623:	be 08 00 00 00       	mov    $0x8,%esi
    a628:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a62d:	e8 ee 8e ff ff       	call   3520 <calloc@plt>
    a632:	4c 8b 54 24 78       	mov    0x78(%rsp),%r10
    a637:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a63d:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    a643:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a648:	48 89 c1             	mov    %rax,%rcx
    a64b:	e9 10 fe ff ff       	jmp    a460 <fwp_hof0.constprop.0+0x1380>
    a650:	66 85 c0             	test   %ax,%ax
    a653:	0f 85 40 eb ff ff    	jne    9199 <fwp_hof0.constprop.0+0xb9>
    a659:	e9 27 eb ff ff       	jmp    9185 <fwp_hof0.constprop.0+0xa5>
    a65e:	66 90                	xchg   %ax,%ax
    a660:	66 85 c0             	test   %ax,%ax
    a663:	0f 85 d7 f9 ff ff    	jne    a040 <fwp_hof0.constprop.0+0xf60>
    a669:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a66d:	84 c0                	test   %al,%al
    a66f:	0f 84 cb f9 ff ff    	je     a040 <fwp_hof0.constprop.0+0xf60>
    a675:	3c 01                	cmp    $0x1,%al
    a677:	0f 85 af f9 ff ff    	jne    a02c <fwp_hof0.constprop.0+0xf4c>
    a67d:	48 89 df             	mov    %rbx,%rdi
    a680:	e8 2b af ff ff       	call   55b0 <fwp_mem_free>
    a685:	e9 b6 f9 ff ff       	jmp    a040 <fwp_hof0.constprop.0+0xf60>
    a68a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a690:	66 85 c0             	test   %ax,%ax
    a693:	0f 85 f0 f8 ff ff    	jne    9f89 <fwp_hof0.constprop.0+0xea9>
    a699:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a69d:	0f 85 e2 f8 ff ff    	jne    9f85 <fwp_hof0.constprop.0+0xea5>
    a6a3:	4c 89 ff             	mov    %r15,%rdi
    a6a6:	e8 c5 ac ff ff       	call   5370 <fwp_rc_forget_slot>
    a6ab:	e9 d5 f8 ff ff       	jmp    9f85 <fwp_hof0.constprop.0+0xea5>
    a6b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a6b4:	e9 16 ec ff ff       	jmp    92cf <fwp_hof0.constprop.0+0x1ef>
    a6b9:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a6bd:	48 85 c0             	test   %rax,%rax
    a6c0:	0f 88 7d fc ff ff    	js     a343 <fwp_hof0.constprop.0+0x1263>
    a6c6:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    a6cd:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a6d2:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    a6d9:	48 c1 e6 10          	shl    $0x10,%rsi
    a6dd:	48 39 f1             	cmp    %rsi,%rcx
    a6e0:	0f 83 5d fc ff ff    	jae    a343 <fwp_hof0.constprop.0+0x1263>
    a6e6:	48 89 ce             	mov    %rcx,%rsi
    a6e9:	48 c1 ee 10          	shr    $0x10,%rsi
    a6ed:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a6f1:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a6f8:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a6fc:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a700:	48 85 ff             	test   %rdi,%rdi
    a703:	0f 84 3a fc ff ff    	je     a343 <fwp_hof0.constprop.0+0x1263>
    a709:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a70e:	49 89 c7             	mov    %rax,%r15
    a711:	e9 ff f3 ff ff       	jmp    9b15 <fwp_hof0.constprop.0+0xa35>
    a716:	be 68 00 00 00       	mov    $0x68,%esi
    a71b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    a721:	e9 35 ec ff ff       	jmp    935b <fwp_hof0.constprop.0+0x27b>
    a726:	66 85 c0             	test   %ax,%ax
    a729:	0f 85 ab fe ff ff    	jne    a5da <fwp_hof0.constprop.0+0x14fa>
    a72f:	e9 85 fe ff ff       	jmp    a5b9 <fwp_hof0.constprop.0+0x14d9>
    a734:	48 89 ea             	mov    %rbp,%rdx
    a737:	48 c1 ea 11          	shr    $0x11,%rdx
    a73b:	48 31 ea             	xor    %rbp,%rdx
    a73e:	48 89 d0             	mov    %rdx,%rax
    a741:	48 c1 e8 09          	shr    $0x9,%rax
    a745:	48 31 c2             	xor    %rax,%rdx
    a748:	0f b6 d2             	movzbl %dl,%edx
    a74b:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a752:	00 
    a753:	48 85 c0             	test   %rax,%rax
    a756:	75 11                	jne    a769 <fwp_hof0.constprop.0+0x1689>
    a758:	eb 6f                	jmp    a7c9 <fwp_hof0.constprop.0+0x16e9>
    a75a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a760:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a764:	48 85 c0             	test   %rax,%rax
    a767:	74 60                	je     a7c9 <fwp_hof0.constprop.0+0x16e9>
    a769:	48 89 c2             	mov    %rax,%rdx
    a76c:	48 39 28             	cmp    %rbp,(%rax)
    a76f:	75 ef                	jne    a760 <fwp_hof0.constprop.0+0x1680>
    a771:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a775:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a779:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a77d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a784:	0f 85 e6 f6 ff ff    	jne    9e70 <fwp_hof0.constprop.0+0xd90>
    a78a:	48 89 ef             	mov    %rbp,%rdi
    a78d:	e8 de ab ff ff       	call   5370 <fwp_rc_forget_slot>
    a792:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a796:	e9 d5 f6 ff ff       	jmp    9e70 <fwp_hof0.constprop.0+0xd90>
    a79b:	e8 b0 aa ff ff       	call   5250 <fwp_rc_wide_dup>
    a7a0:	e9 e3 ea ff ff       	jmp    9288 <fwp_hof0.constprop.0+0x1a8>
    a7a5:	48 89 e8             	mov    %rbp,%rax
    a7a8:	48 c1 e8 11          	shr    $0x11,%rax
    a7ac:	48 31 e8             	xor    %rbp,%rax
    a7af:	48 89 c2             	mov    %rax,%rdx
    a7b2:	48 c1 ea 09          	shr    $0x9,%rdx
    a7b6:	48 31 d0             	xor    %rdx,%rax
    a7b9:	0f b6 d0             	movzbl %al,%edx
    a7bc:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a7c3:	00 
    a7c4:	48 85 c0             	test   %rax,%rax
    a7c7:	75 60                	jne    a829 <fwp_hof0.constprop.0+0x1749>
    a7c9:	48 8d 3d d0 3f 00 00 	lea    0x3fd0(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    a7d0:	e8 cb 99 ff ff       	call   41a0 <fwp_trap>
    a7d5:	49 89 da             	mov    %rbx,%r10
    a7d8:	48 89 cf             	mov    %rcx,%rdi
    a7db:	31 f6                	xor    %esi,%esi
    a7dd:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a7e2:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
    a7e6:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a7ed:	00 
    a7ee:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a7f3:	e8 c8 8c ff ff       	call   34c0 <memset@plt>
    a7f8:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a7fe:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a804:	48 89 c1             	mov    %rax,%rcx
    a807:	e9 7d fc ff ff       	jmp    a489 <fwp_hof0.constprop.0+0x13a9>
    a80c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a813:	00 00 
    a815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a81c:	00 00 00 00 
    a820:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a824:	48 85 c0             	test   %rax,%rax
    a827:	74 a0                	je     a7c9 <fwp_hof0.constprop.0+0x16e9>
    a829:	48 89 c2             	mov    %rax,%rdx
    a82c:	48 3b 28             	cmp    (%rax),%rbp
    a82f:	75 ef                	jne    a820 <fwp_hof0.constprop.0+0x1740>
    a831:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a835:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a839:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a83d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a844:	0f 85 f6 f7 ff ff    	jne    a040 <fwp_hof0.constprop.0+0xf60>
    a84a:	48 89 ef             	mov    %rbp,%rdi
    a84d:	e8 1e ab ff ff       	call   5370 <fwp_rc_forget_slot>
    a852:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a856:	e9 e5 f7 ff ff       	jmp    a040 <fwp_hof0.constprop.0+0xf60>
    a85b:	e8 f0 a9 ff ff       	call   5250 <fwp_rc_wide_dup>
    a860:	e9 34 e9 ff ff       	jmp    9199 <fwp_hof0.constprop.0+0xb9>
    a865:	45 31 ff             	xor    %r15d,%r15d
    a868:	e9 28 f4 ff ff       	jmp    9c95 <fwp_hof0.constprop.0+0xbb5>
    a86d:	48 8d 3d 54 3f 00 00 	lea    0x3f54(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    a874:	e8 27 99 ff ff       	call   41a0 <fwp_trap>
    a879:	48 8d 3d 84 38 00 00 	lea    0x3884(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    a880:	e8 1b 99 ff ff       	call   41a0 <fwp_trap>
    a885:	48 8d 3d 14 40 00 00 	lea    0x4014(%rip),%rdi        # e8a0 <_IO_stdin_used+0x8a0>
    a88c:	e8 0f 99 ff ff       	call   41a0 <fwp_trap>
    a891:	45 31 e4             	xor    %r12d,%r12d
    a894:	e9 bc fa ff ff       	jmp    a355 <fwp_hof0.constprop.0+0x1275>
    a899:	48 8d 3d 1e 39 00 00 	lea    0x391e(%rip),%rdi        # e1be <_IO_stdin_used+0x1be>
    a8a0:	e8 fb 98 ff ff       	call   41a0 <fwp_trap>
    a8a5:	48 8d 3d 2c 39 00 00 	lea    0x392c(%rip),%rdi        # e1d8 <_IO_stdin_used+0x1d8>
    a8ac:	e8 ef 98 ff ff       	call   41a0 <fwp_trap>
    a8b1:	48 8d 3d 75 38 00 00 	lea    0x3875(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    a8b8:	e8 e3 98 ff ff       	call   41a0 <fwp_trap>
    a8bd:	0f 1f 00             	nopl   (%rax)
    a8c0:	48 8d 3d 01 40 00 00 	lea    0x4001(%rip),%rdi        # e8c8 <_IO_stdin_used+0x8c8>
    a8c7:	e8 d4 98 ff ff       	call   41a0 <fwp_trap>
    a8cc:	4d 85 d2             	test   %r10,%r10
    a8cf:	0f 84 ad fb ff ff    	je     a482 <fwp_hof0.constprop.0+0x13a2>
    a8d5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    a8dc:	00 
    a8dd:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a8e2:	48 89 05 2f 9b 01 00 	mov    %rax,0x19b2f(%rip)        # 24418 <fwp_cleanups>
    a8e9:	e8 a2 a5 ff ff       	call   4e90 <fwp_tape_buffers_release>
    a8ee:	ba 13 00 00 00       	mov    $0x13,%edx
    a8f3:	48 8b 0d 46 77 00 00 	mov    0x7746(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a8fa:	be 01 00 00 00       	mov    $0x1,%esi
    a8ff:	48 8d 3d 02 37 00 00 	lea    0x3702(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a906:	e8 75 8d ff ff       	call   3680 <fwrite@plt>
    a90b:	31 ff                	xor    %edi,%edi
    a90d:	e8 ae 8c ff ff       	call   35c0 <fflush@plt>
    a912:	bf 66 00 00 00       	mov    $0x66,%edi
    a917:	e8 84 8d ff ff       	call   36a0 <_Exit@plt>
    a91c:	48 8d 3d 4d 3f 00 00 	lea    0x3f4d(%rip),%rdi        # e870 <_IO_stdin_used+0x870>
    a923:	e8 78 98 ff ff       	call   41a0 <fwp_trap>
    a928:	48 8b 0d 11 77 00 00 	mov    0x7711(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a92f:	ba 13 00 00 00       	mov    $0x13,%edx
    a934:	be 01 00 00 00       	mov    $0x1,%esi
    a939:	48 8d 3d c8 36 00 00 	lea    0x36c8(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a940:	e8 3b 8d ff ff       	call   3680 <fwrite@plt>
    a945:	31 ff                	xor    %edi,%edi
    a947:	e8 74 8c ff ff       	call   35c0 <fflush@plt>
    a94c:	bf 66 00 00 00       	mov    $0x66,%edi
    a951:	e8 4a 8d ff ff       	call   36a0 <_Exit@plt>
    a956:	48 8d 3d b3 3e 00 00 	lea    0x3eb3(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    a95d:	e8 3e 98 ff ff       	call   41a0 <fwp_trap>
    a962:	e8 f9 8a ff ff       	call   3460 <__stack_chk_fail@plt>
    a967:	48 8d 3d 7a 38 00 00 	lea    0x387a(%rip),%rdi        # e1e8 <_IO_stdin_used+0x1e8>
    a96e:	e8 2d 98 ff ff       	call   41a0 <fwp_trap>
    a973:	48 8b 0d c6 76 00 00 	mov    0x76c6(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a97a:	ba 13 00 00 00       	mov    $0x13,%edx
    a97f:	be 01 00 00 00       	mov    $0x1,%esi
    a984:	48 8d 3d 7d 36 00 00 	lea    0x367d(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a98b:	e8 f0 8c ff ff       	call   3680 <fwrite@plt>
    a990:	31 ff                	xor    %edi,%edi
    a992:	e8 29 8c ff ff       	call   35c0 <fflush@plt>
    a997:	bf 66 00 00 00       	mov    $0x66,%edi
    a99c:	e8 ff 8c ff ff       	call   36a0 <_Exit@plt>
    a9a1:	0f 1f 40 00          	nopl   0x0(%rax)
    a9a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9ac:	00 00 00 00 

000000000000a9b0 <f0>:
    a9b0:	41 56                	push   %r14
    a9b2:	4c 8d 35 c7 7d 01 00 	lea    0x17dc7(%rip),%r14        # 22780 <fwp_heap>
    a9b9:	41 55                	push   %r13
    a9bb:	41 54                	push   %r12
    a9bd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    a9c3:	55                   	push   %rbp
    a9c4:	53                   	push   %rbx
    a9c5:	31 db                	xor    %ebx,%ebx
    a9c7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    a9ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a9d5:	00 00 
    a9d7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    a9de:	00 
    a9df:	31 c0                	xor    %eax,%eax
    a9e1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    a9e8:	00 
    a9e9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    a9f0:	00 00 
    a9f2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    a9f7:	48 8d 05 52 cd ff ff 	lea    -0x32ae(%rip),%rax        # 7750 <fwp_drop1>
    a9fe:	66 48 0f 6e c8       	movq   %rax,%xmm1
    aa03:	48 8b 05 0e 9a 01 00 	mov    0x19a0e(%rip),%rax        # 24418 <fwp_cleanups>
    aa0a:	48 89 25 07 9a 01 00 	mov    %rsp,0x19a07(%rip)        # 24418 <fwp_cleanups>
    aa11:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    aa15:	48 89 04 24          	mov    %rax,(%rsp)
    aa19:	48 8d 05 b0 91 ff ff 	lea    -0x6e50(%rip),%rax        # 3bd0 <fwp_range_release>
    aa20:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aa25:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    aa2a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    aa2f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    aa34:	eb 47                	jmp    aa7d <f0+0xcd>
    aa36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa3d:	00 00 00 
    aa40:	80 f9 01             	cmp    $0x1,%cl
    aa43:	75 29                	jne    aa6e <f0+0xbe>
    aa45:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa48:	0f b7 c0             	movzwl %ax,%eax
    aa4b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa4e:	48 0f af c1          	imul   %rcx,%rax
    aa52:	48 c1 e8 20          	shr    $0x20,%rax
    aa56:	48 39 d0             	cmp    %rdx,%rax
    aa59:	73 13                	jae    aa6e <f0+0xbe>
    aa5b:	49 01 c5             	add    %rax,%r13
    aa5e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aa63:	0f 84 c7 27 00 00    	je     d230 <f0+0x2880>
    aa69:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    aa6e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    aa73:	49 83 ec 01          	sub    $0x1,%r12
    aa77:	0f 82 83 00 00 00    	jb     ab00 <f0+0x150>
    aa7d:	48 89 ee             	mov    %rbp,%rsi
    aa80:	bf 01 00 00 00       	mov    $0x1,%edi
    aa85:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    aa8c:	00 
    aa8d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    aa92:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    aa99:	00 
    aa9a:	e8 31 b1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    aa9f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    aaa6:	48 89 c3             	mov    %rax,%rbx
    aaa9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    aab0:	48 c1 e2 10          	shl    $0x10,%rdx
    aab4:	48 39 d0             	cmp    %rdx,%rax
    aab7:	73 b5                	jae    aa6e <f0+0xbe>
    aab9:	48 89 c2             	mov    %rax,%rdx
    aabc:	48 c1 ea 10          	shr    $0x10,%rdx
    aac0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aac4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    aacb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aacf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    aad3:	4d 85 ed             	test   %r13,%r13
    aad6:	74 96                	je     aa6e <f0+0xbe>
    aad8:	0f b6 0a             	movzbl (%rdx),%ecx
    aadb:	80 f9 02             	cmp    $0x2,%cl
    aade:	0f 85 5c ff ff ff    	jne    aa40 <f0+0x90>
    aae4:	66 85 c0             	test   %ax,%ax
    aae7:	0f 84 71 ff ff ff    	je     aa5e <f0+0xae>
    aaed:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    aaf2:	49 83 ec 01          	sub    $0x1,%r12
    aaf6:	73 85                	jae    aa7d <f0+0xcd>
    aaf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aaff:	00 
    ab00:	48 8b 04 24          	mov    (%rsp),%rax
    ab04:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    ab09:	bf 01 00 00 00       	mov    $0x1,%edi
    ab0e:	66 0f 6f 05 4a 40 00 	movdqa 0x404a(%rip),%xmm0        # eb60 <msg.8+0xe0>
    ab15:	00 
    ab16:	48 89 05 fb 98 01 00 	mov    %rax,0x198fb(%rip)        # 24418 <fwp_cleanups>
    ab1d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ab22:	e8 a9 b0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ab27:	48 8b 15 2a 90 01 00 	mov    0x1902a(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ab2e:	49 89 c5             	mov    %rax,%r13
    ab31:	48 2b 05 f8 8f 01 00 	sub    0x18ff8(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    ab38:	48 c1 e2 10          	shl    $0x10,%rdx
    ab3c:	48 39 d0             	cmp    %rdx,%rax
    ab3f:	73 59                	jae    ab9a <f0+0x1ea>
    ab41:	48 89 c2             	mov    %rax,%rdx
    ab44:	48 c1 ea 10          	shr    $0x10,%rdx
    ab48:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab4c:	48 8b 15 25 90 01 00 	mov    0x19025(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    ab53:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab57:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ab5b:	4d 85 e4             	test   %r12,%r12
    ab5e:	74 3a                	je     ab9a <f0+0x1ea>
    ab60:	0f b6 0a             	movzbl (%rdx),%ecx
    ab63:	80 f9 02             	cmp    $0x2,%cl
    ab66:	0f 84 74 27 00 00    	je     d2e0 <f0+0x2930>
    ab6c:	80 f9 01             	cmp    $0x1,%cl
    ab6f:	75 29                	jne    ab9a <f0+0x1ea>
    ab71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab74:	0f b7 c0             	movzwl %ax,%eax
    ab77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab7a:	48 0f af c1          	imul   %rcx,%rax
    ab7e:	48 c1 e8 20          	shr    $0x20,%rax
    ab82:	48 39 d0             	cmp    %rdx,%rax
    ab85:	73 13                	jae    ab9a <f0+0x1ea>
    ab87:	49 01 c4             	add    %rax,%r12
    ab8a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ab8f:	0f 84 26 29 00 00    	je     d4bb <f0+0x2b0b>
    ab95:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ab9a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    ab9f:	bf 01 00 00 00       	mov    $0x1,%edi
    aba4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    aba9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    abb0:	00 f0 3f 
    abb3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    abb8:	e8 13 b0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    abbd:	48 8b 15 94 8f 01 00 	mov    0x18f94(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    abc4:	49 89 c5             	mov    %rax,%r13
    abc7:	48 2b 05 62 8f 01 00 	sub    0x18f62(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    abce:	48 c1 e2 10          	shl    $0x10,%rdx
    abd2:	48 39 d0             	cmp    %rdx,%rax
    abd5:	73 59                	jae    ac30 <f0+0x280>
    abd7:	48 89 c2             	mov    %rax,%rdx
    abda:	48 c1 ea 10          	shr    $0x10,%rdx
    abde:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    abe2:	48 8b 15 8f 8f 01 00 	mov    0x18f8f(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    abe9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    abed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    abf1:	4d 85 e4             	test   %r12,%r12
    abf4:	74 3a                	je     ac30 <f0+0x280>
    abf6:	0f b6 0a             	movzbl (%rdx),%ecx
    abf9:	80 f9 02             	cmp    $0x2,%cl
    abfc:	0f 84 ce 26 00 00    	je     d2d0 <f0+0x2920>
    ac02:	80 f9 01             	cmp    $0x1,%cl
    ac05:	75 29                	jne    ac30 <f0+0x280>
    ac07:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac0a:	0f b7 c0             	movzwl %ax,%eax
    ac0d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac10:	48 0f af c1          	imul   %rcx,%rax
    ac14:	48 c1 e8 20          	shr    $0x20,%rax
    ac18:	48 39 d0             	cmp    %rdx,%rax
    ac1b:	73 13                	jae    ac30 <f0+0x280>
    ac1d:	49 01 c4             	add    %rax,%r12
    ac20:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ac25:	0f 84 9d 28 00 00    	je     d4c8 <f0+0x2b18>
    ac2b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ac30:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    ac35:	bf 01 00 00 00       	mov    $0x1,%edi
    ac3a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    ac3f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ac46:	33 f3 bf 
    ac49:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    ac4e:	e8 7d af ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ac53:	48 8b 15 fe 8e 01 00 	mov    0x18efe(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ac5a:	49 89 c5             	mov    %rax,%r13
    ac5d:	48 2b 05 cc 8e 01 00 	sub    0x18ecc(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    ac64:	48 c1 e2 10          	shl    $0x10,%rdx
    ac68:	48 39 d0             	cmp    %rdx,%rax
    ac6b:	73 59                	jae    acc6 <f0+0x316>
    ac6d:	48 89 c2             	mov    %rax,%rdx
    ac70:	48 c1 ea 10          	shr    $0x10,%rdx
    ac74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac78:	48 8b 15 f9 8e 01 00 	mov    0x18ef9(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    ac7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac83:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac87:	4d 85 e4             	test   %r12,%r12
    ac8a:	74 3a                	je     acc6 <f0+0x316>
    ac8c:	0f b6 0a             	movzbl (%rdx),%ecx
    ac8f:	80 f9 02             	cmp    $0x2,%cl
    ac92:	0f 84 28 26 00 00    	je     d2c0 <f0+0x2910>
    ac98:	80 f9 01             	cmp    $0x1,%cl
    ac9b:	75 29                	jne    acc6 <f0+0x316>
    ac9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aca0:	0f b7 c0             	movzwl %ax,%eax
    aca3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aca6:	48 0f af c1          	imul   %rcx,%rax
    acaa:	48 c1 e8 20          	shr    $0x20,%rax
    acae:	48 39 d0             	cmp    %rdx,%rax
    acb1:	73 13                	jae    acc6 <f0+0x316>
    acb3:	49 01 c4             	add    %rax,%r12
    acb6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    acbb:	0f 84 14 28 00 00    	je     d4d5 <f0+0x2b25>
    acc1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    acc6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    accb:	bf 01 00 00 00       	mov    $0x1,%edi
    acd0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    acd5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    acdc:	00 f0 3f 
    acdf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ace4:	e8 e7 ae ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ace9:	48 8b 15 68 8e 01 00 	mov    0x18e68(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    acf0:	49 89 c5             	mov    %rax,%r13
    acf3:	48 2b 05 36 8e 01 00 	sub    0x18e36(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    acfa:	48 c1 e2 10          	shl    $0x10,%rdx
    acfe:	48 39 d0             	cmp    %rdx,%rax
    ad01:	73 59                	jae    ad5c <f0+0x3ac>
    ad03:	48 89 c2             	mov    %rax,%rdx
    ad06:	48 c1 ea 10          	shr    $0x10,%rdx
    ad0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad0e:	48 8b 15 63 8e 01 00 	mov    0x18e63(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    ad15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad19:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad1d:	4d 85 e4             	test   %r12,%r12
    ad20:	74 3a                	je     ad5c <f0+0x3ac>
    ad22:	0f b6 0a             	movzbl (%rdx),%ecx
    ad25:	80 f9 02             	cmp    $0x2,%cl
    ad28:	0f 84 f2 25 00 00    	je     d320 <f0+0x2970>
    ad2e:	80 f9 01             	cmp    $0x1,%cl
    ad31:	75 29                	jne    ad5c <f0+0x3ac>
    ad33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad36:	0f b7 c0             	movzwl %ax,%eax
    ad39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad3c:	48 0f af c1          	imul   %rcx,%rax
    ad40:	48 c1 e8 20          	shr    $0x20,%rax
    ad44:	48 39 d0             	cmp    %rdx,%rax
    ad47:	73 13                	jae    ad5c <f0+0x3ac>
    ad49:	49 01 c4             	add    %rax,%r12
    ad4c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad51:	0f 84 8b 27 00 00    	je     d4e2 <f0+0x2b32>
    ad57:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad5c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ad63:	33 f3 bf 
    ad66:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ad6d:	00 
    ad6e:	bf 01 00 00 00       	mov    $0x1,%edi
    ad73:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    ad7a:	00 
    ad7b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ad82:	00 
    ad83:	e8 48 ae ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ad88:	48 8b 15 c9 8d 01 00 	mov    0x18dc9(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ad8f:	49 89 c5             	mov    %rax,%r13
    ad92:	48 2b 05 97 8d 01 00 	sub    0x18d97(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    ad99:	48 c1 e2 10          	shl    $0x10,%rdx
    ad9d:	48 39 d0             	cmp    %rdx,%rax
    ada0:	73 59                	jae    adfb <f0+0x44b>
    ada2:	48 89 c2             	mov    %rax,%rdx
    ada5:	48 c1 ea 10          	shr    $0x10,%rdx
    ada9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adad:	48 8b 15 c4 8d 01 00 	mov    0x18dc4(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    adb4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adb8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    adbc:	4d 85 e4             	test   %r12,%r12
    adbf:	74 3a                	je     adfb <f0+0x44b>
    adc1:	0f b6 0a             	movzbl (%rdx),%ecx
    adc4:	80 f9 02             	cmp    $0x2,%cl
    adc7:	0f 84 43 25 00 00    	je     d310 <f0+0x2960>
    adcd:	80 f9 01             	cmp    $0x1,%cl
    add0:	75 29                	jne    adfb <f0+0x44b>
    add2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    add5:	0f b7 c0             	movzwl %ax,%eax
    add8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    addb:	48 0f af c1          	imul   %rcx,%rax
    addf:	48 c1 e8 20          	shr    $0x20,%rax
    ade3:	48 39 d0             	cmp    %rdx,%rax
    ade6:	73 13                	jae    adfb <f0+0x44b>
    ade8:	49 01 c4             	add    %rax,%r12
    adeb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    adf0:	0f 84 f9 26 00 00    	je     d4ef <f0+0x2b3f>
    adf6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    adfb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    ae02:	00 f0 3f 
    ae05:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    ae0c:	00 
    ae0d:	bf 01 00 00 00       	mov    $0x1,%edi
    ae12:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    ae19:	00 
    ae1a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    ae21:	00 
    ae22:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    ae29:	33 f3 bf 
    ae2c:	e8 9f ad ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ae31:	48 89 c7             	mov    %rax,%rdi
    ae34:	e8 e7 b4 ff ff       	call   6320 <fwp_rc_fresh>
    ae39:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    ae40:	00 
    ae41:	bf 01 00 00 00       	mov    $0x1,%edi
    ae46:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    ae4d:	00 
    ae4e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    ae55:	00 
    ae56:	e8 75 ad ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ae5b:	48 89 c7             	mov    %rax,%rdi
    ae5e:	e8 bd b4 ff ff       	call   6320 <fwp_rc_fresh>
    ae63:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    ae6a:	00 
    ae6b:	bf 01 00 00 00       	mov    $0x1,%edi
    ae70:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    ae77:	00 
    ae78:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    ae7f:	00 
    ae80:	e8 4b ad ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ae85:	48 89 c7             	mov    %rax,%rdi
    ae88:	e8 93 b4 ff ff       	call   6320 <fwp_rc_fresh>
    ae8d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    ae94:	00 
    ae95:	bf 01 00 00 00       	mov    $0x1,%edi
    ae9a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    aea1:	00 
    aea2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    aea9:	00 
    aeaa:	e8 21 ad ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    aeaf:	48 89 c7             	mov    %rax,%rdi
    aeb2:	e8 69 b4 ff ff       	call   6320 <fwp_rc_fresh>
    aeb7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    aebe:	00 
    aebf:	bf 01 00 00 00       	mov    $0x1,%edi
    aec4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    aecb:	00 
    aecc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    aed3:	00 
    aed4:	e8 f7 ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    aed9:	48 89 c7             	mov    %rax,%rdi
    aedc:	e8 3f b4 ff ff       	call   6320 <fwp_rc_fresh>
    aee1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    aee8:	00 
    aee9:	bf 01 00 00 00       	mov    $0x1,%edi
    aeee:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    aef5:	00 
    aef6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    aefd:	00 
    aefe:	e8 cd ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    af03:	48 89 c7             	mov    %rax,%rdi
    af06:	e8 15 b4 ff ff       	call   6320 <fwp_rc_fresh>
    af0b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    af12:	00 
    af13:	bf 01 00 00 00       	mov    $0x1,%edi
    af18:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    af1f:	00 
    af20:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    af27:	00 
    af28:	e8 a3 ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    af2d:	48 89 c7             	mov    %rax,%rdi
    af30:	e8 eb b3 ff ff       	call   6320 <fwp_rc_fresh>
    af35:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    af3c:	00 
    af3d:	bf 01 00 00 00       	mov    $0x1,%edi
    af42:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    af49:	00 
    af4a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    af51:	00 
    af52:	e8 79 ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    af57:	48 89 c7             	mov    %rax,%rdi
    af5a:	e8 c1 b3 ff ff       	call   6320 <fwp_rc_fresh>
    af5f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    af66:	00 
    af67:	bf 01 00 00 00       	mov    $0x1,%edi
    af6c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    af73:	00 
    af74:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    af7b:	00 
    af7c:	e8 4f ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    af81:	48 89 c7             	mov    %rax,%rdi
    af84:	e8 97 b3 ff ff       	call   6320 <fwp_rc_fresh>
    af89:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    af90:	00 
    af91:	bf 01 00 00 00       	mov    $0x1,%edi
    af96:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    af9d:	00 
    af9e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    afa5:	00 
    afa6:	e8 25 ac ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    afab:	48 89 c7             	mov    %rax,%rdi
    afae:	e8 6d b3 ff ff       	call   6320 <fwp_rc_fresh>
    afb3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    afba:	00 
    afbb:	bf 01 00 00 00       	mov    $0x1,%edi
    afc0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    afc7:	00 
    afc8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    afcf:	00 
    afd0:	e8 fb ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    afd5:	48 89 c7             	mov    %rax,%rdi
    afd8:	e8 43 b3 ff ff       	call   6320 <fwp_rc_fresh>
    afdd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    afe4:	00 
    afe5:	bf 01 00 00 00       	mov    $0x1,%edi
    afea:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    aff1:	00 
    aff2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    aff9:	00 
    affa:	e8 d1 ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    afff:	48 89 c7             	mov    %rax,%rdi
    b002:	e8 19 b3 ff ff       	call   6320 <fwp_rc_fresh>
    b007:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b00e:	00 
    b00f:	bf 01 00 00 00       	mov    $0x1,%edi
    b014:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b01b:	00 
    b01c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b023:	00 
    b024:	e8 a7 ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b029:	48 89 c7             	mov    %rax,%rdi
    b02c:	e8 ef b2 ff ff       	call   6320 <fwp_rc_fresh>
    b031:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b038:	00 
    b039:	bf 01 00 00 00       	mov    $0x1,%edi
    b03e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b045:	00 
    b046:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b04d:	00 
    b04e:	e8 7d ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b053:	48 89 c7             	mov    %rax,%rdi
    b056:	e8 c5 b2 ff ff       	call   6320 <fwp_rc_fresh>
    b05b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b062:	00 
    b063:	bf 01 00 00 00       	mov    $0x1,%edi
    b068:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b06f:	00 
    b070:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b077:	00 
    b078:	e8 53 ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b07d:	48 89 c7             	mov    %rax,%rdi
    b080:	e8 9b b2 ff ff       	call   6320 <fwp_rc_fresh>
    b085:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b08c:	00 
    b08d:	bf 01 00 00 00       	mov    $0x1,%edi
    b092:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b099:	00 
    b09a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b0a1:	00 
    b0a2:	e8 29 ab ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b0a7:	48 89 c7             	mov    %rax,%rdi
    b0aa:	e8 71 b2 ff ff       	call   6320 <fwp_rc_fresh>
    b0af:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b0b6:	00 
    b0b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b0bc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b0c3:	00 
    b0c4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b0cb:	00 
    b0cc:	e8 ff aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b0d1:	48 89 c7             	mov    %rax,%rdi
    b0d4:	e8 47 b2 ff ff       	call   6320 <fwp_rc_fresh>
    b0d9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b0e0:	00 
    b0e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b0e6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b0ed:	00 
    b0ee:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b0f5:	00 
    b0f6:	e8 d5 aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b0fb:	48 89 c7             	mov    %rax,%rdi
    b0fe:	e8 1d b2 ff ff       	call   6320 <fwp_rc_fresh>
    b103:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b10a:	00 
    b10b:	bf 01 00 00 00       	mov    $0x1,%edi
    b110:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b117:	00 
    b118:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b11f:	00 
    b120:	e8 ab aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b125:	48 89 c7             	mov    %rax,%rdi
    b128:	e8 f3 b1 ff ff       	call   6320 <fwp_rc_fresh>
    b12d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b134:	00 
    b135:	bf 01 00 00 00       	mov    $0x1,%edi
    b13a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b141:	00 
    b142:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b149:	00 
    b14a:	e8 81 aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b14f:	48 89 c7             	mov    %rax,%rdi
    b152:	e8 c9 b1 ff ff       	call   6320 <fwp_rc_fresh>
    b157:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b15e:	00 
    b15f:	bf 01 00 00 00       	mov    $0x1,%edi
    b164:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b16b:	00 
    b16c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b173:	00 
    b174:	e8 57 aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b179:	48 89 c7             	mov    %rax,%rdi
    b17c:	e8 9f b1 ff ff       	call   6320 <fwp_rc_fresh>
    b181:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b188:	00 
    b189:	bf 01 00 00 00       	mov    $0x1,%edi
    b18e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b195:	00 
    b196:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b19d:	00 
    b19e:	e8 2d aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b1a3:	48 89 c7             	mov    %rax,%rdi
    b1a6:	e8 75 b1 ff ff       	call   6320 <fwp_rc_fresh>
    b1ab:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b1b2:	00 
    b1b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b1b8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b1bf:	00 
    b1c0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b1c7:	00 
    b1c8:	e8 03 aa ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b1cd:	48 89 c7             	mov    %rax,%rdi
    b1d0:	e8 4b b1 ff ff       	call   6320 <fwp_rc_fresh>
    b1d5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b1dc:	00 
    b1dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b1e2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b1e9:	00 
    b1ea:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b1f1:	00 
    b1f2:	e8 d9 a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b1f7:	48 89 c7             	mov    %rax,%rdi
    b1fa:	e8 21 b1 ff ff       	call   6320 <fwp_rc_fresh>
    b1ff:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b206:	00 
    b207:	bf 01 00 00 00       	mov    $0x1,%edi
    b20c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b213:	00 
    b214:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b21b:	00 
    b21c:	e8 af a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b221:	48 89 c7             	mov    %rax,%rdi
    b224:	e8 f7 b0 ff ff       	call   6320 <fwp_rc_fresh>
    b229:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b230:	00 
    b231:	bf 01 00 00 00       	mov    $0x1,%edi
    b236:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b23d:	00 
    b23e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b245:	00 
    b246:	e8 85 a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b24b:	48 89 c7             	mov    %rax,%rdi
    b24e:	e8 cd b0 ff ff       	call   6320 <fwp_rc_fresh>
    b253:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b25a:	00 
    b25b:	bf 01 00 00 00       	mov    $0x1,%edi
    b260:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b267:	00 
    b268:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b26f:	00 
    b270:	e8 5b a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b275:	48 89 c7             	mov    %rax,%rdi
    b278:	e8 a3 b0 ff ff       	call   6320 <fwp_rc_fresh>
    b27d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b284:	00 
    b285:	bf 01 00 00 00       	mov    $0x1,%edi
    b28a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b291:	00 
    b292:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b299:	00 
    b29a:	e8 31 a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b29f:	48 89 c7             	mov    %rax,%rdi
    b2a2:	e8 79 b0 ff ff       	call   6320 <fwp_rc_fresh>
    b2a7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b2ae:	00 
    b2af:	bf 01 00 00 00       	mov    $0x1,%edi
    b2b4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b2bb:	00 
    b2bc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b2c3:	00 
    b2c4:	e8 07 a9 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b2c9:	48 89 c7             	mov    %rax,%rdi
    b2cc:	e8 4f b0 ff ff       	call   6320 <fwp_rc_fresh>
    b2d1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b2d8:	00 
    b2d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b2de:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b2e5:	00 
    b2e6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b2ed:	00 
    b2ee:	e8 dd a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b2f3:	48 89 c7             	mov    %rax,%rdi
    b2f6:	e8 25 b0 ff ff       	call   6320 <fwp_rc_fresh>
    b2fb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b302:	00 
    b303:	bf 01 00 00 00       	mov    $0x1,%edi
    b308:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b30f:	00 
    b310:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b317:	00 
    b318:	e8 b3 a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b31d:	48 89 c7             	mov    %rax,%rdi
    b320:	e8 fb af ff ff       	call   6320 <fwp_rc_fresh>
    b325:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b32c:	00 
    b32d:	bf 01 00 00 00       	mov    $0x1,%edi
    b332:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b339:	00 
    b33a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b341:	00 
    b342:	e8 89 a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b347:	48 89 c7             	mov    %rax,%rdi
    b34a:	e8 d1 af ff ff       	call   6320 <fwp_rc_fresh>
    b34f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b356:	00 
    b357:	bf 01 00 00 00       	mov    $0x1,%edi
    b35c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b363:	00 
    b364:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b36b:	00 
    b36c:	e8 5f a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b371:	48 89 c7             	mov    %rax,%rdi
    b374:	e8 a7 af ff ff       	call   6320 <fwp_rc_fresh>
    b379:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b380:	00 
    b381:	bf 01 00 00 00       	mov    $0x1,%edi
    b386:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b38d:	00 
    b38e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b395:	00 
    b396:	e8 35 a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b39b:	48 89 c7             	mov    %rax,%rdi
    b39e:	e8 7d af ff ff       	call   6320 <fwp_rc_fresh>
    b3a3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b3aa:	00 
    b3ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b3b0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b3b7:	00 
    b3b8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b3bf:	00 
    b3c0:	e8 0b a8 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b3c5:	48 89 c7             	mov    %rax,%rdi
    b3c8:	e8 53 af ff ff       	call   6320 <fwp_rc_fresh>
    b3cd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b3d4:	00 
    b3d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b3da:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b3e1:	00 
    b3e2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b3e9:	00 
    b3ea:	e8 e1 a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b3ef:	48 89 c7             	mov    %rax,%rdi
    b3f2:	e8 29 af ff ff       	call   6320 <fwp_rc_fresh>
    b3f7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b3fe:	00 
    b3ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b404:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b40b:	00 
    b40c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b413:	00 
    b414:	e8 b7 a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b419:	48 89 c7             	mov    %rax,%rdi
    b41c:	e8 ff ae ff ff       	call   6320 <fwp_rc_fresh>
    b421:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b428:	00 
    b429:	bf 01 00 00 00       	mov    $0x1,%edi
    b42e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b435:	00 
    b436:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b43d:	00 
    b43e:	e8 8d a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b443:	48 89 c7             	mov    %rax,%rdi
    b446:	e8 d5 ae ff ff       	call   6320 <fwp_rc_fresh>
    b44b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b452:	00 
    b453:	bf 01 00 00 00       	mov    $0x1,%edi
    b458:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b45f:	00 
    b460:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b467:	00 
    b468:	e8 63 a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b46d:	48 89 c7             	mov    %rax,%rdi
    b470:	e8 ab ae ff ff       	call   6320 <fwp_rc_fresh>
    b475:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b47c:	00 
    b47d:	bf 01 00 00 00       	mov    $0x1,%edi
    b482:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b489:	00 
    b48a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b491:	00 
    b492:	e8 39 a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b497:	48 89 c7             	mov    %rax,%rdi
    b49a:	e8 81 ae ff ff       	call   6320 <fwp_rc_fresh>
    b49f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b4a6:	00 
    b4a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b4ac:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b4b3:	00 
    b4b4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b4bb:	00 
    b4bc:	e8 0f a7 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b4c1:	48 89 c7             	mov    %rax,%rdi
    b4c4:	e8 57 ae ff ff       	call   6320 <fwp_rc_fresh>
    b4c9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b4d0:	00 
    b4d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b4dd:	00 
    b4de:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b4e5:	00 
    b4e6:	e8 e5 a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b4eb:	48 89 c7             	mov    %rax,%rdi
    b4ee:	e8 2d ae ff ff       	call   6320 <fwp_rc_fresh>
    b4f3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b4fa:	00 
    b4fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b500:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b507:	00 
    b508:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b50f:	00 
    b510:	e8 bb a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b515:	48 89 c7             	mov    %rax,%rdi
    b518:	e8 03 ae ff ff       	call   6320 <fwp_rc_fresh>
    b51d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b524:	00 
    b525:	bf 01 00 00 00       	mov    $0x1,%edi
    b52a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b531:	00 
    b532:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b539:	00 
    b53a:	e8 91 a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b53f:	48 89 c7             	mov    %rax,%rdi
    b542:	e8 d9 ad ff ff       	call   6320 <fwp_rc_fresh>
    b547:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b54e:	00 
    b54f:	bf 01 00 00 00       	mov    $0x1,%edi
    b554:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b55b:	00 
    b55c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b563:	00 
    b564:	e8 67 a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b569:	48 89 c7             	mov    %rax,%rdi
    b56c:	e8 af ad ff ff       	call   6320 <fwp_rc_fresh>
    b571:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b578:	00 
    b579:	bf 01 00 00 00       	mov    $0x1,%edi
    b57e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b585:	00 
    b586:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b58d:	00 
    b58e:	e8 3d a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b593:	48 89 c7             	mov    %rax,%rdi
    b596:	e8 85 ad ff ff       	call   6320 <fwp_rc_fresh>
    b59b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b5a2:	00 
    b5a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b5af:	00 
    b5b0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b5b7:	00 
    b5b8:	e8 13 a6 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b5bd:	48 89 c7             	mov    %rax,%rdi
    b5c0:	e8 5b ad ff ff       	call   6320 <fwp_rc_fresh>
    b5c5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b5cc:	00 
    b5cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b5d2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b5d9:	00 
    b5da:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b5e1:	00 
    b5e2:	e8 e9 a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b5e7:	48 89 c7             	mov    %rax,%rdi
    b5ea:	e8 31 ad ff ff       	call   6320 <fwp_rc_fresh>
    b5ef:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b5f6:	00 
    b5f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b5fc:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b603:	00 
    b604:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b60b:	00 
    b60c:	e8 bf a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b611:	48 89 c7             	mov    %rax,%rdi
    b614:	e8 07 ad ff ff       	call   6320 <fwp_rc_fresh>
    b619:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b620:	00 
    b621:	bf 01 00 00 00       	mov    $0x1,%edi
    b626:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b62d:	00 
    b62e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b635:	00 
    b636:	e8 95 a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b63b:	48 89 c7             	mov    %rax,%rdi
    b63e:	e8 dd ac ff ff       	call   6320 <fwp_rc_fresh>
    b643:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b64a:	00 
    b64b:	bf 01 00 00 00       	mov    $0x1,%edi
    b650:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b657:	00 
    b658:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b65f:	00 
    b660:	e8 6b a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b665:	48 89 c7             	mov    %rax,%rdi
    b668:	e8 b3 ac ff ff       	call   6320 <fwp_rc_fresh>
    b66d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b674:	00 
    b675:	bf 01 00 00 00       	mov    $0x1,%edi
    b67a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b681:	00 
    b682:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b689:	00 
    b68a:	e8 41 a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b68f:	48 89 c7             	mov    %rax,%rdi
    b692:	e8 89 ac ff ff       	call   6320 <fwp_rc_fresh>
    b697:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b69e:	00 
    b69f:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b6ab:	00 
    b6ac:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b6b3:	00 
    b6b4:	e8 17 a5 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b6b9:	48 89 c7             	mov    %rax,%rdi
    b6bc:	e8 5f ac ff ff       	call   6320 <fwp_rc_fresh>
    b6c1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b6c8:	00 
    b6c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ce:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b6d5:	00 
    b6d6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b6dd:	00 
    b6de:	e8 ed a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b6e3:	48 89 c7             	mov    %rax,%rdi
    b6e6:	e8 35 ac ff ff       	call   6320 <fwp_rc_fresh>
    b6eb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b6f2:	00 
    b6f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b6ff:	00 
    b700:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b707:	00 
    b708:	e8 c3 a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b70d:	48 89 c7             	mov    %rax,%rdi
    b710:	e8 0b ac ff ff       	call   6320 <fwp_rc_fresh>
    b715:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b71c:	00 
    b71d:	bf 01 00 00 00       	mov    $0x1,%edi
    b722:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b729:	00 
    b72a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b731:	00 
    b732:	e8 99 a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b737:	48 89 c7             	mov    %rax,%rdi
    b73a:	e8 e1 ab ff ff       	call   6320 <fwp_rc_fresh>
    b73f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b746:	00 
    b747:	bf 01 00 00 00       	mov    $0x1,%edi
    b74c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b753:	00 
    b754:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b75b:	00 
    b75c:	e8 6f a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b761:	48 89 c7             	mov    %rax,%rdi
    b764:	e8 b7 ab ff ff       	call   6320 <fwp_rc_fresh>
    b769:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b770:	00 
    b771:	bf 01 00 00 00       	mov    $0x1,%edi
    b776:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b77d:	00 
    b77e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b785:	00 
    b786:	e8 45 a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b78b:	48 89 c7             	mov    %rax,%rdi
    b78e:	e8 8d ab ff ff       	call   6320 <fwp_rc_fresh>
    b793:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b79a:	00 
    b79b:	bf 01 00 00 00       	mov    $0x1,%edi
    b7a0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b7a7:	00 
    b7a8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b7af:	00 
    b7b0:	e8 1b a4 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b7b5:	48 89 c7             	mov    %rax,%rdi
    b7b8:	e8 63 ab ff ff       	call   6320 <fwp_rc_fresh>
    b7bd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b7c4:	00 
    b7c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ca:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b7d1:	00 
    b7d2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b7d9:	00 
    b7da:	e8 f1 a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b7df:	48 89 c7             	mov    %rax,%rdi
    b7e2:	e8 39 ab ff ff       	call   6320 <fwp_rc_fresh>
    b7e7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b7ee:	00 
    b7ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b7fb:	00 
    b7fc:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b803:	00 
    b804:	e8 c7 a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b809:	48 89 c7             	mov    %rax,%rdi
    b80c:	e8 0f ab ff ff       	call   6320 <fwp_rc_fresh>
    b811:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b818:	00 
    b819:	bf 01 00 00 00       	mov    $0x1,%edi
    b81e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b825:	00 
    b826:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b82d:	00 
    b82e:	e8 9d a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b833:	48 89 c7             	mov    %rax,%rdi
    b836:	e8 e5 aa ff ff       	call   6320 <fwp_rc_fresh>
    b83b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    b842:	00 
    b843:	bf 01 00 00 00       	mov    $0x1,%edi
    b848:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    b84f:	00 
    b850:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    b857:	00 
    b858:	e8 73 a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b85d:	48 89 c7             	mov    %rax,%rdi
    b860:	e8 bb aa ff ff       	call   6320 <fwp_rc_fresh>
    b865:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    b86c:	00 
    b86d:	bf 01 00 00 00       	mov    $0x1,%edi
    b872:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    b879:	00 
    b87a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    b881:	00 
    b882:	e8 49 a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b887:	48 89 c7             	mov    %rax,%rdi
    b88a:	e8 91 aa ff ff       	call   6320 <fwp_rc_fresh>
    b88f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    b896:	00 
    b897:	bf 01 00 00 00       	mov    $0x1,%edi
    b89c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    b8a3:	00 
    b8a4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    b8ab:	00 
    b8ac:	e8 1f a3 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b8b1:	48 89 c7             	mov    %rax,%rdi
    b8b4:	e8 67 aa ff ff       	call   6320 <fwp_rc_fresh>
    b8b9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    b8c0:	00 
    b8c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    b8cd:	00 
    b8ce:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    b8d5:	00 
    b8d6:	e8 f5 a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b8db:	48 89 c7             	mov    %rax,%rdi
    b8de:	e8 3d aa ff ff       	call   6320 <fwp_rc_fresh>
    b8e3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    b8ea:	00 
    b8eb:	bf 01 00 00 00       	mov    $0x1,%edi
    b8f0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    b8f7:	00 
    b8f8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    b8ff:	00 
    b900:	e8 cb a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b905:	48 89 c7             	mov    %rax,%rdi
    b908:	e8 13 aa ff ff       	call   6320 <fwp_rc_fresh>
    b90d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    b914:	00 
    b915:	bf 01 00 00 00       	mov    $0x1,%edi
    b91a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    b921:	00 
    b922:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    b929:	00 
    b92a:	e8 a1 a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b92f:	48 89 c7             	mov    %rax,%rdi
    b932:	e8 e9 a9 ff ff       	call   6320 <fwp_rc_fresh>
    b937:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    b93e:	00 
    b93f:	bf 01 00 00 00       	mov    $0x1,%edi
    b944:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    b94b:	00 
    b94c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    b953:	00 
    b954:	e8 77 a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b959:	48 89 c7             	mov    %rax,%rdi
    b95c:	e8 bf a9 ff ff       	call   6320 <fwp_rc_fresh>
    b961:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    b968:	00 
    b969:	bf 01 00 00 00       	mov    $0x1,%edi
    b96e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    b975:	00 
    b976:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    b97d:	00 
    b97e:	e8 4d a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b983:	48 89 c7             	mov    %rax,%rdi
    b986:	e8 95 a9 ff ff       	call   6320 <fwp_rc_fresh>
    b98b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    b992:	00 
    b993:	bf 01 00 00 00       	mov    $0x1,%edi
    b998:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    b99f:	00 
    b9a0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    b9a7:	00 
    b9a8:	e8 23 a2 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b9ad:	48 89 c7             	mov    %rax,%rdi
    b9b0:	e8 6b a9 ff ff       	call   6320 <fwp_rc_fresh>
    b9b5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    b9bc:	00 
    b9bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    b9c9:	00 
    b9ca:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    b9d1:	00 
    b9d2:	e8 f9 a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    b9d7:	48 89 c7             	mov    %rax,%rdi
    b9da:	e8 41 a9 ff ff       	call   6320 <fwp_rc_fresh>
    b9df:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    b9e6:	00 
    b9e7:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ec:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    b9f3:	00 
    b9f4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    b9fb:	00 
    b9fc:	e8 cf a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ba01:	48 89 c7             	mov    %rax,%rdi
    ba04:	e8 17 a9 ff ff       	call   6320 <fwp_rc_fresh>
    ba09:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    ba10:	00 
    ba11:	bf 01 00 00 00       	mov    $0x1,%edi
    ba16:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    ba1d:	00 
    ba1e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    ba25:	00 
    ba26:	e8 a5 a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ba2b:	48 89 c7             	mov    %rax,%rdi
    ba2e:	e8 ed a8 ff ff       	call   6320 <fwp_rc_fresh>
    ba33:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    ba3a:	00 
    ba3b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba40:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    ba47:	00 
    ba48:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    ba4f:	00 
    ba50:	e8 7b a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ba55:	48 89 c7             	mov    %rax,%rdi
    ba58:	e8 c3 a8 ff ff       	call   6320 <fwp_rc_fresh>
    ba5d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    ba64:	00 
    ba65:	bf 01 00 00 00       	mov    $0x1,%edi
    ba6a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    ba71:	00 
    ba72:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    ba79:	00 
    ba7a:	e8 51 a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ba7f:	48 89 c7             	mov    %rax,%rdi
    ba82:	e8 99 a8 ff ff       	call   6320 <fwp_rc_fresh>
    ba87:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    ba8e:	00 
    ba8f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba94:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    ba9b:	00 
    ba9c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    baa3:	00 
    baa4:	e8 27 a1 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    baa9:	48 89 c7             	mov    %rax,%rdi
    baac:	e8 6f a8 ff ff       	call   6320 <fwp_rc_fresh>
    bab1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bab8:	00 
    bab9:	bf 01 00 00 00       	mov    $0x1,%edi
    babe:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bac5:	00 
    bac6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bacd:	00 
    bace:	e8 fd a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bad3:	48 89 c7             	mov    %rax,%rdi
    bad6:	e8 45 a8 ff ff       	call   6320 <fwp_rc_fresh>
    badb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bae2:	00 
    bae3:	bf 01 00 00 00       	mov    $0x1,%edi
    bae8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    baef:	00 
    baf0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    baf7:	00 
    baf8:	e8 d3 a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bafd:	48 89 c7             	mov    %rax,%rdi
    bb00:	e8 1b a8 ff ff       	call   6320 <fwp_rc_fresh>
    bb05:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bb0c:	00 
    bb0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb12:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bb19:	00 
    bb1a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bb21:	00 
    bb22:	e8 a9 a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bb27:	48 89 c7             	mov    %rax,%rdi
    bb2a:	e8 f1 a7 ff ff       	call   6320 <fwp_rc_fresh>
    bb2f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bb36:	00 
    bb37:	bf 01 00 00 00       	mov    $0x1,%edi
    bb3c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bb43:	00 
    bb44:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bb4b:	00 
    bb4c:	e8 7f a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bb51:	48 89 c7             	mov    %rax,%rdi
    bb54:	e8 c7 a7 ff ff       	call   6320 <fwp_rc_fresh>
    bb59:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bb60:	00 
    bb61:	bf 01 00 00 00       	mov    $0x1,%edi
    bb66:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bb6d:	00 
    bb6e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bb75:	00 
    bb76:	e8 55 a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bb7b:	48 89 c7             	mov    %rax,%rdi
    bb7e:	e8 9d a7 ff ff       	call   6320 <fwp_rc_fresh>
    bb83:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bb8a:	00 
    bb8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb90:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bb97:	00 
    bb98:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bb9f:	00 
    bba0:	e8 2b a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bba5:	48 89 c7             	mov    %rax,%rdi
    bba8:	e8 73 a7 ff ff       	call   6320 <fwp_rc_fresh>
    bbad:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bbb4:	00 
    bbb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbba:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bbc1:	00 
    bbc2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bbc9:	00 
    bbca:	e8 01 a0 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bbcf:	48 89 c7             	mov    %rax,%rdi
    bbd2:	e8 49 a7 ff ff       	call   6320 <fwp_rc_fresh>
    bbd7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bbde:	00 
    bbdf:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bbeb:	00 
    bbec:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bbf3:	00 
    bbf4:	e8 d7 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bbf9:	48 89 c7             	mov    %rax,%rdi
    bbfc:	e8 1f a7 ff ff       	call   6320 <fwp_rc_fresh>
    bc01:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bc08:	00 
    bc09:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bc15:	00 
    bc16:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bc1d:	00 
    bc1e:	e8 ad 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bc23:	48 89 c7             	mov    %rax,%rdi
    bc26:	e8 f5 a6 ff ff       	call   6320 <fwp_rc_fresh>
    bc2b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bc32:	00 
    bc33:	bf 01 00 00 00       	mov    $0x1,%edi
    bc38:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bc3f:	00 
    bc40:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bc47:	00 
    bc48:	e8 83 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bc4d:	48 89 c7             	mov    %rax,%rdi
    bc50:	e8 cb a6 ff ff       	call   6320 <fwp_rc_fresh>
    bc55:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bc5c:	00 
    bc5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc62:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    bc69:	00 
    bc6a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    bc71:	00 
    bc72:	e8 59 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bc77:	48 89 c7             	mov    %rax,%rdi
    bc7a:	e8 a1 a6 ff ff       	call   6320 <fwp_rc_fresh>
    bc7f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bc86:	00 
    bc87:	bf 01 00 00 00       	mov    $0x1,%edi
    bc8c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    bc93:	00 
    bc94:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bc9b:	00 
    bc9c:	e8 2f 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bca1:	48 89 c7             	mov    %rax,%rdi
    bca4:	e8 77 a6 ff ff       	call   6320 <fwp_rc_fresh>
    bca9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    bcb0:	00 
    bcb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    bcbd:	00 
    bcbe:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    bcc5:	00 
    bcc6:	e8 05 9f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bccb:	48 89 c7             	mov    %rax,%rdi
    bcce:	e8 4d a6 ff ff       	call   6320 <fwp_rc_fresh>
    bcd3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    bcda:	00 
    bcdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bce0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    bce7:	00 
    bce8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    bcef:	00 
    bcf0:	e8 db 9e ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bcf5:	48 8b 15 5c 7e 01 00 	mov    0x17e5c(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    bcfc:	49 89 c5             	mov    %rax,%r13
    bcff:	48 2b 05 2a 7e 01 00 	sub    0x17e2a(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    bd06:	48 c1 e2 10          	shl    $0x10,%rdx
    bd0a:	48 39 d0             	cmp    %rdx,%rax
    bd0d:	73 59                	jae    bd68 <f0+0x13b8>
    bd0f:	48 89 c2             	mov    %rax,%rdx
    bd12:	48 c1 ea 10          	shr    $0x10,%rdx
    bd16:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd1a:	48 8b 15 57 7e 01 00 	mov    0x17e57(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    bd21:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd25:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd29:	4d 85 e4             	test   %r12,%r12
    bd2c:	74 3a                	je     bd68 <f0+0x13b8>
    bd2e:	0f b6 0a             	movzbl (%rdx),%ecx
    bd31:	80 f9 02             	cmp    $0x2,%cl
    bd34:	0f 84 c6 15 00 00    	je     d300 <f0+0x2950>
    bd3a:	80 f9 01             	cmp    $0x1,%cl
    bd3d:	75 29                	jne    bd68 <f0+0x13b8>
    bd3f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd42:	0f b7 c0             	movzwl %ax,%eax
    bd45:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd48:	48 0f af c1          	imul   %rcx,%rax
    bd4c:	48 c1 e8 20          	shr    $0x20,%rax
    bd50:	48 39 d0             	cmp    %rdx,%rax
    bd53:	73 13                	jae    bd68 <f0+0x13b8>
    bd55:	49 01 c4             	add    %rax,%r12
    bd58:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bd5d:	0f 84 99 17 00 00    	je     d4fc <f0+0x2b4c>
    bd63:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bd68:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bd6f:	33 f3 bf 
    bd72:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bd79:	00 
    bd7a:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bd86:	00 
    bd87:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bd8e:	00 
    bd8f:	e8 3c 9e ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bd94:	48 8b 15 bd 7d 01 00 	mov    0x17dbd(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    bd9b:	49 89 c5             	mov    %rax,%r13
    bd9e:	48 2b 05 8b 7d 01 00 	sub    0x17d8b(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    bda5:	48 c1 e2 10          	shl    $0x10,%rdx
    bda9:	48 39 d0             	cmp    %rdx,%rax
    bdac:	73 59                	jae    be07 <f0+0x1457>
    bdae:	48 89 c2             	mov    %rax,%rdx
    bdb1:	48 c1 ea 10          	shr    $0x10,%rdx
    bdb5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdb9:	48 8b 15 b8 7d 01 00 	mov    0x17db8(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    bdc0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bdc4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bdc8:	4d 85 e4             	test   %r12,%r12
    bdcb:	74 3a                	je     be07 <f0+0x1457>
    bdcd:	0f b6 0a             	movzbl (%rdx),%ecx
    bdd0:	80 f9 02             	cmp    $0x2,%cl
    bdd3:	0f 84 17 15 00 00    	je     d2f0 <f0+0x2940>
    bdd9:	80 f9 01             	cmp    $0x1,%cl
    bddc:	75 29                	jne    be07 <f0+0x1457>
    bdde:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bde1:	0f b7 c0             	movzwl %ax,%eax
    bde4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bde7:	48 0f af c1          	imul   %rcx,%rax
    bdeb:	48 c1 e8 20          	shr    $0x20,%rax
    bdef:	48 39 d0             	cmp    %rdx,%rax
    bdf2:	73 13                	jae    be07 <f0+0x1457>
    bdf4:	49 01 c4             	add    %rax,%r12
    bdf7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bdfc:	0f 84 07 17 00 00    	je     d509 <f0+0x2b59>
    be02:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be07:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    be0e:	00 f0 3f 
    be11:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    be18:	00 
    be19:	bf 01 00 00 00       	mov    $0x1,%edi
    be1e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    be25:	00 
    be26:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    be2d:	00 
    be2e:	e8 9d 9d ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    be33:	48 8b 15 1e 7d 01 00 	mov    0x17d1e(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    be3a:	49 89 c5             	mov    %rax,%r13
    be3d:	48 2b 05 ec 7c 01 00 	sub    0x17cec(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    be44:	48 c1 e2 10          	shl    $0x10,%rdx
    be48:	48 39 d0             	cmp    %rdx,%rax
    be4b:	73 59                	jae    bea6 <f0+0x14f6>
    be4d:	48 89 c2             	mov    %rax,%rdx
    be50:	48 c1 ea 10          	shr    $0x10,%rdx
    be54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be58:	48 8b 15 19 7d 01 00 	mov    0x17d19(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    be5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be63:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be67:	4d 85 e4             	test   %r12,%r12
    be6a:	74 3a                	je     bea6 <f0+0x14f6>
    be6c:	0f b6 0a             	movzbl (%rdx),%ecx
    be6f:	80 f9 02             	cmp    $0x2,%cl
    be72:	0f 84 28 15 00 00    	je     d3a0 <f0+0x29f0>
    be78:	80 f9 01             	cmp    $0x1,%cl
    be7b:	75 29                	jne    bea6 <f0+0x14f6>
    be7d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be80:	0f b7 c0             	movzwl %ax,%eax
    be83:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be86:	48 0f af c1          	imul   %rcx,%rax
    be8a:	48 c1 e8 20          	shr    $0x20,%rax
    be8e:	48 39 d0             	cmp    %rdx,%rax
    be91:	73 13                	jae    bea6 <f0+0x14f6>
    be93:	49 01 c4             	add    %rax,%r12
    be96:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be9b:	0f 84 75 16 00 00    	je     d516 <f0+0x2b66>
    bea1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bea6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bead:	33 f3 bf 
    beb0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    beb7:	00 
    beb8:	bf 01 00 00 00       	mov    $0x1,%edi
    bebd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    bec4:	00 
    bec5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    becc:	00 
    becd:	e8 fe 9c ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bed2:	48 8b 15 7f 7c 01 00 	mov    0x17c7f(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    bed9:	49 89 c5             	mov    %rax,%r13
    bedc:	48 2b 05 4d 7c 01 00 	sub    0x17c4d(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    bee3:	48 c1 e2 10          	shl    $0x10,%rdx
    bee7:	48 39 d0             	cmp    %rdx,%rax
    beea:	73 59                	jae    bf45 <f0+0x1595>
    beec:	48 89 c2             	mov    %rax,%rdx
    beef:	48 c1 ea 10          	shr    $0x10,%rdx
    bef3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bef7:	48 8b 15 7a 7c 01 00 	mov    0x17c7a(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    befe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf02:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf06:	4d 85 e4             	test   %r12,%r12
    bf09:	74 3a                	je     bf45 <f0+0x1595>
    bf0b:	0f b6 0a             	movzbl (%rdx),%ecx
    bf0e:	80 f9 02             	cmp    $0x2,%cl
    bf11:	0f 84 79 14 00 00    	je     d390 <f0+0x29e0>
    bf17:	80 f9 01             	cmp    $0x1,%cl
    bf1a:	75 29                	jne    bf45 <f0+0x1595>
    bf1c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf1f:	0f b7 c0             	movzwl %ax,%eax
    bf22:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf25:	48 0f af c1          	imul   %rcx,%rax
    bf29:	48 c1 e8 20          	shr    $0x20,%rax
    bf2d:	48 39 d0             	cmp    %rdx,%rax
    bf30:	73 13                	jae    bf45 <f0+0x1595>
    bf32:	49 01 c4             	add    %rax,%r12
    bf35:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf3a:	0f 84 e3 15 00 00    	je     d523 <f0+0x2b73>
    bf40:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf45:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bf4c:	00 f0 3f 
    bf4f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    bf56:	00 
    bf57:	bf 01 00 00 00       	mov    $0x1,%edi
    bf5c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    bf63:	00 
    bf64:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    bf6b:	00 
    bf6c:	e8 5f 9c ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    bf71:	48 8b 15 e0 7b 01 00 	mov    0x17be0(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    bf78:	49 89 c5             	mov    %rax,%r13
    bf7b:	48 2b 05 ae 7b 01 00 	sub    0x17bae(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    bf82:	48 c1 e2 10          	shl    $0x10,%rdx
    bf86:	48 39 d0             	cmp    %rdx,%rax
    bf89:	73 59                	jae    bfe4 <f0+0x1634>
    bf8b:	48 89 c2             	mov    %rax,%rdx
    bf8e:	48 c1 ea 10          	shr    $0x10,%rdx
    bf92:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf96:	48 8b 15 db 7b 01 00 	mov    0x17bdb(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    bf9d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfa1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfa5:	4d 85 e4             	test   %r12,%r12
    bfa8:	74 3a                	je     bfe4 <f0+0x1634>
    bfaa:	0f b6 0a             	movzbl (%rdx),%ecx
    bfad:	80 f9 02             	cmp    $0x2,%cl
    bfb0:	0f 84 ca 13 00 00    	je     d380 <f0+0x29d0>
    bfb6:	80 f9 01             	cmp    $0x1,%cl
    bfb9:	75 29                	jne    bfe4 <f0+0x1634>
    bfbb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfbe:	0f b7 c0             	movzwl %ax,%eax
    bfc1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfc4:	48 0f af c1          	imul   %rcx,%rax
    bfc8:	48 c1 e8 20          	shr    $0x20,%rax
    bfcc:	48 39 d0             	cmp    %rdx,%rax
    bfcf:	73 13                	jae    bfe4 <f0+0x1634>
    bfd1:	49 01 c4             	add    %rax,%r12
    bfd4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfd9:	0f 84 51 15 00 00    	je     d530 <f0+0x2b80>
    bfdf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfe4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bfeb:	33 f3 bf 
    bfee:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    bff5:	00 
    bff6:	bf 01 00 00 00       	mov    $0x1,%edi
    bffb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c002:	00 
    c003:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c00a:	00 
    c00b:	e8 c0 9b ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c010:	48 8b 15 41 7b 01 00 	mov    0x17b41(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c017:	49 89 c5             	mov    %rax,%r13
    c01a:	48 2b 05 0f 7b 01 00 	sub    0x17b0f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c021:	48 c1 e2 10          	shl    $0x10,%rdx
    c025:	48 39 d0             	cmp    %rdx,%rax
    c028:	73 59                	jae    c083 <f0+0x16d3>
    c02a:	48 89 c2             	mov    %rax,%rdx
    c02d:	48 c1 ea 10          	shr    $0x10,%rdx
    c031:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c035:	48 8b 15 3c 7b 01 00 	mov    0x17b3c(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c03c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c040:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c044:	4d 85 e4             	test   %r12,%r12
    c047:	74 3a                	je     c083 <f0+0x16d3>
    c049:	0f b6 0a             	movzbl (%rdx),%ecx
    c04c:	80 f9 02             	cmp    $0x2,%cl
    c04f:	0f 84 1b 13 00 00    	je     d370 <f0+0x29c0>
    c055:	80 f9 01             	cmp    $0x1,%cl
    c058:	75 29                	jne    c083 <f0+0x16d3>
    c05a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c05d:	0f b7 c0             	movzwl %ax,%eax
    c060:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c063:	48 0f af c1          	imul   %rcx,%rax
    c067:	48 c1 e8 20          	shr    $0x20,%rax
    c06b:	48 39 d0             	cmp    %rdx,%rax
    c06e:	73 13                	jae    c083 <f0+0x16d3>
    c070:	49 01 c4             	add    %rax,%r12
    c073:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c078:	0f 84 bf 14 00 00    	je     d53d <f0+0x2b8d>
    c07e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c083:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c08a:	00 f0 3f 
    c08d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c094:	00 
    c095:	bf 01 00 00 00       	mov    $0x1,%edi
    c09a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c0a1:	00 
    c0a2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c0a9:	00 
    c0aa:	e8 21 9b ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c0af:	48 8b 15 a2 7a 01 00 	mov    0x17aa2(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c0b6:	49 89 c5             	mov    %rax,%r13
    c0b9:	48 2b 05 70 7a 01 00 	sub    0x17a70(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c0c0:	48 c1 e2 10          	shl    $0x10,%rdx
    c0c4:	48 39 d0             	cmp    %rdx,%rax
    c0c7:	73 59                	jae    c122 <f0+0x1772>
    c0c9:	48 89 c2             	mov    %rax,%rdx
    c0cc:	48 c1 ea 10          	shr    $0x10,%rdx
    c0d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0d4:	48 8b 15 9d 7a 01 00 	mov    0x17a9d(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c0db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0df:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0e3:	4d 85 e4             	test   %r12,%r12
    c0e6:	74 3a                	je     c122 <f0+0x1772>
    c0e8:	0f b6 0a             	movzbl (%rdx),%ecx
    c0eb:	80 f9 02             	cmp    $0x2,%cl
    c0ee:	0f 84 6c 12 00 00    	je     d360 <f0+0x29b0>
    c0f4:	80 f9 01             	cmp    $0x1,%cl
    c0f7:	75 29                	jne    c122 <f0+0x1772>
    c0f9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0fc:	0f b7 c0             	movzwl %ax,%eax
    c0ff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c102:	48 0f af c1          	imul   %rcx,%rax
    c106:	48 c1 e8 20          	shr    $0x20,%rax
    c10a:	48 39 d0             	cmp    %rdx,%rax
    c10d:	73 13                	jae    c122 <f0+0x1772>
    c10f:	49 01 c4             	add    %rax,%r12
    c112:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c117:	0f 84 2d 14 00 00    	je     d54a <f0+0x2b9a>
    c11d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c122:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c129:	33 f3 bf 
    c12c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c133:	00 
    c134:	bf 01 00 00 00       	mov    $0x1,%edi
    c139:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c140:	00 
    c141:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c148:	00 
    c149:	e8 82 9a ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c14e:	48 8b 15 03 7a 01 00 	mov    0x17a03(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c155:	49 89 c5             	mov    %rax,%r13
    c158:	48 2b 05 d1 79 01 00 	sub    0x179d1(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c15f:	48 c1 e2 10          	shl    $0x10,%rdx
    c163:	48 39 d0             	cmp    %rdx,%rax
    c166:	73 59                	jae    c1c1 <f0+0x1811>
    c168:	48 89 c2             	mov    %rax,%rdx
    c16b:	48 c1 ea 10          	shr    $0x10,%rdx
    c16f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c173:	48 8b 15 fe 79 01 00 	mov    0x179fe(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c17a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c17e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c182:	4d 85 e4             	test   %r12,%r12
    c185:	74 3a                	je     c1c1 <f0+0x1811>
    c187:	0f b6 0a             	movzbl (%rdx),%ecx
    c18a:	80 f9 02             	cmp    $0x2,%cl
    c18d:	0f 84 bd 11 00 00    	je     d350 <f0+0x29a0>
    c193:	80 f9 01             	cmp    $0x1,%cl
    c196:	75 29                	jne    c1c1 <f0+0x1811>
    c198:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c19b:	0f b7 c0             	movzwl %ax,%eax
    c19e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1a1:	48 0f af c1          	imul   %rcx,%rax
    c1a5:	48 c1 e8 20          	shr    $0x20,%rax
    c1a9:	48 39 d0             	cmp    %rdx,%rax
    c1ac:	73 13                	jae    c1c1 <f0+0x1811>
    c1ae:	49 01 c4             	add    %rax,%r12
    c1b1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1b6:	0f 84 9b 13 00 00    	je     d557 <f0+0x2ba7>
    c1bc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1c1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c1c8:	00 f0 3f 
    c1cb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c1d2:	00 
    c1d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c1df:	00 
    c1e0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c1e7:	00 
    c1e8:	e8 e3 99 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c1ed:	48 8b 15 64 79 01 00 	mov    0x17964(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c1f4:	49 89 c5             	mov    %rax,%r13
    c1f7:	48 2b 05 32 79 01 00 	sub    0x17932(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c1fe:	48 c1 e2 10          	shl    $0x10,%rdx
    c202:	48 39 d0             	cmp    %rdx,%rax
    c205:	73 59                	jae    c260 <f0+0x18b0>
    c207:	48 89 c2             	mov    %rax,%rdx
    c20a:	48 c1 ea 10          	shr    $0x10,%rdx
    c20e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c212:	48 8b 15 5f 79 01 00 	mov    0x1795f(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c219:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c21d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c221:	4d 85 e4             	test   %r12,%r12
    c224:	74 3a                	je     c260 <f0+0x18b0>
    c226:	0f b6 0a             	movzbl (%rdx),%ecx
    c229:	80 f9 02             	cmp    $0x2,%cl
    c22c:	0f 84 0e 11 00 00    	je     d340 <f0+0x2990>
    c232:	80 f9 01             	cmp    $0x1,%cl
    c235:	75 29                	jne    c260 <f0+0x18b0>
    c237:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c23a:	0f b7 c0             	movzwl %ax,%eax
    c23d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c240:	48 0f af c1          	imul   %rcx,%rax
    c244:	48 c1 e8 20          	shr    $0x20,%rax
    c248:	48 39 d0             	cmp    %rdx,%rax
    c24b:	73 13                	jae    c260 <f0+0x18b0>
    c24d:	49 01 c4             	add    %rax,%r12
    c250:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c255:	0f 84 09 13 00 00    	je     d564 <f0+0x2bb4>
    c25b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c260:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c267:	33 f3 bf 
    c26a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c271:	00 
    c272:	bf 01 00 00 00       	mov    $0x1,%edi
    c277:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c27e:	00 
    c27f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c286:	00 
    c287:	e8 44 99 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c28c:	48 8b 15 c5 78 01 00 	mov    0x178c5(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c293:	49 89 c5             	mov    %rax,%r13
    c296:	48 2b 05 93 78 01 00 	sub    0x17893(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c29d:	48 c1 e2 10          	shl    $0x10,%rdx
    c2a1:	48 39 d0             	cmp    %rdx,%rax
    c2a4:	73 59                	jae    c2ff <f0+0x194f>
    c2a6:	48 89 c2             	mov    %rax,%rdx
    c2a9:	48 c1 ea 10          	shr    $0x10,%rdx
    c2ad:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2b1:	48 8b 15 c0 78 01 00 	mov    0x178c0(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c2b8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2bc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2c0:	4d 85 e4             	test   %r12,%r12
    c2c3:	74 3a                	je     c2ff <f0+0x194f>
    c2c5:	0f b6 0a             	movzbl (%rdx),%ecx
    c2c8:	80 f9 02             	cmp    $0x2,%cl
    c2cb:	0f 84 5f 10 00 00    	je     d330 <f0+0x2980>
    c2d1:	80 f9 01             	cmp    $0x1,%cl
    c2d4:	75 29                	jne    c2ff <f0+0x194f>
    c2d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2d9:	0f b7 c0             	movzwl %ax,%eax
    c2dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2df:	48 0f af c1          	imul   %rcx,%rax
    c2e3:	48 c1 e8 20          	shr    $0x20,%rax
    c2e7:	48 39 d0             	cmp    %rdx,%rax
    c2ea:	73 13                	jae    c2ff <f0+0x194f>
    c2ec:	49 01 c4             	add    %rax,%r12
    c2ef:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2f4:	0f 84 77 12 00 00    	je     d571 <f0+0x2bc1>
    c2fa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2ff:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c306:	00 f0 3f 
    c309:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c310:	00 
    c311:	bf 01 00 00 00       	mov    $0x1,%edi
    c316:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c31d:	00 
    c31e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c325:	00 
    c326:	e8 a5 98 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c32b:	48 8b 15 26 78 01 00 	mov    0x17826(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c332:	49 89 c5             	mov    %rax,%r13
    c335:	48 2b 05 f4 77 01 00 	sub    0x177f4(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c33c:	48 c1 e2 10          	shl    $0x10,%rdx
    c340:	48 39 d0             	cmp    %rdx,%rax
    c343:	73 59                	jae    c39e <f0+0x19ee>
    c345:	48 89 c2             	mov    %rax,%rdx
    c348:	48 c1 ea 10          	shr    $0x10,%rdx
    c34c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c350:	48 8b 15 21 78 01 00 	mov    0x17821(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c357:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c35b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c35f:	4d 85 e4             	test   %r12,%r12
    c362:	74 3a                	je     c39e <f0+0x19ee>
    c364:	0f b6 0a             	movzbl (%rdx),%ecx
    c367:	80 f9 02             	cmp    $0x2,%cl
    c36a:	0f 84 40 0f 00 00    	je     d2b0 <f0+0x2900>
    c370:	80 f9 01             	cmp    $0x1,%cl
    c373:	75 29                	jne    c39e <f0+0x19ee>
    c375:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c378:	0f b7 c0             	movzwl %ax,%eax
    c37b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c37e:	48 0f af c1          	imul   %rcx,%rax
    c382:	48 c1 e8 20          	shr    $0x20,%rax
    c386:	48 39 d0             	cmp    %rdx,%rax
    c389:	73 13                	jae    c39e <f0+0x19ee>
    c38b:	49 01 c4             	add    %rax,%r12
    c38e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c393:	0f 84 e5 11 00 00    	je     d57e <f0+0x2bce>
    c399:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c39e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c3a5:	33 f3 bf 
    c3a8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c3af:	00 
    c3b0:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c3bc:	00 
    c3bd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c3c4:	00 
    c3c5:	e8 06 98 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c3ca:	48 8b 15 87 77 01 00 	mov    0x17787(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c3d1:	49 89 c5             	mov    %rax,%r13
    c3d4:	48 2b 05 55 77 01 00 	sub    0x17755(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c3db:	48 c1 e2 10          	shl    $0x10,%rdx
    c3df:	48 39 d0             	cmp    %rdx,%rax
    c3e2:	73 59                	jae    c43d <f0+0x1a8d>
    c3e4:	48 89 c2             	mov    %rax,%rdx
    c3e7:	48 c1 ea 10          	shr    $0x10,%rdx
    c3eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3ef:	48 8b 15 82 77 01 00 	mov    0x17782(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c3f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3fa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3fe:	4d 85 e4             	test   %r12,%r12
    c401:	74 3a                	je     c43d <f0+0x1a8d>
    c403:	0f b6 0a             	movzbl (%rdx),%ecx
    c406:	80 f9 02             	cmp    $0x2,%cl
    c409:	0f 84 91 0e 00 00    	je     d2a0 <f0+0x28f0>
    c40f:	80 f9 01             	cmp    $0x1,%cl
    c412:	75 29                	jne    c43d <f0+0x1a8d>
    c414:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c417:	0f b7 c0             	movzwl %ax,%eax
    c41a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c41d:	48 0f af c1          	imul   %rcx,%rax
    c421:	48 c1 e8 20          	shr    $0x20,%rax
    c425:	48 39 d0             	cmp    %rdx,%rax
    c428:	73 13                	jae    c43d <f0+0x1a8d>
    c42a:	49 01 c4             	add    %rax,%r12
    c42d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c432:	0f 84 53 11 00 00    	je     d58b <f0+0x2bdb>
    c438:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c43d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c444:	00 f0 3f 
    c447:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c44e:	00 
    c44f:	bf 01 00 00 00       	mov    $0x1,%edi
    c454:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c45b:	00 
    c45c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c463:	00 
    c464:	e8 67 97 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c469:	48 8b 15 e8 76 01 00 	mov    0x176e8(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c470:	49 89 c5             	mov    %rax,%r13
    c473:	48 2b 05 b6 76 01 00 	sub    0x176b6(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c47a:	48 c1 e2 10          	shl    $0x10,%rdx
    c47e:	48 39 d0             	cmp    %rdx,%rax
    c481:	73 59                	jae    c4dc <f0+0x1b2c>
    c483:	48 89 c2             	mov    %rax,%rdx
    c486:	48 c1 ea 10          	shr    $0x10,%rdx
    c48a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c48e:	48 8b 15 e3 76 01 00 	mov    0x176e3(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c495:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c499:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c49d:	4d 85 e4             	test   %r12,%r12
    c4a0:	74 3a                	je     c4dc <f0+0x1b2c>
    c4a2:	0f b6 0a             	movzbl (%rdx),%ecx
    c4a5:	80 f9 02             	cmp    $0x2,%cl
    c4a8:	0f 84 e2 0d 00 00    	je     d290 <f0+0x28e0>
    c4ae:	80 f9 01             	cmp    $0x1,%cl
    c4b1:	75 29                	jne    c4dc <f0+0x1b2c>
    c4b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4b6:	0f b7 c0             	movzwl %ax,%eax
    c4b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4bc:	48 0f af c1          	imul   %rcx,%rax
    c4c0:	48 c1 e8 20          	shr    $0x20,%rax
    c4c4:	48 39 d0             	cmp    %rdx,%rax
    c4c7:	73 13                	jae    c4dc <f0+0x1b2c>
    c4c9:	49 01 c4             	add    %rax,%r12
    c4cc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4d1:	0f 84 c1 10 00 00    	je     d598 <f0+0x2be8>
    c4d7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4dc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c4e3:	33 f3 bf 
    c4e6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c4ed:	00 
    c4ee:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c4fa:	00 
    c4fb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c502:	00 
    c503:	e8 c8 96 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c508:	48 8b 15 49 76 01 00 	mov    0x17649(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c50f:	49 89 c5             	mov    %rax,%r13
    c512:	48 2b 05 17 76 01 00 	sub    0x17617(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c519:	48 c1 e2 10          	shl    $0x10,%rdx
    c51d:	48 39 d0             	cmp    %rdx,%rax
    c520:	73 59                	jae    c57b <f0+0x1bcb>
    c522:	48 89 c2             	mov    %rax,%rdx
    c525:	48 c1 ea 10          	shr    $0x10,%rdx
    c529:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c52d:	48 8b 15 44 76 01 00 	mov    0x17644(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c534:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c538:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c53c:	4d 85 e4             	test   %r12,%r12
    c53f:	74 3a                	je     c57b <f0+0x1bcb>
    c541:	0f b6 0a             	movzbl (%rdx),%ecx
    c544:	80 f9 02             	cmp    $0x2,%cl
    c547:	0f 84 33 0d 00 00    	je     d280 <f0+0x28d0>
    c54d:	80 f9 01             	cmp    $0x1,%cl
    c550:	75 29                	jne    c57b <f0+0x1bcb>
    c552:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c555:	0f b7 c0             	movzwl %ax,%eax
    c558:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c55b:	48 0f af c1          	imul   %rcx,%rax
    c55f:	48 c1 e8 20          	shr    $0x20,%rax
    c563:	48 39 d0             	cmp    %rdx,%rax
    c566:	73 13                	jae    c57b <f0+0x1bcb>
    c568:	49 01 c4             	add    %rax,%r12
    c56b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c570:	0f 84 2f 10 00 00    	je     d5a5 <f0+0x2bf5>
    c576:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c57b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c582:	00 f0 3f 
    c585:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c58c:	00 
    c58d:	bf 01 00 00 00       	mov    $0x1,%edi
    c592:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c599:	00 
    c59a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c5a1:	00 
    c5a2:	e8 29 96 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c5a7:	48 8b 15 aa 75 01 00 	mov    0x175aa(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c5ae:	49 89 c5             	mov    %rax,%r13
    c5b1:	48 2b 05 78 75 01 00 	sub    0x17578(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c5b8:	48 c1 e2 10          	shl    $0x10,%rdx
    c5bc:	48 39 d0             	cmp    %rdx,%rax
    c5bf:	73 59                	jae    c61a <f0+0x1c6a>
    c5c1:	48 89 c2             	mov    %rax,%rdx
    c5c4:	48 c1 ea 10          	shr    $0x10,%rdx
    c5c8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5cc:	48 8b 15 a5 75 01 00 	mov    0x175a5(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c5d3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5d7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5db:	4d 85 e4             	test   %r12,%r12
    c5de:	74 3a                	je     c61a <f0+0x1c6a>
    c5e0:	0f b6 0a             	movzbl (%rdx),%ecx
    c5e3:	80 f9 02             	cmp    $0x2,%cl
    c5e6:	0f 84 84 0c 00 00    	je     d270 <f0+0x28c0>
    c5ec:	80 f9 01             	cmp    $0x1,%cl
    c5ef:	75 29                	jne    c61a <f0+0x1c6a>
    c5f1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5f4:	0f b7 c0             	movzwl %ax,%eax
    c5f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5fa:	48 0f af c1          	imul   %rcx,%rax
    c5fe:	48 c1 e8 20          	shr    $0x20,%rax
    c602:	48 39 d0             	cmp    %rdx,%rax
    c605:	73 13                	jae    c61a <f0+0x1c6a>
    c607:	49 01 c4             	add    %rax,%r12
    c60a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c60f:	0f 84 9d 0f 00 00    	je     d5b2 <f0+0x2c02>
    c615:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c61a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c621:	33 f3 bf 
    c624:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c62b:	00 
    c62c:	bf 01 00 00 00       	mov    $0x1,%edi
    c631:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c638:	00 
    c639:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c640:	00 
    c641:	e8 8a 95 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c646:	48 8b 15 0b 75 01 00 	mov    0x1750b(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c64d:	49 89 c5             	mov    %rax,%r13
    c650:	48 2b 05 d9 74 01 00 	sub    0x174d9(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c657:	48 c1 e2 10          	shl    $0x10,%rdx
    c65b:	48 39 d0             	cmp    %rdx,%rax
    c65e:	73 59                	jae    c6b9 <f0+0x1d09>
    c660:	48 89 c2             	mov    %rax,%rdx
    c663:	48 c1 ea 10          	shr    $0x10,%rdx
    c667:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c66b:	48 8b 15 06 75 01 00 	mov    0x17506(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c672:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c676:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c67a:	4d 85 e4             	test   %r12,%r12
    c67d:	74 3a                	je     c6b9 <f0+0x1d09>
    c67f:	0f b6 0a             	movzbl (%rdx),%ecx
    c682:	80 f9 02             	cmp    $0x2,%cl
    c685:	0f 84 d5 0b 00 00    	je     d260 <f0+0x28b0>
    c68b:	80 f9 01             	cmp    $0x1,%cl
    c68e:	75 29                	jne    c6b9 <f0+0x1d09>
    c690:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c693:	0f b7 c0             	movzwl %ax,%eax
    c696:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c699:	48 0f af c1          	imul   %rcx,%rax
    c69d:	48 c1 e8 20          	shr    $0x20,%rax
    c6a1:	48 39 d0             	cmp    %rdx,%rax
    c6a4:	73 13                	jae    c6b9 <f0+0x1d09>
    c6a6:	49 01 c4             	add    %rax,%r12
    c6a9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6ae:	0f 84 0b 0f 00 00    	je     d5bf <f0+0x2c0f>
    c6b4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6b9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c6c0:	00 f0 3f 
    c6c3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c6ca:	00 
    c6cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c6d7:	00 
    c6d8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c6df:	00 
    c6e0:	e8 eb 94 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c6e5:	48 8b 15 6c 74 01 00 	mov    0x1746c(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c6ec:	49 89 c5             	mov    %rax,%r13
    c6ef:	48 2b 05 3a 74 01 00 	sub    0x1743a(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c6f6:	48 c1 e2 10          	shl    $0x10,%rdx
    c6fa:	48 39 d0             	cmp    %rdx,%rax
    c6fd:	73 59                	jae    c758 <f0+0x1da8>
    c6ff:	48 89 c2             	mov    %rax,%rdx
    c702:	48 c1 ea 10          	shr    $0x10,%rdx
    c706:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c70a:	48 8b 15 67 74 01 00 	mov    0x17467(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c711:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c715:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c719:	4d 85 e4             	test   %r12,%r12
    c71c:	74 3a                	je     c758 <f0+0x1da8>
    c71e:	0f b6 0a             	movzbl (%rdx),%ecx
    c721:	80 f9 02             	cmp    $0x2,%cl
    c724:	0f 84 26 0b 00 00    	je     d250 <f0+0x28a0>
    c72a:	80 f9 01             	cmp    $0x1,%cl
    c72d:	75 29                	jne    c758 <f0+0x1da8>
    c72f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c732:	0f b7 c0             	movzwl %ax,%eax
    c735:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c738:	48 0f af c1          	imul   %rcx,%rax
    c73c:	48 c1 e8 20          	shr    $0x20,%rax
    c740:	48 39 d0             	cmp    %rdx,%rax
    c743:	73 13                	jae    c758 <f0+0x1da8>
    c745:	49 01 c4             	add    %rax,%r12
    c748:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c74d:	0f 84 79 0e 00 00    	je     d5cc <f0+0x2c1c>
    c753:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c758:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c75f:	33 f3 bf 
    c762:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c769:	00 
    c76a:	bf 01 00 00 00       	mov    $0x1,%edi
    c76f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c776:	00 
    c777:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c77e:	00 
    c77f:	e8 4c 94 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c784:	48 8b 15 cd 73 01 00 	mov    0x173cd(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c78b:	49 89 c5             	mov    %rax,%r13
    c78e:	48 2b 05 9b 73 01 00 	sub    0x1739b(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c795:	48 c1 e2 10          	shl    $0x10,%rdx
    c799:	48 39 d0             	cmp    %rdx,%rax
    c79c:	73 59                	jae    c7f7 <f0+0x1e47>
    c79e:	48 89 c2             	mov    %rax,%rdx
    c7a1:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7a9:	48 8b 15 c8 73 01 00 	mov    0x173c8(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c7b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7b8:	4d 85 e4             	test   %r12,%r12
    c7bb:	74 3a                	je     c7f7 <f0+0x1e47>
    c7bd:	0f b6 0a             	movzbl (%rdx),%ecx
    c7c0:	80 f9 02             	cmp    $0x2,%cl
    c7c3:	0f 84 77 0a 00 00    	je     d240 <f0+0x2890>
    c7c9:	80 f9 01             	cmp    $0x1,%cl
    c7cc:	75 29                	jne    c7f7 <f0+0x1e47>
    c7ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7d1:	0f b7 c0             	movzwl %ax,%eax
    c7d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d7:	48 0f af c1          	imul   %rcx,%rax
    c7db:	48 c1 e8 20          	shr    $0x20,%rax
    c7df:	48 39 d0             	cmp    %rdx,%rax
    c7e2:	73 13                	jae    c7f7 <f0+0x1e47>
    c7e4:	49 01 c4             	add    %rax,%r12
    c7e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7ec:	0f 84 e7 0d 00 00    	je     d5d9 <f0+0x2c29>
    c7f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7fe:	00 f0 3f 
    c801:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c808:	00 
    c809:	bf 01 00 00 00       	mov    $0x1,%edi
    c80e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c815:	00 
    c816:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c81d:	00 
    c81e:	e8 ad 93 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c823:	48 8b 15 2e 73 01 00 	mov    0x1732e(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c82a:	49 89 c5             	mov    %rax,%r13
    c82d:	48 2b 05 fc 72 01 00 	sub    0x172fc(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c834:	48 c1 e2 10          	shl    $0x10,%rdx
    c838:	48 39 d0             	cmp    %rdx,%rax
    c83b:	73 59                	jae    c896 <f0+0x1ee6>
    c83d:	48 89 c2             	mov    %rax,%rdx
    c840:	48 c1 ea 10          	shr    $0x10,%rdx
    c844:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c848:	48 8b 15 29 73 01 00 	mov    0x17329(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c84f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c853:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c857:	4d 85 e4             	test   %r12,%r12
    c85a:	74 3a                	je     c896 <f0+0x1ee6>
    c85c:	0f b6 0a             	movzbl (%rdx),%ecx
    c85f:	80 f9 02             	cmp    $0x2,%cl
    c862:	0f 84 38 0c 00 00    	je     d4a0 <f0+0x2af0>
    c868:	80 f9 01             	cmp    $0x1,%cl
    c86b:	75 29                	jne    c896 <f0+0x1ee6>
    c86d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c870:	0f b7 c0             	movzwl %ax,%eax
    c873:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c876:	48 0f af c1          	imul   %rcx,%rax
    c87a:	48 c1 e8 20          	shr    $0x20,%rax
    c87e:	48 39 d0             	cmp    %rdx,%rax
    c881:	73 13                	jae    c896 <f0+0x1ee6>
    c883:	49 01 c4             	add    %rax,%r12
    c886:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c88b:	0f 84 55 0d 00 00    	je     d5e6 <f0+0x2c36>
    c891:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c896:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c89d:	33 f3 bf 
    c8a0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    c8a7:	00 
    c8a8:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ad:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    c8b4:	00 
    c8b5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    c8bc:	00 
    c8bd:	e8 0e 93 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c8c2:	48 8b 15 8f 72 01 00 	mov    0x1728f(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c8c9:	49 89 c5             	mov    %rax,%r13
    c8cc:	48 2b 05 5d 72 01 00 	sub    0x1725d(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c8d3:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d7:	48 39 d0             	cmp    %rdx,%rax
    c8da:	73 59                	jae    c935 <f0+0x1f85>
    c8dc:	48 89 c2             	mov    %rax,%rdx
    c8df:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e7:	48 8b 15 8a 72 01 00 	mov    0x1728a(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c8ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f6:	4d 85 e4             	test   %r12,%r12
    c8f9:	74 3a                	je     c935 <f0+0x1f85>
    c8fb:	0f b6 0a             	movzbl (%rdx),%ecx
    c8fe:	80 f9 02             	cmp    $0x2,%cl
    c901:	0f 84 89 0b 00 00    	je     d490 <f0+0x2ae0>
    c907:	80 f9 01             	cmp    $0x1,%cl
    c90a:	75 29                	jne    c935 <f0+0x1f85>
    c90c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c90f:	0f b7 c0             	movzwl %ax,%eax
    c912:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c915:	48 0f af c1          	imul   %rcx,%rax
    c919:	48 c1 e8 20          	shr    $0x20,%rax
    c91d:	48 39 d0             	cmp    %rdx,%rax
    c920:	73 13                	jae    c935 <f0+0x1f85>
    c922:	49 01 c4             	add    %rax,%r12
    c925:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c92a:	0f 84 c3 0c 00 00    	je     d5f3 <f0+0x2c43>
    c930:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c935:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c93c:	00 f0 3f 
    c93f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    c946:	00 
    c947:	bf 01 00 00 00       	mov    $0x1,%edi
    c94c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    c953:	00 
    c954:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    c95b:	00 
    c95c:	e8 6f 92 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    c961:	48 8b 15 f0 71 01 00 	mov    0x171f0(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    c968:	49 89 c5             	mov    %rax,%r13
    c96b:	48 2b 05 be 71 01 00 	sub    0x171be(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    c972:	48 c1 e2 10          	shl    $0x10,%rdx
    c976:	48 39 d0             	cmp    %rdx,%rax
    c979:	73 59                	jae    c9d4 <f0+0x2024>
    c97b:	48 89 c2             	mov    %rax,%rdx
    c97e:	48 c1 ea 10          	shr    $0x10,%rdx
    c982:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c986:	48 8b 15 eb 71 01 00 	mov    0x171eb(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    c98d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c991:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c995:	4d 85 e4             	test   %r12,%r12
    c998:	74 3a                	je     c9d4 <f0+0x2024>
    c99a:	0f b6 0a             	movzbl (%rdx),%ecx
    c99d:	80 f9 02             	cmp    $0x2,%cl
    c9a0:	0f 84 da 0a 00 00    	je     d480 <f0+0x2ad0>
    c9a6:	80 f9 01             	cmp    $0x1,%cl
    c9a9:	75 29                	jne    c9d4 <f0+0x2024>
    c9ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9ae:	0f b7 c0             	movzwl %ax,%eax
    c9b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b4:	48 0f af c1          	imul   %rcx,%rax
    c9b8:	48 c1 e8 20          	shr    $0x20,%rax
    c9bc:	48 39 d0             	cmp    %rdx,%rax
    c9bf:	73 13                	jae    c9d4 <f0+0x2024>
    c9c1:	49 01 c4             	add    %rax,%r12
    c9c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9c9:	0f 84 31 0c 00 00    	je     d600 <f0+0x2c50>
    c9cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9db:	33 f3 bf 
    c9de:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    c9e5:	00 
    c9e6:	bf 01 00 00 00       	mov    $0x1,%edi
    c9eb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    c9f2:	00 
    c9f3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    c9fa:	00 
    c9fb:	e8 d0 91 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ca00:	48 8b 15 51 71 01 00 	mov    0x17151(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ca07:	49 89 c5             	mov    %rax,%r13
    ca0a:	48 2b 05 1f 71 01 00 	sub    0x1711f(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    ca11:	48 c1 e2 10          	shl    $0x10,%rdx
    ca15:	48 39 d0             	cmp    %rdx,%rax
    ca18:	73 59                	jae    ca73 <f0+0x20c3>
    ca1a:	48 89 c2             	mov    %rax,%rdx
    ca1d:	48 c1 ea 10          	shr    $0x10,%rdx
    ca21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca25:	48 8b 15 4c 71 01 00 	mov    0x1714c(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    ca2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca30:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca34:	4d 85 e4             	test   %r12,%r12
    ca37:	74 3a                	je     ca73 <f0+0x20c3>
    ca39:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3c:	80 f9 02             	cmp    $0x2,%cl
    ca3f:	0f 84 2b 0a 00 00    	je     d470 <f0+0x2ac0>
    ca45:	80 f9 01             	cmp    $0x1,%cl
    ca48:	75 29                	jne    ca73 <f0+0x20c3>
    ca4a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4d:	0f b7 c0             	movzwl %ax,%eax
    ca50:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca53:	48 0f af c1          	imul   %rcx,%rax
    ca57:	48 c1 e8 20          	shr    $0x20,%rax
    ca5b:	48 39 d0             	cmp    %rdx,%rax
    ca5e:	73 13                	jae    ca73 <f0+0x20c3>
    ca60:	49 01 c4             	add    %rax,%r12
    ca63:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca68:	0f 84 9f 0b 00 00    	je     d60d <f0+0x2c5d>
    ca6e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca73:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca7a:	00 f0 3f 
    ca7d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    ca84:	00 
    ca85:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    ca91:	00 
    ca92:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    ca99:	00 
    ca9a:	e8 31 91 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ca9f:	48 8b 15 b2 70 01 00 	mov    0x170b2(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    caa6:	49 89 c5             	mov    %rax,%r13
    caa9:	48 2b 05 80 70 01 00 	sub    0x17080(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cab0:	48 c1 e2 10          	shl    $0x10,%rdx
    cab4:	48 39 d0             	cmp    %rdx,%rax
    cab7:	73 59                	jae    cb12 <f0+0x2162>
    cab9:	48 89 c2             	mov    %rax,%rdx
    cabc:	48 c1 ea 10          	shr    $0x10,%rdx
    cac0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac4:	48 8b 15 ad 70 01 00 	mov    0x170ad(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cacb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cacf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad3:	4d 85 e4             	test   %r12,%r12
    cad6:	74 3a                	je     cb12 <f0+0x2162>
    cad8:	0f b6 0a             	movzbl (%rdx),%ecx
    cadb:	80 f9 02             	cmp    $0x2,%cl
    cade:	0f 84 7c 09 00 00    	je     d460 <f0+0x2ab0>
    cae4:	80 f9 01             	cmp    $0x1,%cl
    cae7:	75 29                	jne    cb12 <f0+0x2162>
    cae9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caec:	0f b7 c0             	movzwl %ax,%eax
    caef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf2:	48 0f af c1          	imul   %rcx,%rax
    caf6:	48 c1 e8 20          	shr    $0x20,%rax
    cafa:	48 39 d0             	cmp    %rdx,%rax
    cafd:	73 13                	jae    cb12 <f0+0x2162>
    caff:	49 01 c4             	add    %rax,%r12
    cb02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb07:	0f 84 0d 0b 00 00    	je     d61a <f0+0x2c6a>
    cb0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb12:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb19:	33 f3 bf 
    cb1c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    cb23:	00 
    cb24:	bf 01 00 00 00       	mov    $0x1,%edi
    cb29:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    cb30:	00 
    cb31:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    cb38:	00 
    cb39:	e8 92 90 ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cb3e:	48 8b 15 13 70 01 00 	mov    0x17013(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cb45:	49 89 c5             	mov    %rax,%r13
    cb48:	48 2b 05 e1 6f 01 00 	sub    0x16fe1(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cb4f:	48 c1 e2 10          	shl    $0x10,%rdx
    cb53:	48 39 d0             	cmp    %rdx,%rax
    cb56:	73 59                	jae    cbb1 <f0+0x2201>
    cb58:	48 89 c2             	mov    %rax,%rdx
    cb5b:	48 c1 ea 10          	shr    $0x10,%rdx
    cb5f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb63:	48 8b 15 0e 70 01 00 	mov    0x1700e(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cb6a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb6e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb72:	4d 85 e4             	test   %r12,%r12
    cb75:	74 3a                	je     cbb1 <f0+0x2201>
    cb77:	0f b6 0a             	movzbl (%rdx),%ecx
    cb7a:	80 f9 02             	cmp    $0x2,%cl
    cb7d:	0f 84 cd 08 00 00    	je     d450 <f0+0x2aa0>
    cb83:	80 f9 01             	cmp    $0x1,%cl
    cb86:	75 29                	jne    cbb1 <f0+0x2201>
    cb88:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb8b:	0f b7 c0             	movzwl %ax,%eax
    cb8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb91:	48 0f af c1          	imul   %rcx,%rax
    cb95:	48 c1 e8 20          	shr    $0x20,%rax
    cb99:	48 39 d0             	cmp    %rdx,%rax
    cb9c:	73 13                	jae    cbb1 <f0+0x2201>
    cb9e:	49 01 c4             	add    %rax,%r12
    cba1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba6:	0f 84 7b 0a 00 00    	je     d627 <f0+0x2c77>
    cbac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cbb8:	00 f0 3f 
    cbbb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cbc2:	00 
    cbc3:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cbcf:	00 
    cbd0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cbd7:	00 
    cbd8:	e8 f3 8f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cbdd:	48 8b 15 74 6f 01 00 	mov    0x16f74(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cbe4:	49 89 c5             	mov    %rax,%r13
    cbe7:	48 2b 05 42 6f 01 00 	sub    0x16f42(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cbee:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf2:	48 39 d0             	cmp    %rdx,%rax
    cbf5:	73 59                	jae    cc50 <f0+0x22a0>
    cbf7:	48 89 c2             	mov    %rax,%rdx
    cbfa:	48 c1 ea 10          	shr    $0x10,%rdx
    cbfe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc02:	48 8b 15 6f 6f 01 00 	mov    0x16f6f(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cc09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc11:	4d 85 e4             	test   %r12,%r12
    cc14:	74 3a                	je     cc50 <f0+0x22a0>
    cc16:	0f b6 0a             	movzbl (%rdx),%ecx
    cc19:	80 f9 02             	cmp    $0x2,%cl
    cc1c:	0f 84 1e 08 00 00    	je     d440 <f0+0x2a90>
    cc22:	80 f9 01             	cmp    $0x1,%cl
    cc25:	75 29                	jne    cc50 <f0+0x22a0>
    cc27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc2a:	0f b7 c0             	movzwl %ax,%eax
    cc2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc30:	48 0f af c1          	imul   %rcx,%rax
    cc34:	48 c1 e8 20          	shr    $0x20,%rax
    cc38:	48 39 d0             	cmp    %rdx,%rax
    cc3b:	73 13                	jae    cc50 <f0+0x22a0>
    cc3d:	49 01 c4             	add    %rax,%r12
    cc40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc45:	0f 84 e9 09 00 00    	je     d634 <f0+0x2c84>
    cc4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc57:	33 f3 bf 
    cc5a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    cc61:	00 
    cc62:	bf 01 00 00 00       	mov    $0x1,%edi
    cc67:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    cc6e:	00 
    cc6f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    cc76:	00 
    cc77:	e8 54 8f ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cc7c:	48 8b 15 d5 6e 01 00 	mov    0x16ed5(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cc83:	49 89 c5             	mov    %rax,%r13
    cc86:	48 2b 05 a3 6e 01 00 	sub    0x16ea3(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cc8d:	48 c1 e2 10          	shl    $0x10,%rdx
    cc91:	48 39 d0             	cmp    %rdx,%rax
    cc94:	73 59                	jae    ccef <f0+0x233f>
    cc96:	48 89 c2             	mov    %rax,%rdx
    cc99:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca1:	48 8b 15 d0 6e 01 00 	mov    0x16ed0(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cca8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccb0:	4d 85 e4             	test   %r12,%r12
    ccb3:	74 3a                	je     ccef <f0+0x233f>
    ccb5:	0f b6 0a             	movzbl (%rdx),%ecx
    ccb8:	80 f9 02             	cmp    $0x2,%cl
    ccbb:	0f 84 6f 07 00 00    	je     d430 <f0+0x2a80>
    ccc1:	80 f9 01             	cmp    $0x1,%cl
    ccc4:	75 29                	jne    ccef <f0+0x233f>
    ccc6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccc9:	0f b7 c0             	movzwl %ax,%eax
    cccc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cccf:	48 0f af c1          	imul   %rcx,%rax
    ccd3:	48 c1 e8 20          	shr    $0x20,%rax
    ccd7:	48 39 d0             	cmp    %rdx,%rax
    ccda:	73 13                	jae    ccef <f0+0x233f>
    ccdc:	49 01 c4             	add    %rax,%r12
    ccdf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce4:	0f 84 57 09 00 00    	je     d641 <f0+0x2c91>
    ccea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccf6:	00 f0 3f 
    ccf9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cd00:	00 
    cd01:	bf 01 00 00 00       	mov    $0x1,%edi
    cd06:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cd0d:	00 
    cd0e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    cd15:	00 
    cd16:	e8 b5 8e ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cd1b:	48 8b 15 36 6e 01 00 	mov    0x16e36(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cd22:	49 89 c5             	mov    %rax,%r13
    cd25:	48 2b 05 04 6e 01 00 	sub    0x16e04(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cd2c:	48 c1 e2 10          	shl    $0x10,%rdx
    cd30:	48 39 d0             	cmp    %rdx,%rax
    cd33:	73 59                	jae    cd8e <f0+0x23de>
    cd35:	48 89 c2             	mov    %rax,%rdx
    cd38:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd40:	48 8b 15 31 6e 01 00 	mov    0x16e31(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cd47:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd4b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd4f:	4d 85 e4             	test   %r12,%r12
    cd52:	74 3a                	je     cd8e <f0+0x23de>
    cd54:	0f b6 0a             	movzbl (%rdx),%ecx
    cd57:	80 f9 02             	cmp    $0x2,%cl
    cd5a:	0f 84 c0 06 00 00    	je     d420 <f0+0x2a70>
    cd60:	80 f9 01             	cmp    $0x1,%cl
    cd63:	75 29                	jne    cd8e <f0+0x23de>
    cd65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd68:	0f b7 c0             	movzwl %ax,%eax
    cd6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd6e:	48 0f af c1          	imul   %rcx,%rax
    cd72:	48 c1 e8 20          	shr    $0x20,%rax
    cd76:	48 39 d0             	cmp    %rdx,%rax
    cd79:	73 13                	jae    cd8e <f0+0x23de>
    cd7b:	49 01 c4             	add    %rax,%r12
    cd7e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd83:	0f 84 c5 08 00 00    	je     d64e <f0+0x2c9e>
    cd89:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd8e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd95:	33 f3 bf 
    cd98:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cd9f:	00 
    cda0:	bf 01 00 00 00       	mov    $0x1,%edi
    cda5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cdac:	00 
    cdad:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cdb4:	00 
    cdb5:	e8 16 8e ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cdba:	48 8b 15 97 6d 01 00 	mov    0x16d97(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cdc1:	49 89 c5             	mov    %rax,%r13
    cdc4:	48 2b 05 65 6d 01 00 	sub    0x16d65(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cdcb:	48 c1 e2 10          	shl    $0x10,%rdx
    cdcf:	48 39 d0             	cmp    %rdx,%rax
    cdd2:	73 59                	jae    ce2d <f0+0x247d>
    cdd4:	48 89 c2             	mov    %rax,%rdx
    cdd7:	48 c1 ea 10          	shr    $0x10,%rdx
    cddb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cddf:	48 8b 15 92 6d 01 00 	mov    0x16d92(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cde6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdee:	4d 85 e4             	test   %r12,%r12
    cdf1:	74 3a                	je     ce2d <f0+0x247d>
    cdf3:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf6:	80 f9 02             	cmp    $0x2,%cl
    cdf9:	0f 84 11 06 00 00    	je     d410 <f0+0x2a60>
    cdff:	80 f9 01             	cmp    $0x1,%cl
    ce02:	75 29                	jne    ce2d <f0+0x247d>
    ce04:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce07:	0f b7 c0             	movzwl %ax,%eax
    ce0a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0d:	48 0f af c1          	imul   %rcx,%rax
    ce11:	48 c1 e8 20          	shr    $0x20,%rax
    ce15:	48 39 d0             	cmp    %rdx,%rax
    ce18:	73 13                	jae    ce2d <f0+0x247d>
    ce1a:	49 01 c4             	add    %rax,%r12
    ce1d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce22:	0f 84 33 08 00 00    	je     d65b <f0+0x2cab>
    ce28:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce34:	00 f0 3f 
    ce37:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    ce3e:	00 
    ce3f:	bf 01 00 00 00       	mov    $0x1,%edi
    ce44:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    ce4b:	00 
    ce4c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    ce53:	00 
    ce54:	e8 77 8d ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    ce59:	48 8b 15 f8 6c 01 00 	mov    0x16cf8(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ce60:	49 89 c5             	mov    %rax,%r13
    ce63:	48 2b 05 c6 6c 01 00 	sub    0x16cc6(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    ce6a:	48 c1 e2 10          	shl    $0x10,%rdx
    ce6e:	48 39 d0             	cmp    %rdx,%rax
    ce71:	73 59                	jae    cecc <f0+0x251c>
    ce73:	48 89 c2             	mov    %rax,%rdx
    ce76:	48 c1 ea 10          	shr    $0x10,%rdx
    ce7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce7e:	48 8b 15 f3 6c 01 00 	mov    0x16cf3(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    ce85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce89:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8d:	4d 85 e4             	test   %r12,%r12
    ce90:	74 3a                	je     cecc <f0+0x251c>
    ce92:	0f b6 0a             	movzbl (%rdx),%ecx
    ce95:	80 f9 02             	cmp    $0x2,%cl
    ce98:	0f 84 62 05 00 00    	je     d400 <f0+0x2a50>
    ce9e:	80 f9 01             	cmp    $0x1,%cl
    cea1:	75 29                	jne    cecc <f0+0x251c>
    cea3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea6:	0f b7 c0             	movzwl %ax,%eax
    cea9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceac:	48 0f af c1          	imul   %rcx,%rax
    ceb0:	48 c1 e8 20          	shr    $0x20,%rax
    ceb4:	48 39 d0             	cmp    %rdx,%rax
    ceb7:	73 13                	jae    cecc <f0+0x251c>
    ceb9:	49 01 c4             	add    %rax,%r12
    cebc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec1:	0f 84 a1 07 00 00    	je     d668 <f0+0x2cb8>
    cec7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cecc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ced3:	33 f3 bf 
    ced6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    cedd:	00 
    cede:	bf 01 00 00 00       	mov    $0x1,%edi
    cee3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    ceea:	00 
    ceeb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    cef2:	00 
    cef3:	e8 d8 8c ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cef8:	48 8b 15 59 6c 01 00 	mov    0x16c59(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    ceff:	49 89 c5             	mov    %rax,%r13
    cf02:	48 2b 05 27 6c 01 00 	sub    0x16c27(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cf09:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0d:	48 39 d0             	cmp    %rdx,%rax
    cf10:	73 59                	jae    cf6b <f0+0x25bb>
    cf12:	48 89 c2             	mov    %rax,%rdx
    cf15:	48 c1 ea 10          	shr    $0x10,%rdx
    cf19:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1d:	48 8b 15 54 6c 01 00 	mov    0x16c54(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cf24:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf28:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2c:	4d 85 e4             	test   %r12,%r12
    cf2f:	74 3a                	je     cf6b <f0+0x25bb>
    cf31:	0f b6 0a             	movzbl (%rdx),%ecx
    cf34:	80 f9 02             	cmp    $0x2,%cl
    cf37:	0f 84 b3 04 00 00    	je     d3f0 <f0+0x2a40>
    cf3d:	80 f9 01             	cmp    $0x1,%cl
    cf40:	75 29                	jne    cf6b <f0+0x25bb>
    cf42:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf45:	0f b7 c0             	movzwl %ax,%eax
    cf48:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf4b:	48 0f af c1          	imul   %rcx,%rax
    cf4f:	48 c1 e8 20          	shr    $0x20,%rax
    cf53:	48 39 d0             	cmp    %rdx,%rax
    cf56:	73 13                	jae    cf6b <f0+0x25bb>
    cf58:	49 01 c4             	add    %rax,%r12
    cf5b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf60:	0f 84 0f 07 00 00    	je     d675 <f0+0x2cc5>
    cf66:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf6b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf72:	00 f0 3f 
    cf75:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    cf7c:	00 
    cf7d:	bf 01 00 00 00       	mov    $0x1,%edi
    cf82:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    cf89:	00 
    cf8a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    cf91:	00 
    cf92:	e8 39 8c ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    cf97:	48 8b 15 ba 6b 01 00 	mov    0x16bba(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    cf9e:	49 89 c5             	mov    %rax,%r13
    cfa1:	48 2b 05 88 6b 01 00 	sub    0x16b88(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    cfa8:	48 c1 e2 10          	shl    $0x10,%rdx
    cfac:	48 39 d0             	cmp    %rdx,%rax
    cfaf:	73 59                	jae    d00a <f0+0x265a>
    cfb1:	48 89 c2             	mov    %rax,%rdx
    cfb4:	48 c1 ea 10          	shr    $0x10,%rdx
    cfb8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfbc:	48 8b 15 b5 6b 01 00 	mov    0x16bb5(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    cfc3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfcb:	4d 85 e4             	test   %r12,%r12
    cfce:	74 3a                	je     d00a <f0+0x265a>
    cfd0:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd3:	80 f9 02             	cmp    $0x2,%cl
    cfd6:	0f 84 04 04 00 00    	je     d3e0 <f0+0x2a30>
    cfdc:	80 f9 01             	cmp    $0x1,%cl
    cfdf:	75 29                	jne    d00a <f0+0x265a>
    cfe1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe4:	0f b7 c0             	movzwl %ax,%eax
    cfe7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfea:	48 0f af c1          	imul   %rcx,%rax
    cfee:	48 c1 e8 20          	shr    $0x20,%rax
    cff2:	48 39 d0             	cmp    %rdx,%rax
    cff5:	73 13                	jae    d00a <f0+0x265a>
    cff7:	49 01 c4             	add    %rax,%r12
    cffa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfff:	0f 84 7d 06 00 00    	je     d682 <f0+0x2cd2>
    d005:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d00a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d011:	33 f3 bf 
    d014:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d01b:	00 
    d01c:	bf 01 00 00 00       	mov    $0x1,%edi
    d021:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d028:	00 
    d029:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d030:	00 
    d031:	e8 9a 8b ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    d036:	48 8b 15 1b 6b 01 00 	mov    0x16b1b(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    d03d:	49 89 c5             	mov    %rax,%r13
    d040:	48 2b 05 e9 6a 01 00 	sub    0x16ae9(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    d047:	48 c1 e2 10          	shl    $0x10,%rdx
    d04b:	48 39 d0             	cmp    %rdx,%rax
    d04e:	73 59                	jae    d0a9 <f0+0x26f9>
    d050:	48 89 c2             	mov    %rax,%rdx
    d053:	48 c1 ea 10          	shr    $0x10,%rdx
    d057:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d05b:	48 8b 15 16 6b 01 00 	mov    0x16b16(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    d062:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d066:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d06a:	4d 85 e4             	test   %r12,%r12
    d06d:	74 3a                	je     d0a9 <f0+0x26f9>
    d06f:	0f b6 0a             	movzbl (%rdx),%ecx
    d072:	80 f9 02             	cmp    $0x2,%cl
    d075:	0f 84 55 03 00 00    	je     d3d0 <f0+0x2a20>
    d07b:	80 f9 01             	cmp    $0x1,%cl
    d07e:	75 29                	jne    d0a9 <f0+0x26f9>
    d080:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d083:	0f b7 c0             	movzwl %ax,%eax
    d086:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d089:	48 0f af c1          	imul   %rcx,%rax
    d08d:	48 c1 e8 20          	shr    $0x20,%rax
    d091:	48 39 d0             	cmp    %rdx,%rax
    d094:	73 13                	jae    d0a9 <f0+0x26f9>
    d096:	49 01 c4             	add    %rax,%r12
    d099:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d09e:	0f 84 eb 05 00 00    	je     d68f <f0+0x2cdf>
    d0a4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0b0:	00 f0 3f 
    d0b3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d0ba:	00 
    d0bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d0c0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d0c7:	00 
    d0c8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d0cf:	00 
    d0d0:	e8 fb 8a ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    d0d5:	48 8b 15 7c 6a 01 00 	mov    0x16a7c(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    d0dc:	49 89 c5             	mov    %rax,%r13
    d0df:	48 2b 05 4a 6a 01 00 	sub    0x16a4a(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    d0e6:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ea:	48 39 d0             	cmp    %rdx,%rax
    d0ed:	73 59                	jae    d148 <f0+0x2798>
    d0ef:	48 89 c2             	mov    %rax,%rdx
    d0f2:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0fa:	48 8b 15 77 6a 01 00 	mov    0x16a77(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    d101:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d105:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d109:	4d 85 e4             	test   %r12,%r12
    d10c:	74 3a                	je     d148 <f0+0x2798>
    d10e:	0f b6 0a             	movzbl (%rdx),%ecx
    d111:	80 f9 02             	cmp    $0x2,%cl
    d114:	0f 84 a6 02 00 00    	je     d3c0 <f0+0x2a10>
    d11a:	80 f9 01             	cmp    $0x1,%cl
    d11d:	75 29                	jne    d148 <f0+0x2798>
    d11f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d122:	0f b7 c0             	movzwl %ax,%eax
    d125:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d128:	48 0f af c1          	imul   %rcx,%rax
    d12c:	48 c1 e8 20          	shr    $0x20,%rax
    d130:	48 39 d0             	cmp    %rdx,%rax
    d133:	73 13                	jae    d148 <f0+0x2798>
    d135:	49 01 c4             	add    %rax,%r12
    d138:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d13d:	0f 84 59 05 00 00    	je     d69c <f0+0x2cec>
    d143:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d148:	48 89 ee             	mov    %rbp,%rsi
    d14b:	bf 01 00 00 00       	mov    $0x1,%edi
    d150:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d157:	33 f3 bf 
    d15a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d161:	00 
    d162:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d169:	00 
    d16a:	e8 61 8a ff ff       	call   5bd0 <fwp_data.part.0.constprop.0>
    d16f:	48 8b 15 e2 69 01 00 	mov    0x169e2(%rip),%rdx        # 23b58 <fwp_heap+0x13d8>
    d176:	48 89 c5             	mov    %rax,%rbp
    d179:	48 2b 05 b0 69 01 00 	sub    0x169b0(%rip),%rax        # 23b30 <fwp_heap+0x13b0>
    d180:	48 c1 e2 10          	shl    $0x10,%rdx
    d184:	48 39 d0             	cmp    %rdx,%rax
    d187:	73 59                	jae    d1e2 <f0+0x2832>
    d189:	48 89 c2             	mov    %rax,%rdx
    d18c:	48 c1 ea 10          	shr    $0x10,%rdx
    d190:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d194:	48 8b 15 dd 69 01 00 	mov    0x169dd(%rip),%rdx        # 23b78 <fwp_heap+0x13f8>
    d19b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d19f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1a3:	4d 85 e4             	test   %r12,%r12
    d1a6:	74 3a                	je     d1e2 <f0+0x2832>
    d1a8:	0f b6 0a             	movzbl (%rdx),%ecx
    d1ab:	80 f9 02             	cmp    $0x2,%cl
    d1ae:	0f 84 fc 01 00 00    	je     d3b0 <f0+0x2a00>
    d1b4:	80 f9 01             	cmp    $0x1,%cl
    d1b7:	75 29                	jne    d1e2 <f0+0x2832>
    d1b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1bc:	0f b7 c0             	movzwl %ax,%eax
    d1bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c2:	48 0f af c1          	imul   %rcx,%rax
    d1c6:	48 c1 e8 20          	shr    $0x20,%rax
    d1ca:	48 39 d0             	cmp    %rdx,%rax
    d1cd:	73 13                	jae    d1e2 <f0+0x2832>
    d1cf:	49 01 c4             	add    %rax,%r12
    d1d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1d7:	0f 84 d1 02 00 00    	je     d4ae <f0+0x2afe>
    d1dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e2:	48 89 de             	mov    %rbx,%rsi
    d1e5:	48 89 ef             	mov    %rbp,%rdi
    d1e8:	e8 f3 be ff ff       	call   90e0 <fwp_hof0.constprop.0>
    d1ed:	48 89 ef             	mov    %rbp,%rdi
    d1f0:	e8 6b a3 ff ff       	call   7560 <fwp_drop0>
    d1f5:	48 89 df             	mov    %rbx,%rdi
    d1f8:	e8 63 a3 ff ff       	call   7560 <fwp_drop0>
    d1fd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d204:	00 
    d205:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d20c:	00 00 
    d20e:	0f 85 95 04 00 00    	jne    d6a9 <f0+0x2cf9>
    d214:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d21b:	31 c0                	xor    %eax,%eax
    d21d:	5b                   	pop    %rbx
    d21e:	5d                   	pop    %rbp
    d21f:	41 5c                	pop    %r12
    d221:	41 5d                	pop    %r13
    d223:	41 5e                	pop    %r14
    d225:	c3                   	ret
    d226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d22d:	00 00 00 
    d230:	4c 89 ef             	mov    %r13,%rdi
    d233:	e8 38 81 ff ff       	call   5370 <fwp_rc_forget_slot>
    d238:	e9 2c d8 ff ff       	jmp    aa69 <f0+0xb9>
    d23d:	0f 1f 00             	nopl   (%rax)
    d240:	66 85 c0             	test   %ax,%ax
    d243:	0f 85 ae f5 ff ff    	jne    c7f7 <f0+0x1e47>
    d249:	e9 99 f5 ff ff       	jmp    c7e7 <f0+0x1e37>
    d24e:	66 90                	xchg   %ax,%ax
    d250:	66 85 c0             	test   %ax,%ax
    d253:	0f 85 ff f4 ff ff    	jne    c758 <f0+0x1da8>
    d259:	e9 ea f4 ff ff       	jmp    c748 <f0+0x1d98>
    d25e:	66 90                	xchg   %ax,%ax
    d260:	66 85 c0             	test   %ax,%ax
    d263:	0f 85 50 f4 ff ff    	jne    c6b9 <f0+0x1d09>
    d269:	e9 3b f4 ff ff       	jmp    c6a9 <f0+0x1cf9>
    d26e:	66 90                	xchg   %ax,%ax
    d270:	66 85 c0             	test   %ax,%ax
    d273:	0f 85 a1 f3 ff ff    	jne    c61a <f0+0x1c6a>
    d279:	e9 8c f3 ff ff       	jmp    c60a <f0+0x1c5a>
    d27e:	66 90                	xchg   %ax,%ax
    d280:	66 85 c0             	test   %ax,%ax
    d283:	0f 85 f2 f2 ff ff    	jne    c57b <f0+0x1bcb>
    d289:	e9 dd f2 ff ff       	jmp    c56b <f0+0x1bbb>
    d28e:	66 90                	xchg   %ax,%ax
    d290:	66 85 c0             	test   %ax,%ax
    d293:	0f 85 43 f2 ff ff    	jne    c4dc <f0+0x1b2c>
    d299:	e9 2e f2 ff ff       	jmp    c4cc <f0+0x1b1c>
    d29e:	66 90                	xchg   %ax,%ax
    d2a0:	66 85 c0             	test   %ax,%ax
    d2a3:	0f 85 94 f1 ff ff    	jne    c43d <f0+0x1a8d>
    d2a9:	e9 7f f1 ff ff       	jmp    c42d <f0+0x1a7d>
    d2ae:	66 90                	xchg   %ax,%ax
    d2b0:	66 85 c0             	test   %ax,%ax
    d2b3:	0f 85 e5 f0 ff ff    	jne    c39e <f0+0x19ee>
    d2b9:	e9 d0 f0 ff ff       	jmp    c38e <f0+0x19de>
    d2be:	66 90                	xchg   %ax,%ax
    d2c0:	66 85 c0             	test   %ax,%ax
    d2c3:	0f 85 fd d9 ff ff    	jne    acc6 <f0+0x316>
    d2c9:	e9 e8 d9 ff ff       	jmp    acb6 <f0+0x306>
    d2ce:	66 90                	xchg   %ax,%ax
    d2d0:	66 85 c0             	test   %ax,%ax
    d2d3:	0f 85 57 d9 ff ff    	jne    ac30 <f0+0x280>
    d2d9:	e9 42 d9 ff ff       	jmp    ac20 <f0+0x270>
    d2de:	66 90                	xchg   %ax,%ax
    d2e0:	66 85 c0             	test   %ax,%ax
    d2e3:	0f 85 b1 d8 ff ff    	jne    ab9a <f0+0x1ea>
    d2e9:	e9 9c d8 ff ff       	jmp    ab8a <f0+0x1da>
    d2ee:	66 90                	xchg   %ax,%ax
    d2f0:	66 85 c0             	test   %ax,%ax
    d2f3:	0f 85 0e eb ff ff    	jne    be07 <f0+0x1457>
    d2f9:	e9 f9 ea ff ff       	jmp    bdf7 <f0+0x1447>
    d2fe:	66 90                	xchg   %ax,%ax
    d300:	66 85 c0             	test   %ax,%ax
    d303:	0f 85 5f ea ff ff    	jne    bd68 <f0+0x13b8>
    d309:	e9 4a ea ff ff       	jmp    bd58 <f0+0x13a8>
    d30e:	66 90                	xchg   %ax,%ax
    d310:	66 85 c0             	test   %ax,%ax
    d313:	0f 85 e2 da ff ff    	jne    adfb <f0+0x44b>
    d319:	e9 cd da ff ff       	jmp    adeb <f0+0x43b>
    d31e:	66 90                	xchg   %ax,%ax
    d320:	66 85 c0             	test   %ax,%ax
    d323:	0f 85 33 da ff ff    	jne    ad5c <f0+0x3ac>
    d329:	e9 1e da ff ff       	jmp    ad4c <f0+0x39c>
    d32e:	66 90                	xchg   %ax,%ax
    d330:	66 85 c0             	test   %ax,%ax
    d333:	0f 85 c6 ef ff ff    	jne    c2ff <f0+0x194f>
    d339:	e9 b1 ef ff ff       	jmp    c2ef <f0+0x193f>
    d33e:	66 90                	xchg   %ax,%ax
    d340:	66 85 c0             	test   %ax,%ax
    d343:	0f 85 17 ef ff ff    	jne    c260 <f0+0x18b0>
    d349:	e9 02 ef ff ff       	jmp    c250 <f0+0x18a0>
    d34e:	66 90                	xchg   %ax,%ax
    d350:	66 85 c0             	test   %ax,%ax
    d353:	0f 85 68 ee ff ff    	jne    c1c1 <f0+0x1811>
    d359:	e9 53 ee ff ff       	jmp    c1b1 <f0+0x1801>
    d35e:	66 90                	xchg   %ax,%ax
    d360:	66 85 c0             	test   %ax,%ax
    d363:	0f 85 b9 ed ff ff    	jne    c122 <f0+0x1772>
    d369:	e9 a4 ed ff ff       	jmp    c112 <f0+0x1762>
    d36e:	66 90                	xchg   %ax,%ax
    d370:	66 85 c0             	test   %ax,%ax
    d373:	0f 85 0a ed ff ff    	jne    c083 <f0+0x16d3>
    d379:	e9 f5 ec ff ff       	jmp    c073 <f0+0x16c3>
    d37e:	66 90                	xchg   %ax,%ax
    d380:	66 85 c0             	test   %ax,%ax
    d383:	0f 85 5b ec ff ff    	jne    bfe4 <f0+0x1634>
    d389:	e9 46 ec ff ff       	jmp    bfd4 <f0+0x1624>
    d38e:	66 90                	xchg   %ax,%ax
    d390:	66 85 c0             	test   %ax,%ax
    d393:	0f 85 ac eb ff ff    	jne    bf45 <f0+0x1595>
    d399:	e9 97 eb ff ff       	jmp    bf35 <f0+0x1585>
    d39e:	66 90                	xchg   %ax,%ax
    d3a0:	66 85 c0             	test   %ax,%ax
    d3a3:	0f 85 fd ea ff ff    	jne    bea6 <f0+0x14f6>
    d3a9:	e9 e8 ea ff ff       	jmp    be96 <f0+0x14e6>
    d3ae:	66 90                	xchg   %ax,%ax
    d3b0:	66 85 c0             	test   %ax,%ax
    d3b3:	0f 85 29 fe ff ff    	jne    d1e2 <f0+0x2832>
    d3b9:	e9 14 fe ff ff       	jmp    d1d2 <f0+0x2822>
    d3be:	66 90                	xchg   %ax,%ax
    d3c0:	66 85 c0             	test   %ax,%ax
    d3c3:	0f 85 7f fd ff ff    	jne    d148 <f0+0x2798>
    d3c9:	e9 6a fd ff ff       	jmp    d138 <f0+0x2788>
    d3ce:	66 90                	xchg   %ax,%ax
    d3d0:	66 85 c0             	test   %ax,%ax
    d3d3:	0f 85 d0 fc ff ff    	jne    d0a9 <f0+0x26f9>
    d3d9:	e9 bb fc ff ff       	jmp    d099 <f0+0x26e9>
    d3de:	66 90                	xchg   %ax,%ax
    d3e0:	66 85 c0             	test   %ax,%ax
    d3e3:	0f 85 21 fc ff ff    	jne    d00a <f0+0x265a>
    d3e9:	e9 0c fc ff ff       	jmp    cffa <f0+0x264a>
    d3ee:	66 90                	xchg   %ax,%ax
    d3f0:	66 85 c0             	test   %ax,%ax
    d3f3:	0f 85 72 fb ff ff    	jne    cf6b <f0+0x25bb>
    d3f9:	e9 5d fb ff ff       	jmp    cf5b <f0+0x25ab>
    d3fe:	66 90                	xchg   %ax,%ax
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 c3 fa ff ff    	jne    cecc <f0+0x251c>
    d409:	e9 ae fa ff ff       	jmp    cebc <f0+0x250c>
    d40e:	66 90                	xchg   %ax,%ax
    d410:	66 85 c0             	test   %ax,%ax
    d413:	0f 85 14 fa ff ff    	jne    ce2d <f0+0x247d>
    d419:	e9 ff f9 ff ff       	jmp    ce1d <f0+0x246d>
    d41e:	66 90                	xchg   %ax,%ax
    d420:	66 85 c0             	test   %ax,%ax
    d423:	0f 85 65 f9 ff ff    	jne    cd8e <f0+0x23de>
    d429:	e9 50 f9 ff ff       	jmp    cd7e <f0+0x23ce>
    d42e:	66 90                	xchg   %ax,%ax
    d430:	66 85 c0             	test   %ax,%ax
    d433:	0f 85 b6 f8 ff ff    	jne    ccef <f0+0x233f>
    d439:	e9 a1 f8 ff ff       	jmp    ccdf <f0+0x232f>
    d43e:	66 90                	xchg   %ax,%ax
    d440:	66 85 c0             	test   %ax,%ax
    d443:	0f 85 07 f8 ff ff    	jne    cc50 <f0+0x22a0>
    d449:	e9 f2 f7 ff ff       	jmp    cc40 <f0+0x2290>
    d44e:	66 90                	xchg   %ax,%ax
    d450:	66 85 c0             	test   %ax,%ax
    d453:	0f 85 58 f7 ff ff    	jne    cbb1 <f0+0x2201>
    d459:	e9 43 f7 ff ff       	jmp    cba1 <f0+0x21f1>
    d45e:	66 90                	xchg   %ax,%ax
    d460:	66 85 c0             	test   %ax,%ax
    d463:	0f 85 a9 f6 ff ff    	jne    cb12 <f0+0x2162>
    d469:	e9 94 f6 ff ff       	jmp    cb02 <f0+0x2152>
    d46e:	66 90                	xchg   %ax,%ax
    d470:	66 85 c0             	test   %ax,%ax
    d473:	0f 85 fa f5 ff ff    	jne    ca73 <f0+0x20c3>
    d479:	e9 e5 f5 ff ff       	jmp    ca63 <f0+0x20b3>
    d47e:	66 90                	xchg   %ax,%ax
    d480:	66 85 c0             	test   %ax,%ax
    d483:	0f 85 4b f5 ff ff    	jne    c9d4 <f0+0x2024>
    d489:	e9 36 f5 ff ff       	jmp    c9c4 <f0+0x2014>
    d48e:	66 90                	xchg   %ax,%ax
    d490:	66 85 c0             	test   %ax,%ax
    d493:	0f 85 9c f4 ff ff    	jne    c935 <f0+0x1f85>
    d499:	e9 87 f4 ff ff       	jmp    c925 <f0+0x1f75>
    d49e:	66 90                	xchg   %ax,%ax
    d4a0:	66 85 c0             	test   %ax,%ax
    d4a3:	0f 85 ed f3 ff ff    	jne    c896 <f0+0x1ee6>
    d4a9:	e9 d8 f3 ff ff       	jmp    c886 <f0+0x1ed6>
    d4ae:	4c 89 e7             	mov    %r12,%rdi
    d4b1:	e8 ba 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4b6:	e9 22 fd ff ff       	jmp    d1dd <f0+0x282d>
    d4bb:	4c 89 e7             	mov    %r12,%rdi
    d4be:	e8 ad 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4c3:	e9 cd d6 ff ff       	jmp    ab95 <f0+0x1e5>
    d4c8:	4c 89 e7             	mov    %r12,%rdi
    d4cb:	e8 a0 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4d0:	e9 56 d7 ff ff       	jmp    ac2b <f0+0x27b>
    d4d5:	4c 89 e7             	mov    %r12,%rdi
    d4d8:	e8 93 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4dd:	e9 df d7 ff ff       	jmp    acc1 <f0+0x311>
    d4e2:	4c 89 e7             	mov    %r12,%rdi
    d4e5:	e8 86 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4ea:	e9 68 d8 ff ff       	jmp    ad57 <f0+0x3a7>
    d4ef:	4c 89 e7             	mov    %r12,%rdi
    d4f2:	e8 79 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d4f7:	e9 fa d8 ff ff       	jmp    adf6 <f0+0x446>
    d4fc:	4c 89 e7             	mov    %r12,%rdi
    d4ff:	e8 6c 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d504:	e9 5a e8 ff ff       	jmp    bd63 <f0+0x13b3>
    d509:	4c 89 e7             	mov    %r12,%rdi
    d50c:	e8 5f 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d511:	e9 ec e8 ff ff       	jmp    be02 <f0+0x1452>
    d516:	4c 89 e7             	mov    %r12,%rdi
    d519:	e8 52 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d51e:	e9 7e e9 ff ff       	jmp    bea1 <f0+0x14f1>
    d523:	4c 89 e7             	mov    %r12,%rdi
    d526:	e8 45 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d52b:	e9 10 ea ff ff       	jmp    bf40 <f0+0x1590>
    d530:	4c 89 e7             	mov    %r12,%rdi
    d533:	e8 38 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d538:	e9 a2 ea ff ff       	jmp    bfdf <f0+0x162f>
    d53d:	4c 89 e7             	mov    %r12,%rdi
    d540:	e8 2b 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d545:	e9 34 eb ff ff       	jmp    c07e <f0+0x16ce>
    d54a:	4c 89 e7             	mov    %r12,%rdi
    d54d:	e8 1e 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d552:	e9 c6 eb ff ff       	jmp    c11d <f0+0x176d>
    d557:	4c 89 e7             	mov    %r12,%rdi
    d55a:	e8 11 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d55f:	e9 58 ec ff ff       	jmp    c1bc <f0+0x180c>
    d564:	4c 89 e7             	mov    %r12,%rdi
    d567:	e8 04 7e ff ff       	call   5370 <fwp_rc_forget_slot>
    d56c:	e9 ea ec ff ff       	jmp    c25b <f0+0x18ab>
    d571:	4c 89 e7             	mov    %r12,%rdi
    d574:	e8 f7 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d579:	e9 7c ed ff ff       	jmp    c2fa <f0+0x194a>
    d57e:	4c 89 e7             	mov    %r12,%rdi
    d581:	e8 ea 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d586:	e9 0e ee ff ff       	jmp    c399 <f0+0x19e9>
    d58b:	4c 89 e7             	mov    %r12,%rdi
    d58e:	e8 dd 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d593:	e9 a0 ee ff ff       	jmp    c438 <f0+0x1a88>
    d598:	4c 89 e7             	mov    %r12,%rdi
    d59b:	e8 d0 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5a0:	e9 32 ef ff ff       	jmp    c4d7 <f0+0x1b27>
    d5a5:	4c 89 e7             	mov    %r12,%rdi
    d5a8:	e8 c3 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5ad:	e9 c4 ef ff ff       	jmp    c576 <f0+0x1bc6>
    d5b2:	4c 89 e7             	mov    %r12,%rdi
    d5b5:	e8 b6 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5ba:	e9 56 f0 ff ff       	jmp    c615 <f0+0x1c65>
    d5bf:	4c 89 e7             	mov    %r12,%rdi
    d5c2:	e8 a9 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5c7:	e9 e8 f0 ff ff       	jmp    c6b4 <f0+0x1d04>
    d5cc:	4c 89 e7             	mov    %r12,%rdi
    d5cf:	e8 9c 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5d4:	e9 7a f1 ff ff       	jmp    c753 <f0+0x1da3>
    d5d9:	4c 89 e7             	mov    %r12,%rdi
    d5dc:	e8 8f 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5e1:	e9 0c f2 ff ff       	jmp    c7f2 <f0+0x1e42>
    d5e6:	4c 89 e7             	mov    %r12,%rdi
    d5e9:	e8 82 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5ee:	e9 9e f2 ff ff       	jmp    c891 <f0+0x1ee1>
    d5f3:	4c 89 e7             	mov    %r12,%rdi
    d5f6:	e8 75 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d5fb:	e9 30 f3 ff ff       	jmp    c930 <f0+0x1f80>
    d600:	4c 89 e7             	mov    %r12,%rdi
    d603:	e8 68 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d608:	e9 c2 f3 ff ff       	jmp    c9cf <f0+0x201f>
    d60d:	4c 89 e7             	mov    %r12,%rdi
    d610:	e8 5b 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d615:	e9 54 f4 ff ff       	jmp    ca6e <f0+0x20be>
    d61a:	4c 89 e7             	mov    %r12,%rdi
    d61d:	e8 4e 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d622:	e9 e6 f4 ff ff       	jmp    cb0d <f0+0x215d>
    d627:	4c 89 e7             	mov    %r12,%rdi
    d62a:	e8 41 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d62f:	e9 78 f5 ff ff       	jmp    cbac <f0+0x21fc>
    d634:	4c 89 e7             	mov    %r12,%rdi
    d637:	e8 34 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d63c:	e9 0a f6 ff ff       	jmp    cc4b <f0+0x229b>
    d641:	4c 89 e7             	mov    %r12,%rdi
    d644:	e8 27 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d649:	e9 9c f6 ff ff       	jmp    ccea <f0+0x233a>
    d64e:	4c 89 e7             	mov    %r12,%rdi
    d651:	e8 1a 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d656:	e9 2e f7 ff ff       	jmp    cd89 <f0+0x23d9>
    d65b:	4c 89 e7             	mov    %r12,%rdi
    d65e:	e8 0d 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d663:	e9 c0 f7 ff ff       	jmp    ce28 <f0+0x2478>
    d668:	4c 89 e7             	mov    %r12,%rdi
    d66b:	e8 00 7d ff ff       	call   5370 <fwp_rc_forget_slot>
    d670:	e9 52 f8 ff ff       	jmp    cec7 <f0+0x2517>
    d675:	4c 89 e7             	mov    %r12,%rdi
    d678:	e8 f3 7c ff ff       	call   5370 <fwp_rc_forget_slot>
    d67d:	e9 e4 f8 ff ff       	jmp    cf66 <f0+0x25b6>
    d682:	4c 89 e7             	mov    %r12,%rdi
    d685:	e8 e6 7c ff ff       	call   5370 <fwp_rc_forget_slot>
    d68a:	e9 76 f9 ff ff       	jmp    d005 <f0+0x2655>
    d68f:	4c 89 e7             	mov    %r12,%rdi
    d692:	e8 d9 7c ff ff       	call   5370 <fwp_rc_forget_slot>
    d697:	e9 08 fa ff ff       	jmp    d0a4 <f0+0x26f4>
    d69c:	4c 89 e7             	mov    %r12,%rdi
    d69f:	e8 cc 7c ff ff       	call   5370 <fwp_rc_forget_slot>
    d6a4:	e9 9a fa ff ff       	jmp    d143 <f0+0x2793>
    d6a9:	e8 b2 5d ff ff       	call   3460 <__stack_chk_fail@plt>
    d6ae:	66 90                	xchg   %ax,%ax

000000000000d6b0 <fwp_main_thread>:
    d6b0:	f3 0f 1e fa          	endbr64
    d6b4:	41 54                	push   %r12
    d6b6:	55                   	push   %rbp
    d6b7:	53                   	push   %rbx
    d6b8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d6bf:	8b 0d 5f 64 01 00    	mov    0x1645f(%rip),%ecx        # 23b24 <fwp_heap+0x13a4>
    d6c5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d6cc:	00 00 
    d6ce:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d6d5:	00 
    d6d6:	31 c0                	xor    %eax,%eax
    d6d8:	85 c9                	test   %ecx,%ecx
    d6da:	0f 84 68 06 00 00    	je     dd48 <fwp_main_thread+0x698>
    d6e0:	8b 15 42 64 01 00    	mov    0x16442(%rip),%edx        # 23b28 <fwp_heap+0x13a8>
    d6e6:	85 d2                	test   %edx,%edx
    d6e8:	0f 85 42 06 00 00    	jne    dd30 <fwp_main_thread+0x680>
    d6ee:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d6f3:	31 f6                	xor    %esi,%esi
    d6f5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d6fa:	48 c7 05 13 4a 01 00 	movq   $0x40000000,0x14a13(%rip)        # 22118 <fwp_main_stack_size>
    d701:	00 00 00 40 
    d705:	48 89 05 14 4a 01 00 	mov    %rax,0x14a14(%rip)        # 22120 <fwp_main_stack_top>
    d70c:	48 8d 05 8d 49 00 00 	lea    0x498d(%rip),%rax        # 120a0 <alt.9>
    d713:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d718:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d71f:	01 00 
    d721:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d728:	00 
    d729:	e8 92 5f ff ff       	call   36c0 <sigaltstack@plt>
    d72e:	85 c0                	test   %eax,%eax
    d730:	0f 85 4a 06 00 00    	jne    dd80 <fwp_main_thread+0x6d0>
    d736:	31 c0                	xor    %eax,%eax
    d738:	b9 12 00 00 00       	mov    $0x12,%ecx
    d73d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d742:	f3 48 ab             	rep stos %rax,(%rdi)
    d745:	48 8d 05 a4 65 ff ff 	lea    -0x9a5c(%rip),%rax        # 3cf0 <fwp_segv>
    d74c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d751:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d758:	04 00 00 08 
    d75c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d761:	e8 1a 5e ff ff       	call   3580 <sigemptyset@plt>
    d766:	85 c0                	test   %eax,%eax
    d768:	0f 85 12 06 00 00    	jne    dd80 <fwp_main_thread+0x6d0>
    d76e:	31 d2                	xor    %edx,%edx
    d770:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d775:	bf 0b 00 00 00       	mov    $0xb,%edi
    d77a:	e8 81 5c ff ff       	call   3400 <sigaction@plt>
    d77f:	85 c0                	test   %eax,%eax
    d781:	0f 85 f9 05 00 00    	jne    dd80 <fwp_main_thread+0x6d0>
    d787:	31 d2                	xor    %edx,%edx
    d789:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d78e:	bf 07 00 00 00       	mov    $0x7,%edi
    d793:	e8 68 5c ff ff       	call   3400 <sigaction@plt>
    d798:	85 c0                	test   %eax,%eax
    d79a:	0f 85 e0 05 00 00    	jne    dd80 <fwp_main_thread+0x6d0>
    d7a0:	8b 05 e2 48 00 00    	mov    0x48e2(%rip),%eax        # 12088 <st.7>
    d7a6:	85 c0                	test   %eax,%eax
    d7a8:	0f 84 62 05 00 00    	je     dd10 <fwp_main_thread+0x660>
    d7ae:	48 8b 2d ab 4f 01 00 	mov    0x14fab(%rip),%rbp        # 22760 <fwp_cur>
    d7b5:	48 85 ed             	test   %rbp,%rbp
    d7b8:	0f 84 72 03 00 00    	je     db30 <fwp_main_thread+0x480>
    d7be:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d7c3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d7c7:	48 89 eb             	mov    %rbp,%rbx
    d7ca:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d7cf:	0f 84 41 01 00 00    	je     d916 <fwp_main_thread+0x266>
    d7d5:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d7da:	0f 84 80 02 00 00    	je     da60 <fwp_main_thread+0x3b0>
    d7e0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d7e4:	0f 84 66 02 00 00    	je     da50 <fwp_main_thread+0x3a0>
    d7ea:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d7ee:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d7f2:	0f 85 e8 02 00 00    	jne    dae0 <fwp_main_thread+0x430>
    d7f8:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d7fc:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d803:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d807:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d80e:	00 00 00 00 
    d812:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d819:	48 85 d2             	test   %rdx,%rdx
    d81c:	74 07                	je     d825 <fwp_main_thread+0x175>
    d81e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d825:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d829:	48 85 c0             	test   %rax,%rax
    d82c:	74 34                	je     d862 <fwp_main_thread+0x1b2>
    d82e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    d832:	48 8b 05 ff 4e 01 00 	mov    0x14eff(%rip),%rax        # 22738 <fwp_timers>
    d839:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    d83d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    d844:	00 00 00 00 
    d848:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    d84f:	48 85 c0             	test   %rax,%rax
    d852:	74 07                	je     d85b <fwp_main_thread+0x1ab>
    d854:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    d85b:	48 89 1d d6 4e 01 00 	mov    %rbx,0x14ed6(%rip)        # 22738 <fwp_timers>
    d862:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    d866:	e8 c5 98 ff ff       	call   7130 <fwp_block>
    d86b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    d872:	48 85 c9             	test   %rcx,%rcx
    d875:	74 47                	je     d8be <fwp_main_thread+0x20e>
    d877:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    d87e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d885:	48 85 d2             	test   %rdx,%rdx
    d888:	0f 84 92 02 00 00    	je     db20 <fwp_main_thread+0x470>
    d88e:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    d895:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d89c:	48 85 c0             	test   %rax,%rax
    d89f:	74 07                	je     d8a8 <fwp_main_thread+0x1f8>
    d8a1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    d8a8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    d8af:	00 00 00 00 
    d8b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    d8b7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    d8be:	48 8b 0d 9b 4e 01 00 	mov    0x14e9b(%rip),%rcx        # 22760 <fwp_cur>
    d8c5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    d8c9:	0f 84 01 02 00 00    	je     dad0 <fwp_main_thread+0x420>
    d8cf:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    d8d6:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    d8dd:	48 85 d2             	test   %rdx,%rdx
    d8e0:	0f 84 fa 03 00 00    	je     dce0 <fwp_main_thread+0x630>
    d8e6:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    d8ed:	48 85 c0             	test   %rax,%rax
    d8f0:	74 07                	je     d8f9 <fwp_main_thread+0x249>
    d8f2:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    d8f9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    d8fd:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    d901:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    d908:	48 89 cb             	mov    %rcx,%rbx
    d90b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d910:	0f 85 bf fe ff ff    	jne    d7d5 <fwp_main_thread+0x125>
    d916:	48 83 3d da 6a 01 00 	cmpq   $0x0,0x16ada(%rip)        # 243f8 <fwp_state_len>
    d91d:	00 
    d91e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    d922:	0f 84 ba 00 00 00    	je     d9e2 <fwp_main_thread+0x332>
    d928:	48 39 1d 29 4e 01 00 	cmp    %rbx,0x14e29(%rip)        # 22758 <fwp_root>
    d92f:	c7 05 67 47 01 00 00 	movl   $0x0,0x14767(%rip)        # 220a0 <fwp_exit_code>
    d936:	00 00 00 
    d939:	0f 85 5f 04 00 00    	jne    dd9e <fwp_main_thread+0x6ee>
    d93f:	48 85 db             	test   %rbx,%rbx
    d942:	0f 84 0e 02 00 00    	je     db56 <fwp_main_thread+0x4a6>
    d948:	48 8b 15 d9 4d 01 00 	mov    0x14dd9(%rip),%rdx        # 22728 <fwp_tasks_active>
    d94f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    d953:	48 85 d2             	test   %rdx,%rdx
    d956:	0f 84 fa 01 00 00    	je     db56 <fwp_main_thread+0x4a6>
    d95c:	0f 1f 40 00          	nopl   0x0(%rax)
    d960:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    d964:	75 08                	jne    d96e <fwp_main_thread+0x2be>
    d966:	48 89 d7             	mov    %rdx,%rdi
    d969:	e8 42 67 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    d96e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    d975:	48 85 d2             	test   %rdx,%rdx
    d978:	75 e6                	jne    d960 <fwp_main_thread+0x2b0>
    d97a:	eb 31                	jmp    d9ad <fwp_main_thread+0x2fd>
    d97c:	0f 1f 40 00          	nopl   0x0(%rax)
    d980:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    d987:	48 89 1d b2 4d 01 00 	mov    %rbx,0x14db2(%rip)        # 22740 <fwp_ready_tail>
    d98e:	e8 9d 97 ff ff       	call   7130 <fwp_block>
    d993:	e8 88 95 ff ff       	call   6f20 <fwp_free_zombie>
    d998:	48 83 3d 88 4d 01 00 	cmpq   $0x0,0x14d88(%rip)        # 22728 <fwp_tasks_active>
    d99f:	00 
    d9a0:	0f 84 b0 01 00 00    	je     db56 <fwp_main_thread+0x4a6>
    d9a6:	48 8b 1d ab 4d 01 00 	mov    0x14dab(%rip),%rbx        # 22758 <fwp_root>
    d9ad:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    d9b1:	75 db                	jne    d98e <fwp_main_thread+0x2de>
    d9b3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    d9b7:	75 d5                	jne    d98e <fwp_main_thread+0x2de>
    d9b9:	48 8b 05 80 4d 01 00 	mov    0x14d80(%rip),%rax        # 22740 <fwp_ready_tail>
    d9c0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    d9c4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    d9cb:	00 00 00 00 
    d9cf:	48 85 c0             	test   %rax,%rax
    d9d2:	75 ac                	jne    d980 <fwp_main_thread+0x2d0>
    d9d4:	48 89 1d 6d 4d 01 00 	mov    %rbx,0x14d6d(%rip)        # 22748 <fwp_ready_head>
    d9db:	eb aa                	jmp    d987 <fwp_main_thread+0x2d7>
    d9dd:	0f 1f 00             	nopl   (%rax)
    d9e0:	31 db                	xor    %ebx,%ebx
    d9e2:	48 83 3d fe 69 01 00 	cmpq   $0x0,0x169fe(%rip)        # 243e8 <fwp_state_owners>
    d9e9:	00 
    d9ea:	0f 85 38 ff ff ff    	jne    d928 <fwp_main_thread+0x278>
    d9f0:	48 8b 3d 09 6a 01 00 	mov    0x16a09(%rip),%rdi        # 24400 <fwp_state>
    d9f7:	e8 b4 7b ff ff       	call   55b0 <fwp_mem_free>
    d9fc:	48 c7 05 f9 69 01 00 	movq   $0x0,0x169f9(%rip)        # 24400 <fwp_state>
    da03:	00 00 00 00 
    da07:	48 c7 05 de 69 01 00 	movq   $0x0,0x169de(%rip)        # 243f0 <fwp_state_cap>
    da0e:	00 00 00 00 
    da12:	48 85 db             	test   %rbx,%rbx
    da15:	0f 84 46 03 00 00    	je     dd61 <fwp_main_thread+0x6b1>
    da1b:	48 39 1d 36 4d 01 00 	cmp    %rbx,0x14d36(%rip)        # 22758 <fwp_root>
    da22:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    da29:	00 00 00 00 
    da2d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    da34:	00 00 00 00 
    da38:	c7 05 5e 46 01 00 00 	movl   $0x0,0x1465e(%rip)        # 220a0 <fwp_exit_code>
    da3f:	00 00 00 
    da42:	0f 84 00 ff ff ff    	je     d948 <fwp_main_thread+0x298>
    da48:	e9 08 5d ff ff       	jmp    3755 <fwp_main_thread.cold>
    da4d:	0f 1f 00             	nopl   (%rax)
    da50:	e8 bb 68 ff ff       	call   4310 <fwp_now_ns>
    da55:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    da59:	0f 8d 91 02 00 00    	jge    dcf0 <fwp_main_thread+0x640>
    da5f:	90                   	nop
    da60:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    da64:	0f 85 80 fd ff ff    	jne    d7ea <fwp_main_thread+0x13a>
    da6a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    da6e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    da72:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    da76:	0f 85 80 fd ff ff    	jne    d7fc <fwp_main_thread+0x14c>
    da7c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    da80:	48 85 c9             	test   %rcx,%rcx
    da83:	0f 84 73 fd ff ff    	je     d7fc <fwp_main_thread+0x14c>
    da89:	48 85 c0             	test   %rax,%rax
    da8c:	0f 84 ff 02 00 00    	je     dd91 <fwp_main_thread+0x6e1>
    da92:	48 39 c8             	cmp    %rcx,%rax
    da95:	48 0f 4f c1          	cmovg  %rcx,%rax
    da99:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    daa0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    daa4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    daab:	00 00 00 00 
    daaf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dab6:	48 85 d2             	test   %rdx,%rdx
    dab9:	74 07                	je     dac2 <fwp_main_thread+0x412>
    dabb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dac2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dac6:	e9 63 fd ff ff       	jmp    d82e <fwp_main_thread+0x17e>
    dacb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    dad0:	48 89 cb             	mov    %rcx,%rbx
    dad3:	e9 f2 fc ff ff       	jmp    d7ca <fwp_main_thread+0x11a>
    dad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dadf:	00 
    dae0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    dae4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    daeb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    daf2:	00 00 00 00 
    daf6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    dafd:	48 85 c0             	test   %rax,%rax
    db00:	0f 84 52 02 00 00    	je     dd58 <fwp_main_thread+0x6a8>
    db06:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    db0d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    db11:	e9 4c fd ff ff       	jmp    d862 <fwp_main_thread+0x1b2>
    db16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    db1d:	00 00 00 
    db20:	48 89 01             	mov    %rax,(%rcx)
    db23:	e9 74 fd ff ff       	jmp    d89c <fwp_main_thread+0x1ec>
    db28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    db2f:	00 
    db30:	48 83 3d c0 68 01 00 	cmpq   $0x0,0x168c0(%rip)        # 243f8 <fwp_state_len>
    db37:	00 
    db38:	0f 84 a2 fe ff ff    	je     d9e0 <fwp_main_thread+0x330>
    db3e:	48 83 3d 12 4c 01 00 	cmpq   $0x0,0x14c12(%rip)        # 22758 <fwp_root>
    db45:	00 
    db46:	c7 05 50 45 01 00 00 	movl   $0x0,0x14550(%rip)        # 220a0 <fwp_exit_code>
    db4d:	00 00 00 
    db50:	0f 85 43 02 00 00    	jne    dd99 <fwp_main_thread+0x6e9>
    db56:	e8 c5 93 ff ff       	call   6f20 <fwp_free_zombie>
    db5b:	48 83 3d e5 4b 01 00 	cmpq   $0x0,0x14be5(%rip)        # 22748 <fwp_ready_head>
    db62:	00 
    db63:	0f 85 ec 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db69:	48 83 3d c7 4b 01 00 	cmpq   $0x0,0x14bc7(%rip)        # 22738 <fwp_timers>
    db70:	00 
    db71:	0f 85 de 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db77:	8b 1d af 45 01 00    	mov    0x145af(%rip),%ebx        # 2212c <fwp_stack_pool_n>
    db7d:	85 db                	test   %ebx,%ebx
    db7f:	74 36                	je     dbb7 <fwp_main_thread+0x507>
    db81:	83 eb 01             	sub    $0x1,%ebx
    db84:	48 8d 05 b5 45 01 00 	lea    0x145b5(%rip),%rax        # 22140 <fwp_stack_pool>
    db8b:	48 63 d3             	movslq %ebx,%rdx
    db8e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    db92:	eb 07                	jmp    db9b <fwp_main_thread+0x4eb>
    db94:	0f 1f 40 00          	nopl   0x0(%rax)
    db98:	83 eb 01             	sub    $0x1,%ebx
    db9b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    db9f:	be 00 00 00 10       	mov    $0x10000000,%esi
    dba4:	89 1d 82 45 01 00    	mov    %ebx,0x14582(%rip)        # 2212c <fwp_stack_pool_n>
    dbaa:	48 83 ed 08          	sub    $0x8,%rbp
    dbae:	e8 2d 5a ff ff       	call   35e0 <munmap@plt>
    dbb3:	85 db                	test   %ebx,%ebx
    dbb5:	75 e1                	jne    db98 <fwp_main_thread+0x4e8>
    dbb7:	8b 3d 5b 44 00 00    	mov    0x445b(%rip),%edi        # 12018 <fwp_epfd>
    dbbd:	85 ff                	test   %edi,%edi
    dbbf:	78 05                	js     dbc6 <fwp_main_thread+0x516>
    dbc1:	e8 0a 59 ff ff       	call   34d0 <close@plt>
    dbc6:	4c 8b 25 73 47 01 00 	mov    0x14773(%rip),%r12        # 22340 <fwp_nfdws>
    dbcd:	48 8b 2d 74 47 01 00 	mov    0x14774(%rip),%rbp        # 22348 <fwp_fdws>
    dbd4:	31 db                	xor    %ebx,%ebx
    dbd6:	c7 05 38 44 00 00 ff 	movl   $0xffffffff,0x4438(%rip)        # 12018 <fwp_epfd>
    dbdd:	ff ff ff 
    dbe0:	4d 85 e4             	test   %r12,%r12
    dbe3:	74 38                	je     dc1d <fwp_main_thread+0x56d>
    dbe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    dbec:	00 00 00 00 
    dbf0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    dbf5:	48 85 ff             	test   %rdi,%rdi
    dbf8:	74 1a                	je     dc14 <fwp_main_thread+0x564>
    dbfa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    dbfe:	0f 85 51 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dc04:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    dc09:	0f 85 46 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dc0f:	e8 9c 79 ff ff       	call   55b0 <fwp_mem_free>
    dc14:	48 83 c3 01          	add    $0x1,%rbx
    dc18:	4c 39 e3             	cmp    %r12,%rbx
    dc1b:	75 d3                	jne    dbf0 <fwp_main_thread+0x540>
    dc1d:	48 89 ef             	mov    %rbp,%rdi
    dc20:	e8 8b 79 ff ff       	call   55b0 <fwp_mem_free>
    dc25:	48 8b 15 2c 4b 01 00 	mov    0x14b2c(%rip),%rdx        # 22758 <fwp_root>
    dc2c:	48 c7 05 11 47 01 00 	movq   $0x0,0x14711(%rip)        # 22348 <fwp_fdws>
    dc33:	00 00 00 00 
    dc37:	48 c7 05 fe 46 01 00 	movq   $0x0,0x146fe(%rip)        # 22340 <fwp_nfdws>
    dc3e:	00 00 00 00 
    dc42:	48 85 d2             	test   %rdx,%rdx
    dc45:	74 4e                	je     dc95 <fwp_main_thread+0x5e5>
    dc47:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    dc4c:	0f 85 03 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dc52:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    dc59:	00 
    dc5a:	0f 85 f5 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dc60:	48 83 3d 90 67 01 00 	cmpq   $0x0,0x16790(%rip)        # 243f8 <fwp_state_len>
    dc67:	00 
    dc68:	0f 85 e7 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dc6e:	48 83 3d 72 67 01 00 	cmpq   $0x0,0x16772(%rip)        # 243e8 <fwp_state_owners>
    dc75:	00 
    dc76:	0f 85 d9 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dc7c:	b9 79 00 00 00       	mov    $0x79,%ecx
    dc81:	31 c0                	xor    %eax,%eax
    dc83:	48 8d 3d d6 46 01 00 	lea    0x146d6(%rip),%rdi        # 22360 <fwp_root_context>
    dc8a:	f3 48 ab             	rep stos %rax,(%rdi)
    dc8d:	48 89 d7             	mov    %rdx,%rdi
    dc90:	e8 1b 79 ff ff       	call   55b0 <fwp_mem_free>
    dc95:	48 8b 3d 84 43 00 00 	mov    0x4384(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    dc9c:	48 c7 05 b9 4a 01 00 	movq   $0x0,0x14ab9(%rip)        # 22760 <fwp_cur>
    dca3:	00 00 00 00 
    dca7:	48 c7 05 a6 4a 01 00 	movq   $0x0,0x14aa6(%rip)        # 22758 <fwp_root>
    dcae:	00 00 00 00 
    dcb2:	e8 09 59 ff ff       	call   35c0 <fflush@plt>
    dcb7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    dcbe:	00 
    dcbf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dcc6:	00 00 
    dcc8:	0f 85 be 00 00 00    	jne    dd8c <fwp_main_thread+0x6dc>
    dcce:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    dcd5:	31 c0                	xor    %eax,%eax
    dcd7:	5b                   	pop    %rbx
    dcd8:	5d                   	pop    %rbp
    dcd9:	41 5c                	pop    %r12
    dcdb:	c3                   	ret
    dcdc:	0f 1f 40 00          	nopl   0x0(%rax)
    dce0:	48 89 05 51 4a 01 00 	mov    %rax,0x14a51(%rip)        # 22738 <fwp_timers>
    dce7:	e9 01 fc ff ff       	jmp    d8ed <fwp_main_thread+0x23d>
    dcec:	0f 1f 40 00          	nopl   0x0(%rax)
    dcf0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    dcf4:	0f 85 66 fd ff ff    	jne    da60 <fwp_main_thread+0x3b0>
    dcfa:	48 89 ef             	mov    %rbp,%rdi
    dcfd:	e8 ae 63 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    dd02:	e9 59 fd ff ff       	jmp    da60 <fwp_main_thread+0x3b0>
    dd07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    dd0e:	00 00 
    dd10:	e8 9b cc ff ff       	call   a9b0 <f0>
    dd15:	48 c7 05 60 43 00 00 	movq   $0x0,0x4360(%rip)        # 12080 <v.6>
    dd1c:	00 00 00 00 
    dd20:	c7 05 5e 43 00 00 01 	movl   $0x1,0x435e(%rip)        # 12088 <st.7>
    dd27:	00 00 00 
    dd2a:	e9 7f fa ff ff       	jmp    d7ae <fwp_main_thread+0xfe>
    dd2f:	90                   	nop
    dd30:	48 8d 3d e9 6c ff ff 	lea    -0x9317(%rip),%rdi        # 4a20 <fwp_heap_report>
    dd37:	e8 84 02 00 00       	call   dfc0 <atexit>
    dd3c:	e9 ad f9 ff ff       	jmp    d6ee <fwp_main_thread+0x3e>
    dd41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    dd48:	e8 e3 6d ff ff       	call   4b30 <fwp_heap_init>
    dd4d:	e9 8e f9 ff ff       	jmp    d6e0 <fwp_main_thread+0x30>
    dd52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dd58:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dd5c:	e9 01 fb ff ff       	jmp    d862 <fwp_main_thread+0x1b2>
    dd61:	48 83 3d ef 49 01 00 	cmpq   $0x0,0x149ef(%rip)        # 22758 <fwp_root>
    dd68:	00 
    dd69:	c7 05 2d 43 01 00 00 	movl   $0x0,0x1432d(%rip)        # 220a0 <fwp_exit_code>
    dd70:	00 00 00 
    dd73:	0f 84 dd fd ff ff    	je     db56 <fwp_main_thread+0x4a6>
    dd79:	e9 d7 59 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dd7e:	66 90                	xchg   %ax,%ax
    dd80:	48 8d 3d 71 0b 00 00 	lea    0xb71(%rip),%rdi        # e8f8 <_IO_stdin_used+0x8f8>
    dd87:	e8 14 64 ff ff       	call   41a0 <fwp_trap>
    dd8c:	e8 cf 56 ff ff       	call   3460 <__stack_chk_fail@plt>
    dd91:	48 89 c8             	mov    %rcx,%rax
    dd94:	e9 00 fd ff ff       	jmp    da99 <fwp_main_thread+0x3e9>
    dd99:	e9 b7 59 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dd9e:	e9 b2 59 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dda3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ddaa:	00 00 00 
    ddad:	0f 1f 00             	nopl   (%rax)

000000000000ddb0 <__divmodti4>:
    ddb0:	f3 0f 1e fa          	endbr64
    ddb4:	55                   	push   %rbp
    ddb5:	49 89 f1             	mov    %rsi,%r9
    ddb8:	49 89 d2             	mov    %rdx,%r10
    ddbb:	48 89 fe             	mov    %rdi,%rsi
    ddbe:	49 89 cb             	mov    %rcx,%r11
    ddc1:	48 89 e5             	mov    %rsp,%rbp
    ddc4:	41 57                	push   %r15
    ddc6:	41 56                	push   %r14
    ddc8:	41 55                	push   %r13
    ddca:	41 54                	push   %r12
    ddcc:	53                   	push   %rbx
    ddcd:	4c 89 c3             	mov    %r8,%rbx
    ddd0:	45 31 c0             	xor    %r8d,%r8d
    ddd3:	4d 85 c9             	test   %r9,%r9
    ddd6:	79 12                	jns    ddea <__divmodti4+0x3a>
    ddd8:	31 ff                	xor    %edi,%edi
    ddda:	48 f7 de             	neg    %rsi
    dddd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    dde4:	4c 19 cf             	sbb    %r9,%rdi
    dde7:	49 89 f9             	mov    %rdi,%r9
    ddea:	4c 89 d8             	mov    %r11,%rax
    dded:	4d 85 db             	test   %r11,%r11
    ddf0:	0f 88 1a 01 00 00    	js     df10 <__divmodti4+0x160>
    ddf6:	4c 89 d9             	mov    %r11,%rcx
    ddf9:	49 89 f3             	mov    %rsi,%r11
    ddfc:	75 62                	jne    de60 <__divmodti4+0xb0>
    ddfe:	4d 89 c4             	mov    %r8,%r12
    de01:	4d 39 d1             	cmp    %r10,%r9
    de04:	0f 83 46 01 00 00    	jae    df50 <__divmodti4+0x1a0>
    de0a:	4c 89 d8             	mov    %r11,%rax
    de0d:	4c 89 ca             	mov    %r9,%rdx
    de10:	49 f7 f2             	div    %r10
    de13:	49 89 c3             	mov    %rax,%r11
    de16:	31 c0                	xor    %eax,%eax
    de18:	48 89 d6             	mov    %rdx,%rsi
    de1b:	31 ff                	xor    %edi,%edi
    de1d:	4c 89 d9             	mov    %r11,%rcx
    de20:	48 89 c2             	mov    %rax,%rdx
    de23:	48 89 c8             	mov    %rcx,%rax
    de26:	4d 85 e4             	test   %r12,%r12
    de29:	74 0a                	je     de35 <__divmodti4+0x85>
    de2b:	48 f7 d8             	neg    %rax
    de2e:	48 83 d2 00          	adc    $0x0,%rdx
    de32:	48 f7 da             	neg    %rdx
    de35:	4d 85 c0             	test   %r8,%r8
    de38:	74 0a                	je     de44 <__divmodti4+0x94>
    de3a:	48 f7 de             	neg    %rsi
    de3d:	48 83 d7 00          	adc    $0x0,%rdi
    de41:	48 f7 df             	neg    %rdi
    de44:	48 89 33             	mov    %rsi,(%rbx)
    de47:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    de4b:	5b                   	pop    %rbx
    de4c:	41 5c                	pop    %r12
    de4e:	41 5d                	pop    %r13
    de50:	41 5e                	pop    %r14
    de52:	41 5f                	pop    %r15
    de54:	5d                   	pop    %rbp
    de55:	c3                   	ret
    de56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    de5d:	00 00 00 
    de60:	4d 89 c4             	mov    %r8,%r12
    de63:	49 39 c1             	cmp    %rax,%r9
    de66:	0f 82 ce 00 00 00    	jb     df3a <__divmodti4+0x18a>
    de6c:	31 ff                	xor    %edi,%edi
    de6e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    de73:	48 63 c7             	movslq %edi,%rax
    de76:	be 40 00 00 00       	mov    $0x40,%esi
    de7b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    de80:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    de85:	48 29 c6             	sub    %rax,%rsi
    de88:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    de8d:	48 09 c8             	or     %rcx,%rax
    de90:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    de95:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    de9a:	49 89 c6             	mov    %rax,%r14
    de9d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    dea1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    dea6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    deab:	49 09 c1             	or     %rax,%r9
    deae:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    deb2:	4c 89 c8             	mov    %r9,%rax
    deb5:	49 f7 f6             	div    %r14
    deb8:	48 89 d1             	mov    %rdx,%rcx
    debb:	49 89 c3             	mov    %rax,%r11
    debe:	49 89 c1             	mov    %rax,%r9
    dec1:	49 f7 e2             	mul    %r10
    dec4:	49 89 c6             	mov    %rax,%r14
    dec7:	49 89 d2             	mov    %rdx,%r10
    deca:	48 39 d1             	cmp    %rdx,%rcx
    decd:	72 07                	jb     ded6 <__divmodti4+0x126>
    decf:	75 17                	jne    dee8 <__divmodti4+0x138>
    ded1:	49 39 c7             	cmp    %rax,%r15
    ded4:	73 12                	jae    dee8 <__divmodti4+0x138>
    ded6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    deda:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    dede:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    dee2:	49 89 d2             	mov    %rdx,%r10
    dee5:	49 89 c6             	mov    %rax,%r14
    dee8:	4c 89 f8             	mov    %r15,%rax
    deeb:	4c 29 f0             	sub    %r14,%rax
    deee:	4c 19 d1             	sbb    %r10,%rcx
    def1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    def6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    defb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    df00:	48 09 c6             	or     %rax,%rsi
    df03:	48 89 cf             	mov    %rcx,%rdi
    df06:	31 c0                	xor    %eax,%eax
    df08:	4c 89 c9             	mov    %r9,%rcx
    df0b:	e9 10 ff ff ff       	jmp    de20 <__divmodti4+0x70>
    df10:	4c 89 d0             	mov    %r10,%rax
    df13:	4c 89 da             	mov    %r11,%rdx
    df16:	4d 89 c4             	mov    %r8,%r12
    df19:	49 89 f3             	mov    %rsi,%r11
    df1c:	48 f7 d8             	neg    %rax
    df1f:	49 f7 d4             	not    %r12
    df22:	48 83 d2 00          	adc    $0x0,%rdx
    df26:	49 89 c2             	mov    %rax,%r10
    df29:	48 f7 da             	neg    %rdx
    df2c:	48 89 d1             	mov    %rdx,%rcx
    df2f:	0f 84 cc fe ff ff    	je     de01 <__divmodti4+0x51>
    df35:	49 39 d1             	cmp    %rdx,%r9
    df38:	73 46                	jae    df80 <__divmodti4+0x1d0>
    df3a:	4c 89 cf             	mov    %r9,%rdi
    df3d:	31 c0                	xor    %eax,%eax
    df3f:	31 c9                	xor    %ecx,%ecx
    df41:	e9 da fe ff ff       	jmp    de20 <__divmodti4+0x70>
    df46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df4d:	00 00 00 
    df50:	4d 85 d2             	test   %r10,%r10
    df53:	75 0d                	jne    df62 <__divmodti4+0x1b2>
    df55:	b8 01 00 00 00       	mov    $0x1,%eax
    df5a:	31 d2                	xor    %edx,%edx
    df5c:	49 f7 f2             	div    %r10
    df5f:	49 89 c2             	mov    %rax,%r10
    df62:	4c 89 c8             	mov    %r9,%rax
    df65:	31 d2                	xor    %edx,%edx
    df67:	49 f7 f2             	div    %r10
    df6a:	49 89 c1             	mov    %rax,%r9
    df6d:	4c 89 d8             	mov    %r11,%rax
    df70:	49 f7 f2             	div    %r10
    df73:	49 89 c3             	mov    %rax,%r11
    df76:	4c 89 c8             	mov    %r9,%rax
    df79:	e9 9a fe ff ff       	jmp    de18 <__divmodti4+0x68>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	45 31 f6             	xor    %r14d,%r14d
    df83:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    df88:	44 89 f7             	mov    %r14d,%edi
    df8b:	45 85 f6             	test   %r14d,%r14d
    df8e:	0f 85 df fe ff ff    	jne    de73 <__divmodti4+0xc3>
    df94:	4c 39 ca             	cmp    %r9,%rdx
    df97:	72 17                	jb     dfb0 <__divmodti4+0x200>
    df99:	31 c9                	xor    %ecx,%ecx
    df9b:	48 39 c6             	cmp    %rax,%rsi
    df9e:	73 10                	jae    dfb0 <__divmodti4+0x200>
    dfa0:	4c 89 cf             	mov    %r9,%rdi
    dfa3:	31 c0                	xor    %eax,%eax
    dfa5:	e9 76 fe ff ff       	jmp    de20 <__divmodti4+0x70>
    dfaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dfb0:	4c 89 de             	mov    %r11,%rsi
    dfb3:	b9 01 00 00 00       	mov    $0x1,%ecx
    dfb8:	48 29 c6             	sub    %rax,%rsi
    dfbb:	49 19 d1             	sbb    %rdx,%r9
    dfbe:	eb e0                	jmp    dfa0 <__divmodti4+0x1f0>

000000000000dfc0 <atexit>:
    dfc0:	f3 0f 1e fa          	endbr64
    dfc4:	48 8b 15 3d 40 00 00 	mov    0x403d(%rip),%rdx        # 12008 <__dso_handle>
    dfcb:	31 f6                	xor    %esi,%esi
    dfcd:	e9 8e 56 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000dfd4 <_fini>:
    dfd4:	f3 0f 1e fa          	endbr64
    dfd8:	48 83 ec 08          	sub    $0x8,%rsp
    dfdc:	48 83 c4 08          	add    $0x8,%rsp
    dfe0:	c3                   	ret
